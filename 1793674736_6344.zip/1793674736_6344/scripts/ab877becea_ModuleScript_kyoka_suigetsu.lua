local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("E01E9A")
local v_u_8 = Color3.fromRGB(255, 175, 228)
local v_u_9 = Color3.fromRGB(255, 110, 200)
local v_u_10 = Color3.fromRGB(255, 226, 244)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Wedge
local v_u_13 = Enum.Material.Glass
local v_u_14 = {}
for _, v15 in {
	"Head",
	"UpperTorso",
	"LowerTorso",
	"LeftUpperArm",
	"RightUpperArm",
	"LeftLowerArm",
	"RightLowerArm",
	"LeftHand",
	"RightHand",
	"LeftUpperLeg",
	"RightUpperLeg",
	"LeftLowerLeg",
	"RightLowerLeg",
	"LeftFoot",
	"RightFoot",
	"Torso",
	"Left Arm",
	"Right Arm",
	"Left Leg",
	"Right Leg"
} do
	v_u_14[v15] = true
end
local function v_u_27(p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_31(p28, p29) -- name: setAlpha
	for _, v30 in p28:GetChildren() do
		if not v30:IsA("Decal") then
			continue
		end
		v30.Transparency = p29
	end
end
local function v_u_35(p32, p33) -- name: shardOffsets
	local v34 = CFrame.Angles(0, 3.141592653589793, 0)
	return v34 * CFrame.new(0, p32 / 2, 0), v34 * CFrame.new(0, -p33 / 2, 0) * CFrame.Angles(0, 0, 3.141592653589793)
end
return function(p_u_36)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_31, (copy) v_u_3, (copy) v_u_4, (copy) v_u_11, (copy) v_u_8, (copy) v_u_13, (copy) v_u_12, (copy) v_u_7, (copy) v_u_35, (copy) v_u_9, (copy) v_u_6, (copy) v_u_14, (copy) v_u_10, (copy) v_u_5
	local function v_u_53(p_u_37, p_u_38, p_u_39, p40, p41, p_u_42, p_u_43, p44) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_36, (ref) v_u_31
		local v_u_45 = p44 or 0
		local v_u_46 = v_u_27(p_u_37, p_u_38, p40, p41, v_u_45)
		v_u_1:AddItem(v_u_46, p_u_42 + 0.1)
		p_u_36.animate(p_u_42, 0, function(p47)
			-- upvalues: (copy) v_u_46, (copy) p_u_38, (copy) p_u_39, (copy) p_u_37, (copy) p_u_42, (copy) p_u_43, (ref) v_u_31, (copy) v_u_45
			local v48 = 1 - (1 - p47) ^ 3
			local v49 = v_u_46
			local v50 = p_u_38 + (p_u_39 - p_u_38) * v48
			local v51 = v50 * 2
			local v52 = v50 * 2
			v49.Size = Vector3.new(v51, 0.05, v52)
			v_u_46.CFrame = p_u_37 * CFrame.Angles(0, p47 * p_u_42 * p_u_43, 0)
			v_u_31(v_u_46, v_u_45 + (1 - v_u_45) * p47 ^ 1.5)
			if p47 >= 1 then
				v_u_46:Destroy()
			end
		end)
	end
	local function v_u_65(p54, p55, p56, p57, p58, p59, p60, p61) -- name: viewFlare
		-- upvalues: (ref) v_u_3, (copy) v_u_53, (copy) p_u_36
		local v62 = v_u_3.CurrentCamera
		local v63
		if v62 then
			local v64 = v62.CFrame.Position - p54
			v63 = v64.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v64.Unit
		else
			v63 = Vector3.new(0, 0, 1)
		end
		v_u_53(p_u_36.facing(p54 + v63 * 0.3, v63) * CFrame.Angles(0, p60 or 0, 0), p55, p56, p57, p58, p59, 0, p61)
	end
	local function v_u_103(p66, p67, p68, p69, p_u_70) -- name: splinters
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_13, (ref) v_u_12, (ref) v_u_1, (copy) p_u_36
		local v_u_71 = {}
		for _ = 1, p67 do
			local v72 = p69 * (0.5 + math.random() * 0.8)
			local v73 = v_u_4.part
			local v74 = v72 * 0.7
			local v75 = Vector3.new(0.05, v72, v74)
			local v76 = CFrame.new(p66)
			local v77
			if math.random() < 0.3 then
				v77 = v_u_11
			else
				v77 = v_u_8
			end
			local v78 = v73(v75, v76, v77, {
				["material"] = nil,
				["transparency"] = 0.1,
				["material"] = v_u_13
			})
			v78.Shape = v_u_12
			v_u_1:AddItem(v78, p_u_70 + 0.1)
			local v79 = math.random() - 0.5
			local v80 = math.random() * 0.8
			local v81 = math.random() - 0.5
			local v82 = Vector3.new(v79, v80, v81)
			local v83 = {
				["p"] = v78,
				["v"] = (v82.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v82.Unit) * p68 * (0.6 + math.random() * 0.6),
				["r"] = CFrame.Angles(math.random() * 6, math.random() * 6, math.random() * 6),
				["spin"] = CFrame.Angles((math.random() - 0.5) * 0.6, (math.random() - 0.5) * 0.6, (math.random() - 0.5) * 0.6)
			}
			table.insert(v_u_71, v83)
		end
		local v_u_84 = os.clock()
		local v_u_85 = v_u_84
		p_u_36.frame(function()
			-- upvalues: (ref) v_u_85, (copy) v_u_84, (copy) p_u_70, (copy) v_u_71, (ref) p_u_36
			local v86 = os.clock()
			local v87 = v86 - v_u_85
			local v88 = math.min(v87, 0.05)
			v_u_85 = v86
			local v89 = v86 - v_u_84
			local v90 = (v89 - p_u_70 * 0.5) / (p_u_70 * 0.5)
			local v91 = math.clamp(v90, 0, 1)
			for _, v92 in v_u_71 do
				local v93 = v92.v
				local v94 = v88 * 60
				v92.v = v93 - Vector3.new(0, v94, 0)
				local v95 = v92.p.Position + v92.v * v88
				if v95.Y < p_u_36.FLOOR + 0.1 then
					local v96 = v95.X
					local v97 = p_u_36.FLOOR + 0.1
					local v98 = v95.Z
					v95 = Vector3.new(v96, v97, v98)
					local v99 = v92.v.X * 0.4
					local v100 = v92.v.Y
					local v101 = math.abs(v100) * 0.25
					local v102 = v92.v.Z * 0.4
					v92.v = Vector3.new(v99, v101, v102)
				end
				v92.r = v92.r * v92.spin
				v92.p.CFrame = CFrame.new(v95) * v92.r
				v92.p.Transparency = v91 * 0.9 + 0.1
			end
			return v89 < p_u_70
		end)
	end
	local function v_u_133(p104, p105, p106, p107, p108, p109, p110) -- name: glassShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_35, (ref) v_u_8, (ref) v_u_13, (ref) v_u_12, (copy) p_u_36, (ref) v_u_9, (ref) v_u_11
		local v111 = p104.size
		local v112 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p105, v_u_7, {
			["transparency"] = 1
		})
		local v113, v114 = v_u_35(p107 * 0.6, p107 * 0.4)
		local v115 = v_u_4.part
		local v116 = 0.12 * v111
		local v117 = p107 * 0.6
		local v118 = {
			["material"] = nil,
			["transparency"] = 0.12,
			["material"] = v_u_13
		}
		local v119 = v115(Vector3.new(v116, v117, p106), p105, v_u_8, v118)
		v119.Shape = v_u_12
		local v120 = v_u_4.part
		local v121 = 0.12 * v111
		local v122 = p107 * 0.4
		local v123 = {
			["material"] = nil,
			["transparency"] = 0.12,
			["material"] = v_u_13
		}
		local v124 = v120(Vector3.new(v121, v122, p106), p105, v_u_8, v123)
		v124.Shape = v_u_12
		local v125 = v_u_4.part
		local v126 = 0.18 * v111
		local v127 = p107 * 0.3
		local v128 = p106 * 0.8
		local v129 = v125(Vector3.new(v126, v127, v128), p105, v_u_7)
		v129.Shape = v_u_12
		local v130 = {
			{
				["p"] = v119,
				["off"] = v113
			},
			{
				["p"] = v124,
				["off"] = v114
			},
			{
				["p"] = v129,
				["off"] = v113 * CFrame.new(0, -p107 * 0.15, p106 * 0.05)
			}
		}
		p_u_36.streak(v112, v_u_9, v_u_7, p108, 0.16)
		if p104.mine then
			p_u_36.light(v112, v_u_7, 9 * v111)
		end
		local v131 = {}
		if p110 and not p104.lite then
			local v_u_132 = Instance.new("ParticleEmitter")
			v_u_132.Texture = "rbxassetid://76741008972969"
			v_u_132.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_132.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_132.Color = ColorSequence.new(v_u_11, v_u_8)
			v_u_132.LightEmission = 0.8
			v_u_132.LightInfluence = 0
			v_u_132.Lifetime = NumberRange.new(0.25, 0.4)
			v_u_132.Size = NumberSequence.new(0.55 * v111, 0.1 * v111)
			v_u_132.Speed = NumberRange.new(0.5, 2)
			v_u_132.SpreadAngle = Vector2.new(180, 180)
			v_u_132.Rate = 40
			v_u_132.Parent = v112
			table.insert(v131, function()
				-- upvalues: (copy) v_u_132
				v_u_132.Enabled = false
			end)
		end
		return p_u_36.assemble(v112, v130, {}, 0, 0, v131, 0.16, p109)
	end
	local function v137(p134, p135) -- name: shardHit
		-- upvalues: (copy) v_u_65, (ref) v_u_6, (ref) v_u_8, (ref) v_u_7, (copy) v_u_103, (copy) p_u_36, (ref) v_u_11
		local v136 = p134.size
		v_u_65(p135, 0.8 * v136, 4.4 * v136, v_u_6.KyokaCrack, v_u_8, 0.32, math.random() * 6)
		v_u_65(p135, 0.6 * v136, 3.2 * v136, v_u_6.Glow, v_u_7, 0.18, 0, 0.25)
		v_u_103(p135, p134.lite and 3 or 6, 16 * v136, 0.55 * v136, 0.55)
		p_u_36.burst("Impact", p135, v_u_7, 0.8 * v136)
		if not p134.lite then
			p_u_36.glint(p135, v_u_11, 2.6 * v136, 0.12)
		end
		p_u_36.hitSound(p135)
	end
	local v_u_138 = {}
	setmetatable(v_u_138, {
		["__mode"] = "k"
	})
	local function v_u_159(p139, p140) -- name: bodyCopy
		-- upvalues: (ref) v_u_14, (ref) v_u_9, (ref) v_u_4, (ref) v_u_1, (copy) p_u_36
		local v141 = {
			["parts"] = nil,
			["offs"] = nil,
			["alpha"] = 0.2,
			["parts"] = {},
			["offs"] = {}
		}
		local v142 = p139.caster
		if v142 then
			v142 = p139.caster.Character
		end
		local v143
		if v142 then
			v143 = v142:FindFirstChild("HumanoidRootPart")
		else
			v143 = v142
		end
		if v142 and (v143 and v143:IsA("BasePart")) then
			for _, v144 in v142:GetChildren() do
				if not (v144:IsA("BasePart") and v_u_14[v144.Name]) then
					continue
				end
				local v145 = v144:Clone()
				if not v145 then
					continue
				end
				for _, v146 in v145:GetChildren() do
					if v146:IsA("DataModelMesh") then
						continue
					end
					v146:Destroy()
				end
				if v145:IsA("MeshPart") then
					v145.TextureID = ""
				end
				v145.Anchored = true
				v145.CanCollide = false
				v145.CanQuery = false
				v145.CanTouch = false
				v145.CastShadow = false
				v145.Massless = true
				v145.Material = Enum.Material.Neon
				v145.Color = v_u_9
				v145.Transparency = 1
				v145.Parent = v_u_4.folder()
				v_u_1:AddItem(v145, p140)
				local v147 = v141.parts
				table.insert(v147, v145)
				local v148 = v141.offs
				local v149 = v143.CFrame
				local v150 = v144.CFrame
				table.insert(v148, v149:ToObjectSpace(v150))
			end
			if #v141.parts > 0 then
				local v151 = v143.Position.Y - p_u_36.FLOOR
				return v141, math.max(v151, 2)
			end
		end
		local v152 = {
			CFrame.new(0, 1.55, 0),
			CFrame.new(0, 0, 0),
			CFrame.new(-1.5, 0, 0),
			CFrame.new(1.5, 0, 0),
			CFrame.new(-0.5, -2, 0),
			CFrame.new(0.5, -2, 0)
		}
		for v153, v154 in {
			Vector3.new(1.1, 1.1, 1.1),
			Vector3.new(2, 2, 1),
			Vector3.new(0.9, 2, 0.9),
			Vector3.new(0.9, 2, 0.9),
			Vector3.new(0.9, 2, 0.9),
			Vector3.new(0.9, 2, 0.9)
		} do
			local v155 = v_u_4.part(v154, CFrame.identity, v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v155, p140)
			local v156 = v141.parts
			table.insert(v156, v155)
			local v157 = v141.offs
			local v158 = v152[v153]
			table.insert(v157, v158)
		end
		return v141, 3
	end
	local function v226(p160, p161, p162) -- name: raiseMirrors
		-- upvalues: (copy) p_u_36, (copy) v_u_138, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_13, (ref) v_u_11, (ref) v_u_1, (copy) v_u_159
		local v_u_163 = p160.size
		local v164 = p160.ability.radius * v_u_163
		local v165 = p160.ability.freeze or 3
		local v166 = p_u_36.ground(p161, 0)
		local v167 = p160.lite
		local v168 = v167 and 3 or 5
		local v169 = v164 * 0.62
		local v170 = p162 + 2
		local v_u_171 = 6.4 * v_u_163
		local v_u_172 = {
			["g"] = nil,
			["mirrors"] = nil,
			["rootHeight"] = 3,
			["g"] = v166,
			["mirrors"] = {}
		}
		v_u_138[p160] = v_u_172
		v_u_4.ring(v166, v_u_7, v164, 0.35, v_u_6.Ring)
		p_u_36.mark(v166, v_u_7, v164 * 0.8, p162 + v165 * 0.5, v_u_6.KyokaCrack, 0.35)
		local v173 = p_u_36.flatUnit(p160.feet - v166)
		local v174 = v173.Z
		local v175 = v173.X
		local v176 = math.atan2(v174, v175) + 3.141592653589793 / v168
		for v177 = 0, v168 - 1 do
			local v178 = v176 + v177 * 3.141592653589793 * 2 / v168
			local v179 = math.cos(v178)
			local v180 = math.sin(v178)
			local v181 = v166 + Vector3.new(v179, 0, v180) * v169
			local v182 = CFrame.lookAt
			local v183 = v166.X
			local v184 = v181.Y
			local v185 = v166.Z
			local v186 = v182(v181, (Vector3.new(v183, v184, v185)))
			local v187 = v_u_4.part
			local v188 = 3.8 * v_u_163
			local v189 = {
				["material"] = nil,
				["transparency"] = 0.45,
				["material"] = v_u_13
			}
			local v190 = v187(Vector3.new(v188, v_u_171, 0.15), v186, v_u_8, v189)
			for _, v191 in { Enum.NormalId.Front, Enum.NormalId.Back } do
				local v192 = Instance.new("Decal")
				v192.Face = v191
				v192.Texture = v_u_6.KyokaCrack
				v192.Color3 = v_u_11
				v192.Transparency = 1
				v192.Parent = v190
			end
			v_u_1:AddItem(v190, v170)
			local v193 = {}
			if not v167 then
				local v194 = 3.8 * v_u_163
				local v195 = {}
				local v196 = 0.35 * v_u_163
				local v197 = v_u_171 + 0.35 * v_u_163
				local v198 = Vector3.new(v196, v197, 0.25)
				local v199 = 0.35 * v_u_163
				local v200 = v_u_171 + 0.35 * v_u_163
				local v201 = Vector3.new(v199, v200, 0.25)
				local v202 = v194 + 0.35 * v_u_163
				local v203 = 0.35 * v_u_163
				local v204 = Vector3.new(v202, v203, 0.25)
				local v205 = v194 + 0.35 * v_u_163
				local v206 = 0.35 * v_u_163
				__set_list(v195, 1, {v198, v201, v204, (Vector3.new(v205, v206, 0.25))})
				for _, v207 in v195 do
					local v208 = v_u_4.part(v207, v186, v_u_7)
					v_u_1:AddItem(v208, v170)
					table.insert(v193, v208)
				end
			end
			local v209, v210 = v_u_159(p160, v170)
			v_u_172.rootHeight = v210
			local v211 = v_u_172.mirrors
			table.insert(v211, {
				["pane"] = v190,
				["rim"] = v193,
				["copy"] = v209,
				["spot"] = v186,
				["height"] = v_u_171
			})
		end
		local v212 = 3.8 * v_u_163
		local v_u_213 = {
			CFrame.new(-v212 / 2, 0, 0),
			CFrame.new(v212 / 2, 0, 0),
			CFrame.new(0, v_u_171 / 2, 0),
			CFrame.new(0, -v_u_171 / 2, 0)
		}
		p_u_36.animate(math.max(p162, 0.1), 0, function(p214)
			-- upvalues: (copy) v_u_172, (copy) v_u_171, (copy) v_u_163, (copy) v_u_213
			local v215 = p214 - 1
			local v216 = v215 * 2.8 * v215 * v215 + 1 + v215 * 1.8 * v215
			for _, v217 in v_u_172.mirrors do
				local v218 = -v_u_171 / 2 + (v_u_171 + 0.4 * v_u_163) * v216
				v217.pane.CFrame = v217.spot * CFrame.new(0, v218, 0)
				for v219, v220 in v217.rim do
					v220.CFrame = v217.spot * CFrame.new(0, v218, 0) * v_u_213[v219]
				end
				local v221 = v217.copy
				local v222 = v217.spot * CFrame.new(0, v_u_172.rootHeight - 0.4 * (1 - p214), -0.4)
				local v223 = 1 - (1 - v217.copy.alpha) * p214
				for v224, v225 in v221.parts do
					v225.CFrame = v222 * v221.offs[v224]
					v225.Transparency = v223
				end
			end
		end)
	end
	local function v286(p_u_227, p228) -- name: hypnotize
		-- upvalues: (copy) v_u_138, (copy) p_u_36, (ref) v_u_31, (copy) v_u_103, (copy) v_u_65, (ref) v_u_6, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5, (ref) v_u_27, (ref) v_u_1, (ref) v_u_3
		local v_u_229 = p_u_227.size
		local v_u_230 = p_u_227.ability.radius * v_u_229
		local v231 = p_u_227.ability.freeze or 3
		local v_u_232 = p_u_227.lite
		local v233 = v_u_138[p_u_227]
		v_u_138[p_u_227] = nil
		local v_u_234
		if v233 then
			v_u_234 = v233.g
		else
			v_u_234 = p_u_36.ground(p228, 0)
		end
		if v233 then
			for v_u_235, v_u_236 in v233.mirrors do
				v_u_31(v_u_236.pane, 0.05)
				local v_u_237 = v_u_236.pane.Position
				p_u_36.after(0.06, function()
					-- upvalues: (copy) v_u_236, (ref) v_u_103, (copy) v_u_237, (copy) v_u_232, (copy) v_u_229, (ref) v_u_65, (ref) v_u_6, (ref) v_u_8, (copy) v_u_235
					v_u_236.pane:Destroy()
					for _, v238 in v_u_236.rim do
						v238:Destroy()
					end
					v_u_103(v_u_237, v_u_232 and 4 or 8, 22 * v_u_229, 0.9 * v_u_229, 0.7)
					v_u_65(v_u_237, 1.5 * v_u_229, 5.5 * v_u_229, v_u_6.KyokaCrack, v_u_8, 0.3, v_u_235)
				end)
				local v_u_239 = v_u_236.spot * CFrame.new(0, v233.rootHeight, -0.4)
				local v_u_240 = (v_u_236.spot.Position - v_u_234).Magnitude * 0.55
				p_u_36.animate(0.14, 0, function(p241)
					-- upvalues: (copy) v_u_236, (copy) v_u_239, (copy) v_u_240, (copy) v_u_229, (ref) v_u_65, (ref) v_u_6, (ref) v_u_10, (copy) v_u_235, (ref) p_u_36
					local v242 = 1 - (1 - p241) ^ 2
					local v243 = v_u_236.copy
					local v244 = v_u_239 * CFrame.new(0, 0, -v_u_240 * v242)
					local v245 = v_u_236.copy.alpha
					for v246, v247 in v243.parts do
						v247.CFrame = v244 * v243.offs[v246]
						v247.Transparency = v245
					end
					if p241 >= 1 then
						v_u_65((v_u_239 * CFrame.new(0, 0.5 * v_u_229, -v_u_240 - 1.5 * v_u_229)).Position, 3.5 * v_u_229, 7.5 * v_u_229, v_u_6.KyokaSlash, v_u_10, 0.28, v_u_235 * 2.1 + math.random())
						p_u_36.animate(0.35, 0, function(p248)
							-- upvalues: (ref) v_u_236
							for _, v249 in v_u_236.copy.parts do
								v249.Transparency = v_u_236.copy.alpha + (1 - v_u_236.copy.alpha) * p248
							end
							if p248 >= 1 then
								for _, v250 in v_u_236.copy.parts do
									v250:Destroy()
								end
							end
						end)
					end
				end)
			end
		end
		local v_u_251 = v_u_234 + Vector3.new(0, 3, 0) * v_u_229
		p_u_36.after(0.12, function()
			-- upvalues: (ref) v_u_65, (copy) v_u_251, (copy) v_u_229, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (ref) v_u_7, (ref) p_u_36, (ref) v_u_4, (copy) v_u_234, (copy) v_u_230, (ref) v_u_5, (copy) p_u_227
			v_u_65(v_u_251, 5 * v_u_229, 11 * v_u_229, v_u_6.KyokaSlash, v_u_11, 0.32, 0.6108652381980153)
			v_u_65(v_u_251, 5 * v_u_229, 11 * v_u_229, v_u_6.KyokaSlash, v_u_9, 0.32, 3.0543261909900767)
			v_u_65(v_u_251, 2 * v_u_229, 9 * v_u_229, v_u_6.Glow, v_u_7, 0.25, 0, 0.2)
			p_u_36.burst("Impact", v_u_251, v_u_7, 1.6 * v_u_229)
			v_u_4.ring(v_u_234, v_u_9, v_u_230 * 1.05, 0.4, v_u_6.Shockwave)
			v_u_5.play("Crit", {
				["at"] = v_u_251,
				["volume"] = p_u_227.mine and 0.8 or 0.45
			})
			if p_u_227.mine then
				v_u_4.shake(0.3, 0.3)
			end
		end)
		local v_u_252 = v_u_234 + Vector3.new(0, 11, 0) * v_u_229
		local v_u_253 = v_u_27(CFrame.new(v_u_252), 0.1, v_u_6.Swirl, v_u_7, 0.25)
		local v_u_254 = v_u_27(CFrame.new(v_u_252), 0.1, p_u_36.iris("kyoka_suigetsu"), v_u_11, 0.05)
		local v_u_255 = v231 + 0.3
		v_u_1:AddItem(v_u_253, v_u_255 + 0.6)
		v_u_1:AddItem(v_u_254, v_u_255 + 0.6)
		local v_u_256
		if v_u_232 then
			v_u_256 = nil
		else
			local v257 = v_u_4.part
			local v258 = v_u_230 * 1.5
			local v259 = 4 * v_u_229
			local v260 = v_u_230 * 1.5
			local v261 = v257(Vector3.new(v258, v259, v260), CFrame.new(v_u_234 + Vector3.new(0, 3, 0) * v_u_229), v_u_7, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v261, v_u_255 + 1)
			v_u_256 = Instance.new("ParticleEmitter")
			v_u_256.Texture = "rbxassetid://76741008972969"
			v_u_256.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_256.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_256.Color = ColorSequence.new(v_u_11, v_u_8)
			v_u_256.LightEmission = 0.8
			v_u_256.LightInfluence = 0
			v_u_256.Lifetime = NumberRange.new(0.5, 0.9)
			v_u_256.Size = NumberSequence.new(0.9 * v_u_229, 0.2 * v_u_229)
			v_u_256.Speed = NumberRange.new(0.5, 2)
			v_u_256.SpreadAngle = Vector2.new(180, 180)
			v_u_256.Shape = Enum.ParticleEmitterShape.Box
			v_u_256.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_256.Rate = 16
			v_u_256.Parent = v261
		end
		local v_u_262 = os.clock()
		p_u_36.frame(function()
			-- upvalues: (copy) v_u_262, (copy) v_u_254, (copy) v_u_255, (copy) v_u_253, (copy) v_u_252, (ref) v_u_3, (copy) v_u_229, (ref) p_u_36, (ref) v_u_31, (ref) v_u_256
			local v263 = os.clock() - v_u_262
			if not v_u_254.Parent or v_u_255 + 0.3 < v263 then
				v_u_253:Destroy()
				v_u_254:Destroy()
				return false
			end
			local v264 = v263 / 0.3
			local v265 = math.clamp(v264, 0, 1) - 1
			local v266 = v265 * 2.8 * v265 * v265 + 1 + v265 * 1.8 * v265
			local v267 = (v263 - v_u_255) / 0.3
			local v268 = math.clamp(v267, 0, 1)
			local v269 = v263 * 7
			local v270 = math.sin(v269) * 0.05 + 1
			local v271 = v_u_252
			local v272 = v_u_3.CurrentCamera
			local v273
			if v272 then
				local v274 = v272.CFrame.Position - v271
				v273 = v274.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v274.Unit
			else
				v273 = Vector3.new(0, 0, 1)
			end
			local v275 = v_u_254
			local v276 = 4.6 * v_u_229 * v266 * (1 - v268) * v270
			local v277 = math.max(v276, 0.05)
			local v278 = v277 * 2
			local v279 = v277 * 2
			v275.Size = Vector3.new(v278, 0.05, v279)
			local v280 = v_u_253
			local v281 = 7.5 * v_u_229 * v266 * (v268 * 0.3 + 1)
			local v282 = math.max(v281, 0.05)
			local v283 = v282 * 2
			local v284 = v282 * 2
			v280.Size = Vector3.new(v283, 0.05, v284)
			v_u_254.CFrame = p_u_36.facing(v_u_252 + v273 * 0.2, v273) * CFrame.Angles(0, v263 * 0.8, 0)
			v_u_253.CFrame = p_u_36.facing(v_u_252, v273) * CFrame.Angles(0, -v263 * 2.4, 0)
			v_u_31(v_u_254, v268 * 0.95 + 0.05)
			v_u_31(v_u_253, v268 * 0.75 + 0.25)
			local v285 = v268 > 0 and v_u_256
			if v285 then
				v285.Enabled = false
			end
			return true
		end)
	end
	local v_u_287 = {}
	setmetatable(v_u_287, {
		["__mode"] = "k"
	})
	local function v401(p_u_288, p289, p_u_290) -- name: riseMoon
		-- upvalues: (copy) p_u_36, (copy) v_u_287, (ref) v_u_27, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (ref) v_u_3, (ref) v_u_31, (copy) v_u_65, (ref) v_u_13, (ref) v_u_12, (ref) v_u_5
		local v_u_291 = p_u_288.size
		local v_u_292 = p_u_288.ability.radius * v_u_291
		local v_u_293 = p_u_288.lite
		local v_u_294 = p_u_36.ground(p289, 0)
		local v_u_295 = 11 * v_u_291
		local v_u_296 = v_u_294 + Vector3.new(0, 30, 0) * v_u_291
		v_u_287[p_u_288] = {
			["at"] = v_u_296,
			["radius"] = v_u_295,
			["g"] = v_u_294
		}
		local v297 = p_u_290 + 0.6
		local v_u_298 = v_u_27(CFrame.new(v_u_296), 0.1, v_u_6.Glow, v_u_9, 0.35)
		local v_u_299 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v_u_296), v_u_10)
		local v300 = Instance.new("SpecialMesh")
		v300.MeshType = Enum.MeshType.Sphere
		v300.Parent = v_u_299
		local v_u_301 = v_u_27(CFrame.new(v_u_296), 0.1, v_u_6.Ring, v_u_7, 0)
		local v_u_302
		if v_u_293 then
			v_u_302 = nil
		else
			v_u_302 = v_u_27(CFrame.new(v_u_296), 0.1, p_u_36.iris("kyoka_suigetsu"), v_u_11, 0.7)
		end
		local v_u_303 = v_u_27(CFrame.new(v_u_296), 0.1, v_u_6.KyokaCrack, v_u_7, 0.6)
		local v_u_304 = {
			v_u_298,
			v_u_299,
			v_u_301,
			v_u_303
		}
		if v_u_302 then
			table.insert(v_u_304, v_u_302)
		end
		for _, v305 in v_u_304 do
			v_u_1:AddItem(v305, v297)
		end
		local v_u_306 = v_u_27(CFrame.new(v_u_294 + Vector3.new(0, 0.12, 0)), 0.1, v_u_6.Glow, v_u_9, 0.45)
		local v_u_307 = v_u_27(CFrame.new(v_u_294 + Vector3.new(0, 0.16, 0)), 0.1, v_u_6.Ring, v_u_7, 0.3)
		v_u_1:AddItem(v_u_306, v297 + 0.6)
		v_u_1:AddItem(v_u_307, v297 + 0.6)
		local v_u_308
		if v_u_293 then
			v_u_308 = nil
		else
			local v309 = Instance.new("Attachment")
			v309.Parent = v_u_299
			local v310 = Instance.new("Attachment")
			v310.Parent = v_u_306
			v_u_308 = Instance.new("Beam")
			v_u_308.Attachment0 = v309
			v_u_308.Attachment1 = v310
			v_u_308.Texture = v_u_6.Beam
			v_u_308.TextureMode = Enum.TextureMode.Stretch
			v_u_308.TextureSpeed = 0.6
			v_u_308.Color = ColorSequence.new(v_u_10, v_u_9)
			v_u_308.LightEmission = 0.6
			v_u_308.LightInfluence = 0
			v_u_308.FaceCamera = true
			v_u_308.Width0 = v_u_295 * 1.4
			v_u_308.Width1 = v_u_292 * 1.7
			v_u_308.Transparency = NumberSequence.new(1)
			v_u_308.Segments = 1
			v_u_308.Parent = v_u_299
		end
		local v_u_311 = os.clock()
		p_u_36.frame(function()
			-- upvalues: (copy) v_u_311, (copy) v_u_299, (copy) p_u_290, (copy) v_u_291, (copy) v_u_296, (ref) v_u_3, (ref) p_u_36, (copy) v_u_295, (copy) v_u_298, (copy) v_u_301, (copy) v_u_302, (copy) v_u_303, (ref) v_u_31, (copy) v_u_306, (copy) v_u_292, (copy) v_u_307, (copy) v_u_294, (ref) v_u_308
			local v312 = os.clock() - v_u_311
			if not v_u_299.Parent then
				return false
			end
			local v313 = v312 / 0.3
			local v314 = math.clamp(v313, 0, 1) - 1
			local v315 = v314 * 2.8 * v314 * v314 + 1 + v314 * 1.8 * v314
			local v316 = p_u_290
			local v317 = v312 / math.max(v316, 0.2)
			local v318 = math.clamp(v317, 0, 1)
			local v319 = math.random() - 0.5
			local v320 = math.random() - 0.5
			local v321 = math.random() - 0.5
			local v322 = Vector3.new(v319, v320, v321) * (0.5 * v_u_291 * v318 * v318)
			local v323 = v_u_296
			local v324 = v_u_3.CurrentCamera
			local v325
			if v324 then
				local v326 = v324.CFrame.Position - v323
				v325 = v326.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v326.Unit
			else
				v325 = Vector3.new(0, 0, 1)
			end
			local v327 = p_u_36.facing(v_u_296 + v322, v325)
			local v328 = v_u_295 * v315
			v_u_298.CFrame = v327 * CFrame.new(0, -0.6, 0)
			local v329 = v_u_298
			local v330 = v328 * 1.75
			local v331 = v330 * 2
			local v332 = v330 * 2
			v329.Size = Vector3.new(v331, 0.05, v332)
			v_u_299.CFrame = CFrame.lookAt(v_u_296 + v322, v_u_296 + v322 + v325)
			local v333 = v_u_299
			local v334 = v328 * 2
			local v335 = v328 * 2
			v333.Size = Vector3.new(v334, v335, 0.3)
			v_u_301.CFrame = v327 * CFrame.new(0, 0.2, 0)
			local v336 = v_u_301
			local v337 = v328 * 1.08
			local v338 = v337 * 2
			local v339 = v337 * 2
			v336.Size = Vector3.new(v338, 0.05, v339)
			if v_u_302 then
				v_u_302.CFrame = v327 * CFrame.new(0, 0.25, 0) * CFrame.Angles(0, v312 * 0.6, 0)
				local v340 = v_u_302
				local v341 = v328 * 0.72
				local v342 = v341 * 2
				local v343 = v341 * 2
				v340.Size = Vector3.new(v342, 0.05, v343)
			end
			v_u_303.CFrame = v327 * CFrame.new(0, 0.3, 0)
			local v344 = v_u_303
			local v345 = v328 * (v318 * 0.88 + 0.2)
			local v346 = v345 * 2
			local v347 = v345 * 2
			v344.Size = Vector3.new(v346, 0.05, v347)
			v_u_31(v_u_303, 0.6 - v318 * 0.6)
			local v348 = v_u_306
			local v349 = v_u_292 * 0.9 * v315
			local v350 = v349 * 2
			local v351 = v349 * 2
			v348.Size = Vector3.new(v350, 0.05, v351)
			local v352 = v_u_307
			local v353 = v_u_292 * v315
			local v354 = v353 * 2
			local v355 = v353 * 2
			v352.Size = Vector3.new(v354, 0.05, v355)
			v_u_307.CFrame = CFrame.new(v_u_294 + Vector3.new(0, 0.16, 0)) * CFrame.Angles(0, v312 * 0.5, 0)
			local v356 = v_u_308
			if v356 then
				local v357 = v312 * 6
				local v358 = 0.82 - math.sin(v357) * 0.1
				local v359 = NumberSequence.new
				local v360 = {}
				local v361 = NumberSequenceKeypoint.new(0, v358)
				local v362 = NumberSequenceKeypoint.new
				local v363 = v358 + 0.12
				__set_list(v360, 1, {v361, v362(1, (math.min(v363, 1)))})
				v356.Transparency = v359(v360)
			end
			return true
		end)
		p_u_36.after(p_u_290, function()
			-- upvalues: (copy) v_u_304, (copy) v_u_306, (copy) v_u_307, (ref) p_u_36, (ref) v_u_31, (ref) v_u_65, (copy) v_u_296, (copy) v_u_295, (ref) v_u_6, (ref) v_u_10, (ref) v_u_9, (copy) v_u_291, (ref) v_u_3, (copy) v_u_293, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12, (ref) v_u_7, (ref) v_u_1, (copy) v_u_294, (copy) v_u_292, (ref) v_u_5, (copy) p_u_288
			for _, v364 in v_u_304 do
				v364:Destroy()
			end
			for _, v_u_365 in { v_u_306, v_u_307 } do
				p_u_36.animate(0.5, 0, function(p366)
					-- upvalues: (ref) v_u_31, (copy) v_u_365
					v_u_31(v_u_365, 0.45 + 0.55 * p366)
					if p366 >= 1 then
						v_u_365:Destroy()
					end
				end)
			end
			v_u_65(v_u_296, v_u_295 * 0.8, v_u_295 * 2.2, v_u_6.Glow, v_u_10, 0.35, 0, 0.1)
			v_u_65(v_u_296, v_u_295, v_u_295 * 2.6, v_u_6.KyokaCrack, v_u_9, 0.5, math.random() * 6)
			p_u_36.burst("Flash", v_u_296, v_u_9, 0.8 * v_u_291)
			local v367 = v_u_296
			local v368 = v_u_3.CurrentCamera
			local v369
			if v368 then
				local v370 = v368.CFrame.Position - v367
				v369 = v370.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v370.Unit
			else
				v369 = Vector3.new(0, 0, 1)
			end
			local v371 = CFrame.lookAt(v_u_296, v_u_296 + v369)
			local v372 = v_u_293 and 6 or 12
			local v_u_373 = {}
			for v374 = 1, v372 do
				local v375 = (v374 - 1) / v372 * 3.141592653589793 * 2 + math.random() * 0.4
				local v376 = math.cos(v375)
				local v377 = math.sin(v375)
				local v378 = v371:VectorToWorldSpace((Vector3.new(v376, v377, 0)))
				local v379 = v_u_295 * (0.35 + math.random() * 0.25)
				local v380 = v_u_4.part
				local v381 = v379 * 0.6
				local v382 = Vector3.new(0.15, v379, v381)
				local v383 = {
					["material"] = nil,
					["transparency"] = 0.1,
					["material"] = v_u_13
				}
				local v384 = v380(v382, CFrame.new(v_u_296), v_u_10, v383)
				v384.Shape = v_u_12
				local v385 = v_u_4.part
				local v386 = v379 * 0.5
				local v387 = v379 * 0.3
				local v388 = v385(Vector3.new(0.2, v386, v387), CFrame.new(v_u_296), v_u_7)
				v388.Shape = v_u_12
				v_u_1:AddItem(v384, 1.3)
				v_u_1:AddItem(v388, 1.3)
				local v389 = {
					["a"] = v384,
					["b"] = v388,
					["v"] = v378 * (34 + math.random() * 16) * v_u_291 + Vector3.new(0, 8, 0) * v_u_291,
					["r"] = v371 * CFrame.Angles(0, 0, v375) * CFrame.new(0, v_u_295 * 0.45, 0),
					["spin"] = CFrame.Angles((math.random() - 0.5) * 0.25, (math.random() - 0.5) * 0.25, (math.random() - 0.5) * 0.25)
				}
				table.insert(v_u_373, v389)
			end
			local v_u_390 = os.clock()
			local v_u_391 = v_u_390
			p_u_36.frame(function()
				-- upvalues: (ref) v_u_391, (copy) v_u_390, (copy) v_u_373
				local v392 = os.clock()
				local v393 = v392 - v_u_391
				local v394 = math.min(v393, 0.05)
				v_u_391 = v392
				local v395 = v392 - v_u_390
				local v396 = (v395 - 0.5) / 0.7
				local v397 = math.clamp(v396, 0, 1)
				for _, v398 in v_u_373 do
					local v399 = v398.v
					local v400 = v394 * 40
					v398.v = v399 - Vector3.new(0, v400, 0)
					v398.r = (v398.r + v398.v * v394) * v398.spin
					v398.a.CFrame = v398.r
					v398.b.CFrame = v398.r * CFrame.new(0.1, -v398.a.Size.Y * 0.15, 0)
					v398.a.Transparency = v397 * 0.9 + 0.1
					v398.b.Transparency = v397
				end
				return v395 < 1.2
			end)
			v_u_4.ring(v_u_294, v_u_9, v_u_292 * 1.3, 0.55, v_u_6.Ring)
			v_u_5.play("Explosion", {
				["at"] = v_u_296,
				["volume"] = p_u_288.mine and 0.9 or 0.5
			})
			if p_u_288.mine then
				v_u_4.shake(0.5, 0.45)
			end
		end)
	end
	local function v_u_405(p402, p403) -- name: fallingShard
		-- upvalues: (copy) v_u_133
		local v404 = p402.size
		return v_u_133(p402, p403, 7 * v404, 2.4 * v404, 1.3 * v404, 6, true)
	end
	local function v_u_412(p406, p407) -- name: shardLands
		-- upvalues: (copy) p_u_36, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (copy) v_u_65, (ref) v_u_9, (copy) v_u_103, (copy) v_u_287, (ref) v_u_10, (ref) v_u_5
		local v408 = p406.size
		local v409 = p_u_36.ground(p407, 0)
		local v410 = (p406.ability.strikeRadius or 8) * v408
		v_u_4.ring(v409, v_u_7, v410, 0.35, v_u_6.Ring)
		p_u_36.mark(v409, v_u_7, v410 * 0.8, 1.3, v_u_6.KyokaCrack, 0.1)
		v_u_65(v409 + Vector3.new(0, 2, 0) * v408, 1.5 * v408, 6 * v408, v_u_6.Glow, v_u_9, 0.22, 0, 0.2)
		v_u_103(v409 + Vector3.new(0, 1.5, 0) * v408, p406.lite and 4 or 8, 20 * v408, 0.8 * v408, 0.65)
		p_u_36.burst("Impact", v409 + Vector3.new(0, 1.5, 0) * v408, v_u_7, 1.2 * v408)
		local v411 = v_u_287[p406]
		if v411 then
			v_u_4.ring(v411.g, v_u_10, (p406.ability.radius or 18) * v408 * 0.7, 0.4, v_u_6.Ring)
		end
		v_u_5.play("Hit", {
			["at"] = v409,
			["volume"] = p406.mine and 0.7 or 0.35
		})
	end
	local function v_u_417(p413, p414) -- name: skillCast
		-- upvalues: (copy) v_u_65, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_53, (copy) p_u_36, (ref) v_u_4, (ref) v_u_11
		local v415 = p413.size
		local v416 = p413.eye + p413.dir * 1.2
		v_u_65(v416, 0.6 * v415, (p414 and 4.5 or 3.2) * v415, v_u_6.Glow, v_u_7, 0.2, 0, 0.1)
		v_u_65(v416, 0.5 * v415, (p414 and 3.4 or 2.4) * v415, v_u_6.KyokaCrack, v_u_8, 0.28, math.random() * 6)
		v_u_53(p_u_36.facing(v416, p413.dir), 0.4 * v415, (p414 and 3 or 2.2) * v415, v_u_6.Swirl, v_u_7, 0.3, -10, 0.1)
		v_u_4.ring(p413.feet, v_u_7, (p414 and 9 or 6) * v415, 0.3, v_u_6.Ring)
		if not p413.lite then
			p_u_36.glint(v416, v_u_11, (p414 and 3 or 2) * v415, 0.14)
		end
		if p413.mine then
			v_u_4.shake(p414 and 0.15 or 0.07, 0.14)
		end
	end
	local v426 = {
		["kyoka_suigetsu_a"] = {
			["cast"] = function(p418) -- name: cast
				-- upvalues: (copy) v_u_65, (ref) v_u_6, (ref) v_u_7, (copy) p_u_36, (ref) v_u_10
				local v419 = p418.size
				local v420 = p418.eye + p418.dir * 1.1
				v_u_65(v420, 0.4 * v419, 1.9 * v419, v_u_6.Glow, v_u_7, 0.12, 0, 0.15)
				if not p418.lite then
					p_u_36.glint(v420, v_u_10, 1.8 * v419, 0.1)
				end
			end,
			["shot"] = function(p421, p422) -- name: shot
				-- upvalues: (copy) v_u_133
				local v423 = p421.size
				return v_u_133(p421, p422, 2.4 * v423, 0.85 * v423, 0.6 * v423, 16, true)
			end,
			["impact"] = v137,
			["hit"] = function(p424, p425, _) -- name: hit
				-- upvalues: (copy) p_u_36, (ref) v_u_7, (copy) v_u_65, (ref) v_u_6, (ref) v_u_8
				p_u_36.burst("Impact", p425, v_u_7, 0.55)
				if not p424.lite then
					v_u_65(p425, 0.4 * p424.size, 2 * p424.size, v_u_6.KyokaCrack, v_u_8, 0.2, math.random() * 6)
				end
			end
		}
	}
	local v_u_427 = {}
	setmetatable(v_u_427, {
		["__mode"] = "k"
	})
	v426.kyoka_suigetsu_e = {
		["castSound"] = "EyeActivate",
		["cast"] = nil,
		["windup"] = nil,
		["land"] = nil,
		["hit"] = nil,
		["cast"] = function(p428) -- name: cast
			-- upvalues: (copy) v_u_417
			v_u_417(p428, false)
		end,
		["windup"] = v226,
		["land"] = v286,
		["hit"] = function(p429, p430, _) -- name: hit
			-- upvalues: (copy) p_u_36, (ref) v_u_7, (copy) v_u_427, (ref) v_u_27, (ref) v_u_6, (ref) v_u_1, (ref) v_u_3
			p_u_36.burst("Impact", p430, v_u_7, 0.6)
			local v431 = (v_u_427[p429] or 0) + 1
			v_u_427[p429] = v431
			if not p429.lite and v431 <= 12 then
				local v_u_432 = p429.size
				local v_u_433 = p430 + Vector3.new(0, 3.2, 0) * v_u_432
				local v_u_434 = v_u_27(CFrame.new(v_u_433), 0.1, v_u_6.Swirl, v_u_7, 0.1)
				local v_u_435 = p429.ability.freeze or 3
				v_u_1:AddItem(v_u_434, v_u_435 + 0.6)
				local v_u_436 = os.clock()
				p_u_36.frame(function()
					-- upvalues: (copy) v_u_436, (copy) v_u_434, (copy) v_u_435, (copy) v_u_432, (ref) p_u_36, (copy) v_u_433, (ref) v_u_3
					local v437 = os.clock() - v_u_436
					if not v_u_434.Parent or v_u_435 < v437 then
						v_u_434:Destroy()
						return false
					end
					local v438 = v437 / 0.25
					local v439 = math.clamp(v438, 0, 1) - 1
					local v440 = v439 * 2.8 * v439 * v439 + 1 + v439 * 1.8 * v439
					local v441 = (v437 - v_u_435 + 0.3) / 0.3
					local v442 = math.clamp(v441, 0, 1)
					local v443 = v_u_434
					local v444 = 1.3 * v_u_432 * v440 * (1 - v442)
					local v445 = math.max(v444, 0.05)
					local v446 = v445 * 2
					local v447 = v445 * 2
					v443.Size = Vector3.new(v446, 0.05, v447)
					local v448 = v_u_434
					local v449 = p_u_36.facing
					local v450 = v_u_433
					local v451 = v_u_433
					local v452 = v_u_3.CurrentCamera
					local v453
					if v452 then
						local v454 = v452.CFrame.Position - v451
						v453 = v454.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v454.Unit
					else
						v453 = Vector3.new(0, 0, 1)
					end
					v448.CFrame = v449(v450, v453) * CFrame.Angles(0, -v437 * 5, 0)
					return true
				end)
			end
		end
	}
	v426.kyoka_suigetsu_r = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["strike"] = nil,
		["hit"] = nil,
		["cast"] = function(p455) -- name: cast
			-- upvalues: (copy) v_u_417
			v_u_417(p455, true)
		end,
		["windup"] = v401,
		["strike"] = function(p_u_456, p457, p458) -- name: strike
			-- upvalues: (copy) v_u_287, (copy) p_u_36, (copy) v_u_405, (copy) v_u_412
			local v459 = p_u_456.size
			local v460 = v_u_287[p_u_456]
			local v461
			if v460 then
				local v462 = v460.at
				local v463 = (math.random() - 0.5) * 1.2
				local v464 = (math.random() - 0.5) * 1.2
				v461 = v462 + Vector3.new(v463, -0.3, v464) * v460.radius
			else
				v461 = p457 + Vector3.new(0, 30, 0) * v459
			end
			local v465 = p_u_36.ground(p457, 0) + Vector3.new(0, 1.6, 0) * v459
			p_u_36.drop(p_u_456, v_u_405, v461, v465, 0.32, p458, 0.45, function(p466)
				-- upvalues: (ref) v_u_412, (copy) p_u_456
				v_u_412(p_u_456, p466)
			end)
		end,
		["hit"] = function(p467, p468, _) -- name: hit
			-- upvalues: (copy) p_u_36, (ref) v_u_7, (ref) v_u_10
			p_u_36.burst("Impact", p468, v_u_7, 0.8)
			if not p467.lite then
				p_u_36.glint(p468, v_u_10, 2.6, 0.12)
			end
		end
	}
	return v426
end