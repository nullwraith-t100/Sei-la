local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_4 = require(script.Parent.Parent.Mythic8)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.SunSeal,
	v_u_7.SunRays,
	v_u_7.SunFlame,
	v_u_7.FireBeam
})
local v_u_8 = Color3.fromHex("FFB21F")
local v_u_9 = Color3.fromHex("FFF4CC")
local v_u_10 = Color3.fromRGB(255, 120, 24)
local v_u_11 = Color3.fromRGB(232, 60, 26)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(255, 170, 60)
local v_u_14 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_20(p15, p16, p17) -- name: rays
	-- upvalues: (copy) v_u_7
	local v18 = Instance.new("BillboardGui")
	v18.Size = UDim2.fromScale(p16, p16)
	v18.LightInfluence = 0
	v18.Brightness = 1.7
	v18.AlwaysOnTop = false
	v18.ResetOnSpawn = false
	v18.Parent = p15
	local v19 = Instance.new("ImageLabel")
	v19.BackgroundTransparency = 1
	v19.Size = UDim2.fromScale(1, 1)
	v19.Image = v_u_7.SunRays
	v19.ImageColor3 = p17
	v19.Parent = v18
	return v18, v19
end
return function(p_u_21)
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_11, (copy) v_u_9, (copy) v_u_20, (copy) v_u_10, (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (copy) v_u_14, (copy) v_u_1, (copy) v_u_6, (copy) v_u_13
	local v63 = {
		["sun_breathing_a"] = {
			["cast"] = function(p22) -- name: cast
				-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7
				local v23 = p22.size
				local v24 = p22.eye + p22.dir * 1.1
				v_u_3.flash(v24, v_u_8, 2.8 * v23, 0.1)
				v_u_4.facePic(v24, 0.8 * v23, 3.2 * v23, v_u_7.SunRays, v_u_8, 0.15, nil, 0.2)
			end,
			["shot"] = function(p25, p26) -- name: haloShot
				-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9, (ref) v_u_20, (copy) p_u_21, (ref) v_u_10
				local v27 = p25.size
				local v28 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p26, v_u_8, {
					["transparency"] = 1
				})
				local v29 = v_u_3.part(Vector3.new(0.95, 0.95, 0.95) * v27, p26, v_u_11, {
					["shape"] = Enum.PartType.Ball
				})
				local v30 = v_u_3.part(Vector3.new(0.5, 0.5, 0.5) * v27, p26, v_u_9, {
					["shape"] = Enum.PartType.Ball
				})
				local v31 = {
					{
						["p"] = v29,
						["off"] = CFrame.identity
					},
					{
						["p"] = v30,
						["off"] = CFrame.new(0, 0, -0.2 * v27)
					}
				}
				local v_u_32, v_u_33 = v_u_20(v28, 3.4 * v27, v_u_8)
				p_u_21.streak(v28, v_u_8, v_u_10, 1.2 * v27, 0.16)
				if not p25.lite then
					p_u_21.light(v28, v_u_8, 9 * v27)
				end
				local v_u_34 = p_u_21.assemble(v28, v31, {}, 0, 0, {}, 0.16, 0)
				return {
					["place"] = function(p35, p36) -- name: place
						-- upvalues: (copy) v_u_34, (copy) v_u_33
						v_u_34.place(p35, p36)
						v_u_33.Rotation = p36 * 900 % 360
					end,
					["stop"] = function(p37) -- name: stop
						-- upvalues: (copy) v_u_32, (copy) v_u_34
						v_u_32.Enabled = false
						v_u_34.stop(p37)
					end
				}
			end,
			["impact"] = function(p38, p39) -- name: impact
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_3, (ref) v_u_9, (ref) v_u_12, (ref) v_u_14
				local v40 = p38.size
				v_u_4.facePic(p39, 1 * v40, 6 * v40, v_u_7.SunSeal, v_u_8, 0.32, nil, 0.2, 0)
				v_u_3.flash(p39, v_u_9, 3.6 * v40, 0.13)
				if not p38.lite then
					local v41 = 1.4 * v40
					local v42 = 6 * v40
					local v43 = {
						["layout"] = nil,
						["emission"] = 0.15,
						["dir"] = nil,
						["spread"] = 60,
						["spin"] = 30,
						["drag"] = 1.5,
						["layout"] = v_u_14
					}
					v_u_4.spray(p39, v_u_7.SunFlame, 2, v41, v42, 0.6, v_u_12, v43)
				end
			end,
			["hit"] = p_u_21.simpleHit(v_u_8, 0.55)
		},
		["sun_breathing_e"] = {
			["cast"] = function(p44) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3
				local v45 = p44.size
				local v46 = p44.eye + p44.dir * 2 * v45
				v_u_4.planePic(v_u_4.facing(v46, p44.dir), 2 * v45, 8 * v45, v_u_7.SunRays, v_u_8, 0, 0.1, 0.12, 0.25, 4, 0.2)
				v_u_4.planePic(v_u_4.facing(v46 + p44.dir * 0.2, p44.dir), 1 * v45, 4.5 * v45, v_u_7.SunSeal, v_u_9, 0, 0.08, 0.12, 0.2, -3, 0.2)
				v_u_3.flash(v46, v_u_9, 4 * v45, 0.14)
				if p44.mine then
					v_u_3.shake(0.08, 0.1)
				end
			end,
			["shot"] = function(p47, p48) -- name: thrustShot
				-- upvalues: (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (copy) p_u_21, (ref) v_u_10
				local v49 = p47.size
				local v50 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p48, v_u_8, {
					["transparency"] = 1
				})
				local v51 = v_u_4.shotBlade(CFrame.new(0, 0, 0.9 * v49), 2.8 * v49, 0.55 * v49, 0.28 * v49, v_u_8, Enum.Material.Neon)
				local v52 = v_u_3.part
				local v53 = 0.12 * v49
				local v54 = 0.12 * v49
				local v55 = 2 * v49
				local v56 = {
					["p"] = v52(Vector3.new(v53, v54, v55), p48, v_u_9),
					["off"] = CFrame.new(0, 0, -0.1 * v49)
				}
				table.insert(v51, v56)
				p_u_21.streak(v50, v_u_8, v_u_10, 0.55 * v49, 0.1)
				return p_u_21.assemble(v50, v51, {}, 0, 0, {}, 0.1, 0)
			end,
			["impact"] = function(p57, p58) -- name: impact
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_3, (ref) v_u_9, (ref) v_u_12, (ref) v_u_14
				local v59 = p57.size
				v_u_4.facePic(p58, 0.5 * v59, 4 * v59, v_u_7.SunRays, v_u_8, 0.25, nil, 0.2)
				v_u_3.flash(p58, v_u_9, 2.4 * v59, 0.12)
				if not p57.lite then
					local v60 = 1.4 * v59
					local v61 = 4 * v59
					local v62 = {
						["layout"] = nil,
						["emission"] = 0.15,
						["dir"] = nil,
						["spread"] = 60,
						["spin"] = 30,
						["drag"] = 1.5,
						["layout"] = v_u_14
					}
					v_u_4.spray(p58, v_u_7.SunFlame, 1, v60, v61, 0.6, v_u_12, v62)
				end
			end,
			["hit"] = p_u_21.simpleHit(v_u_8, 0.6)
		}
	}
	local v_u_64 = {}
	setmetatable(v_u_64, {
		["__mode"] = "k"
	})
	v63.sun_breathing_r = {
		["cast"] = function(p65) -- name: cast
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (copy) p_u_21, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_14
			local v66 = p65.size
			v_u_3.flash(p65.eye, v_u_8, 6 * v66, 0.2)
			p_u_21.glint(p65.eye, v_u_9, 6 * v66, 0.3)
			local v67 = p65.feet + Vector3.new(0, 1, 0)
			local v68 = p65.lite and 2 or 8
			local v69 = 2 * v66
			local v70 = 8 * v66
			local v71 = {
				["layout"] = nil,
				["emission"] = 0.15,
				["dir"] = nil,
				["spread"] = 60,
				["spin"] = 30,
				["drag"] = 1.5,
				["layout"] = v_u_14
			}
			v_u_4.spray(v67, v_u_7.SunFlame, v68, v69, v70, 0.8, v_u_12, v71)
			if p65.mine then
				v_u_3.shake(0.14, 0.15)
				v_u_4.tint("SunBreathing", Color3.fromRGB(255, 236, 200), 0.04, 0.12, 0.12, 0.9, 0.6)
			end
		end,
		["windup"] = function(p_u_72, p73, p74) -- name: windup
			-- upvalues: (copy) p_u_21, (ref) v_u_4, (copy) v_u_64, (ref) v_u_7, (ref) v_u_8, (ref) v_u_20, (ref) v_u_10, (ref) v_u_9, (ref) v_u_3, (ref) v_u_11, (ref) v_u_12, (ref) v_u_1, (ref) v_u_14, (ref) v_u_6
			local v_u_75 = p_u_72.size
			local v_u_76 = p_u_72.lite
			local v_u_77 = p_u_72.ability.radius * v_u_75
			local v_u_78 = p_u_21.ground(p73, 0)
			local v_u_79 = p_u_72.eye
			local v80 = v_u_4.flat(v_u_79 - v_u_78)
			local v_u_81 = v_u_78 + v80 * v_u_77 * 0.75 + Vector3.new(0, 6, 0) * v_u_75
			local v_u_82 = v_u_79:Lerp(v_u_81, 0.5) + Vector3.new(0, 1, 0) * v_u_77 * 0.5
			local v_u_83 = math.max(p74, 0.1) + 0.8
			v_u_64[p_u_72] = {
				["dive"] = v_u_83 - math.max(p74, 0.1),
				["at"] = v_u_78
			}
			local v84 = v80.Z
			local v85 = v80.X
			local v_u_86 = math.atan2(v84, v85)
			local v87 = v_u_76 and 8 or 16
			local v88 = v_u_83 + 0.8
			local v_u_89 = {}
			local v_u_90 = {}
			local v_u_91 = {}
			local function v_u_106(p92) -- name: path
				-- upvalues: (copy) v_u_79, (copy) v_u_82, (copy) v_u_81, (copy) v_u_86, (copy) v_u_77, (copy) v_u_78, (copy) v_u_75
				if p92 <= 0.35 then
					local v93 = p92 / 0.35
					return v_u_79:Lerp(v_u_82, v93):Lerp(v_u_82:Lerp(v_u_81, v93), v93)
				elseif p92 <= 0.88 then
					local v94 = (p92 - 0.35) / 0.53
					local v95 = v_u_86 + v94 * 3.141592653589793 * 2
					local v96 = v_u_77 * (0.75 - v94 * 0.2)
					local v97 = v_u_78
					local v98 = math.cos(v95)
					local v99 = math.sin(v95)
					return v97 + Vector3.new(v98, 0, v99) * v96 + Vector3.new(0, 1, 0) * (6 - v94 * 2.5) * v_u_75
				else
					local v100 = (p92 - 0.88) / 0.12
					local v101 = v_u_78
					local v102 = v_u_86
					local v103 = math.cos(v102)
					local v104 = v_u_86
					local v105 = math.sin(v104)
					return (v101 + Vector3.new(v103, 0, v105) * v_u_77 * 0.55 + Vector3.new(0, 3.5, 0) * v_u_75):Lerp(v_u_78 + Vector3.new(0, 1, 0), v100 * v100)
				end
			end
			for v107 = 1, v87 do
				local v108 = v_u_4.holder(CFrame.new(v_u_79), v88)
				table.insert(v_u_89, v108)
				if v107 > 1 then
					local v109 = 4.4 * v_u_75 * (1 - (v107 - 2) / v87) + 0.4
					local v110 = 4.4 * v_u_75 * (1 - (v107 - 1) / v87) + 0.4
					local v111 = v_u_4.beam(v_u_89[v107 - 1], v108, v_u_7.FireBeam, v_u_8, v109, v110, 0.4)
					v111.TextureMode = Enum.TextureMode.Wrap
					v111.TextureLength = 5
					v111.TextureSpeed = 3
					v111.Segments = 4
					table.insert(v_u_90, v111)
				end
				if v107 % 3 ~= 2 then
					continue
				end
				local v112 = v_u_20
				local v113 = 6.5 * v_u_75 * (1 - v107 / v87 * 0.55)
				local v114
				if v107 % 2 == 0 then
					v114 = v_u_8
				else
					v114 = v_u_10
				end
				local _, v115 = v112(v108, v113, v114)
				table.insert(v_u_91, v115)
			end
			local v_u_116 = v_u_4.blade(v_u_8, Enum.Material.Neon)
			local v_u_117 = v_u_4.blade(v_u_10, Enum.Material.Neon)
			local v_u_118 = { v_u_4.blade(v_u_9, Enum.Material.Neon), v_u_4.blade(v_u_9, Enum.Material.Neon) }
			local v_u_119 = v_u_3.part(Vector3.new(2, 2, 2) * v_u_75, CFrame.new(v_u_79), v_u_11, {
				["shape"] = Enum.PartType.Ball
			})
			local v_u_120 = { v_u_3.part(Vector3.new(0.45, 0.45, 0.45) * v_u_75, CFrame.new(v_u_79), v_u_12, {
					["shape"] = Enum.PartType.Ball
				}), v_u_3.part(Vector3.new(0.45, 0.45, 0.45) * v_u_75, CFrame.new(v_u_79), v_u_12, {
					["shape"] = Enum.PartType.Ball
				}) }
			local v_u_121 = { v_u_119, v_u_120[1], v_u_120[2] }
			for _, v122 in {
				v_u_116,
				v_u_117,
				v_u_118[1],
				v_u_118[2]
			} do
				for _, v123 in v122 do
					table.insert(v_u_121, v123)
				end
			end
			for _, v124 in v_u_121 do
				v_u_1:AddItem(v124, v88)
			end
			local v_u_125, v_u_126 = v_u_20(v_u_89[1], 9.5 * v_u_75, v_u_8)
			if not v_u_76 then
				p_u_21.light(v_u_119, v_u_8, 16 * v_u_75)
			end
			local v_u_127 = os.clock() - p_u_72.skip
			local v_u_128 = 0
			p_u_21.runNow(function()
				-- upvalues: (copy) v_u_127, (copy) v_u_83, (copy) v_u_89, (copy) v_u_106, (copy) v_u_91, (copy) v_u_126, (copy) p_u_72, (ref) v_u_4, (copy) v_u_116, (copy) v_u_75, (copy) v_u_117, (copy) v_u_118, (copy) v_u_120, (copy) v_u_119, (copy) v_u_76, (ref) v_u_128, (ref) v_u_7, (ref) v_u_12, (ref) v_u_14, (copy) v_u_90, (copy) v_u_125, (copy) v_u_121
				local v129 = os.clock() - v_u_127
				local v130 = v129 / v_u_83
				local v131 = math.clamp(v130, 0, 1)
				for v132, v133 in v_u_89 do
					local v134 = v_u_106
					local v135 = v131 - (v132 - 1) * 0.022
					v133.WorldPosition = v134((math.max(v135, 0)))
				end
				for v136, v137 in v_u_91 do
					v137.Rotation = v129 * (v136 * 40 + 300) % 360
				end
				v_u_126.Rotation = -v129 * 200 % 360
				local v138 = v_u_106(v131)
				local v139 = v_u_106
				local v140 = v131 + 0.01
				local v141 = v139((math.min(v140, 1))) - v138
				local v142
				if v141.Magnitude > 0.001 then
					v142 = v141.Unit
				else
					v142 = p_u_72.dir
				end
				local v143 = CFrame.lookAt(v138, v138 + v142)
				local v144 = v143 * CFrame.Angles(0, 0, 1.5707963267948966)
				v_u_4.placeBlade(v_u_116, v144, 4.2 * v_u_75, 2.5 * v_u_75, 1.2 * v_u_75)
				local v145 = v129 * 14
				local v146 = math.sin(v145) * 0.15 + 0.25
				v_u_4.placeBlade(v_u_117, v144 * CFrame.new(-0.5 * v_u_75, 0, 0) * CFrame.Angles(0, v146, 0), 2.4 * v_u_75, 1.2 * v_u_75, 0.5 * v_u_75)
				for v147, v148 in { -1, 1 } do
					local v149 = v143 * CFrame.new(v148 * 0.5 * v_u_75, 0.6 * v_u_75, 0.3 * v_u_75)
					v_u_4.placeBlade(v_u_118[v147], v149 * CFrame.Angles(0.5, 3.141592653589793 + v148 * 0.4, 0), 2.4 * v_u_75, 0.5 * v_u_75, 0.3 * v_u_75)
					v_u_120[v147].CFrame = v143 * CFrame.new(v148 * 0.55 * v_u_75, 0.35 * v_u_75, -0.6 * v_u_75)
				end
				v_u_119.CFrame = v143 * CFrame.new(0, 0.55 * v_u_75, 0.1 * v_u_75)
				v_u_89[1].WorldPosition = v138
				if not v_u_76 and (v129 - v_u_128 > 0.08 and v131 < 1) then
					v_u_128 = v129
					local v150 = v_u_106
					local v151 = v131 - 0.1
					local v152 = v150((math.max(v151, 0)))
					local v153 = 2.4 * v_u_75
					local v154 = 3 * v_u_75
					local v155 = {
						["layout"] = nil,
						["emission"] = 0.15,
						["dir"] = nil,
						["spread"] = 60,
						["spin"] = 30,
						["drag"] = 1.5,
						["layout"] = v_u_14
					}
					v_u_4.spray(v152, v_u_7.SunFlame, 1, v153, v154, 0.6, v_u_12, v155)
				end
				if v131 < 1 then
					return true
				end
				for _, v156 in v_u_90 do
					v156.Enabled = false
				end
				v_u_125.Enabled = false
				for _, v157 in v_u_91 do
					v157.ImageTransparency = 1
				end
				for _, v158 in v_u_121 do
					v158:Destroy()
				end
				return false
			end)
			v_u_6.play("Fireball", {
				["at"] = v_u_79,
				["volume"] = p_u_72.mine and 0.8 or 0.4
			})
		end,
		["land"] = function(p_u_159, p160) -- name: land
			-- upvalues: (copy) p_u_21, (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_3, (ref) v_u_12, (ref) v_u_14, (ref) v_u_6, (copy) v_u_64, (ref) v_u_9, (ref) v_u_13
			local v_u_161 = p_u_159.size
			local v_u_162 = p_u_159.lite
			local v_u_163 = p_u_159.ability.radius * v_u_161
			local v_u_164 = p_u_21.ground(p160, 0.1)
			v_u_4.groundPic(v_u_164, v_u_163 * 0.3, v_u_163 * 2.2, v_u_7.SunSeal, v_u_8, 0, 0.3, 0.7, 0.5, 1.2, 0.15)
			v_u_4.groundPic(v_u_164 + Vector3.new(0, 0.05, 0), v_u_163 * 0.5, v_u_163 * 2.8, v_u_7.SunRays, v_u_10, 0.1, 0.2, 0.2, 0.4, -1.5, 0.15)
			v_u_4.groundPic(v_u_164 - Vector3.new(0, 0.05, 0), v_u_163 * 0.8, v_u_163 * 2.6, v_u_7.Glow, v_u_10, 0.4, 0.3, 0.8, 0.6, 0)
			v_u_3.ring(v_u_164, v_u_8, v_u_163 * 1.2, 0.5, v_u_7.Shockwave)
			for v165 = 1, v_u_162 and 4 or 12 do
				local v166 = v165 * 3.141592653589793 * 2 / (v_u_162 and 4 or 12)
				local v167 = math.cos(v166)
				local v168 = math.sin(v166)
				local v169 = v_u_164 + Vector3.new(v167, 0.4, v168) * v_u_163 * 0.5
				local v170 = 3 * v_u_161
				local v171 = 6 * v_u_161
				local v172 = {
					["layout"] = nil,
					["emission"] = 0.15,
					["dir"] = Vector3.new(0, 1, 0),
					["spread"] = 10,
					["spin"] = 30,
					["drag"] = 1.5,
					["layout"] = v_u_14
				}
				v_u_4.spray(v169, v_u_7.SunFlame, 1, v170, v171, 0.9, v_u_12, v172)
			end
			v_u_6.play("Explosion", {
				["at"] = v_u_164,
				["volume"] = p_u_159.mine and 0.8 or 0.4
			})
			if p_u_159.mine then
				v_u_3.shake(0.3, 0.3)
			end
			local v173 = v_u_64[p_u_159]
			v_u_64[p_u_159] = nil
			local v174 = not v173 and 0.75 or v173.dive
			p_u_21.after(v174, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_164, (copy) v_u_161, (ref) v_u_8, (ref) v_u_9, (copy) v_u_163, (ref) v_u_7, (ref) v_u_3, (ref) p_u_21, (ref) v_u_10, (copy) v_u_162, (ref) v_u_12, (ref) v_u_14, (ref) v_u_13, (ref) v_u_6, (copy) p_u_159
				local v175 = v_u_4.bar(v_u_164, v_u_164 + Vector3.new(0, 45, 0) * v_u_161, 7 * v_u_161, v_u_8, 0.15)
				v_u_4.thinBar(v175, 0.6, true)
				local v176 = v_u_4.bar(v_u_164, v_u_164 + Vector3.new(0, 45, 0) * v_u_161, 2.6 * v_u_161, v_u_9)
				v_u_4.thinBar(v176, 0.5, true)
				v_u_4.facePic(v_u_164 + Vector3.new(0, 1, 0) * v_u_163 * 0.4, v_u_163 * 0.5, v_u_163 * 2.8, v_u_7.SunRays, v_u_8, 0.6, nil, 0.25)
				v_u_4.facePic(v_u_164 + Vector3.new(0, 1, 0) * v_u_163 * 0.4, v_u_163 * 0.3, v_u_163 * 1.7, v_u_7.SunSeal, v_u_9, 0.5, nil, 0.3, 0)
				v_u_3.flash(v_u_164 + Vector3.new(0, 4, 0) * v_u_161, v_u_9, v_u_163 * 0.9, 0.25)
				p_u_21.dome(v_u_164, v_u_163 * 0.9, v_u_8, 0.5)
				v_u_3.ring(v_u_164, v_u_10, v_u_163 * 1.4, 0.6, v_u_7.Shockwave)
				for v177 = 1, v_u_162 and 6 or 20 do
					local v178 = v177 * 3.141592653589793 * 2 / (v_u_162 and 6 or 20)
					local v179 = math.cos(v178)
					local v180 = math.sin(v178)
					local v181 = Vector3.new(v179, 0, v180)
					local v182 = v_u_164 + v181 * 2 * v_u_161 + Vector3.new(0, 1, 0)
					local v183 = 3.4 * v_u_161
					local v184 = v_u_163 * 1.3
					local v185 = {
						["layout"] = nil,
						["emission"] = 0.15,
						["dir"] = nil,
						["spread"] = 8,
						["spin"] = 30,
						["drag"] = 1.5,
						["layout"] = v_u_14,
						["dir"] = (v181 + Vector3.new(0, 0.25, 0)).Unit
					}
					v_u_4.spray(v182, v_u_7.SunFlame, 1, v183, v184, 0.8, v_u_12, v185)
				end
				if not v_u_162 then
					local v186 = { v_u_8, v_u_13, v_u_10 }
					p_u_21.chunks(v_u_164 + Vector3.new(0, 1, 0), v186, 14, 40 * v_u_161, 0.7 * v_u_161, 1.4, true, 1.1)
				end
				v_u_6.play("Explosion", {
					["at"] = v_u_164,
					["volume"] = p_u_159.mine and 1 or 0.5
				})
				if p_u_159.mine then
					v_u_3.shake(0.55, 0.45)
					v_u_4.tint("SunBreathing", Color3.fromRGB(255, 225, 170), 0.2, 0.2, 0.03, 0.1, 0.45)
				end
			end)
		end,
		["hit"] = function(p187, p188, _) -- name: hit
			-- upvalues: (copy) p_u_21, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_14
			p_u_21.burst("Impact", p188, v_u_8, 0.8)
			if not p187.lite then
				local v189 = 1.6 * p187.size
				local v190 = {
					["layout"] = nil,
					["emission"] = 0.15,
					["dir"] = nil,
					["spread"] = 60,
					["spin"] = 30,
					["drag"] = 1.5,
					["layout"] = v_u_14
				}
				v_u_4.spray(p188, v_u_7.SunFlame, 1, v189, 3, 0.5, v_u_12, v190)
			end
		end
	}
	return v63
end