local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromRGB(255, 249, 232)
local v_u_10 = Color3.fromRGB(214, 220, 236)
local v_u_11 = Color3.fromRGB(120, 122, 138)
local v_u_12 = Color3.fromRGB(6, 6, 10)
local v_u_13 = Color3.fromRGB(16, 16, 20)
local v_u_14 = Color3.fromRGB(78, 78, 92)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_28(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_5
	local v22 = v_u_5.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: fadePicture
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
return function(p_u_33)
	-- upvalues: (copy) v_u_4, (copy) v_u_28, (copy) v_u_1, (copy) v_u_32, (copy) v_u_2, (copy) v_u_5, (copy) v_u_8, (copy) v_u_12, (copy) v_u_15, (copy) v_u_16, (copy) v_u_7, (copy) v_u_9, (copy) v_u_11, (copy) v_u_10, (copy) v_u_14, (copy) v_u_13, (copy) v_u_6
	local function v_u_50(p_u_34, p_u_35, p_u_36, p37, p38, p_u_39, p_u_40, p41) -- name: spinOut
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_33, (ref) v_u_32
		local v_u_42 = p41 or 0
		local v_u_43 = v_u_28(p_u_34, p_u_35, p37, p38, v_u_42)
		v_u_1:AddItem(v_u_43, p_u_39 + 0.1)
		p_u_33.animate(p_u_39, 0, function(p44)
			-- upvalues: (copy) v_u_43, (copy) p_u_35, (copy) p_u_36, (copy) p_u_34, (copy) p_u_39, (copy) p_u_40, (ref) v_u_32, (copy) v_u_42
			local v45 = 1 - (1 - p44) ^ 3
			local v46 = v_u_43
			local v47 = p_u_35 + (p_u_36 - p_u_35) * v45
			local v48 = v47 * 2
			local v49 = v47 * 2
			v46.Size = Vector3.new(v48, 0.05, v49)
			v_u_43.CFrame = p_u_34 * CFrame.Angles(0, p44 * p_u_39 * p_u_40, 0)
			v_u_32(v_u_43, v_u_42 + (1 - v_u_42) * p44 ^ 1.5)
			if p44 >= 1 then
				v_u_43:Destroy()
			end
		end)
	end
	local v_u_51 = {}
	local function v_u_63(p52, p53, p54, p55, p56, p57, p58, p_u_59) -- name: screen
		-- upvalues: (copy) v_u_51, (ref) v_u_2, (ref) v_u_5, (copy) p_u_33, (ref) v_u_8, (ref) v_u_1
		local v60 = os.clock()
		if v60 >= (v_u_51[p52] or 0) then
			v_u_51[p52] = v60 + p57 + p58 + p_u_59
			local v_u_61 = Instance.new("ColorCorrectionEffect")
			v_u_61.Name = p52
			v_u_61.Parent = v_u_2
			v_u_5.tween(v_u_61, p57, {
				["TintColor"] = p53,
				["Brightness"] = p54,
				["Contrast"] = p55,
				["Saturation"] = p56
			})
			p_u_33.after(p57 + p58, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_61, (copy) p_u_59, (ref) v_u_8
				local v62 = {
					["TintColor"] = nil,
					["Brightness"] = 0,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_8
				}
				v_u_5.tween(v_u_61, p_u_59, v62)
			end)
			v_u_1:AddItem(v_u_61, p57 + p58 + p_u_59 + 0.05)
		end
	end
	local function v85(p64, p65) -- name: sparkShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_28, (ref) v_u_7, (ref) v_u_9, (copy) p_u_33, (ref) v_u_11, (ref) v_u_1, (ref) v_u_4
		local v_u_66 = p64.size
		local v_u_67 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p65, v_u_8, {
			["transparency"] = 1
		})
		local v68 = {
			["shape"] = v_u_15,
			["material"] = v_u_16
		}
		local v_u_69 = v_u_5.part(Vector3.new(0.95, 0.95, 0.95) * v_u_66, p65, v_u_12, v68)
		v_u_69.Reflectance = 0
		local v70 = {
			["shape"] = nil,
			["transparency"] = 0.05,
			["shape"] = v_u_15
		}
		local v_u_71 = v_u_5.part(Vector3.new(1.32, 1.32, 1.32) * v_u_66, p65, v_u_8, v70)
		local v_u_72
		if p64.lite then
			v_u_72 = nil
		else
			v_u_72 = v_u_28(p65, 1.55 * v_u_66, v_u_7.EclipseCorona, v_u_9, 0.05)
			p_u_33.streak(v_u_67, v_u_9, v_u_8, 0.4 * v_u_66, 0.08)
		end
		p_u_33.streak(v_u_67, v_u_8, v_u_11, 1.4 * v_u_66, 0.13)
		if p64.mine then
			p_u_33.light(v_u_67, v_u_8, 9 * v_u_66)
		end
		local v_u_73 = { v_u_69, v_u_71 }
		if v_u_72 then
			table.insert(v_u_73, v_u_72)
		end
		for _, v74 in v_u_73 do
			v_u_1:AddItem(v74, 3)
		end
		v_u_1:AddItem(v_u_67, 3)
		local v_u_75 = false
		return {
			["place"] = function(p76, p77) -- name: place
				-- upvalues: (copy) v_u_67, (ref) v_u_4, (copy) v_u_69, (copy) v_u_66, (copy) v_u_71, (ref) v_u_72, (ref) p_u_33
				local v78 = p76.Position
				v_u_67.CFrame = p76
				local v79 = v_u_4.CurrentCamera
				local v80
				if v79 then
					local v81 = v79.CFrame.Position - v78
					v80 = v81.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v81.Unit
				else
					v80 = Vector3.new(0, 0, 1)
				end
				v_u_69.CFrame = CFrame.new(v78 + v80 * 0.3 * v_u_66)
				v_u_71.CFrame = CFrame.new(v78 - v80 * 0.1 * v_u_66)
				local v82 = v_u_72
				if v82 then
					v82.CFrame = p_u_33.facing(v78 - v80 * 0.55 * v_u_66, v80) * CFrame.Angles(0, -p77 * 14, 0)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_75, (copy) v_u_67, (ref) v_u_1, (copy) v_u_73
				if not v_u_75 then
					v_u_75 = true
					local v83 = v_u_67:FindFirstChildWhichIsA("PointLight")
					if v83 then
						v83:Destroy()
					end
					v_u_1:AddItem(v_u_67, 0.15)
					for _, v84 in v_u_73 do
						v84:Destroy()
					end
				end
			end
		}
	end
	local function v104(p86, p87) -- name: sparkImpact
		-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_8, (copy) v_u_50, (copy) p_u_33, (ref) v_u_7, (ref) v_u_12, (ref) v_u_16, (ref) v_u_9, (ref) v_u_10
		local v88 = p86.size
		local v89 = v_u_4.CurrentCamera
		local v90
		if v89 then
			local v91 = v89.CFrame.Position - p87
			v90 = v91.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v91.Unit
		else
			v90 = Vector3.new(0, 0, 1)
		end
		v_u_5.flash(p87, v_u_8, 4.5 * v88, 0.12)
		local v92 = v_u_50
		local v93 = p87 - v90 * 0.4
		local v94 = p_u_33.facing
		local v95 = v_u_4.CurrentCamera
		local v96
		if v95 then
			local v97 = v95.CFrame.Position - v93
			v96 = v97.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v97.Unit
		else
			v96 = Vector3.new(0, 0, 1)
		end
		v92(v94(v93, v96), 1 * v88, 4.6 * v88, v_u_7.EclipseRays, v_u_8, 0.18, 5, 0.05)
		p_u_33.pop(p87 + v90 * 0.5, v_u_12, 1.5 * v88, 0.2 * v88, 0.16, 0, v_u_16)
		p_u_33.burst("Impact", p87, v_u_8, 0.8 * v88)
		if not p86.lite then
			local v98 = v_u_50
			local v99 = p87 - v90 * 0.6
			local v100 = p_u_33.facing
			local v101 = v_u_4.CurrentCamera
			local v102
			if v101 then
				local v103 = v101.CFrame.Position - v99
				v102 = v103.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v103.Unit
			else
				v102 = Vector3.new(0, 0, 1)
			end
			v98(v100(v99, v102), 1.2 * v88, 3.4 * v88, v_u_7.EclipseCorona, v_u_9, 0.2, -22)
			p_u_33.spikes(p87, v_u_10, 4, 3.2 * v88, 0.13, nil, nil, true)
		end
		p_u_33.hitSound(p87)
	end
	local v_u_105 = {}
	setmetatable(v_u_105, {
		["__mode"] = "k"
	})
	local function v_u_110(p106, p107, p108) -- name: chainBeam
		-- upvalues: (ref) v_u_7, (ref) v_u_14
		local v109 = Instance.new("Beam")
		v109.Attachment0 = p106
		v109.Attachment1 = p107
		v109.Texture = v_u_7.EclipseChain
		v109.TextureMode = Enum.TextureMode.Wrap
		v109.TextureLength = p108 * 2.9767441860465116
		v109.TextureSpeed = 0
		v109.Color = ColorSequence.new(v_u_14)
		v109.LightEmission = 0
		v109.LightInfluence = 0
		v109.Width0 = p108
		v109.Width1 = p108
		v109.FaceCamera = true
		v109.Segments = 12
		v109.ZOffset = 0.05
		v109.Parent = p106.Parent
		return v109
	end
	local function v_u_115(p111, p112, p113) -- name: hotBeam
		-- upvalues: (ref) v_u_7, (ref) v_u_8
		local v114 = Instance.new("Beam")
		v114.Attachment0 = p111
		v114.Attachment1 = p112
		v114.Texture = v_u_7.Beam
		v114.TextureMode = Enum.TextureMode.Stretch
		v114.TextureLength = 1
		v114.Color = ColorSequence.new(v_u_8)
		v114.LightEmission = 1
		v114.LightInfluence = 0
		v114.Brightness = 2
		v114.Transparency = NumberSequence.new(0.1)
		v114.Width0 = p113
		v114.Width1 = p113
		v114.FaceCamera = true
		v114.Segments = 12
		v114.Parent = p111.Parent
		return v114
	end
	local function v_u_119(p116) -- name: endUmbra
		-- upvalues: (copy) p_u_33, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10
		if not p116.done then
			p116.done = true
			local v117 = p116.top
			p_u_33.pop(v117, v_u_8, 3.36, 0.5599999999999999, 0.16)
			v_u_5.flash(v117, v_u_10, 7, 0.14)
			p116.holder:Destroy()
			p116.orb:Destroy()
			p116.rim:Destroy()
			local v118 = p116.corona
			if v118 then
				v118:Destroy()
			end
		end
	end
	local function v_u_152(p120) -- name: umbraStep
		-- upvalues: (ref) v_u_4, (copy) p_u_33, (ref) v_u_14, (ref) v_u_8, (copy) v_u_119
		if p120.done then
			return false
		end
		local v121 = os.clock()
		local v122 = v121 - p120.born
		local v123 = v122 / 0.12
		local v124 = (math.clamp(v123, 0, 1) * 0.8 + 0.2) * 2.8
		local v125 = v122 * 9
		local v126 = v124 * (math.sin(v125) * 0.04 + 1)
		local v127 = p120.top
		local v128 = v_u_4.CurrentCamera
		local v129
		if v128 then
			local v130 = v128.CFrame.Position - v127
			v129 = v130.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v130.Unit
		else
			v129 = Vector3.new(0, 0, 1)
		end
		p120.orb.Size = Vector3.new(1, 1, 1) * v126
		p120.orb.CFrame = CFrame.new(p120.top + v129 * 0.4)
		p120.rim.Size = Vector3.new(1, 1, 1) * v126 * 1.18
		p120.rim.CFrame = CFrame.new(p120.top)
		local v131 = p120.corona
		if v131 then
			local v132 = v126 * 1.25
			local v133 = v132 * 2
			local v134 = v132 * 2
			v131.Size = Vector3.new(v133, 0.05, v134)
			v131.CFrame = p_u_33.facing(p120.top - v129 * 0.6, v129) * CFrame.Angles(0, -v122 * 2.2, 0)
		end
		local v135 = v122 / p120.span
		local v136 = 1 - (1 - math.clamp(v135, 0, 1)) ^ 2
		local v137 = 0
		local v138 = p120.landAt
		local v139
		if v138 then
			v139 = v138 + p120.hold
		else
			v139 = p120.born + p120.span + 1.1
		end
		if v138 then
			local v140 = (v121 - v138) / 0.45
			v137 = 1 - math.clamp(v140, 0, 1)
		end
		local v141 = (v121 - v139) / 0.22
		local v142 = math.clamp(v141, 0, 1)
		local v143 = v136 * (1 - v142 * v142)
		for v144, v145 in p120.chains do
			local v146 = p120.top:Lerp(v145.goal, v143)
			v145.a1.WorldPosition = v146
			local v147 = (1 - v143) * 3.5
			local v148
			if v138 then
				local v149 = v122 * 40 + v144
				v148 = math.sin(v149) * 0.12
			else
				v148 = 0
			end
			local v150 = v147 + v148
			v145.links.CurveSize0 = v150
			local v151 = v145.hot
			if v151 then
				v151.CurveSize0 = v150
			end
			if v137 <= 0 and v142 <= 0 then
				continue
			end
			v145.links.Color = ColorSequence.new(v_u_14:Lerp(v_u_8, v137))
			v145.links.LightEmission = v137 * 0.8
		end
		if v142 < 1 then
			return true
		end
		v_u_119(p120)
		return false
	end
	local function v_u_180(p153, p154, p155) -- name: startUmbra
		-- upvalues: (copy) p_u_33, (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (ref) v_u_12, (ref) v_u_16, (ref) v_u_28, (ref) v_u_7, (ref) v_u_9, (copy) v_u_110, (copy) v_u_115, (copy) v_u_105, (copy) v_u_152
		local v156 = p153.size
		local v157 = p153.ability.radius * v156
		local v158 = p_u_33.ground(p154, 7 * v156)
		local v159 = p155 + (p153.ability.freeze or 2.5) + 3
		local v160 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v158), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v160, v159)
		local v161 = p_u_33.ball(v158, v_u_12, 0.5, 0, v_u_16)
		v161.Reflectance = 0
		v_u_1:AddItem(v161, v159)
		local v162 = p_u_33.ball(v158, v_u_8, 0.5, 0.05)
		v_u_1:AddItem(v162, v159)
		local v_u_163 = {
			["holder"] = nil,
			["orb"] = nil,
			["rim"] = nil,
			["corona"] = nil,
			["chains"] = nil,
			["top"] = nil,
			["born"] = nil,
			["span"] = nil,
			["landAt"] = nil,
			["hold"] = nil,
			["done"] = false,
			["holder"] = v160,
			["orb"] = v161,
			["rim"] = v162,
			["chains"] = {},
			["top"] = v158,
			["born"] = os.clock(),
			["span"] = p155
		}
		local v164 = p153.ability.freeze or 2.5
		v_u_163.hold = math.min(v164, 2.5)
		if not p153.lite then
			local v165 = v_u_28(CFrame.new(v158), 1, v_u_7.EclipseCorona, v_u_9, 0)
			v_u_1:AddItem(v165, v159)
			v_u_163.corona = v165
		end
		local v166 = p153.lite and 4 or 8
		local v167 = math.random() * 3.141592653589793 * 2
		for v168 = 1, v166 do
			local v169 = v167 + (v168 - 1) / v166 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.3
			local v170 = math.cos(v169)
			local v171 = math.sin(v169)
			local v172 = Vector3.new(v170, 0, v171)
			local v173 = p_u_33.ground(p154, 0.3) + v172 * v157 * (0.75 + math.random() * 0.15)
			local v174 = Instance.new("Attachment")
			v174.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), (v172 + Vector3.new(0, 0.8, 0)).Unit) * CFrame.Angles(0, 1.5707963267948966, 0)
			v174.Parent = v160
			local v175 = Instance.new("Attachment")
			v175.Parent = v160
			v175.WorldPosition = v158
			local v176 = 1.25 * v156
			local v177 = {
				["a0"] = v174,
				["a1"] = v175,
				["links"] = v_u_110(v174, v175, v176)
			}
			local v178
			if p153.lite then
				v178 = nil
			else
				v178 = v_u_115(v174, v175, v176 * 0.32)
			end
			v177.hot = v178
			v177.goal = v173
			local v179 = v_u_163.chains
			table.insert(v179, v177)
		end
		v_u_105[p153] = v_u_163
		p_u_33.runNow(function()
			-- upvalues: (ref) v_u_152, (copy) v_u_163
			return v_u_152(v_u_163)
		end)
		return v_u_163
	end
	local function v_u_208(p181, p_u_182) -- name: chainLoop
		-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_1, (copy) v_u_110, (copy) p_u_33, (ref) v_u_8
		local v_u_183 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p181), v_u_14, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_183, p_u_182 + 0.6)
		local v_u_184 = CFrame.Angles((math.random() - 0.5) * 0.5, math.random() * 6, (math.random() - 0.5) * 0.5)
		local v_u_185 = {}
		local v_u_186 = {}
		for _ = 1, 4 do
			local v187 = Instance.new("Attachment")
			v187.Parent = v_u_183
			table.insert(v_u_185, v187)
		end
		for v188 = 1, 4 do
			local v189 = v_u_110(v_u_185[v188], v_u_185[v188 % 4 + 1], 0.7)
			v189.Segments = 8
			table.insert(v_u_186, v189)
		end
		local v_u_190 = os.clock()
		p_u_33.runNow(function()
			-- upvalues: (copy) v_u_183, (copy) v_u_190, (copy) v_u_185, (copy) v_u_184, (copy) p_u_182, (copy) v_u_186, (ref) v_u_14, (ref) v_u_8
			if not v_u_183.Parent then
				return false
			end
			local v191 = os.clock() - v_u_190
			local v192 = v191 / 0.12
			local v193 = (1.8 - (1 - (1 - math.clamp(v192, 0, 1)) ^ 2) * 0.8) * 1.8
			for v194, v195 in v_u_185 do
				local v196 = (v194 - 1) * 1.5707963267948966 + v191 * 0.6
				local v197 = math.cos(v196) * v193
				local v198 = math.sin(v196) * v193
				local v199 = Vector3.new(v197, 0, v198)
				local v200 = -math.sin(v196)
				local v201 = math.cos(v196)
				local v202 = Vector3.new(v200, 0, v201)
				v195.CFrame = v_u_184 * CFrame.fromMatrix(v199, v202, Vector3.new(0, 1, 0))
			end
			local v203 = (v191 - p_u_182) / 0.3
			local v204 = math.clamp(v203, 0, 1)
			local v205 = v191 / 0.35
			local v206 = 1 - math.clamp(v205, 0, 1)
			for _, v207 in v_u_186 do
				v207.CurveSize0 = v193 * 0.5522847498307933
				v207.CurveSize1 = v193 * 0.5522847498307933
				if v206 <= 0 and v204 <= 0 then
					continue
				end
				v207.Color = ColorSequence.new(v_u_14:Lerp(v_u_8, v206))
				v207.LightEmission = v206 * 0.8
				v207.Transparency = NumberSequence.new(v204)
			end
			if v204 < 1 then
				return true
			end
			v_u_183:Destroy()
			return false
		end)
	end
	local v_u_209 = {}
	setmetatable(v_u_209, {
		["__mode"] = "k"
	})
	local function v_u_211(p210) -- name: endEclipse
		if not p210.done then
			p210.done = true
			p210.sun:Destroy()
			p210.moon:Destroy()
			p210.corona:Destroy()
			p210.rays:Destroy()
			p210.shade:Destroy()
		end
	end
	local function v_u_249(p212, p213) -- name: eclipseStep
		-- upvalues: (ref) v_u_4, (copy) p_u_33, (ref) v_u_32, (copy) v_u_211
		if p213.done then
			return false
		end
		local v214 = p212.size
		local v215 = p212.ability.radius * v214
		local v216 = os.clock()
		local v217 = v216 - p213.born
		local v218 = p213.at
		local v219 = v_u_4.CurrentCamera
		local v220
		if v219 then
			local v221 = v219.CFrame.Position - v218
			v220 = v221.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v221.Unit
		else
			v220 = Vector3.new(0, 0, 1)
		end
		local v222 = v220:Cross(Vector3.new(0, 1, 0))
		local v223 = v222.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v222.Unit
		local v224 = v217 / p213.span
		local v225 = 1 - (1 - math.clamp(v224, 0, 1)) ^ 2
		local v226 = v217 / 0.1
		local v227 = math.clamp(v226, 0, 1)
		local v228 = p213.landAt
		local v229
		if v228 then
			local v230 = (v216 - v228 - 0.25) / 0.5
			v229 = math.clamp(v230, 0, 1)
		else
			v229 = 0
		end
		if not v228 and p213.span + 1.3 < v217 then
			local v231 = (v217 - p213.span - 1.3) / 0.4
			v229 = math.clamp(v231, 0, 1)
		end
		local v232 = 11 * v214
		p213.sun.Size = Vector3.new(1, 1, 1) * v232 * (v227 * 0.7 + 0.3)
		p213.sun.CFrame = CFrame.new(p213.at)
		p213.sun.Transparency = v229
		p213.moon.Size = Vector3.new(1, 1, 1) * v232 * 1.04
		p213.moon.CFrame = CFrame.new(p213.at + v220 * 2 * v214 + v223 * v232 * 1.3 * (1 - v225))
		p213.moon.Transparency = v229
		local v233 = v217 * 0.8
		local v234 = p213.corona
		local v235 = v232 * 0.95 * (v227 * 0.6 + 0.4) * (v225 * 0.15 + 1)
		local v236 = v235 * 2
		local v237 = v235 * 2
		v234.Size = Vector3.new(v236, 0.05, v237)
		p213.corona.CFrame = p_u_33.facing(p213.at - v220 * 1.5 * v214, v220) * CFrame.Angles(0, -v233 * 1.6, 0)
		v_u_32(p213.corona, v229 * 0.95 + 0.05)
		local v238 = p213.rays
		local v239 = v232 * 1.5 * (v227 * 0.6 + 0.4)
		local v240 = v239 * 2
		local v241 = v239 * 2
		v238.Size = Vector3.new(v240, 0.05, v241)
		p213.rays.CFrame = p_u_33.facing(p213.at - v220 * 2.5 * v214, v220) * CFrame.Angles(0, v233, 0)
		local v242 = v_u_32
		local v243 = p213.rays
		local v244 = v225 * 0.4
		v242(v243, math.max(v229, v244) * 0.7 + 0.3)
		local v245 = p213.shade
		local v246 = v215 * (v225 * 0.7 + 0.5)
		local v247 = v246 * 2
		local v248 = v246 * 2
		v245.Size = Vector3.new(v247, 0.05, v248)
		v_u_32(p213.shade, 1 - v225 * 0.8 * (1 - v229))
		if v229 < 1 then
			return true
		end
		v_u_211(p213)
		return false
	end
	local function v_u_264(p_u_250, p251, p252) -- name: startEclipse
		-- upvalues: (copy) p_u_33, (ref) v_u_9, (ref) v_u_12, (ref) v_u_16, (ref) v_u_28, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (copy) v_u_209, (copy) v_u_249
		local v253 = p_u_250.size
		local v254 = p_u_33.flatUnit(p251 - p_u_250.feet)
		local v255 = p_u_33.ground(p251, 20 * p_u_250.size) + v254 * 8 * p_u_250.size
		local v256 = p252 + 4
		local v257 = p_u_33.ball(v255, v_u_9, 1, 0)
		local v258 = p_u_33.ball(v255, v_u_12, 1, 0, v_u_16)
		v258.Reflectance = 0
		local v259 = v_u_28(CFrame.new(v255), 1, v_u_7.EclipseCorona, v_u_8, 0.05)
		local v260 = v_u_28(CFrame.new(v255), 1, v_u_7.EclipseRays, v_u_10, 0.3)
		local v261 = v_u_28(CFrame.new(p_u_33.ground(p251, 0.12)), 1, v_u_7.Glow, v_u_13, 1)
		for _, v262 in {
			v257,
			v258,
			v259,
			v260,
			v261
		} do
			v_u_1:AddItem(v262, v256)
		end
		local v_u_263 = {
			["sun"] = nil,
			["moon"] = nil,
			["corona"] = nil,
			["rays"] = nil,
			["shade"] = nil,
			["at"] = nil,
			["from"] = nil,
			["born"] = nil,
			["span"] = nil,
			["landAt"] = nil,
			["done"] = false,
			["sun"] = v257,
			["moon"] = v258,
			["corona"] = v259,
			["rays"] = v260,
			["shade"] = v261,
			["at"] = v255,
			["from"] = p_u_250.feet,
			["born"] = os.clock(),
			["span"] = p252
		}
		if p_u_250.mine then
			p_u_33.light(v257, v_u_9, 40 * v253)
		end
		v_u_209[p_u_250] = v_u_263
		p_u_33.runNow(function()
			-- upvalues: (ref) v_u_249, (copy) p_u_250, (copy) v_u_263
			return v_u_249(p_u_250, v_u_263)
		end)
		return v_u_263
	end
	local v358 = {
		["eclipse_spiral_a"] = {
			["cast"] = function(p265) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_33, (ref) v_u_9, (copy) v_u_50, (ref) v_u_4, (ref) v_u_7
				local v266 = p265.size
				local v267 = p265.eye + p265.dir * 1.2
				v_u_5.flash(v267, v_u_8, 3 * v266, 0.1)
				p_u_33.pop(v267, v_u_9, 1.2 * v266, 0.3 * v266, 0.08)
				if not p265.lite then
					local v268 = v_u_50
					local v269 = p_u_33.facing
					local v270 = v_u_4.CurrentCamera
					local v271
					if v270 then
						local v272 = v270.CFrame.Position - v267
						v271 = v272.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v272.Unit
					else
						v271 = Vector3.new(0, 0, 1)
					end
					v268(v269(v267, v271), 0.4 * v266, 2.2 * v266, v_u_7.EclipseRays, v_u_8, 0.12, 6, 0.1)
				end
			end,
			["shot"] = v85,
			["impact"] = v104,
			["hit"] = function(p273, p274, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (ref) v_u_10
				p_u_33.burst("Impact", p274, v_u_8, 0.6)
				if not p273.lite then
					p_u_33.glint(p274, v_u_10, 2.6, 0.12)
				end
			end
		},
		["eclipse_spiral_e"] = {
			["cast"] = function(p275) -- name: cast
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (copy) v_u_50, (ref) v_u_4, (ref) v_u_7
				p_u_33.skillCast(p275, v_u_8)
				if not p275.lite then
					local v276 = v_u_50
					local v277 = p275.eye + p275.dir
					local v278 = p_u_33.facing
					local v279 = v_u_4.CurrentCamera
					local v280
					if v279 then
						local v281 = v279.CFrame.Position - v277
						v280 = v281.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v281.Unit
					else
						v280 = Vector3.new(0, 0, 1)
					end
					v276(v278(v277, v280), 0.6, 3, v_u_7.EclipseCorona, v_u_8, 0.2, -10, 0.1)
				end
			end,
			["windup"] = function(p282, p283, p284) -- name: windup
				-- upvalues: (copy) v_u_180, (copy) p_u_33, (ref) v_u_13, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8
				local v285 = p282.size
				local v286 = p282.ability.radius * v285
				local v287 = math.max(p284, 0.08)
				local v288 = v_u_180(p282, p283, v287)
				p_u_33.sigil(CFrame.new(p_u_33.ground(p283, 0.14)), v286 * 0.8, v_u_13, v_u_7.EclipseCorona, v287 + v288.hold, -0.8)
				p_u_33.sigil(CFrame.new(p_u_33.ground(p283, 0.16)), v286, v_u_10, v_u_7.Ring, v287 + v288.hold, 0.4)
				p_u_33.inward(v288.top, v_u_8, p282.lite and 3 or 6, 9 * v285, v287)
			end,
			["land"] = function(p289, p290) -- name: land
				-- upvalues: (copy) v_u_105, (ref) v_u_5, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (copy) p_u_33
				local v291 = p289.size
				local v292 = p289.ability.radius * v291
				local v293 = v_u_105[p289]
				v_u_105[p289] = nil
				if v293 and not v293.done then
					v293.landAt = os.clock()
					for _, v294 in v293.chains do
						v_u_5.flash(v294.goal, v_u_8, 3 * v291, 0.14)
						if p289.lite then
							continue
						end
						v_u_5.ring(v294.goal, v_u_10, 2.4 * v291, 0.3, v_u_7.Ring)
					end
					v_u_5.flash(v293.top, v_u_8, 8.399999999999999 * v291, 0.16)
				end
				local v295 = p_u_33.ground(p290)
				local v296 = p_u_33.burst
				local v297 = v295 + Vector3.new(0, 0.3, 0)
				local v298 = v_u_8
				local v299 = v292 / 16
				v296("Shockwave", v297, v298, (math.min(v299, 1.2)))
				v_u_5.ring(v295, v_u_8, v292 * 1.05, 0.35, v_u_7.Shockwave)
				if not p289.lite then
					p_u_33.spikes(p_u_33.ground(p290, 1), v_u_10, 6, v292 * 0.8, 0.22, nil, nil, true)
				end
				if p289.mine then
					v_u_5.shake(0.22, 0.22)
				end
			end,
			["hit"] = function(p300, p301, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (copy) v_u_208
				p_u_33.burst("Impact", p301, v_u_8, 0.7)
				if not p300.lite then
					local v302 = v_u_208
					local v303 = p300.ability.freeze or 2.5
					v302(p301, math.min(v303, 2.5) - 0.3)
				end
			end
		},
		["eclipse_spiral_r"] = {
			["cast"] = function(p304) -- name: cast
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (copy) v_u_63
				p_u_33.skillCast(p304, v_u_8, true)
				p_u_33.burst("Flash", p304.eye, v_u_8, 0.35)
				if p304.mine then
					v_u_63("TotalEclipse", Color3.fromRGB(196, 198, 226), -0.16, 0.12, -0.25, 0.15, (p304.ability.delay or 0.25) + 0.1, 0.5)
				end
			end,
			["windup"] = function(p305, p306, p307) -- name: windup
				-- upvalues: (copy) v_u_264, (copy) p_u_33, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_5
				local v_u_308 = p305.size
				local v309 = p305.ability.radius * v_u_308
				local v310 = math.max(p307, 0.08)
				local v_u_311 = v_u_264(p305, p306, v310)
				p_u_33.sigil(CFrame.new(p_u_33.ground(p306, 0.15)), v309, v_u_10, v_u_7.Ring, v310 + 0.4, 0.6)
				p_u_33.after(v310 * 0.8, function()
					-- upvalues: (copy) v_u_311, (ref) v_u_4, (ref) p_u_33, (copy) v_u_308, (ref) v_u_8
					if not v_u_311.done then
						local v312 = v_u_311.at
						local v313 = v_u_4.CurrentCamera
						local v314
						if v313 then
							local v315 = v313.CFrame.Position - v312
							v314 = v315.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v315.Unit
						else
							v314 = Vector3.new(0, 0, 1)
						end
						local v316 = v314:Cross(Vector3.new(0, 1, 0))
						local v317 = v316.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v316.Unit
						p_u_33.glint(v_u_311.at - v317 * 11 * 0.45 * v_u_308 + v314 * 2.5 * v_u_308, v_u_8, 12 * v_u_308, 0.25)
					end
				end)
				if p305.mine then
					v_u_5.shake(0.15, v310 + 0.1)
				end
			end,
			["land"] = function(p318, p319) -- name: land
				-- upvalues: (copy) p_u_33, (copy) v_u_209, (ref) v_u_4, (copy) v_u_50, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_5, (ref) v_u_12, (ref) v_u_16, (ref) v_u_11, (ref) v_u_13, (ref) v_u_6, (copy) v_u_63
				local v320 = p318.size
				local v_u_321 = p318.ability.radius * v320
				local v322 = p318.lite
				local v_u_323 = p_u_33.ground(p319)
				local v324 = v_u_209[p318]
				v_u_209[p318] = nil
				local v325
				if v324 and not v324.done then
					v325 = v324.at
				else
					local v326 = p_u_33.flatUnit(p319 - p318.feet)
					v325 = p_u_33.ground(p319, 20 * p318.size) + v326 * 8 * p318.size
				end
				if v324 and not v324.done then
					v324.landAt = os.clock()
				end
				local v327 = v_u_4.CurrentCamera
				local v328
				if v327 then
					local v329 = v327.CFrame.Position - v325
					v328 = v329.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v329.Unit
				else
					v328 = Vector3.new(0, 0, 1)
				end
				local v330 = v_u_50
				local v331 = v325 - v328 * 1.6 * v320
				local v332 = p_u_33.facing
				local v333 = v_u_4.CurrentCamera
				local v334
				if v333 then
					local v335 = v333.CFrame.Position - v331
					v334 = v335.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v335.Unit
				else
					v334 = Vector3.new(0, 0, 1)
				end
				v330(v332(v331, v334), 11 * v320, 28.6 * v320, v_u_7.EclipseCorona, v_u_8, 0.45, -3)
				local v336 = v_u_50
				local v337 = v325 - v328 * 2.6 * v320
				local v338 = p_u_33.facing
				local v339 = v_u_4.CurrentCamera
				local v340
				if v339 then
					local v341 = v339.CFrame.Position - v337
					v340 = v341.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v341.Unit
				else
					v340 = Vector3.new(0, 0, 1)
				end
				v336(v338(v337, v340), 16.5 * v320, 39.6 * v320, v_u_7.EclipseRays, v_u_10, 0.5, 1.2, 0.1)
				p_u_33.pop(v325, v_u_8, 11 * v320, 22 * v320, 0.25, 0.2)
				local v342 = v322 and 6 or 12
				local v343 = math.random() * 3.141592653589793 * 2
				for v344 = 1, v342 do
					local v345 = v343 + (v344 - 1) / v342 * 3.141592653589793 * 2
					local v346 = p_u_33.ground(p319, 0.3)
					local v347 = math.cos(v345)
					local v348 = math.sin(v345)
					local v349 = v346 + Vector3.new(v347, 0, v348) * v_u_321 * 0.85
					p_u_33.thin(p_u_33.rod(v325, v349, 1 * v320, v_u_8, 0.1), 0.4, true)
				end
				p_u_33.glowBeam(v325, v_u_323, v_u_8, 9 * v320, 0.4)
				p_u_33.thin(p_u_33.rod(v325, v_u_323, 2.2 * v320, v_u_9, 0), 0.32, true)
				local v350 = p_u_33.ground(p319, 3)
				v_u_5.flash(v350, v_u_8, v_u_321 * 1.2, 0.15)
				p_u_33.pop(v_u_323, v_u_8, v_u_321 * 0.5, v_u_321 * 2.1, 0.38, 0.25)
				p_u_33.pop(v_u_323, v_u_12, v_u_321 * 0.4, v_u_321 * 2.5, 0.55, 0.45, v_u_16)
				v_u_50(CFrame.new(p_u_33.ground(p319, 0.25)), v_u_321 * 0.3, v_u_321 * 1.35, v_u_7.EclipseCorona, v_u_8, 0.6, -3)
				p_u_33.burst("Explosion", p_u_33.ground(p319, 2), v_u_8, 2.4)
				p_u_33.burst("Shockwave", v_u_323 + Vector3.new(0, 0.3, 0), v_u_8, 1.5)
				v_u_5.ring(v_u_323, v_u_8, v_u_321 * 1.2, 0.5, v_u_7.Shockwave)
				p_u_33.after(0.06, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_323, (ref) v_u_10, (copy) v_u_321, (ref) v_u_7
					v_u_5.ring(v_u_323, v_u_10, v_u_321 * 1.45, 0.45, v_u_7.SpeedLines)
				end)
				p_u_33.spikes(p_u_33.ground(p319, 1), v_u_8, v322 and 5 or 10, v_u_321 * 1.1, 0.35, nil, nil, true)
				p_u_33.chunks(p_u_33.ground(p319, 1), {
					p_u_33.EARTH[1],
					p_u_33.EARTH[2],
					v_u_11,
					v_u_13
				}, v322 and 5 or 12, 45, 1.3, 1.2, false, 1)
				p_u_33.mark(p319, v_u_12, v_u_321 * 0.8, 2.5, v_u_7.CrackGlow, 0.05)
				if not v322 then
					p_u_33.mark(p319, v_u_8, v_u_321 * 0.6, 1.6, v_u_7.CrackLines, 0.2)
					local v351 = { v_u_8, v_u_10, v_u_9 }
					p_u_33.chunks(v350, v351, 8, 40, 0.5, 0.9, true, 0.9)
				end
				v_u_6.play("Explosion", {
					["at"] = v_u_323,
					["volume"] = p318.mine and 1 or 0.6
				})
				if p318.mine then
					v_u_5.shake(0.6, 0.55)
					v_u_63("EclipseFlash", v_u_8, 0.3, 0.15, 0, 0.04, 0.05, 0.35)
				end
			end,
			["hit"] = function(p352, p353, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (ref) v_u_4, (ref) v_u_12, (ref) v_u_16
				p_u_33.burst("Impact", p353, v_u_8, 1.1)
				if not p352.lite then
					p_u_33.glint(p353, v_u_8, 5, 0.18)
					local v354 = p_u_33.pop
					local v355 = v_u_4.CurrentCamera
					local v356
					if v355 then
						local v357 = v355.CFrame.Position - p353
						v356 = v357.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v357.Unit
					else
						v356 = Vector3.new(0, 0, 1)
					end
					v354(p353 + v356 * 0.6, v_u_12, 1.4, 0.2, 0.16, 0, v_u_16)
				end
			end
		}
	}
	return v358
end