local v_u_1 = require(script.Parent.Parent.Config.BossDrops)
local v_u_2 = require(script.Parent.Parent.Config.Auras)
local v_u_3 = require(script.Parent.Parent.Config.Pets)
local v_u_53 = {
	["LUCK"] = {
		["luck2"] = 2,
		["luck5"] = 5
	},
	["MAX_LUCK"] = 20,
	["luckWith"] = function(p4, p5) -- name: luckWith
		-- upvalues: (copy) v_u_53
		local v6 = math.max(p4, 1) * math.max(p5 or 1, 1)
		local v7 = v_u_53.MAX_LUCK
		return math.min(v6, v7)
	end,
	["luck"] = function(p8, p9, p10) -- name: luck
		-- upvalues: (copy) v_u_53
		local v11 = 1
		if p8 then
			for v12, v13 in v_u_53.LUCK do
				local v14 = p8[v12]
				if type(v14) ~= "number" or (p9 >= v14 or v11 >= v13) then
					continue
				end
				v11 = v13
			end
		end
		return v_u_53.luckWith(v11, p10)
	end,
	["chanceWith"] = function(p15, p16) -- name: chanceWith
		local v17 = p15 * math.max(p16 or 1, 1)
		return math.min(v17, 1)
	end,
	["roll"] = function(p18, p19, p20, p21) -- name: roll
		-- upvalues: (copy) v_u_1, (copy) v_u_53
		local v22 = math.max(p21 or 1, 1)
		local v23 = {}
		for v24, v25 in p20 or v_u_1.list do
			local v26 = p18[v24]
			if type(v26) ~= "number" or v26 >= v_u_53.chanceWith(v25.chance, v22) then
				continue
			end
			local v27
			if v25.kind == "pet" then
				v27 = false
			else
				v27 = p19(v25)
			end
			local v28 = {
				["drop"] = v25,
				["duplicate"] = v27,
				["coins"] = not v27 and 0 or v_u_1.DUPLICATE_COINS,
				["luck"] = v22
			}
			table.insert(v23, v28)
		end
		return v23
	end,
	["percent"] = function(p29) -- name: percent
		local v30 = string.format("%.3f", p29 * 100)
		local v31 = string.gsub(v30, "0+$", "")
		return string.gsub(v31, "%.$", "") .. "%"
	end,
	["nameOf"] = function(p32) -- name: nameOf
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_3
		if p32.kind == "title" then
			local v33 = v_u_1.TITLES[p32.id]
			if v33 then
				return v33.text
			else
				return p32.id
			end
		elseif p32.kind == "aura" then
			local v34 = v_u_2.byId[p32.id]
			if v34 then
				return v34.name
			else
				return p32.id
			end
		else
			local v35 = v_u_3.byId[p32.id]
			if v35 then
				return v35.name
			else
				return p32.id
			end
		end
	end,
	["lines"] = function(p36) -- name: lines
		-- upvalues: (copy) v_u_53
		local v37 = p36.drop
		local v38 = string.upper(v_u_53.nameOf(v37))
		local v39 = v_u_53.odds(v37.chance, p36.luck)
		if p36.duplicate then
			return ("DUPLICATE! +%* KYUBI COINS"):format(p36.coins), ("%* %*"):format(v38, v39)
		else
			return ("OBTAINED %*!"):format(v38), ("%* %*"):format(v37.what, v39)
		end
	end,
	["odds"] = function(p40, p41) -- name: odds
		-- upvalues: (copy) v_u_53
		local v42 = math.max(p41 or 1, 1)
		if v42 > 1 then
			return ("(%* x%* LUCK)"):format(v_u_53.percent(v_u_53.chanceWith(p40, v42)), v42)
		else
			return ("(%*)"):format((v_u_53.percent(p40)))
		end
	end,
	["announce"] = function(p43, p44, p45) -- name: announce
		-- upvalues: (copy) v_u_53
		return ("%* OBTAINED %*! %*"):format(p43, string.upper(v_u_53.nameOf(p44)), (v_u_53.odds(p44.chance, p45)))
	end,
	["find"] = function(p46, p47) -- name: find
		-- upvalues: (copy) v_u_1
		for _, v48 in v_u_1.list do
			if v48.kind ~= p46 or v48.id ~= p47 then
				continue
			end
			return v48
		end
		return nil
	end,
	["bestTitle"] = function(p49) -- name: bestTitle
		local v50 = (-1 / 0)
		local v51 = nil
		for _, v52 in p49 do
			if v50 >= v52.rank then
				continue
			end
			v51 = v52.text
			v50 = v52.rank
		end
		return v51
	end
}
return v_u_53