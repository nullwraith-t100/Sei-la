local v_u_1 = game:GetService("ContextActionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("PolicyService")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = require(v4.Shared.Config.Daily)
local v_u_8 = require(v4.Shared.Logic.DailyStreak)
local v_u_9 = require(v4.Shared.Config.Packs)
local v_u_10 = require(v4.Shared.Config.Pets)
local v_u_11 = require(v4.Shared.Config.Products)
local v_u_12 = require(v4.Shared.Logic.Prizes)
local v_u_13 = require(v4.Shared.Logic.Luck)
local v_u_14 = require(script.Parent.LuckLadder)
local v_u_15 = require(script.Parent.Gamepad)
local v_u_16 = require(script.Parent.PetModels)
local v_u_17 = require(script.Parent.State)
local v_u_18 = require(script.Parent.Store)
local v_u_19 = require(script.Parent.Ui)
local v_u_20 = {}
local v_u_21 = v2.LocalPlayer
local function v_u_22(_) end
local v_u_23 = nil
local function v_u_30() -- name: checkPolicy
	-- upvalues: (copy) v_u_3, (copy) v_u_21, (ref) v_u_23
	for v24 = 1, 3 do
		local v25 = v_u_3.GetPolicyInfoForPlayerAsync
		local v26 = v_u_3
		local v27 = v_u_21
		local v28, v29 = pcall(v25, v26, v27)
		if v28 and type(v29) == "table" then
			v_u_23 = v29.ArePaidRandomItemsRestricted == true
			return
		end
		task.wait(v24 * 2)
	end
	v_u_23 = true
end
function v_u_20.blocked() -- name: blocked
	-- upvalues: (copy) v_u_21, (copy) v_u_5, (ref) v_u_23
	local v31 = v_u_21:GetAttribute("DevRandom")
	if not v_u_5:IsStudio() or type(v31) ~= "boolean" then
		v31 = nil
	end
	if v31 == nil then
		return v_u_23 ~= false
	else
		return not v31
	end
end
local function v_u_33() -- name: furthestWorld
	-- upvalues: (copy) v_u_12, (copy) v_u_17
	local _, v32 = v_u_12.progress(v_u_17.number("BestStage"), v_u_17.number("BestStage2"), v_u_17.number("BestStage3"), v_u_17.number("BestStage4"), v_u_17.number("BestStage5"), v_u_17.number("BestStage6"), v_u_17.number("BestStage7"), v_u_17.number("BestStage8"))
	return v32
end
local function v_u_39(p34) -- name: eggsIn
	-- upvalues: (copy) v_u_33, (copy) v_u_12
	local v35 = v_u_33()
	local v36 = {}
	for _, v37 in p34 do
		if v37.kind ~= "egg" then
			continue
		end
		local v38 = {
			["egg"] = v_u_12.eggFor(v37, v35),
			["count"] = v37.count or 1
		}
		table.insert(v36, v38)
	end
	return v36
end
local function v_u_43() -- name: skipDayPrizes
	-- upvalues: (copy) v_u_8, (copy) v_u_17, (copy) v_u_7
	local v40, _, v41 = v_u_8.claim(v_u_17.number("DailyStreak"), v_u_17.number("DailyLast", -1), v_u_17.number("DailyWeek"), v_u_17.number("Today", -2), v_u_7.DAYS, true)
	local v42
	if v40 then
		v42 = v_u_7.week(v41)[v40]
	else
		v42 = nil
	end
	return v42 and { v42 } or {}
end
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = {}
local v_u_47 = 1
local v_u_48 = nil
local v_u_49 = nil
local function v_u_51() -- name: close
	-- upvalues: (ref) v_u_44, (ref) v_u_48, (copy) v_u_1, (copy) v_u_15, (ref) v_u_49
	if v_u_44 then
		v_u_44.Enabled = false
	end
	v_u_48 = nil
	v_u_1:UnbindAction("OddsClose")
	v_u_15.capture("odds", false)
	local v50 = v_u_49
	v_u_49 = nil
	if v50 and (v50.Parent and v_u_15.shown(v50)) then
		v_u_15.select(v50)
	end
end
local function v_u_62() -- name: build
	-- upvalues: (ref) v_u_44, (ref) v_u_45, (copy) v_u_21, (copy) v_u_51, (ref) v_u_48, (ref) v_u_47, (ref) v_u_46, (copy) v_u_20, (copy) v_u_15
	if v_u_44 and v_u_45 then
		return v_u_44, v_u_45
	end
	local v52 = v_u_21:WaitForChild("PlayerGui"):FindFirstChild("Main")
	if v52 then
		v52 = v52:FindFirstChild("Frames")
	end
	if v52 then
		v52 = v52:FindFirstChild("Egg")
	end
	if not (v52 and v52:IsA("Frame")) then
		return nil, nil
	end
	local v_u_53 = Instance.new("ScreenGui")
	v_u_53.Name = "Odds"
	v_u_53.ResetOnSpawn = false
	v_u_53.DisplayOrder = 60
	v_u_53.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_53.Enabled = false
	local v_u_54 = v52:Clone()
	v_u_54.Name = "OddsPanel"
	v_u_54.Visible = true
	v_u_54.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_54.Position = UDim2.fromScale(0.5, 0.5)
	for v55 in v_u_54:GetAttributes() do
		v_u_54:SetAttribute(v55, nil)
	end
	local v56 = Instance.new("UIScale")
	v56.Name = "Pop"
	v56.Parent = v_u_54
	local v57 = Instance.new("TextButton")
	v57.Name = "OddsDim"
	v57.Text = ""
	v57.AutoButtonColor = false
	v57.BackgroundColor3 = Color3.new(0, 0, 0)
	v57.BackgroundTransparency = 0.35
	v57.BorderSizePixel = 0
	v57.Position = UDim2.fromOffset(0, -120)
	v57.Size = UDim2.new(1, 0, 1, 240)
	v57.ZIndex = v_u_54.ZIndex - 1
	v57.Selectable = false
	v57.Activated:Connect(v_u_51)
	v57.Parent = v_u_53
	v_u_54.Parent = v_u_53
	local v58 = v_u_54:FindFirstChild("Close", true)
	if v58 and v58:IsA("GuiButton") then
		v58.Activated:Connect(v_u_51)
	end
	local v59 = v_u_54:FindFirstChild("Hatch1", true)
	if v59 and v59:IsA("GuiButton") then
		v59.Activated:Connect(function()
			-- upvalues: (ref) v_u_48, (ref) v_u_51
			local v60 = v_u_48
			v_u_51()
			if v60 then
				v60()
			end
		end)
	end
	local v61 = v_u_54:FindFirstChild("Hatch3", true)
	if v61 and v61:IsA("GuiButton") then
		v61.Activated:Connect(function()
			-- upvalues: (ref) v_u_47, (ref) v_u_46, (ref) v_u_20
			v_u_47 = v_u_47 >= #v_u_46 and 1 or v_u_47 + 1
			v_u_20.showPage()
		end)
	end
	v_u_53.Parent = v_u_21:WaitForChild("PlayerGui")
	v_u_44 = v_u_53
	v_u_45 = v_u_54
	v_u_15.onEnter(function()
		-- upvalues: (copy) v_u_53, (ref) v_u_15, (copy) v_u_54
		if not v_u_53.Enabled then
			return false
		end
		v_u_15.select((v_u_54:FindFirstChild("Hatch1", true)))
		return v_u_15.selected() ~= nil
	end, 30)
	return v_u_53, v_u_54
end
function v_u_20.showPage() -- name: showPage
	-- upvalues: (ref) v_u_45, (ref) v_u_46, (ref) v_u_47, (copy) v_u_10, (copy) v_u_21, (copy) v_u_13, (copy) v_u_14, (copy) v_u_19, (copy) v_u_16
	local v63 = v_u_45
	local v64 = v_u_46[v_u_47]
	local v65
	if v64 then
		v65 = v_u_10.eggById[v64.egg]
	else
		v65 = v64
	end
	if v63 and v65 then
		local v66 = v_u_21:WaitForChild("PlayerGui"):FindFirstChild("Main")
		if v66 then
			v66 = v66:FindFirstChild("Templates")
		end
		if v66 then
			v66 = v66:FindFirstChild("ChanceCard")
		end
		local v67 = v63:FindFirstChild("Pool", true)
		if v67 and v66 then
			for _, v68 in v67:GetChildren() do
				if not v68:IsA("GuiObject") then
					continue
				end
				v68:Destroy()
			end
			local v71 = v_u_13.chances(v65.pool, function(p69)
				-- upvalues: (ref) v_u_10
				local v70 = v_u_10.byId[p69]
				return not v70 and "Common" or v70.rarity
			end, v_u_14.tier())
			for v72, v73 in v65.pool do
				local v74 = v_u_10.byId[v73.pet]
				if not v74 then
					continue
				end
				local v75 = v66:Clone()
				v75.Visible = true
				v75.LayoutOrder = v72
				v75.Size = UDim2.fromScale(0.18, 0.95)
				v75.Position = UDim2.new()
				v75.AnchorPoint = Vector2.zero
				if v75:IsA("GuiButton") then
					v75.Selectable = false
				end
				v_u_19.paint(v75, v74.rarity)
				local v76 = v75:FindFirstChild("Chance", true)
				if v76 and v76:IsA("TextLabel") then
					v76.Text = v_u_13.percent(v71[v72] or 0)
				end
				local v77 = v75:FindFirstChild("View", true)
				local v78 = v_u_16.build(v74.id)
				if v78 and (v77 and v77:IsA("ViewportFrame")) then
					v_u_16.show(v77, v78, false)
				end
				v75.Parent = v67
			end
			local v79 = v63:FindFirstChild("Cost", true)
			if v79 and v79:IsA("TextLabel") then
				v79.Text = ("%*x %*"):format(v64.count, (string.upper(v65.name)))
				v79.Size = UDim2.fromScale(0.6, v79.Size.Y.Scale)
			end
			local v80 = v63:FindFirstChild("CostIcon", true)
			if v80 and v80:IsA("GuiObject") then
				v80.Visible = false
			end
			local v81 = v63:FindFirstChild("Free", true)
			if v81 and v81:IsA("TextLabel") then
				v81.Text = #v_u_46 <= 1 and "ODDS FOR EACH PET" or ("EGG %* OF %*: ODDS FOR EACH PET"):format(v_u_47, #v_u_46)
			end
			local v82 = v63:FindFirstChild("Hatch3", true)
			if v82 and v82:IsA("GuiObject") then
				v82.Visible = #v_u_46 > 1
				if not v82 then
					return
				end
				local v83 = v82:FindFirstChild("TextLabel")
				if v83 and v83:IsA("TextLabel") then
					v83.Text = "NEXT EGG"
				end
			end
		end
	else
		return
	end
end
local function v_u_97(p84, p85, p86, p87) -- name: show
	-- upvalues: (copy) v_u_62, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (copy) v_u_19, (copy) v_u_20, (copy) v_u_15, (ref) v_u_49, (copy) v_u_6, (copy) v_u_1, (copy) v_u_51
	local v88, v89 = v_u_62()
	if v88 and v89 then
		v_u_46 = p85
		v_u_47 = 1
		v_u_48 = p87
		local v90 = v89:FindFirstChild("Top", true)
		if v90 then
			v_u_19.setText(v90, p84)
		end
		local v91 = v89:FindFirstChild("Hatch1", true)
		local v92 = "BUY  " .. p86
		if v91 then
			local v93 = v91:FindFirstChild("TextLabel")
			if v93 and v93:IsA("TextLabel") then
				v93.Text = v92
			end
		end
		v_u_20.showPage()
		local v94 = v_u_15.selected()
		if not v88.Enabled and (v94 and not v94:IsDescendantOf(v88)) then
			v_u_49 = v94
		end
		v_u_15.capture("odds", true)
		v88.Enabled = true
		local v95 = v89:FindFirstChild("Pop")
		if v95 and v95:IsA("UIScale") then
			v95.Scale = 0.72
			v_u_6:Create(v95, TweenInfo.new(0.25, Enum.EasingStyle.Back), {
				["Scale"] = 1
			}):Play()
		end
		v_u_15.select((v89:FindFirstChild("Hatch1", true)))
		v_u_1:BindActionAtPriority("OddsClose", function(_, p96)
			-- upvalues: (ref) v_u_51
			if p96 == Enum.UserInputState.Begin then
				v_u_51()
			end
			return Enum.ContextActionResult.Sink
		end, false, Enum.ContextActionPriority.High.Value, Enum.KeyCode.ButtonB)
	end
end
function v_u_20.restricted() -- name: restricted
	-- upvalues: (copy) v_u_21, (copy) v_u_5, (ref) v_u_23
	local v98 = v_u_21:GetAttribute("DevRandom")
	if not v_u_5:IsStudio() or type(v98) ~= "boolean" then
		v98 = nil
	end
	if v98 == nil then
		return v_u_23 == true
	else
		return not v98
	end
end
local function v_u_109(p99, p100, p101) -- name: gate
	-- upvalues: (ref) v_u_23, (copy) v_u_11, (copy) v_u_9, (copy) v_u_20, (copy) v_u_97, (copy) v_u_39, (copy) v_u_18, (copy) v_u_43, (ref) v_u_22
	local v102 = 0
	while v_u_23 == nil and v102 < 6 do
		task.wait(0.25)
		v102 = v102 + 0.25
	end
	if p99 == "pass" then
		local v103 = v_u_11.passByKey[p100]
		local v104 = v_u_9[p100]
		if v103 and (v104 and not v_u_20.restricted()) then
			v_u_97(string.upper(v103.name), v_u_39(v104), v_u_18.priceText(v103.price), p101)
		else
			p101()
		end
	else
		local v105 = v_u_11.productByKey[p100]
		if v105 and (v105.kind == "skipDay" or v105.kind == "dailyAll") then
			local v106
			if v105.kind == "skipDay" then
				v106 = v_u_43()
			else
				v106 = v_u_18.dailyAllPrizes()
			end
			local v107 = v105.kind == "skipDay" and "SKIP DAY" or "UNLOCK ALL"
			local v108 = v_u_39(v106)
			if #v108 == 0 or v_u_20.restricted() then
				p101()
				return
			elseif v_u_20.blocked() then
				v_u_22("Couldn\'t check your region\'s rules, try again in a moment.")
			else
				v_u_97(v107, v108, v_u_18.priceText(v105.price), p101)
			end
		elseif v_u_20.blocked() then
			v_u_22("Random pets can\'t be bought with Robux in your region.")
		else
			p101()
		end
	end
end
function v_u_20.start(p110) -- name: start
	-- upvalues: (ref) v_u_22, (copy) v_u_18, (copy) v_u_109, (copy) v_u_20, (copy) v_u_30, (copy) v_u_5, (copy) v_u_21
	v_u_22 = p110
	v_u_18.onRandomPurchase(v_u_109, v_u_20.blocked, v_u_20.restricted)
	task.spawn(function()
		-- upvalues: (ref) v_u_30, (ref) v_u_18
		v_u_30()
		v_u_18.fireRandomChanged()
	end)
	if v_u_5:IsStudio() then
		v_u_21:GetAttributeChangedSignal("DevRandom"):Connect(function()
			-- upvalues: (ref) v_u_18
			v_u_18.fireRandomChanged()
		end)
	end
end
return v_u_20