local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
return function(p_u_8)
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6, (copy) v_u_4
	local v_u_9 = p_u_8.rgb
	local v_u_10 = p_u_8.WHITE
	local v_u_11 = v_u_9(255, 138, 30)
	local v_u_12 = v_u_9(255, 227, 107)
	local v_u_13 = v_u_9(255, 250, 222)
	local v_u_14 = v_u_9(255, 78, 10)
	local v_u_15 = v_u_9(40, 22, 12)
	local function v_u_22(p16, p17, p18, p19) -- name: petal
		-- upvalues: (ref) v_u_5, (ref) v_u_1
		local v20 = v_u_5.part(p16, p17, p18, {
			["transparency"] = p19
		})
		local v21 = Instance.new("SpecialMesh")
		v21.MeshType = Enum.MeshType.Sphere
		v21.Parent = v20
		v_u_1:AddItem(v20, 6)
		return v20
	end
	local function v_u_40(p23, p24, p25, p26, p27, p28, p29) -- name: flatRing
		-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_1
		local v30 = v_u_5.part
		local v31 = p25 * 2
		local v32 = p25 * 2
		local v33 = v30(Vector3.new(v31, 0.05, v32), CFrame.new(p23) * CFrame.Angles(0, math.random() * 6.28, 0), p24, {
			["transparency"] = 1
		})
		for _, v34 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v35 = Instance.new("Decal")
			v35.Face = v34
			v35.Texture = p28 or v_u_7.Ring
			v35.Color3 = p24
			v35.Transparency = p29 or 0
			v35.Parent = v33
			v_u_5.tween(v35, p27, {
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
		local v36 = v_u_5.tween
		local v37 = {}
		local v38 = p26 * 2
		local v39 = p26 * 2
		v37.Size = Vector3.new(v38, 0.05, v39)
		v36(v33, p27, v37, Enum.EasingStyle.Quart)
		v_u_1:AddItem(v33, p27 + 0.05)
	end
	local function v_u_64(p41, p42, p43, p44, p45) -- name: flare
		-- upvalues: (copy) p_u_8, (copy) v_u_22, (copy) v_u_11, (copy) v_u_12, (ref) v_u_5, (ref) v_u_1
		local v46 = p_u_8.aimAt(p41, p42)
		local v47 = math.random() * 3.141592653589793
		for v48 = 1, p43 do
			local v49 = v47 + v48 / p43 * 3.141592653589793 * 2
			local v50 = v46.RightVector * math.cos(v49) + v46.UpVector * math.sin(v49)
			local v51 = p_u_8.aimAt(p41, v50)
			local v52 = v_u_22
			local v53 = p44 * 0.22
			local v54 = p44 * 0.22
			local v55 = p44 * 0.35
			local v56 = Vector3.new(v53, v54, v55)
			local v57 = v51 * CFrame.new(0, 0, -p44 * 0.2)
			local v58
			if v48 % 2 == 0 then
				v58 = v_u_11
			else
				v58 = v_u_12
			end
			local v59 = v52(v56, v57, v58)
			local v60 = v_u_5.tween
			local v61 = {
				["Size"] = nil,
				["CFrame"] = nil,
				["Transparency"] = 1
			}
			local v62 = p44 * 0.1
			local v63 = p44 * 0.1
			v61.Size = Vector3.new(v62, v63, p44)
			v61.CFrame = v51 * CFrame.new(0, 0, -p44 * 0.7)
			v60(v59, p45, v61)
			v_u_1:AddItem(v59, p45 + 0.05)
		end
	end
	local function v_u_97(p_u_65, p_u_66, p67) -- name: shimmer
		-- upvalues: (ref) v_u_5, (copy) v_u_12, (ref) v_u_1, (copy) p_u_8, (ref) v_u_7, (copy) v_u_13
		local v68 = (p_u_66 - p_u_65).Magnitude
		if v68 >= 6 then
			local v_u_69 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_65), v_u_12, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_69, p67 + 0.1)
			local v70 = p_u_8.aimAt(p_u_65, p_u_66 - p_u_65)
			local v_u_71 = v70.LookVector
			local v72 = v68 / 14
			local v73 = math.floor(v72)
			local v_u_74 = math.clamp(v73, 2, 6)
			local v75 = v68 / v_u_74
			local v_u_76 = {}
			for v77 = 1, 2 do
				local v78 = {
					["atts"] = {},
					["beams"] = {}
				}
				local v79
				if v77 == 1 then
					v79 = v70.UpVector
				else
					v79 = v70.RightVector
				end
				v78.side = v79
				v78.phase = v77 * 1.7
				for _ = 0, v_u_74 do
					local v80 = Instance.new("Attachment")
					v80.Parent = v_u_69
					local v81 = v78.atts
					table.insert(v81, v80)
				end
				for v82 = 1, v_u_74 do
					local v83 = Instance.new("Beam")
					v83.Attachment0 = v78.atts[v82]
					v83.Attachment1 = v78.atts[v82 + 1]
					v83.Texture = v_u_7.Beam
					v83.TextureMode = Enum.TextureMode.Wrap
					v83.TextureLength = 6
					v83.TextureSpeed = 3
					v83.LightEmission = 0.6
					v83.LightInfluence = 0
					local v84 = ColorSequence.new
					local v85
					if v77 == 1 then
						v85 = v_u_12
					else
						v85 = v_u_13
					end
					v83.Color = v84(v85)
					v83.FaceCamera = true
					v83.Segments = 10
					v83.Width0 = 0.4
					v83.Width1 = 0.4
					v83.CurveSize0 = v75 * 0.4
					v83.CurveSize1 = v75 * 0.4
					v83.Parent = v_u_69
					local v86 = v78.beams
					table.insert(v86, v83)
				end
				table.insert(v_u_76, v78)
			end
			local v_u_87 = os.clock()
			p_u_8.animate(p67, 0, function(p88)
				-- upvalues: (copy) v_u_87, (copy) v_u_76, (copy) p_u_65, (copy) p_u_66, (copy) v_u_74, (ref) p_u_8, (copy) v_u_71, (copy) v_u_69
				local v89 = os.clock() - v_u_87
				for _, v90 in v_u_76 do
					for v91, v92 in v90.atts do
						local v93 = v89 * 34 + v91 * 2.1 + v90.phase
						local v94 = math.sin(v93) * 0.8
						local v95 = p_u_65:Lerp(p_u_66, (v91 - 1) / v_u_74)
						v92.WorldCFrame = p_u_8.aimAt(v95, v_u_71 + v90.side * v94) * CFrame.Angles(0, 1.5707963267948966, 0)
					end
					for _, v96 in v90.beams do
						v96.Transparency = NumberSequence.new(0.45 + 0.55 * p88)
					end
				end
				if p88 >= 1 then
					v_u_69:Destroy()
				end
			end)
		end
	end
	local function v_u_110(p98, p99, p100, p101) -- name: embers
		-- upvalues: (copy) p_u_8, (copy) v_u_12, (copy) v_u_11, (ref) v_u_5, (ref) v_u_1
		for _ = 1, p100 do
			local v102 = p98:Lerp(p99, math.random())
			local v103 = p_u_8.ball
			local v104
			if math.random() < 0.5 then
				v104 = v_u_12
			else
				v104 = v_u_11
			end
			local v105 = v103(v102, v104, 0.4, 0)
			local v106 = (math.random() - 0.5) * 2
			local v107 = 2 + math.random() * 2
			local v108 = (math.random() - 0.5) * 2
			local v109 = Vector3.new(v106, v107, v108)
			v_u_5.tween(v105, p101, {
				["CFrame"] = nil,
				["Size"] = Vector3.new(0.08, 0.08, 0.08),
				["Transparency"] = 1,
				["CFrame"] = CFrame.new(v102 + v109)
			})
			v_u_1:AddItem(v105, p101 + 0.05)
		end
	end
	local function v_u_150(p_u_111, p_u_112, p113, p114, p115) -- name: corona
		-- upvalues: (copy) v_u_22, (copy) v_u_11, (copy) v_u_14, (copy) v_u_12, (copy) p_u_8
		local v116 = math.random() * 3.141592653589793
		local v_u_117 = {}
		for v118 = 1, p113 do
			local v119 = {}
			local v120 = v_u_22
			local v121 = Vector3.new(1, 1, 1)
			local v122 = CFrame.new(p_u_111)
			local v123
			if v118 % 2 == 0 then
				v123 = v_u_11
			else
				v123 = v_u_14
			end
			v119.outer = v120(v121, v122, v123, 0.1)
			v119.inner = v_u_22(Vector3.new(1, 1, 1), CFrame.new(p_u_111), v_u_12, 0)
			v119.a = v116 + v118 / p113 * 3.141592653589793 * 2
			v119.h = p114 * (v118 % 2 == 0 and 1 or 0.72)
			table.insert(v_u_117, v119)
		end
		p_u_8.animate(p115, 0, function(p124)
			-- upvalues: (copy) p_u_112, (copy) v_u_117, (copy) p_u_111
			local v125 = 1 - (1 - p124) ^ 3
			local v126 = 1.5 + (p_u_112 - 1.5) * v125
			local v127 = 0.2 + 0.95 * v125
			local v128 = p124 * 2.2
			local v129 = math.min(v128, 1) * 3.141592653589793 / 2
			local v130 = math.sin(v129)
			local v131 = (p124 - 0.45) / 0.55
			local v132 = math.clamp(v131, 0, 1)
			for _, v133 in v_u_117 do
				local v134 = v133.a
				local v135 = math.cos(v134)
				local v136 = v133.a
				local v137 = math.sin(v136)
				local v138 = Vector3.new(v135, 0, v137)
				local v139 = p_u_111 + v138 * v126
				local v140 = v133.h * (v130 * 0.7 + 0.3) * (1 - 0.35 * p124)
				local v141 = math.max(v140, 0.2)
				local v142 = CFrame.lookAt(v139, v139 + v138) * CFrame.Angles(-v127, 0, 0)
				local v143 = v133.outer
				local v144 = v141 * 0.42
				local v145 = v141 * 0.16
				v143.Size = Vector3.new(v144, v141, v145)
				v133.outer.CFrame = v142 * CFrame.new(0, v141 * 0.45, 0)
				v133.outer.Transparency = v132 * 0.9 + 0.1
				local v146 = v133.inner
				local v147 = v141 * 0.2
				local v148 = v141 * 0.68
				local v149 = v141 * 0.2
				v146.Size = Vector3.new(v147, v148, v149)
				v133.inner.CFrame = v142 * CFrame.new(0, v141 * 0.34, 0)
				v133.inner.Transparency = v132
				if p124 < 1 then
					continue
				end
				v133.outer:Destroy()
				v133.inner:Destroy()
			end
		end)
	end
	local v_u_151 = 0
	local function v_u_155() -- name: whiteout
		-- upvalues: (ref) v_u_151, (ref) v_u_2, (ref) v_u_5, (copy) v_u_9, (copy) v_u_10, (ref) v_u_1
		local v152 = os.clock()
		if v152 >= v_u_151 then
			v_u_151 = v152 + 0.6
			local v_u_153 = Instance.new("ColorCorrectionEffect")
			v_u_153.Name = "Supernova"
			v_u_153.Parent = v_u_2
			v_u_5.tween(v_u_153, 0.04, {
				["Brightness"] = 0.42,
				["Contrast"] = 0.2,
				["TintColor"] = nil,
				["TintColor"] = v_u_9(255, 236, 200)
			})
			task.delay(0.07, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_153, (ref) v_u_10
				local v154 = {
					["Brightness"] = 0,
					["Contrast"] = 0,
					["TintColor"] = nil,
					["TintColor"] = v_u_10
				}
				v_u_5.tween(v_u_153, 0.45, v154)
			end)
			v_u_1:AddItem(v_u_153, 0.6)
		end
	end
	local v252 = {
		["solar_lotus_a"] = {
			["cast"] = function(p156) -- name: cast
				-- upvalues: (ref) v_u_5, (copy) v_u_11, (copy) p_u_8, (copy) v_u_13, (copy) v_u_12, (copy) v_u_64
				local v157 = p156.size
				local v158 = p156.eye + p156.dir * 1
				v_u_5.flash(v158, v_u_11, 3.2 * v157, 0.12)
				p_u_8.pop(v158, v_u_13, 1.6 * v157, 0.4 * v157, 0.1)
				if not p156.lite then
					p_u_8.glint(v158, v_u_12, 4.5 * v157, 0.14)
					v_u_64(v158, p156.dir, 5, 2.2 * v157, 0.13)
				end
			end,
			["beam"] = function(p159, p160, p161) -- name: beam
				-- upvalues: (copy) p_u_8, (copy) v_u_13, (copy) v_u_11, (ref) v_u_5, (copy) v_u_12, (ref) v_u_7, (copy) v_u_97, (copy) v_u_110
				local v162 = p159.size
				local v163 = p160 + (p161 - p160).Unit * 0.8
				p_u_8.thin(p_u_8.rod(v163, p161, 0.45 * v162, v_u_13), 0.15)
				p_u_8.thin(p_u_8.rod(v163, p161, 1.6 * v162, v_u_11, 0.35), 0.17)
				v_u_5.flash(v163, v_u_12, 2.8 * v162, 0.1)
				if not p159.lite then
					p_u_8.glowBeam(v163, p161, v_u_11, 3.6 * v162, 0.16, v_u_7.FireBeam)
					v_u_97(v163, p161, 0.22)
					v_u_110(v163, p161, 3, 0.45)
				end
			end,
			["hit"] = function(p164, p165, _) -- name: hit
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (copy) v_u_12
				p_u_8.burst("Impact", p165, v_u_11, 0.65)
				if not p164.lite then
					p_u_8.pop(p165, v_u_12, 1, 3, 0.12, 0.3)
				end
				p_u_8.beamHitSound(p164, p165, "Fireball")
			end
		},
		["solar_lotus_e"] = {
			["cast"] = function(p166) -- name: cast
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (copy) v_u_13, (ref) v_u_5, (copy) v_u_12
				p_u_8.skillCast(p166, v_u_11)
				local v167 = p166.origin
				local v_u_168 = p_u_8.ball(v167, v_u_13, 1, 0)
				local v_u_169 = p_u_8.ball(v167, v_u_11, 1.6, 0.35)
				v_u_5.tween(v_u_168, 0.12, {
					["Size"] = Vector3.new(3.2, 3.2, 3.2)
				}, Enum.EasingStyle.Back)
				v_u_5.tween(v_u_169, 0.12, {
					["Size"] = Vector3.new(5.5, 5.5, 5.5)
				}, Enum.EasingStyle.Back)
				task.delay(0.18, function()
					-- upvalues: (ref) p_u_8, (copy) v_u_168, (copy) v_u_169
					p_u_8.fadeOut(v_u_168, 0.1)
					p_u_8.fadeOut(v_u_169, 0.1)
				end)
				p_u_8.glint(p166.eye, v_u_12, 6, 0.2)
				if not p166.lite then
					p_u_8.inward(v167, v_u_12, 6, 7, 0.14)
				end
			end,
			["windup"] = function(p170, p171, p172) -- name: windup
				-- upvalues: (copy) v_u_40, (copy) p_u_8, (copy) v_u_12, (ref) v_u_7, (copy) v_u_11
				v_u_40(p_u_8.ground(p171, 0.3), v_u_12, 10, 2, p172 + 0.05, v_u_7.Ring, 0.2)
				p_u_8.pop(p170.origin, v_u_11, 2, 5, p172 + 0.05, 0.3)
			end,
			["land"] = function(p173, p174) -- name: land
				-- upvalues: (copy) p_u_8, (copy) v_u_13, (copy) v_u_11, (copy) v_u_150, (copy) v_u_12, (ref) v_u_5, (ref) v_u_7, (copy) v_u_40, (copy) v_u_14, (copy) v_u_15, (ref) v_u_6
				local v175 = p173.ability.radius
				local v176 = p173.lite
				local v177 = p_u_8.ground(p174)
				local v178 = p174.X
				local v179 = p173.origin.Y
				local v180 = p174.Z
				local v181 = Vector3.new(v178, v179, v180)
				p_u_8.pop(v181, v_u_13, 3, 10, 0.2, 0)
				p_u_8.pop(v181, v_u_11, 5, 18, 0.32, 0.35)
				p_u_8.burst("Flash", v181, v_u_11, 0.45)
				v_u_150(v177, v175, v176 and 8 or 16, v176 and 6 or 7.5, 0.45)
				p_u_8.spikes(v181, v_u_12, v176 and 6 or 12, v175 * 0.9, 0.3, nil, nil, true)
				v_u_5.ring(v177, v_u_11, v175, 0.45, v_u_7.Shockwave)
				v_u_5.ring(v177, v_u_12, v175 * 1.1, 0.35, v_u_7.Ring)
				p_u_8.burst("Shockwave", v177 + Vector3.new(0, 0.3, 0), v_u_11, v175 / 16)
				if not v176 then
					v_u_40(p_u_8.ground(p174, 3), v_u_12, 3, v175 * 0.9, 0.35, v_u_7.SpeedLines, 0.2)
					local v182 = math.random() * 3.141592653589793
					for v183 = 1, 6 do
						local v184 = v182 + v183 / 6 * 3.141592653589793 * 2
						local v185 = math.cos(v184)
						local v186 = math.sin(v184)
						local v_u_187 = v177 + Vector3.new(v185, 0, v186) * v175 * 0.55
						p_u_8.after(0.08, function()
							-- upvalues: (ref) p_u_8, (copy) v_u_187, (ref) v_u_11
							p_u_8.burst("Fire", v_u_187, v_u_11, 0.8)
						end)
					end
					local v188 = { v_u_11, v_u_12, v_u_14 }
					p_u_8.chunks(v177 + Vector3.new(0, 1, 0), v188, 8, 34, 0.5, 0.7, true, 0.6)
				end
				p_u_8.mark(p174, v_u_15, v175 * 0.35, 1.6)
				p_u_8.mark(p174, v_u_11, v175 * 0.3, 1, v_u_7.CrackGlow, 0.25)
				v_u_6.play("Explosion", {
					["at"] = nil,
					["volume"] = 0.8,
					["at"] = v177
				})
				if p173.mine then
					v_u_5.shake(0.4, 0.35)
				end
			end,
			["hit"] = function(p189, p190, _) -- name: hit
				-- upvalues: (copy) p_u_8, (copy) v_u_11
				p_u_8.burst("Impact", p190, v_u_11, 0.8)
				if not p189.lite then
					p_u_8.burst("Fire", p190 - Vector3.new(0, 1.5, 0), v_u_11, 0.24)
				end
			end
		},
		["solar_lotus_r"] = {
			["cast"] = function(p191) -- name: cast
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (copy) v_u_12
				p_u_8.skillCast(p191, v_u_11, true)
				p_u_8.burst("Flash", p191.eye, v_u_11, 0.4)
				p_u_8.glint(p191.eye, v_u_12, 8, 0.25)
				local v192 = p191.eye + Vector3.new(0, 45, 0)
				p_u_8.thin(p_u_8.rod(p191.eye, v192, 1.2, v_u_12, 0.2), 0.35)
				p_u_8.thin(p_u_8.rod(p191.eye, v192, 3.2, v_u_11, 0.6), 0.3)
			end,
			["windup"] = function(p193, p194, p195) -- name: windup
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (ref) v_u_7, (copy) v_u_40, (copy) v_u_12, (copy) v_u_13, (copy) v_u_14, (copy) v_u_22, (ref) v_u_4, (ref) v_u_1
				local v196 = p193.ability.radius
				local v197 = p193.lite
				local v_u_198 = p_u_8.ground(p194, 52) + p193.dir * 14
				local v_u_199 = p_u_8.ground(p194, 3)
				local v200 = math.max(p195, 0.05)
				p_u_8.sigil(CFrame.new(p_u_8.ground(p194, 0.15)), v196, v_u_11, v_u_7.Ring, v200 + 0.1, 1.5)
				v_u_40(p_u_8.ground(p194, 0.4), v_u_12, v196 * 1.3, v196 * 0.3, v200 + 0.05, v_u_7.Ring, 0.1)
				p_u_8.mark(p194, v_u_12, v196 * 0.6, v200 + 0.4, nil, 0.3)
				local v_u_201 = p_u_8.ball(v_u_198, v_u_13, 6, 0)
				local v_u_202 = p_u_8.ball(v_u_198, v_u_11, 9.5, 0.2)
				local v_u_203 = p_u_8.ball(v_u_198, v_u_14, 14, 0.72)
				p_u_8.streak(v_u_201, v_u_12, v_u_14, 8, 0.3)
				local v_u_204
				if v197 then
					v_u_204 = nil
				else
					v_u_204 = p_u_8.loop("Trail", v_u_201, v_u_11, 1.6)
				end
				if p193.mine then
					p_u_8.light(v_u_201, v_u_11, 40)
				end
				local v_u_205 = v197 and 6 or 10
				local v_u_206 = {}
				for v207 = 1, v_u_205 do
					local v208 = v_u_22
					local v209 = Vector3.new(2, 2, 5.6)
					local v210 = CFrame.new(v_u_198)
					local v211
					if v207 % 2 == 0 then
						v211 = v_u_11
					else
						v211 = v_u_12
					end
					local v212 = v208(v209, v210, v211, 0.1)
					table.insert(v_u_206, v212)
				end
				local v_u_213 = v_u_4.CurrentCamera
				local v_u_214 = os.clock()
				p_u_8.animate(v200, 0, function(p215)
					-- upvalues: (copy) v_u_198, (copy) v_u_199, (copy) v_u_201, (copy) v_u_202, (copy) v_u_203, (copy) v_u_213, (copy) v_u_214, (copy) v_u_206, (copy) v_u_205, (ref) p_u_8, (ref) v_u_204, (ref) v_u_1
					local v216 = v_u_198:Lerp(v_u_199, p215 * p215)
					v_u_201.CFrame = CFrame.new(v216)
					v_u_202.CFrame = CFrame.new(v216)
					v_u_203.CFrame = CFrame.new(v216)
					local v217
					if v_u_213 then
						v217 = v_u_213.CFrame
					else
						v217 = CFrame.identity
					end
					local v218 = (os.clock() - v_u_214) * 5
					for v219, v220 in v_u_206 do
						local v221 = v218 + v219 / v_u_205 * 3.141592653589793 * 2
						local v222 = v217.RightVector * math.cos(v221) + v217.UpVector * math.sin(v221)
						v220.CFrame = p_u_8.aimAt(v216 + v222 * 7.6, v222)
					end
					if p215 >= 1 then
						if v_u_204 then
							v_u_204()
						end
						for _, v223 in v_u_206 do
							v223:Destroy()
						end
						v_u_202:Destroy()
						v_u_203:Destroy()
						v_u_201.Transparency = 1
						local v224 = v_u_201:FindFirstChildWhichIsA("PointLight")
						if v224 then
							v224:Destroy()
						end
						v_u_1:AddItem(v_u_201, 0.8)
					end
				end)
			end,
			["land"] = function(p225, p_u_226) -- name: land
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (copy) v_u_10, (copy) v_u_13, (copy) v_u_155, (copy) v_u_12, (copy) v_u_14, (copy) v_u_40, (ref) v_u_7, (ref) v_u_5, (copy) v_u_15, (ref) v_u_1, (ref) v_u_6
				local v_u_227 = p225.ability.radius
				local v228 = p225.lite
				local v229 = p_u_8.ground(p_u_226)
				local v230 = p_u_8.ground(p_u_226, 3)
				p_u_8.burst("Flash", v230, v_u_11, 1.2, true)
				p_u_8.pop(v230, v_u_10, 6, v_u_227 * 1.5, 0.22, 0)
				p_u_8.glint(p_u_8.ground(p_u_226, 8), v_u_13, 30, 0.35)
				if p225.mine then
					v_u_155()
				end
				p_u_8.pop(v230, v_u_11, 6, v_u_227 * 2.3, 0.55, 0.1)
				p_u_8.pop(v230, v_u_12, 4, v_u_227 * 1.4, 0.4, 0)
				p_u_8.pop(v230, v_u_14, 8, v_u_227 * 2.8, 0.7, 0.2, Enum.Material.ForceField)
				p_u_8.burst("Explosion", v230, v_u_11, v_u_227 / 8)
				for v_u_231, v_u_232 in { 0.3, 5, 10 } do
					p_u_8.after((v_u_231 - 1) * 0.06, function()
						-- upvalues: (ref) v_u_40, (ref) p_u_8, (copy) p_u_226, (copy) v_u_232, (copy) v_u_231, (ref) v_u_11, (ref) v_u_12, (copy) v_u_227, (ref) v_u_7
						local v233 = v_u_40
						local v234 = p_u_8.ground(p_u_226, v_u_232)
						local v235
						if v_u_231 == 1 then
							v235 = v_u_11
						else
							v235 = v_u_12
						end
						v233(v234, v235, 2, v_u_227 * (1.3 - v_u_231 * 0.15), 0.5, v_u_7.Ring)
					end)
				end
				local v236 = p_u_8.burst
				local v237 = v229 + Vector3.new(0, 0.3, 0)
				local v238 = v_u_11
				local v239 = v_u_227 / 14
				v236("Shockwave", v237, v238, (math.min(v239, 1.8)))
				v_u_5.ring(v229, v_u_14, v_u_227 * 1.3, 0.6, v_u_7.Shockwave)
				v_u_5.ring(v229, v_u_12, v_u_227 * 1.5, 0.45, v_u_7.SpeedLines)
				p_u_8.tongues(p_u_226, v_u_227 * 0.6, v228 and 4 or 10, 13, v_u_11, v_u_12, 0.6, true, 0.5)
				p_u_8.thin(p_u_8.pillar(v229, 40, v_u_227 * 0.5, v_u_12, 0.3), 0.6, true)
				p_u_8.thin(p_u_8.pillar(v229, 44, v_u_227 * 0.2, v_u_13, 0), 0.45, true)
				p_u_8.spikes(v230, v_u_12, v228 and 8 or 16, v_u_227 * 1.3, 0.35)
				if not v228 then
					local v240 = math.random() * 3.141592653589793
					for v241 = 1, 6 do
						local v242 = v240 + v241 / 6 * 3.141592653589793 * 2
						local v243 = p_u_8.ground(p_u_226, 2)
						local v244 = math.cos(v242)
						local v245 = math.sin(v242)
						local v_u_246 = v243 + Vector3.new(v244, 0, v245) * v_u_227 * (v241 % 2 * 0.2 + 0.45)
						p_u_8.after(v241 * 0.035 + 0.03, function()
							-- upvalues: (ref) p_u_8, (copy) v_u_246, (ref) v_u_11
							p_u_8.burst("Explosion", v_u_246, v_u_11, 1.3)
						end)
					end
					local v247 = {
						v_u_11,
						v_u_12,
						v_u_14,
						v_u_13
					}
					p_u_8.chunks(v229 + Vector3.new(0, 1, 0), v247, 12, 46, 0.7, 1, true)
					p_u_8.chunks(v229 + Vector3.new(0, 1, 0), { p_u_8.EARTH[1], p_u_8.EARTH[2], v_u_15 }, 8, 36, 1.2, 1)
				end
				local v248 = p_u_8.ball(v230, v_u_13, 4, 0)
				local v249 = p_u_8.ball(v230, v_u_11, 7, 0.5)
				v_u_5.tween(v248, 1, {
					["Size"] = Vector3.new(0.3, 0.3, 0.3),
					["Transparency"] = 0.4
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_5.tween(v249, 0.9, {
					["Size"] = Vector3.new(1, 1, 1),
					["Transparency"] = 1
				})
				v_u_1:AddItem(v248, 1.02)
				v_u_1:AddItem(v249, 0.92)
				p_u_8.mark(p_u_226, v_u_15, v_u_227 * 0.6, 2.4)
				p_u_8.mark(p_u_226, v_u_11, v_u_227 * 0.5, 1.8, v_u_7.CrackGlow, 0.15)
				v_u_6.play("Explosion", {
					["at"] = v229
				})
				if p225.mine then
					v_u_5.shake(0.6, 0.55)
				end
			end,
			["hit"] = function(p250, p251, _) -- name: hit
				-- upvalues: (copy) p_u_8, (copy) v_u_11, (copy) v_u_12
				p_u_8.burst("Impact", p251, v_u_11, 1.1)
				if not p250.lite then
					p_u_8.burst("Fire", p251 - Vector3.new(0, 1.5, 0), v_u_11, 0.33)
				end
				p_u_8.glint(p251, v_u_12, 5, 0.18)
			end
		}
	}
	return v252
end