local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Bars)
local v_u_6 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v7 = require(script.Parent.Parent.Preload)
local v_u_8 = require(script.Parent.Parent.Parent.Sfx)
local v_u_9 = require(v3.Shared.Config.Textures)
v7.images({ v_u_9.AlmightyEye, v_u_9.AlmightyWisp, v_u_9.AlmightyMantle })
local v_u_10 = Color3.fromHex("6FC3FF")
local v_u_11 = Color3.fromRGB(6, 6, 12)
local v_u_12 = Color3.fromRGB(150, 195, 255)
local v_u_13 = Color3.fromRGB(255, 206, 96)
local v_u_14 = Color3.fromRGB(255, 244, 210)
local v_u_15 = Color3.new(1, 1, 1)
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = Enum.Material.Neon
local function v_u_48(p18, p19, p20, p21, p22, p23, p24, p25, p26) -- name: groundPic
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v27 = p24 + p25 + p26
	local v28 = math.max(v27, 0.05)
	local v29 = {}
	local v30 = {}
	for v31 = 0, 12 do
		local v32 = v31 / 12
		local v33 = v32 * v28
		local v34 = v33 / math.max(p24, 0.001)
		local v35 = math.clamp(v34, 0, 1) - 1
		local v36 = v35 * 2.7 * v35 * v35 + 1 + v35 * 1.7 * v35
		local v37 = (v33 - p24 - p25) / math.max(p26, 0.001)
		local v38 = math.clamp(v37, 0, 1)
		local v39 = v38 * v38 * (3 - v38 * 2)
		local v40 = NumberSequenceKeypoint.new
		local v41 = p19 + (p20 - p19) * v36 + p20 * 0.1 * v39
		local v42 = math.max(v41, 0.05) / 2
		table.insert(v30, v40(v32, v42))
		local v43 = NumberSequenceKeypoint.new
		local v44 = p23 + (1 - p23) * v39
		local v45 = math.clamp(v44, 0, 1)
		table.insert(v29, v43(v32, v45))
	end
	local v46 = Instance.new("Attachment")
	v46.WorldPosition = p18
	v46.Parent = v_u_4.Terrain
	local v47 = Instance.new("ParticleEmitter")
	v47.Enabled = false
	v47.Texture = p21
	v47.Color = ColorSequence.new(p22)
	v47.LightEmission = 0
	v47.LightInfluence = 0
	v47.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v47.EmissionDirection = Enum.NormalId.Top
	v47.SpreadAngle = Vector2.zero
	v47.Speed = NumberRange.new(0.01)
	v47.Size = NumberSequence.new(v30)
	v47.Transparency = NumberSequence.new(v29)
	v47.Lifetime = NumberRange.new(v28)
	v47.Rotation = NumberRange.new(0, 360)
	v47.Parent = v46
	v47:Emit(1)
	v_u_1:AddItem(v46, v28 + 0.2)
end
local function v_u_54(p49, p50, p51) -- name: eyeAt
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1
	local v52 = Instance.new("Attachment")
	v52.WorldPosition = p49
	v52.Parent = v_u_4.Terrain
	local v53 = Instance.new("ParticleEmitter")
	v53.Enabled = false
	v53.Texture = v_u_9.AlmightyEye
	v53.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v53.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v53.Color = ColorSequence.new(v_u_10)
	v53.LightEmission = 0.35
	v53.LightInfluence = 0
	v53.Size = NumberSequence.new(p50 / 2)
	v53.Lifetime = NumberRange.new(p51)
	v53.Speed = NumberRange.new(0)
	v53.Rotation = NumberRange.new(-10, 10)
	v53.ZOffset = 1.5
	v53.Parent = v52
	v53:Emit(1)
	v_u_1:AddItem(v52, p51 + 0.2)
end
local function v_u_69(p55, p56, p57, p58, p59, p60) -- name: smokeBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_12, (copy) v_u_1
	if p56 > 0 then
		local v61 = Instance.new("Attachment")
		v61.WorldPosition = p55
		v61.Parent = v_u_4.Terrain
		local v62 = Instance.new("ParticleEmitter")
		v62.Enabled = false
		v62.Texture = v_u_9.AlmightyWisp
		v62.Color = ColorSequence.new(v_u_12)
		v62.LightEmission = 0
		v62.LightInfluence = 0
		v62.Size = NumberSequence.new(p57 * 0.5, p57)
		v62.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.6, 0.25), NumberSequenceKeypoint.new(1, 1) })
		v62.Lifetime = NumberRange.new(p59 * 0.7, p59)
		v62.Speed = NumberRange.new(p58 * 0.5, p58)
		v62.Drag = 2.5
		v62.Rotation = NumberRange.new(0, 360)
		v62.RotSpeed = NumberRange.new(-40, 40)
		v62.Parent = v61
		if p60 then
			v62.EmissionDirection = Enum.NormalId.Front
			v62.SpreadAngle = Vector2.new(12, 4)
			for v63 = 1, 10 do
				local v64 = v63 * 3.141592653589793 * 2 / 10
				local v65 = CFrame.lookAt
				local v66 = math.cos(v64)
				local v67 = math.sin(v64)
				v61.WorldCFrame = v65(p55, p55 + Vector3.new(v66, 0.05, v67))
				local v68 = p56 / 10
				v62:Emit((math.ceil(v68)))
			end
		else
			v62.SpreadAngle = Vector2.new(180, 180)
			v62:Emit(p56)
		end
		v_u_1:AddItem(v61, p59 + 0.3)
	end
end
local function v_u_78(p70, p71, p72, p73, p74, p_u_75) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_15, (copy) v_u_1
	local v_u_76 = Instance.new("ColorCorrectionEffect")
	v_u_76.Name = "Almighty"
	v_u_76.Parent = v_u_2
	v_u_6.tween(v_u_76, p73, {
		["TintColor"] = p70,
		["Brightness"] = p71,
		["Saturation"] = p72
	})
	task.delay(p73 + p74, function()
		-- upvalues: (ref) v_u_6, (copy) v_u_76, (copy) p_u_75, (ref) v_u_15
		local v77 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_15
		}
		v_u_6.tween(v_u_76, p_u_75, v77)
	end)
	v_u_1:AddItem(v_u_76, p73 + p74 + p_u_75 + 0.1)
end
local function v_u_85(p79, p80, p81, p82) -- name: wedgePart
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	local v83 = v_u_6.part(p79, CFrame.new(0, -500, 0), p80, {
		["material"] = p81
	})
	local v84 = Instance.new("SpecialMesh")
	v84.MeshType = Enum.MeshType.Wedge
	v84.Parent = v83
	v_u_1:AddItem(v83, p82)
	return v83
end
local function v_u_116(p86, p87, p88) -- name: newBlade
	-- upvalues: (copy) v_u_85, (copy) v_u_11, (copy) v_u_16, (copy) v_u_6, (copy) v_u_10, (copy) v_u_17, (copy) v_u_1
	local v89 = p87 * 0.18
	local v_u_90 = {}
	local v_u_91 = {}
	local v92 = v_u_85
	local v93 = p87 / 2
	local v94 = v92(Vector3.new(v89, p86, v93), v_u_11, v_u_16, p88)
	local v95 = v_u_85
	local v96 = p87 / 2
	local v97 = v95(Vector3.new(v89, p86, v96), v_u_11, v_u_16, p88)
	v94.Reflectance = 0.15
	v97.Reflectance = 0.15
	table.insert(v_u_90, v94)
	local v98 = CFrame.new(0, 0, -p87 / 4) * CFrame.Angles(3.141592653589793, 0, 0) * CFrame.Angles(0, 3.141592653589793, 0)
	table.insert(v_u_91, v98)
	table.insert(v_u_90, v97)
	local v99 = CFrame.new(0, 0, p87 / 4) * CFrame.Angles(3.141592653589793, 0, 0)
	table.insert(v_u_91, v99)
	local v100 = v_u_6.part
	local v101 = v89 * 0.6
	local v102 = p86 * 0.92
	local v103 = v89 * 0.6
	local v104 = Vector3.new(v101, v102, v103)
	local v105 = {
		["material"] = v_u_17
	}
	local v106 = v100(v104, CFrame.new(0, -500, 0), v_u_10, v105)
	v_u_1:AddItem(v106, p88)
	table.insert(v_u_90, v106)
	local v107 = CFrame.new(0, p86 * 0.04, p87 * 0.27 + v89 * 0.2)
	local v108 = CFrame.Angles
	local v109 = p87 * 0.5
	local v110 = v107 * v108(math.atan2(v109, p86), 0, 0)
	table.insert(v_u_91, v110)
	return {
		["parts"] = v_u_90,
		["offs"] = v_u_91,
		["place"] = function(p111) -- name: place
			-- upvalues: (copy) v_u_90, (copy) v_u_91
			for v112, v113 in v_u_90 do
				v113.CFrame = p111 * v_u_91[v112]
			end
		end,
		["fade"] = function(p114) -- name: fade
			-- upvalues: (copy) v_u_90, (ref) v_u_6, (ref) v_u_1
			for _, v115 in v_u_90 do
				v_u_6.tween(v115, p114, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v115, p114 + 0.05)
			end
		end
	}
end
return function(p_u_117)
	-- upvalues: (copy) v_u_6, (copy) v_u_11, (copy) v_u_9, (copy) v_u_5, (copy) v_u_10, (copy) v_u_85, (copy) v_u_16, (copy) v_u_54, (copy) v_u_69, (copy) v_u_13, (copy) v_u_14, (copy) v_u_1, (copy) v_u_78, (copy) v_u_48, (copy) v_u_8, (copy) v_u_12, (copy) v_u_4, (copy) v_u_116
	local v145 = {
		["almighty_a"] = {
			["cast"] = function(p118) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (copy) p_u_117, (ref) v_u_11, (ref) v_u_16
				local v119 = p118.size
				local v120 = p118.eye + p118.dir * 1.1
				v_u_6.flash(v120, v_u_10, 2.4 * v119, 0.1)
				p_u_117.pop(v120, v_u_11, 1.4 * v119, 0.3 * v119, 0.12, 0, v_u_16)
			end,
			["beam"] = function(p121, p122, p123) -- name: shadowBlade
				-- upvalues: (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (copy) p_u_117, (ref) v_u_5, (ref) v_u_10, (ref) v_u_85, (ref) v_u_16, (ref) v_u_54, (ref) v_u_69
				local v_u_124 = p121.size
				local v125 = p123 - p122
				if v125.Magnitude < 1 then
					return
				else
					local v126 = v125.Unit
					local v127 = p122 + v126 * 0.8
					local v_u_128 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v127), v_u_11, {
						["transparency"] = 1
					})
					local v129 = Instance.new("Attachment")
					v129.Parent = v_u_128
					local v130 = Instance.new("Attachment")
					v130.Parent = v_u_128
					v130.WorldPosition = p123
					local v_u_131 = Instance.new("Beam")
					v_u_131.Attachment0 = v129
					v_u_131.Attachment1 = v130
					v_u_131.Texture = v_u_9.AlmightyMantle
					v_u_131.TextureMode = Enum.TextureMode.Wrap
					v_u_131.TextureLength = 6
					v_u_131.TextureSpeed = 5
					v_u_131.Color = ColorSequence.new(v_u_11)
					v_u_131.LightEmission = 0
					v_u_131.LightInfluence = 0
					v_u_131.FaceCamera = true
					v_u_131.Segments = 1
					v_u_131.Parent = v_u_128
					p_u_117.animate(0.28, 0, function(p132)
						-- upvalues: (copy) v_u_124, (copy) v_u_131, (copy) v_u_128
						local v133 = 1.9 * v_u_124 * (1 - p132 * p132)
						v_u_131.Width0 = v133
						v_u_131.Width1 = v133 * 0.3
						local v134 = v_u_131
						local v135 = NumberSequence.new
						local v136 = (p132 - 0.3) / 0.7
						local v137 = math.clamp(v136, 0, 1)
						v134.Transparency = v135(v137 * v137 * (3 - v137 * 2))
						if p132 >= 1 then
							v_u_128:Destroy()
						end
					end)
					v_u_5.thin(v_u_5.rod(v127, p123, 0.12 * v_u_124, v_u_10), 0.22)
					if not p121.lite then
						local v138 = v_u_85
						local v139 = 0.3 * v_u_124
						local v140 = 2.2 * v_u_124
						local v141 = 0.9 * v_u_124
						local v142 = v138(Vector3.new(v139, v140, v141), v_u_11, v_u_16, 0.4)
						v142.CFrame = CFrame.lookAt(p123, p123 + v126) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.new(0, -0.6 * v_u_124, 0)
						v_u_6.tween(v142, 0.3, {
							["Transparency"] = 1
						})
						v_u_54(p122:Lerp(p123, 0.3) + Vector3.new(0, 0.4, 0) * v_u_124, 1.6 * v_u_124, 0.45)
						v_u_54(p122:Lerp(p123, 0.6499999999999999) + Vector3.new(0, 0.4, 0) * v_u_124, 1.6 * v_u_124, 0.45)
						v_u_69(p122:Lerp(p123, 0.5), 2, 2.4 * v_u_124, 4, 0.7, false)
					end
				end
			end,
			["hit"] = function(p143, p144, _) -- name: hit
				-- upvalues: (copy) p_u_117, (ref) v_u_10, (ref) v_u_54, (ref) v_u_69
				p_u_117.beamHitSound(p143, p144, "Hit")
				p_u_117.burst("Impact", p144, v_u_10, 0.5)
				if not p143.lite then
					v_u_54(p144 + Vector3.new(0, 0.6, 0), 2.2, 0.55)
					v_u_69(p144, 2, 2, 5, 0.6, false)
				end
			end
		}
	}
	local v_u_146 = {}
	setmetatable(v_u_146, {
		["__mode"] = "k"
	})
	local function v_u_161(p_u_147, p_u_148) -- name: drain
		-- upvalues: (copy) p_u_117, (ref) v_u_5, (ref) v_u_13, (ref) v_u_14, (ref) v_u_9, (ref) v_u_6, (ref) v_u_1
		local v_u_149 = p_u_147.size
		local v150 = p_u_117.ground(p_u_148, 0)
		v_u_5.thin(v_u_5.rod(v150, v150 + Vector3.new(0, 16, 0) * v_u_149, 2.4 * v_u_149, v_u_13, 0.35), 0.7)
		p_u_117.glowBeam(v150, v150 + Vector3.new(0, 24, 0) * v_u_149, v_u_14, 3 * v_u_149, 0.6, v_u_9.Beam)
		v_u_6.ring(v150, v_u_13, 4 * v_u_149, 0.4, v_u_9.Ring)
		p_u_117.after(0.22, function()
			-- upvalues: (ref) v_u_6, (copy) v_u_149, (copy) p_u_148, (ref) v_u_14, (ref) v_u_1, (ref) p_u_117, (ref) v_u_13, (copy) p_u_147
			local v_u_151 = v_u_6.part(Vector3.new(0.9, 0.9, 0.9) * v_u_149, CFrame.new(p_u_148), v_u_14, {
				["shape"] = Enum.PartType.Ball
			})
			v_u_1:AddItem(v_u_151, 1.2)
			p_u_117.streak(v_u_151, v_u_13, v_u_14, 0.8 * v_u_149, 0.3)
			local v_u_152 = p_u_148 + Vector3.new(0, 1.5, 0)
			local v_u_153 = Vector3.new(0, 1, 0) * (5 + math.random() * 4) * v_u_149
			p_u_117.animate(0.5, 0, function(p154)
				-- upvalues: (ref) p_u_147, (copy) v_u_152, (copy) v_u_153, (copy) v_u_151, (ref) v_u_6, (ref) v_u_13, (ref) v_u_149
				local v155 = p_u_147
				local v156 = v155.caster
				if v156 then
					v156 = v155.caster.Character
				end
				if v156 then
					v156 = v156:FindFirstChild("HumanoidRootPart")
				end
				local v157
				if v156 and v156:IsA("BasePart") then
					v157 = v156.Position + Vector3.new(0, 0.8, 0)
				else
					v157 = v155.origin
				end
				local v158 = p154 * p154
				local v159 = v_u_152:Lerp(v157, 0.5) + v_u_153
				local v160 = v_u_152:Lerp(v159, v158):Lerp(v159:Lerp(v157, v158), v158)
				v_u_151.CFrame = CFrame.new(v160)
				if p154 >= 1 then
					v_u_6.flash(v157, v_u_13, 3 * v_u_149, 0.15)
					v_u_151:Destroy()
				end
			end)
		end)
	end
	v145.almighty_e = {
		["cast"] = function(p162) -- name: cast
			-- upvalues: (copy) p_u_117, (ref) v_u_10, (ref) v_u_54, (ref) v_u_78
			local v163 = p162.size
			p_u_117.skillCast(p162, v_u_10, false, true)
			v_u_54(p162.eye + p162.dir * 1.5 + Vector3.new(0, 0.5, 0), 2.4 * v163, 0.6)
			if p162.mine then
				v_u_78(Color3.fromRGB(205, 215, 240), -0.03, -0.25, 0.15, 1.1, 0.5)
			end
		end,
		["windup"] = function(p164, p165, p166) -- name: windup
			-- upvalues: (copy) p_u_117, (ref) v_u_48, (ref) v_u_9, (ref) v_u_11, (ref) v_u_69
			local v167 = p164.size
			local v168 = p164.ability.radius * v167
			local v169 = p_u_117.ground(p165, 0.1)
			local v170 = math.max(p166, 0.1)
			v_u_48(v169, v168 * 0.3, v168 * 2.2, v_u_9.Glow, v_u_11, 0.05, v170 + 0.3, 1.2, 0.6)
			v_u_69(v169 + Vector3.new(0, 0.6, 0), p164.lite and 6 or 20, 4 * v167, v168 * 1.6, 1.4, true)
		end,
		["land"] = function(p_u_171, p172) -- name: land
			-- upvalues: (copy) p_u_117, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (ref) v_u_54, (ref) v_u_8, (ref) v_u_13, (ref) v_u_10
			local v_u_173 = p_u_171.size
			local v174 = p_u_171.ability.radius * v_u_173
			local v175 = p_u_117.ground(p172, 0.1)
			v_u_6.ring(v175, v_u_11, v174 * 1.1, 0.5, v_u_9.Shockwave)
			if not p_u_171.lite then
				for _ = 1, 10 do
					local v176 = math.random() * 3.141592653589793 * 2
					local v177 = v174 * (0.25 + math.random() * 0.7)
					local v178 = math.cos(v176) * v177
					local v179 = 0.8 + math.random() * 1.5
					local v180 = math.sin(v176) * v177
					local v_u_181 = v175 + Vector3.new(v178, v179, v180)
					p_u_117.after(math.random() * 0.4, function()
						-- upvalues: (ref) v_u_54, (copy) v_u_181, (copy) v_u_173
						v_u_54(v_u_181, (2.4 + math.random() * 1.4) * v_u_173, 1.1)
					end)
				end
			end
			v_u_8.play("Bind", {
				["at"] = v175,
				["volume"] = p_u_171.mine and 0.8 or 0.45
			})
			p_u_117.after(0.8, function()
				-- upvalues: (copy) p_u_171, (ref) v_u_6, (ref) v_u_13, (copy) v_u_173, (ref) v_u_9, (ref) v_u_10, (ref) p_u_117, (ref) v_u_8
				local v182 = p_u_171
				local v183 = v182.caster
				if v183 then
					v183 = v182.caster.Character
				end
				if v183 then
					v183 = v183:FindFirstChild("HumanoidRootPart")
				end
				local v184
				if v183 and v183:IsA("BasePart") then
					v184 = v183.Position + Vector3.new(0, 0.8, 0)
				else
					v184 = v182.origin
				end
				v_u_6.flash(v184, v_u_13, 7 * v_u_173, 0.3)
				v_u_6.ring(p_u_171.feet, v_u_13, 9 * v_u_173, 0.5, v_u_9.Ring)
				v_u_6.ring(p_u_171.feet, v_u_10, 6 * v_u_173, 0.4, v_u_9.Shockwave)
				p_u_117.burst("Flash", v184, v_u_10, 0.3)
				v_u_8.play("Crit", {
					["at"] = v184,
					["volume"] = p_u_171.mine and 0.6 or 0.3
				})
				if p_u_171.mine then
					v_u_6.shake(0.2, 0.2)
				end
			end)
		end,
		["hit"] = function(p185, p186, _) -- name: hit
			-- upvalues: (copy) p_u_117, (ref) v_u_13, (copy) v_u_146, (copy) v_u_161
			p_u_117.burst("Impact", p186, v_u_13, 0.6)
			local v187 = (v_u_146[p185] or 0) + 1
			v_u_146[p185] = v187
			if (p185.lite and 3 or 10) >= v187 then
				v_u_161(p185, p186)
			end
		end
	}
	local v_u_188 = {}
	setmetatable(v_u_188, {
		["__mode"] = "k"
	})
	v145.almighty_r = {
		["cast"] = function(p189) -- name: cast
			-- upvalues: (copy) p_u_117, (ref) v_u_10, (ref) v_u_54, (ref) v_u_6
			local v190 = p189.size
			p_u_117.skillCast(p189, v_u_10, true, true)
			v_u_54(p189.eye + p189.dir * 1.5 + Vector3.new(0, 0.6, 0), 3 * v190, 0.7)
			if p189.mine then
				v_u_6.shake(0.12, 0.15)
			end
		end,
		["windup"] = function(p_u_191, p192, p193) -- name: windup
			-- upvalues: (copy) p_u_117, (copy) v_u_188, (ref) v_u_6, (ref) v_u_11, (ref) v_u_1, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (ref) v_u_4, (ref) v_u_48, (ref) v_u_8, (ref) v_u_78, (ref) v_u_69
			local v_u_194 = p_u_191.size
			local v_u_195 = p_u_191.lite
			local v_u_196 = p_u_191.ability.radius * v_u_194
			local v_u_197 = p_u_117.ground(p192, 0)
			local v198 = 24 * v_u_194
			v_u_188[p_u_191] = {
				["height"] = v198
			}
			task.delay(p193 + 1, function()
				-- upvalues: (ref) v_u_188, (copy) p_u_191
				v_u_188[p_u_191] = nil
			end)
			local v199 = v_u_197 + Vector3.new(0, 1, 0) * v198
			local v200 = p193 + 0.4
			local v201 = v_u_6.part
			local v202 = v_u_196 * 2.2
			local v203 = v_u_196 * 2.2
			local v204 = v201(Vector3.new(v202, 3, v203), CFrame.new(v199), v_u_11, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v204, v200 + 3)
			local v_u_205 = Instance.new("ParticleEmitter")
			v_u_205.Texture = v_u_9.FxSmoke
			v_u_205.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_205.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v_u_205.FlipbookFramerate = NumberRange.new(0)
			v_u_205.FlipbookStartRandom = true
			v_u_205.Color = ColorSequence.new(v_u_11)
			v_u_205.LightEmission = 0
			v_u_205.LightInfluence = 0
			v_u_205.Size = NumberSequence.new(6 * v_u_194, 11 * v_u_194)
			v_u_205.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.2, 0.15),
				NumberSequenceKeypoint.new(0.8, 0.2),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_205.Lifetime = NumberRange.new(1.4, 2)
			v_u_205.Speed = NumberRange.new(0.5, 2)
			v_u_205.SpreadAngle = Vector2.new(180, 180)
			v_u_205.Rotation = NumberRange.new(0, 360)
			v_u_205.RotSpeed = NumberRange.new(-20, 20)
			v_u_205.Shape = Enum.ParticleEmitterShape.Box
			v_u_205.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_205.Rate = v_u_195 and 14 or 40
			v_u_205.Parent = v204
			v_u_205:Emit(v_u_195 and 8 or 24)
			local v_u_206 = Instance.new("ParticleEmitter")
			v_u_206.Texture = v_u_9.AlmightyWisp
			v_u_206.Color = ColorSequence.new(v_u_12)
			v_u_206.LightEmission = 0
			v_u_206.LightInfluence = 0
			v_u_206.Size = NumberSequence.new(5 * v_u_194, 8 * v_u_194)
			v_u_206.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.25, 0.1), NumberSequenceKeypoint.new(1, 1) })
			v_u_206.Lifetime = NumberRange.new(1.2, 1.8)
			v_u_206.Speed = NumberRange.new(1, 3)
			v_u_206.SpreadAngle = Vector2.new(180, 180)
			v_u_206.Rotation = NumberRange.new(0, 360)
			v_u_206.RotSpeed = NumberRange.new(-30, 30)
			v_u_206.Shape = Enum.ParticleEmitterShape.Box
			v_u_206.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_206.Rate = v_u_195 and 0 or 10
			v_u_206.Parent = v204
			local v_u_207 = Instance.new("ParticleEmitter")
			v_u_207.Texture = v_u_9.AlmightyEye
			v_u_207.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_207.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_207.Color = ColorSequence.new(v_u_10)
			v_u_207.LightEmission = 0.4
			v_u_207.LightInfluence = 0
			v_u_207.Size = NumberSequence.new(1.6 * v_u_194, 2.6 * v_u_194)
			v_u_207.Lifetime = NumberRange.new(1, 1.5)
			v_u_207.Speed = NumberRange.new(0)
			v_u_207.Rotation = NumberRange.new(-15, 15)
			v_u_207.ZOffset = 2
			v_u_207.Shape = Enum.ParticleEmitterShape.Box
			v_u_207.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_207.Rate = v_u_195 and 4 or 16
			v_u_207.Parent = v204
			p_u_117.after(v200, function()
				-- upvalues: (copy) v_u_205, (copy) v_u_206, (copy) v_u_207
				v_u_205.Enabled = false
				v_u_206.Enabled = false
				v_u_207.Enabled = false
			end)
			local v208 = Instance.new("Attachment")
			v208.WorldPosition = v199 - Vector3.new(0, 1.5, 0)
			v208.Parent = v_u_4.Terrain
			local v209 = Instance.new("ParticleEmitter")
			v209.Enabled = false
			v209.Texture = v_u_9.AlmightyEye
			v209.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v209.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v209.Color = ColorSequence.new(v_u_10)
			v209.LightEmission = 0.5
			v209.LightInfluence = 0
			v209.Size = NumberSequence.new(v_u_196 * 0.42)
			v209.Lifetime = NumberRange.new(v200 + 0.6)
			v209.Speed = NumberRange.new(0)
			v209.ZOffset = 3
			v209.Parent = v208
			v209:Emit(1)
			v_u_1:AddItem(v208, v200 + 1)
			v_u_48(v_u_197 + Vector3.new(0, 0.1, 0), v_u_196 * 0.4, v_u_196 * 2.5, v_u_9.Glow, v_u_11, 0.1, 0.35, p193, 0.6)
			v_u_6.flash(v199, v_u_10, v_u_196 * 0.6, 0.3)
			v_u_8.play("EyeActivate", {
				["at"] = v_u_197,
				["volume"] = p_u_191.mine and 0.6 or 0.3
			})
			if p_u_191.mine then
				v_u_78(Color3.fromRGB(175, 190, 230), -0.08, -0.45, 0.25, p193, 0.6)
			end
			p_u_117.after(v200, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_197, (ref) v_u_11, (copy) v_u_196, (ref) v_u_9, (ref) v_u_69, (copy) v_u_195, (copy) v_u_194
				v_u_6.ring(v_u_197, v_u_11, v_u_196 * 1.3, 0.6, v_u_9.Shockwave)
				v_u_69(v_u_197 + Vector3.new(0, 1, 0), v_u_195 and 4 or 14, 5 * v_u_194, v_u_196, 1.2, true)
			end)
		end,
		["strike"] = function(p_u_210, p211, p212) -- name: strike
			-- upvalues: (copy) v_u_188, (copy) p_u_117, (ref) v_u_116, (ref) v_u_69, (ref) v_u_48, (ref) v_u_9, (ref) v_u_11, (ref) v_u_54, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8
			local v_u_213 = p_u_210.size
			local v214 = v_u_188[p_u_210]
			local v_u_215
			if v214 then
				v_u_215 = v214.height
			else
				v_u_215 = 24 * v_u_213
			end
			local v_u_216 = p_u_117.ground(p211, 0)
			local v_u_217 = 9 * v_u_213
			local v218 = p_u_117.after
			local v219 = p212 - 0.16
			v218(math.max(v219, 0), function()
				-- upvalues: (ref) v_u_116, (copy) v_u_217, (copy) v_u_213, (copy) v_u_216, (copy) v_u_215, (ref) p_u_117, (ref) v_u_69, (copy) p_u_210, (ref) v_u_48, (ref) v_u_9, (ref) v_u_11, (ref) v_u_54, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8
				local v_u_220 = v_u_116(v_u_217, 2.2 * v_u_213, 1.5599999999999998)
				local v_u_221 = v_u_216 + Vector3.new(0, 1, 0) * v_u_215
				local v_u_222 = CFrame.Angles(0, math.random() * 3.141592653589793, 0)
				p_u_117.animate(0.16, 0, function(p223)
					-- upvalues: (copy) v_u_221, (ref) v_u_216, (copy) v_u_220, (ref) v_u_217, (copy) v_u_222, (ref) v_u_69, (ref) p_u_210, (ref) v_u_213, (ref) v_u_48, (ref) v_u_9, (ref) v_u_11, (ref) v_u_54, (ref) p_u_117, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8
					local v224 = v_u_221:Lerp(v_u_216, p223 * p223)
					v_u_220.place(CFrame.new(v224 + Vector3.new(0, 1, 0) * v_u_217 * 0.5) * v_u_222)
					if p223 >= 1 then
						v_u_220.place(CFrame.new(v_u_216 + Vector3.new(0, 1, 0) * v_u_217 * 0.32) * v_u_222 * CFrame.Angles(0.12, 0, 0.08))
						v_u_69(v_u_216 + Vector3.new(0, 0.6, 0), p_u_210.lite and 2 or 6, 3.2 * v_u_213, 9 * v_u_213, 0.8, true)
						v_u_48(v_u_216 + Vector3.new(0, 0.12, 0), 1 * v_u_213, 7 * v_u_213, v_u_9.Glow, v_u_11, 0.1, 0.12, 0.5, 0.5)
						if not p_u_210.lite then
							v_u_54(v_u_216 + Vector3.new(0, 2.2, 0) * v_u_213, 3.4 * v_u_213, 0.9)
							local v225 = { v_u_11, v_u_12 }
							p_u_117.chunks(v_u_216, v225, 3, 14 * v_u_213, 0.4 * v_u_213, 0.7, false, 0.6)
						end
						p_u_117.burst("Impact", v_u_216 + Vector3.new(0, 1, 0), v_u_10, 0.7)
						v_u_6.ring(v_u_216 + Vector3.new(0, 0.1, 0), v_u_11, 5 * v_u_213, 0.35, v_u_9.Shockwave)
						if p_u_210.mine then
							local v226 = {
								["at"] = nil,
								["volume"] = 0.45,
								["at"] = v_u_216
							}
							v_u_8.play("Hit", v226)
							v_u_6.shake(0.12, 0.1)
						end
						p_u_117.after(0.55, function()
							-- upvalues: (ref) v_u_220, (ref) p_u_210, (ref) v_u_69, (ref) v_u_216, (ref) v_u_217, (ref) v_u_213
							v_u_220.fade(0.4)
							if not p_u_210.lite then
								v_u_69(v_u_216 + Vector3.new(0, 1, 0) * v_u_217 * 0.4, 3, 3 * v_u_213, 3, 0.9, false)
							end
						end)
					end
				end)
			end)
		end,
		["hit"] = function(p227, p228, _) -- name: hit
			-- upvalues: (copy) p_u_117, (ref) v_u_10, (ref) v_u_69
			p_u_117.burst("Impact", p228, v_u_10, 0.8)
			if not p227.lite then
				v_u_69(p228, 1, 2.2, 3, 0.5, false)
			end
		end
	}
	return v145
end