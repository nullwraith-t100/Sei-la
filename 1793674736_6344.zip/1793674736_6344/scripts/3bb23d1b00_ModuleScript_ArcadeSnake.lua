local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.ArcadeKit)
local v_u_3 = require(script.Parent.Sfx)
local v_u_4 = require(script.Parent.State)
local v5 = v1.Shared
local v_u_6 = require(v5.Logic.Snake)
require(v5.Logic.ArcadeLog)
local v_u_7 = require(v5.Config.Eyes)
local v_u_8 = require(v5.Config.Images)
local v9 = {
	["KEYS"] = {
		[Enum.KeyCode.W] = "up",
		[Enum.KeyCode.Up] = "up",
		[Enum.KeyCode.DPadUp] = "up",
		[Enum.KeyCode.S] = "down",
		[Enum.KeyCode.Down] = "down",
		[Enum.KeyCode.DPadDown] = "down",
		[Enum.KeyCode.A] = "left",
		[Enum.KeyCode.Left] = "left",
		[Enum.KeyCode.DPadLeft] = "left",
		[Enum.KeyCode.D] = "right",
		[Enum.KeyCode.Right] = "right",
		[Enum.KeyCode.DPadRight] = "right"
	}
}
local v_u_10 = {
	["up"] = v_u_6.UP,
	["right"] = v_u_6.RIGHT,
	["down"] = v_u_6.DOWN,
	["left"] = v_u_6.LEFT
}
local v_u_11 = {}
local v_u_12 = {
	0,
	1,
	0,
	-1
}
local v_u_13 = {
	-1,
	0,
	1,
	0
}
for _, v14 in v_u_7.list do
	local v15 = v_u_8.Iris[v14.id]
	if not v15 or ((v14.world or 1) ~= 1 or (v14.pass or v14.reissueOf)) then
		continue
	end
	local v16 = {
		["image"] = v15,
		["color"] = Color3.fromHex(v14.color)
	}
	table.insert(v_u_11, v16)
end
local v_u_17 = {
	v_u_2.WHITE,
	v_u_2.CYAN,
	v_u_2.GREEN,
	v_u_2.GOLD,
	Color3.fromRGB(255, 120, 60)
}
local function v_u_25(p18, p19, p20, p21, p22) -- name: circle
	local v23 = Instance.new("Frame")
	v23.Name = p19
	v23.BackgroundColor3 = p20
	v23.BorderSizePixel = 0
	v23.AnchorPoint = Vector2.new(0.5, 0.5)
	v23.Position = UDim2.fromScale(0.5, 0.5)
	v23.Size = UDim2.fromScale(p21, p21)
	v23.ZIndex = p22
	local v24 = Instance.new("UICorner")
	v24.CornerRadius = UDim.new(1, 0)
	v24.Parent = v23
	v23.Parent = p18
	return v23
end
function v9.new(p26, p27, p28, p29, p30, p_u_31) -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_2, (copy) v_u_25, (copy) v_u_11, (copy) v_u_3, (copy) v_u_17, (copy) v_u_10, (copy) v_u_12, (copy) v_u_13
	local v_u_32 = v_u_6.new(p26)
	local v_u_33 = v_u_32.w
	local v_u_34 = v_u_32.h
	local v_u_35 = table.clone(v_u_32.body)
	local v36 = v_u_7.byId[v_u_4.string("Eye", v_u_7.STARTER)] or v_u_7.byId[v_u_7.STARTER]
	local v_u_37 = Color3.fromHex(v36.color)
	local v_u_38 = Color3.fromHex(v36.color2)
	local v39 = v_u_8.Iris[v36.id] or v_u_8.Iris[v_u_7.STARTER]
	local v_u_40 = v_u_2.box(p27, "Board", v_u_2.BOARD, 0)
	v_u_40.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_40.Position = UDim2.fromScale(0.5, 0.5)
	v_u_40.Size = UDim2.fromScale(1, 1)
	v_u_40.ClipsDescendants = false
	local v41 = Instance.new("UIAspectRatioConstraint")
	v41.AspectRatio = v_u_33 / v_u_34
	v41.Parent = v_u_40
	local v42 = Instance.new("UIStroke")
	v42.Thickness = 4
	v42.Color = Color3.new(0, 0, 0)
	v42.Parent = v_u_40
	local v43 = Instance.new("UIStroke")
	v43.Name = "Glow"
	v43.Thickness = 2
	v43.Color = v_u_37
	v43.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v43.Transparency = 0.3
	v43.Parent = v_u_40
	local v_u_44 = 0
	local v_u_45 = {}
	local v_u_46 = true
	for v47 = 1, v_u_34 do
		for v48 = 1, v_u_33 do
			if (v48 + v47) % 2 ~= 0 then
				continue
			end
			local v49 = Instance.new("Frame")
			v49.Name = "Check"
			v49.BorderSizePixel = 0
			v49.BackgroundColor3 = Color3.fromRGB(32, 36, 60)
			v49.BackgroundTransparency = 0.35
			v49.Position = UDim2.fromScale((v48 - 1) / v_u_33, (v47 - 1) / v_u_34)
			v49.Size = UDim2.fromScale(1 / v_u_33, 1 / v_u_34)
			v49.ZIndex = 2
			v49.Parent = v_u_40
		end
	end
	local function v58(p50, p51, p52) -- name: orbView
		-- upvalues: (copy) v_u_33, (copy) v_u_34, (ref) v_u_25, (ref) v_u_2, (copy) v_u_40
		local v53 = Instance.new("Frame")
		v53.Name = p50
		v53.BackgroundTransparency = 1
		v53.AnchorPoint = Vector2.new(0.5, 0.5)
		v53.Size = UDim2.fromScale(1.15 / v_u_33, 1.15 / v_u_34)
		v53.ZIndex = 5
		v53.Visible = false
		local v54 = v_u_25(v53, "Halo", p51, 1.25, 5)
		v54.BackgroundTransparency = 0.55
		local v55 = v_u_25(v53, "Ball", v_u_2.WHITE, 0.95, 6)
		local v56 = Instance.new("UIStroke")
		v56.Thickness = 2
		v56.Color = Color3.new(0, 0, 0)
		v56.Parent = v55
		local v57 = Instance.new("ImageLabel")
		v57.Name = "Iris"
		v57.BackgroundTransparency = 1
		v57.AnchorPoint = Vector2.new(0.5, 0.5)
		v57.Position = UDim2.fromScale(0.5, 0.5)
		v57.Size = UDim2.fromScale(0.82, 0.82)
		v57.Image = p52
		v57.ZIndex = 7
		v57.Parent = v55
		v53.Parent = v_u_40
		return v53, v54, v57
	end
	local v59 = "Orb"
	local v60 = v_u_2.CYAN
	local v61
	if v_u_11[1] then
		v61 = v_u_11[1].image or v39
	else
		v61 = v39
	end
	local v_u_62, v_u_63, v_u_64 = v58(v59, v60, v61)
	local v_u_65, v_u_66, v_u_67 = v58("Golden", v_u_2.GOLD, v_u_8.Icon.Star)
	local v68 = v_u_65:FindFirstChild("Ball")
	if v68 and v68:IsA("Frame") then
		v68.BackgroundColor3 = v_u_2.GOLD
	end
	local v_u_69 = 0
	local v_u_70 = 0
	local function v_u_85() -- name: placeOrbs
		-- upvalues: (copy) v_u_32, (ref) v_u_69, (copy) v_u_62, (ref) v_u_11, (copy) v_u_64, (copy) v_u_63, (ref) v_u_6, (copy) v_u_33, (copy) v_u_34, (ref) v_u_2, (ref) v_u_70, (copy) v_u_65
		if v_u_32.orb ~= v_u_69 then
			v_u_69 = v_u_32.orb
			v_u_62.Visible = v_u_32.orb ~= 0
			if v_u_32.orb ~= 0 then
				local v71 = v_u_11
				local v72 = math.random
				local v73 = #v_u_11
				local v74 = v71[v72(1, (math.max(v73, 1)))]
				if v74 then
					v_u_64.Image = v74.image
					v_u_63.BackgroundColor3 = v74.color
				end
				local v75 = v_u_62
				local v76 = v_u_32.orb
				local v77, v78 = v_u_6.xyOf(v_u_32, v76)
				v75.Position = UDim2.fromScale((v77 - 0.5) / v_u_33, (v78 - 0.5) / v_u_34)
				local v79 = v_u_2.scaleNamed(v_u_62, "Bump")
				v79.Scale = 0
				v_u_2.tween(v79, 0.3, {
					["Scale"] = 1
				}, Enum.EasingStyle.Back)
			end
		end
		if v_u_32.golden ~= v_u_70 then
			v_u_70 = v_u_32.golden
			v_u_65.Visible = v_u_32.golden ~= 0
			if v_u_32.golden ~= 0 then
				local v80 = v_u_65
				local v81 = v_u_32.golden
				local v82, v83 = v_u_6.xyOf(v_u_32, v81)
				v80.Position = UDim2.fromScale((v82 - 0.5) / v_u_33, (v83 - 0.5) / v_u_34)
				local v84 = v_u_2.scaleNamed(v_u_65, "Bump")
				v84.Scale = 0
				v_u_2.tween(v84, 0.35, {
					["Scale"] = 1
				}, Enum.EasingStyle.Back)
			end
		end
	end
	v_u_85()
	local v_u_86 = {}
	local v_u_87 = v_u_25(v_u_40, "Head", v_u_2.WHITE, 1, 12)
	v_u_87.Size = UDim2.fromScale(1.08 / v_u_33, 1.08 / v_u_34)
	local v88 = Instance.new("UIStroke")
	v88.Thickness = 2.5
	v88.Color = Color3.new(0, 0, 0)
	v88.Parent = v_u_87
	local v_u_89 = Instance.new("ImageLabel")
	v_u_89.Name = "Iris"
	v_u_89.BackgroundTransparency = 1
	v_u_89.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_89.Size = UDim2.fromScale(0.78, 0.78)
	v_u_89.Position = UDim2.fromScale(0.5, 0.5)
	v_u_89.Image = v39
	v_u_89.ZIndex = 13
	v_u_89.Parent = v_u_87
	local function v_u_95(p90) -- name: segment
		-- upvalues: (copy) v_u_86, (copy) v_u_33, (copy) v_u_34, (copy) v_u_40
		local v91 = v_u_86[p90]
		if v91 then
			return v91
		end
		local v92 = Instance.new("Frame")
		v92.Name = "Body"
		v92.BorderSizePixel = 0
		v92.AnchorPoint = Vector2.new(0.5, 0.5)
		v92.Size = UDim2.fromScale(0.86 / v_u_33, 0.86 / v_u_34)
		v92.ZIndex = 10
		local v93 = Instance.new("UICorner")
		v93.CornerRadius = UDim.new(0.38, 0)
		v93.Parent = v92
		local v94 = Instance.new("UIStroke")
		v94.Thickness = 2
		v94.Color = Color3.new(0, 0, 0)
		v94.Parent = v92
		v92.Parent = v_u_40
		v_u_86[p90] = v92
		return v92
	end
	local v_u_96 = v_u_2.label(p29, "Combo", "", UDim2.fromScale(0.78, 0.16), UDim2.fromScale(0.5, 0.35), v_u_2.GOLD, 3)
	local v_u_97 = v_u_2.label(p29, "Orbs", "ORBS 0", UDim2.fromScale(1, 0.1), UDim2.fromScale(0.5, 0.55), v_u_2.WHITE, 2)
	local v_u_98 = (-1 / 0)
	local function v_u_129(p99) -- name: draw
		-- upvalues: (copy) v_u_32, (ref) v_u_35, (ref) v_u_6, (copy) v_u_33, (copy) v_u_34, (copy) v_u_87, (copy) v_u_89, (copy) v_u_95, (copy) v_u_37, (copy) v_u_38, (copy) v_u_86, (copy) v_u_63, (copy) v_u_64, (copy) v_u_67, (copy) v_u_66, (ref) v_u_98, (copy) v_u_96
		local v100 = #v_u_32.body
		local v101 = math.clamp(p99, 0, 1)
		for v102 = 1, v100 do
			local v103 = v_u_35[v102] or v_u_35[#v_u_35]
			local v104 = v_u_32.body[v102]
			local v105, v106 = v_u_6.xyOf(v_u_32, v103)
			local v107, v108 = v_u_6.xyOf(v_u_32, v104)
			local v109 = v105 + (v107 - v105) * v101
			local v110 = v106 + (v108 - v106) * v101
			local v111 = UDim2.fromScale((v109 - 0.5) / v_u_33, (v110 - 0.5) / v_u_34)
			if v102 == 1 then
				v_u_87.Position = v111
				local v112 = v107 - v105
				local v113 = v108 - v106
				v_u_89.Position = UDim2.fromScale(0.5 + v112 * 0.1, 0.5 + v113 * 0.1)
			else
				local v114 = v_u_95(v102)
				v114.Visible = true
				v114.Position = v111
				local v115 = v102 - 2
				local v116 = v100 - 2
				local v117 = v115 / math.max(v116, 1)
				v114.BackgroundColor3 = v_u_37:Lerp(v_u_38, v117)
				local v118 = 0.86 - v117 * 0.22
				v114.Size = UDim2.fromScale(v118 / v_u_33, v118 / v_u_34)
			end
		end
		for v119 = v100 + 1, #v_u_86 do
			if not v_u_86[v119] then
				continue
			end
			v_u_86[v119].Visible = false
		end
		local v120 = os.clock()
		local v121 = v_u_63
		local v122 = UDim2.fromScale
		local v123 = v120 * 5
		local v124 = math.sin(v123) * 0.12 + 1.25
		local v125 = v120 * 5
		v121.Size = v122(v124, math.sin(v125) * 0.12 + 1.25)
		v_u_64.Rotation = v120 * 40 % 360
		v_u_67.Rotation = v120 * 120 % 360
		if v_u_32.golden ~= 0 then
			local v126 = v_u_66
			local v127
			if v_u_32.goldenUntil - v_u_32.time < 2 then
				local v128 = v120 * 8
				v127 = math.floor(v128) % 2 == 0 and 0.9 or 0.4
			else
				v127 = 0.4
			end
			v126.BackgroundTransparency = v127
		end
		if v120 - v_u_98 > 2.2 and v_u_96.Text ~= "" then
			v_u_96.Text = ""
		end
	end
	local function v_u_152() -- name: onEvents
		-- upvalues: (copy) v_u_32, (ref) v_u_6, (copy) v_u_33, (copy) v_u_34, (copy) v_u_40, (ref) v_u_2, (copy) v_u_63, (ref) v_u_3, (copy) v_u_87, (copy) v_u_96, (ref) v_u_17, (ref) v_u_98, (copy) v_u_97
		for _, v130 in v_u_32.events do
			local v131, v132 = v_u_6.xyOf(v_u_32, v130.cell)
			local v133 = UDim2.fromScale((v131 - 0.5) / v_u_33, (v132 - 0.5) / v_u_34)
			local v134 = v_u_40.AbsoluteSize.X / v_u_33
			if v130.kind == "eat" then
				v_u_2.burst(v_u_40, v133, v134, v_u_63.BackgroundColor3)
				local v135 = v_u_2.float
				local v136 = v_u_40
				local v137 = "+" .. v130.points
				local v138 = v_u_2.WHITE
				local v139 = v134 * 0.9
				v135(v136, v137, v138, v133, (math.max(16, v139)))
				v_u_3.play("Gain", {
					["volume"] = 3.5,
					["pitch"] = nil,
					["pitch"] = 1 + 0.12 * (v130.combo - 1)
				})
			elseif v130.kind == "golden" then
				v_u_2.burst(v_u_40, v133, v134 * 1.4, v_u_2.GOLD)
				v_u_2.sparks(v_u_40, v133, v134, v_u_2.GOLD, 12)
				local v140 = v_u_2.float
				local v141 = v_u_40
				local v142 = "+" .. v130.points
				local v143 = v_u_2.GOLD
				local v144 = v134 * 1.2
				v140(v141, v142, v143, v133, (math.max(20, v144)))
				v_u_3.play("Coin", {
					["volume"] = 2
				})
			elseif v130.kind == "spawn" then
				v_u_3.play("ItemDrop", {
					["volume"] = 0.5
				})
			elseif v130.kind == "over" then
				v_u_87.BackgroundColor3 = v_u_2.RED
				local v145 = v_u_2.shake
				local v146 = v_u_40
				local v147 = v134 * 0.4
				v145(v146, math.max(6, v147), 0.35)
				v_u_3.play("Hurt")
			end
			if (v130.kind == "eat" or v130.kind == "golden") and v130.combo >= 2 then
				v_u_96.Text = "COMBO x" .. v130.combo .. "!"
				local v148 = v_u_96
				local v149 = v_u_17
				local v150 = v130.combo
				local v151 = #v_u_17
				v148.TextColor3 = v149[math.min(v150, v151)]
				v_u_98 = os.clock()
				v_u_2.bump(v_u_96, 0.4)
			end
			if v130.kind ~= "eat" and v130.kind ~= "golden" then
				continue
			end
			v_u_97.Text = "ORBS " .. v_u_32.orbs + v_u_32.goldens
			v_u_2.bump(v_u_97, 0.2)
		end
	end
	local function v_u_156(p153) -- name: turn
		-- upvalues: (ref) v_u_46, (copy) p_u_31, (ref) v_u_6, (copy) v_u_32, (copy) v_u_45, (ref) v_u_3
		if v_u_46 and (p_u_31() and v_u_6.turn(v_u_32, p153)) then
			local v154 = v_u_45
			local v155 = {
				["tick"] = v_u_32.tick,
				["action"] = p153
			}
			table.insert(v154, v155)
			v_u_3.play("RouletteTick", {
				["volume"] = 0.8
			})
		end
	end
	local v_u_157 = {}
	if p30 then
		local v158 = v_u_2.find("Frames.Leave.Redeem")
		local v159 = {
			["up"] = UDim2.fromScale(0.5, 0.18),
			["down"] = UDim2.fromScale(0.5, 0.82),
			["left"] = UDim2.fromScale(0.18, 0.5),
			["right"] = UDim2.fromScale(0.82, 0.5)
		}
		local v160 = Instance.new("Frame")
		v160.Name = "Pad"
		v160.BackgroundTransparency = 1
		v160.AnchorPoint = Vector2.new(0.5, 0.5)
		v160.Position = UDim2.fromScale(0.5, 0.55)
		v160.Size = UDim2.fromScale(0.95, 0.95)
		Instance.new("UIAspectRatioConstraint").Parent = v160
		v160.Parent = p28
		local v161 = {
			["up"] = "\226\150\178",
			["down"] = "\226\150\188",
			["left"] = "\226\151\128",
			["right"] = "\226\150\182"
		}
		for v162, v163 in v159 do
			local v164
			if v158 then
				v164 = v_u_2.button(v158, v162, v161[v162])
				v_u_2.paint(v164, Color3.fromRGB(80, 200, 255), Color3.fromRGB(40, 120, 255))
			else
				v164 = Instance.new("TextButton")
				v164.Name = v162
				v164.Text = v161[v162]
			end
			v164.AnchorPoint = Vector2.new(0.5, 0.5)
			v164.Position = v163
			v164.Size = UDim2.fromScale(0.36, 0.36)
			v164.Selectable = false
			v164.Parent = v160
			local v_u_165 = v_u_10[v162]
			local v166 = v164.InputBegan
			table.insert(v_u_157, v166:Connect(function(p167)
				-- upvalues: (copy) v_u_156, (copy) v_u_165
				if p167.UserInputType == Enum.UserInputType.Touch or p167.UserInputType == Enum.UserInputType.MouseButton1 then
					v_u_156(v_u_165)
				end
			end))
		end
	end
	v_u_129(1)
	return {
		["score"] = function() -- name: score
			-- upvalues: (copy) v_u_32
			return v_u_32.score
		end,
		["over"] = function() -- name: over
			-- upvalues: (copy) v_u_32
			return v_u_32.over
		end,
		["reason"] = function() -- name: reason
			-- upvalues: (copy) v_u_32
			return v_u_32.reason
		end,
		["tick"] = function() -- name: tick
			-- upvalues: (copy) v_u_32
			return v_u_32.tick
		end,
		["left"] = function() -- name: left
			-- upvalues: (ref) v_u_6, (copy) v_u_32
			return v_u_6.left(v_u_32)
		end,
		["count"] = function() -- name: count
			-- upvalues: (copy) v_u_32
			return v_u_32.orbs + v_u_32.goldens
		end,
		["inputs"] = v_u_45,
		["update"] = function(p168) -- name: update
			-- upvalues: (ref) v_u_46, (copy) v_u_32, (ref) v_u_44, (ref) v_u_35, (ref) v_u_6, (copy) v_u_85, (copy) v_u_152, (copy) v_u_129
			if v_u_46 then
				if not v_u_32.over then
					v_u_44 = v_u_44 + math.min(p168, 0.25)
					while v_u_44 >= v_u_32.interval and not v_u_32.over do
						v_u_44 = v_u_44 - v_u_32.interval
						v_u_35 = table.clone(v_u_32.body)
						v_u_6.step(v_u_32)
						v_u_85()
						v_u_152()
					end
				end
				v_u_129(v_u_32.over and 1 or v_u_44 / v_u_32.interval)
			end
		end,
		["press"] = function(p169, p170) -- name: press
			-- upvalues: (ref) v_u_10, (copy) v_u_156
			local v171 = v_u_10[p169]
			if p170 and v171 then
				v_u_156(v171)
			end
		end,
		["auto"] = function() -- name: auto
			-- upvalues: (copy) v_u_32, (ref) v_u_6, (ref) v_u_12, (ref) v_u_13, (copy) v_u_33, (copy) v_u_34, (copy) v_u_156
			if not v_u_32.over and #v_u_32.queue <= 0 then
				local v172, v173 = v_u_6.xyOf(v_u_32, v_u_32.body[1])
				local v174
				if v_u_32.golden == 0 then
					v174 = v_u_32.orb
				else
					v174 = v_u_32.golden
				end
				local v175, v176 = v_u_6.xyOf(v_u_32, v174)
				local v177 = v_u_32.dir
				local v178 = (1 / 0)
				for v179 = 1, 4 do
					local v180 = v172 + v_u_12[v179]
					local v181 = v173 + v_u_13[v179]
					local v182 = (v181 - 1) * v_u_33 + v180
					local v183 = table.find(v_u_32.body, v182)
					if v180 < 1 or (v180 > v_u_33 or (v181 < 1 or (v181 > v_u_34 or v183 ~= nil and v183 ~= #v_u_32.body))) or (v179 + 1) % 4 + 1 == v_u_32.dir then
						continue
					end
					local v184 = v175 - v180
					local v185 = math.abs(v184)
					local v186 = v176 - v181
					local v187 = v185 + math.abs(v186) + (v179 == v_u_32.dir and 0 or 0.1)
					if v187 >= v178 then
						continue
					end
					v177 = v179
					v178 = v187
				end
				if v177 ~= v_u_32.dir then
					v_u_156(v177)
				end
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (ref) v_u_46, (copy) v_u_157, (copy) v_u_40, (copy) v_u_96, (copy) v_u_97
			v_u_46 = false
			for _, v188 in v_u_157 do
				v188:Disconnect()
			end
			v_u_40:Destroy()
			v_u_96:Destroy()
			v_u_97:Destroy()
		end
	}
end
return v9