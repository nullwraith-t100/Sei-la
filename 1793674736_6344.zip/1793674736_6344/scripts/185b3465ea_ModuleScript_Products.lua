local v1 = {
	["passes"] = {
		{
			["key"] = "starter",
			["name"] = "Starter Pack",
			["id"] = 2040074413,
			["price"] = 29,
			["group"] = "pack",
			["info"] = "3 eggs of your world (Shinobi in World 1), 1K+ Trophies, x2 Chakra and x2 Trophies for 30 min",
			["mult"] = nil
		},
		{
			["key"] = "pro",
			["name"] = "Pro Pack",
			["id"] = 2039582486,
			["price"] = 199,
			["group"] = "pack",
			["info"] = "2 Akatsuki Eggs, 10 eggs of your world (Shinobi in World 1), 25K+ Trophies, x5 Chakra and x2 Trophies for 1 h",
			["mult"] = nil
		},
		{
			["key"] = "ultimate",
			["name"] = "Ultimate OP Bundle",
			["id"] = 2053176645,
			["price"] = 4999,
			["group"] = "pack",
			["info"] = "All 4 Robux training areas, Ten Tails, Rainbow Chakra Aura, Six Paths Sage and the ULTIMATE title",
			["mult"] = nil
		},
		{
			["key"] = "equip1",
			["name"] = "+1 Pet Equip",
			["id"] = 2038232661,
			["price"] = 49,
			["group"] = "perk",
			["info"] = "Equip one more pet",
			["mult"] = nil
		},
		{
			["key"] = "equip2",
			["name"] = "+2 Pet Equip",
			["id"] = 2036750675,
			["price"] = 99,
			["group"] = "perk",
			["info"] = "Equip two more pets",
			["mult"] = nil
		},
		{
			["key"] = "storage20",
			["name"] = "+20 Pet Storage",
			["id"] = 2036702669,
			["price"] = 9,
			["group"] = "perk",
			["info"] = "Keep 20 more pets",
			["mult"] = nil
		},
		{
			["key"] = "storage120",
			["name"] = "+120 Pet Storage",
			["id"] = 2038364675,
			["price"] = 79,
			["group"] = "perk",
			["info"] = "Keep 120 more pets",
			["mult"] = nil
		},
		{
			["key"] = "winsPad",
			["name"] = "x3 Wins Pad",
			["id"] = 2036654683,
			["price"] = 99,
			["group"] = "perk",
			["info"] = "Use the purple x3 Trophy pads",
			["mult"] = nil
		},
		{
			["key"] = "speed2",
			["name"] = "x2 Speed",
			["id"] = 2036702671,
			["price"] = 29,
			["group"] = "perk",
			["info"] = "Run twice as fast",
			["mult"] = nil
		},
		{
			["key"] = "autoRebirth",
			["name"] = "Auto Rebirth",
			["id"] = 2037284757,
			["price"] = 99,
			["group"] = "perk",
			["info"] = "Rebirth by itself as soon as you can",
			["mult"] = nil
		},
		{
			["key"] = "x2",
			["name"] = "x2 Chakra",
			["id"] = 2038334675,
			["price"] = 3,
			["group"] = "chakra",
			["info"] = "Double all chakra",
			["mult"] = 2
		},
		{
			["key"] = "x4",
			["name"] = "x4 Chakra",
			["id"] = 2036726711,
			["price"] = 19,
			["group"] = "chakra",
			["info"] = "x4 all chakra",
			["mult"] = 4
		},
		{
			["key"] = "x8",
			["name"] = "x8 Chakra",
			["id"] = 2039774481,
			["price"] = 39,
			["group"] = "chakra",
			["info"] = "x8 all chakra",
			["mult"] = 8
		},
		{
			["key"] = "x16",
			["name"] = "x16 Chakra",
			["id"] = 2040038425,
			["price"] = 69,
			["group"] = "chakra",
			["info"] = "x16 all chakra",
			["mult"] = 16
		},
		{
			["key"] = "x32",
			["name"] = "x32 Chakra",
			["id"] = 2036714692,
			["price"] = 139,
			["group"] = "chakra",
			["info"] = "x32 all chakra",
			["mult"] = 32
		},
		{
			["key"] = "x64",
			["name"] = "x64 Chakra",
			["id"] = 2038202661,
			["price"] = 229,
			["group"] = "chakra",
			["info"] = "x64 all chakra",
			["mult"] = 64
		},
		{
			["key"] = "x128",
			["name"] = "x128 Chakra",
			["id"] = 2038064663,
			["price"] = 359,
			["group"] = "chakra",
			["info"] = "x128 all chakra",
			["mult"] = 128
		},
		{
			["key"] = "x256",
			["name"] = "x256 Chakra",
			["id"] = 2036618680,
			["price"] = 589,
			["group"] = "chakra",
			["info"] = "x256 all chakra",
			["mult"] = 256
		},
		{
			["key"] = "x512",
			["name"] = "x512 Chakra",
			["id"] = 2037926656,
			["price"] = 799,
			["group"] = "chakra",
			["info"] = "x512 all chakra",
			["mult"] = 512
		},
		{
			["key"] = "x1024",
			["name"] = "x1024 Chakra",
			["id"] = 2037176671,
			["price"] = 1199,
			["group"] = "chakra",
			["info"] = "x1024 all chakra",
			["mult"] = 1024
		},
		{
			["key"] = "x2048",
			["name"] = "x2048 Chakra",
			["id"] = 2036426712,
			["price"] = 1659,
			["group"] = "chakra",
			["info"] = "x2048 all chakra",
			["mult"] = 2048
		},
		{
			["key"] = "x4096",
			["name"] = "x4096 Chakra",
			["id"] = 2038178671,
			["price"] = 2099,
			["group"] = "chakra",
			["info"] = "x4096 all chakra",
			["mult"] = 4096
		},
		{
			["key"] = "x8192",
			["name"] = "x8192 Chakra",
			["id"] = 2036300657,
			["price"] = 2339,
			["group"] = "chakra",
			["info"] = "x8192 all chakra",
			["mult"] = 8192
		},
		{
			["key"] = "shin",
			["name"] = "Shin Ketsuryugan",
			["id"] = 2036792682,
			["price"] = 599,
			["group"] = "special",
			["info"] = "The strongest eye: x3000 Chakra",
			["mult"] = nil
		},
		{
			["key"] = "kurama",
			["name"] = "Kyubi",
			["id"] = 2037644712,
			["price"] = 799,
			["group"] = "special",
			["info"] = "The Nine-Tails pet: x100 Chakra, more in each later world",
			["mult"] = nil
		},
		{
			["key"] = "prismEye",
			["name"] = "Prism Eye",
			["id"] = 2039942699,
			["price"] = 899,
			["group"] = "special",
			["info"] = "World 2\'s strongest eye: x120B Chakra",
			["mult"] = nil
		},
		{
			["key"] = "tenTails",
			["name"] = "Ten Tails",
			["id"] = 2037392970,
			["price"] = 1499,
			["group"] = "special",
			["info"] = "The Ten-Tails pet: x250 Chakra, more in Worlds 3 and 4",
			["mult"] = nil
		},
		{
			["key"] = "sixPaths",
			["name"] = "Six Paths Sage",
			["id"] = 2036836890,
			["price"] = 899,
			["group"] = "special",
			["info"] = "The strongest eye in every world",
			["mult"] = nil
		},
		{
			["key"] = "train1",
			["name"] = "Golden Dojo",
			["id"] = 2037938800,
			["price"] = 99,
			["group"] = "train",
			["info"] = "Train at x8",
			["mult"] = nil
		},
		{
			["key"] = "train2",
			["name"] = "Thunder Dome",
			["id"] = 2037764709,
			["price"] = 299,
			["group"] = "train",
			["info"] = "Train at x25",
			["mult"] = nil
		},
		{
			["key"] = "train3",
			["name"] = "Dragon Sanctum",
			["id"] = 2037296729,
			["price"] = 699,
			["group"] = "train",
			["info"] = "Train at x50",
			["mult"] = nil
		},
		{
			["key"] = "train4",
			["name"] = "Six Paths Throne",
			["id"] = 2038142762,
			["price"] = 1800,
			["group"] = "train",
			["info"] = "Train at x250",
			["mult"] = nil
		},
		{
			["key"] = "skipSpark",
			["name"] = "Spark Aura",
			["id"] = 2036738733,
			["price"] = 9,
			["group"] = "aura",
			["info"] = "Unlock Spark now",
			["mult"] = nil
		},
		{
			["key"] = "skipBlueFlame",
			["name"] = "Blue Flame Aura",
			["id"] = 2037644752,
			["price"] = 19,
			["group"] = "aura",
			["info"] = "Unlock Blue Flame now",
			["mult"] = nil
		},
		{
			["key"] = "skipLeaf",
			["name"] = "Leaf Storm Aura",
			["id"] = 2040260282,
			["price"] = 39,
			["group"] = "aura",
			["info"] = "Unlock Leaf Storm now",
			["mult"] = nil
		},
		{
			["key"] = "skipThunder",
			["name"] = "Thunder Aura",
			["id"] = 2036366717,
			["price"] = 69,
			["group"] = "aura",
			["info"] = "Unlock Thunder now",
			["mult"] = nil
		},
		{
			["key"] = "skipSakura",
			["name"] = "Sakura Storm Aura",
			["id"] = 2040098325,
			["price"] = 99,
			["group"] = "aura",
			["info"] = "Unlock Sakura Storm now",
			["mult"] = nil
		},
		{
			["key"] = "skipInferno",
			["name"] = "Astral Aura",
			["id"] = 2037608753,
			["price"] = 149,
			["group"] = "aura",
			["info"] = "Unlock Astral now",
			["mult"] = nil
		},
		{
			["key"] = "skipAmaterasu",
			["name"] = "Amaterasu Aura",
			["id"] = 2036348752,
			["price"] = 249,
			["group"] = "aura",
			["info"] = "Unlock Amaterasu now",
			["mult"] = nil
		},
		{
			["key"] = "skipVoid",
			["name"] = "Void Aura",
			["id"] = 2039606551,
			["price"] = 399,
			["group"] = "aura",
			["info"] = "Unlock Void now",
			["mult"] = nil
		},
		{
			["key"] = "skipCelestial",
			["name"] = "Celestial Aura",
			["id"] = 2038232719,
			["price"] = 599,
			["group"] = "aura",
			["info"] = "Unlock Celestial now",
			["mult"] = nil
		},
		{
			["key"] = "auraSage",
			["name"] = "Golden Sage Aura",
			["id"] = 2036612713,
			["price"] = 149,
			["group"] = "aura",
			["info"] = "x15 Chakra aura, more in every world",
			["mult"] = nil
		},
		{
			["key"] = "auraKurama",
			["name"] = "Kyubi Chakra Aura",
			["id"] = 2039864521,
			["price"] = 399,
			["group"] = "aura",
			["info"] = "x25 Chakra aura, more in every world",
			["mult"] = nil
		},
		{
			["key"] = "auraOtsutsuki",
			["name"] = "Otsutsuki Aura",
			["id"] = 2038268737,
			["price"] = 899,
			["group"] = "aura",
			["info"] = "x40 Chakra aura, more in every world",
			["mult"] = nil
		},
		{
			["key"] = "auraSusanoo",
			["name"] = "Susanoo Flame Aura",
			["id"] = 2054256245,
			["price"] = 499,
			["group"] = "aura",
			["info"] = "Always +50% better than your best aura",
			["mult"] = nil
		},
		{
			["key"] = "auraRainbow",
			["name"] = "Rainbow Chakra Aura",
			["id"] = 2052342231,
			["price"] = 1199,
			["group"] = "aura",
			["info"] = "Always +150% better than your best aura",
			["mult"] = nil
		},
		{
			["key"] = "vip",
			["name"] = "VIP",
			["id"] = 2057902891,
			["price"] = 199,
			["group"] = "perk",
			["info"] = "x1.5 Chakra, x1.5 Trophies, faster running, the VIP title and the VIP aura",
			["mult"] = nil
		},
		{
			["key"] = "autoWin",
			["name"] = "Auto Win",
			["id"] = 2057722878,
			["price"] = 299,
			["group"] = "perk",
			["info"] = "Earns your best stage\'s trophies by itself while you are idle",
			["mult"] = nil
		},
		{
			["key"] = "vipPlus",
			["name"] = "VIP+",
			["id"] = 2060794868,
			["price"] = 699,
			["group"] = "perk",
			["info"] = "Everything VIP gives, the VIP+ aura, the Royal Lion pet, the VIP+ title and +20% Kyubi Coins",
			["mult"] = nil
		},
		{
			["key"] = "hokage",
			["name"] = "Hokage OP Bundle",
			["id"] = 2058683718,
			["price"] = 3999,
			["group"] = "pack",
			["info"] = "VIP+, Kyubi, Prism Eye, Shin Ketsuryugan, Otsutsuki Aura, Auto Win, x3 Wins Pad, Auto Rebirth, pet equip and storage, x2 Speed, 1,500 Kyubi Coins and the HOKAGE title",
			["mult"] = nil
		},
		{
			["key"] = "luckX2",
			["name"] = "x2 Luck",
			["id"] = 0,
			["price"] = 49,
			["group"] = "luck",
			["info"] = "x2 Luck for good: rarer pets and boss drops",
			["mult"] = 2
		},
		{
			["key"] = "luckX4",
			["name"] = "x4 Luck",
			["id"] = 0,
			["price"] = 189,
			["group"] = "luck",
			["info"] = "x4 Luck for good: rarer pets and boss drops",
			["mult"] = 4
		},
		{
			["key"] = "luckX8",
			["name"] = "x8 Luck",
			["id"] = 0,
			["price"] = 359,
			["group"] = "luck",
			["info"] = "x8 Luck for good: rarer pets and boss drops",
			["mult"] = 8
		}
	},
	["products"] = {
		{
			["key"] = "chakra1",
			["name"] = "Chakra 1",
			["id"] = 3718791970,
			["price"] = 9,
			["info"] = "10 minutes of chakra",
			["kind"] = "chakra",
			["seconds"] = 600
		},
		{
			["key"] = "chakra2",
			["name"] = "Chakra 2",
			["id"] = 3718791988,
			["price"] = 49,
			["info"] = "1 hour of chakra",
			["kind"] = "chakra",
			["seconds"] = 3600
		},
		{
			["key"] = "chakra3",
			["name"] = "Chakra 3",
			["id"] = 3718792011,
			["price"] = 199,
			["info"] = "5 hours of chakra",
			["kind"] = "chakra",
			["seconds"] = 18000
		},
		{
			["key"] = "boost2",
			["name"] = "x2 Chakra 10 min",
			["id"] = 3718792137,
			["price"] = 14,
			["info"] = "x2 Chakra for 10 minutes",
			["kind"] = "boost",
			["mult"] = 2,
			["minutes"] = 10
		},
		{
			["key"] = "boostWins",
			["name"] = "x2 Trophies 10 min",
			["id"] = 3722606218,
			["price"] = 15,
			["info"] = "x2 Trophies for 10 minutes",
			["kind"] = "boost",
			["mult"] = 2,
			["minutes"] = 10,
			["boost"] = "wins"
		},
		{
			["key"] = "boost5",
			["name"] = "x5 Chakra 15 min",
			["id"] = 3718792180,
			["price"] = 49,
			["info"] = "x5 Chakra for 15 minutes",
			["kind"] = "boost",
			["mult"] = 5,
			["minutes"] = 15
		},
		{
			["key"] = "boost10",
			["name"] = "x10 Chakra 15 min",
			["id"] = 3718792217,
			["price"] = 99,
			["info"] = "x10 Chakra for 15 minutes",
			["kind"] = "boost",
			["mult"] = 10,
			["minutes"] = 15
		},
		{
			["key"] = "boost50",
			["name"] = "x50 Chakra 60 s",
			["id"] = 3722961385,
			["price"] = 19,
			["info"] = "x50 Chakra for 60 seconds",
			["kind"] = "boost",
			["mult"] = 50,
			["minutes"] = 1
		},
		{
			["key"] = "skipRebirth",
			["name"] = "Skip Rebirth",
			["id"] = 3718795561,
			["price"] = 19,
			["info"] = "Rebirth now, at any level",
			["kind"] = "skipRebirth"
		},
		{
			["key"] = "skipDay",
			["name"] = "Skip Day",
			["id"] = 3718968982,
			["price"] = 49,
			["info"] = "Claim the next daily reward now",
			["kind"] = "skipDay"
		},
		{
			["key"] = "skipEye",
			["name"] = "Skip Eye",
			["id"] = 3719039525,
			["price"] = 79,
			["info"] = "Unlock your next eye now",
			["kind"] = "skipEye"
		},
		{
			["key"] = "autoOp",
			["name"] = "OP Auto Clicker",
			["id"] = 3718952394,
			["price"] = 79,
			["info"] = "Clicks twice as fast as the free one for 30 minutes",
			["kind"] = "autoclick",
			["minutes"] = 30
		},
		{
			["key"] = "revive",
			["name"] = "Revive",
			["id"] = 3718796082,
			["price"] = 14,
			["info"] = "Back on your feet at full health",
			["kind"] = "revive"
		},
		{
			["key"] = "revenge",
			["name"] = "Revenge",
			["id"] = 3718796040,
			["price"] = 39,
			["info"] = "Back at full health and every enemy of the wave falls",
			["kind"] = "revenge"
		},
		{
			["key"] = "eggAkatsuki1",
			["name"] = "Akatsuki Egg x1",
			["id"] = 3718841057,
			["price"] = 79,
			["info"] = "Hatch one Akatsuki Egg",
			["kind"] = "egg",
			["egg"] = "akatsuki",
			["count"] = 1
		},
		{
			["key"] = "eggAkatsuki3",
			["name"] = "Akatsuki Egg x3",
			["id"] = 3718841079,
			["price"] = 199,
			["info"] = "Hatch three Akatsuki Eggs",
			["kind"] = "egg",
			["egg"] = "akatsuki",
			["count"] = 3
		},
		{
			["key"] = "eggDivine1",
			["name"] = "Divine Egg x1",
			["id"] = 3718841103,
			["price"] = 149,
			["info"] = "Hatch one Divine Egg",
			["kind"] = "egg",
			["egg"] = "divine",
			["count"] = 1
		},
		{
			["key"] = "eggDivine3",
			["name"] = "Divine Egg x3",
			["id"] = 3718841119,
			["price"] = 379,
			["info"] = "Hatch three Divine Eggs",
			["kind"] = "egg",
			["egg"] = "divine",
			["count"] = 3
		},
		{
			["key"] = "bossSkip",
			["name"] = "Summon Kyubi",
			["id"] = 3722981039,
			["price"] = 29,
			["info"] = "Kyubi comes now for the whole server",
			["kind"] = "bossSkip"
		},
		{
			["key"] = "bossRevive",
			["name"] = "Boss Revive",
			["id"] = 3723339562,
			["price"] = 9,
			["info"] = "Back in the Kyubi fight at full health",
			["kind"] = "bossRevive"
		},
		{
			["key"] = "dailyAll",
			["name"] = "Unlock All Days",
			["id"] = 3723113128,
			["price"] = 149,
			["info"] = "Every daily reward left this week, now",
			["kind"] = "dailyAll"
		},
		{
			["key"] = "potionPack",
			["name"] = "Potion Pack",
			["id"] = 3723113142,
			["price"] = 129,
			["info"] = "x5 Chakra 30 min, x2 Trophies 30 min and the OP Auto Clicker for 30 min",
			["kind"] = "bundle",
			["contents"] = nil,
			["contents"] = {
				{
					["key"] = "boost5",
					["count"] = 2
				},
				{
					["key"] = "boostWins",
					["count"] = 3
				},
				{
					["key"] = "autoOp",
					["count"] = 1
				}
			}
		},
		{
			["key"] = "offlineX5",
			["name"] = "Welcome Back x5",
			["id"] = 3723113435,
			["price"] = 49,
			["info"] = "x5 the chakra you earned while offline (this visit)",
			["kind"] = "offlineX5",
			["mult"] = 5
		},
		{
			["key"] = "questsDaily",
			["name"] = "Refresh Daily Quests",
			["id"] = 3723124352,
			["price"] = 29,
			["info"] = "New daily quests for the ones not done yet",
			["kind"] = "questRefresh",
			["period"] = "daily"
		},
		{
			["key"] = "questsWeekly",
			["name"] = "Refresh Weekly Quests",
			["id"] = 3723124359,
			["price"] = 59,
			["info"] = "New weekly quests for the ones not done yet",
			["kind"] = "questRefresh",
			["period"] = "weekly"
		},
		{
			["key"] = "kuramaCoins100",
			["name"] = "100 Kyubi Coins",
			["id"] = 3723322469,
			["price"] = 109,
			["info"] = "100 Kyubi Coins for the boss shop",
			["kind"] = "kuramaCoins",
			["coins"] = 100
		},
		{
			["key"] = "kuramaCoins500",
			["name"] = "500 Kyubi Coins",
			["id"] = 3723322486,
			["price"] = 499,
			["info"] = "500 Kyubi Coins for the boss shop",
			["kind"] = "kuramaCoins",
			["coins"] = 500
		},
		{
			["key"] = "kuramaCoins1500",
			["name"] = "1500 Kyubi Coins",
			["id"] = 3723322501,
			["price"] = 1199,
			["info"] = "1,500 Kyubi Coins for the boss shop",
			["kind"] = "kuramaCoins",
			["coins"] = 1500
		},
		{
			["key"] = "bossLuck2",
			["name"] = "x2 Boss Luck 60 min",
			["id"] = 3726870644,
			["price"] = 129,
			["info"] = "x2 Kyubi boss drop chances for 60 minutes",
			["kind"] = "boost",
			["mult"] = 2,
			["minutes"] = 60,
			["boost"] = "luck"
		},
		{
			["key"] = "bossLuck5",
			["name"] = "x5 Boss Luck 60 min",
			["id"] = 3726870668,
			["price"] = 599,
			["info"] = "x5 Kyubi boss drop chances for 60 minutes",
			["kind"] = "boost",
			["mult"] = 5,
			["minutes"] = 60,
			["boost"] = "luck"
		},
		{
			["key"] = "serverBoost2",
			["name"] = "Server x2 Chakra",
			["id"] = 3723393805,
			["price"] = 149,
			["info"] = "x2 Chakra for 15 minutes for everyone in the server",
			["kind"] = "serverBoost",
			["mult"] = 2,
			["minutes"] = 15,
			["cap"] = 120
		},
		{
			["key"] = "vipPlusUpgrade",
			["name"] = "VIP+ Upgrade",
			["id"] = 3723396073,
			["price"] = 500,
			["info"] = "VIP+ for VIP owners: pay only the difference",
			["kind"] = "passUpgrade",
			["pass"] = "vipPlus"
		},
		{
			["key"] = "fuseVoid",
			["name"] = "Upgrade to Void",
			["id"] = 3723585254,
			["price"] = 99,
			["info"] = "One pet to VOID now: no copies needed",
			["kind"] = "fuseSkip",
			["tier"] = 1
		},
		{
			["key"] = "fuseRainbow",
			["name"] = "Upgrade to Rainbow",
			["id"] = 3723585267,
			["price"] = 399,
			["info"] = "One VOID pet to RAINBOW now: no copies needed",
			["kind"] = "fuseSkip",
			["tier"] = 2
		},
		{
			["key"] = "fuseCorrupted",
			["name"] = "Upgrade to Corrupted",
			["id"] = 3723585283,
			["price"] = 799,
			["info"] = "One RAINBOW pet to CORRUPTED now: no copies needed",
			["kind"] = "fuseSkip",
			["tier"] = 3
		},
		{
			["key"] = "luckTier2",
			["name"] = "x2 Luck",
			["id"] = 3727220985,
			["price"] = 49,
			["info"] = "x2 Luck for good: rarer pets and boss drops",
			["kind"] = "luckTier",
			["pass"] = "luckX2",
			["mult"] = 2
		},
		{
			["key"] = "luckTier4",
			["name"] = "x4 Luck",
			["id"] = 3727221014,
			["price"] = 189,
			["info"] = "x4 Luck for good: rarer pets and boss drops",
			["kind"] = "luckTier",
			["pass"] = "luckX4",
			["mult"] = 4
		},
		{
			["key"] = "luckTier8",
			["name"] = "x8 Luck",
			["id"] = 3727221043,
			["price"] = 359,
			["info"] = "x8 Luck for good: rarer pets and boss drops",
			["kind"] = "luckTier",
			["pass"] = "luckX8",
			["mult"] = 8
		}
	},
	["passByKey"] = {}
}
for _, v2 in v1.passes do
	v1.passByKey[v2.key] = v2
end
v1.productByKey = {}
for _, v3 in v1.products do
	v1.productByKey[v3.key] = v3
end
v1.BUNDLES = {
	["ultimate"] = {
		"train1",
		"train2",
		"train3",
		"train4",
		"tenTails",
		"auraRainbow",
		"sixPaths"
	},
	["vipPlus"] = { "vip" },
	["hokage"] = {
		"vipPlus",
		"kurama",
		"prismEye",
		"shin",
		"auraOtsutsuki",
		"autoWin",
		"winsPad",
		"autoRebirth",
		"equip2",
		"equip1",
		"storage120",
		"storage20",
		"speed2"
	}
}
v1.BUNDLE_UPDATE = {
	["vipPlus"] = 2,
	["hokage"] = 2
}
v1.TITLES = {
	["ultimate"] = "ULTIMATE",
	["vip"] = "VIP",
	["vipPlus"] = "VIP+",
	["hokage"] = "HOKAGE"
}
v1.TITLE_RANK = {
	["ultimate"] = 4,
	["hokage"] = 3,
	["vipPlus"] = 2,
	["vip"] = 1
}
v1.TITLE_UPDATE = {
	["vipPlus"] = 2,
	["hokage"] = 2
}
function v1.tier(p4) -- name: tier
	return p4 < 29 and "micro" or (p4 < 99 and "entry" or (p4 < 449 and "mid" or (p4 < 1000 and "high" or (p4 < 4999 and "whale" or "mega"))))
end
v1.chakraTiers = {}
for _, v5 in v1.passes do
	if v5.group ~= "chakra" then
		continue
	end
	local v6 = v1.chakraTiers
	table.insert(v6, v5)
end
v1.luckTiers = {}
v1.luckProduct = {}
for _, v7 in v1.passes do
	if v7.group ~= "luck" then
		continue
	end
	local v8 = v1.luckTiers
	table.insert(v8, v7)
end
for _, v9 in v1.products do
	if v9.kind ~= "luckTier" or not v9.pass then
		continue
	end
	v1.luckProduct[v9.pass] = v9
end
v1.RETIRED = {
	["x1024"] = true,
	["x2048"] = true,
	["x4096"] = true,
	["x8192"] = true
}
for v10 in v1.RETIRED do
	local v11 = v1.passByKey[v10]
	if not v11 then
		continue
	end
	v11.retired = true
end
return v1