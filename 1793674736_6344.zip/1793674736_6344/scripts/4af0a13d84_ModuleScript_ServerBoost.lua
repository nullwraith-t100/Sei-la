local v_u_24 = {
	["left"] = function(p1, p2) -- name: left
		local v3 = p1 - p2
		return math.max(0, v3)
	end,
	["active"] = function(p4, p5) -- name: active
		return p5 < p4
	end,
	["mult"] = function(p6, p7, p8) -- name: mult
		return p7 >= p6 and 1 or math.max(p8, 1)
	end,
	["extend"] = function(p9, p10, p11) -- name: extend
		return math.max(p9, p10) + math.max(p11, 0) * 60
	end,
	["canBuy"] = function(p12, p13, p14, p15) -- name: canBuy
		-- upvalues: (copy) v_u_24
		return v_u_24.left(p12, p13) + p14 * 60 <= p15 * 60
	end,
	["stack"] = function(p16, p17) -- name: stack
		return p16 * math.max(p17, 1)
	end,
	["clock"] = function(p18) -- name: clock
		local v19 = math.ceil(p18)
		local v20 = math.max(v19, 0)
		if v20 >= 3600 then
			return string.format("%d:%02d:%02d", v20 // 3600, v20 // 60 % 60, v20 % 60)
		else
			return string.format("%d:%02d", v20 // 60, v20 % 60)
		end
	end,
	["announce"] = function(p21, p22, p23) -- name: announce
		return ("%* gave the whole server x%* CHAKRA for %* min!"):format(p21, p22, p23)
	end
}
return v_u_24