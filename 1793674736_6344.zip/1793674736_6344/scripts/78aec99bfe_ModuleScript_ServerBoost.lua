local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.Gifting)
local v_u_7 = require(script.Parent.Menus)
local v_u_8 = require(script.Parent.Sfx)
local v_u_9 = require(script.Parent.Store)
local v_u_10 = require(script.Parent.Tutorial)
local v11 = v2.Shared
local v_u_12 = require(v11.Config.Images)
require(v11.Config.Products)
local v_u_13 = require(v11.Config.Release)
local v_u_14 = require(v11.Logic.ServerBoost)
local v_u_15 = {}
local v_u_16 = v1.LocalPlayer
local v17 = Color3.fromRGB
local v_u_18 = v17(60, 240, 205)
local v_u_19 = v17(8, 158, 150)
local v_u_20 = v17(80, 245, 220)
local v_u_21 = v17(255, 215, 60)
local v_u_22 = v17(127, 240, 255)
local v_u_23 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local function v_u_24(_, _) end
local function v_u_28(p25, p26) -- name: child
	for v27 in string.gmatch(p26, "[^%.]+") do
		if not p25 then
			continue
		end
		p25 = p25:FindFirstChild(v27)
	end
	return p25
end
local function v_u_29() -- name: now
	-- upvalues: (copy) v_u_5
	return v_u_5:GetServerTimeNow()
end
function v_u_15.left() -- name: left
	-- upvalues: (copy) v_u_14, (copy) v_u_5, (copy) v_u_29
	local v30 = v_u_14.left
	local v31 = v_u_5:GetAttribute("ServerBoostUntil")
	return v30(type(v31) ~= "number" and 0 or v31, v_u_29())
end
function v_u_15.sellable() -- name: sellable
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_13, (copy) v_u_14
	local v32 = v_u_9.product("serverBoost2")
	if v32 then
		if v32.id == 0 then
			local v33 = v_u_3:IsStudio()
			if v33 then
				v33 = v_u_5:GetAttribute("DevOffers") == true
			end
			if not v33 then
				v32 = nil
			end
		end
	else
		v32 = nil
	end
	local v34 = v_u_13.on(2)
	if v34 then
		if v32 == nil then
			v34 = false
		else
			local v35 = v_u_14.canBuy
			local v36 = v_u_5:GetAttribute("ServerBoostUntil")
			v34 = v35(type(v36) ~= "number" and 0 or v36, v_u_5:GetServerTimeNow(), v32.minutes or 15, v32.cap or 120)
		end
	end
	return v34
end
local function v_u_42(p37) -- name: fresh
	for _, v38 in p37:GetDescendants() do
		local v39 = v38.Parent
		local v40
		if v38.Name == "Shine" and v39 ~= nil then
			v40 = v39:GetAttribute("Ui-Effect") == "Shine"
		else
			v40 = false
		end
		if v40 or (v38.Name == "PadHint" or (v38.Name == "GiftButton" or v38.Name == "Gloss")) then
			v38:Destroy()
		elseif v38:IsA("ImageLabel") then
			local v41 = v38:GetAttribute("Ui-Effect")
			if v41 ~= "Bg_X" and v41 ~= "Bg_Y" then
				continue
			end
			v38.Position = UDim2.fromScale(v38.Position.X.Scale, v38.Position.Y.Scale)
			v38.Size = UDim2.fromScale(v38.Size.X.Scale, v38.Size.Y.Scale)
		else
			if not v38:IsA("UIScale") or v38.Name ~= "Pop" then
				continue
			end
			v38.Scale = 1
		end
	end
end
local v_u_43 = nil
local v_u_44 = nil
local v_u_45 = nil
local function v_u_61(p46) -- name: buildCard
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_28, (copy) v_u_13, (copy) v_u_42, (copy) v_u_12, (copy) v_u_18, (copy) v_u_19, (copy) v_u_23, (ref) v_u_43, (ref) v_u_44, (copy) v_u_6, (copy) v_u_15, (copy) v_u_8, (ref) v_u_24, (ref) v_u_45
	local v_u_47 = v_u_9.product("serverBoost2")
	if v_u_47 then
		if v_u_47.id == 0 then
			local v48 = v_u_3:IsStudio()
			if v48 then
				v48 = v_u_5:GetAttribute("DevOffers") == true
			end
			if not v48 then
				v_u_47 = nil
			end
		end
	else
		v_u_47 = nil
	end
	local v49 = v_u_28(p46, "Frames.Store")
	if v49 then
		v49 = v49:FindFirstChild("Holder", true)
	end
	local v50
	if v49 then
		v50 = v49:FindFirstChild("Product_boost2")
	else
		v50 = v49
	end
	if v_u_13.on(2) and (v_u_47 and (v49 and (v50 and (v50:IsA("GuiObject") and not v49:FindFirstChild("Product_serverBoost2"))))) then
		local v51 = v50:Clone()
		v_u_42(v51)
		v51.Name = "Product_serverBoost2"
		local v52 = v49:FindFirstChild("Product_boost10")
		local v53
		if v52 and v52:IsA("GuiObject") then
			v53 = v52.LayoutOrder
		else
			v53 = v50.LayoutOrder
		end
		v51.LayoutOrder = v53
		local v54 = v51:FindFirstChild("Title")
		if v54 and v54:IsA("TextLabel") then
			v54.Text = v_u_47.name
		end
		local v55 = v51:FindFirstChild("Icon")
		if v55 and v55:IsA("ImageLabel") then
			v55.Image = v_u_12.Icon.BoostChakra or v55.Image
		end
		local v56 = v51:FindFirstChildOfClass("UIGradient")
		if v56 then
			v56.Color = ColorSequence.new(v_u_18, v_u_19)
			v56.Rotation = 90
		end
		v51.BackgroundColor3 = Color3.new(1, 1, 1)
		local v57 = Instance.new("TextLabel")
		v57.Name = "Line"
		v57.BackgroundTransparency = 1
		v57.AnchorPoint = Vector2.new(0.5, 0.5)
		v57.Position = UDim2.fromScale(0.735, 0.47)
		v57.Size = UDim2.fromScale(0.46, 0.26)
		v57.FontFace = v_u_23
		v57.TextScaled = true
		v57.TextWrapped = true
		v57.TextColor3 = Color3.new(1, 1, 1)
		v57.Text = "FOR THE WHOLE SERVER!"
		v57.ZIndex = 4
		local v58 = Instance.new("UIStroke")
		v58.Thickness = 2
		v58.Color = Color3.new(0, 0, 0)
		v58.Parent = v57
		v57.Parent = v51
		v_u_43 = v57
		local v59 = v51:FindFirstChild("Purchase")
		if v59 and v59:IsA("GuiButton") then
			v59:SetAttribute("Ui-Product", "serverBoost2")
			local v60 = v59:FindFirstChild("PriceTag")
			if not (v60 and v60:IsA("TextLabel")) then
				v60 = nil
			end
			v_u_44 = v60
			v59.Activated:Connect(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_15, (ref) v_u_8, (ref) v_u_24, (copy) v_u_47, (ref) v_u_9
				if v_u_6.storeBuy("serverBoost2") then
					return
				elseif v_u_15.sellable() then
					v_u_9.buyProduct("serverBoost2")
				else
					v_u_8.play("Error")
					v_u_24((("The server boost is at its %* hour max!"):format((v_u_47.cap or 120) // 60)))
				end
			end)
			v51.Parent = v49
			v_u_45 = v51
		end
	else
		return
	end
end
local function v_u_67() -- name: updateCard
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_15, (ref) v_u_43, (copy) v_u_14, (ref) v_u_44
	local v62 = v_u_9.product("serverBoost2")
	if v62 then
		if v62.id == 0 then
			local v63 = v_u_3:IsStudio()
			if v63 then
				v63 = v_u_5:GetAttribute("DevOffers") == true
			end
			if not v63 then
				v62 = nil
			end
		end
	else
		v62 = nil
	end
	local v64 = v_u_15.left()
	local v65 = v_u_43
	if v65 then
		v65.Text = v64 <= 0 and "FOR THE WHOLE SERVER!" or "ON NOW " .. v_u_14.clock(v64)
	end
	local v66 = v_u_44
	if v66 and v62 then
		v66.Text = not v_u_15.sellable() and "MAX" or v_u_9.priceText(v62.price)
	end
end
local v_u_68 = nil
local v_u_69 = {}
local v_u_70 = {}
local v_u_71 = nil
local v_u_72 = 0
local function v_u_77(p73, p74) -- name: labels
	local v75 = {}
	for _, v76 in p73:GetChildren() do
		if not v76:IsA("TextLabel") or v76.Name ~= p74 and v76.Name ~= p74 .. "Shadow" then
			continue
		end
		table.insert(v75, v76)
	end
	return v75
end
local function v_u_82(p78, p79, p80) -- name: setText
	for _, v81 in p78 do
		v81.Text = p79
		if string.find(v81.Name, "Shadow") then
			continue
		end
		v81.TextColor3 = p80
	end
end
local function v_u_89(p83) -- name: buildBanner
	-- upvalues: (copy) v_u_28, (ref) v_u_69, (copy) v_u_77, (ref) v_u_70, (ref) v_u_71, (ref) v_u_68
	local v84 = v_u_28(p83, "HUD.Overlay.Title")
	local v85 = v_u_28(p83, "HUD.Overlay")
	if v84 and (v84:IsA("Frame") and v85) then
		local v86 = v84:Clone()
		v86.Name = "ServerBoostBanner"
		v86.Visible = false
		v86.Position = UDim2.fromScale(0.5, 0.345)
		v86.Size = UDim2.fromScale(0.5, 0.12)
		local v87 = v86:FindFirstChildOfClass("UIAspectRatioConstraint")
		if v87 then
			v87.AspectRatio = 4.6
		end
		v_u_69 = v_u_77(v86, "Main")
		v_u_70 = v_u_77(v86, "Sub")
		local v88 = Instance.new("UIScale")
		v88.Scale = 1
		v88.Parent = v86
		v_u_71 = v88
		v86.Parent = v85
		v_u_68 = v86
	end
end
local function v_u_99(p90, p91, p92) -- name: showBanner
	-- upvalues: (ref) v_u_68, (ref) v_u_72, (copy) v_u_82, (ref) v_u_69, (copy) v_u_21, (ref) v_u_70, (copy) v_u_22, (ref) v_u_71, (copy) v_u_4
	local v_u_93 = v_u_68
	if v_u_93 then
		v_u_72 = v_u_72 + 1
		local v_u_94 = v_u_72
		v_u_82(v_u_69, ("x%* CHAKRA FOR %* MIN!"):format(p91, p92), v_u_21)
		v_u_82(v_u_70, string.upper(p90) .. " GAVE IT TO THE WHOLE SERVER!", v_u_22)
		v_u_93.Visible = true
		local v95 = v_u_71
		if v95 then
			v95.Scale = 0.2
			local v96 = Enum.EasingStyle.Back
			v_u_4:Create(v95, TweenInfo.new(0.35, v96 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
		task.delay(5, function()
			-- upvalues: (copy) v_u_94, (ref) v_u_72, (ref) v_u_71, (ref) v_u_4, (copy) v_u_93
			if v_u_94 == v_u_72 then
				local v97 = v_u_71
				if v97 then
					local v98 = Enum.EasingStyle.Quad
					v_u_4:Create(v97, TweenInfo.new(0.25, v98 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = 0
					}):Play()
				end
				task.wait(0.25)
				if v_u_94 == v_u_72 then
					v_u_93.Visible = false
				end
			end
		end)
	end
end
local function v_u_110() -- name: bought
	-- upvalues: (copy) v_u_5, (ref) v_u_24, (copy) v_u_14, (copy) v_u_19, (copy) v_u_8, (copy) v_u_7, (copy) v_u_10, (copy) v_u_15, (copy) v_u_99
	local v100 = v_u_5:GetAttribute("ServerBoostBy")
	local v_u_101 = (type(v100) ~= "string" or v100 == "") and "Someone" or v100
	local v102 = v_u_5:GetAttribute("ServerBoostMult")
	local v_u_103 = type(v102) ~= "number" and 2 or v102
	local v104 = v_u_5:GetAttribute("ServerBoostMinutes")
	local v_u_105 = type(v104) ~= "number" and 15 or v104
	v_u_24(v_u_14.announce(v_u_101, v_u_103, v_u_105), v_u_19)
	v_u_8.play("Boost")
	local v106 = v_u_5:GetAttribute("ServerBoostBuys")
	local v_u_107 = type(v106) ~= "number" and 0 or v106
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_10, (ref) v_u_5, (copy) v_u_107, (ref) v_u_15, (ref) v_u_99, (copy) v_u_101, (copy) v_u_103, (copy) v_u_105
		local v108 = 0
		while v_u_7.current() ~= nil and v108 < 30 do
			v108 = v108 + task.wait(0.5)
		end
		if v_u_7.current() == nil and not v_u_10.active() then
			local v109 = v_u_5:GetAttribute("ServerBoostBuys")
			if (type(v109) ~= "number" and 0 or v109) == v_u_107 and v_u_15.left() > 0 then
				v_u_99(v_u_101, v_u_103, v_u_105)
			end
		end
	end)
end
local function v_u_123(p111) -- name: bindTimer
	-- upvalues: (copy) v_u_28, (copy) v_u_12, (copy) v_u_20, (copy) v_u_15, (copy) v_u_4, (copy) v_u_5, (copy) v_u_14, (ref) v_u_45, (copy) v_u_67
	local v112 = v_u_28(p111, "HUD.Boosts")
	local v113
	if v112 then
		v113 = v112:FindFirstChild("chakra")
	else
		v113 = v112
	end
	if v112 and (v113 and v113:IsA("GuiObject")) then
		local v114 = v113:Clone()
		v114.Name = "chakraServer"
		v114.Visible = false
		v114.Size = UDim2.new(1.3, 0, v113.Size.Y.Scale, v113.Size.Y.Offset)
		local v115 = v114:FindFirstChild("Icon")
		if v115 and v115:IsA("ImageLabel") then
			v115.Image = v_u_12.Icon.BoostChakra or v115.Image
		end
		local v116 = v114:FindFirstChild("Text")
		if not (v116 and v116:IsA("TextLabel")) then
			v116 = nil
		end
		if v116 then
			v116.TextColor3 = v_u_20
		end
		local v117 = Instance.new("UIScale")
		v117.Name = "Pop"
		v117.Parent = v114
		v114.Parent = v112
		while v112.Parent do
			local v118 = v_u_15.left()
			if v118 > 0 and not v114.Visible then
				v114.Visible = true
				v117.Scale = 0.3
				local v119 = Enum.EasingStyle.Back
				v_u_4:Create(v117, TweenInfo.new(0.35, v119 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			elseif v118 <= 0 and v114.Visible then
				v114.Visible = false
			end
			if v118 > 0 and v116 then
				local v120 = v_u_5:GetAttribute("ServerBoostMult")
				v116.Text = ("Server x%* Chakra %*"):format(type(v120) ~= "number" and 2 or v120, (v_u_14.clock(v118)))
			end
			local v121 = v_u_45
			if v121 and v121:IsDescendantOf(p111) then
				local v122 = v_u_28(p111, "Frames.Store")
				if v122 and (v122:IsA("GuiObject") and v122.Visible) then
					v_u_67()
				end
			end
			task.wait(0.2)
		end
	end
end
function v_u_15.start(p124) -- name: start
	-- upvalues: (ref) v_u_24, (copy) v_u_16, (copy) v_u_61, (copy) v_u_67, (copy) v_u_9, (copy) v_u_89, (copy) v_u_5, (copy) v_u_110, (copy) v_u_123
	v_u_24 = p124
	local v125 = v_u_16:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	if v125 then
		v_u_61(v125)
		v_u_67()
		v_u_9.pricesChanged:Connect(v_u_67)
		v_u_89(v125)
		v_u_5:GetAttributeChangedSignal("ServerBoostBuys"):Connect(v_u_110)
		task.spawn(v_u_123, v125)
	end
end
return v_u_15