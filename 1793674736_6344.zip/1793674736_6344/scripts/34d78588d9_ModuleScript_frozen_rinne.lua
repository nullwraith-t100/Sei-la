local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(14, 18, 30)
local v_u_7 = Color3.fromRGB(40, 110, 200)
local v_u_8 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_9 = CFrame.Angles(0, 1.5707963267948966, 0)
local function v_u_22(p10, p11, p12, p13, p14) -- name: snowAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
	local v15 = p11.fx
	local v_u_16 = Instance.new("Attachment")
	local v17 = 0.8 * v15
	v_u_16.Position = Vector3.new(0, v17, 0)
	local v_u_18 = Instance.new("ParticleEmitter")
	v_u_18.Texture = v_u_5.Snowflake
	v_u_18.Color = ColorSequence.new(p12)
	v_u_18.LightEmission = 0.35
	v_u_18.LightInfluence = 0
	v_u_18.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.15, p14 * v15), NumberSequenceKeypoint.new(1, p14 * 0.6 * v15) })
	v_u_18.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 1) })
	v_u_18.Lifetime = NumberRange.new(1.2, 2)
	v_u_18.Speed = NumberRange.new(1.2 * v15, 2.6 * v15)
	v_u_18.SpreadAngle = Vector2.new(180, 180)
	v_u_18.Rotation = NumberRange.new(0, 360)
	v_u_18.RotSpeed = NumberRange.new(-90, 90)
	v_u_18.Drag = 1.2
	local v19 = -1.2 * v15
	v_u_18.Acceleration = Vector3.new(0, v19, 0)
	v_u_18:SetAttribute("BaseRate", p13)
	v_u_18.Rate = p13 * v_u_4.formRate()
	v_u_18.Enabled = true
	v_u_18.Parent = v_u_16
	v_u_16.Parent = p11.root
	p10.own(p11, v_u_16)
	local v20 = p11.stops
	local function v21()
		-- upvalues: (copy) v_u_18, (ref) v_u_1, (copy) v_u_16
		v_u_18.Enabled = false
		v_u_1:AddItem(v_u_16, 2.2)
	end
	table.insert(v20, v21)
	return v_u_18
end
return function(p_u_23)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_1, (copy) v_u_9, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7, (copy) v_u_22
	return {
		["w4_frozen_rinne"] = function(p_u_24, p25)
			-- upvalues: (ref) v_u_3, (copy) p_u_23, (ref) v_u_5, (ref) v_u_1, (ref) v_u_9, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_22
			local v_u_26 = v_u_3.color(p25.color)
			local v_u_27 = v_u_3.color(p25.color2)
			local v_u_28 = p_u_24.character:GetScale()
			local v_u_29 = 2.4 * v_u_28
			local v_u_30 = CFrame.new(0, 1.2 * v_u_28, 1.6 * v_u_28)
			local v_u_31 = nil
			local v_u_41 = p_u_23.throb(p_u_24, 4.2, 1.6, 1.4, function(p32)
				-- upvalues: (copy) v_u_30, (ref) v_u_3, (copy) v_u_27, (copy) v_u_28, (ref) p_u_23, (copy) p_u_24, (copy) v_u_26, (ref) v_u_5, (ref) v_u_31, (copy) v_u_29, (ref) v_u_1
				local v33 = p32 * v_u_30
				v_u_3.flash(v33.Position, v_u_27, 6 * v_u_28, 0.25)
				v_u_3.ring(p_u_23.feetAt(p_u_24, p32, 0.15), v_u_26, 5 * p_u_24.fx, 0.45, v_u_5.Ring)
				if v_u_31 then
					v_u_31:Emit(10)
				end
				for v34 = 1, 4 do
					local v35 = v34 / 4 * 3.141592653589793 * 2 + math.random()
					local v36 = v33 * CFrame.new(math.cos(v35) * v_u_29, math.sin(v35) * v_u_29, 0)
					local v37 = v_u_3.part(Vector3.new(0.35, 0.35, 0.35) * v_u_28, v36, v_u_27, {
						["material"] = Enum.Material.Ice
					})
					local v38 = v_u_3.tween
					local v39 = {
						["CFrame"] = nil,
						["Transparency"] = 1
					}
					local v40 = 3 * v_u_28
					v39.CFrame = (v36 - Vector3.new(0, v40, 0)) * CFrame.Angles(2, 1, 0)
					v38(v37, 0.7, v39, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v37, 0.75)
				end
			end)
			local v_u_42 = 0
			local v_u_43 = 0
			local v44 = p_u_24.ticks
			local function v47(_, _, p45)
				-- upvalues: (copy) v_u_41, (ref) v_u_42, (ref) v_u_43
				local v46 = 1 - v_u_41()
				v_u_42 = v_u_42 + p45 * 0.3 * v46
				v_u_43 = v_u_43 - p45 * 0.9 * v46
			end
			table.insert(v44, v47)
			local v_u_56 = p_u_23.group(p_u_24, function(p48, p49)
				-- upvalues: (copy) v_u_30, (copy) v_u_28
				local v50 = p48 * v_u_30
				local v51 = CFrame.new
				local v52 = p49 * 1.4
				local v53 = v50 * v51(0, math.sin(v52) * 0.08 * v_u_28, 0)
				local v54 = CFrame.Angles
				local v55 = p49 * 0.8
				return v53 * v54(math.sin(v55) * 0.08, 0, 0)
			end)
			local v57 = p_u_23.pin
			local v58 = p_u_23.disc
			local v59 = 0.1 * v_u_28
			local v60 = v_u_29 * 2
			local v61 = v_u_29 * 2
			v57(p_u_24, v_u_56, v58(Vector3.new(v59, v60, v61), v_u_26, 0.86), v_u_9)
			p_u_23.pin(p_u_24, v_u_56, p_u_23.picture(v_u_29 * 2 + 0.5 * v_u_28, v_u_5.Ring, v_u_27, 0), v_u_8)
			p_u_23.pin(p_u_24, v_u_56, p_u_23.picture(3.3 * v_u_28, v_u_5.Ring, v_u_6, 0.1), v_u_8 * CFrame.new(0, -0.03, 0))
			p_u_23.pin(p_u_24, v_u_56, p_u_23.picture(1.9 * v_u_28, v_u_5.Ring, v_u_6, 0.1), v_u_8 * CFrame.new(0, -0.05, 0))
			local v_u_62 = v_u_43
			local v_u_63 = v_u_42
			for v64 = 1, 12 do
				local v_u_65 = (v64 % 2 == 0 and 1 or 0.6) * v_u_28
				local v_u_66 = v64 / 12 * 3.141592653589793 * 2
				local v67 = p_u_23.add
				local v68 = p_u_23.bar
				local v69 = 0.22 * v_u_28
				local v70 = 0.22 * v_u_28
				v67(p_u_24, v68(Vector3.new(v69, v70, v_u_65), v_u_27, 0), function()
					-- upvalues: (copy) v_u_41, (copy) v_u_28, (copy) v_u_56, (copy) v_u_66, (ref) v_u_63, (copy) v_u_29, (copy) v_u_65, (ref) v_u_9
					local v71 = v_u_41() * 0.7 * v_u_28
					return v_u_56.cf * CFrame.Angles(0, 0, v_u_66 + v_u_63) * CFrame.new(v_u_29 - v_u_65 / 2 - v71, 0, 0) * v_u_9 * CFrame.Angles(0, 0, 0.7853981633974483)
				end)
			end
			local v_u_72 = 1.65 * v_u_28
			for v73 = 1, 3 do
				local v_u_74 = v73 / 3 * 3.141592653589793 * 2
				p_u_23.add(p_u_24, p_u_23.dark(p_u_23.ball(0.46 * v_u_28, v_u_6, 0, Enum.Material.SmoothPlastic)), function()
					-- upvalues: (copy) v_u_74, (ref) v_u_62, (copy) v_u_56, (copy) v_u_72, (copy) v_u_28
					local v75 = v_u_74 + v_u_62
					return v_u_56.cf * CFrame.new(math.cos(v75) * v_u_72, math.sin(v75) * v_u_72, -0.08 * v_u_28)
				end)
				p_u_23.add(p_u_24, p_u_23.dark(p_u_23.bar(Vector3.new(0.16, 0.16, 0.55) * v_u_28, v_u_6, 0, Enum.Material.SmoothPlastic)), function()
					-- upvalues: (copy) v_u_74, (ref) v_u_62, (copy) v_u_72, (copy) v_u_28, (copy) v_u_56
					local v76 = v_u_74 + v_u_62
					local v77 = math.cos(v76) * v_u_72
					local v78 = math.sin(v76) * v_u_72
					local v79 = -0.08 * v_u_28
					local v80 = Vector3.new(v77, v78, v79)
					local v81 = -math.sin(v76)
					local v82 = math.cos(v76)
					local v83 = v80 + Vector3.new(v81, v82, 0) * 0.5 * v_u_28
					return v_u_56.cf * CFrame.lookAt((v80 + v83) / 2, v83)
				end)
			end
			p_u_23.pin(p_u_24, v_u_56, p_u_23.ball(0.75 * v_u_28, v_u_7, 0), CFrame.identity)
			local v84 = p_u_23.pin
			local v85 = p_u_23.disc
			local v86 = 0.82 * v_u_28
			local v87 = 0.36 * v_u_28
			local v88 = 0.36 * v_u_28
			v84(p_u_24, v_u_56, v85(Vector3.new(v86, v87, v88), v_u_6, 0, Enum.Material.SmoothPlastic), v_u_9)
			v_u_31 = v_u_22(p_u_23, p_u_24, v_u_27, 6, 0.2)
			p_u_23.particles(p_u_24, "AuraMode", v_u_26, {
				["rate"] = 0.45,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_23.particles(p_u_24, "Petals", v_u_27, {
				["rate"] = 0.9,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end