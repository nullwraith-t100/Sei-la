local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = {
	"CameraMinZoomDistance",
	"CameraMaxZoomDistance",
	"CameraMode",
	"DevCameraOcclusionMode",
	"DevComputerCameraMode",
	"DevTouchCameraMode",
	"DevComputerMovementMode",
	"DevTouchMovementMode",
	"DevEnableMouseLock"
}
local v_u_3 = {
	"ComputerCameraMovementMode",
	"ComputerMovementMode",
	"ControlMode",
	"GamepadCameraSensitivity",
	"MouseSensitivity",
	"RotationType",
	"TouchCameraMovementMode",
	"TouchMovementMode"
}
local v_u_4 = game:GetService("Players")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("VRService")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v9 = require(script.Parent:WaitForChild("CommonUtils"))
local v_u_10 = v9.get("ConnectionUtil")
local v11 = v9.get("FlagUtil")
local v_u_12 = require(script:WaitForChild("CameraUtils"))
require(script:WaitForChild("CameraInput"))
local v_u_13 = require(script:WaitForChild("ClassicCamera"))
local v_u_14 = require(script:WaitForChild("OrbitalCamera"))
local v_u_15 = require(script:WaitForChild("LegacyCamera"))
local v_u_16 = require(script:WaitForChild("VehicleCamera"))
local v_u_17 = require(script:WaitForChild("VRCamera"))
local v_u_18 = require(script:WaitForChild("VRVehicleCamera"))
local v_u_19 = require(script:WaitForChild("Invisicam"))
local v_u_20 = require(script:WaitForChild("Poppercam"))
local v_u_21 = require(script:WaitForChild("TransparencyController"))
local v_u_22 = require(script:WaitForChild("MouseLockController"))
local v_u_23 = {}
local v_u_24 = {}
if v_u_4.LocalPlayer then
	local v25 = v_u_4.LocalPlayer
	assert(v25, "Strict typing check")
	local v26 = v_u_4.LocalPlayer:WaitForChild("PlayerScripts")
	v26:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Default)
	v26:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Follow)
	v26:RegisterTouchCameraMovementMode(Enum.TouchCameraMovementMode.Classic)
	v26:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Default)
	v26:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Follow)
	v26:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.Classic)
	v26:RegisterComputerCameraMovementMode(Enum.ComputerCameraMovementMode.CameraToggle)
	local v_u_27 = v11.getUserFlag("UserPlayerConnectionMemoryLeak")
	local v_u_28 = v11.getUserFlag("UserPSFixCameraControllerReset")
	local v_u_29 = v11.getUserFlag("UserVRFixCameraCloseArticulation")
	local v_u_30 = FFlagUserOrthographicOcclusion
	if v_u_30 then
		v_u_30 = pcall(function()
			return Instance.new("Camera").ProjectionType
		end)
	end
	local v_u_31 = v9.get("VRFirstPersonState")
	function v_u_1.new() -- name: new
		-- upvalues: (copy) v_u_21, (copy) v_u_27, (copy) v_u_10, (copy) v_u_1, (copy) v_u_4, (copy) v_u_22, (copy) v_u_2, (copy) v_u_3, (copy) v_u_8, (copy) v_u_6
		local v32 = {
			["activeTransparencyController"] = v_u_21.new()
		}
		local v33
		if v_u_27 then
			v33 = v_u_10.new()
		else
			v33 = nil
		end
		v32.connectionUtil = v33
		local v34 = v_u_1
		local v_u_35 = setmetatable(v32, v34)
		v_u_35.activeCameraController = nil
		v_u_35.activeOcclusionModule = nil
		v_u_35.activeMouseLockController = nil
		v_u_35.currentComputerCameraMovementMode = nil
		v_u_35.cameraSubjectChangedConn = nil
		v_u_35.cameraTypeChangedConn = nil
		for _, v36 in pairs(v_u_4:GetPlayers()) do
			v_u_35:OnPlayerAdded(v36)
		end
		v_u_4.PlayerAdded:Connect(function(p37)
			-- upvalues: (copy) v_u_35
			v_u_35:OnPlayerAdded(p37)
		end)
		if v_u_27 then
			v_u_4.PlayerRemoving:Connect(function(p38)
				-- upvalues: (copy) v_u_35
				v_u_35:OnPlayerRemoving(p38)
			end)
		end
		v_u_35.activeTransparencyController:Enable(true)
		v_u_35.activeMouseLockController = v_u_22.new()
		local v39 = v_u_35.activeMouseLockController
		assert(v39, "Strict typing check")
		local v40 = v_u_35.activeMouseLockController:GetBindableToggleEvent()
		if v40 then
			v40:Connect(function()
				-- upvalues: (copy) v_u_35
				v_u_35:OnMouseLockToggled()
			end)
		end
		v_u_35:ActivateCameraController()
		v_u_35:ActivateOcclusionModule(v_u_4.LocalPlayer.DevCameraOcclusionMode)
		v_u_35:OnCurrentCameraChanged()
		for _, v_u_41 in pairs(v_u_2) do
			v_u_4.LocalPlayer:GetPropertyChangedSignal(v_u_41):Connect(function()
				-- upvalues: (copy) v_u_35, (copy) v_u_41
				v_u_35:OnLocalPlayerCameraPropertyChanged(v_u_41)
			end)
		end
		for _, v_u_42 in pairs(v_u_3) do
			v_u_8:GetPropertyChangedSignal(v_u_42):Connect(function()
				-- upvalues: (copy) v_u_35, (copy) v_u_42
				v_u_35:OnUserGameSettingsPropertyChanged(v_u_42)
			end)
		end
		game.Workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (copy) v_u_35
			v_u_35:OnCurrentCameraChanged()
		end)
		v_u_6:GetPropertyChangedSignal("PreferredInput"):Connect(function()
			-- upvalues: (copy) v_u_35
			v_u_35:OnPreferredInputChanged()
		end)
		return v_u_35
	end
	function v_u_1.GetCameraMovementModeFromSettings(_) -- name: GetCameraMovementModeFromSettings
		-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_6, (copy) v_u_8
		if v_u_4.LocalPlayer.CameraMode == Enum.CameraMode.LockFirstPerson then
			return v_u_12.ConvertCameraModeEnumToStandard(Enum.ComputerCameraMovementMode.Classic)
		else
			local v43, v44
			if v_u_6.PreferredInput == Enum.PreferredInput.Touch then
				v43 = v_u_12.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevTouchCameraMode)
				v44 = v_u_12.ConvertCameraModeEnumToStandard(v_u_8.TouchCameraMovementMode)
			else
				v43 = v_u_12.ConvertCameraModeEnumToStandard(v_u_4.LocalPlayer.DevComputerCameraMode)
				v44 = v_u_12.ConvertCameraModeEnumToStandard(v_u_8.ComputerCameraMovementMode)
			end
			if v43 == Enum.DevComputerCameraMovementMode.UserChoice then
				return v44
			else
				return v43
			end
		end
	end
	function v_u_1.ActivateOcclusionModule(p45, p46) -- name: ActivateOcclusionModule
		-- upvalues: (copy) v_u_20, (copy) v_u_19, (copy) v_u_24, (copy) v_u_4
		local v47
		if p46 == Enum.DevCameraOcclusionMode.Zoom then
			v47 = v_u_20
		else
			if p46 ~= Enum.DevCameraOcclusionMode.Invisicam then
				warn("CameraScript ActivateOcclusionModule called with unsupported mode")
				return
			end
			v47 = v_u_19
		end
		p45.occlusionMode = p46
		if p45.activeOcclusionModule and p45.activeOcclusionModule:GetOcclusionMode() == p46 then
			if not p45.activeOcclusionModule:GetEnabled() then
				p45.activeOcclusionModule:Enable(true)
			end
		else
			local v48 = p45.activeOcclusionModule
			p45.activeOcclusionModule = v_u_24[v47]
			if not p45.activeOcclusionModule then
				p45.activeOcclusionModule = v47.new()
				if p45.activeOcclusionModule then
					v_u_24[v47] = p45.activeOcclusionModule
				end
			end
			if p45.activeOcclusionModule then
				if p45.activeOcclusionModule:GetOcclusionMode() ~= p46 then
					warn("CameraScript ActivateOcclusionModule mismatch: ", p45.activeOcclusionModule:GetOcclusionMode(), "~=", p46)
				end
				if v48 then
					if v48 == p45.activeOcclusionModule then
						warn("CameraScript ActivateOcclusionModule failure to detect already running correct module")
					else
						v48:Enable(false)
					end
				end
				if p46 == Enum.DevCameraOcclusionMode.Invisicam then
					if v_u_4.LocalPlayer.Character then
						p45.activeOcclusionModule:CharacterAdded(v_u_4.LocalPlayer.Character, v_u_4.LocalPlayer)
					end
				else
					for _, v49 in pairs(v_u_4:GetPlayers()) do
						if not (v49 and v49.Character) then
							continue
						end
						p45.activeOcclusionModule:CharacterAdded(v49.Character, v49)
					end
					p45.activeOcclusionModule:OnCameraSubjectChanged(game.Workspace.CurrentCamera.CameraSubject)
				end
				p45.activeOcclusionModule:Enable(true)
			end
		end
	end
	function v_u_1.ShouldUseVehicleCamera(p50) -- name: ShouldUseVehicleCamera
		local v51 = workspace.CurrentCamera
		if not v51 then
			return false
		end
		local v52 = v51.CameraType
		local v53 = v51.CameraSubject
		local v54 = v52 == Enum.CameraType.Custom and true or v52 == Enum.CameraType.Follow
		local v55 = v53 and v53:IsA("VehicleSeat") or false
		local v56 = p50.occlusionMode ~= Enum.DevCameraOcclusionMode.Invisicam
		if v55 then
			if not v54 then
				v56 = v54
			end
		else
			v56 = v55
		end
		return v56
	end
	function v_u_1.ActivateCameraController(p57) -- name: ActivateCameraController
		-- upvalues: (copy) v_u_15, (copy) v_u_7, (copy) v_u_17, (copy) v_u_13, (copy) v_u_14, (copy) v_u_18, (copy) v_u_16, (copy) v_u_23, (copy) v_u_28
		local v58 = workspace.CurrentCamera.CameraType
		local v59 = p57:GetCameraMovementModeFromSettings()
		local v60 = nil
		if v58 == Enum.CameraType.Scriptable then
			if p57.activeCameraController then
				p57.activeCameraController:Enable(false)
				p57.activeCameraController = nil
			end
		else
			if v58 == Enum.CameraType.Custom then
				v59 = p57:GetCameraMovementModeFromSettings()
			elseif v58 == Enum.CameraType.Track then
				v59 = Enum.ComputerCameraMovementMode.Classic
			elseif v58 == Enum.CameraType.Follow then
				v59 = Enum.ComputerCameraMovementMode.Follow
			elseif v58 == Enum.CameraType.Orbital then
				v59 = Enum.ComputerCameraMovementMode.Orbital
			elseif v58 == Enum.CameraType.Attach or (v58 == Enum.CameraType.Watch or v58 == Enum.CameraType.Fixed) then
				v60 = v_u_15
			else
				warn("CameraScript encountered an unhandled Camera.CameraType value: ", v58)
			end
			if not v60 then
				if v_u_7.VREnabled then
					v60 = v_u_17
				elseif v59 == Enum.ComputerCameraMovementMode.Classic or (v59 == Enum.ComputerCameraMovementMode.Follow or (v59 == Enum.ComputerCameraMovementMode.Default or v59 == Enum.ComputerCameraMovementMode.CameraToggle)) then
					v60 = v_u_13
				else
					if v59 ~= Enum.ComputerCameraMovementMode.Orbital then
						warn("ActivateCameraController did not select a module.")
						return
					end
					v60 = v_u_14
				end
			end
			if p57:ShouldUseVehicleCamera() then
				if v_u_7.VREnabled then
					v60 = v_u_18
				else
					v60 = v_u_16
				end
			end
			local v61
			if v_u_23[v60] then
				v61 = v_u_23[v60]
				if v_u_28 then
					if v61.Reset and p57.activeCameraController ~= v61 then
						v61:Reset()
					end
				elseif v61.Reset then
					v61:Reset()
				end
			else
				v61 = v60.new()
				v_u_23[v60] = v61
			end
			if p57.activeCameraController then
				if p57.activeCameraController == v61 then
					if not p57.activeCameraController:GetEnabled() then
						p57.activeCameraController:Enable(true)
					end
				else
					if v61.HandleSubjectDistance then
						v61:HandleSubjectDistance(p57.activeCameraController)
					end
					p57.activeCameraController:Enable(false)
					p57.activeCameraController = v61
					p57.activeCameraController:Enable(true)
				end
			elseif v61 ~= nil then
				p57.activeCameraController = v61
				local v62 = p57.activeCameraController
				assert(v62, "Strict typing check")
				p57.activeCameraController:Enable(true)
			end
			if p57.activeCameraController then
				p57.activeCameraController:SetCameraMovementMode(v59)
				p57.activeCameraController:SetCameraType(v58)
			end
		end
	end
	function v_u_1.OnCameraSubjectChanged(p63) -- name: OnCameraSubjectChanged
		local v64 = workspace.CurrentCamera
		local v65
		if v64 then
			v65 = v64.CameraSubject
		else
			v65 = nil
		end
		if p63.activeTransparencyController then
			p63.activeTransparencyController:SetSubject(v65)
		end
		if p63.activeOcclusionModule then
			p63.activeOcclusionModule:OnCameraSubjectChanged(v65)
		end
		p63:ActivateCameraController()
	end
	function v_u_1.OnCameraTypeChanged(p66, p67) -- name: OnCameraTypeChanged
		-- upvalues: (copy) v_u_6, (copy) v_u_12
		if p67 == Enum.CameraType.Scriptable and v_u_6.MouseBehavior == Enum.MouseBehavior.LockCenter then
			v_u_12.restoreMouseBehavior()
		end
		p66:ActivateCameraController()
	end
	function v_u_1.OnCurrentCameraChanged(p_u_68) -- name: OnCurrentCameraChanged
		local v_u_69 = game.Workspace.CurrentCamera
		if v_u_69 then
			if p_u_68.cameraSubjectChangedConn then
				p_u_68.cameraSubjectChangedConn:Disconnect()
			end
			if p_u_68.cameraTypeChangedConn then
				p_u_68.cameraTypeChangedConn:Disconnect()
			end
			p_u_68.cameraSubjectChangedConn = v_u_69:GetPropertyChangedSignal("CameraSubject"):Connect(function()
				-- upvalues: (copy) p_u_68
				p_u_68:OnCameraSubjectChanged()
			end)
			p_u_68.cameraTypeChangedConn = v_u_69:GetPropertyChangedSignal("CameraType"):Connect(function()
				-- upvalues: (copy) p_u_68, (copy) v_u_69
				p_u_68:OnCameraTypeChanged(v_u_69.CameraType)
			end)
			p_u_68:OnCameraSubjectChanged()
			p_u_68:OnCameraTypeChanged(v_u_69.CameraType)
		end
	end
	function v_u_1.OnLocalPlayerCameraPropertyChanged(p70, p71) -- name: OnLocalPlayerCameraPropertyChanged
		-- upvalues: (copy) v_u_4
		if p71 == "CameraMode" then
			if v_u_4.LocalPlayer.CameraMode ~= Enum.CameraMode.LockFirstPerson then
				if v_u_4.LocalPlayer.CameraMode == Enum.CameraMode.Classic then
					p70:ActivateCameraController()
				else
					warn("Unhandled value for property player.CameraMode: ", v_u_4.LocalPlayer.CameraMode)
				end
			end
			if not p70.activeCameraController or p70.activeCameraController:GetModuleName() ~= "ClassicCamera" then
				p70:ActivateCameraController()
			end
			if p70.activeCameraController then
				p70.activeCameraController:UpdateForDistancePropertyChange()
				return
			end
		else
			if p71 == "DevComputerCameraMode" or p71 == "DevTouchCameraMode" then
				p70:ActivateCameraController()
				return
			end
			if p71 == "DevCameraOcclusionMode" then
				p70:ActivateOcclusionModule(v_u_4.LocalPlayer.DevCameraOcclusionMode)
				return
			end
			if p71 == "CameraMinZoomDistance" or p71 == "CameraMaxZoomDistance" then
				if p70.activeCameraController then
					p70.activeCameraController:UpdateForDistancePropertyChange()
					return
				end
			else
				if p71 == "DevTouchMovementMode" then
					return
				end
				if p71 == "DevComputerMovementMode" then
					return
				end
				local _ = p71 == "DevEnableMouseLock"
			end
		end
	end
	function v_u_1.OnUserGameSettingsPropertyChanged(p72, p73) -- name: OnUserGameSettingsPropertyChanged
		if p73 == "ComputerCameraMovementMode" then
			p72:ActivateCameraController()
		end
	end
	function v_u_1.OnPreferredInputChanged(p74) -- name: OnPreferredInputChanged
		p74:ActivateCameraController()
	end
	function v_u_1.Update(p75, _, p76) -- name: Update
		-- upvalues: (copy) v_u_29, (copy) v_u_7, (copy) v_u_31, (copy) v_u_30
		if p75.activeCameraController then
			p75.activeCameraController:UpdateMouseBehavior()
			local v77, v78 = p75.activeCameraController:Update(p76)
			if v_u_29 and (v_u_7.VREnabled and p75.activeCameraController.IsInFirstPerson) then
				v_u_31.inFirstPerson = p75.activeCameraController:IsInFirstPerson()
			end
			local v79 = game.Workspace.CurrentCamera
			if v_u_30 then
				if p75.activeOcclusionModule and (not p75.activeCameraController.skipOcclusion and v79.ProjectionType ~= Enum.ProjectionType.Orthographic) then
					v77, v78 = p75.activeOcclusionModule:Update(p76, v77, v78)
				end
			elseif p75.activeOcclusionModule and not p75.activeCameraController.skipOcclusion then
				v77, v78 = p75.activeOcclusionModule:Update(p76, v77, v78)
			end
			v79.CFrame = v77
			v79.Focus = v78
			if p75.activeTransparencyController then
				p75.activeTransparencyController:Update(p76)
				return
			end
		elseif v_u_29 and v_u_7.VREnabled then
			v_u_31.inFirstPerson = false
		end
	end
	function v_u_1.OnCharacterAdded(p80, p81, p82) -- name: OnCharacterAdded
		if p80.activeOcclusionModule then
			p80.activeOcclusionModule:CharacterAdded(p81, p82)
		end
	end
	function v_u_1.OnCharacterRemoving(p83, p84, p85) -- name: OnCharacterRemoving
		if p83.activeOcclusionModule then
			p83.activeOcclusionModule:CharacterRemoving(p84, p85)
		end
	end
	function v_u_1.OnPlayerAdded(p_u_86, p_u_87) -- name: OnPlayerAdded
		-- upvalues: (copy) v_u_27
		if v_u_27 then
			if p_u_86.connectionUtil then
				p_u_86.connectionUtil:trackConnection(("%*CharacterAdded"):format(p_u_87.UserId), p_u_87.CharacterAdded:Connect(function(p88)
					-- upvalues: (copy) p_u_86, (copy) p_u_87
					p_u_86:OnCharacterAdded(p88, p_u_87)
				end))
				p_u_86.connectionUtil:trackConnection(("%*CharacterRemoving"):format(p_u_87.UserId), p_u_87.CharacterRemoving:Connect(function(p89)
					-- upvalues: (copy) p_u_86, (copy) p_u_87
					p_u_86:OnCharacterRemoving(p89, p_u_87)
				end))
				return
			end
		else
			p_u_87.CharacterAdded:Connect(function(p90)
				-- upvalues: (copy) p_u_86, (copy) p_u_87
				p_u_86:OnCharacterAdded(p90, p_u_87)
			end)
			p_u_87.CharacterRemoving:Connect(function(p91)
				-- upvalues: (copy) p_u_86, (copy) p_u_87
				p_u_86:OnCharacterRemoving(p91, p_u_87)
			end)
		end
	end
	function v_u_1.OnPlayerRemoving(p92, p93) -- name: OnPlayerRemoving
		if p92.connectionUtil then
			p92.connectionUtil:disconnect((("%*CharacterAdded"):format(p93.UserId)))
			p92.connectionUtil:disconnect((("%*CharacterRemoving"):format(p93.UserId)))
		end
	end
	function v_u_1.OnMouseLockToggled(p94) -- name: OnMouseLockToggled
		if p94.activeMouseLockController then
			local v95 = p94.activeMouseLockController:GetIsMouseLocked()
			local v96 = p94.activeMouseLockController:GetMouseLockOffset()
			if p94.activeCameraController then
				p94.activeCameraController:SetIsMouseLocked(v95)
				p94.activeCameraController:SetMouseLockOffset(v96)
			end
		end
	end
	if v5:IsClient() then
		return v_u_1.new()
	else
		return v_u_1
	end
else
	return {}
end