local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ProximityPromptService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.BossCoins)
local v_u_8 = require(script.Parent.Device)
local v_u_9 = require(script.Parent.Events)
local v_u_10 = require(script.Parent.Gamepad)
local v_u_11 = require(script.Parent.Gifting)
local v_u_12 = require(script.Parent.ArcadeKit)
local v_u_13 = require(script.Parent.BossShopLook)
local v_u_14 = require(script.Parent.Menus)
local v_u_15 = require(script.Parent.Sfx)
local v_u_16 = require(script.Parent.State)
local v_u_17 = require(script.Parent.Store)
local v_u_18 = require(script.Parent.Tutorial)
local v19 = v_u_3.Shared
local v_u_20 = require(v19.Config.Boss)
local v_u_21 = require(v19.Config.Eyes)
local v_u_22 = require(v19.Config.Auras)
local v_u_23 = require(v19.Config.Images)
local v24 = require(v19.Config.Products)
local v_u_25 = require(v19.Config.Release)
local v_u_26 = require(v19.Logic.BossShop)
local v_u_27 = require(v19.Logic.BossDrops)
local v_u_28 = require(script.Parent.LuckLadder)
local v_u_29 = require(v19.Config.BossDrops)
local v_u_30 = require(v19.Logic.Format)
local v_u_31 = {}
local v_u_32 = v1.LocalPlayer
local v_u_33 = v_u_23.Icon.KuramaCoin
local v_u_34 = table.clone(v_u_23.Iris)
local v_u_35 = table.clone(v_u_23.Aura)
local v_u_36 = Color3.new(1, 1, 1)
local v_u_37 = Color3.new(0, 0, 0)
local v_u_38 = Color3.fromRGB(255, 168, 52)
local v_u_39 = Color3.fromRGB(222, 64, 24)
local v_u_40 = Color3.fromRGB(58, 255, 14)
local v_u_41 = Color3.fromRGB(132, 255, 16)
local v_u_42 = Color3.fromRGB(69, 200, 255)
local v_u_43 = Color3.fromRGB(0, 128, 255)
local v_u_44 = Color3.fromRGB(150, 152, 165)
local v_u_45 = Color3.fromRGB(90, 92, 104)
local v_u_46 = Color3.fromRGB(255, 61, 110)
local v_u_47 = Color3.fromRGB(255, 196, 50)
local v_u_48 = Color3.fromRGB(255, 214, 64)
local v_u_49 = Color3.fromRGB(255, 240, 120)
local v_u_50 = Color3.fromRGB(236, 238, 248)
local function v_u_51(_, _) end
function v_u_31.onNotify(p52) -- name: onNotify
	-- upvalues: (ref) v_u_51
	v_u_51 = p52
end
local function v_u_54(p53) -- name: hasAura
	-- upvalues: (copy) v_u_22, (copy) v_u_32, (copy) v_u_16
	if v_u_22.isOut(p53) then
		if p53.pass then
			return v_u_32:GetAttribute("Pass_" .. p53.pass) == true
		elseif p53.skip and v_u_32:GetAttribute("Pass_" .. p53.skip) == true then
			return true
		elseif p53.exclusive then
			return v_u_16.ownedAuras()[p53.id] == true
		else
			return v_u_16.number("TotalWins") >= p53.trophies
		end
	else
		return false
	end
end
local v_u_55 = v_u_51
local v_u_56 = {}
local function v_u_59(p_u_57) -- name: whenOn
	-- upvalues: (copy) v_u_25, (copy) v_u_4, (copy) v_u_6
	if v_u_25.on(2) then
		task.spawn(p_u_57)
		return
	elseif v_u_4:IsStudio() then
		local v_u_58 = nil
		v_u_58 = v_u_6:GetAttributeChangedSignal("DevUpdate2"):Connect(function()
			-- upvalues: (ref) v_u_25, (ref) v_u_58, (copy) p_u_57
			if v_u_25.on(2) then
				v_u_58:Disconnect()
				task.spawn(p_u_57)
			end
		end)
	end
end
local function v_u_66(p60) -- name: givesOf
	-- upvalues: (copy) v_u_16, (copy) v_u_21, (copy) v_u_30, (copy) v_u_22, (copy) v_u_54
	local v61 = v_u_16.number("World", 1)
	if p60.kind ~= "eye" then
		if p60.kind ~= "aura" then
			return ("x2 %* FOR %* MINUTES"):format(p60.item == "wins" and "TROPHIES" or "CHAKRA", p60.minutes or 0)
		end
		local v62 = v_u_22.byId[p60.item]
		return not v62 and "" or ("%* CHAKRA IN WORLD %*"):format(v_u_30.mult(v_u_22.multFor(v62, v61, v_u_54)), v61)
	end
	local v63 = v_u_21.byId[p60.item]
	local v64
	if v63 then
		v64 = v63.reissueOf
	else
		v64 = nil
	end
	local v65 = v_u_16.eyes()
	if v63 and (v64 and (v65[v63.id] == nil and v65[v64] ~= nil)) then
		v63 = v_u_21.byId[v64]
	end
	return not v63 and "" or ("%* CHAKRA IN WORLD %*"):format(v_u_30.mult(v_u_21.multIn(v63, v61)), v61)
end
for _, v67 in v_u_20.TIERS do
	v_u_56[v67.id] = v67.name
end
local v_u_68 = {}
for _, v69 in v24.products do
	if v69.kind ~= "kuramaCoins" then
		continue
	end
	table.insert(v_u_68, v69)
end
table.sort(v_u_68, function(p70, p71)
	return (p70.coins or 0) < (p71.coins or 0)
end)
local v_u_72 = {
	[1] = {
		{
			0.5,
			0.5,
			0.95,
			1
		}
	},
	[3] = {
		{
			0.3,
			0.6,
			0.66,
			1
		},
		{
			0.7,
			0.6,
			0.66,
			1
		},
		{
			0.5,
			0.42,
			0.72,
			2
		}
	},
	[5] = {
		{
			0.2,
			0.66,
			0.54,
			1
		},
		{
			0.8,
			0.66,
			0.54,
			1
		},
		{
			0.35,
			0.52,
			0.6,
			2
		},
		{
			0.65,
			0.52,
			0.6,
			2
		},
		{
			0.5,
			0.36,
			0.66,
			3
		}
	}
}
local v_u_73 = {}
local function v_u_83(p74, p75, p76) -- name: pile
	-- upvalues: (copy) v_u_72, (copy) v_u_33
	local v77 = v_u_72[p76 >= 3 and 5 or (p76 == 2 and 3 or 1)]
	p75.Visible = false
	local v78 = Instance.new("Frame")
	v78.Name = "Pile"
	v78.BackgroundTransparency = 1
	v78.AnchorPoint = Vector2.new(0.5, 0.5)
	v78.Position = UDim2.fromScale(0.5, 0.5)
	v78.Size = UDim2.fromScale(1, 1)
	v78.ZIndex = p75.ZIndex
	for v79, v80 in v77 do
		local v81 = Instance.new("ImageLabel")
		v81.Name = "Coin" .. v79
		v81.BackgroundTransparency = 1
		v81.AnchorPoint = Vector2.new(0.5, 0.5)
		v81.Position = UDim2.fromScale(v80[1], v80[2])
		v81.Size = UDim2.fromScale(v80[3], v80[3])
		v81.ZIndex = p75.ZIndex + v80[4]
		v81.Image = v_u_33
		v81.ScaleType = Enum.ScaleType.Fit
		if not v81:FindFirstChild("Round") then
			local v82 = Instance.new("UIAspectRatioConstraint")
			v82.Name = "Round"
			v82.AspectRatio = 1
			v82.Parent = v81
		end
		v81.Parent = v78
	end
	v78.Parent = p74
end
for _, v84 in v24.products do
	if v84.kind ~= "boost" or v84.boost ~= "luck" then
		continue
	end
	table.insert(v_u_73, v84)
end
table.sort(v_u_73, function(p85, p86)
	return (p85.mult or 0) < (p86.mult or 0)
end)
function v_u_31.luckSold() -- name: luckSold
	-- upvalues: (copy) v_u_25, (copy) v_u_73, (copy) v_u_4, (copy) v_u_6
	if not v_u_25.on(2) or #v_u_73 == 0 then
		return false
	end
	if v_u_4:IsStudio() and v_u_6:GetAttribute("DevBossLuck") == true then
		return true
	end
	for _, v87 in v_u_73 do
		if v87.id == 0 then
			continue
		end
		return true
	end
	return false
end
function v_u_31.luckShown() -- name: luckShown
	-- upvalues: (copy) v_u_31, (copy) v_u_17
	local v88 = v_u_31.luckSold()
	if v88 then
		v88 = not v_u_17.randomRestricted()
	end
	return v88
end
function v_u_31.luck() -- name: luck
	-- upvalues: (copy) v_u_27, (copy) v_u_16
	local v89 = 1
	local v90 = 0
	for v91, v92 in v_u_27.LUCK do
		local v93 = v_u_16.boostLeft(v91)
		if v93 <= 0 or v89 >= v92 then
			continue
		end
		v90 = v93
		v89 = v92
	end
	return v89, v90
end
function v_u_31.clock(p94) -- name: clock
	local v95 = math.floor(p94)
	local v96 = math.max(0, v95)
	local v97 = v96 // 3600
	local v98 = v96 // 60 % 60
	if v97 > 0 then
		return string.format("%d:%02d:%02d", v97, v98, v96 % 60)
	else
		return string.format("%d:%02d", v98, v96 % 60)
	end
end
local v_u_99 = {
	["item"] = {
		["decor"] = {
			["y"] = 0.3,
			["h"] = 0.36
		},
		["name"] = {
			["y"] = 0.54,
			["h"] = 0.085
		},
		["gives"] = {
			["y"] = 0.615,
			["h"] = 0.06
		},
		["about"] = {
			["y"] = 0.675,
			["h"] = 0.045
		}
	},
	["luck"] = {
		["decor"] = {
			["y"] = 0.235,
			["h"] = 0.26
		},
		["name"] = {
			["y"] = 0.405,
			["h"] = 0.07
		},
		["gives"] = {
			["y"] = 0.475,
			["h"] = 0.065
		},
		["about"] = {
			["y"] = 0.705,
			["h"] = 0.05
		}
	}
}
local v_u_100 = v_u_26.byTier()
local v_u_101 = {}
local function v_u_108(p102, p103, p104) -- name: multTag
	-- upvalues: (copy) v_u_36
	local v105 = Instance.new("TextLabel")
	v105.Name = "Mult"
	v105.BackgroundTransparency = 1
	v105.AnchorPoint = Vector2.new(1, 1)
	v105.Position = UDim2.fromScale(0.98, 1.02)
	v105.Size = UDim2.fromScale(0.55, 0.5)
	v105.FontFace = p103
	v105.TextScaled = true
	v105.TextXAlignment = Enum.TextXAlignment.Right
	v105.TextColor3 = v_u_36
	v105.Text = ""
	v105.Rotation = -8
	v105.ZIndex = p104 + 3
	v105.Visible = false
	local v106 = Instance.new("UIStroke")
	v106.Thickness = 3
	v106.Color = Color3.fromRGB(40, 16, 0)
	v106.LineJoinMode = Enum.LineJoinMode.Round
	v106.Parent = v105
	local v107 = Instance.new("UIGradient")
	v107.Rotation = 90
	v107.Color = ColorSequence.new(Color3.fromRGB(255, 252, 200), Color3.fromRGB(255, 190, 30))
	v107.Parent = v105
	v105.Parent = p102
	return v105
end
for v109, v110 in v_u_20.SHOP do
	v_u_101[v110.id] = v109
end
for _, v111 in v_u_100 do
	table.sort(v111.items, function(p112, p113)
		-- upvalues: (copy) v_u_101
		if p112.cost == p113.cost then
			return (v_u_101[p112.id] or 0) < (v_u_101[p113.id] or 0)
		else
			return p112.cost < p113.cost
		end
	end)
end
local v_u_114 = {}
local v_u_115 = {}
local v_u_116 = {}
local v_u_117 = nil
local v_u_118 = nil
local v_u_119 = nil
local v_u_120 = nil
local v_u_121 = "genin"
local v_u_122 = nil
local v_u_123 = false
local v_u_124 = nil
local function v_u_146(p_u_125, p_u_126, p_u_127) -- name: sizeText
	p_u_125.TextScaled = false
	local function v137() -- name: apply
		-- upvalues: (copy) p_u_126, (copy) p_u_127, (copy) p_u_125
		local v128 = p_u_126.AbsoluteSize.Y
		local v129 = v128 * p_u_127
		local v130 = math.floor(v129)
		local v131 = math.max(8, v130)
		p_u_125.TextSize = v131
		local v132 = p_u_126.AbsoluteSize.X - v128 * 1.2 - 8
		local v133 = p_u_125.TextBounds.X
		if v132 > 0 and v132 < v133 then
			local v134 = p_u_125
			local v135 = v131 * v132 / v133
			local v136 = math.floor(v135)
			v134.TextSize = math.max(8, v136)
		end
	end
	p_u_126:GetPropertyChangedSignal("AbsoluteSize"):Connect(v137)
	p_u_125:GetPropertyChangedSignal("Text"):Connect(v137)
	local v138 = p_u_126.AbsoluteSize.Y
	local v139 = v138 * p_u_127
	local v140 = math.floor(v139)
	local v141 = math.max(8, v140)
	p_u_125.TextSize = v141
	local v142 = p_u_126.AbsoluteSize.X - v138 * 1.2 - 8
	local v143 = p_u_125.TextBounds.X
	if v142 > 0 and v142 < v143 then
		local v144 = v141 * v142 / v143
		local v145 = math.floor(v144)
		p_u_125.TextSize = math.max(8, v145)
	end
end
local function v_u_156(p147, p148, p149, p150) -- name: priceRow
	-- upvalues: (copy) v_u_33, (copy) v_u_48, (copy) v_u_146
	local v151 = Instance.new("Frame")
	v151.Name = "Price"
	v151.BackgroundTransparency = 1
	v151.AnchorPoint = Vector2.new(0.5, 0.5)
	v151.Position = p149
	v151.Size = p150
	v151.ZIndex = 4
	local v152 = Instance.new("UIListLayout")
	v152.FillDirection = Enum.FillDirection.Horizontal
	v152.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v152.VerticalAlignment = Enum.VerticalAlignment.Center
	v152.SortOrder = Enum.SortOrder.LayoutOrder
	v152.Padding = UDim.new(0, 4)
	v152.Parent = v151
	local v153 = Instance.new("ImageLabel")
	v153.Name = "Coin"
	v153.BackgroundTransparency = 1
	v153.Size = UDim2.fromScale(1.15, 1.15)
	v153.LayoutOrder = 1
	v153.ZIndex = 5
	v153.Image = v_u_33
	v153.ScaleType = Enum.ScaleType.Fit
	if not v153:FindFirstChild("Round") then
		local v154 = Instance.new("UIAspectRatioConstraint")
		v154.Name = "Round"
		v154.AspectRatio = 1
		v154.Parent = v153
	end
	local v155 = v153:FindFirstChild("Round")
	if v155 and v155:IsA("UIAspectRatioConstraint") then
		v155.DominantAxis = Enum.DominantAxis.Height
	end
	v153.Parent = v151
	p148.AnchorPoint = Vector2.zero
	p148.Position = UDim2.new()
	p148.Size = UDim2.fromScale(0, 1)
	p148.AutomaticSize = Enum.AutomaticSize.X
	p148.LayoutOrder = 2
	p148.TextColor3 = v_u_48
	p148.RichText = true
	p148.Parent = v151
	v151.Parent = p147
	v_u_146(p148, v151, 0.82)
	return v153
end
local function v_u_166(p157, p158) -- name: giftBeside
	-- upvalues: (copy) v_u_11
	local v159 = p157.buy:FindFirstChild("GiftButton")
	if v159 then
		v159:Destroy()
	end
	if p158 and v_u_11.can(p158) then
		local v160 = p157.buy
		local v161 = UDim2.fromScale(0.585, 0.885)
		local v162 = UDim2.fromScale(0.67, 0.14)
		v160.AnchorPoint = Vector2.new(0.5, 0.5)
		v160.Position = v161
		v160.Size = v162
		v_u_11.beside(p157.buy, p158)
	else
		local v163 = p157.buy
		local v164 = UDim2.fromScale(0.5, 0.885)
		local v165 = UDim2.fromScale(0.84, 0.14)
		v163.AnchorPoint = Vector2.new(0.5, 0.5)
		v163.Position = v164
		v163.Size = v165
	end
end
local function v_u_174(p167, p168) -- name: arrange
	-- upvalues: (copy) v_u_99
	local v169 = v_u_99[p168] or v_u_99.item
	for v170, v171 in {
		["decor"] = p167.decor,
		["name"] = p167.name,
		["gives"] = p167.gives,
		["about"] = p167.about
	} do
		local v172 = v169[v170]
		if not v172 then
			continue
		end
		v171.Position = UDim2.fromScale(v171.Position.X.Scale, v172.y)
		v171.Size = UDim2.fromScale(v171.Size.X.Scale, v172.h)
	end
	local v173 = p168 == "luck"
	p167.odds.Visible = v173
	p167.mult.Visible = v173
end
local function v_u_210(p175, p176) -- name: showLuck
	-- upvalues: (copy) v_u_174, (copy) v_u_13, (copy) v_u_23, (copy) v_u_28, (copy) v_u_27, (copy) v_u_29, (copy) v_u_31, (copy) v_u_16, (copy) v_u_50, (copy) v_u_17, (copy) v_u_12, (copy) v_u_40, (copy) v_u_41
	v_u_174(p175, "luck")
	local v177 = p176.mult or 2
	local v178 = p176.minutes or 60
	v_u_13.card(p175.root, "luck")
	p175.tier.Text = ("BOSS LUCK - %* MINUTES"):format(v178)
	v_u_13.text(p175.tier, "luck", true)
	local v179 = p175.picture
	local v180
	if (p176.mult or 2) > 2 then
		v180 = v_u_23.Icon.LuckClover5
	else
		v180 = v_u_23.Icon.LuckClover
	end
	v179.Image = v180
	p175.mult.Text = ("x%*"):format(v177)
	p175.name.Text = ("x%* BOSS LUCK"):format(v177)
	v_u_13.text(p175.name, "luck")
	local v181 = v_u_28.tier()
	local v182 = v_u_27.luckWith(v177, v181)
	local v183 = p175.gives
	local v184
	if v181 > 1 then
		v184 = ("WITH YOUR x%* LUCK: EVERY DROP %*x AS LIKELY%*"):format(v181, v182, v_u_27.MAX_LUCK <= v182 and " (MAX)" or "")
	else
		v184 = ("EVERY KYUBI BOSS DROP IS %*x AS LIKELY"):format(v177)
	end
	v183.Text = v184
	for v185, v186 in v_u_29.list do
		local v187 = p175.oddsRows[v185]
		if not v187 then
			continue
		end
		v187.Text = ("<font color=\"#9A9AB0\">%*</font>  >  %*"):format(v_u_27.percent(v_u_27.chanceWith(v186.chance, v181)), (v_u_27.percent(v_u_27.chanceWith(v186.chance, v182))))
	end
	local v188, v189 = v_u_31.luck()
	local v190 = v_u_16.boostLeft("luck" .. tostring(v177))
	if v190 > 0 and v188 == v177 then
		local v191 = p175.about
		local v192 = "ON NOW: %* LEFT - BUY AGAIN: +%* MIN"
		local v193 = math.floor(v190)
		local v194 = math.max(0, v193)
		local v195 = v194 // 3600
		local v196 = v194 // 60 % 60
		local v197
		if v195 > 0 then
			v197 = string.format("%d:%02d:%02d", v195, v196, v194 % 60)
		else
			v197 = string.format("%d:%02d", v196, v194 % 60)
		end
		v191.Text = v192:format(v197, v178)
		p175.about.TextColor3 = Color3.fromRGB(120, 255, 110)
	elseif v188 > 1 then
		local v198 = p175.about
		local v199 = "x%* LUCK ON NOW: %* LEFT"
		local v200 = math.floor(v189)
		local v201 = math.max(0, v200)
		local v202 = v201 // 3600
		local v203 = v201 // 60 % 60
		local v204
		if v202 > 0 then
			v204 = string.format("%d:%02d:%02d", v202, v203, v201 % 60)
		else
			v204 = string.format("%d:%02d", v203, v201 % 60)
		end
		v198.Text = v199:format(v188, v204)
		p175.about.TextColor3 = Color3.fromRGB(120, 255, 110)
	else
		p175.about.Text = ("BUY AGAIN WHILE IT RUNS: +%* MINUTES"):format(v178)
		p175.about.TextColor3 = v_u_50
	end
	p175.price.Text = v_u_17.priceText(p176.price)
	p175.coin.Visible = false
	local v205 = p175.buy:FindFirstChild("TextLabel")
	if not (v205 and v205:IsA("TextLabel")) then
		v205 = nil
	end
	if v205 then
		v205.Text = "BUY"
	end
	v_u_12.paint(p175.buy, v_u_40, v_u_41)
	local v206 = p175.buy:FindFirstChild("GiftButton")
	if v206 then
		v206:Destroy()
	end
	local v207 = p175.buy
	local v208 = UDim2.fromScale(0.5, 0.885)
	local v209 = UDim2.fromScale(0.84, 0.14)
	v207.AnchorPoint = Vector2.new(0.5, 0.5)
	v207.Position = v208
	v207.Size = v209
end
local function v_u_216(p211, p212) -- name: showPack
	-- upvalues: (copy) v_u_210, (copy) v_u_174, (copy) v_u_50, (copy) v_u_13, (copy) v_u_33, (copy) v_u_30, (copy) v_u_26, (copy) v_u_20, (copy) v_u_17, (copy) v_u_12, (copy) v_u_40, (copy) v_u_41, (copy) v_u_166
	local v213
	if p212.kind == "boost" then
		v213 = p212.boost == "luck"
	else
		v213 = false
	end
	if v213 then
		v_u_210(p211, p212)
	else
		v_u_174(p211, "item")
		p211.about.TextColor3 = v_u_50
		v_u_13.card(p211.root, "coins")
		p211.tier.Text = "KYUBI COINS"
		v_u_13.text(p211.tier, "coins", true)
		p211.picture.Image = v_u_33
		p211.name.Text = string.upper((("%* Kyubi Coins"):format((v_u_30.commas(p212.coins or 0)))))
		v_u_13.text(p211.name, "coins")
		local v214 = v_u_26.winsFor(p212.coins or 0)
		p211.gives.Text = ("THE COINS OF %* BOSS WINS"):format(v214)
		p211.about.Text = ("Spend them in the boss shop. Beating Kyubi gives %* a fight"):format(v_u_20.COINS_PER_WIN)
		p211.price.Text = v_u_17.priceText(p212.price)
		p211.coin.Visible = false
		local v215 = p211.buy:FindFirstChild("TextLabel")
		if not (v215 and v215:IsA("TextLabel")) then
			v215 = nil
		end
		if v215 then
			v215.Text = "BUY"
		end
		v_u_12.paint(p211.buy, v_u_40, v_u_41)
		v_u_166(p211, p212.key)
	end
end
local function v_u_248() -- name: showDetail
	-- upvalues: (ref) v_u_119, (ref) v_u_122, (copy) v_u_216, (copy) v_u_174, (copy) v_u_50, (copy) v_u_16, (copy) v_u_26, (copy) v_u_22, (copy) v_u_54, (copy) v_u_13, (copy) v_u_56, (copy) v_u_34, (copy) v_u_23, (copy) v_u_35, (copy) v_u_21, (copy) v_u_66, (copy) v_u_12, (copy) v_u_42, (copy) v_u_43, (copy) v_u_30, (copy) v_u_44, (copy) v_u_45, (ref) v_u_123, (copy) v_u_40, (copy) v_u_41
	local v217 = v_u_119
	local v218 = v_u_122
	if v217 and v218 then
		local v219 = v218.pack
		if v219 then
			v_u_216(v217, v219)
			return
		else
			local v220 = v218.item
			if v220 then
				v_u_174(v217, "item")
				v217.about.TextColor3 = v_u_50
				local v221 = v217.buy:FindFirstChild("GiftButton")
				if v221 then
					v221:Destroy()
				end
				local v222 = v217.buy
				local v223 = UDim2.fromScale(0.5, 0.885)
				local v224 = UDim2.fromScale(0.84, 0.14)
				v222.AnchorPoint = Vector2.new(0.5, 0.5)
				v222.Position = v223
				v222.Size = v224
				local v225 = v_u_16.number("KuramaCoins")
				local v226
				if v220.kind == "eye" then
					v226 = v_u_26.ownsEye(v220, v_u_16.eyes())
				elseif v220.kind == "aura" then
					local v227 = v_u_22.byId[v220.item]
					if v227 == nil then
						v226 = false
					else
						v226 = v_u_54(v227)
					end
				else
					v226 = false
				end
				v_u_13.card(v217.root, v220.tier)
				v217.tier.Text = v220.tier == "mythical" and "MYTHICAL - GRAND PRIZE" or ("%* - %*"):format(v_u_56[v220.tier] or "", v220.kind == "eye" and "EYE" or (v220.kind == "aura" and "AURA" or "BOOST"))
				v_u_13.text(v217.tier, v220.tier, true)
				local v228 = v217.picture
				local v229
				if v220.kind == "eye" then
					v229 = v_u_34[v220.item] or v_u_23.Icon.Eyes
				elseif v220.kind == "aura" then
					v229 = v_u_35[v220.item] or v_u_23.Icon.Auras
				elseif v220.item == "wins" then
					v229 = v_u_23.Icon.BoostWins
				else
					v229 = v_u_23.Icon.BoostChakra
				end
				v228.Image = v229
				local v230 = v217.name
				local v231 = string.upper
				local v232
				if v220.kind == "eye" then
					local v233 = v_u_21.byId[v220.item]
					local v234
					if v233 then
						v234 = v233.reissueOf
					else
						v234 = nil
					end
					local v235 = v_u_16.eyes()
					if v233 and (v234 and (v235[v233.id] == nil and v235[v234] ~= nil)) then
						v233 = v_u_21.byId[v234]
					end
					if v233 then
						v232 = v233.name
					else
						v232 = v220.id
					end
				elseif v220.kind == "aura" then
					local v236 = v_u_22.byId[v220.item]
					if v236 then
						v232 = v236.name
					else
						v232 = v220.id
					end
				else
					v232 = v220.item == "wins" and "x2 Trophies" or "x2 Chakra"
				end
				v230.Text = v231(v232)
				v_u_13.text(v217.name, v220.tier)
				v217.gives.Text = v_u_66(v220)
				local v237 = v217.about
				local v238
				if v220.kind == "eye" then
					local v239 = v_u_21.byId[v220.item]
					local v240
					if v239 then
						v240 = v239.reissueOf
					else
						v240 = nil
					end
					local v241 = v_u_16.eyes()
					if v239 and (v240 and (v241[v239.id] == nil and v241[v240] ~= nil)) then
						v239 = v_u_21.byId[v240]
					end
					v238 = not v239 and "" or v239.blurb
				else
					v238 = v220.kind == "aura" and "An aura: wear it from the Auras menu" or ("Buy again to add %* more minutes"):format(v220.minutes or 0)
				end
				v237.Text = v238
				local v242 = v220.cost - v225
				if v226 then
					v217.price.Text = "YOU OWN IT"
					v217.coin.Visible = false
					local v243 = v217.buy:FindFirstChild("TextLabel")
					if not (v243 and v243:IsA("TextLabel")) then
						v243 = nil
					end
					if v243 then
						v243.Text = "OWNED"
					end
					v_u_12.paint(v217.buy, v_u_42, v_u_43)
					return
				elseif v242 > 0 then
					local v244 = v_u_30.commas(v242)
					v217.price.Text = ("%*  <font color=\"#FF7070\">NEED %*</font>"):format(v_u_30.commas(v220.cost), v244)
					v217.coin.Visible = true
					local v245 = v217.buy:FindFirstChild("TextLabel")
					if not (v245 and v245:IsA("TextLabel")) then
						v245 = nil
					end
					if v245 then
						v245.Text = "NOT ENOUGH COINS"
					end
					v_u_12.paint(v217.buy, v_u_44, v_u_45)
				else
					v217.price.Text = v_u_30.commas(v220.cost)
					v217.coin.Visible = true
					local v246 = v_u_123 and "..." or "BUY"
					local v247 = v217.buy:FindFirstChild("TextLabel")
					if not (v247 and v247:IsA("TextLabel")) then
						v247 = nil
					end
					if v247 then
						v247.Text = v246
					end
					v_u_12.paint(v217.buy, v_u_40, v_u_41)
				end
			else
				return
			end
		end
	else
		return
	end
end
local function v_u_256() -- name: refresh
	-- upvalues: (ref) v_u_120, (copy) v_u_30, (copy) v_u_16, (copy) v_u_114, (copy) v_u_26, (copy) v_u_22, (copy) v_u_54, (copy) v_u_36, (copy) v_u_17, (ref) v_u_122, (copy) v_u_248
	if v_u_120 then
		v_u_120.Text = v_u_30.commas(v_u_16.number("KuramaCoins"))
	end
	for _, v249 in v_u_114 do
		local v250 = v249.item
		local v251 = v249.pack
		if v250 then
			local v252
			if v250.kind == "eye" then
				v252 = v_u_26.ownsEye(v250, v_u_16.eyes())
			elseif v250.kind == "aura" then
				local v253 = v_u_22.byId[v250.item]
				if v253 == nil then
					v252 = false
				else
					v252 = v_u_54(v253)
				end
			else
				v252 = false
			end
			v249.coin.Visible = not v252
			v249.price.Text = v252 and "OWNED" or v_u_30.commas(v250.cost)
			local v254 = v249.price
			local v255
			if v252 then
				v255 = Color3.fromRGB(120, 255, 110)
			else
				v255 = v_u_36
			end
			v254.TextColor3 = v255
		elseif v251 then
			v249.coin.Visible = false
			v249.price.Text = v_u_17.priceText(v251.price)
			v249.price.TextColor3 = v_u_36
		end
		v249.ring.Visible = v_u_122 == v249
	end
	v_u_248()
end
local function v_u_268(p257) -- name: showTier
	-- upvalues: (ref) v_u_121, (copy) v_u_115, (copy) v_u_13, (copy) v_u_31, (copy) v_u_114, (ref) v_u_118, (ref) v_u_122, (copy) v_u_256
	v_u_121 = p257
	for v258, v259 in v_u_115 do
		v_u_13.tab(v259, v258, v258 == p257)
	end
	local v260 = p257 ~= "luck" and 1 or v_u_31.luck()
	local v261 = 0
	local v262 = nil
	for _, v263 in v_u_114 do
		local v264 = v263.tab == p257
		v263.root.Visible = v264
		if not v264 then
			continue
		end
		v261 = v261 + 1
		local v265 = v263.pack
		if v260 > 1 and v265 then
			if v265.mult == v260 then
				v262 = v263
			end
		end
		v262 = v262 or v263
	end
	local v266 = v_u_118
	if v266 then
		if v261 == 1 then
			v266.FillDirectionMaxCells = 1
			v266.CellSize = UDim2.fromScale(1, 1)
		elseif v261 <= 3 then
			v266.FillDirectionMaxCells = v261
			v266.CellSize = UDim2.fromScale(v261 == 2 and 0.485 or 0.315, 0.82)
		else
			v266.FillDirectionMaxCells = 2
			v266.CellSize = UDim2.fromScale(0.485, 0.485)
		end
		v266.CellPadding = UDim2.fromScale(v261 == 3 and 0.0275 or 0.03, 0.03)
	end
	local v267 = v_u_122
	if not v267 or v267.tab ~= p257 then
		v_u_122 = v262
	end
	v_u_256()
end
local function v_u_276(p269) -- name: stepTier
	-- upvalues: (copy) v_u_116, (ref) v_u_121, (copy) v_u_115, (copy) v_u_15, (copy) v_u_268, (copy) v_u_10, (copy) v_u_14, (ref) v_u_122, (copy) v_u_114
	for v270, v271 in v_u_116 do
		if v271 ~= v_u_121 then
			continue
		end
		local v272 = v_u_116[v270 + p269]
		local v273
		if v272 then
			v273 = v_u_115[v272]
		else
			v273 = v272
		end
		if v272 and (v273 and v273.Visible) then
			v_u_15.play("Click")
			v_u_268(v272)
			v_u_10.selectSoon(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_122, (ref) v_u_114
				if v_u_14.current() ~= "BossShop" then
					return nil
				end
				local v274 = v_u_122
				if v274 and v274.root.Visible then
					return v274.pick
				end
				for _, v275 in v_u_114 do
					if not v275.root.Visible then
						continue
					end
					return v275.pick
				end
				return nil
			end)
		end
		return
	end
end
local function v_u_297() -- name: buy
	-- upvalues: (ref) v_u_122, (ref) v_u_119, (ref) v_u_123, (ref) v_u_124, (copy) v_u_17, (copy) v_u_26, (copy) v_u_16, (copy) v_u_22, (copy) v_u_54, (copy) v_u_15, (ref) v_u_55, (copy) v_u_21, (copy) v_u_30, (copy) v_u_12, (copy) v_u_3, (copy) v_u_248, (ref) v_u_120, (copy) v_u_256
	local v277 = v_u_122
	local v278 = v_u_119
	if v_u_123 or not (v277 and v278) then
		return
	else
		local v279 = v277.pack
		if v279 then
			if v279.kind == "kuramaCoins" then
				v_u_124 = {
					["coins"] = v279.coins or 0,
					["at"] = os.clock()
				}
			end
			v_u_17.buyProduct(v279.key)
			return
		else
			local v_u_280 = v277.item
			if v_u_280 then
				local v281
				if v_u_280.kind == "eye" then
					v281 = v_u_26.ownsEye(v_u_280, v_u_16.eyes())
				elseif v_u_280.kind == "aura" then
					local v282 = v_u_22.byId[v_u_280.item]
					if v282 == nil then
						v281 = false
					else
						v281 = v_u_54(v282)
					end
				else
					v281 = false
				end
				if v281 then
					v_u_15.play("Error")
					local v283 = v_u_55
					local v284 = "You already have "
					local v285
					if v_u_280.kind == "eye" then
						local v286 = v_u_21.byId[v_u_280.item]
						local v287
						if v286 then
							v287 = v286.reissueOf
						else
							v287 = nil
						end
						local v288 = v_u_16.eyes()
						if v286 and (v287 and (v288[v286.id] == nil and v288[v287] ~= nil)) then
							v286 = v_u_21.byId[v287]
						end
						if v286 then
							v285 = v286.name
						else
							v285 = v_u_280.id
						end
					elseif v_u_280.kind == "aura" then
						local v289 = v_u_22.byId[v_u_280.item]
						if v289 then
							v285 = v289.name
						else
							v285 = v_u_280.id
						end
					else
						v285 = v_u_280.item == "wins" and "x2 Trophies" or "x2 Chakra"
					end
					v283(v284 .. v285)
					return
				else
					local v290 = v_u_16.number("KuramaCoins")
					if v290 < v_u_280.cost then
						v_u_15.play("Error")
						v_u_55(("You need %* more Kyubi Coins: beat Kyubi!"):format((v_u_30.commas(v_u_280.cost - v290))), Color3.fromRGB(220, 40, 60))
						v_u_12.shake(v278.buy, 6, 0.25)
						return
					else
						local v_u_291 = v_u_3:FindFirstChild("Remotes")
						if v_u_291 then
							v_u_291 = v_u_291:WaitForChild("BossShop", 10)
						end
						if not (v_u_291 and v_u_291:IsA("RemoteFunction")) then
							v_u_291 = nil
						end
						if v_u_291 then
							v_u_123 = true
							v_u_248()
							local v292, v293, v294 = pcall(function()
								-- upvalues: (copy) v_u_291, (copy) v_u_280
								return v_u_291:InvokeServer("buy", v_u_280.id)
							end)
							v_u_123 = false
							if v292 and v293 == true then
								v_u_15.play("RevealBig")
								v_u_55(tostring(v294), Color3.fromRGB(40, 200, 60))
								local v295 = UDim2.fromScale(0.5, 0.31)
								v_u_12.burst(v278.root, v295, 90, Color3.fromRGB(255, 214, 64))
								v_u_12.sparks(v278.root, v295, 40, Color3.fromRGB(255, 160, 40), 14)
								v_u_12.bump(v278.picture, 0.3)
								local v296 = v_u_120
								if v296 then
									v_u_12.bump(v296, 0.25)
								end
							else
								v_u_15.play("Error")
								v_u_55((not v292 or type(v294) ~= "string") and "Try again" or v294)
							end
							v_u_256()
						else
							v_u_55("The boss shop is not ready, try again")
						end
					end
				end
			else
				return
			end
		end
	end
end
local function v_u_307(p298) -- name: coinsArrived
	-- upvalues: (copy) v_u_7, (ref) v_u_124, (ref) v_u_55, (copy) v_u_30, (ref) v_u_119, (ref) v_u_117, (copy) v_u_12, (copy) v_u_48, (ref) v_u_120
	if type(p298) == "table" then
		local v299 = p298.coins
		local v300 = p298.total
		if type(v299) == "number" and v299 > 0 then
			local v301 = v_u_7.won
			if type(v300) ~= "number" then
				v300 = nil
			end
			v301(v299, v300)
			local v302 = v_u_124
			if v302 and v299 >= v302.coins then
				v_u_124 = nil
				if os.clock() - v302.at <= 600 then
					v_u_55(("+%* Kyubi Coins!"):format((v_u_30.commas(v299))), Color3.fromRGB(255, 170, 30))
					local v303 = v_u_119
					local v304 = v_u_117
					if v303 and (v304 and v304.Visible) then
						local v305 = UDim2.fromScale(0.5, 0.31)
						v_u_12.burst(v303.root, v305, 90, v_u_48)
						v_u_12.sparks(v303.root, v305, 40, Color3.fromRGB(255, 160, 40), 14)
						v_u_12.bump(v303.picture, 0.3)
					end
					local v306 = v_u_120
					if v306 then
						v_u_12.bump(v306, 0.25)
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_311() -- name: pieces
	-- upvalues: (copy) v_u_32
	local v308 = v_u_32:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	local v309
	if v308 then
		v309 = v308:WaitForChild("Frames", 10)
	else
		v309 = v308
	end
	if v308 then
		v308 = v308:WaitForChild("Templates", 10)
	end
	local v310
	if v309 then
		v310 = v309:WaitForChild("Store", 10)
	else
		v310 = v309
	end
	if v309 then
		v309 = v309:WaitForChild("Quests", 10)
	end
	if v309 then
		v309 = v309:FindFirstChild("Tabs")
	end
	if v309 then
		v309 = v309:FindFirstChild("Daily")
	end
	if v308 then
		v308 = v308:WaitForChild("EyeCard", 10)
	end
	return v310 and (v310:IsA("Frame") and (v309 and (v309:IsA("GuiButton") and (v308 and v308:IsA("GuiObject"))))) and {
		["store"] = v310,
		["tab"] = v309,
		["card"] = v308
	} or nil
end
local function v_u_319(p312, p313, p314) -- name: packButton
	local v315 = p312:Clone()
	v315.Name = p313
	v315.Visible = true
	for _, v316 in {
		"Ui-Frame",
		"Ui-Close",
		"Ui-Pass",
		"Ui-Product",
		"Ui-Pack"
	} do
		v315:SetAttribute(v316, nil)
	end
	for _, v317 in v315:GetChildren() do
		if v317.Name ~= "PadHint" and not v317:IsA("UIScale") then
			continue
		end
		v317:Destroy()
	end
	local v318 = v315:FindFirstChild("TextLabel")
	if not (v318 and v318:IsA("TextLabel")) then
		v318 = nil
	end
	if v318 then
		v318.Text = p314
	end
	return v315
end
local function v_u_329(p320) -- name: shell
	-- upvalues: (copy) v_u_8, (copy) v_u_5
	local v_u_321 = Instance.new("Frame")
	v_u_321.Name = "BossShop"
	v_u_321.Visible = false
	v_u_321.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_321.Position = UDim2.fromScale(0.5, 0.5)
	v_u_321.BackgroundColor3 = p320.BackgroundColor3
	v_u_321.BackgroundTransparency = p320.BackgroundTransparency
	v_u_321.BorderSizePixel = 0
	v_u_321.ZIndex = p320.ZIndex
	local v322 = nil
	for _, v323 in p320:GetChildren() do
		if v323.Name == "Top" then
			v322 = v323:Clone()
			v322.Parent = v_u_321
		else
			if not (v323:IsA("UIStroke") or v323:IsA("UICorner")) then
				continue
			end
			v323:Clone().Parent = v_u_321
		end
	end
	local v324 = Instance.new("UIAspectRatioConstraint")
	v324.AspectRatio = 1.6
	v324.Parent = v_u_321
	local function v327() -- name: size
		-- upvalues: (copy) v_u_321, (ref) v_u_8
		local v325 = v_u_321
		local v326
		if v_u_8.touch() then
			v326 = UDim2.fromScale(0.94, 0.9)
		else
			v326 = UDim2.fromScale(0.62, 0.72)
		end
		v325.Size = v326
	end
	local v328
	if v_u_8.touch() then
		v328 = UDim2.fromScale(0.94, 0.9)
	else
		v328 = UDim2.fromScale(0.62, 0.72)
	end
	v_u_321.Size = v328
	v_u_5:GetPropertyChangedSignal("PreferredInput"):Connect(v327)
	return v_u_321, v322
end
local function v_u_353(p330, p331, p332) -- name: topBar
	-- upvalues: (copy) v_u_33, (copy) v_u_38, (copy) v_u_39, (copy) v_u_13, (copy) v_u_37, (copy) v_u_156, (ref) v_u_120, (copy) v_u_25, (copy) v_u_68, (copy) v_u_4, (copy) v_u_6, (copy) v_u_319, (copy) v_u_12, (copy) v_u_40, (copy) v_u_41, (ref) v_u_121, (copy) v_u_15, (copy) v_u_268, (copy) v_u_10, (copy) v_u_14, (ref) v_u_122, (copy) v_u_114, (copy) v_u_8
	local v333 = nil
	for _, v334 in p330:GetChildren() do
		if v334:IsA("TextLabel") then
			v334.Text = "Boss Shop"
			if v333 and v334.ZIndex <= v333.ZIndex then
				continue
			end
			v333 = v334
		elseif v334:IsA("ImageLabel") and v334.Name ~= "StudPattern" then
			v334.Image = v_u_33
			v334.ScaleType = Enum.ScaleType.Fit
			if v334:FindFirstChild("Round") then
				continue
			end
			local v335 = Instance.new("UIAspectRatioConstraint")
			v335.Name = "Round"
			v335.AspectRatio = 1
			v335.Parent = v334
		else
			if not v334:IsA("UIGradient") then
				continue
			end
			v334.Color = ColorSequence.new(v_u_38, v_u_39)
		end
	end
	if v333 then
		v_u_13.title(v333)
	end
	local v336 = Instance.new("Frame")
	v336.Name = "Coins"
	v336.BackgroundColor3 = Color3.fromRGB(20, 12, 10)
	v336.BackgroundTransparency = 0.3
	local v337 = UDim2.fromScale(0.735, 0.5)
	local v338 = UDim2.fromScale(0.22, 0.66)
	v336.AnchorPoint = Vector2.new(0.5, 0.5)
	v336.Position = v337
	v336.Size = v338
	v336.ZIndex = 5
	local v339 = Instance.new("UICorner")
	v339.CornerRadius = UDim.new(0.5, 0)
	v339.Parent = v336
	local v340 = Instance.new("UIStroke")
	v340.Thickness = 2
	v340.Color = v_u_37
	v340.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v340.Parent = v336
	local v341 = p331:Clone()
	v341.Name = "Amount"
	v341.Text = "0"
	v341.ZIndex = 6
	v_u_156(v336, v341, UDim2.fromScale(0.5, 0.5), UDim2.fromScale(0.96, 0.92))
	v336.Parent = p330
	v_u_120 = v341
	local v342
	if v_u_25.on(2) and #v_u_68 ~= 0 then
		local v343 = v_u_4:IsStudio()
		if v343 then
			v343 = v_u_6:GetAttribute("DevCoinPacks") == true
		end
		if v343 then
			v342 = true
		else
			for _, v344 in v_u_68 do
				if v344.id == 0 then
					continue
				end
				v342 = true
			end
			v342 = false
		end
	else
		v342 = false
	end
	if v342 then
		local v345 = v_u_319(p332, "GetCoins", "+")
		local v346 = UDim2.fromScale(0.6, 0.5)
		local v347 = UDim2.fromScale(0.06, 0.66)
		v345.AnchorPoint = Vector2.new(0.5, 0.5)
		v345.Position = v346
		v345.Size = v347
		local v348 = Instance.new("UIAspectRatioConstraint")
		v348.AspectRatio = 1
		v348.DominantAxis = Enum.DominantAxis.Height
		v348.Parent = v345
		v345.ZIndex = 6
		v_u_12.paint(v345, v_u_40, v_u_41)
		v345:SetAttribute("Pad", true)
		v345.Parent = p330
		v345.Activated:Connect(function()
			-- upvalues: (ref) v_u_121, (ref) v_u_15, (ref) v_u_268, (ref) v_u_10, (ref) v_u_14, (ref) v_u_122, (ref) v_u_114
			if v_u_121 ~= "coins" then
				v_u_15.play("Click")
				v_u_268("coins")
			end
			if v_u_10.active() then
				v_u_10.selectSoon(function()
					-- upvalues: (ref) v_u_14, (ref) v_u_122, (ref) v_u_114
					if v_u_14.current() ~= "BossShop" then
						return nil
					end
					local v349 = v_u_122
					if v349 and v349.root.Visible then
						return v349.pick
					end
					for _, v350 in v_u_114 do
						if not v350.root.Visible then
							continue
						end
						return v350.pick
					end
					return nil
				end)
			end
		end)
	end
	for _, v351 in p330:GetDescendants() do
		if v351.Name ~= "PadHint" then
			continue
		end
		v351:Destroy()
	end
	local v352 = p330:FindFirstChild("Close")
	if v352 and v352:IsA("GuiObject") then
		v_u_10.hint(v352, Enum.KeyCode.ButtonB, 26)
		if v_u_8.touch() then
			v352.Size = UDim2.fromScale(v352.Size.X.Scale * 1.35, v352.Size.Y.Scale * 1.35)
		end
	end
end
local function v_u_417(p354, p355, p356, p357, p358, p359, p360) -- name: makeTile
	-- upvalues: (copy) v_u_13, (copy) v_u_21, (copy) v_u_16, (copy) v_u_22, (copy) v_u_30, (copy) v_u_34, (copy) v_u_23, (copy) v_u_35, (copy) v_u_108, (copy) v_u_83, (copy) v_u_319, (copy) v_u_12, (copy) v_u_46, (copy) v_u_47, (copy) v_u_10, (copy) v_u_156, (copy) v_u_36, (ref) v_u_122, (copy) v_u_256, (ref) v_u_119
	local v361
	if p356 then
		v361 = p356.tier
	elseif p357 then
		local v362
		if p357.kind == "boost" then
			v362 = p357.boost == "luck"
		else
			v362 = false
		end
		v361 = v362 and "luck" or "coins"
	else
		v361 = nil
	end
	if not v361 then
		return nil
	end
	local v363 = p354:Clone()
	local v364 = "Item_"
	local v365
	if p356 then
		v365 = p356.id
	else
		v365 = not p357 and "" or p357.key
	end
	v363.Name = v364 .. v365
	v363.LayoutOrder = p359
	v363.Visible = false
	for _, v366 in { "Redeem", "Locked" } do
		local v367 = v363:FindFirstChild(v366)
		if not v367 then
			continue
		end
		v367:Destroy()
	end
	local v368 = v363:FindFirstChild("DayText")
	if not (v368 and v368:IsA("TextLabel")) then
		v368 = nil
	end
	local v369 = v363:FindFirstChild("Decor")
	local v370
	if v369 then
		v370 = v369:FindFirstChild("Icon")
	else
		v370 = v369
	end
	local v371
	if v369 then
		v371 = v369:FindFirstChild("Sunburst")
	else
		v371 = v369
	end
	local v372 = v363:FindFirstChild("RewardText")
	if not (v372 and v372:IsA("TextLabel")) then
		v372 = nil
	end
	if not (v368 and (v369 and (v369:IsA("GuiObject") and (v370 and (v370:IsA("ImageLabel") and v372))))) then
		v363:Destroy()
		return nil
	end
	v_u_13.card(v363, v361)
	local v373
	if p356 then
		if p360 then
			local v374 = string.upper
			local v375
			if p356.kind == "eye" then
				local v376 = v_u_21.byId[p356.item]
				local v377
				if v376 then
					v377 = v376.reissueOf
				else
					v377 = nil
				end
				local v378 = v_u_16.eyes()
				if v376 and (v377 and (v378[v376.id] == nil and v378[v377] ~= nil)) then
					v376 = v_u_21.byId[v377]
				end
				if v376 then
					v375 = v376.name
				else
					v375 = p356.id
				end
			elseif p356.kind == "aura" then
				local v379 = v_u_22.byId[p356.item]
				if v379 then
					v375 = v379.name
				else
					v375 = p356.id
				end
			else
				v375 = p356.item == "wins" and "x2 Trophies" or "x2 Chakra"
			end
			v373 = v374(v375)
		elseif p356.kind == "eye" then
			local v380 = v_u_21.byId[p356.item]
			local v381
			if v380 then
				v381 = v380.reissueOf
			else
				v381 = nil
			end
			local v382 = v_u_16.eyes()
			if v380 and (v381 and (v382[v380.id] == nil and v382[v381] ~= nil)) then
				v380 = v_u_21.byId[v381]
			end
			if v380 then
				v373 = v380.name
			else
				v373 = p356.id
			end
		elseif p356.kind == "aura" then
			local v383 = v_u_22.byId[p356.item]
			if v383 then
				v373 = v383.name
			else
				v373 = p356.id
			end
		else
			v373 = p356.item == "wins" and "x2 Trophies" or "x2 Chakra"
		end
	elseif p357 then
		local v384
		if p357.kind == "boost" then
			v384 = p357.boost == "luck"
		else
			v384 = false
		end
		if v384 then
			v373 = ("x%* Boss Luck"):format(p357.mult or 2)
		else
			v373 = not p357 and "" or ("%* Coins"):format((v_u_30.commas(p357.coins or 0)))
		end
	else
		v373 = not p357 and "" or ("%* Coins"):format((v_u_30.commas(p357.coins or 0)))
	end
	v368.Text = v373
	v_u_13.text(v368, v361)
	local v385 = UDim2.fromScale(0.5, p360 and 0.2 or 0.13)
	local v386 = UDim2.fromScale(0.92, p360 and 0.11 or 0.17)
	v368.AnchorPoint = Vector2.new(0.5, 0.5)
	v368.Position = v385
	v368.Size = v386
	local v387 = UDim2.fromScale(0.5, p360 and 0.535 or 0.5)
	local v388 = UDim2.fromScale(0.92, 0.5)
	v369.AnchorPoint = Vector2.new(0.5, 0.5)
	v369.Position = v387
	v369.Size = v388
	local v389 = UDim2.fromScale(0.5, 0.5)
	local v390 = UDim2.fromScale(1, 1)
	v370.AnchorPoint = Vector2.new(0.5, 0.5)
	v370.Position = v389
	v370.Size = v390
	v370.ScaleType = Enum.ScaleType.Fit
	if p356 then
		local v391
		if p356.kind == "eye" then
			v391 = v_u_34[p356.item] or v_u_23.Icon.Eyes
		elseif p356.kind == "aura" then
			v391 = v_u_35[p356.item] or v_u_23.Icon.Auras
		elseif p356.item == "wins" then
			v391 = v_u_23.Icon.BoostWins
		else
			v391 = v_u_23.Icon.BoostChakra
		end
		v370.Image = v391
	elseif p357 then
		local v392
		if p357.kind == "boost" then
			v392 = p357.boost == "luck"
		else
			v392 = false
		end
		if v392 then
			local v393
			if (p357.mult or 2) > 2 then
				v393 = v_u_23.Icon.LuckClover5
			else
				v393 = v_u_23.Icon.LuckClover
			end
			v370.Image = v393
			local v394 = v_u_108(v369, v368.FontFace, v370.ZIndex)
			v394.Text = ("x%*"):format(p357.mult or 2)
			v394.Visible = true
		else
			v_u_83(v369, v370, p358)
		end
	else
		v_u_83(v369, v370, p358)
	end
	if v371 and v371:IsA("GuiObject") then
		local v395 = UDim2.fromScale(0.5, 0.5)
		local v396 = UDim2.fromScale(2, p360 and 1.7 or 1.45)
		v371.AnchorPoint = Vector2.new(0.5, 0.5)
		v371.Position = v395
		v371.Size = v396
		Instance.new("UIAspectRatioConstraint").Parent = v371
	end
	if p360 then
		v370:SetAttribute("Ui-Effect", "Float")
		v370:SetAttribute("Ui-Effect-Rate", 6)
		v370:SetAttribute("Ui-Effect-Speed", 2.2)
		local v397 = v_u_319(p355, "Tag", "GRAND PRIZE!")
		local v398 = UDim2.fromScale(0.5, 0.075)
		local v399 = UDim2.fromScale(0.36, 0.1)
		v397.AnchorPoint = Vector2.new(0.5, 0.5)
		v397.Position = v398
		v397.Size = v399
		v397.Rotation = -3
		v397.ZIndex = 6
		v_u_12.paint(v397, v_u_46, v_u_47)
		v_u_10.skip(v397)
		v397.Active = false
		v397.AutoButtonColor = false
		for _, v400 in { "Ui-Hover", "Ui-Click" } do
			v397:SetAttribute(v400, nil)
		end
		v397:SetAttribute("Ui-Effect", "Shake")
		v397:SetAttribute("Ui-Effect-Rate", 1.05)
		v397.Parent = v363
	end
	local v401 = v_u_156(v363, v372, UDim2.fromScale(0.5, p360 and 0.885 or 0.865), UDim2.fromScale(0.9, p360 and 0.12 or 0.16))
	local v402 = Instance.new("Frame")
	v402.Name = "Ring"
	v402.BackgroundTransparency = 1
	local v403 = UDim2.fromScale(0.5, 0.5)
	local v404 = UDim2.fromScale(1, 1)
	v402.AnchorPoint = Vector2.new(0.5, 0.5)
	v402.Position = v403
	v402.Size = v404
	v402.ZIndex = 7
	v402.Visible = false
	local v405 = Instance.new("UICorner")
	v405.CornerRadius = UDim.new(0, 4)
	v405.Parent = v402
	local v406 = Instance.new("UIStroke")
	v406.Color = v_u_36
	v406.Thickness = 4
	v406.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v406.Parent = v402
	v402.Parent = v363
	local v_u_407 = Instance.new("UIScale")
	v_u_407.Name = "Lift"
	v_u_407.Parent = v363
	local v408 = Instance.new("TextButton")
	v408.Name = "Pick"
	v408.BackgroundTransparency = 1
	v408.Text = ""
	v408.AutoButtonColor = false
	local v409 = UDim2.fromScale(0.5, 0.5)
	local v410 = UDim2.fromScale(1, 1)
	v408.AnchorPoint = Vector2.new(0.5, 0.5)
	v408.Position = v409
	v408.Size = v410
	v408.ZIndex = 8
	v408:SetAttribute("Pad", true)
	v408.Selectable = true
	v408.Parent = v363
	local v_u_411 = {
		["item"] = p356,
		["pack"] = p357,
		["tab"] = v361,
		["root"] = v363,
		["pick"] = v408,
		["name"] = v368,
		["price"] = v372,
		["coin"] = v401,
		["ring"] = v402,
		["lift"] = v_u_407
	}
	v408.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_407
		v_u_12.tween(v_u_407, 0.1, {
			["Scale"] = 1.04
		})
	end)
	v408.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_407
		v_u_12.tween(v_u_407, 0.1, {
			["Scale"] = 1
		})
	end)
	v408.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_407, (copy) v_u_411, (ref) v_u_122, (ref) v_u_256, (ref) v_u_119
		v_u_12.tween(v_u_407, 0.1, {
			["Scale"] = 1.04
		})
		local v412 = v_u_411
		if v_u_122 ~= v412 then
			v_u_122 = v412
			v_u_256()
			local v413 = v_u_119
			if v413 then
				v_u_12.bump(v413.picture, 0.12)
			end
		end
	end)
	v408.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_407
		v_u_12.tween(v_u_407, 0.1, {
			["Scale"] = 1
		})
	end)
	v408.Activated:Connect(function()
		-- upvalues: (copy) v_u_411, (ref) v_u_122, (ref) v_u_256, (ref) v_u_119, (ref) v_u_12, (copy) v_u_407, (ref) v_u_10
		local v414 = v_u_411
		if v_u_122 ~= v414 then
			v_u_122 = v414
			v_u_256()
			local v415 = v_u_119
			if v415 then
				v_u_12.bump(v415.picture, 0.12)
			end
		end
		v_u_407.Scale = 0.94
		v_u_12.tween(v_u_407, 0.25, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		local v416 = v_u_119
		if v416 and v_u_10.active() then
			v_u_10.select(v416.buy)
		end
	end)
	return v_u_411
end
local function v_u_476(p418, p419, p420) -- name: makeDetail
	-- upvalues: (copy) v_u_49, (copy) v_u_50, (copy) v_u_156, (copy) v_u_36, (copy) v_u_319, (copy) v_u_12, (copy) v_u_40, (copy) v_u_41, (copy) v_u_297, (copy) v_u_108, (copy) v_u_29, (copy) v_u_37, (copy) v_u_27
	local v421 = p418:Clone()
	v421.Name = "Detail"
	v421.Visible = true
	for _, v422 in { "Redeem", "Locked" } do
		local v423 = v421:FindFirstChild(v422)
		if not v423 then
			continue
		end
		v423:Destroy()
	end
	local v_u_424 = v421:FindFirstChild("DayText")
	if not (v_u_424 and v_u_424:IsA("TextLabel")) then
		v_u_424 = nil
	end
	local v425 = v421:FindFirstChild("Decor")
	local v426
	if v425 then
		v426 = v425:FindFirstChild("Icon")
	else
		v426 = v425
	end
	local v427
	if v425 then
		v427 = v425:FindFirstChild("Sunburst")
	else
		v427 = v425
	end
	local v428 = v421:FindFirstChild("RewardText")
	if not (v428 and v428:IsA("TextLabel")) then
		v428 = nil
	end
	if not (v_u_424 and (v425 and (v425:IsA("GuiObject") and (v426 and (v426:IsA("ImageLabel") and v428))))) then
		v421:Destroy()
		return nil
	end
	v421.AnchorPoint = Vector2.zero
	v421.Position = UDim2.fromScale(0.62, 0.195)
	v421.Size = UDim2.fromScale(0.355, 0.77)
	local v429 = UDim2.fromScale(0.5, 0.065)
	local v430 = UDim2.fromScale(0.9, 0.07)
	v_u_424.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_424.Position = v429
	v_u_424.Size = v430
	local v431 = UDim2.fromScale(0.5, 0.3)
	local v432 = UDim2.fromScale(0.9, 0.36)
	v425.AnchorPoint = Vector2.new(0.5, 0.5)
	v425.Position = v431
	v425.Size = v432
	local v433 = UDim2.fromScale(0.5, 0.5)
	local v434 = UDim2.fromScale(1, 1)
	v426.AnchorPoint = Vector2.new(0.5, 0.5)
	v426.Position = v433
	v426.Size = v434
	v426.ScaleType = Enum.ScaleType.Fit
	if v427 and v427:IsA("GuiObject") then
		local v435 = UDim2.fromScale(0.5, 0.5)
		local v436 = UDim2.fromScale(2, 1.45)
		v427.AnchorPoint = Vector2.new(0.5, 0.5)
		v427.Position = v435
		v427.Size = v436
		Instance.new("UIAspectRatioConstraint").Parent = v427
	end
	local v437 = v_u_424:Clone()
	v437.Name = "ItemName"
	local v438 = UDim2.fromScale(0.5, 0.54)
	local v439 = UDim2.fromScale(0.94, 0.085)
	v437.AnchorPoint = Vector2.new(0.5, 0.5)
	v437.Position = v438
	v437.Size = v439
	v437.Parent = v421
	local v440 = UDim2.fromScale(0.5, 0.615)
	local v441 = UDim2.fromScale(0.94, 0.06)
	v428.AnchorPoint = Vector2.new(0.5, 0.5)
	v428.Position = v440
	v428.Size = v441
	v428.TextColor3 = v_u_49
	local v442 = v_u_424:Clone()
	v442.Name = "About"
	local v443 = UDim2.fromScale(0.5, 0.675)
	local v444 = UDim2.fromScale(0.92, 0.045)
	v442.AnchorPoint = Vector2.new(0.5, 0.5)
	v442.Position = v443
	v442.Size = v444
	v442.TextColor3 = v_u_50
	v442.Parent = v421
	local v445 = p420:Clone()
	v445.Name = "Amount"
	local v446 = v_u_156(v421, v445, UDim2.fromScale(0.5, 0.76), UDim2.fromScale(0.94, 0.075))
	v445.TextColor3 = v_u_36
	local v447 = v_u_319(p419, "Buy", "BUY")
	local v448 = UDim2.fromScale(0.5, 0.885)
	local v449 = UDim2.fromScale(0.84, 0.14)
	v447.AnchorPoint = Vector2.new(0.5, 0.5)
	v447.Position = v448
	v447.Size = v449
	v447.ZIndex = 5
	v447:SetAttribute("Pad", true)
	v_u_12.paint(v447, v_u_40, v_u_41)
	v447.Parent = v421
	v447.Activated:Connect(v_u_297)
	local v450 = v_u_108(v425, v_u_424.FontFace, v426.ZIndex)
	local v451 = Instance.new("Frame")
	v451.Name = "Odds"
	v451.BackgroundTransparency = 1
	local v452 = UDim2.fromScale(0.5, 0.59)
	local v453 = UDim2.fromScale(0.92, 0.165)
	v451.AnchorPoint = Vector2.new(0.5, 0.5)
	v451.Position = v452
	v451.Size = v453
	v451.ZIndex = 4
	v451.Visible = false
	local v454 = Instance.new("UIListLayout")
	v454.SortOrder = Enum.SortOrder.LayoutOrder
	v454.Padding = UDim.new(0.06, 0)
	v454.Parent = v451
	local v455 = {}
	for v456, v_u_457 in v_u_29.list do
		local v458 = Color3.fromHex(v_u_457.glow)
		local v_u_459 = Instance.new("Frame")
		v_u_459.Name = "Drop" .. v456
		v_u_459.LayoutOrder = v456
		v_u_459.Size = UDim2.fromScale(1, 0.29)
		v_u_459.BackgroundColor3 = v458:Lerp(v_u_37, 0.72)
		v_u_459.BackgroundTransparency = 0.15
		v_u_459.ZIndex = 4
		local v460 = Instance.new("UICorner")
		v460.CornerRadius = UDim.new(0.3, 0)
		v460.Parent = v_u_459
		local v461 = Instance.new("UIStroke")
		v461.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v461.Color = v458
		v461.Thickness = 1.5
		v461.Parent = v_u_459
		local function v468(p462, p463, p464, p465) -- name: text
			-- upvalues: (copy) v_u_424, (ref) v_u_36, (copy) v_u_457, (copy) v_u_459
			local v466 = Instance.new("TextLabel")
			v466.Name = p462
			v466.BackgroundTransparency = 1
			v466.AnchorPoint = Vector2.new(0, 0.5)
			v466.Position = UDim2.fromScale(p463, 0.5)
			v466.Size = UDim2.fromScale(p464, 0.8)
			v466.FontFace = v_u_424.FontFace
			v466.TextScaled = true
			v466.TextXAlignment = p465
			v466.TextColor3 = v_u_36
			v466.ZIndex = 5
			local v467 = Instance.new("UIStroke")
			v467.Color = Color3.fromHex(v_u_457.stroke)
			v467.Thickness = 1.5
			v467.LineJoinMode = Enum.LineJoinMode.Round
			v467.Parent = v466
			v466.Parent = v_u_459
			return v466
		end
		local v469 = v468("Name", 0.04, 0.56, Enum.TextXAlignment.Left)
		local v470 = v_u_457.kind == "title" and "TITLE" or (v_u_457.kind == "aura" and "AURA" or "PET")
		v469.Text = ("%* %*"):format(string.upper(v_u_27.nameOf(v_u_457)), v470)
		local v471 = {}
		for _, v472 in v_u_457.colors do
			local v473 = Color3.fromHex
			table.insert(v471, v473(v472))
		end
		local v474 = Instance.new("UIGradient")
		v474.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v471[1]), ColorSequenceKeypoint.new(0.5, v471[2]), ColorSequenceKeypoint.new(1, v471[3]) })
		v474.Parent = v469
		local v475 = v468("Odds", 0.6, 0.37, Enum.TextXAlignment.Right)
		v475.RichText = true
		v475.TextColor3 = Color3.fromRGB(120, 255, 110)
		v_u_459.Parent = v451
		table.insert(v455, v475)
	end
	v451.Parent = v421
	return {
		["root"] = v421,
		["tier"] = v_u_424,
		["decor"] = v425,
		["mult"] = v450,
		["odds"] = v451,
		["oddsRows"] = v455,
		["picture"] = v426,
		["name"] = v437,
		["gives"] = v428,
		["about"] = v442,
		["price"] = v445,
		["coin"] = v446,
		["buy"] = v447
	}
end
local function v_u_548() -- name: makeShop
	-- upvalues: (copy) v_u_311, (copy) v_u_32, (copy) v_u_329, (copy) v_u_353, (copy) v_u_116, (copy) v_u_100, (copy) v_u_25, (copy) v_u_68, (copy) v_u_4, (copy) v_u_6, (copy) v_u_31, (copy) v_u_115, (copy) v_u_319, (ref) v_u_121, (copy) v_u_268, (copy) v_u_10, (ref) v_u_118, (copy) v_u_114, (copy) v_u_417, (copy) v_u_73, (copy) v_u_17, (copy) v_u_476, (ref) v_u_119, (copy) v_u_13, (copy) v_u_256, (copy) v_u_248, (ref) v_u_117
	local v477 = v_u_311()
	local v478 = v_u_32:FindFirstChild("PlayerGui")
	if v478 then
		v478 = v478:FindFirstChild("Main")
	end
	if v478 then
		v478 = v478:FindFirstChild("Frames")
	end
	local v479
	if v477 then
		v479 = v477.card:FindFirstChild("DayText")
		if not (v479 and v479:IsA("TextLabel")) then
			v479 = nil
		end
	else
		v479 = v477
	end
	if not (v477 and (v478 and v479)) then
		warn("[BossShop] the UI pack\'s pieces are missing: no boss shop")
		return nil
	end
	local v_u_480, v481 = v_u_329(v477.store)
	if v481 then
		v_u_353(v481, v479, v477.tab)
	end
	table.clear(v_u_116)
	local v482 = {}
	for _, v483 in v_u_100 do
		local v484 = v_u_116
		local v485 = v483.tier
		table.insert(v484, v485)
		v482[v483.tier] = v483.name
	end
	local v486
	if v_u_25.on(2) and #v_u_68 ~= 0 then
		local v487 = v_u_4:IsStudio()
		if v487 then
			v487 = v_u_6:GetAttribute("DevCoinPacks") == true
		end
		if v487 then
			v486 = true
		else
			for _, v488 in v_u_68 do
				if v488.id == 0 then
					continue
				end
				v486 = true
			end
			v486 = false
		end
	else
		v486 = false
	end
	if v486 then
		local v489 = v_u_116
		table.insert(v489, "coins")
		v482.coins = "COINS"
	end
	if v_u_31.luckSold() then
		local v490 = v_u_116
		table.insert(v490, "luck")
		v482.luck = "LUCK"
	end
	local v_u_491 = Instance.new("Frame")
	v_u_491.Name = "Tabs"
	v_u_491.BackgroundTransparency = 1
	v_u_491.AnchorPoint = Vector2.zero
	v_u_491.Position = UDim2.fromScale(0.025, 0.195)
	v_u_491.Size = UDim2.fromScale(0.575, 0.085)
	v_u_491.Parent = v_u_480
	table.clear(v_u_115)
	local v492 = #v_u_116
	for v493, v_u_494 in v_u_116 do
		local v495 = v_u_319(v477.tab, "Tab_" .. v_u_494, v482[v_u_494] or v_u_494)
		local v496 = UDim2.fromScale((v493 - 0.5) / v492, 0.5)
		local v497 = UDim2.fromScale(1 / v492 - 0.02, 1)
		v495.AnchorPoint = Vector2.new(0.5, 0.5)
		v495.Position = v496
		v495.Size = v497
		v495.LayoutOrder = v493
		local v498 = v495:FindFirstChild("TextLabel")
		if not (v498 and v498:IsA("TextLabel")) then
			v498 = nil
		end
		if v498 then
			local v499 = UDim2.fromScale(0.5, 0.5)
			local v500 = UDim2.fromScale(0.92, 0.8)
			v498.AnchorPoint = Vector2.new(0.5, 0.5)
			v498.Position = v499
			v498.Size = v500
		end
		v495:SetAttribute("Pad", false)
		v495.Parent = v_u_491
		v_u_115[v_u_494] = v495
		v495.Activated:Connect(function()
			-- upvalues: (ref) v_u_121, (copy) v_u_494, (ref) v_u_268
			if v_u_121 ~= v_u_494 then
				v_u_268(v_u_494)
			end
		end)
		if v493 == 1 then
			v_u_10.hint(v495, Enum.KeyCode.ButtonL1, 26, UDim2.fromOffset(4, 4))
		else
			if v493 ~= v492 then
				continue
			end
			v_u_10.hint(v495, Enum.KeyCode.ButtonR1, 26)
		end
	end
	local function v_u_520() -- name: evenTabText
		-- upvalues: (copy) v_u_491, (ref) v_u_116, (ref) v_u_115
		local v501 = v_u_491.AbsoluteSize
		if v501.X < 10 or v501.Y < 4 then
			return
		else
			local v502 = {}
			local v503 = 0
			for _, v504 in v_u_116 do
				local v505 = v_u_115[v504]
				local v506
				if v505 then
					v506 = v505:FindFirstChild("TextLabel")
					if not (v506 and v506:IsA("TextLabel")) then
						v506 = nil
					end
				else
					v506 = v505
				end
				if not (v505 and (v506 and v505.Visible)) then
					continue
				end
				v506.TextScaled = false
				v506.TextWrapped = false
				v506.TextTruncate = Enum.TextTruncate.None
				v506.TextSize = 20
				local v507 = v506.TextBounds.X
				local v508 = math.max(v507, 1)
				table.insert(v502, {
					["tab"] = v505,
					["word"] = v506,
					["wide"] = v508
				})
				v503 = v503 + v508
			end
			if #v502 ~= 0 then
				local v509 = v501.Y / v501.X
				local v510 = 1 - (0.02 + v509) * #v502
				local v511 = math.max(v510, 0.1)
				local v512 = v501.Y * 0.8 * 0.9
				local v513 = 0.01
				for _, v514 in v502 do
					local v515 = v509 + v511 * v514.wide / v503
					v514.tab.AnchorPoint = Vector2.new(0.5, 0.5)
					v514.tab.Position = UDim2.fromScale(v513 + v515 / 2, 0.5)
					v514.tab.Size = UDim2.fromScale(v515, 1)
					v513 = v513 + (v515 + 0.02)
					local v516 = 18.400000000000002 * v515 * v501.X / v514.wide
					v512 = math.min(v512, v516)
				end
				for _, v517 in v502 do
					local v518 = v517.word
					local v519 = math.floor(v512)
					v518.TextSize = math.max(8, v519)
				end
			end
		end
	end
	v_u_491:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_520)
	task.defer(v_u_520)
	local v521 = Instance.new("Frame")
	v521.Name = "Grid"
	v521.BackgroundTransparency = 1
	v521.AnchorPoint = Vector2.zero
	v521.Position = UDim2.fromScale(0.025, 0.3)
	v521.Size = UDim2.fromScale(0.575, 0.665)
	local v522 = Instance.new("UIGridLayout")
	v522.CellSize = UDim2.fromScale(0.485, 0.485)
	v522.CellPadding = UDim2.fromScale(0.03, 0.03)
	v522.FillDirectionMaxCells = 2
	v522.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v522.VerticalAlignment = Enum.VerticalAlignment.Center
	v522.SortOrder = Enum.SortOrder.LayoutOrder
	v522.Parent = v521
	v521.Parent = v_u_480
	v_u_118 = v522
	table.clear(v_u_114)
	local v523 = 0
	for _, v524 in v_u_100 do
		for _, v525 in v524.items do
			v523 = v523 + 1
			local v526 = v_u_417(v477.card, v477.tab, v525, nil, 0, v523, #v524.items == 1)
			if not v526 then
				continue
			end
			v526.root.Parent = v521
			local v527 = v_u_114
			table.insert(v527, v526)
		end
	end
	local v528
	if v_u_25.on(2) and #v_u_68 ~= 0 then
		local v529 = v_u_4:IsStudio()
		if v529 then
			v529 = v_u_6:GetAttribute("DevCoinPacks") == true
		end
		if v529 then
			v528 = true
		else
			for _, v530 in v_u_68 do
				if v530.id == 0 then
					continue
				end
				v528 = true
			end
			v528 = false
		end
	else
		v528 = false
	end
	if v528 then
		for v531, v532 in v_u_68 do
			v523 = v523 + 1
			local v533 = v_u_417(v477.card, v477.tab, nil, v532, v531, v523, false)
			if not v533 then
				continue
			end
			v533.root.Parent = v521
			local v534 = v_u_114
			table.insert(v534, v533)
		end
	end
	if v_u_31.luckSold() then
		for v535, v536 in v_u_73 do
			v523 = v523 + 1
			local v537 = v_u_417(v477.card, v477.tab, nil, v536, v535, v523, false)
			if not v537 then
				continue
			end
			v537.root.Parent = v521
			local v538 = v_u_114
			table.insert(v538, v537)
		end
		local function v541() -- name: luckTab
			-- upvalues: (ref) v_u_115, (ref) v_u_31, (copy) v_u_520, (ref) v_u_121, (ref) v_u_268, (ref) v_u_116
			local v539 = v_u_115.luck
			if v539 then
				local v540 = v_u_31.luckShown()
				if v539.Visible ~= v540 then
					v539.Visible = v540
					v_u_520()
				end
				if not v540 and v_u_121 == "luck" then
					v_u_268(v_u_116[1])
				end
			end
		end
		local v542 = v_u_115.luck
		if v542 then
			local v543 = v_u_31.luckShown()
			if v542.Visible ~= v543 then
				v542.Visible = v543
				v_u_520()
			end
			if not v543 and v_u_121 == "luck" then
				v_u_268(v_u_116[1])
			end
		end
		v_u_17.randomChanged:Connect(v541)
	end
	local v544 = v_u_476(v477.card, v477.tab, v479)
	if v544 then
		v544.root.Parent = v_u_480
		v_u_119 = v544
	end
	v_u_10.root(v_u_480)
	v_u_480.Parent = v478
	v_u_13.run(v_u_480)
	v_u_480:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_480, (ref) v_u_256
		if v_u_480.Visible then
			v_u_256()
		end
	end)
	local function v545() -- name: changed
		-- upvalues: (copy) v_u_480, (ref) v_u_256
		if v_u_480.Visible then
			v_u_256()
		end
	end
	for _, v546 in {
		"KuramaCoins",
		"Eyes",
		"OwnedAuras",
		"World",
		"TotalWins",
		"GiftCredits",
		"Boosts"
	} do
		v_u_32:GetAttributeChangedSignal(v546):Connect(v545)
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_480, (ref) v_u_121, (ref) v_u_248
		while true do
			repeat
				task.wait(1)
			until v_u_480.Visible and v_u_121 == "luck"
			v_u_248()
		end
	end)
	v_u_32.AttributeChanged:Connect(function(p547)
		-- upvalues: (copy) v_u_480, (ref) v_u_256
		if string.sub(p547, 1, 5) == "Pass_" and v_u_480.Visible then
			v_u_256()
		end
	end)
	v_u_17.pricesChanged:Connect(v545)
	v_u_117 = v_u_480
	v_u_268(v_u_121)
	return v_u_480
end
local v_u_549 = false
function v_u_31.open(p550) -- name: open
	-- upvalues: (copy) v_u_25, (ref) v_u_117, (ref) v_u_549, (copy) v_u_548, (copy) v_u_115, (ref) v_u_121, (copy) v_u_268, (copy) v_u_14
	if v_u_25.on(2) then
		local v551
		if v_u_117 then
			v551 = v_u_117
		elseif v_u_549 then
			while v_u_549 do
				task.wait()
			end
			v551 = v_u_117
		else
			v_u_549 = true
			v551 = v_u_548()
			v_u_549 = false
		end
		if v551 then
			local v552
			if p550 then
				v552 = v_u_115[p550]
			else
				v552 = nil
			end
			if p550 and (v552 and (v552.Visible and v_u_121 ~= p550)) then
				v_u_268(p550)
			end
			if v_u_14.current() ~= "BossShop" then
				v_u_14.open("BossShop")
			end
		end
	end
end
local v_u_553 = nil
local v_u_554 = Instance.new("BindableEvent")
function v_u_31.hudShown() -- name: hudShown
	-- upvalues: (ref) v_u_553
	local v555 = v_u_553
	local v556
	if v555 == nil then
		v556 = false
	else
		v556 = v555.Visible
	end
	return v556
end
v_u_31.hudChanged = v_u_554.Event
function v_u_31.affordable() -- name: affordable
	-- upvalues: (copy) v_u_25, (copy) v_u_16, (copy) v_u_20, (copy) v_u_26, (copy) v_u_22, (copy) v_u_54
	if not v_u_25.on(2) then
		return false
	end
	local v557 = v_u_16.number("KuramaCoins")
	for _, v558 in v_u_20.SHOP do
		if v558.kind == "boost" or v558.cost > v557 then
			continue
		end
		local v559
		if v558.kind == "eye" then
			v559 = v_u_26.ownsEye(v558, v_u_16.eyes())
		elseif v558.kind == "aura" then
			local v560 = v_u_22.byId[v558.item]
			if v560 == nil then
				v559 = false
			else
				v559 = v_u_54(v560)
			end
		else
			v559 = false
		end
		if v559 then
			continue
		end
		return true
	end
	return false
end
function v_u_31.onAffordableChanged(p_u_561) -- name: onAffordableChanged
	-- upvalues: (copy) v_u_32
	for _, v562 in { "KuramaCoins", "Eyes", "OwnedAuras" } do
		v_u_32:GetAttributeChangedSignal(v562):Connect(p_u_561)
	end
	v_u_32.AttributeChanged:Connect(function(p563)
		-- upvalues: (copy) p_u_561
		if string.sub(p563, 1, 5) == "Pass_" then
			p_u_561()
		end
	end)
end
function v_u_31.hud(p_u_564, p_u_565) -- name: hud
	-- upvalues: (copy) v_u_59, (copy) v_u_33, (copy) v_u_38, (copy) v_u_39, (ref) v_u_553, (copy) v_u_18, (copy) v_u_554, (ref) v_u_117, (ref) v_u_549, (copy) v_u_548
	local v_u_566 = p_u_564:FindFirstChild("Auras")
	local v_u_567 = p_u_564:FindFirstChild("Store")
	local v_u_568 = p_u_564:FindFirstChild("Quests")
	local v_u_569 = p_u_564:FindFirstChild("MyEyes")
	local v_u_570 = p_u_564:FindFirstChild("RebirthCounter")
	local v_u_571 = p_u_564:FindFirstChild("TrophyCounter")
	if v_u_566 and (v_u_566:IsA("GuiButton") and (v_u_567 and (v_u_567:IsA("GuiObject") and (v_u_568 and (v_u_568:IsA("GuiObject") and (v_u_569 and (v_u_569:IsA("GuiObject") and (v_u_570 and (v_u_570:IsA("GuiObject") and (v_u_571 and v_u_571:IsA("ImageLabel"))))))))))) then
		local v_u_572 = v_u_571:Clone()
		v_u_59(function()
			-- upvalues: (copy) v_u_566, (ref) v_u_33, (ref) v_u_38, (ref) v_u_39, (copy) v_u_567, (copy) v_u_568, (copy) v_u_569, (copy) p_u_564, (ref) v_u_553, (copy) v_u_572, (copy) v_u_571, (copy) v_u_570, (copy) p_u_565, (ref) v_u_18, (ref) v_u_554, (ref) v_u_117, (ref) v_u_549, (ref) v_u_548
			local v_u_573 = v_u_566:Clone()
			v_u_573.Name = "BossShop"
			v_u_573.Visible = false
			v_u_573:SetAttribute("Ui-Frame", "BossShop")
			local v574 = v_u_573:FindFirstChild("TextLabel")
			if not (v574 and v574:IsA("TextLabel")) then
				v574 = nil
			end
			if v574 then
				v574.Text = "BOSS SHOP"
			end
			local v575 = v_u_573:FindFirstChild("Icon")
			if v575 and v575:IsA("ImageLabel") then
				v575.Image = v_u_33
				v575.ScaleType = Enum.ScaleType.Fit
				if not v575:FindFirstChild("Round") then
					local v576 = Instance.new("UIAspectRatioConstraint")
					v576.Name = "Round"
					v576.AspectRatio = 1
					v576.Parent = v575
				end
			end
			local v577 = v_u_573:FindFirstChildOfClass("UIGradient")
			if v577 then
				v577.Color = ColorSequence.new(v_u_38, v_u_39)
			end
			for _, v578 in v_u_573:GetChildren() do
				if v578.Name ~= "Badge" and (v578.Name ~= "Pop" and v578.Name ~= "PadHint") then
					continue
				end
				v578:Destroy()
			end
			local v579 = v_u_567.Position.X.Scale
			local v580 = v_u_568.Position.X.Scale
			local v581 = v_u_569.Position.Y.Scale - v_u_567.Position.Y.Scale
			local v582 = (v579 + v580) / 2
			local v583 = v_u_567.Position.Y.Scale - v581
			local v584 = v580 - v579 + v_u_567.Size.X.Scale
			v_u_573.Position = UDim2.fromScale(v582, v583)
			v_u_573.Size = UDim2.fromScale(v584, v_u_567.Size.Y.Scale)
			v_u_573.LayoutOrder = 0
			v_u_573.Parent = p_u_564
			v_u_553 = v_u_573
			local v_u_585 = v_u_572
			v_u_585.Name = "CoinCounter"
			v_u_585.Image = v_u_33
			v_u_585.ScaleType = Enum.ScaleType.Fit
			if not v_u_585:FindFirstChild("Round") then
				local v586 = Instance.new("UIAspectRatioConstraint")
				v586.Name = "Round"
				v586.AspectRatio = 1
				v586.Parent = v_u_585
			end
			v_u_585.Visible = false
			local v587 = v_u_571.Position.Y.Scale - v_u_570.Position.Y.Scale
			v_u_585.Position = UDim2.new(v_u_571.Position.X.Scale, v_u_571.Position.X.Offset, v_u_571.Position.Y.Scale + v587, v_u_571.Position.Y.Offset)
			v_u_585.LayoutOrder = v_u_571.LayoutOrder + 1
			v_u_585.Parent = p_u_564
			p_u_565(v_u_585)
			local v588 = v_u_18.known()
			if v588 then
				v588 = not v_u_18.active()
			end
			local v589 = v_u_573.Visible
			v_u_573.Visible = v588
			v_u_585.Visible = v588
			if v589 ~= v588 then
				v_u_554:Fire()
			end
			v_u_18.onChange(function()
				-- upvalues: (ref) v_u_18, (copy) v_u_573, (copy) v_u_585, (ref) v_u_554
				local v590 = v_u_18.known()
				if v590 then
					v590 = not v_u_18.active()
				end
				local v591 = v_u_573.Visible
				v_u_573.Visible = v590
				v_u_585.Visible = v590
				if v591 ~= v590 then
					v_u_554:Fire()
				end
			end)
			if not v_u_117 then
				if v_u_549 then
					while v_u_549 do
						task.wait()
					end
				else
					v_u_549 = true
					v_u_548()
					v_u_549 = false
				end
			end
		end)
	end
end
local function v_u_602() -- name: bindStalls
	-- upvalues: (copy) v_u_6, (copy) v_u_25, (copy) v_u_18, (copy) v_u_2, (copy) v_u_32, (copy) v_u_31
	local v_u_592 = v_u_6:WaitForChild("BossShops", 60)
	if v_u_592 then
		local function v595(p593) -- name: setup
			-- upvalues: (ref) v_u_25, (ref) v_u_18
			if p593:IsA("ProximityPrompt") and p593.Name == "BossShopPrompt" then
				local v594 = v_u_25.on(2) and v_u_18.known()
				if v594 then
					v594 = not v_u_18.active()
				end
				p593.Enabled = v594
			end
		end
		v_u_592.DescendantAdded:Connect(v595)
		v_u_18.onChange(function()
			-- upvalues: (copy) v_u_592, (ref) v_u_25, (ref) v_u_18
			for _, v596 in v_u_592:GetDescendants() do
				if not v596:IsA("ProximityPrompt") or v596.Name ~= "BossShopPrompt" then
					continue
				end
				local v597 = v_u_25.on(2) and v_u_18.known()
				if v597 then
					v597 = not v_u_18.active()
				end
				v596.Enabled = v597
			end
		end)
		for _, v598 in v_u_592:GetDescendants() do
			if not v598:IsA("ProximityPrompt") or v598.Name ~= "BossShopPrompt" then
				continue
			end
			local v599 = v_u_25.on(2) and v_u_18.known()
			if v599 then
				v599 = not v_u_18.active()
			end
			v598.Enabled = v599
		end
		v_u_2.PromptTriggered:Connect(function(p600, p601)
			-- upvalues: (ref) v_u_32, (copy) v_u_592, (ref) v_u_31
			if p601 == v_u_32 and (p600.Name == "BossShopPrompt" and p600:IsDescendantOf(v_u_592)) then
				v_u_31.open()
			end
		end)
	end
end
function v_u_31.start() -- name: start
	-- upvalues: (copy) v_u_59, (ref) v_u_117, (ref) v_u_549, (copy) v_u_548, (copy) v_u_602, (copy) v_u_9, (copy) v_u_307, (copy) v_u_5, (copy) v_u_14, (copy) v_u_276, (copy) v_u_10, (ref) v_u_119, (ref) v_u_122, (copy) v_u_114
	v_u_59(function()
		-- upvalues: (ref) v_u_117, (ref) v_u_549, (ref) v_u_548
		if not v_u_117 then
			if v_u_549 then
				while v_u_549 do
					task.wait()
				end
			else
				v_u_549 = true
				v_u_548()
				v_u_549 = false
			end
		end
	end)
	v_u_59(v_u_602)
	v_u_9.onNotify("KuramaCoins", v_u_307)
	v_u_5.InputBegan:Connect(function(p603)
		-- upvalues: (ref) v_u_14, (ref) v_u_276
		if v_u_14.current() == "BossShop" then
			if p603.KeyCode == Enum.KeyCode.ButtonL1 then
				v_u_276(-1)
			elseif p603.KeyCode == Enum.KeyCode.ButtonR1 then
				v_u_276(1)
			end
		else
			return
		end
	end)
	v_u_10.onBack(function(p604)
		-- upvalues: (ref) v_u_119, (ref) v_u_14, (ref) v_u_122, (ref) v_u_114, (ref) v_u_10
		local v605 = v_u_119
		if v_u_14.current() ~= "BossShop" or (not v605 or p604 ~= v605.buy) then
			return false
		end
		local v606 = v_u_122
		local v607
		if v606 and v606.root.Visible then
			v607 = v606.pick
		else
			for _, v608 in v_u_114 do
				if not v608.root.Visible then
					continue
				end
				v607 = v608.pick
			end
			v607 = nil
		end
		if not v607 then
			return false
		end
		v_u_10.select(v607)
		return true
	end, 20)
end
return v_u_31