local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Store)
local v6 = v2.Shared
local v_u_7 = require(v6.Config.Images)
local v_u_8 = require(v6.Config.Perks)
local v_u_9 = require(v6.Config.Products)
local v_u_10 = require(v6.Config.Release)
local v_u_11 = require(v6.Logic.Format)
local v_u_12 = require(v6.Logic.Offers)
local v_u_13 = require(v6.Logic.VipPlus)
local v_u_14 = {}
local v_u_15 = v1.LocalPlayer
local function v19(p16, p17, p18) -- name: rgb
	return Color3.fromRGB(p16, p17, p18)
end
local v_u_20 = { Color3.fromRGB(255, 226, 60), v19(255, 150, 0) }
local v_u_21 = { Color3.fromRGB(206, 120, 255), v19(132, 40, 230) }
local v_u_22 = { Color3.fromRGB(255, 150, 90), v19(222, 52, 52) }
local v_u_23 = { Color3.fromRGB(69, 200, 255), v19(0, 128, 255) }
local v_u_24 = { Color3.fromRGB(125, 240, 95), v19(30, 168, 70) }
local v_u_25 = { Color3.fromRGB(255, 125, 220), v19(196, 48, 168) }
local function v_u_32(p26, p27) -- name: paintTile
	if p26:IsA("GuiObject") then
		p26.Visible = true
		local v28 = p26:FindFirstChild("Count")
		local v29 = p26:FindFirstChild("Name")
		local v30 = p26:FindFirstChild("Icon")
		if v28 and v28:IsA("TextLabel") then
			v28.Text = p27.count
		end
		if v29 and v29:IsA("TextLabel") then
			v29.Text = p27.name
		end
		if v30 and v30:IsA("ImageLabel") then
			v30.Image = p27.icon
		end
		local v31 = p26:FindFirstChildOfClass("UIGradient")
		if v31 then
			v31.Color = ColorSequence.new(p27.colors[1], p27.colors[2])
			v31.Rotation = 90
		end
	end
end
local function v_u_43(p33, p34) -- name: tilesOf
	local v35 = p33:FindFirstChild("Tiles")
	if not v35 then
		return {}
	end
	local v36 = v35:FindFirstChild("Tile5")
	for v37 = 6, p34 do
		if not v36 or v35:FindFirstChild("Tile" .. v37) then
			continue
		end
		local v38 = v36:Clone()
		v38.Name = "Tile" .. v37
		v38.LayoutOrder = v37
		v38.Parent = v35
	end
	local v39 = (1 - (p34 - 1) * 0.012) / p34
	local v40 = {}
	for v41 = 1, p34 do
		local v42 = v35:FindFirstChild("Tile" .. v41)
		if not (v42 and v42:IsA("GuiObject")) then
			continue
		end
		v42.Size = UDim2.fromScale(v39, 1)
		table.insert(v40, v42)
	end
	return v40
end
local function v_u_52(p44, p45, p46, p47) -- name: copyCard
	local v48 = p44:FindFirstChild("Pack_pro")
	if not v48 or p44:FindFirstChild("Pack_" .. p45) then
		return nil
	end
	local v49 = v48:Clone()
	v49.Name = "Pack_" .. p45
	v49.LayoutOrder = p47
	for _, v50 in v49:GetChildren() do
		if not v50:IsA("TextLabel") or (v50.Name ~= "Title" or (v50.Rotation ~= 0 or v50.Text ~= "PRO PACK")) then
			continue
		end
		v50.Text = p46
	end
	local v51 = v49:FindFirstChild("Purchase1")
	if v51 then
		v51:SetAttribute("Ui-Pass", p45)
		v51:SetAttribute("Ui-Pack", nil)
	end
	return v49
end
local function v_u_56(p53, p54) -- name: setTag
	for _, v55 in p53:GetChildren() do
		if not v55:IsA("TextLabel") or (v55.Name ~= "Title" or v55.Rotation == 0) then
			continue
		end
		v55.Text = p54
	end
end
local v_u_57 = {
	[v_u_8.HOKAGE_PASS] = true,
	["ultimate"] = true
}
local function v_u_64(p58) -- name: worthOf
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_13, (copy) v_u_5
	local v59 = v_u_9.productByKey.kuramaCoins1500
	local v60 = (p58 ~= v_u_8.HOKAGE_PASS or not v59) and 0 or v59.price * v_u_8.HOKAGE_COINS / (v59.coins or v_u_8.HOKAGE_COINS)
	local v63 = v_u_13.saving(0, v_u_9.BUNDLES[p58] or {}, function(p61)
		-- upvalues: (ref) v_u_5
		local v62 = v_u_5.pass(p61)
		return not v62 and 0 or v62.price
	end, v60) + 0.5
	return math.floor(v63)
end
function v_u_14.discount(p65) -- name: discount
	-- upvalues: (copy) v_u_5, (copy) v_u_57, (copy) v_u_64, (copy) v_u_12
	local v66 = v_u_5.pass(p65)
	if not (v66 and v_u_57[p65]) then
		return nil, nil
	end
	local v67 = v_u_64(p65)
	return v_u_12.struck(v66.price, v67), v_u_12.savePercent(v66.price, v67)
end
local function v_u_79(p68) -- name: struckLabel
	local v_u_69 = Instance.new("TextLabel")
	v_u_69.Name = "Was"
	v_u_69.BackgroundTransparency = 1
	v_u_69.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_69.Position = UDim2.fromScale(0.62, -0.02)
	v_u_69.Size = UDim2.fromScale(0.6, 0.5)
	v_u_69.TextScaled = true
	v_u_69.Text = ""
	v_u_69.TextColor3 = Color3.fromRGB(255, 72, 72)
	v_u_69.ZIndex = 12
	local v70 = p68:FindFirstChild("PriceTag")
	if v70 and v70:IsA("TextLabel") then
		v_u_69.FontFace = v70.FontFace
	end
	local v71 = Instance.new("UIStroke")
	v71.Thickness = 2
	v71.Parent = v_u_69
	local v_u_72 = Instance.new("Frame")
	v_u_72.Name = "Line"
	v_u_72.BorderSizePixel = 0
	v_u_72.BackgroundColor3 = Color3.fromRGB(255, 40, 40)
	v_u_72.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_72.Position = UDim2.fromScale(0.5, 0.52)
	v_u_72.Rotation = -16
	v_u_72.ZIndex = 13
	local v73 = Instance.new("UIStroke")
	v73.Thickness = 1.5
	v73.Parent = v_u_72
	v_u_72.Parent = v_u_69
	v_u_69:GetPropertyChangedSignal("TextBounds"):Connect(function() -- name: fit
		-- upvalues: (copy) v_u_72, (copy) v_u_69
		local v74 = v_u_72
		local v75 = UDim2.new
		local v76 = v_u_69.TextBounds.X * 1.2
		v74.Size = v75(0, math.max(v76, 8), 0.12, 0)
	end)
	local v77 = UDim2.new
	local v78 = v_u_69.TextBounds.X * 1.2
	v_u_72.Size = v77(0, math.max(v78, 8), 0.12, 0)
	v_u_69.Parent = p68
	return v_u_69
end
local function v_u_89(p_u_80, p_u_81) -- name: discountOn
	-- upvalues: (copy) v_u_79, (copy) v_u_14, (copy) v_u_15, (copy) v_u_11, (copy) v_u_56, (copy) v_u_5
	local v82 = p_u_80:FindFirstChild("Purchase1")
	if v82 and not v82:FindFirstChild("Was") then
		local v_u_83 = v_u_79(v82)
		local function v88() -- name: show
			-- upvalues: (ref) v_u_14, (copy) p_u_81, (copy) v_u_83, (ref) v_u_15, (ref) v_u_11, (ref) v_u_56, (copy) p_u_80
			local v84, v85 = v_u_14.discount(p_u_81)
			local v86 = v_u_83
			local v87
			if v84 == nil then
				v87 = false
			else
				v87 = v_u_15:GetAttribute("Pass_" .. p_u_81) ~= true
			end
			v86.Visible = v87
			v_u_83.Text = not v84 and "" or v_u_11.commas(v84)
			if v85 then
				v_u_56(p_u_80, (("-%*%% OFF!"):format(v85)))
			end
		end
		v88()
		v_u_5.pricesChanged:Connect(v88)
		v_u_15:GetAttributeChangedSignal("Pass_" .. p_u_81):Connect(v88)
	end
end
local function v_u_93(p90) -- name: made
	-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_3, (copy) v_u_4
	local v91 = v_u_5.pass(p90)
	if not (v91 and v_u_10.on(2)) then
		return false
	end
	local v92 = v91.id == 0 and v_u_3:IsStudio()
	if v92 then
		v92 = v_u_4:GetAttribute("DevStoreCards") == true
	end
	return v92
end
local function v_u_104(p94, p95) -- name: vipPlusCard
	-- upvalues: (copy) v_u_52, (copy) v_u_8, (copy) v_u_43, (copy) v_u_7, (copy) v_u_20, (copy) v_u_21, (copy) v_u_22, (copy) v_u_32, (copy) v_u_56, (copy) v_u_5, (copy) v_u_15
	local v_u_96 = v_u_52(p94, v_u_8.VIP_PLUS_PASS, "VIP+", p95)
	if v_u_96 then
		local v97 = v_u_43(v_u_96, 5)
		local v98 = {
			{
				["icon"] = nil,
				["count"] = "x1.5",
				["name"] = "All of VIP",
				["colors"] = nil,
				["icon"] = v_u_7.Aura.vip_aura,
				["colors"] = v_u_20
			},
			{
				["icon"] = nil,
				["count"] = "+75%",
				["name"] = "VIP+ Aura",
				["colors"] = nil,
				["icon"] = v_u_7.Aura.vip_plus_aura,
				["colors"] = v_u_21
			},
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "Royal Lion",
				["colors"] = nil,
				["icon"] = v_u_7.Pet.royal_lion,
				["colors"] = v_u_22
			},
			{
				["icon"] = "rbxassetid://122420734012429",
				["count"] = "",
				["name"] = "VIP+ Title",
				["colors"] = nil,
				["colors"] = v_u_20
			},
			{
				["icon"] = nil,
				["count"] = "+20%",
				["name"] = "Kyubi Coins",
				["colors"] = nil,
				["icon"] = v_u_7.Icon.KuramaCoin,
				["colors"] = v_u_22
			}
		}
		for v99, v100 in v97 do
			local v101 = v98[v99]
			if not v101 then
				continue
			end
			v_u_32(v100, v101)
		end
		local function v102() -- name: tag
			-- upvalues: (ref) v_u_56, (copy) v_u_96, (ref) v_u_5, (ref) v_u_8
			v_u_56(v_u_96, v_u_5.upgradeFor(v_u_8.VIP_PLUS_PASS) and "UPGRADE FROM VIP!" or "VIP + MORE!")
		end
		v_u_56(v_u_96, v_u_5.upgradeFor(v_u_8.VIP_PLUS_PASS) and "UPGRADE FROM VIP!" or "VIP + MORE!")
		for _, v103 in { "Pass_" .. v_u_8.VIP_PASS, "Pass_" .. v_u_8.VIP_PLUS_PASS } do
			v_u_15:GetAttributeChangedSignal(v103):Connect(function()
				-- upvalues: (ref) v_u_56, (copy) v_u_96, (ref) v_u_5, (ref) v_u_8
				v_u_56(v_u_96, v_u_5.upgradeFor(v_u_8.VIP_PLUS_PASS) and "UPGRADE FROM VIP!" or "VIP + MORE!")
				v_u_5.firePricesChanged()
			end)
		end
		v_u_5.pricesChanged:Connect(v102)
		v_u_96.Parent = p94
	end
end
local function v_u_138(p105, p106) -- name: hokageCard
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_52, (copy) v_u_89, (copy) v_u_43, (copy) v_u_7, (copy) v_u_21, (copy) v_u_22, (copy) v_u_25, (copy) v_u_20, (copy) v_u_24, (copy) v_u_23, (copy) v_u_11, (copy) v_u_32
	local v107 = v_u_5.pass(v_u_8.HOKAGE_PASS)
	local v_u_108 = v_u_52(p105, v_u_8.HOKAGE_PASS, "HOKAGE OP BUNDLE", p106)
	if v_u_108 and v107 then
		v_u_89(v_u_108, v_u_8.HOKAGE_PASS)
		local v_u_109 = v_u_43(v_u_108, 6)
		local v_u_110 = {}
		local v111 = {
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "VIP+",
				["colors"] = nil,
				["icon"] = v_u_7.Aura.vip_plus_aura,
				["colors"] = v_u_21
			},
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "Kyubi",
				["colors"] = nil,
				["icon"] = v_u_7.Pet.kurama,
				["colors"] = v_u_22
			},
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "Prism Eye",
				["colors"] = nil,
				["icon"] = v_u_7.Iris.prism_eye,
				["colors"] = v_u_25
			},
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "Shin Eye",
				["colors"] = nil,
				["icon"] = v_u_7.Iris.shin_ketsuryugan,
				["colors"] = v_u_22
			},
			{
				["icon"] = nil,
				["count"] = "",
				["name"] = "Otsutsuki Aura",
				["colors"] = nil,
				["icon"] = v_u_7.Aura.otsutsuki,
				["colors"] = v_u_21
			},
			{
				["icon"] = "rbxassetid://122420734012429",
				["count"] = "",
				["name"] = "HOKAGE Title",
				["colors"] = nil,
				["colors"] = v_u_20
			}
		}
		local v112 = {}
		local v113 = {
			["icon"] = nil,
			["count"] = "AUTO",
			["name"] = "Auto Win",
			["colors"] = nil
		}
		local v114 = v_u_7.Icon.Trophy
		local v115 = p105:FindFirstChild("Pass_autoWin")
		if v115 then
			v115 = v115:FindFirstChild("Icon")
		end
		if v115 and (v115:IsA("ImageLabel") and v115.Image ~= "") then
			v114 = v115.Image
		end
		v113.icon = v114
		v113.colors = v_u_22
		local v116 = {
			["icon"] = nil,
			["count"] = "x3",
			["name"] = "Wins Pad",
			["colors"] = nil
		}
		local v117 = v_u_7.Icon.Trophy
		local v118 = p105:FindFirstChild("Pass_winsPad")
		if v118 then
			v118 = v118:FindFirstChild("Icon")
		end
		if v118 and (v118:IsA("ImageLabel") and v118.Image ~= "") then
			v117 = v118.Image
		end
		v116.icon = v117
		v116.colors = v_u_21
		local v119 = {
			["icon"] = nil,
			["count"] = "AUTO",
			["name"] = "Auto Rebirth",
			["colors"] = nil
		}
		local v120 = v_u_7.Icon.Rebirth
		local v121 = p105:FindFirstChild("Pass_autoRebirth")
		if v121 then
			v121 = v121:FindFirstChild("Icon")
		end
		if v121 and (v121:IsA("ImageLabel") and v121.Image ~= "") then
			v120 = v121.Image
		end
		v119.icon = v120
		v119.colors = v_u_25
		local v122 = {
			["icon"] = nil,
			["count"] = "+3",
			["name"] = "Pet Equip",
			["colors"] = nil
		}
		local v123 = v_u_7.Icon.EggShinobi
		local v124 = p105:FindFirstChild("Pass_equip2")
		if v124 then
			v124 = v124:FindFirstChild("Icon")
		end
		if v124 and (v124:IsA("ImageLabel") and v124.Image ~= "") then
			v123 = v124.Image
		end
		v122.icon = v123
		v122.colors = v_u_24
		local v125 = {
			["icon"] = nil,
			["count"] = "x2",
			["name"] = "Speed",
			["colors"] = nil
		}
		local v126 = v_u_7.Icon.Chakra
		local v127 = p105:FindFirstChild("Pass_speed2")
		if v127 then
			v127 = v127:FindFirstChild("Icon")
		end
		if v127 and (v127:IsA("ImageLabel") and v127.Image ~= "") then
			v126 = v127.Image
		end
		v125.icon = v126
		v125.colors = v_u_23
		__set_list(v112, 1, {v113, v116, v119, v122, v125, {
	["icon"] = nil,
	["count"] = nil,
	["name"] = "Kyubi Coins",
	["colors"] = nil,
	["icon"] = v_u_7.Icon.KuramaCoin,
	["count"] = v_u_11.commas(v_u_8.HOKAGE_COINS),
	["colors"] = v_u_20
}})
		__set_list(v_u_110, 1, {v111, v112})
		local v128 = 1
		local v_u_129 = v128
		for v130, v131 in v_u_109 do
			local v132 = v_u_110[v_u_129][v130]
			if not v132 then
				continue
			end
			v_u_32(v131, v132)
		end
		v_u_108.Parent = p105
		task.spawn(function()
			-- upvalues: (copy) v_u_108, (ref) v_u_129, (copy) v_u_110, (copy) v_u_109, (ref) v_u_32
			local v133 = v_u_108:FindFirstAncestor("Store")
			while v_u_108.Parent do
				task.wait(3)
				local v134 = v133 ~= nil and v133:IsA("GuiObject")
				if v134 then
					v134 = v133.Visible
				end
				if not (v134 and v_u_108.Visible) then
					continue
				end
				v_u_129 = v_u_129 % #v_u_110 + 1
				for v135, v136 in v_u_109 do
					local v137 = v_u_110[v_u_129][v135]
					if not v137 then
						continue
					end
					v_u_32(v136, v137)
				end
			end
		end)
	end
end
function v_u_14.promoWeight(p139) -- name: promoWeight
	-- upvalues: (copy) v_u_8, (copy) v_u_93, (copy) v_u_15, (copy) v_u_9, (copy) v_u_13
	if p139 ~= v_u_8.VIP_PLUS_PASS and p139 ~= v_u_8.HOKAGE_PASS then
		return nil
	end
	if not v_u_93(p139) or v_u_15:GetAttribute("Pass_" .. p139) == true then
		return 0
	end
	local v140 = 0
	for _, v141 in v_u_9.passes do
		if v_u_15:GetAttribute("Pass_" .. v141.key) ~= true then
			continue
		end
		v140 = v140 + 1
	end
	return v_u_13.promoWeight(v140, v_u_8.PROMO_MIN_PASSES, v_u_8.PROMO_WEIGHT)
end
function v_u_14.promoPicture(p142) -- name: promoPicture
	-- upvalues: (copy) v_u_8, (copy) v_u_7
	if p142 == v_u_8.VIP_PLUS_PASS then
		return v_u_7.Aura.vip_plus_aura
	elseif p142 == v_u_8.HOKAGE_PASS then
		return v_u_7.Icon.Deal
	else
		return nil
	end
end
function v_u_14.made(p143) -- name: made
	-- upvalues: (copy) v_u_8, (copy) v_u_93
	local v144
	if p143 == v_u_8.VIP_PLUS_PASS or p143 == v_u_8.HOKAGE_PASS then
		v144 = v_u_93(p143)
	else
		v144 = false
	end
	return v144
end
function v_u_14.promoDiscount(p145) -- name: promoDiscount
	-- upvalues: (copy) v_u_14
	local v146, v147 = v_u_14.discount(p145)
	if v146 and v147 then
		return ("-%*%% OFF!"):format(v147), v146
	else
		return nil, nil
	end
end
function v_u_14.add(p148) -- name: add
	-- upvalues: (copy) v_u_93, (copy) v_u_8, (copy) v_u_138, (copy) v_u_104, (copy) v_u_89
	if v_u_93(v_u_8.HOKAGE_PASS) then
		v_u_138(p148, 5)
	end
	if v_u_93(v_u_8.VIP_PLUS_PASS) then
		v_u_104(p148, 6)
	end
	local v149 = p148:FindFirstChild("Pack_ultimate")
	if v149 then
		v_u_89(v149, "ultimate")
	end
end
return v_u_14