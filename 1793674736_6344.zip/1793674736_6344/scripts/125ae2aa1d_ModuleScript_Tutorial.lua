return {
	["step"] = function(p1) -- name: step
		return (p1.done or p1.rebirths > 0) and "done" or (p1.totalWins <= 0 and (p1.inWave and "fight" or (p1.runCleared >= 1 and "pad" or "battle")) or (p1.upgraded and (p1.usedE and (p1.usedR and (p1.trained and (p1.level < p1.rebirthLevel and (p1.onPlot and "level" or "train") or "rebirth") or "train") or "skillR") or "skillE") or "eye"))
	end
}