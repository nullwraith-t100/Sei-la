require(script.Parent.Parent.Config.Products)
require(script.Parent.Prizes)
local v_u_1 = {}
local v_u_2 = {
	["chakra"] = {
		["mult"] = 2,
		["wins"] = false
	},
	["chakra5"] = {
		["mult"] = 5,
		["wins"] = false
	},
	["chakra10"] = {
		["mult"] = 10,
		["wins"] = false
	},
	["wins"] = {
		["mult"] = 2,
		["wins"] = true
	}
}
function v_u_1.prizeWorth(p3, p4) -- name: prizeWorth
	-- upvalues: (copy) v_u_2
	local v5 = nil
	if p3.kind == "boost" then
		local v6 = v_u_2[p3.boost or "chakra"]
		local v7 = p3.minutes or 0
		for _, v8 in p4 do
			local v9 = v8.minutes or 0
			if not v6 or (v8.kind ~= "boost" or (v8.id == 0 or (v9 <= 0 or v8.mult ~= v6.mult))) or v8.boost == "wins" ~= v6.wins then
				continue
			end
			local v10 = v7 * v8.price / v9
			if v5 ~= nil and v10 >= v5 then
				continue
			end
			v5 = v10
		end
	elseif p3.kind == "egg" and (p3.tier == nil and p3.egg) then
		local v11 = p3.count or 1
		for _, v12 in p4 do
			local v13 = v12.count or 0
			if v12.kind ~= "egg" or (v12.id == 0 or (v12.egg ~= p3.egg or v13 <= 0)) then
				continue
			end
			local v14 = v11 * v12.price / v13
			if v5 ~= nil and v14 >= v5 then
				continue
			end
			v5 = v14
		end
	end
	if not v5 then
		return 0
	end
	local v15 = v5 + 1e-6
	return math.floor(v15)
end
function v_u_1.packWorth(p16, p17) -- name: packWorth
	-- upvalues: (copy) v_u_1
	local v18 = 0
	for _, v19 in p16 do
		v18 = v18 + v_u_1.prizeWorth(v19, p17)
	end
	return v18
end
function v_u_1.bundleWorth(p20, p21) -- name: bundleWorth
	local v22 = 0
	for _, v23 in p20 do
		local v24 = p21[v23.key]
		if not v24 or v24.id == 0 then
			continue
		end
		v22 = v22 + v24.price * v23.count
	end
	return v22
end
function v_u_1.struck(p25, p26) -- name: struck
	if p25 < p26 then
		return p26
	else
		return nil
	end
end
function v_u_1.savePercent(p27, p28) -- name: savePercent
	if p28 <= 0 or p28 <= p27 then
		return nil
	else
		local v29 = (1 - p27 / p28) * 100
		local v30 = math.floor(v29)
		if v30 >= 1 then
			return v30
		else
			return nil
		end
	end
end
v_u_1.UNLOCK_MIN_DAYS = 2
function v_u_1.unlockShown(p31) -- name: unlockShown
	-- upvalues: (copy) v_u_1
	return v_u_1.UNLOCK_MIN_DAYS <= p31
end
return v_u_1