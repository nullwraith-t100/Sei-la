local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.BalaPow,
	v_u_7.HollowRing,
	v_u_7.FxSmoke,
	v_u_7.FxTwinkle
})
local v_u_8 = Color3.fromHex("2EE6C9")
local v_u_9 = Color3.fromHex("F2EBD9")
local v_u_10 = Color3.fromRGB(196, 186, 165)
local v_u_11 = Color3.fromRGB(8, 110, 100)
local v_u_12 = Color3.fromRGB(14, 40, 38)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.Material.SmoothPlastic
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_17 = CFrame.identity
local function v_u_22(p18, p19, p20) -- name: sized
	local v21 = math.clamp(p20 or 0.25, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 / 2), NumberSequenceKeypoint.new(v21, p19 / 2), NumberSequenceKeypoint.new(1, p19 / 2) })
end
local function v_u_25(p23) -- name: fading
	local v24 = math.clamp(p23 or 0.55, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(v24, 0.1), NumberSequenceKeypoint.new(1, 1) })
end
local function v_u_32(p26, p27, p28, p29) -- name: once
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v30 = Instance.new("Attachment")
	v30.WorldCFrame = p26
	v30.Parent = v_u_3.Terrain
	local v31 = Instance.new("ParticleEmitter")
	v31.Enabled = false
	v31.LightInfluence = 0
	v31.Speed = NumberRange.new(0)
	v31.Lifetime = NumberRange.new(p27)
	p29(v31)
	v31.Parent = v30
	v31:Emit(p28)
	v_u_1:AddItem(v30, p27 + 0.3)
end
local function v_u_46(p33, p34, p_u_35, p_u_36, p_u_37, p_u_38, p39, p_u_40, p_u_41) -- name: plane
	-- upvalues: (copy) v_u_32, (copy) v_u_22, (copy) v_u_25, (copy) v_u_16
	local v42 = p34.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p34.Unit
	local v43 = v42.Y
	local v44
	if math.abs(v43) > 0.98 then
		v44 = CFrame.new(p33)
	else
		v44 = CFrame.fromMatrix(p33, v42:Cross(Vector3.new(0, 1, 0)).Unit, v42)
	end
	v_u_32(v44, p39, 1, function(p45)
		-- upvalues: (copy) p_u_35, (copy) p_u_36, (copy) p_u_41, (ref) v_u_22, (copy) p_u_37, (copy) p_u_38, (ref) v_u_25, (copy) p_u_40, (ref) v_u_16
		p45.Texture = p_u_35
		p45.Color = ColorSequence.new(p_u_36)
		p45.LightEmission = p_u_41 or 0.2
		p45.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		p45.EmissionDirection = Enum.NormalId.Top
		p45.SpreadAngle = Vector2.zero
		p45.Speed = NumberRange.new(0.01)
		p45.Size = v_u_22(p_u_37, p_u_38)
		p45.Transparency = v_u_25()
		p45.Rotation = NumberRange.new(0, 360)
		if p_u_40 then
			p45.FlipbookLayout = v_u_16
			p45.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
	end)
end
local function v_u_53(p47, p48, p49, p50, p51) -- name: block
	-- upvalues: (copy) v_u_15, (copy) v_u_4
	local v52
	if p51 then
		v52 = Instance.new("WedgePart")
	else
		v52 = Instance.new("Part")
	end
	v52.Anchored = true
	v52.CanCollide = false
	v52.CanQuery = false
	v52.CanTouch = false
	v52.CastShadow = false
	v52.Material = p49 or v_u_15
	v52.Color = p48
	v52.Transparency = p50 or 0
	v52.Size = p47
	v52.CFrame = CFrame.new(0, -500, 0)
	v52.Parent = v_u_4.folder()
	return v52
end
local function v_u_59(p54) -- name: maskPiece
	-- upvalues: (copy) v_u_2, (copy) v_u_9, (copy) v_u_15, (copy) v_u_4, (copy) v_u_1
	local v55 = v_u_2:FindFirstChild("EyePieces")
	if v55 then
		v55 = v55:FindFirstChild("w7_resurreccion")
	end
	if not (v55 and v55:IsA("MeshPart")) then
		return nil
	end
	local v56 = v55:Clone()
	local v57 = v55.Size
	local v58 = v55.Size.Y
	v56.Size = v57 * (p54 / math.max(v58, 0.01))
	if not v56:FindFirstChildWhichIsA("SurfaceAppearance") then
		v56.Color = v_u_9
		v56.Material = v_u_15
	end
	v56.Anchored = true
	v56.CanCollide = false
	v56.CanQuery = false
	v56.CanTouch = false
	v56.CastShadow = false
	v56.Massless = true
	v56.Parent = v_u_4.folder()
	v_u_1:AddItem(v56, 6)
	return v56
end
return function(p_u_60)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_53, (copy) v_u_14, (copy) v_u_13, (copy) v_u_11, (copy) v_u_3, (copy) v_u_46, (copy) v_u_7, (copy) v_u_32, (copy) v_u_25, (copy) v_u_22, (copy) v_u_16, (copy) v_u_59, (copy) v_u_17, (copy) v_u_10, (copy) v_u_9, (copy) v_u_15, (copy) v_u_6, (copy) v_u_12
	local v102 = {
		["resurreccion_a"] = {
			["cast"] = function(p61) -- name: cast
				-- upvalues: (ref) v_u_46, (ref) v_u_7, (ref) v_u_8
				local v62 = p61.size
				v_u_46(p61.eye + p61.dir * 1.6, p61.dir, v_u_7.HollowRing, v_u_8, 1 * v62, 4 * v62, 0.2, true, 0.3)
			end,
			["shot"] = function(p_u_63, p64) -- name: fistShot
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_53, (ref) v_u_14, (ref) v_u_13, (ref) v_u_11, (copy) p_u_60, (ref) v_u_3, (ref) v_u_46, (ref) v_u_7
				local v_u_65 = p_u_63.size
				local v_u_66 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p64, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_66, 4)
				local v_u_67 = {}
				local v68 = CFrame.new(0, 0, 0.35 * v_u_65)
				local v69 = v_u_8
				local v70 = v_u_53(Vector3.new(1, 1.15, 1) * v_u_65, v69, v_u_14, 0.15)
				v_u_1:AddItem(v70, 4)
				table.insert(v_u_67, {
					["p"] = v70,
					["off"] = v68
				})
				if not p_u_63.lite then
					for v71 = 0, 3 do
						local v72 = CFrame.new((v71 * 0.24 + -0.36) * v_u_65, 0.36 * v_u_65, -0.25 * v_u_65)
						local v73 = v_u_13
						local v74 = v_u_53(Vector3.new(0.26, 0.3, 0.42) * v_u_65, v73, v_u_14, 0.05)
						v_u_1:AddItem(v74, 4)
						table.insert(v_u_67, {
							["p"] = v74,
							["off"] = v72
						})
					end
					local v75 = CFrame.new(0.05 * v_u_65, -0.12 * v_u_65, -0.22 * v_u_65)
					local v76 = v_u_11
					local v77 = v_u_53(Vector3.new(0.75, 0.28, 0.4) * v_u_65, v76, v_u_14, 0.05)
					v_u_1:AddItem(v77, 4)
					table.insert(v_u_67, {
						["p"] = v77,
						["off"] = v75
					})
				end
				p_u_60.streak(v_u_66, v_u_8, v_u_11, 1.1 * v_u_65, 0.12)
				local v_u_78 = -1
				local v_u_79 = false
				return {
					["place"] = function(p80, p81) -- name: place
						-- upvalues: (copy) v_u_66, (copy) v_u_67, (ref) v_u_3, (copy) p_u_63, (ref) v_u_78, (ref) v_u_46, (ref) v_u_7, (ref) v_u_8, (copy) v_u_65
						v_u_66.CFrame = p80
						local v82 = p80 * CFrame.Angles(0, 0, p81 * 6)
						local v83 = {}
						local v84 = {}
						for _, v85 in v_u_67 do
							local v86 = v85.p
							table.insert(v83, v86)
							local v87 = v82 * v85.off
							table.insert(v84, v87)
						end
						v_u_3:BulkMoveTo(v83, v84, Enum.BulkMoveMode.FireCFrameChanged)
						if not p_u_63.lite and p81 - v_u_78 >= 0.035 then
							v_u_78 = p81
							v_u_46(p80.Position, p80.LookVector, v_u_7.HollowRing, v_u_8, 0.8 * v_u_65, 3.4 * v_u_65, 0.22, true, 0.3)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_79, (copy) v_u_67, (ref) v_u_1, (copy) v_u_66
						if not v_u_79 then
							v_u_79 = true
							for _, v88 in v_u_67 do
								v88.p:Destroy()
							end
							v_u_1:AddItem(v_u_66, 0.3)
						end
					end
				}
			end,
			["impact"] = function(p89, p90) -- name: impact
				-- upvalues: (ref) v_u_32, (ref) v_u_7, (ref) v_u_8, (ref) v_u_25, (ref) v_u_46, (copy) p_u_60, (ref) v_u_11, (ref) v_u_13
				local v_u_91 = p89.size
				v_u_32(CFrame.new(p90), 0.24, 1, function(p92)
					-- upvalues: (ref) v_u_7, (ref) v_u_8, (copy) v_u_91, (ref) v_u_25
					p92.Texture = v_u_7.BalaPow
					p92.Color = ColorSequence.new(v_u_8)
					p92.LightEmission = 0
					p92.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.2 * v_u_91), NumberSequenceKeypoint.new(0.3, 3.4 * v_u_91), NumberSequenceKeypoint.new(1, 3.8 * v_u_91) })
					p92.Transparency = v_u_25(0.6)
					p92.Rotation = NumberRange.new(-25, 25)
				end)
				v_u_46(p_u_60.ground(p90, 0.14), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_11, 1.5 * v_u_91, p89.ability.radius * 2.4 * v_u_91, 0.4, true)
				p_u_60.spikes(p90, v_u_13, p89.lite and 3 or 7, 8 * v_u_91, 0.16, nil, nil, true)
				p_u_60.hitSound(p90)
			end,
			["hit"] = function(_, p93, _) -- name: hit
				-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16
				local v_u_94 = v_u_7.BalaPow
				local v_u_95 = v_u_8
				local v_u_96 = 0
				local v_u_97 = 1.5
				local v_u_98 = 3.5
				local v_u_99 = nil
				local v_u_100 = nil
				v_u_32(CFrame.new(p93), 0.2, 1, function(p101)
					-- upvalues: (copy) v_u_94, (copy) v_u_95, (copy) v_u_96, (ref) v_u_22, (copy) v_u_97, (copy) v_u_98, (ref) v_u_25, (copy) v_u_99, (copy) v_u_100, (ref) v_u_16
					p101.Texture = v_u_94
					p101.Color = ColorSequence.new(v_u_95)
					p101.LightEmission = v_u_96 or 0.4
					p101.Size = v_u_22(v_u_97, v_u_98)
					p101.Transparency = v_u_25()
					p101.Rotation = NumberRange.new(0, 360)
					p101.RotSpeed = NumberRange.new(v_u_99 or 0)
					if v_u_100 then
						p101.FlipbookLayout = v_u_16
						p101.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
			end
		}
	}
	local v_u_103 = {}
	setmetatable(v_u_103, {
		["__mode"] = "k"
	})
	v102.resurreccion_e = {
		["cast"] = function(p104) -- name: cast
			-- upvalues: (copy) p_u_60, (ref) v_u_8
			p_u_60.skillCast(p104, v_u_8, false, true)
		end,
		["windup"] = function(p105, _, p106) -- name: windup
			-- upvalues: (ref) v_u_59, (ref) v_u_17, (ref) v_u_4, (copy) v_u_103, (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) p_u_60
			local v107 = p105.size
			local v108 = p105.eye + Vector3.new(0, 0.6, 0)
			local v109 = v108 + p105.dir * 2 - v108
			local v110 = CFrame.lookAt(v108 + p105.dir * 0.6, v108 + p105.dir * 0.6 + v109)
			local v111 = v_u_59(4.2 * v107)
			if v111 then
				v111.CFrame = v110 * v_u_17
				v111.Transparency = 1
				v_u_4.tween(v111, math.max(p106, 0.06), {
					["Transparency"] = 0
				})
				v_u_103[p105] = v111
			end
			local v_u_112 = v_u_7.Glow
			local v_u_113 = v_u_8
			local v_u_114 = 2 * v107
			local v_u_115 = 7 * v107
			local v116 = p106 + 0.15
			local v_u_117 = 0.5
			local v_u_118 = nil
			local v_u_119 = nil
			v_u_32(CFrame.new(v108), v116, 1, function(p120)
				-- upvalues: (copy) v_u_112, (copy) v_u_113, (copy) v_u_117, (ref) v_u_22, (copy) v_u_114, (copy) v_u_115, (ref) v_u_25, (copy) v_u_118, (copy) v_u_119, (ref) v_u_16
				p120.Texture = v_u_112
				p120.Color = ColorSequence.new(v_u_113)
				p120.LightEmission = v_u_117 or 0.4
				p120.Size = v_u_22(v_u_114, v_u_115)
				p120.Transparency = v_u_25()
				p120.Rotation = NumberRange.new(0, 360)
				p120.RotSpeed = NumberRange.new(v_u_118 or 0)
				if v_u_119 then
					p120.FlipbookLayout = v_u_16
					p120.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_60.inward(v108, v_u_8, p105.lite and 4 or 8, 6 * v107, (math.max(p106, 0.08)))
		end,
		["land"] = function(p121, p122) -- name: land
			-- upvalues: (copy) p_u_60, (copy) v_u_103, (ref) v_u_4, (ref) v_u_1, (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_46, (ref) v_u_11, (ref) v_u_10, (ref) v_u_53, (ref) v_u_9, (ref) v_u_15, (ref) v_u_14, (ref) v_u_6
			local v_u_123 = p121.size
			local v_u_124 = p121.lite
			local v125 = p121.ability.radius * v_u_123
			local v126 = p121.eye + Vector3.new(0, 0.6, 0)
			local v127 = p_u_60.ground(p122, 0.14)
			local v128 = v_u_103[p121]
			if v128 then
				v_u_103[p121] = nil
				v_u_4.tween(v128, 0.14, {
					["Size"] = v128.Size * 1.35
				})
				v_u_4.tween(v128, 0.14, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v128, 0.19)
			end
			local v_u_129 = v_u_7.Glow
			local v_u_130 = v_u_8
			local v_u_131 = 4 * v_u_123
			local v_u_132 = 12 * v_u_123
			local v_u_133 = 0.5
			local v_u_134 = nil
			local v_u_135 = nil
			v_u_32(CFrame.new(v126), 0.25, 1, function(p136)
				-- upvalues: (copy) v_u_129, (copy) v_u_130, (copy) v_u_133, (ref) v_u_22, (copy) v_u_131, (copy) v_u_132, (ref) v_u_25, (copy) v_u_134, (copy) v_u_135, (ref) v_u_16
				p136.Texture = v_u_129
				p136.Color = ColorSequence.new(v_u_130)
				p136.LightEmission = v_u_133 or 0.4
				p136.Size = v_u_22(v_u_131, v_u_132)
				p136.Transparency = v_u_25()
				p136.Rotation = NumberRange.new(0, 360)
				p136.RotSpeed = NumberRange.new(v_u_134 or 0)
				if v_u_135 then
					p136.FlipbookLayout = v_u_16
					p136.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			local v_u_137 = v_u_7.HollowRing
			local v_u_138 = v_u_8
			local v_u_139 = 3 * v_u_123
			local v_u_140 = 14 * v_u_123
			local v_u_141 = 0.3
			local v_u_142 = nil
			local v_u_143 = true
			v_u_32(CFrame.new(v126), 0.4, 1, function(p144)
				-- upvalues: (copy) v_u_137, (copy) v_u_138, (copy) v_u_141, (ref) v_u_22, (copy) v_u_139, (copy) v_u_140, (ref) v_u_25, (copy) v_u_142, (copy) v_u_143, (ref) v_u_16
				p144.Texture = v_u_137
				p144.Color = ColorSequence.new(v_u_138)
				p144.LightEmission = v_u_141 or 0.4
				p144.Size = v_u_22(v_u_139, v_u_140)
				p144.Transparency = v_u_25()
				p144.Rotation = NumberRange.new(0, 360)
				p144.RotSpeed = NumberRange.new(v_u_142 or 0)
				if v_u_143 then
					p144.FlipbookLayout = v_u_16
					p144.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			v_u_46(v127, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_8, 4 * v_u_123, v125 * 2.3, 0.55, true)
			v_u_46(v127 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), v_u_7.Glow, v_u_11, v125 * 0.6, v125 * 2, 0.45)
			local v_u_145 = v_u_10
			local v_u_146 = 4 * v_u_123
			local v_u_147 = 14 * v_u_123
			v_u_32(CFrame.new(v126), 1.1, v_u_124 and 3 or 7, function(p148)
				-- upvalues: (ref) v_u_7, (ref) v_u_16, (copy) v_u_145, (ref) v_u_22, (copy) v_u_146, (copy) v_u_147
				p148.Texture = v_u_7.FxSmoke
				p148.FlipbookLayout = v_u_16
				p148.FlipbookMode = Enum.ParticleFlipbookMode.Random
				p148.Color = ColorSequence.new(v_u_145)
				p148.LightEmission = 0
				p148.Lifetime = NumberRange.new(0.7, 1.1)
				p148.Size = v_u_22(v_u_146 * 0.5, v_u_146, 0.4)
				p148.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
				p148.Speed = NumberRange.new(2, v_u_147)
				p148.SpreadAngle = Vector2.new(70, 70)
				p148.EmissionDirection = Enum.NormalId.Top
				p148.Drag = 3
				p148.Rotation = NumberRange.new(0, 360)
				p148.RotSpeed = NumberRange.new(-60, 60)
			end)
			local v149 = v_u_124 and 7 or 14
			local v150 = math.random() * 3.141592653589793 * 2
			for v_u_151 = 1, v149 do
				local v_u_152 = v150 + v_u_151 * 3.141592653589793 * 2 / v149
				local v153 = math.cos(v_u_152)
				local v154 = math.sin(v_u_152)
				local v_u_155 = Vector3.new(v153, 0, v154)
				local v_u_156 = v127 + v_u_155 * v125 * (0.72 + math.random() * 0.25)
				local v_u_157 = v126 + v_u_155 * 1.2 * v_u_123
				local v158 = (1.4 + math.random() * 0.8) * v_u_123
				local v159 = v_u_53
				local v160 = 0.35 * v158
				local v161 = 0.9 * v158
				local v162 = 1.9 * v158
				local v163 = Vector3.new(v160, v161, v162)
				local v164
				if v_u_151 % 2 == 0 then
					v164 = v_u_9
				else
					v164 = v_u_10
				end
				local v_u_165 = v159(v163, v164, v_u_15, 0, true)
				v_u_1:AddItem(v_u_165, 2.5)
				if not v_u_124 then
					local v166 = Instance.new("Attachment")
					local v167 = 0.3 * v158
					v166.Position = Vector3.new(0, v167, 0)
					v166.Parent = v_u_165
					local v168 = Instance.new("Attachment")
					local v169 = -0.3 * v158
					v168.Position = Vector3.new(0, v169, 0)
					v168.Parent = v_u_165
					local v170 = Instance.new("Trail")
					v170.Attachment0 = v166
					v170.Attachment1 = v168
					v170.Color = ColorSequence.new(v_u_8, v_u_11)
					v170.Transparency = NumberSequence.new(0.1, 1)
					v170.Lifetime = 0.2
					v170.LightEmission = 0.4
					v170.LightInfluence = 0
					v170.FaceCamera = true
					v170.Parent = v_u_165
					local v171 = v_u_53
					local v172 = 0.35 * v_u_123
					local v_u_173 = v171(Vector3.new(v172, 0.08, 0.1), v_u_11, v_u_14, 0.15)
					v_u_1:AddItem(v_u_173, 1.6)
					local v_u_174 = v127 + v_u_155 * 1.5 * v_u_123
					p_u_60.animate(0.28, 0, function(p175)
						-- upvalues: (copy) v_u_174, (copy) v_u_156, (copy) v_u_173, (copy) v_u_123, (copy) v_u_155, (ref) v_u_4
						local v176 = v_u_174:Lerp(v_u_156, p175)
						local v177 = (v_u_174 + v176) / 2
						local v178 = v_u_173
						local v179 = 0.35 * v_u_123
						local v180 = (v176 - v_u_174).Magnitude
						local v181 = math.max(v180, 0.1)
						v178.Size = Vector3.new(v179, 0.08, v181)
						v_u_173.CFrame = CFrame.lookAt(v177, v177 + v_u_155)
						if p175 >= 1 then
							v_u_4.tween(v_u_173, 1.2, {
								["Transparency"] = 1
							})
						end
					end)
				end
				p_u_60.animate(0.28, 0, function(p182)
					-- upvalues: (copy) v_u_157, (copy) v_u_156, (copy) v_u_123, (copy) v_u_165, (copy) v_u_152, (ref) v_u_46, (ref) v_u_7, (ref) v_u_11, (copy) v_u_124, (copy) v_u_151, (ref) v_u_10, (ref) v_u_32, (ref) v_u_16, (ref) v_u_22
					local v183 = v_u_157:Lerp(v_u_156, 1 - (1 - p182) ^ 2)
					local v184 = p182 * 3.141592653589793
					local v185 = v183 + Vector3.new(0, 1, 0) * math.sin(v184) * 2.5 * v_u_123
					local v186 = (v_u_156 - v_u_157).Unit:Lerp(Vector3.new(-0, -1, -0), p182 * 0.7)
					v_u_165.CFrame = CFrame.lookAt(v185, v185 + v186) * CFrame.Angles(0, 0, v_u_152)
					if p182 >= 1 then
						v_u_46(v_u_156 + Vector3.new(0, 0.1, 0), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_11, 1 * v_u_123, 5 * v_u_123, 0.35, true)
						if not v_u_124 and v_u_151 % 2 == 0 then
							local v187 = v_u_156
							local v_u_188 = v_u_10
							local v_u_189 = 2.5 * v_u_123
							local v_u_190 = 6
							v_u_32(CFrame.new(v187), 1.1, 2, function(p191)
								-- upvalues: (ref) v_u_7, (ref) v_u_16, (copy) v_u_188, (ref) v_u_22, (copy) v_u_189, (copy) v_u_190
								p191.Texture = v_u_7.FxSmoke
								p191.FlipbookLayout = v_u_16
								p191.FlipbookMode = Enum.ParticleFlipbookMode.Random
								p191.Color = ColorSequence.new(v_u_188)
								p191.LightEmission = 0
								p191.Lifetime = NumberRange.new(0.7, 1.1)
								p191.Size = v_u_22(v_u_189 * 0.5, v_u_189, 0.4)
								p191.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
								p191.Speed = NumberRange.new(2, v_u_190)
								p191.SpreadAngle = Vector2.new(70, 70)
								p191.EmissionDirection = Enum.NormalId.Top
								p191.Drag = 3
								p191.Rotation = NumberRange.new(0, 360)
								p191.RotSpeed = NumberRange.new(-60, 60)
							end)
						end
					end
				end)
				p_u_60.after(1.03, function()
					-- upvalues: (copy) v_u_165, (copy) v_u_124, (copy) v_u_151, (ref) p_u_60, (ref) v_u_9, (ref) v_u_10, (copy) v_u_123, (ref) v_u_4, (ref) v_u_1
					if v_u_165.Parent then
						if not v_u_124 and v_u_151 % 2 == 1 then
							local v192 = { v_u_9, v_u_10 }
							p_u_60.chunks(v_u_165.Position, v192, 3, 12 * v_u_123, 0.4 * v_u_123, 0.6, false, 0.7)
						end
						local v193 = v_u_165
						v_u_4.tween(v193, 0.2, {
							["Transparency"] = 1
						})
						v_u_1:AddItem(v193, 0.25)
					end
				end)
			end
			v_u_6.play("Explosion", {
				["at"] = v127,
				["volume"] = p121.mine and 0.8 or 0.4
			})
			if p121.mine then
				v_u_4.shake(0.3, 0.3)
			end
		end,
		["hit"] = function(_, p194, _) -- name: hit
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) p_u_60
			local v_u_195 = v_u_7.BalaPow
			local v_u_196 = v_u_8
			local v_u_197 = 0
			local v_u_198 = 2
			local v_u_199 = 4
			local v_u_200 = nil
			local v_u_201 = nil
			v_u_32(CFrame.new(p194), 0.22, 1, function(p202)
				-- upvalues: (copy) v_u_195, (copy) v_u_196, (copy) v_u_197, (ref) v_u_22, (copy) v_u_198, (copy) v_u_199, (ref) v_u_25, (copy) v_u_200, (copy) v_u_201, (ref) v_u_16
				p202.Texture = v_u_195
				p202.Color = ColorSequence.new(v_u_196)
				p202.LightEmission = v_u_197 or 0.4
				p202.Size = v_u_22(v_u_198, v_u_199)
				p202.Transparency = v_u_25()
				p202.Rotation = NumberRange.new(0, 360)
				p202.RotSpeed = NumberRange.new(v_u_200 or 0)
				if v_u_201 then
					p202.FlipbookLayout = v_u_16
					p202.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_60.burst("Impact", p194, v_u_8, 0.7)
		end
	}
	local v_u_203 = {}
	setmetatable(v_u_203, {
		["__mode"] = "k"
	})
	local function v_u_215(p204, p205, p206) -- name: poseHead
		-- upvalues: (ref) v_u_3
		local v207 = {}
		local v208 = {}
		for v209, v210 in p204.skull do
			table.insert(v207, v210)
			local v211 = p204.frame * CFrame.new(0, p205, 0) * p204.skullOffs[v209]
			table.insert(v208, v211)
		end
		for v212, v213 in p204.jaw do
			table.insert(v207, v213)
			local v214 = p204.frame * CFrame.new(0, p206, 0) * p204.jawOffs[v212]
			table.insert(v208, v214)
		end
		v_u_3:BulkMoveTo(v207, v208, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local function v_u_280(p216, p217) -- name: newHead
		-- upvalues: (copy) p_u_60, (ref) v_u_59, (ref) v_u_9, (ref) v_u_11, (ref) v_u_17, (ref) v_u_53, (ref) v_u_12, (ref) v_u_15, (ref) v_u_10, (ref) v_u_1
		local v218 = p216.size
		local v219 = p216.lite
		local v220 = p216.ability.radius * v218 * 0.8
		local v221 = p_u_60.ground(p217, 0)
		local v222 = -p216.dir
		local v223 = CFrame.lookAt(v221, v221 + v222)
		local v224 = {}
		local v225 = {}
		local v226 = v_u_59(v220)
		if v226 then
			if not v219 then
				local v227 = Instance.new("Highlight")
				v227.FillColor = v_u_9
				v227.FillTransparency = 0.55
				v227.OutlineColor = v_u_11
				v227.OutlineTransparency = 0
				v227.DepthMode = Enum.HighlightDepthMode.Occluded
				v227.Parent = v226
			end
			table.insert(v224, v226)
			local v228 = v_u_17
			table.insert(v225, v228)
		else
			local v229 = v_u_53
			local v230 = v220 * 0.95
			local v231 = v220 * 0.7
			local v232 = v220 * 0.8
			local v233 = v229(Vector3.new(v230, v231, v232), v_u_9)
			table.insert(v224, v233)
			local v234 = CFrame.new
			local v235 = v220 * 0.1
			table.insert(v225, v234(0, v235, 0))
			for _, v236 in { -1, 1 } do
				local v237 = v_u_53
				local v238 = v220 * 0.22
				local v239 = v220 * 0.18
				local v240 = v237(Vector3.new(v238, v239, 0.4), v_u_12)
				table.insert(v224, v240)
				local v241 = CFrame.new
				local v242 = v236 * v220 * 0.22
				local v243 = v220 * 0.12
				local v244 = -v220 * 0.4
				table.insert(v225, v241(v242, v243, v244))
			end
		end
		local v245 = v219 and 3 or 6
		for v246 = 1, v245 do
			local v247 = (v246 - (v245 + 1) / 2) * v220 * 0.14
			local v248 = v_u_53
			local v249 = v220 * 0.1
			local v250 = v220 * 0.3
			local v251 = v220 * 0.13
			local v252 = v248(Vector3.new(v249, v250, v251), v_u_9, v_u_15, 0, true)
			table.insert(v224, v252)
			local v253 = CFrame.new(v247, -v220 * 0.42, -v220 * 0.3) * CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.Angles(0, 0, 3.141592653589793)
			table.insert(v225, v253)
		end
		local v254 = {}
		local v255 = {}
		local v256 = v220 * 0.8
		local v257 = v220 * 0.18
		local v258 = v220 * 0.2
		local v259 = Vector3.new(v256, v257, v258)
		local v260 = CFrame.new(0, 0, -v220 * 0.32)
		local v261 = v_u_53(v259, v_u_10, v_u_15, 0, nil)
		table.insert(v254, v261)
		table.insert(v255, v260)
		for _, v262 in { -1, 1 } do
			local v263 = v220 * 0.18
			local v264 = v220 * 0.18
			local v265 = v220 * 0.7
			local v266 = Vector3.new(v263, v264, v265)
			local v267 = CFrame.new(v262 * v220 * 0.36, 0, 0)
			local v268 = v_u_53(v266, v_u_10, v_u_15, 0, nil)
			table.insert(v254, v268)
			table.insert(v255, v267)
		end
		for v269 = 1, v245 do
			local v270 = (v269 - (v245 + 1) / 2) * v220 * 0.14
			local v271 = v220 * 0.1
			local v272 = v220 * 0.26
			local v273 = v220 * 0.13
			local v274 = Vector3.new(v271, v272, v273)
			local v275 = CFrame.new(v270, v220 * 0.2, -v220 * 0.32) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v276 = v_u_53(v274, v_u_9, v_u_15, 0, true)
			table.insert(v254, v276)
			table.insert(v255, v275)
		end
		local v277 = { (v223 * CFrame.new(-v220 * 0.22, v220 * 0.12, -v220 * 0.42)).Position, (v223 * CFrame.new(v220 * 0.22, v220 * 0.12, -v220 * 0.42)).Position }
		for _, v278 in v224 do
			v_u_1:AddItem(v278, 4)
		end
		for _, v279 in v254 do
			v_u_1:AddItem(v279, 4)
		end
		return {
			["skull"] = v224,
			["skullOffs"] = v225,
			["jaw"] = v254,
			["jawOffs"] = v255,
			["frame"] = v223,
			["big"] = v220,
			["eyes"] = v277
		}
	end
	v102.resurreccion_r = {
		["cast"] = function(p281) -- name: cast
			-- upvalues: (copy) p_u_60, (ref) v_u_8, (ref) v_u_4
			p_u_60.skillCast(p281, v_u_8, true, true)
			if p281.mine then
				v_u_4.shake(0.12, 0.15)
			end
		end,
		["windup"] = function(p282, p283, p284) -- name: windup
			-- upvalues: (copy) v_u_280, (copy) v_u_203, (copy) p_u_60, (ref) v_u_46, (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) v_u_215, (ref) v_u_10
			local v285 = p282.size
			local v286 = p282.ability.radius * v285
			local v_u_287 = v_u_280(p282, p283)
			v_u_203[p282] = v_u_287
			local v288 = p_u_60.ground(p283, 0.12)
			local v289 = math.max(p284, 0.12)
			v_u_46(v288, Vector3.new(0, 1, 0), v_u_7.Glow, v_u_11, v286 * 0.6, v286 * 2.2, v289 + 0.5, false, 0.1)
			v_u_46(v288 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_8, v286 * 2.4, v286 * 1.6, v289, true)
			for _, v290 in v_u_287.skull do
				v290.Transparency = 1
				v_u_4.tween(v290, v289, {
					["Transparency"] = 0
				})
			end
			local v291 = v288 + Vector3.new(0, 1, 0) * v_u_287.big * 1.6
			local v_u_292 = v_u_7.Glow
			local v_u_293 = v_u_8
			local v_u_294 = v_u_287.big * 0.6
			local v_u_295 = v_u_287.big * 2.2
			local v296 = v289 + 0.2
			local v_u_297 = 0.4
			local v_u_298 = nil
			local v_u_299 = nil
			v_u_32(CFrame.new(v291), v296, 1, function(p300)
				-- upvalues: (copy) v_u_292, (copy) v_u_293, (copy) v_u_297, (ref) v_u_22, (copy) v_u_294, (copy) v_u_295, (ref) v_u_25, (copy) v_u_298, (copy) v_u_299, (ref) v_u_16
				p300.Texture = v_u_292
				p300.Color = ColorSequence.new(v_u_293)
				p300.LightEmission = v_u_297 or 0.4
				p300.Size = v_u_22(v_u_294, v_u_295)
				p300.Transparency = v_u_25()
				p300.Rotation = NumberRange.new(0, 360)
				p300.RotSpeed = NumberRange.new(v_u_298 or 0)
				if v_u_299 then
					p300.FlipbookLayout = v_u_16
					p300.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_60.animate(v289, 0, function(p301)
				-- upvalues: (ref) v_u_215, (copy) v_u_287
				local v302 = math.clamp(p301, 0, 1)
				local v303 = v302 * v302 * (3 - v302 * 2)
				v_u_215(v_u_287, v_u_287.big * (1.25 - v303 * 0.2), -v_u_287.big * 0.45 + v_u_287.big * 0.25 * v303)
			end)
			if not p282.lite then
				local v_u_304 = v_u_10
				local v_u_305 = 4 * v285
				local v_u_306 = 8
				v_u_32(CFrame.new(v288), 1.1, 5, function(p307)
					-- upvalues: (ref) v_u_7, (ref) v_u_16, (copy) v_u_304, (ref) v_u_22, (copy) v_u_305, (copy) v_u_306
					p307.Texture = v_u_7.FxSmoke
					p307.FlipbookLayout = v_u_16
					p307.FlipbookMode = Enum.ParticleFlipbookMode.Random
					p307.Color = ColorSequence.new(v_u_304)
					p307.LightEmission = 0
					p307.Lifetime = NumberRange.new(0.7, 1.1)
					p307.Size = v_u_22(v_u_305 * 0.5, v_u_305, 0.4)
					p307.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
					p307.Speed = NumberRange.new(2, v_u_306)
					p307.SpreadAngle = Vector2.new(70, 70)
					p307.EmissionDirection = Enum.NormalId.Top
					p307.Drag = 3
					p307.Rotation = NumberRange.new(0, 360)
					p307.RotSpeed = NumberRange.new(-60, 60)
				end)
			end
		end,
		["land"] = function(p_u_308, p309) -- name: land
			-- upvalues: (copy) v_u_203, (copy) v_u_280, (copy) p_u_60, (copy) v_u_215, (ref) v_u_46, (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_13, (ref) v_u_10, (ref) v_u_6, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (ref) v_u_1
			local v_u_310 = p_u_308.size
			local v_u_311 = p_u_308.lite
			local v_u_312 = p_u_308.ability.radius * v_u_310
			local v_u_313 = v_u_203[p_u_308] or v_u_280(p_u_308, p309)
			v_u_203[p_u_308] = nil
			local v_u_314 = p_u_60.ground(p309, 0.14)
			p_u_60.animate(0.11, 0, function(p315)
				-- upvalues: (ref) v_u_215, (copy) v_u_313, (ref) v_u_46, (copy) v_u_314, (ref) v_u_7, (ref) v_u_8, (copy) v_u_310, (copy) v_u_312, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_13, (ref) p_u_60, (copy) v_u_311, (ref) v_u_10, (ref) v_u_6, (copy) p_u_308, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (ref) v_u_1
				local v316 = p315 * p315
				v_u_215(v_u_313, v_u_313.big * (1.05 - 0.5 * v316), -v_u_313.big * 0.2 + v_u_313.big * 0.3 * v316)
				if p315 >= 1 then
					v_u_46(v_u_314, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_8, 4 * v_u_310, v_u_312 * 2.5, 0.6, true)
					v_u_46(v_u_314 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), v_u_7.Glow, v_u_8, v_u_312, v_u_312 * 2.4, 0.4, false, 0.3)
					local v317 = v_u_314 + Vector3.new(0, 1, 0) * v_u_313.big * 0.5
					local v_u_318 = v_u_7.HollowRing
					local v_u_319 = v_u_8
					local v_u_320 = v_u_313.big * 0.6
					local v_u_321 = v_u_313.big * 2.6
					local v_u_322 = 0.3
					local v_u_323 = nil
					local v_u_324 = true
					v_u_32(CFrame.new(v317), 0.45, 1, function(p325)
						-- upvalues: (copy) v_u_318, (copy) v_u_319, (copy) v_u_322, (ref) v_u_22, (copy) v_u_320, (copy) v_u_321, (ref) v_u_25, (copy) v_u_323, (copy) v_u_324, (ref) v_u_16
						p325.Texture = v_u_318
						p325.Color = ColorSequence.new(v_u_319)
						p325.LightEmission = v_u_322 or 0.4
						p325.Size = v_u_22(v_u_320, v_u_321)
						p325.Transparency = v_u_25()
						p325.Rotation = NumberRange.new(0, 360)
						p325.RotSpeed = NumberRange.new(v_u_323 or 0)
						if v_u_324 then
							p325.FlipbookLayout = v_u_16
							p325.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
						end
					end)
					local v326 = v_u_314 + Vector3.new(0, 1, 0) * v_u_313.big * 0.5
					local v_u_327 = v_u_7.Glow
					local v_u_328 = v_u_13
					local v_u_329 = v_u_313.big * 0.5
					local v_u_330 = v_u_313.big * 1.6
					local v_u_331 = 0.5
					local v_u_332 = nil
					local v_u_333 = nil
					v_u_32(CFrame.new(v326), 0.18, 1, function(p334)
						-- upvalues: (copy) v_u_327, (copy) v_u_328, (copy) v_u_331, (ref) v_u_22, (copy) v_u_329, (copy) v_u_330, (ref) v_u_25, (copy) v_u_332, (copy) v_u_333, (ref) v_u_16
						p334.Texture = v_u_327
						p334.Color = ColorSequence.new(v_u_328)
						p334.LightEmission = v_u_331 or 0.4
						p334.Size = v_u_22(v_u_329, v_u_330)
						p334.Transparency = v_u_25()
						p334.Rotation = NumberRange.new(0, 360)
						p334.RotSpeed = NumberRange.new(v_u_332 or 0)
						if v_u_333 then
							p334.FlipbookLayout = v_u_16
							p334.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
						end
					end)
					p_u_60.spikes(v_u_314 + Vector3.new(0, 2, 0), v_u_8, v_u_311 and 5 or 12, 18 * v_u_310, 0.3, nil, nil, true)
					local v335 = v_u_314 + Vector3.new(0, 1, 0)
					local v_u_336 = v_u_10
					local v337 = v_u_311 and 4 or 10
					local v_u_338 = 6 * v_u_310
					local v_u_339 = 16 * v_u_310
					v_u_32(CFrame.new(v335), 1.1, v337, function(p340)
						-- upvalues: (ref) v_u_7, (ref) v_u_16, (copy) v_u_336, (ref) v_u_22, (copy) v_u_338, (copy) v_u_339
						p340.Texture = v_u_7.FxSmoke
						p340.FlipbookLayout = v_u_16
						p340.FlipbookMode = Enum.ParticleFlipbookMode.Random
						p340.Color = ColorSequence.new(v_u_336)
						p340.LightEmission = 0
						p340.Lifetime = NumberRange.new(0.7, 1.1)
						p340.Size = v_u_22(v_u_338 * 0.5, v_u_338, 0.4)
						p340.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
						p340.Speed = NumberRange.new(2, v_u_339)
						p340.SpreadAngle = Vector2.new(70, 70)
						p340.EmissionDirection = Enum.NormalId.Top
						p340.Drag = 3
						p340.Rotation = NumberRange.new(0, 360)
						p340.RotSpeed = NumberRange.new(-60, 60)
					end)
					v_u_6.play("Explosion", {
						["at"] = v_u_314,
						["volume"] = p_u_308.mine and 1 or 0.5
					})
					if p_u_308.mine then
						v_u_4.shake(0.45, 0.4)
					end
					for _, v341 in v_u_313.eyes do
						local v342 = v341 + Vector3.new(0, 1, 0) * v_u_313.big * 0.55
						local v_u_343 = v_u_7.Glow
						local v_u_344 = v_u_8
						local v_u_345 = v_u_313.big * 0.15
						local v_u_346 = v_u_313.big * 0.5
						local v_u_347 = 0.6
						local v_u_348 = nil
						local v_u_349 = nil
						v_u_32(CFrame.new(v342), 0.6, 1, function(p350)
							-- upvalues: (copy) v_u_343, (copy) v_u_344, (copy) v_u_347, (ref) v_u_22, (copy) v_u_345, (copy) v_u_346, (ref) v_u_25, (copy) v_u_348, (copy) v_u_349, (ref) v_u_16
							p350.Texture = v_u_343
							p350.Color = ColorSequence.new(v_u_344)
							p350.LightEmission = v_u_347 or 0.4
							p350.Size = v_u_22(v_u_345, v_u_346)
							p350.Transparency = v_u_25()
							p350.Rotation = NumberRange.new(0, 360)
							p350.RotSpeed = NumberRange.new(v_u_348 or 0)
							if v_u_349 then
								p350.FlipbookLayout = v_u_16
								p350.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						if v_u_311 then
							continue
						end
						local v_u_351 = v_u_7.FxTwinkle
						local v_u_352 = v_u_8
						local v_u_353 = v_u_313.big * 0.2
						local v_u_354 = v_u_313.big * 0.5
						local v_u_355 = 0.6
						local v_u_356 = nil
						local v_u_357 = true
						v_u_32(CFrame.new(v342), 0.5, 1, function(p358)
							-- upvalues: (copy) v_u_351, (copy) v_u_352, (copy) v_u_355, (ref) v_u_22, (copy) v_u_353, (copy) v_u_354, (ref) v_u_25, (copy) v_u_356, (copy) v_u_357, (ref) v_u_16
							p358.Texture = v_u_351
							p358.Color = ColorSequence.new(v_u_352)
							p358.LightEmission = v_u_355 or 0.4
							p358.Size = v_u_22(v_u_353, v_u_354)
							p358.Transparency = v_u_25()
							p358.Rotation = NumberRange.new(0, 360)
							p358.RotSpeed = NumberRange.new(v_u_356 or 0)
							if v_u_357 then
								p358.FlipbookLayout = v_u_16
								p358.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
					end
					p_u_60.after(0.45, function()
						-- upvalues: (ref) v_u_313, (ref) v_u_311, (ref) p_u_60, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_310, (ref) v_u_4, (ref) v_u_1, (ref) v_u_314, (ref) v_u_8, (ref) v_u_32, (ref) v_u_7, (ref) v_u_16, (ref) v_u_22, (ref) v_u_25, (ref) v_u_6, (ref) p_u_308
						for v359, v360 in v_u_313.skull do
							if not v360.Parent then
								continue
							end
							if not v_u_311 and v359 <= 2 then
								local v361 = { v_u_9, v_u_10, v_u_12 }
								p_u_60.chunks(v360.Position, v361, 8, 24 * v_u_310, 0.8 * v_u_310, 0.8, false, 0.6)
							end
							v_u_4.tween(v360, 0.3, {
								["Transparency"] = 1
							})
							v_u_1:AddItem(v360, 0.35)
						end
						for v362, v363 in v_u_313.jaw do
							if not v363.Parent then
								continue
							end
							if not v_u_311 and v362 % 3 == 0 then
								local v364 = { v_u_9, v_u_10 }
								p_u_60.chunks(v363.Position, v364, 2, 14 * v_u_310, 0.6 * v_u_310, 0.6, false, 0.6)
							end
							v_u_4.tween(v363, 0.3, {
								["Transparency"] = 1
							})
							v_u_1:AddItem(v363, 0.35)
						end
						local v365 = v_u_314 + Vector3.new(0, 1, 0) * v_u_313.big * 0.6
						local v_u_366 = v_u_8
						local v367 = v_u_311 and 3 or 8
						local v_u_368 = 5 * v_u_310
						local v_u_369 = 10 * v_u_310
						v_u_32(CFrame.new(v365), 1.1, v367, function(p370)
							-- upvalues: (ref) v_u_7, (ref) v_u_16, (copy) v_u_366, (ref) v_u_22, (copy) v_u_368, (copy) v_u_369
							p370.Texture = v_u_7.FxSmoke
							p370.FlipbookLayout = v_u_16
							p370.FlipbookMode = Enum.ParticleFlipbookMode.Random
							p370.Color = ColorSequence.new(v_u_366)
							p370.LightEmission = 0
							p370.Lifetime = NumberRange.new(0.7, 1.1)
							p370.Size = v_u_22(v_u_368 * 0.5, v_u_368, 0.4)
							p370.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
							p370.Speed = NumberRange.new(2, v_u_369)
							p370.SpreadAngle = Vector2.new(70, 70)
							p370.EmissionDirection = Enum.NormalId.Top
							p370.Drag = 3
							p370.Rotation = NumberRange.new(0, 360)
							p370.RotSpeed = NumberRange.new(-60, 60)
						end)
						local v371 = v_u_314 + Vector3.new(0, 1, 0) * v_u_313.big * 0.6
						local v_u_372 = v_u_7.HollowRing
						local v_u_373 = v_u_8
						local v_u_374 = v_u_313.big
						local v_u_375 = v_u_313.big * 2.2
						local v_u_376 = 0.3
						local v_u_377 = nil
						local v_u_378 = true
						v_u_32(CFrame.new(v371), 0.4, 1, function(p379)
							-- upvalues: (copy) v_u_372, (copy) v_u_373, (copy) v_u_376, (ref) v_u_22, (copy) v_u_374, (copy) v_u_375, (ref) v_u_25, (copy) v_u_377, (copy) v_u_378, (ref) v_u_16
							p379.Texture = v_u_372
							p379.Color = ColorSequence.new(v_u_373)
							p379.LightEmission = v_u_376 or 0.4
							p379.Size = v_u_22(v_u_374, v_u_375)
							p379.Transparency = v_u_25()
							p379.Rotation = NumberRange.new(0, 360)
							p379.RotSpeed = NumberRange.new(v_u_377 or 0)
							if v_u_378 then
								p379.FlipbookLayout = v_u_16
								p379.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						v_u_6.play("Hit", {
							["at"] = v_u_314,
							["volume"] = p_u_308.mine and 0.6 or 0.3
						})
					end)
				end
			end)
		end,
		["hit"] = function(_, p380, _) -- name: hit
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) p_u_60
			local v_u_381 = v_u_7.BalaPow
			local v_u_382 = v_u_8
			local v_u_383 = 0
			local v_u_384 = 2
			local v_u_385 = 5
			local v_u_386 = nil
			local v_u_387 = nil
			v_u_32(CFrame.new(p380), 0.25, 1, function(p388)
				-- upvalues: (copy) v_u_381, (copy) v_u_382, (copy) v_u_383, (ref) v_u_22, (copy) v_u_384, (copy) v_u_385, (ref) v_u_25, (copy) v_u_386, (copy) v_u_387, (ref) v_u_16
				p388.Texture = v_u_381
				p388.Color = ColorSequence.new(v_u_382)
				p388.LightEmission = v_u_383 or 0.4
				p388.Size = v_u_22(v_u_384, v_u_385)
				p388.Transparency = v_u_25()
				p388.Rotation = NumberRange.new(0, 360)
				p388.RotSpeed = NumberRange.new(v_u_386 or 0)
				if v_u_387 then
					p388.FlipbookLayout = v_u_16
					p388.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_60.burst("Impact", p380, v_u_8, 0.9)
		end
	}
	return v102
end