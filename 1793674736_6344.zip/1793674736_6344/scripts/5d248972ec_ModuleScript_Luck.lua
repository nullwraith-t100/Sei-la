require(script.Parent.Parent.Config.Products)
local v_u_52 = {
	["LUCKY"] = { "Mythic", "Legendary" },
	["EGG_SHARE"] = 0.5,
	["MAX"] = {
		["Mythic"] = 4
	},
	["tier"] = function(p1, p2) -- name: tier
		local v3 = 1
		for _, v4 in p1 do
			local v5 = v4.mult or 1
			if v3 >= v5 or not p2(v4.key) then
				continue
			end
			v3 = v5
		end
		return v3
	end,
	["next"] = function(p6, p7) -- name: next
		-- upvalues: (copy) v_u_52
		local v8 = v_u_52.tier(p6, p7)
		local v9 = nil
		for _, v10 in p6 do
			local v11 = v10.mult or 1
			if v8 >= v11 or v9 ~= nil and v11 >= (v9.mult or 1) then
				continue
			end
			v9 = v10
		end
		return v9
	end,
	["chances"] = function(p12, p13, p14) -- name: chances
		-- upvalues: (copy) v_u_52
		local v15 = 0
		for _, v16 in p12 do
			local v17 = v16.weight
			v15 = v15 + math.max(v17, 0)
		end
		local v18 = {}
		for v19, v20 in p12 do
			local v21
			if v15 > 0 then
				local v22 = v20.weight
				v21 = math.max(v22, 0) / v15
			else
				v21 = 0
			end
			v18[v19] = v21
		end
		local v23 = math.max(p14 or 1, 1)
		if v23 <= 1 or v15 <= 0 then
			return v18
		end
		local v24 = {}
		local v25 = 0
		for v26, v27 in p12 do
			local v28 = p13(v27.pet)
			if not table.find(v_u_52.LUCKY, v28) then
				continue
			end
			v24[v28] = (v24[v28] or 0) + v18[v26]
			v25 = v25 + v18[v26]
		end
		if v25 <= 0 or v25 >= 1 then
			return v18
		end
		local v29 = v_u_52.EGG_SHARE
		local v30 = math.max(v29, v25)
		local v31 = 0
		local v32 = {}
		for v33, v34 in v_u_52.LUCKY do
			local v35 = v24[v34]
			if not v35 or v35 <= 0 then
				continue
			end
			local v36 = 0
			for v37 = v33 + 1, #v_u_52.LUCKY do
				v36 = v36 + (v24[v_u_52.LUCKY[v37]] or 0)
			end
			local v38 = v_u_52.MAX[v34] or v23
			local v39 = v35 * math.min(v23, v38)
			local v40 = v30 - v31 - v36
			local v41 = math.min(v39, v40)
			v32[v34] = math.max(v41, v35)
			v31 = v31 + v32[v34]
		end
		local v42 = (1 - v31) / (1 - v25)
		local v43 = {}
		for v44, v45 in p12 do
			local v46 = p13(v45.pet)
			local v47 = v24[v46]
			if v47 and (v47 > 0 and v32[v46]) then
				v43[v44] = v18[v44] * v32[v46] / v47
			else
				v43[v44] = v18[v44] * v42
			end
		end
		return v43
	end,
	["percent"] = function(p48) -- name: percent
		local v49 = p48 * 100
		if v49 < 1 then
			return string.format("%.1f%%", v49)
		end
		local v50 = string.format
		local v51 = v49 + 0.5
		return v50("%d%%", (math.floor(v51)))
	end
}
return v_u_52