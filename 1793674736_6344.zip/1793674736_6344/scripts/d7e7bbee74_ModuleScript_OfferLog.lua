local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Net)
local v3 = {}
local v_u_4 = nil
function v3.shown(p_u_5, p_u_6, p_u_7, p_u_8) -- name: shown
	-- upvalues: (ref) v_u_4, (copy) v_u_2
	local v_u_9 = "shown"
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_2, (copy) v_u_9, (copy) p_u_5, (copy) p_u_6, (copy) p_u_7, (copy) p_u_8
		local v10 = v_u_4 or v_u_2.event("OfferLog")
		v_u_4 = v10
		v10:FireServer(v_u_9, p_u_5, p_u_6, p_u_7, p_u_8)
	end)
end
function v3.click(p_u_11, p_u_12, p_u_13, p_u_14) -- name: click
	-- upvalues: (ref) v_u_4, (copy) v_u_2
	local v_u_15 = "click"
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_2, (copy) v_u_15, (copy) p_u_11, (copy) p_u_12, (copy) p_u_13, (copy) p_u_14
		local v16 = v_u_4 or v_u_2.event("OfferLog")
		v_u_4 = v16
		v16:FireServer(v_u_15, p_u_11, p_u_12, p_u_13, p_u_14)
	end)
end
return v3