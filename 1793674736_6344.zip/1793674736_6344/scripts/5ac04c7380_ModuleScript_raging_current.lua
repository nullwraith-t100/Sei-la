local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.CurrentFang,
	v_u_7.CurrentSlash,
	v_u_7.CurrentRing,
	v_u_7.CurrentStream
})
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("2E8BFF")
local v_u_10 = Color3.fromHex("E8F6FF")
local v_u_11 = Color3.fromRGB(110, 205, 255)
local v_u_12 = Color3.fromRGB(16, 64, 178)
local v_u_13 = Color3.fromRGB(6, 12, 30)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.Material.SmoothPlastic
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_28(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_4
	local v22 = v_u_4.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: setAlpha
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_45(p33, p34, p35, p36) -- name: turnedTo
	local v37 = CFrame.lookAt
	local v38 = p33 + p34
	local v39 = p34.Y
	local v40 = v37(p33, v38, math.abs(v39) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v41 = p35 - p34 * p35:Dot(p34)
	local v42 = v41:Dot(v40.LookVector)
	local v43 = v41:Dot(v40.RightVector)
	local v44 = math.atan2(v42, v43)
	return v40 * CFrame.Angles(0, v44 + p36, 0)
end
local v_u_46 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
local function v_u_51(p47, p48) -- name: emitter
	-- upvalues: (copy) v_u_46
	local v49 = Instance.new("ParticleEmitter")
	v49.Texture = p48.texture
	local v50 = p48.grid
	if v50 then
		v49.FlipbookLayout = v50
		v49.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v49.Color = p48.color
	v49.Size = p48.size
	v49.Transparency = p48.alpha or v_u_46
	v49.Lifetime = p48.life
	v49.Speed = p48.speed
	v49.SpreadAngle = p48.spread or Vector2.new(180, 180)
	v49.EmissionDirection = Enum.NormalId.Top
	v49.LightEmission = p48.light or 0
	v49.LightInfluence = 0
	v49.Acceleration = p48.accel or Vector3.new(0, 0, 0)
	v49.Drag = p48.drag or 0
	v49.Rotation = p48.rot or NumberRange.new(0, 360)
	v49.RotSpeed = p48.spin or NumberRange.new(0)
	v49.Rate = p48.rate or 0
	v49.ZOffset = p48.z or 0
	if p48.flat then
		v49.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v49.SpreadAngle = Vector2.zero
	end
	if p48.box then
		v49.Shape = Enum.ParticleEmitterShape.Box
		v49.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	end
	v49.Parent = p47
	return v49
end
local function v_u_58(p52, p53, p54, p55) -- name: slashAt
	-- upvalues: (copy) v_u_7, (copy) v_u_16, (copy) v_u_3, (copy) v_u_51, (copy) v_u_1
	local v56 = {
		["texture"] = nil,
		["grid"] = nil,
		["color"] = nil,
		["size"] = nil,
		["alpha"] = nil,
		["life"] = nil,
		["speed"] = nil,
		["light"] = 0.25,
		["z"] = 1,
		["texture"] = v_u_7.CurrentSlash,
		["grid"] = v_u_16,
		["color"] = ColorSequence.new(p54),
		["size"] = NumberSequence.new(p53),
		["alpha"] = NumberSequence.new(0),
		["life"] = NumberRange.new(0.38, 0.45),
		["speed"] = NumberRange.new(0.5, 2)
	}
	local v57 = Instance.new("Attachment")
	v57.Parent = v_u_3.Terrain
	v57.WorldPosition = p52
	v_u_51(v57, v56):Emit(p55 or 1)
	v_u_1:AddItem(v57, v56.life.Max + 0.3)
end
local function v_u_66(p59, p60, p61, p62) -- name: splashRing
	-- upvalues: (copy) v_u_7, (copy) v_u_16, (copy) v_u_3, (copy) v_u_51, (copy) v_u_1
	local v63 = p59 + Vector3.new(0, 0.25, 0)
	local v64 = {
		["texture"] = nil,
		["grid"] = nil,
		["color"] = nil,
		["size"] = nil,
		["alpha"] = nil,
		["life"] = nil,
		["speed"] = nil,
		["light"] = 0.2,
		["flat"] = true,
		["texture"] = v_u_7.CurrentRing,
		["grid"] = v_u_16,
		["color"] = ColorSequence.new(p61),
		["size"] = NumberSequence.new(p60),
		["alpha"] = NumberSequence.new(0),
		["life"] = NumberRange.new(p62 or 0.5),
		["speed"] = NumberRange.new(0.02)
	}
	local v65 = Instance.new("Attachment")
	v65.Parent = v_u_3.Terrain
	v65.WorldPosition = v63
	v_u_51(v65, v64):Emit(1)
	v_u_1:AddItem(v65, v64.life.Max + 0.3)
end
local function v_u_73(p67, p68, p69, p70) -- name: drops
	-- upvalues: (copy) v_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_3, (copy) v_u_51, (copy) v_u_1
	local v71 = {
		["texture"] = nil,
		["color"] = nil,
		["size"] = nil,
		["life"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["accel"] = Vector3.new(0, -70, 0),
		["light"] = 0.35,
		["texture"] = v_u_7.Glow,
		["color"] = ColorSequence.new(v_u_10, v_u_11),
		["size"] = NumberSequence.new(p70, p70 * 0.4),
		["life"] = NumberRange.new(0.6, 1.1),
		["speed"] = NumberRange.new(p69 * 0.5, p69),
		["spread"] = Vector2.new(55, 55)
	}
	local v72 = Instance.new("Attachment")
	v72.Parent = v_u_3.Terrain
	v72.WorldPosition = p67
	v_u_51(v72, v71):Emit(p68)
	v_u_1:AddItem(v72, v71.life.Max + 0.3)
end
local function v_u_82(p74, p75, p76, p77, p78) -- name: stream
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v79 = Instance.new("Attachment")
	v79.Parent = p74
	v79.WorldPosition = p75
	local v80 = Instance.new("Attachment")
	v80.Parent = p74
	v80.WorldPosition = p76
	local v81 = Instance.new("Beam")
	v81.Attachment0 = v79
	v81.Attachment1 = v80
	v81.Texture = v_u_7.CurrentStream
	v81.TextureMode = Enum.TextureMode.Wrap
	v81.TextureLength = p77 * 1.6
	v81.TextureSpeed = p78
	v81.Color = ColorSequence.new(v_u_8)
	v81.LightEmission = 0.1
	v81.LightInfluence = 0
	v81.FaceCamera = true
	v81.Width0 = p77
	v81.Width1 = p77 * 0.85
	v81.Segments = 1
	v81.Transparency = NumberSequence.new(0)
	v81.Parent = p74
	return {
		["beam"] = v81,
		["a0"] = v79,
		["a1"] = v80
	}
end
local function v_u_90(p83) -- name: serpent
	-- upvalues: (copy) v_u_2, (copy) v_u_9, (copy) v_u_4
	local v84 = v_u_2:FindFirstChild("EyePieces")
	if v84 then
		v84 = v84:FindFirstChild("w6_raging_current")
	end
	if not (v84 and v84:IsA("MeshPart")) then
		return nil
	end
	local v85 = v84:Clone()
	v85.Anchored = true
	v85.CanCollide = false
	v85.CanQuery = false
	v85.CanTouch = false
	v85.CastShadow = false
	v85.Massless = true
	local v86 = v84.Size.X
	local v87 = v84.Size.Y
	local v88 = v84.Size.Z
	local v89 = math.max(v86, v87, v88, 0.01)
	v85.Size = v84.Size * (p83 / v89)
	if not v85:FindFirstChildWhichIsA("SurfaceAppearance") then
		v85.Color = v_u_9
	end
	v85.Parent = v_u_4.folder()
	return v85
end
return function(p_u_91)
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_1, (copy) v_u_28, (copy) v_u_7, (copy) v_u_10, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_11, (copy) v_u_12, (copy) v_u_51, (copy) v_u_3, (copy) v_u_58, (copy) v_u_8, (copy) v_u_66, (copy) v_u_73, (copy) v_u_32, (copy) v_u_82, (copy) v_u_16, (copy) v_u_6, (copy) v_u_45, (copy) v_u_90
	local v123 = {
		["raging_current_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["weave"] = 0.4,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p92) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_91, (ref) v_u_8, (ref) v_u_58, (ref) v_u_10
				local v93 = p92.size
				local v94 = p92.eye + p92.dir * 1.2
				v_u_4.flash(v94, v_u_9, 3 * v93, 0.12)
				p_u_91.pop(v94, v_u_8, 1.1 * v93, 0.3 * v93, 0.1)
				if not p92.lite then
					v_u_58(v94, 2.2 * v93, v_u_10)
				end
			end,
			["shot"] = function(p95, p96) -- name: fangShot
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_28, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_11, (copy) p_u_91, (ref) v_u_12, (ref) v_u_51, (ref) v_u_3
				local v97 = p95.size
				local v_u_98 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p96, v_u_9, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_98, 3)
				local v_u_99 = v_u_28(p96, 1.8 * v97, v_u_7.CurrentFang, v_u_9, 0)
				local v_u_100 = v_u_28(p96, 1.35 * v97, v_u_7.CurrentFang, v_u_10, 0)
				local v101 = {
					["shape"] = v_u_14,
					["material"] = v_u_15
				}
				local v_u_102 = v_u_4.part(Vector3.new(0.6, 0.6, 0.6) * v97, p96, v_u_13, v101)
				local v_u_103 = { v_u_99, v_u_100, v_u_102 }
				local v_u_104
				if p95.lite then
					v_u_104 = nil
				else
					local v105 = {
						["shape"] = nil,
						["transparency"] = 0.72,
						["shape"] = v_u_14
					}
					v_u_104 = v_u_4.part(Vector3.new(1.9, 1.9, 1.9) * v97, p96, v_u_11, v105)
					table.insert(v_u_103, v_u_104)
				end
				for _, v106 in v_u_103 do
					v_u_1:AddItem(v106, 3)
				end
				p_u_91.streak(v_u_98, v_u_11, v_u_12, 1.2 * v97, p95.lite and 0.1 or 0.18)
				local v_u_107
				if p95.lite then
					v_u_107 = nil
				else
					v_u_107 = v_u_51(v_u_98, {
						["texture"] = nil,
						["color"] = nil,
						["size"] = nil,
						["life"] = nil,
						["speed"] = nil,
						["accel"] = Vector3.new(0, -30, 0),
						["light"] = 0.3,
						["rate"] = 30,
						["texture"] = v_u_7.Glow,
						["color"] = ColorSequence.new(v_u_10, v_u_11),
						["size"] = NumberSequence.new(0.35 * v97, 0.1),
						["life"] = NumberRange.new(0.25, 0.4),
						["speed"] = NumberRange.new(1, 4)
					})
				end
				if p95.mine then
					p_u_91.light(v_u_98, v_u_9, 9 * v97)
				end
				local v_u_108 = false
				return {
					["place"] = function(p109, p110) -- name: place
						-- upvalues: (copy) v_u_98, (ref) v_u_3, (copy) v_u_99, (ref) p_u_91, (copy) v_u_100, (copy) v_u_102, (ref) v_u_104
						v_u_98.CFrame = p109
						local v111 = p109.Position
						local v112 = v_u_3.CurrentCamera
						local v113
						if v112 then
							local v114 = v112.CFrame.Position - v111
							v113 = v114.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v114.Unit
						else
							v113 = Vector3.new(0, 0, 1)
						end
						local v115 = CFrame.Angles(0, -p110 * 17, 0)
						v_u_99.CFrame = p_u_91.facing(v111 + v113 * 0.3, v113) * v115
						v_u_100.CFrame = p_u_91.facing(v111 + v113 * 0.4, v113) * v115 * CFrame.Angles(0, 3.141592653589793, 0)
						v_u_102.CFrame = CFrame.new(v111 + v113 * 0.5)
						local v116 = v_u_104
						if v116 then
							v116.CFrame = CFrame.new(v111 - v113 * 0.3)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_108, (ref) v_u_107, (copy) v_u_98, (ref) v_u_1, (copy) v_u_103
						if not v_u_108 then
							v_u_108 = true
							local v117 = v_u_107
							if v117 then
								v117.Enabled = false
							end
							local v118 = v_u_98:FindFirstChildWhichIsA("PointLight")
							if v118 then
								v118:Destroy()
							end
							v_u_1:AddItem(v_u_98, 0.5)
							for _, v119 in v_u_103 do
								v119:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p120, p121) -- name: fangImpact
				-- upvalues: (ref) v_u_58, (ref) v_u_11, (copy) p_u_91, (ref) v_u_9, (ref) v_u_8, (ref) v_u_66, (ref) v_u_10, (ref) v_u_73
				local v122 = p120.size
				v_u_58(p121, 4.6 * v122, v_u_11)
				p_u_91.pop(p121, v_u_9, 1.2 * v122, 4 * v122, 0.2, 0.4)
				p_u_91.pop(p121, v_u_8, 0.8 * v122, 2.2 * v122, 0.12)
				v_u_66(p_u_91.ground(p121), p120.ability.radius * 1.3 * v122, v_u_10, 0.45)
				if not p120.lite then
					v_u_73(p121, 10, 22 * v122, 0.4 * v122)
					v_u_58(p121, 3 * v122, v_u_10)
				end
				p_u_91.hitSound(p121)
			end,
			["hit"] = p_u_91.simpleHit(v_u_9, 0.6)
		}
	}
	local v_u_124 = {}
	setmetatable(v_u_124, {
		["__mode"] = "k"
	})
	local function v_u_193(p125, p126, p127) -- name: openPool
		-- upvalues: (copy) p_u_91, (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_28, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_11, (ref) v_u_13, (ref) v_u_66, (ref) v_u_32
		local v_u_128 = p125.ability.radius
		local v_u_129 = p127 + (p125.ability.duration or 2) + 1.5
		local v_u_130 = p_u_91.ground(p126, 0)
		local v131 = v_u_4.part
		local v132 = v_u_128 * 1.6
		local v133 = v_u_128 * 1.6
		local v134 = v131(Vector3.new(v132, 0.3, v133), CFrame.new(v_u_130 + Vector3.new(0, 0.3, 0)), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v134, v_u_129)
		local v_u_135 = {}
		for v136 = 1, 6 do
			local v137 = v_u_28
			local v138 = CFrame.new(v_u_130)
			local v139 = 0.1
			local v140 = v_u_7.CurrentFang
			local v141
			if v136 % 2 == 0 then
				v141 = v_u_10
			else
				v141 = v_u_9
			end
			local v142 = v137(v138, v139, v140, v141, 0)
			v_u_1:AddItem(v142, v_u_129)
			local v143 = {
				["p"] = nil,
				["r"] = nil,
				["a"] = nil,
				["size"] = nil,
				["speed"] = 2.3,
				["p"] = v142,
				["r"] = v_u_128 * 0.6,
				["a"] = v136 / 6 * 3.141592653589793 * 2,
				["size"] = v_u_128 * 0.42
			}
			table.insert(v_u_135, v143)
		end
		for v144 = 1, 4 do
			local v145 = v_u_28
			local v146 = CFrame.new(v_u_130)
			local v147 = 0.1
			local v148 = v_u_7.CurrentFang
			local v149
			if v144 % 2 == 0 then
				v149 = v_u_8
			else
				v149 = v_u_11
			end
			local v150 = v145(v146, v147, v148, v149, 0)
			v_u_1:AddItem(v150, v_u_129)
			local v151 = {
				["p"] = nil,
				["r"] = nil,
				["a"] = nil,
				["size"] = nil,
				["speed"] = 4.2,
				["p"] = v150,
				["r"] = v_u_128 * 0.26,
				["a"] = v144 / 4 * 3.141592653589793 * 2,
				["size"] = v_u_128 * 0.24
			}
			table.insert(v_u_135, v151)
		end
		local v_u_152 = v_u_28(CFrame.new(v_u_130 + Vector3.new(0, 0.12, 0)), 0.1, v_u_7.Glow, v_u_13, 0.05)
		v_u_1:AddItem(v_u_152, v_u_129)
		local v_u_153 = {
			["g"] = nil,
			["holder"] = nil,
			["arms"] = nil,
			["eye"] = nil,
			["walls"] = nil,
			["emitters"] = nil,
			["born"] = nil,
			["closing"] = nil,
			["hits"] = 0,
			["g"] = v_u_130,
			["holder"] = v134,
			["arms"] = v_u_135,
			["eye"] = v_u_152,
			["walls"] = {},
			["emitters"] = {},
			["born"] = os.clock()
		}
		v_u_66(v_u_130, v_u_128 * 1.15, v_u_10, 0.45)
		local v_u_154 = os.clock()
		local v_u_155 = 0
		p_u_91.runNow(function()
			-- upvalues: (ref) v_u_154, (ref) v_u_155, (copy) v_u_153, (copy) v_u_135, (copy) v_u_152, (copy) v_u_130, (ref) v_u_32, (copy) v_u_128, (copy) v_u_129
			local v156 = os.clock()
			local v157 = v156 - v_u_154
			local v158 = math.min(v157, 0.05)
			v_u_154 = v156
			v_u_155 = v_u_155 + v158
			local v159 = (v156 - v_u_153.born) / 0.3
			local v160 = math.clamp(v159, 0, 1) - 1
			local v161 = v160 * 2.7 * v160 * v160 + 1 + v160 * 1.7 * v160
			local v162 = v_u_153.closing
			local v163
			if v162 then
				local v164 = (v156 - v162) / 0.35
				v163 = math.clamp(v164, 0, 1)
				if v163 >= 1 then
					for _, v165 in v_u_135 do
						v165.p:Destroy()
					end
					v_u_152:Destroy()
					return false
				end
			else
				v163 = 0
			end
			for _, v166 in v_u_135 do
				local v167 = v166.a + v_u_155 * v166.speed * (v163 * 2 + 1)
				local v168 = v166.r * v161 * (v163 * 1.2 + 1)
				local v169 = v_u_130
				local v170 = math.cos(v167) * v168
				local v171 = math.sin(v167) * v168
				local v172 = v169 + Vector3.new(v170, 0.15, v171)
				local v173 = -math.sin(v167)
				local v174 = math.cos(v167)
				local v175 = Vector3.new(v173, 0, v174)
				local v176 = v166.p
				local v177 = CFrame.new(v172)
				local v178 = CFrame.Angles
				local v179 = -v175.Z
				local v180 = v175.X
				v176.CFrame = v177 * v178(0, math.atan2(v179, v180) + 0, 0)
				local v181 = v166.p
				local v182 = v166.size * v161
				local v183 = math.max(v182, 0.03)
				local v184 = v183 * 2
				local v185 = v183 * 2
				v181.Size = Vector3.new(v184, 0.05, v185)
				if v163 <= 0 then
					continue
				end
				v_u_32(v166.p, v163)
			end
			local v186 = v_u_152
			local v187 = v_u_128 * 0.32 * v161
			local v188 = v_u_155 * 9
			local v189 = v187 * (math.sin(v188) * 0.08 + 1)
			local v190 = math.max(v189, 0.03)
			local v191 = v190 * 2
			local v192 = v190 * 2
			v186.Size = Vector3.new(v191, 0.05, v192)
			if v163 > 0 then
				v_u_32(v_u_152, v163 * 0.95 + 0.05)
			end
			return v156 - v_u_153.born < v_u_129
		end)
		return v_u_153
	end
	local function v_u_203(p194, p_u_195) -- name: closingRing
		-- upvalues: (ref) v_u_28, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (copy) p_u_91, (ref) v_u_32
		local v_u_196 = v_u_28(CFrame.new(p194 + Vector3.new(0, 0.3, 0)), p_u_195, v_u_7.Ring, v_u_11, 0.35)
		v_u_1:AddItem(v_u_196, 0.5)
		p_u_91.animate(0.4, 0, function(p197)
			-- upvalues: (copy) v_u_196, (copy) p_u_195, (ref) v_u_32
			local v198 = v_u_196
			local v199 = p_u_195 * (1.1 - p197 * p197)
			local v200 = math.max(v199, 0.03)
			local v201 = v200 * 2
			local v202 = v200 * 2
			v198.Size = Vector3.new(v201, 0.05, v202)
			v_u_32(v_u_196, 0.35 + 0.65 * p197 ^ 3)
			if p197 >= 1 then
				v_u_196:Destroy()
			end
		end)
	end
	v123.raging_current_e = {
		["cast"] = function(p204) -- name: cast
			-- upvalues: (copy) p_u_91, (ref) v_u_9, (ref) v_u_58, (ref) v_u_10
			p_u_91.skillCast(p204, v_u_9)
			if not p204.lite then
				v_u_58(p204.eye + p204.dir * 1.2, 3 * p204.size, v_u_10)
			end
		end,
		["windup"] = function(p205, p206, p207) -- name: windup
			-- upvalues: (copy) v_u_124, (copy) v_u_193
			v_u_124[p205] = v_u_193(p205, p206, p207)
		end,
		["zone"] = function(p_u_208, p209, p_u_210) -- name: zone
			-- upvalues: (copy) v_u_124, (copy) v_u_193, (ref) v_u_82, (copy) p_u_91, (ref) v_u_51, (ref) v_u_7, (ref) v_u_16, (ref) v_u_11, (ref) v_u_10, (ref) v_u_4, (copy) v_u_203, (ref) v_u_66, (ref) v_u_58, (ref) v_u_73, (ref) v_u_6
			local v_u_211 = v_u_124[p_u_208] or v_u_193(p_u_208, p209, 0)
			v_u_124[p_u_208] = v_u_211
			local v_u_212 = p_u_208.ability.radius
			local v_u_213 = v_u_211.g
			local v_u_214 = p_u_208.lite
			if not v_u_214 then
				for v215 = 1, 10 do
					local v216 = v215 / 10 * 3.141592653589793 * 2
					local v217 = math.cos(v216) * v_u_212 * 0.95
					local v218 = math.sin(v216) * v_u_212 * 0.95
					local v219 = v_u_213 + Vector3.new(v217, 0.1, v218)
					local v220 = v_u_82(v_u_211.holder, v219, v219 + Vector3.new(0, 0.2, 0), 3, 2.2)
					local v221 = v_u_211.walls
					table.insert(v221, v220)
				end
				p_u_91.animate(0.3, 0, function(p222)
					-- upvalues: (copy) v_u_211
					local v223 = p222 - 1
					local v224 = (v223 * 2.7 * v223 * v223 + 1 + v223 * 1.7 * v223) * 4.2 + 0.2
					for _, v225 in v_u_211.walls do
						v225.a1.WorldPosition = v225.a0.WorldPosition + Vector3.new(0, 1, 0) * v224
					end
				end)
				local v226 = v_u_51(v_u_211.holder, {
					["texture"] = nil,
					["grid"] = nil,
					["color"] = nil,
					["size"] = nil,
					["alpha"] = nil,
					["life"] = nil,
					["speed"] = nil,
					["spread"] = nil,
					["light"] = 0.2,
					["rate"] = 9,
					["box"] = true,
					["z"] = 1,
					["texture"] = v_u_7.CurrentSlash,
					["grid"] = v_u_16,
					["color"] = ColorSequence.new(v_u_11, v_u_10),
					["size"] = NumberSequence.new(3.2),
					["alpha"] = NumberSequence.new(0),
					["life"] = NumberRange.new(0.4, 0.5),
					["speed"] = NumberRange.new(1, 3),
					["spread"] = Vector2.new(20, 20)
				})
				local v227 = v_u_211.emitters
				table.insert(v227, v226)
				local v228 = v_u_51(v_u_211.holder, {
					["texture"] = nil,
					["color"] = nil,
					["size"] = nil,
					["life"] = nil,
					["speed"] = nil,
					["spread"] = nil,
					["accel"] = Vector3.new(0, -25, 0),
					["light"] = 0.3,
					["rate"] = 28,
					["box"] = true,
					["texture"] = v_u_7.Glow,
					["color"] = ColorSequence.new(v_u_10, v_u_11),
					["size"] = NumberSequence.new(0.6, 0.15),
					["life"] = NumberRange.new(0.5, 0.9),
					["speed"] = NumberRange.new(4, 9),
					["spread"] = Vector2.new(25, 25)
				})
				local v229 = v_u_211.emitters
				table.insert(v229, v228)
			end
			if p_u_208.mine then
				v_u_4.shake(0.2, 0.25)
			end
			local v_u_230 = os.clock()
			local v_u_231 = 0.4
			local v_u_232 = false
			p_u_91.runNow(function()
				-- upvalues: (ref) v_u_232, (copy) v_u_230, (ref) v_u_231, (ref) v_u_203, (copy) v_u_213, (copy) v_u_212, (copy) v_u_214, (ref) v_u_66, (ref) v_u_11, (copy) p_u_210
				if v_u_232 then
					return false
				end
				local v233 = os.clock() - v_u_230
				if v_u_231 <= v233 then
					v_u_231 = v_u_231 + 0.4
					v_u_203(v_u_213, v_u_212)
					if not v_u_214 then
						v_u_66(v_u_213, v_u_212 * 0.45, v_u_11, 0.4)
					end
				end
				return v233 < p_u_210 + 0.3
			end)
			return function()
				-- upvalues: (ref) v_u_232, (ref) v_u_124, (copy) p_u_208, (copy) v_u_211, (ref) p_u_91, (ref) v_u_66, (copy) v_u_213, (copy) v_u_212, (ref) v_u_10, (ref) v_u_58, (ref) v_u_11, (copy) v_u_214, (ref) v_u_73, (ref) v_u_6
				v_u_232 = true
				v_u_124[p_u_208] = nil
				v_u_211.closing = os.clock()
				for _, v234 in v_u_211.emitters do
					v234.Enabled = false
				end
				p_u_91.animate(0.3, 0, function(p235)
					-- upvalues: (ref) v_u_211
					for _, v236 in v_u_211.walls do
						v236.a1.WorldPosition = v236.a0.WorldPosition + Vector3.new(0, 1, 0) * (0.2 + 4.4 * (1 - p235))
						v236.beam.Transparency = NumberSequence.new(p235)
					end
				end)
				v_u_66(v_u_213, v_u_212 * 1.3, v_u_10, 0.5)
				v_u_58(v_u_213 + Vector3.new(0, 2, 0), 7, v_u_11, v_u_214 and 1 or 3)
				if not v_u_214 then
					v_u_73(v_u_213 + Vector3.new(0, 1, 0), 24, 30, 0.6)
				end
				local v237 = {
					["at"] = nil,
					["volume"] = 0.5,
					["at"] = v_u_213
				}
				v_u_6.play("Burst", v237)
			end
		end,
		["hit"] = function(p238, p239, _) -- name: hit
			-- upvalues: (copy) v_u_124, (copy) p_u_91, (ref) v_u_9, (ref) v_u_58, (ref) v_u_10, (ref) v_u_11, (ref) v_u_66
			local v240 = v_u_124[p238]
			local v241 = not v240 and 1 or v240.hits + 1
			if v240 then
				v240.hits = v241
			end
			if p238.lite or v241 > 24 then
				p_u_91.burst("Impact", p239, v_u_9, 0.5)
			else
				local v242 = v_u_58
				local v243 = 3
				local v244
				if v241 % 2 == 0 then
					v244 = v_u_10
				else
					v244 = v_u_11
				end
				v242(p239, v243, v244)
				v_u_66(p_u_91.ground(p239), 3.2, v_u_11, 0.35)
			end
		end
	}
	local v_u_245 = {}
	setmetatable(v_u_245, {
		["__mode"] = "k"
	})
	local function v_u_255(p246, p247) -- name: placeLips
		-- upvalues: (ref) v_u_3, (ref) v_u_45
		for _, v248 in p246.walls do
			local v249 = v248.s.a1.WorldPosition
			local v250 = v_u_3.CurrentCamera
			local v251
			if v250 then
				local v252 = v250.CFrame.Position - v249
				v251 = v252.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v252.Unit
			else
				v251 = Vector3.new(0, 0, 1)
			end
			local v253 = (p246.g - v248.base) * Vector3.new(1, 0, 1)
			local v254 = (v253.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v253.Unit) + Vector3.new(0, 1, 0) * (0.4 - p247)
			v248.lip.CFrame = v_u_45(v249 + v251 * 0.5, v251, v254, 0)
		end
	end
	local function v_u_296(p256, p257, p_u_258) -- name: raise
		-- upvalues: (copy) p_u_91, (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_82, (ref) v_u_28, (ref) v_u_7, (ref) v_u_10, (ref) v_u_12, (copy) v_u_203, (ref) v_u_90, (ref) v_u_73, (copy) v_u_255
		local v259 = p256.ability.radius
		local v_u_260 = p_u_91.ground(p257, 0)
		local v261 = p_u_258 + 3
		local v262 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_260), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v262, v261)
		local v263 = p256.lite and 5 or 9
		local v264 = math.random() * 3.141592653589793 * 2
		local v_u_265 = {
			["g"] = nil,
			["holder"] = nil,
			["walls"] = nil,
			["snake"] = nil,
			["height"] = 0,
			["crashed"] = false,
			["g"] = v_u_260,
			["holder"] = v262,
			["walls"] = {}
		}
		for v266 = 1, v263 do
			local v267 = v264 + v266 / v263 * 3.141592653589793 * 2
			local v268 = math.cos(v267) * v259 * 0.95
			local v269 = math.sin(v267) * v259 * 0.95
			local v270 = v_u_260 + Vector3.new(v268, 0.1, v269)
			local v271 = v_u_82(v262, v270, v270 + Vector3.new(0, 0.3, 0), 7.5, 3)
			local v272 = v_u_28(CFrame.new(v270), 4, v_u_7.CurrentFang, v_u_10, 0)
			v_u_1:AddItem(v272, v261)
			local v273 = v_u_265.walls
			table.insert(v273, {
				["s"] = v271,
				["base"] = v270,
				["lip"] = v272
			})
		end
		p_u_91.mark(v_u_260, v_u_12, v259 * 1.05, p_u_258 + 1.2, v_u_7.Glow, 0.35)
		v_u_203(v_u_260, v259 * 1.1)
		if not p256.lite then
			local v_u_274 = v_u_90(13)
			if v_u_274 then
				v_u_1:AddItem(v_u_274, v261)
				v_u_265.snake = v_u_274
				local v_u_275 = os.clock()
				local v_u_276 = v_u_274.Size
				v_u_274.Size = v_u_276 * 0.05
				p_u_91.runNow(function()
					-- upvalues: (copy) v_u_274, (copy) v_u_265, (copy) v_u_275, (copy) p_u_258, (copy) v_u_276, (copy) v_u_260
					if not v_u_274.Parent or v_u_265.crashed then
						return false
					end
					local v277 = os.clock() - v_u_275
					local v278 = p_u_258
					local v279 = v277 / math.max(v278, 0.15)
					local v280 = math.clamp(v279, 0, 1)
					local v281 = v_u_274
					local v282 = v_u_276
					local v283 = v280 - 1
					local v284 = v283 * 2.7 * v283 * v283 + 1 + v283 * 1.7 * v283
					v281.Size = v282 * math.max(v284, 0.05)
					v_u_274.CFrame = CFrame.new(v_u_260 + Vector3.new(0, 22, 0)) * CFrame.Angles(0, v277 * 3.2, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
					return true
				end)
			end
			for _, v285 in v_u_265.walls do
				v_u_73(v285.base + Vector3.new(0, 1, 0), 4, 18, 0.7)
			end
		end
		p_u_91.animate(math.max(p_u_258, 0.12), 0, function(p286)
			-- upvalues: (copy) v_u_265, (ref) v_u_255
			if not v_u_265.crashed then
				local v287 = p286 - 1
				local v288 = (v287 * 2.7 * v287 * v287 + 1 + v287 * 1.7 * v287) * 15
				v_u_265.height = v288
				for _, v289 in v_u_265.walls do
					v289.s.a1.WorldPosition = v289.base + Vector3.new(0, 1, 0) * math.max(v288, 0.3)
					local v290 = v289.lip
					local v291 = p286 * 1.4
					local v292 = math.clamp(v291, 0.05, 1) * 4
					local v293 = math.max(v292, 0.03)
					local v294 = v293 * 2
					local v295 = v293 * 2
					v290.Size = Vector3.new(v294, 0.05, v295)
				end
				v_u_255(v_u_265, 0)
			end
		end)
		return v_u_265
	end
	local function v_u_358(p_u_297, p_u_298) -- name: crash
		-- upvalues: (copy) p_u_91, (copy) v_u_255, (ref) v_u_32, (ref) v_u_4, (ref) v_u_10, (ref) v_u_9, (ref) v_u_66, (ref) v_u_11, (ref) v_u_7, (ref) v_u_16, (ref) v_u_3, (ref) v_u_51, (ref) v_u_1, (ref) v_u_82, (ref) v_u_73, (ref) v_u_28, (ref) v_u_12, (ref) v_u_6
		local v_u_299 = p_u_297.ability.radius
		local v_u_300 = p_u_298.g
		local v_u_301 = p_u_297.lite
		p_u_298.crashed = true
		local v302 = p_u_298.height
		local v_u_303 = math.max(v302, 12)
		p_u_91.animate(0.2, 0, function(p304)
			-- upvalues: (copy) p_u_298, (copy) v_u_300, (copy) v_u_303, (ref) v_u_255
			local v305 = p304 * p304
			for _, v306 in p_u_298.walls do
				local v307 = v306.base:Lerp(v_u_300, 0.25 + 0.7 * v305) + Vector3.new(0, 1, 0) * (v_u_303 * (1 - v305) + 2 * v305)
				v306.s.a1.WorldPosition = v307
				v306.s.beam.Width0 = 7.5 + 3 * v305
			end
			v_u_255(p_u_298, v305 * 1.4)
		end)
		local v_u_308 = p_u_298.snake
		if v_u_308 then
			local v_u_309 = v_u_308.CFrame
			local v_u_310 = v_u_308.Size
			p_u_91.animate(0.2, 0, function(p311)
				-- upvalues: (copy) v_u_308, (copy) v_u_309, (copy) v_u_300, (ref) p_u_91, (copy) v_u_310
				if v_u_308.Parent then
					v_u_308.CFrame = v_u_309:Lerp(CFrame.new(v_u_300 + Vector3.new(0, 2, 0)) * v_u_309.Rotation, p311 * p311)
					if p311 >= 1 then
						p_u_91.animate(0.3, 0, function(p312)
							-- upvalues: (ref) v_u_308, (ref) v_u_310
							if v_u_308.Parent then
								v_u_308.Size = v_u_310 * (1 + 0.8 * p312)
								v_u_308.Transparency = p312
							end
							if p312 >= 1 then
								v_u_308:Destroy()
							end
						end)
					end
				end
			end)
		end
		p_u_91.after(0.18, function()
			-- upvalues: (ref) p_u_91, (copy) p_u_298, (ref) v_u_32, (ref) v_u_4, (copy) v_u_300, (ref) v_u_10, (copy) v_u_299, (ref) v_u_9, (ref) v_u_66, (ref) v_u_11, (ref) v_u_7, (ref) v_u_16, (copy) v_u_301, (ref) v_u_3, (ref) v_u_51, (ref) v_u_1, (ref) v_u_82, (ref) v_u_73, (ref) v_u_28, (ref) v_u_12, (ref) v_u_6, (copy) p_u_297
			p_u_91.animate(0.3, 0, function(p313)
				-- upvalues: (ref) p_u_298, (ref) v_u_32
				for _, v314 in p_u_298.walls do
					v314.s.beam.Transparency = NumberSequence.new(p313)
					v_u_32(v314.lip, p313)
				end
				if p313 >= 1 then
					p_u_298.holder:Destroy()
					for _, v315 in p_u_298.walls do
						v315.lip:Destroy()
					end
				end
			end)
			v_u_4.flash(v_u_300 + Vector3.new(0, 3, 0), v_u_10, v_u_299 * 1.1, 0.3)
			p_u_91.dome(v_u_300, v_u_299 * 1.15, v_u_9, 0.6)
			v_u_66(v_u_300, v_u_299 * 1.5, v_u_10, 0.6)
			v_u_66(v_u_300, v_u_299 * 1.05, v_u_11, 0.5)
			v_u_4.ring(v_u_300, v_u_9, v_u_299 * 1.3, 0.6, v_u_7.Shockwave)
			p_u_91.burst("Explosion", v_u_300 + Vector3.new(0, 2, 0), v_u_9, 2)
			local v316 = v_u_300 + Vector3.new(0, 4, 0)
			local v317 = {
				["texture"] = nil,
				["grid"] = nil,
				["color"] = nil,
				["size"] = nil,
				["alpha"] = nil,
				["life"] = nil,
				["speed"] = nil,
				["spread"] = nil,
				["light"] = 0.2,
				["z"] = 2,
				["texture"] = v_u_7.CurrentSlash,
				["grid"] = v_u_16,
				["color"] = ColorSequence.new(v_u_11, v_u_10),
				["size"] = NumberSequence.new(9, 11),
				["alpha"] = NumberSequence.new(0),
				["life"] = NumberRange.new(0.5, 0.6),
				["speed"] = NumberRange.new(6, 14),
				["spread"] = Vector2.new(60, 60)
			}
			local v318 = v_u_301 and 3 or 8
			local v319 = Instance.new("Attachment")
			v319.Parent = v_u_3.Terrain
			v319.WorldPosition = v316
			v_u_51(v319, v317):Emit(v318)
			v_u_1:AddItem(v319, v317.life.Max + 0.3)
			if not v_u_301 then
				local v320 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_300), v_u_9, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v320, 1)
				local v_u_321 = v_u_82(v320, v_u_300 + Vector3.new(0, 0.2, 0), v_u_300 + Vector3.new(0, 0.5, 0), 9, 6)
				p_u_91.animate(0.7, 0, function(p322)
					-- upvalues: (copy) v_u_321, (ref) v_u_300
					local v323 = p322 / 0.8
					local v324 = math.min(v323, 1) * 3.141592653589793
					local v325 = math.sin(v324)
					v_u_321.a1.WorldPosition = v_u_300 + Vector3.new(0, 1, 0) * (v325 * 28 + 0.5)
					v_u_321.beam.Width0 = 9 * (1 - 0.5 * p322)
					v_u_321.beam.Width1 = 6 * (1 - 0.6 * p322)
					local v326 = v_u_321.beam
					local v327 = NumberSequence.new
					local v328 = p322 - 0.6
					v326.Transparency = v327(math.max(v328, 0) / 0.4)
				end)
				v_u_73(v_u_300 + Vector3.new(0, 3, 0), 40, 55, 0.9)
				for v329 = 1, 6 do
					local v_u_330 = v329 / 6 * 3.141592653589793 * 2
					local v331 = v_u_28
					local v332 = CFrame.new(v_u_300)
					local v333 = 0.1
					local v334 = v_u_7.CurrentFang
					local v335
					if v329 % 2 == 0 then
						v335 = v_u_10
					else
						v335 = v_u_9
					end
					local v_u_336 = v331(v332, v333, v334, v335, 0)
					v_u_1:AddItem(v_u_336, 1)
					p_u_91.animate(0.75, 0, function(p337)
						-- upvalues: (copy) v_u_330, (ref) v_u_299, (ref) v_u_300, (copy) v_u_336, (ref) v_u_32
						local v338 = 1 - (1 - p337) ^ 2
						local v339 = v_u_330 + 2.4 * v338
						local v340 = v_u_299 * 1.25 * v338
						local v341 = v_u_300
						local v342 = math.cos(v339) * v340
						local v343 = math.sin(v339) * v340
						local v344 = v341 + Vector3.new(v342, 0.2, v343)
						local v345 = v_u_336
						local v346 = -math.sin(v339)
						local v347 = math.cos(v339)
						local v348 = Vector3.new(v346, 0, v347)
						local v349 = CFrame.new(v344)
						local v350 = CFrame.Angles
						local v351 = -v348.Z
						local v352 = v348.X
						v345.CFrame = v349 * v350(0, math.atan2(v351, v352) + 0, 0)
						local v353 = v_u_336
						local v354 = v_u_299 * (0.2 + 0.25 * v338)
						local v355 = math.max(v354, 0.03)
						local v356 = v355 * 2
						local v357 = v355 * 2
						v353.Size = Vector3.new(v356, 0.05, v357)
						v_u_32(v_u_336, p337 ^ 2)
						if p337 >= 1 then
							v_u_336:Destroy()
						end
					end)
				end
			end
			p_u_91.mark(v_u_300, v_u_12, v_u_299 * 1.1, 1.6, v_u_7.Glow, 0.35)
			v_u_6.play("Explosion", {
				["at"] = v_u_300,
				["volume"] = p_u_297.mine and 1 or 0.6
			})
			if p_u_297.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end)
	end
	v123.raging_current_r = {
		["cast"] = function(p359) -- name: cast
			-- upvalues: (copy) p_u_91, (ref) v_u_9, (ref) v_u_58, (ref) v_u_10, (ref) v_u_66, (ref) v_u_11
			p_u_91.skillCast(p359, v_u_9, true)
			v_u_58(p359.eye + p359.dir * 1.3, 4 * p359.size, v_u_10)
			if not p359.lite then
				v_u_66(p359.feet, 7 * p359.size, v_u_11, 0.4)
			end
		end,
		["windup"] = function(p360, p361, p362) -- name: windup
			-- upvalues: (copy) v_u_245, (copy) v_u_296
			v_u_245[p360] = v_u_296(p360, p361, p362)
		end,
		["land"] = function(p363, p364) -- name: land
			-- upvalues: (copy) v_u_245, (copy) v_u_296, (copy) v_u_358
			local v365 = v_u_245[p363] or v_u_296(p363, p364, 0)
			v_u_245[p363] = nil
			v_u_358(p363, v365)
		end,
		["hit"] = function(p366, p367, _) -- name: hit
			-- upvalues: (copy) p_u_91, (ref) v_u_9, (ref) v_u_58, (ref) v_u_10
			p_u_91.burst("Impact", p367, v_u_9, 0.8)
			if not p366.lite then
				v_u_58(p367, 3.5, v_u_10)
			end
		end
	}
	return v123
end