local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("E0141E")
local v_u_9 = Color3.fromRGB(8, 6, 8)
local v_u_10 = Color3.fromRGB(150, 6, 18)
local v_u_11 = Color3.fromRGB(255, 236, 236)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.Material.SmoothPlastic
local v_u_14 = CFrame.Angles(0, 3.9269908169872414, 0)
local v_u_15 = {
	["texture"] = nil,
	["life"] = 0.4,
	["speed"] = 6,
	["rise"] = 0,
	["glow"] = 0,
	["color"] = nil,
	["upright"] = false,
	["spin"] = 200,
	["texture"] = v_u_7.GetsugaFang,
	["color"] = v_u_12
}
local v_u_16 = {
	["texture"] = nil,
	["life"] = 0.7,
	["speed"] = 4,
	["rise"] = 8,
	["glow"] = 0,
	["color"] = nil,
	["upright"] = true,
	["spin"] = 0,
	["texture"] = v_u_7.ShadowFlame,
	["color"] = v_u_8
}
local function v_u_21(p17, p18) -- name: emitterOf
	local v19 = Instance.new("ParticleEmitter")
	v19.Enabled = false
	v19.Texture = p17.texture
	v19.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v19.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v19.Color = ColorSequence.new(p17.color)
	v19.LightEmission = p17.glow
	v19.LightInfluence = 0
	v19.Brightness = 1.4
	v19.Lifetime = NumberRange.new(p17.life * 0.8, p17.life * 1.15)
	v19.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 * 0.75), NumberSequenceKeypoint.new(0.4, p18), NumberSequenceKeypoint.new(1, p18 * 0.8) })
	v19.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.85, 0), NumberSequenceKeypoint.new(1, 1) })
	v19.Speed = NumberRange.new(p17.speed * 0.5, p17.speed * 1.2)
	v19.SpreadAngle = Vector2.new(180, 180)
	local v20 = p17.rise
	v19.Acceleration = Vector3.new(0, v20, 0)
	v19.Drag = 2
	if not p17.upright then
		v19.Rotation = NumberRange.new(0, 360)
		v19.RotSpeed = NumberRange.new(-p17.spin, p17.spin)
		return v19
	end
	v19.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
	v19.Rotation = NumberRange.new(-12, 12)
	v19.SpreadAngle = Vector2.new(30, 30)
	v19.EmissionDirection = Enum.NormalId.Top
	return v19
end
local v_u_22 = {}
local function v_u_29(p23, p24, p25) -- name: katanaFrame
	local v26 = p24.Unit
	local v27 = p25 - v26 * p25:Dot(v26)
	if v27.Magnitude < 0.001 then
		v27 = v26:Cross(Vector3.new(1, 0, 0))
	end
	local v28 = v27.Unit
	return CFrame.fromMatrix(p23, v28, v28:Cross(v26)) * CFrame.Angles(-0.7155849933176751, 0, 0)
end
local function v_u_36(p30, p31, p32, p33) -- name: sprite
	-- upvalues: (copy) v_u_4, (copy) v_u_21, (copy) v_u_1
	if p32 > 0 then
		local v34 = Instance.new("Attachment")
		v34.WorldPosition = p31
		v34.Parent = v_u_4.Terrain
		local v35 = v_u_21(p30, p33)
		v35.Parent = v34
		v35:Emit(p32)
		v_u_1:AddItem(v34, p30.life * 1.3 + 0.2)
	end
end
local function v_u_48(p37, p38, p39, p40, p41) -- name: pic
	-- upvalues: (copy) v_u_5
	local v42 = v_u_5.part
	local v43 = p38 * 2
	local v44 = p38 * 2
	local v45 = v42(Vector3.new(v43, 0.05, v44), p37, p40, {
		["transparency"] = 1
	})
	for _, v46 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v47 = Instance.new("Decal")
		v47.Face = v46
		v47.Texture = p39
		v47.Color3 = p40
		v47.Transparency = p41
		v47.Parent = v45
	end
	return v45
end
local function v_u_54(p49, p50, p51) -- name: setPic
	local v52 = math.max(p50, 0.03) * 2
	p49.Size = Vector3.new(v52, 0.05, v52)
	if p51 then
		for _, v53 in p49:GetChildren() do
			if not v53:IsA("Decal") then
				continue
			end
			v53.Transparency = p51
		end
	end
end
local function v_u_65(p55, p56) -- name: katana
	-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_13, (copy) v_u_5, (copy) v_u_1
	local v57 = v_u_3:FindFirstChild("EyePieces")
	if v57 then
		v57 = v57:FindFirstChild("w6_getsuga_tensho")
	end
	local v58
	if v57 and v57:IsA("MeshPart") then
		v58 = v57:Clone()
		local v59 = v57.Size
		local v60 = v57.Size.Y
		local v61 = v57.Size.Z
		local v62 = math.max(v60, v61) * 1.35
		v58.Size = v59 * (p55 / math.max(v62, 0.01))
	else
		v58 = Instance.new("WedgePart")
		local v63 = p55 * 0.03
		local v64 = p55 * 0.07
		v58.Size = Vector3.new(v63, v64, p55)
		v58.Color = v_u_9
		v58.Material = v_u_13
	end
	v58.Anchored = true
	v58.CanCollide = false
	v58.CanQuery = false
	v58.CanTouch = false
	v58.CastShadow = false
	v58.Parent = v_u_5.folder()
	v_u_1:AddItem(v58, p56)
	return v58
end
local function v_u_76(p66, p67, p68, p69, p70, p71, p_u_72) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_12, (copy) v_u_1
	local v73 = v_u_2:FindFirstChild("GetsugaTensho")
	if v73 then
		v73:Destroy()
	end
	local v_u_74 = Instance.new("ColorCorrectionEffect")
	v_u_74.Name = "GetsugaTensho"
	v_u_74.Parent = v_u_2
	v_u_5.tween(v_u_74, p70, {
		["TintColor"] = p66,
		["Brightness"] = p67,
		["Contrast"] = p68,
		["Saturation"] = p69
	})
	task.delay(p70 + p71, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_74, (copy) p_u_72, (ref) v_u_12
		local v75 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_12
		}
		v_u_5.tween(v_u_74, p_u_72, v75)
	end)
	v_u_1:AddItem(v_u_74, p70 + p71 + p_u_72 + 0.1)
end
local function v_u_82(p77, p78, p79) -- name: planeFrame
	local v80 = p78.Unit
	local v81 = p79 - v80 * p79:Dot(v80)
	if v81.Magnitude < 0.001 then
		v81 = v80:Cross(Vector3.new(1, 0, 0))
		if v81.Magnitude < 0.001 then
			v81 = v80:Cross(Vector3.new(0, 0, 1))
		end
	end
	return CFrame.fromMatrix(p77, v81.Unit, v80)
end
for _, v83 in {
	"Head",
	"UpperTorso",
	"LowerTorso",
	"LeftUpperArm",
	"RightUpperArm",
	"LeftLowerArm",
	"RightLowerArm",
	"LeftHand",
	"RightHand",
	"LeftUpperLeg",
	"RightUpperLeg",
	"LeftLowerLeg",
	"RightLowerLeg",
	"LeftFoot",
	"RightFoot",
	"Torso",
	"Left Arm",
	"Right Arm",
	"Left Leg",
	"Right Leg"
} do
	v_u_22[v83] = true
end
local v_u_84 = {
	{
		["size"] = Vector3.new(1.2, 1.2, 1.2),
		["off"] = nil,
		["off"] = CFrame.new(0, 1.6, 0)
	},
	{
		["size"] = Vector3.new(2, 1.6, 1),
		["off"] = nil,
		["off"] = CFrame.new(0, 0.4, 0)
	},
	{
		["size"] = Vector3.new(1.8, 0.6, 1),
		["off"] = nil,
		["off"] = CFrame.new(0, -0.6, 0)
	},
	{
		["size"] = Vector3.new(0.9, 2.1, 0.9),
		["off"] = nil,
		["off"] = CFrame.new(-1.45, 0.05, 0)
	},
	{
		["size"] = Vector3.new(0.9, 2.1, 0.9),
		["off"] = nil,
		["off"] = CFrame.new(1.45, 0.05, 0)
	},
	{
		["size"] = Vector3.new(0.9, 2.2, 0.9),
		["off"] = nil,
		["off"] = CFrame.new(-0.5, -2, 0)
	},
	{
		["size"] = Vector3.new(0.9, 2.2, 0.9),
		["off"] = nil,
		["off"] = CFrame.new(0.5, -2, 0)
	}
}
return function(p_u_85)
	-- upvalues: (copy) v_u_48, (copy) v_u_1, (copy) v_u_54, (copy) v_u_5, (copy) v_u_11, (copy) v_u_8, (copy) v_u_10, (copy) v_u_7, (copy) v_u_21, (copy) v_u_15, (copy) v_u_82, (copy) v_u_4, (copy) v_u_14, (copy) v_u_36, (copy) v_u_9, (copy) v_u_13, (copy) v_u_22, (copy) v_u_84, (copy) v_u_65, (copy) v_u_29, (copy) v_u_6, (copy) v_u_16, (copy) v_u_76
	local v86 = {}
	local function v_u_97(p87, p_u_88, p_u_89, p90, p91, p92, p93) -- name: flare
		-- upvalues: (ref) v_u_48, (ref) v_u_1, (copy) p_u_85, (ref) v_u_54
		local v_u_94 = p93 or 0
		local v_u_95 = v_u_48(p87, p_u_88, p90, p91, v_u_94)
		v_u_1:AddItem(v_u_95, p92 + 0.1)
		p_u_85.animate(p92, 0, function(p96)
			-- upvalues: (ref) v_u_54, (copy) v_u_95, (copy) p_u_88, (copy) p_u_89, (copy) v_u_94
			v_u_54(v_u_95, p_u_88 + (p_u_89 - p_u_88) * (1 - (1 - p96) ^ 3), v_u_94 + (1 - v_u_94) * p96 ^ 1.6)
			if p96 >= 1 then
				v_u_95:Destroy()
			end
		end)
	end
	local function v_u_129(p98, p99, p_u_100, p101) -- name: cut
		-- upvalues: (ref) v_u_5, (ref) v_u_11, (ref) v_u_8, (ref) v_u_1, (copy) p_u_85
		local v_u_102 = (p99 - p98).Magnitude
		if v_u_102 >= 0.1 then
			local v103 = CFrame.lookAt((p98 + p99) / 2, p99)
			local v_u_104 = v_u_5.part(Vector3.new(p_u_100, p_u_100, v_u_102), v103, v_u_11)
			local v105 = v_u_5.part
			local v106 = p_u_100 * 2.6
			local v107 = p_u_100 * 2.6
			local v108 = v_u_102 * 1.02
			local v_u_109 = v105(Vector3.new(v106, v107, v108), v103, v_u_8, {
				["transparency"] = 0.35
			})
			v_u_1:AddItem(v_u_104, p101 + 0.05)
			v_u_1:AddItem(v_u_109, p101 + 0.05)
			p_u_85.animate(p101, 0, function(p110)
				-- upvalues: (copy) p_u_100, (copy) v_u_104, (copy) v_u_102, (ref) v_u_11, (ref) v_u_8, (copy) v_u_109
				local v111 = p_u_100
				local v112 = p110 * 3
				local v113 = math.min(v112, 1) * 3.141592653589793 / 2
				local v114 = v111 * (math.sin(v113) * 1.5 + 1) * (1 - p110)
				local v115 = v_u_104
				local v116 = math.max(v114, 0.02)
				local v117 = math.max(v114, 0.02)
				local v118 = v_u_102
				v115.Size = Vector3.new(v116, v117, v118)
				local v119 = v_u_104
				local v120 = v_u_11
				local v121 = v_u_8
				local v122 = p110 * 2
				v119.Color = v120:Lerp(v121, (math.clamp(v122, 0, 1)))
				local v123 = v_u_109
				local v124 = v114 * 2.6
				local v125 = math.max(v124, 0.02)
				local v126 = v114 * 2.6
				local v127 = math.max(v126, 0.02)
				local v128 = v_u_102 * 1.02
				v123.Size = Vector3.new(v125, v127, v128)
				v_u_109.Transparency = 0.35 + 0.65 * p110
				if p110 >= 1 then
					v_u_104:Destroy()
					v_u_109:Destroy()
				end
			end)
		end
	end
	v86.getsuga_tensho_a = {
		["cast"] = function(p130) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_85, (ref) v_u_9, (ref) v_u_13
			local v131 = p130.size
			local v132 = p130.eye + p130.dir * 1.2
			v_u_5.flash(v132, v_u_8, 3.2 * v131, 0.12)
			p_u_85.pop(v132, v_u_9, 1.6 * v131, 0.3 * v131, 0.12, 0, v_u_13)
		end,
		["shot"] = function(p_u_133, p134) -- name: waveShot
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (copy) p_u_85, (ref) v_u_10, (ref) v_u_48, (ref) v_u_7, (ref) v_u_21, (ref) v_u_15, (ref) v_u_82, (ref) v_u_4, (ref) v_u_14
			local v_u_135 = p_u_133.size
			local v_u_136 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p134, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_136, 3)
			p_u_85.streak(v_u_136, v_u_8, v_u_10, 1.2 * v_u_135, p_u_133.lite and 0.1 or 0.18)
			local v_u_137 = v_u_48(p134, 3.3 * v_u_135, v_u_7.Glow, v_u_8, 0.5)
			local v_u_138 = v_u_48(p134, 3 * v_u_135, v_u_7.GetsugaBrush, v_u_8, 0)
			v_u_1:AddItem(v_u_137, 3)
			v_u_1:AddItem(v_u_138, 3)
			local v_u_139
			if p_u_133.lite then
				v_u_139 = nil
			else
				v_u_139 = v_u_21(v_u_15, 2.6 * v_u_135)
				v_u_139.Lifetime = NumberRange.new(0.22, 0.3)
				v_u_139.Speed = NumberRange.new(0.5, 1.5)
				v_u_139.Rate = 26
				v_u_139.Enabled = true
				v_u_139.Parent = v_u_136
			end
			if p_u_133.mine then
				p_u_85.light(v_u_136, v_u_8, 9 * v_u_135)
			end
			local v_u_140 = false
			return {
				["place"] = function(p141, p142) -- name: place
					-- upvalues: (copy) v_u_136, (ref) v_u_82, (ref) v_u_4, (copy) v_u_138, (ref) v_u_14, (copy) v_u_135, (copy) v_u_137, (ref) p_u_85
					v_u_136.CFrame = p141
					local v143 = p141.Position
					local v144 = p141.LookVector
					local v145 = v_u_82
					local v146 = v_u_4.CurrentCamera
					local v147
					if v146 then
						local v148 = v146.CFrame.Position - v143
						v147 = v148.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v148.Unit
					else
						v147 = Vector3.new(0, 0, 1)
					end
					v_u_138.CFrame = v145(v143, v147, v144 + Vector3.new(0, 0.6, 0)) * v_u_14
					local v149 = v_u_138
					local v150 = 3 * v_u_135
					local v151 = p142 * 45
					local v152 = v150 * (math.sin(v151) * 0.05 + 1)
					local v153 = math.max(v152, 0.03) * 2
					v149.Size = Vector3.new(v153, 0.05, v153)
					local v154 = v_u_137
					local v155 = p_u_85.facing
					local v156 = v_u_4.CurrentCamera
					local v157
					if v156 then
						local v158 = v156.CFrame.Position - v143
						v157 = v158.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v158.Unit
					else
						v157 = Vector3.new(0, 0, 1)
					end
					v154.CFrame = v155(v143, v157) * CFrame.new(0, -0.3, 0)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_140, (copy) v_u_138, (copy) v_u_137, (ref) v_u_139, (copy) v_u_136, (ref) v_u_1, (copy) p_u_133
					if not v_u_140 then
						v_u_140 = true
						v_u_138:Destroy()
						v_u_137:Destroy()
						local v159 = v_u_139
						if v159 then
							v159.Enabled = false
						end
						local v160 = v_u_136:FindFirstChildWhichIsA("PointLight")
						if v160 then
							v160:Destroy()
						end
						v_u_1:AddItem(v_u_136, p_u_133.lite and 0.2 or 0.5)
					end
				end
			}
		end,
		["impact"] = function(p161, p162) -- name: waveCut
			-- upvalues: (ref) v_u_4, (copy) v_u_129, (ref) v_u_36, (ref) v_u_15, (copy) p_u_85, (ref) v_u_8, (ref) v_u_9, (ref) v_u_13, (copy) v_u_97, (ref) v_u_82, (ref) v_u_14, (ref) v_u_7
			local v163 = p161.size
			local v164 = v_u_4.CurrentCamera
			local v165 = not v164 and Vector3.new(1, 0, 0) or v164.CFrame.RightVector
			local v166 = (v165 + Vector3.new(0, 1, 0) * (math.random() < 0.5 and 0.6 or -0.6)).Unit
			v_u_129(p162 - v166 * 3.4 * v163, p162 + v166 * 3.4 * v163, 0.18 * v163, 0.22)
			v_u_36(v_u_15, p162, p161.lite and 1 or 3, 4.2 * v163)
			p_u_85.burst("Impact", p162, v_u_8, 0.75 * v163)
			if not p161.lite then
				p_u_85.pop(p162, v_u_9, 2.6 * v163, 0.4 * v163, 0.16, 0, v_u_13)
				local v167 = v_u_97
				local v168 = v_u_82
				local v169 = v_u_4.CurrentCamera
				local v170
				if v169 then
					local v171 = v169.CFrame.Position - p162
					v170 = v171.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v171.Unit
				else
					v170 = Vector3.new(0, 0, 1)
				end
				v167(v168(p162, v170, v165) * v_u_14, 1.6 * v163, 4.4 * v163, v_u_7.GetsugaBrush, v_u_8, 0.2, 0)
			end
			p_u_85.hitSound(p162)
		end,
		["hit"] = p_u_85.simpleHit(v_u_8, 0.55)
	}
	local function v_u_191(p172, p173, p174) -- name: afterimage
		-- upvalues: (ref) v_u_22, (ref) v_u_13, (ref) v_u_9, (ref) v_u_84, (ref) v_u_5, (ref) v_u_65, (ref) v_u_29, (ref) v_u_8, (ref) v_u_1
		local v175 = Instance.new("Model")
		v175.Name = "GetsugaAfterimage"
		local v176
		if p172 then
			v176 = p172:FindFirstChild("HumanoidRootPart")
			if not (v176 and v176:IsA("BasePart")) then
				v176 = nil
			end
		else
			v176 = nil
		end
		local v177 = 0
		local v178 = nil
		if p172 and v176 then
			local v179 = v176.CFrame
			for _, v180 in p172:GetChildren() do
				if not (v180:IsA("BasePart") and v_u_22[v180.Name]) then
					continue
				end
				local v181 = v179:ToObjectSpace(v180.CFrame)
				local v182
				if v180:IsA("MeshPart") then
					local v183 = v180.Archivable
					v180.Archivable = true
					v182 = v180:Clone()
					v180.Archivable = v183
					for _, v184 in v182:GetChildren() do
						v184:Destroy()
					end
					v182.TextureID = ""
				else
					v182 = Instance.new("Part")
					v182.Size = v180.Size
				end
				v182.Anchored = true
				v182.CanCollide = false
				v182.CanQuery = false
				v182.CanTouch = false
				v182.CastShadow = false
				v182.Material = v_u_13
				v182.Color = v_u_9
				v182.CFrame = p173 * v181
				v182.Parent = v175
				v177 = v177 + 1
				if v180.Name ~= "RightHand" and v180.Name ~= "Right Arm" then
					continue
				end
				v178 = p173 * v181 * CFrame.new(0, -v180.Size.Y * 0.45, 0)
			end
		end
		if v177 == 0 then
			for _, v185 in v_u_84 do
				local v186 = {
					["material"] = v_u_13
				}
				v_u_5.part(v185.size, p173 * v185.off, v_u_9, v186).Parent = v175
			end
			v178 = p173 * CFrame.new(1.45, -1, 0)
		end
		local v187 = v178 or p173 * CFrame.new(1.45, -1, 0)
		local v188 = v_u_65(5, p174)
		local v189 = (p173.LookVector * 0.8 - Vector3.new(0, 0.45, 0) + p173.RightVector * 0.25).Unit
		v188.CFrame = v_u_29(v187.Position + v189 * 5 * 0.45, v189, p173.RightVector)
		v188.Parent = v175
		local v190 = Instance.new("Highlight")
		v190.FillColor = v_u_9
		v190.FillTransparency = 0
		v190.OutlineColor = v_u_8
		v190.OutlineTransparency = 0
		v190.DepthMode = Enum.HighlightDepthMode.Occluded
		v190.Parent = v175
		v175.Parent = v_u_5.folder()
		v_u_1:AddItem(v175, p174)
		return v175
	end
	local function v_u_198(p192, p193) -- name: scatter
		-- upvalues: (ref) v_u_5, (copy) p_u_85, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1
		local v194 = p192:FindFirstChildWhichIsA("Highlight")
		if v194 then
			v_u_5.tween(v194, 0.25, {
				["FillTransparency"] = 1,
				["OutlineTransparency"] = 1
			})
		end
		local v195 = p192:GetPivot().Position
		for _, v196 in p192:GetChildren() do
			if not v196:IsA("BasePart") then
				continue
			end
			v_u_5.tween(v196, 0.25, {
				["Transparency"] = 1
			})
		end
		if not p193 then
			local v197 = { v_u_9, v_u_10 }
			p_u_85.chunks(v195, v197, 5, 16, 0.45, 0.6, false, 0.4)
		end
		v_u_1:AddItem(p192, 0.3)
	end
	v86.getsuga_tensho_e = {
		["cast"] = function(p199) -- name: cast
			-- upvalues: (copy) p_u_85, (ref) v_u_8, (ref) v_u_9, (ref) v_u_13
			p_u_85.skillCast(p199, v_u_8)
			p_u_85.pop(p199.feet + Vector3.new(0, 2.5, 0), v_u_9, 5, 1, 0.15, 0, v_u_13)
		end,
		["beam"] = function(p_u_200, p_u_201, p_u_202) -- name: beam
			-- upvalues: (copy) p_u_85, (copy) v_u_191, (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1, (copy) v_u_129, (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (copy) v_u_198
			local v203 = p_u_202 - p_u_201
			local v204 = v203.X
			local v205 = v203.Z
			local v206 = Vector3.new(v204, 0, v205)
			local v_u_207 = v206.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v206.Unit
			local v_u_208 = p_u_200.lite and 2 or 5
			local v_u_209 = p_u_85.ground(p_u_201, 0)
			local v_u_210
			if p_u_200.caster then
				v_u_210 = p_u_200.caster.Character
			else
				v_u_210 = nil
			end
			local v211
			if v_u_210 then
				v211 = v_u_210:FindFirstChild("HumanoidRootPart")
			else
				v211 = v_u_210
			end
			local v_u_212 = not (v211 and v211:IsA("BasePart")) and 3 or v211.Position.Y - v_u_209.Y
			local v213 = p_u_202.X - p_u_201.X
			local v214 = p_u_202.Z - p_u_201.Z
			local v_u_215 = Vector3.new(v213, 0, v214).Magnitude
			local v_u_216 = {}
			for v_u_217 = 1, v_u_208 do
				p_u_85.after((v_u_217 - 1) * 0.05, function()
					-- upvalues: (copy) v_u_215, (copy) v_u_217, (copy) v_u_208, (copy) v_u_209, (copy) v_u_207, (copy) v_u_212, (ref) v_u_191, (copy) v_u_210, (copy) v_u_216, (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1, (ref) v_u_129, (copy) p_u_200, (ref) p_u_85, (ref) v_u_8, (ref) v_u_6
					local v218 = v_u_209 + v_u_207 * (v_u_215 * (v_u_217 - 0.4) / v_u_208) + Vector3.new(0, 1, 0) * v_u_212
					local v219 = v_u_217 % 2 == 0 and 0.35 or -0.35
					local v220 = CFrame.lookAt(v218, v218 + v_u_207) * CFrame.Angles(-0.3, v219, 0)
					local v221 = v_u_191(v_u_210, v220, 1.4)
					local v222 = v_u_216
					table.insert(v222, v221)
					local v223 = v218 + Vector3.new(0, 0.6, 0)
					local v224 = v_u_15
					local v225 = Instance.new("Attachment")
					v225.WorldPosition = v223
					v225.Parent = v_u_4.Terrain
					local v226 = v_u_21(v224, 9)
					v226.Parent = v225
					v226:Emit(1)
					v_u_1:AddItem(v225, v224.life * 1.3 + 0.2)
					local v227 = (v220.RightVector + Vector3.new(0, 1, 0) * (v_u_217 % 2 == 0 and 0.7 or -0.7)).Unit
					v_u_129(v223 - v227 * 4, v223 + v227 * 4, 0.2, 0.25)
					if not p_u_200.lite then
						p_u_85.pop(v223, v_u_8, 3, 0.5, 0.14)
					end
					v_u_6.play("Hit", {
						["at"] = nil,
						["volume"] = 0.35,
						["at"] = v223
					})
				end)
			end
			local v228 = (v_u_208 - 1) * 0.05 + 0.12
			p_u_85.after(v228, function()
				-- upvalues: (copy) v_u_209, (copy) v_u_212, (copy) v_u_207, (copy) v_u_215, (ref) v_u_129, (ref) p_u_85, (copy) p_u_201, (copy) p_u_202, (ref) v_u_8, (copy) p_u_200, (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1, (ref) v_u_6, (ref) v_u_5
				local v229 = v_u_209 + Vector3.new(0, 1, 0) * (v_u_212 + 0.5)
				local v230 = v229 + v_u_207 * v_u_215
				v_u_129(v229, v230, 0.35, 0.45)
				p_u_85.groundLine(p_u_201, p_u_202, 1.6, v_u_8, 0.8, 0.2)
				if not p_u_200.lite then
					p_u_85.alongPath(v229, v230, 10, 0.12, function(p231)
						-- upvalues: (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1
						local v232 = v_u_15
						local v233 = Instance.new("Attachment")
						v233.WorldPosition = p231
						v233.Parent = v_u_4.Terrain
						local v234 = v_u_21(v232, 6)
						v234.Parent = v233
						v234:Emit(1)
						v_u_1:AddItem(v233, v232.life * 1.3 + 0.2)
					end)
				end
				v_u_6.play("Crit", {
					["at"] = nil,
					["volume"] = 0.6,
					["at"] = (v229 + v230) / 2
				})
				if p_u_200.mine then
					v_u_5.shake(0.3, 0.2)
				end
			end)
			p_u_85.after(v228 + 0.4, function()
				-- upvalues: (copy) v_u_216, (ref) v_u_198, (copy) p_u_200
				for _, v235 in v_u_216 do
					v_u_198(v235, p_u_200.lite)
				end
			end)
		end,
		["hit"] = function(_, p236, _) -- name: hit
			-- upvalues: (copy) p_u_85, (ref) v_u_8, (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1
			p_u_85.burst("Impact", p236, v_u_8, 0.6)
			local v237 = v_u_15
			local v238 = Instance.new("Attachment")
			v238.WorldPosition = p236
			v238.Parent = v_u_4.Terrain
			local v239 = v_u_21(v237, 4)
			v239.Parent = v238
			v239:Emit(1)
			v_u_1:AddItem(v238, v237.life * 1.3 + 0.2)
		end
	}
	local v_u_240 = {}
	setmetatable(v_u_240, {
		["__mode"] = "k"
	})
	local function v_u_248(p241, p242, p243, p244, p245) -- name: darkFire
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_21, (ref) v_u_16
		local v246 = v_u_5.part(Vector3.new(p242, 0.6, p242), CFrame.new(p241), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v246, p245 + 1.2)
		local v_u_247 = v_u_21(v_u_16, p243)
		v_u_247.Shape = Enum.ParticleEmitterShape.Box
		v_u_247.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v_u_247.Speed = NumberRange.new(5, 9)
		v_u_247.Rate = p244
		v_u_247.Enabled = true
		v_u_247.Parent = v246
		task.delay(p245, function()
			-- upvalues: (copy) v_u_247
			v_u_247.Enabled = false
		end)
		return v_u_247
	end
	v86.getsuga_tensho_r = {
		["cast"] = function(p249) -- name: cast
			-- upvalues: (copy) p_u_85, (ref) v_u_8, (ref) v_u_36, (ref) v_u_16, (ref) v_u_76
			p_u_85.skillCast(p249, v_u_8, true)
			v_u_36(v_u_16, p249.feet + Vector3.new(0, 1, 0), p249.lite and 4 or 10, 6)
			if p249.mine then
				v_u_76(Color3.fromRGB(255, 190, 190), -0.1, 0.25, -0.35, 0.15, 1.1, 0.5)
			end
		end,
		["windup"] = function(p_u_250, p251, p252) -- name: windup
			-- upvalues: (ref) v_u_65, (copy) v_u_248, (copy) v_u_240, (copy) p_u_85, (ref) v_u_8, (ref) v_u_29
			local v253 = p252 + 1
			local v254 = p_u_250.dir
			local v255 = v254.X
			local v256 = v254.Z
			local v257 = Vector3.new(v255, 0, v256)
			local v_u_258 = v257.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v257.Unit
			local v_u_259 = v_u_65(16, v253)
			local v_u_260 = {
				["sword"] = v_u_259,
				["flames"] = v_u_248(p_u_250.feet + Vector3.new(0, 0.5, 0), 4, 5.5, p_u_250.lite and 8 or 22, p252 + 0.35),
				["born"] = os.clock()
			}
			v_u_240[p_u_250] = v_u_260
			local v_u_261 = math.max(p252, 0.08)
			if not p_u_250.lite then
				p_u_85.inward(p251 + Vector3.new(0, 4, 0), v_u_8, 8, 14, v_u_261 + 0.05)
			end
			p_u_85.runNow(function()
				-- upvalues: (copy) v_u_260, (copy) v_u_259, (copy) v_u_261, (copy) v_u_258, (copy) p_u_250, (ref) v_u_29
				local v262 = os.clock() - v_u_260.born
				if not v_u_259.Parent or v_u_260.sword ~= v_u_259 then
					return false
				end
				local v263 = v262 / v_u_261
				local v264 = math.clamp(v263, 0, 1)
				local v265 = v264 * v264 * (3 - v264 * 2)
				local v266 = (Vector3.new(0, 0.8, 0) - v_u_258 * 0.6 * v265).Unit
				v_u_259.CFrame = v_u_29(p_u_250.feet + Vector3.new(0, 1, 0) * (v265 * 4 + 5) + v266 * 16 * 0.5, v266, -v_u_258 + Vector3.new(0, 0.3, 0))
				return v262 < v_u_261 + 0.3
			end)
		end,
		["beam"] = function(p_u_267, p268, p269) -- name: beam
			-- upvalues: (copy) p_u_85, (copy) v_u_240, (ref) v_u_29, (ref) v_u_5, (ref) v_u_1, (ref) v_u_48, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_21, (ref) v_u_16, (ref) v_u_82, (ref) v_u_14, (ref) v_u_13, (ref) v_u_36, (ref) v_u_15, (copy) v_u_129, (ref) v_u_6
			local v270 = p269 - p268
			local v271 = v270.X
			local v272 = v270.Z
			local v273 = Vector3.new(v271, 0, v272)
			local v_u_274 = v273.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v273.Unit
			local v_u_275 = p_u_85.ground(p268, 0)
			local v276 = p269.X - p268.X
			local v277 = p269.Z - p268.Z
			local v_u_278 = Vector3.new(v276, 0, v277).Magnitude
			local v_u_279 = v_u_274:Cross(Vector3.new(0, 1, 0))
			local v280 = v_u_240[p_u_267]
			v_u_240[p_u_267] = nil
			if v280 then
				local v_u_281 = v280.sword
				local v_u_282 = p_u_267.feet + Vector3.new(0, 9, 0)
				p_u_85.animate(0.14, 0, function(p283)
					-- upvalues: (copy) v_u_281, (copy) v_u_274, (ref) v_u_29, (copy) v_u_282, (ref) v_u_5, (ref) v_u_1
					if v_u_281.Parent then
						local v284 = (1 - p283) * 1.1 - 0.35
						local v285 = Vector3.new(0, 1, 0) * math.cos(v284)
						local v286 = v_u_274
						local v287 = v284 + 1.2
						local v288 = (v285 + v286 * math.sin(v287)).Unit
						v_u_281.CFrame = v_u_29(v_u_282 + v288 * 16 * 0.5, v288, -v_u_274 + Vector3.new(0, 0.3, 0))
						if p283 >= 1 then
							v_u_5.tween(v_u_281, 0.3, {
								["Transparency"] = 1
							})
							v_u_1:AddItem(v_u_281, 0.35)
						end
					end
				end)
			end
			local v_u_289 = {}
			local v_u_290 = { 0, 0.5, -0.5 }
			for v291 = 1, p_u_267.lite and 1 or 3 do
				local v292 = v_u_48(CFrame.new(v_u_275), (1 - (v291 - 1) * 0.12) * 13, v_u_7.GetsugaBrush, v_u_8, 0)
				v_u_1:AddItem(v292, 0.9)
				v_u_289[v291] = v292
			end
			local v_u_293 = v_u_48(CFrame.new(v_u_275), 22.099999999999998, v_u_7.Glow, v_u_8, 0.2)
			v_u_1:AddItem(v_u_293, 0.9)
			local v_u_294 = v_u_5.part(Vector3.new(10, 1, 3), CFrame.new(v_u_275), v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_294, 2.4)
			local v_u_295 = v_u_21(v_u_16, 8)
			v_u_295.Lifetime = NumberRange.new(0.9, 1.3)
			v_u_295.Speed = NumberRange.new(3, 6)
			v_u_295.Shape = Enum.ParticleEmitterShape.Box
			v_u_295.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_295.Rate = p_u_267.lite and 25 or 70
			v_u_295.Enabled = true
			v_u_295.Parent = v_u_294
			local v_u_296 = 0
			p_u_85.animate(0.4, 0, function(p297)
				-- upvalues: (copy) v_u_278, (copy) v_u_275, (copy) v_u_274, (copy) v_u_289, (ref) v_u_82, (copy) v_u_290, (ref) v_u_14, (copy) v_u_293, (copy) v_u_294, (ref) v_u_296, (ref) p_u_85, (ref) v_u_8, (ref) v_u_7, (copy) v_u_295, (ref) v_u_9, (ref) v_u_13, (ref) v_u_5, (ref) v_u_36, (ref) v_u_16, (copy) p_u_267, (ref) v_u_15
				local v298 = v_u_278 * p297
				local v299 = v_u_275 + v_u_274 * v298 + Vector3.new(0, 9.75, 0)
				for v300, v301 in v_u_289 do
					v301.CFrame = v_u_82(v299 - v_u_274 * (v300 - 1) * 1.5, v_u_274, Vector3.new(0, 1, 0)) * CFrame.Angles(0, v_u_290[v300], 0) * v_u_14
					local v302 = (1 - (v300 - 1) * 0.12) * 13
					local v303 = p297 * 4
					local v304 = v302 * (math.min(v303, 1) * 0.3 + 0.7)
					local v305 = math.max(v304, 0.03) * 2
					v301.Size = Vector3.new(v305, 0.05, v305)
				end
				v_u_293.CFrame = v_u_82(v299 - v_u_274 * 2, v_u_274, Vector3.new(0, 1, 0))
				v_u_294.CFrame = CFrame.lookAt(v_u_275 + v_u_274 * v298 + Vector3.new(0, 0.6, 0), v_u_275 + v_u_274 * (v298 + 1))
				if v298 - v_u_296 >= 12 then
					v_u_296 = v298
					p_u_85.mark(v_u_275 + v_u_274 * v298, v_u_8, 6, 2.2, v_u_7.CrackGlow, 0.25)
				end
				if p297 >= 1 then
					for _, v306 in v_u_289 do
						v306:Destroy()
					end
					v_u_293:Destroy()
					v_u_295.Enabled = false
					local v307 = v_u_275 + v_u_274 * v_u_278 + Vector3.new(0, 4, 0)
					p_u_85.pop(v307, v_u_9, 4, 26, 0.45, 0, v_u_13)
					v_u_5.ring(p_u_85.ground(v307), v_u_8, 16, 0.5, v_u_7.Shockwave)
					v_u_36(v_u_16, v307 - Vector3.new(0, 3, 0), p_u_267.lite and 4 or 12, 8)
					v_u_36(v_u_15, v307, p_u_267.lite and 1 or 4, 9)
				end
			end)
			p_u_85.groundLine(p268, p269, 12, v_u_9, 1.6, 0.15)
			p_u_85.after(0.5, function()
				-- upvalues: (copy) v_u_275, (copy) v_u_274, (copy) v_u_278, (ref) v_u_129, (copy) p_u_267, (copy) v_u_279, (ref) v_u_6
				local v308 = v_u_275 + Vector3.new(0, 3, 0)
				local v309 = v308 + v_u_274 * v_u_278
				v_u_129(v308, v309, 0.55, 0.55)
				if not p_u_267.lite then
					for v310 = 1, 5 do
						local v311 = v308:Lerp(v309, (v310 - 0.5) / 5) + Vector3.new(0, 1, 0) * (math.random() * 4)
						local v312 = (v_u_279 + Vector3.new(0, 1, 0) * (math.random() - 0.5) * 1.6).Unit
						v_u_129(v311 - v312 * 7, v311 + v312 * 7, 0.3, 0.35)
					end
				end
				v_u_6.play("Explosion", {
					["at"] = nil,
					["volume"] = 0.9,
					["at"] = (v308 + v309) / 2
				})
			end)
			p_u_85.burst("Shockwave", v_u_275 + Vector3.new(0, 0.3, 0), v_u_8, 0.8)
			v_u_6.play("Laser", {
				["at"] = nil,
				["volume"] = 0.8,
				["at"] = v_u_275
			})
			if p_u_267.mine then
				v_u_5.shake(0.6, 0.55)
			end
		end,
		["hit"] = function(_, p313, _) -- name: hit
			-- upvalues: (copy) p_u_85, (ref) v_u_8, (ref) v_u_15, (ref) v_u_4, (ref) v_u_21, (ref) v_u_1
			p_u_85.burst("Impact", p313, v_u_8, 0.7)
			local v314 = v_u_15
			local v315 = Instance.new("Attachment")
			v315.WorldPosition = p313
			v315.Parent = v_u_4.Terrain
			local v316 = v_u_21(v314, 5)
			v316.Parent = v315
			v316:Emit(1)
			v_u_1:AddItem(v315, v314.life * 1.3 + 0.2)
		end
	}
	return v86
end