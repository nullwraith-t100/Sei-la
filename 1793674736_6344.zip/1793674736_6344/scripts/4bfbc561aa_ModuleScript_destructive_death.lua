local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromHex("FF9A1F")
local v_u_9 = Color3.fromRGB(10, 34, 72)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.PartType.Wedge
local v_u_12 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_20(p13) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v14 = v_u_2:FindFirstChild("EyePieces")
	if v14 then
		v14 = v14:FindFirstChild("w8_destructive_death")
	end
	if not (v14 and v14:IsA("MeshPart")) then
		return nil
	end
	local v15 = v14:Clone()
	local v16 = v14.Size
	local v17 = v16.X
	local v18 = v16.Y
	local v19 = v16.Z
	v15.Size = v16 * (p13 / math.max(v17, v18, v19, 0.01))
	v15.Anchored = true
	v15.CanCollide = false
	v15.CanQuery = false
	v15.CanTouch = false
	v15.Massless = true
	v15.CastShadow = false
	v15.Parent = v_u_4.folder()
	return v15
end
return function(p_u_21)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_1, (copy) v_u_20, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_5
	return {
		["w8_destructive_death"] = function(p_u_22, p23)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) p_u_21, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (ref) v_u_20, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5
			local v_u_24 = v_u_4.color(p23.color)
			local v25 = p_u_22.headY / 1.5
			local v_u_26 = math.clamp(v25, 0.7, 3)
			local v_u_27 = Instance.new("Attachment")
			v_u_27.Parent = v_u_3.Terrain
			p_u_21.own(p_u_22, v_u_27)
			local v_u_28 = Instance.new("ParticleEmitter")
			v_u_28.Enabled = false
			v_u_28.Texture = v_u_6.AkazaStar
			v_u_28.Color = ColorSequence.new(v_u_7)
			v_u_28.LightEmission = 0.15
			v_u_28.LightInfluence = 0
			v_u_28.Speed = NumberRange.new(0)
			v_u_28.Lifetime = NumberRange.new(0.24)
			v_u_28.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_26 * 0.3 * p_u_22.fx), NumberSequenceKeypoint.new(0.3, v_u_26 * 1.1 * p_u_22.fx), NumberSequenceKeypoint.new(1, v_u_26 * 1.3 * p_u_22.fx) })
			v_u_28.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.1), NumberSequenceKeypoint.new(1, 1) })
			v_u_28.Rotation = NumberRange.new(0, 360)
			v_u_28.RotSpeed = NumberRange.new(-120, 120)
			v_u_28.Parent = v_u_27
			local v29 = p_u_22.stops
			local function v30()
				-- upvalues: (ref) v_u_1, (copy) v_u_27
				v_u_1:AddItem(v_u_27, 0.5)
			end
			table.insert(v29, v30)
			local v_u_31 = -100
			local v_u_32 = true
			p_u_21.throb(p_u_22, 5.5, 2.2, 1, function()
				-- upvalues: (ref) v_u_31, (ref) v_u_32
				v_u_31 = os.clock()
				v_u_32 = false
			end)
			local v33 = p_u_21.bar(Vector3.new(0.2, 0.2, 0.2), v_u_7, 1)
			p_u_21.add(p_u_22, v33, function(p34)
				-- upvalues: (ref) p_u_21, (copy) p_u_22
				return CFrame.new(p_u_21.feetAt(p_u_22, p34, 0.1))
			end)
			local v_u_35 = Instance.new("ParticleEmitter")
			v_u_35.Texture = v_u_6.AkazaCompass
			v_u_35.Color = ColorSequence.new(v_u_24)
			v_u_35.LightEmission = 0.35
			v_u_35.LightInfluence = 0
			v_u_35.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_35.EmissionDirection = Enum.NormalId.Top
			v_u_35.SpreadAngle = Vector2.zero
			v_u_35.Speed = NumberRange.new(0.01)
			v_u_35.LockedToPart = true
			v_u_35.Lifetime = NumberRange.new(8)
			v_u_35.Size = NumberSequence.new(v_u_26 * 3.2 * p_u_22.fx)
			v_u_35.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.05, 0.12),
				NumberSequenceKeypoint.new(0.95, 0.12),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_35.Rotation = NumberRange.new(0, 0)
			v_u_35.RotSpeed = NumberRange.new(7.5, 7.5)
			v_u_35.Rate = 0.125
			v_u_35.Parent = v33
			v_u_35:Emit(1)
			local v36 = p_u_22.stops
			table.insert(v36, function()
				-- upvalues: (copy) v_u_35
				v_u_35.Enabled = false
			end)
			local v37 = v_u_20(v_u_26 * 4.4)
			if v37 then
				p_u_21.add(p_u_22, v37, function(p38, p39)
					-- upvalues: (ref) p_u_21, (copy) p_u_22, (ref) v_u_12
					return CFrame.new(p_u_21.feetAt(p_u_22, p38, 0.2)) * CFrame.Angles(0, -p39 * 0.25, 0) * v_u_12
				end)
			end
			local function v_u_56(p40, p41) -- name: needleTurn
				-- upvalues: (ref) v_u_31, (ref) p_u_21, (copy) p_u_22
				local v42 = os.clock() - v_u_31
				local v43 = p41 * 1.7
				local v44 = math.sin(v43) * 0.3
				local v45 = p41 * 3.1
				local v46 = v44 + math.sin(v45) * 0.12
				if v42 >= 0 and v42 < 1 then
					local v47 = v42 / 0.5
					local v48 = math.clamp(v47, 0, 1)
					local v49 = v48 * v48 * (3 - v48 * 2) * 3.141592653589793 * 4
					local v50 = (v42 - 0.5) / 0.5
					local v51 = math.clamp(v50, 0, 1)
					v46 = v49 + v46 * (v51 * v51 * (3 - v51 * 2))
				end
				local v52 = p40.LookVector
				local v53 = -v52.X
				local v54 = -v52.Z
				local v55 = math.atan2(v53, v54)
				return CFrame.new(p_u_21.feetAt(p_u_22, p40, 0.32)) * CFrame.Angles(0, v55 + v46, 0)
			end
			local v_u_57 = v_u_26 * 0.22
			local v_u_58 = v_u_32
			local v_u_59 = v_u_31
			for _, v_u_60 in { 1, -1 } do
				for _, v_u_61 in { 1, -1 } do
					local v62 = p_u_21.bar
					local v63 = v_u_26 * 0.1
					local v64 = v_u_26 * 1.05
					local v65 = Vector3.new(v63, v_u_57, v64)
					local v66
					if v_u_60 > 0 then
						v66 = v_u_8
					else
						v66 = v_u_9
					end
					local v67 = 0
					local v68
					if v_u_60 > 0 then
						v68 = nil
					else
						v68 = v_u_10
					end
					local v69 = v62(v65, v66, v67, v68)
					v69.Shape = v_u_11
					p_u_21.add(p_u_22, v69, function(p70, p71)
						-- upvalues: (copy) v_u_56, (copy) v_u_60, (copy) v_u_26, (copy) v_u_61, (copy) v_u_57
						return v_u_56(p70, p71) * CFrame.Angles(0, v_u_60 > 0 and 0 or 3.141592653589793, 0) * CFrame.new(0, 0, v_u_26 * -0.52) * CFrame.Angles(0, 0, v_u_61 * 3.141592653589793 / 2) * CFrame.new(0, v_u_57 / 2, 0)
					end)
				end
			end
			local v_u_72 = {}
			for _, v73 in {
				"LeftLowerArm",
				"RightLowerArm",
				"Left Arm",
				"Right Arm"
			} do
				local v_u_74 = p_u_22.character:FindFirstChild(v73)
				if not (v_u_74 and v_u_74:IsA("BasePart")) then
					continue
				end
				local v75 = string.find(v73, " ") ~= nil
				local v76 = v_u_74.Size.X / 2 + v_u_26 * 0.06
				local v77 = v_u_74.Size.Z / 2 + v_u_26 * 0.06
				for v78, v79 in v75 and { -0.45, -0.75 } or { 0.05, -0.22 } do
					local v80 = v78 == 1
					for v81 = 0, 3 do
						local v82 = v81 % 2 == 0
						local v_u_83
						if v81 == 0 then
							v_u_83 = CFrame.new(0, v79, -v77)
						elseif v81 == 1 then
							v_u_83 = CFrame.new(v76, v79, 0)
						elseif v81 == 2 then
							v_u_83 = CFrame.new(0, v79, v77)
						else
							v_u_83 = CFrame.new(-v76, v79, 0)
						end
						local v84
						if v82 then
							local v85 = v76 * 2 + v_u_26 * 0.1
							local v86 = v_u_26 * 0.11
							local v87 = v_u_26 * 0.1
							v84 = Vector3.new(v85, v86, v87)
						else
							local v88 = v_u_26 * 0.1
							local v89 = v_u_26 * 0.11
							local v90 = v77 * 2 + v_u_26 * 0.1
							v84 = Vector3.new(v88, v89, v90)
						end
						local v91 = p_u_21.bar
						local v92
						if v80 then
							v92 = v_u_24
						else
							v92 = v_u_9
						end
						local v93 = 0
						local v94
						if v80 then
							v94 = nil
						else
							v94 = v_u_10
						end
						local v95 = v91(v84, v92, v93, v94)
						p_u_21.add(p_u_22, v95, function(p96)
							-- upvalues: (copy) v_u_74, (copy) v_u_83
							if v_u_74.Parent then
								return v_u_74.CFrame * v_u_83
							else
								return p96
							end
						end)
						table.insert(v_u_72, {
							["part"] = v95,
							["lit"] = v80
						})
					end
				end
			end
			local v_u_97 = 1.2
			local v_u_98 = 1
			local v99 = p_u_22.ticks
			local function v111(p100, p101)
				-- upvalues: (ref) p_u_21, (ref) v_u_97, (ref) v_u_98, (ref) v_u_5, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28, (ref) v_u_59, (copy) v_u_72, (copy) v_u_24, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_58, (copy) p_u_22, (ref) v_u_4, (ref) v_u_6
				local v102 = (p100.Position - p_u_21.camPos()).Magnitude < 120
				if v_u_97 <= p101 then
					v_u_97 = p101 + 0.8 + math.random() * 0.6
					v_u_98 = -v_u_98
					if v102 and v_u_5.level() >= 2 then
						v_u_27.WorldPosition = (p100 * CFrame.new(v_u_98 * 0.7 * v_u_26, v_u_26 * 0.5, v_u_26 * -2.2)).Position
						v_u_28:Emit(1)
					end
				end
				local v103 = os.clock() - v_u_59
				local v104 = (v103 < 0.5 or v103 >= 1.1) and 0 or 1 - (v103 - 0.5) / 0.6
				for _, v105 in v_u_72 do
					if v105.lit then
						v105.part.Color = v_u_24:Lerp(v_u_7, v104)
					else
						v105.part.Color = v_u_9:Lerp(v_u_8, v104)
					end
				end
				if not v_u_58 and v103 >= 0.5 then
					v_u_58 = true
					if v102 then
						for v106 = 1, 6 do
							local v_u_107 = v106 / 6 * 3.141592653589793 * 2
							task.delay(v106 * 0.04, function()
								-- upvalues: (ref) p_u_22, (copy) v_u_107, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28
								if not p_u_22.stopped then
									local v108 = v_u_107
									local v109 = v_u_107
									v_u_27.WorldPosition = (p_u_22.root.CFrame * CFrame.new(math.cos(v108) * 2.2 * v_u_26, v_u_26 * 0.4, math.sin(v109) * 2.2 * v_u_26)).Position
									v_u_28:Emit(1)
								end
							end)
						end
						local v110 = p_u_21.feetAt(p_u_22, p100, 0.15)
						v_u_4.ring(v110, v_u_9, 5 * p_u_22.fx, 0.45, v_u_6.Ring)
						v_u_4.ring(v110, v_u_24, 7.5 * p_u_22.fx, 0.6, v_u_6.AkazaCompass)
					end
				end
			end
			table.insert(v99, v111)
			p_u_21.particles(p_u_22, "AuraMode", v_u_24, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end