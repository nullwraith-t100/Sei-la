local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(script.Parent.Menus)
local v_u_6 = require(script.Parent.OfferLog)
local v_u_7 = require(script.Parent.Sfx)
local v_u_8 = require(script.Parent.State)
local v_u_9 = require(script.Parent.Store)
local v_u_10 = require(script.Parent.Fx.Kit)
local v11 = v_u_2.Shared
local v_u_12 = require(v11.Config.Images)
local v_u_13 = require(v11.Config.Products)
local v_u_14 = require(v11.Logic.Format)
local v15 = {}
local v_u_16 = v1.LocalPlayer
local v_u_17 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local function v21(p18, p19, p20) -- name: rgb
	return Color3.fromRGB(p18, p19, p20)
end
local v_u_22 = { Color3.fromRGB(255, 246, 150), Color3.fromRGB(255, 196, 30), v21(255, 140, 0) }
local v_u_23 = { Color3.fromRGB(58, 255, 14), v21(40, 196, 14) }
local function v_u_32(p24, p25) -- name: rainbow
	local v26 = {}
	for v27 = 0, 6 do
		local v28 = (v27 / 6 * 0.85 + p24) % 1
		local v29 = ColorSequenceKeypoint.new
		local v30 = v27 / 6
		local v31 = Color3.fromHSV
		table.insert(v26, v29(v30, v31(v28, p25, 1)))
	end
	return ColorSequence.new(v26)
end
local function v_u_43(p33, p34, p35, p36, p37, p38, p39, p40) -- name: text
	-- upvalues: (copy) v_u_17
	local v41 = Instance.new("TextLabel")
	v41.Name = p34
	v41.BackgroundTransparency = 1
	v41.AnchorPoint = Vector2.new(0.5, 0.5)
	v41.Size = p36
	v41.Position = p37
	v41.FontFace = p40 or v_u_17
	v41.TextScaled = true
	v41.RichText = true
	v41.Text = p35
	v41.TextColor3 = p38
	v41.ZIndex = p39
	local v42 = Instance.new("UIStroke")
	v42.Thickness = 0.12
	v42.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v42.Color = Color3.new(0, 0, 0)
	v42.Parent = v41
	v41.Parent = p33
	return v41
end
local function v_u_52(p44, p45, p46, p47, p48, p49) -- name: image
	local v50 = Instance.new("ImageLabel")
	v50.Name = p45
	v50.BackgroundTransparency = 1
	v50.Image = p46
	v50.ScaleType = Enum.ScaleType.Fit
	v50.AnchorPoint = Vector2.new(0.5, 0.5)
	v50.Size = UDim2.fromScale(p47, p47)
	v50.Position = p48
	v50.ZIndex = p49
	local v51 = Instance.new("UIAspectRatioConstraint")
	v51.DominantAxis = Enum.DominantAxis.Height
	v51.Parent = v50
	v50.Parent = p44
	return v50
end
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = 0
local v_u_56 = 0
local v_u_57 = false
local v_u_58 = false
local function v_u_59(_) end
local function v_u_60() end
local function v_u_61() end
local v_u_62 = {
	"Top",
	"MainDescription",
	"Gained",
	"Levels",
	"Redeem"
}
local function v_u_94(p63) -- name: build
	-- upvalues: (ref) v_u_54, (copy) v_u_62, (copy) v_u_43, (copy) v_u_52, (copy) v_u_12, (copy) v_u_22, (copy) v_u_32, (copy) v_u_13, (copy) v_u_23, (ref) v_u_60, (ref) v_u_61
	if v_u_54 then
		return v_u_54
	end
	local v_u_64 = p63:FindFirstChild("Redeem")
	if not (v_u_64 and v_u_64:IsA("GuiButton")) then
		return nil
	end
	for _, v65 in v_u_62 do
		local v66 = p63:FindFirstChild(v65)
		if not (v66 and v66:IsA("GuiObject")) then
			continue
		end
		v66.Visible = false
	end
	local v67 = p63:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v67 then
		local v68 = v67.AspectRatio
		v67.AspectRatio = 1.3
		p63.Size = UDim2.new(p63.Size.X.Scale * 1.3 / v68, p63.Size.X.Offset, p63.Size.Y.Scale, p63.Size.Y.Offset)
	end
	local v_u_69 = Instance.new("Frame")
	v_u_69.Name = "WelcomeLook"
	v_u_69.BackgroundTransparency = 1
	v_u_69.Size = UDim2.fromScale(1, 1)
	v_u_69.ZIndex = 3
	v_u_69.Parent = p63
	local v70 = p63:FindFirstChild("Top")
	if v70 then
		v70 = v70:FindFirstChild("MainText")
	end
	local v71
	if v70 and v70:IsA("TextLabel") then
		v71 = v70.FontFace
	else
		v71 = nil
	end
	v_u_43(v_u_69, "Title", "Welcome Back!", UDim2.fromScale(0.68, 0.16), UDim2.fromScale(0.6, 0.02), Color3.new(1, 1, 1), 8, v71)
	local v72 = v_u_52(v_u_69, "Clock", "rbxassetid://75181037261221", 0.24, UDim2.fromScale(0.11, 0.03), 9)
	v72.Rotation = -10
	v_u_52(v72, "Flame", v_u_12.Icon.Chakra, 0.62, UDim2.fromScale(0.86, 0.78), 10)
	local v73 = v_u_43(v_u_69, "Sub", "You trained while you were offline:", UDim2.fromScale(0.9, 0.075), UDim2.fromScale(0.5, 0.165), Color3.new(1, 1, 1), 6)
	local v74 = v_u_52(v_u_69, "Rays", "rbxassetid://96427887277553", 0.6, UDim2.fromScale(0.5, 0.43), 4)
	v74.ImageColor3 = Color3.fromRGB(255, 236, 170)
	v74.ImageTransparency = 0.15
	local v75 = v_u_52(v_u_69, "Icon", v_u_12.Icon.Chakra, 0.34, UDim2.fromScale(0.5, 0.43), 5)
	local v76 = v_u_43(v_u_69, "Amount", "+0 CHAKRA", UDim2.fromScale(0.9, 0.12), UDim2.fromScale(0.5, 0.67), Color3.new(1, 1, 1), 6)
	local v77 = Instance.new("UIGradient")
	v77.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_22[1]), ColorSequenceKeypoint.new(0.5, v_u_22[2]), ColorSequenceKeypoint.new(1, v_u_22[3]) })
	v77.Rotation = 90
	v77.Parent = v76
	local function v81(p78) -- name: button
		-- upvalues: (copy) v_u_64, (copy) v_u_69
		local v79 = v_u_64:Clone()
		v79.Name = p78
		v79.Visible = true
		v79.AnchorPoint = Vector2.new(0.5, 0.5)
		v79.ZIndex = 6
		for _, v80 in { "Ui-Frame", "Ui-Close" } do
			v79:SetAttribute(v80, nil)
		end
		v79.Parent = v_u_69
		return v79
	end
	local v82 = v81("X5")
	v82.Position = UDim2.fromScale(0.34, 0.86)
	v82.Size = UDim2.fromScale(0.48, 0.17)
	local v83 = v82:FindFirstChildOfClass("UIGradient")
	if v83 then
		v83.Rotation = -20
		v83.Color = v_u_32(0, 0.75)
	end
	local v84 = v_u_43(v82, "Price", "", UDim2.fromScale(0.36, 0.42), UDim2.fromScale(0.88, 0.02), Color3.new(1, 1, 1), 9)
	local v85 = v_u_43
	local v86 = v_u_13.productByKey.offlineX5
	v85(v82, "Mark", "x" .. (v86 and (v86.mult or 5) or 5), UDim2.fromScale(0.26, 0.5), UDim2.fromScale(0.06, 0.04), v_u_22[2], 9).Rotation = -14
	local v_u_87 = v81("Claim")
	v_u_87.Position = UDim2.fromScale(0.8, 0.86)
	v_u_87.Size = UDim2.fromScale(0.3, 0.17)
	local v88 = v_u_23
	local v89 = v_u_87:FindFirstChildOfClass("UIGradient")
	if v89 then
		v89.Color = ColorSequence.new(v88[1], v88[2])
		v89.Rotation = 90
	end
	local v90 = v_u_87:FindFirstChild("TextLabel")
	if not (v90 and v90:IsA("TextLabel")) then
		v90 = nil
	end
	if v90 then
		v90.Text = "Claim!"
	end
	for _, v_u_91 in { v82, v_u_87 } do
		v_u_91.Activated:Connect(function()
			-- upvalues: (copy) v_u_91, (copy) v_u_87, (ref) v_u_60, (ref) v_u_61
			if v_u_91 == v_u_87 then
				v_u_60()
			else
				v_u_61()
			end
		end)
	end
	local v92 = {
		["root"] = v_u_69,
		["sub"] = v73,
		["amount"] = v76,
		["icon"] = v75,
		["rays"] = v74,
		["x5"] = v82
	}
	local v93 = v82:FindFirstChild("TextLabel")
	if not (v93 and v93:IsA("TextLabel")) then
		v93 = nil
	end
	v92.x5Text = v93
	v92.x5Paint = v83
	v92.price = v84
	v92.claim = v_u_87
	v92.claimText = v90
	v_u_54 = v92
	return v_u_54
end
local function v_u_108() -- name: refresh
	-- upvalues: (ref) v_u_53, (copy) v_u_8, (copy) v_u_94, (copy) v_u_62, (ref) v_u_57, (copy) v_u_9, (copy) v_u_3, (copy) v_u_16, (copy) v_u_14, (copy) v_u_13, (ref) v_u_54, (ref) v_u_55, (ref) v_u_56
	local v95 = v_u_53
	local v96 = v_u_8.offline()
	if v95 and (v96 and v96.chakra > 0) then
		local v97 = v_u_94(v95)
		if v97 then
			for _, v98 in v_u_62 do
				local v99 = v95:FindFirstChild(v98)
				if not (v99 and v99:IsA("GuiObject")) then
					continue
				end
				v99.Visible = false
			end
			if not v_u_57 then
				local v100
				if v_u_8.number("OfflineX5") > 0 then
					local v101 = v_u_9.product("offlineX5")
					v100 = ((not v101 or v101.id == 0) and true or false) and v_u_3:IsStudio()
					if v100 then
						v100 = v_u_16:GetAttribute("DevX5") == true
					end
				else
					v100 = false
				end
				v97.sub.Text = ("You trained while you were offline for %*:"):format((v_u_14.duration(v96.seconds)))
				local v102 = v96.chakra
				local v103 = v96.chakra
				local v104 = v_u_13.productByKey.offlineX5
				local v105 = v103 * (v104 and (v104.mult or 5) or 5)
				local v106 = v_u_54
				if v106 then
					v_u_55 = v102
					v_u_56 = v105
					v106.amount.Text = "+" .. v_u_14.short((math.max(v102, 0))) .. " CHAKRA"
					if v106.x5Text then
						v106.x5Text.Text = "+" .. v_u_14.short((math.max(v105, 0)))
					end
				end
				v97.x5.Visible = v100
				v97.x5.Active = v100
				v97.claim.Position = UDim2.fromScale(v100 and 0.8 or 0.5, 0.86)
				v97.claim.Size = UDim2.fromScale(v100 and 0.3 or 0.42, 0.17)
				if v97.claimText then
					v97.claimText.Text = "Claim!"
				end
				local v107 = v_u_9.product("offlineX5")
				v97.price.Text = ("<font color=\"#5CFF6A\">%*</font>%*"):format(v_u_9.ROBUX, not v107 and 0 or v107.price)
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_110() -- name: counter
	-- upvalues: (copy) v_u_16
	local v109 = v_u_16:FindFirstChildOfClass("PlayerGui")
	if v109 then
		v109 = v109:FindFirstChild("Main")
	end
	if v109 then
		v109 = v109:FindFirstChild("HUD")
	end
	if v109 then
		v109 = v109:FindFirstChild("Bottom")
	end
	if v109 then
		v109 = v109:FindFirstChild("Chakra")
	end
	if v109 and (v109:IsA("GuiObject") and v109.AbsoluteSize.X > 0) then
		return v109
	else
		return nil
	end
end
local function v_u_128(p111) -- name: fly
	-- upvalues: (ref) v_u_54, (copy) v_u_16, (copy) v_u_43, (copy) v_u_14, (copy) v_u_22, (copy) v_u_4, (copy) v_u_110, (copy) v_u_7
	local v112 = v_u_54
	local v113 = v_u_16:FindFirstChildOfClass("PlayerGui")
	if v113 then
		v113 = v113:FindFirstChild("Main")
	end
	if v112 and (v113 and v113:IsA("ScreenGui")) then
		local v114 = v112.icon.AbsolutePosition + v112.icon.AbsoluteSize / 2
		local v115 = v112.icon.AbsoluteSize.Y
		local v116 = math.max(v115, 40)
		local v_u_117 = v_u_43(v113, "WelcomeFly", "+" .. v_u_14.short(p111), UDim2.fromOffset(v116 * 2.4, v116 * 0.7), UDim2.fromOffset(v114.X, v114.Y), Color3.new(1, 1, 1), 60)
		local v118 = Instance.new("UIGradient")
		v118.Color = ColorSequence.new(v_u_22[1], v_u_22[3])
		v118.Rotation = 90
		v118.Parent = v_u_117
		local v_u_119 = Instance.new("UIScale")
		v_u_119.Scale = 0.5
		v_u_119.Parent = v_u_117
		local v120 = Enum.EasingStyle.Back
		v_u_4:Create(v_u_119, TweenInfo.new(0.3, v120 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1.3
		}):Play()
		task.delay(0.45, function()
			-- upvalues: (ref) v_u_110, (copy) v_u_117, (ref) v_u_4, (copy) v_u_119, (ref) v_u_7
			local v_u_121 = v_u_110()
			if v_u_121 then
				local v122 = v_u_121.AbsolutePosition + v_u_121.AbsoluteSize / 2
				local v123 = v_u_117
				local v124 = {
					["Position"] = UDim2.fromOffset(v122.X, v122.Y)
				}
				local v125 = Enum.EasingStyle.Quad
				v_u_4:Create(v123, TweenInfo.new(0.6, v125 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v124):Play()
				v_u_4:Create(v_u_119, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 0.45
				}):Play()
			end
			task.delay(0.62, function()
				-- upvalues: (ref) v_u_117, (copy) v_u_121, (ref) v_u_7, (ref) v_u_4
				v_u_117:Destroy()
				if v_u_121 then
					v_u_7.play("Gain", {
						["volume"] = 2.2,
						["pitch"] = 1.1
					})
					local v126 = v_u_121:FindFirstChild("PopLand")
					if not (v126 or v_u_121:FindFirstChildOfClass("UIScale")) then
						v126 = Instance.new("UIScale")
						v126.Name = "PopLand"
						v126.Parent = v_u_121
					end
					if v126 and v126:IsA("UIScale") then
						v126.Scale = 1.3
						local v127 = Enum.EasingStyle.Back
						v_u_4:Create(v126, TweenInfo.new(0.25, v127 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Scale"] = 1
						}):Play()
					end
				end
			end)
		end)
	end
end
local function v_u_145(p_u_129) -- name: countDownAndClose
	-- upvalues: (ref) v_u_54, (ref) v_u_57, (copy) v_u_16, (copy) v_u_8, (ref) v_u_55, (ref) v_u_56, (copy) v_u_3, (copy) v_u_14, (copy) v_u_7, (copy) v_u_128, (copy) v_u_10, (ref) v_u_53, (copy) v_u_5
	if v_u_54 then
		v_u_57 = true
		v_u_16:SetAttribute("OfflineClaimed", v_u_8.string("Offline"))
		local v_u_130 = v_u_55
		local v_u_131 = v_u_56
		local v_u_132 = os.clock()
		local v_u_133 = 0
		local v_u_134 = nil
		v_u_134 = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_132, (copy) v_u_130, (copy) v_u_131, (ref) v_u_54, (ref) v_u_55, (ref) v_u_56, (ref) v_u_14, (ref) v_u_133, (ref) v_u_7, (ref) v_u_134, (ref) v_u_128, (copy) p_u_129, (ref) v_u_16, (ref) v_u_10, (ref) v_u_53, (ref) v_u_5, (ref) v_u_57
			local v135 = (os.clock() - v_u_132) / 0.6
			local v136 = math.clamp(v135, 0, 1)
			local v137 = (1 - v136) ^ 2
			local v138 = v_u_130 * v137
			local v139 = v_u_131 * v137
			local v140 = v_u_54
			if v140 then
				v_u_55 = v138
				v_u_56 = v139
				v140.amount.Text = "+" .. v_u_14.short((math.max(v138, 0))) .. " CHAKRA"
				if v140.x5Text then
					v140.x5Text.Text = "+" .. v_u_14.short((math.max(v139, 0)))
				end
			end
			local v141 = v136 * 8
			local v142 = math.floor(v141)
			if v_u_133 < v142 then
				v_u_133 = v142
				v_u_7.play("Coin", {
					["volume"] = 0.7,
					["pitch"] = nil,
					["pitch"] = v142 * 0.06 + 1
				})
			end
			if v136 >= 1 then
				v_u_134:Disconnect()
				v_u_128(p_u_129)
				v_u_7.play("RevealBig", {
					["volume"] = 0.6
				})
				local v143 = v_u_16.Character
				if v143 then
					v143 = v_u_16.Character:FindFirstChild("HumanoidRootPart")
				end
				if v143 and v143:IsA("BasePart") then
					v_u_10.burst("Sparkle", v143.Position, nil, 1.5)
				end
				local v144 = v_u_53
				if v144 then
					v144 = v144:FindFirstChild("Open")
				end
				if v144 and v144:IsA("UIScale") then
					v144.Scale = 1.06
				end
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_5, (ref) v_u_57
					if v_u_5.current() == "Offline" then
						v_u_5.close()
					end
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_57
						v_u_57 = false
					end)
				end)
			end
		end)
	end
end
local function v_u_148() -- name: claimFree
	-- upvalues: (ref) v_u_54, (copy) v_u_8, (ref) v_u_57, (copy) v_u_145
	local v146 = v_u_54
	local v_u_147 = v_u_8.offline()
	if v146 and (not v_u_57 and v_u_147) then
		v_u_57 = true
		if v146.claimText then
			v146.claimText.Text = "Claiming..."
		end
		task.delay(0.35, function()
			-- upvalues: (ref) v_u_145, (copy) v_u_147
			v_u_145(v_u_147.chakra)
		end)
	end
end
local function v_u_156() -- name: buy
	-- upvalues: (ref) v_u_58, (ref) v_u_57, (copy) v_u_8, (copy) v_u_9, (copy) v_u_3, (copy) v_u_16, (copy) v_u_2, (ref) v_u_59, (copy) v_u_7
	if not (v_u_58 or v_u_57) then
		local v149
		if v_u_8.number("OfflineX5") > 0 then
			local v150 = v_u_9.product("offlineX5")
			v149 = ((not v150 or v150.id == 0) and true or false) and v_u_3:IsStudio()
			if v149 then
				v149 = v_u_16:GetAttribute("DevX5") == true
			end
		else
			v149 = false
		end
		if v149 then
			local v_u_151 = v_u_2:FindFirstChild("Remotes")
			if v_u_151 then
				v_u_151 = v_u_151:FindFirstChild("WelcomeBack")
			end
			if v_u_151 and v_u_151:IsA("RemoteFunction") then
				v_u_58 = true
				local v152, v153, v154, v155 = pcall(function()
					-- upvalues: (copy) v_u_151
					return v_u_151:InvokeServer("ask")
				end)
				v_u_58 = false
				if v152 and v153 == true then
					if type(v155) == "number" and v155 ~= 0 then
						v_u_9.promptProduct(v155, "WelcomeBack")
					else
						v_u_59("Studio: no product yet (DevRun buy offlineX5)")
					end
				else
					v_u_59((not v152 or type(v154) ~= "string") and "Try again" or v154)
					v_u_7.play("Error")
					return
				end
			else
				v_u_59("Try again in a moment")
				return
			end
		end
	end
end
local function v_u_165(p157) -- name: paid
	-- upvalues: (ref) v_u_54, (copy) v_u_8, (ref) v_u_53, (copy) v_u_5, (ref) v_u_57, (copy) v_u_145, (copy) v_u_13, (ref) v_u_59, (copy) v_u_14, (copy) v_u_7
	local v158 = v_u_54
	local v_u_159 = v_u_8.offline()
	if v158 and (v_u_53 and (v_u_53.Visible and (v_u_5.current() == "Offline" and (not v_u_57 and v_u_159)))) then
		v_u_57 = true
		if v158.x5Text then
			v158.x5Text.Text = "CLAIMED!"
		end
		task.delay(0.25, function()
			-- upvalues: (ref) v_u_145, (copy) v_u_159, (ref) v_u_13
			local v160 = v_u_145
			local v161 = v_u_159.chakra
			local v162 = v_u_13.productByKey.offlineX5
			v160(v161 * (v162 and (v162.mult or 5) or 5))
		end)
	else
		local v163 = v_u_59
		local v164 = v_u_13.productByKey.offlineX5
		v163((("Welcome Back x%*: +%* chakra!"):format(v164 and (v164.mult or 5) or 5, (v_u_14.short(p157)))))
		v_u_7.play("RevealBig", {
			["volume"] = 0.6
		})
	end
end
function v15.start(p166) -- name: start
	-- upvalues: (ref) v_u_59, (ref) v_u_60, (copy) v_u_148, (ref) v_u_61, (copy) v_u_156, (copy) v_u_16, (ref) v_u_53, (ref) v_u_54, (copy) v_u_32, (copy) v_u_3, (ref) v_u_57, (copy) v_u_108, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_165
	v_u_59 = p166
	v_u_60 = v_u_148
	v_u_61 = v_u_156
	local v_u_167 = v_u_16:WaitForChild("PlayerGui"):WaitForChild("Main"):WaitForChild("Frames"):WaitForChild("Offline", 20)
	if v_u_167 and v_u_167:IsA("Frame") then
		v_u_53 = v_u_167
		local v_u_168 = nil
		local function v_u_173() -- name: step
			-- upvalues: (ref) v_u_54, (ref) v_u_32
			local v169 = v_u_54
			if v169 then
				local v170 = os.clock()
				v169.rays.Rotation = v170 * 20 % 360
				local v171 = v170 * 3
				local v172 = math.sin(v171) * 0.05 + 1
				v169.icon.Size = UDim2.fromScale(v172 * 0.34, v172 * 0.34)
				if v169.x5Paint then
					v169.x5Paint.Color = v_u_32(v170 * 0.15 % 1, 0.75)
				end
			end
		end
		local function v_u_176()
			-- upvalues: (ref) v_u_53, (ref) v_u_54, (ref) v_u_168, (ref) v_u_3, (copy) v_u_173
			local v174 = v_u_53
			local v175 = v174 ~= nil and v174.Visible
			if v175 then
				v175 = v_u_54 ~= nil
			end
			if v175 and not v_u_168 then
				v_u_168 = v_u_3.RenderStepped:Connect(v_u_173)
			elseif not v175 and v_u_168 then
				v_u_168:Disconnect()
				v_u_168 = nil
			end
		end
		v_u_167:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_167, (ref) v_u_57, (ref) v_u_108, (copy) v_u_176, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3, (ref) v_u_16, (ref) v_u_6
			if v_u_167.Visible and not v_u_57 then
				v_u_108()
			end
			v_u_176()
			if v_u_167.Visible then
				task.defer(function()
					-- upvalues: (ref) v_u_167, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3, (ref) v_u_16, (ref) v_u_6
					if v_u_167.Visible then
						local v177
						if v_u_8.number("OfflineX5") > 0 then
							local v178 = v_u_9.product("offlineX5")
							v177 = ((not v178 or v178.id == 0) and true or false) and v_u_3:IsStudio()
							if v177 then
								v177 = v_u_16:GetAttribute("DevX5") == true
							end
						else
							v177 = false
						end
						if v177 then
							v_u_6.shown("WelcomeBack", "product", "offlineX5")
						end
					end
				end)
			end
		end)
		local function v179() -- name: later
			-- upvalues: (ref) v_u_108, (copy) v_u_176
			task.defer(function()
				-- upvalues: (ref) v_u_108, (ref) v_u_176
				v_u_108()
				v_u_176()
			end)
		end
		v_u_8.watch("Offline", v179)
		v_u_8.watch("OfflineX5", v179)
		v_u_16:GetAttributeChangedSignal("DevX5"):Connect(v179)
		v_u_9.pricesChanged:Connect(v179)
		v_u_8.watch("OfflineX5Paid", function()
			-- upvalues: (ref) v_u_8, (ref) v_u_165
			local v180 = v_u_8.number("OfflineX5Paid")
			if v180 > 0 then
				v_u_165(v180)
			end
		end)
		task.defer(function()
			-- upvalues: (ref) v_u_108, (copy) v_u_176
			v_u_108()
			v_u_176()
		end)
	end
end
return v15