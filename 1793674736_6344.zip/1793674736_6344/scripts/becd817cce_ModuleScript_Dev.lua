local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Fx.Abilities)
local v_u_5 = require(script.Parent.Fx.Modes)
local v_u_6 = require(script.Parent.Perf)
local v_u_7 = require(script.Parent.Store)
return {
	["start"] = function() -- name: start
		-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5
		if v_u_2:IsStudio() then
			local v_u_8 = v_u_1.LocalPlayer
			v_u_2:BindToRenderStep("DevCam", Enum.RenderPriority.Camera.Value + 2, function()
				-- upvalues: (copy) v_u_8, (ref) v_u_3
				local v9 = v_u_8:GetAttribute("DevCam")
				local v10 = v_u_3.CurrentCamera
				if typeof(v9) == "CFrame" and v10 then
					v10.CFrame = v9
				end
			end)
			v_u_8:GetAttributeChangedSignal("DevBuy"):Connect(function()
				-- upvalues: (copy) v_u_8, (ref) v_u_7
				local v11 = v_u_8:GetAttribute("DevBuy")
				if type(v11) == "string" then
					local v12, v13 = string.match(v11, "^(%a+):(.+)$")
					if v12 == "pass" and v13 then
						v_u_7.buyPass(v13)
					elseif v12 == "product" and v13 then
						v_u_7.buyProduct(v13)
					end
				else
					return
				end
			end)
			v_u_8:GetAttributeChangedSignal("DevPerf"):Connect(function()
				-- upvalues: (copy) v_u_8, (ref) v_u_6
				local v14 = v_u_8:GetAttribute("DevPerf")
				if type(v14) == "number" then
					v_u_6.set(v14)
				end
			end)
			v_u_8:GetAttributeChangedSignal("DevFx"):Connect(function()
				-- upvalues: (copy) v_u_8, (ref) v_u_4, (ref) v_u_3
				local v15 = v_u_8:GetAttribute("DevFx")
				if type(v15) == "string" then
					local v16, v17, v18, v19 = string.match(v15, "^([%w_]+)@(-?[%d%.]+),(-?[%d%.]+),(-?[%d%.]+)")
					local v20 = v_u_8.Character
					if v20 then
						v20 = v_u_8.Character:FindFirstChild("HumanoidRootPart")
					end
					if v16 and (v20 and v20:IsA("BasePart")) then
						local v21 = tonumber(v17) or 0
						local v22 = tonumber(v18) or 0
						local v23 = tonumber(v19) or 0
						local v24 = Vector3.new(v21, v22, v23)
						local v25 = v20.Position + Vector3.new(0, 1.5, 0)
						local v26 = {}
						for v27 = 1, 8 do
							local v28 = v27 / 8 * 3.141592653589793 * 2
							local v29 = {
								["x"] = v24.X + math.cos(v28) * 8,
								["z"] = v24.Z + math.sin(v28) * 8,
								["at"] = v27 * 0.15 + 0.3
							}
							table.insert(v26, v29)
						end
						local v30 = {}
						for v31 = -2, 2 do
							local v32 = CFrame.lookAt(v25, v24)
							local v33 = CFrame.Angles
							local v34 = v31 * 12
							local v35 = {
								["p"] = nil,
								["d"] = 0.35,
								["p"] = v25 + (v32 * v33(0, math.rad(v34), 0)).LookVector * 40
							}
							table.insert(v30, v35)
						end
						v_u_4.play({
							["u"] = v_u_8.UserId,
							["a"] = v16,
							["o"] = v25,
							["p"] = v24,
							["t"] = v_u_3:GetServerTimeNow(),
							["d"] = (v24 - v25).Magnitude / 120,
							["strikes"] = v26,
							["bolts"] = v30
						})
					end
				else
					return
				end
			end)
			v_u_8:GetAttributeChangedSignal("DevMode"):Connect(function()
				-- upvalues: (copy) v_u_8, (ref) v_u_5
				local v36 = v_u_8:GetAttribute("DevMode")
				local v37 = v_u_8.Character
				if type(v36) == "string" and v37 then
					local v38 = v_u_5.start(v_u_8, v37, v36)
					task.delay(6, v38)
				end
			end)
		end
	end
}