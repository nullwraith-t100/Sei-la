local v_u_1 = require(script.Parent.ArcadeLog)
local v_u_2 = require(script.Parent.Parent.Config.Arcade)
local v_u_3 = {}
local v_u_4 = {
	0,
	1,
	0,
	-1
}
local v_u_5 = {
	-1,
	0,
	1,
	0
}
v_u_3.UP = 1
v_u_3.RIGHT = 2
v_u_3.DOWN = 3
v_u_3.LEFT = 4
v_u_3.ACTIONS = 4
function v_u_3.xyOf(p6, p7) -- name: xyOf
	local v8 = (p7 - 1) % p6.w + 1
	return v8, (p7 - v8) // p6.w + 1
end
local function v_u_16(p9) -- name: freeCell
	-- upvalues: (copy) v_u_1
	local v10 = {}
	local v11 = {}
	for _, v12 in p9.body do
		v10[v12] = true
	end
	v10[p9.orb] = true
	v10[p9.golden] = true
	for v13 = 1, p9.w * p9.h do
		if v10[v13] then
			continue
		end
		table.insert(v11, v13)
	end
	if #v11 == 0 then
		return 0
	end
	local v14, v15 = v_u_1.roll(p9.rng, #v11)
	p9.rng = v14
	return v11[v15]
end
function v_u_3.new(p17) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_1, (copy) v_u_16
	local v18 = v_u_2.snake
	local v19 = {
		["w"] = nil,
		["h"] = nil,
		["body"] = nil,
		["dir"] = nil,
		["queue"] = nil,
		["orb"] = 0,
		["golden"] = 0,
		["goldenUntil"] = 0,
		["grow"] = 0,
		["rng"] = nil,
		["tick"] = 0,
		["time"] = 0,
		["interval"] = nil,
		["score"] = 0,
		["orbs"] = 0,
		["goldens"] = 0,
		["combo"] = 0,
		["bestCombo"] = 0,
		["lastEat"] = (-1 / 0),
		["over"] = false,
		["reason"] = "",
		["events"] = nil,
		["w"] = v18.width,
		["h"] = v18.height,
		["body"] = {},
		["dir"] = v_u_3.RIGHT,
		["queue"] = {},
		["rng"] = v_u_1.seed(p17),
		["interval"] = v18.interval,
		["events"] = {}
	}
	local v20 = (v19.h + 1) // 2
	local v21 = (v19.w + 1) // 2
	for v22 = 0, v18.startLength - 1 do
		local v23 = v19.body
		local v24 = v21 - v22
		local v25 = (v20 - 1) * v19.w + v24
		table.insert(v23, v25)
	end
	v19.orb = v_u_16(v19)
	return v19
end
function v_u_3.turn(p26, p27) -- name: turn
	if p26.over or (p27 < 1 or (p27 > 4 or #p26.queue >= 3)) then
		return false
	end
	local v28 = p26.queue[#p26.queue] or p26.dir
	if p27 == v28 or (p27 + 2 - 1) % 4 + 1 == v28 then
		return false
	end
	local v29 = p26.queue
	table.insert(v29, p27)
	return true
end
local function v_u_51(p30, p31, p32) -- name: eat
	-- upvalues: (copy) v_u_2, (copy) v_u_16
	local v33 = v_u_2.snake
	if p30.time - p30.lastEat <= v33.comboSeconds then
		local v34 = p30.combo + 1
		local v35 = v33.comboMax
		p30.combo = math.min(v34, v35)
	else
		p30.combo = 1
	end
	local v36 = p30.bestCombo
	local v37 = p30.combo
	p30.bestCombo = math.max(v36, v37)
	p30.lastEat = p30.time
	local v38
	if p32 then
		v38 = v33.goldenPoints
	else
		v38 = v33.orbPoints
	end
	local v39 = v38 * p30.combo
	p30.score = p30.score + v39
	if p32 then
		p30.goldens = p30.goldens + 1
		p30.grow = p30.grow + v33.goldenGrow
		p30.golden = 0
		local v40 = p30.events
		local v41 = {
			["kind"] = "golden",
			["cell"] = nil,
			["points"] = nil,
			["combo"] = nil,
			["cell"] = p31,
			["points"] = v39 or 0,
			["combo"] = p30.combo
		}
		table.insert(v40, v41)
		return
	else
		p30.orbs = p30.orbs + 1
		p30.grow = p30.grow + 1
		local v42 = v33.minInterval
		local v43 = p30.interval - v33.speedUp
		p30.interval = math.max(v42, v43)
		p30.orb = 0
		local v44 = p30.events
		local v45 = {
			["kind"] = "eat",
			["cell"] = nil,
			["points"] = nil,
			["combo"] = nil,
			["cell"] = p31,
			["points"] = v39 or 0,
			["combo"] = p30.combo
		}
		table.insert(v44, v45)
		p30.orb = v_u_16(p30)
		if p30.orb == 0 then
			p30.over = true
			p30.reason = "full"
			local v46 = p30.events
			local v47 = {
				["kind"] = "over",
				["cell"] = nil,
				["points"] = 0,
				["combo"] = nil,
				["cell"] = p31,
				["combo"] = p30.combo
			}
			table.insert(v46, v47)
		elseif p30.orbs % v33.goldenEvery == 0 and p30.golden == 0 then
			p30.golden = v_u_16(p30)
			p30.goldenUntil = p30.time + v33.goldenSeconds
			if p30.golden ~= 0 then
				local v48 = p30.golden
				local v49 = p30.events
				local v50 = {
					["kind"] = "spawn",
					["cell"] = nil,
					["points"] = 0,
					["combo"] = nil,
					["cell"] = v48,
					["combo"] = p30.combo
				}
				table.insert(v49, v50)
			end
		end
	end
end
function v_u_3.step(p52) -- name: step
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_51, (copy) v_u_2
	if p52.over then
		return
	else
		table.clear(p52.events)
		local v53 = table.remove(p52.queue, 1)
		if v53 and p52.dir ~= (v53 + 2 - 1) % 4 + 1 then
			p52.dir = v53
		end
		p52.tick = p52.tick + 1
		p52.time = p52.time + p52.interval
		local v54 = p52.body[1]
		local v55 = (v54 - 1) % p52.w + 1
		local v56 = (v54 - v55) // p52.w + 1
		local v57 = v55 + v_u_4[p52.dir]
		local v58 = v56 + v_u_5[p52.dir]
		if v57 < 1 or (p52.w < v57 or (v58 < 1 or p52.h < v58)) then
			p52.over = true
			p52.reason = "wall"
			local v59 = p52.body[1]
			local v60 = p52.events
			local v61 = {
				["kind"] = "over",
				["cell"] = nil,
				["points"] = 0,
				["combo"] = nil,
				["cell"] = v59,
				["combo"] = p52.combo
			}
			table.insert(v60, v61)
			return
		else
			local v62 = (v58 - 1) * p52.w + v57
			local v63 = p52.body[#p52.body]
			if table.find(p52.body, v62) ~= nil and (v62 ~= v63 or p52.grow ~= 0) then
				p52.over = true
				p52.reason = "self"
				local v64 = p52.events
				local v65 = {
					["kind"] = "over",
					["cell"] = nil,
					["points"] = 0,
					["combo"] = nil,
					["cell"] = v62,
					["combo"] = p52.combo
				}
				table.insert(v64, v65)
			else
				local v66 = p52.body
				table.insert(v66, 1, v62)
				if p52.grow > 0 then
					p52.grow = p52.grow - 1
				else
					table.remove(p52.body)
				end
				if v62 == p52.orb then
					v_u_51(p52, v62, false)
				elseif v62 == p52.golden then
					local v67 = v_u_2.snake
					if p52.time - p52.lastEat <= v67.comboSeconds then
						local v68 = p52.combo + 1
						local v69 = v67.comboMax
						p52.combo = math.min(v68, v69)
					else
						p52.combo = 1
					end
					local v70 = p52.bestCombo
					local v71 = p52.combo
					p52.bestCombo = math.max(v70, v71)
					p52.lastEat = p52.time
					local v72 = v67.goldenPoints * p52.combo
					p52.score = p52.score + v72
					p52.goldens = p52.goldens + 1
					p52.grow = p52.grow + v67.goldenGrow
					p52.golden = 0
					local v73 = p52.events
					local v74 = {
						["kind"] = "golden",
						["cell"] = nil,
						["points"] = nil,
						["combo"] = nil,
						["cell"] = v62,
						["points"] = v72 or 0,
						["combo"] = p52.combo
					}
					table.insert(v73, v74)
				end
				if p52.golden ~= 0 and p52.time >= p52.goldenUntil then
					local v75 = p52.golden
					local v76 = p52.events
					local v77 = {
						["kind"] = "goldenGone",
						["cell"] = nil,
						["points"] = 0,
						["combo"] = nil,
						["cell"] = v75,
						["combo"] = p52.combo
					}
					table.insert(v76, v77)
					p52.golden = 0
				end
				if not p52.over and p52.time >= v_u_2.snake.roundSeconds then
					p52.over = true
					p52.reason = "time"
					local v78 = p52.body[1]
					local v79 = p52.events
					local v80 = {
						["kind"] = "over",
						["cell"] = nil,
						["points"] = 0,
						["combo"] = nil,
						["cell"] = v78,
						["combo"] = p52.combo
					}
					table.insert(v79, v80)
				end
			end
		end
	end
end
function v_u_3.left(p81) -- name: left
	-- upvalues: (copy) v_u_2
	local v82 = v_u_2.snake.roundSeconds - p81.time
	return math.max(0, v82)
end
function v_u_3.replay(p83, p84, p85, p86) -- name: replay
	-- upvalues: (copy) v_u_3
	local v87 = v_u_3.new(p83)
	local v88 = 1
	while not v87.over and v87.tick < p85 do
		while p84[v88] and p84[v88].tick <= v87.tick do
			if p84[v88].tick == v87.tick then
				v_u_3.turn(v87, p84[v88].action)
			end
			v88 = v88 + 1
		end
		if p86 < v87.time + v87.interval then
			break
		end
		v_u_3.step(v87)
	end
	return v87
end
return v_u_3