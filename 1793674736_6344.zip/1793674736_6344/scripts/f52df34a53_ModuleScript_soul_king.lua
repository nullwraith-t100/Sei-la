local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromHex("34E5FF")
local v_u_6 = Color3.fromRGB(10, 70, 160)
local v_u_7 = Color3.fromRGB(196, 250, 255)
local v_u_8 = Color3.fromRGB(255, 196, 70)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Enum.Material.Glass
local v_u_11 = Enum.Material.Neon
local function v_u_22(p12, p13) -- name: eyePiece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v14 = v_u_1:FindFirstChild("EyePieces")
	if v14 then
		v14 = v14:FindFirstChild(p12)
	end
	if not (v14 and v14:IsA("MeshPart")) then
		return nil
	end
	local v15 = v14:Clone()
	local v16 = v14.Size
	local v17 = v14.Size.X
	local v18 = v14.Size.Y
	local v19 = v14.Size.Z
	v15.Size = v16 * (p13 / math.max(v17, v18, v19, 0.01))
	v15.Anchored = true
	v15.CanCollide = false
	v15.CanQuery = false
	v15.CanTouch = false
	v15.Massless = true
	v15.CastShadow = false
	local v20 = v15:FindFirstChildOfClass("SurfaceAppearance")
	if v20 then
		local v21 = v20.EmissiveStrength
		v20.EmissiveStrength = math.max(v21, 5)
	end
	v15.Parent = v_u_2.folder()
	return v15
end
return function(p_u_23)
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_3, (copy) v_u_22, (copy) v_u_11, (copy) v_u_10, (copy) v_u_8, (copy) v_u_9
	return {
		["w7_soul_king"] = function(p_u_24, _)
			-- upvalues: (copy) p_u_23, (ref) v_u_2, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (ref) v_u_3, (ref) v_u_22, (ref) v_u_11, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9
			local v25 = p_u_24.headY / 1.5
			local v_u_26 = math.clamp(v25, 0.7, 3)
			local v_u_27 = p_u_24.fx
			local v_u_28 = nil
			local v_u_29 = {}
			local v_u_33 = p_u_23.throb(p_u_24, 6, 2.2, 0.9, function(p30)
				-- upvalues: (ref) p_u_23, (copy) p_u_24, (ref) v_u_2, (copy) v_u_26, (ref) v_u_7, (copy) v_u_27, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (ref) v_u_28, (ref) v_u_3
				local v31 = p_u_23.feetAt(p_u_24, p30, 0.1)
				v_u_2.flash(p30.Position + Vector3.new(0, 0.5, 0) * v_u_26, v_u_7, v_u_26 * 6 * v_u_27, 0.3)
				v_u_2.ring(v31, v_u_6, 9 * v_u_27, 0.7, v_u_4.SoulSeal)
				v_u_2.ring(v31 + Vector3.new(0, 0.05, 0), v_u_5, 7 * v_u_27, 0.5, v_u_4.Ring)
				local v32 = v_u_28
				if v32 then
					v32:Emit(v_u_3.level() <= 1 and 4 or 12)
				end
			end)
			local v34 = p_u_24.headY + v_u_26 * 1.15
			local v35 = Vector3.new(0, v34, 0)
			local v_u_36 = 0
			local v37 = p_u_24.ticks
			local function v39(_, _, p38)
				-- upvalues: (ref) v_u_36, (copy) v_u_33
				v_u_36 = v_u_36 + p38 * (0.6 + 6 * v_u_33())
			end
			table.insert(v37, v39)
			local v_u_40 = v_u_36
			for v_u_41 = 1, 4 do
				local v_u_42 = v_u_22("w7_soul_king", v_u_26 * 1.7)
				if v_u_42 then
					local v_u_43 = v_u_42.Size
					local v_u_44 = -1
					p_u_23.add(p_u_24, v_u_42, function(p45, p46)
						-- upvalues: (copy) v_u_33, (ref) v_u_44, (copy) v_u_42, (copy) v_u_43, (copy) v_u_41, (copy) v_u_26, (ref) v_u_40
						local v47 = v_u_33() * 16
						local v48 = math.floor(v47) / 16
						if v48 ~= v_u_44 then
							v_u_44 = v48
							v_u_42.Size = v_u_43 * (v48 * 0.2 + 1)
						end
						local v49 = CFrame.new
						local v50 = v_u_41
						local v51 = 0.7853981633974483 + (v50 - 1) * 3.141592653589793 / 2
						local v52 = (2.25 + 0.35 * v_u_33()) * v_u_26
						local v53 = math.cos(v51) * v52
						local v54 = v_u_26 * 0.25
						local v55 = p46 * 1.2 + v50 * 1.6
						local v56 = v54 + math.sin(v55) * 0.15 * v_u_26
						local v57 = math.sin(v51) * v52
						return p45 * v49((Vector3.new(v53, v56, v57))) * CFrame.Angles(0, v_u_40 + v_u_41, 0)
					end)
				else
					local v58 = v_u_26 * 0.5
					local v59 = v_u_26 * 0.75
					local v60 = v_u_26 * 0.34
					local v61 = {}
					local v62 = {}
					for _, v63 in { 1, -1 } do
						for _, v64 in { -1, 1 } do
							local v65
							if v64 < 0 then
								v65 = v_u_5
							else
								v65 = v_u_7
							end
							local v66
							if v64 < 0 then
								v66 = v_u_11
							else
								v66 = v_u_10
							end
							local v67 = v60 / 2
							local v68 = Vector3.new(v58, v59, v67)
							local v69 = v64 < 0 and 0 or 0.1
							local v70 = Instance.new("WedgePart")
							v70.Anchored = true
							v70.CanCollide = false
							v70.CanQuery = false
							v70.CanTouch = false
							v70.CastShadow = false
							v70.Massless = true
							v70.Color = v65
							v70.Material = v66
							v70.Transparency = v69
							v70.Size = v68
							v70.Parent = v_u_2.folder()
							local v71 = CFrame.new(0, v63 * v59 / 2, v64 * v60 / 4) * CFrame.Angles(v63 < 0 and 3.141592653589793 or 0, v64 > 0 and 3.141592653589793 or 0, 0)
							table.insert(v61, v70)
							table.insert(v62, v71)
						end
					end
					local v72 = p_u_23.bar
					local v73 = v58 * 1.08
					local v74 = v_u_26 * 0.12
					local v75 = v60 * 1.1
					local v76 = Vector3.new(v73, v74, v75)
					local v77 = v_u_8
					local v78 = Enum.Material.Metal
					table.insert(v61, v72(v76, v77, 0, v78))
					local v79 = CFrame.identity
					table.insert(v62, v79)
					for v80, v81 in v61 do
						local v_u_82 = v62[v80]
						p_u_23.add(p_u_24, v81, function(p83, p84)
							-- upvalues: (copy) v_u_41, (copy) v_u_33, (copy) v_u_26, (ref) v_u_40, (copy) v_u_82
							local v85 = CFrame.new
							local v86 = v_u_41
							local v87 = 0.7853981633974483 + (v86 - 1) * 3.141592653589793 / 2
							local v88 = (2.25 + 0.35 * v_u_33()) * v_u_26
							local v89 = math.cos(v87) * v88
							local v90 = v_u_26 * 0.25
							local v91 = p84 * 1.2 + v86 * 1.6
							local v92 = v90 + math.sin(v91) * 0.15 * v_u_26
							local v93 = math.sin(v87) * v88
							return p83 * v85((Vector3.new(v89, v92, v93))) * CFrame.Angles(0, v_u_40 + v_u_41, 0) * v_u_82
						end)
					end
				end
			end
			local v_u_94 = {}
			local v_u_95 = Instance.new("Attachment")
			v_u_95.Parent = p_u_24.root
			p_u_23.own(p_u_24, v_u_95)
			local v96 = p_u_24.stops
			table.insert(v96, function()
				-- upvalues: (copy) v_u_95
				v_u_95:Destroy()
			end)
			table.insert(v_u_94, v_u_95)
			local v_u_97 = Instance.new("Attachment")
			v_u_97.Parent = p_u_24.root
			p_u_23.own(p_u_24, v_u_97)
			local v98 = p_u_24.stops
			table.insert(v98, function()
				-- upvalues: (copy) v_u_97
				v_u_97:Destroy()
			end)
			table.insert(v_u_94, v_u_97)
			local v_u_99 = Instance.new("Attachment")
			v_u_99.Parent = p_u_24.root
			p_u_23.own(p_u_24, v_u_99)
			local v100 = p_u_24.stops
			table.insert(v100, function()
				-- upvalues: (copy) v_u_99
				v_u_99:Destroy()
			end)
			table.insert(v_u_94, v_u_99)
			local v_u_101 = Instance.new("Attachment")
			v_u_101.Parent = p_u_24.root
			p_u_23.own(p_u_24, v_u_101)
			local v102 = p_u_24.stops
			table.insert(v102, function()
				-- upvalues: (copy) v_u_101
				v_u_101:Destroy()
			end)
			table.insert(v_u_94, v_u_101)
			local v_u_103 = Instance.new("Attachment")
			v_u_103.Parent = p_u_24.root
			p_u_23.own(p_u_24, v_u_103)
			local v104 = p_u_24.stops
			table.insert(v104, function()
				-- upvalues: (copy) v_u_103
				v_u_103:Destroy()
			end)
			v_u_103.Position = v35
			for v105 = 1, 4 do
				local v106 = v_u_94[v105 % 4 + 1]
				for _, v107 in {
					{ v_u_94[v105], v106 },
					{ v_u_94[v105], v_u_103 }
				} do
					local v108 = p_u_23.ray(v107[1], v107[2], v_u_5, v_u_26 * 0.14, v_u_26 * 0.14)
					v108.LightEmission = 0.7
					v108.Transparency = NumberSequence.new(0.25)
					table.insert(v_u_29, v108)
				end
			end
			local v_u_109 = -1
			local v110 = p_u_24.ticks
			local function v125(_, p111)
				-- upvalues: (copy) v_u_94, (copy) v_u_33, (copy) v_u_26, (ref) v_u_109, (ref) v_u_5, (ref) v_u_9, (copy) v_u_29
				for v112, v113 in v_u_94 do
					local v114 = 0.7853981633974483 + (v112 - 1) * 3.141592653589793 / 2
					local v115 = (2.25 + 0.35 * v_u_33()) * v_u_26
					local v116 = math.cos(v114) * v115
					local v117 = v_u_26 * 0.25
					local v118 = p111 * 1.2 + v112 * 1.6
					local v119 = v117 + math.sin(v118) * 0.15 * v_u_26
					local v120 = math.sin(v114) * v115
					v113.Position = Vector3.new(v116, v119, v120)
				end
				local v121 = v_u_33() * 12
				local v122 = math.floor(v121) / 12
				if v122 ~= v_u_109 then
					v_u_109 = v122
					local v123 = v_u_5:Lerp(v_u_9, v122 * 0.8)
					for _, v124 in v_u_29 do
						v124.Color = ColorSequence.new(v123)
						v124.Width0 = (v122 * 0.12 + 0.14) * v_u_26
						v124.Width1 = v124.Width0
					end
				end
			end
			table.insert(v110, v125)
			local v126 = p_u_23.picture(v_u_26 * 5.4, v_u_4.Glow, v_u_6, 0.6)
			local v_u_127 = p_u_23.picture(v_u_26 * 6, v_u_4.SoulSeal, v_u_5:Lerp(v_u_6, 0.4), 0)
			p_u_23.add(p_u_24, v126, function(p128)
				-- upvalues: (ref) p_u_23, (copy) p_u_24
				return CFrame.new(p_u_23.feetAt(p_u_24, p128, 0.04))
			end)
			p_u_23.add(p_u_24, v_u_127, function(p129, p130)
				-- upvalues: (ref) p_u_23, (copy) p_u_24
				local v131 = CFrame.new(p_u_23.feetAt(p_u_24, p129, 0.08))
				local v132 = CFrame.Angles
				local v133 = -p129.LookVector.X
				local v134 = -p129.LookVector.Z
				local v135 = math.atan2(v133, v134)
				local v136 = p130 * 0.4
				return v131 * v132(0, v135 + math.sin(v136) * 0.3, 0)
			end)
			local v_u_137 = -1
			local v138 = p_u_24.ticks
			local function v144()
				-- upvalues: (copy) v_u_33, (ref) v_u_137, (copy) v_u_26, (copy) v_u_127
				local v139 = v_u_33() * 16
				local v140 = math.floor(v139) / 16
				if v140 ~= v_u_137 then
					v_u_137 = v140
					local v141 = v_u_26 * 6
					local v142 = math.clamp(v140, 0, 1)
					local v143 = v141 * (v142 * v142 * (3 - v142 * 2) * 0.35 + 1)
					v_u_127.Size = Vector3.new(v143, 0.05, v143)
				end
			end
			table.insert(v138, v144)
			local v_u_145 = Instance.new("ParticleEmitter")
			v_u_145.Texture = v_u_4.SoulGem
			v_u_145.Color = ColorSequence.new(v_u_5, v_u_7)
			v_u_145.LightEmission = 0.35
			v_u_145.LightInfluence = 0
			v_u_145.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, v_u_26 * 0.32 * v_u_27), NumberSequenceKeypoint.new(1, 0) })
			v_u_145.Lifetime = NumberRange.new(1.4, 2.2)
			v_u_145.Speed = NumberRange.new(1, 2.4)
			v_u_145.SpreadAngle = Vector2.new(20, 20)
			v_u_145.EmissionDirection = Enum.NormalId.Top
			v_u_145.Drag = 0.6
			v_u_145.RotSpeed = NumberRange.new(-60, 60)
			v_u_145.Shape = Enum.ParticleEmitterShape.Box
			v_u_145.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_145:SetAttribute("BaseRate", 4 * v_u_27)
			v_u_145.Rate = 4 * v_u_27 * v_u_3.formRate()
			v_u_145.Parent = v126
			v_u_28 = v_u_145
			p_u_23.own(p_u_24, v126)
			local v146 = p_u_24.stops
			table.insert(v146, function()
				-- upvalues: (copy) v_u_145
				v_u_145.Enabled = false
			end)
			p_u_23.particles(p_u_24, "AuraMode", v_u_5, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end