local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.CompulsoryNerve, v_u_7.CompulsoryWeb, v_u_7.CompulsorySpark })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FFC83D")
local v_u_10 = Color3.fromRGB(255, 128, 36)
local v_u_11 = Color3.fromRGB(86, 18, 10)
local v_u_12 = Color3.fromRGB(236, 232, 220)
local v_u_13 = Enum.Material.SmoothPlastic
local function v_u_46(p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v25 = p20 + p21 + p22
	local v26 = math.max(v25, 0.05)
	local v27 = {}
	local v28 = {}
	for v29 = 0, 10 do
		local v30 = v29 / 10
		local v31 = v30 * v26
		local v32 = v31 / math.max(p20, 0.001)
		local v33 = 1 - (1 - math.clamp(v32, 0, 1)) ^ 3
		local v34 = (v31 - p20 - p21) / math.max(p22, 0.001)
		local v35 = math.clamp(v34, 0, 1)
		local v36 = v35 * v35 * (3 - v35 * 2)
		local v37 = NumberSequenceKeypoint.new
		local v38 = p15 + (p16 - p15) * v33
		local v39 = math.max(v38, 0.05) / 2
		table.insert(v28, v37(v30, v39))
		local v40 = NumberSequenceKeypoint.new
		local v41 = p19 + (1 - p19) * v36
		local v42 = math.clamp(v41, 0, 1)
		table.insert(v27, v40(v30, v42))
	end
	local v43 = Instance.new("Attachment")
	v43.WorldCFrame = CFrame.new(p14)
	v43.Parent = v_u_3.Terrain
	local v44 = Instance.new("ParticleEmitter")
	v44.Enabled = false
	v44.Texture = p17
	v44.Color = ColorSequence.new(p18)
	v44.LightEmission = p24 or 0
	v44.LightInfluence = 0
	v44.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v44.EmissionDirection = Enum.NormalId.Top
	v44.SpreadAngle = Vector2.zero
	v44.Speed = NumberRange.new(0.01)
	v44.Size = NumberSequence.new(v28)
	v44.Transparency = NumberSequence.new(v27)
	v44.Lifetime = NumberRange.new(v26)
	local v45 = p23 or math.random(0, 359)
	v44.Rotation = NumberRange.new(v45, v45)
	v44.Parent = v43
	v44:Emit(1)
	v_u_1:AddItem(v43, v26 + 0.2)
end
local function v_u_53(p47, p48, p49, p50) -- name: sparks
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1
	local v51 = Instance.new("Attachment")
	v51.WorldPosition = p47
	v51.Parent = v_u_3.Terrain
	local v52 = Instance.new("ParticleEmitter")
	v52.Enabled = false
	v52.Texture = v_u_7.CompulsorySpark
	v52.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
	v52.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v52.Color = ColorSequence.new(v_u_9, v_u_10)
	v52.LightEmission = 0.5
	v52.LightInfluence = 0
	v52.Lifetime = NumberRange.new(0.22, 0.32)
	v52.Size = NumberSequence.new(p48 * 0.6, p48)
	v52.Speed = NumberRange.new(0, p50 or 0)
	v52.SpreadAngle = Vector2.new(180, 180)
	v52.Rotation = NumberRange.new(0, 360)
	v52.Parent = v51
	v52:Emit(p49)
	v_u_1:AddItem(v51, 0.6)
end
local function v_u_61(p54, p55, p56, p57, p58, p59) -- name: nerve
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v60 = Instance.new("Beam")
	v60.Attachment0 = p54
	v60.Attachment1 = p55
	v60.Texture = v_u_7.CompulsoryNerve
	v60.TextureMode = Enum.TextureMode.Wrap
	v60.TextureLength = 3
	v60.TextureSpeed = p58
	v60.Color = ColorSequence.new(v_u_8)
	v60.LightEmission = 0.2
	v60.LightInfluence = 0
	v60.FaceCamera = true
	v60.Segments = 16
	v60.Width0 = p56
	v60.Width1 = p57
	v60.Parent = p59
	return v60
end
local function v_u_68(p62, p63, p64) -- name: setAxis
	local v65 = p64.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p64.Unit
	local v66 = v65.Y
	local v67 = math.abs(v66) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	p62.WorldCFrame = CFrame.fromMatrix(p63, v65, v67:Cross(v65).Unit:Cross(v65))
end
return function(p_u_69)
	-- upvalues: (copy) v_u_53, (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_68, (copy) v_u_61, (copy) v_u_9, (copy) v_u_11, (copy) v_u_7, (copy) v_u_46, (copy) v_u_13, (copy) v_u_10, (copy) v_u_12, (copy) v_u_6
	local v263 = {
		["compulsory_a"] = {
			["windup"] = function(p70, _, _) -- name: windup
				-- upvalues: (ref) v_u_53
				v_u_53(p70.eye - Vector3.new(0, 0.5, 0) + p70.dir:Cross(Vector3.new(0, 1, 0)) * 0.7 * p70.size - p70.dir * 0.4, 1.6 * p70.size, 1)
			end,
			["beam"] = function(p71, _, p_u_72) -- name: beam
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_68, (ref) v_u_61, (ref) v_u_53, (ref) v_u_9, (ref) v_u_11, (ref) v_u_7
				local v_u_73 = p71.size
				local v74 = p71.lite
				local v_u_75 = p71.eye - Vector3.new(0, 0.5, 0) + p71.dir:Cross(Vector3.new(0, 1, 0)) * 0.7 * p71.size - p71.dir * 0.4
				local v_u_76 = p_u_72 - v_u_75
				local v_u_77 = p_u_69.flatUnit(v_u_76):Cross(Vector3.new(0, 1, 0))
				local v_u_78 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_75), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_78, 1.2)
				local v79 = Instance.new("Attachment")
				v79.Parent = v_u_78
				v_u_68(v79, v_u_75, v_u_77)
				local v_u_80 = Instance.new("Attachment")
				v_u_80.Parent = v_u_78
				v_u_68(v_u_80, v_u_75, v_u_77)
				local v_u_81 = { (v_u_61(v79, v_u_80, 1.5 * v_u_73, 0.6 * v_u_73, 3, v_u_78)) }
				local v_u_82 = (math.random() < 0.5 and 1 or -1) * 5 * v_u_73
				p_u_69.animate(0.08, 0, function(p83)
					-- upvalues: (copy) v_u_80, (copy) v_u_75, (copy) p_u_72, (copy) v_u_81, (copy) v_u_82
					local v84 = 1 - (1 - p83) ^ 2
					v_u_80.WorldPosition = v_u_75:Lerp(p_u_72, v84)
					v_u_81[1].CurveSize0 = v_u_82 * (1 - v84 * 0.7)
					v_u_81[1].CurveSize1 = v_u_82 * 0.6 * (1 - v84)
				end)
				if not v74 then
					p_u_69.after(0.05, function()
						-- upvalues: (copy) v_u_75, (copy) p_u_72, (ref) p_u_69, (copy) v_u_77, (copy) v_u_73, (copy) v_u_76, (copy) v_u_78, (ref) v_u_68, (ref) v_u_61, (copy) v_u_81
						for v85 = 1, 2 do
							local v_u_86 = v_u_75:Lerp(p_u_72, v85 * 0.22 + 0.35)
							local v_u_87 = p_u_69.ground(v_u_86 + v_u_77 * (v85 == 1 and 1.6 or -1.4) * v_u_73 + v_u_76.Unit * 1.2, 0.1)
							local v88 = v_u_78
							local v89 = Instance.new("Attachment")
							v89.Parent = v88
							v_u_68(v89, v_u_86, Vector3.new(-0, -1, -0))
							local v90 = v_u_78
							local v_u_91 = Instance.new("Attachment")
							v_u_91.Parent = v90
							v_u_68(v_u_91, v_u_86, Vector3.new(-0, -1, -0))
							local v92 = v_u_61(v89, v_u_91, 0.55 * v_u_73, 0.2 * v_u_73, 2, v_u_78)
							v92.CurveSize0 = 1.2 * v_u_73
							local v93 = v_u_81
							table.insert(v93, v92)
							p_u_69.animate(0.1, 0, function(p94)
								-- upvalues: (copy) v_u_91, (copy) v_u_86, (copy) v_u_87
								v_u_91.WorldPosition = v_u_86:Lerp(v_u_87, p94)
							end)
						end
					end)
				end
				v_u_53(p_u_72, 3.2 * v_u_73, v74 and 1 or 3, 4)
				v_u_4.flash(p_u_72, v_u_9, 2.6 * v_u_73, 0.14)
				if not v74 then
					v_u_4.ring(p_u_69.ground(p_u_72, 0.12), v_u_11, 3 * v_u_73, 0.25, v_u_7.Ring)
				end
				p_u_69.after(0.14, function()
					-- upvalues: (ref) p_u_69, (copy) v_u_80, (copy) p_u_72, (copy) v_u_75, (copy) v_u_81, (copy) v_u_82, (copy) v_u_78
					p_u_69.animate(0.16, 0, function(p95)
						-- upvalues: (ref) v_u_80, (ref) p_u_72, (ref) v_u_75, (ref) v_u_81, (ref) v_u_82
						v_u_80.WorldPosition = p_u_72:Lerp(v_u_75, p95 * p95)
						local v96 = v_u_81[1]
						local v97 = -v_u_82 * 0.5
						local v98 = p95 * 3.141592653589793
						v96.CurveSize0 = v97 * math.sin(v98)
					end)
					local v_u_99 = v_u_81
					local function v_u_100()
						-- upvalues: (ref) v_u_78
						v_u_78:Destroy()
					end
					local v_u_101 = os.clock()
					local v_u_102 = 0.18
					task.spawn(function()
						-- upvalues: (copy) v_u_101, (copy) v_u_102, (copy) v_u_99, (copy) v_u_100
						while os.clock() - v_u_101 < v_u_102 do
							local v103 = (os.clock() - v_u_101) / v_u_102
							for _, v104 in v_u_99 do
								v104.Transparency = NumberSequence.new(v103)
							end
							task.wait()
						end
						for _, v105 in v_u_99 do
							v105.Transparency = NumberSequence.new(1)
						end
						if v_u_100 then
							v_u_100()
						end
					end)
				end)
				p_u_69.beamHitSound(p71, p_u_72, "Hit")
			end,
			["hit"] = function(p106, p107, _) -- name: hit
				-- upvalues: (ref) v_u_53, (copy) p_u_69, (ref) v_u_9
				v_u_53(p107, 2.2 * p106.size, 1)
				p_u_69.burst("Impact", p107, v_u_9, 0.5)
			end
		},
		["compulsory_e"] = {
			["cast"] = nil,
			["castSound"] = "Bind",
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p108) -- name: cast
				-- upvalues: (copy) p_u_69, (ref) v_u_9, (ref) v_u_53
				p_u_69.skillCast(p108, v_u_9, false, true)
				v_u_53(p108.eye - Vector3.new(0, 0.5, 0) + p108.dir:Cross(Vector3.new(0, 1, 0)) * 0.7 * p108.size - p108.dir * 0.4, 2.4 * p108.size, 2, 3)
			end,
			["windup"] = function(p109, p110, p111) -- name: windup
				-- upvalues: (copy) p_u_69, (ref) v_u_46, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_53
				local v112 = p109.size
				local v113 = p109.ability.radius * v112
				local v114 = p111 + (p109.ability.duration or 1.6)
				local v115 = p_u_69.ground(p110, 0.12)
				v_u_46(v115, v113 * 0.4, v113 * 2.3, v_u_7.CompulsoryWeb, v_u_11, 0.35, 0.25, v114, 0.4, nil, 0)
				v_u_46(v115, v113 * 0.3, v113 * 2.1, v_u_7.CompulsoryWeb, v_u_9, 0.05, 0.25, v114, 0.4, nil, 0.25)
				v_u_53(v115 + Vector3.new(0, 1, 0), 3 * v112, p109.lite and 1 or 4, 8)
			end,
			["zone"] = function(p116, p117, p_u_118) -- name: zone
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_11, (ref) v_u_13, (ref) v_u_68, (ref) v_u_61, (ref) v_u_53
				local v_u_119 = p116.size
				local v_u_120 = p116.lite
				local v_u_121 = p116.ability.radius * v_u_119
				local v_u_122 = p_u_69.ground(p117, 0.2)
				local v_u_123 = v_u_122 + Vector3.new(0, 4.5, 0) * v_u_119
				local v_u_124 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_122), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_124, p_u_118 + 1.5)
				local v_u_125 = p_u_69.ball(v_u_123, v_u_9, 1.2 * v_u_119)
				local v_u_126 = p_u_69.ball(v_u_123, v_u_11, 1.5 * v_u_119, 0.3, v_u_13)
				v_u_1:AddItem(v_u_125, p_u_118 + 1)
				v_u_1:AddItem(v_u_126, p_u_118 + 1)
				local v127 = v_u_120 and 4 or 7
				local v128 = math.random() * 3.141592653589793 * 2
				local v129 = Instance.new("Attachment")
				v129.Parent = v_u_124
				v_u_68(v129, v_u_123, Vector3.new(-0, -1, -0))
				local v_u_130 = {}
				local v_u_131 = {}
				for v132 = 1, v127 do
					local v133 = v128 + v132 / v127 * 3.141592653589793 * 2
					local v134 = math.cos(v133)
					local v135 = math.sin(v133)
					local v136 = Vector3.new(v134, 0, v135)
					local v137 = v_u_122 + v136 * v_u_121 * 0.95
					local v138 = Instance.new("Attachment")
					v138.Parent = v_u_124
					v_u_68(v138, v137, Vector3.new(0, 1, 0))
					local v139 = v_u_61(v138, v129, 1.3 * v_u_119, 0.45 * v_u_119, -2.5, v_u_124)
					v139.CurveSize0 = 5 * v_u_119
					table.insert(v_u_131, {
						["a0"] = v138,
						["a1"] = v129,
						["beam"] = v139,
						["angle"] = v133
					})
					table.insert(v_u_130, v139)
					v_u_53(v_u_122 + v136 * v_u_121 * 0.95 + Vector3.new(0, 0.5, 0), 1.8 * v_u_119, 1)
				end
				local v_u_140 = os.clock()
				local v_u_141 = 0
				local v_u_142 = p116.ability.tick or 0.32
				local v_u_143 = true
				p_u_69.frame(function()
					-- upvalues: (ref) v_u_143, (copy) v_u_124, (copy) v_u_140, (copy) p_u_118, (copy) v_u_131, (copy) v_u_121, (ref) v_u_68, (copy) v_u_122, (copy) v_u_119, (copy) v_u_142, (copy) v_u_125, (ref) v_u_141, (ref) v_u_4, (copy) v_u_123, (ref) v_u_9, (copy) v_u_120, (ref) v_u_53
					if not (v_u_143 and v_u_124.Parent) then
						return false
					end
					local v144 = os.clock() - v_u_140
					local v145 = v144 / p_u_118
					local v146 = math.clamp(v145, 0, 1)
					for v147, v148 in v_u_131 do
						local v149 = v148.angle
						local v150 = math.cos(v149)
						local v151 = v148.angle
						local v152 = math.sin(v151)
						local v153 = Vector3.new(v150, 0, v152)
						local v154 = v_u_121 * (0.95 - v146 * 0.4)
						local v155 = v_u_68
						local v156 = v148.a0
						local v157 = v_u_122 + v153 * v154
						local v158 = Vector3.new(0, 1, 0) - v153 * 0.4
						local v159 = v153:Cross(Vector3.new(0, 1, 0))
						local v160 = v144 * 5 + v147
						v155(v156, v157, (v158 + v159 * math.sin(v160) * 0.6).Unit)
						local v161 = v148.beam
						local v162 = v144 * 7 + v147 * 1.3
						v161.CurveSize0 = (math.sin(v162) * 1.5 + 4.5) * v_u_119
						local v163 = v148.beam
						local v164 = v144 * 6 + v147
						v163.CurveSize1 = math.sin(v164) * 2 * v_u_119
					end
					local v165 = 1 - v144 % v_u_142 / v_u_142 * 3
					v_u_125.Size = Vector3.new(1, 1, 1) * (math.max(0, v165) * 0.8 + 1.2) * v_u_119
					if v_u_141 <= v144 then
						v_u_141 = v_u_141 + v_u_142
						v_u_4.flash(v_u_123, v_u_9, 3.5 * v_u_119, 0.18)
						if not v_u_120 then
							v_u_53(v_u_131[math.random(1, #v_u_131)].a0.WorldPosition + Vector3.new(0, 0.5, 0), 2 * v_u_119, 1)
						end
					end
					return true
				end)
				return function()
					-- upvalues: (ref) v_u_143, (copy) v_u_131, (ref) p_u_69, (copy) v_u_123, (ref) v_u_9, (copy) v_u_120, (copy) v_u_121, (copy) v_u_130, (copy) v_u_124, (copy) v_u_125, (copy) v_u_126
					v_u_143 = false
					for _, v_u_166 in v_u_131 do
						local v_u_167 = v_u_166.a0.WorldPosition
						p_u_69.animate(0.12, 0, function(p168)
							-- upvalues: (copy) v_u_166, (copy) v_u_167, (ref) v_u_123
							v_u_166.a0.WorldPosition = v_u_167:Lerp(v_u_123, p168 * p168)
						end)
					end
					p_u_69.inward(v_u_123, v_u_9, v_u_120 and 4 or 10, v_u_121 * 0.8, 0.14)
					local v_u_169 = v_u_130
					local function v_u_170()
						-- upvalues: (ref) v_u_124
						v_u_124:Destroy()
					end
					local v_u_171 = os.clock()
					local v_u_172 = 0.2
					task.spawn(function()
						-- upvalues: (copy) v_u_171, (copy) v_u_172, (copy) v_u_169, (copy) v_u_170
						while os.clock() - v_u_171 < v_u_172 do
							local v173 = (os.clock() - v_u_171) / v_u_172
							for _, v174 in v_u_169 do
								v174.Transparency = NumberSequence.new(v173)
							end
							task.wait()
						end
						for _, v175 in v_u_169 do
							v175.Transparency = NumberSequence.new(1)
						end
						if v_u_170 then
							v_u_170()
						end
					end)
					p_u_69.fadeOut(v_u_125, 0.2)
					p_u_69.fadeOut(v_u_126, 0.2)
				end
			end,
			["finish"] = function(p176, p177) -- name: finish
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (ref) v_u_46, (ref) v_u_53, (ref) v_u_12, (ref) v_u_6
				local v178 = p176.size
				local v179 = p176.ability.radius * v178
				local v180 = p_u_69.ground(p177, 0.15)
				v_u_4.flash(v180 + Vector3.new(0, 3, 0), v_u_8, 6 * v178, 0.16)
				v_u_4.flash(v180 + Vector3.new(0, 3, 0), v_u_9, 14 * v178, 0.35)
				p_u_69.pop(v180 + Vector3.new(0, 2, 0), v_u_10, 3 * v178, v179 * 1.2, 0.4, 0.45)
				v_u_4.ring(v180, v_u_11, v179 * 1.2, 0.45, v_u_7.Shockwave)
				v_u_4.ring(v180, v_u_9, v179 * 1.5, 0.55, v_u_7.Ring)
				v_u_46(v180, v179, v179 * 2.6, v_u_7.CompulsoryWeb, v_u_9, 0, 0.12, 0.1, 0.45, nil, 0.4)
				v_u_53(v180 + Vector3.new(0, 2, 0), 4 * v178, p176.lite and 2 or 6, 14)
				if not p176.lite then
					local v181 = { v_u_12, v_u_11, v_u_9 }
					p_u_69.chunks(v180 + Vector3.new(0, 0.5, 0), v181, 6, 26, 0.45 * v178, 0.8, false, 1)
				end
				v_u_6.play("Explosion", {
					["at"] = v180,
					["volume"] = p176.mine and 0.8 or 0.45
				})
				if p176.mine then
					v_u_4.shake(0.3, 0.25)
				end
			end,
			["hit"] = function(p182, p183, _) -- name: hit
				-- upvalues: (ref) v_u_53
				v_u_53(p183, 2 * p182.size, 1)
			end
		},
		["compulsory_r"] = {
			["cast"] = function(p184) -- name: cast
				-- upvalues: (copy) p_u_69, (ref) v_u_9
				p_u_69.skillCast(p184, v_u_9, true, true)
			end,
			["windup"] = function(p185, p186, p187) -- name: windup
				-- upvalues: (copy) p_u_69, (ref) v_u_10, (ref) v_u_9, (ref) v_u_46, (ref) v_u_7
				local v188 = p185.size
				local v189 = p_u_69.ground(p186, 0.2)
				local v190 = math.max(p187, 0.15)
				p_u_69.pop(v189 + Vector3.new(0, 1.2, 0), v_u_10, 1 * v188, 5 * v188, v190 + 0.1, 0.2)
				p_u_69.pop(v189 + Vector3.new(0, 1.2, 0), v_u_9, 0.6 * v188, 3 * v188, v190 + 0.1, 0)
				v_u_46(v189, 2 * v188, 9 * v188, v_u_7.CompulsoryWeb, v_u_9, 0.1, v190, 0, 0.2, nil, 0.3)
				p_u_69.inward(v189 + Vector3.new(0, 1.2, 0), v_u_9, p185.lite and 4 or 10, 10 * v188, v190)
			end,
			["land"] = function(p_u_191, p192) -- name: land
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_46, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_68, (ref) v_u_61, (ref) v_u_53, (ref) v_u_6, (ref) v_u_10, (ref) v_u_12
				local v_u_193 = p_u_191.size
				local v_u_194 = p_u_191.lite
				local v_u_195 = p_u_191.ability.radius * v_u_193
				local v196 = p_u_191.ability.freeze or 3
				local v_u_197 = p_u_69.ground(p192, 0.25)
				local v_u_198 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_197), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_198, v196 + 2)
				v_u_46(v_u_197, v_u_195 * 0.4, v_u_195 * 2.25, v_u_7.CompulsoryWeb, v_u_11, 0.3, 0.3, v196, 0.5, nil, 0)
				v_u_46(v_u_197, v_u_195 * 0.3, v_u_195 * 2.05, v_u_7.CompulsoryWeb, v_u_9, 0, 0.3, v196, 0.5, nil, 0.3)
				local v_u_199 = {}
				local v_u_200 = {}
				local v201 = v_u_194 and 6 or 9
				local v202 = math.random() * 3.141592653589793 * 2
				local function v215(p203, p204, p205, p206, p207) -- name: grow
					-- upvalues: (copy) v_u_198, (ref) v_u_68, (ref) v_u_61, (copy) v_u_199, (copy) v_u_200
					local v208 = v_u_198
					local v209 = Instance.new("Attachment")
					v209.Parent = v208
					v_u_68(v209, p203, Vector3.new(0, 1, 0))
					local v210 = v_u_198
					local v211 = Instance.new("Attachment")
					v211.Parent = v210
					v_u_68(v211, p203, Vector3.new(0, 1, 0))
					local v212 = v_u_61(v209, v211, p205, p205 * 0.35, -3, v_u_198)
					v212.CurveSize0 = p207
					v212.CurveSize1 = -p207 * 0.5
					local v213 = v_u_199
					table.insert(v213, {
						["a0"] = v209,
						["a1"] = v211,
						["from"] = p203,
						["to"] = p204,
						["beam"] = v212,
						["delay"] = p206
					})
					local v214 = v_u_200
					table.insert(v214, v212)
				end
				for v216 = 1, v201 do
					local v217 = v202 + v216 / v201 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.3
					local v218 = math.cos(v217)
					local v219 = math.sin(v217)
					local v220 = Vector3.new(v218, 0, v219)
					local v221 = v_u_195 * (0.8 + math.random() * 0.2)
					local v222 = v_u_197 + v220 * v221
					v215(v_u_197 + Vector3.new(0, 0.4, 0), v222, 2.4 * v_u_193, 0, (1.5 + math.random() * 2) * v_u_193)
					if v_u_194 then
						continue
					end
					for v223, v224 in { 0.38, 0.66 } do
						local v225 = v220:Cross(Vector3.new(0, 1, 0)) * (v223 == 1 and 1 or -1)
						local v226 = v_u_197 + v220 * v221 * v224
						v215(v226, v226 + (v220 + v225 * 0.9).Unit * v221 * (0.45 - v224 * 0.2), 1.3 * v_u_193, 0.08 + v224 * 0.12, 1 * v_u_193)
					end
				end
				for _, v_u_227 in v_u_199 do
					p_u_69.after(v_u_227.delay, function()
						-- upvalues: (ref) p_u_69, (copy) v_u_227, (ref) v_u_53, (copy) v_u_193
						p_u_69.animate(0.22, 0, function(p228)
							-- upvalues: (ref) v_u_227, (ref) v_u_53, (ref) v_u_193
							local v229 = 1 - (1 - p228) ^ 3
							v_u_227.a1.WorldPosition = v_u_227.from:Lerp(v_u_227.to, v229)
							if p228 >= 1 then
								v_u_53(v_u_227.to + Vector3.new(0, 0.6, 0), 2.4 * v_u_193, 1, 2)
							end
						end)
					end)
				end
				v_u_4.flash(v_u_197 + Vector3.new(0, 1.5, 0), v_u_8, 6 * v_u_193, 0.15)
				v_u_4.flash(v_u_197 + Vector3.new(0, 1.5, 0), v_u_9, 12 * v_u_193, 0.3)
				v_u_4.ring(v_u_197, v_u_11, v_u_195, 0.4, v_u_7.Shockwave)
				v_u_53(v_u_197 + Vector3.new(0, 1.5, 0), 4 * v_u_193, v_u_194 and 2 or 5, 10)
				v_u_6.play("Lightning", {
					["at"] = v_u_197,
					["volume"] = p_u_191.mine and 0.8 or 0.4
				})
				if p_u_191.mine then
					v_u_4.shake(0.25, 0.25)
				end
				if not v_u_194 then
					for v230 = 1, 3 do
						p_u_69.after(0.4 + (v230 - 1) * v196 / 3, function()
							-- upvalues: (ref) v_u_46, (copy) v_u_197, (copy) v_u_195, (ref) v_u_7, (ref) v_u_9
							v_u_46(v_u_197 + Vector3.new(0, 0.1, 0), v_u_195 * 2.2, 1, v_u_7.Ring, v_u_9, 0.05, 0.6, 0, 0.12, nil, 0.4)
						end)
					end
				end
				p_u_69.after(v196, function()
					-- upvalues: (copy) v_u_199, (ref) p_u_69, (copy) v_u_197, (copy) v_u_200, (copy) v_u_198, (ref) v_u_4, (ref) v_u_8, (copy) v_u_193, (ref) v_u_9, (copy) v_u_195, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11, (ref) v_u_53, (copy) v_u_194, (ref) v_u_12, (ref) v_u_6, (copy) p_u_191
					for _, v_u_231 in v_u_199 do
						local v_u_232 = v_u_231.a1.WorldPosition
						p_u_69.animate(0.28, 0, function(p233)
							-- upvalues: (copy) v_u_231, (copy) v_u_232, (ref) v_u_197
							local v234 = p233 * p233
							v_u_231.a1.WorldPosition = v_u_232:Lerp(v_u_197, v234)
							v_u_231.a0.WorldPosition = v_u_231.from:Lerp(v_u_197, v234)
						end)
					end
					local v_u_235 = v_u_200
					local v_u_236 = os.clock()
					local v_u_237 = 0.3
					local v_u_238 = nil
					task.spawn(function()
						-- upvalues: (copy) v_u_236, (copy) v_u_237, (copy) v_u_235, (copy) v_u_238
						while os.clock() - v_u_236 < v_u_237 do
							local v239 = (os.clock() - v_u_236) / v_u_237
							for _, v240 in v_u_235 do
								v240.Transparency = NumberSequence.new(v239)
							end
							task.wait()
						end
						for _, v241 in v_u_235 do
							v241.Transparency = NumberSequence.new(1)
						end
						if v_u_238 then
							v_u_238()
						end
					end)
					p_u_69.after(0.28, function()
						-- upvalues: (ref) v_u_198, (ref) v_u_4, (ref) v_u_197, (ref) v_u_8, (ref) v_u_193, (ref) v_u_9, (ref) v_u_195, (ref) p_u_69, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11, (ref) v_u_53, (ref) v_u_194, (ref) v_u_12, (ref) v_u_6, (ref) p_u_191
						v_u_198:Destroy()
						v_u_4.flash(v_u_197 + Vector3.new(0, 2, 0), v_u_8, 9 * v_u_193, 0.18)
						v_u_4.flash(v_u_197 + Vector3.new(0, 2, 0), v_u_9, v_u_195 * 1.1, 0.4)
						p_u_69.pop(v_u_197 + Vector3.new(0, 2, 0), v_u_10, 4 * v_u_193, v_u_195 * 1.3, 0.45, 0.5)
						v_u_4.ring(v_u_197, v_u_9, v_u_195 * 1.3, 0.5, v_u_7.Ring)
						v_u_4.ring(v_u_197, v_u_11, v_u_195 * 1.05, 0.45, v_u_7.Shockwave)
						v_u_53(v_u_197 + Vector3.new(0, 2, 0), 5 * v_u_193, v_u_194 and 2 or 8, 18)
						if not v_u_194 then
							local v242 = {
								v_u_12,
								v_u_11,
								v_u_9,
								v_u_10
							}
							p_u_69.chunks(v_u_197 + Vector3.new(0, 0.6, 0), v242, 8, 30, 0.5 * v_u_193, 0.9, false, 1)
						end
						v_u_6.play("Explosion", {
							["at"] = v_u_197,
							["volume"] = p_u_191.mine and 0.9 or 0.5
						})
						if p_u_191.mine then
							v_u_4.shake(0.4, 0.35)
						end
					end)
				end)
			end,
			["hit"] = function(p243, p_u_244, _) -- name: hit
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_68, (ref) v_u_61, (ref) v_u_53, (ref) v_u_46, (ref) v_u_7, (ref) v_u_9
				local v245 = p243.size
				local v246 = p243.ability.freeze or 3
				local v247 = p_u_69.ground
				local v248 = math.random() - 0.5
				local v249 = math.random() - 0.5
				local v_u_250 = v247(p_u_244 + Vector3.new(v248, 0, v249) * 3, 0.1)
				local v_u_251 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_250), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_251, v246 + 1)
				local v252 = Instance.new("Attachment")
				v252.Parent = v_u_251
				v_u_68(v252, v_u_250, Vector3.new(0, 1, 0))
				local v_u_253 = Instance.new("Attachment")
				v_u_253.Parent = v_u_251
				v_u_68(v_u_253, v_u_250, Vector3.new(0, 1, 0))
				local v_u_254 = v_u_61(v252, v_u_253, 0.6 * v245, 0.25 * v245, 2, v_u_251)
				v_u_254.CurveSize0 = 1.5 * v245
				p_u_69.animate(0.1, 0, function(p255)
					-- upvalues: (copy) v_u_253, (copy) v_u_250, (copy) p_u_244
					v_u_253.WorldPosition = v_u_250:Lerp(p_u_244, p255)
				end)
				v_u_53(p_u_244, 2.2 * v245, 1)
				if not p243.lite then
					v_u_46(v_u_250, 1, 4.5 * v245, v_u_7.CompulsoryWeb, v_u_9, 0.15, 0.15, v246 - 0.3, 0.3, nil, 0.3)
				end
				p_u_69.after(v246 - 0.2, function()
					-- upvalues: (copy) v_u_254, (copy) v_u_251
					local v_u_256 = { v_u_254 }
					local function v_u_257()
						-- upvalues: (ref) v_u_251
						v_u_251:Destroy()
					end
					local v_u_258 = os.clock()
					local v_u_259 = 0.2
					task.spawn(function()
						-- upvalues: (copy) v_u_258, (copy) v_u_259, (copy) v_u_256, (copy) v_u_257
						while os.clock() - v_u_258 < v_u_259 do
							local v260 = (os.clock() - v_u_258) / v_u_259
							for _, v261 in v_u_256 do
								v261.Transparency = NumberSequence.new(v260)
							end
							task.wait()
						end
						for _, v262 in v_u_256 do
							v262.Transparency = NumberSequence.new(1)
						end
						if v_u_257 then
							v_u_257()
						end
					end)
				end)
			end
		}
	}
	return v263
end