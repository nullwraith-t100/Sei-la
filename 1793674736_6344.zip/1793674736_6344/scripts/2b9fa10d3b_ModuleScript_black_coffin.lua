local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("7A2AD8")
local v_u_8 = Color3.fromRGB(190, 130, 255)
local v_u_9 = Color3.fromRGB(238, 220, 255)
local v_u_10 = Color3.fromRGB(14, 10, 20)
local v_u_11 = Color3.fromRGB(6, 4, 10)
local v_u_12 = Enum.PartType.Wedge
local v_u_13 = Enum.Material.SmoothPlastic
local function v_u_25(p14, p15, p16, p17, p18) -- name: picture
	-- upvalues: (copy) v_u_4
	local v19 = v_u_4.part
	local v20 = p15 * 2
	local v21 = p15 * 2
	local v22 = v19(Vector3.new(v20, 0.05, v21), p14, p17, {
		["transparency"] = 1
	})
	for _, v23 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p16
		v24.Color3 = p17
		v24.Transparency = p18
		v24.Parent = v22
	end
	return v22
end
local function v_u_29(p26, p27) -- name: setAlpha
	for _, v28 in p26:GetChildren() do
		if not v28:IsA("Decal") then
			continue
		end
		v28.Transparency = p27
	end
end
local function v_u_37(p30, p31, p32, p33) -- name: squareWave
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1
	local v34 = Instance.new("Attachment")
	v34.Parent = v_u_3.Terrain
	v34.WorldPosition = p30 + Vector3.new(0, 0.25, 0)
	local v35 = Instance.new("ParticleEmitter")
	v35.Texture = v_u_6.CoffinRipple
	v35.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v35.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v35.Color = ColorSequence.new(p32)
	v35.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p31 * 0.3), NumberSequenceKeypoint.new(1, p31 * 0.5) })
	v35.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.25), NumberSequenceKeypoint.new(1, 1) })
	local v36 = p33 or 0.45
	v35.Lifetime = NumberRange.new(v36)
	v35.LightEmission = 0.7
	v35.LightInfluence = 0
	v35.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v35.EmissionDirection = Enum.NormalId.Top
	v35.Speed = NumberRange.new(0.02)
	v35.SpreadAngle = Vector2.zero
	v35.Rotation = NumberRange.new(0)
	v35.Rate = 0
	v35.Parent = v34
	v35:Emit(1)
	v_u_1:AddItem(v34, v36 + 0.2)
end
local function v_u_45(p38, p39, p40, p41) -- name: squares
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v42 = false
	local v43
	if typeof(p38) == "Vector3" then
		v43 = Instance.new("Attachment")
		v43.Parent = v_u_3.Terrain
		v43.WorldPosition = p38
		v_u_1:AddItem(v43, 1.6)
	else
		v43 = p38
		v42 = true
	end
	local v44 = Instance.new("ParticleEmitter")
	v44.Texture = v_u_6.CoffinSquare
	v44.Color = ColorSequence.new(v_u_7, v_u_8)
	v44.LightEmission = 0
	v44.LightInfluence = 0
	v44.Lifetime = NumberRange.new(0.6, 1.1)
	v44.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p41), NumberSequenceKeypoint.new(0.7, p41 * 0.8), NumberSequenceKeypoint.new(1, 0) })
	v44.Transparency = NumberSequence.new(0.05)
	v44.Speed = NumberRange.new(p40 * 0.5, p40)
	v44.SpreadAngle = Vector2.new(180, 180)
	v44.Drag = 3
	v44.Acceleration = Vector3.new(0, -6, 0)
	v44.Rotation = NumberRange.new(0, 90)
	v44.RotSpeed = NumberRange.new(-200, 200)
	v44.Rate = 0
	if v42 then
		v44.Shape = Enum.ParticleEmitterShape.Box
		v44.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	end
	v44.Parent = v43
	v44:Emit(p39)
end
return function(p_u_46)
	-- upvalues: (copy) v_u_25, (copy) v_u_1, (copy) v_u_29, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_37, (copy) v_u_45, (copy) v_u_9, (copy) v_u_4, (copy) v_u_10, (copy) v_u_13, (copy) v_u_12, (copy) v_u_8, (copy) v_u_5, (copy) v_u_11
	local function v_u_62(p47, p_u_48, p_u_49, p50, p51, p52, p53) -- name: flare
		-- upvalues: (ref) v_u_25, (ref) v_u_1, (copy) p_u_46, (ref) v_u_29
		local v_u_54 = p53 or 0
		local v_u_55 = v_u_25(p47, p_u_48, p50, p51, v_u_54)
		v_u_1:AddItem(v_u_55, p52 + 0.1)
		p_u_46.animate(p52, 0, function(p56)
			-- upvalues: (copy) v_u_55, (copy) p_u_48, (copy) p_u_49, (ref) v_u_29, (copy) v_u_54
			local v57 = 1 - (1 - p56) ^ 3
			local v58 = v_u_55
			local v59 = p_u_48 + (p_u_49 - p_u_48) * v57
			local v60 = v59 * 2
			local v61 = v59 * 2
			v58.Size = Vector3.new(v60, 0.05, v61)
			v_u_29(v_u_55, v_u_54 + (1 - v_u_54) * p56 ^ 1.5)
			if p56 >= 1 then
				v_u_55:Destroy()
			end
		end)
	end
	local function v_u_74(p63, p64) -- name: skillCast
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_62, (copy) p_u_46, (ref) v_u_37, (ref) v_u_45, (ref) v_u_9, (ref) v_u_4
		local v65 = p63.size
		local v66 = p63.eye + p63.dir * 1.2
		local v67 = 0.6 * v65
		local v68 = (p64 and 4.5 or 3.2) * v65
		local v69 = v_u_6.Glow
		local v70 = v_u_7
		local v71 = v_u_3.CurrentCamera
		local v72
		if v71 then
			local v73 = v71.CFrame.Position - v66
			v72 = v73.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v73.Unit
		else
			v72 = Vector3.new(0, 0, 1)
		end
		v_u_62(p_u_46.facing(v66 + v72 * 0.3, v72), v67, v68, v69, v70, 0.22, 0.05)
		v_u_37(p63.feet, (p64 and 16 or 11) * v65, v_u_7)
		if not p63.lite then
			v_u_45(v66, p64 and 10 or 6, 9 * v65, 0.5 * v65)
			p_u_46.glint(v66, v_u_9, (p64 and 3 or 2) * v65, 0.14)
		end
		if p63.mine then
			v_u_4.shake(p64 and 0.15 or 0.07, 0.14)
		end
	end
	local function v102(p75, p76) -- name: spearShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (ref) v_u_12, (ref) v_u_8, (copy) p_u_46
		local v77 = p75.size
		local v78 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p76, v_u_7, {
			["transparency"] = 1
		})
		local v79 = Vector3.new(0.26, 0.26, 3.2) * v77
		local v80 = {
			["material"] = v_u_13
		}
		local v81 = v_u_4.part(v79, p76, v_u_10, v80)
		v81.Reflectance = 0.12
		v_u_1:AddItem(v81, 4)
		local v82 = v_u_4.part(Vector3.new(0.5, 0.5, 3) * v77, p76, v_u_7, {
			["transparency"] = 0.55
		})
		local v83 = CFrame.Angles(0, 3.141592653589793, 0)
		local v84 = 1.3 * v77
		local v85 = 0.16 * v77
		local v86 = 0.36 * v77
		local v87 = Vector3.new(v85, v86, v84)
		local v88 = {
			["material"] = v_u_13
		}
		local v89 = v_u_4.part(v87, p76, v_u_10, v88)
		v89.Reflectance = 0.12
		v_u_1:AddItem(v89, 4)
		v89.Shape = v_u_12
		local v90 = 0.16 * v77
		local v91 = 0.36 * v77
		local v92 = Vector3.new(v90, v91, v84)
		local v93 = {
			["material"] = v_u_13
		}
		local v94 = v_u_4.part(v92, p76, v_u_10, v93)
		v94.Reflectance = 0.12
		v_u_1:AddItem(v94, 4)
		v94.Shape = v_u_12
		local v95 = v_u_4.part
		local v96 = 0.22 * v77
		local v97 = 0.22 * v77
		local v98 = v84 * 0.8
		local v99 = v95(Vector3.new(v96, v97, v98), p76, v_u_8)
		v99.Shape = v_u_12
		local v100 = -1.6 * v77 - v84 / 2
		local v101 = {
			{
				["p"] = v81,
				["off"] = CFrame.identity
			},
			{
				["p"] = v82,
				["off"] = CFrame.new(0, 0, 0.1 * v77)
			},
			{
				["p"] = v89,
				["off"] = CFrame.new(0, 0, v100) * v83 * CFrame.new(0, 0.18 * v77, 0)
			},
			{
				["p"] = v94,
				["off"] = CFrame.new(0, 0, v100) * v83 * CFrame.new(0, -0.18 * v77, 0) * CFrame.Angles(0, 0, 3.141592653589793)
			},
			{
				["p"] = v99,
				["off"] = CFrame.new(0, 0, v100 - 0.05 * v77) * v83 * CFrame.new(0, 0.11 * v77, 0)
			}
		}
		p_u_46.streak(v78, v_u_8, v_u_7, 0.55 * v77, 0.14)
		if p75.mine then
			p_u_46.light(v78, v_u_7, 9 * v77)
		end
		return p_u_46.assemble(v78, v101, {}, 0, 0, {}, 0.14, 7)
	end
	local function v113(p103, p104) -- name: spearHit
		-- upvalues: (ref) v_u_37, (copy) p_u_46, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (copy) v_u_62, (ref) v_u_45
		local v105 = p103.size
		v_u_37(p_u_46.ground(p104, 0), 9 * v105, v_u_7)
		local v106 = 0.6 * v105
		local v107 = 3.4 * v105
		local v108 = v_u_6.Glow
		local v109 = v_u_8
		local v110 = v_u_3.CurrentCamera
		local v111
		if v110 then
			local v112 = v110.CFrame.Position - p104
			v111 = v112.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v112.Unit
		else
			v111 = Vector3.new(0, 0, 1)
		end
		v_u_62(p_u_46.facing(p104 + v111 * 0.3, v111), v106, v107, v108, v109, 0.18, 0.2)
		v_u_45(p104, p103.lite and 3 or 7, 14 * v105, 0.45 * v105)
		p_u_46.burst("Impact", p104, v_u_7, 0.8 * v105)
		p_u_46.hitSound(p104)
	end
	local v_u_114 = {}
	setmetatable(v_u_114, {
		["__mode"] = "k"
	})
	local function v192(p115, p116, p117) -- name: openBind
		-- upvalues: (copy) p_u_46, (copy) v_u_114, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_37, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13, (ref) v_u_6, (ref) v_u_9
		local v_u_118 = p115.size
		local v_u_119 = p115.ability.radius * v_u_118
		local v_u_120 = p115.ability.duration or 1.6
		local v121 = p117 + v_u_120 + 1
		local v_u_122 = p_u_46.ground(p116, 0)
		local v123 = p115.lite
		local v_u_124 = {
			["g"] = nil,
			["panels"] = nil,
			["seal"] = nil,
			["beams"] = nil,
			["radius"] = nil,
			["spin"] = 0,
			["alive"] = true,
			["g"] = v_u_122,
			["panels"] = {},
			["seal"] = {},
			["beams"] = {},
			["radius"] = v_u_119 * 0.95
		}
		v_u_114[p115] = v_u_124
		for _ = 1, 4 do
			local v125 = v_u_4.part
			local v126 = v_u_119 * 1.7
			local v127 = 0.35 * v_u_118
			local v128 = v125(Vector3.new(v126, 0.15, v127), CFrame.new(v_u_122), v_u_8, {
				["transparency"] = 0.15
			})
			v_u_1:AddItem(v128, v121)
			local v129 = v_u_124.seal
			table.insert(v129, v128)
		end
		v_u_37(v_u_122, v_u_119 * 2.2, v_u_7)
		local v130 = {}
		for _ = 1, 9 do
			local v131 = 2.4 * v_u_118
			local v132 = 2.4 * v_u_118
			local v133 = 0.3 * v_u_118
			local v134 = Vector3.new(v131, v132, v133)
			local v135 = CFrame.new(v_u_122)
			local v136 = {
				["material"] = v_u_13
			}
			local v137 = v_u_4.part(v134, v135, v_u_10, v136)
			v137.Reflectance = 0.12
			v_u_1:AddItem(v137, v121)
			local v138
			if v123 then
				v138 = nil
			else
				local v139 = v_u_4.part
				local v140 = 2.9 * v_u_118
				local v141 = 2.9 * v_u_118
				local v142 = 0.12 * v_u_118
				v138 = v139(Vector3.new(v140, v141, v142), CFrame.new(v_u_122), v_u_7, {
					["transparency"] = 0.2
				})
				v_u_1:AddItem(v138, v121)
			end
			local v143 = Instance.new("Attachment")
			v143.Parent = v137
			table.insert(v130, v143)
			local v144 = v_u_124.panels
			table.insert(v144, {
				["slab"] = nil,
				["frame"] = nil,
				["angle"] = 0,
				["slab"] = v137,
				["frame"] = v138
			})
		end
		for v145 = 1, 9 do
			local v146 = Instance.new("Beam")
			v146.Attachment0 = v130[v145]
			v146.Attachment1 = v130[(v145 + 3) % 9 + 1]
			v146.Texture = v_u_6.Beam
			v146.TextureMode = Enum.TextureMode.Wrap
			v146.TextureLength = 6
			v146.TextureSpeed = 3
			v146.Color = ColorSequence.new(v_u_8)
			v146.LightEmission = 0.8
			v146.LightInfluence = 0
			v146.FaceCamera = true
			v146.Width0 = 0.4 * v_u_118
			v146.Width1 = 0.4 * v_u_118
			v146.Transparency = NumberSequence.new(1)
			v146.Segments = 1
			v146.Parent = v130[v145]
			local v147 = v_u_124.beams
			table.insert(v147, v146)
		end
		local v_u_148 = math.max(p117, 0.08)
		local v_u_149 = os.clock()
		local v_u_150 = v_u_149
		local v_u_151 = v_u_148
		local v_u_152 = p115.ability.tick or 0.32
		local v_u_153 = -10
		p_u_46.runNow(function()
			-- upvalues: (copy) v_u_124, (ref) v_u_150, (copy) v_u_149, (copy) v_u_148, (copy) v_u_120, (copy) v_u_119, (ref) v_u_151, (copy) v_u_152, (ref) v_u_153, (ref) v_u_37, (copy) v_u_122, (ref) v_u_7, (copy) v_u_118, (ref) v_u_9
			if not v_u_124.alive then
				return false
			end
			local v154 = os.clock()
			local v155 = v154 - v_u_150
			local v156 = math.min(v155, 0.05)
			v_u_150 = v154
			local v157 = v154 - v_u_149
			local v158 = v157 / v_u_148
			local v159 = math.clamp(v158, 0, 1) - 1
			local v160 = v159 * 2.7 * v159 * v159 + 1 + v159 * 1.7 * v159
			local v161 = (v157 - v_u_148) / v_u_120
			local v162 = math.clamp(v161, 0, 1)
			v_u_124.radius = v_u_119 * (0.95 - v162 * 0.5 * v162)
			local v163 = v_u_124
			v163.spin = v163.spin + v156 * (v162 * 0.8 + 0.5)
			if v_u_151 <= v157 then
				v_u_151 = v_u_151 + v_u_152
				v_u_153 = v157
				v_u_37(v_u_122, v_u_124.radius * 2.1, v_u_7, 0.35)
			end
			local v164 = -(v157 - v_u_153) * 9
			local v165 = math.exp(v164)
			for v166, v167 in v_u_124.panels do
				local v168 = (v160 * 4.8 + -2) * v_u_118
				local v169 = v157 * 3 + v166
				local v170 = v168 + math.sin(v169) * 0.15 * v_u_118
				local v171 = v_u_122
				local v172 = v_u_124.radius
				local v173 = v_u_124.spin + (v166 - 1) * 3.141592653589793 * 2 / 9
				local v174 = math.cos(v173) * v172
				local v175 = math.sin(v173) * v172
				local v176 = v171 + Vector3.new(v174, v170, v175)
				local v177 = CFrame.lookAt
				local v178 = v171.X
				local v179 = v176.Y
				local v180 = v171.Z
				local v181 = v177(v176, (Vector3.new(v178, v179, v180)))
				v167.slab.CFrame = v181
				local v182 = v167.frame
				if not v182 then
					continue
				end
				v182.CFrame = v181
				v182.Transparency = 0.2 - v165 * 0.2
				v182.Color = v_u_7:Lerp(v_u_9, v165 * 0.6)
			end
			local v183 = (v157 - v_u_148 * 0.5) / 0.15
			local v184 = 1 - math.clamp(v183, 0, 1) * (v165 * 0.2 + 0.75)
			for _, v185 in v_u_124.beams do
				v185.Transparency = NumberSequence.new(v184)
			end
			local v186 = v_u_124.radius * 1.8
			for v187, v188 in v_u_124.seal do
				local v189 = CFrame.Angles(0, -v_u_124.spin * 0.5 + (v187 - 1) * 3.141592653589793 / 2, 0)
				v188.CFrame = CFrame.new(v_u_122 + Vector3.new(0, 0.12, 0)) * v189 * CFrame.new(0, 0, v186 / 2)
				local v190 = v186 + 0.35 * v_u_118
				local v191 = 0.35 * v_u_118
				v188.Size = Vector3.new(v190, 0.15, v191)
				v188.Transparency = 0.15 - v165 * 0.15
			end
			return true
		end)
	end
	local function v219(p193, p194) -- name: crushBind
		-- upvalues: (copy) v_u_114, (copy) p_u_46, (ref) v_u_4, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (copy) v_u_62, (ref) v_u_37, (ref) v_u_45, (ref) v_u_5
		local v_u_195 = p193.size
		local v196 = p193.ability.radius * v_u_195
		local v197 = p193.lite
		local v198 = v_u_114[p193]
		v_u_114[p193] = nil
		local v199
		if v198 then
			v199 = v198.g
		else
			v199 = p_u_46.ground(p194, 0)
		end
		if v198 then
			for _, v200 in v198.panels do
				v200.slab:Destroy()
				local v201 = v200.frame
				if not v201 then
					continue
				end
				v201:Destroy()
			end
			for _, v202 in v198.seal do
				v202:Destroy()
			end
		end
		local v_u_203 = v199 + Vector3.new(0, 2.8, 0) * v_u_195
		local v204 = Vector3.new(2, 2, 2) * v_u_195
		local v205 = CFrame.new(v_u_203)
		local v206 = {
			["material"] = v_u_13
		}
		local v_u_207 = v_u_4.part(v204, v205, v_u_10, v206)
		v_u_207.Reflectance = 0.12
		v_u_1:AddItem(v_u_207, 0.5)
		local v_u_208 = v_u_4.part(Vector3.new(2.6, 2.6, 2.6) * v_u_195, CFrame.new(v_u_203), v_u_7, {
			["transparency"] = 0.4
		})
		v_u_1:AddItem(v_u_208, 0.5)
		p_u_46.animate(0.32, 0, function(p209)
			-- upvalues: (copy) v_u_195, (copy) v_u_207, (copy) v_u_203, (copy) v_u_208
			local v210
			if p209 < 0.3 then
				v210 = p209 / 0.3
			else
				v210 = 1 - (p209 - 0.3) / 0.7
			end
			local v211 = 6.5 * v_u_195 * math.max(v210, 0.02)
			v_u_207.Size = Vector3.new(1, 1, 1) * v211
			v_u_207.CFrame = CFrame.new(v_u_203) * CFrame.Angles(p209 * 2, p209 * 3, p209)
			v_u_208.Size = Vector3.new(1, 1, 1) * v211 * 1.25
			v_u_208.CFrame = v_u_207.CFrame
			v_u_208.Transparency = 0.4 + 0.6 * p209
			if p209 >= 1 then
				v_u_207:Destroy()
				v_u_208:Destroy()
			end
		end)
		local v212 = 2 * v_u_195
		local v213 = 11 * v_u_195
		local v214 = v_u_6.Glow
		local v215 = v_u_8
		local v216 = v_u_3.CurrentCamera
		local v217
		if v216 then
			local v218 = v216.CFrame.Position - v_u_203
			v217 = v218.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v218.Unit
		else
			v217 = Vector3.new(0, 0, 1)
		end
		v_u_62(p_u_46.facing(v_u_203 + v217 * 0.3, v217), v212, v213, v214, v215, 0.3, 0.1)
		v_u_37(v199, v196 * 2.8, v_u_7, 0.55)
		v_u_45(v_u_203, v197 and 8 or 22, 30 * v_u_195, 0.8 * v_u_195)
		p_u_46.burst("Impact", v_u_203, v_u_7, 2 * v_u_195)
		if not v197 then
			p_u_46.spikes(v_u_203, v_u_8, 10, v196, 0.3, nil, nil, true)
		end
		v_u_5.play("Explosion", {
			["at"] = v_u_203,
			["volume"] = p193.mine and 0.8 or 0.45
		})
		if p193.mine then
			v_u_4.shake(0.4, 0.35)
		end
	end
	local v_u_220 = {}
	setmetatable(v_u_220, {
		["__mode"] = "k"
	})
	local function v_u_227(p221, p222) -- name: sideFrames
		local v223 = {}
		for v224 = 0, 3 do
			local v225 = CFrame.Angles(0, v224 * 3.141592653589793 / 2, 0)
			local v226 = CFrame.new(p221) * v225 * CFrame.new(0, 0, -p222)
			table.insert(v223, v226)
		end
		return v223
	end
	local function v_u_230(p228, p229) -- name: edgeOffsets
		return { CFrame.new(p228, 0, 0), CFrame.new(0, p229 / 2, 0) }
	end
	local function v_u_286(p231, p232, p233) -- name: raiseCoffin
		-- upvalues: (copy) p_u_46, (ref) v_u_4, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (ref) v_u_11, (ref) v_u_6, (ref) v_u_8, (copy) v_u_220, (copy) v_u_227, (ref) v_u_37, (ref) v_u_7, (copy) v_u_230
		local v_u_234 = p231.size
		local v235 = p231.ability.radius * v_u_234
		local v_u_236 = p_u_46.ground(p232, 0)
		local v237 = v235 * 0.6
		local v_u_238 = 16 * v_u_234
		local v239 = p233 + 2.5
		local v240 = 1.2 * v_u_234
		local v241 = p231.feet - v_u_236
		local v242 = p231.mine
		if v242 then
			local v243 = v241.X
			if math.abs(v243) < v237 + 3 then
				local v244 = v241.Z
				v242 = math.abs(v244) < v237 + 3
			else
				v242 = false
			end
		end
		local v_u_245 = v242 and 0.6 or 0
		local v_u_246 = {
			["g"] = nil,
			["half"] = nil,
			["height"] = nil,
			["walls"] = nil,
			["edges"] = nil,
			["lid"] = nil,
			["alpha"] = nil,
			["closed"] = false,
			["g"] = v_u_236,
			["half"] = v237,
			["height"] = v_u_238,
			["walls"] = {},
			["edges"] = {}
		}
		local v247 = v237 * 2 + v240
		local v248 = v237 * 2 + v240
		local v249 = Vector3.new(v247, v240, v248)
		local v250 = CFrame.new(v_u_236 + Vector3.new(0, 60, 0))
		local v251 = {
			["material"] = v_u_13
		}
		local v252 = v_u_4.part(v249, v250, v_u_10, v251)
		v252.Reflectance = 0.12
		v_u_1:AddItem(v252, v239)
		v252.Color = v_u_11
		v252.Reflectance = 0
		v_u_246.lid = v252
		v_u_246.alpha = v_u_245
		v_u_246.lid.Transparency = 1
		local v253 = v_u_246.lid
		local v254 = Enum.NormalId.Top
		local v255 = Instance.new("Decal")
		v255.Face = v254
		v255.Texture = v_u_6.CrackLines
		v255.Color3 = v_u_8
		v255.Transparency = 1
		v255.Parent = v253
		v_u_220[p231] = v_u_246
		local v_u_256 = v_u_227(v_u_236, v237)
		for _, v257 in v_u_256 do
			local v258 = v237 * 2
			local v259 = 0.8 * v_u_234
			local v260 = Vector3.new(v258, v_u_238, v259)
			local v261 = {
				["material"] = v_u_13
			}
			local v262 = v_u_4.part(v260, v257, v_u_10, v261)
			v262.Reflectance = 0.12
			v_u_1:AddItem(v262, v239)
			v262.Color = v_u_11
			v262.Reflectance = 0
			v262.Transparency = v_u_245
			local v263 = Enum.NormalId.Front
			local v264 = Instance.new("Decal")
			v264.Face = v263
			v264.Texture = v_u_6.CrackLines
			v264.Color3 = v_u_8
			v264.Transparency = 1
			v264.Parent = v262
			local v265 = v_u_246.walls
			table.insert(v265, v262)
			local v266 = v_u_4.part
			local v267 = v_u_238 + v240
			local v268 = v266(Vector3.new(v240, v267, v240), v257, v_u_8)
			local v269 = v_u_4.part
			local v270 = v237 * 2 + v240
			local v271 = v269(Vector3.new(v270, v240, v240), v257, v_u_8)
			v_u_1:AddItem(v268, v239)
			v_u_1:AddItem(v271, v239)
			local v272 = v_u_246.edges
			table.insert(v272, v268)
			local v273 = v_u_246.edges
			table.insert(v273, v271)
		end
		v_u_37(v_u_236, v237 * 3, v_u_7)
		v_u_4.ring(v_u_236, v_u_7, v235, 0.3, v_u_6.Ring)
		local v_u_274 = v_u_230(v237, v_u_238)
		local v275 = math.max(p233, 0.1)
		p_u_46.animate(v275, 0, function(p276)
			-- upvalues: (copy) v_u_246, (copy) v_u_238, (copy) v_u_256, (copy) v_u_274, (copy) v_u_245, (copy) v_u_236, (copy) v_u_234
			if not v_u_246.closed then
				local v277 = p276 / 0.8
				local v278 = math.min(v277, 1) - 1
				local v279 = v278 * 2.7 * v278 * v278 + 1 + v278 * 1.7 * v278
				local v280 = math.min(v279, 1.08)
				local v281 = -v_u_238 / 2 + v_u_238 * v280
				for v282, v283 in v_u_246.walls do
					local v284 = v_u_256[v282] * CFrame.new(0, v281, 0)
					v283.CFrame = v284
					v_u_246.edges[v282 * 2 - 1].CFrame = v284 * v_u_274[1]
					v_u_246.edges[v282 * 2].CFrame = v284 * v_u_274[2]
				end
				if p276 >= 0.6 then
					local v285 = (p276 - 0.6) / 0.4
					v_u_246.lid.Transparency = v_u_245
					v_u_246.lid.CFrame = CFrame.new(v_u_236 + Vector3.new(0, 1, 0) * (v_u_238 + 7 * v_u_234 * (1 - v285) * (1 - v285)))
				end
			end
		end)
	end
	local function v_u_318(p_u_287, p288, p289, p_u_290, p291, p_u_292) -- name: stab
		-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (ref) v_u_11, (ref) v_u_8, (copy) p_u_46, (ref) v_u_45, (ref) v_u_6, (ref) v_u_3, (copy) v_u_62
		local v_u_293 = p_u_287.size
		local v_u_294 = CFrame.lookAt(p288, p288 + p289)
		local v295 = 1.4 * v_u_293
		local v296 = 1.4 * v_u_293
		local v297 = Vector3.new(v295, v296, p_u_290)
		local v298 = p291 + 0.5
		local v299 = {
			["material"] = v_u_13
		}
		local v_u_300 = v_u_4.part(v297, v_u_294, v_u_10, v299)
		v_u_300.Reflectance = 0.12
		v_u_1:AddItem(v_u_300, v298)
		v_u_300.Color = v_u_11
		v_u_300.Reflectance = 0
		local v301 = v_u_4.part
		local v302 = 0.9 * v_u_293
		local v303 = 0.9 * v_u_293
		local v304 = 4 * v_u_293
		local v_u_305 = v301(Vector3.new(v302, v303, v304), v_u_294, v_u_8)
		v_u_1:AddItem(v_u_305, p291 + 0.5)
		p_u_46.animate(0.08, 0, function(p306)
			-- upvalues: (copy) p_u_290, (copy) v_u_294, (copy) v_u_300, (copy) v_u_305, (copy) v_u_293, (ref) v_u_45, (copy) p_u_292, (copy) p_u_287, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (ref) v_u_62, (ref) p_u_46
			local v307 = p_u_290 * (0.2 + 0.8 * (1 - (1 - p306) ^ 2))
			local v308 = v_u_294 * CFrame.new(0, 0, -v307 + p_u_290 / 2)
			v_u_300.CFrame = v308
			v_u_305.CFrame = v308 * CFrame.new(0, 0, -p_u_290 / 2 - 1.2 * v_u_293)
			if p306 >= 1 then
				v_u_45(p_u_292, p_u_287.lite and 2 or 6, 14 * v_u_293, 0.7 * v_u_293)
				local v309 = p_u_292
				local v310 = 1 * v_u_293
				local v311 = 4.5 * v_u_293
				local v312 = v_u_6.Glow
				local v313 = v_u_8
				local v314 = v_u_3.CurrentCamera
				local v315
				if v314 then
					local v316 = v314.CFrame.Position - v309
					v315 = v316.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v316.Unit
				else
					v315 = Vector3.new(0, 0, 1)
				end
				v_u_62(p_u_46.facing(v309 + v315 * 0.3, v315), v310, v311, v312, v313, 0.22, 0.1)
			end
		end)
		p_u_46.after(p291, function()
			-- upvalues: (ref) p_u_46, (copy) v_u_300, (copy) v_u_305
			p_u_46.animate(0.25, 0, function(p317)
				-- upvalues: (ref) v_u_300, (ref) v_u_305
				v_u_300.Transparency = p317
				v_u_305.Transparency = p317
				if p317 >= 1 then
					v_u_300:Destroy()
					v_u_305:Destroy()
				end
			end)
		end)
	end
	local v414 = {
		["black_coffin_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["keep"] = 0.3,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p319) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_62, (copy) p_u_46, (ref) v_u_45
				local v320 = p319.size
				local v321 = p319.eye + p319.dir * 1.1
				local v322 = 0.4 * v320
				local v323 = 2 * v320
				local v324 = v_u_6.Glow
				local v325 = v_u_7
				local v326 = v_u_3.CurrentCamera
				local v327
				if v326 then
					local v328 = v326.CFrame.Position - v321
					v327 = v328.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v328.Unit
				else
					v327 = Vector3.new(0, 0, 1)
				end
				v_u_62(p_u_46.facing(v321 + v327 * 0.3, v327), v322, v323, v324, v325, 0.12, 0.1)
				if not p319.lite then
					v_u_45(v321, 2, 6 * v320, 0.35 * v320)
				end
			end,
			["shot"] = v102,
			["impact"] = v113,
			["hit"] = function(_, p329, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7
				p_u_46.burst("Impact", p329, v_u_7, 0.55)
			end
		},
		["black_coffin_e"] = {
			["castSound"] = "Bind",
			["loopSound"] = "ModeLoop",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p330) -- name: cast
				-- upvalues: (copy) v_u_74
				v_u_74(p330, false)
			end,
			["windup"] = v192,
			["zone"] = function(p_u_331, _, _) -- name: zone
				-- upvalues: (copy) v_u_114, (copy) p_u_46
				return function()
					-- upvalues: (copy) p_u_331, (ref) v_u_114, (ref) p_u_46
					local v332 = p_u_331
					local v_u_333 = v_u_114[v332]
					if v_u_333 then
						v_u_333.alive = false
						local v_u_334 = v332.size
						local v_u_335 = v_u_333.g
						local v_u_336 = v_u_333.radius
						local v_u_337 = v_u_333.spin
						p_u_46.animate(0.12, 0, function(p338)
							-- upvalues: (copy) v_u_336, (copy) v_u_334, (copy) v_u_333, (copy) v_u_335, (copy) v_u_337
							local v339 = v_u_336 + (1.2 * v_u_334 - v_u_336) * p338 * p338
							for v340, v341 in v_u_333.panels do
								local v342 = v_u_335
								local v343 = v_u_337
								local v344 = 2.8 * v_u_334
								local v345 = v343 + (v340 - 1) * 3.141592653589793 * 2 / 9
								local v346 = math.cos(v345) * v339
								local v347 = math.sin(v345) * v339
								local v348 = v342 + Vector3.new(v346, v344, v347)
								local v349 = CFrame.lookAt
								local v350 = v342.X
								local v351 = v348.Y
								local v352 = v342.Z
								local v353 = v349(v348, (Vector3.new(v350, v351, v352)))
								v341.slab.CFrame = v353
								local v354 = v341.frame
								if not v354 then
									continue
								end
								v354.CFrame = v353
							end
							for _, v355 in v_u_333.beams do
								v355.Transparency = NumberSequence.new(0.1 + 0.9 * p338)
							end
						end)
					end
				end
			end,
			["finish"] = v219,
			["hit"] = function(p356, p357, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_8
				p_u_46.burst("Impact", p357, v_u_7, 0.45)
				if not p356.lite then
					p_u_46.glint(p357, v_u_8, 1.6, 0.1)
				end
			end
		},
		["black_coffin_r"] = {
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["land"] = nil,
			["hit"] = nil,
			["cast"] = function(p358) -- name: cast
				-- upvalues: (copy) v_u_74
				v_u_74(p358, true)
			end,
			["windup"] = v_u_286,
			["land"] = function(p_u_359, p360) -- name: closeCoffin
				-- upvalues: (copy) v_u_220, (copy) v_u_286, (copy) v_u_227, (copy) v_u_230, (ref) v_u_4, (ref) v_u_37, (ref) v_u_8, (ref) v_u_5, (copy) p_u_46, (copy) v_u_318, (ref) v_u_7, (ref) v_u_1, (ref) v_u_45, (ref) v_u_6, (ref) v_u_3, (copy) v_u_62
				local v_u_361 = p_u_359.size
				local v_u_362 = p_u_359.ability.radius * v_u_361
				local v_u_363 = p_u_359.lite
				local v_u_364 = v_u_220[p_u_359]
				v_u_220[p_u_359] = nil
				if not v_u_364 then
					v_u_286(p_u_359, p360, 0)
					v_u_364 = v_u_220[p_u_359]
					v_u_220[p_u_359] = nil
				end
				if v_u_364 then
					v_u_364.closed = true
					local v_u_365 = v_u_364.g
					local v_u_366 = v_u_364.half
					local v_u_367 = v_u_364.height
					local v368 = v_u_227(v_u_365, v_u_366)
					local v369 = v_u_230(v_u_366, v_u_367)
					for v370, v371 in v_u_364.walls do
						local v372 = v368[v370] * CFrame.new(0, v_u_367 / 2, 0)
						v371.CFrame = v372
						v_u_364.edges[v370 * 2 - 1].CFrame = v372 * v369[1]
						v_u_364.edges[v370 * 2].CFrame = v372 * v369[2]
					end
					v_u_364.lid.CFrame = CFrame.new(v_u_365 + Vector3.new(0, 1, 0) * v_u_367)
					v_u_364.lid.Transparency = v_u_364.alpha
					local v_u_373 = table.clone(v_u_364.walls)
					local v374 = v_u_364.lid
					table.insert(v_u_373, v374)
					for _, v375 in v_u_373 do
						local v376 = v375:FindFirstChildOfClass("Decal")
						if not v376 then
							continue
						end
						v_u_4.tween(v376, 0.12, {
							["Transparency"] = 0.05
						})
					end
					v_u_37(v_u_365, v_u_366 * 3.4, v_u_8, 0.5)
					v_u_5.play("Burst", {
						["at"] = v_u_365,
						["volume"] = p_u_359.mine and 0.9 or 0.5
					})
					if p_u_359.mine then
						v_u_4.shake(0.45, 0.35)
					end
					for v_u_377 = 1, v_u_363 and 6 or 16 do
						local v378 = (v_u_377 - 1) % 5
						local v_u_379
						if v378 == 4 then
							local v380 = math.random() - 0.5
							local v381 = math.random() - 0.5
							v_u_379 = Vector3.new(v380, 1.6, v381).Unit
						else
							local v382 = v378 * 3.141592653589793 / 2 + (math.random() - 0.5) * 1.1
							local v383 = math.sin(v382)
							local v384 = 0.1 + math.random() * 0.55
							local v385 = -math.cos(v382)
							v_u_379 = Vector3.new(v383, v384, v385).Unit
						end
						local v386 = (math.random() - 0.5) * v_u_366
						local v387 = (0.3 + math.random() * 0.4) * v_u_367
						local v388 = (math.random() - 0.5) * v_u_366
						local v_u_389 = v_u_365 + Vector3.new(v386, v387, v388)
						local v390 = v_u_379.X
						local v391 = math.abs(v390)
						local v392 = v_u_379.Z
						local v393 = math.abs(v392)
						local v394 = v_u_366 / math.max(v391, v393, 0.05)
						local v395 = v_u_365.Y + v_u_367 - v_u_389.Y
						local v396 = v_u_379.Y
						local v397 = v395 / math.max(v396, 0.05)
						local v398 = math.min(v394, v397)
						local v_u_399 = v_u_389 + v_u_379 * v398
						local v_u_400 = v398 + 12 * v_u_361
						p_u_46.after((v_u_377 - 1) * 0.035, function()
							-- upvalues: (ref) v_u_318, (copy) p_u_359, (copy) v_u_389, (ref) v_u_379, (copy) v_u_400, (copy) v_u_377, (copy) v_u_399, (ref) v_u_5
							v_u_318(p_u_359, v_u_389, v_u_379, v_u_400, 0.85 - (v_u_377 - 1) * 0.035, v_u_399)
							if v_u_377 % 4 == 1 then
								v_u_5.play("Hit", {
									["at"] = v_u_399,
									["volume"] = p_u_359.mine and 0.6 or 0.3
								})
							end
						end)
					end
					p_u_46.after(0.85, function()
						-- upvalues: (copy) v_u_373, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_45, (copy) v_u_363, (copy) v_u_361, (ref) v_u_364, (copy) v_u_365, (copy) v_u_367, (copy) v_u_362, (ref) v_u_6, (ref) v_u_8, (ref) v_u_3, (ref) v_u_62, (ref) p_u_46, (ref) v_u_37, (copy) v_u_366, (ref) v_u_5, (copy) p_u_359
						for _, v401 in v_u_373 do
							local v402 = v_u_4.part(v401.Size, v401.CFrame, v_u_7, {
								["transparency"] = 1
							})
							v_u_1:AddItem(v402, 1.5)
							v_u_45(v402, v_u_363 and 7 or 22, 22 * v_u_361, 1.1 * v_u_361)
							v401:Destroy()
						end
						for _, v403 in v_u_364.edges do
							v403:Destroy()
						end
						local v404 = v_u_365 + Vector3.new(0, 1, 0) * v_u_367 * 0.45
						local v405 = 4 * v_u_361
						local v406 = v_u_362 * 1.3
						local v407 = v_u_6.Glow
						local v408 = v_u_8
						local v409 = v_u_3.CurrentCamera
						local v410
						if v409 then
							local v411 = v409.CFrame.Position - v404
							v410 = v411.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v411.Unit
						else
							v410 = Vector3.new(0, 0, 1)
						end
						v_u_62(p_u_46.facing(v404 + v410 * 0.3, v410), v405, v406, v407, v408, 0.35, 0.1)
						v_u_37(v_u_365, v_u_366 * 5, v_u_7, 0.6)
						v_u_4.ring(v_u_365, v_u_7, v_u_362 * 1.3, 0.55, v_u_6.Shockwave)
						v_u_4.ring(v_u_365, v_u_8, v_u_362 * 1.6, 0.7, v_u_6.Ring)
						p_u_46.burst("Impact", v404, v_u_7, 2.4 * v_u_361)
						p_u_46.burst("Flash", v404, v_u_7, 0.7 * v_u_361)
						v_u_5.play("Explosion", {
							["at"] = v404,
							["volume"] = p_u_359.mine and 1 or 0.6
						})
						if p_u_359.mine then
							v_u_4.shake(0.55, 0.45)
						end
					end)
				end
			end,
			["hit"] = function(p412, p413, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_45
				p_u_46.burst("Impact", p413, v_u_7, 0.8)
				if not p412.lite then
					v_u_45(p413, 3, 8, 0.5)
				end
			end
		}
	}
	return v414
end