local v_u_1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserFixOrbitalCameraAzimuth")
require(script.Parent:WaitForChild("CameraUtils"))
local v_u_2 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_3 = game:GetService("Players")
local v_u_4 = require(script.Parent:WaitForChild("BaseCamera"))
local v_u_5 = setmetatable({}, v_u_4)
v_u_5.__index = v_u_5
function v_u_5.new() -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v6 = v_u_4.new()
	local v7 = v_u_5
	local v8 = setmetatable(v6, v7)
	v8.lastUpdate = tick()
	v8.changedSignalConnections = {}
	v8.refAzimuthRad = nil
	v8.curAzimuthRad = nil
	v8.minAzimuthAbsoluteRad = nil
	v8.maxAzimuthAbsoluteRad = nil
	v8.useAzimuthLimits = nil
	v8.curElevationRad = nil
	v8.minElevationRad = nil
	v8.maxElevationRad = nil
	v8.curDistance = nil
	v8.minDistance = nil
	v8.maxDistance = nil
	v8.gamepadDollySpeedMultiplier = 1
	v8.lastUserPanCamera = tick()
	v8.externalProperties = {}
	v8.externalProperties.InitialDistance = 25
	v8.externalProperties.MinDistance = 10
	v8.externalProperties.MaxDistance = 100
	v8.externalProperties.InitialElevation = 35
	v8.externalProperties.MinElevation = 35
	v8.externalProperties.MaxElevation = 35
	v8.externalProperties.ReferenceAzimuth = -45
	v8.externalProperties.CWAzimuthTravel = 90
	v8.externalProperties.CCWAzimuthTravel = 90
	v8.externalProperties.UseAzimuthLimits = false
	v8:LoadNumberValueParameters()
	return v8
end
function v_u_5.LoadOrCreateNumberValueParameter(p_u_9, p_u_10, p11, p_u_12) -- name: LoadOrCreateNumberValueParameter
	local v13 = script:FindFirstChild(p_u_10)
	if v13 and v13:IsA(p11) then
		p_u_9.externalProperties[p_u_10] = v13.Value
	else
		if p_u_9.externalProperties[p_u_10] == nil then
			return
		end
		v13 = Instance.new(p11)
		v13.Name = p_u_10
		v13.Parent = script
		v13.Value = p_u_9.externalProperties[p_u_10]
	end
	if p_u_12 then
		if p_u_9.changedSignalConnections[p_u_10] then
			p_u_9.changedSignalConnections[p_u_10]:Disconnect()
		end
		p_u_9.changedSignalConnections[p_u_10] = v13.Changed:Connect(function(p14)
			-- upvalues: (copy) p_u_9, (copy) p_u_10, (copy) p_u_12
			p_u_9.externalProperties[p_u_10] = p14
			p_u_12(p_u_9)
		end)
	end
end
function v_u_5.SetAndBoundsCheckAzimuthValues(p15) -- name: SetAndBoundsCheckAzimuthValues
	local v16 = p15.externalProperties.ReferenceAzimuth
	local v17 = math.rad(v16)
	local v18 = p15.externalProperties.CWAzimuthTravel
	local v19 = math.rad(v18)
	p15.minAzimuthAbsoluteRad = v17 - math.abs(v19)
	local v20 = p15.externalProperties.ReferenceAzimuth
	local v21 = math.rad(v20)
	local v22 = p15.externalProperties.CCWAzimuthTravel
	local v23 = math.rad(v22)
	p15.maxAzimuthAbsoluteRad = v21 + math.abs(v23)
	p15.useAzimuthLimits = p15.externalProperties.UseAzimuthLimits
	if p15.useAzimuthLimits then
		local v24 = p15.curAzimuthRad
		local v25 = p15.minAzimuthAbsoluteRad
		p15.curAzimuthRad = math.max(v24, v25)
		local v26 = p15.curAzimuthRad
		local v27 = p15.maxAzimuthAbsoluteRad
		p15.curAzimuthRad = math.min(v26, v27)
	end
end
function v_u_5.SetAndBoundsCheckElevationValues(p28) -- name: SetAndBoundsCheckElevationValues
	local v29 = p28.externalProperties.MinElevation
	local v30 = math.max(v29, -80)
	local v31 = p28.externalProperties.MaxElevation
	local v32 = math.min(v31, 80)
	local v33 = math.min(v30, v32)
	p28.minElevationRad = math.rad(v33)
	local v34 = math.max(v30, v32)
	p28.maxElevationRad = math.rad(v34)
	local v35 = p28.curElevationRad
	local v36 = p28.minElevationRad
	p28.curElevationRad = math.max(v35, v36)
	local v37 = p28.curElevationRad
	local v38 = p28.maxElevationRad
	p28.curElevationRad = math.min(v37, v38)
end
function v_u_5.SetAndBoundsCheckDistanceValues(p39) -- name: SetAndBoundsCheckDistanceValues
	p39.minDistance = p39.externalProperties.MinDistance
	p39.maxDistance = p39.externalProperties.MaxDistance
	local v40 = p39.curDistance
	local v41 = p39.minDistance
	p39.curDistance = math.max(v40, v41)
	local v42 = p39.curDistance
	local v43 = p39.maxDistance
	p39.curDistance = math.min(v42, v43)
end
function v_u_5.LoadNumberValueParameters(p44) -- name: LoadNumberValueParameters
	-- upvalues: (copy) v_u_1
	p44:LoadOrCreateNumberValueParameter("InitialElevation", "NumberValue", nil)
	p44:LoadOrCreateNumberValueParameter("InitialDistance", "NumberValue", nil)
	local v45 = "ReferenceAzimuth"
	local v46 = "NumberValue"
	local v47
	if v_u_1 then
		v47 = p44.SetAndBoundsCheckAzimuthValues
	else
		v47 = p44.SetAndBoundsCheckAzimuthValue
	end
	p44:LoadOrCreateNumberValueParameter(v45, v46, v47)
	p44:LoadOrCreateNumberValueParameter("CWAzimuthTravel", "NumberValue", p44.SetAndBoundsCheckAzimuthValues)
	p44:LoadOrCreateNumberValueParameter("CCWAzimuthTravel", "NumberValue", p44.SetAndBoundsCheckAzimuthValues)
	p44:LoadOrCreateNumberValueParameter("MinElevation", "NumberValue", p44.SetAndBoundsCheckElevationValues)
	p44:LoadOrCreateNumberValueParameter("MaxElevation", "NumberValue", p44.SetAndBoundsCheckElevationValues)
	p44:LoadOrCreateNumberValueParameter("MinDistance", "NumberValue", p44.SetAndBoundsCheckDistanceValues)
	p44:LoadOrCreateNumberValueParameter("MaxDistance", "NumberValue", p44.SetAndBoundsCheckDistanceValues)
	p44:LoadOrCreateNumberValueParameter("UseAzimuthLimits", "BoolValue", p44.SetAndBoundsCheckAzimuthValues)
	local v48 = p44.externalProperties.ReferenceAzimuth
	p44.curAzimuthRad = math.rad(v48)
	local v49 = p44.externalProperties.InitialElevation
	p44.curElevationRad = math.rad(v49)
	p44.curDistance = p44.externalProperties.InitialDistance
	p44:SetAndBoundsCheckAzimuthValues()
	p44:SetAndBoundsCheckElevationValues()
	p44:SetAndBoundsCheckDistanceValues()
end
function v_u_5.GetModuleName(_) -- name: GetModuleName
	return "OrbitalCamera"
end
function v_u_5.GetCameraToSubjectDistance(p50) -- name: GetCameraToSubjectDistance
	return p50.curDistance
end
function v_u_5.SetCameraToSubjectDistance(p51, p52) -- name: SetCameraToSubjectDistance
	-- upvalues: (copy) v_u_3
	if v_u_3.LocalPlayer then
		local v53 = p51.minDistance
		local v54 = p51.maxDistance
		p51.currentSubjectDistance = math.clamp(p52, v53, v54)
		local v55 = p51.currentSubjectDistance
		local v56 = p51.FIRST_PERSON_DISTANCE_THRESHOLD
		p51.currentSubjectDistance = math.max(v55, v56)
	end
	p51.inFirstPerson = false
	p51:UpdateMouseBehavior()
	return p51.currentSubjectDistance
end
function v_u_5.CalculateNewLookVector(p57, p58, p59) -- name: CalculateNewLookVector
	local v60 = p58 or p57:GetCameraLookVector()
	local v61 = v60.Y
	local v62 = math.asin(v61)
	local v63 = p59.Y
	local v64 = v62 - 1.3962634015954636
	local v65 = v62 - -1.3962634015954636
	local v66 = math.clamp(v63, v64, v65)
	local v67 = Vector2.new(p59.X, v66)
	local v68 = CFrame.new(Vector3.new(0, 0, 0), v60)
	return (CFrame.Angles(0, -v67.X, 0) * v68 * CFrame.Angles(-v67.Y, 0, 0)).LookVector
end
function v_u_5.Update(p69, p70) -- name: Update
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v71 = tick()
	local v72 = v71 - p69.lastUpdate
	local v73 = v_u_2.getRotation(p70) ~= Vector2.new()
	local v74 = workspace.CurrentCamera
	local v75 = v74.CFrame
	local v76 = v74.Focus
	local v77 = v_u_3.LocalPlayer
	local v78
	if v74 then
		v78 = v74.CameraSubject
	else
		v78 = v74
	end
	local v79
	if v78 then
		v79 = v78:IsA("VehicleSeat")
	else
		v79 = v78
	end
	local v80
	if v78 then
		v80 = v78:IsA("SkateboardPlatform")
	else
		v80 = v78
	end
	if p69.lastUpdate == nil or v72 > 1 then
		p69.lastCameraTransform = nil
	end
	if v73 then
		p69.lastUserPanCamera = tick()
	end
	local v81 = p69:GetSubjectPosition()
	if v81 and (v77 and v74) then
		if p69.gamepadDollySpeedMultiplier ~= 1 then
			p69:SetCameraToSubjectDistance(p69.currentSubjectDistance * p69.gamepadDollySpeedMultiplier)
		end
		v76 = CFrame.new(v81)
		local v82 = v_u_2.getRotation(p70)
		p69.curAzimuthRad = p69.curAzimuthRad - v82.X
		if p69.useAzimuthLimits then
			local v83 = p69.curAzimuthRad
			local v84 = p69.minAzimuthAbsoluteRad
			local v85 = p69.maxAzimuthAbsoluteRad
			p69.curAzimuthRad = math.clamp(v83, v84, v85)
		else
			local v86
			if p69.curAzimuthRad == 0 then
				v86 = 0
			else
				local v87 = p69.curAzimuthRad
				local v88 = math.sign(v87)
				local v89 = p69.curAzimuthRad
				v86 = v88 * (math.abs(v89) % 6.283185307179586) or 0
			end
			p69.curAzimuthRad = v86
		end
		local v90 = p69.curElevationRad + v82.Y
		local v91 = p69.minElevationRad
		local v92 = p69.maxElevationRad
		p69.curElevationRad = math.clamp(v90, v91, v92)
		local v93 = v81 + p69.currentSubjectDistance * (CFrame.fromEulerAnglesYXZ(-p69.curElevationRad, p69.curAzimuthRad, 0) * Vector3.new(0, 0, 1))
		v75 = CFrame.new(v93, v81)
		p69.lastCameraTransform = v75
		p69.lastCameraFocus = v76
		if (v79 or v80) and v78:IsA("BasePart") then
			p69.lastSubjectCFrame = v78.CFrame
		else
			p69.lastSubjectCFrame = nil
		end
	end
	p69.lastUpdate = v71
	return v75, v76
end
return v_u_5