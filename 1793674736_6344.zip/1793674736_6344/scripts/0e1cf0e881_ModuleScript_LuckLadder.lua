local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Store)
local v6 = v2.Shared
local v_u_7 = require(v6.Config.Images)
local v_u_8 = require(v6.Config.Products)
local v_u_9 = require(v6.Config.Release)
local v_u_10 = require(v6.Logic.Luck)
local v_u_11 = {}
local v_u_12 = v1.LocalPlayer
local v_u_13 = Instance.new("BindableEvent")
v_u_11.changed = v_u_13.Event
local function v_u_15(p14) -- name: owns
	-- upvalues: (copy) v_u_12
	return v_u_12:GetAttribute("Pass_" .. p14) == true
end
function v_u_11.on() -- name: on
	-- upvalues: (copy) v_u_9
	return v_u_9.luckLadder()
end
function v_u_11.tier() -- name: tier
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_8, (copy) v_u_15
	return not v_u_11.on() and 1 or v_u_10.tier(v_u_8.luckTiers, v_u_15)
end
function v_u_11.nextTier() -- name: nextTier
	-- upvalues: (copy) v_u_10, (copy) v_u_8, (copy) v_u_15
	return v_u_10.next(v_u_8.luckTiers, v_u_15)
end
function v_u_11.offer() -- name: offer
	-- upvalues: (copy) v_u_11, (copy) v_u_5, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
	if v_u_11.on() and not v_u_5.luckBlocked() then
		local v16 = v_u_11.nextTier()
		local v17
		if v16 then
			v17 = v_u_8.luckProduct[v16.key]
		else
			v17 = nil
		end
		if v17 then
			local v18 = v_u_3:IsStudio()
			if v18 then
				v18 = v_u_4:GetAttribute("DevLuckLadder") == true
			end
			if v17.id == 0 and not v18 then
				return nil
			else
				return v17
			end
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_11.picture(p19) -- name: picture
	-- upvalues: (copy) v_u_7
	local v20
	if p19 >= 8 then
		v20 = v_u_7.Icon.LuckClover5
		if not v20 then
			return v_u_7.Icon.LuckClover
		end
	else
		v20 = v_u_7.Icon.LuckClover
	end
	return v20
end
function v_u_11.buy(p21, p22) -- name: buy
	-- upvalues: (copy) v_u_11, (copy) v_u_5
	local v23 = v_u_11.offer()
	if v23 then
		v_u_5.buyProduct(v23.key, p21, p22)
	end
end
local v_u_24 = false
function v_u_11.start() -- name: start
	-- upvalues: (ref) v_u_24, (copy) v_u_12, (copy) v_u_13, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4
	if not v_u_24 then
		v_u_24 = true
		v_u_12.AttributeChanged:Connect(function(p25)
			-- upvalues: (ref) v_u_13
			if string.sub(p25, 1, 9) == "Pass_luck" then
				v_u_13:Fire()
			end
		end)
		v_u_5.randomChanged:Connect(function()
			-- upvalues: (ref) v_u_13
			v_u_13:Fire()
		end)
		v_u_5.pricesChanged:Connect(function()
			-- upvalues: (ref) v_u_13
			v_u_13:Fire()
		end)
		if v_u_3:IsStudio() then
			v_u_4:GetAttributeChangedSignal("DevLuckLadder"):Connect(function()
				-- upvalues: (ref) v_u_13
				v_u_13:Fire()
			end)
		end
	end
end
return v_u_11