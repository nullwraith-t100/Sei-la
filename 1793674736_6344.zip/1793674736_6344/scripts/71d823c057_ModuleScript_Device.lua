local v_u_1 = game:GetService("UserInputService")
return {
	["touch"] = function() -- name: touch
		-- upvalues: (copy) v_u_1
		return v_u_1.PreferredInput == Enum.PreferredInput.Touch
	end
}