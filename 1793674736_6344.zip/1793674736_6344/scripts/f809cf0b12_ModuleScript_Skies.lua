local v1 = {}
local v2 = {
	["update"] = 4,
	["set"] = nil
}
local v3 = {
	["Lighting"] = {
		["Brightness"] = 2.2,
		["Ambient"] = nil,
		["OutdoorAmbient"] = nil,
		["ColorShift_Top"] = nil,
		["ColorShift_Bottom"] = nil,
		["EnvironmentDiffuseScale"] = 0.2,
		["EnvironmentSpecularScale"] = 0.1,
		["Ambient"] = Color3.fromRGB(70, 76, 98),
		["OutdoorAmbient"] = Color3.fromRGB(118, 126, 156),
		["ColorShift_Top"] = Color3.fromRGB(206, 222, 255),
		["ColorShift_Bottom"] = Color3.fromRGB(0, 0, 0)
	},
	["Sky"] = {
		["SkyboxUp"] = "rbxassetid://93095318625919",
		["SkyboxDn"] = "rbxassetid://70680290449778",
		["SkyboxBk"] = "rbxassetid://103788769844404",
		["SkyboxFt"] = "rbxassetid://103788769844404",
		["SkyboxLf"] = "rbxassetid://103788769844404",
		["SkyboxRt"] = "rbxassetid://103788769844404",
		["CelestialBodiesShown"] = false,
		["StarCount"] = 0
	},
	["Atmosphere"] = {
		["Density"] = 0.34,
		["Offset"] = 0.05,
		["Color"] = nil,
		["Decay"] = nil,
		["Glare"] = 0,
		["Haze"] = 0.6,
		["Color"] = Color3.fromRGB(16, 19, 34),
		["Decay"] = Color3.fromRGB(6, 8, 16)
	},
	["SunRays"] = {
		["Enabled"] = false
	},
	["Grade"] = {
		["TintColor"] = nil,
		["Contrast"] = 0.12,
		["Saturation"] = 0.04,
		["TintColor"] = Color3.fromRGB(234, 240, 255)
	}
}
v2.set = v3
v1[7] = v2
local v4 = {
	["update"] = 4,
	["set"] = nil
}
local v5 = {
	["Lighting"] = {
		["Brightness"] = 1.7,
		["Ambient"] = nil,
		["OutdoorAmbient"] = nil,
		["ColorShift_Top"] = nil,
		["ColorShift_Bottom"] = nil,
		["EnvironmentDiffuseScale"] = 0.15,
		["EnvironmentSpecularScale"] = 0.1,
		["Ambient"] = Color3.fromRGB(98, 72, 66),
		["OutdoorAmbient"] = Color3.fromRGB(150, 112, 100),
		["ColorShift_Top"] = Color3.fromRGB(255, 218, 184),
		["ColorShift_Bottom"] = Color3.fromRGB(40, 6, 8)
	},
	["Sky"] = {
		["SkyboxUp"] = "rbxassetid://138776212512810",
		["SkyboxDn"] = "rbxassetid://103030312653622",
		["SkyboxBk"] = "rbxassetid://117353460317094",
		["SkyboxFt"] = "rbxassetid://117353460317094",
		["SkyboxLf"] = "rbxassetid://117353460317094",
		["SkyboxRt"] = "rbxassetid://117353460317094",
		["CelestialBodiesShown"] = false,
		["StarCount"] = 0
	},
	["Atmosphere"] = {
		["Density"] = 0.32,
		["Offset"] = 0.1,
		["Color"] = nil,
		["Decay"] = nil,
		["Glare"] = 0,
		["Haze"] = 1.6,
		["Color"] = Color3.fromRGB(120, 16, 24),
		["Decay"] = Color3.fromRGB(72, 8, 14)
	},
	["SunRays"] = {
		["Enabled"] = false
	},
	["Grade"] = {
		["TintColor"] = nil,
		["Contrast"] = 0.1,
		["Saturation"] = 0.08,
		["TintColor"] = Color3.fromRGB(255, 242, 236)
	}
}
v4.set = v5
v1[8] = v4
return v1