local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return {
		["w3_thorn_blossom"] = function(p_u_5, p6)
			-- upvalues: (copy) p_u_4, (ref) v_u_2, (ref) v_u_3
			local v_u_7 = Color3.fromHex(p6.color)
			local v8 = p_u_4.rgb(20, 6, 14)
			local v_u_9 = p_u_5.fx <= 1 and 1 or p_u_5.fx / 1.35
			local v_u_14 = p_u_4.throb(p_u_5, 3.6, 1.2, 2.2, function(p10)
				-- upvalues: (copy) v_u_9, (ref) v_u_2, (copy) v_u_7, (copy) p_u_5, (ref) v_u_3
				local v11 = p10.Position
				local v12 = -0.5 * v_u_9
				local v13 = v11 + Vector3.new(0, v12, 0)
				v_u_2.ring(v13, v_u_7, 6.5 * p_u_5.fx, 0.45, v_u_3.Shockwave)
				v_u_2.flash(v13, v_u_7, 4 * v_u_9, 0.25)
			end)
			local v_u_17 = p_u_4.group(p_u_5, function(p15, p16)
				-- upvalues: (copy) v_u_9
				return p15 * CFrame.new(0, -0.5 * v_u_9, 0) * CFrame.Angles(0, p16 * 0.35, 0)
			end)
			local v_u_18 = table.create(30, CFrame.identity)
			local v_u_19 = {}
			local v_u_20 = {}
			for _ = 1, 5 do
				for _ = 1, 4 do
					local v21 = p_u_4.bar
					local v22 = Enum.Material.SmoothPlastic
					table.insert(v_u_19, v21(Vector3.new(0.16, 0.16, 1), v8, 0, v22))
				end
				local v23 = p_u_4.bar
				local v24 = Enum.Material.SmoothPlastic
				table.insert(v_u_20, v23(Vector3.new(0.13, 0.13, 1), v8, 0, v24))
			end
			local v_u_25 = {}
			for _ = 1, 5 do
				local v26 = p_u_4.blob
				local v27 = Vector3.new(1.224, 0.1, 2.35) * v_u_9
				table.insert(v_u_25, v26(v27, v_u_7, 0.3))
			end
			local v_u_28 = -1
			local v29 = p_u_5.ticks
			local function v90()
				-- upvalues: (copy) v_u_14, (ref) v_u_28, (copy) v_u_9, (copy) v_u_19, (ref) p_u_4, (copy) v_u_18, (copy) v_u_20, (copy) v_u_25
				local v30 = v_u_14()
				if v30 ~= v_u_28 then
					v_u_28 = v30
					local v31 = 0.32 - 0.24 * v30
					local v32 = 1 + 0.12 * v30
					for v33 = 1, 5 do
						local v34 = (v33 - 1) / 5 * 3.141592653589793 * 2
						local v35 = math.cos(v34)
						local v36 = math.sin(v34)
						local v37 = Vector3.new(v35, 0, v36)
						local v38 = -math.sin(v34)
						local v39 = math.cos(v34)
						local v40 = Vector3.new(v38, 0, v39)
						local v41 = v37 * math.cos(v31) + Vector3.new(0, 1, 0) * math.sin(v31)
						local v42 = 1.25 * v_u_9 * v32
						local v43 = 3.6 * v_u_9 * v32
						local v44 = v41 * v42
						local v45 = v41 * v43
						local v46 = v41 * (v42 + (v43 - v42) * 0.42)
						local v47 = 0.72 * v_u_9 * v32
						local v48 = (v33 - 1) * 6
						local v49 = v46 + v40 * v47
						local v50 = v48 + 1
						local v51 = v_u_19[(v33 - 1) * 4 + 1]
						local v52 = 0.16 * v_u_9
						local v53, v54 = p_u_4.between(v44, v49)
						v_u_18[v50] = v53
						local v55 = v54 + v52 * 0.6
						v51.Size = Vector3.new(v52, v52, v55)
						local v56 = v46 + v40 * v47
						local v57 = v48 + 2
						local v58 = v_u_19[(v33 - 1) * 4 + 2]
						local v59 = 0.16 * v_u_9
						local v60, v61 = p_u_4.between(v56, v45)
						v_u_18[v57] = v60
						local v62 = v61 + v59 * 0.6
						v58.Size = Vector3.new(v59, v59, v62)
						local v63 = v46 - v40 * v47
						local v64 = v48 + 3
						local v65 = v_u_19[(v33 - 1) * 4 + 3]
						local v66 = 0.16 * v_u_9
						local v67, v68 = p_u_4.between(v44, v63)
						v_u_18[v64] = v67
						local v69 = v68 + v66 * 0.6
						v65.Size = Vector3.new(v66, v66, v69)
						local v70 = v46 - v40 * v47
						local v71 = v48 + 4
						local v72 = v_u_19[(v33 - 1) * 4 + 4]
						local v73 = 0.16 * v_u_9
						local v74, v75 = p_u_4.between(v70, v45)
						v_u_18[v71] = v74
						local v76 = v75 + v73 * 0.6
						v72.Size = Vector3.new(v73, v73, v76)
						local v77 = v45 + (v41 * 0.9004471023526769 + v40 * 0.43496553411123023).Unit * (1.8 * v_u_9 * (1 + 1.1 * v30))
						local v78 = v48 + 5
						local v79 = v_u_20[v33]
						local v80 = 0.13 * v_u_9
						local v81, v82 = p_u_4.between(v45, v77)
						v_u_18[v78] = v81
						local v83 = v82 + v80 * 0.6
						v79.Size = Vector3.new(v80, v80, v83)
						local v84 = v41 * (v42 + (v43 - v42) * 0.48)
						local v85 = v40:Cross(v41).Unit
						v_u_18[v48 + 6] = CFrame.lookAt(v84, v84 + v41, v85)
						local v86 = v_u_25[v33]
						local v87 = v47 * 1.7
						local v88 = 0.1 * v_u_9
						local v89 = (v43 - v42) * 0.92
						v86.Size = Vector3.new(v87, v88, v89)
					end
				end
			end
			table.insert(v29, v90)
			for v91 = 1, 5 do
				local v_u_92 = (v91 - 1) * 6
				for v93 = 1, 4 do
					local v_u_94 = v_u_92 + v93
					p_u_4.add(p_u_5, v_u_19[(v91 - 1) * 4 + v93], function()
						-- upvalues: (copy) v_u_17, (copy) v_u_18, (copy) v_u_94
						return v_u_17.cf * v_u_18[v_u_94]
					end)
				end
				p_u_4.add(p_u_5, v_u_20[v91], function()
					-- upvalues: (copy) v_u_17, (copy) v_u_18, (copy) v_u_92
					return v_u_17.cf * v_u_18[v_u_92 + 5]
				end)
				p_u_4.add(p_u_5, v_u_25[v91], function()
					-- upvalues: (copy) v_u_17, (copy) v_u_18, (copy) v_u_92
					return v_u_17.cf * v_u_18[v_u_92 + 6]
				end)
			end
			local v_u_95 = p_u_4.crownOf(p_u_5)
			for v96 = 1, 5 do
				local v_u_97 = (v96 - 0.5) / 5 * 3.141592653589793 * 2
				p_u_4.add(p_u_5, p_u_4.bar(Vector3.new(0.14, 0.14, 0.95) * v_u_9, v8, 0, Enum.Material.SmoothPlastic), function(p98)
					-- upvalues: (copy) v_u_95, (copy) v_u_14, (copy) v_u_97, (copy) v_u_9
					local v99 = v_u_95(p98)
					local v100 = v_u_14()
					local v101 = v_u_97
					local v102 = math.cos(v101) * 0.5
					local v103 = v_u_97
					local v104 = math.sin(v103) * 0.5
					local v105 = Vector3.new(v102, 0.42, v104) * v_u_9
					local v106 = v_u_97
					local v107 = math.cos(v106) * 0.55
					local v108 = v_u_97
					local v109 = math.sin(v108) * 0.55
					local v110 = Vector3.new(v107, 1, v109).Unit
					local v111 = v105 + v110 * 0.45 * v_u_9 * (1 + v100 * 0.3)
					return v99 * CFrame.lookAt(v111, v111 + v110)
				end)
			end
			p_u_4.particles(p_u_5, "Petals", v_u_7, {
				["rate"] = 0.8,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Petals", "Motes" }
			})
			p_u_4.particles(p_u_5, "AuraMode", v_u_7, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "FlameBack", "Sparks" }
			})
		end
	}
end