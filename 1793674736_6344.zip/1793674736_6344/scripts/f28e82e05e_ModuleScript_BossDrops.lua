local v1 = {
	["list"] = {
		{
			["id"] = "fox_slayer",
			["kind"] = "title",
			["chance"] = 0.02,
			["what"] = "TITLE",
			["colors"] = nil,
			["stroke"] = "#3A0800",
			["glow"] = "#FF6A1A",
			["colors"] = {
				"#FFF1A8",
				"#FFC23A",
				"#FF7A1A",
				"#FF3A14",
				"#D9161E",
				"#FF7A1A"
			}
		},
		{
			["id"] = "dark_kyubi",
			["kind"] = "aura",
			["chance"] = 0.005,
			["what"] = "AURA",
			["colors"] = nil,
			["stroke"] = "#0C0002",
			["glow"] = "#FF1E2E",
			["colors"] = {
				"#FFB3AA",
				"#FF3B3B",
				"#E3122E",
				"#A00A1E",
				"#E3122E",
				"#FF3B3B"
			}
		},
		{
			["id"] = "shadow_kyubi",
			["kind"] = "pet",
			["chance"] = 0.002,
			["what"] = "MYTHIC PET",
			["colors"] = nil,
			["stroke"] = "#08000E",
			["glow"] = "#A62BFF",
			["colors"] = {
				"#F2D2FF",
				"#C65CFF",
				"#9B2CFF",
				"#6A12C8",
				"#9B2CFF",
				"#C65CFF"
			}
		}
	},
	["byId"] = {}
}
for _, v2 in v1.list do
	v1.byId[v2.id] = v2
end
v1.DUPLICATE_COINS = 100
v1.AURA_BETTER = 0.2
v1.PET_TIMES_BEST_FREE = 3
v1.TITLES = {
	["fox_slayer"] = {
		["text"] = "FOX SLAYER",
		["rank"] = 2.5
	}
}
v1.SHOW_AFTER = 1.4
return v1