local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.EpicKit8)
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.BlackBolt, v_u_7.BlackFork, v_u_7.Glow })
local v_u_8 = Color3.fromHex("B03CFF")
local v_u_9 = Color3.fromRGB(240, 216, 255)
local v_u_10 = Color3.fromRGB(255, 48, 80)
local v_u_11 = Color3.fromRGB(14, 4, 18)
local v_u_12 = Color3.fromRGB(60, 20, 80)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.Material.SmoothPlastic
local function v_u_28(p16, p17, p18, p19) -- name: bolt
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_13
	local v20 = v_u_3.holder(p16, p19 + 0.1)
	local v21 = v_u_3.holder(p17, p19 + 0.1)
	local v22 = v_u_3.beam
	local v23 = v_u_7.BlackBolt
	local v24 = v_u_13
	local v25 = p18 * 1.6
	local v26 = p18 * 5
	local v_u_27 = v22(v20, v21, v23, v24, v25, 0, math.max(v26, 2.5), 10)
	v_u_27.Width1 = p18 * 1.1
	task.delay(p19, function()
		-- upvalues: (copy) v_u_27
		v_u_27.Enabled = false
	end)
end
local function v_u_47(p29, p30, p31, p32, p33) -- name: zigzag
	local v34 = p30 - p29
	local v35 = v34.Magnitude
	local v36 = v35 / p31
	local v37 = math.floor(v36)
	local v38 = math.clamp(v37, 2, 14)
	local v39 = v35 <= 0.001 and Vector3.new(1, 0, 0) or v34 / v35
	local v40 = v39.Y
	local v41 = math.abs(v40) > 0.9 and Vector3.new(1, 0, 0) or v39:Cross(Vector3.new(0, 1, 0)).Unit
	local v42 = v39:Cross(v41).Unit
	local v43 = { p29 }
	for v44 = 1, v38 - 1 do
		local v45 = v41 * (math.random() - 0.5) * 2 * p32
		if not p33 then
			v45 = v45 + v42 * (math.random() - 0.5) * 2 * p32
		end
		local v46 = p29 + v34 * (v44 / v38) + v45
		table.insert(v43, v46)
	end
	table.insert(v43, p30)
	return v43
end
local function v_u_58(p48, p49, p50, p_u_51) -- name: crawl
	-- upvalues: (copy) v_u_28
	local v52 = #p48 - 1
	for v53 = 1, v52 do
		local v_u_54 = p48[v53]
		local v_u_55 = p48[v53 + 1]
		local v_u_56 = p49 * (1 - (v53 - 1) * 0.35 / math.max(v52, 1))
		local v57 = p50 * (v53 - 1) / math.max(v52, 1)
		if v57 <= 0.005 then
			v_u_28(v_u_54, v_u_55, v_u_56, p_u_51)
		else
			task.delay(v57, function()
				-- upvalues: (ref) v_u_28, (copy) v_u_54, (copy) v_u_55, (copy) v_u_56, (copy) p_u_51
				v_u_28(v_u_54, v_u_55, v_u_56, p_u_51)
			end)
		end
	end
end
local function v_u_62(p59, p60, p61) -- name: fork
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_13
	v_u_3.flat(p59, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.2,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["image"] = v_u_7.BlackFork,
		["color"] = v_u_13,
		["life"] = p61,
		["sizes"] = {
			{ 0, p60 * 0.4 },
			{ 0.15, p60 },
			{ 1, p60 * 1.05 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 0.6, 0.15 },
			{ 1, 1 }
		}
	})
end
local function v_u_66(p63, p64, p65) -- name: flash
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8
	v_u_3.puff(p63, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.9,
		["count"] = 1,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["image"] = v_u_7.Glow,
		["color"] = v_u_8,
		["life"] = { p65, p65 },
		["sizes"] = {
			{ 0, p64 * 0.5 },
			{ 1, p64 }
		},
		["alphas"] = {
			{ 0, 0.1 },
			{ 1, 1 }
		},
		["speed"] = { 0 }
	})
end
local function v_u_71(p67, p68, p69, p70) -- name: sparks
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_13, (copy) v_u_10
	v_u_3.puff(p67, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 1,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["accel"] = Vector3.new(0, -30, 0),
		["orient"] = nil,
		["squash"] = 1.5,
		["image"] = v_u_7.Glow,
		["color"] = v_u_13,
		["color2"] = v_u_10,
		["count"] = p68,
		["life"] = { 0.25, 0.45 },
		["sizes"] = {
			{ 0, p70 },
			{ 1, p70 * 0.15 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 1, 0.6 }
		},
		["speed"] = { p69 * 0.5, p69 },
		["orient"] = Enum.ParticleOrientation.VelocityParallel
	})
end
return function(p_u_72)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_58, (copy) v_u_47, (copy) v_u_62, (copy) v_u_4, (copy) v_u_1, (copy) v_u_3, (copy) v_u_7, (copy) v_u_13, (copy) v_u_10, (copy) v_u_66, (copy) v_u_71, (copy) v_u_11, (copy) v_u_12, (copy) v_u_6, (copy) v_u_15, (copy) v_u_14
	local v73 = {}
	local function v_u_82(p74, p75) -- name: thunderCast
		-- upvalues: (copy) p_u_72, (ref) v_u_8, (ref) v_u_9, (ref) v_u_58, (ref) v_u_47, (ref) v_u_62, (ref) v_u_4
		local v76 = p74.size
		p_u_72.burst("Flash", p74.eye, v_u_8, (p75 and 0.3 or 0.2) * v76)
		p_u_72.glint(p74.eye + p74.dir * 0.8, v_u_9, (p75 and 4 or 3) * v76, 0.16)
		for _ = 1, p74.lite and 1 or (p75 and 4 or 2) do
			local v77 = p74.dir
			local v78 = math.random() - 0.5
			local v79 = math.random() - 0.3
			local v80 = math.random() - 0.5
			local v81 = (v77 + Vector3.new(v78, v79, v80)).Unit
			v_u_58(v_u_47(p74.eye, p74.eye + v81 * 4 * v76, 1.2, 0.5, false), 0.5 * v76, 0.05, 0.12)
		end
		v_u_62(p_u_72.ground(p74.feet, 0.12), (p75 and 9 or 6) * v76, 0.4)
		if p74.mine then
			v_u_4.shake(p75 and 0.12 or 0.06, 0.14)
		end
	end
	v73.black_thunder_a = {
		["cast"] = function(p83) -- name: cast
			-- upvalues: (copy) p_u_72, (ref) v_u_8, (ref) v_u_58, (ref) v_u_47
			local v84 = p83.size
			p_u_72.glint(p83.eye + p83.dir * 1.2, v_u_8, 2.4 * v84, 0.1)
			if not p83.lite then
				v_u_58(v_u_47(p83.eye, p83.eye + p83.dir * 3 * v84, 1, 0.4, false), 0.4 * v84, 0, 0.08)
			end
		end,
		["shot"] = function(p85, p86) -- name: lanceShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_3, (ref) v_u_7, (ref) v_u_13, (ref) v_u_10, (copy) p_u_72
			local v_u_87 = p85.size
			local v88 = 6 * v_u_87
			local v_u_89 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p86, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_89, 3)
			local v90 = Instance.new("Attachment")
			v90.Parent = v_u_89
			local v91 = Instance.new("Attachment")
			v91.Position = Vector3.new(0, 0, v88)
			v91.Parent = v_u_89
			local v_u_92 = v_u_3.beam(v90, v91, v_u_7.BlackBolt, v_u_13, 2 * v_u_87, 0, 5 * v_u_87, 14)
			v_u_92.Width1 = 1 * v_u_87
			local v93 = Instance.new("ParticleEmitter")
			v93.Texture = v_u_7.Glow
			v93.Color = ColorSequence.new(v_u_8)
			v93.LightEmission = 0.9
			v93.LightInfluence = 0
			v93.Lifetime = NumberRange.new(0.08)
			v93.Speed = NumberRange.new(0)
			v93.Size = NumberSequence.new(1.2 * v_u_87)
			v93.LockedToPart = true
			v93.Rate = 30
			v93.Parent = v90
			if not p85.lite then
				local v94 = Instance.new("ParticleEmitter")
				v94.Texture = v_u_7.Glow
				v94.Color = ColorSequence.new(v_u_13, v_u_10)
				v94.LightEmission = 1
				v94.LightInfluence = 0
				v94.Orientation = Enum.ParticleOrientation.VelocityParallel
				v94.Squash = NumberSequence.new(1.5)
				v94.Lifetime = NumberRange.new(0.15, 0.3)
				v94.Size = v_u_3.seq({
					{ 0, 0.3 },
					{ 1, 0.05 }
				}, v_u_87)
				v94.Speed = NumberRange.new(4, 9)
				v94.SpreadAngle = Vector2.new(180, 180)
				v94.Rate = 40
				v94.Parent = v91
			end
			if p85.mine then
				p_u_72.light(v_u_89, v_u_8, 7 * v_u_87)
			end
			local v_u_95 = false
			return {
				["place"] = function(p96, p97) -- name: place
					-- upvalues: (copy) v_u_89, (copy) v_u_92, (copy) v_u_87
					v_u_89.CFrame = p96
					local v98 = v_u_92
					local v99 = p97 * 60
					local v100 = math.sin(v99)
					v98.Width0 = (math.abs(v100) * 0.6 + 1.7) * v_u_87
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_95, (copy) v_u_92, (copy) v_u_89, (ref) v_u_1
					if not v_u_95 then
						v_u_95 = true
						v_u_92.Enabled = false
						for _, v101 in v_u_89:GetDescendants() do
							if v101:IsA("ParticleEmitter") then
								v101.Enabled = false
							else
								if not v101:IsA("PointLight") then
									continue
								end
								v101:Destroy()
							end
						end
						v_u_1:AddItem(v_u_89, 0.4)
					end
				end
			}
		end,
		["impact"] = function(p102, p103) -- name: impact
			-- upvalues: (copy) p_u_72, (ref) v_u_62, (ref) v_u_66, (ref) v_u_58, (ref) v_u_47, (ref) v_u_71
			local v104 = p102.size
			local v105 = p_u_72.ground(p103, 0.1)
			v_u_62(v105, 7 * v104, 0.4)
			v_u_66(p103, 5 * v104, 0.25)
			if not p102.lite then
				for _ = 1, 2 do
					local v106 = math.random() - 0.5
					local v107 = math.random() - 0.5
					local v108 = v105 + Vector3.new(v106, 0, v107) * 3 * v104 + Vector3.new(0, 4, 0) * v104
					v_u_58(v_u_47(v105 + Vector3.new(0, 0.3, 0), v108, 1.2, 0.6, false), 0.45 * v104, 0.04, 0.12)
				end
				v_u_71(p103, 8, 18, 0.5 * v104)
			end
			p_u_72.hitSound(p103)
		end,
		["hit"] = function(_, p109, _) -- name: hit
			-- upvalues: (copy) p_u_72, (ref) v_u_8
			p_u_72.burst("Impact", p109, v_u_8, 0.55)
		end
	}
	v73.black_thunder_e = {
		["cast"] = function(p110) -- name: cast
			-- upvalues: (copy) v_u_82
			v_u_82(p110, false)
		end,
		["windup"] = function(p111, p112, p113) -- name: windup
			-- upvalues: (ref) v_u_58, (ref) v_u_47, (copy) p_u_72
			local v114 = p111.size
			local v115 = math.max(p113, 0.12)
			v_u_58(v_u_47(p_u_72.ground(p111.feet, 0.4), p_u_72.ground(p112, 0.4), 3 * v114, 1.2 * v114, true), 0.8 * v114, v115, 0.35)
		end,
		["zone"] = function(p_u_116, p117, p118) -- name: zone
			-- upvalues: (copy) p_u_72, (ref) v_u_3, (ref) v_u_7, (ref) v_u_11, (ref) v_u_62, (ref) v_u_58, (ref) v_u_47, (ref) v_u_66
			local v_u_119 = p_u_116.size
			local v_u_120 = p_u_116.lite
			local v_u_121 = p_u_116.ability.radius * v_u_119
			local v_u_122 = p_u_72.ground(p117, 0.1)
			v_u_3.flat(v_u_122, {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0,
				["life"] = nil,
				["sizes"] = nil,
				["alphas"] = nil,
				["image"] = v_u_7.Glow,
				["color"] = v_u_11,
				["life"] = p118 + 0.5,
				["sizes"] = {
					{ 0, v_u_121 * 0.6 },
					{ 0.1, v_u_121 * 2.2 },
					{ 1, v_u_121 * 2.3 }
				},
				["alphas"] = {
					{ 0, 0.6 },
					{ 0.1, 0.3 },
					{ 0.8, 0.35 },
					{ 1, 1 }
				}
			})
			v_u_62(v_u_122 + Vector3.new(0, 0.02, 0), v_u_121 * 1.8, 0.6)
			local v_u_123 = os.clock()
			local v_u_124 = 0
			local v_u_125 = false
			p_u_72.frame(function()
				-- upvalues: (ref) v_u_125, (copy) v_u_123, (ref) v_u_124, (copy) p_u_116, (copy) v_u_120, (copy) v_u_122, (copy) v_u_121, (ref) v_u_58, (ref) v_u_47, (copy) v_u_119, (ref) v_u_62, (ref) v_u_66
				if v_u_125 then
					return false
				end
				if v_u_124 <= os.clock() - v_u_123 then
					v_u_124 = v_u_124 + (p_u_116.ability.tick or 0.32)
					for _ = 1, v_u_120 and 2 or 4 do
						local v126 = math.random() * 3.141592653589793 * 2
						local v127 = v_u_122
						local v128 = math.cos(v126)
						local v129 = math.sin(v126)
						local v130 = v127 + Vector3.new(v128, 0, v129) * v_u_121 + Vector3.new(0, 0.3, 0)
						local v131 = v_u_122
						local v132 = math.random() - 0.5
						local v133 = math.random() - 0.5
						v_u_58(v_u_47(v130, v131 + Vector3.new(v132, 0, v133) * v_u_121 * 0.3 + Vector3.new(0, 0.3, 0), 2 * v_u_119, 0.9 * v_u_119, true), 0.6 * v_u_119, 0.1, 0.22)
						if v_u_120 then
							continue
						end
						v_u_62(v130 - Vector3.new(0, 0.2, 0), 3 * v_u_119, 0.3)
					end
					v_u_66(v_u_122 + Vector3.new(0, 1, 0), 4 * v_u_119, 0.2)
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_125
				v_u_125 = true
			end
		end,
		["finish"] = function(p134, p135) -- name: finish
			-- upvalues: (copy) p_u_72, (ref) v_u_58, (ref) v_u_47, (ref) v_u_62, (ref) v_u_66, (ref) v_u_71, (ref) v_u_11, (ref) v_u_12, (ref) v_u_6, (ref) v_u_4
			local v136 = p134.size
			local v137 = p134.lite
			local v138 = p134.ability.radius * v136
			local v139 = p_u_72.ground(p135, 0.1)
			v_u_58(v_u_47(v139 + Vector3.new(0, 45, 0), v139, 7, 2.5, false), 2.6 * v136, 0.06, 0.35)
			v_u_62(v139, v138 * 2.6, 0.7)
			v_u_66(v139 + Vector3.new(0, 2, 0), v138 * 1.2, 0.35)
			for v140 = 1, v137 and 4 or 8 do
				local v141 = v140 * 3.141592653589793 * 2 / (v137 and 4 or 8) + math.random() * 0.4
				local v142 = math.cos(v141)
				local v143 = math.sin(v141)
				local v144 = v139 + Vector3.new(v142, 0, v143) * v138 * 1.1 + Vector3.new(0, 0.3, 0)
				v_u_58(v_u_47(v139 + Vector3.new(0, 0.3, 0), v144, 2 * v136, 1 * v136, true), 0.7 * v136, 0.12, 0.3)
			end
			if not v137 then
				v_u_71(v139 + Vector3.new(0, 1, 0), 16, 26, 0.7 * v136)
				local v145 = { v_u_11, v_u_12 }
				p_u_72.chunks(v139 + Vector3.new(0, 0.5, 0), v145, 8, 26, 0.5 * v136, 0.8, false, 0.8)
			end
			v_u_6.play("Explosion", {
				["at"] = v139,
				["volume"] = p134.mine and 0.85 or 0.45
			})
			if p134.mine then
				v_u_4.shake(0.3, 0.3)
			end
		end,
		["hit"] = function(_, p146, _) -- name: hit
			-- upvalues: (copy) p_u_72, (ref) v_u_8
			p_u_72.burst("Impact", p146, v_u_8, 0.6)
		end
	}
	local function v_u_169(p147, p148) -- name: head
		-- upvalues: (ref) v_u_3, (ref) v_u_11, (ref) v_u_15, (ref) v_u_8, (ref) v_u_14, (ref) v_u_9
		local v149 = {}
		local v150 = v_u_3.part(v_u_11, v_u_15, p148)
		v150.Reflectance = 0.15
		local v151 = CFrame.new(0, 0.2, 0.4)
		v150.Size = Vector3.new(1.6, 1.2, 2.2) * p147
		local v152 = {
			["p"] = v150,
			["off"] = CFrame.new(v151.Position * p147) * v151.Rotation
		}
		table.insert(v149, v152)
		local v153 = v_u_3.wedge(v_u_11, v_u_15, p148)
		local v154 = CFrame.new(0, 0.25, -1.6)
		v153.Size = Vector3.new(1.3, 0.8, 1.8) * p147
		local v155 = {
			["p"] = v153,
			["off"] = CFrame.new(v154.Position * p147) * v154.Rotation
		}
		table.insert(v149, v155)
		local v156 = v_u_3.wedge(v_u_8, v_u_14, p148)
		local v157 = CFrame.new(0, -0.5, -1.1) * CFrame.Angles(0.35, 0, 0) * CFrame.Angles(0, 0, 3.141592653589793)
		v156.Size = Vector3.new(1.1, 0.5, 2) * p147
		local v158 = {
			["p"] = v156,
			["off"] = CFrame.new(v157.Position * p147) * v157.Rotation
		}
		table.insert(v149, v158)
		for _, v159 in { -1, 1 } do
			local v160 = v_u_3.wedge(v_u_8, v_u_14, p148)
			local v161 = CFrame.new(v159 * 0.55, 0.85, 1.3) * CFrame.Angles(0.45, v159 * 0.25, 0) * CFrame.Angles(0, 3.141592653589793, 0)
			v160.Size = Vector3.new(0.28, 0.45, 2.4) * p147
			local v162 = {
				["p"] = v160,
				["off"] = CFrame.new(v161.Position * p147) * v161.Rotation
			}
			table.insert(v149, v162)
		end
		local v163 = v_u_3.part(v_u_9, v_u_14, p148)
		local v164 = CFrame.new(0, 0.45, -0.35)
		v163.Size = Vector3.new(1.7, 0.18, 0.3) * p147
		local v165 = {
			["p"] = v163,
			["off"] = CFrame.new(v164.Position * p147) * v164.Rotation
		}
		table.insert(v149, v165)
		local v166 = v_u_3.wedge(v_u_8, v_u_14, p148)
		local v167 = CFrame.new(0, 0.95, 0.9) * CFrame.Angles(0, 3.141592653589793, 0)
		v166.Size = Vector3.new(0.2, 0.7, 1.2) * p147
		local v168 = {
			["p"] = v166,
			["off"] = CFrame.new(v167.Position * p147) * v167.Rotation
		}
		table.insert(v149, v168)
		return v149
	end
	local function v_u_236(p_u_170, p_u_171, p_u_172) -- name: dragon
		-- upvalues: (ref) v_u_3, (copy) v_u_169, (ref) v_u_7, (ref) v_u_13, (copy) p_u_72, (ref) v_u_58, (ref) v_u_47, (ref) v_u_62, (ref) v_u_11, (ref) v_u_66, (ref) v_u_71, (ref) v_u_6
		local v_u_173 = p_u_170.size
		local v_u_174 = p_u_170.lite
		local v175 = p_u_172 - p_u_171
		local v176 = v175.Magnitude
		local v_u_177 = math.max(v176, 1)
		local v_u_178 = v175 / v_u_177
		local v_u_179 = v_u_3.side(v_u_178)
		local v_u_180 = v_u_179:Cross(v_u_178).Unit
		local v_u_181 = v_u_169(3 * v_u_173, 1.1)
		local v182 = v_u_174 and 5 or 10
		local v_u_183 = 2.8 * v_u_173 / v_u_177
		local v_u_184 = {}
		for _ = 0, v182 do
			local v185 = v_u_3.holder
			table.insert(v_u_184, v185(p_u_171, 1.1))
		end
		local v_u_186 = {}
		for v187 = 1, v182 do
			local v188 = 5 * v_u_173 * (1 - (v187 - 1) / v182 * 0.7)
			local v189 = v_u_3.beam(v_u_184[v187], v_u_184[v187 + 1], v_u_7.BlackBolt, v_u_13, v188, 0, 7 * v_u_173, 12)
			v189.Width1 = v188 * 0.85
			table.insert(v_u_186, v189)
		end
		local v_u_190 = 0
		local v_u_191 = os.clock()
		p_u_72.frame(function()
			-- upvalues: (copy) v_u_191, (copy) p_u_171, (copy) v_u_178, (copy) v_u_177, (copy) v_u_179, (copy) v_u_173, (copy) v_u_180, (copy) v_u_181, (copy) v_u_184, (copy) v_u_183, (copy) v_u_186, (copy) v_u_174, (ref) v_u_190, (ref) p_u_72, (ref) v_u_58, (ref) v_u_47, (ref) v_u_62
			local v192 = os.clock() - v_u_191
			local v193 = v192 / 0.5
			local v194 = 1 - (1 - math.min(v193, 1)) ^ 1.5
			local v195 = (v192 - 0.5) / 0.3
			local v196 = math.clamp(v195, 0, 1)
			local v197 = p_u_171 + v_u_178 * v_u_177 * v194
			local v198 = v_u_179
			local v199 = v194 * 3.141592653589793 * 3
			local v200 = v197 + v198 * math.sin(v199) * 2.5 * v_u_173
			local v201 = v_u_180
			local v202 = v194 * 3.141592653589793 * 2 + 0.6
			local v203 = v200 + v201 * math.sin(v202) * 1.5 * v_u_173
			local v204 = v194 + 0.01
			local v205 = math.min(v204, 1.01)
			local v206 = p_u_171 + v_u_178 * v_u_177 * v205
			local v207 = v_u_179
			local v208 = v205 * 3.141592653589793 * 3
			local v209 = v206 + v207 * math.sin(v208) * 2.5 * v_u_173
			local v210 = v_u_180
			local v211 = v205 * 3.141592653589793 * 2 + 0.6
			local v212 = v209 + v210 * math.sin(v211) * 1.5 * v_u_173
			local v213 = CFrame.lookAt
			if (v212 - v203).Magnitude <= 0.001 then
				v212 = v203 + v_u_178
			end
			local v214 = v213(v203, v212)
			for _, v215 in v_u_181 do
				v215.p.CFrame = v214 * v215.off
				v215.p.Transparency = v196
			end
			for v216, v217 in v_u_184 do
				local v218 = v194 - (v216 - 1) * v_u_183
				local v219 = math.max(v218, 0)
				local v220 = p_u_171 + v_u_178 * v_u_177 * v219
				local v221 = v_u_179
				local v222 = v219 * 3.141592653589793 * 3
				local v223 = v220 + v221 * math.sin(v222) * 2.5 * v_u_173
				local v224 = v_u_180
				local v225 = v219 * 3.141592653589793 * 2 + 0.6
				v217.WorldPosition = v223 + v224 * math.sin(v225) * 1.5 * v_u_173
			end
			for _, v226 in v_u_186 do
				v226.Transparency = NumberSequence.new(v196)
			end
			if not v_u_174 and (v192 < 0.5 and v_u_190 <= v192) then
				v_u_190 = v192 + 0.07
				local v227 = p_u_72.ground(v203, 0.2)
				v_u_58(v_u_47(v203, v227, 1.5, 0.6, false), 0.6 * v_u_173, 0.03, 0.12)
				v_u_62(v227, 4 * v_u_173, 0.35)
			end
			if v192 < 1.1 then
				return true
			end
			for _, v228 in v_u_181 do
				v228.p:Destroy()
			end
			for _, v229 in v_u_186 do
				v229:Destroy()
			end
			return false
		end)
		p_u_72.groundLine(p_u_171, p_u_172, 3 * v_u_173, v_u_11, 1.3, 0.25)
		p_u_72.after(0.5, function()
			-- upvalues: (ref) p_u_72, (copy) p_u_172, (ref) v_u_62, (copy) v_u_173, (ref) v_u_66, (copy) v_u_174, (ref) v_u_58, (ref) v_u_47, (ref) v_u_71, (ref) v_u_6, (copy) p_u_170
			v_u_62(p_u_72.ground(p_u_172, 0.1), 12 * v_u_173, 0.6)
			v_u_66(p_u_172, 9 * v_u_173, 0.3)
			for v230 = 1, v_u_174 and 3 or 6 do
				local v231 = v230 * 3.141592653589793 * 2 / (v_u_174 and 3 or 6)
				local v232 = p_u_172
				local v233 = math.cos(v231)
				local v234 = (math.random() - 0.3) * 0.8
				local v235 = math.sin(v231)
				v_u_58(v_u_47(p_u_172, v232 + Vector3.new(v233, v234, v235) * 7 * v_u_173, 1.5, 0.8, false), 0.8 * v_u_173, 0.06, 0.18)
			end
			if not v_u_174 then
				v_u_71(p_u_172, 14, 24, 0.6 * v_u_173)
			end
			v_u_6.play("Explosion", {
				["at"] = p_u_172,
				["volume"] = p_u_170.mine and 0.8 or 0.45
			})
		end)
	end
	v73.black_thunder_r = {
		["cast"] = function(p237) -- name: cast
			-- upvalues: (copy) v_u_82
			v_u_82(p237, true)
		end,
		["windup"] = function(p238, p239, p240) -- name: windup
			-- upvalues: (copy) p_u_72, (ref) v_u_8, (ref) v_u_58, (ref) v_u_47
			local v241 = p238.size
			local v242 = math.max(p240, 0.12)
			p_u_72.inward(p239, v_u_8, p238.lite and 4 or 10, 6 * v241, v242)
			if not p238.lite then
				for _ = 1, 3 do
					local v243 = math.random() - 0.5
					local v244 = math.random() - 0.5
					local v245 = math.random() - 0.5
					local v246 = p239 + Vector3.new(v243, v244, v245) * 4 * v241
					local v247 = math.random() - 0.5
					local v248 = math.random() - 0.5
					local v249 = math.random() - 0.5
					v_u_58(v_u_47(v246, p239 + Vector3.new(v247, v248, v249) * 4 * v241, 1, 0.5, false), 0.5 * v241, 0.03, v242)
				end
			end
		end,
		["beam"] = function(p250, p251, p252) -- name: beam
			-- upvalues: (copy) v_u_236, (ref) v_u_4
			v_u_236(p250, p251, p252)
			if p250.mine then
				v_u_4.shake(0.2, 0.45)
			end
		end,
		["hit"] = function(_, p253, _) -- name: hit
			-- upvalues: (copy) p_u_72, (ref) v_u_8
			p_u_72.burst("Impact", p253, v_u_8, 0.65)
		end
	}
	return v73
end