local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(235, 70, 10)
local v_u_5 = CFrame.Angles(1.5707963267948966, 0, 0)
return function(p_u_6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4
	return {
		["w5_corona_gear"] = function(p_u_7, p8)
			-- upvalues: (ref) v_u_2, (copy) p_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4
			local v9 = v_u_2.color(p8.color)
			local v_u_10 = v_u_2.color(p8.color2)
			local v11 = p_u_7.headY / 1.5
			local v_u_12 = math.clamp(v11, 0.7, 3)
			local v_u_13 = v_u_12 * 3
			local v_u_14 = -10
			local v_u_16 = p_u_6.throb(p_u_7, 4.5, 1.8, 1.1, function(p15)
				-- upvalues: (ref) v_u_2, (ref) p_u_6, (copy) p_u_7, (copy) v_u_10, (ref) v_u_3
				v_u_2.ring(p_u_6.feetAt(p_u_7, p15, 0.15), v_u_10, 5.5 * p_u_7.fx, 0.55, v_u_3.Ring)
			end)
			local v_u_17 = 0
			local v_u_18 = 0
			local v_u_19 = 0
			local v_u_20 = 0
			local v21 = p_u_7.ticks
			local function v25(_, p22, p23)
				-- upvalues: (copy) v_u_16, (ref) v_u_20, (ref) v_u_14, (ref) v_u_19, (ref) v_u_17, (ref) v_u_18
				local v24 = v_u_16()
				if v_u_20 + 0.5 < v24 then
					v_u_14 = p22
				end
				v_u_20 = v24
				v_u_19 = p22
				v_u_17 = v_u_17 + p23 * (0.7 + v24 * 4)
				v_u_18 = v_u_18 - p23 * (1.2 + v24 * 5)
			end
			table.insert(v21, v25)
			local v_u_27 = p_u_6.group(p_u_7, function(p26)
				-- upvalues: (copy) v_u_12
				return p26 * CFrame.new(0, v_u_12 * -0.15, 0) * CFrame.Angles(0.14, 0, 0.1)
			end)
			local v28 = v_u_13 * 2 * 0.1908089953765448 + v_u_12 * 0.1
			local v_u_29 = v_u_14
			local v_u_30 = v_u_19
			local v_u_31 = v_u_18
			local v_u_32 = v_u_17
			local v33 = {}
			for v_u_34 = 0, 5 do
				for _, v_u_35 in { -1, 1 } do
					local v36 = p_u_6.bar
					local v37 = v_u_12 * 0.42
					local v38 = v_u_12 * 0.3
					local v39 = v36(Vector3.new(v37, v38, v28), v9)
					p_u_6.add(p_u_7, v39, function()
						-- upvalues: (ref) v_u_32, (copy) v_u_34, (copy) v_u_35, (copy) v_u_13, (copy) v_u_27
						local v40 = v_u_32 + v_u_34 * 3.141592653589793 / 3 + v_u_35 * 0.767944870877505 / 4
						local v41 = v_u_13
						local v42 = math.cos(v40) * v41
						local v43 = math.sin(v40) * v41
						local v44 = Vector3.new(v42, 0, v43)
						local v45 = -math.sin(v40)
						local v46 = math.cos(v40)
						local v47 = Vector3.new(v45, 0, v46)
						return v_u_27.cf * CFrame.lookAt(v44, v44 + v47)
					end)
				end
				local v48 = p_u_6.bar
				local v49 = v_u_12 * 0.5
				local v50 = v_u_12 * 0.34
				local v51 = v_u_12 * 0.5
				local v52 = v48(Vector3.new(v49, v50, v51), v9)
				p_u_6.add(p_u_7, v52, function()
					-- upvalues: (ref) v_u_32, (copy) v_u_34, (copy) v_u_13, (copy) v_u_12, (copy) v_u_27
					local v53 = v_u_32 + v_u_34 * 3.141592653589793 / 3
					local v54 = v_u_13 + v_u_12 * 0.4
					local v55 = math.cos(v53) * v54
					local v56 = math.sin(v53) * v54
					local v57 = Vector3.new(v55, 0, v56)
					local v58 = -math.sin(v53)
					local v59 = math.cos(v53)
					local v60 = Vector3.new(v58, 0, v59)
					return v_u_27.cf * CFrame.lookAt(v57, v57 + v60)
				end)
				table.insert(v33, v52)
			end
			local v61 = p_u_6.picture(v_u_12 * 4.3, v_u_3.Ring, v_u_10, 0)
			p_u_6.add(p_u_7, v61, function()
				-- upvalues: (copy) v_u_27, (ref) v_u_31
				return v_u_27.cf * CFrame.Angles(0, v_u_31, 0)
			end)
			for v_u_62 = 0, 2 do
				local v63 = p_u_6.bar
				local v64 = v_u_12 * 0.3
				local v65 = v_u_12 * 0.22
				local v66 = v_u_12 * 1.15
				local v67 = v63(Vector3.new(v64, v65, v66), v_u_10)
				p_u_6.add(p_u_7, v67, function()
					-- upvalues: (ref) v_u_31, (copy) v_u_62, (copy) v_u_12, (copy) v_u_27
					local v68 = v_u_31 + v_u_62 * 3.141592653589793 * 2 / 3
					local v69 = math.cos(v68)
					local v70 = math.sin(v68)
					local v71 = Vector3.new(v69, 0, v70)
					local v72 = v71 * 1.55 * v_u_12
					return v_u_27.cf * CFrame.lookAt(v72, v72 + v71)
				end)
			end
			local v73 = p_u_6.picture(v_u_12 * 4.8, v_u_3.CoronaFlare, v9, 0.25)
			p_u_6.add(p_u_7, v73, function(p74, p75)
				-- upvalues: (copy) v_u_12, (ref) v_u_5
				return p74 * CFrame.new(0, v_u_12 * 0.9, v_u_12 * 1.3) * CFrame.Angles(0, 0, p75 * 0.3) * v_u_5
			end)
			p_u_6.fadeFromBehind(p_u_7, v73, 0.45)
			local v_u_76 = {}
			for _, v77 in {
				{ 1, 2 },
				{ 3, 4 },
				{ 5, 6 }
			} do
				local v78 = Instance.new("Attachment")
				v78.CFrame = CFrame.fromMatrix(Vector3.new(0, 0, 0), Vector3.new(0, 1, 0), Vector3.new(1, 0, 0))
				v78.Parent = v33[v77[1]]
				local v79 = Instance.new("Attachment")
				v79.CFrame = CFrame.fromMatrix(Vector3.new(0, 0, 0), Vector3.new(-0, -1, -0), Vector3.new(1, 0, 0))
				v79.Parent = v33[v77[2]]
				local v80 = Instance.new("Beam")
				v80.Attachment0 = v78
				v80.Attachment1 = v79
				v80.Texture = v_u_3.FireBeam
				v80.TextureMode = Enum.TextureMode.Wrap
				v80.TextureLength = v_u_12 * 3
				v80.TextureSpeed = 2.5
				v80.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_4), ColorSequenceKeypoint.new(0.5, v9), ColorSequenceKeypoint.new(1, v_u_4) })
				v80.LightEmission = 0.3
				v80.LightInfluence = 0
				v80.FaceCamera = true
				v80.Segments = 16
				v80.CurveSize0 = v_u_12 * 3.4
				v80.CurveSize1 = v_u_12 * 3.4
				v80.Width0 = 0
				v80.Width1 = 0
				v80.Enabled = false
				v80.Parent = v78
				table.insert(v_u_76, v80)
			end
			local v_u_81 = false
			local v82 = p_u_7.ticks
			local function v91()
				-- upvalues: (ref) v_u_30, (ref) v_u_29, (ref) v_u_81, (copy) v_u_76, (copy) v_u_12
				local v83 = (v_u_30 - v_u_29) / 1.4
				if v83 < 0 or v83 > 1 then
					if v_u_81 then
						v_u_81 = false
						for _, v84 in v_u_76 do
							v84.Enabled = false
						end
					end
				else
					v_u_81 = true
					local v85 = v83 * 3.141592653589793
					local v86 = math.sin(v85) * 1.9 * v_u_12
					local v87 = v_u_12 * 4.4
					local v88 = v83 * 3
					local v89 = v87 * (math.min(v88, 1) * 0.5 + 0.5)
					for _, v90 in v_u_76 do
						v90.Enabled = true
						v90.Width0 = v86
						v90.Width1 = v86
						v90.CurveSize0 = v89
						v90.CurveSize1 = v89
					end
				end
			end
			table.insert(v82, v91)
			p_u_6.particles(p_u_7, "AuraMode", v_u_10, {
				["rate"] = 0.45,
				["glow"] = 0.55,
				["only"] = nil,
				["only"] = { "Glow", "FlameBack", "Sparks" }
			})
			p_u_6.particles(p_u_7, "Fire", v9, {
				["rate"] = 0.5,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Embers" }
			})
		end
	}
end