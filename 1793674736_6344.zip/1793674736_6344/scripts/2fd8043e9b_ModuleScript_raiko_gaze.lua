local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromRGB(255, 206, 60)
local v_u_8 = Enum.Material.SmoothPlastic
local function v_u_17(p9, p10) -- name: piece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v11 = v_u_2:FindFirstChild("EyePieces")
	if v11 then
		v11 = v11:FindFirstChild("w6_raiko_gaze")
	end
	if not (v11 and v11:IsA("MeshPart")) then
		return nil
	end
	local v12 = v11:Clone()
	v12.Anchored = true
	v12.CanCollide = false
	v12.CanQuery = false
	v12.CanTouch = false
	v12.CastShadow = false
	v12.Massless = true
	local v13 = v11.Size.X
	local v14 = v11.Size.Y
	local v15 = v11.Size.Z
	local v16 = math.max(v13, v14, v15, 0.01)
	v12.Size = v11.Size * (p9 / v16)
	if not v12:FindFirstChildWhichIsA("SurfaceAppearance") then
		v12.Color = p10
	end
	v12.Parent = v_u_4.folder()
	return v12
end
local function v_u_23(p18, p19, p20, p21) -- name: arc
	-- upvalues: (copy) v_u_6
	local v22 = Instance.new("Beam")
	v22.Attachment0 = p18
	v22.Attachment1 = p19
	v22.Texture = v_u_6.RaikoPillar
	v22.TextureMode = Enum.TextureMode.Stretch
	v22.TextureSpeed = 2
	v22.Color = ColorSequence.new(p21)
	v22.LightEmission = 1
	v22.LightInfluence = 0
	v22.Brightness = 1.6
	v22.FaceCamera = true
	v22.Width0 = p20
	v22.Width1 = p20
	v22.Segments = 1
	v22.Enabled = false
	v22.Parent = p18
	return v22
end
return function(p_u_24)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_23, (copy) v_u_7, (copy) v_u_6, (copy) v_u_1, (copy) v_u_17, (copy) v_u_8, (copy) v_u_5
	return {
		["w6_raiko_gaze"] = function(p_u_25, p26)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (ref) v_u_23, (copy) p_u_24, (ref) v_u_7, (ref) v_u_6, (ref) v_u_1, (ref) v_u_17, (ref) v_u_8, (ref) v_u_5
			local v27 = v_u_4.color(p26.color)
			local v_u_28 = v_u_4.color(p26.color2)
			local v29 = p_u_25.headY / 1.5
			local v_u_30 = math.clamp(v29, 0.7, 3)
			local v_u_31 = v_u_30 * 1.75
			local v_u_32 = Instance.new("Attachment")
			local v_u_33 = Instance.new("Attachment")
			v_u_32.Parent = v_u_3.Terrain
			v_u_33.Parent = v_u_3.Terrain
			local v_u_34 = v_u_23(v_u_32, v_u_33, v_u_30 * 1.1, v_u_28)
			p_u_24.own(p_u_25, v_u_32)
			local v35 = p_u_25.stops
			table.insert(v35, function()
				-- upvalues: (copy) v_u_32, (copy) v_u_33
				v_u_32:Destroy()
				v_u_33:Destroy()
			end)
			local v_u_36 = 0
			local v_u_37 = Vector3.new(0, 0, 0)
			local v_u_47 = p_u_24.throb(p_u_25, 3.8, 1.8, 2.2, function(p38)
				-- upvalues: (copy) v_u_30, (copy) p_u_25, (copy) v_u_32, (ref) v_u_37, (copy) v_u_33, (copy) v_u_34, (ref) v_u_36, (ref) v_u_4, (ref) p_u_24, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (copy) v_u_28, (ref) v_u_1
				local v39 = math.random() < 0.5 and -1 or 1
				local v40 = (p38 * CFrame.new(v39 * 2.4 * v_u_30, 0, v_u_30 * 0.8)).Position
				local v41 = v40.X
				local v42 = p38.Position.Y + p_u_25.feet + 0.1
				local v43 = v40.Z
				local v44 = Vector3.new(v41, v42, v43)
				v_u_32.WorldPosition = v_u_37
				v_u_33.WorldPosition = v44
				v_u_34.Enabled = true
				v_u_36 = os.clock() + 0.16
				v_u_4.ring(p_u_24.feetAt(p_u_25, p38, 0.15), v_u_7, 5 * p_u_25.fx, 0.45, v_u_6.Ring)
				local v45 = Instance.new("Attachment")
				v45.Parent = v_u_3.Terrain
				v45.WorldPosition = v44 + Vector3.new(0, 0.8, 0)
				local v46 = Instance.new("ParticleEmitter")
				v46.Texture = v_u_6.RaikoSpark
				v46.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
				v46.FlipbookMode = Enum.ParticleFlipbookMode.Random
				v46.FlipbookFramerate = NumberRange.new(0)
				v46.FlipbookStartRandom = true
				v46.Color = ColorSequence.new(v_u_28, v_u_7)
				v46.LightEmission = 0.9
				v46.LightInfluence = 0
				v46.Size = NumberSequence.new(1.6 * p_u_25.fx)
				v46.Lifetime = NumberRange.new(0.15, 0.22)
				v46.Speed = NumberRange.new(0.5, 2)
				v46.Rotation = NumberRange.new(0, 360)
				v46.Rate = 0
				v46.Parent = v45
				v46:Emit(3)
				v_u_1:AddItem(v45, 0.5)
			end)
			local v_u_48 = 0
			local v49 = p_u_25.ticks
			local function v51(_, _, p50)
				-- upvalues: (ref) v_u_48, (copy) v_u_47
				v_u_48 = v_u_48 + p50 * (0.45 + 4 * v_u_47())
			end
			table.insert(v49, v51)
			local v_u_59 = p_u_24.group(p_u_25, function(p52, p53)
				-- upvalues: (copy) v_u_47, (copy) v_u_30
				local v54 = v_u_47()
				local v55 = CFrame.new
				local v56 = v_u_30 * 1
				local v57 = v_u_30 * 0.1
				local v58 = p53 * 1.5
				return p52 * v55(0, v56 + v57 * math.sin(v58) + v_u_30 * 0.15 * v54, v_u_30 * 1.3) * CFrame.Angles(0.08 * v54, 0, 0)
			end)
			local v60 = p_u_25.ticks
			local function v61()
				-- upvalues: (ref) v_u_37, (copy) v_u_59, (copy) v_u_34, (ref) v_u_36
				v_u_37 = v_u_59.cf.Position
				if v_u_34.Enabled and v_u_36 < os.clock() then
					v_u_34.Enabled = false
				end
			end
			table.insert(v60, v61)
			local v62 = p_u_24.picture(v_u_30 * 4.6, v_u_6.Glow, v27, 0.45)
			p_u_24.add(p_u_25, v62, function()
				-- upvalues: (copy) v_u_59, (copy) v_u_30
				return v_u_59.cf * CFrame.new(0, 0, v_u_30 * -0.3) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v_u_63 = v_u_17(v_u_30 * 3.7, v27)
			local v_u_64
			if v_u_63 then
				local v_u_65 = v_u_63.Size
				p_u_24.add(p_u_25, v_u_63, function()
					-- upvalues: (copy) v_u_63, (copy) v_u_65, (copy) v_u_47, (copy) v_u_59, (ref) v_u_48
					v_u_63.Size = v_u_65 * (1 + 0.12 * v_u_47())
					return v_u_59.cf * CFrame.Angles(0, 0, v_u_48)
				end)
				v_u_64 = v_u_48
			else
				local v66 = p_u_24.group(p_u_25, function()
					-- upvalues: (copy) v_u_59, (ref) v_u_48
					return v_u_59.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v_u_48, 0)
				end)
				p_u_24.ring(p_u_25, v66, 12, v_u_31, v_u_30 * 0.16, v_u_7)
				v_u_64 = v_u_48
				for v67 = 1, 8 do
					local v68 = v67 / 8 * 3.141592653589793 * 2
					p_u_24.pin(p_u_25, v66, p_u_24.blob(Vector3.new(0.7, 0.45, 0.7) * v_u_30, v27, 0, v_u_8), CFrame.new(math.cos(v68) * v_u_31, 0, math.sin(v68) * v_u_31))
				end
			end
			local v69 = {}
			for _ = 1, 4 do
				local v70 = p_u_24.bar(Vector3.new(0.1, 0.1, 0.1), v_u_7, 1)
				table.insert(v69, v70)
			end
			local v_u_71 = {
				0,
				1,
				2,
				3
			}
			for v_u_72, v73 in v69 do
				p_u_24.add(p_u_25, v73, function()
					-- upvalues: (copy) v_u_59, (ref) v_u_64, (copy) v_u_71, (copy) v_u_72, (copy) v_u_31, (copy) v_u_30
					return v_u_59.cf * CFrame.Angles(0, 0, v_u_64 + v_u_71[v_u_72]) * CFrame.new(v_u_31 * 0.95, 0, v_u_30 * -0.2)
				end)
			end
			local v_u_74 = {}
			for v75 = 1, 2 do
				local v76 = Instance.new("Attachment")
				v76.Parent = v69[v75 * 2 - 1]
				local v77 = Instance.new("Attachment")
				v77.Parent = v69[v75 * 2]
				local v78 = v_u_23(v76, v77, v_u_30 * 0.55, v_u_7)
				table.insert(v_u_74, v78)
			end
			local v_u_79 = 0
			local v80 = p_u_25.ticks
			local function v85(_, p81)
				-- upvalues: (ref) v_u_79, (copy) v_u_74, (copy) v_u_71
				if p81 >= v_u_79 then
					v_u_79 = p81 + 0.08 + math.random() * 0.25
					for v82, v83 in v_u_74 do
						local v84 = math.random() * 3.141592653589793 * 2
						v_u_71[v82 * 2 - 1] = v84
						v_u_71[v82 * 2] = v84 + 0.9 + math.random() * 1.6
						v83.Enabled = math.random() < 0.7
					end
				end
			end
			table.insert(v80, v85)
			local v86 = p_u_24.bar
			local v87 = p_u_25.headY - p_u_25.feet + 0.6
			local v88 = v86(Vector3.new(2.6, v87, 2) * v_u_30, v_u_7, 1)
			p_u_24.add(p_u_25, v88, function(p89)
				-- upvalues: (copy) p_u_25
				return p89 * CFrame.new(0, (p_u_25.headY + p_u_25.feet) / 2, 0)
			end)
			local v90 = Instance.new("ParticleEmitter")
			v90.Texture = v_u_6.RaikoSpark
			v90.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v90.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v90.FlipbookFramerate = NumberRange.new(0)
			v90.FlipbookStartRandom = true
			v90.Color = ColorSequence.new(v_u_28, v_u_7)
			v90.LightEmission = 0.9
			v90.LightInfluence = 0
			v90.Size = NumberSequence.new(0.7 * p_u_25.fx)
			v90.Lifetime = NumberRange.new(0.1, 0.18)
			v90.Speed = NumberRange.new(0)
			v90.Rotation = NumberRange.new(0, 360)
			v90.Shape = Enum.ParticleEmitterShape.Box
			v90.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v90:SetAttribute("BaseRate", 4)
			v90.Rate = 4 * v_u_5.formRate()
			v90.Parent = v88
			p_u_24.own(p_u_25, v88)
			p_u_24.particles(p_u_25, "AuraMode", v27, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "FlameBack", "Sparks" }
			})
		end
	}
end