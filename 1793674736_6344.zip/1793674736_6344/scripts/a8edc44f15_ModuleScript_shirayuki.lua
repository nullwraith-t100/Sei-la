local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromHex("EFFFFF")
local v_u_6 = Color3.fromRGB(170, 238, 255)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Enum.PartType.Wedge
local v_u_9 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_18(p10, p11) -- name: eyePiece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v12 = v_u_1:FindFirstChild("EyePieces")
	if v12 then
		v12 = v12:FindFirstChild(p10)
	end
	if not (v12 and v12:IsA("MeshPart")) then
		return nil
	end
	local v13 = v12:Clone()
	local v14 = v12.Size
	local v15 = v14.X
	local v16 = v14.Y
	local v17 = v14.Z
	v13.Size = v14 * (p11 / math.max(v15, v16, v17, 0.01))
	v13.Anchored = true
	v13.CanCollide = false
	v13.CanQuery = false
	v13.CanTouch = false
	v13.Massless = true
	v13.CastShadow = false
	v13.Parent = v_u_2.folder()
	return v13
end
return function(p_u_19)
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3, (copy) v_u_9, (copy) v_u_18, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
	return {
		["w6_shirayuki"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_2, (copy) p_u_19, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_9, (ref) v_u_18, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7
			local v22 = v_u_2.color(p21.color)
			local v23 = p_u_20.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v_u_25 = nil
			local v_u_28 = p_u_19.throb(p_u_20, 4.5, 1.6, 1.6, function(p26)
				-- upvalues: (ref) v_u_2, (ref) p_u_19, (copy) p_u_20, (ref) v_u_6, (ref) v_u_4, (ref) v_u_25, (ref) v_u_3
				v_u_2.ring(p_u_19.feetAt(p_u_20, p26, 0.15), v_u_6, 6 * p_u_20.fx, 0.6, v_u_4.Ring)
				local v27 = v_u_25
				if v27 then
					v27:Emit(v_u_3.level() <= 1 and 4 or 12)
				end
			end)
			local v_u_39 = p_u_19.group(p_u_20, function(p29, p30)
				-- upvalues: (copy) v_u_24, (copy) v_u_28
				local v31 = CFrame.new
				local v32 = v_u_24 * 0.8
				local v33 = p30 * 1.4
				local v34 = p29 * v31(0, v32 + math.sin(v33) * 0.1 * v_u_24, v_u_24 * 1.6)
				local v35 = CFrame.Angles
				local v36 = p30 * 0.8
				local v37 = math.sin(v36) * 0.08
				local v38 = 1 - v_u_28()
				return v34 * v35(0, 0, v37 + (v_u_28() <= 0 and 0 or v38 * v38 * (3 - 2 * v38) * 3.141592653589793 * 2))
			end)
			local v_u_40 = p_u_19.picture(v_u_24 * 10, v_u_4.Glow, v22, 0.2)
			p_u_19.pin(p_u_20, v_u_39, v_u_40, CFrame.new(0, 0, v_u_24 * -0.25) * v_u_9)
			p_u_19.fadeFromBehind(p_u_20, v_u_40, 0.5)
			local v41 = v_u_18("w6_shirayuki", v_u_24 * 4.6)
			if v41 then
				if not v41:FindFirstChildOfClass("SurfaceAppearance") then
					v41.Color = v_u_5
					v41.Material = Enum.Material.SmoothPlastic
				end
				p_u_19.pin(p_u_20, v_u_39, v41, CFrame.Angles(0, 3.141592653589793, 0))
			else
				local v_u_42 = p_u_19.group(p_u_20, function()
					-- upvalues: (copy) v_u_39
					return v_u_39.cf * CFrame.Angles(0, 0, -0.6632251157578453)
				end)
				local v43 = p_u_19.bar
				local v44 = v_u_24 * 2.5
				local v45 = v_u_24 * 0.2
				local v46 = v_u_24 * 0.06
				v41 = v43(Vector3.new(v44, v45, v46), v_u_5)
				p_u_19.pin(p_u_20, v_u_42, v41, CFrame.new(v_u_24 * 0.35, 0, 0))
				for _, v47 in { 1, -1 } do
					local v48 = p_u_19.bar
					local v49 = v_u_24 * 0.06
					local v50 = v_u_24 * 0.1
					local v51 = v_u_24 * 0.4
					local v52 = v48(Vector3.new(v49, v50, v51), v_u_5)
					v52.Shape = v_u_8
					p_u_19.pin(p_u_20, v_u_42, v52, CFrame.new(v_u_24 * 1.8, v47 * 0.05 * v_u_24, 0) * CFrame.Angles(0, -1.5707963267948966, 0) * CFrame.Angles(0, 0, v47 > 0 and 0 or 3.141592653589793))
				end
				local v53 = p_u_19.pin
				local v54 = p_u_19.bar
				local v55 = v_u_24 * 0.08
				local v56 = v_u_24 * 0.42
				local v57 = v_u_24 * 0.3
				v53(p_u_20, v_u_42, v54(Vector3.new(v55, v56, v57), v22), CFrame.new(v_u_24 * -0.95, 0, 0))
				local v58 = p_u_19.pin
				local v59 = p_u_19.bar
				local v60 = v_u_24 * 0.7
				local v61 = v_u_24 * 0.16
				local v62 = v_u_24 * 0.16
				v58(p_u_20, v_u_42, v59(Vector3.new(v60, v61, v62), v_u_7, 0, Enum.Material.SmoothPlastic), CFrame.new(v_u_24 * -1.35, 0, 0))
				for v_u_63, v_u_64 in { -0.08, 0.08 } do
					local v65 = p_u_19.bar
					local v66 = v_u_24 * 0.12
					local v67 = v_u_24 * 1.3
					local v68 = v_u_24 * 0.03
					local v69 = v65(Vector3.new(v66, v67, v68), v_u_5)
					p_u_19.add(p_u_20, v69, function(_, p70)
						-- upvalues: (copy) v_u_42, (copy) v_u_24, (copy) v_u_63, (copy) v_u_64
						local v71 = v_u_42.cf * CFrame.new(v_u_24 * -1.7, 0, 0)
						local v72 = CFrame.Angles
						local v73 = p70 * 2 + v_u_63
						return v71 * v72(0, 0, math.sin(v73) * 0.15 + 0.6632251157578453 + v_u_64) * CFrame.new(0, v_u_24 * -0.65, 0)
					end)
				end
			end
			local v74 = Instance.new("ParticleEmitter")
			v74.Texture = v_u_4.ShirayukiCrystal
			v74.Color = ColorSequence.new(v_u_7, v_u_6)
			v74.LightEmission = 0.5
			v74.LightInfluence = 0
			v74.Lifetime = NumberRange.new(0.6, 1)
			v74.Size = NumberSequence.new(v_u_24 * 0.55 * p_u_20.fx, 0)
			v74.Rotation = NumberRange.new(0, 360)
			v74.RotSpeed = NumberRange.new(-200, 200)
			v74.Speed = NumberRange.new(5 * p_u_20.fx, 10 * p_u_20.fx)
			v74.SpreadAngle = Vector2.new(180, 180)
			v74.Drag = 3
			v74.Rate = 0
			v74.Enabled = false
			v74.Parent = v41
			v_u_25 = v74
			local v_u_75 = 0
			local v76 = p_u_20.ticks
			local function v78(_, _, p77)
				-- upvalues: (ref) v_u_75, (copy) v_u_28
				v_u_75 = v_u_75 + p77 * (0.8 + v_u_28() * 2.5)
			end
			table.insert(v76, v78)
			local v_u_79 = v_u_75
			for v_u_80 = 1, 6 do
				local v_u_81 = p_u_19.picture(v_u_24 * 1.35, v_u_4.ShirayukiCrystal, v_u_5, 0)
				p_u_19.add(p_u_20, v_u_81, function(p82, p83)
					-- upvalues: (ref) v_u_79, (copy) v_u_80, (copy) v_u_28, (copy) v_u_24, (ref) p_u_19, (ref) v_u_9
					local v84 = v_u_79 + v_u_80 * 3.141592653589793 / 3
					local v85 = v_u_28() * 3.141592653589793
					local v86 = (math.sin(v85) * 1.2 + 2.3) * v_u_24
					local v87 = CFrame.new
					local v88 = p82.Position
					local v89 = v_u_24 * 0.2
					local v90 = v87(v88 + Vector3.new(0, v89, 0)) * CFrame.Angles(0.35, 0, 0.2)
					local v91 = CFrame.new
					local v92 = math.cos(v84) * v86
					local v93 = p83 * 2 + v_u_80
					local v94 = (v90 * v91(v92, math.sin(v93) * 0.15 * v_u_24, math.sin(v84) * v86)).Position
					local v95 = p_u_19.camPos() - v94
					local v96 = v95.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v95.Unit
					return CFrame.lookAt(v94, v94 + v96) * v_u_9 * CFrame.Angles(0, p83 * 1.5 + v_u_80, 0)
				end)
				local v97 = p_u_20.ticks
				table.insert(v97, function(_, p98)
					-- upvalues: (copy) v_u_24, (copy) v_u_80, (copy) v_u_28, (copy) v_u_81
					local v99 = v_u_24 * 1.35
					local v100 = p98 * 4 + v_u_80 * 1.7
					local v101 = v99 * (math.sin(v100) * 0.2 + 0.85 + v_u_28() * 0.4)
					v_u_81.Size = Vector3.new(v101, 0.05, v101)
				end)
			end
			local v102 = p_u_19.bar
			local v103 = v_u_24 * 6
			local v104 = v_u_24 * 6
			local v105 = v102(Vector3.new(v103, 0.2, v104), v_u_7, 1)
			p_u_19.add(p_u_20, v105, function(p106)
				-- upvalues: (copy) p_u_20, (copy) v_u_24
				local v107 = CFrame.new
				local v108 = p106.Position
				local v109 = p_u_20.headY + v_u_24 * 3
				return v107(v108 + Vector3.new(0, v109, 0))
			end)
			local v110 = Instance.new("ParticleEmitter")
			v110.Texture = v_u_4.ShirayukiCrystal
			v110.Color = ColorSequence.new(v_u_7, v_u_6)
			v110.LightEmission = 0.4
			v110.LightInfluence = 0
			v110.Lifetime = NumberRange.new(1.6, 2.2)
			v110.Size = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0),
				NumberSequenceKeypoint.new(0.15, v_u_24 * 0.32 * p_u_20.fx),
				NumberSequenceKeypoint.new(0.85, v_u_24 * 0.32 * p_u_20.fx),
				NumberSequenceKeypoint.new(1, 0)
			})
			v110.Rotation = NumberRange.new(0, 360)
			v110.RotSpeed = NumberRange.new(-90, 90)
			v110.Speed = NumberRange.new(v_u_24 * 2.5, v_u_24 * 4)
			v110.EmissionDirection = Enum.NormalId.Bottom
			v110.SpreadAngle = Vector2.new(15, 15)
			v110.Shape = Enum.ParticleEmitterShape.Box
			v110.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v110.Rate = 7 * v_u_3.formRate() * (p_u_20.fx > 1 and 2 or 1)
			v110.Parent = v105
			p_u_19.own(p_u_20, v110)
			local v_u_111 = -1
			local v112 = p_u_20.ticks
			local function v116()
				-- upvalues: (copy) v_u_28, (ref) v_u_111, (copy) v_u_24, (copy) v_u_40
				local v113 = v_u_28()
				local v114 = v113 - v_u_111
				if math.abs(v114) >= 0.01 then
					v_u_111 = v113
					local v115 = v_u_24 * 10 * (1 + v113 * 0.3)
					v_u_40.Size = Vector3.new(v115, 0.05, v115)
				end
			end
			table.insert(v112, v116)
			p_u_19.particles(p_u_20, "AuraMode", v22, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end