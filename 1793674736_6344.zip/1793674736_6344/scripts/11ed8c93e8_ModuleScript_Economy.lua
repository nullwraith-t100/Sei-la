local v_u_1 = require(script.Parent.Parent.Config.Economy)
local v_u_93 = {
	["rebirthMult"] = function(p2) -- name: rebirthMult
		-- upvalues: (copy) v_u_1
		return 1 + v_u_1.rebirthBonus * math.max(p2, 0)
	end,
	["multiplier"] = function(p3) -- name: multiplier
		-- upvalues: (copy) v_u_93
		local v4 = p3.eyeMult
		local v5 = math.max(v4, 1) * v_u_93.rebirthMult(p3.rebirths)
		local v6 = p3.training
		local v7 = v5 * math.max(v6, 1)
		local v8 = p3.boost
		local v9 = v7 * math.max(v8, 1)
		local v10 = p3.aura or 1
		local v11 = v9 * math.max(v10, 1)
		local v12 = p3.pets or 1
		local v13 = v11 * math.max(v12, 1)
		local v14 = p3.group or 1
		return v13 * math.max(v14, 1)
	end,
	["petMult"] = function(p15) -- name: petMult
		local v16 = 0
		for _, v17 in p15 do
			v16 = v16 + v17
		end
		return math.max(v16, 1)
	end,
	["enemySpeedMult"] = function(p18, p19) -- name: enemySpeedMult
		-- upvalues: (copy) v_u_1
		local v20 = 1 + (p18 / math.max(p19, 1) - 1) * v_u_1.weakSpeed
		local v21 = v_u_1.weakSpeedMax
		return math.clamp(v20, 1, v21)
	end,
	["perSecond"] = function(p22) -- name: perSecond
		-- upvalues: (copy) v_u_1, (copy) v_u_93
		return v_u_1.baseGain * v_u_93.multiplier(p22)
	end,
	["perClick"] = function(p23) -- name: perClick
		-- upvalues: (copy) v_u_1, (copy) v_u_93
		return v_u_1.clickGain * v_u_93.perSecond(p23)
	end,
	["xpToNext"] = function(p24) -- name: xpToNext
		-- upvalues: (copy) v_u_1
		local v25 = math.max(p24, 1)
		local v26 = v_u_1.xpLinear * v25
		local v27 = v_u_1.xpBase * v_u_1.xpGrowth ^ (v25 - 1) + 0.5
		return v26 + math.floor(v27)
	end,
	["addXp"] = function(p28, p29, p30) -- name: addXp
		-- upvalues: (copy) v_u_93
		local v31 = p29 + math.max(p30, 0)
		local v32 = v_u_93.xpToNext(p28)
		local v33 = 0
		while v32 <= v31 and v33 < 10000 do
			v31 = v31 - v32
			p28 = p28 + 1
			v32 = v_u_93.xpToNext(p28)
			v33 = v33 + 1
		end
		return p28, v31
	end,
	["totalXp"] = function(p34, p35) -- name: totalXp
		-- upvalues: (copy) v_u_1
		local v36 = math.max(p34, 1) - 1
		local v37 = v_u_1.xpGrowth
		return v_u_1.xpLinear * v36 * (v36 + 1) / 2 + v_u_1.xpBase * (v37 ^ v36 - 1) / (v37 - 1) + p35
	end,
	["rebirthLevel"] = function(p38) -- name: rebirthLevel
		-- upvalues: (copy) v_u_1
		local v39 = math.floor(p38)
		local v40 = math.max(v39, 0)
		local v41 = v_u_1.rebirthLevels
		if v40 < #v41 then
			return v41[v40 + 1]
		else
			return v41[#v41] + v_u_1.rebirthStep * (v40 - #v41 + 1)
		end
	end,
	["rebirthProgress"] = function(p42, p43, p44) -- name: rebirthProgress
		-- upvalues: (copy) v_u_93
		local v45 = v_u_93.rebirthLevel(p44)
		local v46 = v_u_93.xpToNext(p42)
		local v47 = p43 / math.max(v46, 1)
		local v48 = math.clamp(v47, 0, 1)
		local v49 = p42 - 1 + v48
		local v50 = v45 - 1
		local v51 = v49 / math.max(v50, 1)
		return math.clamp(v51, 0, 1)
	end,
	["enemyHealth"] = function(p52, p53) -- name: enemyHealth
		-- upvalues: (copy) v_u_1
		local v54
		if p53 then
			v54 = v_u_1.bossHealth
		else
			v54 = v_u_1.enemyHealth
		end
		return p52 * v54
	end,
	["hitShare"] = function(p55, p56, p57) -- name: hitShare
		-- upvalues: (copy) v_u_1
		local v58 = p55 / math.max(p56, 1)
		local v59 = v_u_1.hitAtParity * v58 ^ v_u_1.hitPower
		local v60 = v_u_1.hitMin
		local v61 = v_u_1.hitMax
		local v62 = math.clamp(v59, v60, v61)
		if p57 then
			local v63 = v62 * v_u_1.hitBoss
			local v64 = v_u_1.hitMax
			v62 = math.min(v63, v64)
		end
		return v62
	end,
	["capHit"] = function(p65, p66) -- name: capHit
		-- upvalues: (copy) v_u_1
		local v67 = v_u_1.hurtPerSecond - p66
		local v68 = math.min(p65, v67)
		local v69 = v_u_1.hitMax
		return math.clamp(v68, 0, v69)
	end,
	["chaseSpeed"] = function(p70, p71) -- name: chaseSpeed
		-- upvalues: (copy) v_u_1
		local v72 = p70 * p71
		local v73 = v_u_1.walkHub * v_u_1.chaseMax
		return math.min(v72, v73)
	end,
	["weakness"] = function(p74, p75, p76) -- name: weakness
		-- upvalues: (copy) v_u_1
		local v77 = math.max(p74, 1) / math.max(p75, 1)
		local v78 = math.clamp(v77, 0, 1)
		local v79
		if p76 then
			v79 = v_u_1.bossWeakPower
		else
			v79 = v_u_1.weakPower
		end
		return v78 ^ v79
	end,
	["damage"] = function(p80, p81, p82, p83, p84) -- name: damage
		-- upvalues: (copy) v_u_93, (copy) v_u_1
		local v85 = math.max(p80, 1) * p81 * v_u_93.weakness(p80, p82, p83)
		if p84 then
			v85 = v85 * v_u_1.critDamage
		end
		return v85
	end,
	["killChakra"] = function(p86, p87) -- name: killChakra
		-- upvalues: (copy) v_u_1
		local v88
		if p87 then
			v88 = v_u_1.bossSeconds
		else
			v88 = v_u_1.killSeconds
		end
		return p86 * v88
	end,
	["offlineChakra"] = function(p89, p90) -- name: offlineChakra
		-- upvalues: (copy) v_u_1
		if p90 < v_u_1.offlineMin or (p89 ~= p89 or p90 ~= p90) then
			return 0
		end
		local v91 = math.max(p89, 0)
		local v92 = v_u_1.offlineCap
		return v91 * math.min(p90, v92) * v_u_1.offlineShare
	end
}
return v_u_93