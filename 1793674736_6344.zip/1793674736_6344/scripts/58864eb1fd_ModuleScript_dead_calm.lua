local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = Color3.new(1, 1, 1)
local v_u_7 = Color3.fromHex("FFF7C2")
local v_u_8 = Color3.fromRGB(14, 30, 82)
local v_u_9 = Color3.fromRGB(24, 72, 170)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = CFrame.identity
local function v_u_19(p12) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v13 = v_u_2:FindFirstChild("EyePieces")
	if v13 then
		v13 = v13:FindFirstChild("w8_dead_calm")
	end
	if not (v13 and v13:IsA("MeshPart")) then
		return nil
	end
	local v14 = v13:Clone()
	local v15 = v13.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	v14.Size = v15 * (p12 / math.max(v16, v17, v18, 0.01))
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanQuery = false
	v14.CanTouch = false
	v14.Massless = true
	v14.CastShadow = false
	v14.Parent = v_u_4.folder()
	return v14
end
local function v_u_26(p20, p21, p22, p23) -- name: cutAt
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_1
	local v24 = Instance.new("Attachment")
	v24.WorldPosition = p20
	v24.Parent = v_u_3.Terrain
	local v25 = Instance.new("ParticleEmitter")
	v25.Enabled = false
	v25.Texture = v_u_5.CalmSlash
	v25.Color = ColorSequence.new(p22)
	v25.LightEmission = 0.2
	v25.LightInfluence = 0
	v25.Speed = NumberRange.new(0)
	v25.Lifetime = NumberRange.new(0.4)
	v25.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p21 * 0.2), NumberSequenceKeypoint.new(0.2, p21 * 0.5), NumberSequenceKeypoint.new(1, p21 * 0.55) })
	v25.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.4, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v25.Rotation = NumberRange.new(p23, p23)
	v25.Parent = v24
	v25:Emit(1)
	v_u_1:AddItem(v24, 0.6)
end
return function(p_u_27)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_19, (copy) v_u_11, (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_3, (copy) v_u_1, (copy) v_u_26, (copy) v_u_7
	return {
		["w8_dead_calm"] = function(p_u_28, p29)
			-- upvalues: (ref) v_u_4, (copy) p_u_27, (ref) v_u_6, (ref) v_u_5, (ref) v_u_19, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_3, (ref) v_u_1, (ref) v_u_26, (ref) v_u_7
			local v_u_30 = v_u_4.color(p29.color)
			local v31 = p_u_28.headY / 1.5
			local v_u_32 = math.clamp(v31, 0.7, 3)
			local v_u_33 = -100
			local v_u_34 = true
			p_u_27.throb(p_u_28, 5.5, 2.5, 1, function()
				-- upvalues: (ref) v_u_33, (ref) v_u_34
				v_u_33 = os.clock()
				v_u_34 = false
			end)
			local v35 = p_u_27.bar(Vector3.new(0.2, 0.2, 0.2), v_u_6, 1)
			p_u_27.add(p_u_28, v35, function(p36)
				-- upvalues: (ref) p_u_27, (copy) p_u_28
				return CFrame.new(p_u_27.feetAt(p_u_28, p36, 0.1))
			end)
			local v_u_37 = Instance.new("ParticleEmitter")
			v_u_37.Texture = v_u_5.CalmSpiral
			v_u_37.Color = ColorSequence.new(v_u_6)
			v_u_37.LightEmission = 0.1
			v_u_37.LightInfluence = 0
			v_u_37.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_37.EmissionDirection = Enum.NormalId.Top
			v_u_37.SpreadAngle = Vector2.zero
			v_u_37.Speed = NumberRange.new(0.01)
			v_u_37.LockedToPart = true
			v_u_37.Lifetime = NumberRange.new(8)
			v_u_37.Size = NumberSequence.new(v_u_32 * 2.6 * p_u_28.fx)
			v_u_37.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.05, 0.12),
				NumberSequenceKeypoint.new(0.95, 0.12),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_37.Rotation = NumberRange.new(0, 0)
			v_u_37.RotSpeed = NumberRange.new(-9, -9)
			v_u_37.Rate = 0.125
			v_u_37.Parent = v35
			v_u_37:Emit(1)
			local v38 = p_u_28.stops
			table.insert(v38, function()
				-- upvalues: (copy) v_u_37
				v_u_37.Enabled = false
			end)
			local v_u_39 = 1.5707963267948966
			local v_u_40 = 0
			local v_u_69 = p_u_27.group(p_u_28, function(p41, p42)
				-- upvalues: (ref) v_u_40, (ref) v_u_39, (ref) v_u_33, (copy) v_u_32, (copy) p_u_28
				local v43 = p42 - v_u_40
				local v44 = math.clamp(v43, 0, 0.25)
				v_u_40 = p42
				local v45 = v_u_39
				local v46 = v44 * 0.9
				local v47 = os.clock() - v_u_33
				local v48 = v47 / 0.55
				local v49 = math.clamp(v48, 0, 1)
				local v50 = v49 * v49 * (3 - v49 * 2)
				local v51 = (v47 - 0.85 - 0.15) / 0.6
				local v52 = math.clamp(v51, 0, 1)
				v_u_39 = v45 + v46 * (1 - v50 * (1 - v52 * v52 * (3 - v52 * 2)))
				local v53 = v_u_32 * 2.35 * p_u_28.fx
				local v54 = v_u_39
				local v55 = math.cos(v54)
				local v56 = v_u_39
				local v57 = math.sin(v56)
				local v58 = Vector3.new(v55, 0, v57)
				local v59 = v_u_39
				local v60 = -math.sin(v59)
				local v61 = v_u_39
				local v62 = math.cos(v61)
				local v63 = Vector3.new(v60, 0, v62)
				local v64 = p41.Position + v58 * v53
				local v65 = v_u_32 * -0.15
				local v66 = p42 * 1.7
				local v67 = v64 + Vector3.new(0, 1, 0) * (v65 + math.sin(v66) * 0.12 * v_u_32)
				local v68 = v_u_39 * 2.35 / 0.9
				return CFrame.fromMatrix(v67, v63, Vector3.new(0, 1, 0)) * CFrame.Angles(0, 0, -v68)
			end)
			local v70 = v_u_19(v_u_32 * 1.8)
			local v_u_71, v_u_72
			if v70 then
				p_u_27.pin(p_u_28, v_u_69, v70, v_u_11)
				v_u_71 = v_u_33
				v_u_72 = v_u_34
			else
				local v73 = p_u_27.picture(v_u_32 * 1.8, v_u_5.CalmSpiral, v_u_6, 0)
				p_u_27.pin(p_u_28, v_u_69, v73, CFrame.Angles(1.5707963267948966, 0, 0))
				local v74 = v_u_32 * 0.846
				local v75 = v74 * 2 * 0.3090169943749474 + v_u_32 * 0.1
				v_u_72 = v_u_34
				v_u_71 = v_u_33
				for v76 = 1, 10 do
					local v77 = (v76 - 0.5) / 10 * 3.141592653589793 * 2
					local v78 = math.cos(v77) * v74
					local v79 = math.sin(v77) * v74
					local v80 = Vector3.new(v78, v79, 0)
					local v81 = -math.sin(v77)
					local v82 = math.cos(v77)
					local v83 = Vector3.new(v81, v82, 0)
					local v84 = p_u_27.pin
					local v85 = p_u_27.bar
					local v86 = v_u_32 * 0.14
					local v87 = v_u_32 * 0.14
					local v88 = Vector3.new(v86, v87, v75)
					local v89
					if v76 % 2 == 0 then
						v89 = v_u_9
					else
						v89 = v_u_8
					end
					v84(p_u_28, v_u_69, v85(v88, v89, 0, v_u_10), CFrame.lookAt(v80, v80 + v83))
				end
			end
			local v90 = p_u_27.bar(Vector3.new(0.2, 0.2, 0.2), v_u_6, 1)
			p_u_27.add(p_u_28, v90, function()
				-- upvalues: (copy) v_u_69, (copy) v_u_32
				return v_u_69.cf * CFrame.new(0, v_u_32 * -0.81, 0)
			end)
			local v91 = Instance.new("ParticleEmitter")
			v91.Texture = v_u_5.FxSmoke
			v91.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v91.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v91.Color = ColorSequence.new(v_u_6, v_u_30)
			v91.LightEmission = 0.3
			v91.LightInfluence = 0
			v91.Lifetime = NumberRange.new(0.3, 0.5)
			v91.Size = NumberSequence.new(v_u_32 * 0.25 * p_u_28.fx, v_u_32 * 0.6 * p_u_28.fx)
			v91.Transparency = NumberSequence.new(0.2, 1)
			v91.Speed = NumberRange.new(2, 4)
			v91.EmissionDirection = Enum.NormalId.Top
			v91.SpreadAngle = Vector2.new(40, 40)
			v91.Acceleration = Vector3.new(0, -14, 0)
			v91.Rate = 12
			v91.Parent = v90
			local v_u_92 = {}
			for v93 = 1, 3 do
				local v_u_94 = Instance.new("Attachment")
				v_u_94.Parent = v_u_3.Terrain
				local v_u_95 = Instance.new("Attachment")
				v_u_95.Parent = v_u_3.Terrain
				p_u_27.own(p_u_28, v_u_94)
				p_u_27.own(p_u_28, v_u_95)
				local v96 = Instance.new("Beam")
				v96.Attachment0 = v_u_94
				v96.Attachment1 = v_u_95
				v96.Texture = v_u_5.CalmStream
				v96.TextureMode = Enum.TextureMode.Wrap
				v96.TextureLength = v_u_32 * 1.25 * p_u_28.fx
				v96.TextureSpeed = 1.6
				v96.Color = ColorSequence.new(v_u_6)
				v96.LightEmission = 0.2
				v96.LightInfluence = 0
				v96.FaceCamera = true
				v96.Segments = 12
				v96.Width0 = v_u_32 * 0.85 * p_u_28.fx
				v96.Width1 = v_u_32 * 0.85 * p_u_28.fx
				v96.Transparency = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 0.85),
					NumberSequenceKeypoint.new(0.18, 0),
					NumberSequenceKeypoint.new(0.82, 0),
					NumberSequenceKeypoint.new(1, 0.85)
				})
				v96.Parent = v_u_94
				local v97 = {
					["a0"] = v_u_94,
					["a1"] = v_u_95,
					["beam"] = v96,
					["phase"] = (v93 - 1) / 3 * 3.141592653589793 * 2
				}
				table.insert(v_u_92, v97)
				local v98 = p_u_28.stops
				local function v99()
					-- upvalues: (ref) v_u_1, (copy) v_u_94, (copy) v_u_95
					v_u_1:AddItem(v_u_94, 0.1)
					v_u_1:AddItem(v_u_95, 0.1)
				end
				table.insert(v98, v99)
			end
			local v_u_100 = 0
			local v101 = p_u_28.ticks
			local function v150(p102, p103, p104)
				-- upvalues: (ref) v_u_71, (ref) v_u_100, (copy) p_u_28, (copy) v_u_32, (copy) v_u_92, (ref) v_u_72, (ref) p_u_27, (ref) v_u_26, (ref) v_u_6, (copy) v_u_30, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5, (ref) v_u_8
				local v105 = os.clock() - v_u_71
				local v106 = v105 / 0.55
				local v107 = math.clamp(v106, 0, 1)
				local v108 = v107 * v107 * (3 - v107 * 2)
				local v109 = (v105 - 0.85 - 0.15) / 0.6
				local v110 = math.clamp(v109, 0, 1)
				local v111 = v108 * (1 - v110 * v110 * (3 - v110 * 2))
				v_u_100 = v_u_100 + p104 * 1.1 * (1 - v111)
				local v112 = p102.Position
				local v113 = p_u_28.feet + 0.35
				local v114 = (v111 * 0.5 + 2.1) * v_u_32 * p_u_28.fx
				local v115 = 0.6217435442066648 * v114
				for v116, v117 in v_u_92 do
					local v118 = v_u_100 + v117.phase
					local v119 = p103 * 1.3 + v116 * 2.1
					local v120 = (math.sin(v119) * 0.75 + -0.4) * v_u_32
					local v121 = p103 * 1.3 + v116 * 2.1 + 1.4
					local v122 = (math.sin(v121) * 0.75 + -0.4) * v_u_32
					local v123 = v120 + (v113 - v120) * v111
					local v124 = v122 + (v113 - v122) * v111
					local v125 = math.cos(v118) * v114
					local v126 = math.sin(v118) * v114
					local v127 = v112 + Vector3.new(v125, v123, v126)
					local v128 = v118 + 1.7453292519943295
					local v129 = math.cos(v128) * v114
					local v130 = v118 + 1.7453292519943295
					local v131 = math.sin(v130) * v114
					local v132 = v112 + Vector3.new(v129, v124, v131)
					local v133 = -math.sin(v118)
					local v134 = math.cos(v118)
					local v135 = Vector3.new(v133, 0, v134)
					local v136 = v118 + 1.7453292519943295
					local v137 = -math.sin(v136)
					local v138 = v118 + 1.7453292519943295
					local v139 = math.cos(v138)
					local v140 = Vector3.new(v137, 0, v139)
					v117.a0.WorldCFrame = CFrame.fromMatrix(v127, v135, Vector3.new(0, 1, 0))
					v117.a1.WorldCFrame = CFrame.fromMatrix(v132, v140, Vector3.new(0, 1, 0))
					v117.beam.CurveSize0 = v115
					v117.beam.CurveSize1 = v115
					v117.beam.TextureSpeed = (1 - v111) * 1.6
				end
				if not v_u_72 and os.clock() - v_u_71 >= 0.85 then
					v_u_72 = true
					if (v112 - p_u_27.camPos()).Magnitude < 150 then
						local v141 = p_u_27.feetAt(p_u_28, p102, 0.15)
						for v142 = 1, 6 do
							local v143 = v142 / 6 * 3.141592653589793 * 2 + v_u_100
							local v144 = math.cos(v143)
							local v145 = math.sin(v143)
							local v146 = v112 + Vector3.new(v144, 0, v145) * 2.4 * v_u_32 * p_u_28.fx
							local v147 = v_u_26
							local v148 = v_u_32 * 3.6 * p_u_28.fx
							local v149
							if v142 % 2 == 0 then
								v149 = v_u_6
							else
								v149 = v_u_30
							end
							v147(v146, v148, v149, math.random(0, 359))
						end
						v_u_4.ring(v141, v_u_7, 6.5 * p_u_28.fx, 0.6, v_u_5.Ring)
						v_u_4.ring(v141, v_u_8, 4.5 * p_u_28.fx, 0.45, v_u_5.Ring)
					end
				end
			end
			table.insert(v101, v150)
			p_u_27.particles(p_u_28, "AuraMode", v_u_30, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end