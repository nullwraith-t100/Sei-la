local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(226, 245, 255)
local v_u_6 = Color3.fromRGB(95, 175, 255)
local v_u_7 = Enum.Material.SmoothPlastic
local v_u_8 = CFrame.Angles(1.5707963267948966, 0, 0)
return function(p_u_9)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (copy) v_u_7, (copy) v_u_1, (copy) v_u_6
	return {
		["w4_polar_dial"] = function(p_u_10, p11)
			-- upvalues: (ref) v_u_3, (copy) p_u_9, (ref) v_u_4, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_1, (ref) v_u_6
			local v_u_12 = v_u_3.color(p11.color)
			local v_u_13 = v_u_3.color(p11.color2)
			local v14 = p_u_10.headY / 1.5
			local v_u_15 = math.clamp(v14, 0.7, 3)
			local v_u_16 = v_u_15 * 2.3
			local v_u_25 = p_u_9.group(p_u_10, function(p17, p18)
				-- upvalues: (copy) v_u_15
				local v19 = CFrame.new
				local v20 = v_u_15 * 0.95
				local v21 = p18 * 1.3
				local v22 = p17 * v19(0, v20 + math.sin(v21) * 0.1 * v_u_15, v_u_15 * 1.85)
				local v23 = CFrame.Angles
				local v24 = p18 * 0.8
				return v22 * v23(0, 0, math.sin(v24) * 0.035)
			end)
			local v26 = p_u_9.picture(v_u_16 * 3, v_u_4.Glow, v_u_12, 0.45)
			p_u_9.pin(p_u_10, v_u_25, v26, CFrame.new(0, 0, v_u_15 * -0.3) * v_u_8)
			p_u_9.fadeFromBehind(p_u_10, v26, 0.55)
			p_u_9.pin(p_u_10, v_u_25, p_u_9.picture(v_u_16 * 2.7, v_u_4.Ring, v_u_13, 0.15), CFrame.new(0, 0, v_u_15 * -0.15) * v_u_8)
			p_u_9.pin(p_u_10, v_u_25, p_u_9.picture(v_u_16 * 2.1, v_u_4.Ring, v_u_5, 0), v_u_8)
			local v27 = p_u_9.disc
			local v28 = v_u_15 * 0.08
			local v29 = v_u_16 * 2.25
			local v30 = v_u_16 * 2.25
			local v31 = v27(Vector3.new(v28, v29, v30), v_u_12, 0.7)
			p_u_9.pin(p_u_10, v_u_25, v31, CFrame.new(0, 0, v_u_15 * -0.08) * CFrame.Angles(0, 1.5707963267948966, 0))
			p_u_9.fadeFromBehind(p_u_10, v31, 0.5)
			local v_u_32 = {}
			local v_u_33 = {}
			local v_u_34 = 0
			local v_u_35 = 0.8
			local v_u_36 = 0
			local v_u_37 = 0
			local v_u_38 = -10
			local v_u_39 = 0
			local v_u_40 = 0.09
			local v_u_41 = -1
			local v_u_42 = -10
			local v_u_43 = 0
			local v_u_44 = -10
			for v45 = 0, 11 do
				local v46 = v45 * 3.141592653589793 / 6
				local v47
				if v45 % 3 == 0 then
					local v48 = v_u_16 * 1.04
					v47 = p_u_9.blob(Vector3.new(0.5, 1.2, 0.34) * v_u_15, v_u_13, 0, v_u_7)
					p_u_9.pin(p_u_10, v_u_25, v47, CFrame.new(math.sin(v46) * v48, math.cos(v46) * v48, v_u_15 * 0.05) * CFrame.Angles(0, 0, -v46))
				else
					v47 = p_u_9.ball(v_u_15 * 0.55, v_u_13, 0, v_u_7)
					p_u_9.pin(p_u_10, v_u_25, v47, CFrame.new(math.sin(v46) * v_u_16, math.cos(v46) * v_u_16, v_u_15 * 0.05))
				end
				p_u_9.dark(v47)
				v_u_32[v45 + 1] = v47
				v_u_33[v45 + 1] = 0
			end
			p_u_9.add(p_u_10, p_u_9.dark(p_u_9.ball(v_u_15 * 0.85, v_u_13, 0, v_u_7)), function()
				-- upvalues: (copy) v_u_25, (ref) v_u_34, (copy) v_u_15
				return v_u_25.cf * CFrame.Angles(0, 0, -v_u_34) * CFrame.new(0, 0, v_u_15 * 0.12)
			end)
			local v49 = v_u_15 * 0.75
			local v50 = v_u_15 * 0.9
			local v51 = v_u_15 * 0.22
			local v52 = v_u_15 * 0.5
			for _, v53 in { 0, 3.141592653589793 } do
				for _, v54 in { -1, 1 } do
					local v55 = p_u_9.bar
					local v56 = v49 / 2
					local v57 = v55(Vector3.new(v51, v50, v56), v_u_13, 0, v_u_7)
					v57.Shape = Enum.PartType.Wedge
					local v_u_58 = CFrame.Angles(0, 0, v53) * CFrame.new(v54 * v49 / 4, v52 + v50 / 2, v_u_15 * 0.12) * CFrame.Angles(0, -v54 * 3.141592653589793 / 2, 0)
					p_u_9.add(p_u_10, v57, function()
						-- upvalues: (copy) v_u_25, (ref) v_u_34, (copy) v_u_58
						return v_u_25.cf * CFrame.Angles(0, 0, -v_u_34) * v_u_58
					end)
				end
			end
			local function v_u_68(p59) -- name: chime
				-- upvalues: (ref) v_u_3, (ref) p_u_9, (copy) p_u_10, (copy) v_u_12, (ref) v_u_4, (copy) v_u_25, (ref) v_u_5, (copy) v_u_15, (copy) v_u_16, (ref) v_u_1
				v_u_3.ring(p_u_9.feetAt(p_u_10, p59, 0.15), v_u_12, 5.5 * p_u_10.fx, 0.5, v_u_4.Ring)
				v_u_3.flash(v_u_25.cf.Position, v_u_5, v_u_15 * 3.4, 0.25)
				for v60 = 0, 11 do
					local v61 = v60 * 3.141592653589793 / 6
					local v62 = v_u_25.cf
					local v63 = math.sin(v61)
					local v64 = math.cos(v61)
					local v65 = v62:VectorToWorldSpace((Vector3.new(v63, v64, 0)))
					local v66 = v_u_25.cf.Position + v65 * v_u_16 * 1.2
					local v67 = v_u_3.part(Vector3.new(0.16, 0.16, 0.9) * v_u_15, CFrame.lookAt(v66, v66 + v65), v_u_5)
					v_u_3.tween(v67, 0.35, {
						["CFrame"] = nil,
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = CFrame.lookAt(v66 + v65 * 2.4 * v_u_15, v66 + v65 * 3.4 * v_u_15),
						["Size"] = Vector3.new(0.05, 0.05, 0.4) * v_u_15
					})
					v_u_1:AddItem(v67, 0.4)
				end
			end
			local v69 = p_u_10.ticks
			local function v88(p70, p71, p72)
				-- upvalues: (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (ref) v_u_39, (ref) v_u_38, (ref) v_u_40, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (copy) p_u_10, (ref) p_u_9, (copy) v_u_68, (ref) v_u_34, (copy) v_u_32, (copy) v_u_33, (copy) v_u_13, (ref) v_u_5
				if v_u_35 <= p71 then
					v_u_36 = v_u_36 + 1
					v_u_35 = p71 + 0.3
					v_u_37 = v_u_39
					v_u_38 = p71
					v_u_40 = 0.09
					v_u_41 = v_u_36 % 12
					v_u_42 = p71
					if v_u_41 == 0 then
						v_u_43 = v_u_43 + 1
						v_u_44 = p71
						v_u_40 = 0.45
						v_u_35 = p71 + 0.45 + 0.12
						p_u_10.pulse = 1
						if (p70.Position - p_u_9.camPos()).Magnitude < 150 then
							v_u_68(p70)
						end
					end
					v_u_39 = v_u_36 * 3.141592653589793 / 6 + v_u_43 * 3.141592653589793 * 2
				end
				local v73 = (p71 - v_u_38) / v_u_40
				local v74 = math.clamp(v73, 0, 1)
				local v75 = v_u_37
				local v76 = v_u_39 - v_u_37
				local v77 = v74 - 1
				v_u_34 = v75 + v76 * (v77 * 3.2 * v77 * v77 + 1 + v77 * 2.2 * v77)
				local v78 = p_u_10
				local v79 = p_u_10.pulse - p72 * 2
				v78.pulse = math.max(v79, 0)
				for v80, v81 in v_u_32 do
					local v82 = v80 - 1
					local v83
					if v82 == v_u_41 then
						local v84 = 1 - (p71 - v_u_42) / 0.22
						v83 = math.max(v84, 0)
					else
						v83 = 0
					end
					local v85 = p71 - v_u_44 - v82 * 0.035
					if v85 >= 0 and v85 < 0.3 then
						local v86 = 1 - v85 / 0.3
						v83 = math.max(v83, v86)
					end
					local v87 = v83 - v_u_33[v80]
					if math.abs(v87) <= 0.02 and (v83 ~= 0 or v_u_33[v80] == 0) then
						continue
					end
					v_u_33[v80] = v83
					v81.Color = v_u_13:Lerp(v_u_5, v83)
				end
			end
			table.insert(v69, v88)
			for v_u_89 = 1, 3 do
				local v_u_90 = (v_u_89 - 1) / 3 * 3.141592653589793 * 2
				local function v_u_107(p91, p92) -- name: at
					-- upvalues: (copy) v_u_90, (copy) v_u_15, (copy) v_u_89, (ref) v_u_44
					local v93 = p92 * 0.85 + v_u_90
					local v94 = p91.Position
					local v95 = math.cos(v93) * 2.75 * v_u_15
					local v96 = p92 * 1.7 + v_u_89 * 2
					local v97 = (math.sin(v96) * 0.22 + -0.45) * v_u_15
					local v98 = math.sin(v93) * 2.75 * v_u_15
					local v99 = v94 + Vector3.new(v95, v97, v98)
					local v100 = p92 * 11 + v_u_89 * 1.9
					local v101 = math.sin(v100) * 0.05
					local v102 = p92 - v_u_44
					if v102 >= 0 and v102 < 1.8 then
						local v103 = v102 / 0.9
						v101 = v101 + (1 - (1 - math.min(v103, 1)) ^ 3) * 3.141592653589793 * 4
						if v102 > 0.9 then
							local v104 = (v102 - 0.9) * 22
							local v105 = math.sin(v104) * 0.35
							local v106 = -(v102 - 0.9) * 6
							v101 = v101 + v105 * math.exp(v106)
						end
					end
					return CFrame.lookAt(v99, v99 + Vector3.new(0, 0, -1)) * CFrame.Angles(0, v101, 0)
				end
				local v108 = p_u_9.blob(Vector3.new(0.3, 0.14, 0.95) * v_u_15, v_u_12, 0)
				p_u_9.add(p_u_10, v108, function(p109, p110)
					-- upvalues: (copy) v_u_107, (copy) v_u_15
					return v_u_107(p109, p110) * CFrame.new(0, 0, v_u_15 * -0.42)
				end)
				p_u_9.add(p_u_10, p_u_9.dark(p_u_9.blob(Vector3.new(0.3, 0.14, 0.95) * v_u_15, v_u_13, 0, v_u_7)), function(p111, p112)
					-- upvalues: (copy) v_u_107, (copy) v_u_15
					return v_u_107(p111, p112) * CFrame.new(0, 0, v_u_15 * 0.42)
				end)
				p_u_9.tail(v108, v_u_12, v_u_6, v_u_15 * 0.16, 0.3)
			end
			p_u_9.particles(p_u_10, "AuraMode", v_u_12, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
			p_u_9.particles(p_u_10, "Petals", v_u_5, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end