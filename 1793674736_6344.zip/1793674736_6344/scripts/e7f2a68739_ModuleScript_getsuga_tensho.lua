local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(8, 6, 8)
local v_u_7 = {
	{ 0.34, 0.2, 0.55 },
	{ 0.42, -0.02, 0.7 },
	{ 0.3, -0.24, 0.5 }
}
local function v_u_14(p8, p9, p10) -- name: katanaFrame
	local v11 = p9.Unit
	local v12 = p10 - v11 * p10:Dot(v11)
	if v12.Magnitude < 0.001 then
		v12 = v11:Cross(Vector3.new(1, 0, 0))
	end
	local v13 = v12.Unit
	return CFrame.fromMatrix(p8, v13, v13:Cross(v11)) * CFrame.Angles(-0.7155849933176751, 0, 0)
end
return function(p_u_15)
	-- upvalues: (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (copy) v_u_14, (copy) v_u_5, (copy) v_u_1, (copy) v_u_7, (copy) v_u_4
	return {
		["w6_getsuga_tensho"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_14, (copy) p_u_15, (ref) v_u_5, (ref) v_u_1, (ref) v_u_7, (ref) v_u_4
			local v_u_18 = v_u_3.color(p17.color)
			local v19 = p_u_16.headY / 1.5
			local v_u_20 = math.clamp(v19, 0.7, 3)
			local v21 = v_u_20 * 4.2
			local v22 = v_u_2:FindFirstChild("EyePieces")
			if v22 then
				v22 = v22:FindFirstChild("w6_getsuga_tensho")
			end
			local v_u_23 = nil
			local v24
			if v22 and v22:IsA("MeshPart") then
				v24 = v22:Clone()
				local v25 = v22.Size
				local v26 = v22.Size.Y
				local v27 = v22.Size.Z
				local v28 = math.max(v26, v27) * 1.35
				v24.Size = v25 * (v21 / math.max(v28, 0.01))
				v_u_23 = v24:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_23 then
					v24.Color = v_u_6
					v24.Material = Enum.Material.SmoothPlastic
					v24.Reflectance = 0.2
				end
			else
				v24 = Instance.new("WedgePart")
				local v29 = v21 * 0.03
				local v30 = v21 * 0.07
				v24.Size = Vector3.new(v29, v30, v21)
				v24.Color = v_u_6
				v24.Material = Enum.Material.SmoothPlastic
				v24.Reflectance = 0.2
			end
			v24.Anchored = true
			v24.CanCollide = false
			v24.CanQuery = false
			v24.CanTouch = false
			v24.CastShadow = false
			v24.Massless = true
			v24.Parent = v_u_3.folder()
			local v_u_31 = CFrame.identity
			local v_u_32 = -1
			local v33 = p_u_16.ticks
			local function v66(p34, p35, p36)
				-- upvalues: (copy) v_u_20, (ref) v_u_14, (ref) v_u_31, (ref) v_u_32, (copy) p_u_16, (ref) p_u_15, (ref) v_u_5, (copy) v_u_18, (ref) v_u_3, (ref) v_u_1
				local v37 = p35 * 1.4
				local v38 = math.sin(v37) * 0.12 * v_u_20
				local v39 = v_u_14((p34 * CFrame.new(v_u_20 * 0.15, v_u_20 * 0.55 + v38, v_u_20 * 0.95)).Position, p34:VectorToWorldSpace(Vector3.new(-0.55, 0.84, 0)), p34:VectorToWorldSpace(Vector3.new(0, 0, 1)))
				local v40, v41
				if p35 < 2 then
					v40 = 0
					v41 = 0
				else
					local v42 = (p35 - 2) % 4.5
					if v42 < 0.15 then
						local v43 = v42 / 0.15
						local v44 = math.clamp(v43, 0, 1)
						v40 = v44 * v44 * (3 - v44 * 2)
						v41 = 0
					elseif v42 < 0.6 then
						v41 = 6.283185307179586 * (1 - (1 - (v42 - 0.15) / 0.45) ^ 2)
						v40 = 1
					elseif v42 < 0.8999999999999999 then
						local v45 = (0.8999999999999999 - v42) / 0.3
						local v46 = math.clamp(v45, 0, 1)
						v40 = v46 * v46 * (3 - v46 * 2)
						v41 = 6.283185307179586
					else
						v40 = 0
						v41 = 0
					end
				end
				if v40 > 0 then
					local v47 = math.sin(v41)
					local v48 = math.cos(v41)
					local v49 = p34:VectorToWorldSpace((Vector3.new(v47, 0, v48)))
					local v50 = math.cos(v41)
					local v51 = -math.sin(v41)
					local v52 = (v49 + p34:VectorToWorldSpace((Vector3.new(v50, 0, v51))) * 0.35).Unit
					v_u_31 = v39:Lerp(v_u_14(p34.Position + v49 * 1.9 * v_u_20 - Vector3.new(0, 0.15, 0) * v_u_20, v52, Vector3.new(0, 1, 0)), v40)
				else
					v_u_31 = v39
				end
				if p35 >= 2 then
					local v53 = (p35 - 2) / 4.5
					local v54 = math.floor(v53)
					local v55 = (p35 - 2) % 4.5
					if v54 ~= v_u_32 and v55 >= 0.15 then
						v_u_32 = v54
						p_u_16.pulse = 1
						if (p34.Position - p_u_15.camPos()).Magnitude < 150 then
							local v56 = p34.Position - Vector3.new(0, 0.2, 0) * v_u_20
							local v57, v58 = p_u_15.picture(v_u_20 * 3, v_u_5.GetsugaBrush, v_u_18, 0)
							v57.CFrame = CFrame.new(v56) * CFrame.Angles(0, math.random() * 6.28, 0)
							local v59 = v_u_3.tween
							local v60 = {}
							local v61 = v_u_20 * 11 * p_u_16.fx
							local v62 = v_u_20 * 11 * p_u_16.fx
							v60.Size = Vector3.new(v61, 0.05, v62)
							v59(v57, 0.6, v60)
							for _, v63 in v58 do
								v_u_3.tween(v63, 0.6, {
									["Transparency"] = 1
								}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							end
							v_u_1:AddItem(v57, 0.65)
							v_u_3.ring(p_u_15.feetAt(p_u_16, p34, 0.15), v_u_18, 6 * p_u_16.fx, 0.55, v_u_5.Ring)
						end
					end
				end
				local v64 = p_u_16
				local v65 = p_u_16.pulse - p36 * 1.5
				v64.pulse = math.max(v65, 0)
			end
			table.insert(v33, v66)
			p_u_15.add(p_u_16, v24, function()
				-- upvalues: (ref) v_u_31
				return v_u_31
			end)
			p_u_15.tail(v24, v_u_18, v_u_6, v_u_20 * 0.7, 0.25)
			if v_u_23 then
				local v_u_67 = v_u_23.EmissiveStrength
				local v_u_68 = -1
				local v69 = p_u_16.ticks
				local function v72()
					-- upvalues: (copy) p_u_16, (ref) v_u_68, (copy) v_u_23, (copy) v_u_67
					local v70 = p_u_16.pulse * 20
					local v71 = math.floor(v70) / 20
					if v71 ~= v_u_68 then
						v_u_68 = v71
						v_u_23.EmissiveStrength = v_u_67 * (v71 * 1.5 + 1)
					end
				end
				table.insert(v69, v72)
			end
			local v_u_83 = p_u_15.group(p_u_16, function(p73, p74)
				-- upvalues: (copy) p_u_16, (ref) p_u_15, (copy) v_u_20
				local v75 = p73.Position + Vector3.new(0, 1, 0) * (p_u_16.headY + p_u_16.eyeLift)
				local v76 = p_u_15.camPos() - v75
				local v77 = v76.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v76.Unit
				local v78 = v77.Y
				local v79 = math.abs(v78) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v80 = CFrame.lookAt(v75 - v77 * 0.35 * v_u_20, v75 - v77 * 0.35 * v_u_20 + v77, v79) * CFrame.Angles(-1.5707963267948966, 0, 0)
				local v81 = CFrame.Angles
				local v82 = p74 * 0.9
				return v80 * v81(0, math.sin(v82) * 0.15, 0)
			end)
			local v_u_84 = v_u_20 * 4.6
			local v85 = p_u_15.picture(v_u_84 * 1.25, v_u_5.Glow, v_u_18, 0.55)
			p_u_15.add(p_u_16, v85, function()
				-- upvalues: (copy) v_u_83, (copy) v_u_20
				return v_u_83.cf * CFrame.new(0, v_u_20 * -0.05, 0)
			end)
			local v86 = p_u_15.picture(v_u_84, v_u_5.GetsugaBrush, v_u_18, 0)
			p_u_15.add(p_u_16, v86, function()
				-- upvalues: (copy) v_u_83
				return v_u_83.cf * CFrame.Angles(0, -1.9198621771937625, 0)
			end)
			local v_u_87 = {}
			for v88, v_u_89 in v_u_7 do
				local v90 = p_u_15.blob
				local v91 = v_u_20 * 0.16
				local v92 = v_u_84 * v_u_89[3]
				local v93 = v90(Vector3.new(v91, 0.05, v92), v_u_18, 0)
				v93.Material = Enum.Material.Neon
				v_u_87[v88] = v93
				p_u_15.add(p_u_16, v93, function()
					-- upvalues: (copy) v_u_83, (copy) v_u_84, (copy) v_u_89, (copy) v_u_20
					return v_u_83.cf * CFrame.new(-v_u_84 * v_u_89[1], v_u_20 * 0.04, v_u_84 * v_u_89[2]) * CFrame.Angles(0, -1.0122909661567112, 0)
				end)
			end
			local v_u_94 = -1
			local v95 = p_u_16.ticks
			local function v103(_, p96)
				-- upvalues: (ref) v_u_94, (copy) v_u_87, (copy) v_u_84, (ref) v_u_7, (copy) p_u_16, (copy) v_u_20
				if p96 - v_u_94 >= 0.06666666666666667 then
					v_u_94 = p96
					for v97, v98 in v_u_87 do
						local v99 = v_u_84 * v_u_7[v97][3]
						local v100 = p96 * 9 + v97 * 2
						local v101 = v99 * (math.sin(v100) * 0.15 + 0.85) * (1 + 0.3 * p_u_16.pulse)
						local v102 = v_u_20 * 0.16
						v98.Size = Vector3.new(v102, 0.05, v101)
					end
				end
			end
			table.insert(v95, v103)
			local v104 = p_u_15.picture
			local v105 = v_u_20 * 5.5
			local v106 = p_u_16.fx
			local v107 = v104(v105 * math.min(v106, 1.6), v_u_5.CrackGlow, v_u_18, 0.35)
			p_u_15.add(p_u_16, v107, function(p108)
				-- upvalues: (ref) p_u_15, (copy) p_u_16
				return CFrame.new(p_u_15.feetAt(p_u_16, p108, 0.08))
			end)
			local v109 = v_u_3.part
			local v110 = v_u_20 * 2.2
			local v111 = v_u_20 * 1.5
			local v112 = v109(Vector3.new(v110, 0.3, v111), CFrame.identity, v_u_6, {
				["transparency"] = 1
			})
			v112.Massless = true
			p_u_15.add(p_u_16, v112, function(p113)
				-- upvalues: (copy) p_u_16, (copy) v_u_20
				return p113 * CFrame.new(0, p_u_16.feet + v_u_20 * 0.4, v_u_20 * 0.1)
			end)
			local v114 = Instance.new("ParticleEmitter")
			v114.Texture = v_u_5.ShadowFlame
			v114.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v114.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v114.Color = ColorSequence.new(v_u_18)
			v114.LightEmission = 0
			v114.LightInfluence = 0
			v114.Brightness = 1.4
			v114.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
			local v115 = v_u_20 * 2.1 * p_u_16.fx
			v114.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v115 * 0.7), NumberSequenceKeypoint.new(0.4, v115), NumberSequenceKeypoint.new(1, v115 * 0.6) })
			v114.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.85, 0.1), NumberSequenceKeypoint.new(1, 1) })
			v114.Lifetime = NumberRange.new(0.7, 0.95)
			v114.Speed = NumberRange.new(v_u_20 * 3, v_u_20 * 6)
			v114.SpreadAngle = Vector2.new(15, 15)
			v114.EmissionDirection = Enum.NormalId.Top
			local v116 = v_u_20 * 5
			v114.Acceleration = Vector3.new(0, v116, 0)
			v114.Rotation = NumberRange.new(-12, 12)
			v114.Shape = Enum.ParticleEmitterShape.Box
			v114.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v114:SetAttribute("BaseRate", 11)
			v114.Rate = 11 * v_u_4.formRate()
			v114.Parent = v112
			p_u_15.own(p_u_16, v112)
			p_u_15.particles(p_u_16, "AuraMode", v_u_18, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end