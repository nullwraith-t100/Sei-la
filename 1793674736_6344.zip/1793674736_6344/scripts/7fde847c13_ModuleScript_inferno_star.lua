local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return {
		["w3_inferno_star"] = function(p_u_5, p6)
			-- upvalues: (ref) v_u_2, (copy) p_u_4, (ref) v_u_3
			local v_u_7 = v_u_2.color(p6.color)
			local v_u_8 = v_u_2.color(p6.color2)
			local v9 = p_u_4.rgb(235, 28, 16)
			local v10 = p_u_4.rgb(14, 6, 4)
			local v_u_11 = p_u_4.rgb(255, 64, 10)
			local v_u_12 = p_u_5.fx <= 1 and 1 or p_u_5.fx / 1.35
			local v_u_14 = p_u_4.throb(p_u_5, 3, 1, 2, function(p13)
				-- upvalues: (ref) v_u_2, (ref) p_u_4, (copy) p_u_5, (copy) v_u_7, (ref) v_u_3, (copy) v_u_8
				v_u_2.ring(p_u_4.feetAt(p_u_5, p13, 0.15), v_u_7, 5 * p_u_5.fx, 0.45, v_u_3.Shockwave)
				v_u_2.flash(p13.Position, v_u_8, 4 * p_u_5.fx, 0.2)
			end)
			local v_u_20 = p_u_4.group(p_u_5, function(p15, p16)
				-- upvalues: (copy) v_u_12
				local v17 = CFrame.new
				local v18 = -0.35 * v_u_12
				local v19 = p16 * 1.6
				return p15 * v17(0, v18 + math.sin(v19) * 0.06, 0) * CFrame.Angles(0, p16 * 0.5, 0)
			end)
			local v_u_21 = 1.25 * v_u_12
			local v_u_22 = {}
			for v23 = 0, 5 do
				local v24 = v23 / 6 * 3.141592653589793 * 2
				local v25 = math.sin(v24)
				local v26 = -math.cos(v24)
				local v_u_27 = Vector3.new(v25, 0, v26)
				local v_u_28 = (v23 % 3 == 0 and 3.9 or 2.7) * v_u_12
				local v29 = p_u_4.blob
				local v30 = 0.56 * v_u_12
				local v31 = 0.4 * v_u_12
				local v32 = v29(Vector3.new(v30, v31, v_u_28), v10, 0, Enum.Material.SmoothPlastic)
				local v33 = p_u_4.blob
				local v34 = 0.86 * v_u_12
				local v35 = 0.62 * v_u_12
				local v36 = v_u_28 * 1.1
				local v37 = v33(Vector3.new(v34, v35, v36), v_u_11, 0.6)
				table.insert(v_u_22, v37)
				for _, v38 in { v32, v37 } do
					p_u_4.add(p_u_5, v38, function()
						-- upvalues: (copy) v_u_28, (copy) v_u_14, (copy) v_u_27, (copy) v_u_21, (copy) v_u_20
						local v39 = v_u_27 * (v_u_21 + v_u_28 * (0.5 + 0.12 * v_u_14()))
						return v_u_20.cf * CFrame.lookAt(v39, v39 + v_u_27)
					end)
				end
			end
			local v_u_40 = -1
			local v41 = p_u_5.ticks
			local function v46()
				-- upvalues: (copy) v_u_14, (ref) v_u_40, (copy) v_u_11, (copy) v_u_8, (copy) v_u_22
				local v42 = v_u_14() * 20 + 0.5
				local v43 = math.floor(v42) / 20
				if v43 ~= v_u_40 then
					v_u_40 = v43
					local v44 = v_u_11:Lerp(v_u_8, v43)
					for _, v45 in v_u_22 do
						v45.Color = v44
						v45.Transparency = 0.6 - v43 * 0.3
					end
				end
			end
			table.insert(v41, v46)
			local v47 = p_u_4.picture(v_u_21 * 2.3, v_u_3.Ring, v9, 0)
			p_u_4.pin(p_u_5, v_u_20, v47, CFrame.identity)
			local v50 = p_u_4.group(p_u_5, function(p48, p49)
				-- upvalues: (copy) v_u_12
				return p48 * CFrame.new(0, 0.3 * v_u_12, 0) * CFrame.Angles(0.55, 0, -0.25) * CFrame.Angles(0, -p49 * 1.5, 0)
			end)
			local v51 = 3.1 * v_u_12
			for v52 = 0, 1 do
				local v53 = v52 * 3.141592653589793
				for v54 = 1, 4 do
					local v55 = v53 + (v54 - 1) / 4 * 1.9198621771937625
					local v56 = v53 + v54 / 4 * 1.9198621771937625
					local v57 = math.cos(v55) * v51
					local v58 = math.sin(v55) * v51
					local v59 = Vector3.new(v57, 0, v58)
					local v60 = math.cos(v56) * v51
					local v61 = math.sin(v56) * v51
					local v62 = Vector3.new(v60, 0, v61)
					local v63 = (v54 - 0.5) / 4 * 3.141592653589793
					local v64 = (math.sin(v63) * 0.48 + 0.32) * v_u_12
					local v65, v66 = p_u_4.between(v59, v62)
					local v67 = p_u_4.blob
					local v68 = v64 * 0.9
					local v69 = v66 + v64 * 0.8
					local v70 = v67(Vector3.new(v64, v68, v69), v10, 0, Enum.Material.SmoothPlastic)
					p_u_4.pin(p_u_5, v50, v70, v65)
					if v54 ~= 1 then
						continue
					end
					p_u_4.tail(v70, v_u_8, v9, 0.5 * v_u_12, 0.35)
				end
			end
			p_u_4.particles(p_u_5, "AuraMode", v_u_7, {
				["rate"] = 0.55,
				["glow"] = 0.55,
				["only"] = nil,
				["only"] = { "FlameBack", "FlameFront", "Sparks" }
			})
			local v71 = p_u_4.particles
			local v72 = {
				["rate"] = 0.45,
				["glow"] = 0.6,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Tongues", "Embers" }
			}
			local v73 = p_u_5.feet + 0.1
			v72.at = Vector3.new(0, v73, 0)
			v71(p_u_5, "Fire", v_u_7, v72)
		end
	}
end