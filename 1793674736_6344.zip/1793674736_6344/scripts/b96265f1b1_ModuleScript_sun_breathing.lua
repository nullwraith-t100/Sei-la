local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Mythic8)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(v2.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FFB21F")
local v_u_9 = Color3.fromHex("FFF4CC")
local v_u_10 = Color3.fromRGB(255, 120, 24)
local v_u_11 = Color3.fromRGB(240, 70, 20)
local v_u_12 = Color3.fromRGB(232, 60, 26)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_16 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_21(p17, p18, p19) -- name: flames
	-- upvalues: (copy) v_u_7, (copy) v_u_15, (copy) v_u_13, (copy) v_u_5
	local v20 = Instance.new("ParticleEmitter")
	v20.Texture = v_u_7.SunFlame
	v20.FlipbookLayout = v_u_15
	v20.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v20.Color = ColorSequence.new(v_u_13)
	v20.LightEmission = 0.15
	v20.LightInfluence = 0
	v20.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 * 0.7), NumberSequenceKeypoint.new(1, p18) })
	v20.Transparency = NumberSequence.new(0)
	v20.Lifetime = NumberRange.new(0.7, 1)
	v20.Speed = NumberRange.new(1, 2.4)
	v20.EmissionDirection = Enum.NormalId.Top
	v20.SpreadAngle = Vector2.new(20, 20)
	v20.Acceleration = Vector3.new(0, 2.5, 0)
	v20.Rotation = NumberRange.new(-20, 20)
	v20.Shape = Enum.ParticleEmitterShape.Box
	v20.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v20:SetAttribute("BaseRate", p19)
	v20.Rate = p19 * v_u_5.formRate()
	v20.Parent = p17
	return v20
end
return function(p_u_22)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_13, (copy) v_u_15, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_12, (copy) v_u_14, (copy) v_u_21, (copy) v_u_10
	return {
		["w8_sun_breathing"] = function(p_u_23, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) p_u_22, (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_15, (ref) v_u_9, (ref) v_u_16, (ref) v_u_11, (ref) v_u_12, (ref) v_u_14, (ref) v_u_21, (ref) v_u_10
			v_u_6.images({
				v_u_7.SunRays,
				v_u_7.SunSeal,
				v_u_7.SunCard,
				v_u_7.SunFlame
			})
			local v24 = p_u_23.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v_u_26 = p_u_23.fx
			local v27 = p_u_23.character == v_u_1.LocalPlayer.Character
			local v_u_28 = p_u_22.backOf(p_u_23)
			local v29 = p_u_23.character:FindFirstChild("Head")
			if not (v29 and v29:IsA("BasePart")) then
				v29 = nil
			end
			local v_u_30
			if v29 then
				v_u_30 = v29.Size.Y
			else
				v_u_30 = v_u_25 * 1.2
			end
			local v_u_31 = p_u_22.crownOf(p_u_23)
			local v_u_32 = Vector3.new(0, 0, 0)
			local v_u_33 = {}
			local v_u_43 = p_u_22.throb(p_u_23, 6, 2.6, 1, function(p34)
				-- upvalues: (ref) p_u_22, (copy) p_u_23, (ref) v_u_3, (ref) v_u_32, (ref) v_u_8, (copy) v_u_25, (copy) v_u_26, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5, (ref) v_u_13, (ref) v_u_15, (copy) v_u_33, (ref) v_u_9
				local v35 = p_u_22.feetAt(p_u_23, p34, 0.1)
				v_u_3.flash(v_u_32, v_u_8, v_u_25 * 5 * v_u_26, 0.3)
				v_u_4.groundPic(v35, v_u_25 * 3, v_u_25 * 15 * v_u_26, v_u_7.SunRays, v_u_8, 0, 0.25, 0.1, 0.4, 1.2, 0.2)
				if v_u_5.level() > 1 then
					for v36 = 1, 8 do
						local v37 = v36 * 3.141592653589793 / 4
						local v38 = v_u_4.spray
						local v39 = math.cos(v37)
						local v40 = math.sin(v37)
						local v41 = {
							["layout"] = nil,
							["emission"] = 0.15,
							["spread"] = 15,
							["spin"] = 0,
							["layout"] = v_u_15
						}
						v38(v35 + Vector3.new(v39, 0.3, v40) * 2.2 * v_u_25, v_u_7.SunFlame, 1, v_u_25 * 1.6 * v_u_26, v_u_25 * 5, 0.8, v_u_13, v41)
					end
				end
				for _, v42 in v_u_33 do
					v_u_3.flash(v42, v_u_9, v_u_25 * 1.4, 0.2)
				end
			end)
			local v_u_44 = v_u_32
			for v_u_45, v_u_46 in { -1, 1 } do
				local function v_u_54(p47, p48)
					-- upvalues: (copy) v_u_46, (copy) p_u_23, (copy) v_u_31, (copy) v_u_30, (copy) v_u_33, (copy) v_u_45
					local v49 = p48 * 2.3 + v_u_46
					local v50 = math.sin(v49) * 0.12
					local v51 = -p47:VectorToObjectSpace(p_u_23.root.AssemblyLinearVelocity).Z / 40
					local v52 = math.clamp(v51, 0, 0.35)
					local v53 = v_u_31(p47) * CFrame.new(v_u_46 * 0.62 * v_u_30, -0.18 * v_u_30, 0) * CFrame.Angles(v52, 0, v50)
					v_u_33[v_u_45] = v53.Position
					return v53
				end
				local v55 = v_u_4.piece("w8_sun_breathing", v_u_25 * 1.4, 4)
				if v55 then
					p_u_22.add(p_u_23, v55, function(p56, p57)
						-- upvalues: (copy) v_u_54, (copy) v_u_25, (ref) v_u_16
						return v_u_54(p56, p57) * CFrame.new(0, v_u_25 * -0.72, 0) * v_u_16
					end)
				else
					local v58 = v_u_4.standingCard(v_u_25 * 0.65, v_u_25 * 1.3, v_u_7.SunCard, v_u_13, 0, 1.2)
					p_u_22.add(p_u_23, v58, function(p59, p60)
						-- upvalues: (copy) v_u_54, (copy) v_u_25
						return v_u_54(p59, p60) * CFrame.new(0, v_u_25 * -0.72, 0)
					end)
				end
			end
			local v_u_68 = p_u_22.group(p_u_23, function(p61, p62)
				-- upvalues: (copy) v_u_28, (copy) v_u_25, (ref) v_u_44
				local v63 = p61 * v_u_28
				local v64 = CFrame.new
				local v65 = v_u_25 * 1.7
				local v66 = p62 * 1.1
				local v67 = v63 * v64(0, v65 + math.sin(v66) * 0.06 * v_u_25, v_u_25 * 1)
				v_u_44 = v67.Position
				return v67
			end)
			local v_u_69 = v_u_4.standingCard(v_u_25 * 4.3, v_u_25 * 4.3, v_u_7.SunRays, v_u_8, 0, 1.7)
			p_u_22.add(p_u_23, v_u_69, function(_, p70)
				-- upvalues: (copy) v_u_68, (copy) v_u_25
				return v_u_68.cf * CFrame.new(0, 0, v_u_25 * 0.1) * CFrame.Angles(0, 0, p70 * 0.35)
			end)
			local v_u_71 = v_u_4.standingCard(v_u_25 * 3.3, v_u_25 * 3.3, v_u_7.SunRays, v_u_11, 0, 1.6)
			p_u_22.add(p_u_23, v_u_71, function(_, p72)
				-- upvalues: (copy) v_u_68, (copy) v_u_25
				return v_u_68.cf * CFrame.new(0, 0, v_u_25 * 0.25) * CFrame.Angles(0, 0, -p72 * 0.5 + 0.26)
			end)
			local v_u_73 = -1
			local v74 = p_u_23.ticks
			local function v79()
				-- upvalues: (copy) v_u_43, (ref) v_u_73, (copy) v_u_25, (copy) v_u_69, (copy) v_u_71
				local v75 = v_u_43() * 16
				local v76 = math.floor(v75) / 16
				if v76 ~= v_u_73 then
					v_u_73 = v76
					local v77 = v_u_25 * 4.3 * (1 + 0.45 * v_u_43())
					local v78 = v_u_25 * 3.3 * (1 + 0.45 * v_u_43())
					v_u_69.Size = Vector3.new(v77, v77, 0.05)
					v_u_71.Size = Vector3.new(v78, v78, 0.05)
				end
			end
			table.insert(v74, v79)
			p_u_22.pin(p_u_23, v_u_68, p_u_22.blob(Vector3.new(1.75, 1.75, 0.3) * v_u_25, v_u_12, 0, v_u_14), CFrame.identity)
			p_u_22.pin(p_u_23, v_u_68, p_u_22.blob(Vector3.new(0.4, 0.4, 0.2) * v_u_25, v_u_9, 0, v_u_14), CFrame.new(v_u_25 * -0.35, v_u_25 * 0.35, v_u_25 * 0.12))
			local v80 = v_u_25 * 3
			local v81 = v_u_25 * 3
			local v82 = v_u_25 * 0.3
			local v83 = Vector3.new(v80, v81, v82)
			local v84 = Instance.new("Part")
			v84.Size = v83
			v84.Transparency = 1
			v84.Anchored = true
			v84.CanCollide = false
			v84.CanQuery = false
			v84.CanTouch = false
			v84.CastShadow = false
			v84.Parent = v_u_3.folder()
			p_u_22.add(p_u_23, v84, function()
				-- upvalues: (copy) v_u_68, (copy) v_u_25
				return v_u_68.cf * CFrame.new(0, 0, v_u_25 * 0.3)
			end)
			p_u_22.own(p_u_23, v84)
			local v_u_85 = v_u_21(v84, (v27 and 0.75 or 0.9) * v_u_25 * v_u_26, 4 * v_u_26)
			local v86 = p_u_23.stops
			table.insert(v86, function()
				-- upvalues: (copy) v_u_85
				v_u_85.Enabled = false
			end)
			local v87 = v_u_25 * 2.4
			local v88 = v_u_25 * 2.6
			local v89 = v_u_25 * 1.4
			local v90 = Vector3.new(v87, v88, v89)
			local v91 = Instance.new("Part")
			v91.Size = v90
			v91.Transparency = 1
			v91.Anchored = true
			v91.CanCollide = false
			v91.CanQuery = false
			v91.CanTouch = false
			v91.CastShadow = false
			v91.Parent = v_u_3.folder()
			p_u_22.add(p_u_23, v91, function(p92)
				-- upvalues: (copy) v_u_25
				return p92 * CFrame.new(0, v_u_25 * -0.2, 0)
			end)
			p_u_22.own(p_u_23, v91)
			local v_u_93 = v_u_21(v91, (v27 and 0.55 or 0.7) * v_u_25 * v_u_26, 2.5 * v_u_26)
			local v94 = p_u_23.stops
			table.insert(v94, function()
				-- upvalues: (copy) v_u_93
				v_u_93.Enabled = false
			end)
			local v95 = p_u_22.picture(v_u_25 * 5.8, v_u_7.Glow, v_u_10, 0.35)
			p_u_22.add(p_u_23, v95, function(p96)
				-- upvalues: (ref) p_u_22, (copy) p_u_23
				return CFrame.new(p_u_22.feetAt(p_u_23, p96, 0.05))
			end)
			local v97 = v_u_4.card(v_u_25 * 5.6, v_u_7.SunSeal, v_u_8, 0.05, 1.5)
			p_u_22.add(p_u_23, v97, function(p98, p99)
				-- upvalues: (ref) p_u_22, (copy) p_u_23
				return CFrame.new(p_u_22.feetAt(p_u_23, p98, 0.09)) * CFrame.Angles(0, p99 * 0.2, 0)
			end)
		end
	}
end