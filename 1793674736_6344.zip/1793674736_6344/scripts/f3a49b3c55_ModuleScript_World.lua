local v_u_32 = {
	["ORIGINS"] = {
		Vector3.new(0, 0, 0),
		Vector3.new(3000, 0, 0),
		Vector3.new(6000, 0, 0),
		Vector3.new(9000, 0, 0),
		Vector3.new(12000, 0, 0),
		Vector3.new(15000, 0, 0),
		Vector3.new(18000, 0, 0),
		Vector3.new(21000, 0, 0)
	},
	["origin"] = function(p1) -- name: origin
		-- upvalues: (copy) v_u_32
		return v_u_32.ORIGINS[p1 or 1] or Vector3.new(0, 0, 0)
	end,
	["worldAt"] = function(p2) -- name: worldAt
		-- upvalues: (copy) v_u_32
		local v3 = (1 / 0)
		local v4 = 1
		for v5, v6 in v_u_32.ORIGINS do
			local v7 = p2.X - v6.X
			local v8 = math.abs(v7)
			if v8 >= v3 then
				continue
			end
			v4 = v5
			v3 = v8
		end
		return v4
	end,
	["toLocal"] = function(p9) -- name: toLocal
		-- upvalues: (copy) v_u_32
		return p9 - v_u_32.origin(v_u_32.worldAt(p9))
	end,
	["FLOOR_Y"] = 0,
	["HUB_MIN"] = Vector3.new(-168, 0, -30),
	["HUB_MAX"] = Vector3.new(152, 0, 160),
	["SPAWN"] = Vector3.new(0, 3, 46),
	["STAGE_LENGTH"] = 90,
	["PATH_WIDTH"] = 84,
	["STAGE_COUNT"] = 15,
	["TRIGGER_DEPTH"] = -3.5,
	["stageStart"] = function(p10) -- name: stageStart
		-- upvalues: (copy) v_u_32
		return v_u_32.HUB_MIN.Z - (p10 - 1) * v_u_32.STAGE_LENGTH
	end,
	["stageEnd"] = function(p11) -- name: stageEnd
		-- upvalues: (copy) v_u_32
		return v_u_32.HUB_MIN.Z - p11 * v_u_32.STAGE_LENGTH
	end,
	["stageAt"] = function(p12) -- name: stageAt
		-- upvalues: (copy) v_u_32
		if v_u_32.HUB_MIN.Z < p12 then
			return 0
		end
		local v13 = (v_u_32.HUB_MIN.Z - p12) / v_u_32.STAGE_LENGTH
		local v14 = math.floor(v13) + 1
		local v15 = v_u_32.STAGE_COUNT + 1
		return math.min(v14, v15)
	end,
	["PAD_SIZE"] = Vector3.new(12, 1.2, 8),
	["padPosition"] = function(p16, p17) -- name: padPosition
		-- upvalues: (copy) v_u_32
		local v18 = p17 == "purple" and -20 or 20
		local v19 = v_u_32.FLOOR_Y + 0.6
		local v20 = v_u_32.stageEnd(p16) + 9
		return Vector3.new(v18, v19, v20)
	end,
	["spawnCentre"] = function(p21) -- name: spawnCentre
		-- upvalues: (copy) v_u_32
		local v22 = (v_u_32.stageStart(p21) + v_u_32.stageEnd(p21)) / 2
		return Vector3.new(0, 0, v22)
	end,
	["stageBounds"] = function(p23) -- name: stageBounds
		-- upvalues: (copy) v_u_32
		local v24 = v_u_32.PATH_WIDTH / 2 - 3
		local v25 = -v24
		local v26 = v_u_32.stageEnd(p23) + 3
		local v27 = Vector3.new(v25, 0, v26)
		local v28 = v_u_32.stageStart(p23) - 2
		return v27, Vector3.new(v24, 0, v28)
	end,
	["TRAIN_SIZE"] = 13,
	["TRAINING"] = {
		Vector3.new(-62, 0, 38),
		Vector3.new(-90, 0, 38),
		Vector3.new(-118, 0, 38),
		Vector3.new(-146, 0, 38),
		Vector3.new(-62, 0, 66),
		Vector3.new(-90, 0, 66),
		Vector3.new(-118, 0, 66),
		Vector3.new(-146, 0, 66),
		Vector3.new(-62, 0, 94),
		Vector3.new(-90, 0, 94),
		Vector3.new(-118, 0, 94),
		Vector3.new(-146, 0, 94),
		Vector3.new(-62, 0, 122)
	},
	["TRAINING_SPARE"] = { Vector3.new(-90, 0, 122), Vector3.new(-118, 0, 122), Vector3.new(-146, 0, 122) },
	["insideWave"] = function(p29, p30) -- name: insideWave
		-- upvalues: (copy) v_u_32
		return p29 <= v_u_32.stageStart(p30) - 1
	end,
	["EYE_PAD"] = 4,
	["EYE_PADS"] = {
		Vector3.new(58, 1.5, 105),
		Vector3.new(67, 1.5, 105),
		Vector3.new(76, 1.5, 105),
		Vector3.new(85, 1.5, 105),
		Vector3.new(94, 1.5, 105),
		Vector3.new(103, 1.5, 105),
		Vector3.new(53.5, 3.5, 116),
		Vector3.new(62.5, 3.5, 116),
		Vector3.new(71.5, 3.5, 116),
		Vector3.new(80.5, 3.5, 116),
		Vector3.new(89.5, 3.5, 116),
		Vector3.new(98.5, 3.5, 116),
		Vector3.new(107.5, 3.5, 116)
	},
	["EYE_PADS_14"] = {
		Vector3.new(58, 1.5, 105),
		Vector3.new(67, 1.5, 105),
		Vector3.new(76, 1.5, 105),
		Vector3.new(85, 1.5, 105),
		Vector3.new(94, 1.5, 105),
		Vector3.new(103, 1.5, 105),
		Vector3.new(112, 1.5, 105),
		Vector3.new(53.5, 3.5, 116),
		Vector3.new(62.5, 3.5, 116),
		Vector3.new(71.5, 3.5, 116),
		Vector3.new(80.5, 3.5, 116),
		Vector3.new(89.5, 3.5, 116),
		Vector3.new(98.5, 3.5, 116),
		Vector3.new(107.5, 3.5, 116)
	},
	["eyePadsFor"] = function(p31) -- name: eyePadsFor
		-- upvalues: (copy) v_u_32
		if (p31 or 1) >= 3 then
			return v_u_32.EYE_PADS_14
		else
			return v_u_32.EYE_PADS
		end
	end,
	["EGG_REACH"] = 7,
	["EGGS"] = {
		Vector3.new(60, 1, 30),
		Vector3.new(84, 1, 30),
		Vector3.new(108, 1, 30),
		Vector3.new(132, 1, 30)
	},
	["SHOWCASE_EYE"] = Vector3.new(40, 0, -8),
	["SHOWCASE_PET"] = Vector3.new(26, 0, 90),
	["SHOWCASE_PET2"] = Vector3.new(-26, 0, 74),
	["SHOWCASE_EYE_ALL"] = Vector3.new(80, 0, 0),
	["SHOWCASE_REACH"] = 9,
	["FREE_REWARD"] = Vector3.new(-38, 0, 23),
	["FREE_REWARD_RADIUS"] = 6,
	["PORTAL"] = Vector3.new(0, 10, 144),
	["PORTAL_RADIUS"] = 8,
	["LEADERBOARDS"] = {
		{
			["kind"] = "Playtime",
			["at"] = Vector3.new(96, 0, 152)
		},
		{
			["kind"] = "Chakra",
			["at"] = Vector3.new(68, 0, 152)
		},
		{
			["kind"] = "Trophies",
			["at"] = Vector3.new(40, 0, 152)
		}
	},
	["PLAYER_GROUP"] = "Players",
	["DEBRIS_GROUP"] = "EnemyDebris"
}
local v_u_33 = require(script.Parent.Worlds)
function v_u_32.mapLive(p34) -- name: mapLive
	-- upvalues: (copy) v_u_33
	local v35 = v_u_33[p34]
	return v35 == nil and true or v35.ready
end
return v_u_32