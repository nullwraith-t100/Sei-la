local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(196, 236, 255)
local v_u_6 = Color3.fromRGB(40, 96, 210)
local v_u_7 = {
	{
		["r"] = 2.2,
		["tilt"] = 0.5,
		["lean"] = 0.3,
		["speed"] = 1.9,
		["size"] = 0.42
	},
	{
		["r"] = 3,
		["tilt"] = -0.62,
		["lean"] = 2.4,
		["speed"] = 1.3,
		["size"] = 0.55
	},
	{
		["r"] = 3.8,
		["tilt"] = 0.34,
		["lean"] = 4.3,
		["speed"] = 0.9,
		["size"] = 0.66
	}
}
local function v_u_14(p8, p9, p10) -- name: face
	local v11 = p10 - p9 * p10:Dot(p9)
	local v12
	if v11.Magnitude > 0.001 then
		v12 = v11.Unit
	else
		local v13 = p9.Y
		v12 = math.abs(v13) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p8, p9:Cross(v12), p9, v12)
end
return function(p_u_15)
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_14
	return {
		["w4_yumegan"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_2, (copy) p_u_15, (ref) v_u_7, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_14
			local v_u_18 = v_u_2.color(p17.color)
			local v19 = v_u_2.color(p17.color2)
			local v20 = p_u_16.headY / 1.5
			local v_u_21 = math.clamp(v20, 0.7, 3)
			local v_u_22 = p_u_15.crownOf(p_u_16)
			local v_u_23 = {}
			local v_u_24 = 0
			local v_u_25 = false
			local v_u_26 = 0
			local v_u_27 = -1
			for v28 = 1, #v_u_7 do
				v_u_23[v28] = {
					["angle"] = 0,
					["phase"] = nil,
					["from"] = 0,
					["wraps"] = 0,
					["phase"] = v28 * 2.1
				}
			end
			local v_u_29 = Vector3.new(0, 0, 0)
			local v_u_30 = Vector3.new(0, 0, 0)
			local v_u_31 = Vector3.new(0, 0, 0)
			local v_u_32 = {}
			local v_u_33 = {}
			local v34 = p_u_16.ticks
			local function v75(p35, p36)
				-- upvalues: (ref) v_u_31, (ref) p_u_15, (ref) v_u_29, (copy) v_u_21, (ref) v_u_30, (copy) v_u_22, (copy) p_u_16, (ref) v_u_27, (ref) v_u_25, (ref) v_u_26, (ref) v_u_7, (copy) v_u_23, (ref) v_u_24, (copy) v_u_32, (copy) v_u_33, (ref) v_u_2, (ref) v_u_5, (ref) v_u_4, (copy) v_u_18, (ref) v_u_3
				v_u_31 = p_u_15.camPos()
				v_u_29 = p35.Position + Vector3.new(0, 0.35, 0) * v_u_21
				v_u_30 = v_u_22(p35).Position + Vector3.new(0, 1, 0) * p_u_16.eyeLift
				local v37 = p36 * 0.25
				local v38
				if p36 >= 2.5 then
					local v39 = (p36 - 2.5) / 5
					v38 = math.floor(v39)
				else
					v38 = -1
				end
				local v40 = v38 < 0 and -1 or p36 - 2.5 - v38 * 5
				if v38 >= 0 and (v38 ~= v_u_27 and v40 < 0.55) then
					v_u_27 = v38
					v_u_25 = false
					local v41 = v_u_29 - v_u_31
					local v42 = v41.X
					local v43 = v41.Z
					local v44 = Vector3.new(v42, 0, v43)
					local v45 = v44.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v44.Unit:Cross(Vector3.new(0, 1, 0))
					local v46 = v45.Z
					local v47 = v45.X
					v_u_26 = math.atan2(v46, v47)
					for v48, v49 in v_u_7 do
						local v50 = v_u_23[v48]
						v50.from = v50.angle
						local v51 = v_u_26 + v37 + v49.lean
						local v52 = (v51 - v50.from) % 6.283185307179586
						v50.wraps = v50.from + v52 + (v52 < 3.141592653589793 and 6.283185307179586 or 0) - v51
					end
				end
				if v40 >= 0 and v40 < 0.55 then
					local v53 = v40 / 0.55
					local v54 = math.clamp(v53, 0, 1)
					v_u_24 = v54 * v54 * (3 - v54 * 2)
				elseif v40 >= 0.55 and v40 < 1 then
					v_u_24 = 1
				elseif v40 >= 1 and v40 < 1.5 then
					local v55 = (v40 - 1) / 0.5
					local v56 = math.clamp(v55, 0, 1)
					v_u_24 = 1 - v56 * v56 * (3 - v56 * 2)
				else
					v_u_24 = 0
				end
				for v57, v58 in v_u_7 do
					local v59 = v_u_23[v57]
					local v60 = v_u_26 + v37 + v58.lean + v59.wraps
					if v40 >= 0 and (v40 < 0.55 and v38 == v_u_27) then
						local v61 = v59.from
						local v62 = v60 - v59.from
						local v63 = v40 / 0.55
						local v64 = math.clamp(v63, 0, 1)
						v59.angle = v61 + v62 * (v64 * v64 * (3 - v64 * 2))
						v59.phase = v59.angle - v58.speed * p36
					elseif v40 >= 0.55 and v40 < 1 then
						v59.angle = v60
						v59.phase = v59.angle - v58.speed * p36
					else
						v59.angle = v58.speed * p36 + v59.phase
					end
					local v65 = v58.tilt * (1 - v_u_24)
					local v66 = p36 * 0.7 + v57
					local v67 = v65 + math.sin(v66) * 0.12 * (1 - v_u_24)
					local v68 = CFrame.new(v_u_29) * CFrame.Angles(0, v37 + v58.lean, 0) * CFrame.Angles(v67, 0, 0)
					v_u_32[v57] = v68
					local v69 = v_u_33
					local v70 = CFrame.new
					local v71 = v59.angle
					local v72 = math.cos(v71) * v58.r * v_u_21
					local v73 = v59.angle
					v69[v57] = (v68 * v70(v72, 0, math.sin(v73) * v58.r * v_u_21)).Position
				end
				if v40 >= 0.55 and (not v_u_25 and v38 == v_u_27) then
					v_u_25 = true
					if (v_u_29 - v_u_31).Magnitude < 150 then
						for _, v74 in v_u_33 do
							v_u_2.flash(v74, v_u_5, v_u_21 * 2.6 * p_u_16.fx, 0.25)
						end
						v_u_2.flash(v_u_30, v_u_4, v_u_21 * 4.5 * p_u_16.fx, 0.3)
						v_u_2.ring(p_u_15.feetAt(p_u_16, p35, 0.15), v_u_18, 8 * p_u_16.fx, 0.6, v_u_3.Ring)
					end
				end
			end
			table.insert(v34, v75)
			p_u_15.throb(p_u_16, 5, 3.05, 2, nil)
			local v_u_76 = v_u_31
			local v_u_77 = v_u_30
			local v_u_78 = v_u_29
			for v_u_79, v80 in v_u_7 do
				local v81, v82 = p_u_15.picture(v80.r * 2 * v_u_21, v_u_3.Ring, v_u_18, 0.35)
				for _, v83 in v82 do
					v83.Color3 = Color3.new(v_u_18.R * 1.3, v_u_18.G * 1.3, v_u_18.B * 1.3)
				end
				p_u_15.add(p_u_16, v81, function()
					-- upvalues: (copy) v_u_32, (copy) v_u_79, (ref) v_u_78
					return v_u_32[v_u_79] or CFrame.new(v_u_78)
				end)
				local v84 = v80.size * v_u_21
				local v85 = p_u_15.ball(v84, v_u_5, 0, Enum.Material.Neon)
				local function v86()
					-- upvalues: (copy) v_u_33, (copy) v_u_79, (ref) v_u_78
					return CFrame.new(v_u_33[v_u_79] or v_u_78)
				end
				p_u_15.add(p_u_16, v85, v86)
				p_u_15.add(p_u_16, p_u_15.ball(v84 * 1.7, v_u_18, 0.6), p_u_15.behind(v86, v84 * 0.6))
				p_u_15.tail(v85, v_u_18, v_u_6, v84 * 0.7, 0.8)
				if v_u_79 ~= #v_u_7 then
					break
				end
				local v87 = p_u_15.ball(v_u_21 * 0.22, v_u_4, 0, Enum.Material.Neon)
				p_u_15.add(p_u_16, v87, function(_, p88)
					-- upvalues: (copy) v_u_33, (copy) v_u_79, (ref) v_u_78, (copy) v_u_21
					local v89 = p88 * 4.2
					local v90 = v_u_33[v_u_79] or v_u_78
					local v91 = CFrame.new
					local v92 = math.cos(v89)
					local v93 = v89 * 0.5
					local v94 = math.sin(v93) * 0.35
					local v95 = math.sin(v89)
					return v91(v90 + Vector3.new(v92, v94, v95) * 0.75 * v_u_21)
				end)
			end
			local v_u_96 = p_u_15.bar(Vector3.new(0.14, 0.14, 1) * v_u_21, v_u_4, 1)
			local v_u_97 = -1
			p_u_15.add(p_u_16, v_u_96, function()
				-- upvalues: (copy) v_u_33, (ref) v_u_7, (ref) v_u_78, (copy) v_u_21, (ref) v_u_24, (ref) v_u_97, (copy) v_u_96
				local v98 = (v_u_33[#v_u_7] or v_u_78) - v_u_78
				local v99 = v98.Magnitude + v_u_21 * 1.4
				local v100 = math.max(v99, 0.1)
				local v101 = (v_u_24 - 0.6) / 0.4
				local v102 = math.clamp(v101, 0, 1)
				local v103 = 1 - v102 * 0.75
				local v104 = v103 - v_u_97
				if math.abs(v104) > 0.01 then
					v_u_97 = v103
					v_u_96.Transparency = v103
				end
				local v105 = v_u_96
				local v106 = v_u_21 * 0.16 * (v102 + 0.4)
				local v107 = v_u_21 * 0.16 * (v102 + 0.4)
				v105.Size = Vector3.new(v106, v107, v100)
				local v108 = v98.Magnitude <= 0.01 and Vector3.new(1, 0, 0) or v98.Unit
				return CFrame.lookAt(v_u_78 + v108 * v100 * 0.5, v_u_78 + v108 * v100)
			end)
			local v_u_109, v_u_110 = p_u_15.picture(v_u_21 * 4.56, v_u_3.Glow, v_u_18, 0.5)
			local v_u_111, v_u_112 = p_u_15.picture(v_u_21 * 3.8, v_u_3.YumeStar, v_u_18, 0)
			for _, v113 in v_u_112 do
				local v114 = v_u_5
				v113.Color3 = Color3.new(v114.R * 1.5, v114.G * 1.5, v114.B * 1.5)
			end
			local v_u_115 = -1
			p_u_15.add(p_u_16, v_u_111, function(p116, p117)
				-- upvalues: (ref) v_u_76, (ref) v_u_77, (ref) v_u_24, (ref) v_u_115, (copy) v_u_112, (copy) v_u_110, (copy) v_u_21, (copy) v_u_111, (ref) v_u_14
				local v118 = v_u_76 - v_u_77
				local v119 = v118.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v118.Unit
				local v120 = p116.Position - v_u_76
				local v121 = ((v120.Magnitude <= 0.01 and 0 or v120.Unit:Dot(p116.LookVector)) + 0.1) * 1.6
				local v122 = math.clamp(v121, 0, 1) * 0.45 * (1 - v_u_24)
				local v123 = v122 - v_u_115
				if math.abs(v123) > 0.01 then
					v_u_115 = v122
					for _, v124 in v_u_112 do
						v124.Transparency = v122
					end
					for _, v125 in v_u_110 do
						v125.Transparency = v122 * 0.5 + 0.5
					end
				end
				local v126 = p117 * 9
				local v127 = math.sin(v126) * 0.04 + 1 + v_u_24 * 0.3
				local v128 = v_u_21 * 3.8 * v127
				v_u_111.Size = Vector3.new(v128, 0.05, v128)
				local v129 = Vector3.new(0, 1, 0) - v119 * (Vector3.new(0, 1, 0)):Dot(v119)
				local v130 = v129.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v129.Unit
				local v131 = p117 * 0.3 + v_u_24 * 1.2
				local v132 = v130:Cross(v119)
				return v_u_14(v_u_77 - v119 * 0.3, v119, v130 * math.cos(v131) + v132 * math.sin(v131))
			end)
			p_u_15.add(p_u_16, v_u_109, function(_, p133)
				-- upvalues: (ref) v_u_76, (ref) v_u_77, (copy) v_u_21, (ref) v_u_24, (copy) v_u_109, (ref) v_u_14
				local v134 = v_u_76 - v_u_77
				local v135 = v134.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v134.Unit
				local v136 = v_u_21 * 3.8
				local v137 = v_u_24 * 0.4 + 1.1
				local v138 = p133 * 3
				local v139 = v136 * (v137 + math.sin(v138) * 0.05)
				v_u_109.Size = Vector3.new(v139, 0.05, v139)
				return v_u_14(v_u_77 - v135 * 0.45, v135, Vector3.new(0, 1, 0))
			end)
			local v140 = p_u_15.picture(v_u_21 * 8, v_u_3.Glow, v19, 0.3)
			p_u_15.add(p_u_16, v140, function(p141)
				-- upvalues: (ref) p_u_15, (copy) p_u_16
				return CFrame.new(p_u_15.feetAt(p_u_16, p141, 0.06))
			end)
			local v142 = p_u_15.picture(v_u_21 * 6.5, v_u_3.Ring, v_u_18, 0.55)
			p_u_15.add(p_u_16, v142, function(p143, p144)
				-- upvalues: (ref) p_u_15, (copy) p_u_16
				return CFrame.new(p_u_15.feetAt(p_u_16, p143, 0.09)) * CFrame.Angles(0, p144 * 0.4, 0)
			end)
			p_u_15.particles(p_u_16, "AuraMode", v_u_18, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_15.particles(p_u_16, "Petals", v_u_5, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end