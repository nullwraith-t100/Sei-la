local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
return function(p_u_7)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (copy) v_u_6, (copy) v_u_5
	local v8 = p_u_7.rgb
	local v_u_9 = p_u_7.WHITE
	local v_u_10 = v8(241, 224, 138)
	local v_u_11 = v8(236, 186, 64)
	local v_u_12 = v8(255, 253, 240)
	local v_u_13 = v8(30, 25, 18)
	local function v_u_34(p14, p15, p16, p17) -- name: tomoeRig
		-- upvalues: (copy) p_u_7, (copy) v_u_13
		local v18 = p_u_7.newRig()
		local v19 = p_u_7.rigAdd(v18, Vector3.new(1, 1, 1) * p14, CFrame.identity, v_u_13, 0, Enum.Material.SmoothPlastic, p16)
		v19.Shape = Enum.PartType.Ball
		v19.Reflectance = 0.25
		local v20 = p_u_7.rigAdd(v18, Vector3.new(0.6, 0.5, 1.05) * p14, CFrame.new(p14 * 0.17, 0, p14 * 0.58) * CFrame.Angles(0, 0.35, 0), v_u_13, 0, Enum.Material.SmoothPlastic, p16)
		local v21 = Instance.new("SpecialMesh")
		v21.MeshType = Enum.MeshType.Sphere
		v21.Parent = v20
		local v22 = p_u_7.rigAdd(v18, Vector3.new(0.34, 0.3, 0.9) * p14, CFrame.new(p14 * 0.56, 0, p14 * 1.12) * CFrame.Angles(0, 1, 0), v_u_13, 0, Enum.Material.SmoothPlastic, p16)
		local v23 = Instance.new("SpecialMesh")
		v23.MeshType = Enum.MeshType.Sphere
		v23.Parent = v22
		if p15 then
			local v24 = CFrame.new(0, p14 * -0.14, 0)
			local v25 = p_u_7.rigAdd
			local v26 = p14 * 0.12
			local v27 = p14 * 1.32
			local v28 = p14 * 1.32
			v25(v18, Vector3.new(v26, v27, v28), v24 * CFrame.Angles(0, 0, 1.5707963267948966), p15, 0, nil, p16).Shape = Enum.PartType.Cylinder
		end
		if p15 and p17 then
			local v29 = CFrame.new(0, p14 * -0.14, 0)
			local v30 = p_u_7.rigAdd(v18, Vector3.new(0.92, 0.12, 1.4) * p14, v29 * CFrame.new(p14 * 0.17, 0, p14 * 0.6) * CFrame.Angles(0, 0.35, 0), p15, 0, nil, p16)
			local v31 = Instance.new("SpecialMesh")
			v31.MeshType = Enum.MeshType.Sphere
			v31.Parent = v30
			local v32 = p_u_7.rigAdd(v18, Vector3.new(0.6, 0.12, 1.25) * p14, v29 * CFrame.new(p14 * 0.58, 0, p14 * 1.14) * CFrame.Angles(0, 1, 0), p15, 0, nil, p16)
			local v33 = Instance.new("SpecialMesh")
			v33.MeshType = Enum.MeshType.Sphere
			v33.Parent = v32
		end
		return v18
	end
	local function v_u_57(p_u_35, p_u_36, p_u_37, p38, p39, p_u_40, p_u_41, p42, p43) -- name: picture
		-- upvalues: (ref) v_u_4, (ref) v_u_1, (copy) p_u_7
		local v_u_44 = v_u_4.part(Vector3.new(p_u_36, 0.05, p_u_36), p_u_35, p39, {
			["transparency"] = 1
		})
		local v_u_45 = p42 or 0
		local v_u_46 = {}
		for _, v47 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v48 = Instance.new("Decal")
			v48.Face = v47
			v48.Texture = p38
			v48.Color3 = p39
			v48.Transparency = v_u_45
			v48.Parent = v_u_44
			table.insert(v_u_46, v48)
		end
		v_u_1:AddItem(v_u_44, p_u_40 + 0.1)
		local v_u_49 = p43 or 0.35
		local v_u_50 = math.random() * 6.28
		p_u_7.animate(p_u_40, 0, function(p51)
			-- upvalues: (copy) p_u_36, (copy) p_u_37, (copy) v_u_44, (copy) p_u_35, (copy) v_u_50, (copy) p_u_40, (copy) p_u_41, (copy) v_u_49, (copy) v_u_46, (copy) v_u_45
			local v52 = 1 - (1 - p51) ^ 2
			local v53 = p_u_36 + (p_u_37 - p_u_36) * v52
			v_u_44.Size = Vector3.new(v53, 0.05, v53)
			v_u_44.CFrame = p_u_35 * CFrame.Angles(0, v_u_50 + p51 * p_u_40 * p_u_41, 0)
			local v54 = (p51 - v_u_49) / (1 - v_u_49)
			local v55 = math.clamp(v54, 0, 1)
			for _, v56 in v_u_46 do
				v56.Transparency = v_u_45 + (1 - v_u_45) * v55
			end
			if p51 >= 1 then
				v_u_44:Destroy()
			end
		end)
	end
	local function v_u_74(p58, p59) -- name: meteorShot
		-- upvalues: (copy) v_u_34, (copy) v_u_11, (ref) v_u_4, (copy) v_u_10, (ref) v_u_1, (copy) p_u_7, (copy) v_u_12, (ref) v_u_3
		local v_u_60 = 2.4 * p58.size
		local v_u_61 = v_u_34(v_u_60, v_u_11, 3, not p58.lite)
		local v_u_62 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p59, v_u_10, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_62, 3)
		p_u_7.streak(v_u_62, v_u_11, v_u_12, 2.6 * p58.size, 0.22)
		local v_u_63
		if p58.lite then
			v_u_63 = nil
		else
			v_u_63 = p_u_7.loop("Trail", v_u_62, v_u_11, 0.9)
		end
		local v_u_64 = false
		return {
			["place"] = function(p65, p66) -- name: place
				-- upvalues: (copy) v_u_62, (ref) p_u_7, (copy) v_u_61, (ref) v_u_3, (copy) v_u_60
				v_u_62.CFrame = p65
				local v67 = p_u_7.rigPlace
				local v68 = v_u_61
				local v69 = p65.Position
				local v70 = v_u_3.CurrentCamera
				local v71
				if v70 then
					v71 = v70.CFrame
				else
					v71 = CFrame.identity
				end
				local v72 = CFrame.fromMatrix(v69, v71.RightVector, -v71.LookVector) * CFrame.Angles(0, -p66 * 22, 0)
				local v73 = v_u_60
				v67(v68, v72 * CFrame.new(v73 * -0.25, 0, v73 * -0.45), 1)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_64, (ref) v_u_63, (ref) v_u_1, (copy) v_u_62, (ref) p_u_7, (copy) v_u_61
				if not v_u_64 then
					v_u_64 = true
					if v_u_63 then
						v_u_63()
					end
					v_u_1:AddItem(v_u_62, 0.8)
					p_u_7.rigDestroy(v_u_61)
				end
			end
		}
	end
	local v254 = {
		["sage_rings_a"] = {
			["cast"] = function(p75) -- name: cast
				-- upvalues: (ref) v_u_4, (copy) v_u_11, (copy) p_u_7, (copy) v_u_12, (copy) v_u_10
				local v76 = p75.size
				local v77 = p75.eye + p75.dir * 1
				v_u_4.flash(v77, v_u_11, 3 * v76, 0.12)
				p_u_7.pop(v77, v_u_12, 1.4 * v76, 0.3 * v76, 0.1)
				if not p75.lite then
					p_u_7.glint(v77, v_u_10, 4 * v76, 0.13)
				end
			end,
			["beam"] = function(p78, p79, p_u_80) -- name: beam
				-- upvalues: (copy) p_u_7, (copy) v_u_12, (copy) v_u_11, (ref) v_u_4, (copy) v_u_10, (copy) v_u_34, (ref) v_u_3
				local v_u_81 = p78.size
				local v_u_82 = (p_u_80 - p79).Unit
				local v_u_83 = p79 + v_u_82 * 1
				local v_u_84 = (p_u_80 - v_u_83).Magnitude
				p_u_7.thin(p_u_7.rod(v_u_83, p_u_80, 0.35 * v_u_81, v_u_12), 0.16)
				p_u_7.thin(p_u_7.rod(v_u_83, p_u_80, 1.3 * v_u_81, v_u_11, 0.45), 0.18)
				v_u_4.flash(v_u_83, v_u_10, 2.6 * v_u_81, 0.1)
				local v85 = p78.lite and 3 or 4
				local v_u_86 = 1.4 * v_u_81
				local v_u_87 = {}
				for v88 = 1, v85 do
					local v89 = v_u_34
					local v90
					if p78.lite then
						v90 = nil
					else
						v90 = v_u_11
					end
					local v91 = v89(v_u_86, v90, 1)
					if not p78.lite and v88 == 1 then
						p_u_7.streak(v91.parts[1], v_u_11, v_u_12, 0.6 * v_u_81, 0.1)
					end
					local v92 = {
						["rig"] = v91,
						["lag"] = (v88 - 1) * 0.025,
						["phase"] = (v88 - 1) * 3.141592653589793 * 2 / 3
					}
					table.insert(v_u_87, v92)
				end
				local v_u_93 = p_u_7.aimAt(v_u_83, v_u_82)
				local v_u_94 = os.clock()
				p_u_7.runNow(function()
					-- upvalues: (copy) v_u_94, (copy) v_u_87, (ref) p_u_7, (copy) v_u_93, (copy) v_u_83, (copy) v_u_82, (copy) v_u_84, (copy) v_u_81, (ref) v_u_3, (copy) v_u_86
					local v95 = os.clock() - v_u_94
					local v96 = false
					for _, v97 in v_u_87 do
						local v98 = (v95 - v97.lag) / 0.17
						local v99 = math.clamp(v98, 0, 1)
						if v99 >= 1 then
							if not v97.rig.parts[1].Parent then
								continue
							end
							p_u_7.rigDestroy(v97.rig)
						else
							v96 = true
							local v100 = v97.phase + v95 * 26
							local v101 = v_u_93.RightVector * math.cos(v100) + v_u_93.UpVector * math.sin(v100)
							local v102 = v_u_83 + v_u_82 * (v_u_84 * v99) + v101 * 1.1 * v_u_81
							local v103
							if v99 > 0 then
								local v104 = v99 * 6
								v103 = math.min(v104, 1)
							else
								v103 = 0.02
							end
							local v105 = p_u_7.rigPlace
							local v106 = v97.rig
							local v107 = v_u_3.CurrentCamera
							local v108
							if v107 then
								v108 = v107.CFrame
							else
								v108 = CFrame.identity
							end
							local v109 = CFrame.fromMatrix(v102, v108.RightVector, -v108.LookVector) * CFrame.Angles(0, v97.phase - v95 * 24, 0)
							local v110 = v_u_86 * v103
							v105(v106, v109 * CFrame.new(v110 * -0.25, 0, v110 * -0.45), v103)
						end
					end
					return v96
				end)
				p_u_7.after(0.17, function()
					-- upvalues: (ref) v_u_4, (copy) p_u_80, (ref) v_u_11, (copy) v_u_81
					v_u_4.flash(p_u_80, v_u_11, 3 * v_u_81, 0.12)
				end)
			end,
			["hit"] = function(p111, p112, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_11
				p_u_7.burst("Impact", p112, v_u_11, 0.6)
				p_u_7.beamHitSound(p111, p112, "Orb")
			end
		},
		["sage_rings_e"] = {
			["cast"] = function(p113) -- name: cast
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_12, (copy) v_u_34
				p_u_7.skillCast(p113, v_u_11)
				p_u_7.glint(p113.eye, v_u_12, 5, 0.2)
				if not p113.lite then
					local v_u_114 = { v_u_34(1.1, v_u_11, 1), v_u_34(1.1, v_u_11, 1), v_u_34(1.1, v_u_11, 1) }
					local v_u_115 = p113.eye + Vector3.new(0, 1.5, 0)
					p_u_7.animate(0.35, 0, function(p116)
						-- upvalues: (copy) v_u_114, (copy) v_u_115, (ref) p_u_7
						for v117, v118 in v_u_114 do
							local v119 = v117 / 3 * 3.141592653589793 * 2 + p116 * 9
							local v120 = 1.8 + p116 * 2
							local v121 = v_u_115
							local v122 = math.cos(v119) * v120
							local v123 = p116 * p116 * 14
							local v124 = math.sin(v119) * v120
							local v125 = v121 + Vector3.new(v122, v123, v124)
							local v126 = -math.sin(v119)
							local v127 = math.cos(v119)
							local v128 = Vector3.new(v126, 0, v127)
							p_u_7.rigPlace(v118, CFrame.lookAt(v125, v125 + v128), 1 - p116 * 0.5)
							if p116 < 1 then
								continue
							end
							p_u_7.rigDestroy(v118)
						end
					end)
				end
			end,
			["windup"] = function(p129, p130, p131) -- name: windup
				-- upvalues: (copy) p_u_7, (ref) v_u_3, (copy) v_u_11, (ref) v_u_6, (copy) v_u_10, (copy) v_u_12
				local v132 = p129.ability.radius
				local v133 = p131 + 0.15
				local v134 = p_u_7.ground(p130, 22)
				local v135 = v_u_3.CurrentCamera
				local v136 = ((not v135 and Vector3.new(0, 1, 0) or (v135.CFrame.Position - v134).Unit) - Vector3.new(0, 1.2, 0)).Unit
				p_u_7.sigil(p_u_7.facing(v134, v136), v132 * 0.6, v_u_11, v_u_6.Ring, v133, 1.6)
				p_u_7.sigil(p_u_7.facing(v134 - v136 * 0.3, v136), v132 * 0.45, v_u_10, v_u_6.MagicCircle, v133, -2)
				p_u_7.sigil(p_u_7.facing(v134 - v136 * 0.6, v136), v132 * 0.75, v_u_12, v_u_6.Ring, v133, -1)
				p_u_7.burst("Flash", v134, v_u_11, 0.6)
				p_u_7.sigil(CFrame.new(p_u_7.ground(p130, 0.15)), v132, v_u_11, v_u_6.Ring, v133, 0.8)
			end,
			["strike"] = function(p_u_137, p138, p139) -- name: strike
				-- upvalues: (copy) p_u_7, (ref) v_u_3, (copy) v_u_74, (copy) v_u_11, (copy) v_u_12, (ref) v_u_4, (copy) v_u_10, (ref) v_u_6, (copy) v_u_57, (copy) v_u_13, (ref) v_u_5
				local v_u_140 = p_u_137.ability.strikeRadius or 6.5
				local v141 = p_u_137.target
				local v142 = p_u_7.ground(v141, 22)
				local v143 = v_u_3.CurrentCamera
				local v144 = ((not v143 and Vector3.new(0, 1, 0) or (v143.CFrame.Position - v142).Unit) - Vector3.new(0, 1.2, 0)).Unit
				local v145 = p_u_7.facing(v142, v144)
				local v146 = math.random() * 3.141592653589793 * 2
				local v147 = v142 + (v145.RightVector * math.cos(v146) + v145.LookVector * math.sin(v146)) * p_u_137.ability.radius * 0.35
				p_u_7.drop(p_u_137, v_u_74, v147, p_u_7.ground(p138, 1.2), 0.18, p139, nil, function(p148)
					-- upvalues: (ref) p_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_4, (ref) v_u_10, (copy) v_u_140, (ref) v_u_6, (ref) v_u_57, (ref) v_u_13, (copy) p_u_137, (ref) v_u_5
					local v149 = p_u_7.ground(p148)
					p_u_7.burst("Impact", p_u_7.ground(p148, 1), v_u_11, 1.1)
					p_u_7.pop(p_u_7.ground(p148, 1), v_u_12, 1.5, 7, 0.15, 0.3)
					v_u_4.ring(v149, v_u_10, v_u_140, 0.3, v_u_6.Ring)
					v_u_57(CFrame.new(p_u_7.ground(p148, 0.12)), v_u_140 * 0.8, v_u_140 * 1.5, v_u_6.Ring, v_u_11, 0.75, 2, 0.05, 0.4)
					v_u_57(CFrame.new(p_u_7.ground(p148, 0.15)), v_u_140 * 0.4, v_u_140 * 0.9, v_u_6.Ring, v_u_13, 0.75, -3, 0.15, 0.4)
					if not p_u_137.lite then
						if math.random() < 0.5 then
							p_u_7.chunks(p_u_7.ground(p148, 0.6), { p_u_7.EARTH[1], p_u_7.EARTH[2], v_u_11 }, 4, 22, 0.5, 0.6)
						end
						p_u_7.mark(p148, v_u_13, v_u_140 * 0.45, 1, v_u_6.CrackLines, 0.2)
					end
					v_u_5.play("Hit", {
						["at"] = nil,
						["volume"] = 0.5,
						["at"] = p148
					})
				end)
			end,
			["hit"] = function(p150, p151, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_12
				p_u_7.burst("Impact", p151, v_u_11, 0.8)
				if not p150.lite then
					p_u_7.glint(p151, v_u_12, 3.2, 0.15)
				end
			end
		},
		["sage_rings_r"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p_u_152) -- name: cast
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_12, (copy) v_u_57, (ref) v_u_6
				p_u_7.skillCast(p_u_152, v_u_11, true)
				p_u_7.burst("Flash", p_u_152.eye, v_u_11, 0.4)
				p_u_7.glint(p_u_152.eye, v_u_12, 7, 0.22)
				for v153, v_u_154 in { -1.5, 0, 1.4 } do
					p_u_7.after((v153 - 1) * 0.04, function()
						-- upvalues: (ref) v_u_57, (copy) p_u_152, (copy) v_u_154, (ref) v_u_6, (ref) v_u_11
						local v155 = v_u_154
						v_u_57(CFrame.new(p_u_152.origin + Vector3.new(0, v155, 0)), 4, 18, v_u_6.Ring, v_u_11, 0.4, 3, 0, 0.2)
					end)
				end
			end,
			["windup"] = function(p156, p157, p158) -- name: windup
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (ref) v_u_6, (copy) v_u_57, (copy) v_u_12, (copy) v_u_10
				local v159 = p156.ability.radius
				p_u_7.sigil(CFrame.new(p_u_7.ground(p157, 0.14)), v159, v_u_11, v_u_6.MagicCircle, p158 + 0.1, 0.8)
				v_u_57(CFrame.new(p_u_7.ground(p157, 0.3)), v159 * 2.8, v159 * 1.6, v_u_6.Ring, v_u_12, p158 + 0.15, 2)
				for v160 = 1, 9 do
					local v161 = v160 / 9 * 3.141592653589793 * 2
					local v162 = p_u_7.ground(p157)
					local v163 = math.cos(v161)
					local v164 = math.sin(v161)
					local v165 = v162 + Vector3.new(v163, 0, v164) * v159 * 0.95
					p_u_7.thin(p_u_7.pillar(v165, 14, 0.8, v_u_10, 0.2), p158 + 0.15, true)
				end
			end,
			["zone"] = function(p166, p_u_167, p_u_168) -- name: zone
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (ref) v_u_6, (copy) v_u_10, (copy) v_u_12, (ref) v_u_4, (ref) v_u_1, (copy) v_u_34, (copy) v_u_57
				local v_u_169 = p166.ability.radius
				local v_u_170 = p166.lite
				local v171 = p_u_7.ground(p_u_167, 7)
				p_u_7.sigil(CFrame.new(p_u_7.ground(p_u_167, 0.14)), v_u_169, v_u_11, v_u_6.MagicCircle, p_u_168, 0.8)
				p_u_7.sigil(CFrame.new(p_u_7.ground(p_u_167, 0.18)), v_u_169 * 1.08, v_u_10, v_u_6.Ring, p_u_168, -0.5)
				local v_u_172 = p_u_7.ball(v171, v_u_12, 1.5, 0)
				local v_u_173 = p_u_7.ball(v171, v_u_11, 3, 0.6)
				v_u_4.tween(v_u_172, p_u_168, {
					["Size"] = Vector3.new(5, 5, 5)
				}, Enum.EasingStyle.Linear)
				v_u_4.tween(v_u_173, p_u_168, {
					["Size"] = Vector3.new(9, 9, 9)
				}, Enum.EasingStyle.Linear)
				p_u_7.burst("Flash", v171, v_u_11, 0.6)
				local v174 = v_u_4.part
				local v175 = v_u_169 * 2
				local v176 = v_u_169 * 2
				local v_u_177 = v174(Vector3.new(v175, 0.05, v176), CFrame.new(v171), v_u_10, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_177, p_u_168 + 1)
				for _, v178 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
					local v179 = Instance.new("Decal")
					v179.Face = v178
					v179.Texture = v_u_6.Ring
					v179.Color3 = v_u_11
					v179.Transparency = 0.1
					v179.Parent = v_u_177
				end
				local v_u_180 = {}
				local v_u_181 = {}
				for v182 = 1, 9 do
					local v183 = v_u_34(3.8, v_u_11, p_u_168 + 1, not v_u_170)
					v_u_180[v182] = v183
					if v_u_170 then
						continue
					end
					p_u_7.streak(v183.parts[1], v_u_11, v_u_12, 1.8, 0.25)
					local v184 = v_u_4.part(Vector3.new(0.2, 0.2, 1), CFrame.new(v171), v_u_10, {
						["transparency"] = 0.4
					})
					v_u_1:AddItem(v184, p_u_168 + 1)
					v_u_181[v182] = v184
				end
				local v_u_185 = os.clock()
				local v_u_186 = v_u_185
				local v_u_187 = math.random() * 3.141592653589793
				local v_u_188 = nil
				p_u_7.runNow(function()
					-- upvalues: (copy) v_u_185, (ref) v_u_186, (copy) p_u_168, (ref) v_u_188, (ref) v_u_187, (copy) v_u_169, (copy) v_u_172, (copy) v_u_180, (ref) p_u_7, (copy) p_u_167, (copy) v_u_181, (copy) v_u_177
					local v189 = os.clock()
					local v190 = v189 - v_u_185
					local v191 = v189 - v_u_186
					local v192 = math.min(v191, 0.05)
					v_u_186 = v189
					local v193 = v190 / p_u_168
					local v194 = math.clamp(v193, 0, 1)
					local v195
					if v_u_188 then
						local v196 = (v189 - v_u_188) / 0.12
						v195 = math.clamp(v196, 0, 1)
					else
						v195 = 0
					end
					v_u_187 = v_u_187 + v192 * (v194 * 3.4 * v194 + 1.2)
					local v197 = v_u_169 * (1 - v194 * 0.42) * (1 - v195)
					local v198 = v190 * 2
					local v199 = math.sin(v198) * 0.4 + 7 - v195 * 2
					local v200 = v190 / 0.2
					local v201 = 1 - (1 - math.min(v200, 1)) ^ 2
					local v202 = v_u_172.Position
					for v203, v204 in v_u_180 do
						local v205 = v_u_187 + v203 / 9 * 3.141592653589793 * 2
						local v206 = v190 * 3 + v203
						local v207 = math.sin(v206) * 0.5
						local v208 = p_u_7.ground(p_u_167, v199 + v207)
						local v209 = math.cos(v205)
						local v210 = math.sin(v205)
						local v211 = v208 + Vector3.new(v209, 0, v210) * v197
						local v212 = -math.sin(v205)
						local v213 = math.cos(v205)
						local v214 = Vector3.new(v212, 0, v213)
						p_u_7.rigPlace(v204, CFrame.lookAt(v211, v211 + v214) * CFrame.Angles(0, 0, -0.5), v201 * (1 - v195 * 0.5))
						local v215 = v_u_181[v203]
						if not v215 then
							continue
						end
						local v216 = (v202 - v211).Magnitude
						local v217 = math.max(v216, 0.1)
						v215.Size = Vector3.new(0.2, 0.2, v217)
						v215.CFrame = CFrame.lookAt((v211 + v202) / 2, v202)
					end
					local v218 = v197 * 2 + 2
					local v219 = math.max(v218, 0.2) * v201
					v_u_177.Size = Vector3.new(v219, 0.05, v219)
					v_u_177.CFrame = CFrame.new(p_u_7.ground(p_u_167, v199)) * CFrame.Angles(0, v_u_187 * 0.5, 0)
					if v195 < 1 then
						return v190 < p_u_168 + 1
					end
					for _, v220 in v_u_180 do
						p_u_7.rigDestroy(v220)
					end
					for _, v221 in v_u_181 do
						v221:Destroy()
					end
					v_u_177:Destroy()
					return false
				end)
				local v_u_222 = true
				local v_u_223 = p166.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (ref) v_u_222, (copy) v_u_185, (copy) p_u_168, (ref) p_u_7, (copy) v_u_172, (ref) v_u_12, (ref) v_u_57, (copy) p_u_167, (copy) v_u_169, (ref) v_u_6, (ref) v_u_11, (copy) v_u_170, (ref) v_u_10, (copy) v_u_223
					while v_u_222 and os.clock() - v_u_185 < p_u_168 + 0.5 do
						p_u_7.pop(v_u_172.Position, v_u_12, v_u_172.Size.X, v_u_172.Size.X * 2.2, 0.2, 0.3)
						v_u_57(CFrame.new(p_u_7.ground(p_u_167, 0.3)), v_u_169 * 2.6, 4, v_u_6.Ring, v_u_11, 0.35, 2, 0.1)
						if not v_u_170 then
							p_u_7.inward(p_u_7.ground(p_u_167, 1.5), v_u_10, 4, v_u_169 * 1.2, 0.3)
						end
						task.wait(v_u_223)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_222, (ref) v_u_188, (ref) v_u_4, (copy) v_u_172, (copy) v_u_173, (ref) v_u_1
					v_u_222 = false
					v_u_188 = os.clock()
					v_u_4.tween(v_u_172, 0.12, {
						["Size"] = Vector3.new(1.5, 1.5, 1.5)
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_4.tween(v_u_173, 0.12, {
						["Size"] = Vector3.new(2, 2, 2),
						["Transparency"] = 1
					})
					v_u_1:AddItem(v_u_172, 0.13)
					v_u_1:AddItem(v_u_173, 0.13)
				end
			end,
			["finish"] = function(p224, p225) -- name: finish
				-- upvalues: (copy) p_u_7, (copy) v_u_9, (copy) v_u_11, (copy) v_u_12, (copy) v_u_57, (ref) v_u_6, (ref) v_u_4, (copy) v_u_10, (copy) v_u_34, (copy) v_u_13, (ref) v_u_5
				local v_u_226 = p224.ability.radius
				local v227 = p224.lite
				local v228 = p_u_7.ground(p225)
				local v_u_229 = p_u_7.ground(p225, 5)
				p_u_7.pop(v_u_229, v_u_9, 3, v_u_226 * 1.1, 0.22, 0)
				p_u_7.pop(v_u_229, v_u_11, 4, v_u_226 * 1.5, 0.35, 0.4)
				p_u_7.burst("Explosion", v_u_229, v_u_11, v_u_226 / 6)
				p_u_7.burst("Shockwave", v228 + Vector3.new(0, 0.3, 0), v_u_11, v_u_226 / 14)
				p_u_7.burst("Sparkle", p_u_7.ground(p225, 3), nil, 1.5)
				p_u_7.thin(p_u_7.pillar(v228, 34, v_u_226 * 0.22, v_u_12, 0), 0.4, true)
				local v_u_230 = math.random() * 3.141592653589793
				for v231 = 1, 9 do
					local v232 = v_u_230 + v231 / 9 * 3.141592653589793 * 2
					local v233 = math.cos(v232)
					local v234 = math.sin(v232)
					local v_u_235 = v228 + Vector3.new(v233, 0, v234) * v_u_226 * 0.6
					p_u_7.after(v231 % 3 * 0.03, function()
						-- upvalues: (ref) p_u_7, (copy) v_u_235, (ref) v_u_11
						p_u_7.thin(p_u_7.pillar(v_u_235, 26, 2.2, v_u_11, 0.15), 0.45, true)
					end)
				end
				v_u_57(CFrame.new(p_u_7.ground(p225, 7)), 6, v_u_226 * 3, v_u_6.Ring, v_u_11, 0.45, 3, 0, 0.3)
				v_u_4.ring(v228, v_u_11, v_u_226 * 1.3, 0.5)
				v_u_4.ring(v228, v_u_12, v_u_226 * 1.5, 0.45, v_u_6.SpeedLines)
				v_u_57(CFrame.new(p_u_7.ground(p225, 0.2)), 4, v_u_226 * 2.6, v_u_6.MagicCircle, v_u_11, 0.6, 2, 0, 0.3)
				p_u_7.glint(p_u_7.ground(p225, 6), v_u_12, 22, 0.35)
				p_u_7.spikes(v_u_229, v_u_10, v227 and 6 or 12, v_u_226 * 1.2, 0.3, nil, nil, true)
				if not v227 then
					local v_u_236 = {}
					for v237 = 1, 9 do
						v_u_236[v237] = v_u_34(2.4, v_u_11, 1.5)
					end
					p_u_7.animate(0.5, 0, function(p238)
						-- upvalues: (copy) v_u_236, (copy) v_u_230, (copy) v_u_229, (copy) v_u_226, (ref) p_u_7
						local v239 = 1 - (1 - p238) ^ 2
						for v240, v241 in v_u_236 do
							local v242 = v_u_230 + (v240 + 0.5) / 9 * 3.141592653589793 * 2 + v239 * 1.5
							local v243 = v_u_229
							local v244 = math.cos(v242)
							local v245 = math.sin(v242)
							local v246 = v243 + Vector3.new(v244, 0, v245) * v_u_226 * 1.3 * v239
							local v247 = -math.sin(v242)
							local v248 = math.cos(v242)
							local v249 = Vector3.new(v247, 0, v248)
							p_u_7.rigPlace(v241, CFrame.lookAt(v246, v246 + v249), 1 - 0.4 * p238)
							local v250 = p_u_7.rigFade
							local v251 = (p238 - 0.5) / 0.5
							v250(v241, (math.max(0, v251)))
							if p238 < 1 then
								continue
							end
							p_u_7.rigDestroy(v241)
						end
					end)
					p_u_7.chunks(v228 + Vector3.new(0, 1, 0), { p_u_7.EARTH[1], p_u_7.EARTH[2], v_u_11 }, 12, 40, 1.2, 1)
				end
				p_u_7.mark(p225, v_u_13, v_u_226 * 0.8, 2, v_u_6.CrackLines, 0.1)
				p_u_7.mark(p225, v_u_11, v_u_226 * 0.6, 1.6, v_u_6.CrackGlow, 0.2)
				v_u_5.play("Explosion", {
					["at"] = v228
				})
				if p224.mine then
					v_u_4.shake(0.6, 0.5)
				end
			end,
			["hit"] = function(p252, p253, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_12
				p_u_7.burst("Impact", p253, v_u_11, 0.9)
				if not p252.lite then
					p_u_7.glint(p253, v_u_12, 3.6, 0.15)
				end
			end
		}
	}
	return v254
end