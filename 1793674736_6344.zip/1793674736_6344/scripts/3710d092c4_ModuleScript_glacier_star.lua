local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v2.Shared.Config.Textures)
local function v_u_10(p6, p7, p8) -- name: wedge
	-- upvalues: (copy) v_u_3
	local v9 = Instance.new("WedgePart")
	v9.Anchored = true
	v9.CanCollide = false
	v9.CanQuery = false
	v9.CanTouch = false
	v9.CastShadow = false
	v9.Size = p6
	v9.Color = p7
	v9.Material = Enum.Material.Neon
	v9.Transparency = p8
	v9.TopSurface = Enum.SurfaceType.Smooth
	v9.BottomSurface = Enum.SurfaceType.Smooth
	v9.Parent = v_u_3.folder()
	return v9
end
local function v_u_23(p11, p12, p13, p14, p15) -- name: snowAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
	local v16 = p12.fx
	local v_u_17 = Instance.new("Attachment")
	local v18 = 0.3 * v16
	v_u_17.Position = Vector3.new(0, v18, 0)
	local v_u_19 = Instance.new("ParticleEmitter")
	v_u_19.Texture = v_u_5.Snowflake
	v_u_19.Color = ColorSequence.new(p13)
	v_u_19.LightEmission = 0.4
	v_u_19.LightInfluence = 0
	v_u_19.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.15, p15 * v16), NumberSequenceKeypoint.new(1, p15 * 0.6 * v16) })
	v_u_19.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 1) })
	v_u_19.Lifetime = NumberRange.new(1.2, 2)
	v_u_19.Speed = NumberRange.new(1.4 * v16, 3 * v16)
	v_u_19.SpreadAngle = Vector2.new(180, 180)
	v_u_19.Rotation = NumberRange.new(0, 360)
	v_u_19.RotSpeed = NumberRange.new(-90, 90)
	v_u_19.Drag = 1.2
	local v20 = -1.2 * v16
	v_u_19.Acceleration = Vector3.new(0, v20, 0)
	v_u_19:SetAttribute("BaseRate", p14)
	v_u_19.Rate = p14 * v_u_4.formRate()
	v_u_19.Enabled = true
	v_u_19.Parent = v_u_17
	v_u_17.Parent = p12.root
	p11.own(p12, v_u_17)
	local v21 = p12.stops
	local function v22()
		-- upvalues: (copy) v_u_19, (ref) v_u_1, (copy) v_u_17
		v_u_19.Enabled = false
		v_u_1:AddItem(v_u_17, 2.2)
	end
	table.insert(v21, v22)
	return v_u_19
end
return function(p_u_24)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_10, (copy) v_u_23
	return {
		["w4_glacier_star"] = function(p_u_25, p26)
			-- upvalues: (ref) v_u_3, (copy) p_u_24, (ref) v_u_5, (ref) v_u_10, (ref) v_u_23
			local v27 = v_u_3.color(p26.color)
			local v_u_28 = v_u_3.color(p26.color2)
			local v29 = v27:Lerp(v_u_28, 0.3)
			local v_u_30 = p_u_25.character:GetScale()
			local v_u_31 = nil
			local v_u_36 = p_u_24.throb(p_u_25, 4, 1.5, 2.2, function(p32)
				-- upvalues: (ref) v_u_3, (ref) p_u_24, (copy) p_u_25, (copy) v_u_28, (ref) v_u_5, (copy) v_u_30, (ref) v_u_31
				v_u_3.ring(p_u_24.feetAt(p_u_25, p32, 0.15), v_u_28, 5.5 * p_u_25.fx, 0.45, v_u_5.Ring)
				local v33 = v_u_3.flash
				local v34 = p32.Position
				local v35 = -0.5 * v_u_30
				v33(v34 + Vector3.new(0, v35, 0), v_u_28, 5 * v_u_30, 0.22)
				if v_u_31 then
					v_u_31:Emit(10)
				end
			end)
			local v_u_48 = p_u_24.group(p_u_25, function(p37, p38)
				-- upvalues: (copy) v_u_30
				local v39 = CFrame.new
				local v40 = p37.Position
				local v41 = -0.55 * v_u_30
				local v42 = v39(v40 + Vector3.new(0, v41, 0))
				local v43 = CFrame.Angles
				local v44 = p38 * 0.9
				local v45 = math.sin(v44) * 0.08
				local v46 = p38 * 0.35
				local v47 = p38 * 0.7
				return v42 * v43(v45, v46, math.cos(v47) * 0.08)
			end)
			local v49 = 1.45 * v_u_30
			local v50 = 0.14 * v_u_30
			local v_u_51 = {}
			for v52 = 0, 7 do
				local v53 = v52 * 3.141592653589793 / 4
				local v54 = math.cos(v53)
				local v55 = math.sin(v53)
				local v_u_56 = Vector3.new(v54, 0, v55)
				local v57 = v52 % 2 == 0
				local v_u_58 = (v57 and 3.9 or 3) * v_u_30
				local v59 = (v57 and 0.88 or 0.64) * v_u_30
				local v60 = v_u_58 - v49
				local v61 = CFrame.lookAt(v_u_56 * (v49 + v_u_58) / 2, v_u_56 * v_u_58) * CFrame.Angles(0, 0, 1.5707963267948966)
				for _, v62 in { 1, -1 } do
					local v_u_63 = v61 * CFrame.new(0, v62 * v59 / 2, 0)
					if v62 < 0 then
						v_u_63 = v_u_63 * CFrame.Angles(0, 0, 3.141592653589793)
					end
					local v64 = v_u_10
					local v65 = Vector3.new(v50, v59, v60)
					local v66
					if v57 then
						v66 = v27
					else
						v66 = v29
					end
					local v67 = v64(v65, v66, 0.12)
					table.insert(v_u_51, v67)
					p_u_24.add(p_u_25, v67, function()
						-- upvalues: (copy) v_u_48, (copy) v_u_56, (copy) v_u_36, (copy) v_u_30, (ref) v_u_63
						return v_u_48.cf * CFrame.new(v_u_56 * v_u_36() * 0.55 * v_u_30) * v_u_63
					end)
				end
				local v68 = v_u_56 * v49 * 0.85
				local v69 = v_u_56 * (v_u_58 - 0.25 * v_u_30)
				local v_u_70, v71 = p_u_24.between(v68 + Vector3.new(0, v50, 0), v69 + Vector3.new(0, v50, 0))
				local v72 = p_u_24.add
				local v73 = p_u_24.bar
				local v74 = 0.1 * v_u_30
				local v75 = 0.08 * v_u_30
				v72(p_u_25, v73(Vector3.new(v74, v75, v71), v_u_28, 0), function()
					-- upvalues: (copy) v_u_48, (copy) v_u_56, (copy) v_u_36, (copy) v_u_30, (copy) v_u_70
					return v_u_48.cf * CFrame.new(v_u_56 * v_u_36() * 0.55 * v_u_30) * v_u_70
				end)
				if not v57 then
					break
				end
				p_u_24.add(p_u_25, p_u_24.ball(0.42 * v_u_30, v_u_28, 0), function()
					-- upvalues: (copy) v_u_48, (copy) v_u_56, (copy) v_u_58, (copy) v_u_30, (copy) v_u_36
					return v_u_48.cf * CFrame.new(v_u_56 * (v_u_58 + 0.1 * v_u_30 + v_u_36() * 0.55 * v_u_30))
				end)
			end
			local v_u_76 = false
			local v77 = p_u_25.ticks
			local function v81()
				-- upvalues: (copy) v_u_36, (ref) v_u_76, (copy) v_u_51
				local v78 = v_u_36()
				if v78 > 0.01 then
					v_u_76 = true
					for _, v79 in v_u_51 do
						v79.Transparency = 0.12 - 0.12 * v78
					end
				elseif v_u_76 then
					v_u_76 = false
					for _, v80 in v_u_51 do
						v80.Transparency = 0.12
					end
				end
			end
			table.insert(v77, v81)
			p_u_24.pin(p_u_25, v_u_48, p_u_24.picture(8.6 * v_u_30, v_u_5.Ring, v27, 0.35), CFrame.identity)
			v_u_31 = v_u_23(p_u_24, p_u_25, v_u_28, 5, 0.22)
			p_u_24.particles(p_u_25, "AuraMode", v27, {
				["rate"] = 0.45,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_24.particles(p_u_25, "Petals", v_u_28, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end