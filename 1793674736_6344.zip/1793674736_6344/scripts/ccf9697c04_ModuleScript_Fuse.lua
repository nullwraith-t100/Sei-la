local v1 = require(script.Parent.Daily)
local v2 = require(script.Parent.Pets)
local v_u_3 = {
	["UPDATE"] = 3,
	["COUNT"] = 4,
	["TIERS"] = {
		{
			["id"] = "void",
			["name"] = "VOID",
			["mult"] = 1.1
		},
		{
			["id"] = "rainbow",
			["name"] = "RAINBOW",
			["mult"] = 1.25
		},
		{
			["id"] = "corrupted",
			["name"] = "CORRUPTED",
			["mult"] = 1.5
		}
	}
}
v_u_3.MAX = #v_u_3.TIERS
v_u_3.NORMAL = "NORMAL"
v_u_3.FROM_WORLD = 1
v_u_3.LUCK = 0
v_u_3.AUTO_FUSE_PASS = nil
v_u_3.SKIP_KEYS = { "fuseVoid", "fuseRainbow", "fuseCorrupted" }
v_u_3.SKIP_SECONDS = 900
function v_u_3.tier(p4) -- name: tier
	-- upvalues: (copy) v_u_3
	if p4 then
		return v_u_3.TIERS[p4]
	else
		return nil
	end
end
function v_u_3.factor(p5) -- name: factor
	-- upvalues: (copy) v_u_3
	local v6 = v_u_3.tier(p5)
	return not v6 and 1 or v6.mult
end
function v_u_3.name(p7) -- name: name
	-- upvalues: (copy) v_u_3
	local v8 = v_u_3.tier(p7)
	if v8 then
		return v8.name
	else
		return v_u_3.NORMAL
	end
end
local v_u_9 = {}
for _, v10 in v2.eggs do
	if v10.prizeOnly then
		continue
	end
	for _, v11 in v10.pool do
		v_u_9[v11.pet] = true
	end
end
for _, v12 in v1.weeks do
	for _, v13 in v12 do
		if v13.kind ~= "pet" or not v13.pet then
			continue
		end
		v_u_9[v13.pet] = true
	end
end
for _, v14 in v2.list do
	if not v14.drop or v14.pass then
		continue
	end
	v_u_9[v14.id] = true
end
for v15 in v_u_9 do
	local v16 = v2.byId[v15]
	if v16 and not v16.pass then
		continue
	end
	v_u_9[v15] = nil
end
function v_u_3.fusable(p17) -- name: fusable
	-- upvalues: (copy) v_u_9
	return v_u_9[p17] == true
end
return v_u_3