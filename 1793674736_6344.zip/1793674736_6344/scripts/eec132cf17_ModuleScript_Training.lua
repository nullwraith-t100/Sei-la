return {
	{
		["id"] = "dummy",
		["name"] = "Training Dummy",
		["theme"] = "dummy",
		["rebirths"] = 0,
		["mult"] = 2,
		["color"] = "#7CFF4F"
	},
	{
		["id"] = "ring",
		["name"] = "Boxing Ring",
		["theme"] = "ring",
		["rebirths"] = 2,
		["mult"] = 3,
		["color"] = "#FFE14B"
	},
	{
		["id"] = "golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 8,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "falls",
		["name"] = "Waterfall",
		["theme"] = "waterfall",
		["rebirths"] = 6,
		["mult"] = 5,
		["color"] = "#4FD1FF"
	},
	{
		["id"] = "forge",
		["name"] = "Fire Forge",
		["theme"] = "forge",
		["rebirths"] = 12,
		["mult"] = 7,
		["color"] = "#FF8A2B"
	},
	{
		["id"] = "thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 25,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "temple",
		["name"] = "Sage Temple",
		["theme"] = "temple",
		["rebirths"] = 20,
		["mult"] = 10,
		["color"] = "#F2C94A"
	},
	{
		["id"] = "storm",
		["name"] = "Storm Tower",
		["theme"] = "storm",
		["rebirths"] = 28,
		["mult"] = 12,
		["color"] = "#7FD3FF"
	},
	{
		["id"] = "dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 50,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "gravity",
		["name"] = "Gravity Chamber",
		["theme"] = "gravity",
		["rebirths"] = 36,
		["mult"] = 20,
		["color"] = "#B57BFF"
	},
	{
		["id"] = "blood",
		["name"] = "Blood Moon Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 44,
		["mult"] = 35,
		["color"] = "#FF3D6E"
	},
	{
		["id"] = "six_paths",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 250,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "void",
		["name"] = "Void Altar",
		["theme"] = "void",
		["rebirths"] = 56,
		["mult"] = 40,
		["color"] = "#C77DFF"
	}
}