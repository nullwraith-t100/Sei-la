local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("MarketplaceService")
local v3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = require(script.Parent.Device)
local v_u_8 = require(script.Parent.Gamepad)
local v_u_9 = require(script.Parent.Sfx)
local v_u_10 = require(script.Parent.Store)
local v11 = v4.Shared
local v_u_12 = require(v11.Net)
local v_u_13 = require(v11.Config.Products)
local v_u_14 = {}
local v_u_15 = v3.LocalPlayer
local v_u_16 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_17 = Color3.new(1, 1, 1)
local v_u_18 = Color3.new(0, 0, 0)
local v_u_19 = Color3.fromRGB
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = {}
local v_u_28 = nil
local function v_u_29() end
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = false
local v_u_33 = false
local v_u_34 = false
local v_u_35 = {
	["revive"] = 0,
	["revenge"] = 0,
	["bossRevive"] = 0
}
local v_u_36 = {
	["revive"] = v_u_13.productByKey.revive.price,
	["revenge"] = v_u_13.productByKey.revenge.price,
	["bossRevive"] = v_u_13.productByKey.bossRevive.price
}
local v_u_37 = "stage"
local v_u_38 = {
	["buy"] = function() -- name: buy end,
	["no"] = function() -- name: no end
}
local v_u_39 = false
local v_u_40 = nil
local v_u_41 = false
local function v_u_42(_, _) end
function v_u_14.onNotify(p43) -- name: onNotify
	-- upvalues: (ref) v_u_42
	v_u_42 = p43
end
function v_u_14.open() -- name: open
	-- upvalues: (ref) v_u_33
	return v_u_33
end
local function v_u_53(p44, p45, p46, p47, p48, p49) -- name: text
	-- upvalues: (copy) v_u_16, (copy) v_u_17, (copy) v_u_18
	local v50 = Instance.new("TextLabel")
	v50.Name = p45
	v50.BackgroundTransparency = 1
	v50.AnchorPoint = Vector2.new(0.5, 0.5)
	v50.Size = p47
	v50.Position = p48
	v50.FontFace = v_u_16
	v50.TextScaled = true
	v50.TextColor3 = v_u_17
	v50.Text = p46
	v50.ZIndex = 4
	local v51 = v_u_18
	local v52 = Instance.new("UIStroke")
	v52.Thickness = p49
	v52.Color = v51
	v52.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v52.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
	v52.LineJoinMode = Enum.LineJoinMode.Round
	v52.Parent = v50
	v50.Parent = p44
	return v50
end
local function v_u_57() -- name: showPrices
	-- upvalues: (copy) v_u_27, (ref) v_u_37, (copy) v_u_35, (copy) v_u_10, (copy) v_u_36
	for v54, v55 in v_u_27 do
		local v56 = v_u_37 == "boss" and v54 == "revive" and "bossRevive" or v54
		v55.Text = (v_u_35[v56] or 0) > 0 and "FREE" or v_u_10.priceText(v_u_36[v56])
	end
end
local function v_u_62(p58, p_u_59) -- name: press
	-- upvalues: (copy) v_u_6, (copy) v_u_9
	p58.MouseEnter:Connect(function()
		-- upvalues: (copy) p_u_59, (ref) v_u_6, (ref) v_u_9
		v_u_6:Create(p_u_59, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1.04
		}):Play()
		v_u_9.play("Hover")
	end)
	p58.MouseLeave:Connect(function()
		-- upvalues: (copy) p_u_59, (ref) v_u_6
		v_u_6:Create(p_u_59, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end)
	p58.SelectionGained:Connect(function()
		-- upvalues: (copy) p_u_59, (ref) v_u_6
		v_u_6:Create(p_u_59, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1.04
		}):Play()
	end)
	p58.SelectionLost:Connect(function()
		-- upvalues: (copy) p_u_59, (ref) v_u_6
		v_u_6:Create(p_u_59, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end)
	p58.Activated:Connect(function()
		-- upvalues: (ref) v_u_9, (copy) p_u_59, (ref) v_u_6
		v_u_9.play("Click")
		v_u_6:Create(p_u_59, TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 0.9
		}):Play()
		task.delay(0.08, function()
			-- upvalues: (ref) p_u_59, (ref) v_u_6
			local v60 = p_u_59
			local v61 = Enum.EasingStyle.Back
			v_u_6:Create(v60, TweenInfo.new(0.2, v61 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end)
	end)
end
local function v_u_80(p63, p64, p65, p66, p67, p68, p69) -- name: button
	-- upvalues: (copy) v_u_17, (copy) v_u_18, (copy) v_u_53, (copy) v_u_35, (copy) v_u_10, (copy) v_u_36, (copy) v_u_27, (ref) v_u_22, (copy) v_u_62
	local v_u_70 = Instance.new("TextButton")
	v_u_70.Name = p63
	v_u_70.Text = ""
	v_u_70.AutoButtonColor = false
	v_u_70.BackgroundColor3 = v_u_17
	v_u_70.BorderSizePixel = 0
	v_u_70.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_70.Size = UDim2.fromScale(0.315, 0.32)
	v_u_70.Position = UDim2.fromScale(p67, 0.755)
	v_u_70.ZIndex = 2
	local v71 = Instance.new("UIGradient")
	v71.Color = ColorSequence.new(p65, p66)
	v71.Rotation = 90
	v71.Parent = v_u_70
	local v72 = Instance.new("UICorner")
	v72.CornerRadius = UDim.new(0.05, 0)
	v72.Parent = v_u_70
	local v73 = v_u_18
	local v74 = Instance.new("UIStroke")
	v74.Thickness = 0.055
	v74.Color = v73
	v74.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v74.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v74.LineJoinMode = Enum.LineJoinMode.Round
	v74.Parent = v_u_70
	local v75 = Instance.new("UIScale")
	v75.Parent = v_u_70
	local v_u_76 = Instance.new("ImageLabel")
	v_u_76.Name = "StudPattern"
	v_u_76.BackgroundTransparency = 1
	v_u_76.Image = "rbxassetid://97016358865650"
	v_u_76.ImageTransparency = 0.55
	v_u_76.ScaleType = Enum.ScaleType.Tile
	v_u_76.Size = UDim2.fromScale(1, 1)
	v_u_76.ZIndex = 3
	v_u_76.Parent = v_u_70
	v_u_70:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- name: tile
		-- upvalues: (copy) v_u_70, (copy) v_u_76
		local v77 = v_u_70.AbsoluteSize.X / 2.8
		if v77 >= 1 then
			v_u_76.TileSize = UDim2.fromOffset(v77, v77)
		end
	end)
	local v78 = v_u_70.AbsoluteSize.X / 2.8
	if v78 >= 1 then
		v_u_76.TileSize = UDim2.fromOffset(v78, v78)
	end
	v_u_53(v_u_70, "Word", p64, UDim2.fromScale(0.86, 0.44), UDim2.fromScale(0.5, 0.58), 0.1)
	if p68 then
		local v79 = v_u_53(v_u_70, "Price", (v_u_35[p68] or 0) > 0 and "FREE" or v_u_10.priceText(v_u_36[p68]), UDim2.fromScale(0.5, 0.25), UDim2.fromScale(0.955, 0.06), 0.11)
		v79.AnchorPoint = Vector2.new(1, 0)
		v79.TextXAlignment = Enum.TextXAlignment.Right
		v_u_27[p68] = v79
	end
	if p69 then
		v_u_53(v_u_22, p63 .. "Gives", p69, UDim2.fromScale(0.3, 0.075), UDim2.fromScale(p67, 0.965), 0.14)
	end
	v_u_62(v_u_70, v75)
	v_u_70.Parent = v_u_22
	return v_u_70
end
local function v_u_105() -- name: build
	-- upvalues: (copy) v_u_15, (ref) v_u_21, (ref) v_u_24, (copy) v_u_17, (ref) v_u_22, (copy) v_u_7, (ref) v_u_23, (copy) v_u_53, (copy) v_u_19, (ref) v_u_25, (copy) v_u_80, (ref) v_u_40, (ref) v_u_33, (ref) v_u_34, (ref) v_u_37, (ref) v_u_38, (ref) v_u_20, (ref) v_u_32, (ref) v_u_29, (copy) v_u_14, (ref) v_u_28, (copy) v_u_8, (copy) v_u_9, (ref) v_u_26, (copy) v_u_1
	local v81 = v_u_15:WaitForChild("PlayerGui")
	v_u_21 = Instance.new("ScreenGui")
	v_u_21.Name = "Revive"
	v_u_21.ResetOnSpawn = false
	v_u_21.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v_u_21.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
	v_u_21.DisplayOrder = 50
	v_u_21.Enabled = false
	v_u_24 = Instance.new("TextButton")
	v_u_24.Name = "Wash"
	v_u_24.Text = ""
	v_u_24.AutoButtonColor = false
	v_u_24.BorderSizePixel = 0
	v_u_24.BackgroundColor3 = v_u_17
	v_u_24.BackgroundTransparency = 1
	v_u_24.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_24.Position = UDim2.fromScale(0.5, 0.5)
	v_u_24.Size = UDim2.new(1, 600, 1, 600)
	v_u_24.Selectable = false
	v_u_24.Parent = v_u_21
	v_u_22 = Instance.new("Frame")
	v_u_22.Name = "Panel"
	v_u_22.BackgroundTransparency = 1
	v_u_22.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_22.Position = UDim2.fromScale(0.5, 0.5)
	local v82 = v_u_22
	local v83
	if v_u_7.touch() then
		v83 = UDim2.fromScale(0.94, 0.86)
	else
		v83 = UDim2.fromScale(0.64, 0.56)
	end
	v82.Size = v83
	local v84 = Instance.new("UIAspectRatioConstraint")
	v84.AspectRatio = 2.2
	v84.Parent = v_u_22
	v_u_23 = Instance.new("UIScale")
	v_u_23.Parent = v_u_22
	v_u_22.Parent = v_u_21
	local v85 = v_u_53(v_u_22, "Title", "REVIVE?", UDim2.fromScale(0.7, 0.31), UDim2.fromScale(0.5, 0.12), 0.085)
	local v86 = v_u_19(255, 170, 60)
	local v87 = v_u_19(240, 96, 18)
	local v88 = Instance.new("UIGradient")
	v88.Color = ColorSequence.new(v86, v87)
	v88.Rotation = 90
	v88.Parent = v85
	local v89 = v85:FindFirstChildOfClass("UIStroke")
	if v89 then
		v89.Color = v_u_19(52, 22, 10)
	end
	v_u_25 = v_u_53(v_u_22, "Clock", "5.00", UDim2.fromScale(0.36, 0.25), UDim2.fromScale(0.5, 0.425), 0.085)
	local v90 = v_u_25
	local v91 = v_u_19(255, 120, 70)
	local v92 = v_u_19(226, 34, 30)
	local v93 = Instance.new("UIGradient")
	v93.Color = ColorSequence.new(v91, v92)
	v93.Rotation = 90
	v93.Parent = v90
	local v94 = v_u_25:FindFirstChildOfClass("UIStroke")
	if v94 then
		v94.Color = v_u_19(52, 14, 10)
	end
	local v95 = v_u_80("Revive", "Revive!", v_u_19(160, 236, 52), v_u_19(68, 182, 30), 0.1575, "revive", "+ FULL HP")
	local v96 = v_u_80("Revenge", "Revenge!", v_u_19(255, 216, 64), v_u_19(244, 160, 16), 0.5, "revenge", "+ KILL ENEMIES")
	local v97 = v_u_80("No", "No", v_u_19(255, 84, 76), v_u_19(200, 22, 30), 0.8425, nil, nil)
	local v98 = v_u_53(v_u_22, "NoGives", "BACK TO LOBBY", UDim2.fromScale(0.3, 0.075), UDim2.fromScale(0.8425, 0.965), 0.14)
	v98.Visible = false
	local v99 = {
		["title"] = v85,
		["revive"] = v95
	}
	local v100 = v95:FindFirstChild("Word")
	if not (v100 and v100:IsA("TextLabel")) then
		v100 = nil
	end
	v99.reviveWord = v100
	local v101 = v_u_22:FindFirstChild("ReviveGives")
	if not (v101 and v101:IsA("TextLabel")) then
		v101 = nil
	end
	v99.reviveGives = v101
	v99.revenge = v96
	local v102 = v_u_22:FindFirstChild("RevengeGives")
	if not (v102 and v102:IsA("TextLabel")) then
		v102 = nil
	end
	v99.revengeGives = v102
	v99.no = v97
	v99.noGives = v98
	v_u_40 = v99
	local function v_u_104(p103) -- name: ask
		-- upvalues: (ref) v_u_33, (ref) v_u_34, (ref) v_u_37, (ref) v_u_38, (ref) v_u_20, (ref) v_u_32
		if v_u_33 and not v_u_34 then
			v_u_34 = true
			if v_u_37 == "boss" then
				v_u_38.buy()
			else
				v_u_20:FireServer("buy", p103)
			end
			task.delay(1.5, function()
				-- upvalues: (ref) v_u_34, (ref) v_u_32
				if v_u_34 and not v_u_32 then
					v_u_34 = false
				end
			end)
		end
	end
	v95.Activated:Connect(function()
		-- upvalues: (copy) v_u_104
		v_u_104("revive")
	end)
	v96.Activated:Connect(function()
		-- upvalues: (copy) v_u_104
		v_u_104("revenge")
	end)
	v_u_29 = function()
		-- upvalues: (ref) v_u_33, (ref) v_u_37, (ref) v_u_38, (ref) v_u_20, (ref) v_u_14
		if v_u_33 then
			if v_u_37 == "boss" then
				v_u_38.no()
			else
				v_u_20:FireServer("no")
			end
			v_u_14.hide()
		end
	end
	v97.Activated:Connect(v_u_29)
	v_u_28 = v95
	v_u_8.root(v_u_22)
	v_u_8.hint(v97, Enum.KeyCode.ButtonB, 34)
	v_u_8.onBack(function()
		-- upvalues: (ref) v_u_33, (ref) v_u_9, (ref) v_u_29
		if not v_u_33 then
			return false
		end
		v_u_9.play("Click")
		v_u_29()
		return true
	end, 60)
	v_u_8.onEnter(function()
		-- upvalues: (ref) v_u_33, (ref) v_u_8, (ref) v_u_28, (ref) v_u_22
		if not v_u_33 then
			return false
		end
		v_u_8.select(v_u_28)
		if not v_u_8.selected() then
			v_u_8.select(v_u_22)
		end
		return v_u_8.selected() ~= nil
	end, 60)
	v_u_21.Parent = v81
	v_u_26 = Instance.new("BlurEffect")
	v_u_26.Name = "ReviveBlur"
	v_u_26.Size = 0
	v_u_26.Parent = v_u_1
end
local function v_u_115() -- name: layout
	-- upvalues: (ref) v_u_40, (ref) v_u_37, (ref) v_u_39, (copy) v_u_35, (ref) v_u_28, (copy) v_u_57
	local v106 = v_u_40
	if v106 then
		local v107 = v_u_37 == "boss"
		local v108 = not v107 or (v_u_39 or (v_u_35.bossRevive or 0) > 0)
		v106.title.Text = v107 and "KNOCKED OUT!" or "REVIVE?"
		local v109 = v106.reviveWord
		local v110 = v106.reviveGives
		if v109 then
			v109.Text = v107 and "Revive Now!" or "Revive!"
		end
		local v111 = v107 and 0.3 or 0.1575
		local v112 = v107 and (v108 and 0.7 or 0.5) or 0.8425
		if v110 then
			v110.Text = v107 and "+ BACK IN THE FIGHT" or "+ FULL HP"
			v110.Visible = v108
			v110.Position = UDim2.fromScale(v111, v110.Position.Y.Scale)
		end
		v106.revive.Visible = v108
		v106.revive.Position = UDim2.fromScale(v111, v106.revive.Position.Y.Scale)
		v106.revenge.Visible = not v107
		local v113 = v106.revengeGives
		if v113 then
			v113.Visible = not v107
		end
		v106.no.Position = UDim2.fromScale(v112, v106.no.Position.Y.Scale)
		v106.noGives.Visible = v107
		v106.noGives.Position = UDim2.fromScale(v112, v106.noGives.Position.Y.Scale)
		local v114
		if v108 then
			v114 = v106.revive
		else
			v114 = v106.no
		end
		v_u_28 = v114
		v_u_57()
	end
end
local function v_u_125(p116) -- name: openScreen
	-- upvalues: (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_34, (copy) v_u_57, (ref) v_u_25, (ref) v_u_33, (copy) v_u_15, (ref) v_u_41, (ref) v_u_21, (ref) v_u_24, (copy) v_u_6, (ref) v_u_26, (ref) v_u_23, (copy) v_u_9, (copy) v_u_8, (ref) v_u_28
	local v117 = p116.left
	v_u_30 = type(v117) ~= "number" and 0 or v117
	v_u_31 = os.clock()
	v_u_32 = p116.paused == true
	if not v_u_32 then
		v_u_34 = false
	end
	v_u_57()
	v_u_34 = false
	local v118 = v_u_25
	local v119 = string.format
	local v120 = v_u_30 - (v_u_32 and 0 or os.clock() - v_u_31)
	v118.Text = v119("%.2f", (math.max(0, v120)))
	if not v_u_33 then
		v_u_33 = true
		local v121 = v_u_15:FindFirstChild("PlayerGui")
		if v121 then
			v121 = v121:FindFirstChild("Main")
		end
		if not (v121 and v121:IsA("ScreenGui")) then
			v121 = nil
		end
		local v122
		if v121 == nil then
			v122 = false
		else
			v122 = v121.Enabled
		end
		v_u_41 = v122
		if v121 then
			v121.Enabled = false
		end
		v_u_21.Enabled = true
		v_u_24.BackgroundTransparency = 1
		v_u_6:Create(v_u_24, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 0.55
		}):Play()
		v_u_6:Create(v_u_26, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = 14
		}):Play()
		v_u_23.Scale = 0.6
		local v123 = v_u_23
		local v124 = Enum.EasingStyle.Back
		v_u_6:Create(v123, TweenInfo.new(0.3, v124 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
		v_u_9.play("Open")
		v_u_8.capture("revive", true)
		v_u_8.selectSoon(function()
			-- upvalues: (ref) v_u_33, (ref) v_u_28
			if v_u_33 then
				return v_u_28
			else
				return nil
			end
		end)
	end
end
function v_u_14.show(p126) -- name: show
	-- upvalues: (ref) v_u_37, (copy) v_u_35, (copy) v_u_115, (copy) v_u_125
	v_u_37 = "stage"
	local v127 = p126.free
	if type(v127) == "table" then
		local v128 = v_u_35
		local v129 = v127.revive
		v128.revive = type(v129) ~= "number" and 0 or v127.revive
		local v130 = v_u_35
		local v131 = v127.revenge
		v130.revenge = type(v131) ~= "number" and 0 or v127.revenge
	end
	v_u_115()
	v_u_125(p126)
end
function v_u_14.showBoss(p132) -- name: showBoss
	-- upvalues: (ref) v_u_37, (copy) v_u_35, (ref) v_u_39, (copy) v_u_115, (copy) v_u_125
	v_u_37 = "boss"
	local v133 = v_u_35
	local v134 = p132.free
	v133.bossRevive = type(v134) ~= "number" and 0 or p132.free
	v_u_39 = p132.can == true
	v_u_115()
	v_u_125(p132)
end
function v_u_14.bossTime(p135) -- name: bossTime
	-- upvalues: (ref) v_u_33, (ref) v_u_37, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_34
	if v_u_33 and v_u_37 == "boss" then
		local v136 = p135.left
		v_u_30 = type(v136) ~= "number" and 0 or v136
		v_u_31 = os.clock()
		v_u_32 = p135.paused == true
		if not v_u_32 then
			v_u_34 = false
		end
	end
end
function v_u_14.onBoss(p137) -- name: onBoss
	-- upvalues: (ref) v_u_38
	v_u_38 = p137
end
function v_u_14.hide() -- name: hide
	-- upvalues: (ref) v_u_33, (ref) v_u_34, (copy) v_u_8, (ref) v_u_21, (ref) v_u_26, (copy) v_u_6, (copy) v_u_15, (ref) v_u_41
	if v_u_33 then
		v_u_33 = false
		v_u_34 = false
		v_u_8.capture("revive", false)
		local v138 = v_u_8.selected()
		if v138 and v138:IsDescendantOf(v_u_21) then
			v_u_8.clear()
		end
		v_u_21.Enabled = false
		v_u_6:Create(v_u_26, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = 0
		}):Play()
		local v139 = v_u_15:FindFirstChild("PlayerGui")
		if v139 then
			v139 = v139:FindFirstChild("Main")
		end
		if not (v139 and v139:IsA("ScreenGui")) then
			v139 = nil
		end
		if v139 and v_u_41 then
			v139.Enabled = true
		end
	end
end
local function v_u_145() -- name: fetchPrices
	-- upvalues: (copy) v_u_13, (copy) v_u_2, (copy) v_u_36, (copy) v_u_57
	for _, v140 in { "revive", "revenge", "bossRevive" } do
		local v_u_141 = v_u_13.productByKey[v140]
		if v_u_141.id == 0 then
			continue
		end
		local function v142()
			-- upvalues: (ref) v_u_2, (copy) v_u_141
			return v_u_2:GetProductInfo(v_u_141.id, Enum.InfoType.Product)
		end
		local v143, v144 = pcall(v142)
		if v143 then
			if type(v144) == "table" then
				v143 = v144.PriceInRobux
			else
				v143 = false
			end
		end
		if type(v143) ~= "number" or v143 <= 0 then
			continue
		end
		v_u_36[v140] = v143
	end
	v_u_57()
end
function v_u_14.start() -- name: start
	-- upvalues: (ref) v_u_20, (copy) v_u_12, (copy) v_u_105, (copy) v_u_145, (copy) v_u_14, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_34, (ref) v_u_33, (copy) v_u_9, (ref) v_u_42, (copy) v_u_19, (copy) v_u_5, (ref) v_u_25, (copy) v_u_15
	v_u_20 = v_u_12.event("Revive")
	v_u_105()
	task.spawn(v_u_145)
	v_u_20.OnClientEvent:Connect(function(p146, p147)
		-- upvalues: (ref) v_u_14, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_34, (ref) v_u_33, (ref) v_u_9, (ref) v_u_42, (ref) v_u_19
		if p146 == "show" and type(p147) == "table" then
			v_u_14.show(p147)
		elseif p146 == "time" and type(p147) == "table" then
			local v148 = p147.left
			v_u_30 = type(v148) ~= "number" and 0 or v148
			v_u_31 = os.clock()
			v_u_32 = p147.paused == true
			if not v_u_32 then
				v_u_34 = false
				return
			end
		elseif p146 == "hide" then
			local v149 = v_u_33
			v_u_14.hide()
			if p147 == "revive" or p147 == "revenge" then
				v_u_9.play("LevelUp")
				if not v149 then
					v_u_42("Revived!", v_u_19(40, 200, 60))
					return
				end
			end
		elseif p146 == "saved" then
			v_u_42(("%* saved: it is FREE the next time you fall"):format(p147 == "revenge" and "Revenge" or "Revive"), v_u_19(40, 200, 60))
		end
	end)
	v_u_5.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_33, (ref) v_u_25, (ref) v_u_30, (ref) v_u_32, (ref) v_u_31
		if v_u_33 then
			local v150 = v_u_25
			local v151 = string.format
			local v152 = v_u_30 - (v_u_32 and 0 or os.clock() - v_u_31)
			v150.Text = v151("%.2f", (math.max(0, v152)))
		end
	end)
	v_u_15.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_14
		v_u_14.hide()
	end)
end
return v_u_14