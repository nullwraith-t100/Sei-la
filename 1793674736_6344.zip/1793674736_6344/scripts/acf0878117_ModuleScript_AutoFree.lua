local v_u_1 = require(script.Parent.Parent.Config.Economy)
local v_u_10 = {
	["forever"] = function() -- name: forever
		-- upvalues: (copy) v_u_1
		return v_u_1.autoFreeFor == (1 / 0)
	end,
	["phase"] = function(p2) -- name: phase
		-- upvalues: (copy) v_u_1, (copy) v_u_10
		local v3 = v_u_1.autoFreeAfter
		local v4 = v_u_1.autoFreeFor
		local v5 = math.max(0, p2)
		if v_u_10.forever() then
			return v5 < v3 and {
				["ready"] = false,
				["left"] = nil,
				["cycle"] = 0,
				["left"] = v3 - v5
			} or {
				["ready"] = true,
				["left"] = (1 / 0),
				["cycle"] = 0
			}
		end
		local v6 = v3 + v4
		local v7 = v5 / v6
		local v8 = math.floor(v7)
		local v9 = v5 - v8 * v6
		return v9 < v3 and {
			["ready"] = false,
			["left"] = nil,
			["cycle"] = nil,
			["left"] = v3 - v9,
			["cycle"] = v8
		} or {
			["ready"] = true,
			["left"] = nil,
			["cycle"] = nil,
			["left"] = v6 - v9,
			["cycle"] = v8
		}
	end
}
return v_u_10