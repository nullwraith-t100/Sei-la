local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromRGB(10, 30, 120)
local v_u_8 = Color3.fromRGB(236, 230, 214)
local v_u_9 = Color3.fromRGB(16, 20, 40)
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Enum.Material.SmoothPlastic
local v_u_12 = CFrame.Angles(0, 1.5707963267948966, 0)
local function v_u_24(p13, p14, p15, p16, p17, p18) -- name: ring
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1
	local v19 = Instance.new("Attachment")
	local v20 = p14.Unit
	local v21 = v20.Y
	local v22
	if math.abs(v21) > 0.98 then
		v22 = CFrame.new(p13)
	else
		v22 = CFrame.fromMatrix(p13, v20:Cross(Vector3.new(0, 1, 0)).Unit, v20)
	end
	v19.WorldCFrame = v22
	v19.Parent = v_u_3.Terrain
	local v23 = Instance.new("ParticleEmitter")
	v23.Enabled = false
	v23.Texture = v_u_6.HollowRing
	v23.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v23.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v23.Color = ColorSequence.new(p15)
	v23.LightEmission = 0.25
	v23.LightInfluence = 0
	v23.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v23.EmissionDirection = Enum.NormalId.Top
	v23.SpreadAngle = Vector2.zero
	v23.Speed = NumberRange.new(0.01)
	v23.Size = NumberSequence.new(p16 / 2, p17 / 2)
	v23.Transparency = NumberSequence.new(0, 0.3)
	v23.Lifetime = NumberRange.new(p18)
	v23.Parent = v19
	v23:Emit(1)
	v_u_1:AddItem(v19, p18 + 0.2)
end
return function(p_u_25)
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_5, (copy) v_u_24, (copy) v_u_7
	return {
		["w7_gran_rey_cero"] = function(p_u_26, p27)
			-- upvalues: (ref) v_u_4, (copy) p_u_25, (ref) v_u_2, (ref) v_u_8, (ref) v_u_11, (ref) v_u_12, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10, (ref) v_u_5, (ref) v_u_24, (ref) v_u_7
			local v_u_28 = v_u_4.color(p27.color)
			local v29 = p_u_26.headY / 1.5
			local v_u_30 = math.clamp(v29, 0.7, 3)
			local v_u_31 = v_u_30 * 2.3
			local v_u_41 = p_u_25.group(p_u_26, function(p32, p33)
				-- upvalues: (copy) v_u_30, (copy) p_u_26
				local v34 = CFrame.new
				local v35 = v_u_30 * 1.35
				local v36 = p_u_26.headY + v_u_30 * 0.9
				local v37 = p33 * 1.5
				local v38 = p32 * v34(v35, v36 + math.sin(v37) * 0.12 * v_u_30, v_u_30 * 0.6)
				local v39 = CFrame.Angles
				local v40 = p33 * 0.8
				return v38 * v39(math.sin(v40) * 0.04 + -0.10471975511965978, -0.20943951023931956, -0.10471975511965978)
			end)
			local v42 = v_u_2:FindFirstChild("EyePieces")
			if v42 then
				v42 = v42:FindFirstChild("w7_gran_rey_cero")
			end
			local v_u_43 = nil
			if v42 and v42:IsA("MeshPart") then
				local v44 = v42:Clone()
				local v45 = v42.Size
				local v46 = v42.Size.Y
				v44.Size = v45 * (v_u_31 / math.max(v46, 0.01))
				v_u_43 = v44:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_43 then
					v44.Color = v_u_8
					v44.Material = v_u_11
				end
				v44.Anchored = true
				v44.CanCollide = false
				v44.CanQuery = false
				v44.CanTouch = false
				v44.CastShadow = false
				v44.Massless = true
				v44.Parent = v_u_4.folder()
				p_u_25.pin(p_u_26, v_u_41, v44, v_u_12)
			else
				local v47 = p_u_25.pin
				local v48 = p_u_25.bar
				local v49 = v_u_31 * 1.1
				local v50 = v_u_31 * 0.6
				local v51 = v_u_31 * 0.8
				v47(p_u_26, v_u_41, v48(Vector3.new(v49, v50, v51), v_u_8, 0, v_u_11), CFrame.new(0, v_u_31 * 0.15, v_u_31 * 0.1))
				local v52 = p_u_25.pin
				local v53 = p_u_25.bar
				local v54 = v_u_31 * 0.7
				local v55 = v_u_31 * 0.3
				local v56 = v_u_31 * 0.5
				v52(p_u_26, v_u_41, v53(Vector3.new(v54, v55, v56), v_u_8, 0, v_u_11), CFrame.new(0, v_u_31 * 0.05, v_u_31 * -0.45))
				for _, v57 in { -1, 1 } do
					local v58 = p_u_25.pin
					local v59 = p_u_25.bar
					local v60 = v_u_31 * 0.22
					local v61 = v_u_31 * 0.16
					local v62 = v_u_31 * 0.05
					v58(p_u_26, v_u_41, v59(Vector3.new(v60, v61, v62), v_u_9, 0, v_u_11), CFrame.new(v57 * 0.25 * v_u_31, v_u_31 * 0.22, v_u_31 * -0.31))
				end
			end
			local v63 = p_u_25.bar(Vector3.new(0.2, 0.2, 0.2), v_u_28, 1)
			v63.Massless = true
			p_u_25.add(p_u_26, v63, function()
				-- upvalues: (copy) v_u_41, (copy) v_u_31
				return v_u_41.cf * CFrame.new(Vector3.new(0, -0.2, -0.38) * v_u_31)
			end)
			local v_u_64 = Instance.new("ParticleEmitter")
			v_u_64.Texture = v_u_6.CeroOrb
			v_u_64.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_64.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v_u_64.Color = ColorSequence.new(v_u_28)
			v_u_64.LightEmission = 0.15
			v_u_64.LightInfluence = 0
			v_u_64.LockedToPart = true
			v_u_64.Speed = NumberRange.new(0)
			v_u_64.Lifetime = NumberRange.new(0.12)
			v_u_64.Size = NumberSequence.new(v_u_30 * 0.4)
			v_u_64.Rate = 25
			v_u_64.Parent = v63
			local v_u_65 = Instance.new("ParticleEmitter")
			v_u_65.Texture = v_u_6.Glow
			v_u_65.Color = ColorSequence.new(v_u_28)
			v_u_65.LightEmission = 0.5
			v_u_65.LightInfluence = 0
			v_u_65.LockedToPart = true
			v_u_65.Speed = NumberRange.new(0)
			v_u_65.Lifetime = NumberRange.new(0.12)
			v_u_65.Size = NumberSequence.new(v_u_30 * 0.8)
			v_u_65.Transparency = NumberSequence.new(0.2)
			v_u_65.Rate = 25
			v_u_65.Parent = v63
			local v66 = Instance.new("ParticleEmitter")
			v66.Texture = v_u_6.FxTwinkle
			v66.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v66.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v66.Color = ColorSequence.new(v_u_10, v_u_28)
			v66.LightEmission = 0.5
			v66.LightInfluence = 0
			v66.Size = NumberSequence.new(v_u_30 * 0.3 * p_u_26.fx, 0.05)
			v66.Lifetime = NumberRange.new(0.35)
			v66.Speed = NumberRange.new(v_u_30 * -5)
			v66.SpreadAngle = Vector2.new(180, 180)
			v66.Shape = Enum.ParticleEmitterShape.Sphere
			v66.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v66.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
			v66:SetAttribute("BaseRate", 8)
			v66.Rate = 8 * v_u_5.formRate()
			v66.Parent = v63
			p_u_25.own(p_u_26, v66)
			local v67 = Instance.new("Attachment")
			local v68 = v_u_30 * -5
			v67.Position = Vector3.new(0, 0, v68)
			v67.Parent = v63
			local v69 = Instance.new("Attachment")
			v69.Parent = v63
			local v_u_70 = Instance.new("Beam")
			v_u_70.Attachment0 = v69
			v_u_70.Attachment1 = v67
			v_u_70.Texture = v_u_6.Beam
			v_u_70.TextureMode = Enum.TextureMode.Stretch
			v_u_70.Color = ColorSequence.new(v_u_10, v_u_28)
			v_u_70.LightEmission = 0.8
			v_u_70.LightInfluence = 0
			v_u_70.Transparency = NumberSequence.new(0.1, 1)
			v_u_70.FaceCamera = true
			v_u_70.Segments = 1
			v_u_70.Width0 = 0
			v_u_70.Width1 = 0
			v_u_70.Parent = v63
			local v_u_72 = p_u_25.throb(p_u_26, 5, 1.6, 2.2, function(p71)
				-- upvalues: (copy) v_u_41, (copy) v_u_31, (ref) v_u_24, (copy) v_u_30, (ref) v_u_7, (copy) p_u_26, (ref) p_u_25, (copy) v_u_28
				v_u_24((v_u_41.cf * CFrame.new(Vector3.new(0, -0.2, -0.38) * v_u_31)).Position + v_u_41.cf.LookVector * 0.6 * v_u_30, v_u_41.cf.LookVector, v_u_7, v_u_30 * 0.6, v_u_30 * 4 * p_u_26.fx, 0.35)
				v_u_24(p_u_25.feetAt(p_u_26, p71, 0.12), Vector3.new(0, 1, 0), v_u_28, v_u_30 * 2, v_u_30 * 8 * p_u_26.fx, 0.5)
			end)
			local v_u_73 = -1
			local v74 = p_u_26.ticks
			local function v82(_, p75)
				-- upvalues: (copy) v_u_72, (copy) v_u_30, (copy) p_u_26, (ref) v_u_73, (copy) v_u_64, (copy) v_u_65, (copy) v_u_70
				local v76 = v_u_72()
				local v77 = p75 * 5
				local v78 = (math.sin(v77) * 0.12 + 0.55 + v76 * 0.6) * v_u_30 * p_u_26.fx
				local v79 = v78 * 20
				local v80 = math.floor(v79)
				if v80 ~= v_u_73 then
					v_u_73 = v80
					v_u_64.Size = NumberSequence.new(v78)
					v_u_65.Size = NumberSequence.new(v78 * 2)
				end
				local v81 = v76 * v76 * 1.4 * v_u_30
				v_u_70.Width0 = v81
				v_u_70.Width1 = v81 * 0.3
			end
			table.insert(v74, v82)
			if v_u_43 then
				local v_u_83 = v_u_43.EmissiveStrength
				local v_u_84 = -1
				local v85 = p_u_26.ticks
				local function v88()
					-- upvalues: (copy) v_u_72, (ref) v_u_84, (copy) v_u_43, (copy) v_u_83
					local v86 = v_u_72() * 10
					local v87 = math.floor(v86) / 10
					if v87 ~= v_u_84 then
						v_u_84 = v87
						v_u_43.EmissiveStrength = v_u_83 * (v87 * 1.8 + 1)
					end
				end
				table.insert(v85, v88)
			end
			p_u_25.particles(p_u_26, "AuraMode", v_u_28, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end