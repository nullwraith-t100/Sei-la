local v_u_1 = game:GetService("SoundService")
local v_u_2 = game:GetService("Workspace")
local v3 = {}
local v_u_4 = {
	["LevelUp"] = true,
	["QuestDone"] = true,
	["RewardLand"] = true,
	["DailyClaim"] = true,
	["Reveal"] = true,
	["RevealBig"] = true,
	["WaveClear"] = true,
	["Coin"] = true,
	["PadClaim"] = true
}
local v_u_5 = {}
local v_u_6 = {}
local v_u_7 = nil
local v_u_8 = nil
function v3.play(p_u_9, p10) -- name: play
	-- upvalues: (ref) v_u_7, (copy) v_u_1, (copy) v_u_5, (copy) v_u_6, (copy) v_u_4, (ref) v_u_8, (copy) v_u_2
	local v11
	if v_u_7 and v_u_7.Parent then
		v11 = v_u_7
	else
		v_u_7 = v_u_1:FindFirstChild("Sfx")
		v11 = v_u_7
	end
	if v11 then
		v11 = v11:FindFirstChild(p_u_9)
	end
	if not (v11 and v11:IsA("Sound")) then
		return nil
	end
	local v12 = os.clock()
	if v12 - (v_u_5[p_u_9] or 0) < 0.035 or (v_u_6[p_u_9] or 0) >= 5 then
		return nil
	end
	v_u_5[p_u_9] = v12
	local v_u_13 = v11:Clone()
	local v14 = p10 or {}
	local v15 = v14.vary or (v_u_4[p_u_9] and 0 or 0.06)
	v_u_13.PlaybackSpeed = v11.PlaybackSpeed * (v14.pitch or 1) * (1 + (math.random() * 2 - 1) * v15)
	v_u_13.Volume = v11.Volume * (v14.volume or 1)
	v_u_13.Looped = false
	local v_u_16
	if v_u_8 and v_u_8.Parent then
		v_u_16 = v_u_8
	else
		v_u_16 = Instance.new("Folder")
		v_u_16.Name = "Playing"
		v_u_16.Parent = v_u_1
		v_u_8 = v_u_16
	end
	if v14.at then
		v_u_16 = Instance.new("Attachment")
		v_u_16.WorldPosition = v14.at
		v_u_16.Parent = v_u_2.Terrain
		v_u_13.RollOffMinDistance = 30
		v_u_13.RollOffMaxDistance = 260
	end
	v_u_13.Parent = v_u_16
	v_u_6[p_u_9] = (v_u_6[p_u_9] or 0) + 1
	v_u_13:Play()
	local v17 = v_u_13.TimeLength <= 0 and 4 or v_u_13.TimeLength / v_u_13.PlaybackSpeed
	task.delay(math.min(v17, 1.2), function()
		-- upvalues: (ref) v_u_6, (copy) p_u_9
		local v18 = v_u_6
		local v19 = p_u_9
		local v20 = (v_u_6[p_u_9] or 1) - 1
		v18[v19] = math.max(0, v20)
	end)
	local v21 = task.delay
	local v22 = v17 + 0.2
	v21(math.min(v22, 10), function()
		-- upvalues: (ref) v_u_16, (ref) v_u_8, (copy) v_u_13
		if v_u_16 == v_u_8 then
			v_u_13:Destroy()
		else
			v_u_16:Destroy()
		end
	end)
	return v_u_13
end
function v3.loop(p23, p24, p25) -- name: loop
	-- upvalues: (ref) v_u_7, (copy) v_u_1
	local v26
	if v_u_7 and v_u_7.Parent then
		v26 = v_u_7
	else
		v_u_7 = v_u_1:FindFirstChild("Sfx")
		v26 = v_u_7
	end
	if v26 then
		v26 = v26:FindFirstChild(p23)
	end
	if not (v26 and v26:IsA("Sound")) then
		return function() end
	end
	local v_u_27 = v26:Clone()
	v_u_27.Looped = true
	v_u_27.Volume = v26.Volume * (p25 or 1)
	v_u_27.Parent = p24
	v_u_27:Play()
	return function()
		-- upvalues: (copy) v_u_27
		v_u_27:Destroy()
	end
end
return v3