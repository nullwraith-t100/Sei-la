local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v1.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(6, 8, 22)
local v_u_7 = Color3.fromRGB(70, 125, 255)
local v_u_8 = Color3.fromRGB(196, 222, 255)
local v_u_9 = Color3.new(1, 1, 1)
return function(p_u_10)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_8, (copy) v_u_2, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_4
	return {
		["w4_abyss_spindle"] = function(p_u_11, p12)
			-- upvalues: (ref) v_u_3, (copy) p_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_2, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4
			local v_u_13 = v_u_3.color(p12.color)
			local v14 = v_u_3.color(p12.color2)
			local v15 = p_u_11.headY / 1.5
			local v_u_16 = math.clamp(v15, 0.7, 3)
			local v_u_17 = 0
			local v_u_18 = 0
			local v_u_28 = p_u_10.throb(p_u_11, 3.6, 1.4, 1.7, function(p19)
				-- upvalues: (ref) v_u_3, (ref) p_u_10, (copy) p_u_11, (copy) v_u_13, (ref) v_u_5, (copy) v_u_16, (ref) v_u_8, (ref) v_u_2
				v_u_3.ring(p_u_10.feetAt(p_u_11, p19, 0.15), v_u_13, 5 * p_u_11.fx, 0.55, v_u_5.Ring)
				local v20 = p19 * CFrame.new(0, v_u_16 * 0.9, v_u_16 * 1.6) * CFrame.Angles(1.5707963267948966, 0, 0)
				local v21, v22 = p_u_10.picture(1, v_u_5.Ring, v_u_8, 0.05)
				v21.CFrame = v20
				local v23 = v_u_3.tween
				local v24 = {}
				local v25 = v_u_16 * 11
				local v26 = v_u_16 * 11
				v24.Size = Vector3.new(v25, 0.05, v26)
				v23(v21, 0.5, v24)
				for _, v27 in v22 do
					v_u_3.tween(v27, 0.5, {
						["Transparency"] = 1
					})
				end
				v_u_2:AddItem(v21, 0.55)
			end)
			local v29 = p_u_11.ticks
			local function v32(_, _, p30)
				-- upvalues: (copy) v_u_28, (ref) v_u_18, (ref) v_u_17
				local v31 = v_u_28()
				v_u_18 = v31
				v_u_17 = v_u_17 + p30 * (0.9 + v31 * 9)
			end
			table.insert(v29, v32)
			local v_u_38 = p_u_10.group(p_u_11, function(p33, p34)
				-- upvalues: (copy) v_u_16
				local v35 = CFrame.new
				local v36 = v_u_16 * 0.9
				local v37 = p34 * 1.3
				return p33 * v35(0, v36 + math.sin(v37) * 0.12 * v_u_16, v_u_16 * 1.55)
			end)
			local function v39() -- name: turning
				-- upvalues: (copy) v_u_38, (ref) v_u_17
				return v_u_38.cf * CFrame.Angles(0, v_u_17, 0)
			end
			local v40 = p_u_10.dark(p_u_10.blob(Vector3.new(1.15, 6.6, 0.34) * v_u_16, v_u_6, 0, Enum.Material.SmoothPlastic))
			p_u_10.add(p_u_11, v40, v39)
			local v41 = p_u_10.blob(Vector3.new(1.6, 7.2, 0.5) * v_u_16, v_u_13, 0.62)
			p_u_10.add(p_u_11, v41, v39)
			local v_u_42 = p_u_10.blob(Vector3.new(0.13, 5.7, 0.36) * v_u_16, v_u_7, 0)
			p_u_10.add(p_u_11, v_u_42, v39)
			local v_u_43 = -1
			local v44 = p_u_11.ticks
			local function v45()
				-- upvalues: (ref) v_u_18, (ref) v_u_43, (copy) v_u_42, (ref) v_u_7, (ref) v_u_9
				if v_u_18 ~= v_u_43 then
					v_u_43 = v_u_18
					v_u_42.Color = v_u_7:Lerp(v_u_9, v_u_18)
				end
			end
			table.insert(v44, v45)
			p_u_10.fadeFromBehind(p_u_11, v40, 0.5)
			p_u_10.fadeFromBehind(p_u_11, v41, 0.5)
			p_u_10.pin(p_u_11, v_u_38, p_u_10.dark(p_u_10.ball(v_u_16 * 1.05, v_u_6, 0, Enum.Material.SmoothPlastic)), CFrame.identity)
			local v46 = p_u_10.picture(v_u_16 * 2.5, v_u_5.Ring, v_u_7, 0.1)
			p_u_10.add(p_u_11, v46, function(_, p47)
				-- upvalues: (copy) v_u_38
				return v_u_38.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, -p47 * 0.7, 0)
			end)
			local v_u_48 = v_u_17
			for v_u_49 = 0, 1 do
				local v_u_50, v_u_51 = p_u_10.picture(2, v_u_5.Ring, v_u_13, 0.3)
				v_u_50.Transparency = 1
				p_u_10.add(p_u_11, v_u_50, function()
					-- upvalues: (copy) v_u_38
					return v_u_38.cf * CFrame.Angles(1.5707963267948966, 0, 0)
				end)
				local v52 = p_u_11.ticks
				table.insert(v52, function(_, p53)
					-- upvalues: (copy) v_u_49, (copy) v_u_16, (copy) v_u_50, (copy) v_u_51
					local v54 = (p53 / 2.6 + v_u_49 / 2) % 1
					local v55 = (2.2 + v54 * 6.5) * v_u_16
					v_u_50.Size = Vector3.new(v55, 0.05, v55)
					for _, v56 in v_u_51 do
						v56.Transparency = 0.25 + 0.75 * v54
					end
				end)
			end
			for v57 = 1, 3 do
				local v58 = (v57 - 1) / 3 * 3.141592653589793
				local v59 = math.cos(v58)
				local v60 = math.sin(v58)
				local v_u_61 = Vector3.new(v59, 0, v60)
				local v_u_62 = (v57 - 1) / 3 * 3.141592653589793 * 2
				local function v_u_68(p63) -- name: at
					-- upvalues: (ref) v_u_48, (copy) v_u_62, (copy) v_u_16, (copy) v_u_61, (copy) v_u_38
					local v64 = v_u_48 * 1.6 + v_u_62 - p63
					local v65 = v_u_16 * 1.75
					local v66 = v_u_61 * math.cos(v64) * v65 + Vector3.new(0, 1, 0) * math.sin(v64) * v65 * 1.55
					local v67 = -v_u_61 * math.sin(v64) + Vector3.new(0, 1, 0) * math.cos(v64) * 1.55
					return v_u_38.cf * CFrame.lookAt(v66, v66 + v67)
				end
				local function v69() -- name: headAt
					-- upvalues: (copy) v_u_68
					return v_u_68(0)
				end
				local v70 = p_u_10.dark(p_u_10.ball(v_u_16 * 0.55, v14:Lerp(v_u_6, 0.6), 0, Enum.Material.SmoothPlastic))
				p_u_10.add(p_u_11, v70, v69)
				p_u_10.add(p_u_11, p_u_10.ball(v_u_16 * 0.85, v_u_7, 0.55), p_u_10.behind(v69, v_u_16 * 0.25))
				p_u_10.add(p_u_11, p_u_10.blob(Vector3.new(0.28, 0.28, 0.75) * v_u_16, v_u_6, 0), function()
					-- upvalues: (copy) v_u_68, (copy) v_u_16
					return v_u_68(0.32) * CFrame.new(0, 0, v_u_16 * 0.1)
				end)
				p_u_10.tail(v70, v_u_7, v14, v_u_16 * 0.22, 0.5)
			end
			local v71 = Instance.new("ParticleEmitter")
			v71.Texture = v_u_5.TideBubble
			v71.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v71.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v71.Color = ColorSequence.new(v_u_8)
			v71.LightEmission = 0.3
			v71.LightInfluence = 0
			v71.Lifetime = NumberRange.new(1.1, 1.6)
			v71.Speed = NumberRange.new(1.5 * p_u_11.fx, 3 * p_u_11.fx)
			local v72 = 1.5 * p_u_11.fx
			v71.Acceleration = Vector3.new(0, v72, 0)
			v71.SpreadAngle = Vector2.new(25, 25)
			v71.EmissionDirection = Enum.NormalId.Top
			v71.Size = NumberSequence.new(0.22 * p_u_11.fx, 0.45 * p_u_11.fx)
			v71.Transparency = NumberSequence.new(0.15, 0.6)
			v71:SetAttribute("BaseRate", 5)
			v71.Rate = 5 * v_u_4.formRate()
			v71.Parent = v41
			p_u_10.own(p_u_11, v41)
			p_u_10.particles(p_u_11, "AuraMode", v_u_13, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
		end
	}
end