local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.EpicKit8)
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.NeedleBurst,
	v_u_7.NeedleSplash,
	v_u_7.PorcelainPlate,
	v_u_7.Glow
})
local v_u_8 = Color3.fromHex("3DE0FF")
local v_u_9 = v_u_3.PORCELAIN
local v_u_10 = v_u_3.COBALT
local v_u_11 = Color3.fromRGB(8, 40, 70)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.Material.Neon
local function v_u_21(p14, p15, p16) -- name: vase
	-- upvalues: (copy) v_u_3
	local v17 = v_u_3.piece("w8_thousand_needles", p14, p16)
	if v17 then
		return {
			["parts"] = { v17 },
			["offs"] = { CFrame.new(0, p14 * 0.5, 0) * v_u_3.longY(v17) }
		}
	end
	local v18 = v_u_3.VASE
	local v19, v20 = v_u_3.build(v18, p14, p15, p16)
	return {
		["parts"] = v19,
		["offs"] = v20
	}
end
local function v_u_25(p22, p23, p24) -- name: sunburst
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8
	v_u_3.flat(p22, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.5,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["spin"] = 70,
		["image"] = v_u_7.NeedleBurst,
		["color"] = v_u_8,
		["life"] = p24,
		["sizes"] = {
			{ 0, p23 * 0.3 },
			{ 0.25, p23 },
			{ 1, p23 * 1.1 }
		},
		["alphas"] = {
			{ 0, 0.2 },
			{ 0.25, 0 },
			{ 0.6, 0.2 },
			{ 1, 1 }
		}
	})
end
local function v_u_29(p26, p27, p28) -- name: splash
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8, (copy) v_u_12
	v_u_3.puff(p26, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.35,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["flip"] = "4x4",
		["image"] = v_u_7.NeedleSplash,
		["color"] = v_u_8,
		["color2"] = v_u_12,
		["count"] = p27,
		["life"] = { 0.45, 0.6 },
		["sizes"] = {
			{ 0, p28 * 0.6 },
			{ 1, p28 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 0.8, 0.1 },
			{ 1, 1 }
		},
		["speed"] = { 3, 7 },
		["spread"] = Vector2.new(45, 45)
	})
end
local function v_u_34(p30, p31, p32, p33) -- name: plate
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_12
	v_u_3.flat(p30, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.05,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["spin"] = 8,
		["image"] = v_u_7.PorcelainPlate,
		["color"] = v_u_12,
		["life"] = p32,
		["sizes"] = {
			{ 0, p31 * 0.3 },
			{ 0.1, p31 },
			{ 1, p31 * 1.04 }
		},
		["alphas"] = {
			{ 0, 1 },
			{ 0.1, p33 },
			{ 0.85, p33 },
			{ 1, 1 }
		}
	})
end
return function(p_u_35)
	-- upvalues: (copy) v_u_3, (copy) v_u_12, (copy) v_u_8, (copy) v_u_13, (copy) v_u_4, (copy) v_u_9, (copy) v_u_10, (copy) v_u_25, (copy) v_u_29, (copy) v_u_21, (copy) v_u_1, (copy) v_u_11, (copy) v_u_7, (copy) v_u_34, (copy) v_u_6
	local v36 = {}
	local function v_u_58(p37, p38, p_u_39, p40) -- name: needleSpray
		-- upvalues: (ref) v_u_3, (ref) v_u_12, (ref) v_u_8, (ref) v_u_13, (copy) p_u_35, (ref) v_u_4
		local v41 = p37.X
		local v42 = p37.Y
		local v43 = p37.Z
		local v_u_44 = Vector3.new(v41, v42, v43)
		local v45 = math.random() * 3.141592653589793 * 2
		for v46 = 1, p38 do
			local v47 = v45 + v46 * 3.141592653589793 * 2 / p38 + (math.random() - 0.5) * 0.4
			local v48 = math.cos(v47)
			local v49 = math.sin(v47)
			local v_u_50 = Vector3.new(v48, 0, v49)
			local v_u_51 = p40 * (0.45 + math.random() * 0.55)
			local v52 = v_u_3.part
			local v53
			if v46 % 3 == 0 then
				v53 = v_u_12
			else
				v53 = v_u_8
			end
			local v_u_54 = v52(v53, v_u_13, 1.2)
			v_u_54.Size = Vector3.new(0.14, 0.14, p_u_39)
			local v_u_55 = (v_u_50 * 0.8 + Vector3.new(0, 1, 0) * (0.7 + math.random() * 0.5)).Unit
			p_u_35.animate(0.08, 0, function(p56)
				-- upvalues: (copy) v_u_44, (copy) v_u_50, (copy) v_u_51, (copy) v_u_54, (copy) v_u_55, (copy) p_u_39
				local v57 = v_u_44 + v_u_50 * v_u_51 * p56
				v_u_54.CFrame = CFrame.lookAt(v57 + v_u_55 * p_u_39 * 0.35, v57 + v_u_55 * p_u_39)
			end)
			task.delay(0.45, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_54
				v_u_4.tween(v_u_54, 0.35, {
					["Transparency"] = 1
				})
			end)
		end
	end
	local function v_u_62(p59, p60) -- name: needleCast
		-- upvalues: (copy) p_u_35, (ref) v_u_8, (ref) v_u_12, (ref) v_u_25, (ref) v_u_29, (ref) v_u_4
		local v61 = p59.size
		p_u_35.burst("Flash", p59.eye, v_u_8, (p60 and 0.3 or 0.2) * v61)
		p_u_35.glint(p59.eye + p59.dir * 0.8, v_u_12, (p60 and 4 or 3) * v61, 0.16)
		v_u_25(p_u_35.ground(p59.feet, 0.12), (p60 and 9 or 6) * v61, 0.5)
		if not p59.lite then
			v_u_29(p59.eye + p59.dir, p60 and 3 or 2, 3 * v61)
		end
		if p59.mine then
			v_u_4.shake(p60 and 0.12 or 0.06, 0.14)
		end
	end
	local function v_u_75(p63) -- name: popVase
		-- upvalues: (ref) v_u_21, (copy) p_u_35, (ref) v_u_3
		local v64 = p63.size
		local v_u_65 = 1.8 * v64
		local v_u_66 = v_u_21(v_u_65, true, 0.5)
		local v_u_67 = p_u_35.ground(p63.feet, 0) + v_u_3.side(p63.dir) * 1.8 * v64 + p63.dir * 0.6 * v64
		p_u_35.animate(0.4, 0, function(p68)
			-- upvalues: (ref) v_u_3, (copy) v_u_66, (copy) v_u_67, (copy) v_u_65
			local v69
			if p68 < 0.3 then
				v69 = v_u_3.outBack(p68 / 0.3)
			else
				v69 = 1 - v_u_3.smooth((p68 - 0.55) / 0.45)
			end
			local v70 = v_u_66
			local v71 = CFrame.new(v_u_67 + Vector3.new(0, 1, 0) * (v69 - 1) * v_u_65) * CFrame.Angles(0.25, 0, -0.35)
			for v72, v73 in v70.parts do
				v73.CFrame = v71 * v70.offs[v72]
			end
			if p68 >= 1 then
				for _, v74 in v_u_66.parts do
					v74:Destroy()
				end
			end
		end)
	end
	v36.thousand_needles_a = {
		["cast"] = function(p76) -- name: cast
			-- upvalues: (copy) p_u_35, (ref) v_u_8, (copy) v_u_75
			local v77 = p76.size
			p_u_35.glint(p76.eye + p76.dir * 1.2, v_u_8, 2.4 * v77, 0.1)
			if not p76.lite then
				v_u_75(p76)
			end
		end,
		["shot"] = function(p78, p79) -- name: fishShot
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (copy) p_u_35, (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			local v80 = p78.size
			local v81 = v_u_3.FISH
			local v82 = 2.4 * v80
			local v83 = p78.lite
			local v84, v85 = v_u_3.build(v81, v82, v83, 3)
			local v_u_86 = {
				["parts"] = v84,
				["offs"] = v85
			}
			local v_u_87 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p79, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_87, 3)
			p_u_35.streak(v_u_87, v_u_8, v_u_11, 0.5 * v80, 0.14)
			if not p78.lite then
				local v88 = Instance.new("ParticleEmitter")
				v88.Texture = v_u_7.Glow
				v88.Color = ColorSequence.new(v_u_12, v_u_8)
				v88.LightEmission = 1
				v88.LightInfluence = 0
				v88.Orientation = Enum.ParticleOrientation.VelocityParallel
				v88.Squash = NumberSequence.new(2)
				v88.Lifetime = NumberRange.new(0.15, 0.25)
				v88.Size = NumberSequence.new(0.35 * v80)
				v88.Speed = NumberRange.new(3, 7)
				v88.SpreadAngle = Vector2.new(180, 180)
				v88.Rate = 35
				v88.Parent = v_u_87
			end
			if p78.mine then
				p_u_35.light(v_u_87, v_u_8, 6 * v80)
			end
			local v_u_89 = false
			return {
				["place"] = function(p90, p91) -- name: place
					-- upvalues: (copy) v_u_87, (copy) v_u_86
					v_u_87.CFrame = p90
					local v92 = v_u_86
					local v93 = CFrame.Angles
					local v94 = p91 * 40
					local v95 = p90 * v93(0, math.sin(v94) * 0.25, 0)
					for v96, v97 in v92.parts do
						v97.CFrame = v95 * v92.offs[v96]
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_89, (copy) v_u_86, (copy) v_u_87, (ref) v_u_1
					if not v_u_89 then
						v_u_89 = true
						for _, v98 in v_u_86.parts do
							v98:Destroy()
						end
						for _, v99 in v_u_87:GetChildren() do
							if v99:IsA("ParticleEmitter") then
								v99.Enabled = false
							else
								if not v99:IsA("PointLight") then
									continue
								end
								v99:Destroy()
							end
						end
						v_u_1:AddItem(v_u_87, 0.4)
					end
				end
			}
		end,
		["impact"] = function(p100, p101) -- name: impact
			-- upvalues: (copy) p_u_35, (ref) v_u_25, (ref) v_u_29, (copy) v_u_58, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12
			local v102 = p100.size
			local v103 = p_u_35.ground(p101, 0.1)
			v_u_25(v103, 5.5 * v102, 0.45)
			v_u_29(p101, p100.lite and 1 or 2, 4 * v102)
			if not p100.lite then
				v_u_58(v103, 6, 1.6 * v102, 2.4 * v102)
				local v104 = { v_u_9, v_u_10, v_u_9 }
				p_u_35.chunks(p101, v104, 4, 22, v102 * 0.35, 0.7, false, 0.8)
			end
			p_u_35.glint(p101, v_u_12, 2.6 * v102, 0.12)
			p_u_35.hitSound(p101)
		end,
		["hit"] = function(_, p105, _) -- name: hit
			-- upvalues: (copy) p_u_35, (ref) v_u_8
			p_u_35.burst("Impact", p105, v_u_8, 0.55)
		end
	}
	v36.thousand_needles_e = {
		["cast"] = function(p106) -- name: cast
			-- upvalues: (copy) v_u_62
			v_u_62(p106, false)
		end,
		["windup"] = function(p107, p108, p109) -- name: windup
			-- upvalues: (ref) v_u_34, (copy) p_u_35
			local v110 = p107.size
			local v111 = p107.ability.radius * v110
			v_u_34(p_u_35.ground(p108, 0.08), v111 * 2.2, p109 + (p107.ability.duration or 2) + 0.6, 0.3)
		end,
		["zone"] = function(p_u_112, p113, p114) -- name: zone
			-- upvalues: (copy) p_u_35, (ref) v_u_21, (ref) v_u_29, (ref) v_u_9, (ref) v_u_10, (copy) v_u_58, (ref) v_u_25, (ref) v_u_6, (ref) v_u_3
			local v_u_115 = p_u_112.size
			local v_u_116 = p_u_112.lite
			local v_u_117 = p_u_112.ability.radius * v_u_115
			local v_u_118 = p_u_35.ground(p113, 0)
			local v_u_119 = 5 * v_u_115
			local v120 = p114 + 2
			local v121 = v_u_116 and 3 or 5
			local v_u_122 = {}
			for v123 = 1, v121 do
				local v124 = {
					["v"] = nil,
					["a"] = nil,
					["born"] = nil,
					["up"] = true,
					["v"] = v_u_21(v_u_119, v_u_116, v120),
					["a"] = v123 * 3.141592653589793 * 2 / v121 + math.random() * 0.4,
					["born"] = os.clock() + v123 * 0.04
				}
				table.insert(v_u_122, v124)
			end
			local v_u_125 = os.clock()
			local v_u_126 = 0.25
			local v_u_127 = 0
			local v_u_128 = false
			local function v_u_144(p_u_129) -- name: burst
				-- upvalues: (copy) v_u_118, (copy) v_u_117, (ref) v_u_29, (copy) v_u_119, (copy) v_u_116, (copy) v_u_115, (ref) p_u_35, (ref) v_u_9, (ref) v_u_10, (ref) v_u_58, (ref) v_u_25, (ref) v_u_6, (copy) p_u_112, (ref) v_u_128
				local v130 = v_u_118
				local v131 = p_u_129.a
				local v132 = math.cos(v131)
				local v133 = p_u_129.a
				local v134 = math.sin(v133)
				local v135 = v130 + Vector3.new(v132, 0, v134) * v_u_117 * 0.85
				v_u_29(v135 + Vector3.new(0, 1, 0) * v_u_119 * 0.6, v_u_116 and 1 or 3, 5 * v_u_115)
				local v136 = v135 + Vector3.new(0, 1, 0) * v_u_119 * 0.5
				local v137 = v_u_116 and 2 or 6
				local v138 = v_u_115
				local v139 = { v_u_9, v_u_10, v_u_9 }
				p_u_35.chunks(v136, v139, v137, 22, v138 * 0.35, 0.7, false, 0.8)
				local v140 = v_u_118
				local v141 = math.random() - 0.5
				local v142 = math.random() - 0.5
				local v143 = v140 + Vector3.new(v141, 0, v142) * v_u_117 * 0.3
				v_u_58(v143 + (v135 - v143) * 0.35, v_u_116 and 3 or 6, 1.8 * v_u_115, v_u_117 * 0.35)
				v_u_25(v143 + Vector3.new(0, 0.1, 0), v_u_117 * 0.8, 0.45)
				v_u_6.play("Hit", {
					["at"] = v135,
					["volume"] = p_u_112.mine and 0.6 or 0.35
				})
				p_u_129.up = false
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_128, (copy) p_u_129
					if not v_u_128 then
						p_u_129.a = math.random() * 3.141592653589793 * 2
						p_u_129.born = os.clock()
						p_u_129.up = true
					end
				end)
			end
			p_u_35.frame(function()
				-- upvalues: (ref) v_u_128, (copy) v_u_125, (copy) v_u_122, (copy) v_u_118, (copy) v_u_117, (ref) v_u_3, (copy) v_u_119, (ref) v_u_126, (copy) p_u_112, (ref) v_u_127, (copy) v_u_144
				if v_u_128 then
					return false
				end
				local v145 = os.clock()
				local v146 = v145 - v_u_125
				for _, v147 in v_u_122 do
					local v148 = v_u_118
					local v149 = v147.a
					local v150 = math.cos(v149)
					local v151 = v147.a
					local v152 = math.sin(v151)
					local v153 = v148 + Vector3.new(v150, 0, v152) * v_u_117 * 0.85
					local v154 = not v147.up and 0 or v_u_3.outBack((v145 - v147.born) / 0.2)
					local v155 = v145 * 7 + v147.a * 3
					local v156 = math.sin(v155) * 0.12
					local v157 = v147.v
					local v158 = CFrame.new(v153 + Vector3.new(0, 1, 0) * (v154 - 1) * v_u_119) * CFrame.Angles(v156, v147.a, v156 * 0.6)
					for v159, v160 in v157.parts do
						v160.CFrame = v158 * v157.offs[v159]
					end
				end
				if v_u_126 <= v146 then
					v_u_126 = v_u_126 + (p_u_112.ability.tick or 0.4)
					v_u_127 = v_u_127 % #v_u_122 + 1
					v_u_144(v_u_122[v_u_127])
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_128, (copy) v_u_122, (copy) v_u_118, (copy) v_u_117, (copy) v_u_119, (copy) v_u_116, (copy) v_u_115, (ref) p_u_35, (ref) v_u_9, (ref) v_u_10, (ref) v_u_29
				v_u_128 = true
				for _, v161 in v_u_122 do
					if v161.up then
						local v162 = v_u_118
						local v163 = v161.a
						local v164 = math.cos(v163)
						local v165 = v161.a
						local v166 = math.sin(v165)
						local v167 = v162 + Vector3.new(v164, 0, v166) * v_u_117 * 0.85
						local v168 = v167 + Vector3.new(0, 1, 0) * v_u_119 * 0.5
						local v169 = v_u_116 and 2 or 5
						local v170 = v_u_115
						local v171 = { v_u_9, v_u_10, v_u_9 }
						p_u_35.chunks(v168, v171, v169, 22, v170 * 0.35, 0.7, false, 0.8)
						v_u_29(v167 + Vector3.new(0, 1, 0) * v_u_119 * 0.5, 1, 4 * v_u_115)
					end
					for _, v172 in v161.v.parts do
						v172:Destroy()
					end
				end
			end
		end,
		["hit"] = function(_, p173, _) -- name: hit
			-- upvalues: (copy) p_u_35, (ref) v_u_8
			p_u_35.burst("Impact", p173, v_u_8, 0.6)
		end
	}
	local v_u_174 = {}
	setmetatable(v_u_174, {
		["__mode"] = "k"
	})
	v36.thousand_needles_r = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["strike"] = nil,
		["hit"] = nil,
		["cast"] = function(p175) -- name: cast
			-- upvalues: (copy) v_u_62
			v_u_62(p175, true)
		end,
		["windup"] = function(p176, p177, p_u_178) -- name: windup
			-- upvalues: (copy) p_u_35, (ref) v_u_34, (copy) v_u_174, (ref) v_u_21, (ref) v_u_3, (ref) v_u_29, (ref) v_u_6
			local v179 = p176.size
			local v180 = p176.lite
			local v_u_181 = p176.ability.radius * v179
			local v182 = p_u_35.ground(p177, 0)
			local v_u_183 = p_u_178 + 1
			v_u_34(v182 + Vector3.new(0, 0.08, 0), v_u_181 * 2.1, p_u_178 + 0.6, 0.35)
			local v_u_184 = v_u_181 * 0.42
			local v_u_185 = v182 + Vector3.new(0, 1, 0) * (16 + v_u_184 * 0.5)
			v_u_174[p176] = {
				["mouth"] = v_u_185 - Vector3.new(0, 1, 0) * v_u_184 * 0.5,
				["g"] = v182,
				["R"] = v_u_181
			}
			local v_u_186 = v_u_21(v_u_184, v180, v_u_183)
			local v_u_187 = v180 and 4 or 9
			local v_u_188 = {}
			for _ = 1, v_u_187 do
				local v189 = v_u_3.FISH
				local v190 = 2.4 * v179
				local v191, v192 = v_u_3.build(v189, v190, true, v_u_183)
				table.insert(v_u_188, {
					["parts"] = v191,
					["offs"] = v192
				})
			end
			local v_u_193 = os.clock()
			p_u_35.frame(function()
				-- upvalues: (copy) v_u_193, (ref) v_u_3, (copy) p_u_178, (copy) v_u_185, (copy) v_u_184, (copy) v_u_186, (copy) v_u_188, (copy) v_u_187, (copy) v_u_181, (copy) v_u_183
				local v194 = os.clock() - v_u_193
				local v195 = 1 - v_u_3.smooth(v194 / 0.35)
				local v196 = (v194 - p_u_178) / 0.4
				local v197 = math.clamp(v196, 0, 1)
				local v198 = CFrame.new(v_u_185 + Vector3.new(0, 1, 0) * (v195 * 14 + v197 * 10))
				local v199 = CFrame.Angles
				local v200 = v194 * 3
				local v201 = v198 * v199(3.391592653589793 + math.sin(v200) * 0.08, v194 * 0.6, 0) * CFrame.new(0, -v_u_184 * 0.5, 0)
				local v202 = v_u_186
				for v203, v204 in v202.parts do
					v204.CFrame = v201 * v202.offs[v203]
				end
				for _, v205 in v_u_186.parts do
					v205.Transparency = v197
				end
				for v206, v207 in v_u_188 do
					local v208 = (v194 - v206 * 0.04) / 0.3
					local v209 = math.clamp(v208, 0, 1)
					local v210 = v194 * 2.4 + v206 * 3.141592653589793 * 2 / v_u_187
					local v211 = v_u_181 * 0.55 * v209
					local v212 = v_u_185 - Vector3.new(0, 1, 0) * (v_u_184 * 0.5 + v209 * 3)
					local v213 = math.cos(v210)
					local v214 = math.sin(v210)
					local v215 = v212 + Vector3.new(v213, 0, v214) * v211
					local v216 = v194 * 3 + v206
					local v217 = v215 + Vector3.new(0, 1, 0) * math.sin(v216) * 1.2
					local v218 = -math.sin(v210)
					local v219 = math.cos(v210)
					local v220 = Vector3.new(v218, 0, v219)
					local v221 = CFrame.lookAt(v217, v217 + v220)
					local v222 = CFrame.Angles
					local v223 = v194 * 12 + v206
					local v224 = v221 * v222(0, math.sin(v223) * 0.25, 0)
					for v225, v226 in v207.parts do
						v226.CFrame = v224 * v207.offs[v225]
					end
					for _, v227 in v207.parts do
						v227.Transparency = v197
					end
				end
				if v_u_183 - 0.05 > v194 then
					return true
				end
				for _, v228 in v_u_186.parts do
					v228:Destroy()
				end
				for _, v229 in v_u_188 do
					for _, v230 in v229.parts do
						v230:Destroy()
					end
				end
				return false
			end)
			v_u_29(v_u_185 - Vector3.new(0, 1, 0) * v_u_184 * 0.5, v180 and 2 or 5, 6 * v179)
			v_u_6.play("Hit", {
				["at"] = v182,
				["volume"] = p176.mine and 0.6 or 0.35
			})
		end,
		["strike"] = function(p_u_231, p232, p233) -- name: strike
			-- upvalues: (copy) v_u_174, (copy) p_u_35, (ref) v_u_3, (ref) v_u_25, (ref) v_u_29, (copy) v_u_58, (ref) v_u_12, (ref) v_u_6, (ref) v_u_4
			local v_u_234 = p_u_231.size
			local v_u_235 = p_u_231.lite
			local v_u_236 = (p_u_231.ability.strikeRadius or 5) * v_u_234
			local v_u_237 = v_u_174[p_u_231]
			local v_u_238 = p_u_35.ground(p232, 0.1)
			if v_u_237 and not v_u_235 then
				p_u_35.after(p233 - 0.2, function()
					-- upvalues: (ref) v_u_3, (copy) v_u_234, (copy) v_u_237, (ref) p_u_35, (copy) v_u_238
					local v239 = v_u_3.FISH
					local v240 = 2.4 * v_u_234
					local v241, v242 = v_u_3.build(v239, v240, true, 0.5)
					local v_u_243 = {
						["parts"] = v241,
						["offs"] = v242
					}
					local v_u_244 = v_u_237.mouth - Vector3.new(0, 3, 0)
					p_u_35.animate(0.2, 0, function(p245)
						-- upvalues: (copy) v_u_244, (ref) v_u_238, (copy) v_u_243
						local v246 = v_u_244:Lerp(v_u_238 + Vector3.new(0, 0.5, 0), p245 * p245)
						local v247 = v_u_244
						local v248 = v_u_238 + Vector3.new(0, 0.5, 0)
						local v249 = p245 * p245 + 0.05
						local v250 = v247:Lerp(v248, (math.min(v249, 1.05)))
						local v251 = v_u_243
						local v252 = CFrame.lookAt
						if (v250 - v246).Magnitude <= 0.001 then
							v250 = v246 - Vector3.new(0, 1, 0)
						end
						local v253 = v252(v246, v250)
						for v254, v255 in v251.parts do
							v255.CFrame = v253 * v251.offs[v254]
						end
						if p245 >= 1 then
							for _, v256 in v_u_243.parts do
								v256:Destroy()
							end
						end
					end)
				end)
			end
			p_u_35.after(p233, function()
				-- upvalues: (ref) v_u_25, (copy) v_u_238, (copy) v_u_236, (ref) v_u_29, (copy) v_u_234, (copy) v_u_235, (ref) v_u_58, (ref) p_u_35, (ref) v_u_12, (ref) v_u_6, (copy) p_u_231, (ref) v_u_4
				v_u_25(v_u_238, v_u_236 * 2, 0.45)
				v_u_29(v_u_238 + Vector3.new(0, 0.8, 0), 1, 3.5 * v_u_234)
				if not v_u_235 then
					v_u_58(v_u_238, 4, 1.6 * v_u_234, v_u_236 * 0.6)
				end
				p_u_35.glint(v_u_238 + Vector3.new(0, 1.2, 0), v_u_12, 3 * v_u_234, 0.12)
				v_u_6.play(math.random() < 0.3 and "Explosion" or "Hit", {
					["at"] = v_u_238,
					["volume"] = p_u_231.mine and 0.5 or 0.28
				})
				if p_u_231.mine then
					v_u_4.shake(0.08, 0.1)
				end
			end)
		end,
		["hit"] = function(_, p257, _) -- name: hit
			-- upvalues: (copy) p_u_35, (ref) v_u_8
			p_u_35.burst("Impact", p257, v_u_8, 0.55)
		end
	}
	return v36
end