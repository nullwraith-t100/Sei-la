local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(56, 146, 255)
local v_u_9 = Color3.fromRGB(30, 82, 210)
local v_u_10 = Color3.fromRGB(14, 32, 92)
local v_u_11 = Color3.fromRGB(242, 240, 232)
local v_u_12 = Enum.Material.SmoothPlastic
local v_u_13 = Enum.PartType.Wedge
local v_u_14 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_15 = CFrame.Angles(0, 3.141592653589793, 0) * CFrame.Angles(0.4886921905584123, 0, 0)
local function v_u_23(p16) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v17 = v_u_2:FindFirstChild("EyePieces")
	if v17 then
		v17 = v17:FindFirstChild("w7_los_lobos")
	end
	if not (v17 and v17:IsA("MeshPart")) then
		return nil
	end
	local v18 = v17:Clone()
	local v19 = v17.Size
	local v20 = v19.X
	local v21 = v19.Y
	local v22 = v19.Z
	v18.Size = v19 * (p16 / math.max(v20, v21, v22, 0.01))
	v18.Anchored = true
	v18.CanCollide = false
	v18.CanQuery = false
	v18.CanTouch = false
	v18.Massless = true
	v18.CastShadow = false
	v18.Parent = v_u_4.folder()
	return v18
end
return function(p_u_24)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_1, (copy) v_u_10, (copy) v_u_5, (copy) v_u_14, (copy) v_u_23, (copy) v_u_15, (copy) v_u_7, (copy) v_u_12, (copy) v_u_13, (copy) v_u_9, (copy) v_u_11
	return {
		["w7_los_lobos"] = function(p_u_25, p26)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) p_u_24, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_10, (ref) v_u_5, (ref) v_u_14, (ref) v_u_23, (ref) v_u_15, (ref) v_u_7, (ref) v_u_12, (ref) v_u_13, (ref) v_u_9, (ref) v_u_11
			local v27 = v_u_4.color(p26.color)
			local v28 = p_u_25.headY / 1.5
			local v_u_29 = math.clamp(v28, 0.7, 3)
			local v_u_30 = Instance.new("Attachment")
			v_u_30.Parent = v_u_3.Terrain
			p_u_24.own(p_u_25, v_u_30)
			local v_u_31 = Instance.new("ParticleEmitter")
			v_u_31.Enabled = false
			v_u_31.Texture = v_u_6.LobosPaw
			v_u_31.Color = ColorSequence.new(v_u_8)
			v_u_31.LightEmission = 0.15
			v_u_31.LightInfluence = 0
			v_u_31.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_31.EmissionDirection = Enum.NormalId.Top
			v_u_31.SpreadAngle = Vector2.zero
			v_u_31.Speed = NumberRange.new(0.01)
			v_u_31.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_29 * 0.35 * p_u_25.fx), NumberSequenceKeypoint.new(0.1, v_u_29 * 0.62 * p_u_25.fx), NumberSequenceKeypoint.new(1, v_u_29 * 0.62 * p_u_25.fx) })
			v_u_31.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.55, 0.15), NumberSequenceKeypoint.new(1, 1) })
			v_u_31.Lifetime = NumberRange.new(1.3)
			v_u_31.Parent = v_u_30
			local v32 = p_u_25.stops
			local function v33()
				-- upvalues: (ref) v_u_1, (copy) v_u_30
				v_u_1:AddItem(v_u_30, 1.5)
			end
			table.insert(v32, v33)
			local v_u_34 = 0
			local function v_u_50(p35, p36, p37, p38) -- name: printAt
				-- upvalues: (ref) p_u_24, (copy) p_u_25, (copy) v_u_29, (copy) v_u_30, (copy) v_u_31
				local v39 = math.cos(p36)
				local v40 = math.sin(p36)
				local v41 = Vector3.new(v39, 0, v40)
				local v42 = -math.sin(p36)
				local v43 = math.cos(p36)
				local v44 = Vector3.new(v42, 0, v43)
				local v45 = p_u_24.feetAt(p_u_25, p35, 0.1) + v41 * (p38 + (p37 and 0.28 or -0.28) * v_u_29)
				v_u_30.WorldCFrame = CFrame.new(v45)
				local v46 = v44.X
				local v47 = v44.Z
				local v48 = math.atan2(v46, v47)
				local v49 = math.deg(v48) + 0
				v_u_31.Rotation = NumberRange.new(v49, v49)
				v_u_31:Emit(1)
			end
			local v_u_54 = p_u_24.throb(p_u_25, 7, 2.5, 1.1, function(p51)
				-- upvalues: (ref) p_u_24, (copy) p_u_25, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8, (ref) v_u_5, (copy) v_u_50, (copy) v_u_29
				local v52 = p_u_24.feetAt(p_u_25, p51, 0.15)
				v_u_4.ring(v52, v_u_10, 5.5 * p_u_25.fx, 0.55, v_u_6.Ring)
				v_u_4.ring(v52, v_u_8, 7.5 * p_u_25.fx, 0.75, v_u_6.Ring)
				if v_u_5.level() >= 2 then
					for v_u_53 = 1, 12 do
						task.delay(v_u_53 * 0.035, function()
							-- upvalues: (ref) p_u_25, (ref) v_u_50, (copy) v_u_53, (ref) v_u_29
							if not p_u_25.stopped then
								v_u_50(p_u_25.root.CFrame, v_u_53 / 12 * 3.141592653589793 * 2, v_u_53 % 2 == 0, v_u_29 * 3.4)
							end
						end)
					end
				end
			end)
			local v_u_55 = 0
			local v56 = p_u_25.ticks
			local function v63(p57, p58, p59)
				-- upvalues: (ref) v_u_5, (ref) p_u_24, (ref) v_u_55, (ref) v_u_34, (copy) v_u_50, (copy) v_u_29
				if v_u_5.level() >= 2 and (p57.Position - p_u_24.camPos()).Magnitude <= 120 then
					v_u_55 = v_u_55 + p59 * 1.9
					if p58 - v_u_34 >= 0.2 then
						v_u_34 = p58
						local v60 = v_u_50
						local v61 = v_u_55
						local v62 = p58 * 5
						v60(p57, v61, math.floor(v62) % 2 == 0, v_u_29 * 2.7)
					end
				end
			end
			table.insert(v56, v63)
			local v_u_80 = p_u_24.group(p_u_25, function(p64, p65)
				-- upvalues: (copy) v_u_29, (copy) p_u_25, (copy) v_u_54
				local v66 = CFrame.new
				local v67 = v_u_29 * -1.35
				local v68 = p_u_25.headY + v_u_29 * 0.5
				local v69 = p65 * 1.3
				local v70 = p64 * v66(v67, v68 + math.sin(v69) * 0.12 * v_u_29, v_u_29 * 0.75)
				local v71 = CFrame.Angles
				local v72 = p65 * 0.7
				local v73 = v70 * v71(0, math.sin(v72) * 0.08 + 0.25, 0)
				local v74 = CFrame.Angles
				local v75 = v_u_54()
				local v76
				if v75 <= 0 then
					v76 = 0
				else
					local v77 = 1 - v75
					local v78 = math.clamp(v77, 0, 1)
					local v79 = v78 * v78 * (3 - v78 * 2) * 3.141592653589793
					v76 = math.sin(v79)
				end
				return v73 * v74(v76 * 0.55, 0, 0)
			end)
			local v81 = p_u_24.picture(v_u_29 * 4.4, v_u_6.Glow, v_u_8, 0.35)
			p_u_24.pin(p_u_25, v_u_80, v81, CFrame.new(0, 0, v_u_29 * 0.6) * v_u_14)
			p_u_24.fadeFromBehind(p_u_25, v81, 0.6)
			local v_u_82 = CFrame.new(Vector3.new(0, 1.0073999, 0.55545) * v_u_29)
			local v83 = v_u_23(v_u_29 * 2.3)
			if v83 then
				p_u_24.pin(p_u_25, v_u_80, v83, v_u_15)
				p_u_24.fadeFromBehind(p_u_25, v83, 0.35)
			else
				p_u_24.pin(p_u_25, v_u_80, p_u_24.ball(v_u_29 * 1.2, v27, 0.05), CFrame.identity)
				local v84 = p_u_24.bar(Vector3.new(0.6, 0.55, 1.1) * v_u_29, v_u_7, 0, v_u_12)
				v84.Shape = v_u_13
				p_u_24.pin(p_u_25, v_u_80, v84, CFrame.new(0, v_u_29 * 0.25, v_u_29 * -0.75) * CFrame.Angles(0.5, 3.141592653589793, 0))
				for _, v85 in { -1, 1 } do
					local v86 = p_u_24.bar(Vector3.new(0.18, 0.6, 0.4) * v_u_29, v_u_8)
					v86.Shape = v_u_13
					p_u_24.pin(p_u_25, v_u_80, v86, CFrame.new(v85 * 0.35 * v_u_29, v_u_29 * 0.62, v_u_29 * 0.12) * CFrame.Angles(0, 0, v85 * -0.25))
					p_u_24.pin(p_u_25, v_u_80, p_u_24.bar(Vector3.new(0.15, 0.1, 0.06) * v_u_29, v_u_10, 0, v_u_12), CFrame.new(v85 * 0.27 * v_u_29, v_u_29 * 0.22, v_u_29 * -0.55))
				end
			end
			local v_u_87 = 0
			local v88 = p_u_25.ticks
			local function v101(_, p89)
				-- upvalues: (copy) v_u_54, (ref) v_u_87, (copy) v_u_80, (ref) p_u_24, (ref) v_u_15, (copy) v_u_82, (ref) v_u_4, (copy) v_u_29, (ref) v_u_8, (ref) v_u_6, (copy) p_u_25, (ref) v_u_1
				local v90 = v_u_54()
				local v91
				if v90 <= 0 then
					v91 = 0
				else
					local v92 = 1 - v90
					local v93 = math.clamp(v92, 0, 1)
					local v94 = v93 * v93 * (3 - v93 * 2) * 3.141592653589793
					v91 = math.sin(v94)
				end
				if v91 >= 0.35 and (p89 - v_u_87 >= 0.16 and (v_u_80.cf.Position - p_u_24.camPos()).Magnitude <= 150) then
					v_u_87 = p89
					local v95 = (v_u_80.cf * v_u_15 * v_u_82).Position
					local v96 = (v_u_80.cf * v_u_15):VectorToWorldSpace(Vector3.new(0, 0.876, 0.483))
					local v97 = v_u_4.part(Vector3.new(0.6, 0.05, 0.6) * v_u_29, CFrame.lookAt(v95, v95 + v96) * CFrame.Angles(1.5707963267948966, 0, 0), v_u_8, {
						["transparency"] = 1
					})
					local v98 = Instance.new("Decal")
					v98.Face = Enum.NormalId.Top
					v98.Texture = v_u_6.Ring
					v98.Color3 = v_u_8
					v98.Parent = v97
					local v99 = v98:Clone()
					v99.Face = Enum.NormalId.Bottom
					v99.Parent = v97
					local v100 = CFrame.lookAt(v95 + v96 * 2.2 * v_u_29, v95 + v96 * 3 * v_u_29) * CFrame.Angles(1.5707963267948966, 0, 0)
					v_u_4.tween(v97, 0.5, {
						["Size"] = Vector3.new(3, 0.05, 3) * v_u_29 * p_u_25.fx,
						["CFrame"] = v100
					})
					v_u_4.tween(v98, 0.5, {
						["Transparency"] = 1
					})
					v_u_4.tween(v99, 0.5, {
						["Transparency"] = 1
					})
					v_u_1:AddItem(v97, 0.55)
				end
			end
			table.insert(v88, v101)
			for _, v_u_102 in { -1, 1 } do
				local v119 = p_u_24.group(p_u_25, function(p103, p104)
					-- upvalues: (copy) v_u_54, (copy) v_u_102, (copy) v_u_29
					local v105 = v_u_54()
					local v106
					if v105 <= 0 then
						v106 = 0
					else
						local v107 = 1 - v105
						local v108 = math.clamp(v107, 0, 1)
						local v109 = v108 * v108 * (3 - v108 * 2) * 3.141592653589793
						v106 = math.sin(v109)
					end
					local v110 = CFrame.new
					local v111 = v_u_102 * 1.45 * v_u_29
					local v112 = v_u_29 * -0.3
					local v113 = p104 * 1.6 + v_u_102
					local v114 = p103 * v110(v111, v112 + math.sin(v113) * 0.08 * v_u_29, v_u_29 * -0.15 + v106 * 0.35 * v_u_29)
					local v115 = CFrame.Angles
					local v116 = v106 * 0.9 + -0.12
					local v117 = v_u_102 * -0.06
					local v118 = p104 * 1.1 + v_u_102
					return v114 * v115(v116, v117, math.sin(v118) * 0.05)
				end)
				for _, v120 in {
					{
						["size"] = Vector3.new(0.36, 0.5, 1),
						["at"] = nil,
						["color"] = nil,
						["material"] = nil,
						["at"] = CFrame.new(0, 0, 0.1),
						["color"] = v_u_10,
						["material"] = v_u_12
					},
					{
						["size"] = Vector3.new(0.22, 0.22, 1.5),
						["at"] = nil,
						["color"] = nil,
						["at"] = CFrame.new(0, 0.1, -0.95),
						["color"] = v_u_8
					},
					{
						["size"] = Vector3.new(0.1, 0.1, 1.6),
						["at"] = nil,
						["color"] = nil,
						["at"] = CFrame.new(0, 0.1, -1),
						["color"] = v_u_7
					},
					{
						["size"] = Vector3.new(0.3, 0.85, 0.4),
						["at"] = nil,
						["color"] = nil,
						["material"] = nil,
						["at"] = CFrame.new(0, -0.5, 0.5) * CFrame.Angles(-0.4, 0, 0),
						["color"] = v_u_9,
						["material"] = v_u_12
					},
					{
						["size"] = Vector3.new(0.12, 0.22, 0.14),
						["at"] = nil,
						["color"] = nil,
						["material"] = nil,
						["at"] = CFrame.new(0, 0.32, 0.55),
						["color"] = v_u_10,
						["material"] = v_u_12
					}
				} do
					p_u_24.pin(p_u_25, v119, p_u_24.bar(v120.size * v_u_29, v120.color, 0, v120.material), CFrame.new(v120.at.Position * v_u_29) * v120.at.Rotation)
				end
				p_u_24.pin(p_u_25, v119, p_u_24.ball(v_u_29 * 0.46, v27), CFrame.new(0, v_u_29 * 0.02, v_u_29 * -0.2))
				p_u_24.pin(p_u_25, v119, p_u_24.ball(v_u_29 * 0.3, v27), CFrame.new(0, v_u_29 * 0.1, v_u_29 * -1.72))
			end
			local v122 = p_u_24.group(p_u_25, function(p121)
				-- upvalues: (copy) p_u_25, (copy) v_u_29
				return p121 * CFrame.new(0, p_u_25.headY - v_u_29 * 0.62, v_u_29 * -0.05)
			end)
			for v123 = 1, 10 do
				local v124 = (v123 - 0.5) / 10 * 3.141592653589793 * 2
				local v125 = math.sin(v124)
				local v126 = -math.cos(v124)
				local v127 = Vector3.new(v125, 0, v126)
				local v128 = v123 % 2 == 0 and 0.5 or 0.38
				local v129 = p_u_24.bar(Vector3.new(0.1, v128, 0.2) * v_u_29, v_u_11)
				v129.Shape = v_u_13
				local v130 = v127 * 0.66 * v_u_29
				local v131 = (Vector3.new(0, 0.921061, 0) + v127 * 0.3894183423086505).Unit
				p_u_24.pin(p_u_25, v122, v129, CFrame.fromMatrix(v130 + v131 * v128 * v_u_29 / 2, v127:Cross(v131), v131))
			end
			p_u_24.particles(p_u_25, "AuraMode", v27, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end