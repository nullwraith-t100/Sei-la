local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("B06BFF")
local v_u_9 = Color3.new(1, 1, 1)
local v10 = Color3.fromRGB(235, 225, 255)
local v_u_11 = Color3.new(v10.R * 2.35, v10.G * 2.35, v10.B * 2.35)
local v_u_12 = Color3.fromRGB(255, 125, 215)
local v_u_13 = Color3.fromRGB(115, 210, 255)
local v_u_14 = Color3.fromRGB(78, 30, 160)
local v_u_15 = Color3.fromRGB(226, 196, 255)
local v_u_16 = {
	v_u_8,
	v_u_12,
	v_u_13,
	v_u_14,
	v_u_15
}
local v_u_17 = Enum.PartType.Ball
local function v_u_36(p18, p19, p20, p21, p22) -- name: picture
	-- upvalues: (copy) v_u_5
	local v23 = Color3.new
	local v24 = p21.R
	local v25 = math.min(v24, 1)
	local v26 = p21.G
	local v27 = math.min(v26, 1)
	local v28 = p21.B
	local v29 = v23(v25, v27, (math.min(v28, 1)))
	local v30 = v_u_5.part
	local v31 = p19 * 2
	local v32 = p19 * 2
	local v33 = v30(Vector3.new(v31, 0.05, v32), p18, v29, {
		["transparency"] = 1
	})
	for _, v34 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v35 = Instance.new("Decal")
		v35.Face = v34
		v35.Texture = p20
		v35.Color3 = p21
		v35.Transparency = p22
		v35.Parent = v33
	end
	return v33
end
local function v_u_40(p37, p38) -- name: setAlpha
	for _, v39 in p37:GetChildren() do
		if not v39:IsA("Decal") then
			continue
		end
		v39.Transparency = p38
	end
end
local function v_u_45(p41, p42, p43) -- name: gas
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_13
	local v44 = Instance.new("ParticleEmitter")
	v44.Texture = "rbxassetid://84314209625046"
	v44.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v44.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v44.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_8), ColorSequenceKeypoint.new(0.5, v_u_12), ColorSequenceKeypoint.new(1, v_u_13) })
	v44.LightEmission = 0.75
	v44.LightInfluence = 0
	v44.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.6, 0.45), NumberSequenceKeypoint.new(1, 1) })
	v44.Lifetime = NumberRange.new(p43 * 0.7, p43)
	v44.Size = NumberSequence.new(p42 * 0.6, p42 * 1.3)
	v44.Rotation = NumberRange.new(0, 360)
	v44.RotSpeed = NumberRange.new(-50, 50)
	v44.Speed = NumberRange.new(0.5, 1.5)
	v44.SpreadAngle = Vector2.new(180, 180)
	v44.Rate = 0
	v44.Enabled = false
	v44.Parent = p41
	return v44
end
local function v_u_53(p46, p47, p48, p49, p50) -- name: gasBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_45, (copy) v_u_1
	local v51 = Instance.new("Attachment")
	v51.WorldPosition = p46
	v51.Parent = v_u_4.Terrain
	local v52 = v_u_45(v51, p48, p50)
	v52.Speed = NumberRange.new(p49 * 0.5, p49)
	v52.Drag = 3
	v52:Emit(p47)
	v_u_1:AddItem(v51, p50 + 0.3)
end
local function v_u_60(p54, p55, p56, p57) -- name: starBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_15, (copy) v_u_1
	local v58 = Instance.new("Attachment")
	v58.WorldPosition = p54
	v58.Parent = v_u_4.Terrain
	local v59 = Instance.new("ParticleEmitter")
	v59.Texture = "rbxassetid://76741008972969"
	v59.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v59.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v59.Color = ColorSequence.new(v_u_9, v_u_15)
	v59.LightEmission = 0.8
	v59.LightInfluence = 0
	v59.Lifetime = NumberRange.new(0.5, 0.9)
	v59.Size = NumberSequence.new(p56, p56 * 0.3)
	v59.Speed = NumberRange.new(p57 * 0.4, p57)
	v59.SpreadAngle = Vector2.new(180, 180)
	v59.Drag = 2
	v59.Rotation = NumberRange.new(0, 360)
	v59.Rate = 0
	v59.Enabled = false
	v59.Parent = v58
	v59:Emit(p55)
	v_u_1:AddItem(v58, 1.2)
end
local v_u_61 = 0
local function v_u_65(p62) -- name: bangScreen
	-- upvalues: (ref) v_u_61, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_1
	if os.clock() >= v_u_61 then
		v_u_61 = os.clock() + p62 + 1
		local v_u_63 = Instance.new("ColorCorrectionEffect")
		v_u_63.Name = "BigBang"
		v_u_63.Parent = v_u_2
		v_u_5.tween(v_u_63, p62, {
			["Brightness"] = -0.18,
			["Saturation"] = -0.2,
			["TintColor"] = nil,
			["TintColor"] = Color3.fromRGB(205, 190, 255)
		})
		task.delay(p62, function()
			-- upvalues: (copy) v_u_63, (ref) v_u_5, (ref) v_u_9
			v_u_63.Brightness = 0.35
			v_u_63.Contrast = 0.1
			v_u_63.TintColor = Color3.fromRGB(255, 220, 245)
			v_u_63.Saturation = 0.1
			local v64 = {
				["Brightness"] = 0,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = nil,
				["TintColor"] = v_u_9
			}
			v_u_5.tween(v_u_63, 0.7, v64)
		end)
		v_u_1:AddItem(v_u_63, p62 + 0.8)
	end
end
return function(p_u_66)
	-- upvalues: (copy) v_u_4, (copy) v_u_36, (copy) v_u_1, (copy) v_u_40, (copy) v_u_5, (copy) v_u_8, (copy) v_u_7, (copy) v_u_11, (copy) v_u_17, (copy) v_u_12, (copy) v_u_45, (copy) v_u_9, (copy) v_u_53, (copy) v_u_15, (copy) v_u_6, (copy) v_u_13, (copy) v_u_16, (copy) v_u_60, (copy) v_u_14, (copy) v_u_65
	local v67 = {}
	local function v_u_95(p_u_68, p_u_69, p_u_70, p71, p72, p_u_73, p_u_74, p75) -- name: flare
		-- upvalues: (ref) v_u_36, (ref) v_u_4, (copy) p_u_66, (ref) v_u_1, (ref) v_u_40
		local v_u_76 = p75 or 0
		local v_u_77 = math.random() * 3.141592653589793 * 2
		local v78 = v_u_36
		local v79 = v_u_4.CurrentCamera
		local v80
		if v79 then
			local v81 = v79.CFrame.Position - p_u_68
			v80 = v81.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v81.Unit
		else
			v80 = Vector3.new(0, 0, 1)
		end
		local v_u_82 = v78(p_u_66.facing(p_u_68 + v80 * 0.3, v80) * CFrame.Angles(0, v_u_77, 0), p_u_69, p71, p72, v_u_76)
		v_u_1:AddItem(v_u_82, p_u_73 + 0.1)
		p_u_66.animate(p_u_73, 0, function(p83)
			-- upvalues: (copy) v_u_82, (copy) p_u_69, (copy) p_u_70, (copy) p_u_68, (copy) v_u_77, (copy) p_u_73, (copy) p_u_74, (ref) v_u_4, (ref) p_u_66, (ref) v_u_40, (copy) v_u_76
			local v84 = v_u_82
			local v85 = p_u_69 + (p_u_70 - p_u_69) * (1 - (1 - p83) ^ 3)
			local v86 = math.max(v85, 0.03)
			local v87 = v86 * 2
			local v88 = v86 * 2
			v84.Size = Vector3.new(v87, 0.05, v88)
			local v89 = v_u_82
			local v90 = p_u_68
			local v91 = v_u_77 + p83 * p_u_73 * p_u_74
			local v92 = v_u_4.CurrentCamera
			local v93
			if v92 then
				local v94 = v92.CFrame.Position - v90
				v93 = v94.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v94.Unit
			else
				v93 = Vector3.new(0, 0, 1)
			end
			v89.CFrame = p_u_66.facing(v90 + v93 * 0.3, v93) * CFrame.Angles(0, v91, 0)
			v_u_40(v_u_82, v_u_76 + (1 - v_u_76) * p83 ^ 1.5)
			if p83 >= 1 then
				v_u_82:Destroy()
			end
		end)
	end
	v67.nebula_rinne_a = {
		["cast"] = function(p96) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_66, (ref) v_u_9, (copy) v_u_95, (ref) v_u_7, (ref) v_u_11
			local v97 = p96.size
			local v98 = p96.eye + p96.dir * 1.2
			v_u_5.flash(v98, v_u_8, 3.2 * v97, 0.12)
			p_u_66.pop(v98, v_u_9, 1.2 * v97, 0.3 * v97, 0.1)
			if not p96.lite then
				v_u_95(v98, 0.5 * v97, 1.6 * v97, v_u_7.NebulaTomoe, v_u_11, 0.14, 20)
			end
		end,
		["shot"] = function(p99, p100) -- name: tomoeShot
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (ref) v_u_17, (ref) v_u_12, (copy) p_u_66, (ref) v_u_45, (ref) v_u_4
			local v_u_101 = p99.size
			local v_u_102 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p100, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_102, 3)
			local v_u_103 = v_u_36(p100, 1.15 * v_u_101, v_u_7.NebulaTomoe, v_u_11, 0)
			v_u_1:AddItem(v_u_103, 3)
			local v_u_104 = {}
			local v105 = {
				["shape"] = nil,
				["transparency"] = 0.45,
				["shape"] = v_u_17
			}
			__set_list(v_u_104, 1, {v_u_5.part(Vector3.new(1.6, 1.6, 1.6) * v_u_101, p100, v_u_8, v105)})
			if not p99.lite then
				local v106 = v_u_5.part
				local v107 = Vector3.new(2.4, 2.4, 2.4) * v_u_101
				local v108 = v_u_12
				local v109 = {
					["shape"] = nil,
					["transparency"] = 0.78,
					["shape"] = v_u_17
				}
				table.insert(v_u_104, v106(v107, p100, v108, v109))
			end
			for _, v110 in v_u_104 do
				v_u_1:AddItem(v110, 3)
			end
			p_u_66.streak(v_u_102, v_u_8, v_u_12, 1.1 * v_u_101, p99.lite and 0.12 or 0.22)
			local v_u_111
			if p99.lite then
				v_u_111 = nil
			else
				v_u_111 = v_u_45(v_u_102, 1.1 * v_u_101, 0.55)
				v_u_111.Rate = 30
				v_u_111.Enabled = true
			end
			if p99.mine then
				p_u_66.light(v_u_102, v_u_8, 9 * v_u_101)
			end
			local v_u_112 = false
			return {
				["place"] = function(p113, p114) -- name: place
					-- upvalues: (copy) v_u_102, (copy) v_u_104, (copy) v_u_103, (copy) v_u_101, (ref) v_u_4, (ref) p_u_66
					v_u_102.CFrame = p113
					for _, v115 in v_u_104 do
						v115.CFrame = p113
					end
					local v116 = v_u_103
					local v117 = p113.Position
					local v118 = -p114 * 22
					local v119 = 0.8 * v_u_101
					local v120 = v_u_4.CurrentCamera
					local v121
					if v120 then
						local v122 = v120.CFrame.Position - v117
						v121 = v122.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v122.Unit
					else
						v121 = Vector3.new(0, 0, 1)
					end
					v116.CFrame = p_u_66.facing(v117 + v121 * (v119 or 0.3), v121) * CFrame.Angles(0, v118, 0)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_112, (ref) v_u_111, (copy) v_u_102, (ref) v_u_1, (copy) v_u_103, (copy) v_u_104
					if not v_u_112 then
						v_u_112 = true
						local v123 = v_u_111
						if v123 then
							v123.Enabled = false
						end
						local v124 = v_u_102:FindFirstChildWhichIsA("PointLight")
						if v124 then
							v124:Destroy()
						end
						v_u_1:AddItem(v_u_102, 0.6)
						v_u_103:Destroy()
						for _, v125 in v_u_104 do
							v125:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p126, p127) -- name: tomoeImpact
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_9, (copy) v_u_95, (ref) v_u_7, (ref) v_u_11, (ref) v_u_5, (ref) v_u_53
			local v128 = p126.size
			p_u_66.pop(p127, v_u_8, 1.2 * v128, 4.4 * v128, 0.22, 0.35)
			p_u_66.pop(p127, v_u_9, 0.8 * v128, 2 * v128, 0.12)
			v_u_95(p127, 1.1 * v128, 3.4 * v128, v_u_7.NebulaTomoe, v_u_11, 0.26, -14)
			v_u_5.ring(p_u_66.ground(p127), v_u_8, p126.ability.radius * v128 * 0.8, 0.25, v_u_7.Ring)
			p_u_66.burst("Impact", p127, v_u_8, 0.9 * v128)
			if not p126.lite then
				v_u_53(p127, 6, 1.7 * v128, 9 * v128, 0.6)
				p_u_66.glint(p127 + Vector3.new(0.4, 1, -0.3) * v128, v_u_9, 2.5 * v128, 0.16)
			end
			p_u_66.hitSound(p127)
		end,
		["hit"] = p_u_66.simpleHit(v_u_8, 0.6)
	}
	local v_u_129 = {}
	setmetatable(v_u_129, {
		["__mode"] = "k"
	})
	local v_u_130 = {}
	setmetatable(v_u_130, {
		["__mode"] = "k"
	})
	local function v_u_146(p131, p132, p133, p134, p135, p136, p137, p138) -- name: newHoop
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11
		local v139 = p131 * 2
		local v140 = 3.141592653589793 / p132
		local v141 = v139 * math.sin(v140) + 0.3
		local v142 = {}
		for _ = 1, p132 do
			local v143 = v_u_5.part(Vector3.new(0.5, 0.5, v141), CFrame.identity, v_u_9)
			v_u_1:AddItem(v143, p138)
			table.insert(v142, v143)
		end
		local v144 = {}
		for _ = 1, p133 do
			local v145 = v_u_36(CFrame.identity, 1.7, v_u_7.NebulaTomoe, v_u_11, 0)
			v_u_1:AddItem(v145, p138)
			table.insert(v144, v145)
		end
		return {
			["segs"] = nil,
			["tomoe"] = nil,
			["radius"] = nil,
			["thick"] = 0.5,
			["axis"] = nil,
			["lean"] = nil,
			["turn"] = nil,
			["ride"] = nil,
			["segs"] = v142,
			["tomoe"] = v144,
			["radius"] = p131,
			["axis"] = p134,
			["lean"] = p135,
			["turn"] = p136,
			["ride"] = p137
		}
	end
	local v_u_147 = {}
	local v_u_148 = {}
	local function v_u_192(p149, p150, p151, p152, p153) -- name: placeHoop
		-- upvalues: (copy) v_u_147, (copy) v_u_148, (ref) v_u_4, (copy) p_u_66
		table.clear(v_u_147)
		table.clear(v_u_148)
		local v154 = p149.radius * p151
		local v155 = #p149.segs
		for v156, v157 in p149.segs do
			local v158 = (v156 - 0.5) / v155 * 3.141592653589793 * 2
			local v159 = math.cos(v158) * v154
			local v160 = math.sin(v158) * v154
			local v161 = Vector3.new(v159, 0, v160)
			local v162 = -math.sin(v158)
			local v163 = math.cos(v158)
			local v164 = Vector3.new(v162, 0, v163)
			if p153 then
				local v165 = v154 * 2
				local v166 = 3.141592653589793 / v155
				local v167 = v165 * math.sin(v166) + p149.thick * 0.6
				local v168 = math.max(v167, 0.05)
				local v169 = p149.thick
				local v170 = p149.thick
				v157.Size = Vector3.new(v169, v170, v168)
			end
			local v171 = v_u_147
			table.insert(v171, v157)
			local v172 = v_u_148
			local v173 = p150 * CFrame.lookAt(v161, v161 + v164)
			table.insert(v172, v173)
		end
		local v174 = #p149.tomoe
		for v175, v176 in p149.tomoe do
			local v177 = p152 + (v175 - 1) / v174 * 3.141592653589793 * 2
			local v178 = math.cos(v177) * v154
			local v179 = math.sin(v177) * v154
			local v180 = p150 * Vector3.new(v178, 0, v179)
			if p153 then
				local v181 = math.min(p151, 1) * 1.7
				local v182 = math.max(v181, 0.03)
				local v183 = v182 * 2
				local v184 = v182 * 2
				v176.Size = Vector3.new(v183, 0.05, v184)
			end
			local v185 = v_u_147
			table.insert(v185, v176)
			local v186 = v_u_148
			local v187 = -v177 * 2
			local v188 = v_u_4.CurrentCamera
			local v189
			if v188 then
				local v190 = v188.CFrame.Position - v180
				v189 = v190.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v190.Unit
			else
				v189 = Vector3.new(0, 0, 1)
			end
			local v191 = p_u_66.facing(v180 + v189 * 0.3, v189) * CFrame.Angles(0, v187, 0)
			table.insert(v186, v191)
		end
		v_u_4:BulkMoveTo(v_u_147, v_u_148, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local function v_u_199(p193, p194, p195) -- name: hoopFrame
		local v196 = p195 / 0.32
		local v197 = math.clamp(v196, 0, 1) - 1
		local v198 = v197 * 2.7 * v197 * v197 + 1 + v197 * 1.7 * v197
		return CFrame.new(p193) * CFrame.Angles(0, p195 * 0.5, 0) * CFrame.fromAxisAngle(p194.axis, p194.lean * v198 + p194.turn * p195)
	end
	local function v_u_216(p200, p201) -- name: buildGyro
		-- upvalues: (copy) p_u_66, (copy) v_u_146, (ref) v_u_5, (ref) v_u_8, (ref) v_u_17, (ref) v_u_12, (ref) v_u_9, (ref) v_u_1
		local v202 = p_u_66.ground(p201, 0)
		local v203 = v202 + Vector3.new(0, 9, 0)
		local v204 = p200.lite
		local v205 = (p200.ability.freeze or 3) + 2
		local v206 = v204 and 1 or 3
		local v207 = { v_u_146(10.5, v204 and 9 or 16, v206, Vector3.new(1, 0, 0), 1.15, 1.6, 2.4, v205), v_u_146(9.2, v204 and 8 or 14, v206, Vector3.new(0, 0, 1), -1.1, -1.3, -2.8, v205), (v_u_146(7.9, v204 and 7 or 12, v206, Vector3.new(1, 0, 0), 0, 0, 3.2, v205)) }
		local v208 = {
			["shape"] = nil,
			["transparency"] = 0.2,
			["shape"] = v_u_17
		}
		local v209 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v203), v_u_8, v208)
		local v210 = {
			["shape"] = nil,
			["transparency"] = 0.65,
			["shape"] = v_u_17
		}
		local v211 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v203), v_u_12, v210)
		local v212 = {
			["shape"] = v_u_17
		}
		local v213 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v203), v_u_9, v212)
		for _, v214 in { v209, v211, v213 } do
			v_u_1:AddItem(v214, v205)
		end
		local v215 = Instance.new("Attachment")
		v215.Parent = v209
		return {
			["at"] = v203,
			["g"] = v202,
			["hoops"] = v207,
			["core"] = v209,
			["haze"] = v211,
			["pupil"] = v213,
			["anchor"] = v215
		}
	end
	local function v_u_241(p217, p_u_218) -- name: spinGyro
		-- upvalues: (ref) v_u_45, (copy) p_u_66, (copy) v_u_192, (copy) v_u_199
		local v_u_219 = p217.ability.freeze or 3
		local v_u_220 = os.clock()
		local v_u_221
		if p217.lite then
			v_u_221 = nil
		else
			v_u_221 = v_u_45(p_u_218.core, 2.4, 1)
			v_u_221.Rate = 12
			v_u_221.Enabled = true
		end
		local v_u_222 = nil
		p_u_66.runNow(function()
			-- upvalues: (copy) v_u_220, (copy) v_u_219, (ref) v_u_222, (ref) v_u_221, (copy) p_u_218, (ref) v_u_192, (ref) v_u_199
			local v223 = os.clock()
			local v224 = v223 - v_u_220
			local v225
			if v224 < 0.25 then
				local v226 = v224 / 0.25 - 1
				v225 = (v226 * 2.7 * v226 * v226 + 1 + v226 * 1.7 * v226) * 0.85 + 0.15
			else
				v225 = 1
			end
			if v_u_219 <= v224 and not v_u_222 then
				v_u_222 = v223
				local v227 = v_u_221
				if v227 then
					v227.Enabled = false
				end
			end
			local v228 = v_u_222
			if v228 then
				local v229 = (v223 - v228) / 0.25
				local v230 = math.clamp(v229, 0, 1)
				v225 = (1 - v230) ^ 2
				if v230 >= 1 then
					return false
				end
			end
			local v231 = v224 < 0.3 and true or v228 ~= nil
			for _, v232 in p_u_218.hoops do
				v_u_192(v232, v_u_199(p_u_218.at, v232, v224), math.max(v225, 0.02), v232.ride * v224, v231)
			end
			local v233 = v224 * 9
			local v234 = math.sin(v233) * 0.12 + 1
			local v235 = p_u_218.core
			local v236 = v225 * 2.6 * v234
			v235.Size = Vector3.new(1, 1, 1) * math.max(v236, 0.05)
			local v237 = p_u_218.haze
			local v238 = v225 * 4.8 * v234
			v237.Size = Vector3.new(1, 1, 1) * math.max(v238, 0.05)
			local v239 = p_u_218.pupil
			local v240 = v225 * 1.1
			v239.Size = Vector3.new(1, 1, 1) * math.max(v240, 0.05)
			return true
		end)
	end
	local function v_u_262(p242, p243) -- name: burstGyro
		-- upvalues: (copy) p_u_66, (ref) v_u_4, (ref) v_u_40, (ref) v_u_5, (ref) v_u_9, (ref) v_u_8, (ref) v_u_15, (ref) v_u_7, (ref) v_u_53, (ref) v_u_6
		local v_u_244 = p243.at
		for _, v245 in p243.hoops do
			for _, v246 in v245.segs do
				v246:Destroy()
			end
			for _, v_u_247 in v245.tomoe do
				local v248 = math.random() - 0.5
				local v249 = math.random() - 0.2
				local v250 = math.random() - 0.5
				local v251 = Vector3.new(v248, v249, v250)
				local v_u_252 = v251.Magnitude <= 0.05 and Vector3.new(0, 1, 0) or v251.Unit
				local v_u_253 = math.random() * 20 - 10
				v_u_247.Size = Vector3.new(3.4, 0.05, 3.4)
				p_u_66.animate(0.4, 0, function(p254)
					-- upvalues: (copy) v_u_244, (ref) v_u_252, (copy) v_u_247, (copy) v_u_253, (ref) v_u_4, (ref) p_u_66, (ref) v_u_40
					local v255 = v_u_244 + v_u_252 * 14 * (1 - (1 - p254) ^ 2)
					local v256 = v_u_247
					local v257 = p254 * v_u_253
					local v258 = v_u_4.CurrentCamera
					local v259
					if v258 then
						local v260 = v258.CFrame.Position - v255
						v259 = v260.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v260.Unit
					else
						v259 = Vector3.new(0, 0, 1)
					end
					v256.CFrame = p_u_66.facing(v255 + v259 * 0.3, v259) * CFrame.Angles(0, v257, 0)
					v_u_40(v_u_247, p254 ^ 2)
					if p254 >= 1 then
						v_u_247:Destroy()
					end
				end)
			end
		end
		for _, v261 in { p243.core, p243.haze, p243.pupil } do
			v261:Destroy()
		end
		v_u_5.flash(v_u_244, v_u_9, 10, 0.22)
		p_u_66.pop(v_u_244, v_u_8, 3, 14, 0.35, 0.4)
		v_u_5.ring(p243.g, v_u_15, p242.ability.radius, 0.35, v_u_7.Ring)
		if not p242.lite then
			v_u_53(v_u_244, 12, 3.2, 16, 0.9)
		end
		v_u_6.play("Burst", {
			["at"] = nil,
			["volume"] = 0.45,
			["at"] = v_u_244
		})
	end
	v67.nebula_rinne_e = {
		["cast"] = function(p263) -- name: cast
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (copy) v_u_95, (ref) v_u_7, (ref) v_u_9
			p_u_66.skillCast(p263, v_u_8)
			if not p263.lite then
				local v264 = p263.size
				v_u_95(p263.eye + p263.dir * 1.2, 0.6 * v264, 2.4 * v264, v_u_7.Ring, v_u_9, 0.25, 0)
			end
		end,
		["windup"] = function(p265, p266, p267) -- name: windup
			-- upvalues: (copy) p_u_66, (ref) v_u_5, (ref) v_u_15, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
			local v268 = p_u_66.ground(p266, 0)
			v_u_5.flash(v268 + Vector3.new(0, 9, 0), v_u_15, 6, math.max(p267, 0.12) + 0.1)
			p_u_66.mark(v268, v_u_8, p265.ability.radius * 0.7, p267 + 0.3, v_u_7.Glow, 0.4)
			if not p265.lite then
				p_u_66.inward(v268 + Vector3.new(0, 9, 0), v_u_9, 8, 14, (math.max(p267, 0.12)))
			end
		end,
		["land"] = function(p_u_269, p270) -- name: land
			-- upvalues: (copy) v_u_216, (copy) v_u_129, (copy) v_u_241, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (copy) p_u_66, (ref) v_u_8, (ref) v_u_36, (ref) v_u_15, (ref) v_u_1, (ref) v_u_53, (ref) v_u_6, (copy) v_u_262
			local v271 = p_u_269.ability.radius
			local v272 = p_u_269.ability.freeze or 3
			local v_u_273 = v_u_216(p_u_269, p270)
			v_u_129[p_u_269] = v_u_273
			v_u_241(p_u_269, v_u_273)
			local v274 = v_u_273.g
			v_u_5.flash(v_u_273.at, v_u_9, 9, 0.2)
			v_u_5.ring(v274, v_u_9, v271 * 1.1, 0.35, v_u_7.Shockwave)
			p_u_66.burst("Shockwave", v274 + Vector3.new(0, 0.3, 0), v_u_8, v271 / 18)
			p_u_66.mark(v274, v_u_8, v271 * 1.05, v272 + 0.3, v_u_7.Glow, 0.45)
			local v_u_275 = v_u_36(CFrame.new(v274 + Vector3.new(0, 0.3, 0)), v271, v_u_7.Ring, v_u_15, 0.15)
			v_u_1:AddItem(v_u_275, v272 + 0.6)
			p_u_66.after(v272, function()
				-- upvalues: (copy) v_u_275, (ref) v_u_5
				for _, v276 in v_u_275:GetChildren() do
					if not v276:IsA("Decal") then
						continue
					end
					v_u_5.tween(v276, 0.3, {
						["Transparency"] = 1
					})
				end
			end)
			if not p_u_269.lite then
				v_u_53(v_u_273.at, 8, 3, 10, 0.8)
			end
			v_u_6.play("Crit", {
				["at"] = nil,
				["volume"] = 0.55,
				["at"] = v274
			})
			if p_u_269.mine then
				v_u_5.shake(0.3, 0.25)
			end
			p_u_66.after(v272 + 0.26, function()
				-- upvalues: (ref) v_u_262, (copy) p_u_269, (copy) v_u_273, (ref) v_u_129
				v_u_262(p_u_269, v_u_273)
				v_u_129[p_u_269] = nil
			end)
		end,
		["hit"] = function(p277, p278, p279) -- name: hit
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (copy) v_u_130, (ref) v_u_36, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) v_u_11, (copy) v_u_129, (ref) v_u_5, (ref) v_u_15, (ref) v_u_4
			p_u_66.burst("Impact", p278, v_u_8, 0.6)
			local v280 = (v_u_130[p277] or 0) + 1
			v_u_130[p277] = v280
			local v_u_281 = p277.ability.freeze or 3
			local v_u_282 = p278 + Vector3.new(0, -0.5, 0)
			local v_u_283 = v_u_36(CFrame.new(v_u_282), 2.4, v_u_7.Ring, v_u_9, 0.1)
			v_u_1:AddItem(v_u_283, v_u_281 + 0.5)
			local v_u_284 = { v_u_283 }
			local v_u_285 = {}
			if not p277.lite and v280 <= 8 then
				for _ = 1, 3 do
					local v286 = v_u_36(CFrame.new(v_u_282), 0.75, v_u_7.NebulaTomoe, v_u_11, 0)
					v_u_1:AddItem(v286, v_u_281 + 0.5)
					table.insert(v_u_285, v286)
					table.insert(v_u_284, v286)
				end
				local v287 = v_u_129[p277]
				if v287 and v287.core.Parent then
					local v288 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p278), v_u_9, {
						["transparency"] = 1
					})
					v_u_1:AddItem(v288, v_u_281 + 0.5)
					table.insert(v_u_284, v288)
					local v289 = Instance.new("Attachment")
					v289.Parent = v288
					local v290 = Instance.new("Beam")
					v290.Attachment0 = v287.anchor
					v290.Attachment1 = v289
					v290.Texture = v_u_7.Beam
					v290.TextureMode = Enum.TextureMode.Wrap
					v290.TextureLength = 6
					v290.TextureSpeed = 2
					v290.Color = ColorSequence.new(v_u_15, v_u_9)
					v290.LightEmission = 0.8
					v290.LightInfluence = 0
					v290.FaceCamera = true
					v290.Width0 = 0.6
					v290.Width1 = 0.35
					v290.Segments = 1
					v290.Parent = v288
				end
			end
			local v291 = v_u_4:FindFirstChild("MyEnemies")
			local v_u_292
			if v291 then
				v_u_292 = v291:FindFirstChild("Foe" .. p279)
			else
				v_u_292 = nil
			end
			local v_u_293 = os.clock()
			p_u_66.runNow(function()
				-- upvalues: (copy) v_u_293, (copy) v_u_292, (copy) v_u_281, (ref) p_u_66, (copy) v_u_282, (ref) v_u_15, (copy) v_u_284, (copy) v_u_283, (copy) v_u_285, (ref) v_u_4
				local v294 = os.clock() - v_u_293
				local v295
				if v_u_292 == nil then
					v295 = false
				else
					v295 = v_u_292.Parent == nil
				end
				if v_u_281 <= v294 or v295 then
					if not v295 then
						p_u_66.pop(v_u_282, v_u_15, 1.5, 4.5, 0.2)
					end
					for _, v296 in v_u_284 do
						v296:Destroy()
					end
					return false
				else
					v_u_283.CFrame = CFrame.new(v_u_282) * CFrame.Angles(0, v294 * 3, 0)
					for v297, v298 in v_u_285 do
						local v299 = v294 * 4 + (v297 - 1) / 3 * 3.141592653589793 * 2
						local v300 = v_u_282
						local v301 = math.cos(v299) * 2.4
						local v302 = math.sin(v299) * 2.4
						local v303 = v300 + Vector3.new(v301, 0.2, v302)
						local v304 = -v299 * 2
						local v305 = v_u_4.CurrentCamera
						local v306
						if v305 then
							local v307 = v305.CFrame.Position - v303
							v306 = v307.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v307.Unit
						else
							v306 = Vector3.new(0, 0, 1)
						end
						v298.CFrame = p_u_66.facing(v303 + v306 * 0.3, v306) * CFrame.Angles(0, v304, 0)
					end
					return true
				end
			end)
		end
	}
	local v_u_308 = {}
	setmetatable(v_u_308, {
		["__mode"] = "k"
	})
	local function v_u_322(p309, p310, p311) -- name: gather
		-- upvalues: (copy) p_u_66, (ref) v_u_5, (ref) v_u_8, (ref) v_u_17, (ref) v_u_9, (ref) v_u_1, (ref) v_u_12, (ref) v_u_13
		local v_u_312 = p309.ability.radius
		local v313 = p_u_66.ground(p310, 0) + Vector3.new(0, 7, 0)
		local v314 = math.max(p311, 0.12)
		local v315 = {
			["shape"] = nil,
			["transparency"] = 0.85,
			["shape"] = v_u_17
		}
		local v_u_316 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_312 * 2.4, CFrame.new(v313), v_u_8, v315)
		local v317 = {
			["shape"] = v_u_17
		}
		local v_u_318 = v_u_5.part(Vector3.new(0.3, 0.3, 0.3), CFrame.new(v313), v_u_9, v317)
		v_u_1:AddItem(v_u_316, v314 + 0.5)
		v_u_1:AddItem(v_u_318, v314 + 0.5)
		p_u_66.animate(v314, 0, function(p319)
			-- upvalues: (copy) v_u_316, (copy) v_u_312, (copy) v_u_318
			if v_u_316.Parent then
				local v320 = v_u_316
				local v321 = v_u_312 * 2.4 * (1 - p319 * p319)
				v320.Size = Vector3.new(1, 1, 1) * math.max(v321, 0.5)
				v_u_316.Transparency = 0.85 - 0.45 * p319
				v_u_318.Size = Vector3.new(1, 1, 1) * (0.3 + 1.6 * p319)
			end
		end)
		p_u_66.inward(v313, v_u_12, p309.lite and 4 or 8, v_u_312 * 0.9, v314)
		if not p309.lite then
			p_u_66.inward(v313, v_u_13, 6, v_u_312 * 0.7, v314)
			p_u_66.inward(v313, v_u_9, 6, v_u_312 * 0.5, v314)
		end
		p_u_66.glint(v313, v_u_9, 6, v314 + 0.05)
		return {
			["shell"] = v_u_316,
			["point"] = v_u_318
		}
	end
	local function v_u_339(p_u_323, p324, p325) -- name: cloud
		-- upvalues: (ref) v_u_5, (ref) v_u_17, (ref) v_u_1, (copy) p_u_66
		local v326 = math.random() - 0.5
		local v327 = (math.random() - 0.35) * 0.7
		local v328 = math.random() - 0.5
		local v329 = Vector3.new(v326, v327, v328)
		local v_u_330 = v329.Magnitude <= 0.05 and Vector3.new(1, 0, 0) or v329.Unit
		local v_u_331 = p324 * (0.65 + math.random() * 0.5)
		local v_u_332 = 2 + math.random() * 1.5
		local v_u_333 = 6 + math.random() * 4
		local v334 = 0.8 + math.random() * 0.35
		local v335 = {
			["shape"] = nil,
			["transparency"] = 0.62,
			["shape"] = v_u_17
		}
		local v_u_336 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_332, CFrame.new(p_u_323), p325, v335)
		v_u_1:AddItem(v_u_336, v334 + 0.1)
		p_u_66.animate(v334, 0, function(p337)
			-- upvalues: (copy) v_u_336, (copy) p_u_323, (ref) v_u_330, (copy) v_u_331, (copy) v_u_332, (copy) v_u_333
			local v338 = 1 - (1 - p337) ^ 3
			v_u_336.CFrame = CFrame.new(p_u_323 + v_u_330 * v_u_331 * v338 + Vector3.new(0, 2, 0) * p337)
			v_u_336.Size = Vector3.new(1, 1, 1) * (v_u_332 + (v_u_333 - v_u_332) * v338)
			v_u_336.Transparency = 0.62 + 0.38 * p337 ^ 1.5
			if p337 >= 1 then
				v_u_336:Destroy()
			end
		end)
	end
	local function v_u_374(p340, p341, p_u_342, p_u_343, p_u_344) -- name: hoopOut
		-- upvalues: (copy) p_u_66, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (ref) v_u_40, (ref) v_u_4
		local v_u_345 = p_u_66.facing(p340, p341)
		local v_u_346 = v_u_36(v_u_345, 1, v_u_7.Ring, v_u_11, 0)
		v_u_1:AddItem(v_u_346, 0.7999999999999999)
		local v_u_347 = {}
		for _ = 1, p_u_343 do
			local v348 = v_u_36(CFrame.new(p340), 1.8, v_u_7.NebulaTomoe, v_u_11, 0)
			v_u_1:AddItem(v348, 0.7999999999999999)
			table.insert(v_u_347, v348)
		end
		p_u_66.animate(0.7, 0, function(p349)
			-- upvalues: (copy) p_u_342, (copy) v_u_346, (copy) v_u_345, (ref) v_u_40, (copy) v_u_347, (copy) p_u_344, (copy) p_u_343, (ref) v_u_4, (ref) p_u_66
			local v350 = 1 - (1 - p349) ^ 2.5
			local v351 = 1 + (p_u_342 * 1.1 - 1) * v350
			local v352 = (p349 - 0.55) / 0.45
			local v353 = math.clamp(v352, 0, 1)
			local v354 = v_u_346
			local v355 = math.max(v351, 0.03)
			local v356 = v355 * 2
			local v357 = v355 * 2
			v354.Size = Vector3.new(v356, 0.05, v357)
			v_u_346.CFrame = v_u_345 * CFrame.Angles(0, p349 * 1.5, 0)
			v_u_40(v_u_346, v353)
			for v358, v359 in v_u_347 do
				local v360 = p_u_344 + p349 * 2.5 + (v358 - 1) / p_u_343 * 3.141592653589793 * 2
				local v361 = v_u_345
				local v362 = math.cos(v360) * v351
				local v363 = math.sin(v360) * v351
				local v364 = v361 * Vector3.new(v362, 0, v363)
				local v365 = -v360 * 2
				local v366 = v_u_4.CurrentCamera
				local v367
				if v366 then
					local v368 = v366.CFrame.Position - v364
					v367 = v368.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v368.Unit
				else
					v367 = Vector3.new(0, 0, 1)
				end
				v359.CFrame = p_u_66.facing(v364 + v367 * 0.3, v367) * CFrame.Angles(0, v365, 0)
				local v369 = 1.8 + 1.4 * v350
				local v370 = math.max(v369, 0.03)
				local v371 = v370 * 2
				local v372 = v370 * 2
				v359.Size = Vector3.new(v371, 0.05, v372)
				v_u_40(v359, v353)
			end
			if p349 >= 1 then
				v_u_346:Destroy()
				for _, v373 in v_u_347 do
					v373:Destroy()
				end
			end
		end)
	end
	local function v_u_406(p_u_375, p376, p377) -- name: galaxy
		-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_1, (copy) p_u_66, (ref) v_u_4, (ref) v_u_40
		local v378 = math.random() * 3.141592653589793 * 2
		local v379 = math.cos(v378)
		local v380 = math.sin(v378)
		local v_u_381 = Vector3.new(v379, 0, v380)
		local v_u_382 = p376 * (0.75 + math.random() * 0.45)
		local v_u_383 = 3 + math.random() * 6
		local v_u_384 = 3.6 + math.random() * 2
		local v_u_385 = (math.random() < 0.5 and -1 or 1) * (4 + math.random() * 3)
		local v_u_386 = v_u_36(CFrame.new(p_u_375), 1, v_u_7.NebulaGalaxy, p377, 0)
		v_u_1:AddItem(v_u_386, 1.05)
		p_u_66.animate(0.95, 0, function(p387)
			-- upvalues: (copy) p_u_375, (copy) v_u_381, (copy) v_u_382, (copy) v_u_383, (copy) v_u_386, (copy) v_u_385, (ref) v_u_4, (ref) p_u_66, (copy) v_u_384, (ref) v_u_40
			local v388 = 1 - (1 - p387) ^ 2
			local v389 = p_u_375 + v_u_381 * v_u_382 * v388
			local v390 = Vector3.new(0, 1, 0) * v_u_383
			local v391 = p387 * 3.141592653589793 * 0.8
			local v392 = v389 + v390 * math.sin(v391)
			local v393 = v_u_386
			local v394 = p387 * v_u_385
			local v395 = v_u_4.CurrentCamera
			local v396
			if v395 then
				local v397 = v395.CFrame.Position - v392
				v396 = v397.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v397.Unit
			else
				v396 = Vector3.new(0, 0, 1)
			end
			v393.CFrame = p_u_66.facing(v392 + v396 * 0.3, v396) * CFrame.Angles(0, v394, 0)
			local v398 = v_u_386
			local v399 = 1 + (v_u_384 - 1) * v388
			local v400 = math.max(v399, 0.03)
			local v401 = v400 * 2
			local v402 = v400 * 2
			v398.Size = Vector3.new(v401, 0.05, v402)
			local v403 = v_u_40
			local v404 = v_u_386
			local v405 = (p387 - 0.6) / 0.4
			v403(v404, (math.clamp(v405, 0, 1)))
			if p387 >= 1 then
				v_u_386:Destroy()
			end
		end)
	end
	local function v_u_423(p407, p408) -- name: bang
		-- upvalues: (copy) p_u_66, (ref) v_u_5, (ref) v_u_9, (ref) v_u_8, (ref) v_u_12, (copy) v_u_339, (ref) v_u_16, (ref) v_u_53, (ref) v_u_60, (ref) v_u_4, (copy) v_u_374, (ref) v_u_13, (ref) v_u_15, (copy) v_u_406, (ref) v_u_7, (ref) v_u_14, (ref) v_u_6
		local v409 = p407.ability.radius
		local v410 = p_u_66.ground(p408, 0)
		local v411 = v410 + Vector3.new(0, 7, 0)
		local v412 = p407.lite
		v_u_5.flash(v411, v_u_9, v409 * 1.6, 0.3)
		p_u_66.burst("Flash", v411, v_u_9, 1.2, true)
		p_u_66.pop(v411, v_u_9, 2, v409 * 0.9, 0.3)
		p_u_66.pop(v411, v_u_8, v409 * 0.4, v409 * 2.3, 0.75, 0.55)
		p_u_66.pop(v411, v_u_12, v409 * 0.3, v409 * 1.7, 0.6, 0.62)
		for v413 = 1, v412 and 4 or 9 do
			v_u_339(v411, v409, v_u_16[(v413 - 1) % #v_u_16 + 1])
		end
		if not v412 then
			v_u_53(v411, 30, 7, v409 * 2, 1.4)
			v_u_60(v411, 24, 1.3, v409 * 2.4)
		end
		local v414 = p_u_66.flatUnit
		local v415 = v_u_4.CurrentCamera
		local v416
		if v415 then
			local v417 = v415.CFrame.Position - v411
			v416 = v417.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v417.Unit
		else
			v416 = Vector3.new(0, 0, 1)
		end
		local v418 = v414(v416):Cross(Vector3.new(0, 1, 0))
		for v419, v420 in { Vector3.new(0, 1, 0), (Vector3.new(0, 1, 0) + v418 * 0.85).Unit, (Vector3.new(0, 1, 0) - v418 * 0.85).Unit } do
			v_u_374(v411, v420, v409 * (0.8 + 0.12 * v419), v412 and 1 or 3, v419 * 2)
		end
		local v421 = {
			v_u_12,
			v_u_13,
			v_u_15,
			v_u_8,
			v_u_9,
			v_u_12
		}
		for v422 = 1, v412 and 2 or 6 do
			v_u_406(v411, v409, v421[v422])
		end
		p_u_66.spikes(v411, v_u_9, v412 and 8 or 18, v409 * 1.2, 0.4)
		v_u_5.ring(v410, v_u_12, v409 * 1.3, 0.6, v_u_7.Shockwave)
		v_u_5.ring(v410, v_u_9, v409 * 1.1, 0.4, v_u_7.Ring)
		p_u_66.burst("Shockwave", v410 + Vector3.new(0, 0.3, 0), v_u_8, v409 / 13)
		p_u_66.chunks(v410 + Vector3.new(0, 1, 0), { v_u_14, v_u_8, v_u_12 }, v412 and 6 or 14, 50, 1.1, 1.2, true, 0.9)
		p_u_66.mark(v410, v_u_8, v409, 1.4, v_u_7.Glow, 0.3)
		v_u_6.play("Explosion", {
			["at"] = v411,
			["volume"] = p407.mine and 1 or 0.6
		})
		if p407.mine then
			v_u_5.shake(0.6, 0.55)
		end
	end
	v67.nebula_rinne_r = {
		["cast"] = function(p424) -- name: cast
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (copy) v_u_95, (ref) v_u_9, (ref) v_u_7, (ref) v_u_11, (ref) v_u_5
			p_u_66.skillCast(p424, v_u_8, true)
			local v425 = p424.size
			local v426 = p424.eye + p424.dir * 1.4
			v_u_95(v426, 1 * v425, 3.4 * v425, p_u_66.iris("nebula_rinne"), v_u_9, 0.4, 6)
			if not p424.lite then
				v_u_95(v426, 0.8 * v425, 3.3 * v425, v_u_7.Ring, v_u_11, 0.28, 0)
				v_u_95(v426, 0.8 * v425, 4.6 * v425, v_u_7.Ring, v_u_11, 0.36, 0)
				v_u_95(v426, 0.8 * v425, 5.9 * v425, v_u_7.Ring, v_u_11, 0.44, 0)
			end
			if p424.mine then
				v_u_5.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p427, p428, p429) -- name: windup
			-- upvalues: (copy) v_u_308, (copy) v_u_322, (ref) v_u_65
			v_u_308[p427] = v_u_322(p427, p428, p429)
			if p427.mine then
				v_u_65((math.max(p429, 0.12)))
			end
		end,
		["land"] = function(p430, p431) -- name: land
			-- upvalues: (copy) v_u_308, (copy) v_u_423
			local v432 = v_u_308[p430]
			v_u_308[p430] = nil
			if v432 then
				v432.shell:Destroy()
				v432.point:Destroy()
			end
			v_u_423(p430, p431)
		end,
		["hit"] = function(p433, p434, _) -- name: hit
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_9
			p_u_66.burst("Impact", p434, v_u_8, 1)
			if not p433.lite then
				p_u_66.glint(p434, v_u_9, 3.5, 0.15)
			end
		end
	}
	return v67
end