local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return {
		["w3_crimson_bloom"] = function(p_u_5, p6)
			-- upvalues: (copy) p_u_4, (ref) v_u_2, (ref) v_u_3
			local v_u_7 = Color3.fromHex(p6.color)
			local v_u_8 = p_u_4.rgb(255, 80, 90)
			local v9 = p_u_4.rgb(18, 4, 7)
			local v_u_10 = p_u_4.rgb(70, 6, 14)
			local v_u_11 = p_u_5.fx <= 1 and 1 or p_u_5.fx / 1.35
			local v_u_12 = -10
			local v_u_13 = 0
			local v_u_18 = p_u_4.throb(p_u_5, 3.2, 1, 2, function(p14)
				-- upvalues: (ref) v_u_2, (ref) p_u_4, (copy) p_u_5, (copy) v_u_7, (ref) v_u_3, (copy) v_u_11
				v_u_2.ring(p_u_4.feetAt(p_u_5, p14, 0.15), v_u_7, 6 * p_u_5.fx, 0.5, v_u_3.Ring)
				local v15 = v_u_2.flash
				local v16 = p14.Position
				local v17 = p_u_5.headY - 0.5 * v_u_11
				v15(v16 + Vector3.new(0, v17, 0), v_u_7, 4 * v_u_11, 0.3)
			end)
			local v_u_19 = 0
			local v20 = p_u_5.ticks
			local function v23(_, p21)
				-- upvalues: (ref) v_u_13, (copy) v_u_18, (ref) v_u_19, (ref) v_u_12
				v_u_13 = p21
				local v22 = v_u_18()
				if v_u_19 + 0.3 < v22 then
					v_u_12 = p21
				end
				v_u_19 = v22
			end
			table.insert(v20, v23)
			local v_u_26 = p_u_4.group(p_u_5, function(p24, p25)
				-- upvalues: (copy) p_u_5, (copy) v_u_11
				return p24 * CFrame.new(0, p_u_5.headY - 0.62 * v_u_11, 0) * CFrame.Angles(0, p25 * 0.12, 0)
			end)
			local v_u_27 = {}
			local function v50(p28, p29, p_u_30, p_u_31, p_u_32, p_u_33, p34, p35, p36) -- name: petals
				-- upvalues: (ref) p_u_4, (copy) v_u_11, (copy) v_u_27, (copy) p_u_5, (copy) v_u_18, (copy) v_u_26
				for v_u_37 = 1, p28 do
					local v38 = (v_u_37 - 1 + p29) / p28 * 3.141592653589793 * 2
					local v39 = math.cos(v38)
					local v40 = math.sin(v38)
					local v_u_41 = Vector3.new(v39, 0, v40)
					local v42 = p_u_4.blob(p_u_31 * v_u_11, p34, 0, p35)
					if p35 then
						v42.Reflectance = 0.02
					end
					if p36 then
						local v43 = v_u_27
						table.insert(v43, v42)
					end
					p_u_4.add(p_u_5, v42, function(_, p44)
						-- upvalues: (copy) p_u_32, (copy) p_u_33, (ref) v_u_18, (copy) v_u_37, (copy) v_u_41, (copy) p_u_30, (ref) v_u_11, (copy) p_u_31, (ref) v_u_26
						local v45 = p_u_32 - p_u_33 * v_u_18()
						local v46 = p44 * 1.6 + v_u_37
						local v47 = v45 + math.sin(v46) * 0.03
						local v48 = v_u_41 * math.cos(v47) + Vector3.new(0, 1, 0) * math.sin(v47)
						local v49 = v_u_41 * p_u_30 * v_u_11 + v48 * p_u_31.Z * v_u_11 * 0.5
						return v_u_26.cf * CFrame.lookAt(v49, v49 + v48, (Vector3.new(0, 1, 0)):Lerp(-v_u_41, 0.3))
					end)
				end
			end
			v50(8, 0, 1.05, Vector3.new(1.25, 0.16, 2.35), 0.5, 0.22, v9, Enum.Material.SmoothPlastic, false)
			v50(8, 0.5, 0.85, Vector3.new(0.95, 0.14, 1.65), 0.78, 0.25, v_u_7, nil, true)
			local v_u_51 = -1
			local v52 = p_u_5.ticks
			local function v56()
				-- upvalues: (copy) v_u_18, (ref) v_u_51, (copy) v_u_7, (copy) v_u_8, (copy) v_u_27
				local v53 = v_u_18()
				if v53 ~= v_u_51 then
					v_u_51 = v53
					local v54 = v_u_7:Lerp(v_u_8, v53)
					for _, v55 in v_u_27 do
						v55.Color = v54
					end
				end
			end
			table.insert(v52, v56)
			local v_u_57 = v_u_12
			local v_u_58 = v_u_13
			for v59 = 1, 5 do
				local v60 = (v59 - 1 + math.random() * 0.5) / 5 * 3.141592653589793 * 2
				local v61 = (math.random() - 0.5) * 1.2
				local v62 = (3 + math.random() * 0.8) * v_u_11
				local v63 = {}
				for v64 = 0, 3 do
					local v65 = v64 / 3
					local v66 = v60 + v61 * v65 * v65
					local v67 = 0.35 * v_u_11 + v62 * v65
					local v68 = math.cos(v66) * v67
					local v69 = math.sin(v66) * v67
					local v70 = Vector3.new(v68, 0, v69)
					table.insert(v63, v70)
				end
				for v_u_71 = 1, 3 do
					local v72 = (0.6 - v_u_71 * 0.13) * v_u_11
					local v_u_73, v74 = p_u_4.between(v63[v_u_71], v63[v_u_71 + 1])
					local v75 = p_u_4.bar
					local v76 = v72 * 0.6
					local v77 = v74 + v72 * 0.5
					local v_u_78 = v75(Vector3.new(v72, v76, v77), v_u_10, 0, Enum.Material.Neon)
					p_u_4.add(p_u_5, v_u_78, function(p79)
						-- upvalues: (ref) p_u_4, (copy) p_u_5, (copy) v_u_73
						return CFrame.new(p_u_4.feetAt(p_u_5, p79, 0.12)) * p79.Rotation * v_u_73
					end)
					local v_u_80 = 0
					local v81 = p_u_5.ticks
					local function v84()
						-- upvalues: (ref) v_u_58, (ref) v_u_57, (copy) v_u_71, (ref) v_u_80, (copy) v_u_78, (copy) v_u_10, (copy) v_u_8
						local v82 = v_u_58 - v_u_57 - (v_u_71 - 1) * 0.09
						local v83 = (v82 < 0 or v82 >= 0.22) and 0 or 1 - v82 / 0.22
						if v83 ~= v_u_80 then
							v_u_80 = v83
							v_u_78.Color = v_u_10:Lerp(v_u_8, v83)
						end
					end
					table.insert(v81, v84)
				end
			end
			p_u_4.particles(p_u_5, "Petals", v_u_7, {
				["rate"] = 0.8,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Petals", "Motes" }
			})
			p_u_4.particles(p_u_5, "AuraMode", v_u_7, {
				["rate"] = 0.4,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "FlameBack" }
			})
		end
	}
end