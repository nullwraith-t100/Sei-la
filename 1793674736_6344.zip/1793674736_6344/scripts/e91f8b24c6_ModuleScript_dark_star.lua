local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = require(v3.Shared.Config.Boss)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = {
	["violet"] = Color3.fromHex("9B4DFF"),
	["pale"] = Color3.fromHex("F0E0FF")
}
local v11 = Color3.fromRGB(240, 230, 255)
v_u_10.starlight = Color3.new(v11.R * 2.4, v11.G * 2.4, v11.B * 2.4)
v_u_10.orchid = Color3.fromRGB(205, 125, 255)
v_u_10.deep = Color3.fromRGB(74, 22, 170)
v_u_10.tar = Color3.fromRGB(16, 8, 30)
v_u_10.void = Color3.fromRGB(3, 1, 8)
v_u_10.rock = Color3.fromRGB(78, 66, 102)
v_u_10.dim = Color3.fromRGB(214, 196, 255)
local v_u_12 = {
	["violet"] = Color3.fromHex("FFA21F"),
	["pale"] = Color3.fromHex("FFF0C8")
}
local v13 = Color3.fromRGB(255, 240, 205)
v_u_12.starlight = Color3.new(v13.R * 2.4, v13.G * 2.4, v13.B * 2.4)
v_u_12.orchid = Color3.fromRGB(255, 190, 90)
v_u_12.deep = Color3.fromRGB(176, 18, 34)
v_u_12.tar = Color3.fromRGB(34, 6, 8)
v_u_12.void = Color3.fromRGB(10, 1, 2)
v_u_12.rock = Color3.fromRGB(104, 70, 60)
v_u_12.dim = Color3.fromRGB(255, 222, 190)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.PartType.Wedge
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = Enum.Material.Neon
local function v_u_36(p18, p19, p20, p21, p22) -- name: picture
	-- upvalues: (copy) v_u_5
	local v23 = Color3.new
	local v24 = p21.R
	local v25 = math.min(v24, 1)
	local v26 = p21.G
	local v27 = math.min(v26, 1)
	local v28 = p21.B
	local v29 = v23(v25, v27, (math.min(v28, 1)))
	local v30 = v_u_5.part
	local v31 = p19 * 2
	local v32 = p19 * 2
	local v33 = v30(Vector3.new(v31, 0.05, v32), p18, v29, {
		["transparency"] = 1
	})
	for _, v34 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v35 = Instance.new("Decal")
		v35.Face = v34
		v35.Texture = p20
		v35.Color3 = p21
		v35.Transparency = p22
		v35.Parent = v33
	end
	return v33
end
local function v_u_40(p37, p38) -- name: setAlpha
	for _, v39 in p37:GetChildren() do
		if not v39:IsA("Decal") then
			continue
		end
		v39.Transparency = p38
	end
end
local function v_u_48(p41, p42, p43, p44, p45) -- name: blob
	-- upvalues: (copy) v_u_5
	local v46 = v_u_5.part(p41, p42, p43, {
		["material"] = p44,
		["transparency"] = p45
	})
	local v47 = Instance.new("SpecialMesh")
	v47.MeshType = Enum.MeshType.Sphere
	v47.Parent = v46
	return v46
end
local v_u_49 = {}
local v_u_50 = {}
local function v_u_58(p51, p52) -- name: placeBits
	-- upvalues: (copy) v_u_49, (copy) v_u_50, (copy) v_u_4
	table.clear(v_u_49)
	table.clear(v_u_50)
	for _, v53 in p51 do
		if not v53.p.Parent then
			continue
		end
		local v54 = v_u_49
		local v55 = v53.p
		table.insert(v54, v55)
		local v56 = v_u_50
		local v57 = p52 * v53.off
		table.insert(v56, v57)
	end
	if #v_u_49 > 0 then
		v_u_4:BulkMoveTo(v_u_49, v_u_50, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_74(p59, p60, p61, p62, p63, p64, p65, p66) -- name: triangle
	-- upvalues: (copy) v_u_5, (copy) v_u_15, (copy) v_u_1
	for _, v67 in { -1, 1 } do
		local v68 = v_u_5.part
		local v69 = p61 / 2
		local v70 = Vector3.new(p63, p62, v69)
		local v71 = {
			["shape"] = v_u_15,
			["transparency"] = p65
		}
		local v72 = v68(v70, CFrame.identity, p64, v71)
		v_u_1:AddItem(v72, p66)
		local v73 = {
			["p"] = v72,
			["off"] = p60 * CFrame.new(v67 * p61 / 4, p62 / 2, 0) * CFrame.Angles(0, -v67 * 3.141592653589793 / 2, 0)
		}
		table.insert(p59, v73)
	end
end
local function v_u_83(p75, p76, p77, p78, p79, p80, p81, p82) -- name: shardBits
	-- upvalues: (copy) v_u_74
	v_u_74(p75, CFrame.identity, p76, p77, p79, p80, p81, p82)
	v_u_74(p75, CFrame.Angles(0, 0, 3.141592653589793), p76, p78, p79, p80, p81, p82)
end
local v_u_84 = 0
local function v_u_89(p85, p86) -- name: dimWorld
	-- upvalues: (ref) v_u_84, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_1
	if os.clock() >= v_u_84 then
		local v_u_87 = Instance.new("ColorCorrectionEffect")
		v_u_87.Name = "DarkStarDim"
		v_u_87.Parent = v_u_2
		v_u_5.tween(v_u_87, 0.3, {
			["TintColor"] = nil,
			["Brightness"] = -0.1,
			["Contrast"] = 0.12,
			["Saturation"] = -0.15,
			["TintColor"] = p86
		})
		task.delay(p85 + 0.3, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_87, (ref) v_u_9
			local v88 = {
				["TintColor"] = nil,
				["Brightness"] = 0,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = v_u_9
			}
			v_u_5.tween(v_u_87, 0.35, v88)
		end)
		v_u_1:AddItem(v_u_87, p85 + 0.75)
		v_u_84 = os.clock() + p85 + 0.75
	end
end
local function v_u_510(p_u_90, p_u_91) -- name: build
	-- upvalues: (copy) v_u_4, (copy) v_u_36, (copy) v_u_7, (copy) v_u_1, (copy) v_u_40, (copy) v_u_48, (copy) v_u_9, (copy) v_u_5, (copy) v_u_83, (copy) v_u_58, (copy) v_u_6, (copy) v_u_14, (copy) v_u_16, (copy) v_u_17, (copy) v_u_89
	local v_u_92 = p_u_91.violet
	local v_u_93 = p_u_91.pale
	local v_u_94 = p_u_91.starlight
	local v_u_95 = p_u_91.orchid
	local v_u_96 = p_u_91.deep
	local v_u_97 = p_u_91.tar
	local v_u_98 = p_u_91.void
	local v_u_99 = p_u_91.rock
	local v100 = {}
	local function v_u_121(p101, p_u_102, p_u_103, p104, p105, p106, p107) -- name: starFlash
		-- upvalues: (ref) v_u_4, (copy) p_u_90, (ref) v_u_36, (ref) v_u_7, (ref) v_u_1, (ref) v_u_40
		local v108 = v_u_4.CurrentCamera
		local v109
		if v108 then
			local v110 = v108.CFrame.Position - p101
			v109 = v110.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v110.Unit
		else
			v109 = Vector3.new(0, 0, 1)
		end
		local v111 = p_u_90.facing(p101 + v109 * 0.6, v109) * CFrame.Angles(0, p106 or 0, 0)
		local v_u_112 = p107 or 0
		local v_u_113 = v_u_36(v111, p_u_102, v_u_7.DarkStar, p104, v_u_112)
		v_u_1:AddItem(v_u_113, p105 + 0.1)
		p_u_90.animate(p105, 0, function(p114)
			-- upvalues: (copy) v_u_113, (copy) p_u_102, (copy) p_u_103, (ref) v_u_40, (copy) v_u_112
			local v115 = 1 - (1 - p114) ^ 3
			local v116 = v_u_113
			local v117 = p_u_102 + (p_u_103 - p_u_102) * v115
			local v118 = math.max(v117, 0.03)
			local v119 = v118 * 2
			local v120 = v118 * 2
			v116.Size = Vector3.new(v119, 0.05, v120)
			v_u_40(v_u_113, v_u_112 + (1 - v_u_112) * p114 ^ 1.6)
			if p114 >= 1 then
				v_u_113:Destroy()
			end
		end)
	end
	local function v_u_143(p122, p_u_123, p124) -- name: slit
		-- upvalues: (ref) v_u_4, (copy) p_u_90, (ref) v_u_48, (copy) v_u_95, (ref) v_u_9, (ref) v_u_1
		local v125 = v_u_4.CurrentCamera
		local v126
		if v125 then
			local v127 = v125.CFrame.Position - p122
			v126 = v127.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v127.Unit
		else
			v126 = Vector3.new(0, 0, 1)
		end
		local v128 = p_u_90.aimAt(p122 + v126 * 0.8, v126)
		local v_u_129 = v_u_48(Vector3.new(0.1, 0.1, 0.1), v128, v_u_95, nil, 0.1)
		local v_u_130 = v_u_48(Vector3.new(0.1, 0.1, 0.1), v128 * CFrame.new(0, 0, -0.05), v_u_9)
		v_u_1:AddItem(v_u_129, p124 + 0.1)
		v_u_1:AddItem(v_u_130, p124 + 0.1)
		p_u_90.animate(p124, 0, function(p131)
			-- upvalues: (copy) p_u_123, (copy) v_u_129, (copy) v_u_130
			local v132 = p131 / 0.85
			local v133 = math.min(v132, 1) * 3.141592653589793
			local v134 = math.sin(v133)
			local v135 = p_u_123 * (v134 * 0.45 + 0.55)
			local v136 = v_u_129
			local v137 = p_u_123 * 0.22 * v134
			local v138 = math.max(v137, 0.05)
			v136.Size = Vector3.new(v138, v135, 0.1)
			local v139 = v_u_130
			local v140 = p_u_123 * 0.07 * v134
			local v141 = math.max(v140, 0.03)
			local v142 = v135 * 0.82
			v139.Size = Vector3.new(v141, v142, 0.12)
			v_u_129.Transparency = 0.1 + 0.9 * p131 ^ 3
			v_u_130.Transparency = p131 ^ 3
			if p131 >= 1 then
				v_u_129:Destroy()
				v_u_130:Destroy()
			end
		end)
	end
	local function v_u_147(p144, p145) -- name: sparkles
		-- upvalues: (copy) v_u_93, (copy) v_u_92
		local v146 = Instance.new("ParticleEmitter")
		v146.Texture = "rbxassetid://76741008972969"
		v146.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v146.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v146.Color = ColorSequence.new(v_u_93, v_u_92)
		v146.LightEmission = 0.7
		v146.LightInfluence = 0
		v146.Lifetime = NumberRange.new(0.25, 0.4)
		v146.Size = NumberSequence.new(p145, 0)
		v146.Speed = NumberRange.new(0.5, 2.5)
		v146.SpreadAngle = Vector2.new(180, 180)
		v146.Rotation = NumberRange.new(0, 360)
		v146.Rate = 26
		v146.Parent = p144
		return v146
	end
	v100.dark_star_a = {
		["cast"] = function(p148) -- name: cast
			-- upvalues: (ref) v_u_5, (copy) v_u_92, (copy) p_u_90, (ref) v_u_9, (copy) v_u_121, (copy) v_u_94
			local v149 = p148.size
			local v150 = p148.eye + p148.dir * 1.2
			v_u_5.flash(v150, v_u_92, 3 * v149, 0.12)
			p_u_90.pop(v150, v_u_9, 1.2 * v149, 0.3 * v149, 0.1)
			if not p148.lite then
				v_u_121(v150, 0.6 * v149, 2 * v149, v_u_94, 0.14)
			end
		end,
		["shot"] = function(p151, p152) -- name: shardShot
			-- upvalues: (ref) v_u_5, (copy) v_u_92, (ref) v_u_1, (ref) v_u_83, (copy) v_u_95, (ref) v_u_48, (ref) v_u_9, (ref) v_u_36, (ref) v_u_7, (copy) v_u_94, (copy) p_u_90, (copy) v_u_96, (copy) v_u_147, (ref) v_u_58, (ref) v_u_4
			local v_u_153 = p151.size
			local v_u_154 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p152, v_u_92, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_154, 3)
			local v_u_155 = {}
			v_u_83(v_u_155, 0.8 * v_u_153, 1.9 * v_u_153, 0.9 * v_u_153, 0.14 * v_u_153, v_u_95, 0.15, 3)
			local v156 = v_u_48(Vector3.new(0.24, 2.3, 0.24) * v_u_153, p152, v_u_9)
			v_u_1:AddItem(v156, 3)
			local v157 = {
				["p"] = v156,
				["off"] = CFrame.new(0, 0.45 * v_u_153, 0)
			}
			table.insert(v_u_155, v157)
			local v_u_158
			if p151.lite then
				v_u_158 = nil
			else
				v_u_158 = v_u_48(Vector3.new(1.25, 3.6, 1.25) * v_u_153, p152, v_u_92, nil, 0.64)
				v_u_1:AddItem(v_u_158, 3)
				local v159 = {
					["p"] = v_u_158,
					["off"] = CFrame.new(0, 0.4 * v_u_153, 0)
				}
				table.insert(v_u_155, v159)
			end
			local v_u_160 = v_u_36(p152, 1.2 * v_u_153, v_u_7.DarkStar, v_u_94, 0)
			v_u_1:AddItem(v_u_160, 3)
			p_u_90.streak(v_u_154, v_u_95, v_u_96, 0.9 * v_u_153, p151.lite and 0.1 or 0.2)
			local v_u_161
			if p151.lite then
				v_u_161 = nil
			else
				v_u_161 = v_u_147(v_u_154, 0.45 * v_u_153)
			end
			if p151.mine then
				p_u_90.light(v_u_154, v_u_92, 9 * v_u_153)
			end
			local v_u_162 = false
			return {
				["place"] = function(p163, p164) -- name: place
					-- upvalues: (copy) v_u_154, (ref) v_u_58, (copy) v_u_155, (copy) v_u_153, (ref) v_u_4, (copy) v_u_160, (ref) p_u_90
					v_u_154.CFrame = p163
					v_u_58(v_u_155, p163 * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, p164 * 22, 0))
					local v165 = (p163 * CFrame.new(0, 0, -1.9 * v_u_153)).Position
					local v166 = v_u_4.CurrentCamera
					local v167
					if v166 then
						local v168 = v166.CFrame.Position - v165
						v167 = v168.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v168.Unit
					else
						v167 = Vector3.new(0, 0, 1)
					end
					v_u_160.CFrame = p_u_90.facing(v165 + v167 * 0.4, v167) * CFrame.Angles(0, p164 * 2, 0)
					local v169 = v_u_160
					local v170 = p164 * 30
					local v171 = math.sin(v170)
					local v172 = (math.abs(v171) * 0.3 + 1.1) * v_u_153
					local v173 = math.max(v172, 0.03)
					local v174 = v173 * 2
					local v175 = v173 * 2
					v169.Size = Vector3.new(v174, 0.05, v175)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_162, (ref) v_u_161, (copy) v_u_154, (ref) v_u_1, (copy) v_u_155, (ref) v_u_158, (copy) v_u_160
					if not v_u_162 then
						v_u_162 = true
						local v176 = v_u_161
						if v176 then
							v176.Enabled = false
						end
						local v177 = v_u_154:FindFirstChildWhichIsA("PointLight")
						if v177 then
							v177:Destroy()
						end
						v_u_1:AddItem(v_u_154, 0.45)
						for _, v178 in v_u_155 do
							v178.p:Destroy()
						end
						if v_u_158 then
							v_u_158:Destroy()
						end
						v_u_160:Destroy()
					end
				end
			}
		end,
		["impact"] = function(p179, p_u_180) -- name: shardImpact
			-- upvalues: (copy) p_u_90, (copy) v_u_92, (ref) v_u_9, (copy) v_u_121, (copy) v_u_94, (ref) v_u_5, (ref) v_u_7, (copy) v_u_143, (ref) v_u_83, (copy) v_u_95, (ref) v_u_58
			local v_u_181 = p179.size
			p_u_90.pop(p_u_180, v_u_92, 1.2 * v_u_181, 4.4 * v_u_181, 0.2, 0.3)
			p_u_90.pop(p_u_180, v_u_9, 0.8 * v_u_181, 2.2 * v_u_181, 0.12)
			v_u_121(p_u_180, 1 * v_u_181, 4.4 * v_u_181, v_u_94, 0.24, math.random() * 0.4 - 0.2)
			v_u_5.ring(p_u_90.ground(p_u_180), v_u_92, p179.ability.radius * v_u_181 * 0.8, 0.25, v_u_7.Ring)
			p_u_90.burst("Impact", p_u_180, v_u_92, 0.9 * v_u_181)
			if not p179.lite then
				v_u_143(p_u_180, 3.2 * v_u_181, 0.22)
				for _ = 1, 5 do
					local v182 = math.random() - 0.5
					local v183 = math.random() - 0.3
					local v184 = math.random() - 0.5
					local v185 = Vector3.new(v182, v183, v184)
					local v_u_186 = v185.Magnitude <= 0.05 and Vector3.new(0, 1, 0) or v185.Unit
					local v_u_187 = {}
					v_u_83(v_u_187, 0.36 * v_u_181, 0.8 * v_u_181, 0.4 * v_u_181, 0.1 * v_u_181, v_u_95, 0.1, 0.4)
					local v_u_188 = math.random() * 20 - 10
					p_u_90.animate(0.3, 0, function(p189)
						-- upvalues: (copy) p_u_180, (ref) v_u_186, (copy) v_u_181, (ref) v_u_58, (copy) v_u_187, (ref) p_u_90, (copy) v_u_188
						local v190 = p_u_180 + v_u_186 * (0.6 + 4.2 * (1 - (1 - p189) ^ 2)) * v_u_181
						v_u_58(v_u_187, p_u_90.aimAt(v190, v_u_186) * CFrame.Angles(-1.5707963267948966, p189 * v_u_188, 0))
						for _, v191 in v_u_187 do
							v191.p.Transparency = 0.1 + 0.9 * p189 ^ 2
						end
						if p189 >= 1 then
							for _, v192 in v_u_187 do
								v192.p:Destroy()
							end
						end
					end)
				end
			end
			p_u_90.hitSound(p_u_180)
		end,
		["hit"] = p_u_90.simpleHit(v_u_92, 0.6)
	}
	local v_u_193 = {}
	setmetatable(v_u_193, {
		["__mode"] = "k"
	})
	local v_u_194 = {}
	setmetatable(v_u_194, {
		["__mode"] = "k"
	})
	local function v_u_199(p195, p196) -- name: emitter
		local v197 = Instance.new("ParticleEmitter")
		v197.Texture = p196.texture
		if p196.grid then
			v197.FlipbookLayout = p196.grid
			v197.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
		v197.Color = p196.color
		v197.Size = p196.size
		v197.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 1),
			NumberSequenceKeypoint.new(0.15, 0),
			NumberSequenceKeypoint.new(0.75, 0.1),
			NumberSequenceKeypoint.new(1, 1)
		})
		v197.Lifetime = p196.life
		v197.Speed = p196.speed
		v197.Rate = p196.rate
		v197.LightEmission = p196.light or 0
		v197.LightInfluence = 0
		v197.Rotation = NumberRange.new(-30, 30)
		v197.RotSpeed = p196.spin or NumberRange.new(-20, 20)
		v197.Shape = Enum.ParticleEmitterShape.Box
		v197.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v197.EmissionDirection = Enum.NormalId.Top
		local v198
		if p196.up then
			v198 = Vector2.new(8, 8)
		else
			v198 = Vector2.new(25, 25)
		end
		v197.SpreadAngle = v198
		v197.ZOffset = 0.5
		v197.Parent = p195
		return v197
	end
	local function v_u_204(p200, p201, p202) -- name: holder
		-- upvalues: (ref) v_u_5, (copy) v_u_92, (ref) v_u_1
		local v203 = v_u_5.part(Vector3.new(p201, 0.3, p201), CFrame.new(p200 + Vector3.new(0, 0.3, 0)), v_u_92, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v203, p202)
		return v203
	end
	local function v_u_206(p205) -- name: swell
		return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, p205), NumberSequenceKeypoint.new(1, 0) })
	end
	local function v_u_210(p207, p208, p209) -- name: darkFlame
		-- upvalues: (copy) v_u_199, (ref) v_u_7, (copy) v_u_95, (copy) v_u_92, (copy) v_u_206
		return v_u_199(p207, {
			["texture"] = nil,
			["grid"] = nil,
			["color"] = nil,
			["size"] = nil,
			["life"] = nil,
			["speed"] = nil,
			["rate"] = nil,
			["up"] = true,
			["texture"] = v_u_7.ShadowFlame,
			["grid"] = Enum.ParticleFlipbookLayout.Grid4x4,
			["color"] = ColorSequence.new(v_u_95, v_u_92),
			["size"] = v_u_206(p208),
			["life"] = NumberRange.new(0.55, 0.9),
			["speed"] = NumberRange.new(2, 5),
			["rate"] = p209
		})
	end
	local function v_u_214(p211, p212, p213) -- name: twinkles
		-- upvalues: (copy) v_u_199, (copy) v_u_93, (copy) v_u_95, (copy) v_u_206
		return v_u_199(p211, {
			["texture"] = "rbxassetid://76741008972969",
			["grid"] = nil,
			["color"] = nil,
			["size"] = nil,
			["life"] = nil,
			["speed"] = nil,
			["rate"] = nil,
			["light"] = 0.8,
			["spin"] = nil,
			["grid"] = Enum.ParticleFlipbookLayout.Grid4x4,
			["color"] = ColorSequence.new(v_u_93, v_u_95),
			["size"] = v_u_206(p212),
			["life"] = NumberRange.new(0.35, 0.6),
			["speed"] = NumberRange.new(0.5, 2),
			["rate"] = p213,
			["spin"] = NumberRange.new(-90, 90)
		})
	end
	local function v_u_223(p_u_215, p216, p217, p218, p_u_219, p220) -- name: groundPicture
		-- upvalues: (ref) v_u_36, (ref) v_u_1, (copy) p_u_90
		local v_u_221 = v_u_36(CFrame.new(p_u_215 + Vector3.new(0, 0.2, 0)), 0.1, p216, p217, p218)
		v_u_1:AddItem(v_u_221, p220)
		local v_u_222 = os.clock()
		p_u_90.runNow(function()
			-- upvalues: (copy) v_u_221, (copy) p_u_215, (copy) v_u_222, (copy) p_u_219
			if not v_u_221.Parent then
				return false
			end
			v_u_221.CFrame = CFrame.new(p_u_215 + Vector3.new(0, 0.2, 0)) * CFrame.Angles(0, (os.clock() - v_u_222) * p_u_219, 0)
			return true
		end)
		return v_u_221
	end
	local function v_u_231(p224, p225, p226, p227, p228) -- name: flatRing
		-- upvalues: (ref) v_u_4, (ref) v_u_1
		local v229 = Instance.new("Attachment")
		v229.Parent = v_u_4.Terrain
		v229.WorldPosition = p224 + Vector3.new(0, 0.25, 0)
		local v230 = Instance.new("ParticleEmitter")
		v230.Texture = p227
		v230.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v230.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v230.Color = ColorSequence.new(p226)
		v230.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p225 * 0.5), NumberSequenceKeypoint.new(0.5, p225 * 1.8), NumberSequenceKeypoint.new(1, p225 * 2) })
		v230.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
		v230.Lifetime = NumberRange.new(p228)
		v230.LightEmission = 0.6
		v230.LightInfluence = 0
		v230.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v230.EmissionDirection = Enum.NormalId.Top
		v230.Speed = NumberRange.new(0.02)
		v230.SpreadAngle = Vector2.zero
		v230.Rotation = NumberRange.new(0, 360)
		v230.Rate = 0
		v230.Parent = v229
		v230:Emit(1)
		v_u_1:AddItem(v229, p228 + 0.2)
	end
	local function v_u_239(p232, p233, p234, p235) -- name: lightPillar
		-- upvalues: (ref) v_u_7, (copy) v_u_95, (copy) v_u_93
		local v236 = Instance.new("Attachment")
		v236.Parent = p232
		v236.WorldPosition = p233
		local v237 = Instance.new("Attachment")
		v237.Parent = p232
		v237.WorldPosition = p233 + Vector3.new(0, 1, 0) * p234
		local v238 = Instance.new("Beam")
		v238.Attachment0 = v236
		v238.Attachment1 = v237
		v238.Texture = v_u_7.Beam
		v238.TextureMode = Enum.TextureMode.Stretch
		v238.TextureSpeed = 1.2
		v238.Color = ColorSequence.new(v_u_95, v_u_93)
		v238.LightEmission = 1
		v238.LightInfluence = 0
		v238.FaceCamera = true
		v238.Width0 = p235
		v238.Width1 = p235 * 0.3
		v238.Transparency = NumberSequence.new(1)
		v238.Segments = 1
		v238.Parent = p232
		return v238
	end
	local function v_u_247(p240, p241) -- name: beamAlpha
		local v242 = NumberSequence.new
		local v243 = {}
		local v244 = NumberSequenceKeypoint.new(0, p241)
		local v245 = NumberSequenceKeypoint.new
		local v246 = p241 + 0.25
		__set_list(v243, 1, {v244, v245(0.7, (math.min(1, v246))), NumberSequenceKeypoint.new(1, 1)})
		p240.Transparency = v242(v243)
	end
	local function v_u_277(p248, p249, p250) -- name: openField
		-- upvalues: (copy) p_u_90, (copy) v_u_92, (ref) v_u_7, (copy) v_u_204, (copy) v_u_223, (copy) v_u_94, (copy) v_u_214
		local v_u_251 = p248.ability.radius
		local v252 = p248.ability.freeze or 3
		local v253 = p250 + v252 + 2
		local v254 = p_u_90.ground(p249, 0)
		p_u_90.mark(v254, v_u_92, v_u_251 * 1.1, p250 + v252 + 0.4, v_u_7.CrackGlow, 0.05)
		local v255 = v_u_204(v254, v_u_251 * 2, v253)
		local v256 = {
			["g"] = nil,
			["holder"] = nil,
			["emitters"] = nil,
			["pictures"] = nil,
			["beams"] = nil,
			["ended"] = false,
			["g"] = v254,
			["holder"] = v255,
			["emitters"] = {},
			["pictures"] = {},
			["beams"] = {}
		}
		local v_u_257 = v_u_223(v254, v_u_7.DarkDisc, v_u_92, 0.02, 0.9, v253)
		local v_u_258 = v_u_223(v254, v_u_7.DarkStar, v_u_94, 0.08, -1.4, v253)
		local v259 = v256.pictures
		table.insert(v259, v_u_257)
		local v260 = v256.pictures
		table.insert(v260, v_u_258)
		local v261 = math.max(p250, 0.15)
		p_u_90.animate(v261, 0, function(p262)
			-- upvalues: (copy) v_u_257, (copy) v_u_251, (copy) v_u_258
			local v263 = p262 - 1
			local v264 = v263 * 2.7 * v263 * v263 + 1 + v263 * 1.7 * v263
			local v265 = v_u_257
			local v266 = v_u_251 * 1.05 * v264
			local v267 = math.max(v266, 0.03)
			local v268 = v267 * 2
			local v269 = v267 * 2
			v265.Size = Vector3.new(v268, 0.05, v269)
			local v270 = v_u_258
			local v271 = v_u_251 * 0.7 * v264
			local v272 = math.max(v271, 0.03)
			local v273 = v272 * 2
			local v274 = v272 * 2
			v270.Size = Vector3.new(v273, 0.05, v274)
		end)
		if not p248.lite then
			local v_u_275 = v_u_214(v255, 1.3, 0)
			v_u_275.Shape = Enum.ParticleEmitterShape.Cylinder
			v_u_275.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v_u_275.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
			v_u_275.Speed = NumberRange.new(v_u_251 * 1.4, v_u_251 * 1.8)
			v_u_275.Lifetime = NumberRange.new(0.5, 0.6)
			p_u_90.animate(v261, 0, function(p276)
				-- upvalues: (copy) v_u_275
				v_u_275.Rate = 60 * p276
				if p276 >= 1 then
					v_u_275.Enabled = false
				end
			end)
		end
		return v256
	end
	local function v_u_310(p278, p_u_279) -- name: fillField
		-- upvalues: (copy) v_u_121, (copy) v_u_94, (copy) v_u_199, (ref) v_u_7, (copy) v_u_92, (copy) v_u_97, (copy) v_u_231, (copy) v_u_95, (copy) p_u_90, (copy) v_u_210, (copy) v_u_98, (copy) v_u_206, (copy) v_u_93, (copy) v_u_214, (copy) v_u_239, (copy) v_u_247
		local v_u_280 = p278.ability.radius
		local v281 = p278.ability.freeze or 3
		local v_u_282 = p_u_279.g
		local v283 = p_u_279.holder
		local v284 = p278.lite
		v_u_121(v_u_282 + Vector3.new(0, 3, 0), 2, v_u_280 * 0.9, v_u_94, 0.45)
		v_u_199(v283, {
			["texture"] = nil,
			["grid"] = nil,
			["color"] = nil,
			["size"] = nil,
			["life"] = nil,
			["speed"] = nil,
			["rate"] = 0,
			["up"] = true,
			["texture"] = v_u_7.KyubiErupt,
			["grid"] = Enum.ParticleFlipbookLayout.Grid2x2,
			["color"] = ColorSequence.new(v_u_92, v_u_97),
			["size"] = NumberSequence.new(v_u_280 * 0.5, v_u_280 * 0.8),
			["life"] = NumberRange.new(0.35, 0.5),
			["speed"] = NumberRange.new(0, 0)
		}):Emit(v284 and 3 or 8)
		v_u_231(v_u_282, v_u_280 * 1.15, v_u_95, v_u_7.KyubiRing, 0.45)
		v_u_231(v_u_282, v_u_280 * 0.8, v_u_92, v_u_7.KyubiSpikeRing, 0.5)
		p_u_90.burst("Shockwave", v_u_282 + Vector3.new(0, 0.3, 0), v_u_92, v_u_280 / 18)
		local v285 = p_u_279.emitters
		local v286 = v_u_210
		local v287 = 5
		local v288
		if v284 then
			v288 = v_u_280 * 0.8
		else
			v288 = v_u_280 * 3.5
		end
		local v289 = v286(v283, v287, v288)
		table.insert(v285, v289)
		if not v284 then
			local v290 = v_u_199(v283, {
				["texture"] = v_u_7.Glow,
				["color"] = ColorSequence.new(v_u_97, v_u_98),
				["size"] = v_u_206(v_u_280 * 0.55),
				["life"] = NumberRange.new(1, 1.6),
				["speed"] = NumberRange.new(0.3, 1),
				["rate"] = v_u_280 * 0.35
			})
			v290.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.3, 0.45),
				NumberSequenceKeypoint.new(0.7, 0.5),
				NumberSequenceKeypoint.new(1, 1)
			})
			v290.ZOffset = -1
			local v291 = p_u_279.emitters
			table.insert(v291, v290)
			local v292 = p_u_279.emitters
			local v293 = v_u_199(v283, {
				["texture"] = nil,
				["grid"] = nil,
				["color"] = nil,
				["size"] = nil,
				["life"] = nil,
				["speed"] = nil,
				["rate"] = nil,
				["light"] = 0.3,
				["spin"] = nil,
				["up"] = true,
				["texture"] = v_u_7.ShadowWisp,
				["grid"] = Enum.ParticleFlipbookLayout.Grid4x4,
				["color"] = ColorSequence.new(v_u_93, v_u_92),
				["size"] = v_u_206(3),
				["life"] = NumberRange.new(0.8, 1.2),
				["speed"] = NumberRange.new(4, 8),
				["rate"] = v_u_280 * 0.9,
				["spin"] = NumberRange.new(-60, 60)
			})
			table.insert(v292, v293)
			local v294 = p_u_279.emitters
			local v295 = v_u_214(v283, 1.2, v_u_280 * 1.4)
			table.insert(v294, v295)
			local v296 = v_u_214(v283, 0.9, v_u_280 * 0.6)
			v296.Speed = NumberRange.new(10, 18)
			v296.SpreadAngle = Vector2.new(6, 6)
			v296.Lifetime = NumberRange.new(0.6, 0.9)
			local v297 = p_u_279.emitters
			table.insert(v297, v296)
			local v298 = p_u_279.emitters
			local v299 = v_u_199(v283, {
				["texture"] = nil,
				["grid"] = nil,
				["color"] = nil,
				["size"] = nil,
				["life"] = nil,
				["speed"] = nil,
				["rate"] = 5,
				["light"] = 1,
				["spin"] = nil,
				["texture"] = v_u_7.KyubiBolts,
				["grid"] = Enum.ParticleFlipbookLayout.Grid4x4,
				["color"] = ColorSequence.new(v_u_93, v_u_95),
				["size"] = NumberSequence.new(v_u_280 * 0.35),
				["life"] = NumberRange.new(0.25, 0.35),
				["speed"] = NumberRange.new(0, 0),
				["spin"] = NumberRange.new(0, 0)
			})
			table.insert(v298, v299)
			for v300 = 1, 8 do
				local v301 = v300 / 8 * 3.141592653589793 * 2
				local v302 = math.cos(v301) * v_u_280 * 0.92
				local v303 = math.sin(v301) * v_u_280 * 0.92
				local v304 = v_u_239(v283, v_u_282 + Vector3.new(v302, 0.2, v303), v_u_280 * 1.1, 3.4)
				local v305 = p_u_279.beams
				table.insert(v305, v304)
			end
			p_u_90.animate(0.25, 0, function(p306)
				-- upvalues: (copy) p_u_279, (ref) v_u_247
				for _, v307 in p_u_279.beams do
					v_u_247(v307, 1 - 0.8 * p306)
				end
			end)
			local v308 = v281 / 0.5
			for v309 = 1, math.floor(v308) do
				p_u_90.after(v309 * 0.5, function()
					-- upvalues: (copy) p_u_279, (ref) v_u_231, (copy) v_u_282, (copy) v_u_280, (ref) v_u_92, (ref) v_u_7
					if not p_u_279.ended then
						v_u_231(v_u_282, v_u_280, v_u_92, v_u_7.KyubiRing, 0.5)
					end
				end)
			end
		end
	end
	local function v_u_331(p311, p_u_312) -- name: endField
		-- upvalues: (copy) v_u_214, (copy) p_u_90, (ref) v_u_40, (copy) v_u_247, (copy) v_u_121, (copy) v_u_94, (ref) v_u_5, (copy) v_u_95, (ref) v_u_7, (ref) v_u_6
		local v_u_313 = p311.ability.radius
		p_u_312.ended = true
		for _, v314 in p_u_312.emitters do
			v314.Enabled = false
		end
		local v315 = v_u_214(p_u_312.holder, 1.8, 0)
		v315.Speed = NumberRange.new(8, 18)
		v315.SpreadAngle = Vector2.new(70, 70)
		v315:Emit(p311.lite and 10 or 30)
		local v_u_316 = p_u_312.pictures[1]
		local v_u_317 = p_u_312.pictures[2]
		p_u_90.animate(0.35, 0, function(p318)
			-- upvalues: (copy) v_u_316, (copy) v_u_313, (ref) v_u_40, (copy) v_u_317, (copy) p_u_312, (ref) v_u_247
			local v319 = 1 - p318 * p318
			if v_u_316 and v_u_316.Parent then
				local v320 = v_u_316
				local v321 = v_u_313 * 1.05 * v319
				local v322 = math.max(v321, 0.03)
				local v323 = v322 * 2
				local v324 = v322 * 2
				v320.Size = Vector3.new(v323, 0.05, v324)
				v_u_40(v_u_316, 0.02 + 0.98 * p318)
			end
			if v_u_317 and v_u_317.Parent then
				local v325 = v_u_317
				local v326 = v_u_313 * 0.7 * (1 + p318)
				local v327 = math.max(v326, 0.03)
				local v328 = v327 * 2
				local v329 = v327 * 2
				v325.Size = Vector3.new(v328, 0.05, v329)
				v_u_40(v_u_317, 0.08 + 0.92 * p318)
			end
			for _, v330 in p_u_312.beams do
				v_u_247(v330, 0.2 + 0.8 * p318)
			end
		end)
		if not p311.lite then
			v_u_121(p_u_312.g + Vector3.new(0, 3, 0), 1.5, v_u_313 * 0.6, v_u_94, 0.3)
		end
		v_u_5.ring(p_u_312.g, v_u_95, v_u_313 * 1.2, 0.35, v_u_7.Ring)
		v_u_6.play("Burst", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p_u_312.g
		})
	end
	v100.dark_star_e = {
		["cast"] = function(p332) -- name: cast
			-- upvalues: (copy) p_u_90, (copy) v_u_92, (copy) v_u_121, (copy) v_u_93
			p_u_90.skillCast(p332, v_u_92)
			if not p332.lite then
				v_u_121(p332.eye + p332.dir * 1.2, 0.8 * p332.size, 3 * p332.size, v_u_93, 0.25)
			end
		end,
		["windup"] = function(p333, p334, p335) -- name: windup
			-- upvalues: (copy) v_u_193, (copy) v_u_277
			v_u_193[p333] = v_u_277(p333, p334, p335)
		end,
		["land"] = function(p_u_336, p337) -- name: land
			-- upvalues: (copy) v_u_193, (copy) v_u_277, (copy) v_u_310, (ref) v_u_6, (ref) v_u_5, (copy) p_u_90, (copy) v_u_331
			local v_u_338 = v_u_193[p_u_336] or v_u_277(p_u_336, p337, 0)
			v_u_193[p_u_336] = nil
			v_u_310(p_u_336, v_u_338)
			v_u_6.play("Hit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v_u_338.g
			})
			if p_u_336.mine then
				v_u_5.shake(0.45, 0.3)
			end
			p_u_90.after(p_u_336.ability.freeze or 3, function()
				-- upvalues: (ref) v_u_331, (copy) p_u_336, (copy) v_u_338
				v_u_331(p_u_336, v_u_338)
			end)
		end,
		["hit"] = function(p339, p340, _) -- name: hit
			-- upvalues: (copy) p_u_90, (copy) v_u_92, (copy) v_u_194, (copy) v_u_204, (copy) v_u_210, (copy) v_u_214, (copy) v_u_223, (ref) v_u_7, (copy) v_u_94, (ref) v_u_40
			p_u_90.burst("Impact", p340, v_u_92, 0.6)
			local v341 = (v_u_194[p339] or 0) + 1
			v_u_194[p339] = v341
			if not p339.lite and v341 <= 12 then
				local v342 = p339.ability.freeze or 3
				local v343 = p_u_90.ground(p340, 0)
				local v344 = v_u_204(v343, 3.5, v342 + 1.2)
				local v_u_345 = v_u_210(v344, 3, 16)
				v_u_345.SpreadAngle = Vector2.new(15, 15)
				local v_u_346 = v_u_214(v344, 0.9, 8)
				local v_u_347 = v_u_223(v343, v_u_7.DarkStar, v_u_94, 0.3, 2, v342 + 0.5)
				p_u_90.animate(0.2, 0, function(p348)
					-- upvalues: (copy) v_u_347
					local v349 = v_u_347
					local v350 = p348 - 1
					local v351 = (v350 * 2.7 * v350 * v350 + 1 + v350 * 1.7 * v350) * 2.6
					local v352 = math.max(v351, 0.03)
					local v353 = v352 * 2
					local v354 = v352 * 2
					v349.Size = Vector3.new(v353, 0.05, v354)
				end)
				p_u_90.after(v342, function()
					-- upvalues: (copy) v_u_345, (copy) v_u_346, (ref) p_u_90, (copy) v_u_347, (ref) v_u_40
					v_u_345.Enabled = false
					v_u_346.Enabled = false
					p_u_90.animate(0.3, 0, function(p355)
						-- upvalues: (ref) v_u_347, (ref) v_u_40
						if v_u_347.Parent then
							v_u_40(v_u_347, 0.3 + 0.7 * p355)
						end
					end)
				end)
			end
		end
	}
	local v_u_356 = {}
	setmetatable(v_u_356, {
		["__mode"] = "k"
	})
	local function v_u_422(p357) -- name: makeHole
		-- upvalues: (copy) p_u_90, (ref) v_u_4, (ref) v_u_5, (copy) v_u_98, (ref) v_u_14, (ref) v_u_16, (ref) v_u_36, (ref) v_u_7, (copy) v_u_94, (copy) v_u_93, (copy) v_u_92, (copy) v_u_95, (ref) v_u_1, (ref) v_u_40
		local v358 = p_u_90.ground(p357, 0)
		local v_u_359 = v358 + Vector3.new(0, 10, 0)
		local v360 = p_u_90.flatUnit
		local v361 = v_u_4.CurrentCamera
		local v362
		if v361 then
			local v363 = v361.CFrame.Position - v_u_359
			v362 = v363.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v363.Unit
		else
			v362 = Vector3.new(0, 0, 1)
		end
		local v364 = v360(v362) * 0.28
		local v365 = {
			["shape"] = v_u_14,
			["material"] = v_u_16
		}
		local v_u_366 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_359), v_u_98, v365)
		local v_u_367 = v_u_36(CFrame.new(v_u_359), 0.1, v_u_7.Ring, v_u_94, 0)
		local v_u_368 = v_u_36(CFrame.new(v_u_359), 0.1, v_u_7.DarkDisc, v_u_93, 0.15)
		local v_u_369 = v_u_36(CFrame.new(v_u_359), 0.1, v_u_7.Glow, v_u_92, 0.35)
		local v_u_370 = v_u_36(CFrame.new(v_u_359), 0.1, v_u_7.DarkDisc, v_u_92, 0)
		local v_u_371 = v_u_36(CFrame.new(v_u_359), 0.1, v_u_7.DarkDisc, v_u_95, 0.1)
		for _, v372 in {
			v_u_366,
			v_u_367,
			v_u_368,
			v_u_369,
			v_u_370,
			v_u_371
		} do
			v_u_1:AddItem(v372, 6)
		end
		local v_u_373 = {
			["at"] = nil,
			["g"] = nil,
			["tilt"] = nil,
			["core"] = nil,
			["photon"] = nil,
			["halo"] = nil,
			["glow"] = nil,
			["disc"] = nil,
			["inner"] = nil,
			["born"] = nil,
			["opened"] = nil,
			["closing"] = nil,
			["pulse"] = 0,
			["at"] = v_u_359,
			["g"] = v358,
			["tilt"] = (Vector3.new(0, 1, 0) + v364).Unit,
			["core"] = v_u_366,
			["photon"] = v_u_367,
			["halo"] = v_u_368,
			["glow"] = v_u_369,
			["disc"] = v_u_370,
			["inner"] = v_u_371,
			["born"] = os.clock()
		}
		local v_u_374 = 0
		local v_u_375 = os.clock()
		p_u_90.runNow(function()
			-- upvalues: (ref) v_u_375, (copy) v_u_373, (copy) v_u_366, (copy) v_u_367, (copy) v_u_368, (copy) v_u_369, (copy) v_u_370, (copy) v_u_371, (ref) v_u_374, (copy) v_u_359, (ref) v_u_4, (ref) p_u_90, (ref) v_u_40
			local v376 = os.clock()
			local v377 = v376 - v_u_375
			local v378 = math.min(v377, 0.05)
			v_u_375 = v376
			local v379 = v_u_373.opened
			local v380
			if v379 then
				local v381 = (v376 - v379) / 0.35
				local v382 = math.clamp(v381, 0, 1) - 1
				v380 = (v382 * 2.7 * v382 * v382 + 1 + v382 * 1.7 * v382) * 0.8 + 0.2
			else
				local v383 = (v376 - v_u_373.born) / 0.2
				v380 = math.clamp(v383, 0, 1) * 0.1 + 0.12
			end
			local v384 = v_u_373.closing
			if v384 then
				local v385 = (v376 - v384) / 0.12
				local v386 = math.clamp(v385, 0, 1)
				v380 = v380 * ((1 - v386) * (1 - v386))
				if v386 >= 1 then
					for _, v387 in {
						v_u_366,
						v_u_367,
						v_u_368,
						v_u_369,
						v_u_370,
						v_u_371
					} do
						v387:Destroy()
					end
					return false
				end
			end
			local v388 = v_u_373
			local v389 = v_u_373.pulse - v378 * 3
			v388.pulse = math.max(v389, 0)
			local v390 = v_u_373.pulse * 0.12 + 1
			v_u_374 = v_u_374 + v378 * (v_u_373.pulse * 2 + 2.5)
			local v391 = v_u_359
			local v392 = v_u_4.CurrentCamera
			local v393
			if v392 then
				local v394 = v392.CFrame.Position - v391
				v393 = v394.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v394.Unit
			else
				v393 = Vector3.new(0, 0, 1)
			end
			local v395 = v_u_366
			local v396 = v380 * 6
			v395.Size = Vector3.new(1, 1, 1) * math.max(v396, 0.1)
			v_u_366.CFrame = CFrame.new(v_u_359)
			local v397 = v_u_367
			local v398 = v380 * 3.35 * v390
			local v399 = math.max(v398, 0.03)
			local v400 = v399 * 2
			local v401 = v399 * 2
			v397.Size = Vector3.new(v400, 0.05, v401)
			v_u_367.CFrame = p_u_90.facing(v_u_359 + v393 * 0.25, v393)
			local v402 = v_u_368
			local v403 = v380 * 5.3 * v390
			local v404 = math.max(v403, 0.03)
			local v405 = v404 * 2
			local v406 = v404 * 2
			v402.Size = Vector3.new(v405, 0.05, v406)
			v_u_368.CFrame = p_u_90.facing(v_u_359 - v393 * 0.4, v393) * CFrame.Angles(0, -v_u_374 * 0.7, 0)
			local v407 = v_u_369
			local v408 = v380 * 10.5
			local v409 = math.max(v408, 0.03)
			local v410 = v409 * 2
			local v411 = v409 * 2
			v407.Size = Vector3.new(v410, 0.05, v411)
			v_u_369.CFrame = p_u_90.facing(v_u_359 - v393 * 1.2, v393)
			local v412 = v_u_370
			local v413 = v380 * 9.5 * v390
			local v414 = math.max(v413, 0.03)
			local v415 = v414 * 2
			local v416 = v414 * 2
			v412.Size = Vector3.new(v415, 0.05, v416)
			v_u_370.CFrame = p_u_90.facing(v_u_359, v_u_373.tilt) * CFrame.Angles(0, v_u_374, 0)
			local v417 = v_u_371
			local v418 = v380 * 5.89 * v390
			local v419 = math.max(v418, 0.03)
			local v420 = v419 * 2
			local v421 = v419 * 2
			v417.Size = Vector3.new(v420, 0.05, v421)
			v_u_371.CFrame = p_u_90.facing(v_u_359 + v_u_373.tilt * 0.05, v_u_373.tilt) * CFrame.Angles(0, v_u_374 * 1.7, 0)
			v_u_40(v_u_367, (1 - v_u_373.pulse) * 0.25)
			return v376 - v_u_373.born < 6
		end)
		return v_u_373
	end
	local function v_u_464(p_u_423, p424, p425) -- name: infall
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) v_u_99, (ref) v_u_17, (ref) v_u_16, (ref) v_u_14, (ref) v_u_1, (copy) p_u_90, (copy) v_u_95, (copy) v_u_93, (copy) v_u_92
		local v_u_426 = math.random() * 3.141592653589793 * 2
		local v_u_427 = p424 * (0.75 + math.random() * 0.45)
		local v_u_428 = math.random() < 0.35
		local v_u_429 = v_u_428 and 0.45 or 0.7 + math.random() * 0.7
		local v430 = v_u_5.part
		local v431 = Vector3.new(1, 1, 1) * v_u_429
		local v432 = CFrame.new
		local v433 = p_u_423.g
		local v434 = math.cos(v_u_426) * v_u_427
		local v435 = math.sin(v_u_426) * v_u_427
		local v436 = v432(v433 + Vector3.new(v434, 0.5, v435))
		local v437
		if v_u_428 then
			v437 = v_u_9
		else
			v437 = v_u_99
		end
		local v438 = {}
		local v439
		if v_u_428 then
			v439 = v_u_17
		else
			v439 = v_u_16
		end
		v438.material = v439
		local v440
		if v_u_428 then
			v440 = v_u_14
		else
			v440 = nil
		end
		v438.shape = v440
		local v_u_441 = v430(v431, v436, v437, v438)
		local v442 = 0.8 + math.random() * 0.3
		v_u_1:AddItem(v_u_441, v442 + 0.1)
		local v_u_443 = 4 + math.random() * 2
		local v_u_444 = v_u_441.Position
		local v_u_445 = CFrame.Angles(math.random() * 6, math.random() * 6, 0)
		p_u_90.animate(v442, 0, function(p446)
			-- upvalues: (copy) v_u_427, (copy) v_u_426, (copy) v_u_443, (copy) p_u_423, (ref) v_u_444, (copy) v_u_429, (copy) v_u_441, (ref) p_u_90, (copy) v_u_428, (ref) v_u_17, (ref) v_u_99, (ref) v_u_95, (copy) v_u_445
			local v447 = p446 * p446
			local v448 = v_u_427 * (1 - v447)
			local v449 = v_u_426 + v_u_443 * v447
			local v450 = p_u_423.g.Y + 0.5 + (p_u_423.at.Y - p_u_423.g.Y - 0.5) * (1 - (1 - p446) ^ 2)
			local v451 = p_u_423.at.X + math.cos(v449) * v448
			local v452 = p_u_423.at.Z + math.sin(v449) * v448
			local v453 = Vector3.new(v451, v450, v452)
			local v454 = v453 - v_u_444
			v_u_444 = v453
			local v455 = 1 + 6 * p446 ^ 2
			local v456 = v_u_429 * (1 - 0.65 * p446)
			local v457 = math.max(v456, 0.08)
			if v454.Magnitude > 0.001 and p446 > 0.35 then
				v_u_441.CFrame = p_u_90.aimAt(v453, v454)
				if not v_u_428 then
					v_u_441.Material = v_u_17
					local v458 = v_u_441
					local v459 = v_u_99
					local v460 = v_u_95
					local v461 = (p446 - 0.35) * 2
					v458.Color = v459:Lerp(v460, (math.clamp(v461, 0, 1)))
				end
				local v462 = v_u_441
				local v463 = v_u_429 * v455
				v462.Size = Vector3.new(v457, v457, v463)
			else
				v_u_441.CFrame = CFrame.new(v453) * v_u_445
			end
			if p446 >= 1 then
				v_u_441:Destroy()
			end
		end)
		if not p425 and math.random() < 0.3 then
			p_u_90.streak(v_u_441, v_u_93, v_u_92, 0.35, 0.15)
		end
	end
	local function v_u_479(p465, p_u_466, p467) -- name: closingRing
		-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_1, (copy) p_u_90, (ref) v_u_40
		local v_u_468 = v_u_36(CFrame.new(p465 + Vector3.new(0, 0.35, 0)), p_u_466, v_u_7.Ring, p467, 0.5)
		v_u_1:AddItem(v_u_468, 0.5)
		p_u_90.animate(0.42, 0, function(p469)
			-- upvalues: (copy) v_u_468, (copy) p_u_466, (ref) v_u_40
			local v470 = v_u_468
			local v471 = p_u_466 * (1.05 - 0.95 * p469 * p469)
			local v472 = math.max(v471, 0.03)
			local v473 = v472 * 2
			local v474 = v472 * 2
			v470.Size = Vector3.new(v473, 0.05, v474)
			local v475 = v_u_40
			local v476 = v_u_468
			local v477 = 0.5 - 0.4 * p469
			local v478 = p469 - 0.8
			v475(v476, v477 + math.max(v478, 0) * 0.9 / 0.2)
			if p469 >= 1 then
				v_u_468:Destroy()
			end
		end)
	end
	local function v_u_486(p480, p481) -- name: heartBurst
		-- upvalues: (copy) p_u_90, (ref) v_u_5, (ref) v_u_9, (copy) v_u_121, (copy) v_u_94, (copy) v_u_95, (copy) v_u_143, (copy) v_u_92, (copy) v_u_93, (ref) v_u_7, (copy) v_u_97, (copy) v_u_99, (ref) v_u_6
		local v482 = p480.ability.radius
		local v483 = p_u_90.ground(p481, 0)
		local v484 = v483 + Vector3.new(0, 10, 0)
		local v485 = p480.lite
		v_u_5.flash(v484, v_u_9, v482 * 1.3, 0.25)
		v_u_121(v484, 3, v482 * 2, v_u_94, 0.5)
		v_u_121(v484, 2, v482 * 1.1, v_u_95, 0.42, 0.7853981633974483)
		if not v485 then
			v_u_143(v484, v482 * 1.15, 0.5)
		end
		p_u_90.pop(v484, v_u_92, 5, v482 * 2.4, 0.55, 0.45)
		p_u_90.pop(v484, v_u_93, 3, v482 * 1.1, 0.3, 0.2)
		p_u_90.dome(v483, v482 * 1.3, v_u_92, 0.6)
		v_u_5.ring(v483, v_u_95, v482 * 1.5, 0.55, v_u_7.Shockwave)
		v_u_5.ring(v483, v_u_9, v482 * 1.2, 0.35, v_u_7.Ring)
		p_u_90.burst("Shockwave", v483 + Vector3.new(0, 0.3, 0), v_u_92, v482 / 13)
		p_u_90.burst("Explosion", v484, v_u_92, 2)
		p_u_90.spikes(v484, v_u_9, v485 and 6 or 14, v482 * 1.5, 0.35)
		p_u_90.chunks(v483 + Vector3.new(0, 1, 0), { v_u_97, v_u_99, v_u_95 }, v485 and 6 or 14, 46, 1.1, 1.1, false, 0.9)
		p_u_90.mark(v483, v_u_92, v482 * 1.1, 1, v_u_7.Glow, 0.3)
		v_u_6.play("Explosion", {
			["at"] = v484,
			["volume"] = p480.mine and 1 or 0.6
		})
		if p480.mine then
			v_u_5.shake(0.6, 0.5)
		end
	end
	v100.dark_star_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p487) -- name: cast
			-- upvalues: (copy) p_u_90, (copy) v_u_92, (copy) v_u_121, (copy) v_u_94, (copy) v_u_143, (ref) v_u_5
			p_u_90.skillCast(p487, v_u_92, true)
			local v488 = p487.size
			local v489 = p487.eye + p487.dir * 1.4
			v_u_121(v489, 1 * v488, 5 * v488, v_u_94, 0.32)
			if not p487.lite then
				v_u_143(v489, 3.4 * v488, 0.3)
			end
			if p487.mine then
				v_u_5.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p490, p491, p492) -- name: windup
			-- upvalues: (copy) v_u_422, (copy) v_u_356, (copy) p_u_90, (copy) v_u_93, (copy) v_u_479, (copy) v_u_92
			local v493 = v_u_422(p491)
			v_u_356[p490] = v493
			p_u_90.inward(v493.at, v_u_93, p490.lite and 5 or 10, 16, (math.max(p492, 0.15)))
			v_u_479(v493.g, p490.ability.radius * 1.2, v_u_92)
		end,
		["zone"] = function(p_u_494, p495, p_u_496) -- name: zone
			-- upvalues: (copy) v_u_356, (copy) v_u_422, (ref) v_u_5, (copy) v_u_95, (copy) v_u_92, (ref) v_u_7, (copy) p_u_90, (copy) v_u_96, (ref) v_u_89, (copy) p_u_91, (copy) v_u_464, (copy) v_u_479
			local v_u_497 = v_u_356[p_u_494] or v_u_422(p495)
			v_u_356[p_u_494] = v_u_497
			v_u_497.opened = os.clock()
			local v_u_498 = p_u_494.ability.radius
			local v_u_499 = v_u_497.g
			local v_u_500 = p_u_494.lite
			v_u_5.flash(v_u_497.at, v_u_95, 12, 0.25)
			v_u_5.ring(v_u_499, v_u_92, v_u_498 * 1.2, 0.4, v_u_7.Shockwave)
			p_u_90.mark(v_u_499, v_u_96, v_u_498 * 1.1, p_u_496 + 0.3, v_u_7.Glow, 0.25)
			if p_u_494.mine then
				v_u_89(p_u_496, p_u_91.dim)
				v_u_5.shake(0.3, 0.3)
			end
			local v_u_501 = os.clock()
			local v_u_502 = 0
			local v_u_503 = 0.4
			local v_u_504 = false
			p_u_90.runNow(function()
				-- upvalues: (ref) v_u_504, (copy) v_u_501, (ref) v_u_502, (copy) v_u_500, (ref) v_u_464, (copy) v_u_497, (copy) v_u_498, (ref) v_u_503, (ref) v_u_479, (copy) v_u_499, (ref) v_u_95, (ref) p_u_90, (copy) p_u_496
				if v_u_504 then
					return false
				end
				local v505 = os.clock() - v_u_501
				if v_u_502 <= v505 then
					v_u_502 = v505 + (v_u_500 and 0.22 or 0.08)
					v_u_464(v_u_497, v_u_498, v_u_500)
				end
				if v_u_503 <= v505 then
					v_u_503 = v_u_503 + 0.4
					v_u_497.pulse = 1
					v_u_479(v_u_499, v_u_498 * 1.1, v_u_95)
					if not v_u_500 then
						p_u_90.inward(v_u_497.at, v_u_95, 5, 12, 0.3)
					end
				end
				return v505 < p_u_496 + 0.5
			end)
			return function()
				-- upvalues: (ref) v_u_504, (copy) v_u_497, (ref) v_u_356, (copy) p_u_494
				v_u_504 = true
				v_u_497.closing = os.clock()
				v_u_356[p_u_494] = nil
			end
		end,
		["finish"] = function(p506, p507) -- name: finish
			-- upvalues: (copy) v_u_486
			v_u_486(p506, p507)
		end,
		["hit"] = function(p508, p509, _) -- name: hit
			-- upvalues: (copy) p_u_90, (copy) v_u_92, (copy) v_u_93
			p_u_90.burst("Impact", p509, v_u_92, 0.8)
			if not p508.lite then
				p_u_90.glint(p509, v_u_93, 3, 0.14)
			end
		end
	}
	return v100
end
return function(p511)
	-- upvalues: (copy) v_u_510, (copy) v_u_10, (copy) v_u_12, (copy) v_u_8
	local v512 = v_u_510(p511, v_u_10)
	local v513 = v_u_510(p511, v_u_12)
	local v514 = {}
	for v515, v_u_516 in v512 do
		local v_u_517 = v513[v515]
		local v518 = {}
		for v_u_519, v520 in v_u_516 do
			if type(v520) == "function" then
				v518[v_u_519] = function(p521, ...)
					-- upvalues: (copy) v_u_517, (ref) v_u_8, (copy) v_u_516, (copy) v_u_519
					local v522
					if v_u_517 then
						local v523 = p521.caster
						local v524
						if v523 then
							v524 = v523:GetAttribute("Eye")
						else
							v524 = nil
						end
						local v525 = v_u_8.GRAND_PRIZE
						local v526
						if type(v524) == "string" then
							local v527 = #v525
							if string.sub(v524, 1, v527) == v525 then
								v526 = v_u_8.GRAND_PRIZE_RECOLOR.look == "dark_star"
							else
								v526 = false
							end
						else
							v526 = false
						end
						if v526 then
							v522 = v_u_517
							return v522[v_u_519](p521, ...)
						else
							v522 = v_u_516
							return v522[v_u_519](p521, ...)
						end
					else
						v522 = v_u_516
						return v522[v_u_519](p521, ...)
					end
				end
			else
				v518[v_u_519] = v520
			end
		end
		v514[v515] = v518
	end
	return v514
end