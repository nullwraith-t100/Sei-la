local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF3FA4")
local v_u_9 = Color3.fromHex("2A0718")
local v_u_10 = Color3.fromRGB(20, 6, 14)
local v_u_11 = Color3.fromRGB(255, 150, 210)
local v_u_12 = Color3.fromRGB(96, 10, 54)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.Material.SmoothPlastic
local function v_u_27(p16, p17, p18, p19, p20) -- name: disc
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_31(p28, p29) -- name: fadeDecals
	for _, v30 in p28:GetChildren() do
		if not v30:IsA("Decal") then
			continue
		end
		v30.Transparency = p29
	end
end
local function v_u_38(p32, p33, p34, p35) -- name: thornFrame
	local v36 = p33:Cross(p34)
	if v36.Magnitude < 0.001 then
		v36 = p33:Cross(Vector3.new(1, 0, 0))
	end
	local v37 = v36.Unit:Cross(p33).Unit
	return CFrame.fromMatrix(p32 + p33 * p35 / 2, v36.Unit, p33, v37)
end
return function(p_u_39)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_31, (copy) v_u_5, (copy) v_u_10, (copy) v_u_15, (copy) v_u_2, (copy) v_u_13, (copy) v_u_8, (copy) v_u_14, (copy) v_u_9, (copy) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_12, (copy) v_u_38, (copy) v_u_4
	local function v_u_55(p_u_40, p_u_41, p_u_42, p43, p44, p_u_45, p_u_46, p47) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_39, (ref) v_u_31
		local v_u_48 = p47 or 0
		local v_u_49 = v_u_27(p_u_40, p_u_41, p43, p44, v_u_48)
		v_u_1:AddItem(v_u_49, p_u_45 + 0.1)
		p_u_39.animate(p_u_45, 0, function(p50)
			-- upvalues: (copy) p_u_41, (copy) p_u_42, (copy) v_u_49, (copy) p_u_40, (copy) p_u_45, (copy) p_u_46, (ref) v_u_31, (copy) v_u_48
			local v51 = p_u_41 + (p_u_42 - p_u_41) * (1 - (1 - p50) ^ 3)
			local v52 = v_u_49
			local v53 = v51 * 2
			local v54 = v51 * 2
			v52.Size = Vector3.new(v53, 0.05, v54)
			v_u_49.CFrame = p_u_40 * CFrame.Angles(0, p50 * p_u_45 * p_u_46, 0)
			v_u_31(v_u_49, v_u_48 + (1 - v_u_48) * p50 ^ 1.5)
			if p50 >= 1 then
				v_u_49:Destroy()
			end
		end)
	end
	local function v_u_76(p_u_56, p57, p_u_58, p59, p60) -- name: spray
		-- upvalues: (ref) v_u_5, (copy) p_u_39, (ref) v_u_10, (ref) v_u_15, (ref) v_u_1
		local v_u_61 = {}
		for _ = 1, p57 do
			local v62 = math.random() - 0.5
			local v63 = math.random() * 0.8
			local v64 = math.random() - 0.5
			local v65 = Vector3.new(v62, v63, v64)
			local v66 = v65.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v65.Unit
			local v67 = {
				["material"] = v_u_15
			}
			local v68 = v_u_5.part(Vector3.new(0.16, 0.16, p59), p_u_39.aimAt(p_u_56, v66), v_u_10, v67)
			v_u_1:AddItem(v68, p60 + 0.2)
			local v69 = {
				["p"] = v68,
				["way"] = v66 * p_u_58 * (0.7 + math.random() * 0.5)
			}
			table.insert(v_u_61, v69)
		end
		p_u_39.animate(p60, 0, function(p70)
			-- upvalues: (copy) v_u_61, (copy) p_u_56, (copy) p_u_58, (ref) p_u_39
			local v71 = 1 - (1 - p70) ^ 3
			for _, v72 in v_u_61 do
				local v73 = p_u_56 + v72.way * v71 - Vector3.new(0, 1, 0) * p70 * p70 * p_u_58 * 0.4
				v72.p.CFrame = p_u_39.aimAt(v73, v72.way)
				local v74 = v72.p
				local v75 = p70 * 2 - 1
				v74.Transparency = math.max(v75, 0)
				if p70 < 1 then
					continue
				end
				v72.p:Destroy()
			end
		end)
	end
	local v_u_77 = 0
	local function v_u_81() -- name: crushFrame
		-- upvalues: (ref) v_u_77, (ref) v_u_2, (ref) v_u_5, (copy) p_u_39, (ref) v_u_13, (ref) v_u_1
		local v78 = os.clock()
		if v78 >= v_u_77 then
			v_u_77 = v78 + 0.6
			local v_u_79 = Instance.new("ColorCorrectionEffect")
			v_u_79.Name = "BramblePrison"
			v_u_79.Parent = v_u_2
			v_u_5.tween(v_u_79, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.25,
				["Saturation"] = 0.2,
				["TintColor"] = Color3.fromRGB(255, 205, 230)
			})
			p_u_39.after(0.12, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_79, (ref) v_u_13
				local v80 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_13
				}
				v_u_5.tween(v_u_79, 0.4, v80)
			end)
			v_u_1:AddItem(v_u_79, 0.6)
		end
	end
	local function v102(p82, p83) -- name: seedShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_10, (ref) v_u_15, (ref) v_u_14, (copy) p_u_39, (ref) v_u_9
		local v84 = p82.size
		local v85 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p83, v_u_8, {
			["transparency"] = 1
		})
		local v86 = {
			["material"] = v_u_15
		}
		local v87 = v_u_5.part(Vector3.new(0.8, 0.8, 1.5) * v84, p83, v_u_10, v86)
		v87.Reflectance = 0.3
		local v88 = Instance.new("SpecialMesh")
		v88.MeshType = Enum.MeshType.Sphere
		v88.Parent = v87
		local v89 = {
			["shape"] = nil,
			["transparency"] = 0.55,
			["shape"] = v_u_14
		}
		local v90 = v_u_5.part(Vector3.new(1.5, 1.5, 1.5) * v84, p83, v_u_8, v89)
		local v91 = {
			{
				["p"] = v87,
				["off"] = CFrame.identity
			},
			{
				["p"] = v90,
				["off"] = CFrame.identity
			}
		}
		local v92 = p82.lite and 3 or 5
		for v93 = 1, v92 do
			local v94 = v93 / v92 * 3.141592653589793 * 2
			local v95 = math.cos(v94)
			local v96 = math.sin(v94)
			local v97 = Vector3.new(v95, v96, 0.75).Unit
			local v98 = {
				["material"] = v_u_15
			}
			local v99 = v_u_5.part(Vector3.new(0.13, 0.13, 1) * v84, p83, v_u_10, v98)
			local v100 = v97 * 0.75 * v84
			local v101 = {
				["p"] = v99,
				["off"] = CFrame.lookAt(v100, v100 + v97)
			}
			table.insert(v91, v101)
		end
		p_u_39.streak(v85, v_u_8, v_u_9, 0.9 * v84, 0.12)
		if p82.mine then
			p_u_39.light(v85, v_u_8, 8 * v84)
		end
		return p_u_39.assemble(v85, v91, {}, 0, 0, {}, 0.12, 16)
	end
	local function v106(p103, p104) -- name: seedImpact
		-- upvalues: (copy) p_u_39, (ref) v_u_8, (ref) v_u_10, (ref) v_u_15, (copy) v_u_76, (ref) v_u_11
		local v105 = p103.size
		p_u_39.pop(p104, v_u_8, 1 * v105, 3.8 * v105, 0.16, 0.3)
		p_u_39.pop(p104, v_u_10, 0.9 * v105, 2.2 * v105, 0.12, 0, v_u_15)
		p_u_39.burst("Impact", p104, v_u_8, 0.8 * v105)
		v_u_76(p104, p103.lite and 4 or 7, 5 * v105, 1.4 * v105, 0.24)
		if not p103.lite then
			p_u_39.spikes(p104, v_u_11, 4, 3.5 * v105, 0.14)
		end
		p_u_39.hitSound(p104)
	end
	local v_u_107 = {}
	setmetatable(v_u_107, {
		["__mode"] = "k"
	})
	local function v_u_144(p108, p_u_109) -- name: startBud
		-- upvalues: (copy) v_u_107, (copy) p_u_39, (ref) v_u_10, (ref) v_u_15, (ref) v_u_8, (ref) v_u_5, (ref) v_u_1
		local v_u_110 = p108.size
		local v_u_111 = p108.eye + Vector3.new(0, 3.2, 0) * p108.size - p108.dir * 0.6 * p108.size
		local v_u_112 = {
			["kickAt"] = -10,
			["done"] = false
		}
		v_u_107[p108] = v_u_112
		local v_u_113 = p_u_39.ball(v_u_111, v_u_10, 0.9 * v_u_110, 0, v_u_15)
		local v_u_114 = p_u_39.ball(v_u_111, v_u_8, 1.9 * v_u_110, 0.5)
		local v_u_115 = {}
		for _ = 1, p108.lite and 3 or 5 do
			local v116 = {
				["material"] = v_u_15
			}
			local v117 = v_u_5.part(Vector3.new(0.22, 0.22, 2.2) * v_u_110, CFrame.new(v_u_111), v_u_10, v116)
			table.insert(v_u_115, v117)
		end
		local v_u_118 = { v_u_113, v_u_114 }
		for _, v119 in v_u_115 do
			table.insert(v_u_118, v119)
		end
		for _, v120 in v_u_118 do
			v_u_1:AddItem(v120, p_u_109 + 1)
		end
		local v_u_121 = p_u_39.flatUnit(p108.dir)
		local v_u_122 = v_u_121:Cross(Vector3.new(0, 1, 0)).Unit
		local v_u_123 = os.clock()
		p_u_39.runNow(function()
			-- upvalues: (copy) v_u_123, (copy) v_u_112, (copy) p_u_109, (copy) v_u_115, (copy) v_u_122, (copy) v_u_121, (copy) v_u_110, (copy) v_u_111, (ref) p_u_39, (copy) v_u_114, (copy) v_u_113, (copy) v_u_118
			local v124 = os.clock() - v_u_123
			local v125 = v124 / 0.12
			local v126 = 1 - (1 - math.clamp(v125, 0, 1)) ^ 3
			local v127 = 1 - (os.clock() - v_u_112.kickAt) / 0.12
			local v128 = math.max(v127, 0)
			local v129 = (v124 - p_u_109) / 0.2
			local v130 = math.clamp(v129, 0, 1)
			local v131 = #v_u_115
			for v132, v133 in v_u_115 do
				local v134 = v132 / v131 * 3.141592653589793 * 2 + v124 * 1.2
				local v135 = (v_u_122 * math.cos(v134) + Vector3.new(0, 1, 0) * math.sin(v134)) * (v126 * 0.2 + 0.8) - v_u_121 * 0.5 * (1 - v126)
				local v136 = (v128 * 0.8 + 2.2) * v_u_110 * v126
				local v137 = v_u_111 + v135.Unit * (0.4 * v_u_110 + v136 / 2)
				local v138 = 0.22 * v_u_110
				local v139 = 0.22 * v_u_110
				local v140 = math.max(v136, 0.05)
				v133.Size = Vector3.new(v138, v139, v140)
				v133.CFrame = p_u_39.aimAt(v137, v135)
				v133.Transparency = v130
			end
			local v141 = v_u_114
			local v142 = (v128 * 1.2 + 1.9) * v_u_110 * v126
			v141.Size = Vector3.new(1, 1, 1) * math.max(v142, 0.05)
			v_u_114.Transparency = v130 * 0.5 + 0.5
			v_u_113.Transparency = v130
			if v130 < 1 then
				return true
			end
			for _, v143 in v_u_118 do
				v143:Destroy()
			end
			v_u_112.done = true
			return false
		end)
		v_u_5.flash(v_u_111, v_u_8, 4 * v_u_110, 0.15)
		return v_u_112
	end
	local function v_u_187(p_u_145, p_u_146, p147) -- name: lob
		-- upvalues: (copy) p_u_39, (copy) v_u_107, (ref) v_u_5, (ref) v_u_10, (ref) v_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (ref) v_u_7, (ref) v_u_11, (copy) v_u_76, (ref) v_u_6
		local v_u_148 = p_u_145.size
		local v_u_149 = p_u_145.lite
		local v150 = math.max(p147, 0.06)
		local v_u_151 = math.min(0.42, v150)
		local v152 = p_u_145.eye + Vector3.new(0, 3.2, 0) * p_u_145.size - p_u_145.dir * 0.6 * p_u_145.size
		local v153 = math.random() - 0.5
		local v154 = math.random() * 0.5
		local v155 = math.random() - 0.5
		local v_u_156 = v152 + Vector3.new(v153, v154, v155)
		local v_u_157 = p_u_39.ground(p_u_146, 0.1)
		local v_u_158 = 3.6 * v_u_148
		local v_u_159 = 9 + (v_u_157 - v_u_156).Magnitude * 0.22
		local function v185() -- name: go
			-- upvalues: (ref) v_u_107, (copy) p_u_145, (ref) v_u_5, (copy) v_u_158, (copy) v_u_148, (copy) v_u_156, (ref) v_u_10, (ref) v_u_15, (copy) v_u_149, (ref) v_u_8, (ref) p_u_39, (ref) v_u_9, (ref) v_u_1, (copy) v_u_151, (copy) v_u_157, (copy) v_u_159
			local v160 = v_u_107[p_u_145]
			if v160 then
				v160.kickAt = os.clock()
			end
			local v161 = v_u_158
			local v162 = Vector3.new(0.3, 0.3, v161)
			local v163 = v_u_148
			local v164 = v_u_148
			local v165 = v162 * Vector3.new(v163, v164, 1)
			local v166 = {
				["material"] = v_u_15
			}
			local v_u_167 = v_u_5.part(v165, CFrame.new(v_u_156), v_u_10, v166)
			v_u_167.Reflectance = 0.2
			local v_u_168
			if v_u_149 then
				v_u_168 = nil
			else
				local v169 = v_u_5.part
				local v170 = 0.75 * v_u_148
				local v171 = 0.75 * v_u_148
				local v172 = v_u_158 * 1.05
				v_u_168 = v169(Vector3.new(v170, v171, v172), CFrame.new(v_u_156), v_u_8, {
					["transparency"] = 0.6
				})
			end
			p_u_39.streak(v_u_167, v_u_8, v_u_9, 0.7 * v_u_148, 0.14)
			v_u_1:AddItem(v_u_167, v_u_151 + 1.5)
			if v_u_168 then
				v_u_1:AddItem(v_u_168, v_u_151 + 1.5)
			end
			local v_u_173 = false
			local v_u_174 = CFrame.identity
			p_u_39.animate(v_u_151, 0, function(p175)
				-- upvalues: (ref) v_u_173, (ref) v_u_156, (ref) v_u_157, (ref) v_u_159, (ref) p_u_39, (ref) v_u_158, (copy) v_u_167, (ref) v_u_168, (ref) v_u_174, (ref) v_u_5, (ref) v_u_1
				if not v_u_173 then
					local v176 = v_u_156:Lerp(v_u_157, p175) + Vector3.new(0, 1, 0) * v_u_159 * 4 * p175 * (1 - p175)
					local v177 = p175 + 0.03
					local v178 = math.min(v177, 1)
					local v179 = v_u_156:Lerp(v_u_157, v178) + Vector3.new(0, 1, 0) * v_u_159 * 4 * v178 * (1 - v178)
					local v180 = p175 - 0.03
					local v181 = math.max(v180, 0)
					local v182 = v179 - (v_u_156:Lerp(v_u_157, v181) + Vector3.new(0, 1, 0) * v_u_159 * 4 * v181 * (1 - v181))
					local v183 = p_u_39.aimAt(v176, v182) * CFrame.new(0, 0, v_u_158 / 2)
					v_u_167.CFrame = v183
					local v184 = v_u_168
					if v184 then
						v184.CFrame = v183
					end
					if p175 >= 1 then
						v_u_173 = true
						v_u_174 = v183 * CFrame.new(0, 0, -v_u_158 * 0.3)
						v_u_167.CFrame = v_u_174
						if v184 then
							v184.CFrame = v_u_174
							p_u_39.fadeOut(v184, 0.25)
						end
						p_u_39.after(0.5, function()
							-- upvalues: (ref) v_u_167, (ref) v_u_5, (ref) v_u_174, (ref) v_u_158, (ref) v_u_1
							if v_u_167.Parent then
								v_u_5.tween(v_u_167, 0.3, {
									["CFrame"] = nil,
									["Transparency"] = 1,
									["CFrame"] = v_u_174 * CFrame.new(0, 0, -v_u_158 * 0.6)
								})
								v_u_1:AddItem(v_u_167, 0.32)
							end
						end)
					end
				end
			end)
		end
		p_u_39.after(p147 - v_u_151, v185)
		p_u_39.after(p147, function()
			-- upvalues: (ref) p_u_39, (copy) p_u_146, (ref) v_u_5, (ref) v_u_8, (copy) p_u_145, (copy) v_u_148, (ref) v_u_7, (ref) v_u_9, (copy) v_u_149, (ref) v_u_11, (ref) v_u_76, (ref) v_u_6
			local v186 = p_u_39.ground(p_u_146)
			v_u_5.ring(v186, v_u_8, (p_u_145.ability.strikeRadius or 5) * v_u_148, 0.3, v_u_7.Ring)
			p_u_39.burst("Impact", v186 + Vector3.new(0, 0.8, 0), v_u_8, 0.8 * v_u_148)
			p_u_39.mark(p_u_146, v_u_9, 2.4 * v_u_148, 1.2, v_u_7.CrackLines, 0.2)
			if not v_u_149 then
				p_u_39.spikes(p_u_39.ground(p_u_146, 0.4), v_u_11, 3, 3 * v_u_148, 0.14, Vector3.new(0, 1, 0), 0.9)
				v_u_76(p_u_39.ground(p_u_146, 0.4), 3, 3 * v_u_148, 0.9 * v_u_148, 0.2)
			end
			v_u_6.play("Hit", {
				["at"] = v186,
				["volume"] = p_u_145.mine and 0.35 or 0.2
			})
		end)
	end
	local v_u_188 = {}
	setmetatable(v_u_188, {
		["__mode"] = "k"
	})
	local function v_u_205(p189, p190) -- name: shatter
		-- upvalues: (ref) v_u_1, (copy) p_u_39
		if not p189.done then
			p189.done = true
			local v_u_191 = {}
			for _, v192 in p189.parts do
				if not v192.Parent then
					continue
				end
				local v193 = v192.Position - p189.knot
				local v194 = {
					["p"] = v192,
					["v"] = ((v193.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v193.Unit) + Vector3.new(0, 1, 0) * (0.5 + math.random() * 0.6)) * p190 * (0.6 + math.random() * 0.7),
					["spin"] = CFrame.Angles(math.random() * 0.3, math.random() * 0.3, 0),
					["cf"] = v192.CFrame
				}
				table.insert(v_u_191, v194)
				v_u_1:AddItem(v192, 1)
			end
			local v_u_195 = os.clock()
			local v_u_196 = v_u_195
			p_u_39.frame(function()
				-- upvalues: (ref) v_u_196, (copy) v_u_195, (copy) v_u_191
				local v197 = os.clock()
				local v198 = v197 - v_u_196
				local v199 = math.min(v198, 0.05)
				v_u_196 = v197
				local v200 = v197 - v_u_195
				for _, v201 in v_u_191 do
					v201.v = v201.v - Vector3.new(0, 70, 0) * v199
					v201.cf = (v201.cf + v201.v * v199) * v201.spin
					v201.p.CFrame = v201.cf
					local v202 = v201.p
					local v203 = (v200 - 0.3) / 0.45
					v202.Transparency = math.clamp(v203, 0, 1)
				end
				if v200 <= 0.75 then
					return true
				end
				for _, v204 in v_u_191 do
					v204.p:Destroy()
				end
				return false
			end)
		end
	end
	local function v_u_236(p206, p207, p208) -- name: startCage
		-- upvalues: (copy) p_u_39, (ref) v_u_5, (ref) v_u_12, (ref) v_u_1, (ref) v_u_8, (ref) v_u_9, (copy) v_u_188
		local v209 = p206.size
		local v210 = p206.lite
		local v211 = p206.ability.radius * v209
		local v212 = v210 and 5 or 9
		local v213 = p208 + 3
		local v214 = {
			["vines"] = nil,
			["parts"] = nil,
			["cfs"] = nil,
			["crushAt"] = nil,
			["done"] = false,
			["knot"] = nil,
			["vines"] = {},
			["parts"] = {},
			["cfs"] = {},
			["knot"] = p_u_39.ground(p207, 3 * v209)
		}
		local v215 = math.random() * 3.141592653589793 * 2
		local v216 = v210 and 5 or 7
		for v217 = 1, v212 do
			local v218 = v215 + (v217 + (math.random() - 0.5) * 0.4) / v212 * 3.141592653589793 * 2
			local v219 = v211 * (0.85 + math.random() * 0.15)
			local v220 = {
				["segs"] = {},
				["thorns"] = {},
				["at"] = {},
				["side"] = {},
				["a"] = v218
			}
			local v221 = p_u_39.ground(p207, -0.6)
			local v222 = math.cos(v218)
			local v223 = math.sin(v218)
			v220.root = v221 + Vector3.new(v222, 0, v223) * v219
			v220.phase = math.random() * 6
			for _ = 1, v216 do
				local v224 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v220.root), v_u_12)
				v_u_1:AddItem(v224, v213)
				local v225 = v220.segs
				table.insert(v225, v224)
				local v226 = v214.parts
				table.insert(v226, v224)
			end
			for v227, v228 in v210 and { 0.45, 0.75 } or {
				0.28,
				0.5,
				0.7,
				0.88
			} do
				local v229 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v220.root), v_u_8, {
					["shape"] = Enum.PartType.Wedge
				})
				v_u_1:AddItem(v229, v213)
				local v230 = v220.thorns
				table.insert(v230, v229)
				local v231 = v220.at
				table.insert(v231, v228)
				local v232 = v220.side
				local v233 = v227 % 2 == 0 and 1 or -1
				table.insert(v232, v233)
				local v234 = v214.parts
				table.insert(v234, v229)
			end
			local v235 = v214.vines
			table.insert(v235, v220)
			p_u_39.burst("Impact", p_u_39.ground(v220.root, 1), v_u_8, 1.1 * v209)
			if v210 then
				break
			end
			p_u_39.chunks(p_u_39.ground(v220.root, 0.6), { p_u_39.EARTH[1], p_u_39.EARTH[2], v_u_9 }, 3, 30, 0.7, 0.8)
		end
		v214.cfs = table.create(#v214.parts, CFrame.identity)
		v_u_188[p206] = v214
		return v214
	end
	local function v_u_307(p237, p238, p239, p240, p241, p242, p243, p244, p245) -- name: poseCage
		-- upvalues: (copy) p_u_39, (ref) v_u_38, (ref) v_u_4
		local v246 = p237.knot
		local v247 = p_u_39.ground(p238, 0)
		local v248 = 0
		for _, v249 in p237.vines do
			local v250 = v249.a
			local v251 = math.cos(v250)
			local v252 = v249.a
			local v253 = math.sin(v252)
			local v254 = Vector3.new(v251, 0, v253)
			local v255 = -v254.Z
			local v256 = v254.X
			local v257 = Vector3.new(v255, 0, v256)
			local v258 = p240 * 12 * (1 - p243 * 0.25)
			local v259 = v249.root
			local v260 = v247.X
			local v261 = v249.root.Y
			local v262 = v247.Z
			local v263 = v259:Lerp(Vector3.new(v260, v261, v262), p243 * 0.22)
			local v264 = v263 + Vector3.new(0, 1, 0) * v258 * 0.75 - v254 * p239 * 0.05
			local v265 = v247 + v254 * p239 * (0.55 - p243 * 0.3) + Vector3.new(0, 1, 0) * v258 * 1.05
			local v266 = p241 * 2.3 + v249.phase
			local v267 = math.sin(v266) * 1.4 * p240
			local v268 = v247 + v254 * p239 * (0.3 - p243 * 0.32)
			local v269 = p244 * 3 * p240
			local v270 = v249.phase * 3
			local v271 = v268 + v257 * (v267 + v269 * math.sin(v270)) + Vector3.new(0, 1, 0) * (v258 * (0.62 - p243 * 0.22) + p244 * 4 * p240)
			local v272 = v249.segs
			local v273 = #v272
			local v274 = p242 * 0
			local v275 = 1 - v274
			local v276 = v263 * (v275 * v275 * v275) + v264 * (v275 * 3 * v275 * v274) + v265 * (v275 * 3 * v274 * v274) + v271 * (v274 * v274 * v274)
			if p245 > 0 then
				v276 = v276:Lerp(v246 + (v276 - v246) * 0.12, p245)
			end
			for v277, v278 in v272 do
				local v279 = v277 / v273
				local v280 = v279 * p242
				local v281 = 1 - v280
				local v282 = v263 * (v281 * v281 * v281) + v264 * (v281 * 3 * v281 * v280) + v265 * (v281 * 3 * v280 * v280) + v271 * (v280 * v280 * v280)
				if p245 > 0 then
					v282 = v282:Lerp(v246 + (v282 - v246) * 0.12, p245)
				end
				local v283 = (2.1 - (v279 - 0.5 / v273) * 1.6) * p240 * (1 - p245 * 0.4)
				local v284 = (v282 - v276).Magnitude + v283 * 0.5
				local v285 = math.max(v284, 0.1)
				v278.Size = Vector3.new(v283, v283, v285)
				v248 = v248 + 1
				p237.cfs[v248] = p_u_39.aimAt((v276 + v282) / 2, v282 - v276)
				v276 = v282
			end
			for v286, v287 in v249.thorns do
				local v288 = v249.at[v286]
				local v289 = v288 * p242
				local v290 = 1 - v289
				local v291 = v263 * (v290 * v290 * v290) + v264 * (v290 * 3 * v290 * v289) + v265 * (v290 * 3 * v289 * v289) + v271 * (v289 * v289 * v289)
				if p245 > 0 then
					v291 = v291:Lerp(v246 + (v291 - v246) * 0.12, p245)
				end
				local v292 = v288 + 0.05
				local v293 = math.min(v292, 1) * p242
				local v294 = 1 - v293
				local v295 = v263 * (v294 * v294 * v294) + v264 * (v294 * 3 * v294 * v293) + v265 * (v294 * 3 * v293 * v293) + v271 * (v293 * v293 * v293)
				if p245 > 0 then
					v295 = v295:Lerp(v246 + (v295 - v246) * 0.12, p245)
				end
				local v296 = v295 - v291
				local v297 = v296.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v296.Unit
				local v298 = v297:Cross(Vector3.new(0, 1, 0))
				local v299 = v298.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or (v298.Unit * v249.side[v286] + Vector3.new(0, 0.3, 0)).Unit
				local v300 = p240 * 2.6 * (1 - v288 * 0.35)
				local v301 = p242 * 1.5 - v288
				local v302 = v300 * math.clamp(v301, 0, 1)
				local v303 = p240 * 0.45
				local v304 = math.max(v302, 0.05)
				local v305 = p240 * 1.3
				v287.Size = Vector3.new(v303, v304, v305)
				v248 = v248 + 1
				local v306 = (2.1 - v288 * 1.6) * p240 * 0.45
				p237.cfs[v248] = v_u_38(v291 + v299 * v306, v299, -v297, (math.max(v302, 0.05)))
			end
		end
		v_u_4:BulkMoveTo(p237.parts, p237.cfs, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v401 = {
		["thorn_blossom_a"] = {
			["cast"] = function(p308) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_39, (ref) v_u_11, (ref) v_u_10
				local v309 = p308.size
				local v310 = p308.eye + p308.dir * 1.2
				v_u_5.flash(v310, v_u_8, 2.8 * v309, 0.1)
				p_u_39.pop(v310, v_u_11, 1 * v309, 0.2 * v309, 0.1)
				if not p308.lite then
					p_u_39.spikes(v310, v_u_10, 3, 2.6 * v309, 0.1, p308.dir, 0.7)
				end
			end,
			["shot"] = v102,
			["impact"] = v106,
			["hit"] = function(_, p311, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_8
				p_u_39.burst("Impact", p311, v_u_8, 0.6)
			end
		},
		["thorn_blossom_e"] = {
			["cast"] = function(p312) -- name: cast
				-- upvalues: (copy) p_u_39, (ref) v_u_8, (ref) v_u_11
				p_u_39.skillCast(p312, v_u_8)
				p_u_39.glint(p312.eye + Vector3.new(0, 3.2, 0) * p312.size - p312.dir * 0.6 * p312.size, v_u_11, 4, 0.16)
			end,
			["windup"] = function(p313, p314, p315) -- name: windup
				-- upvalues: (copy) v_u_144, (copy) v_u_55, (copy) p_u_39, (ref) v_u_7, (ref) v_u_8
				local v316 = p313.size
				local v317 = p313.ability.radius * v316
				v_u_144(p313, p315 + 0.1)
				v_u_55(CFrame.new(p_u_39.ground(p314, 0.15)), v317 * 1.25, v317, v_u_7.Ring, v_u_8, 0.3, 1.5, 0.2)
				p_u_39.mark(p314, v_u_8, v317, p315 + 0.6, v_u_7.Glow, 0.75)
			end,
			["strike"] = function(p318, p319, p320) -- name: strike
				-- upvalues: (copy) v_u_187
				v_u_187(p318, p319, p320)
			end,
			["hit"] = function(p321, p322, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_8, (ref) v_u_10
				p_u_39.burst("Impact", p322, v_u_8, 0.65)
				if not p321.lite then
					p_u_39.spikes(p322, v_u_10, 2, 2.4, 0.12)
				end
			end
		},
		["thorn_blossom_r"] = {
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p323) -- name: cast
				-- upvalues: (copy) p_u_39, (ref) v_u_8, (ref) v_u_11
				p_u_39.skillCast(p323, v_u_8, true)
				p_u_39.glint(p323.eye, v_u_11, 6, 0.2)
			end,
			["windup"] = function(p324, p325, p326) -- name: windup
				-- upvalues: (copy) v_u_55, (copy) p_u_39, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (ref) v_u_5
				local v327 = p324.size
				local v328 = p324.ability.radius * v327
				local v329 = math.max(p326, 0.1)
				v_u_55(CFrame.new(p_u_39.ground(p325, 0.15)), v328 * 1.3, v328, v_u_7.Ring, v_u_8, v329 + 0.1, 2, 0.1)
				p_u_39.mark(p325, v_u_9, v328 * 1.1, 4, v_u_7.CrackLines, 0.1)
				p_u_39.mark(p325, v_u_12, v328, 3.5, v_u_7.Glow, 0.5)
				if not p324.lite then
					for v330 = 1, 8 do
						local v331 = v330 / 8 * 3.141592653589793 * 2
						local v332 = p_u_39.ground(p325, 0.3)
						local v333 = math.cos(v331)
						local v334 = math.sin(v331)
						local v335 = v332 + Vector3.new(v333, 0, v334) * v328 * 0.95
						p_u_39.spikes(v335, v_u_10, 2, 2.5 * v327, 0.2, Vector3.new(0, 1, 0), 0.5)
					end
				end
				if p324.mine then
					v_u_5.shake(0.15, v329)
				end
			end,
			["zone"] = function(p_u_336, p_u_337, p_u_338) -- name: zone
				-- upvalues: (copy) v_u_236, (copy) p_u_39, (ref) v_u_8, (ref) v_u_1, (ref) v_u_5, (ref) v_u_7, (copy) v_u_307, (copy) v_u_205, (ref) v_u_11, (ref) v_u_6
				local v_u_339 = p_u_336.size
				local v_u_340 = p_u_336.lite
				local v_u_341 = p_u_336.ability.radius * v_u_339
				local v_u_342 = v_u_236(p_u_336, p_u_337, p_u_338)
				local v_u_343 = p_u_39.ground(p_u_337, 4 * v_u_339)
				local v_u_344
				if p_u_336.mine and not v_u_340 then
					v_u_344 = p_u_39.ball(v_u_343, v_u_8, 0.2, 1)
					v_u_1:AddItem(v_u_344, p_u_338 + 1)
					p_u_39.light(v_u_344, v_u_8, v_u_341 * 2)
				else
					v_u_344 = nil
				end
				v_u_5.ring(p_u_39.ground(p_u_337), v_u_8, v_u_341 * 1.2, 0.4, v_u_7.Shockwave)
				p_u_39.burst("Shockwave", p_u_39.ground(p_u_337, 0.3), v_u_8, v_u_341 / 16)
				local v_u_345 = os.clock()
				local v_u_346 = -10
				p_u_39.runNow(function()
					-- upvalues: (copy) v_u_342, (copy) v_u_345, (copy) p_u_338, (ref) v_u_346, (ref) v_u_307, (copy) p_u_337, (copy) v_u_341, (copy) v_u_339, (ref) v_u_205
					if v_u_342.done then
						return false
					end
					local v347 = os.clock()
					local v348 = v347 - v_u_345
					local v349 = v348 / 0.28
					local v350 = math.clamp(v349, 0, 1)
					local v351 = (v350 - 1) ^ 3 * 2.2 + 1 + (v350 - 1) ^ 2 * 1.2
					local v352 = v348 / p_u_338
					local v353 = math.clamp(v352, 0, 1)
					local v354 = 1 - (v347 - v_u_346) / 0.22
					local v355 = math.max(v354, 0)
					local v356 = v355 * v355
					local v357 = v_u_342.crushAt
					local v358
					if v357 then
						local v359 = (v347 - v357) / 0.12
						v358 = 1 - (1 - math.clamp(v359, 0, 1)) ^ 3
					else
						v358 = 0
					end
					v_u_307(v_u_342, p_u_337, v_u_341, v_u_339, v348, math.max(v351, 0.02), v353, v356, v358)
					if p_u_338 + 1 >= v348 then
						return true
					end
					v_u_205(v_u_342, 10 * v_u_339)
					return false
				end)
				local v_u_360 = true
				local v_u_361 = p_u_336.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (copy) v_u_361, (ref) v_u_360, (copy) v_u_345, (copy) p_u_338, (ref) v_u_346, (copy) v_u_340, (copy) v_u_339, (ref) p_u_39, (copy) p_u_337, (copy) v_u_341, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (copy) v_u_343, (copy) p_u_336
					local v362 = v_u_361
					task.wait((math.min(v362, 0.3)))
					while v_u_360 and os.clock() - v_u_345 < p_u_338 + 1 do
						v_u_346 = os.clock()
						for _ = 1, v_u_340 and 2 or 4 do
							local v363 = math.random() * 3.141592653589793 * 2
							local v364 = v363 + 3.141592653589793 * (0.6 + math.random() * 0.8)
							local v365 = (1 + math.random() * 5) * v_u_339
							local v366 = p_u_39.ground(p_u_337, v365)
							local v367 = math.cos(v363)
							local v368 = math.sin(v363)
							local v369 = v366 + Vector3.new(v367, 0, v368) * v_u_341 * 0.75
							local v370 = p_u_39.ground(p_u_337, v365 * 0.5)
							local v371 = math.cos(v364)
							local v372 = math.sin(v364)
							local v373 = v370 + Vector3.new(v371, 0, v372) * v_u_341 * 0.75
							local v374 = p_u_39.thin
							local v375 = p_u_39.rod
							local v376 = 0.3 * v_u_339
							local v377
							if math.random() < 0.5 then
								v377 = v_u_11
							else
								v377 = v_u_8
							end
							v374(v375(v369, v373, v376, v377), 0.16)
						end
						v_u_5.ring(p_u_39.ground(p_u_337), v_u_8, v_u_341 * 0.9, 0.25, v_u_7.Ring)
						if not v_u_340 then
							p_u_39.inward(p_u_39.ground(p_u_337, 1.5), v_u_8, 5, v_u_341, 0.25)
							for _ = 1, 2 do
								local v378 = math.random() * 3.141592653589793 * 2
								local v379 = v_u_341
								local v380 = math.random()
								local v381 = v379 * math.sqrt(v380) * 0.8
								local v382 = p_u_39.burst
								local v383 = p_u_39.ground(p_u_337, 1)
								local v384 = math.cos(v378)
								local v385 = math.sin(v378)
								v382("Impact", v383 + Vector3.new(v384, 0, v385) * v381, v_u_8, 0.9 * v_u_339)
							end
						end
						v_u_6.play("Hit", {
							["at"] = v_u_343,
							["volume"] = p_u_336.mine and 0.4 or 0.2
						})
						task.wait(v_u_361)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_360, (copy) v_u_342, (ref) v_u_344
					v_u_360 = false
					v_u_342.crushAt = os.clock()
					local v386 = v_u_344
					if v386 then
						v386:Destroy()
					end
				end
			end,
			["finish"] = function(p387, p388) -- name: finish
				-- upvalues: (copy) p_u_39, (copy) v_u_188, (ref) v_u_5, (ref) v_u_8, (ref) v_u_10, (ref) v_u_15, (ref) v_u_7, (ref) v_u_11, (copy) v_u_205, (copy) v_u_76, (ref) v_u_9, (ref) v_u_6, (copy) v_u_81
				local v389 = p387.size
				local v390 = p387.lite
				local v_u_391 = p387.ability.radius * v389
				local v_u_392 = p_u_39.ground(p388)
				local v393 = v_u_188[p387]
				v_u_188[p387] = nil
				local v394
				if v393 then
					v394 = v393.knot
				else
					v394 = p_u_39.ground(p388, 3 * v389)
				end
				v_u_5.flash(v394, v_u_8, v_u_391 * 1.4, 0.16)
				p_u_39.pop(v394, v_u_10, 3 * v389, v_u_391 * 0.9, 0.3, 0.05, v_u_15)
				p_u_39.pop(p_u_39.ground(p388, 2), v_u_8, v_u_391 * 0.5, v_u_391 * 2.2, 0.45, 0.35)
				p_u_39.burst("Explosion", v394, v_u_8, v_u_391 / 7)
				p_u_39.burst("Shockwave", v_u_392 + Vector3.new(0, 0.3, 0), v_u_8, v_u_391 / 14)
				v_u_5.ring(v_u_392, v_u_8, v_u_391 * 1.4, 0.5, v_u_7.Shockwave)
				p_u_39.after(0.06, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_392, (ref) v_u_11, (copy) v_u_391, (ref) v_u_7
					v_u_5.ring(v_u_392, v_u_11, v_u_391 * 1.6, 0.45, v_u_7.Ring)
				end)
				if v393 then
					v_u_205(v393, 22 * v389)
				end
				p_u_39.spikes(v394, v_u_8, v390 and 6 or 12, v_u_391, 0.35, nil, nil, true)
				v_u_76(v394, v390 and 5 or 12, v_u_391 * 0.9, 2.2 * v389, 0.4)
				p_u_39.mark(p388, v_u_10, v_u_391 * 0.7, 2.5, v_u_7.CrackGlow, 0.1)
				p_u_39.mark(p388, v_u_8, v_u_391 * 0.6, 2, v_u_7.CrackLines, 0.2)
				p_u_39.chunks(p_u_39.ground(p388, 1), {
					p_u_39.EARTH[1],
					p_u_39.EARTH[2],
					v_u_9,
					p_u_39.EARTH[4]
				}, v390 and 6 or 14, 55, 1.2, 1.3, false, 1.1)
				v_u_6.play("Explosion", {
					["at"] = v_u_392,
					["volume"] = p387.mine and 1 or 0.6
				})
				if p387.mine then
					v_u_5.shake(0.55, 0.5)
					v_u_81()
				end
			end,
			["hit"] = function(p395, p396, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_8, (ref) v_u_11
				p_u_39.burst("Impact", p396, v_u_8, 0.7)
				if not p395.lite then
					local v397 = math.random() * 3.141592653589793
					local v398 = math.cos(v397)
					local v399 = math.sin(v397)
					local v400 = Vector3.new(v398, 0.6, v399).Unit * 1.6
					p_u_39.thin(p_u_39.rod(p396 - v400, p396 + v400, 0.2, v_u_11), 0.12)
				end
			end
		}
	}
	return v401
end