local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("F4F2FF")
local v_u_8 = Color3.fromHex("1A1A2E")
local v_u_9 = Color3.fromRGB(190, 176, 255)
local v_u_10 = Color3.fromRGB(150, 110, 255)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Ball
local function v_u_24(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part
	local v19 = p14 * 2
	local v20 = p14 * 2
	local v21 = v18(Vector3.new(v19, 0.05, v20), p13, p16, {
		["transparency"] = 1
	})
	for _, v22 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v23 = Instance.new("Decal")
		v23.Face = v22
		v23.Texture = p15
		v23.Color3 = p16
		v23.Transparency = p17
		v23.Parent = v21
	end
	return v21
end
local function v_u_28(p25, p26) -- name: setAlpha
	for _, v27 in p25:GetChildren() do
		if not v27:IsA("Decal") then
			continue
		end
		v27.Transparency = p26
	end
end
local function v_u_36(p29, p30, p31, p32) -- name: lightLine
	-- upvalues: (copy) v_u_6
	local v33 = Instance.new("Attachment")
	v33.Parent = p29
	local v34 = Instance.new("Attachment")
	v34.Parent = p29
	local v35 = Instance.new("Beam")
	v35.Attachment0 = v33
	v35.Attachment1 = v34
	v35.Color = ColorSequence.new(p30, p31)
	v35.LightEmission = 1
	v35.LightInfluence = 0
	v35.Brightness = 1.4
	v35.FaceCamera = true
	v35.Width0 = p32
	v35.Width1 = p32
	v35.Segments = 14
	v35.Texture = v_u_6.Beam
	v35.TextureMode = Enum.TextureMode.Wrap
	v35.TextureLength = 6
	v35.TextureSpeed = 1.5
	v35.Parent = p29
	return v33, v34, v35
end
local function v_u_44(p37, p38, p39, p40, p41) -- name: starSpray
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_11, (copy) v_u_9, (copy) v_u_1
	local v42 = Instance.new("Attachment")
	v42.WorldPosition = p37
	v42.Parent = v_u_3.Terrain
	local v43 = Instance.new("ParticleEmitter")
	v43.Texture = v_u_6.AstralStar
	v43.Color = ColorSequence.new(v_u_11, v_u_9)
	v43.LightEmission = 0.8
	v43.LightInfluence = 0
	v43.Lifetime = NumberRange.new(p41 * 0.6, p41)
	v43.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p39), NumberSequenceKeypoint.new(0.6, p39 * 0.8), NumberSequenceKeypoint.new(1, 0) })
	v43.Rotation = NumberRange.new(-20, 20)
	v43.Speed = NumberRange.new(p40 * 0.4, p40)
	v43.SpreadAngle = Vector2.new(180, 180)
	v43.Drag = 5
	v43.Rate = 0
	v43.Enabled = false
	v43.Parent = v42
	v43:Emit(p38)
	v_u_1:AddItem(v42, p41 + 0.2)
end
return function(p_u_45)
	-- upvalues: (copy) v_u_24, (copy) v_u_1, (copy) v_u_28, (copy) v_u_3, (copy) v_u_6, (copy) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_44, (copy) v_u_36, (copy) v_u_5
	local function v_u_62(p_u_46, p_u_47, p_u_48, p49, p50, p_u_51, p_u_52, p53) -- name: bloom
		-- upvalues: (ref) v_u_24, (ref) v_u_1, (copy) p_u_45, (ref) v_u_28
		local v_u_54 = p53 or 0
		local v_u_55 = v_u_24(p_u_46, p_u_47, p49, p50, v_u_54)
		v_u_1:AddItem(v_u_55, p_u_51 + 0.1)
		p_u_45.animate(p_u_51, 0, function(p56)
			-- upvalues: (copy) v_u_55, (copy) p_u_47, (copy) p_u_48, (copy) p_u_46, (copy) p_u_51, (copy) p_u_52, (ref) v_u_28, (copy) v_u_54
			local v57 = 1 - (1 - p56) ^ 3
			local v58 = v_u_55
			local v59 = p_u_47 + (p_u_48 - p_u_47) * v57
			local v60 = v59 * 2
			local v61 = v59 * 2
			v58.Size = Vector3.new(v60, 0.05, v61)
			v_u_55.CFrame = p_u_46 * CFrame.Angles(0, p56 * p_u_51 * p_u_52, 0)
			v_u_28(v_u_55, v_u_54 + (1 - v_u_54) * p56 ^ 1.6)
			if p56 >= 1 then
				v_u_55:Destroy()
			end
		end)
	end
	local function v_u_71(p63, p64, p65, p66, p67) -- name: flowerPop
		-- upvalues: (ref) v_u_3, (copy) v_u_62, (copy) p_u_45, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7
		local v68 = v_u_3.CurrentCamera
		local v69
		if v68 then
			local v70 = v68.CFrame.Position - p63
			v69 = v70.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v70.Unit
		else
			v69 = Vector3.new(0, 0, 1)
		end
		v_u_62(p_u_45.facing(p63 + v69 * 0.45, v69), p64 * 1.08, p65 * 1.08, v_u_6.AstralPetals, v_u_10, p66, 2.2)
		v_u_62(p_u_45.facing(p63 + v69 * 0.6, v69), p64, p65, v_u_6.AstralPetals, p67 or v_u_7, p66, 2.2)
	end
	local function v101(p72, p73) -- name: petalShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) p_u_45, (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1
		local v_u_74 = p72.size
		local v_u_75 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p73, v_u_7, {
			["transparency"] = 1
		})
		local v_u_76 = v_u_4.part(Vector3.new(0.8, 0.36, 2.8) * v_u_74, p73, v_u_7)
		local v77 = Instance.new("SpecialMesh")
		v77.MeshType = Enum.MeshType.Sphere
		v77.Parent = v_u_76
		local v_u_78 = v_u_4.part(Vector3.new(1.7, 1, 3.6) * v_u_74, p73, v_u_10, {
			["transparency"] = 0.5
		})
		local v79 = Instance.new("SpecialMesh")
		v79.MeshType = Enum.MeshType.Sphere
		v79.Parent = v_u_78
		local v80 = {
			["shape"] = v_u_12
		}
		local v_u_81 = v_u_4.part(Vector3.new(0.5, 0.5, 0.5) * v_u_74, p73, v_u_11, v80)
		p_u_45.streak(v_u_75, v_u_10, v_u_8, 1.1 * v_u_74, 0.16)
		local v82 = { v_u_76, v_u_78, v_u_81 }
		for _, v83 in { -1, 1 } do
			local v84 = Instance.new("Attachment")
			local v85 = v83 * 0.5 * v_u_74
			local v86 = 0.11 * v_u_74
			local v87 = 0.8 * v_u_74
			v84.Position = Vector3.new(v85, v86, v87)
			v84.Parent = v_u_76
			local v88 = Instance.new("Attachment")
			local v89 = v83 * 0.5 * v_u_74
			local v90 = -0.11 * v_u_74
			local v91 = 0.8 * v_u_74
			v88.Position = Vector3.new(v89, v90, v91)
			v88.Parent = v_u_76
			local v92 = Instance.new("Trail")
			v92.Attachment0 = v84
			v92.Attachment1 = v88
			v92.Color = ColorSequence.new(v_u_11, v_u_10)
			v92.Transparency = NumberSequence.new(0, 1)
			v92.Lifetime = 0.22
			v92.LightEmission = 1
			v92.LightInfluence = 0
			v92.FaceCamera = true
			v92.MinLength = 0.05
			v92.Parent = v_u_76
		end
		local v_u_93
		if p72.lite then
			v_u_93 = nil
		else
			v_u_93 = Instance.new("ParticleEmitter")
			v_u_93.Texture = v_u_6.AstralStar
			v_u_93.Color = ColorSequence.new(v_u_11, v_u_9)
			v_u_93.LightEmission = 0.8
			v_u_93.LightInfluence = 0
			v_u_93.Lifetime = NumberRange.new(0.2, 0.35)
			v_u_93.Size = NumberSequence.new(0.7 * v_u_74, 0)
			v_u_93.Speed = NumberRange.new(0, 1.5)
			v_u_93.SpreadAngle = Vector2.new(180, 180)
			v_u_93.Rate = 34
			v_u_93.Parent = v_u_75
		end
		if p72.mine then
			p_u_45.light(v_u_75, v_u_9, 8 * v_u_74)
		end
		for _, v94 in v82 do
			v_u_1:AddItem(v94, 3)
		end
		v_u_1:AddItem(v_u_75, 3)
		local v_u_95 = false
		return {
			["place"] = function(p96, p97) -- name: place
				-- upvalues: (copy) v_u_75, (copy) v_u_76, (copy) v_u_78, (copy) v_u_81, (copy) v_u_74
				v_u_75.CFrame = p96
				local v98 = p96 * CFrame.Angles(0, 0, p97 * 9)
				v_u_76.CFrame = v98
				v_u_78.CFrame = v98
				v_u_81.CFrame = p96 * CFrame.new(0, 0, -0.35 * v_u_74)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_95, (ref) v_u_93, (copy) v_u_75, (ref) v_u_1, (copy) v_u_76, (copy) v_u_78, (copy) v_u_81
				if not v_u_95 then
					v_u_95 = true
					local v99 = v_u_93
					if v99 then
						v99.Enabled = false
					end
					local v100 = v_u_75:FindFirstChildWhichIsA("PointLight")
					if v100 then
						v100:Destroy()
					end
					v_u_1:AddItem(v_u_75, 0.4)
					v_u_76.Transparency = 1
					v_u_1:AddItem(v_u_76, 0.25)
					v_u_78:Destroy()
					v_u_81:Destroy()
				end
			end
		}
	end
	local function v105(p102, p103) -- name: petalImpact
		-- upvalues: (copy) v_u_71, (copy) p_u_45, (ref) v_u_9, (ref) v_u_11, (ref) v_u_4, (ref) v_u_6, (ref) v_u_44
		local v104 = p102.size
		v_u_71(p103, 0.8 * v104, 3.6 * v104, 0.26)
		p_u_45.pop(p103, v_u_9, 1.2 * v104, 4.4 * v104, 0.18, 0.35)
		p_u_45.pop(p103, v_u_11, 0.9 * v104, 2 * v104, 0.1)
		p_u_45.glint(p103, v_u_11, 4 * v104, 0.16)
		v_u_4.ring(p_u_45.ground(p103), v_u_9, p102.ability.radius * 0.8 * v104, 0.25, v_u_6.Ring)
		if not p102.lite then
			v_u_44(p103, 5, 0.8 * v104, 10 * v104, 0.4)
		end
		p_u_45.hitSound(p103)
	end
	local function v193(p106, p_u_107, p_u_108) -- name: constellation
		-- upvalues: (copy) p_u_45, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_11, (ref) v_u_12, (ref) v_u_24, (ref) v_u_6, (ref) v_u_10, (ref) v_u_36, (ref) v_u_3, (ref) v_u_28, (copy) v_u_71, (ref) v_u_9, (ref) v_u_44
		local v_u_109 = p106.size
		local v_u_110 = p106.lite
		local v_u_111 = p106.ability.radius * v_u_109 * 0.92
		local v_u_112 = p106.ability.freeze or 2.5
		local v_u_113 = p_u_108 + v_u_112 + 0.6
		local v_u_114 = p_u_45.ground(p_u_107, 2.4)
		local v115 = p106.dir.Z
		local v116 = p106.dir.X
		local v_u_117 = math.atan2(v115, v116)
		local v118 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_114), v_u_7, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v118, v_u_113 + 0.5)
		local function v123(p119) -- name: newStar
			-- upvalues: (ref) v_u_4, (copy) v_u_114, (ref) v_u_11, (ref) v_u_12, (ref) v_u_24, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) v_u_113
			local v120 = {
				["shape"] = v_u_12
			}
			local v121 = v_u_4.part(Vector3.new(0.05, 0.05, 0.05), CFrame.new(v_u_114), v_u_11, v120)
			local v122 = v_u_24(CFrame.new(v_u_114), 0.1, v_u_6.AstralStar, v_u_7, 0)
			v_u_1:AddItem(v121, v_u_113 + 0.5)
			v_u_1:AddItem(v122, v_u_113 + 0.5)
			return {
				["core"] = v121,
				["shine"] = v122,
				["size"] = p119
			}
		end
		local v_u_124 = v123(4.8 * v_u_109)
		local v_u_125 = {}
		for _ = 1, 5 do
			local v126 = v123(3.6 * v_u_109)
			table.insert(v_u_125, v126)
		end
		local v_u_127 = {}
		for _ = 1, 5 do
			local v128 = v_u_24(CFrame.new(v_u_114), 0.1, v_u_6.Ring, v_u_10, 0.1)
			v_u_1:AddItem(v128, v_u_113 + 0.5)
			table.insert(v_u_127, v128)
		end
		local v_u_129 = {}
		for v130 = 1, 5 do
			for _, v131 in { -1, 1 } do
				local v132, v133, v134 = v_u_36(v118, v_u_7, v_u_10, (v_u_110 and 0.7 or 1) * v_u_109)
				table.insert(v_u_129, {
					["a0"] = v132,
					["a1"] = v133,
					["beam"] = v134,
					["tip"] = v130,
					["side"] = v131
				})
			end
		end
		local v_u_135 = os.clock()
		p_u_45.runNow(function()
			-- upvalues: (copy) v_u_135, (copy) v_u_113, (copy) v_u_117, (copy) p_u_108, (copy) v_u_112, (copy) v_u_114, (ref) v_u_3, (ref) p_u_45, (ref) v_u_28, (copy) v_u_125, (copy) p_u_107, (copy) v_u_111, (copy) v_u_124, (copy) v_u_127, (copy) v_u_109, (copy) v_u_129
			local v_u_136 = os.clock() - v_u_135
			if v_u_113 <= v_u_136 then
				return false
			end
			local v137 = v_u_117 + v_u_136 * 0.35
			local v138 = p_u_108
			local v139 = v_u_136 / math.max(v138, 0.1)
			local v140 = math.clamp(v139, 0, 1) - 1
			local v141 = v140 * 2.7 * v140 * v140 + 1 + v140 * 1.7 * v140
			local v142 = (v_u_136 - p_u_108) / 0.22
			local v143 = 1 - (1 - math.clamp(v142, 0, 1)) ^ 3
			local v144 = (v_u_136 - p_u_108 - v_u_112) / 0.35
			local v_u_145 = math.clamp(v144, 0, 1)
			local v146 = v_u_114
			local v147 = v_u_3.CurrentCamera
			local v_u_148
			if v147 then
				local v149 = v147.CFrame.Position - v146
				v_u_148 = v149.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v149.Unit
			else
				v_u_148 = Vector3.new(0, 0, 1)
			end
			local function v162(p150, p151, p152) -- name: placeStar
				-- upvalues: (copy) v_u_136, (copy) v_u_145, (ref) p_u_45, (copy) v_u_148, (ref) v_u_28
				local v153 = v_u_136 * 9 + p151.X
				local v154 = math.sin(v153) * 0.12 + 1
				local v155 = p150.core
				local v156 = p150.size * 0.3 * p152
				v155.Size = Vector3.new(1, 1, 1) * math.max(v156, 0.05)
				p150.core.CFrame = CFrame.new(p151)
				p150.core.Transparency = v_u_145
				local v157 = p150.shine
				local v158 = p150.size * p152 * v154
				local v159 = math.max(v158, 0.05)
				local v160 = v159 * 2
				local v161 = v159 * 2
				v157.Size = Vector3.new(v160, 0.05, v161)
				p150.shine.CFrame = p_u_45.facing(p151 + v_u_148 * 0.3, v_u_148)
				v_u_28(p150.shine, v_u_145)
			end
			local v163 = {}
			for v164, v165 in v_u_125 do
				local v166 = v137 + (v164 - 1) * 3.141592653589793 * 2 / 5
				local v167 = math.cos(v166)
				local v168 = math.sin(v166)
				local v169 = Vector3.new(v167, 0, v168)
				local v170 = p_u_45.ground(p_u_107, v141 * 2.4) + v169 * v_u_111
				v163[v164] = v170
				v162(v165, v170, (math.clamp(v141, 0, 1.2)))
			end
			v162(v_u_124, v_u_114, (math.clamp(v141, 0, 1.2)))
			for v171, v172 in v_u_127 do
				local v173 = v137 + (v171 - 0.5) * 3.141592653589793 * 2 / 5
				local v174 = v_u_114
				local v175 = math.cos(v173)
				local v176 = math.sin(v173)
				local v177 = v174 + Vector3.new(v175, 0, v176) * v_u_111 * 0.62
				local v178 = 2.2 * v_u_109 * v143
				local v179 = math.max(v178, 0.05)
				local v180 = v179 * 2
				local v181 = v179 * 2
				v172.Size = Vector3.new(v180, 0.05, v181)
				v172.CFrame = CFrame.new(v177)
				local v182 = v_u_28
				local v183 = 1 - v143
				v182(v172, math.max(v_u_145, v183) * 0.9 + 0.1)
			end
			for _, v184 in v_u_129 do
				local v185 = v163[v184.tip] - v_u_114
				local v186 = v185.Magnitude
				local v187 = v186 <= 0.001 and Vector3.new(1, 0, 0) or v185 / v186
				local v188 = (Vector3.new(0, 1, 0)):Cross(v187) * v184.side
				local v189 = v187 * 0.7960837985490559 + v188 * 0.6051864057360395
				local v190 = v187 * 0.9210609940028851 - v188 * 0.3894183423086505
				local v191 = math.max(v143, 0.01)
				v184.a0.WorldCFrame = CFrame.fromMatrix(v_u_114, v189, Vector3.new(0, 1, 0))
				v184.a1.WorldCFrame = CFrame.fromMatrix(v_u_114 + v185 * v191, v190, Vector3.new(0, 1, 0))
				v184.beam.CurveSize0 = v186 * 0.55 * v191
				v184.beam.CurveSize1 = v186 * 0.3 * v191
				v184.beam.Transparency = NumberSequence.new(v_u_145)
			end
			return true
		end)
		p_u_45.after(p_u_108 + v_u_112, function()
			-- upvalues: (copy) v_u_125, (ref) p_u_45, (ref) v_u_11, (copy) v_u_109, (copy) v_u_110, (ref) v_u_71, (copy) v_u_114, (copy) v_u_111, (ref) v_u_9, (ref) v_u_44
			for _, v192 in v_u_125 do
				p_u_45.glint(v192.core.Position, v_u_11, 4 * v_u_109, 0.2)
			end
			if not v_u_110 then
				v_u_71(v_u_114, 4 * v_u_109, v_u_111 * 1.1, 0.45, v_u_9)
				v_u_44(v_u_114, 12, 1.4 * v_u_109, 18 * v_u_109, 0.6)
			end
		end)
		p_u_45.after(p_u_108, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_114, (ref) v_u_7, (copy) v_u_109, (ref) p_u_45, (ref) v_u_11, (copy) p_u_107, (ref) v_u_9, (copy) v_u_111, (ref) v_u_6, (copy) v_u_110
			v_u_4.flash(v_u_114, v_u_7, 6 * v_u_109, 0.2)
			p_u_45.glint(v_u_114, v_u_11, 6 * v_u_109, 0.2)
			v_u_4.ring(p_u_45.ground(p_u_107), v_u_9, v_u_111 * 1.05, 0.4, v_u_6.Ring)
			if not v_u_110 then
				p_u_45.inward(v_u_114, v_u_7, 8, v_u_111, 0.22)
			end
		end)
	end
	local v_u_194 = {}
	setmetatable(v_u_194, {
		["__mode"] = "k"
	})
	local function v_u_202(p195, p196, p197, p198, p199) -- name: starBeam
		-- upvalues: (copy) p_u_45, (ref) v_u_10, (ref) v_u_11, (copy) v_u_71, (ref) v_u_9, (ref) v_u_4, (ref) v_u_6, (ref) v_u_5
		local v200 = p195.size
		local v201 = (p195.ability.strikeRadius or 8) * v200
		p_u_45.glowBeam(p196, p197, v_u_10, p198 * 2.6, 0.32)
		p_u_45.thin(p_u_45.rod(p196, p197, p198, v_u_11), 0.3)
		p_u_45.pop(p196, v_u_11, 2 * v200, 4.5 * v200, 0.18)
		if not p199 then
			v_u_71(p197 + Vector3.new(0, 1.5, 0), 1.5 * v200, v201 * 0.85, 0.32)
			p_u_45.pop(p197 + Vector3.new(0, 1, 0), v_u_9, 2 * v200, v201 * 1.2, 0.25, 0.4)
			v_u_4.ring(p_u_45.ground(p197), v_u_9, v201, 0.35, v_u_6.Ring)
			p_u_45.burst("Impact", p197 + Vector3.new(0, 1, 0), v_u_11, 1.2 * v200)
			if not p195.lite then
				p_u_45.spikes(p197 + Vector3.new(0, 1, 0), v_u_11, 6, 6 * v200, 0.2, Vector3.new(0, 1, 0), 0.7)
				p_u_45.mark(p197, v_u_9, v201 * 0.6, 0.8, v_u_6.Glow, 0.3)
			end
			v_u_5.play("Hit", {
				["at"] = p197,
				["volume"] = p195.mine and 0.6 or 0.35
			})
		end
	end
	local function v_u_215(p203, p204, p205) -- name: nova
		-- upvalues: (copy) p_u_45, (ref) v_u_10, (ref) v_u_11, (ref) v_u_4, (ref) v_u_9, (copy) v_u_71, (ref) v_u_6, (ref) v_u_44, (ref) v_u_5
		local v206 = p203.size
		local v207 = p203.lite
		local v208 = p203.ability.radius * v206
		local v209 = p_u_45.ground(p204, 0.2)
		for _, v210 in p205 do
			local v211 = v209 + Vector3.new(0, 1.5, 0)
			local v212 = 1.4 * v206
			local v213 = p203.size
			local _ = (p203.ability.strikeRadius or 8) * v213
			p_u_45.glowBeam(v210, v211, v_u_10, v212 * 2.6, 0.32)
			p_u_45.thin(p_u_45.rod(v210, v211, v212, v_u_11), 0.3)
			p_u_45.pop(v210, v_u_11, 2 * v213, 4.5 * v213, 0.18)
		end
		local v214 = v209 + Vector3.new(0, 2, 0)
		v_u_4.flash(v214, v_u_11, v208 * 1.4, 0.3)
		p_u_45.pop(v214, v_u_11, 4, v208 * 1.3, 0.4, 0.2)
		p_u_45.pop(v209, v_u_9, v208 * 0.5, v208 * 2.2, 0.55, 0.45)
		v_u_71(v214, 4 * v206, v208 * 1.15, 0.55)
		v_u_4.ring(v209, v_u_11, v208 * 1.2, 0.5, v_u_6.Shockwave)
		v_u_4.ring(v209, v_u_9, v208 * 1.5, 0.65, v_u_6.Ring)
		p_u_45.burst("Flash", v214, v_u_11, 0.7, true)
		p_u_45.burst("Shockwave", v209 + Vector3.new(0, 0.3, 0), v_u_9, v208 / 14)
		p_u_45.spikes(v214, v_u_11, v207 and 6 or 14, v208 * 1.1, 0.35)
		if not v207 then
			v_u_44(v214, 22, 2 * v206, 34 * v206, 0.9)
			p_u_45.mark(p204, v_u_9, v208 * 0.9, 1.2, v_u_6.Glow, 0.25)
		end
		v_u_5.play("Explosion", {
			["at"] = v214,
			["volume"] = p203.mine and 1 or 0.6
		})
		if p203.mine then
			v_u_4.shake(0.5, 0.45)
		end
	end
	local v317 = {
		["astral_bloom_a"] = {
			["cast"] = function(p216) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_45, (ref) v_u_11, (copy) v_u_62, (ref) v_u_6, (ref) v_u_7
				local v217 = p216.size
				local v218 = p216.eye + p216.dir * 1.2
				v_u_4.flash(v218, v_u_9, 3 * v217, 0.1)
				p_u_45.pop(v218, v_u_11, 1.2 * v217, 0.3 * v217, 0.1)
				if not p216.lite then
					v_u_62(p_u_45.facing(v218, -p216.dir), 0.5 * v217, 1.5 * v217, v_u_6.AstralPetals, v_u_7, 0.12, 20)
				end
			end,
			["shot"] = v101,
			["impact"] = v105,
			["hit"] = function(_, p219, _) -- name: hit
				-- upvalues: (copy) p_u_45, (ref) v_u_9
				p_u_45.burst("Impact", p219, v_u_9, 0.6)
			end
		},
		["astral_bloom_e"] = {
			["cast"] = function(p220) -- name: cast
				-- upvalues: (copy) p_u_45, (ref) v_u_9, (copy) v_u_62, (ref) v_u_6, (ref) v_u_7, (ref) v_u_11
				p_u_45.skillCast(p220, v_u_9)
				local v221 = p220.size
				local v222 = p220.eye + p220.dir * 1.4
				v_u_62(p_u_45.facing(v222, -p220.dir), 1 * v221, 3.4 * v221, v_u_6.AstralPetals, v_u_7, 0.3, -6)
				p_u_45.glint(v222, v_u_11, 4 * v221, 0.16)
			end,
			["windup"] = v193,
			["hit"] = function(p223, p224, _) -- name: hit
				-- upvalues: (ref) v_u_3, (copy) p_u_45, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11
				local v225 = v_u_3.CurrentCamera
				local v226
				if v225 then
					local v227 = v225.CFrame.Position - p224
					v226 = v227.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v227.Unit
				else
					v226 = Vector3.new(0, 0, 1)
				end
				p_u_45.sigil(p_u_45.facing(p224 + Vector3.new(0, 0.4, 0) + v226 * 1.2, v226), 1.6, v_u_7, v_u_6.AstralPetals, p223.ability.freeze or 2.5, 1.8)
				p_u_45.glint(p224, v_u_11, 2.6, 0.14)
			end
		},
		["astral_bloom_r"] = {
			["cast"] = function(p228) -- name: cast
				-- upvalues: (copy) p_u_45, (ref) v_u_9, (copy) v_u_62, (ref) v_u_6, (ref) v_u_7, (ref) v_u_44, (ref) v_u_4
				p_u_45.skillCast(p228, v_u_9, true)
				local v229 = p228.size
				local v230 = p228.eye + p228.dir * 1.5
				v_u_62(p_u_45.facing(v230, -p228.dir), 1.2 * v229, 4.6 * v229, v_u_6.AstralPetals, v_u_7, 0.34, 9)
				p_u_45.burst("Flash", p228.eye, v_u_9, 0.35)
				if not p228.lite then
					v_u_44(p228.eye, 8, 0.9 * v229, 12 * v229, 0.5)
				end
				if p228.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p_u_231, p_u_232, p_u_233) -- name: sky
				-- upvalues: (copy) p_u_45, (copy) v_u_194, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (ref) v_u_11, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_12, (ref) v_u_24, (ref) v_u_36, (ref) v_u_3, (ref) v_u_28, (copy) v_u_215
				local v_u_234 = p_u_231.size
				local v235 = p_u_231.lite
				local v236 = p_u_45.ground(p_u_232, 22)
				local v237 = 11 * v_u_234
				local v238 = p_u_231.dir.Z
				local v239 = p_u_231.dir.X
				local v240 = math.atan2(v238, v239)
				local v_u_241 = p_u_233 + 0.5
				local v_u_242 = {}
				for v243 = 1, 5 do
					local v244 = v240 + (v243 - 1) * 3.141592653589793 * 2 / 5
					local v245 = math.cos(v244)
					local v246 = math.sin(v244)
					local v247 = v236 + Vector3.new(v245, 0, v246) * v237
					table.insert(v_u_242, v247)
				end
				v_u_194[p_u_231] = {
					["stars"] = nil,
					["fired"] = 0,
					["stars"] = v_u_242
				}
				task.delay(v_u_241 + 1, function()
					-- upvalues: (ref) v_u_194, (copy) p_u_231
					v_u_194[p_u_231] = nil
				end)
				p_u_45.sigil(p_u_45.facing(v236 + Vector3.new(0, 0.6, 0), Vector3.new(-0, -1, -0)), v237 * 1.25, v_u_10, v_u_6.AstralPetals, v_u_241, 0.4)
				p_u_45.sigil(p_u_45.facing(v236 + Vector3.new(0, 0.4, 0), Vector3.new(-0, -1, -0)), v237 * 1.35, v_u_9, v_u_6.Ring, v_u_241, -0.3)
				p_u_45.sigil(p_u_45.facing(v236 + Vector3.new(0, 0.8, 0), Vector3.new(-0, -1, -0)), 4.2 * v_u_234, v_u_11, p_u_45.iris("astral_bloom"), v_u_241, 0.25)
				local v248 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v236), v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v248, v_u_241 + 0.3)
				local v_u_249 = {}
				for v250, v251 in v_u_242 do
					local v252 = {
						["shape"] = v_u_12
					}
					local v253 = v_u_4.part(Vector3.new(0.05, 0.05, 0.05), CFrame.new(v251), v_u_11, v252)
					local v254 = v_u_24(CFrame.new(v251), 0.05, v_u_6.AstralStar, v_u_7, 0)
					local v255 = v_u_24(CFrame.new(v251), 0.05, v_u_6.Ring, v_u_9, 0)
					for _, v256 in { v253, v254, v255 } do
						v_u_1:AddItem(v256, v_u_241 + 0.3)
					end
					local v257 = {
						["core"] = v253,
						["shine"] = v254,
						["ring"] = v255,
						["born"] = (v250 - 1) * 0.06
					}
					table.insert(v_u_249, v257)
				end
				local v_u_258 = {}
				for v259 = 1, 5 do
					local v260, v261, v262 = v_u_36(v248, v_u_7, v_u_10, (v235 and 0.8 or 1.2) * v_u_234)
					v262.Segments = 1
					local v263 = {
						["a0"] = v260,
						["a1"] = v261,
						["beam"] = v262,
						["from"] = v_u_242[v259],
						["to"] = v_u_242[(v259 + 1) % 5 + 1]
					}
					table.insert(v_u_258, v263)
				end
				local v_u_264 = os.clock()
				p_u_45.runNow(function()
					-- upvalues: (copy) v_u_264, (copy) v_u_241, (copy) p_u_233, (copy) v_u_249, (ref) v_u_3, (ref) p_u_45, (copy) v_u_234, (ref) v_u_28, (copy) v_u_258
					local v265 = os.clock() - v_u_264
					if v_u_241 <= v265 then
						return false
					end
					local v266 = (v265 - p_u_233) / 0.4
					local v267 = math.clamp(v266, 0, 1)
					for _, v268 in v_u_249 do
						local v269 = v268.core.Position
						local v270 = v_u_3.CurrentCamera
						local v271
						if v270 then
							local v272 = v270.CFrame.Position - v269
							v271 = v272.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v272.Unit
						else
							v271 = Vector3.new(0, 0, 1)
						end
						local v273 = p_u_45.facing(v269 + v271 * 0.4, v271)
						local v274 = (v265 - v268.born) / 0.14
						local v275 = math.clamp(v274, 0, 1)
						local v276 = v268.ring
						local v277 = 2.2 * v_u_234
						local v278 = v275 - 1
						local v279 = v277 * (v278 * 2.7 * v278 * v278 + 1 + v278 * 1.7 * v278)
						local v280 = math.max(v279, 0.05)
						local v281 = v280 * 2
						local v282 = v280 * 2
						v276.Size = Vector3.new(v281, 0.05, v282)
						v268.ring.CFrame = v273 * CFrame.new(0, -0.05, 0)
						local v283 = v_u_28
						local v284 = v268.ring
						local v285 = (v265 - v268.born - 0.2) / 0.3
						local v286 = math.clamp(v285, 0, 0.6)
						v283(v284, (math.max(v267, v286)))
						local v287 = (v265 - v268.born - 0.1) / 0.12
						local v288 = math.clamp(v287, 0, 1)
						local v289 = v265 * 11 + v268.born * 40
						local v290 = math.sin(v289) * 0.15 + 1
						local v291 = v268.shine
						local v292 = 5.5 * v_u_234
						local v293 = v288 - 1
						local v294 = v292 * (v293 * 2.7 * v293 * v293 + 1 + v293 * 1.7 * v293) * v290
						local v295 = math.max(v294, 0.05)
						local v296 = v295 * 2
						local v297 = v295 * 2
						v291.Size = Vector3.new(v296, 0.05, v297)
						v268.shine.CFrame = v273
						v_u_28(v268.shine, v267)
						local v298 = v268.core
						local v299 = 1.8 * v_u_234 * v288
						v298.Size = Vector3.new(1, 1, 1) * math.max(v299, 0.05)
						v268.core.Transparency = v267
					end
					local v300 = (v265 - 0.3) / 0.25
					local v301 = 1 - (1 - math.clamp(v300, 0, 1)) ^ 2
					for _, v302 in v_u_258 do
						v302.a0.WorldPosition = v302.from
						v302.a1.WorldPosition = v302.from:Lerp(v302.to, (math.max(v301, 0.01)))
						local v303 = v302.beam
						local v304 = NumberSequence.new
						local v305 = 1 - v301 * 4
						v303.Transparency = v304((math.max(v267, v305)))
					end
					return true
				end)
				p_u_45.burst("Flash", v236, v_u_9, 0.5)
				p_u_45.after(p_u_233, function()
					-- upvalues: (ref) v_u_215, (copy) p_u_231, (copy) p_u_232, (copy) v_u_242
					v_u_215(p_u_231, p_u_232, v_u_242)
				end)
			end,
			["strike"] = function(p_u_306, p_u_307, p308) -- name: strike
				-- upvalues: (copy) v_u_194, (copy) p_u_45, (ref) v_u_7, (copy) v_u_202
				local v309 = v_u_194[p_u_306]
				if v309 then
					v309.fired = v309.fired + 1
					local v310 = v309.fired
					local v_u_311 = p_u_306.size
					if #v309.stars >= v310 then
						local v_u_312 = v309.stars[v310]
						local v313 = p_u_45.after
						local v314 = p308 - 0.14
						v313(math.max(v314, 0), function()
							-- upvalues: (ref) p_u_45, (copy) v_u_312, (ref) v_u_7, (copy) v_u_311
							p_u_45.pop(v_u_312, v_u_7, 1.5 * v_u_311, 5 * v_u_311, 0.14, 0.3)
						end)
						p_u_45.after(p308, function()
							-- upvalues: (ref) v_u_202, (copy) p_u_306, (copy) v_u_312, (copy) p_u_307, (copy) v_u_311
							v_u_202(p_u_306, v_u_312, p_u_307, 1.3 * v_u_311, false)
						end)
					end
				else
					return
				end
			end,
			["hit"] = function(p315, p316, _) -- name: hit
				-- upvalues: (copy) p_u_45, (ref) v_u_9, (ref) v_u_11
				p_u_45.burst("Impact", p316, v_u_9, 1)
				if not p315.lite then
					p_u_45.glint(p316, v_u_11, 3.4, 0.15)
				end
			end
		}
	}
	return v317
end