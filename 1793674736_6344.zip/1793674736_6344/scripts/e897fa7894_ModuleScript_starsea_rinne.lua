local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("3B8BFF")
local v_u_8 = Color3.fromHex("0A1B4D")
local v_u_9 = Color3.fromRGB(200, 226, 255)
local v_u_10 = Color3.fromRGB(110, 215, 255)
local v_u_11 = Color3.fromRGB(3, 4, 12)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.PartType.Ball
local function v_u_25(p14, p15, p16, p17, p18) -- name: picture
	-- upvalues: (copy) v_u_4
	local v19 = v_u_4.part
	local v20 = p15 * 2
	local v21 = p15 * 2
	local v22 = v19(Vector3.new(v20, 0.05, v21), p14, p17, {
		["transparency"] = 1
	})
	for _, v23 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p16
		v24.Color3 = p17
		v24.Transparency = p18
		v24.Parent = v22
	end
	return v22
end
local function v_u_29(p26, p27) -- name: fadeDecals
	for _, v28 in p26:GetChildren() do
		if not v28:IsA("Decal") then
			continue
		end
		v28.Transparency = p27
	end
end
return function(p_u_30)
	-- upvalues: (copy) v_u_25, (copy) v_u_1, (copy) v_u_29, (copy) v_u_9, (copy) v_u_12, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_13, (copy) v_u_6, (copy) v_u_3, (copy) v_u_11, (copy) v_u_10, (copy) v_u_5
	local function v_u_48(p_u_31, p_u_32, p_u_33, p34, p35, p_u_36, p_u_37, p38) -- name: flare
		-- upvalues: (ref) v_u_25, (ref) v_u_1, (copy) p_u_30, (ref) v_u_29
		local v_u_39 = p38 or 0
		local v_u_40 = v_u_25(p_u_31, p_u_32, p34, p35, v_u_39)
		v_u_1:AddItem(v_u_40, p_u_36 + 0.1)
		p_u_30.animate(p_u_36, 0, function(p41)
			-- upvalues: (copy) v_u_40, (copy) p_u_32, (copy) p_u_33, (copy) p_u_31, (copy) p_u_36, (copy) p_u_37, (ref) v_u_29, (copy) v_u_39
			local v42 = 1 - (1 - p41) ^ 3
			local v43 = v_u_40
			local v44 = p_u_32 + (p_u_33 - p_u_32) * v42
			local v45 = math.max(v44, 0.03)
			local v46 = v45 * 2
			local v47 = v45 * 2
			v43.Size = Vector3.new(v46, 0.05, v47)
			v_u_40.CFrame = p_u_31 * CFrame.Angles(0, p41 * p_u_36 * p_u_37, 0)
			v_u_29(v_u_40, v_u_39 + (1 - v_u_39) * p41 ^ 1.5)
			if p41 >= 1 then
				v_u_40:Destroy()
			end
		end)
	end
	local function v_u_61(p_u_49, p50, p51, p_u_52) -- name: twinkles
		-- upvalues: (copy) p_u_30, (ref) v_u_9, (ref) v_u_12
		for v_u_53 = 1, p50 do
			local v54 = math.random() - 0.5
			local v55 = math.random() - 0.5
			local v56 = math.random() - 0.5
			local v_u_57 = Vector3.new(v54, v55, v56) * 2 * p51
			p_u_30.after((v_u_53 - 1) * 0.05, function()
				-- upvalues: (ref) p_u_30, (copy) p_u_49, (copy) v_u_57, (copy) v_u_53, (ref) v_u_9, (ref) v_u_12, (copy) p_u_52
				local v58 = p_u_30.glint
				local v59 = p_u_49 + v_u_57
				local v60
				if v_u_53 % 2 == 0 then
					v60 = v_u_9
				else
					v60 = v_u_12
				end
				v58(v59, v60, p_u_52 * (0.7 + math.random() * 0.6), 0.22)
			end)
		end
	end
	local function v87(p62, p63) -- name: marbleShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_13, (ref) v_u_25, (ref) v_u_6, (ref) v_u_9, (copy) p_u_30, (ref) v_u_12, (ref) v_u_1, (ref) v_u_3
		local v_u_64 = p62.size
		local v_u_65 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p63, v_u_7, {
			["transparency"] = 1
		})
		local v_u_66 = v_u_4.part(Vector3.new(1.05, 1.05, 1.05) * v_u_64, p63, v_u_8, {
			["shape"] = v_u_13,
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_66.Reflectance = 0.35
		local v67 = {
			["shape"] = nil,
			["transparency"] = 0.62,
			["shape"] = v_u_13
		}
		local v_u_68 = v_u_4.part(Vector3.new(1.75, 1.75, 1.75) * v_u_64, p63, v_u_7, v67)
		local v_u_69 = v_u_25(p63, 0.95 * v_u_64, v_u_6.StarseaGalaxy, v_u_9, 0)
		local v_u_70 = { v_u_66, v_u_68, v_u_69 }
		local v_u_71 = {}
		p_u_30.streak(v_u_65, v_u_7, v_u_8, 1.3 * v_u_64, 0.2)
		if not p62.lite then
			p_u_30.streak(v_u_65, v_u_12, v_u_7, 0.35 * v_u_64, 0.12)
			for _ = 1, 2 do
				local v72 = {
					["shape"] = v_u_13
				}
				local v73 = v_u_4.part(Vector3.new(0.24, 0.24, 0.24) * v_u_64, p63, v_u_12, v72)
				table.insert(v_u_71, v73)
				table.insert(v_u_70, v73)
			end
		end
		if p62.mine then
			p_u_30.light(v_u_65, v_u_7, 9 * v_u_64)
		end
		for _, v74 in v_u_70 do
			v_u_1:AddItem(v74, 3)
		end
		v_u_1:AddItem(v_u_65, 3)
		local v_u_75 = false
		return {
			["place"] = function(p76, p77) -- name: place
				-- upvalues: (copy) v_u_65, (copy) v_u_66, (copy) v_u_68, (ref) v_u_3, (copy) v_u_69, (ref) p_u_30, (copy) v_u_64, (copy) v_u_71
				local v78 = p76.Position
				v_u_65.CFrame = p76
				v_u_66.CFrame = p76
				v_u_68.CFrame = p76
				local v79 = v_u_3.CurrentCamera
				local v80
				if v79 then
					local v81 = v79.CFrame.Position - v78
					v80 = v81.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v81.Unit
				else
					v80 = Vector3.new(0, 0, 1)
				end
				v_u_69.CFrame = p_u_30.facing(v78 + v80 * 0.92 * v_u_64, v80) * CFrame.Angles(0, -p77 * 9, 0)
				for v82, v83 in v_u_71 do
					local v84 = p77 * 15 + v82 * 3.141592653589793
					v83.CFrame = p76 * CFrame.Angles(0.6, 0, 0) * CFrame.new(math.cos(v84) * 1.25 * v_u_64, 0, math.sin(v84) * 1.25 * v_u_64)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_75, (copy) v_u_65, (ref) v_u_1, (copy) v_u_70
				if not v_u_75 then
					v_u_75 = true
					local v85 = v_u_65:FindFirstChildWhichIsA("PointLight")
					if v85 then
						v85:Destroy()
					end
					v_u_1:AddItem(v_u_65, 0.22)
					for _, v86 in v_u_70 do
						v86:Destroy()
					end
				end
			end
		}
	end
	local function v94(p88, p89) -- name: nebulaBurst
		-- upvalues: (ref) v_u_3, (copy) v_u_48, (copy) p_u_30, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12, (ref) v_u_4, (copy) v_u_61
		local v90 = p88.size
		local v91 = v_u_3.CurrentCamera
		local v92
		if v91 then
			local v93 = v91.CFrame.Position - p89
			v92 = v93.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v93.Unit
		else
			v92 = Vector3.new(0, 0, 1)
		end
		v_u_48(p_u_30.facing(p89 + v92 * 0.5, v92), 1 * v90, 6.5 * v90, v_u_6.StarseaGalaxy, v_u_9, 0.32, -6)
		p_u_30.pop(p89, v_u_7, 2 * v90, 6 * v90, 0.18, 0.4)
		p_u_30.pop(p89, v_u_12, 1.2 * v90, 0.3 * v90, 0.12)
		v_u_4.ring(p_u_30.ground(p89), v_u_7, p88.ability.radius * 0.65 * v90, 0.28, v_u_6.Ring)
		if not p88.lite then
			v_u_61(p89, 3, 2.2 * v90, 2.6 * v90)
			p_u_30.spikes(p89, v_u_12, 4, 3.5 * v90, 0.15)
		end
		p_u_30.hitSound(p89)
	end
	local v_u_95 = {}
	setmetatable(v_u_95, {
		["__mode"] = "k"
	})
	local function v_u_156(p96, p97) -- name: openHole
		-- upvalues: (copy) p_u_30, (copy) v_u_95, (ref) v_u_11, (ref) v_u_7, (ref) v_u_25, (ref) v_u_6, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (ref) v_u_12, (ref) v_u_13, (ref) v_u_1, (ref) v_u_5, (ref) v_u_3, (ref) v_u_29, (copy) v_u_61
		local v_u_98 = p96.size
		local v_u_99 = p96.ability.radius * v_u_98
		local v_u_100 = p96.lite
		local v_u_101 = p96.ability.freeze or 2.5
		local v_u_102 = p_u_30.ground(p97, 5 * v_u_98)
		v_u_95[p96] = {
			["at"] = v_u_102,
			["born"] = os.clock(),
			["life"] = v_u_101
		}
		local v103 = v_u_101 + 0.6
		local v_u_104 = p_u_30.ball(v_u_102, v_u_11, 0.2, 0, Enum.Material.SmoothPlastic)
		local v_u_105 = p_u_30.ball(v_u_102, v_u_7, 0.2, 0.86)
		local v_u_106 = v_u_25(CFrame.new(v_u_102), 0.1, v_u_6.Ring, v_u_9, 0)
		local v_u_107 = v_u_25(CFrame.new(v_u_102), 0.1, v_u_6.StarseaHole, v_u_7, 0)
		local v_u_108 = {
			v_u_104,
			v_u_105,
			v_u_106,
			v_u_107
		}
		local v_u_109
		if v_u_100 then
			v_u_109 = nil
		else
			v_u_109 = v_u_25(CFrame.new(v_u_102), 0.1, v_u_6.StarseaHole, v_u_10, 0.35)
			table.insert(v_u_108, v_u_109)
		end
		local v_u_110 = {}
		for v111 = 1, v_u_100 and 2 or 6 do
			local v112 = {
				["shape"] = v_u_13
			}
			local v113 = v_u_4.part(Vector3.new(1, 1, 1) * (v111 % 3 * 0.08 + 0.25) * v_u_98, CFrame.new(v_u_102), v_u_12, v112)
			table.insert(v_u_108, v113)
			local v114 = {
				["p"] = v113,
				["r"] = (v111 % 3 * 1.1 + 3.4) * v_u_98,
				["speed"] = 3.2 - v111 % 3 * 0.6,
				["tilt"] = CFrame.Angles(v111 % 2 * 0.5 + 0.35, v111 * 1.3, v111 % 3 * 0.3),
				["phase"] = v111 * 1.7
			}
			table.insert(v_u_110, v114)
		end
		for _, v115 in v_u_108 do
			v_u_1:AddItem(v115, v103 + 0.5)
		end
		v_u_1:AddItem(p_u_30.sigil(CFrame.new(p_u_30.ground(p97, 0.12)), v_u_99, v_u_7, v_u_6.Ring, v_u_101, 1.2), v103 + 1)
		v_u_4.flash(v_u_102, v_u_7, 10 * v_u_98, 0.14)
		p_u_30.burst("Impact", v_u_102, v_u_7, 1.4)
		v_u_4.ring(p_u_30.ground(p97), v_u_7, v_u_99 * 1.15, 0.4, v_u_6.Shockwave)
		v_u_5.play("Orb", {
			["at"] = v_u_102,
			["volume"] = p96.mine and 0.8 or 0.5
		})
		if p96.mine then
			v_u_4.shake(0.18, 0.2)
		end
		local v_u_116 = os.clock()
		local v_u_117 = 0.3
		p_u_30.runNow(function()
			-- upvalues: (copy) v_u_116, (copy) v_u_101, (copy) v_u_102, (ref) v_u_3, (ref) p_u_30, (copy) v_u_104, (copy) v_u_98, (copy) v_u_105, (copy) v_u_106, (ref) v_u_29, (copy) v_u_107, (ref) v_u_109, (copy) v_u_110, (copy) v_u_100, (ref) v_u_117, (ref) v_u_9, (copy) v_u_99, (copy) v_u_108, (ref) v_u_4, (ref) v_u_7, (ref) v_u_61
			local v118 = os.clock() - v_u_116
			local v119 = v118 / 0.2
			local v120 = math.clamp(v119, 0, 1) - 1
			local v121 = v120 * 2.9 * v120 * v120 + 1 + v120 * 1.9 * v120
			local v122 = (v118 - v_u_101) / 0.15
			local v123 = math.clamp(v122, 0, 1)
			local v124 = v121 * (1 - v123)
			local v125 = math.max(v124, 0.01)
			local v126 = v_u_102
			local v127 = v_u_3.CurrentCamera
			local v128
			if v127 then
				local v129 = v127.CFrame.Position - v126
				v128 = v129.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v129.Unit
			else
				v128 = Vector3.new(0, 0, 1)
			end
			local v130 = p_u_30.flatUnit(v128) * 0.5
			local v131 = p_u_30.facing(v_u_102, (Vector3.new(0, 1, 0) + v130).Unit)
			v_u_104.Size = Vector3.new(3.1, 3.1, 3.1) * v_u_98 * v125
			local v132 = v_u_105
			local v133 = Vector3.new(9, 9, 9) * v_u_98 * v125
			local v134 = v118 * 5
			v132.Size = v133 * (math.sin(v134) * 0.03 + 1)
			v_u_106.CFrame = p_u_30.facing(v_u_102 + v128 * 0.2, v128)
			local v135 = v_u_106
			local v136 = 1.95 * v_u_98 * v125
			local v137 = math.max(v136, 0.03)
			local v138 = v137 * 2
			local v139 = v137 * 2
			v135.Size = Vector3.new(v138, 0.05, v139)
			local v140 = v_u_29
			local v141 = v_u_106
			local v142 = v118 * 9
			v140(v141, math.sin(v142) ^ 2 * 0.2 + 0.05)
			v_u_107.CFrame = v131 * CFrame.Angles(0, -v118 * 5.5, 0)
			local v143 = v_u_107
			local v144 = 7.5 * v_u_98 * v125
			local v145 = math.max(v144, 0.03)
			local v146 = v145 * 2
			local v147 = v145 * 2
			v143.Size = Vector3.new(v146, 0.05, v147)
			local v148 = v_u_109
			if v148 then
				v148.CFrame = v131 * CFrame.Angles(0, v118 * 2.2, 0)
				local v149 = 9.8 * v_u_98 * v125
				local v150 = math.max(v149, 0.03)
				local v151 = v150 * 2
				local v152 = v150 * 2
				v148.Size = Vector3.new(v151, 0.05, v152)
			end
			for _, v153 in v_u_110 do
				local v154 = v153.phase + v118 * v153.speed
				v153.p.CFrame = CFrame.new(v_u_102) * v153.tilt * CFrame.new(math.cos(v154) * v153.r * v125, 0, math.sin(v154) * v153.r * v125)
			end
			if not v_u_100 and (v_u_117 <= v118 and v123 <= 0) then
				v_u_117 = v118 + 0.35
				p_u_30.inward(v_u_102, v_u_9, 3, v_u_99 * 0.9, 0.35)
			end
			if v123 < 1 then
				return true
			end
			for _, v155 in v_u_108 do
				v155:Destroy()
			end
			v_u_4.flash(v_u_102, v_u_9, 8 * v_u_98, 0.15)
			p_u_30.pop(v_u_102, v_u_7, 1, 9 * v_u_98, 0.25, 0.4)
			if not v_u_100 then
				v_u_61(v_u_102, 4, 3 * v_u_98, 3 * v_u_98)
			end
			return false
		end)
	end
	local function v_u_183(p157, p_u_158, p159) -- name: holdInOrbit
		-- upvalues: (ref) v_u_3, (copy) v_u_95, (ref) v_u_25, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4, (ref) v_u_12, (ref) v_u_13, (ref) v_u_7, (ref) v_u_1, (copy) p_u_30
		local v_u_160 = p157.ability.freeze or 2.5
		local v161 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_162
		if v161 then
			v_u_162 = v161:FindFirstChild("Foe" .. p159)
		else
			v_u_162 = nil
		end
		if not (v_u_162 and v_u_162:IsA("Model")) then
			v_u_162 = nil
		end
		local v_u_163 = v_u_95[p157]
		local v_u_164 = v_u_25(CFrame.new(p_u_158), 1.9, v_u_6.Ring, v_u_9, 0.1)
		local v165 = {
			["shape"] = v_u_13
		}
		local v_u_166 = v_u_4.part(Vector3.new(0.42, 0.42, 0.42), CFrame.new(p_u_158), v_u_12, v165)
		local v_u_167 = { v_u_164, v_u_166 }
		local v_u_168
		if v_u_163 and not p157.lite then
			v_u_168 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_163.at), v_u_7, {
				["transparency"] = 1
			})
			table.insert(v_u_167, v_u_168)
			local v169 = Instance.new("Attachment")
			v169.Parent = v_u_166
			local v170 = Instance.new("Attachment")
			v170.Parent = v_u_168
			local v171 = Instance.new("Beam")
			v171.Attachment0 = v169
			v171.Attachment1 = v170
			v171.Texture = v_u_6.Beam
			v171.TextureMode = Enum.TextureMode.Wrap
			v171.TextureLength = 4
			v171.TextureSpeed = -3
			v171.Color = ColorSequence.new(v_u_9, v_u_7)
			v171.LightEmission = 1
			v171.LightInfluence = 0
			v171.Width0 = 0.25
			v171.Width1 = 0.6
			v171.FaceCamera = true
			v171.Transparency = NumberSequence.new(0.35, 0.6)
			v171.Parent = v_u_166
		else
			v_u_168 = nil
		end
		for _, v172 in v_u_167 do
			v_u_1:AddItem(v172, v_u_160 + 1)
		end
		p_u_30.burst("Impact", p_u_158, v_u_7, 0.7)
		local v_u_173 = os.clock()
		local v_u_174 = CFrame.Angles(0.45 + math.random() * 0.3, math.random() * 6, 0.2)
		p_u_30.runNow(function()
			-- upvalues: (copy) v_u_173, (copy) v_u_162, (copy) p_u_158, (copy) v_u_160, (copy) v_u_167, (ref) p_u_30, (ref) v_u_9, (copy) v_u_174, (copy) v_u_164, (copy) v_u_166, (ref) v_u_168, (copy) v_u_163
			local v175 = os.clock() - v_u_173
			local v176
			if v_u_162 and v_u_162.Parent then
				v176 = v_u_162:GetPivot().Position
			else
				v176 = p_u_158
			end
			local v177
			if v_u_160 < v175 then
				v177 = true
			elseif v_u_162 == nil then
				v177 = false
			else
				v177 = v_u_162.Parent == nil
			end
			if v177 then
				for _, v178 in v_u_167 do
					v178:Destroy()
				end
				p_u_30.pop(v176, v_u_9, 1.5, 4, 0.18, 0.3)
				return false
			end
			local v179 = CFrame.new(v176) * v_u_174 * CFrame.Angles(0, v175 * 1.5, 0)
			v_u_164.CFrame = v179
			local v180 = v175 * 6
			v_u_166.CFrame = v179 * CFrame.new(math.cos(v180) * 1.9, 0, math.sin(v180) * 1.9)
			local v181 = v_u_168
			if v181 then
				local v182 = CFrame.new
				if v_u_163 then
					v176 = v_u_163.at or v176
				end
				v181.CFrame = v182(v176)
			end
			return true
		end)
	end
	local v_u_184 = {}
	setmetatable(v_u_184, {
		["__mode"] = "k"
	})
	local function v_u_194(p185, p186, p187, p188) -- name: strand
		-- upvalues: (ref) v_u_6
		local v189 = {}
		local v190 = {}
		for v191 = 1, 4 do
			local v192 = Instance.new("Attachment")
			v192.Parent = p185
			v189[v191] = v192
			if v191 <= 1 then
				continue
			end
			local v193 = Instance.new("Beam")
			v193.Attachment0 = v189[v191 - 1]
			v193.Attachment1 = v192
			v193.Texture = v_u_6.Beam
			v193.TextureMode = Enum.TextureMode.Wrap
			v193.TextureLength = 8
			v193.TextureSpeed = 6
			v193.Color = ColorSequence.new(p186)
			v193.LightEmission = 0.85
			v193.LightInfluence = 0
			v193.FaceCamera = true
			v193.Segments = 12
			v193.Width0 = p187
			v193.Width1 = p187
			v193.Parent = p185
			table.insert(v190, v193)
		end
		return {
			["points"] = v189,
			["beams"] = v190,
			["phase"] = p188
		}
	end
	local function v_u_207(p195, p196, p197, p198) -- name: riverStars
		-- upvalues: (ref) v_u_4, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10, (copy) p_u_30, (ref) v_u_1
		local v199 = (p196 - p195).Magnitude
		local v200 = v_u_4.part
		local v201 = p197 * 5
		local v202 = p197 * 5
		local v203 = v199 - 4
		local v204 = math.max(v203, 1)
		local v205 = v200(Vector3.new(v201, v202, v204), CFrame.lookAt((p195 + p196) / 2, p196), v_u_12, {
			["transparency"] = 1
		})
		local v_u_206 = Instance.new("ParticleEmitter")
		v_u_206.Texture = v_u_6.PetStar
		v_u_206.EmissionDirection = Enum.NormalId.Front
		v_u_206.Color = ColorSequence.new(v_u_12, v_u_10)
		v_u_206.LightEmission = 1
		v_u_206.LightInfluence = 0
		v_u_206.Lifetime = NumberRange.new(0.25, 0.45)
		v_u_206.Speed = NumberRange.new(80, 130)
		v_u_206.SpreadAngle = Vector2.new(4, 4)
		v_u_206.Rotation = NumberRange.new(0, 90)
		v_u_206.RotSpeed = NumberRange.new(-200, 200)
		v_u_206.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p197 * 0.7), NumberSequenceKeypoint.new(0.5, p197 * 1.6), NumberSequenceKeypoint.new(1, p197 * 0.2) })
		v_u_206.Transparency = NumberSequence.new(0, 0.5)
		v_u_206.Rate = p198 and 25 or 70
		v_u_206.Parent = v205
		p_u_30.after(0.45, function()
			-- upvalues: (copy) v_u_206
			v_u_206.Enabled = false
		end)
		v_u_1:AddItem(v205, 1.1)
	end
	local v311 = {
		["starsea_rinne_a"] = {
			["cast"] = function(p208) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_30, (ref) v_u_12, (copy) v_u_48, (ref) v_u_6, (ref) v_u_9
				local v209 = p208.size
				local v210 = p208.eye + p208.dir * 1.1
				v_u_4.flash(v210, v_u_7, 3 * v209, 0.1)
				p_u_30.pop(v210, v_u_12, 1 * v209, 0.3 * v209, 0.1)
				if not p208.lite then
					v_u_48(p_u_30.facing(v210, p208.dir), 0.5 * v209, 2.4 * v209, v_u_6.StarseaGalaxy, v_u_9, 0.14, 8)
				end
			end,
			["shot"] = v87,
			["impact"] = v94,
			["hit"] = function(p211, p212, _) -- name: hit
				-- upvalues: (copy) p_u_30, (ref) v_u_7, (ref) v_u_9
				p_u_30.burst("Impact", p212, v_u_7, 0.6)
				if not p211.lite then
					p_u_30.glint(p212, v_u_9, 2.4, 0.16)
				end
			end
		},
		["starsea_rinne_e"] = {
			["cast"] = function(p213) -- name: cast
				-- upvalues: (copy) p_u_30, (ref) v_u_7
				p_u_30.skillCast(p213, v_u_7)
			end,
			["windup"] = function(p214, p215, p216) -- name: windup
				-- upvalues: (copy) v_u_48, (copy) p_u_30, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11
				local v217 = p214.size
				local v218 = p214.ability.radius * v217
				local v219 = math.max(p216, 0.06)
				v_u_48(CFrame.new(p_u_30.ground(p215, 0.15)), v218 * 1.3, v218 * 0.25, v_u_6.Ring, v_u_7, v219 + 0.1, 3, 0.15)
				p_u_30.inward(p_u_30.ground(p215, 5 * v217), v_u_9, p214.lite and 4 or 9, v218 * 1.2, v219 + 0.05)
				p_u_30.pop(p_u_30.ground(p215, 5 * v217), v_u_11, 0.4, 2.2 * v217, v219 + 0.05, 0.2, Enum.Material.SmoothPlastic)
			end,
			["land"] = function(p220, p221) -- name: land
				-- upvalues: (copy) v_u_156
				v_u_156(p220, p221)
			end,
			["hit"] = function(p222, p223, p224) -- name: hit
				-- upvalues: (copy) v_u_183
				v_u_183(p222, p223, p224)
			end
		},
		["starsea_rinne_r"] = {
			["cast"] = function(p225) -- name: cast
				-- upvalues: (copy) p_u_30, (ref) v_u_7
				p_u_30.skillCast(p225, v_u_7, true)
			end,
			["windup"] = function(p226, p227, p228) -- name: windup
				-- upvalues: (copy) p_u_30, (ref) v_u_25, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_1, (copy) v_u_184
				local v_u_229 = p226.size
				local v_u_230 = math.max(p228, 0.06)
				local v231 = p227 + p226.dir * 2.4 * v_u_229
				local v_u_232 = p_u_30.facing(v231, p226.dir)
				local v_u_233 = v_u_25(v_u_232, 0.3, v_u_6.StarseaGalaxy, v_u_9, 0)
				local v_u_234 = v_u_25(v_u_232, 0.3, v_u_6.Ring, v_u_7, 0.1)
				v_u_1:AddItem(v_u_233, v_u_230 + 0.6)
				v_u_1:AddItem(v_u_234, v_u_230 + 0.6)
				local v_u_235 = {
					["galaxy"] = nil,
					["ring"] = nil,
					["taken"] = false,
					["galaxy"] = v_u_233,
					["ring"] = v_u_234
				}
				v_u_184[p226] = v_u_235
				p_u_30.inward(v231, v_u_9, p226.lite and 4 or 8, 9 * v_u_229, v_u_230)
				if not p226.lite then
					local v236 = p_u_30.loopAt("Charge", v231, v_u_7, 0.7)
					p_u_30.after(v_u_230, v236)
				end
				local v_u_237 = os.clock()
				p_u_30.runNow(function()
					-- upvalues: (copy) v_u_235, (copy) v_u_237, (copy) v_u_230, (copy) v_u_233, (copy) v_u_229, (copy) v_u_232, (copy) v_u_234
					if v_u_235.taken then
						return false
					end
					local v238 = os.clock() - v_u_237
					local v239 = v238 / v_u_230
					local v240 = 1 - (1 - math.clamp(v239, 0, 1)) ^ 2
					local v241 = v_u_233
					local v242 = (v240 * 3.9 + 0.3) * v_u_229
					local v243 = math.max(v242, 0.03)
					local v244 = v243 * 2
					local v245 = v243 * 2
					v241.Size = Vector3.new(v244, 0.05, v245)
					v_u_233.CFrame = v_u_232 * CFrame.Angles(0, -v238 * 7, 0)
					local v246 = v_u_234
					local v247 = (v240 * 4.6 + 0.4) * v_u_229
					local v248 = math.max(v247, 0.03)
					local v249 = v248 * 2
					local v250 = v248 * 2
					v246.Size = Vector3.new(v249, 0.05, v250)
					v_u_234.CFrame = v_u_232 * CFrame.Angles(0, v238 * 4, 0)
					if v_u_230 + 0.5 >= v238 then
						return true
					end
					v_u_233:Destroy()
					v_u_234:Destroy()
					return false
				end)
			end,
			["beam"] = function(p_u_251, p252, p_u_253) -- name: galacticTide
				-- upvalues: (copy) v_u_184, (copy) v_u_48, (copy) p_u_30, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (ref) v_u_1, (ref) v_u_8, (ref) v_u_10, (copy) v_u_194, (copy) v_u_207, (ref) v_u_3, (copy) v_u_61, (ref) v_u_5
				local v_u_254 = p_u_251.size
				local v_u_255 = p_u_251.lite
				local v_u_256 = p_u_253 - p252
				local v257 = v_u_256.Magnitude
				local v_u_258 = math.max(v257, 1)
				local v_u_259 = v_u_256 / v_u_258
				local v260 = v_u_259:Cross(Vector3.new(0, 1, 0))
				local v_u_261 = v260.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v260.Unit
				local v_u_262 = v_u_261:Cross(v_u_259).Unit
				local v263 = v_u_184[p_u_251]
				v_u_184[p_u_251] = nil
				if v263 then
					v263.taken = true
					v263.galaxy:Destroy()
					v263.ring:Destroy()
				end
				local v264 = p252 + v_u_259 * 2.4 * v_u_254
				v_u_48(p_u_30.facing(v264, v_u_259), 4.2 * v_u_254, 8 * v_u_254, v_u_6.StarseaGalaxy, v_u_9, 0.4, -5)
				v_u_48(p_u_30.facing(v264 + v_u_259 * 0.3, v_u_259), 5 * v_u_254, 10 * v_u_254, v_u_6.Ring, v_u_7, 0.3, 3, 0.1)
				v_u_4.flash(v264, v_u_7, 9 * v_u_254, 0.14)
				local v_u_265 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p252), v_u_12, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_265, 1.1)
				local v266 = Instance.new("Attachment")
				v266.Parent = v_u_265
				local v267 = Instance.new("Attachment")
				v267.Position = v_u_256
				v267.Parent = v_u_265
				local v_u_268 = Instance.new("Beam")
				v_u_268.Attachment0 = v266
				v_u_268.Attachment1 = v267
				v_u_268.Texture = v_u_6.Beam
				v_u_268.TextureMode = Enum.TextureMode.Wrap
				v_u_268.TextureLength = 10
				v_u_268.TextureSpeed = 4
				v_u_268.Color = ColorSequence.new(v_u_7, v_u_8:Lerp(v_u_7, 0.4))
				v_u_268.LightEmission = 0.4
				v_u_268.LightInfluence = 0
				v_u_268.FaceCamera = true
				v_u_268.Segments = 1
				v_u_268.Parent = v_u_265
				local v269 = {
					v_u_9,
					v_u_7,
					v_u_10,
					v_u_12
				}
				local v_u_270 = {}
				for v271 = 1, v_u_255 and 2 or 4 do
					local v272 = v_u_194(v_u_265, v269[v271], 1.5 * v_u_254, (v271 - 1) / 4 * 3.141592653589793 * 2)
					table.insert(v_u_270, v272)
				end
				local v273 = p_u_30.rod(p252, p_u_253, 0.6 * v_u_254, v_u_9, 0.4)
				p_u_30.thin(v273, 0.5, true)
				v_u_207(p252, p_u_253, v_u_254, v_u_255)
				p_u_30.groundLine(p252, p_u_253, 3.5 * v_u_254, v_u_7, 0.8, 0.72)
				local v274 = 13 * v_u_254
				local v275 = (v_u_258 - 6) / v274
				local v276 = math.floor(v275)
				local v277 = math.max(v276, 1)
				for v_u_278 = 1, v277 do
					local v_u_279 = p252 + v_u_259 * ((v_u_278 - 0.5) * (v_u_258 - 6) / v277 + 6)
					p_u_30.after(v_u_278 * 0.025, function()
						-- upvalues: (ref) p_u_30, (copy) v_u_279, (copy) v_u_278, (ref) v_u_7, (ref) v_u_8, (copy) v_u_254, (copy) v_u_255, (ref) v_u_3, (ref) v_u_48, (ref) v_u_6, (ref) v_u_9
						local v280 = p_u_30.pop
						local v281 = v_u_279
						local v282
						if v_u_278 % 2 == 0 then
							v282 = v_u_7
						else
							v282 = v_u_8:Lerp(v_u_7, 0.5)
						end
						v280(v281, v282, 3 * v_u_254, 8.5 * v_u_254, 0.4, 0.62)
						if not v_u_255 and v_u_278 % 2 == 1 then
							local v283 = v_u_279
							local v284 = v_u_3.CurrentCamera
							local v285
							if v284 then
								local v286 = v284.CFrame.Position - v283
								v285 = v286.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v286.Unit
							else
								v285 = Vector3.new(0, 0, 1)
							end
							v_u_48(p_u_30.facing(v_u_279 + v285, v285), 1 * v_u_254, 3.6 * v_u_254, v_u_6.StarseaGalaxy, v_u_9, 0.45, 7)
						end
					end)
				end
				local v_u_287 = os.clock()
				p_u_30.runNow(function()
					-- upvalues: (copy) v_u_287, (copy) v_u_254, (copy) v_u_268, (copy) v_u_270, (ref) v_u_261, (copy) v_u_262, (copy) v_u_256, (copy) v_u_259, (copy) v_u_258, (copy) v_u_265
					local v288 = os.clock() - v_u_287
					local v289 = v288 / 0.8
					local v290 = math.clamp(v289, 0, 1)
					local v291 = v288 / 0.08
					local v292 = math.clamp(v291, 0, 1)
					local v293 = 12 * v_u_254 * v292 * (1 - v290 * v290)
					local v294 = v_u_268
					local v295 = v293 * 0.7
					v294.Width0 = math.max(v295, 0.05)
					v_u_268.Width1 = math.max(v293, 0.05)
					v_u_268.Transparency = NumberSequence.new(v290 * 0.95 + 0.05, v290 * 0.85 + 0.15)
					for _, v296 in v_u_270 do
						for v297, v298 in v296.points do
							local v299 = (v297 - 1) / 3
							local v300 = (v297 == 1 and 0.6 or 3.2) * v_u_254 * v292 * (1 - v290)
							local v301 = v296.phase + v299 * 4 - v288 * 9
							local v302 = v_u_261 * math.cos(v301) * v300 + v_u_262 * math.sin(v301) * v300
							v298.CFrame = CFrame.fromMatrix(v_u_256 * v299 + v302, v_u_259, v_u_262)
						end
						for _, v303 in v296.beams do
							local v304 = v_u_258 / 9
							v303.CurveSize0 = v304
							v303.CurveSize1 = v304
							v303.Transparency = NumberSequence.new(v290 * 0.9 + 0.1)
						end
					end
					if v290 < 1 then
						return true
					end
					v_u_265:Destroy()
					return false
				end)
				p_u_30.after(0.12, function()
					-- upvalues: (copy) p_u_253, (ref) v_u_3, (ref) v_u_48, (ref) p_u_30, (copy) v_u_254, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_12, (copy) v_u_255, (ref) v_u_61, (ref) v_u_5, (copy) p_u_251
					local v305 = p_u_253
					local v306 = v_u_3.CurrentCamera
					local v307
					if v306 then
						local v308 = v306.CFrame.Position - v305
						v307 = v308.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v308.Unit
					else
						v307 = Vector3.new(0, 0, 1)
					end
					v_u_48(p_u_30.facing(p_u_253 + v307, v307), 2 * v_u_254, 15 * v_u_254, v_u_6.StarseaGalaxy, v_u_9, 0.55, -4)
					p_u_30.burst("Explosion", p_u_253, v_u_7, 1.6)
					v_u_4.ring(p_u_30.ground(p_u_253), v_u_7, 14 * v_u_254, 0.5, v_u_6.Shockwave)
					v_u_4.ring(p_u_30.ground(p_u_253), v_u_9, 17 * v_u_254, 0.45, v_u_6.Ring)
					p_u_30.spikes(p_u_253, v_u_12, v_u_255 and 4 or 9, 12 * v_u_254, 0.3)
					if not v_u_255 then
						v_u_61(p_u_253, 4, 5 * v_u_254, 5 * v_u_254)
					end
					v_u_5.play("Explosion", {
						["at"] = p_u_253,
						["volume"] = p_u_251.mine and 0.9 or 0.5
					})
				end)
				if p_u_251.mine then
					v_u_4.shake(0.5, 0.45)
				end
			end,
			["hit"] = function(p309, p310, _) -- name: hit
				-- upvalues: (copy) p_u_30, (ref) v_u_7, (ref) v_u_9
				p_u_30.burst("Impact", p310, v_u_7, 1)
				if not p309.lite then
					p_u_30.glint(p310, v_u_9, 4, 0.18)
				end
			end
		}
	}
	return v311
end