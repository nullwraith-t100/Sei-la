local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = {}
local function v7(p4, p5, p6) -- name: rgb
	return Color3.fromRGB(p4, p5, p6)
end
local v_u_8 = {
	["starter"] = { Color3.fromRGB(255, 214, 64), v7(255, 136, 26) },
	["ultimate"] = { Color3.fromRGB(255, 210, 60), v7(200, 40, 40) },
	["potionPack"] = { Color3.fromRGB(225, 130, 255), v7(120, 44, 220) },
	["vipPlus"] = { Color3.fromRGB(196, 112, 255), v7(92, 26, 196) },
	["hokage"] = { Color3.fromRGB(255, 150, 60), v7(190, 26, 26) },
	["equip1"] = { Color3.fromRGB(125, 240, 95), v7(30, 168, 70) },
	["equip2"] = { Color3.fromRGB(80, 235, 175), v7(18, 150, 120) },
	["storage20"] = { Color3.fromRGB(255, 186, 70), v7(238, 108, 30) },
	["storage120"] = { Color3.fromRGB(255, 140, 90), v7(222, 52, 52) },
	["winsPad"] = { Color3.fromRGB(205, 125, 255), v7(118, 48, 230) },
	["speed2"] = { Color3.fromRGB(105, 215, 255), v7(30, 128, 255) },
	["autoRebirth"] = { Color3.fromRGB(255, 125, 220), v7(196, 48, 168) },
	["autoOp"] = { Color3.fromRGB(255, 230, 90), v7(255, 158, 30) },
	["skipEye"] = { Color3.fromRGB(255, 104, 112), v7(196, 28, 60) },
	["boost2"] = { Color3.fromRGB(95, 205, 255), v7(40, 108, 240) },
	["boostWins"] = { Color3.fromRGB(125, 240, 95), v7(30, 168, 70) },
	["boost5"] = { Color3.fromRGB(195, 112, 255), v7(108, 48, 222) },
	["skipRebirth"] = { Color3.fromRGB(255, 112, 205), v7(166, 40, 200) },
	["chakra1"] = { Color3.fromRGB(112, 232, 255), v7(36, 160, 230) },
	["chakra2"] = { Color3.fromRGB(102, 172, 255), v7(48, 88, 232) },
	["chakra3"] = { Color3.fromRGB(152, 132, 255), v7(82, 58, 222) },
	["bossLuck2"] = { Color3.fromRGB(125, 240, 95), v7(24, 150, 62) },
	["bossLuck5"] = { Color3.fromRGB(255, 222, 70), v7(236, 128, 20) },
	["luckLadder"] = { Color3.fromRGB(110, 232, 84), v7(226, 170, 20) }
}
local v_u_9 = {
	["pro"] = true,
	["boost10"] = true
}
local v_u_10 = {
	["starter"] = {
		Color3.fromRGB(235, 252, 255),
		Color3.fromRGB(100, 225, 255),
		Color3.fromRGB(40, 140, 255),
		v7(100, 225, 255)
	},
	["pro"] = {
		Color3.fromRGB(255, 252, 205),
		Color3.fromRGB(255, 222, 60),
		Color3.fromRGB(255, 150, 0),
		v7(255, 222, 60)
	},
	["potionPack"] = {
		Color3.fromRGB(240, 255, 250),
		Color3.fromRGB(130, 255, 215),
		Color3.fromRGB(30, 210, 180),
		v7(130, 255, 215)
	},
	["vipPlus"] = {
		Color3.fromRGB(255, 252, 215),
		Color3.fromRGB(255, 214, 64),
		Color3.fromRGB(255, 150, 0),
		v7(255, 214, 64)
	},
	["hokage"] = {
		Color3.fromRGB(255, 255, 230),
		Color3.fromRGB(255, 232, 110),
		Color3.fromRGB(255, 196, 40),
		v7(255, 232, 110)
	},
	["ultimate"] = {
		Color3.fromRGB(255, 90, 90),
		Color3.fromRGB(255, 205, 60),
		Color3.fromRGB(110, 255, 120),
		Color3.fromRGB(90, 200, 255),
		v7(215, 110, 255)
	},
	["sixPaths"] = {
		Color3.fromRGB(255, 255, 225),
		Color3.fromRGB(255, 222, 60),
		Color3.fromRGB(255, 56, 40),
		v7(255, 222, 60)
	},
	["luckLadder"] = {
		Color3.fromRGB(255, 255, 230),
		Color3.fromRGB(255, 222, 70),
		Color3.fromRGB(120, 245, 100),
		v7(255, 222, 70)
	},
	["kurama"] = {
		Color3.fromRGB(255, 246, 170),
		Color3.fromRGB(255, 176, 40),
		Color3.fromRGB(255, 104, 20),
		v7(255, 176, 40)
	},
	["tenTails"] = {
		Color3.fromRGB(244, 222, 255),
		Color3.fromRGB(196, 118, 255),
		Color3.fromRGB(140, 64, 255),
		v7(196, 118, 255)
	},
	["shin"] = {
		Color3.fromRGB(255, 255, 255),
		Color3.fromRGB(255, 214, 120),
		Color3.fromRGB(255, 64, 64),
		v7(255, 214, 120)
	},
	["prismEye"] = {
		Color3.fromRGB(130, 240, 255),
		Color3.fromRGB(255, 140, 230),
		Color3.fromRGB(255, 240, 120),
		v7(160, 255, 170)
	},
	["train1"] = {
		Color3.fromRGB(255, 246, 160),
		Color3.fromRGB(255, 184, 40),
		Color3.fromRGB(240, 56, 40),
		v7(255, 184, 40)
	},
	["train2"] = {
		Color3.fromRGB(255, 255, 225),
		Color3.fromRGB(255, 240, 70),
		Color3.fromRGB(255, 176, 0),
		v7(255, 240, 70)
	},
	["train3"] = {
		Color3.fromRGB(225, 255, 200),
		Color3.fromRGB(110, 255, 120),
		Color3.fromRGB(0, 200, 120),
		v7(110, 255, 120)
	},
	["train4"] = {
		Color3.fromRGB(242, 228, 255),
		Color3.fromRGB(186, 130, 255),
		Color3.fromRGB(120, 70, 240),
		v7(186, 130, 255)
	}
}
local v_u_11 = { Color3.fromRGB(255, 255, 225), Color3.fromRGB(255, 228, 70), v7(255, 160, 0) }
local v12 = { Color3.fromRGB(240, 255, 255), Color3.fromRGB(120, 230, 255), v7(30, 150, 255) }
local v13 = { Color3.fromRGB(250, 236, 255), Color3.fromRGB(214, 140, 255), v7(156, 64, 255) }
local v14 = { Color3.fromRGB(255, 238, 250), Color3.fromRGB(255, 140, 220), v7(255, 60, 170) }
local v15 = { Color3.fromRGB(255, 255, 220), Color3.fromRGB(255, 242, 70), v7(255, 184, 0) }
local v_u_16 = {
	["equip1"] = v_u_11,
	["equip2"] = { Color3.fromRGB(255, 255, 225), Color3.fromRGB(255, 205, 90), v7(255, 122, 40) },
	["storage20"] = v12,
	["storage120"] = v_u_11,
	["winsPad"] = v_u_11,
	["speed2"] = v15,
	["autoRebirth"] = v12,
	["vip"] = v13,
	["autoWin"] = v_u_11,
	["autoOp"] = v12,
	["skipEye"] = v_u_11,
	["boost2"] = v15,
	["boostWins"] = v_u_11,
	["boost5"] = v12,
	["boost10"] = v_u_11,
	["skipRebirth"] = v12,
	["chakra1"] = v_u_11,
	["chakra2"] = v15,
	["chakra3"] = v14,
	["bossLuck2"] = v_u_11,
	["bossLuck5"] = { Color3.fromRGB(245, 255, 240), Color3.fromRGB(170, 255, 140), v7(50, 210, 90) }
}
local v_u_17 = { Color3.fromRGB(255, 255, 255), Color3.fromRGB(255, 242, 160), v7(255, 204, 70) }
local v_u_18 = Color3.new(1, 1, 1)
local function v_u_27(p19, p20) -- name: rainbow
	local v21 = {}
	for v22 = 0, 6 do
		local v23 = (v22 / 6 * 0.85 + p19) % 1
		local v24 = ColorSequenceKeypoint.new
		local v25 = v22 / 6
		local v26 = Color3.fromHSV
		table.insert(v21, v24(v25, v26(v23, p20, 1)))
	end
	return ColorSequence.new(v21)
end
local function v_u_31(p28) -- name: gloss
	local v29 = Instance.new("Frame")
	v29.Name = "Gloss"
	v29.BackgroundColor3 = Color3.new(1, 1, 1)
	v29.BorderSizePixel = 0
	v29.Size = UDim2.fromScale(1, 1)
	v29.ZIndex = 6
	local v30 = Instance.new("UIGradient")
	v30.Rotation = 25
	v30.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.36, 1),
		NumberSequenceKeypoint.new(0.45, 0.55),
		NumberSequenceKeypoint.new(0.5, 0.2),
		NumberSequenceKeypoint.new(0.55, 0.55),
		NumberSequenceKeypoint.new(0.64, 1),
		NumberSequenceKeypoint.new(1, 1)
	})
	v30.Offset = Vector2.new(-1, 0)
	v30.Parent = v29
	v29.Parent = p28
	return v30
end
local function v_u_38(p32) -- name: spread
	local v33 = {}
	for v34, v35 in p32 do
		local v36 = ColorSequenceKeypoint.new
		local v37 = (v34 - 1) / (#p32 - 1)
		table.insert(v33, v36(v37, v35))
	end
	return ColorSequence.new(v33)
end
local function v_u_41(p39) -- name: titleOf
	for _, v40 in p39:GetChildren() do
		if not v40:IsA("TextLabel") or (v40.Name ~= "Title" or v40.Rotation ~= 0) then
			continue
		end
		return v40
	end
	return nil
end
local function v_u_71(p_u_42, p_u_43, p_u_44, p_u_45, p_u_46) -- name: flowing
	-- upvalues: (copy) v_u_18
	local v_u_47 = #p_u_42
	local v48 = p_u_44 - p_u_43
	local v_u_49 = math.max(v48, 0.01)
	local function v58(p50) -- name: at
		-- upvalues: (copy) p_u_43, (copy) p_u_44, (copy) v_u_49, (copy) p_u_45, (copy) v_u_47, (copy) p_u_42, (copy) p_u_46, (ref) v_u_18
		local v51 = p_u_43
		local v52 = p_u_44
		local v53 = ((math.clamp(p50, v51, v52) - p_u_43) / v_u_49 - p_u_45) % 1 * v_u_47
		local v54 = math.floor(v53)
		local v55 = p_u_42[v54 % v_u_47 + 1]:Lerp(p_u_42[(v54 + 1) % v_u_47 + 1], v53 - v54)
		if p_u_46 then
			local v56 = p50 - p_u_46
			local v57 = math.abs(v56) / (v_u_49 * 0.14)
			if v57 < 1 then
				v55 = v55:Lerp(v_u_18, (1 - v57) * 0.85)
			end
		end
		return v55
	end
	local v59 = {}
	for v60 = 0, 12 do
		local v61 = p_u_43 + v_u_49 * v60 / 12
		table.insert(v59, v61)
	end
	if p_u_46 then
		for _, v62 in { -1, 0, 1 } do
			local v63 = p_u_46 + v62 * 0.14 * v_u_49
			table.insert(v59, v63)
		end
	end
	table.sort(v59)
	local v64 = { ColorSequenceKeypoint.new(0, (v58(0))) }
	local v65 = 0
	for _, v66 in v59 do
		if v65 + 0.001 >= v66 or v66 >= 0.999 then
			continue
		end
		local v67 = ColorSequenceKeypoint.new
		local v68 = v58(v66)
		table.insert(v64, v67(v66, v68))
		v65 = v66
	end
	local v69 = ColorSequenceKeypoint.new
	local v70 = v58(1)
	table.insert(v64, v69(1, v70))
	return ColorSequence.new(v64)
end
function v3.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_38, (copy) v_u_17, (copy) v_u_41, (copy) v_u_18, (copy) v_u_10, (copy) v_u_71, (copy) v_u_16, (copy) v_u_11, (copy) v_u_8, (copy) v_u_9, (copy) v_u_27, (copy) v_u_31, (copy) v_u_2
	local v_u_72 = v_u_1.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	if v_u_72 then
		v_u_72 = v_u_72:WaitForChild("Frames", 10)
	end
	if v_u_72 then
		v_u_72 = v_u_72:WaitForChild("Store", 10)
	end
	local v73
	if v_u_72 then
		v73 = v_u_72:FindFirstChild("Holder", true)
	else
		v73 = v_u_72
	end
	if v_u_72 and (v_u_72:IsA("GuiObject") and v73) then
		local v_u_74 = {}
		local v_u_75 = {}
		local function v_u_85(p76, p77) -- name: dressTitle
			-- upvalues: (copy) v_u_75, (ref) v_u_38, (ref) v_u_17, (ref) v_u_41, (ref) v_u_18, (ref) v_u_10, (ref) v_u_71, (copy) v_u_74, (ref) v_u_16, (ref) v_u_11
			if p76:IsA("TextLabel") then
				local v78 = p76.Name
				if string.sub(v78, -4) == "Text" and not v_u_75[p76] then
					v_u_75[p76] = true
					local v79 = Instance.new("UIGradient")
					v79.Name = "TitlePaint"
					v79.Color = v_u_38(v_u_17)
					v79.Rotation = 90
					v79.Parent = p76
				end
				return
			else
				local v80 = string.match(p76.Name, "^%a+_(.+)$")
				local v81 = v_u_41(p76)
				if v80 and (v81 and not v_u_75[v81]) then
					v_u_75[v81] = true
					v81.TextColor3 = v_u_18
					local v82 = v81:FindFirstChild("TitlePaint")
					if not (v82 and v82:IsA("UIGradient")) then
						v82 = Instance.new("UIGradient")
					end
					v82.Name = "TitlePaint"
					local v83 = v_u_10[v80]
					if v83 then
						v82.Rotation = 0
						v82.Color = v_u_71(v83, 0, 1, 0, nil)
						local v84 = v_u_74
						table.insert(v84, {
							["label"] = v81,
							["paint"] = v82,
							["palette"] = v83,
							["sweep"] = p77
						})
					else
						v82.Rotation = 90
						v82.Color = v_u_38(v_u_16[v80] or v_u_11)
					end
					v82.Parent = v81
				end
			end
		end
		local v_u_86 = {}
		local v_u_87 = {}
		local v_u_88 = {}
		local v_u_89 = {}
		local v_u_90 = {}
		for _, v91 in v73:GetChildren() do
			if not v91:IsA("GuiObject") then
				continue
			end
			local v92, v93 = string.match(v91.Name, "^(%a+)_(.+)$")
			if not (v92 and v93) then
				continue
			end
			local v94 = v91:FindFirstChild("UIGradient")
			if not (v94 and v94:IsA("UIGradient")) then
				v94 = nil
			end
			local v95 = v_u_8[v93]
			if v94 and v_u_9[v93] then
				v91.BackgroundColor3 = Color3.new(1, 1, 1)
				v94.Rotation = -25
				v94.Color = v_u_27(0, 0.62)
				table.insert(v_u_88, v94)
				local v96 = v91:FindFirstChild("OuterUIStroke")
				if v96 and v96:IsA("UIStroke") then
					v96.Color = Color3.new(1, 1, 1)
					local v97 = Instance.new("UIGradient")
					v97.Color = v_u_27(0, 1)
					v97.Parent = v96
					table.insert(v_u_89, v97)
				end
			elseif v94 and v95 then
				v91.BackgroundColor3 = Color3.new(1, 1, 1)
				v94.Color = ColorSequence.new(v95[1], v95[2])
				v94.Rotation = 90
				local v98 = v91:FindFirstChild("OuterUIStroke")
				if v92 == "Pack" and (v98 and v98:IsA("UIStroke")) then
					v98.Color = v95[2]:Lerp(Color3.new(0, 0, 0), 0.35)
				end
			end
			local v99 = v91:FindFirstChild("Sunburst")
			if v99 and v99:IsA("GuiObject") then
				table.insert(v_u_90, v99)
			end
			for _, v100 in v91:GetChildren() do
				if not v100:IsA("TextLabel") or v100.Name ~= "Tag" and (v100.Name ~= "Title" or v100.Rotation == 0) then
					continue
				end
				local v101 = Instance.new("UIScale")
				v101.Name = "Beat"
				v101.Parent = v100
				local v102 = {
					["label"] = v100,
					["scale"] = v101,
					["gradient"] = v100:FindFirstChildOfClass("UIGradient")
				}
				table.insert(v_u_86, v102)
			end
			local v103 = v_u_31(v91)
			table.insert(v_u_87, v103)
			v_u_85(v91, #v_u_87)
		end
		for _, v104 in v73:GetChildren() do
			v_u_85(v104, 0)
		end
		v73.ChildAdded:Connect(function(p105)
			-- upvalues: (copy) v_u_85
			task.defer(v_u_85, p105, 0)
		end)
		local v_u_106 = nil
		local function v_u_132() -- name: step
			-- upvalues: (copy) v_u_87, (copy) v_u_90, (copy) v_u_88, (ref) v_u_27, (copy) v_u_89, (copy) v_u_86, (copy) v_u_74, (ref) v_u_71
			local v107 = os.clock()
			for v108, v109 in v_u_87 do
				local v110 = (v107 + v108 * 0.35) % 3.6 / 1.1
				v109.Offset = Vector2.new(v110 >= 1 and -1 or -0.75 + v110 * 1.5, 0)
			end
			for v111, v112 in v_u_90 do
				v112.Rotation = (v107 * 25 + v111 * 37) % 360
			end
			local v113 = v107 * 0.12 % 1
			for _, v114 in v_u_88 do
				v114.Color = v_u_27(v113, 0.62)
			end
			for _, v115 in v_u_89 do
				v115.Rotation = v107 * 120 % 360
				v115.Color = v_u_27(v113, 1)
			end
			for v116, v117 in v_u_86 do
				local v118 = v107 * 5 + v116
				local v119 = math.sin(v118)
				v117.scale.Scale = math.max(v119, 0) * 0.06 + 1
				local v120 = v117.label
				local v121 = v107 * 2.2 + v116
				v120.Rotation = math.sin(v121) * 3 + 4
				if not v117.gradient then
					continue
				end
				v117.gradient.Rotation = v107 * 90 % 360
			end
			local v122 = v107 * 0.25 % 1
			for _, v123 in v_u_74 do
				local v124 = v123.label
				local v125 = v124.AbsoluteSize.X
				local v126, v127
				if v125 <= 0 then
					v126 = 1
					v127 = 0
				else
					local v128 = v124.TextBounds.X / v125
					v126 = math.clamp(v128, 0.05, 1)
					if v124.TextXAlignment == Enum.TextXAlignment.Left then
						v127 = 0
					elseif v124.TextXAlignment == Enum.TextXAlignment.Right then
						v127 = 1 - v126
						v126 = 1
					else
						v127 = (1 - v126) / 2
						v126 = (v126 + 1) / 2
					end
				end
				local v129 = (v107 + v123.sweep * 0.35) % 3.6 / 1.1
				local v130 = (v126 - v127) * 0.14
				local v131
				if v129 < 1 then
					v131 = v127 - v130 + v129 * (v126 - v127 + 2 * v130)
				else
					v131 = nil
				end
				v123.paint.Color = v_u_71(v123.palette, v127, v126, v122, v131)
			end
		end
		local function v133() -- name: sync
			-- upvalues: (copy) v_u_72, (ref) v_u_106, (copy) v_u_132, (ref) v_u_2
			if v_u_72.Visible and not v_u_106 then
				v_u_132()
				v_u_106 = v_u_2.RenderStepped:Connect(v_u_132)
			elseif not v_u_72.Visible and v_u_106 then
				v_u_106:Disconnect()
				v_u_106 = nil
			end
		end
		v_u_72:GetPropertyChangedSignal("Visible"):Connect(v133)
		if v_u_72.Visible and not v_u_106 then
			v_u_132()
			v_u_106 = v_u_2.RenderStepped:Connect(v_u_132)
		elseif not v_u_72.Visible and v_u_106 then
			v_u_106:Disconnect()
			v_u_106 = nil
		end
	end
end
v3.rainbow = v_u_27
v3.gloss = v_u_31
v3.spread = v_u_38
function v3.span(p134) -- name: span
	local v135 = p134.AbsoluteSize.X
	if v135 <= 0 then
		return 0, 1
	else
		local v136 = p134.TextBounds.X / v135
		local v137 = math.clamp(v136, 0.05, 1)
		if p134.TextXAlignment == Enum.TextXAlignment.Left then
			return 0, v137
		elseif p134.TextXAlignment == Enum.TextXAlignment.Right then
			return 1 - v137, 1
		else
			return (1 - v137) / 2, (v137 + 1) / 2
		end
	end
end
v3.flowing = v_u_71
v3.GLINT = 0.14
return v3