local v_u_1 = {}
local v2 = {
	["Promo"] = {
		["Fight"] = true,
		["New"] = true,
		["Rotation"] = true
	},
	["Starter"] = {},
	["UnlockAll"] = {},
	["WelcomeBack"] = {},
	["QuestRefresh"] = {
		["Daily"] = true,
		["Weekly"] = true
	},
	["TrophyNudge"] = {
		["Barrier"] = true,
		["Eye Pad"] = true,
		["My Eyes"] = true,
		["Menu"] = true
	},
	["GoldBubble"] = {},
	["Revive"] = {},
	["NextStep"] = {},
	["FuseSkip"] = {
		["Common"] = true,
		["Rare"] = true,
		["Epic"] = true,
		["Legendary"] = true,
		["Mythic"] = true
	}
}
v_u_1.SURFACES = v2
v_u_1.FROM_CLIENT = {
	["Promo"] = true,
	["Starter"] = true,
	["UnlockAll"] = true,
	["WelcomeBack"] = true,
	["QuestRefresh"] = true,
	["TrophyNudge"] = true,
	["GoldBubble"] = true,
	["NextStep"] = true,
	["FuseSkip"] = true
}
v_u_1.OTHER_BUY = "OtherBuy"
v_u_1.NONE = "None"
v_u_1.ATTRIBUTION_SECONDS = 900
v_u_1.FLUSH_SECONDS = 120
function v_u_1.isSurface(p3) -- name: isSurface
	-- upvalues: (copy) v_u_1
	local v4
	if type(p3) == "string" then
		v4 = v_u_1.SURFACES[p3] ~= nil
	else
		v4 = false
	end
	return v4
end
function v_u_1.eventName(p5, p6) -- name: eventName
	return p5 .. p6
end
function v_u_1.context(p7, p8) -- name: context
	-- upvalues: (copy) v_u_1
	local v9 = v_u_1.SURFACES[p7]
	if v9 and (type(p8) == "string" and v9[p8]) then
		return p8
	else
		return v_u_1.NONE
	end
end
local v_u_10 = {
	"One",
	"Two",
	"Three",
	"Four",
	"Five",
	"Six",
	"Seven",
	"Eight",
	"Nine"
}
local v_u_11 = {
	"Ten",
	"Eleven",
	"Twelve",
	"Thirteen",
	"Fourteen",
	"Fifteen",
	"Sixteen",
	"Seventeen",
	"Eighteen",
	"Nineteen"
}
local v_u_12 = {
	"",
	"Twenty",
	"Thirty",
	"Forty",
	"Fifty",
	"Sixty",
	"Seventy",
	"Eighty",
	"Ninety"
}
function v_u_1.words(p13) -- name: words
	-- upvalues: (copy) v_u_1, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12
	local v14 = math.abs(p13)
	local v15 = math.floor(v14)
	if v15 == 0 then
		return "Zero"
	end
	if v15 >= 1000000 then
		return "Many"
	end
	local v16 = {}
	local v17 = v15 // 1000
	if v17 > 0 then
		local v18 = v_u_1.words(v17) .. " Thousand"
		table.insert(v16, v18)
		v15 = v15 % 1000
	end
	if v15 >= 100 then
		local v19 = v_u_10[v15 // 100] .. " Hundred"
		table.insert(v16, v19)
		v15 = v15 % 100
	end
	if v15 > 0 then
		local v20
		if v15 < 10 then
			v20 = v_u_10[v15] or ""
		elseif v15 < 20 then
			v20 = v_u_11[v15 - 9]
		else
			local v21 = v15 // 10
			local v22 = v15 % 10
			if v22 == 0 then
				v20 = v_u_12[v21]
			else
				v20 = v_u_12[v21] .. " " .. v_u_10[v22]
			end
		end
		table.insert(v16, v20)
	end
	return table.concat(v16, " ")
end
function v_u_1.label(p23) -- name: label
	-- upvalues: (copy) v_u_1
	local v25 = string.gsub(p23, "%d+", function(p24)
		-- upvalues: (ref) v_u_1
		return " " .. v_u_1.words(tonumber(p24) or 0) .. " "
	end)
	local v26 = string.gsub(v25, "[^%a ]", " ")
	local v27 = string.gsub(v26, "%s+", " ")
	local v28 = string.match(v27, "^%s*(.-)%s*$") or ""
	return v28 == "" and "Unknown" or string.sub(v28, 1, 60)
end
function v_u_1.worldLabel(p29) -- name: worldLabel
	-- upvalues: (copy) v_u_1
	local v30 = v_u_1.words
	local v31 = math.floor(p29)
	return "World " .. v30((math.clamp(v31, 1, 99)))
end
function v_u_1.add(p32, p33, p34, p35) -- name: add
	local v36 = p33 .. "|" .. p34 .. "|" .. p35
	local v37 = p32[v36]
	if v37 then
		v37.count = v37.count + 1
	else
		p32[v36] = {
			["surface"] = nil,
			["item"] = nil,
			["context"] = nil,
			["count"] = 1,
			["surface"] = p33,
			["item"] = p34,
			["context"] = p35
		}
	end
end
function v_u_1.drain(p38) -- name: drain
	local v39 = {}
	for v40, v41 in p38 do
		table.insert(v39, v41)
		p38[v40] = nil
	end
	table.sort(v39, function(p42, p43)
		return p42.surface .. p42.item .. p42.context < p43.surface .. p43.item .. p43.context
	end)
	return v39
end
function v_u_1.itemId(p44, p45) -- name: itemId
	return p44 .. ":" .. p45
end
function v_u_1.remember(p46, p47, p48, p49, p50, p51) -- name: remember
	-- upvalues: (copy) v_u_1
	p46[v_u_1.itemId(p47, p48)] = {
		["surface"] = p49,
		["context"] = p50,
		["at"] = p51
	}
end
function v_u_1.claim(p52, p53, p54, p55) -- name: claim
	-- upvalues: (copy) v_u_1
	local v56 = v_u_1.itemId(p53, p54)
	local v57 = p52[v56]
	p52[v56] = nil
	if v57 and p55 - v57.at <= v_u_1.ATTRIBUTION_SECONDS then
		return v57.surface, v57.context
	else
		return nil, nil
	end
end
function v_u_1.budget(p58) -- name: budget
	return math.max(p58, 0) * 10 + 60
end
return v_u_1