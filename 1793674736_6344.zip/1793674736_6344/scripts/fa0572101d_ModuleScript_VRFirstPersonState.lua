return {
	["inFirstPerson"] = false
}