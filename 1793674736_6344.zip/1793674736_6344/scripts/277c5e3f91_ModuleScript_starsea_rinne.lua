local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(200, 226, 255)
local v_u_5 = Color3.fromRGB(8, 8, 16)
local v_u_6 = Color3.new(1, 1, 1)
return function(p_u_7)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6, (copy) v_u_5
	return {
		["w4_starsea_rinne"] = function(p_u_8, p9)
			-- upvalues: (ref) v_u_2, (copy) p_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6, (ref) v_u_5
			local v_u_10 = v_u_2.color(p9.color)
			local v11 = v_u_2.color(p9.color2)
			local v12 = p_u_8.headY / 1.5
			local v_u_13 = math.clamp(v12, 0.7, 3)
			local v_u_14 = p_u_8.headY * 0.6
			local v_u_15 = v_u_14 - (p_u_8.feet + v_u_13 * 0.75)
			local v_u_17 = p_u_7.throb(p_u_8, 4.2, 1.8, 1.5, function(p16)
				-- upvalues: (ref) v_u_2, (ref) p_u_7, (copy) p_u_8, (copy) v_u_10, (ref) v_u_3
				v_u_2.ring(p_u_7.feetAt(p_u_8, p16, 0.15), v_u_10, 5.5 * p_u_8.fx, 0.55, v_u_3.Ring)
			end)
			local function v_u_63(p18, p19, p20) -- name: capeFrame
				-- upvalues: (copy) v_u_13, (copy) v_u_14, (copy) v_u_15
				local v21 = (p19 * 0.95 + 1.2) * v_u_13
				local v22 = p20 * 1.7 + p18 * 0.8 - p19 * 1.4
				local v23 = math.sin(v22) * 0.22 * p19 * p19
				local v24 = (p19 * 0.95 + 0.65 + v23) * v_u_13
				local v25 = p18 * v21
				local v26 = v_u_14 - p19 * v_u_15
				local v27 = Vector3.new(v25, v26, v24)
				local v28 = p18 + 0.05
				local v29 = (p19 * 0.95 + 1.2) * v_u_13
				local v30 = p20 * 1.7 + v28 * 0.8 - p19 * 1.4
				local v31 = math.sin(v30) * 0.22 * p19 * p19
				local v32 = (p19 * 0.95 + 0.65 + v31) * v_u_13
				local v33 = v28 * v29
				local v34 = v_u_14 - p19 * v_u_15
				local v35 = Vector3.new(v33, v34, v32)
				local v36 = p18 - 0.05
				local v37 = (p19 * 0.95 + 1.2) * v_u_13
				local v38 = p20 * 1.7 + v36 * 0.8 - p19 * 1.4
				local v39 = math.sin(v38) * 0.22 * p19 * p19
				local v40 = (p19 * 0.95 + 0.65 + v39) * v_u_13
				local v41 = v36 * v37
				local v42 = v_u_14 - p19 * v_u_15
				local v43 = v35 - Vector3.new(v41, v42, v40)
				local v44 = p19 + 0.05
				local v45 = (v44 * 0.95 + 1.2) * v_u_13
				local v46 = p20 * 1.7 + p18 * 0.8 - v44 * 1.4
				local v47 = math.sin(v46) * 0.22 * v44 * v44
				local v48 = (v44 * 0.95 + 0.65 + v47) * v_u_13
				local v49 = p18 * v45
				local v50 = v_u_14 - v44 * v_u_15
				local v51 = Vector3.new(v49, v50, v48)
				local v52 = p19 - 0.05
				local v53 = math.max(v52, 0)
				local v54 = (v53 * 0.95 + 1.2) * v_u_13
				local v55 = p20 * 1.7 + p18 * 0.8 - v53 * 1.4
				local v56 = math.sin(v55) * 0.22 * v53 * v53
				local v57 = (v53 * 0.95 + 0.65 + v56) * v_u_13
				local v58 = p18 * v54
				local v59 = v_u_14 - v53 * v_u_15
				local v60 = v51 - Vector3.new(v58, v59, v57)
				local v61 = v43.Unit
				local v62 = v61:Cross(-v60.Unit)
				if v62.Z < 0 then
					v62 = -v62
				end
				return CFrame.fromMatrix(v27, v61, v62.Unit:Cross(v61))
			end
			for v64 = 1, 3 do
				for v65 = 1, 2 do
					local v_u_66 = (v64 - 1) * 2 / 3 + -1
					local v_u_67 = v64 * 2 / 3 + -1
					local v_u_68 = (v65 - 1) / 2
					local v_u_69 = v65 / 2
					local v70 = p_u_7.bar
					local v71 = v_u_13 * 0.12
					local v72 = v70(Vector3.new(1, 1, v71), v11, 0.04, Enum.Material.SmoothPlastic)
					local v_u_73 = p_u_7.scalable(v72)
					p_u_7.add(p_u_8, v72, function(p74, p75)
						-- upvalues: (copy) v_u_66, (copy) v_u_68, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_67, (copy) v_u_69, (copy) v_u_73
						local v76 = v_u_66
						local v77 = v_u_68
						local v78 = (v77 * 0.95 + 1.2) * v_u_13
						local v79 = p75 * 1.7 + v76 * 0.8 - v77 * 1.4
						local v80 = math.sin(v79) * 0.22 * v77 * v77
						local v81 = (v77 * 0.95 + 0.65 + v80) * v_u_13
						local v82 = v76 * v78
						local v83 = v_u_14 - v77 * v_u_15
						local v84 = Vector3.new(v82, v83, v81)
						local v85 = v_u_67
						local v86 = v_u_68
						local v87 = (v86 * 0.95 + 1.2) * v_u_13
						local v88 = p75 * 1.7 + v85 * 0.8 - v86 * 1.4
						local v89 = math.sin(v88) * 0.22 * v86 * v86
						local v90 = (v86 * 0.95 + 0.65 + v89) * v_u_13
						local v91 = v85 * v87
						local v92 = v_u_14 - v86 * v_u_15
						local v93 = Vector3.new(v91, v92, v90)
						local v94 = v_u_66
						local v95 = v_u_69
						local v96 = (v95 * 0.95 + 1.2) * v_u_13
						local v97 = p75 * 1.7 + v94 * 0.8 - v95 * 1.4
						local v98 = math.sin(v97) * 0.22 * v95 * v95
						local v99 = (v95 * 0.95 + 0.65 + v98) * v_u_13
						local v100 = v94 * v96
						local v101 = v_u_14 - v95 * v_u_15
						local v102 = Vector3.new(v100, v101, v99)
						local v103 = v_u_67
						local v104 = v_u_69
						local v105 = (v104 * 0.95 + 1.2) * v_u_13
						local v106 = p75 * 1.7 + v103 * 0.8 - v104 * 1.4
						local v107 = math.sin(v106) * 0.22 * v104 * v104
						local v108 = (v104 * 0.95 + 0.65 + v107) * v_u_13
						local v109 = v103 * v105
						local v110 = v_u_14 - v104 * v_u_15
						local v111 = Vector3.new(v109, v110, v108)
						local v112 = (v84 + v93) / 2
						local v113 = (v102 + v111) / 2
						local v114 = (v112 - v113).Unit
						local v115 = v114:Cross((v93 - v84 + (v111 - v102)):Cross(v114).Unit).Unit
						local v116 = v_u_73
						local v117 = ((v93 - v84).Magnitude + (v111 - v102).Magnitude) / 2 * 1.04
						local v118 = (v113 - v112).Magnitude * 1.03
						v116.Scale = Vector3.new(v117, v118, 1)
						return p74 * CFrame.fromMatrix((v112 + v113) / 2, v115, v114)
					end)
				end
			end
			local function v152(p_u_119, p_u_120, p_u_121, p_u_122) -- name: edge
				-- upvalues: (ref) p_u_7, (copy) v_u_13, (copy) v_u_10, (copy) p_u_8, (copy) v_u_14, (copy) v_u_15
				local v123 = p_u_7.bar
				local v124 = v_u_13 * 0.16
				local v125 = v_u_13 * 0.16
				local v126 = v123(Vector3.new(v124, v125, 1), v_u_10, 0)
				local v_u_127 = p_u_7.scalable(v126)
				p_u_7.add(p_u_8, v126, function(p128, p129)
					-- upvalues: (copy) p_u_119, (copy) p_u_120, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (copy) p_u_121, (copy) p_u_122, (ref) p_u_7, (copy) v_u_127
					local v130 = p_u_119
					local v131 = p_u_120
					local v132 = (v131 * 0.95 + 1.2) * v_u_13
					local v133 = p129 * 1.7 + v130 * 0.8 - v131 * 1.4
					local v134 = math.sin(v133) * 0.22 * v131 * v131
					local v135 = (v131 * 0.95 + 0.65 + v134) * v_u_13
					local v136 = v130 * v132
					local v137 = v_u_14 - v131 * v_u_15
					local v138 = Vector3.new(v136, v137, v135)
					local v139 = p_u_121
					local v140 = p_u_122
					local v141 = (v140 * 0.95 + 1.2) * v_u_13
					local v142 = p129 * 1.7 + v139 * 0.8 - v140 * 1.4
					local v143 = math.sin(v142) * 0.22 * v140 * v140
					local v144 = (v140 * 0.95 + 0.65 + v143) * v_u_13
					local v145 = v139 * v141
					local v146 = v_u_14 - v140 * v_u_15
					local v147 = Vector3.new(v145, v146, v144)
					local v148, v149 = p_u_7.between(v138, v147)
					local v150 = v_u_127
					local v151 = v149 + v_u_13 * 0.12
					v150.Scale = Vector3.new(1, 1, v151)
					return p128 * v148
				end)
			end
			for _, v153 in { -1, 1 } do
				v152(v153 * 1.02, 0, v153 * 1.02, 0.5)
				v152(v153 * 1.02, 0.5, v153 * 1.02, 1)
			end
			v152(-1, 1, -0.33333333333333337, 1)
			v152(-0.33333333333333337, 1, 0.33333333333333326, 1)
			v152(0.33333333333333326, 1, 1, 1)
			for v_u_154 = 1, 8 do
				local v_u_155 = v_u_154 * 0.618 % 1 * 1.7 + -0.85
				local v_u_156 = v_u_154 * 0.37 % 1
				local v_u_157 = v_u_154 % 3 * 0.025 + 0.07
				local v158 = p_u_7.bar
				local v159 = Vector3.new(0.26, 0.26, 0.26) * v_u_13
				local v160
				if v_u_154 % 3 == 0 then
					v160 = v_u_4
				else
					v160 = v_u_6
				end
				local v161 = v158(v159, v160, 0)
				local v_u_162 = p_u_7.scalable(v161)
				p_u_7.add(p_u_8, v161, function(p163, p164)
					-- upvalues: (copy) v_u_156, (copy) v_u_157, (copy) v_u_63, (copy) v_u_155, (copy) v_u_13
					return p163 * v_u_63(v_u_155, (v_u_156 + p164 * v_u_157) % 1, p164) * CFrame.new(0, 0, v_u_13 * 0.1) * CFrame.Angles(0, 0, 0.7853981633974483)
				end)
				local v165 = p_u_8.ticks
				table.insert(v165, function(_, p166)
					-- upvalues: (copy) v_u_156, (copy) v_u_157, (copy) v_u_154, (copy) v_u_162
					local v167 = (v_u_156 + p166 * v_u_157) % 1
					local v168 = v167 / 0.1
					local v169 = (1 - v167) / 0.15
					local v170 = math.min(v168, v169, 1)
					local v171 = p166 * 2.6 + v_u_154 * 1.9
					local v172 = math.sin(v171)
					local v173 = v_u_162
					local v174 = (math.abs(v172) * 0.55 + 0.45) * v170
					v173.Scale = Vector3.new(1, 1, 1) * math.max(v174, 0.01)
				end)
			end
			for _, v_u_175 in { -1, 1 } do
				local function v181(p176, p177) -- name: clasp
					-- upvalues: (copy) v_u_175, (copy) v_u_13, (copy) v_u_14
					local v178 = p176 * CFrame.new(v_u_175 * 0.85 * v_u_13, v_u_14 + v_u_13 * 0.18, v_u_13 * 0.05)
					local v179 = CFrame.Angles
					local v180 = p177 * 2 + v_u_175
					return v178 * v179(0, 0, 0.7853981633974483 + math.sin(v180) * 0.2)
				end
				p_u_7.add(p_u_8, p_u_7.bar(Vector3.new(0.34, 0.34, 0.2) * v_u_13, v_u_6, 0), v181)
				p_u_7.add(p_u_8, p_u_7.ball(v_u_13 * 0.62, v_u_10, 0.45), p_u_7.behind(v181, v_u_13 * 0.15))
			end
			local v_u_184 = p_u_7.group(p_u_8, function(p182, p183)
				-- upvalues: (copy) v_u_63, (copy) v_u_13
				return p182 * v_u_63(0, 0.27, p183) * CFrame.new(0, 0, v_u_13 * 0.12)
			end)
			local v_u_185, v_u_186 = p_u_7.picture(v_u_13 * 2.1, v_u_3.StarseaGalaxy, v_u_4, 0)
			p_u_7.add(p_u_8, v_u_185, function(_, p187)
				-- upvalues: (copy) v_u_184
				return v_u_184.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, -p187 * 0.6, 0)
			end)
			local v188 = p_u_7.picture(v_u_13 * 2.6, v_u_3.Ring, v_u_10, 0.05)
			p_u_7.add(p_u_8, v188, function(_, p189)
				-- upvalues: (copy) v_u_184, (copy) v_u_13
				return v_u_184.cf * CFrame.new(0, 0, v_u_13 * 0.02) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, p189 * 0.4, 0)
			end)
			local v_u_190 = -1
			local v191 = p_u_8.ticks
			local function v195()
				-- upvalues: (copy) v_u_17, (ref) v_u_190, (copy) v_u_13, (copy) v_u_185, (copy) v_u_186, (ref) v_u_4, (ref) v_u_6
				local v192 = v_u_17()
				if v192 ~= v_u_190 then
					v_u_190 = v192
					local v193 = v_u_13 * 2.1 * (1 + v192 * 0.35)
					v_u_185.Size = Vector3.new(v193, 0.05, v193)
					for _, v194 in v_u_186 do
						v194.Color3 = v_u_4:Lerp(v_u_6, v192)
					end
				end
			end
			table.insert(v191, v195)
			for v_u_196 = 1, 3 do
				local function v199(_, p197) -- name: at
					-- upvalues: (copy) v_u_196, (copy) v_u_184, (copy) v_u_13
					local v198 = p197 * 1.2 + v_u_196 / 3 * 3.141592653589793 * 2
					return v_u_184.cf * CFrame.new(math.cos(v198) * 0.95 * v_u_13, math.sin(v198) * 0.95 * v_u_13, v_u_13 * 0.08)
				end
				p_u_7.add(p_u_8, p_u_7.dark(p_u_7.ball(v_u_13 * 0.32, v_u_5, 0, Enum.Material.SmoothPlastic)), v199)
				p_u_7.add(p_u_8, p_u_7.ball(v_u_13 * 0.5, v_u_10, 0.5), p_u_7.behind(v199, v_u_13 * 0.12))
			end
			local v_u_200 = p_u_7.ball(v_u_13 * 0.45, v_u_6, 1)
			local v_u_201 = p_u_7.tail(v_u_200, v_u_6, v_u_10, v_u_13 * 0.4, 0.3)
			v_u_201.Enabled = false
			local v_u_202 = -10
			local v_u_203 = 1
			p_u_7.add(p_u_8, v_u_200, function(p204, p205)
				-- upvalues: (ref) v_u_202, (ref) v_u_203, (copy) v_u_13, (copy) p_u_8, (copy) v_u_184
				local v206 = (p205 - v_u_202) / 0.4
				local v207 = math.clamp(v206, 0, 1)
				local v208 = v_u_203 * 5 * v_u_13
				local v209 = p_u_8.headY + v_u_13 * 7
				local v210 = v_u_13 * -2.5
				local v211 = p204 * Vector3.new(v208, v209, v210)
				local v212 = (v_u_184.cf * CFrame.new(0, 0, v_u_13 * 0.2)).Position
				return CFrame.new(v211:Lerp(v212, v207 * v207))
			end)
			local v213 = p_u_8.ticks
			local function v216(p214, p215)
				-- upvalues: (copy) v_u_17, (ref) v_u_202, (ref) v_u_203, (copy) v_u_201, (copy) v_u_200, (ref) p_u_7, (ref) v_u_2, (copy) v_u_184, (copy) v_u_10, (copy) v_u_13
				if v_u_17() > 0.97 and p215 - v_u_202 > 1 then
					v_u_202 = p215
					v_u_203 = -v_u_203
					v_u_201:Clear()
					v_u_201.Enabled = true
					v_u_200.Transparency = 0
				end
				if p215 - v_u_202 >= 0.4 and v_u_200.Transparency < 1 then
					v_u_200.Transparency = 1
					v_u_201.Enabled = false
					if (p214.Position - p_u_7.camPos()).Magnitude < 120 then
						v_u_2.flash(v_u_184.cf.Position, v_u_10, v_u_13 * 3.5, 0.25)
					end
				end
			end
			table.insert(v213, v216)
			p_u_7.particles(p_u_8, "AuraMode", v_u_10, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_7.particles(p_u_8, "Petals", v_u_4, {
				["rate"] = 1,
				["glow"] = 0.7,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end