local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TextService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.Events)
local v_u_7 = require(script.Parent.Sfx)
local v_u_8 = require(script.Parent.State)
local v_u_9 = require(script.Parent.Streamed)
local v_u_10 = require(script.Parent.Fx.Kit)
local v_u_11 = require(v2.Shared.Config.Images)
local v_u_12 = require(v2.Shared.Config.Stages)
local v_u_13 = require(v2.Shared.Config.World)
local v_u_14 = require(v2.Shared.Logic.Format)
local v_u_15 = require(v2.Shared.Logic.StageGate)
local v_u_16 = require(v2.Shared.Net)
local v_u_17 = v1.LocalPlayer
local v_u_18 = Color3.fromRGB(90, 255, 140)
local v_u_19 = Color3.fromRGB(255, 40, 60)
local v_u_20 = Color3.fromRGB(255, 185, 40)
local v_u_21 = Color3.fromRGB(255, 110, 110)
local v_u_22 = Color3.fromRGB(127, 255, 140)
local v23 = {}
local v_u_24 = {}
local function v_u_27(p25) -- name: gatesFor
	-- upvalues: (copy) v_u_24
	local v26 = v_u_24[p25]
	if not v26 then
		v26 = {
			["barriers"] = {},
			["pads"] = {}
		}
		v_u_24[p25] = v26
	end
	return v26
end
local v_u_28 = 1
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = {}
local function v_u_61(p34, p35, p36, p37) -- name: paint
	-- upvalues: (ref) v_u_28, (ref) v_u_32, (copy) v_u_19, (ref) v_u_29, (copy) v_u_15, (copy) v_u_8, (copy) v_u_10, (copy) v_u_18, (copy) v_u_13, (copy) v_u_7, (copy) v_u_20, (ref) v_u_30, (ref) v_u_31, (copy) v_u_27
	if p35 == 0 then
		local v38
		if p34 == v_u_28 then
			v38 = v_u_32 == 1
		else
			v38 = false
		end
		local v39 = p36.part
		local v40
		if v38 then
			v40 = v_u_19
		else
			v40 = p36.baseColor
		end
		v39.Color = v40
		p36.part.Transparency = v38 and 0.55 or p36.baseTransparency
	else
		local v41
		if p34 == v_u_28 then
			v41 = p35 <= v_u_29
		else
			v41 = false
		end
		local v42
		if v41 then
			local v43
			if p35 < 1 then
				v43 = nil
			else
				v43 = v_u_15.need(p34, p35 + 1, v_u_8.number(p34 == 1 and "BestStage" or "BestStage" .. tostring(p34)), v_u_8.number("TotalWins"))
			end
			v42 = v43 ~= nil
		else
			v42 = v41
		end
		if v41 then
			v41 = not v42
		end
		p36.part.CanCollide = not v41
		if v41 then
			local v44 = p36.sign
			if v44 then
				v44 = v44:FindFirstChild("Left")
			end
			if not (v44 and v44:IsA("TextLabel")) then
				v44 = nil
			end
			if v44 then
				v44.Text = "CLEARED!"
			end
			if p37 then
				local v45 = v_u_10.tween
				local v46 = p36.part
				local v47 = {}
				local v48 = p36.baseTransparency + 0.25
				v47.Transparency = math.max(v48, 0.65)
				v47.Color = v_u_18
				v45(v46, 0.6, v47)
				local v49 = p36.part.Position
				for v50 = -2, 2 do
					local v51 = v_u_10.burst
					local v52 = v50 * v_u_13.PATH_WIDTH / 5
					v51("Sparkle", v49 + Vector3.new(v52, -6, 0), nil, 1.2)
				end
				v_u_10.burst("Flash", v49, p36.part.Color, 1.2)
				v_u_7.play("GateOpen", {
					["at"] = v49
				})
			else
				local v53 = p36.part
				local v54 = p36.baseTransparency + 0.25
				v53.Transparency = math.max(v54, 0.65)
				p36.part.Color = v_u_18
			end
		else
			p36.part.Transparency = p36.baseTransparency
			local v55 = p36.part
			local v56
			if v42 then
				v56 = v_u_20
			else
				v56 = p36.baseColor
			end
			v55.Color = v56
			if p36.sign then
				p36.sign.Enabled = true
			end
			local v57 = p36.sign
			if v57 then
				v57 = v57:FindFirstChild("Left")
			end
			if not (v57 and v57:IsA("TextLabel")) then
				v57 = nil
			end
			if v57 then
				v57.Text = (p34 ~= v_u_28 or (p35 ~= v_u_30 or v_u_31 <= 0)) and "" or ("%* LEFT"):format(v_u_31)
			end
		end
		if p34 == v_u_28 and v_u_32 > 0 then
			local v58 = v_u_32
			local v59 = v_u_27(p34)
			local v60
			if v58 == 1 then
				v60 = v59.entrance
			else
				v60 = v59.barriers[v58 - 1]
			end
			if v60 == p36 then
				p36.part.Color = v_u_19
				p36.part.Transparency = 0.55
			end
		end
	end
end
local function v_u_69(p62, p63, p64, p65) -- name: paintPad
	-- upvalues: (ref) v_u_28, (copy) v_u_33
	local v66
	if p62 == v_u_28 and v_u_33[p63] ~= nil then
		v66 = v_u_33[p63][p64] == true
	else
		v66 = false
	end
	p65.top.Transparency = v66 and 0.65 or 0
	local v67 = p65.top
	local v68
	if v66 then
		v68 = Color3.fromRGB(120, 120, 130)
	else
		v68 = p65.color
	end
	v67.Color = v68
	if p65.amount then
		p65.amount.TextTransparency = v66 and 0.5 or 0
	end
	if p65.icon then
		p65.icon.ImageTransparency = v66 and 0.5 or 0
	end
end
local function v_u_87(p70, p71, p72, p73) -- name: fillPad
	-- upvalues: (copy) v_u_14, (copy) v_u_4, (copy) v_u_11
	local v74 = "+" .. v_u_14.short(p73)
	p71.Text = v74
	local v75 = p70.Size.X.Scale
	local v76 = p70.Size.Y.Scale
	local v77 = p71.Size.Y.Scale * v76
	if v75 > 0 and v77 > 0 then
		local v78 = not p72 and 0 or v77
		local v79 = not p72 and 0 or v77 * 0.15
		local v80 = p71.FontFace
		local v81 = Instance.new("GetTextBoundsParams")
		v81.Text = v74
		v81.Font = v80
		v81.Size = 100
		v81.Width = 100000
		local v82 = (v_u_4:GetTextBoundsAsync(v81).X / 100 + 0.1) * v77
		local v83 = v75 - v78 - v79 - 0.4
		local v84 = math.min(v82, v83)
		local v85 = (v75 - (v84 + v79 + v78)) / 2
		local v86
		if p72 then
			v86 = Enum.TextXAlignment.Right
		else
			v86 = Enum.TextXAlignment.Center
		end
		p71.TextXAlignment = v86
		p71.AnchorPoint = Vector2.new(0.5, 0.5)
		p71.Size = UDim2.fromScale(v84 / v75, p71.Size.Y.Scale)
		p71.Position = UDim2.fromScale((v85 + v84 / 2) / v75, p71.Position.Y.Scale)
		if p72 then
			p72.Image = v_u_11.Icon.Trophy
			p72.AnchorPoint = Vector2.new(0.5, 0.5)
			p72.Position = UDim2.fromScale((v85 + v84 + v79 + v78 / 2) / v75, p72.Position.Y.Scale)
		end
	end
end
local function v_u_100(p88) -- name: repaintAll
	-- upvalues: (copy) v_u_27, (copy) v_u_61, (ref) v_u_28, (ref) v_u_32, (copy) v_u_19, (copy) v_u_69
	local v89 = v_u_27(p88)
	for v90, v91 in v89.barriers do
		v_u_61(p88, v90, v91, false)
	end
	if v89.entrance then
		local v92 = v89.entrance
		local v93
		if p88 == v_u_28 then
			v93 = v_u_32 == 1
		else
			v93 = false
		end
		local v94 = v92.part
		local v95
		if v93 then
			v95 = v_u_19
		else
			v95 = v92.baseColor
		end
		v94.Color = v95
		v92.part.Transparency = v93 and 0.55 or v92.baseTransparency
	end
	for v96, v97 in v89.pads do
		for v98, v99 in v97 do
			v_u_69(p88, v96, v98, v99)
		end
	end
end
local function v_u_113(p101, p102, p103) -- name: writeTrophies
	-- upvalues: (copy) v_u_12, (copy) v_u_8, (copy) v_u_14, (copy) v_u_22, (copy) v_u_21
	local v104
	if p101 then
		v104 = p101:FindFirstChild("Sub")
	else
		v104 = p101
	end
	if p101 and (v104 and v104:IsA("TextLabel")) then
		local v105 = p101:FindFirstChild("Title")
		if p101:GetAttribute("SubY") == nil then
			p101:SetAttribute("SubY", v104.Position.Y.Scale)
			if v105 and v105:IsA("GuiObject") then
				p101:SetAttribute("TitleY", v105.Position.Y.Scale)
			end
		end
		local v106 = v_u_12.forWorld(p102)[p103]
		if v106 then
			v106 = v106.needWins
		end
		local v107
		if v106 == nil then
			v107 = false
		else
			v107 = v_u_8.number(p102 == 1 and "BestStage" or "BestStage" .. tostring(p102)) < p103
		end
		local v108 = p101:FindFirstChild("Trophies")
		if v107 then
			if not (v108 and v108:IsA("TextLabel")) then
				v108 = v104:Clone()
				v108.Name = "Trophies"
				v108.Size = UDim2.fromScale(v104.Size.X.Scale, 0.07)
				v108.Parent = p101
			end
			if v105 and v105:IsA("GuiObject") then
				v105.Position = UDim2.new(v105.Position.X, UDim.new(0.5, 0))
			end
			if v104 and v104:IsA("GuiObject") then
				v104.Position = UDim2.new(v104.Position.X, UDim.new(0.655, 0))
			end
			if v108 and v108:IsA("GuiObject") then
				v108.Position = UDim2.new(v108.Position.X, UDim.new(0.735, 0))
			end
			local v109 = v106 or 0
			v108.Visible = true
			v108.Text = "NEED " .. v_u_14.short(v109) .. " TROPHIES"
			local v110
			if v109 <= v_u_8.number("TotalWins") then
				v110 = v_u_22
			else
				v110 = v_u_21
			end
			v108.TextColor3 = v110
		else
			if v108 and v108:IsA("TextLabel") then
				v108.Visible = false
			end
			local v111 = p101:GetAttribute("SubY")
			if v104 and v104:IsA("GuiObject") then
				v104.Position = UDim2.new(v104.Position.X, UDim.new(v111, 0))
			end
			local v112 = p101:GetAttribute("TitleY")
			if type(v112) == "number" and (v105 and v105:IsA("GuiObject")) then
				v105.Position = UDim2.new(v105.Position.X, UDim.new(v112, 0))
			end
		end
	else
		return
	end
end
local function v_u_117(p114) -- name: barrierOf
	local v115 = p114:FindFirstChild("Sign")
	local v116 = {
		["part"] = p114
	}
	if not (v115 and v115:IsA("SurfaceGui")) then
		v115 = nil
	end
	v116.sign = v115
	v116.baseTransparency = p114.Transparency
	v116.baseColor = p114.Color
	return v116
end
local function v_u_134(p118, p_u_119, p_u_120) -- name: watchStage
	-- upvalues: (copy) v_u_9, (copy) v_u_27, (copy) v_u_69, (copy) v_u_87, (copy) v_u_12, (copy) v_u_117, (copy) v_u_14, (copy) v_u_113, (copy) v_u_61
	for _, v_u_121 in { "gold", "purple" } do
		v_u_9.each(p118, v_u_121 == "gold" and "PadGold" or "PadPurple", function(p122)
			-- upvalues: (copy) p_u_119, (copy) v_u_121, (ref) v_u_27, (copy) p_u_120, (ref) v_u_69, (ref) v_u_87, (ref) v_u_12
			local v123 = p122:WaitForChild("Pad", 10)
			if not (p122:IsA("Model") and (v123 and v123:IsA("BasePart"))) then
				warn((("[Gates] Stage%* has no %* win pad"):format(p_u_119, v_u_121)))
				return nil
			end
			local v124 = v123:FindFirstChild("Label")
			local v125
			if v124 then
				v125 = v124:FindFirstChild("Amount")
			else
				v125 = v124
			end
			local v126
			if v124 then
				v126 = v124:FindFirstChild("Icon")
			else
				v126 = v124
			end
			if not (v125 and v125:IsA("TextLabel")) then
				v125 = nil
			end
			if not (v126 and v126:IsA("ImageLabel")) then
				v126 = nil
			end
			local v_u_127 = {
				["model"] = p122,
				["top"] = v123,
				["amount"] = v125,
				["icon"] = v126,
				["color"] = v123.Color
			}
			local v_u_128 = v_u_27(p_u_120).pads
			v_u_128[p_u_119] = v_u_128[p_u_119] or {}
			v_u_128[p_u_119][v_u_121] = v_u_127
			v_u_69(p_u_120, p_u_119, v_u_121, v_u_127)
			if v124 and (v124:IsA("BillboardGui") and v125) then
				v_u_87(v124, v125, v126, v_u_12.padWins(p_u_119, v_u_121, p_u_120))
			else
				warn((("[Gates] Stage%* %* has no Label.Amount to show its trophies"):format(p_u_119, p122.Name)))
			end
			return function()
				-- upvalues: (copy) v_u_128, (ref) p_u_119, (ref) v_u_121, (copy) v_u_127
				if v_u_128[p_u_119] and v_u_128[p_u_119][v_u_121] == v_u_127 then
					v_u_128[p_u_119][v_u_121] = nil
				end
			end
		end)
	end
	v_u_9.each(p118, "Barrier", function(p129)
		-- upvalues: (ref) v_u_117, (ref) v_u_12, (copy) p_u_120, (copy) p_u_119, (ref) v_u_14, (ref) v_u_113, (ref) v_u_27, (ref) v_u_61
		if not p129:IsA("BasePart") then
			return nil
		end
		local v_u_130 = v_u_117(p129)
		local v131 = v_u_130.sign
		local v132 = v_u_12.forWorld(p_u_120)[p_u_119 + 1]
		if v131 then
			v131 = v131:FindFirstChild("Sub")
		end
		if v132 and (v131 and v131:IsA("TextLabel")) then
			v131.Text = "RECOMMENDED CHAKRA " .. v_u_14.short(v132.recommended)
		end
		v_u_113(v_u_130.sign, p_u_120, p_u_119 + 1)
		local v_u_133 = v_u_27(p_u_120)
		v_u_133.barriers[p_u_119] = v_u_130
		v_u_61(p_u_120, p_u_119, v_u_130, false)
		return function()
			-- upvalues: (copy) v_u_133, (ref) p_u_119, (copy) v_u_130
			if v_u_133.barriers[p_u_119] == v_u_130 then
				v_u_133.barriers[p_u_119] = nil
			end
		end
	end)
end
local function v_u_150(p135, p_u_136) -- name: watchMap
	-- upvalues: (copy) v_u_13, (copy) v_u_134, (copy) v_u_9, (copy) v_u_117, (copy) v_u_12, (copy) v_u_14, (copy) v_u_27, (ref) v_u_28, (ref) v_u_32, (copy) v_u_19
	local v137 = p135:WaitForChild("Stages", 30)
	if v137 then
		for v138 = 1, v_u_13.STAGE_COUNT do
			local v139 = v137:WaitForChild("Stage" .. v138, 30)
			if not v139 then
				continue
			end
			v_u_134(v139, v138, p_u_136)
		end
	end
	local v140 = p135:WaitForChild("Hub", 30)
	if v140 then
		v_u_9.each(v140, "Entrance", function(p141)
			-- upvalues: (ref) v_u_117, (ref) v_u_12, (copy) p_u_136, (ref) v_u_14, (ref) v_u_27, (ref) v_u_28, (ref) v_u_32, (ref) v_u_19
			local v142 = p141:WaitForChild("Barrier", 10)
			if not (v142 and v142:IsA("BasePart")) then
				return nil
			end
			local v_u_143 = v_u_117(v142)
			local v144 = v_u_143.sign
			local v145 = v_u_12.forWorld(p_u_136)[1]
			if v144 then
				v144 = v144:FindFirstChild("Sub")
			end
			if v145 and (v144 and v144:IsA("TextLabel")) then
				v144.Text = "RECOMMENDED CHAKRA " .. v_u_14.short(v145.recommended)
			end
			local v_u_146 = v_u_27(p_u_136)
			v_u_146.entrance = v_u_143
			local v147
			if p_u_136 == v_u_28 then
				v147 = v_u_32 == 1
			else
				v147 = false
			end
			local v148 = v_u_143.part
			local v149
			if v147 then
				v149 = v_u_19
			else
				v149 = v_u_143.baseColor
			end
			v148.Color = v149
			v_u_143.part.Transparency = v147 and 0.55 or v_u_143.baseTransparency
			return function()
				-- upvalues: (copy) v_u_146, (copy) v_u_143
				if v_u_146.entrance == v_u_143 then
					v_u_146.entrance = nil
				end
			end
		end)
	end
end
local function v_u_157(p151) -- name: lockBehind
	-- upvalues: (ref) v_u_32, (ref) v_u_28, (copy) v_u_27, (copy) v_u_61, (copy) v_u_10, (copy) v_u_19
	local v152 = v_u_32
	v_u_32 = p151
	if v152 > 0 then
		local v153 = v_u_27(v_u_28)
		local v154
		if v152 == 1 then
			v154 = v153.entrance
		else
			v154 = v153.barriers[v152 - 1]
		end
		if v154 then
			v_u_61(v_u_28, v152 - 1, v154, false)
		end
	end
	if p151 > 0 then
		local v155 = v_u_27(v_u_28)
		local v156
		if p151 == 1 then
			v156 = v155.entrance
		else
			v156 = v155.barriers[p151 - 1]
		end
		if v156 then
			v_u_61(v_u_28, p151 - 1, v156, false)
			v_u_10.burst("Flash", v156.part.Position, v_u_19, 1)
		end
	end
end
function v23.cleared() -- name: cleared
	-- upvalues: (ref) v_u_29
	return v_u_29
end
local v_u_158 = { "gold", "purple" }
local v_u_159 = nil
local v_u_160 = 0
local v_u_161 = 0
local function v_u_186(p162, p163) -- name: padUnder
	-- upvalues: (copy) v_u_13, (ref) v_u_29, (copy) v_u_158, (copy) v_u_17
	local v164 = v_u_13.stageAt(p162.Z)
	local v165 = v_u_13.PAD_SIZE.X / 2 + 1.5
	local v166 = v_u_13.PAD_SIZE.Z / 2 + 1.5
	local v167 = not p163 and Vector3.new(0, 0, 0) or p162 - p163
	local v168
	if p163 and v167.Magnitude <= 30 then
		local v169 = v167.Magnitude
		v168 = math.ceil(v169)
	else
		v168 = 0
	end
	local v170 = v164 - 1
	local v171 = math.max(1, v170)
	local v172 = v_u_29
	local v173 = v164 + 1
	for v174 = v171, math.min(v172, v173) do
		for v175 in v_u_158 do
			if v175 == 2 and v_u_17:GetAttribute("Pass_winsPad") ~= true then
				continue
			end
			local v176 = v175 == 2 and "purple" or "gold"
			local v177 = v_u_13.padPosition(v174, v176)
			local v178 = p162.X - v177.X
			local v179
			if math.abs(v178) <= v165 then
				local v180 = p162.Z - v177.Z
				if math.abs(v180) <= v166 then
					v179 = p162.Y < v177.Y + 8
				else
					v179 = false
				end
			else
				v179 = false
			end
			if v179 then
				return v174, v176
			end
			if not p163 then
				continue
			end
			for v181 = 1, v168 - 1 do
				local v182 = p163 + v167 * (v181 / v168)
				local v183 = v182.X - v177.X
				local v184
				if math.abs(v183) <= v165 then
					local v185 = v182.Z - v177.Z
					if math.abs(v185) <= v166 then
						v184 = v182.Y < v177.Y + 8
					else
						v184 = false
					end
				else
					v184 = false
				end
				if not v184 then
					continue
				end
				return v174, v176
			end
		end
	end
	return 0, nil
end
function v23.start() -- name: start
	-- upvalues: (ref) v_u_28, (copy) v_u_8, (ref) v_u_29, (copy) v_u_16, (copy) v_u_3, (copy) v_u_17, (ref) v_u_159, (copy) v_u_13, (ref) v_u_160, (copy) v_u_186, (ref) v_u_161, (copy) v_u_7, (copy) v_u_5, (copy) v_u_150, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (copy) v_u_33, (copy) v_u_100, (copy) v_u_24, (copy) v_u_113, (copy) v_u_61, (copy) v_u_6, (copy) v_u_12, (copy) v_u_157, (copy) v_u_27, (copy) v_u_69, (copy) v_u_10
	v_u_28 = v_u_8.number("RunWorld", 1)
	v_u_29 = v_u_8.number("RunCleared")
	local v_u_187 = v_u_16.event("Pad")
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_17, (ref) v_u_29, (ref) v_u_159, (ref) v_u_13, (ref) v_u_28, (ref) v_u_160, (ref) v_u_186, (ref) v_u_161, (ref) v_u_7, (copy) v_u_187
		local v188 = v_u_17.Character
		local v189
		if v188 then
			v189 = v188:FindFirstChild("HumanoidRootPart")
		else
			v189 = v188
		end
		if v_u_29 <= 0 or not (v188 and (v189 and v189:IsA("BasePart"))) then
			v_u_159 = nil
			return
		elseif v_u_13.worldAt(v189.Position) == v_u_28 then
			local v190 = v_u_13.origin(v_u_28)
			local v191 = v189.Position - v190
			local v192 = v_u_159
			v_u_159 = v191
			if os.clock() < v_u_160 then
				return
			else
				local v193 = v188:FindFirstChildOfClass("Humanoid")
				if v193 and v193.Health > 0 then
					local v194, v195 = v_u_186(v191, v192)
					if v194 ~= 0 and v195 then
						v_u_160 = os.clock() + 2
						v_u_161 = os.clock()
						if not v_u_7.play("PadClaim") then
							v_u_7.play("Coin")
						end
						v_u_159 = nil
						v_u_187:FireServer(v194, v195)
						v188:PivotTo(CFrame.new(v190 + v_u_13.SPAWN))
					end
				else
					return
				end
			end
		else
			v_u_159 = nil
			return
		end
	end)
	for v_u_196 in v_u_13.ORIGINS do
		if not v_u_13.mapLive(v_u_196) then
			continue
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_196, (ref) v_u_5, (ref) v_u_150
			local v197 = v_u_196 == 1 and "Map" or "Map" .. v_u_196
			local v198 = v_u_5:WaitForChild(v197, 60)
			if v198 then
				v_u_150(v198, v_u_196)
			else
				warn("[Gates] Workspace." .. v197 .. " is missing")
			end
		end)
	end
	v_u_8.watch("RunWorld", function()
		-- upvalues: (ref) v_u_8, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_100
		local v199 = v_u_8.number("RunWorld", 1)
		if v199 ~= v_u_28 then
			local v200 = v_u_28
			v_u_28 = v199
			v_u_29 = 0
			v_u_30 = 0
			v_u_31 = 0
			v_u_32 = 0
			table.clear(v_u_33)
			v_u_100(v_u_28)
			v_u_100(v200)
		end
	end)
	local function v_u_205() -- name: trophiesChanged
		-- upvalues: (ref) v_u_24, (ref) v_u_113, (ref) v_u_61
		for v201, v202 in v_u_24 do
			for v203, v204 in v202.barriers do
				v_u_113(v204.sign, v201, v203 + 1)
				v_u_61(v201, v203, v204, false)
			end
		end
	end
	v_u_8.watch("TotalWins", v_u_205)
	for v206 in v_u_13.ORIGINS do
		v_u_8.watch(v206 == 1 and "BestStage" or "BestStage" .. tostring(v206), v_u_205)
	end
	v_u_6.on("reset", function()
		-- upvalues: (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_100, (ref) v_u_28, (copy) v_u_205
		v_u_29 = 0
		v_u_30 = 0
		v_u_31 = 0
		v_u_32 = 0
		table.clear(v_u_33)
		v_u_100(v_u_28)
		v_u_205()
	end)
	v_u_6.on("start", function(p207)
		-- upvalues: (ref) v_u_30, (ref) v_u_12, (ref) v_u_28, (ref) v_u_31, (ref) v_u_157, (ref) v_u_27
		v_u_30 = p207.stage
		local v208 = v_u_12.forWorld(v_u_28)[v_u_30]
		v_u_31 = not v208 and 0 or v208.count + (v208.boss and 1 or 0)
		v_u_157(p207.stage)
		local v209 = v_u_27(v_u_28).barriers[v_u_30]
		if v209 then
			v209 = v209.sign
			if v209 then
				v209 = v209:FindFirstChild("Left")
			end
			if not (v209 and v209:IsA("TextLabel")) then
				v209 = nil
			end
		end
		if v209 then
			v209.Text = v_u_31 <= 0 and "" or ("%* LEFT"):format(v_u_31)
		end
	end)
	v_u_6.on("die", function()
		-- upvalues: (ref) v_u_31, (ref) v_u_27, (ref) v_u_28, (ref) v_u_30
		local v210 = v_u_31 - 1
		v_u_31 = math.max(0, v210)
		local v211 = v_u_27(v_u_28).barriers[v_u_30]
		if v211 then
			v211 = v211.sign
			if v211 then
				v211 = v211:FindFirstChild("Left")
			end
			if not (v211 and v211:IsA("TextLabel")) then
				v211 = nil
			end
		end
		if v211 then
			v211.Text = v_u_31 <= 0 and "" or ("%* LEFT"):format(v_u_31)
		end
	end)
	v_u_6.on("clear", function(p212)
		-- upvalues: (ref) v_u_32, (ref) v_u_28, (ref) v_u_27, (ref) v_u_61, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31
		local v213 = v_u_32
		v_u_32 = 0
		if v213 > 0 then
			local v214 = v_u_27(v_u_28)
			local v215
			if v213 == 1 then
				v215 = v214.entrance
			else
				v215 = v214.barriers[v213 - 1]
			end
			if v215 then
				v_u_61(v_u_28, v213 - 1, v215, false)
			end
		end
		local v216 = p212.stage
		if type(v216) == "number" then
			local v217 = v_u_29
			local v218 = p212.stage
			v_u_29 = math.max(v217, v218)
			local v219 = p212.stage == v_u_30
			if v219 then
				v_u_31 = 0
				v_u_30 = 0
			end
			local v220 = p212.stage
			local v221 = v_u_27(v_u_28).barriers[v220]
			if v221 then
				v_u_61(v_u_28, v220, v221, v219)
			end
		end
	end)
	v_u_6.on("pad", function(p222)
		-- upvalues: (ref) v_u_29, (ref) v_u_33, (ref) v_u_27, (ref) v_u_28, (ref) v_u_69, (ref) v_u_10, (ref) v_u_161, (ref) v_u_7
		local v223 = p222.stage
		if type(v223) == "number" then
			local v224 = p222.which
			if type(v224) == "string" then
				if v_u_29 >= p222.stage then
					v_u_33[p222.stage] = v_u_33[p222.stage] or {}
					v_u_33[p222.stage][p222.which] = true
				end
				local v225 = v_u_27(v_u_28).pads[p222.stage]
				if v225 then
					v225 = v_u_27(v_u_28).pads[p222.stage][p222.which]
				end
				if v225 then
					v_u_69(v_u_28, p222.stage, p222.which, v225)
					v_u_10.burst("Sparkle", v225.top.Position + Vector3.new(0, 1, 0), nil, 1.3)
					v_u_10.ring(v225.top.Position, v225.color, 10, 0.4)
				end
				if os.clock() - v_u_161 > 3 and not v_u_7.play("PadClaim") then
					v_u_7.play("Coin")
				end
				return
			end
		end
	end)
end
return v23