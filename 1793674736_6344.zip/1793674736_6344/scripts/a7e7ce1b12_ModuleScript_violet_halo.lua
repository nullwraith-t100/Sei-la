local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_4 = require(script.Parent.Parent.Parent.Sfx)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(176, 77, 255)
local v_u_7 = Color3.fromRGB(242, 217, 255)
local v_u_8 = Color3.fromRGB(138, 56, 255)
local v_u_9 = Color3.fromRGB(92, 28, 170)
local v_u_10 = Color3.fromRGB(255, 255, 255)
local v_u_11 = CFrame.Angles(0.55, 0, 0)
return function(p_u_12)
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5, (copy) v_u_11, (copy) v_u_9, (copy) v_u_4, (copy) v_u_10
	local function v_u_33(p13, p14, p15, p16, p17, p18) -- name: ringBits
		-- upvalues: (ref) v_u_3, (ref) v_u_1
		local v19 = 6.283185307179586 * p14 / p13 * (p17 * 0.6 + 1.08)
		local v20 = {}
		for v21 = 1, p13 do
			local v22 = (v21 - 0.5) / p13 * 3.141592653589793 * 2
			local v23 = math.cos(v22)
			local v24 = math.sin(v22)
			local v25 = Vector3.new(v23, 0, v24)
			local v26 = -math.sin(v22)
			local v27 = math.cos(v22)
			local v28 = Vector3.new(v26, 0, v27)
			local v29 = v25 * p14
			local v30 = CFrame.lookAt(v29, v29 + (v28 + v25 * p17).Unit, Vector3.new(0, 1, 0))
			local v31 = Vector3.new(p15, p15, v19)
			local v32 = v_u_3.part(v31, v30, p16, {
				["transparency"] = p18
			})
			v_u_1:AddItem(v32, 8)
			table.insert(v20, {
				["p"] = v32,
				["off"] = v30,
				["size"] = v31
			})
		end
		return v20
	end
	local function v_u_42(p34, p35, p36, p37, p38) -- name: picture
		-- upvalues: (ref) v_u_3, (ref) v_u_1
		local v39 = v_u_3.part(Vector3.new(p34, 0.05, p34), p35, p36, {
			["transparency"] = 1
		})
		for _, v40 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v41 = Instance.new("Decal")
			v41.Face = v40
			v41.Texture = p37
			v41.Color3 = p36
			v41.Transparency = p38
			v41.Parent = v39
		end
		v_u_1:AddItem(v39, 8)
		return v39
	end
	local function v_u_55(p43, p44, p45, p46, p47, p48) -- name: wave
		-- upvalues: (copy) v_u_42, (ref) v_u_3, (ref) v_u_1
		local v49 = v_u_42(p44 * 2, p43, p47, p48, 0)
		for _, v50 in v49:GetChildren() do
			v_u_3.tween(v50, p46, {
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
		local v51 = v_u_3.tween
		local v52 = {}
		local v53 = p45 * 2
		local v54 = p45 * 2
		v52.Size = Vector3.new(v53, 0.05, v54)
		v51(v49, p46, v52, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		v_u_1:AddItem(v49, p46 + 0.05)
	end
	local function v_u_72(p56, p57, p58, p59, p60, p61) -- name: sawFrame
		-- upvalues: (copy) p_u_12
		local v62 = p59 / p60
		local v63 = p57 * (0.8 - math.clamp(v62, 0, 1) * 0.5) * (1 - p61)
		local v64 = p58.phase + p59 * 3.4
		local v65 = math.cos(v64)
		local v66 = math.sin(v64)
		local v67 = Vector3.new(v65, 0, v66)
		local v68 = p56 + v67 * v63 + Vector3.new(0, 1, 0) * (p61 * 1.2 + 3.9)
		local v69 = -math.sin(v64)
		local v70 = math.cos(v64)
		local v71 = Vector3.new(v69, 0, v70)
		return p_u_12.facing(v68, v67) * CFrame.Angles(0, p59 * 22, 0), v68, v71
	end
	local v216 = {
		["violet_halo_a"] = {
			["cast"] = function(p73) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (copy) v_u_55, (ref) v_u_7, (ref) v_u_5
				p_u_12.muzzle(p73, v_u_6)
				if not p73.lite then
					v_u_55(p_u_12.facing(p73.eye + p73.dir * 1.6, p73.dir), 0.6, 2.4, 0.15, v_u_7, v_u_5.Ring)
				end
			end,
			["shot"] = function(p74, p75) -- name: discShot
				-- upvalues: (ref) v_u_3, (ref) v_u_6, (copy) v_u_33, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1, (copy) v_u_42, (ref) v_u_5, (copy) p_u_12, (ref) v_u_11
				local v76 = p74.size
				local v_u_77 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p75, v_u_6, {
					["transparency"] = 1
				})
				local v_u_78 = v_u_33(p74.lite and 6 or 9, 1.7 * v76, 0.42 * v76, v_u_8, 0)
				if not p74.lite then
					for _, v79 in v_u_33(6, 1.05 * v76, 0.2 * v76, v_u_7, 0) do
						table.insert(v_u_78, v79)
					end
					for v80 = 1, 4 do
						local v81 = v80 / 4 * 3.141592653589793 * 2
						local v82 = math.cos(v81)
						local v83 = math.sin(v81)
						local v84 = Vector3.new(v82, 0, v83)
						local v85 = -math.sin(v81)
						local v86 = math.cos(v81)
						local v87 = Vector3.new(v85, 0, v86)
						local v88 = v84 * 2.05 * v76
						local v89 = CFrame.lookAt(v88, v88 + v87 + v84 * 0.7, Vector3.new(0, 1, 0))
						local v90 = Vector3.new(0.3, 0.3, 1.25) * v76
						local v91 = v_u_3.part(v90, p75 * v89, v_u_7)
						v_u_1:AddItem(v91, 8)
						table.insert(v_u_78, {
							["p"] = v91,
							["off"] = v89,
							["size"] = v90
						})
					end
					local v92 = v_u_42(5.4 * v76, p75, v_u_6, v_u_5.Ring, 0.25)
					local v93 = {
						["p"] = v92,
						["off"] = CFrame.identity,
						["size"] = v92.Size
					}
					table.insert(v_u_78, v93)
				end
				v_u_1:AddItem(v_u_77, 6)
				p_u_12.streak(v_u_77, v_u_6, v_u_7, 2.8 * v76, 0.13)
				if p74.mine then
					p_u_12.light(v_u_77, v_u_6, 9 * v76)
				end
				local v_u_94 = false
				return {
					["place"] = function(p95, p96) -- name: place
						-- upvalues: (copy) v_u_77, (copy) v_u_78, (ref) v_u_11
						v_u_77.CFrame = p95 * CFrame.Angles(0, 0, 1.5707963267948966)
						local v97 = v_u_78
						local v98 = p95 * v_u_11 * CFrame.Angles(0, p96 * 26, 0)
						for _, v99 in v97 do
							v99.p.CFrame = v98 * v99.off
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_94, (copy) v_u_77, (ref) v_u_1, (copy) v_u_78
						if not v_u_94 then
							v_u_94 = true
							local v100 = v_u_77:FindFirstChildWhichIsA("PointLight")
							if v100 then
								v100:Destroy()
							end
							v_u_1:AddItem(v_u_77, 0.18)
							for _, v101 in v_u_78 do
								v101.p:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p102, p103) -- name: impact
				-- upvalues: (copy) v_u_55, (copy) p_u_12, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_7
				local v104 = p102.size
				v_u_55(p_u_12.facing(p103, -p102.dir), 1.5 * v104, 5.5 * v104, 0.25, v_u_6, v_u_5.Ring)
				p_u_12.burst("Slash", p103, v_u_6, 1 * v104)
				p_u_12.burst("Impact", p103, v_u_6, 0.8 * v104)
				v_u_3.flash(p103, v_u_6, 4.2 * v104, 0.14)
				p_u_12.pop(p103, v_u_7, 1.2 * v104, 4 * v104, 0.15, 0.2)
				v_u_3.ring(p_u_12.ground(p103), v_u_7, 4 * v104, 0.25, v_u_5.Ring)
				if not p102.lite then
					p_u_12.spikes(p103, v_u_7, 4, 4 * v104, 0.15, nil, nil, true)
				end
				p_u_12.hitSound(p103)
			end,
			["hit"] = function(_, p105, _) -- name: hit
				-- upvalues: (copy) p_u_12, (ref) v_u_6
				p_u_12.burst("Impact", p105, v_u_6, 0.6)
			end
		},
		["violet_halo_e"] = {
			["cast"] = function(p106) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (copy) v_u_55, (ref) v_u_7, (ref) v_u_5
				p_u_12.skillCast(p106, v_u_6)
				v_u_55(p_u_12.facing(p106.eye + p106.dir * 1.5, p106.dir), 0.8, 3.2, 0.2, v_u_7, v_u_5.Ring)
			end,
			["windup"] = function(p107, p108, p109) -- name: windup
				-- upvalues: (ref) v_u_3, (copy) p_u_12, (ref) v_u_7, (ref) v_u_5
				local v110 = p107.ability.radius
				v_u_3.ring(p_u_12.ground(p108), v_u_7, v110, p109 + 0.15, v_u_5.Ring)
				p_u_12.pop(p_u_12.ground(p108, 3), v_u_7, 1, 6, p109 + 0.1, 0.3)
			end,
			["zone"] = function(p111, p_u_112, p_u_113) -- name: zone
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (ref) v_u_5, (ref) v_u_9, (copy) v_u_33, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (copy) v_u_72
				local v_u_114 = p111.ability.radius
				local v_u_115 = p_u_12.ground(p_u_112, 0)
				local v_u_116 = p111.lite
				p_u_12.sigil(CFrame.new(p_u_12.ground(p_u_112, 0.12)), v_u_114, v_u_6, v_u_5.MagicCircle, p_u_113, 2.5)
				p_u_12.sigil(CFrame.new(p_u_12.ground(p_u_112, 0.16)), v_u_114 * 0.6, v_u_9, v_u_5.Swirl, p_u_113, -4)
				local v_u_117 = v_u_116 and 3 or 4
				local v_u_118 = {}
				for v119 = 1, v_u_117 do
					local v120 = v_u_33(v_u_116 and 7 or 10, 3.6, 0.65, v_u_8, 0.35)
					if not v_u_116 then
						for _, v121 in v_u_33(6, 2.088, 0.28, v_u_7, 0) do
							table.insert(v120, v121)
						end
					end
					local v122 = {
						["bits"] = v120,
						["phase"] = v119 / v_u_117 * 3.141592653589793 * 2
					}
					table.insert(v_u_118, v122)
				end
				v_u_4.play("Roll", {
					["at"] = v_u_115,
					["volume"] = p111.mine and 0.8 or 0.45
				})
				local v_u_123 = os.clock()
				local v_u_124 = nil
				local v_u_125 = 0
				local v_u_126 = 0
				local v_u_127 = p111.ability.tick or 0.32
				p_u_12.runNow(function()
					-- upvalues: (copy) v_u_123, (ref) v_u_124, (ref) v_u_125, (copy) v_u_117, (ref) v_u_126, (copy) v_u_118, (ref) v_u_72, (copy) v_u_115, (copy) v_u_114, (copy) p_u_113, (copy) v_u_116, (ref) p_u_12, (ref) v_u_7, (ref) v_u_6, (copy) v_u_127, (copy) p_u_112
					local v128 = os.clock()
					local v129 = v128 - v_u_123
					local v130
					if v_u_124 then
						local v131 = (v128 - v_u_124) / 0.12
						v130 = math.clamp(v131, 0, 1)
					else
						v130 = 0
					end
					local v132 = v_u_125 > v129 and 0 or math.random(1, v_u_117)
					local v133 = v_u_126 <= v129
					for v134, v135 in v_u_118 do
						local v136, v137, v138 = v_u_72(v_u_115, v_u_114, v135, v129, p_u_113, v130)
						for _, v139 in v135.bits do
							v139.p.CFrame = v136 * v139.off
						end
						if v_u_116 or v130 ~= 0 then
							break
						end
						if v134 == v132 then
							p_u_12.spikes(p_u_12.ground(v137, 0.3), v_u_7, 2, 2.4, 0.14, -v138 + Vector3.new(0, 0.8, 0), 0.5)
						end
						if not v133 then
							break
						end
						p_u_12.burst("Slash", v137, v_u_6, 0.9)
					end
					if v132 > 0 then
						v_u_125 = v129 + 0.05
					end
					if v133 then
						v_u_126 = v_u_126 + v_u_127
						if not v_u_116 and v130 == 0 then
							p_u_12.inward(p_u_12.ground(p_u_112, 1.5), v_u_6, 3, v_u_114 * 1.1, 0.3)
						end
					end
					if v130 < 1 and p_u_113 + 0.6 >= v129 then
						return true
					end
					for _, v140 in v_u_118 do
						for _, v141 in v140.bits do
							v141.p:Destroy()
						end
					end
					return false
				end)
				return function()
					-- upvalues: (ref) v_u_124
					v_u_124 = os.clock()
				end
			end,
			["finish"] = function(p142, p143) -- name: finish
				-- upvalues: (copy) p_u_12, (ref) v_u_10, (copy) v_u_33, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_4
				local v_u_144 = p142.ability.radius
				local v145 = p_u_12.ground(p143, 0)
				local v_u_146 = p_u_12.ground(p143, 3.5)
				p_u_12.pop(v_u_146, v_u_10, 2, v_u_144 * 1.1, 0.25, 0.1)
				local v_u_147 = v_u_33(p142.lite and 8 or 14, 1, 0.7, v_u_7, 0)
				local v_u_148 = os.clock()
				p_u_12.runNow(function()
					-- upvalues: (copy) v_u_148, (copy) v_u_144, (copy) v_u_147, (copy) v_u_146
					local v149 = (os.clock() - v_u_148) / 0.3
					local v150 = math.clamp(v149, 0, 1)
					local v151 = 1 - (1 - v150) ^ 3
					local v152 = 1 + (v_u_144 * 1.2 - 1) * v151
					for v153, v154 in v_u_147 do
						local v155 = (v153 - 0.5) / #v_u_147 * 3.141592653589793 * 2
						local v156 = math.cos(v155)
						local v157 = math.sin(v155)
						local v158 = Vector3.new(v156, 0, v157)
						v154.p.CFrame = CFrame.lookAt(v_u_146 + v158 * v152, v_u_146 + v158 * v152 + v158:Cross(Vector3.new(0, 1, 0)))
						local v159 = v154.p
						local v160 = 6.283185307179586 * v152 / #v_u_147 * 1.1
						v159.Size = Vector3.new(0.7, 0.7, v160)
						v154.p.Transparency = v150
					end
					if v150 < 1 then
						return true
					end
					for _, v161 in v_u_147 do
						v161.p:Destroy()
					end
					return false
				end)
				p_u_12.burst("Explosion", v_u_146, v_u_6, v_u_144 / 6)
				p_u_12.burst("Shockwave", p_u_12.ground(p143, 0.4), v_u_6, v_u_144 / 18)
				v_u_3.ring(v145, v_u_6, v_u_144 * 1.3, 0.45)
				p_u_12.spikes(v_u_146, v_u_7, p142.lite and 5 or 10, v_u_144, 0.3)
				v_u_4.play("Explosion", {
					["at"] = v_u_146,
					["volume"] = p142.mine and 1 or 0.6
				})
				if p142.mine then
					v_u_3.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(_, p162, _) -- name: hit
				-- upvalues: (copy) p_u_12, (ref) v_u_6
				p_u_12.burst("Slash", p162, v_u_6, 0.6)
			end
		},
		["violet_halo_r"] = {
			["cast"] = function(p163) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (ref) v_u_7, (ref) v_u_5
				p_u_12.skillCast(p163, v_u_6, true)
				p_u_12.sigil(CFrame.new(p163.eye + Vector3.new(0, 2.6, 0)), 1.8, v_u_7, v_u_5.Ring, 0.6, 3)
				p_u_12.glint(p163.eye, v_u_7, 7, 0.2)
			end,
			["windup"] = function(p164, p165, p166) -- name: windup
				-- upvalues: (copy) p_u_12, (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_7, (copy) v_u_33, (ref) v_u_8, (ref) v_u_3
				local v167 = p164.ability.radius
				local v_u_168 = p_u_12.ground(p165, 40)
				local v_u_169 = p166 + 0.3
				p_u_12.sigil(p_u_12.facing(v_u_168, Vector3.new(-0, -1, -0)), 7, v_u_10, p_u_12.iris("violet_halo"), v_u_169, 0.4)
				p_u_12.sigil(p_u_12.facing(v_u_168 + Vector3.new(0, 0.3, 0), Vector3.new(-0, -1, -0)), v167 * 0.6, v_u_6, v_u_5.MagicCircle, v_u_169, 1.2)
				p_u_12.sigil(p_u_12.facing(v_u_168 + Vector3.new(0, 0.6, 0), Vector3.new(-0, -1, -0)), v167, v_u_7, v_u_5.Ring, v_u_169, -0.8)
				p_u_12.burst("Flash", v_u_168, v_u_6, 0.5)
				p_u_12.sigil(CFrame.new(p_u_12.ground(p165, 0.12)), v167, v_u_6, v_u_5.Ring, v_u_169, 0.6)
				if not p164.lite then
					local v_u_170 = v_u_33(16, v167 * 0.8, 0.8, v_u_8, 0)
					local v_u_171 = os.clock()
					p_u_12.runNow(function()
						-- upvalues: (copy) v_u_171, (copy) v_u_169, (copy) v_u_168, (copy) v_u_170
						local v172 = os.clock() - v_u_171
						local v173 = (v172 - v_u_169 + 0.25) / 0.25
						local v174 = math.clamp(v173, 0, 1)
						local v175 = v172 / 0.25
						local v176 = math.min(v175, 1)
						local v177 = CFrame.new(v_u_168 - Vector3.new(0, 1, 0)) * CFrame.Angles(0, v172 * 0.9, 0)
						for _, v178 in v_u_170 do
							local v179 = v178.off
							v178.p.CFrame = v177 * (v179 - v179.Position + v179.Position * v176)
							v178.p.Transparency = v174
						end
						if v174 < 1 then
							return true
						end
						for _, v180 in v_u_170 do
							v180.p:Destroy()
						end
						return false
					end)
				end
				if p164.mine then
					v_u_3.shake(0.15, 0.2)
				end
			end,
			["strike"] = function(p_u_181, p_u_182, p183) -- name: strike
				-- upvalues: (copy) p_u_12, (copy) v_u_55, (ref) v_u_7, (ref) v_u_5, (copy) v_u_33, (ref) v_u_8, (copy) v_u_42, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1, (ref) v_u_9, (ref) v_u_4
				local v_u_184 = p_u_181.ability.strikeRadius or 8
				local v185 = p_u_12.flatUnit(p_u_182 - p_u_181.feet)
				local v_u_186 = CFrame.Angles(0, (math.random() - 0.5) * 1.2, 0):VectorToWorldSpace(v185)
				local v_u_187 = v_u_186:Cross(Vector3.new(0, 1, 0)).Unit
				local v_u_188 = p_u_12.ground(p_u_182, 34)
				local v189 = p_u_12.ground(p_u_182, 3.0250000000000004)
				local v190 = p183 - 0.22
				if v190 > 0.12 then
					p_u_12.after(v190 - 0.12, function()
						-- upvalues: (ref) v_u_55, (ref) p_u_12, (copy) v_u_188, (copy) v_u_186, (ref) v_u_7, (ref) v_u_5
						v_u_55(p_u_12.facing(v_u_188, v_u_186), 1, 7.15, 0.2, v_u_7, v_u_5.Ring)
					end)
				end
				p_u_12.drop(p_u_181, function(p191, p192)
					-- upvalues: (ref) v_u_33, (ref) v_u_8, (ref) v_u_7, (ref) v_u_42, (ref) v_u_6, (ref) v_u_5, (copy) v_u_186, (ref) v_u_3, (ref) v_u_1, (ref) p_u_12
					local v193 = p191.size
					local v_u_194 = 5.5 * v193
					local v_u_195 = v_u_33(p191.lite and 8 or 10, v_u_194, 1 * v193, v_u_8, 0)
					if not p191.lite then
						for _, v196 in v_u_33(8, v_u_194 * 0.78, 0.35 * v193, v_u_7, 0) do
							table.insert(v_u_195, v196)
						end
						local v197 = v_u_42(v_u_194 * 2.5, p192, v_u_6, v_u_5.Ring, 0.35)
						local v198 = {
							["p"] = v197,
							["off"] = CFrame.identity,
							["size"] = v197.Size
						}
						table.insert(v_u_195, v198)
					end
					local v_u_199 = v_u_186:Cross(Vector3.new(0, 1, 0)).Unit
					local v_u_200 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p192, v_u_6, {
						["transparency"] = 1
					})
					v_u_1:AddItem(v_u_200, 6)
					p_u_12.streak(v_u_200, v_u_7, v_u_6, v_u_194 * 1.6, 0.12)
					local v_u_201 = false
					local v_u_202 = p192.Position
					return {
						["place"] = function(p203, p204) -- name: place
							-- upvalues: (ref) v_u_202, (copy) v_u_200, (copy) v_u_199, (copy) v_u_195, (ref) p_u_12, (ref) v_u_186
							local v205 = p203.Position
							v_u_202 = v205
							v_u_200.CFrame = CFrame.lookAt(v205, v205 - Vector3.new(0, 1, 0), v_u_199)
							local v206 = v_u_195
							local v207 = p_u_12.facing(v205, v_u_186) * CFrame.Angles(0, p204 * 14, 0)
							for _, v208 in v206 do
								v208.p.CFrame = v207 * v208.off
							end
						end,
						["stop"] = function(p209) -- name: stop
							-- upvalues: (ref) v_u_201, (ref) v_u_1, (copy) v_u_200, (copy) v_u_195, (ref) v_u_3, (copy) v_u_194, (ref) p_u_12, (ref) v_u_202, (ref) v_u_6
							if not v_u_201 then
								v_u_201 = true
								v_u_1:AddItem(v_u_200, 0.15)
								local v210 = (p209 or 0.2) + 0.2
								for _, v211 in v_u_195 do
									v_u_3.tween(v211.p, v210, {
										["CFrame"] = nil,
										["Transparency"] = 1,
										["CFrame"] = v211.p.CFrame - Vector3.new(0, 1, 0) * v_u_194 * 0.9
									}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
									for _, v212 in v211.p:GetChildren() do
										if not v212:IsA("Decal") then
											continue
										end
										v_u_3.tween(v212, v210, {
											["Transparency"] = 1
										})
									end
									v_u_1:AddItem(v211.p, v210 + 0.05)
								end
								p_u_12.burst("Impact", v_u_202 - Vector3.new(0, 1, 0) * v_u_194 * 0.3, v_u_6, 0.6)
							end
						end
					}
				end, v_u_188, v189, 0.22, p183, 0.4, function(p213)
					-- upvalues: (ref) p_u_12, (copy) p_u_182, (ref) v_u_3, (ref) v_u_6, (copy) v_u_184, (ref) v_u_7, (copy) v_u_187, (ref) v_u_9, (ref) v_u_5, (copy) p_u_181, (ref) v_u_4
					local v214 = p_u_12.ground(p_u_182, 0)
					v_u_3.ring(v214, v_u_6, v_u_184, 0.35)
					p_u_12.burst("Shockwave", p_u_12.ground(p_u_182, 0.3), v_u_6, v_u_184 / 18)
					p_u_12.burst("Impact", p_u_12.ground(p_u_182, 1), v_u_6, 1.3)
					v_u_3.flash(p_u_12.ground(p_u_182, 2), v_u_7, 7, 0.15)
					p_u_12.groundLine(v214 - v_u_187 * 5.5 * 1.2, v214 + v_u_187 * 5.5 * 1.2, 1.2, v_u_7, 0.7, 0.15)
					p_u_12.mark(p_u_182, v_u_9, v_u_184 * 0.6, 1.2, v_u_5.CrackLines, 0.1)
					p_u_12.chunks(p_u_12.ground(p_u_182, 0.5), { p_u_12.EARTH[1], p_u_12.EARTH[2], v_u_6 }, p_u_181.lite and 2 or 3, 30, 0.8, 0.8)
					v_u_4.play("Crit", {
						["at"] = p213,
						["volume"] = p_u_181.mine and 0.55 or 0.3
					})
					v_u_4.play("Hit", {
						["at"] = nil,
						["volume"] = 0.5,
						["at"] = p213
					})
					if p_u_181.mine then
						v_u_3.shake(0.25, 0.18)
					end
				end)
			end,
			["hit"] = function(_, p215, _) -- name: hit
				-- upvalues: (copy) p_u_12, (ref) v_u_6
				p_u_12.burst("Impact", p215, v_u_6, 0.8)
			end
		}
	}
	return v216
end