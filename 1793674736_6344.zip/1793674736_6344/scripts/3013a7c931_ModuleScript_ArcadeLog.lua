return {
	["seed"] = function(p1) -- name: seed
		local v2 = math.abs(p1)
		return math.floor(v2) % 2147483646 + 1
	end,
	["roll"] = function(p3, p4) -- name: roll
		local v5 = p3 * 48271 % 2147483647
		local v6 = math.floor(p4)
		return v5, v5 % math.max(1, v6) + 1
	end,
	["encode"] = function(p7) -- name: encode
		local v8 = 0
		local v9 = {}
		for _, v10 in p7 do
			local v11 = v10.tick - v8
			while v11 > 65535 do
				table.insert(v9, {
					["tick"] = 65535,
					["action"] = 0
				})
				v11 = v11 - 65535
			end
			local v12 = {
				["tick"] = math.max(v11, 0),
				["action"] = v10.action
			}
			table.insert(v9, v12)
			local v13 = v10.tick
			v8 = math.max(v13, v8)
		end
		local v14 = buffer.create(#v9 * 3)
		for v15, v16 in v9 do
			local v17 = (v15 - 1) * 3
			local v18 = v16.tick
			buffer.writeu16(v14, v17, v18)
			local v19 = v17 + 2
			local v20 = v16.action
			buffer.writeu8(v14, v19, v20)
		end
		return v14
	end,
	["decode"] = function(p21, p22, p23) -- name: decode
		local v24 = buffer.len(p21)
		if v24 % 3 ~= 0 or p22 < v24 / 3 then
			return nil
		end
		local v25 = 0
		local v26 = {}
		for v27 = 0, v24 - 3, 3 do
			v25 = v25 + buffer.readu16(p21, v27)
			local v28 = v27 + 2
			local v29 = buffer.readu8(p21, v28)
			if p23 < v29 then
				return nil
			end
			if v29 <= 0 then
				continue
			end
			table.insert(v26, {
				["tick"] = v25,
				["action"] = v29
			})
		end
		return v26
	end
}