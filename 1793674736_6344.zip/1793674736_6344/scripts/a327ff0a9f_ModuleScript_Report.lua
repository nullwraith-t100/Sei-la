local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Stats")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = require(v3.Shared.Net)
local v_u_9 = require(script.Parent.Menus)
local v_u_10 = require(script.Parent.Perf)
local v_u_11 = require(script.Parent.Store)
local v_u_12 = require(script.Parent.Tutorial)
local v13 = {}
local v_u_14 = v2.LocalPlayer
local function v_u_21() -- name: device
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v15 = v_u_6.TouchEnabled
	local v16 = v_u_6.KeyboardEnabled
	if v_u_6.GamepadEnabled and not (v15 or v16) then
		return "Console"
	end
	if not v15 or v16 then
		return "Computer"
	end
	local v17 = v_u_7.CurrentCamera
	local v18
	if v17 then
		v18 = v17.ViewportSize
	else
		v18 = Vector2.new(800, 400)
	end
	local v19 = v18.X
	local v20 = v18.Y
	return math.min(v19, v20) >= 600 and "Tablet" or "Phone"
end
local v_u_22 = false
local function v_u_24() -- name: doing
	-- upvalues: (ref) v_u_22, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9, (copy) v_u_14
	if v_u_22 then
		return "Roblox menu"
	end
	if v_u_11.sincePrompt() < 8 then
		return "Robux prompt"
	end
	if v_u_12.active() then
		return "Tutorial " .. v_u_12.step()
	end
	local v23 = v_u_9.current()
	return not v23 and (v_u_14:GetAttribute("InWave") == true and "Wave" or (v_u_14:GetAttribute("InStages") == true and "Stages" or "Spawn")) or "Menu " .. v23
end
function v13.start() -- name: start
	-- upvalues: (copy) v_u_1, (ref) v_u_22, (copy) v_u_4, (copy) v_u_8, (copy) v_u_21, (copy) v_u_10, (copy) v_u_5, (copy) v_u_24
	v_u_1.MenuOpened:Connect(function()
		-- upvalues: (ref) v_u_22
		v_u_22 = true
	end)
	v_u_1.MenuClosed:Connect(function()
		-- upvalues: (ref) v_u_22
		v_u_22 = false
	end)
	local v_u_25 = 0
	v_u_4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_25
		v_u_25 = v_u_25 + 1
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_25, (ref) v_u_21, (ref) v_u_10, (ref) v_u_5, (ref) v_u_24
		local v26 = v_u_8.event("Report")
		local v27 = os.clock()
		local v28 = 1
		while true do
			task.wait(v28)
			v28 = 10
			local v29 = os.clock()
			local v30 = v_u_25
			local v31 = v29 - v27
			local v32 = v30 / math.max(v31, 0.001)
			v_u_25 = 0
			local v33 = {
				["device"] = v_u_21(),
				["level"] = v_u_10.level()
			}
			local v34 = v32 + 0.5
			v33.fps = math.floor(v34)
			local v35 = v_u_5:GetTotalMemoryUsageMb()
			v33.memory = math.floor(v35)
			v33.doing = v_u_24()
			v26:FireServer(v33)
			v27 = v29
		end
	end)
end
return v13