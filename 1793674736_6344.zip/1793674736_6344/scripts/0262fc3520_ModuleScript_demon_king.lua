local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_4 = require(script.Parent.Parent.Mythic8)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.MuzanTendril,
	v_u_7.MuzanPool,
	v_u_7.MuzanMaw,
	v_u_7.FxSmoke,
	v_u_7.ImpactBurst
})
local v_u_8 = Color3.fromHex("FF1A2E")
local v_u_9 = Color3.fromRGB(150, 0, 22)
local v_u_10 = Color3.fromRGB(30, 4, 10)
local v_u_11 = Color3.fromRGB(255, 120, 130)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(70, 40, 30)
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = Enum.Material.Neon
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_22(p17, p18) -- name: axisAt
	local v19 = p18.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p18.Unit
	local v20 = v19.Y
	local v21 = math.abs(v20) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p17, p17 + v19, v21) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_30(p23, p24, p25, p26, p27, p28, p29) -- name: blood
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_16
	v_u_4.spray(p23, v_u_7.FxSmoke, p24, p25, p26, p27, v_u_9, {
		["layout"] = nil,
		["mode"] = nil,
		["emission"] = 0,
		["dir"] = nil,
		["spread"] = nil,
		["gravity"] = 14,
		["grow"] = 1.4,
		["layout"] = v_u_16,
		["mode"] = Enum.ParticleFlipbookMode.Random,
		["dir"] = p28,
		["spread"] = p29
	})
end
local function v_u_34(p31, p32, p33) -- name: maw
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_12
	v_u_4.planeFlip(CFrame.new(p31) * CFrame.Angles(0, math.random() * 6.3, 0), p32, v_u_7.MuzanMaw, v_u_12, p33)
end
return function(p_u_35)
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (copy) v_u_15, (copy) v_u_1, (copy) v_u_22, (copy) v_u_16, (copy) v_u_30, (copy) v_u_10, (copy) v_u_14, (copy) v_u_11, (copy) v_u_9, (copy) v_u_34, (copy) v_u_13, (copy) v_u_6
	local v70 = {
		["demon_king_a"] = {
			["cast"] = function(p36) -- name: cast
				-- upvalues: (ref) v_u_3, (ref) v_u_8
				v_u_3.flash(p36.eye + p36.dir, v_u_8, 2.2 * p36.size, 0.1)
			end,
			["beam"] = function(p_u_37, p38, p_u_39) -- name: beam
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_15, (ref) v_u_1, (copy) p_u_35, (ref) v_u_22, (ref) v_u_16, (ref) v_u_3, (ref) v_u_30
				local v_u_40 = p_u_37.size
				local v41 = p_u_39 - p38
				local v_u_42 = v41.Magnitude
				if v_u_42 >= 2 then
					local v_u_43 = v41.Unit
					local v44 = v_u_4.flat(v_u_43):Cross(Vector3.new(0, 1, 0))
					local v_u_45 = p38 - v_u_43 * 0.9 * v_u_40 + Vector3.new(0, 0.4, 0) * v_u_40 + v44 * 0.9 * v_u_40
					local v_u_46 = v_u_4.holder(CFrame.new(v_u_45), 1)
					local v_u_47 = v_u_4.holder(CFrame.new(v_u_45), 1)
					local v48 = 1.7 * v_u_40
					local v49 = 0.6 * v_u_40
					local v_u_50 = v_u_4.beam(v_u_46, v_u_47, v_u_7.MuzanTendril, v_u_12, v48, v49, 0)
					v_u_50.TextureMode = Enum.TextureMode.Wrap
					v_u_50.TextureLength = math.max(v48, 0.5) * 2.6
					v_u_50.Segments = 16
					local v_u_51 = v_u_4.blade(v_u_8, v_u_15)
					for _, v52 in v_u_51 do
						v_u_1:AddItem(v52, 1)
					end
					local v_u_53 = false
					p_u_35.animate(0.42, p_u_37.skip, function(p54)
						-- upvalues: (ref) v_u_4, (copy) v_u_45, (copy) p_u_39, (copy) v_u_43, (copy) v_u_46, (ref) v_u_22, (copy) v_u_47, (copy) v_u_50, (copy) v_u_42, (copy) v_u_51, (copy) v_u_40, (ref) v_u_53, (ref) v_u_7, (ref) v_u_8, (ref) v_u_16, (ref) v_u_3, (copy) p_u_37, (ref) v_u_30
						local v55 = p54 * 0.42
						local v56
						if v55 < 0.1 then
							v56 = v_u_4.smooth(v55 / 0.1)
						else
							v56 = 1 - v_u_4.smooth((v55 - 0.16) / 0.26)
						end
						local v57 = v_u_45:Lerp(p_u_39, v56)
						local v58 = (v_u_43 - Vector3.new(0, 0.5, 0)).Unit
						v_u_46.WorldCFrame = v_u_22(v_u_45, (Vector3.new(0, 0.9, 0) + v_u_43).Unit)
						v_u_47.WorldCFrame = v_u_22(v57, v58)
						v_u_50.CurveSize0 = v_u_42 * v56 * 0.22
						local v59 = v_u_50
						local v60 = v_u_42 * v56 * 0.08
						local v61 = v55 * 26
						v59.CurveSize1 = v60 * math.cos(v61)
						local v62 = v_u_4.placeBlade
						local v63 = v_u_51
						local v64 = v58.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or v58.Unit
						local v65 = v64.Y
						local v66 = math.abs(v65) > 0.95 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
						v62(v63, CFrame.lookAt(v57, v57 + v64, v66), 1.2 * v_u_40, 0.5 * v_u_40, 0.16 * v_u_40)
						if v55 >= 0.1 and not v_u_53 then
							v_u_53 = true
							v_u_4.facePic(p_u_39, 1 * v_u_40, 5 * v_u_40, v_u_7.ImpactBurst, v_u_8, 0.3, v_u_16, 0.2)
							v_u_3.flash(p_u_39, v_u_8, 3 * v_u_40, 0.12)
							if not p_u_37.lite then
								v_u_30(p_u_39, 2, 1.2 * v_u_40, 6 * v_u_40, 0.6)
							end
						end
						if p54 >= 1 then
							v_u_50.Enabled = false
							for _, v67 in v_u_51 do
								v67:Destroy()
							end
						end
					end)
				end
			end,
			["hit"] = function(p68, p69, _) -- name: hit
				-- upvalues: (copy) p_u_35, (ref) v_u_8, (ref) v_u_10
				p_u_35.burst("Impact", p69, v_u_8, 0.55)
				if not p68.lite then
					p_u_35.spikes(p69, v_u_10, 2, 4, 0.2, Vector3.new(0, 1, 0), 0.8)
				end
				p_u_35.beamHitSound(p68, p69, "Hit")
			end
		}
	}
	local function v_u_93(p_u_71, p_u_72, p_u_73, p_u_74, p_u_75) -- name: thornUp
		-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_14, (ref) v_u_8, (ref) v_u_15, (ref) v_u_1, (copy) p_u_35
		local v_u_76 = v_u_4.blade(v_u_10, v_u_14)
		local v_u_77 = v_u_4.blade(v_u_8, v_u_15)
		for _, v78 in { v_u_76, v_u_77 } do
			for _, v79 in v78 do
				v79.Reflectance = 0.15
				v_u_1:AddItem(v79, p_u_75 + 0.8)
			end
		end
		local v_u_80 = p_u_75 + 0.1 + 0.3
		p_u_35.animate(v_u_80, 0, function(p81)
			-- upvalues: (copy) v_u_80, (ref) v_u_4, (copy) p_u_75, (copy) p_u_73, (copy) p_u_71, (copy) p_u_72, (copy) v_u_76, (copy) p_u_74, (copy) v_u_77
			local v82 = p81 * v_u_80
			local v83 = p_u_73 * (v_u_4.outBack(v82 / 0.1) * (1 - v_u_4.smooth((v82 - 0.1 - p_u_75) / 0.3)))
			local v84 = math.max(v83, 0.05)
			local v85 = p_u_71
			local v86 = p_u_72
			local v87 = v86.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or v86.Unit
			local v88 = v87.Y
			local v89 = math.abs(v88) > 0.95 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			local v90 = CFrame.lookAt(v85, v85 + v87, v89)
			v_u_4.placeBlade(v_u_76, v90, v84, p_u_74, p_u_74 * 0.5)
			v_u_4.placeBlade(v_u_77, v90 * CFrame.new(0, 0, -v84 * 0.1), v84 * 0.75, p_u_74 * 0.45, p_u_74 * 0.55)
			if p81 >= 1 then
				for _, v91 in { v_u_76, v_u_77 } do
					for _, v92 in v91 do
						v92:Destroy()
					end
				end
			end
		end)
	end
	v70.demon_king_e = {
		["cast"] = nil,
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p94) -- name: cast
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (copy) p_u_35, (ref) v_u_11, (ref) v_u_9, (ref) v_u_7
			local v95 = p94.size
			v_u_3.flash(p94.eye, v_u_8, 4 * v95, 0.16)
			p_u_35.glint(p94.eye, v_u_11, 4 * v95, 0.2)
			v_u_3.ring(p94.feet, v_u_9, 6 * v95, 0.3, v_u_7.Ring)
		end,
		["windup"] = function(p96, p97, p98) -- name: windup
			-- upvalues: (ref) v_u_4, (copy) p_u_35, (ref) v_u_7, (ref) v_u_12, (ref) v_u_3, (ref) v_u_8
			local v99 = p96.size
			local v100 = math.max(p98, 0.1)
			v_u_4.groundPic(p_u_35.ground(p97, 0.1), 1 * v99, 10 * v99, v_u_7.MuzanPool, v_u_12, 0, v100, 0, 0.2, 0)
			v_u_3.flash(p_u_35.ground(p97, 1), v_u_8, 5 * v99, v100)
		end,
		["zone"] = function(p101, p102, p103) -- name: zone
			-- upvalues: (copy) p_u_35, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_8, (ref) v_u_15, (ref) v_u_1, (ref) v_u_22, (copy) v_u_93, (ref) v_u_34
			local v_u_104 = p101.size
			local v_u_105 = p101.lite
			local v_u_106 = p101.ability.radius * v_u_104
			local v_u_107 = p_u_35.ground(p102, 0.08)
			v_u_4.groundPic(v_u_107, v_u_106 * 0.6, v_u_106 * 2.3, v_u_7.MuzanPool, v_u_12, 0, 0.3, p103 - 0.2, 0.4, 0.1)
			v_u_4.groundPic(v_u_107 - Vector3.new(0, 0.04, 0), v_u_106 * 0.8, v_u_106 * 2.4, v_u_7.Glow, v_u_9, 0.35, 0.3, p103 - 0.2, 0.4, 0)
			local v108 = p103 + 1
			local v_u_109 = v_u_105 and 2 or 4
			local v110 = math.random() * 3.141592653589793 * 2
			local v_u_111 = {}
			for v112 = 1, v_u_109 do
				local v113 = v110 + v112 * 3.141592653589793 * 2 / v_u_109
				local v114 = math.cos(v113)
				local v115 = math.sin(v113)
				local v116 = v_u_107 + Vector3.new(v114, 0, v115) * v_u_106 * 0.95
				local v117 = v_u_4.holder(CFrame.new(v116), v108)
				local v118 = v_u_4.holder(CFrame.new(v116), v108)
				local v119 = v_u_4.blade(v_u_8, v_u_15)
				for _, v120 in v119 do
					v_u_1:AddItem(v120, v108)
				end
				local v121 = {
					["a0"] = v117,
					["a1"] = v118
				}
				local v122 = 2.4 * v_u_104
				local v123 = 0.7 * v_u_104
				local v124 = v_u_4.beam(v117, v118, v_u_7.MuzanTendril, v_u_12, v122, v123, 0)
				v124.TextureMode = Enum.TextureMode.Wrap
				v124.TextureLength = math.max(v122, 0.5) * 2.6
				v124.Segments = 16
				v121.beam = v124
				v121.base = v116
				v121.angle = v113
				v121.thorn = v119
				table.insert(v_u_111, v121)
			end
			local v_u_125 = nil
			local v_u_126 = os.clock()
			local v_u_127 = 0.1
			local v_u_128 = 0
			local v_u_129 = 0.3
			local v_u_130 = v_u_105 and 0 or 2
			p_u_35.runNow(function()
				-- upvalues: (copy) v_u_126, (ref) v_u_125, (ref) v_u_4, (copy) v_u_111, (copy) v_u_107, (copy) v_u_109, (copy) v_u_106, (copy) v_u_104, (ref) v_u_22, (ref) v_u_127, (ref) v_u_128, (copy) v_u_105, (ref) v_u_93, (ref) v_u_129, (ref) p_u_35, (ref) v_u_8, (ref) v_u_130, (ref) v_u_34
				local v131 = os.clock()
				local v132 = v131 - v_u_126
				local v133 = not v_u_125 and 0 or v_u_4.smooth((v131 - v_u_125) / 0.3)
				local v134 = v_u_4.outBack(v132 / 0.35) * (1 - v133)
				for v135, v136 in v_u_111 do
					local v137 = v_u_4.flat(v_u_107 - v136.base)
					local v138 = v132 * 3.2 + v135 * 3.141592653589793 * 2 / v_u_109
					local v139 = v_u_107
					local v140 = math.cos(v138)
					local v141 = math.sin(v138)
					local v142 = v139 + Vector3.new(v140, 0, v141) * v_u_106 * 0.14
					local v143 = v132 * 5 + v135
					local v144 = v142 + Vector3.new(0, 1, 0) * (math.sin(v143) * 0.8 + 2.2) * v_u_104
					local v145 = v136.base:Lerp(v144, (math.max(v134, 0.02))) + Vector3.new(0, 0.3, 0)
					local v146 = (v144 - v136.base + Vector3.new(0, 1, 0) * -v_u_106 * 0.6).Unit
					v136.a0.WorldCFrame = v_u_22(v136.base - Vector3.new(0, 0.4, 0), (Vector3.new(0, 1.4, 0) + v137).Unit)
					v136.a1.WorldCFrame = v_u_22(v145, v146)
					v136.beam.CurveSize0 = v_u_106 * 0.55 * v134
					v136.beam.CurveSize1 = v_u_106 * 0.2 * v134
					local v147 = v_u_4.placeBlade
					local v148 = v136.thorn
					local v149 = v146.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or v146.Unit
					local v150 = v149.Y
					local v151 = math.abs(v150) > 0.95 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
					v147(v148, CFrame.lookAt(v145, v145 + v149, v151), 1.5 * v_u_104 * v134 + 0.05, 0.6 * v_u_104, 0.2 * v_u_104)
				end
				if not v_u_125 and v_u_127 <= v132 then
					v_u_127 = v132 + 0.4
					local v152 = v_u_106 * (0.88 - v_u_128 % 4 * 0.2)
					v_u_128 = v_u_128 + 1
					local v153 = v_u_105 and 4 or 9
					local v154 = math.random() * 3.141592653589793
					for v155 = 1, v153 do
						local v156 = v154 + v155 * 3.141592653589793 * 2 / v153
						local v157 = math.cos(v156)
						local v158 = math.sin(v156)
						local v159 = Vector3.new(v157, 0, v158)
						v_u_93(v_u_107 + v159 * v152, (Vector3.new(0, 1, 0) - v159 * 0.55).Unit, (2.8 + math.random() * 1.4) * v_u_104, 0.85 * v_u_104, 0.22)
					end
				end
				if not v_u_125 and v_u_129 <= v132 then
					v_u_129 = v132 + 0.6
					p_u_35.inward(v_u_107 + Vector3.new(0, 1.5, 0), v_u_8, v_u_105 and 3 or 7, v_u_106, 0.5)
					if v_u_130 > 0 then
						v_u_130 = v_u_130 - 1
						local v160 = math.random() * 3.141592653589793 * 2
						local v161 = v_u_34
						local v162 = v_u_107
						local v163 = math.cos(v160)
						local v164 = math.sin(v160)
						v161(v162 + Vector3.new(v163, 0.06, v164) * v_u_106 * 0.45, 4 * v_u_104, 1)
					end
				end
				if not v_u_125 or v133 < 1 then
					return true
				end
				for _, v165 in v_u_111 do
					v165.beam.Enabled = false
					for _, v166 in v165.thorn do
						v166:Destroy()
					end
				end
				return false
			end)
			return function()
				-- upvalues: (ref) v_u_125
				v_u_125 = os.clock()
			end
		end,
		["finish"] = function(p167, p168) -- name: finish
			-- upvalues: (copy) p_u_35, (ref) v_u_34, (copy) v_u_93, (ref) v_u_3, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_16, (ref) v_u_30, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (ref) v_u_6
			local v169 = p167.size
			local v170 = p167.lite
			local v171 = p167.ability.radius * v169
			local v172 = p_u_35.ground(p168, 0.1)
			v_u_34(v172 + Vector3.new(0, 0.05, 0), v171 * 1.2, 1)
			for v173 = 1, v170 and 6 or 14 do
				local v174 = v173 * 3.141592653589793 * 2 / (v170 and 6 or 14) + math.random() * 0.2
				local v175 = 0.5 + math.random() * 0.9
				local v176 = math.cos(v174)
				local v177 = math.sin(v174)
				local v178 = (Vector3.new(v176, 0, v177) + Vector3.new(0, 1, 0) * v175).Unit
				v_u_93(v172 + v178 * 0.6 * v169, v178, v171 * (0.45 + 0.3 * math.random()), 1.4 * v169, 0.45)
			end
			v_u_3.flash(v172 + Vector3.new(0, 2, 0) * v169, v_u_8, v171 * 0.8, 0.2)
			v_u_3.ring(v172, v_u_8, v171 * 1.2, 0.5, v_u_7.Shockwave)
			v_u_4.facePic(v172 + Vector3.new(0, 2, 0) * v169, v171 * 0.4, v171 * 1.6, v_u_7.ImpactBurst, v_u_8, 0.45, v_u_16, 0.2)
			v_u_30(v172 + Vector3.new(0, 1, 0), v170 and 3 or 10, 3 * v169, v171 * 1.2, 1, Vector3.new(0, 1, 0), 70)
			if not v170 then
				local v179 = { v_u_10, v_u_9, v_u_13 }
				p_u_35.chunks(v172 + Vector3.new(0, 0.5, 0), v179, 10, 30 * v169, 0.8 * v169, 1.1, false, 1)
			end
			v_u_6.play("Explosion", {
				["at"] = v172,
				["volume"] = p167.mine and 0.9 or 0.45
			})
			if p167.mine then
				v_u_3.shake(0.4, 0.35)
			end
		end,
		["hit"] = function(p180, p181, _) -- name: hit
			-- upvalues: (copy) p_u_35, (ref) v_u_8, (ref) v_u_30
			p_u_35.burst("Impact", p181, v_u_8, 0.55)
			if not p180.lite then
				v_u_30(p181, 1, 1.2 * p180.size, 3, 0.5)
			end
		end
	}
	local v_u_182 = {}
	setmetatable(v_u_182, {
		["__mode"] = "k"
	})
	v70.demon_king_r = {
		["cast"] = function(p183) -- name: cast
			-- upvalues: (ref) v_u_3, (ref) v_u_8, (copy) p_u_35, (ref) v_u_11, (ref) v_u_30, (ref) v_u_4
			local v184 = p183.size
			v_u_3.flash(p183.eye, v_u_8, 7 * v184, 0.22)
			p_u_35.glint(p183.eye, v_u_11, 6 * v184, 0.3)
			v_u_30(p183.feet + Vector3.new(0, 1, 0), p183.lite and 2 or 6, 2 * v184, 8 * v184, 0.8)
			if p183.mine then
				v_u_3.shake(0.16, 0.2)
				v_u_4.tint("DemonKing", Color3.fromRGB(255, 222, 218), -0.05, 0.15, 0.12, 0.9, 0.6)
			end
		end,
		["windup"] = function(p185, p186, p187) -- name: windup
			-- upvalues: (copy) p_u_35, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_34, (copy) v_u_182, (ref) v_u_22, (ref) v_u_8, (ref) v_u_6
			local v_u_188 = p185.size
			local v189 = p185.lite
			local v190 = p185.ability.radius * v_u_188
			local v_u_191 = math.max(p187, 0.15)
			local v192 = p_u_35.ground(p186, 0.08)
			v_u_4.groundPic(v192, v190 * 0.3, v190 * 2.4, v_u_7.MuzanPool, v_u_12, 0, v_u_191 + 0.15, 0.7, 0.6, 0.15)
			v_u_4.groundPic(v192 - Vector3.new(0, 0.04, 0), v190 * 0.5, v190 * 2.6, v_u_7.Glow, v_u_9, 0.3, v_u_191, 0.8, 0.6, 0)
			local v193 = v189 and 4 or 8
			local v194 = {}
			for v195 = 1, v193 do
				local v196 = v195 * 3.141592653589793 * 2 / v193 + math.random() * 0.2
				local v197 = v190 * (v195 % 2 == 0 and 0.85 or 0.55)
				local v198 = math.cos(v196)
				local v199 = math.sin(v196)
				local v200 = v192 + Vector3.new(v198, 0.05, v199) * v197
				table.insert(v194, v200)
				v_u_34(v200, (v195 % 2 == 0 and 6.5 or 5) * v_u_188, v_u_191 + 1.1)
			end
			local v_u_201 = v189 and 5 or 10
			local v_u_202 = p185.origin - p185.dir * 0.6 * v_u_188
			local v_u_203 = v_u_191 + 1.4
			local v_u_204 = {}
			local v_u_205 = {}
			local v_u_206 = {}
			local v_u_207 = {}
			local v_u_208 = {}
			for v209 = 1, v_u_201 do
				local v210 = v209 * 3.141592653589793 * 2 / v_u_201
				local v211 = math.cos(v210)
				local v212 = math.sin(v210)
				local v213 = Vector3.new(v211, 0, v212)
				local v214 = v_u_202 + v213 * 0.4 * v_u_188
				table.insert(v_u_207, v214)
				local v215 = v_u_202 + v213 * (v209 % 3 + 3) * v_u_188 + Vector3.new(0, 1, 0) * (v209 % 4 * 1.5 + 9) * v_u_188
				table.insert(v_u_208, v215)
				local v216 = v_u_4.holder(CFrame.new(v_u_202), v_u_203)
				local v217 = v_u_4.holder(CFrame.new(v_u_202), v_u_203)
				table.insert(v_u_205, v216)
				table.insert(v_u_206, v217)
				local v218 = 2.2 * v_u_188
				local v219 = 0.6 * v_u_188
				local v220 = v_u_4.beam(v216, v217, v_u_7.MuzanTendril, v_u_12, v218, v219, 0)
				v220.TextureMode = Enum.TextureMode.Wrap
				v220.TextureLength = math.max(v218, 0.5) * 2.6
				v220.Segments = 16
				table.insert(v_u_204, v220)
			end
			local v_u_221 = {
				["roots"] = nil,
				["a0s"] = nil,
				["a1s"] = nil,
				["beams"] = nil,
				["tips"] = nil,
				["mouths"] = nil,
				["alive"] = true,
				["roots"] = v_u_207,
				["a0s"] = v_u_205,
				["a1s"] = v_u_206,
				["beams"] = v_u_204,
				["tips"] = v_u_208,
				["mouths"] = v194
			}
			v_u_182[p185] = v_u_221
			local v_u_222 = os.clock()
			p_u_35.runNow(function()
				-- upvalues: (copy) v_u_221, (copy) v_u_222, (ref) v_u_4, (copy) v_u_191, (copy) v_u_201, (copy) v_u_188, (copy) v_u_207, (copy) v_u_208, (copy) v_u_205, (ref) v_u_22, (copy) v_u_202, (copy) v_u_206, (copy) v_u_204, (copy) v_u_203
				if not v_u_221.alive then
					return false
				end
				local v223 = os.clock() - v_u_222
				local v224 = v_u_4.outBack(v223 / v_u_191)
				for v225 = 1, v_u_201 do
					local v226 = v223 * 5 + v225
					local v227 = math.sin(v226)
					local v228 = v223 * 4 + v225
					local v229 = math.cos(v228)
					local v230 = Vector3.new(v227, 0, v229) * 0.8 * v_u_188
					local v231 = v_u_207[v225]:Lerp(v_u_208[v225], v224) + v230
					v_u_205[v225].WorldCFrame = v_u_22(v_u_207[v225], (v_u_207[v225] - v_u_202 + Vector3.new(0, 0.3, 0)).Unit)
					v_u_206[v225].WorldCFrame = v_u_22(v231, Vector3.new(0, 1, 0))
					v_u_204[v225].CurveSize0 = 3 * v_u_188
					local v232 = v_u_204[v225]
					local v233 = -2 * v_u_188
					local v234 = v223 * 3 + v225
					v232.CurveSize1 = v233 * math.sin(v234)
				end
				return v223 < v_u_203
			end)
			p_u_35.inward(p185.origin, v_u_8, v189 and 4 or 12, v190 * 0.5, v_u_191)
			v_u_6.play("EyeActivate", {
				["at"] = p185.origin,
				["volume"] = p185.mine and 0.7 or 0.35
			})
		end,
		["land"] = function(p235, p236) -- name: land
			-- upvalues: (copy) p_u_35, (copy) v_u_182, (ref) v_u_4, (ref) v_u_22, (ref) v_u_3, (ref) v_u_8, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9, (ref) v_u_30, (ref) v_u_11, (ref) v_u_7, (ref) v_u_16, (ref) v_u_12, (ref) v_u_6
			local v_u_237 = p235.size
			local v_u_238 = p235.lite
			local v_u_239 = p235.ability.radius * v_u_237
			local v240 = p_u_35.ground(p236, 0.1)
			local v_u_241 = v_u_182[p235]
			v_u_182[p235] = nil
			if v_u_241 then
				v_u_241.alive = false
				local v_u_242 = #v_u_241.beams
				local v_u_243 = {}
				for v244 = 1, v_u_242 do
					local v245 = v240 + v_u_4.flat(v_u_241.tips[v244] - v_u_241.roots[v244]) * v_u_239 * 0.9
					table.insert(v_u_243, v245)
				end
				local v_u_246 = {}
				for v247 = 1, v_u_242 do
					v_u_246[v247] = v_u_241.a1s[v247].WorldPosition
				end
				local v_u_248 = false
				p_u_35.animate(0.72, 0, function(p249)
					-- upvalues: (ref) v_u_4, (copy) v_u_242, (copy) v_u_246, (copy) v_u_243, (copy) v_u_241, (copy) v_u_239, (ref) v_u_22, (ref) v_u_248, (ref) v_u_3, (ref) v_u_8, (copy) v_u_237, (copy) v_u_238, (ref) p_u_35, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9
					local v250 = p249 * 0.72
					local v251 = v_u_4.smooth(v250 / 0.12)
					local v252 = v_u_4.smooth((v250 - 0.37) / 0.35)
					for v253 = 1, v_u_242 do
						local v254 = v_u_246[v253]:Lerp(v_u_243[v253], v251):Lerp(v_u_241.roots[v253], v252)
						local v255 = v251 * 3.141592653589793
						local v256 = Vector3.new(0, 1, 0) * math.sin(v255) * v_u_239 * 0.25
						v_u_241.a1s[v253].WorldCFrame = v_u_22(v254 + v256, (v_u_243[v253] - v_u_241.roots[v253]).Unit - Vector3.new(0, 0.6, 0))
						v_u_241.beams[v253].CurveSize0 = v_u_239 * 0.25 * (1 - v252)
						v_u_241.beams[v253].CurveSize1 = 0
						v_u_241.beams[v253].Transparency = NumberSequence.new(v252)
					end
					if v250 >= 0.12 and not v_u_248 then
						v_u_248 = true
						for v257, v258 in v_u_243 do
							v_u_3.flash(v258 + Vector3.new(0, 1, 0), v_u_8, 4 * v_u_237, 0.18)
							if v_u_238 or v257 % 2 ~= 0 then
								continue
							end
							local v259 = { v_u_10, v_u_13, v_u_9 }
							p_u_35.chunks(v258 + Vector3.new(0, 0.4, 0), v259, 3, 16 * v_u_237, 0.6 * v_u_237, 0.9, false, 0.8)
							p_u_35.spikes(v258 + Vector3.new(0, 1, 0), v_u_8, 3, 6 * v_u_237, 0.25, Vector3.new(0, 1, 0), 0.7)
						end
					end
					if p249 >= 1 then
						for _, v260 in v_u_241.beams do
							v260.Enabled = false
						end
					end
				end)
				for _, v261 in v_u_241.mouths do
					v_u_30(v261 + Vector3.new(0, 0.5, 0), v_u_238 and 1 or 4, 3 * v_u_237, 22 * v_u_237, 1, Vector3.new(0, 1, 0), 12)
					v_u_3.flash(v261 + Vector3.new(0, 1.5, 0), v_u_8, 3.5 * v_u_237, 0.2)
				end
			end
			local v262 = v_u_4.bar(v240, v240 + Vector3.new(0, 42, 0) * v_u_237, 8 * v_u_237, v_u_8, 0.15)
			v_u_4.thinBar(v262, 0.55, true)
			v_u_4.thinBar(v_u_4.bar(v240, v240 + Vector3.new(0, 42, 0) * v_u_237, 2.8 * v_u_237, v_u_11), 0.45, true)
			p_u_35.dome(v240, v_u_239 * 0.85, v_u_8, 0.5)
			v_u_3.ring(v240, v_u_8, v_u_239 * 1.25, 0.6, v_u_7.Shockwave)
			v_u_3.ring(v240 + Vector3.new(0, 0.1, 0), v_u_9, v_u_239 * 0.9, 0.45, v_u_7.Ring)
			v_u_4.facePic(v240 + Vector3.new(0, 4, 0) * v_u_237, v_u_239 * 0.5, v_u_239 * 1.8, v_u_7.ImpactBurst, v_u_8, 0.5, v_u_16, 0.2)
			v_u_3.flash(v240 + Vector3.new(0, 3, 0) * v_u_237, v_u_8, v_u_239 * 0.8, 0.22)
			v_u_4.groundPic(v240 + Vector3.new(0, 0.1, 0), v_u_239 * 1, v_u_239 * 2.8, v_u_7.MuzanPool, v_u_12, 0, 0.18, 0.4, 0.6, 0.5)
			v_u_30(v240 + Vector3.new(0, 2, 0), v_u_238 and 4 or 14, 3.5 * v_u_237, v_u_239 * 1.1, 1.1, Vector3.new(0, 1, 0), 80)
			if not v_u_238 then
				local v263 = {
					v_u_10,
					v_u_9,
					v_u_13,
					v_u_10
				}
				p_u_35.chunks(v240 + Vector3.new(0, 1, 0), v263, 16, 45 * v_u_237, 1 * v_u_237, 1.5, false, 1)
			end
			v_u_6.play("Explosion", {
				["at"] = v240,
				["volume"] = p235.mine and 1 or 0.5
			})
			v_u_6.play("Crit", {
				["at"] = v240,
				["volume"] = p235.mine and 0.6 or 0.3
			})
			if p235.mine then
				v_u_3.shake(0.6, 0.5)
				v_u_4.tint("DemonKing", Color3.fromRGB(255, 205, 205), 0.1, 0.15, 0.03, 0.1, 0.5)
			end
		end,
		["hit"] = function(p264, p265, _) -- name: hit
			-- upvalues: (copy) p_u_35, (ref) v_u_8, (ref) v_u_10
			p_u_35.burst("Impact", p265, v_u_8, 0.8)
			if not p264.lite then
				p_u_35.spikes(p265, v_u_10, 2, 5, 0.22, Vector3.new(0, 1, 0), 0.7)
			end
		end
	}
	return v70
end