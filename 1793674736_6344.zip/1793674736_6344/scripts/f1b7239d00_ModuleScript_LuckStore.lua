local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Gifting)
local v_u_6 = require(script.Parent.LuckLadder)
local v_u_7 = require(script.Parent.State)
local v_u_8 = require(script.Parent.Store)
local v9 = v2.Shared
local v_u_10 = require(v9.Config.Images)
require(v9.Config.Products)
local v_u_11 = require(v9.Config.Release)
local v12 = {}
local v_u_13 = v1.LocalPlayer
local v_u_14 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_15 = {
	{
		["key"] = "bossLuck2",
		["boost"] = "luck2",
		["icon"] = nil,
		["icon"] = function() -- name: icon
			-- upvalues: (copy) v_u_10
			return v_u_10.Icon.LuckClover
		end
	},
	{
		["key"] = "bossLuck5",
		["boost"] = "luck5",
		["icon"] = nil,
		["icon"] = function() -- name: icon
			-- upvalues: (copy) v_u_10
			return v_u_10.Icon.LuckClover5 or v_u_10.Icon.LuckClover
		end
	}
}
local function v_u_19(p16, p17) -- name: child
	for v18 in string.gmatch(p17, "[^%.]+") do
		if not p16 then
			continue
		end
		p16 = p16:FindFirstChild(v18)
	end
	return p16
end
local function v_u_25(p20) -- name: fresh
	for _, v21 in p20:GetDescendants() do
		local v22 = v21.Parent
		local v23
		if v21.Name == "Shine" and v22 ~= nil then
			v23 = v22:GetAttribute("Ui-Effect") == "Shine"
		else
			v23 = false
		end
		if v23 or (v21.Name == "PadHint" or (v21.Name == "GiftButton" or v21.Name == "Gloss")) then
			v21:Destroy()
		elseif v21:IsA("ImageLabel") then
			local v24 = v21:GetAttribute("Ui-Effect")
			if v24 ~= "Bg_X" and v24 ~= "Bg_Y" then
				continue
			end
			v21.Position = UDim2.fromScale(v21.Position.X.Scale, v21.Position.Y.Scale)
			v21.Size = UDim2.fromScale(v21.Size.X.Scale, v21.Size.Y.Scale)
		else
			if not v21:IsA("UIScale") or v21.Name ~= "Pop" then
				continue
			end
			v21.Scale = 1
		end
	end
end
local function v_u_29(p26) -- name: cardLine
	-- upvalues: (copy) v_u_14
	local v27 = Instance.new("TextLabel")
	v27.Name = "Line"
	v27.BackgroundTransparency = 1
	v27.AnchorPoint = Vector2.new(0.5, 0.5)
	v27.Position = UDim2.fromScale(0.735, 0.47)
	v27.Size = UDim2.fromScale(0.46, 0.26)
	v27.FontFace = v_u_14
	v27.TextScaled = true
	v27.TextWrapped = true
	v27.TextColor3 = Color3.new(1, 1, 1)
	v27.ZIndex = 4
	local v28 = Instance.new("UIStroke")
	v28.Thickness = 2
	v28.Color = Color3.new(0, 0, 0)
	v28.Parent = v27
	v27.Parent = p26
	return v27
end
local v_u_30 = {}
local v_u_31 = nil
local function v_u_37() -- name: update
	-- upvalues: (copy) v_u_5, (copy) v_u_30, (copy) v_u_8, (ref) v_u_31, (copy) v_u_6
	local v32 = v_u_5.giftMode() ~= nil
	local v33 = false
	for _, v34 in v_u_30 do
		local v35 = v34.shown()
		if not v32 and v34.frame.Visible ~= v35 then
			v34.frame.Visible = v35
		end
		v33 = v33 or v35
		if v34.line then
			v34.line.Text = v34.text()
		end
		local v36 = v34.priceOf()
		if v34.price and v36 then
			v34.price.Text = v_u_8.priceText(v36)
		end
		if not (v34.draw and v35) then
			continue
		end
		v34.draw()
	end
	if v_u_31 then
		v_u_31.Text = v_u_6.on() and "- Luck -" or "- Boss Luck -"
		if not v32 and v_u_31.Visible ~= v33 then
			v_u_31.Visible = v33
		end
	end
end
local function v_u_41(p38) -- name: buildHeading
	-- upvalues: (ref) v_u_31
	local v39 = p38:FindFirstChild("ProductsText")
	if v39 and (v39:IsA("TextLabel") and not p38:FindFirstChild("LuckText")) then
		local v40 = v39:Clone()
		v40.Name = "LuckText"
		v40.Text = "- Boss Luck -"
		v40.LayoutOrder = 290
		v40.Parent = p38
		v_u_31 = v40
	end
end
local function v_u_63(p42) -- name: buildLadder
	-- upvalues: (copy) v_u_25, (copy) v_u_6, (copy) v_u_5, (copy) v_u_30
	local v43 = p42:FindFirstChild("Deal_kurama")
	if not v43 then
		for _, v44 in p42:GetChildren() do
			local v45 = v44.Name
			if string.sub(v45, 1, 5) ~= "Deal_" or not v44:FindFirstChild("Purchase1") then
				continue
			end
			v43 = v44
		end
	end
	if v43 and (v43:IsA("GuiObject") and not p42:FindFirstChild("Deal_luckLadder")) then
		local v46 = v43:Clone()
		v_u_25(v46)
		v46.Name = "Deal_luckLadder"
		v46:SetAttribute("Ui-World", nil)
		v46:SetAttribute("Ui-Slot", nil)
		v46.LayoutOrder = 291
		v46.Visible = false
		for _, v47 in { "LimitedStock", "Owned" } do
			local v48 = v46:FindFirstChild(v47)
			if not (v48 and v48:IsA("GuiObject")) then
				continue
			end
			if v47 == "Owned" then
				v48.Visible = false
			else
				v48:Destroy()
			end
		end
		local v_u_49 = v46:FindFirstChild("Title")
		local v50 = v46:FindFirstChild("Tag")
		local v_u_51 = v46:FindFirstChild("Picture")
		local v52 = v46:FindFirstChild("Line1")
		local v_u_53 = v46:FindFirstChild("Line2")
		if v50 and v50:IsA("TextLabel") then
			v50.Text = "FOR GOOD!"
		end
		if v52 and v52:IsA("TextLabel") then
			v52.Text = "RARER PETS + BOSS DROPS"
		end
		for _, v54 in { v52, v_u_53 } do
			if not v54 or (not v54:IsA("TextLabel") or v54.Position.X.Scale + v54.Size.X.Scale <= 0.73) then
				continue
			end
			v54.Size = UDim2.new(0.73 - v54.Position.X.Scale, 0, v54.Size.Y.Scale, v54.Size.Y.Offset)
		end
		local v_u_55 = v46:FindFirstChild("Purchase1")
		local v56
		if v_u_55 then
			v56 = v_u_55:FindFirstChild("PriceTag", true)
		else
			v56 = v_u_55
		end
		if v_u_55 and v_u_55:IsA("GuiButton") then
			v_u_55:SetAttribute("Ui-Pass", nil)
			v_u_55:SetAttribute("Ui-Pack", nil)
			v_u_55.Activated:Connect(function()
				-- upvalues: (ref) v_u_6, (ref) v_u_5
				local v57 = v_u_6.offer()
				if not (v57 and v_u_5.storeBuy(v57.key)) then
					v_u_6.buy()
				end
			end)
		end
		v46.Parent = p42
		local v58 = v_u_30
		local v59 = {
			["frame"] = nil,
			["line"] = nil,
			["price"] = nil,
			["shown"] = nil,
			["text"] = nil,
			["priceOf"] = nil,
			["draw"] = nil,
			["frame"] = v46
		}
		if not (v56 and v56:IsA("TextLabel")) then
			v56 = nil
		end
		v59.price = v56
		function v59.shown() -- name: shown
			-- upvalues: (ref) v_u_6
			return v_u_6.offer() ~= nil
		end
		function v59.text() -- name: text
			return ""
		end
		function v59.priceOf() -- name: priceOf
			-- upvalues: (ref) v_u_6
			local v60 = v_u_6.offer()
			if v60 then
				return v60.price
			else
				return nil
			end
		end
		function v59.draw() -- name: draw
			-- upvalues: (ref) v_u_6, (copy) v_u_49, (copy) v_u_53, (copy) v_u_51, (copy) v_u_55
			local v61 = v_u_6.offer()
			if v61 then
				local v62 = v61.mult or 2
				if v_u_49 and v_u_49:IsA("TextLabel") then
					v_u_49.Text = ("x%* LUCK"):format(v62)
				end
				if v_u_53 and v_u_53:IsA("TextLabel") then
					v_u_53.Text = ("x%* MYTHIC PET CHANCE"):format(v62)
				end
				if v_u_51 and v_u_51:IsA("ImageLabel") then
					v_u_51.Image = v_u_6.picture(v62)
				end
				if v_u_55 then
					v_u_55:SetAttribute("Ui-Product", v61.key)
				end
			end
		end
		table.insert(v58, v59)
	end
end
local function v_u_86(p64) -- name: buildBossLuck
	-- upvalues: (copy) v_u_15, (copy) v_u_8, (copy) v_u_25, (copy) v_u_29, (copy) v_u_5, (copy) v_u_30, (copy) v_u_11, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7
	local v65 = p64:FindFirstChild("Product_boost2")
	if v65 and v65:IsA("GuiObject") then
		for v66, v_u_67 in v_u_15 do
			local v_u_68 = v_u_67.key
			local v69 = v_u_8.product(v_u_68)
			if not v69 or p64:FindFirstChild("Product_" .. v_u_68) then
				continue
			end
			local v70 = v65:Clone()
			v_u_25(v70)
			v70.Name = "Product_" .. v_u_68
			v70.LayoutOrder = v66 + 291
			v70.Visible = false
			local v71 = v70:FindFirstChild("Title")
			if v71 and v71:IsA("TextLabel") then
				v71.Text = v69.name
			end
			local v72 = v70:FindFirstChild("Icon")
			if v72 and v72:IsA("ImageLabel") then
				v72.Image = v_u_67.icon() or v72.Image
			end
			local v73 = v_u_29(v70)
			local v74 = v70:FindFirstChild("Purchase")
			local v75
			if v74 then
				v75 = v74:FindFirstChild("PriceTag")
			else
				v75 = v74
			end
			if v74 and v74:IsA("GuiButton") then
				v74:SetAttribute("Ui-Product", v_u_68)
				v74.Activated:Connect(function()
					-- upvalues: (ref) v_u_5, (copy) v_u_68, (ref) v_u_8
					if not v_u_5.storeBuy(v_u_68) then
						v_u_8.buyProduct(v_u_68)
					end
				end)
			end
			v70.Parent = p64
			local v_u_76 = v69.mult or 2
			local v77 = v_u_30
			local v78 = {
				["frame"] = v70,
				["line"] = v73
			}
			if not (v75 and v75:IsA("TextLabel")) then
				v75 = nil
			end
			v78.price = v75
			function v78.shown() -- name: shown
				-- upvalues: (copy) v_u_68, (ref) v_u_8, (ref) v_u_11, (ref) v_u_3, (ref) v_u_4
				local v79 = v_u_68
				local v80 = v_u_8.product(v79)
				if v80 and (v_u_11.on(2) and not v_u_8.luckBlocked()) then
					if v80.id == 0 then
						local v81 = v_u_3:IsStudio()
						if v81 then
							v81 = v_u_4:GetAttribute("DevBossLuck") == true
						end
						if not v81 then
							v80 = nil
						end
					end
				else
					v80 = nil
				end
				return v80 ~= nil
			end
			function v78.text() -- name: text
				-- upvalues: (ref) v_u_7, (copy) v_u_67, (copy) v_u_76
				local v82 = v_u_7.boostLeft(v_u_67.boost)
				if v82 <= 0 then
					return ("x%* KYUBI DROP CHANCE"):format(v_u_76)
				end
				local v83 = math.floor(v82)
				local v84 = math.max(0, v83)
				return "ON NOW " .. string.format("%d:%02d", v84 // 60, v84 % 60)
			end
			function v78.priceOf() -- name: priceOf
				-- upvalues: (ref) v_u_8, (copy) v_u_68
				local v85 = v_u_8.product(v_u_68)
				if v85 then
					return v85.price
				else
					return nil
				end
			end
			table.insert(v77, v78)
		end
	end
end
function v12.start() -- name: start
	-- upvalues: (copy) v_u_13, (copy) v_u_19, (copy) v_u_41, (copy) v_u_6, (copy) v_u_63, (copy) v_u_86, (copy) v_u_37, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4
	local v_u_87 = v_u_13:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	if v_u_87 then
		v_u_87 = v_u_19(v_u_87, "Frames.Store")
	end
	local v88
	if v_u_87 then
		v88 = v_u_87:FindFirstChild("Holder", true)
	else
		v88 = v_u_87
	end
	if v_u_87 and (v_u_87:IsA("GuiObject") and v88) then
		v_u_41(v88)
		if v_u_6.on() then
			v_u_63(v88)
		end
		v_u_86(v88)
		v_u_37()
		v_u_6.start()
		v_u_6.changed:Connect(v_u_37)
		v_u_8.randomChanged:Connect(v_u_37)
		v_u_8.pricesChanged:Connect(v_u_37)
		if v_u_3:IsStudio() then
			v_u_4:GetAttributeChangedSignal("DevBossLuck"):Connect(v_u_37)
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_87, (ref) v_u_37
			while v_u_87.Parent do
				if v_u_87.Visible then
					v_u_37()
				end
				task.wait(0.5)
			end
		end)
		v_u_87:GetPropertyChangedSignal("Visible"):Connect(v_u_37)
	end
end
return v12