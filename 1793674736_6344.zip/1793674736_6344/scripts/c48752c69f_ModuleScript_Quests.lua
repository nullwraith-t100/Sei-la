local v1 = require(script.Parent.Parent.Logic.Prizes)
local v_u_2 = {
	["SET_SIZE"] = 5
}
local v3 = {
	["daily"] = {
		{
			["id"] = "d_clicks_300",
			["kind"] = "clicks",
			["goal"] = 300,
			["prize"] = nil,
			["prize"] = v1.trophies(0.2, 3)
		},
		{
			["id"] = "d_clicks_1000",
			["kind"] = "clicks",
			["goal"] = 1000,
			["prize"] = nil,
			["prize"] = v1.trophies(0.4, 4)
		},
		{
			["id"] = "d_kills_40",
			["kind"] = "kills",
			["goal"] = 40,
			["prize"] = nil,
			["prize"] = v1.trophies(0.3, 4)
		},
		{
			["id"] = "d_kills_120",
			["kind"] = "kills",
			["goal"] = 120,
			["prize"] = nil,
			["prize"] = v1.trophies(0.5, 5)
		},
		{
			["id"] = "d_stages_5",
			["kind"] = "stages",
			["goal"] = 5,
			["prize"] = nil,
			["prize"] = v1.trophies(0.4, 5)
		},
		{
			["id"] = "d_stages_15",
			["kind"] = "stages",
			["goal"] = 15,
			["prize"] = nil,
			["prize"] = v1.trophies(0.7, 6)
		},
		{
			["id"] = "d_minutes_15",
			["kind"] = "minutes",
			["goal"] = 15,
			["prize"] = nil,
			["prize"] = v1.boost("chakra", 3)
		},
		{
			["id"] = "d_minutes_30",
			["kind"] = "minutes",
			["goal"] = 30,
			["prize"] = nil,
			["prize"] = v1.boost("chakra", 5)
		},
		{
			["id"] = "d_hatch_3",
			["kind"] = "hatch",
			["goal"] = 3,
			["prize"] = nil,
			["prize"] = v1.worldEgg(1, 1)
		},
		{
			["id"] = "d_hatch_8",
			["kind"] = "hatch",
			["goal"] = 8,
			["prize"] = nil,
			["prize"] = v1.worldEgg(1, 2)
		},
		{
			["id"] = "d_rebirths_2",
			["kind"] = "rebirths",
			["goal"] = 2,
			["prize"] = nil,
			["prize"] = v1.trophies(0.3, 4)
		},
		{
			["id"] = "d_rebirths_5",
			["kind"] = "rebirths",
			["goal"] = 5,
			["prize"] = nil,
			["prize"] = v1.boost("wins", 10)
		}
	},
	["weekly"] = {
		{
			["id"] = "w_minutes_180",
			["kind"] = "minutes",
			["goal"] = 180,
			["prize"] = nil,
			["prize"] = v1.worldEgg(2, 1)
		},
		{
			["id"] = "w_minutes_420",
			["kind"] = "minutes",
			["goal"] = 420,
			["prize"] = nil,
			["prize"] = v1.worldEgg(2, 2)
		},
		{
			["id"] = "w_kills_500",
			["kind"] = "kills",
			["goal"] = 500,
			["prize"] = nil,
			["prize"] = v1.trophies(2, 40)
		},
		{
			["id"] = "w_kills_1500",
			["kind"] = "kills",
			["goal"] = 1500,
			["prize"] = nil,
			["prize"] = v1.trophies(3.5, 60)
		},
		{
			["id"] = "w_stages_30",
			["kind"] = "stages",
			["goal"] = 30,
			["prize"] = nil,
			["prize"] = v1.trophies(2.5, 50)
		},
		{
			["id"] = "w_stages_80",
			["kind"] = "stages",
			["goal"] = 80,
			["prize"] = nil,
			["prize"] = v1.trophies(4.5, 75)
		},
		{
			["id"] = "w_hatch_15",
			["kind"] = "hatch",
			["goal"] = 15,
			["prize"] = nil,
			["prize"] = v1.boost("wins", 15)
		},
		{
			["id"] = "w_hatch_40",
			["kind"] = "hatch",
			["goal"] = 40,
			["prize"] = nil,
			["prize"] = v1.boost("wins", 30)
		},
		{
			["id"] = "w_rebirths_5",
			["kind"] = "rebirths",
			["goal"] = 5,
			["prize"] = nil,
			["prize"] = v1.trophies(2.5, 40)
		},
		{
			["id"] = "w_rebirths_15",
			["kind"] = "rebirths",
			["goal"] = 15,
			["prize"] = nil,
			["prize"] = v1.trophies(4, 65)
		},
		{
			["id"] = "w_clicks_3000",
			["kind"] = "clicks",
			["goal"] = 3000,
			["prize"] = nil,
			["prize"] = v1.boost("chakra", 10)
		},
		{
			["id"] = "w_clicks_10000",
			["kind"] = "clicks",
			["goal"] = 10000,
			["prize"] = nil,
			["prize"] = v1.trophies(2.5, 45)
		}
	}
}
v_u_2.pools = v3
local v4 = {
	["daily"] = {
		{
			["id"] = "d1",
			["kind"] = "clicks",
			["goal"] = 300,
			["prize"] = nil,
			["prize"] = v1.trophies(0.5, 5)
		},
		{
			["id"] = "d2",
			["kind"] = "kills",
			["goal"] = 40,
			["prize"] = nil,
			["prize"] = v1.trophies(0.75, 8)
		},
		{
			["id"] = "d3",
			["kind"] = "stages",
			["goal"] = 5,
			["prize"] = nil,
			["prize"] = v1.trophies(1, 10)
		},
		{
			["id"] = "d4",
			["kind"] = "minutes",
			["goal"] = 20,
			["prize"] = nil,
			["prize"] = v1.boost("chakra", 10)
		},
		{
			["id"] = "d5",
			["kind"] = "hatch",
			["goal"] = 3,
			["prize"] = nil,
			["prize"] = v1.worldEgg(1, 2)
		}
	},
	["weekly"] = {
		{
			["id"] = "w1",
			["kind"] = "minutes",
			["goal"] = 300,
			["prize"] = nil,
			["prize"] = v1.worldEgg(2, 2)
		},
		{
			["id"] = "w2",
			["kind"] = "kills",
			["goal"] = 1000,
			["prize"] = nil,
			["prize"] = v1.trophies(6, 100)
		},
		{
			["id"] = "w3",
			["kind"] = "stages",
			["goal"] = 60,
			["prize"] = nil,
			["prize"] = v1.trophies(8, 150)
		},
		{
			["id"] = "w4",
			["kind"] = "hatch",
			["goal"] = 25,
			["prize"] = nil,
			["prize"] = v1.boost("wins", 30)
		},
		{
			["id"] = "w5",
			["kind"] = "rebirths",
			["goal"] = 5,
			["prize"] = nil,
			["prize"] = v1.trophies(5, 80)
		}
	}
}
v_u_2.legacy = v4
v_u_2.byId = {}
for _, v5 in {
	v_u_2.pools.daily,
	v_u_2.pools.weekly,
	v_u_2.legacy.daily,
	v_u_2.legacy.weekly
} do
	for _, v6 in v5 do
		v_u_2.byId[v6.id] = v6
	end
end
function v_u_2.legacyIds(p7) -- name: legacyIds
	-- upvalues: (copy) v_u_2
	local v8 = {}
	for _, v9 in v_u_2.legacy[p7] do
		local v10 = v9.id
		table.insert(v8, v10)
	end
	return v8
end
v_u_2.KINDS = {
	"clicks",
	"kills",
	"stages",
	"hatch",
	"minutes",
	"rebirths"
}
v_u_2.DAY = 86400
v_u_2.WEEK = 604800
v_u_2.WEEK_OFFSET = 259200
function v_u_2.dayIndex(p11) -- name: dayIndex
	-- upvalues: (copy) v_u_2
	local v12 = p11 / v_u_2.DAY
	return math.floor(v12)
end
function v_u_2.weekIndex(p13) -- name: weekIndex
	-- upvalues: (copy) v_u_2
	local v14 = (p13 + v_u_2.WEEK_OFFSET) / v_u_2.WEEK
	return math.floor(v14)
end
function v_u_2.resetsIn(p15, p16) -- name: resetsIn
	-- upvalues: (copy) v_u_2
	if p15 == "daily" then
		return (v_u_2.dayIndex(p16) + 1) * v_u_2.DAY - p16
	else
		return (v_u_2.weekIndex(p16) + 1) * v_u_2.WEEK - v_u_2.WEEK_OFFSET - p16
	end
end
return v_u_2