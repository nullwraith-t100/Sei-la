local v_u_1 = game:GetService("RunService")
local v2 = require(script.Parent:WaitForChild("CommonUtils"))
local v_u_3 = v2.get("CharacterUtil")
local v_u_4 = v2.get("ConnectionUtil")
local v_u_5 = v2.get("EventBus")
local v_u_6 = require(script.Parent)
local v_u_7 = require(script.Parent:WaitForChild("CameraModule"))
local v_u_8 = require(script.Parent:WaitForChild("ControlModule"))
local v_u_9 = require(script.Parent:WaitForChild("ServerAuthority"))
local v_u_10 = {}
v_u_10.__index = v_u_10
function v_u_10.new() -- name: new
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10
	local v11 = {
		["data"] = {
			["playerModule"] = nil,
			["isJumping"] = false,
			["moveVector"] = nil,
			["worldMoveVector"] = nil,
			["actions"] = nil,
			["player"] = nil,
			["character"] = nil,
			["connectionUtil"] = nil,
			["eventBus"] = nil,
			["isServerAuthority"] = false,
			["playerModule"] = v_u_6,
			["moveVector"] = Vector2.new(),
			["worldMoveVector"] = Vector3.new(),
			["actions"] = {},
			["connectionUtil"] = v_u_4.new(),
			["eventBus"] = v_u_5.new()
		}
	}
	local v12 = v_u_10
	return setmetatable(v11, v12)
end
function v_u_10.start(p_u_13) -- name: start
	-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_8, (copy) v_u_1, (copy) v_u_7
	p_u_13.data.connectionUtil:trackConnection("ONLOCALPLAYER", v_u_3.onLocalPlayer(function(p14)
		-- upvalues: (copy) p_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (ref) v_u_3, (ref) v_u_7
		p_u_13.data.player = p14
		v_u_9.initialize(p_u_13.data)
		v_u_8:initialize(p_u_13.data)
		v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT", Enum.RenderPriority.Input.Value, function(p15)
			-- upvalues: (ref) p_u_13, (ref) v_u_3, (ref) v_u_8
			p_u_13.data.character = v_u_3.getCharacter()
			if p_u_13.data.character then
				v_u_8:Update(p_u_13.data, p15)
			end
		end)
		p_u_13.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_INPUT", function()
			-- upvalues: (ref) v_u_1
			v_u_1:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT")
		end)
		v_u_1:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA", Enum.RenderPriority.Camera.Value, function(p16)
			-- upvalues: (ref) v_u_7, (ref) p_u_13
			v_u_7:Update(p_u_13.data, p16)
		end)
		p_u_13.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_CAMERA", function()
			-- upvalues: (ref) v_u_1
			v_u_1:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA")
		end)
	end))
end
function v_u_10.stop(p17) -- name: stop
	p17.data.connectionUtil:disconnectAll()
end
return v_u_10