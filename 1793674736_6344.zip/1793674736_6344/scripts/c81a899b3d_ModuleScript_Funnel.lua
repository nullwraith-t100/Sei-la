local v1 = {
	["steps"] = {
		{
			["name"] = "Joined"
		},
		{
			["name"] = "Went to the battle"
		},
		{
			["name"] = "Defeated the enemies"
		},
		{
			["name"] = "Took the win pad"
		},
		{
			["name"] = "Upgraded to Mangekyo"
		},
		{
			["name"] = "Used the E skill"
		},
		{
			["name"] = "Used the R skill"
		},
		{
			["name"] = "Went to training"
		},
		{
			["name"] = "Reached the rebirth level"
		},
		{
			["name"] = "Tutorial Completed"
		}
	},
	["finishedOnEntering"] = {
		["fight"] = 2,
		["pad"] = 3,
		["eye"] = 4,
		["skillE"] = 5,
		["skillR"] = 6,
		["train"] = 7,
		["level"] = 8,
		["rebirth"] = 9
	},
	["JOINED"] = 1
}
v1.COMPLETED = #v1.steps
return v1