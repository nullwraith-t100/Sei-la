local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Mythic8)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(v2.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF1A2E")
local v_u_9 = Color3.fromRGB(150, 0, 22)
local v_u_10 = Color3.fromRGB(240, 236, 228)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.Material.SmoothPlastic
local v_u_13 = Enum.Material.Neon
local v_u_14 = CFrame.identity
local v_u_15 = {
	{
		["root"] = Vector3.new(-0.35, 0.55, 0.3),
		["tip"] = Vector3.new(-2.3, 3.4, 1.9),
		["curl"] = 1
	},
	{
		["root"] = Vector3.new(0.35, 0.55, 0.3),
		["tip"] = Vector3.new(2.3, 3.4, 1.9),
		["curl"] = -1
	},
	{
		["root"] = Vector3.new(-0.45, 0.15, 0.32),
		["tip"] = Vector3.new(-3.6, 1.1, 2.1),
		["curl"] = -1
	},
	{
		["root"] = Vector3.new(0.45, 0.15, 0.32),
		["tip"] = Vector3.new(3.6, 1.1, 2.1),
		["curl"] = 1
	},
	{
		["root"] = Vector3.new(-0.3, -0.3, 0.3),
		["tip"] = Vector3.new(-2.6, -2.2, 2.6),
		["curl"] = 1
	},
	{
		["root"] = Vector3.new(0.3, -0.3, 0.3),
		["tip"] = Vector3.new(2.6, -2.2, 2.6),
		["curl"] = -1
	}
}
local function v_u_21(p16, p17) -- name: axisAt
	local v18 = p17.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p17.Unit
	local v19 = v18.Y
	local v20 = math.abs(v19) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p16, p16 + v18, v20) * CFrame.Angles(0, 1.5707963267948966, 0)
end
return function(p_u_22)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3, (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_11, (copy) v_u_9, (copy) v_u_14, (copy) v_u_10, (copy) v_u_12, (copy) v_u_13, (copy) v_u_15, (copy) v_u_21
	return {
		["w8_demon_king"] = function(p_u_23, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) p_u_22, (ref) v_u_3, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_11, (ref) v_u_9, (ref) v_u_14, (ref) v_u_10, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15, (ref) v_u_21
			v_u_6.images({ v_u_7.MuzanTendril, v_u_7.MuzanPool, v_u_7.MuzanMaw })
			local v24 = p_u_23.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v_u_26 = p_u_23.fx
			local v27 = p_u_23.character == v_u_1.LocalPlayer.Character
			local v_u_28 = p_u_22.backOf(p_u_23)
			local v29 = p_u_23.character:FindFirstChild("Head")
			if not (v29 and v29:IsA("BasePart")) then
				v29 = nil
			end
			local v_u_30
			if v29 then
				v_u_30 = v29.Size.Y
			else
				v_u_30 = v_u_25 * 1.2
			end
			local v_u_31 = p_u_22.crownOf(p_u_23)
			p_u_23.eyeLift = 3.1
			local v_u_40 = p_u_22.throb(p_u_23, 6, 3.2, 1.3, function(p32)
				-- upvalues: (ref) p_u_22, (copy) p_u_23, (ref) v_u_3, (ref) v_u_8, (copy) v_u_25, (copy) v_u_26, (ref) v_u_7, (copy) v_u_28, (ref) v_u_5, (ref) v_u_4, (ref) v_u_11, (ref) v_u_9
				local v33 = p_u_22.feetAt(p_u_23, p32, 0.12)
				v_u_3.ring(v33, v_u_8, v_u_25 * 10 * v_u_26, 0.5, v_u_7.Shockwave)
				v_u_3.flash((p32 * v_u_28).Position, v_u_8, v_u_25 * 4 * v_u_26, 0.25)
				local v34 = v_u_5.level() <= 1 and 2 or 4
				for v35 = 1, v34 do
					local v36 = (v35 + math.random() * 0.4) * 3.141592653589793 * 2 / v34
					local v37 = math.cos(v36)
					local v38 = math.sin(v36)
					local v39 = v33 + Vector3.new(v37, 0, v38) * 3 * v_u_25 * v_u_26
					v_u_4.planeFlip(CFrame.new(v39) * CFrame.Angles(0, v36, 0), v_u_25 * 2.6 * v_u_26, v_u_7.MuzanMaw, v_u_11, 0.9)
				end
				if v_u_5.level() > 1 then
					v_u_4.spray(v33 + Vector3.new(0, 0.5, 0), v_u_7.FxSmoke, 6, v_u_25 * 2.2, v_u_25 * 6, 0.9, v_u_9, {
						["layout"] = nil,
						["mode"] = nil,
						["emission"] = 0,
						["spread"] = 70,
						["layout"] = Enum.ParticleFlipbookLayout.Grid4x4,
						["mode"] = Enum.ParticleFlipbookMode.Random
					})
				end
			end)
			local v42 = p_u_22.group(p_u_23, function(p41)
				-- upvalues: (copy) v_u_31, (copy) v_u_30
				return v_u_31(p41) * CFrame.new(0, 0.62 * v_u_30, 0.02 * v_u_30) * CFrame.Angles(-0.1, 0, 0.06)
			end)
			local v43 = v_u_4.piece("w8_demon_king", 2.15 * v_u_30, 1.5)
			if v43 then
				p_u_22.pin(p_u_23, v42, v43, v_u_14)
			else
				p_u_22.pin(p_u_23, v42, p_u_22.blob(Vector3.new(1.85, 0.1, 1.65) * v_u_30, v_u_10, 0, v_u_12), CFrame.identity)
				p_u_22.pin(p_u_23, v42, p_u_22.blob(Vector3.new(1.08, 0.75, 0.95) * v_u_30, v_u_10, 0, v_u_12), CFrame.new(0, 0.3 * v_u_30, 0))
				p_u_22.pin(p_u_23, v42, p_u_22.blob(Vector3.new(1.12, 0.2, 0.99) * v_u_30, v_u_8, 0, v_u_13), CFrame.new(0, 0.13 * v_u_30, 0))
			end
			local v_u_44 = {}
			for v45, v46 in v_u_15 do
				local v_u_47 = Instance.new("Attachment")
				v_u_47.Parent = p_u_23.root
				p_u_22.own(p_u_23, v_u_47)
				local v48 = p_u_23.stops
				table.insert(v48, function()
					-- upvalues: (copy) v_u_47
					v_u_47:Destroy()
				end)
				local v_u_49 = Instance.new("Attachment")
				v_u_49.Parent = p_u_23.root
				p_u_22.own(p_u_23, v_u_49)
				local v50 = p_u_23.stops
				table.insert(v50, function()
					-- upvalues: (copy) v_u_49
					v_u_49:Destroy()
				end)
				local v51 = v_u_4.beam(v_u_47, v_u_49, v_u_7.MuzanTendril, v_u_11, v_u_25 * 1.5, v_u_25 * 0.5, 0)
				v51.TextureMode = Enum.TextureMode.Wrap
				v51.TextureLength = v_u_25 * 2.4
				v51.TextureSpeed = (v45 % 2 == 0 and 1 or -1) * 0.15
				v51.Segments = 14
				if v27 then
					v51.Transparency = NumberSequence.new(0.15)
				end
				local v_u_52 = {
					["a0"] = v_u_47,
					["a1"] = v_u_49,
					["beam"] = v51,
					["reach"] = v46,
					["tipCf"] = CFrame.identity
				}
				table.insert(v_u_44, v_u_52)
				v_u_4.formBlade(p_u_22, p_u_23, v_u_8, v_u_13, function()
					-- upvalues: (copy) v_u_52, (copy) v_u_25
					return v_u_52.tipCf, v_u_25 * 0.9, v_u_25 * 0.36, v_u_25 * 0.12
				end)
			end
			local v_u_53 = 0
			local v54 = p_u_23.ticks
			local function v84(p55, p56, p57)
				-- upvalues: (copy) v_u_40, (ref) v_u_53, (copy) v_u_28, (copy) v_u_44, (copy) v_u_25, (copy) p_u_23, (ref) v_u_21
				local v58 = v_u_40()
				if v_u_53 >= v58 then
					local v59 = v_u_53
					local v60 = v58 - v_u_53
					local v61 = p57 * 6
					v58 = v59 + v60 * math.min(v61, 1)
				end
				v_u_53 = v58
				local v62 = p55 * v_u_28
				for v63, v64 in v_u_44 do
					local v65 = v64.reach
					local v66 = p56 * (v63 * 0.13 + 1.6) + v63 * 1.9
					local v67 = math.sin(v66)
					local v68 = p56 * (v63 * 0.07 + 1.1) + v63
					local v69 = math.cos(v68)
					local v70 = v_u_53 * 0.55 + 1
					local v71 = v65.tip.X * v70 + v67 * 0.35
					local v72 = v65.tip.Y * (v65.tip.Y < 0 and 1 or v70) + v69 * 0.35
					local v73 = v65.tip.Z + v69 * 0.3
					local v74 = Vector3.new(v71, v72, v73) * v_u_25
					local v75 = v62 * (v65.root * v_u_25)
					local v76 = v62 * v74
					local v77 = p55.Position.Y + p_u_23.feet + 0.25
					if v76.Y < v77 then
						local v78 = v76.X
						local v79 = v76.Z
						v76 = Vector3.new(v78, v77, v79)
					end
					local v80 = v65.root.X * 0.6
					local v81 = v62:VectorToWorldSpace((Vector3.new(v80, 0.25, 1)))
					local v82 = ((v76 - v75).Unit + Vector3.new(0, 0.15, 0) * v65.curl + v81 * 0.1).Unit
					v64.a0.WorldCFrame = v_u_21(v75, v81)
					v64.a1.WorldCFrame = v_u_21(v76, v82)
					v64.beam.CurveSize0 = (v67 * 0.5 + 1.4) * v_u_25
					v64.beam.CurveSize1 = (v65.curl * 0.8 + v69 * 0.4) * v_u_25
					local v83 = v82:Cross(Vector3.new(0, 1, 0))
					v64.tipCf = CFrame.lookAt(v76 - v82 * 0.1 * v_u_25, v76 + v82, v83.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v83.Unit)
				end
			end
			table.insert(v54, v84)
			local v85 = p_u_22.picture(v_u_25 * 6, v_u_7.Glow, v_u_9, 0.35)
			p_u_22.add(p_u_23, v85, function(p86)
				-- upvalues: (ref) p_u_22, (copy) p_u_23
				return CFrame.new(p_u_22.feetAt(p_u_23, p86, 0.05))
			end)
			local v_u_87 = v_u_4.card(v_u_25 * 6.6, v_u_7.MuzanPool, v_u_11, 0, 1.3)
			p_u_22.add(p_u_23, v_u_87, function(p88, p89)
				-- upvalues: (ref) p_u_22, (copy) p_u_23
				return CFrame.new(p_u_22.feetAt(p_u_23, p88, 0.09)) * CFrame.Angles(0, p89 * 0.08, 0)
			end)
			local v_u_90 = -1
			local v91 = p_u_23.ticks
			local function v101(_, p92)
				-- upvalues: (copy) v_u_40, (ref) v_u_90, (copy) v_u_25, (copy) v_u_87
				local v93 = p92 % 1.1
				local v94 = 1 - v93 / 0.12
				local v95 = math.max(v94, 0)
				local v96 = v93 - 0.25
				local v97 = 1 - math.abs(v96) / 0.1
				local v98 = (v95 + math.max(v97, 0) * 0.6 + v_u_40() * 0.6) * 12
				local v99 = math.floor(v98) / 12
				if v99 ~= v_u_90 then
					v_u_90 = v99
					local v100 = v_u_25 * 6.6 * (v99 * 0.07 + 1)
					v_u_87.Size = Vector3.new(v100, 0.05, v100)
				end
			end
			table.insert(v91, v101)
			local v_u_102 = Instance.new("ParticleEmitter")
			v_u_102.Texture = v_u_7.FxSmoke
			v_u_102.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_102.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_102.Color = ColorSequence.new(v_u_9)
			v_u_102.LightEmission = 0
			v_u_102.LightInfluence = 0
			v_u_102.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_25 * 0.6 * v_u_26), NumberSequenceKeypoint.new(1, v_u_25 * 1.4 * v_u_26) })
			v_u_102.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.3, 0.55), NumberSequenceKeypoint.new(1, 1) })
			v_u_102.Lifetime = NumberRange.new(1.4, 2)
			v_u_102.Speed = NumberRange.new(0.3, 0.8)
			v_u_102.SpreadAngle = Vector2.new(60, 60)
			v_u_102.Rotation = NumberRange.new(0, 360)
			v_u_102.RotSpeed = NumberRange.new(-20, 20)
			v_u_102.Shape = Enum.ParticleEmitterShape.Box
			v_u_102.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_102:SetAttribute("BaseRate", 2.5 * v_u_26)
			v_u_102.Rate = 2.5 * v_u_26 * v_u_5.formRate()
			v_u_102.Parent = v_u_87
			local v103 = p_u_23.stops
			table.insert(v103, function()
				-- upvalues: (copy) v_u_102
				v_u_102.Enabled = false
			end)
		end
	}
end