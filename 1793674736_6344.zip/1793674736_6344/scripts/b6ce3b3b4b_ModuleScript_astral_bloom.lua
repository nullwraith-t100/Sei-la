local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(190, 176, 255)
local v_u_6 = Color3.fromRGB(150, 110, 255)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = CFrame.Angles(1.5707963267948966, 0, 0)
return function(p_u_9)
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_7
	return {
		["w5_astral_bloom"] = function(p_u_10, p11)
			-- upvalues: (ref) v_u_2, (copy) p_u_9, (ref) v_u_5, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6, (ref) v_u_8, (ref) v_u_7
			local v12 = v_u_2.color(p11.color)
			local v13 = p_u_10.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v15 = v_u_14 * 2.3
			local v_u_16 = nil
			local v_u_19 = p_u_9.throb(p_u_10, 4, 1.4, 1.4, function(p17)
				-- upvalues: (ref) v_u_2, (ref) p_u_9, (copy) p_u_10, (ref) v_u_5, (ref) v_u_4, (ref) v_u_16, (ref) v_u_3
				v_u_2.ring(p_u_9.feetAt(p_u_10, p17, 0.15), v_u_5, 5.5 * p_u_10.fx, 0.55, v_u_4.Ring)
				local v18 = v_u_16
				if v18 then
					v18:Emit(v_u_3.level() <= 1 and 3 or 8)
				end
			end)
			local v_u_20 = 0
			local v21 = p_u_10.ticks
			local function v23(_, _, p22)
				-- upvalues: (ref) v_u_20, (copy) v_u_19
				v_u_20 = v_u_20 + p22 * (0.22 + v_u_19() * 3.2)
			end
			table.insert(v21, v23)
			local v29 = p_u_9.group(p_u_10, function(p24, p25)
				-- upvalues: (copy) v_u_14, (ref) v_u_20
				local v26 = CFrame.new
				local v27 = v_u_14 * 1
				local v28 = p25 * 1.1
				return p24 * v26(0, v27 + math.sin(v28) * 0.1 * v_u_14, v_u_14 * 1.9) * CFrame.Angles(0, 0, v_u_20)
			end)
			local v30 = p_u_9.picture(v15 * 3, v_u_4.Glow, v_u_6, 0.3)
			p_u_9.pin(p_u_10, v29, v30, CFrame.new(0, 0, v_u_14 * -0.25) * v_u_8)
			p_u_9.fadeFromBehind(p_u_10, v30, 0.5)
			local v_u_31 = v15 * 2 / 0.886
			local v_u_32 = p_u_9.picture(v_u_31 * 1.07, v_u_4.AstralPetals, v_u_6, 0)
			p_u_9.pin(p_u_10, v29, v_u_32, CFrame.new(0, 0, v_u_14 * -0.08) * v_u_8)
			local v_u_33 = p_u_9.picture(v_u_31, v_u_4.AstralPetals, v12, 0)
			p_u_9.pin(p_u_10, v29, v_u_33, v_u_8)
			local v_u_34 = p_u_9.ball(v_u_14 * 0.55, v_u_7)
			p_u_9.pin(p_u_10, v29, v_u_34, CFrame.new(0, 0, v_u_14 * 0.05))
			local v_u_35 = p_u_9.picture(v_u_14 * 1.7, v_u_4.AstralStar, v12, 0)
			p_u_9.pin(p_u_10, v29, v_u_35, CFrame.new(0, 0, v_u_14 * 0.1) * v_u_8)
			local v_u_36 = {}
			for v37 = 0, 4 do
				local v38 = 1.5707963267948966 + v37 * 3.141592653589793 * 2 / 5
				local v39 = CFrame.new(math.cos(v38) * v15, math.sin(v38) * v15, v_u_14 * 0.05)
				p_u_9.pin(p_u_10, v29, p_u_9.ball(v_u_14 * 0.28, v_u_7), v39)
				local v40 = p_u_9.picture(v_u_14 * 1.25, v_u_4.AstralStar, v12, 0)
				p_u_9.pin(p_u_10, v29, v40, v39 * CFrame.new(0, 0, v_u_14 * 0.05) * v_u_8)
				table.insert(v_u_36, v40)
				local v41 = v38 + 0.6283185307179586
				local v42 = p_u_9.picture(v_u_14 * 0.95, v_u_4.Ring, v_u_6, 0)
				p_u_9.pin(p_u_10, v29, v42, CFrame.new(math.cos(v41) * v15 * 0.78, math.sin(v41) * v15 * 0.78, v_u_14 * 0.04) * v_u_8)
			end
			local v_u_43 = -1
			local v44 = p_u_10.ticks
			local function v62(_, p45)
				-- upvalues: (copy) v_u_19, (ref) v_u_43, (copy) v_u_33, (copy) v_u_31, (copy) v_u_32, (copy) v_u_14, (copy) v_u_35, (copy) v_u_34, (ref) v_u_7, (ref) v_u_5, (copy) v_u_36
				local v46 = v_u_19()
				local v47 = v46 * 3.141592653589793
				local v48 = math.sin(v47) * 0.24 + 1
				local v49 = v48 - v_u_43
				if math.abs(v49) > 0.002 then
					v_u_43 = v48
					local v50 = v_u_33
					local v51 = v_u_31 * v48
					local v52 = v_u_31 * v48
					v50.Size = Vector3.new(v51, 0.05, v52)
					local v53 = v_u_32
					local v54 = v_u_31 * 1.07 * v48
					local v55 = v_u_31 * 1.07 * v48
					v53.Size = Vector3.new(v54, 0.05, v55)
					local v56 = v_u_14 * 1.7 * (1 + v46 * 0.8)
					v_u_35.Size = Vector3.new(v56, 0.05, v56)
					v_u_34.Color = v_u_7:Lerp(v_u_5, v46 * 0.5)
				end
				for v57, v58 in v_u_36 do
					local v59 = v_u_14 * 1.25
					local v60 = p45 * 5 + v57 * 1.9
					local v61 = v59 * (math.sin(v60) * 0.25 + 0.85 + v46 * 0.4)
					v58.Size = Vector3.new(v61, 0.05, v61)
				end
			end
			table.insert(v44, v62)
			for v_u_63 = 1, 3 do
				local v64 = CFrame.Angles
				local v65 = v_u_63 * 2.1
				local v66 = math.cos(v65) * 0.5
				local v67 = v_u_63 * 2.1
				local v68 = v_u_63 * 2.1
				local v_u_69 = v64(v66, v67, math.sin(v68) * 0.45)
				local v_u_70 = v_u_63 * 0.35 + 1.9
				local v71 = p_u_9.ball(v_u_14 * 0.3, v_u_7)
				p_u_9.add(p_u_10, v71, function(p72, p73)
					-- upvalues: (copy) v_u_70, (copy) v_u_63, (copy) v_u_14, (copy) v_u_69
					local v74 = p73 * v_u_70 + v_u_63 * 2.1
					local v75 = CFrame.new
					local v76 = p72.Position
					local v77 = v_u_14 * 0.1
					return v75(v76 + Vector3.new(0, v77, 0)) * v_u_69 * CFrame.new(math.cos(v74) * 2.4 * v_u_14, 0, math.sin(v74) * 2.4 * v_u_14)
				end)
				p_u_9.tail(v71, v_u_7, v_u_5, v_u_14 * 0.16, 0.5)
			end
			local v78 = Instance.new("ParticleEmitter")
			v78.Texture = v_u_4.AstralStar
			v78.Color = ColorSequence.new(v_u_7, v_u_5)
			v78.LightEmission = 0.8
			v78.LightInfluence = 0
			v78.Lifetime = NumberRange.new(0.5, 0.8)
			v78.Size = NumberSequence.new(v_u_14 * 0.7 * p_u_10.fx, 0)
			v78.Speed = NumberRange.new(5 * p_u_10.fx, 9 * p_u_10.fx)
			v78.SpreadAngle = Vector2.new(180, 180)
			v78.Drag = 4
			v78.Rate = 0
			v78.Enabled = false
			v78.Parent = v_u_34
			v_u_16 = v78
			p_u_9.particles(p_u_10, "AuraMode", v_u_5, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_9.particles(p_u_10, "Petals", v12, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end