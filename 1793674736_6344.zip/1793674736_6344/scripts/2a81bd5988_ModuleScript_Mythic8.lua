local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
require(script.Parent.FormTypes)
local v_u_5 = require(script.Parent.Kit)
local v_u_6 = {
	["UP"] = Vector3.new(0, 1, 0)
}
local v_u_7 = Color3.new(1, 1, 1)
function v_u_6.smooth(p8) -- name: smooth
	local v9 = math.clamp(p8, 0, 1)
	return v9 * v9 * (3 - v9 * 2)
end
function v_u_6.outBack(p10) -- name: outBack
	local v11 = math.clamp(p10, 0, 1) - 1
	return v11 * 2.7 * v11 * v11 + 1 + v11 * 1.7 * v11
end
function v_u_6.flat(p12) -- name: flat
	local v13 = p12.X
	local v14 = p12.Z
	local v15 = Vector3.new(v13, 0, v14)
	return v15.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v15.Unit
end
function v_u_6.facing(p16, p17) -- name: facing
	-- upvalues: (copy) v_u_6
	local v18
	if p17.Magnitude > 0.0001 then
		v18 = p17.Unit
	else
		v18 = v_u_6.UP
	end
	local v19 = v18.Y
	local v20 = (math.abs(v19) > 0.95 and Vector3.new(0, 0, 1) or v_u_6.UP):Cross(v18).Unit
	return CFrame.fromMatrix(p16, v20, v18)
end
function v_u_6.holder(p21, p22) -- name: holder
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v23 = Instance.new("Attachment")
	v23.Parent = v_u_4.Terrain
	v23.WorldCFrame = p21
	v_u_1:AddItem(v23, p22)
	return v23
end
function v_u_6.planePic(p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35) -- name: planePic
	-- upvalues: (copy) v_u_6
	local v36 = p30 + p31 + p32
	local v37 = math.max(v36, 0.05)
	local v38 = {}
	local v39 = {}
	for v40 = 0, 12 do
		local v41 = v40 / 12
		local v42 = v41 * v37
		local v43 = v_u_6.outBack(v42 / math.max(p30, 0.001))
		local v44 = v_u_6.smooth((v42 - p30 - p31) / math.max(p32, 0.001))
		local v45 = NumberSequenceKeypoint.new
		local v46 = p25 + (p26 - p25) * v43 + p26 * 0.1 * v44
		local v47 = math.max(v46, 0.05) / 2
		table.insert(v39, v45(v41, v47))
		local v48 = NumberSequenceKeypoint.new
		local v49 = p29 + (1 - p29) * v44
		local v50 = math.clamp(v49, 0, 1)
		table.insert(v38, v48(v41, v50))
	end
	local v51 = Instance.new("ParticleEmitter")
	v51.Enabled = false
	v51.Texture = p27
	v51.Color = ColorSequence.new(p28)
	v51.LightEmission = p34 or 0
	v51.LightInfluence = 0
	v51.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v51.EmissionDirection = Enum.NormalId.Top
	v51.SpreadAngle = Vector2.zero
	v51.Speed = NumberRange.new(0.01)
	v51.Size = NumberSequence.new(v39)
	v51.Transparency = NumberSequence.new(v38)
	v51.Lifetime = NumberRange.new(v37)
	local v52
	if p35 then
		v52 = NumberRange.new(p35)
	else
		v52 = NumberRange.new(0, 360)
	end
	v51.Rotation = v52
	v51.RotSpeed = NumberRange.new((math.deg(p33)))
	v51.Parent = v_u_6.holder(p24, v37 + 0.2)
	v51:Emit(1)
end
function v_u_6.planeFlip(p53, p54, p55, p56, p57, p58, p59) -- name: planeFlip
	-- upvalues: (copy) v_u_6
	local v60 = Instance.new("ParticleEmitter")
	v60.Enabled = false
	v60.Texture = p55
	v60.FlipbookLayout = p58 or Enum.ParticleFlipbookLayout.Grid4x4
	v60.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v60.Color = ColorSequence.new(p56)
	v60.LightEmission = p59 or 0
	v60.LightInfluence = 0
	v60.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v60.EmissionDirection = Enum.NormalId.Top
	v60.SpreadAngle = Vector2.zero
	v60.Speed = NumberRange.new(0.01)
	v60.Size = NumberSequence.new(p54 / 2)
	v60.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.85, 0), NumberSequenceKeypoint.new(1, 1) })
	v60.Lifetime = NumberRange.new(p57)
	v60.Rotation = NumberRange.new(0)
	v60.Parent = v_u_6.holder(p53, p57 + 0.2)
	v60:Emit(1)
end
function v_u_6.groundPic(p61, p62, p63, p64, p65, p66, p67, p68, p69, p70, p71) -- name: groundPic
	-- upvalues: (copy) v_u_6
	v_u_6.planePic(CFrame.new(p61), p62, p63, p64, p65, p66, p67, p68, p69, p70, p71)
end
function v_u_6.facePic(p72, p73, p74, p75, p76, p77, p78, p79, p80) -- name: facePic
	-- upvalues: (copy) v_u_6
	local v81 = Instance.new("ParticleEmitter")
	v81.Enabled = false
	v81.Texture = p75
	if p78 then
		v81.FlipbookLayout = p78
		v81.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v81.Color = ColorSequence.new(p76)
	v81.LightEmission = p79 or 0
	v81.LightInfluence = 0
	v81.Size = NumberSequence.new(p73 / 2, p74 / 2)
	v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v81.Lifetime = NumberRange.new(p77)
	v81.Speed = NumberRange.new(0)
	if p80 then
		v81.Rotation = NumberRange.new(p80)
	else
		v81.Rotation = NumberRange.new(0, 360)
	end
	v81.ZOffset = 1
	v81.Parent = v_u_6.holder(CFrame.new(p72), p77 + 0.2)
	v81:Emit(1)
end
function v_u_6.spray(p82, p83, p84, p85, p86, p87, p88, p89) -- name: spray
	-- upvalues: (copy) v_u_6
	if p84 > 0 then
		local v90 = p89 or {}
		local v91 = v90.dir or v_u_6.UP
		local v92 = Instance.new("ParticleEmitter")
		v92.Enabled = false
		v92.Texture = p83
		if v90.layout then
			v92.FlipbookLayout = v90.layout
			v92.FlipbookMode = v90.mode or Enum.ParticleFlipbookMode.OneShot
		end
		v92.Color = ColorSequence.new(p88, v90.color2 or p88)
		v92.LightEmission = v90.emission or 0.3
		v92.LightInfluence = 0
		local v93 = v90.grow or 1
		v92.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p85 * 0.5), NumberSequenceKeypoint.new(0.3, p85 * 0.5 * v93), NumberSequenceKeypoint.new(1, p85 * 0.5 * v93 * 0.6) })
		v92.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
		v92.Lifetime = NumberRange.new(p87 * 0.6, p87)
		v92.Speed = NumberRange.new(p86 * 0.35, p86)
		local v94 = v90.spread or 180
		v92.SpreadAngle = Vector2.new(v94, v94)
		v92.Drag = v90.drag or 2
		local v95 = -(v90.gravity or 0)
		v92.Acceleration = Vector3.new(0, v95, 0)
		v92.Rotation = NumberRange.new(0, 360)
		local v96 = v90.spin or 60
		v92.RotSpeed = NumberRange.new(-v96, v96)
		v92.ZOffset = 1
		v92.Parent = v_u_6.holder(v_u_6.facing(p82, v91), p87 + 0.3)
		v92:Emit(p84)
	end
end
function v_u_6.tint(p97, p98, p99, p100, p101, p102, p_u_103) -- name: tint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_7, (copy) v_u_1
	local v_u_104 = Instance.new("ColorCorrectionEffect")
	v_u_104.Name = p97
	v_u_104.Parent = v_u_2
	v_u_5.tween(v_u_104, p101, {
		["TintColor"] = p98,
		["Brightness"] = p99,
		["Contrast"] = p100
	})
	task.delay(p101 + p102, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_104, (copy) p_u_103, (ref) v_u_7
		local v105 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_7
		}
		v_u_5.tween(v_u_104, p_u_103, v105)
	end)
	v_u_1:AddItem(v_u_104, p101 + p102 + p_u_103 + 0.1)
end
local v_u_106 = CFrame.Angles(0.7853981633974483, 0, 0)
function v_u_6.newBar(p107, p108, p109, p110) -- name: newBar
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v111 = {}
	for _ = 1, 2 do
		local v112 = v_u_5.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(0, -500, 0), p107, {
			["transparency"] = p108,
			["material"] = p109
		})
		v_u_1:AddItem(v112, p110 or 8)
		table.insert(v111, v112)
	end
	return v111
end
function v_u_6.placeBar(p113, p114, p115, p116) -- name: placeBar
	-- upvalues: (copy) v_u_6, (copy) v_u_106
	local v117 = p115 - p114
	local v118 = v117.Magnitude
	local v119 = v118 <= 0.0001 and Vector3.new(1, 0, 0) or v117 / v118
	local v120 = v119.Y
	local v121 = v119:Cross(math.abs(v120) > 0.95 and Vector3.new(0, 0, 1) or v_u_6.UP).Unit
	local v122 = v121:Cross(v119)
	local v123 = CFrame.fromMatrix((p114 + p115) / 2, v119, v122, v121)
	local v124 = math.max(v118, 0.05)
	local v125 = Vector3.new(v124, p116, p116)
	p113[1].Size = v125
	p113[1].CFrame = v123
	p113[2].Size = v125
	p113[2].CFrame = v123 * v_u_106
end
function v_u_6.bar(p126, p127, p128, p129, p130, p131) -- name: bar
	-- upvalues: (copy) v_u_6
	local v132 = v_u_6.newBar(p129, p130, p131)
	v_u_6.placeBar(v132, p126, p127, p128)
	return v132
end
function v_u_6.thinBar(p133, p134, p135) -- name: thinBar
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v136 in p133 do
		local v137 = v_u_5.tween
		local v138 = {
			["Size"] = nil,
			["Transparency"] = 1
		}
		local v139 = v136.Size.X
		v138.Size = Vector3.new(v139, 0.05, 0.05)
		local v140 = Enum.EasingStyle.Quad
		local v141
		if p135 then
			v141 = Enum.EasingDirection.In
		else
			v141 = Enum.EasingDirection.Out
		end
		v137(v136, p134, v138, v140, v141)
		v_u_1:AddItem(v136, p134 + 0.05)
	end
end
function v_u_6.fadeBar(p142, p143) -- name: fadeBar
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v144 in p142 do
		v_u_5.tween(v144, p143, {
			["Transparency"] = 1
		})
		v_u_1:AddItem(v144, p143 + 0.05)
	end
end
function v_u_6.wedge(p145, p146, p147, p148) -- name: wedge
	-- upvalues: (copy) v_u_5
	local v149 = Instance.new("WedgePart")
	v149.Anchored = true
	v149.CanCollide = false
	v149.CanQuery = false
	v149.CanTouch = false
	v149.CastShadow = false
	v149.Massless = true
	v149.Size = p145
	v149.Color = p146
	v149.Material = p147 or Enum.Material.Neon
	v149.Transparency = p148 or 0
	v149.CFrame = CFrame.new(0, -500, 0)
	v149.Parent = v_u_5.folder()
	return v149
end
function v_u_6.meshWedge(p150, p151, p152) -- name: meshWedge
	-- upvalues: (copy) v_u_5
	local v153 = v_u_5.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(0, -500, 0), p150, {
		["material"] = p151,
		["transparency"] = p152
	})
	local v154 = Instance.new("SpecialMesh")
	v154.MeshType = Enum.MeshType.Wedge
	v154.Parent = v153
	return v153
end
function v_u_6.shotBlade(p155, p156, p157, p158, p159, p160) -- name: shotBlade
	-- upvalues: (copy) v_u_6
	local v161, v162, v163 = v_u_6.bladeFrames(p155, p156, p157, p158)
	local v164 = {}
	for _, v165 in { v161, v162 } do
		local v166 = v_u_6.meshWedge(p159, p160)
		v166.Size = v163
		table.insert(v164, {
			["p"] = v166,
			["off"] = v165
		})
	end
	return v164
end
function v_u_6.blade(p167, p168, p169) -- name: blade
	-- upvalues: (copy) v_u_6
	return { v_u_6.wedge(Vector3.new(0.1, 0.1, 0.1), p167, p168, p169), v_u_6.wedge(Vector3.new(0.1, 0.1, 0.1), p167, p168, p169) }
end
function v_u_6.bladeFrames(p170, p171, p172, p173) -- name: bladeFrames
	local v174 = p170.LookVector
	local v175 = p170.UpVector
	local v176 = CFrame.fromMatrix(p170.Position + v174 * p171 / 2, v174:Cross(v175), v174, v175)
	local v177 = math.max(p171, 0.05)
	local v178 = p172 / 2
	local v179 = math.max(v178, 0.02)
	local v180 = Vector3.new(p173, v177, v179)
	return v176 * CFrame.new(0, 0, -p172 / 4), v176 * CFrame.new(0, 0, p172 / 4) * CFrame.Angles(0, 3.141592653589793, 0), v180
end
function v_u_6.placeBlade(p181, p182, p183, p184, p185) -- name: placeBlade
	-- upvalues: (copy) v_u_6
	local v186, v187, v188 = v_u_6.bladeFrames(p182, p183, p184, p185)
	p181[1].Size = v188
	p181[2].Size = v188
	p181[1].CFrame = v186
	p181[2].CFrame = v187
end
function v_u_6.formBlade(p189, p190, p191, p192, p_u_193) -- name: formBlade
	-- upvalues: (copy) v_u_6
	local v_u_194 = v_u_6.blade(p191, p192)
	local v_u_195 = { CFrame.new(0, -500, 0), CFrame.new(0, -500, 0) }
	local v_u_196 = Vector3.new(0, 0, 0)
	local v197 = p190.ticks
	local function v208(p198, p199)
		-- upvalues: (copy) p_u_193, (ref) v_u_6, (copy) v_u_195, (ref) v_u_196, (copy) v_u_194
		local v200, v201, v202, v203 = p_u_193(p198, p199)
		local v204, v205, v206 = v_u_6.bladeFrames(v200, v201, v202, v203)
		local v207 = v_u_195
		v_u_195[1] = v204
		v207[2] = v205
		if (v206 - v_u_196).Magnitude > 0.01 then
			v_u_196 = v206
			v_u_194[1].Size = v206
			v_u_194[2].Size = v206
		end
	end
	table.insert(v197, v208)
	for v_u_209, v210 in v_u_194 do
		p189.add(p190, v210, function()
			-- upvalues: (copy) v_u_195, (copy) v_u_209
			return v_u_195[v_u_209]
		end)
	end
	return v_u_194
end
function v_u_6.piece(p211, p212, p213) -- name: piece
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	local v214 = v_u_3:FindFirstChild("EyePieces")
	if v214 then
		v214 = v214:FindFirstChild(p211)
	end
	if not (v214 and v214:IsA("MeshPart")) then
		return nil
	end
	local v215 = v214:Clone()
	local v216 = v214.Size
	local v217 = v214.Size.X
	local v218 = v214.Size.Y
	local v219 = v214.Size.Z
	v215.Size = v216 * (p212 / math.max(v217, v218, v219, 0.01))
	v215.Anchored = true
	v215.CanCollide = false
	v215.CanQuery = false
	v215.CanTouch = false
	v215.Massless = true
	v215.CastShadow = false
	local v220 = v215:FindFirstChildOfClass("SurfaceAppearance")
	if v220 and p213 then
		local v221 = v220.EmissiveStrength
		v220.EmissiveStrength = math.max(v221, p213)
	end
	v215.CFrame = CFrame.new(0, -500, 0)
	v215.Parent = v_u_5.folder()
	return v215
end
function v_u_6.card(p222, p223, p224, p225, p226) -- name: card
	-- upvalues: (copy) v_u_5
	local v227 = v_u_5.part(Vector3.new(p222, 0.05, p222), CFrame.new(0, -500, 0), p224, {
		["transparency"] = 1
	})
	local v228 = {}
	for _, v229 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v230 = Instance.new("SurfaceGui")
		v230.Face = v229
		v230.LightInfluence = 0
		v230.Brightness = p226 or 1.4
		v230.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
		v230.CanvasSize = Vector2.new(256, 256)
		v230.ClipsDescendants = false
		v230.ResetOnSpawn = false
		v230.Parent = v227
		local v231 = Instance.new("ImageLabel")
		v231.BackgroundTransparency = 1
		v231.Size = UDim2.fromScale(1, 1)
		v231.Image = p223
		v231.ImageColor3 = p224
		v231.ImageTransparency = p225 or 0
		v231.Parent = v230
		table.insert(v228, v231)
	end
	return v227, v228
end
function v_u_6.standingCard(p232, p233, p234, p235, p236, p237) -- name: standingCard
	-- upvalues: (copy) v_u_5
	local v238 = v_u_5.part(Vector3.new(p232, p233, 0.05), CFrame.new(0, -500, 0), p235, {
		["transparency"] = 1
	})
	local v239 = {}
	for _, v240 in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local v241 = Instance.new("SurfaceGui")
		v241.Face = v240
		v241.LightInfluence = 0
		v241.Brightness = p237 or 1.4
		v241.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
		local v242 = Vector2.new
		local v243 = p233 * 256 / math.max(p232, 0.01)
		v241.CanvasSize = v242(256, (math.floor(v243)))
		v241.ResetOnSpawn = false
		v241.Parent = v238
		local v244 = Instance.new("ImageLabel")
		v244.BackgroundTransparency = 1
		v244.Size = UDim2.fromScale(1, 1)
		v244.Image = p234
		v244.ImageColor3 = p235
		v244.ImageTransparency = p236 or 0
		v244.Parent = v241
		table.insert(v239, v244)
	end
	return v238, v239
end
function v_u_6.beam(p245, p246, p247, p248, p249, p250, p251) -- name: beam
	local v252 = Instance.new("Beam")
	v252.Attachment0 = p245
	v252.Attachment1 = p246
	v252.Texture = p247
	v252.TextureMode = Enum.TextureMode.Stretch
	v252.TextureLength = 1
	v252.Color = ColorSequence.new(p248)
	v252.LightEmission = p251 or 0
	v252.LightInfluence = 0
	v252.FaceCamera = true
	v252.Segments = 12
	v252.Width0 = p249
	v252.Width1 = p250
	v252.Parent = p245
	return v252
end
return v_u_6