return {
	["new"] = function(p1, p2) -- name: new
		return {
			["burst"] = p1,
			["perSecond"] = p2,
			["buckets"] = {}
		}
	end,
	["take"] = function(p3, p4, p5) -- name: take
		local v6 = p3.buckets[p4]
		if not v6 then
			v6 = {
				["tokens"] = p3.burst,
				["at"] = p5
			}
			p3.buckets[p4] = v6
		end
		local v7 = p3.burst
		local v8 = v6.tokens + (p5 - v6.at) * p3.perSecond
		v6.tokens = math.min(v7, v8)
		v6.at = p5
		if v6.tokens < 1 then
			return false
		end
		v6.tokens = v6.tokens - 1
		return true
	end,
	["forget"] = function(p9, p10) -- name: forget
		p9.buckets[p10] = nil
	end
}