local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("2FD8B5")
local v_u_9 = Color3.fromHex("063A33")
local v_u_10 = Color3.fromRGB(130, 240, 226)
local v_u_11 = Color3.fromRGB(228, 255, 250)
local v_u_12 = Color3.fromRGB(150, 105, 235)
local v_u_13 = Color3.fromRGB(8, 16, 18)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.MeshType.Sphere
local function v_u_23(p16, p17, p18, p19, p20) -- name: blob
	-- upvalues: (copy) v_u_5, (copy) v_u_15, (copy) v_u_1
	local v21 = v_u_5.part(p16, p17, p18, {
		["transparency"] = p19
	})
	local v22 = Instance.new("SpecialMesh")
	v22.MeshType = v_u_15
	v22.Parent = v21
	v_u_1:AddItem(v21, p20 or 6)
	return v21
end
local function v_u_36(p24, p25, p26, p27, p28, p29, p30, p31, p32) -- name: sprites
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	if p27 > 0 then
		local v33 = Instance.new("Attachment")
		v33.WorldPosition = p24
		v33.Parent = v_u_4.Terrain
		local v34 = Instance.new("ParticleEmitter")
		v34.Texture = p25
		v34.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v34.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v34.Color = ColorSequence.new(p26)
		v34.LightEmission = 0.3
		v34.LightInfluence = 0
		v34.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p28 * 0.75, p28 * 0.15), NumberSequenceKeypoint.new(1, p28 * 1.15, p28 * 0.15) })
		v34.Lifetime = NumberRange.new(p29 * 0.8, p29)
		v34.Speed = NumberRange.new(p30 * 0.5, (math.max(p30, 0.01)))
		v34.SpreadAngle = Vector2.new(p31, p31)
		v34.EmissionDirection = Enum.NormalId.Top
		v34.Rotation = NumberRange.new(-25, 25)
		v34.RotSpeed = NumberRange.new(-30, 30)
		local v35 = -p32
		v34.Acceleration = Vector3.new(0, v35, 0)
		v34.Drag = 1.5
		v34.Enabled = false
		v34.Parent = v33
		v34:Emit(p27)
		v_u_1:AddItem(v33, p29 + 0.3)
	end
end
local function v_u_45(p37, p38) -- name: newTomoe
	-- upvalues: (copy) v_u_5, (copy) v_u_13, (copy) v_u_1, (copy) v_u_23
	local v39 = v_u_5.part(Vector3.new(1, 1, 1) * p37, CFrame.identity, v_u_13, {
		["shape"] = nil,
		["material"] = nil,
		["transparency"] = 1,
		["shape"] = Enum.PartType.Ball,
		["material"] = Enum.Material.SmoothPlastic
	})
	v39.Reflectance = 0.15
	v_u_1:AddItem(v39, p38)
	local v40 = v_u_23
	local v41 = p37 * 0.45
	local v42 = p37 * 0.45
	local v43 = p37 * 1.15
	local v44 = v40(Vector3.new(v41, v42, v43), CFrame.identity, v_u_13, 1, p38)
	v44.Material = Enum.Material.SmoothPlastic
	return {
		["head"] = v39,
		["tail"] = v44
	}
end
local function v_u_53(p46, p47, p48, p49, p50) -- name: placeTomoe
	local v51 = p48.Magnitude <= 0.0001 and Vector3.new(1, 0, 0) or p48.Unit
	local v52 = p47 - v51 * p50 * 0.55 + p49 * p50 * 0.22
	p46.head.CFrame = CFrame.new(p47)
	p46.tail.CFrame = CFrame.lookAt(v52, v52 - v51 + p49 * 0.5)
end
return function(p_u_54)
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_23, (copy) v_u_10, (copy) v_u_14, (copy) v_u_45, (copy) v_u_7, (copy) v_u_1, (copy) v_u_4, (copy) v_u_53, (copy) v_u_36, (copy) v_u_11, (copy) v_u_6, (copy) v_u_9, (copy) v_u_2, (copy) v_u_12
	local function v89(p55, p56) -- name: bubbleShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_23, (ref) v_u_10, (ref) v_u_14, (ref) v_u_45, (ref) v_u_7, (ref) v_u_1, (copy) p_u_54, (ref) v_u_4, (ref) v_u_53
		local v_u_57 = p55.size
		local v58 = p55.lite
		local v_u_59 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p56, v_u_8, {
			["transparency"] = 1
		})
		local v_u_60 = v_u_23(Vector3.new(2.5, 2.5, 2.5) * v_u_57, p56, v_u_10, 0.55, 4)
		local v_u_61 = v_u_23(Vector3.new(1.5, 1.5, 1.5) * v_u_57, p56, v_u_8, 0.4, 4)
		local v_u_62 = v_u_23(Vector3.new(0.55, 0.38, 0.2) * v_u_57, p56, v_u_14, 0, 4)
		local v_u_63 = v_u_45(0.72 * v_u_57, 4)
		v_u_63.head.Transparency = 0
		v_u_63.tail.Transparency = 0
		if v58 then
			v_u_63.tail:Destroy()
		end
		local v_u_64 = {
			v_u_60,
			v_u_61,
			v_u_62,
			v_u_63.head,
			v_u_63.tail
		}
		local v_u_65
		if v58 then
			v_u_65 = nil
		else
			local v66 = Instance.new("Attachment")
			v66.Parent = v_u_59
			v_u_65 = Instance.new("ParticleEmitter")
			v_u_65.Texture = v_u_7.TideBubble
			v_u_65.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_65.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_65.Color = ColorSequence.new(v_u_10)
			v_u_65.LightEmission = 0.25
			v_u_65.LightInfluence = 0
			v_u_65.Size = NumberSequence.new(0.42 * v_u_57, 0.15 * v_u_57)
			v_u_65.Lifetime = NumberRange.new(0.3, 0.45)
			v_u_65.Speed = NumberRange.new(1, 3)
			v_u_65.SpreadAngle = Vector2.new(180, 180)
			v_u_65.Rate = 24
			v_u_65.Parent = v66
		end
		v_u_1:AddItem(v_u_59, 4)
		p_u_54.streak(v_u_59, v_u_10, v_u_8, 1.6 * v_u_57, 0.16)
		if p55.mine then
			p_u_54.light(v_u_59, v_u_8, 10 * v_u_57)
		end
		local v_u_67 = false
		return {
			["place"] = function(p68, p69) -- name: place
				-- upvalues: (copy) v_u_59, (copy) v_u_60, (copy) v_u_57, (copy) v_u_61, (ref) v_u_4, (copy) v_u_62, (copy) v_u_63, (ref) v_u_53
				local v70 = p68.Position
				v_u_59.CFrame = p68
				local v71 = p69 * 38
				local v72 = math.sin(v71) * 0.09
				local v73 = v_u_60
				local v74 = v72 + 1
				local v75 = 1 - v72
				local v76 = v72 * 0.5 + 1
				v73.Size = Vector3.new(v74, v75, v76) * 2.5 * v_u_57
				v_u_60.CFrame = p68
				v_u_61.CFrame = p68
				local v77 = v_u_4.CurrentCamera
				local v78
				if v77 then
					local v79 = v77.CFrame.Position - v70
					v78 = v79.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v79.Unit
				else
					v78 = Vector3.new(0, 0, 1)
				end
				local v80 = CFrame.lookAt(v70, v70 + v78)
				local v81 = v80.RightVector
				local v82 = v80.UpVector
				v_u_62.CFrame = CFrame.lookAt(v70 + v78 * 1.05 * v_u_57 + v82 * 0.55 * v_u_57 - v81 * 0.45 * v_u_57, v70 + v78 * 2) * CFrame.Angles(0, 0, 0.6)
				local v83 = p69 * 14
				local v84 = v81 * math.cos(v83) + v82 * math.sin(v83)
				local v85 = -v81 * math.sin(v83) + v82 * math.cos(v83)
				if v_u_63.tail.Parent then
					v_u_53(v_u_63, v70 + v84 * 0.45 * v_u_57 + v78 * 0.2 * v_u_57, v85, -v84, 0.72 * v_u_57)
				else
					v_u_63.head.CFrame = CFrame.new(v70 + v84 * 0.45 * v_u_57 + v78 * 0.2 * v_u_57)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_67, (ref) v_u_65, (copy) v_u_59, (ref) v_u_1, (copy) v_u_64
				if not v_u_67 then
					v_u_67 = true
					local v86 = v_u_65
					if v86 then
						v86.Enabled = false
					end
					local v87 = v_u_59:FindFirstChildWhichIsA("PointLight")
					if v87 then
						v87:Destroy()
					end
					v_u_1:AddItem(v_u_59, 0.5)
					for _, v88 in v_u_64 do
						if not v88.Parent then
							continue
						end
						v88:Destroy()
					end
				end
			end
		}
	end
	local function v95(p90, p91) -- name: bubblePop
		-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (copy) p_u_54, (ref) v_u_8
		local v92 = p90.size
		local v93 = p90.lite
		v_u_36(p91, v_u_7.TideBubble, v_u_10, 1, 2.8 * v92, 0.22, 0, 0, 0)
		v_u_36(p91, v_u_7.TideSplash, v_u_11, v93 and 1 or 3, 2.4 * v92, 0.4, 9 * v92, 60, 30)
		v_u_5.flash(p91, v_u_10, 4 * v92, 0.12)
		p_u_54.pop(p91, v_u_11, 1.4 * v92, 4 * v92, 0.14, 0.45)
		if not v93 then
			local v94 = { v_u_8, v_u_10, v_u_11 }
			p_u_54.chunks(p91, v94, 5, 22, 0.35, 0.5, true, 1.2)
		end
		if p91.Y - p_u_54.FLOOR < 5 then
			v_u_5.ring(p_u_54.ground(p91), v_u_8, p90.ability.radius * 0.7 * v92, 0.3, v_u_7.Ring)
		end
		p_u_54.hitSound(p91)
	end
	local function v_u_114(p_u_96) -- name: tomoeWhirl
		-- upvalues: (ref) v_u_45, (copy) p_u_54, (ref) v_u_53
		local v_u_97 = p_u_96.lite and 3 or 6
		local v_u_98 = {}
		for _ = 1, v_u_97 do
			local v99 = v_u_45(0.8 * p_u_96.size, 1)
			v99.head.Transparency = 0
			v99.tail.Transparency = 0
			table.insert(v_u_98, v99)
		end
		local v_u_100 = p_u_96.feet + Vector3.new(0, 0.6, 0)
		p_u_54.animate(0.38, 0, function(p101)
			-- upvalues: (copy) p_u_96, (copy) v_u_98, (copy) v_u_97, (ref) v_u_53, (copy) v_u_100
			local v102 = (1.8 + 3 * p101 * p101) * p_u_96.size
			for v103, v104 in v_u_98 do
				local v105 = (v103 - 1) / v_u_97 * 3.141592653589793 * 2 + p101 * 9
				local v106 = math.cos(v105)
				local v107 = math.sin(v105)
				local v108 = Vector3.new(v106, 0, v107)
				local v109 = -math.sin(v105)
				local v110 = math.cos(v105)
				local v111 = Vector3.new(v109, 0, v110)
				v_u_53(v104, v_u_100 + v108 * v102, v111, -v108, 0.8 * p_u_96.size)
				local v112 = p101 ^ 3
				v104.head.Transparency = v112
				v104.tail.Transparency = v112
			end
			if p101 >= 1 then
				for _, v113 in v_u_98 do
					v113.head:Destroy()
					v113.tail:Destroy()
				end
			end
		end)
	end
	local function v175(p_u_115, p116, p117) -- name: riptide
		-- upvalues: (copy) p_u_54, (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_14, (ref) v_u_23, (ref) v_u_10, (ref) v_u_11, (ref) v_u_45, (ref) v_u_36, (ref) v_u_53, (ref) v_u_6
		local v_u_118 = p_u_115.size
		local v_u_119 = p_u_115.lite
		local v_u_120 = (p_u_115.ability.width or 10) * v_u_118
		local v_u_121 = p_u_54.flatUnit(p117 - p116)
		local v_u_122 = p_u_54.ground(p116, 0.35) + v_u_121 * 1.5
		local v123 = (p_u_54.ground(p117, 0.35) - v_u_122).Magnitude
		local v_u_124 = math.max(v123, 4)
		local v_u_125 = v_u_122 + v_u_121 * v_u_124
		local v_u_126 = (Vector3.new(0, 1, 0)):Cross(v_u_121)
		local v_u_127 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_122), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_127, 1.26)
		local v_u_128 = Instance.new("Attachment")
		v_u_128.CFrame = CFrame.fromMatrix(Vector3.new(0, 0, 0), v_u_121, v_u_126)
		v_u_128.Parent = v_u_127
		local v_u_129 = Instance.new("Attachment")
		v_u_129.CFrame = CFrame.fromMatrix(Vector3.new(0, 0, 0), v_u_121, v_u_126)
		v_u_129.Parent = v_u_127
		local v_u_130 = {}
		local v_u_131 = {}
		local function v140(p132, p133, p134, p135, p136) -- name: current
			-- upvalues: (copy) v_u_128, (copy) v_u_129, (copy) v_u_127, (copy) v_u_130, (copy) v_u_131
			local v137 = Instance.new("Beam")
			v137.Attachment0 = v_u_128
			v137.Attachment1 = v_u_129
			v137.FaceCamera = false
			v137.Width0 = p132 * 0.8
			v137.Width1 = p132
			v137.Segments = 1
			v137.Color = ColorSequence.new(p134)
			v137.LightEmission = p136
			v137.LightInfluence = 0
			v137.Transparency = NumberSequence.new(p135)
			if p133 then
				v137.Texture = p133
				v137.TextureMode = Enum.TextureMode.Wrap
				v137.TextureLength = p132 * 1.6
				v137.TextureSpeed = 3
			end
			v137.Parent = v_u_127
			local v138 = v_u_130
			table.insert(v138, v137)
			local v139 = v_u_131
			table.insert(v139, p135)
		end
		if not v_u_119 then
			v140(v_u_120 * 1.05, nil, v_u_8, 0.5, 0.5)
		end
		v140(v_u_120 * 1.6, v_u_7.TideWater, v_u_14, 0, 0.2)
		local v141 = v_u_23
		local v142 = v_u_120 * 1.1
		local v143 = 4.6 * v_u_118
		local v144 = 3.4 * v_u_118
		local v_u_145 = v141(Vector3.new(v142, v143, v144), CFrame.new(v_u_122), v_u_10, 0.3, 1.26)
		local v146 = v_u_23
		local v147 = 1.3 * v_u_118
		local v148 = 2.2 * v_u_118
		local v_u_149 = v146(Vector3.new(v_u_120, v147, v148), CFrame.new(v_u_122), v_u_11, 0, 1.26)
		local v_u_150 = {}
		if not v_u_119 then
			for _ = 1, 3 do
				local v151 = v_u_45(1.1 * v_u_118, 1.26)
				v151.head.Transparency = 0
				v151.tail.Transparency = 0
				table.insert(v_u_150, v151)
			end
		end
		p_u_54.alongPath(v_u_122, v_u_125, v_u_119 and 18 or 8, 0.24, function(p152)
			-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) v_u_119, (copy) v_u_118
			v_u_36(p152 + Vector3.new(0, 0.6, 0), v_u_7.TideSplash, v_u_11, v_u_119 and 1 or 2, 3.2 * v_u_118, 0.45, 12 * v_u_118, 35, 40)
		end)
		if not v_u_119 then
			p_u_54.groundLine(v_u_122, v_u_125, v_u_120 * 0.75, v_u_8, 1.3599999999999999, 0.55)
		end
		local v_u_153 = os.clock()
		local v_u_154 = false
		p_u_54.runNow(function()
			-- upvalues: (copy) v_u_153, (copy) v_u_124, (copy) v_u_129, (copy) v_u_121, (copy) v_u_128, (copy) v_u_130, (copy) v_u_131, (ref) v_u_154, (copy) v_u_122, (copy) v_u_145, (copy) v_u_120, (copy) v_u_118, (copy) v_u_126, (copy) v_u_149, (copy) v_u_150, (ref) v_u_53, (ref) v_u_5, (ref) v_u_36, (copy) v_u_125, (ref) v_u_7, (ref) v_u_11, (copy) v_u_119, (ref) v_u_10, (ref) p_u_54, (ref) v_u_8, (ref) v_u_6, (copy) p_u_115, (copy) v_u_127
			local v155 = os.clock() - v_u_153
			local v156 = v155 / 0.24
			local v157 = math.clamp(v156, 0, 1)
			local v158 = v_u_124 * (1 - (1 - v157) ^ 2)
			v_u_129.Position = v_u_121 * v158
			local v159 = (v155 - 0.24 - 0.14) / 0.38
			local v160 = math.clamp(v159, 0, 1)
			v_u_128.Position = v_u_121 * v_u_124 * v160 * v160
			if v160 > 0 then
				for v161, v162 in v_u_130 do
					v162.Width0 = v162.Width1 * 0.8 * (1 - v160 * 0.5)
					v162.Transparency = NumberSequence.new(v_u_131[v161] + (1 - v_u_131[v161]) * v160)
				end
			end
			if not v_u_154 then
				local v163 = v_u_122 + v_u_121 * v158 + Vector3.new(0, 0.45, 0)
				local v164 = v155 / 0.06
				local v165 = math.clamp(v164, 0.3, 1)
				local v166 = v_u_145
				local v167 = v_u_120 * 1.1
				local v168 = 4.6 * v_u_118 * v165
				local v169 = 3.4 * v_u_118
				v166.Size = Vector3.new(v167, v168, v169)
				v_u_145.CFrame = CFrame.fromMatrix(v163, v_u_126, Vector3.new(0, 1, 0))
				v_u_149.CFrame = CFrame.fromMatrix(v163 + Vector3.new(0, 2.1, 0) * v_u_118 * v165 + v_u_121 * 0.6 * v_u_118, v_u_126, Vector3.new(0, 1, 0))
				for v170, v171 in v_u_150 do
					local v172 = v155 * 16 + v170 * 2
					v_u_53(v171, v163 - v_u_121 * (v170 * 0.6 + 2.4) * v_u_118 + v_u_126 * (v170 - 2) * v_u_120 * 0.3 + Vector3.new(0, 0.9, 0) * v_u_118, v_u_121 * math.cos(v172) + Vector3.new(0, 1, 0) * math.sin(v172), -(v_u_121 * -math.sin(v172) + Vector3.new(0, 1, 0) * math.cos(v172)), 1.1 * v_u_118)
				end
				if v157 >= 1 then
					v_u_154 = true
					v_u_5.tween(v_u_145, 0.25, {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = v_u_145.Size * 1.7
					})
					v_u_5.tween(v_u_149, 0.25, {
						["Size"] = nil,
						["Transparency"] = 1,
						["Size"] = v_u_149.Size * 1.8
					})
					v_u_36(v_u_125 + Vector3.new(0, 1, 0), v_u_7.TideSplash, v_u_11, v_u_119 and 2 or 5, 5 * v_u_118, 0.55, 18 * v_u_118, 55, 45)
					if not v_u_119 then
						v_u_36(v_u_125 + Vector3.new(0, 1, 0), v_u_7.TideBubble, v_u_10, 4, 1.6 * v_u_118, 0.6, 8, 90, -6)
						local v173 = { v_u_8, v_u_10, v_u_11 }
						p_u_54.chunks(v_u_125 + Vector3.new(0, 1, 0), v173, 8, 30, 0.5, 0.7, true, 1.3)
					end
					v_u_5.ring(p_u_54.ground(v_u_125), v_u_8, v_u_120 * 0.75, 0.35, v_u_7.Ring)
					p_u_54.burst("Impact", v_u_125 + Vector3.new(0, 1, 0), v_u_8, 1.2 * v_u_118)
					for _, v174 in v_u_150 do
						v_u_5.tween(v174.head, 0.3, {
							["CFrame"] = nil,
							["Transparency"] = 1,
							["CFrame"] = v174.head.CFrame + Vector3.new(0, 4, 0) + v_u_121 * 3
						})
						v_u_5.tween(v174.tail, 0.3, {
							["Transparency"] = 1
						})
					end
					v_u_6.play("Hit", {
						["at"] = v_u_125,
						["volume"] = p_u_115.mine and 0.6 or 0.35
					})
				end
			end
			if v160 < 1 then
				return true
			end
			v_u_127:Destroy()
			v_u_145:Destroy()
			v_u_149:Destroy()
			return false
		end)
	end
	local v_u_176 = {}
	setmetatable(v_u_176, {
		["__mode"] = "k"
	})
	local v_u_177 = {}
	setmetatable(v_u_177, {
		["__mode"] = "k"
	})
	local function v_u_182(p178) -- name: dropWave
		if not p178.done then
			p178.done = true
			for _, v179 in p178.slabs do
				v179:Destroy()
			end
			for _, v180 in p178.foam do
				v180:Destroy()
			end
			for _, v181 in p178.tomoe do
				v181.head:Destroy()
				v181.tail:Destroy()
			end
			p178.holder:Destroy()
		end
	end
	local function v_u_221(p183, p184) -- name: buildWave
		-- upvalues: (copy) p_u_54, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (ref) v_u_7, (ref) v_u_14, (ref) v_u_23, (ref) v_u_11, (ref) v_u_45
		local v185 = p183.lite
		local v186 = p183.ability.radius
		local v187 = p183.feet.X
		local v188 = p_u_54.FLOOR
		local v189 = p183.feet.Z
		local v190 = Vector3.new(v187, v188, v189)
		local v191 = p184.X
		local v192 = p_u_54.FLOOR
		local v193 = p184.Z
		local v194 = Vector3.new(v191, v192, v193)
		local v195
		if (v194 - v190).Magnitude > 1 then
			v195 = p_u_54.flatUnit(v194 - v190)
		else
			v195 = p_u_54.flatUnit(p183.dir)
		end
		local v196 = -v195
		local v197 = (Vector3.new(0, 1, 0)):Cross(v196)
		local v198 = v186 * 2 + 6
		local v199 = v185 and 5 or 8
		local v200 = {}
		for v201 = 1, v199 do
			local v202 = v_u_5.part
			local v203 = Vector3.new(v198, 1, 1)
			local v204 = CFrame.new(v194)
			local v205
			if v201 <= 2 then
				v205 = v_u_8:Lerp(v_u_9, 0.35)
			else
				v205 = v_u_8
			end
			local v206 = v202(v203, v204, v205, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v206, 3.86)
			table.insert(v200, v206)
		end
		local v207 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v194), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v207, 3.86)
		local v208 = {}
		local v209 = {}
		if not v185 then
			local v210 = {}
			for _ = 0, v199 do
				local v211 = Instance.new("Attachment")
				v211.Parent = v207
				table.insert(v210, v211)
			end
			for v212 = 1, v199 do
				local v213 = Instance.new("Beam")
				v213.Attachment0 = v210[v212]
				v213.Attachment1 = v210[v212 + 1]
				v213.FaceCamera = false
				v213.Width0 = v198 * 1.35
				v213.Width1 = v198 * 1.35
				v213.Segments = 1
				v213.Texture = v_u_7.TideWater
				v213.TextureMode = Enum.TextureMode.Wrap
				v213.TextureLength = 14
				v213.TextureSpeed = 2.2
				v213.LightEmission = 0.2
				v213.LightInfluence = 0
				v213.Color = ColorSequence.new(v_u_14)
				v213.Transparency = NumberSequence.new(0.05)
				v213.Parent = v207
				table.insert(v209, v213)
			end
			table.insert(v208, v210)
		end
		local v214 = v185 and 2 or 4
		local v215 = {}
		for _ = 1, v214 do
			local v216 = v_u_23
			local v217 = v198 / v214 + 4
			local v218 = v216(Vector3.new(v217, 2.2, 3.4), CFrame.new(v194), v_u_11, 1, 3.86)
			table.insert(v215, v218)
		end
		local v219 = {}
		if not v185 then
			for _ = 1, 6 do
				local v220 = v_u_45(2.3, 3.86)
				table.insert(v219, v220)
			end
		end
		return {
			["lite"] = nil,
			["base"] = nil,
			["fwd"] = nil,
			["side"] = nil,
			["wide"] = nil,
			["n"] = nil,
			["slabs"] = nil,
			["holder"] = nil,
			["atts"] = nil,
			["beams"] = nil,
			["foam"] = nil,
			["tomoe"] = nil,
			["born"] = nil,
			["crashAt"] = nil,
			["landed"] = false,
			["done"] = false,
			["nextSpray"] = 0,
			["parts"] = nil,
			["cfs"] = nil,
			["lite"] = v185,
			["base"] = v194 + v195 * v186 * 0.75,
			["fwd"] = v196,
			["side"] = v197,
			["wide"] = v198,
			["n"] = v199,
			["slabs"] = v200,
			["holder"] = v207,
			["atts"] = v208,
			["beams"] = v209,
			["foam"] = v215,
			["tomoe"] = v219,
			["born"] = os.clock(),
			["parts"] = {},
			["cfs"] = {}
		}
	end
	local function v_u_243(p222, p223, p224, p225) -- name: curve
		-- upvalues: (copy) p_u_54
		local v226 = p222.n
		local v227 = 24 / v226 * (p223 * 0.88 + 0.12) * (p224 * 0.25 + 1)
		local v228 = p224 * 1.25 + -0.3
		local v229 = p224 * 1.7 + 0.95
		local v230 = v226 - 1
		local v231 = v229 / math.max(v230, 1) * (p223 * 0.6 + 0.4)
		local v232 = p222.base + p222.fwd * (p222.wide * 0.25 * p224)
		local v233 = { v232 }
		for v234 = 0, v226 - 1 do
			local v235 = v228 + v231 * v234
			local v236 = v232 + (p222.fwd * math.sin(v235) + Vector3.new(0, 1, 0) * math.cos(v235)) * v227
			local v237 = v236.Y
			local v238 = p_u_54.FLOOR + 0.3
			local v239 = math.max(v237, v238)
			local v240 = v239 + (p_u_54.FLOOR + 0.3 - v239) * p225
			local v241 = v236.X
			local v242 = v236.Z
			v232 = Vector3.new(v241, v240, v242)
			table.insert(v233, v232)
		end
		return v233
	end
	local function v_u_298(p244) -- name: waveStep
		-- upvalues: (copy) v_u_243, (ref) v_u_53, (ref) v_u_4, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) v_u_182
		if p244.done then
			return false
		end
		local v245 = os.clock()
		local v246 = v245 - p244.born
		local v247 = p244.crashAt
		if not v247 and v246 > 1.52 then
			v247 = v245 - 0.16
			p244.crashAt = v247
		end
		local v248 = v246 / 0.22
		local v249 = math.clamp(v248, 0, 1) - 1
		local v250 = v249 * 2.7 * v249 * v249 + 1 + v249 * 1.7 * v249
		local v251
		if v247 then
			local v252 = (v245 - v247) / 0.16
			v251 = math.clamp(v252, 0, 1)
		else
			v251 = 0
		end
		local v253
		if v247 then
			local v254 = (v245 - v247 - 0.16) / 0.4
			v253 = math.clamp(v254, 0, 1)
		else
			v253 = 0
		end
		local v255 = v_u_243(p244, v250, v251 * v251, v253)
		local v256 = p244.n
		local v257 = p244.side
		local v258 = p244.parts
		local v259 = p244.cfs
		table.clear(v258)
		table.clear(v259)
		local v260 = v253 * 0.68 + 0.32
		local v261 = {}
		for v262 = 1, v256 do
			local v263 = v255[v262]
			local v264 = v255[v262 + 1]
			local v265 = v264 - v263
			local v266 = v265.Magnitude
			local v267 = math.max(v266, 0.1)
			local v268 = v265.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v265.Unit
			v261[v262] = v268
			local v269 = p244.slabs[v262]
			table.insert(v258, v269)
			local v270 = CFrame.fromMatrix
			local v271 = (v263 + v264) / 2
			table.insert(v259, v270(v271, v257, v268:Cross(v257)))
			local v272 = p244.wide * (1 - v262 * 0.06 / v256)
			local v273 = v267 * 1.12
			v269.Size = Vector3.new(v272, 0.9, v273)
			v269.Transparency = v260
		end
		local v274 = v255[v256 + 1]
		local v275 = v261[v256]
		for v276, v277 in p244.foam do
			local v278 = ((v276 - 0.5) / #p244.foam - 0.5) * p244.wide * 0.9
			table.insert(v258, v277)
			local v279 = CFrame.fromMatrix
			local v280 = v274 + v257 * v278 + v275 * 0.6
			table.insert(v259, v279(v280, v257, Vector3.new(0, 1, 0)))
			v277.Transparency = v253 * 0.9 + 0.1
		end
		if #p244.tomoe > 0 then
			local v281 = v256 / 2
			local v282 = math.floor(v281) + 1
			local v283 = v255[v282]
			local v284 = v261[v282]
			local v285 = -v284:Cross(v257)
			for v286, v287 in ipairs(p244.tomoe) do
				local v288 = v246 * 3 + (v286 - 1) / 6 * 3.141592653589793 * 2
				local v289 = v257 * math.cos(v288) + v284 * math.sin(v288)
				local v290 = -v257 * math.sin(v288) + v284 * math.cos(v288)
				v_u_53(v287, v283 + v289 * 5.2 + v285 * 0.9, v290, -v289, 2.3)
				local v291 = 1 - v250 * 3
				local v292 = math.max(v291, v253)
				v287.head.Transparency = v292
				v287.tail.Transparency = v292
			end
		end
		if #v258 > 0 then
			v_u_4:BulkMoveTo(v258, v259, Enum.BulkMoveMode.FireCFrameChanged)
		end
		for _, v293 in p244.atts do
			for v294 = 1, v256 + 1 do
				local v295 = v261[math.min(v294, v256)]
				v293[v294].WorldCFrame = CFrame.fromMatrix(v255[v294] - v295:Cross(v257) * 0.5, v295, v257)
			end
		end
		if v253 > 0 and #p244.beams > 0 then
			local v296 = NumberSequence.new(v253 * 0.95 + 0.05)
			for _, v297 in p244.beams do
				v297.Transparency = v296
			end
		end
		if not p244.lite and (v253 <= 0 and p244.nextSpray <= v246) then
			p244.nextSpray = v246 + 0.07
			v_u_36(v274 + v257 * ((math.random() - 0.5) * p244.wide * 0.8), v_u_7.TideSplash, v_u_11, 1, 4.5, 0.45, 10, 40, 30)
		end
		if v253 < 1 then
			return true
		end
		v_u_182(p244)
		return false
	end
	local function v_u_304(p299, p300) -- name: startWave
		-- upvalues: (copy) v_u_221, (copy) v_u_176, (copy) v_u_182, (copy) v_u_177, (copy) p_u_54, (copy) v_u_298
		local v_u_301 = v_u_221(p299, p300)
		local v302 = p299.caster
		if v302 then
			local v303 = v_u_176[v302]
			if v303 and not v303.crashAt then
				v_u_182(v303)
			end
			v_u_176[v302] = v_u_301
		else
			v_u_177[p299] = v_u_301
		end
		p_u_54.runNow(function()
			-- upvalues: (ref) v_u_298, (copy) v_u_301
			return v_u_298(v_u_301)
		end)
		return v_u_301
	end
	local v_u_305 = 0
	local function v_u_309() -- name: wash
		-- upvalues: (ref) v_u_305, (ref) v_u_2, (ref) v_u_5, (copy) p_u_54, (ref) v_u_14, (ref) v_u_1
		local v306 = os.clock()
		if v306 >= v_u_305 then
			v_u_305 = v306 + 0.7
			local v_u_307 = Instance.new("ColorCorrectionEffect")
			v_u_307.Name = "TidalCrash"
			v_u_307.Parent = v_u_2
			v_u_5.tween(v_u_307, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.15,
				["Saturation"] = 0.2,
				["Brightness"] = 0.04,
				["TintColor"] = Color3.fromRGB(200, 255, 245)
			})
			p_u_54.after(0.12, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_307, (ref) v_u_14
				local v308 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["Brightness"] = 0,
					["TintColor"] = v_u_14
				}
				v_u_5.tween(v_u_307, 0.5, v308)
			end)
			v_u_1:AddItem(v_u_307, 0.7)
		end
	end
	local function v_u_321(p310, p311) -- name: splash
		-- upvalues: (copy) p_u_54, (ref) v_u_5, (ref) v_u_11, (ref) v_u_8, (ref) v_u_10, (ref) v_u_36, (ref) v_u_7, (ref) v_u_12, (ref) v_u_1, (ref) v_u_6, (copy) v_u_309
		local v_u_312 = p310.ability.radius
		local v313 = p310.lite
		local v_u_314 = p_u_54.ground(p311, 0)
		local v315 = p_u_54.ground(p311, 3)
		v_u_5.flash(v315, v_u_11, v_u_312 * 1.1, 0.14)
		p_u_54.pop(v_u_314, v_u_8, v_u_312 * 0.5, v_u_312 * 2.3, 0.5, 0.35)
		p_u_54.pop(v_u_314, v_u_10, v_u_312 * 0.3, v_u_312 * 1.6, 0.3, 0.2)
		v_u_36(p_u_54.ground(p311, 1), v_u_7.TideSplash, v_u_11, v313 and 4 or 10, 8, 0.65, 32, 70, 60)
		v_u_36(p_u_54.ground(p311, 1.5), v_u_7.TideBubble, v_u_10, v313 and 3 or 8, 2.4, 0.75, 14, 90, -8)
		p_u_54.burst("Shockwave", v_u_314 + Vector3.new(0, 0.3, 0), v_u_8, 1.5)
		v_u_5.ring(v_u_314, v_u_8, v_u_312 * 1.25, 0.55, v_u_7.Shockwave)
		p_u_54.after(0.05, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_314, (ref) v_u_11, (copy) v_u_312, (ref) v_u_7
			v_u_5.ring(v_u_314, v_u_11, v_u_312 * 1.45, 0.5, v_u_7.Ring)
		end)
		p_u_54.after(0.1, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_314, (ref) v_u_12, (copy) v_u_312, (ref) v_u_7
			v_u_5.ring(v_u_314, v_u_12, v_u_312 * 1.3, 0.45, v_u_7.SpeedLines)
		end)
		p_u_54.spikes(p_u_54.ground(p311, 1), v_u_11, v313 and 5 or 10, v_u_312 * 1.1, 0.35, Vector3.new(0, 1, 0), 0.7)
		p_u_54.chunks(p_u_54.ground(p311, 1), { v_u_8, v_u_10, v_u_11 }, v313 and 6 or 16, 55, 0.7, 1.1, true, 1.2)
		p_u_54.mark(p311, v_u_8, v_u_312 * 0.95, 2.2, v_u_7.Glow, 0.3)
		local v316 = p_u_54.plate(p_u_54.ground(p311, 0.12), v_u_312 * 0.5, v_u_8, 0.25)
		local v317 = v_u_5.tween
		local v318 = {
			["Size"] = nil,
			["Transparency"] = 1
		}
		local v319 = v_u_312 * 2.4
		local v320 = v_u_312 * 2.4
		v318.Size = Vector3.new(0.12, v319, v320)
		v317(v316, 0.8, v318)
		v_u_1:AddItem(v316, 0.85)
		v_u_6.play("Explosion", {
			["at"] = v_u_314,
			["volume"] = p310.mine and 1 or 0.6
		})
		if p310.mine then
			v_u_5.shake(0.6, 0.5)
			v_u_309()
		end
	end
	local v345 = {
		["tide_tomoe_a"] = {
			["cast"] = function(p322) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_36, (ref) v_u_7, (ref) v_u_11
				local v323 = p322.eye + p322.dir * 1.2
				v_u_5.flash(v323, v_u_8, 3 * p322.size, 0.1)
				if not p322.lite then
					v_u_36(v323, v_u_7.TideSplash, v_u_11, 1, 1.6 * p322.size, 0.25, 4, 40, 10)
				end
			end,
			["shot"] = v89,
			["impact"] = v95,
			["hit"] = function(_, p324, _) -- name: hit
				-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) p_u_54, (ref) v_u_8
				v_u_36(p324, v_u_7.TideSplash, v_u_11, 1, 1.8, 0.3, 4, 40, 20)
				p_u_54.burst("Impact", p324, v_u_8, 0.5)
			end
		},
		["tide_tomoe_e"] = {
			["cast"] = function(p325) -- name: cast
				-- upvalues: (copy) p_u_54, (ref) v_u_8, (copy) v_u_114
				p_u_54.skillCast(p325, v_u_8)
				v_u_114(p325)
			end,
			["windup"] = function(p326, _, p327) -- name: windup
				-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) p_u_54, (ref) v_u_10
				v_u_36(p326.feet + Vector3.new(0, 0.5, 0), v_u_7.TideSplash, v_u_11, p326.lite and 1 or 3, 2.6, 0.4, 7, 50, 30)
				if not p326.lite then
					p_u_54.inward(p326.feet + Vector3.new(0, 1, 0), v_u_10, 4, 6, (math.max(p327, 0.08)))
				end
			end,
			["beam"] = v175,
			["hit"] = function(p328, p329, _) -- name: hit
				-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) p_u_54, (ref) v_u_8
				v_u_36(p329, v_u_7.TideSplash, v_u_11, 1, 2.4, 0.35, 6, 40, 25)
				p_u_54.burst("Impact", p329, v_u_8, 0.6)
				p_u_54.beamHitSound(p328, p329, "Hit")
			end
		},
		["tide_tomoe_r"] = {
			["cast"] = function(p330) -- name: cast
				-- upvalues: (copy) p_u_54, (ref) v_u_8, (copy) v_u_114, (copy) v_u_304
				p_u_54.skillCast(p330, v_u_8, true)
				v_u_114(p330)
				v_u_304(p330, p330.target)
			end,
			["windup"] = function(p331, p332, p333) -- name: windup
				-- upvalues: (copy) v_u_176, (copy) v_u_177, (copy) v_u_304, (copy) p_u_54, (ref) v_u_9, (ref) v_u_7, (ref) v_u_5
				local v334 = p331.caster
				local v335
				if v334 then
					v335 = v_u_176[v334]
				else
					v335 = v_u_177[p331]
				end
				if not v335 or (v335.done or v335.landed) then
					v335 = nil
				end
				local v_u_336 = v335 or v_u_304(p331, p332)
				p_u_54.mark(p332, v_u_9, p331.ability.radius * 0.9, p333 + 0.4, v_u_7.Glow, 0.35)
				local v337 = p_u_54.after
				local v338 = p333 - 0.06
				v337(math.max(v338, 0), function()
					-- upvalues: (copy) v_u_336
					if not (v_u_336.done or v_u_336.crashAt) then
						v_u_336.crashAt = os.clock()
					end
				end)
				if p331.mine then
					v_u_5.shake(0.2, 0.25)
				end
			end,
			["land"] = function(p339, p340) -- name: land
				-- upvalues: (copy) v_u_176, (copy) v_u_177, (copy) v_u_321
				local v341 = p339.caster
				local v342
				if v341 then
					v342 = v_u_176[v341]
				else
					v342 = v_u_177[p339]
				end
				if v342 and not (v342.done or v342.landed) then
					v342.landed = true
					if not v342.crashAt then
						v342.crashAt = os.clock() - 0.08
					end
				end
				v_u_321(p339, p340)
			end,
			["hit"] = function(p343, p344, _) -- name: hit
				-- upvalues: (ref) v_u_36, (ref) v_u_7, (ref) v_u_11, (copy) p_u_54, (ref) v_u_8
				v_u_36(p344, v_u_7.TideSplash, v_u_11, p343.lite and 1 or 2, 3, 0.4, 8, 50, 30)
				p_u_54.burst("Impact", p344, v_u_8, 1.1)
			end
		}
	}
	return v345
end