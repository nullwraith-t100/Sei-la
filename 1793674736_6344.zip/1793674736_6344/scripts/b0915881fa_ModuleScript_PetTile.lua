local v_u_1 = game:GetService("RunService")
local v_u_2 = require(script.Parent.Gamepad)
local v_u_3 = require(script.Parent.PetLooks)
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = require(v4.Shared.Config.Images)
local v_u_6 = require(v4.Shared.Config.Pets)
local v_u_7 = {}
local v_u_8 = v_u_5.Fuse.Splash
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB
local v_u_11 = {
	["Common"] = {
		["color"] = v_u_10(222, 226, 236),
		["specks"] = v_u_10(236, 238, 245)
	},
	["Rare"] = {
		["color"] = v_u_10(36, 186, 255),
		["specks"] = v_u_10(110, 214, 255)
	},
	["Epic"] = {
		["color"] = nil,
		["specks"] = nil,
		["stars"] = true,
		["color"] = v_u_10(176, 64, 255),
		["specks"] = v_u_10(206, 128, 255)
	},
	["Legendary"] = {
		["color"] = v_u_10(255, 178, 26),
		["specks"] = v_u_10(255, 214, 92)
	},
	["Mythic"] = {
		["color"] = v_u_10(255, 40, 112),
		["specks"] = v_u_10(255, 120, 170)
	}
}
local v_u_12 = {
	["color"] = nil,
	["gradient"] = nil,
	["specks"] = nil,
	["stars"] = true,
	["color"] = v_u_9,
	["gradient"] = ColorSequence.new(v_u_10(255, 61, 110), v_u_10(255, 196, 50)),
	["specks"] = v_u_10(255, 214, 90)
}
local v_u_20 = {
	{
		["color"] = nil,
		["gradient"] = nil,
		["specks"] = nil,
		["stars"] = true,
		["color"] = v_u_9,
		["gradient"] = ColorSequence.new(v_u_10(158, 76, 255), v_u_10(64, 8, 140)),
		["specks"] = v_u_10(186, 120, 255)
	},
	{
		["color"] = nil,
		["gradient"] = nil,
		["specks"] = nil,
		["stars"] = true,
		["turning"] = true,
		["color"] = v_u_9,
		["gradient"] = (function(p13) -- name: rainbow
			local v14 = {}
			for v15 = 0, 6 do
				local v16 = ColorSequenceKeypoint.new
				local v17 = v15 / 6
				local v18 = Color3.fromHSV
				local v19 = v15 / 6 * 0.85
				table.insert(v14, v16(v17, v18(v19, p13, 1)))
			end
			return ColorSequence.new(v14)
		end)(0.75),
		["specks"] = v_u_10(255, 255, 255)
	},
	{
		["color"] = nil,
		["gradient"] = nil,
		["specks"] = nil,
		["stars"] = true,
		["color"] = v_u_9,
		["gradient"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_10(222, 22, 48)), ColorSequenceKeypoint.new(0.55, v_u_10(110, 0, 18)), ColorSequenceKeypoint.new(1, v_u_10(16, 0, 4)) }),
		["specks"] = v_u_10(235, 40, 60)
	}
}
local v_u_21 = {
	["color"] = v_u_10(16, 16, 22),
	["specks"] = v_u_10(40, 40, 52)
}
local v_u_22 = {}
setmetatable(v_u_22, {
	["__mode"] = "k"
})
local v_u_23 = {}
local v_u_24 = nil
local function v_u_31(p25, p26, p27, p28) -- name: layer
	local v29 = Instance.new("ImageLabel")
	v29.Name = p26
	v29.BackgroundTransparency = 1
	v29.AnchorPoint = Vector2.new(0.5, 0.5)
	v29.Position = UDim2.fromScale(0.5, 0.47)
	v29.Size = UDim2.fromScale(p27, p27)
	v29.ScaleType = Enum.ScaleType.Fit
	v29.ZIndex = p28
	v29.Interactable = false
	local v30 = Instance.new("UIGradient")
	v30.Enabled = false
	v30.Parent = v29
	v29.Parent = p25
	return v29, v30
end
function v_u_7.strip(p32) -- name: strip
	p32.BackgroundTransparency = 1
	for _, v33 in p32:GetChildren() do
		if v33:IsA("UIStroke") then
			v33.Enabled = false
		else
			if v33.Name ~= "StudPattern" or not v33:IsA("GuiObject") then
				continue
			end
			v33.Visible = false
		end
	end
end
function v_u_7.dress(p_u_34, p35) -- name: dress
	-- upvalues: (copy) v_u_22, (copy) v_u_7, (copy) v_u_31, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5
	local v36 = v_u_22[p_u_34]
	if v36 then
		return v36
	end
	v_u_7.strip(p_u_34)
	local v37 = p_u_34:FindFirstChild("View")
	local v38
	if v37 and v37:IsA("GuiObject") then
		local v39 = v37.ZIndex - 2
		v38 = math.max(1, v39)
	else
		v38 = 1
	end
	local v40, v41 = v_u_31(p_u_34, "Specks", 1.16, v38)
	local v42, v43 = v_u_31(p_u_34, "Splash", 1, v38 + 1)
	local v44 = p35 % 4
	v42.Image = v_u_8
	v42.ImageRectOffset = Vector2.new(v44 * 256, 0)
	v42.ImageRectSize = Vector2.new(256, 256)
	v42.Rotation = p35 * 97 % 360
	v40.Rotation = p35 * 53 % 360
	if v37 and v37:IsA("GuiObject") then
		v37.AnchorPoint = Vector2.new(0.5, 0.5)
		v37.Position = UDim2.fromScale(0.5, 0.42)
		v37.Size = UDim2.fromScale(1.1, 1)
	end
	local v_u_45 = p_u_34:FindFirstChild("Mult")
	local v_u_46
	if v_u_45 and v_u_45:IsA("TextLabel") then
		v_u_45.AnchorPoint = Vector2.new(1, 0.5)
		v_u_45.Position = UDim2.fromScale(0.99, 0.86)
		v_u_45.Size = UDim2.fromScale(0.74, 0.27)
		v_u_45.TextXAlignment = Enum.TextXAlignment.Right
		v_u_45.TextColor3 = v_u_9
		local v47 = v_u_45.ZIndex
		local v48 = v38 + 6
		v_u_45.ZIndex = math.max(v47, v48)
		v_u_46 = Instance.new("ImageLabel")
		v_u_46.Name = "MultIcon"
		v_u_46.BackgroundTransparency = 1
		v_u_46.Image = v_u_5.Icon.Chakra
		v_u_46.ScaleType = Enum.ScaleType.Fit
		v_u_46.AnchorPoint = Vector2.new(1, 0.5)
		v_u_46.Size = UDim2.fromScale(0.26, 0.26)
		v_u_46.ZIndex = v_u_45.ZIndex
		v_u_46.Interactable = false
		Instance.new("UIAspectRatioConstraint").Parent = v_u_46
		v_u_46.Parent = p_u_34
		local function v55() -- name: follow
			-- upvalues: (copy) v_u_45, (copy) p_u_34, (copy) v_u_46
			local v49 = v_u_45.TextBounds.X
			local v50 = v_u_45.AbsoluteSize.X
			local v51 = p_u_34.AbsoluteSize.X
			if v51 > 0 and v50 > 0 then
				local v52 = 0.99 - math.min(v49, v50) / v51
				v_u_46.Position = UDim2.fromScale(v52 - 0.01, 0.86)
				local v53 = v_u_46
				local v54 = v_u_45.Visible
				if v54 then
					v54 = v_u_45.Text ~= ""
				end
				v53.Visible = v54
			end
		end
		v_u_45:GetPropertyChangedSignal("TextBounds"):Connect(v55)
		v_u_45:GetPropertyChangedSignal("Visible"):Connect(v55)
		p_u_34:GetPropertyChangedSignal("AbsoluteSize"):Connect(v55)
		local v56 = v_u_45.TextBounds.X
		local v57 = v_u_45.AbsoluteSize.X
		local v58 = p_u_34.AbsoluteSize.X
		if v58 > 0 and v57 > 0 then
			local v59 = 0.99 - math.min(v56, v57) / v58
			v_u_46.Position = UDim2.fromScale(v59 - 0.01, 0.86)
			local v60 = v_u_45.Visible
			if v60 then
				v60 = v_u_45.Text ~= ""
			end
			v_u_46.Visible = v60
		end
	else
		v_u_45 = nil
		v_u_46 = nil
	end
	local v61 = {
		["root"] = p_u_34,
		["splash"] = v42,
		["specks"] = v40,
		["paint"] = v43,
		["specksPaint"] = v41,
		["mult"] = v_u_45,
		["icon"] = v_u_46
	}
	v_u_22[p_u_34] = v61
	return v61
end
local function v_u_71(p62, p63) -- name: apply
	-- upvalues: (copy) v_u_23, (ref) v_u_24, (copy) v_u_1, (copy) v_u_2, (copy) v_u_8
	p62.splash.ImageColor3 = p63.color
	local v64 = p63.gradient
	if v64 then
		p62.paint.Enabled = true
		p62.paint.Color = v64
		p62.paint.Rotation = 90
	else
		p62.paint.Enabled = false
	end
	if p63.turning then
		v_u_23[p62.paint] = p62.root
		if not v_u_24 then
			v_u_24 = v_u_1.RenderStepped:Connect(function(p65)
				-- upvalues: (ref) v_u_23, (ref) v_u_2, (ref) v_u_24
				local v66 = false
				for v67, v68 in v_u_23 do
					if v67.Parent and v68.Parent then
						v66 = true
						if not v_u_2.shown(v68) then
							continue
						end
						v67.Rotation = (v67.Rotation + p65 * 80) % 360
					else
						v_u_23[v67] = nil
					end
				end
				if not v66 and v_u_24 then
					v_u_24:Disconnect()
					v_u_24 = nil
				end
			end)
		end
	else
		v_u_23[p62.paint] = nil
	end
	local v69 = p62.specks
	local v70 = p63.stars and 2 or p62.splash.Rotation // 90 % 2
	v69.Image = v_u_8
	v69.ImageRectOffset = Vector2.new(v70 * 256, 256)
	v69.ImageRectSize = Vector2.new(256, 256)
	p62.specks.ImageColor3 = p63.specks
	p62.specksPaint.Enabled = false
end
function v_u_7.paint(p72, p73, p74) -- name: paint
	-- upvalues: (copy) v_u_20, (copy) v_u_12, (copy) v_u_11, (copy) v_u_71
	local v75 = v_u_20[p74]
	if not v75 then
		if p73 and p73.pass then
			v75 = v_u_12
		else
			local v76
			if p73 then
				v76 = v_u_11[p73.rarity]
			else
				v76 = nil
			end
			v75 = v76 or v_u_11.Common
		end
	end
	v_u_71(p72, v75)
end
function v_u_7.empty(p77) -- name: empty
	-- upvalues: (copy) v_u_71, (copy) v_u_21
	v_u_71(p77, v_u_21)
end
function v_u_7.tier(p78, p79) -- name: tier
	-- upvalues: (copy) v_u_71, (copy) v_u_20, (copy) v_u_21
	v_u_71(p78, v_u_20[p79] or v_u_21)
end
function v_u_7.tag(p80, p81, p82) -- name: tag
	-- upvalues: (copy) v_u_3
	local v83 = v_u_3.badge(p80, p81)
	if v83 and p82 then
		local v84 = UDim2.fromScale
		local v85 = v83.Size.X.Scale
		v83.Size = v84(math.min(v85, 0.64), v83.Size.Y.Scale)
	end
end
function v_u_7.pet(p86, p87, p88, p89) -- name: pet
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v90 = v_u_7.dress(p86, p89)
	v_u_7.paint(v90, v_u_6.byId[p87], p88)
	local v91 = p86:FindFirstChild("TierGlow_View")
	if v91 then
		v91:Destroy()
	end
	local v92 = p86:FindFirstChild("On")
	local v93 = v_u_7.tag
	local v94 = v92 ~= nil and v92:IsA("GuiObject")
	if v94 then
		v94 = v92.Visible
	end
	v93(p86, p88, v94)
	p86:SetAttribute("Ui-Hover", "Expand")
	p86:SetAttribute("Ui-Hover-Rate", 1.06)
	p86:SetAttribute("Ui-Click", "In")
	p86:SetAttribute("Ui-Click-Rate", 0.92)
end
local v_u_95 = v_u_10(255, 206, 46)
local v_u_96 = v_u_10(70, 40, 0)
function v_u_7.lock(p97, p98) -- name: lock
	-- upvalues: (copy) v_u_95, (copy) v_u_96, (copy) v_u_10, (copy) v_u_5
	for _, v99 in { "Padlock", "LockRing" } do
		local v100 = p97:FindFirstChild(v99)
		if not v100 then
			continue
		end
		v100:Destroy()
	end
	local v101 = Instance.new("Frame")
	v101.Name = "LockRing"
	v101.BackgroundTransparency = 1
	v101.Size = UDim2.fromScale(1, 1)
	v101.ZIndex = 8
	v101.Interactable = false
	local v102 = Instance.new("UICorner")
	v102.CornerRadius = UDim.new(0.12, 0)
	v102.Parent = v101
	local v103 = Instance.new("UIStroke")
	v103.Color = v_u_95
	v103.Thickness = 3
	v103.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v103.Parent = v101
	v101.Parent = p97
	local v104 = Instance.new("Frame")
	v104.Name = "Padlock"
	v104.BackgroundColor3 = v_u_95
	v104.Size = UDim2.fromScale(0.36, 0.36)
	v104.Position = UDim2.fromScale(0.02, p98 and 0.24 or 0.02)
	v104.ZIndex = 9
	v104.Interactable = false
	Instance.new("UIAspectRatioConstraint").Parent = v104
	local v105 = Instance.new("UICorner")
	v105.CornerRadius = UDim.new(0.5, 0)
	v105.Parent = v104
	local v106 = Instance.new("UIStroke")
	v106.Color = v_u_96
	v106.Thickness = 2
	v106.Parent = v104
	local v107 = Instance.new("UIGradient")
	v107.Color = ColorSequence.new(v_u_10(255, 245, 170), v_u_10(255, 170, 20))
	v107.Rotation = 90
	v107.Parent = v104
	local v108 = Instance.new("ImageLabel")
	v108.Name = "Icon"
	v108.BackgroundTransparency = 1
	v108.Image = v_u_5.Icon.Lock
	v108.ScaleType = Enum.ScaleType.Fit
	v108.AnchorPoint = Vector2.new(0.5, 0.5)
	v108.Position = UDim2.fromScale(0.5, 0.5)
	v108.Size = UDim2.fromScale(0.72, 0.72)
	v108.ZIndex = 10
	v108.Interactable = false
	v108.Parent = v104
	v104.Parent = p97
end
return v_u_7