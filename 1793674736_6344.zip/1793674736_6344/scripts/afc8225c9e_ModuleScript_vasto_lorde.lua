local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Bars)
local v_u_6 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v7 = require(script.Parent.Parent.Preload)
local v_u_8 = require(script.Parent.Parent.Parent.Sfx)
local v_u_9 = require(v_u_3.Shared.Config.Textures)
v7.images({ v_u_9.VastoMark, v_u_9.VastoVoid, v_u_9.VastoBolt })
local v_u_10 = Color3.fromHex("FF2E3A")
local v_u_11 = Color3.fromHex("F2EBD9")
local v_u_12 = Color3.fromRGB(150, 0, 18)
local v_u_13 = Color3.fromRGB(10, 4, 6)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Color3.fromRGB(196, 186, 168)
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_18 = Enum.ParticleFlipbookLayout.Grid2x2
local v_u_19 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_51(p20, p21, p22, p23, p24, p25, p26, p27, p28, p29) -- name: groundPic
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v30 = p26 + p27 + p28
	local v31 = math.max(v30, 0.05)
	local v32 = {}
	local v33 = {}
	for v34 = 0, 12 do
		local v35 = v34 / 12
		local v36 = v35 * v31
		local v37 = v36 / math.max(p26, 0.001)
		local v38 = math.clamp(v37, 0, 1) - 1
		local v39 = v38 * 2.7 * v38 * v38 + 1 + v38 * 1.7 * v38
		local v40 = (v36 - p26 - p27) / math.max(p28, 0.001)
		local v41 = math.clamp(v40, 0, 1)
		local v42 = v41 * v41 * (3 - v41 * 2)
		local v43 = NumberSequenceKeypoint.new
		local v44 = p21 + (p22 - p21) * v39 + p22 * 0.1 * v42
		local v45 = math.max(v44, 0.05) / 2
		table.insert(v33, v43(v35, v45))
		local v46 = NumberSequenceKeypoint.new
		local v47 = p25 + (1 - p25) * v42
		local v48 = math.clamp(v47, 0, 1)
		table.insert(v32, v46(v35, v48))
	end
	local v49 = Instance.new("Attachment")
	v49.WorldPosition = p20
	v49.Parent = v_u_4.Terrain
	local v50 = Instance.new("ParticleEmitter")
	v50.Enabled = false
	v50.Texture = p23
	v50.Color = ColorSequence.new(p24)
	v50.LightEmission = 0
	v50.LightInfluence = 0
	v50.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v50.EmissionDirection = Enum.NormalId.Top
	v50.SpreadAngle = Vector2.zero
	v50.Speed = NumberRange.new(0.01)
	v50.Size = NumberSequence.new(v33)
	v50.Transparency = NumberSequence.new(v32)
	v50.Lifetime = NumberRange.new(v31)
	v50.Rotation = NumberRange.new(0, 360)
	v50.RotSpeed = NumberRange.new((math.deg(p29)))
	v50.Parent = v49
	v50:Emit(1)
	v_u_1:AddItem(v49, v31 + 0.2)
end
local function v_u_62(p52, p53, p54, p55, p56, p57, p58, p59) -- name: facePic
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v60 = Instance.new("Attachment")
	v60.WorldPosition = p52
	v60.Parent = v_u_4.Terrain
	local v61 = Instance.new("ParticleEmitter")
	v61.Enabled = false
	v61.Texture = p55
	if p58 then
		v61.FlipbookLayout = p58
		v61.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v61.Color = ColorSequence.new(p56)
	v61.LightEmission = p59 or 0
	v61.LightInfluence = 0
	v61.Size = NumberSequence.new(p53 / 2, p54 / 2)
	v61.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.75, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v61.Lifetime = NumberRange.new(p57)
	v61.Speed = NumberRange.new(0)
	v61.Rotation = NumberRange.new(0, 360)
	v61.ZOffset = 1
	v61.Parent = v60
	v61:Emit(1)
	v_u_1:AddItem(v60, p57 + 0.2)
end
local function v_u_72(p63, p64, p65, p66) -- name: crackles
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_18, (copy) v_u_10, (copy) v_u_12, (copy) v_u_1
	if p64 > 0 then
		local v67 = Instance.new("Attachment")
		v67.WorldPosition = p63
		v67.Parent = v_u_4.Terrain
		local v68 = Instance.new("ParticleEmitter")
		v68.Enabled = false
		v68.Texture = v_u_9.VastoBolt
		v68.FlipbookLayout = v_u_18
		v68.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v68.Color = ColorSequence.new(v_u_10, v_u_12)
		v68.LightEmission = 0.5
		v68.LightInfluence = 0
		v68.Size = NumberSequence.new(p65 * 0.35, p65 * 0.5)
		v68.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
		v68.Lifetime = NumberRange.new(0.2, 0.32)
		v68.Speed = NumberRange.new(0)
		v68.Rotation = NumberRange.new(0, 360)
		v68.ZOffset = 1.5
		v68.Parent = v67
		for _ = 1, p64 do
			local v69 = math.random() - 0.5
			local v70 = math.random() - 0.5
			local v71 = math.random() - 0.5
			v67.WorldPosition = p63 + Vector3.new(v69, v70, v71) * p66 * 2
			v68:Emit(1)
		end
		v_u_1:AddItem(v67, 0.6)
	end
end
local function v_u_81(p73, p74, p75, p76, p77, p_u_78) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_14, (copy) v_u_1
	local v_u_79 = Instance.new("ColorCorrectionEffect")
	v_u_79.Name = "VastoLorde"
	v_u_79.Parent = v_u_2
	v_u_6.tween(v_u_79, p76, {
		["TintColor"] = p73,
		["Brightness"] = p74,
		["Contrast"] = p75
	})
	task.delay(p76 + p77, function()
		-- upvalues: (ref) v_u_6, (copy) v_u_79, (copy) p_u_78, (ref) v_u_14
		local v80 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_14
		}
		v_u_6.tween(v_u_79, p_u_78, v80)
	end)
	v_u_1:AddItem(v_u_79, p76 + p77 + p_u_78 + 0.1)
end
local function v_u_87(p82, p83, p84, p85) -- name: wedge
	-- upvalues: (copy) v_u_6
	local v86 = Instance.new("WedgePart")
	v86.Anchored = true
	v86.CanCollide = false
	v86.CanQuery = false
	v86.CanTouch = false
	v86.CastShadow = false
	v86.Size = p82
	v86.Color = p83
	v86.Material = p84
	v86.Transparency = p85
	v86.CFrame = CFrame.new(0, -500, 0)
	v86.Parent = v_u_6.folder()
	return v86
end
local function v_u_142(p88, p89, p90) -- name: newMask
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_19, (copy) v_u_11, (copy) v_u_16, (copy) v_u_13, (copy) v_u_10, (copy) v_u_87, (copy) v_u_1
	local v_u_91 = {}
	local v_u_92 = {}
	local v93 = v_u_3:FindFirstChild("EyePieces")
	if v93 then
		v93 = v93:FindFirstChild("w7_vasto_lorde")
	end
	if v93 and v93:IsA("MeshPart") then
		local v94 = v93:Clone()
		local v95 = v93.Size
		local v96 = v93.Size.X
		local v97 = v93.Size.Y
		local v98 = v93.Size.Z
		v94.Size = v95 * (p88 / math.max(v96, v97, v98, 0.01))
		v94.Anchored = true
		v94.CanCollide = false
		v94.CanQuery = false
		v94.CanTouch = false
		v94.CastShadow = false
		v94.Transparency = p90
		local v99 = v94:FindFirstChildOfClass("SurfaceAppearance")
		if v99 then
			local v100 = v99.EmissiveStrength
			v99.EmissiveStrength = math.max(v100, 6)
		end
		v94.CFrame = CFrame.new(0, -500, 0)
		v94.Parent = v_u_6.folder()
		table.insert(v_u_91, v94)
		local v101 = v_u_19
		table.insert(v_u_92, v101)
	else
		local v102 = p88 / 2
		local v103 = v_u_6.part
		local v104 = v102 * 1
		local v105 = v102 * 1.15
		local v106 = v102 * 0.7
		local v107 = Vector3.new(v104, v105, v106)
		local v108 = {
			["material"] = v_u_16,
			["transparency"] = p90
		}
		local v109 = v103(v107, CFrame.new(0, -500, 0), v_u_11, v108)
		local v110 = Instance.new("SpecialMesh")
		v110.MeshType = Enum.MeshType.Sphere
		v110.Parent = v109
		table.insert(v_u_91, v109)
		local v111 = CFrame.identity
		table.insert(v_u_92, v111)
		for _, v112 in { -1, 1 } do
			local v113 = v_u_6.part
			local v114 = v102 * 0.3
			local v115 = v102 * 0.08
			local v116 = v102 * 0.1
			local v117 = Vector3.new(v114, v115, v116)
			local v118 = {
				["material"] = v_u_16,
				["transparency"] = p90
			}
			local v119 = v113(v117, CFrame.new(0, -500, 0), v_u_13, v118)
			table.insert(v_u_91, v119)
			local v120 = CFrame.new(v112 * 0.22 * v102, v102 * 0.1, v102 * -0.33) * CFrame.Angles(0, 0, v112 * 0.3)
			table.insert(v_u_92, v120)
			local v121 = v_u_6.part
			local v122 = v102 * 0.07
			local v123 = v102 * 0.5
			local v124 = v102 * 0.06
			local v125 = v121(Vector3.new(v122, v123, v124), CFrame.new(0, -500, 0), v_u_10, {
				["transparency"] = p90
			})
			table.insert(v_u_91, v125)
			local v126 = CFrame.new
			local v127 = v112 * 0.24 * v102
			local v128 = v102 * -0.25
			local v129 = v102 * -0.33
			table.insert(v_u_92, v126(v127, v128, v129))
			local v130 = v_u_87
			local v131 = v102 * 0.16
			local v132 = v102 * 1.3
			local v133 = v102 * 0.4
			local v134 = v130(Vector3.new(v131, v132, v133), v_u_11, v_u_16, p90)
			table.insert(v_u_91, v134)
			local v135 = CFrame.new(v112 * 0.55 * v102, v102 * 0.85, v102 * 0.1) * CFrame.Angles(0.2, 0, -v112 * 0.45)
			table.insert(v_u_92, v135)
		end
	end
	for _, v136 in v_u_91 do
		v_u_1:AddItem(v136, p89)
	end
	return {
		["parts"] = v_u_91,
		["offs"] = v_u_92,
		["place"] = function(p137) -- name: place
			-- upvalues: (copy) v_u_91, (copy) v_u_92
			for v138, v139 in v_u_91 do
				v139.CFrame = p137 * v_u_92[v138]
			end
		end,
		["fade"] = function(p140) -- name: fade
			-- upvalues: (copy) v_u_91, (ref) v_u_6, (ref) v_u_1
			for _, v141 in v_u_91 do
				v_u_6.tween(v141, p140, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v141, p140 + 0.05)
			end
		end
	}
end
return function(p_u_143)
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_13, (copy) v_u_16, (copy) v_u_11, (copy) v_u_62, (copy) v_u_9, (copy) v_u_14, (copy) v_u_17, (copy) v_u_72, (copy) v_u_51, (copy) v_u_12, (copy) v_u_1, (copy) v_u_5, (copy) v_u_87, (copy) v_u_8, (copy) v_u_15, (copy) v_u_81, (copy) v_u_142, (copy) v_u_4
	local v174 = {
		["vasto_lorde_a"] = {
			["cast"] = function(p144) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (copy) p_u_143, (ref) v_u_13, (ref) v_u_16
				local v145 = p144.size
				local v146 = p144.eye + p144.dir * 1.1
				v_u_6.flash(v146, v_u_10, 2.8 * v145, 0.1)
				p_u_143.pop(v146, v_u_13, 1.2 * v145, 0.2 * v145, 0.1, 0, v_u_16)
			end,
			["shot"] = function(p147, p148) -- name: hornShot
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_13, (ref) v_u_16, (ref) v_u_11, (copy) p_u_143
				local v149 = p147.size
				local v150 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), p148, v_u_10, {
					["transparency"] = 1
				})
				local v151 = v_u_6.part(Vector3.new(0.75, 0.75, 0.75) * v149, p148, v_u_13, {
					["shape"] = Enum.PartType.Ball,
					["material"] = v_u_16
				})
				local v152 = v_u_6.part(Vector3.new(1.4, 1.4, 1.4) * v149, p148, v_u_10, {
					["shape"] = nil,
					["transparency"] = 0.3,
					["shape"] = Enum.PartType.Ball
				})
				local v153 = {
					{
						["p"] = v151,
						["off"] = CFrame.identity
					},
					{
						["p"] = v152,
						["off"] = CFrame.identity
					}
				}
				for _, v154 in { -1, 1 } do
					local v155 = v_u_6.part
					local v156 = 0.14 * v149
					local v157 = 0.32 * v149
					local v158 = 1.5 * v149
					local v159 = v155(Vector3.new(v156, v157, v158), p148, v_u_11, {
						["material"] = v_u_16
					})
					local v160 = Instance.new("SpecialMesh")
					v160.MeshType = Enum.MeshType.Wedge
					v160.Parent = v159
					local v161 = {
						["p"] = v159,
						["off"] = CFrame.new(v154 * 0.62 * v149, 0.1 * v149, -0.25 * v149) * CFrame.Angles(0, v154 * 0.22, 0)
					}
					table.insert(v153, v161)
					if p147.lite then
						continue
					end
					local v162 = Instance.new("Attachment")
					local v163 = 0.1 * v149
					local v164 = -0.6 * v149
					v162.Position = Vector3.new(0, v163, v164)
					v162.Parent = v159
					local v165 = Instance.new("Attachment")
					local v166 = -0.1 * v149
					local v167 = -0.6 * v149
					v165.Position = Vector3.new(0, v166, v167)
					v165.Parent = v159
					local v168 = Instance.new("Trail")
					v168.Attachment0 = v162
					v168.Attachment1 = v165
					v168.Color = ColorSequence.new(v_u_10, v_u_13)
					v168.Transparency = NumberSequence.new(0, 1)
					v168.Lifetime = 0.2
					v168.LightEmission = 0.4
					v168.LightInfluence = 0
					v168.FaceCamera = true
					v168.WidthScale = NumberSequence.new(1, 0.3)
					v168.Parent = v159
				end
				p_u_143.streak(v150, v_u_10, v_u_13, 1.1 * v149, 0.14)
				local v169 = {}
				if not p147.lite then
					p_u_143.light(v150, v_u_10, 9 * v149)
				end
				return p_u_143.assemble(v150, v153, {}, 0, 0, v169, 0.14, 16)
			end,
			["impact"] = function(p170, p171) -- name: hornBurst
				-- upvalues: (ref) v_u_62, (ref) v_u_9, (ref) v_u_14, (ref) v_u_17, (ref) v_u_6, (ref) v_u_10, (ref) v_u_72, (ref) v_u_51, (copy) p_u_143, (ref) v_u_12
				local v172 = p170.size
				local v173 = 5.2 * v172
				v_u_62(p171, v173 * 0.7, v173, v_u_9.VastoVoid, v_u_14, 0.38, v_u_17, 0)
				v_u_6.flash(p171, v_u_10, 4 * v172, 0.14)
				v_u_72(p171, p170.lite and 1 or 3, 4 * v172, 1.2 * v172)
				if not p170.lite then
					v_u_51(p_u_143.ground(p171, 0.15), 1 * v172, 5.5 * v172, v_u_9.VastoMark, v_u_12, 0, 0.1, 0.05, 0.3, 1.5)
				end
			end,
			["hit"] = p_u_143.simpleHit(v_u_10, 0.55)
		}
	}
	local function v_u_189(p175, p176, p177, p178, p179, p180) -- name: strip
		-- upvalues: (copy) p_u_143, (ref) v_u_6, (ref) v_u_16, (ref) v_u_1
		local v181 = p_u_143.ground(p175, p180)
		local v182 = p_u_143.ground(p176, p180)
		local v183 = (v182 - v181).Magnitude
		if v183 >= 0.5 then
			local v184 = {
				["material"] = v_u_16
			}
			local v185 = v_u_6.part(Vector3.new(p177, 0.05, v183), p_u_143.aimAt((v181 + v182) / 2, v182 - v181), p178, v184)
			local v186 = v_u_6.tween
			local v187 = {
				["Transparency"] = 1,
				["Size"] = nil
			}
			local v188 = p177 * 0.2
			v187.Size = Vector3.new(v188, 0.05, v183)
			v186(v185, p179, v187, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v185, p179 + 0.05)
		end
	end
	v174.vasto_lorde_e = {
		["cast"] = function(p190) -- name: cast
			-- upvalues: (copy) p_u_143, (ref) v_u_10, (ref) v_u_6, (ref) v_u_13, (ref) v_u_9
			local v191 = p190.size
			p_u_143.skillCast(p190, v_u_10, false, true)
			v_u_6.ring(p190.feet, v_u_13, 7 * v191, 0.3, v_u_9.Shockwave)
			p_u_143.glint(p190.eye, v_u_10, 3.5 * v191, 0.18)
		end,
		["windup"] = function(p192, p193, p194) -- name: windup
			-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_72
			local v195 = p192.size
			v_u_6.flash(p193, v_u_10, 3.2 * v195, (math.max(p194, 0.1)))
			v_u_72(p193, p192.lite and 1 or 3, 3 * v195, 0.8 * v195)
		end,
		["beam"] = function(p_u_196, p197, p198) -- name: beam
			-- upvalues: (copy) p_u_143, (ref) v_u_5, (ref) v_u_11, (ref) v_u_16, (ref) v_u_10, (ref) v_u_87, (ref) v_u_1, (ref) v_u_12, (ref) v_u_72, (ref) v_u_6, (ref) v_u_62, (ref) v_u_9, (ref) v_u_14, (ref) v_u_17, (ref) v_u_8, (copy) v_u_189, (ref) v_u_13, (ref) v_u_15, (ref) v_u_51
			local v_u_199 = p_u_196.size
			local v_u_200 = p_u_196.lite
			local v201 = p198 - p197
			local v202 = v201.X
			local v203 = v201.Z
			local v204 = Vector3.new(v202, 0, v203)
			local v_u_205 = v204.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v204.Unit
			local v_u_206 = v_u_205:Cross(Vector3.new(0, 1, 0))
			local v_u_207 = p197 + v_u_205 * 0.6 - Vector3.new(0, 0.5, 0) * v_u_199
			local v_u_208 = p_u_143.ground(p198, 2.4 * v_u_199)
			local v_u_209 = (v_u_208 - v_u_207).Magnitude
			if v_u_209 >= 2 then
				local v_u_210 = math.random() < 0.5 and -1 or 1
				local v_u_211 = v_u_200 and 4 or 7
				local v_u_212 = 2.3 * v_u_199
				local v_u_213 = {}
				local v_u_214 = {}
				local v_u_215 = {}
				for v216 = 1, v_u_211 do
					local v217 = v_u_5.new
					local v218 = v_u_11
					local v219 = v_u_16
					table.insert(v_u_213, v217(v218, 0, v219))
					if not v_u_200 then
						local v220 = v_u_5.new
						local v221 = v_u_10
						table.insert(v_u_215, v220(v221, 0.72))
					end
					if v_u_200 or v216 >= v_u_211 then
						continue
					end
					local v222 = v_u_5.new
					local v223 = v_u_10
					table.insert(v_u_214, v222(v223))
				end
				local v_u_224 = v_u_87(Vector3.new(0.1, 0.1, 0.1), v_u_11, v_u_16, 0)
				local v_u_225 = v_u_87(Vector3.new(0.1, 0.1, 0.1), v_u_11, v_u_16, 0)
				local v_u_226 = { v_u_224, v_u_225 }
				for _, v227 in { v_u_213, v_u_214, v_u_215 } do
					for _, v228 in v227 do
						for _, v229 in v228 do
							table.insert(v_u_226, v229)
						end
					end
				end
				for _, v230 in v_u_226 do
					v_u_1:AddItem(v230, 1.6)
				end
				local function v_u_263(p231) -- name: shape
					-- upvalues: (copy) v_u_213, (copy) v_u_211, (copy) v_u_207, (copy) v_u_208, (copy) v_u_209, (copy) v_u_206, (copy) v_u_210, (copy) v_u_212, (copy) v_u_205, (ref) v_u_5, (copy) v_u_215, (copy) v_u_214, (copy) v_u_199, (copy) v_u_224, (copy) v_u_225
					for v232, v233 in v_u_213 do
						local v234 = (v232 - 1) / v_u_211 * p231
						local v235 = v232 / v_u_211 * p231
						local v236 = math.clamp(v234, 0, 1) * 3.141592653589793
						local v237 = math.sin(v236)
						local v238 = v_u_207:Lerp(v_u_208, v234) + Vector3.new(0, 1, 0) * v237 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v237 * v_u_209 * 0.035
						local v239 = math.clamp(v235, 0, 1) * 3.141592653589793
						local v240 = math.sin(v239)
						local v241 = v_u_207:Lerp(v_u_208, v235) + Vector3.new(0, 1, 0) * v240 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v240 * v_u_209 * 0.035
						local v242 = v_u_212 * (1 - (v234 + v235) / 2 * 0.82)
						local v243 = v241 - v238
						local v244
						if v243.Magnitude > 0.0001 then
							v244 = v243.Unit
						else
							v244 = v_u_205
						end
						local v245 = v244 * v242 * 0.125
						v_u_5.place(v233, v238 - v245, v241 + v245, v242)
						local v246 = v_u_215[v232]
						if v246 then
							v_u_5.place(v246, v238 - v245, v241 + v245, v242 * 1.4)
						end
						local v247 = v_u_214[v232]
						if not v247 then
							continue
						end
						v_u_5.place(v247, v241 - v244 * 0.15 * v_u_199, v241 + v244 * 0.15 * v_u_199, v_u_212 * (1 - v235 * 0.82) * 1.08)
					end
					local v248 = math.clamp(p231, 0, 1) * 3.141592653589793
					local v249 = math.sin(v248)
					local v250 = v_u_207:Lerp(v_u_208, p231) + Vector3.new(0, 1, 0) * v249 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v249 * v_u_209 * 0.035
					local v251 = p231 - 0.05
					local v252 = math.max(v251, 0)
					local v253 = math.clamp(v252, 0, 1) * 3.141592653589793
					local v254 = math.sin(v253)
					local v255 = (v250 - (v_u_207:Lerp(v_u_208, v252) + Vector3.new(0, 1, 0) * v254 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v254 * v_u_209 * 0.035)).Unit
					local v256 = v_u_212 * (1 - p231 * 0.82)
					local v257 = v255:Cross(Vector3.new(0, 1, 0))
					local v258 = v257.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v257.Unit
					local v259 = v256 * 2.2
					local v260 = CFrame.fromMatrix(v250 + v255 * v259 / 2, v258, v255)
					local v261 = v_u_224
					local v262 = v256 / 2
					v261.Size = Vector3.new(v256, v259, v262)
					v_u_225.Size = v_u_224.Size
					v_u_224.CFrame = v260 * CFrame.new(0, 0, -v256 / 4)
					v_u_225.CFrame = v260 * CFrame.new(0, 0, v256 / 4) * CFrame.Angles(0, 3.141592653589793, 0)
				end
				p_u_143.animate(0.13, p_u_196.skip, function(p264)
					-- upvalues: (copy) v_u_263
					local v265 = v_u_263
					local v266 = math.clamp(p264, 0, 1) - 1
					local v267 = v266 * 2.7 * v266 * v266 + 1 + v266 * 1.7 * v266
					v265((math.max(v267, 0.02)))
				end)
				p_u_143.after(0.53, function()
					-- upvalues: (copy) v_u_211, (copy) v_u_200, (copy) v_u_207, (copy) v_u_208, (copy) v_u_209, (copy) v_u_206, (copy) v_u_210, (ref) p_u_143, (ref) v_u_11, (ref) v_u_12, (copy) v_u_199, (ref) v_u_72, (copy) v_u_212, (copy) v_u_226, (ref) v_u_6, (ref) v_u_62, (ref) v_u_9, (ref) v_u_14, (ref) v_u_17, (ref) v_u_10, (ref) v_u_8, (copy) p_u_196
					for v268 = 1, v_u_211, v_u_200 and 3 or 2 do
						local v269 = (v268 - 0.5) / v_u_211
						local v270 = math.clamp(v269, 0, 1) * 3.141592653589793
						local v271 = math.sin(v270)
						local v272 = v_u_207:Lerp(v_u_208, v269) + Vector3.new(0, 1, 0) * v271 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v271 * v_u_209 * 0.035
						p_u_143.chunks(v272, { v_u_11, v_u_11, v_u_12 }, v_u_200 and 2 or 4, 16 * v_u_199, 0.6 * v_u_199, 0.9, false, 0.6)
						v_u_72(v272, 1, 4 * v_u_199, v_u_212 * (1 - (v268 - 0.5) / v_u_211 * 0.82) * 0.6)
					end
					for _, v273 in v_u_226 do
						v_u_6.tween(v273, 0.2, {
							["Transparency"] = 1
						})
					end
					local v274 = v_u_207:Lerp(v_u_208, 1) + Vector3.new(0, 0.00000000000000012246469, 0) * v_u_209 * 0.05 + v_u_206 * v_u_210 * 1.2246467991473532e-16 * v_u_209 * 0.035
					local v275 = 9 * v_u_199
					v_u_62(v274, v275 * 0.7, v275, v_u_9.VastoVoid, v_u_14, 0.45, v_u_17, 0)
					v_u_6.flash(v274, v_u_10, 7 * v_u_199, 0.18)
					v_u_8.play("Crit", {
						["at"] = v274,
						["volume"] = p_u_196.mine and 0.6 or 0.3
					})
				end)
				v_u_6.flash(v_u_207, v_u_10, 5 * v_u_199, 0.15)
				local v276 = 2.4 * v_u_199
				v_u_189(v_u_207, v_u_208, v276, v_u_13, 1.4, 0.06)
				v_u_189(v_u_207, v_u_208, v276 * 0.3, v_u_12, 1.1, 0.12)
				for v277 = 1, v_u_200 and 1 or 4 do
					local v278 = p_u_143.ground
					local v279 = v277 / 4.5
					local v280 = math.clamp(v279, 0, 1) * 3.141592653589793
					local v281 = math.sin(v280)
					local v282 = v278(v_u_207:Lerp(v_u_208, v279) + Vector3.new(0, 1, 0) * v281 * v_u_209 * 0.05 + v_u_206 * v_u_210 * v281 * v_u_209 * 0.035, 0.3)
					if not v_u_200 then
						local v283 = { v_u_11, v_u_15, v_u_13 }
						p_u_143.chunks(v282 + v_u_206 * 2 * v_u_199, v283, 3, 18 * v_u_199, 0.6 * v_u_199, 0.9, false, 0.8)
						local v284 = { v_u_11, v_u_15, v_u_13 }
						p_u_143.chunks(v282 - v_u_206 * 2 * v_u_199, v284, 3, 18 * v_u_199, 0.6 * v_u_199, 0.9, false, 0.8)
						v_u_51(v282, 2 * v_u_199, 7 * v_u_199, v_u_9.VastoMark, v_u_12, 0, 0.12, 0.25, 0.4, 0)
					end
					v_u_6.ring(v282, v_u_13, 4.5 * v_u_199, 0.3, v_u_9.Shockwave)
				end
				for v285 = 1, v_u_200 and 2 or 5 do
					local v286 = v_u_206 * (math.random() - 0.5) * 6 * v_u_199 + Vector3.new(0, 1, 0) * (math.random() - 0.3) * 3 * v_u_199
					local v287 = v_u_5.rod
					local v288 = v_u_207 + v286
					local v289 = v_u_208 + v286
					local v290 = (0.12 + math.random() * 0.15) * v_u_199
					local v291
					if v285 % 2 == 0 then
						v291 = v_u_11
					else
						v291 = v_u_10
					end
					local v292 = v287(v288, v289, v290, v291)
					v_u_5.thin(v292, 0.25 + math.random() * 0.15)
				end
				if p_u_196.mine then
					v_u_6.shake(0.3, 0.3)
				end
			end
		end,
		["hit"] = function(p293, p294, _) -- name: hit
			-- upvalues: (copy) p_u_143, (ref) v_u_10, (ref) v_u_11, (ref) v_u_72
			p_u_143.burst("Impact", p294, v_u_10, 0.7)
			if not p293.lite then
				p_u_143.spikes(p294, v_u_11, 3, 5, 0.18, Vector3.new(0, 1, 0), 0.6)
				v_u_72(p294, 1, 3, 0.6)
			end
		end
	}
	local v_u_295 = {}
	setmetatable(v_u_295, {
		["__mode"] = "k"
	})
	v174.vasto_lorde_r = {
		["cast"] = function(p296) -- name: cast
			-- upvalues: (copy) p_u_143, (ref) v_u_10, (ref) v_u_72, (ref) v_u_6, (ref) v_u_81
			local v297 = p296.size
			p_u_143.skillCast(p296, v_u_10, true, true)
			p_u_143.glint(p296.eye, v_u_10, 5 * v297, 0.25)
			v_u_72(p296.eye, p296.lite and 1 or 4, 3.5 * v297, 1 * v297)
			if p296.mine then
				v_u_6.shake(0.12, 0.15)
				v_u_81(Color3.fromRGB(255, 205, 205), -0.04, 0.12, 0.15, 0.7, 0.6)
			end
		end,
		["windup"] = function(p298, p299, p300) -- name: windup
			-- upvalues: (copy) p_u_143, (ref) v_u_142, (ref) v_u_6, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1, (ref) v_u_13, (ref) v_u_16, (copy) v_u_295, (ref) v_u_51, (ref) v_u_12, (ref) v_u_72, (ref) v_u_8
			local v301 = p298.size
			local v_u_302 = p298.ability.radius * v301
			local v303 = math.max(p300, 0.15)
			local v304 = p_u_143.ground(p299, 0)
			local v305 = v304 + Vector3.new(0, 1, 0) * v_u_302 * 1.15
			local v_u_306 = v_u_142(v_u_302 * 0.75, v303 + 2.5, 1)
			local v307 = p299 - p298.origin
			local v308 = v307.X
			local v309 = v307.Z
			local v310 = Vector3.new(v308, 0, v309)
			local v311 = v310.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v310.Unit
			local v_u_312 = CFrame.new(v305) * CFrame.lookAt(Vector3.new(0, 0, 0), Vector3.new(-0, -1, -0), v311)
			v_u_306.place(v_u_312)
			for _, v313 in v_u_306.parts do
				v_u_6.tween(v313, v303 * 0.8, {
					["Transparency"] = 0.05
				})
			end
			local v314 = Instance.new("Attachment")
			v314.WorldPosition = v305 + Vector3.new(0, 1, 0) * v_u_302 * 0.1
			v314.Parent = v_u_4.Terrain
			local v315 = Instance.new("ParticleEmitter")
			v315.Enabled = false
			v315.Texture = v_u_9.Glow
			v315.Color = ColorSequence.new(v_u_10)
			v315.LightEmission = 0.6
			v315.LightInfluence = 0
			v315.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_302 * 1.5), NumberSequenceKeypoint.new(0.15, v_u_302 * 1.8), NumberSequenceKeypoint.new(1, v_u_302 * 1.9) })
			v315.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.7, 0.2), NumberSequenceKeypoint.new(1, 1) })
			v315.Lifetime = NumberRange.new(v303 + 1)
			v315.Speed = NumberRange.new(0)
			v315.ZOffset = -4
			v315.Parent = v314
			v315:Emit(1)
			v_u_1:AddItem(v314, v303 + 1.2)
			local v316 = v305 - Vector3.new(0, 1, 0) * v_u_302 * 0.35
			local v_u_317 = v_u_6.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(v316), v_u_10, {
				["shape"] = nil,
				["transparency"] = 0.25,
				["shape"] = Enum.PartType.Ball
			})
			local v_u_318 = v_u_6.part(Vector3.new(0.3, 0.3, 0.3), CFrame.new(v316), v_u_13, {
				["shape"] = Enum.PartType.Ball,
				["material"] = v_u_16
			})
			v_u_1:AddItem(v_u_317, v303 + 1)
			v_u_1:AddItem(v_u_318, v303 + 1)
			v_u_295[p298] = {
				["mask"] = v_u_306,
				["at"] = v305,
				["brow"] = v316,
				["shell"] = v_u_317,
				["core"] = v_u_318,
				["born"] = os.clock()
			}
			p_u_143.animate(v303, 0, function(p319)
				-- upvalues: (copy) v_u_306, (copy) v_u_312, (copy) v_u_302, (copy) v_u_317, (copy) v_u_318
				local v320 = v_u_306.place
				local v321 = v_u_312
				local v322 = CFrame.new
				local v323 = math.clamp(p319, 0, 1) - 1
				v320(v321 * v322(0, 0, (1 - (v323 * 2.7 * v323 * v323 + 1 + v323 * 1.7 * v323)) * v_u_302 * 0.3))
				local v324 = v_u_302 * 0.35
				local v325 = math.clamp(p319, 0, 1)
				local v326 = v324 * (v325 * v325 * (3 - v325 * 2)) + 0.5
				v_u_317.Size = Vector3.new(1, 1, 1) * v326
				v_u_318.Size = Vector3.new(1, 1, 1) * v326 * 0.6
			end)
			v_u_51(v304 + Vector3.new(0, 0.08, 0), v_u_302 * 0.5, v_u_302 * 2.6, v_u_9.Glow, v_u_13, 0.3, v303, 0.4, 0.8, 0)
			v_u_51(v304 + Vector3.new(0, 0.14, 0), v_u_302 * 0.4, v_u_302 * 2.2, v_u_9.VastoMark, v_u_12, 0, v303 + 0.1, 0.3, 0.6, 0.5)
			p_u_143.inward(v316, v_u_10, p298.lite and 4 or 10, v_u_302 * 0.7, v303)
			v_u_72(v316, p298.lite and 2 or 6, 6 * v301, v_u_302 * 0.25)
			v_u_8.play("EyeActivate", {
				["at"] = v316,
				["volume"] = p298.mine and 0.6 or 0.3
			})
		end,
		["land"] = function(p_u_327, p328) -- name: land
			-- upvalues: (copy) p_u_143, (copy) v_u_295, (ref) v_u_10, (ref) v_u_9, (ref) v_u_5, (ref) v_u_13, (ref) v_u_16, (ref) v_u_1, (ref) v_u_62, (ref) v_u_14, (ref) v_u_17, (ref) v_u_6, (ref) v_u_72, (ref) v_u_51, (ref) v_u_12, (ref) v_u_11, (ref) v_u_15, (ref) v_u_8, (ref) v_u_81
			local v_u_329 = p_u_327.size
			local v_u_330 = p_u_327.lite
			local v_u_331 = p_u_327.ability.radius * v_u_329
			local v_u_332 = p_u_143.ground(p328, 0)
			local v_u_333 = v_u_295[p_u_327]
			v_u_295[p_u_327] = nil
			local v334
			if v_u_333 then
				v334 = v_u_333.brow
			else
				v334 = v_u_332 + Vector3.new(0, 1, 0) * v_u_331 * 0.8
			end
			p_u_143.glowBeam(v334, v_u_332, v_u_10, v_u_331 * 0.45, 0.35, v_u_9.Beam)
			local v335 = v_u_5.rod(v334, v_u_332, v_u_331 * 0.16, v_u_13, 0, v_u_16)
			v_u_5.thin(v335, 0.45, true)
			local v336 = v_u_5.rod(v334, v_u_332, v_u_331 * 0.3, v_u_10, 0.35)
			v_u_5.thin(v336, 0.4)
			if v_u_333 then
				v_u_333.shell:Destroy()
				v_u_333.core:Destroy()
			end
			local v_u_337 = p_u_143.ball(v_u_332, v_u_10, v_u_331 * 0.4, 0, Enum.Material.ForceField)
			local v_u_338 = p_u_143.ball(v_u_332, v_u_13, v_u_331 * 0.3, 0, v_u_16)
			v_u_1:AddItem(v_u_337, 1.9)
			v_u_1:AddItem(v_u_338, 1.9)
			p_u_143.animate(1.4, 0, function(p339)
				-- upvalues: (copy) v_u_337, (copy) v_u_331, (copy) v_u_338
				local v340 = p339 / 0.25
				local v341 = math.clamp(v340, 0, 1) - 1
				local v342 = v341 * 2.7 * v341 * v341 + 1 + v341 * 1.7 * v341
				local v343 = (p339 * 1.4 - 0.9) / 0.5
				local v344 = math.clamp(v343, 0, 1)
				local v345 = v344 * v344 * (3 - v344 * 2)
				local v346 = v_u_337
				local v347 = v_u_331 * 2.1 * v342 * (1 - v345 * 0.6)
				v346.Size = Vector3.new(1, 1, 1) * math.max(v347, 0.1)
				local v348 = v_u_337
				local v349 = (p339 * 1.4 - 0.3) / 1.1
				local v350 = math.clamp(v349, 0, 1)
				v348.Transparency = v350 * v350 * (3 - v350 * 2)
				local v351 = v_u_338
				local v352 = v_u_331 * 1.5 * v342 * (1 - v345)
				v351.Size = Vector3.new(1, 1, 1) * math.max(v352, 0.1)
				if p339 >= 1 then
					v_u_337:Destroy()
					v_u_338:Destroy()
				end
			end)
			local v353 = v_u_332 + Vector3.new(0, 1, 0) * v_u_331 * 0.35
			local v354 = v_u_331 * 2.4
			v_u_62(v353, v354 * 0.7, v354, v_u_9.VastoVoid, v_u_14, 0.7, v_u_17, 0)
			v_u_6.flash(v_u_332 + Vector3.new(0, 2, 0), v_u_14, v_u_331 * 1.2, 0.18)
			for v355 = 1, v_u_330 and 2 or 6 do
				p_u_143.after(v355 * 0.13, function()
					-- upvalues: (ref) v_u_72, (copy) v_u_332, (copy) v_u_331, (copy) v_u_329
					local v356 = math.random() * 3.141592653589793 * 2
					local v357 = math.random() * 0.9
					local v358 = math.cos(v356) * math.cos(v357)
					local v359 = math.sin(v357)
					local v360 = math.sin(v356) * math.cos(v357)
					v_u_72(v_u_332 + Vector3.new(v358, v359, v360) * v_u_331 * 0.95, 2, 9 * v_u_329, 2 * v_u_329)
				end)
			end
			v_u_51(v_u_332 + Vector3.new(0, 0.2, 0), v_u_331 * 0.5, v_u_331 * 3.4, v_u_9.VastoMark, v_u_12, 0, 0.18, 0.5, 0.8, 0.8)
			v_u_51(v_u_332 + Vector3.new(0, 0.1, 0), v_u_331 * 0.8, v_u_331 * 2.6, v_u_9.CrackGlow, v_u_12, 0.1, 0.12, 1, 0.8, 0)
			v_u_51(v_u_332 + Vector3.new(0, 0.05, 0), v_u_331 * 1, v_u_331 * 3, v_u_9.Glow, v_u_13, 0.4, 0.2, 0.9, 0.8, 0)
			v_u_6.ring(v_u_332, v_u_13, v_u_331 * 1.5, 0.5, v_u_9.Shockwave)
			v_u_6.ring(v_u_332 + Vector3.new(0, 0.1, 0), v_u_10, v_u_331 * 1.25, 0.65, v_u_9.Ring)
			p_u_143.burst("Shockwave", v_u_332 + Vector3.new(0, 0.3, 0), v_u_10, v_u_331 / 14)
			v_u_72(v_u_332 + Vector3.new(0, 1, 0) * v_u_331 * 0.3, v_u_330 and 4 or 14, 9 * v_u_329, v_u_331 * 0.6)
			if not v_u_330 then
				local v361 = {
					v_u_11,
					v_u_15,
					v_u_13,
					v_u_11
				}
				p_u_143.chunks(v_u_332, v361, 14, 45 * v_u_329, 1.1 * v_u_329, 1.6, false, 1)
				p_u_143.spikes(v_u_332 + Vector3.new(0, 2, 0), v_u_10, 10, v_u_331 * 1.1, 0.35, Vector3.new(0, 1, 0), 1.4, true)
			end
			v_u_8.play("Explosion", {
				["at"] = v_u_332,
				["volume"] = p_u_327.mine and 1 or 0.5
			})
			if p_u_327.mine then
				v_u_6.shake(0.55, 0.5)
				v_u_81(Color3.fromRGB(255, 170, 170), 0.15, 0.25, 0.03, 0.1, 0.5)
			end
			if v_u_333 then
				local v_u_362 = v_u_333.mask
				p_u_143.after(0.35, function()
					-- upvalues: (ref) v_u_72, (copy) v_u_333, (copy) v_u_330, (copy) v_u_329, (copy) v_u_331, (ref) p_u_143, (ref) v_u_11, (ref) v_u_10, (ref) v_u_6, (copy) v_u_362
					v_u_72(v_u_333.at, v_u_330 and 2 or 8, 8 * v_u_329, v_u_331 * 0.3)
					if not v_u_330 then
						local v363 = { v_u_11, v_u_11, v_u_10 }
						p_u_143.chunks(v_u_333.at, v363, 8, 22 * v_u_329, 0.9 * v_u_329, 1.2, false, 0.4)
					end
					v_u_6.flash(v_u_333.at, v_u_10, v_u_331 * 0.8, 0.2)
					v_u_362.fade(0.35)
				end)
			end
			p_u_143.after(0.9, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_332, (ref) v_u_13, (copy) v_u_331, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (copy) p_u_327
				v_u_6.ring(v_u_332, v_u_13, v_u_331 * 0.9, 0.4, v_u_9.Ring)
				v_u_6.flash(v_u_332 + Vector3.new(0, 1, 0), v_u_12, v_u_331 * 0.6, 0.25)
				v_u_8.play("Crit", {
					["at"] = v_u_332,
					["volume"] = p_u_327.mine and 0.6 or 0.3
				})
			end)
		end,
		["hit"] = function(p364, p365, _) -- name: hit
			-- upvalues: (copy) p_u_143, (ref) v_u_10, (ref) v_u_72
			p_u_143.burst("Impact", p365, v_u_10, 0.8)
			if not p364.lite then
				v_u_72(p365, 1, 3.5, 0.8)
			end
		end
	}
	return v174
end