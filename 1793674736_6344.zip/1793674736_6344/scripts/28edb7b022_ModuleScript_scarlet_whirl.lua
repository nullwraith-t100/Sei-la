local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("C8101E")
local v_u_9 = Color3.fromHex("FF5A64")
local v_u_10 = Color3.fromRGB(255, 34, 46)
local v_u_11 = Color3.fromRGB(255, 214, 218)
local v_u_12 = Color3.fromRGB(18, 3, 6)
local v_u_13 = Color3.fromRGB(90, 0, 12)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.PartType.Cylinder
local function v_u_27(p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_31(p28, p29) -- name: fadePicture
	for _, v30 in p28:GetChildren() do
		if not v30:IsA("Decal") then
			continue
		end
		v30.Transparency = p29
	end
end
return function(p_u_32)
	-- upvalues: (copy) v_u_4, (copy) v_u_27, (copy) v_u_1, (copy) v_u_31, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_11, (copy) v_u_8, (copy) v_u_12, (copy) v_u_15, (copy) v_u_9, (copy) v_u_13, (copy) v_u_2, (copy) v_u_14, (copy) v_u_6
	local function v_u_49(p_u_33, p_u_34, p_u_35, p36, p37, p_u_38, p_u_39, p40) -- name: spinOut
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_32, (ref) v_u_31
		local v_u_41 = p40 or 0
		local v_u_42 = v_u_27(p_u_33, p_u_34, p36, p37, v_u_41)
		v_u_1:AddItem(v_u_42, p_u_38 + 0.1)
		p_u_32.animate(p_u_38, 0, function(p43)
			-- upvalues: (copy) p_u_34, (copy) p_u_35, (copy) v_u_42, (copy) p_u_33, (copy) p_u_38, (copy) p_u_39, (ref) v_u_31, (copy) v_u_41
			local v44 = 1 - (1 - p43) ^ 3
			local v45 = p_u_34 + (p_u_35 - p_u_34) * v44
			local v46 = v_u_42
			local v47 = v45 * 2
			local v48 = v45 * 2
			v46.Size = Vector3.new(v47, 0.05, v48)
			v_u_42.CFrame = p_u_33 * CFrame.Angles(0, p43 * p_u_38 * p_u_39, 0)
			v_u_31(v_u_42, v_u_41 + (1 - v_u_41) * p43 ^ 1.5)
			if p43 >= 1 then
				v_u_42:Destroy()
			end
		end)
	end
	local function v_u_55(p50, p51, p52, p53) -- name: slashBeam
		-- upvalues: (ref) v_u_7
		local v54 = Instance.new("Beam")
		v54.Attachment0 = p50
		v54.Attachment1 = p51
		v54.Texture = v_u_7.Beam
		v54.TextureMode = Enum.TextureMode.Stretch
		v54.TextureLength = 1
		v54.LightEmission = p53
		v54.LightInfluence = 0
		v54.Brightness = 2
		v54.Color = ColorSequence.new(p52)
		v54.FaceCamera = true
		v54.Segments = 1
		v54.Width0 = 0
		v54.Width1 = 0
		v54.Parent = p50.Parent
		return v54
	end
	local function v_u_88(p_u_56, p_u_57, p58, p59, p60, p_u_61, p_u_62) -- name: slash
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (copy) v_u_55, (copy) p_u_32
		local v_u_63 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_56), p59, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_63, p_u_61 + p_u_62 + 0.3)
		local v_u_64 = Instance.new("Attachment")
		v_u_64.Parent = v_u_63
		local v_u_65 = Instance.new("Attachment")
		v_u_65.Parent = v_u_63
		local v_u_66 = Instance.new("Attachment")
		v_u_66.Parent = v_u_63
		local v_u_67 = {}
		local v_u_68 = {}
		local v69 = v_u_55(v_u_64, v_u_65, p59, 0.75)
		table.insert(v_u_67, v69)
		local v70 = v_u_55(v_u_65, v_u_66, p59, 0.75)
		table.insert(v_u_67, v70)
		table.insert(v_u_68, p58)
		table.insert(v_u_68, p58)
		if p60 then
			local v71 = p58 * 0.38
			local v72 = v_u_55(v_u_64, v_u_65, p60, 1)
			table.insert(v_u_67, v72)
			local v73 = v_u_55(v_u_65, v_u_66, p60, 1)
			table.insert(v_u_67, v73)
			table.insert(v_u_68, v71)
			table.insert(v_u_68, v71)
		end
		local v_u_74 = os.clock()
		p_u_32.runNow(function()
			-- upvalues: (copy) v_u_63, (copy) v_u_74, (copy) p_u_61, (copy) p_u_62, (copy) p_u_56, (copy) p_u_57, (copy) v_u_64, (copy) v_u_65, (copy) v_u_66, (copy) v_u_67, (copy) v_u_68
			if not v_u_63.Parent then
				return false
			end
			local v75 = os.clock() - v_u_74
			local v76 = p_u_61
			local v77 = v75 / math.max(v76, 0.001)
			local v78 = 1 - (1 - math.clamp(v77, 0, 1)) ^ 3
			local v79 = p_u_62
			local v80 = (v75 - p_u_61) / math.max(v79, 0.001)
			local v81 = math.clamp(v80, 0, 1)
			local v82 = p_u_56:Lerp(p_u_57, v78)
			local v83 = p_u_56:Lerp(p_u_57, v78 * v81 * 0.8)
			v_u_64.WorldPosition = v83
			v_u_65.WorldPosition = v83:Lerp(v82, 0.62)
			v_u_66.WorldPosition = v82
			local v84 = (1 - v81) ^ 1.4 * (v78 * 0.45 + 0.55)
			for v85, v86 in v_u_67 do
				local v87 = v_u_68[v85] * v84
				if v85 % 2 == 1 then
					v86.Width0 = 0
					v86.Width1 = v87
				else
					v86.Width0 = v87
					v86.Width1 = 0
				end
			end
			if v81 < 1 then
				return true
			end
			v_u_63:Destroy()
			return false
		end)
	end
	local function v_u_100(p_u_89, p90, p_u_91, p92, p_u_93) -- name: cross
		-- upvalues: (ref) v_u_4, (copy) v_u_88, (ref) v_u_10, (ref) v_u_11, (copy) p_u_32
		local v94 = v_u_4.CurrentCamera
		local v95, v96
		if v94 then
			v95 = v94.CFrame.RightVector
			v96 = v94.CFrame.UpVector
		else
			v96 = Vector3.new(0, 1, 0)
			v95 = Vector3.new(1, 0, 0)
		end
		local v97 = (math.random() - 0.5) * 0.5
		local v98 = (v95 + v96 * (1 + v97)).Unit * p90 / 2
		local v_u_99 = (v95 * -1 + v96 * (1 - v97)).Unit * p90 / 2
		v_u_88(p_u_89 - v98, p_u_89 + v98, p_u_91, v_u_10, v_u_11, 0.05, p_u_93)
		p_u_32.after(p92, function()
			-- upvalues: (ref) v_u_88, (copy) p_u_89, (copy) v_u_99, (copy) p_u_91, (ref) v_u_10, (ref) v_u_11, (copy) p_u_93
			v_u_88(p_u_89 - v_u_99, p_u_89 + v_u_99, p_u_91, v_u_10, v_u_11, 0.05, p_u_93)
		end)
	end
	local function v_u_111(p101, p102, p103) -- name: newSaw
		-- upvalues: (ref) v_u_27, (ref) v_u_7, (ref) v_u_8, (ref) v_u_5, (ref) v_u_12, (ref) v_u_15, (ref) v_u_1, (ref) v_u_10
		local v104 = v_u_27(CFrame.identity, p101, v_u_7.ScarletSaw, v_u_8, 0)
		local v105 = v_u_5.part
		local v106 = p101 * 1.3
		local v107 = p101 * 1.3
		local v108 = v105(Vector3.new(0.14, v106, v107), CFrame.identity, v_u_12, {
			["shape"] = v_u_15,
			["material"] = Enum.Material.SmoothPlastic
		})
		v108.Reflectance = 0
		v_u_1:AddItem(v104, p103)
		v_u_1:AddItem(v108, p103)
		local v109 = {
			["blades"] = nil,
			["body"] = nil,
			["glow"] = nil,
			["blades"] = v104,
			["body"] = v108
		}
		if not p102 then
			local v110 = v_u_27(CFrame.identity, p101 * 1.45, v_u_7.Glow, v_u_10, 0.4)
			v_u_1:AddItem(v110, p103)
			v109.glow = v110
		end
		return v109
	end
	local function v_u_117(p112, p113, p114) -- name: placeSaw
		local v115 = p113 * CFrame.Angles(0, p114, 0)
		p112.blades.CFrame = v115 * CFrame.new(0, 0.09, 0)
		p112.body.CFrame = v115 * CFrame.Angles(0, 0, 1.5707963267948966)
		local v116 = p112.glow
		if v116 then
			v116.CFrame = v115 * CFrame.new(0, -0.12, 0)
		end
	end
	local function v137(p118, p119) -- name: sawShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) v_u_111, (copy) p_u_32, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (copy) v_u_117, (ref) v_u_4
		local v120 = p118.size
		local v_u_121 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p119, v_u_8, {
			["transparency"] = 1
		})
		local v_u_122 = v_u_111(1.6 * v120, p118.lite, 3)
		if not p118.lite then
			p_u_32.streak(v_u_121, v_u_11, v_u_9, 0.45 * v120, 0.09)
		end
		p_u_32.streak(v_u_121, v_u_10, v_u_13, 2.1 * v120, 0.14)
		if p118.mine then
			p_u_32.light(v_u_121, v_u_8, 9 * v120)
		end
		v_u_1:AddItem(v_u_121, 3)
		local v_u_123 = false
		return {
			["place"] = function(p124, p125) -- name: place
				-- upvalues: (copy) v_u_121, (ref) v_u_117, (copy) v_u_122, (ref) p_u_32, (ref) v_u_4
				v_u_121.CFrame = p124
				local v126 = v_u_117
				local v127 = v_u_122
				local v128 = p124.Position
				local v129 = p_u_32.facing
				local v130 = Vector3.new(0, 1, 0)
				local v131 = v_u_4.CurrentCamera
				local v132
				if v131 then
					local v133 = v131.CFrame.Position - v128
					v132 = v133.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v133.Unit
				else
					v132 = Vector3.new(0, 0, 1)
				end
				v126(v127, v129(v128, (v130 + v132 * 0.9).Unit), -p125 * 38)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_123, (copy) v_u_121, (ref) v_u_1, (copy) v_u_122
				if not v_u_123 then
					v_u_123 = true
					local v134 = v_u_121:FindFirstChildWhichIsA("PointLight")
					if v134 then
						v134:Destroy()
					end
					v_u_1:AddItem(v_u_121, 0.16)
					local v135 = v_u_122
					v135.blades:Destroy()
					v135.body:Destroy()
					local v136 = v135.glow
					if v136 then
						v136:Destroy()
					end
				end
			end
		}
	end
	local function v147(p138, p139) -- name: sawImpact
		-- upvalues: (copy) v_u_49, (copy) p_u_32, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (copy) v_u_100
		local v140 = p138.size
		local v141 = v_u_49
		local v142 = p_u_32.facing
		local v143 = Vector3.new(0, 1, 0)
		local v144 = v_u_4.CurrentCamera
		local v145
		if v144 then
			local v146 = v144.CFrame.Position - p139
			v145 = v146.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v146.Unit
		else
			v145 = Vector3.new(0, 0, 1)
		end
		v141(v142(p139, (v143 + v145 * 0.9).Unit), 1.6 * v140, 4 * v140, v_u_7.ScarletSaw, v_u_10, 0.2, -34)
		v_u_5.flash(p139, v_u_8, 4.5 * v140, 0.12)
		p_u_32.pop(p139, v_u_9, 1 * v140, 2.6 * v140, 0.12, 0.25)
		p_u_32.burst("Impact", p139, v_u_8, 0.85 * v140)
		if not p138.lite then
			v_u_100(p139, 3.6 * v140, 0.75 * v140, 0.03, 0.12)
			p_u_32.spikes(p139, v_u_9, 4, 3.4 * v140, 0.14, nil, nil, true)
		end
		p_u_32.hitSound(p139)
	end
	local function v197(p148, p_u_149) -- name: sickleShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_11, (copy) p_u_32, (ref) v_u_13, (ref) v_u_4
		local v_u_150 = p148.size
		local v151 = 2 * v_u_150
		local v152 = p148.lite
		local v_u_153 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p_u_149, v_u_8, {
			["transparency"] = 1
		})
		local v_u_154 = {}
		local function v173(p155, p156, p157, p158, p159, p160) -- name: seg
			-- upvalues: (copy) v_u_150, (ref) v_u_5, (copy) p_u_149, (ref) v_u_1, (copy) v_u_154
			local v161 = (p156 - 1) / 4 * 2.792526803190927
			local v162 = p156 / 4 * 2.792526803190927
			local v163 = math.cos(v161) * p155
			local v164 = math.sin(v161) * p155
			local v165 = Vector3.new(v163, 0, v164)
			local v166 = math.cos(v162) * p155
			local v167 = math.sin(v162) * p155
			local v168 = Vector3.new(v166, 0, v167)
			local v169 = (v168 - v165).Magnitude + 0.12 * v_u_150
			local v170 = v_u_5.part(Vector3.new(p157, p158, v169), p_u_149, p159, {
				["transparency"] = p160
			})
			v_u_1:AddItem(v170, 3)
			local v171 = v_u_154
			local v172 = {
				["p"] = v170,
				["off"] = CFrame.lookAt((v165 + v168) / 2, v168)
			}
			table.insert(v171, v172)
			return v170
		end
		local v_u_174 = v_u_153
		for v175 = 1, 4 do
			local v176 = (0.95 - (v175 - 1) / 3 * 0.72) * v_u_150
			local v177 = 0.16 * v_u_150
			local v178
			if v175 == 4 then
				v178 = v_u_9
			else
				v178 = v_u_8
			end
			local v179 = v173(v151, v175, v176, v177, v178, 0)
			if v175 ~= 4 then
				v179 = v_u_153
			end
			if v152 then
				v_u_153 = v179
			else
				v173(v151 + v176 * 0.5, v175, 0.14 * v_u_150, 0.22 * v_u_150, v_u_11, 0.15)
				v_u_153 = v179
			end
		end
		p_u_32.streak(v_u_153, v_u_9, v_u_8, 0.55 * v_u_150, v152 and 0.14 or 0.22)
		p_u_32.streak(v_u_174, v_u_8, v_u_13, 1.2 * v_u_150, 0.1)
		if p148.mine then
			p_u_32.light(v_u_174, v_u_8, 8 * v_u_150)
		end
		v_u_1:AddItem(v_u_174, 3)
		local v_u_180 = 24 + math.random() * 6
		local v_u_181 = false
		local v_u_182 = {}
		local v_u_183 = {}
		return {
			["place"] = function(p184, p185) -- name: place
				-- upvalues: (copy) v_u_174, (ref) p_u_32, (ref) v_u_4, (copy) v_u_180, (copy) v_u_154, (copy) v_u_182, (copy) v_u_183
				v_u_174.CFrame = p184
				local v186 = p184.Position
				local v187 = p_u_32.facing
				local v188 = Vector3.new(0, 1, 0)
				local v189 = v_u_4.CurrentCamera
				local v190
				if v189 then
					local v191 = v189.CFrame.Position - v186
					v190 = v191.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v191.Unit
				else
					v190 = Vector3.new(0, 0, 1)
				end
				local v192 = v187(v186, (v188 + v190 * 0.45).Unit) * CFrame.Angles(0, -p185 * v_u_180, 0)
				for v193, v194 in v_u_154 do
					v_u_182[v193] = v194.p
					v_u_183[v193] = v192 * v194.off
				end
				v_u_4:BulkMoveTo(v_u_182, v_u_183, Enum.BulkMoveMode.FireCFrameChanged)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_181, (copy) v_u_174, (ref) v_u_1, (copy) v_u_154, (ref) v_u_153
				if not v_u_181 then
					v_u_181 = true
					local v195 = v_u_174:FindFirstChildWhichIsA("PointLight")
					if v195 then
						v195:Destroy()
					end
					v_u_1:AddItem(v_u_174, 0.12)
					for _, v196 in v_u_154 do
						if v196.p == v_u_153 then
							v196.p.Transparency = 1
							v_u_1:AddItem(v196.p, 0.24)
						else
							v196.p:Destroy()
						end
					end
				end
			end
		}
	end
	local function v202(p198, p199) -- name: bladeImpact
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_32, (copy) v_u_100, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (ref) v_u_7
		local v200 = p198.size
		v_u_5.flash(p199, v_u_8, 5 * v200, 0.14)
		p_u_32.burst("Impact", p199, v_u_8, 1 * v200)
		v_u_100(p199, 4.4 * v200, 0.9 * v200, 0.04, 0.16)
		if not p198.lite then
			local v201 = { v_u_10, v_u_8, v_u_9 }
			p_u_32.chunks(p199, v201, 4, 22, 0.35 * v200, 0.4, true, 0.6)
			p_u_32.burst("Slash", p199, v_u_8, 0.7 * v200)
		end
		p_u_32.mark(p199, v_u_13, 2.2 * v200, 0.9, v_u_7.Glow, 0.3)
		p_u_32.hitSound(p199)
	end
	local v_u_203 = {}
	setmetatable(v_u_203, {
		["__mode"] = "k"
	})
	local v_u_204 = 0
	local function v_u_208() -- name: redFrame
		-- upvalues: (ref) v_u_204, (ref) v_u_2, (ref) v_u_5, (copy) p_u_32, (ref) v_u_14, (ref) v_u_1
		local v205 = os.clock()
		if v205 >= v_u_204 then
			v_u_204 = v205 + 0.7
			local v_u_206 = Instance.new("ColorCorrectionEffect")
			v_u_206.Name = "ThousandCuts"
			v_u_206.Parent = v_u_2
			v_u_5.tween(v_u_206, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.25,
				["Saturation"] = 0.3,
				["TintColor"] = Color3.fromRGB(255, 196, 200)
			})
			p_u_32.after(0.14, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_206, (ref) v_u_14
				local v207 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_14
				}
				v_u_5.tween(v_u_206, 0.45, v207)
			end)
			v_u_1:AddItem(v_u_206, 0.7)
		end
	end
	local v407 = {
		["scarlet_whirl_a"] = {
			["cast"] = function(p209) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_32, (ref) v_u_11, (copy) v_u_49, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10
				local v210 = p209.size
				local v211 = p209.eye + p209.dir * 1.2
				v_u_5.flash(v211, v_u_8, 3 * v210, 0.1)
				p_u_32.pop(v211, v_u_11, 1 * v210, 0.3 * v210, 0.08)
				if not p209.lite then
					local v212 = v_u_49
					local v213 = p_u_32.facing
					local v214 = Vector3.new(0, 1, 0)
					local v215 = v_u_4.CurrentCamera
					local v216
					if v215 then
						local v217 = v215.CFrame.Position - v211
						v216 = v217.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v217.Unit
					else
						v216 = Vector3.new(0, 0, 1)
					end
					v212(v213(v211, (v214 + v216 * 0.9).Unit), 0.5 * v210, 1.8 * v210, v_u_7.ScarletSaw, v_u_10, 0.12, -40, 0.2)
				end
			end,
			["shot"] = v137,
			["impact"] = v147,
			["hit"] = function(p218, p219, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_8, (ref) v_u_4, (copy) v_u_88, (ref) v_u_10
				p_u_32.burst("Impact", p219, v_u_8, 0.6)
				if not p218.lite then
					local v220 = v_u_4.CurrentCamera
					local v221, v222
					if v220 then
						v221 = v220.CFrame.RightVector
						v222 = v220.CFrame.UpVector
					else
						v222 = Vector3.new(0, 1, 0)
						v221 = Vector3.new(1, 0, 0)
					end
					local v223 = (v221 + v222 * 0.4).Unit * 1.6
					v_u_88(p219 - v223, p219 + v223, 0.5, v_u_10, nil, 0.04, 0.1)
				end
			end
		},
		["scarlet_whirl_e"] = {
			["weave"] = 1.8,
			["castSound"] = "EyeActivate",
			["cast"] = nil,
			["shot"] = nil,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p224) -- name: cast
				-- upvalues: (copy) p_u_32, (ref) v_u_8, (copy) v_u_88, (ref) v_u_10, (ref) v_u_11
				local v225 = p224.size
				p_u_32.skillCast(p224, v_u_8)
				local v226 = p224.eye + p224.dir * 1.6
				local v227 = p224.dir:Cross(Vector3.new(0, 1, 0)).Unit
				for v228 = -2, 2 do
					local v229 = (p224.dir + v227 * v228 * 0.32).Unit
					local v230 = v_u_88
					local v231 = v226 + v229 * 0.6 * v225
					local v232 = v226 + v229 * 4.2 * v225 + Vector3.new(0, 0.3, 0) * math.abs(v228)
					local v233 = 0.7 * v225
					local v234 = v_u_10
					local v235
					if p224.lite then
						v235 = nil
					else
						v235 = v_u_11
					end
					v230(v231, v232, v233, v234, v235, 0.05, 0.14)
				end
				if not p224.lite then
					p_u_32.burst("Slash", v226, v_u_8, 1 * v225)
				end
			end,
			["shot"] = v197,
			["impact"] = v202,
			["hit"] = function(_, p236, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_8
				p_u_32.burst("Impact", p236, v_u_8, 0.7)
			end
		},
		["scarlet_whirl_r"] = {
			["castSound"] = "EyeActivate",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p237) -- name: cast
				-- upvalues: (copy) p_u_32, (ref) v_u_8, (copy) v_u_49, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10
				local v238 = p237.size
				p_u_32.skillCast(p237, v_u_8, true)
				local v239 = p237.eye + Vector3.new(0, 1.5, 0)
				local v240 = v_u_49
				local v241 = p_u_32.facing
				local v242 = v_u_4.CurrentCamera
				local v243
				if v242 then
					local v244 = v242.CFrame.Position - v239
					v243 = v244.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v244.Unit
				else
					v243 = Vector3.new(0, 0, 1)
				end
				v240(v241(v239, v243), 1 * v238, 5 * v238, v_u_7.ScarletSaw, v_u_10, 0.3, -18, 0.1)
				p_u_32.burst("Slash", p237.eye + p237.dir * 2, v_u_8, 1.4 * v238)
			end,
			["windup"] = function(p245, p_u_246, p247) -- name: windup
				-- upvalues: (copy) v_u_111, (copy) v_u_203, (copy) p_u_32, (copy) v_u_117, (ref) v_u_4, (copy) v_u_49, (ref) v_u_7, (ref) v_u_10, (ref) v_u_5
				local v_u_248 = p245.size
				local v_u_249 = p245.ability.radius * v_u_248
				local v_u_250 = math.max(p247, 0.06)
				local v_u_251 = {
					["saws"] = nil,
					["taken"] = false,
					["angle"] = nil,
					["saws"] = {},
					["angle"] = math.random() * 3.141592653589793 * 2
				}
				for _ = 1, p245.lite and 3 or 6 do
					local v252 = v_u_251.saws
					local v253 = v_u_111(1.9 * v_u_248, p245.lite, v_u_250 + 5)
					table.insert(v252, v253)
				end
				v_u_203[p245] = v_u_251
				local v_u_254 = p245.eye + Vector3.new(0, 1.5, 0)
				local v_u_255 = os.clock()
				local v_u_256 = #v_u_251.saws
				p_u_32.runNow(function()
					-- upvalues: (copy) v_u_251, (copy) v_u_255, (copy) v_u_250, (copy) p_u_246, (copy) v_u_249, (copy) v_u_256, (ref) p_u_32, (copy) v_u_254, (ref) v_u_117, (ref) v_u_4, (copy) v_u_248, (ref) v_u_49, (ref) v_u_7, (ref) v_u_10
					if v_u_251.taken then
						return false
					end
					local v257 = os.clock() - v_u_255
					local v258 = v257 / v_u_250
					local v259 = math.clamp(v258, 0, 1)
					local v260 = 1 - (1 - v259) ^ 2
					for v261, v262 in v_u_251.saws do
						local v263 = p_u_246
						local v264 = v_u_249 * 0.95
						local v265 = v_u_251.angle
						local v266 = (v261 - 1) * 6 / v_u_256 + 1
						local v267 = v265 + (v266 - 1) / 6 * 3.141592653589793 * 2
						local v268 = p_u_32.ground
						local v269 = v266 * 1.3 + 0
						local v270 = v268(v263, math.sin(v269) * 0.6 + 2.4)
						local v271 = math.cos(v267) * v264
						local v272 = math.sin(v267) * v264
						local v273 = v_u_254:Lerp(v270 + Vector3.new(v271, 0, v272), v260)
						local v274 = v259 * 3.141592653589793
						local v275 = v273 + Vector3.new(0, 1, 0) * math.sin(v274) * 3
						local v276 = v_u_117
						local v277 = p_u_32.facing
						local v278 = Vector3.new(0, 1, 0)
						local v279 = v_u_4.CurrentCamera
						local v280
						if v279 then
							local v281 = v279.CFrame.Position - v275
							v280 = v281.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v281.Unit
						else
							v280 = Vector3.new(0, 0, 1)
						end
						v276(v262, v277(v275, (v278 + v280 * 0.7).Unit), -v257 * 30)
					end
					if v_u_250 + 1.2 >= v257 then
						return true
					end
					for _, v282 in v_u_251.saws do
						local v283 = v282.body.Position
						local v284 = 1.9 * v_u_248
						v282.blades:Destroy()
						v282.body:Destroy()
						local v285 = v282.glow
						if v285 then
							v285:Destroy()
						end
						local v286 = v_u_49
						local v287 = p_u_32.facing
						local v288 = Vector3.new(0, 1, 0)
						local v289 = v_u_4.CurrentCamera
						local v290
						if v289 then
							local v291 = v289.CFrame.Position - v283
							v290 = v291.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v291.Unit
						else
							v290 = Vector3.new(0, 0, 1)
						end
						v286(v287(v283, (v288 + v290 * 0.8).Unit), v284, v284 * 2.4, v_u_7.ScarletSaw, v_u_10, 0.22, -30)
					end
					return false
				end)
				v_u_49(CFrame.new(p_u_32.ground(p_u_246, 0.15)), v_u_249 * 1.25, v_u_249, v_u_7.Ring, v_u_10, v_u_250 + 0.1, 2, 0.2)
				if p245.mine then
					v_u_5.shake(0.15, 0.2)
				end
			end,
			["zone"] = function(p_u_292, p_u_293, p_u_294) -- name: zone
				-- upvalues: (copy) p_u_32, (copy) v_u_203, (copy) v_u_111, (ref) v_u_27, (ref) v_u_7, (ref) v_u_13, (ref) v_u_1, (ref) v_u_10, (ref) v_u_5, (copy) v_u_117, (ref) v_u_4, (copy) v_u_49, (copy) v_u_88, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9, (ref) v_u_6
				local v_u_295 = p_u_292.size
				local v_u_296 = p_u_292.ability.radius * v_u_295
				local v_u_297 = p_u_292.lite
				local v_u_298 = p_u_32.ground(p_u_293)
				local v299 = p_u_294 + 2
				local v300 = v_u_203[p_u_292]
				v_u_203[p_u_292] = nil
				local v_u_301 = v300 or {
					["saws"] = nil,
					["taken"] = false,
					["angle"] = nil,
					["saws"] = {},
					["angle"] = math.random() * 3.141592653589793 * 2
				}
				v_u_301.taken = true
				if #v_u_301.saws == 0 then
					for _ = 1, v_u_297 and 3 or 6 do
						local v302 = v_u_301.saws
						local v303 = v_u_111(1.9 * v_u_295, v_u_297, v299)
						table.insert(v302, v303)
					end
				end
				local v_u_304 = #v_u_301.saws
				local v_u_305 = v_u_27(CFrame.new(p_u_32.ground(p_u_293, 0.1)), v_u_296 * 1.15, v_u_7.Glow, v_u_13, 0.25)
				v_u_1:AddItem(v_u_305, v299)
				local v_u_306 = v_u_27(CFrame.new(p_u_32.ground(p_u_293, 0.14)), v_u_296 * 1.02, v_u_7.Ring, v_u_10, 0.15)
				v_u_1:AddItem(v_u_306, v299)
				p_u_32.mark(p_u_293, v_u_10, v_u_296 * 0.8, p_u_294 + 1.2, v_u_7.CrackLines, 0.35)
				v_u_5.ring(v_u_298, v_u_10, v_u_296 * 1.1, 0.35, v_u_7.Shockwave)
				local v_u_307 = os.clock()
				local v_u_308 = v_u_307
				local v_u_309 = v_u_301.angle
				local v_u_310 = nil
				local v_u_311 = {}
				p_u_32.runNow(function()
					-- upvalues: (copy) v_u_307, (ref) v_u_308, (ref) v_u_309, (ref) v_u_310, (copy) v_u_301, (copy) p_u_293, (copy) v_u_296, (copy) v_u_304, (ref) p_u_32, (copy) v_u_311, (ref) v_u_117, (ref) v_u_4, (copy) v_u_306, (copy) v_u_295, (ref) v_u_49, (ref) v_u_7, (ref) v_u_10, (copy) p_u_294
					local v312 = os.clock()
					local v313 = v312 - v_u_307
					local v314 = v312 - v_u_308
					local v315 = math.min(v314, 0.05)
					v_u_308 = v312
					v_u_309 = v_u_309 + v315 * 2.6
					local v316
					if v_u_310 then
						local v317 = (v312 - v_u_310) / 0.12
						v316 = math.clamp(v317, 0, 1)
					else
						v316 = 0
					end
					for v318, v319 in v_u_301.saws do
						local v320 = p_u_293
						local v321 = v_u_296 * 0.95
						local v322 = v_u_309
						local v323 = (v318 - 1) * 6 / v_u_304 + 1
						local v324 = v322 + (v323 - 1) / 6 * 3.141592653589793 * 2
						local v325 = p_u_32.ground
						local v326 = v313 * 3 + v323 * 1.3
						local v327 = v325(v320, math.sin(v326) * 0.6 + 2.4)
						local v328 = math.cos(v324) * v321
						local v329 = math.sin(v324) * v321
						local v330 = v327 + Vector3.new(v328, 0, v329)
						if v316 > 0 then
							v_u_311[v318] = v_u_311[v318] or v330
							v330 = v_u_311[v318]:Lerp(p_u_32.ground(p_u_293, 5), v316 * v316)
						end
						local v331 = v_u_117
						local v332 = p_u_32.facing
						local v333 = Vector3.new(0, 1, 0)
						local v334 = v_u_4.CurrentCamera
						local v335
						if v334 then
							local v336 = v334.CFrame.Position - v330
							v335 = v336.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v336.Unit
						else
							v335 = Vector3.new(0, 0, 1)
						end
						v331(v319, v332(v330, (v333 + v335 * 0.7).Unit), -v313 * 34)
					end
					if v_u_306.Parent then
						v_u_306.CFrame = CFrame.new(p_u_32.ground(p_u_293, 0.14)) * CFrame.Angles(0, -v_u_309 * 0.3, 0)
					end
					if v316 < 1 then
						return v313 < p_u_294 + 1
					end
					for _, v337 in v_u_301.saws do
						local v338 = p_u_32.ground(p_u_293, 5)
						local v339 = 1.9 * v_u_295
						v337.blades:Destroy()
						v337.body:Destroy()
						local v340 = v337.glow
						if v340 then
							v340:Destroy()
						end
						local v341 = v_u_49
						local v342 = p_u_32.facing
						local v343 = Vector3.new(0, 1, 0)
						local v344 = v_u_4.CurrentCamera
						local v345
						if v344 then
							local v346 = v344.CFrame.Position - v338
							v345 = v346.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v346.Unit
						else
							v345 = Vector3.new(0, 0, 1)
						end
						v341(v342(v338, (v343 + v345 * 0.8).Unit), v339, v339 * 2.4, v_u_7.ScarletSaw, v_u_10, 0.22, -30)
					end
					return false
				end)
				local v_u_347 = true
				local v_u_348 = v_u_297 and 0.16666666666666666 or 0.07142857142857142
				local v_u_349 = p_u_292.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (ref) v_u_347, (copy) v_u_307, (copy) p_u_294, (copy) v_u_301, (copy) v_u_304, (copy) p_u_293, (ref) p_u_32, (copy) v_u_296, (ref) v_u_88, (copy) v_u_295, (ref) v_u_10, (copy) v_u_297, (ref) v_u_11, (copy) v_u_349, (ref) v_u_8, (ref) v_u_5, (copy) v_u_298, (ref) v_u_7, (ref) v_u_9, (copy) p_u_292, (ref) v_u_6, (copy) v_u_348
					local v350 = 0
					local v351 = 0
					while v_u_347 and os.clock() - v_u_307 < p_u_294 + 0.3 do
						local v352 = os.clock() - v_u_307
						v350 = v350 + 1
						local v353 = v_u_301.saws[v350 * 4 % v_u_304 + 1].body.Position
						local v354 = v353.Z - p_u_293.Z
						local v355 = v353.X - p_u_293.X
						local v356 = math.atan2(v354, v355) + 3.141592653589793 + (math.random() - 0.5) * 1.8
						local v357 = p_u_32.ground(p_u_293, 0.6 + math.random() * 6.5)
						local v358 = math.cos(v356)
						local v359 = math.sin(v356)
						local v360 = v357 + Vector3.new(v358, 0, v359) * v_u_296
						local v361 = v_u_88
						local v362 = (1.7 + math.random() * 1.1) * v_u_295
						local v363 = v_u_10
						local v364
						if v_u_297 then
							v364 = nil
						else
							v364 = v_u_11
						end
						v361(v353, v360, v362, v363, v364, 0.07, 0.18)
						if v351 <= v352 then
							v351 = v352 + v_u_349
							local v365 = math.random() * 3.141592653589793
							local v366 = v_u_297 and 3 or 5
							for v367 = 0, v366 - 1 do
								local v368 = v365 + v367 * 3.141592653589793 / v366
								local v369 = math.cos(v368)
								local v370 = (math.random() - 0.5) * 0.5
								local v371 = math.sin(v368)
								local v372 = Vector3.new(v369, v370, v371)
								local v373 = p_u_32.ground(p_u_293, 1 + math.random() * 4)
								local v374 = v_u_88
								local v375 = v373 - v372 * v_u_296
								local v376 = v373 + v372 * v_u_296
								local v377 = 2.4 * v_u_295
								local v378 = v_u_8
								local v379
								if v_u_297 then
									v379 = nil
								else
									v379 = v_u_11
								end
								v374(v375, v376, v377, v378, v379, 0.06, 0.2)
							end
							v_u_5.flash(p_u_32.ground(p_u_293, 3), v_u_10, v_u_296 * 0.6, 0.12)
							v_u_5.ring(v_u_298, v_u_10, v_u_296 * 1.05, 0.25, v_u_7.Ring)
							if not v_u_297 then
								local v380 = v365 + 1.5707963267948966
								local v381 = math.cos(v380)
								local v382 = math.sin(v380)
								local v383 = Vector3.new(v381, 0, v382) * v_u_296 * 0.9
								p_u_32.groundLine(p_u_293 - v383, p_u_293 + v383, 1, v_u_10, 1.4, 0.2)
								p_u_32.spikes(p_u_32.ground(p_u_293, 2), v_u_9, 4, v_u_296 * 0.7, 0.18, nil, nil, true)
							end
							if p_u_292.mine then
								local v384 = {
									["at"] = nil,
									["volume"] = 0.35,
									["at"] = v_u_298
								}
								v_u_6.play("EyeActivate", v384)
							end
						end
						task.wait(v_u_348)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_347, (ref) v_u_310, (copy) v_u_305, (copy) v_u_306
					v_u_347 = false
					v_u_310 = os.clock()
					v_u_305:Destroy()
					v_u_306:Destroy()
				end
			end,
			["finish"] = function(p_u_385, p_u_386) -- name: finish
				-- upvalues: (copy) p_u_32, (ref) v_u_4, (copy) v_u_88, (ref) v_u_10, (ref) v_u_11, (ref) v_u_6, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_13, (copy) v_u_208
				local v_u_387 = p_u_385.size
				local v_u_388 = p_u_385.ability.radius * v_u_387
				local v_u_389 = p_u_385.lite
				local v_u_390 = p_u_32.ground(p_u_386)
				local v_u_391 = p_u_32.ground(p_u_386, 5)
				local v392 = v_u_4.CurrentCamera
				local v_u_393, v394
				if v392 then
					v_u_393 = v392.CFrame.RightVector
					v394 = v392.CFrame.UpVector
				else
					v_u_393 = Vector3.new(1, 0, 0)
					v394 = Vector3.new(0, 1, 0)
				end
				local v395 = v_u_388 * 1.2
				local v396 = (v_u_393 - v394).Unit * v395
				local v_u_397 = (v_u_393 * -1 - v394).Unit * v395
				v_u_88(v_u_391 - v396, v_u_391 + v396, 5 * v_u_387, v_u_10, v_u_11, 0.08, 0.42)
				p_u_32.after(0.1, function()
					-- upvalues: (ref) v_u_88, (copy) v_u_391, (copy) v_u_397, (copy) v_u_387, (ref) v_u_10, (ref) v_u_11
					v_u_88(v_u_391 - v_u_397, v_u_391 + v_u_397, 5 * v_u_387, v_u_10, v_u_11, 0.08, 0.38)
				end)
				v_u_6.play("Crit", {
					["at"] = v_u_390,
					["volume"] = p_u_385.mine and 0.9 or 0.5
				})
				p_u_32.after(0.2, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_391, (ref) v_u_10, (copy) v_u_388, (ref) p_u_32, (copy) v_u_390, (ref) v_u_8, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (copy) v_u_393, (copy) p_u_386, (copy) v_u_387, (ref) v_u_13, (copy) v_u_389, (ref) v_u_6, (copy) p_u_385, (ref) v_u_208
					v_u_5.flash(v_u_391, v_u_10, v_u_388 * 1.5, 0.16)
					p_u_32.pop(v_u_390, v_u_8, v_u_388 * 0.6, v_u_388 * 2.3, 0.45, 0.3)
					p_u_32.pop(v_u_391, v_u_11, 2, v_u_388 * 0.8, 0.14)
					p_u_32.burst("Explosion", v_u_391, v_u_8, 2.2)
					p_u_32.burst("Shockwave", v_u_390 + Vector3.new(0, 0.3, 0), v_u_8, 1.4)
					v_u_5.ring(v_u_390, v_u_10, v_u_388 * 1.4, 0.5, v_u_7.Shockwave)
					p_u_32.after(0.06, function()
						-- upvalues: (ref) v_u_5, (ref) v_u_390, (ref) v_u_9, (ref) v_u_388, (ref) v_u_7
						v_u_5.ring(v_u_390, v_u_9, v_u_388 * 1.6, 0.45, v_u_7.SpeedLines)
					end)
					local v398 = p_u_32.flatUnit(v_u_393) * v_u_388
					local v399 = p_u_32.flatUnit(v_u_393:Cross(Vector3.new(0, 1, 0)) * -1) * v_u_388
					p_u_32.groundLine(p_u_386 - v398 - v399, p_u_386 + v398 + v399, 2.6 * v_u_387, v_u_10, 1.8, 0.1)
					p_u_32.groundLine(p_u_386 + v398 - v399, p_u_386 - v398 + v399, 2.6 * v_u_387, v_u_10, 1.8, 0.1)
					p_u_32.mark(p_u_386, v_u_13, v_u_388 * 0.9, 2.2, v_u_7.CrackGlow, 0.05)
					p_u_32.spikes(v_u_391, v_u_9, v_u_389 and 5 or 10, v_u_388 * 1.2, 0.32, nil, nil, true)
					p_u_32.chunks(p_u_32.ground(p_u_386, 1), {
						p_u_32.EARTH[1],
						p_u_32.EARTH[2],
						v_u_13,
						v_u_8
					}, v_u_389 and 5 or 14, 50, 1.3, 1.3, false, 1)
					if not v_u_389 then
						local v400 = { v_u_10, v_u_9, v_u_8 }
						p_u_32.chunks(v_u_391, v400, 8, 40, 0.5, 0.9, true, 0.8)
						p_u_32.burst("Slash", v_u_391, v_u_8, 2.4)
					end
					v_u_6.play("Explosion", {
						["at"] = v_u_390,
						["volume"] = p_u_385.mine and 1 or 0.6
					})
					if p_u_385.mine then
						v_u_5.shake(0.55, 0.5)
						v_u_208()
					end
				end)
			end,
			["hit"] = function(p401, p402, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_8, (ref) v_u_4, (copy) v_u_88, (ref) v_u_10
				p_u_32.burst("Impact", p402, v_u_8, 0.8)
				if not p401.lite then
					local v403 = v_u_4.CurrentCamera
					local v404, v405
					if v403 then
						v404 = v403.CFrame.RightVector
						v405 = v403.CFrame.UpVector
					else
						v405 = Vector3.new(0, 1, 0)
						v404 = Vector3.new(1, 0, 0)
					end
					local v406 = (v404 + v405 * ((math.random() - 0.5) * 1.6)).Unit * 2
					v_u_88(p402 - v406, p402 + v406, 0.6, v_u_10, nil, 0.04, 0.12)
				end
			end
		}
	}
	return v407
end