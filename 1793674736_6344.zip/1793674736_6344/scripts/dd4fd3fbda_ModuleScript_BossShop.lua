local v_u_1 = require(script.Parent.Parent.Config.Boss)
local v_u_2 = require(script.Parent.Parent.Config.Eyes)
local v_u_28 = {
	["check"] = function(p3, p4, p5, p6) -- name: check
		if p3 then
			if p6 then
				if p3.kind == "boost" or not p5 then
					if p4 < p3.cost then
						return "coins", p3.cost - p4
					else
						return "ok", 0
					end
				else
					return "owned", 0
				end
			else
				return "out", 0
			end
		else
			return "unknown", 0
		end
	end,
	["boostUntil"] = function(p7, p8, p9) -- name: boostUntil
		return math.max(p7 or 0, p8) + p9 * 60
	end,
	["byTier"] = function() -- name: byTier
		-- upvalues: (copy) v_u_1
		local v10 = {}
		for _, v11 in v_u_1.TIERS do
			local v12 = {}
			for _, v13 in v_u_1.SHOP do
				if v13.tier ~= v11.id then
					continue
				end
				table.insert(v12, v13)
			end
			table.sort(v12, function(p14, p15)
				return p14.cost < p15.cost
			end)
			local v16 = {
				["tier"] = v11.id,
				["name"] = v11.name,
				["color"] = v11.color,
				["items"] = v12
			}
			table.insert(v10, v16)
		end
		return v10
	end,
	["ownsEye"] = function(p17, p18) -- name: ownsEye
		-- upvalues: (copy) v_u_2
		local v19 = v_u_2.byId[p17.item]
		local v20
		if v19 == nil then
			v20 = false
		else
			v20 = v_u_2.owns(p18, v19)
		end
		return v20
	end,
	["lostEyes"] = function(p21, p22) -- name: lostEyes
		-- upvalues: (copy) v_u_1, (copy) v_u_2, (copy) v_u_28
		local v23 = {}
		for _, v24 in v_u_1.SHOP do
			if v24.kind ~= "eye" or (not p21[v24.id] or (not v_u_2.byId[v24.item] or v_u_28.ownsEye(v24, p22))) then
				continue
			end
			local v25 = v24.item
			table.insert(v23, v25)
		end
		return v23
	end,
	["winsFor"] = function(p26) -- name: winsFor
		-- upvalues: (copy) v_u_1
		local v27 = p26 / v_u_1.COINS_PER_WIN
		return math.ceil(v27)
	end
}
return v_u_28