local v1 = require(script.Parent.Parent.Logic.Prizes)
local v_u_2 = require(script.Parent.Release)
local v3 = {
	{
		["code"] = "AWAKEN",
		["prizes"] = nil,
		["prizes"] = { v1.trophies(5, 100), v1.worldEgg(2, 3), v1.boost("chakra", 30) }
	},
	{
		["code"] = "SHARINGAN",
		["prizes"] = nil,
		["prizes"] = { v1.trophies(10, 250), v1.egg("akatsuki", 1), v1.boost("wins", 30) }
	},
	{
		["code"] = "UPDATE1",
		["prizes"] = nil,
		["prizes"] = { v1.boost("chakra", 10) }
	},
	{
		["code"] = "NEWWORLDS",
		["prizes"] = nil,
		["prizes"] = { v1.boost("wins", 10) }
	},
	{
		["code"] = "1MILLIONVISITS",
		["prizes"] = nil,
		["update"] = 2,
		["prizes"] = { v1.egg("infernal_aegis", 1) }
	},
	{
		["code"] = "UPDATE2",
		["prizes"] = nil,
		["update"] = 2,
		["prizes"] = { v1.kuramaCoins(15), v1.boost("chakra", 5) }
	},
	{
		["code"] = "KURUMA",
		["prizes"] = nil,
		["update"] = 2,
		["prizes"] = { v1.kuramaCoins(15), v1.boost("chakra", 5) }
	}
}
local v_u_4 = {}
for _, v5 in v3 do
	if v5.live == false then
		continue
	end
	v_u_4[v5.code] = v5
end
return {
	["list"] = v3,
	["byCode"] = v_u_4,
	["normalize"] = function(p6) -- name: normalize
		return string.upper((string.gsub(p6, "%s", "")))
	end,
	["find"] = function(p7) -- name: find
		-- upvalues: (copy) v_u_4, (copy) v_u_2
		local v8 = v_u_4[string.upper((string.gsub(p7, "%s", "")))]
		if v8 and (v8.update and not v_u_2.on(v8.update)) then
			return nil
		else
			return v8
		end
	end
}