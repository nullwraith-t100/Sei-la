local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromHex("0D0405")
local v_u_5 = Color3.fromRGB(120, 0, 14)
local v_u_6 = Enum.PartType.Wedge
return function(p_u_7)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5
	return {
		["w3_blood_trident"] = function(p_u_8, p9)
			-- upvalues: (ref) v_u_2, (copy) p_u_7, (ref) v_u_3, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5
			local v_u_10 = v_u_2.color(p9.color)
			local v_u_11 = v_u_10:Lerp(Color3.fromRGB(255, 90, 90), 0.35)
			local v_u_12 = p_u_8.fx <= 1 and 1 or p_u_8.fx / 1.35
			local v_u_14 = p_u_7.throb(p_u_8, 3.6, 1.2, 1.4, function(p13)
				-- upvalues: (ref) v_u_2, (ref) p_u_7, (copy) p_u_8, (copy) v_u_10, (ref) v_u_3, (copy) v_u_11
				v_u_2.ring(p_u_7.feetAt(p_u_8, p13, 0.15), v_u_10, 5.5 * p_u_8.fx, 0.45, v_u_3.Shockwave)
				v_u_2.flash(p_u_7.feetAt(p_u_8, p13, 0.8), v_u_11, 4 * p_u_8.fx, 0.25)
			end)
			local v_u_15 = 0
			local v16 = p_u_8.ticks
			local function v18(_, _, p17)
				-- upvalues: (ref) v_u_15, (copy) v_u_14
				v_u_15 = v_u_15 + p17 * (1.1 + v_u_14() * 9)
			end
			table.insert(v16, v18)
			local v_u_24 = p_u_7.group(p_u_8, function(p19, p20)
				-- upvalues: (copy) v_u_12, (ref) v_u_15
				local v21 = p19 * CFrame.new(0, -0.45 * v_u_12, 0)
				local v22 = CFrame.Angles
				local v23 = p20 * 0.9
				return v21 * v22(math.sin(v23) * 0.05 + 0.2792526803190927, 0, -0.10471975511965978) * CFrame.Angles(0, v_u_15, 0)
			end)
			p_u_7.pin(p_u_8, v_u_24, p_u_7.picture(4.6 * v_u_12, v_u_3.Ring, v_u_10, 0.05), CFrame.identity)
			for v25 = 0, 2 do
				local v26 = v25 * 2.0943951023931953
				local v27 = math.cos(v26)
				local v28 = math.sin(v26)
				local v29 = Vector3.new(v27, 0, v28)
				local v30 = -math.sin(v26)
				local v31 = math.cos(v26)
				local v32 = Vector3.new(v30, 0, v31)
				local v33 = v29 * 2.1 * v_u_12
				local v34 = 2.7 * v_u_12
				local v35 = 1.3 * v_u_12
				local v36 = 0.22 * v_u_12
				local v37 = v33 + v29 * (v34 / 2) + v32 * (v35 / 2)
				local v_u_38 = CFrame.fromMatrix(v37, v32:Cross(-v29), v32)
				local v39 = Vector3.new(v36, v35, v34)
				local v40 = {
					["shape"] = v_u_6
				}
				p_u_7.add(p_u_8, v_u_2.part(v39, CFrame.identity, v_u_10, v40), function()
					-- upvalues: (copy) v_u_14, (copy) v_u_24, (copy) v_u_38
					local v41 = 1 + v_u_14() * 0.22
					return v_u_24.cf * (v_u_38 - v_u_38.Position + v_u_38.Position * v41)
				end)
				local v42 = v29 * 2.35 * v_u_12
				local v43 = 1.85 * v_u_12
				local v44 = 0.62 * v_u_12
				local v45 = 0.26 * v_u_12
				local v46 = v42 + v29 * (v43 / 2) + v32 * (v44 / 2)
				local v47 = CFrame.fromMatrix(v46, v32:Cross(-v29), v32)
				local v48 = Vector3.new(v45, v44, v43)
				local v49 = v_u_2.part(v48, CFrame.identity, v_u_4, {
					["shape"] = v_u_6,
					["material"] = Enum.Material.SmoothPlastic
				})
				local v50 = p_u_7.add
				local v_u_51 = v47 * CFrame.new(-0.05 * v_u_12, 0, 0)
				v50(p_u_8, v49, function()
					-- upvalues: (copy) v_u_14, (copy) v_u_24, (copy) v_u_51
					local v52 = 1 + v_u_14() * 0.22
					return v_u_24.cf * (v_u_51 - v_u_51.Position + v_u_51.Position * v52)
				end)
				local v53 = v_u_2.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v_u_10, {
					["transparency"] = 1
				})
				local v54 = p_u_7.add
				local v_u_55 = CFrame.new(v29 * 4.6 * v_u_12)
				v54(p_u_8, v53, function()
					-- upvalues: (copy) v_u_14, (copy) v_u_24, (copy) v_u_55
					local v56 = 1 + v_u_14() * 0.22
					return v_u_24.cf * (v_u_55 - v_u_55.Position + v_u_55.Position * v56)
				end)
				p_u_7.tail(v53, v_u_11, v_u_10, 0.35 * v_u_12, 0.22)
			end
			local v_u_57 = p_u_7.backOf(p_u_8) * CFrame.new(0, 0.15 * v_u_12, 0.42 * v_u_12) * CFrame.Angles(0, 0, -0.6108652381980153)
			local v58 = p_u_7.bar(Vector3.new(0.17, 5.6, 0.17) * v_u_12, v_u_5, 0, Enum.Material.SmoothPlastic)
			local v_u_59 = CFrame.identity
			v58.Massless = true
			p_u_7.glue(p_u_8, v58, function(p60)
				-- upvalues: (copy) v_u_57, (copy) v_u_59
				return p60 * v_u_57 * v_u_59
			end)
			local v61 = p_u_7.bar(Vector3.new(1.3, 0.17, 0.17) * v_u_12, v_u_10, 0)
			local v_u_62 = CFrame.new(0, 2.75 * v_u_12, 0)
			v61.Massless = true
			p_u_7.glue(p_u_8, v61, function(p63)
				-- upvalues: (copy) v_u_57, (copy) v_u_62
				return p63 * v_u_57 * v_u_62
			end)
			local v64 = p_u_7.blob(Vector3.new(0.24, 1.5, 0.24) * v_u_12, v_u_11, 0)
			local v_u_65 = CFrame.new(0, 3.45 * v_u_12, 0)
			v64.Massless = true
			p_u_7.glue(p_u_8, v64, function(p66)
				-- upvalues: (copy) v_u_57, (copy) v_u_65
				return p66 * v_u_57 * v_u_65
			end)
			for _, v67 in { -1, 1 } do
				local v68 = p_u_7.blob(Vector3.new(0.2, 1.05, 0.2) * v_u_12, v_u_11, 0)
				local v_u_69 = CFrame.new(v67 * 0.58 * v_u_12, 3.2 * v_u_12, 0) * CFrame.Angles(0, 0, -v67 * 0.14)
				v68.Massless = true
				p_u_7.glue(p_u_8, v68, function(p70)
					-- upvalues: (copy) v_u_57, (copy) v_u_69
					return p70 * v_u_57 * v_u_69
				end)
			end
			local v71 = p_u_7.blob(Vector3.new(0.22, 0.6, 0.22) * v_u_12, v_u_10, 0)
			local v_u_72 = CFrame.new(0, -2.85 * v_u_12, 0)
			v71.Massless = true
			p_u_7.glue(p_u_8, v71, function(p73)
				-- upvalues: (copy) v_u_57, (copy) v_u_72
				return p73 * v_u_57 * v_u_72
			end)
			p_u_7.particles(p_u_8, "AuraMode", v_u_10, {
				["rate"] = 0.32,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "FlameBack", "Crackle", "Sparks" }
			})
		end
	}
end