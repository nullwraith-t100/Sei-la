local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("E89AA8")
local v_u_8 = Color3.fromHex("5A1E2E")
local v_u_9 = Color3.fromRGB(255, 150, 176)
local v_u_10 = Color3.fromRGB(240, 70, 120)
local v_u_11 = Color3.fromRGB(255, 236, 242)
local v_u_12 = Color3.fromRGB(14, 8, 10)
local v_u_13 = Enum.PartType.Ball
local function v_u_27(p14, p15, p16, p17, p18, p19) -- name: picture
	-- upvalues: (copy) v_u_4
	local v20 = v_u_4.part
	local v21 = p15 * 2
	local v22 = p15 * 2
	local v23 = v20(Vector3.new(v21, 0.05, v22), p14, p17, {
		["transparency"] = 1
	})
	local v24
	if p19 then
		v24 = { Enum.NormalId.Top, Enum.NormalId.Bottom }
	else
		v24 = { Enum.NormalId.Top }
	end
	for _, v25 in v24 do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p16
		v26.Color3 = p17
		v26.Transparency = p18
		v26.Parent = v23
	end
	return v23
end
local function v_u_31(p28, p29) -- name: setAlpha
	for _, v30 in p28:GetChildren() do
		if not v30:IsA("Decal") then
			continue
		end
		v30.Transparency = p29
	end
end
local function v_u_38(p32, p33, p34, p35, p36) -- name: lightBeam
	-- upvalues: (copy) v_u_6
	local v37 = Instance.new("Beam")
	v37.Attachment0 = p32
	v37.Attachment1 = p33
	v37.Texture = v_u_6.Beam
	v37.TextureMode = Enum.TextureMode.Wrap
	v37.TextureLength = 6
	v37.TextureSpeed = 3
	v37.Color = ColorSequence.new(p34)
	v37.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v37.LightEmission = 0.25
	v37.LightInfluence = 0
	v37.FaceCamera = true
	v37.Width0 = p35
	v37.Width1 = p36
	v37.Segments = 1
	v37.Parent = p32
	return v37
end
return function(p_u_39)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_31, (copy) v_u_4, (copy) v_u_7, (copy) v_u_13, (copy) v_u_11, (copy) v_u_6, (copy) v_u_8, (copy) v_u_3, (copy) v_u_10, (copy) v_u_9, (copy) v_u_38, (copy) v_u_12, (copy) v_u_5
	local function v_u_57(p_u_40, p_u_41, p_u_42, p43, p44, p_u_45, p_u_46, p47, p48) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_39, (ref) v_u_31
		local v_u_49 = p47 or 0
		local v_u_50 = v_u_27(p_u_40, p_u_41, p43, p44, v_u_49, p48)
		v_u_1:AddItem(v_u_50, p_u_45 + 0.1)
		p_u_39.animate(p_u_45, 0, function(p51)
			-- upvalues: (copy) v_u_50, (copy) p_u_41, (copy) p_u_42, (copy) p_u_40, (copy) p_u_45, (copy) p_u_46, (ref) v_u_31, (copy) v_u_49
			local v52 = 1 - (1 - p51) ^ 3
			local v53 = v_u_50
			local v54 = p_u_41 + (p_u_42 - p_u_41) * v52
			local v55 = v54 * 2
			local v56 = v54 * 2
			v53.Size = Vector3.new(v55, 0.05, v56)
			v_u_50.CFrame = p_u_40 * CFrame.Angles(0, p51 * p_u_45 * p_u_46, 0)
			v_u_31(v_u_50, v_u_49 + (1 - v_u_49) * p51 ^ 1.5)
			if p51 >= 1 then
				v_u_50:Destroy()
			end
		end)
	end
	local function v80(p58, p59) -- name: tomoeShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_13, (ref) v_u_11, (ref) v_u_27, (ref) v_u_6, (copy) p_u_39, (ref) v_u_8, (ref) v_u_1, (ref) v_u_3, (copy) v_u_57, (ref) v_u_10
		local v_u_60 = p58.size
		local v_u_61 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p59, v_u_7, {
			["transparency"] = 1
		})
		local v62 = {
			["shape"] = nil,
			["transparency"] = 0.35,
			["shape"] = v_u_13
		}
		local v_u_63 = v_u_4.part(Vector3.new(1.7, 1.7, 1.7) * v_u_60, p59, v_u_7, v62)
		local v64 = {
			["shape"] = v_u_13
		}
		local v_u_65 = v_u_4.part(Vector3.new(0.65, 0.65, 0.65) * v_u_60, p59, v_u_11, v64)
		local v_u_66 = v_u_27(p59, 1.05 * v_u_60, v_u_6.PulsarTomoe, v_u_7, 0)
		local v_u_67 = { v_u_63, v_u_65, v_u_66 }
		p_u_39.streak(v_u_61, v_u_7, v_u_8, 1 * v_u_60, 0.14)
		if p58.mine then
			p_u_39.light(v_u_61, v_u_7, 9 * v_u_60)
		end
		for _, v68 in v_u_67 do
			v_u_1:AddItem(v68, 3)
		end
		v_u_1:AddItem(v_u_61, 3)
		local v_u_69 = p58.lite and 0.09 or 0.045
		local v_u_70 = 0.02
		local v_u_71 = false
		return {
			["place"] = function(p72, p73) -- name: place
				-- upvalues: (copy) v_u_61, (copy) v_u_63, (copy) v_u_65, (ref) v_u_3, (copy) v_u_66, (ref) p_u_39, (copy) v_u_60, (ref) v_u_70, (copy) v_u_69, (ref) v_u_57, (ref) v_u_6, (ref) v_u_10
				local v74 = p72.Position
				v_u_61.CFrame = p72
				v_u_63.CFrame = p72
				v_u_65.CFrame = p72
				local v75 = v_u_3.CurrentCamera
				local v76
				if v75 then
					local v77 = v75.CFrame.Position - v74
					v76 = v77.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v77.Unit
				else
					v76 = Vector3.new(0, 0, 1)
				end
				v_u_66.CFrame = p_u_39.facing(v74 + v76 * 0.7 * v_u_60, v76) * CFrame.Angles(0, -p73 * 18, 0)
				if v_u_70 <= p73 then
					v_u_70 = p73 + v_u_69
					v_u_57(p_u_39.facing(v74, p72.LookVector), 0.7 * v_u_60, 2.5 * v_u_60, v_u_6.Ring, v_u_10, 0.24, 0, 0, true)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_71, (copy) v_u_61, (ref) v_u_1, (copy) v_u_67
				if not v_u_71 then
					v_u_71 = true
					local v78 = v_u_61:FindFirstChildWhichIsA("PointLight")
					if v78 then
						v78:Destroy()
					end
					v_u_1:AddItem(v_u_61, 0.2)
					for _, v79 in v_u_67 do
						v79:Destroy()
					end
				end
			end
		}
	end
	local function v87(p81, p82) -- name: tomoeImpact
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) p_u_39, (ref) v_u_7, (ref) v_u_6, (copy) v_u_57, (ref) v_u_9, (ref) v_u_11
		local v83 = p81.size
		local v84 = v_u_3.CurrentCamera
		local v85
		if v84 then
			local v86 = v84.CFrame.Position - p82
			v85 = v86.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v86.Unit
		else
			v85 = Vector3.new(0, 0, 1)
		end
		v_u_4.ring(p_u_39.ground(p82), v_u_7, p81.ability.radius * v83, 0.3, v_u_6.PulsarRipple)
		v_u_57(p_u_39.facing(p82 + v85 * 0.5, v85), 0.8 * v83, 4 * v83, v_u_6.PulsarRipple, v_u_9, 0.24, 0, 0.1)
		v_u_57(p_u_39.facing(p82 + v85, v85), 1.05 * v83, 2.8 * v83, v_u_6.PulsarTomoe, v_u_7, 0.2, -20)
		p_u_39.pop(p82, v_u_7, 1.2 * v83, 4.4 * v83, 0.18, 0.35)
		p_u_39.pop(p82, v_u_11, 0.7 * v83, 1.8 * v83, 0.1)
		p_u_39.burst("Impact", p82, v_u_7, 0.9 * v83)
		p_u_39.hitSound(p82)
	end
	local function v161(p88, p89, p90) -- name: beacon
		-- upvalues: (copy) p_u_39, (ref) v_u_4, (ref) v_u_11, (ref) v_u_13, (ref) v_u_7, (ref) v_u_27, (ref) v_u_6, (ref) v_u_10, (ref) v_u_1, (ref) v_u_3, (ref) v_u_38, (ref) v_u_9
		local v_u_91 = p88.size
		local v92 = p88.lite
		local v_u_93 = p88.ability.radius * v_u_91
		local v_u_94 = p_u_39.ground(p89, 0)
		local v_u_95 = v_u_94 + Vector3.new(0, 6.5, 0) * v_u_91
		local v96 = p90 + 1.5
		local v_u_97 = p88.ability.tick or 0.5
		local v98 = {
			["shape"] = v_u_13
		}
		local v_u_99 = v_u_4.part(Vector3.new(1.5, 1.5, 1.5) * v_u_91, CFrame.new(v_u_95), v_u_11, v98)
		local v100 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_13
		}
		local v_u_101 = v_u_4.part(Vector3.new(2.8, 2.8, 2.8) * v_u_91, CFrame.new(v_u_95), v_u_7, v100)
		local v102 = {
			["shape"] = nil,
			["transparency"] = 0.8,
			["shape"] = v_u_13
		}
		local v_u_103 = v_u_4.part(Vector3.new(5, 5, 5) * v_u_91, CFrame.new(v_u_95), v_u_7, v102)
		local v104 = v_u_27(CFrame.new(v_u_94 + Vector3.new(0, 0.22, 0)), v_u_93, v_u_6.Ring, v_u_7, 0.35, true)
		local v_u_105 = v_u_27(CFrame.new(v_u_94 + Vector3.new(0, 0.26, 0)), 3.6 * v_u_91, v_u_6.Glow, v_u_10, 0)
		local v_u_106 = {
			v_u_99,
			v_u_101,
			v_u_103,
			v104,
			v_u_105
		}
		local v_u_107 = {}
		if not v92 then
			for _ = 1, 3 do
				local v108 = v_u_27(CFrame.new(v_u_95), 1 * v_u_91, v_u_6.PulsarTomoe, v_u_7, 0)
				table.insert(v_u_107, v108)
				table.insert(v_u_106, v108)
			end
		end
		for _, v109 in v_u_106 do
			v_u_1:AddItem(v109, v96)
		end
		local v110 = Instance.new("Attachment")
		v110.Parent = v_u_99
		local v_u_111 = {}
		for _ = 1, 2 do
			local v112 = Instance.new("Attachment")
			v112.WorldPosition = v_u_95
			v112.Parent = v_u_3.Terrain
			v_u_1:AddItem(v112, v96)
			table.insert(v_u_111, v112)
		end
		local v_u_113 = { v_u_38(v110, v_u_111[1], v_u_10, 0.9 * v_u_91, 7 * v_u_91), (v_u_38(v110, v_u_111[2], v_u_10, 0.9 * v_u_91, 6 * v_u_91)) }
		if not v92 then
			local v114 = v_u_38(v110, v_u_111[1], v_u_9, 0.35 * v_u_91, 1.6 * v_u_91)
			table.insert(v_u_113, v114)
			local v115 = v_u_38(v110, v_u_111[2], v_u_9, 0.35 * v_u_91, 1.8 * v_u_91)
			table.insert(v_u_113, v115)
		end
		if p88.mine then
			p_u_39.light(v_u_99, v_u_9, 18)
		end
		local v116 = v_u_93 / (6.5 * v_u_91)
		local v_u_117 = math.atan(v116)
		local v_u_118 = 6.5 * v_u_91 / math.cos(v_u_117)
		local v_u_119 = true
		local v_u_120 = os.clock()
		local v_u_121 = v_u_120
		local v_u_122 = 0
		local v_u_123 = 0
		p_u_39.runNow(function()
			-- upvalues: (ref) v_u_119, (copy) v_u_99, (ref) v_u_121, (copy) v_u_120, (ref) v_u_122, (copy) v_u_117, (copy) v_u_111, (copy) v_u_95, (copy) v_u_118, (copy) v_u_91, (copy) v_u_105, (copy) v_u_94, (ref) v_u_123, (copy) v_u_97, (ref) v_u_4, (ref) v_u_7, (copy) v_u_93, (ref) v_u_6, (ref) v_u_9, (copy) v_u_101, (copy) v_u_103, (copy) v_u_107, (ref) p_u_39, (ref) v_u_3
			if not (v_u_119 and v_u_99.Parent) then
				return false
			end
			local v124 = os.clock()
			local v125 = v124 - v_u_121
			local v126 = math.min(v125, 0.05)
			v_u_121 = v124
			local v127 = v124 - v_u_120
			v_u_122 = v_u_122 + v126 * 4.2
			local v128 = v_u_122
			local v129 = v_u_117
			local v130 = math.cos(v128) * math.sin(v129)
			local v131 = v_u_117
			local v132 = -math.cos(v131)
			local v133 = v_u_122
			local v134 = v_u_117
			local v135 = math.sin(v133) * math.sin(v134)
			local v136 = Vector3.new(v130, v132, v135)
			v_u_111[1].WorldPosition = v_u_95 + v136 * v_u_118
			v_u_111[2].WorldPosition = v_u_95 - v136 * 20 * v_u_91
			local v137 = v_u_95 + v136 * v_u_118
			local v138 = v_u_105
			local v139 = CFrame.new
			local v140 = v137.X
			local v141 = v_u_94.Y + 0.26
			local v142 = v137.Z
			v138.CFrame = v139((Vector3.new(v140, v141, v142))) * CFrame.Angles(0, v_u_122, 0)
			if v_u_123 <= v127 then
				v_u_123 = v_u_123 + v_u_97
				v_u_4.ring(v_u_94, v_u_7, v_u_93, 0.42, v_u_6.PulsarRipple)
				v_u_4.flash(v_u_95, v_u_9, 5 * v_u_91, 0.14)
			end
			local v143 = -(v127 % v_u_97 / v_u_97) * 6
			local v144 = math.exp(v143)
			v_u_101.Size = Vector3.new(1, 1, 1) * (v144 * 1.3 + 2.8) * v_u_91
			v_u_103.Size = Vector3.new(1, 1, 1) * (v144 * 2 + 5) * v_u_91
			v_u_103.Transparency = 0.8 - v144 * 0.25
			for v145, v146 in v_u_107 do
				local v147 = -v127 * 3.2 + (v145 - 1) * 3.141592653589793 * 2 / 3
				local v148 = v_u_95
				local v149 = math.cos(v147) * 3.2
				local v150 = v127 * 2 + v145
				local v151 = math.sin(v150) * 0.4
				local v152 = math.sin(v147) * 3.2
				local v153 = v148 + Vector3.new(v149, v151, v152) * v_u_91
				local v154 = p_u_39.facing
				local v155 = v_u_3.CurrentCamera
				local v156
				if v155 then
					local v157 = v155.CFrame.Position - v153
					v156 = v157.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v157.Unit
				else
					v156 = Vector3.new(0, 0, 1)
				end
				v146.CFrame = v154(v153, v156) * CFrame.Angles(0, v127 * 8, 0)
			end
			return true
		end)
		return function()
			-- upvalues: (ref) v_u_119, (ref) v_u_4, (copy) v_u_95, (ref) v_u_11, (copy) v_u_91, (ref) p_u_39, (ref) v_u_7, (copy) v_u_113, (copy) v_u_106, (copy) v_u_111
			v_u_119 = false
			v_u_4.flash(v_u_95, v_u_11, 7 * v_u_91, 0.2)
			p_u_39.burst("Impact", v_u_95, v_u_7, 1.2)
			for _, v158 in v_u_113 do
				v158:Destroy()
			end
			for _, v159 in v_u_106 do
				v159:Destroy()
			end
			for _, v160 in v_u_111 do
				v160:Destroy()
			end
		end
	end
	local v_u_162 = {}
	setmetatable(v_u_162, {
		["__mode"] = "k"
	})
	local v321 = {
		["pulsar_tomoe_a"] = {
			["cast"] = function(p163) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) v_u_57, (copy) p_u_39, (ref) v_u_6, (ref) v_u_9
				local v164 = p163.size
				local v165 = p163.eye + p163.dir * 1.2
				v_u_4.flash(v165, v_u_7, 3 * v164, 0.1)
				v_u_57(p_u_39.facing(v165, p163.dir), 0.6 * v164, 2.4 * v164, v_u_6.PulsarRipple, v_u_9, 0.15, 0, 0.1, true)
			end,
			["shot"] = v80,
			["impact"] = v87,
			["hit"] = function(_, p166, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_7
				p_u_39.burst("Impact", p166, v_u_7, 0.6)
			end
		},
		["pulsar_tomoe_e"] = {
			["castSound"] = "Orb",
			["loopSound"] = "ModeLoop",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["hit"] = nil,
			["cast"] = function(p167) -- name: cast
				-- upvalues: (copy) p_u_39, (ref) v_u_7, (copy) v_u_57, (ref) v_u_6
				p_u_39.skillCast(p167, v_u_7)
				local v168 = p167.size
				local v169 = p167.eye + p167.dir * 1.2
				v_u_57(p_u_39.facing(v169, -p167.dir), 0.8 * v168, 2.6 * v168, v_u_6.PulsarTomoe, v_u_7, 0.3, -14)
			end,
			["windup"] = function(p170, p171, p172) -- name: windup
				-- upvalues: (copy) p_u_39, (ref) v_u_9, (ref) v_u_11, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6
				local v173 = p170.size
				local v174 = p_u_39.ground(p171, 0)
				local v175 = v174 + Vector3.new(0, 6.5, 0) * v173
				local v176 = math.max(p172, 0.12)
				p_u_39.thin(p_u_39.rod(v175 + Vector3.new(0, 24, 0) * v173, v175, 1 * v173, v_u_9, 0.2), v176 + 0.1)
				p_u_39.pop(v175, v_u_11, 0.6 * v173, 3.5 * v173, v176, 0.2)
				v_u_4.ring(v174, v_u_7, p170.ability.radius * v173, 0.3, v_u_6.Ring)
			end,
			["zone"] = v161,
			["hit"] = function(p177, p178, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_7, (ref) v_u_9
				p_u_39.burst("Impact", p178, v_u_7, 0.55)
				if not p177.lite then
					p_u_39.glint(p178, v_u_9, 2, 0.1)
				end
			end
		},
		["pulsar_tomoe_r"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p179) -- name: cast
				-- upvalues: (copy) p_u_39, (ref) v_u_7, (copy) v_u_57, (ref) v_u_6, (ref) v_u_4
				p_u_39.skillCast(p179, v_u_7, true)
				local v180 = p179.size
				local v181 = p179.eye + p179.dir * 1.4
				v_u_57(p_u_39.facing(v181, -p179.dir), 1 * v180, 4 * v180, v_u_6.PulsarTomoe, v_u_7, 0.32, -12)
				if p179.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p182, p183, p184) -- name: windup
				-- upvalues: (copy) p_u_39, (ref) v_u_11
				local v185 = p182.size
				local v186 = p_u_39.ground(p183, 0)
				local v187 = math.max(p184, 0.12)
				p_u_39.pop(v186 + Vector3.new(0, 2.5, 0) * v185, v_u_11, 0.4 * v185, 2.6 * v185, v187, 0.1)
				p_u_39.glint(v186 + Vector3.new(0, 2.5, 0) * v185, v_u_11, 5, v187 + 0.05)
			end,
			["zone"] = function(p188, p189, p_u_190) -- name: spread
				-- upvalues: (copy) p_u_39, (ref) v_u_27, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_1, (ref) v_u_4, (ref) v_u_11, (ref) v_u_13, (copy) v_u_162, (ref) v_u_31, (ref) v_u_3
				local v_u_191 = p188.size
				local v_u_192 = p188.lite
				local v_u_193 = p188.ability.radius * v_u_191
				local v_u_194 = p_u_39.ground(p189, 0)
				local v195 = p_u_190 + 1
				local v_u_196 = p188.ability.tick or 0.4
				local v_u_197 = v_u_192 and 3 or 5
				local v_u_198 = {}
				local v_u_199 = {}
				local v_u_200 = {}
				for v201 = 1, v_u_197 do
					local v202 = v_u_27
					local v203 = CFrame.new(v_u_194 + Vector3.new(0, 1, 0) * (0.2 + (v201 - 1) * 0.45 * v_u_191))
					local v204 = 0.1
					local v205
					if v201 % 2 == 1 then
						v205 = v_u_6.PulsarRipple
					else
						v205 = v_u_6.Ring
					end
					local v206
					if v201 % 2 == 0 then
						v206 = v_u_9
					else
						v206 = v_u_7
					end
					local v207 = v202(v203, v204, v205, v206, 0.05, true)
					v_u_1:AddItem(v207, v195)
					table.insert(v_u_200, v207)
					local v208 = v_u_193 * (v201 * 0.78 / v_u_197 + 0.22)
					table.insert(v_u_198, v208)
					table.insert(v_u_199, 0.1)
				end
				local v209 = {
					["shape"] = v_u_13
				}
				local v_u_210 = v_u_4.part(Vector3.new(2, 2, 2) * v_u_191, CFrame.new(v_u_194 + Vector3.new(0, 2.5, 0) * v_u_191), v_u_11, v209)
				local v211 = {
					["shape"] = nil,
					["transparency"] = 0.45,
					["shape"] = v_u_13
				}
				local v_u_212 = v_u_4.part(Vector3.new(3.6, 3.6, 3.6) * v_u_191, CFrame.new(v_u_194 + Vector3.new(0, 2.5, 0) * v_u_191), v_u_7, v211)
				v_u_1:AddItem(v_u_210, v195)
				v_u_1:AddItem(v_u_212, v195)
				local v_u_213 = p_u_39.pillar(v_u_194, 11 * v_u_191, 2.4 * v_u_191, v_u_7, 0.55)
				local v_u_214 = p_u_39.pillar(v_u_194, 11 * v_u_191, 0.8 * v_u_191, v_u_11, 0.2)
				v_u_1:AddItem(v_u_213, v195)
				v_u_1:AddItem(v_u_214, v195)
				local v_u_215 = {}
				for _ = 1, 3 do
					local v216 = v_u_27(CFrame.new(v_u_194), 2.1 * v_u_191, v_u_6.PulsarTomoe, v_u_7, 0)
					v_u_1:AddItem(v216, v195)
					table.insert(v_u_215, v216)
				end
				v_u_162[p188] = {
					["g"] = v_u_194,
					["rings"] = v_u_200,
					["now"] = v_u_199,
					["tomoe"] = v_u_215,
					["core"] = v_u_210,
					["shell"] = v_u_212,
					["extra"] = { v_u_213, v_u_214 }
				}
				local v_u_217 = true
				local v_u_218 = os.clock()
				local v_u_219 = 0.55
				local v_u_220 = -10
				p_u_39.runNow(function()
					-- upvalues: (ref) v_u_217, (copy) v_u_210, (copy) v_u_218, (ref) v_u_219, (copy) v_u_196, (ref) v_u_220, (copy) v_u_192, (ref) p_u_39, (copy) v_u_194, (ref) v_u_9, (copy) v_u_193, (copy) v_u_200, (copy) v_u_198, (copy) v_u_199, (copy) v_u_197, (ref) v_u_31, (copy) v_u_212, (copy) v_u_191, (copy) v_u_213, (copy) p_u_190, (copy) v_u_215, (ref) v_u_3
					if not (v_u_217 and v_u_210.Parent) then
						return false
					end
					local v221 = os.clock() - v_u_218
					if v_u_219 <= v221 then
						v_u_219 = v_u_219 + v_u_196
						v_u_220 = v221
						if not v_u_192 then
							p_u_39.inward(v_u_194 + Vector3.new(0, 1.5, 0), v_u_9, 4, v_u_193, 0.3)
						end
					end
					local v222 = (v221 - 0.5) / 0.2
					local v223 = math.clamp(v222, 0, 1)
					for v224, v225 in v_u_200 do
						local v226 = (v221 - (v224 - 1) * 0.07) / 0.45
						local v227 = math.clamp(v226, 0, 1)
						local v228 = v221 * 18 + v224 * 1.7
						local v229 = math.sin(v228) * 0.035 * v223 + 1
						local v230 = v_u_198[v224]
						local v231 = v227 - 1
						local v232 = v230 * (v231 * 3.2 * v231 * v231 + 1 + v231 * 2.2 * v231) * v229
						local v233 = math.max(v232, 0.1)
						v_u_199[v224] = v233
						local v234 = v233 * 2
						local v235 = v233 * 2
						v225.Size = Vector3.new(v234, 0.05, v235)
						local v236 = v221 - v_u_220 - (v_u_197 - v224) * 0.05
						local v237 = v_u_31
						local v238 = 0.14 - 0.14 * ((v236 < 0 or v236 >= 0.15) and 0 or 1 - v236 / 0.15)
						local v239 = v221 * 9 + v224
						local v240 = v238 + math.sin(v239) * 0.08
						v237(v225, (math.max(v240, 0)))
					end
					local v241 = v221 - v_u_220
					local v242 = -math.max(v241, 0) * 6
					local v243 = math.exp(v242)
					v_u_212.Size = Vector3.new(1, 1, 1) * (v243 * 1.6 + 3.6) * v_u_191
					local v244 = v_u_213
					local v245 = 11 * v_u_191
					local v246 = (v243 * 1.2 + 2.4) * v_u_191
					local v247 = (v243 * 1.2 + 2.4) * v_u_191
					v244.Size = Vector3.new(v245, v246, v247)
					v_u_213.Transparency = 0.55 - v243 * 0.2
					local v248 = v221 - 0.5
					local v249 = p_u_190 - 0.6
					local v250 = v248 / math.max(v249, 0.1)
					local v251 = math.clamp(v250, 0, 1)
					for v252, v253 in v_u_215 do
						local v254 = v221 * 2.4 + (v252 - 1) * 3.141592653589793 * 2 / 3
						local v255 = v_u_193 * (0.95 - v251 * 0.5)
						local v256 = v_u_194
						local v257 = math.cos(v254) * v255
						local v258 = 3.5 * v_u_191
						local v259 = math.sin(v254) * v255
						local v260 = v256 + Vector3.new(v257, v258, v259)
						local v261 = p_u_39.facing
						local v262 = v_u_3.CurrentCamera
						local v263
						if v262 then
							local v264 = v262.CFrame.Position - v260
							v263 = v264.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v264.Unit
						else
							v263 = Vector3.new(0, 0, 1)
						end
						v253.CFrame = v261(v260, v263) * CFrame.Angles(0, -v221 * 7, 0)
					end
					return true
				end)
				return function()
					-- upvalues: (ref) v_u_217, (ref) p_u_39, (copy) v_u_213, (copy) v_u_214, (copy) v_u_199, (copy) v_u_194, (copy) v_u_191, (ref) v_u_4, (copy) v_u_193, (ref) v_u_7, (ref) v_u_13, (ref) v_u_1, (copy) v_u_200, (ref) v_u_31, (copy) v_u_215, (ref) v_u_3
					v_u_217 = false
					p_u_39.thin(v_u_213, 0.12)
					p_u_39.thin(v_u_214, 0.12)
					local v_u_265 = table.clone(v_u_199)
					local v266 = v_u_194 + Vector3.new(0, 2.5, 0) * v_u_191
					local v267 = {
						["shape"] = nil,
						["transparency"] = 0.7,
						["shape"] = v_u_13
					}
					local v_u_268 = v_u_4.part(Vector3.new(1, 1, 1) * v_u_193 * 2, CFrame.new(v266), v_u_7, v267)
					v_u_1:AddItem(v_u_268, 0.3)
					p_u_39.animate(0.12, 0, function(p269)
						-- upvalues: (ref) v_u_200, (copy) v_u_265, (ref) v_u_31, (ref) v_u_215, (ref) v_u_193, (ref) v_u_194, (ref) v_u_191, (ref) p_u_39, (ref) v_u_3, (copy) v_u_268
						local v270 = p269 * p269
						for v271, v272 in v_u_200 do
							local v273 = v_u_265[v271] * (1 - v270)
							local v274 = math.max(v273, 0.2)
							local v275 = v274 * 2
							local v276 = v274 * 2
							v272.Size = Vector3.new(v275, 0.05, v276)
							v_u_31(v272, 0.05 + 0.5 * p269)
						end
						for v277, v278 in v_u_215 do
							local v279 = (v277 - 1) * 3.141592653589793 * 2 / 3
							local v280 = v_u_193 * 0.45 * (1 - v270)
							local v281 = v_u_194
							local v282 = math.cos(v279) * v280
							local v283 = 3.5 * v_u_191 - 1 * v270
							local v284 = math.sin(v279) * v280
							local v285 = v281 + Vector3.new(v282, v283, v284)
							local v286 = p_u_39.facing
							local v287 = v_u_3.CurrentCamera
							local v288
							if v287 then
								local v289 = v287.CFrame.Position - v285
								v288 = v289.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v289.Unit
							else
								v288 = Vector3.new(0, 0, 1)
							end
							v278.CFrame = v286(v285, v288)
						end
						local v290 = v_u_268
						local v291 = v_u_193 * 2 * (1 - v270)
						v290.Size = Vector3.new(1, 1, 1) * math.max(v291, 0.5)
						v_u_268.Transparency = 0.7 - 0.5 * p269
						if p269 >= 1 then
							v_u_268:Destroy()
						end
					end)
				end
			end,
			["finish"] = function(p292, p293) -- name: crush
				-- upvalues: (copy) v_u_162, (copy) p_u_39, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_3, (copy) v_u_57, (ref) v_u_8, (ref) v_u_12, (ref) v_u_5
				local v294 = p292.size
				local v295 = p292.lite
				local v296 = p292.ability.radius * v294
				local v297 = v_u_162[p292]
				v_u_162[p292] = nil
				local v298
				if v297 then
					v298 = v297.g
				else
					v298 = p_u_39.ground(p293, 0)
				end
				if v297 then
					for _, v299 in v297.rings do
						v299:Destroy()
					end
					for _, v300 in v297.tomoe do
						v300:Destroy()
					end
					v297.core:Destroy()
					v297.shell:Destroy()
					for _, v301 in v297.extra do
						v301:Destroy()
					end
				end
				local v302 = v298 + Vector3.new(0, 2.5, 0) * v294
				v_u_4.flash(v302, v_u_11, 16 * v294, 0.22)
				p_u_39.pop(v302, v_u_7, 3 * v294, v296 * 1.7, 0.4, 0.3)
				p_u_39.pop(v302, v_u_11, 2 * v294, 8 * v294, 0.2)
				v_u_4.ring(v298, v_u_7, v296 * 1.1, 0.45, v_u_6.PulsarRipple)
				v_u_4.ring(v298, v_u_9, v296 * 1.3, 0.55, v_u_6.Shockwave)
				p_u_39.burst("Impact", v302, v_u_7, 2.6)
				p_u_39.burst("Flash", v302, v_u_9, 0.6)
				p_u_39.spikes(v302, v_u_9, v295 and 6 or 12, v296 * 1.1, 0.3, nil, nil, true)
				local v303 = v298 + Vector3.new(0, 9, 0) * v294
				local v304 = v_u_3.CurrentCamera
				local v305
				if v304 then
					local v306 = v304.CFrame.Position - v303
					v305 = v306.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v306.Unit
				else
					v305 = Vector3.new(0, 0, 1)
				end
				local v307 = p_u_39.facing(v303, v305)
				v_u_57(v307, 3 * v294, 13 * v294, v_u_6.PulsarRipple, v_u_9, 0.5, 0, 0)
				v_u_57(v307 * CFrame.new(0, 0.06, 0), 1.6 * v294, 6 * v294, p_u_39.iris("pulsar_tomoe"), Color3.new(1, 1, 1), 0.5, 2)
				if not v295 then
					local v308 = { v_u_7, v_u_8, v_u_12 }
					p_u_39.chunks(v298 + Vector3.new(0, 1, 0), v308, 10, 40, 1, 1.1, true, 0.8)
					for v309 = 0, 2 do
						local v310 = v309 * 3.141592653589793 * 2 / 3
						local v311 = math.cos(v310)
						local v312 = math.sin(v310)
						local v313 = v298 + Vector3.new(v311, 0, v312) * v296 * 0.6 + Vector3.new(0, 3, 0) * v294
						local v314 = v_u_57
						local v315 = p_u_39.facing
						local v316 = v_u_3.CurrentCamera
						local v317
						if v316 then
							local v318 = v316.CFrame.Position - v313
							v317 = v318.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v318.Unit
						else
							v317 = Vector3.new(0, 0, 1)
						end
						v314(v315(v313, v317), 1 * v294, 3.4 * v294, v_u_6.PulsarTomoe, v_u_7, 0.35, -14)
					end
				end
				v_u_5.play("Explosion", {
					["at"] = v298,
					["volume"] = p292.mine and 1 or 0.6
				})
				if p292.mine then
					v_u_4.shake(0.6, 0.5)
				end
			end,
			["hit"] = function(p319, p320, _) -- name: hit
				-- upvalues: (copy) p_u_39, (ref) v_u_7, (ref) v_u_9
				p_u_39.burst("Impact", p320, v_u_7, 0.8)
				if not p319.lite then
					p_u_39.glint(p320, v_u_9, 2.6, 0.12)
				end
			end
		}
	}
	return v321
end