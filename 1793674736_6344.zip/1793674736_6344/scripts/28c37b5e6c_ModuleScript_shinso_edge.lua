local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("D8DCE8")
local v_u_8 = Color3.fromHex("8A3CFF")
local v_u_9 = Color3.fromRGB(205, 170, 255)
local v_u_10 = Color3.fromRGB(176, 70, 255)
local v_u_11 = Color3.fromRGB(70, 14, 130)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.PartType.Wedge
local function v_u_32(p14, p15, p16, p17) -- name: newBlade
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_13, (copy) v_u_1, (copy) v_u_8
	local v18 = p14 * 1.6
	local v19 = v_u_4.part(Vector3.new(p14, p15, 0.05), CFrame.identity, v_u_7)
	local v20 = v_u_4.part
	local v21 = p14 / 2
	local v22 = {
		["shape"] = v_u_13
	}
	local v23 = v20(Vector3.new(p15, v21, v18), CFrame.identity, v_u_7, v22)
	local v24 = v_u_4.part
	local v25 = p14 / 2
	local v26 = {
		["shape"] = v_u_13
	}
	local v27 = v24(Vector3.new(p15, v25, v18), CFrame.identity, v_u_7, v26)
	v_u_1:AddItem(v19, p17)
	v_u_1:AddItem(v23, p17)
	v_u_1:AddItem(v27, p17)
	local v28
	if p16 then
		local v29 = v_u_4.part
		local v30 = p14 * 1.7
		local v31 = p15 * 2.5
		v28 = v29(Vector3.new(v30, v31, 0.05), CFrame.identity, v_u_8, {
			["transparency"] = 0.68
		})
		v_u_1:AddItem(v28, p17)
	else
		v28 = nil
	end
	return {
		["body"] = v19,
		["glow"] = v28,
		["tipA"] = v23,
		["tipB"] = v27,
		["width"] = p14,
		["thick"] = p15,
		["tip"] = v18
	}
end
local function v_u_45(p33, p34, p35) -- name: placeBlade
	local v36 = math.max(p35, 0.05)
	local v37 = p33.body
	local v38 = p33.width
	local v39 = p33.thick
	v37.Size = Vector3.new(v38, v39, v36)
	p33.body.CFrame = p34 * CFrame.new(0, 0, -v36 / 2)
	local v40 = p33.glow
	if v40 then
		local v41 = v36 + p33.tip * 0.7
		local v42 = p33.width * 1.7
		local v43 = p33.thick * 2.5
		v40.Size = Vector3.new(v42, v43, v41)
		v40.CFrame = p34 * CFrame.new(0, 0, -v41 / 2)
	end
	local v44 = p34 * CFrame.new(0, 0, -v36 - p33.tip / 2)
	p33.tipA.CFrame = v44 * CFrame.new(p33.width / 4, 0, 0) * CFrame.Angles(0, 0, -1.5707963267948966)
	p33.tipB.CFrame = v44 * CFrame.new(-p33.width / 4, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
end
local function v_u_52(p46, p47, p48, p49) -- name: boil
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1
	local v50 = Instance.new("Attachment")
	v50.WorldPosition = p46
	v50.Parent = v_u_3.Terrain
	local v_u_51 = Instance.new("ParticleEmitter")
	v_u_51.Texture = v_u_6.Glow
	v_u_51.Color = ColorSequence.new(v_u_9, v_u_10)
	v_u_51.LightEmission = 0.7
	v_u_51.LightInfluence = 0
	v_u_51.Lifetime = NumberRange.new(0.4, 0.7)
	v_u_51.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p47 * 0.4), NumberSequenceKeypoint.new(0.3, p47), NumberSequenceKeypoint.new(1, 0) })
	v_u_51.Transparency = NumberSequence.new(0.1, 0.6)
	v_u_51.Speed = NumberRange.new(2, 6)
	v_u_51.SpreadAngle = Vector2.new(35, 35)
	v_u_51.EmissionDirection = Enum.NormalId.Top
	v_u_51.Acceleration = Vector3.new(0, 6, 0)
	v_u_51.Rate = p48
	v_u_51.Parent = v50
	task.delay(p49, function()
		-- upvalues: (copy) v_u_51
		v_u_51.Enabled = false
	end)
	v_u_1:AddItem(v50, p49 + 0.8)
end
return function(p_u_53)
	-- upvalues: (copy) v_u_32, (copy) v_u_45, (copy) v_u_3, (copy) v_u_4, (copy) v_u_12, (copy) v_u_1, (copy) v_u_8, (copy) v_u_7, (copy) v_u_6, (copy) v_u_9, (copy) v_u_10, (copy) v_u_52, (copy) v_u_11, (copy) v_u_5
	local function v_u_81(p54, p55, p56, p57, p58, p_u_59, p_u_60, p_u_61, p_u_62) -- name: lunge
		-- upvalues: (copy) p_u_53, (ref) v_u_32, (ref) v_u_45
		local v63 = p55 - p54
		local v64 = v63.Magnitude
		local v_u_65 = math.max(v64, 1)
		local v_u_66 = p_u_53.aimAt(p54, v63)
		local v_u_67 = v_u_32(p56, p57, p58, p_u_59 + p_u_60 + p_u_61 + 1)
		local v_u_68 = p_u_59 + p_u_60 + p_u_61
		local v_u_69 = false
		v_u_45(v_u_67, v_u_66, 0.05)
		p_u_53.animate(v_u_68, 0, function(p70)
			-- upvalues: (copy) v_u_68, (copy) p_u_59, (copy) p_u_60, (copy) p_u_61, (ref) v_u_69, (copy) p_u_62, (ref) v_u_45, (copy) v_u_67, (copy) v_u_66, (copy) v_u_65
			local v71 = p70 * v_u_68
			local v72
			if v71 < p_u_59 then
				local v73 = v71 / p_u_59
				v72 = 1 - (1 - v73) * (1 - v73)
			elseif v71 < p_u_59 + p_u_60 then
				v72 = 1
			else
				local v74 = (v71 - p_u_59 - p_u_60) / p_u_61
				v72 = 1 - v74 * v74
			end
			if p_u_59 <= v71 and not v_u_69 then
				v_u_69 = true
				if p_u_62 then
					p_u_62()
				end
			end
			local v75 = v_u_45
			local v76 = v_u_67
			local v77 = v_u_66
			local v78 = (v_u_65 - v_u_67.tip) * v72
			v75(v76, v77, (math.max(v78, 0.05)))
			if p70 >= 1 then
				local v79 = v_u_67
				v79.body:Destroy()
				v79.tipA:Destroy()
				v79.tipB:Destroy()
				local v80 = v79.glow
				if v80 then
					v80:Destroy()
				end
			end
		end)
	end
	local function v_u_100(p82, p83, p84) -- name: crossCut
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_12, (ref) v_u_1, (ref) v_u_8
		local v85 = v_u_3.CurrentCamera
		local v86
		if v85 then
			local v87 = v85.CFrame.Position - p82
			v86 = v87.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v87.Unit
		else
			v86 = Vector3.new(0, 0, 1)
		end
		local v88 = CFrame.lookAt(p82 + v86 * 0.4, p82 + v86 * 2)
		for _, v89 in { 0.6981317007977318, -0.6981317007977318 } do
			local v90 = v88 * CFrame.Angles(0, 0, v89)
			local v91 = v_u_4.part
			local v92 = p83 * 0.25
			local v93 = v91(Vector3.new(v92, 0.22, 0.1), v90, v_u_12)
			v_u_4.tween(v93, p84, {
				["Size"] = nil,
				["Transparency"] = 1,
				["Size"] = Vector3.new(p83, 0.04, 0.1)
			})
			v_u_1:AddItem(v93, p84 + 0.05)
			local v94 = v_u_4.part
			local v95 = p83 * 0.3
			local v96 = v94(Vector3.new(v95, 0.6, 0.08), v90, v_u_8, {
				["transparency"] = 0.5
			})
			local v97 = v_u_4.tween
			local v98 = {
				["Size"] = nil,
				["Transparency"] = 1
			}
			local v99 = p83 * 1.1
			v98.Size = Vector3.new(v99, 0.1, 0.08)
			v97(v96, p84, v98)
			v_u_1:AddItem(v96, p84 + 0.05)
		end
	end
	local function v_u_118(p101, p102, p103, p104, p105) -- name: airRing
		-- upvalues: (ref) v_u_4, (copy) p_u_53, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1
		local v106 = v_u_4.part
		local v107 = p103 * 2
		local v108 = p103 * 2
		local v109 = v106(Vector3.new(v107, 0.05, v108), p_u_53.facing(p101, p102), v_u_7, {
			["transparency"] = 1
		})
		local v110 = {}
		for _, v111 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v112 = Instance.new("Decal")
			v112.Face = v111
			v112.Texture = v_u_6.Ring
			v112.Color3 = v_u_9
			v112.Parent = v109
			table.insert(v110, v112)
		end
		local v113 = v_u_4.tween
		local v114 = {}
		local v115 = p104 * 2
		local v116 = p104 * 2
		v114.Size = Vector3.new(v115, 0.05, v116)
		v113(v109, p105, v114)
		for _, v117 in v110 do
			v_u_4.tween(v117, p105, {
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
		v_u_1:AddItem(v109, p105 + 0.05)
	end
	local v168 = {
		["shinso_edge_a"] = {
			["cast"] = function(p119) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) p_u_53, (ref) v_u_12
				local v120 = p119.size
				local v121 = p119.eye + p119.dir * 1.2 - Vector3.new(0, 0.5, 0)
				v_u_4.flash(v121, v_u_8, 2.6 * v120, 0.1)
				p_u_53.pop(v121, v_u_12, 1 * v120, 0.2 * v120, 0.08)
			end,
			["beam"] = function(p_u_122, p123, p124) -- name: beam
				-- upvalues: (copy) v_u_81, (copy) p_u_53, (ref) v_u_12, (ref) v_u_4, (ref) v_u_8
				local v_u_125 = p_u_122.size
				local v126 = p123 + p_u_122.dir * 1.2 - Vector3.new(0, 0.5, 0)
				local v127 = p124.X
				local v128 = v126.Y - 0.5
				local v129 = p124.Z
				local v_u_130 = Vector3.new(v127, v128, v129)
				v_u_81(v126, v_u_130, 0.62 * v_u_125, 0.1 * v_u_125, not p_u_122.lite, 0.06, 0.04, 0.1, function()
					-- upvalues: (ref) p_u_53, (copy) v_u_130, (ref) v_u_12, (copy) v_u_125, (copy) p_u_122, (ref) v_u_4, (ref) v_u_8
					p_u_53.glint(v_u_130, v_u_12, 3.4 * v_u_125, 0.12)
					if not p_u_122.lite then
						v_u_4.flash(v_u_130, v_u_8, 3 * v_u_125, 0.12)
					end
				end)
			end,
			["hit"] = function(p131, p132, _) -- name: hit
				-- upvalues: (copy) p_u_53, (ref) v_u_8
				p_u_53.burst("Impact", p132, v_u_8, 0.55)
				p_u_53.beamHitSound(p131, p132, "Hit")
			end
		},
		["shinso_edge_e"] = {
			["cast"] = function(p_u_133) -- name: cast
				-- upvalues: (copy) p_u_53, (ref) v_u_8, (copy) v_u_81
				p_u_53.skillCast(p_u_133, v_u_8)
				local v_u_134 = p_u_133.size
				if not p_u_133.lite then
					local v_u_135 = p_u_133.eye + p_u_133.dir * 0.8 - Vector3.new(0, 0.4, 0)
					for v136 = 1, 4 do
						p_u_53.after((v136 - 1) * 0.035, function()
							-- upvalues: (copy) p_u_133, (ref) v_u_81, (copy) v_u_135, (copy) v_u_134
							local v137 = (math.random() - 0.5) * 1.2217304763960306
							local v138 = (math.random() - 0.5) * 0.5
							v_u_81(v_u_135, v_u_135 + (CFrame.Angles(0, v137, 0):VectorToWorldSpace(p_u_133.dir) + Vector3.new(0, 1, 0) * v138).Unit * 6 * v_u_134, 0.32 * v_u_134, 0.06 * v_u_134, false, 0.04, 0.02, 0.06)
						end)
					end
				end
			end,
			["shot"] = function(p139, p140) -- name: renjinShot
				-- upvalues: (ref) v_u_32, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (copy) p_u_53, (ref) v_u_9, (ref) v_u_8, (ref) v_u_45
				local v141 = p139.size
				local v_u_142 = p140.Position
				local v_u_143 = v_u_32(0.5 * v141, 0.09 * v141, not p139.lite, 4)
				local v_u_144 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p140, v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_144, 4)
				p_u_53.streak(v_u_144, v_u_9, v_u_8, 0.45 * v141, 0.1)
				v_u_45(v_u_143, p140, 0.05)
				local v_u_145 = v_u_142
				local v_u_146 = false
				return {
					["place"] = function(p147, _) -- name: place
						-- upvalues: (copy) v_u_144, (ref) v_u_145, (copy) v_u_142, (ref) v_u_45, (copy) v_u_143, (ref) p_u_53
						v_u_144.CFrame = p147
						v_u_145 = p147.Position
						local v148 = (v_u_145 - v_u_142).Magnitude
						local v149 = v_u_45
						local v150 = v_u_143
						local v151 = p_u_53.aimAt(v_u_142, v_u_145 - v_u_142)
						local v152 = v148 - v_u_143.tip
						v149(v150, v151, (math.max(v152, 0.05)))
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_146, (ref) v_u_1, (copy) v_u_144, (ref) p_u_53, (copy) v_u_142, (ref) v_u_145, (copy) v_u_143, (ref) v_u_45
						if not v_u_146 then
							v_u_146 = true
							v_u_1:AddItem(v_u_144, 0.2)
							local v_u_153 = p_u_53.aimAt(v_u_142, v_u_145 - v_u_142)
							local v154 = (v_u_145 - v_u_142).Magnitude - v_u_143.tip
							local v_u_155 = math.max(v154, 0.05)
							p_u_53.animate(0.13, 0, function(p156)
								-- upvalues: (ref) v_u_45, (ref) v_u_143, (copy) v_u_153, (copy) v_u_155
								local v157 = v_u_45
								local v158 = v_u_143
								local v159 = v_u_153
								local v160 = v_u_155 * (1 - p156 * p156)
								v157(v158, v159, (math.max(v160, 0.05)))
								if p156 >= 1 then
									local v161 = v_u_143
									v161.body:Destroy()
									v161.tipA:Destroy()
									v161.tipB:Destroy()
									local v162 = v161.glow
									if v162 then
										v162:Destroy()
									end
								end
							end)
						end
					end
				}
			end,
			["impact"] = function(p163, p164) -- name: impact
				-- upvalues: (copy) v_u_100, (copy) p_u_53, (ref) v_u_8, (ref) v_u_12, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
				local v165 = p163.size
				v_u_100(p164, 5.5 * v165, 0.2)
				p_u_53.pop(p164, v_u_8, 1.2 * v165, 4 * v165, 0.2, 0.4)
				p_u_53.glint(p164, v_u_12, 3.6 * v165, 0.14)
				p_u_53.burst("Impact", p164, v_u_8, 0.9 * v165)
				if not p163.lite then
					v_u_4.ring(p_u_53.ground(p164), v_u_9, p163.ability.radius * 1.1 * v165, 0.25, v_u_6.Ring)
				end
				p_u_53.hitSound(p164)
			end,
			["hit"] = function(p166, p167, _) -- name: hit
				-- upvalues: (copy) p_u_53, (ref) v_u_8, (ref) v_u_7
				p_u_53.burst("Impact", p167, v_u_8, 0.7)
				if not p166.lite then
					p_u_53.glint(p167, v_u_7, 2.4, 0.12)
				end
			end
		}
	}
	local function v_u_183(p_u_169, p170, p171) -- name: poison
		-- upvalues: (copy) p_u_53, (ref) v_u_10, (ref) v_u_6, (ref) v_u_52, (ref) v_u_11, (ref) v_u_9, (ref) v_u_5, (ref) v_u_4
		local v_u_172 = p_u_169.lite
		local v_u_173 = p_u_169.size
		local v174 = p_u_53.ground(p170, 0.3)
		local v175 = p_u_53.ground(p171, 0.3)
		local v176 = (v175 - v174).Magnitude / (v_u_172 and 18 or 9)
		local v177 = math.floor(v176)
		local v178 = math.max(v177, 2)
		p_u_53.groundLine(v174, v175, 3.4 * v_u_173, v_u_10, 1.6, 0.35)
		for v_u_179 = 1, v178 do
			local v_u_180 = v174:Lerp(v175, (v_u_179 - 0.5) / v178)
			p_u_53.after(v_u_179 * 0.04, function()
				-- upvalues: (ref) p_u_53, (copy) v_u_180, (ref) v_u_10, (copy) v_u_173, (ref) v_u_6, (copy) v_u_172, (ref) v_u_52
				p_u_53.mark(v_u_180, v_u_10, 3.2 * v_u_173, 1.4, v_u_6.Glow, 0.25)
				if not v_u_172 then
					v_u_52(v_u_180 + Vector3.new(0, 0.5, 0), 4 * v_u_173, 18, 0.55)
				end
			end)
			p_u_53.after(v_u_179 * 0.05 + 0.45, function()
				-- upvalues: (copy) v_u_180, (ref) p_u_53, (ref) v_u_10, (copy) v_u_173, (ref) v_u_11, (copy) v_u_172, (ref) v_u_9, (copy) v_u_179, (ref) v_u_5, (copy) p_u_169
				local v181 = v_u_180 + Vector3.new(0, 1.6, 0)
				p_u_53.pop(v181, v_u_10, 1.5 * v_u_173, 7 * v_u_173, 0.3, 0.35)
				p_u_53.pop(v181, v_u_11, 3 * v_u_173, 0.4 * v_u_173, 0.22, 0.2, Enum.Material.SmoothPlastic)
				p_u_53.burst("Impact", v181, v_u_10, 1.1 * v_u_173)
				if not v_u_172 then
					local v182 = { v_u_10, v_u_9 }
					p_u_53.chunks(v181, v182, 3, 14 * v_u_173, 0.35 * v_u_173, 0.6, true, 0.6)
				end
				if v_u_179 % 3 == 1 then
					v_u_5.play("Hit", {
						["at"] = v181,
						["volume"] = p_u_169.mine and 0.45 or 0.25
					})
				end
			end)
		end
		if p_u_169.mine then
			p_u_53.after(0.5, function()
				-- upvalues: (ref) v_u_4
				v_u_4.shake(0.2, 0.25)
			end)
		end
	end
	v168.shinso_edge_r = {
		["cast"] = function(p184) -- name: cast
			-- upvalues: (copy) p_u_53, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4
			p_u_53.skillCast(p184, v_u_8, true)
			p_u_53.burst("Flash", p184.eye, v_u_9, 0.3)
			if p184.mine then
				v_u_4.shake(0.12, 0.15)
			end
		end,
		["windup"] = function(p_u_185, p186, p187) -- name: windup
			-- upvalues: (ref) v_u_32, (copy) p_u_53, (ref) v_u_45, (ref) v_u_9, (ref) v_u_8
			local v_u_188 = p_u_185.size
			local v189 = math.max(p187, 0.12)
			local v_u_190 = p186 + p_u_185.dir * 1.6 - Vector3.new(0, 0.6, 0)
			local v191 = p_u_185.dir:Cross(Vector3.new(0, 1, 0))
			for v192 = 0, 2 do
				local v193 = v192 * 3.141592653589793 * 2 / 3 + 1.5707963267948966
				local v_u_194 = v_u_190 + (v191 * math.cos(v193) + Vector3.new(0, 1, 0) * math.sin(v193)) * 4 * v_u_188 - p_u_185.dir * 1.5
				local v_u_195 = v_u_32(0.36 * v_u_188, 0.07 * v_u_188, false, v189 + 0.5)
				p_u_53.animate(v189, 0, function(p196)
					-- upvalues: (copy) v_u_194, (copy) v_u_190, (ref) v_u_45, (copy) v_u_195, (ref) p_u_53, (copy) p_u_185, (copy) v_u_188
					local v197 = p196 * p196
					local v198 = v_u_194:Lerp(v_u_190, v197)
					v_u_45(v_u_195, p_u_53.aimAt(v198, v_u_190 - v_u_194 + p_u_185.dir * 2), 2.2 * v_u_188 * (1 - v197 * 0.6))
					if p196 >= 1 then
						local v199 = v_u_195
						v199.body:Destroy()
						v199.tipA:Destroy()
						v199.tipB:Destroy()
						local v200 = v199.glow
						if v200 then
							v200:Destroy()
						end
					end
				end)
			end
			p_u_53.inward(v_u_190, v_u_9, p_u_185.lite and 4 or 8, 7 * v_u_188, v189)
			p_u_53.pop(v_u_190, v_u_8, 0.6 * v_u_188, 3.2 * v_u_188, v189 + 0.05, 0.4)
		end,
		["beam"] = function(p_u_201, p202, p203) -- name: beam
			-- upvalues: (copy) p_u_53, (ref) v_u_12, (ref) v_u_4, (ref) v_u_8, (copy) v_u_81, (copy) v_u_118, (ref) v_u_7, (copy) v_u_183
			local v_u_204 = p_u_201.size
			local v_u_205 = p_u_201.lite
			local v_u_206 = p202 + p_u_201.dir * 1.6 - Vector3.new(0, 0.6, 0)
			local v207 = p203.X
			local v208 = v_u_206.Y - 0.2
			local v209 = p203.Z
			local v_u_210 = Vector3.new(v207, v208, v209)
			local v_u_211 = (v_u_210 - v_u_206).Unit
			p_u_53.pop(v_u_206, v_u_12, 2 * v_u_204, 6 * v_u_204, 0.2)
			v_u_4.flash(v_u_206, v_u_8, 8 * v_u_204, 0.25)
			v_u_81(v_u_206, v_u_210, 3.2 * v_u_204, 0.4 * v_u_204, true, 0.12, 0.3, 0.18, function()
				-- upvalues: (ref) p_u_53, (copy) v_u_210, (ref) v_u_12, (copy) v_u_204, (ref) v_u_4, (ref) v_u_8, (copy) v_u_205, (copy) v_u_206, (ref) v_u_118, (copy) v_u_211, (copy) p_u_201
				p_u_53.glint(v_u_210, v_u_12, 12 * v_u_204, 0.3)
				v_u_4.flash(v_u_210, v_u_8, 10 * v_u_204, 0.3)
				local v212 = v_u_205 and 3 or 6
				for v213 = 1, v212 do
					local v_u_214 = v_u_206:Lerp(v_u_210, v213 / (v212 + 1))
					p_u_53.after(v213 * 0.012, function()
						-- upvalues: (ref) v_u_118, (copy) v_u_214, (ref) v_u_211, (ref) v_u_204
						v_u_118(v_u_214, v_u_211, 2 * v_u_204, 9 * v_u_204, 0.35)
					end)
				end
				if p_u_201.mine then
					v_u_4.shake(0.35, 0.3)
				end
			end)
			if not v_u_205 then
				p_u_53.spikes(v_u_206 + v_u_211 * 4, v_u_7, 6, 14 * v_u_204, 0.25, v_u_211, 0.25)
				p_u_53.alongPath(v_u_206, v_u_210, 14, 0.12, function(p215)
					-- upvalues: (ref) p_u_53, (ref) v_u_7
					p_u_53.glint(p215, v_u_7, 3, 0.12)
				end)
			end
			p_u_53.after(0.42, function()
				-- upvalues: (ref) v_u_183, (copy) p_u_201, (copy) v_u_206, (copy) v_u_210
				v_u_183(p_u_201, v_u_206, v_u_210)
			end)
		end,
		["hit"] = function(p_u_216, p_u_217, _) -- name: hit
			-- upvalues: (copy) p_u_53, (ref) v_u_8, (ref) v_u_3, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9
			p_u_53.burst("Impact", p_u_217, v_u_8, 1)
			local v218 = v_u_3.CurrentCamera
			local v219
			if v218 then
				local v220 = v218.CFrame.Position - p_u_217
				v219 = v220.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v220.Unit
			else
				v219 = Vector3.new(0, 0, 1)
			end
			p_u_53.sigil(p_u_53.facing(p_u_217 + v219 * 1.2, v219), 2.2, v_u_10, v_u_6.Ring, 0.55, 3)
			p_u_53.after(0.5, function()
				-- upvalues: (ref) p_u_53, (copy) p_u_217, (ref) v_u_10, (copy) p_u_216, (ref) v_u_9
				p_u_53.pop(p_u_217, v_u_10, 1, 5, 0.25, 0.3)
				if not p_u_216.lite then
					p_u_53.glint(p_u_217, v_u_9, 3, 0.15)
				end
			end)
		end
	}
	return v168
end