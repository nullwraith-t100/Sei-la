local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({ v_u_7.KidoBeam, v_u_7.KidoCircle, v_u_7.KidoHex })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("F4F2EE")
local v_u_10 = Color3.fromHex("D8263A")
local v_u_11 = Color3.fromRGB(255, 222, 70)
local v_u_12 = Color3.fromRGB(255, 190, 50)
local v_u_13 = Color3.fromRGB(255, 236, 236)
local v_u_14 = Color3.new(v_u_10.R * 1.6, v_u_10.G * 1.6, v_u_10.B * 1.6)
local v_u_15 = Color3.new(v_u_9.R * 1.8, v_u_9.G * 1.8, v_u_9.B * 1.8)
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_35(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_4
	local v22 = Color3.new
	local v23 = p20.R
	local v24 = math.min(v23, 1)
	local v25 = p20.G
	local v26 = math.min(v25, 1)
	local v27 = p20.B
	local v28 = v22(v24, v26, (math.min(v27, 1)))
	local v29 = v_u_4.part
	local v30 = p18 * 2
	local v31 = p18 * 2
	local v32 = v29(Vector3.new(v30, 0.05, v31), p17, v28, {
		["transparency"] = 1
	})
	for _, v33 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v34 = Instance.new("Decal")
		v34.Face = v33
		v34.Texture = p19
		v34.Color3 = p20
		v34.Transparency = p21
		v34.Parent = v32
	end
	return v32
end
local function v_u_39(p36, p37) -- name: setAlpha
	for _, v38 in p36:GetChildren() do
		if not v38:IsA("Decal") then
			continue
		end
		v38.Transparency = p37
	end
end
local function v_u_50(p40, p41, p42, p43, p44, p45) -- name: ray
	local v46 = Instance.new("Attachment")
	v46.Parent = p40
	v46.WorldPosition = p41
	local v47 = Instance.new("Attachment")
	v47.Parent = p40
	v47.WorldPosition = p42
	local v48 = Instance.new("Beam")
	v48.Attachment0 = v46
	v48.Attachment1 = v47
	v48.Texture = p45
	v48.TextureMode = Enum.TextureMode.Wrap
	local v49 = p43 * 3
	v48.TextureLength = math.max(v49, 3)
	v48.TextureSpeed = 3
	v48.Color = ColorSequence.new(p44)
	v48.LightEmission = 1
	v48.LightInfluence = 0
	v48.Brightness = 1.5
	v48.FaceCamera = true
	v48.Width0 = p43
	v48.Width1 = p43
	v48.Segments = 1
	v48.Parent = p40
	return v48
end
local function v_u_57(p51, p52, p53, p54) -- name: embers
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_13, (copy) v_u_1
	local v55 = Instance.new("Attachment")
	v55.Parent = v_u_3.Terrain
	v55.WorldPosition = p51
	local v56 = Instance.new("ParticleEmitter")
	v56.Texture = v_u_7.Glow
	v56.Color = ColorSequence.new(v_u_13, p52)
	v56.LightEmission = 0.6
	v56.LightInfluence = 0
	v56.Size = NumberSequence.new(0.45, 0)
	v56.Lifetime = NumberRange.new(0.6, 1)
	v56.Speed = NumberRange.new(p54 * 0.5, p54)
	v56.SpreadAngle = Vector2.new(40, 40)
	v56.Acceleration = Vector3.new(0, 6, 0)
	v56.Drag = 2
	v56.Rate = 0
	v56.Parent = v55
	v56:Emit(p53)
	v_u_1:AddItem(v55, 1.3)
end
local function v_u_86(p_u_58) -- name: talisman
	-- upvalues: (copy) v_u_2, (copy) v_u_9, (copy) v_u_4, (copy) v_u_16, (copy) v_u_10
	local v59 = v_u_2:FindFirstChild("EyePieces")
	if v59 then
		v59 = v59:FindFirstChild("w6_kido_seal")
	end
	if v59 and v59:IsA("MeshPart") then
		local v_u_60 = v59:Clone()
		v_u_60.Anchored = true
		v_u_60.CanCollide = false
		v_u_60.CanQuery = false
		v_u_60.CanTouch = false
		v_u_60.CastShadow = false
		v_u_60.Massless = true
		local v61 = v59.Size.X
		local v62 = v59.Size.Y
		local v63 = v59.Size.Z
		local v64 = math.max(v61, v62, v63, 0.01)
		v_u_60.Size = v59.Size * (p_u_58 / v64)
		if not v_u_60:FindFirstChildWhichIsA("SurfaceAppearance") then
			v_u_60.Color = v_u_9
		end
		v_u_60.Parent = v_u_4.folder()
		local v_u_65 = v_u_60.Size.Y / 2
		return {
			["parts"] = { v_u_60 },
			["place"] = function(p66) -- name: place
				-- upvalues: (copy) v_u_60, (copy) v_u_65
				v_u_60.CFrame = p66 * CFrame.new(0, -v_u_65, 0)
			end,
			["fade"] = function(p67) -- name: fade
				-- upvalues: (copy) v_u_60
				v_u_60.Transparency = p67
			end
		}
	else
		local v68 = p_u_58 * 0.38
		local v69 = v_u_4.part
		local v70 = p_u_58 * 0.72
		local v71 = {
			["material"] = v_u_16
		}
		local v_u_72 = v69(Vector3.new(v68, v70, 0.06), CFrame.identity, v_u_9, v71)
		local v73 = v_u_4.part
		local v74 = v68 * 0.22
		local v75 = p_u_58 * 0.6
		local v76 = {
			["material"] = v_u_16
		}
		local v_u_77 = v73(Vector3.new(v74, v75, 0.08), CFrame.identity, v_u_10, v76)
		local v78 = v_u_4.part
		local v79 = p_u_58 * 0.26
		local v80 = {
			["material"] = v_u_16
		}
		local v_u_81 = v78(Vector3.new(0.12, v79, 0.12), CFrame.identity, v_u_10, v80)
		local v_u_82 = { v_u_72, v_u_77, v_u_81 }
		return {
			["parts"] = v_u_82,
			["place"] = function(p83) -- name: place
				-- upvalues: (copy) v_u_72, (copy) p_u_58, (copy) v_u_77, (copy) v_u_81
				v_u_72.CFrame = p83 * CFrame.new(0, -p_u_58 * 0.36, 0)
				v_u_77.CFrame = p83 * CFrame.new(0, -p_u_58 * 0.36, 0)
				v_u_81.CFrame = p83 * CFrame.new(0, -p_u_58 * 0.85, 0)
			end,
			["fade"] = function(p84) -- name: fade
				-- upvalues: (copy) v_u_82
				for _, v85 in v_u_82 do
					v85.Transparency = p84
				end
			end
		}
	end
end
return function(p_u_87)
	-- upvalues: (copy) v_u_35, (copy) v_u_7, (copy) v_u_14, (copy) v_u_1, (copy) v_u_39, (copy) v_u_8, (copy) v_u_4, (copy) v_u_13, (copy) v_u_50, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6, (copy) v_u_9, (copy) v_u_15, (copy) v_u_86, (copy) v_u_57, (copy) v_u_12
	local v88 = {}
	local function v_u_102(p89, p90, p_u_91, p_u_92, p93) -- name: circleFlash
		-- upvalues: (ref) v_u_35, (copy) p_u_87, (ref) v_u_7, (ref) v_u_14, (ref) v_u_1, (ref) v_u_39
		local v_u_94 = v_u_35(p_u_87.facing(p89, p90), p_u_91, v_u_7.KidoCircle, v_u_14, 0)
		v_u_1:AddItem(v_u_94, p93 + 0.1)
		local v_u_95 = p_u_87.facing(p89, p90)
		p_u_87.animate(p93, 0, function(p96)
			-- upvalues: (copy) v_u_94, (copy) p_u_91, (copy) p_u_92, (copy) v_u_95, (ref) v_u_39
			local v97 = v_u_94
			local v98 = p_u_91 + (p_u_92 - p_u_91) * (1 - (1 - p96) ^ 3)
			local v99 = math.max(v98, 0.03)
			local v100 = v99 * 2
			local v101 = v99 * 2
			v97.Size = Vector3.new(v100, 0.05, v101)
			v_u_94.CFrame = v_u_95 * CFrame.Angles(0, p96 * 2, 0)
			v_u_39(v_u_94, p96 ^ 2)
			if p96 >= 1 then
				v_u_94:Destroy()
			end
		end)
	end
	v88.kido_seal_a = {
		["cast"] = function(p103) -- name: cast
			-- upvalues: (copy) p_u_87, (ref) v_u_8, (ref) v_u_4, (ref) v_u_13, (copy) v_u_102
			local v104 = p103.size
			local v105 = p103.eye + p103.dir * 1.1
			p_u_87.pop(v105, v_u_8, 1.2 * v104, 0.3 * v104, 0.1)
			v_u_4.flash(v105, v_u_13, 2.6 * v104, 0.1)
			if not p103.lite then
				v_u_102(v105, p103.dir, 0.4 * v104, 1.5 * v104, 0.2)
			end
		end,
		["beam"] = function(p106, p107, p108) -- name: beam
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_50, (ref) v_u_7, (ref) v_u_10, (copy) p_u_87, (ref) v_u_35, (ref) v_u_39, (ref) v_u_13
			local v_u_109 = p106.size
			local v110 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p107), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v110, 0.3)
			local v_u_111 = {
				{
					["b"] = v_u_50(v110, p107, p108, 0.6 * v_u_109, v_u_8, v_u_7.Beam),
					["w"] = 0.6 * v_u_109
				},
				{
					["b"] = v_u_50(v110, p107, p108, 2.4 * v_u_109, v_u_8, v_u_7.KidoBeam),
					["w"] = 2.4 * v_u_109
				},
				{
					["b"] = v_u_50(v110, p107, p108, 1.5 * v_u_109, v_u_8, v_u_7.Beam),
					["w"] = 1.5 * v_u_109
				}
			}
			if not p106.lite then
				local v112 = v_u_50(v110, p107, p108, 2.2 * v_u_109, v_u_10, v_u_7.Beam)
				v112.LightEmission = 0.2
				v112.Brightness = 0.8
				local v113 = {
					["b"] = v112,
					["w"] = 2.2 * v_u_109
				}
				table.insert(v_u_111, v113)
				local v114 = v_u_50(v110, p107 + Vector3.new(0, 0.1, 0), p108 - Vector3.new(0, 0.1, 0), 1.6 * v_u_109, v_u_8, v_u_7.KidoBeam)
				v114.TextureSpeed = -4
				local v115 = {
					["b"] = v114,
					["w"] = 1.6 * v_u_109
				}
				table.insert(v_u_111, v115)
			end
			p_u_87.animate(0.16, 0, function(p116)
				-- upvalues: (copy) v_u_111
				for _, v117 in v_u_111 do
					local v118 = v117.w * (1 - p116 * p116)
					local v119 = v117.b
					local v120 = v117.b
					v119.Width0 = v118
					v120.Width1 = v118
					v117.b.Transparency = NumberSequence.new(p116 * 0.6)
				end
			end)
			if not p106.lite then
				local v121 = p108 - p107
				for v122, v123 in { 0.22, 0.5, 0.8 } do
					local v124 = p107:Lerp(p108, v123)
					local v_u_125 = v_u_35(p_u_87.facing(v124, v121), 0.5 * v_u_109, v_u_7.Ring, v_u_8, 0.1)
					v_u_1:AddItem(v_u_125, 0.3)
					p_u_87.after(v122 * 0.02, function()
						-- upvalues: (ref) p_u_87, (copy) v_u_125, (copy) v_u_109, (ref) v_u_39
						p_u_87.animate(0.18, 0, function(p126)
							-- upvalues: (ref) v_u_125, (ref) v_u_109, (ref) v_u_39
							local v127 = v_u_125
							local v128 = (0.5 + 1.8 * (1 - (1 - p126) ^ 2)) * v_u_109
							local v129 = math.max(v128, 0.03)
							local v130 = v129 * 2
							local v131 = v129 * 2
							v127.Size = Vector3.new(v130, 0.05, v131)
							v_u_39(v_u_125, 0.1 + 0.9 * p126)
							if p126 >= 1 then
								v_u_125:Destroy()
							end
						end)
					end)
				end
			end
			p_u_87.glint(p108, v_u_8, 3.4 * v_u_109, 0.14)
			v_u_4.flash(p108, v_u_13, 2.4 * v_u_109, 0.12)
		end,
		["hit"] = function(p132, p133, _) -- name: hit
			-- upvalues: (copy) p_u_87, (ref) v_u_13
			p_u_87.burst("Impact", p133, v_u_13, 0.55)
			p_u_87.beamHitSound(p132, p133, "Lightning")
		end
	}
	local v_u_134 = {}
	setmetatable(v_u_134, {
		["__mode"] = "k"
	})
	local function v_u_154(p135, p136, p_u_137) -- name: openPrison
		-- upvalues: (copy) p_u_87, (ref) v_u_35, (ref) v_u_7, (ref) v_u_14, (ref) v_u_1, (ref) v_u_39, (ref) v_u_10
		local v_u_138 = p135.ability.radius
		local v139 = p135.ability.freeze or 3
		local v_u_140 = p_u_87.ground(p136, 0)
		local v_u_141 = p_u_137 + v139 + 0.6
		local v_u_142 = v_u_35(CFrame.new(v_u_140 + Vector3.new(0, 0.2, 0)), 0.1, v_u_7.KidoHex, v_u_14, 0)
		v_u_1:AddItem(v_u_142, v_u_141)
		local v_u_143 = os.clock()
		p_u_87.runNow(function()
			-- upvalues: (copy) v_u_142, (copy) v_u_143, (copy) v_u_138, (copy) p_u_137, (copy) v_u_140, (copy) v_u_141, (ref) v_u_39
			if not v_u_142.Parent then
				return false
			end
			local v144 = os.clock() - v_u_143
			local v145 = v_u_142
			local v146 = v_u_138
			local v147 = p_u_137 + 0.1
			local v148 = v144 / math.max(v147, 0.2)
			local v149 = math.clamp(v148, 0, 1) - 1
			local v150 = v146 * (v149 * 2.7 * v149 * v149 + 1 + v149 * 1.7 * v149)
			local v151 = math.max(v150, 0.03)
			local v152 = v151 * 2
			local v153 = v151 * 2
			v145.Size = Vector3.new(v152, 0.05, v153)
			v_u_142.CFrame = CFrame.new(v_u_140 + Vector3.new(0, 0.2, 0)) * CFrame.Angles(0, v144 * 0.6, 0)
			if v_u_141 - 0.4 < v144 then
				v_u_39(v_u_142, (v144 - (v_u_141 - 0.4)) / 0.4)
			end
			return v144 < v_u_141
		end)
		p_u_87.mark(v_u_140, v_u_10, v_u_138 * 1.05, v_u_141, v_u_7.Glow, 0.6)
		return {
			["g"] = nil,
			["ring"] = nil,
			["rods"] = nil,
			["bound"] = 0,
			["g"] = v_u_140,
			["ring"] = v_u_142,
			["rods"] = {}
		}
	end
	local function v_u_185(p155, p_u_156, p_u_157, p_u_158, p159, p160) -- name: stab
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_8, (ref) v_u_1, (copy) p_u_87
		local v_u_161 = {}
		for _, v162 in p155 do
			local v163 = p_u_156 - v162
			local v164 = v163.Magnitude
			local v165 = v163.Unit
			local v166 = v_u_4.part(Vector3.new(p_u_157, p_u_158, v164), CFrame.lookAt(v162, p_u_156), v_u_11)
			local v167 = v_u_4.part
			local v168 = p_u_157 * 0.4
			local v169 = p_u_158 * 1.2
			local v170 = v167(Vector3.new(v168, v169, v164), CFrame.lookAt(v162, p_u_156), v_u_8)
			v_u_1:AddItem(v166, p160 + 1)
			v_u_1:AddItem(v170, p160 + 1)
			local v171 = {
				["p"] = v166,
				["core"] = v170,
				["from"] = v162 - v165 * p159,
				["len"] = v164,
				["dir"] = v165
			}
			table.insert(v_u_161, v171)
		end
		p_u_87.animate(0.09, 0, function(p172)
			-- upvalues: (copy) v_u_161, (copy) p_u_156
			local v173 = p172 * p172
			for _, v174 in v_u_161 do
				local v175 = (v174.from + v174.dir * v174.len * 0.2):Lerp(p_u_156, v173)
				local v176 = v175 - v174.dir * v174.len
				local v177 = CFrame.lookAt((v175 + v176) / 2, v175)
				v174.p.CFrame = v177
				v174.core.CFrame = v177
			end
		end)
		p_u_87.after(p160, function()
			-- upvalues: (ref) p_u_87, (copy) v_u_161, (copy) p_u_157, (copy) p_u_158
			p_u_87.animate(0.22, 0, function(p178)
				-- upvalues: (ref) v_u_161, (ref) p_u_157, (ref) p_u_158
				for _, v179 in v_u_161 do
					local v180 = v179.p.CFrame
					local v181 = v179.p
					local v182 = p_u_157 * (1 + p178)
					local v183 = p_u_158
					local v184 = v179.len * (1 - 0.4 * p178)
					v181.Size = Vector3.new(v182, v183, v184)
					v179.p.CFrame = v180
					v179.p.Transparency = p178
					v179.core.Transparency = p178
					if p178 < 1 then
						continue
					end
					v179.p:Destroy()
					v179.core:Destroy()
				end
			end)
		end)
	end
	v88.kido_seal_e = {
		["cast"] = function(p186) -- name: cast
			-- upvalues: (copy) p_u_87, (ref) v_u_10, (copy) v_u_102
			p_u_87.skillCast(p186, v_u_10)
			if not p186.lite then
				v_u_102(p186.eye + p186.dir * 1.2, p186.dir, 0.6, 2.6, 0.3)
			end
		end,
		["windup"] = function(p187, p188, p189) -- name: windup
			-- upvalues: (copy) v_u_134, (copy) v_u_154
			v_u_134[p187] = v_u_154(p187, p188, p189)
		end,
		["land"] = function(p_u_190, p191) -- name: land
			-- upvalues: (copy) v_u_134, (copy) v_u_154, (copy) v_u_185, (copy) p_u_87, (ref) v_u_4, (ref) v_u_13, (ref) v_u_11, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10
			local v192 = v_u_134[p_u_190] or v_u_154(p_u_190, p191, 0)
			local v_u_193 = p_u_190.ability.radius
			local v194 = p_u_190.ability.freeze or 3
			local v_u_195 = v192.g
			local v_u_196 = v_u_195 + Vector3.new(0, 2.5, 0)
			local v197 = {}
			for v198 = 1, 6 do
				local v199 = v198 / 6 * 3.141592653589793 * 2 + 0.5235987755982988
				local v200 = math.cos(v199) * v_u_193 * 0.95
				local v201 = math.sin(v199) * v_u_193 * 0.95
				local v202 = v_u_195 + Vector3.new(v200, 6.5, v201)
				table.insert(v197, v202)
			end
			v_u_185(v197, v_u_196, 1.6, 0.3, 10, v194)
			p_u_87.after(0.09, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_196, (ref) v_u_13, (ref) p_u_87, (ref) v_u_11, (copy) v_u_195, (copy) v_u_193, (ref) v_u_7, (copy) p_u_190
				v_u_4.flash(v_u_196, v_u_13, 9, 0.25)
				p_u_87.burst("Impact", v_u_196, v_u_11, 1.6)
				v_u_4.ring(v_u_195, v_u_11, v_u_193 * 1.1, 0.4, v_u_7.Ring)
				if not p_u_190.lite then
					p_u_87.spikes(v_u_196, v_u_11, 8, 9, 0.25)
				end
			end)
			v_u_6.play("Hit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v_u_195
			})
			if p_u_190.mine then
				v_u_4.shake(0.35, 0.25)
			end
			p_u_87.after(v194, function()
				-- upvalues: (ref) v_u_134, (copy) p_u_190, (ref) p_u_87, (copy) v_u_196, (ref) v_u_11, (ref) v_u_4, (copy) v_u_195, (ref) v_u_10, (copy) v_u_193, (ref) v_u_7
				v_u_134[p_u_190] = nil
				p_u_87.burst("Impact", v_u_196, v_u_11, 1.4)
				v_u_4.ring(v_u_195, v_u_10, v_u_193, 0.35, v_u_7.Ring)
			end)
		end,
		["hit"] = function(p203, p204, p205) -- name: hit
			-- upvalues: (copy) v_u_134, (copy) p_u_87, (ref) v_u_11, (ref) v_u_8, (copy) v_u_185, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			local v206 = v_u_134[p203]
			local v207
			if v206 then
				v206.bound = v206.bound + 1
				v207 = v206.bound
			else
				v207 = 1
			end
			if p203.lite or v207 > 8 then
				p_u_87.bindHit(p203, p204, p205, v_u_11, v_u_8)
			else
				local v_u_208 = p203.ability.freeze or 3
				local v_u_209 = p204 + Vector3.new(0, 0.2, 0)
				local v_u_210 = {}
				for v211 = 1, 6 do
					local v212 = v211 / 6 * 3.141592653589793 * 2 + v207
					local v213 = math.cos(v212) * 2.6
					local v214 = math.sin(v212) * 2.6
					local v215 = v_u_209 + Vector3.new(v213, 0, v214)
					table.insert(v_u_210, v215)
				end
				p_u_87.after(0.1, function()
					-- upvalues: (ref) v_u_185, (copy) v_u_210, (copy) v_u_209, (copy) v_u_208, (ref) p_u_87, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11
					v_u_185(v_u_210, v_u_209, 0.55, 0.12, 3, v_u_208)
					p_u_87.sigil(CFrame.new(v_u_209), 1.8, v_u_9, v_u_7.Ring, v_u_208, 2)
					v_u_4.flash(v_u_209, v_u_11, 3, 0.15)
				end)
			end
		end
	}
	local v_u_216 = {}
	setmetatable(v_u_216, {
		["__mode"] = "k"
	})
	local function v_u_261(p217, p218, p219) -- name: descend
		-- upvalues: (copy) p_u_87, (ref) v_u_35, (ref) v_u_7, (ref) v_u_14, (ref) v_u_15, (ref) v_u_1, (ref) v_u_86, (ref) v_u_10
		local v_u_220 = p217.ability.radius
		local v_u_221 = p_u_87.ground(p218, 0)
		local v222 = p219 + 2
		local v_u_223 = v_u_35(CFrame.new(v_u_221 + Vector3.new(0, 24, 0)), v_u_220 * 0.9, v_u_7.KidoCircle, v_u_14, 0)
		local v_u_224 = v_u_35(CFrame.new(v_u_221 + Vector3.new(0, 24, 0)), v_u_220 * 0.5, v_u_7.KidoHex, v_u_15, 0.1)
		v_u_1:AddItem(v_u_223, v222)
		v_u_1:AddItem(v_u_224, v222)
		local v_u_225 = {
			["g"] = nil,
			["circle"] = nil,
			["hex"] = nil,
			["slips"] = nil,
			["spots"] = nil,
			["height"] = 24,
			["landed"] = false,
			["g"] = v_u_221,
			["circle"] = v_u_223,
			["hex"] = v_u_224,
			["slips"] = {},
			["spots"] = {}
		}
		for _ = 1, p217.lite and 0 or 8 do
			local v226 = v_u_86(6.5)
			for _, v227 in v226.parts do
				v_u_1:AddItem(v227, v222)
			end
			local v228 = v_u_225.slips
			table.insert(v228, v226)
		end
		for v229 = 1, 8 do
			local v230 = v229 / 8 * 3.141592653589793 * 2
			local v231 = v_u_225.spots
			local v232 = math.cos(v230)
			local v233 = math.sin(v230)
			local v234 = Vector3.new(v232, 0, v233) * v_u_220 * 0.78
			table.insert(v231, v234)
		end
		local v_u_235 = os.clock()
		local v_u_236 = math.max(p219, 0.15)
		p_u_87.runNow(function()
			-- upvalues: (copy) v_u_225, (copy) v_u_235, (copy) v_u_236, (copy) v_u_223, (copy) v_u_221, (copy) v_u_224, (copy) v_u_220
			if v_u_225.landed then
				return false
			end
			local v237 = os.clock() - v_u_235
			local v238 = v237 / v_u_236
			local v239 = math.clamp(v238, 0, 1)
			local v240 = (1 - v239 * v239) * 23.6 + 0.4
			v_u_225.height = v240
			local v241 = v237 * 1.2
			v_u_223.CFrame = CFrame.new(v_u_221 + Vector3.new(0, 1, 0) * v240) * CFrame.Angles(0, v241, 0)
			v_u_224.CFrame = CFrame.new(v_u_221 + Vector3.new(0, 1, 0) * (v240 + 0.1)) * CFrame.Angles(0, -v241 * 1.8, 0)
			local v242 = v_u_223
			local v243 = v_u_220 * 0.9
			local v244 = v237 / 0.12
			local v245 = math.min(v244, 1) - 1
			local v246 = v245 * 2.7 * v245 * v245 + 1 + v245 * 1.7 * v245
			local v247 = v243 * math.clamp(v246, 0.1, 1.1)
			local v248 = math.max(v247, 0.03)
			local v249 = v248 * 2
			local v250 = v248 * 2
			v242.Size = Vector3.new(v249, 0.05, v250)
			for v251, v252 in v_u_225.slips do
				local v253 = v_u_225.spots[v251]
				local v254 = v253.X
				local v255 = v253.Z
				local v256 = math.atan2(v254, v255)
				local v257 = v252.place
				local v258 = CFrame.new(v_u_221 + v253 + Vector3.new(0, 1, 0) * (v240 + 6.8))
				local v259 = CFrame.Angles
				local v260 = v237 * 6 + v251
				v257(v258 * v259(0, v256 + math.sin(v260) * 0.2, 0))
			end
			return true
		end)
		p_u_87.sigil(CFrame.new(v_u_221 + Vector3.new(0, 0.2, 0)), v_u_220, v_u_10, v_u_7.Ring, p219 + 0.1, 1)
		return v_u_225
	end
	local function v_u_300(p262, p263) -- name: detonate
		-- upvalues: (copy) p_u_87, (ref) v_u_39, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_50, (ref) v_u_7, (ref) v_u_10, (ref) v_u_57, (ref) v_u_9, (ref) v_u_12, (ref) v_u_6
		local v_u_264 = p262.ability.radius
		local v265 = p263.g
		local v266 = p262.lite
		p263.landed = true
		local v_u_267 = p263.circle
		local v_u_268 = p263.hex
		v_u_267.CFrame = CFrame.new(v265 + Vector3.new(0, 0.35, 0))
		v_u_268.CFrame = CFrame.new(v265 + Vector3.new(0, 0.45, 0))
		p_u_87.animate(0.55, 0, function(p269)
			-- upvalues: (copy) v_u_267, (copy) v_u_264, (copy) v_u_268, (ref) v_u_39
			local v270 = 1 - (1 - p269) ^ 3
			local v271 = v_u_267
			local v272 = v_u_264 * (0.9 + 0.55 * v270)
			local v273 = math.max(v272, 0.03)
			local v274 = v273 * 2
			local v275 = v273 * 2
			v271.Size = Vector3.new(v274, 0.05, v275)
			local v276 = v_u_268
			local v277 = v_u_264 * (0.5 + 0.9 * v270)
			local v278 = math.max(v277, 0.03)
			local v279 = v278 * 2
			local v280 = v278 * 2
			v276.Size = Vector3.new(v279, 0.05, v280)
			v_u_39(v_u_267, p269 ^ 1.5)
			v_u_39(v_u_268, 0.1 + 0.9 * p269)
			if p269 >= 1 then
				v_u_267:Destroy()
				v_u_268:Destroy()
			end
		end)
		local v281 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v265), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v281, 0.8)
		local v_u_282 = {}
		for v283, v284 in p263.spots do
			if v266 and v283 % 2 == 0 then
				continue
			end
			local v285 = v265 + v284
			local v286 = {
				["b"] = nil,
				["w"] = 3.2,
				["b"] = v_u_50(v281, v285, v285 + Vector3.new(0, 26, 0), 3.2, v_u_8, v_u_7.Beam)
			}
			table.insert(v_u_282, v286)
			if v266 then
				continue
			end
			local v287 = v_u_50(v281, v285, v285 + Vector3.new(0, 20, 0), 6.5, v_u_10, v_u_7.Beam)
			v287.LightEmission = 0.5
			table.insert(v_u_282, {
				["b"] = nil,
				["w"] = 6.5,
				["b"] = v287
			})
			v_u_57(v285 + Vector3.new(0, 2, 0), v_u_10, 8, 10)
		end
		p_u_87.animate(0.6, 0, function(p288)
			-- upvalues: (copy) v_u_282
			for _, v289 in v_u_282 do
				local v290 = v289.w * (1 - p288 * p288)
				local v291 = v289.b
				local v292 = v289.b
				local v293 = v290 * 0.4
				v291.Width0 = v290
				v292.Width1 = v293
				v289.b.Transparency = NumberSequence.new(p288 * 0.7)
			end
		end)
		for v294, v_u_295 in p263.slips do
			local v296 = p263.spots[v294]
			local v_u_297 = CFrame.new(v265 + v296 + Vector3.new(0, 7, 0))
			p_u_87.animate(0.5, 0, function(p298)
				-- upvalues: (copy) v_u_295, (copy) v_u_297
				v_u_295.place(v_u_297 * CFrame.new(0, 3 * p298, 0) * CFrame.Angles(0, p298 * 4, 0))
				v_u_295.fade(p298)
				if p298 >= 1 then
					for _, v299 in v_u_295.parts do
						v299:Destroy()
					end
				end
			end)
		end
		v_u_4.flash(v265 + Vector3.new(0, 3, 0), v_u_8, v_u_264 * 1.2, 0.3)
		p_u_87.dome(v265, v_u_264 * 1.1, v_u_10, 0.6)
		v_u_4.ring(v265, v_u_10, v_u_264 * 1.35, 0.6, v_u_7.Shockwave)
		v_u_4.ring(v265, v_u_9, v_u_264 * 1.05, 0.45, v_u_7.Ring)
		p_u_87.burst("Shockwave", v265 + Vector3.new(0, 0.3, 0), v_u_10, v_u_264 / 14)
		p_u_87.burst("Explosion", v265 + Vector3.new(0, 2, 0), v_u_10, 2.4)
		p_u_87.spikes(v265 + Vector3.new(0, 2, 0), v_u_9, v266 and 6 or 14, v_u_264 * 1.4, 0.35, nil, nil, true)
		p_u_87.mark(v265, v_u_10, v_u_264 * 1.1, 1.5, v_u_7.Glow, 0.35)
		if not v266 then
			v_u_57(v265 + Vector3.new(0, 2, 0), v_u_12, 24, 22)
		end
		v_u_6.play("Explosion", {
			["at"] = v265,
			["volume"] = p262.mine and 1 or 0.6
		})
		if p262.mine then
			v_u_4.shake(0.6, 0.5)
		end
	end
	v88.kido_seal_r = {
		["cast"] = function(p301) -- name: cast
			-- upvalues: (copy) p_u_87, (ref) v_u_10, (copy) v_u_102
			p_u_87.skillCast(p301, v_u_10, true)
			v_u_102(p301.eye + p301.dir * 1.3, p301.dir, 0.8, 3.6 * p301.size, 0.35)
		end,
		["windup"] = function(p302, p303, p304) -- name: windup
			-- upvalues: (copy) v_u_216, (copy) v_u_261
			v_u_216[p302] = v_u_261(p302, p303, p304)
		end,
		["land"] = function(p305, p306) -- name: land
			-- upvalues: (copy) v_u_216, (copy) v_u_261, (copy) v_u_300
			local v307 = v_u_216[p305] or v_u_261(p305, p306, 0)
			v_u_216[p305] = nil
			v_u_300(p305, v307)
		end,
		["hit"] = function(_, p308, _) -- name: hit
			-- upvalues: (copy) p_u_87, (ref) v_u_10
			p_u_87.burst("Impact", p308, v_u_10, 0.8)
		end
	}
	return v88
end