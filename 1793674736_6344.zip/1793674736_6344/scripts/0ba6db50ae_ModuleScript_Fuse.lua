local v_u_1 = require(script.Parent.Parent.Config.Fuse)
local v_u_2 = require(script.Parent.Parent.Config.Pets)
local v_u_3 = require(script.Parent.Parent.Config.Worlds)
local v_u_62 = {
	["open"] = function(p4) -- name: open
		-- upvalues: (copy) v_u_1, (copy) v_u_3
		local v5 = v_u_1.FROM_WORLD
		if v5 <= 1 then
			return true
		end
		local v6 = v_u_3[v5]
		local v7
		if v6 == nil then
			v7 = false
		else
			v7 = p4(v5 - 1) >= (v6.needStage or 0)
		end
		return v7
	end,
	["lockedText"] = function() -- name: lockedText
		-- upvalues: (copy) v_u_1
		return ("Reach World %* to fuse pets!"):format(v_u_1.FROM_WORLD)
	end,
	["tierOf"] = function(p8, p9) -- name: tierOf
		-- upvalues: (copy) v_u_1
		if p8 then
			p8 = p8[p9]
		end
		return (type(p8) ~= "number" or (not v_u_1.tier(p8) or p8 ~= math.floor(p8))) and 0 or p8
	end,
	["clean"] = function(p10, p11) -- name: clean
		-- upvalues: (copy) v_u_62
		local v12 = {}
		if type(p11) ~= "table" then
			return v12
		end
		for v13, v14 in p11 do
			if type(v13) ~= "string" or (not p10[v13] or type(v14) ~= "number") then
				continue
			end
			local v15 = v_u_62.tierOf({
				[v13] = v14
			}, v13)
			if v15 <= 0 then
				continue
			end
			v12[v13] = v15
		end
		return v12
	end,
	["mult"] = function(p16, p17, p18) -- name: mult
		-- upvalues: (copy) v_u_2, (copy) v_u_1
		local v19 = v_u_2.byId[p16]
		if v19 then
			local v20 = v_u_2.multIn(v19, p18)
			local v21 = v_u_1.factor(p17)
			if v21 == 1 then
				return v20
			else
				local v22 = v20 * v21
				if v22 >= 10 then
					local v23 = v22 + 0.5
					return math.floor(v23)
				else
					local v24 = v22 * 10 + 0.5
					return math.floor(v24) / 10
				end
			end
		else
			return 0
		end
	end,
	["multOf"] = function(p25, p26, p27, p28) -- name: multOf
		-- upvalues: (copy) v_u_62
		local v29 = p25[p27]
		return not v29 and 0 or v_u_62.mult(v29, v_u_62.tierOf(p26, p27), p28)
	end,
	["result"] = function(p30, p31, p32) -- name: result
		-- upvalues: (copy) v_u_1
		local v33 = p31 + 1 + math.max(p32 or 0, 0)
		local v34 = v_u_1.MAX
		return p30, math.min(v33, v34)
	end,
	["canFuse"] = function(p35, p36) -- name: canFuse
		-- upvalues: (copy) v_u_1
		local v37 = v_u_1.fusable(p35)
		if v37 then
			v37 = p36 < v_u_1.MAX
		end
		return v37
	end,
	["check"] = function(p38, p39, p40) -- name: check
		-- upvalues: (copy) v_u_1, (copy) v_u_62, (copy) v_u_2
		if type(p40) == "table" then
			local v41 = {}
			for v42 = 1, v_u_1.COUNT do
				local v43 = p40[v42]
				if type(v43) ~= "string" then
					return ("Pick %* pets"):format(v_u_1.COUNT), nil
				end
				if table.find(v41, v43) then
					return ("Pick %* different pets"):format(v_u_1.COUNT), nil
				end
				table.insert(v41, v43)
			end
			if p40[v_u_1.COUNT + 1] == nil then
				local v44 = nil
				local v45 = 0
				for v46, v47 in v41 do
					local v48 = p38[v47]
					if not v48 then
						return "You don\'t have that pet", nil
					end
					local v49 = v_u_62.tierOf(p39, v47)
					if v46 ~= 1 then
						if v48 ~= v44 then
							return ("Pick %* of the same pet"):format(v_u_1.COUNT), nil
						end
						if v49 == v45 then
							continue
						end
						return ("Pick %* pets of the same tier"):format(v_u_1.COUNT), nil
					end
					v45 = v49
					v44 = v48
				end
				local v50 = v_u_2.byId[v44]
				local v51 = not v50 and "This pet" or v50.name
				if v_u_1.fusable(v44) then
					if v_u_1.MAX <= v45 then
						return ("%* is already %*"):format(v51, (v_u_1.name(v45))), nil
					else
						return nil, {
							["kind"] = v44,
							["tier"] = v45,
							["uids"] = v41
						}
					end
				else
					return ("%* can\'t be fused"):format(v51), nil
				end
			else
				return ("Pick %* pets"):format(v_u_1.COUNT), nil
			end
		else
			return ("Pick %* pets"):format(v_u_1.COUNT), nil
		end
	end,
	["apply"] = function(p52, p53, p54, p55) -- name: apply
		local v56 = nil
		for _, v57 in p53.uids do
			p52.Pets[v57] = nil
			p52.PetTiers[v57] = nil
			local v58 = table.find(p52.Equipped, v57)
			if not v58 then
				continue
			end
			table.remove(p52.Equipped, v58)
			if v56 then
				v56 = math.min(v56, v58)
			else
				v56 = v58
			end
		end
		p52.Pets[p54] = p53.kind
		if p55 > 0 then
			p52.PetTiers[p54] = p55
		else
			p52.PetTiers[p54] = nil
		end
		if v56 then
			local v59 = p52.Equipped
			local v60 = #p52.Equipped + 1
			local v61 = math.min(v56, v60)
			table.insert(v59, v61, p54)
		end
		return v56 ~= nil
	end
}
local function v_u_67(p63, p64) -- name: byUid
	local v65 = tonumber(p63)
	local v66 = tonumber(p64)
	if v65 and (v66 and v65 ~= v66) then
		return v65 < v66
	else
		return p63 < p64
	end
end
function v_u_62.matches(p68, p69, p70, p71, p72) -- name: matches
	-- upvalues: (copy) v_u_62, (copy) v_u_67
	local v73 = {}
	for v74, v75 in p68 do
		if v75 ~= p70 or (v_u_62.tierOf(p69, v74) ~= p71 or p72 and table.find(p72, v74)) then
			continue
		end
		table.insert(v73, v74)
	end
	table.sort(v73, v_u_67)
	return v73
end
function v_u_62.groups(p76, p77, p_u_78, p_u_79) -- name: groups
	-- upvalues: (copy) v_u_62, (copy) v_u_1
	local v80 = {}
	for v81, v82 in p76 do
		local v83 = v_u_62.tierOf(p77, v81)
		if not v_u_62.canFuse(v82, v83) then
			continue
		end
		local v84 = v82 .. "|" .. v83
		local v85 = v80[v84]
		if not v85 then
			v85 = {
				["kind"] = v82,
				["tier"] = v83,
				["uids"] = {}
			}
			v80[v84] = v85
		end
		local v86 = v85.uids
		table.insert(v86, v81)
	end
	local v87 = {}
	for _, v88 in v80 do
		table.sort(v88.uids, function(p89, p90)
			-- upvalues: (copy) p_u_78
			local v91
			if p_u_78 == nil then
				v91 = false
			else
				v91 = table.find(p_u_78, p89) ~= nil
			end
			local v92
			if p_u_78 == nil then
				v92 = false
			else
				v92 = table.find(p_u_78, p90) ~= nil
			end
			if v91 == v92 then
				local v93 = tonumber(p89)
				local v94 = tonumber(p90)
				if v93 and (v94 and v93 ~= v94) then
					return v93 < v94
				else
					return p89 < p90
				end
			else
				return v92
			end
		end)
		for v95 = 1, #v88.uids - v_u_1.COUNT + 1, v_u_1.COUNT do
			local v96 = {
				["kind"] = v88.kind,
				["tier"] = v88.tier,
				["uids"] = table.move(v88.uids, v95, v95 + v_u_1.COUNT - 1, 1, {})
			}
			table.insert(v87, v96)
		end
	end
	table.sort(v87, function(p97, p98)
		-- upvalues: (ref) v_u_62, (copy) p_u_79
		local v99 = v_u_62.mult(p97.kind, p97.tier + 1, p_u_79)
		local v100 = v_u_62.mult(p98.kind, p98.tier + 1, p_u_79)
		if v99 == v100 then
			local v101 = p97.uids[1]
			local v102 = p98.uids[1]
			local v103 = tonumber(v101)
			local v104 = tonumber(v102)
			if v103 and (v104 and v103 ~= v104) then
				return v103 < v104
			else
				return v101 < v102
			end
		else
			return v100 < v99
		end
	end)
	return v87
end
function v_u_62.canSkip(p105, p106) -- name: canSkip
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v107
	if v_u_2.byId[p105] == nil then
		v107 = false
	else
		v107 = p106 < v_u_1.MAX
	end
	return v107
end
function v_u_62.skipKey(p108) -- name: skipKey
	-- upvalues: (copy) v_u_1
	return v_u_1.SKIP_KEYS[p108]
end
function v_u_62.skipTier(p109) -- name: skipTier
	-- upvalues: (copy) v_u_1
	return table.find(v_u_1.SKIP_KEYS, p109)
end
function v_u_62.creditId(p110) -- name: creditId
	-- upvalues: (copy) v_u_1
	local v111 = v_u_1.tier(p110)
	if v111 then
		return v111.id
	else
		return nil
	end
end
function v_u_62.skipCheck(p112, p113, p114) -- name: skipCheck
	-- upvalues: (copy) v_u_2, (copy) v_u_62, (copy) v_u_1
	if type(p114) == "string" then
		local v115 = p112[p114]
		if v115 and v_u_2.byId[v115] then
			local v116 = v_u_62.tierOf(p113, p114)
			if v_u_62.canSkip(v115, v116) then
				return nil, v115, v116
			else
				return ("%* is already %*"):format(v_u_2.byId[v115].name, (v_u_1.name(v116))), nil, nil
			end
		else
			return "You don\'t have that pet", nil, nil
		end
	else
		return "Pick a pet", nil, nil
	end
end
function v_u_62.skipTarget(p117, p118, p119, p120, p121, p122) -- name: skipTarget
	-- upvalues: (copy) v_u_1, (copy) v_u_62
	local v123 = p119 - 1
	if p120 and (p120.from == v123 and (p121 - p120.at <= v_u_1.SKIP_SECONDS and (p117[p120.uid] ~= nil and v_u_62.tierOf(p118, p120.uid) == v123))) then
		return p120.uid
	end
	local v124 = -1
	local v125 = nil
	for v126, v127 in p117 do
		if v_u_62.tierOf(p118, v126) ~= v123 or not v_u_62.canSkip(v127, v123) then
			continue
		end
		local v128 = v_u_62.mult(v127, p119, p122)
		if v124 >= v128 then
			if v128 ~= v124 or v125 == nil then
				continue
			end
			local v129 = tonumber(v126)
			local v130 = tonumber(v125)
			local v131
			if v129 and (v130 and v129 ~= v130) then
				v131 = v129 < v130
			else
				v131 = v126 < v125
			end
			if not v131 then
				continue
			end
		end
		v125 = v126
		v124 = v128
	end
	return v125
end
function v_u_62.cleanCredits(p132) -- name: cleanCredits
	-- upvalues: (copy) v_u_1
	local v133 = {}
	if type(p132) ~= "table" then
		return v133
	end
	for _, v134 in v_u_1.TIERS do
		local v135 = p132[v134.id]
		if type(v135) ~= "number" or v135 < 1 then
			continue
		end
		v133[v134.id] = math.floor(v135)
	end
	return v133
end
return v_u_62