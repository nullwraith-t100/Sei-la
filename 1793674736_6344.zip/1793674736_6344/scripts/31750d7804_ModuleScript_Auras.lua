local v_u_1 = {
	{
		["id"] = "spark",
		["name"] = "Spark",
		["skip"] = "skipSpark",
		["trophies"] = 50,
		["mult"] = 1.5,
		["color"] = "#FFF27A",
		["look"] = "Aura",
		["extra"] = "Sparkle",
		["scale"] = 1
	},
	{
		["id"] = "blue_flame",
		["name"] = "Blue Flame",
		["skip"] = "skipBlueFlame",
		["trophies"] = 500,
		["mult"] = 2,
		["color"] = "#3FA9FF",
		["look"] = "AuraMode",
		["scale"] = 1
	},
	{
		["id"] = "leaf",
		["name"] = "Leaf Storm",
		["skip"] = "skipLeaf",
		["trophies"] = 5000,
		["mult"] = 3,
		["color"] = "#5BE37D",
		["look"] = "Aura",
		["extra"] = "Petals",
		["scale"] = 1.2
	},
	{
		["id"] = "thunder",
		["name"] = "Thunder",
		["skip"] = "skipThunder",
		["trophies"] = 40000,
		["mult"] = 4,
		["color"] = "#9BE7FF",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.1
	},
	{
		["id"] = "sakura",
		["name"] = "Sakura Storm",
		["skip"] = "skipSakura",
		["trophies"] = 250000,
		["mult"] = 5.5,
		["color"] = "#FF8AD8",
		["look"] = "Aura",
		["extra"] = "Petals",
		["scale"] = 1.3
	},
	{
		["id"] = "inferno",
		["name"] = "Astral",
		["skip"] = "skipInferno",
		["trophies"] = 1500000,
		["mult"] = 7,
		["color"] = "#FF5A1F",
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 1.2
	},
	{
		["id"] = "amaterasu",
		["name"] = "Amaterasu",
		["skip"] = "skipAmaterasu",
		["trophies"] = 8000000,
		["mult"] = 9,
		["color"] = "#2A0A18",
		["look"] = "FireDark",
		["extra"] = "AuraMode",
		["scale"] = 1
	},
	{
		["id"] = "void",
		["name"] = "Void",
		["skip"] = "skipVoid",
		["trophies"] = 30000000,
		["mult"] = 11,
		["color"] = "#9B3BFF",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.3
	},
	{
		["id"] = "celestial",
		["name"] = "Celestial",
		["skip"] = "skipCelestial",
		["trophies"] = 100000000,
		["mult"] = 13,
		["color"] = "#FFE16B",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.5
	},
	{
		["id"] = "moonlight",
		["name"] = "Moonlight",
		["trophies"] = 10000000000,
		["mult"] = 16,
		["color"] = "#C9D6FF",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.4
	},
	{
		["id"] = "lotus_bloom",
		["name"] = "Lotus Bloom",
		["trophies"] = 1000000000000,
		["mult"] = 19,
		["color"] = "#FF6FD8",
		["look"] = "Aura",
		["extra"] = "Petals",
		["scale"] = 1.4
	},
	{
		["id"] = "starfall",
		["name"] = "Starfall",
		["trophies"] = 100000000000000,
		["mult"] = 22,
		["color"] = "#FFB43A",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.5
	},
	{
		["id"] = "heavenly",
		["name"] = "Heavenly",
		["trophies"] = 1e16,
		["mult"] = 26,
		["color"] = "#FFF4D6",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.6
	},
	{
		["id"] = "blood_moon",
		["name"] = "Blood Moon",
		["trophies"] = 1e19,
		["mult"] = 30,
		["color"] = "#E3122E",
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 1.5
	},
	{
		["id"] = "demon_flame",
		["name"] = "Demon Flame",
		["trophies"] = 1e22,
		["mult"] = 35,
		["color"] = "#5A0612",
		["look"] = "FireDark",
		["extra"] = "AuraMode",
		["scale"] = 1.2
	},
	{
		["id"] = "crimson_eclipse",
		["name"] = "Crimson Eclipse",
		["trophies"] = 1e25,
		["mult"] = 40,
		["color"] = "#FF4A2A",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.6
	},
	{
		["id"] = "frostbite",
		["name"] = "Frostbite",
		["trophies"] = 1e28,
		["mult"] = 46,
		["color"] = "#6FE6FF",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.6
	},
	{
		["id"] = "abyssal_tide",
		["name"] = "Abyssal Tide",
		["trophies"] = 1e31,
		["mult"] = 53,
		["color"] = "#2D5BFF",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.7
	},
	{
		["id"] = "nebula_veil",
		["name"] = "Nebula Veil",
		["trophies"] = 1e34,
		["mult"] = 60,
		["color"] = "#B06BFF",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.7,
		["world"] = 5
	},
	{
		["id"] = "event_horizon",
		["name"] = "Event Horizon",
		["trophies"] = 1e37,
		["mult"] = 68,
		["color"] = "#7A3CFF",
		["look"] = "FireDark",
		["extra"] = "Vortex",
		["scale"] = 1.8,
		["world"] = 5
	},
	{
		["id"] = "reiatsu_surge",
		["name"] = "Reiatsu Surge",
		["trophies"] = 1e44,
		["mult"] = 77,
		["color"] = "#7FD0FF",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.8,
		["world"] = 6,
		["update"] = 4
	},
	{
		["id"] = "bankai_flame",
		["name"] = "Bankai Flame",
		["trophies"] = 1e47,
		["mult"] = 87,
		["color"] = "#E0141E",
		["look"] = "FireDark",
		["extra"] = "Vortex",
		["scale"] = 1.9,
		["world"] = 6,
		["update"] = 4
	},
	{
		["id"] = "hollow_hole",
		["name"] = "Hollow Hole",
		["trophies"] = 5e52,
		["mult"] = 96,
		["color"] = "#F2EEE4",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.9,
		["world"] = 7,
		["update"] = 4
	},
	{
		["id"] = "almighty_shadow",
		["name"] = "Almighty Shadow",
		["trophies"] = 5e55,
		["mult"] = 104,
		["color"] = "#6FC3FF",
		["look"] = "FireDark",
		["extra"] = "Sparkle",
		["scale"] = 2,
		["world"] = 7,
		["update"] = 4
	},
	{
		["id"] = "upper_moon",
		["name"] = "Upper Moon",
		["trophies"] = 2.5e61,
		["mult"] = 110,
		["color"] = "#E0213A",
		["look"] = "FireDark",
		["extra"] = "Vortex",
		["scale"] = 1.95,
		["world"] = 8,
		["update"] = 4
	},
	{
		["id"] = "hinokami",
		["name"] = "Hinokami",
		["trophies"] = 2.5e64,
		["mult"] = 116,
		["color"] = "#FFB21F",
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 2,
		["world"] = 8,
		["update"] = 4
	},
	{
		["id"] = "crimson_storm",
		["name"] = "Crimson Storm",
		["trophies"] = 0,
		["mult"] = 3,
		["color"] = "#FF2D55",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.3,
		["exclusive"] = true
	},
	{
		["id"] = "emerald_storm",
		["name"] = "Emerald Storm",
		["trophies"] = 0,
		["mult"] = 3,
		["color"] = "#1FE07A",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.3,
		["exclusive"] = true
	},
	{
		["id"] = "violet_storm",
		["name"] = "Violet Storm",
		["trophies"] = 0,
		["mult"] = 3,
		["color"] = "#A64DFF",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.3,
		["exclusive"] = true
	},
	{
		["id"] = "shadow_storm",
		["name"] = "Shadow Storm",
		["trophies"] = 0,
		["mult"] = 3,
		["color"] = "#2A1446",
		["look"] = "FireDark",
		["extra"] = "Lightning",
		["scale"] = 1.3,
		["exclusive"] = true
	},
	{
		["id"] = "golden_sage",
		["name"] = "Golden Sage",
		["trophies"] = 0,
		["mult"] = 15,
		["mults"] = nil,
		["color"] = "#FFD23F",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.4,
		["exclusive"] = true,
		["pass"] = "auraSage",
		["mults"] = {
			15,
			30,
			45,
			60,
			75,
			90,
			105,
			120
		}
	},
	{
		["id"] = "kurama_chakra",
		["name"] = "Kyubi Chakra",
		["trophies"] = 0,
		["mult"] = 25,
		["mults"] = nil,
		["color"] = "#FF7A1A",
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 1.5,
		["exclusive"] = true,
		["pass"] = "auraKurama",
		["mults"] = {
			25,
			50,
			75,
			100,
			125,
			150,
			175,
			200
		}
	},
	{
		["id"] = "otsutsuki",
		["name"] = "Otsutsuki",
		["trophies"] = 0,
		["mult"] = 40,
		["mults"] = nil,
		["color"] = "#E6DDFF",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.6,
		["exclusive"] = true,
		["pass"] = "auraOtsutsuki",
		["mults"] = {
			40,
			80,
			120,
			160,
			200,
			240,
			280,
			320
		}
	},
	{
		["id"] = "susanoo_flame",
		["name"] = "Susanoo Flame",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 0.5,
		["color"] = "#9D5CFF",
		["look"] = "AuraMode",
		["extra"] = "FireDark",
		["scale"] = 1.6,
		["exclusive"] = true,
		["pass"] = "auraSusanoo"
	},
	{
		["id"] = "rainbow_chakra",
		["name"] = "Rainbow Chakra",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 1.5,
		["rainbow"] = true,
		["color"] = "#FF5AD2",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.75,
		["exclusive"] = true,
		["pass"] = "auraRainbow"
	},
	{
		["id"] = "fox_fire",
		["name"] = "Fox Fire",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 0.15,
		["color"] = "#FF8A1F",
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 1.4,
		["exclusive"] = true,
		["update"] = 2,
		["boss"] = 160
	},
	{
		["id"] = "chakra_cloak",
		["name"] = "Chakra Cloak",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 0.3,
		["color"] = "#FFD23C",
		["look"] = "AuraMode",
		["extra"] = "Lightning",
		["scale"] = 1.5,
		["exclusive"] = true,
		["update"] = 2,
		["boss"] = 500
	},
	{
		["id"] = "tailed_cloak",
		["name"] = "Tailed Beast Cloak",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 0.5,
		["color"] = "#E8331C",
		["look"] = "AuraMode",
		["extra"] = "FireDark",
		["scale"] = 1.6,
		["exclusive"] = true,
		["update"] = 2,
		["boss"] = 1000
	},
	{
		["id"] = "bijuu_mode",
		["name"] = "Bijuu Mode",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 1,
		["color"] = "#FF6A00",
		["look"] = "AuraMode",
		["extra"] = "Vortex",
		["scale"] = 1.75,
		["exclusive"] = true,
		["update"] = 2,
		["boss"] = 3000
	},
	{
		["id"] = "dark_kyubi",
		["name"] = "Dark Kyubi",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = nil,
		["color"] = "#E3122E",
		["colors"] = nil,
		["look"] = "AuraMode",
		["extra"] = "Fire",
		["scale"] = 1.5,
		["exclusive"] = true,
		["update"] = 2,
		["drop"] = true,
		["better"] = require(script.Parent.BossDrops).AURA_BETTER,
		["colors"] = {
			"#FF4A3A",
			"#E3122E",
			"#7A0614",
			"#140205"
		}
	},
	{
		["id"] = "vip_aura",
		["name"] = "VIP Aura",
		["trophies"] = 0,
		["mult"] = 20,
		["mults"] = nil,
		["color"] = "#FFC21A",
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.55,
		["exclusive"] = true,
		["pass"] = "vip",
		["mults"] = {
			20,
			40,
			60,
			80,
			100,
			120,
			140,
			160
		}
	},
	{
		["id"] = "vip_plus_aura",
		["name"] = "VIP+ Aura",
		["trophies"] = 0,
		["mult"] = 1,
		["better"] = 0.75,
		["color"] = "#FFC93C",
		["colors"] = nil,
		["look"] = "AuraMode",
		["extra"] = "Sparkle",
		["scale"] = 1.7,
		["exclusive"] = true,
		["pass"] = "vipPlus",
		["update"] = 2,
		["colors"] = {
			"#FFF4C2",
			"#FFD23C",
			"#FFB21F",
			"#9B3BFF"
		}
	}
}
local v_u_2 = require(script.Parent.Worlds)
local v_u_3 = require(script.Parent.Release)
local v_u_4 = {
	["list"] = v_u_1,
	["byId"] = {}
}
for _, v5 in v_u_1 do
	v_u_4.byId[v5.id] = v5
end
function v_u_4.isOut(p6) -- name: isOut
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v7 = v_u_2[p6.world or 1]
	local v8 = v7 == nil or v7.ready
	if v8 then
		v8 = v_u_3.on(p6.update)
	end
	return v8
end
function v_u_4.multIn(p9, p10) -- name: multIn
	local v11 = p9.mults
	local v12
	if v11 then
		v12 = v11[p10 or 1]
		if not v12 then
			return v11[#v11]
		end
	else
		v12 = p9.mult
	end
	return v12
end
function v_u_4.multFor(p13, p14, p15) -- name: multFor
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v16 = p13.better
	if not v16 then
		return v_u_4.multIn(p13, p14)
	end
	local v17 = 1
	for _, v18 in v_u_1 do
		if v18.better or not p15(v18) then
			continue
		end
		local v19 = v_u_4.multIn
		v17 = math.max(v17, v19(v18, p14))
	end
	return v17 * (1 + v16)
end
return v_u_4