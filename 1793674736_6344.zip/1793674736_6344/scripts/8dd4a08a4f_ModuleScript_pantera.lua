local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(8, 36, 80)
local v_u_9 = Color3.fromRGB(242, 238, 226)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.PartType.Wedge
local v_u_12 = CFrame.Angles(0, 1.8849555921538759, 0) * CFrame.Angles(0, 0, -0.20943951023931956)
local function v_u_21(p13, p_u_14, p15, p_u_16) -- name: weldTo
	p15.Anchored = false
	p15.Massless = true
	local v17 = Instance.new("Weld")
	v17.Part0 = p_u_14
	v17.Part1 = p15
	v17.C0 = p_u_16
	v17.Parent = p15
	local v18 = p13.pieces
	local v20 = {
		["part"] = p15,
		["place"] = function(p19, _) -- name: place
			-- upvalues: (copy) p_u_14, (copy) p_u_16
			if p_u_14.Parent then
				return p_u_14.CFrame * p_u_16
			else
				return p19
			end
		end,
		["alpha"] = p15.Transparency,
		["weld"] = v17
	}
	table.insert(v18, v20)
end
local function v_u_26(p22, p23) -- name: bodyPart
	for _, v24 in p23 do
		local v25 = p22.character:FindFirstChild(v24)
		if not (v25 and v25:IsA("BasePart")) then
			continue
		end
		return v25
	end
	return nil
end
return function(p_u_27)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_1, (copy) v_u_5, (copy) v_u_8, (copy) v_u_26, (copy) v_u_2, (copy) v_u_21, (copy) v_u_12, (copy) v_u_9, (copy) v_u_10, (copy) v_u_7, (copy) v_u_11
	return {
		["w7_pantera"] = function(p_u_28, p29)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) p_u_27, (ref) v_u_6, (ref) v_u_1, (ref) v_u_5, (ref) v_u_8, (ref) v_u_26, (ref) v_u_2, (ref) v_u_21, (ref) v_u_12, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11
			local v30 = v_u_4.color(p29.color)
			local v_u_31 = v_u_4.color(p29.color2)
			local v32 = p_u_28.headY / 1.5
			local v_u_33 = math.clamp(v32, 0.7, 3)
			local v_u_34 = {}
			local v_u_35 = Instance.new("Attachment")
			v_u_35.Parent = v_u_3.Terrain
			p_u_27.own(p_u_28, v_u_35)
			local v_u_36 = Instance.new("ParticleEmitter")
			v_u_36.Enabled = false
			v_u_36.Texture = v_u_6.PanteraClaw
			v_u_36.Color = ColorSequence.new(v_u_31)
			v_u_36.LightEmission = 0.2
			v_u_36.LightInfluence = 0
			v_u_36.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_36.EmissionDirection = Enum.NormalId.Top
			v_u_36.SpreadAngle = Vector2.zero
			v_u_36.Speed = NumberRange.new(0.01)
			v_u_36.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_33 * 0.6 * p_u_28.fx), NumberSequenceKeypoint.new(0.08, v_u_33 * 1.7 * p_u_28.fx), NumberSequenceKeypoint.new(1, v_u_33 * 1.8 * p_u_28.fx) })
			v_u_36.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.1), NumberSequenceKeypoint.new(1, 1) })
			v_u_36.Lifetime = NumberRange.new(1.4)
			v_u_36.Parent = v_u_35
			local v37 = p_u_28.stops
			local function v38()
				-- upvalues: (ref) v_u_1, (copy) v_u_35
				v_u_1:AddItem(v_u_35, 1.6)
			end
			table.insert(v37, v38)
			local v_u_39 = 1
			local v_u_56 = p_u_27.throb(p_u_28, 5.5, 2, 1.6, function(p40)
				-- upvalues: (ref) v_u_39, (copy) v_u_33, (ref) p_u_27, (ref) v_u_6, (copy) v_u_31, (copy) p_u_28, (ref) v_u_4, (ref) v_u_1, (ref) v_u_5, (copy) v_u_35, (copy) v_u_36, (ref) v_u_8
				v_u_39 = -v_u_39
				local v41 = p40.RightVector * v_u_39
				local v42 = p40.LookVector
				local v43 = p40.Position + v41 * 2.2 * v_u_33 + v42 * 0.8 * v_u_33
				local v44 = v_u_33 * 0.6
				local v45 = v43 + Vector3.new(0, v44, 0)
				local v46 = p_u_27.camPos() - v45
				local v47 = v46.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v46.Unit
				local v48 = CFrame.lookAt(v45, v45 + v47) * CFrame.Angles(1.5707963267948966, 0, 0)
				local v49 = p_u_27.picture(v_u_33 * 1.2, v_u_6.PanteraClaw, v_u_31, 0)
				v49.CFrame = v48 * CFrame.Angles(0, v_u_39 * 0.5, 0)
				p_u_27.own(p_u_28, v49)
				local v50 = v_u_33 * 5 * p_u_28.fx
				v_u_4.tween(v49, 0.1, {
					["Size"] = Vector3.new(v50, 0.05, v50)
				}, Enum.EasingStyle.Quart)
				for _, v_u_51 in v49:GetChildren() do
					if not v_u_51:IsA("Decal") then
						continue
					end
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_51
						v_u_4.tween(v_u_51, 0.35, {
							["Transparency"] = 1
						})
					end)
				end
				v_u_1:AddItem(v49, 0.5)
				v_u_4.flash(v45, v_u_31, v_u_33 * 2.5, 0.18)
				if v_u_5.level() >= 2 then
					v_u_35.WorldCFrame = CFrame.new(p_u_27.feetAt(p_u_28, p40, 0.1) + v41 * 1.6 * v_u_33 + v42 * 0.6 * v_u_33)
					local v52 = v42.X
					local v53 = v42.Z
					local v54 = math.atan2(v52, v53)
					local v55 = math.deg(v54) + 0 + v_u_39 * 25
					v_u_36.Rotation = NumberRange.new(v55, v55)
					v_u_36:Emit(1)
				end
				v_u_4.ring(p_u_27.feetAt(p_u_28, p40, 0.15), v_u_8, 5 * p_u_28.fx, 0.45, v_u_6.Ring)
			end)
			local v57 = v_u_26(p_u_28, { "Head" })
			local v58 = v_u_2:FindFirstChild("EyePieces")
			if v58 then
				v58 = v58:FindFirstChild("w7_pantera")
			end
			if v57 and (v58 and v58:IsA("MeshPart")) then
				local v59 = v58:Clone()
				local v60 = v58.Size
				local v61 = v_u_33 * 1.25
				local v62 = v58.Size.X
				local v63 = v58.Size.Y
				local v64 = v58.Size.Z
				v59.Size = v60 * (v61 / math.max(v62, v63, v64, 0.01))
				v59.CanCollide = false
				v59.CanQuery = false
				v59.CanTouch = false
				v59.CastShadow = false
				v59.Parent = v_u_4.folder()
				v_u_21(p_u_28, v57, v59, CFrame.new(Vector3.new(0.62, 0.12, 0.05) * v_u_33) * v_u_12)
			elseif v57 then
				v_u_21(p_u_28, v57, p_u_27.bar(Vector3.new(0.14, 0.2, 0.85) * v_u_33, v_u_9, 0, v_u_10), CFrame.new(v_u_33 * 0.55, v_u_33 * -0.3, v_u_33 * -0.05) * CFrame.Angles(0, 0.15, 0))
				for v65 = 1, 4 do
					local v66 = p_u_27.bar
					local v67 = Vector3.new(0.08, 0.22, 0.12) * v_u_33
					local v68
					if v65 % 2 == 0 then
						v68 = v_u_7
					else
						v68 = v_u_31
					end
					local v69 = v66(v67, v68)
					v69.Shape = v_u_11
					v_u_21(p_u_28, v57, v69, CFrame.new(v_u_33 * 0.52, v_u_33 * -0.12, (v65 * 0.16 + -0.38) * v_u_33) * CFrame.Angles(0, 1.5707963267948966, 0))
				end
			end
			for _, v70 in { -1, 1 } do
				local v71 = v_u_26(p_u_28, v70 > 0 and { "RightHand", "Right Arm" } or { "LeftHand", "Left Arm" })
				if not v71 then
					continue
				end
				local v72 = -v71.Size.Y / 2
				local v73 = v71.Size.X
				local v74 = math.min(v73, 1) * 0.85
				for v75 = 1, 5 do
					local v76 = (v75 - 3) / 2
					local v77 = (0.85 - math.abs(v76) * 0.2) * v_u_33
					local v78 = p_u_27.bar
					local v79 = v_u_33 * 0.06
					local v80 = v_u_33 * 0.16
					local v81 = v78(Vector3.new(v79, v77, v80), v_u_31)
					v81.Shape = v_u_11
					v_u_21(p_u_28, v71, v81, CFrame.new(v76 * v74 / 2, v72 - v77 / 2 + v_u_33 * 0.05, v_u_33 * -0.08) * CFrame.Angles(0.3, 0, -v76 * 0.18 * v70) * CFrame.Angles(3.141592653589793, 0, 0))
					table.insert(v_u_34, v81)
					if v75 ~= 3 or v_u_5.level() < 2 then
						continue
					end
					p_u_27.tail(v81, v_u_31, v30, v_u_33 * 0.3, 0.18)
				end
			end
			local v_u_82 = -1
			local v83 = p_u_28.ticks
			local function v88()
				-- upvalues: (copy) v_u_56, (ref) v_u_82, (copy) v_u_31, (ref) v_u_7, (copy) v_u_34
				local v84 = v_u_56() * 10
				local v85 = math.floor(v84) / 10
				if v85 ~= v_u_82 then
					v_u_82 = v85
					local v86 = v_u_31:Lerp(v_u_7, v85 * 0.8)
					for _, v87 in v_u_34 do
						v87.Color = v86
					end
				end
			end
			table.insert(v83, v88)
			local function v_u_99(p89, p90, p91) -- name: tailPoint
				-- upvalues: (copy) v_u_33
				local v92 = p90 * 2.1 - p91 * 3.4
				local v93 = math.sin(v92) * 0.75 * v_u_33 * p91
				local v94 = v_u_33 * -0.75
				local v95 = v_u_33 * 0.95
				local v96 = p91 * 3.141592653589793 * 0.75
				local v97 = v94 - v95 * math.sin(v96) + v_u_33 * 0.85 * p91 ^ 3
				local v98 = v_u_33 * 0.45 + v_u_33 * 2.7 * p91
				return (p89 * CFrame.new(v93, v97, v98)).Position
			end
			for v100 = 1, 8 do
				local v_u_101 = (v100 - 1) / 8
				local v_u_102 = v100 / 8
				local v_u_103 = (0.5 - v_u_101 * 0.34) * v_u_33
				local v104 = v100 == 8
				local v105 = p_u_27.blob
				local v106 = Vector3.new(v_u_103, v_u_103, 1)
				local v107
				if v104 then
					v107 = v_u_31
				else
					v107 = v_u_9
				end
				local v108 = 0
				local v109
				if v104 then
					v109 = nil
				else
					v109 = v_u_10
				end
				local v_u_110 = v105(v106, v107, v108, v109)
				p_u_27.add(p_u_28, v_u_110, function(p111, p112)
					-- upvalues: (copy) v_u_99, (copy) v_u_101, (copy) v_u_102, (copy) v_u_110, (copy) v_u_103
					local v113 = v_u_99(p111, p112, v_u_101)
					local v114 = v_u_99(p111, p112, v_u_102)
					local v115 = (v114 - v113).Magnitude
					local v116 = math.max(v115, 0.05)
					local v117 = v_u_110
					local v118 = v_u_103
					local v119 = v_u_103
					local v120 = v116 * 1.6
					v117.Size = Vector3.new(v118, v119, v120)
					return CFrame.lookAt((v113 + v114) / 2, v114)
				end)
				if not v104 or v_u_5.level() < 2 then
					continue
				end
				p_u_27.tail(v_u_110, v_u_31, v30, v_u_33 * 0.25, 0.3)
			end
			p_u_27.particles(p_u_28, "AuraMode", v30, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
		end
	}
end