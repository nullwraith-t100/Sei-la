local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("C9B8FF")
local v_u_9 = Color3.fromHex("EFFFFF")
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(238, 234, 255)
local v_u_12 = Color3.fromRGB(214, 236, 255)
local v_u_13 = Color3.fromRGB(165, 140, 255)
local v_u_14 = Enum.Material.Glass
local v_u_15 = Enum.Material.Neon
local function v_u_25(p16, p17, p18, p19, p20) -- name: pic
	-- upvalues: (copy) v_u_5
	local v21 = math.max(p17, 0.05)
	local v22 = v_u_5.part(Vector3.new(v21, 0.05, v21), p16, p19, {
		["transparency"] = 1
	})
	for _, v23 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p18
		v24.Color3 = p19
		v24.Transparency = p20
		v24.Parent = v22
	end
	return v22
end
local function v_u_29(p26, p27) -- name: setAlpha
	for _, v28 in p26:GetChildren() do
		if not v28:IsA("Decal") then
			continue
		end
		v28.Transparency = math.clamp(p27, 0, 1)
	end
end
local function v_u_34(p30, p31, p32) -- name: wedge
	-- upvalues: (copy) v_u_5
	local v33 = Instance.new("WedgePart")
	v33.Anchored = true
	v33.CanCollide = false
	v33.CanQuery = false
	v33.CanTouch = false
	v33.CastShadow = false
	v33.Color = p30
	v33.Material = p31
	v33.Transparency = p32 or 0
	v33.Size = Vector3.new(0.1, 0.1, 0.1)
	v33.CFrame = CFrame.new(0, -500, 0)
	v33.Parent = v_u_5.folder()
	return v33
end
local function v_u_43(p35, p36, p37, p38, p39, p40) -- name: shard
	-- upvalues: (copy) v_u_34, (copy) v_u_1
	local v41 = v_u_34(p35, p36, p40)
	local v42 = v_u_34(p35, p36, p40)
	v_u_1:AddItem(v41, p39)
	v_u_1:AddItem(v42, p39)
	return {
		["a"] = v41,
		["b"] = v42,
		["wide"] = p37,
		["deep"] = p38
	}
end
local function v_u_56(p44, p45, p46, p47, p48) -- name: put
	local v49 = math.max(p48, 0.05)
	local v50 = p46.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p46.Unit
	local v51 = p47 - v50 * p47:Dot(v50)
	if v51.Magnitude < 0.001 then
		v51 = v50:Cross(Vector3.new(1, 0, 0))
		if v51.Magnitude < 0.001 then
			v51 = v50:Cross(Vector3.new(0, 0, 1))
		end
	end
	local v52 = CFrame.fromMatrix(p45 + v50 * (v49 / 2), v51.Unit, v50)
	local v53 = p44.wide
	local v54 = p44.deep / 2
	local v55 = Vector3.new(v53, v49, v54)
	p44.a.Size = v55
	p44.b.Size = v55
	p44.a.CFrame = v52 * CFrame.new(0, 0, -p44.deep / 4)
	p44.b.CFrame = v52 * CFrame.new(0, 0, p44.deep / 4) * CFrame.Angles(0, 3.141592653589793, 0)
end
local function v_u_66(p57, p58) -- name: bloomPiece
	-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_14, (copy) v_u_5, (copy) v_u_1
	local v59 = v_u_3:FindFirstChild("EyePieces")
	if v59 then
		v59 = v59:FindFirstChild("w6_hakka_bloom")
	end
	if not (v59 and v59:IsA("MeshPart")) then
		return nil
	end
	local v60 = v59:Clone()
	v60.Anchored = true
	v60.CanCollide = false
	v60.CanQuery = false
	v60.CanTouch = false
	v60.CastShadow = false
	local v61 = v59.Size
	local v62 = v59.Size.X
	local v63 = v59.Size.Z
	v60.Size = v61 * (p57 / math.max(v62, v63, 0.01))
	local v64 = v60:FindFirstChildWhichIsA("SurfaceAppearance")
	if v64 then
		local v65 = v64.EmissiveStrength
		v64.EmissiveStrength = math.max(v65, 5)
	else
		v60.Color = v_u_9
		v60.Material = v_u_14
		v60.Transparency = 0.1
		v60.Reflectance = 0.2
	end
	v60.CFrame = CFrame.new(0, -500, 0)
	v60.Parent = v_u_5.folder()
	v_u_1:AddItem(v60, p58)
	return v60
end
local function v_u_74(p67, p68, p69, p70, p71) -- name: glitter
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_13, (copy) v_u_12, (copy) v_u_1
	if p68 > 0 then
		local v72 = Instance.new("Attachment")
		v72.WorldPosition = p67
		v72.Parent = v_u_4.Terrain
		local v73 = Instance.new("ParticleEmitter")
		v73.Enabled = false
		v73.Texture = v_u_7.FxTwinkle
		v73.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v73.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v73.Color = ColorSequence.new(v_u_13, v_u_12)
		v73.LightEmission = 0.45
		v73.LightInfluence = 0
		v73.Size = NumberSequence.new(p69)
		v73.Lifetime = NumberRange.new(p71 * 0.55, p71)
		v73.Speed = NumberRange.new(p70 * 0.3, p70)
		v73.SpreadAngle = Vector2.new(180, 180)
		v73.Drag = 2.2
		v73.Acceleration = Vector3.new(0, -1.5, 0)
		v73.Rotation = NumberRange.new(0, 45)
		v73.Parent = v72
		v73:Emit(p68)
		v_u_1:AddItem(v72, p71 + 0.3)
	end
end
local function v_u_82(p75, p76, p77, p78, p79) -- name: flowerBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_1
	local v80 = Instance.new("Attachment")
	v80.WorldPosition = p75
	v80.Parent = v_u_4.Terrain
	local v81 = Instance.new("ParticleEmitter")
	v81.Enabled = false
	v81.Texture = p79 or v_u_7.HakkaFlower
	v81.Color = ColorSequence.new(p78)
	v81.LightEmission = 0.2
	v81.LightInfluence = 0
	v81.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p76 * 0.1), NumberSequenceKeypoint.new(0.3, p76 * 0.5), NumberSequenceKeypoint.new(1, p76 * 0.58) })
	v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v81.Lifetime = NumberRange.new(p77)
	v81.Speed = NumberRange.new(0)
	v81.Rotation = NumberRange.new(0, 360)
	v81.RotSpeed = NumberRange.new(70, 90)
	v81.ZOffset = 1
	v81.Parent = v80
	v81:Emit(1)
	v_u_1:AddItem(v80, p77 + 0.2)
end
local function v_u_97(p83, p84, p85, p86, p87, p88) -- name: mist
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_1
	if p84 > 0 then
		local v89 = Instance.new("Attachment")
		v89.WorldPosition = p83
		v89.Parent = v_u_4.Terrain
		local v90 = Instance.new("ParticleEmitter")
		v90.Enabled = false
		v90.Texture = v_u_7.FxSmoke
		v90.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v90.FlipbookMode = Enum.ParticleFlipbookMode.Loop
		v90.FlipbookFramerate = NumberRange.new(0)
		v90.FlipbookStartRandom = true
		v90.Color = ColorSequence.new(v_u_10, v_u_11)
		v90.LightEmission = 0.25
		v90.LightInfluence = 0
		v90.Size = NumberSequence.new(p85 * 0.6, p85)
		v90.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0.7),
			NumberSequenceKeypoint.new(0.15, 0.4),
			NumberSequenceKeypoint.new(0.75, 0.55),
			NumberSequenceKeypoint.new(1, 1)
		})
		v90.Lifetime = NumberRange.new(p87 * 0.8, p87)
		v90.Speed = NumberRange.new(p86 * 0.55, p86)
		v90.Drag = 2.5
		v90.Rotation = NumberRange.new(0, 360)
		v90.RotSpeed = NumberRange.new(-20, 20)
		v90.Parent = v89
		if p88 then
			v90.EmissionDirection = Enum.NormalId.Front
			v90.SpreadAngle = Vector2.new(14, 3)
			for v91 = 1, 12 do
				local v92 = v91 * 3.141592653589793 * 2 / 12
				local v93 = CFrame.lookAt
				local v94 = math.cos(v92)
				local v95 = math.sin(v92)
				v89.WorldCFrame = v93(p83, p83 + Vector3.new(v94, 0.04, v95))
				local v96 = p84 / 12
				v90:Emit((math.ceil(v96)))
			end
		else
			v90.SpreadAngle = Vector2.new(180, 180)
			v90:Emit(p84)
		end
		v_u_1:AddItem(v89, p87 + 0.3)
	end
end
local function v_u_106(p98, p99, p100, p101, p102, p_u_103) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	local v_u_104 = Instance.new("ColorCorrectionEffect")
	v_u_104.Name = "HakkaNoTogame"
	v_u_104.Parent = v_u_2
	v_u_5.tween(v_u_104, p101, {
		["TintColor"] = p98,
		["Brightness"] = p99,
		["Saturation"] = p100
	})
	task.delay(p101 + p102, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_104, (copy) p_u_103, (ref) v_u_10
		local v105 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_10
		}
		v_u_5.tween(v_u_104, p_u_103, v105)
	end)
	v_u_1:AddItem(v_u_104, p101 + p102 + p_u_103 + 0.1)
end
return function(p_u_107)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_10, (copy) v_u_8, (copy) v_u_12, (copy) v_u_7, (copy) v_u_43, (copy) v_u_14, (copy) v_u_15, (copy) v_u_56, (copy) v_u_74, (copy) v_u_13, (copy) v_u_25, (copy) v_u_29, (copy) v_u_5, (copy) v_u_82, (copy) v_u_9, (copy) v_u_66, (copy) v_u_97, (copy) v_u_11, (copy) v_u_6, (copy) v_u_106
	local v108 = {}
	local function v_u_140(p109, p110, p111, p112, p113, p114, p115, p116, p117, p118) -- name: opening
		-- upvalues: (ref) v_u_4, (ref) v_u_1
		local v119 = p115 + p116 + p117
		local v120 = math.max(v119, 0.05)
		local v121 = {}
		local v122 = {}
		for v123 = 0, 16 do
			local v124 = v123 / 16
			local v125 = v124 * v120
			local v126 = v125 / math.max(p115, 0.001)
			local v127 = math.clamp(v126, 0, 1) - 1
			local v128 = v127 * 2.7 * v127 * v127 + 1 + v127 * 1.7 * v127
			local v129 = (v125 - p115 - p116) / math.max(p117, 0.001)
			local v130 = math.clamp(v129, 0, 1)
			local v131 = v130 * v130 * (3 - v130 * 2)
			local v132 = NumberSequenceKeypoint.new
			local v133 = p110 + (p111 - p110) * v128 + p111 * 0.12 * v131
			local v134 = math.max(v133, 0.05) / 2
			table.insert(v122, v132(v124, v134))
			local v135 = NumberSequenceKeypoint.new
			local v136 = p114 + (1 - p114) * v131
			local v137 = math.clamp(v136, 0, 1)
			table.insert(v121, v135(v124, v137))
		end
		local v138 = Instance.new("Attachment")
		v138.WorldCFrame = CFrame.new(p109.Position)
		v138.Parent = v_u_4.Terrain
		local v139 = Instance.new("ParticleEmitter")
		v139.Enabled = false
		v139.Texture = p112
		v139.Color = ColorSequence.new(p113)
		v139.LightEmission = 0.15
		v139.LightInfluence = 0
		v139.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v139.EmissionDirection = Enum.NormalId.Top
		v139.SpreadAngle = Vector2.zero
		v139.Speed = NumberRange.new(0.01)
		v139.Size = NumberSequence.new(v122)
		v139.Transparency = NumberSequence.new(v121)
		v139.Lifetime = NumberRange.new(v120)
		v139.Rotation = NumberRange.new(0, 360)
		v139.RotSpeed = NumberRange.new((math.deg(p118)))
		v139.Parent = v138
		v139:Emit(1)
		v_u_1:AddItem(v138, v120 + 0.2)
	end
	local function v_u_148(p141, p142, p143) -- name: shatter
		-- upvalues: (copy) p_u_107, (ref) v_u_10, (ref) v_u_8, (ref) v_u_12
		for v144, v145 in p141 do
			if v145.a.Parent then
				local v146 = (v145.a.Position + v145.b.Position) / 2
				if not p143 and v144 % 2 == 1 then
					local v147 = { v_u_10, v_u_8, v_u_12 }
					p_u_107.chunks(v146, v147, 2, p142 * 14, p142 * 0.45, 0.7, true, 0.5)
				end
				if v144 % 3 == 1 then
					p_u_107.glint(v146, v_u_10, p142 * 2.2, 0.16)
				end
			end
			v145.a:Destroy()
			v145.b:Destroy()
		end
	end
	local function v_u_177(p149, p_u_150, p151) -- name: frostFlower
		-- upvalues: (copy) v_u_140, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_43, (ref) v_u_14, (ref) v_u_15, (copy) p_u_107, (ref) v_u_56, (copy) v_u_148, (ref) v_u_74
		local v_u_152 = p149.size
		local v153 = v_u_140
		local v154 = CFrame.new(p_u_150) * CFrame.Angles(0, math.random() * 6.28, 0)
		local v155 = 0.4 * v_u_152
		local v156 = (2.3 + math.random() * 0.8) * v_u_152
		local v157 = v_u_7.HakkaFlower
		local v158
		if p151 % 2 == 0 then
			v158 = v_u_10
		else
			v158 = v_u_8
		end
		v153(v154, v155, v156, v157, v158, 0, 0.14, 0.25, 0.35, 1.6)
		if not p149.lite and p151 % 2 ~= 0 then
			local v159 = v_u_43
			local v160
			if p151 % 4 == 1 then
				v160 = v_u_10
			else
				v160 = v_u_8
			end
			local v161
			if p151 % 4 == 1 then
				v161 = v_u_14
			else
				v161 = v_u_15
			end
			local v_u_162 = v159(v160, v161, 0.22 * v_u_152, 0.75 * v_u_152, 1)
			local v163 = math.random() - 0.5
			local v164 = math.random() - 0.5
			local v_u_165 = (Vector3.new(0, 1, 0) + Vector3.new(v163, 0, v164) * 0.5).Unit
			local v_u_166 = v_u_165:Cross(Vector3.new(0, 1, 0))
			p_u_107.animate(0.42, 0, function(p167)
				-- upvalues: (ref) v_u_56, (copy) v_u_162, (copy) p_u_150, (copy) v_u_165, (copy) v_u_166, (copy) v_u_152, (ref) v_u_148, (ref) v_u_74
				local v168 = v_u_56
				local v169 = v_u_162
				local v170 = p_u_150 - Vector3.new(0, 0.2, 0)
				local v171 = v_u_165
				local v172 = v_u_166.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v_u_166
				local v173 = 1.7 * v_u_152
				local v174 = p167 / 0.3
				local v175 = math.clamp(v174, 0, 1) - 1
				local v176 = v175 * 2.7 * v175 * v175 + 1 + v175 * 1.7 * v175
				v168(v169, v170, v171, v172, v173 * math.max(v176, 0.05))
				if p167 >= 1 then
					v_u_148({ v_u_162 }, 0.6 * v_u_152, false)
					v_u_74(p_u_150 + Vector3.new(0, 0.8, 0) * v_u_152, 4, 0.5 * v_u_152, 7, 0.8)
				end
			end)
		end
	end
	v108.hakka_no_togame_a = {
		["cast"] = function(p178) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_107, (ref) v_u_10
			local v179 = p178.size
			local v180 = p178.eye + p178.dir * 1.1
			v_u_5.flash(v180, v_u_8, 2.6 * v179, 0.1)
			p_u_107.pop(v180, v_u_10, 1.2 * v179, 0.3 * v179, 0.08)
		end,
		["beam"] = function(p_u_181, p182, p183) -- name: shirafune
			-- upvalues: (copy) p_u_107, (ref) v_u_10, (ref) v_u_13, (ref) v_u_7, (ref) v_u_25, (ref) v_u_1, (ref) v_u_29, (copy) v_u_177
			local v_u_184 = p_u_181.size
			local v185 = p183 - p182
			local v186 = v185.Magnitude
			if v186 >= 1 then
				local v187 = v185.Unit
				local v188 = v187.X
				local v189 = v187.Z
				local v190 = Vector3.new(v188, 0, v189)
				local v191 = v190.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v190.Unit
				local v192 = p182 + v187 * 0.9
				p_u_107.thin(p_u_107.rod(v192, p183, 0.32 * v_u_184, v_u_10), 0.2, true)
				if not p_u_181.lite then
					p_u_107.thin(p_u_107.rod(v192, p183, 1.15 * v_u_184, v_u_13, 0.35), 0.3)
				end
				p_u_107.glowBeam(v192, p183, v_u_13, 2.4 * v_u_184, 0.24, v_u_7.Beam)
				local v_u_193 = p182 + v191 * 3.3 * v_u_184 - Vector3.new(0, 0.5, 0)
				local v194 = -v191.X
				local v195 = -v191.Z
				local v_u_196 = math.atan2(v194, v195)
				local v_u_197 = v_u_25(CFrame.new(v_u_193), 7 * v_u_184, v_u_7.HakkaMistArc, v_u_13, 0)
				v_u_1:AddItem(v_u_197, 0.5)
				p_u_107.animate(0.3, 0, function(p198)
					-- upvalues: (copy) v_u_197, (copy) v_u_193, (copy) v_u_196, (copy) v_u_184, (ref) v_u_29
					local v199 = p198 / 0.5
					local v200 = math.clamp(v199, 0, 1)
					local v201 = v200 * v200 * (3 - v200 * 2) * 1.8 + -0.9
					v_u_197.CFrame = CFrame.new(v_u_193) * CFrame.Angles(0, v_u_196 + v201, 0) * CFrame.Angles(0.2, 0, 0)
					local v202 = v_u_197
					local v203 = (7 + 3 * p198) * v_u_184
					local v204 = math.max(v203, 0.05)
					v202.Size = Vector3.new(v204, 0.05, v204)
					local v205 = v_u_29
					local v206 = v_u_197
					local v207 = (p198 - 0.35) / 0.65
					local v208 = math.clamp(v207, 0, 1)
					v205(v206, v208 * v208 * (3 - v208 * 2))
					if p198 >= 1 then
						v_u_197:Destroy()
					end
				end)
				local v209
				if p_u_181.lite then
					v209 = 3
				else
					local v210 = v186 / 12
					local v211 = math.floor(v210)
					v209 = math.clamp(v211, 3, 5)
				end
				local v212 = v191:Cross(Vector3.new(0, 1, 0))
				for v_u_213 = 1, v209 do
					local v_u_214 = p_u_107.ground(p182:Lerp(p183, (v_u_213 - 0.4) / v209), v_u_213 * 0.01 + 0.1) + v212 * (math.random() - 0.5) * 1.6 * v_u_184
					p_u_107.after((v_u_213 - 1) * 0.03, function()
						-- upvalues: (ref) v_u_177, (copy) p_u_181, (copy) v_u_214, (copy) v_u_213
						v_u_177(p_u_181, v_u_214, v_u_213)
					end)
				end
			end
		end,
		["hit"] = function(p215, p216, _) -- name: hit
			-- upvalues: (copy) p_u_107, (ref) v_u_8, (ref) v_u_82, (ref) v_u_10
			p_u_107.beamHitSound(p215, p216, "Hit")
			p_u_107.burst("Impact", p216, v_u_8, 0.55)
			if not p215.lite then
				v_u_82(p216, 3.4, 0.4, v_u_10)
			end
		end
	}
	local v_u_217 = {}
	setmetatable(v_u_217, {
		["__mode"] = "k"
	})
	local function v_u_223(p218, p219, p220, p221) -- name: blossom
		-- upvalues: (ref) v_u_82, (ref) v_u_10, (ref) v_u_13, (ref) v_u_7, (copy) p_u_107, (ref) v_u_8, (ref) v_u_12, (ref) v_u_74
		v_u_82(p219, p221 * 2.8, 0.8, v_u_10)
		if not p218.lite then
			v_u_82(p219, p221 * 3.6, 0.6, v_u_13, v_u_7.Glow)
			local v222 = { v_u_10, v_u_8, v_u_12 }
			p_u_107.chunks(p219, v222, 4, 16, 0.5, 0.8, true, 0.6)
		end
		v_u_74(p219, p218.lite and 5 or 16, 0.9, 14, 1.5)
		p_u_107.glint(p219 + Vector3.new(0, 1, 0) * p220 * 0.2, v_u_10, 4, 0.2)
	end
	local function v_u_275(p_u_224, p225, p226) -- name: encase
		-- upvalues: (ref) v_u_4, (copy) p_u_107, (ref) v_u_5, (ref) v_u_12, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_25, (ref) v_u_7, (ref) v_u_66, (ref) v_u_1, (copy) v_u_223
		local v_u_227 = p_u_224.ability.freeze or 3
		local v228 = v_u_4:FindFirstChild("MyEnemies")
		local v_u_229
		if v228 then
			v_u_229 = v228:FindFirstChild("Foe" .. p226)
		else
			v_u_229 = nil
		end
		local v_u_230, v_u_231
		if v_u_229 and v_u_229:IsA("Model") then
			local _, v232 = v_u_229:GetBoundingBox()
			local v233 = v232.Y * 1.15
			v_u_230 = math.clamp(v233, 4, 14)
			local v234 = v232.X
			local v235 = v232.Z
			local v236 = math.max(v234, v235) * 1.05
			v_u_231 = math.clamp(v236, 3, 10)
		else
			v_u_231 = 3.6
			v_u_230 = 6
		end
		local v_u_237 = p_u_107.ground(p225, 0)
		local v_u_238 = math.random() * 3.141592653589793
		local v239 = {
			["material"] = nil,
			["transparency"] = 0.5,
			["material"] = v_u_14
		}
		local v_u_240 = v_u_5.part(Vector3.new(v_u_231, 0.1, v_u_231), CFrame.new(v_u_237), v_u_12, v239)
		local v241 = {
			["material"] = nil,
			["transparency"] = 0.5,
			["material"] = v_u_14
		}
		local v_u_242 = v_u_5.part(Vector3.new(v_u_231, 0.1, v_u_231), CFrame.new(v_u_237), v_u_9, v241)
		local v243 = {
			["material"] = nil,
			["transparency"] = 0.35,
			["material"] = v_u_14
		}
		local v_u_244 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_231 * 0.62, CFrame.new(v_u_237), v_u_8, v243)
		local v_u_245 = { v_u_240, v_u_242, v_u_244 }
		local v_u_246
		if p_u_224.lite then
			v_u_246 = nil
		else
			local v247 = v_u_25
			local v248 = v_u_237 + Vector3.new(0, 1, 0) * v_u_230 * 0.5
			local v249 = v_u_4.CurrentCamera
			local v250
			if v249 then
				local v251 = v249.CFrame.Position - v248
				v250 = v251.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v251.Unit
			else
				v250 = Vector3.new(0, 0, 1)
			end
			local v252 = v248 - v250 * 0
			v_u_246 = v247(CFrame.lookAt(v252, v252 + v250) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_231 * 1.6, v_u_7.Glow, v_u_8, 0.45)
			table.insert(v_u_245, v_u_246)
		end
		local v_u_253
		if p_u_224.lite then
			v_u_253 = nil
		else
			v_u_253 = v_u_66(v_u_231 * 1.7, v_u_227 + 1)
		end
		local v_u_254 = not v_u_253 and Vector3.new(1, 1, 1) or v_u_253.Size
		for _, v255 in v_u_245 do
			v_u_1:AddItem(v255, v_u_227 + 1)
		end
		local v_u_256 = os.clock()
		p_u_107.runNow(function()
			-- upvalues: (copy) v_u_256, (copy) v_u_229, (copy) v_u_227, (copy) v_u_245, (copy) v_u_253, (ref) v_u_223, (copy) p_u_224, (copy) v_u_237, (ref) v_u_230, (ref) v_u_231, (copy) v_u_238, (copy) v_u_240, (copy) v_u_242, (copy) v_u_244, (ref) v_u_246, (ref) v_u_4, (copy) v_u_254
			local v257 = os.clock() - v_u_256
			local v258
			if v_u_229 == nil then
				v258 = false
			else
				v258 = v_u_229.Parent == nil
			end
			if v_u_227 <= v257 or v258 then
				for _, v259 in v_u_245 do
					v259:Destroy()
				end
				if v_u_253 then
					v_u_253:Destroy()
				end
				v_u_223(p_u_224, v_u_237 + Vector3.new(0, 1, 0) * v_u_230 * 0.5, v_u_230, v_u_231)
				return false
			end
			local v260 = v257 / 0.18
			local v261 = math.clamp(v260, 0, 1) - 1
			local v262 = v261 * 2.7 * v261 * v261 + 1 + v261 * 1.7 * v261
			local v263 = math.max(v262, 0.03)
			local v264 = v_u_230 * v263
			local v265 = CFrame.Angles(0, v_u_238, 0)
			local v266 = v_u_240
			local v267 = v_u_231 * 0.86
			local v268 = v_u_231 * 0.86
			v266.Size = Vector3.new(v267, v264, v268)
			v_u_240.CFrame = CFrame.new(v_u_237 + Vector3.new(0, 1, 0) * v264 / 2) * v265
			v_u_242.Size = v_u_240.Size
			v_u_242.CFrame = v_u_240.CFrame * CFrame.Angles(0, 0.7853981633974483, 0)
			v_u_244.Size = Vector3.new(1, 1, 1) * v_u_231 * 0.62 * v263
			v_u_244.CFrame = CFrame.new(v_u_237 + Vector3.new(0, 1, 0) * (v264 + v_u_231 * 0.08)) * v265 * CFrame.Angles(0.7853981633974483, 0, 0.6154030942532006)
			local v269 = v_u_246
			if v269 then
				local v270 = v_u_237 + Vector3.new(0, 1, 0) * v264 * 0.5
				local v271 = v_u_4.CurrentCamera
				local v272
				if v271 then
					local v273 = v271.CFrame.Position - v270
					v272 = v273.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v273.Unit
				else
					v272 = Vector3.new(0, 0, 1)
				end
				local v274 = v270 - v272 * 0
				v269.CFrame = CFrame.lookAt(v274, v274 + v272) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end
			if v_u_253 then
				v_u_253.Size = v_u_254 * v263
				v_u_253.CFrame = CFrame.new(v_u_237 + Vector3.new(0, 1, 0) * v_u_253.Size.Y * 0.3) * v265
			end
			return true
		end)
	end
	v108.hakka_no_togame_e = {
		["cast"] = function(p276) -- name: cast
			-- upvalues: (copy) p_u_107, (ref) v_u_8, (ref) v_u_10, (ref) v_u_97
			local v277 = p276.size
			p_u_107.skillCast(p276, v_u_8)
			p_u_107.glint(p276.eye, v_u_10, 4 * v277, 0.2)
			if not p276.lite then
				v_u_97(p276.eye + p276.dir * 0.9, 6, 1.4 * v277, 7, 0.9, false)
			end
		end,
		["windup"] = function(p278, p279, p280) -- name: windup
			-- upvalues: (copy) p_u_107, (ref) v_u_11, (ref) v_u_5, (ref) v_u_10
			local v281 = p278.size
			local v282 = math.max(p280, 0.1)
			p_u_107.inward(p_u_107.ground(p279, 1.5), v_u_11, p278.lite and 4 or 9, 9 * v281, v282 + 0.05)
			v_u_5.flash(p_u_107.ground(p279, 2), v_u_10, 5 * v281, v282)
		end,
		["land"] = function(p_u_283, p284) -- name: land
			-- upvalues: (copy) p_u_107, (copy) v_u_140, (ref) v_u_7, (ref) v_u_11, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_97, (ref) v_u_13, (ref) v_u_12, (ref) v_u_1, (ref) v_u_6, (ref) v_u_106, (ref) v_u_74
			local v_u_285 = p_u_283.size
			local v_u_286 = p_u_283.lite
			local v_u_287 = p_u_283.ability.radius * v_u_285
			local v288 = p_u_283.ability.freeze or 3
			local v_u_289 = p_u_107.ground(p284, 0.1)
			v_u_140(CFrame.new(v_u_289 + Vector3.new(0, 0.15, 0)), 3 * v_u_285, v_u_287 * 2.3, v_u_7.HakkaMist, v_u_11, 0.05, 0.5, 0, 0.5, 1.2)
			v_u_140(CFrame.new(v_u_289 + Vector3.new(0, 0.25, 0)) * CFrame.Angles(0, 2, 0), 2 * v_u_285, v_u_287 * 2, v_u_7.HakkaMist, v_u_10, 0.15, 0.6, 0, 0.45, -0.9)
			p_u_107.dome(v_u_289, v_u_287, v_u_11, 0.6)
			v_u_5.ring(v_u_289, v_u_10, v_u_287 * 1.1, 0.6, v_u_7.HakkaMist)
			v_u_140(CFrame.new(v_u_289 + Vector3.new(0, 0.05, 0)), 4 * v_u_285, v_u_287 * 2, v_u_7.HakkaFrost, v_u_8, 0.15, 0.55, v288 - 0.5, 0.6, 0.06)
			p_u_107.mark(p284, v_u_8, v_u_287 * 0.95, v288 + 0.4, v_u_7.Glow, 0.6)
			v_u_97(v_u_289 + Vector3.new(0, 1.2, 0), v_u_286 and 12 or 36, 5 * v_u_285, v_u_287 * 2.4, v288 + 0.6, true)
			v_u_5.flash(v_u_289 + Vector3.new(0, 3, 0), v_u_10, 9 * v_u_285, 0.3)
			if not v_u_286 then
				local v290 = v_u_5.part
				local v291 = v_u_287 * 1.5
				local v292 = v_u_287 * 1.5
				local v293 = v290(Vector3.new(v291, 1, v292), CFrame.new(v_u_289 + Vector3.new(0, 1.5, 0)), v_u_10, {
					["transparency"] = 1
				})
				local v_u_294 = Instance.new("ParticleEmitter")
				v_u_294.Texture = v_u_7.FxTwinkle
				v_u_294.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v_u_294.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v_u_294.Color = ColorSequence.new(v_u_13, v_u_12)
				v_u_294.LightEmission = 0.45
				v_u_294.LightInfluence = 0
				v_u_294.Size = NumberSequence.new(0.7 * v_u_285)
				v_u_294.Lifetime = NumberRange.new(0.8, 1.4)
				v_u_294.Speed = NumberRange.new(0.5, 2)
				v_u_294.EmissionDirection = Enum.NormalId.Top
				v_u_294.SpreadAngle = Vector2.new(40, 40)
				v_u_294.Shape = Enum.ParticleEmitterShape.Box
				v_u_294.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
				v_u_294.Rate = 18
				v_u_294.Parent = v293
				local v295 = task.delay
				local v296 = v288 - 0.3
				v295(math.max(v296, 0.1), function()
					-- upvalues: (copy) v_u_294
					v_u_294.Enabled = false
				end)
				v_u_1:AddItem(v293, v288 + 1.6)
			end
			v_u_6.play("Bind", {
				["at"] = v_u_289,
				["volume"] = p_u_283.mine and 0.8 or 0.45
			})
			if p_u_283.mine then
				v_u_5.shake(0.25, 0.25)
				v_u_106(Color3.fromRGB(232, 228, 255), 0.04, -0.3, 0.25, v288 - 0.3, 0.6)
			end
			p_u_107.after(v288, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_289, (ref) v_u_10, (copy) v_u_287, (ref) v_u_7, (ref) v_u_74, (copy) v_u_286, (copy) v_u_285, (ref) v_u_6, (copy) p_u_283
				v_u_5.ring(v_u_289, v_u_10, v_u_287 * 1.25, 0.6, v_u_7.HakkaFrost)
				v_u_74(v_u_289 + Vector3.new(0, 3, 0), v_u_286 and 10 or 36, 1.1 * v_u_285, 22 * v_u_285, 1.8)
				v_u_5.flash(v_u_289 + Vector3.new(0, 2.5, 0), v_u_10, v_u_287 * 0.7, 0.3)
				v_u_6.play("Crit", {
					["at"] = v_u_289,
					["volume"] = p_u_283.mine and 0.6 or 0.35
				})
				if p_u_283.mine then
					v_u_5.shake(0.15, 0.2)
				end
			end)
		end,
		["hit"] = function(p297, p298, p299) -- name: hit
			-- upvalues: (copy) p_u_107, (ref) v_u_8, (copy) v_u_217, (copy) v_u_275
			p_u_107.burst("Impact", p298, v_u_8, 0.6)
			local v300 = (v_u_217[p297] or 0) + 1
			v_u_217[p297] = v300
			if (p297.lite and 3 or 8) >= v300 then
				v_u_275(p297, p298, p299)
			end
		end
	}
	v108.hakka_no_togame_r = {
		["cast"] = function(p301) -- name: cast
			-- upvalues: (copy) p_u_107, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_106
			local v302 = p301.size
			p_u_107.skillCast(p301, v_u_8, true)
			p_u_107.glint(p301.eye, v_u_10, 5 * v302, 0.25)
			if p301.mine then
				v_u_5.shake(0.12, 0.15)
				v_u_106(Color3.fromRGB(226, 222, 255), 0.03, -0.25, 0.2, 1.8, 0.7)
			end
		end,
		["windup"] = function(p303, p304, p305) -- name: windup
			-- upvalues: (copy) p_u_107, (copy) v_u_140, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11, (ref) v_u_97
			local v306 = p303.size
			local v307 = p303.ability.radius * v306
			local v308 = math.max(p305, 0.15)
			local v309 = p_u_107.ground(p304, 0.12)
			local v310 = v308 + 1.3
			v_u_140(CFrame.new(v309 + Vector3.new(0, 0.02, 0)), v307 * 0.9, v307 * 3.4, v_u_7.Glow, v_u_8, 0.35, v308 + 0.2, v310 - 0.2, 0.8, 0)
			v_u_140(CFrame.new(v309 + Vector3.new(0, 0.06, 0)), v307 * 0.6, v307 * 2.4, v_u_7.HakkaFrost, v_u_8, 0.1, v308 + 0.25, v310 - 0.25, 0.8, -0.25)
			v_u_140(CFrame.new(v309 + Vector3.new(0, 0.1, 0)), v307 * 0.4, v307 * 1.9, v_u_7.HakkaFlower, v_u_10, 0, v308 + 0.3, v310 - 0.3, 0.8, 0.35)
			p_u_107.glowBeam(v309 + Vector3.new(0, 70, 0), v309, v_u_10, 3 * v306, v308 + 0.25, v_u_7.Beam)
			p_u_107.inward(v309 + Vector3.new(0, 2, 0), v_u_11, p303.lite and 5 or 10, v307 * 0.8, v308)
			if not p303.lite then
				v_u_97(v309 + Vector3.new(0, 0.8, 0), 10, 4 * v306, v307 * 0.6, v308 + 0.6, true)
			end
		end,
		["land"] = function(p_u_311, p312) -- name: land
			-- upvalues: (copy) p_u_107, (ref) v_u_5, (ref) v_u_12, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_15, (ref) v_u_1, (ref) v_u_43, (ref) v_u_66, (ref) v_u_56, (ref) v_u_7, (ref) v_u_25, (ref) v_u_4, (ref) v_u_29, (ref) v_u_97, (ref) v_u_74, (ref) v_u_6, (ref) v_u_13, (copy) v_u_148, (ref) v_u_106
			local v_u_313 = p_u_311.size
			local v_u_314 = p_u_311.lite
			local v_u_315 = p_u_311.ability.radius * v_u_313
			local v_u_316 = p_u_107.ground(p312, 0)
			local v_u_317 = v_u_315 * 1.15
			local v_u_318 = v_u_315 * 0.24
			local v319 = {
				["material"] = nil,
				["transparency"] = 0.2,
				["material"] = v_u_14
			}
			local v_u_320 = v_u_5.part(Vector3.new(v_u_318, 0.1, v_u_318), CFrame.new(v_u_316), v_u_12, v319)
			local v321 = {
				["material"] = nil,
				["transparency"] = 0.25,
				["material"] = v_u_14
			}
			local v_u_322 = v_u_5.part(Vector3.new(v_u_318, 0.1, v_u_318), CFrame.new(v_u_316), v_u_9, v321)
			local v323 = {
				["material"] = nil,
				["transparency"] = 0.1,
				["material"] = v_u_14
			}
			local v_u_324 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_318 * 0.75, CFrame.new(v_u_316), v_u_8, v323)
			local v325 = v_u_5.part
			local v326 = v_u_318 * 0.3
			local v327 = v_u_318 * 0.3
			local v328 = Vector3.new(v326, 0.1, v327)
			local v329 = {
				["material"] = nil,
				["transparency"] = 0.15,
				["material"] = v_u_15
			}
			local v_u_330 = v325(v328, CFrame.new(v_u_316), v_u_10, v329)
			local v_u_331 = {
				v_u_320,
				v_u_322,
				v_u_324,
				v_u_330
			}
			for _, v332 in v_u_331 do
				v_u_1:AddItem(v332, 2.1)
			end
			local v_u_333 = {}
			for v334 = 1, v_u_314 and 4 or 8 do
				local v335 = v_u_43
				local v336
				if v334 % 2 == 0 then
					v336 = v_u_10
				else
					v336 = v_u_8
				end
				local v337
				if v334 % 2 == 0 then
					v337 = v_u_14
				else
					v337 = v_u_15
				end
				v_u_333[v334] = v335(v336, v337, 0.9 * v_u_313, 3.6 * v_u_313, 2.1, v334 % 2 == 0 and 0.15 or 0)
			end
			local v_u_338
			if v_u_314 then
				v_u_338 = nil
			else
				v_u_338 = v_u_66(v_u_315 * 1.1, 2.1)
			end
			local v_u_339 = not v_u_338 and Vector3.new(1, 1, 1) or v_u_338.Size
			local v_u_340 = math.random() * 3.141592653589793
			local v_u_341 = os.clock()
			local v_u_342 = false
			p_u_107.runNow(function()
				-- upvalues: (copy) v_u_341, (ref) v_u_342, (copy) v_u_317, (copy) v_u_340, (copy) v_u_320, (copy) v_u_318, (copy) v_u_316, (copy) v_u_322, (copy) v_u_330, (copy) v_u_324, (copy) v_u_333, (ref) v_u_56, (copy) v_u_338, (copy) v_u_339
				local v343 = os.clock() - v_u_341
				if v_u_342 then
					return false
				end
				local v344 = v343 / 0.3
				local v345 = math.clamp(v344, 0, 1) - 1
				local v346 = v345 * 2.7 * v345 * v345 + 1 + v345 * 1.7 * v345
				local v347 = math.max(v346, 0.03)
				local v348 = v_u_317 * v347
				local v349 = CFrame.Angles(0, v_u_340 + v343 * 0.15, 0)
				local v350 = v_u_318
				local v351 = v_u_318
				v_u_320.Size = Vector3.new(v350, v348, v351)
				v_u_320.CFrame = CFrame.new(v_u_316 + Vector3.new(0, 1, 0) * v348 / 2) * v349
				v_u_322.Size = v_u_320.Size
				v_u_322.CFrame = v_u_320.CFrame * CFrame.Angles(0, 0.7853981633974483, 0)
				local v352 = v_u_330
				local v353 = v_u_318 * 0.3
				local v354 = v348 * 1.02
				local v355 = v_u_318 * 0.3
				v352.Size = Vector3.new(v353, v354, v355)
				v_u_330.CFrame = v_u_320.CFrame
				v_u_324.Size = Vector3.new(1, 1, 1) * v_u_318 * 0.75 * v347
				v_u_324.CFrame = CFrame.new(v_u_316 + Vector3.new(0, 1, 0) * (v348 + v_u_318 * 0.12)) * v349 * CFrame.Angles(0.7853981633974483, 0, 0.6154030942532006)
				for v356, v357 in v_u_333 do
					local v358 = v_u_340 + v356 * 3.141592653589793 * 2 / #v_u_333
					local v359 = math.cos(v358)
					local v360 = math.sin(v358)
					local v361 = Vector3.new(v359, 0, v360)
					local v362 = v356 % 2 * 0.1 + 0.55
					local v363 = (v343 - 0.05 - v356 % 3 * 0.03) / 0.25
					local v364 = math.clamp(v363, 0, 1) - 1
					local v365 = v364 * 2.7 * v364 * v364 + 1 + v364 * 1.7 * v364
					local v366 = math.max(v365, 0.03)
					v_u_56(v357, v_u_316 + v361 * v_u_318 * 0.55 - Vector3.new(0, 0.4, 0), Vector3.new(0, 1, 0) * math.cos(v362) + v361 * math.sin(v362), v361:Cross(Vector3.new(0, 1, 0)), (v_u_317 * 0.32 + v356 % 2 * v_u_317 * 0.1) * v366)
				end
				if v_u_338 then
					local v367 = v_u_338
					local v368 = v_u_339
					local v369 = (v343 - 0.08) / 0.3
					local v370 = math.clamp(v369, 0, 1) - 1
					local v371 = v370 * 2.7 * v370 * v370 + 1 + v370 * 1.7 * v370
					v367.Size = v368 * math.max(v371, 0.03)
					v_u_338.CFrame = CFrame.new(v_u_316 + Vector3.new(0, 1, 0) * v_u_338.Size.Y * 0.25) * v349
				end
				return v343 < 1.6
			end)
			local v_u_372 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_316), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_372, 2.6)
			local v373 = Instance.new("Attachment")
			v373.Parent = v_u_372
			local v374 = Instance.new("Attachment")
			v374.Position = Vector3.new(0, 90, 0)
			v374.Parent = v_u_372
			local v_u_375 = v_u_342
			local v_u_376 = {}
			for v377, v378 in {
				{
					["w"] = nil,
					["c"] = nil,
					["t"] = 0.35,
					["w"] = v_u_318 * 1.9,
					["c"] = v_u_8
				},
				{
					["w"] = nil,
					["c"] = nil,
					["t"] = 0.1,
					["w"] = v_u_318 * 0.7,
					["c"] = v_u_10
				}
			} do
				if v_u_314 and v377 == 1 then
					continue
				end
				local v379 = Instance.new("Beam")
				v379.Attachment0 = v373
				v379.Attachment1 = v374
				v379.Texture = v_u_7.Beam
				v379.TextureMode = Enum.TextureMode.Stretch
				v379.Color = ColorSequence.new(v378.c, v_u_10)
				v379.LightEmission = 0.8
				v379.LightInfluence = 0
				v379.FaceCamera = true
				v379.Segments = 1
				v379.Width0 = 0.1
				v379.Width1 = 0.1
				v379.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v378.t), NumberSequenceKeypoint.new(0.55, (v378.t + 1) / 2), NumberSequenceKeypoint.new(1, 1) })
				v379:SetAttribute("Width", v378.w)
				v379.Parent = v_u_372
				table.insert(v_u_376, v379)
			end
			p_u_107.animate(0.25, 0, function(p380)
				-- upvalues: (copy) v_u_376
				for _, v381 in v_u_376 do
					local v382 = v381:GetAttribute("Width")
					local v383 = math.clamp(p380, 0, 1)
					local v384 = v382 * (v383 * v383 * (3 - v383 * 2))
					v381.Width0 = v384
					v381.Width1 = v384 * 1.3
				end
			end)
			local v_u_385 = v_u_316 + Vector3.new(0, 1, 0) * (v_u_317 + v_u_315 * 0.3)
			local v386 = v_u_25
			local v387 = v_u_4.CurrentCamera
			local v388
			if v387 then
				local v389 = v387.CFrame.Position - v_u_385
				v388 = v389.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v389.Unit
			else
				v388 = Vector3.new(0, 0, 1)
			end
			local v390 = v_u_385 - v388 * 3
			local v_u_391 = v386(CFrame.lookAt(v390, v390 + v388) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_315 * 0.4, v_u_7.Glow, v_u_10, 0.35)
			local v392 = v_u_25
			local v393 = v_u_4.CurrentCamera
			local v394
			if v393 then
				local v395 = v393.CFrame.Position - v_u_385
				v394 = v395.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v395.Unit
			else
				v394 = Vector3.new(0, 0, 1)
			end
			local v396 = v_u_385 - v394 * 2.8
			local v_u_397 = v392(CFrame.lookAt(v396, v396 + v394) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_315 * 0.3, v_u_7.HakkaMist, v_u_8, 0.15)
			local v398 = v_u_25
			local v399 = v_u_4.CurrentCamera
			local v400
			if v399 then
				local v401 = v399.CFrame.Position - v_u_385
				v400 = v401.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v401.Unit
			else
				v400 = Vector3.new(0, 0, 1)
			end
			local v402 = v_u_385 - v400 * 2.6
			local v_u_403 = v398(CFrame.lookAt(v402, v402 + v400) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_315 * 0.3, v_u_7.HakkaFrost, v_u_10, 0.1)
			local v_u_404 = { v_u_391, v_u_397, v_u_403 }
			for _, v405 in v_u_404 do
				v_u_1:AddItem(v405, 2.6)
			end
			local v_u_406 = { v_u_315 * 2.1, v_u_315 * 1.4, v_u_315 * 1.15 }
			p_u_107.runNow(function()
				-- upvalues: (copy) v_u_341, (copy) v_u_404, (copy) v_u_406, (copy) v_u_385, (ref) v_u_4, (ref) v_u_29, (copy) v_u_391, (copy) v_u_397, (copy) v_u_403
				local v407 = os.clock() - v_u_341
				local v408 = v407 / 0.45
				local v409 = math.clamp(v408, 0, 1) - 1
				local v410 = v409 * 2.7 * v409 * v409 + 1 + v409 * 1.7 * v409
				local v411 = (v407 - 1.3) / 0.6
				local v412 = math.clamp(v411, 0, 1)
				local v413 = v412 * v412 * (3 - v412 * 2)
				for v414, v415 in v_u_404 do
					if not v415.Parent then
						return false
					end
					local v416 = v_u_406[v414] * (v410 + v413 * 0.35)
					local v417 = math.max(v416, 0.05)
					v415.Size = Vector3.new(v417, 0.05, v417)
					local v418 = v_u_385
					local v419 = 3 - v414 * 0.2
					local v420 = v_u_4.CurrentCamera
					local v421
					if v420 then
						local v422 = v420.CFrame.Position - v418
						v421 = v422.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v422.Unit
					else
						v421 = Vector3.new(0, 0, 1)
					end
					local v423 = v418 - v421 * (v419 or 0)
					v415.CFrame = CFrame.lookAt(v423, v423 + v421) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, v414 ~= 3 and 0 or v407 * 0.4, 0)
				end
				v_u_29(v_u_391, v413 * 0.65 + 0.35)
				v_u_29(v_u_397, v413 * 0.85 + 0.15)
				v_u_29(v_u_403, v413 * 0.9 + 0.1)
				if v413 < 1 then
					return true
				end
				for _, v424 in v_u_404 do
					v424:Destroy()
				end
				return false
			end)
			p_u_107.pop(v_u_316 + Vector3.new(0, 2, 0), v_u_10, 4 * v_u_313, v_u_315 * 1.3, 0.35)
			v_u_5.ring(v_u_316, v_u_10, v_u_315 * 1.3, 0.55, v_u_7.HakkaMist)
			v_u_5.ring(v_u_316, v_u_8, v_u_315 * 1.6, 0.8, v_u_7.HakkaFrost)
			p_u_107.burst("Shockwave", v_u_316 + Vector3.new(0, 0.3, 0), v_u_8, v_u_315 / 14)
			v_u_97(v_u_316 + Vector3.new(0, 1, 0), v_u_314 and 10 or 28, 5 * v_u_313, v_u_315 * 2.2, 1.8, true)
			v_u_74(v_u_316 + Vector3.new(0, 4, 0), v_u_314 and 8 or 26, 1 * v_u_313, 30 * v_u_313, 1.4)
			v_u_6.play("Explosion", {
				["at"] = v_u_316,
				["volume"] = p_u_311.mine and 1 or 0.5
			})
			if p_u_311.mine then
				v_u_5.shake(0.55, 0.45)
			end
			p_u_107.after(1.3, function()
				-- upvalues: (ref) v_u_375, (copy) v_u_331, (copy) v_u_314, (ref) p_u_107, (copy) v_u_316, (copy) v_u_317, (ref) v_u_10, (ref) v_u_8, (ref) v_u_12, (ref) v_u_13, (copy) v_u_338, (ref) v_u_148, (copy) v_u_333, (copy) v_u_313, (copy) v_u_376, (copy) v_u_372, (ref) v_u_5, (copy) v_u_315, (ref) v_u_7, (ref) v_u_74, (ref) v_u_6, (copy) p_u_311, (ref) v_u_106
				v_u_375 = true
				for v425, v426 in v_u_331 do
					if not v426.Parent then
						continue
					end
					if not v_u_314 and v425 <= 2 then
						for v427 = 1, 4 do
							local v428 = {
								v_u_10,
								v_u_8,
								v_u_12,
								v_u_13
							}
							p_u_107.chunks(v_u_316 + Vector3.new(0, 1, 0) * v_u_317 * v427 / 5, v428, 2, 20, 0.9, 1.1, true, 0.4)
						end
					end
					v426:Destroy()
				end
				if v_u_338 then
					v_u_338:Destroy()
				end
				v_u_148(v_u_333, 1.6 * v_u_313, v_u_314)
				p_u_107.animate(0.45, 0, function(p429)
					-- upvalues: (ref) v_u_376, (ref) v_u_372
					for _, v430 in v_u_376 do
						local v431 = v430:GetAttribute("Width") * (1 + p429)
						v430.Width0 = v431
						v430.Width1 = v431 * 1.3
						local v432 = NumberSequence.new
						local v433 = 0.2 + p429
						v430.Transparency = v432((math.clamp(v433, 0, 1)))
					end
					if p429 >= 1 then
						v_u_372:Destroy()
					end
				end)
				v_u_5.flash(v_u_316 + Vector3.new(0, 1, 0) * v_u_317 * 0.5, v_u_10, v_u_315 * 1.4, 0.35)
				v_u_5.ring(v_u_316, v_u_10, v_u_315 * 1.5, 1, v_u_7.HakkaFrost)
				for v434 = 1, v_u_314 and 1 or 3 do
					v_u_74(v_u_316 + Vector3.new(0, 1, 0) * v_u_317 * (v434 / 4), v_u_314 and 18 or 30, 1.3 * v_u_313, 26 * v_u_313, 2.8)
				end
				v_u_6.play("Crit", {
					["at"] = v_u_316,
					["volume"] = p_u_311.mine and 0.9 or 0.45
				})
				if p_u_311.mine then
					v_u_5.shake(0.3, 0.3)
					v_u_106(v_u_10, 0.25, 0, 0.03, 0.05, 0.4)
				end
			end)
		end,
		["hit"] = function(p435, p436, _) -- name: hit
			-- upvalues: (copy) p_u_107, (ref) v_u_8, (ref) v_u_10
			p_u_107.burst("Impact", p436, v_u_8, 0.8)
			if not p435.lite then
				p_u_107.glint(p436, v_u_10, 3, 0.15)
			end
		end
	}
	return v108
end