local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("3FF0F0")
local v_u_8 = Color3.fromRGB(205, 255, 255)
local v_u_9 = Color3.fromRGB(50, 160, 255)
local v_u_10 = Color3.fromHex("0A2A3A")
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Ball
local v_u_13 = Enum.PartType.Wedge
local function v_u_25(p14, p15, p16, p17, p18) -- name: picture
	-- upvalues: (copy) v_u_4
	local v19 = v_u_4.part
	local v20 = p15 * 2
	local v21 = p15 * 2
	local v22 = v19(Vector3.new(v20, 0.05, v21), p14, p17, {
		["transparency"] = 1
	})
	for _, v23 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p16
		v24.Color3 = p17
		v24.Transparency = p18
		v24.Parent = v22
	end
	return v22
end
local function v_u_29(p26, p27) -- name: setAlpha
	for _, v28 in p26:GetChildren() do
		if not v28:IsA("Decal") then
			continue
		end
		v28.Transparency = p27
	end
end
local function v_u_45(p30, p31) -- name: hexagram
	local v32 = p30 * 1.7320508075688772 / 2
	local v33 = {}
	local v34 = {}
	for _, v35 in { 0, 3.141592653589793 } do
		local v36 = CFrame.Angles(0, 0, v35)
		for _, v37 in { Vector3.new(1, 0, 0), Vector3.new(-1, -0, -0) } do
			local v38 = -p30 / 2
			local v39 = Vector3.new(0, v38, 0)
			local v40 = p30 * 1.5
			local v41 = v39 + v37 * (v32 / 2) + Vector3.new(0, 1, 0) * (v40 / 2)
			local v42 = Vector3.new(p31, v40, v32)
			local v43 = CFrame.fromMatrix(v41, v37:Cross(Vector3.new(0, 1, 0)), Vector3.new(0, 1, 0), -v37)
			table.insert(v33, v42)
			local v44 = v36 * v43
			table.insert(v34, v44)
		end
	end
	return v33, v34
end
return function(p_u_46)
	-- upvalues: (copy) v_u_25, (copy) v_u_1, (copy) v_u_29, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_7, (copy) v_u_45, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9, (copy) v_u_8, (copy) v_u_5, (copy) v_u_10
	local function v_u_63(p_u_47, p_u_48, p_u_49, p50, p51, p_u_52, p_u_53, p54) -- name: flare
		-- upvalues: (ref) v_u_25, (ref) v_u_1, (copy) p_u_46, (ref) v_u_29
		local v_u_55 = p54 or 0
		local v_u_56 = v_u_25(p_u_47, p_u_48, p50, p51, v_u_55)
		v_u_1:AddItem(v_u_56, p_u_52 + 0.1)
		p_u_46.animate(p_u_52, 0, function(p57)
			-- upvalues: (copy) v_u_56, (copy) p_u_48, (copy) p_u_49, (copy) p_u_47, (copy) p_u_52, (copy) p_u_53, (ref) v_u_29, (copy) v_u_55
			local v58 = 1 - (1 - p57) ^ 3
			local v59 = v_u_56
			local v60 = p_u_48 + (p_u_49 - p_u_48) * v58
			local v61 = v60 * 2
			local v62 = v60 * 2
			v59.Size = Vector3.new(v61, 0.05, v62)
			v_u_56.CFrame = p_u_47 * CFrame.Angles(0, p57 * p_u_52 * p_u_53, 0)
			v_u_29(v_u_56, v_u_55 + (1 - v_u_55) * p57 ^ 1.5)
			if p57 >= 1 then
				v_u_56:Destroy()
			end
		end)
	end
	local function v107(p_u_64, p65) -- name: shardShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_45, (ref) v_u_13, (ref) v_u_11, (ref) v_u_12, (copy) p_u_46, (ref) v_u_9, (ref) v_u_1, (ref) v_u_3, (ref) v_u_8, (copy) v_u_63, (ref) v_u_6
		local v_u_66 = p_u_64.size
		local v_u_67 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p65, v_u_7, {
			["transparency"] = 1
		})
		local v68, v_u_69 = v_u_45(1.05 * v_u_66, 0.32 * v_u_66)
		local v_u_70 = {}
		for _, v71 in v68 do
			local v72 = v_u_4.part
			local v73 = v_u_7
			local v74 = {
				["shape"] = nil,
				["transparency"] = 0.05,
				["shape"] = v_u_13
			}
			table.insert(v_u_70, v72(v71, p65, v73, v74))
		end
		local v75 = {
			["shape"] = v_u_12
		}
		local v_u_76 = v_u_4.part(Vector3.new(0.6, 0.6, 0.6) * v_u_66, p65, v_u_11, v75)
		local v77 = {
			["shape"] = nil,
			["transparency"] = 0.7,
			["shape"] = v_u_12
		}
		local v_u_78 = v_u_4.part(Vector3.new(1.8, 1.8, 1.8) * v_u_66, p65, v_u_7, v77)
		local v_u_79 = { v_u_76, v_u_78 }
		for _, v80 in v_u_70 do
			table.insert(v_u_79, v80)
		end
		p_u_46.streak(v_u_67, v_u_7, v_u_9, 1 * v_u_66, 0.14)
		if p_u_64.mine then
			p_u_46.light(v_u_67, v_u_7, 9 * v_u_66)
		end
		for _, v81 in v_u_79 do
			v_u_1:AddItem(v81, 3)
		end
		v_u_1:AddItem(v_u_67, 3)
		local v_u_82 = 0
		local v_u_83 = false
		return {
			["place"] = function(p84, p85) -- name: place
				-- upvalues: (copy) v_u_67, (ref) v_u_3, (copy) v_u_70, (copy) v_u_69, (copy) v_u_76, (copy) v_u_66, (copy) v_u_78, (copy) p_u_64, (ref) v_u_82, (ref) v_u_8, (ref) v_u_63, (ref) p_u_46, (ref) v_u_6
				local v86 = p84.Position
				v_u_67.CFrame = p84
				local v87 = v_u_3.CurrentCamera
				local v88
				if v87 then
					local v89 = v87.CFrame.Position - v86
					v88 = v89.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v89.Unit
				else
					v88 = Vector3.new(0, 0, 1)
				end
				local v90 = v88.Y
				local v91 = math.abs(v90) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v92 = CFrame.lookAt(v86, v86 + v88, v91) * CFrame.Angles(0, 0, -p85 * 16)
				for v93, v94 in v_u_70 do
					v94.CFrame = v92 * v_u_69[v93]
				end
				v_u_76.CFrame = v92 * CFrame.new(0, 0, 0.12 * v_u_66)
				local v95 = v_u_78
				local v96 = CFrame.new
				local v97 = v_u_3.CurrentCamera
				local v98
				if v97 then
					local v99 = v97.CFrame.Position - v86
					v98 = v99.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v99.Unit
				else
					v98 = Vector3.new(0, 0, 1)
				end
				v95.CFrame = v96(v86 - v98 * 1.1 * v_u_66)
				if not p_u_64.lite and p85 - v_u_82 > 0.06 then
					v_u_82 = p85
					local v100 = 0.55 * v_u_66
					local v101 = v_u_8
					local v102 = v_u_3.CurrentCamera
					local v103
					if v102 then
						local v104 = v102.CFrame.Position - v86
						v103 = v104.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v104.Unit
					else
						v103 = Vector3.new(0, 0, 1)
					end
					v_u_63(p_u_46.facing(v86 + v103 * 0.3, v103), v100, v100 * 1.4, v_u_6.AstralStar, v101, 0.28, 2)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_83, (copy) v_u_67, (ref) v_u_1, (copy) v_u_79
				if not v_u_83 then
					v_u_83 = true
					local v105 = v_u_67:FindFirstChildWhichIsA("PointLight")
					if v105 then
						v105:Destroy()
					end
					v_u_1:AddItem(v_u_67, 0.2)
					for _, v106 in v_u_79 do
						v106:Destroy()
					end
				end
			end
		}
	end
	local function v144(p108, p_u_109) -- name: shardImpact
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_13, (ref) v_u_1, (copy) p_u_46, (copy) v_u_63, (ref) v_u_6, (ref) v_u_8
		local v_u_110 = p108.size
		local v111 = v_u_3.CurrentCamera
		local v112
		if v111 then
			local v113 = v111.CFrame.Position - p_u_109
			v112 = v113.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v113.Unit
		else
			v112 = Vector3.new(0, 0, 1)
		end
		local v114 = v112.Y
		local v115 = math.abs(v114) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v116 = CFrame.lookAt(p_u_109, p_u_109 + v112, v115)
		local v117 = math.random() * 3.141592653589793 * 2
		for v118 = 0, p108.lite and 2 or 5 do
			local v119 = v117 + v118 * 3.141592653589793 / 3 * (p108.lite and 2 or 1)
			local v120 = math.cos(v119)
			local v121 = math.sin(v119)
			local v_u_122 = v116:VectorToWorldSpace((Vector3.new(v120, v121, 0)))
			local v123 = 0.35 * v_u_110
			local v124 = 0.9 * v_u_110
			local v125 = 0.22 * v_u_110
			local v126 = Vector3.new(0, 0, 0) + Vector3.new(1, 0, 0) * (v123 / 2) + Vector3.new(0, 1, 0) * (v124 / 2)
			local v127 = Vector3.new(v125, v124, v123)
			local v_u_128 = CFrame.fromMatrix(v126, (Vector3.new(1, 0, 0)):Cross(Vector3.new(0, 1, 0)), Vector3.new(0, 1, 0), Vector3.new(-1, -0, -0))
			local v129 = {
				["shape"] = v_u_13
			}
			local v_u_130 = v_u_4.part(v127, CFrame.new(p_u_109), v_u_7, v129)
			v_u_1:AddItem(v_u_130, 0.4)
			local v_u_131 = (math.random() - 0.5) * 30
			p_u_46.animate(0.3, 0, function(p132)
				-- upvalues: (copy) p_u_109, (copy) v_u_122, (copy) v_u_110, (copy) v_u_130, (copy) v_u_131, (copy) v_u_128
				local v133 = 1 - (1 - p132) ^ 2
				local v134 = p_u_109 + v_u_122 * 4.2 * v_u_110 * v133
				v_u_130.CFrame = CFrame.lookAt(v134, v134 + v_u_122) * CFrame.Angles(0, 0, p132 * v_u_131) * v_u_128
				v_u_130.Transparency = p132 ^ 2
				if p132 >= 1 then
					v_u_130:Destroy()
				end
			end)
		end
		local v135 = v_u_63
		local v136 = p_u_46.facing
		local v137 = v_u_3.CurrentCamera
		local v138
		if v137 then
			local v139 = v137.CFrame.Position - p_u_109
			v138 = v139.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v139.Unit
		else
			v138 = Vector3.new(0, 0, 1)
		end
		local v140 = p_u_109 + v138 * 0.6
		local v141 = v_u_3.CurrentCamera
		local v142
		if v141 then
			local v143 = v141.CFrame.Position - p_u_109
			v142 = v143.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v143.Unit
		else
			v142 = Vector3.new(0, 0, 1)
		end
		v135(v136(v140, v142), 1 * v_u_110, 3.2 * v_u_110, v_u_6.AstralSigil, v_u_7, 0.25, -6)
		p_u_46.pop(p_u_109, v_u_7, 1.1 * v_u_110, 4 * v_u_110, 0.2, 0.35)
		v_u_4.ring(p_u_46.ground(p_u_109), v_u_7, p108.ability.radius * v_u_110, 0.28, v_u_6.Ring)
		p_u_46.burst("Impact", p_u_109, v_u_7, 0.9 * v_u_110)
		p_u_46.glint(p_u_109, v_u_8, 3 * v_u_110, 0.14)
		p_u_46.hitSound(p_u_109)
	end
	local v_u_145 = {}
	setmetatable(v_u_145, {
		["__mode"] = "k"
	})
	local function v_u_172(p146, p147, p148) -- name: addStar
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_12, (ref) v_u_25, (ref) v_u_3, (ref) v_u_6, (ref) v_u_11, (ref) v_u_1, (copy) p_u_46
		local v149 = {
			["shape"] = v_u_12
		}
		local v_u_150 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(p147), v_u_8, v149)
		local v151 = v_u_25
		local v152 = v_u_3.CurrentCamera
		local v153
		if v152 then
			local v154 = v152.CFrame.Position - p147
			v153 = v154.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v154.Unit
		else
			v153 = Vector3.new(0, 0, 1)
		end
		local v155 = v153.Y
		local v156 = math.abs(v155) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v_u_157 = v151(CFrame.lookAt(p147, p147 + v153, v156) * CFrame.Angles(1.5707963267948966, 0, 0), 0.1, v_u_6.AstralStar, v_u_11, 0)
		v_u_1:AddItem(v_u_150, p148)
		v_u_1:AddItem(v_u_157, p148)
		p_u_46.animate(0.16, 0, function(p158)
			-- upvalues: (copy) v_u_150, (copy) v_u_157
			local v159 = p158 - 1
			local v160 = v159 * 2.7 * v159 * v159 + 1 + v159 * 1.7 * v159
			local v161 = v_u_150
			local v162 = v160 * 1.1
			v161.Size = Vector3.new(1, 1, 1) * math.max(v162, 0.05)
			local v163 = v_u_157
			local v164 = v160 * 3.4
			local v165 = math.max(v164, 0.05)
			local v166 = v165 * 2
			local v167 = v165 * 2
			v163.Size = Vector3.new(v166, 0.05, v167)
		end)
		local v168 = {
			["pos"] = p147,
			["node"] = v_u_150,
			["glint"] = v_u_157
		}
		local v169 = p146.stars
		table.insert(v169, v168)
		local v170 = p146.parts
		table.insert(v170, v_u_150)
		local v171 = p146.parts
		table.insert(v171, v_u_157)
		return v168
	end
	local function v_u_190(p173, p_u_174, p_u_175, p176, p177) -- name: addLine
		-- upvalues: (copy) p_u_46, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1
		local v178 = p173.lines
		table.insert(v178, {
			["a"] = p_u_174,
			["b"] = p_u_175
		})
		local v_u_179 = p_u_46.rod(p_u_174, p_u_174 + (p_u_175 - p_u_174) * 0.01, 0.4, v_u_8)
		local v_u_180 = p_u_46.rod(p_u_174, p_u_174 + (p_u_175 - p_u_174) * 0.01, 1.2, v_u_7, 0.65)
		v_u_1:AddItem(v_u_179, p177)
		v_u_1:AddItem(v_u_180, p177)
		local v181 = p173.parts
		table.insert(v181, v_u_179)
		local v182 = p173.parts
		table.insert(v182, v_u_180)
		local v_u_183 = (p_u_175 - p_u_174).Magnitude
		local v_u_184 = p_u_46.aimAt((p_u_174 + p_u_175) / 2, p_u_175 - p_u_174) * CFrame.Angles(0, 1.5707963267948966, 0)
		p_u_46.animate(p176, 0, function(p185)
			-- upvalues: (copy) v_u_183, (copy) p_u_174, (copy) p_u_175, (copy) v_u_184, (copy) v_u_179, (copy) v_u_180
			local v186 = v_u_183 * (1 - (1 - p185) ^ 2)
			local v187 = math.max(v186, 0.05)
			local v188 = p_u_174 + (p_u_175 - p_u_174).Unit * v187 / 2
			local v189 = v_u_184.Rotation + v188
			v_u_179.Size = Vector3.new(v187, 0.4, 0.4)
			v_u_179.CFrame = v189
			v_u_180.Size = Vector3.new(v187, 1.2, 1.2)
			v_u_180.CFrame = v189
		end)
	end
	local function v_u_199(p191, p192) -- name: detonate
		-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_29, (ref) v_u_1, (ref) v_u_5
		p192.blown = true
		local v_u_193 = p192.lite
		for _, v194 in p192.lines do
			p_u_46.alongPath(v194.a, v194.b, v_u_193 and 6 or 3.2, 0.22, function(p195)
				-- upvalues: (ref) p_u_46, (ref) v_u_7, (copy) v_u_193, (ref) v_u_11
				p_u_46.pop(p195, v_u_7, 0.8, 3.4, 0.22, 0.3)
				if not v_u_193 then
					p_u_46.pop(p195, v_u_11, 0.6, 1.4, 0.12)
				end
			end)
		end
		for _, v196 in p192.stars do
			v_u_4.flash(v196.pos, v_u_8, 5, 0.2)
			v_u_4.ring(p_u_46.ground(v196.pos), v_u_7, 4.5, 0.3, v_u_6.Ring)
			p_u_46.burst("Impact", v196.pos, v_u_7, 1)
		end
		for _, v197 in p192.parts do
			if not v197.Parent then
				continue
			end
			v197.Color = v_u_11
			v_u_4.tween(v197, 0.3, {
				["Transparency"] = 1
			})
			v_u_29(v197, 0.3)
			for _, v198 in v197:GetChildren() do
				if not v198:IsA("Decal") then
					continue
				end
				v_u_4.tween(v198, 0.3, {
					["Transparency"] = 1
				})
			end
			v_u_1:AddItem(v197, 0.35)
		end
		v_u_5.play("Explosion", {
			["at"] = p192.center,
			["volume"] = p191.mine and 0.6 or 0.35
		})
		if p191.mine then
			v_u_4.shake(0.25, 0.25)
		end
	end
	local v_u_200 = {}
	for _, v201 in { Vector3.new(1, 0, 0), Vector3.new(0, 1, 0), Vector3.new(0, 0, 1) } do
		local v202 = v201 == Vector3.new(1, 0, 0) and Vector3.new(0, 1, 0) or Vector3.new(1, 0, 0)
		local v203 = v201:Cross(v202)
		for _, v204 in { -0.5, 0.5 } do
			for _, v205 in { -0.5, 0.5 } do
				local v206 = v202 * v204 + v203 * v205
				local v207 = v206 - v201 * 0.5
				table.insert(v_u_200, v207)
				local v208 = v206 + v201 * 0.5
				table.insert(v_u_200, v208)
			end
		end
	end
	return {
		["astral_sigil_a"] = {
			["cast"] = function(p209) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_46, (ref) v_u_11, (ref) v_u_8, (ref) v_u_3, (copy) v_u_63, (ref) v_u_6
				local v210 = p209.size
				local v211 = p209.eye + p209.dir * 1.2
				v_u_4.flash(v211, v_u_7, 3 * v210, 0.1)
				p_u_46.pop(v211, v_u_11, 1.1 * v210, 0.3 * v210, 0.1)
				if not p209.lite then
					local v212 = 0.9 * v210
					local v213 = v_u_8
					local v214 = v_u_3.CurrentCamera
					local v215
					if v214 then
						local v216 = v214.CFrame.Position - v211
						v215 = v216.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v216.Unit
					else
						v215 = Vector3.new(0, 0, 1)
					end
					v_u_63(p_u_46.facing(v211 + v215 * 0.3, v215), v212, v212 * 1.4, v_u_6.AstralStar, v213, 0.14, 2)
				end
			end,
			["shot"] = v107,
			["impact"] = v144,
			["hit"] = function(_, p217, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7
				p_u_46.burst("Impact", p217, v_u_7, 0.6)
			end
		},
		["astral_sigil_e"] = {
			["cast"] = function(p218) -- name: cast
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (copy) v_u_63, (ref) v_u_6
				p_u_46.skillCast(p218, v_u_7)
				local v219 = p218.size
				local v220 = p218.eye + p218.dir * 1.6
				v_u_63(p_u_46.facing(v220, p218.dir), 0.8 * v219, 3 * v219, v_u_6.AstralSigil, v_u_7, 0.32, 8)
			end,
			["windup"] = function(p221, p222, p223) -- name: windup
				-- upvalues: (copy) p_u_46, (ref) v_u_7
				p_u_46.inward(p_u_46.ground(p222, 2.5), v_u_7, p221.lite and 3 or 7, 14, (math.max(p223, 0.1)))
			end,
			["land"] = function(p_u_224, p225) -- name: land
				-- upvalues: (copy) p_u_46, (copy) v_u_145, (ref) v_u_25, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (ref) v_u_29, (ref) v_u_4, (ref) v_u_8, (copy) v_u_172, (copy) v_u_190, (ref) v_u_3, (copy) v_u_199
				local v226 = p_u_224.size
				local v227 = p_u_224.lite
				local v228 = p_u_224.ability.radius * v226
				local v229 = p_u_46.ground(p225, 0)
				local v230 = p_u_224.ability.freeze or 2.5
				local v_u_231 = v230 + 1
				local v_u_232 = {
					["stars"] = nil,
					["lines"] = nil,
					["parts"] = nil,
					["holds"] = nil,
					["center"] = nil,
					["born"] = nil,
					["blown"] = false,
					["lite"] = nil,
					["stars"] = {},
					["lines"] = {},
					["parts"] = {},
					["holds"] = {},
					["center"] = v229,
					["born"] = os.clock(),
					["lite"] = v227
				}
				v_u_145[p_u_224] = v_u_232
				for _, v_u_233 in { v228, v228 * 0.55 } do
					local v_u_234 = v_u_25(CFrame.new(v229 + Vector3.new(0, 0.15, 0)), 1, v_u_6.Ring, v_u_7, 0.3)
					v_u_1:AddItem(v_u_234, v_u_231)
					p_u_46.animate(v_u_231 - 0.3, 0, function(p235)
						-- upvalues: (copy) v_u_231, (copy) v_u_234, (copy) v_u_233, (ref) v_u_29
						local v236 = p235 * (v_u_231 - 0.3) / 0.25
						local v237 = math.min(v236, 1) - 1
						local v238 = v_u_234
						local v239 = v_u_233 * (v237 * 2.7 * v237 * v237 + 1 + v237 * 1.7 * v237)
						local v240 = math.max(v239, 0.1)
						local v241 = v240 * 2
						local v242 = v240 * 2
						v238.Size = Vector3.new(v241, 0.05, v242)
						if p235 > 0.8 then
							v_u_29(v_u_234, 0.3 + 0.7 * (p235 - 0.8) / 0.2)
						end
						if p235 >= 1 then
							v_u_234:Destroy()
						end
					end)
				end
				v_u_4.flash(v229 + Vector3.new(0, 2, 0), v_u_8, 7, 0.18)
				local v243 = v227 and 4 or 7
				local v244 = math.random() * 3.141592653589793 * 2
				local v245 = {}
				for v246 = 1, v243 do
					local v247 = v244 + (v246 - 1) / v243 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.5
					local v248 = v228 * (0.35 + math.random() * 0.5)
					local v249 = math.cos(v247) * v248
					local v250 = 3 + math.random() * 3
					local v251 = math.sin(v247) * v248
					local v252 = {
						["a"] = v247,
						["p"] = v229 + Vector3.new(v249, v250, v251)
					}
					table.insert(v245, v252)
				end
				for v253, v_u_254 in v245 do
					p_u_46.after(v253 * 0.04, function()
						-- upvalues: (ref) v_u_172, (copy) v_u_232, (copy) v_u_254, (copy) v_u_231
						v_u_172(v_u_232, v_u_254.p, v_u_231)
					end)
					local v_u_255 = v245[v253 % #v245 + 1]
					p_u_46.after(v253 * 0.05 + 0.1, function()
						-- upvalues: (ref) v_u_190, (copy) v_u_232, (copy) v_u_254, (copy) v_u_255, (copy) v_u_231
						v_u_190(v_u_232, v_u_254.p, v_u_255.p, 0.14, v_u_231)
					end)
				end
				p_u_46.runNow(function()
					-- upvalues: (copy) v_u_232, (ref) v_u_3, (copy) v_u_231
					for _, v256 in v_u_232.stars do
						if not v256.glint.Parent then
							continue
						end
						local v257 = v256.glint
						local v258 = v256.pos
						local v259 = v_u_3.CurrentCamera
						local v260
						if v259 then
							local v261 = v259.CFrame.Position - v258
							v260 = v261.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v261.Unit
						else
							v260 = Vector3.new(0, 0, 1)
						end
						local v262 = v260.Y
						local v263 = math.abs(v262) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
						v257.CFrame = CFrame.lookAt(v258, v258 + v260, v263) * CFrame.Angles(1.5707963267948966, 0, 0)
					end
					for v264, v265 in v_u_232.holds do
						if not v265.Parent then
							continue
						end
						local v266 = v265.Position
						local v267 = v_u_3.CurrentCamera
						local v268
						if v267 then
							local v269 = v267.CFrame.Position - v266
							v268 = v269.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v269.Unit
						else
							v268 = Vector3.new(0, 0, 1)
						end
						local v270 = v268.Y
						local v271 = math.abs(v270) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
						v265.CFrame = CFrame.lookAt(v266, v266 + v268, v271) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, (os.clock() - v_u_232.born) * (v264 % 2 + 2), 0)
					end
					return os.clock() - v_u_232.born < v_u_231
				end)
				p_u_46.after(0.62, function()
					-- upvalues: (ref) v_u_199, (copy) p_u_224, (copy) v_u_232
					v_u_199(p_u_224, v_u_232)
				end)
				p_u_46.after(v230, function()
					-- upvalues: (copy) v_u_232, (ref) v_u_4, (ref) v_u_1, (ref) v_u_145, (copy) p_u_224
					for _, v272 in v_u_232.holds do
						if not v272.Parent then
							continue
						end
						for _, v273 in v272:GetChildren() do
							if not v273:IsA("Decal") then
								continue
							end
							v_u_4.tween(v273, 0.25, {
								["Transparency"] = 1
							})
						end
						v_u_1:AddItem(v272, 0.3)
					end
					v_u_145[p_u_224] = nil
				end)
			end,
			["hit"] = function(p274, p275, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (copy) v_u_145, (ref) v_u_25, (ref) v_u_3, (ref) v_u_6, (ref) v_u_1, (copy) v_u_172, (copy) v_u_190
				p_u_46.burst("Impact", p275, v_u_7, 0.7)
				local v276 = v_u_145[p274]
				if v276 then
					local v277 = (p274.ability.freeze or 2.5) + 0.5
					local v278 = v_u_25
					local v279 = p275 + Vector3.new(0, 3.2, 0)
					local v280 = v_u_3.CurrentCamera
					local v281
					if v280 then
						local v282 = v280.CFrame.Position - v279
						v281 = v282.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v282.Unit
					else
						v281 = Vector3.new(0, 0, 1)
					end
					local v283 = v281.Y
					local v284 = math.abs(v283) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
					local v285 = v278(CFrame.lookAt(v279, v279 + v281, v284), 1.3, v_u_6.AstralSigil, v_u_7, 0.05)
					v285.CFrame = CFrame.new(p275 + Vector3.new(0, 3.2, 0))
					v_u_1:AddItem(v285, v277)
					local v286 = v276.holds
					table.insert(v286, v285)
					if not v276.blown then
						local v287 = p275 + Vector3.new(0, 2.2, 0)
						local v288 = (1 / 0)
						local v289 = nil
						for _, v290 in v276.stars do
							local v291 = (v290.pos - v287).Magnitude
							if v291 >= v288 then
								continue
							end
							v289 = v290.pos
							v288 = v291
						end
						v_u_172(v276, v287, v277)
						if v289 then
							v_u_190(v276, v289, v287, 0.1, v277)
						end
					end
				else
					return
				end
			end
		},
		["astral_sigil_r"] = {
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["land"] = nil,
			["hit"] = nil,
			["cast"] = function(p292) -- name: cast
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (copy) v_u_63, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4
				p_u_46.skillCast(p292, v_u_7, true)
				local v293 = p292.size
				local v294 = p292.eye + p292.dir * 1.6
				local v295 = p_u_46.facing(v294, p292.dir)
				v_u_63(v295, 1 * v293, 4.4 * v293, v_u_6.AstralSigil, v_u_7, 0.36, -7)
				v_u_63(v295 * CFrame.new(0, -0.05, 0), 1.6 * v293, 5.4 * v293, v_u_6.Glow, v_u_9, 0.3, 0, 0.3)
				if p292.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p296, p297, p298) -- name: windup
				-- upvalues: (copy) p_u_46, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7
				local v299 = p296.ability.radius * p296.size
				local v300 = p_u_46.ground(p297, 0)
				local v301 = p296.dir.X
				local v302 = p296.dir.Z
				local v303 = Vector3.new(v301, 0, v302)
				local v304 = v303.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v303.Unit
				local v305 = v304:Cross(Vector3.new(0, 1, 0))
				local v_u_306 = math.max(p298, 0.1)
				local v_u_307 = v_u_306 + 0.62 + 0.3
				for _, v308 in { v304, v305 } do
					local v309
					if v308 == v304 then
						v309 = v305
					else
						v309 = v304
					end
					for v310 = -2, 2 do
						local v311 = v310 * 8
						local v312 = v299 * v299 - v311 * v311
						local v313 = math.max(v312, 1)
						local v_u_314 = math.sqrt(v313) * 2
						local v315 = v300 + v309 * v311 + Vector3.new(0, 0.12, 0)
						local v_u_316 = v_u_4.part(Vector3.new(0.3, 0.1, 0.1), CFrame.lookAt(v315, v315 + v308), v_u_8, {
							["transparency"] = 0.15
						})
						v_u_1:AddItem(v_u_316, v_u_307 + 0.1)
						p_u_46.animate(v_u_307, 0, function(p317)
							-- upvalues: (copy) v_u_307, (copy) v_u_306, (copy) v_u_316, (copy) v_u_314
							local v318 = p317 * v_u_307 / v_u_306
							local v319 = math.min(v318, 1)
							local v320 = v_u_316
							local v321 = v_u_314 * (1 - (1 - v319) ^ 2)
							local v322 = math.max(v321, 0.1)
							v320.Size = Vector3.new(0.3, 0.1, v322)
							if p317 * v_u_307 > v_u_306 + 0.62 then
								v_u_316.Transparency = 0.15 + 0.85 * (p317 * v_u_307 - v_u_306 - 0.62) / 0.3
							end
							if p317 >= 1 then
								v_u_316:Destroy()
							end
						end)
					end
				end
				p_u_46.inward(v300 + Vector3.new(0, 4, 0), v_u_7, p296.lite and 3 or 8, v299, v_u_306)
			end,
			["land"] = function(p_u_323, p324) -- name: land
				-- upvalues: (copy) p_u_46, (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (copy) v_u_200, (ref) v_u_1, (ref) v_u_9, (ref) v_u_6, (ref) v_u_5, (copy) v_u_63, (ref) v_u_3, (ref) v_u_10
				local v325 = p_u_323.size
				local v_u_326 = p_u_323.lite
				local v_u_327 = p_u_323.ability.radius * v325
				local v_u_328 = p_u_46.ground(p324, 0)
				local v329 = p_u_323.dir.X
				local v330 = p_u_323.dir.Z
				local v331 = Vector3.new(v329, 0, v330)
				local v332 = (v331.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v331.Unit):Cross(Vector3.new(0, 1, 0))
				local v333 = CFrame.fromMatrix(v_u_328, v332, Vector3.new(0, 1, 0))
				local v_u_334 = {}
				for v335 = 0, 1 do
					for v336 = -2, 2 do
						for v337 = -2, 2 do
							local v338 = v336 * 8
							local v339 = v337 * 8
							local v340 = Vector3.new(v338, 0, v339)
							local v341 = v340.Magnitude
							local v342
							if v335 == 0 then
								if v_u_326 then
									v342 = math.abs(v336) + math.abs(v337) <= 2
								else
									v342 = v341 <= v_u_327 - 2
								end
							else
								v342 = not v_u_326
								if v342 then
									if math.abs(v336) <= 1 then
										v342 = math.abs(v337) <= 1
									else
										v342 = false
									end
								end
							end
							if not v342 then
								continue
							end
							local v343 = v335 * 7.2 + 3.7
							local v344 = v333:PointToWorldSpace(v340 + Vector3.new(0, v343, 0))
							local v345 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v333.Rotation + v344, v_u_7, {
								["transparency"] = 0.72
							})
							local v346 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v333.Rotation + v344, v_u_8, {
								["transparency"] = 0.15
							})
							local v347 = Instance.new("WireframeHandleAdornment")
							v347.Adornee = v345
							v347.Color3 = v_u_11
							v347.Thickness = 5
							v347.AlwaysOnTop = false
							for v348 = 1, #v_u_200, 2 do
								v347:AddLine(v_u_200[v348], v_u_200[v348 + 1])
							end
							v347.Scale = Vector3.new(0.05, 0.05, 0.05)
							v347.Parent = v345
							v_u_1:AddItem(v345, 1.62)
							v_u_1:AddItem(v346, 1.62)
							local v349 = {
								["shell"] = nil,
								["heart"] = nil,
								["wire"] = nil,
								["at"] = nil,
								["delay"] = nil,
								["size"] = 7.2,
								["shell"] = v345,
								["heart"] = v346,
								["wire"] = v347,
								["at"] = v344,
								["delay"] = v341 / v_u_327 * 0.16 + v335 * 0.06
							}
							table.insert(v_u_334, v349)
						end
					end
				end
				local v350 = v_u_4.part
				local v351 = v_u_327 * 2.1
				local v352 = v_u_327 * 2.1
				local v_u_353 = v350(Vector3.new(0.2, v351, v352), CFrame.new(v_u_328) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_8, {
					["shape"] = nil,
					["transparency"] = 1,
					["shape"] = Enum.PartType.Cylinder
				})
				v_u_1:AddItem(v_u_353, 1.12)
				local v_u_354 = os.clock()
				local v_u_355 = false
				p_u_46.runNow(function()
					-- upvalues: (copy) v_u_354, (ref) v_u_355, (copy) v_u_334, (copy) v_u_326, (ref) p_u_46, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_353, (copy) v_u_328
					local v356 = os.clock() - v_u_354
					if v356 >= 0.62 then
						if not v_u_355 then
							v_u_355 = true
							for _, v357 in v_u_334 do
								if not v_u_326 then
									local v358 = { v_u_7, v_u_8, v_u_9 }
									p_u_46.chunks(v357.at, v358, 2, 42, 1.3, 1.1, true, 0.8)
								end
								v357.shell:Destroy()
								v357.heart:Destroy()
							end
							v_u_353:Destroy()
						end
						return false
					end
					for _, v359 in v_u_334 do
						local v360 = (v356 - v359.delay) / 0.12
						local v361 = math.clamp(v360, 0, 1)
						local v362 = v359.size
						local v363 = v361 - 1
						local v364 = v362 * (v363 * 2.7 * v363 * v363 + 1 + v363 * 1.7 * v363)
						local v365 = math.max(v364, 0.05)
						local v366 = v356 * 30 + v359.at.X
						local v367 = math.sin(v366) * 0.06
						v359.shell.Size = Vector3.new(1, 1, 1) * v365
						v359.wire.Scale = Vector3.new(1, 1, 1) * v365
						v359.heart.Size = Vector3.new(1, 1, 1) * v365 * 0.3
						v359.heart.CFrame = CFrame.new(v359.at) * CFrame.Angles(0.7853981633974483, v356 * 3 + v359.at.Z, 0.7853981633974483)
						v359.shell.Transparency = v367 + 0.72
					end
					local v368 = (v356 - 0.18) / 0.4
					local v369 = math.clamp(v368, 0, 1)
					v_u_353.CFrame = CFrame.new(v_u_328 + Vector3.new(0, 1, 0) * (v369 * 7.2 * 2.2 + 0.2)) * CFrame.Angles(0, 0, 1.5707963267948966)
					v_u_353.Transparency = v369 > 0 and v369 < 1 and 0.55 or 1
					return true
				end)
				v_u_4.flash(v_u_328 + Vector3.new(0, 4, 0), v_u_8, v_u_327 * 0.9, 0.2)
				v_u_4.ring(v_u_328, v_u_7, v_u_327, 0.3, v_u_6.Ring)
				v_u_5.play("Lightning", {
					["at"] = v_u_328,
					["volume"] = p_u_323.mine and 0.7 or 0.4
				})
				if p_u_323.mine then
					v_u_4.shake(0.3, 0.25)
				end
				p_u_46.after(0.62, function()
					-- upvalues: (copy) v_u_328, (ref) v_u_4, (ref) v_u_11, (copy) v_u_327, (ref) v_u_63, (ref) p_u_46, (ref) v_u_3, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (copy) v_u_326, (ref) v_u_9, (ref) v_u_5, (copy) p_u_323
					local v370 = v_u_328 + Vector3.new(0, 7.2, 0)
					v_u_4.flash(v370, v_u_11, v_u_327 * 1.3, 0.25)
					local v371 = v_u_63
					local v372 = p_u_46.facing
					local v373 = v370 + Vector3.new(0, 4, 0)
					local v374 = v370 + Vector3.new(0, 4, 0)
					local v375 = v_u_3.CurrentCamera
					local v376
					if v375 then
						local v377 = v375.CFrame.Position - v374
						v376 = v377.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v377.Unit
					else
						v376 = Vector3.new(0, 0, 1)
					end
					v371(v372(v373, v376), 3, v_u_327 * 0.85, v_u_6.AstralSigil, v_u_7, 0.55, -1.5)
					p_u_46.pop(v370, v_u_7, 6, v_u_327 * 2, 0.4, 0.4)
					v_u_4.ring(v_u_328, v_u_8, v_u_327 * 1.35, 0.5, v_u_6.Shockwave)
					v_u_4.ring(v_u_328, v_u_7, v_u_327 * 1.7, 0.6, v_u_6.Ring)
					p_u_46.burst("Shockwave", v_u_328 + Vector3.new(0, 0.3, 0), v_u_7, v_u_327 / 14)
					p_u_46.spikes(v370, v_u_8, v_u_326 and 6 or 14, v_u_327 * 1.1, 0.3)
					if v_u_326 then
						local v378 = { v_u_7, v_u_8, v_u_9 }
						p_u_46.chunks(v370, v378, 8, 42, 1.3, 1.1, true, 0.8)
					else
						for _ = 1, 8 do
							local v379 = math.random() * 3.141592653589793 * 2
							local v380 = v_u_327 * math.random()
							local v381 = v_u_328
							local v382 = math.cos(v379) * v380
							local v383 = 2 + math.random() * 8
							local v384 = math.sin(v379) * v380
							local v385 = v381 + Vector3.new(v382, v383, v384)
							local v386 = v_u_8
							local v387 = v_u_3.CurrentCamera
							local v388
							if v387 then
								local v389 = v387.CFrame.Position - v385
								v388 = v389.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v389.Unit
							else
								v388 = Vector3.new(0, 0, 1)
							end
							v_u_63(p_u_46.facing(v385 + v388 * 0.3, v388), 1.4, 1.9599999999999997, v_u_6.AstralStar, v386, 0.35, 2)
						end
					end
					v_u_5.play("Explosion", {
						["at"] = v_u_328,
						["volume"] = p_u_323.mine and 1 or 0.6
					})
					if p_u_323.mine then
						v_u_4.shake(0.55, 0.45)
					end
				end)
				if not v_u_326 then
					p_u_46.mark(v_u_328, v_u_10, v_u_327 * 0.8, 1.42, v_u_6.Glow, 0.4)
				end
			end,
			["hit"] = function(p390, p391, _) -- name: hit
				-- upvalues: (copy) p_u_46, (ref) v_u_7, (ref) v_u_8
				p_u_46.burst("Impact", p391, v_u_7, 1)
				if not p390.lite then
					p_u_46.glint(p391, v_u_8, 3.2, 0.14)
				end
			end
		}
	}
end