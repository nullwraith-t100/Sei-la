require(script.Parent.Parent.Config.TrainingPops)
local v_u_57 = {
	["between"] = function(p1, p2) -- name: between
		local v3 = p1[1]
		return v3 + ((p1[2] or p1[1]) - v3) * math.clamp(p2, 0, 1)
	end,
	["newClock"] = function(p4, p5) -- name: newClock
		-- upvalues: (copy) v_u_57
		return {
			["wait"] = nil,
			["sinceGold"] = 0,
			["lastId"] = 0,
			["wait"] = v_u_57.between(p4.first, p5)
		}
	end,
	["tick"] = function(p6, p7, p8, p9, p10) -- name: tick
		-- upvalues: (copy) v_u_57
		p7.sinceGold = p7.sinceGold + p8
		if not p9 then
			return false
		end
		p7.wait = p7.wait - p8
		if p7.wait > 0 then
			return false
		end
		p7.wait = v_u_57.between(p6.gap, p10)
		return true
	end,
	["pickFree"] = function(p11, p12) -- name: pickFree
		local v13 = 0
		for _, v14 in p11.free do
			v13 = v13 + v14.weight
		end
		local v15 = math.clamp(p12, 0, 1) * v13
		for _, v16 in p11.free do
			v15 = v15 - v16.weight
			if v15 >= 0 then
				continue
			end
			return v16
		end
		return p11.free[#p11.free]
	end,
	["goldAllowed"] = function(p17, p18, p19) -- name: goldAllowed
		local v20 = p19.ready and not p19.running
		if v20 then
			if p19.playTime >= p17.goldAfter then
				v20 = p18.sinceGold >= p17.goldEvery
			else
				v20 = false
			end
		end
		return v20
	end,
	["make"] = function(p21, p22, p23, p24, p25, p26, p27, p28) -- name: make
		-- upvalues: (copy) v_u_57
		p22.lastId = p22.lastId + 1
		if p24 and p27 < p21.goldChance then
			p22.sinceGold = 0
			return {
				["id"] = nil,
				["kind"] = "gold",
				["mult"] = nil,
				["seconds"] = nil,
				["expires"] = nil,
				["id"] = p22.lastId,
				["mult"] = p25,
				["seconds"] = p26,
				["expires"] = p23 + p21.goldLife
			}
		else
			local v29 = v_u_57.pickFree(p21, p28)
			return {
				["id"] = nil,
				["kind"] = "free",
				["mult"] = nil,
				["seconds"] = 0,
				["expires"] = nil,
				["id"] = p22.lastId,
				["mult"] = v29.mult,
				["expires"] = p23 + p21.life
			}
		end
	end,
	["claimable"] = function(p30, p31, p32, p33) -- name: claimable
		local v34
		if p31 == nil or (p31.kind ~= "free" or (type(p32) ~= "number" or p32 ~= p31.id)) then
			v34 = false
		else
			v34 = p33 <= p31.expires + p30.grace
		end
		return v34
	end,
	["pays"] = function(p35, p36) -- name: pays
		return (p36 ~= p36 or (p36 <= 0 or p36 == (1 / 0))) and 0 or math.max(p35, 0) * p36
	end,
	["simulate"] = function(p37, p38, p39, p40, p41) -- name: simulate
		-- upvalues: (copy) v_u_57
		local v42 = v_u_57.newClock(p37, p41())
		local v43 = 0
		for _, v44 in p37.free do
			local v45 = v44.mult
			v43 = math.max(v43, v45)
		end
		local v46 = 0
		local v47 = 0
		local v48 = 0
		local v49 = 0
		local v50 = 0
		while true do
			local v51 = v42.wait
			local v52 = v46 + v51
			v42.sinceGold = v42.sinceGold + v51
			if p38 <= v52 then
				break
			end
			v42.wait = v_u_57.between(p37.gap, p41())
			local v53 = v_u_57.goldAllowed(p37, v42, {
				["ready"] = nil,
				["playTime"] = (1 / 0),
				["running"] = false,
				["ready"] = p40
			})
			local v54 = v_u_57.make(p37, v42, v52, v53, 50, 60, p41(), p41())
			local v55
			if v54.kind == "gold" then
				v55 = p37.goldLife
			else
				local v56 = p37.life
				v55 = math.min(p39, v56)
			end
			if v54.kind == "gold" then
				v49 = v49 + 1
			else
				v48 = v48 + 1
				v47 = v47 + v_u_57.pays(v54.mult, 1)
				if v54.mult == v43 then
					v50 = v50 + 1
				end
			end
			v46 = v52 + v55
			v42.sinceGold = v42.sinceGold + v55
		end
		return {
			["clicks"] = v47 / p38,
			["free"] = v48,
			["gold"] = v49,
			["top"] = v50
		}
	end
}
return v_u_57