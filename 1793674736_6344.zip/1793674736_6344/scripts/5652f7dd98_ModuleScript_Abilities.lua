local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v5 = game:GetService("RunService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.Bars)
local v_u_8 = require(script.Parent.Kit)
require(script.Parent.LookTypes)
local v9 = require(script.Parent.Parent.Events)
local v_u_10 = require(script.Parent.Parent.Sfx)
local v_u_11 = require(script.Parent.Parent.Perf)
local v_u_12 = require(v_u_4.Shared.Config.Abilities)
local v13 = require(v_u_4.Shared.Config.Eyes)
local v_u_14 = require(v_u_4.Shared.Config.Images)
local v_u_15 = require(v_u_4.Shared.Config.Textures)
local v16 = require(v_u_4.Shared.Config.World)
local v_u_17 = v_u_3.LocalPlayer
local v_u_18 = v16.FLOOR_Y
local v_u_19 = {}
local v_u_20 = 0
local v_u_21 = 0
local v22 = {}
for _, v23 in v13.byId do
	v_u_19[v23.attack] = true
end
local function v_u_24(_)
	return nil
end
function v22.setEnemyLocator(p25) -- name: setEnemyLocator
	-- upvalues: (ref) v_u_24
	v_u_24 = p25
end
local v_u_26 = {}
function v22.onCast(p27) -- name: onCast
	-- upvalues: (copy) v_u_26
	local v28 = v_u_26
	table.insert(v28, p27)
end
local function v32(p29, p30, p31) -- name: rgb
	return Color3.fromRGB(p29, p30, p31)
end
local v_u_33 = Color3.fromRGB(255, 255, 255)
local v_u_34 = Color3.fromRGB(12, 8, 16)
local v_u_35 = Color3.fromRGB(30, 20, 16)
local v_u_36 = {
	Color3.fromRGB(124, 112, 100),
	Color3.fromRGB(96, 88, 82),
	Color3.fromRGB(110, 168, 72),
	v32(140, 128, 112)
}
local v_u_37 = Color3.fromRGB(255, 215, 90)
local v_u_38 = Color3.fromRGB(255, 95, 15)
local v_u_39 = Color3.fromRGB(225, 35, 10)
local v_u_40 = Color3.fromRGB(229, 20, 30)
local v_u_41 = Color3.fromRGB(211, 18, 28)
local v_u_42 = Color3.fromRGB(110, 0, 18)
local v_u_43 = Color3.fromRGB(255, 46, 99)
local v_u_44 = Color3.fromRGB(255, 200, 218)
local v_u_45 = Color3.fromRGB(120, 60, 255)
local v_u_46 = Color3.fromRGB(196, 170, 255)
local v_u_47 = Color3.fromRGB(211, 18, 28)
local v_u_48 = Color3.fromRGB(150, 110, 255)
local v_u_49 = Color3.fromRGB(30, 26, 40)
local v_u_50 = Color3.fromRGB(50, 150, 255)
local v_u_51 = Color3.fromRGB(225, 244, 255)
local v_u_52 = Color3.fromRGB(90, 215, 255)
local v_u_53 = Color3.fromRGB(228, 250, 255)
local v_u_54 = Color3.fromRGB(255, 43, 58)
local v_u_55 = Color3.fromRGB(70, 14, 96)
local v_u_56 = Color3.fromRGB(255, 180, 30)
local v_u_57 = Color3.fromRGB(255, 236, 160)
local v_u_58 = Color3.fromRGB(235, 110, 255)
local v_u_59 = Color3.fromRGB(255, 236, 255)
local v_u_60 = Color3.fromRGB(30, 165, 255)
local v_u_61 = Color3.fromRGB(30, 80, 235)
local v_u_62 = Color3.fromRGB(255, 38, 52)
local v_u_63 = Color3.fromRGB(150, 45, 255)
local v_u_64 = Color3.fromRGB(236, 214, 255)
local v_u_65 = Color3.fromRGB(255, 195, 55)
local v_u_66 = Color3.fromRGB(255, 244, 200)
local v_u_67 = {}
v5.RenderStepped:Connect(function()
	-- upvalues: (ref) v_u_67
	if #v_u_67 ~= 0 then
		local v68 = v_u_67
		v_u_67 = {}
		for _, v69 in v68 do
			local v70, v71 = pcall(v69)
			if v70 and v71 then
				local v72 = v_u_67
				table.insert(v72, v69)
			else
				if v70 then
					continue
				end
				warn("[Fx] animation error: " .. tostring(v71))
			end
		end
	end
end)
local function v75(p73) -- name: frame
	-- upvalues: (ref) v_u_67
	local v74 = v_u_67
	table.insert(v74, p73)
end
local function v_u_86(p76, p77, p_u_78) -- name: animate
	-- upvalues: (ref) v_u_67
	local v_u_79 = math.max(p76, 0.001)
	local v_u_80 = os.clock() - p77
	local v81 = p77 / v_u_79
	local v82 = math.clamp(v81, 0, 1)
	p_u_78(v82)
	if v82 < 1 then
		local v83 = v_u_67
		table.insert(v83, function()
			-- upvalues: (copy) v_u_80, (copy) v_u_79, (copy) p_u_78
			local v84 = (os.clock() - v_u_80) / v_u_79
			local v85 = math.clamp(v84, 0, 1)
			p_u_78(v85)
			return v85 < 1
		end)
	end
end
local v_u_87 = {
	["Flash"] = true,
	["Glare"] = true,
	["Core"] = true
}
local function v_u_96(p88, p89) -- name: scaleSequence
	local v90 = {}
	for _, v91 in p88.Keypoints do
		local v92 = NumberSequenceKeypoint.new
		local v93 = v91.Time
		local v94 = v91.Value * p89
		local v95 = v91.Envelope * p89
		table.insert(v90, v92(v93, v94, v95))
	end
	return NumberSequence.new(v90)
end
local function v_u_105(p97, p98, p99, p100) -- name: prepare
	-- upvalues: (copy) v_u_87, (copy) v_u_96
	local v101 = {}
	for _, v102 in p97:GetDescendants() do
		if not v102:IsA("ParticleEmitter") then
			continue
		end
		local v103 = v102:GetAttribute("Tint") == true
		if p100 or (v103 or not v_u_87[v102.Name]) then
			if v103 then
				if p98 then
					v102.Color = ColorSequence.new(p98)
				end
				local v104 = v102.LightEmission
				v102.LightEmission = math.min(v104, 0.45)
			end
			if p99 ~= 1 then
				v102.Size = v_u_96(v102.Size, p99)
				v102.Speed = NumberRange.new(v102.Speed.Min * p99, v102.Speed.Max * p99)
			end
			table.insert(v101, v102)
		else
			v102:Destroy()
		end
	end
	return v101
end
local function v_u_117(p106, p107, p108, p109, p110) -- name: burst
	-- upvalues: (copy) v_u_4, (copy) v_u_105, (copy) v_u_6, (copy) v_u_1
	local v111 = v_u_4:FindFirstChild("Fx")
	if v111 then
		v111 = v111:FindFirstChild(p106)
	end
	if not (v111 and v111:IsA("Attachment")) then
		v111 = nil
	end
	if v111 then
		local v112 = v111:Clone()
		local v113 = v_u_105(v112, p108, p109 or 1, p110)
		v112.WorldPosition = p107
		v112.Parent = v_u_6.Terrain
		for _, v_u_114 in v113 do
			local v115 = v_u_114:GetAttribute("Emit")
			if type(v115) == "number" then
				v_u_114.Enabled = false
				v_u_114:Emit(v115)
			else
				v_u_114.Enabled = true
				task.delay(0.15, function()
					-- upvalues: (copy) v_u_114
					v_u_114.Enabled = false
				end)
			end
		end
		local v116 = v112:GetAttribute("Life")
		v_u_1:AddItem(v112, (type(v116) ~= "number" and 2 or v116) + 0.5)
	end
end
local function v_u_131(p118, p119, p120, p121, p122) -- name: loop
	-- upvalues: (copy) v_u_4, (copy) v_u_105, (copy) v_u_1
	local v123 = v_u_4:FindFirstChild("Fx")
	local v124 = v123
	if v124 then
		v124 = v123:FindFirstChild(p118)
	end
	if not (v124 and v124:IsA("Attachment")) then
		v124 = nil
	end
	if not v124 then
		return function() end
	end
	local v_u_125 = v124:Clone()
	local v_u_126 = v_u_105(v_u_125, p120, p121 or 1, p122)
	v_u_125.Parent = p119
	for _, v127 in v_u_126 do
		local v128 = v127:GetAttribute("Emit")
		if type(v128) == "number" then
			v127:Emit(v128)
		else
			v127.Enabled = true
		end
	end
	v_u_1:AddItem(v_u_125, 15)
	local v_u_129 = false
	return function()
		-- upvalues: (ref) v_u_129, (copy) v_u_126, (ref) v_u_1, (copy) v_u_125
		if not v_u_129 then
			v_u_129 = true
			for _, v130 in v_u_126 do
				if not v130.Parent then
					continue
				end
				v130.Enabled = false
			end
			v_u_1:AddItem(v_u_125, 2)
		end
	end
end
local function v_u_139(p132, p133, p134, p135, p136) -- name: loopAt
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_131
	local v_u_137 = Instance.new("Attachment")
	v_u_137.WorldPosition = p133
	v_u_137.Parent = v_u_6.Terrain
	v_u_1:AddItem(v_u_137, 15)
	local v_u_138 = v_u_131(p132, v_u_137, p134, p135, p136)
	return function()
		-- upvalues: (copy) v_u_138, (ref) v_u_1, (copy) v_u_137
		v_u_138()
		v_u_1:AddItem(v_u_137, 2.2)
	end
end
local function v_u_145(p140, p141) -- name: aimAt
	local v142 = p141.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or p141.Unit
	local v143 = v142.Y
	local v144 = math.abs(v143) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p140, p140 + v142, v144)
end
local function v_u_152(p146, p147, p148, p149, p150) -- name: ball
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v151 = v_u_8.part(Vector3.new(1, 1, 1) * p148, CFrame.new(p146), p147, {
		["shape"] = Enum.PartType.Ball,
		["transparency"] = p149,
		["material"] = p150
	})
	v_u_1:AddItem(v151, 8)
	return v151
end
local function v_u_168(p153, p154, p155, p156, p157, p158) -- name: rod
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v159 = (p154 - p153).Magnitude
	local v160 = math.max(v159, 0.05)
	local v161 = (p153 + p154) / 2
	local v162 = p154 - p153
	local v163 = v162.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v162.Unit
	local v164 = v163.Y
	local v165 = math.abs(v164) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v166 = CFrame.lookAt(v161, v161 + v163, v165) * CFrame.Angles(0, 1.5707963267948966, 0)
	local v167 = v_u_8.part(Vector3.new(v160, p155, p155), v166, p156, {
		["shape"] = Enum.PartType.Cylinder,
		["transparency"] = p157,
		["material"] = p158
	})
	v_u_1:AddItem(v167, 8)
	return v167
end
local function v_u_180(p169, p170, p171, p172, p173, p174) -- name: pillar
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v175 = v_u_8.part
	local v176 = Vector3.new(p170, p171, p171)
	local v177 = CFrame.new
	local v178 = p170 / 2
	local v179 = v175(v176, v177(p169 + Vector3.new(0, v178, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), p172, {
		["shape"] = Enum.PartType.Cylinder,
		["transparency"] = p173,
		["material"] = p174
	})
	v_u_1:AddItem(v179, 8)
	return v179
end
local function v_u_190(p181, p182, p183, p184, p185) -- name: plate
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v186 = v_u_8.part
	local v187 = p182 * 2
	local v188 = p182 * 2
	local v189 = v186(Vector3.new(0.12, v187, v188), CFrame.new(p181) * CFrame.Angles(0, 0, 1.5707963267948966), p183, {
		["shape"] = Enum.PartType.Cylinder,
		["transparency"] = p184,
		["material"] = p185
	})
	v_u_1:AddItem(v189, 12)
	return v189
end
local function v_u_200(p191, p192, p193) -- name: thin
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v194 = p191.Size
	local v195 = v_u_8.tween
	local v196 = {
		["Size"] = nil,
		["Transparency"] = 1
	}
	local v197 = v194.X
	v196.Size = Vector3.new(v197, 0.05, 0.05)
	local v198 = Enum.EasingStyle.Quad
	local v199
	if p193 then
		v199 = Enum.EasingDirection.In
	else
		v199 = Enum.EasingDirection.Out
	end
	v195(p191, p192, v196, v198, v199)
	v_u_1:AddItem(p191, p192 + 0.05)
end
local function v_u_209(p201, p202, p203, p204, p205, p206, p207) -- name: pop
	-- upvalues: (copy) v_u_152, (copy) v_u_8, (copy) v_u_1
	local v208 = v_u_152(p201, p202, p203, p206, p207)
	v_u_8.tween(v208, p205, {
		["Size"] = nil,
		["Transparency"] = 1,
		["Size"] = Vector3.new(1, 1, 1) * math.max(p204, 0.05)
	}, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	v_u_1:AddItem(v208, p205 + 0.05)
	return v208
end
local function v_u_220(p210, p211, p212, p213, p214) -- name: dome
	-- upvalues: (copy) v_u_152, (copy) v_u_18, (copy) v_u_8, (copy) v_u_1
	local v215 = v_u_152
	local v216 = p210.X
	local v217 = v_u_18 + 0
	local v218 = p210.Z
	local v219 = v215(Vector3.new(v216, v217, v218), p212, p211 * 0.5, p214 and 0.2 or 0.72, p214)
	v_u_8.tween(v219, p213, {
		["Size"] = nil,
		["Transparency"] = 1,
		["Size"] = Vector3.new(1, 1, 1) * p211 * 2.15
	}, Enum.EasingStyle.Quart)
	v_u_1:AddItem(v219, p213 + 0.05)
end
local function v_u_247(p_u_221, p_u_222, p223, p224, p225, p226) -- name: sigil
	-- upvalues: (copy) v_u_8, (ref) v_u_67, (copy) v_u_1
	local v227 = v_u_8.part
	local v228 = p_u_222 * 0.4
	local v229 = p_u_222 * 0.4
	local v_u_230 = v227(Vector3.new(v228, 0.05, v229), p_u_221, p223, {
		["transparency"] = 1
	})
	local v_u_231 = {}
	for _, v232 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v233 = Instance.new("Decal")
		v233.Face = v232
		v233.Texture = p224
		v233.Color3 = p223
		v233.Transparency = 1
		v233.Parent = v_u_230
		table.insert(v_u_231, v233)
		v_u_8.tween(v233, 0.08, {
			["Transparency"] = 0
		})
	end
	local v234 = v_u_8.tween
	local v235 = {}
	local v236 = p_u_222 * 2
	local v237 = p_u_222 * 2
	v235.Size = Vector3.new(v236, 0.05, v237)
	v234(v_u_230, 0.16, v235, Enum.EasingStyle.Back)
	local v_u_238 = p226 or 0
	if v_u_238 ~= 0 then
		local v_u_239 = os.clock()
		local v240 = v_u_67
		table.insert(v240, function()
			-- upvalues: (copy) v_u_230, (copy) p_u_221, (copy) v_u_239, (copy) v_u_238
			if not v_u_230.Parent then
				return false
			end
			v_u_230.CFrame = p_u_221 * CFrame.Angles(0, (os.clock() - v_u_239) * v_u_238, 0)
			return true
		end)
	end
	task.delay(math.max(p225, 0), function()
		-- upvalues: (copy) v_u_231, (ref) v_u_8, (copy) v_u_230, (copy) p_u_222, (ref) v_u_1
		for _, v241 in v_u_231 do
			v_u_8.tween(v241, 0.2, {
				["Transparency"] = 1
			})
		end
		if v_u_230.Parent then
			local v242 = v_u_8.tween
			local v243 = v_u_230
			local v244 = {}
			local v245 = p_u_222 * 2.3
			local v246 = p_u_222 * 2.3
			v244.Size = Vector3.new(v245, 0.05, v246)
			v242(v243, 0.2, v244)
		end
		v_u_1:AddItem(v_u_230, 0.22)
	end)
	v_u_1:AddItem(v_u_230, p225 + 2)
	return v_u_230
end
local function v_u_265(p248, p249, p250, p251, p252, p253) -- name: mark
	-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_15, (copy) v_u_1
	local v254 = v_u_8.part
	local v255 = p250 * 2
	local v256 = p250 * 2
	local v257 = Vector3.new(v255, 0.05, v256)
	local v258 = CFrame.new
	local v259 = 0.06 + math.random() * 0.06
	local v260 = p248.X
	local v261 = v_u_18 + (v259 or 0.2)
	local v262 = p248.Z
	local v263 = v254(v257, v258((Vector3.new(v260, v261, v262))) * CFrame.Angles(0, math.random() * 6.28, 0), p249, {
		["transparency"] = 1
	})
	local v264 = Instance.new("Decal")
	v264.Face = Enum.NormalId.Top
	v264.Texture = p252 or v_u_15.Glow
	v264.Color3 = p249
	v264.Transparency = p253 or 0.1
	v264.Parent = v263
	v_u_8.tween(v264, p251, {
		["Transparency"] = 1
	}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	v_u_1:AddItem(v263, p251 + 0.05)
end
local function v_u_292(p266, p267, p268, p269, p270, p271) -- name: groundLine
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_1
	local v272 = p266.X
	local v273 = v_u_18 + 0.08
	local v274 = p266.Z
	local v275 = Vector3.new(v272, v273, v274)
	local v276 = p267.X
	local v277 = v_u_18 + 0.08
	local v278 = p267.Z
	local v279 = Vector3.new(v276, v277, v278)
	local v280 = (v279 - v275).Magnitude
	if v280 >= 0.5 then
		local v281 = v_u_8.part
		local v282 = Vector3.new(p268, 0.1, v280)
		local v283 = (v275 + v279) / 2
		local v284 = v279 - v275
		local v285 = v284.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v284.Unit
		local v286 = v285.Y
		local v287 = math.abs(v286) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v288 = v281(v282, CFrame.lookAt(v283, v283 + v285, v287), p269, {
			["transparency"] = p271 or 0.3
		})
		local v289 = v_u_8.tween
		local v290 = {
			["Transparency"] = 1,
			["Size"] = nil
		}
		local v291 = p268 * 0.2
		v290.Size = Vector3.new(v291, 0.1, v280)
		v289(v288, p270, v290, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_1:AddItem(v288, p270 + 0.05)
	end
end
local function v_u_315(p293, p294, p295, p296, p297, p298, p299, p300) -- name: spikes
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	for _ = 1, p295 do
		local v301 = math.random() - 0.5
		local v302 = math.random() - 0.5
		local v303 = math.random() - 0.5
		local v304 = Vector3.new(v301, v302, v303) * 2
		if p298 then
			v304 = p298 + v304 * (p299 or 0.4)
		end
		if p300 then
			local v305 = v304.X
			local v306 = v304.Y * 0.15
			local v307 = v304.Z
			v304 = Vector3.new(v305, v306, v307)
		end
		local v308 = v304.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v304.Unit
		local v309 = v308.Y
		local v310 = math.abs(v309) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v311 = CFrame.lookAt(p293, p293 + v308, v310)
		local v312 = v_u_8.part
		local v313 = p296 * 0.25
		local v314 = v312(Vector3.new(0.4, 0.4, v313), v311 * CFrame.new(0, 0, -p296 * 0.2), p294)
		v_u_8.tween(v314, p297, {
			["Size"] = nil,
			["CFrame"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(0.06, 0.06, p296),
			["CFrame"] = v311 * CFrame.new(0, 0, -p296 * 0.85)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		v_u_1:AddItem(v314, p297 + 0.05)
	end
end
local function v_u_342(p316, p317, p318, p319, p320) -- name: inward
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	for _ = 1, p318 do
		local v321 = math.random() * 3.141592653589793 * 2
		local v322 = math.cos(v321)
		local v323 = (math.random() - 0.5) * 0.8
		local v324 = math.sin(v321)
		local v325 = Vector3.new(v322, v323, v324).Unit
		local v326 = p316 + v325 * p319
		local v327 = v_u_8.part
		local v328 = p319 * 0.45
		local v329 = Vector3.new(0.35, 0.35, v328)
		local v330 = p316 - v326
		local v331 = v330.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v330.Unit
		local v332 = v331.Y
		local v333 = math.abs(v332) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v334 = v327(v329, CFrame.lookAt(v326, v326 + v331, v333), p317)
		local v335 = v_u_8.tween
		local v336 = {
			["Size"] = Vector3.new(0.05, 0.05, 1),
			["CFrame"] = nil,
			["Transparency"] = 1
		}
		local v337 = p316 + v325
		local v338 = p316 - v326
		local v339 = v338.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v338.Unit
		local v340 = v339.Y
		local v341 = math.abs(v340) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v336.CFrame = CFrame.lookAt(v337, v337 + v339, v341)
		v335(v334, p320, v336, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_1:AddItem(v334, p320 + 0.05)
	end
end
local function v_u_359(p343, p344, p345, p346) -- name: glint
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_1, (copy) v_u_209, (copy) v_u_33
	local v347 = v_u_6.CurrentCamera
	if v347 then
		local v348 = v347.CFrame
		local v349 = CFrame.fromMatrix(p343, v348.RightVector, v348.UpVector)
		local v350 = {}
		local v351 = Vector3.new(p345, 0.5, 0.5)
		local v352 = p345 * 0.7
		__set_list(v350, 1, {v351, (Vector3.new(0.5, v352, 0.5))})
		local v353 = p346 or 0.18
		for _, v354 in v350 do
			local v355 = v_u_8.part(v354 * 0.3 + Vector3.new(0.3, 0.3, 0.3), v349, p344)
			local v356 = v354.X <= 1 and 0.05 or v354.X
			local v357 = v354.Y <= 1 and 0.05 or v354.Y
			local v358 = {
				["Size"] = nil,
				["Transparency"] = 1,
				["Size"] = Vector3.new(v356, v357, 0.05)
			}
			v_u_8.tween(v355, v353, v358, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			v_u_1:AddItem(v355, v353 + 0.05)
		end
		v_u_209(p343, v_u_33, p345 * 0.25, p345 * 0.05, v353)
	end
end
local function v_u_405(p360, p361, p362, p363, p364, p_u_365, p366, p367) -- name: chunks
	-- upvalues: (copy) v_u_8, (copy) v_u_1, (copy) v_u_18, (ref) v_u_67
	local v_u_368 = {}
	for v369 = 1, p362 do
		local v370 = p364 * (0.6 + math.random() * 0.7)
		local v371 = v_u_8.part
		local v372 = Vector3.new(1, 1, 1) * v370
		local v373 = CFrame.new(p360)
		local v374 = p361[(v369 - 1) % #p361 + 1]
		local v375 = {}
		local v376
		if p366 then
			v376 = Enum.Material.Neon
		else
			v376 = Enum.Material.SmoothPlastic
		end
		v375.material = v376
		local v377 = v371(v372, v373, v374, v375)
		local v378 = math.random() * 3.141592653589793 * 2
		local v379 = math.cos(v378)
		local v380 = math.sin(v378)
		local v381 = Vector3.new(v379, 0, v380) * p363 * (0.5 + math.random() * 0.6)
		local v382 = p363 * (p367 or 0.9) * (0.6 + math.random() * 0.6)
		local v383 = {
			["p"] = v377,
			["v"] = v381 + Vector3.new(0, v382, 0),
			["r"] = CFrame.Angles(math.random() * 6, math.random() * 6, 0),
			["spin"] = CFrame.Angles((math.random() - 0.5) * 0.5, (math.random() - 0.5) * 0.5, 0)
		}
		table.insert(v_u_368, v383)
		v_u_1:AddItem(v377, p_u_365 + 0.1)
	end
	local v_u_384 = os.clock()
	local v_u_385 = v_u_384
	local function v403()
		-- upvalues: (ref) v_u_385, (copy) v_u_384, (copy) p_u_365, (copy) v_u_368, (ref) v_u_18
		local v386 = os.clock()
		local v387 = v386 - v_u_385
		local v388 = math.min(v387, 0.05)
		v_u_385 = v386
		local v389 = v386 - v_u_384
		local v390 = (v389 - p_u_365 * 0.6) / (p_u_365 * 0.4)
		local v391 = math.clamp(v390, 0, 1)
		for _, v392 in v_u_368 do
			local v393 = v392.v
			local v394 = v388 * 110
			v392.v = v393 - Vector3.new(0, v394, 0)
			local v395 = v392.p.Position + v392.v * v388
			local v396 = v_u_18 + v392.p.Size.Y / 2
			if v395.Y < v396 then
				local v397 = v395.X
				local v398 = v395.Z
				v395 = Vector3.new(v397, v396, v398)
				local v399 = v392.v.X * 0.5
				local v400 = v392.v.Y
				local v401 = math.abs(v400) * 0.3
				local v402 = v392.v.Z * 0.5
				v392.v = Vector3.new(v399, v401, v402)
			end
			v392.r = v392.r * v392.spin
			v392.p.CFrame = CFrame.new(v395) * v392.r
			v392.p.Transparency = v391
		end
		return v389 < p_u_365
	end
	local v404 = v_u_67
	table.insert(v404, v403)
end
local function v_u_421(p406, p407, p408, p409) -- name: boltPath
	local v410 = p407 - p406
	local v411 = v410.Magnitude / p409
	local v412 = math.floor(v411)
	local v413 = math.clamp(v412, 2, 16)
	local v414 = v410.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v410.Unit
	local v415 = v414.Y
	local v416 = math.abs(v415) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v417 = CFrame.lookAt(p406, p406 + v414, v416)
	local v418 = { p406 }
	for v419 = 1, v413 - 1 do
		local v420 = p406 + v410 * (v419 / v413) + v417.RightVector * (math.random() - 0.5) * 2 * p408 + v417.UpVector * (math.random() - 0.5) * 2 * p408
		table.insert(v418, v420)
	end
	table.insert(v418, p407)
	return v418
end
local function v_u_428(p422, p423, p424, p425, p426) -- name: drawPath
	-- upvalues: (copy) v_u_200, (copy) v_u_168
	for v427 = 2, #p422 do
		v_u_200(v_u_168(p422[v427 - 1], p422[v427], p423, p424, p426), p425)
	end
end
local function v_u_437(p429, p430) -- name: jitter
	local v431 = {}
	for _, v432 in p429 do
		local v433 = math.random() - 0.5
		local v434 = math.random() - 0.5
		local v435 = math.random() - 0.5
		local v436 = v432 + Vector3.new(v433, v434, v435) * 2 * p430
		table.insert(v431, v436)
	end
	return v431
end
local function v_u_450(p438, p439, p440, p441, p_u_442) -- name: alongPath
	local v443 = (p439 - p438).Magnitude / p440
	local v444 = math.floor(v443)
	local v445 = math.max(v444, 1)
	for v446 = 1, v445 do
		local v_u_447 = p438:Lerp(p439, v446 / v445)
		local v448 = p441 * v446 / v445
		local function v449()
			-- upvalues: (copy) p_u_442, (copy) v_u_447
			p_u_442(v_u_447)
		end
		if v448 > 0.005 then
			task.delay(v448, v449)
		else
			p_u_442(v_u_447)
		end
	end
end
local function v_u_461(p451, p452, p453, p454, p455) -- name: streak
	local v456 = Instance.new("Attachment")
	local v457 = p454 / 2
	v456.Position = Vector3.new(0, v457, 0)
	v456.Parent = p451
	local v458 = Instance.new("Attachment")
	local v459 = -p454 / 2
	v458.Position = Vector3.new(0, v459, 0)
	v458.Parent = p451
	local v460 = Instance.new("Trail")
	v460.Attachment0 = v456
	v460.Attachment1 = v458
	v460.Color = ColorSequence.new(p452, p453)
	v460.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v460.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.15) })
	v460.Lifetime = p455
	v460.LightEmission = 0.35
	v460.LightInfluence = 0
	v460.FaceCamera = true
	v460.MinLength = 0.05
	v460.Parent = p451
end
local function v_u_492(p_u_462, p_u_463, p_u_464, p_u_465, p_u_466, p_u_467, p_u_468, p_u_469) -- name: assemble
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_8
	for _, v470 in p_u_463 do
		v_u_1:AddItem(v470.p, 6)
	end
	for _, v471 in p_u_464 do
		v_u_1:AddItem(v471, 6)
	end
	v_u_1:AddItem(p_u_462, 6)
	local v_u_472 = false
	return {
		["place"] = function(p473, p474) -- name: place
			-- upvalues: (copy) p_u_462, (copy) p_u_469, (copy) p_u_463, (copy) p_u_464, (copy) p_u_466, (copy) p_u_465
			p_u_462.CFrame = p473
			local v475
			if p_u_469 then
				v475 = p473 * CFrame.Angles(0, 0, p474 * p_u_469)
			else
				v475 = p473
			end
			for _, v476 in p_u_463 do
				v476.p.CFrame = v475 * v476.off
			end
			local v477 = #p_u_464
			for v478, v479 in p_u_464 do
				local v480 = p474 * p_u_466 + v478 / v477 * 3.141592653589793 * 2
				v479.CFrame = p473 * CFrame.new(math.cos(v480) * p_u_465, math.sin(v480) * p_u_465, 0)
			end
		end,
		["stop"] = function(p481) -- name: stop
			-- upvalues: (ref) v_u_472, (copy) p_u_467, (copy) p_u_463, (ref) v_u_6, (ref) v_u_1, (copy) p_u_462, (copy) p_u_468, (copy) p_u_464, (ref) v_u_8
			if not v_u_472 then
				v_u_472 = true
				for _, v482 in p_u_467 do
					v482()
				end
				for _, v483 in p_u_463 do
					for _, v484 in v483.p:GetChildren() do
						if not (v484:IsA("Attachment") and v484:FindFirstChildWhichIsA("ParticleEmitter")) then
							continue
						end
						local v485 = v484.WorldPosition
						v484.Parent = v_u_6.Terrain
						v484.WorldPosition = v485
						v_u_1:AddItem(v484, 2)
					end
				end
				local v486 = p_u_462:FindFirstChildWhichIsA("PointLight")
				if v486 then
					v486:Destroy()
				end
				v_u_1:AddItem(p_u_462, p_u_468 + 0.05)
				local v487 = {}
				for _, v488 in p_u_463 do
					local v489 = v488.p
					table.insert(v487, v489)
				end
				for _, v490 in p_u_464 do
					table.insert(v487, v490)
				end
				for _, v491 in v487 do
					if p481 then
						v_u_8.tween(v491, p481, {
							["Transparency"] = 1
						})
						v_u_1:AddItem(v491, p481 + 0.05)
					else
						v491:Destroy()
					end
				end
			end
		end
	}
end
local function v_u_514(p493, p494, p495) -- name: orbShot
	-- upvalues: (copy) v_u_8, (copy) v_u_461, (copy) v_u_131, (copy) v_u_492
	local v496 = p493.size
	local v497 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), p494, p495.trail, {
		["transparency"] = 1
	})
	local v498 = v_u_8.part(Vector3.new(1, 1, 1) * p495.coreSize * v496, p494, p495.core, {
		["shape"] = Enum.PartType.Ball,
		["material"] = p495.coreMaterial
	})
	local v499 = {
		{
			["p"] = v498,
			["off"] = CFrame.identity
		}
	}
	local v500 = p495.shell
	if v500 then
		local v501 = {
			["p"] = v_u_8.part(Vector3.new(1, 1, 1) * (p495.shellSize or p495.coreSize * 1.7) * v496, p494, v500, {
				["shape"] = Enum.PartType.Ball,
				["transparency"] = p495.shellAlpha or 0.5
			}),
			["off"] = CFrame.identity
		}
		table.insert(v499, v501)
	end
	local v502 = {}
	local v503 = p495.orbit
	if v503 then
		for _ = 1, p495.orbitCount or 2 do
			local v504 = v_u_8.part
			local v505 = Vector3.new(1, 1, 1) * (p495.orbitSize or 0.5) * v496
			local v506 = {
				["shape"] = Enum.PartType.Ball,
				["material"] = p495.orbitMaterial
			}
			table.insert(v502, v504(v505, p494, v503, v506))
		end
	end
	local v507 = p495.trailLife or 0.16
	v_u_461(v497, p495.trail, p495.trailEnd or p495.trail, p495.trailWidth * v496, v507)
	local v508 = {}
	local v509 = p495.loop
	if v509 and not p493.lite then
		local v510 = v_u_131(v509, v498, p495.loopColor, (p495.loopScale or 0.35) * v496)
		table.insert(v508, v510)
	end
	if p493.mine then
		local v511 = p495.trail
		local v512 = 10 * v496
		local v513 = Instance.new("PointLight")
		v513.Color = v511
		v513.Range = v512
		v513.Brightness = 2
		v513.Shadows = false
		v513.Parent = v497
	end
	return v_u_492(v497, v499, v502, (p495.orbitRadius or 1.5) * v496, p495.orbitSpeed or 14, v508, v507)
end
local function v_u_539(p515, p516, p517) -- name: arrowShot
	-- upvalues: (copy) v_u_8, (copy) v_u_461, (copy) v_u_131, (copy) v_u_492
	local v518 = p515.size
	local v519 = p517.length * v518
	local v520 = p517.thick * v518
	local v521 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), p516, p517.trail, {
		["transparency"] = 1
	})
	local v522 = v_u_8.part(Vector3.new(v520, v520, v519), p516, p517.shaft)
	local v523 = v_u_8.part
	local v524 = v520 * 2.6
	local v525 = v520 * 2.6
	local v526 = v519 * 1.05
	local v527 = v523(Vector3.new(v524, v525, v526), p516, p517.glow, {
		["transparency"] = 0.6
	})
	local v528 = v520 * 3
	local v529 = v_u_8.part
	local v530 = v528 * 1.8
	local v531 = v529(Vector3.new(v528, v528, v530), p516, p517.head)
	local v532 = {
		{
			["p"] = v522,
			["off"] = CFrame.identity
		},
		{
			["p"] = v527,
			["off"] = CFrame.identity
		},
		{
			["p"] = v531,
			["off"] = CFrame.new(0, 0, -v519 / 2) * CFrame.Angles(0, 0, 0.7853981633974483)
		}
	}
	v_u_461(v521, p517.trail, p517.trailEnd, p517.trailWidth * v518, 0.14)
	local v533 = {}
	local v534 = p517.loop
	if v534 and not p515.lite then
		local v535 = v_u_131(v534, v522, p517.loopColor, 0.3 * v518)
		table.insert(v533, v535)
	end
	if p515.mine then
		local v536 = p517.glow
		local v537 = 9 * v518
		local v538 = Instance.new("PointLight")
		v538.Color = v536
		v538.Range = v537
		v538.Brightness = 2
		v538.Shadows = false
		v538.Parent = v521
	end
	return v_u_492(v521, v532, {}, 0, 0, v533, 0.14)
end
local function v_u_550(p540, p541) -- name: swordShot
	-- upvalues: (copy) v_u_8, (copy) v_u_65, (copy) v_u_66, (copy) v_u_461, (copy) v_u_492
	local v542 = p540.size
	local v543 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), p541, v_u_65, {
		["transparency"] = 1
	})
	local v544 = v_u_8.part(Vector3.new(0.35, 1.2, 6.5) * v542, p541, v_u_66)
	local v545 = v_u_8.part(Vector3.new(0.6, 2, 7.2) * v542, p541, v_u_65, {
		["transparency"] = 0.55
	})
	local v546 = v_u_8.part(Vector3.new(0.6, 3.6, 0.6) * v542, p541, v_u_65)
	local v547 = v_u_8.part(Vector3.new(0.5, 0.5, 1.8) * v542, p541, Color3.fromRGB(205, 150, 50), {
		["material"] = Enum.Material.Metal
	})
	local v548 = v_u_8.part(Vector3.new(0.8, 0.8, 0.8) * v542, p541, v_u_65, {
		["shape"] = Enum.PartType.Ball
	})
	local v549 = {
		{
			["p"] = v544,
			["off"] = CFrame.new(0, 0, -1.4 * v542)
		},
		{
			["p"] = v545,
			["off"] = CFrame.new(0, 0, -1.4 * v542)
		},
		{
			["p"] = v546,
			["off"] = CFrame.new(0, 0, 1.95 * v542)
		},
		{
			["p"] = v547,
			["off"] = CFrame.new(0, 0, 3 * v542)
		},
		{
			["p"] = v548,
			["off"] = CFrame.new(0, 0, 4 * v542)
		}
	}
	v_u_461(v543, v_u_65, v_u_66, 1.4 * v542, 0.12)
	return v_u_492(v543, v549, {}, 0, 0, {}, 0.12)
end
local v_u_551 = {}
local function v_u_557(p552, p553, p554) -- name: muzzle
	-- upvalues: (copy) v_u_8, (copy) v_u_209, (copy) v_u_33, (copy) v_u_315
	local v555 = p552.size * (p554 or 1)
	local v556 = p552.eye + p552.dir * 1.1
	v_u_8.flash(v556, p553, 3.4 * v555, 0.13)
	v_u_209(v556, v_u_33, 1.4 * v555, 0.3 * v555, 0.1)
	if not p552.lite then
		v_u_315(v556, p553, 3, 3.2 * v555, 0.12, p552.dir, 0.35)
	end
end
local function v_u_575(p558, p559, p560, p561) -- name: skillCast
	-- upvalues: (copy) v_u_117, (copy) v_u_8, (copy) v_u_15, (copy) v_u_7, (copy) v_u_1, (copy) v_u_180
	local v562 = p558.size
	v_u_117("Flash", p558.eye, p559, (p560 and 0.3 or 0.2) * v562)
	v_u_8.flash(p558.eye, p559, (p560 and 6 or 4) * v562, 0.16)
	local v563 = p558.feet
	v_u_8.ring(v563, p559, (p560 and 9 or 6) * v562, 0.3, v_u_15.Ring)
	local v564 = (p560 and 5 or 3.6) * v562
	if p561 then
		local v565 = v_u_7.rod
		local v566 = 9 * v562
		for _, v567 in v565(v563, v563 + Vector3.new(0, v566, 0), v564, p559, 0.6) do
			local v568 = v_u_8.tween
			local v569 = {
				["Size"] = nil,
				["Transparency"] = 1
			}
			local v570 = 13 * v562
			v569.Size = Vector3.new(v570, 0.1, 0.1)
			v568(v567, 0.22, v569)
			v_u_1:AddItem(v567, 0.25)
		end
	else
		local v571 = v_u_180(v563, 9 * v562, v564, p559, 0.6)
		local v572 = v_u_8.tween
		local v573 = {
			["Size"] = nil,
			["Transparency"] = 1
		}
		local v574 = 13 * v562
		v573.Size = Vector3.new(v574, 0.1, 0.1)
		v572(v571, 0.22, v573)
		v_u_1:AddItem(v571, 0.25)
	end
	if p558.mine then
		v_u_8.shake(p560 and 0.14 or 0.07, 0.14)
	end
end
local function v_u_600(p576, p577, p_u_578, p579, p580) -- name: bindHit
	-- upvalues: (copy) v_u_247, (copy) v_u_15, (copy) v_u_117, (ref) v_u_24, (ref) v_u_67
	local v_u_581 = p576.ability.freeze or 1
	local v_u_582 = {}
	for v583, v584 in { -0.8, 0.9 } do
		local v585 = v_u_247
		local v586 = CFrame.new(p577 + Vector3.new(0, v584, 0))
		local v587 = v583 == 1 and 2.6 or 2.1
		local v588
		if v583 == 1 then
			v588 = p579
		else
			v588 = p580
		end
		local v589 = {
			["p"] = v585(v586, v587, v588, v_u_15.Ring, v_u_581, 0),
			["h"] = v584,
			["spin"] = v583 == 1 and 3 or -4
		}
		table.insert(v_u_582, v589)
	end
	v_u_117("Impact", p577, p579, 0.7)
	local v_u_590 = os.clock()
	local function v598()
		-- upvalues: (ref) v_u_24, (copy) p_u_578, (copy) v_u_582, (copy) v_u_590, (copy) v_u_581
		local v591 = v_u_24(p_u_578)
		if not v591 then
			for _, v592 in v_u_582 do
				v592.p:Destroy()
			end
			return false
		end
		local v593 = os.clock() - v_u_590
		for _, v594 in v_u_582 do
			if not v594.p.Parent then
				continue
			end
			local v595 = v594.p
			local v596 = CFrame.new
			local v597 = v594.h
			v595.CFrame = v596(v591 + Vector3.new(0, v597, 0)) * CFrame.Angles(0, v593 * v594.spin, 0)
		end
		return v593 < v_u_581 + 0.3
	end
	local v599 = v_u_67
	table.insert(v599, v598)
end
local function v_u_649(p_u_601, p_u_602, p603, p604, p605, p_u_606, p_u_607) -- name: liftRocks
	-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_1, (ref) v_u_67
	local v_u_608 = {}
	for v609 = 1, p604 do
		local v610 = 0.8 + math.random() * 1.4
		local v611 = v_u_8.part
		local v612 = Vector3.new(1, 1, 1) * v610
		local v613 = CFrame.new
		local v614 = v610 / 2
		local v615 = p_u_601.X
		local v616 = v_u_18 + (v614 or 0.2)
		local v617 = p_u_601.Z
		local v618 = v611(v612, v613((Vector3.new(v615, v616, v617))), p605[(v609 - 1) % #p605 + 1], {
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_1:AddItem(v618, p_u_606 + 1)
		local v619 = {
			["p"] = v618,
			["a"] = math.random() * 3.141592653589793 * 2,
			["d"] = p603 * (0.35 + math.random() * 0.75),
			["wait"] = math.random() * p_u_606 * 0.4,
			["rise"] = 0.45 + math.random() * 0.5,
			["spin"] = 1 + math.random() * 3,
			["tilt"] = (math.random() - 0.5) * 1.6
		}
		table.insert(v_u_608, v619)
	end
	local v_u_620 = os.clock()
	local v_u_621 = nil
	local function v647()
		-- upvalues: (copy) v_u_620, (ref) v_u_621, (copy) v_u_608, (copy) p_u_601, (ref) v_u_18, (copy) p_u_602, (copy) p_u_607, (copy) p_u_606
		local v622 = os.clock()
		local v623 = v622 - v_u_620
		local v624
		if v_u_621 then
			local v625 = (v622 - v_u_621) / 0.12
			v624 = math.clamp(v625, 0, 1)
		else
			v624 = 0
		end
		for _, v626 in v_u_608 do
			local v627 = (v623 - v626.wait) / v626.rise
			local v628 = math.clamp(v627, 0, 1)
			local v629 = v628 * v628 * (3 - v628 * 2)
			local v630 = v626.a + v623 * 2.4
			local v631 = p_u_601
			local v632 = v626.p.Size.Y / 2
			local v633 = v631.X
			local v634 = v_u_18 + (v632 or 0.2)
			local v635 = v631.Z
			local v636 = Vector3.new(v633, v634, v635)
			local v637 = math.cos(v630) * v626.d
			local v638 = math.sin(v630) * v626.d
			local v639 = v636 + Vector3.new(v637, 0, v638)
			local v640 = p_u_602
			local v641 = math.cos(v630) * p_u_607
			local v642 = v630 * 1.3 + v626.tilt
			local v643 = math.sin(v642) * p_u_607 * 0.45
			local v644 = math.sin(v630) * p_u_607
			local v645 = v639:Lerp(v640 + Vector3.new(v641, v643, v644), v629):Lerp(p_u_602, v624)
			v626.p.CFrame = CFrame.new(v645) * CFrame.Angles(v623 * v626.spin, v623 * v626.spin * 0.7, 0)
		end
		if not v_u_621 or v624 < 1 then
			return v623 < p_u_606 + 0.6
		end
		for _, v646 in v_u_608 do
			v646.p:Destroy()
		end
		return false
	end
	local v648 = v_u_67
	table.insert(v648, v647)
	return function()
		-- upvalues: (ref) v_u_621
		v_u_621 = os.clock()
	end
end
local v_u_650 = { 1, 0.7, 0.42 }
local function v_u_705(p651, p652, p653, p654, p655, p656, p_u_657, p658, p659) -- name: tongues
	-- upvalues: (copy) v_u_18, (copy) v_u_650, (copy) v_u_8, (copy) v_u_1, (ref) v_u_67
	local v_u_660 = {}
	for v661 = 1, p653 do
		local v662 = (v661 + math.random() * 0.4) / p653 * 3.141592653589793 * 2
		local v663
		if p658 then
			v663 = p652
		else
			v663 = v661 == 1 and 0 or p652 * (0.3 + math.random() * 0.6)
		end
		local v664 = p651.X
		local v665 = v_u_18 + 0
		local v666 = p651.Z
		local v667 = Vector3.new(v664, v665, v666)
		local v668 = math.cos(v662) * v663
		local v669 = math.sin(v662) * v663
		local v670 = v667 + Vector3.new(v668, 0, v669)
		local v671 = 1.5 + math.random() * 1
		local v672 = {
			["cores"] = {},
			["sheaths"] = {},
			["base"] = v670,
			["a"] = v662,
			["h"] = p654 * (0.55 + math.random() * 0.45) * (v663 == 0 and 1.35 or 1),
			["w"] = v671,
			["lean"] = v663 == 0 and 0 or 0.2 + math.random() * 0.18,
			["phase"] = math.random() * 6
		}
		for _ = 1, #v_u_650 do
			local v673 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v670), p655, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v674 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v670), p656, {
				["transparency"] = p659 or 0.6
			})
			v_u_1:AddItem(v673, p_u_657 + 1)
			v_u_1:AddItem(v674, p_u_657 + 1)
			local v675 = v672.cores
			table.insert(v675, v673)
			local v676 = v672.sheaths
			table.insert(v676, v674)
		end
		table.insert(v_u_660, v672)
	end
	local v_u_677 = os.clock()
	local function v703()
		-- upvalues: (copy) v_u_677, (copy) p_u_657, (copy) v_u_660, (ref) v_u_650
		local v678 = os.clock() - v_u_677
		local v679 = v678 / 0.12
		local v680 = math.clamp(v679, 0, 1)
		local v681 = (v678 - p_u_657) / 0.3
		local v682 = v680 * (1 - math.clamp(v681, 0, 1))
		for _, v683 in v_u_660 do
			local v684 = v683.h * v682
			local v685 = v678 * 14 + v683.phase
			local v686 = v684 * (math.sin(v685) * 0.12 + 1)
			local v687 = math.max(v686, 0.3) / #v_u_650
			local v688 = CFrame.new(v683.base) * CFrame.Angles(0, -v683.a, 0) * CFrame.Angles(0, 0, -v683.lean)
			for v689, v690 in v_u_650 do
				local v691 = v683.w * v690
				local v692 = v678 * 9 + v683.phase + v689
				local v693 = math.sin(v692) * 0.25 * (v689 - 1)
				local v694 = v688 * CFrame.new(v693, v687 * (v689 - 0.5), 0) * CFrame.Angles(0, 0.7853981633974483 + v678 * 1.5 + v683.phase, 0)
				local v695 = v683.cores[v689]
				local v696 = v687 + 0.05
				v695.Size = Vector3.new(v691, v696, v691)
				v683.cores[v689].CFrame = v694
				local v697 = v683.sheaths[v689]
				local v698 = v691 * 1.35
				local v699 = v687 * 1.05
				local v700 = v691 * 1.35
				v697.Size = Vector3.new(v698, v699, v700)
				v683.sheaths[v689].CFrame = v694
			end
		end
		if p_u_657 + 0.3 >= v678 then
			return true
		end
		for _, v701 in v_u_660 do
			for v702 = 1, #v_u_650 do
				v701.cores[v702]:Destroy()
				v701.sheaths[v702]:Destroy()
			end
		end
		return false
	end
	local v704 = v_u_67
	table.insert(v704, v703)
end
local function v708(p706, p707, _) -- name: fireHit
	-- upvalues: (copy) v_u_117, (copy) v_u_38
	v_u_117("Impact", p707, v_u_38, 0.7)
	if not p706.lite then
		v_u_117("Fire", p707 - Vector3.new(0, 1.5, 0), v_u_38, 0.3)
	end
end
local function v_u_717(p709, p710, p711) -- name: fireImpact
	-- upvalues: (copy) v_u_117, (copy) v_u_38, (copy) v_u_8, (copy) v_u_209, (copy) v_u_37, (copy) v_u_18, (copy) v_u_405, (copy) v_u_39, (copy) v_u_265, (copy) v_u_35, (copy) v_u_10
	local v712 = p709.size * p711
	v_u_117("Impact", p710, v_u_38, 1.1 * v712)
	v_u_8.flash(p710, v_u_38, 6.5 * v712, 0.2)
	v_u_209(p710, v_u_37, 2 * v712, 4.5 * v712, 0.14)
	if not p709.lite then
		local v713 = v_u_117
		local v714 = p710.X
		local v715 = v_u_18 + 0.2
		local v716 = p710.Z
		v713("Fire", Vector3.new(v714, v715, v716), v_u_38, 0.55 * v712)
		v_u_405(p710, { v_u_38, v_u_37, v_u_39 }, 4, 26, 0.5 * v712, 0.45, true)
	end
	v_u_265(p710, v_u_35, 2.6 * v712, 0.9)
	v_u_10.play("Hit", {
		["at"] = nil,
		["volume"] = 0.5,
		["at"] = p710
	})
end
v_u_551.fireball = {
	["cast"] = function(p718) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_38, (copy) v_u_117
		v_u_557(p718, v_u_38)
		if not p718.lite then
			v_u_117("Fire", p718.eye + p718.dir * 1.2, v_u_38, 0.25)
		end
	end,
	["shot"] = function(p719, p720) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_37, (copy) v_u_38, (copy) v_u_39
		return v_u_514(p719, p720, {
			["core"] = nil,
			["coreSize"] = 1.6,
			["shell"] = nil,
			["shellSize"] = 2.8,
			["shellAlpha"] = 0.3,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 2,
			["loop"] = "Fire",
			["loopColor"] = nil,
			["loopScale"] = 0.32,
			["core"] = v_u_37,
			["shell"] = v_u_38,
			["trail"] = v_u_38,
			["trailEnd"] = v_u_39,
			["loopColor"] = v_u_38
		})
	end,
	["impact"] = function(p721, p722) -- name: impact
		-- upvalues: (copy) v_u_717
		v_u_717(p721, p722, 1)
	end,
	["hit"] = v708
}
v_u_551.phoenix = {
	["weave"] = 2.6,
	["cast"] = nil,
	["shot"] = nil,
	["impact"] = nil,
	["hit"] = nil,
	["cast"] = function(p723) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_38, (copy) v_u_247, (copy) v_u_15, (copy) v_u_117, (copy) v_u_315, (copy) v_u_37
		v_u_575(p723, v_u_38)
		local v724 = p723.eye + p723.dir * 2
		local v725 = v_u_247
		local v726 = p723.dir
		local v727 = v726.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v726.Unit
		local v728 = v727.Y
		local v729 = math.abs(v728) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v725(CFrame.lookAt(v724, v724 + v727, v729) * CFrame.Angles(-1.5707963267948966, 0, 0), 2.6 * p723.size, v_u_38, v_u_15.Ring, 0.12, 6)
		v_u_117("Fire", v724, v_u_38, 0.5)
		v_u_315(v724, v_u_37, 5, 5, 0.16, p723.dir, 0.7)
	end,
	["shot"] = function(p730, p731) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_37, (copy) v_u_39, (copy) v_u_38, (copy) v_u_40
		return v_u_514(p730, p731, {
			["core"] = nil,
			["coreSize"] = 1.2,
			["shell"] = nil,
			["shellSize"] = 2.1,
			["shellAlpha"] = 0.3,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.4,
			["orbit"] = nil,
			["orbitCount"] = 2,
			["orbitRadius"] = 0.95,
			["orbitSize"] = 0.55,
			["orbitSpeed"] = 18,
			["loop"] = "Fire",
			["loopColor"] = nil,
			["loopScale"] = 0.22,
			["core"] = v_u_37,
			["shell"] = v_u_39,
			["trail"] = v_u_38,
			["trailEnd"] = v_u_40,
			["orbit"] = v_u_38,
			["loopColor"] = v_u_38
		})
	end,
	["impact"] = function(p732, p733) -- name: impact
		-- upvalues: (copy) v_u_717
		v_u_717(p732, p733, 0.9)
	end,
	["hit"] = v708
}
local function v_u_760(p_u_734, p_u_735, p_u_736) -- name: tomoeSweep
	-- upvalues: (copy) v_u_152, (copy) v_u_34, (copy) v_u_40, (copy) v_u_18, (copy) v_u_8, (copy) v_u_1, (ref) v_u_67
	local v_u_737 = {}
	for _ = 1, 3 do
		local v738 = {
			["core"] = v_u_152(p_u_734, v_u_34, 1.5, 0, Enum.Material.SmoothPlastic),
			["rim"] = v_u_152(p_u_734, v_u_40, 2.1, 0.45)
		}
		table.insert(v_u_737, v738)
	end
	local v_u_739 = os.clock()
	local function v758()
		-- upvalues: (copy) v_u_739, (copy) p_u_736, (copy) p_u_735, (copy) v_u_737, (copy) p_u_734, (ref) v_u_18, (ref) v_u_8, (ref) v_u_1
		local v740 = os.clock() - v_u_739
		local v741 = v740 / p_u_736
		local v742 = math.clamp(v741, 0, 1)
		local v743 = (p_u_735 - 1.5) * (1 - (1 - v742) ^ 2) + 1.5
		for v744, v745 in v_u_737 do
			local v746 = v740 * 9 + v744 / 3 * 3.141592653589793 * 2
			local v747 = p_u_734
			local v748 = v747.X
			local v749 = v_u_18 + 2.4
			local v750 = v747.Z
			local v751 = Vector3.new(v748, v749, v750)
			local v752 = math.cos(v746) * v743
			local v753 = math.sin(v746) * v743
			local v754 = v751 + Vector3.new(v752, 0, v753)
			v745.core.CFrame = CFrame.new(v754)
			v745.rim.CFrame = CFrame.new(v754)
		end
		if v742 < 1 then
			return true
		end
		for _, v755 in v_u_737 do
			local v756 = v755.core
			v_u_8.tween(v756, 0.15, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v756, 0.2)
			local v757 = v755.rim
			v_u_8.tween(v757, 0.15, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v757, 0.2)
		end
		return false
	end
	local v759 = v_u_67
	table.insert(v759, v758)
end
v_u_551.genjutsu = {
	["cast"] = function(p761) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_40
		v_u_575(p761, v_u_40, true)
	end,
	["windup"] = function(p762, p763, p764) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_40, (copy) v_u_15, (copy) v_u_760
		local v765 = p762.ability.radius
		local v766 = v_u_247
		local v767 = CFrame.new
		local v768 = p763.X
		local v769 = v_u_18 + 0.18
		local v770 = p763.Z
		v766(v767((Vector3.new(v768, v769, v770))), v765 * 0.7, v_u_40, v_u_15.MagicCircle, p764 + 0.9, 3.5)
		v_u_760(p763, v765 * 0.45, p764 + 0.3)
	end,
	["land"] = function(p771, p772) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_40, (copy) v_u_8, (copy) v_u_15, (copy) v_u_34, (copy) v_u_220, (copy) v_u_10
		local v773 = p771.ability.radius
		local v774 = p772.X
		local v775 = v_u_18 + 0.2
		local v776 = p772.Z
		local v777 = Vector3.new(v774, v775, v776)
		v_u_117("Shockwave", v777 + Vector3.new(0, 0.3, 0), v_u_40, v773 / 20)
		v_u_8.ring(v777, v_u_40, v773, 0.5, v_u_15.Ring)
		v_u_8.ring(v777, v_u_34, v773 * 0.75, 0.4)
		v_u_220(p772, v773, v_u_40, 0.45)
		v_u_117("Flash", p772 + Vector3.new(0, 3, 0), v_u_40, 0.5)
		v_u_10.play("Burst", {
			["at"] = v777
		})
		if p771.mine then
			v_u_8.shake(0.25, 0.3)
		end
	end,
	["hit"] = function(p778, p779, p780) -- name: hit
		-- upvalues: (copy) v_u_600, (copy) v_u_40, (copy) v_u_34
		v_u_600(p778, p779, p780, v_u_40, v_u_34)
	end
}
local function v783(p781, p782, _) -- name: blackHit
	-- upvalues: (copy) v_u_117, (copy) v_u_41
	v_u_117("Impact", p782, v_u_41, 0.6)
	if not p781.lite then
		v_u_117("FireDark", p782 - Vector3.new(0, 1.5, 0), nil, 0.3)
	end
end
v_u_551.black_spark = {
	["cast"] = function(p784) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_41, (copy) v_u_117
		v_u_557(p784, v_u_41)
		if not p784.lite then
			v_u_117("FireDark", p784.eye + p784.dir, nil, 0.22)
		end
	end,
	["shot"] = function(p785, p786) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_34, (copy) v_u_41, (copy) v_u_42
		return v_u_514(p785, p786, {
			["core"] = nil,
			["coreMaterial"] = nil,
			["coreSize"] = 1.8,
			["shell"] = nil,
			["shellSize"] = 2.6,
			["shellAlpha"] = 0.7,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.9,
			["loop"] = "FireDark",
			["loopScale"] = 0.3,
			["core"] = v_u_34,
			["coreMaterial"] = Enum.Material.SmoothPlastic,
			["shell"] = v_u_41,
			["trail"] = v_u_41,
			["trailEnd"] = v_u_42
		})
	end,
	["impact"] = function(p787, p788) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_41, (copy) v_u_209, (copy) v_u_34, (copy) v_u_8, (copy) v_u_18, (copy) v_u_265, (copy) v_u_10
		local v789 = p787.size
		v_u_117("Impact", p788, v_u_41, 1 * v789)
		v_u_209(p788, v_u_34, 2 * v789, 5 * v789, 0.22, 0.1, Enum.Material.SmoothPlastic)
		v_u_8.flash(p788, v_u_41, 5 * v789, 0.16)
		if not p787.lite then
			local v790 = v_u_117
			local v791 = p788.X
			local v792 = v_u_18 + 0.2
			local v793 = p788.Z
			v790("FireDark", Vector3.new(v791, v792, v793), nil, 0.5 * v789)
		end
		local v794 = v_u_8.ring
		local v795 = p788.X
		local v796 = v_u_18 + 0.2
		local v797 = p788.Z
		v794(Vector3.new(v795, v796, v797), v_u_41, 3.5 * v789, 0.3)
		v_u_265(p788, v_u_34, 2.6 * v789, 1.3)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p788
		})
	end,
	["hit"] = v783
}
v_u_551.amaterasu = {
	["loopSound"] = "Flames",
	["castSound"] = "Fireball",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["hit"] = nil,
	["cast"] = function(p798) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_41, (copy) v_u_117
		v_u_575(p798, v_u_41)
		v_u_117("FireDark", p798.eye, nil, 0.3)
	end,
	["windup"] = function(p799, p800, p801) -- name: windup
		-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_41, (copy) v_u_15, (copy) v_u_209
		local v802 = v_u_8.ring
		local v803 = p800.X
		local v804 = v_u_18 + 0.2
		local v805 = p800.Z
		v802(Vector3.new(v803, v804, v805), v_u_41, p799.ability.radius, p801 + 0.15, v_u_15.Ring)
		local v806 = v_u_209
		local v807 = p800.X
		local v808 = v_u_18 + 1
		local v809 = p800.Z
		v806(Vector3.new(v807, v808, v809), v_u_41, 1, 4, p801 + 0.1, 0.3)
	end,
	["zone"] = function(p810, p811, p812) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_705, (copy) v_u_34, (copy) v_u_41, (copy) v_u_200, (copy) v_u_180, (copy) v_u_117, (copy) v_u_10, (copy) v_u_405, (copy) v_u_42, (copy) v_u_8, (copy) v_u_190, (copy) v_u_247, (copy) v_u_15, (copy) v_u_139, (copy) v_u_1
		local v813 = p810.ability.radius
		local v814 = p811.X
		local v815 = v_u_18 + 0.2
		local v816 = p811.Z
		local v817 = Vector3.new(v814, v815, v816)
		v_u_705(p811, v813 * 0.8, p810.lite and 4 or 8, 9, v_u_34, v_u_41, p812 - 0.2, false, 0.82)
		v_u_200(v_u_180(v817, 18, v813 * 1.05, v_u_41, 0.5), 0.35)
		v_u_117("Explosion", p811 + Vector3.new(0, 1, 0), Color3.fromRGB(50, 0, 20), v813 / 7)
		v_u_117("Shockwave", v817 + Vector3.new(0, 0.3, 0), v_u_41, v813 / 18)
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.6,
			["at"] = v817
		})
		if not p810.lite then
			local v818 = { v_u_34, v_u_42 }
			v_u_405(v817 + Vector3.new(0, 1, 0), v818, 6, 26, 0.8, 0.8)
		end
		if p810.mine then
			v_u_8.shake(0.18, 0.2)
		end
		local v819 = v_u_190
		local v820 = p811.X
		local v821 = v_u_18 + 0.07
		local v822 = p811.Z
		local v_u_823 = v819(Vector3.new(v820, v821, v822), v813, v_u_34, 0.3, Enum.Material.SmoothPlastic)
		local v824 = v_u_247
		local v825 = CFrame.new
		local v826 = p811.X
		local v827 = v_u_18 + 0.13
		local v828 = p811.Z
		v824(v825((Vector3.new(v826, v827, v828))), v813 * 1.05, v_u_41, v_u_15.Ring, p812, 0.4)
		local v_u_829 = { (v_u_139("FireDark", v817, nil, v813 / 6)) }
		local v830 = p810.lite and 0 or 2
		for v831 = 1, v830 do
			local v832 = v831 / v830 * 3.141592653589793 * 2
			local v833 = v_u_139
			local v834 = math.cos(v832) * v813 * 0.6
			local v835 = math.sin(v832) * v813 * 0.6
			local v836 = v833("FireDark", v817 + Vector3.new(v834, 0, v835), nil, v813 / 11)
			table.insert(v_u_829, v836)
		end
		return function()
			-- upvalues: (copy) v_u_829, (ref) v_u_8, (copy) v_u_823, (ref) v_u_1
			for _, v837 in v_u_829 do
				v837()
			end
			v_u_8.tween(v_u_823, 0.6, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v_u_823, 0.65)
		end
	end,
	["hit"] = v783
}
local v922 = {
	["loopSound"] = "Vortex",
	["castSound"] = "Burst",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["finish"] = nil,
	["hit"] = nil,
	["cast"] = function(p838) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_41, (copy) v_u_247, (copy) v_u_15
		v_u_575(p838, v_u_41, true)
		local v839 = v_u_247
		local v840 = p838.eye + p838.dir * 1.3
		local v841 = p838.dir
		local v842 = v841.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v841.Unit
		local v843 = v842.Y
		local v844 = math.abs(v843) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v839(CFrame.lookAt(v840, v840 + v842, v844) * CFrame.Angles(-1.5707963267948966, 0, 0), 1.5, v_u_41, v_u_15.Swirl, 0.25, 12)
	end,
	["windup"] = function(p845, p846, p847) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_41, (copy) v_u_15, (copy) v_u_209, (copy) v_u_33
		local v848 = v_u_247
		local v849 = CFrame.new
		local v850 = p846.X
		local v851 = v_u_18 + 0.15
		local v852 = p846.Z
		v848(v849((Vector3.new(v850, v851, v852))), p845.ability.radius * 0.5, v_u_41, v_u_15.Swirl, p847 + 0.1, -8)
		v_u_209(p846 + Vector3.new(0, 4, 0), v_u_33, 0.5, 4, p847 + 0.1, 0.2)
	end,
	["zone"] = function(p853, p854, p_u_855) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_247, (copy) v_u_15, (copy) v_u_139, (copy) v_u_41, (copy) v_u_6, (copy) v_u_34, (copy) v_u_8, (copy) v_u_1, (ref) v_u_67, (copy) v_u_152, (copy) v_u_117, (copy) v_u_342
		local v_u_856 = p853.ability.radius
		local v857 = p854.X
		local v858 = v_u_18 + 4.5
		local v859 = p854.Z
		local v_u_860 = Vector3.new(v857, v858, v859)
		local v861 = v_u_247
		local v862 = CFrame.new
		local v863 = p854.X
		local v864 = v_u_18 + 0.15
		local v865 = p854.Z
		v861(v862((Vector3.new(v863, v864, v865))), v_u_856, Color3.fromRGB(150, 15, 40), v_u_15.Swirl, p_u_855, -5)
		local v_u_866 = { (v_u_139("Vortex", v_u_860, v_u_41, v_u_856 / 8)) }
		local v867 = v_u_6.CurrentCamera
		local v868 = not v867 and Vector3.new(0, 0, 1) or (v867.CFrame.Position - v_u_860).Unit
		local v869 = v_u_247
		local v870 = v_u_860 - v868 * 1.5
		local v871 = v868.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v868.Unit
		local v872 = v871.Y
		local v873 = math.abs(v872) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v869(CFrame.lookAt(v870, v870 + v871, v873) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_856 * 0.75, v_u_41, v_u_15.Swirl, p_u_855, -5)
		local v874 = v_u_247
		local v875 = v_u_860 - v868 * 1.3
		local v876 = v868.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v868.Unit
		local v877 = v876.Y
		local v878 = math.abs(v877) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v874(CFrame.lookAt(v875, v875 + v876, v878) * CFrame.Angles(-1.5707963267948966, 0, 0), v_u_856 * 0.45, v_u_34, v_u_15.Swirl, p_u_855, 9)
		local v879 = v868.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v868.Unit
		local v880 = v879.Y
		local v881 = math.abs(v880) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v_u_882 = CFrame.lookAt(v_u_860, v_u_860 + v879, v881) * CFrame.Angles(-1.5707963267948966, 0, 0)
		local v_u_883 = p853.lite and 4 or 8
		local v_u_884 = {}
		for v885 = 1, v_u_883 do
			local v886 = v_u_8.part
			local v887 = Vector3.new(0.6, 0.6, 1.8)
			local v888
			if v885 % 2 == 0 then
				v888 = v_u_41
			else
				v888 = v_u_34
			end
			local v889 = {}
			local v890
			if v885 % 2 == 0 then
				v890 = Enum.Material.Neon
			else
				v890 = Enum.Material.SmoothPlastic
			end
			v889.material = v890
			local v891 = v886(v887, v_u_882, v888, v889)
			v_u_1:AddItem(v891, p_u_855 + 1)
			table.insert(v_u_884, v891)
		end
		local v_u_892 = os.clock()
		local v893 = v_u_67
		table.insert(v893, function()
			-- upvalues: (copy) v_u_892, (copy) v_u_884, (copy) v_u_883, (copy) v_u_856, (copy) v_u_882, (copy) p_u_855
			local v894 = os.clock() - v_u_892
			for v895, v896 in v_u_884 do
				if not v896.Parent then
					return false
				end
				local v897 = (v894 * 1.6 + v895 / v_u_883) % 1
				local v898 = v_u_856 * 0.7 * (1 - v897) + 0.5
				local v899 = v895 / v_u_883 * 3.141592653589793 * 2 + v894 * 5 + v897 * 3
				v896.CFrame = v_u_882 * CFrame.new(math.cos(v899) * v898, 0, math.sin(v899) * v898) * CFrame.Angles(0, -v899, 0)
				local v900 = v897 - 0.7
				v896.Transparency = math.max(0, v900) / 0.3
			end
			return v894 < p_u_855 + 0.5
		end)
		local v_u_901 = v_u_152(v_u_860, v_u_34, 1.5, 0, Enum.Material.SmoothPlastic)
		local v_u_902 = v_u_152(v_u_860, v_u_41, 2.6, 0.72)
		v_u_8.tween(v_u_901, p_u_855, {
			["Size"] = Vector3.new(5, 5, 5)
		}, Enum.EasingStyle.Linear)
		v_u_8.tween(v_u_902, p_u_855, {
			["Size"] = Vector3.new(7.5, 7.5, 7.5)
		}, Enum.EasingStyle.Linear)
		v_u_117("Flash", v_u_860, v_u_41, 0.5)
		local v_u_903 = true
		if not p853.lite then
			local v_u_904 = os.clock() + p_u_855 + 0.3
			task.spawn(function()
				-- upvalues: (ref) v_u_903, (copy) v_u_904, (ref) v_u_342, (copy) v_u_860, (ref) v_u_41, (copy) v_u_856
				while v_u_903 and os.clock() < v_u_904 do
					v_u_342(v_u_860, v_u_41, 3, v_u_856 * 1.1, 0.35)
					task.wait(0.12)
				end
			end)
		end
		return function()
			-- upvalues: (ref) v_u_903, (copy) v_u_866, (ref) v_u_8, (copy) v_u_901, (copy) v_u_902, (ref) v_u_1, (copy) v_u_884
			v_u_903 = false
			for _, v905 in v_u_866 do
				v905()
			end
			v_u_8.tween(v_u_901, 0.12, {
				["Size"] = Vector3.new(0.2, 0.2, 0.2)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_8.tween(v_u_902, 0.12, {
				["Size"] = Vector3.new(0.2, 0.2, 0.2),
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v_u_901, 0.13)
			v_u_1:AddItem(v_u_902, 0.13)
			for _, v906 in v_u_884 do
				v906:Destroy()
			end
		end
	end,
	["finish"] = function(p907, p908) -- name: finish
		-- upvalues: (copy) v_u_18, (copy) v_u_209, (copy) v_u_33, (copy) v_u_117, (copy) v_u_41, (copy) v_u_8, (copy) v_u_315, (copy) v_u_10
		local v909 = p907.ability.radius
		local v910 = p908.X
		local v911 = v_u_18 + 4
		local v912 = p908.Z
		local v913 = Vector3.new(v910, v911, v912)
		v_u_209(v913, v_u_33, 2, v909 * 1.2, 0.25, 0.1)
		v_u_117("Explosion", v913, v_u_41, v909 / 6)
		local v914 = v_u_117
		local v915 = p908.X
		local v916 = v_u_18 + 0.5
		local v917 = p908.Z
		v914("Shockwave", Vector3.new(v915, v916, v917), v_u_41, v909 / 18)
		local v918 = v_u_8.ring
		local v919 = p908.X
		local v920 = v_u_18 + 0.2
		local v921 = p908.Z
		v918(Vector3.new(v919, v920, v921), v_u_41, v909 * 1.3, 0.45)
		v_u_315(v913, v_u_41, 8, v909, 0.3)
		v_u_10.play("Explosion", {
			["at"] = v913
		})
		if p907.mine then
			v_u_8.shake(0.4, 0.35)
		end
	end
}
local v_u_923 = 0.6
function v922.hit(_, p924, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_41, (copy) v_u_923
	v_u_117("Impact", p924, v_u_41, v_u_923)
end
v_u_551.kamui = v922
v_u_551.geass_ray = {
	["cast"] = function(p925) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_43, (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15
		v_u_557(p925, v_u_43, 0.8)
		if not p925.lite then
			local v926 = v_u_247
			local v927 = p925.eye + p925.dir * 0.9
			local v928 = p925.dir
			local v929 = v928.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v928.Unit
			local v930 = v929.Y
			local v931 = math.abs(v930) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			v926(CFrame.lookAt(v927, v927 + v929, v931) * CFrame.Angles(-1.5707963267948966, 0, 0), 1.1 * p925.size, v_u_33, v_u_14.Iris.geass or v_u_15.MagicCircle, 0.08, 0)
		end
	end,
	["beam"] = function(p932, p933, p934) -- name: beam
		-- upvalues: (copy) v_u_200, (copy) v_u_168, (copy) v_u_44, (copy) v_u_43, (copy) v_u_8
		local v935 = p932.size
		v_u_200(v_u_168(p933, p934, 0.45 * v935, v_u_44), 0.16)
		v_u_200(v_u_168(p933, p934, 1.3 * v935, v_u_43, 0.45), 0.14)
		if not p932.lite then
			local v936 = v_u_43
			local v937 = 2.6 * v935
			local v938 = v_u_8.beam(p933, p934, v936, v937, 0.16, nil)
			v938.LightEmission = 0.55
			v938.Brightness = 1.6
		end
		v_u_8.flash(p933, v_u_43, 3 * v935, 0.12)
	end,
	["hit"] = function(p939, p940, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_43, (copy) v_u_359, (copy) v_u_44, (copy) v_u_10
		v_u_117("Impact", p940, v_u_43, 0.7)
		v_u_359(p940, v_u_44, 3, 0.14)
		if not p939.struck then
			p939.struck = true
			v_u_10.play("Orb", {
				["at"] = nil,
				["volume"] = 0.3,
				["at"] = p940
			})
		end
	end
}
v_u_551.geass_kneel = {
	["cast"] = function(p941) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_43, (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15
		v_u_575(p941, v_u_43)
		local v942 = v_u_247
		local v943 = p941.eye + p941.dir * 1.6
		local v944 = p941.dir
		local v945 = v944.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v944.Unit
		local v946 = v945.Y
		local v947 = math.abs(v946) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v942(CFrame.lookAt(v943, v943 + v945, v947) * CFrame.Angles(-1.5707963267948966, 0, 0), 2.6 * p941.size, v_u_33, v_u_14.Iris.geass or v_u_15.MagicCircle, 0.3, 0)
	end,
	["windup"] = function(p948, p949, p950) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_43, (copy) v_u_15
		local v951 = v_u_247
		local v952 = CFrame.new
		local v953 = p949.X
		local v954 = v_u_18 + 0.18
		local v955 = p949.Z
		v951(v952((Vector3.new(v953, v954, v955))), p948.ability.radius * 0.55, v_u_43, v_u_15.MagicCircle, p950 + 0.7, 1.5)
	end,
	["land"] = function(p956, p957) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_43, (copy) v_u_8, (copy) v_u_15, (copy) v_u_44, (copy) v_u_220, (copy) v_u_10
		local v958 = p956.ability.radius
		local v959 = p957.X
		local v960 = v_u_18 + 0.2
		local v961 = p957.Z
		local v962 = Vector3.new(v959, v960, v961)
		v_u_117("Shockwave", v962 + Vector3.new(0, 0.3, 0), v_u_43, v958 / 20)
		v_u_8.ring(v962, v_u_43, v958, 0.45, v_u_15.Ring)
		v_u_8.ring(v962, v_u_44, v958 * 0.85, 0.35, v_u_15.SpeedLines)
		v_u_220(p957, v958, v_u_43, 0.4)
		v_u_10.play("Burst", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v962
		})
		if p956.mine then
			v_u_8.shake(0.2, 0.25)
		end
	end,
	["hit"] = function(p963, p964, p965) -- name: hit
		-- upvalues: (copy) v_u_247, (copy) v_u_43, (copy) v_u_15, (copy) v_u_8, (copy) v_u_18, (copy) v_u_600, (copy) v_u_44
		local v966 = v_u_247(CFrame.new(p964 + Vector3.new(0, 3.5, 0)), 2.4, v_u_43, v_u_15.Ring, 0.22, 0)
		local v967 = v_u_8.tween
		local v968 = {}
		local v969 = CFrame.new
		local v970 = p964.X
		local v971 = v_u_18 + 0.25
		local v972 = p964.Z
		v968.CFrame = v969((Vector3.new(v970, v971, v972)))
		v967(v966, 0.18, v968, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_600(p963, p964, p965, v_u_43, v_u_44)
	end
}
v_u_551.geass_perish = {
	["cast"] = function(p973) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_43
		v_u_575(p973, v_u_43, true)
	end,
	["windup"] = function(p974, p975, p976) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15, (copy) v_u_43, (copy) v_u_8, (copy) v_u_180, (copy) v_u_1
		local v977 = p974.ability.radius
		local v978 = p975.X
		local v979 = v_u_18 + 16
		local v980 = p975.Z
		local v981 = Vector3.new(v978, v979, v980)
		local v982 = v_u_6.CurrentCamera
		local v983 = not v982 and Vector3.new(-0, -1, -0) or (v982.CFrame.Position - v981).Unit
		local v984 = v_u_247
		local v985 = v983.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v983.Unit
		local v986 = v985.Y
		local v987 = math.abs(v986) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v984(CFrame.lookAt(v981, v981 + v985, v987) * CFrame.Angles(-1.5707963267948966, 0, 0), v977 * 0.45, v_u_33, v_u_14.Iris.geass or v_u_15.MagicCircle, p976 + 0.3, 0)
		local v988 = v_u_247
		local v989 = v981 - v983 * 0.3
		local v990 = v983.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v983.Unit
		local v991 = v990.Y
		local v992 = math.abs(v991) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v988(CFrame.lookAt(v989, v989 + v990, v992) * CFrame.Angles(-1.5707963267948966, 0, 0), v977 * 0.62, v_u_43, v_u_15.Ring, p976 + 0.3, -3)
		local v993 = v_u_8.ring
		local v994 = p975.X
		local v995 = v_u_18 + 0.2
		local v996 = p975.Z
		v993(Vector3.new(v994, v995, v996), v_u_43, v977, p976 + 0.1, v_u_15.Ring)
		local v997 = v_u_180
		local v998 = p975.X
		local v999 = v_u_18 + 0.2
		local v1000 = p975.Z
		v_u_1:AddItem(v997(Vector3.new(v998, v999, v1000), 16, 0.6, v_u_43, 0.5), p976 + 0.02)
	end,
	["land"] = function(p1001, p1002) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_200, (copy) v_u_180, (copy) v_u_43, (copy) v_u_33, (copy) v_u_117, (copy) v_u_8, (copy) v_u_15, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_34, (copy) v_u_10
		local v1003 = p1001.ability.radius
		local v1004 = p1002.X
		local v1005 = v_u_18 + 0.2
		local v1006 = p1002.Z
		local v1007 = Vector3.new(v1004, v1005, v1006)
		v_u_200(v_u_180(v1007, 40, v1003 * 0.9, v_u_43, 0.2), 0.4, true)
		v_u_200(v_u_180(v1007, 40, v1003 * 0.4, v_u_33, 0), 0.3, true)
		v_u_117("Explosion", p1002 + Vector3.new(0, 2, 0), v_u_43, v1003 / 7)
		v_u_117("Shockwave", v1007 + Vector3.new(0, 0.3, 0), v_u_43, v1003 / 18)
		v_u_8.ring(v1007, v_u_43, v1003, 0.5)
		v_u_8.ring(v1007, v_u_33, v1003 * 0.6, 0.3, v_u_15.Ring)
		v_u_405(v1007 + Vector3.new(0, 1, 0), { v_u_36[1], v_u_36[2], v_u_43 }, p1001.lite and 4 or 9, 32, 1.1, 0.9)
		v_u_265(p1002, Color3.fromRGB(80, 0, 30), v1003 * 0.6, 1.6)
		v_u_265(p1002, v_u_34, v1003 * 0.8, 1.6, v_u_15.CrackLines, 0.1)
		v_u_10.play("Explosion", {
			["at"] = v1007
		})
		if p1001.mine then
			v_u_8.shake(0.4, 0.35)
		end
	end,
	["hit"] = function(_, p1008, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_43, (copy) v_u_359, (copy) v_u_33
		v_u_117("Impact", p1008, v_u_43, 0.9)
		v_u_359(p1008, v_u_33, 4)
	end
}
local function v1011(p1009, p1010, _) -- name: violetHit
	-- upvalues: (copy) v_u_117, (copy) v_u_45
	v_u_117("Impact", p1010, v_u_45, 0.7)
	if not p1009.lite then
		v_u_117("Fire", p1010 - Vector3.new(0, 1.5, 0), v_u_45, 0.3)
	end
end
v_u_551.blaze_arrow = {
	["cast"] = function(p1012) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_45
		v_u_557(p1012, v_u_45)
	end,
	["shot"] = function(p1013, p1014) -- name: blazeArrow
		-- upvalues: (copy) v_u_539, (copy) v_u_46, (copy) v_u_33, (copy) v_u_45, (copy) v_u_47
		return v_u_539(p1013, p1014, {
			["shaft"] = nil,
			["head"] = nil,
			["glow"] = nil,
			["length"] = 4.8,
			["thick"] = 0.42,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.6,
			["loop"] = "Fire",
			["loopColor"] = nil,
			["shaft"] = v_u_46,
			["head"] = v_u_33,
			["glow"] = v_u_45,
			["trail"] = v_u_45,
			["trailEnd"] = v_u_47,
			["loopColor"] = v_u_45
		})
	end,
	["impact"] = function(p1015, p1016) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_45, (copy) v_u_8, (copy) v_u_18, (copy) v_u_315, (copy) v_u_46, (copy) v_u_265, (copy) v_u_10
		local v1017 = p1015.size
		v_u_117("Impact", p1016, v_u_45, 1 * v1017)
		v_u_8.flash(p1016, v_u_45, 5.5 * v1017, 0.18)
		if not p1015.lite then
			local v1018 = v_u_117
			local v1019 = p1016.X
			local v1020 = v_u_18 + 0.2
			local v1021 = p1016.Z
			v1018("Fire", Vector3.new(v1019, v1020, v1021), v_u_45, 0.5 * v1017)
			v_u_315(p1016, v_u_46, 4, 4, 0.16, p1015.dir, 0.8)
		end
		v_u_265(p1016, Color3.fromRGB(50, 25, 90), 2.3 * v1017, 0.9)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p1016
		})
	end,
	["hit"] = v1011
}
v_u_551.blaze_release = {
	["loopSound"] = "Flames",
	["castSound"] = "Fireball",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["hit"] = nil,
	["cast"] = function(p1022) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_45
		v_u_575(p1022, v_u_45)
	end,
	["windup"] = function(p1023, p1024, p1025) -- name: windup
		-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_45, (copy) v_u_15
		local v1026 = v_u_8.ring
		local v1027 = p1024.X
		local v1028 = v_u_18 + 0.2
		local v1029 = p1024.Z
		v1026(Vector3.new(v1027, v1028, v1029), v_u_45, p1023.ability.radius, p1025 + 0.15, v_u_15.Ring)
	end,
	["zone"] = function(p1030, p1031, p1032) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_200, (copy) v_u_180, (copy) v_u_45, (copy) v_u_117, (copy) v_u_10, (copy) v_u_8, (copy) v_u_190, (copy) v_u_247, (copy) v_u_15, (copy) v_u_139, (copy) v_u_705, (copy) v_u_34, (copy) v_u_46, (copy) v_u_1
		local v1033 = p1030.ability.radius
		local v1034 = p1031.X
		local v1035 = v_u_18 + 0.2
		local v1036 = p1031.Z
		local v1037 = Vector3.new(v1034, v1035, v1036)
		v_u_200(v_u_180(v1037, 14, v1033 * 0.7, v_u_45, 0.3), 0.35)
		v_u_117("Explosion", p1031 + Vector3.new(0, 1, 0), v_u_45, v1033 / 7)
		v_u_117("Shockwave", v1037 + Vector3.new(0, 0.3, 0), v_u_45, v1033 / 18)
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.6,
			["at"] = v1037
		})
		if p1030.mine then
			v_u_8.shake(0.18, 0.2)
		end
		local v1038 = v_u_190
		local v1039 = p1031.X
		local v1040 = v_u_18 + 0.07
		local v1041 = p1031.Z
		local v_u_1042 = v1038(Vector3.new(v1039, v1040, v1041), v1033, Color3.fromRGB(45, 20, 85), 0.35, Enum.Material.SmoothPlastic)
		local v1043 = v_u_247
		local v1044 = CFrame.new
		local v1045 = p1031.X
		local v1046 = v_u_18 + 0.13
		local v1047 = p1031.Z
		v1043(v1044((Vector3.new(v1045, v1046, v1047))), v1033 * 1.02, v_u_45, v_u_15.Ring, p1032, 0.5)
		local v_u_1048 = { v_u_139("FireDark", v1037, nil, v1033 / 7), (v_u_139("Fire", v1037, v_u_45, v1033 / 9)) }
		v_u_705(p1031, v1033 * 0.85, p1030.lite and 6 or 11, 7, Color3.fromRGB(40, 12, 75), v_u_45, p1032 - 0.2, true)
		v_u_705(p1031, v1033 * 0.3, p1030.lite and 2 or 4, 6, v_u_34, v_u_46, p1032 - 0.2, false)
		return function()
			-- upvalues: (copy) v_u_1048, (copy) v_u_1042, (ref) v_u_8, (ref) v_u_1
			for _, v1049 in v_u_1048 do
				v1049()
			end
			local v1050 = v_u_1042
			v_u_8.tween(v1050, 0.5, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v1050, 0.55)
		end
	end,
	["hit"] = v1011
}
local function v_u_1070(p1051, p1052, p1053) -- name: bow
	-- upvalues: (copy) v_u_168, (copy) v_u_45, (copy) v_u_46, (copy) v_u_33, (copy) v_u_200
	local v1054 = p1051.size
	local v1055 = p1051.dir
	local v1056 = p1052 + v1055 * 2.2
	local v1057 = 4.6 * v1054
	local v1058 = {}
	for v1059 = -4, 4 do
		local v1060 = v1059 / 4 * 1.1868238913561442
		local v1061 = v1056 + Vector3.new(0, 1, 0) * math.sin(v1060) * v1057 - v1055 * (1 - math.cos(v1060)) * v1057 * 0.7
		table.insert(v1058, v1061)
	end
	local v_u_1062 = {}
	for v1063 = 2, #v1058 do
		local v1064 = v_u_168(v1058[v1063 - 1], v1058[v1063], 0.75 * v1054, v_u_45)
		table.insert(v_u_1062, v1064)
	end
	local v1065 = v1056 - v1055 * 1.8 * v1054
	local v1066 = v_u_168(v1058[1], v1065, 0.15 * v1054, v_u_46)
	table.insert(v_u_1062, v1066)
	local v1067 = v_u_168(v1058[#v1058], v1065, 0.15 * v1054, v_u_46)
	table.insert(v_u_1062, v1067)
	local v1068 = v_u_168(v1065, v1056 + v1055 * 2.4 * v1054, 0.4 * v1054, v_u_33)
	table.insert(v_u_1062, v1068)
	task.delay(p1053, function()
		-- upvalues: (copy) v_u_1062, (ref) v_u_200
		for _, v1069 in v_u_1062 do
			v_u_200(v1069, 0.15)
		end
	end)
end
v_u_551.susanoo_arrow = {
	["cast"] = function(p1071) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_45
		v_u_575(p1071, v_u_45, true)
	end,
	["windup"] = function(p1072, p1073, p1074) -- name: windup
		-- upvalues: (copy) v_u_1070, (copy) v_u_139, (copy) v_u_45
		v_u_1070(p1072, p1073, p1074 + 0.08)
		if p1074 > 0.05 then
			local v1075 = v_u_139("Charge", p1073 + p1072.dir * 2, v_u_45, 0.8)
			task.delay(p1074, v1075)
		end
	end,
	["beam"] = function(p1076, p_u_1077, p_u_1078) -- name: beam
		-- upvalues: (copy) v_u_539, (copy) v_u_46, (copy) v_u_33, (copy) v_u_45, (copy) v_u_47, (ref) v_u_67, (copy) v_u_200, (copy) v_u_168, (copy) v_u_15, (copy) v_u_8, (copy) v_u_292, (copy) v_u_450, (copy) v_u_117, (copy) v_u_18, (copy) v_u_10
		local v1079 = p1076.size
		local v1080 = v_u_539
		local v1081 = p_u_1078 - p_u_1077
		local v1082 = v1081.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1081.Unit
		local v1083 = v1082.Y
		local v1084 = math.abs(v1083) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v1085 = {
			["shaft"] = nil,
			["head"] = nil,
			["glow"] = nil,
			["length"] = 10,
			["thick"] = 1.1,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 5,
			["shaft"] = v_u_46,
			["head"] = v_u_33,
			["glow"] = v_u_45,
			["trail"] = v_u_45,
			["trailEnd"] = v_u_47
		}
		local v_u_1086 = v1080(p1076, CFrame.lookAt(p_u_1077, p_u_1077 + v1082, v1084), v1085)
		local v_u_1087 = os.clock()
		local function v_u_1095(p1088)
			-- upvalues: (copy) v_u_1086, (copy) p_u_1077, (copy) p_u_1078, (copy) v_u_1087
			local v1089 = v_u_1086.place
			local v1090 = p_u_1077:Lerp(p_u_1078, p1088)
			local v1091 = p_u_1078 - p_u_1077
			local v1092 = v1091.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1091.Unit
			local v1093 = v1092.Y
			local v1094 = math.abs(v1093) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			v1089(CFrame.lookAt(v1090, v1090 + v1092, v1094), os.clock() - v_u_1087)
			if p1088 >= 1 then
				v_u_1086.stop()
			end
		end
		local v_u_1096 = os.clock() - 0
		local v1097 = v_u_1086.place
		local v1098 = p_u_1077:Lerp(p_u_1078, 0)
		local v1099 = p_u_1078 - p_u_1077
		local v1100 = v1099.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1099.Unit
		local v1101 = v1100.Y
		local v1102 = math.abs(v1101) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v1097(CFrame.lookAt(v1098, v1098 + v1100, v1102), os.clock() - v_u_1087)
		local v_u_1103 = 0.14
		local v1104 = v_u_67
		table.insert(v1104, function()
			-- upvalues: (copy) v_u_1096, (copy) v_u_1103, (copy) v_u_1095
			local v1105 = (os.clock() - v_u_1096) / v_u_1103
			local v1106 = math.clamp(v1105, 0, 1)
			v_u_1095(v1106)
			return v1106 < 1
		end)
		v_u_200(v_u_168(p_u_1077, p_u_1078, 2.2 * v1079, v_u_33), 0.45, true)
		v_u_200(v_u_168(p_u_1077, p_u_1078, 6.5 * v1079, v_u_45, 0.45), 0.55, true)
		local v1107 = v_u_45
		local v1108 = 12 * v1079
		local v1109 = v_u_15.FireBeam
		local v1110 = v_u_8.beam(p_u_1077, p_u_1078, v1107, v1108, 0.6, v1109)
		v1110.LightEmission = 0.55
		v1110.Brightness = 1.6
		v_u_292(p_u_1077, p_u_1078, 4 * v1079, Color3.fromRGB(50, 25, 95), 1.4, 0.3)
		v_u_450(p_u_1077, p_u_1078, 14, 0.14, function(p1111)
			-- upvalues: (ref) v_u_117, (ref) v_u_45
			v_u_117("Impact", p1111, v_u_45, 1.6)
		end)
		task.delay(0.14, function()
			-- upvalues: (ref) v_u_117, (copy) p_u_1078, (ref) v_u_45, (ref) v_u_8, (ref) v_u_18, (ref) v_u_10
			v_u_117("Explosion", p_u_1078, v_u_45, 1.6)
			local v1112 = v_u_8.ring
			local v1113 = p_u_1078
			local v1114 = v1113.X
			local v1115 = v_u_18 + 0.2
			local v1116 = v1113.Z
			v1112(Vector3.new(v1114, v1115, v1116), v_u_45, 10, 0.5)
			local v1117 = {
				["at"] = p_u_1078
			}
			v_u_10.play("Explosion", v1117)
		end)
		v_u_117("Flash", p_u_1077 + p1076.dir * 2, v_u_45, 0.6)
		if p1076.mine then
			v_u_8.shake(0.45, 0.4)
		end
	end,
	["hit"] = function(p1118, p1119, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_45
		v_u_117("Impact", p1119, v_u_45, 1.1)
		if not p1118.lite then
			v_u_117("Fire", p1119, v_u_45, 0.4)
		end
	end
}
local v1141 = {
	["keep"] = 0.45,
	["cast"] = nil,
	["shot"] = nil,
	["impact"] = nil,
	["hit"] = nil,
	["cast"] = function(p1120) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_48
		v_u_557(p1120, v_u_48, 0.8)
	end,
	["shot"] = function(p1121, p1122) -- name: rodShot
		-- upvalues: (copy) v_u_8, (copy) v_u_48, (copy) v_u_49, (copy) v_u_461, (copy) v_u_55, (copy) v_u_492
		local v1123 = p1121.size
		local v1124 = 4.4 * v1123
		local v1125 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), p1122, v_u_48, {
			["transparency"] = 1
		})
		local v1126 = v_u_8.part(Vector3.new(0.4, 0.4, v1124) * Vector3.new(v1123, v1123, 1), p1122, v_u_49, {
			["material"] = Enum.Material.Metal
		})
		local v1127 = v_u_8.part(Vector3.new(0.85, 0.85, 0.85) * v1123, p1122, v_u_48, {
			["shape"] = Enum.PartType.Ball
		})
		local v1128 = {
			{
				["p"] = v1126,
				["off"] = CFrame.identity
			},
			{
				["p"] = v1127,
				["off"] = CFrame.new(0, 0, -v1124 / 2)
			}
		}
		for _, v1129 in { -0.5, 0.7 } do
			local v1130 = {
				["p"] = v_u_8.part(Vector3.new(0.75, 0.75, 0.18) * v1123, p1122, v_u_48),
				["off"] = CFrame.new(0, 0, v1129 * v1123)
			}
			table.insert(v1128, v1130)
		end
		v_u_461(v1125, v_u_48, v_u_55, 0.9 * v1123, 0.12)
		if p1121.mine then
			local v1131 = v_u_48
			local v1132 = 8 * v1123
			local v1133 = Instance.new("PointLight")
			v1133.Color = v1131
			v1133.Range = v1132
			v1133.Brightness = 2
			v1133.Shadows = false
			v1133.Parent = v1125
		end
		return v_u_492(v1125, v1128, {}, 0, 0, {}, 0.12, 14)
	end,
	["impact"] = function(p1134, p1135) -- name: impact
		-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_48, (copy) v_u_15, (copy) v_u_117, (copy) v_u_315, (copy) v_u_33, (copy) v_u_10
		local v1136 = p1134.size
		local v1137 = v_u_8.ring
		local v1138 = p1135.X
		local v1139 = v_u_18 + 0.2
		local v1140 = p1135.Z
		v1137(Vector3.new(v1138, v1139, v1140), v_u_48, 4.5 * v1136, 0.35, v_u_15.Ring)
		v_u_117("Impact", p1135, v_u_48, 0.9 * v1136)
		v_u_8.flash(p1135, v_u_48, 4.5 * v1136, 0.16)
		if not p1134.lite then
			v_u_315(p1135, v_u_33, 4, 3.5, 0.14)
		end
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p1135
		})
	end
}
local v_u_1142 = 0.6
function v1141.hit(_, p1143, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_48, (copy) v_u_1142
	v_u_117("Impact", p1143, v_u_48, v_u_1142)
end
v_u_551.rod = v1141
local v1159 = {
	["cast"] = function(p1144) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_48, (copy) v_u_117
		v_u_575(p1144, v_u_48)
		v_u_117("Flash", p1144.eye, v_u_48, 0.35)
	end,
	["windup"] = function(p1145, _, p1146) -- name: windup
		-- upvalues: (copy) v_u_209, (copy) v_u_33
		v_u_209(p1145.origin, v_u_33, 1, 5, p1146 + 0.06, 0.3)
	end,
	["land"] = function(p1147, p1148) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_48, (copy) v_u_8, (copy) v_u_1, (copy) v_u_209, (copy) v_u_33, (copy) v_u_117, (copy) v_u_15, (copy) v_u_315, (copy) v_u_405, (copy) v_u_36, (copy) v_u_10
		local v1149 = p1147.ability.radius
		local v1150 = p1148.X
		local v1151 = v_u_18 + 0.2
		local v1152 = p1148.Z
		local v1153 = Vector3.new(v1150, v1151, v1152)
		local v1154 = p1148.X
		local v1155 = p1147.origin.Y
		local v1156 = p1148.Z
		local v1157 = Vector3.new(v1154, v1155, v1156)
		local v1158 = v_u_152(v1157, v_u_48, 4, 0, Enum.Material.ForceField)
		v_u_8.tween(v1158, 0.42, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(1, 1, 1) * v1149 * 2.2
		}, Enum.EasingStyle.Quart)
		v_u_1:AddItem(v1158, 0.45)
		v_u_209(v1157, v_u_33, 3, 12, 0.22, 0.2)
		v_u_117("Shockwave", v1153 + Vector3.new(0, 0.3, 0), v_u_48, v1149 / 16)
		v_u_8.ring(v1153, v_u_33, v1149 * 1.05, 0.35, v_u_15.SpeedLines)
		v_u_8.ring(v1153, v_u_48, v1149, 0.5)
		v_u_315(v1157, v_u_33, 10, v1149 * 0.8, 0.28, nil, nil, true)
		if not p1147.lite then
			v_u_405(v1153 + Vector3.new(0, 0.6, 0), v_u_36, 10, 40, 1.1, 0.9, false, 0.45)
			v_u_117("Smoke", v1153, nil, 1.3)
		end
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v1153
		})
		if p1147.mine then
			v_u_8.shake(0.45, 0.35)
		end
	end
}
local v_u_1160 = 0.7
function v1159.hit(_, p1161, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_48, (copy) v_u_1160
	v_u_117("Impact", p1161, v_u_48, v_u_1160)
end
v_u_551.shinra = v1159
local v1225 = {
	["loopSound"] = "Vortex",
	["castSound"] = "Burst",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["finish"] = nil,
	["hit"] = nil,
	["cast"] = function(p1162) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_48
		v_u_575(p1162, v_u_48, true)
	end,
	["windup"] = function(p1163, p1164, p1165) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_34, (copy) v_u_48, (copy) v_u_461, (copy) v_u_55, (copy) v_u_1, (ref) v_u_67
		local v1166 = p1164.X
		local v1167 = v_u_18 + 13
		local v1168 = p1164.Z
		local v_u_1169 = Vector3.new(v1166, v1167, v1168)
		local v_u_1170 = v_u_152(p1163.eye, v_u_34, 1.3, 0, Enum.Material.SmoothPlastic)
		local v_u_1171 = v_u_152(p1163.eye, v_u_48, 2, 0.5)
		v_u_461(v_u_1170, v_u_48, v_u_55, 1, 0.15)
		local v_u_1172 = p1163.eye
		local v1173 = math.max(p1165, 0.05)
		local function v_u_1179(p1174)
			-- upvalues: (copy) v_u_1172, (copy) v_u_1169, (copy) v_u_1170, (copy) v_u_1171, (ref) v_u_1
			local v1175 = v_u_1172:Lerp(v_u_1169, p1174)
			local v1176 = p1174 * 3.141592653589793
			local v1177 = math.sin(v1176) * 4
			local v1178 = v1175 + Vector3.new(0, v1177, 0)
			v_u_1170.CFrame = CFrame.new(v1178)
			v_u_1171.CFrame = CFrame.new(v1178)
			if p1174 >= 1 then
				v_u_1:AddItem(v_u_1170, 0.15)
				v_u_1171:Destroy()
				v_u_1170.Transparency = 1
			end
		end
		local v_u_1180 = math.max(v1173, 0.001)
		local v_u_1181 = os.clock() - 0
		local v1182 = 0 / v_u_1180
		local v1183 = math.clamp(v1182, 0, 1)
		v_u_1179(v1183)
		if v1183 < 1 then
			local v1184 = v_u_67
			table.insert(v1184, function()
				-- upvalues: (copy) v_u_1181, (copy) v_u_1180, (copy) v_u_1179
				local v1185 = (os.clock() - v_u_1181) / v_u_1180
				local v1186 = math.clamp(v1185, 0, 1)
				v_u_1179(v1186)
				return v1186 < 1
			end)
		end
	end,
	["zone"] = function(p1187, p_u_1188, p1189) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_34, (copy) v_u_48, (copy) v_u_8, (copy) v_u_117, (copy) v_u_247, (copy) v_u_15, (copy) v_u_139, (copy) v_u_649, (copy) v_u_36, (copy) v_u_1
		local v1190 = p1187.ability.radius
		local v1191 = p_u_1188.X
		local v1192 = v_u_18 + 13
		local v1193 = p_u_1188.Z
		local v1194 = Vector3.new(v1191, v1192, v1193)
		local v_u_1195 = v_u_152(v1194, v_u_34, 2.5, 0, Enum.Material.SmoothPlastic)
		local v_u_1196 = v_u_152(v1194, v_u_48, 3.8, 0.75)
		v_u_8.tween(v_u_1195, p1189, {
			["Size"] = Vector3.new(6.5, 6.5, 6.5)
		}, Enum.EasingStyle.Linear)
		v_u_8.tween(v_u_1196, p1189, {
			["Size"] = Vector3.new(9, 9, 9)
		}, Enum.EasingStyle.Linear)
		v_u_117("Flash", v1194, v_u_48, 0.6)
		local v1197 = v_u_247
		local v1198 = CFrame.new
		local v1199 = p_u_1188.X
		local v1200 = v_u_18 + 0.14
		local v1201 = p_u_1188.Z
		v1197(v1198((Vector3.new(v1199, v1200, v1201))), v1190, v_u_48, v_u_15.Swirl, p1189, 1.8)
		local v_u_1202 = { (v_u_139("Vortex", v1194, v_u_48, 1.3)) }
		local v_u_1203 = v_u_649(p_u_1188, v1194, v1190, p1187.lite and 6 or 14, v_u_36, p1189, 4.5)
		return function()
			-- upvalues: (copy) v_u_1202, (copy) v_u_1203, (copy) p_u_1188, (ref) v_u_18, (ref) v_u_8, (copy) v_u_1195, (copy) v_u_1196, (ref) v_u_1
			for _, v1204 in v_u_1202 do
				v1204()
			end
			v_u_1203()
			local v1205 = p_u_1188
			local v1206 = v1205.X
			local v1207 = v_u_18 + 2
			local v1208 = v1205.Z
			local v1209 = Vector3.new(v1206, v1207, v1208)
			v_u_8.tween(v_u_1195, 0.12, {
				["CFrame"] = CFrame.new(v1209)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_8.tween(v_u_1196, 0.12, {
				["CFrame"] = nil,
				["Transparency"] = 1,
				["CFrame"] = CFrame.new(v1209)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v_u_1195, 0.13)
			v_u_1:AddItem(v_u_1196, 0.13)
		end
	end,
	["finish"] = function(p1210, p1211) -- name: finish
		-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_48, (copy) v_u_209, (copy) v_u_33, (copy) v_u_8, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_35, (copy) v_u_34, (copy) v_u_15, (copy) v_u_10
		local v1212 = p1210.ability.radius
		local v1213 = p1211.X
		local v1214 = v_u_18 + 0.2
		local v1215 = p1211.Z
		local v1216 = Vector3.new(v1213, v1214, v1215)
		local v1217 = v_u_117
		local v1218 = p1211.X
		local v1219 = v_u_18 + 3
		local v1220 = p1211.Z
		v1217("Explosion", Vector3.new(v1218, v1219, v1220), v_u_48, v1212 / 6)
		v_u_117("Shockwave", v1216 + Vector3.new(0, 0.3, 0), v_u_48, v1212 / 14)
		local v1221 = v_u_209
		local v1222 = p1211.X
		local v1223 = v_u_18 + 3
		local v1224 = p1211.Z
		v1221(Vector3.new(v1222, v1223, v1224), v_u_33, 3, v1212 * 1.1, 0.3, 0.2)
		v_u_8.ring(v1216, v_u_48, v1212 * 1.3, 0.5)
		v_u_405(v1216 + Vector3.new(0, 1, 0), v_u_36, p1210.lite and 5 or 12, 40, 1.4, 1.1)
		v_u_265(p1211, v_u_35, v1212 * 0.7, 2)
		v_u_265(p1211, v_u_34, v1212 * 0.9, 2, v_u_15.CrackLines, 0.1)
		v_u_10.play("Explosion", {
			["at"] = v1216
		})
		if p1210.mine then
			v_u_8.shake(0.55, 0.45)
		end
	end
}
local v_u_1226 = 0.6
function v1225.hit(_, p1227, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_48, (copy) v_u_1226
	v_u_117("Impact", p1227, v_u_48, v_u_1226)
end
v_u_551.chibaku = v1225
v_u_551.jogan_bolt = {
	["cast"] = function(p1228) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_50, (copy) v_u_117
		v_u_557(p1228, v_u_50, 0.8)
		if not p1228.lite then
			v_u_117("Lightning", p1228.eye + p1228.dir, v_u_50, 0.3)
		end
	end,
	["beam"] = function(p1229, p_u_1230, p_u_1231) -- name: beam
		-- upvalues: (copy) v_u_421, (copy) v_u_428, (copy) v_u_33, (copy) v_u_50, (copy) v_u_51, (copy) v_u_8
		local v_u_1232 = p1229.size
		local v1233 = v_u_421(p_u_1230, p_u_1231, 1.2, 7)
		v_u_428(v1233, 0.32 * v_u_1232, v_u_33, 0.12)
		v_u_428(v1233, 0.95 * v_u_1232, v_u_50, 0.15, 0.45)
		if not p1229.lite then
			task.delay(0.05, function()
				-- upvalues: (ref) v_u_428, (ref) v_u_421, (copy) p_u_1230, (copy) p_u_1231, (copy) v_u_1232, (ref) v_u_51
				v_u_428(v_u_421(p_u_1230, p_u_1231, 1.5, 7), 0.35 * v_u_1232, v_u_51, 0.1)
			end)
			local v1234 = v_u_50
			local v1235 = 1.8 * v_u_1232
			local v1236 = v_u_8.beam(p_u_1230, p_u_1231, v1234, v1235, 0.14, nil)
			v1236.LightEmission = 0.55
			v1236.Brightness = 1.6
		end
		v_u_8.flash(p_u_1230, v_u_50, 3, 0.1)
	end,
	["hit"] = function(p1237, p1238, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_50, (copy) v_u_10
		v_u_117("Lightning", p1238, v_u_50, 0.5)
		if not p1237.struck then
			p1237.struck = true
			v_u_10.play("Lightning", {
				["at"] = nil,
				["volume"] = 0.3,
				["at"] = p1238
			})
		end
	end
}
v_u_551.rift = {
	["loopSound"] = "Vortex",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["finish"] = nil,
	["hit"] = nil,
	["cast"] = function(p1239) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_50, (copy) v_u_117
		v_u_575(p1239, v_u_50)
		v_u_117("Lightning", p1239.eye, v_u_50, 0.5)
	end,
	["windup"] = function(_, p1240, p1241) -- name: windup
		-- upvalues: (copy) v_u_428, (copy) v_u_421, (copy) v_u_18, (copy) v_u_33
		local v1242 = v_u_428
		local v1243 = v_u_421
		local v1244 = p1240.X
		local v1245 = v_u_18 + 10.5
		local v1246 = p1240.Z
		local v1247 = Vector3.new(v1244, v1245, v1246)
		local v1248 = p1240.X
		local v1249 = v_u_18 + 0
		local v1250 = p1240.Z
		v1242(v1243(v1247, Vector3.new(v1248, v1249, v1250), 0.8, 2), 0.35, v_u_33, p1241 + 0.15)
	end,
	["zone"] = function(p_u_1251, p_u_1252, p_u_1253) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_8, (copy) v_u_50, (copy) v_u_1, (ref) v_u_67, (copy) v_u_117, (copy) v_u_139, (copy) v_u_247, (copy) v_u_15, (copy) v_u_265, (copy) v_u_428, (copy) v_u_437, (copy) v_u_33, (copy) v_u_421, (copy) v_u_51
		local v_u_1254 = p_u_1251.ability.radius
		local v1255 = p_u_1252.X
		local v1256 = v_u_18 + 5.5
		local v1257 = p_u_1252.Z
		local v_u_1258 = Vector3.new(v1255, v1256, v1257)
		local v1259 = v_u_6.CurrentCamera
		local v1260
		if v1259 then
			v1260 = v1259.CFrame.Position
		else
			v1260 = v_u_1258 + Vector3.new(0, 0, 10)
		end
		local v1261 = CFrame.lookAt
		local v1262 = v1260.X
		local v1263 = v_u_1258.Y
		local v1264 = v1260.Z
		local v1265 = v1261(v_u_1258, (Vector3.new(v1262, v1263, v1264)))
		local v_u_1266 = {}
		local v_u_1267 = {}
		local v_u_1268 = {}
		for v1269 = 1, 7 do
			local v1270 = (v1269 - 0.5) * 1.5714285714285714 + -5.5
			local v1271 = 3.141592653589793 * (v1269 - 0.5) / 7
			local v1272 = math.sin(v1271) * 4
			local v1273 = v_u_8.part(Vector3.new(0.05, 1.6214286, 0.2), v1265 * CFrame.new(0, v1270, 0), Color3.fromRGB(8, 10, 34), {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v1274 = v_u_8.part(Vector3.new(0.05, 1.9714285, 0.1), v1265 * CFrame.new(0, v1270, 0.25), v_u_50, {
				["transparency"] = 0.15
			})
			v_u_1:AddItem(v1273, p_u_1253 + 1)
			v_u_1:AddItem(v1274, p_u_1253 + 1)
			table.insert(v_u_1267, {
				["dark"] = v1273,
				["glow"] = v1274,
				["w"] = v1272
			})
			local v1275 = (v1265 * CFrame.new(-v1272 / 2 - 0.5, v1270, -0.3)).Position
			table.insert(v_u_1268, v1275)
			local v1276 = (v1265 * CFrame.new(v1272 / 2 + 0.5, v1270, -0.3)).Position
			table.insert(v_u_1266, v1276)
		end
		local v_u_1277 = os.clock()
		local v_u_1278 = nil
		local function v1293()
			-- upvalues: (copy) v_u_1277, (ref) v_u_1278, (copy) v_u_1267, (copy) p_u_1253
			local v1279 = os.clock()
			local v1280 = (v1279 - v_u_1277) / 0.15
			local v1281 = math.clamp(v1280, 0, 1)
			if v_u_1278 then
				local v1282 = (v1279 - v_u_1278) / 0.1
				v1281 = v1281 * (1 - math.clamp(v1282, 0, 1))
			end
			local v1283 = (v1279 - v_u_1277) * 9
			local v1284 = math.sin(v1283) * 0.06 + 1
			for _, v1285 in v_u_1267 do
				local v1286 = v1285.w * v1281 * v1284
				local v1287 = v1285.dark
				local v1288 = math.max(v1286, 0.05)
				v1287.Size = Vector3.new(v1288, 1.6214285714285714, 0.2)
				local v1289 = v1285.glow
				local v1290 = v1286 + v1281 * 1.3
				local v1291 = math.max(v1290, 0.05)
				v1289.Size = Vector3.new(v1291, 1.9714285714285715, 0.1)
			end
			if not v_u_1278 or v1279 - v_u_1278 <= 0.12 then
				return v1279 - v_u_1277 < p_u_1253 + 1
			end
			for _, v1292 in v_u_1267 do
				v1292.dark:Destroy()
				v1292.glow:Destroy()
			end
			return false
		end
		local v1294 = v_u_67
		table.insert(v1294, v1293)
		v_u_117("Lightning", v_u_1258, v_u_50, 1.4)
		local v_u_1295 = { (v_u_139("Vortex", v_u_1258, v_u_50, v_u_1254 / 9)) }
		local v1296 = v_u_247
		local v1297 = CFrame.new
		local v1298 = p_u_1252.X
		local v1299 = v_u_18 + 0.14
		local v1300 = p_u_1252.Z
		v1296(v1297((Vector3.new(v1298, v1299, v1300))), v_u_1254, v_u_50, v_u_15.Ring, p_u_1253, 1)
		v_u_265(p_u_1252, v_u_50, v_u_1254 * 0.8, p_u_1253, v_u_15.Glow, 0.5)
		local v_u_1301 = true
		local v_u_1302 = os.clock() + p_u_1253 + 0.3
		task.spawn(function()
			-- upvalues: (ref) v_u_1301, (copy) v_u_1302, (ref) v_u_428, (ref) v_u_437, (copy) v_u_1268, (ref) v_u_33, (copy) v_u_1266, (copy) p_u_1251, (copy) v_u_1254, (copy) p_u_1252, (ref) v_u_18, (ref) v_u_421, (copy) v_u_1258, (ref) v_u_51, (ref) v_u_117, (ref) v_u_50
			while v_u_1301 and os.clock() < v_u_1302 do
				v_u_428(v_u_437(v_u_1268, 0.45), 0.25, v_u_33, 0.1)
				v_u_428(v_u_437(v_u_1266, 0.45), 0.25, v_u_33, 0.1)
				if not p_u_1251.lite then
					local v1303 = math.random() * 3.141592653589793 * 2
					local v1304 = math.random() * v_u_1254
					local v1305 = p_u_1252
					local v1306 = v1305.X
					local v1307 = v_u_18 + 0.5
					local v1308 = v1305.Z
					local v1309 = Vector3.new(v1306, v1307, v1308)
					local v1310 = math.cos(v1303) * v1304
					local v1311 = math.sin(v1303) * v1304
					local v1312 = v1309 + Vector3.new(v1310, 0, v1311)
					v_u_428(v_u_421(v_u_1258, v1312, 1.2, 3), 0.3, v_u_51, 0.12)
					v_u_117("Lightning", v1312, v_u_50, 0.7)
				end
				task.wait(0.16)
			end
		end)
		return function()
			-- upvalues: (ref) v_u_1301, (ref) v_u_1278, (copy) v_u_1295
			v_u_1301 = false
			v_u_1278 = os.clock()
			for _, v1313 in v_u_1295 do
				v1313()
			end
		end
	end,
	["finish"] = function(p1314, p1315) -- name: finish
		-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_50, (copy) v_u_209, (copy) v_u_33, (copy) v_u_8, (copy) v_u_15, (copy) v_u_51, (copy) v_u_10
		local v1316 = p1314.ability.radius
		local v1317 = p1315.X
		local v1318 = v_u_18 + 5.5
		local v1319 = p1315.Z
		local v1320 = Vector3.new(v1317, v1318, v1319)
		v_u_117("Flash", v1320, v_u_50, 0.7)
		v_u_117("Lightning", v1320, v_u_50, 1.6)
		v_u_209(v1320, v_u_33, 2, v1316, 0.2, 0.2)
		local v1321 = v_u_8.ring
		local v1322 = p1315.X
		local v1323 = v_u_18 + 0.2
		local v1324 = p1315.Z
		v1321(Vector3.new(v1322, v1323, v1324), v_u_50, v1316 * 1.2, 0.4, v_u_15.SpeedLines)
		local v1325 = v_u_8.ring
		local v1326 = p1315.X
		local v1327 = v_u_18 + 0.2
		local v1328 = p1315.Z
		v1325(Vector3.new(v1326, v1327, v1328), v_u_51, v1316, 0.35)
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v1320
		})
		if p1314.mine then
			v_u_8.shake(0.3, 0.3)
		end
	end,
	["hit"] = function(_, p1329, _) -- name: sparkHit
		-- upvalues: (copy) v_u_117, (copy) v_u_50
		v_u_117("Lightning", p1329, v_u_50, 0.5)
	end
}
v_u_551.jogan_laser = {
	["cast"] = function(p1330) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_50
		v_u_575(p1330, v_u_50, true)
	end,
	["windup"] = function(p1331, p1332, p1333) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15, (copy) v_u_139, (copy) v_u_50, (copy) v_u_428, (copy) v_u_421, (copy) v_u_51
		local v_u_1334 = p1332 + p1331.dir * 1.4
		local v1335 = v_u_247
		local v1336 = p1331.dir
		local v1337 = v1336.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1336.Unit
		local v1338 = v1337.Y
		local v1339 = math.abs(v1338) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v1335(CFrame.lookAt(v_u_1334, v_u_1334 + v1337, v1339) * CFrame.Angles(-1.5707963267948966, 0, 0), 2.2 * p1331.size, v_u_33, v_u_14.Iris.jogan or v_u_15.MagicCircle, p1333 + 0.2, 6)
		if p1333 > 0.05 then
			local v1340 = v_u_139("Charge", v_u_1334, v_u_50, 0.8)
			task.delay(p1333, v1340)
		end
		for v1341 = 1, 3 do
			local v1342 = (v1341 - 1) * p1333 / 3
			local function v1346()
				-- upvalues: (ref) v_u_428, (ref) v_u_421, (copy) v_u_1334, (ref) v_u_51
				local v1343 = math.random() - 0.5
				local v1344 = math.random() - 0.5
				local v1345 = math.random() - 0.5
				v_u_428(v_u_421(v_u_1334 + Vector3.new(v1343, v1344, v1345) * 5, v_u_1334, 0.6, 1), 0.2, v_u_51, 0.08)
			end
			if v1342 > 0.005 then
				task.delay(v1342, v1346)
			else
				v1346()
			end
		end
	end,
	["beam"] = function(p1347, p_u_1348, p_u_1349) -- name: beam
		-- upvalues: (copy) v_u_200, (copy) v_u_168, (copy) v_u_33, (copy) v_u_50, (copy) v_u_8, (copy) v_u_428, (copy) v_u_421, (copy) v_u_51, (copy) v_u_292, (copy) v_u_450, (copy) v_u_117, (copy) v_u_10
		local v1350 = p1347.size
		v_u_200(v_u_168(p_u_1348, p_u_1349, 2 * v1350, v_u_33), 0.45, true)
		v_u_200(v_u_168(p_u_1348, p_u_1349, 5.5 * v1350, v_u_50, 0.4), 0.55, true)
		local v1351 = v_u_50
		local v1352 = 10 * v1350
		local v1353 = v_u_8.beam(p_u_1348, p_u_1349, v1351, v1352, 0.55, nil)
		v1353.LightEmission = 0.55
		v1353.Brightness = 1.6
		for v1354 = 0, 2 do
			local v1355 = v1354 * 0.1
			local function v1356()
				-- upvalues: (ref) v_u_428, (ref) v_u_421, (copy) p_u_1348, (copy) p_u_1349, (ref) v_u_51
				v_u_428(v_u_421(p_u_1348, p_u_1349, 2.4, 6), 0.35, v_u_51, 0.1)
				v_u_428(v_u_421(p_u_1348, p_u_1349, 2.4, 6), 0.35, v_u_51, 0.1)
			end
			if v1355 > 0.005 then
				task.delay(v1355, v1356)
			else
				v1356()
			end
		end
		v_u_292(p_u_1348, p_u_1349, 3 * v1350, Color3.fromRGB(25, 55, 120), 1.3, 0.35)
		v_u_450(p_u_1348, p_u_1349, 15, 0.12, function(p1357)
			-- upvalues: (ref) v_u_117, (ref) v_u_50
			v_u_117("Lightning", p1357, v_u_50, 1.1)
		end)
		v_u_117("Explosion", p_u_1349, v_u_50, 1.4)
		v_u_117("Flash", p_u_1348 + p1347.dir * 2, v_u_50, 0.6)
		v_u_10.play("Lightning", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = p_u_1348:Lerp(p_u_1349, 0.5)
		})
		v_u_10.play("Explosion", {
			["at"] = p_u_1349
		})
		if p1347.mine then
			v_u_8.shake(0.45, 0.4)
		end
	end,
	["hit"] = function(_, p1358, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_50
		v_u_117("Lightning", p1358, v_u_50, 0.8)
		v_u_117("Impact", p1358, v_u_50, 0.9)
	end
}
local function v_u_1361(p1359, p1360) -- name: truthOrb
	-- upvalues: (copy) v_u_514, (copy) v_u_34, (copy) v_u_52, (copy) v_u_33
	return v_u_514(p1359, p1360, {
		["core"] = nil,
		["coreMaterial"] = nil,
		["coreSize"] = 1.8,
		["shell"] = nil,
		["shellSize"] = 2.7,
		["shellAlpha"] = 0.7,
		["trail"] = nil,
		["trailEnd"] = nil,
		["trailWidth"] = 1.7,
		["orbit"] = nil,
		["orbitCount"] = 2,
		["orbitRadius"] = 1.7,
		["orbitSize"] = 0.5,
		["orbitSpeed"] = 14,
		["core"] = v_u_34,
		["coreMaterial"] = Enum.Material.SmoothPlastic,
		["shell"] = v_u_52,
		["trail"] = v_u_52,
		["trailEnd"] = v_u_33,
		["orbit"] = v_u_33
	})
end
local function v_u_1370(p1362, p1363, p1364) -- name: truthImpact
	-- upvalues: (copy) v_u_117, (copy) v_u_52, (copy) v_u_209, (copy) v_u_34, (copy) v_u_8, (copy) v_u_18, (copy) v_u_15, (copy) v_u_405, (copy) v_u_265
	local v1365 = p1362.size * p1364
	v_u_117("Impact", p1363, v_u_52, 1.1 * v1365)
	v_u_209(p1363, v_u_34, 3.5 * v1365, 0.3, 0.16, 0, Enum.Material.SmoothPlastic)
	v_u_8.flash(p1363, v_u_52, 5 * v1365, 0.16)
	local v1366 = v_u_8.ring
	local v1367 = p1363.X
	local v1368 = v_u_18 + 0.2
	local v1369 = p1363.Z
	v1366(Vector3.new(v1367, v1368, v1369), v_u_52, 4 * v1365, 0.3, v_u_15.Ring)
	if not p1362.lite then
		v_u_405(p1363, { v_u_34, v_u_52 }, 5, 24, 0.5 * v1365, 0.45, true)
	end
	v_u_265(p1363, v_u_34, 2.2 * v1365, 0.9)
end
local v1374 = {
	["cast"] = function(p1371) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_52
		v_u_557(p1371, v_u_52)
	end,
	["shot"] = v_u_1361,
	["impact"] = function(p1372, p1373) -- name: impact
		-- upvalues: (copy) v_u_1370, (copy) v_u_10
		v_u_1370(p1372, p1373, 1)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p1373
		})
	end
}
local v_u_1375 = 0.6
function v1374.hit(_, p1376, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_52, (copy) v_u_1375
	v_u_117("Impact", p1376, v_u_52, v_u_1375)
end
v_u_551.truth_orb = v1374
local function v_u_1398(p_u_1377, p_u_1378, p_u_1379, p_u_1380, p_u_1381, p1382, p_u_1383, p_u_1384) -- name: drop
	-- upvalues: (copy) v_u_145, (copy) v_u_86
	local function v1395(p1385) -- name: go
		-- upvalues: (copy) p_u_1378, (copy) p_u_1377, (ref) v_u_145, (copy) p_u_1379, (copy) p_u_1380, (ref) v_u_86, (copy) p_u_1381, (copy) p_u_1383, (copy) p_u_1384
		local v_u_1386 = p_u_1378(p_u_1377, v_u_145(p_u_1379, p_u_1380 - p_u_1379))
		local v_u_1387 = os.clock() - p1385
		v_u_86(p_u_1381, p1385, function(p1388)
			-- upvalues: (copy) v_u_1386, (ref) p_u_1379, (ref) p_u_1380, (copy) v_u_1387, (ref) p_u_1383, (ref) p_u_1384
			local v1389 = v_u_1386.place
			local v1390 = p_u_1379:Lerp(p_u_1380, p1388)
			local v1391 = p_u_1380 - p_u_1379
			local v1392 = v1391.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1391.Unit
			local v1393 = v1392.Y
			local v1394 = math.abs(v1393) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			v1389(CFrame.lookAt(v1390, v1390 + v1392, v1394), os.clock() - v_u_1387)
			if p1388 >= 1 then
				if p_u_1383 then
					task.delay(p_u_1383, function()
						-- upvalues: (ref) v_u_1386
						v_u_1386.stop(0.2)
					end)
				else
					v_u_1386.stop()
				end
				p_u_1384(p_u_1380)
			end
		end)
	end
	local v1396 = p1382 - p_u_1381
	if v1396 > 0.005 then
		task.delay(v1396, v1395, 0)
	else
		local v1397 = -v1396
		v1395((math.min(v1397, p_u_1381)))
	end
end
local v1437 = {
	["cast"] = function(p1399) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_52
		v_u_575(p1399, v_u_52)
	end,
	["windup"] = function(p1400, p1401, p1402) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_247, (copy) v_u_52, (copy) v_u_15, (copy) v_u_117
		local v1403 = p1401.X
		local v1404 = v_u_18 + 20
		local v1405 = p1401.Z
		local v1406 = Vector3.new(v1403, v1404, v1405)
		v_u_247(CFrame.new(v1406), p1400.ability.radius * 0.75, v_u_52, v_u_15.Ring, p1402 + 0.2, 1.2)
		v_u_117("Flash", v1406, v_u_52, 0.5)
	end,
	["strike"] = function(p_u_1407, p1408, p1409) -- name: strike
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_34, (copy) v_u_52, (copy) v_u_1398, (copy) v_u_1361, (copy) v_u_1370, (copy) v_u_8, (copy) v_u_10
		local v1410 = p_u_1407.ability.radius
		local v_u_1411 = p_u_1407.ability.strikeRadius or 6
		local v1412 = p1408.Z - p_u_1407.target.Z
		local v1413 = p1408.X - p_u_1407.target.X
		local v1414 = math.atan2(v1412, v1413)
		local v1415 = p_u_1407.target
		local v1416 = v1415.X
		local v1417 = v_u_18 + 20
		local v1418 = v1415.Z
		local v1419 = Vector3.new(v1416, v1417, v1418)
		local v1420 = math.cos(v1414) * v1410 * 0.55
		local v1421 = math.sin(v1414) * v1410 * 0.55
		local v1422 = v1419 + Vector3.new(v1420, 0, v1421)
		local v_u_1423 = v_u_152(v1422, v_u_34, 1.7, 0, Enum.Material.SmoothPlastic)
		local v_u_1424 = v_u_152(v1422, v_u_52, 2.6, 0.72)
		local v1425 = task.delay
		local v1426 = p1409 - 0.2
		v1425(math.max(v1426, 0), function()
			-- upvalues: (copy) v_u_1423, (copy) v_u_1424
			v_u_1423:Destroy()
			v_u_1424:Destroy()
		end)
		local v1427 = v_u_1398
		local v1428 = v_u_1361
		local v1429 = p1408.X
		local v1430 = v_u_18 + 1
		local v1431 = p1408.Z
		v1427(p_u_1407, v1428, v1422, Vector3.new(v1429, v1430, v1431), 0.2, p1409, nil, function(p1432)
			-- upvalues: (ref) v_u_1370, (copy) p_u_1407, (ref) v_u_8, (ref) v_u_18, (ref) v_u_52, (copy) v_u_1411, (ref) v_u_10
			v_u_1370(p_u_1407, p1432, 1.2)
			local v1433 = v_u_8.ring
			local v1434 = p1432.X
			local v1435 = v_u_18 + 0.2
			local v1436 = p1432.Z
			v1433(Vector3.new(v1434, v1435, v1436), v_u_52, v_u_1411, 0.3)
			v_u_10.play("Hit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = p1432
			})
		end)
	end
}
local v_u_1438 = 0.7
function v1437.hit(_, p1439, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_52, (copy) v_u_1438
	v_u_117("Impact", p1439, v_u_52, v_u_1438)
end
v_u_551.orb_rain = v1437
local v1518 = {
	["loopSound"] = "Vortex",
	["castSound"] = "Burst",
	["cast"] = nil,
	["windup"] = nil,
	["zone"] = nil,
	["finish"] = nil,
	["hit"] = nil,
	["cast"] = function(p1440) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_52
		v_u_575(p1440, v_u_52, true)
	end,
	["windup"] = function(_, p1441, p1442) -- name: windup
		-- upvalues: (copy) v_u_152, (copy) v_u_18, (copy) v_u_33, (copy) v_u_461, (copy) v_u_52, (copy) v_u_1, (ref) v_u_67
		local v1443 = v_u_152
		local v1444 = p1441.X
		local v1445 = v_u_18 + 1
		local v1446 = p1441.Z
		local v_u_1447 = v1443(Vector3.new(v1444, v1445, v1446), v_u_33, 1.5, 0)
		v_u_461(v_u_1447, v_u_52, v_u_33, 1.2, 0.2)
		local v1448 = p1441.X
		local v1449 = v_u_18 + 1
		local v1450 = p1441.Z
		local v_u_1451 = Vector3.new(v1448, v1449, v1450)
		local v1452 = p1441.X
		local v1453 = v_u_18 + 11
		local v1454 = p1441.Z
		local v_u_1455 = Vector3.new(v1452, v1453, v1454)
		local v1456 = math.max(p1442, 0.05)
		local function v_u_1458(p1457)
			-- upvalues: (copy) v_u_1447, (copy) v_u_1451, (copy) v_u_1455, (ref) v_u_1
			v_u_1447.CFrame = CFrame.new(v_u_1451:Lerp(v_u_1455, p1457))
			if p1457 >= 1 then
				v_u_1447.Transparency = 1
				v_u_1:AddItem(v_u_1447, 0.2)
			end
		end
		local v_u_1459 = math.max(v1456, 0.001)
		local v_u_1460 = os.clock() - 0
		local v1461 = 0 / v_u_1459
		local v1462 = math.clamp(v1461, 0, 1)
		v_u_1447.CFrame = CFrame.new(v_u_1451:Lerp(v_u_1455, v1462))
		if v1462 >= 1 then
			v_u_1447.Transparency = 1
			v_u_1:AddItem(v_u_1447, 0.2)
		end
		if v1462 < 1 then
			local v1463 = v_u_67
			table.insert(v1463, function()
				-- upvalues: (copy) v_u_1460, (copy) v_u_1459, (copy) v_u_1458
				local v1464 = (os.clock() - v_u_1460) / v_u_1459
				local v1465 = math.clamp(v1464, 0, 1)
				v_u_1458(v1465)
				return v1465 < 1
			end)
		end
	end,
	["zone"] = function(p1466, p1467, p_u_1468) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_53, (copy) v_u_52, (copy) v_u_8, (copy) v_u_117, (copy) v_u_34, (copy) v_u_247, (copy) v_u_15, (ref) v_u_67, (copy) v_u_649, (copy) v_u_36, (copy) v_u_139, (copy) v_u_1
		local v1469 = p1466.ability.radius
		local v1470 = p1467.X
		local v1471 = v_u_18 + 11
		local v1472 = p1467.Z
		local v_u_1473 = Vector3.new(v1470, v1471, v1472)
		local v_u_1474 = v_u_152(v_u_1473, v_u_53, 4, 0)
		local v_u_1475 = v_u_152(v_u_1473, v_u_52, 6, 0.55)
		v_u_8.tween(v_u_1474, p_u_1468, {
			["Size"] = Vector3.new(8.5, 8.5, 8.5)
		}, Enum.EasingStyle.Linear)
		v_u_8.tween(v_u_1475, p_u_1468, {
			["Size"] = Vector3.new(12, 12, 12)
		}, Enum.EasingStyle.Linear)
		if p1466.mine then
			local v1476 = v_u_52
			local v1477 = Instance.new("PointLight")
			v1477.Color = v1476
			v1477.Range = 30
			v1477.Brightness = 2
			v1477.Shadows = false
			v1477.Parent = v_u_1474
		end
		v_u_117("Flash", v_u_1473, v_u_52, 0.7)
		local v1478 = p1466.lite and 4 or 7
		local v_u_1479 = {}
		for v1480 = 1, 2 do
			for v1481 = 1, v1478 do
				local v1482 = {
					["p"] = v_u_152(v_u_1473, v_u_34, 1.3, 0, Enum.Material.SmoothPlastic),
					["ring"] = v1480,
					["a"] = v1481 / v1478 * 3.141592653589793 * 2
				}
				table.insert(v_u_1479, v1482)
			end
			v_u_247(CFrame.new(v_u_1473) * CFrame.Angles(v1480 == 1 and 0.45 or -0.6, 0, 0.2), v1480 == 1 and 7.5 or 10, v_u_52, v_u_15.Ring, p_u_1468, v1480 == 1 and 2 or -1.5)
		end
		local v_u_1483 = os.clock()
		local v_u_1484 = nil
		local function v1493()
			-- upvalues: (copy) v_u_1483, (ref) v_u_1484, (copy) v_u_1479, (copy) v_u_1473, (copy) p_u_1468
			local v1485 = os.clock() - v_u_1483
			local v1486
			if v_u_1484 then
				local v1487 = (os.clock() - v_u_1484) / 0.12
				v1486 = 1 - math.clamp(v1487, 0, 1)
			else
				v1486 = 1
			end
			for _, v1488 in v_u_1479 do
				local v1489 = (v1488.ring == 1 and 7 or 9.5) * v1486
				local v1490 = CFrame.Angles(v1488.ring == 1 and 0.45 or -0.6, 0, 0.2)
				local v1491 = v1488.a + v1485 * (v1488.ring == 1 and 3 or -2.2)
				v1488.p.CFrame = CFrame.new(v_u_1473) * v1490 * CFrame.new(math.cos(v1491) * v1489, 0, math.sin(v1491) * v1489)
			end
			if not v_u_1484 or v1486 > 0 then
				return v1485 < p_u_1468 + 1
			end
			for _, v1492 in v_u_1479 do
				v1492.p:Destroy()
			end
			return false
		end
		local v1494 = v_u_67
		table.insert(v1494, v1493)
		local v_u_1495 = v_u_649(p1467, v_u_1473, v1469, p1466.lite and 4 or 9, { v_u_36[1], v_u_36[2], v_u_52 }, p_u_1468, 6)
		local v1496 = v_u_247
		local v1497 = CFrame.new
		local v1498 = p1467.X
		local v1499 = v_u_18 + 0.14
		local v1500 = p1467.Z
		v1496(v1497((Vector3.new(v1498, v1499, v1500))), v1469, v_u_52, v_u_15.MagicCircle, p_u_1468, 1)
		local v_u_1501 = { (v_u_139("Vortex", v_u_1473, v_u_52, 1.6)) }
		return function()
			-- upvalues: (ref) v_u_1484, (copy) v_u_1495, (copy) v_u_1501, (ref) v_u_8, (copy) v_u_1474, (copy) v_u_1475, (ref) v_u_1
			v_u_1484 = os.clock()
			v_u_1495()
			for _, v1502 in v_u_1501 do
				v1502()
			end
			v_u_8.tween(v_u_1474, 0.12, {
				["Size"] = Vector3.new(2, 2, 2)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_8.tween(v_u_1475, 0.12, {
				["Size"] = Vector3.new(2, 2, 2),
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v_u_1474, 0.13)
			v_u_1:AddItem(v_u_1475, 0.13)
		end
	end,
	["finish"] = function(p1503, p1504) -- name: finish
		-- upvalues: (copy) v_u_18, (copy) v_u_209, (copy) v_u_53, (copy) v_u_117, (copy) v_u_52, (copy) v_u_8, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_35, (copy) v_u_15, (copy) v_u_10
		local v1505 = p1503.ability.radius
		local v1506 = p1504.X
		local v1507 = v_u_18 + 8
		local v1508 = p1504.Z
		local v1509 = Vector3.new(v1506, v1507, v1508)
		local v1510 = p1504.X
		local v1511 = v_u_18 + 0.2
		local v1512 = p1504.Z
		local v1513 = Vector3.new(v1510, v1511, v1512)
		v_u_209(v1509, v_u_53, 6, v1505 * 2.4, 0.5, 0.15)
		local v1514 = v_u_117
		local v1515 = p1504.X
		local v1516 = v_u_18 + 3
		local v1517 = p1504.Z
		v1514("Explosion", Vector3.new(v1515, v1516, v1517), v_u_52, v1505 / 6)
		v_u_117("Shockwave", v1513 + Vector3.new(0, 0.3, 0), v_u_52, v1505 / 14)
		v_u_117("Flash", v1509, v_u_52, 1)
		v_u_8.ring(v1513, v_u_52, v1505 * 1.4, 0.55)
		v_u_405(v1513 + Vector3.new(0, 1, 0), { v_u_36[1], v_u_36[2], v_u_52 }, p1503.lite and 5 or 12, 42, 1.3, 1.1)
		v_u_265(p1504, v_u_35, v1505 * 0.7, 2)
		v_u_265(p1504, v_u_52, v1505 * 0.8, 1.4, v_u_15.CrackGlow, 0.2)
		v_u_10.play("Explosion", {
			["at"] = v1513
		})
		if p1503.mine then
			v_u_8.shake(0.55, 0.45)
		end
	end
}
local v_u_1519 = 0.7
function v1518.hit(_, p1520, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_52, (copy) v_u_1519
	v_u_117("Impact", p1520, v_u_52, v_u_1519)
end
v_u_551.planetary = v1518
v_u_551.tomoe_orb = {
	["cast"] = function(p1521) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_54
		v_u_557(p1521, v_u_54)
	end,
	["shot"] = function(p1522, p1523) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_55, (copy) v_u_54, (copy) v_u_34
		return v_u_514(p1522, p1523, {
			["core"] = nil,
			["coreSize"] = 1.7,
			["shell"] = nil,
			["shellSize"] = 2.5,
			["shellAlpha"] = 0.5,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.7,
			["orbit"] = nil,
			["orbitMaterial"] = nil,
			["orbitCount"] = 3,
			["orbitRadius"] = 1.5,
			["orbitSize"] = 0.6,
			["orbitSpeed"] = 16,
			["core"] = v_u_55,
			["shell"] = v_u_54,
			["trail"] = v_u_54,
			["trailEnd"] = v_u_55,
			["orbit"] = v_u_34,
			["orbitMaterial"] = Enum.Material.SmoothPlastic
		})
	end,
	["impact"] = function(p1524, p1525) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_54, (copy) v_u_8, (copy) v_u_405, (copy) v_u_34, (copy) v_u_18, (copy) v_u_10
		local v1526 = p1524.size
		v_u_117("Impact", p1525, v_u_54, 1 * v1526)
		v_u_8.flash(p1525, v_u_54, 5 * v1526, 0.16)
		if not p1524.lite then
			v_u_117("Slash", p1525, v_u_54, 0.6 * v1526)
			v_u_405(p1525, { v_u_34 }, 3, 28, 0.6 * v1526, 0.4)
		end
		local v1527 = v_u_8.ring
		local v1528 = p1525.X
		local v1529 = v_u_18 + 0.2
		local v1530 = p1525.Z
		v1527(Vector3.new(v1528, v1529, v1530), v_u_54, 4 * v1526, 0.3)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p1525
		})
	end,
	["hit"] = function(_, p1531, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_54
		v_u_117("Slash", p1531, v_u_54, 0.45)
	end
}
local function v_u_1577(p_u_1532, p1533, p_u_1534) -- name: shadows
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_1, (copy) v_u_54, (ref) v_u_67
	local v1535 = Color3.fromRGB(28, 8, 40)
	local v_u_1536 = {}
	for v1537 = 1, 4 do
		local v1538 = v1537 / 4 * 3.141592653589793 * 2 + 0.7853981633974483
		local v1539 = p_u_1532.X
		local v1540 = v_u_18 + 0
		local v1541 = p_u_1532.Z
		local v1542 = Vector3.new(v1539, v1540, v1541)
		local v1543 = math.cos(v1538)
		local v1544 = math.sin(v1538)
		local v1545 = v1542 + Vector3.new(v1543, 0, v1544) * p1533
		local v1546 = { 1, 3, 4.8 }
		local v1547 = {}
		local v1548 = {}
		for v1549, v1550 in { Vector3.new(1.7, 1.8, 0.9), Vector3.new(1.9, 2.2, 1), Vector3.new(1.2, 1.2, 1.2) } do
			local v1551 = v_u_8.part(v1550, CFrame.new(v1545), v1535, {
				["material"] = nil,
				["transparency"] = 1,
				["material"] = Enum.Material.SmoothPlastic
			})
			v_u_8.tween(v1551, 0.08, {
				["Transparency"] = 0.25
			})
			v_u_1:AddItem(v1551, p_u_1534 + 0.5)
			table.insert(v1547, v1551)
			local v1552 = CFrame.new
			local v1553 = v1546[v1549]
			table.insert(v1548, v1552(0, v1553, 0))
		end
		local v1554 = v_u_8.part(Vector3.new(2.4, 5.6, 1.4), CFrame.new(v1545), v_u_54, {
			["transparency"] = 1
		})
		v_u_8.tween(v1554, 0.08, {
			["Transparency"] = 0.8
		})
		v_u_1:AddItem(v1554, p_u_1534 + 0.5)
		table.insert(v1547, v1554)
		local v1555 = CFrame.new
		table.insert(v1548, v1555(0, 2.8, 0))
		table.insert(v_u_1536, {
			["parts"] = v1547,
			["offs"] = v1548,
			["from"] = v1545,
			["a"] = v1538
		})
	end
	local v_u_1556 = os.clock()
	local function v1575()
		-- upvalues: (copy) v_u_1556, (copy) p_u_1534, (copy) v_u_1536, (copy) p_u_1532, (ref) v_u_18, (ref) v_u_8, (ref) v_u_1
		local v1557 = (os.clock() - v_u_1556 - p_u_1534) / 0.08
		local v1558 = math.clamp(v1557, 0, 1)
		for _, v1559 in v_u_1536 do
			local v1560 = v1559.from
			local v1561 = p_u_1532
			local v1562 = v1561.X
			local v1563 = v_u_18 + 0
			local v1564 = v1561.Z
			local v1565 = v1560:Lerp(Vector3.new(v1562, v1563, v1564), v1558)
			local v1566 = CFrame.lookAt
			local v1567 = p_u_1532.X
			local v1568 = v1565.Y
			local v1569 = p_u_1532.Z
			local v1570 = v1566(v1565, (Vector3.new(v1567, v1568, v1569)))
			for v1571, v1572 in v1559.parts do
				v1572.CFrame = v1570 * v1559.offs[v1571]
			end
		end
		if v1558 < 1 then
			return true
		end
		for _, v1573 in v_u_1536 do
			for _, v1574 in v1573.parts do
				v_u_8.tween(v1574, 0.1, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v1574, 0.15000000000000002)
			end
		end
		return false
	end
	local v1576 = v_u_67
	table.insert(v1576, v1575)
end
v_u_551.limbo = {
	["cast"] = function(p1578) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_54
		v_u_575(p1578, v_u_54)
	end,
	["windup"] = function(p1579, p1580, p1581) -- name: windup
		-- upvalues: (copy) v_u_1577, (copy) v_u_8, (copy) v_u_18, (copy) v_u_54, (copy) v_u_15
		v_u_1577(p1580, p1579.ability.radius * 0.5, p1581)
		local v1582 = v_u_8.ring
		local v1583 = p1580.X
		local v1584 = v_u_18 + 0.2
		local v1585 = p1580.Z
		v1582(Vector3.new(v1583, v1584, v1585), v_u_54, p1579.ability.radius, p1581 + 0.1, v_u_15.Ring)
	end,
	["land"] = function(p1586, p1587) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_33, (copy) v_u_54, (copy) v_u_1, (copy) v_u_117, (copy) v_u_55, (copy) v_u_265, (copy) v_u_10
		local v_u_1588 = p1586.ability.radius
		local v1589 = p1587.X
		local v1590 = v_u_18 + 0.2
		local v1591 = p1587.Z
		local v1592 = Vector3.new(v1589, v1590, v1591)
		local v1593 = p1587.X
		local v1594 = v_u_18 + 3
		local v1595 = p1587.Z
		local v_u_1596 = Vector3.new(v1593, v1594, v1595)
		for v_u_1597 = 1, 6 do
			local v1598 = (v_u_1597 - 1) * 0.03
			local function v1608()
				-- upvalues: (copy) v_u_1596, (ref) v_u_8, (copy) v_u_1588, (copy) v_u_1597, (ref) v_u_33, (ref) v_u_54, (ref) v_u_1
				local v1599 = CFrame.new(v_u_1596) * CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0) * CFrame.Angles((math.random() - 0.5) * 0.9, 0, (math.random() - 0.5) * 0.6)
				local v1600 = v_u_8.part
				local v1601 = v_u_1588 * 1.5
				local v1602 = Vector3.new(0.6, 0.6, v1601)
				local v1603
				if v_u_1597 % 2 == 0 then
					v1603 = v_u_33
				else
					v1603 = v_u_54
				end
				local v1604 = v1600(v1602, v1599, v1603)
				local v1605 = v_u_8.tween
				local v1606 = {
					["Size"] = nil,
					["Transparency"] = 1
				}
				local v1607 = v_u_1588 * 1.9
				v1606.Size = Vector3.new(0.05, 0.05, v1607)
				v1605(v1604, 0.25, v1606)
				v_u_1:AddItem(v1604, 0.3)
			end
			if v1598 > 0.005 then
				task.delay(v1598, v1608)
			else
				v1608()
			end
		end
		if not p1586.lite then
			v_u_117("Slash", v_u_1596, v_u_54, 1.6)
			v_u_117("Slash", v_u_1596, v_u_55, 1.3)
		end
		v_u_117("Explosion", v_u_1596, Color3.fromRGB(150, 15, 70), v_u_1588 / 8)
		v_u_117("Shockwave", v1592 + Vector3.new(0, 0.3, 0), v_u_54, v_u_1588 / 18)
		v_u_8.ring(v1592, v_u_54, v_u_1588, 0.45)
		v_u_265(p1587, v_u_55, v_u_1588 * 0.6, 1.5)
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v_u_1596
		})
		if p1586.mine then
			v_u_8.shake(0.35, 0.3)
		end
	end,
	["hit"] = function(_, p1609, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_54
		v_u_117("Slash", p1609, v_u_54, 0.6)
		v_u_117("Impact", p1609, v_u_54, 0.7)
	end
}
v_u_551.tsukuyomi = {
	["cast"] = function(p1610) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_54, (copy) v_u_117
		v_u_575(p1610, v_u_54, true)
		v_u_117("Flash", p1610.eye, v_u_54, 0.45)
	end,
	["windup"] = function(p1611, p1612, p1613) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_54, (copy) v_u_8, (copy) v_u_6, (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15, (copy) v_u_1
		local v1614 = p1611.ability.radius
		local v1615 = p1612.X
		local v1616 = v_u_18 + 34
		local v1617 = p1612.Z
		local v1618 = Vector3.new(v1615, v1616, v1617) + p1611.dir * 34
		local v1619 = p1613 + 1.4
		local v_u_1620 = v_u_152(v1618, Color3.fromRGB(255, 70, 80), 6, 0.05)
		local v_u_1621 = v_u_152(v1618, v_u_54, 9, 0.75)
		v_u_8.tween(v_u_1620, p1613 + 0.15, {
			["Size"] = Vector3.new(24, 24, 24)
		}, Enum.EasingStyle.Back)
		v_u_8.tween(v_u_1621, p1613 + 0.25, {
			["Size"] = Vector3.new(36, 36, 36)
		}, Enum.EasingStyle.Back)
		local v1622 = v_u_6.CurrentCamera
		local v1623
		if v1622 then
			v1623 = v1622.CFrame.Position
		else
			v1623 = p1612
		end
		local v1624 = (v1623 - v1618).Unit
		local v1625 = v_u_247
		local v1626 = v1618 + v1624 * 12.4
		local v1627 = v1624.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1624.Unit
		local v1628 = v1627.Y
		local v1629 = math.abs(v1628) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v1625(CFrame.lookAt(v1626, v1626 + v1627, v1629) * CFrame.Angles(-1.5707963267948966, 0, 0), 9.5, v_u_33, v_u_14.Iris.rinne_sharingan or v_u_15.MagicCircle, v1619 - 0.2, 0.6)
		local v1630 = v_u_247
		local v1631 = CFrame.new
		local v1632 = p1612.X
		local v1633 = v_u_18 + 0.16
		local v1634 = p1612.Z
		v1630(v1631((Vector3.new(v1632, v1633, v1634))), v1614 * 0.45, v_u_54, v_u_15.MagicCircle, p1613 + 1.2, 1)
		task.delay(v1619, function()
			-- upvalues: (copy) v_u_1620, (ref) v_u_8, (ref) v_u_1, (copy) v_u_1621
			local v1635 = v_u_1620
			v_u_8.tween(v1635, 0.4, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v1635, 0.45)
			local v1636 = v_u_1621
			v_u_8.tween(v1636, 0.4, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v1636, 0.45)
		end)
	end,
	["land"] = function(p1637, p1638) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_220, (copy) v_u_54, (copy) v_u_8, (copy) v_u_15, (copy) v_u_33, (copy) v_u_117, (copy) v_u_10
		local v1639 = p1637.ability.radius
		local v1640 = p1638.X
		local v1641 = v_u_18 + 0.2
		local v1642 = p1638.Z
		local v1643 = Vector3.new(v1640, v1641, v1642)
		local v1644 = p1638.X
		local v1645 = v_u_18 + 34
		local v1646 = p1638.Z
		local v1647 = Vector3.new(v1644, v1645, v1646) + p1637.dir * 34
		v_u_220(p1638, v1639, v_u_54, 0.7)
		v_u_8.ring(v1643, v_u_54, v1639, 0.7, v_u_15.Ring)
		v_u_8.ring(v1643, v_u_33, v1639 * 0.6, 0.5)
		local v1648 = v_u_117
		local v1649 = v1643 + Vector3.new(0, 0.3, 0)
		local v1650 = v_u_54
		local v1651 = v1639 / 20
		v1648("Shockwave", v1649, v1650, (math.min(v1651, 1.6)))
		local v1652 = v_u_54
		local v1653 = v_u_8.beam(v1647, v1643, v1652, 14, 0.6, nil)
		v1653.LightEmission = 0.55
		v1653.Brightness = 1.6
		v_u_117("Flash", v1647, v_u_54, 1.5)
		v_u_10.play("Burst", {
			["at"] = v1643
		})
		if p1637.mine then
			v_u_8.shake(0.45, 0.4)
		end
	end,
	["hit"] = function(p1654, p1655, p1656) -- name: hit
		-- upvalues: (copy) v_u_600, (copy) v_u_54, (copy) v_u_55
		v_u_600(p1654, p1655, p1656, v_u_54, v_u_55)
	end
}
local function v_u_1659(p1657, p1658) -- name: lightArrow
	-- upvalues: (copy) v_u_539, (copy) v_u_57, (copy) v_u_33, (copy) v_u_56
	return v_u_539(p1657, p1658, {
		["shaft"] = nil,
		["head"] = nil,
		["glow"] = nil,
		["length"] = 5.2,
		["thick"] = 0.36,
		["trail"] = nil,
		["trailEnd"] = nil,
		["trailWidth"] = 1.3,
		["shaft"] = v_u_57,
		["head"] = v_u_33,
		["glow"] = v_u_56,
		["trail"] = v_u_56,
		["trailEnd"] = v_u_57
	})
end
local function v1661(_, p1660, _) -- name: goldHit
	-- upvalues: (copy) v_u_117, (copy) v_u_56, (copy) v_u_359, (copy) v_u_57
	v_u_117("Impact", p1660, v_u_56, 0.7)
	v_u_359(p1660, v_u_57, 3.5, 0.15)
end
v_u_551.light_arrow = {
	["cast"] = function(p1662) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_56
		v_u_557(p1662, v_u_56)
	end,
	["shot"] = v_u_1659,
	["impact"] = function(p1663, p1664) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_56, (copy) v_u_8, (copy) v_u_359, (copy) v_u_57, (copy) v_u_10
		local v1665 = p1663.size
		v_u_117("Impact", p1664, v_u_56, 0.9 * v1665)
		v_u_8.flash(p1664, v_u_56, 4.5 * v1665, 0.15)
		v_u_359(p1664, v_u_57, 5.5 * v1665, 0.2)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p1664
		})
	end,
	["hit"] = v1661
}
v_u_551.arrow_rain = {
	["keep"] = 0.35,
	["cast"] = nil,
	["windup"] = nil,
	["strike"] = nil,
	["hit"] = nil,
	["cast"] = function(p1666) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_56, (copy) v_u_247, (copy) v_u_15
		v_u_575(p1666, v_u_56)
		v_u_247(CFrame.new(p1666.eye + Vector3.new(0, 2.6, 0)), 2.2, v_u_56, v_u_15.MagicCircle, 0.4, 4)
	end,
	["windup"] = function(p1667, p1668, p1669) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_56, (copy) v_u_15
		local v1670 = p1667.ability.radius
		for v1671 = 1, 3 do
			local v1672 = v1671 / 3 * 3.141592653589793 * 2
			local v1673 = v_u_247
			local v1674 = CFrame.new
			local v1675 = p1668.X
			local v1676 = v_u_18 + 24
			local v1677 = p1668.Z
			local v1678 = Vector3.new(v1675, v1676, v1677)
			local v1679 = math.cos(v1672) * v1670 * 0.45
			local v1680 = math.sin(v1672) * v1670 * 0.45
			v1673(v1674(v1678 + Vector3.new(v1679, 0, v1680)), 5, v_u_56, v_u_15.MagicCircle, p1669 + 0.2, v1671 % 2 == 0 and 3 or -3)
		end
	end,
	["strike"] = function(p1681, p1682, p1683) -- name: strike
		-- upvalues: (copy) v_u_18, (copy) v_u_1398, (copy) v_u_1659, (copy) v_u_117, (copy) v_u_56, (copy) v_u_8, (copy) v_u_15, (copy) v_u_359, (copy) v_u_57, (copy) v_u_10
		local v_u_1684 = p1681.ability.strikeRadius or 5
		local v1685 = p1682.X
		local v1686 = v_u_18 + 24
		local v1687 = p1682.Z
		local v1688 = Vector3.new(v1685, v1686, v1687)
		local v1689 = (math.random() - 0.5) * 6
		local v1690 = (math.random() - 0.5) * 6
		local v1691 = v1688 + Vector3.new(v1689, 0, v1690)
		local v1692 = v_u_1398
		local v1693 = v_u_1659
		local v1694 = p1682.X
		local v1695 = v_u_18 + 1.2
		local v1696 = p1682.Z
		v1692(p1681, v1693, v1691, Vector3.new(v1694, v1695, v1696), 0.15, p1683, 0.35, function(p1697)
			-- upvalues: (ref) v_u_117, (ref) v_u_56, (ref) v_u_8, (ref) v_u_18, (copy) v_u_1684, (ref) v_u_15, (ref) v_u_359, (ref) v_u_57, (ref) v_u_10
			v_u_117("Impact", p1697, v_u_56, 0.9)
			local v1698 = v_u_8.ring
			local v1699 = p1697.X
			local v1700 = v_u_18 + 0.2
			local v1701 = p1697.Z
			v1698(Vector3.new(v1699, v1700, v1701), v_u_56, v_u_1684, 0.25, v_u_15.Ring)
			v_u_359(p1697, v_u_57, 4, 0.15)
			v_u_10.play("Hit", {
				["at"] = nil,
				["volume"] = 0.5,
				["at"] = p1697
			})
		end)
	end,
	["hit"] = v1661
}
v_u_551.judgement = {
	["cast"] = function(p1702) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_56
		v_u_575(p1702, v_u_56, true)
	end,
	["windup"] = function(p1703, p1704, p1705) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15, (copy) v_u_56, (copy) v_u_139
		local v1706 = p1704 + p1703.dir * 2
		local v1707 = v_u_247
		local v1708 = p1703.dir
		local v1709 = v1708.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1708.Unit
		local v1710 = v1709.Y
		local v1711 = math.abs(v1710) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v1707(CFrame.lookAt(v1706, v1706 + v1709, v1711) * CFrame.Angles(-1.5707963267948966, 0, 0), 3 * p1703.size, v_u_33, v_u_14.Iris.senrigan or v_u_15.MagicCircle, p1705 + 0.2, 3)
		local v1712 = v_u_247
		local v1713 = v1706 + p1703.dir * 1.2
		local v1714 = p1703.dir
		local v1715 = v1714.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1714.Unit
		local v1716 = v1715.Y
		local v1717 = math.abs(v1716) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v1712(CFrame.lookAt(v1713, v1713 + v1715, v1717) * CFrame.Angles(-1.5707963267948966, 0, 0), 4.2 * p1703.size, v_u_56, v_u_15.Ring, p1705 + 0.2, -4)
		if p1705 > 0.05 then
			local v1718 = v_u_139("Charge", v1706, v_u_56, 0.8)
			task.delay(p1705, v1718)
		end
	end,
	["beam"] = function(p1719, p1720, p_u_1721) -- name: beam
		-- upvalues: (copy) v_u_200, (copy) v_u_168, (copy) v_u_33, (copy) v_u_56, (copy) v_u_57, (copy) v_u_8, (copy) v_u_247, (copy) v_u_15, (copy) v_u_292, (copy) v_u_117, (copy) v_u_10
		local v_u_1722 = p1719.size
		v_u_200(v_u_168(p1720, p_u_1721, 2.6 * v_u_1722, v_u_33), 0.5, true)
		v_u_200(v_u_168(p1720, p_u_1721, 7 * v_u_1722, v_u_56, 0.4), 0.6, true)
		local v1723 = v_u_57
		local v1724 = 13 * v_u_1722
		local v1725 = v_u_8.beam(p1720, p_u_1721, v1723, v1724, 0.6, nil)
		v1725.LightEmission = 0.55
		v1725.Brightness = 1.6
		local v_u_1726 = (p_u_1721 - p1720).Unit
		for v1727 = 1, 5 do
			local v_u_1728 = p1720 + v_u_1726 * (v1727 * 14 + 8)
			local v1729 = v1727 * 0.03
			local function v1741()
				-- upvalues: (ref) v_u_247, (copy) v_u_1728, (copy) v_u_1726, (copy) v_u_1722, (ref) v_u_56, (ref) v_u_15, (ref) v_u_8
				local v1730 = v_u_247
				local v1731 = v_u_1728
				local v1732 = v_u_1726
				local v1733 = v1732.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1732.Unit
				local v1734 = v1733.Y
				local v1735 = math.abs(v1734) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v1736 = v1730(CFrame.lookAt(v1731, v1731 + v1733, v1735) * CFrame.Angles(-1.5707963267948966, 0, 0), 3 * v_u_1722, v_u_56, v_u_15.Ring, 0.2, 0)
				local v1737 = v_u_8.tween
				local v1738 = {}
				local v1739 = 14 * v_u_1722
				local v1740 = 14 * v_u_1722
				v1738.Size = Vector3.new(v1739, 0.05, v1740)
				v1737(v1736, 0.35, v1738)
			end
			if v1729 > 0.005 then
				task.delay(v1729, v1741)
			else
				v1741()
			end
		end
		v_u_292(p1720, p_u_1721, 4 * v_u_1722, v_u_56, 1, 0.5)
		task.delay(0.1, function()
			-- upvalues: (ref) v_u_117, (copy) p_u_1721, (ref) v_u_56, (ref) v_u_10
			v_u_117("Explosion", p_u_1721, v_u_56, 1.6)
			v_u_117("Sparkle", p_u_1721, nil, 1)
			local v1742 = {
				["at"] = p_u_1721
			}
			v_u_10.play("Explosion", v1742)
		end)
		v_u_117("Flash", p1720 + p1719.dir * 2, v_u_56, 0.6)
		if p1719.mine then
			v_u_8.shake(0.45, 0.4)
		end
	end,
	["hit"] = function(_, p1743, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_56, (copy) v_u_359, (copy) v_u_57
		v_u_117("Impact", p1743, v_u_56, 1)
		v_u_359(p1743, v_u_57, 5, 0.2)
	end
}
local function v_u_1746(_, p1744, _) -- name: sealHit
	-- upvalues: (copy) v_u_117, (copy) v_u_58, (copy) v_u_247, (copy) v_u_15, (copy) v_u_8
	v_u_117("Impact", p1744, v_u_58, 0.7)
	local v1745 = v_u_247(CFrame.new(p1744), 1.6, v_u_58, v_u_15.Ring, 0.15, 0)
	v_u_8.tween(v1745, 0.3, {
		["Size"] = Vector3.new(6, 0.05, 6)
	})
end
v_u_551.seal_ray = {
	["cast"] = function(p1747) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_58, (copy) v_u_247, (copy) v_u_15
		v_u_557(p1747, v_u_58, 0.8)
		if not p1747.lite then
			local v1748 = v_u_247
			local v1749 = p1747.eye + p1747.dir * 1
			local v1750 = p1747.dir
			local v1751 = v1750.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1750.Unit
			local v1752 = v1751.Y
			local v1753 = math.abs(v1752) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			v1748(CFrame.lookAt(v1749, v1749 + v1751, v1753) * CFrame.Angles(-1.5707963267948966, 0, 0), 1.2 * p1747.size, v_u_58, v_u_15.Ring, 0.08, 6)
		end
	end,
	["beam"] = function(p1754, p1755, p1756) -- name: beam
		-- upvalues: (copy) v_u_200, (copy) v_u_168, (copy) v_u_59, (copy) v_u_58, (copy) v_u_8, (copy) v_u_247, (copy) v_u_15
		local v1757 = p1754.size
		v_u_200(v_u_168(p1755, p1756, 0.5 * v1757, v_u_59), 0.18)
		v_u_200(v_u_168(p1755, p1756, 1.4 * v1757, v_u_58, 0.45), 0.16)
		if not p1754.lite then
			local v1758 = v_u_58
			local v1759 = 2.8 * v1757
			local v1760 = v_u_8.beam(p1755, p1756, v1758, v1759, 0.18, nil)
			v1760.LightEmission = 0.55
			v1760.Brightness = 1.6
			local v1761 = (p1756 - p1755).Unit
			for v1762 = 1, 2 do
				local v1763 = v_u_247
				local v1764 = p1755 + v1761 * (v1762 * 9)
				local v1765 = v1761.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1761.Unit
				local v1766 = v1765.Y
				local v1767 = math.abs(v1766) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v1768 = v1763(CFrame.lookAt(v1764, v1764 + v1765, v1767) * CFrame.Angles(-1.5707963267948966, 0, 0), 1.4 * v1757, v_u_59, v_u_15.Ring, 0.1, 0)
				local v1769 = v_u_8.tween
				local v1770 = {}
				local v1771 = 5 * v1757
				local v1772 = 5 * v1757
				v1770.Size = Vector3.new(v1771, 0.05, v1772)
				v1769(v1768, 0.2, v1770)
			end
		end
		v_u_8.flash(p1755, v_u_58, 3, 0.12)
	end,
	["hit"] = function(p1773, p1774, p1775) -- name: hit
		-- upvalues: (copy) v_u_1746, (copy) v_u_10
		v_u_1746(p1773, p1774, p1775)
		if not p1773.struck then
			p1773.struck = true
			v_u_10.play("Orb", {
				["at"] = nil,
				["volume"] = 0.3,
				["at"] = p1774
			})
		end
	end
}
local function v_u_1824(p1776, p_u_1777, p1778, p_u_1779) -- name: bloom
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_58, (copy) v_u_59, (copy) v_u_1, (ref) v_u_67
	local v1780 = p1776.X
	local v1781 = v_u_18 + 0.3
	local v1782 = p1776.Z
	local v_u_1783 = Vector3.new(v1780, v1781, v1782)
	local v1784 = p1778 and 6 or 8
	local v_u_1785 = {}
	for v1786 = 1, v1784 do
		local v1787 = p_u_1777 * 0.62
		local v1788 = {
			["p"] = nil,
			["a"] = nil,
			["len"] = nil,
			["inner"] = false
		}
		local v1789 = v_u_8.part
		local v1790 = p_u_1777 * 0.3
		v1788.p = v1789(Vector3.new(v1790, 0.35, v1787), CFrame.new(v_u_1783), v_u_58, {
			["transparency"] = 0.2
		})
		v1788.a = v1786 / v1784 * 3.141592653589793 * 2
		v1788.len = v1787
		table.insert(v_u_1785, v1788)
	end
	local v1791 = p1778 and 4 or 6
	for v1792 = 1, v1791 do
		local v1793 = p_u_1777 * 0.4
		local v1794 = {
			["p"] = nil,
			["a"] = nil,
			["len"] = nil,
			["inner"] = true
		}
		local v1795 = v_u_8.part
		local v1796 = p_u_1777 * 0.22
		v1794.p = v1795(Vector3.new(v1796, 0.3, v1793), CFrame.new(v_u_1783), v_u_59, {
			["transparency"] = 0.1
		})
		v1794.a = (v1792 + 0.5) / v1791 * 3.141592653589793 * 2
		v1794.len = v1793
		table.insert(v_u_1785, v1794)
	end
	for _, v1797 in v_u_1785 do
		v_u_1:AddItem(v1797.p, p_u_1779 + 1.5)
	end
	local v_u_1798 = os.clock()
	local v_u_1799 = nil
	local function v1821()
		-- upvalues: (copy) v_u_1798, (ref) v_u_1799, (copy) v_u_1785, (copy) v_u_1783, (copy) p_u_1777, (copy) p_u_1779
		local v1800 = os.clock()
		local v1801 = (v1800 - v_u_1798) / 0.25
		local v1802 = 1 - (1 - math.clamp(v1801, 0, 1)) ^ 3
		if v_u_1799 then
			local v1803 = (v1800 - v_u_1799) / 0.25
			v1802 = v1802 * (1 - math.clamp(v1803, 0, 1))
		end
		local v1804 = (v1800 - v_u_1798) * 3
		local v1805 = math.sin(v1804) * 0.05
		for _, v1806 in v_u_1785 do
			local v1807
			if v1806.inner then
				local v1808 = 80 - v1802 * 35
				v1807 = math.rad(v1808)
			else
				local v1809 = 84 - v1802 * 58
				v1807 = math.rad(v1809)
			end
			local v1810 = v1807 + v1805
			local v1811 = v1806.a
			local v1812 = math.cos(v1811)
			local v1813 = v1806.a
			local v1814 = math.sin(v1813)
			local v1815 = Vector3.new(v1812, 0, v1814)
			local v1816 = v_u_1783
			local v1817
			if v1806.inner then
				v1817 = p_u_1777 * 0.06
			else
				v1817 = p_u_1777 * 0.14
			end
			local v1818 = v1816 + v1815 * v1817
			local v1819 = v1815 * math.cos(v1810) + Vector3.new(0, 1, 0) * math.sin(v1810)
			v1806.p.CFrame = CFrame.lookAt(v1818 + v1819 * v1806.len / 2, v1818 + v1819 * v1806.len)
		end
		if not v_u_1799 or v1800 - v_u_1799 <= 0.3 then
			return v1800 - v_u_1798 < p_u_1779 + 1
		end
		for _, v1820 in v_u_1785 do
			v1820.p:Destroy()
		end
		return false
	end
	local v1822 = v_u_67
	table.insert(v1822, v1821)
	return function()
		-- upvalues: (ref) v_u_1799, (copy) v_u_1785, (ref) v_u_8
		v_u_1799 = os.clock()
		for _, v1823 in v_u_1785 do
			v_u_8.tween(v1823.p, 0.28, {
				["Transparency"] = 1
			})
		end
	end
end
v_u_551.lotus = {
	["cast"] = function(p1825) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_58
		v_u_575(p1825, v_u_58)
	end,
	["windup"] = function(p1826, p1827, p1828) -- name: windup
		-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_58, (copy) v_u_15
		local v1829 = v_u_8.ring
		local v1830 = p1827.X
		local v1831 = v_u_18 + 0.2
		local v1832 = p1827.Z
		v1829(Vector3.new(v1830, v1831, v1832), v_u_58, p1826.ability.radius, p1828 + 0.15, v_u_15.Ring)
	end,
	["zone"] = function(p1833, p_u_1834, p1835) -- name: zone
		-- upvalues: (copy) v_u_18, (copy) v_u_1824, (copy) v_u_247, (copy) v_u_58, (copy) v_u_15, (copy) v_u_180, (copy) v_u_59, (copy) v_u_1, (copy) v_u_117, (copy) v_u_10, (copy) v_u_139, (copy) v_u_8, (copy) v_u_200
		local v_u_1836 = p1833.ability.radius
		local v1837 = p_u_1834.X
		local v1838 = v_u_18 + 0.2
		local v1839 = p_u_1834.Z
		local v_u_1840 = Vector3.new(v1837, v1838, v1839)
		local v_u_1841 = v_u_1824(p_u_1834, v_u_1836, p1833.lite, p1835)
		local v1842 = v_u_247
		local v1843 = CFrame.new
		local v1844 = p_u_1834.X
		local v1845 = v_u_18 + 0.14
		local v1846 = p_u_1834.Z
		v1842(v1843((Vector3.new(v1844, v1845, v1846))), v_u_1836, v_u_58, v_u_15.MagicCircle, p1835, 1.2)
		local v_u_1847 = v_u_180(v_u_1840, 8, 2.2, v_u_59, 0.55)
		v_u_1:AddItem(v_u_1847, p1835 + 1)
		local v1848 = v_u_117
		local v1849 = p_u_1834.X
		local v1850 = v_u_18 + 2
		local v1851 = p_u_1834.Z
		v1848("Flash", Vector3.new(v1849, v1850, v1851), v_u_58, 0.6)
		v_u_117("Shockwave", v_u_1840 + Vector3.new(0, 0.3, 0), v_u_58, v_u_1836 / 18)
		v_u_10.play("Orb", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v_u_1840
		})
		local v_u_1852 = {}
		local v1853 = v_u_139
		local v1854 = p_u_1834.X
		local v1855 = v_u_18 + 1
		local v1856 = p_u_1834.Z
		__set_list(v_u_1852, 1, {(v1853("Petals", Vector3.new(v1854, v1855, v1856), v_u_58, v_u_1836 / 11))})
		if p1833.mine then
			v_u_8.shake(0.15, 0.2)
		end
		return function()
			-- upvalues: (copy) v_u_1841, (copy) v_u_1852, (ref) v_u_200, (copy) v_u_1847, (ref) v_u_117, (copy) p_u_1834, (ref) v_u_18, (ref) v_u_58, (ref) v_u_8, (copy) v_u_1840, (ref) v_u_59, (copy) v_u_1836, (ref) v_u_15
			v_u_1841()
			for _, v1857 in v_u_1852 do
				v1857()
			end
			v_u_200(v_u_1847, 0.25)
			local v1858 = v_u_117
			local v1859 = p_u_1834
			local v1860 = v1859.X
			local v1861 = v_u_18 + 2
			local v1862 = v1859.Z
			v1858("Flash", Vector3.new(v1860, v1861, v1862), v_u_58, 0.5)
			v_u_8.ring(v_u_1840, v_u_59, v_u_1836, 0.35, v_u_15.Ring)
		end
	end,
	["hit"] = v_u_1746
}
v_u_551.prophecy = {
	["cast"] = function(p1863) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_58
		v_u_575(p1863, v_u_58, true)
	end,
	["windup"] = function(p1864, p1865, p1866) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_58, (copy) v_u_15
		local v1867 = v_u_247
		local v1868 = CFrame.new
		local v1869 = p1865.X
		local v1870 = v_u_18 + 0.15
		local v1871 = p1865.Z
		v1867(v1868((Vector3.new(v1869, v1870, v1871))), p1864.ability.radius, v_u_58, v_u_15.MagicCircle, p1866 + 0.3, 1)
	end,
	["strike"] = function(p_u_1872, p_u_1873, p1874) -- name: strike
		-- upvalues: (copy) v_u_18, (copy) v_u_247, (copy) v_u_58, (copy) v_u_15, (copy) v_u_180, (copy) v_u_59, (copy) v_u_1, (copy) v_u_200, (copy) v_u_117, (copy) v_u_8, (copy) v_u_265, (copy) v_u_10
		local v_u_1875 = p_u_1872.ability.strikeRadius or 8
		local v1876 = p_u_1873.X
		local v1877 = v_u_18 + 0.2
		local v1878 = p_u_1873.Z
		local v_u_1879 = Vector3.new(v1876, v1877, v1878)
		local v1880 = v_u_247
		local v1881 = CFrame.new
		local v1882 = p_u_1873.X
		local v1883 = v_u_18 + 0.17
		local v1884 = p_u_1873.Z
		v1880(v1881((Vector3.new(v1882, v1883, v1884))), v_u_1875, v_u_58, v_u_15.Ring, math.max(p1874, 0.05), 2)
		v_u_1:AddItem(v_u_180(v_u_1879, 40, 0.6, v_u_59, 0.6), math.max(p1874, 0) + 0.02)
		local function v1886()
			-- upvalues: (ref) v_u_200, (ref) v_u_180, (copy) v_u_1879, (copy) v_u_1875, (ref) v_u_58, (ref) v_u_59, (ref) v_u_117, (ref) v_u_8, (ref) v_u_265, (copy) p_u_1873, (ref) v_u_10, (copy) p_u_1872
			v_u_200(v_u_180(v_u_1879, 44, v_u_1875 * 2, v_u_58, 0.45), 0.45, true)
			v_u_200(v_u_180(v_u_1879, 44, v_u_1875 * 1.1, v_u_59, 0), 0.35, true)
			v_u_117("Flash", v_u_1879 + Vector3.new(0, 2, 0), v_u_58, 0.45)
			v_u_8.ring(v_u_1879, v_u_58, v_u_1875 * 1.2, 0.35)
			v_u_265(p_u_1873, v_u_58, v_u_1875 * 0.8, 0.9, nil, 0.3)
			local v1885 = {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v_u_1879
			}
			v_u_10.play("Hit", v1885)
			if p_u_1872.mine then
				v_u_8.shake(0.18, 0.15)
			end
		end
		if p1874 > 0.005 then
			task.delay(p1874, v1886)
		else
			v1886()
		end
	end,
	["hit"] = v_u_1746
}
local v1900 = {
	["cast"] = function(p1887) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_60
		v_u_557(p1887, v_u_60)
	end,
	["shot"] = function(p1888, p1889) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_61, (copy) v_u_60, (copy) v_u_33
		return v_u_514(p1888, p1889, {
			["core"] = nil,
			["coreSize"] = 1.7,
			["shell"] = nil,
			["shellSize"] = 2.9,
			["shellAlpha"] = 0.45,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.7,
			["loop"] = "Vortex",
			["loopColor"] = nil,
			["loopScale"] = 0.3,
			["core"] = v_u_61,
			["shell"] = v_u_60,
			["trail"] = v_u_60,
			["trailEnd"] = v_u_33,
			["loopColor"] = v_u_60
		})
	end,
	["impact"] = function(p1890, p_u_1891) -- name: impact
		-- upvalues: (copy) v_u_152, (copy) v_u_60, (copy) v_u_8, (copy) v_u_1, (copy) v_u_342, (copy) v_u_117, (copy) v_u_18, (copy) v_u_15, (copy) v_u_209, (copy) v_u_33, (copy) v_u_10
		local v_u_1892 = p1890.size
		local v1893 = p1890.ability.radius
		local v1894 = v_u_152(p_u_1891, v_u_60, v1893 * 1.6 * v_u_1892, 0.6)
		v_u_8.tween(v1894, 0.14, {
			["Size"] = Vector3.new(0.5, 0.5, 0.5),
			["Transparency"] = 0.2
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_1:AddItem(v1894, 0.15)
		if not p1890.lite then
			v_u_342(p_u_1891, v_u_60, 5, v1893 * 1.2 * v_u_1892, 0.14)
		end
		task.delay(0.13, function()
			-- upvalues: (ref) v_u_117, (copy) p_u_1891, (ref) v_u_60, (copy) v_u_1892, (ref) v_u_8, (ref) v_u_18, (ref) v_u_15, (ref) v_u_209, (ref) v_u_33
			v_u_117("Impact", p_u_1891, v_u_60, 1.2 * v_u_1892)
			local v1895 = v_u_8.ring
			local v1896 = p_u_1891
			local v1897 = v1896.X
			local v1898 = v_u_18 + 0.2
			local v1899 = v1896.Z
			v1895(Vector3.new(v1897, v1898, v1899), v_u_60, 5 * v_u_1892, 0.3, v_u_15.Ring)
			v_u_209(p_u_1891, v_u_33, 1, 4 * v_u_1892, 0.14)
		end)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p_u_1891
		})
	end
}
local v_u_1901 = 0.6
function v1900.hit(_, p1902, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_60, (copy) v_u_1901
	v_u_117("Impact", p1902, v_u_60, v_u_1901)
end
v_u_551.blue = v1900
local v1923 = {
	["cast"] = function(p1903) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_62, (copy) v_u_557, (copy) v_u_117
		v_u_575(p1903, v_u_62)
		v_u_557(p1903, v_u_62, 1.6)
		v_u_117("Flash", p1903.eye + p1903.dir, v_u_62, 0.4)
	end,
	["shot"] = function(p1904, p1905) -- name: shot
		-- upvalues: (copy) v_u_514, (copy) v_u_33, (copy) v_u_62
		return v_u_514(p1904, p1905, {
			["core"] = nil,
			["coreSize"] = 2.2,
			["shell"] = nil,
			["shellSize"] = 4.4,
			["shellAlpha"] = 0.25,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 3.6,
			["loop"] = "Trail",
			["loopColor"] = nil,
			["loopScale"] = 1,
			["orbit"] = nil,
			["orbitCount"] = 4,
			["orbitRadius"] = 2.6,
			["orbitSize"] = 0.7,
			["orbitSpeed"] = 20,
			["core"] = v_u_33,
			["shell"] = v_u_62,
			["trail"] = v_u_62,
			["trailEnd"] = Color3.fromRGB(120, 0, 20),
			["loopColor"] = v_u_62,
			["orbit"] = v_u_62
		})
	end,
	["impact"] = function(p1906, p1907) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_62, (copy) v_u_18, (copy) v_u_152, (copy) v_u_8, (copy) v_u_1, (copy) v_u_209, (copy) v_u_33, (copy) v_u_315, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_35, (copy) v_u_15, (copy) v_u_10
		local v1908 = p1906.size
		local v1909 = p1906.ability.radius
		v_u_117("Explosion", p1907, v_u_62, 1.8 * v1908)
		local v1910 = v_u_117
		local v1911 = p1907.X
		local v1912 = v_u_18 + 0.5
		local v1913 = p1907.Z
		v1910("Shockwave", Vector3.new(v1911, v1912, v1913), v_u_62, v1909 / 16)
		local v1914 = v_u_152(p1907, v_u_62, 3, 0, Enum.Material.ForceField)
		v_u_8.tween(v1914, 0.35, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(1, 1, 1) * v1909 * 2.2
		}, Enum.EasingStyle.Quart)
		v_u_1:AddItem(v1914, 0.37)
		v_u_209(p1907, v_u_33, 3, v1909 * 0.9, 0.2, 0.1)
		v_u_315(p1907, v_u_62, 10, v1909 * 0.9, 0.3, nil, nil, true)
		local v1915 = v_u_8.ring
		local v1916 = p1907.X
		local v1917 = v_u_18 + 0.2
		local v1918 = p1907.Z
		v1915(Vector3.new(v1916, v1917, v1918), v_u_62, v1909 * 1.1, 0.45)
		if not p1906.lite then
			local v1919 = v_u_405
			local v1920 = p1907.X
			local v1921 = v_u_18 + 1
			local v1922 = p1907.Z
			v1919(Vector3.new(v1920, v1921, v1922), v_u_36, 10, 38, 1, 0.9, false, 0.6)
		end
		v_u_265(p1907, v_u_35, v1909 * 0.55, 1.5)
		v_u_265(p1907, v_u_62, v1909 * 0.6, 1, v_u_15.CrackGlow, 0.2)
		v_u_10.play("Explosion", {
			["at"] = nil,
			["volume"] = 1,
			["at"] = p1907
		})
		if p1906.mine then
			v_u_8.shake(0.45, 0.35)
		end
	end
}
local v_u_1924 = 0.8
function v1923.hit(_, p1925, _)
	-- upvalues: (copy) v_u_117, (copy) v_u_62, (copy) v_u_1924
	v_u_117("Impact", p1925, v_u_62, v_u_1924)
end
v_u_551.red = v1923
v_u_551.purple = {
	["cast"] = function(p1926) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_63
		v_u_575(p1926, v_u_63, true)
	end,
	["windup"] = function(p1927, p1928, p1929) -- name: windup
		-- upvalues: (copy) v_u_152, (copy) v_u_33, (copy) v_u_60, (copy) v_u_62, (copy) v_u_209, (copy) v_u_63, (copy) v_u_117, (ref) v_u_67
		local v_u_1930 = p1927.dir:Cross(Vector3.new(0, 1, 0))
		local v_u_1931 = p1928 + p1927.dir * 3
		local v_u_1932 = {
			{
				["core"] = nil,
				["shell"] = nil,
				["side"] = 1,
				["core"] = v_u_152(p1928, v_u_33, 1.4, 0),
				["shell"] = v_u_152(p1928, v_u_60, 2.6, 0.35)
			},
			{
				["core"] = nil,
				["shell"] = nil,
				["side"] = -1,
				["core"] = v_u_152(p1928, v_u_33, 1.4, 0),
				["shell"] = v_u_152(p1928, v_u_62, 2.6, 0.35)
			}
		}
		local v1933 = p1929 * 0.9
		local v1934 = math.max(v1933, 0.05)
		local function v_u_1941(p1935)
			-- upvalues: (copy) v_u_1932, (copy) v_u_1931, (copy) v_u_1930, (ref) v_u_209, (ref) v_u_63, (ref) v_u_117
			local v1936 = 4.5 * (1 - p1935)
			local v1937 = p1935 * 3.141592653589793 * 1.5
			for _, v1938 in v_u_1932 do
				local v1939 = v_u_1931 + v_u_1930 * v1938.side * v1936 * math.cos(v1937) + Vector3.new(0, 1, 0) * v1938.side * v1936 * math.sin(v1937) * 0.6
				v1938.core.CFrame = CFrame.new(v1939)
				v1938.shell.CFrame = CFrame.new(v1939)
			end
			if p1935 >= 1 then
				for _, v1940 in v_u_1932 do
					v1940.core:Destroy()
					v1940.shell:Destroy()
				end
				v_u_209(v_u_1931, v_u_63, 2, 9, 0.2, 0.1)
				v_u_117("Flash", v_u_1931, v_u_63, 0.7)
			end
		end
		local v_u_1942 = math.max(v1934, 0.001)
		local v_u_1943 = os.clock() - 0
		local v1944 = 0 / v_u_1942
		local v1945 = math.clamp(v1944, 0, 1)
		v_u_1941(v1945)
		if v1945 < 1 then
			local v1946 = v_u_67
			table.insert(v1946, function()
				-- upvalues: (copy) v_u_1943, (copy) v_u_1942, (copy) v_u_1941
				local v1947 = (os.clock() - v_u_1943) / v_u_1942
				local v1948 = math.clamp(v1947, 0, 1)
				v_u_1941(v1948)
				return v1948 < 1
			end)
		end
	end,
	["beam"] = function(p1949, p1950, p_u_1951) -- name: beam
		-- upvalues: (copy) v_u_152, (copy) v_u_63, (copy) v_u_64, (copy) v_u_461, (copy) v_u_8, (copy) v_u_1, (ref) v_u_67, (copy) v_u_200, (copy) v_u_168, (copy) v_u_292, (copy) v_u_450, (copy) v_u_117, (copy) v_u_10
		local v_u_1952 = p1949.size
		local v_u_1953 = p1950 + p1949.dir * 3
		local v_u_1954 = v_u_152(v_u_1953, v_u_63, 10 * v_u_1952, 0.15)
		local v_u_1955 = v_u_152(v_u_1953, v_u_64, 5.5 * v_u_1952, 0)
		v_u_461(v_u_1954, v_u_63, Color3.fromRGB(80, 20, 140), 10 * v_u_1952, 0.35)
		local function v_u_1959(p1956)
			-- upvalues: (copy) v_u_1953, (copy) p_u_1951, (copy) v_u_1954, (copy) v_u_1955, (ref) v_u_8, (copy) v_u_1952, (ref) v_u_1
			local v1957 = v_u_1953:Lerp(p_u_1951, p1956)
			v_u_1954.CFrame = CFrame.new(v1957)
			v_u_1955.CFrame = CFrame.new(v1957)
			if p1956 >= 1 then
				v_u_8.tween(v_u_1954, 0.3, {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(22, 22, 22) * v_u_1952
				})
				local v1958 = v_u_1955
				v_u_8.tween(v1958, 0.2, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v1958, 0.25)
				v_u_1:AddItem(v_u_1954, 0.6)
			end
		end
		local v_u_1960 = os.clock() - 0
		local v1961 = v_u_1953:Lerp(p_u_1951, 0)
		v_u_1954.CFrame = CFrame.new(v1961)
		v_u_1955.CFrame = CFrame.new(v1961)
		local v_u_1962 = 0.28
		local v1963 = v_u_67
		table.insert(v1963, function()
			-- upvalues: (copy) v_u_1960, (copy) v_u_1962, (copy) v_u_1959
			local v1964 = (os.clock() - v_u_1960) / v_u_1962
			local v1965 = math.clamp(v1964, 0, 1)
			v_u_1959(v1965)
			return v1965 < 1
		end)
		local v1966 = v_u_63
		local v1967 = 16 * v_u_1952
		local v1968 = v_u_8.beam(v_u_1953, p_u_1951, v1966, v1967, 0.75, nil)
		v1968.LightEmission = 0.55
		v1968.Brightness = 1.6
		v_u_200(v_u_168(v_u_1953, p_u_1951, 9 * v_u_1952, v_u_63, 0.55), 0.7, true)
		v_u_292(p1950, p_u_1951, 8 * v_u_1952, Color3.fromRGB(45, 12, 70), 2.2, 0.15)
		v_u_450(v_u_1953, p_u_1951, 16, 0.28, function(p1969)
			-- upvalues: (ref) v_u_117, (ref) v_u_63
			v_u_117("Explosion", p1969, v_u_63, 1.4)
		end)
		task.delay(0.28, function()
			-- upvalues: (ref) v_u_117, (copy) p_u_1951, (ref) v_u_63, (ref) v_u_10
			v_u_117("Flash", p_u_1951, v_u_63, 1.2)
			local v1970 = {
				["at"] = p_u_1951
			}
			v_u_10.play("Explosion", v1970)
		end)
		if p1949.mine then
			v_u_8.shake(0.6, 0.5)
		end
	end,
	["hit"] = function(_, p1971, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_63
		v_u_117("Impact", p1971, v_u_63, 1.3)
	end
}
v_u_551.god_ray = {
	["cast"] = function(p1972) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_65, (copy) v_u_247, (copy) v_u_15
		v_u_557(p1972, v_u_65, 0.9)
		if not p1972.lite then
			local v1973 = v_u_247
			local v1974 = p1972.eye + p1972.dir * 0.9
			local v1975 = p1972.dir
			local v1976 = v1975.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v1975.Unit
			local v1977 = v1976.Y
			local v1978 = math.abs(v1977) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			v1973(CFrame.lookAt(v1974, v1974 + v1976, v1978) * CFrame.Angles(-1.5707963267948966, 0, 0), 1.3 * p1972.size, v_u_65, v_u_15.Ring, 0.08, 5)
		end
	end,
	["beam"] = function(p1979, p1980, p1981) -- name: beam
		-- upvalues: (copy) v_u_200, (copy) v_u_168, (copy) v_u_33, (copy) v_u_65, (copy) v_u_66, (copy) v_u_8
		local v1982 = p1979.size
		v_u_200(v_u_168(p1980, p1981, 0.5 * v1982, v_u_33), 0.17)
		v_u_200(v_u_168(p1980, p1981, 1.5 * v1982, v_u_65, 0.35), 0.15)
		if not p1979.lite then
			local v1983 = v_u_66
			local v1984 = 3 * v1982
			local v1985 = v_u_8.beam(p1980, p1981, v1983, v1984, 0.18, nil)
			v1985.LightEmission = 0.55
			v1985.Brightness = 1.6
			v_u_8.flash(p1980:Lerp(p1981, 0.3333333333333333), v_u_65, 2.4 * v1982, 0.14)
			v_u_8.flash(p1980:Lerp(p1981, 0.6666666666666666), v_u_65, 2.4 * v1982, 0.14)
		end
		v_u_8.flash(p1980, v_u_65, 3 * v1982, 0.12)
	end,
	["hit"] = function(p1986, p1987, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_65, (copy) v_u_359, (copy) v_u_66, (copy) v_u_10
		v_u_117("Impact", p1987, v_u_65, 0.75)
		v_u_359(p1987, v_u_66, 4, 0.16)
		if not p1986.struck then
			p1986.struck = true
			v_u_10.play("Orb", {
				["at"] = nil,
				["volume"] = 0.3,
				["at"] = p1987
			})
		end
	end
}
v_u_551.divine_swords = {
	["cast"] = function(p1988) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_65, (copy) v_u_359, (copy) v_u_66
		v_u_575(p1988, v_u_65)
		v_u_359(p1988.eye, v_u_66, 5, 0.2)
	end,
	["windup"] = function(p1989, p1990, p1991) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_247, (copy) v_u_65, (copy) v_u_15, (copy) v_u_66, (copy) v_u_117
		local v1992 = p1989.ability.radius
		local v1993 = p1990.X
		local v1994 = v_u_18 + 22
		local v1995 = p1990.Z
		local v1996 = Vector3.new(v1993, v1994, v1995)
		v_u_247(CFrame.new(v1996), v1992 * 0.85, v_u_65, v_u_15.MagicCircle, p1991 + 0.3, 2)
		v_u_247(CFrame.new(v1996 + Vector3.new(0, 0.3, 0)), v1992, v_u_66, v_u_15.Ring, p1991 + 0.3, -1.5)
		v_u_117("Flash", v1996, v_u_65, 0.7)
		local v1997 = v_u_247
		local v1998 = CFrame.new
		local v1999 = p1990.X
		local v2000 = v_u_18 + 0.15
		local v2001 = p1990.Z
		v1997(v1998((Vector3.new(v1999, v2000, v2001))), v1992, v_u_65, v_u_15.Ring, p1991 + 0.3, 1)
	end,
	["strike"] = function(p2002, p2003, p2004) -- name: strike
		-- upvalues: (copy) v_u_18, (copy) v_u_1398, (copy) v_u_550, (copy) v_u_117, (copy) v_u_65, (copy) v_u_8, (copy) v_u_15, (copy) v_u_359, (copy) v_u_66, (copy) v_u_265, (copy) v_u_10
		local v_u_2005 = p2002.ability.strikeRadius or 6
		local v2006 = p2003.X
		local v2007 = v_u_18 + 22
		local v2008 = p2003.Z
		local v2009 = Vector3.new(v2006, v2007, v2008)
		local v2010 = v_u_1398
		local v2011 = v_u_550
		local v2012 = p2003.X
		local v2013 = v_u_18 + 2.2
		local v2014 = p2003.Z
		v2010(p2002, v2011, v2009, Vector3.new(v2012, v2013, v2014), 0.16, p2004, 0.35, function(p2015)
			-- upvalues: (ref) v_u_117, (ref) v_u_18, (ref) v_u_65, (ref) v_u_8, (copy) v_u_2005, (ref) v_u_15, (ref) v_u_359, (ref) v_u_66, (ref) v_u_265, (ref) v_u_10
			local v2016 = v_u_117
			local v2017 = p2015.X
			local v2018 = v_u_18 + 1
			local v2019 = p2015.Z
			v2016("Impact", Vector3.new(v2017, v2018, v2019), v_u_65, 1.1)
			local v2020 = v_u_8.ring
			local v2021 = p2015.X
			local v2022 = v_u_18 + 0.2
			local v2023 = p2015.Z
			v2020(Vector3.new(v2021, v2022, v2023), v_u_65, v_u_2005, 0.3, v_u_15.Ring)
			local v2024 = v_u_359
			local v2025 = p2015.X
			local v2026 = v_u_18 + 1.5
			local v2027 = p2015.Z
			v2024(Vector3.new(v2025, v2026, v2027), v_u_66, 6, 0.2)
			v_u_265(p2015, v_u_65, v_u_2005 * 0.5, 0.8, nil, 0.3)
			v_u_10.play("Hit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = p2015
			})
		end)
	end,
	["hit"] = function(_, p2028, _) -- name: divineHit
		-- upvalues: (copy) v_u_117, (copy) v_u_65, (copy) v_u_359, (copy) v_u_66
		v_u_117("Impact", p2028, v_u_65, 0.75)
		v_u_359(p2028, v_u_66, 4, 0.16)
	end
}
v_u_551.heavens_gaze = {
	["cast"] = function(p2029) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_65, (copy) v_u_117
		v_u_575(p2029, v_u_65, true)
		v_u_117("Flash", p2029.eye, v_u_65, 0.5)
	end,
	["windup"] = function(p2030, p2031, p2032) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_247, (copy) v_u_33, (copy) v_u_14, (copy) v_u_15, (copy) v_u_65, (copy) v_u_66, (copy) v_u_117, (copy) v_u_180, (copy) v_u_1
		local v2033 = p2030.ability.radius
		local v2034 = p2031.X
		local v2035 = v_u_18 + 30
		local v2036 = p2031.Z
		local v2037 = Vector3.new(v2034, v2035, v2036)
		local v2038 = p2032 + 0.5
		local v2039 = v_u_6.CurrentCamera
		local v2040 = not v2039 and Vector3.new(-0, -1, -0) or (v2039.CFrame.Position - v2037).Unit
		local v2041 = v_u_247
		local v2042 = v2040.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2040.Unit
		local v2043 = v2042.Y
		local v2044 = math.abs(v2043) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v2045 = CFrame.lookAt(v2037, v2037 + v2042, v2044) * CFrame.Angles(-1.5707963267948966, 0, 0)
		local v2046 = v_u_33
		local v2047 = v_u_14.Iris.senrigan or v_u_15.MagicCircle
		v2041(v2045, 8, v2046, v_u_14.Iris.all_seeing or (v2047 or v_u_15.MagicCircle), v2038, 0.5)
		local v2048 = v_u_247
		local v2049 = v2037 - v2040 * 0.3
		local v2050 = v2040.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2040.Unit
		local v2051 = v2050.Y
		local v2052 = math.abs(v2051) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v2048(CFrame.lookAt(v2049, v2049 + v2050, v2052) * CFrame.Angles(-1.5707963267948966, 0, 0), 11, v_u_65, v_u_15.Ring, v2038, 2)
		local v2053 = v_u_247
		local v2054 = v2037 - v2040 * 0.6
		local v2055 = v2040.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2040.Unit
		local v2056 = v2055.Y
		local v2057 = math.abs(v2056) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v2053(CFrame.lookAt(v2054, v2054 + v2055, v2057) * CFrame.Angles(-1.5707963267948966, 0, 0), 14.5, v_u_66, v_u_15.Ring, v2038, -1.2)
		v_u_117("Flash", v2037, v_u_65, 0.45)
		local v2058 = v_u_247
		local v2059 = CFrame.new
		local v2060 = p2031.X
		local v2061 = v_u_18 + 0.15
		local v2062 = p2031.Z
		v2058(v2059((Vector3.new(v2060, v2061, v2062))), v2033, v_u_65, v_u_15.MagicCircle, p2032 + 0.8, 3)
		for v2063 = 1, 4 do
			local v2064 = v2063 / 4 * 3.141592653589793 * 2
			local v2065 = v_u_180
			local v2066 = p2031.X
			local v2067 = v_u_18 + 0.2
			local v2068 = p2031.Z
			local v2069 = Vector3.new(v2066, v2067, v2068)
			local v2070 = math.cos(v2064)
			local v2071 = math.sin(v2064)
			v_u_1:AddItem(v2065(v2069 + Vector3.new(v2070, 0, v2071) * v2033 * 0.6, 30, 0.5, v_u_66, 0.55), p2032 + 0.02)
		end
	end,
	["land"] = function(p2072, p2073) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_200, (copy) v_u_180, (copy) v_u_65, (copy) v_u_33, (copy) v_u_117, (copy) v_u_8, (copy) v_u_15, (copy) v_u_66, (copy) v_u_359, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_10
		local v2074 = p2072.ability.radius
		local v2075 = p2073.X
		local v2076 = v_u_18 + 0.2
		local v2077 = p2073.Z
		local v2078 = Vector3.new(v2075, v2076, v2077)
		v_u_200(v_u_180(v2078, 34, v2074 * 1.2, v_u_65, 0.35), 0.55, true)
		v_u_200(v_u_180(v2078, 34, v2074 * 0.55, v_u_33, 0), 0.4, true)
		local v2079 = v_u_117
		local v2080 = p2073.X
		local v2081 = v_u_18 + 2
		local v2082 = p2073.Z
		v2079("Explosion", Vector3.new(v2080, v2081, v2082), v_u_65, 2.5)
		local v2083 = v_u_117
		local v2084 = v2078 + Vector3.new(0, 0.3, 0)
		local v2085 = v_u_65
		local v2086 = v2074 / 16
		v2083("Shockwave", v2084, v2085, (math.min(v2086, 1.6)))
		local v2087 = v_u_117
		local v2088 = p2073.X
		local v2089 = v_u_18 + 3
		local v2090 = p2073.Z
		v2087("Sparkle", Vector3.new(v2088, v2089, v2090), nil, 1.5)
		v_u_8.ring(v2078, v_u_65, v2074, 0.6)
		v_u_8.ring(v2078, v_u_33, v2074 * 1.3, 0.5, v_u_15.Ring)
		v_u_8.ring(v2078, v_u_66, v2074 * 1.1, 0.4, v_u_15.SpeedLines)
		local v2091 = v_u_359
		local v2092 = p2073.X
		local v2093 = v_u_18 + 6
		local v2094 = p2073.Z
		v2091(Vector3.new(v2092, v2093, v2094), v_u_66, 18, 0.35)
		local v2095 = v_u_405
		local v2096 = p2073.X
		local v2097 = v_u_18 + 1
		local v2098 = p2073.Z
		v2095(Vector3.new(v2096, v2097, v2098), { v_u_36[1], v_u_36[2], v_u_65 }, p2072.lite and 5 or 12, 40, 1.3, 1.1)
		v_u_265(p2073, v_u_65, v2074 * 0.7, 2, v_u_15.CrackGlow, 0.15)
		v_u_10.play("Explosion", {
			["at"] = v2078
		})
		if p2072.mine then
			v_u_8.shake(0.6, 0.5)
		end
	end,
	["hit"] = function(_, p2099, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_65, (copy) v_u_359, (copy) v_u_66
		v_u_117("Impact", p2099, v_u_65, 1.2)
		v_u_359(p2099, v_u_66, 6, 0.2)
	end
}
local function v2102(p2100) -- name: runNow
	-- upvalues: (ref) v_u_67
	if p2100() then
		local v2101 = v_u_67
		table.insert(v2101, p2100)
	end
end
local function v_u_2103() -- name: newRig
	return {
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {}
	}
end
local function v_u_2115(p2104, p2105, p2106, p2107, p2108, p2109, p2110) -- name: rigAdd
	-- upvalues: (copy) v_u_8, (copy) v_u_1
	local v2111 = v_u_8.part(p2105, p2106, p2107, {
		["transparency"] = p2108,
		["material"] = p2109
	})
	v_u_1:AddItem(v2111, p2110 or 8)
	local v2112 = p2104.parts
	table.insert(v2112, v2111)
	local v2113 = p2104.offs
	table.insert(v2113, p2106)
	local v2114 = p2104.sizes
	table.insert(v2114, p2105)
	return v2111
end
local function v_u_2123(p2116, p2117, p2118) -- name: rigPlace
	local v2119 = math.max(p2118, 0.02)
	for v2120, v2121 in p2116.parts do
		local v2122 = p2116.offs[v2120]
		v2121.CFrame = p2117 * (v2122 - v2122.Position + v2122.Position * v2119)
		v2121.Size = p2116.sizes[v2120] * v2119
	end
end
local v_u_2124 = v32(236, 232, 250)
local v_u_2125 = v32(125, 70, 235)
local v_u_2126 = v32(58, 42, 92)
local v_u_2127 = v32(26, 22, 34)
local v_u_2128 = v32(44, 40, 56)
local function v_u_2141(p2129, p2130, p2131) -- name: stakeRig
	-- upvalues: (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_2127, (copy) v_u_2125, (copy) v_u_2124
	local v2132 = v_u_2103()
	v_u_2115(v2132, Vector3.new(p2130, p2130, p2129), CFrame.identity, v_u_2127, 0, Enum.Material.SmoothPlastic, p2131)
	local v2133 = v_u_2115
	local v2134 = p2130 * 1.5
	local v2135 = p2130 * 1.5
	local v2136 = p2129 * 1.02
	v2133(v2132, Vector3.new(v2134, v2135, v2136), CFrame.identity, v_u_2125, 0.85, nil, p2131)
	local v2137 = v_u_2115
	local v2138 = p2130 * 1.25
	local v2139 = p2130 * 1.25
	local v2140 = p2130 * 2.4
	v2137(v2132, Vector3.new(v2138, v2139, v2140), CFrame.new(0, 0, -p2129 / 2) * CFrame.Angles(0, 0, 0.7853981633974483), v_u_2124, 0, nil, p2131)
	return v2132
end
local function v_u_2183(p2142, p2143, p2144, p_u_2145, p2146, p_u_2147) -- name: growStake
	-- upvalues: (copy) v_u_18, (copy) v_u_2141, (copy) v_u_2123, (copy) v_u_359, (copy) v_u_2124, (ref) v_u_67, (copy) v_u_117, (copy) v_u_2125, (copy) v_u_8, (copy) v_u_15, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_34
	local v2148 = p2144.X
	local v2149 = p2144.Z
	local v2150 = Vector3.new(v2148, 0, v2149)
	local v2151 = ((v2150.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v2150.Unit) - Vector3.new(0, 1.1, 0)).Unit
	local v2152 = p2143.X
	local v2153 = v_u_18 + -1.2
	local v2154 = p2143.Z
	local v_u_2155 = Vector3.new(v2152, v2153, v2154)
	local v_u_2156 = v_u_2141(p_u_2145, p2146, p_u_2147 + 1)
	local v2157 = v2151.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2151.Unit
	local v2158 = v2157.Y
	local v2159 = math.abs(v2158) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v_u_2160 = CFrame.lookAt(v_u_2155, v_u_2155 + v2157, v2159)
	local v_u_2161 = os.clock()
	local function v2169()
		-- upvalues: (copy) v_u_2161, (copy) p_u_2147, (ref) v_u_2123, (copy) v_u_2156, (copy) v_u_2160, (copy) p_u_2145, (ref) v_u_359, (copy) v_u_2155, (ref) v_u_2124
		local v2162 = os.clock() - v_u_2161
		local v2163
		if v2162 < 0.09 then
			local v2164 = v2162 / 0.09
			local v2165 = 0.95 * (1 - (1 - v2164) ^ 3)
			local v2166 = v2164 * 3.141592653589793
			v2163 = 0.05 + v2165 * (math.sin(v2166) * 0.15 + 1)
		elseif v2162 < p_u_2147 + 0.09 then
			v2163 = 1
		else
			local v2167 = (v2162 - 0.09 - p_u_2147) / 0.12
			v2163 = 1 - math.clamp(v2167, 0, 1) * 0.97
		end
		v_u_2123(v_u_2156, v_u_2160 * CFrame.new(0, 0, p_u_2145 * v2163 / 2), v2163)
		if p_u_2147 + 0.21 >= v2162 then
			return true
		end
		for _, v2168 in v_u_2156.parts do
			v2168:Destroy()
		end
		v_u_359(v_u_2155 + Vector3.new(0, 1, 0), v_u_2124, 3, 0.15)
		return false
	end
	if v2169() then
		local v2170 = v_u_67
		table.insert(v2170, v2169)
	end
	local v2171 = v_u_117
	local v2172 = p2143.X
	local v2173 = v_u_18 + 0.3
	local v2174 = p2143.Z
	v2171("Shockwave", Vector3.new(v2172, v2173, v2174), v_u_2125, p2146 / 3)
	local v2175 = v_u_8.ring
	local v2176 = p2143.X
	local v2177 = v_u_18 + 0.2
	local v2178 = p2143.Z
	v2175(Vector3.new(v2176, v2177, v2178), v_u_2125, p2146 * 3, 0.35, v_u_15.Ring)
	if not p2142.lite then
		local v2179 = v_u_405
		local v2180 = p2143.X
		local v2181 = v_u_18 + 0.8
		local v2182 = p2143.Z
		v2179(Vector3.new(v2180, v2181, v2182), v_u_36, 4, 26, 0.6, 0.6)
	end
	v_u_265(p2143, v_u_34, p2146 * 2.6, 1.2, v_u_15.CrackLines, 0.05)
end
local function v2185(_, p2184, _) -- name: kokuHit
	-- upvalues: (copy) v_u_117, (copy) v_u_2125, (copy) v_u_359, (copy) v_u_2124
	v_u_117("Impact", p2184, v_u_2125, 0.7)
	v_u_359(p2184, v_u_2124, 3, 0.14)
end
v_u_551.sukunahikona = {
	["cast"] = function(p2186) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_2125, (copy) v_u_359, (copy) v_u_2124
		v_u_557(p2186, v_u_2125)
		v_u_359(p2186.eye + p2186.dir * 0.8, v_u_2124, 2.6, 0.12)
	end,
	["shot"] = function(p2187, p2188) -- name: shot
		-- upvalues: (copy) v_u_539, (copy) v_u_2127, (copy) v_u_2124, (copy) v_u_2125
		return v_u_539(p2187, p2188, {
			["shaft"] = nil,
			["head"] = nil,
			["glow"] = nil,
			["length"] = 2.4,
			["thick"] = 0.24,
			["trail"] = nil,
			["trailEnd"] = nil,
			["trailWidth"] = 1.1,
			["shaft"] = v_u_2127,
			["head"] = v_u_2124,
			["glow"] = v_u_2125,
			["trail"] = v_u_2125,
			["trailEnd"] = v_u_2124
		})
	end,
	["impact"] = function(p2189, p2190) -- name: impact
		-- upvalues: (copy) v_u_2183, (copy) v_u_117, (copy) v_u_2125, (copy) v_u_10
		v_u_2183(p2189, p2190, p2189.dir, 13 * p2189.size, 1.4 * p2189.size, 0.32)
		v_u_117("Impact", p2190, v_u_2125, 1 * p2189.size)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p2190
		})
	end,
	["hit"] = v2185
}
local function v_u_2199(p2191, p2192) -- name: gateRig
	-- upvalues: (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_34, (copy) v_u_2125
	local v2193 = v_u_2103()
	v_u_2115(v2193, Vector3.new(p2191, 0.2, p2191), CFrame.identity, v_u_34, 0.05, Enum.Material.SmoothPlastic, p2192)
	local v2194 = p2191 * 0.08
	for v2195 = 0, 3 do
		local v2196 = v2195 * 3.141592653589793 / 2
		local v2197 = v_u_2115
		local v2198 = p2191 + v2194 * 2
		v2197(v2193, Vector3.new(v2198, v2194, v2194), CFrame.Angles(0, v2196, 0) * CFrame.new(0, -0.05, p2191 / 2 + v2194 / 2), v_u_2125, 0, nil, p2192)
	end
	return v2193
end
local function v_u_2213(p2200, p2201) -- name: blockRig
	-- upvalues: (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_2128, (copy) v_u_15, (copy) v_u_2125
	local v2202 = v_u_2103()
	local v2203 = v_u_2115(v2202, p2200, CFrame.identity, v_u_2128, 0, Enum.Material.SmoothPlastic, p2201)
	for _, v2204 in {
		Enum.NormalId.Top,
		Enum.NormalId.Front,
		Enum.NormalId.Back,
		Enum.NormalId.Left,
		Enum.NormalId.Right
	} do
		local v2205 = Instance.new("Decal")
		v2205.Face = v2204
		v2205.Texture = v_u_15.CrackLines
		v2205.Color3 = v_u_2125
		v2205.Parent = v2203
	end
	local v2206 = p2200.X
	local v2207 = p2200.Z
	local v2208 = math.min(v2206, v2207) * 0.07
	for _, v2209 in { -1, 1 } do
		for _, v2210 in { -1, 1 } do
			local v2211 = v_u_2115
			local v2212 = p2200.Y * 1.002
			v2211(v2202, Vector3.new(v2208, v2212, v2208), CFrame.new(v2209 * p2200.X / 2, 0, v2210 * p2200.Z / 2), v_u_2125, 0, nil, p2201)
		end
	end
	v_u_2115(v2202, p2200 * 1.05, CFrame.identity, v_u_2125, 0.93, nil, p2201)
	return v2202
end
local function v_u_2288(p_u_2214, p_u_2215, p2216, p_u_2217, p2218, p_u_2219, p_u_2220) -- name: dropBlock
	-- upvalues: (copy) v_u_18, (copy) v_u_2199, (copy) v_u_2123, (ref) v_u_67, (copy) v_u_2213, (copy) v_u_359, (copy) v_u_2124
	local v2221 = p_u_2214.X
	local v2222 = v_u_18 + (p2216 or 0.2)
	local v2223 = p_u_2214.Z
	local v_u_2224 = Vector3.new(v2221, v2222, v2223)
	local v2225 = p_u_2215.X
	local v2226 = p_u_2215.Z
	local v_u_2227 = math.max(v2225, v2226) * 1.35
	local v2228 = p2218 - p_u_2217 - 0.15
	local v2229 = math.max(v2228, 0)
	local function v2243()
		-- upvalues: (copy) v_u_2224, (copy) v_u_2227, (copy) p_u_2217, (ref) v_u_2199, (ref) v_u_2123, (ref) v_u_67
		local v_u_2230 = CFrame.new(v_u_2224)
		local v2231 = v_u_2227
		local v_u_2232 = p_u_2217 + 0.3
		local v_u_2233 = v_u_2199(v2231, v_u_2232 + 1)
		local v_u_2234 = os.clock()
		local function v2241()
			-- upvalues: (copy) v_u_2234, (copy) v_u_2232, (ref) v_u_2123, (copy) v_u_2233, (copy) v_u_2230
			local v2235 = os.clock() - v_u_2234
			local v2236 = v2235 / 0.1
			local v2237 = math.clamp(v2236, 0, 1)
			local v2238 = (v2235 - v_u_2232) / 0.1
			local v2239 = math.clamp(v2238, 0, 1)
			v_u_2123(v_u_2233, v_u_2230 * CFrame.Angles(0, v2235 * 0.8, 0), (1 - (1 - v2237) ^ 2) * (1 - v2239))
			if v2239 < 1 then
				return true
			end
			for _, v2240 in v_u_2233.parts do
				v2240:Destroy()
			end
			return false
		end
		if v2241() then
			local v2242 = v_u_67
			table.insert(v2242, v2241)
		end
	end
	if v2229 > 0.005 then
		task.delay(v2229, v2243)
	else
		local v_u_2244 = CFrame.new(v_u_2224)
		local v_u_2245 = p_u_2217 + 0.3
		local v_u_2246 = v_u_2199(v_u_2227, v_u_2245 + 1)
		local v_u_2247 = os.clock()
		local function v2254()
			-- upvalues: (copy) v_u_2247, (copy) v_u_2245, (ref) v_u_2123, (copy) v_u_2246, (copy) v_u_2244
			local v2248 = os.clock() - v_u_2247
			local v2249 = v2248 / 0.1
			local v2250 = math.clamp(v2249, 0, 1)
			local v2251 = (v2248 - v_u_2245) / 0.1
			local v2252 = math.clamp(v2251, 0, 1)
			v_u_2123(v_u_2246, v_u_2244 * CFrame.Angles(0, v2248 * 0.8, 0), (1 - (1 - v2250) ^ 2) * (1 - v2252))
			if v2252 < 1 then
				return true
			end
			for _, v2253 in v_u_2246.parts do
				v2253:Destroy()
			end
			return false
		end
		if v2254() then
			local v2255 = v_u_67
			table.insert(v2255, v2254)
		end
	end
	local v2256 = p2218 - p_u_2217
	local v2257 = math.max(v2256, 0)
	local function v2287()
		-- upvalues: (ref) v_u_2213, (copy) p_u_2215, (copy) p_u_2217, (copy) p_u_2219, (copy) v_u_2224, (copy) p_u_2214, (ref) v_u_18, (ref) v_u_2123, (copy) p_u_2220, (ref) v_u_359, (ref) v_u_2124, (ref) v_u_67
		local v_u_2258 = v_u_2213(p_u_2215, p_u_2217 + p_u_2219 + 1)
		local v2259 = v_u_2224
		local v2260 = p_u_2215.Y / 2
		local v_u_2261 = v2259 + Vector3.new(0, v2260, 0)
		local v2262 = p_u_2214
		local v2263 = p_u_2215.Y / 2
		local v2264 = v2262.X
		local v2265 = v_u_18 + (v2263 or 0.2)
		local v2266 = v2262.Z
		local v_u_2267 = Vector3.new(v2264, v2265, v2266)
		local v_u_2268 = math.random() * 3.141592653589793
		local v_u_2269 = os.clock()
		local v_u_2270 = false
		local function v2285()
			-- upvalues: (copy) v_u_2269, (ref) p_u_2217, (copy) v_u_2261, (copy) v_u_2267, (ref) p_u_2219, (ref) p_u_2215, (ref) v_u_2123, (copy) v_u_2258, (copy) v_u_2268, (ref) v_u_2270, (ref) p_u_2220, (ref) v_u_359, (ref) p_u_2214, (ref) v_u_18, (ref) v_u_2124
			local v2271 = os.clock() - v_u_2269
			local v2272 = v2271 / p_u_2217
			local v2273 = math.clamp(v2272, 0, 1)
			local v2274 = v_u_2261:Lerp(v_u_2267, v2273 * v2273)
			local v2275
			if p_u_2217 + p_u_2219 < v2271 then
				local v2276 = (v2271 - p_u_2217 - p_u_2219) / 0.14
				v2275 = 1 - math.clamp(v2276, 0, 1) * 0.97
				local v2277 = v_u_2267
				local v2278 = p_u_2215.Y / 2 * (1 - v2275)
				v2274 = v2277 - Vector3.new(0, v2278, 0)
			else
				v2275 = 1
			end
			v_u_2123(v_u_2258, CFrame.new(v2274) * CFrame.Angles(0, v_u_2268, 0), v2275)
			if v2273 >= 1 and not v_u_2270 then
				v_u_2270 = true
				p_u_2220()
			end
			if p_u_2217 + p_u_2219 + 0.14 >= v2271 then
				return true
			end
			for _, v2279 in v_u_2258.parts do
				v2279:Destroy()
			end
			local v2280 = v_u_359
			local v2281 = p_u_2214
			local v2282 = v2281.X
			local v2283 = v_u_18 + 1
			local v2284 = v2281.Z
			v2280(Vector3.new(v2282, v2283, v2284), v_u_2124, 3.5, 0.15)
			return false
		end
		if v2285() then
			local v2286 = v_u_67
			table.insert(v2286, v2285)
		end
	end
	if v2257 > 0.005 then
		task.delay(v2257, v2287)
	else
		v2287()
	end
end
v_u_551.daikokuten = {
	["cast"] = function(p2289) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_2125, (copy) v_u_359, (copy) v_u_2124
		v_u_575(p2289, v_u_2125)
		v_u_359(p2289.eye, v_u_2124, 5, 0.2)
	end,
	["windup"] = function(p2290, p2291, p2292) -- name: windup
		-- upvalues: (copy) v_u_247, (copy) v_u_18, (copy) v_u_2125, (copy) v_u_15
		local v2293 = v_u_247
		local v2294 = CFrame.new
		local v2295 = p2291.X
		local v2296 = v_u_18 + 0.15
		local v2297 = p2291.Z
		v2293(v2294((Vector3.new(v2295, v2296, v2297))), p2290.ability.radius, v_u_2125, v_u_15.Ring, p2292 + 0.4, 1)
	end,
	["strike"] = function(p_u_2298, p_u_2299, p2300) -- name: strike
		-- upvalues: (copy) v_u_2288, (copy) v_u_18, (copy) v_u_117, (copy) v_u_2125, (copy) v_u_8, (copy) v_u_15, (copy) v_u_405, (copy) v_u_36, (copy) v_u_265, (copy) v_u_2126, (copy) v_u_10
		local v_u_2301 = (p_u_2298.ability.strikeRadius or 7) * 0.75
		local v2302 = v_u_2288
		local v2303 = v_u_2301 * 2.6
		v2302(p_u_2299, Vector3.new(v_u_2301, v2303, v_u_2301), 22, 0.16, p2300, 0.45, function()
			-- upvalues: (copy) p_u_2299, (ref) v_u_18, (ref) v_u_117, (ref) v_u_2125, (copy) v_u_2301, (ref) v_u_8, (ref) v_u_15, (copy) p_u_2298, (ref) v_u_405, (ref) v_u_36, (ref) v_u_265, (ref) v_u_2126, (ref) v_u_10
			local v2304 = p_u_2299
			local v2305 = v2304.X
			local v2306 = v_u_18 + 0.2
			local v2307 = v2304.Z
			local v2308 = Vector3.new(v2305, v2306, v2307)
			v_u_117("Shockwave", v2308 + Vector3.new(0, 0.3, 0), v_u_2125, v_u_2301 / 9)
			v_u_117("Smoke", v2308 + Vector3.new(0, 1, 0), nil, v_u_2301 / 5)
			v_u_8.ring(v2308, v_u_2125, v_u_2301 * 1.6, 0.3, v_u_15.Ring)
			if not p_u_2298.lite then
				v_u_405(v2308 + Vector3.new(0, 1, 0), v_u_36, 4, 30, 0.9, 0.7)
			end
			v_u_265(p_u_2299, v_u_2126, v_u_2301 * 1.3, 1.4, v_u_15.CrackLines, 0.05)
			v_u_265(p_u_2299, v_u_2125, v_u_2301 * 0.9, 0.8, v_u_15.CrackGlow, 0.15)
			v_u_10.play("Hit", {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v2308
			})
			if p_u_2298.mine then
				v_u_8.shake(0.2, 0.15)
			end
		end)
	end,
	["hit"] = v2185
}
local function v_u_2361(p2309, p2310, p_u_2311, p2312) -- name: karmaSeal
	-- upvalues: (copy) v_u_18, (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_34, (copy) v_u_2125, (copy) v_u_2126, (copy) v_u_2123, (ref) v_u_67
	local v2313 = p2309.X
	local v2314 = v_u_18 + 0.12
	local v2315 = p2309.Z
	local v_u_2316 = Vector3.new(v2313, v2314, v2315)
	local v_u_2317 = v_u_2103()
	local v2318 = p2310 * 0.32
	v_u_2115(v_u_2317, Vector3.new(v2318, 0.12, v2318), CFrame.Angles(0, 0.7853981633974483, 0), v_u_34, 0, Enum.Material.SmoothPlastic, p_u_2311 + 1)
	local v2319 = v2318 * 0.75
	for v2320 = 0, 3 do
		local v2321 = v2320 * 3.141592653589793 / 2 + 0.7853981633974483
		local v2322 = v_u_2115
		local v2323 = v2318 * 1.5
		local v2324 = v2318 * 0.08
		v2322(v_u_2317, Vector3.new(v2323, 0.16, v2324), CFrame.Angles(0, v2321, 0) * CFrame.new(0, 0.02, v2319), v_u_2125, 0, nil, p_u_2311 + 1)
	end
	local v2325 = p2312 and 4 or 8
	for v2326 = 1, v2325 do
		local v2327 = v2326 / v2325 * 3.141592653589793 * 2
		local v2328 = math.cos(v2327)
		local v2329 = math.sin(v2327)
		local v2330 = Vector3.new(v2328, 0, v2329) * v2318 * 0.6
		local v2331 = v2327 + 0.35
		local v2332 = math.cos(v2331)
		local v2333 = v2327 + 0.35
		local v2334 = math.sin(v2333)
		local v2335 = v2330 + Vector3.new(v2332, 0, v2334) * p2310 * 0.4
		local v2336 = v2327 - 0.3
		local v2337 = math.cos(v2336)
		local v2338 = v2327 - 0.3
		local v2339 = math.sin(v2338)
		for _, v2340 in {
			{ v2330, v2335 },
			{ v2335, v2335 + Vector3.new(v2337, 0, v2339) * p2310 * 0.45 }
		} do
			local v2341 = v2340[1]
			local v2342 = v2340[2]
			local v2343 = (v2342 - v2341).Magnitude
			local v2344 = v_u_2115
			local v2345 = p2310 * 0.035
			local v2346 = Vector3.new(v2345, 0.1, v2343)
			local v2347 = CFrame.lookAt((v2341 + v2342) / 2, v2342)
			local v2348
			if v2326 % 2 == 0 then
				v2348 = v_u_2125
			else
				v2348 = v_u_2126
			end
			v2344(v_u_2317, v2346, v2347, v2348, 0, nil, p_u_2311 + 1)
		end
	end
	local v_u_2349 = os.clock()
	local function v2359()
		-- upvalues: (copy) v_u_2349, (ref) v_u_2123, (copy) v_u_2317, (copy) v_u_2316, (copy) p_u_2311
		local v2350 = os.clock() - v_u_2349
		local v2351 = v2350 / 0.18
		local v2352 = 1 - (1 - math.clamp(v2351, 0, 1)) ^ 3
		v_u_2123(v_u_2317, CFrame.new(v_u_2316), v2352)
		if p_u_2311 < v2350 then
			local v2353 = v_u_2317
			local v2354 = (v2350 - p_u_2311) / 0.3
			local v2355 = math.clamp(v2354, 0, 1)
			for _, v2356 in v2353.parts do
				local v2357 = v2356.Transparency
				v2356.Transparency = math.max(v2357, v2355)
			end
		end
		if p_u_2311 + 0.3 >= v2350 then
			return true
		end
		for _, v2358 in v_u_2317.parts do
			v2358:Destroy()
		end
		return false
	end
	if v2359() then
		local v2360 = v_u_67
		table.insert(v2360, v2359)
	end
end
v_u_551.karma_cube = {
	["cast"] = function(p2362) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_2125, (copy) v_u_359, (copy) v_u_2124
		v_u_575(p2362, v_u_2125, true)
		v_u_359(p2362.eye, v_u_2124, 7, 0.22)
	end,
	["windup"] = function(p2363, p2364, p2365) -- name: windup
		-- upvalues: (copy) v_u_2361, (copy) v_u_8, (copy) v_u_18, (copy) v_u_34, (copy) v_u_1, (copy) v_u_2288
		local v2366 = p2363.ability.radius
		v_u_2361(p2364, v2366, p2365 + 1.1, p2363.lite)
		local v2367 = v2366 * 0.85
		local v2368 = math.max(p2365, 0.12)
		local v2369 = v_u_8.part
		local v2370 = CFrame.new
		local v2371 = p2364.X
		local v2372 = v_u_18 + 0.08
		local v2373 = p2364.Z
		local v2374 = v2369(Vector3.new(0.5, 0.06, 0.5), v2370((Vector3.new(v2371, v2372, v2373))), v_u_34, {
			["transparency"] = 0.5,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_8.tween(v2374, v2368, {
			["Size"] = nil,
			["Transparency"] = 0.2,
			["Size"] = Vector3.new(v2367, 0.06, v2367)
		})
		v_u_1:AddItem(v2374, v2368 + 0.05)
		v_u_2288(p2364, Vector3.new(1, 1, 1) * v2367, 42, v2368, v2368, 0.75, function() end)
	end,
	["land"] = function(p2375, p2376) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_2125, (copy) v_u_8, (copy) v_u_2124, (copy) v_u_15, (copy) v_u_209, (copy) v_u_315, (copy) v_u_405, (copy) v_u_36, (copy) v_u_2128, (copy) v_u_265, (copy) v_u_2126, (copy) v_u_10
		local v2377 = p2375.ability.radius
		local v2378 = p2376.X
		local v2379 = v_u_18 + 0.2
		local v2380 = p2376.Z
		local v2381 = Vector3.new(v2378, v2379, v2380)
		local v2382 = v_u_117
		local v2383 = p2376.X
		local v2384 = v_u_18 + 2
		local v2385 = p2376.Z
		v2382("Explosion", Vector3.new(v2383, v2384, v2385), v_u_2125, v2377 / 9)
		local v2386 = v_u_117
		local v2387 = v2381 + Vector3.new(0, 0.3, 0)
		local v2388 = v_u_2125
		local v2389 = v2377 / 14
		v2386("Shockwave", v2387, v2388, (math.min(v2389, 1.6)))
		v_u_117("Smoke", v2381 + Vector3.new(0, 2, 0), nil, v2377 / 7)
		v_u_8.ring(v2381, v_u_2125, v2377 * 1.2, 0.5)
		v_u_8.ring(v2381, v_u_2124, v2377 * 1.4, 0.45, v_u_15.SpeedLines)
		local v2390 = v_u_209
		local v2391 = p2376.X
		local v2392 = v_u_18 + 3
		local v2393 = p2376.Z
		v2390(Vector3.new(v2391, v2392, v2393), v_u_2124, 4, v2377 * 1.3, 0.25, 0.3)
		local v2394 = v_u_315
		local v2395 = p2376.X
		local v2396 = v_u_18 + 1
		local v2397 = p2376.Z
		v2394(Vector3.new(v2395, v2396, v2397), v_u_2124, 12, v2377 * 0.9, 0.3, nil, nil, true)
		local v2398 = v_u_405
		local v2399 = p2376.X
		local v2400 = v_u_18 + 1
		local v2401 = p2376.Z
		v2398(Vector3.new(v2399, v2400, v2401), { v_u_36[1], v_u_36[2], v_u_2128 }, p2375.lite and 6 or 14, 44, 1.4, 1.1)
		v_u_265(p2376, v_u_2126, v2377 * 0.95, 2, v_u_15.CrackLines, 0)
		v_u_265(p2376, v_u_2125, v2377 * 0.7, 1.4, v_u_15.CrackGlow, 0.1)
		v_u_10.play("Explosion", {
			["at"] = v2381
		})
		if p2375.mine then
			v_u_8.shake(0.6, 0.5)
		end
	end,
	["hit"] = function(_, p2402, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_2125, (copy) v_u_359, (copy) v_u_2124
		v_u_117("Impact", p2402, v_u_2125, 1.1)
		v_u_359(p2402, v_u_2124, 5, 0.18)
	end
}
local v_u_2403 = v32(179, 0, 27)
local v_u_2404 = v32(255, 40, 50)
local v_u_2405 = v32(70, 0, 12)
local v_u_2406 = v32(255, 120, 120)
local v_u_2407 = v32(120, 0, 20)
local function v_u_2422(p2408, p2409, p2410) -- name: bloodPool
	-- upvalues: (copy) v_u_190, (copy) v_u_18, (copy) v_u_2407, (copy) v_u_8, (copy) v_u_1
	local v2411 = v_u_190
	local v2412 = 0.07 + math.random() * 0.03
	local v2413 = p2408.X
	local v2414 = v_u_18 + (v2412 or 0.2)
	local v2415 = p2408.Z
	local v_u_2416 = v2411(Vector3.new(v2413, v2414, v2415), p2409 * 0.3, v_u_2407, 0.1, Enum.Material.SmoothPlastic)
	local v2417 = v_u_8.tween
	local v2418 = {}
	local v2419 = p2409 * 2
	local v2420 = p2409 * 2
	v2418.Size = Vector3.new(0.12, v2419, v2420)
	v2417(v_u_2416, 0.15, v2418, Enum.EasingStyle.Back)
	task.delay(p2410, function()
		-- upvalues: (copy) v_u_2416, (ref) v_u_8, (ref) v_u_1
		local v2421 = v_u_2416
		v_u_8.tween(v2421, 0.4, {
			["Transparency"] = 1
		})
		v_u_1:AddItem(v2421, 0.45)
	end)
end
v_u_551.blood_needles = {
	["cast"] = function(p2423) -- name: cast
		-- upvalues: (copy) v_u_557, (copy) v_u_2404, (copy) v_u_405, (copy) v_u_2403
		v_u_557(p2423, v_u_2404)
		if not p2423.lite then
			local v2424 = { v_u_2404, v_u_2403 }
			v_u_405(p2423.eye + p2423.dir * 1.2, v2424, 3, 14, 0.3, 0.35, true, 0.4)
		end
	end,
	["shot"] = function(p2425, p2426) -- name: needleShot
		-- upvalues: (copy) v_u_8, (copy) v_u_2403, (copy) v_u_2404, (copy) v_u_2406, (copy) v_u_461, (copy) v_u_2405, (copy) v_u_492
		local v2427 = p2425.size
		local v2428 = v_u_8.part(Vector3.new(0.2, 0.2, 0.2), p2426, v_u_2403, {
			["transparency"] = 1
		})
		local v2429 = {
			Vector3.new(0, 0, 0),
			Vector3.new(0.55, 0.3, 0.6),
			Vector3.new(-0.55, 0.3, 0.6),
			Vector3.new(0.35, -0.45, 0.9),
			Vector3.new(-0.35, -0.45, 0.9)
		}
		local v2430 = {}
		for v2431 = 1, p2425.lite and 3 or #v2429 do
			local v2432 = v2429[v2431] * 1.25 * v2427
			local v2433 = {
				["p"] = v_u_8.part(Vector3.new(0.28, 0.28, 4) * v2427, p2426, v_u_2404),
				["off"] = CFrame.new(v2432)
			}
			table.insert(v2430, v2433)
			local v2434 = {
				["p"] = v_u_8.part(Vector3.new(0.36, 0.36, 0.9) * v2427, p2426, v_u_2406)
			}
			local v2435 = CFrame.new
			local v2436 = -1.6 * v2427
			v2434.off = v2435(v2432 + Vector3.new(0, 0, v2436))
			table.insert(v2430, v2434)
		end
		local v2437 = {
			["p"] = v_u_8.part(Vector3.new(2.4, 2.4, 4.4) * v2427, p2426, v_u_2403, {
				["transparency"] = 0.7
			}),
			["off"] = CFrame.new(0, 0, 0.3 * v2427)
		}
		table.insert(v2430, v2437)
		v_u_461(v2428, v_u_2404, v_u_2405, 2.4 * v2427, 0.16)
		if p2425.mine then
			local v2438 = v_u_2404
			local v2439 = 9 * v2427
			local v2440 = Instance.new("PointLight")
			v2440.Color = v2438
			v2440.Range = v2439
			v2440.Brightness = 2
			v2440.Shadows = false
			v2440.Parent = v2428
		end
		return v_u_492(v2428, v2430, {}, 0, 0, {}, 0.14, 9)
	end,
	["impact"] = function(p2441, p2442) -- name: impact
		-- upvalues: (copy) v_u_117, (copy) v_u_2404, (copy) v_u_8, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405, (copy) v_u_209, (copy) v_u_2422, (copy) v_u_18, (copy) v_u_15, (copy) v_u_10
		local v2443 = p2441.size
		v_u_117("Slash", p2442, v_u_2404, 1.1 * v2443)
		v_u_117("Impact", p2442, v_u_2404, 1 * v2443)
		v_u_8.flash(p2442, v_u_2404, 4.5 * v2443, 0.15)
		local v2444 = 8
		local v2445 = 0.6 * v2443
		if p2441.lite then
			local v2446 = v2444 / 2
			v2444 = math.ceil(v2446)
		end
		v_u_405(p2442, { v_u_2404, v_u_2403, v_u_2405 }, v2444, 28, v2445, 0.55, true, 0.7)
		v_u_209(p2442, v_u_2404, 1.5 * v2443, 6 * v2443, 0.16, 0.1)
		v_u_2422(p2442, 2.4 * v2443, 0.8)
		local v2447 = v_u_8.ring
		local v2448 = p2442.X
		local v2449 = v_u_18 + 0.2
		local v2450 = p2442.Z
		v2447(Vector3.new(v2448, v2449, v2450), v_u_2404, 4 * v2443, 0.25, v_u_15.Ring)
		v_u_10.play("Hit", {
			["at"] = nil,
			["volume"] = 0.5,
			["at"] = p2442
		})
	end,
	["hit"] = function(p2451, p2452, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_2404, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405
		v_u_117("Slash", p2452, v_u_2404, 0.5)
		if not p2451.lite then
			local v2453 = 3 / 2
			v_u_405(p2452, { v_u_2404, v_u_2403, v_u_2405 }, math.ceil(v2453), 18, 0.35, 0.55, true, 0.7)
		end
	end
}
local function v_u_2478(p2454, p2455, p2456, p2457) -- name: crescentRig
	-- upvalues: (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_2406
	local v2458 = v_u_2103()
	local v2459 = p2456 and 7 or 11
	local v2460 = {}
	for v2461 = 0, v2459 do
		local v2462 = v2461 * 2.6179938779914944 / v2459 + -1.3089969389957472
		local v2463 = math.sin(v2462) * p2454
		local v2464 = -math.cos(v2462) * p2454 + p2454 * 0.6
		local v2465 = Vector3.new(v2463, 0, v2464)
		table.insert(v2460, v2465)
	end
	for v2466 = 1, v2459 do
		local v2467 = v2460[v2466]
		local v2468 = v2460[v2466 + 1]
		local v2469 = (v2467 + v2468) / 2
		local v2470 = (v2466 - 0.5) / v2459 * 2 - 1
		local v2471 = p2455 * ((1 - math.abs(v2470)) ^ 0.7 * 0.85 + 0.15)
		local v2472 = (v2468 - v2467).Magnitude * 1.08
		local v2473 = CFrame.lookAt(v2469, v2468)
		local v2474 = v_u_2115
		local v2475 = v2471 * 0.45
		local v2476 = v2471 * 0.15
		local v2477 = math.max(v2476, 0.15)
		v2474(v2458, Vector3.new(v2475, v2477, v2472), v2473, v_u_2406, 0, nil, p2457)
	end
	return v2458
end
local function v_u_2509(p_u_2479, p_u_2480, p_u_2481, p2482, p2483, p2484) -- name: sendCrescent
	-- upvalues: (copy) v_u_2478, (copy) v_u_2115, (copy) v_u_2403, (copy) v_u_15, (copy) v_u_2404, (copy) v_u_2123, (ref) v_u_67
	local v_u_2485 = v_u_2478(p2482, p2482 * 0.32, p2484, p_u_2481 + 1)
	local v2486 = v_u_2115
	local v2487 = p2482 * 2.3
	local v2488 = p2482 * 2.3
	local v_u_2489 = v2486(v_u_2485, Vector3.new(v2487, 0.05, v2488), CFrame.new(0, 0, p2482 * 0.6) * CFrame.Angles(0, 0, 0), v_u_2403, 1, nil, p_u_2481 + 1)
	local v_u_2490 = {}
	for _, v2491 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v2492 = Instance.new("Decal")
		v2492.Face = v2491
		v2492.Texture = v_u_15.Crescent
		v2492.Color3 = v_u_2404
		v2492.Parent = v_u_2489
		table.insert(v_u_2490, v2492)
	end
	local v2493 = p_u_2480 - p_u_2479
	local v2494 = v2493.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2493.Unit
	local v2495 = v2494.Y
	local v2496 = math.abs(v2495) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v_u_2497 = CFrame.lookAt(p_u_2479, p_u_2479 + v2494, v2496) * CFrame.Angles(0, 0, p2483)
	local v_u_2498 = os.clock()
	local function v2507()
		-- upvalues: (copy) v_u_2498, (copy) p_u_2481, (copy) p_u_2479, (copy) p_u_2480, (ref) v_u_2123, (copy) v_u_2485, (copy) v_u_2497, (copy) v_u_2489, (copy) v_u_2490
		local v2499 = (os.clock() - v_u_2498) / p_u_2481
		local v2500 = math.clamp(v2499, 0, 1)
		local v2501 = p_u_2479:Lerp(p_u_2480, v2500)
		v_u_2123(v_u_2485, v_u_2497 - v_u_2497.Position + v2501, v2500 * 0.45 + 0.55)
		if v2500 > 0.75 then
			local v2502 = (v2500 - 0.75) / 0.25
			for _, v2503 in v_u_2485.parts do
				local v2504 = v2503.Transparency
				v2503.Transparency = math.max(v2504, v2502)
			end
			v_u_2489.Transparency = 1
			for _, v2505 in v_u_2490 do
				v2505.Transparency = v2502
			end
		end
		if v2500 < 1 then
			return true
		end
		for _, v2506 in v_u_2485.parts do
			v2506:Destroy()
		end
		return false
	end
	if v2507() then
		local v2508 = v_u_67
		table.insert(v2508, v2507)
	end
end
local function v_u_2541(p2510, p2511, p2512, p2513, p_u_2514) -- name: bloodSpike
	-- upvalues: (copy) v_u_2103, (copy) v_u_2115, (copy) v_u_2406, (copy) v_u_2403, (copy) v_u_2405, (copy) v_u_2123, (ref) v_u_67
	local v_u_2515 = v_u_2103()
	local v2516 = p2512 / 3
	for v2517, v2518 in { 1, 0.62, 0.3 } do
		local v2519 = p2513 * v2518
		local v2520 = v_u_2115
		local v2521 = v2516 * 1.05
		local v2522 = Vector3.new(v2519, v2521, v2519)
		local v2523 = CFrame.new(0, v2516 * (v2517 - 0.5), 0) * CFrame.Angles(0, 0.7853981633974483 * v2517, 0)
		local v2524
		if v2517 == 3 then
			v2524 = v_u_2406
		else
			v2524 = v_u_2403
		end
		v2520(v_u_2515, v2522, v2523, v2524, 0, nil, p_u_2514 + 1)
		local v2525 = v_u_2115
		local v2526 = v2519 * 1.3
		local v2527 = v2516 * 1.02
		local v2528 = v2519 * 1.3
		v2525(v_u_2515, Vector3.new(v2526, v2527, v2528), CFrame.new(0, v2516 * (v2517 - 0.5), 0) * CFrame.Angles(0, 0.7853981633974483 * v2517, 0), v_u_2405, 0.5, nil, p_u_2514 + 1)
	end
	local v2529 = p2511.Unit
	local v2530 = v2529.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2529.Unit
	local v2531 = v2530.Y
	local v2532 = math.abs(v2531) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v_u_2533 = CFrame.lookAt(p2510, p2510 + v2530, v2532) * CFrame.Angles(-1.5707963267948966, 0, 0)
	local v_u_2534 = os.clock()
	local function v2539()
		-- upvalues: (copy) v_u_2534, (copy) p_u_2514, (ref) v_u_2123, (copy) v_u_2515, (copy) v_u_2533
		local v2535 = os.clock() - v_u_2534
		local v2536
		if v2535 < 0.08 then
			v2536 = 0.05 + 0.95 * (1 - (1 - v2535 / 0.08) ^ 3)
		elseif v2535 < p_u_2514 + 0.08 then
			v2536 = 1
		else
			local v2537 = (v2535 - 0.08 - p_u_2514) / 0.18
			v2536 = 1 - math.clamp(v2537, 0, 1) * 0.97
		end
		v_u_2123(v_u_2515, v_u_2533, v2536)
		if p_u_2514 + 0.26 >= v2535 then
			return true
		end
		for _, v2538 in v_u_2515.parts do
			v2538:Destroy()
		end
		return false
	end
	if v2539() then
		local v2540 = v_u_67
		table.insert(v2540, v2539)
	end
end
local v_u_2542 = v32(34, 0, 6)
local v_u_2543 = v32(130, 8, 22)
local v_u_2544 = {}
local function v_u_2599(p2545, p2546, p2547) -- name: newCutBlade
	-- upvalues: (copy) v_u_2478, (copy) v_u_2115, (copy) v_u_2403, (copy) v_u_15, (copy) v_u_2404, (copy) v_u_2405, (copy) v_u_2123, (ref) v_u_67
	local v2548 = v_u_2478(p2546, p2546 * 0.34, p2545.lite, 3)
	local v2549 = v_u_2115
	local v2550 = p2546 * 2.3
	local v2551 = p2546 * 2.3
	local v2552 = v2549(v2548, Vector3.new(v2550, 0.05, v2551), CFrame.new(0, 0, p2546 * 0.6) * CFrame.Angles(0, 0, 0), v_u_2403, 1, nil, 3)
	local v2553 = {}
	for _, v2554 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v2555 = Instance.new("Decal")
		v2555.Face = v2554
		v2555.Texture = v_u_15.Crescent
		v2555.Color3 = v_u_2404
		v2555.Parent = v2552
		table.insert(v2553, v2555)
	end
	local v2556 = Instance.new("Attachment")
	v2556.Parent = v2552
	local v2557 = Instance.new("Attachment")
	v2557.Parent = v2552
	local v2558 = Instance.new("Trail")
	v2558.Attachment0 = v2556
	v2558.Attachment1 = v2557
	v2558.Color = ColorSequence.new(v_u_2404, v_u_2405)
	v2558.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v2558.Lifetime = 0.2
	v2558.LightEmission = 0.35
	v2558.LightInfluence = 0
	v2558.MinLength = 0.05
	v2558.Parent = v2552
	local v_u_2559 = {
		["rig"] = nil,
		["decals"] = nil,
		["edge"] = nil,
		["radius"] = nil,
		["roll"] = nil,
		["born"] = nil,
		["caster"] = nil,
		["eye"] = nil,
		["dir"] = nil,
		["swingAt"] = nil,
		["fly"] = nil,
		["done"] = false,
		["rig"] = v2548,
		["decals"] = v2553,
		["edge"] = { v2556, v2557 },
		["radius"] = p2546,
		["roll"] = p2547,
		["born"] = os.clock(),
		["caster"] = p2545.caster,
		["eye"] = p2545.eye,
		["dir"] = p2545.dir
	}
	local v_u_2560 = v_u_2559.radius
	local function v2597()
		-- upvalues: (copy) v_u_2559, (ref) v_u_2123, (copy) v_u_2560
		local v2561 = os.clock()
		local v2562 = v_u_2559.fly
		if v_u_2559.done or not v2562 and v2561 - v_u_2559.born > 0.8 then
			v_u_2559.done = true
			for _, v2563 in v_u_2559.rig.parts do
				v2563:Destroy()
			end
			return false
		end
		local v2564 = (v2561 - v_u_2559.born) / 0.1
		local v2565 = math.clamp(v2564, 0, 1)
		local v2566
		if v_u_2559.swingAt then
			local v2567 = (v2561 - v_u_2559.swingAt) / 0.06
			v2566 = math.clamp(v2567, 0, 1)
		else
			v2566 = 0
		end
		local v2568 = 1 - (1 - v2566) ^ 3
		local v2569 = ((v_u_2559.swingAt or v2561) - v_u_2559.born) / 0.3
		local v2570 = (-1.9198621771937625 - math.clamp(v2569, 0, 1) * 0.3) * (1 - v2568)
		local v2571 = (1 - v2568) * 1.6
		local v2572 = ((1 - (1 - v2565) ^ 2) * 0.5 + 0.35) * (1 - v2568) + v2568
		local v2573 = 0
		local v2574, v2575
		if v2562 then
			local v2576 = (v2561 - v2562.at) / 0.13
			v2573 = math.clamp(v2576, 0, 1)
			v2572 = v2572 * (v2573 * 0.8 + 1)
			v2574 = v2562.from:Lerp(v2562.to, v2573)
			local v2577 = v2562.to - v2562.from
			local v2578 = v2577.X
			local v2579 = v2577.Z
			local v2580 = Vector3.new(v2578, 0, v2579)
			if v2580.Magnitude > 0.001 then
				v2575 = v2580.Unit
			else
				v2575 = Vector3.new(0, 0, -1)
			end
		else
			local v2581 = v_u_2559.caster
			v2574 = v_u_2559.eye
			local v2582 = v_u_2559.dir
			if v2581 then
				v2581 = v2581.Character
			end
			if v2581 then
				v2581 = v2581:FindFirstChild("Head")
			end
			if v2581 and v2581:IsA("BasePart") then
				v2574 = v2581.Position + Vector3.new(0, 0.15, 0) + v2582 * 0.8
			end
			v2575 = v_u_2559.dir
		end
		local v2583 = v2574 + Vector3.new(0, v2571, 0)
		local v2584 = v2575.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2575.Unit
		local v2585 = v2584.Y
		local v2586 = math.abs(v2585) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v2587 = CFrame.lookAt(v2583, v2583 + v2584, v2586) * CFrame.Angles(0, v2570, 0)
		v_u_2123(v_u_2559.rig, v2587 * CFrame.new(0, 0, v_u_2560 * -0.6 * v2572) * CFrame.Angles(0, 0, v_u_2559.roll), v2572)
		local v2588 = v_u_2559.edge[1]
		local v2589 = -v_u_2560 * 0.98 * v2572
		v2588.Position = Vector3.new(0, 0, v2589)
		local v2590 = v_u_2559.edge[2]
		local v2591 = -v_u_2560 * 0.7 * v2572
		v2590.Position = Vector3.new(0, 0, v2591)
		if v2573 > 0.7 then
			local v2592 = (v2573 - 0.7) / 0.3
			for _, v2593 in v_u_2559.rig.parts do
				local v2594 = v2593.Transparency
				v2593.Transparency = math.max(v2594, v2592)
			end
			for _, v2595 in v_u_2559.decals do
				v2595.Transparency = v2592
			end
		end
		if v2573 < 1 then
			return true
		end
		v_u_2559.done = true
		for _, v2596 in v_u_2559.rig.parts do
			v2596:Destroy()
		end
		return false
	end
	if v2597() then
		local v2598 = v_u_67
		table.insert(v2598, v2597)
	end
	return v_u_2559
end
local function v_u_2609(p2600, p2601) -- name: bloodMist
	-- upvalues: (copy) v_u_4, (copy) v_u_2543, (copy) v_u_96, (copy) v_u_6, (copy) v_u_1
	local v2602 = v_u_4:FindFirstChild("Fx")
	if v2602 then
		v2602 = v2602:FindFirstChild("Smoke")
	end
	if not (v2602 and v2602:IsA("Attachment")) then
		v2602 = nil
	end
	if v2602 then
		local v2603 = v2602:Clone()
		local v2604 = {}
		for _, v2605 in v2603:GetDescendants() do
			if not v2605:IsA("ParticleEmitter") then
				continue
			end
			v2605.Color = ColorSequence.new(v_u_2543)
			v2605.Size = v_u_96(v2605.Size, p2601)
			v2605.Speed = NumberRange.new(v2605.Speed.Min * p2601, v2605.Speed.Max * p2601)
			table.insert(v2604, v2605)
		end
		v2603.WorldPosition = p2600
		v2603.Parent = v_u_6.Terrain
		for _, v2606 in v2604 do
			local v2607 = v2606:GetAttribute("Emit")
			if type(v2607) ~= "number" then
				continue
			end
			v2606:Emit(v2607)
		end
		local v2608 = v2603:GetAttribute("Life")
		v_u_1:AddItem(v2603, (type(v2608) ~= "number" and 2 or v2608) + 0.5)
	end
end
local v_u_2610 = 0
local function v_u_2614() -- name: cutFrame
	-- upvalues: (ref) v_u_2610, (copy) v_u_2, (copy) v_u_8, (copy) v_u_33, (copy) v_u_1
	local v2611 = os.clock()
	if v2611 >= v_u_2610 then
		v_u_2610 = v2611 + 0.5
		local v_u_2612 = Instance.new("ColorCorrectionEffect")
		v_u_2612.Name = "CrimsonCut"
		v_u_2612.Parent = v_u_2
		v_u_8.tween(v_u_2612, 0.04, {
			["TintColor"] = nil,
			["Contrast"] = 0.3,
			["Saturation"] = 0.35,
			["TintColor"] = Color3.fromRGB(255, 170, 170)
		})
		task.delay(0.07, function()
			-- upvalues: (ref) v_u_8, (copy) v_u_2612, (ref) v_u_33
			local v2613 = {
				["TintColor"] = nil,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = v_u_33
			}
			v_u_8.tween(v_u_2612, 0.35, v2613)
		end)
		v_u_1:AddItem(v_u_2612, 0.5)
	end
end
local function v_u_2671(p_u_2615, p2616, p2617, p_u_2618) -- name: tearGround
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_2542, (copy) v_u_2404, (copy) v_u_1, (copy) v_u_2403, (copy) v_u_265, (copy) v_u_2405, (copy) v_u_15, (copy) v_u_2541, (copy) v_u_405, (copy) v_u_36
	local v2619 = p2616.X
	local v2620 = v_u_18 + 0.09
	local v2621 = p2616.Z
	local v2622 = Vector3.new(v2619, v2620, v2621)
	local v2623 = p2617.X
	local v2624 = v_u_18 + 0.09
	local v2625 = p2617.Z
	local v2626 = Vector3.new(v2623, v2624, v2625)
	if (v2626 - v2622).Magnitude >= 2 then
		local v_u_2627 = (v2626 - v2622).Unit
		local v_u_2628 = v_u_2627:Cross(Vector3.new(0, 1, 0))
		local v_u_2629 = p_u_2615.lite and 4 or 8
		local v2630 = {}
		for v2631 = 0, v_u_2629 do
			local v2632 = v2622:Lerp(v2626, v2631 / v_u_2629)
			if v2631 > 0 and v2631 < v_u_2629 then
				v2632 = v2632 + v_u_2628 * (math.random() - 0.5) * 1.8
			end
			table.insert(v2630, v2632)
		end
		for v_u_2633 = 1, v_u_2629 do
			local v_u_2634 = v2630[v_u_2633]
			local v_u_2635 = v2630[v_u_2633 + 1]
			local v2636 = p_u_2618 * (v_u_2633 - 1) / v_u_2629
			local function v2670()
				-- upvalues: (copy) v_u_2635, (copy) v_u_2634, (copy) p_u_2618, (copy) v_u_2629, (ref) v_u_8, (ref) v_u_2542, (ref) v_u_2404, (ref) v_u_1, (ref) v_u_2403, (ref) v_u_265, (ref) v_u_2405, (ref) v_u_15, (copy) p_u_2615, (copy) v_u_2633, (copy) v_u_2628, (copy) v_u_2627, (ref) v_u_2541, (ref) v_u_18, (ref) v_u_405, (ref) v_u_36
				local v_u_2637 = (v_u_2635 - v_u_2634).Magnitude
				local v2638 = (v_u_2634 + v_u_2635) / 2
				local v2639 = v_u_2635 - v_u_2634
				local v2640 = v2639.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2639.Unit
				local v2641 = v2640.Y
				local v2642 = math.abs(v2641) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v2643 = CFrame.lookAt(v2638, v2638 + v2640, v2642)
				local v2644 = p_u_2618 / v_u_2629 + 0.03
				local v_u_2645 = v_u_8.part(Vector3.new(1.6, 0.12, 0.2), v2643, v_u_2542, {
					["material"] = Enum.Material.SmoothPlastic
				})
				local v_u_2646 = v_u_8.part(Vector3.new(0.55, 0.16, 0.2), v2643 + Vector3.new(0, 0.03, 0), v_u_2404)
				v_u_1:AddItem(v_u_2645, 2.5)
				v_u_1:AddItem(v_u_2646, 2.5)
				local v2647 = v_u_8.tween
				local v2648 = {}
				local v2649 = v_u_2637 + 0.7
				v2648.Size = Vector3.new(1.6, 0.12, v2649)
				v2647(v_u_2645, v2644, v2648)
				local v2650 = v_u_8.tween
				local v2651 = {}
				local v2652 = v_u_2637 + 0.5
				v2651.Size = Vector3.new(0.55, 0.16, v2652)
				v2650(v_u_2646, v2644, v2651)
				task.delay(0.5, function()
					-- upvalues: (ref) v_u_8, (copy) v_u_2646, (ref) v_u_2403, (copy) v_u_2637
					local v2653 = v_u_8.tween
					local v2654 = v_u_2646
					local v2655 = {
						["Color"] = nil,
						["Size"] = nil,
						["Transparency"] = 1,
						["Color"] = v_u_2403
					}
					local v2656 = v_u_2637
					v2655.Size = Vector3.new(0.1, 0.16, v2656)
					v2653(v2654, 0.9, v2655)
				end)
				task.delay(1, function()
					-- upvalues: (copy) v_u_2645, (ref) v_u_8, (ref) v_u_1
					local v2657 = v_u_2645
					v_u_8.tween(v2657, 0.6, {
						["Transparency"] = 1
					})
					v_u_1:AddItem(v2657, 0.65)
				end)
				local v2658 = (v_u_2634 + v_u_2635) / 2
				v_u_265(v2658, v_u_2405, 2.8 + math.random() * 1.2, 1.7, v_u_15.CrackLines, 0.05)
				if not p_u_2615.lite and v_u_2633 % 2 == 1 then
					v_u_265(v2658, v_u_2404, 2.2, 0.9, v_u_15.CrackGlow, 0.25)
				end
				if not p_u_2615.lite or v_u_2633 % 2 == 0 then
					local v2659 = v_u_2633 % 2 == 0 and 1 or -1
					local v2660 = v2658 + v_u_2628 * v2659 * 1.4
					local v2661 = v_u_2628 * v2659 * 0.55 + v_u_2627 * 0.3 + Vector3.new(0, 1, 0)
					local v2662 = v_u_2541
					local v2663 = v2660.X
					local v2664 = v_u_18 + 0
					local v2665 = v2660.Z
					v2662(Vector3.new(v2663, v2664, v2665), v2661, 4.5 + math.random() * 3.5, 1.3 + math.random() * 0.5, 0.35)
				end
				if not p_u_2615.lite and v_u_2633 % 3 == 0 then
					local v2666 = v_u_405
					local v2667 = v2658.X
					local v2668 = v_u_18 + 0.6
					local v2669 = v2658.Z
					v2666(Vector3.new(v2667, v2668, v2669), { v_u_2542, v_u_2405, v_u_36[2] }, 3, 22, 0.55, 0.6)
				end
			end
			if v2636 > 0.005 then
				task.delay(v2636, v2670)
			else
				v2670()
			end
		end
	end
end
local function v_u_2679(p_u_2672, p_u_2673, p2674) -- name: cutLightning
	-- upvalues: (copy) v_u_421, (copy) v_u_428, (copy) v_u_2406, (copy) v_u_437, (copy) v_u_2404
	for v_u_2675 = 0, p2674 - 1 do
		local v2676 = v_u_2675 * 0.09
		local function v2678()
			-- upvalues: (ref) v_u_421, (copy) p_u_2672, (copy) p_u_2673, (ref) v_u_428, (ref) v_u_2406, (copy) v_u_2675, (ref) v_u_437, (ref) v_u_2404
			local v2677 = v_u_421(p_u_2672, p_u_2673, 1.6, 7)
			v_u_428(v2677, 0.3, v_u_2406, 0.1)
			if v_u_2675 == 0 then
				v_u_428(v_u_437(v2677, 0.6), 0.8, v_u_2404, 0.14, 0.45)
			end
		end
		if v2676 > 0.005 then
			task.delay(v2676, v2678)
		else
			v2678()
		end
	end
end
local function v_u_2708(p2680, p2681, p2682) -- name: cutEnd
	-- upvalues: (copy) v_u_18, (copy) v_u_117, (copy) v_u_2403, (copy) v_u_2404, (copy) v_u_8, (copy) v_u_15, (copy) v_u_209, (copy) v_u_2406, (copy) v_u_247, (copy) v_u_2422, (copy) v_u_265, (copy) v_u_2405, (copy) v_u_405, (copy) v_u_2541, (copy) v_u_36, (copy) v_u_10
	local v2683 = p2681.X
	local v2684 = v_u_18 + 0.2
	local v2685 = p2681.Z
	local v2686 = Vector3.new(v2683, v2684, v2685)
	v_u_117("Explosion", p2681, v_u_2403, 1.5)
	v_u_117("Shockwave", v2686 + Vector3.new(0, 0.3, 0), v_u_2404, 0.9)
	v_u_8.ring(v2686, v_u_2404, 12, 0.4, v_u_15.Shockwave)
	v_u_209(p2681, v_u_2406, 3, 13, 0.2, 0.45)
	for _, v2687 in { 0.6981317007977318, -0.6981317007977318 } do
		local v2688 = v_u_247
		local v2689 = p2681 + Vector3.new(0, 1, 0)
		local v2690 = -p2682
		local v2691 = v2690.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2690.Unit
		local v2692 = v2691.Y
		local v2693 = math.abs(v2692) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v2688(CFrame.lookAt(v2689, v2689 + v2691, v2693) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, v2687, 0), 7, v_u_2404, v_u_15.Crescent, 0.22, 0)
	end
	v_u_2422(p2681, 5, 1.2)
	v_u_265(p2681, v_u_2405, 7.5, 1.8, v_u_15.CrackLines, 0.05)
	v_u_265(p2681, v_u_2404, 5, 1, v_u_15.CrackGlow, 0.25)
	local v2694 = p2681 + Vector3.new(0, 1, 0)
	local v2695 = 10
	if p2680.lite then
		local v2696 = v2695 / 2
		v2695 = math.ceil(v2696)
	end
	v_u_405(v2694, { v_u_2404, v_u_2403, v_u_2405 }, v2695, 34, 0.5, 0.55, true, 0.7)
	if not p2680.lite then
		for v2697 = 1, 3 do
			local v2698 = CFrame.Angles(0, (v2697 - 2) * 0.7, 0):VectorToWorldSpace(p2682)
			local v2699 = v_u_2541
			local v2700 = p2681 + v2698 * 2.5
			local v2701 = v2700.X
			local v2702 = v_u_18 + 0
			local v2703 = v2700.Z
			v2699(Vector3.new(v2701, v2702, v2703), v2698 * 0.7 + Vector3.new(0, 1, 0), v2697 + 7, 1.9, 0.45)
		end
		local v2704 = v_u_405
		local v2705 = p2681.X
		local v2706 = v_u_18 + 0.8
		local v2707 = p2681.Z
		v2704(Vector3.new(v2705, v2706, v2707), v_u_36, 5, 30, 0.8, 0.8)
	end
	v_u_10.play("Explosion", {
		["at"] = v2686,
		["volume"] = p2680.mine and 0.85 or 0.5
	})
end
v_u_551.crimson_crescent = {
	["cast"] = function(p2709) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_2404, (copy) v_u_359, (copy) v_u_2406, (copy) v_u_2544, (copy) v_u_2599, (copy) v_u_342, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405, (copy) v_u_428, (copy) v_u_421, (copy) v_u_117, (copy) v_u_265, (copy) v_u_15, (copy) v_u_10
		v_u_575(p2709, v_u_2404, true)
		v_u_359(p2709.eye, v_u_2406, 7, 0.2)
		local v2710 = p2709.caster
		local v2711
		if v2710 then
			local v2712 = v2710.UserId
			v2711 = tostring(v2712)
		else
			v2711 = "podium"
		end
		local v2713 = v_u_2544[v2711]
		if v2713 then
			v2713.done = true
		end
		v_u_2544[v2711] = v_u_2599(p2709, 7 * p2709.size, 0.5)
		local v2714 = p2709.dir:Cross(Vector3.new(0, 1, 0))
		local v2715 = p2709.eye + v2714 * 4 + p2709.dir * -1.5 + Vector3.new(0, 1.6, 0)
		if not p2709.lite then
			v_u_342(v2715, v_u_2404, 6, 6, 0.16)
			local v2716 = { v_u_2404, v_u_2403, v_u_2405 }
			v_u_405(p2709.eye + p2709.dir, v2716, 5, 18, 0.35, 0.55, true, 0.7)
			v_u_428(v_u_421(v2715, p2709.eye, 0.8, 1.2), 0.2, v_u_2406, 0.1)
			v_u_428(v_u_421(v2715, p2709.eye, 0.8, 1.2), 0.2, v_u_2406, 0.1)
			v_u_117("Lightning", v2715, v_u_2404, 0.8)
			v_u_265(p2709.feet, v_u_2405, 4.5, 1.2, v_u_15.CrackLines, 0.1)
		end
		v_u_10.play("EyeActivate", {
			["at"] = p2709.origin,
			["volume"] = p2709.mine and 0.9 or 0.5
		})
	end,
	["windup"] = function(p2717, _, p2718) -- name: windup
		-- upvalues: (copy) v_u_2544
		local v2719 = v_u_2544
		local v2720 = p2717.caster
		local v2721
		if v2720 then
			local v2722 = v2720.UserId
			v2721 = tostring(v2722)
		else
			v2721 = "podium"
		end
		local v2723 = v2719[v2721]
		if v2723 and not (v2723.done or v2723.fly) then
			local v2724 = os.clock()
			local v2725 = p2718 - 0.06
			v2723.swingAt = v2724 + math.max(v2725, 0)
		end
	end,
	["beam"] = function(p_u_2726, p_u_2727, p_u_2728) -- name: beam
		-- upvalues: (copy) v_u_2544, (copy) v_u_2599, (copy) v_u_200, (copy) v_u_168, (copy) v_u_33, (copy) v_u_2404, (copy) v_u_8, (copy) v_u_292, (copy) v_u_2405, (copy) v_u_2671, (copy) v_u_2679, (copy) v_u_18, (copy) v_u_117, (copy) v_u_2609, (copy) v_u_2708, (copy) v_u_2406, (copy) v_u_15, (copy) v_u_10, (copy) v_u_2614
		local v_u_2729 = p_u_2726.lite
		local v2730 = p_u_2728 - p_u_2727
		local v2731 = v2730.X
		local v2732 = v2730.Z
		local v2733 = Vector3.new(v2731, 0, v2732)
		local v_u_2734 = v2733.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v2733.Unit
		local v_u_2735 = 7 * p_u_2726.size
		local v2736 = os.clock()
		local v2737 = p_u_2726.caster
		local v2738
		if v2737 then
			local v2739 = v2737.UserId
			v2738 = tostring(v2739)
		else
			v2738 = "podium"
		end
		local v2740 = v_u_2544[v2738]
		v_u_2544[v2738] = nil
		if not v2740 or (v2740.done or v2740.fly) then
			v2740 = v_u_2599(p_u_2726, v_u_2735, 0.5)
		end
		v2740.swingAt = v2740.swingAt or v2736
		v2740.fly = {
			["from"] = p_u_2727,
			["to"] = p_u_2728 - v_u_2734 * v_u_2735 * 1.8,
			["at"] = v2736
		}
		if not v_u_2729 then
			local function v2742()
				-- upvalues: (ref) v_u_2599, (copy) p_u_2726, (copy) v_u_2735, (copy) p_u_2727, (copy) p_u_2728, (copy) v_u_2734
				local v2741 = v_u_2599(p_u_2726, v_u_2735 * 0.75, -0.65)
				v2741.swingAt = os.clock() - 0.06
				v2741.fly = {
					["from"] = p_u_2727,
					["to"] = p_u_2728 - v_u_2734 * v_u_2735 * 0.75 * 1.8,
					["at"] = os.clock()
				}
			end
			task.delay(0.035, v2742)
		end
		local v2743 = p_u_2727 + v_u_2734 * 1.5
		v_u_200(v_u_168(v2743, p_u_2728, 0.55, v_u_33), 0.2, true)
		v_u_200(v_u_168(v2743, p_u_2728, 2.4, v_u_2404, 0.35), 0.32, true)
		local v2744 = v_u_2404
		local v2745 = v_u_8.beam(v2743, p_u_2728, v2744, 6, 0.3, nil)
		v2745.LightEmission = 0.55
		v2745.Brightness = 1.6
		v_u_292(p_u_2727, p_u_2728, p_u_2726.ability.width or 10, v_u_2405, 1.3, 0.55)
		v_u_2671(p_u_2726, p_u_2727 + v_u_2734 * 2, p_u_2728, 0.13)
		local v2746 = v_u_2679
		local v2747 = v2743.X
		local v2748 = v_u_18 + 1.2
		local v2749 = v2743.Z
		local v2750 = Vector3.new(v2747, v2748, v2749)
		local v2751 = p_u_2728.X
		local v2752 = v_u_18 + 1.2
		local v2753 = p_u_2728.Z
		v2746(v2750, Vector3.new(v2751, v2752, v2753), v_u_2729 and 1 or 3)
		local v2754 = v_u_2729 and 3 or 6
		for v_u_2755 = 1, v2754 do
			local v2756 = v_u_2755 / v2754
			local v_u_2757 = v2743:Lerp(p_u_2728, v2756)
			local v2758 = v2756 * 0.13
			local function v2769()
				-- upvalues: (ref) v_u_117, (copy) v_u_2757, (ref) v_u_2404, (copy) v_u_2729, (copy) v_u_2755, (ref) v_u_2609, (ref) v_u_18
				v_u_117("Slash", v_u_2757, v_u_2404, 1.5)
				if not v_u_2729 then
					if v_u_2755 % 2 == 0 then
						local v2759 = v_u_2609
						local v2760 = v_u_2757
						local v2761 = v2760.X
						local v2762 = v_u_18 + 1.5
						local v2763 = v2760.Z
						v2759(Vector3.new(v2761, v2762, v2763), 1.3)
					end
					if v_u_2755 % 3 == 0 then
						local v2764 = v_u_117
						local v2765 = v_u_2757
						local v2766 = v2765.X
						local v2767 = v_u_18 + 1
						local v2768 = v2765.Z
						v2764("Lightning", Vector3.new(v2766, v2767, v2768), v_u_2404, 1)
					end
				end
			end
			if v2758 > 0.005 then
				task.delay(v2758, v2769)
			else
				v2769()
			end
		end
		local function v2770()
			-- upvalues: (ref) v_u_2708, (copy) p_u_2726, (copy) p_u_2728, (copy) v_u_2734
			v_u_2708(p_u_2726, p_u_2728, v_u_2734)
		end
		task.delay(0.13, v2770)
		v_u_117("Flash", v2743, v_u_2404, 0.45)
		v_u_8.ring(p_u_2726.feet, v_u_2406, 10, 0.3, v_u_15.SpeedLines)
		v_u_10.play("Crit", {
			["at"] = p_u_2727,
			["volume"] = p_u_2726.mine and 0.9 or 0.5
		})
		v_u_10.play("Lightning", {
			["at"] = p_u_2727:Lerp(p_u_2728, 0.5),
			["volume"] = p_u_2726.mine and 0.45 or 0.3
		})
		if p_u_2726.mine then
			v_u_8.shake(0.55, 0.4)
			v_u_2614()
		end
	end,
	["hit"] = function(p2771, p2772, _) -- name: hit
		-- upvalues: (copy) v_u_117, (copy) v_u_2404, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405
		v_u_117("Slash", p2772, v_u_2404, 1.1)
		v_u_117("Impact", p2772, v_u_2404, 1)
		if not p2771.lite then
			local v2773 = 4 / 2
			v_u_405(p2772, { v_u_2404, v_u_2403, v_u_2405 }, math.ceil(v2773), 22, 0.4, 0.55, true, 0.7)
		end
	end
}
local v_u_2774 = 0
local function v_u_2777(p2775) -- name: bloodSky
	-- upvalues: (ref) v_u_2774, (copy) v_u_2, (copy) v_u_8, (copy) v_u_1
	if os.clock() >= v_u_2774 then
		local v_u_2776 = Instance.new("ColorCorrectionEffect")
		v_u_2776.Name = "BloodMoon"
		v_u_2776.TintColor = Color3.new(1, 1, 1)
		v_u_2776.Parent = v_u_2
		v_u_8.tween(v_u_2776, 0.12, {
			["TintColor"] = nil,
			["Saturation"] = 0.25,
			["Contrast"] = 0.1,
			["TintColor"] = Color3.fromRGB(255, 150, 150)
		})
		task.delay(p2775 + 0.12, function()
			-- upvalues: (ref) v_u_8, (copy) v_u_2776
			v_u_8.tween(v_u_2776, 0.5, {
				["TintColor"] = nil,
				["Saturation"] = 0,
				["Contrast"] = 0,
				["TintColor"] = Color3.new(1, 1, 1)
			})
		end)
		v_u_1:AddItem(v_u_2776, p2775 + 0.7)
		v_u_2774 = os.clock() + p2775 + 0.7
	end
end
v_u_551.blood_moon = {
	["cast"] = function(p2778) -- name: cast
		-- upvalues: (copy) v_u_575, (copy) v_u_2404, (copy) v_u_117, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405
		v_u_575(p2778, v_u_2404, true)
		v_u_117("Flash", p2778.eye, v_u_2404, 0.4)
		local v2779 = p2778.eye
		local v2780 = 6
		if p2778.lite then
			local v2781 = v2780 / 2
			v2780 = math.ceil(v2781)
		end
		v_u_405(v2779, { v_u_2404, v_u_2403, v_u_2405 }, v2780, 22, 0.4, 0.55, true, 0.7)
	end,
	["windup"] = function(p2782, p2783, p2784) -- name: windup
		-- upvalues: (copy) v_u_18, (copy) v_u_152, (copy) v_u_2404, (copy) v_u_2403, (copy) v_u_8, (copy) v_u_6, (copy) v_u_247, (copy) v_u_2405, (copy) v_u_15, (copy) v_u_1, (copy) v_u_190, (copy) v_u_2407, (copy) v_u_265, (copy) v_u_2777
		local v2785 = p2782.ability.radius
		local v2786 = p2783.X
		local v2787 = v_u_18 + 30
		local v2788 = p2783.Z
		local v2789 = Vector3.new(v2786, v2787, v2788) + p2782.dir * 26
		local v2790 = p2784 + 1.3
		local v_u_2791 = v_u_152(v2789, v_u_2404, 6, 0)
		local v_u_2792 = v_u_152(v2789, v_u_2403, 9, 0.7)
		v_u_8.tween(v_u_2791, p2784 + 0.12, {
			["Size"] = Vector3.new(22, 22, 22)
		}, Enum.EasingStyle.Back)
		v_u_8.tween(v_u_2792, p2784 + 0.2, {
			["Size"] = Vector3.new(34, 34, 34)
		}, Enum.EasingStyle.Back)
		local v2793 = v_u_6.CurrentCamera
		local v2794
		if v2793 then
			v2794 = v2793.CFrame.Position
		else
			v2794 = p2783
		end
		local v2795 = (v2794 - v2789).Unit
		local v2796 = v_u_247
		local v2797 = v2789 + v2795 * 11.5
		local v2798 = v2795.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2795.Unit
		local v2799 = v2798.Y
		local v2800 = math.abs(v2799) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v2796(CFrame.lookAt(v2797, v2797 + v2798, v2800) * CFrame.Angles(-1.5707963267948966, 0, 0), 10.5, v_u_2405, v_u_15.BloodSigil, v2790 - 0.2, 0.6)
		local v2801 = v_u_247
		local v2802 = v2789 + v2795 * 12
		local v2803 = v2795.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2795.Unit
		local v2804 = v2803.Y
		local v2805 = math.abs(v2804) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v2801(CFrame.lookAt(v2802, v2802 + v2803, v2805) * CFrame.Angles(-1.5707963267948966, 0, 0), 19, v_u_2404, v_u_15.Ring, v2790 - 0.2, -1.5)
		task.delay(v2790, function()
			-- upvalues: (copy) v_u_2791, (ref) v_u_8, (ref) v_u_1, (copy) v_u_2792
			local v2806 = v_u_2791
			v_u_8.tween(v2806, 0.4, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v2806, 0.45)
			local v2807 = v_u_2792
			v_u_8.tween(v2807, 0.4, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v2807, 0.45)
		end)
		local v2808 = v_u_190
		local v2809 = p2783.X
		local v2810 = v_u_18 + 0.07
		local v2811 = p2783.Z
		local v_u_2812 = v2808(Vector3.new(v2809, v2810, v2811), 0.5, v_u_2407, 0.05, Enum.Material.SmoothPlastic)
		local v2813 = v_u_8.tween
		local v2814 = p2784 + 0.1
		local v2815 = {}
		local v2816 = v2785 * 2
		local v2817 = v2785 * 2
		v2815.Size = Vector3.new(0.12, v2816, v2817)
		v2813(v_u_2812, v2814, v2815, Enum.EasingStyle.Quad)
		task.delay(p2784 + 1.4, function()
			-- upvalues: (copy) v_u_2812, (ref) v_u_8, (ref) v_u_1
			local v2818 = v_u_2812
			v_u_8.tween(v2818, 0.5, {
				["Transparency"] = 1
			})
			v_u_1:AddItem(v2818, 0.55)
		end)
		local v2819 = v_u_247
		local v2820 = CFrame.new
		local v2821 = p2783.X
		local v2822 = v_u_18 + 0.14
		local v2823 = p2783.Z
		v2819(v2820((Vector3.new(v2821, v2822, v2823))), v2785, v_u_2404, v_u_15.BloodSigil, p2784 + 1.2, 1.2)
		v_u_265(p2783, v_u_2404, v2785 * 0.85, p2784 + 1.3, v_u_15.CrackLines, 0.15)
		if p2782.mine then
			v_u_2777(p2784 + 0.6)
		end
	end,
	["land"] = function(p2824, p2825) -- name: land
		-- upvalues: (copy) v_u_18, (copy) v_u_2541, (copy) v_u_2509, (copy) v_u_2404, (copy) v_u_8, (copy) v_u_117, (copy) v_u_2403, (copy) v_u_2406, (copy) v_u_15, (copy) v_u_209, (copy) v_u_405, (copy) v_u_2405, (copy) v_u_10
		local v2826 = p2824.ability.radius
		local v2827 = p2825.X
		local v2828 = v_u_18 + 0.2
		local v2829 = p2825.Z
		local v2830 = Vector3.new(v2827, v2828, v2829)
		local v2831 = p2825.X
		local v2832 = v_u_18 + 30
		local v2833 = p2825.Z
		local v2834 = Vector3.new(v2831, v2832, v2833) + p2824.dir * 26
		local v2835 = p2824.lite and 6 or 12
		for v2836 = 1, v2835 do
			local v2837 = v2836 / v2835 * 3.141592653589793 * 2 + math.random() * 0.3
			local v2838 = v2826 * (v2836 % 3 / 2 * 0.6 + 0.25)
			local v2839 = math.cos(v2837) * v2838
			local v2840 = math.sin(v2837) * v2838
			local v_u_2841 = v2830 + Vector3.new(v2839, 0, v2840)
			local v2842 = math.cos(v2837) * 0.45
			local v2843 = math.sin(v2837) * 0.45
			local v_u_2844 = Vector3.new(v2842, 1, v2843)
			local v2845 = v2836 % 4 * 0.025
			local function v2846()
				-- upvalues: (ref) v_u_2541, (copy) v_u_2841, (copy) v_u_2844
				v_u_2541(v_u_2841, v_u_2844, 7 + math.random() * 5, 1.8 + math.random() * 0.8, 0.5)
			end
			if v2845 > 0.005 then
				task.delay(v2845, v2846)
			else
				v_u_2541(v_u_2841, v_u_2844, 7 + math.random() * 5, 1.8 + math.random() * 0.8, 0.5)
			end
		end
		v_u_2541(v2830, Vector3.new(0, 1, 0), 16, 3.4, 0.55)
		for v2847 = 0, p2824.lite and 2 or 5 do
			local v2848 = v2847 / 6 * 3.141592653589793 * 2
			local v2849 = math.cos(v2848)
			local v2850 = math.sin(v2848)
			local v2851 = Vector3.new(v2849, 0, v2850)
			local v2852 = v_u_2509
			local v2853 = p2825.X
			local v2854 = v_u_18 + 2
			local v2855 = p2825.Z
			local v2856 = Vector3.new(v2853, v2854, v2855)
			local v2857 = p2825.X
			local v2858 = v_u_18 + 2
			local v2859 = p2825.Z
			v2852(v2856, Vector3.new(v2857, v2858, v2859) + v2851 * v2826 * 1.1, 0.22, 5, 0.1, true)
		end
		local v2860 = p2825.X
		local v2861 = v_u_18 + 1
		local v2862 = p2825.Z
		local v2863 = Vector3.new(v2860, v2861, v2862)
		local v2864 = v_u_2404
		local v2865 = v_u_8.beam(v2834, v2863, v2864, 9, 0.45, nil)
		v2865.LightEmission = 0.55
		v2865.Brightness = 1.6
		local v2866 = v_u_117
		local v2867 = p2825.X
		local v2868 = v_u_18 + 2
		local v2869 = p2825.Z
		v2866("Explosion", Vector3.new(v2867, v2868, v2869), v_u_2403, v2826 / 9)
		local v2870 = v_u_117
		local v2871 = v2830 + Vector3.new(0, 0.3, 0)
		local v2872 = v_u_2404
		local v2873 = v2826 / 14
		v2870("Shockwave", v2871, v2872, (math.min(v2873, 1.6)))
		v_u_8.ring(v2830, v_u_2404, v2826 * 1.2, 0.5)
		v_u_8.ring(v2830, v_u_2406, v2826 * 1.4, 0.45, v_u_15.SpeedLines)
		local v2874 = v_u_209
		local v2875 = p2825.X
		local v2876 = v_u_18 + 3
		local v2877 = p2825.Z
		v2874(Vector3.new(v2875, v2876, v2877), v_u_2406, 4, v2826 * 1.1, 0.22, 0.55)
		local v2878 = p2825.X
		local v2879 = v_u_18 + 2
		local v2880 = p2825.Z
		local v2881 = Vector3.new(v2878, v2879, v2880)
		local v2882 = 12
		if p2824.lite then
			local v2883 = v2882 / 2
			v2882 = math.ceil(v2883)
		end
		v_u_405(v2881, { v_u_2404, v_u_2403, v_u_2405 }, v2882, 40, 0.6, 0.55, true, 0.7)
		v_u_10.play("Explosion", {
			["at"] = v2830
		})
		if p2824.mine then
			v_u_8.shake(0.6, 0.5)
		end
	end,
	["hit"] = function(p2884, p2885, _) -- name: hit
		-- upvalues: (copy) v_u_2541, (copy) v_u_18, (copy) v_u_117, (copy) v_u_2404, (copy) v_u_405, (copy) v_u_2403, (copy) v_u_2405
		local v2886 = v_u_2541
		local v2887 = p2885.X
		local v2888 = v_u_18 + 0
		local v2889 = p2885.Z
		v2886(Vector3.new(v2887, v2888, v2889), Vector3.new(0, 1, 0), 5, 1.2, 0.25)
		v_u_117("Impact", p2885, v_u_2404, 1)
		if not p2884.lite then
			local v2890 = 3 / 2
			v_u_405(p2885, { v_u_2404, v_u_2403, v_u_2405 }, math.ceil(v2890), 18, 0.35, 0.55, true, 0.7)
		end
	end
}
local v_u_2936 = {
	["FLOOR"] = v_u_18,
	["WHITE"] = v_u_33,
	["BLACK"] = v_u_34,
	["EARTH"] = v_u_36,
	["rgb"] = v32,
	["iris"] = function(p2891, p2892) -- name: iris
		-- upvalues: (copy) v_u_14, (copy) v_u_15
		return v_u_14.Iris[p2891] or (p2892 or v_u_15.MagicCircle)
	end,
	["frame"] = v75,
	["runNow"] = v2102,
	["animate"] = v_u_86,
	["after"] = function(p2893, p2894) -- name: after
		if p2893 > 0.005 then
			task.delay(p2893, p2894)
		else
			p2894()
		end
	end,
	["burst"] = v_u_117,
	["loop"] = v_u_131,
	["loopAt"] = v_u_139,
	["glowBeam"] = function(p2895, p2896, p2897, p2898, p2899, p2900) -- name: glowBeam
		-- upvalues: (copy) v_u_8
		local v2901 = v_u_8.beam(p2895, p2896, p2897, p2898, p2899, p2900)
		v2901.LightEmission = 0.55
		v2901.Brightness = 1.6
	end,
	["ground"] = function(p2902, p2903) -- name: ground
		-- upvalues: (copy) v_u_18
		local v2904 = p2902.X
		local v2905 = v_u_18 + (p2903 or 0.2)
		local v2906 = p2902.Z
		return Vector3.new(v2904, v2905, v2906)
	end,
	["flatUnit"] = function(p2907) -- name: flatUnit
		local v2908 = p2907.X
		local v2909 = p2907.Z
		local v2910 = Vector3.new(v2908, 0, v2909)
		return v2910.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v2910.Unit
	end,
	["aimAt"] = v_u_145,
	["facing"] = function(p2911, p2912) -- name: facing
		local v2913 = p2912.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or p2912.Unit
		local v2914 = v2913.Y
		local v2915 = math.abs(v2914) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		return CFrame.lookAt(p2911, p2911 + v2913, v2915) * CFrame.Angles(-1.5707963267948966, 0, 0)
	end,
	["ball"] = v_u_152,
	["rod"] = v_u_168,
	["pillar"] = v_u_180,
	["plate"] = v_u_190,
	["thin"] = v_u_200,
	["fadeOut"] = function(p2916, p2917) -- name: fadeOut
		-- upvalues: (copy) v_u_8, (copy) v_u_1
		v_u_8.tween(p2916, p2917, {
			["Transparency"] = 1
		})
		v_u_1:AddItem(p2916, p2917 + 0.05)
	end,
	["pop"] = v_u_209,
	["dome"] = v_u_220,
	["sigil"] = v_u_247,
	["mark"] = v_u_265,
	["groundLine"] = v_u_292,
	["spikes"] = v_u_315,
	["inward"] = v_u_342,
	["glint"] = v_u_359,
	["chunks"] = v_u_405,
	["boltPath"] = v_u_421,
	["drawPath"] = v_u_428,
	["jitter"] = v_u_437,
	["alongPath"] = v_u_450,
	["streak"] = v_u_461,
	["light"] = function(p2918, p2919, p2920) -- name: light
		local v2921 = Instance.new("PointLight")
		v2921.Color = p2919
		v2921.Range = p2920
		v2921.Brightness = 2
		v2921.Shadows = false
		v2921.Parent = p2918
	end,
	["hitSound"] = function(p2922, p2923) -- name: hitSound
		-- upvalues: (copy) v_u_10
		v_u_10.play(p2923 and "Explosion" or "Hit", {
			["at"] = p2922,
			["volume"] = p2923 and 1 or 0.5
		})
	end,
	["beamHitSound"] = function(p2924, p2925, p2926) -- name: beamHitSound
		-- upvalues: (copy) v_u_10
		if not p2924.struck then
			p2924.struck = true
			v_u_10.play(p2926, {
				["at"] = nil,
				["volume"] = 0.3,
				["at"] = p2925
			})
		end
	end,
	["assemble"] = v_u_492,
	["orbShot"] = v_u_514,
	["arrowShot"] = v_u_539,
	["muzzle"] = v_u_557,
	["skillCast"] = v_u_575,
	["simpleHit"] = function(p_u_2927, p_u_2928) -- name: simpleHit
		-- upvalues: (copy) v_u_117
		return function(_, p2929, _)
			-- upvalues: (ref) v_u_117, (copy) p_u_2927, (copy) p_u_2928
			v_u_117("Impact", p2929, p_u_2927, p_u_2928)
		end
	end,
	["bindHit"] = v_u_600,
	["liftRocks"] = v_u_649,
	["tongues"] = v_u_705,
	["drop"] = v_u_1398,
	["newRig"] = v_u_2103,
	["rigAdd"] = v_u_2115,
	["rigPlace"] = v_u_2123,
	["rigFade"] = function(p2930, p2931) -- name: rigFade
		for _, v2932 in p2930.parts do
			local v2933 = v2932.Transparency
			v2932.Transparency = math.max(v2933, p2931)
		end
	end,
	["rigDestroy"] = function(p2934) -- name: rigDestroy
		for _, v2935 in p2934.parts do
			v2935:Destroy()
		end
	end
}
local v_u_2937 = script.Parent.Moves2
local v_u_2938 = {
	["beast_gaze"] = function() -- name: beast_gaze
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.beast_gaze)
	end,
	["violet_halo"] = function() -- name: violet_halo
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.violet_halo)
	end,
	["venom_tomoe"] = function() -- name: venom_tomoe
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.venom_tomoe)
	end,
	["lotus_eye"] = function() -- name: lotus_eye
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.lotus_eye)
	end,
	["phantom_pinwheel"] = function() -- name: phantom_pinwheel
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.phantom_pinwheel)
	end,
	["amethyst_star"] = function() -- name: amethyst_star
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.amethyst_star)
	end,
	["grave_rinne"] = function() -- name: grave_rinne
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.grave_rinne)
	end,
	["jade_seal"] = function() -- name: jade_seal
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.jade_seal)
	end,
	["solar_lotus"] = function() -- name: solar_lotus
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.solar_lotus)
	end,
	["crimson_spiral"] = function() -- name: crimson_spiral
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.crimson_spiral)
	end,
	["sage_rings"] = function() -- name: sage_rings
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.sage_rings)
	end,
	["oracle_eye"] = function() -- name: oracle_eye
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.oracle_eye)
	end,
	["celestial_gaze"] = function() -- name: celestial_gaze
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.celestial_gaze)
	end,
	["prism_eye"] = function() -- name: prism_eye
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.prism_eye)
	end,
	["six_paths_sage"] = function() -- name: six_paths_sage
		-- upvalues: (copy) v_u_2937
		return require(v_u_2937.six_paths_sage)
	end
}
local v_u_2939 = {}
local v_u_2940 = require(script.Parent.Moves3)(v_u_2936)
local function v_u_2947(p2941) -- name: lookOf
	-- upvalues: (copy) v_u_551, (copy) v_u_2938, (copy) v_u_2939, (copy) v_u_2936, (copy) v_u_2940
	local v2942 = v_u_551[p2941]
	if v2942 then
		return v2942
	end
	local v2943 = string.match(p2941, "^(.+)_[aer]$")
	local v2944
	if v2943 then
		v2944 = v_u_2938[v2943]
	else
		v2944 = nil
	end
	if not (v2943 and v2944) then
		return v_u_2940(p2941)
	end
	if not v_u_2939[v2943] then
		v_u_2939[v2943] = true
		for v2945, v2946 in v2944()(v_u_2936) do
			v_u_551[v2945] = v2946
		end
	end
	return v_u_551[p2941]
end
local function v_u_2987(p_u_2948, p_u_2949, p_u_2950, p_u_2951, p_u_2952, p2953, p_u_2954) -- name: fly
	-- upvalues: (copy) v_u_145, (copy) v_u_86, (ref) v_u_24
	local v2955 = p_u_2949.shot
	if v2955 then
		local v2956 = p_u_2951 - p_u_2950
		if v2956.Magnitude < 0.1 then
			v2956 = p_u_2948.dir
		end
		local v_u_2957 = v2955(p_u_2948, v_u_145(p_u_2950, v2956))
		local v_u_2958 = p_u_2949.weave or 0
		local v2959 = v2956.X
		local v2960 = v2956.Z
		local v2961 = Vector3.new(v2959, 0, v2960)
		local v_u_2962 = (v2961.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v2961.Unit):Cross(Vector3.new(0, 1, 0))
		local v_u_2963 = p_u_2950
		local v2964 = v2956.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2956.Unit
		local v2965 = v2964.Y
		local v2966 = math.abs(v2965) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v_u_2967 = CFrame.lookAt(p_u_2950, p_u_2950 + v2964, v2966)
		local v_u_2968 = os.clock() - p_u_2948.skip
		v_u_86(p2953, p_u_2948.skip, function(p2969)
			-- upvalues: (copy) p_u_2951, (copy) p_u_2952, (ref) v_u_24, (copy) p_u_2950, (copy) v_u_2962, (copy) p_u_2954, (copy) v_u_2958, (ref) v_u_2963, (ref) v_u_2967, (copy) v_u_2957, (copy) v_u_2968, (copy) p_u_2949, (copy) p_u_2948
			local v2970 = p_u_2951
			if p_u_2952 then
				local v2971 = v_u_24(p_u_2952)
				if v2971 then
					v2970 = v2971 + Vector3.new(0, 0.5, 0)
				end
			end
			local v2972 = p2969 * 3.141592653589793
			local v2973 = math.sin(v2972)
			local v2974 = p_u_2950:Lerp(v2970, p2969)
			local v2975 = v2973 * 0.8
			local v2976 = v2974 + Vector3.new(0, v2975, 0)
			local v2977 = v_u_2962
			local v2978 = p2969 * 3.141592653589793 * 3 + p_u_2954
			local v2979 = v2976 + v2977 * (v2973 * math.sin(v2978) * v_u_2958)
			local v2980 = v2979 - v_u_2963
			local v2981
			if v2980.Magnitude > 0.001 then
				local v2982 = v2980.Magnitude <= 0.0001 and Vector3.new(0, 0, -1) or v2980.Unit
				local v2983 = v2982.Y
				local v2984 = math.abs(v2983) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				v2981 = CFrame.lookAt(v2979, v2979 + v2982, v2984)
			else
				v2981 = CFrame.new(v2979) * v_u_2967.Rotation
			end
			v_u_2967 = v2981
			v_u_2957.place(v_u_2967, os.clock() - v_u_2968)
			v_u_2963 = v2979
			if p2969 >= 1 then
				local v2985 = p_u_2949.keep
				if v2985 then
					task.delay(v2985, function()
						-- upvalues: (ref) v_u_2957
						v_u_2957.stop(0.2)
					end)
				else
					v_u_2957.stop()
				end
				local v2986 = p_u_2949.impact
				if v2986 then
					v2986(p_u_2948, v2979)
				end
			end
		end)
	end
end
local function v_u_3009(p_u_2988, p2989, p2990) -- name: playBeam
	local v2991 = (p_u_2988.ability.delay or 0) - p_u_2988.skip
	local v2992 = math.max(v2991, 0)
	local v2993 = p2989.windup
	if v2993 then
		v2993(p_u_2988, p_u_2988.eye, v2992)
	end
	local v_u_2994 = p2989.beam
	if v_u_2994 then
		local v_u_2995 = p2990.p
		local function v3002()
			-- upvalues: (copy) p_u_2988, (copy) v_u_2995, (copy) v_u_2994
			local v2996 = p_u_2988.caster
			local v2997 = p_u_2988.eye
			local v2998 = p_u_2988.dir
			if v2996 then
				v2996 = v2996.Character
			end
			if v2996 then
				v2996 = v2996:FindFirstChild("Head")
			end
			if v2996 and v2996:IsA("BasePart") then
				v2997 = v2996.Position + Vector3.new(0, 0.15, 0) + v2998 * 0.8
			end
			local v2999 = v_u_2995.X
			local v3000 = v2997.Y - 1.2
			local v3001 = v_u_2995.Z
			v_u_2994(p_u_2988, v2997, (Vector3.new(v2999, v3000, v3001)))
		end
		if v2992 > 0.005 then
			task.delay(v2992, v3002)
		else
			local v3003 = p_u_2988.caster
			local v3004 = p_u_2988.eye
			local v3005 = p_u_2988.dir
			if v3003 then
				v3003 = v3003.Character
			end
			if v3003 then
				v3003 = v3003:FindFirstChild("Head")
			end
			if v3003 and v3003:IsA("BasePart") then
				v3004 = v3003.Position + Vector3.new(0, 0.15, 0) + v3005 * 0.8
			end
			local v3006 = v_u_2995.X
			local v3007 = v3004.Y - 1.2
			local v3008 = v_u_2995.Z
			v_u_2994(p_u_2988, v3004, (Vector3.new(v3006, v3007, v3008)))
		end
	else
		return
	end
end
local function v_u_3018(p_u_3010, p3011, p_u_3012) -- name: playArea
	local v3013 = (p_u_3010.ability.delay or 0) - p_u_3010.skip
	local v3014 = math.max(v3013, 0)
	local v3015 = p3011.windup
	if v3015 then
		v3015(p_u_3010, p_u_3012, v3014)
	end
	local v_u_3016 = p3011.land
	if v_u_3016 then
		local function v3017()
			-- upvalues: (copy) v_u_3016, (copy) p_u_3010, (copy) p_u_3012
			v_u_3016(p_u_3010, p_u_3012)
		end
		if v3014 > 0.005 then
			task.delay(v3014, v3017)
			return
		end
		v_u_3016(p_u_3010, p_u_3012)
	end
end
local function v_u_3044(p_u_3019, p_u_3020, p_u_3021) -- name: playZone
	-- upvalues: (copy) v_u_18, (copy) v_u_6, (copy) v_u_1, (copy) v_u_10
	local v3022 = p_u_3019.ability.delay or 0
	local v3023 = v3022 - p_u_3019.skip
	local v3024 = math.max(v3023, 0)
	local v3025 = p_u_3019.ability.duration or 2
	local v3026 = p_u_3019.skip - v3022
	local v3027 = v3025 - math.max(v3026, 0)
	local v_u_3028 = math.max(v3027, 0.1)
	local v3029 = p_u_3020.windup
	if v3029 then
		v3029(p_u_3019, p_u_3021, v3024)
	end
	local function v3043()
		-- upvalues: (copy) p_u_3020, (copy) p_u_3019, (copy) p_u_3021, (copy) v_u_3028, (ref) v_u_18, (ref) v_u_6, (ref) v_u_1, (ref) v_u_10
		local v3030 = p_u_3020.zone
		local v3031 = not v3030 and function() end or v3030(p_u_3019, p_u_3021, v_u_3028)
		local v3032 = p_u_3020.loopSound
		local v_u_3033
		if v3032 then
			local v_u_3034 = Instance.new("Attachment")
			local v3035 = p_u_3021
			local v3036 = v3035.X
			local v3037 = v_u_18 + 2
			local v3038 = v3035.Z
			v_u_3034.WorldPosition = Vector3.new(v3036, v3037, v3038)
			v_u_3034.Parent = v_u_6.Terrain
			v_u_1:AddItem(v_u_3034, v_u_3028 + 1)
			local v_u_3039 = v_u_10.loop(v3032, v_u_3034, 0.7)
			v_u_3033 = function()
				-- upvalues: (copy) v_u_3039, (copy) v_u_3034
				v_u_3039()
				v_u_3034:Destroy()
			end
		else
			v_u_3033 = function() end
		end
		local v3040 = task.delay
		local v3041 = v_u_3028 - 0.12
		v3040(math.max(v3041, 0), v3031)
		task.delay(v_u_3028, function()
			-- upvalues: (ref) v_u_3033, (ref) p_u_3020, (ref) p_u_3019, (ref) p_u_3021
			v_u_3033()
			local v3042 = p_u_3020.finish
			if p_u_3019.ability.finalPower and v3042 then
				v3042(p_u_3019, p_u_3021)
			end
		end)
	end
	if v3024 > 0.005 then
		task.delay(v3024, v3043)
	else
		v3043()
	end
end
local function v_u_3059(p3045, p3046, p3047, p3048) -- name: playRain
	-- upvalues: (copy) v_u_18
	local v3049 = (p3045.ability.delay or 0) + (p3045.ability.duration or 1) - p3045.skip
	local v3050 = p3046.windup
	if v3050 then
		v3050(p3045, p3047, (math.max(v3049, 0.2)))
	end
	local v3051 = p3046.strike
	if v3051 then
		for _, v3052 in p3048 do
			if type(v3052) ~= "table" then
				continue
			end
			local v3053 = v3052.x
			if type(v3053) ~= "number" then
				continue
			end
			local v3054 = v3052.z
			if type(v3054) ~= "number" then
				continue
			end
			local v3055 = v3052.at
			if type(v3055) ~= "number" then
				continue
			end
			local v3056 = v3052.x
			local v3057 = v_u_18
			local v3058 = v3052.z
			v3051(p3045, Vector3.new(v3056, v3057, v3058), v3052.at - p3045.skip)
		end
	end
end
local function v_u_3075(p3060, p3061, p3062, p3063, p3064) -- name: context
	-- upvalues: (copy) v_u_17, (copy) v_u_11, (copy) v_u_18
	local v3065 = p3063 - p3062
	local v3066 = v3065.X
	local v3067 = v3065.Z
	local v3068 = Vector3.new(v3066, 0, v3067)
	local v3069 = v3068.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v3068.Unit
	local v3070
	if p3061 == nil then
		v3070 = false
	else
		v3070 = p3061 == v_u_17
	end
	local v3071 = {
		["ability"] = nil,
		["style"] = nil,
		["size"] = 1,
		["caster"] = nil,
		["mine"] = nil,
		["lite"] = nil,
		["origin"] = nil,
		["feet"] = nil,
		["eye"] = nil,
		["dir"] = nil,
		["target"] = nil,
		["skip"] = nil,
		["struck"] = false,
		["ability"] = p3060,
		["style"] = p3060.style,
		["caster"] = p3061,
		["mine"] = v3070,
		["lite"] = not v3070 or v_u_11.level() <= 1,
		["origin"] = p3062
	}
	local v3072 = p3062.X
	local v3073 = v_u_18 + 0.2
	local v3074 = p3062.Z
	v3071.feet = Vector3.new(v3072, v3073, v3074)
	if p3061 then
		p3061 = p3061.Character
	end
	if p3061 then
		p3061 = p3061:FindFirstChild("Head")
	end
	if p3061 and p3061:IsA("BasePart") then
		p3062 = p3061.Position + Vector3.new(0, 0.15, 0) + v3069 * 0.8
	end
	v3071.eye = p3062
	v3071.dir = v3069
	v3071.target = p3063
	v3071.skip = p3064
	return v3071
end
local function v_u_3081(p3076, p3077) -- name: castLayer
	-- upvalues: (copy) v_u_2947, (copy) v_u_10, (copy) v_u_557, (copy) v_u_33
	local v3078 = v_u_2947(p3076.style)
	local v3079 = v3078 and v3078.castSound or p3076.ability.sound
	local v3080 = p3077 or (p3076.mine and 1 or 0.6)
	if v3079 ~= "Flames" and (v3079 ~= "Vortex" and v3080 > 0) then
		v_u_10.play(v3079, {
			["at"] = p3076.origin,
			["volume"] = v3080
		})
	end
	if v3078 then
		v3078 = v3078.cast
	end
	if v3078 then
		v3078(p3076)
	else
		v_u_557(p3076, v_u_33)
	end
end
local v_u_3082 = nil
local v_u_3083 = 0
local v_u_3084 = nil
local v_u_3085 = 0
local v_u_3086 = {}
function v22.predict(p3087, p3088) -- name: predict
	-- upvalues: (copy) v_u_17, (copy) v_u_3075, (copy) v_u_3086, (copy) v_u_3081
	local v3089 = v_u_17.Character
	if v3089 then
		v3089 = v3089:FindFirstChild("HumanoidRootPart")
	end
	if v3089 and v3089:IsA("BasePart") then
		local v3090 = v_u_3075(p3087, v_u_17, v3089.Position + Vector3.new(0, 1.5, 0), p3088, 0)
		v_u_3086[p3087.id] = os.clock()
		v_u_3081(v3090)
	end
end
function v22.play(p3091) -- name: play
	-- upvalues: (copy) v_u_12, (copy) v_u_3, (copy) v_u_17, (copy) v_u_6, (copy) v_u_11, (copy) v_u_19, (ref) v_u_21, (ref) v_u_20, (copy) v_u_3075, (copy) v_u_2947, (copy) v_u_26, (copy) v_u_3086, (copy) v_u_3081, (ref) v_u_3084, (ref) v_u_3085, (ref) v_u_3082, (ref) v_u_3083, (copy) v_u_2987, (copy) v_u_3009, (copy) v_u_3018, (copy) v_u_3044, (copy) v_u_3059
	local v3092 = v_u_12.byId[p3091.a]
	if v3092 then
		local v3093 = p3091.o
		if typeof(v3093) == "Vector3" then
			local v3094 = p3091.p
			if typeof(v3094) == "Vector3" then
				local v3095 = p3091.t
				if type(v3095) == "number" then
					local v3096 = v_u_3:GetPlayerByUserId(p3091.u)
					local v3097
					if v3096 == nil then
						v3097 = false
					else
						v3097 = v3096 == v_u_17
					end
					local v3098 = v_u_6.CurrentCamera
					if not v3097 and v3098 then
						local v3099 = (v3098.CFrame.Position - p3091.o).Magnitude
						local v3100 = v_u_11.castRange
						if math.min(320, v3100()) < v3099 then
							return
						end
						if v_u_19[p3091.a] then
							local v3101 = os.clock()
							local v3102 = v_u_11.othersAttacksPerSecond()
							local v3103 = v_u_21 + (v3101 - v_u_20) * v3102
							v_u_21 = math.min(v3102, v3103)
							v_u_20 = v3101
							if v_u_21 < 1 then
								return
							end
							v_u_21 = v_u_21 - 1
						end
					end
					local v3104 = v_u_6:GetServerTimeNow() - p3091.t
					local v3105 = math.clamp(v3104, 0, 0.5)
					local v3106 = v_u_3075(v3092, v3096, p3091.o, p3091.p, v3105)
					local v3107 = v_u_2947(v3092.style) or {}
					if v3096 then
						for _, v3108 in v_u_26 do
							task.spawn(v3108, v3096, p3091.p, v3092)
						end
					end
					local v3109 = v_u_3086[v3092.id]
					if v3097 and (v3109 and os.clock() - v3109 < 0.6) then
						v_u_3086[v3092.id] = nil
					else
						v_u_3081(v3106)
					end
					if v3097 then
						local v3110 = v3106.ability
						local v3111 = (v3110.delay or 0) + (v3110.duration or 0) + 0.9
						if v3110.cooldown >= 3 then
							v_u_3084 = v3106
							v_u_3085 = os.clock() + v3111
						else
							v_u_3082 = v3106
							v_u_3083 = os.clock() + v3111
						end
					end
					local v3112 = v3092.kind
					if v3112 == "bolt" then
						v_u_2987(v3106, v3107, v3106.eye, p3091.p + Vector3.new(0, 0.5, 0), p3091.hit, p3091.d or 0.3, 0)
					elseif v3112 == "spread" then
						local v3113 = p3091.bolts
						if v3113 then
							for v3114, v3115 in v3113 do
								local v3116 = v3115.p
								if typeof(v3116) ~= "Vector3" then
									continue
								end
								local v3117 = v3115.d
								if type(v3117) ~= "number" then
									continue
								end
								v_u_2987(v3106, v3107, v3106.eye, v3115.p + Vector3.new(0, 0.5, 0), v3115.hit, v3115.d, v3114 * 1.7)
							end
							return
						end
					else
						if v3112 == "beam" then
							v_u_3009(v3106, v3107, p3091)
							return
						end
						if v3112 == "burst" or v3112 == "bind" then
							v_u_3018(v3106, v3107, p3091.p)
							return
						end
						if v3112 == "zone" then
							v_u_3044(v3106, v3107, p3091.p)
							return
						end
						if v3112 == "rain" then
							v_u_3059(v3106, v3107, p3091.p, p3091.strikes or {})
						end
					end
				end
			end
		end
	end
end
function v22.showcase(p3118, p3119, p3120, p3121) -- name: showcase
	-- upvalues: (copy) v_u_12, (copy) v_u_6, (copy) v_u_18, (copy) v_u_3075, (copy) v_u_3081, (copy) v_u_2947, (copy) v_u_2987, (copy) v_u_3009, (copy) v_u_3018, (copy) v_u_3044, (copy) v_u_3059
	local v3122 = v_u_12.byId[p3118]
	if not v3122 then
		return 0
	end
	local v3123 = p3119.Position
	local v3124 = v_u_6.CurrentCamera
	if v3124 and (v3124.CFrame.Position - v3123).Magnitude > 320 then
		return 0
	end
	local v3125 = p3120.X - v3123.X
	local v3126 = p3120.Z - v3123.Z
	local v3127 = Vector3.new(v3125, 0, v3126)
	local v3128
	if v3127.Magnitude >= 2 then
		v3128 = v3127.Unit
	else
		local v3129 = p3119.LookVector
		local v3130 = v3129.X
		local v3131 = v3129.Z
		local v3132 = Vector3.new(v3130, 0, v3131)
		v3128 = v3132.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v3132.Unit
	end
	local v3133 = v3127.Magnitude
	local v3134 = v3122.range
	local v3135 = math.max(v3134, 8)
	local v3136 = math.clamp(v3133, 8, v3135)
	local v3137 = v3123.X
	local v3138 = v_u_18
	local v3139 = v3123.Z
	local v3140 = Vector3.new(v3137, v3138, v3139) + v3128 * v3136
	local v3141 = v_u_3075(v3122, nil, v3123, v3140, 0)
	v3141.lite = false
	local v3142 = v3123.X
	local v3143 = v3123.Y - 4.5
	local v3144 = v_u_18 + 0.2
	local v3145 = math.max(v3143, v3144)
	local v3146 = v3123.Z
	v3141.feet = Vector3.new(v3142, v3145, v3146)
	v_u_3081(v3141, p3121 or 0)
	local v3147 = v_u_2947(v3122.style) or {}
	local v3148 = v3122.delay or 0
	local v3149 = v3122.kind
	if v3149 == "bolt" then
		local v3150 = v3136 / (v3122.speed or 100)
		v_u_2987(v3141, v3147, v3141.eye, v3140 + Vector3.new(0, 2.5, 0), nil, v3150, 0)
		return v3150 + 1.2
	end
	if v3149 == "spread" then
		local v3151 = v3122.count or 3
		local v3152 = v3122.spreadAngle or 40
		local v3153 = math.rad(v3152)
		local v3154 = v3136 / (v3122.speed or 100)
		for v3155 = 1, v3151 do
			local v3156 = v3151 == 1 and 0 or -v3153 / 2 + v3153 * (v3155 - 1) / (v3151 - 1)
			local v3157 = CFrame.Angles(0, v3156, 0):VectorToWorldSpace(v3128)
			local v3158 = v3123.X
			local v3159 = v_u_18 + 2.5
			local v3160 = v3123.Z
			local v3161 = Vector3.new(v3158, v3159, v3160) + v3157 * v3136
			v_u_2987(v3141, v3147, v3141.eye, v3161, nil, v3154, v3155 * 1.7)
		end
		return v3154 + 1.2
	end
	if v3149 == "beam" then
		v_u_3009(v3141, v3147, {
			["u"] = 0,
			["a"] = nil,
			["o"] = nil,
			["p"] = nil,
			["t"] = 0,
			["a"] = v3122.id,
			["o"] = v3123,
			["p"] = v3140
		})
		return v3148 + 1.2
	end
	if v3149 == "burst" or v3149 == "bind" then
		if v3122.at ~= "target" then
			local v3162 = v3123.X
			local v3163 = v_u_18
			local v3164 = v3123.Z
			v3140 = Vector3.new(v3162, v3163, v3164)
		end
		v_u_3018(v3141, v3147, v3140)
		return v3148 + 1.6
	end
	if v3149 == "zone" then
		v_u_3044(v3141, v3147, v3140)
		return v3148 + (v3122.duration or 2) + 1
	end
	if v3149 ~= "rain" then
		return 0
	end
	local v3165 = v3122.count or 6
	local v3166 = v3122.duration or 1
	local v3167 = {}
	for v3168 = 1, v3165 do
		local v3169 = v3122.radius
		local v3170 = math.random()
		local v3171 = v3169 * math.sqrt(v3170)
		local v3172 = math.random() * 3.141592653589793 * 2
		local v3173 = {
			["x"] = v3140.X + math.cos(v3172) * v3171,
			["z"] = v3140.Z + math.sin(v3172) * v3171
		}
		local v3174 = v3166 * (v3168 - 1)
		local v3175 = v3165 - 1
		v3173.at = v3148 + v3174 / math.max(v3175, 1)
		table.insert(v3167, v3173)
	end
	v_u_3059(v3141, v3147, v3140, v3167)
	return v3148 + v3166 + 1.2
end
local v_u_3176 = {}
local v_u_3177 = 0
local v_u_3178 = 30
local v_u_3179 = os.clock()
v9.on("hit", function(p3180)
	-- upvalues: (ref) v_u_3084, (ref) v_u_3085, (ref) v_u_3082, (ref) v_u_3083, (copy) v_u_3176, (ref) v_u_3178, (ref) v_u_3179, (ref) v_u_24, (ref) v_u_3177, (copy) v_u_2947, (copy) v_u_117, (copy) v_u_33
	local v3181 = p3180.id
	if type(v3181) == "number" then
		local v3182 = os.clock()
		local v3183
		if v_u_3084 and v3182 < v_u_3085 then
			v3183 = v_u_3084
		elseif v_u_3082 and v3182 < v_u_3083 then
			v3183 = v_u_3082
		else
			v3183 = nil
		end
		if v3183 then
			if v3182 - (v_u_3176[v3181] or 0) < 0.08 then
				return
			else
				local v3184 = v_u_3178 + (v3182 - v_u_3179) * 30
				v_u_3178 = math.min(30, v3184)
				v_u_3179 = v3182
				if v_u_3178 < 1 then
					return
				else
					v_u_3178 = v_u_3178 - 1
					local v3185 = v_u_24(v3181)
					if v3185 then
						if not v_u_3176[v3181] then
							v_u_3177 = v_u_3177 + 1
							if v_u_3177 > 300 then
								table.clear(v_u_3176)
								v_u_3177 = 1
							end
						end
						v_u_3176[v3181] = v3182
						local v3186 = v_u_2947(v3183.style)
						if v3186 then
							v3186 = v3186.hit
						end
						if v3186 then
							v3186(v3183, v3185, v3181)
						else
							v_u_117("Impact", v3185, v_u_33, 0.6)
						end
					else
						return
					end
				end
			end
		else
			return
		end
	else
		return
	end
end)
return v22