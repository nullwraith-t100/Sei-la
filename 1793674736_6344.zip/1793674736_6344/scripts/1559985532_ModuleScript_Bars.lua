local v_u_1 = game:GetService("Debris")
local v_u_2 = require(script.Parent.Kit)
local v_u_3 = {}
local v_u_4 = CFrame.Angles(0.7853981633974483, 0, 0)
local function v_u_13(p5, p6) -- name: frame
	local v7 = p6 - p5
	local v8 = v7.Magnitude
	local v9 = v8 <= 0.0001 and Vector3.new(1, 0, 0) or v7 / v8
	local v10 = v9.Y
	local v11 = v9:Cross(math.abs(v10) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)).Unit
	local v12 = v11:Cross(v9)
	return CFrame.fromMatrix((p5 + p6) / 2, v9, v12, v11)
end
function v_u_3.new(p14, p15, p16) -- name: new
	-- upvalues: (copy) v_u_2
	local v17 = {}
	for _ = 1, 2 do
		local v18 = v_u_2.part
		local v19 = CFrame.new(0, -500, 0)
		table.insert(v17, v18(Vector3.new(0.1, 0.1, 0.1), v19, p14, {
			["transparency"] = p15,
			["material"] = p16
		}))
	end
	return v17
end
function v_u_3.placeAt(p20, p21, p22, p23) -- name: placeAt
	-- upvalues: (copy) v_u_4
	local v24 = math.max(p22, 0.05)
	local v25 = Vector3.new(v24, p23, p23)
	p20[1].Size = v25
	p20[1].CFrame = p21
	p20[2].Size = v25
	p20[2].CFrame = p21 * v_u_4
end
function v_u_3.place(p26, p27, p28, p29) -- name: place
	-- upvalues: (copy) v_u_3, (copy) v_u_13
	v_u_3.placeAt(p26, v_u_13(p27, p28), (p28 - p27).Magnitude, p29)
end
function v_u_3.rod(p30, p31, p32, p33, p34, p35) -- name: rod
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v36 = v_u_3.new(p33, p34, p35)
	v_u_3.place(v36, p30, p31, p32)
	for _, v37 in v36 do
		v_u_1:AddItem(v37, 8)
	end
	return v36
end
function v_u_3.thin(p38, p39, p40) -- name: thin
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	for _, v41 in p38 do
		local v42 = v_u_2.tween
		local v43 = {
			["Size"] = nil,
			["Transparency"] = 1
		}
		local v44 = v41.Size.X
		v43.Size = Vector3.new(v44, 0.05, 0.05)
		local v45 = Enum.EasingStyle.Quad
		local v46
		if p40 then
			v46 = Enum.EasingDirection.In
		else
			v46 = Enum.EasingDirection.Out
		end
		v42(v41, p39, v43, v45, v46)
		v_u_1:AddItem(v41, p39 + 0.05)
	end
end
function v_u_3.path(p47, p48, p49, p50, p51) -- name: path
	-- upvalues: (copy) v_u_3
	for v52 = 2, #p47 do
		v_u_3.thin(v_u_3.rod(p47[v52 - 1], p47[v52], p48, p49, p51), p50)
	end
end
return v_u_3