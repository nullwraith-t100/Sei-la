local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v_u_2.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(160, 215, 255)
local v_u_6 = Color3.new(1, 1, 1)
local v_u_7 = Enum.PartType.Wedge
local v_u_8 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_9 = CFrame.Angles(0, -1.5707963267948966, 0)
local function v_u_18(p10, p11) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v12 = v_u_2:FindFirstChild("EyePieces")
	if v12 then
		v12 = v12:FindFirstChild(p10)
	end
	if not (v12 and v12:IsA("MeshPart")) then
		return nil
	end
	local v13 = v12:Clone()
	local v14 = v12.Size
	local v15 = v14.X
	local v16 = v14.Y
	local v17 = v14.Z
	v13.Size = v14 * (p11 / math.max(v15, v16, v17, 0.01))
	v13.Anchored = true
	v13.CanCollide = false
	v13.CanQuery = false
	v13.CanTouch = false
	v13.Massless = true
	v13.CastShadow = false
	v13.Parent = v_u_3.folder()
	return v13
end
return function(p_u_19)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_1, (copy) v_u_18, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8
	return {
		["w6_sanrei_lattice"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_3, (copy) p_u_19, (ref) v_u_5, (ref) v_u_4, (ref) v_u_6, (ref) v_u_1, (ref) v_u_18, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8
			local v_u_22 = v_u_3.color(p21.color)
			local v23 = p_u_20.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v_u_25 = CFrame.identity
			local v_u_35 = p_u_19.throb(p_u_20, 4, 1.8, 2, function(p26)
				-- upvalues: (ref) v_u_3, (ref) p_u_19, (copy) p_u_20, (ref) v_u_5, (ref) v_u_4, (ref) v_u_25, (copy) v_u_24, (ref) v_u_6, (copy) v_u_22, (ref) v_u_1
				v_u_3.ring(p_u_19.feetAt(p_u_20, p26, 0.15), v_u_5, 5.5 * p_u_20.fx, 0.5, v_u_4.Ring)
				local v27 = v_u_25.Position
				local v28 = p26.LookVector
				local v29 = p_u_19.bar
				local v30 = v_u_24 * 0.14
				local v31 = v_u_24 * 0.14
				local v32 = v_u_24 * 2.6
				local v33 = v29(Vector3.new(v30, v31, v32), v_u_6)
				v33.CFrame = CFrame.lookAt(v27, v27 + v28)
				p_u_19.tail(v33, v_u_5, v_u_22, v_u_24 * 0.3, 0.15)
				local v34 = v27 + v28 * 16 * v_u_24
				v_u_3.tween(v33, 0.22, {
					["CFrame"] = nil,
					["Transparency"] = 1,
					["CFrame"] = CFrame.lookAt(v34, v34 + v28)
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_1:AddItem(v33, 0.4)
				v_u_3.flash(v27, v_u_22, v_u_24 * 2.6, 0.2)
			end)
			local v48 = p_u_19.group(p_u_20, function(p36, p37)
				-- upvalues: (copy) v_u_24, (copy) v_u_35, (ref) v_u_25
				local v38 = CFrame.new
				local v39 = v_u_24 * 1.9
				local v40 = v_u_24 * 1.5
				local v41 = p37 * 1.5
				local v42 = p36 * v38(v39, v40 + math.sin(v41) * 0.12 * v_u_24, v_u_24 * 0.35)
				local v43 = CFrame.Angles
				local v44 = p37 * 0.9
				local v45 = math.sin(v44) * 0.06 - v_u_35() * 0.25
				local v46 = p37 * 1.2
				local v47 = v42 * v43(v45, 0, math.sin(v46) * 0.05 + 0.35)
				v_u_25 = v47
				return v47
			end)
			local v49 = v_u_18("w6_sanrei_lattice", v_u_24 * 4)
			local v_u_50 = nil
			local v_u_51 = 1
			if v49 then
				local v52 = v49:FindFirstChildOfClass("SurfaceAppearance")
				if v52 then
					v_u_51 = v52.EmissiveStrength
				else
					v49.Color = v_u_5
					v49.Material = Enum.Material.Glass
					v49.Transparency = 0.1
					v52 = v_u_50
				end
				p_u_19.pin(p_u_20, v48, v49, v_u_9)
				p_u_19.tail(v49, v_u_5, v_u_22, v_u_24 * 0.4, 0.3)
				v_u_50 = v52
			else
				local v53 = p_u_19.pin
				local v54 = p_u_19.bar
				local v55 = v_u_24 * 0.1
				local v56 = v_u_24 * 0.1
				local v57 = v_u_24 * 2.6
				v53(p_u_20, v48, v54(Vector3.new(v55, v56, v57), v_u_6), CFrame.identity)
				for _, v58 in { 1, -1 } do
					local v59 = p_u_19.bar
					local v60 = v_u_24 * 0.14
					local v61 = v_u_24 * 0.06
					local v62 = v_u_24 * 1.3
					local v63 = v59(Vector3.new(v60, v61, v62), v_u_5)
					p_u_19.pin(p_u_20, v48, v63, CFrame.new(v58 * 0.45 * v_u_24, 0, v_u_24 * 0.75) * CFrame.Angles(0, v58 * 0.9, 0))
				end
				local v64 = p_u_19.bar
				local v65 = v_u_24 * 0.06
				local v66 = v_u_24 * 0.12
				local v67 = v_u_24 * 0.4
				local v68 = v64(Vector3.new(v65, v66, v67), v_u_6)
				v68.Shape = v_u_7
				p_u_19.pin(p_u_20, v48, v68, CFrame.new(0, v_u_24 * 0.06, v_u_24 * -1.5))
			end
			local v_u_69 = 0
			local v70 = p_u_20.ticks
			local function v72(_, _, p71)
				-- upvalues: (ref) v_u_69
				v_u_69 = v_u_69 + p71 * 0.25
			end
			table.insert(v70, v72)
			local v_u_78 = p_u_19.group(p_u_20, function(p73, p74)
				-- upvalues: (copy) v_u_24, (ref) v_u_69
				local v75 = CFrame.new
				local v76 = v_u_24 * 0.85
				local v77 = p74 * 1.2
				return p73 * v75(0, v76 + math.sin(v77) * 0.1 * v_u_24, v_u_24 * 1.45) * CFrame.Angles(0, 0, v_u_69)
			end)
			local v_u_79 = p_u_19.picture(v_u_24 * 9, v_u_4.Glow, v_u_22, 0.3)
			p_u_19.pin(p_u_20, v_u_78, v_u_79, CFrame.new(0, 0, v_u_24 * -0.3) * v_u_8)
			p_u_19.fadeFromBehind(p_u_20, v_u_79, 0.5)
			local v_u_80 = {}
			local function v99(p81, p82, p83, p84) -- name: blade
				-- upvalues: (ref) p_u_19, (copy) v_u_24, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (copy) v_u_80
				local v85 = {}
				local v86 = p_u_19.bar
				local v87 = v_u_24 * 0.07
				v85.body = v86(Vector3.new(p83, v87, 1), v_u_5)
				v85.a = p81
				v85.b = p82
				v85.w = p83
				if p84 then
					local v88 = p_u_19.bar
					local v89 = v_u_24 * 0.07
					local v90 = p83 / 2
					local v91 = p83 * 1.8
					local v92 = v88(Vector3.new(v89, v90, v91), v_u_6)
					v92.Shape = v_u_7
					local v93 = p_u_19.bar
					local v94 = v_u_24 * 0.07
					local v95 = p83 / 2
					local v96 = p83 * 1.8
					local v97 = v93(Vector3.new(v94, v95, v96), v_u_6)
					v97.Shape = v_u_7
					v85.tipA = v92
					v85.tipB = v97
				end
				local v98 = v_u_80
				table.insert(v98, v85)
			end
			for _, v100 in { Vector3.new(0.6, 0.8, 0), Vector3.new(-0.6, 0.8, 0) } do
				local v101 = -v100.Y
				local v102 = v100.X
				local v103 = Vector3.new(v101, v102, 0)
				for v104, v105 in { -0.45, 0.45 } do
					local v106 = v103 * v105
					local v107 = v106 - v100 * 1.85
					local v108 = v106 + v100 * 1.85
					if v104 ~= 2 then
						local v109 = v107
						v107 = v108
						v108 = v109
					end
					v99(v108, v107, v_u_24 * 0.2, true)
				end
			end
			for _, v_u_110 in v_u_80 do
				p_u_19.add(p_u_20, v_u_110.body, function(_, p111)
					-- upvalues: (copy) v_u_35, (copy) v_u_24, (copy) v_u_110, (copy) v_u_78
					local v112 = p111 * 1.8
					local v113 = math.sin(v112) * 0.05 + 1
					local v114 = v_u_35()
					local v115 = math.min(v114, 1) * 3.141592653589793 * 0.5
					local v116 = (v113 + math.sin(v115) ^ 2 * 0.55) * v_u_24
					local v117 = v_u_110.a * v116
					local v118 = v_u_110.b * v116
					local v119 = (v118 - v117).Magnitude - v_u_110.w * 1.8
					local v120 = math.max(v119, 0.05)
					local v121 = CFrame.lookAt(v117, v118, Vector3.new(0, 0, 1))
					local v122 = v_u_110.body
					local v123 = v_u_110.w
					local v124 = v_u_24 * 0.07
					v122.Size = Vector3.new(v123, v124, v120)
					return v_u_78.cf * v121 * CFrame.new(0, 0, -v120 / 2)
				end)
				local v125 = v_u_110.tipA
				local v126 = v_u_110.tipB
				if not (v125 and v126) then
					continue
				end
				p_u_19.add(p_u_20, v125, function(_, p127)
					-- upvalues: (copy) v_u_35, (copy) v_u_24, (copy) v_u_110, (copy) v_u_78
					local v128 = p127 * 1.8
					local v129 = math.sin(v128) * 0.05 + 1
					local v130 = v_u_35()
					local v131 = math.min(v130, 1) * 3.141592653589793 * 0.5
					local v132 = (v129 + math.sin(v131) ^ 2 * 0.55) * v_u_24
					local v133 = v_u_110.a * v132
					local v134 = v_u_110.b * v132
					local v135 = (v134 - v133).Magnitude - v_u_110.w * 1.8
					local v136 = math.max(v135, 0.05)
					local v137 = CFrame.lookAt(v133, v134, Vector3.new(0, 0, 1))
					return v_u_78.cf * v137 * CFrame.new(v_u_110.w / 4, 0, -v136 - v_u_110.w * 0.9) * CFrame.Angles(0, 0, -1.5707963267948966)
				end)
				p_u_19.add(p_u_20, v126, function(_, p138)
					-- upvalues: (copy) v_u_35, (copy) v_u_24, (copy) v_u_110, (copy) v_u_78
					local v139 = p138 * 1.8
					local v140 = math.sin(v139) * 0.05 + 1
					local v141 = v_u_35()
					local v142 = math.min(v141, 1) * 3.141592653589793 * 0.5
					local v143 = (v140 + math.sin(v142) ^ 2 * 0.55) * v_u_24
					local v144 = v_u_110.a * v143
					local v145 = v_u_110.b * v143
					local v146 = (v145 - v144).Magnitude - v_u_110.w * 1.8
					local v147 = math.max(v146, 0.05)
					local v148 = CFrame.lookAt(v144, v145, Vector3.new(0, 0, 1))
					return v_u_78.cf * v148 * CFrame.new(-v_u_110.w / 4, 0, -v147 - v_u_110.w * 0.9) * CFrame.Angles(0, 0, 1.5707963267948966)
				end)
			end
			local v_u_149 = -1
			local v150 = p_u_20.ticks
			local function v157()
				-- upvalues: (copy) v_u_35, (ref) v_u_149, (ref) v_u_5, (ref) v_u_6, (copy) v_u_80, (copy) v_u_24, (copy) v_u_79, (ref) v_u_50, (ref) v_u_51
				local v151 = v_u_35()
				local v152 = v151 - v_u_149
				if math.abs(v152) >= 0.01 then
					v_u_149 = v151
					local v153 = v_u_5:Lerp(v_u_6, v151)
					for _, v154 in v_u_80 do
						v154.body.Color = v153
					end
					local v155 = v_u_24 * 9 * (1 + v151 * 0.35)
					v_u_79.Size = Vector3.new(v155, 0.05, v155)
					local v156 = v_u_50
					if v156 then
						v156.EmissiveStrength = v_u_51 * (1 + v151 * 1.5)
					end
				end
			end
			table.insert(v150, v157)
			p_u_19.particles(p_u_20, "AuraMode", v_u_22, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_19.particles(p_u_20, "Petals", v_u_5, {
				["rate"] = 0.5,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end