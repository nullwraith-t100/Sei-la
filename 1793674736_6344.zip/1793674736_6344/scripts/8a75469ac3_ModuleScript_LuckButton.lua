local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(script.Parent.Events)
local v_u_5 = require(script.Parent.LuckLadder)
local v_u_6 = require(script.Parent.Sfx)
local v_u_7 = require(script.Parent.Store)
local v_u_8 = require(script.Parent.StoreLook)
local v_u_9 = require(script.Parent.Tutorial)
local v10 = {}
local v_u_11 = v1.LocalPlayer
local v_u_12 = Color3.fromRGB
local v_u_13 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_14 = v_u_12(120, 236, 88)
local v_u_15 = v_u_12(255, 196, 40)
local v_u_16 = v_u_12(20, 92, 30)
local v_u_17 = {
	v_u_12(255, 255, 230),
	v_u_12(255, 222, 70),
	v_u_12(120, 245, 100),
	v_u_12(255, 222, 70)
}
local v_u_18 = {
	Vector2.new(0.04, 0.08),
	Vector2.new(0.97, 0.12),
	Vector2.new(0.9, 0.95),
	Vector2.new(0.12, 0.9),
	Vector2.new(0.55, -0.02)
}
local function v_u_24(p19) -- name: fresh
	for _, v20 in p19:GetDescendants() do
		local v21 = v20.Parent
		local v22
		if v20.Name == "Shine" and v21 ~= nil then
			v22 = v21:GetAttribute("Ui-Effect") == "Shine"
		else
			v22 = false
		end
		if v22 or v20.Name == "PadHint" then
			v20:Destroy()
		elseif v20:IsA("ImageLabel") then
			local v23 = v20:GetAttribute("Ui-Effect")
			if v23 ~= "Bg_X" and v23 ~= "Bg_Y" then
				continue
			end
			v20.Position = UDim2.fromScale(v20.Position.X.Scale, v20.Position.Y.Scale)
			v20.Size = UDim2.fromScale(v20.Size.X.Scale, v20.Size.Y.Scale)
		else
			if not v20:IsA("UIScale") or v20.Name ~= "Pop" then
				continue
			end
			v20.Scale = 1
		end
	end
end
local function v_u_29(p25, p26, p27) -- name: sparkle
	-- upvalues: (copy) v_u_12
	local v28 = Instance.new("ImageLabel")
	v28.Name = p26
	v28.BackgroundTransparency = 1
	v28.Image = "rbxasset://textures/particles/sparkles_main.dds"
	v28.ImageColor3 = v_u_12(255, 250, 200)
	v28.AnchorPoint = Vector2.new(0.5, 0.5)
	v28.ImageTransparency = 1
	v28.ZIndex = p27
	Instance.new("UIAspectRatioConstraint").Parent = v28
	v28.Parent = p25
	return v28
end
local v_u_30 = 0
local function v_u_78(p31) -- name: celebrate
	-- upvalues: (ref) v_u_30, (copy) v_u_11, (copy) v_u_12, (copy) v_u_5, (copy) v_u_13, (copy) v_u_16, (copy) v_u_29, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_8, (copy) v_u_17
	v_u_30 = v_u_30 + 1
	local v_u_32 = v_u_30
	local v33 = v_u_11:WaitForChild("PlayerGui")
	local v34 = v33:FindFirstChild("LuckCelebration")
	if v34 then
		v34:Destroy()
	end
	local v_u_35 = Instance.new("ScreenGui")
	v_u_35.Name = "LuckCelebration"
	v_u_35.DisplayOrder = 46
	v_u_35.IgnoreGuiInset = true
	v_u_35.ResetOnSpawn = false
	local v_u_36 = Instance.new("Frame")
	v_u_36.BackgroundTransparency = 1
	v_u_36.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_36.Position = UDim2.fromScale(0.5, 0.42)
	v_u_36.Size = UDim2.fromScale(0.5, 0.5)
	v_u_36.SizeConstraint = Enum.SizeConstraint.RelativeYY
	local v_u_37 = Instance.new("UIScale")
	v_u_37.Scale = 0.2
	v_u_37.Parent = v_u_36
	v_u_36.Parent = v_u_35
	local v_u_38 = Instance.new("ImageLabel")
	v_u_38.BackgroundTransparency = 1
	v_u_38.Image = "rbxassetid://96427887277553"
	v_u_38.ImageColor3 = v_u_12(255, 236, 140)
	v_u_38.ImageTransparency = 0.1
	v_u_38.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_38.Position = UDim2.fromScale(0.5, 0.42)
	v_u_38.Size = UDim2.fromScale(1.9, 1.9)
	v_u_38.ZIndex = 1
	v_u_38.Parent = v_u_36
	local v_u_39 = v_u_38:Clone()
	v_u_39.ImageColor3 = v_u_12(130, 255, 110)
	v_u_39.ImageTransparency = 0.35
	v_u_39.Size = UDim2.fromScale(1.45, 1.45)
	v_u_39.ZIndex = 2
	v_u_39.Parent = v_u_36
	local v_u_40 = Instance.new("ImageLabel")
	v_u_40.BackgroundTransparency = 1
	v_u_40.Image = v_u_5.picture(p31)
	v_u_40.ScaleType = Enum.ScaleType.Fit
	v_u_40.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_40.Position = UDim2.fromScale(0.5, 0.42)
	v_u_40.Size = UDim2.fromScale(0.62, 0.62)
	v_u_40.ZIndex = 3
	v_u_40.Parent = v_u_36
	local function v47(p41, p42, p43, p44) -- name: words
		-- upvalues: (ref) v_u_13, (ref) v_u_16, (copy) v_u_36
		local v45 = Instance.new("TextLabel")
		v45.BackgroundTransparency = 1
		v45.AnchorPoint = Vector2.new(0.5, 0.5)
		v45.Position = UDim2.fromScale(0.5, p42)
		v45.Size = UDim2.fromScale(2.2, p43)
		v45.FontFace = v_u_13
		v45.TextScaled = true
		v45.Text = p41
		v45.TextColor3 = Color3.new(1, 1, 1)
		v45.ZIndex = 5
		local v46 = Instance.new("UIStroke")
		v46.Thickness = p44
		v46.Color = v_u_16
		v46.Parent = v45
		v45.Parent = v_u_36
		return v45
	end
	local v_u_48 = v47(("LUCK x%*!"):format(p31), 0.86, 0.24, 4)
	local v_u_49 = Instance.new("UIGradient")
	v_u_49.Parent = v_u_48
	local v_u_50 = v47(p31 >= 8 and "MAX LUCK: RARER PETS + BOSS DROPS" or "FOR GOOD: RARER PETS + BOSS DROPS", 1.03, 0.1, 2.5)
	local v51 = {}
	for v52 = 1, 16 do
		local v53 = v_u_29(v_u_36, "Burst", 4)
		v53.Position = UDim2.fromScale(0.5, 0.42)
		v53.Size = UDim2.fromScale(0.07, 0.07)
		v53.ImageTransparency = 0
		local v54
		if v52 % 2 == 0 then
			v54 = v_u_12(255, 236, 120)
		else
			v54 = v_u_12(170, 255, 140)
		end
		v53.ImageColor3 = v54
		table.insert(v51, v53)
	end
	v_u_35.Parent = v33
	v_u_6.play("RevealBig")
	local v55 = Enum.EasingStyle.Back
	v_u_3:Create(v_u_37, TweenInfo.new(0.45, v55 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Scale"] = 1
	}):Play()
	for v56, v57 in v51 do
		local v58 = v56 / #v51 * 3.141592653589793 * 2 + math.random() * 0.3
		local v59 = 0.55 + math.random() * 0.35
		local v60 = 0.06 + math.random() * 0.06
		local v61 = 0.9 + math.random() * 0.4
		local v62 = {
			["Position"] = nil,
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Rotation"] = nil,
			["Position"] = UDim2.fromScale(0.5 + math.cos(v58) * v59, 0.42 + math.sin(v58) * v59),
			["Size"] = UDim2.fromScale(v60, v60),
			["Rotation"] = math.random(-180, 180)
		}
		local v63 = Enum.EasingStyle.Quart
		v_u_3:Create(v57, TweenInfo.new(v61, v63 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v62):Play()
	end
	local v_u_64 = os.clock()
	local v_u_73 = v_u_2.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_64, (copy) v_u_38, (copy) v_u_39, (copy) v_u_40, (copy) v_u_49, (ref) v_u_8, (ref) v_u_17
		local v65 = os.clock() - v_u_64
		v_u_38.Rotation = v65 * 40 % 360
		v_u_39.Rotation = -(v65 * 25) % 360
		local v66 = v_u_40
		local v67 = v65 * 2.6
		v66.Rotation = math.sin(v67) * 7
		local v68 = v_u_40
		local v69 = UDim2.fromScale
		local v70 = v65 * 5
		local v71 = math.sin(v70) * 0.02 + 0.62
		local v72 = v65 * 5
		v68.Size = v69(v71, math.sin(v72) * 0.02 + 0.62)
		v_u_49.Color = v_u_8.flowing(v_u_17, 0, 1, v65 * 0.5 % 1, v65 * 0.7 % 1.6 - 0.3)
	end)
	task.delay(2.9, function()
		-- upvalues: (ref) v_u_30, (copy) v_u_32, (copy) v_u_37, (ref) v_u_3, (copy) v_u_48, (copy) v_u_50, (copy) v_u_73, (copy) v_u_35
		if v_u_30 == v_u_32 then
			local v74 = v_u_37
			local v75 = Enum.EasingStyle.Back
			local v76 = Enum.EasingDirection.In
			v_u_3:Create(v74, TweenInfo.new(0.3, v75 or Enum.EasingStyle.Quad, v76 or Enum.EasingDirection.Out), {
				["Scale"] = 0
			}):Play()
			for _, v77 in { v_u_48, v_u_50 } do
				v_u_3:Create(v77, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["TextTransparency"] = 1
				}):Play()
			end
		end
		task.wait(0.35)
		v_u_73:Disconnect()
		v_u_35:Destroy()
	end)
end
function v10.start() -- name: start
	-- upvalues: (copy) v_u_5, (copy) v_u_11, (copy) v_u_24, (copy) v_u_14, (copy) v_u_12, (copy) v_u_15, (copy) v_u_16, (copy) v_u_18, (copy) v_u_29, (copy) v_u_9, (copy) v_u_7, (copy) v_u_3, (copy) v_u_4, (copy) v_u_78, (copy) v_u_2, (copy) v_u_8, (copy) v_u_17
	if v_u_5.on() then
		v_u_5.start()
		local v_u_79 = v_u_11:WaitForChild("PlayerGui"):WaitForChild("Main")
		local v80 = v_u_79:WaitForChild("HUD", 30)
		local v_u_81
		if v80 then
			v_u_81 = v80:WaitForChild("Upgrade", 30)
		else
			v_u_81 = v80
		end
		if v_u_79:IsA("GuiBase2d") and (v80 and (v_u_81 and v_u_81:IsA("GuiButton"))) then
			local v_u_82 = Instance.new("Frame")
			v_u_82.Name = "LuckLadder"
			v_u_82.BackgroundTransparency = 1
			v_u_82.AnchorPoint = Vector2.new(1, 0)
			v_u_82.Visible = false
			local v83 = Instance.new("Frame")
			v83.Name = "Beat"
			v83.BackgroundTransparency = 1
			v83.Size = UDim2.fromScale(1, 1)
			local v_u_84 = Instance.new("UIScale")
			v_u_84.Name = "Beat"
			v_u_84.Parent = v83
			v83.Parent = v_u_82
			local v85 = v_u_81:Clone()
			v_u_24(v85)
			v85.Name = "Button"
			v85.Visible = true
			v85.AnchorPoint = Vector2.new(0.5, 0.5)
			v85.Position = UDim2.fromScale(0.5, 0.5)
			v85.Size = UDim2.fromScale(1, 1)
			local v86 = v85:FindFirstChildOfClass("UIAspectRatioConstraint")
			if v86 then
				v86:Destroy()
			end
			local v87 = v85:FindFirstChildOfClass("UIGradient")
			if v87 then
				v87.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_14), ColorSequenceKeypoint.new(0.55, v_u_12(200, 226, 60)), ColorSequenceKeypoint.new(1, v_u_15) })
				v87.Rotation = 90
			end
			for _, v88 in v85:GetChildren() do
				if not v88:IsA("UIStroke") or v88.Color.R >= 0.6 then
					continue
				end
				v88.Color = v_u_16
			end
			local v_u_89 = v85:FindFirstChild("Icon")
			if v_u_89 and v_u_89:IsA("ImageLabel") then
				v_u_89.Image = v_u_5.picture(2)
				v_u_89.ScaleType = Enum.ScaleType.Fit
			end
			local v_u_90 = v85:FindFirstChild("Title")
			local v_u_91 = v85:FindFirstChild("Price")
			if v_u_90 and (v_u_90:IsA("TextLabel") and (v_u_91 and v_u_91:IsA("TextLabel"))) then
				v_u_91.RichText = true
				local v_u_92 = Instance.new("UIGradient")
				v_u_92.Name = "TitlePaint"
				v_u_92.Parent = v_u_90
				v_u_90.TextColor3 = Color3.new(1, 1, 1)
				local v93 = Instance.new("CanvasGroup")
				v93.Name = "ShineContainer"
				v93.BackgroundTransparency = 1
				v93.Size = UDim2.fromScale(1, 1)
				v93.ZIndex = 7
				local v94 = v85:FindFirstChildOfClass("UICorner")
				if v94 then
					v94:Clone().Parent = v93
				end
				v93:SetAttribute("Ui-Effect", "Shine")
				v93:SetAttribute("Ui-Effect-Rate", 0.9)
				v93.Parent = v85
				v85.Parent = v83
				local v_u_95 = {}
				for v96, v97 in v_u_18 do
					local v98 = v_u_29(v_u_82, "Sparkle" .. v96, 9)
					v98.Position = UDim2.fromScale(v97.X, v97.Y)
					table.insert(v_u_95, v98)
				end
				v_u_82.Parent = v80
				local function v102() -- name: place
					-- upvalues: (copy) v_u_79, (copy) v_u_81, (copy) v_u_82
					local v99 = v_u_79.AbsolutePosition
					local v100 = v_u_81.AbsolutePosition.X + v_u_81.AbsoluteSize.X - v99.X
					local v101 = v_u_81.AbsolutePosition.Y - v99.Y
					if v_u_81.Visible then
						v101 = v101 + (v_u_81.AbsoluteSize.Y + 6)
					end
					v_u_82.Position = UDim2.fromOffset(v100, v101)
					v_u_82.Size = UDim2.fromOffset(v_u_81.AbsoluteSize.X, v_u_81.AbsoluteSize.Y)
				end
				for _, v103 in { "AbsolutePosition", "AbsoluteSize", "Visible" } do
					v_u_81:GetPropertyChangedSignal(v103):Connect(v102)
				end
				v_u_79:GetPropertyChangedSignal("AbsoluteSize"):Connect(v102)
				v102()
				local v_u_104 = nil
				local function v_u_110() -- name: refresh
					-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (copy) v_u_90, (copy) v_u_91, (copy) v_u_89, (ref) v_u_104, (copy) v_u_82, (copy) v_u_84, (ref) v_u_3
					local v105 = v_u_5.offer()
					local v106 = v105 ~= nil and (v_u_9.known() and not v_u_9.active())
					if v106 then
						v106 = not v_u_7.quiet()
					end
					if v105 then
						local v107 = v105.mult or 2
						v_u_90.Text = ("x%* LUCK"):format(v107)
						v_u_91.Text = ("ONLY <font color=\"#5CFF6A\">%*</font>%*"):format(v_u_7.ROBUX, v105.price)
						if v_u_89 and v_u_89:IsA("ImageLabel") then
							v_u_89.Image = v_u_5.picture(v107)
						end
						v_u_104 = v107
					end
					if v106 and not v_u_82.Visible then
						v_u_82.Visible = true
						v_u_84.Scale = 0.3
						local v108 = v_u_84
						local v109 = Enum.EasingStyle.Back
						v_u_3:Create(v108, TweenInfo.new(0.4, v109 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Scale"] = 1
						}):Play()
					elseif not v106 and v_u_82.Visible then
						v_u_82.Visible = false
					end
				end
				v_u_5.changed:Connect(v_u_110)
				v_u_9.onChange(function()
					-- upvalues: (copy) v_u_110
					v_u_110()
				end)
				v_u_110()
				task.spawn(function()
					-- upvalues: (copy) v_u_82, (copy) v_u_110
					while v_u_82.Parent do
						task.wait(2)
						v_u_110()
					end
				end)
				v85.Activated:Connect(function()
					-- upvalues: (ref) v_u_5
					v_u_5.buy()
				end)
				local v_u_111 = false
				v_u_4.onNotify("LuckTier", function(p112)
					-- upvalues: (ref) v_u_5, (ref) v_u_78, (copy) v_u_82, (ref) v_u_111, (copy) v_u_84, (ref) v_u_3, (copy) v_u_110
					if type(p112) ~= "number" then
						p112 = v_u_5.tier()
					end
					v_u_78(p112)
					if v_u_82.Visible then
						v_u_111 = true
						local v113 = v_u_84
						local v114 = Enum.EasingStyle.Quad
						v_u_3:Create(v113, TweenInfo.new(0.18, v114 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Scale"] = 1.3
						}):Play()
						task.wait(0.2)
						if v_u_5.offer() then
							v_u_110()
							local v115 = v_u_84
							local v116 = Enum.EasingStyle.Back
							v_u_3:Create(v115, TweenInfo.new(0.45, v116 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Scale"] = 1
							}):Play()
							task.wait(0.45)
						else
							local v117 = v_u_84
							local v118 = Enum.EasingStyle.Back
							local v119 = Enum.EasingDirection.In
							v_u_3:Create(v117, TweenInfo.new(0.3, v118 or Enum.EasingStyle.Quad, v119 or Enum.EasingDirection.Out), {
								["Scale"] = 0
							}):Play()
							task.wait(0.3)
							v_u_110()
							v_u_84.Scale = 1
						end
						v_u_111 = false
					end
				end)
				v_u_2.RenderStepped:Connect(function()
					-- upvalues: (copy) v_u_82, (ref) v_u_111, (copy) v_u_84, (copy) v_u_92, (ref) v_u_8, (ref) v_u_17, (copy) v_u_95
					if v_u_82.Visible then
						local v120 = os.clock()
						if not v_u_111 then
							local v121 = v120 * 3.4
							local v122 = math.sin(v121)
							local v123 = math.max(v122, 0)
							v_u_84.Scale = v123 * 0.045 * v123 + 1
						end
						v_u_92.Color = v_u_8.flowing(v_u_17, 0, 1, v120 * 0.3 % 1, nil)
						for v124, v125 in v_u_95 do
							local v126 = (v120 * 0.9 + v124 * 0.37) % 1.6
							local v127
							if v126 < 1 then
								local v128 = v126 * 3.141592653589793
								v127 = math.sin(v128)
							else
								v127 = 0
							end
							v125.ImageTransparency = 1 - v127
							v125.Size = UDim2.fromScale(1, v127 * 0.25 + 0.3)
							v125.Rotation = (v120 * 90 + v124 * 40) % 360
						end
					end
				end)
				if v_u_2:IsStudio() then
					task.spawn(function()
						-- upvalues: (copy) v_u_82, (ref) v_u_11, (ref) v_u_104
						while v_u_82.Parent do
							local v129 = v_u_11
							local v130 = "LuckShown"
							local v131
							if v_u_82.Visible then
								v131 = v_u_104
							else
								v131 = nil
							end
							v129:SetAttribute(v130, v131)
							task.wait(1)
						end
					end)
				end
			end
		else
			return
		end
	else
		return
	end
end
return v10