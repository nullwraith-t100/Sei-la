local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.CalmStream, v_u_7.CalmSpiral, v_u_7.CalmSlash })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("2EA8FF")
local v_u_10 = Color3.fromHex("FFF7C2")
local v_u_11 = Color3.fromRGB(14, 30, 82)
local v_u_12 = Color3.fromRGB(24, 72, 170)
local function v_u_22(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part(Vector3.new(p14, 0.05, p14), p13, p16, {
		["transparency"] = 1
	})
	local v19 = {}
	for _, v20 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v21 = Instance.new("Decal")
		v21.Face = v20
		v21.Texture = p15
		v21.Color3 = p16
		v21.Transparency = p17
		v21.Parent = v18
		table.insert(v19, v21)
	end
	return v18, v19
end
local function v_u_57(p23, p24, p25, p26, p27, p28, p29, p30, p31, p32, p33, p34) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v35 = p29 + p30 + p31
	local v36 = math.max(v35, 0.05)
	local v37 = {}
	local v38 = {}
	for v39 = 0, 10 do
		local v40 = v39 / 10
		local v41 = v40 * v36
		local v42 = v41 / math.max(p29, 0.001)
		local v43 = 1 - (1 - math.clamp(v42, 0, 1)) ^ 3
		local v44 = (v41 - p29 - p30) / math.max(p31, 0.001)
		local v45 = math.clamp(v44, 0, 1)
		local v46 = v45 * v45 * (3 - v45 * 2)
		local v47 = NumberSequenceKeypoint.new
		local v48 = p24 + (p25 - p24) * v43
		local v49 = math.max(v48, 0.05) / 2
		table.insert(v38, v47(v40, v49))
		local v50 = NumberSequenceKeypoint.new
		local v51 = p28 + (1 - p28) * v46
		local v52 = math.clamp(v51, 0, 1)
		table.insert(v37, v50(v40, v52))
	end
	local v53 = Instance.new("Attachment")
	v53.WorldCFrame = CFrame.new(p23)
	v53.Parent = v_u_3.Terrain
	local v54 = Instance.new("ParticleEmitter")
	v54.Enabled = false
	v54.Texture = p26
	v54.Color = ColorSequence.new(p27)
	v54.LightEmission = p33 or 0
	v54.LightInfluence = 0
	v54.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v54.EmissionDirection = Enum.NormalId.Top
	v54.SpreadAngle = Vector2.zero
	v54.Speed = NumberRange.new(0.01)
	v54.Size = NumberSequence.new(v38)
	v54.Transparency = NumberSequence.new(v37)
	v54.Lifetime = NumberRange.new(v36)
	local v55 = p32 or math.random(0, 359)
	v54.Rotation = NumberRange.new(v55, v55)
	local v56 = p34 or 0
	v54.RotSpeed = NumberRange.new(v56, v56)
	v54.Parent = v53
	v54:Emit(1)
	v_u_1:AddItem(v53, v36 + 0.2)
end
local function v_u_66(p58, p59, p60, p61, p62) -- name: cutAt
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_1
	local v63 = p62 or 0.45
	local v64 = Instance.new("Attachment")
	v64.WorldPosition = p58
	v64.Parent = v_u_3.Terrain
	local v65 = Instance.new("ParticleEmitter")
	v65.Enabled = false
	v65.Texture = v_u_7.CalmSlash
	v65.Color = ColorSequence.new(p60)
	v65.LightEmission = 0.2
	v65.LightInfluence = 0
	v65.Speed = NumberRange.new(0)
	v65.Lifetime = NumberRange.new(v63)
	v65.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p59 * 0.15), NumberSequenceKeypoint.new(0.15, p59 * 0.5), NumberSequenceKeypoint.new(1, p59 * 0.56) })
	v65.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.45, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v65.Rotation = NumberRange.new(p61, p61)
	v65.Parent = v64
	v65:Emit(1)
	v_u_1:AddItem(v64, v63 + 0.2)
end
local function v_u_73(p67, p68, p69) -- name: stream
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_1
	local v70 = Instance.new("Attachment")
	v70.Parent = p67
	local v71 = Instance.new("Attachment")
	v71.Parent = p67
	local v72 = Instance.new("Beam")
	v72.Attachment0 = v70
	v72.Attachment1 = v71
	v72.Texture = v_u_7.CalmStream
	v72.TextureMode = Enum.TextureMode.Wrap
	v72.TextureLength = p68 * 1.42
	v72.TextureSpeed = 2
	v72.Color = ColorSequence.new(v_u_8)
	v72.LightEmission = 0.2
	v72.LightInfluence = 0
	v72.FaceCamera = true
	v72.Segments = 14
	v72.Width0 = p68
	v72.Width1 = p68
	v72.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0.8),
		NumberSequenceKeypoint.new(0.15, 0),
		NumberSequenceKeypoint.new(0.85, 0),
		NumberSequenceKeypoint.new(1, 0.8)
	})
	v72.Parent = v70
	v_u_1:AddItem(v70, p69)
	v_u_1:AddItem(v71, p69)
	return v70, v71, v72
end
local function v_u_101(p74, p75, p76, p77, p78, p79, p80, p81, p82) -- name: arcAlong
	local v83 = math.cos(p79) * p78
	local v84 = math.sin(p79) * p78
	local v85 = p77 + Vector3.new(v83, p81, v84)
	local v86 = p79 + p80
	local v87 = math.cos(v86) * p78
	local v88 = p79 + p80
	local v89 = math.sin(v88) * p78
	local v90 = p77 + Vector3.new(v87, p82, v89)
	local v91 = CFrame.fromMatrix
	local v92 = -math.sin(p79)
	local v93 = math.cos(p79)
	p74.WorldCFrame = v91(v85, Vector3.new(v92, 0, v93), Vector3.new(0, 1, 0))
	local v94 = CFrame.fromMatrix
	local v95 = p79 + p80
	local v96 = -math.sin(v95)
	local v97 = p79 + p80
	local v98 = math.cos(v97)
	p75.WorldCFrame = v94(v90, Vector3.new(v96, 0, v98), Vector3.new(0, 1, 0))
	local v99 = p80 / 4
	local v100 = math.tan(v99) * 1.3333333333333333 * p78
	p76.CurveSize0 = v100
	p76.CurveSize1 = v100
end
return function(p_u_102)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_11, (copy) v_u_7, (copy) v_u_10, (copy) v_u_22, (copy) v_u_1, (copy) v_u_66, (copy) v_u_57, (copy) v_u_12, (copy) v_u_73, (copy) v_u_101, (copy) v_u_6
	local v103 = {}
	local function v_u_109(p104, p105, p106, p107) -- name: spray
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (copy) p_u_102, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10
		v_u_4.flash(p104, v_u_8, p105 * 2.4, 0.12)
		v_u_4.flash(p104, v_u_9, p105 * 4.6, 0.24)
		v_u_4.ring(p_u_102.ground(p104, 0.12), v_u_11, p105 * 3, 0.3, v_u_7.Ring)
		v_u_4.ring(p_u_102.ground(p104, 0.16), v_u_9, p105 * 4.4, 0.4, v_u_7.Ring)
		if not p107 then
			local v108 = { v_u_8, v_u_9, v_u_10 }
			p_u_102.chunks(p104, v108, p106, 20, p105 * 0.3, 0.6, true, 1)
		end
	end
	v103.dead_calm_a = {
		["windup"] = function(p110, _, _) -- name: windup
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			v_u_4.flash(p110.eye + p110.dir * 0.8, v_u_9, 2.2 * p110.size, 0.1)
		end,
		["beam"] = function(p_u_111, p_u_112, p_u_113) -- name: beam
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_22, (ref) v_u_9, (ref) v_u_1, (copy) p_u_102, (copy) v_u_109, (ref) v_u_66
			local v_u_114 = p_u_111.size
			local v115 = v_u_4.beam(p_u_112, p_u_113, v_u_8, 2 * v_u_114, 0.3, v_u_7.CalmStream)
			v115.LightEmission = 0.2
			v115.TextureLength = 2.8 * v_u_114
			v115.TextureSpeed = 4
			local v116 = p_u_113 - p_u_112
			local v_u_117
			if v116.Magnitude > 0.001 then
				v_u_117 = v116.Unit
			else
				v_u_117 = p_u_111.dir
			end
			local v118 = v_u_117:Cross(Vector3.new(0, 1, 0))
			local v_u_119 = v118.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v118.Unit
			local v120 = CFrame.fromMatrix(p_u_112, v_u_117, v_u_119)
			local v_u_121 = {}
			for v122 = 0, p_u_111.lite and 0 or 1 do
				local v123 = v_u_22
				local v124 = 4.2 * v_u_114
				local v125 = v_u_7.CalmSlash
				local v126
				if v122 == 0 then
					v126 = v_u_8
				else
					v126 = v_u_9
				end
				local v127 = v123(v120, v124, v125, v126, 0)
				v_u_1:AddItem(v127, 0.5)
				table.insert(v_u_121, v127)
			end
			local v128 = v116.Magnitude / 420
			local v129 = math.clamp(v128, 0.06, 0.16)
			p_u_102.animate(v129, 0, function(p130)
				-- upvalues: (copy) p_u_112, (copy) p_u_113, (copy) v_u_121, (copy) v_u_117, (ref) v_u_119, (ref) v_u_109, (copy) v_u_114, (copy) p_u_111, (ref) v_u_66, (ref) v_u_8
				local v131 = p_u_112:Lerp(p_u_113, p130)
				for v132, v133 in v_u_121 do
					v133.CFrame = CFrame.fromMatrix(v131, v_u_117, v_u_119) * CFrame.Angles(0, -p130 * 9 + v132 * 3.141592653589793, 0)
				end
				if p130 >= 1 then
					for _, v134 in v_u_121 do
						v134:Destroy()
					end
					v_u_109(p_u_113, v_u_114, 3, p_u_111.lite)
					v_u_66(p_u_113 + Vector3.new(0, 0.5, 0), 4 * v_u_114, v_u_8, math.random(0, 359), 0.3)
				end
			end)
		end,
		["hit"] = function(_, p135, _) -- name: hit
			-- upvalues: (copy) p_u_102, (ref) v_u_9
			p_u_102.burst("Impact", p135, v_u_9, 0.6)
		end
	}
	local v_u_136 = {}
	setmetatable(v_u_136, {
		["__mode"] = "k"
	})
	v103.dead_calm_e = {
		["cast"] = function(p137) -- name: cast
			-- upvalues: (copy) p_u_102, (ref) v_u_9
			p_u_102.skillCast(p137, v_u_9)
		end,
		["windup"] = function(p138, p139, p140) -- name: windup
			-- upvalues: (copy) p_u_102, (ref) v_u_9
			local v141 = p138.size
			local v142 = math.max(p140, 0.1)
			p_u_102.inward(p_u_102.ground(p139, 1.5), v_u_9, p138.lite and 4 or 9, 9 * v141, v142 + 0.05)
		end,
		["land"] = function(p_u_143, p144) -- name: land
			-- upvalues: (copy) p_u_102, (ref) v_u_57, (ref) v_u_7, (ref) v_u_11, (ref) v_u_8, (ref) v_u_4, (ref) v_u_12, (ref) v_u_1, (ref) v_u_73, (ref) v_u_101, (copy) v_u_109, (ref) v_u_6
			local v_u_145 = p_u_143.size
			local v_u_146 = p_u_143.ability.radius * v_u_145
			local v_u_147 = p_u_143.ability.freeze or 3
			local v_u_148 = p_u_102.ground(p144, 0.12)
			v_u_57(v_u_148, v_u_146, v_u_146 * 2.4, v_u_7.Glow, v_u_11, 0.3, 0.25, v_u_147 - 0.3, 0.5, nil, 0)
			v_u_57(v_u_148 + Vector3.new(0, 0.04, 0), v_u_146 * 0.6, v_u_146 * 2.15, v_u_7.CalmSpiral, v_u_8, 0.05, 0.3, v_u_147 - 0.3, 0.5, 0, 0.1, -140)
			v_u_57(v_u_148 + Vector3.new(0, 0.08, 0), v_u_146 * 1.9, v_u_146 * 2.25, v_u_7.Ring, v_u_8, 0.1, 0.3, v_u_147 - 0.3, 0.5, 0, 0.2)
			v_u_4.ring(v_u_148, v_u_12, v_u_146 * 1.2, 0.5, v_u_7.Ring)
			local v_u_149 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_148), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_149, v_u_147 + 1)
			local v_u_150 = p_u_143.lite and 2 or 4
			local v_u_151 = {}
			for _ = 1, v_u_150 do
				local v152, v153, v154 = v_u_73(v_u_149, 2.6 * v_u_145, v_u_147 + 1)
				table.insert(v_u_151, {
					["a0"] = v152,
					["a1"] = v153,
					["b"] = v154
				})
			end
			local v_u_155 = os.clock()
			local v_u_156 = 6.283185307179586 / v_u_150 * 0.85
			p_u_102.frame(function()
				-- upvalues: (copy) v_u_149, (copy) v_u_155, (copy) v_u_147, (copy) v_u_151, (copy) v_u_150, (copy) v_u_145, (ref) v_u_101, (copy) v_u_148, (copy) v_u_146, (copy) v_u_156, (ref) v_u_109, (copy) p_u_143, (ref) v_u_57, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6
				if not v_u_149.Parent then
					return false
				end
				local v157 = os.clock() - v_u_155
				local v158 = v157 / 0.3
				local v159 = math.clamp(v158, 0, 1)
				local v160 = v159 * v159 * (3 - v159 * 2)
				local v161 = (v157 - v_u_147 + 0.4) / 0.4
				local v162 = math.clamp(v161, 0, 1)
				local v163 = v160 * (1 - v162 * v162 * (3 - v162 * 2))
				for v164, v165 in v_u_151 do
					local v166 = -v157 * 1.6 + (v164 - 1) / v_u_150 * 3.141592653589793 * 2
					local v167 = v163 * 1.6 + 0.6
					local v168 = v157 * 4 + v164
					local v169 = (v167 + math.sin(v168) * 0.5) * v_u_145
					local v170 = v_u_101
					local v171 = v165.a0
					local v172 = v165.a1
					local v173 = v165.b
					local v174 = v_u_148
					local v175 = v_u_146
					local v176 = v157 / v_u_147
					local v177 = math.clamp(v176, 0, 1)
					v170(v171, v172, v173, v174, v175 * (0.98 - v177 * v177 * (3 - v177 * 2) * 0.15), v166, v_u_156, v169, v169)
					v165.b.Width0 = 2.6 * v_u_145 * math.max(v163, 0.05)
					v165.b.Width1 = v165.b.Width0
				end
				if v_u_147 > v157 then
					return true
				end
				v_u_149:Destroy()
				v_u_109(v_u_148 + Vector3.new(0, 1.5, 0), v_u_145 * 1.6, 8, p_u_143.lite)
				v_u_57(v_u_148, v_u_146 * 0.5, v_u_146 * 2.4, v_u_7.Ring, v_u_8, 0, 0.12, 0.05, 0.4, 0, 0.3)
				v_u_6.play("Crit", {
					["at"] = v_u_148,
					["volume"] = p_u_143.mine and 0.6 or 0.35
				})
				return false
			end)
			if p_u_143.mine then
				v_u_4.shake(0.2, 0.2)
			end
		end,
		["hit"] = function(p_u_178, p_u_179, _) -- name: hit
			-- upvalues: (copy) p_u_102, (ref) v_u_9, (copy) v_u_136, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_73, (ref) v_u_101, (ref) v_u_66, (copy) v_u_109
			local v_u_180 = p_u_178.size
			p_u_102.burst("Impact", p_u_179, v_u_9, 0.6)
			local v181 = (v_u_136[p_u_178] or 0) + 1
			v_u_136[p_u_178] = v181
			if (p_u_178.lite and 2 or 6) >= v181 then
				local v_u_182 = p_u_178.ability.freeze or 3
				local v_u_183 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_179), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_183, v_u_182 + 1)
				local v_u_184 = {}
				for _ = 1, 2 do
					local v185, v186, v187 = v_u_73(v_u_183, 1.1 * v_u_180, v_u_182 + 1)
					table.insert(v_u_184, {
						["a0"] = v185,
						["a1"] = v186,
						["b"] = v187
					})
				end
				local v_u_188 = p_u_102.ground(p_u_179, 0)
				local v_u_189 = os.clock()
				p_u_102.frame(function()
					-- upvalues: (copy) v_u_183, (copy) v_u_189, (copy) v_u_184, (copy) v_u_180, (ref) v_u_101, (copy) v_u_188, (copy) v_u_182, (ref) v_u_66, (copy) p_u_179, (ref) v_u_8, (ref) v_u_109, (copy) p_u_178
					if not v_u_183.Parent then
						return false
					end
					local v190 = os.clock() - v_u_189
					for v191, v192 in v_u_184 do
						local v193 = v190 * (v191 == 1 and 3.2 or -2.6) + v191 * 2
						local v194 = (v191 - 1) * 1.7 + 0.8
						local v195 = v190 * 3 + v191
						local v196 = (v194 + math.sin(v195) * 0.4) * v_u_180
						v_u_101(v192.a0, v192.a1, v192.b, v_u_188, 1.7 * v_u_180, v193, 4.363323129985824, v196, v196 + 0.8 * v_u_180)
					end
					if v_u_182 > v190 then
						return true
					end
					v_u_183:Destroy()
					v_u_66(p_u_179 + Vector3.new(0, 1.5, 0) * v_u_180, 6 * v_u_180, v_u_8, 0, 0.35)
					v_u_109(p_u_179 + Vector3.new(0, 1, 0), v_u_180, 5, p_u_178.lite)
					return false
				end)
			end
		end
	}
	v103.dead_calm_r = {
		["cast"] = function(p197) -- name: cast
			-- upvalues: (copy) p_u_102, (ref) v_u_9
			p_u_102.skillCast(p197, v_u_9, true)
		end,
		["windup"] = function(p198, p199, p200) -- name: windup
			-- upvalues: (copy) p_u_102, (ref) v_u_57, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8
			local v201 = p198.size
			local v202 = p198.ability.radius * v201
			local v203 = p_u_102.ground(p199, 0.1)
			local v204 = math.max(p200, 0.12)
			v_u_57(v203, 2, v202 * 2.1, v_u_7.Ring, v_u_10, 0, v204, 0.05, 0.35, 0, 0.3)
			v_u_57(v203, 2, v202 * 2.3, v_u_7.Glow, v_u_11, 0.35, v204, 0.9, 0.5, nil, 0)
			v_u_57(v203 + Vector3.new(0, 0.04, 0), 3, v202 * 2.05, v_u_7.CalmSpiral, v_u_8, 0.2, v204, 0.9, 0.5, 0, 0)
		end,
		["land"] = function(p_u_205, p206) -- name: land
			-- upvalues: (copy) p_u_102, (ref) v_u_66, (ref) v_u_8, (ref) v_u_9, (ref) v_u_57, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10, (copy) v_u_109, (ref) v_u_6
			local v_u_207 = p_u_205.size
			local v_u_208 = p_u_205.ability.radius * v_u_207
			local v_u_209 = p_u_102.ground(p206, 0.1)
			local v210 = p_u_205.lite and 2 or 4
			local v211 = math.random() * 3.141592653589793 * 2
			for v_u_212 = 1, 5 do
				for v_u_213 = 1, v210 do
					local v_u_214 = v_u_213 / v210
					local v215 = v_u_208 * (v_u_214 * 0.8 + 0.15)
					local v216 = v211 + (v_u_212 - 1) / 5 * 3.141592653589793 * 2
					local v217 = v_u_214 * 6 + 1
					local v_u_218 = v216 - math.log(v217) * 0.9
					local v219 = math.cos(v_u_218)
					local v220 = math.sin(v_u_218)
					local v_u_221 = v_u_209 + Vector3.new(v219, 0, v220) * v215
					p_u_102.after(v_u_213 * 0.03 + v_u_212 * 0.008, function()
						-- upvalues: (ref) v_u_66, (copy) v_u_221, (copy) v_u_207, (copy) v_u_214, (copy) v_u_212, (copy) v_u_213, (ref) v_u_8, (ref) v_u_9, (ref) v_u_57, (ref) v_u_7, (copy) v_u_218
						local v222 = v_u_66
						local v223 = v_u_221 + Vector3.new(0, 2.2, 0) * v_u_207
						local v224 = (v_u_214 * 3 + 5) * v_u_207
						local v225
						if (v_u_212 + v_u_213) % 2 == 0 then
							v225 = v_u_8
						else
							v225 = v_u_9
						end
						v222(v223, v224, v225, math.random(0, 359))
						local v226 = v_u_57
						local v227 = v_u_221
						local v228 = (v_u_214 * 4 + 6) * v_u_207
						local v229 = v_u_7.CalmSlash
						local v230 = v_u_9
						local v231 = -v_u_218
						v226(v227, 1, v228, v229, v230, 0, 0.06, 0.25, 0.35, math.deg(v231), 0.15)
					end)
				end
			end
			p_u_102.after(0.45, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_209, (ref) v_u_8, (copy) v_u_207, (ref) v_u_9, (copy) v_u_208, (ref) v_u_11, (ref) v_u_7, (ref) v_u_57, (ref) v_u_10, (copy) p_u_205, (ref) v_u_109, (ref) v_u_6
				v_u_4.flash(v_u_209 + Vector3.new(0, 2, 0), v_u_8, 10 * v_u_207, 0.2)
				v_u_4.flash(v_u_209 + Vector3.new(0, 2, 0), v_u_9, v_u_208 * 0.9, 0.4)
				v_u_4.ring(v_u_209, v_u_11, v_u_208 * 0.9, 0.45, v_u_7.Shockwave)
				v_u_4.ring(v_u_209, v_u_8, v_u_208 * 1.15, 0.6, v_u_7.Ring)
				v_u_57(v_u_209, v_u_208 * 0.6, v_u_208 * 2.3, v_u_7.Ring, v_u_10, 0, 0.15, 0.05, 0.4, 0, 0.3)
				if not p_u_205.lite then
					for _ = 1, 6 do
						local v232 = math.random() * 3.141592653589793 * 2
						local v233 = v_u_208 * 0.8
						local v234 = math.random()
						local v235 = v233 * math.sqrt(v234)
						local v236 = v_u_109
						local v237 = v_u_209
						local v238 = math.cos(v232) * v235
						local v239 = math.sin(v232) * v235
						v236(v237 + Vector3.new(v238, 1, v239), v_u_207 * 1.3, 4, false)
					end
				end
				v_u_6.play("Explosion", {
					["at"] = v_u_209,
					["volume"] = p_u_205.mine and 0.8 or 0.45
				})
				if p_u_205.mine then
					v_u_4.shake(0.35, 0.3)
				end
			end)
		end,
		["hit"] = function(p240, p241, _) -- name: hit
			-- upvalues: (ref) v_u_66, (ref) v_u_8, (ref) v_u_9
			local v242 = p240.size
			v_u_66(p241, 5 * v242, v_u_8, 45, 0.35)
			v_u_66(p241, 5 * v242, v_u_9, -45, 0.35)
		end
	}
	return v103
end