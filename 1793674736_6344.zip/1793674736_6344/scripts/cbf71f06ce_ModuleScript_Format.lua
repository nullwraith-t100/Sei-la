local v_u_1 = {
	"K",
	"M",
	"B",
	"T",
	"Qa",
	"Qi",
	"Sx",
	"Sp",
	"Oc",
	"No",
	"Dc",
	"Ud",
	"Dd",
	"Td",
	"Qad",
	"Qid",
	"Sxd",
	"Spd",
	"Ocd",
	"Nod",
	"Vg",
	"Uvg",
	"Dvg",
	"Tvg",
	"Qavg",
	"Qivg",
	"Sxvg",
	"Spvg",
	"Ocvg",
	"Novg",
	"Tg",
	"Utg",
	"Dtg",
	"Ttg",
	"Qatg",
	"Qitg",
	"Sxtg",
	"Sptg",
	"Octg",
	"Notg",
	"Qag",
	"Uqag",
	"Dqag",
	"Tqag",
	"Qaqag",
	"Qiqag",
	"Sxqag"
}
local v_u_35 = {
	["short"] = function(p2) -- name: short
		-- upvalues: (copy) v_u_1
		if p2 == p2 then
			local v3 = p2 < 0
			local v4 = math.abs(p2)
			local v5
			if v4 < 1000 then
				local v6 = math.floor(v4)
				v5 = tostring(v6)
			else
				local v7 = math.log10(v4) / 3
				local v8 = math.floor(v7)
				local v9 = #v_u_1
				local v10 = math.min(v8, v9)
				local v11 = v4 / 10 ^ (v10 * 3)
				if v11 >= 999.95 and v10 < #v_u_1 then
					v10 = v10 + 1
					v11 = v4 / 10 ^ (v10 * 3)
				end
				local v12
				if v11 < 100 then
					v12 = string.format("%.2f", v11)
					if string.find(v12, "%.") then
						local v13 = string.gsub(v12, "0+$", "")
						v12 = string.gsub(v13, "%.$", "")
					end
				else
					v12 = string.format("%.1f", v11)
					if string.find(v12, "%.") then
						local v14 = string.gsub(v12, "0+$", "")
						v12 = string.gsub(v14, "%.$", "")
					end
				end
				v5 = v12 .. v_u_1[v10]
			end
			if v3 then
				return "-" .. v5
			else
				return v5
			end
		else
			return "0"
		end
	end,
	["commas"] = function(p15) -- name: commas
		local v16 = math.abs(p15)
		local v17 = math.floor(v16)
		local v18 = tostring(v17)
		local v19 = string.reverse((string.gsub(string.reverse(v18), "(%d%d%d)", "%1,")))
		if string.sub(v19, 1, 1) == "," then
			v19 = string.sub(v19, 2)
		end
		if p15 < 0 then
			return "-" .. v19
		else
			return v19
		end
	end,
	["mult"] = function(p20) -- name: mult
		-- upvalues: (copy) v_u_35
		if p20 >= 1000 then
			return "x" .. v_u_35.short(p20)
		end
		local v21 = "x"
		local v22 = string.format("%.2f", p20)
		if string.find(v22, "%.") then
			local v23 = string.gsub(v22, "0+$", "")
			v22 = string.gsub(v23, "%.$", "")
		end
		return v21 .. v22
	end,
	["percent"] = function(p24) -- name: percent
		local v25 = p24 * 100
		if v25 >= 10 then
			local v26 = string.format
			local v27 = v25 + 0.5
			return v26("%d%%", (math.floor(v27)))
		else
			local v28 = string.format("%.1f", v25)
			if string.find(v28, "%.") then
				local v29 = string.gsub(v28, "0+$", "")
				v28 = string.gsub(v29, "%.$", "")
			end
			return v28 .. "%"
		end
	end,
	["duration"] = function(p30) -- name: duration
		local v31 = math.floor(p30)
		local v32 = math.max(v31, 0)
		if v32 < 60 then
			return v32 .. "s"
		else
			local v33 = v32 // 3600
			local v34 = v32 // 60 % 60
			if v33 == 0 then
				return v34 .. "m"
			elseif v34 == 0 then
				return v33 .. "h"
			else
				return v33 .. "h " .. v34 .. "m"
			end
		end
	end
}
return v_u_35