local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("SocialService")
local v_u_5 = game:GetService("StarterGui")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = require(v2.Shared.Config.Images)
local v_u_9 = require(v2.Shared.Config.Eyes)
local v_u_10 = require(v2.Shared.Config.Products)
local v_u_11 = require(v2.Shared.Config.Release)
local v_u_12 = require(v2.Shared.Logic.Boss)
local v_u_13 = require(v2.Shared.Logic.ChakraLadder)
local v_u_14 = require(v2.Shared.Logic.Format)
local v_u_15 = require(v2.Shared.Logic.NextStep)
local v_u_16 = require(v2.Shared.Logic.PromoWeights)
local v_u_17 = require(script.Parent.Gamepad)
local v_u_18 = require(script.Parent.LuckLadder)
local v_u_19 = require(script.Parent.OfferLog)
local v_u_20 = require(script.Parent.Revive)
local v_u_21 = require(script.Parent.ServerBoost)
local v_u_22 = require(script.Parent.State)
local v_u_23 = require(script.Parent.Store)
local v_u_24 = require(script.Parent.Tutorial)
local v_u_25 = require(script.Parent.VipPlusCards)
local v_u_26 = v1.LocalPlayer
local v_u_27 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_28 = {
	{
		["key"] = "starter",
		["pass"] = true,
		["title"] = "STARTER PACK"
	},
	{
		["key"] = "pro",
		["pass"] = true,
		["title"] = "PRO PACK"
	},
	{
		["key"] = "skipEye",
		["pass"] = false,
		["title"] = "SKIP EYE",
		["sub"] = "UNLOCK NEXT EYE NOW"
	},
	{
		["key"] = "boostWins",
		["pass"] = false,
		["title"] = "x2 TROPHIES"
	},
	{
		["key"] = "boost2",
		["pass"] = false,
		["title"] = "x2 CHAKRA"
	},
	{
		["key"] = "boost5",
		["pass"] = false,
		["title"] = "x5 CHAKRA"
	},
	{
		["key"] = "boost10",
		["pass"] = false,
		["title"] = "x10 CHAKRA"
	},
	{
		["key"] = "chakra1",
		["pass"] = false,
		["title"] = "10 MIN CHAKRA"
	},
	{
		["key"] = "chakra2",
		["pass"] = false,
		["title"] = "1 HOUR CHAKRA"
	},
	{
		["key"] = "chakra3",
		["pass"] = false,
		["title"] = "5 HOURS CHAKRA"
	},
	{
		["key"] = "skipRebirth",
		["pass"] = false,
		["title"] = "SKIP REBIRTH",
		["sub"] = "REBIRTH NOW!"
	},
	{
		["key"] = "equip1",
		["pass"] = true,
		["title"] = "+1 PET EQUIP",
		["sub"] = "EQUIP 1 MORE PET"
	},
	{
		["key"] = "equip2",
		["pass"] = true,
		["title"] = "+2 PET EQUIP",
		["sub"] = "EQUIP 2 MORE PETS"
	},
	{
		["key"] = "storage120",
		["pass"] = true,
		["title"] = "+120 STORAGE",
		["sub"] = "KEEP 120 MORE PETS"
	},
	{
		["key"] = "winsPad",
		["pass"] = true,
		["title"] = "x3 WINS PAD",
		["sub"] = "USE x3 TROPHY PADS"
	},
	{
		["key"] = "speed2",
		["pass"] = true,
		["title"] = "x2 SPEED"
	},
	{
		["key"] = "autoRebirth",
		["pass"] = true,
		["title"] = "AUTO REBIRTH",
		["sub"] = "REBIRTHS FOR YOU"
	},
	{
		["key"] = "vip",
		["pass"] = true,
		["title"] = "VIP",
		["sub"] = "x1.5 CHAKRA + TROPHIES"
	},
	{
		["key"] = "autoWin",
		["pass"] = true,
		["title"] = "AUTO WIN",
		["sub"] = "TROPHIES WHILE IDLE"
	},
	{
		["key"] = "serverBoost2",
		["pass"] = false,
		["title"] = "SERVER x2 CHAKRA",
		["sub"] = "FOR EVERYONE, 15 MIN"
	},
	{
		["key"] = "vipPlus",
		["pass"] = true,
		["title"] = "VIP+",
		["sub"] = "AURA, PET + TITLE"
	},
	{
		["key"] = "hokage",
		["pass"] = true,
		["title"] = "HOKAGE BUNDLE",
		["sub"] = "13 PASSES + COINS"
	},
	{
		["key"] = "bossLuck2",
		["pass"] = false,
		["title"] = "x2 BOSS LUCK",
		["sub"] = "BOSS DROPS, 60 MIN"
	},
	{
		["key"] = "bossLuck5",
		["pass"] = false,
		["title"] = "x5 BOSS LUCK",
		["sub"] = "BOSS DROPS, 60 MIN"
	}
}
local v_u_29 = v_u_28[1]
local v30 = {}
local v_u_31 = { 3, 6 }
local v_u_32 = {
	{
		["key"] = "starter",
		["pass"] = true,
		["title"] = "STARTER PACK"
	},
	{
		["key"] = "pro",
		["pass"] = true,
		["title"] = "PRO PACK"
	}
}
local v_u_33 = { 20, 40 }
local function v_u_40() -- name: rungOffer
	-- upvalues: (copy) v_u_26, (copy) v_u_13, (copy) v_u_10, (copy) v_u_15, (copy) v_u_14
	local function v35(p34) -- name: owns
		-- upvalues: (ref) v_u_26
		return v_u_26:GetAttribute("Pass_" .. p34) == true
	end
	local v36 = v_u_13.next(v_u_10.chakraTiers, v35)
	if not v36 then
		return nil
	end
	local v37 = v_u_15.gain(v36, v35)
	local v38 = {
		["key"] = nil,
		["pass"] = true,
		["title"] = nil,
		["sub"] = nil,
		["rung"] = true,
		["key"] = v36.key,
		["title"] = ("x%* CHAKRA"):format(v36.mult or 1)
	}
	local v39 = v_u_14.mult(v37)
	v38.sub = ("%*x MORE THAN NOW"):format((string.sub(v39, 2)))
	return v38
end
for _, v41 in v_u_28 do
	if v41.key ~= "speed2" then
		continue
	end
	v_u_29 = v41
end
local function v_u_49(p42) -- name: priceOf
	-- upvalues: (copy) v_u_23, (copy) v_u_25, (copy) v_u_18
	if p42.pass then
		local v43 = v_u_23.pass(p42.key)
		local v44
		if v43 == nil then
			v44 = false
		else
			v44 = v43.id ~= 0 and true or v_u_25.made(v43.key)
		end
		if v43 and v44 then
			return v_u_23.passPrice(v43)
		else
			return nil
		end
	else
		local v45 = v_u_23.product(p42.key)
		if p42.luck and v45 then
			local v46 = v45.key
			local v47 = v_u_18.offer()
			local v48
			if v47 == nil then
				v48 = false
			else
				v48 = v47.key == v46
			end
			if v48 then
				return v45.price
			else
				return nil
			end
		elseif v45 and v45.id ~= 0 then
			return v45.price
		else
			return nil
		end
	end
end
local function v_u_55(p50) -- name: pictureOf
	-- upvalues: (copy) v_u_25, (copy) v_u_8, (copy) v_u_10, (copy) v_u_18, (copy) v_u_26
	local v51 = v_u_25.promoPicture(p50)
	if v51 then
		return v51
	elseif p50 == "starter" or p50 == "pro" then
		return v_u_8.Icon.Deal
	else
		local v52 = v_u_10.passByKey[p50]
		if v52 and v52.group == "chakra" then
			return v_u_8.Icon.BoostChakra
		else
			local v53 = v_u_10.productByKey[p50]
			if v53 and v53.kind == "luckTier" then
				return v_u_18.picture(v53.mult or 2)
			else
				local v54 = v_u_26:FindFirstChild("PlayerGui")
				if v54 then
					v54 = v54:FindFirstChild("Main")
				end
				if v54 then
					v54 = v54:FindFirstChild("Frames")
				end
				if v54 then
					v54 = v54:FindFirstChild("Store")
				end
				if v54 then
					v54 = v54:FindFirstChild("Holder", true)
				end
				if v54 then
					v54 = v54:FindFirstChild("Pass_" .. p50) or v54:FindFirstChild("Product_" .. p50)
				end
				if v54 then
					v54 = v54:FindFirstChild("Icon")
				end
				if v54 and (v54:IsA("ImageLabel") and v54.Image ~= "") then
					return v54.Image
				else
					return nil
				end
			end
		end
	end
end
local function v_u_58(p56) -- name: available
	-- upvalues: (copy) v_u_55, (copy) v_u_49, (copy) v_u_11, (copy) v_u_21, (copy) v_u_23, (copy) v_u_10, (copy) v_u_26, (copy) v_u_9, (copy) v_u_22
	if v_u_55(p56.key) and v_u_49(p56) then
		if (p56.key == "vip" or p56.key == "autoWin") and not v_u_11.on(v_u_11.PERKS) then
			return false
		elseif p56.key == "serverBoost2" and not v_u_21.sellable() then
			return false
		elseif v_u_23.randomBlocked(p56.pass and "pass" or "product", p56.key) then
			return false
		else
			local v57
			if p56.pass then
				v57 = nil
			else
				v57 = v_u_10.productByKey[p56.key]
			end
			if v57 and (v57.boost == "luck" and (not v_u_11.on(2) or v_u_23.luckBlocked())) then
				return false
			elseif p56.pass then
				return v_u_26:GetAttribute("Pass_" .. p56.key) ~= true
			else
				return p56.key ~= "skipEye" and true or v_u_9.nextLocked(v_u_22.eyes(), v_u_22.number("World", 1)) ~= nil
			end
		end
	else
		return false
	end
end
local function v_u_63(p59) -- name: textOf
	-- upvalues: (copy) v_u_23, (copy) v_u_22, (copy) v_u_14, (copy) v_u_25
	local v60
	if p59.pass then
		v60 = nil
	else
		v60 = v_u_23.product(p59.key)
	end
	if v60 and (v60.kind == "chakra" and v60.seconds) then
		local v61 = v_u_22.number("PaidPerSecond", v_u_22.number("PerSecond"))
		return ("+%* CHAKRA"):format((v_u_14.short(math.max(v61, 1) * v60.seconds))), "INSTANTLY!"
	elseif v60 and (v60.kind == "boost" and v60.minutes) then
		return p59.title, p59.sub or ("FOR %* MIN"):format(v60.minutes)
	else
		local v62 = v_u_25.promoDiscount(p59.key)
		if v62 then
			return p59.title, v62
		else
			return p59.title, p59.sub
		end
	end
end
local function v_u_71() -- name: fighting
	-- upvalues: (copy) v_u_11, (copy) v_u_7, (copy) v_u_26, (copy) v_u_12
	if not v_u_11.on(2) or v_u_7:GetAttribute("BossPhase") ~= "fight" then
		return false
	end
	local v64 = v_u_26.Character
	if v64 then
		v64 = v64:FindFirstChild("HumanoidRootPart")
	end
	if not (v64 and v64:IsA("BasePart")) then
		return false
	end
	local v65 = v64.Position
	local v66 = v_u_12.CENTRE
	local v67 = v65.X - v66.X
	local v68 = v65.Z - v66.Z
	local v69
	if v67 * v67 + v68 * v68 <= v_u_12.INSIDE_RADIUS * v_u_12.INSIDE_RADIUS then
		local v70 = v65.Y - v66.Y
		v69 = math.abs(v70) < 80
	else
		v69 = false
	end
	return v69
end
local v_u_72 = nil
local v_u_73 = 0
local v_u_74 = nil
local function v_u_78() -- name: forced
	-- upvalues: (copy) v_u_26, (copy) v_u_3, (copy) v_u_40, (copy) v_u_18, (copy) v_u_28
	local v75 = v_u_26:GetAttribute("DevPromo")
	if v_u_3:IsStudio() and type(v75) == "string" then
		if v75 == "rung" then
			return v_u_40()
		elseif v75 == "luck" then
			local v76 = v_u_18.offer()
			return v76 and {
				["key"] = nil,
				["pass"] = false,
				["title"] = nil,
				["sub"] = "RARER PETS FOR GOOD",
				["luck"] = true,
				["key"] = v76.key,
				["title"] = ("x%* LUCK"):format(v76.mult or 2)
			} or nil
		else
			for _, v77 in v_u_28 do
				if v77.key ~= v75 then
					continue
				end
				return v77
			end
			return nil
		end
	else
		return nil
	end
end
local function v_u_95() -- name: pick
	-- upvalues: (copy) v_u_78, (copy) v_u_71, (copy) v_u_58, (ref) v_u_29, (ref) v_u_72, (copy) v_u_7, (ref) v_u_73, (copy) v_u_22, (copy) v_u_32, (copy) v_u_28, (copy) v_u_40, (copy) v_u_18, (copy) v_u_25, (ref) v_u_74, (copy) v_u_10, (copy) v_u_16
	local v79 = v_u_78()
	if v79 then
		return v79, "Rotation"
	end
	local v80 = v_u_71()
	if v80 then
		v80 = v_u_58(v_u_29)
	end
	if v80 then
		if v_u_72 ~= v_u_7:GetAttribute("BossAt") then
			v_u_72 = v_u_7:GetAttribute("BossAt")
			v_u_73 = 0
		end
		v_u_73 = v_u_73 + 1
		local v81
		if v_u_73 == 1 or v_u_73 % 3 ~= 0 then
			v81 = v_u_29
		else
			v81 = nil
		end
		if v81 then
			return v81, "Fight"
		end
	end
	local v82 = {}
	if v_u_22.number("PlayTime") < 2700 then
		for _, v83 in v_u_32 do
			if not v_u_58(v83) then
				continue
			end
			table.insert(v82, v83)
		end
		if #v82 > 0 then
			return v82[1], "New"
		end
	end
	local v84 = v_u_22.number("World", 1)
	local v85 = {}
	local v86 = table.clone(v_u_28)
	local v87 = v_u_40()
	if v87 then
		table.insert(v86, v87)
	end
	local v88 = v_u_18.offer()
	local v89 = v88 and {
		["key"] = nil,
		["pass"] = false,
		["title"] = nil,
		["sub"] = "RARER PETS FOR GOOD",
		["luck"] = true,
		["key"] = v88.key,
		["title"] = ("x%* LUCK"):format(v88.mult or 2)
	} or nil
	if v89 then
		table.insert(v86, v89)
	end
	for _, v90 in v86 do
		local v91 = v_u_25.promoWeight(v90.key)
		if v90.key == v_u_74 or (v91 == 0 or not v_u_58(v90)) then
			continue
		end
		table.insert(v82, v90)
		local v92
		if v90.rung then
			v92 = v_u_10.passByKey[v90.key].mult
		else
			v92 = nil
		end
		if not v91 then
			if v92 then
				v91 = v_u_16.rung(v92)
			else
				v91 = v_u_16.of(v90.key, v84)
			end
		end
		table.insert(v85, v91)
	end
	local v93 = v_u_16.pick(v85, math.random())
	local v94
	if v93 then
		v94 = v82[v93]
	else
		v94 = nil
	end
	return v94, "Rotation"
end
v30.fighting = v_u_71
local function v_u_100(p96, p97) -- name: waitUntil
	-- upvalues: (copy) v_u_26, (copy) v_u_3, (copy) v_u_24
	while true do
		while os.clock() - p96 < p97 do
			local v98 = v_u_26:GetAttribute("DevPromo")
			local v99 = v_u_3:IsStudio()
			if v99 then
				v99 = v98 == true and true or type(v98) == "string"
			end
			if v99 then
				if v_u_24.known() and not v_u_24.active() then
					return
				end
				task.wait(2)
			else
				task.wait(2)
			end
		end
		if v_u_24.known() and not v_u_24.active() then
			return
		end
		task.wait(2)
	end
end
local function v_u_106(p101, p102) -- name: waitForOffer
	-- upvalues: (copy) v_u_26, (copy) v_u_3, (copy) v_u_71, (copy) v_u_58, (ref) v_u_29, (copy) v_u_24, (copy) v_u_20
	while true do
		while os.clock() - p101 < p102 do
			local v103 = v_u_26:GetAttribute("DevPromo")
			local v104 = v_u_3:IsStudio()
			if v104 then
				v104 = v103 == true and true or type(v103) == "string"
			end
			if v104 then
				if v_u_24.known() and not (v_u_24.active() or v_u_20.open()) then
					return
				end
				task.wait(1)
			else
				local v105 = v_u_71()
				if v105 then
					v105 = v_u_58(v_u_29)
				end
				if v105 then
					if v_u_24.known() and not (v_u_24.active() or v_u_20.open()) then
						return
					end
					task.wait(1)
				else
					task.wait(1)
				end
			end
		end
		if v_u_24.known() and not (v_u_24.active() or v_u_20.open()) then
			return
		end
		task.wait(1)
	end
end
local function v_u_114(p107, p108, p109, p110, p111) -- name: label
	-- upvalues: (copy) v_u_27
	local v112 = Instance.new("TextLabel")
	v112.Name = p108
	v112.BackgroundTransparency = 1
	v112.AnchorPoint = Vector2.new(0.5, 0.5)
	v112.Size = p109
	v112.Position = p110
	v112.FontFace = v_u_27
	v112.TextScaled = true
	v112.TextColor3 = p111
	v112.ZIndex = 4
	local v113 = Instance.new("UIStroke")
	v113.Thickness = 2.5
	v113.Color = Color3.new(0, 0, 0)
	v113.Parent = v112
	v112.Parent = p107
	return v112
end
local function v_u_133(p115, p116, p117, p118, p119) -- name: place
	-- upvalues: (copy) v_u_17
	local v120 = p116.AbsolutePosition
	local v121 = p116.AbsoluteSize.X
	local v122 = p116.AbsoluteSize.Y
	if v121 >= 100 and v122 >= 100 then
		local v123 = p117.AbsolutePosition.Y + p117.AbsoluteSize.Y - v120.Y + 8
		local v124 = p118.AbsolutePosition.Y - v120.Y
		local v125, v126
		if v124 < v122 * 0.4 then
			v125 = p118.AbsolutePosition.X - v120.X - 8
			local v127 = (not p119 or p119.AbsoluteSize.Y <= 0) and 150 or p119.AbsolutePosition.Y - v120.Y - 8 - v124
			local v128 = v122 * 0.3
			local v129 = math.min(v127, v128)
			v126 = math.clamp(v129, 70, 150)
		else
			local v130 = v124 - 10 - v123
			local v131 = v122 * 0.26
			local v132 = math.min(v130, v131)
			v126 = math.clamp(v132, 80, 200)
			if v_u_17.tv() then
				v125 = v121 * 0.95 - v126 * 0.86 * 0.05
				v124 = v123
			else
				v125 = v121 - 14
				v124 = v123
			end
		end
		p115.AnchorPoint = Vector2.new(1, 0)
		p115.Position = UDim2.fromOffset(v125, v124)
		p115.Size = UDim2.fromOffset(v126 * 0.86, v126)
	end
end
function v30.start() -- name: start
	-- upvalues: (copy) v_u_26, (copy) v_u_17, (copy) v_u_114, (copy) v_u_63, (copy) v_u_133, (copy) v_u_23, (copy) v_u_3, (copy) v_u_106, (copy) v_u_71, (copy) v_u_58, (ref) v_u_29, (copy) v_u_95, (ref) v_u_74, (copy) v_u_19, (copy) v_u_55, (copy) v_u_49, (copy) v_u_25, (copy) v_u_14, (copy) v_u_6, (copy) v_u_18, (copy) v_u_24, (copy) v_u_20, (ref) v_u_72, (copy) v_u_7, (ref) v_u_73, (copy) v_u_78, (copy) v_u_31, (copy) v_u_33, (copy) v_u_100, (copy) v_u_4, (copy) v_u_5
	local v_u_134 = os.clock()
	task.spawn(function()
		-- upvalues: (ref) v_u_26, (ref) v_u_17, (ref) v_u_114, (ref) v_u_63, (ref) v_u_133, (ref) v_u_23, (ref) v_u_3, (ref) v_u_106, (copy) v_u_134, (ref) v_u_71, (ref) v_u_58, (ref) v_u_29, (ref) v_u_95, (ref) v_u_74, (ref) v_u_19, (ref) v_u_55, (ref) v_u_49, (ref) v_u_25, (ref) v_u_14, (ref) v_u_6, (ref) v_u_18, (ref) v_u_24, (ref) v_u_20, (ref) v_u_72, (ref) v_u_7, (ref) v_u_73, (ref) v_u_78, (ref) v_u_31, (ref) v_u_33
		local v_u_135 = v_u_26:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
		local v136
		if v_u_135 then
			v136 = v_u_135:WaitForChild("HUD", 10)
		else
			v136 = v_u_135
		end
		local v_u_137
		if v136 then
			v_u_137 = v136:WaitForChild("TopRight", 10)
		else
			v_u_137 = v136
		end
		local v_u_138
		if v136 then
			v_u_138 = v136:WaitForChild("Upgrade", 10)
		else
			v_u_138 = v136
		end
		local v_u_139
		if v136 then
			v_u_139 = v136:FindFirstChild("Skills")
		else
			v_u_139 = v136
		end
		if not (v_u_135 and (v_u_135:IsA("GuiBase2d") and (v136 and (v_u_137 and (v_u_137:IsA("GuiObject") and (v_u_138 and v_u_138:IsA("GuiObject"))))))) then
			return
		end
		local v_u_140 = Instance.new("Frame")
		v_u_140.Name = "Promo"
		v_u_140.BackgroundTransparency = 1
		local v_u_141 = Instance.new("TextButton")
		v_u_141.Name = "Offer"
		v_u_141.Text = ""
		v_u_141.BackgroundTransparency = 1
		v_u_141.Size = UDim2.fromScale(1, 1)
		v_u_141.Visible = false
		v_u_141:SetAttribute("Ui-Hover", "Expand")
		v_u_141:SetAttribute("Ui-Hover-Rate", 1.08)
		v_u_141.Parent = v_u_140
		local v142 = Instance.new("UIScale")
		v142.Name = "Show"
		v142.Scale = 0
		local v143 = Instance.new("Frame")
		v143.Name = "Body"
		v143.BackgroundTransparency = 1
		v143.Size = UDim2.fromScale(1, 1)
		v142.Parent = v143
		v143.Parent = v_u_141
		v_u_17.hint(v143, Enum.KeyCode.DPadRight, 30, UDim2.fromScale(0.08, 0.2)).ZIndex = 6
		local v_u_144 = Instance.new("ImageLabel")
		v_u_144.Name = "Rays"
		v_u_144.BackgroundTransparency = 1
		v_u_144.Image = "rbxassetid://96427887277553"
		v_u_144.ImageColor3 = Color3.fromRGB(255, 240, 170)
		v_u_144.ImageTransparency = 0.15
		v_u_144.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_144.Position = UDim2.fromScale(0.5, 0.5)
		v_u_144.Size = UDim2.fromScale(1.35, 1.35)
		v_u_144.SizeConstraint = Enum.SizeConstraint.RelativeXX
		v_u_144.ZIndex = 2
		v_u_144.Parent = v143
		local v_u_145 = Instance.new("ImageLabel")
		v_u_145.Name = "Picture"
		v_u_145.BackgroundTransparency = 1
		v_u_145.ScaleType = Enum.ScaleType.Fit
		v_u_145.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_145.Position = UDim2.fromScale(0.5, 0.5)
		v_u_145.Size = UDim2.fromScale(0.95, 0.62)
		v_u_145.ZIndex = 3
		v_u_145.Parent = v143
		local v_u_146 = v_u_114(v143, "Title", UDim2.fromScale(1.1, 0.15), UDim2.fromScale(0.5, 0.1), Color3.fromRGB(255, 232, 80))
		local v147 = v_u_114(v143, "Price", UDim2.fromScale(0.8, 0.17), UDim2.fromScale(0.5, 0.88), Color3.new(1, 1, 1))
		v147.RichText = true
		local v_u_148 = v_u_114(v143, "Was", UDim2.fromScale(0.55, 0.11), UDim2.fromScale(0.5, 1), Color3.fromRGB(255, 72, 72))
		v_u_148.Visible = false
		local v_u_149 = Instance.new("Frame")
		v_u_149.Name = "Line"
		v_u_149.BorderSizePixel = 0
		v_u_149.BackgroundColor3 = Color3.fromRGB(255, 40, 40)
		v_u_149.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_149.Position = UDim2.fromScale(0.5, 0.52)
		v_u_149.Rotation = -12
		v_u_149.ZIndex = 5
		local v150 = Instance.new("UIStroke")
		v150.Thickness = 1.5
		v150.Parent = v_u_149
		v_u_149.Parent = v_u_148
		v_u_148:GetPropertyChangedSignal("TextBounds"):Connect(function()
			-- upvalues: (copy) v_u_149, (copy) v_u_148
			local v151 = v_u_149
			local v152 = UDim2.new
			local v153 = v_u_148.TextBounds.X * 1.2
			v151.Size = v152(0, math.max(v153, 8), 0.14, 0)
		end)
		local v_u_154 = v_u_114(v143, "Sub", UDim2.fromScale(1, 0.1), UDim2.fromScale(0.5, 0.225), Color3.new(1, 1, 1))
		v_u_154.Visible = false
		local v_u_155 = 0.5
		local function v161(p156) -- name: setText
			-- upvalues: (ref) v_u_63, (copy) v_u_146, (copy) v_u_154, (ref) v_u_155, (copy) v_u_145
			local v157, v158 = v_u_63(p156)
			v_u_146.Text = v157
			v_u_154.Text = v158 or ""
			v_u_154.Visible = v158 ~= nil
			v_u_155 = v158 and 0.545 or 0.5
			local v159 = v_u_145
			local v160
			if v158 then
				v160 = UDim2.fromScale(0.95, 0.5)
			else
				v160 = UDim2.fromScale(0.95, 0.62)
			end
			v159.Size = v160
		end
		v_u_140.Parent = v136
		local function v168() -- name: relayout
			-- upvalues: (ref) v_u_133, (copy) v_u_140, (copy) v_u_135, (copy) v_u_137, (copy) v_u_138, (copy) v_u_139
			local v162 = v_u_133
			local v163 = v_u_140
			local v164 = v_u_135
			local v165 = v_u_137
			local v166 = v_u_138
			local v167
			if v_u_139 and v_u_139:IsA("GuiObject") then
				v167 = v_u_139
			else
				v167 = nil
			end
			v162(v163, v164, v165, v166, v167)
		end
		local v_u_169 = v_u_155
		for _, v170 in {
			v_u_135,
			v_u_137,
			v_u_138,
			v_u_139
		} do
			if not (v170 and v170:IsA("GuiBase2d")) then
				continue
			end
			v170:GetPropertyChangedSignal("AbsoluteSize"):Connect(v168)
			v170:GetPropertyChangedSignal("AbsolutePosition"):Connect(v168)
		end
		local v171 = v_u_133
		if not (v_u_139 and v_u_139:IsA("GuiObject")) then
			v_u_139 = nil
		end
		v171(v_u_140, v_u_135, v_u_137, v_u_138, v_u_139)
		local v_u_172 = nil
		local v_u_173 = "Rotation"
		v_u_141.Activated:Connect(function()
			-- upvalues: (ref) v_u_172, (ref) v_u_23, (ref) v_u_173
			local v174 = v_u_172
			if v174 then
				if v174.pass then
					v_u_23.buyPass(v174.key, "Promo", v_u_173)
				else
					v_u_23.buyProduct(v174.key, "Promo", v_u_173)
				end
			else
				return
			end
		end)
		v_u_3.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_141, (copy) v_u_144, (copy) v_u_145, (ref) v_u_169
			if v_u_141.Visible then
				local v175 = os.clock()
				v_u_144.Rotation = v175 * 30 % 360
				local v176 = v_u_145
				local v177 = UDim2.fromScale
				local v178 = v_u_169
				local v179 = v175 * 2.4
				v176.Position = v177(0.5, v178 + math.sin(v179) * 0.025)
				local v180 = v_u_145
				local v181 = v175 * 1.7
				v180.Rotation = math.sin(v181) * 4
			end
		end)
		while true do
			local v182, v183, v184
			while true do
				v_u_106(v_u_134, 180)
				local v185 = v_u_71()
				if v185 then
					v185 = v_u_58(v_u_29)
				end
				local v186, v187 = v_u_95()
				if v186 then
					break
				end
				v196 = v_u_26:GetAttribute("DevPromo")
				v197 = v_u_3:IsStudio()
				if v197 then
					v197 = v196 == true and true or type(v196) == "string"
				end
				if v197 then
					v182 = 3
				else
					v183 = v_u_71()
					if v183 then
						v183 = v_u_58(v_u_29)
					end
					if v183 then
						v182 = v_u_31[1] + math.random() * (v_u_31[2] - v_u_31[1])
					else
						v182 = v_u_33[1] + math.random() * (v_u_33[2] - v_u_33[1])
					end
				end
				v198 = os.clock() + v182
				while os.clock() < v198 do
					v184 = v_u_71()
					if v184 then
						v184 = v_u_58(v_u_29)
					end
					if v184 then
						v184 = v_u_72 ~= v_u_7:GetAttribute("BossAt") and true or v_u_73 == 0
					end
					if v184 then
						break
					end
					task.wait(0.5)
				end
			end
			v_u_172 = v186
			v_u_173 = v187
			v_u_74 = v186.key
			v_u_19.shown("Promo", v186.pass and "pass" or "product", v186.key, v187)
			v_u_145.Image = v_u_55(v186.key) or ""
			v161(v186)
			local v188 = v_u_23.ROBUX
			local v189 = v_u_49(v186)
			v147.Text = "<font color=\"#5CFF6A\">" .. v188 .. "</font> " .. tostring(v189)
			local _, v190 = v_u_25.promoDiscount(v186.key)
			v_u_148.Text = not v190 and "" or v_u_14.commas(v190)
			v_u_148.Visible = v190 ~= nil
			v142.Scale = 0
			v_u_141.Visible = true
			v_u_6:Create(v142, TweenInfo.new(0.4, Enum.EasingStyle.Back), {
				["Scale"] = 1
			}):Play()
			local v191 = os.clock() + (v185 and 24 or 32)
			while true do
				while true do
					if os.clock() >= v191 or v186.pass and v_u_26:GetAttribute("Pass_" .. v186.key) == true then
						v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Scale"] = 0
						}):Play()
						task.wait(0.2)
						v_u_141.Visible = false
						v_u_172 = nil
						goto l2
					end
					if not v186.luck then
						if v_u_24.active() or v_u_20.open() then
							v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
								["Scale"] = 0
							}):Play()
							task.wait(0.2)
							v_u_141.Visible = false
							v_u_172 = nil
						else
							if v185 then
								goto l6
							end
							v195 = v_u_71()
							if v195 then
								v195 = v_u_58(v_u_29)
							end
							if v195 then
								v195 = v_u_72 ~= v_u_7:GetAttribute("BossAt") and true or v_u_73 == 0
							end
							if v195 then
								::l41::
								v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
									["Scale"] = 0
								}):Play()
								task.wait(0.2)
								v_u_141.Visible = false
								v_u_172 = nil
							else
								if (not v185 or v_u_71()) and (not v_u_78() or v_u_78().key == v186.key) then
									goto l29
								end
								v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
									["Scale"] = 0
								}):Play()
								task.wait(0.2)
								v_u_141.Visible = false
								v_u_172 = nil
							end
						end
						goto l2
					end
					local v192 = v186.key
					local v193 = v_u_18.offer()
					local v194
					if v193 == nil then
						v194 = false
					else
						v194 = v193.key == v192
					end
					if not v194 then
						v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Scale"] = 0
						}):Play()
						task.wait(0.2)
						v_u_141.Visible = false
						v_u_172 = nil
						goto l2
					end
					if v_u_24.active() or v_u_20.open() then
						v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Scale"] = 0
						}):Play()
						task.wait(0.2)
						v_u_141.Visible = false
						v_u_172 = nil
						goto l2
					end
					if v185 then
						break
					end
					local v195 = v_u_71()
					if v195 then
						v195 = v_u_58(v_u_29)
					end
					if v195 then
						v195 = v_u_72 ~= v_u_7:GetAttribute("BossAt") and true or v_u_73 == 0
					end
					if v195 then
						goto l41
					end
					if v185 and not v_u_71() or v_u_78() and v_u_78().key ~= v186.key then
						v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
							["Scale"] = 0
						}):Play()
						task.wait(0.2)
						v_u_141.Visible = false
						v_u_172 = nil
						goto l2
					end
					::l29::
					task.wait(0.5)
					v161(v186)
				end
				::l6::
				if v185 and not v_u_71() or v_u_78() and v_u_78().key ~= v186.key then
					break
				end
				task.wait(0.5)
				v161(v186)
			end
			v_u_6:Create(v142, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				["Scale"] = 0
			}):Play()
			task.wait(0.2)
			v_u_141.Visible = false
			v_u_172 = nil
			::l2::
			local v196 = v_u_26:GetAttribute("DevPromo")
			local v197 = v_u_3:IsStudio()
			if v197 then
				v197 = v196 == true and true or type(v196) == "string"
			end
			if v197 then
				v182 = 3
			else
				v183 = v_u_71()
				if v183 then
					v183 = v_u_58(v_u_29)
				end
				if v183 then
					v182 = v_u_31[1] + math.random() * (v_u_31[2] - v_u_31[1])
				else
					v182 = v_u_33[1] + math.random() * (v_u_33[2] - v_u_33[1])
				end
			end
			local v198 = os.clock() + v182
			while os.clock() < v198 do
				v184 = v_u_71()
				if v184 then
					v184 = v_u_58(v_u_29)
				end
				if v184 then
					v184 = v_u_72 ~= v_u_7:GetAttribute("BossAt") and true or v_u_73 == 0
				end
				if v184 then
					break
				end
				task.wait(0.5)
			end
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_100, (copy) v_u_134, (ref) v_u_26, (ref) v_u_24, (ref) v_u_23, (ref) v_u_4, (ref) v_u_5, (ref) v_u_3
		v_u_100(v_u_134, 270)
		local v199 = 0
		local v200 = 0
		while v199 < 3 do
			local v201 = false
			local v202 = v_u_26:FindFirstChild("PlayerGui")
			if v202 then
				v202 = v202:FindFirstChild("Main")
			end
			if v202 then
				v202 = v202:FindFirstChild("Frames")
			end
			if v202 then
				for _, v203 in v202:GetChildren() do
					if not (v203:IsA("GuiObject") and v203.Visible) then
						continue
					end
					v201 = true
				end
			end
			if v200 <= os.clock() and (not v201 and (not v_u_24.active() and v_u_23.sincePrompt() > 20)) then
				local function v204()
					-- upvalues: (ref) v_u_4, (ref) v_u_26
					return v_u_4:CanSendGameInviteAsync(v_u_26)
				end
				local v205, v206 = pcall(v204)
				if not (v205 and v206) then
					return
				end
				local v_u_207 = Instance.new("BindableFunction")
				function v_u_207.OnInvoke(p208)
					-- upvalues: (ref) v_u_4, (ref) v_u_26, (copy) v_u_207
					if p208 == "Invite" then
						local function v209()
							-- upvalues: (ref) v_u_4, (ref) v_u_26
							v_u_4:PromptGameInvite(v_u_26)
						end
						pcall(v209)
					end
					v_u_207:Destroy()
					return nil
				end
				local function v210()
					-- upvalues: (ref) v_u_5, (copy) v_u_207
					v_u_5:SetCore("SendNotification", {
						["Title"] = "Play with friends!",
						["Text"] = "Invite your friends to train with you!",
						["Icon"] = "rbxassetid://93906086071494",
						["Duration"] = 12,
						["Button1"] = "Invite",
						["Button2"] = "Later",
						["Callback"] = nil,
						["Callback"] = v_u_207
					})
				end
				if pcall(v210) then
					v199 = v199 + 1
					local v211 = os.clock()
					local v212 = v_u_26:GetAttribute("DevPromo")
					local v213 = v_u_3:IsStudio()
					if v213 then
						v213 = v212 == true and true or type(v212) == "string"
					end
					v200 = v211 + (v213 and 30 or 900)
				else
					v_u_207:Destroy()
					v200 = os.clock() + 5
				end
			end
			task.wait(2)
		end
	end)
end
return v30