local v1 = {
	["SELL_LIMITED"] = false,
	["LIMITED"] = {
		["kurama"] = 10000,
		["tenTails"] = 10000,
		["sixPaths"] = 10000
	},
	["LIMITED_BUNDLES"] = true,
	["limited"] = {
		{
			["key"] = "limitedKurama",
			["kind"] = "pass",
			["pass"] = "kurama",
			["name"] = "Kyubi (Limited)",
			["id"] = 3722991632,
			["price"] = 799
		},
		{
			["key"] = "limitedTenTails",
			["kind"] = "pass",
			["pass"] = "tenTails",
			["name"] = "Ten Tails (Limited)",
			["id"] = 3722991647,
			["price"] = 1499
		},
		{
			["key"] = "limitedSixPaths",
			["kind"] = "pass",
			["pass"] = "sixPaths",
			["name"] = "Six Paths Sage (Limited)",
			["id"] = 3722991671,
			["price"] = 899
		},
		{
			["key"] = "limitedUltimate",
			["kind"] = "pass",
			["pass"] = "ultimate",
			["name"] = "Ultimate OP Bundle (Limited)",
			["id"] = 3722991686,
			["price"] = 4999
		}
	},
	["NOT_GIFTABLE"] = {
		["revive"] = true,
		["revenge"] = true,
		["bossSkip"] = true,
		["bossRevive"] = true,
		["skipRebirth"] = true,
		["skipDay"] = true,
		["skipEye"] = true,
		["boost50"] = true,
		["dailyAll"] = true,
		["offlineX5"] = true,
		["questsDaily"] = true,
		["questsWeekly"] = true,
		["serverBoost2"] = true,
		["vipPlusUpgrade"] = true,
		["fuseVoid"] = true,
		["fuseRainbow"] = true,
		["fuseCorrupted"] = true
	},
	["FULL_PRICE_GIFTS"] = {
		["x2"] = true
	},
	["UPDATE_ITEMS"] = {
		["kuramaCoins100"] = 2,
		["kuramaCoins500"] = 2,
		["kuramaCoins1500"] = 2,
		["vipPlus"] = 2,
		["hokage"] = 2
	},
	["INTENT_SECONDS"] = 900,
	["RECENT"] = 200,
	["LOW"] = 50,
	["GIFT_IDS"] = {
		["starter"] = 3722992415,
		["pro"] = 3722992211,
		["ultimate"] = 3722992713,
		["equip1"] = 3722992695,
		["equip2"] = 3722992302,
		["storage20"] = 3722992197,
		["storage120"] = 3722992281,
		["winsPad"] = 3722992463,
		["speed2"] = 3722992163,
		["autoRebirth"] = 3722992558,
		["x2"] = 3722992510,
		["x4"] = 3722992576,
		["x8"] = 3722992389,
		["x16"] = 3722992729,
		["x32"] = 3722992025,
		["x64"] = 3722991890,
		["x128"] = 3722991965,
		["x256"] = 3722992368,
		["x512"] = 3722992054,
		["x1024"] = 3722992235,
		["x2048"] = 3722992080,
		["x4096"] = 3722992129,
		["x8192"] = 3722991978,
		["shin"] = 3722992451,
		["kurama"] = 3722991842,
		["prismEye"] = 3722992637,
		["tenTails"] = 3722991701,
		["sixPaths"] = 3722992335,
		["train1"] = 3722992433,
		["train2"] = 3722991934,
		["train3"] = 3722992659,
		["train4"] = 3722992616,
		["skipSpark"] = 3722992601,
		["skipBlueFlame"] = 3722991785,
		["skipLeaf"] = 3722992146,
		["skipThunder"] = 3722992113,
		["skipSakura"] = 3722992544,
		["skipInferno"] = 3722992525,
		["skipAmaterasu"] = 3722991718,
		["skipVoid"] = 3722992676,
		["skipCelestial"] = 3722991752,
		["auraSage"] = 3722992479,
		["auraKurama"] = 3722992353,
		["auraOtsutsuki"] = 3722992318,
		["auraSusanoo"] = 3722991733,
		["auraRainbow"] = 3722991911,
		["chakra1"] = 3722992262,
		["chakra2"] = 3722992172,
		["chakra3"] = 3722992104,
		["boost2"] = 3722991998,
		["boostWins"] = 3722992498,
		["boost5"] = 3722992009,
		["boost10"] = 3722992070,
		["autoOp"] = 3722991873,
		["eggAkatsuki1"] = 3722991950,
		["eggAkatsuki3"] = 3722992039,
		["eggDivine1"] = 3722991771,
		["eggDivine3"] = 3722991832,
		["vip"] = 3722991805,
		["autoWin"] = 3722991818,
		["potionPack"] = 3723113161,
		["kuramaCoins100"] = 3723322517,
		["kuramaCoins500"] = 3723322508,
		["kuramaCoins1500"] = 3723322521,
		["vipPlus"] = 3723396089,
		["hokage"] = 3723396126
	},
	["gifts"] = {}
}
for v2, v3 in v1.GIFT_IDS do
	local v4 = v1.gifts
	local v5 = {
		["key"] = "gift_" .. v2,
		["item"] = v2,
		["id"] = v3
	}
	table.insert(v4, v5)
end
table.sort(v1.gifts, function(p6, p7)
	return p6.key < p7.key
end)
v1.giftByItem = {}
for _, v8 in v1.gifts do
	v1.giftByItem[v8.item] = v8
end
v1.limitedByPass = {}
for _, v9 in v1.limited do
	v1.limitedByPass[v9.pass] = v9
end
return v1