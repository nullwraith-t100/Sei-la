local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(255, 34, 44)
local function v_u_13(p5, p6, p7, p8) -- name: strip
	-- upvalues: (copy) v_u_2
	local v9 = v_u_2.part(Vector3.new(p5, 0.05, p6), CFrame.identity, p8, {
		["transparency"] = 1
	})
	local v10 = {}
	for _, v11 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v12 = Instance.new("Decal")
		v12.Face = v11
		v12.Texture = p7
		v12.Color3 = p8
		v12.Parent = v9
		table.insert(v10, v12)
	end
	return v9, v10
end
return function(p_u_14)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_13
	local function v_u_21(p15, p16) -- name: toViewer
		-- upvalues: (copy) p_u_14
		local v17 = p_u_14.camPos() - p15
		local v18 = v17.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v17.Unit
		local v19 = v18.Y
		local v20 = math.abs(v19) > 0.98 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
		return CFrame.lookAt(p15, p15 + v18, v20) * CFrame.Angles(-1.5707963267948966, p16, 0)
	end
	return {
		["w3_rift_crescent"] = function(p_u_22, p23)
			-- upvalues: (ref) v_u_2, (copy) p_u_14, (ref) v_u_4, (ref) v_u_3, (ref) v_u_13, (copy) v_u_21
			local v24 = v_u_2.color(p23.color)
			local v_u_25 = p_u_22.fx <= 1 and 1 or p_u_22.fx / 1.35
			local v26 = CFrame.fromMatrix
			local v27 = p_u_22.headY + 5 * v_u_25
			local v28 = 0.6 * v_u_25
			local v_u_29 = v26(Vector3.new(0, v27, v28), Vector3.new(1, 0, 0), Vector3.new(0, 0.64278764, 0.76604444))
			local v_u_31 = p_u_14.throb(p_u_22, 4, 1.4, 1.2, function(p30)
				-- upvalues: (ref) v_u_2, (ref) p_u_14, (copy) p_u_22, (ref) v_u_4, (ref) v_u_3, (copy) v_u_29, (copy) v_u_25
				v_u_2.ring(p_u_14.feetAt(p_u_22, p30, 0.15), v_u_4, 6 * p_u_22.fx, 0.45, v_u_3.Shockwave)
				v_u_2.flash((p30 * v_u_29).Position, v_u_4, 5 * v_u_25, 0.25)
			end)
			local v_u_32 = v_u_13(8 * v_u_25, 1, v_u_3.RiftSlit, v_u_4)
			p_u_14.add(p_u_22, v_u_32, function(p33)
				-- upvalues: (copy) v_u_29
				return p33 * v_u_29
			end)
			local v34 = p_u_14.picture(5.5 * v_u_25, v_u_3.Glow, v24, 0.5)
			p_u_14.add(p_u_22, v34, function(p35)
				-- upvalues: (copy) v_u_29, (copy) v_u_25
				return p35 * v_u_29 * CFrame.new(0, -0.25 * v_u_25, 0)
			end)
			local v36 = p_u_22.ticks
			table.insert(v36, function(_, p37)
				-- upvalues: (copy) v_u_31, (copy) v_u_25, (copy) v_u_32
				local v38 = p37 * 1.3
				local v39 = ((math.sin(v38) * 0.5 + 0.5) * 1.6 + 1.6 + v_u_31() * 3) * v_u_25
				local v40 = v_u_32
				local v41 = 8 * v_u_25
				v40.Size = Vector3.new(v41, 0.05, v39)
			end)
			local v42 = Instance.new("Attachment")
			v42.Parent = v_u_32
			local v_u_45 = p_u_14.group(p_u_22, function(p43, p44)
				-- upvalues: (copy) v_u_25
				return p43 * CFrame.new(0, 0.3 * v_u_25, 0) * CFrame.Angles(0.24434609527920614, p44 * 1.15, -0.13962634015954636)
			end)
			local v_u_46 = {}
			for v_u_47 = 1, 3 do
				local v_u_48 = (v_u_47 - 1) / 3 * 3.141592653589793 * 2
				local v49 = v_u_13(2.1 * v_u_25, 2.1 * v_u_25, v_u_3.RiftBlade, v_u_4)
				p_u_14.add(p_u_22, v49, function(_, p50)
					-- upvalues: (copy) v_u_31, (copy) v_u_25, (copy) v_u_45, (copy) v_u_48, (ref) v_u_21, (copy) v_u_47
					local v51 = (2.7 + v_u_31() * 1.3) * v_u_25
					local v52 = v_u_45.cf
					local v53 = v_u_48
					local v54 = math.cos(v53) * v51
					local v55 = v_u_48
					local v56 = math.sin(v55) * v51
					return v_u_21(v52:PointToWorldSpace((Vector3.new(v54, 0, v56))), p50 * 3 + v_u_47 * 2.1)
				end)
				local v57 = Instance.new("Attachment")
				v57.Parent = v49
				local v58 = p_u_14.ray(v42, v57, v_u_4, 0.5 * v_u_25, 0.25 * v_u_25, v_u_3.LightningArc)
				v58.Enabled = false
				table.insert(v_u_46, v58)
			end
			local v_u_59 = {}
			for v_u_60 = 1, 2 do
				local v61, v62 = v_u_13(2.6 * v_u_25, 0.05, v_u_3.RiftSlit, v_u_4)
				p_u_14.add(p_u_22, v61, function(p63)
					-- upvalues: (copy) v_u_59, (copy) v_u_60, (ref) v_u_21
					local v64 = v_u_59[v_u_60]
					return v_u_21(p63:PointToWorldSpace(v64.at), v64.roll)
				end)
				table.insert(v_u_59, {
					["part"] = nil,
					["decals"] = nil,
					["at"] = Vector3.new(0, 0, 0),
					["roll"] = 0,
					["from"] = -10,
					["shown"] = -1,
					["part"] = v61,
					["decals"] = v62
				})
			end
			local v_u_65 = 0.6
			local v_u_66 = 0
			local v_u_67 = 1
			local v_u_68 = Random.new()
			local v69 = p_u_22.ticks
			local function v94(p70, p71)
				-- upvalues: (ref) p_u_14, (ref) v_u_65, (copy) v_u_68, (ref) v_u_67, (copy) v_u_59, (copy) v_u_25, (ref) v_u_66, (copy) v_u_46, (copy) v_u_31
				local v72 = (p70.Position - p_u_14.camPos()).Magnitude < 120
				if v72 and v_u_65 <= p71 then
					v_u_65 = p71 + 0.9 + v_u_68:NextNumber() * 0.8
					v_u_67 = v_u_67 % #v_u_59 + 1
					local v73 = v_u_59[v_u_67]
					local v74 = v_u_68:NextNumber() * 3.141592653589793 * 2
					local v75 = v_u_68:NextNumber(2.2, 3.4) * v_u_25
					local v76 = math.cos(v74) * v75
					local v77 = v_u_68:NextNumber(-1.5, 3) * v_u_25
					local v78 = math.sin(v74) * v75
					v73.at = Vector3.new(v76, v77, v78)
					v73.roll = v_u_68:NextNumber(-0.9, 0.9)
					v73.from = p71
				end
				for _, v79 in v_u_59 do
					local v80 = (p71 - v79.from) / 0.7
					local v81
					if v80 < 0 or v80 > 1 then
						v81 = 0
					elseif v80 < 0.25 then
						local v82 = v80 / 0.25
						local v83 = math.clamp(v82, 0, 1)
						v81 = v83 * v83 * (3 - v83 * 2)
					elseif v80 < 0.8 then
						v81 = 1
					else
						local v84 = (v80 - 0.8) / 0.2
						local v85 = math.clamp(v84, 0, 1)
						v81 = 1 - v85 * v85 * (3 - v85 * 2)
					end
					if v81 == v79.shown then
						continue
					end
					v79.shown = v81
					local v86 = v79.part
					local v87 = 2.6 * v_u_25
					local v88 = 1.4 * v_u_25 * v81
					local v89 = math.max(v88, 0.05)
					v86.Size = Vector3.new(v87, 0.05, v89)
					local v90 = v81 > 0.02 and 0 or 1
					for _, v91 in v79.decals do
						v91.Transparency = v90
					end
				end
				if v_u_66 <= p71 then
					v_u_66 = p71 + 0.12
					for _, v92 in v_u_46 do
						local v93
						if v72 then
							v93 = v_u_68:NextNumber() < 0.3 + v_u_31() * 0.6
						else
							v93 = v72
						end
						v92.Enabled = v93
					end
				end
			end
			table.insert(v69, v94)
			p_u_14.particles(p_u_22, "AuraMode", v24, {
				["rate"] = 0.45,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Crackle" }
			})
			local v95 = p_u_14.particles
			local v96 = {
				["only"] = nil,
				["rate"] = 1.2,
				["at"] = nil,
				["only"] = { "Embers" }
			}
			local v97 = p_u_22.feet + 0.3
			v96.at = Vector3.new(0, v97, 0)
			v95(p_u_22, "FireDark", nil, v96)
		end
	}
end