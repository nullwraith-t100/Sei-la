local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(v3.Shared.Config.World)
local v_u_8 = {}
local v_u_9 = 3
local v_u_10 = {}
function v_u_8.level() -- name: level
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v_u_8.onChanged(p11) -- name: onChanged
	-- upvalues: (copy) v_u_10
	local v12 = v_u_10
	table.insert(v12, p11)
end
function v_u_8.formBudget() -- name: formBudget
	-- upvalues: (ref) v_u_9
	return v_u_9 <= 1 and 3 or (v_u_9 == 2 and 4 or 12)
end
function v_u_8.formRate() -- name: formRate
	-- upvalues: (ref) v_u_9
	return v_u_9 <= 1 and 0.4 or (v_u_9 == 2 and 0.7 or 1)
end
function v_u_8.mapRate() -- name: mapRate
	-- upvalues: (ref) v_u_9
	return v_u_9 <= 1 and 0.25 or (v_u_9 == 2 and 0.4 or 1)
end
function v_u_8.othersAttacksPerSecond() -- name: othersAttacksPerSecond
	-- upvalues: (ref) v_u_9
	return v_u_9 <= 1 and 0 or (v_u_9 == 2 and 8 or 20)
end
function v_u_8.castRange() -- name: castRange
	-- upvalues: (ref) v_u_9
	return v_u_9 <= 1 and 110 or (v_u_9 == 2 and 200 or 320)
end
function v_u_8.frameGap(p13) -- name: frameGap
	-- upvalues: (ref) v_u_9
	return p13 > 400 and 1 or ((v_u_9 <= 1 and 90 or (v_u_9 == 2 and 140 or 200)) < p13 and 0.25 or (v_u_9 <= 1 and 0.05 or (v_u_9 == 2 and 0.03333333333333333 or 0.016666666666666666)))
end
function v_u_8.set(p14) -- name: set
	-- upvalues: (ref) v_u_9, (copy) v_u_10
	local v15 = math.clamp(p14, 1, 3)
	if v15 ~= v_u_9 then
		v_u_9 = v15
		for _, v16 in v_u_10 do
			task.spawn(v16)
		end
	end
end
local function v_u_21() -- name: guess
	-- upvalues: (copy) v_u_5
	local v17 = v_u_5.TouchEnabled and not v_u_5.KeyboardEnabled and 2 or 3
	local v18, v19 = pcall(function()
		return UserSettings():GetService("UserGameSettings").SavedQualityLevel
	end)
	if v18 and (typeof(v19) == "EnumItem" and v19 ~= Enum.SavedQualitySetting.Automatic) then
		local v20 = v19.Value
		if v20 <= 4 then
			return 1
		end
		if v20 <= 6 then
			v17 = math.min(v17, 2)
		end
	end
	return v17
end
local v_u_22 = {}
local v_u_23 = 1
local function v_u_30(p24) -- name: applyMap
	-- upvalues: (copy) v_u_22, (ref) v_u_23, (copy) v_u_8, (ref) v_u_9
	local v25 = v_u_22[p24]
	if v25 then
		for v26, v27 in v25.emitters do
			v26.Enabled = p24 == v_u_23
			v26.Rate = v27 * v_u_8.mapRate()
		end
		for v28 in v25.lights do
			local v29
			if p24 == v_u_23 then
				v29 = v_u_9 >= 2
			else
				v29 = false
			end
			v28.Enabled = v29
		end
	end
end
local function v_u_33() -- name: applyAll
	-- upvalues: (copy) v_u_22, (copy) v_u_30, (copy) v_u_1, (ref) v_u_9
	for v31 in v_u_22 do
		v_u_30(v31)
	end
	local v32 = v_u_1:FindFirstChildOfClass("BloomEffect")
	if v32 then
		v32.Enabled = v_u_9 >= 3
	end
end
local function v_u_45(p_u_34, p35) -- name: collect
	-- upvalues: (copy) v_u_22, (ref) v_u_23, (copy) v_u_8, (ref) v_u_9
	local v_u_36 = {
		["emitters"] = {},
		["lights"] = {}
	}
	v_u_22[p_u_34] = v_u_36
	local function v_u_41(p37) -- name: take
		-- upvalues: (copy) v_u_36, (copy) p_u_34, (ref) v_u_23, (ref) v_u_8, (ref) v_u_9
		if p37:IsA("ParticleEmitter") and (p37.Enabled and not v_u_36.emitters[p37]) then
			v_u_36.emitters[p37] = p37.Rate
			local v38 = p_u_34
			local v39 = p37.Rate
			p37.Enabled = v38 == v_u_23
			p37.Rate = v39 * v_u_8.mapRate()
		elseif p37:IsA("Light") and (p37.Enabled and not v_u_36.lights[p37]) then
			v_u_36.lights[p37] = true
			local v40
			if p_u_34 == v_u_23 then
				v40 = v_u_9 >= 2
			else
				v40 = false
			end
			p37.Enabled = v40
		end
	end
	for _, v42 in p35:GetDescendants() do
		v_u_41(v42)
	end
	p35.DescendantAdded:Connect(function(p43)
		-- upvalues: (copy) v_u_41
		if p43:IsA("ParticleEmitter") or p43:IsA("Light") then
			task.defer(v_u_41, p43)
		end
	end)
	p35.DescendantRemoving:Connect(function(p44)
		-- upvalues: (copy) v_u_36
		if p44:IsA("ParticleEmitter") then
			v_u_36.emitters[p44] = nil
		elseif p44:IsA("Light") then
			v_u_36.lights[p44] = nil
		end
	end)
end
local function v_u_53() -- name: watchFrames
	-- upvalues: (copy) v_u_4, (ref) v_u_9, (copy) v_u_10
	task.wait(6)
	local v_u_46 = 0
	local v_u_47 = os.clock()
	v_u_4.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_46, (ref) v_u_47, (ref) v_u_9, (ref) v_u_10
		v_u_46 = v_u_46 + 1
		local v48 = os.clock()
		if v48 - v_u_47 >= 4 then
			local v49 = v_u_46 / (v48 - v_u_47)
			v_u_46 = 0
			v_u_47 = v48
			if v49 < 27 and v_u_9 > 1 then
				local v50 = v_u_9 - 1
				local v51 = math.clamp(v50, 1, 3)
				if v51 == v_u_9 then
					return
				end
				v_u_9 = v51
				for _, v52 in v_u_10 do
					task.spawn(v52)
				end
			end
		end
	end)
end
local function v_u_56() -- name: watchBlur
	-- upvalues: (copy) v_u_1
	for _, v_u_54 in v_u_1:GetChildren() do
		if not v_u_54:IsA("BlurEffect") then
			continue
		end
		v_u_54:GetPropertyChangedSignal("Size"):Connect(function() -- name: sync
			-- upvalues: (copy) v_u_54
			v_u_54.Enabled = v_u_54.Size > 0.05
		end)
		v_u_54.Enabled = v_u_54.Size > 0.05
	end
	v_u_1.ChildAdded:Connect(function(p_u_55)
		if p_u_55:IsA("BlurEffect") then
			p_u_55:GetPropertyChangedSignal("Size"):Connect(function() -- name: sync
				-- upvalues: (copy) p_u_55
				p_u_55.Enabled = p_u_55.Size > 0.05
			end)
			p_u_55.Enabled = p_u_55.Size > 0.05
		end
	end)
end
function v_u_8.start() -- name: start
	-- upvalues: (copy) v_u_21, (ref) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_33, (copy) v_u_22, (copy) v_u_30, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (copy) v_u_45, (copy) v_u_2, (ref) v_u_23, (copy) v_u_56, (copy) v_u_53
	local v57 = v_u_21()
	local v58 = math.clamp(v57, 1, 3)
	if v58 ~= v_u_9 then
		v_u_9 = v58
		for _, v59 in v_u_10 do
			task.spawn(v59)
		end
	end
	v_u_8.onChanged(v_u_33)
	for v60 in v_u_22 do
		v_u_30(v60)
	end
	local v61 = v_u_1:FindFirstChildOfClass("BloomEffect")
	if v61 then
		v61.Enabled = v_u_9 >= 3
	end
	for v_u_62 in v_u_7.ORIGINS do
		if not v_u_7.mapLive(v_u_62) then
			continue
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_62, (ref) v_u_6, (ref) v_u_45
			local v63 = v_u_6:WaitForChild(v_u_62 == 1 and "Map" or "Map" .. v_u_62, 60)
			if v63 then
				v_u_45(v_u_62, v63)
			end
		end)
	end
	local v_u_64 = v_u_2.LocalPlayer
	task.spawn(function()
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_64, (ref) v_u_23, (ref) v_u_30
		while true do
			local v65 = v_u_6.CurrentCamera
			local v66
			if v65 then
				v66 = v_u_7.worldAt(v65.Focus.Position)
			else
				v66 = v_u_64:GetAttribute("World") or 1
			end
			if v66 ~= v_u_23 then
				local v67 = v_u_23
				v_u_23 = v66
				v_u_30(v67)
				v_u_30(v66)
			end
			task.wait(0.5)
		end
	end)
	v_u_56()
	task.spawn(v_u_53)
end
v_u_9 = v_u_21()
return v_u_8