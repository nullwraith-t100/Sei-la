local v_u_1 = game:GetService("ContentProvider")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("Workspace")
require(script.Parent.FormTypes)
local v_u_7 = require(script.Parent.Kit)
local v_u_8 = require(script.Parent.Parent.Sfx)
local v_u_9 = require(script.Parent.Parent.Perf)
local v_u_10 = require(v_u_4.Shared.Config.Eyes)
local v11 = require(v_u_4.Shared.Config.Images)
local v_u_12 = require(v_u_4.Shared.Config.Textures)
local v13 = {}
local v_u_14 = table.clone(v11.Iris)
local v_u_15 = Random.new()
local function v_u_19(p16, p17, p18) -- name: rgb
	return Color3.fromRGB(p16, p17, p18)
end
local function v25(p20, p21, p22) -- name: add
	local v23 = p20.pieces
	local v24 = {
		["part"] = p21,
		["place"] = p22,
		["alpha"] = p21.Transparency
	}
	table.insert(v23, v24)
end
local function v29(p26, p27) -- name: own
	p27:SetAttribute("FormExtra", true)
	local v28 = p26.extras
	table.insert(v28, p27)
end
local function v36(p30, p_u_31) -- name: group
	local v_u_32 = {
		["cf"] = CFrame.identity
	}
	local v33 = p30.ticks
	table.insert(v33, function(p34, p35)
		-- upvalues: (copy) v_u_32, (copy) p_u_31
		v_u_32.cf = p_u_31(p34, p35)
	end)
	return v_u_32
end
local function v43(p37, p_u_38, p39, p_u_40) -- name: pin
	local v41 = p37.pieces
	local v42 = {
		["part"] = p39,
		["place"] = function()
			-- upvalues: (copy) p_u_38, (copy) p_u_40
			return p_u_38.cf * p_u_40
		end,
		["alpha"] = p39.Transparency
	}
	table.insert(v41, v42)
end
local function v48(p44, p45, p46, p47) -- name: bar
	-- upvalues: (copy) v_u_7
	return v_u_7.part(p44, CFrame.identity, p45, {
		["transparency"] = p46,
		["material"] = p47
	})
end
local function v53(p49, p50, p51, p52) -- name: ball
	-- upvalues: (copy) v_u_7
	return v_u_7.part(Vector3.new(1, 1, 1) * p49, CFrame.identity, p50, {
		["shape"] = Enum.PartType.Ball,
		["transparency"] = p51,
		["material"] = p52
	})
end
local function v58(p54, p55, p56, p57) -- name: disc
	-- upvalues: (copy) v_u_7
	return v_u_7.part(p54, CFrame.identity, p55, {
		["shape"] = Enum.PartType.Cylinder,
		["transparency"] = p56,
		["material"] = p57
	})
end
local function v65(p59, p60, p61, p62) -- name: blob
	-- upvalues: (copy) v_u_7
	local v63 = v_u_7.part(p59, CFrame.identity, p60, {
		["transparency"] = p61,
		["material"] = p62
	})
	local v64 = Instance.new("SpecialMesh")
	v64.MeshType = Enum.MeshType.Sphere
	v64.Parent = v63
	return v63
end
local function v67(p66) -- name: dark
	p66.Reflectance = 0.2
	return p66
end
local function v70(p68, p69) -- name: between
	return CFrame.lookAt((p68 + p69) / 2, p69), (p69 - p68).Magnitude
end
local function v_u_94(p71, p_u_72, p73, p74, p75, p76, p77) -- name: ring
	-- upvalues: (copy) v_u_7
	local v78 = p74 * 2
	local v79 = 3.141592653589793 / p73
	local v80 = v78 * math.sin(v79) + p75 * 0.5
	for v81 = 1, p73 do
		local v82 = (v81 - 0.5) / p73 * 3.141592653589793 * 2
		local v83 = math.cos(v82) * p74
		local v84 = math.sin(v82) * p74
		local v85 = Vector3.new(v83, 0, v84)
		local v86 = -math.sin(v82)
		local v87 = math.cos(v82)
		local v88 = Vector3.new(v86, 0, v87)
		local v89 = Vector3.new(p75, p75, v80)
		local v90 = v_u_7.part(v89, CFrame.identity, p76, {
			["transparency"] = nil,
			["material"] = nil,
			["transparency"] = p77
		})
		local v_u_91 = CFrame.lookAt(v85, v85 + v88)
		local v92 = p71.pieces
		local v93 = {
			["part"] = v90,
			["place"] = function()
				-- upvalues: (copy) p_u_72, (copy) v_u_91
				return p_u_72.cf * v_u_91
			end,
			["alpha"] = v90.Transparency
		}
		table.insert(v92, v93)
	end
end
local function v_u_133(p95, p_u_96, p97, p98, p99, p100, p101, p102, p103) -- name: ribcage
	-- upvalues: (copy) v_u_7
	for v104 = 1, p100 do
		local v105 = v104 - 1
		local v106 = p100 - 1
		local v107 = v105 / math.max(v106, 1)
		local v108 = p101 + (p102 - p101) * v107
		local v109 = 3.141592653589793 * (v107 * 0.8 + 0.15)
		local v110 = p99 * (math.sin(v109) * 0.28 + 0.72)
		for _, v111 in { -1, 1 } do
			local v112 = Vector3.new(0, v108, 1.35)
			for v113 = 1, 3 do
				local v114 = v113 * 2.303834612632515 / 3
				local v115 = v111 * math.sin(v114) * v110
				local v116 = v108 - v113 * 0.45 / 3
				local v117 = math.cos(v114) * 1.35
				local v118 = Vector3.new(v115, v116, v117)
				local v_u_119 = CFrame.lookAt((v112 + v118) / 2, v118)
				local v120 = (v118 - v112).Magnitude + p103 * 0.6
				local v121 = Vector3.new(p103, p103, v120)
				local v122 = v_u_7.part(v121, CFrame.identity, p97, {
					["transparency"] = nil,
					["material"] = nil,
					["transparency"] = p98
				})
				local v123 = p95.pieces
				local v124 = {
					["part"] = v122,
					["place"] = function()
						-- upvalues: (copy) p_u_96, (copy) v_u_119
						return p_u_96.cf * v_u_119
					end,
					["alpha"] = v122.Transparency
				}
				table.insert(v123, v124)
				v112 = v118
			end
		end
	end
	local v125 = p103 * 1.5
	local v126 = p101 - p102 + 1.2
	local v127 = p103 * 1.5
	local v128 = Vector3.new(v125, v126, v127)
	local v129 = v_u_7.part(v128, CFrame.identity, p97, {
		["transparency"] = nil,
		["material"] = nil,
		["transparency"] = p98
	})
	local v_u_130 = CFrame.new(0, (p101 + p102) / 2, 1.35)
	local v131 = p95.pieces
	local v132 = {
		["part"] = v129,
		["place"] = function()
			-- upvalues: (copy) p_u_96, (copy) v_u_130
			return p_u_96.cf * v_u_130
		end,
		["alpha"] = v129.Transparency
	}
	table.insert(v131, v132)
end
local v_u_134 = Vector3.new(0, 0, 0)
local function v141(p_u_135, p_u_136) -- name: behind
	-- upvalues: (ref) v_u_134
	return function(p137, p138)
		-- upvalues: (copy) p_u_135, (ref) v_u_134, (copy) p_u_136
		local v139 = p_u_135(p137, p138)
		local v140 = v139.Position - v_u_134
		if v140.Magnitude < 0.01 then
			return v139
		else
			return v139 + v140.Unit * p_u_136
		end
	end
end
local function v_u_163(p142, p_u_143, p144, p145, p146, p147) -- name: truthOrb
	-- upvalues: (copy) v_u_7, (ref) v_u_134
	local v148 = p146 or Color3.fromRGB(14, 10, 20)
	local v149 = Enum.Material.SmoothPlastic
	local v150 = v_u_7.part(Vector3.new(1, 1, 1) * p145, CFrame.identity, v148, {
		["shape"] = nil,
		["transparency"] = 0,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball,
		["material"] = v149
	})
	v150.Reflectance = 0.2
	local v151 = p142.pieces
	local v152 = {
		["part"] = v150,
		["place"] = p_u_143,
		["alpha"] = v150.Transparency
	}
	table.insert(v151, v152)
	local v153 = p145 * 1.3
	local v154 = v_u_7.part(Vector3.new(1, 1, 1) * v153, CFrame.identity, p144, {
		["shape"] = nil,
		["transparency"] = nil,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball,
		["transparency"] = p147 or 0.55
	})
	local v_u_155 = p145 * 0.45
	local function v160(p156, p157)
		-- upvalues: (copy) p_u_143, (ref) v_u_134, (copy) v_u_155
		local v158 = p_u_143(p156, p157)
		local v159 = v158.Position - v_u_134
		if v159.Magnitude < 0.01 then
			return v158
		else
			return v158 + v159.Unit * v_u_155
		end
	end
	local v161 = p142.pieces
	local v162 = {
		["part"] = v154,
		["place"] = v160,
		["alpha"] = v154.Transparency
	}
	table.insert(v161, v162)
	return v150
end
local v_u_164 = 1
local function v_u_173(p165, p166) -- name: scaleSequence
	local v167 = {}
	for _, v168 in p165.Keypoints do
		local v169 = NumberSequenceKeypoint.new
		local v170 = v168.Time
		local v171 = v168.Value * p166
		local v172 = v168.Envelope * p166
		table.insert(v167, v169(v170, v171, v172))
	end
	return NumberSequence.new(v167)
end
task.spawn(function()
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_1
	task.wait(20)
	if v_u_9.level() >= 3 then
		local v174 = v_u_4:FindFirstChild("FormModels") or v_u_4:WaitForChild("FormModels", 20)
		if v174 then
			v_u_1:PreloadAsync({ v174 })
		end
	end
end)
local function v_u_179(p175, p176) -- name: formMesh
	-- upvalues: (copy) v_u_4, (ref) v_u_164, (copy) v_u_7
	local v177 = v_u_4:FindFirstChild("FormModels")
	if v177 then
		v177 = v177:FindFirstChild(p175)
	end
	if v177 then
		v177 = v177:FindFirstChild("Handle")
	end
	if not (v177 and v177:IsA("MeshPart")) then
		return nil
	end
	local v178 = v177:Clone()
	v178.Anchored = true
	v178.CanCollide = false
	v178.CanQuery = false
	v178.CanTouch = false
	v178.Massless = true
	v178.CastShadow = false
	v178.Size = v177.Size * p176 * v_u_164
	v178.Parent = v_u_7.folder()
	return v178
end
local function v_u_193(p180) -- name: backOf
	local v181 = p180.character
	local v182 = p180.root:FindFirstChild("RootRigAttachment")
	local v183 = v181:FindFirstChild("LowerTorso")
	if v183 then
		v183 = v183:FindFirstChild("RootRigAttachment")
	end
	local v184
	if v183 and v183:IsA("Attachment") then
		v184 = v183.CFrame
	else
		v184 = nil
	end
	local v185 = v181:FindFirstChild("LowerTorso")
	if v185 then
		v185 = v185:FindFirstChild("WaistRigAttachment")
	end
	local v186
	if v185 and v185:IsA("Attachment") then
		v186 = v185.CFrame
	else
		v186 = nil
	end
	local v187 = v181:FindFirstChild("UpperTorso")
	if v187 then
		v187 = v187:FindFirstChild("WaistRigAttachment")
	end
	local v188
	if v187 and v187:IsA("Attachment") then
		v188 = v187.CFrame
	else
		v188 = nil
	end
	local v189 = v181:FindFirstChild("UpperTorso")
	if v189 then
		v189 = v189:FindFirstChild("BodyBackAttachment")
	end
	local v190
	if v189 and v189:IsA("Attachment") then
		v190 = v189.CFrame
	else
		v190 = nil
	end
	if v182 and (v182:IsA("Attachment") and (v184 and (v186 and (v188 and v190)))) then
		return v182.CFrame * v184:Inverse() * v186 * v188:Inverse() * v190
	end
	local v191 = v181:FindFirstChild("Torso")
	if v191 then
		v191 = v191:FindFirstChild("BodyBackAttachment")
	end
	local v192
	if v191 and v191:IsA("Attachment") then
		v192 = v191.CFrame
	else
		v192 = nil
	end
	return v192 or CFrame.new(0, 0, 0.5)
end
local function v_u_205(p194) -- name: torsoOf
	local v195 = p194.character
	local v196 = v195:FindFirstChild("UpperTorso")
	if v196 and v196:IsA("BasePart") then
		local v197 = p194.root:FindFirstChild("RootRigAttachment")
		local v198 = v195:FindFirstChild("LowerTorso")
		if v198 then
			v198 = v198:FindFirstChild("RootRigAttachment")
		end
		local v199
		if v198 and v198:IsA("Attachment") then
			v199 = v198.CFrame
		else
			v199 = nil
		end
		local v200 = v195:FindFirstChild("LowerTorso")
		if v200 then
			v200 = v200:FindFirstChild("WaistRigAttachment")
		end
		local v201
		if v200 and v200:IsA("Attachment") then
			v201 = v200.CFrame
		else
			v201 = nil
		end
		local v202 = v195:FindFirstChild("UpperTorso")
		if v202 then
			v202 = v202:FindFirstChild("WaistRigAttachment")
		end
		local v203
		if v202 and v202:IsA("Attachment") then
			v203 = v202.CFrame
		else
			v203 = nil
		end
		if v197 and (v197:IsA("Attachment") and (v199 and (v201 and v203))) then
			return v196, v197.CFrame * v199:Inverse() * v201 * v203:Inverse()
		else
			return v196, p194.root.CFrame:ToObjectSpace(v196.CFrame)
		end
	else
		local v204 = v195:FindFirstChild("Torso")
		if v204 and (v204:IsA("BasePart") and v204 ~= p194.root) then
			return v204, CFrame.identity
		else
			return nil, CFrame.identity
		end
	end
end
local function v_u_216(p206, p207, p208) -- name: glue
	-- upvalues: (copy) v_u_205
	local v209, v210 = v_u_205(p206)
	if v209 then
		p207.Anchored = false
		local v211 = Instance.new("Weld")
		v211.Part0 = v209
		v211.Part1 = p207
		v211.Parent = p207
		local v212 = p206.pieces
		local v213 = {
			["part"] = p207,
			["place"] = p208,
			["alpha"] = p207.Transparency,
			["weld"] = v211,
			["fromTorso"] = v210:Inverse()
		}
		table.insert(v212, v213)
	else
		local v214 = p206.pieces
		local v215 = {
			["part"] = p207,
			["place"] = p208,
			["alpha"] = p207.Transparency
		}
		table.insert(v214, v215)
	end
end
local function v_u_236(p217, p_u_218, p219, p220, p221, p222) -- name: worn
	-- upvalues: (copy) v_u_179, (ref) v_u_164, (copy) v_u_193, (copy) v_u_216
	local v223 = v_u_179(p219, p220)
	if v223 then
		local v224 = v223:FindFirstChild("BodyBackAttachment")
		local v225 = p220 * v_u_164
		local v226
		if v224 and v224:IsA("Attachment") then
			v226 = CFrame.new(v224.CFrame.Position * v225) * v224.CFrame.Rotation
		else
			v226 = CFrame.identity
		end
		local v227 = p221 or CFrame.identity
		local v228 = CFrame.new(v227.Position * v_u_164) * v227.Rotation
		local v_u_229 = v_u_193(p217) * v228 * v226:Inverse()
		if p222 then
			v_u_216(p217, v223, function(p230)
				-- upvalues: (copy) p_u_218, (copy) v_u_229
				if p_u_218 then
					p230 = p_u_218.cf
				end
				return p230 * v_u_229
			end)
			return v223
		elseif p_u_218 then
			local v231 = p217.pieces
			local v232 = {
				["part"] = v223,
				["place"] = function()
					-- upvalues: (copy) p_u_218, (copy) v_u_229
					return p_u_218.cf * v_u_229
				end,
				["alpha"] = v223.Transparency
			}
			table.insert(v231, v232)
			return v223
		else
			local v233 = p217.pieces
			local v235 = {
				["part"] = v223,
				["place"] = function(p234)
					-- upvalues: (copy) v_u_229
					return p234 * v_u_229
				end,
				["alpha"] = v223.Transparency
			}
			table.insert(v233, v235)
			return v223
		end
	else
		return nil
	end
end
local v_u_237 = v_u_164
local v_u_238 = v_u_134
local v_u_239 = {}
local function v241(p240) -- name: blacken
	p240.TextureID = ""
	p240.Color = Color3.fromRGB(10, 9, 14)
	p240.Material = Enum.Material.SmoothPlastic
	p240.Reflectance = 0.12
end
local function v_u_260(p242, p243, p244, p245) -- name: particles
	-- upvalues: (copy) v_u_4, (copy) v_u_173, (copy) v_u_9, (copy) v_u_2
	local v246 = v_u_4:FindFirstChild("Fx")
	if v246 then
		v246 = v246:FindFirstChild(p243)
	end
	if not (v246 and v246:IsA("Attachment")) then
		return nil
	end
	local v_u_247 = v246:Clone()
	local v248 = p245 and (p245.rate or 1) or 1
	local v249 = p245 and (p245.scale or 1) or 1
	local v250 = p242.fx
	local v251
	if p245 then
		v251 = p245.glow
	else
		v251 = p245
	end
	local v252
	if p245 then
		v252 = p245.only
	else
		v252 = p245
	end
	local v253
	if p245 then
		v253 = p245.paint
	else
		v253 = p245
	end
	if p245 and p245.at then
		v_u_247.Position = p245.at
	end
	for _, v254 in v_u_247:GetChildren() do
		if not v254:IsA("ParticleEmitter") then
			continue
		end
		if v252 and not table.find(v252, v254.Name) then
			v254:Destroy()
		else
			if v253 then
				v254.Color = ColorSequence.new(v253)
			elseif p244 and v254:GetAttribute("Tint") == true then
				v254.Color = ColorSequence.new(p244)
				if v251 then
					local v255 = v254.LightEmission
					v254.LightEmission = math.min(v255, v251)
				end
			end
			if v249 ~= 1 then
				v254.Size = v_u_173(v254.Size, v249)
				v254.Speed = NumberRange.new(v254.Speed.Min * v249, v254.Speed.Max * v249)
			end
			if v250 ~= 1 then
				v254.Size = v_u_173(v254.Size, v250)
				v254.Speed = NumberRange.new(v254.Speed.Min * v250, v254.Speed.Max * v250)
				v254.Acceleration = v254.Acceleration * v250
				if v_u_9.level() >= 3 then
					v254.Rate = v254.Rate * 1.6
				end
			end
			v254.Rate = v254.Rate * v248
			v254:SetAttribute("BaseRate", v254.Rate)
			v254.Rate = v254.Rate * v_u_9.formRate()
			v254.Enabled = true
		end
	end
	v_u_247.Parent = p242.root
	v_u_247:SetAttribute("FormExtra", true)
	local v256 = p242.extras
	table.insert(v256, v_u_247)
	local v257 = p242.stops
	local function v259()
		-- upvalues: (copy) v_u_247, (ref) v_u_2
		for _, v258 in v_u_247:GetChildren() do
			if not v258:IsA("ParticleEmitter") then
				continue
			end
			v258.Enabled = false
		end
		v_u_2:AddItem(v_u_247, 2)
	end
	table.insert(v257, v259)
	return v_u_247
end
local function v270(p_u_261, p_u_262, p_u_263, p_u_264) -- name: beat
	-- upvalues: (copy) v_u_7, (copy) v_u_12
	local v_u_265 = p_u_262 * 0.5
	local v266 = p_u_261.ticks
	local function v269(p267, p268)
		-- upvalues: (ref) v_u_265, (copy) p_u_262, (ref) v_u_7, (copy) p_u_263, (copy) p_u_264, (copy) p_u_261, (ref) v_u_12
		if v_u_265 <= p268 then
			v_u_265 = p268 + p_u_262
			v_u_7.ring(p267.Position + Vector3.new(0, -0.8, 0), p_u_263, p_u_264 * p_u_261.fx, 0.5, v_u_12.Ring)
		end
	end
	table.insert(v266, v269)
end
local function v_u_291(p271, p272, p_u_273, p_u_274, p_u_275) -- name: ripples
	-- upvalues: (copy) v_u_7, (copy) v_u_12
	local v_u_276 = p271.fx
	for v_u_277 = 0, p_u_273 - 1 do
		local v_u_278 = v_u_7.part(Vector3.new(1, 0.05, 1), CFrame.identity, p272, {
			["transparency"] = 1
		})
		local v_u_279 = {}
		for _, v280 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v281 = Instance.new("Decal")
			v281.Face = v280
			v281.Texture = v_u_12.Ring
			v281.Color3 = p272
			v281.Parent = v_u_278
			table.insert(v_u_279, v281)
		end
		local v282 = p271.pieces
		local v285 = {
			["part"] = v_u_278,
			["place"] = function(p283)
				-- upvalues: (copy) p_u_275
				local v284 = p_u_275
				return CFrame.new(p283.Position + Vector3.new(0, v284, 0))
			end,
			["alpha"] = v_u_278.Transparency
		}
		table.insert(v282, v285)
		local v286 = p271.ticks
		table.insert(v286, function(_, p287)
			-- upvalues: (copy) p_u_274, (copy) v_u_277, (copy) p_u_273, (copy) v_u_276, (copy) v_u_278, (copy) v_u_279
			local v288 = (p287 / p_u_274 + v_u_277 / p_u_273) % 1
			local v289 = (2 + v288 * 7) * v_u_276
			v_u_278.Size = Vector3.new(v289, 0.05, v289)
			for _, v290 in v_u_279 do
				v290.Transparency = v288
			end
		end)
	end
end
for _, v292 in {
	"Head",
	"UpperTorso",
	"LowerTorso",
	"LeftUpperArm",
	"RightUpperArm",
	"LeftLowerArm",
	"RightLowerArm",
	"LeftHand",
	"RightHand",
	"LeftUpperLeg",
	"RightUpperLeg",
	"Torso",
	"Left Arm",
	"Right Arm",
	"Left Leg",
	"Right Leg"
} do
	v_u_239[v292] = true
end
local function v_u_312(p293, p294, p295, p296) -- name: wornOnBody
	-- upvalues: (copy) v_u_179, (copy) v_u_239, (ref) v_u_237
	local v297 = v_u_179(p294, p295)
	if not v297 then
		return nil
	end
	local v298 = v297:FindFirstChildWhichIsA("Attachment")
	local v_u_299 = nil
	local v300 = nil
	if v298 then
		for _, v301 in p293.character:GetChildren() do
			local v302
			if v301:IsA("BasePart") and v_u_239[v301.Name] then
				v302 = v301:FindFirstChild(v298.Name)
			else
				v302 = nil
			end
			if not (v302 and v302:IsA("Attachment")) then
				continue
			end
			v300 = v302
			v_u_299 = v301
		end
	end
	if not (v298 and (v_u_299 and v300)) then
		v297:Destroy()
		return nil
	end
	local v303 = p295 * v_u_237
	local v304 = CFrame.new(v298.CFrame.Position * v303) * v298.CFrame.Rotation
	local v305 = p296 or CFrame.identity
	local v306 = CFrame.new(v305.Position * v_u_237) * v305.Rotation
	local v_u_307 = v300.CFrame * v306 * v304:Inverse()
	v297.Anchored = false
	local v308 = Instance.new("Weld")
	v308.Part0 = v_u_299
	v308.Part1 = v297
	v308.C0 = v_u_307
	v308.Parent = v297
	local v310 = {
		["part"] = v297,
		["place"] = function(p309, _) -- name: place
			-- upvalues: (copy) v_u_299, (copy) v_u_307
			if v_u_299.Parent then
				return v_u_299.CFrame * v_u_307
			else
				return p309 * v_u_307
			end
		end,
		["alpha"] = v297.Transparency,
		["weld"] = v308
	}
	local v311 = p293.pieces
	table.insert(v311, v310)
	return v297
end
local v_u_313 = CFrame.Angles(0, 1.5707963267948966, 0) * CFrame.Angles(0.5585053606381855, 0, 0) * CFrame.Angles(0, 0, -0.5410520681182421)
local v_u_314 = CFrame.Angles(0, 0, -0.6806784082777885)
local function v_u_322(p315, p316, p317, p318, p319, p320) -- name: image
	local v321 = Instance.new("ImageLabel")
	v321.BackgroundTransparency = 1
	v321.Image = p316
	v321.AnchorPoint = Vector2.new(0.5, 0.5)
	v321.Position = UDim2.fromScale(0.5, 0.5)
	v321.Size = UDim2.fromScale(p317, p317)
	v321.ZIndex = p318
	if p319 then
		v321.ImageColor3 = p319
	end
	v321.ImageTransparency = p320 or 0
	v321.Parent = p315
	return v321
end
local function v_u_329(p323, p324, p325, p326) -- name: circle
	local v327 = Instance.new("Frame")
	v327.AnchorPoint = Vector2.new(0.5, 0.5)
	v327.Position = UDim2.fromScale(0.5, 0.5)
	v327.Size = UDim2.fromScale(p324, p324)
	v327.SizeConstraint = Enum.SizeConstraint.RelativeYY
	v327.BackgroundColor3 = p325
	v327.BorderSizePixel = 0
	v327.ZIndex = p326
	local v328 = Instance.new("UICorner")
	v328.CornerRadius = UDim.new(1, 0)
	v328.Parent = v327
	v327.Parent = p323
	return v327
end
local function v_u_337(p330, p331, p332) -- name: drawnEye
	-- upvalues: (copy) v_u_329
	local v333 = Instance.new("Frame")
	v333.Name = "Eye"
	v333.AnchorPoint = Vector2.new(0.5, 0.5)
	v333.Position = UDim2.fromScale(0.5, 0.5)
	v333.Size = UDim2.fromScale(p331, p331 * 0.56)
	v333.BackgroundColor3 = Color3.fromRGB(255, 252, 240)
	v333.BorderSizePixel = 0
	v333.ZIndex = 3
	v333.ClipsDescendants = true
	local v334 = Instance.new("UICorner")
	v334.CornerRadius = UDim.new(1, 0)
	v334.Parent = v333
	local v335 = Instance.new("UIStroke")
	v335.Color = p332
	v335.Thickness = 3
	v335.Parent = v333
	local v336 = v_u_329(v333, 0.92, p332, 4)
	v_u_329(v336, 0.5, Color3.fromRGB(12, 8, 6), 5)
	v_u_329(v336, 0.18, Color3.new(1, 1, 1), 6).Position = UDim2.fromScale(0.36, 0.34)
	v333.Parent = p330
	return v333
end
local function v_u_365(p_u_338, p339) -- name: headEye
	-- upvalues: (copy) v_u_7, (copy) v_u_322, (copy) v_u_12, (copy) v_u_14, (copy) v_u_337
	local v340 = p_u_338.character:FindFirstChild("Head")
	if v340 and v340:IsA("BasePart") then
		local v341 = v_u_7.color(p339.color)
		local v_u_342 = Instance.new("BillboardGui")
		v_u_342.Name = "FormEye"
		v_u_342.Adornee = v340
		v_u_342.Size = UDim2.fromScale(3.4, 3.4)
		local v343 = p_u_338.eyeLift
		v_u_342.StudsOffsetWorldSpace = Vector3.new(0, v343, 0)
		v_u_342.LightInfluence = 0
		v_u_342.Brightness = 1.3
		v_u_342.MaxDistance = 250
		v_u_342.ResetOnSpawn = false
		local v_u_344 = v_u_322(v_u_342, v_u_12.Glow, 1.05, 1, v341, 0.35)
		local v_u_345 = v_u_322(v_u_342, v_u_12.Ring, 0.86, 2, v341)
		local v346 = v_u_14[p339.id]
		local v_u_347 = nil
		if v346 then
			v_u_347 = v_u_322(v_u_342, v346, 0.6, 3)
		else
			local v348 = v_u_337
			local v349 = 0.7
			if v341.R * 0.3 + v341.G * 0.59 + v341.B * 0.11 > 0.8 then
				v341 = v_u_7.color(p339.color2)
			end
			v348(v_u_342, v349, v341)
		end
		v_u_342.Parent = v340
		v_u_342:SetAttribute("FormExtra", true)
		local v350 = p_u_338.extras
		table.insert(v350, v_u_342)
		local v_u_351 = 0
		local v_u_352 = 0
		local v353 = p_u_338.ticks
		local function v363(_, p354, p355)
			-- upvalues: (ref) v_u_351, (copy) p_u_338, (ref) v_u_347, (copy) v_u_345, (copy) v_u_344, (copy) v_u_342, (ref) v_u_352
			v_u_351 = (v_u_351 + p355 * (55 + p_u_338.flare * 700)) % 360
			if v_u_347 then
				v_u_347.Rotation = v_u_351
			end
			v_u_345.Rotation = -v_u_351 * 0.5
			local v356 = v_u_344
			local v357 = p354 * 3
			v356.ImageTransparency = math.sin(v357) * 0.08 + 0.35 - p_u_338.flare * 0.3 - p_u_338.pulse * 0.3
			local v358 = v_u_342
			local v359 = p_u_338.eyeLift
			local v360 = p354 * 2
			local v361 = v359 + math.sin(v360) * 0.1
			v358.StudsOffsetWorldSpace = Vector3.new(0, v361, 0)
			if p_u_338.pulse ~= v_u_352 then
				v_u_352 = p_u_338.pulse
				local v362 = (v_u_352 * 0.14 + 1) * 3.4
				v_u_342.Size = UDim2.fromScale(v362, v362)
			end
		end
		table.insert(v353, v363)
		local v364 = p_u_338.stops
		table.insert(v364, function()
			-- upvalues: (copy) v_u_342
			v_u_342:Destroy()
		end)
	end
end
local v_u_1353 = {
	["tomoe"] = function(p_u_366)
		-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_260
		local v_u_367 = Color3.fromRGB(235, 22, 34)
		local v_u_368 = 1.75
		local v369 = p_u_366.ticks
		local v_u_370 = 3.5
		local v_u_371 = 4
		local function v374(p372, p373)
			-- upvalues: (ref) v_u_368, (copy) v_u_370, (ref) v_u_7, (copy) v_u_367, (copy) v_u_371, (copy) p_u_366, (ref) v_u_12
			if v_u_368 <= p373 then
				v_u_368 = p373 + v_u_370
				v_u_7.ring(p372.Position + Vector3.new(0, -0.8, 0), v_u_367, v_u_371 * p_u_366.fx, 0.5, v_u_12.Ring)
			end
		end
		table.insert(v369, v374)
		v_u_260(p_u_366, "AuraMode", v_u_367, {
			["rate"] = 0.6,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = {
				"Glow",
				"FlameBack",
				"FlameFront",
				"Sparks",
				"Pulse"
			}
		})
	end,
	["ribcage"] = function(p375)
		-- upvalues: (copy) v_u_179, (ref) v_u_237, (copy) v_u_216, (copy) v_u_133, (copy) v_u_7, (copy) v_u_313, (copy) v_u_260
		local v376 = Color3.fromRGB(255, 72, 28)
		local function v_u_381(p377, p378)
			local v379 = CFrame.new
			local v380 = p378 * 2.2
			return p377 * v379(0, math.sin(v380) * 0.06, 0)
		end
		local v_u_382 = {
			["cf"] = CFrame.identity
		}
		local v383 = p375.ticks
		table.insert(v383, function(p384, p385)
			-- upvalues: (copy) v_u_382, (copy) v_u_381
			v_u_382.cf = v_u_381(p384, p385)
		end)
		local v386 = v_u_179("SusanooRibcage", 0.95)
		if v386 then
			local v387 = v386:FindFirstChildOfClass("SurfaceAppearance")
			if v387 then
				v387.Color = Color3.fromRGB(255, 90, 40)
			else
				v386.Color = v376
			end
			local v_u_388 = CFrame.new(Vector3.new(0, 0.4, 0.05) * v_u_237)
			v_u_216(p375, v386, function(p389)
				-- upvalues: (copy) v_u_388
				return p389 * v_u_388
			end)
		else
			v_u_133(p375, v_u_382, v376, 0.25, 2.9, 4, 1.3, -1, 0.28)
		end
		local function v_u_394(p390, p391)
			local v392 = CFrame.new
			local v393 = p391 * 1.6
			return p390 * v392(-3.55, math.sin(v393) * 0.15 + 0.1, -0.2) * CFrame.Angles(0, 0.7853981633974483, 0)
		end
		local v_u_395 = {
			["cf"] = CFrame.identity
		}
		local v396 = p375.ticks
		table.insert(v396, function(p397, p398)
			-- upvalues: (copy) v_u_395, (copy) v_u_394
			v_u_395.cf = v_u_394(p397, p398)
		end)
		local v399 = v_u_7.part(Vector3.new(0.22, 2.3, 2.3), CFrame.identity, v376, {
			["shape"] = nil,
			["transparency"] = 0.35,
			["material"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v_u_400 = CFrame.identity
		local v401 = p375.pieces
		local v402 = {
			["part"] = v399,
			["place"] = function()
				-- upvalues: (copy) v_u_395, (copy) v_u_400
				return v_u_395.cf * v_u_400
			end,
			["alpha"] = v399.Transparency
		}
		table.insert(v401, v402)
		local v403 = Color3.fromRGB(255, 190, 80)
		local v404 = v_u_7.part(Vector3.new(0.3, 1.3, 1.3), CFrame.identity, v403, {
			["shape"] = nil,
			["transparency"] = 0.15,
			["material"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v_u_405 = CFrame.identity
		local v406 = p375.pieces
		local v407 = {
			["part"] = v404,
			["place"] = function()
				-- upvalues: (copy) v_u_395, (copy) v_u_405
				return v_u_395.cf * v_u_405
			end,
			["alpha"] = v404.Transparency
		}
		table.insert(v406, v407)
		local function v_u_412(p408, p409)
			local v410 = CFrame.new
			local v411 = p409 * 1.8 + 1
			return p408 * v410(3.45, math.sin(v411) * 0.15 + 0.4, 0.1) * CFrame.Angles(0, 0, -0.3141592653589793)
		end
		local v_u_413 = {
			["cf"] = CFrame.identity
		}
		local v414 = p375.ticks
		table.insert(v414, function(p415, p416)
			-- upvalues: (copy) v_u_413, (copy) v_u_412
			v_u_413.cf = v_u_412(p415, p416)
		end)
		local v417 = v_u_179("TotsukaSword", 1.35)
		if v417 then
			local v_u_418 = CFrame.new(0, 0.5, 0) * v_u_313
			local v419 = p375.pieces
			local v420 = {
				["part"] = v417,
				["place"] = function()
					-- upvalues: (copy) v_u_413, (copy) v_u_418
					return v_u_413.cf * v_u_418
				end,
				["alpha"] = v417.Transparency
			}
			table.insert(v419, v420)
		else
			local v421 = Color3.fromRGB(255, 205, 160)
			local v422 = v_u_7.part(Vector3.new(0.18, 3.8, 0.55), CFrame.identity, v421, {
				["transparency"] = 0.15,
				["material"] = nil
			})
			local v423 = Instance.new("SpecialMesh")
			v423.MeshType = Enum.MeshType.Sphere
			v423.Parent = v422
			local v_u_424 = CFrame.new(0, 0.6, 0)
			local v425 = p375.pieces
			local v426 = {
				["part"] = v422,
				["place"] = function()
					-- upvalues: (copy) v_u_413, (copy) v_u_424
					return v_u_413.cf * v_u_424
				end,
				["alpha"] = v422.Transparency
			}
			table.insert(v425, v426)
			local v427 = v_u_7.part(Vector3.new(0.6, 0.6, 0.6), CFrame.identity, v376, {
				["shape"] = nil,
				["transparency"] = 0.1,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v_u_428 = CFrame.new(0, -1.45, 0)
			local v429 = p375.pieces
			local v430 = {
				["part"] = v427,
				["place"] = function()
					-- upvalues: (copy) v_u_413, (copy) v_u_428
					return v_u_413.cf * v_u_428
				end,
				["alpha"] = v427.Transparency
			}
			table.insert(v429, v430)
		end
		v_u_260(p375, "AuraMode", v376, {
			["rate"] = 0.6,
			["glow"] = 0.55,
			["only"] = nil,
			["only"] = {
				"Glow",
				"FlameBack",
				"FlameFront",
				"Sparks"
			}
		})
	end,
	["sigil"] = function(p_u_431)
		-- upvalues: (copy) v_u_236, (copy) v_u_7, (copy) v_u_12, (copy) v_u_260
		local v_u_432 = Color3.fromRGB(225, 8, 55)
		local v433 = Color3.fromRGB(255, 55, 105)
		local function v_u_438(p434, p435)
			local v436 = CFrame.new
			local v437 = p435 * 2.4
			return p434 * v436(0, math.sin(v437) * 0.12 + 0.15, 0)
		end
		local v_u_439 = {
			["cf"] = CFrame.identity
		}
		local v440 = p_u_431.ticks
		table.insert(v440, function(p441, p442)
			-- upvalues: (copy) v_u_439, (copy) v_u_438
			v_u_439.cf = v_u_438(p441, p442)
		end)
		local v443 = v_u_236(p_u_431, v_u_439, "GeassWings", 1.15, CFrame.new(0, 0.2, 0.2), true)
		local v444 = { 3.4, 2.8, 2.1 }
		local v_u_445 = { 8, 34, 60 }
		if not v443 then
			for _, v_u_446 in { -1, 1 } do
				for v_u_447 = 1, 3 do
					local v_u_448 = v444[v_u_447]
					local v449 = Vector3.new(0.16, 0.75, v_u_448)
					local v450
					if v_u_447 == 2 then
						v450 = v433
					else
						v450 = v_u_432
					end
					local v451 = v_u_7.part(v449, CFrame.identity, v450, {
						["transparency"] = 0.05,
						["material"] = nil
					})
					local v452 = Instance.new("SpecialMesh")
					v452.MeshType = Enum.MeshType.Sphere
					v452.Parent = v451
					local v453 = p_u_431.pieces
					local v465 = {
						["part"] = v451,
						["place"] = function(p454, p455)
							-- upvalues: (copy) v_u_445, (copy) v_u_447, (copy) v_u_446, (copy) v_u_448
							local v456 = v_u_445[v_u_447]
							local v457 = p455 * 2.4
							local v458 = v456 + math.sin(v457) * 9
							local v459 = math.rad(v458)
							local v460 = v_u_446 * math.cos(v459)
							local v461 = math.sin(v459)
							local v462 = Vector3.new(v460, v461, 0.3).Unit
							local v463 = v_u_446 * 0.5
							local v464 = Vector3.new(v463, 0.7, 0.6) + v462 * v_u_448 / 2
							return p454 * CFrame.lookAt(v464, v464 + v462)
						end,
						["alpha"] = v451.Transparency
					}
					table.insert(v453, v465)
				end
			end
		end
		for v_u_466 = 1, 3 do
			local v_u_467 = (v_u_466 - 1) / 3 * 3.141592653589793 * 2
			local function v_u_479(p468, p469)
				-- upvalues: (copy) v_u_467, (copy) v_u_466
				local v470 = v_u_467 + p469 * 1.1
				local v471 = math.cos(v470) * 3.1
				local v472 = p469 * 1.7 + v_u_466
				local v473 = math.sin(v472) * 0.45 + -0.4
				local v474 = math.sin(v470) * 3.1
				local v475 = Vector3.new(v471, v473, v474)
				local v476 = CFrame.lookAt
				local v477 = v475.X
				local v478 = v475.Z
				return p468 * v476(v475, v475 + Vector3.new(v477, 0, v478))
			end
			local v_u_480 = {
				["cf"] = CFrame.identity
			}
			local v481 = p_u_431.ticks
			table.insert(v481, function(p482, p483)
				-- upvalues: (copy) v_u_480, (copy) v_u_479
				v_u_480.cf = v_u_479(p482, p483)
			end)
			local v484 = v_u_7.part(Vector3.new(0.5, 0.5, 0.14), CFrame.identity, v433, {
				["transparency"] = 0,
				["material"] = nil
			})
			local v_u_485 = CFrame.new(0, -0.05, 0) * CFrame.Angles(0, 0, 0.7853981633974483)
			local v486 = p_u_431.pieces
			local v487 = {
				["part"] = v484,
				["place"] = function()
					-- upvalues: (copy) v_u_480, (copy) v_u_485
					return v_u_480.cf * v_u_485
				end,
				["alpha"] = v484.Transparency
			}
			table.insert(v486, v487)
			for _, v_u_488 in { -1, 1 } do
				local v489 = v_u_7.part(Vector3.new(1.6, 0.42, 0.12), CFrame.identity, v_u_432, {
					["transparency"] = 0,
					["material"] = nil
				})
				local v490 = Instance.new("SpecialMesh")
				v490.MeshType = Enum.MeshType.Sphere
				v490.Parent = v489
				local v491 = p_u_431.pieces
				local v496 = {
					["part"] = v489,
					["place"] = function(_, p492)
						-- upvalues: (copy) v_u_466, (copy) v_u_480, (copy) v_u_488
						local v493 = p492 * 6 + v_u_466
						local v494 = math.sin(v493) * 15 + 30
						local v495 = math.rad(v494)
						return v_u_480.cf * CFrame.new(v_u_488 * 0.68, 0.22, 0) * CFrame.Angles(0, 0, v_u_488 * v495)
					end,
					["alpha"] = v489.Transparency
				}
				table.insert(v491, v496)
			end
		end
		local v_u_497 = 1.5
		local v498 = p_u_431.ticks
		local v_u_499 = 3
		local v_u_500 = 4
		local function v503(p501, p502)
			-- upvalues: (ref) v_u_497, (copy) v_u_499, (ref) v_u_7, (copy) v_u_432, (copy) v_u_500, (copy) p_u_431, (ref) v_u_12
			if v_u_497 <= p502 then
				v_u_497 = p502 + v_u_499
				v_u_7.ring(p501.Position + Vector3.new(0, -0.8, 0), v_u_432, v_u_500 * p_u_431.fx, 0.5, v_u_12.Ring)
			end
		end
		table.insert(v498, v503)
		v_u_260(p_u_431, "AuraMode", v_u_432, {
			["rate"] = 0.6,
			["glow"] = 0.55,
			["only"] = nil,
			["only"] = {
				"Glow",
				"Streaks",
				"Crackle",
				"Sparks"
			}
		})
	end,
	["susanoo"] = function(p504)
		-- upvalues: (copy) v_u_179, (copy) v_u_3, (copy) v_u_6, (copy) v_u_236, (copy) v_u_133, (copy) v_u_7, (copy) v_u_260
		local v505 = Color3.fromRGB(85, 30, 215)
		local v506 = Color3.fromRGB(150, 95, 255)
		local function v_u_511(p507, p508)
			local v509 = CFrame.new
			local v510 = p508 * 2
			return p507 * v509(0, math.sin(v510) * 0.06, 0)
		end
		local v_u_512 = {
			["cf"] = CFrame.identity
		}
		local v513 = p504.ticks
		table.insert(v513, function(p514, p515)
			-- upvalues: (copy) v_u_512, (copy) v_u_511
			v_u_512.cf = v_u_511(p514, p515)
		end)
		local v_u_516 = v_u_179("SusanooSkeleton", 2)
		if v_u_516 then
			v_u_516.Transparency = 0.12
			local v_u_517 = CFrame.new(0.8, 4, 2.8) * CFrame.Angles(0, 3.141592653589793, 0)
			local v518 = p504.pieces
			local v519 = {
				["part"] = v_u_516,
				["place"] = function()
					-- upvalues: (copy) v_u_512, (copy) v_u_517
					return v_u_512.cf * v_u_517
				end,
				["alpha"] = v_u_516.Transparency
			}
			table.insert(v518, v519)
			if p504.character == v_u_3.LocalPlayer.Character then
				local v520 = p504.ticks
				local v_u_521 = 0.8
				local function v526(p522)
					-- upvalues: (ref) v_u_6, (copy) v_u_516, (copy) v_u_521
					local v523 = v_u_6.CurrentCamera
					if v523 then
						local v524 = v_u_516
						local v525 = (v523.CFrame.LookVector:Dot(p522.LookVector) + 0.1) * 1.6
						v524.LocalTransparencyModifier = math.clamp(v525, 0, 1) * v_u_521
					end
				end
				table.insert(v520, v526)
			end
			v_u_236(p504, v_u_512, "SusanooArms", 1.15, nil, true)
		else
			v_u_133(p504, v_u_512, v505, 0.2, 3, 3, 1.1, -0.7, 0.32)
			for _, v527 in { -1, 1 } do
				local v528 = v_u_7.part(Vector3.new(1.9, 0.35, 2), CFrame.identity, v505, {
					["transparency"] = 0.1,
					["material"] = nil
				})
				local v_u_529 = CFrame.new(v527 * 2, 1.45, 0.1) * CFrame.Angles(0, 0, -v527 * 0.4188790204786391)
				local v530 = p504.pieces
				local v531 = {
					["part"] = v528,
					["place"] = function()
						-- upvalues: (copy) v_u_512, (copy) v_u_529
						return v_u_512.cf * v_u_529
					end,
					["alpha"] = v528.Transparency
				}
				table.insert(v530, v531)
				local v532 = v_u_7.part(Vector3.new(0.45, 1.6, 0.45), CFrame.identity, v506, {
					["transparency"] = 0.05,
					["material"] = nil
				})
				local v533 = Instance.new("SpecialMesh")
				v533.MeshType = Enum.MeshType.Sphere
				v533.Parent = v532
				local v_u_534 = CFrame.new(v527 * 2.65, 2.15, 0.25) * CFrame.Angles(0, 0, -v527 * 0.6108652381980153)
				local v535 = p504.pieces
				local v536 = {
					["part"] = v532,
					["place"] = function()
						-- upvalues: (copy) v_u_512, (copy) v_u_534
						return v_u_512.cf * v_u_534
					end,
					["alpha"] = v532.Transparency
				}
				table.insert(v535, v536)
			end
		end
		local function v_u_541(p537, p538)
			local v539 = CFrame.new
			local v540 = p538 * 1.5
			return p537 * v539(-3.7, math.sin(v540) * 0.12 + 0.2, -0.2) * CFrame.Angles(0, 0.7853981633974483, 0)
		end
		local v_u_542 = {
			["cf"] = CFrame.identity
		}
		local v543 = p504.ticks
		table.insert(v543, function(p544, p545)
			-- upvalues: (copy) v_u_542, (copy) v_u_541
			v_u_542.cf = v_u_541(p544, p545)
		end)
		local v546 = Vector3.new(0, -1.9505106, 0.5061857)
		for v547 = 1, 6 do
			local v548 = v547 / 6 * 2.0245819323134224 + -1.0122909661567112
			local v549 = math.sin(v548) * 2.3
			local v550 = -math.cos(v548) * 2.3 + 1.7249999999999999
			local v551 = Vector3.new(0, v549, v550)
			local v_u_552 = CFrame.lookAt((v546 + v551) / 2, v551)
			local v553 = (v551 - v546).Magnitude
			local v554 = 3.141592653589793 * (v547 - 0.5) / 6
			local v555 = math.sin(v554) * 0.14 + 0.2
			local v556 = v553 + 0.1
			local v557 = Vector3.new(v555, v555, v556)
			local v558 = v_u_7.part(v557, CFrame.identity, v506, {
				["transparency"] = 0.1,
				["material"] = nil
			})
			local v559 = p504.pieces
			local v560 = {
				["part"] = v558,
				["place"] = function()
					-- upvalues: (copy) v_u_542, (copy) v_u_552
					return v_u_542.cf * v_u_552
				end,
				["alpha"] = v558.Transparency
			}
			table.insert(v559, v560)
			v546 = v551
		end
		local v561 = Vector3.new(0, 1.9505106, 0.5061857)
		local v562 = Vector3.new(0, -1.9505106, 0.5061857)
		local v_u_563 = CFrame.lookAt((v562 + v561) / 2, v561)
		local v564 = (v561 - v562).Magnitude
		local v565 = Vector3.new(0.06, 0.06, v564)
		local v566 = Color3.fromRGB(235, 220, 255)
		local v567 = v_u_7.part(v565, CFrame.identity, v566, {
			["transparency"] = 0.2,
			["material"] = nil
		})
		local v568 = p504.pieces
		local v569 = {
			["part"] = v567,
			["place"] = function()
				-- upvalues: (copy) v_u_542, (copy) v_u_563
				return v_u_542.cf * v_u_563
			end,
			["alpha"] = v567.Transparency
		}
		table.insert(v568, v569)
		local v570 = v561.Z
		local v571 = Vector3.new(0, 0, v570)
		local v572 = v561.Z - 3.4
		local v573 = Vector3.new(0, 0, v572)
		local v_u_574 = CFrame.lookAt((v571 + v573) / 2, v573)
		local v575 = (v573 - v571).Magnitude
		local v576 = Vector3.new(0.1, 0.1, v575)
		local v577 = Color3.fromRGB(225, 200, 255)
		local v578 = v_u_7.part(v576, CFrame.identity, v577, {
			["transparency"] = 0.1,
			["material"] = nil
		})
		local v579 = p504.pieces
		local v580 = {
			["part"] = v578,
			["place"] = function()
				-- upvalues: (copy) v_u_542, (copy) v_u_574
				return v_u_542.cf * v_u_574
			end,
			["alpha"] = v578.Transparency
		}
		table.insert(v579, v580)
		local v581 = v_u_7.part(Vector3.new(0.32, 0.32, 0.8), CFrame.identity, v505, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v582 = Instance.new("SpecialMesh")
		v582.MeshType = Enum.MeshType.Sphere
		v582.Parent = v581
		local v_u_583 = CFrame.new(v573)
		local v584 = p504.pieces
		local v585 = {
			["part"] = v581,
			["place"] = function()
				-- upvalues: (copy) v_u_542, (copy) v_u_583
				return v_u_542.cf * v_u_583
			end,
			["alpha"] = v581.Transparency
		}
		table.insert(v584, v585)
		v_u_260(p504, "AuraMode", v505, {
			["rate"] = 0.5,
			["glow"] = 0.5,
			["only"] = nil,
			["only"] = {
				"Glow",
				"FlameBack",
				"FlameFront",
				"Crackle",
				"Sparks"
			}
		})
	end,
	["orbs"] = function(p586)
		-- upvalues: (copy) v_u_236, (copy) v_u_163, (copy) v_u_179, (copy) v_u_314, (copy) v_u_291, (copy) v_u_260
		local v587 = Color3.fromRGB(165, 125, 255)
		local function v_u_592(p588, p589)
			local v590 = CFrame.new
			local v591 = p589 * 1.3
			return p588 * v590(0, math.sin(v591) * 0.12, 0)
		end
		local v_u_593 = {
			["cf"] = CFrame.identity
		}
		local v594 = p586.ticks
		table.insert(v594, function(p595, p596)
			-- upvalues: (copy) v_u_593, (copy) v_u_592
			v_u_593.cf = v_u_592(p595, p596)
		end)
		local v597 = v_u_236(p586, v_u_593, "TruthOrbRing", 2.2, CFrame.new(0, 0.3, 0.4), true)
		if v597 then
			v597.TextureID = ""
			v597.Color = Color3.fromRGB(10, 9, 14)
			v597.Material = Enum.Material.SmoothPlastic
			v597.Reflectance = 0.12
		else
			for v_u_598 = 1, 6 do
				local v599 = (v_u_598 - 1) * 30 + 15
				local v_u_600 = math.rad(v599)
				v_u_163(p586, function(p601, p602)
					-- upvalues: (copy) v_u_600, (copy) v_u_598
					local v603 = v_u_600
					local v604 = p602 * 0.8
					local v605 = v603 + math.sin(v604) * 0.1
					local v606 = p602 * 2 + v_u_598
					local v607 = math.sin(v606) * 0.1 + 2.6
					return p601 * CFrame.new(math.cos(v605) * v607, math.sin(v605) * v607 + 0.45, 1.45)
				end, v587, 1.05)
			end
		end
		local v608 = v_u_179("SageStaff", 1.8)
		if v608 then
			local function v_u_613(p609, p610)
				local v611 = CFrame.new
				local v612 = p610 * 1.5 + 1
				return p609 * v611(2.6, math.sin(v612) * 0.15 + 0.5, 0.1) * CFrame.Angles(0, 0, -0.13962634015954636)
			end
			local v_u_614 = {
				["cf"] = CFrame.identity
			}
			local v615 = p586.ticks
			table.insert(v615, function(p616, p617)
				-- upvalues: (copy) v_u_614, (copy) v_u_613
				v_u_614.cf = v_u_613(p616, p617)
			end)
			local v_u_618 = v_u_314
			local v619 = p586.pieces
			local v620 = {
				["part"] = v608,
				["place"] = function()
					-- upvalues: (copy) v_u_614, (copy) v_u_618
					return v_u_614.cf * v_u_618
				end,
				["alpha"] = v608.Transparency
			}
			table.insert(v619, v620)
		end
		v_u_291(p586, v587, 2, 2.2, -0.9)
		v_u_260(p586, "AuraMode", v587, {
			["rate"] = 0.5,
			["glow"] = 0.5,
			["only"] = nil,
			["only"] = { "Glow", "Sparks", "Pulse" }
		})
		v_u_260(p586, "Petals", v587, {
			["rate"] = 0.8,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Motes" }
		})
	end,
	["lightning"] = function(p_u_621)
		-- upvalues: (copy) v_u_236, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_12, (copy) v_u_19, (copy) v_u_15, (copy) v_u_260
		local v_u_622 = Color3.fromRGB(200, 240, 255)
		local v623 = Color3.fromRGB(40, 140, 255)
		local function v_u_628(p624, p625)
			local v626 = CFrame.new
			local v627 = p625 * 1.4
			return p624 * v626(0, math.sin(v627) * 0.15, 0)
		end
		local v_u_629 = {
			["cf"] = CFrame.identity
		}
		local v630 = p_u_621.ticks
		table.insert(v630, function(p631, p632)
			-- upvalues: (copy) v_u_629, (copy) v_u_628
			v_u_629.cf = v_u_628(p631, p632)
		end)
		local v_u_633 = v_u_236(p_u_621, v_u_629, "SusanooBlue", 1.35, CFrame.new(0, 1.6, 1.1))
		if v_u_633 then
			if p_u_621.character == v_u_3.LocalPlayer.Character then
				local v634 = p_u_621.ticks
				local v_u_635 = 0.6
				local function v640(p636)
					-- upvalues: (ref) v_u_6, (copy) v_u_633, (copy) v_u_635
					local v637 = v_u_6.CurrentCamera
					if v637 then
						local v638 = v_u_633
						local v639 = (v637.CFrame.LookVector:Dot(p636.LookVector) + 0.1) * 1.6
						v638.LocalTransparencyModifier = math.clamp(v639, 0, 1) * v_u_635
					end
				end
				table.insert(v634, v640)
			end
			p_u_621.eyeLift = 5
		end
		local v_u_641 = {}
		local v642 = p_u_621.ticks
		table.insert(v642, function(_, p643)
			-- upvalues: (copy) v_u_641
			for v644 = 1, 6 do
				local v645 = (v644 - 1) / 6 * 3.141592653589793 * 2 + p643 * 1.2
				local v646 = v_u_641
				local v647 = math.cos(v645) * 2.7
				local v648 = p643 * 2 + v644 * 1.3
				local v649 = math.sin(v648) * 0.55 + -0.5
				local v650 = math.sin(v645) * 2.7
				v646[v644] = Vector3.new(v647, v649, v650)
			end
		end)
		local v651 = {}
		for v_u_652 = 1, 6 do
			local v653 = v_u_7.part(Vector3.new(0.45, 1, 0.45), CFrame.identity, v623, {
				["transparency"] = 0.05,
				["material"] = nil
			})
			local v654 = p_u_621.pieces
			local v657 = {
				["part"] = v653,
				["place"] = function(p655, p656)
					-- upvalues: (copy) v_u_641, (copy) v_u_652
					return p655 * CFrame.new(v_u_641[v_u_652]) * CFrame.Angles(0, p656 * 3 + v_u_652, 0.7853981633974483)
				end,
				["alpha"] = v653.Transparency
			}
			table.insert(v654, v657)
			local v658 = Instance.new("Attachment")
			v658.Parent = v653
			v651[v_u_652] = v658
		end
		local v_u_659 = {}
		for v660 = 1, 6 do
			local v661 = Instance.new("Beam")
			v661.Attachment0 = v651[v660]
			v661.Attachment1 = v651[v660 % 6 + 1]
			v661.Texture = v_u_12.LightningArc
			v661.TextureMode = Enum.TextureMode.Wrap
			v661.TextureLength = 3
			v661.LightEmission = 0.35
			v661.LightInfluence = 0
			v661.Color = ColorSequence.new(Color3.fromRGB(130, 205, 255), v_u_19(40, 130, 255))
			v661.FaceCamera = true
			v661.Segments = 8
			v661.Parent = v651[v660]
			table.insert(v_u_659, v661)
		end
		local v_u_662 = 0
		local v663 = p_u_621.ticks
		local function v668(_, p664)
			-- upvalues: (ref) v_u_662, (ref) v_u_15, (copy) v_u_659
			if p664 >= v_u_662 then
				v_u_662 = p664 + v_u_15:NextNumber(0.06, 0.11)
				for _, v665 in v_u_659 do
					v665.Enabled = v_u_15:NextNumber() < 0.8
					v665.CurveSize0 = v_u_15:NextNumber(-0.9, 0.9)
					v665.CurveSize1 = v_u_15:NextNumber(-0.9, 0.9)
					local v666 = v_u_15:NextNumber(0.7, 1.2)
					local v667 = v666 * v_u_15:NextNumber(0.6, 1)
					v665.Width0 = v666
					v665.Width1 = v667
					v665.TextureSpeed = v_u_15:NextNumber(2, 5) * (v_u_15:NextNumber() < 0.5 and 1 or -1)
				end
			end
		end
		table.insert(v663, v668)
		local v_u_669 = {}
		local function v679() -- name: addBolt
			-- upvalues: (copy) v_u_622, (ref) v_u_7, (copy) p_u_621, (copy) v_u_669
			local v_u_670 = {
				["parts"] = nil,
				["meshes"] = nil,
				["frames"] = nil,
				["next"] = 0,
				["jitter"] = nil,
				["ends"] = nil,
				["shown"] = false,
				["thick"] = 0.15,
				["parts"] = {},
				["meshes"] = {},
				["frames"] = {},
				["jitter"] = {},
				["ends"] = {}
			}
			for v_u_671 = 1, 3 do
				local v672 = v_u_622
				local v673 = v_u_7.part(Vector3.new(1, 1, 1), CFrame.identity, v672, {
					["transparency"] = 1,
					["material"] = nil
				})
				local v674 = Instance.new("SpecialMesh")
				v674.MeshType = Enum.MeshType.Brick
				v674.Parent = v673
				v_u_670.parts[v_u_671] = v673
				v_u_670.meshes[v_u_671] = v674
				v_u_670.frames[v_u_671] = CFrame.identity
				local v675 = p_u_621.pieces
				local v677 = {
					["part"] = v673,
					["place"] = function(p676)
						-- upvalues: (copy) v_u_670, (copy) v_u_671
						return p676 * v_u_670.frames[v_u_671]
					end,
					["alpha"] = v673.Transparency
				}
				table.insert(v675, v677)
			end
			local v678 = v_u_669
			table.insert(v678, v_u_670)
			return v_u_670
		end
		v679()
		v679()
		local v680 = p_u_621.ticks
		local function v706(_, p681)
			-- upvalues: (copy) v_u_669, (ref) v_u_15, (copy) p_u_621
			for _, v682 in v_u_669 do
				if v682.next <= p681 then
					v682.next = p681 + v_u_15:NextNumber(0.05, 0.12)
					v682.shown = v_u_15:NextNumber() < 0.6
					v682.jitter[1] = v_u_15:NextUnitVector() * v_u_15:NextNumber(0.2, 0.55)
					v682.jitter[2] = v_u_15:NextUnitVector() * v_u_15:NextNumber(0.2, 0.55)
					v682.thick = v_u_15:NextNumber(0.12, 0.22)
					local v683 = v_u_15:NextNumber() * 3.141592653589793 * 2
					local v684 = v_u_15:NextNumber(0.9, 1.6)
					local v685 = math.cos(v683) * v684
					local v686 = v_u_15:NextNumber(p_u_621.feet + 0.6, 1.4)
					local v687 = math.sin(v683) * v684
					local v688 = Vector3.new(v685, v686, v687)
					v682.ends[1] = v688
					local v689 = v682.ends
					local v690 = v_u_15:NextNumber(-1, 1)
					local v691 = v_u_15:NextNumber(1.2, 2.2) * (v_u_15:NextNumber() < 0.5 and 1 or -1)
					local v692 = v_u_15
					v689[2] = v688 + Vector3.new(v690, v691, v692:NextNumber(-1, 1))
				end
				if v682.shown then
					local v693 = v682.ends[1]
					local v694 = v682.ends[2]
					local v695 = {
						v693,
						v693:Lerp(v694, 0.3333333333333333) + v682.jitter[1],
						v693:Lerp(v694, 0.6666666666666666) + v682.jitter[2],
						v694
					}
					for v696 = 1, 3 do
						local v697 = v695[v696]
						local v698 = v695[v696 + 1]
						local v699 = CFrame.lookAt((v697 + v698) / 2, v698)
						local v700 = (v698 - v697).Magnitude
						local v701 = v682.meshes[v696]
						local v702 = v682.thick
						local v703 = v682.thick
						local v704 = v700 + v682.thick
						v701.Scale = Vector3.new(v702, v703, v704)
						v682.parts[v696].Transparency = 0
						v682.frames[v696] = v699
					end
				else
					for _, v705 in v682.parts do
						v705.Transparency = 1
					end
				end
			end
		end
		table.insert(v680, v706)
		local v_u_707 = 0.5
		local v708 = p_u_621.ticks
		local function v712(p709, p710)
			-- upvalues: (ref) v_u_707, (ref) v_u_15, (ref) v_u_7, (copy) v_u_622
			if v_u_707 <= p710 then
				v_u_707 = p710 + v_u_15:NextNumber(0.8, 1.4)
				local v711 = p709 * CFrame.new(v_u_15:NextNumber(-1.5, 1.5), v_u_15:NextNumber(-1.5, 1.5), v_u_15:NextNumber(-1, 1))
				v_u_7.burst("Lightning", v711.Position, v_u_622, 0.5)
			end
		end
		table.insert(v708, v712)
		v_u_260(p_u_621, "AuraMode", Color3.fromRGB(80, 180, 255), {
			["rate"] = 0.55,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = {
				"Glow",
				"Crackle",
				"Pulse",
				"Sparks"
			}
		})
	end,
	["cloak"] = function(p_u_713)
		-- upvalues: (copy) v_u_236, (copy) v_u_7, (copy) v_u_260
		local v714 = Color3.fromRGB(140, 215, 255)
		local v715 = Color3.fromRGB(35, 130, 255)
		local function v_u_720(p716, p717)
			local v718 = CFrame.new
			local v719 = p717 * 2.2
			return p716 * v718(0, math.sin(v719) * 0.15 + 0.2, 0)
		end
		local v_u_721 = {
			["cf"] = CFrame.identity
		}
		local v722 = p_u_713.ticks
		table.insert(v722, function(p723, p724)
			-- upvalues: (copy) v_u_721, (copy) v_u_720
			v_u_721.cf = v_u_720(p723, p724)
		end)
		v_u_236(p_u_713, v_u_721, "BlueWings", 1.15, CFrame.new(0, 0.3, 0.2), true)
		local function v_u_727(p725, p726)
			return p725 * CFrame.new(0, -0.2, 0) * CFrame.Angles(0.22, 0, 0.12) * CFrame.Angles(0, p726 * 0.8, 0)
		end
		local v_u_728 = {
			["cf"] = CFrame.identity
		}
		local v729 = p_u_713.ticks
		table.insert(v729, function(p730, p731)
			-- upvalues: (copy) v_u_728, (copy) v_u_727
			v_u_728.cf = v_u_727(p730, p731)
		end)
		for v732 = 1, 8 do
			local v733 = (v732 - 1) / 8 * 3.141592653589793 * 2
			local v_u_734 = CFrame.new(math.cos(v733) * 2.85, v732 % 2 == 0 and 0.35 or -0.35, math.sin(v733) * 2.85)
			local v735 = v_u_7.part(Vector3.new(0.8, 0.8, 0.8), CFrame.identity, v714, {
				["shape"] = nil,
				["transparency"] = 0,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v736 = p_u_713.pieces
			local v737 = {
				["part"] = v735,
				["place"] = function()
					-- upvalues: (copy) v_u_728, (copy) v_u_734
					return v_u_728.cf * v_u_734
				end,
				["alpha"] = v735.Transparency
			}
			table.insert(v736, v737)
			local v738 = v_u_7.part(Vector3.new(1.3, 1.3, 1.3), CFrame.identity, v715, {
				["shape"] = nil,
				["transparency"] = 0.7,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v739 = p_u_713.pieces
			local v740 = {
				["part"] = v738,
				["place"] = function()
					-- upvalues: (copy) v_u_728, (copy) v_u_734
					return v_u_728.cf * v_u_734
				end,
				["alpha"] = v738.Transparency
			}
			table.insert(v739, v740)
		end
		local function v_u_746(p741, p742)
			-- upvalues: (copy) p_u_713
			local v743 = CFrame.new
			local v744 = p_u_713.headY + p_u_713.eyeLift
			local v745 = p742 * 2
			return p741 * v743(0, v744 + math.sin(v745) * 0.1, 0.35) * CFrame.Angles(0, 0, 0.6108652381980153)
		end
		local v_u_747 = {
			["cf"] = CFrame.identity
		}
		local v748 = p_u_713.ticks
		table.insert(v748, function(p749, p750)
			-- upvalues: (copy) v_u_747, (copy) v_u_746
			v_u_747.cf = v_u_746(p749, p750)
		end)
		local v751 = Vector3.new(0.875, 1.5155444, 0)
		for v752 = 1, 7 do
			local v753 = v752 * 4.188790204786391 / 7 + 1.0471975511965976
			local v754 = math.cos(v753) * 1.75
			local v755 = math.sin(v753) * 1.75
			local v756 = Vector3.new(v754, v755, 0)
			local v_u_757 = CFrame.lookAt((v751 + v756) / 2, v756)
			local v758 = (v756 - v751).Magnitude
			local v759 = 3.141592653589793 * (v752 - 0.5) / 7
			local v760 = math.sin(v759) * 0.36 + 0.16
			local v761 = v758 + 0.14
			local v762 = Vector3.new(v760, v760, v761)
			local v763 = v_u_7.part(v762, CFrame.identity, v714, {
				["transparency"] = 0,
				["material"] = nil
			})
			local v764 = p_u_713.pieces
			local v765 = {
				["part"] = v763,
				["place"] = function()
					-- upvalues: (copy) v_u_747, (copy) v_u_757
					return v_u_747.cf * v_u_757
				end,
				["alpha"] = v763.Transparency
			}
			table.insert(v764, v765)
			v751 = v756
		end
		v_u_260(p_u_713, "AuraMode", Color3.fromRGB(60, 160, 255), {
			["rate"] = 0.55,
			["glow"] = 0.45,
			["only"] = nil,
			["only"] = { "FlameBack", "FlameFront", "Sparks" }
		})
		v_u_260(p_u_713, "Petals", Color3.fromRGB(170, 220, 255), {
			["rate"] = 0.7,
			["glow"] = 0.5,
			["only"] = nil,
			["only"] = { "Motes" }
		})
	end,
	["tentails"] = function(p_u_766)
		-- upvalues: (copy) v_u_236, (copy) v_u_3, (copy) v_u_6, (copy) v_u_163, (copy) v_u_7, (copy) v_u_12, (copy) v_u_260
		local v_u_767 = Color3.fromRGB(225, 20, 35)
		local function v_u_772(p768, p769)
			local v770 = CFrame.new
			local v771 = p769 * 1.1
			return p768 * v770(0, math.sin(v771) * 0.25, 0)
		end
		local v_u_773 = {
			["cf"] = CFrame.identity
		}
		local v774 = p_u_766.ticks
		table.insert(v774, function(p775, p776)
			-- upvalues: (copy) v_u_773, (copy) v_u_772
			v_u_773.cf = v_u_772(p775, p776)
		end)
		local v_u_777 = v_u_236(p_u_766, v_u_773, "SusanooPerfect", 2.4, CFrame.new(-5.4, 3.8, 3))
		if v_u_777 and p_u_766.character == v_u_3.LocalPlayer.Character then
			local v778 = p_u_766.ticks
			local v_u_779 = 0.85
			local function v784(p780)
				-- upvalues: (ref) v_u_6, (copy) v_u_777, (copy) v_u_779
				local v781 = v_u_6.CurrentCamera
				if v781 then
					local v782 = v_u_777
					local v783 = (v781.CFrame.LookVector:Dot(p780.LookVector) + 0.1) * 1.6
					v782.LocalTransparencyModifier = math.clamp(v783, 0, 1) * v_u_779
				end
			end
			table.insert(v778, v784)
		end
		local function v_u_789(p785, p786)
			local v787 = CFrame.new
			local v788 = p786 * 1.6
			return p785 * v787(0, math.sin(v788) * 0.1, 0)
		end
		local v_u_790 = {
			["cf"] = CFrame.identity
		}
		local v791 = p_u_766.ticks
		table.insert(v791, function(p792, p793)
			-- upvalues: (copy) v_u_790, (copy) v_u_789
			v_u_790.cf = v_u_789(p792, p793)
		end)
		local v794 = v_u_236(p_u_766, v_u_790, "TruthOrbsStaffs", 2, CFrame.new(0, 1.2, 0.2), true)
		if not v794 then
			local function v_u_797(p795, p796)
				return p795 * CFrame.new(0, 1.05, 1.6) * CFrame.Angles(0, 0, p796 * 0.5)
			end
			local v_u_798 = {
				["cf"] = CFrame.identity
			}
			local v799 = p_u_766.ticks
			table.insert(v799, function(p800, p801)
				-- upvalues: (copy) v_u_798, (copy) v_u_797
				v_u_798.cf = v_u_797(p800, p801)
			end)
			for v802 = 1, 9 do
				local v803 = (v802 - 1) / 9 * 3.141592653589793 * 2
				local v_u_804 = CFrame.new(math.cos(v803) * 2.75, math.sin(v803) * 2.75, 0)
				v_u_163(p_u_766, function()
					-- upvalues: (copy) v_u_798, (copy) v_u_804
					return v_u_798.cf * v_u_804
				end, v_u_767, 0.95)
			end
		end
		local v_u_805 = p_u_766.character:FindFirstChild("Head")
		if not (v_u_805 and v_u_805:IsA("BasePart")) then
			v_u_805 = nil
		end
		local v_u_806 = not v_u_805 and 1.2 or v_u_805.Size.Y
		local v807 = Color3.fromRGB(238, 232, 218)
		for _, v_u_808 in { -1, 1 } do
			local v809 = Vector3.new(0.3, 0.85, 0.3) * v_u_806
			local v810 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v811 = v_u_7.part(v809, CFrame.identity, v807, v810)
			local v812 = Instance.new("SpecialMesh")
			v812.MeshType = Enum.MeshType.Sphere
			v812.Parent = v811
			local v813 = p_u_766.pieces
			local v816 = {
				["part"] = v811,
				["place"] = function(p814)
					-- upvalues: (copy) v_u_805, (copy) p_u_766, (copy) v_u_808, (copy) v_u_806
					local v815
					if v_u_805 and v_u_805.Parent then
						v815 = v_u_805.CFrame
					else
						v815 = p814 * CFrame.new(0, p_u_766.headY, 0)
					end
					return v815 * CFrame.new(v_u_808 * 0.3 * v_u_806, 0.62 * v_u_806, 0) * CFrame.Angles(0.3, 0, -v_u_808 * 0.3)
				end,
				["alpha"] = v811.Transparency
			}
			table.insert(v813, v816)
			local v817 = Vector3.new(0.2, 0.75, 0.2) * v_u_806
			local v818 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v819 = v_u_7.part(v817, CFrame.identity, v807, v818)
			local v820 = Instance.new("SpecialMesh")
			v820.MeshType = Enum.MeshType.Sphere
			v820.Parent = v819
			local v821 = p_u_766.pieces
			local v824 = {
				["part"] = v819,
				["place"] = function(p822)
					-- upvalues: (copy) v_u_805, (copy) p_u_766, (copy) v_u_808, (copy) v_u_806
					local v823
					if v_u_805 and v_u_805.Parent then
						v823 = v_u_805.CFrame
					else
						v823 = p822 * CFrame.new(0, p_u_766.headY, 0)
					end
					return v823 * CFrame.new(v_u_808 * 0.42 * v_u_806, 1.15 * v_u_806, 0.14 * v_u_806) * CFrame.Angles(0.6, 0, -v_u_808 * 0.15)
				end,
				["alpha"] = v819.Transparency
			}
			table.insert(v821, v824)
		end
		if not v794 then
			local function v_u_829(p825, p826)
				local v827 = CFrame.new
				local v828 = p826 * 1.4
				return p825 * v827(2.45, math.sin(v828) * 0.15 + -0.2, 0.2) * CFrame.Angles(0, p826 * 0.6, 0.13962634015954636)
			end
			local v_u_830 = {
				["cf"] = CFrame.identity
			}
			local v831 = p_u_766.ticks
			table.insert(v831, function(p832, p833)
				-- upvalues: (copy) v_u_830, (copy) v_u_829
				v_u_830.cf = v_u_829(p832, p833)
			end)
			local v834 = Color3.fromRGB(20, 16, 22)
			local v835 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v836 = v_u_7.part(Vector3.new(0.2, 4.8, 0.2), CFrame.identity, v834, v835)
			v836.Reflectance = 0.2
			local v_u_837 = CFrame.identity
			local v838 = p_u_766.pieces
			local v839 = {
				["part"] = v836,
				["place"] = function()
					-- upvalues: (copy) v_u_830, (copy) v_u_837
					return v_u_830.cf * v_u_837
				end,
				["alpha"] = v836.Transparency
			}
			table.insert(v838, v839)
			local v840 = Enum.Material.SmoothPlastic
			local v841 = v_u_7.part(Vector3.new(0.16, 1.15, 1.15), CFrame.identity, v834, {
				["shape"] = nil,
				["transparency"] = 0,
				["material"] = nil,
				["shape"] = Enum.PartType.Cylinder,
				["material"] = v840
			})
			local v_u_842 = CFrame.new(0, 2.75, 0)
			local v843 = p_u_766.pieces
			local v844 = {
				["part"] = v841,
				["place"] = function()
					-- upvalues: (copy) v_u_830, (copy) v_u_842
					return v_u_830.cf * v_u_842
				end,
				["alpha"] = v841.Transparency
			}
			table.insert(v843, v844)
			local v845 = v_u_7.part(Vector3.new(0.42, 0.42, 0.42), CFrame.identity, v_u_767, {
				["shape"] = nil,
				["transparency"] = 0,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v_u_846 = CFrame.new(0, 2.75, 0)
			local v847 = p_u_766.pieces
			local v848 = {
				["part"] = v845,
				["place"] = function()
					-- upvalues: (copy) v_u_830, (copy) v_u_846
					return v_u_830.cf * v_u_846
				end,
				["alpha"] = v845.Transparency
			}
			table.insert(v847, v848)
		end
		local v_u_849 = 2
		local v850 = p_u_766.ticks
		local v_u_851 = 4
		local v_u_852 = 4
		local function v855(p853, p854)
			-- upvalues: (ref) v_u_849, (copy) v_u_851, (ref) v_u_7, (copy) v_u_767, (copy) v_u_852, (copy) p_u_766, (ref) v_u_12
			if v_u_849 <= p854 then
				v_u_849 = p854 + v_u_851
				v_u_7.ring(p853.Position + Vector3.new(0, -0.8, 0), v_u_767, v_u_852 * p_u_766.fx, 0.5, v_u_12.Ring)
			end
		end
		table.insert(v850, v855)
		v_u_260(p_u_766, "AuraMode", Color3.fromRGB(190, 10, 30), {
			["rate"] = 0.5,
			["glow"] = 0.3,
			["only"] = nil,
			["only"] = {
				"FlameBack",
				"FlameFront",
				"Crackle",
				"Sparks"
			}
		})
	end,
	["garden"] = function(p_u_856)
		-- upvalues: (copy) v_u_236, (copy) v_u_7, (copy) v_u_19, (copy) v_u_15, (copy) v_u_6, (copy) v_u_260
		local function v_u_858(p857)
			return p857
		end
		local v_u_859 = {
			["cf"] = CFrame.identity
		}
		local v860 = p_u_856.ticks
		table.insert(v860, function(p861, p862)
			-- upvalues: (copy) v_u_859, (copy) v_u_858
			v_u_859.cf = v_u_858(p861, p862)
		end)
		v_u_236(p_u_856, v_u_859, "MerlinStaff", 1.3, nil, true)
		for v_u_863 = 1, 8 do
			local v864 = Color3.new(1, 1, 1)
			local v_u_865 = v_u_7.part(Vector3.new(0.5, 1.3, 0.5), CFrame.identity, v864, {
				["transparency"] = 0,
				["material"] = nil
			})
			local v866 = p_u_856.pieces
			local v875 = {
				["part"] = v_u_865,
				["place"] = function(p867, p868)
					-- upvalues: (copy) v_u_863
					local v869 = (v_u_863 - 1) / 8 * 3.141592653589793 * 2 + p868 * 0.7
					local v870 = math.cos(v869) * 2.8
					local v871 = p868 * 1.5 + v_u_863
					local v872 = math.sin(v871) * 0.35 + -0.3
					local v873 = math.sin(v869) * 2.8
					local v874 = Vector3.new(v870, v872, v873)
					return p867 * CFrame.new(v874) * CFrame.Angles(0, p868 * 2 + v_u_863, 0.3490658503988659)
				end,
				["alpha"] = v_u_865.Transparency
			}
			table.insert(v866, v875)
			local v876 = p_u_856.ticks
			table.insert(v876, function(_, p877)
				-- upvalues: (copy) v_u_865, (copy) v_u_863
				v_u_865.Color = Color3.fromHSV((v_u_863 / 8 + p877 * 0.12) % 1, 0.8, 1)
			end)
		end
		local v_u_878 = {
			Color3.fromRGB(255, 80, 165),
			Color3.fromRGB(255, 190, 40),
			Color3.fromRGB(165, 100, 255),
			Color3.fromRGB(70, 190, 255),
			v_u_19(255, 120, 80)
		}
		local v_u_879 = {}
		for _ = 1, 4 do
			local v_u_880 = {
				["anchor"] = nil,
				["born"] = -10,
				["scale"] = 0,
				["parts"] = nil,
				["anchor"] = CFrame.identity,
				["parts"] = {}
			}
			for v881 = 1, 5 do
				local v882 = v_u_878[1]
				local v883 = v_u_7.part(Vector3.new(0.7, 0.14, 1.3), CFrame.identity, v882, {
					["transparency"] = 1,
					["material"] = nil
				})
				local v884 = Instance.new("SpecialMesh")
				v884.MeshType = Enum.MeshType.Sphere
				v884.Parent = v883
				local v885 = v_u_880.parts
				table.insert(v885, v883)
				local v_u_886 = (v881 - 1) / 5 * 3.141592653589793 * 2
				local v887 = p_u_856.pieces
				local v888 = {
					["part"] = v883,
					["place"] = function()
						-- upvalues: (copy) v_u_880, (copy) v_u_886
						return v_u_880.anchor * CFrame.Angles(0, v_u_886, 0) * CFrame.new(0, 0.1, v_u_880.scale * -0.6) * CFrame.Angles(0.3141592653589793, 0, 0)
					end,
					["alpha"] = v883.Transparency
				}
				table.insert(v887, v888)
			end
			local v889 = Color3.fromRGB(255, 215, 60)
			local v890 = v_u_7.part(Vector3.new(0.5, 0.5, 0.5), CFrame.identity, v889, {
				["transparency"] = 1,
				["material"] = nil
			})
			local v891 = Instance.new("SpecialMesh")
			v891.MeshType = Enum.MeshType.Sphere
			v891.Parent = v890
			local v892 = v_u_880.parts
			table.insert(v892, v890)
			local v893 = p_u_856.pieces
			local v894 = {
				["part"] = v890,
				["place"] = function()
					-- upvalues: (copy) v_u_880
					return v_u_880.anchor * CFrame.new(0, 0.18, 0)
				end,
				["alpha"] = v890.Transparency
			}
			table.insert(v893, v894)
			table.insert(v_u_879, v_u_880)
		end
		local v_u_895 = RaycastParams.new()
		v_u_895.FilterType = Enum.RaycastFilterType.Exclude
		v_u_895.FilterDescendantsInstances = { p_u_856.character }
		local v_u_896 = 0.3
		local v_u_897 = 0
		local v898 = p_u_856.ticks
		local function v928(p899, p900)
			-- upvalues: (ref) v_u_896, (copy) p_u_856, (ref) v_u_897, (copy) v_u_879, (ref) v_u_15, (ref) v_u_6, (copy) v_u_895, (copy) v_u_878
			if v_u_896 <= p900 then
				local v901 = p_u_856.root.AssemblyLinearVelocity.Magnitude > 4
				v_u_896 = p900 + (v901 and 0.35 or 0.8)
				v_u_897 = v_u_897 % #v_u_879 + 1
				local v902 = v_u_879[v_u_897]
				local v903
				if v901 then
					local v904 = v_u_15:NextNumber(-0.8, 0.8)
					local v905 = v_u_15
					v903 = Vector3.new(v904, 0, v905:NextNumber(-0.8, 0.8))
				else
					local v906 = v_u_15:NextNumber(0, 6.283185307179586)
					local v907 = v_u_15:NextNumber(1.3, 2.6)
					local v908 = math.cos(v906) * v907
					local v909 = math.sin(v906) * v907
					v903 = Vector3.new(v908, 0, v909)
				end
				local v910 = p899.Position + v903
				local v911 = v_u_6
				local v912 = p_u_856.feet - 3
				local v913 = v911:Raycast(v910, Vector3.new(0, v912, 0), v_u_895)
				local v914
				if v913 then
					v914 = v913.Position
				else
					local v915 = p_u_856.feet
					v914 = v910 + Vector3.new(0, v915, 0)
				end
				v902.anchor = CFrame.new(v914) * CFrame.Angles(0, v_u_15:NextNumber(0, 6.283185307179586), 0)
				v902.born = p900
				local v916 = v_u_878[v_u_15:NextInteger(1, #v_u_878)]
				v902.parts[1].Color = v916
				v902.parts[2].Color = v916
				v902.parts[3].Color = v916
				v902.parts[4].Color = v916
				v902.parts[5].Color = v916
			end
			for _, v917 in v_u_879 do
				local v918 = p900 - v917.born
				if v918 > 2.2 then
					continue
				end
				local v919 = v918 / 0.35
				local v920 = math.clamp(v919, 0, 1)
				local v921 = 1 - (1 - v920) ^ 3
				local v922 = v920 * 3.141592653589793
				v917.scale = v921 * (math.sin(v922) * 0.2 + 1)
				local v923
				if v918 > 2 then
					v923 = 1
				else
					local v924 = (v918 - 1.3) / 0.7
					v923 = math.clamp(v924, 0, 1) * 0.95 + 0.05
				end
				for _, v925 in v917.parts do
					v925.Transparency = v923
					local v926 = v925:FindFirstChildOfClass("SpecialMesh")
					if not v926 then
						continue
					end
					local v927 = v917.scale
					v926.Scale = Vector3.new(1, 1, 1) * math.max(v927, 0.01)
				end
			end
		end
		table.insert(v898, v928)
		local v929 = v_u_260(p_u_856, "Petals", Color3.fromRGB(255, 215, 120), {
			["rate"] = 1,
			["glow"] = 0.6
		})
		if v929 then
			v929 = v929:FindFirstChild("Petals")
		end
		if v929 and v929:IsA("ParticleEmitter") then
			local v930 = {}
			for v931 = 0, 5 do
				local v932 = ColorSequenceKeypoint.new
				local v933 = v931 / 5
				local v934 = Color3.fromHSV
				local v935 = v931 / 6
				table.insert(v930, v932(v933, v934(v935, 0.5, 1)))
			end
			v929.Color = ColorSequence.new(v930)
		end
		v_u_260(p_u_856, "AuraMode", Color3.fromRGB(255, 210, 90), {
			["rate"] = 0.4,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Glow", "Sparks" }
		})
	end,
	["lotus"] = function(p_u_936)
		-- upvalues: (copy) v_u_312, (copy) v_u_7, (copy) v_u_94, (copy) v_u_260
		local v937 = Color3.fromRGB(255, 105, 185)
		local v938 = Color3.fromRGB(255, 165, 220)
		local v939 = Color3.fromRGB(255, 205, 80)
		v_u_312(p_u_936, "PriestessCirclet", 1.1)
		local function v_u_945(p940, p941)
			-- upvalues: (copy) p_u_936
			local v942 = CFrame.new
			local v943 = p940.Position
			local v944 = p_u_936.feet + 0.3
			return v942(v943 + Vector3.new(0, v944, 0)) * CFrame.Angles(0, p941 * 0.35, 0)
		end
		local v_u_946 = {
			["cf"] = CFrame.identity
		}
		local v947 = p_u_936.ticks
		table.insert(v947, function(p948, p949)
			-- upvalues: (copy) v_u_946, (copy) v_u_945
			v_u_946.cf = v_u_945(p948, p949)
		end)
		local function v976(p950, p951, p952, p_u_953, p954, p955, p956, p957, p958) -- name: petals
			-- upvalues: (copy) p_u_936, (ref) v_u_7, (copy) v_u_946
			for v959 = 1, p950 do
				local v960 = (v959 - 1 + p957) / p950 * 3.141592653589793 * 2
				local v961 = math.cos(v960)
				local v962 = math.sin(v960)
				local v_u_963 = Vector3.new(v961, 0, v962)
				local v_u_964 = v_u_963 * p951 + Vector3.new(0, p954, 0)
				local v965 = p_u_936
				local v966 = v_u_7.part(p952, CFrame.identity, p955, {
					["transparency"] = p956,
					["material"] = p958
				})
				local v967 = Instance.new("SpecialMesh")
				v967.MeshType = Enum.MeshType.Sphere
				v967.Parent = v966
				local function v973(_, p968)
					-- upvalues: (copy) p_u_953, (ref) v_u_946, (copy) v_u_964, (copy) v_u_963
					local v969 = p_u_953
					local v970 = p968 * 1.4
					local v971 = v969 + math.sin(v970) * 5
					local v972 = math.rad(v971)
					return v_u_946.cf * CFrame.lookAt(v_u_964, v_u_964 + v_u_963) * CFrame.Angles(v972, 0, 0)
				end
				local v974 = v965.pieces
				local v975 = {
					["part"] = v966,
					["place"] = v973,
					["alpha"] = v966.Transparency
				}
				table.insert(v974, v975)
			end
		end
		v976(8, 1.45, Vector3.new(1, 0.3, 2.1), 26, 0, v937, 0, 0, Enum.Material.SmoothPlastic)
		v976(6, 0.85, Vector3.new(0.75, 0.24, 1.5), 55, 0.25, v938, 0.05, 0.5, Enum.Material.Neon)
		local function v_u_979(p977, p978)
			return p977 * CFrame.new(0, 0.3, 0) * CFrame.Angles(0.1, -p978 * 0.6, 0)
		end
		local v_u_980 = {
			["cf"] = CFrame.identity
		}
		local v981 = p_u_936.ticks
		table.insert(v981, function(p982, p983)
			-- upvalues: (copy) v_u_980, (copy) v_u_979
			v_u_980.cf = v_u_979(p982, p983)
		end)
		v_u_94(p_u_936, v_u_980, 12, 2.3, 0.14, v939, 0.05)
		for v984 = 1, 4 do
			local v985 = (v984 - 1) / 4 * 3.141592653589793 * 2
			local v986 = math.cos(v985)
			local v987 = math.sin(v985)
			local v988 = Vector3.new(v986, 0, v987)
			local v989 = v988 * 2.3 + Vector3.new(0, -0.5, 0)
			local v990 = Color3.fromRGB(255, 248, 230)
			local v991 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v992 = v_u_7.part(Vector3.new(0.5, 0.85, 0.05), CFrame.identity, v990, v991)
			local v_u_993 = CFrame.lookAt(v989, v989 + v988)
			local v994 = p_u_936.pieces
			local v995 = {
				["part"] = v992,
				["place"] = function()
					-- upvalues: (copy) v_u_980, (copy) v_u_993
					return v_u_980.cf * v_u_993
				end,
				["alpha"] = v992.Transparency
			}
			table.insert(v994, v995)
			local v996 = Color3.fromRGB(220, 30, 40)
			local v997 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v998 = v_u_7.part(Vector3.new(0.12, 0.55, 0.07), CFrame.identity, v996, v997)
			local v_u_999 = CFrame.lookAt(v989, v989 + v988)
			local v1000 = p_u_936.pieces
			local v1001 = {
				["part"] = v998,
				["place"] = function()
					-- upvalues: (copy) v_u_980, (copy) v_u_999
					return v_u_980.cf * v_u_999
				end,
				["alpha"] = v998.Transparency
			}
			table.insert(v1000, v1001)
		end
		local v1002 = Color3.fromRGB(255, 240, 205)
		local v1003 = v_u_7.part(Vector3.new(9, 3.6, 3.6), CFrame.identity, v1002, {
			["shape"] = nil,
			["transparency"] = 0.93,
			["material"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v1004 = p_u_936.pieces
		local v1009 = {
			["part"] = v1003,
			["place"] = function(p1005)
				-- upvalues: (copy) p_u_936
				local v1006 = CFrame.new
				local v1007 = p1005.Position
				local v1008 = p_u_936.feet + 4.5
				return v1006(v1007 + Vector3.new(0, v1008, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
			end,
			["alpha"] = v1003.Transparency
		}
		table.insert(v1004, v1009)
		v_u_260(p_u_936, "Petals", Color3.fromRGB(255, 150, 210), {
			["rate"] = 1,
			["glow"] = 0.5,
			["only"] = nil,
			["only"] = { "Petals", "Motes" }
		})
		v_u_260(p_u_936, "AuraMode", Color3.fromRGB(255, 210, 110), {
			["rate"] = 0.5,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Streaks" }
		})
	end,
	["domain"] = function(p1010)
		-- upvalues: (copy) v_u_7, (copy) v_u_260
		local v1011 = Color3.fromRGB(70, 150, 255)
		local v1012 = Color3.fromRGB(255, 45, 60)
		local v_u_1013 = Color3.fromRGB(175, 70, 255)
		local v1014 = v_u_7.part(Vector3.new(7.4, 7.4, 7.4), CFrame.identity, Color3.fromRGB(80, 175, 255), {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.1,
			["shape"] = Enum.PartType.Ball,
			["material"] = Enum.Material.ForceField
		})
		local v1015 = p1010.pieces
		local v1018 = {
			["part"] = v1014,
			["place"] = function(p1016, p1017)
				return p1016 * CFrame.new(0, -0.3, 0) * CFrame.Angles(0, p1017 * 0.3, 0)
			end,
			["alpha"] = v1014.Transparency
		}
		table.insert(v1015, v1018)
		local v_u_1019 = v_u_7.part(Vector3.new(0.95, 0.95, 0.95), CFrame.identity, v1011, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v1020 = Color3.fromRGB(40, 110, 255)
		local v_u_1021 = v_u_7.part(Vector3.new(1.7, 1.7, 1.7), CFrame.identity, v1020, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v_u_1022 = v_u_7.part(Vector3.new(0.95, 0.95, 0.95), CFrame.identity, v1012, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v1023 = Color3.fromRGB(255, 30, 45)
		local v_u_1024 = v_u_7.part(Vector3.new(1.7, 1.7, 1.7), CFrame.identity, v1023, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v_u_1025 = v_u_7.part(Vector3.new(1.6, 1.6, 1.6), CFrame.identity, v_u_1013, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v1026 = Color3.fromRGB(140, 40, 255)
		local v_u_1027 = v_u_7.part(Vector3.new(2.8, 2.8, 2.8), CFrame.identity, v1026, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v_u_1028 = Vector3.new(0, 0.6, 0)
		local v_u_1029 = Vector3.new(0, 0.6, 0)
		local v_u_1030 = -1
		local v1031 = p1010.ticks
		local function v1058(p1032, p1033)
			-- upvalues: (ref) v_u_1028, (ref) v_u_1029, (copy) v_u_1019, (copy) v_u_1022, (copy) v_u_1021, (copy) v_u_1024, (copy) v_u_1025, (copy) v_u_1027, (ref) v_u_1030, (ref) v_u_7, (copy) v_u_1013
			local v1034 = p1033 % 7
			local v1035 = 0
			if v1034 > 4.6 and v1034 <= 5.4 then
				local v1036 = (v1034 - 4.6) / 0.8
				v1035 = v1036 * v1036
			elseif v1034 > 5.4 and v1034 <= 6.6 then
				v1035 = 1
			elseif v1034 > 6.6 then
				v1035 = 1 - (v1034 - 6.6) / 0.4
			end
			local v1037 = p1033 * 1.8
			local v1038 = (1 - v1035) * 2.4
			local v1039 = (Vector3.new(0, 0.6, 0)):Lerp(Vector3.new(0, 0.6, -2.6), v1035)
			local v1040 = p1033 * 2
			local v1041 = math.sin(v1040) * 0.2
			local v1042 = math.cos(v1037) * v1038
			local v1043 = math.sin(v1037) * v1038
			v_u_1028 = v1039 + Vector3.new(v1042, v1041, v1043)
			local v1044 = -math.cos(v1037) * v1038
			local v1045 = -v1041
			local v1046 = -math.sin(v1037) * v1038
			v_u_1029 = v1039 + Vector3.new(v1044, v1045, v1046)
			local v1047
			if v1034 > 5.4 then
				v1047 = v1034 <= 6.6
			else
				v1047 = false
			end
			v_u_1019.Transparency = v1047 and 1 or 0
			v_u_1022.Transparency = v1047 and 1 or 0
			v_u_1021.Transparency = v1047 and 1 or 0.7
			v_u_1024.Transparency = v1047 and 1 or 0.7
			if v1047 then
				local v1048 = (v1034 - 5.4) / 0.2
				local v1049 = math.min(v1048, 1)
				local v1050 = p1033 * 12
				local v1051 = v1049 * (math.sin(v1050) * 0.06 + 1)
				local v1052 = v_u_1025
				local v1053 = v1051 * 1.6
				v1052.Size = Vector3.new(1, 1, 1) * math.max(v1053, 0.05)
				local v1054 = v_u_1027
				local v1055 = v1051 * 2.8
				v1054.Size = Vector3.new(1, 1, 1) * math.max(v1055, 0.05)
				v_u_1025.Transparency = 0
				v_u_1027.Transparency = 0.6
				local v1056 = p1033 / 7
				local v1057 = math.floor(v1056)
				if v_u_1030 ~= v1057 then
					v_u_1030 = v1057
					v_u_7.flash((p1032 * CFrame.new(Vector3.new(0, 0.6, -2.6))).Position, v_u_1013, 4, 0.3)
					return
				end
			else
				v_u_1025.Transparency = 1
				v_u_1027.Transparency = 1
			end
		end
		table.insert(v1031, v1058)
		local v_u_1059 = v_u_1029
		local v_u_1060 = v_u_1028
		for _, v1061 in { v_u_1019, v_u_1021 } do
			local v1062 = p1010.pieces
			local v1064 = {
				["part"] = v1061,
				["place"] = function(p1063)
					-- upvalues: (ref) v_u_1060
					return p1063 * CFrame.new(v_u_1060)
				end,
				["alpha"] = v1061.Transparency
			}
			table.insert(v1062, v1064)
		end
		for _, v1065 in { v_u_1022, v_u_1024 } do
			local v1066 = p1010.pieces
			local v1068 = {
				["part"] = v1065,
				["place"] = function(p1067)
					-- upvalues: (ref) v_u_1059
					return p1067 * CFrame.new(v_u_1059)
				end,
				["alpha"] = v1065.Transparency
			}
			table.insert(v1066, v1068)
		end
		for _, v1069 in { v_u_1025, v_u_1027 } do
			local v1070 = p1010.pieces
			local v1072 = {
				["part"] = v1069,
				["place"] = function(p1071)
					return p1071 * CFrame.new(Vector3.new(0, 0.6, -2.6))
				end,
				["alpha"] = v1069.Transparency
			}
			table.insert(v1070, v1072)
		end
		v_u_260(p1010, "Petals", Color3.fromRGB(170, 215, 255), {
			["rate"] = 1.4,
			["glow"] = 0.8,
			["only"] = nil,
			["only"] = { "Motes" }
		})
		v_u_260(p1010, "AuraMode", Color3.fromRGB(80, 170, 255), {
			["rate"] = 0.5,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Glow", "Sparks", "Pulse" }
		})
	end,
	["divine"] = function(p_u_1073)
		-- upvalues: (copy) v_u_236, (copy) v_u_94, (copy) v_u_7, (copy) v_u_322, (copy) v_u_12, (copy) v_u_337, (copy) v_u_15, (copy) v_u_260
		local v1074 = Color3.fromRGB(255, 200, 60)
		local v1075 = Color3.fromRGB(255, 235, 150)
		local function v_u_1080(p1076, p1077)
			local v1078 = CFrame.new
			local v1079 = p1077 * 1.8
			return p1076 * v1078(0, math.sin(v1079) * 0.15 + 0.2, 0)
		end
		local v_u_1081 = {
			["cf"] = CFrame.identity
		}
		local v1082 = p_u_1073.ticks
		table.insert(v1082, function(p1083, p1084)
			-- upvalues: (copy) v_u_1081, (copy) v_u_1080
			v_u_1081.cf = v_u_1080(p1083, p1084)
		end)
		v_u_236(p_u_1073, v_u_1081, "AngelWings", 1.2, CFrame.new(0, 0.3, 0.3), true)
		local function v_u_1087(p1085, p1086)
			-- upvalues: (copy) p_u_1073
			return p1085 * CFrame.new(0, p_u_1073.headY + 0.1, 0.85) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, p1086 * 0.4, 0)
		end
		local v_u_1088 = {
			["cf"] = CFrame.identity
		}
		local v1089 = p_u_1073.ticks
		table.insert(v1089, function(p1090, p1091)
			-- upvalues: (copy) v_u_1088, (copy) v_u_1087
			v_u_1088.cf = v_u_1087(p1090, p1091)
		end)
		v_u_94(p_u_1073, v_u_1088, 16, 1.4, 0.2, v1074, 0)
		local function v_u_1094(p1092, p1093)
			-- upvalues: (copy) p_u_1073
			return p1092 * CFrame.new(0, p_u_1073.headY + 0.1, 0.9) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, -p1093 * 0.25, 0)
		end
		local v_u_1095 = {
			["cf"] = CFrame.identity
		}
		local v1096 = p_u_1073.ticks
		table.insert(v1096, function(p1097, p1098)
			-- upvalues: (copy) v_u_1095, (copy) v_u_1094
			v_u_1095.cf = v_u_1094(p1097, p1098)
		end)
		for v1099 = 1, 10 do
			local v1100 = (v1099 - 1) / 10 * 3.141592653589793 * 2
			local v1101 = v1099 % 2 == 0 and 0.7 or 1.2
			local v1102 = math.cos(v1100)
			local v1103 = math.sin(v1100)
			local v1104 = Vector3.new(v1102, 0, v1103)
			local v1105 = v1104 * (v1101 / 2 + 1.75)
			local v1106 = Vector3.new(0.12, 0.12, v1101)
			local v1107 = v_u_7.part(v1106, CFrame.identity, v1075, {
				["transparency"] = 0.3,
				["material"] = nil
			})
			local v_u_1108 = CFrame.lookAt(v1105, v1105 + v1104)
			local v1109 = p_u_1073.pieces
			local v1110 = {
				["part"] = v1107,
				["place"] = function()
					-- upvalues: (copy) v_u_1095, (copy) v_u_1108
					return v_u_1095.cf * v_u_1108
				end,
				["alpha"] = v1107.Transparency
			}
			table.insert(v1109, v1110)
		end
		for v_u_1111 = 1, 5 do
			local v_u_1112 = Instance.new("BillboardGui")
			v_u_1112.Name = "DivineEye"
			v_u_1112.Size = UDim2.fromScale(1.5, 1.5)
			v_u_1112.Adornee = p_u_1073.root
			v_u_1112.LightInfluence = 0
			v_u_1112.Brightness = 1.2
			v_u_1112.MaxDistance = 200
			v_u_1112.ResetOnSpawn = false
			v_u_322(v_u_1112, v_u_12.Glow, 1.3, 1, v1074, 0.45).Size = UDim2.fromScale(1.6, 1.3)
			local v_u_1113 = v_u_337(v_u_1112, 0.95, v1074)
			v_u_1112.Parent = p_u_1073.root
			v_u_1112:SetAttribute("FormExtra", true)
			local v1114 = p_u_1073.extras
			table.insert(v1114, v_u_1112)
			local v1115 = p_u_1073.stops
			table.insert(v1115, function()
				-- upvalues: (copy) v_u_1112
				v_u_1112:Destroy()
			end)
			local v_u_1116 = v_u_15:NextNumber(1, 5)
			local v1117 = p_u_1073.ticks
			local function v1129(p1118, p1119)
				-- upvalues: (copy) v_u_1111, (copy) v_u_1112, (ref) v_u_1116, (ref) v_u_15, (copy) v_u_1113
				local v1120 = (v_u_1111 - 1) / 5 * 3.141592653589793 * 2 + p1119 * 0.5
				local v1121 = math.cos(v1120) * 2.9
				local v1122 = p1119 * 1.3 + v_u_1111
				local v1123 = math.sin(v1122) * 0.7 + 0.2
				local v1124 = math.sin(v1120) * 2.9
				v_u_1112.StudsOffsetWorldSpace = p1118:VectorToWorldSpace((Vector3.new(v1121, v1123, v1124)))
				local v1125 = p1119 - v_u_1116
				if v1125 > 0.18 then
					v_u_1116 = p1119 + v_u_15:NextNumber(2.5, 6)
					v_u_1113.Size = UDim2.fromScale(0.95, 0.53)
				elseif v1125 > 0 then
					local v1126 = v_u_1113
					local v1127 = UDim2.fromScale
					local v1128 = 1 - v1125 / 0.09
					v1126.Size = v1127(0.95, math.abs(v1128) * 0.53)
				end
			end
			table.insert(v1117, v1129)
		end
		local v_u_1130 = 1
		local v1131 = p_u_1073.ticks
		local function v1137(p1132, p1133)
			-- upvalues: (ref) v_u_1130, (ref) v_u_7, (copy) p_u_1073
			if v_u_1130 <= p1133 then
				v_u_1130 = p1133 + 2.2
				local v1134 = v_u_7.burst
				local v1135 = p1132.Position
				local v1136 = p_u_1073.headY + 0.3
				v1134("Sparkle", v1135 + Vector3.new(0, v1136, 0), nil, 0.5)
			end
		end
		table.insert(v1131, v1137)
		v_u_260(p_u_1073, "AuraMode", v1074, {
			["rate"] = 0.6,
			["glow"] = 0.7,
			["only"] = nil,
			["only"] = { "Glow", "Streaks", "Sparks" }
		})
	end,
	["otsutsuki"] = function(p_u_1138)
		-- upvalues: (copy) v_u_7, (ref) v_u_238, (copy) v_u_12, (copy) v_u_260
		local v1139 = Color3.fromRGB(236, 230, 252)
		local v_u_1140 = Color3.fromRGB(190, 165, 250)
		local v_u_1141 = Color3.fromRGB(120, 70, 235)
		local v1142 = Color3.fromRGB(24, 20, 34)
		local v1143 = p_u_1138.character:FindFirstChild("Head")
		local v_u_1144 = not (v1143 and v1143:IsA("BasePart")) and 1.2 or v1143.Size.Y
		local v_u_1145 = p_u_1138.character:FindFirstChild("Head")
		if not (v_u_1145 and v_u_1145:IsA("BasePart")) then
			v_u_1145 = nil
		end
		local function v_u_1147(p1146)
			-- upvalues: (copy) v_u_1145, (copy) p_u_1138
			if v_u_1145 and v_u_1145.Parent then
				return v_u_1145.CFrame
			else
				return p1146 * CFrame.new(0, p_u_1138.headY, 0)
			end
		end
		local v1148 = Vector3.new(0.4, 1.15, 0.4) * v_u_1144
		local v1149 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v1150 = v_u_7.part(v1148, CFrame.identity, v1139, v1149)
		local v1151 = Instance.new("SpecialMesh")
		v1151.MeshType = Enum.MeshType.Sphere
		v1151.Parent = v1150
		local v1152 = p_u_1138.pieces
		local v1154 = {
			["part"] = v1150,
			["place"] = function(p1153)
				-- upvalues: (copy) v_u_1147, (copy) v_u_1144
				return v_u_1147(p1153) * CFrame.new(0.2 * v_u_1144, 0.85 * v_u_1144, -0.3 * v_u_1144) * CFrame.Angles(0.2, 0, -0.18)
			end,
			["alpha"] = v1150.Transparency
		}
		table.insert(v1152, v1154)
		local v1155 = Vector3.new(0.26, 1, 0.26) * v_u_1144
		local v1156 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v1157 = v_u_7.part(v1155, CFrame.identity, v1139, v1156)
		local v1158 = Instance.new("SpecialMesh")
		v1158.MeshType = Enum.MeshType.Sphere
		v1158.Parent = v1157
		local v1159 = p_u_1138.pieces
		local v1161 = {
			["part"] = v1157,
			["place"] = function(p1160)
				-- upvalues: (copy) v_u_1147, (copy) v_u_1144
				return v_u_1147(p1160) * CFrame.new(0.37 * v_u_1144, 1.7 * v_u_1144, -0.05 * v_u_1144) * CFrame.Angles(0.6, 0, -0.3)
			end,
			["alpha"] = v1157.Transparency
		}
		table.insert(v1159, v1161)
		local function v_u_1164(p1162, p1163)
			return p1162 * CFrame.new(0, -0.3, 0) * CFrame.Angles(0.18, 0, -0.1) * CFrame.Angles(0, -p1163 * 0.7, 0)
		end
		local v_u_1165 = {
			["cf"] = CFrame.identity
		}
		local v1166 = p_u_1138.ticks
		table.insert(v1166, function(p1167, p1168)
			-- upvalues: (copy) v_u_1165, (copy) v_u_1164
			v_u_1165.cf = v_u_1164(p1167, p1168)
		end)
		for v_u_1169 = 1, 6 do
			local v1170 = (v_u_1169 - 1) / 6 * 3.141592653589793 * 2
			local v1171 = v_u_1169 % 2 == 1
			local v1172 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v1173 = v_u_7.part(v1171 and Vector3.new(0.32, 1.7, 0.32) or Vector3.new(0.75, 0.75, 0.75), CFrame.identity, v1142, v1172)
			v1173.Reflectance = 0.2
			local v1174 = v_u_7.part(v1171 and Vector3.new(0.6, 2, 0.6) or Vector3.new(1.05, 1.05, 1.05), CFrame.identity, v_u_1141, {
				["transparency"] = 0.45,
				["material"] = nil
			})
			local v_u_1175 = {}
			local v1176 = Instance.new("SpecialMesh")
			v1176.MeshType = Enum.MeshType.Brick
			v1176.Parent = v1173
			local v1177 = Instance.new("SpecialMesh")
			v1177.MeshType = Enum.MeshType.Brick
			v1177.Parent = v1174
			__set_list(v_u_1175, 1, {v1176, v1177})
			local v_u_1178 = CFrame.new(math.cos(v1170) * 2.65, 0, math.sin(v1170) * 2.65)
			local function v_u_1180(_, p1179) -- name: place
				-- upvalues: (copy) v_u_1165, (copy) v_u_1178, (copy) v_u_1169
				return v_u_1165.cf * v_u_1178 * CFrame.Angles(p1179 * 0.8 + v_u_1169, p1179 * 1.2, 0.3)
			end
			local v1181 = p_u_1138.pieces
			local v1182 = {
				["part"] = v1173,
				["place"] = v_u_1180,
				["alpha"] = v1173.Transparency
			}
			table.insert(v1181, v1182)
			local v_u_1183 = 0.3
			local function v1188(p1184, p1185)
				-- upvalues: (copy) v_u_1180, (ref) v_u_238, (copy) v_u_1183
				local v1186 = v_u_1180(p1184, p1185)
				local v1187 = v1186.Position - v_u_238
				if v1187.Magnitude < 0.01 then
					return v1186
				else
					return v1186 + v1187.Unit * v_u_1183
				end
			end
			local v1189 = p_u_1138.pieces
			local v1190 = {
				["part"] = v1174,
				["place"] = v1188,
				["alpha"] = v1174.Transparency
			}
			table.insert(v1189, v1190)
			local v1191 = p_u_1138.ticks
			table.insert(v1191, function(_, p1192)
				-- upvalues: (copy) v_u_1169, (copy) v_u_1175
				local v1193 = p1192 * 2.3 + v_u_1169 * 1.7
				local v1194 = (math.sin(v1193) * 0.5 + 0.5) * 0.8 + 0.3
				for _, v1195 in v_u_1175 do
					v1195.Scale = Vector3.new(1, 1, 1) * v1194
				end
			end)
		end
		local function v_u_1201(p1196, p1197)
			-- upvalues: (copy) p_u_1138
			local v1198 = CFrame.new
			local v1199 = p_u_1138.headY + 0.45
			local v1200 = p1197 * 1.3
			return p1196 * v1198(1.95, v1199 + math.sin(v1200) * 0.15, 1.2) * CFrame.Angles(p1197 * 0.4, p1197 * 0.55, 0.6)
		end
		local v_u_1202 = {
			["cf"] = CFrame.identity
		}
		local v1203 = p_u_1138.ticks
		table.insert(v1203, function(p1204, p1205)
			-- upvalues: (copy) v_u_1202, (copy) v_u_1201
			v_u_1202.cf = v_u_1201(p1204, p1205)
		end)
		local v1206 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v1207 = v_u_7.part(Vector3.new(1.5, 1.5, 1.5), CFrame.identity, v1142, v1206)
		v1207.Reflectance = 0.2
		local v1208 = v_u_7.part(Vector3.new(1.85, 1.85, 1.85), CFrame.identity, v_u_1141, {
			["transparency"] = 0.5,
			["material"] = nil
		})
		local v_u_1209 = {}
		local v1210 = Instance.new("SpecialMesh")
		v1210.MeshType = Enum.MeshType.Brick
		v1210.Parent = v1207
		local v1211 = Instance.new("SpecialMesh")
		v1211.MeshType = Enum.MeshType.Brick
		v1211.Parent = v1208
		__set_list(v_u_1209, 1, {v1210, v1211})
		local v_u_1212 = CFrame.identity
		local v1213 = p_u_1138.pieces
		local v1214 = {
			["part"] = v1207,
			["place"] = function()
				-- upvalues: (copy) v_u_1202, (copy) v_u_1212
				return v_u_1202.cf * v_u_1212
			end,
			["alpha"] = v1207.Transparency
		}
		table.insert(v1213, v1214)
		local function v_u_1215()
			-- upvalues: (copy) v_u_1202
			return v_u_1202.cf
		end
		local v_u_1216 = 0.35
		local function v1221(p1217, p1218)
			-- upvalues: (copy) v_u_1215, (ref) v_u_238, (copy) v_u_1216
			local v1219 = v_u_1215(p1217, p1218)
			local v1220 = v1219.Position - v_u_238
			if v1220.Magnitude < 0.01 then
				return v1219
			else
				return v1219 + v1220.Unit * v_u_1216
			end
		end
		local v1222 = p_u_1138.pieces
		local v1223 = {
			["part"] = v1208,
			["place"] = v1221,
			["alpha"] = v1208.Transparency
		}
		table.insert(v1222, v1223)
		local v_u_1224 = -1
		local v1225 = p_u_1138.ticks
		local function v1236(_, p1226)
			-- upvalues: (ref) v_u_1224, (ref) v_u_7, (copy) v_u_1202, (copy) v_u_1141, (copy) v_u_1209
			local v1227 = p1226 / 6
			local v1228 = math.floor(v1227)
			local v1229 = p1226 - v1228 * 6
			local v1230 = 1
			if v1229 > 4.5 and v1229 <= 4.9 then
				local v1231 = (v1229 - 4.5) / 0.4
				v1230 = 1 - 0.94 * v1231 * v1231
			elseif v1229 > 4.9 and v1229 <= 5.1 then
				v1230 = 0.06
			elseif v1229 > 5.1 and v1229 <= 5.6 then
				local v1232 = (v1229 - 5.1) / 0.5
				local v1233 = 0.06 + 0.94 * v1232
				local v1234 = v1232 * 3.141592653589793
				v1230 = v1233 + math.sin(v1234) * 0.35
				if v_u_1224 ~= v1228 then
					v_u_1224 = v1228
					v_u_7.flash(v_u_1202.cf.Position, v_u_1141, 3.2, 0.3)
				end
			end
			for _, v1235 in v_u_1209 do
				v1235.Scale = Vector3.new(1, 1, 1) * v1230
			end
		end
		table.insert(v1225, v1236)
		local function v_u_1242(p1237, p1238)
			-- upvalues: (copy) p_u_1138
			local v1239 = CFrame.new
			local v1240 = p_u_1138.headY - 0.2
			local v1241 = p1238 * 1.1 + 1
			return p1237 * v1239(-1.85, v1240 + math.sin(v1241) * 0.15, 1.25) * CFrame.Angles(0.15, 0, 0.3839724354387525)
		end
		local v_u_1243 = {
			["cf"] = CFrame.identity
		}
		local v1244 = p_u_1138.ticks
		table.insert(v1244, function(p1245, p1246)
			-- upvalues: (copy) v_u_1243, (copy) v_u_1242
			v_u_1243.cf = v_u_1242(p1245, p1246)
		end)
		local v1247 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v1248 = v_u_7.part(Vector3.new(0.36, 3.3, 0.36), CFrame.identity, v1142, v1247)
		v1248.Reflectance = 0.2
		local v_u_1249 = CFrame.identity
		local v1250 = p_u_1138.pieces
		local v1251 = {
			["part"] = v1248,
			["place"] = function()
				-- upvalues: (copy) v_u_1243, (copy) v_u_1249
				return v_u_1243.cf * v_u_1249
			end,
			["alpha"] = v1248.Transparency
		}
		table.insert(v1250, v1251)
		local v1252 = v_u_7.part(Vector3.new(0.65, 3.6, 0.65), CFrame.identity, v_u_1141, {
			["transparency"] = 0.5,
			["material"] = nil
		})
		local function v_u_1253()
			-- upvalues: (copy) v_u_1243
			return v_u_1243.cf
		end
		local v_u_1254 = 0.25
		local function v1259(p1255, p1256)
			-- upvalues: (copy) v_u_1253, (ref) v_u_238, (copy) v_u_1254
			local v1257 = v_u_1253(p1255, p1256)
			local v1258 = v1257.Position - v_u_238
			if v1258.Magnitude < 0.01 then
				return v1257
			else
				return v1257 + v1258.Unit * v_u_1254
			end
		end
		local v1260 = p_u_1138.pieces
		local v1261 = {
			["part"] = v1252,
			["place"] = v1259,
			["alpha"] = v1252.Transparency
		}
		table.insert(v1260, v1261)
		local v_u_1262 = 2
		local v1263 = p_u_1138.ticks
		local v_u_1264 = 4
		local v_u_1265 = 4
		local function v1268(p1266, p1267)
			-- upvalues: (ref) v_u_1262, (copy) v_u_1264, (ref) v_u_7, (copy) v_u_1140, (copy) v_u_1265, (copy) p_u_1138, (ref) v_u_12
			if v_u_1262 <= p1267 then
				v_u_1262 = p1267 + v_u_1264
				v_u_7.ring(p1266.Position + Vector3.new(0, -0.8, 0), v_u_1140, v_u_1265 * p_u_1138.fx, 0.5, v_u_12.Ring)
			end
		end
		table.insert(v1263, v1268)
		v_u_260(p_u_1138, "AuraMode", Color3.fromRGB(165, 130, 250), {
			["rate"] = 0.6,
			["glow"] = 0.3,
			["only"] = nil,
			["only"] = { "FlameBack", "Streaks", "Sparks" }
		})
		v_u_260(p_u_1138, "Petals", v1139, {
			["rate"] = 0.6,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Motes" }
		})
	end,
	["blood"] = function(p_u_1269)
		-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_236, (copy) v_u_312, (copy) v_u_179, (ref) v_u_237, (copy) v_u_216, (copy) v_u_163, (copy) v_u_291, (copy) v_u_260
		local v1270 = Color3.fromRGB(120, 0, 18)
		local v_u_1271 = Color3.fromRGB(255, 28, 52)
		local v_u_1272 = Color3.fromRGB(225, 0, 30)
		local v1273 = Color3.fromRGB(90, 0, 14)
		local v_u_1274 = 0
		local v_u_1275 = 0.4
		local v_u_1276 = (1 / 0)
		local v1277 = p_u_1269.ticks
		local function v1286(p1278, p1279, p1280)
			-- upvalues: (ref) v_u_1275, (ref) v_u_1276, (ref) v_u_1274, (ref) v_u_7, (copy) p_u_1269, (copy) v_u_1271, (ref) v_u_12, (copy) v_u_1272
			if v_u_1275 <= p1279 then
				v_u_1275 = p1279 + 1.5
				v_u_1276 = p1279 + 0.26
				v_u_1274 = 1
				local v1281 = v_u_7.ring
				local v1282 = p1278.Position
				local v1283 = p_u_1269.feet + 0.15
				v1281(v1282 + Vector3.new(0, v1283, 0), v_u_1271, 5.5 * p_u_1269.fx, 0.55, v_u_12.Shockwave)
			elseif v_u_1276 <= p1279 then
				v_u_1276 = (1 / 0)
				local v1284 = v_u_1274
				v_u_1274 = math.max(v1284, 0.7)
				v_u_7.ring(p1278.Position + Vector3.new(0, -0.6, 0), v_u_1272, 3 * p_u_1269.fx, 0.4, v_u_12.Ring)
			end
			local v1285 = v_u_1274 - p1280 * 4
			v_u_1274 = math.max(v1285, 0)
			p_u_1269.pulse = v_u_1274
		end
		table.insert(v1277, v1286)
		v_u_236(p_u_1269, nil, "SusanooArmsRed", 1.15, nil, true)
		v_u_312(p_u_1269, "JinMoriHaloRed", 1.1)
		local v1287 = v_u_179("DemonWings", 0.72)
		if v1287 then
			local v_u_1288 = CFrame.new(Vector3.new(0, 1.25, 0.95) * v_u_237) * CFrame.Angles(0.12, 3.141592653589793, 0)
			v_u_216(p_u_1269, v1287, function(p1289)
				-- upvalues: (copy) v_u_1288
				return p1289 * v_u_1288
			end)
		end
		local v_u_1290 = v_u_1274
		for v_u_1291 = 1, 6 do
			local v_u_1292 = (v_u_1291 - 1) / 6 * 3.141592653589793 * 2
			local v1299 = v_u_163(p_u_1269, function(p1293, p1294)
				-- upvalues: (copy) v_u_1292, (ref) v_u_1290, (copy) v_u_1291
				local v1295 = v_u_1292 + p1294 * 1
				local v1296 = v_u_1290 * 0.45 + 2.7
				local v1297 = p1294 * 1.7 + v_u_1291 * 1.05
				local v1298 = math.sin(v1297) * 0.85 + -0.3
				return p1293 * CFrame.new(math.cos(v1295) * v1296, v1298, math.sin(v1295) * v1296)
			end, v_u_1272, 0.85, v1270, 0.3)
			v1299.Reflectance = 0.12
			local v_u_1300 = Instance.new("Attachment")
			v_u_1300.Name = "BloodThread"
			v_u_1300.CFrame = CFrame.new(0, 0.6, 0) * CFrame.Angles(0, v_u_1292, 1.2217304763960306)
			v_u_1300.Parent = p_u_1269.root
			v_u_1300:SetAttribute("FormExtra", true)
			local v1301 = p_u_1269.extras
			table.insert(v1301, v_u_1300)
			local v1302 = Instance.new("Attachment")
			v1302.Parent = v1299
			local v1303 = Instance.new("Beam")
			v1303.Attachment0 = v_u_1300
			v1303.Attachment1 = v1302
			v1303.Texture = v_u_12.BloodThread
			v1303.TextureMode = Enum.TextureMode.Wrap
			v1303.TextureLength = 3
			v1303.TextureSpeed = 1.4
			v1303.LightEmission = 0.25
			v1303.LightInfluence = 0
			v1303.Color = ColorSequence.new(v_u_1271)
			v1303.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.3), NumberSequenceKeypoint.new(0.25, 0), NumberSequenceKeypoint.new(1, 0) })
			v1303.Width0 = 0.6
			v1303.Width1 = 1.4
			v1303.CurveSize0 = 2.2
			v1303.CurveSize1 = 0.8
			v1303.Segments = 12
			v1303.FaceCamera = true
			v1303.Parent = v_u_1300
			local v1304 = p_u_1269.stops
			table.insert(v1304, function()
				-- upvalues: (copy) v_u_1300
				v_u_1300:Destroy()
			end)
		end
		local v_u_1305 = 0
		local v_u_1306 = 1.2
		local v_u_1307 = -10
		local v1308 = p_u_1269.ticks
		local function v1313(p1309, p1310)
			-- upvalues: (ref) v_u_1306, (ref) v_u_1307, (ref) v_u_7, (copy) v_u_1271, (copy) p_u_1269, (ref) v_u_12, (ref) v_u_1305
			if v_u_1306 <= p1310 then
				v_u_1306 = p1310 + 3
				v_u_1307 = p1310
				v_u_7.ring(p1309.Position + Vector3.new(0, 0.45, 0), v_u_1271, 5 * p_u_1269.fx, 0.3, v_u_12.Ring)
			end
			local v1311 = p1310 - v_u_1307
			if v1311 < 0.12 then
				v_u_1305 = v1311 / 0.12
				return
			elseif v1311 < 0.3 then
				v_u_1305 = 1
				return
			elseif v1311 < 1 then
				local v1312 = (v1311 - 0.3) / 0.7
				v_u_1305 = 1 - v1312 * v1312 * (3 - 2 * v1312)
			else
				v_u_1305 = 0
			end
		end
		table.insert(v1308, v1313)
		local v_u_1314 = v_u_1305
		for v_u_1315 = 1, 6 do
			local v_u_1316 = (v_u_1315 - 1) / 6 * 3.141592653589793 * 2
			local v1317 = v_u_7.part(Vector3.new(0.15, 0.15, 1.7), CFrame.identity, v_u_1271, {
				["transparency"] = 0,
				["material"] = nil
			})
			local v1318 = Instance.new("SpecialMesh")
			v1318.MeshType = Enum.MeshType.Sphere
			v1318.Parent = v1317
			local v1319 = p_u_1269.pieces
			local v1332 = {
				["part"] = v1317,
				["place"] = function(p1320, p1321)
					-- upvalues: (copy) v_u_1316, (ref) v_u_1314, (copy) v_u_1315
					local v1322 = v_u_1316 - p1321 * 0.45
					local v1323 = math.cos(v1322)
					local v1324 = math.sin(v1322)
					local v1325 = Vector3.new(v1323, 0, v1324)
					local v1326 = v_u_1314 * 2.5 + 2.1
					local v1327 = p1321 * 3 + v_u_1315
					local v1328 = v1325 * (v1326 + math.sin(v1327) * 0.08)
					local v1329 = p1321 * 2 + v_u_1315
					local v1330 = math.sin(v1329) * 0.15 + 0.45
					local v1331 = v1328 + Vector3.new(0, v1330, 0)
					return p1320 * CFrame.lookAt(v1331, v1331 + v1325)
				end,
				["alpha"] = v1317.Transparency
			}
			table.insert(v1319, v1332)
		end
		local v1333 = p_u_1269.feet + 0.1
		local v1334 = Vector3.new(0, v1333, 0)
		v_u_291(p_u_1269, v_u_1271, 2, 1.5, p_u_1269.feet + 0.12)
		v_u_260(p_u_1269, "FireDark", nil, {
			["only"] = nil,
			["paint"] = nil,
			["at"] = nil,
			["rate"] = 0.5,
			["only"] = { "Rim", "Flames" },
			["paint"] = Color3.fromRGB(150, 0, 22),
			["at"] = v1334
		})
		v_u_260(p_u_1269, "FireDark", nil, {
			["only"] = nil,
			["paint"] = nil,
			["at"] = nil,
			["rate"] = 1,
			["only"] = { "Stain", "Smoke", "Embers" },
			["paint"] = v1273,
			["at"] = v1334
		})
		v_u_260(p_u_1269, "AuraMode", v_u_1271, {
			["rate"] = 0.45,
			["glow"] = 0.35,
			["only"] = nil,
			["only"] = { "FlameBack", "Sparks" }
		})
	end,
	["six_paths"] = function(p_u_1335)
		-- upvalues: (copy) v_u_312, (copy) v_u_236, (copy) v_u_163, (copy) v_u_291, (copy) v_u_7, (copy) v_u_12, (copy) v_u_260
		local v1336 = Color3.fromRGB(255, 196, 40)
		local v_u_1337 = Color3.fromRGB(255, 130, 0)
		v_u_312(p_u_1335, "KcmTorso", 1)
		v_u_312(p_u_1335, "KcmLeftArm", 1)
		v_u_312(p_u_1335, "KcmRightArm", 1)
		if not v_u_236(p_u_1335, nil, "SixPathsOrbs", 1, nil, true) then
			for v1338 = 1, 6 do
				local v1339 = (v1338 - 1) * 30 + 15
				local v_u_1340 = math.rad(v1339)
				v_u_163(p_u_1335, function(p1341, p1342)
					-- upvalues: (copy) v_u_1340
					local v1343 = v_u_1340
					local v1344 = p1342 * 0.8
					local v1345 = v1343 + math.sin(v1344) * 0.1
					return p1341 * CFrame.new(math.cos(v1345) * 2.6, math.sin(v1345) * 2.6 + 0.45, 1.45)
				end, v1336, 1.05)
			end
		end
		v_u_291(p_u_1335, v1336, 2, 1.8, p_u_1335.feet + 0.12)
		local v_u_1346 = 1.3
		local v1347 = p_u_1335.ticks
		local v_u_1348 = 2.6
		local v_u_1349 = 7
		local function v1352(p1350, p1351)
			-- upvalues: (ref) v_u_1346, (copy) v_u_1348, (ref) v_u_7, (copy) v_u_1337, (copy) v_u_1349, (copy) p_u_1335, (ref) v_u_12
			if v_u_1346 <= p1351 then
				v_u_1346 = p1351 + v_u_1348
				v_u_7.ring(p1350.Position + Vector3.new(0, -0.8, 0), v_u_1337, v_u_1349 * p_u_1335.fx, 0.5, v_u_12.Ring)
			end
		end
		table.insert(v1347, v1352)
		v_u_260(p_u_1335, "AuraMode", v1336, {
			["rate"] = 0.75,
			["glow"] = 0.55,
			["only"] = nil,
			["only"] = {
				"Glow",
				"FlameBack",
				"FlameFront",
				"Streaks",
				"Sparks"
			}
		})
		v_u_260(p_u_1335, "AuraMode", v_u_1337, {
			["rate"] = 0.6,
			["glow"] = 0.5,
			["only"] = nil,
			["only"] = { "Crackle" }
		})
		v_u_260(p_u_1335, "Petals", v1336, {
			["rate"] = 0.8,
			["glow"] = 0.6,
			["only"] = nil,
			["only"] = { "Motes" }
		})
	end
}
local function v_u_1362(p1354, p1355, p1356, p1357) -- name: picture
	-- upvalues: (copy) v_u_7
	local v1358 = v_u_7.part(Vector3.new(p1354, 0.05, p1354), CFrame.identity, p1356, {
		["transparency"] = 1
	})
	local v1359 = {}
	for _, v1360 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v1361 = Instance.new("Decal")
		v1361.Face = v1360
		v1361.Texture = p1355
		v1361.Color3 = p1356
		v1361.Transparency = p1357 or 0
		v1361.Parent = v1358
		table.insert(v1359, v1361)
	end
	return v1358, v1359
end
local function v_u_1368(p1363, p1364, p1365) -- name: bothFaces
	for _, v1366 in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local v1367 = Instance.new("Decal")
		v1367.Face = v1366
		v1367.Texture = p1364
		v1367.Color3 = p1365
		v1367.Parent = p1363
	end
end
local function v_u_1379(p1369, p1370, p1371, p1372, p1373) -- name: tail
	local v1374 = Instance.new("Attachment")
	local v1375 = p1372 / 2
	v1374.Position = Vector3.new(0, v1375, 0)
	v1374.Parent = p1369
	local v1376 = Instance.new("Attachment")
	local v1377 = -p1372 / 2
	v1376.Position = Vector3.new(0, v1377, 0)
	v1376.Parent = p1369
	local v1378 = Instance.new("Trail")
	v1378.Attachment0 = v1374
	v1378.Attachment1 = v1376
	v1378.Color = ColorSequence.new(p1370, p1371)
	v1378.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v1378.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.2) })
	v1378.Lifetime = p1373
	v1378.LightEmission = 0.5
	v1378.LightInfluence = 0
	v1378.FaceCamera = true
	v1378.MinLength = 0.05
	v1378.Parent = p1369
	return v1378
end
local function v_u_1387(p1380, p1381, p1382, p1383, p1384, p1385) -- name: ray
	local v1386 = Instance.new("Beam")
	v1386.Attachment0 = p1380
	v1386.Attachment1 = p1381
	v1386.Color = ColorSequence.new(p1382)
	v1386.Width0 = p1383
	v1386.Width1 = p1384
	v1386.LightEmission = 0.6
	v1386.LightInfluence = 0
	v1386.FaceCamera = true
	v1386.Segments = 1
	if p1385 then
		v1386.Texture = p1385
		v1386.TextureMode = Enum.TextureMode.Wrap
		v1386.TextureLength = 4
		v1386.TextureSpeed = 1.2
	end
	v1386.Parent = p1380
	return v1386
end
local function v_u_1389(p1388) -- name: hue
	return Color3.fromHSV(p1388 % 1, 0.72, 1)
end
function v_u_1353.w2_beast_gaze(p_u_1390, p1391)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_1362, (copy) v_u_236, (copy) v_u_260
	local v_u_1392 = v_u_7.color(p1391.color)
	local v1393 = v_u_7.color(p1391.color2)
	local v1394 = v_u_1392:Lerp(Color3.fromRGB(255, 120, 0), 0.45)
	local function v_u_1400(p1395)
		-- upvalues: (ref) v_u_7, (copy) p_u_1390, (copy) v_u_1392, (ref) v_u_12
		local v1396 = v_u_7.ring
		local v1397 = p_u_1390
		local v1398 = p1395.Position
		local v1399 = v1397.feet + 0.15
		v1396(v1398 + Vector3.new(0, v1399, 0), v_u_1392, 5, 0.45, v_u_12.Shockwave)
	end
	local v_u_1401 = 0
	local v_u_1402 = 1.2
	local v1403 = p_u_1390.ticks
	local v_u_1404 = 3.2
	local v_u_1405 = 2.2
	local function v1410(p1406, p1407, p1408)
		-- upvalues: (ref) v_u_1402, (copy) v_u_1404, (ref) v_u_1401, (copy) v_u_1400, (ref) v_u_238, (copy) v_u_1405, (copy) p_u_1390
		if v_u_1402 <= p1407 then
			v_u_1402 = p1407 + v_u_1404
			v_u_1401 = 1
			if v_u_1400 and (p1406.Position - v_u_238).Magnitude < 150 then
				v_u_1400(p1406)
			end
		end
		local v1409 = v_u_1401 - p1408 * v_u_1405
		v_u_1401 = math.max(v1409, 0)
		p_u_1390.pulse = v_u_1401
	end
	table.insert(v1403, v1410)
	local function v_u_1411()
		-- upvalues: (ref) v_u_1401
		return v_u_1401
	end
	local function v_u_1418(p1412, p1413)
		-- upvalues: (copy) p_u_1390
		local v1414 = CFrame.new
		local v1415 = p_u_1390
		local v1416 = p1412.Position
		local v1417 = v1415.feet + 3.2
		return v1414(v1416 + Vector3.new(0, v1417, 0)) * CFrame.Angles(0, p1413 * 0.3, 0)
	end
	local v_u_1419 = {
		["cf"] = CFrame.identity
	}
	local v1420 = p_u_1390.ticks
	table.insert(v1420, function(p1421, p1422)
		-- upvalues: (copy) v_u_1419, (copy) v_u_1418
		v_u_1419.cf = v_u_1418(p1421, p1422)
	end)
	for v_u_1423 = 1, 8 do
		local v_u_1424 = (v_u_1423 - 0.5) / 8 * 3.141592653589793 * 2
		local v1425 = v_u_7.part(Vector3.new(0.17, 6.2, 0.17), CFrame.identity, v_u_1392, {
			["transparency"] = 0.1,
			["material"] = nil
		})
		local v1426 = p_u_1390.pieces
		local v1434 = {
			["part"] = v1425,
			["place"] = function(_, p1427)
				-- upvalues: (copy) v_u_1411, (copy) v_u_1423, (copy) v_u_1419, (copy) v_u_1424
				local v1428 = v_u_1411()
				local v1429 = 2.7 + v1428 * 0.55
				local v1430 = p1427 * 42 + v_u_1423 * 2
				local v1431 = v1429 + math.sin(v1430) * 0.08 * v1428
				local v1432 = v_u_1424
				local v1433 = v_u_1424
				return v_u_1419.cf * CFrame.new(math.cos(v1432) * v1431, 0, math.sin(v1433) * v1431)
			end,
			["alpha"] = v1425.Transparency
		}
		table.insert(v1426, v1434)
	end
	local v_u_1435 = {}
	for _, v1436 in { -3.1, 3.1 } do
		local v1437 = v_u_1362(5.6, v_u_12.Ring, v1393, 0.1)
		table.insert(v_u_1435, v1437)
		local v_u_1438 = CFrame.new(0, v1436, 0)
		local v1439 = p_u_1390.pieces
		local v1440 = {
			["part"] = v1437,
			["place"] = function()
				-- upvalues: (copy) v_u_1419, (copy) v_u_1438
				return v_u_1419.cf * v_u_1438
			end,
			["alpha"] = v1437.Transparency
		}
		table.insert(v1439, v1440)
	end
	local v1441 = p_u_1390.ticks
	table.insert(v1441, function()
		-- upvalues: (copy) v_u_1411, (copy) v_u_1435
		local v1442 = 5.6 + v_u_1411() * 1.1
		for _, v1443 in v_u_1435 do
			v1443.Size = Vector3.new(v1442, 0.05, v1442)
		end
	end)
	local function v_u_1453(p1444, p1445)
		-- upvalues: (copy) v_u_1411
		local v1446 = v_u_1411()
		local v1447 = p1444 * CFrame.new(0, -0.2, 0)
		local v1448 = CFrame.Angles
		local v1449 = -0.12 * v1446
		local v1450 = p1445 * 1.6
		local v1451 = math.sin(v1450) * 0.12
		local v1452 = p1445 * 2.1
		return v1447 * v1448(v1449, v1451, math.sin(v1452) * 0.06)
	end
	local v_u_1454 = {
		["cf"] = CFrame.identity
	}
	local v1455 = p_u_1390.ticks
	table.insert(v1455, function(p1456, p1457)
		-- upvalues: (copy) v_u_1454, (copy) v_u_1453
		v_u_1454.cf = v_u_1453(p1456, p1457)
	end)
	for v_u_1458 = 1, v_u_236(p_u_1390, v_u_1454, "KuramaTails", 1.05, CFrame.new(0, -0.6, 0.3), true) and 0 or 3 do
		local v_u_1459 = (v_u_1458 - 2) * 0.6
		local v_u_1460 = {
			CFrame.identity,
			CFrame.identity,
			CFrame.identity,
			CFrame.identity
		}
		local v1461 = p_u_1390.ticks
		table.insert(v1461, function(_, p1462)
			-- upvalues: (copy) v_u_1411, (copy) v_u_1459, (copy) v_u_1458, (copy) v_u_1460
			local v1463 = 1 + v_u_1411() * 0.8
			local v1464 = Vector3.new(0, -0.7, 0.75)
			for v1465 = 1, 4 do
				local v1466 = v_u_1459
				local v1467 = p1462 * 2.4 + v_u_1458 * 1.3 + v1465 * 0.7
				local v1468 = v1466 + math.sin(v1467) * 0.16 * v1465 * v1463
				local v1469 = v1465 * 0.3 + 0.1
				local v1470 = p1462 * 1.9 + v_u_1458 + v1465
				local v1471 = v1469 + math.sin(v1470) * 0.08
				local v1472 = math.sin(v1468) * math.cos(v1471)
				local v1473 = math.sin(v1471)
				local v1474 = math.cos(v1468) * math.cos(v1471)
				local v1475 = v1464 + Vector3.new(v1472, v1473, v1474) * 1
				v_u_1460[v1465] = CFrame.lookAt((v1464 + v1475) / 2, v1475)
				v1464 = v1475
			end
		end)
		for v_u_1476 = 1, 4 do
			local v1477 = 1.05 - v_u_1476 * 0.15
			local v1478 = Vector3.new(v1477, v1477, 1.3)
			local v1479
			if v_u_1476 == 4 then
				v1479 = v1393
			elseif v_u_1476 == 1 then
				v1479 = v1394
			else
				v1479 = v_u_1392
			end
			local v1480 = v_u_7.part(v1478, CFrame.identity, v1479, {
				["transparency"] = 0.1,
				["material"] = nil
			})
			local v1481 = Instance.new("SpecialMesh")
			v1481.MeshType = Enum.MeshType.Sphere
			v1481.Parent = v1480
			local v1482 = p_u_1390.pieces
			local v1484 = {
				["part"] = v1480,
				["place"] = function(p1483)
					-- upvalues: (copy) v_u_1460, (copy) v_u_1476
					return p1483 * v_u_1460[v_u_1476]
				end,
				["alpha"] = v1480.Transparency
			}
			table.insert(v1482, v1484)
		end
	end
	local v1485 = p_u_1390.character:FindFirstChild("Head")
	local v_u_1486 = not (v1485 and v1485:IsA("BasePart")) and 1.2 or v1485.Size.Y
	local v_u_1487 = p_u_1390.character:FindFirstChild("Head")
	if not (v_u_1487 and v_u_1487:IsA("BasePart")) then
		v_u_1487 = nil
	end
	local function v_u_1489(p1488)
		-- upvalues: (copy) v_u_1487, (copy) p_u_1390
		if v_u_1487 and v_u_1487.Parent then
			return v_u_1487.CFrame
		else
			return p1488 * CFrame.new(0, p_u_1390.headY, 0)
		end
	end
	for _, v_u_1490 in { -1, 1 } do
		local v1491 = Vector3.new(0.34, 0.95, 0.22) * v_u_1486
		local v1492 = v_u_7.part(v1491, CFrame.identity, v_u_1392, {
			["transparency"] = 0.05,
			["material"] = nil
		})
		local v1493 = Instance.new("SpecialMesh")
		v1493.MeshType = Enum.MeshType.Sphere
		v1493.Parent = v1492
		local v1494 = p_u_1390.pieces
		local v1496 = {
			["part"] = v1492,
			["place"] = function(p1495)
				-- upvalues: (copy) v_u_1489, (copy) v_u_1490, (copy) v_u_1486, (copy) v_u_1411
				return v_u_1489(p1495) * CFrame.new(v_u_1490 * 0.42 * v_u_1486, 0.78 * v_u_1486, 0.05 * v_u_1486) * CFrame.Angles(0, 0, -v_u_1490 * (0.35 + v_u_1411() * 0.2))
			end,
			["alpha"] = v1492.Transparency
		}
		table.insert(v1494, v1496)
	end
	v_u_260(p_u_1390, "AuraMode", v_u_1392, {
		["rate"] = 0.55,
		["glow"] = 0.55,
		["only"] = nil,
		["only"] = { "FlameBack", "FlameFront", "Sparks" }
	})
end
function v_u_1353.w2_violet_halo(p_u_1497, p1498)
	-- upvalues: (copy) v_u_7, (copy) v_u_94, (copy) v_u_1362, (copy) v_u_12, (copy) v_u_260
	local v1499 = v_u_7.color(p1498.color)
	local v1500 = v_u_7.color(p1498.color2)
	p_u_1497.eyeLift = 3.3
	local function v_u_1506(p1501, p1502)
		-- upvalues: (copy) p_u_1497
		local v1503 = CFrame.new
		local v1504 = p_u_1497.headY + 1.05
		local v1505 = p1502 * 2
		return p1501 * v1503(0, v1504 + math.sin(v1505) * 0.06, 0.1) * CFrame.Angles(-0.24434609527920614, 0, 0) * CFrame.Angles(0, p1502 * 0.8, 0)
	end
	local v_u_1507 = {
		["cf"] = CFrame.identity
	}
	local v1508 = p_u_1497.ticks
	table.insert(v1508, function(p1509, p1510)
		-- upvalues: (copy) v_u_1507, (copy) v_u_1506
		v_u_1507.cf = v_u_1506(p1509, p1510)
	end)
	v_u_94(p_u_1497, v_u_1507, 12, 1.1, 0.22, v1500, 0)
	local function v_u_1522(p1511, p1512)
		-- upvalues: (copy) p_u_1497
		local v1513 = p1512 * 3.141592653589793 / 2.5
		local v1514 = 0.5 - math.cos(v1513) * 0.5
		local v1515 = p_u_1497.feet + 0.6 + v1514 * (p_u_1497.headY + 0.4 - p_u_1497.feet - 0.6)
		local v1516 = CFrame.new(p1511.Position + Vector3.new(0, v1515, 0)) * p1511.Rotation
		local v1517 = CFrame.Angles
		local v1518 = p1512 * 1.3
		local v1519 = math.sin(v1518) * 0.18
		local v1520 = p1512 * 0.6
		local v1521 = p1512 * 1.1
		return v1516 * v1517(v1519, v1520, math.cos(v1521) * 0.12)
	end
	local v_u_1523 = {
		["cf"] = CFrame.identity
	}
	local v1524 = p_u_1497.ticks
	table.insert(v1524, function(p1525, p1526)
		-- upvalues: (copy) v_u_1523, (copy) v_u_1522
		v_u_1523.cf = v_u_1522(p1525, p1526)
	end)
	v_u_94(p_u_1497, v_u_1523, 12, 3, 0.26, v1499, 0.05)
	local v1527 = v_u_1362(6.9, v_u_12.Ring, v1500, 0.35)
	local v_u_1528 = CFrame.identity
	local v1529 = p_u_1497.pieces
	local v1530 = {
		["part"] = v1527,
		["place"] = function()
			-- upvalues: (copy) v_u_1523, (copy) v_u_1528
			return v_u_1523.cf * v_u_1528
		end,
		["alpha"] = v1527.Transparency
	}
	table.insert(v1529, v1530)
	for v1531 = 1, 2 do
		local v1532 = CFrame.new
		local v1533 = v1531 * 3.141592653589793
		local v1534 = math.cos(v1533) * 3
		local v1535 = v1531 * 3.141592653589793
		local v_u_1536 = v1532(v1534, 0, math.sin(v1535) * 3)
		local v1537 = Color3.fromRGB(255, 255, 255)
		local v1538 = v_u_7.part(Vector3.new(0.55, 0.55, 0.55), CFrame.identity, v1537, {
			["shape"] = nil,
			["transparency"] = 0,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v1539 = p_u_1497.pieces
		local v1540 = {
			["part"] = v1538,
			["place"] = function()
				-- upvalues: (copy) v_u_1523, (copy) v_u_1536
				return v_u_1523.cf * v_u_1536
			end,
			["alpha"] = v1538.Transparency
		}
		table.insert(v1539, v1540)
		local v1541 = v_u_7.part(Vector3.new(1.15, 1.15, 1.15), CFrame.identity, v1499, {
			["shape"] = nil,
			["transparency"] = 0.55,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v1542 = p_u_1497.pieces
		local v1543 = {
			["part"] = v1541,
			["place"] = function()
				-- upvalues: (copy) v_u_1523, (copy) v_u_1536
				return v_u_1523.cf * v_u_1536
			end,
			["alpha"] = v1541.Transparency
		}
		table.insert(v1542, v1543)
	end
	v_u_260(p_u_1497, "Petals", v1500, {
		["rate"] = 1,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Motes" }
	})
	v_u_260(p_u_1497, "AuraMode", v1499, {
		["rate"] = 0.5,
		["glow"] = 0.5,
		["only"] = nil,
		["only"] = { "Glow", "Streaks", "Sparks" }
	})
end
function v_u_1353.w2_venom_tomoe(p_u_1544, p1545)
	-- upvalues: (copy) v_u_7, (ref) v_u_238, (copy) v_u_1379, (copy) v_u_15, (copy) v_u_12, (copy) v_u_260
	local v_u_1546 = v_u_7.color(p1545.color)
	local v1547 = v_u_7.color(p1545.color2)
	local v_u_1548 = 0
	local function v_u_1550(p1549)
		return p1549 * CFrame.new(0, -0.25, 0) * CFrame.Angles(0.25, 0, -0.12)
	end
	local v_u_1551 = {
		["cf"] = CFrame.identity
	}
	local v1552 = p_u_1544.ticks
	table.insert(v1552, function(p1553, p1554)
		-- upvalues: (copy) v_u_1551, (copy) v_u_1550
		v_u_1551.cf = v_u_1550(p1553, p1554)
	end)
	local v1555 = p_u_1544.ticks
	local function v1557(_, _, p1556)
		-- upvalues: (ref) v_u_1548
		v_u_1548 = v_u_1548 + p1556 * 1.7
	end
	table.insert(v1555, v1557)
	local v_u_1558 = v_u_1548
	for v1559 = 1, 3 do
		local v_u_1560 = (v1559 - 1) / 3 * 3.141592653589793 * 2
		local function v_u_1569() -- name: headPlace
			-- upvalues: (copy) v_u_1560, (ref) v_u_1558, (copy) v_u_1551
			local v1561 = v_u_1558 + v_u_1560 - 0
			local v1562 = math.cos(v1561) * 2.8
			local v1563 = math.sin(v1561) * 2.8
			local v1564 = Vector3.new(v1562, 0, v1563)
			local v1565 = v_u_1551.cf
			local v1566 = CFrame.lookAt
			local v1567 = -math.sin(v1561)
			local v1568 = math.cos(v1561)
			return v1565 * v1566(v1564, v1564 + Vector3.new(v1567, 0, v1568))
		end
		local v1570 = Enum.Material.SmoothPlastic
		local v1571 = v_u_7.part(Vector3.new(1, 1, 1), CFrame.identity, v1547, {
			["shape"] = nil,
			["transparency"] = 0,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball,
			["material"] = v1570
		})
		v1571.Reflectance = 0.2
		local v1572 = p_u_1544.pieces
		local v1573 = {
			["part"] = v1571,
			["place"] = v_u_1569,
			["alpha"] = v1571.Transparency
		}
		table.insert(v1572, v1573)
		local v1574 = v_u_7.part(Vector3.new(1.35, 1.35, 1.35), CFrame.identity, v_u_1546, {
			["shape"] = nil,
			["transparency"] = 0.45,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v_u_1575 = 0.4
		local function v1580(p1576, p1577)
			-- upvalues: (copy) v_u_1569, (ref) v_u_238, (copy) v_u_1575
			local v1578 = v_u_1569(p1576, p1577)
			local v1579 = v1578.Position - v_u_238
			if v1579.Magnitude < 0.01 then
				return v1578
			else
				return v1578 + v1579.Unit * v_u_1575
			end
		end
		local v1581 = p_u_1544.pieces
		local v1582 = {
			["part"] = v1574,
			["place"] = v1580,
			["alpha"] = v1574.Transparency
		}
		table.insert(v1581, v1582)
		local v1583 = v_u_7.part(Vector3.new(0.6, 0.6, 1), CFrame.identity, v_u_1546, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v1584 = Instance.new("SpecialMesh")
		v1584.MeshType = Enum.MeshType.Sphere
		v1584.Parent = v1583
		local v1585 = p_u_1544.pieces
		local v1594 = {
			["part"] = v1583,
			["place"] = function()
				-- upvalues: (copy) v_u_1560, (ref) v_u_1558, (copy) v_u_1551
				local v1586 = v_u_1558 + v_u_1560 - 0.27
				local v1587 = math.cos(v1586) * 2.6799999999999997
				local v1588 = math.sin(v1586) * 2.6799999999999997
				local v1589 = Vector3.new(v1587, 0, v1588)
				local v1590 = v_u_1551.cf
				local v1591 = CFrame.lookAt
				local v1592 = -math.sin(v1586)
				local v1593 = math.cos(v1586)
				return v1590 * v1591(v1589, v1589 + Vector3.new(v1592, 0, v1593))
			end,
			["alpha"] = v1583.Transparency
		}
		table.insert(v1585, v1594)
		local v1595 = v_u_7.part(Vector3.new(0.34, 0.34, 0.95), CFrame.identity, v_u_1546, {
			["transparency"] = 0.1,
			["material"] = nil
		})
		local v1596 = Instance.new("SpecialMesh")
		v1596.MeshType = Enum.MeshType.Sphere
		v1596.Parent = v1595
		local v1597 = p_u_1544.pieces
		local v1606 = {
			["part"] = v1595,
			["place"] = function()
				-- upvalues: (copy) v_u_1560, (ref) v_u_1558, (copy) v_u_1551
				local v1598 = v_u_1558 + v_u_1560 - 0.5
				local v1599 = math.cos(v1598) * 2.4499999999999997
				local v1600 = math.sin(v1598) * 2.4499999999999997
				local v1601 = Vector3.new(v1599, 0, v1600)
				local v1602 = v_u_1551.cf
				local v1603 = CFrame.lookAt
				local v1604 = -math.sin(v1598)
				local v1605 = math.cos(v1598)
				return v1602 * v1603(v1601, v1601 + Vector3.new(v1604, 0, v1605))
			end,
			["alpha"] = v1595.Transparency
		}
		table.insert(v1597, v1606)
		v_u_1379(v1571, v_u_1546, v1547, 0.7, 0.35)
	end
	local v_u_1607 = {}
	for v1608 = 1, 4 do
		local v_u_1609 = {
			["part"] = nil,
			["x"] = 0,
			["y"] = 0,
			["z"] = 0,
			["v"] = 0,
			["live"] = false,
			["wait"] = nil
		}
		local v1610 = v_u_7.part(Vector3.new(0.24, 0.42, 0.24), CFrame.identity, v_u_1546, {
			["transparency"] = 1,
			["material"] = nil
		})
		local v1611 = Instance.new("SpecialMesh")
		v1611.MeshType = Enum.MeshType.Sphere
		v1611.Parent = v1610
		v_u_1609.part = v1610
		v_u_1609.wait = v1608 * 0.4
		table.insert(v_u_1607, v_u_1609)
		local v1612 = v_u_1609.part
		local v1613 = p_u_1544.pieces
		local v1620 = {
			["part"] = v1612,
			["place"] = function(p1614)
				-- upvalues: (copy) v_u_1609
				local v1615 = CFrame.new
				local v1616 = p1614.Position
				local v1617 = v_u_1609.x
				local v1618 = v_u_1609.y
				local v1619 = v_u_1609.z
				return v1615(v1616 + Vector3.new(v1617, v1618, v1619))
			end,
			["alpha"] = v1612.Transparency
		}
		table.insert(v1613, v1620)
	end
	local v_u_1621 = 0
	local v1622 = p_u_1544.ticks
	local function v1640(p1623, p1624, p1625)
		-- upvalues: (copy) v_u_1607, (copy) p_u_1544, (ref) v_u_15, (ref) v_u_238, (ref) v_u_7, (copy) v_u_1546, (ref) v_u_12, (ref) v_u_1621, (ref) v_u_1558, (copy) v_u_1551
		for _, v1626 in v_u_1607 do
			if v1626.live then
				v1626.v = v1626.v - 38 * p1625
				v1626.y = v1626.y + v1626.v * p1625
				if v1626.y > p_u_1544.feet + 0.15 then
					continue
				end
				v1626.live = false
				v1626.wait = p1624 + v_u_15:NextNumber(0.3, 0.9)
				v1626.part.Transparency = 1
				if (p1623.Position - v_u_238).Magnitude >= 120 then
					continue
				end
				local v1627 = v_u_7.ring
				local v1628 = p1623.Position
				local v1629 = v1626.x
				local v1630 = p_u_1544.feet + 0.12
				local v1631 = v1626.z
				v1627(v1628 + Vector3.new(v1629, v1630, v1631), v_u_1546, 1.1, 0.3, v_u_12.Ring)
			else
				if v1626.wait > p1624 then
					continue
				end
				v_u_1621 = v_u_1621 % 3 + 1
				local v1632 = v_u_1558 + (v_u_1621 - 1) / 3 * 3.141592653589793 * 2
				local v1633 = v_u_1551.cf
				local v1634 = math.cos(v1632) * 2.8
				local v1635 = math.sin(v1632) * 2.8
				local v1636 = v1633 * Vector3.new(v1634, 0, v1635) - p1623.Position
				local v1637 = v1636.X
				local v1638 = v1636.Y - 0.45
				local v1639 = v1636.Z
				v1626.x = v1637
				v1626.y = v1638
				v1626.z = v1639
				v1626.v = 0
				v1626.live = true
				v1626.part.Transparency = 0
			end
		end
	end
	table.insert(v1622, v1640)
	local v1641 = v1547:Lerp(v_u_1546, 0.3)
	local v1642 = v_u_7.part(Vector3.new(0.1, 5.2, 5.2), CFrame.identity, v1641, {
		["shape"] = nil,
		["transparency"] = 0.4,
		["material"] = nil,
		["shape"] = Enum.PartType.Cylinder
	})
	local v1643 = p_u_1544.pieces
	local v1649 = {
		["part"] = v1642,
		["place"] = function(p1644)
			-- upvalues: (copy) p_u_1544
			local v1645 = CFrame.new
			local v1646 = p_u_1544
			local v1647 = p1644.Position
			local v1648 = v1646.feet + 0.07
			return v1645(v1647 + Vector3.new(0, v1648, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
		end,
		["alpha"] = v1642.Transparency
	}
	table.insert(v1643, v1649)
	for v1650 = 1, 4 do
		local v_u_1651 = v_u_7.part(Vector3.new(0.55, 0.55, 0.55), CFrame.identity, v_u_1546, {
			["transparency"] = 1,
			["material"] = nil
		})
		local v1652 = Instance.new("SpecialMesh")
		v1652.MeshType = Enum.MeshType.Sphere
		v1652.Parent = v_u_1651
		local v_u_1653 = v_u_1651:FindFirstChildOfClass("SpecialMesh")
		local v_u_1654 = -v1650 * 0.3
		local v_u_1655 = Vector3.new(0, 0, 0)
		local v1656 = p_u_1544.ticks
		local function v1663(_, p1657)
			-- upvalues: (ref) v_u_1654, (ref) v_u_15, (ref) v_u_1655, (copy) v_u_1651, (copy) v_u_1653
			local v1658 = p1657 - v_u_1654
			if v1658 > 1.1 then
				v_u_1654 = p1657 + v_u_15:NextNumber(0, 0.4)
				local v1659 = v_u_15:NextNumber(0, 6.283185307179586)
				local v1660 = v_u_15:NextNumber(0.3, 2.1)
				local v1661 = math.cos(v1659) * v1660
				local v1662 = math.sin(v1659) * v1660
				v_u_1655 = Vector3.new(v1661, 0, v1662)
				v1658 = p1657 - v_u_1654
			end
			if v1658 < 0 or v1658 > 0.9 then
				v_u_1651.Transparency = 1
			else
				v_u_1651.Transparency = 0.15
				if v_u_1653 then
					v_u_1653.Scale = Vector3.new(1, 1, 1) * (0.25 + v1658)
				end
			end
		end
		table.insert(v1656, v1663)
		local function v1672(p1664, p1665)
			-- upvalues: (copy) p_u_1544, (ref) v_u_1654, (ref) v_u_1655
			local v1666 = CFrame.new
			local v1667 = p_u_1544
			local v1668 = p1665 - v_u_1654
			local v1669 = math.clamp(v1668, 0, 0.9) * 0.6 + 0.05
			local v1670 = p1664.Position
			local v1671 = v1667.feet + v1669
			return v1666(v1670 + Vector3.new(0, v1671, 0) + v_u_1655)
		end
		local v1673 = p_u_1544.pieces
		local v1674 = {
			["part"] = v_u_1651,
			["place"] = v1672,
			["alpha"] = v_u_1651.Transparency
		}
		table.insert(v1673, v1674)
	end
	local v1675 = v_u_260
	local v1676 = {
		["only"] = nil,
		["paint"] = nil,
		["at"] = nil,
		["rate"] = 1,
		["only"] = { "Stain", "Smoke" },
		["paint"] = v1547:Lerp(v_u_1546, 0.3)
	}
	local v1677 = p_u_1544.feet + 0.1
	v1676.at = Vector3.new(0, v1677, 0)
	v1675(p_u_1544, "FireDark", nil, v1676)
	v_u_260(p_u_1544, "AuraMode", v_u_1546, {
		["rate"] = 0.5,
		["glow"] = 0.5,
		["only"] = nil,
		["only"] = { "Glow", "Crackle", "Sparks" }
	})
end
function v_u_1353.w2_lotus_eye(p_u_1678, p1679)
	-- upvalues: (copy) v_u_7, (ref) v_u_238, (copy) v_u_260
	local v_u_1680 = v_u_7.color(p1679.color)
	local v1681 = v_u_7.color(p1679.color2)
	local v1682 = Color3.fromRGB(255, 214, 120)
	local function v_u_1684(p1683)
		-- upvalues: (ref) v_u_7, (copy) v_u_1680
		v_u_7.flash((p1683 * CFrame.new(0, 1.5, 1.35)).Position, v_u_1680, 3.5, 0.3)
	end
	local v_u_1685 = 0
	local v_u_1686 = 1.5
	local v1687 = p_u_1678.ticks
	local v_u_1688 = 4
	local v_u_1689 = 1.6
	local function v1694(p1690, p1691, p1692)
		-- upvalues: (ref) v_u_1686, (copy) v_u_1688, (ref) v_u_1685, (copy) v_u_1684, (ref) v_u_238, (copy) v_u_1689, (copy) p_u_1678
		if v_u_1686 <= p1691 then
			v_u_1686 = p1691 + v_u_1688
			v_u_1685 = 1
			if v_u_1684 and (p1690.Position - v_u_238).Magnitude < 150 then
				v_u_1684(p1690)
			end
		end
		local v1693 = v_u_1685 - p1692 * v_u_1689
		v_u_1685 = math.max(v1693, 0)
		p_u_1678.pulse = v_u_1685
	end
	table.insert(v1687, v1694)
	local function v_u_1695()
		-- upvalues: (ref) v_u_1685
		return v_u_1685
	end
	local function v_u_1700(p1696, p1697)
		local v1698 = CFrame.new
		local v1699 = p1697 * 1.4
		return p1696 * v1698(0, math.sin(v1699) * 0.08 + 1.5, 1.35) * CFrame.Angles(0, 0, p1697 * 0.22)
	end
	local v_u_1701 = {
		["cf"] = CFrame.identity
	}
	local v1702 = p_u_1678.ticks
	table.insert(v1702, function(p1703, p1704)
		-- upvalues: (copy) v_u_1701, (copy) v_u_1700
		v_u_1701.cf = v_u_1700(p1703, p1704)
	end)
	local function v1732(p1705, p_u_1706, p_u_1707, p_u_1708, p1709, p1710, p1711) -- name: petals
		-- upvalues: (copy) p_u_1678, (ref) v_u_7, (copy) v_u_1695, (copy) v_u_1701
		for v_u_1712 = 1, p1705 do
			local v1713 = (v_u_1712 - 1 + p1711) / p1705 * 3.141592653589793 * 2
			local v1714 = math.cos(v1713)
			local v1715 = math.sin(v1713)
			local v_u_1716 = Vector3.new(v1714, v1715, 0)
			local v1717 = p_u_1678
			local v1718 = v_u_7.part(p_u_1707, CFrame.identity, p1709, {
				["transparency"] = nil,
				["material"] = nil,
				["transparency"] = p1710
			})
			local v1719 = Instance.new("SpecialMesh")
			v1719.MeshType = Enum.MeshType.Sphere
			v1719.Parent = v1718
			local function v1729(_, p1720)
				-- upvalues: (copy) p_u_1708, (ref) v_u_1695, (copy) v_u_1712, (copy) v_u_1716, (copy) p_u_1706, (copy) p_u_1707, (ref) v_u_1701
				local v1721 = p_u_1708 - 14 * v_u_1695()
				local v1722 = p1720 * 1.3 + v_u_1712
				local v1723 = v1721 + math.sin(v1722) * 4
				local v1724 = math.rad(v1723)
				local v1725 = v_u_1716 * math.cos(v1724)
				local v1726 = math.sin(v1724)
				local v1727 = v1725 + Vector3.new(0, 0, v1726)
				local v1728 = v_u_1716 * p_u_1706 + v1727 * p_u_1707.Z / 2
				return v_u_1701.cf * CFrame.lookAt(v1728, v1728 + v1727, Vector3.new(0, 0, 1))
			end
			local v1730 = v1717.pieces
			local v1731 = {
				["part"] = v1718,
				["place"] = v1729,
				["alpha"] = v1718.Transparency
			}
			table.insert(v1730, v1731)
		end
	end
	v1732(10, 0.95, Vector3.new(1, 0.22, 2.5), 22, v_u_1680, 0.05, 0)
	v1732(8, 0.55, Vector3.new(0.75, 0.2, 1.6), 44, v1681, 0.25, 0.5)
	local v1733 = v_u_7.part(Vector3.new(0.8, 0.8, 0.8), CFrame.identity, v1682, {
		["shape"] = nil,
		["transparency"] = 0.1,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_1734 = CFrame.new(0, 0, 0.3)
	local v1735 = p_u_1678.pieces
	local v1736 = {
		["part"] = v1733,
		["place"] = function()
			-- upvalues: (copy) v_u_1701, (copy) v_u_1734
			return v_u_1701.cf * v_u_1734
		end,
		["alpha"] = v1733.Transparency
	}
	table.insert(v1735, v1736)
	local v1737 = v_u_7.part(Vector3.new(1.5, 1.5, 1.5), CFrame.identity, v_u_1680, {
		["shape"] = nil,
		["transparency"] = 0.65,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_1738 = CFrame.identity
	local v1739 = p_u_1678.pieces
	local v1740 = {
		["part"] = v1737,
		["place"] = function()
			-- upvalues: (copy) v_u_1701, (copy) v_u_1738
			return v_u_1701.cf * v_u_1738
		end,
		["alpha"] = v1737.Transparency
	}
	table.insert(v1739, v1740)
	for v_u_1741 = 1, 4 do
		local v1742 = v_u_7.part(Vector3.new(0.5, 0.12, 0.9), CFrame.identity, v_u_1680, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v1743 = Instance.new("SpecialMesh")
		v1743.MeshType = Enum.MeshType.Sphere
		v1743.Parent = v1742
		local v1744 = p_u_1678.pieces
		local v1753 = {
			["part"] = v1742,
			["place"] = function(p1745, p1746)
				-- upvalues: (copy) v_u_1741
				local v1747 = (v_u_1741 - 1) / 4 * 3.141592653589793 * 2 + p1746 * 0.7
				local v1748 = math.cos(v1747) * 2.7
				local v1749 = p1746 * 1.2 + v_u_1741 * 1.7
				local v1750 = math.sin(v1749) * 0.9 + -0.6
				local v1751 = math.sin(v1747) * 2.7
				local v1752 = Vector3.new(v1748, v1750, v1751)
				return p1745 * CFrame.new(v1752) * CFrame.Angles(p1746 * 1.3 + v_u_1741, p1746 * 0.9, p1746 * 0.6 + v_u_1741)
			end,
			["alpha"] = v1742.Transparency
		}
		table.insert(v1744, v1753)
	end
	v_u_260(p_u_1678, "Petals", v_u_1680, {
		["rate"] = 1,
		["glow"] = 0.5,
		["only"] = nil,
		["only"] = { "Petals", "Motes" }
	})
	v_u_260(p_u_1678, "AuraMode", v_u_1680, {
		["rate"] = 0.45,
		["glow"] = 0.5,
		["only"] = nil,
		["only"] = { "Glow", "Sparks" }
	})
end
function v_u_1353.w2_phantom_pinwheel(p_u_1754, p1755)
	-- upvalues: (copy) v_u_7, (copy) v_u_179, (copy) v_u_3, (copy) v_u_6, (ref) v_u_238, (copy) v_u_15, (copy) v_u_260
	local v_u_1756 = v_u_7.color(p1755.color)
	local v_u_1757 = v_u_7.color(p1755.color2)
	local v_u_1758 = v_u_179("SusanooStatue", 1)
	if v_u_1758 then
		local function v_u_1768(p1759, p1760)
			-- upvalues: (copy) p_u_1754, (copy) v_u_1758
			local v1761 = CFrame.new
			local v1762 = p_u_1754
			local v1763 = v_u_1758.Size.Y / 2
			local v1764 = p1760 * 1.2
			local v1765 = v1763 + math.sin(v1764) * 0.2
			local v1766 = p1759.Position
			local v1767 = v1762.feet + v1765
			return v1761(v1766 + Vector3.new(0, v1767, 0)) * p1759.Rotation
		end
		local v_u_1769 = {
			["cf"] = CFrame.identity
		}
		local v1770 = p_u_1754.ticks
		table.insert(v1770, function(p1771, p1772)
			-- upvalues: (copy) v_u_1769, (copy) v_u_1768
			v_u_1769.cf = v_u_1768(p1771, p1772)
		end)
		local v_u_1773 = CFrame.new(0, 0, 5.5)
		local v1774 = p_u_1754.pieces
		local v1775 = {
			["part"] = v_u_1758,
			["place"] = function()
				-- upvalues: (copy) v_u_1769, (copy) v_u_1773
				return v_u_1769.cf * v_u_1773
			end,
			["alpha"] = v_u_1758.Transparency
		}
		table.insert(v1774, v1775)
		if p_u_1754.character == v_u_3.LocalPlayer.Character then
			local v1776 = p_u_1754.ticks
			local v_u_1777 = 0.75
			local function v1782(p1778)
				-- upvalues: (ref) v_u_6, (copy) v_u_1758, (copy) v_u_1777
				local v1779 = v_u_6.CurrentCamera
				if v1779 then
					local v1780 = v_u_1758
					local v1781 = (v1779.CFrame.LookVector:Dot(p1778.LookVector) + 0.1) * 1.6
					v1780.LocalTransparencyModifier = math.clamp(v1781, 0, 1) * v_u_1777
				end
			end
			table.insert(v1776, v1782)
		end
	end
	local v1783 = v_u_1756:Lerp(Color3.fromRGB(10, 0, 25), 0.55)
	local v_u_1784 = 0
	local v_u_1785 = 0
	local v_u_1786 = 3.5
	local v_u_1787 = -10
	local v_u_1788 = true
	local v1789 = p_u_1754.ticks
	local function v1797(p1790, p1791, p1792)
		-- upvalues: (ref) v_u_238, (ref) v_u_1786, (ref) v_u_1787, (ref) v_u_1788, (ref) v_u_7, (copy) v_u_1756, (ref) v_u_1785, (copy) p_u_1754, (copy) v_u_1757, (ref) v_u_1784
		local v1793 = (p1790.Position - v_u_238).Magnitude < 150
		if v_u_1786 <= p1791 then
			v_u_1786 = p1791 + 5.5
			v_u_1787 = p1791
			v_u_1788 = false
			if v1793 then
				v_u_7.burst("Vortex", (p1790 * CFrame.new(0, 1.2, 1.5)).Position, v_u_1756, 0.45)
			end
		end
		local v1794 = p1791 - v_u_1787
		if v1794 < 0.35 then
			v_u_1785 = v1794 / 0.35
		elseif v1794 < 0.7 then
			v_u_1785 = 1
		elseif v1794 < 0.95 then
			v_u_1785 = 1 - (v1794 - 0.7) / 0.25
			if not v_u_1788 then
				v_u_1788 = true
				p_u_1754.pulse = 1
				if v1793 then
					v_u_7.flash((p1790 * CFrame.new(0, 1.2, 1.5)).Position, v_u_1757, 4, 0.3)
				end
			end
		else
			v_u_1785 = 0
		end
		local v1795 = p_u_1754
		local v1796 = p_u_1754.pulse - p1792 * 2
		v1795.pulse = math.max(v1796, 0)
		v_u_1784 = v_u_1784 + p1792 * (v_u_1785 * 9 + 2.6)
	end
	table.insert(v1789, v1797)
	local function v_u_1802(p1798, p1799)
		-- upvalues: (ref) v_u_1784
		local v1800 = CFrame.new
		local v1801 = p1799 * 1.5
		return p1798 * v1800(0, math.sin(v1801) * 0.08 + 1.2, 1.45) * CFrame.Angles(0, 0, v_u_1784)
	end
	local v_u_1803 = {
		["cf"] = CFrame.identity
	}
	local v1804 = p_u_1754.ticks
	table.insert(v1804, function(p1805, p1806)
		-- upvalues: (copy) v_u_1803, (copy) v_u_1802
		v_u_1803.cf = v_u_1802(p1805, p1806)
	end)
	local v_u_1807 = v_u_1785
	local v1808 = { 0.8, 0.62, 0.34 }
	local v_u_1809 = {}
	for v1810 = 1, 4 do
		local v1811 = (v1810 - 1) / 4 * 3.141592653589793 * 2
		local v1812 = math.cos(v1811) * 0.45
		local v1813 = math.sin(v1811) * 0.45
		local v1814 = Vector3.new(v1812, v1813, 0)
		for v1815 = 1, 3 do
			local v1816 = v1815 * 0.8 + 0.45
			local v1817 = v1811 + v1815 * 0.42
			local v1818 = math.cos(v1817) * v1816
			local v1819 = math.sin(v1817) * v1816
			local v1820 = Vector3.new(v1818, v1819, 0)
			local v1821 = v1808[v1815]
			local v1822 = (v1820 - v1814).Magnitude + 0.25
			local v1823 = Vector3.new(v1821, 0.16, v1822)
			local v1824
			if v1815 == 3 then
				v1824 = v_u_1757
			else
				v1824 = v_u_1756
			end
			local v1825 = v_u_7.part(v1823, CFrame.identity, v1824, {
				["transparency"] = 1,
				["material"] = nil
			})
			local v_u_1826 = CFrame.lookAt((v1814 + v1820) / 2, v1820, Vector3.new(0, 0, 1))
			local v1827 = p_u_1754.pieces
			local v1828 = {
				["part"] = v1825,
				["place"] = function()
					-- upvalues: (copy) v_u_1803, (copy) v_u_1826
					return v_u_1803.cf * v_u_1826
				end,
				["alpha"] = v1825.Transparency
			}
			table.insert(v1827, v1828)
			table.insert(v_u_1809, v1825)
			v1814 = v1820
		end
	end
	local v1829 = p_u_1754.ticks
	table.insert(v1829, function()
		-- upvalues: (copy) v_u_1809, (ref) v_u_1807
		for _, v1830 in v_u_1809 do
			v1830.Transparency = v_u_1807 * 0.9 + 0.05
		end
	end)
	local v1831 = Enum.Material.SmoothPlastic
	local v1832 = v_u_7.part(Vector3.new(0.9, 0.9, 0.9), CFrame.identity, v1783, {
		["shape"] = nil,
		["transparency"] = 0,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball,
		["material"] = v1831
	})
	v1832.Reflectance = 0.2
	local v_u_1833 = CFrame.identity
	local v1834 = p_u_1754.pieces
	local v1835 = {
		["part"] = v1832,
		["place"] = function()
			-- upvalues: (copy) v_u_1803, (copy) v_u_1833
			return v_u_1803.cf * v_u_1833
		end,
		["alpha"] = v1832.Transparency
	}
	table.insert(v1834, v1835)
	local v1836 = v_u_7.part(Vector3.new(1.4, 1.4, 1.4), CFrame.identity, v_u_1757, {
		["shape"] = nil,
		["transparency"] = 0.55,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_1837 = CFrame.new(0, 0, 0.05)
	local v1838 = p_u_1754.pieces
	local v1839 = {
		["part"] = v1836,
		["place"] = function()
			-- upvalues: (copy) v_u_1803, (copy) v_u_1837
			return v_u_1803.cf * v_u_1837
		end,
		["alpha"] = v1836.Transparency
	}
	table.insert(v1838, v1839)
	for v1840 = 1, 3 do
		local v_u_1841 = v_u_7.part(Vector3.new(0.3, 0.95, 0.3), CFrame.identity, v_u_1757, {
			["transparency"] = 1,
			["material"] = nil
		})
		local v_u_1842 = CFrame.identity
		local v_u_1843 = v1840 * 0.25
		local v1844 = p_u_1754.ticks
		local function v1848(_, p1845)
			-- upvalues: (ref) v_u_1843, (ref) v_u_15, (ref) v_u_1842, (copy) v_u_1841
			if v_u_1843 <= p1845 then
				v_u_1843 = p1845 + v_u_15:NextNumber(0.6, 1)
				local v1846 = v_u_15:NextNumber(0, 6.283185307179586)
				local v1847 = v_u_15:NextNumber(2.2, 3)
				v_u_1842 = CFrame.new(math.cos(v1846) * v1847, v_u_15:NextNumber(-1.6, 1.6), math.sin(v1846) * v1847) * CFrame.Angles(v_u_15:NextNumber(0, 3), v_u_15:NextNumber(0, 3), 0)
			end
			v_u_1841.Transparency = v_u_1843 - p1845 < 0.15 and 1 or 0.1
		end
		table.insert(v1844, v1848)
		local function v1851(p1849, p1850)
			-- upvalues: (ref) v_u_1842
			return p1849 * v_u_1842 * CFrame.Angles(0, p1850 * 3, 0)
		end
		local v1852 = p_u_1754.pieces
		local v1853 = {
			["part"] = v_u_1841,
			["place"] = v1851,
			["alpha"] = v_u_1841.Transparency
		}
		table.insert(v1852, v1853)
	end
	v_u_260(p_u_1754, "AuraMode", v_u_1756, {
		["rate"] = 0.5,
		["glow"] = 0.45,
		["only"] = nil,
		["only"] = { "FlameBack", "Streaks", "Sparks" }
	})
	v_u_260(p_u_1754, "Petals", v_u_1757, {
		["rate"] = 0.7,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Motes" }
	})
end
function v_u_1353.w2_amethyst_star(p_u_1854, p1855)
	-- upvalues: (copy) v_u_7, (copy) v_u_236, (copy) v_u_179, (copy) v_u_3, (copy) v_u_6, (copy) v_u_12, (ref) v_u_238, (copy) v_u_260
	local v_u_1856 = v_u_7.color(p1855.color)
	local v1857 = v_u_7.color(p1855.color2)
	local function v_u_1862(p1858, p1859)
		local v1860 = CFrame.new
		local v1861 = p1859 * 1.5
		return p1858 * v1860(0, math.sin(v1861) * 0.12, 0)
	end
	local v_u_1863 = {
		["cf"] = CFrame.identity
	}
	local v1864 = p_u_1854.ticks
	table.insert(v1864, function(p1865, p1866)
		-- upvalues: (copy) v_u_1863, (copy) v_u_1862
		v_u_1863.cf = v_u_1862(p1865, p1866)
	end)
	v_u_236(p_u_1854, v_u_1863, "SasukeArms", 1.5, CFrame.new(0, 0.6, 0.5), true)
	local v_u_1867 = v_u_179("SusanooMask", 2.3)
	if v_u_1867 then
		local v_u_1868 = CFrame.new(0, p_u_1854.headY + 2.6, 2.4)
		local v1869 = p_u_1854.pieces
		local v1870 = {
			["part"] = v_u_1867,
			["place"] = function()
				-- upvalues: (copy) v_u_1863, (copy) v_u_1868
				return v_u_1863.cf * v_u_1868
			end,
			["alpha"] = v_u_1867.Transparency
		}
		table.insert(v1869, v1870)
		if p_u_1854.character == v_u_3.LocalPlayer.Character then
			local v1871 = p_u_1854.ticks
			local v_u_1872 = 0.7
			local function v1877(p1873)
				-- upvalues: (ref) v_u_6, (copy) v_u_1867, (copy) v_u_1872
				local v1874 = v_u_6.CurrentCamera
				if v1874 then
					local v1875 = v_u_1867
					local v1876 = (v1874.CFrame.LookVector:Dot(p1873.LookVector) + 0.1) * 1.6
					v1875.LocalTransparencyModifier = math.clamp(v1876, 0, 1) * v_u_1872
				end
			end
			table.insert(v1871, v1877)
		end
		p_u_1854.eyeLift = 4.6
	end
	local function v_u_1883(p1878)
		-- upvalues: (ref) v_u_7, (copy) p_u_1854, (copy) v_u_1856, (ref) v_u_12
		local v1879 = v_u_7.ring
		local v1880 = p_u_1854
		local v1881 = p1878.Position
		local v1882 = v1880.feet + 0.15
		v1879(v1881 + Vector3.new(0, v1882, 0), v_u_1856, 5, 0.45, v_u_12.Ring)
	end
	local v_u_1884 = 0
	local v_u_1885 = 1.4
	local v1886 = p_u_1854.ticks
	local v_u_1887 = 4
	local v_u_1888 = 2.5
	local function v1893(p1889, p1890, p1891)
		-- upvalues: (ref) v_u_1885, (copy) v_u_1887, (ref) v_u_1884, (copy) v_u_1883, (ref) v_u_238, (copy) v_u_1888, (copy) p_u_1854
		if v_u_1885 <= p1890 then
			v_u_1885 = p1890 + v_u_1887
			v_u_1884 = 1
			if v_u_1883 and (p1889.Position - v_u_238).Magnitude < 150 then
				v_u_1883(p1889)
			end
		end
		local v1892 = v_u_1884 - p1891 * v_u_1888
		v_u_1884 = math.max(v1892, 0)
		p_u_1854.pulse = v_u_1884
	end
	table.insert(v1886, v1893)
	local function v_u_1894()
		-- upvalues: (ref) v_u_1884
		return v_u_1884
	end
	local function v1924(p_u_1895, p1896, p1897, p1898, p1899, p1900) -- name: hexagram
		-- upvalues: (ref) v_u_7, (copy) p_u_1854
		local v1901 = {}
		for v1902 = 0, 1 do
			for v1903 = 0, 2 do
				local v1904 = v1902 * 180 + 90 + v1903 * 120
				local v1905 = math.rad(v1904)
				local v1906 = v1902 * 180 + 90 + (v1903 + 1) * 120
				local v1907 = math.rad(v1906)
				local v1908
				if p1900 then
					local v1909 = math.cos(v1905) * p1896
					local v1910 = math.sin(v1905) * p1896
					v1908 = Vector3.new(v1909, 0, v1910)
				else
					local v1911 = math.cos(v1905) * p1896
					local v1912 = math.sin(v1905) * p1896
					v1908 = Vector3.new(v1911, v1912, 0)
				end
				local v1913
				if p1900 then
					local v1914 = math.cos(v1907) * p1896
					local v1915 = math.sin(v1907) * p1896
					v1913 = Vector3.new(v1914, 0, v1915)
				else
					local v1916 = math.cos(v1907) * p1896
					local v1917 = math.sin(v1907) * p1896
					v1913 = Vector3.new(v1916, v1917, 0)
				end
				local v_u_1918 = CFrame.lookAt((v1908 + v1913) / 2, v1913)
				local v1919 = (v1913 - v1908).Magnitude + p1897
				local v1920 = Vector3.new(p1897, p1897, v1919)
				local v1921 = v_u_7.part(v1920, CFrame.identity, p1898, {
					["transparency"] = nil,
					["material"] = nil,
					["transparency"] = p1899
				})
				local v1922 = p_u_1854.pieces
				local v1923 = {
					["part"] = v1921,
					["place"] = function()
						-- upvalues: (copy) p_u_1895, (copy) v_u_1918
						return p_u_1895.cf * v_u_1918
					end,
					["alpha"] = v1921.Transparency
				}
				table.insert(v1922, v1923)
				table.insert(v1901, v1921)
			end
		end
		return v1901
	end
	local function v_u_1929(p1925, p1926)
		local v1927 = CFrame.new
		local v1928 = p1926 * 1.6
		return p1925 * v1927(0, math.sin(v1928) * 0.08 + 1.5, 1.4) * CFrame.Angles(0, 0, p1926 * 0.35)
	end
	local v_u_1930 = {
		["cf"] = CFrame.identity
	}
	local v1931 = p_u_1854.ticks
	table.insert(v1931, function(p1932, p1933)
		-- upvalues: (copy) v_u_1930, (copy) v_u_1929
		v_u_1930.cf = v_u_1929(p1932, p1933)
	end)
	v1924(v_u_1930, 2.5, 0.17, v1857, 0, false)
	for v1934 = 0, 5 do
		local v1935 = v1934 * 60 + 90
		local v1936 = math.rad(v1935)
		local v1937 = math.cos(v1936)
		local v1938 = math.sin(v1936)
		local v1939 = Vector3.new(v1937, v1938, 0) * 2.75
		local v1940 = v_u_7.part(Vector3.new(0.55, 0.55, 0.55), CFrame.identity, v_u_1856, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v_u_1941 = CFrame.new(v1939) * CFrame.Angles(0.7853981633974483, 0.6154030942532006, 0)
		local v1942 = p_u_1854.pieces
		local v1943 = {
			["part"] = v1940,
			["place"] = function()
				-- upvalues: (copy) v_u_1930, (copy) v_u_1941
				return v_u_1930.cf * v_u_1941
			end,
			["alpha"] = v1940.Transparency
		}
		table.insert(v1942, v1943)
	end
	local function v_u_1950(p1944, p1945)
		-- upvalues: (copy) p_u_1854
		local v1946 = CFrame.new
		local v1947 = p_u_1854
		local v1948 = p1944.Position
		local v1949 = v1947.feet + 0.12
		return v1946(v1948 + Vector3.new(0, v1949, 0)) * CFrame.Angles(0, -p1945 * 0.3, 0)
	end
	local v_u_1951 = {
		["cf"] = CFrame.identity
	}
	local v1952 = p_u_1854.ticks
	table.insert(v1952, function(p1953, p1954)
		-- upvalues: (copy) v_u_1951, (copy) v_u_1950
		v_u_1951.cf = v_u_1950(p1953, p1954)
	end)
	local v_u_1955 = v1924(v_u_1951, 3.4, 0.14, v_u_1856, 1, true)
	local v1956 = p_u_1854.ticks
	table.insert(v1956, function()
		-- upvalues: (copy) v_u_1894, (copy) v_u_1955
		local v1957 = 0.3 - v_u_1894() * 0.3
		for _, v1958 in v_u_1955 do
			v1958.Transparency = v1957
		end
	end)
	for v_u_1959 = 1, 4 do
		local function v_u_1966(p1960, p1961) -- name: place
			-- upvalues: (copy) v_u_1959
			local v1962 = (v_u_1959 - 1) / 4 * 3.141592653589793 * 2 - p1961 * 0.6
			local v1963 = CFrame.new
			local v1964 = math.cos(v1962) * 2.9
			local v1965 = p1961 * 1.5 + v_u_1959 * 1.6
			return p1960 * v1963(v1964, math.sin(v1965) * 0.5 + -0.5, math.sin(v1962) * 2.9) * CFrame.Angles(0, p1961 * 1.4 + v_u_1959, 0)
		end
		local v1967 = v_u_7.part(Vector3.new(0.5, 1.4, 0.5), CFrame.identity, v_u_1856, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v1968 = p_u_1854.pieces
		local v1971 = {
			["part"] = v1967,
			["place"] = function(p1969, p1970)
				-- upvalues: (copy) v_u_1966
				return v_u_1966(p1969, p1970) * CFrame.Angles(0, 0.7853981633974483, 0)
			end,
			["alpha"] = v1967.Transparency
		}
		table.insert(v1968, v1971)
		local v1972 = v_u_7.part(Vector3.new(0.75, 1.7, 0.75), CFrame.identity, v1857, {
			["transparency"] = 0.6,
			["material"] = nil
		})
		local v_u_1973 = 0.3
		local function v1978(p1974, p1975)
			-- upvalues: (copy) v_u_1966, (ref) v_u_238, (copy) v_u_1973
			local v1976 = v_u_1966(p1974, p1975)
			local v1977 = v1976.Position - v_u_238
			if v1977.Magnitude < 0.01 then
				return v1976
			else
				return v1976 + v1977.Unit * v_u_1973
			end
		end
		local v1979 = p_u_1854.pieces
		local v1980 = {
			["part"] = v1972,
			["place"] = v1978,
			["alpha"] = v1972.Transparency
		}
		table.insert(v1979, v1980)
	end
	v_u_260(p_u_1854, "AuraMode", v_u_1856, {
		["rate"] = 0.5,
		["glow"] = 0.45,
		["only"] = nil,
		["only"] = { "Glow", "Crackle", "Sparks" }
	})
	v_u_260(p_u_1854, "Petals", v1857, {
		["rate"] = 0.8,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Motes" }
	})
end
function v_u_1353.w2_grave_rinne(p_u_1981, p1982)
	-- upvalues: (copy) v_u_7, (copy) v_u_236, (copy) v_u_3, (copy) v_u_6, (copy) v_u_1362, (copy) v_u_12, (copy) v_u_1379, (copy) v_u_15, (ref) v_u_238, (copy) v_u_260
	local v1983 = v_u_7.color(p1982.color)
	local v1984 = v_u_7.color(p1982.color2)
	local function v_u_1989(p1985, p1986)
		local v1987 = CFrame.new
		local v1988 = p1986 * 1.3
		return p1985 * v1987(0, math.sin(v1988) * 0.2, 0)
	end
	local v_u_1990 = {
		["cf"] = CFrame.identity
	}
	local v1991 = p_u_1981.ticks
	table.insert(v1991, function(p1992, p1993)
		-- upvalues: (copy) v_u_1990, (copy) v_u_1989
		v_u_1990.cf = v_u_1989(p1992, p1993)
	end)
	local v_u_1994 = v_u_236(p_u_1981, v_u_1990, "SusanooGuardian", 1.8, CFrame.new(-3, 2.6, 0.9))
	if v_u_1994 then
		if p_u_1981.character == v_u_3.LocalPlayer.Character then
			local v1995 = p_u_1981.ticks
			local v_u_1996 = 0.6
			local function v2001(p1997)
				-- upvalues: (ref) v_u_6, (copy) v_u_1994, (copy) v_u_1996
				local v1998 = v_u_6.CurrentCamera
				if v1998 then
					local v1999 = v_u_1994
					local v2000 = (v1998.CFrame.LookVector:Dot(p1997.LookVector) + 0.1) * 1.6
					v1999.LocalTransparencyModifier = math.clamp(v2000, 0, 1) * v_u_1996
				end
			end
			table.insert(v1995, v2001)
		end
		p_u_1981.eyeLift = 6
	end
	local v2002 = Color3.fromRGB(228, 222, 248)
	local v_u_2003 = v1983:Lerp(Color3.fromRGB(205, 185, 255), 0.4)
	local v2004 = Enum.Material.SmoothPlastic
	local v2005 = v_u_7.part(Vector3.new(0.1, 5.6, 5.6), CFrame.identity, v1984, {
		["shape"] = nil,
		["transparency"] = 0.1,
		["material"] = nil,
		["shape"] = Enum.PartType.Cylinder,
		["material"] = v2004
	})
	local v2006 = p_u_1981.pieces
	local v2012 = {
		["part"] = v2005,
		["place"] = function(p2007)
			-- upvalues: (copy) p_u_1981
			local v2008 = CFrame.new
			local v2009 = p_u_1981
			local v2010 = p2007.Position
			local v2011 = v2009.feet + 0.05
			return v2008(v2010 + Vector3.new(0, v2011, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
		end,
		["alpha"] = v2005.Transparency
	}
	table.insert(v2006, v2012)
	local v2013 = v_u_1362(5.4, v_u_12.Swirl, v_u_2003, 0.15)
	local v2014 = p_u_1981.pieces
	local v2021 = {
		["part"] = v2013,
		["place"] = function(p2015, p2016)
			-- upvalues: (copy) p_u_1981
			local v2017 = CFrame.new
			local v2018 = p_u_1981
			local v2019 = p2015.Position
			local v2020 = v2018.feet + 0.1
			return v2017(v2019 + Vector3.new(0, v2020, 0)) * CFrame.Angles(0, -p2016 * 1.1, 0)
		end,
		["alpha"] = v2013.Transparency
	}
	table.insert(v2014, v2021)
	for v_u_2022 = 1, 3 do
		local v_u_2023, v_u_2024 = v_u_1362(5.6, v_u_12.Ring, v_u_2003, 0)
		local v2025 = p_u_1981.ticks
		table.insert(v2025, function(_, p2026)
			-- upvalues: (copy) v_u_2022, (copy) v_u_2023, (copy) v_u_2024
			local v2027 = (p2026 / 2.6 + v_u_2022 / 3) % 1
			local v2028 = 5.6 - v2027 * 2.4
			v_u_2023.Size = Vector3.new(v2028, 0.05, v2028)
			for _, v2029 in v_u_2024 do
				v2029.Transparency = v2027 * 0.9 + 0.1
			end
		end)
		local v2030 = p_u_1981.pieces
		local v2039 = {
			["part"] = v_u_2023,
			["place"] = function(p2031, p2032)
				-- upvalues: (copy) v_u_2022, (copy) p_u_1981
				local v2033 = (p2032 / 2.6 + v_u_2022 / 3) % 1
				local v2034 = CFrame.new
				local v2035 = p_u_1981
				local v2036 = 0.2 + v2033 * (p_u_1981.headY + 1 - p_u_1981.feet)
				local v2037 = p2031.Position
				local v2038 = v2035.feet + v2036
				return v2034(v2037 + Vector3.new(0, v2038, 0))
			end,
			["alpha"] = v_u_2023.Transparency
		}
		table.insert(v2030, v2039)
	end
	for v_u_2040 = 1, 5 do
		local v_u_2041 = v_u_7.part(Vector3.new(0.5, 0.5, 0.5), CFrame.identity, v2002, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v_u_2042 = v_u_1379(v_u_2041, v2002, v1983, 0.5, 0.7)
		local v_u_2043 = -(v_u_2040 - 1) * 0.7
		local v_u_2044 = CFrame.Angles(v_u_15:NextNumber(-0.3, 0.3), 0, v_u_15:NextNumber(-0.3, 0.3))
		local v_u_2045 = false
		local v2046 = p_u_1981.ticks
		local function v2049(_, p2047)
			-- upvalues: (ref) v_u_2045, (copy) v_u_2042, (ref) v_u_2043, (copy) v_u_2041
			if v_u_2045 then
				v_u_2045 = false
				v_u_2042.Enabled = true
			end
			if p2047 - v_u_2043 > 3.4 then
				v_u_2043 = p2047
				v_u_2042.Enabled = false
				v_u_2042:Clear()
				v_u_2045 = true
			end
			local v2048 = (p2047 - v_u_2043) / 3.4
			v_u_2041.Transparency = v_u_2045 and 1 or (v2048 <= 0.85 and 0 or (v2048 - 0.85) / 0.15)
		end
		table.insert(v2046, v2049)
		local function v2057(p2050, p2051)
			-- upvalues: (ref) v_u_2043, (copy) v_u_2040, (copy) p_u_1981, (copy) v_u_2044
			local v2052 = (p2051 - v_u_2043) / 3.4
			local v2053 = math.clamp(v2052, 0, 1)
			local v2054 = v_u_2040 * 1.3 + (p2051 - v_u_2043) * 2.2
			local v2055 = 2.6 - v2053 * 0.9
			local v2056 = p_u_1981.feet + 0.3 + v2053 * (p_u_1981.headY + 1.8 - p_u_1981.feet)
			return CFrame.new(p2050.Position) * v_u_2044 * CFrame.new(math.cos(v2054) * v2055, v2056, math.sin(v2054) * v2055)
		end
		local v2058 = p_u_1981.pieces
		local v2059 = {
			["part"] = v_u_2041,
			["place"] = v2057,
			["alpha"] = v_u_2041.Transparency
		}
		table.insert(v2058, v2059)
	end
	local function v_u_2066(p2060, p2061)
		-- upvalues: (copy) p_u_1981
		local v2062 = CFrame.new
		local v2063 = p_u_1981
		local v2064 = p2060.Position
		local v2065 = v2063.feet + 0
		return v2062(v2064 + Vector3.new(0, v2065, 0)) * CFrame.Angles(0, p2061 * 0.2, 0)
	end
	local v_u_2067 = {
		["cf"] = CFrame.identity
	}
	local v2068 = p_u_1981.ticks
	table.insert(v2068, function(p2069, p2070)
		-- upvalues: (copy) v_u_2067, (copy) v_u_2066
		v_u_2067.cf = v_u_2066(p2069, p2070)
	end)
	for v_u_2071 = 1, 6 do
		local v2072 = (v_u_2071 - 1) / 6 * 3.141592653589793 * 2
		local v2073 = math.cos(v2072)
		local v2074 = math.sin(v2072)
		local v_u_2075 = Vector3.new(v2073, 0, v2074)
		local function v_u_2082(_, p2076) -- name: place
			-- upvalues: (copy) v_u_2071, (copy) v_u_2075, (copy) v_u_2067
			local v2077 = p2076 * 1.1 + v_u_2071 * 2.1
			local v2078 = math.sin(v2077) * 0.5 + 0.5
			local v2079 = v_u_2075 * 3
			local v2080 = v2078 * 1.4 + -0.6
			local v2081 = v2079 + Vector3.new(0, v2080, 0)
			return v_u_2067.cf * CFrame.lookAt(v2081, v2081 + v_u_2075) * CFrame.Angles(1.1344640137963142, 0, 0)
		end
		local v2083 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v2084 = v_u_7.part(Vector3.new(0.38, 0.38, 2), CFrame.identity, v1984, v2083)
		v2084.Reflectance = 0.2
		local v2085 = p_u_1981.pieces
		local v2086 = {
			["part"] = v2084,
			["place"] = v_u_2082,
			["alpha"] = v2084.Transparency
		}
		table.insert(v2085, v2086)
		local v2087 = v_u_7.part(Vector3.new(0.6, 0.6, 2.2), CFrame.identity, v_u_2003, {
			["transparency"] = 0.55,
			["material"] = nil
		})
		local v_u_2088 = 0.2
		local function v2093(p2089, p2090)
			-- upvalues: (copy) v_u_2082, (ref) v_u_238, (copy) v_u_2088
			local v2091 = v_u_2082(p2089, p2090)
			local v2092 = v2091.Position - v_u_238
			if v2092.Magnitude < 0.01 then
				return v2091
			else
				return v2091 + v2092.Unit * v_u_2088
			end
		end
		local v2094 = p_u_1981.pieces
		local v2095 = {
			["part"] = v2087,
			["place"] = v2093,
			["alpha"] = v2087.Transparency
		}
		table.insert(v2094, v2095)
	end
	local v_u_2096 = 2
	local v2097 = p_u_1981.ticks
	local v_u_2098 = 4
	local v_u_2099 = 4
	local function v2102(p2100, p2101)
		-- upvalues: (ref) v_u_2096, (copy) v_u_2098, (ref) v_u_7, (copy) v_u_2003, (copy) v_u_2099, (copy) p_u_1981, (ref) v_u_12
		if v_u_2096 <= p2101 then
			v_u_2096 = p2101 + v_u_2098
			v_u_7.ring(p2100.Position + Vector3.new(0, -0.8, 0), v_u_2003, v_u_2099 * p_u_1981.fx, 0.5, v_u_12.Ring)
		end
	end
	table.insert(v2097, v2102)
	local v2103 = v_u_260
	local v2104 = {
		["only"] = nil,
		["paint"] = nil,
		["at"] = nil,
		["rate"] = 1,
		["only"] = { "Stain", "Smoke" },
		["paint"] = v1984
	}
	local v2105 = p_u_1981.feet + 0.1
	v2104.at = Vector3.new(0, v2105, 0)
	v2103(p_u_1981, "FireDark", nil, v2104)
	local v2106 = v_u_260
	local v2107 = {
		["only"] = nil,
		["rate"] = 0.4,
		["glow"] = 0.4,
		["at"] = nil,
		["only"] = { "Tongues", "Embers" }
	}
	local v2108 = p_u_1981.feet + 0.1
	v2107.at = Vector3.new(0, v2108, 0)
	v2106(p_u_1981, "Fire", v_u_2003, v2107)
	v_u_260(p_u_1981, "AuraMode", v2002, {
		["rate"] = 0.45,
		["glow"] = 0.4,
		["only"] = nil,
		["only"] = { "Streaks", "Sparks" }
	})
end
function v_u_1353.w2_jade_seal(p_u_2109, p2110)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_1368, (copy) v_u_260
	local v_u_2111 = v_u_7.color(p2110.color)
	local v2112 = v_u_7.color(p2110.color2)
	local v2113 = Color3.fromRGB(70, 140, 80):Lerp(v_u_2111, 0.25)
	local function v_u_2119(p2114)
		-- upvalues: (ref) v_u_7, (copy) p_u_2109, (copy) v_u_2111, (ref) v_u_12
		local v2115 = v_u_7.ring
		local v2116 = p_u_2109
		local v2117 = p2114.Position
		local v2118 = v2116.feet + 0.15
		v2115(v2117 + Vector3.new(0, v2118, 0), v_u_2111, 5.5, 0.6, v_u_12.CrackGlow)
	end
	local v_u_2120 = 0
	local v_u_2121 = 2
	local v2122 = p_u_2109.ticks
	local v_u_2123 = 5
	local v_u_2124 = 1.8
	local function v2129(p2125, p2126, p2127)
		-- upvalues: (ref) v_u_2121, (copy) v_u_2123, (ref) v_u_2120, (copy) v_u_2119, (ref) v_u_238, (copy) v_u_2124, (copy) p_u_2109
		if v_u_2121 <= p2126 then
			v_u_2121 = p2126 + v_u_2123
			v_u_2120 = 1
			if v_u_2119 and (p2125.Position - v_u_238).Magnitude < 150 then
				v_u_2119(p2125)
			end
		end
		local v2128 = v_u_2120 - p2127 * v_u_2124
		v_u_2120 = math.max(v2128, 0)
		p_u_2109.pulse = v_u_2120
	end
	table.insert(v2122, v2129)
	for v_u_2130 = 1, 4 do
		local function v_u_2142(p2131, p2132) -- name: place
			-- upvalues: (copy) v_u_2130
			local v2133 = (v_u_2130 - 1) / 4 * 3.141592653589793 * 2 + p2132 * 0.55
			local v2134 = math.cos(v2133) * 2.75
			local v2135 = p2132 * 1.3 + v_u_2130 * 1.6
			local v2136 = math.sin(v2135) * 0.3 + 0.35
			local v2137 = math.sin(v2133) * 2.75
			local v2138 = Vector3.new(v2134, v2136, v2137)
			local v2139 = p2131 * CFrame.lookAt(v2138, v2138 * 2)
			local v2140 = CFrame.Angles
			local v2141 = p2132 * 0.9 + v_u_2130
			return v2139 * v2140(0, 0, math.sin(v2141) * 0.2)
		end
		local v2143 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v2144 = v_u_7.part(Vector3.new(0.95, 1.55, 0.16), CFrame.identity, v2113, v2143)
		v2144.Reflectance = 0.15
		v_u_1368(v2144, v_u_12.CrackLines, v_u_2111)
		local v2145 = p_u_2109.pieces
		local v2146 = {
			["part"] = v2144,
			["place"] = v_u_2142,
			["alpha"] = v2144.Transparency
		}
		table.insert(v2145, v2146)
		local v2147 = v_u_7.part(Vector3.new(1.15, 1.75, 0.08), CFrame.identity, v_u_2111, {
			["transparency"] = 0.3,
			["material"] = nil
		})
		local v_u_2148 = 0.12
		local function v2153(p2149, p2150)
			-- upvalues: (copy) v_u_2142, (ref) v_u_238, (copy) v_u_2148
			local v2151 = v_u_2142(p2149, p2150)
			local v2152 = v2151.Position - v_u_238
			if v2152.Magnitude < 0.01 then
				return v2151
			else
				return v2151 + v2152.Unit * v_u_2148
			end
		end
		local v2154 = p_u_2109.pieces
		local v2155 = {
			["part"] = v2147,
			["place"] = v2153,
			["alpha"] = v2147.Transparency
		}
		table.insert(v2154, v2155)
	end
	local function v_u_2158(p2156, p2157)
		return p2156 * CFrame.new(0, 1, 0) * CFrame.Angles(0.28, 0, 0.1) * CFrame.Angles(0, -p2157 * 0.5, 0)
	end
	local v_u_2159 = {
		["cf"] = CFrame.identity
	}
	local v2160 = p_u_2109.ticks
	table.insert(v2160, function(p2161, p2162)
		-- upvalues: (copy) v_u_2159, (copy) v_u_2158
		v_u_2159.cf = v_u_2158(p2161, p2162)
	end)
	for v2163 = 1, 10 do
		local v2164 = (v2163 - 1) / 10 * 3.141592653589793 * 2
		local v2165 = v2163 == 1
		local v2166 = v2165 and 0.65 or 0.42
		local v2167
		if v2165 then
			v2167 = v_u_2111
		else
			v2167 = v2113
		end
		local v2168
		if v2165 then
			v2168 = Enum.Material.Neon
		else
			v2168 = Enum.Material.SmoothPlastic
		end
		local v2169 = v_u_7.part(Vector3.new(1, 1, 1) * v2166, CFrame.identity, v2167, {
			["shape"] = nil,
			["transparency"] = 0,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball,
			["material"] = v2168
		})
		if not v2165 then
			v2169.Reflectance = 0.25
		end
		local v_u_2170 = CFrame.new(math.cos(v2164) * 2.1, 0, math.sin(v2164) * 2.1)
		local v2171 = p_u_2109.pieces
		local v2172 = {
			["part"] = v2169,
			["place"] = function()
				-- upvalues: (copy) v_u_2159, (copy) v_u_2170
				return v_u_2159.cf * v_u_2170
			end,
			["alpha"] = v2169.Transparency
		}
		table.insert(v2171, v2172)
	end
	local v2173 = p_u_2109.feet + 0.1
	local v2174 = Vector3.new(0, v2173, 0)
	v_u_260(p_u_2109, "FireDark", nil, {
		["only"] = nil,
		["paint"] = nil,
		["at"] = nil,
		["rate"] = 0.5,
		["only"] = { "Rim", "Flames" },
		["paint"] = v2112,
		["at"] = v2174
	})
	v_u_260(p_u_2109, "FireDark", nil, {
		["only"] = nil,
		["paint"] = nil,
		["at"] = nil,
		["rate"] = 0.8,
		["only"] = { "Edges", "Embers" },
		["paint"] = v_u_2111,
		["at"] = v2174
	})
	v_u_260(p_u_2109, "AuraMode", v_u_2111, {
		["rate"] = 0.45,
		["glow"] = 0.45,
		["only"] = nil,
		["only"] = { "Crackle", "Sparks" }
	})
end
function v_u_1353.w2_solar_lotus(p_u_2175, p2176)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_1379, (copy) v_u_260
	local v_u_2177 = v_u_7.color(p2176.color)
	local v2178 = v_u_7.color(p2176.color2)
	local function v_u_2184(p2179)
		-- upvalues: (ref) v_u_7, (copy) p_u_2175, (copy) v_u_2177, (ref) v_u_12
		local v2180 = v_u_7.ring
		local v2181 = p_u_2175
		local v2182 = p2179.Position
		local v2183 = v2181.feet + 0.15
		v2180(v2182 + Vector3.new(0, v2183, 0), v_u_2177, 5, 0.5, v_u_12.Shockwave)
	end
	local v_u_2185 = 0
	local v_u_2186 = 1
	local v2187 = p_u_2175.ticks
	local v_u_2188 = 3
	local v_u_2189 = 1.8
	local function v2194(p2190, p2191, p2192)
		-- upvalues: (ref) v_u_2186, (copy) v_u_2188, (ref) v_u_2185, (copy) v_u_2184, (ref) v_u_238, (copy) v_u_2189, (copy) p_u_2175
		if v_u_2186 <= p2191 then
			v_u_2186 = p2191 + v_u_2188
			v_u_2185 = 1
			if v_u_2184 and (p2190.Position - v_u_238).Magnitude < 150 then
				v_u_2184(p2190)
			end
		end
		local v2193 = v_u_2185 - p2192 * v_u_2189
		v_u_2185 = math.max(v2193, 0)
		p_u_2175.pulse = v_u_2185
	end
	table.insert(v2187, v2194)
	local function v_u_2195()
		-- upvalues: (ref) v_u_2185
		return v_u_2185
	end
	local function v_u_2200(p2196, p2197)
		local v2198 = CFrame.new
		local v2199 = p2197 * 1.2
		return p2196 * v2198(0, math.sin(v2199) * 0.08 + 1.7, 1.6)
	end
	local v_u_2201 = {
		["cf"] = CFrame.identity
	}
	local v2202 = p_u_2175.ticks
	table.insert(v2202, function(p2203, p2204)
		-- upvalues: (copy) v_u_2201, (copy) v_u_2200
		v_u_2201.cf = v_u_2200(p2203, p2204)
	end)
	local function v_u_2205() -- name: core
		-- upvalues: (copy) v_u_2201
		return v_u_2201.cf
	end
	local v2206 = v_u_7.part(Vector3.new(2, 2, 2), CFrame.identity, v2178, {
		["shape"] = nil,
		["transparency"] = 0.05,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v2207 = p_u_2175.pieces
	local v2208 = {
		["part"] = v2206,
		["place"] = v_u_2205,
		["alpha"] = v2206.Transparency
	}
	table.insert(v2207, v2208)
	local v2209 = v_u_7.part(Vector3.new(3, 3, 3), CFrame.identity, v_u_2177, {
		["shape"] = nil,
		["transparency"] = 0.55,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_2210 = 0.6
	local function v2215(p2211, p2212)
		-- upvalues: (copy) v_u_2205, (ref) v_u_238, (copy) v_u_2210
		local v2213 = v_u_2205(p2211, p2212)
		local v2214 = v2213.Position - v_u_238
		if v2214.Magnitude < 0.01 then
			return v2213
		else
			return v2213 + v2214.Unit * v_u_2210
		end
	end
	local v2216 = p_u_2175.pieces
	local v2217 = {
		["part"] = v2209,
		["place"] = v2215,
		["alpha"] = v2209.Transparency
	}
	table.insert(v2216, v2217)
	for v_u_2218 = 1, 12 do
		local v_u_2219 = (v_u_2218 - 1) / 12 * 3.141592653589793 * 2
		local v2220
		if v_u_2218 % 2 == 0 then
			v2220 = v_u_2177
		else
			v2220 = v_u_2177:Lerp(v2178, 0.4)
		end
		local v2221 = v_u_7.part(Vector3.new(0.75, 0.2, 2), CFrame.identity, v2220, {
			["transparency"] = 0.05,
			["material"] = nil
		})
		local v2222 = Instance.new("SpecialMesh")
		v2222.MeshType = Enum.MeshType.Sphere
		v2222.Parent = v2221
		local v2223 = p_u_2175.pieces
		local v2239 = {
			["part"] = v2221,
			["place"] = function(_, p2224)
				-- upvalues: (copy) v_u_2219, (copy) v_u_2195, (copy) v_u_2218, (copy) v_u_2201
				local v2225 = v_u_2219 + p2224 * 0.3
				local v2226 = math.cos(v2225)
				local v2227 = math.sin(v2225)
				local v2228 = Vector3.new(v2226, v2227, 0)
				local v2229 = 1.25 + v_u_2195() * 0.5
				local v2230 = p2224 * 4 + v_u_2218 * 1.7
				local v2231 = v2229 + math.sin(v2230) * 0.08
				local v2232 = p2224 * 1.5 + v_u_2218
				local v2233 = math.sin(v2232) * 5 + 15
				local v2234 = math.rad(v2233)
				local v2235 = v2228 * math.cos(v2234)
				local v2236 = math.sin(v2234)
				local v2237 = v2235 + Vector3.new(0, 0, v2236)
				local v2238 = v2228 * v2231 + v2237
				return v_u_2201.cf * CFrame.lookAt(v2238, v2238 + v2237, Vector3.new(0, 0, 1))
			end,
			["alpha"] = v2221.Transparency
		}
		table.insert(v2223, v2239)
	end
	for v2240 = 1, 6 do
		local v_u_2241 = (v2240 - 0.5) / 6 * 3.141592653589793 * 2
		local v2242 = v_u_7.part(Vector3.new(0.14, 0.14, 3), CFrame.identity, v2178, {
			["transparency"] = 0.15,
			["material"] = nil
		})
		local v2243 = p_u_2175.pieces
		local v2250 = {
			["part"] = v2242,
			["place"] = function(_, p2244)
				-- upvalues: (copy) v_u_2241, (copy) v_u_2195, (copy) v_u_2201
				local v2245 = v_u_2241 - p2244 * 0.2
				local v2246 = math.cos(v2245)
				local v2247 = math.sin(v2245)
				local v2248 = Vector3.new(v2246, v2247, 0)
				local v2249 = v2248 * (2.8 + v_u_2195() * 0.8)
				return v_u_2201.cf * CFrame.lookAt(v2249, v2249 + v2248, Vector3.new(0, 0, 1))
			end,
			["alpha"] = v2242.Transparency
		}
		table.insert(v2243, v2250)
	end
	for v_u_2251 = 1, 3 do
		local v2252 = v_u_7.part(Vector3.new(0.55, 0.55, 0.55), CFrame.identity, v2178, {
			["shape"] = nil,
			["transparency"] = 0,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		v_u_1379(v2252, v2178, v_u_2177, 0.5, 0.4)
		local v2253 = p_u_2175.pieces
		local v2257 = {
			["part"] = v2252,
			["place"] = function(p2254, p2255)
				-- upvalues: (copy) v_u_2251
				local v2256 = (v_u_2251 - 1) / 3 * 3.141592653589793 * 2 + p2255 * 1.5
				return p2254 * CFrame.Angles(0.3, 0, v_u_2251 * 0.2) * CFrame.new(math.cos(v2256) * 2.8, -0.4, math.sin(v2256) * 2.8)
			end,
			["alpha"] = v2252.Transparency
		}
		table.insert(v2253, v2257)
	end
	local v2258 = v_u_260
	local v2259 = {
		["rate"] = 0.45,
		["glow"] = 0.6,
		["only"] = nil,
		["at"] = nil,
		["only"] = { "Flames", "Embers" }
	}
	local v2260 = p_u_2175.feet + 0.1
	v2259.at = Vector3.new(0, v2260, 0)
	v2258(p_u_2175, "Fire", v_u_2177, v2259)
	v_u_260(p_u_2175, "AuraMode", v_u_2177, {
		["rate"] = 0.5,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "FlameBack", "Sparks" }
	})
end
function v_u_1353.w2_crimson_spiral(p_u_2261, p2262)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_1362, (copy) v_u_260
	local v2263 = v_u_7.color(p2262.color)
	local v2264 = v_u_7.color(p2262.color2)
	local v_u_2265 = v2263:Lerp(Color3.fromRGB(255, 40, 60), 0.6)
	local v_u_2266 = 0
	local function v_u_2272(p2267)
		-- upvalues: (ref) v_u_7, (copy) p_u_2261, (copy) v_u_2265, (ref) v_u_12
		local v2268 = v_u_7.ring
		local v2269 = p_u_2261
		local v2270 = p2267.Position
		local v2271 = v2269.feet + 0.15
		v2268(v2270 + Vector3.new(0, v2271, 0), v_u_2265, 4.5, 0.45, v_u_12.Ring)
	end
	local v_u_2273 = 0
	local v_u_2274 = 1.2
	local v2275 = p_u_2261.ticks
	local v_u_2276 = 3.5
	local v_u_2277 = 1.5
	local function v2282(p2278, p2279, p2280)
		-- upvalues: (ref) v_u_2274, (copy) v_u_2276, (ref) v_u_2273, (copy) v_u_2272, (ref) v_u_238, (copy) v_u_2277, (copy) p_u_2261
		if v_u_2274 <= p2279 then
			v_u_2274 = p2279 + v_u_2276
			v_u_2273 = 1
			if v_u_2272 and (p2278.Position - v_u_238).Magnitude < 150 then
				v_u_2272(p2278)
			end
		end
		local v2281 = v_u_2273 - p2280 * v_u_2277
		v_u_2273 = math.max(v2281, 0)
		p_u_2261.pulse = v_u_2273
	end
	table.insert(v2275, v2282)
	local function v_u_2283()
		-- upvalues: (ref) v_u_2273
		return v_u_2273
	end
	local v2284 = p_u_2261.ticks
	local function v2286(_, _, p2285)
		-- upvalues: (ref) v_u_2266, (copy) v_u_2283
		v_u_2266 = v_u_2266 + p2285 * (1.3 + v_u_2283() * 5)
	end
	table.insert(v2284, v2286)
	local v_u_2287 = p_u_2261.headY + 1.2 - (p_u_2261.feet + 0.4)
	local v_u_2288 = v_u_2266
	for v_u_2289 = 0, 1 do
		for v2290 = 0, 6 do
			local v_u_2291 = v2290 / 6
			local v2292 = (0.68 - v_u_2291 * 0.28) * (v_u_2289 == 0 and 1 or 0.8)
			local v2293
			if v_u_2289 == 0 then
				v2293 = v2263
			else
				v2293 = v2264
			end
			local v2294 = Enum.Material.SmoothPlastic
			local v2295 = v_u_7.part(Vector3.new(1, 1, 1) * v2292, CFrame.identity, v2293, {
				["shape"] = nil,
				["transparency"] = 0,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball,
				["material"] = v2294
			})
			v2295.Reflectance = 0.2
			local v2296 = p_u_2261.pieces
			local v2307 = {
				["part"] = v2295,
				["place"] = function(p2297)
					-- upvalues: (copy) v_u_2291, (copy) v_u_2289, (ref) v_u_2288, (copy) p_u_2261, (copy) v_u_2287
					local v2298 = CFrame.new
					local v2299 = p2297.Position
					local v2300 = v_u_2291
					local v2301 = v_u_2289
					local v2302 = 2.35 - v_u_2291 * 0.65
					local v2303 = v_u_2288 + v2300 * 5.5 + v2301 * 3.141592653589793
					local v2304 = math.cos(v2303) * v2302
					local v2305 = p_u_2261.feet + 0.4 + v2300 * v_u_2287
					local v2306 = math.sin(v2303) * v2302
					return v2298(v2299 + Vector3.new(v2304, v2305, v2306))
				end,
				["alpha"] = v2295.Transparency
			}
			table.insert(v2296, v2307)
		end
	end
	for v_u_2308 = 1, 4 do
		local v_u_2309 = v_u_7.part(Vector3.new(0.3, 0.3, 0.3), CFrame.identity, v_u_2265, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v2310 = p_u_2261.ticks
		table.insert(v2310, function(_, p2311)
			-- upvalues: (copy) v_u_2308, (copy) v_u_2309
			local v2312 = (p2311 * 0.32 + v_u_2308 / 4) % 1
			v_u_2309.Transparency = v2312 <= 0.85 and 0 or (v2312 - 0.85) / 0.15
		end)
		local v2313 = p_u_2261.pieces
		local v2325 = {
			["part"] = v_u_2309,
			["place"] = function(p2314, p2315)
				-- upvalues: (copy) v_u_2308, (ref) v_u_2288, (copy) p_u_2261, (copy) v_u_2287
				local v2316 = (p2315 * 0.32 + v_u_2308 / 4) % 1
				local v2317 = CFrame.new
				local v2318 = p2314.Position
				local v2319 = v_u_2308 % 2
				local v2320 = 2.35 - v2316 * 0.65
				local v2321 = v_u_2288 + v2316 * 5.5 + v2319 * 3.141592653589793
				local v2322 = math.cos(v2321) * v2320
				local v2323 = p_u_2261.feet + 0.4 + v2316 * v_u_2287
				local v2324 = math.sin(v2321) * v2320
				return v2317(v2318 + Vector3.new(v2322, v2323, v2324) + Vector3.new(0, 0.35, 0))
			end,
			["alpha"] = v_u_2309.Transparency
		}
		table.insert(v2313, v2325)
	end
	local function v_u_2330(p2326, p2327)
		local v2328 = CFrame.new
		local v2329 = p2327 * 1.3
		return p2326 * v2328(0, math.sin(v2329) * 0.08 + 1.5, 1.35) * CFrame.Angles(1.5707963267948966, 0, 0)
	end
	local v_u_2331 = {
		["cf"] = CFrame.identity
	}
	local v2332 = p_u_2261.ticks
	table.insert(v2332, function(p2333, p2334)
		-- upvalues: (copy) v_u_2331, (copy) v_u_2330
		v_u_2331.cf = v_u_2330(p2333, p2334)
	end)
	local v2335 = v_u_1362(5.8, v_u_12.Swirl, v_u_2265, 0.1)
	local v2336 = p_u_2261.pieces
	local v2337 = {
		["part"] = v2335,
		["place"] = function()
			-- upvalues: (copy) v_u_2331, (ref) v_u_2288
			return v_u_2331.cf * CFrame.Angles(0, v_u_2288 * 1.2, 0)
		end,
		["alpha"] = v2335.Transparency
	}
	table.insert(v2336, v2337)
	local v2338 = v_u_1362(3.2, v_u_12.Swirl, v2264, 0.15)
	local v2339 = p_u_2261.pieces
	local v2340 = {
		["part"] = v2338,
		["place"] = function()
			-- upvalues: (copy) v_u_2331, (ref) v_u_2288
			return v_u_2331.cf * CFrame.new(0, 0.12, 0) * CFrame.Angles(0, -v_u_2288 * 1.6, 0)
		end,
		["alpha"] = v2338.Transparency
	}
	table.insert(v2339, v2340)
	local v2341 = v_u_260
	local v2342 = {
		["only"] = nil,
		["paint"] = nil,
		["at"] = nil,
		["rate"] = 0.8,
		["only"] = { "Stain", "Smoke" },
		["paint"] = v2263:Lerp(Color3.fromRGB(0, 0, 0), 0.4)
	}
	local v2343 = p_u_2261.feet + 0.1
	v2342.at = Vector3.new(0, v2343, 0)
	v2341(p_u_2261, "FireDark", nil, v2342)
	v_u_260(p_u_2261, "AuraMode", v_u_2265, {
		["rate"] = 0.45,
		["glow"] = 0.35,
		["only"] = nil,
		["only"] = { "FlameBack", "Sparks" }
	})
end
function v_u_1353.w2_sage_rings(p_u_2344, p2345)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_1362, (copy) v_u_260
	local v_u_2346 = v_u_7.color(p2345.color)
	local v2347 = v_u_7.color(p2345.color2)
	local v2348 = Color3.fromRGB(34, 28, 20)
	local function v_u_2354(p2349)
		-- upvalues: (ref) v_u_7, (copy) p_u_2344, (copy) v_u_2346, (ref) v_u_12
		local v2350 = v_u_7.ring
		local v2351 = p_u_2344
		local v2352 = p2349.Position
		local v2353 = v2351.feet + 0.15
		v2350(v2352 + Vector3.new(0, v2353, 0), v_u_2346, 5, 0.5, v_u_12.Ring)
	end
	local v_u_2355 = 0
	local v_u_2356 = 1.5
	local v2357 = p_u_2344.ticks
	local v_u_2358 = 4.5
	local v_u_2359 = 1.4
	local function v2364(p2360, p2361, p2362)
		-- upvalues: (ref) v_u_2356, (copy) v_u_2358, (ref) v_u_2355, (copy) v_u_2354, (ref) v_u_238, (copy) v_u_2359, (copy) p_u_2344
		if v_u_2356 <= p2361 then
			v_u_2356 = p2361 + v_u_2358
			v_u_2355 = 1
			if v_u_2354 and (p2360.Position - v_u_238).Magnitude < 150 then
				v_u_2354(p2360)
			end
		end
		local v2363 = v_u_2355 - p2362 * v_u_2359
		v_u_2355 = math.max(v2363, 0)
		p_u_2344.pulse = v_u_2355
	end
	table.insert(v2357, v2364)
	local function v_u_2365()
		-- upvalues: (ref) v_u_2355
		return v_u_2355
	end
	for v_u_2366, v_u_2367 in {
		{
			["y"] = -1.5,
			["r"] = 3,
			["tx"] = 0.22,
			["tz"] = 0.1,
			["speed"] = 0.9
		},
		{
			["y"] = -0.1,
			["r"] = 2.65,
			["tx"] = -0.18,
			["tz"] = 0.14,
			["speed"] = -1.2
		},
		{
			["y"] = 1.3,
			["r"] = 2.3,
			["tx"] = 0.12,
			["tz"] = -0.2,
			["speed"] = 1.5
		}
	} do
		local function v_u_2374(p2368, p2369)
			-- upvalues: (copy) v_u_2365, (copy) v_u_2367, (copy) v_u_2366
			local v2370 = 1 - v_u_2365()
			local v2371 = CFrame.new
			local v2372 = v_u_2367.y
			local v2373 = p2369 * 1.3 + v_u_2366
			return p2368 * v2371(0, v2372 + math.sin(v2373) * 0.08, 0) * CFrame.Angles(v_u_2367.tx * v2370, 0, v_u_2367.tz * v2370) * CFrame.Angles(0, p2369 * v_u_2367.speed, 0)
		end
		local v_u_2375 = {
			["cf"] = CFrame.identity
		}
		local v2376 = p_u_2344.ticks
		table.insert(v2376, function(p2377, p2378)
			-- upvalues: (copy) v_u_2375, (copy) v_u_2374
			v_u_2375.cf = v_u_2374(p2377, p2378)
		end)
		local v2379 = v_u_1362(v_u_2367.r * 2 + 0.4, v_u_12.Ring, v_u_2346, 0.2)
		local v_u_2380 = CFrame.identity
		local v2381 = p_u_2344.pieces
		local v2382 = {
			["part"] = v2379,
			["place"] = function()
				-- upvalues: (copy) v_u_2375, (copy) v_u_2380
				return v_u_2375.cf * v_u_2380
			end,
			["alpha"] = v2379.Transparency
		}
		table.insert(v2381, v2382)
		local v2383 = v_u_2367.speed > 0 and 1 or -1
		for v2384 = 1, 3 do
			local v2385 = (v2384 - 1) / 3 * 3.141592653589793 * 2
			local v2386 = Enum.Material.SmoothPlastic
			local v2387 = v_u_7.part(Vector3.new(0.62, 0.62, 0.62), CFrame.identity, v2348, {
				["shape"] = nil,
				["transparency"] = 0,
				["material"] = nil,
				["shape"] = Enum.PartType.Ball,
				["material"] = v2386
			})
			v2387.Reflectance = 0.2
			local v2388 = v_u_2367.r
			local v2389 = v2385 + v2383 * 0
			local v2390 = math.cos(v2389) * v2388
			local v2391 = math.sin(v2389) * v2388
			local v2392 = Vector3.new(v2390, 0, v2391)
			local v2393 = CFrame.lookAt
			local v2394 = -math.sin(v2389)
			local v2395 = math.cos(v2389)
			local v_u_2396 = v2393(v2392, v2392 + Vector3.new(v2394, 0, v2395))
			local v2397 = p_u_2344.pieces
			local v2398 = {
				["part"] = v2387,
				["place"] = function()
					-- upvalues: (copy) v_u_2375, (copy) v_u_2396
					return v_u_2375.cf * v_u_2396
				end,
				["alpha"] = v2387.Transparency
			}
			table.insert(v2397, v2398)
			local v2399 = {
				["transparency"] = 0,
				["material"] = nil,
				["material"] = Enum.Material.SmoothPlastic
			}
			local v2400 = v_u_7.part(Vector3.new(0.34, 0.34, 0.8), CFrame.identity, v2348, v2399)
			local v2401 = Instance.new("SpecialMesh")
			v2401.MeshType = Enum.MeshType.Sphere
			v2401.Parent = v2400
			local v2402 = v_u_2367.r - 0.12
			local v2403 = v2385 + v2383 * 0.2
			local v2404 = math.cos(v2403) * v2402
			local v2405 = math.sin(v2403) * v2402
			local v2406 = Vector3.new(v2404, 0, v2405)
			local v2407 = CFrame.lookAt
			local v2408 = -math.sin(v2403)
			local v2409 = math.cos(v2403)
			local v_u_2410 = v2407(v2406, v2406 + Vector3.new(v2408, 0, v2409))
			local v2411 = p_u_2344.pieces
			local v2412 = {
				["part"] = v2400,
				["place"] = function()
					-- upvalues: (copy) v_u_2375, (copy) v_u_2410
					return v_u_2375.cf * v_u_2410
				end,
				["alpha"] = v2400.Transparency
			}
			table.insert(v2411, v2412)
		end
	end
	local function v_u_2417(p2413, p2414)
		local v2415 = CFrame.new
		local v2416 = p2414 * 1.3
		return p2413 * v2415(2.6, math.sin(v2416) * 0.12 + -0.1, -0.3) * CFrame.Angles(0, 0, -0.10471975511965978)
	end
	local v_u_2418 = {
		["cf"] = CFrame.identity
	}
	local v2419 = p_u_2344.ticks
	table.insert(v2419, function(p2420, p2421)
		-- upvalues: (copy) v_u_2418, (copy) v_u_2417
		v_u_2418.cf = v_u_2417(p2420, p2421)
	end)
	local v2422 = {
		["transparency"] = 0,
		["material"] = nil,
		["material"] = Enum.Material.SmoothPlastic
	}
	local v2423 = v_u_7.part(Vector3.new(0.18, 5.4, 0.18), CFrame.identity, v_u_2346, v2422)
	local v_u_2424 = CFrame.identity
	local v2425 = p_u_2344.pieces
	local v2426 = {
		["part"] = v2423,
		["place"] = function()
			-- upvalues: (copy) v_u_2418, (copy) v_u_2424
			return v_u_2418.cf * v_u_2424
		end,
		["alpha"] = v2423.Transparency
	}
	table.insert(v2425, v2426)
	local v2427 = v_u_1362(1.6, v_u_12.Ring, v_u_2346, 0)
	local v_u_2428 = CFrame.new(0, 3.2, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
	local v2429 = p_u_2344.pieces
	local v2430 = {
		["part"] = v2427,
		["place"] = function()
			-- upvalues: (copy) v_u_2418, (copy) v_u_2428
			return v_u_2418.cf * v_u_2428
		end,
		["alpha"] = v2427.Transparency
	}
	table.insert(v2429, v2430)
	local v2431 = v_u_7.part(Vector3.new(0.45, 0.45, 0.45), CFrame.identity, v2347, {
		["shape"] = nil,
		["transparency"] = 0,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_2432 = CFrame.new(0, 3.2, 0)
	local v2433 = p_u_2344.pieces
	local v2434 = {
		["part"] = v2431,
		["place"] = function()
			-- upvalues: (copy) v_u_2418, (copy) v_u_2432
			return v_u_2418.cf * v_u_2432
		end,
		["alpha"] = v2431.Transparency
	}
	table.insert(v2433, v2434)
	v_u_260(p_u_2344, "AuraMode", v_u_2346, {
		["rate"] = 0.5,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Glow", "Streaks" }
	})
	v_u_260(p_u_2344, "Petals", v2347, {
		["rate"] = 1,
		["glow"] = 0.7,
		["only"] = nil,
		["only"] = { "Motes" }
	})
end
function v_u_1353.w2_oracle_eye(p_u_2435, p2436)
	-- upvalues: (copy) v_u_7, (ref) v_u_238, (copy) v_u_1368, (copy) v_u_12, (copy) v_u_1387, (copy) v_u_1362, (copy) v_u_260
	local v_u_2437 = v_u_7.color(p2436.color)
	local v2438 = v_u_7.color(p2436.color2)
	local v_u_2439 = 0
	local v_u_2440 = -10
	local v_u_2441 = {}
	local function v_u_2443()
		-- upvalues: (ref) v_u_2439, (ref) v_u_2440, (copy) v_u_2441, (ref) v_u_7, (copy) v_u_2437
		v_u_2439 = v_u_2439 % 6 + 1
		v_u_2440 = os.clock()
		local v2442 = v_u_2441[v_u_2439]
		if v2442 then
			v_u_7.flash(v2442.Position, v_u_2437, 3, 0.3)
		end
	end
	local v_u_2444 = 0
	local v_u_2445 = 1.6
	local v2446 = p_u_2435.ticks
	local v_u_2447 = 4
	local v_u_2448 = 1.5
	local function v2453(p2449, p2450, p2451)
		-- upvalues: (ref) v_u_2445, (copy) v_u_2447, (ref) v_u_2444, (copy) v_u_2443, (ref) v_u_238, (copy) v_u_2448, (copy) p_u_2435
		if v_u_2445 <= p2450 then
			v_u_2445 = p2450 + v_u_2447
			v_u_2444 = 1
			if v_u_2443 and (p2449.Position - v_u_238).Magnitude < 150 then
				v_u_2443(p2449)
			end
		end
		local v2452 = v_u_2444 - p2451 * v_u_2448
		v_u_2444 = math.max(v2452, 0)
		p_u_2435.pulse = v_u_2444
	end
	table.insert(v2446, v2453)
	local function v_u_2456(p2454, p2455)
		return p2454 * CFrame.new(0, 0.15, 0) * CFrame.Angles(0.12, p2455 * 0.45, 0)
	end
	local v_u_2457 = {
		["cf"] = CFrame.identity
	}
	local v2458 = p_u_2435.ticks
	table.insert(v2458, function(p2459, p2460)
		-- upvalues: (copy) v_u_2457, (copy) v_u_2456
		v_u_2457.cf = v_u_2456(p2459, p2460)
	end)
	local v_u_2461 = Instance.new("Attachment")
	v_u_2461.Name = "FateThreads"
	v_u_2461.Position = Vector3.new(0, 0.4, 0)
	v_u_2461.Parent = p_u_2435.root
	v_u_2461:SetAttribute("FormExtra", true)
	local v2462 = p_u_2435.extras
	table.insert(v2462, v_u_2461)
	local v2463 = p_u_2435.stops
	table.insert(v2463, function()
		-- upvalues: (copy) v_u_2461
		v_u_2461:Destroy()
	end)
	local v_u_2464 = v_u_2439
	local v_u_2465 = v_u_2440
	for v_u_2466 = 1, 6 do
		local v2467 = (v_u_2466 - 1) / 6 * 3.141592653589793 * 2
		local v2468 = math.cos(v2467) * 3
		local v2469 = math.sin(v2467) * 3
		local v_u_2470 = Vector3.new(v2468, 0, v2469)
		local function v2479(_, p2471) -- name: place
			-- upvalues: (ref) v_u_2464, (copy) v_u_2466, (ref) v_u_2465, (copy) v_u_2457, (copy) v_u_2470
			local v2472
			if v_u_2464 == v_u_2466 then
				local v2473 = (os.clock() - v_u_2465) / 0.5
				v2472 = math.clamp(v2473, 0, 1) * 3.141592653589793 * 2
			else
				v2472 = 0
			end
			local v2474 = v_u_2457.cf
			local v2475 = CFrame.new
			local v2476 = v_u_2470
			local v2477 = p2471 * 1.4 + v_u_2466
			local v2478 = math.sin(v2477) * 0.3
			return v2474 * v2475(v2476 + Vector3.new(0, v2478, 0)) * CFrame.lookAt(Vector3.new(0, 0, 0), v_u_2470) * CFrame.Angles(0, p2471 * 0.9 + v_u_2466 * 1.1 + v2472, 0)
		end
		local v2480 = {
			["transparency"] = 0,
			["material"] = nil,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v2481 = v_u_7.part(Vector3.new(0.95, 1.4, 0.06), CFrame.identity, v2438, v2480)
		v_u_1368(v2481, v_u_12.MagicCircle, v_u_2437)
		local v2482 = p_u_2435.pieces
		local v2483 = {
			["part"] = v2481,
			["place"] = v2479,
			["alpha"] = v2481.Transparency
		}
		table.insert(v2482, v2483)
		local v2484 = v_u_7.part(Vector3.new(1.12, 1.57, 0.04), CFrame.identity, v_u_2437, {
			["transparency"] = 0.05,
			["material"] = nil
		})
		local v2485 = p_u_2435.pieces
		local v2486 = {
			["part"] = v2484,
			["place"] = v2479,
			["alpha"] = v2484.Transparency
		}
		table.insert(v2485, v2486)
		table.insert(v_u_2441, v2481)
		local v2487 = Instance.new("Attachment")
		v2487.Parent = v2481
		local v2488 = v_u_1387(v_u_2461, v2487, v_u_2437, 0.16, 0.28, v_u_12.BloodThread)
		v2488.CurveSize0 = 1.2
		v2488.LightEmission = 0.4
	end
	local function v_u_2493(p2489, p2490)
		local v2491 = CFrame.new
		local v2492 = p2490 * 1.7
		return p2489 * v2491(-2.4, math.sin(v2492) * 0.15 + 0.1, -0.6)
	end
	local v_u_2494 = {
		["cf"] = CFrame.identity
	}
	local v2495 = p_u_2435.ticks
	table.insert(v2495, function(p2496, p2497)
		-- upvalues: (copy) v_u_2494, (copy) v_u_2493
		v_u_2494.cf = v_u_2493(p2496, p2497)
	end)
	local v2498 = Enum.Material.SmoothPlastic
	local v2499 = v_u_7.part(Vector3.new(1.25, 1.25, 1.25), CFrame.identity, v2438, {
		["shape"] = nil,
		["transparency"] = 0.5,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball,
		["material"] = v2498
	})
	v2499.Reflectance = 0.35
	local v_u_2500 = CFrame.identity
	local v2501 = p_u_2435.pieces
	local v2502 = {
		["part"] = v2499,
		["place"] = function()
			-- upvalues: (copy) v_u_2494, (copy) v_u_2500
			return v_u_2494.cf * v_u_2500
		end,
		["alpha"] = v2499.Transparency
	}
	table.insert(v2501, v2502)
	local v2503 = v_u_7.part(Vector3.new(0.6, 0.6, 0.6), CFrame.identity, v_u_2437, {
		["shape"] = nil,
		["transparency"] = 0,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_2504 = CFrame.identity
	local v2505 = p_u_2435.pieces
	local v2506 = {
		["part"] = v2503,
		["place"] = function()
			-- upvalues: (copy) v_u_2494, (copy) v_u_2504
			return v_u_2494.cf * v_u_2504
		end,
		["alpha"] = v2503.Transparency
	}
	table.insert(v2505, v2506)
	local v2507 = v_u_1362(2.3, v_u_12.Ring, v_u_2437, 0.1)
	local v2508 = p_u_2435.pieces
	local v2510 = {
		["part"] = v2507,
		["place"] = function(_, p2509)
			-- upvalues: (copy) v_u_2494
			return v_u_2494.cf * CFrame.Angles(p2509 * 1.2, 0, 0.6)
		end,
		["alpha"] = v2507.Transparency
	}
	table.insert(v2508, v2510)
	local v2511 = v_u_1362(6.4, v_u_12.MagicCircle, v_u_2437, 0.25)
	local v2512 = p_u_2435.pieces
	local v2515 = {
		["part"] = v2511,
		["place"] = function(p2513, p2514)
			return p2513 * CFrame.new(0, 1.5, 1.5) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, p2514 * 0.3, 0)
		end,
		["alpha"] = v2511.Transparency
	}
	table.insert(v2512, v2515)
	v_u_260(p_u_2435, "AuraMode", v_u_2437, {
		["rate"] = 0.5,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Glow", "Sparks" }
	})
	v_u_260(p_u_2435, "Petals", v2438, {
		["rate"] = 0.9,
		["glow"] = 0.7,
		["only"] = nil,
		["only"] = { "Motes" }
	})
end
function v_u_1353.w2_celestial_gaze(p_u_2516, p2517)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_94, (copy) v_u_1362, (copy) v_u_15, (copy) v_u_260
	local v_u_2518 = v_u_7.color(p2517.color)
	local v2519 = v_u_7.color(p2517.color2)
	local v2520 = Color3.fromRGB(255, 255, 255)
	local function v_u_2526(p2521)
		-- upvalues: (ref) v_u_7, (copy) p_u_2516, (copy) v_u_2518, (ref) v_u_12
		local v2522 = v_u_7.ring
		local v2523 = p_u_2516
		local v2524 = p2521.Position
		local v2525 = v2523.feet + 0.15
		v2522(v2524 + Vector3.new(0, v2525, 0), v_u_2518, 5.5, 0.5, v_u_12.Ring)
	end
	local v_u_2527 = 0
	local v_u_2528 = 1.2
	local v2529 = p_u_2516.ticks
	local v_u_2530 = 3.5
	local v_u_2531 = 1.6
	local function v2536(p2532, p2533, p2534)
		-- upvalues: (ref) v_u_2528, (copy) v_u_2530, (ref) v_u_2527, (copy) v_u_2526, (ref) v_u_238, (copy) v_u_2531, (copy) p_u_2516
		if v_u_2528 <= p2533 then
			v_u_2528 = p2533 + v_u_2530
			v_u_2527 = 1
			if v_u_2526 and (p2532.Position - v_u_238).Magnitude < 150 then
				v_u_2526(p2532)
			end
		end
		local v2535 = v_u_2527 - p2534 * v_u_2531
		v_u_2527 = math.max(v2535, 0)
		p_u_2516.pulse = v_u_2527
	end
	table.insert(v2529, v2536)
	local function v_u_2539(p2537, p2538)
		return p2537 * CFrame.new(0, -0.1, 0) * CFrame.Angles(0.3839724354387525, 0, -0.17453292519943295) * CFrame.Angles(0, p2538 * 0.5, 0)
	end
	local v_u_2540 = {
		["cf"] = CFrame.identity
	}
	local v2541 = p_u_2516.ticks
	table.insert(v2541, function(p2542, p2543)
		-- upvalues: (copy) v_u_2540, (copy) v_u_2539
		v_u_2540.cf = v_u_2539(p2542, p2543)
	end)
	v_u_94(p_u_2516, v_u_2540, 14, 3.25, 0.2, v_u_2518, 0)
	for v2544 = 1, 3 do
		local v2545 = (v2544 - 1) / 3 * 3.141592653589793 * 2 + 0.4
		local v_u_2546 = CFrame.new(math.cos(v2545) * 3.25, 0, math.sin(v2545) * 3.25)
		local v2547 = ({ 0.95, 0.72, 0.55 })[v2544]
		local v2548
		if v2544 == 1 then
			v2548 = v2520
		else
			v2548 = v2519
		end
		local v2549 = v_u_7.part(Vector3.new(1, 1, 1) * v2547, CFrame.identity, v2548, {
			["shape"] = nil,
			["transparency"] = 0,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v2550 = p_u_2516.pieces
		local v2551 = {
			["part"] = v2549,
			["place"] = function()
				-- upvalues: (copy) v_u_2540, (copy) v_u_2546
				return v_u_2540.cf * v_u_2546
			end,
			["alpha"] = v2549.Transparency
		}
		table.insert(v2550, v2551)
		local v2552 = v2547 * 1.8
		local v2553 = v_u_7.part(Vector3.new(1, 1, 1) * v2552, CFrame.identity, v_u_2518, {
			["shape"] = nil,
			["transparency"] = 0.6,
			["material"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local function v_u_2554()
			-- upvalues: (copy) v_u_2540, (copy) v_u_2546
			return v_u_2540.cf * v_u_2546
		end
		local v_u_2555 = v2547 * 0.5
		local function v2560(p2556, p2557)
			-- upvalues: (copy) v_u_2554, (ref) v_u_238, (copy) v_u_2555
			local v2558 = v_u_2554(p2556, p2557)
			local v2559 = v2558.Position - v_u_238
			if v2559.Magnitude < 0.01 then
				return v2558
			else
				return v2558 + v2559.Unit * v_u_2555
			end
		end
		local v2561 = p_u_2516.pieces
		local v2562 = {
			["part"] = v2553,
			["place"] = v2560,
			["alpha"] = v2553.Transparency
		}
		table.insert(v2561, v2562)
	end
	local v2563 = v_u_1362(7.1, v_u_12.Ring, v2519, 0.25)
	local v2564 = p_u_2516.pieces
	local v2567 = {
		["part"] = v2563,
		["place"] = function(p2565, p2566)
			return p2565 * CFrame.new(0, -0.1, 0) * CFrame.Angles(0, p2566 * 0.35, 0) * CFrame.Angles(1.3089969389957472, 0, 0)
		end,
		["alpha"] = v2563.Transparency
	}
	table.insert(v2564, v2567)
	local function v_u_2570(p2568, p2569)
		-- upvalues: (copy) p_u_2516
		return p2568 * CFrame.new(0, p_u_2516.headY + p_u_2516.eyeLift, 0) * CFrame.Angles(0, 0, p2569 * 0.4)
	end
	local v_u_2571 = {
		["cf"] = CFrame.identity
	}
	local v2572 = p_u_2516.ticks
	table.insert(v2572, function(p2573, p2574)
		-- upvalues: (copy) v_u_2571, (copy) v_u_2570
		v_u_2571.cf = v_u_2570(p2573, p2574)
	end)
	for v2575 = 0, 3 do
		local v_u_2576 = CFrame.Angles(0, 0, v2575 / 4 * 3.141592653589793) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v2577 = v2575 % 2 == 0 and 4.6 or 3.1
		local v2578 = Vector3.new(0.32, 0.32, v2577)
		local v2579
		if v2575 % 2 == 0 then
			v2579 = v_u_2518
		else
			v2579 = v2519
		end
		local v2580 = v_u_7.part(v2578, CFrame.identity, v2579, {
			["transparency"] = 0.05,
			["material"] = nil
		})
		local v2581 = Instance.new("SpecialMesh")
		v2581.MeshType = Enum.MeshType.Sphere
		v2581.Parent = v2580
		local function v_u_2582()
			-- upvalues: (copy) v_u_2571, (copy) v_u_2576
			return v_u_2571.cf * v_u_2576
		end
		local v_u_2583 = 0.7
		local function v2588(p2584, p2585)
			-- upvalues: (copy) v_u_2582, (ref) v_u_238, (copy) v_u_2583
			local v2586 = v_u_2582(p2584, p2585)
			local v2587 = v2586.Position - v_u_238
			if v2587.Magnitude < 0.01 then
				return v2586
			else
				return v2586 + v2587.Unit * v_u_2583
			end
		end
		local v2589 = p_u_2516.pieces
		local v2590 = {
			["part"] = v2580,
			["place"] = v2588,
			["alpha"] = v2580.Transparency
		}
		table.insert(v2589, v2590)
	end
	local v2591 = {}
	local v_u_2592 = {}
	for v_u_2593, v_u_2594 in {
		Vector3.new(-1.3, 2.4, 1.1),
		Vector3.new(-2.5, 1.8, 1.2),
		Vector3.new(-3.3, 0.6, 1.1),
		Vector3.new(1.3, 2.4, 1.1),
		Vector3.new(2.5, 1.8, 1.2),
		Vector3.new(3.3, 0.6, 1.1)
	} do
		local v2595 = v_u_7.part(Vector3.new(0.45, 0.45, 0.45), CFrame.identity, v2520, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v_u_2596 = Instance.new("SpecialMesh")
		v_u_2596.MeshType = Enum.MeshType.Brick
		v_u_2596.Parent = v2595
		local v2597 = p_u_2516.pieces
		local v2604 = {
			["part"] = v2595,
			["place"] = function(p2598, p2599)
				-- upvalues: (copy) v_u_2594, (copy) v_u_2593
				local v2600 = CFrame.new
				local v2601 = v_u_2594
				local v2602 = p2599 * 1.2 + v_u_2593
				local v2603 = math.sin(v2602) * 0.08
				return p2598 * v2600(v2601 + Vector3.new(0, v2603, 0)) * CFrame.Angles(0, 0, 0.7853981633974483)
			end,
			["alpha"] = v2595.Transparency
		}
		table.insert(v2597, v2604)
		local v2605 = p_u_2516.ticks
		table.insert(v2605, function(_, p2606)
			-- upvalues: (copy) v_u_2596, (copy) v_u_2593
			local v2607 = v_u_2596
			local v2608 = p2606 * 2.3 + v_u_2593 * 1.9
			local v2609 = math.sin(v2608)
			v2607.Scale = Vector3.new(1, 1, 1) * (math.abs(v2609) * 0.4 + 0.7)
		end)
		local v2610 = Instance.new("Attachment")
		v2610.Parent = v2595
		v2591[v_u_2593] = v2610
		v_u_2592[v_u_2593] = v2595
	end
	for _, v2611 in {
		{ 1, 2 },
		{ 2, 3 },
		{ 4, 5 },
		{ 5, 6 },
		{ 1, 4 }
	} do
		local v2612 = v2591[v2611[1]]
		local v2613 = v2591[v2611[2]]
		local v2614 = Instance.new("Beam")
		v2614.Attachment0 = v2612
		v2614.Attachment1 = v2613
		v2614.Color = ColorSequence.new(v2519)
		v2614.Width0 = 0.09
		v2614.Width1 = 0.09
		v2614.LightEmission = 0.6
		v2614.LightInfluence = 0
		v2614.FaceCamera = true
		v2614.Segments = 1
		v2614.Parent = v2612
		v2614.LightEmission = 1
		v2614.Transparency = NumberSequence.new(0.25)
	end
	local v_u_2615 = 1
	local v2616 = p_u_2516.ticks
	local function v2619(p2617, p2618)
		-- upvalues: (ref) v_u_2615, (ref) v_u_238, (ref) v_u_7, (copy) v_u_2592, (ref) v_u_15
		if v_u_2615 <= p2618 then
			v_u_2615 = p2618 + 1.4
			if (p2617.Position - v_u_238).Magnitude < 120 then
				v_u_7.burst("Sparkle", v_u_2592[v_u_15:NextInteger(1, #v_u_2592)].Position, nil, 0.3)
			end
		end
	end
	table.insert(v2616, v2619)
	v_u_260(p_u_2516, "AuraMode", v_u_2518, {
		["rate"] = 0.6,
		["glow"] = 0.6,
		["only"] = nil,
		["only"] = { "Glow", "Streaks", "Sparks" }
	})
	v_u_260(p_u_2516, "Petals", v2519, {
		["rate"] = 1.2,
		["glow"] = 0.7,
		["only"] = nil,
		["only"] = { "Motes" }
	})
end
function v_u_1353.w2_prism_eye(p_u_2620, p2621)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (ref) v_u_238, (copy) v_u_236, (copy) v_u_1387, (copy) v_u_1389, (copy) v_u_260
	local v2622 = v_u_7.color(p2621.color)
	local v2623 = v_u_7.color(p2621.color2)
	local v2624 = Color3.fromRGB(255, 255, 255)
	local v_u_2625 = {}
	local v_u_2626 = 0
	local function v_u_2634(p2627)
		-- upvalues: (ref) v_u_7, (copy) p_u_2620, (ref) v_u_2626, (ref) v_u_12
		local v2628 = v_u_7.ring
		local v2629 = p_u_2620
		local v2630 = p2627.Position
		local v2631 = v2629.feet + 0.15
		local v2632 = v2630 + Vector3.new(0, v2631, 0)
		local v2633 = v_u_2626
		v2628(v2632, Color3.fromHSV(v2633 % 1, 0.72, 1), 6 * p_u_2620.fx, 0.5, v_u_12.Ring)
	end
	local v_u_2635 = 0
	local v_u_2636 = 1
	local v2637 = p_u_2620.ticks
	local v_u_2638 = 3
	local v_u_2639 = 1.8
	local function v2644(p2640, p2641, p2642)
		-- upvalues: (ref) v_u_2636, (copy) v_u_2638, (ref) v_u_2635, (copy) v_u_2634, (ref) v_u_238, (copy) v_u_2639, (copy) p_u_2620
		if v_u_2636 <= p2641 then
			v_u_2636 = p2641 + v_u_2638
			v_u_2635 = 1
			if v_u_2634 and (p2640.Position - v_u_238).Magnitude < 150 then
				v_u_2634(p2640)
			end
		end
		local v2643 = v_u_2635 - p2642 * v_u_2639
		v_u_2635 = math.max(v2643, 0)
		p_u_2620.pulse = v_u_2635
	end
	table.insert(v2637, v2644)
	local function v_u_2645()
		-- upvalues: (ref) v_u_2635
		return v_u_2635
	end
	local v2646 = p_u_2620.ticks
	local function v2651(_, _, p2647)
		-- upvalues: (ref) v_u_2626, (copy) v_u_2645, (copy) v_u_2625
		v_u_2626 = (v_u_2626 + p2647 * (0.1 + v_u_2645() * 0.6)) % 1
		for _, v2648 in v_u_2625 do
			local v2649 = v2648.part
			local v2650 = v2648.offset + v_u_2626
			v2649.Color = Color3.fromHSV(v2650 % 1, 0.72, 1)
		end
	end
	table.insert(v2646, v2651)
	local function v_u_2656(p2652, p2653)
		-- upvalues: (copy) v_u_2645
		local v2654 = CFrame.new
		local v2655 = p2653 * 1.8
		return p2652 * v2654(0, math.sin(v2655) * 0.12 + 0.2 + v_u_2645() * 0.35, 0)
	end
	local v_u_2657 = {
		["cf"] = CFrame.identity
	}
	local v2658 = p_u_2620.ticks
	table.insert(v2658, function(p2659, p2660)
		-- upvalues: (copy) v_u_2657, (copy) v_u_2656
		v_u_2657.cf = v_u_2656(p2659, p2660)
	end)
	local v_u_2661 = v_u_2626
	local v2662 = {
		3.9,
		3.4,
		2.9,
		2.3,
		1.7
	}
	local v_u_2663 = {
		64,
		42,
		20,
		-2,
		-22
	}
	for _, v_u_2664 in v_u_236(p_u_2620, v_u_2657, "PrismWings", 1.25, CFrame.new(0, 0.3, 0.25), true) and {} or { -1, 1 } do
		for v_u_2665 = 1, 5 do
			local v_u_2666 = v2662[v_u_2665]
			local v2667 = Vector3.new(0.42, 0.42, v_u_2666)
			local v2668 = v_u_7.part(v2667, CFrame.identity, v2622, {
				["transparency"] = 0.12,
				["material"] = nil
			})
			local v2669 = {
				["part"] = v2668,
				["offset"] = v_u_2665 * 0.13 + (v_u_2664 > 0 and 0.5 or 0)
			}
			table.insert(v_u_2625, v2669)
			local v2670 = p_u_2620.pieces
			local v2682 = {
				["part"] = v2668,
				["place"] = function(p2671, p2672)
					-- upvalues: (copy) v_u_2663, (copy) v_u_2665, (copy) v_u_2645, (copy) v_u_2664, (copy) v_u_2666
					local v2673 = v_u_2663[v_u_2665]
					local v2674 = p2672 * 1.8
					local v2675 = v2673 + math.sin(v2674) * 7 + v_u_2645() * 8
					local v2676 = math.rad(v2675)
					local v2677 = v_u_2664 * math.cos(v2676)
					local v2678 = math.sin(v2676)
					local v2679 = Vector3.new(v2677, v2678, 0.35).Unit
					local v2680 = v_u_2664 * 0.55
					local v2681 = Vector3.new(v2680, 0.85, 0.65) + v2679 * v_u_2666 / 2
					return p2671 * CFrame.lookAt(v2681, v2681 + v2679) * CFrame.Angles(0, 0, 0.7853981633974483)
				end,
				["alpha"] = v2668.Transparency
			}
			table.insert(v2670, v2682)
		end
	end
	local function v_u_2688(p2683, p2684)
		-- upvalues: (copy) p_u_2620
		local v2685 = CFrame.new
		local v2686 = p_u_2620.headY + p_u_2620.eyeLift + 2.5
		local v2687 = p2684 * 1.6
		return p2683 * v2685(0, v2686 + math.sin(v2687) * 0.12, 0) * CFrame.Angles(0, p2684 * 0.8, 0)
	end
	local v_u_2689 = {
		["cf"] = CFrame.identity
	}
	local v2690 = p_u_2620.ticks
	table.insert(v2690, function(p2691, p2692)
		-- upvalues: (copy) v_u_2689, (copy) v_u_2688
		v_u_2689.cf = v_u_2688(p2691, p2692)
	end)
	for _, v2693 in { -1, 1 } do
		local v2694 = v_u_7.part(Vector3.new(2.2, 1.5, 0.87), CFrame.identity, v2624, {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.3,
			["shape"] = Enum.PartType.Wedge,
			["material"] = Enum.Material.SmoothPlastic
		})
		v2694.Reflectance = 0.35
		local v_u_2695 = CFrame.new(0, 0, v2693 * 0.435) * CFrame.Angles(0, v2693 > 0 and 3.141592653589793 or 0, 0)
		local v2696 = p_u_2620.pieces
		local v2697 = {
			["part"] = v2694,
			["place"] = function()
				-- upvalues: (copy) v_u_2689, (copy) v_u_2695
				return v_u_2689.cf * v_u_2695
			end,
			["alpha"] = v2694.Transparency
		}
		table.insert(v2696, v2697)
	end
	local v2698 = v_u_7.part(Vector3.new(1.1, 1.1, 1.1), CFrame.identity, v2624, {
		["shape"] = nil,
		["transparency"] = 0.35,
		["material"] = nil,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_2699 = CFrame.new(0, -0.2, 0)
	local v2700 = p_u_2620.pieces
	local v2701 = {
		["part"] = v2698,
		["place"] = function()
			-- upvalues: (copy) v_u_2689, (copy) v_u_2699
			return v_u_2689.cf * v_u_2699
		end,
		["alpha"] = v2698.Transparency
	}
	table.insert(v2700, v2701)
	local v2702 = Instance.new("Attachment")
	v2702.Parent = v2698
	local v2703 = Instance.new("Attachment")
	v2703.Position = Vector3.new(0, 45, 0)
	v2703.Parent = v2698
	local v2704 = v_u_1387(v2703, v2702, v2624, 0.45, 0.7, v_u_12.Beam)
	v2704.LightEmission = 1
	v2704.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.6, 0.35), NumberSequenceKeypoint.new(1, 0.1) })
	local v_u_2705 = {}
	local v_u_2706 = {}
	for v2707 = 1, 6 do
		local v_u_2708 = Instance.new("Attachment")
		v_u_2708.Name = "PrismRay"
		v_u_2708.Parent = p_u_2620.root
		local v2709 = p_u_2620.stops
		table.insert(v2709, function()
			-- upvalues: (copy) v_u_2708
			v_u_2708:Destroy()
		end)
		local v2710 = v_u_1387
		local v2711 = v2707 / 6
		local v2712 = v2710(v2702, v_u_2708, Color3.fromHSV(v2711 % 1, 0.72, 1), 0.25, 1.1, v_u_12.Beam)
		v2712.Transparency = NumberSequence.new(0.15, 0.55)
		table.insert(v_u_2705, v2712)
		v_u_2706[v2707] = v_u_2708
	end
	local v2713 = p_u_2620.ticks
	local function v2723(_, p2714)
		-- upvalues: (copy) v_u_2645, (copy) v_u_2705, (copy) v_u_2706, (copy) p_u_2620, (ref) v_u_1389, (ref) v_u_2661
		local v2715 = v_u_2645()
		for v2716, v2717 in v_u_2705 do
			local v2718 = (v2716 - 1) / 6 * 3.141592653589793 * 2 + p2714 * 0.6
			local v2719 = v_u_2706[v2716]
			local v2720 = math.cos(v2718) * 3.4
			local v2721 = p_u_2620.feet + 0.15
			local v2722 = math.sin(v2718) * 3.4
			v2719.Position = Vector3.new(v2720, v2721, v2722)
			v2717.Color = ColorSequence.new(v_u_1389(v2716 / 6 + v_u_2661))
			v2717.Width1 = 1.1 + v2715 * 0.9
		end
	end
	table.insert(v2713, v2723)
	local function v_u_2726(p2724, p2725)
		-- upvalues: (copy) p_u_2620
		return p2724 * CFrame.new(0, p_u_2620.headY + p_u_2620.eyeLift, 0) * CFrame.Angles(0, 0, -p2725 * 0.5)
	end
	local v_u_2727 = {
		["cf"] = CFrame.identity
	}
	local v2728 = p_u_2620.ticks
	table.insert(v2728, function(p2729, p2730)
		-- upvalues: (copy) v_u_2727, (copy) v_u_2726
		v_u_2727.cf = v_u_2726(p2729, p2730)
	end)
	for v2731 = 1, 12 do
		local v2732 = (v2731 - 0.5) / 12 * 3.141592653589793 * 2
		local v2733 = math.cos(v2732) * 2
		local v2734 = math.sin(v2732) * 2
		local v2735 = Vector3.new(v2733, v2734, 0)
		local v2736 = -math.sin(v2732)
		local v2737 = math.cos(v2732)
		local v2738 = Vector3.new(v2736, v2737, 0)
		local v2739 = v_u_7.part(Vector3.new(0.24, 0.24, 1.1552762), CFrame.identity, v2623, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v2740 = {
			["part"] = v2739,
			["offset"] = v2731 / 12
		}
		table.insert(v_u_2625, v2740)
		local v_u_2741 = CFrame.lookAt(v2735, v2735 + v2738)
		local function v_u_2742()
			-- upvalues: (copy) v_u_2727, (copy) v_u_2741
			return v_u_2727.cf * v_u_2741
		end
		local v_u_2743 = 0.6
		local function v2748(p2744, p2745)
			-- upvalues: (copy) v_u_2742, (ref) v_u_238, (copy) v_u_2743
			local v2746 = v_u_2742(p2744, p2745)
			local v2747 = v2746.Position - v_u_238
			if v2747.Magnitude < 0.01 then
				return v2746
			else
				return v2746 + v2747.Unit * v_u_2743
			end
		end
		local v2749 = p_u_2620.pieces
		local v2750 = {
			["part"] = v2739,
			["place"] = v2748,
			["alpha"] = v2739.Transparency
		}
		table.insert(v2749, v2750)
	end
	for v_u_2751 = 1, 6 do
		local v2752 = v_u_7.part(Vector3.new(0.38, 0.95, 0.38), CFrame.identity, v2622, {
			["transparency"] = 0,
			["material"] = nil
		})
		local v2753 = {
			["part"] = v2752,
			["offset"] = v_u_2751 / 6 + 0.25
		}
		table.insert(v_u_2625, v2753)
		local v2754 = p_u_2620.pieces
		local v2761 = {
			["part"] = v2752,
			["place"] = function(p2755, p2756)
				-- upvalues: (copy) v_u_2751
				local v2757 = (v_u_2751 - 1) / 6 * 3.141592653589793 * 2 + p2756 * 0.9
				local v2758 = CFrame.new
				local v2759 = math.cos(v2757) * 2.6
				local v2760 = p2756 * 1.6 + v_u_2751
				return p2755 * v2758(v2759, math.sin(v2760) * 0.35 + -0.8, math.sin(v2757) * 2.6) * CFrame.Angles(0, p2756 * 2 + v_u_2751, 0.7853981633974483)
			end,
			["alpha"] = v2752.Transparency
		}
		table.insert(v2754, v2761)
	end
	local v2762 = {}
	for v2763 = 0, 6 do
		local v2764 = ColorSequenceKeypoint.new
		local v2765 = v2763 / 6
		local v2766 = v_u_1389
		local v2767 = v2763 / 6
		table.insert(v2762, v2764(v2765, v2766(v2767)))
	end
	local v_u_2768 = ColorSequence.new(v2762)
	local function v2771(p2769) -- name: paint
		-- upvalues: (copy) v_u_2768
		if p2769 then
			for _, v2770 in p2769:GetChildren() do
				if not v2770:IsA("ParticleEmitter") then
					continue
				end
				v2770.Color = v_u_2768
			end
		end
	end
	v2771((v_u_260(p_u_2620, "AuraMode", v2622, {
		["rate"] = 0.6,
		["glow"] = 0.55,
		["only"] = nil,
		["only"] = { "Glow", "Streaks", "Sparks" }
	})))
	v2771((v_u_260(p_u_2620, "Petals", v2624, {
		["rate"] = 1.2,
		["glow"] = 0.7,
		["only"] = nil,
		["only"] = { "Motes" }
	})))
end
local v_u_2808 = require(script.Parent.Forms3)({
	["rgb"] = v_u_19,
	["add"] = v25,
	["own"] = v29,
	["group"] = v36,
	["pin"] = v43,
	["bar"] = v48,
	["ball"] = v53,
	["disc"] = v58,
	["blob"] = v65,
	["dark"] = v67,
	["between"] = v70,
	["ring"] = v_u_94,
	["behind"] = v141,
	["truthOrb"] = v_u_163,
	["ripples"] = v_u_291,
	["beat"] = v270,
	["particles"] = v_u_260,
	["formMesh"] = v_u_179,
	["blacken"] = v241,
	["backOf"] = v_u_193,
	["glue"] = v_u_216,
	["worn"] = v_u_236,
	["wornOnBody"] = v_u_312,
	["fadeFromBehind"] = function(p2772, p_u_2773, p_u_2774) -- name: fadeFromBehind
		-- upvalues: (copy) v_u_3, (copy) v_u_6
		if p2772.character == v_u_3.LocalPlayer.Character then
			local v2775 = p2772.ticks
			local function v2780(p2776)
				-- upvalues: (ref) v_u_6, (copy) p_u_2773, (copy) p_u_2774
				local v2777 = v_u_6.CurrentCamera
				if v2777 then
					local v2778 = p_u_2773
					local v2779 = (v2777.CFrame.LookVector:Dot(p2776.LookVector) + 0.1) * 1.6
					v2778.LocalTransparencyModifier = math.clamp(v2779, 0, 1) * p_u_2774
				end
			end
			table.insert(v2775, v2780)
		end
	end,
	["stretchy"] = function(p2781) -- name: stretchy
		-- upvalues: (copy) v_u_7
		local v2782 = v_u_7.part(Vector3.new(1, 1, 1), CFrame.identity, p2781, {
			["transparency"] = 1,
			["material"] = nil
		})
		local v2783 = Instance.new("SpecialMesh")
		v2783.MeshType = Enum.MeshType.Brick
		v2783.Parent = v2782
		return v2782, v2783
	end,
	["scalable"] = function(p2784) -- name: scalable
		local v2785 = Instance.new("SpecialMesh")
		v2785.MeshType = Enum.MeshType.Brick
		v2785.Parent = p2784
		return v2785
	end,
	["crownOf"] = function(p_u_2786) -- name: crownOf
		local v_u_2787 = p_u_2786.character:FindFirstChild("Head")
		if not (v_u_2787 and v_u_2787:IsA("BasePart")) then
			v_u_2787 = nil
		end
		return function(p2788)
			-- upvalues: (copy) v_u_2787, (copy) p_u_2786
			if v_u_2787 and v_u_2787.Parent then
				return v_u_2787.CFrame
			else
				return p2788 * CFrame.new(0, p_u_2786.headY, 0)
			end
		end
	end,
	["picture"] = v_u_1362,
	["bothFaces"] = v_u_1368,
	["tail"] = v_u_1379,
	["ray"] = v_u_1387,
	["hue"] = v_u_1389,
	["throb"] = function(p_u_2789, p_u_2790, p2791, p_u_2792, p_u_2793) -- name: throb
		-- upvalues: (ref) v_u_238
		local v_u_2794 = 0
		local v_u_2795 = p2791
		local v2796 = p_u_2789.ticks
		local function v2801(p2797, p2798, p2799)
			-- upvalues: (ref) v_u_2795, (copy) p_u_2790, (ref) v_u_2794, (copy) p_u_2793, (ref) v_u_238, (copy) p_u_2792, (copy) p_u_2789
			if v_u_2795 <= p2798 then
				v_u_2795 = p2798 + p_u_2790
				v_u_2794 = 1
				if p_u_2793 and (p2797.Position - v_u_238).Magnitude < 150 then
					p_u_2793(p2797)
				end
			end
			local v2800 = v_u_2794 - p2799 * p_u_2792
			v_u_2794 = math.max(v2800, 0)
			p_u_2789.pulse = v_u_2794
		end
		table.insert(v2796, v2801)
		return function()
			-- upvalues: (ref) v_u_2794
			return v_u_2794
		end
	end,
	["feetAt"] = function(p2802, p2803, p2804) -- name: feetAt
		local v2805 = p2803.Position
		local v2806 = p2802.feet + p2804
		return v2805 + Vector3.new(0, v2806, 0)
	end,
	["camPos"] = function() -- name: camPos
		-- upvalues: (ref) v_u_238
		return v_u_238
	end,
	["iris"] = function(p2807) -- name: iris
		-- upvalues: (copy) v_u_14
		return v_u_14[p2807] or v_u_14.sharingan
	end
})
local v_u_2809 = {}
local v_u_2810 = nil
local v_u_2811 = {}
local v_u_2812 = {}
local v_u_2813 = {}
local function v_u_2827(p2814, p2815) -- name: setHidden
	if p2814.hidden == p2815 then
		return
	else
		p2814.hidden = p2815
		if p2815 then
			local v_u_2816 = {}
			local function v2822(p2817) -- name: quiet
				-- upvalues: (copy) v_u_2816
				local v2818 = p2817:GetDescendants()
				table.insert(v2818, p2817)
				for _, v2819 in v2818 do
					if (v2819:IsA("ParticleEmitter") or (v2819:IsA("Beam") or (v2819:IsA("Light") or v2819:IsA("Trail")))) and v2819.Enabled then
						v2819.Enabled = false
						local v2820 = v_u_2816
						table.insert(v2820, v2819)
					else
						if not (v2819:IsA("LayerCollector") and v2819.Enabled) then
							continue
						end
						v2819.Enabled = false
						local v2821 = v_u_2816
						table.insert(v2821, v2819)
					end
				end
			end
			for _, v2823 in p2814.pieces do
				v2823.part.LocalTransparencyModifier = 1
				v2822(v2823.part)
			end
			for _, v2824 in p2814.extras do
				if not v2824.Parent then
					continue
				end
				v2822(v2824)
			end
			p2814.off = v_u_2816
		else
			for _, v2825 in p2814.pieces do
				v2825.part.LocalTransparencyModifier = 0
			end
			for _, v2826 in p2814.off do
				if not v2826.Parent then
					continue
				end
				v2826.Enabled = true
			end
			p2814.off = {}
		end
	end
end
v_u_9.onChanged(function()
	-- upvalues: (copy) v_u_9, (copy) v_u_2809
	local v2828 = v_u_9.formRate()
	for v2829 in v_u_2809 do
		for _, v2830 in v2829.extras do
			for _, v2831 in v2830:GetDescendants() do
				local v2832 = v2831:GetAttribute("BaseRate")
				if not v2831:IsA("ParticleEmitter") or type(v2832) ~= "number" then
					continue
				end
				v2831.Rate = v2832 * v2828
			end
		end
	end
end)
local v_u_2833 = 0
local v_u_2834 = nil
local function v_u_2858(p2835) -- name: cull
	-- upvalues: (copy) v_u_3, (copy) v_u_2809, (copy) v_u_2827, (copy) v_u_2811, (copy) v_u_6, (copy) v_u_9, (ref) v_u_2834
	local v2836 = v_u_3.LocalPlayer.Character
	for v2837 in v_u_2809 do
		if v2837.character == v2836 then
			if v2837.hidden == false then
				continue
			end
			v2837.hidden = false
			for _, v2838 in v2837.pieces do
				v2838.part.LocalTransparencyModifier = 0
			end
			for _, v2839 in v2837.off do
				if not v2839.Parent then
					continue
				end
				v2839.Enabled = true
			end
			v2837.off = {}
		else
			if not v2837.fixed then
				continue
			end
			v_u_2827(v2837, (v2837.root.Position - p2835).Magnitude > 400)
		end
	end
	local v2840 = {}
	for v2841 in v_u_2811 do
		if v2841.form and v2841.form.stopped then
			v2841.form = nil
		end
		if not v2841.root:IsDescendantOf(v_u_6) then
			continue
		end
		local v2842 = {
			["slot"] = v2841,
			["d"] = (v2841.root.Position - p2835).Magnitude
		}
		table.insert(v2840, v2842)
	end
	table.sort(v2840, function(p2843, p2844)
		return p2843.d < p2844.d
	end)
	local v2845 = v_u_9.formBudget()
	local v2846 = os.clock()
	local v2847 = 0
	for v2848, v2849 in v2840 do
		local v2850 = v2849.slot
		local v2851 = v2850.form
		local v2852
		if v2851 == nil then
			v2852 = false
		else
			v2852 = not v2851.hidden
		end
		local v2853
		if v2849.d <= 400 then
			local v2854
			if v2852 then
				v2854 = v2845 + 1
			else
				v2854 = v2845
			end
			v2853 = v2848 <= v2854
		else
			v2853 = false
		end
		if v2853 then
			v2850.hiddenAt = nil
			if v2851 then
				if v2851.hidden == false then
					continue
				end
				v2851.hidden = false
				for _, v2855 in v2851.pieces do
					v2855.part.LocalTransparencyModifier = 0
				end
				for _, v2856 in v2851.off do
					if not v2856.Parent then
						continue
					end
					v2856.Enabled = true
				end
				v2851.off = {}
			else
				if v2847 >= 2 then
					continue
				end
				v2847 = v2847 + 1
				local v2857
				if v2846 - v2850.created < 1.5 and v2849.d < 80 then
					v2857 = v2850.player
				else
					v2857 = nil
				end
				v2850.form = v_u_2834(v2850.character, v2850.root, v2850.feet, v2850.eye, v2857)
			end
		else
			if not v2851 then
				continue
			end
			v_u_2827(v2851, true)
			v2850.hiddenAt = v2850.hiddenAt or v2846
			if v2846 - v2850.hiddenAt <= 10 then
				continue
			end
			v2851.stop()
			v2850.form = nil
			v2850.hiddenAt = nil
		end
	end
end
local function v_u_2872() -- name: step
	-- upvalues: (copy) v_u_6, (ref) v_u_238, (copy) v_u_3, (ref) v_u_2833, (copy) v_u_2858, (copy) v_u_2812, (copy) v_u_2813, (copy) v_u_2809, (copy) v_u_9, (copy) v_u_2811, (ref) v_u_2810
	local v2859 = os.clock()
	local v2860 = v_u_6.CurrentCamera
	local v2861 = not v2860 and Vector3.new(0, 0, 0) or v2860.CFrame.Position
	v_u_238 = v2861
	local v2862 = v_u_3.LocalPlayer.Character
	if v2859 - v_u_2833 >= 0.5 then
		v_u_2833 = v2859
		v_u_2858(v2861)
	end
	table.clear(v_u_2812)
	table.clear(v_u_2813)
	local v2863 = 0
	for v2864 in v_u_2809 do
		if v2864.root:IsDescendantOf(v_u_6) then
			if v2864.hidden then
				continue
			end
			local v2865 = v2864.root.CFrame
			local v2866 = v2859 - v2864.last
			if v2864.character ~= v2862 and v2866 + 0.005 < v_u_9.frameGap((v2865.Position - v2861).Magnitude) then
				continue
			end
			v2864.last = v2859
			local v2867 = math.min(v2866, 0.25)
			local v2868 = v2859 - v2864.started
			local v2869 = v2864.flare - v2867 * 2
			v2864.flare = math.max(v2869, 0)
			for _, v2870 in v2864.ticks do
				v2870(v2865, v2868, v2867)
			end
			for _, v2871 in v2864.pieces do
				if not v2871.part.Parent or v2871.weld then
					continue
				end
				v2863 = v2863 + 1
				v_u_2812[v2863] = v2871.part
				v_u_2813[v2863] = v2871.place(v2865, v2868)
			end
		else
			v2864.stop()
		end
	end
	if v2863 > 0 then
		v_u_6:BulkMoveTo(v_u_2812, v_u_2813, Enum.BulkMoveMode.FireCFrameChanged)
	end
	if next(v_u_2809) == nil and (next(v_u_2811) == nil and v_u_2810) then
		v_u_2810:Disconnect()
		v_u_2810 = nil
	end
end
v_u_2834 = function(p2873, p2874, p2875, p2876, p2877) -- name: begin
	-- upvalues: (copy) v_u_7, (copy) v_u_3, (copy) v_u_8, (copy) v_u_1353, (copy) v_u_2808, (ref) v_u_237, (copy) v_u_9, (copy) v_u_260, (copy) v_u_365, (copy) v_u_2809, (copy) v_u_2, (ref) v_u_2810, (copy) v_u_5, (copy) v_u_2872
	local v2878 = p2873:FindFirstChild("Head")
	local v2879 = os.clock()
	local v_u_2880 = {
		["character"] = nil,
		["root"] = nil,
		["feet"] = nil,
		["headY"] = nil,
		["pieces"] = nil,
		["ticks"] = nil,
		["stops"] = nil,
		["started"] = nil,
		["last"] = nil,
		["flare"] = 0,
		["pulse"] = 0,
		["eyeLift"] = 2.6,
		["stopped"] = false,
		["hidden"] = false,
		["extras"] = nil,
		["off"] = nil,
		["fixed"] = false,
		["fx"] = 1,
		["stop"] = nil,
		["character"] = p2873,
		["root"] = p2874,
		["feet"] = p2875,
		["headY"] = not (v2878 and v2878:IsA("BasePart")) and 1.5 or (v2878.Position - p2874.Position).Y,
		["pieces"] = {},
		["ticks"] = {},
		["stops"] = {},
		["started"] = v2879,
		["last"] = v2879,
		["extras"] = {},
		["off"] = {},
		["stop"] = function() -- name: stop end
	}
	if p2877 then
		local v2881 = v_u_7.color(p2876.color)
		v_u_7.burst("Flash", p2874.Position + Vector3.new(0, 1, 0), v2881, 0.6)
		local v2882 = v_u_7.burst
		local v2883 = p2874.Position
		local v2884 = p2875 + 0.3
		v2882("Shockwave", v2883 + Vector3.new(0, v2884, 0), v2881, 0.8)
		if p2877 == v_u_3.LocalPlayer then
			v_u_8.play("ModeActivate")
			v_u_7.shake(0.3, 0.4)
		else
			v_u_8.play("ModeActivate", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = p2874.Position
			})
		end
	end
	local v2885 = v_u_1353[p2876.mode.look] or (v_u_2808(p2876.mode.look) or v_u_1353.tomoe)
	v_u_237 = p2873:GetScale()
	v_u_2880.fx = v_u_237 <= 1 and 1 or v_u_237 * 1.35
	v2885(v_u_2880, p2876)
	if v_u_2880.fx > 1 and v_u_9.level() >= 2 then
		v_u_260(v_u_2880, "AuraMode", v_u_7.color(p2876.color), {
			["rate"] = 0.6,
			["glow"] = 0.4,
			["only"] = nil,
			["only"] = { "Glow", "FlameBack", "FlameFront" }
		})
	end
	v_u_237 = 1
	v_u_365(v_u_2880, p2876)
	local v2886 = p2874.CFrame
	for _, v2887 in v_u_2880.ticks do
		v2887(v2886, 0, 0)
	end
	for _, v2888 in v_u_2880.pieces do
		local v2889 = v2888.weld
		local v2890 = v2888.fromTorso
		if v2889 and v2890 then
			v2889.C0 = v2890 * v2886:Inverse() * v2888.place(v2886, 0)
		elseif not v2889 then
			v2888.part.CFrame = v2888.place(v2886, 0)
		end
		if v2888.alpha >= 1 then
			continue
		end
		v2888.part.Transparency = 1
		v_u_7.tween(v2888.part, 0.4, {
			["Transparency"] = v2888.alpha
		})
	end
	function v_u_2880.stop()
		-- upvalues: (copy) v_u_2880, (ref) v_u_2809, (ref) v_u_7, (ref) v_u_2
		if not v_u_2880.stopped then
			v_u_2880.stopped = true
			v_u_2809[v_u_2880] = nil
			for _, v2891 in v_u_2880.stops do
				v2891()
			end
			for _, v2892 in v_u_2880.pieces do
				local v2893 = v2892.part
				if v2892.weld then
					v2892.weld:Destroy()
					v2893.Anchored = true
				end
				v_u_7.tween(v2893, 0.3, {
					["Transparency"] = 1
				})
				for _, v2894 in v2893:GetChildren() do
					if not v2894:IsA("Decal") then
						continue
					end
					v_u_7.tween(v2894, 0.3, {
						["Transparency"] = 1
					})
				end
				v_u_2:AddItem(v2893, 0.35)
			end
		end
	end
	v_u_2809[v_u_2880] = true
	if not v_u_2810 then
		v_u_2810 = v_u_5.RenderStepped:Connect(v_u_2872)
	end
	return v_u_2880
end
function v13.start(p2895, p2896, p2897) -- name: start
	-- upvalues: (copy) v_u_10, (copy) v_u_3, (ref) v_u_2834, (copy) v_u_2811, (ref) v_u_2833, (ref) v_u_2810, (copy) v_u_5, (copy) v_u_2872
	local v2898 = v_u_10.byId[p2897] or v_u_10.byId[v_u_10.STARTER]
	local v2899 = p2896:FindFirstChild("HumanoidRootPart")
	if not (v2899 and v2899:IsA("BasePart")) then
		return function() end
	end
	local v2900 = p2896:FindFirstChildOfClass("Humanoid")
	local v2901 = -(v2899.Size.Y / 2 + (not v2900 and 2 or v2900.HipHeight))
	if p2895 == v_u_3.LocalPlayer then
		return v_u_2834(p2896, v2899, v2901, v2898, p2895).stop
	end
	local v_u_2902 = {
		["player"] = nil,
		["character"] = nil,
		["root"] = nil,
		["feet"] = nil,
		["eye"] = nil,
		["form"] = nil,
		["created"] = nil,
		["hiddenAt"] = nil,
		["player"] = p2895,
		["character"] = p2896,
		["root"] = v2899,
		["feet"] = v2901,
		["eye"] = v2898,
		["created"] = os.clock()
	}
	v_u_2811[v_u_2902] = true
	v_u_2833 = 0
	if not v_u_2810 then
		v_u_2810 = v_u_5.RenderStepped:Connect(v_u_2872)
	end
	return function()
		-- upvalues: (ref) v_u_2811, (copy) v_u_2902
		v_u_2811[v_u_2902] = nil
		local v2903 = v_u_2902.form
		if v2903 then
			v_u_2902.form = nil
			v2903.stop()
		end
	end
end
function v13.startOn(p2904, p2905) -- name: startOn
	-- upvalues: (copy) v_u_10, (copy) v_u_6, (ref) v_u_2834
	local v2906 = v_u_10.byId[p2905] or v_u_10.byId[v_u_10.STARTER]
	local v2907 = nil
	for _, v2908 in { "HumanoidRootPart", "UpperTorso", "Torso" } do
		local v2909 = p2904:FindFirstChild(v2908)
		if not (v2909 and v2909:IsA("BasePart")) then
			continue
		end
		v2907 = v2909
	end
	local v2910 = v2907 or p2904.PrimaryPart
	if not (v2910 and p2904:IsDescendantOf(v_u_6)) then
		return function() end
	end
	local v2911, v2912 = p2904:GetBoundingBox()
	local v2913 = v_u_2834(p2904, v2910, v2911.Position.Y - v2912.Y / 2 - v2910.Position.Y, v2906, nil)
	v2913.fixed = true
	return v2913.stop
end
function v13.flare(p2914) -- name: flare
	-- upvalues: (copy) v_u_2809
	for v2915 in v_u_2809 do
		if v2915.character ~= p2914 then
			continue
		end
		v2915.flare = 1
	end
end
return v13