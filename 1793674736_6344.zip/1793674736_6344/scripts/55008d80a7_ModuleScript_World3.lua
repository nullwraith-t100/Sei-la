local v1 = {
	["ash_ghoul"] = {
		["shirt"] = 1445230441,
		["pants"] = 112006247518688,
		["accessories"] = nil,
		["face"] = 7506136,
		["skin"] = "#3E383A",
		["accessories"] = { 127794041774801, 73669066070343 }
	},
	["cinder_crow"] = {
		["shirt"] = 8724651487,
		["pants"] = 104687930048209,
		["accessories"] = nil,
		["skin"] = "#221A1E",
		["accessories"] = { 16973440333, 121049287555407 }
	},
	["blood_kappa"] = {
		["shirt"] = 92357863188268,
		["pants"] = 92245719727231,
		["accessories"] = nil,
		["skin"] = "#8A1E2A",
		["accessories"] = { 18650888085, 122797470712525, 18381984331 }
	},
	["blood_bat"] = {
		["shirt"] = 102998814196765,
		["pants"] = 5904151330,
		["accessories"] = nil,
		["face"] = 7075142,
		["skin"] = "#3A0E18",
		["accessories"] = { 126123409637845, 9435548314, 126283348485747 }
	},
	["skeleton_samurai"] = {
		["shirt"] = 5455715793,
		["pants"] = 11317623303,
		["accessories"] = nil,
		["skin"] = "#ECE4D2",
		["accessories"] = { 13327370194, 128601805199534, 14312097630 }
	},
	["bone_hound"] = {
		["shirt"] = 7681823562,
		["pants"] = 116631799016842,
		["accessories"] = nil,
		["skin"] = "#ECE4D2",
		["accessories"] = { 131270278110920, 15905456882 }
	},
	["bone_shogun"] = {
		["shirt"] = 1447824096,
		["pants"] = 12713419107,
		["accessories"] = nil,
		["skin"] = "#F0E8D6",
		["accessories"] = {
			13055540739,
			128496102329497,
			112299116752633,
			77716488642664
		}
	},
	["red_ninja"] = {
		["shirt"] = 2882800442,
		["pants"] = 6288670866,
		["accessories"] = nil,
		["skin"] = "#F0C8A8",
		["accessories"] = { 15945150495, 14501509753, 88127727505692 }
	},
	["mantis_blade"] = {
		["shirt"] = 71483585662025,
		["pants"] = 5706006887,
		["accessories"] = nil,
		["skin"] = "#9A1C2A",
		["accessories"] = { 109852760849101, 100641790242384, 18381984331 }
	},
	["magma_imp"] = {
		["shirt"] = 1413433373,
		["pants"] = 10667908824,
		["accessories"] = nil,
		["face"] = 7317765,
		["skin"] = "#2A1410",
		["accessories"] = { 79013130402020, 18810172158, 105011030747416 }
	},
	["lava_salamander"] = {
		["shirt"] = 131462938961314,
		["pants"] = 135899741225577,
		["accessories"] = nil,
		["skin"] = "#2A1610",
		["accessories"] = { 88192327849082, 87408482990607 }
	},
	["cursed_monk"] = {
		["shirt"] = 15956862873,
		["pants"] = 15956876543,
		["accessories"] = nil,
		["skin"] = "#C8BCB4",
		["accessories"] = { 138427401844942, 111471878638425 }
	},
	["mask_spirit"] = {
		["shirt"] = 8120102562,
		["pants"] = 4689948941,
		["accessories"] = nil,
		["skin"] = "#F4F0E8",
		["accessories"] = { 123285551927084, 18932887942 }
	},
	["shrine_oni"] = {
		["shirt"] = 14541633720,
		["pants"] = 96655371240047,
		["accessories"] = nil,
		["face"] = 8329679,
		["skin"] = "#C8202E",
		["accessories"] = {
			84763340479716,
			120999973880106,
			111471878638425,
			15564765287
		}
	},
	["thorn_beast"] = {
		["shirt"] = 12070022025,
		["pants"] = 104051758677030,
		["accessories"] = nil,
		["skin"] = "#4A2024",
		["accessories"] = { 132490802195048, 13832827186, 140409734575450 }
	},
	["briar_witch"] = {
		["shirt"] = 282655591,
		["pants"] = 7748043101,
		["accessories"] = nil,
		["face"] = 7317765,
		["skin"] = "#E0C8CC",
		["accessories"] = { 17590871206, 18934198808, 110464967322599 }
	},
	["ghost_ronin"] = {
		["shirt"] = 110049876184443,
		["pants"] = 4490307067,
		["accessories"] = nil,
		["skin"] = "#E8E4F0",
		["accessories"] = { 106781383265505, 139502074562785, 103779412977076 }
	},
	["gargoyle"] = {
		["shirt"] = 8359531984,
		["pants"] = 10858692717,
		["accessories"] = nil,
		["skin"] = "#5A5458",
		["accessories"] = { 124592020782649, 18466689333, 126283348485747 }
	},
	["eclipse_cultist"] = {
		["shirt"] = 132858480588035,
		["pants"] = 139236483206923,
		["accessories"] = nil,
		["skin"] = "#2A2028",
		["accessories"] = { 136793471068085, 97933155375247, 105011030747416 }
	},
	["shadow_wolf"] = {
		["shirt"] = 5807703785,
		["pants"] = 5834080963,
		["accessories"] = nil,
		["skin"] = "#1A1420",
		["accessories"] = { 86103257471648, 122915630270314 }
	},
	["eclipse_priest"] = {
		["shirt"] = 11338201173,
		["pants"] = 102614721232054,
		["accessories"] = nil,
		["skin"] = "#2A2028",
		["accessories"] = {
			73990953714699,
			96971441819614,
			124596128259330,
			96901822489728
		}
	},
	["crimson_naga"] = {
		["shirt"] = 137601375119682,
		["pants"] = 5996106647,
		["accessories"] = nil,
		["skin"] = "#A8202E",
		["accessories"] = { 88713718461884, 17647078523, 16806227520 }
	},
	["blood_golem"] = {
		["shirt"] = 10176955743,
		["pants"] = 5100637025,
		["accessories"] = nil,
		["skin"] = "#9A0A1C",
		["accessories"] = { 121433174095191, 138224680082759, 94958511366183 }
	},
	["demon_guard"] = {
		["shirt"] = 76385472361936,
		["pants"] = 75218089751176,
		["accessories"] = nil,
		["skin"] = "#8A1420",
		["accessories"] = { 104280711008545, 85190410758678, 77303386935876 }
	},
	["hellhound"] = {
		["shirt"] = 6034246585,
		["pants"] = 6788936910,
		["accessories"] = nil,
		["skin"] = "#241214",
		["accessories"] = { 5769289648, 140562029280739, 15603813439 }
	},
	["moon_cultist"] = {
		["shirt"] = 15956339228,
		["pants"] = 15956347983,
		["accessories"] = nil,
		["skin"] = "#E8D8D0",
		["accessories"] = { 130060953298771, 82692112462125, 137438238207632 }
	},
	["lunar_wraith"] = {
		["shirt"] = 71680093872163,
		["pants"] = 918546440,
		["accessories"] = nil,
		["face"] = 7075142,
		["skin"] = "#F0F0F8",
		["accessories"] = { 18934180067, 118999287920689, 126283348485747 }
	},
	["blood_moon_queen"] = {
		["shirt"] = 10850993952,
		["pants"] = 85811788789907,
		["accessories"] = nil,
		["face"] = 7075142,
		["skin"] = "#F4E4E0",
		["accessories"] = {
			128747779837954,
			18932887942,
			79950366550792,
			73432101437261
		}
	},
	["infernal_smith"] = {
		["shirt"] = 9919987536,
		["pants"] = 9919990419,
		["accessories"] = nil,
		["face"] = 8329679,
		["skin"] = "#6A1A14",
		["accessories"] = { 113991185060856, 16078883890 }
	},
	["chain_demon"] = {
		["shirt"] = 105933321246347,
		["pants"] = 120274898723340,
		["accessories"] = nil,
		["skin"] = "#2A1418",
		["accessories"] = { 125744858645512, 134152209452913, 103779412977076 }
	},
	["moon_tengu"] = {
		["shirt"] = 10748699528,
		["pants"] = 15731867517,
		["accessories"] = nil,
		["skin"] = "#2A1A1E",
		["accessories"] = { 14927253943, 76859709856809, 72358986791167 }
	},
	["blood_drake"] = {
		["shirt"] = 8389960444,
		["pants"] = 8390036142,
		["accessories"] = nil,
		["skin"] = "#A81628",
		["accessories"] = { 106586427258490, 15097028745, 131541613437135 }
	},
	["vampire_knight"] = {
		["shirt"] = 116726639090133,
		["pants"] = 11468627803,
		["accessories"] = nil,
		["face"] = 7317765,
		["skin"] = "#E8DCE0",
		["accessories"] = { 92117238780455, 121406551456224 }
	},
	["crimson_assassin"] = {
		["shirt"] = 109065567611784,
		["pants"] = 8691108264,
		["accessories"] = nil,
		["skin"] = "#F0D0C0",
		["accessories"] = { 15507395842, 90700599983712, 90290736877181 }
	},
	["blood_moon_king"] = {
		["shirt"] = 7921590075,
		["pants"] = 18318402482,
		["accessories"] = nil,
		["face"] = 7317765,
		["skin"] = "#E8DCE0",
		["accessories"] = {
			87462903872901,
			17819627501,
			9429032278,
			126283348485747
		}
	}
}
return v1