local v_u_1 = game:GetService("Players")
local v_u_21 = {
	["_connectionUtil"] = require(script.Parent).get("ConnectionUtil").new(),
	["_boundEvents"] = {},
	["getLocalPlayer"] = function() -- name: getLocalPlayer
		-- upvalues: (copy) v_u_1
		return v_u_1.LocalPlayer
	end,
	["onLocalPlayer"] = function(p2) -- name: onLocalPlayer
		-- upvalues: (copy) v_u_21, (copy) v_u_1
		local v3 = v_u_21.getLocalPlayer()
		if v3 then
			p2(v3)
		end
		v_u_21._connectionUtil:trackConnection("LOCAL_PLAYER", v_u_1:GetPropertyChangedSignal("LocalPlayer"):Connect(function()
			-- upvalues: (ref) v_u_21
			local v4 = v_u_21.getLocalPlayer()
			assert(v4)
			v_u_21._getOrCreateBoundEvent("LOCAL_PLAYER"):Fire(v4)
		end))
		return v_u_21._getOrCreateBoundEvent("LOCAL_PLAYER").Event:Connect(p2)
	end,
	["getCharacter"] = function() -- name: getCharacter
		-- upvalues: (copy) v_u_21
		local v5 = v_u_21.getLocalPlayer()
		if v5 then
			return v5.Character
		else
			return nil
		end
	end,
	["onCharacter"] = function(p_u_6) -- name: onCharacter
		-- upvalues: (copy) v_u_21
		v_u_21._connectionUtil:trackConnection("ON_LOCAL_PLAYER", v_u_21.onLocalPlayer(function(p7)
			-- upvalues: (ref) v_u_21, (copy) p_u_6
			local v8 = v_u_21.getCharacter()
			if v8 then
				p_u_6(v8)
			end
			v_u_21._connectionUtil:trackConnection("CHARACTER_ADDED", p7.CharacterAdded:Connect(function(p9)
				-- upvalues: (ref) v_u_21
				assert(p9)
				v_u_21._getOrCreateBoundEvent("CHARACTER_ADDED"):Fire(p9)
			end))
		end))
		return v_u_21._getOrCreateBoundEvent("CHARACTER_ADDED").Event:Connect(p_u_6)
	end,
	["getChild"] = function(p10, p11) -- name: getChild
		-- upvalues: (copy) v_u_21
		local v12 = v_u_21.getCharacter()
		if v12 then
			local v13 = v12:FindFirstChild(p10)
			if v13 and v13:IsA(p11) then
				return v13
			else
				return nil
			end
		else
			return nil
		end
	end,
	["onChild"] = function(p_u_14, p_u_15, p_u_16) -- name: onChild
		-- upvalues: (copy) v_u_21
		v_u_21._connectionUtil:trackConnection("ON_CHARACTER", v_u_21.onCharacter(function(p17)
			-- upvalues: (ref) v_u_21, (copy) p_u_14, (copy) p_u_15, (copy) p_u_16
			local v18 = v_u_21.getChild(p_u_14, p_u_15)
			if v18 then
				p_u_16(v18)
			end
			v_u_21._connectionUtil:trackConnection("CHARACTER_CHILD_ADDED", p17.ChildAdded:Connect(function(p19)
				-- upvalues: (ref) p_u_14, (ref) p_u_15, (ref) v_u_21
				if p19.Name == p_u_14 and p19:IsA(p_u_15) then
					v_u_21._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. p_u_14 .. p_u_15):Fire(p19)
				end
			end))
		end))
		return v_u_21._getOrCreateBoundEvent("CHARACTER_CHILD_ADDED" .. p_u_14 .. p_u_15).Event:Connect(p_u_16)
	end,
	["_getOrCreateBoundEvent"] = function(p20) -- name: _getOrCreateBoundEvent
		-- upvalues: (copy) v_u_21
		if not v_u_21._boundEvents[p20] then
			v_u_21._boundEvents[p20] = Instance.new("BindableEvent")
		end
		return v_u_21._boundEvents[p20]
	end
}
return v_u_21