local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(238, 234, 255)
local v_u_9 = Color3.fromRGB(214, 236, 255)
local v_u_10 = Color3.fromRGB(165, 140, 255)
local v_u_11 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_12 = Enum.Material.Glass
local v_u_13 = Enum.Material.Neon
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = CFrame.Angles(0, 1.5707963267948966, 0)
local v_u_16 = CFrame.Angles(0, 0, -1.5707963267948966)
local v_u_17 = CFrame.identity
local function v_u_23(p18, p19) -- name: axisAt
	local v20 = p19.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p19.Unit
	local v21 = v20.Y
	local v22 = math.abs(v21) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p18, p18 + v20, v22) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_32(p24, p25) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v26 = v_u_2:FindFirstChild("EyePieces")
	if v26 then
		v26 = v26:FindFirstChild(p24)
	end
	if not (v26 and v26:IsA("MeshPart")) then
		return nil
	end
	local v27 = v26:Clone()
	local v28 = v26.Size
	local v29 = v26.Size.X
	local v30 = v26.Size.Y
	local v31 = v26.Size.Z
	v27.Size = v28 * (p25 / math.max(v29, v30, v31, 0.01))
	v27.Anchored = true
	v27.CanCollide = false
	v27.CanQuery = false
	v27.CanTouch = false
	v27.Massless = true
	v27.CastShadow = false
	v27.Parent = v_u_4.folder()
	return v27
end
local function v_u_42(p33, p34, p35, p36, p37, p38) -- name: newShard
	-- upvalues: (copy) v_u_4
	local v39 = {
		["a"] = nil,
		["b"] = nil,
		["wide"] = nil,
		["len"] = nil,
		["deep"] = nil,
		["k"] = -1
	}
	local v40 = Instance.new("WedgePart")
	v40.Anchored = true
	v40.CanCollide = false
	v40.CanQuery = false
	v40.CanTouch = false
	v40.CastShadow = false
	v40.Massless = true
	v40.Color = p33
	v40.Material = p34
	v40.Transparency = p35 or 0
	v40.Size = Vector3.new(0.1, 0.1, 0.1)
	v40.Parent = v_u_4.folder()
	v39.a = v40
	local v41 = Instance.new("WedgePart")
	v41.Anchored = true
	v41.CanCollide = false
	v41.CanQuery = false
	v41.CanTouch = false
	v41.CastShadow = false
	v41.Massless = true
	v41.Color = p33
	v41.Material = p34
	v41.Transparency = p35 or 0
	v41.Size = Vector3.new(0.1, 0.1, 0.1)
	v41.Parent = v_u_4.folder()
	v39.b = v41
	v39.wide = p36
	v39.len = p37
	v39.deep = p38
	return v39
end
local function v_u_51(p43, p44, p_u_45, p_u_46) -- name: placeShard
	p43.add(p44, p_u_45.a, function()
		-- upvalues: (copy) p_u_45, (copy) p_u_46
		local v47 = p_u_45.k
		local v48 = math.max(v47, 0.02)
		return p_u_46() * CFrame.new(0, p_u_45.len * v48 / 2, -p_u_45.deep * v48 / 4)
	end)
	p43.add(p44, p_u_45.b, function()
		-- upvalues: (copy) p_u_45, (copy) p_u_46
		local v49 = p_u_45.k
		local v50 = math.max(v49, 0.02)
		return p_u_46() * CFrame.new(0, p_u_45.len * v50 / 2, p_u_45.deep * v50 / 4) * CFrame.Angles(0, 3.141592653589793, 0)
	end)
end
local function v_u_61(p52, p53, p54, p55, p56, p57) -- name: bloomPicture
	-- upvalues: (copy) v_u_4
	local v58 = v_u_4.part(Vector3.new(p53, 0.05, p53), p52, p56, {
		["transparency"] = 1
	})
	for _, v59 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v60 = Instance.new("Decal")
		v60.Face = v59
		v60.Texture = p55
		v60.Color3 = p56
		v60.Parent = v58
		v_u_4.tween(v60, p57, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	v_u_4.tween(v58, p57, {
		["Size"] = Vector3.new(p54, 0.05, p54)
	}, Enum.EasingStyle.Quart)
	game:GetService("Debris"):AddItem(v58, p57 + 0.05)
end
return function(p_u_62)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (copy) v_u_61, (copy) v_u_3, (copy) v_u_5, (copy) v_u_11, (copy) v_u_32, (copy) v_u_12, (copy) v_u_15, (copy) v_u_9, (copy) v_u_14, (copy) v_u_13, (copy) v_u_16, (copy) v_u_23, (copy) v_u_10, (copy) v_u_8, (copy) v_u_17, (copy) v_u_42, (copy) v_u_51
	return {
		["w6_hakka_no_togame"] = function(p_u_63, p64)
			-- upvalues: (ref) v_u_4, (ref) v_u_1, (copy) p_u_62, (ref) v_u_7, (ref) v_u_6, (ref) v_u_61, (ref) v_u_3, (ref) v_u_5, (ref) v_u_11, (ref) v_u_32, (ref) v_u_12, (ref) v_u_15, (ref) v_u_9, (ref) v_u_14, (ref) v_u_13, (ref) v_u_16, (ref) v_u_23, (ref) v_u_10, (ref) v_u_8, (ref) v_u_17, (ref) v_u_42, (ref) v_u_51
			local v_u_65 = v_u_4.color(p64.color)
			local v66 = v_u_4.color(p64.color2)
			local v67 = p_u_63.headY / 1.5
			local v_u_68 = math.clamp(v67, 0.7, 3)
			local v_u_69 = p_u_63.fx
			local v_u_70 = p_u_63.character == v_u_1.LocalPlayer.Character
			local v71 = p_u_63.character:FindFirstChild("Head")
			if not (v71 and v71:IsA("BasePart")) then
				v71 = nil
			end
			local v_u_72
			if v71 then
				v_u_72 = v71.Size.Y
			else
				v_u_72 = v_u_68 * 1.2
			end
			local v_u_73 = p_u_62.crownOf(p_u_63)
			local v_u_74 = nil
			local v_u_75 = nil
			local v_u_76 = nil
			local function v_u_77()
				-- upvalues: (copy) p_u_63
				return p_u_63.root.CFrame
			end
			local v_u_98 = p_u_62.throb(p_u_63, 6, 2, 1.1, function(p78)
				-- upvalues: (ref) p_u_62, (copy) p_u_63, (ref) v_u_4, (copy) v_u_68, (ref) v_u_7, (copy) v_u_69, (copy) v_u_65, (ref) v_u_6, (ref) v_u_61, (ref) v_u_77, (ref) v_u_3, (copy) v_u_72, (ref) v_u_74, (ref) v_u_5, (ref) v_u_75, (ref) v_u_76
				local v79 = p_u_62.feetAt(p_u_63, p78, 0.12)
				v_u_4.flash(p78.Position + Vector3.new(0, 0.4, 0) * v_u_68, v_u_7, v_u_68 * 5.5 * v_u_69, 0.32)
				v_u_4.ring(v79, v_u_65, 8 * v_u_69, 0.85, v_u_6.HakkaFrost)
				v_u_4.ring(v79 + Vector3.new(0, 0.05, 0), v_u_7, 6 * v_u_69, 0.6, v_u_6.HakkaMist)
				for v80 = 1, 5 do
					local v81 = v80 * 3.141592653589793 * 2 / 5 + math.random() * 0.6
					local v82 = (1.6 + math.random() * 2) * v_u_68
					local v83 = v_u_61
					local v84 = CFrame.new
					local v85 = math.cos(v81) * v82
					local v86 = v80 * 0.02
					local v87 = math.sin(v81) * v82
					local v88 = v84(v79 + Vector3.new(v85, v86, v87)) * CFrame.Angles(0, math.random() * 6.28, 0)
					local v89 = v_u_68 * 0.4
					local v90 = (1.6 + math.random() * 0.8) * v_u_68 * v_u_69
					local v91 = v_u_6.HakkaFlower
					local v92
					if v80 % 2 == 0 then
						v92 = v_u_7
					else
						v92 = v_u_65
					end
					v83(v88, v89, v90, v91, v92, 1.1)
				end
				local v93 = Instance.new("Attachment")
				v93.WorldPosition = v_u_77().Position
				v93.Parent = v_u_3.Terrain
				local v94 = Instance.new("ParticleEmitter")
				v94.Enabled = false
				v94.Texture = v_u_6.HakkaFlower
				v94.LightEmission = 0.2
				v94.LightInfluence = 0
				v94.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2 * v_u_72 * v_u_69), NumberSequenceKeypoint.new(0.35, 1.6 * v_u_72 * v_u_69), NumberSequenceKeypoint.new(1, 1.8 * v_u_72 * v_u_69) })
				v94.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.05), NumberSequenceKeypoint.new(1, 1) })
				v94.Lifetime = NumberRange.new(0.75)
				v94.Speed = NumberRange.new(0)
				v94.Rotation = NumberRange.new(0, 360)
				v94.RotSpeed = NumberRange.new(60, 80)
				v94.ZOffset = 1
				v94.Parent = v93
				v94:Emit(1)
				game:GetService("Debris"):AddItem(v93, 1)
				local v95 = v_u_74
				if v95 then
					v95:Emit(v_u_5.level() <= 1 and 4 or 14)
				end
				local v96 = v_u_75
				if v96 then
					v96:Emit(4)
				end
				local v97 = v_u_76
				if v97 then
					v97.FillTransparency = 0.45
					v_u_4.tween(v97, 0.6, {
						["FillTransparency"] = 0.78
					})
				end
			end)
			local v_u_104 = p_u_62.group(p_u_63, function(p99, p100)
				-- upvalues: (copy) v_u_73, (copy) v_u_72
				local v101 = v_u_73(p99) * CFrame.new(0.62 * v_u_72, 0.36 * v_u_72, 0.08 * v_u_72)
				local v102 = CFrame.Angles
				local v103 = p100 * 1.3
				return v101 * v102(0, -0.20943951023931956, math.sin(v103) * 0.04 + -0.24434609527920614)
			end)
			local v_u_105 = CFrame.new(0.05 * v_u_72, 0.32 * v_u_72, 0)
			v_u_77 = function()
				-- upvalues: (copy) v_u_104, (copy) v_u_105
				return v_u_104.cf * v_u_105
			end
			local v106 = p_u_62.picture(1.3 * v_u_72, v_u_6.Glow, v_u_65, 0.3)
			p_u_62.add(p_u_63, v106, function()
				-- upvalues: (copy) v_u_104, (copy) v_u_105, (ref) p_u_62, (copy) v_u_72, (ref) v_u_11
				local v107 = (v_u_104.cf * v_u_105).Position
				local v108 = p_u_62.camPos() - v107
				local v109 = v108.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v108.Unit
				return CFrame.lookAt(v107 - v109 * 0.25 * v_u_72, v107 + v109) * v_u_11
			end)
			local v_u_110 = v_u_32("w6_hakka_flower", 2.1 * v_u_72)
			if v_u_110 then
				local v111 = v_u_110:FindFirstChildOfClass("SurfaceAppearance")
				if v111 then
					local v112 = v111.EmissiveStrength
					v111.EmissiveStrength = math.max(v112, 5)
				else
					v_u_110.Color = v66
					v_u_110.Material = v_u_12
					v_u_110.Transparency = 0.08
					v_u_110.Reflectance = 0.2
				end
				local v_u_113 = v_u_110.Size
				p_u_62.pin(p_u_63, v_u_104, v_u_110, v_u_15)
				local v_u_114 = -1
				local v115 = p_u_63.ticks
				local function v121()
					-- upvalues: (copy) v_u_98, (ref) v_u_114, (copy) v_u_110, (copy) v_u_113
					local v116 = v_u_98() * 20
					local v117 = math.floor(v116) / 20
					if v117 ~= v_u_114 then
						v_u_114 = v117
						local v118 = v_u_110
						local v119 = v_u_113
						local v120 = v117 * 3.141592653589793
						v118.Size = v119 * (math.sin(v120) * 0.14 + 1)
					end
				end
				table.insert(v115, v121)
			else
				for v122 = 1, 5 do
					local v123 = p_u_62.blob
					local v124 = 0.07 * v_u_72
					local v125 = 0.46 * v_u_72
					local v126 = 0.24 * v_u_72
					local v127 = Vector3.new(v124, v125, v126)
					local v128
					if v122 % 2 == 0 then
						v128 = v_u_9
					else
						v128 = v_u_7
					end
					local v129 = v123(v127, v128, 0, v_u_14)
					v129.Reflectance = 0.2
					local v_u_130 = v122 * 3.141592653589793 * 2 / 5
					p_u_62.add(p_u_63, v129, function()
						-- upvalues: (copy) v_u_98, (copy) v_u_104, (copy) v_u_105, (copy) v_u_130, (copy) v_u_72
						local v131 = 0.25 + 0.55 * v_u_98()
						return v_u_104.cf * v_u_105 * CFrame.Angles(v_u_130, 0, 0) * CFrame.Angles(0, 0, -v131) * CFrame.new(0, 0.24 * v_u_72, 0)
					end)
				end
				p_u_62.add(p_u_63, p_u_62.ball(0.2 * v_u_72, v_u_65, 0, v_u_13), function()
					-- upvalues: (copy) v_u_104, (copy) v_u_105, (copy) v_u_72
					return v_u_104.cf * v_u_105 * CFrame.new(0.04 * v_u_72, 0, 0)
				end)
				for v_u_132, v_u_133 in { -0.14, 0, 0.14 } do
					local v134 = p_u_62.bar
					local v135 = 0.05 * v_u_72
					local v136 = 0.62 * v_u_72
					local v137 = 0.05 * v_u_72
					local v138 = v134(Vector3.new(v135, v136, v137), v_u_9, 0.1, v_u_13)
					p_u_62.add(p_u_63, v138, function(_, p139)
						-- upvalues: (copy) v_u_104, (copy) v_u_72, (copy) v_u_133, (copy) v_u_132
						local v140 = (v_u_104.cf * CFrame.new(0, 0.05 * v_u_72, v_u_133 * v_u_72)).Position
						local v141 = p139 * 1.9 + v_u_132
						local v142 = math.sin(v141) * 0.12
						local v143 = CFrame.new(v140)
						local v144 = CFrame.Angles
						local v145 = p139 * 1.4 + v_u_132 * 2
						return v143 * v144(v142, 0, math.sin(v145) * 0.1) * CFrame.new(0, -0.31 * v_u_72 * (1 + 0.15 * (v_u_132 % 2)), 0)
					end)
				end
			end
			local v_u_146 = v_u_68 * 3.5
			local v_u_160 = p_u_62.group(p_u_63, function(p147, p148)
				-- upvalues: (copy) v_u_98, (copy) v_u_68
				local v149 = v_u_98() * 3.141592653589793
				local v150 = math.sin(v149) * 0.45 * v_u_68
				local v151 = CFrame.new
				local v152 = v_u_68 * 1.85
				local v153 = v_u_68 * -0.75
				local v154 = p148 * 1.1
				local v155 = p147 * v151(v152, v153 + math.sin(v154) * 0.12 * v_u_68 + v150, v_u_68 * 0.15)
				local v156 = CFrame.Angles
				local v157 = p148 * 0.6
				local v158 = math.sin(v157) * 0.08 + -0.3141592653589793
				local v159 = p148 * 0.9
				return v155 * v156(0, v158, math.sin(v159) * 0.04 + 0.17453292519943295)
			end)
			local v161 = p_u_62.picture(v_u_68 * 2.6, v_u_6.Glow, v_u_65, 0.5)
			p_u_62.add(p_u_63, v161, function()
				-- upvalues: (copy) v_u_160, (ref) p_u_62, (copy) v_u_68, (ref) v_u_11
				local v162 = v_u_160.cf.Position
				local v163 = p_u_62.camPos() - v162
				local v164 = v163.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v163.Unit
				return CFrame.lookAt(v162 - v164 * 0.4 * v_u_68, v162 + v164) * v_u_11
			end)
			p_u_62.fadeFromBehind(p_u_63, v161, 0.6)
			local v165 = v_u_32("w6_hakka_blade", v_u_146)
			if v165 then
				local v166 = v_u_7
				local v167 = v165:FindFirstChildOfClass("SurfaceAppearance")
				if v167 then
					local v168 = v167.EmissiveStrength
					v167.EmissiveStrength = math.max(v168, 5)
				else
					v165.Color = v166
					v165.Material = v_u_12
					v165.Transparency = 0.08
					v165.Reflectance = 0.2
				end
				p_u_62.pin(p_u_63, v_u_160, v165, v_u_16)
			else
				local v169 = p_u_62.pin
				local v170 = p_u_62.bar
				local v171 = v_u_68 * 0.06
				local v172 = v_u_68 * 2.1
				local v173 = v_u_68 * 0.22
				v169(p_u_63, v_u_160, v170(Vector3.new(v171, v172, v173), v_u_7, 0, v_u_14), CFrame.new(0, v_u_68 * -0.35, 0))
				local v174 = p_u_62.pin
				local v175 = p_u_62.bar
				local v176 = v_u_68 * 0.04
				local v177 = v_u_68 * 2.1
				local v178 = v_u_68 * 0.04
				v174(p_u_63, v_u_160, v175(Vector3.new(v176, v177, v178), v_u_65, 0, v_u_13), CFrame.new(0, v_u_68 * -0.35, v_u_68 * -0.11))
				local v179 = v_u_7
				local v180 = v_u_14
				local v181 = Instance.new("WedgePart")
				v181.Anchored = true
				v181.CanCollide = false
				v181.CanQuery = false
				v181.CanTouch = false
				v181.CastShadow = false
				v181.Massless = true
				v181.Color = v179
				v181.Material = v180
				v181.Transparency = 0
				v181.Size = Vector3.new(0.1, 0.1, 0.1)
				v181.Parent = v_u_4.folder()
				local v182 = v_u_68 * 0.06
				local v183 = v_u_68 * 0.36
				local v184 = v_u_68 * 0.22
				v181.Size = Vector3.new(v182, v183, v184)
				p_u_62.pin(p_u_63, v_u_160, v181, CFrame.new(0, v_u_68 * -1.58, 0) * CFrame.Angles(3.141592653589793, 0, 0))
				local v185 = p_u_62.picture(v_u_68 * 0.7, v_u_6.HakkaFlower, v_u_65, 0)
				p_u_62.pin(p_u_63, v_u_160, v185, CFrame.new(0, v_u_68 * 0.76, 0))
				local v186 = p_u_62.pin
				local v187 = p_u_62.bar
				local v188 = v_u_68 * 0.14
				local v189 = v_u_68 * 0.9
				local v190 = v_u_68 * 0.14
				v186(p_u_63, v_u_160, v187(Vector3.new(v188, v189, v190), v_u_7, 0, v_u_14), CFrame.new(0, v_u_68 * 1.25, 0))
			end
			local v_u_191 = Instance.new("Attachment")
			v_u_191.Parent = p_u_63.root
			p_u_62.own(p_u_63, v_u_191)
			local v192 = p_u_63.stops
			table.insert(v192, function()
				-- upvalues: (copy) v_u_191
				v_u_191:Destroy()
			end)
			local v_u_193 = Instance.new("Attachment")
			v_u_193.Parent = p_u_63.root
			p_u_62.own(p_u_63, v_u_193)
			local v194 = p_u_63.stops
			table.insert(v194, function()
				-- upvalues: (copy) v_u_193
				v_u_193:Destroy()
			end)
			local v195 = v_u_68 * 0.32
			local v196 = v_u_68 * 0.14
			local v197 = p_u_62.ray(v_u_191, v_u_193, v_u_7, v195, v196, v_u_6.HakkaVeil)
			v197.TextureMode = Enum.TextureMode.Stretch
			v197.TextureLength = 1
			v197.TextureSpeed = 0
			v197.Color = ColorSequence.new(v_u_7, v_u_65)
			v197.LightEmission = 0.35
			v197.Segments = 14
			v197.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 0.9) })
			v197.CurveSize0 = v_u_68 * 1.4
			v197.CurveSize1 = v_u_68 * 1.1
			local v_u_198 = {}
			for _, v199 in { -1, 1 } do
				local v_u_200 = Instance.new("Attachment")
				v_u_200.Parent = p_u_63.root
				p_u_62.own(p_u_63, v_u_200)
				local v201 = p_u_63.stops
				table.insert(v201, function()
					-- upvalues: (copy) v_u_200
					v_u_200:Destroy()
				end)
				local v_u_202 = Instance.new("Attachment")
				v_u_202.Parent = p_u_63.root
				p_u_62.own(p_u_63, v_u_202)
				local v203 = p_u_63.stops
				table.insert(v203, function()
					-- upvalues: (copy) v_u_202
					v_u_202:Destroy()
				end)
				local v204 = v_u_68 * 1.1
				local v205 = v_u_68 * 2.6
				local v206 = p_u_62.ray(v_u_200, v_u_202, v_u_7, v204, v205, v_u_6.HakkaVeil)
				v206.TextureMode = Enum.TextureMode.Stretch
				v206.TextureLength = 1
				v206.TextureSpeed = 0
				v206.Color = ColorSequence.new(v_u_7, v_u_65)
				v206.LightEmission = 0.35
				v206.Segments = 14
				v206.CurveSize0 = v_u_68 * 1.3
				v206.CurveSize1 = v_u_68 * 1.6
				table.insert(v_u_198, {
					["a0"] = v_u_200,
					["a1"] = v_u_202,
					["beam"] = v206,
					["side"] = v199
				})
			end
			local v_u_207 = -1
			local v_u_208 = 0
			local v209 = p_u_63.ticks
			local function v273(p210, p211, p212)
				-- upvalues: (copy) v_u_160, (copy) v_u_146, (copy) v_u_68, (copy) v_u_191, (ref) v_u_23, (copy) v_u_193, (copy) p_u_63, (ref) v_u_208, (copy) v_u_198, (copy) v_u_70, (ref) v_u_3, (ref) v_u_207
				local v213 = p210:PointToObjectSpace((v_u_160.cf * CFrame.new(0, v_u_146 / 2 + v_u_68 * 0.05, 0)).Position)
				local v214 = v_u_68 * 0.5
				local v215 = p211 * 1.1
				local v216 = v214 + math.sin(v215) * 0.45 * v_u_68
				local v217 = v_u_146 * -0.85
				local v218 = p211 * 2
				local v219 = v217 + math.sin(v218) * 0.2 * v_u_68
				local v220 = v_u_68 * 1.5
				local v221 = p211 * 1.3
				local v222 = v220 + math.cos(v221) * 0.45 * v_u_68
				local v223 = v213 + Vector3.new(v216, v219, v222)
				local v224 = v_u_191
				local v225 = v_u_23
				local v226 = p211 * 1.7
				local v227 = math.sin(v226) * 0.3 + 0.3
				v224.CFrame = v225(v213, (Vector3.new(v227, 0.45, 1)))
				local v228 = v_u_193
				local v229 = v_u_23
				local v230 = p211 * 1.9
				local v231 = math.sin(v230) * 0.8
				v228.CFrame = v229(v223, (Vector3.new(v231, -1, 0.35)))
				local v232 = v_u_208
				local v233 = -p210:VectorToObjectSpace(p_u_63.root.AssemblyLinearVelocity).Z / 18
				local v234 = math.clamp(v233, 0, 1) - v_u_208
				local v235 = p212 * 4
				v_u_208 = v232 + v234 * math.min(v235, 1)
				for v236, v237 in v_u_198 do
					local v238 = v237.side
					local v239 = p211 * 1.5 + v236 * 1.3
					local v240 = math.sin(v239)
					local v241 = v237.a0
					local v242 = v_u_23
					local v243 = v238 * 0.42 * v_u_68
					local v244 = v_u_68 * 0.8
					local v245 = v_u_68 * 0.5
					local v246 = Vector3.new(v243, v244, v245)
					local v247 = v238 * 0.15
					local v248 = 0.3 - v_u_208 * 0.2
					v241.CFrame = v242(v246, (Vector3.new(v247, v248, 1)))
					local v249 = v237.a1
					local v250 = v_u_23
					local v251 = v238 * (v240 * 0.2 + 0.85) * v_u_68
					local v252 = p_u_63.feet + 0.15 + v_u_208 * 1.4 * v_u_68
					local v253 = (v240 * 0.25 + 1.35 + v_u_208 * 2.2) * v_u_68
					local v254 = Vector3.new(v251, v252, v253)
					local v255 = v238 * 0.1 + v240 * 0.15
					local v256 = v_u_208 * 0.3 + -0.3
					v249.CFrame = v250(v254, (Vector3.new(v255, v256, 1)))
				end
				if v_u_70 then
					local v257 = v_u_3.CurrentCamera
					local v258 = ((not v257 and 0 or v257.CFrame.LookVector:Dot(p210.LookVector)) - 0.3) * 1.4
					local v259 = math.clamp(v258, 0, 1) * 4
					local v260 = math.floor(v259) / 4
					if v260 ~= v_u_207 then
						v_u_207 = v260
						local v261 = v260 * 0.4 + 0.25
						for _, v262 in v_u_198 do
							local v263 = v262.beam
							local v264 = NumberSequence.new
							local v265 = {}
							local v266 = NumberSequenceKeypoint.new
							local v267 = v261 + 0.15
							local v268 = v266(0, (math.min(v267, 1)))
							local v269 = NumberSequenceKeypoint.new(0.15, v261)
							local v270 = NumberSequenceKeypoint.new
							local v271 = v261 + 0.15
							__set_list(v265, 1, {v268, v269, v270(0.75, (math.min(v271, 1))), NumberSequenceKeypoint.new(1, 0.95)})
							v263.Transparency = v264(v265)
						end
						return
					end
				elseif v_u_207 < 0 then
					v_u_207 = 0
					for _, v272 in v_u_198 do
						v272.beam.Transparency = NumberSequence.new({
							NumberSequenceKeypoint.new(0, 0.5),
							NumberSequenceKeypoint.new(0.15, 0.35),
							NumberSequenceKeypoint.new(0.75, 0.5),
							NumberSequenceKeypoint.new(1, 0.95)
						})
					end
				end
			end
			table.insert(v209, v273)
			for _, v274 in {
				{ "RightHand", "Right Arm" },
				{ "LeftHand", "Left Arm" }
			} do
				local v275 = p_u_63.character:FindFirstChild(v274[1]) or p_u_63.character:FindFirstChild(v274[2])
				if not (v275 and v275:IsA("BasePart")) then
					continue
				end
				local v276 = v275.Name ~= v274[2] and 0 or -v275.Size.Y / 2
				local v_u_277 = Instance.new("Attachment")
				local v278 = v276 + v_u_68 * 0.25
				v_u_277.Position = Vector3.new(0, v278, 0)
				v_u_277.Parent = v275
				local v_u_279 = Instance.new("Attachment")
				local v280 = v276 - v_u_68 * 0.25
				v_u_279.Position = Vector3.new(0, v280, 0)
				v_u_279.Parent = v275
				local v281 = Instance.new("Trail")
				v281.Attachment0 = v_u_277
				v281.Attachment1 = v_u_279
				v281.Texture = v_u_6.HakkaVeil
				v281.TextureMode = Enum.TextureMode.Stretch
				v281.Color = ColorSequence.new(v_u_7, v_u_65)
				v281.Transparency = NumberSequence.new(0.25, 1)
				v281.WidthScale = NumberSequence.new(1, 0.3)
				v281.Lifetime = 0.45
				v281.LightEmission = 0.4
				v281.LightInfluence = 0
				v281.FaceCamera = true
				v281.MinLength = 0.05
				v281.Parent = v_u_277
				for _, v282 in { v_u_277, v_u_279 } do
					p_u_62.own(p_u_63, v282)
				end
				local v283 = p_u_63.stops
				table.insert(v283, function()
					-- upvalues: (copy) v_u_277, (copy) v_u_279
					v_u_277:Destroy()
					v_u_279:Destroy()
				end)
			end
			local v_u_284 = p_u_62.picture(v_u_68 * 6.6, v_u_6.HakkaFrost, v_u_10, 0)
			local v285 = p_u_62.picture(v_u_68 * 5.4, v_u_6.Glow, v_u_10, 0.45)
			local v286 = p_u_62.picture(v_u_68 * 3.8, v_u_6.HakkaFlower, v_u_10, 0.3)
			local v_u_287 = 0
			local v288 = p_u_63.ticks
			local function v290(_, _, p289)
				-- upvalues: (ref) v_u_287
				v_u_287 = v_u_287 + p289 * 0.12
			end
			table.insert(v288, v290)
			p_u_62.add(p_u_63, v285, function(p291)
				-- upvalues: (ref) p_u_62, (copy) p_u_63
				return CFrame.new(p_u_62.feetAt(p_u_63, p291, 0.04))
			end)
			p_u_62.add(p_u_63, v286, function(p292)
				-- upvalues: (ref) p_u_62, (copy) p_u_63, (ref) v_u_287
				return CFrame.new(p_u_62.feetAt(p_u_63, p292, 0.1)) * CFrame.Angles(0, -v_u_287 * 1.5, 0)
			end)
			p_u_62.add(p_u_63, v_u_284, function(p293)
				-- upvalues: (ref) p_u_62, (copy) p_u_63, (ref) v_u_287
				return CFrame.new(p_u_62.feetAt(p_u_63, p293, 0.07)) * CFrame.Angles(0, v_u_287, 0)
			end)
			local v_u_294 = -1
			local v295 = p_u_63.ticks
			local function v299()
				-- upvalues: (copy) v_u_98, (ref) v_u_294, (copy) v_u_68, (copy) v_u_284
				local v296 = v_u_98() * 20
				local v297 = math.floor(v296) / 20
				if v297 ~= v_u_294 then
					v_u_294 = v297
					local v298 = v_u_68 * 6.6 * (v297 * 0.25 + 1)
					v_u_284.Size = Vector3.new(v298, 0.05, v298)
				end
			end
			table.insert(v295, v299)
			p_u_62.own(p_u_63, v_u_284)
			local v_u_300 = Instance.new("ParticleEmitter")
			v_u_300.Texture = v_u_6.FxSmoke
			v_u_300.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_300.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v_u_300.FlipbookFramerate = NumberRange.new(0)
			v_u_300.FlipbookStartRandom = true
			v_u_300.Color = ColorSequence.new(v_u_8, v_u_10)
			v_u_300.LightEmission = 0
			v_u_300.LightInfluence = 0
			v_u_300.Size = NumberSequence.new(v_u_68 * 1.2 * v_u_69, v_u_68 * 2.6 * v_u_69)
			v_u_300.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.25, 0.62),
				NumberSequenceKeypoint.new(0.7, 0.75),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_300.Lifetime = NumberRange.new(2.2, 3)
			v_u_300.Speed = NumberRange.new(0.2, 0.6)
			v_u_300.SpreadAngle = Vector2.new(60, 60)
			v_u_300.EmissionDirection = Enum.NormalId.Top
			v_u_300.Acceleration = Vector3.new(0, 0.12, 0)
			v_u_300.Rotation = NumberRange.new(0, 360)
			v_u_300.RotSpeed = NumberRange.new(-15, 15)
			v_u_300.Shape = Enum.ParticleEmitterShape.Box
			v_u_300.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_300:SetAttribute("BaseRate", 3 * v_u_69)
			v_u_300.Rate = 3 * v_u_69 * v_u_5.formRate()
			v_u_300.Parent = v_u_284
			local v_u_301 = Instance.new("ParticleEmitter")
			v_u_301.Texture = v_u_6.FxTwinkle
			v_u_301.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_301.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_301.Color = ColorSequence.new(v_u_10, v_u_9)
			v_u_301.LightEmission = 0.35
			v_u_301.LightInfluence = 0
			v_u_301.Size = NumberSequence.new(v_u_68 * 0.5 * v_u_69)
			v_u_301.Lifetime = NumberRange.new(1.2, 2)
			v_u_301.Speed = NumberRange.new(0.8, 2)
			v_u_301.SpreadAngle = Vector2.new(25, 25)
			v_u_301.EmissionDirection = Enum.NormalId.Top
			v_u_301.Drag = 0.4
			v_u_301.Rotation = NumberRange.new(0, 45)
			v_u_301.Shape = Enum.ParticleEmitterShape.Box
			v_u_301.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_301:SetAttribute("BaseRate", 5 * v_u_69)
			v_u_301.Rate = 5 * v_u_69 * v_u_5.formRate()
			v_u_301.Parent = v_u_284
			v_u_74 = v_u_301
			local v302 = p_u_63.stops
			table.insert(v302, function()
				-- upvalues: (copy) v_u_300, (copy) v_u_301
				v_u_300.Enabled = false
				v_u_301.Enabled = false
			end)
			if v71 then
				local v_u_303 = Instance.new("Attachment")
				local v304 = -0.12 * v_u_72
				local v305 = -0.6 * v_u_72
				v_u_303.Position = Vector3.new(0, v304, v305)
				v_u_303.Parent = v71
				local v_u_306 = Instance.new("ParticleEmitter")
				v_u_306.Texture = v_u_6.FxSmoke
				v_u_306.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v_u_306.FlipbookMode = Enum.ParticleFlipbookMode.Loop
				v_u_306.FlipbookFramerate = NumberRange.new(0)
				v_u_306.FlipbookStartRandom = true
				v_u_306.Color = ColorSequence.new(v_u_7, v_u_8)
				v_u_306.LightEmission = 0.3
				v_u_306.LightInfluence = 0
				v_u_306.Size = NumberSequence.new(0.12 * v_u_72, 0.55 * v_u_72)
				v_u_306.Transparency = NumberSequence.new(0.45, 1)
				v_u_306.Lifetime = NumberRange.new(0.9, 1.3)
				v_u_306.Speed = NumberRange.new(1.2, 2)
				v_u_306.SpreadAngle = Vector2.new(18, 18)
				v_u_306.EmissionDirection = Enum.NormalId.Front
				v_u_306.Drag = 2
				v_u_306.Acceleration = Vector3.new(0, -0.4, 0)
				v_u_306.Rotation = NumberRange.new(0, 360)
				v_u_306.Rate = 0
				v_u_306.Parent = v_u_303
				v_u_75 = v_u_306
				p_u_62.own(p_u_63, v_u_303)
				local v307 = p_u_63.stops
				table.insert(v307, function()
					-- upvalues: (copy) v_u_303
					v_u_303:Destroy()
				end)
				local v_u_308 = 1.2
				local v309 = p_u_63.ticks
				local function v312(p310, p311)
					-- upvalues: (ref) v_u_308, (ref) p_u_62, (copy) v_u_306
					if v_u_308 <= p311 then
						v_u_308 = p311 + 3.2
						if (p310.Position - p_u_62.camPos()).Magnitude < 80 then
							v_u_306:Emit(3)
						end
					end
				end
				table.insert(v309, v312)
			end
			local function v_u_323(p313, p314) -- name: grown
				if p313 < 2 then
					return 0, 0
				end
				local v315 = (p313 - 2) / 6
				local v316 = math.floor(v315)
				local v317 = (p313 - 2) % 6 - (p314 - 1) * 0.07
				if v317 <= 0 or v317 >= 3.45 then
					return 0, v316
				end
				local v318 = v317 / 0.35
				local v319 = math.clamp(v318, 0, 1) - 1
				local v320 = v319 * 2.7 * v319 * v319 + 1 + v319 * 1.7 * v319
				if v317 > 2.75 then
					local v321 = (v317 - 0.35 - 2.4) / 0.7
					local v322 = math.clamp(v321, 0, 1)
					v320 = v320 * (1 - v322 * v322 * (3 - v322 * 2))
				end
				return v320, v316
			end
			local function v_u_334(p324, p325, p326) -- name: bloomFrame
				-- upvalues: (copy) v_u_323, (ref) p_u_62, (copy) p_u_63, (copy) v_u_68
				local v327, v328 = v_u_323(p325, p326)
				local v329 = v328 * 0.9 + p326 * 3.141592653589793 * 2 / 4
				local v330 = math.cos(v329)
				local v331 = math.sin(v329)
				local v332 = Vector3.new(v330, 0, v331)
				local v333 = p_u_62.feetAt(p_u_63, p324, v_u_68 * 0.45 * math.max(v327, 0) + 0.15) + v332 * 2.6 * v_u_68
				if v327 <= 0.02 then
					v333 = v333 - Vector3.new(0, 4, 0)
				end
				return CFrame.new(v333) * CFrame.fromAxisAngle(v332:Cross(Vector3.new(0, 1, 0)), -0.9) * CFrame.Angles(0, v329, 0)
			end
			for v_u_335 = 1, 4 do
				local v_u_336 = v_u_32("w6_hakka_bloom", v_u_68 * 2.2)
				if v_u_336 then
					local v337
					if v_u_335 % 2 == 0 then
						v337 = v66
					else
						v337 = v_u_9
					end
					local v338 = v_u_336:FindFirstChildOfClass("SurfaceAppearance")
					if v338 then
						local v339 = v338.EmissiveStrength
						v338.EmissiveStrength = math.max(v339, 5)
					else
						v_u_336.Color = v337
						v_u_336.Material = v_u_12
						v_u_336.Transparency = 0.08
						v_u_336.Reflectance = 0.2
					end
					local v_u_340 = v_u_336.Size
					local v_u_341 = -1
					p_u_62.add(p_u_63, v_u_336, function(p342, p343)
						-- upvalues: (copy) v_u_323, (copy) v_u_335, (ref) v_u_341, (copy) v_u_336, (copy) v_u_340, (copy) v_u_334, (ref) v_u_17
						local v344 = v_u_323(p343, v_u_335)
						local v345 = v344 - v_u_341
						if math.abs(v345) > 0.01 then
							v_u_341 = v344
							v_u_336.Size = v_u_340 * math.max(v344, 0.02)
						end
						return v_u_334(p342, p343, v_u_335) * v_u_17
					end)
				else
					local v346 = v_u_42
					local v347
					if v_u_335 % 2 == 0 then
						v347 = v_u_7
					else
						v347 = v_u_65
					end
					local v348
					if v_u_335 % 2 == 0 then
						v348 = v_u_12
					else
						v348 = v_u_13
					end
					local v_u_349 = v346(v347, v348, v_u_335 % 2 == 0 and 0.1 or 0, v_u_68 * 0.2, v_u_68 * 1.8, v_u_68 * 0.6)
					local v_u_350 = CFrame.identity
					local v351 = p_u_63.ticks
					local function v368(p352, p353)
						-- upvalues: (copy) v_u_323, (copy) v_u_335, (copy) v_u_349, (copy) v_u_334, (copy) v_u_68, (ref) v_u_350
						local v354 = v_u_323(p353, v_u_335)
						local v355 = v_u_349
						local v356 = v354 - v355.k
						if math.abs(v356) >= 0.01 then
							v355.k = v354
							local v357 = math.max(v354, 0.02)
							local v358 = v355.wide * v357
							local v359 = v355.len * v357
							local v360 = v355.deep * v357 / 2
							local v361 = Vector3.new(v358, v359, v360)
							v355.a.Size = v361
							v355.b.Size = v361
						end
						local v362 = v_u_334(p352, p353, v_u_335)
						local v363 = v362.Position - Vector3.new(0, 1, 0) * (v_u_68 * 0.45 * math.max(v354, 0) + 0.35)
						local v364 = v362.UpVector.X
						local v365 = v362.UpVector.Z
						local v366 = Vector3.new(v364, 0, v365)
						local v367 = v366.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v366.Unit
						v_u_350 = CFrame.lookAt(v363, v363 + v367) * CFrame.Angles(-0.35, 0, 0)
					end
					table.insert(v351, v368)
					v_u_51(p_u_62, p_u_63, v_u_349, function()
						-- upvalues: (ref) v_u_350
						return v_u_350
					end)
				end
			end
			local v_u_369 = 0
			local v370 = p_u_63.ticks
			local function v372(_, _, p371)
				-- upvalues: (ref) v_u_369, (copy) v_u_98
				v_u_369 = v_u_369 + p371 * (0.5 + 1.6 * v_u_98())
			end
			table.insert(v370, v372)
			local v_u_373 = v_u_369
			for v_u_374 = 1, 4 do
				local v375 = v_u_42
				local v376
				if v_u_374 % 2 == 0 then
					v376 = v_u_9
				else
					v376 = v_u_10
				end
				local v377
				if v_u_374 % 2 == 0 then
					v377 = v_u_12
				else
					v377 = v_u_13
				end
				local v378 = v375(v376, v377, v_u_374 % 2 == 0 and 0.05 or 0, v_u_68 * 0.14, v_u_68 * 1.15, v_u_68 * 0.42)
				local v379 = 1 - v378.k
				if math.abs(v379) >= 0.01 then
					v378.k = 1
					local v380 = v378.wide * 1
					local v381 = v378.len * 1
					local v382 = v378.deep * 1 / 2
					local v383 = Vector3.new(v380, v381, v382)
					v378.a.Size = v383
					v378.b.Size = v383
				end
				v_u_51(p_u_62, p_u_63, v378, function()
					-- upvalues: (copy) p_u_63, (ref) v_u_373, (copy) v_u_374, (copy) v_u_98, (copy) v_u_68
					local v384 = p_u_63.root.CFrame
					local v385 = v_u_373
					local v386 = v385 + v_u_374 * 3.141592653589793 * 2 / 4
					local v387 = (2.3 + 0.9 * v_u_98()) * v_u_68
					local v388 = CFrame.new(v384.Position + Vector3.new(0, 0.1, 0) * v_u_68) * CFrame.Angles(0.3, 0, -0.15)
					local v389 = math.cos(v386) * v387
					local v390 = v386 * 2 + v_u_374
					local v391 = math.sin(v390) * 0.35 * v_u_68
					local v392 = math.sin(v386) * v387
					local v393 = v388 * Vector3.new(v389, v391, v392)
					return CFrame.new(v393) * CFrame.Angles(v385 * 0.7 + v_u_374, v385 * 1.1 + v_u_374 * 2, 0.4) * CFrame.new(0, v_u_68 * -0.42, 0)
				end)
			end
			if v_u_70 or v_u_69 > 1 then
				local v_u_394 = Instance.new("Highlight")
				v_u_394.FillColor = Color3.fromRGB(236, 232, 255)
				v_u_394.FillTransparency = 0.78
				v_u_394.OutlineColor = Color3.fromRGB(190, 170, 255)
				v_u_394.OutlineTransparency = 0.2
				v_u_394.DepthMode = Enum.HighlightDepthMode.Occluded
				v_u_394.Parent = p_u_63.character
				v_u_76 = v_u_394
				p_u_62.own(p_u_63, v_u_394)
				local v395 = p_u_63.stops
				table.insert(v395, function()
					-- upvalues: (copy) v_u_394
					v_u_394:Destroy()
				end)
			end
			p_u_62.particles(p_u_63, "AuraMode", v_u_10, {
				["rate"] = 0.35,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end