local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(255, 222, 70)
local v_u_7 = Color3.fromRGB(255, 190, 50)
local v_u_8 = Enum.Material.SmoothPlastic
local function v_u_17(p9, p10) -- name: piece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v11 = v_u_2:FindFirstChild("EyePieces")
	if v11 then
		v11 = v11:FindFirstChild("w6_kido_seal")
	end
	if not (v11 and v11:IsA("MeshPart")) then
		return nil
	end
	local v12 = v11:Clone()
	v12.Anchored = true
	v12.CanCollide = false
	v12.CanQuery = false
	v12.CanTouch = false
	v12.CastShadow = false
	v12.Massless = true
	local v13 = v11.Size.X
	local v14 = v11.Size.Y
	local v15 = v11.Size.Z
	local v16 = math.max(v13, v14, v15, 0.01)
	v12.Size = v11.Size * (p9 / v16)
	if not v12:FindFirstChildWhichIsA("SurfaceAppearance") then
		v12.Color = p10
	end
	v12.Parent = v_u_4.folder()
	return v12
end
return function(p_u_18)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_3, (copy) v_u_17, (copy) v_u_8, (copy) v_u_7, (copy) v_u_6
	return {
		["w6_kido_seal"] = function(p_u_19, p20)
			-- upvalues: (ref) v_u_4, (copy) p_u_18, (ref) v_u_5, (ref) v_u_1, (ref) v_u_3, (ref) v_u_17, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6
			local v21 = v_u_4.color(p20.color)
			local v_u_22 = v_u_4.color(p20.color2)
			local v23 = p_u_19.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v_u_25 = 0
			local v_u_27 = p_u_18.throb(p_u_19, 4.6, 2, 1.8, function(p26)
				-- upvalues: (ref) v_u_4, (ref) p_u_18, (copy) p_u_19, (copy) v_u_22, (ref) v_u_5
				v_u_4.ring(p_u_18.feetAt(p_u_19, p26, 0.15), v_u_22, 5.5 * p_u_19.fx, 0.5, v_u_5.Ring)
			end)
			local v_u_28 = 0
			local v29 = p_u_19.ticks
			local function v31()
				-- upvalues: (copy) v_u_27, (ref) v_u_28, (ref) v_u_25
				local v30 = v_u_27()
				if v_u_28 + 0.5 < v30 then
					v_u_25 = os.clock()
				end
				v_u_28 = v30
			end
			table.insert(v29, v31)
			local v_u_38 = p_u_18.group(p_u_19, function(p32, p33)
				-- upvalues: (copy) v_u_24
				local v34 = CFrame.new
				local v35 = v_u_24 * 0.75
				local v36 = v_u_24 * 0.08
				local v37 = p33 * 1.3
				return p32 * v34(0, v35 + v36 * math.sin(v37), v_u_24 * 1.25)
			end)
			local v39 = p_u_18.picture(v_u_24 * 4.6, v_u_5.Glow, v21, 0.5)
			p_u_18.add(p_u_19, v39, function()
				-- upvalues: (copy) v_u_38, (copy) v_u_24
				return v_u_38.cf * CFrame.new(0, 0, v_u_24 * -0.3) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v40, v_u_41 = p_u_18.picture(v_u_24 * 4.4, v_u_5.KidoCircle, v_u_22, 0)
			local v_u_42 = v_u_25
			for _, v43 in v_u_41 do
				v43.Color3 = Color3.new(v_u_22.R * 1.7, v_u_22.G * 1.7, v_u_22.B * 1.7)
			end
			p_u_18.add(p_u_19, v40, function(_, p44)
				-- upvalues: (copy) v_u_38
				return v_u_38.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, p44 * 0.35, 0)
			end)
			local v_u_45 = p_u_19.character == v_u_1.LocalPlayer.Character
			local v46 = p_u_19.ticks
			local function v53(p47)
				-- upvalues: (copy) v_u_27, (copy) v_u_45, (ref) v_u_3, (copy) v_u_41
				local v48 = 0.08 * (1 - v_u_27())
				if v_u_45 then
					local v49 = v_u_3.CurrentCamera
					if v49 then
						local v50 = v49.CFrame.LookVector:Dot(p47.LookVector)
						local v51 = math.clamp(v50, 0, 1) * 0.3
						v48 = math.max(v48, v51)
					end
				end
				for _, v52 in v_u_41 do
					v52.Transparency = v48
				end
			end
			table.insert(v46, v53)
			local function v_u_62(_, p54) -- name: hang
				-- upvalues: (copy) v_u_38, (copy) v_u_24
				local v55 = v_u_38.cf * CFrame.new(0, 0, v_u_24 * 0.25)
				local v56 = CFrame.Angles
				local v57 = p54 * 1.1
				local v58 = math.sin(v57) * 0.06
				local v59 = p54 * 0.8
				local v60 = 3.141592653589793 + math.sin(v59) * 0.3
				local v61 = p54 * 1.7
				return v55 * v56(v58, v60, math.sin(v61) * 0.08)
			end
			local v63 = v_u_17(v_u_24 * 2.7, v21)
			if v63 then
				p_u_18.add(p_u_19, v63, v_u_62)
			else
				local v64 = p_u_18.bar(Vector3.new(0.9, 2, 0.06) * v_u_24, v21, 0, v_u_8)
				local v65 = p_u_18.bar(Vector3.new(0.2, 1.6, 0.08) * v_u_24, v_u_22, 0, v_u_8)
				local v66 = p_u_18.bar(Vector3.new(0.12, 0.7, 0.12) * v_u_24, v_u_22, 0, v_u_8)
				p_u_18.add(p_u_19, v64, v_u_62)
				p_u_18.add(p_u_19, v65, v_u_62)
				p_u_18.add(p_u_19, v66, function(p67, p68)
					-- upvalues: (copy) v_u_62, (copy) v_u_24
					return v_u_62(p67, p68) * CFrame.new(0, v_u_24 * -1.35, 0)
				end)
			end
			local v_u_69 = v_u_24 * 1.55
			for v_u_70 = 1, 6 do
				p_u_18.add(p_u_19, p_u_18.ball(v_u_24 * 0.32, v_u_7), function(p71, p72)
					-- upvalues: (copy) v_u_70, (copy) v_u_69, (copy) v_u_24
					local v73 = p72 * 0.8 + v_u_70 / 6 * 3.141592653589793 * 2
					return p71 * CFrame.new(math.cos(v73) * v_u_69, v_u_24 * -0.15, math.sin(v73) * v_u_69)
				end)
				local v_u_74 = p_u_18.bar(Vector3.new(1, 1, 1), v_u_6, 1)
				local v_u_75 = p_u_18.scalable(v_u_74)
				p_u_18.add(p_u_19, v_u_74, function(p76, p77)
					-- upvalues: (copy) v_u_70, (ref) v_u_42, (copy) v_u_74, (copy) v_u_69, (copy) v_u_24, (copy) v_u_75
					local v78 = p77 * 0.8 + v_u_70 / 6 * 3.141592653589793 * 2
					local v79 = os.clock() - v_u_42
					local v80 = 0
					if v79 < 0.12 then
						v80 = v79 / 0.12
					elseif v79 < 0.47 then
						v80 = 1
					elseif v79 < 0.6699999999999999 then
						v80 = 1 - (v79 - 0.12 - 0.35) / 0.2
					end
					v_u_74.Transparency = v80 > 0 and 0 or 1
					local v81 = math.cos(v78) * v_u_69
					local v82 = v_u_24 * -0.15
					local v83 = math.sin(v78) * v_u_69
					local v84 = Vector3.new(v81, v82, v83)
					if v80 <= 0 then
						return p76 * CFrame.new(v84)
					end
					local v85 = v84 * (1 - v80 * 0.75)
					local v86 = (v84 - v85).Magnitude
					local v87 = math.max(v86, 0.05)
					local v88 = v_u_75
					local v89 = v_u_24 * 0.22
					local v90 = v_u_24 * 0.06
					v88.Scale = Vector3.new(v89, v90, v87)
					return p76 * CFrame.lookAt((v84 + v85) / 2, v85)
				end)
			end
			p_u_18.particles(p_u_19, "AuraMode", v21, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow" }
			})
			p_u_18.particles(p_u_19, "Petals", v_u_22, {
				["rate"] = 0.7,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end