local v_u_23 = {
	["KEEP"] = 2,
	["startVisit"] = function(p1, p2, p3) -- name: startVisit
		-- upvalues: (copy) v_u_23
		local v4 = {}
		for _, v5 in p1 do
			if v5.asked <= 0 or (v5.paid or v5.gain <= 0) then
				continue
			end
			table.insert(v4, v5)
		end
		while #v4 > v_u_23.KEEP - 1 do
			table.remove(v4, 1)
		end
		table.clear(p1)
		for _, v6 in v4 do
			table.insert(p1, v6)
		end
		local v7 = (p2 ~= p2 or (p2 <= 0 or p2 >= (1 / 0))) and 0 or p2
		table.insert(p1, {
			["gain"] = nil,
			["at"] = nil,
			["asked"] = 0,
			["paid"] = false,
			["gain"] = v7,
			["at"] = p3
		})
	end,
	["current"] = function(p8) -- name: current
		local v9 = p8[#p8]
		if v9 and (v9.gain > 0 and not v9.paid) then
			return v9
		else
			return nil
		end
	end,
	["extra"] = function(p10, p11) -- name: extra
		if not p10 or p10.paid then
			return 0
		end
		local v12 = p10.gain
		local v13 = p11 - 1
		return v12 * math.max(v13, 0)
	end,
	["ask"] = function(p14, p15) -- name: ask
		-- upvalues: (copy) v_u_23
		local v16 = v_u_23.current(p14)
		if not v16 then
			return false
		end
		v16.asked = p15
		return true
	end,
	["forReceipt"] = function(p17) -- name: forReceipt
		-- upvalues: (copy) v_u_23
		for v18 = #p17, 1, -1 do
			local v19 = p17[v18]
			if v19.asked <= 0 or (v19.paid or v19.gain <= 0) then
				continue
			end
			return v19
		end
		return v_u_23.current(p17)
	end,
	["pay"] = function(p20, p21) -- name: pay
		-- upvalues: (copy) v_u_23
		local v22 = v_u_23.extra(p20, p21)
		p20.paid = true
		return v22
	end
}
return v_u_23