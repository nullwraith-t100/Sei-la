local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(214, 222, 236)
local function v_u_12(p6, p7, p8) -- name: face
	local v9 = p8 - p7 * p8:Dot(p7)
	local v10
	if v9.Magnitude > 0.001 then
		v10 = v9.Unit
	else
		local v11 = p7.Y
		v10 = math.abs(v11) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p6, p7:Cross(v10), p7, v10)
end
local function v_u_20(p13, p14, p15) -- name: toward
	-- upvalues: (copy) v_u_12
	local v16 = p14 - p13
	local v17 = v16.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v16.Unit
	local v18 = Vector3.new(0, 1, 0) - v17 * (Vector3.new(0, 1, 0)):Dot(v17)
	local v19 = v18.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v18.Unit
	return v_u_12(p13, v17, v19:Cross(v17) * math.cos(p15) + v19 * math.sin(p15))
end
return function(p_u_21)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_20, (copy) v_u_5
	return {
		["w4_kurobyougan"] = function(p_u_22, p23)
			-- upvalues: (ref) v_u_2, (ref) v_u_4, (copy) p_u_21, (ref) v_u_3, (ref) v_u_20, (ref) v_u_5
			local v_u_24 = v_u_2.color(p23.color)
			local v25 = p_u_22.headY / 1.5
			local v_u_26 = math.clamp(v25, 0.7, 3)
			local v27 = v_u_4
			local v28 = Color3.new(v27.R * 1.7, v27.G * 1.7, v27.B * 1.7)
			local v_u_29 = 0
			local v_u_30 = 0
			local v_u_31 = Vector3.new(0, 0, 0)
			local v_u_32 = Vector3.new(0, 0, 0)
			local v33 = p_u_22.ticks
			local function v42(p34, p35, p36)
				-- upvalues: (ref) v_u_32, (ref) p_u_21, (ref) v_u_31, (copy) v_u_26, (ref) v_u_29, (ref) v_u_30
				v_u_32 = p_u_21.camPos()
				v_u_31 = (p34 * CFrame.new(0, v_u_26 * 1.1, v_u_26 * 1.3)).Position
				local v37 = p35 < 2.2 and -1 or (p35 - 2.2) % 4.2
				if v37 >= 0 and v37 < 0.5 then
					local v38 = v37 / 0.5
					local v39 = math.clamp(v38, 0, 1)
					v_u_29 = v39 * v39 * (3 - v39 * 2)
				elseif v37 >= 0.5 and v37 < 0.95 then
					local v40 = (v37 - 0.5) / 0.45
					local v41 = math.clamp(v40, 0, 1)
					v_u_29 = 1 - v41 * v41 * (3 - v41 * 2)
				else
					v_u_29 = 0
				end
				v_u_30 = v_u_30 + p36 * (v_u_29 * 14 + 2.6)
			end
			table.insert(v33, v42)
			p_u_21.throb(p_u_22, 4.2, 2.7, 2.4, function(p43)
				-- upvalues: (ref) v_u_2, (ref) v_u_31, (ref) v_u_4, (copy) v_u_26, (copy) p_u_22, (ref) p_u_21, (copy) v_u_24, (ref) v_u_3
				v_u_2.flash(v_u_31, v_u_4, v_u_26 * 5 * p_u_22.fx, 0.3)
				v_u_2.ring(p_u_21.feetAt(p_u_22, p43, 0.15), v_u_24, 7.5 * p_u_22.fx, 0.55, v_u_3.Shockwave)
				v_u_2.burst("Impact", v_u_31, v_u_4, v_u_26 * 1.2)
			end)
			local v_u_44, v_u_45 = p_u_21.picture(v_u_26 * 6.6000000000000005, v_u_3.Glow, v_u_4, 0.45)
			local v_u_46, v_u_47 = p_u_21.picture(v_u_26 * 4.4, v_u_3.KuroStar, v_u_4, 0)
			local v_u_48 = v_u_29
			local v_u_49 = v_u_32
			local v_u_50 = v_u_30
			local v_u_51 = v_u_31
			for _, v52 in v_u_47 do
				v52.Color3 = v28
			end
			local v_u_53 = -1
			local v54 = p_u_22.ticks
			local function v62(p55)
				-- upvalues: (ref) v_u_49, (ref) v_u_48, (ref) v_u_53, (copy) v_u_47, (copy) v_u_45
				local v56 = p55.Position - v_u_49
				local v57 = ((v56.Magnitude <= 0.01 and 0 or v56.Unit:Dot(p55.LookVector)) + 0.1) * 1.6
				local v58 = math.clamp(v57, 0, 1) * 0.55 * (1 - v_u_48)
				local v59 = v58 - v_u_53
				if math.abs(v59) > 0.01 then
					v_u_53 = v58
					for _, v60 in v_u_47 do
						v60.Transparency = v58
					end
					for _, v61 in v_u_45 do
						v61.Transparency = v58 * 0.5 + 0.45
					end
				end
			end
			table.insert(v54, v62)
			p_u_21.add(p_u_22, v_u_46, function()
				-- upvalues: (copy) v_u_26, (ref) v_u_48, (copy) v_u_46, (ref) v_u_20, (ref) v_u_51, (ref) v_u_49, (ref) v_u_50
				local v63 = v_u_26 * 4.4 * (v_u_48 * 0.25 + 1)
				v_u_46.Size = Vector3.new(v63, 0.05, v63)
				return v_u_20(v_u_51, v_u_49, -v_u_50)
			end)
			p_u_21.add(p_u_22, v_u_44, function(_, p64)
				-- upvalues: (copy) v_u_26, (ref) v_u_48, (copy) v_u_44, (ref) v_u_20, (ref) v_u_51, (ref) v_u_49
				local v65 = v_u_26 * 4.4
				local v66 = v_u_48 * 0.5 + 1.4
				local v67 = p64 * 7
				local v68 = v65 * (v66 + math.sin(v67) * 0.06)
				v_u_44.Size = Vector3.new(v68, 0.05, v68)
				local v69 = v_u_20(v_u_51, v_u_49, 0)
				return v69 - v69.UpVector * 0.15
			end)
			local v70 = p_u_21.particles
			local v71 = v_u_4
			local v72 = {
				["rate"] = 0.5,
				["scale"] = nil,
				["glow"] = 0.5,
				["only"] = nil,
				["at"] = nil,
				["scale"] = v_u_26 * 0.42,
				["only"] = { "Disc", "Inner", "Collapse" }
			}
			local v73 = v_u_26 * 1.1
			local v74 = v_u_26 * 1.3 + 0.2
			v72.at = Vector3.new(0, v73, v74)
			v70(p_u_22, "Vortex", v71, v72)
			for v_u_75 = 1, 12 do
				local v_u_76 = v_u_75 * 1.618
				local v_u_77 = (v_u_76 * 3.7 % 0.45 + 0.55) * v_u_26
				local v_u_78 = (v_u_76 * 2.9 % 1.7 + 1.7) * v_u_26
				local v_u_79 = (v_u_75 - 1) / 12
				local v_u_80 = v_u_76 * 5.1 % 6.283185307179586
				local v_u_81, v_u_82 = p_u_21.picture(v_u_77, v_u_3.KuroStar, v_u_4, 0)
				for _, v83 in v_u_82 do
					v83.Color3 = v28
				end
				local v_u_84 = -1
				p_u_21.add(p_u_22, v_u_81, function(p85, p86)
					-- upvalues: (copy) v_u_79, (copy) p_u_22, (copy) v_u_26, (copy) v_u_80, (copy) v_u_75, (copy) v_u_78, (ref) v_u_48, (ref) v_u_51, (ref) v_u_84, (copy) v_u_82, (copy) v_u_77, (copy) v_u_81, (ref) v_u_20, (ref) v_u_49, (copy) v_u_76
					local v87 = (p86 / 3.4 + v_u_79) % 1
					local v88 = p_u_22.headY + v_u_26 * 2.4
					local v89 = v88 + (p_u_22.feet - v88) * v87
					local v90 = v_u_80 + p86 * 0.45 + v87 * 1.6
					local v91 = v_u_26 * 0.35
					local v92 = p86 * 2.1 + v_u_75
					local v93 = v91 * math.sin(v92)
					local v94 = p85.Position
					local v95 = math.cos(v90) * (v_u_78 + v93)
					local v96 = math.sin(v90) * (v_u_78 + v93)
					local v97 = v94 + Vector3.new(v95, v89, v96)
					local v98 = v87 / 0.12
					local v99 = (1 - v87) / 0.18
					local v100 = math.min(v98, v99, 1)
					local v101 = v_u_48
					if v101 > 0 then
						local v102 = v90 + v101 * 5
						local v103 = v_u_78 * (1 - v101)
						local v104 = v_u_51
						local v105 = math.cos(v102) * v103
						local v106 = math.sin(v102) * v103
						v97 = v97:Lerp(v104 + Vector3.new(v105, 0, v106) + Vector3.new(0, 1, 0) * (1 - v101) * 1.5 * v_u_26, v101)
						local v107 = 1 - v101 * 0.4
						v100 = math.max(v100, v107)
					end
					local v108 = 1 - v100
					local v109 = v108 - v_u_84
					if math.abs(v109) > 0.02 then
						v_u_84 = v108
						for _, v110 in v_u_82 do
							v110.Transparency = v108
						end
					end
					local v111 = v_u_77 * (1 - v101 * 0.6)
					v_u_81.Size = Vector3.new(v111, 0.05, v111)
					return v_u_20(v97, v_u_49, p86 * (v_u_76 % 1 + 1.4) + v_u_76)
				end)
			end
			for v_u_112 = 1, 2 do
				local v113 = p_u_21.bar(Vector3.new(0.2, 0.2, 0.2), v_u_4, 1)
				p_u_21.tail(v113, v_u_4, v_u_5, v_u_26 * 0.35, 0.5)
				p_u_21.add(p_u_22, v113, function(p114, p115)
					-- upvalues: (copy) v_u_112, (copy) v_u_26, (ref) v_u_48
					local v116 = p115 * (v_u_112 * 0.5 + 3.4) + v_u_112 * 3.141592653589793
					local v117 = p115 * 1.3 + v_u_112
					local v118 = (math.sin(v117) * 0.4 + 2.1) * v_u_26 * (v_u_48 * 0.4 + 1)
					local v119 = p115 * 1.1 + v_u_112 * 2
					local v120 = (math.sin(v119) * 0.6 + (v_u_112 - 1.5) * 1.2) * v_u_26
					local v121 = CFrame.new
					local v122 = p114.Position
					local v123 = math.cos(v116) * v118
					local v124 = math.sin(v116) * v118
					return v121(v122 + Vector3.new(v123, v120, v124))
				end)
			end
			local v125 = p_u_21.picture(v_u_26 * 7, v_u_3.Glow, v_u_5, 0.55)
			p_u_21.add(p_u_22, v125, function(p126)
				-- upvalues: (ref) p_u_21, (copy) p_u_22
				return CFrame.new(p_u_21.feetAt(p_u_22, p126, 0.07))
			end)
			p_u_21.particles(p_u_22, "AuraMode", v_u_24, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
			p_u_21.particles(p_u_22, "Petals", v_u_4, {
				["rate"] = 0.7,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end