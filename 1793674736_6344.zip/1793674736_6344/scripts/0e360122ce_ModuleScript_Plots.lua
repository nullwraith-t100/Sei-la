local v_u_1 = require(script.Parent.Training)
local v2 = {}
local v_u_3 = {
	v_u_1,
	require(script.Parent.Training2),
	require(script.Parent.Training3),
	require(script.Parent.Training4),
	require(script.Parent.Training5),
	require(script.Parent.Training6),
	require(script.Parent.Training7),
	(require(script.Parent.Training8))
}
function v2.forWorld(p4) -- name: forWorld
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	return v_u_3[p4 or 1] or v_u_1
end
return v2