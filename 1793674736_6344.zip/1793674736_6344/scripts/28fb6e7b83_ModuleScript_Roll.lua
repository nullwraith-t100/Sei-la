local v_u_13 = {
	["total"] = function(p1) -- name: total
		local v2 = 0
		for _, v3 in p1 do
			v2 = v2 + v3
		end
		return v2
	end,
	["pick"] = function(p4, p5) -- name: pick
		-- upvalues: (copy) v_u_13
		local v6 = math.clamp(p5, 0, 0.999999) * v_u_13.total(p4)
		local v7 = 0
		for v8, v9 in p4 do
			v7 = v7 + v9
			if v6 >= v7 then
				continue
			end
			return v8
		end
		return #p4
	end,
	["chance"] = function(p10, p11) -- name: chance
		-- upvalues: (copy) v_u_13
		local v12 = v_u_13.total(p10)
		return v12 <= 0 and 0 or p10[p11] / v12
	end
}
return v_u_13