local v1 = {
	{
		["id"] = "fireball",
		["name"] = "Fireball",
		["kind"] = "bolt",
		["style"] = "fireball",
		["sound"] = "Fireball",
		["power"] = 1,
		["cooldown"] = 0.28,
		["range"] = 70,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 190
	},
	{
		["id"] = "phoenix_flowers",
		["name"] = "Phoenix Flowers",
		["kind"] = "spread",
		["style"] = "phoenix",
		["sound"] = "Fireball",
		["power"] = 1.4,
		["cooldown"] = 5.5,
		["range"] = 70,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 180,
		["count"] = 5,
		["spreadAngle"] = 50
	},
	{
		["id"] = "genjutsu",
		["name"] = "Genjutsu: Bind",
		["kind"] = "bind",
		["style"] = "genjutsu",
		["sound"] = "Bind",
		["power"] = 2.5,
		["cooldown"] = 10,
		["range"] = 0,
		["radius"] = 20,
		["delay"] = 0.2,
		["freeze"] = 3,
		["at"] = "self"
	},
	{
		["id"] = "amaterasu_spark",
		["name"] = "Black Flame",
		["kind"] = "bolt",
		["style"] = "black_spark",
		["sound"] = "Fireball",
		["power"] = 1.1,
		["cooldown"] = 0.28,
		["range"] = 70,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 190
	},
	{
		["id"] = "amaterasu",
		["name"] = "Amaterasu",
		["kind"] = "zone",
		["style"] = "amaterasu",
		["sound"] = "Flames",
		["power"] = 0.9,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 9,
		["duration"] = 4,
		["tick"] = 0.5,
		["delay"] = 0.12
	},
	{
		["id"] = "kamui",
		["name"] = "Kamui",
		["kind"] = "zone",
		["style"] = "kamui",
		["sound"] = "Vortex",
		["power"] = 1.2,
		["cooldown"] = 10,
		["range"] = 60,
		["radius"] = 13,
		["duration"] = 2,
		["tick"] = 0.4,
		["pull"] = 9,
		["finalPower"] = 6,
		["delay"] = 0.2
	},
	{
		["id"] = "command_ray",
		["name"] = "Command Ray",
		["kind"] = "beam",
		["style"] = "geass_ray",
		["sound"] = "Laser",
		["power"] = 1.15,
		["cooldown"] = 0.28,
		["range"] = 60,
		["radius"] = 0,
		["width"] = 3.5,
		["delay"] = 0.03
	},
	{
		["id"] = "command_kneel",
		["name"] = "Command: Kneel",
		["kind"] = "bind",
		["style"] = "geass_kneel",
		["sound"] = "Bind",
		["power"] = 3,
		["cooldown"] = 5.5,
		["range"] = 0,
		["radius"] = 22,
		["delay"] = 0.12,
		["freeze"] = 4,
		["at"] = "self"
	},
	{
		["id"] = "command_perish",
		["name"] = "Command: Perish",
		["kind"] = "burst",
		["style"] = "geass_perish",
		["sound"] = "Burst",
		["power"] = 8,
		["cooldown"] = 10,
		["range"] = 50,
		["radius"] = 18,
		["delay"] = 0.25,
		["at"] = "target"
	},
	{
		["id"] = "blaze_arrow",
		["name"] = "Blaze Arrow",
		["kind"] = "bolt",
		["style"] = "blaze_arrow",
		["sound"] = "Orb",
		["power"] = 1.2,
		["cooldown"] = 0.27,
		["range"] = 80,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 230
	},
	{
		["id"] = "blaze_release",
		["name"] = "Blaze Release",
		["kind"] = "zone",
		["style"] = "blaze_release",
		["sound"] = "Flames",
		["power"] = 1.4,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 11,
		["duration"] = 4,
		["tick"] = 0.5,
		["delay"] = 0.12
	},
	{
		["id"] = "susanoo_arrow",
		["name"] = "Susanoo Arrow",
		["kind"] = "beam",
		["style"] = "susanoo_arrow",
		["sound"] = "Laser",
		["power"] = 14,
		["cooldown"] = 10,
		["range"] = 90,
		["radius"] = 0,
		["width"] = 7,
		["delay"] = 0.22
	},
	{
		["id"] = "chakra_rod",
		["name"] = "Chakra Rod",
		["kind"] = "bolt",
		["style"] = "rod",
		["sound"] = "Orb",
		["power"] = 1.25,
		["cooldown"] = 0.27,
		["range"] = 75,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 220
	},
	{
		["id"] = "shinra_tensei",
		["name"] = "Shinra Tensei",
		["kind"] = "burst",
		["style"] = "shinra",
		["sound"] = "Burst",
		["power"] = 6,
		["cooldown"] = 5.5,
		["range"] = 0,
		["radius"] = 24,
		["delay"] = 0.1,
		["push"] = 30,
		["at"] = "self"
	},
	{
		["id"] = "chibaku_tensei",
		["name"] = "Chibaku Tensei",
		["kind"] = "zone",
		["style"] = "chibaku",
		["sound"] = "Vortex",
		["power"] = 1.6,
		["cooldown"] = 10,
		["range"] = 60,
		["radius"] = 15,
		["duration"] = 2.4,
		["tick"] = 0.4,
		["pull"] = 10,
		["finalPower"] = 12,
		["delay"] = 0.2
	},
	{
		["id"] = "jogan_pulse",
		["name"] = "Jogan Pulse",
		["kind"] = "beam",
		["style"] = "jogan_bolt",
		["sound"] = "Lightning",
		["power"] = 1.3,
		["cooldown"] = 0.27,
		["range"] = 65,
		["radius"] = 0,
		["width"] = 3.5,
		["delay"] = 0.03
	},
	{
		["id"] = "dimension_rift",
		["name"] = "Dimension Rift",
		["kind"] = "zone",
		["style"] = "rift",
		["sound"] = "Lightning",
		["power"] = 2,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 11,
		["duration"] = 1.6,
		["tick"] = 0.32,
		["pull"] = 6,
		["finalPower"] = 6,
		["delay"] = 0.12
	},
	{
		["id"] = "jogan_laser",
		["name"] = "Jogan Laser",
		["kind"] = "beam",
		["style"] = "jogan_laser",
		["sound"] = "Laser",
		["power"] = 18,
		["cooldown"] = 10,
		["range"] = 90,
		["radius"] = 0,
		["width"] = 6,
		["delay"] = 0.22
	},
	{
		["id"] = "truth_orb",
		["name"] = "Truth-Seeking Orb",
		["kind"] = "bolt",
		["style"] = "truth_orb",
		["sound"] = "Orb",
		["power"] = 1.35,
		["cooldown"] = 0.27,
		["range"] = 75,
		["radius"] = 6,
		["width"] = 3.5,
		["speed"] = 200
	},
	{
		["id"] = "orb_barrage",
		["name"] = "Truth-Seeking Barrage",
		["kind"] = "rain",
		["style"] = "orb_rain",
		["sound"] = "Rain",
		["power"] = 3,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 14,
		["strikeRadius"] = 6,
		["count"] = 8,
		["duration"] = 0.9,
		["delay"] = 0.12
	},
	{
		["id"] = "planetary_devastation",
		["name"] = "Planetary Devastation",
		["kind"] = "zone",
		["style"] = "planetary",
		["sound"] = "Vortex",
		["power"] = 2.5,
		["cooldown"] = 10,
		["range"] = 60,
		["radius"] = 16,
		["duration"] = 2.4,
		["tick"] = 0.4,
		["pull"] = 11,
		["finalPower"] = 20,
		["delay"] = 0.2
	},
	{
		["id"] = "tomoe_orb",
		["name"] = "Tomoe Orb",
		["kind"] = "bolt",
		["style"] = "tomoe_orb",
		["sound"] = "Orb",
		["power"] = 1.45,
		["cooldown"] = 0.26,
		["range"] = 75,
		["radius"] = 6,
		["width"] = 3.5,
		["speed"] = 210
	},
	{
		["id"] = "limbo_strike",
		["name"] = "Limbo Strike",
		["kind"] = "burst",
		["style"] = "limbo",
		["sound"] = "Burst",
		["power"] = 9,
		["cooldown"] = 5.5,
		["range"] = 55,
		["radius"] = 16,
		["delay"] = 0.14,
		["at"] = "target"
	},
	{
		["id"] = "infinite_tsukuyomi",
		["name"] = "Infinite Tsukuyomi",
		["kind"] = "bind",
		["style"] = "tsukuyomi",
		["sound"] = "Bind",
		["power"] = 14,
		["cooldown"] = 11,
		["range"] = 0,
		["radius"] = 40,
		["delay"] = 0.25,
		["freeze"] = 5,
		["at"] = "self"
	},
	{
		["id"] = "light_arrow",
		["name"] = "Light Arrow",
		["kind"] = "bolt",
		["style"] = "light_arrow",
		["sound"] = "Orb",
		["power"] = 1.5,
		["cooldown"] = 0.26,
		["range"] = 85,
		["radius"] = 4,
		["width"] = 3,
		["speed"] = 250
	},
	{
		["id"] = "arrow_storm",
		["name"] = "Arrow Storm",
		["kind"] = "rain",
		["style"] = "arrow_rain",
		["sound"] = "Rain",
		["power"] = 3.5,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 16,
		["strikeRadius"] = 5,
		["count"] = 12,
		["duration"] = 1,
		["delay"] = 0.12
	},
	{
		["id"] = "clairvoyant_judgement",
		["name"] = "Clairvoyant Judgement",
		["kind"] = "beam",
		["style"] = "judgement",
		["sound"] = "Laser",
		["power"] = 24,
		["cooldown"] = 10,
		["range"] = 90,
		["radius"] = 0,
		["width"] = 8,
		["delay"] = 0.22
	},
	{
		["id"] = "sealing_light",
		["name"] = "Sealing Light",
		["kind"] = "beam",
		["style"] = "seal_ray",
		["sound"] = "Laser",
		["power"] = 1.55,
		["cooldown"] = 0.27,
		["range"] = 65,
		["radius"] = 0,
		["width"] = 4,
		["delay"] = 0.03
	},
	{
		["id"] = "sealing_lotus",
		["name"] = "Sealing Lotus",
		["kind"] = "zone",
		["style"] = "lotus",
		["sound"] = "Bind",
		["power"] = 2.8,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 13,
		["duration"] = 2,
		["tick"] = 0.4,
		["pull"] = 7,
		["freeze"] = 0.6,
		["delay"] = 0.12
	},
	{
		["id"] = "prophecy",
		["name"] = "Prophecy",
		["kind"] = "rain",
		["style"] = "prophecy",
		["sound"] = "Rain",
		["power"] = 9,
		["cooldown"] = 10,
		["range"] = 60,
		["radius"] = 18,
		["strikeRadius"] = 8,
		["count"] = 6,
		["duration"] = 1.1,
		["delay"] = 0.2
	},
	{
		["id"] = "lapse_blue",
		["name"] = "Lapse: Blue",
		["kind"] = "bolt",
		["style"] = "blue",
		["sound"] = "Orb",
		["power"] = 1.7,
		["cooldown"] = 0.25,
		["range"] = 80,
		["radius"] = 7,
		["width"] = 4,
		["speed"] = 210
	},
	{
		["id"] = "reversal_red",
		["name"] = "Reversal: Red",
		["kind"] = "bolt",
		["style"] = "red",
		["sound"] = "Explosion",
		["power"] = 10,
		["cooldown"] = 5.5,
		["range"] = 80,
		["radius"] = 12,
		["width"] = 5,
		["speed"] = 240,
		["push"] = 25
	},
	{
		["id"] = "hollow_purple",
		["name"] = "Hollow Purple",
		["kind"] = "beam",
		["style"] = "purple",
		["sound"] = "Laser",
		["power"] = 36,
		["cooldown"] = 11,
		["range"] = 100,
		["radius"] = 0,
		["width"] = 12,
		["delay"] = 0.25
	},
	{
		["id"] = "god_ray",
		["name"] = "God Ray",
		["kind"] = "beam",
		["style"] = "god_ray",
		["sound"] = "Laser",
		["power"] = 1.85,
		["cooldown"] = 0.25,
		["range"] = 70,
		["radius"] = 0,
		["width"] = 4,
		["delay"] = 0.03
	},
	{
		["id"] = "divine_judgement",
		["name"] = "Divine Judgement",
		["kind"] = "rain",
		["style"] = "divine_swords",
		["sound"] = "Rain",
		["power"] = 4.5,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 15,
		["strikeRadius"] = 6.5,
		["count"] = 10,
		["duration"] = 0.7,
		["delay"] = 0.12
	},
	{
		["id"] = "heavens_gaze",
		["name"] = "Heaven\'s Gaze",
		["kind"] = "burst",
		["style"] = "heavens_gaze",
		["sound"] = "Burst",
		["power"] = 42,
		["cooldown"] = 11,
		["range"] = 60,
		["radius"] = 24,
		["delay"] = 0.25,
		["at"] = "target"
	},
	{
		["id"] = "sukunahikona",
		["name"] = "Sukunahikona",
		["kind"] = "bolt",
		["style"] = "sukunahikona",
		["sound"] = "Orb",
		["power"] = 1.78,
		["cooldown"] = 0.25,
		["range"] = 80,
		["radius"] = 6,
		["width"] = 3.5,
		["speed"] = 230
	},
	{
		["id"] = "daikokuten",
		["name"] = "Daikokuten",
		["kind"] = "rain",
		["style"] = "daikokuten",
		["sound"] = "Rain",
		["power"] = 7,
		["cooldown"] = 5.5,
		["range"] = 60,
		["radius"] = 14,
		["strikeRadius"] = 7,
		["count"] = 6,
		["duration"] = 0.6,
		["delay"] = 0.12
	},
	{
		["id"] = "karma_cube",
		["name"] = "Karma: Daikokuten Cube",
		["kind"] = "burst",
		["style"] = "karma_cube",
		["sound"] = "Burst",
		["power"] = 39,
		["cooldown"] = 11,
		["range"] = 55,
		["radius"] = 20,
		["delay"] = 0.25,
		["at"] = "target"
	},
	{
		["id"] = "blood_needles",
		["name"] = "Blood Needles",
		["kind"] = "bolt",
		["style"] = "blood_needles",
		["sound"] = "Orb",
		["power"] = 2,
		["cooldown"] = 0.24,
		["range"] = 80,
		["radius"] = 6,
		["width"] = 4,
		["speed"] = 260
	},
	{
		["id"] = "crimson_crescent",
		["name"] = "Crimson Crescent",
		["kind"] = "beam",
		["style"] = "crimson_crescent",
		["sound"] = "Fireball",
		["power"] = 13,
		["cooldown"] = 5.5,
		["range"] = 70,
		["radius"] = 0,
		["width"] = 10,
		["delay"] = 0.1
	},
	{
		["id"] = "blood_moon",
		["name"] = "Blood Moon",
		["kind"] = "burst",
		["style"] = "blood_moon",
		["sound"] = "Burst",
		["power"] = 48,
		["cooldown"] = 11,
		["range"] = 55,
		["radius"] = 26,
		["delay"] = 0.25,
		["at"] = "target"
	}
}
local v2 = {}
for _, v3 in v1 do
	v2[v3.id] = v3
end
local v4 = {}
local v9 = {
	["eye"] = "beast_gaze",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Beast Fang"
	},
	["e"] = {
		["base"] = "command_kneel",
		["name"] = "Beast Cage",
		["tune"] = nil,
		["tune"] = function(p5) -- name: tune
			local v_u_6 = 55
			local v_u_7 = 16
			(function(p8)
				-- upvalues: (copy) v_u_6, (copy) v_u_7
				p8.at = "target"
				p8.range = v_u_6
				p8.radius = v_u_7
			end)(p5)
			p5.freeze = 3
		end
	}
}
local v10 = {
	["base"] = "heavens_gaze",
	["name"] = "Beast Roar",
	["tune"] = nil
}
local v_u_11 = 28
local v_u_12 = 35
function v10.tune(p13)
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	p13.at = "self"
	p13.range = 0
	p13.radius = v_u_11
	p13.push = v_u_12
end
v9.r = v10
local v16 = {
	["eye"] = "lotus_eye",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Petal Star"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Lotus Bloom",
		["tune"] = nil,
		["tune"] = function(p14) -- name: tune
			p14.kind = "bind"
			p14.freeze = 2
		end
	},
	["r"] = {
		["base"] = "prophecy",
		["name"] = "Thousand Petals",
		["tune"] = nil,
		["tune"] = function(p15) -- name: tune
			p15.count = 12
			p15.power = p15.power * 0.6
			p15.strikeRadius = 6.5
		end
	}
}
local v18 = {
	["eye"] = "phantom_pinwheel",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Phantom Shuriken"
	},
	["e"] = {
		["base"] = "kamui",
		["name"] = "Pinwheel Warp",
		["tune"] = nil,
		["tune"] = function(p17) -- name: tune
			p17.cooldown = 5.5
			p17.power = p17.power * 0.55
			p17.finalPower = (p17.finalPower or 0) * 0.55
		end
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "World Flip"
	}
}
local v23 = {
	["eye"] = "grave_rinne",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Soul Wisp"
	},
	["e"] = {
		["base"] = "command_kneel",
		["name"] = "Grave Hands",
		["tune"] = nil,
		["tune"] = function(p19) -- name: tune
			local v_u_20 = 55
			local v_u_21 = 15
			(function(p22)
				-- upvalues: (copy) v_u_20, (copy) v_u_21
				p22.at = "target"
				p22.range = v_u_20
				p22.radius = v_u_21
			end)(p19)
			p19.freeze = 3
		end
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Underworld Gate"
	}
}
local v25 = {
	["eye"] = "oracle_eye",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Fate Needle"
	},
	["e"] = {
		["base"] = "command_kneel",
		["name"] = "Fate Threads"
	},
	["r"] = {
		["base"] = "heavens_gaze",
		["name"] = "Fate Clock",
		["tune"] = nil,
		["tune"] = function(p24) -- name: tune
			p24.kind = "bind"
			p24.freeze = 3
		end
	}
}
local v27 = {
	["eye"] = "prism_eye",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Prism Ray"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Rainbow Shards",
		["tune"] = nil,
		["tune"] = function(p26) -- name: tune
			p26.count = 7
			p26.spreadAngle = 60
		end
	},
	["r"] = {
		["base"] = "heavens_gaze",
		["name"] = "Prism Judgement"
	}
}
__set_list(v4, 1, {v9, {
	["eye"] = "violet_halo",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Halo Disc"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Halo Ring"
	},
	["r"] = {
		["base"] = "prophecy",
		["name"] = "Halo Fall"
	}
}, {
	["eye"] = "venom_tomoe",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Venom Spit"
	},
	["e"] = {
		["base"] = "amaterasu",
		["name"] = "Venom Mire"
	},
	["r"] = {
		["base"] = "susanoo_arrow",
		["name"] = "Plague Serpent"
	}
}, v16, v18, {
	["eye"] = "amethyst_star",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Star Shard"
	},
	["e"] = {
		["base"] = "command_kneel",
		["name"] = "Star Seal"
	},
	["r"] = {
		["base"] = "heavens_gaze",
		["name"] = "Amethyst Nova"
	}
}, v23, {
	["eye"] = "jade_seal",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Jade Talisman"
	},
	["e"] = {
		["base"] = "daikokuten",
		["name"] = "Jade Pillars"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Jade Dragon"
	}
}, {
	["eye"] = "solar_lotus",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Sun Ray"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Corona Flare"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Supernova"
	}
}, {
	["eye"] = "crimson_spiral",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Spiral Drill"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Blood Vortex"
	},
	["r"] = {
		["base"] = "hollow_purple",
		["name"] = "Spiral Cannon"
	}
}, {
	["eye"] = "sage_rings",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sealing_light",
		["name"] = "Tomoe Chain"
	},
	["e"] = {
		["base"] = "divine_judgement",
		["name"] = "Tomoe Rain"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Sage Verdict"
	}
}, v25, {
	["eye"] = "celestial_gaze",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Star Bolt"
	},
	["e"] = {
		["base"] = "arrow_storm",
		["name"] = "Constellation"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Galaxy Collapse"
	}
}, v27, {
	["eye"] = "six_paths_sage",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Rasengan"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Rasenshuriken"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Tailed Beast Bomb"
	}
}})
for v28, v29 in v4 do
	local v30 = v28 * 0.02 + 1.1
	local v31 = v29.a
	local v32 = v29.eye .. "_a"
	local v33 = table.clone(v2[v31.base])
	v33.id = v32
	v33.name = v31.name
	v33.style = v32
	v33.power = v33.power * v30
	if v33.finalPower then
		v33.finalPower = v33.finalPower * v30
	end
	local v34 = v31.tune
	if v34 then
		v34(v33)
	end
	table.insert(v1, v33)
	local v35 = v29.e
	local v36 = v29.eye .. "_e"
	local v37 = table.clone(v2[v35.base])
	v37.id = v36
	v37.name = v35.name
	v37.style = v36
	v37.power = v37.power * v30
	if v37.finalPower then
		v37.finalPower = v37.finalPower * v30
	end
	local v38 = v35.tune
	if v38 then
		v38(v37)
	end
	table.insert(v1, v37)
	local v39 = v29.r
	local v40 = v29.eye .. "_r"
	local v41 = table.clone(v2[v39.base])
	v41.id = v40
	v41.name = v39.name
	v41.style = v40
	v41.power = v41.power * v30
	if v41.finalPower then
		v41.finalPower = v41.finalPower * v30
	end
	local v42 = v39.tune
	if v42 then
		v42(v41)
	end
	table.insert(v1, v41)
end
local v43 = {}
local v44 = {
	["eye"] = "blossom_orbit",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Orb Flick"
	}
}
local v45 = {
	["base"] = "command_kneel",
	["name"] = "Orbit Lock",
	["tune"] = nil
}
local v_u_46 = 55
local v_u_47 = 16
local v_u_48 = 2.5
function v45.tune(p49)
	-- upvalues: (copy) v_u_46, (copy) v_u_47, (copy) v_u_48
	local v_u_50 = v_u_46
	local v_u_51 = v_u_47;
	(function(p52)
		-- upvalues: (copy) v_u_50, (copy) v_u_51
		p52.at = "target"
		p52.range = v_u_50
		p52.radius = v_u_51
	end)(p49)
	p49.freeze = v_u_48
end
v44.e = v45
v44.r = {
	["base"] = "susanoo_arrow",
	["name"] = "Trinity Beam"
}
local v53 = {
	["eye"] = "crimson_bloom",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Blood Pollen"
	}
}
local v54 = {
	["base"] = "command_kneel",
	["name"] = "Root Snare",
	["tune"] = nil
}
local v_u_55 = 55
local v_u_56 = 14
local v_u_57 = 2.5
function v54.tune(p58)
	-- upvalues: (copy) v_u_55, (copy) v_u_56, (copy) v_u_57
	local v_u_59 = v_u_55
	local v_u_60 = v_u_56;
	(function(p61)
		-- upvalues: (copy) v_u_59, (copy) v_u_60
		p61.at = "target"
		p61.range = v_u_59
		p61.radius = v_u_60
	end)(p58)
	p58.freeze = v_u_57
end
v53.e = v54
v53.r = {
	["base"] = "prophecy",
	["name"] = "Blood Rain"
}
local v62 = {
	["eye"] = "void_compass",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Compass Needle"
	}
}
local v63 = {
	["base"] = "command_kneel",
	["name"] = "Cardinal Seal",
	["tune"] = nil
}
local v_u_64 = 55
local v_u_65 = 16
local v_u_66 = 2.5
function v63.tune(p67)
	-- upvalues: (copy) v_u_64, (copy) v_u_65, (copy) v_u_66
	local v_u_68 = v_u_64
	local v_u_69 = v_u_65;
	(function(p70)
		-- upvalues: (copy) v_u_68, (copy) v_u_69
		p70.at = "target"
		p70.range = v_u_68
		p70.radius = v_u_69
	end)(p67)
	p67.freeze = v_u_66
end
v62.e = v63
v62.r = {
	["base"] = "hollow_purple",
	["name"] = "Meridian Ray"
}
local v71 = {
	["eye"] = "eclipse_spiral",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "amaterasu_spark",
		["name"] = "Corona Spark"
	}
}
local v72 = {
	["base"] = "command_kneel",
	["name"] = "Umbra Chains",
	["tune"] = nil
}
local v_u_73 = 55
local v_u_74 = 16
local v_u_75 = 2.5
function v72.tune(p76)
	-- upvalues: (copy) v_u_73, (copy) v_u_74, (copy) v_u_75
	local v_u_77 = v_u_73
	local v_u_78 = v_u_74;
	(function(p79)
		-- upvalues: (copy) v_u_77, (copy) v_u_78
		p79.at = "target"
		p79.range = v_u_77
		p79.radius = v_u_78
	end)(p76)
	p76.freeze = v_u_75
end
v71.e = v72
v71.r = {
	["base"] = "heavens_gaze",
	["name"] = "Total Eclipse"
}
local v81 = {
	["eye"] = "thorn_halo",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Light Thorn"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Radiant Spikes",
		["tune"] = nil,
		["tune"] = function(p80) -- name: tune
			p80.count = 7
			p80.spreadAngle = 60
		end
	}
}
local v82 = {
	["base"] = "heavens_gaze",
	["name"] = "Starburst Crown",
	["tune"] = nil
}
local v_u_83 = 30
local v_u_84 = 30
function v82.tune(p85)
	-- upvalues: (copy) v_u_83, (copy) v_u_84
	p85.at = "self"
	p85.range = 0
	p85.radius = v_u_83
	p85.push = v_u_84
end
v81.r = v82
__set_list(v43, 1, {v44, {
	["eye"] = "thorn_blossom",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Thorn Seed"
	},
	["e"] = {
		["base"] = "arrow_storm",
		["name"] = "Thorn Volley"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Bramble Prison"
	}
}, v53, {
	["eye"] = "nightshade_pinwheel",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Night Moth"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Windmill Cutter"
	},
	["r"] = {
		["base"] = "kamui",
		["name"] = "Nightfall"
	}
}, {
	["eye"] = "iron_mandala",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Gear Bullet"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Piston Slam"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Mandala Crusher"
	}
}, v62, {
	["eye"] = "blood_trident",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Trident Tip"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Blood Spears"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Trident Judgement"
	}
}, {
	["eye"] = "moon_rinne",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Moon Shard"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Lunar Tide"
	},
	["r"] = {
		["base"] = "prophecy",
		["name"] = "Moonfall"
	}
}, {
	["eye"] = "rift_crescent",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Rift Shot"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Crescent Guillotine"
	},
	["r"] = {
		["base"] = "jogan_laser",
		["name"] = "Rift Splitter"
	}
}, {
	["eye"] = "scarlet_whirl",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Whirl Disc"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Scarlet Blades"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Thousand Cuts"
	}
}, v71, {
	["eye"] = "inferno_star",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "fireball",
		["name"] = "Star Ember"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Hellfire Ring"
	},
	["r"] = {
		["base"] = "clairvoyant_judgement",
		["name"] = "Solar Lance"
	}
}, v81, {
	["eye"] = "arcane_sigil",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Rune Bolt"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Hex Circle"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Arcane Cataclysm"
	}
}})
for v86, v87 in v43 do
	local v88 = v86 * 0.02 + 1.4
	local v89 = v87.a
	local v90 = v87.eye .. "_a"
	local v91 = table.clone(v2[v89.base])
	v91.id = v90
	v91.name = v89.name
	v91.style = v90
	v91.power = v91.power * v88
	if v91.finalPower then
		v91.finalPower = v91.finalPower * v88
	end
	local v92 = v89.tune
	if v92 then
		v92(v91)
	end
	table.insert(v1, v91)
	local v93 = v87.e
	local v94 = v87.eye .. "_e"
	local v95 = table.clone(v2[v93.base])
	v95.id = v94
	v95.name = v93.name
	v95.style = v94
	v95.power = v95.power * v88
	if v95.finalPower then
		v95.finalPower = v95.finalPower * v88
	end
	local v96 = v93.tune
	if v96 then
		v96(v95)
	end
	table.insert(v1, v95)
	local v97 = v87.r
	local v98 = v87.eye .. "_r"
	local v99 = table.clone(v2[v97.base])
	v99.id = v98
	v99.name = v97.name
	v99.style = v98
	v99.power = v99.power * v88
	if v99.finalPower then
		v99.finalPower = v99.finalPower * v88
	end
	local v100 = v97.tune
	if v100 then
		v100(v99)
	end
	table.insert(v1, v99)
end
local v101 = {}
local v102 = {
	["eye"] = "frost_thorn",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Ice Thorn"
	}
}
local v103 = {
	["base"] = "command_kneel",
	["name"] = "Frostbite",
	["tune"] = nil
}
local v_u_104 = 55
local v_u_105 = 16
local v_u_106 = 2.5
function v103.tune(p107)
	-- upvalues: (copy) v_u_104, (copy) v_u_105, (copy) v_u_106
	local v_u_108 = v_u_104
	local v_u_109 = v_u_105;
	(function(p110)
		-- upvalues: (copy) v_u_108, (copy) v_u_109
		p110.at = "target"
		p110.range = v_u_108
		p110.radius = v_u_109
	end)(p107)
	p107.freeze = v_u_106
end
v102.e = v103
v102.r = {
	["base"] = "prophecy",
	["name"] = "Hailstorm"
}
local v111 = {
	["eye"] = "starsea_rinne",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Nebula Orb"
	}
}
local v112 = {
	["base"] = "command_kneel",
	["name"] = "Gravity Well",
	["tune"] = nil
}
local v_u_113 = 55
local v_u_114 = 16
local v_u_115 = 2.5
function v112.tune(p116)
	-- upvalues: (copy) v_u_113, (copy) v_u_114, (copy) v_u_115
	local v_u_117 = v_u_113
	local v_u_118 = v_u_114;
	(function(p119)
		-- upvalues: (copy) v_u_117, (copy) v_u_118
		p119.at = "target"
		p119.range = v_u_117
		p119.radius = v_u_118
	end)(p116)
	p116.freeze = v_u_115
end
v111.e = v112
v111.r = {
	["base"] = "clairvoyant_judgement",
	["name"] = "Galactic Tide"
}
local v120 = {
	["eye"] = "azure_flame",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "fireball",
		["name"] = "Azure Ember"
	},
	["e"] = {
		["base"] = "amaterasu",
		["name"] = "Cold Fire"
	}
}
local v121 = {
	["base"] = "heavens_gaze",
	["name"] = "Azure Inferno",
	["tune"] = nil
}
local v_u_122 = 30
local v_u_123 = 30
function v121.tune(p124)
	-- upvalues: (copy) v_u_122, (copy) v_u_123
	p124.at = "self"
	p124.range = 0
	p124.radius = v_u_122
	p124.push = v_u_123
end
v120.r = v121
local v125 = {
	["eye"] = "polar_dial",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Clock Hand"
	}
}
local v126 = {
	["base"] = "command_kneel",
	["name"] = "Frozen Hour",
	["tune"] = nil
}
local v_u_127 = 55
local v_u_128 = 18
local v_u_129 = 3
function v126.tune(p130)
	-- upvalues: (copy) v_u_127, (copy) v_u_128, (copy) v_u_129
	local v_u_131 = v_u_127
	local v_u_132 = v_u_128;
	(function(p133)
		-- upvalues: (copy) v_u_131, (copy) v_u_132
		p133.at = "target"
		p133.range = v_u_131
		p133.radius = v_u_132
	end)(p130)
	p130.freeze = v_u_129
end
v125.e = v126
v125.r = {
	["base"] = "jogan_laser",
	["name"] = "Polar Night"
}
local v134 = {
	["eye"] = "yumegan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Dream Node"
	}
}
local v135 = {
	["base"] = "command_kneel",
	["name"] = "Dream Bind",
	["tune"] = nil
}
local v_u_136 = 55
local v_u_137 = 18
local v_u_138 = 3
function v135.tune(p139)
	-- upvalues: (copy) v_u_136, (copy) v_u_137, (copy) v_u_138
	local v_u_140 = v_u_136
	local v_u_141 = v_u_137;
	(function(p142)
		-- upvalues: (copy) v_u_140, (copy) v_u_141
		p142.at = "target"
		p142.range = v_u_140
		p142.radius = v_u_141
	end)(p139)
	p139.freeze = v_u_138
end
v134.e = v135
v134.r = {
	["base"] = "clairvoyant_judgement",
	["name"] = "Star Dream"
}
__set_list(v101, 1, {{
	["eye"] = "tide_tomoe",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Tide Bubble"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Riptide"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Tidal Crash"
	}
}, v102, {
	["eye"] = "glacier_star",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Snowflake Star"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Crystal Fan"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Absolute Zero"
	}
}, {
	["eye"] = "frozen_rinne",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Ice Lance"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Blizzard Eye"
	},
	["r"] = {
		["base"] = "hollow_purple",
		["name"] = "Glacial Beam"
	}
}, {
	["eye"] = "abyss_spindle",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Deep Needle"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Pressure Crush"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Drowning Depths"
	}
}, v111, v120, v125, {
	["eye"] = "blizzard_wheel",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Snow Comma"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Whiteout"
	},
	["r"] = {
		["base"] = "kamui",
		["name"] = "Blizzard Engine"
	}
}, {
	["eye"] = "dark_maelstrom",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Undertow"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Shutter Blades"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Maelstrom"
	}
}, {
	["eye"] = "ember_trinity",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "amaterasu_spark",
		["name"] = "Ember Comma"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Trinity Pinwheel"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Sunken Sun"
	}
}, {
	["eye"] = "glacier_sharingan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Glacier Tomoe"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Frost Pinwheel"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Absolute Zero"
	}
}, {
	["eye"] = "kurobyougan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Black Star"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Eclipse Blades"
	},
	["r"] = {
		["base"] = "kamui",
		["name"] = "Silent Eclipse"
	}
}, v134})
for v143, v144 in v101 do
	local v145 = v143 * 0.02 + 1.7
	local v146 = v144.a
	local v147 = v144.eye .. "_a"
	local v148 = table.clone(v2[v146.base])
	v148.id = v147
	v148.name = v146.name
	v148.style = v147
	v148.power = v148.power * v145
	if v148.finalPower then
		v148.finalPower = v148.finalPower * v145
	end
	local v149 = v146.tune
	if v149 then
		v149(v148)
	end
	table.insert(v1, v148)
	local v150 = v144.e
	local v151 = v144.eye .. "_e"
	local v152 = table.clone(v2[v150.base])
	v152.id = v151
	v152.name = v150.name
	v152.style = v151
	v152.power = v152.power * v145
	if v152.finalPower then
		v152.finalPower = v152.finalPower * v145
	end
	local v153 = v150.tune
	if v153 then
		v153(v152)
	end
	table.insert(v1, v152)
	local v154 = v144.r
	local v155 = v144.eye .. "_r"
	local v156 = table.clone(v2[v154.base])
	v156.id = v155
	v156.name = v154.name
	v156.style = v155
	v156.power = v156.power * v145
	if v156.finalPower then
		v156.finalPower = v156.finalPower * v145
	end
	local v157 = v154.tune
	if v157 then
		v157(v156)
	end
	table.insert(v1, v156)
end
local v158 = {}
local v159 = {
	["eye"] = "astral_bloom",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Petal Comet"
	}
}
local v160 = {
	["base"] = "command_kneel",
	["name"] = "Constellation Bloom",
	["tune"] = nil
}
local v_u_161 = 55
local v_u_162 = 16
local v_u_163 = 2.5
function v160.tune(p164)
	-- upvalues: (copy) v_u_161, (copy) v_u_162, (copy) v_u_163
	local v_u_165 = v_u_161
	local v_u_166 = v_u_162;
	(function(p167)
		-- upvalues: (copy) v_u_165, (copy) v_u_166
		p167.at = "target"
		p167.range = v_u_165
		p167.radius = v_u_166
	end)(p164)
	p164.freeze = v_u_163
end
v159.e = v160
v159.r = {
	["base"] = "prophecy",
	["name"] = "Pentagram Nova"
}
local v168 = {
	["eye"] = "mangekyou_byakugan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Vacuum Palm"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Sixty-Four Stars"
	}
}
local v169 = {
	["base"] = "heavens_gaze",
	["name"] = "Heavenly Star Rotation",
	["tune"] = nil
}
local v_u_170 = 30
local v_u_171 = 30
function v169.tune(p172)
	-- upvalues: (copy) v_u_170, (copy) v_u_171
	p172.at = "self"
	p172.range = 0
	p172.radius = v_u_170
	p172.push = v_u_171
end
v168.r = v169
local v173 = {
	["eye"] = "astral_sigil",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Sigil Shard"
	}
}
local v174 = {
	["base"] = "command_kneel",
	["name"] = "Star Map",
	["tune"] = nil
}
local v_u_175 = 55
local v_u_176 = 18
local v_u_177 = 2.5
function v174.tune(p178)
	-- upvalues: (copy) v_u_175, (copy) v_u_176, (copy) v_u_177
	local v_u_179 = v_u_175
	local v_u_180 = v_u_176;
	(function(p181)
		-- upvalues: (copy) v_u_179, (copy) v_u_180
		p181.at = "target"
		p181.range = v_u_179
		p181.radius = v_u_180
	end)(p178)
	p178.freeze = v_u_177
end
v173.e = v174
v173.r = {
	["base"] = "karma_cube",
	["name"] = "Astral Lattice"
}
local v182 = {
	["eye"] = "nova_trinity",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "amaterasu_spark",
		["name"] = "Nova Blade"
	}
}
local v183 = {
	["base"] = "command_kneel",
	["name"] = "Plasma Vortex",
	["tune"] = nil
}
local v_u_184 = 55
local v_u_185 = 18
local v_u_186 = 3
function v183.tune(p187)
	-- upvalues: (copy) v_u_184, (copy) v_u_185, (copy) v_u_186
	local v_u_188 = v_u_184
	local v_u_189 = v_u_185;
	(function(p190)
		-- upvalues: (copy) v_u_188, (copy) v_u_189
		p190.at = "target"
		p190.range = v_u_188
		p190.radius = v_u_189
	end)(p187)
	p187.freeze = v_u_186
end
v182.e = v183
v182.r = {
	["base"] = "planetary_devastation",
	["name"] = "Supernova"
}
local v191 = {
	["eye"] = "dark_star",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Void Shard"
	}
}
local v192 = {
	["base"] = "command_kneel",
	["name"] = "Dark Matter",
	["tune"] = nil
}
local v_u_193 = 55
local v_u_194 = 18
local v_u_195 = 3
function v192.tune(p196)
	-- upvalues: (copy) v_u_193, (copy) v_u_194, (copy) v_u_195
	local v_u_197 = v_u_193
	local v_u_198 = v_u_194;
	(function(p199)
		-- upvalues: (copy) v_u_197, (copy) v_u_198
		p199.at = "target"
		p199.range = v_u_197
		p199.radius = v_u_198
	end)(p196)
	p196.freeze = v_u_195
end
v191.e = v192
v191.r = {
	["base"] = "chibaku_tensei",
	["name"] = "Singularity"
}
local v200 = {
	["eye"] = "nebula_rinne",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Nebula Tomoe"
	}
}
local v201 = {
	["base"] = "command_kneel",
	["name"] = "Orbital Rings",
	["tune"] = nil
}
local v_u_202 = 55
local v_u_203 = 18
local v_u_204 = 3
function v201.tune(p205)
	-- upvalues: (copy) v_u_202, (copy) v_u_203, (copy) v_u_204
	local v_u_206 = v_u_202
	local v_u_207 = v_u_203;
	(function(p208)
		-- upvalues: (copy) v_u_206, (copy) v_u_207
		p208.at = "target"
		p208.range = v_u_206
		p208.radius = v_u_207
	end)(p205)
	p205.freeze = v_u_204
end
v200.e = v201
v200.r = {
	["base"] = "blood_moon",
	["name"] = "Big Bang"
}
__set_list(v158, 1, {v159, {
	["eye"] = "crimson_vortex",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Spiral Drill"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Spiral Arms"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Crimson Galaxy"
	}
}, {
	["eye"] = "corona_gear",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Flare Loop"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Solar Wind"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Dyson Ring"
	}
}, v168, {
	["eye"] = "crimson_comet",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Comet Shuriken"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Orbit Blades"
	},
	["r"] = {
		["base"] = "hollow_purple",
		["name"] = "Red Comet Crash"
	}
}, {
	["eye"] = "pulsar_tomoe",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Pulse Tomoe"
	},
	["e"] = {
		["base"] = "amaterasu",
		["name"] = "Pulsar Beacon"
	},
	["r"] = {
		["base"] = "chibaku_tensei",
		["name"] = "Ripple Collapse"
	}
}, {
	["eye"] = "mangekyou_jigokugan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Hell Star"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Purgatory Cross"
	},
	["r"] = {
		["base"] = "kamui",
		["name"] = "Jigoku Descent"
	}
}, v173, {
	["eye"] = "red_giant",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "fireball",
		["name"] = "Red Dwarf"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Tomoe Bloom"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Red Giant"
	}
}, {
	["eye"] = "void_gaze",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Cross Flash"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Lens Flare"
	},
	["r"] = {
		["base"] = "jogan_laser",
		["name"] = "Orbital Strike"
	}
}, v182, v191, v200, {
	["eye"] = "chikaragan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Ring Pulse"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Gravity Ripple"
	},
	["r"] = {
		["base"] = "kamui",
		["name"] = "Wormhole Torrent"
	}
}})
for v209, v210 in v158 do
	local v211 = v209 * 0.02 + 2
	local v212 = v210.a
	local v213 = v210.eye .. "_a"
	local v214 = table.clone(v2[v212.base])
	v214.id = v213
	v214.name = v212.name
	v214.style = v213
	v214.power = v214.power * v211
	if v214.finalPower then
		v214.finalPower = v214.finalPower * v211
	end
	local v215 = v212.tune
	if v215 then
		v215(v214)
	end
	table.insert(v1, v214)
	local v216 = v210.e
	local v217 = v210.eye .. "_e"
	local v218 = table.clone(v2[v216.base])
	v218.id = v217
	v218.name = v216.name
	v218.style = v217
	v218.power = v218.power * v211
	if v218.finalPower then
		v218.finalPower = v218.finalPower * v211
	end
	local v219 = v216.tune
	if v219 then
		v219(v218)
	end
	table.insert(v1, v218)
	local v220 = v210.r
	local v221 = v210.eye .. "_r"
	local v222 = table.clone(v2[v220.base])
	v222.id = v221
	v222.name = v220.name
	v222.style = v221
	v222.power = v222.power * v211
	if v222.finalPower then
		v222.finalPower = v222.finalPower * v211
	end
	local v223 = v220.tune
	if v223 then
		v223(v222)
	end
	table.insert(v1, v222)
end
local v224 = {}
local v225 = {
	["eye"] = "hell_butterfly",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Butterfly Dart"
	}
}
local v226 = {
	["base"] = "command_kneel",
	["name"] = "Swarm Seal",
	["tune"] = nil
}
local v_u_227 = 55
local v_u_228 = 16
local v_u_229 = 2.5
function v226.tune(p230)
	-- upvalues: (copy) v_u_227, (copy) v_u_228, (copy) v_u_229
	local v_u_231 = v_u_227
	local v_u_232 = v_u_228;
	(function(p233)
		-- upvalues: (copy) v_u_231, (copy) v_u_232
		p233.at = "target"
		p233.range = v_u_231
		p233.radius = v_u_232
	end)(p230)
	p230.freeze = v_u_229
end
v225.e = v226
v225.r = {
	["base"] = "chibaku_tensei",
	["name"] = "Gate of Hell"
}
local v234 = {
	["eye"] = "kido_seal",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sealing_light",
		["name"] = "Byakurai"
	}
}
local v235 = {
	["base"] = "command_kneel",
	["name"] = "Six Rods Prison",
	["tune"] = nil
}
local v_u_236 = 55
local v_u_237 = 16
local v_u_238 = 3
function v235.tune(p239)
	-- upvalues: (copy) v_u_236, (copy) v_u_237, (copy) v_u_238
	local v_u_240 = v_u_236
	local v_u_241 = v_u_237;
	(function(p242)
		-- upvalues: (copy) v_u_240, (copy) v_u_241
		p242.at = "target"
		p242.range = v_u_240
		p242.radius = v_u_241
	end)(p239)
	p239.freeze = v_u_238
end
v234.e = v235
v234.r = {
	["base"] = "blood_moon",
	["name"] = "Seal Burst"
}
local v243 = {
	["eye"] = "shirayuki",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Frost Petal"
	}
}
local v244 = {
	["base"] = "command_kneel",
	["name"] = "First Dance",
	["tune"] = nil
}
local v_u_245 = 55
local v_u_246 = 16
local v_u_247 = 3
function v244.tune(p248)
	-- upvalues: (copy) v_u_245, (copy) v_u_246, (copy) v_u_247
	local v_u_249 = v_u_245
	local v_u_250 = v_u_246;
	(function(p251)
		-- upvalues: (copy) v_u_249, (copy) v_u_250
		p251.at = "target"
		p251.range = v_u_249
		p251.radius = v_u_250
	end)(p248)
	p248.freeze = v_u_247
end
v243.e = v244
local v252 = {
	["base"] = "heavens_gaze",
	["name"] = "Second Dance",
	["tune"] = nil
}
local v_u_253 = 30
local v_u_254 = 30
function v252.tune(p255)
	-- upvalues: (copy) v_u_253, (copy) v_u_254
	p255.at = "self"
	p255.range = 0
	p255.radius = v_u_253
	p255.push = v_u_254
end
v243.r = v252
local v257 = {
	["eye"] = "quincy_cross",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Heilig Pfeil"
	},
	["e"] = {
		["base"] = "arrow_storm",
		["name"] = "Arrow Rain"
	},
	["r"] = {
		["base"] = "prophecy",
		["name"] = "Vollstandig",
		["tune"] = nil,
		["tune"] = function(p256) -- name: tune
			p256.count = 16
			p256.power = p256.power * 0.45
			p256.strikeRadius = 6
		end
	}
}
local v258 = {
	["eye"] = "kyoka_suigetsu",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Mirror Shard"
	}
}
local v259 = {
	["base"] = "command_kneel",
	["name"] = "Complete Hypnosis",
	["tune"] = nil
}
local v_u_260 = 55
local v_u_261 = 18
local v_u_262 = 3
function v259.tune(p263)
	-- upvalues: (copy) v_u_260, (copy) v_u_261, (copy) v_u_262
	local v_u_264 = v_u_260
	local v_u_265 = v_u_261;
	(function(p266)
		-- upvalues: (copy) v_u_264, (copy) v_u_265
		p266.at = "target"
		p266.range = v_u_264
		p266.radius = v_u_265
	end)(p263)
	p263.freeze = v_u_262
end
v258.e = v259
v258.r = {
	["base"] = "prophecy",
	["name"] = "Shattered Moon"
}
local v267 = {
	["eye"] = "hyorinmaru",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Dragon Fang"
	}
}
local v268 = {
	["base"] = "command_kneel",
	["name"] = "Ice Flowers",
	["tune"] = nil
}
local v_u_269 = 55
local v_u_270 = 18
local v_u_271 = 3
function v268.tune(p272)
	-- upvalues: (copy) v_u_269, (copy) v_u_270, (copy) v_u_271
	local v_u_273 = v_u_269
	local v_u_274 = v_u_270;
	(function(p275)
		-- upvalues: (copy) v_u_273, (copy) v_u_274
		p275.at = "target"
		p275.range = v_u_273
		p275.radius = v_u_274
	end)(p272)
	p272.freeze = v_u_271
end
v267.e = v268
v267.r = {
	["base"] = "heavens_gaze",
	["name"] = "Daiguren"
}
local v280 = {
	["eye"] = "hakka_no_togame",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Shirafune"
	},
	["e"] = {
		["base"] = "command_kneel",
		["name"] = "Hakka no Togame",
		["tune"] = nil,
		["tune"] = function(p276) -- name: tune
			local v_u_277 = 24
			local v_u_278 = nil
			(function(p279)
				-- upvalues: (copy) v_u_277, (copy) v_u_278
				p279.at = "self"
				p279.range = 0
				p279.radius = v_u_277
				p279.push = v_u_278
			end)(p276)
			p276.freeze = 3
		end
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "White Moon Bloom"
	}
}
__set_list(v224, 1, {{
	["eye"] = "raging_current",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Tide Fang"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Whirlpool Bind"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Tsunami"
	}
}, v225, {
	["eye"] = "raiko_gaze",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Raiko Bolt"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Thunder Step"
	},
	["r"] = {
		["base"] = "heavens_gaze",
		["name"] = "Thunder God\'s Hammer"
	}
}, v234, {
	["eye"] = "shinso_edge",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "jogan_pulse",
		["name"] = "Shinso Stab"
	},
	["e"] = {
		["base"] = "phoenix_flowers",
		["name"] = "Butou Renjin"
	},
	["r"] = {
		["base"] = "hollow_purple",
		["name"] = "Kamishini no Yari"
	}
}, v243, v257, {
	["eye"] = "sanrei_lattice",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Seele Schneider"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Sprenger"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Letzt Stil"
	}
}, v258, {
	["eye"] = "black_coffin",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Black Spear"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Nine Light Bind"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Kurohitsugi"
	}
}, {
	["eye"] = "senbonzakura",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Petal Blade"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Gokei"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Senkei"
	}
}, v267, {
	["eye"] = "ryujin_jakka",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "fireball",
		["name"] = "Flame Slash"
	},
	["e"] = {
		["base"] = "blaze_release",
		["name"] = "Flame Prison"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Zanka no Tachi"
	}
}, {
	["eye"] = "getsuga_tensho",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Getsuga"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Bankai Flash"
	},
	["r"] = {
		["base"] = "hollow_purple",
		["name"] = "Mugetsu"
	}
}, v280})
for v281, v282 in v224 do
	local v283 = 2.3 + v281 * 0.02
	local v284 = v282.a
	local v285 = v282.eye .. "_a"
	local v286 = table.clone(v2[v284.base])
	v286.id = v285
	v286.name = v284.name
	v286.style = v285
	v286.power = v286.power * v283
	if v286.finalPower then
		v286.finalPower = v286.finalPower * v283
	end
	local v287 = v284.tune
	if v287 then
		v287(v286)
	end
	table.insert(v1, v286)
	local v288 = v282.e
	local v289 = v282.eye .. "_e"
	local v290 = table.clone(v2[v288.base])
	v290.id = v289
	v290.name = v288.name
	v290.style = v289
	v290.power = v290.power * v283
	if v290.finalPower then
		v290.finalPower = v290.finalPower * v283
	end
	local v291 = v288.tune
	if v291 then
		v291(v290)
	end
	table.insert(v1, v290)
	local v292 = v282.r
	local v293 = v282.eye .. "_r"
	local v294 = table.clone(v2[v292.base])
	v294.id = v293
	v294.name = v292.name
	v294.style = v293
	v294.power = v294.power * v283
	if v294.finalPower then
		v294.finalPower = v294.finalPower * v283
	end
	local v295 = v292.tune
	if v295 then
		v295(v294)
	end
	table.insert(v1, v294)
end
local v296 = {}
local v297 = {
	["eye"] = "cero_inferno",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Red Cero"
	}
}
local v298 = {
	["base"] = "phoenix_flowers",
	["name"] = "Cero Barrage",
	["tune"] = nil
}
local v_u_299 = 5
local v_u_300 = 60
function v298.tune(p301)
	-- upvalues: (copy) v_u_299, (copy) v_u_300
	p301.count = v_u_299
	p301.spreadAngle = v_u_300
end
v297.e = v298
v297.r = {
	["base"] = "heavens_gaze",
	["name"] = "Inferno Burst"
}
local v302 = {
	["eye"] = "tatarforas",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Fear Thorn"
	}
}
local v303 = {
	["base"] = "command_kneel",
	["name"] = "Tatarforas Gaze",
	["tune"] = nil
}
local v_u_304 = 55
local v_u_305 = 16
local v_u_306 = 3
function v303.tune(p307)
	-- upvalues: (copy) v_u_304, (copy) v_u_305, (copy) v_u_306
	local v_u_308 = v_u_304
	local v_u_309 = v_u_305;
	(function(p310)
		-- upvalues: (copy) v_u_308, (copy) v_u_309
		p310.at = "target"
		p310.range = v_u_308
		p310.radius = v_u_309
	end)(p307)
	p307.freeze = v_u_306
end
v302.e = v303
v302.r = {
	["base"] = "planetary_devastation",
	["name"] = "Cage of Fear"
}
local v311 = {
	["eye"] = "los_lobos",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Twin Shot"
	}
}
local v312 = {
	["base"] = "phoenix_flowers",
	["name"] = "Los Lobos",
	["tune"] = nil
}
local v_u_313 = 6
local v_u_314 = 80
function v312.tune(p315)
	-- upvalues: (copy) v_u_313, (copy) v_u_314
	p315.count = v_u_313
	p315.spreadAngle = v_u_314
end
v311.e = v312
local v316 = {
	["base"] = "prophecy",
	["name"] = "Cero Metralleta",
	["tune"] = nil
}
local v_u_317 = 18
local v_u_318 = 0.35
local v_u_319 = 5
local v_u_320 = 22
function v316.tune(p321)
	-- upvalues: (copy) v_u_317, (copy) v_u_318, (copy) v_u_319, (copy) v_u_320
	p321.count = v_u_317
	p321.power = p321.power * v_u_318
	p321.strikeRadius = v_u_319
	p321.radius = v_u_320
end
v311.r = v316
local v322 = {
	["eye"] = "pantera",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sealing_light",
		["name"] = "Panther Claw"
	}
}
local v323 = {
	["base"] = "phoenix_flowers",
	["name"] = "Garra de la Pantera",
	["tune"] = nil
}
local v_u_324 = 7
local v_u_325 = 40
function v323.tune(p326)
	-- upvalues: (copy) v_u_324, (copy) v_u_325
	p326.count = v_u_324
	p326.spreadAngle = v_u_325
end
v322.e = v323
local v327 = {
	["base"] = "prophecy",
	["name"] = "Desgarron",
	["tune"] = nil
}
local v_u_328 = 5
local v_u_329 = 1.15
local v_u_330 = 10
local v_u_331 = 14
function v327.tune(p332)
	-- upvalues: (copy) v_u_328, (copy) v_u_329, (copy) v_u_330, (copy) v_u_331
	p332.count = v_u_328
	p332.power = p332.power * v_u_329
	p332.strikeRadius = v_u_330
	p332.radius = v_u_331
end
v322.r = v327
local v337 = {
	["eye"] = "compulsory",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Nerve Thread"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Compulsion"
	},
	["r"] = {
		["base"] = "infinite_tsukuyomi",
		["name"] = "Nerve Web",
		["tune"] = nil,
		["tune"] = function(p333) -- name: tune
			local v_u_334 = 55
			local v_u_335 = 24
			(function(p336)
				-- upvalues: (copy) v_u_334, (copy) v_u_335
				p336.at = "target"
				p336.range = v_u_334
				p336.radius = v_u_335
			end)(p333)
			p333.freeze = 3
		end
	}
}
local v338 = {
	["eye"] = "inner_hollow",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Inverted Slash"
	}
}
local v339 = {
	["base"] = "phoenix_flowers",
	["name"] = "Mask Roar",
	["tune"] = nil
}
local v_u_340 = 9
local v_u_341 = 70
function v339.tune(p342)
	-- upvalues: (copy) v_u_340, (copy) v_u_341
	p342.count = v_u_340
	p342.spreadAngle = v_u_341
end
v338.e = v339
v338.r = {
	["base"] = "chibaku_tensei",
	["name"] = "Hollow Frenzy"
}
local v343 = {
	["eye"] = "hogyoku",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Hogyoku Pulse"
	}
}
local v344 = {
	["base"] = "command_kneel",
	["name"] = "Chrysalis",
	["tune"] = nil
}
local v_u_345 = 55
local v_u_346 = 18
local v_u_347 = 3
function v344.tune(p348)
	-- upvalues: (copy) v_u_345, (copy) v_u_346, (copy) v_u_347
	local v_u_349 = v_u_345
	local v_u_350 = v_u_346;
	(function(p351)
		-- upvalues: (copy) v_u_349, (copy) v_u_350
		p351.at = "target"
		p351.range = v_u_349
		p351.radius = v_u_350
	end)(p348)
	p348.freeze = v_u_347
end
v343.e = v344
local v352 = {
	["base"] = "karma_cube",
	["name"] = "Transcendence",
	["tune"] = nil
}
local v_u_353 = 32
local v_u_354 = 30
function v352.tune(p355)
	-- upvalues: (copy) v_u_353, (copy) v_u_354
	p355.at = "self"
	p355.range = 0
	p355.radius = v_u_353
	p355.push = v_u_354
end
v343.r = v352
local v356 = {
	["eye"] = "soul_king",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Royal Shard"
	}
}
local v357 = {
	["base"] = "command_kneel",
	["name"] = "Sealed Crystal",
	["tune"] = nil
}
local v_u_358 = 55
local v_u_359 = 18
local v_u_360 = 3.5
function v357.tune(p361)
	-- upvalues: (copy) v_u_358, (copy) v_u_359, (copy) v_u_360
	local v_u_362 = v_u_358
	local v_u_363 = v_u_359;
	(function(p364)
		-- upvalues: (copy) v_u_362, (copy) v_u_363
		p364.at = "target"
		p364.range = v_u_362
		p364.radius = v_u_363
	end)(p361)
	p361.freeze = v_u_360
end
v356.e = v357
v356.r = {
	["base"] = "blood_moon",
	["name"] = "Palace Descent"
}
local v365 = {
	["eye"] = "almighty",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Shadow Blade"
	}
}
local v366 = {
	["base"] = "shinra_tensei",
	["name"] = "Auswahlen",
	["tune"] = nil
}
local v_u_367 = 30
local v_u_368 = nil
function v366.tune(p369)
	-- upvalues: (copy) v_u_367, (copy) v_u_368
	p369.at = "self"
	p369.range = 0
	p369.radius = v_u_367
	p369.push = v_u_368
end
v365.e = v366
local v370 = {
	["base"] = "prophecy",
	["name"] = "The Almighty",
	["tune"] = nil
}
local v_u_371 = 12
local v_u_372 = 0.5
local v_u_373 = 6
local v_u_374 = 26
function v370.tune(p375)
	-- upvalues: (copy) v_u_371, (copy) v_u_372, (copy) v_u_373, (copy) v_u_374
	p375.count = v_u_371
	p375.power = p375.power * v_u_372
	p375.strikeRadius = v_u_373
	p375.radius = v_u_374
end
v365.r = v370
__set_list(v296, 1, {{
	["eye"] = "gamuza",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Lanzador Verde"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Cero Doble"
	},
	["r"] = {
		["base"] = "susanoo_arrow",
		["name"] = "Centaur Charge"
	}
}, {
	["eye"] = "resurreccion",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Bala"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Mask Break"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Release"
	}
}, {
	["eye"] = "gran_rey_cero",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Cero"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Charging Sphere"
	},
	["r"] = {
		["base"] = "jogan_laser",
		["name"] = "Gran Rey Cero"
	}
}, v297, v302, v311, v322, v337, {
	["eye"] = "murcielago",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Luz de la Luna"
	},
	["e"] = {
		["base"] = "reversal_red",
		["name"] = "Cero Oscuras"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Lanza del Relampago"
	}
}, v338, {
	["eye"] = "vasto_lorde",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Horn Cero"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Horn Gore"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Vasto Cero"
	}
}, v343, v356, v365})
for v376, v377 in v296 do
	local v378 = 2.6 + v376 * 0.02
	local v379 = v377.a
	local v380 = v377.eye .. "_a"
	local v381 = table.clone(v2[v379.base])
	v381.id = v380
	v381.name = v379.name
	v381.style = v380
	v381.power = v381.power * v378
	if v381.finalPower then
		v381.finalPower = v381.finalPower * v378
	end
	local v382 = v379.tune
	if v382 then
		v382(v381)
	end
	table.insert(v1, v381)
	local v383 = v377.e
	local v384 = v377.eye .. "_e"
	local v385 = table.clone(v2[v383.base])
	v385.id = v384
	v385.name = v383.name
	v385.style = v384
	v385.power = v385.power * v378
	if v385.finalPower then
		v385.finalPower = v385.finalPower * v378
	end
	local v386 = v383.tune
	if v386 then
		v386(v385)
	end
	table.insert(v1, v385)
	local v387 = v377.r
	local v388 = v377.eye .. "_r"
	local v389 = table.clone(v2[v387.base])
	v389.id = v388
	v389.name = v387.name
	v389.style = v388
	v389.power = v389.power * v378
	if v389.finalPower then
		v389.finalPower = v389.finalPower * v378
	end
	local v390 = v387.tune
	if v390 then
		v390(v389)
	end
	table.insert(v1, v389)
end
local v391 = {}
local v392 = {
	["eye"] = "exploding_blood",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "amaterasu_spark",
		["name"] = "Blood Spark"
	},
	["e"] = {
		["base"] = "limbo_strike",
		["name"] = "Bamboo Kick"
	}
}
local v393 = {
	["base"] = "prophecy",
	["name"] = "Exploding Blood",
	["tune"] = nil
}
local v_u_394 = 10
local v_u_395 = 0.6
local v_u_396 = 7
local v_u_397 = 24
function v393.tune(p398)
	-- upvalues: (copy) v_u_394, (copy) v_u_395, (copy) v_u_396, (copy) v_u_397
	p398.count = v_u_394
	p398.power = p398.power * v_u_395
	p398.strikeRadius = v_u_396
	p398.radius = v_u_397
end
v392.r = v393
local v403 = {
	["eye"] = "lower_moon",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Dream Bolt"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Dream Train"
	},
	["r"] = {
		["base"] = "infinite_tsukuyomi",
		["name"] = "Eternal Sleep",
		["tune"] = nil,
		["tune"] = function(p399) -- name: tune
			local v_u_400 = 55
			local v_u_401 = 24
			(function(p402)
				-- upvalues: (copy) v_u_400, (copy) v_u_401
				p402.at = "target"
				p402.range = v_u_400
				p402.radius = v_u_401
			end)(p399)
			p399.freeze = 3
		end
	}
}
local v404 = {
	["eye"] = "blood_sickle",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Flying Sickle"
	}
}
local v405 = {
	["base"] = "command_kneel",
	["name"] = "Obi Sash",
	["tune"] = nil
}
local v_u_406 = 55
local v_u_407 = 16
local v_u_408 = 3
function v405.tune(p409)
	-- upvalues: (copy) v_u_406, (copy) v_u_407, (copy) v_u_408
	local v_u_410 = v_u_406
	local v_u_411 = v_u_407;
	(function(p412)
		-- upvalues: (copy) v_u_410, (copy) v_u_411
		p412.at = "target"
		p412.range = v_u_410
		p412.radius = v_u_411
	end)(p409)
	p409.freeze = v_u_408
end
v404.e = v405
local v413 = {
	["base"] = "heavens_gaze",
	["name"] = "Rampaging Blood",
	["tune"] = nil
}
local v_u_414 = 30
local v_u_415 = 30
function v413.tune(p416)
	-- upvalues: (copy) v_u_414, (copy) v_u_415
	p416.at = "self"
	p416.range = 0
	p416.radius = v_u_414
	p416.push = v_u_415
end
v404.r = v413
local v417 = {
	["eye"] = "thousand_needles",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blood_needles",
		["name"] = "Needle Fish"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Vase Swap"
	}
}
local v418 = {
	["base"] = "prophecy",
	["name"] = "Thousand Needle Kill",
	["tune"] = nil
}
local v_u_419 = 18
local v_u_420 = 0.35
local v_u_421 = 5
local v_u_422 = 22
function v418.tune(p423)
	-- upvalues: (copy) v_u_419, (copy) v_u_420, (copy) v_u_421, (copy) v_u_422
	p423.count = v_u_419
	p423.power = p423.power * v_u_420
	p423.strikeRadius = v_u_421
	p423.radius = v_u_422
end
v417.r = v418
local v424 = {
	["eye"] = "zohakuten",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "chakra_rod",
		["name"] = "Wood Dragon"
	}
}
local v425 = {
	["base"] = "shinra_tensei",
	["name"] = "Taiko Drums",
	["tune"] = nil
}
local v_u_426 = 28
local v_u_427 = nil
function v425.tune(p428)
	-- upvalues: (copy) v_u_426, (copy) v_u_427
	p428.at = "self"
	p428.range = 0
	p428.radius = v_u_426
	p428.push = v_u_427
end
v424.e = v425
local v429 = {
	["base"] = "prophecy",
	["name"] = "Hatred Dragons",
	["tune"] = nil
}
local v_u_430 = 5
local v_u_431 = 1.15
local v_u_432 = 10
local v_u_433 = 14
function v429.tune(p434)
	-- upvalues: (copy) v_u_430, (copy) v_u_431, (copy) v_u_432, (copy) v_u_433
	p434.count = v_u_430
	p434.power = p434.power * v_u_431
	p434.strikeRadius = v_u_432
	p434.radius = v_u_433
end
v424.r = v429
local v435 = {
	["eye"] = "dead_calm",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sealing_light",
		["name"] = "Water Wheel"
	}
}
local v436 = {
	["base"] = "command_kneel",
	["name"] = "Whirlpool",
	["tune"] = nil
}
local v_u_437 = 55
local v_u_438 = 18
local v_u_439 = 3
function v436.tune(p440)
	-- upvalues: (copy) v_u_437, (copy) v_u_438, (copy) v_u_439
	local v_u_441 = v_u_437
	local v_u_442 = v_u_438;
	(function(p443)
		-- upvalues: (copy) v_u_441, (copy) v_u_442
		p443.at = "target"
		p443.range = v_u_441
		p443.radius = v_u_442
	end)(p440)
	p440.freeze = v_u_439
end
v435.e = v436
local v444 = {
	["base"] = "karma_cube",
	["name"] = "Dead Calm",
	["tune"] = nil
}
local v_u_445 = 30
local v_u_446 = 25
function v444.tune(p447)
	-- upvalues: (copy) v_u_445, (copy) v_u_446
	p447.at = "self"
	p447.range = 0
	p447.radius = v_u_445
	p447.push = v_u_446
end
v435.r = v444
local v448 = {
	["eye"] = "destructive_death",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "lapse_blue",
		["name"] = "Air Type"
	}
}
local v449 = {
	["base"] = "shinra_tensei",
	["name"] = "Compass Needle",
	["tune"] = nil
}
local v_u_450 = 30
local v_u_451 = nil
function v449.tune(p452)
	-- upvalues: (copy) v_u_450, (copy) v_u_451
	p452.at = "self"
	p452.range = 0
	p452.radius = v_u_450
	p452.push = v_u_451
end
v448.e = v449
v448.r = {
	["base"] = "divine_judgement",
	["name"] = "Annihilation Type"
}
local v453 = {
	["eye"] = "demon_seal",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "tomoe_orb",
		["name"] = "Seal Bolt"
	}
}
local v454 = {
	["base"] = "command_kneel",
	["name"] = "Clockwork Lock",
	["tune"] = nil
}
local v_u_455 = 55
local v_u_456 = 18
local v_u_457 = 3.5
function v454.tune(p458)
	-- upvalues: (copy) v_u_455, (copy) v_u_456, (copy) v_u_457
	local v_u_459 = v_u_455
	local v_u_460 = v_u_456;
	(function(p461)
		-- upvalues: (copy) v_u_459, (copy) v_u_460
		p461.at = "target"
		p461.range = v_u_459
		p461.radius = v_u_460
	end)(p458)
	p458.freeze = v_u_457
end
v453.e = v454
v453.r = {
	["base"] = "clairvoyant_judgement",
	["name"] = "Seal Judgement"
}
local v462 = {
	["eye"] = "moon_breathing",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Crescent Cut"
	}
}
local v463 = {
	["base"] = "limbo_strike",
	["name"] = "Moon Dragon Ring",
	["tune"] = nil
}
local v_u_464 = 26
local v_u_465 = nil
function v463.tune(p466)
	-- upvalues: (copy) v_u_464, (copy) v_u_465
	p466.at = "self"
	p466.range = 0
	p466.radius = v_u_464
	p466.push = v_u_465
end
v462.e = v463
local v467 = {
	["base"] = "prophecy",
	["name"] = "Moonbow Half Moon",
	["tune"] = nil
}
local v_u_468 = 8
local v_u_469 = 0.8
local v_u_470 = 8
local v_u_471 = 24
function v467.tune(p472)
	-- upvalues: (copy) v_u_468, (copy) v_u_469, (copy) v_u_470, (copy) v_u_471
	p472.count = v_u_468
	p472.power = p472.power * v_u_469
	p472.strikeRadius = v_u_470
	p472.radius = v_u_471
end
v462.r = v467
local v473 = {
	["eye"] = "sun_breathing",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "fireball",
		["name"] = "Sun Halo"
	}
}
local v474 = {
	["base"] = "phoenix_flowers",
	["name"] = "Sunflower Thrust",
	["tune"] = nil
}
local v_u_475 = 9
local v_u_476 = 50
function v474.tune(p477)
	-- upvalues: (copy) v_u_475, (copy) v_u_476
	p477.count = v_u_475
	p477.spreadAngle = v_u_476
end
v473.e = v474
v473.r = {
	["base"] = "blood_moon",
	["name"] = "Sun Halo Dragon"
}
local v478 = {
	["eye"] = "demon_king",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "god_ray",
		["name"] = "Blood Whip"
	},
	["e"] = {
		["base"] = "planetary_devastation",
		["name"] = "Black Blood"
	}
}
local v479 = {
	["base"] = "blood_moon",
	["name"] = "Demon King",
	["tune"] = nil
}
local v_u_480 = 32
local v_u_481 = 30
function v479.tune(p482)
	-- upvalues: (copy) v_u_480, (copy) v_u_481
	p482.at = "self"
	p482.range = 0
	p482.radius = v_u_480
	p482.push = v_u_481
end
v478.r = v479
__set_list(v391, 1, {v392, v403, v404, {
	["eye"] = "black_thunder",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "light_arrow",
		["name"] = "Black Bolt"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Thunder Crawl"
	},
	["r"] = {
		["base"] = "jogan_laser",
		["name"] = "Jealousy Fang"
	}
}, v417, v424, v435, {
	["eye"] = "biwa_castle",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "jogan_pulse",
		["name"] = "Biwa Strum"
	},
	["e"] = {
		["base"] = "dimension_rift",
		["name"] = "Room Shift"
	},
	["r"] = {
		["base"] = "karma_cube",
		["name"] = "Infinity Fold"
	}
}, v448, {
	["eye"] = "cryo_lotus",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "sukunahikona",
		["name"] = "Ice Fan"
	},
	["e"] = {
		["base"] = "sealing_lotus",
		["name"] = "Lotus Vines"
	},
	["r"] = {
		["base"] = "heavens_gaze",
		["name"] = "Ice Bodhisattva"
	}
}, v453, v462, v473, v478})
for v483, v484 in v391 do
	local v485 = 2.9 + v483 * 0.02
	local v486 = v484.a
	local v487 = v484.eye .. "_a"
	local v488 = table.clone(v2[v486.base])
	v488.id = v487
	v488.name = v486.name
	v488.style = v487
	v488.power = v488.power * v485
	if v488.finalPower then
		v488.finalPower = v488.finalPower * v485
	end
	local v489 = v486.tune
	if v489 then
		v489(v488)
	end
	table.insert(v1, v488)
	local v490 = v484.e
	local v491 = v484.eye .. "_e"
	local v492 = table.clone(v2[v490.base])
	v492.id = v491
	v492.name = v490.name
	v492.style = v491
	v492.power = v492.power * v485
	if v492.finalPower then
		v492.finalPower = v492.finalPower * v485
	end
	local v493 = v490.tune
	if v493 then
		v493(v492)
	end
	table.insert(v1, v492)
	local v494 = v484.r
	local v495 = v484.eye .. "_r"
	local v496 = table.clone(v2[v494.base])
	v496.id = v495
	v496.name = v494.name
	v496.style = v495
	v496.power = v496.power * v485
	if v496.finalPower then
		v496.finalPower = v496.finalPower * v485
	end
	local v497 = v494.tune
	if v497 then
		v497(v496)
	end
	table.insert(v1, v496)
end
local v498 = {}
local v499 = {
	["eye"] = "kanjogan",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "truth_orb",
		["name"] = "Sense Orb"
	},
	["e"] = {
		["base"] = "shinra_tensei",
		["name"] = "Sensing Wave"
	}
}
local v500 = {
	["base"] = "heavens_gaze",
	["name"] = "Eight Lights",
	["tune"] = nil
}
local v_u_501 = 30
local v_u_502 = 30
function v500.tune(p503)
	-- upvalues: (copy) v_u_501, (copy) v_u_502
	p503.at = "self"
	p503.range = 0
	p503.radius = v_u_501
	p503.push = v_u_502
end
v499.r = v500
__set_list(v498, 1, {v499, {
	["eye"] = "fuma_mangekyo",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "blaze_arrow",
		["name"] = "Fuma Throw"
	},
	["e"] = {
		["base"] = "crimson_crescent",
		["name"] = "Shuriken Storm"
	},
	["r"] = {
		["base"] = "planetary_devastation",
		["name"] = "Fuma Cataclysm"
	}
}, {
	["eye"] = "kurenai_mangekyo",
	["a"] = nil,
	["e"] = nil,
	["r"] = nil,
	["a"] = {
		["base"] = "amaterasu_spark",
		["name"] = "Crimson Blade"
	},
	["e"] = {
		["base"] = "amaterasu",
		["name"] = "Kurenai Flames"
	},
	["r"] = {
		["base"] = "blood_moon",
		["name"] = "Scarlet Moon"
	}
}})
for v504, v505 in v498 do
	local v506 = 2.3 + v504 * 0.02
	local v507 = v505.a
	local v508 = v505.eye .. "_a"
	local v509 = table.clone(v2[v507.base])
	v509.id = v508
	v509.name = v507.name
	v509.style = v508
	v509.power = v509.power * v506
	if v509.finalPower then
		v509.finalPower = v509.finalPower * v506
	end
	local v510 = v507.tune
	if v510 then
		v510(v509)
	end
	table.insert(v1, v509)
	local v511 = v505.e
	local v512 = v505.eye .. "_e"
	local v513 = table.clone(v2[v511.base])
	v513.id = v512
	v513.name = v511.name
	v513.style = v512
	v513.power = v513.power * v506
	if v513.finalPower then
		v513.finalPower = v513.finalPower * v506
	end
	local v514 = v511.tune
	if v514 then
		v514(v513)
	end
	table.insert(v1, v513)
	local v515 = v505.r
	local v516 = v505.eye .. "_r"
	local v517 = table.clone(v2[v515.base])
	v517.id = v516
	v517.name = v515.name
	v517.style = v516
	v517.power = v517.power * v506
	if v517.finalPower then
		v517.finalPower = v517.finalPower * v506
	end
	local v518 = v515.tune
	if v518 then
		v518(v517)
	end
	table.insert(v1, v517)
end
for _, v519 in v1 do
	if v519.cooldown < 1 then
		continue
	end
	v519.cooldown = 3
end
local v520 = {
	["SKILL_COOLDOWN"] = 3,
	["list"] = v1,
	["byId"] = {}
}
for _, v521 in v1 do
	v520.byId[v521.id] = v521
end
return v520