local v_u_1 = require(script.Parent.Parent.Config.Stages)
local v_u_2 = require(script.Parent.Parent.Config.Pets)
local v_u_3 = require(script.Parent.Format)
local v_u_63 = {
	["trophies"] = function(p4, p5) -- name: trophies
		return {
			["kind"] = "trophies",
			["scale"] = nil,
			["min"] = nil,
			["scale"] = p4,
			["min"] = p5
		}
	end,
	["egg"] = function(p6, p7) -- name: egg
		return {
			["kind"] = "egg",
			["egg"] = nil,
			["count"] = nil,
			["egg"] = p6,
			["count"] = p7
		}
	end,
	["worldEgg"] = function(p8, p9) -- name: worldEgg
		-- upvalues: (copy) v_u_2
		return {
			["kind"] = "egg",
			["egg"] = nil,
			["tier"] = nil,
			["count"] = nil,
			["egg"] = v_u_2.STANDS[1][p8],
			["tier"] = p8,
			["count"] = p9
		}
	end,
	["eggFor"] = function(p10, p11) -- name: eggFor
		-- upvalues: (copy) v_u_2
		return p10.tier and (v_u_2.STANDS[p11 or 1] or v_u_2.STANDS[1])[p10.tier] or (p10.egg or "normal")
	end,
	["boost"] = function(p12, p13) -- name: boost
		return {
			["kind"] = "boost",
			["boost"] = nil,
			["minutes"] = nil,
			["boost"] = p12,
			["minutes"] = p13
		}
	end,
	["aura"] = function(p14) -- name: aura
		return {
			["kind"] = "aura",
			["aura"] = nil,
			["aura"] = p14
		}
	end,
	["pet"] = function(p15) -- name: pet
		return {
			["kind"] = "pet",
			["pet"] = nil,
			["pet"] = p15
		}
	end,
	["kuramaCoins"] = function(p16) -- name: kuramaCoins
		return {
			["kind"] = "kuramaCoins",
			["count"] = nil,
			["count"] = p16
		}
	end,
	["worldPet"] = function(p17, p18, p19) -- name: worldPet
		-- upvalues: (copy) v_u_2
		return {
			["kind"] = "pet",
			["egg"] = nil,
			["tier"] = nil,
			["rarity"] = nil,
			["count"] = nil,
			["egg"] = v_u_2.STANDS[1][p17],
			["tier"] = p17,
			["rarity"] = p18,
			["count"] = p19
		}
	end,
	["eggPet"] = function(p20, p21) -- name: eggPet
		return {
			["kind"] = "pet",
			["egg"] = nil,
			["tier"] = nil,
			["rarity"] = nil,
			["count"] = nil,
			["egg"] = p20.egg,
			["tier"] = p20.tier,
			["rarity"] = p21,
			["count"] = p20.count or 1
		}
	end,
	["petFor"] = function(p22, p23) -- name: petFor
		-- upvalues: (copy) v_u_2, (copy) v_u_63
		if p22.pet then
			return p22.pet
		end
		local v24 = v_u_2.eggById[v_u_63.eggFor(p22, p23)]
		if not (v24 and p22.rarity) then
			return nil
		end
		for _, v25 in v24.pool do
			local v26 = v_u_2.byId[v25.pet]
			if not v26 or v26.rarity ~= p22.rarity then
				continue
			end
			return v26.id
		end
		return nil
	end,
	["withoutEggs"] = function(p27, p28, p29) -- name: withoutEggs
		local v30 = false
		local v31 = {}
		for _, v32 in p27 do
			if v32.kind == "egg" then
				if p29 and v30 then
					continue
				end
				local v33 = p28(v32)
				if not v33 then
					continue
				end
				table.insert(v31, v33)
				v30 = true
			else
				table.insert(v31, v32)
			end
		end
		return v31
	end,
	["BOOST_MULT"] = {
		["chakra"] = 2,
		["chakra5"] = 5,
		["chakra10"] = 10,
		["wins"] = 2
	},
	["progress"] = function(p34, ...) -- name: progress
		for v35 = select("#", ...), 1, -1 do
			local v36 = select(v35, ...)
			if not v36 or v36 <= 0 then
				continue
			end
			return v36, v35 + 1
		end
		return p34, 1
	end,
	["amount"] = function(p37, p38, p39) -- name: amount
		-- upvalues: (copy) v_u_1
		if p37.kind ~= "trophies" then
			return p37.count or 1
		end
		local v40 = v_u_1.forWorld(p39)
		local v41 = #v40
		local v42 = v40[math.clamp(p38, 1, v41)]
		local v43 = p37.min or 1
		local v44 = (p37.scale or 1) * v42.wins
		local v45 = math.floor(v44)
		return math.max(v43, v45)
	end,
	["label"] = function(p46, p47, p48) -- name: label
		-- upvalues: (copy) v_u_3, (copy) v_u_63
		if p46.kind == "trophies" then
			return "+" .. v_u_3.short(v_u_63.amount(p46, p47, p48))
		end
		if p46.kind == "egg" then
			local v49 = p46.count or 1
			return "x" .. tostring(v49)
		end
		if p46.kind ~= "boost" then
			return p46.kind ~= "kuramaCoins" and "" or ("+%* Kyubi Coins"):format((v_u_3.commas(p46.count or 0)))
		end
		local v50 = v_u_63.BOOST_MULT[p46.boost or "chakra"] or 2
		local v51 = p46.minutes or 0
		local v52
		if v51 >= 60 and v51 % 60 == 0 then
			v52 = ("%*h"):format(v51 // 60)
		else
			v52 = ("%*m"):format(v51)
		end
		return ("x%* %* %*"):format(v50, p46.boost == "wins" and "Trophies" or "Chakra", v52)
	end,
	["pick"] = function(p53, p54) -- name: pick
		local v55 = 0
		for _, v56 in p53 do
			v55 = v55 + v56.weight
		end
		local v57 = p54 * v55
		for _, v58 in p53 do
			v57 = v57 - v58.weight
			if v57 >= 0 then
				continue
			end
			return v58
		end
		return p53[#p53]
	end,
	["chance"] = function(p59, p60) -- name: chance
		local v61 = 0
		for _, v62 in p59 do
			v61 = v61 + v62.weight
		end
		return p60.weight / v61 * 100
	end
}
return v_u_63