require(script.Parent.Parent.FormTypes)
local v_u_1 = require(script.Parent.Parent.Kit)
return function(p_u_2)
	-- upvalues: (copy) v_u_1
	local v_u_3 = Enum.Material.SmoothPlastic
	local v_u_4 = Enum.Material.Metal
	local v_u_5 = Enum.Material.Neon
	local v_u_6 = CFrame.Angles(0, 1.5707963267948966, 0)
	return {
		["w3_iron_mandala"] = function(p_u_7, p8) -- name: w3_iron_mandala
			-- upvalues: (copy) p_u_2, (ref) v_u_1, (copy) v_u_6, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
			local v_u_9 = p_u_7.fx <= 1 and 1 or p_u_7.fx / 1.35
			local v10 = Color3.fromHex(p8.color)
			local v11 = Color3.fromHex(p8.color2)
			local v_u_12 = p_u_2.rgb(226, 238, 250)
			local v_u_13 = p_u_2.rgb(255, 176, 64)
			local v14 = p_u_2.rgb(18, 20, 24)
			local v_u_15 = Vector3.new(0, 1, 1) * v_u_9
			local v16 = { Vector3.new(-2.05, 2, 0) * v_u_9, Vector3.new(2.05, 2, 0) * v_u_9 }
			local v_u_17 = 0
			local v_u_18 = 0
			local v_u_19 = 0
			local v_u_20 = -10
			local v_u_21 = 2
			local v22 = p_u_7.ticks
			local function v39(p23, p24, p25)
				-- upvalues: (ref) v_u_21, (ref) v_u_20, (copy) p_u_7, (ref) p_u_2, (copy) v_u_15, (ref) v_u_1, (copy) v_u_13, (copy) v_u_12, (copy) v_u_9, (ref) v_u_19, (ref) v_u_17, (ref) v_u_18
				local v26 = p24 * 2
				local v27 = math.floor(v26)
				local v28 = (p24 * 2 - v27) / 0.25
				local v29 = 1 - (1 - math.min(v28, 1)) ^ 3
				if v_u_21 <= p24 then
					v_u_21 = p24 + 4
					v_u_20 = p24
					p_u_7.pulse = 1
					if (p23.Position - p_u_2.camPos()).Magnitude < 150 then
						local v30 = p23:PointToWorldSpace(v_u_15)
						v_u_1.burst("Impact", v30, v_u_13, 0.8 * p_u_7.fx)
						v_u_1.flash(v30, v_u_12, 3.5 * p_u_7.fx, 0.3)
						for _, v31 in { -1, 1 } do
							local v32 = v_u_15
							local v33 = v31 * 1.9
							local v34 = p23:PointToWorldSpace(v32 + Vector3.new(v33, -2.6, 0.2) * v_u_9)
							v_u_1.burst("Smoke", v34, nil, 0.35 * p_u_7.fx)
						end
					end
				end
				local v35 = v_u_20 < 0 and -1 or (p24 - v_u_20) / 0.7
				if v35 >= 1 then
					v_u_19 = v_u_19 + 1
					v_u_20 = -10
					v35 = -1
				end
				local v36 = v35 < 0 and 0 or (1 - (1 - v35) ^ 3) * 3.141592653589793
				v_u_17 = (v27 + v29) * 0.5235987755982988 + v_u_19 * 3.141592653589793 + v36
				v_u_18 = 1 - v29
				local v37 = p_u_7
				local v38 = p_u_7.pulse - p25 * 2
				v37.pulse = math.max(v38, 0)
			end
			table.insert(v22, v39)
			local v41 = p_u_2.group(p_u_7, function(p40)
				-- upvalues: (copy) v_u_15, (ref) v_u_17
				return p40 * CFrame.new(v_u_15) * CFrame.Angles(0, 0, -v_u_17)
			end)
			p_u_2.pin(p_u_7, v41, p_u_2.dark(p_u_2.disc(Vector3.new(0.25, 3.6, 3.6) * v_u_9, v11, 0, v_u_3)), CFrame.new(0, 0, 0 * v_u_9) * v_u_6)
			local v_u_42 = v_u_18
			local v_u_43 = v_u_17
			for v44 = 0, 5 do
				p_u_2.pin(p_u_7, v41, p_u_2.bar(Vector3.new(0.42, 4.3, 0.28) * v_u_9, v10, 0, v_u_4), CFrame.Angles(0, 0, v44 * 3.141592653589793 / 6))
			end
			p_u_2.pin(p_u_7, v41, p_u_2.disc(Vector3.new(0.3, 2.7, 2.7) * v_u_9, v10, 0, v_u_4), CFrame.new(0, 0, 0.06 * v_u_9) * v_u_6)
			p_u_2.pin(p_u_7, v41, p_u_2.disc(Vector3.new(0.34, 1.9, 1.9) * v_u_9, v14, 0, v_u_3), CFrame.new(0, 0, 0.1 * v_u_9) * v_u_6)
			p_u_2.pin(p_u_7, v41, p_u_2.disc(Vector3.new(0.38, 1.25, 1.25) * v_u_9, v_u_12, 0, v_u_5), CFrame.new(0, 0, 0.13 * v_u_9) * v_u_6)
			p_u_2.pin(p_u_7, v41, p_u_2.disc(Vector3.new(0.42, 0.55, 0.55) * v_u_9, v14, 0, v_u_3), CFrame.new(0, 0, 0.16 * v_u_9) * v_u_6)
			for v45 = 0, 2 do
				local v46 = 1.5707963267948966 + v45 * 3.141592653589793 * 2 / 3
				p_u_2.pin(p_u_7, v41, p_u_2.ball(0.5 * v_u_9, v14, 0, v_u_3), CFrame.new(math.cos(v46) * 1.15 * v_u_9, math.sin(v46) * 1.15 * v_u_9, 0.12 * v_u_9))
			end
			for v_u_47, v_u_48 in v16 do
				local v50 = p_u_2.group(p_u_7, function(p49)
					-- upvalues: (copy) v_u_15, (copy) v_u_48, (ref) v_u_43, (copy) v_u_47
					return p49 * CFrame.new(v_u_15 + v_u_48) * CFrame.Angles(0, 0, v_u_43 * 1.8695652173913044 + v_u_47 * 0.26)
				end)
				p_u_2.pin(p_u_7, v50, p_u_2.dark(p_u_2.disc(Vector3.new(0.25, 1.7, 1.7) * v_u_9, v11, 0, v_u_3)), CFrame.new(0, 0, 0 * v_u_9) * v_u_6)
				for v51 = 0, 2 do
					p_u_2.pin(p_u_7, v50, p_u_2.bar(Vector3.new(0.36, 2.3, 0.26) * v_u_9, v10, 0, v_u_4), CFrame.Angles(0, 0, v51 * 3.141592653589793 / 3))
				end
				p_u_2.pin(p_u_7, v50, p_u_2.disc(Vector3.new(0.32, 0.6, 0.6) * v_u_9, v_u_12, 0, v_u_5), CFrame.new(0, 0, 0.06 * v_u_9) * v_u_6)
			end
			for _, v52 in { -1, 1 } do
				local v53 = v52 * 0.7071067811865476
				local v_u_54 = Vector3.new(v53, -0.7071067811865475, 0)
				local v_u_55 = v_u_15 + v_u_54 * 1.9 * v_u_9
				p_u_2.add(p_u_7, p_u_2.disc(Vector3.new(1.3, 0.62, 0.62) * v_u_9, v11, 0, v_u_3), function(p56)
					-- upvalues: (copy) v_u_55, (copy) v_u_54, (copy) v_u_9, (ref) v_u_6
					local v57 = v_u_55 + v_u_54 * 0.65 * v_u_9
					return p56 * CFrame.lookAt(v57, v57 + v_u_54) * v_u_6
				end)
				p_u_2.add(p_u_7, p_u_2.disc(Vector3.new(1.2, 0.32, 0.32) * v_u_9, v10, 0, v_u_4), function(p58)
					-- upvalues: (copy) v_u_55, (copy) v_u_54, (ref) v_u_42, (copy) v_u_9, (ref) v_u_6
					local v59 = v_u_55 + v_u_54 * (v_u_42 * 0.45 + 1.4) * v_u_9
					return p58 * CFrame.lookAt(v59, v59 + v_u_54) * v_u_6
				end)
			end
			p_u_2.particles(p_u_7, "AuraMode", v_u_13, {
				["rate"] = 0.7,
				["glow"] = 0.5,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Sparks" },
				["at"] = v_u_15
			})
			p_u_2.particles(p_u_7, "AuraMode", v10, {
				["rate"] = 0.45,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
		end
	}
end