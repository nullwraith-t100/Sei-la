local v_u_1 = game:GetService("RunService")
local v_u_2 = newproxy()
local v_u_3 = newproxy()
local v_u_4 = table.freeze({
	"Destroy",
	"Disconnect",
	"destroy",
	"disconnect"
})
local function v_u_10(p5, p6) -- name: getObjectCleanupFunction
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	local v7 = typeof(p5)
	if v7 == "function" then
		return v_u_2
	end
	if v7 == "thread" then
		return v_u_3
	end
	if p6 then
		return p6
	end
	if v7 == "Instance" then
		return "Destroy"
	end
	if v7 == "RBXScriptConnection" then
		return "Disconnect"
	end
	if v7 == "table" then
		for _, v8 in v_u_4 do
			local v9 = p5[v8]
			if typeof(v9) ~= "function" then
				continue
			end
			return v8
		end
	end
	error(("failed to get cleanup function for object %*: %*"):format(v7, p5), 3)
end
local v_u_11 = {}
v_u_11.__index = v_u_11
function v_u_11.new() -- name: new
	-- upvalues: (copy) v_u_11
	local v12 = v_u_11
	local v13 = setmetatable({}, v12)
	v13._objects = {}
	v13._cleaning = false
	return v13
end
function v_u_11.Add(p14, p15, p16) -- name: Add
	-- upvalues: (copy) v_u_10
	if p14._cleaning then
		error("cannot call trove:Add() while cleaning", 2)
	end
	local v17 = v_u_10(p15, p16)
	local v18 = p14._objects
	table.insert(v18, { p15, v17 })
	return p15
end
function v_u_11.Clone(p19, p20) -- name: Clone
	if p19._cleaning then
		error("cannot call trove:Clone() while cleaning", 2)
	end
	return p19:Add(p20:Clone())
end
function v_u_11.Construct(p21, p22, ...) -- name: Construct
	if p21._cleaning then
		error("Cannot call trove:Construct() while cleaning", 2)
	end
	local v23 = nil
	local v24 = type(p22)
	if v24 == "table" then
		v23 = p22.new(...)
	elseif v24 == "function" then
		v23 = p22(...)
	end
	return p21:Add(v23)
end
function v_u_11.Connect(p25, p26, p27) -- name: Connect
	if p25._cleaning then
		error("Cannot call trove:Connect() while cleaning", 2)
	end
	if typeof(p26) == "RBXScriptSignal" then
		return p25:Add(p26:Connect(p27))
	end
	if typeof(p26) == "table" then
		local v28 = p26.Connect
		if typeof(v28) == "function" then
			local v29 = p26.Once
			if typeof(v29) == "function" then
				return p25:Add(p26:Connect(p27))
			end
			error("did not receive a signal as an argument", 3)
		else
			error("did not receive a signal as an argument", 3)
		end
	else
		error("did not receive a signal as an argument", 3)
	end
	return p25:Add(p26:Connect(p27))
end
function v_u_11.Once(p_u_30, p31, p_u_32) -- name: Once
	if p_u_30._cleaning then
		error("Cannot call trove:Connect() while cleaning", 2)
	end
	if typeof(p31) ~= "RBXScriptSignal" then
		if typeof(p31) == "table" then
			local v33 = p31.Connect
			if typeof(v33) == "function" then
				local v34 = p31.Once
				if typeof(v34) ~= "function" then
					error("did not receive a signal as an argument", 3)
				end
			else
				error("did not receive a signal as an argument", 3)
			end
		else
			error("did not receive a signal as an argument", 3)
		end
	end
	local v_u_35 = nil
	v_u_35 = p31:Once(function(...)
		-- upvalues: (copy) p_u_32, (copy) p_u_30, (ref) v_u_35
		p_u_32(...)
		p_u_30:Pop(v_u_35)
	end)
	return p_u_30:Add(v_u_35)
end
function v_u_11.BindToRenderStep(p36, p_u_37, p38, p39) -- name: BindToRenderStep
	-- upvalues: (copy) v_u_1
	if p36._cleaning then
		error("cannot call trove:BindToRenderStep() while cleaning", 2)
	end
	v_u_1:BindToRenderStep(p_u_37, p38, p39)
	p36:Add(function()
		-- upvalues: (ref) v_u_1, (copy) p_u_37
		v_u_1:UnbindFromRenderStep(p_u_37)
	end)
end
function v_u_11.AddPromise(p_u_40, p_u_41) -- name: AddPromise
	if p_u_40._cleaning then
		error("cannot call trove:AddPromise() while cleaning", 2)
	end
	if typeof(p_u_41) == "table" then
		local v42 = p_u_41.getStatus
		if typeof(v42) == "function" then
			local v43 = p_u_41.finally
			if typeof(v43) == "function" then
				local v44 = p_u_41.cancel
				if typeof(v44) ~= "function" then
					error("did not receive a promise as an argument", 3)
				end
			else
				error("did not receive a promise as an argument", 3)
			end
		else
			error("did not receive a promise as an argument", 3)
		end
	else
		error("did not receive a promise as an argument", 3)
	end
	if p_u_41:getStatus() == "Started" then
		p_u_41:finally(function()
			-- upvalues: (copy) p_u_40, (copy) p_u_41
			if not p_u_40._cleaning then
				p_u_40:_findAndRemoveFromObjects(p_u_41, false)
			end
		end)
		p_u_40:Add(p_u_41, "cancel")
	end
	return p_u_41
end
function v_u_11.Remove(p45, p46) -- name: Remove
	if p45._cleaning then
		error("cannot call trove:Remove() while cleaning", 2)
	end
	return p45:_findAndRemoveFromObjects(p46, true)
end
function v_u_11.Pop(p47, p48) -- name: Pop
	if p47._cleaning then
		error("cannot call trove:Pop() while cleaning", 2)
	end
	return p47:_findAndRemoveFromObjects(p48, false)
end
function v_u_11.Extend(p49) -- name: Extend
	-- upvalues: (copy) v_u_11
	if p49._cleaning then
		error("cannot call trove:Extend() while cleaning", 2)
	end
	return p49:Construct(v_u_11)
end
function v_u_11.Clean(p50) -- name: Clean
	if not p50._cleaning then
		p50._cleaning = true
		for _, v51 in p50._objects do
			p50:_cleanupObject(v51[1], v51[2])
		end
		table.clear(p50._objects)
		p50._cleaning = false
	end
end
function v_u_11.WrapClean(p_u_52) -- name: WrapClean
	return function()
		-- upvalues: (copy) p_u_52
		p_u_52:Clean()
	end
end
function v_u_11._findAndRemoveFromObjects(p53, p54, p55) -- name: _findAndRemoveFromObjects
	local v56 = p53._objects
	for v57, v58 in v56 do
		if v58[1] ~= p54 then
			continue
		end
		local v59 = #v56
		v56[v57] = v56[v59]
		v56[v59] = nil
		if p55 then
			p53:_cleanupObject(v58[1], v58[2])
		end
		return true
	end
	return false
end
function v_u_11._cleanupObject(_, p60, p61) -- name: _cleanupObject
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	if p61 == v_u_2 then
		task.spawn(p60)
		return
	elseif p61 == v_u_3 then
		local v62 = task.cancel
		pcall(v62, p60)
	else
		p60[p61](p60)
	end
end
function v_u_11.AttachToInstance(p_u_63, p64) -- name: AttachToInstance
	if p_u_63._cleaning then
		error("cannot call trove:AttachToInstance() while cleaning", 2)
	elseif not p64:IsDescendantOf(game) then
		error("instance is not a descendant of the game hierarchy", 2)
	end
	return p_u_63:Connect(p64.Destroying, function()
		-- upvalues: (copy) p_u_63
		p_u_63:Destroy()
	end)
end
function v_u_11.Destroy(p65) -- name: Destroy
	p65:Clean()
end
return {
	["new"] = v_u_11.new
}