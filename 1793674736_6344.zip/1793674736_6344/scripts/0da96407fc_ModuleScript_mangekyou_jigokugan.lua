local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(170, 112, 255)
local v_u_6 = Color3.fromRGB(238, 222, 255)
local v_u_7 = Color3.fromRGB(10, 6, 18)
local v_u_8 = Color3.fromRGB(24, 10, 48)
local v_u_9 = Color3.fromRGB(58, 16, 118)
local function v_u_14(p10, p11, p12) -- name: hellFlames
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9
	local v13 = Instance.new("ParticleEmitter")
	v13.Texture = v_u_4.HellFlame
	v13.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v13.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v13.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, v_u_6),
		ColorSequenceKeypoint.new(0.3, v_u_5),
		ColorSequenceKeypoint.new(0.75, p11),
		ColorSequenceKeypoint.new(1, v_u_9)
	})
	v13.LightEmission = 0.35
	v13.LightInfluence = 0
	v13.Lifetime = NumberRange.new(0.5, 0.65)
	v13.Size = NumberSequence.new(p12)
	v13.Rotation = NumberRange.new(-8, 8)
	v13.Speed = NumberRange.new(1, 2.5)
	v13.EmissionDirection = Enum.NormalId.Top
	v13.Rate = 0
	v13.Enabled = false
	v13.Parent = p10
	return v13
end
return function(p_u_15)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_8, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_14
	return {
		["w5_mangekyou_jigokugan"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_2, (copy) p_u_15, (ref) v_u_4, (ref) v_u_3, (ref) v_u_8, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_14
			local v_u_18 = p_u_16.character:GetScale()
			local v_u_19 = v_u_2.color(p17.color)
			local v_u_20 = nil
			local v_u_21 = 0
			local v_u_24 = p_u_15.throb(p_u_16, 4.2, 1.5, 1.7, function(p22)
				-- upvalues: (ref) v_u_21, (ref) v_u_2, (ref) p_u_15, (copy) p_u_16, (copy) v_u_19, (ref) v_u_4, (ref) v_u_20, (ref) v_u_3
				v_u_21 = v_u_21 + 6.283185307179586
				v_u_2.ring(p_u_15.feetAt(p_u_16, p22, 0.15), v_u_19, 5.5 * p_u_16.fx, 0.5, v_u_4.Ring)
				local v23 = v_u_20
				if v23 then
					v23:Emit(v_u_3.level() <= 1 and 2 or 5)
				end
			end)
			local v_u_25 = 0
			local v26 = p_u_16.ticks
			local function v31(_, _, p27)
				-- upvalues: (ref) v_u_25, (ref) v_u_21
				local v28 = v_u_25
				local v29 = v_u_21 - v_u_25
				local v30 = p27 * 7
				v_u_25 = v28 + v29 * math.min(v30, 1)
			end
			table.insert(v26, v31)
			local v_u_44 = p_u_15.group(p_u_16, function(p32, p33)
				-- upvalues: (copy) v_u_18, (ref) p_u_15, (ref) v_u_25
				local v34 = p32.Position
				local v35 = 0.6 * v_u_18
				local v36 = v34 + Vector3.new(0, v35, 0)
				local v37 = p_u_15.camPos() - v36
				local v38
				if v37.Magnitude > 0.001 then
					v38 = v37.Unit
				else
					v38 = -p32.LookVector
				end
				local v39 = v36 - v38 * 1.5 * v_u_18
				local v40 = CFrame.lookAt(v39, v39 + v38)
				local v41 = CFrame.Angles
				local v42 = v_u_25
				local v43 = p33 * 0.8
				return v40 * v41(0, 0, v42 + math.sin(v43) * 0.08)
			end)
			local v45 = {
				Vector3.new(0, 6, 0) * v_u_18,
				Vector3.new(4.4, 0, 0) * v_u_18,
				Vector3.new(0, -3.5, 0) * v_u_18,
				Vector3.new(-4.4, 0, 0) * v_u_18
			}
			local v46 = 1.45 * v_u_18
			local v47 = v46 / 1.4142135623730951
			local v_u_48 = {}
			local function v59(p49, p50, p51) -- name: fill
				-- upvalues: (ref) v_u_2, (ref) v_u_8, (ref) p_u_15, (copy) p_u_16, (copy) v_u_44, (copy) v_u_48
				local v52 = v_u_2.part
				local v53 = CFrame.identity
				local v54 = v_u_8
				local v55 = {
					["shape"] = nil,
					["material"] = nil,
					["transparency"] = 0.12
				}
				local v56
				if p51 then
					v56 = Enum.PartType.Wedge
				else
					v56 = nil
				end
				v55.shape = v56
				v55.material = Enum.Material.SmoothPlastic
				local v57 = v52(p49, v53, v54, v55)
				p_u_15.pin(p_u_16, v_u_44, v57, p50)
				p_u_15.fadeFromBehind(p_u_16, v57, 0.8)
				local v58 = v_u_48
				table.insert(v58, v57)
			end
			local v60 = v47 * 2
			local v61 = v47 * 2
			local v62 = 0.08 * v_u_18
			v59(Vector3.new(v60, v61, v62), CFrame.identity, false)
			for _, v63 in v45 do
				local v64 = v63.Unit
				local v65 = -v64.Y
				local v66 = v64.X
				local v67 = Vector3.new(v65, v66, 0)
				for _, v68 in { v67, -v67 } do
					local v69 = v64 * v47
					local v70 = v63.Magnitude - v47
					local v71 = 0.08 * v_u_18
					local v72 = v69 + v68 * (v47 / 2) + v64 * (v70 / 2)
					v59(Vector3.new(v71, v70, v47), CFrame.fromMatrix(v72, v68:Cross(v64), v64, -v68), true)
				end
			end
			local v_u_73 = -1
			local v74 = p_u_16.ticks
			local function v79()
				-- upvalues: (copy) v_u_24, (ref) v_u_73, (ref) v_u_8, (copy) v_u_19, (copy) v_u_48
				local v75 = v_u_24() * 10 + 0.5
				local v76 = math.floor(v75) / 10
				if v76 ~= v_u_73 then
					v_u_73 = v76
					local v77 = v_u_8:Lerp(v_u_19, v76 * 0.5)
					for _, v78 in v_u_48 do
						v78.Color = v77
					end
				end
			end
			table.insert(v74, v79)
			for _, v80 in v45 do
				local v81 = v80.Y
				local v82 = v80.X
				local v83 = math.atan2(v81, v82)
				for _, v84 in { v83 - 0.7853981633974483, v83 + 0.7853981633974483 } do
					local v85 = math.cos(v84) * v46
					local v86 = math.sin(v84) * v46
					local v87 = -0.1 * v_u_18
					local v88 = Vector3.new(v85, v86, v87)
					local v89 = p_u_15.between
					local v90 = -0.1 * v_u_18
					local v_u_91, v_u_92 = v89(v88, v80 + Vector3.new(0, 0, v90))
					local v93 = p_u_15.bar
					local v94 = 0.22 * v_u_18
					local v95 = 0.22 * v_u_18
					local v_u_96 = v93(Vector3.new(v94, v95, v_u_92), v_u_5, 0)
					p_u_15.add(p_u_16, v_u_96, function()
						-- upvalues: (copy) v_u_24, (copy) v_u_96, (copy) v_u_18, (copy) v_u_92, (ref) v_u_5, (ref) v_u_6, (copy) v_u_44, (copy) v_u_91
						local v97 = v_u_24()
						local v98 = v_u_96
						local v99 = (0.22 + 0.16 * v97) * v_u_18
						local v100 = (0.22 + 0.16 * v97) * v_u_18
						local v101 = v_u_92
						v98.Size = Vector3.new(v99, v100, v101)
						v_u_96.Color = v_u_5:Lerp(v_u_6, v97)
						return v_u_44.cf * v_u_91
					end)
					p_u_15.fadeFromBehind(p_u_16, v_u_96, 0.45)
				end
			end
			for v102 = 0, 3 do
				local v103 = 0.7853981633974483 + v102 * 3.141592653589793 / 2
				local v104 = math.cos(v103)
				local v105 = math.sin(v103)
				local v106 = Vector3.new(v104, v105, 0)
				local v107, v108 = p_u_15.between(v106 * v46 - Vector3.new(0, 0, 0.1) * v_u_18, v106 * 3.3 * v_u_18)
				local v109 = p_u_15.bar
				local v110 = 0.12 * v_u_18
				local v111 = 0.12 * v_u_18
				local v112 = v109(Vector3.new(v110, v111, v108), v_u_5, 0)
				p_u_15.pin(p_u_16, v_u_44, v112, v107)
				p_u_15.fadeFromBehind(p_u_16, v112, 0.45)
			end
			local v_u_113 = 2.7 * v_u_18
			local v114 = p_u_15.picture(v_u_113 * 2.15, v_u_4.Ring, v_u_19, 0.1)
			p_u_15.pin(p_u_16, v_u_44, v114, CFrame.new(0, 0, -0.06 * v_u_18) * CFrame.Angles(1.5707963267948966, 0, 0))
			p_u_15.fadeFromBehind(p_u_16, v114, 0.45)
			for v_u_115 = 0, 3 do
				local function v121(_, p116) -- name: place
					-- upvalues: (copy) v_u_115, (copy) v_u_113, (copy) v_u_24, (copy) v_u_44, (copy) v_u_18
					local v117 = 0.7853981633974483 + v_u_115 * 3.141592653589793 / 2
					local v118 = p116 * 1.3 + v_u_115
					local v119 = v117 + math.sin(v118) * 0.08
					local v120 = v_u_113 * (1 + 0.3 * v_u_24())
					return v_u_44.cf * CFrame.new(math.cos(v119) * v120, math.sin(v119) * v120, -0.35 * v_u_18)
				end
				local v122 = p_u_15.ball(0.6 * v_u_18, v_u_7, 0, Enum.Material.SmoothPlastic)
				p_u_15.add(p_u_16, v122, v121)
				p_u_15.add(p_u_16, p_u_15.ball(1 * v_u_18, v_u_19, 0.55), p_u_15.behind(v121, 0.3 * v_u_18))
				local v123 = v_u_14(v122, v_u_19, 0.8 * v_u_18 * p_u_16.fx)
				v123.Rate = 5
				v123:SetAttribute("BaseRate", v123.Rate)
				v123.Rate = v123.Rate * v_u_3.formRate()
				v123.Enabled = true
			end
			local v_u_124 = 1.25 * p_u_16.fx
			local v125 = p_u_15.bar
			local v126 = 2.4 * v_u_18
			local v127 = 2.4 * v_u_18
			local v128 = v125(Vector3.new(v126, 0.2, v127), v_u_19, 1)
			p_u_15.add(p_u_16, v128, function(p129)
				-- upvalues: (ref) p_u_15, (copy) p_u_16, (copy) v_u_124
				return CFrame.new(p_u_15.feetAt(p_u_16, p129, v_u_124 * 0.85))
			end)
			local v130 = v_u_14(v128, v_u_19, v_u_124)
			v130.Rate = (p_u_16.fx > 1 and 1.6 or 1) * 7
			v130:SetAttribute("BaseRate", v130.Rate)
			v130.Rate = v130.Rate * v_u_3.formRate()
			v130.Enabled = true
			v_u_20 = v130
			p_u_15.particles(p_u_16, "AuraMode", v_u_19, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end