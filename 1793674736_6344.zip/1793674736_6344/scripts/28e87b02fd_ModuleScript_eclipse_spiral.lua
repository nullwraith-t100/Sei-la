local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(v2.Shared.Config.Textures)
return function(p_u_6)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_3
	return {
		["w3_eclipse_spiral"] = function(p_u_7, p8)
			-- upvalues: (ref) v_u_4, (copy) p_u_6, (ref) v_u_5, (ref) v_u_1, (ref) v_u_3
			local v_u_9 = v_u_4.color(p8.color)
			local v10 = v_u_4.color(p8.color2)
			local v_u_11 = p_u_6.rgb(214, 220, 236)
			local v12 = p_u_6.rgb(255, 249, 232)
			local v13 = p_u_6.rgb(6, 6, 10)
			local v_u_14 = p_u_7.fx <= 1 and 1 or p_u_7.fx / 1.35
			local v_u_15 = p_u_6.crownOf(p_u_7)
			local v_u_16 = Vector3.new(0, 0, 0)
			local v_u_18 = p_u_6.throb(p_u_7, 4.2, 2, 1.4, function(p17)
				-- upvalues: (ref) v_u_4, (ref) v_u_16, (copy) v_u_9, (copy) p_u_7, (ref) p_u_6, (copy) v_u_11, (ref) v_u_5
				v_u_4.flash(v_u_16, v_u_9, 3.2 * p_u_7.fx, 0.25)
				v_u_4.ring(p_u_6.feetAt(p_u_7, p17, 0.15), v_u_11, 4.5 * p_u_7.fx, 0.5, v_u_5.Ring)
			end)
			local v_u_19 = Vector3.new(0, 0, 1)
			local v_u_20 = Vector3.new(0, 0, 0)
			local v21 = p_u_7.ticks
			local function v30(p22, p23)
				-- upvalues: (ref) v_u_20, (copy) v_u_15, (copy) p_u_7, (ref) p_u_6, (ref) v_u_19, (ref) v_u_16
				local v24 = v_u_15(p22).Position
				local v25 = p_u_7.eyeLift
				local v26 = p23 * 2
				local v27 = v25 + math.sin(v26) * 0.1
				v_u_20 = v24 + Vector3.new(0, v27, 0)
				local v28 = p_u_6.camPos() - v_u_20
				v_u_19 = v28.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v28.Unit
				local v29 = v_u_19:Cross(Vector3.new(0, 1, 0))
				v_u_16 = v_u_20 + (v29.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v29.Unit) * 2 + v_u_19 * 0.4
			end
			table.insert(v21, v30)
			local v_u_31 = p_u_6.disc(Vector3.new(0.12, 3.9, 3.9), v13, 0, Enum.Material.SmoothPlastic)
			p_u_6.add(p_u_7, v_u_31, function()
				-- upvalues: (ref) v_u_20, (ref) v_u_19
				return CFrame.lookAt(v_u_20 - v_u_19 * 0.35, v_u_20 + v_u_19) * CFrame.Angles(0, 1.5707963267948966, 0)
			end)
			local v_u_32 = math.sqrt(v_u_14) * 7.4
			local v_u_33, v_u_34 = p_u_6.picture(v_u_32, v_u_5.EclipseCorona, v12, 0.05)
			p_u_6.add(p_u_7, v_u_33, function(_, p35)
				-- upvalues: (ref) v_u_20, (ref) v_u_19
				local v36 = -p35 * 0.9
				return CFrame.lookAt(v_u_20 - v_u_19 * 0.55, v_u_20 - v_u_19 * 1.55) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v36, 0)
			end)
			local v37 = math.sqrt(v_u_14) * 10
			local v38, v_u_39 = p_u_6.picture(v37, v_u_5.EclipseRays, v_u_11, 0.5)
			p_u_6.add(p_u_7, v38, function(_, p40)
				-- upvalues: (ref) v_u_20, (ref) v_u_19
				local v41 = p40 * 0.35
				return CFrame.lookAt(v_u_20 - v_u_19 * 0.75, v_u_20 - v_u_19 * 1.75) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v41, 0)
			end)
			if p_u_7.character == v_u_1.LocalPlayer.Character then
				local v_u_42 = -1
				local v43 = p_u_7.ticks
				local function v51(p44)
					-- upvalues: (ref) v_u_3, (ref) v_u_42, (copy) v_u_31, (copy) v_u_34, (copy) v_u_39
					local v45 = v_u_3.CurrentCamera
					if v45 then
						local v46 = (v45.CFrame.LookVector:Dot(p44.LookVector) + 0.1) * 1.6
						local v47 = math.clamp(v46, 0, 1) * 20 + 0.5
						local v48 = math.floor(v47) / 20
						if v48 ~= v_u_42 then
							v_u_42 = v48
							v_u_31.LocalTransparencyModifier = v48 * 0.7
							for _, v49 in v_u_34 do
								v49.LocalTransparencyModifier = v48 * 0.6
							end
							for _, v50 in v_u_39 do
								v50.LocalTransparencyModifier = v48 * 0.75
							end
						end
					else
						return
					end
				end
				table.insert(v43, v51)
			end
			local v52 = p_u_7.ticks
			table.insert(v52, function()
				-- upvalues: (copy) v_u_18, (copy) v_u_32, (copy) v_u_33, (copy) v_u_39
				local v53 = v_u_18()
				local v54 = v_u_32 * (1 + 0.22 * v53)
				v_u_33.Size = Vector3.new(v54, 0.05, v54)
				for _, v55 in v_u_39 do
					v55.Transparency = 0.5 - 0.3 * v53
				end
			end)
			local v_u_56 = 0
			local v57 = p_u_7.ticks
			local function v59(_, _, p58)
				-- upvalues: (ref) v_u_56, (copy) v_u_18
				v_u_56 = v_u_56 + p58 * (0.9 + v_u_18() * 2.5)
			end
			table.insert(v57, v59)
			local v65 = p_u_6.group(p_u_7, function(p60, p61)
				-- upvalues: (copy) v_u_14, (ref) v_u_56
				local v62 = CFrame.new
				local v63 = 0.35 * v_u_14
				local v64 = p61 * 1.4
				return p60 * v62(0, v63 + math.sin(v64) * 0.1, 0) * CFrame.Angles(0.32, 0, -0.14) * CFrame.Angles(0, v_u_56, 0)
			end)
			local v66 = 2.75 * v_u_14
			p_u_6.pin(p_u_7, v65, p_u_6.picture(v66 * 2.1, v_u_5.Ring, v_u_9, 0.05), CFrame.identity)
			for v67 = 1, 3 do
				local v68 = (v67 - 1) / 3 * 3.141592653589793 * 2
				local v69 = math.cos(v68) * v66
				local v70 = math.sin(v68) * v66
				local v71 = Vector3.new(v69, 0, v70)
				local v72 = -math.sin(v68)
				local v73 = math.cos(v68)
				local v74 = Vector3.new(v72, 0, v73)
				local v75 = math.cos(v68)
				local v76 = math.sin(v68)
				local v77 = Vector3.new(v75, 0, v76)
				p_u_6.pin(p_u_7, v65, p_u_6.ball(0.78 * v_u_14, v_u_9, 0), CFrame.new(v71))
				local v78 = v71 - v74 * 1.05 * v_u_14 + v77 * 0.35 * v_u_14
				local v79 = v78 - v74 * 0.7 * v_u_14 + v77 * 0.65 * v_u_14
				local v80, v81 = p_u_6.between(v71, v78)
				local v82, v83 = p_u_6.between(v78, v79)
				local v84 = p_u_6.pin
				local v85 = p_u_6.bar
				local v86 = 0.44 * v_u_14
				local v87 = 0.2 * v_u_14
				local v88 = v81 + 0.1
				v84(p_u_7, v65, v85(Vector3.new(v86, v87, v88), v_u_9, 0), v80)
				local v89 = p_u_6.pin
				local v90 = p_u_6.bar
				local v91 = 0.26 * v_u_14
				local v92 = 0.16 * v_u_14
				local v93 = v83 + 0.06
				v89(p_u_7, v65, v90(Vector3.new(v91, v92, v93), v_u_9, 0), v82)
			end
			local v94 = p_u_6.particles
			local v95 = {
				["only"] = nil,
				["paint"] = nil,
				["at"] = nil,
				["rate"] = 0.6,
				["only"] = { "Flames", "Smoke" },
				["paint"] = v10:Lerp(v13, 0.3)
			}
			local v96 = p_u_7.feet + 0.1
			v95.at = Vector3.new(0, v96, 0)
			v94(p_u_7, "FireDark", nil, v95)
			p_u_6.particles(p_u_7, "AuraMode", v_u_9, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
		end
	}
end