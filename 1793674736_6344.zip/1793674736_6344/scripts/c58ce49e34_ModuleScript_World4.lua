local v1 = {
	["frost_imp"] = {
		["shirt"] = 7530698924,
		["pants"] = 7530700005,
		["accessories"] = nil,
		["skin"] = "#BFE8FF",
		["accessories"] = { 82499094470805, 98362181805476, 106707675260188 }
	},
	["snow_hare"] = {
		["shirt"] = 6329202444,
		["pants"] = 6329204573,
		["accessories"] = nil,
		["skin"] = "#F4FAFF",
		["accessories"] = { 90885705544321, 139761838067966, 14927388883 }
	},
	["ice_kappa"] = {
		["shirt"] = 5039424968,
		["pants"] = 5367081440,
		["accessories"] = nil,
		["skin"] = "#5AA8C8",
		["accessories"] = { 17504950322, 88621841158278, 134422566436747 }
	},
	["frost_seal"] = {
		["shirt"] = 111679653588444,
		["pants"] = 13792440419,
		["accessories"] = nil,
		["skin"] = "#8AA8C0",
		["accessories"] = { 112566482177131, 17420136101 }
	},
	["glacier_golem"] = {
		["shirt"] = 6735136452,
		["pants"] = 126381460793121,
		["accessories"] = nil,
		["skin"] = "#A8D8F0",
		["accessories"] = { 139437284390794, 70662778916402, 17420136101 }
	},
	["frost_ram"] = {
		["shirt"] = 11783456935,
		["pants"] = 6413424791,
		["accessories"] = nil,
		["skin"] = "#8A98A8",
		["accessories"] = { 15440426240, 85643027206646 }
	},
	["glacier_titan"] = {
		["shirt"] = 131041476181880,
		["pants"] = 113056249233922,
		["accessories"] = nil,
		["skin"] = "#9FD0EC",
		["accessories"] = {
			140615807228564,
			17050569631,
			70662778916402,
			90777104860506
		}
	},
	["pine_spirit"] = {
		["shirt"] = 129807719683427,
		["pants"] = 8358917520,
		["accessories"] = nil,
		["skin"] = "#6A4A30",
		["accessories"] = { 93966772640007, 91152197733041, 76327129683226 }
	},
	["ice_lynx"] = {
		["shirt"] = 95627929125538,
		["pants"] = 6207469635,
		["accessories"] = nil,
		["skin"] = "#E8F2FA",
		["accessories"] = { 102531804966151, 75323171069105 }
	},
	["cave_yeti"] = {
		["shirt"] = 96762617245393,
		["pants"] = 4775259993,
		["accessories"] = nil,
		["skin"] = "#2E3A6A",
		["accessories"] = { 15825442299, 11891729595 }
	},
	["icicle_bat"] = {
		["shirt"] = 17427473279,
		["pants"] = 2129449725,
		["accessories"] = nil,
		["skin"] = "#3A5A8A",
		["accessories"] = { 119354841246212, 120611486452864, 17420136101 }
	},
	["frozen_pirate"] = {
		["shirt"] = 4900963361,
		["pants"] = 4900964392,
		["accessories"] = nil,
		["skin"] = "#A8C8D8",
		["accessories"] = { 110938232256056, 129846359749306 }
	},
	["ice_shark"] = {
		["shirt"] = 83246252919093,
		["pants"] = 109877600926430,
		["accessories"] = nil,
		["skin"] = "#9FC8E0",
		["accessories"] = { 90677999156592, 16428749404, 91268379275915 }
	},
	["frost_captain"] = {
		["shirt"] = 15244515241,
		["pants"] = 121034618824693,
		["accessories"] = nil,
		["skin"] = "#A8C8D8",
		["accessories"] = {
			130686359396581,
			75645942123574,
			123928247533572,
			18915467304
		}
	},
	["angler"] = {
		["shirt"] = 102315826695424,
		["pants"] = 11028894179,
		["accessories"] = nil,
		["skin"] = "#1A2A3A",
		["accessories"] = { 89202510770546, 113938769247099 }
	},
	["abyss_squid"] = {
		["shirt"] = 11866620919,
		["pants"] = 14520870457,
		["accessories"] = nil,
		["skin"] = "#34347A",
		["accessories"] = { 17560584623, 15540891345 }
	},
	["drowned_knight"] = {
		["shirt"] = 13395472161,
		["pants"] = 17440202544,
		["accessories"] = nil,
		["skin"] = "#4A7A78",
		["accessories"] = { 90676740104555, 94655805239046 }
	},
	["eel_serpent"] = {
		["shirt"] = 13929140947,
		["pants"] = 7263280035,
		["accessories"] = nil,
		["skin"] = "#2A4A5A",
		["accessories"] = { 84902431356634, 6098387810 }
	},
	["ice_maiden"] = {
		["shirt"] = 8029418323,
		["pants"] = 8029415729,
		["accessories"] = nil,
		["skin"] = "#E8F4FF",
		["accessories"] = { 134423307956869, 71822131250932, 13808515440 }
	},
	["frost_guard"] = {
		["shirt"] = 110429238876049,
		["pants"] = 101856514577624,
		["accessories"] = nil,
		["skin"] = "#CFE0EC",
		["accessories"] = { 137862034108203, 103501428460301, 132234823610119 }
	},
	["snow_empress"] = {
		["shirt"] = 797864360,
		["pants"] = 91142376,
		["accessories"] = nil,
		["skin"] = "#F0F8FF",
		["accessories"] = {
			72820267799890,
			15873458653,
			84256837151483,
			86789123264515
		}
	},
	["storm_yeti"] = {
		["shirt"] = 1131060868,
		["pants"] = 1131059551,
		["accessories"] = nil,
		["skin"] = "#4A5A6A",
		["accessories"] = { 79990906029979, 135233579661576, 120416207213537 }
	},
	["blizzard_spirit"] = {
		["shirt"] = 80216895056699,
		["pants"] = 6436140387,
		["accessories"] = nil,
		["skin"] = "#E8F4FF",
		["accessories"] = { 13504738802, 12633538171, 92236597784759 }
	},
	["rift_wraith"] = {
		["shirt"] = 15479748278,
		["pants"] = 84399778005538,
		["accessories"] = nil,
		["skin"] = "#0E1028",
		["accessories"] = { 17357502669, 85650094872311, 85997942516602 }
	},
	["crystal_mantis"] = {
		["shirt"] = 126969731781578,
		["pants"] = 121368931181216,
		["accessories"] = nil,
		["skin"] = "#7FC8F0",
		["accessories"] = { 10490337110, 112731832726288 }
	},
	["deep_cultist"] = {
		["shirt"] = 17627375011,
		["pants"] = 17627385029,
		["accessories"] = nil,
		["skin"] = "#3A6A6A",
		["accessories"] = { 100260561180166, 118107814221954, 118921905646000 }
	},
	["abyss_eel"] = {
		["shirt"] = 14960901717,
		["pants"] = 11028894179,
		["accessories"] = nil,
		["skin"] = "#0E1A2A",
		["accessories"] = { 12350145559, 137769508784035 }
	},
	["leviathan"] = {
		["shirt"] = 5784574075,
		["pants"] = 7263280035,
		["accessories"] = nil,
		["skin"] = "#1E3A5A",
		["accessories"] = {
			73265112749140,
			117885095119787,
			81946997251152,
			131033301105691
		}
	},
	["jelly_spirit"] = {
		["shirt"] = 9053157700,
		["pants"] = 16187846133,
		["accessories"] = nil,
		["skin"] = "#FF9AF0",
		["accessories"] = { 138346693859623, 13813351692 }
	},
	["lantern_fish"] = {
		["shirt"] = 17862940358,
		["pants"] = 2129449725,
		["accessories"] = nil,
		["skin"] = "#1A1E3A",
		["accessories"] = { 112912144404682, 76327129683226 }
	},
	["citadel_knight"] = {
		["shirt"] = 13325671671,
		["pants"] = 14876148908,
		["accessories"] = nil,
		["skin"] = "#DDEFFF",
		["accessories"] = { 138049525857858, 98298761222109, 138231125710919 }
	},
	["ice_drake"] = {
		["shirt"] = 8835892991,
		["pants"] = 8835902276,
		["accessories"] = nil,
		["skin"] = "#8FD0F0",
		["accessories"] = { 94583350527816, 117936113649118, 6098387810 }
	},
	["abyss_samurai"] = {
		["shirt"] = 76236722545259,
		["pants"] = 16962366304,
		["accessories"] = nil,
		["skin"] = "#2A3A4A",
		["accessories"] = { 9243345494, 14382881471 }
	},
	["abyss_assassin"] = {
		["shirt"] = 6334353124,
		["pants"] = 103205951147180,
		["accessories"] = nil,
		["skin"] = "#1A2A3A",
		["accessories"] = { 17482279965, 127079733947853, 76327129683226 }
	},
	["abyss_king"] = {
		["shirt"] = 118400353455601,
		["pants"] = 118553906523936,
		["accessories"] = nil,
		["skin"] = "#2A4A5A",
		["accessories"] = {
			115907885673764,
			78545040296642,
			106641167041333,
			16717600399
		}
	}
}
return v1