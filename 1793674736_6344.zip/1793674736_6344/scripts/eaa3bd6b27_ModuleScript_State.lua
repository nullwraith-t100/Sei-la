local v_u_1 = game:GetService("HttpService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v3.Shared.Config.Daily)
local v_u_6 = require(v3.Shared.Logic.DailyStreak)
local v_u_7 = require(v3.Shared.Logic.Fuse)
local v_u_8 = require(v3.Shared.Logic.PetLocks)
local v_u_9 = require(v3.Shared.Config.Quests)
local v_u_10 = require(v3.Shared.Config.Rewards)
local v_u_11 = require(v3.Shared.Net)
local v_u_12 = v2.LocalPlayer
local v_u_31 = {
	["sync"] = function() -- name: sync
		-- upvalues: (copy) v_u_11, (copy) v_u_12
		v_u_11.event("PrivateState").OnClientEvent:Connect(function(p13, p14)
			-- upvalues: (ref) v_u_12
			if type(p13) == "table" then
				for v15, v16 in p13 do
					v_u_12:SetAttribute(v15, v16)
				end
			end
			if type(p14) == "table" then
				for _, v17 in p14 do
					if type(v17) ~= "string" then
						continue
					end
					v_u_12:SetAttribute(v17, nil)
				end
			end
		end)
		local function v18()
			-- upvalues: (ref) v_u_11
			return v_u_11.func("GetState"):InvokeServer()
		end
		local v19, v20 = pcall(v18)
		if v19 and type(v20) == "table" then
			for v21, v22 in v20 do
				v_u_12:SetAttribute(v21, v22)
			end
		elseif not v19 then
			warn("[State] could not fetch the player\'s state: " .. tostring(v20))
		end
	end,
	["number"] = function(p23, p24) -- name: number
		-- upvalues: (copy) v_u_12
		local v25 = v_u_12:GetAttribute(p23)
		return type(v25) ~= "number" and (p24 or 0) or v25
	end,
	["string"] = function(p26, p27) -- name: string
		-- upvalues: (copy) v_u_12
		local v28 = v_u_12:GetAttribute(p26)
		return type(v28) ~= "string" and (p27 or "") or v28
	end,
	["watch"] = function(p29, p30) -- name: watch
		-- upvalues: (copy) v_u_12
		task.spawn(p30)
		return v_u_12:GetAttributeChangedSignal(p29):Connect(p30)
	end
}
local v_u_32 = {}
local function v_u_40(p33) -- name: decode
	-- upvalues: (copy) v_u_31, (copy) v_u_32, (copy) v_u_1
	local v_u_34 = v_u_31.string(p33, "{}")
	local v35 = v_u_32[p33]
	if v35 and v35.raw == v_u_34 then
		return v35.value
	end
	local function v36()
		-- upvalues: (ref) v_u_1, (copy) v_u_34
		return v_u_1:JSONDecode(v_u_34)
	end
	local v37, v38 = pcall(v36)
	local v39 = (not v37 or type(v38) ~= "table") and {} or v38
	v_u_32[p33] = {
		["raw"] = v_u_34,
		["value"] = v39
	}
	return v39
end
function v_u_31.eyes() -- name: eyes
	-- upvalues: (copy) v_u_40
	local v41 = {}
	for v42, v43 in v_u_40("Eyes") do
		if type(v43) ~= "number" then
			continue
		end
		v41[v42] = v43
	end
	return v41
end
function v_u_31.pets() -- name: pets
	-- upvalues: (copy) v_u_40
	local v44 = {}
	for v45, v46 in v_u_40("Pets") do
		if type(v46) ~= "string" then
			continue
		end
		v44[v45] = v46
	end
	return v44
end
function v_u_31.petTiers() -- name: petTiers
	-- upvalues: (copy) v_u_40
	local v47 = {}
	for v48, v49 in v_u_40("PetTiers") do
		if type(v49) ~= "number" then
			continue
		end
		v47[v48] = v49
	end
	return v47
end
function v_u_31.petTier(p50) -- name: petTier
	-- upvalues: (copy) v_u_7, (copy) v_u_31
	return v_u_7.tierOf(v_u_31.petTiers(), p50)
end
function v_u_31.fuseCredits() -- name: fuseCredits
	-- upvalues: (copy) v_u_7, (copy) v_u_40
	return v_u_7.cleanCredits((v_u_40("FuseCredits")))
end
function v_u_31.petMult(p51) -- name: petMult
	-- upvalues: (copy) v_u_7, (copy) v_u_31
	return v_u_7.multOf(v_u_31.pets(), v_u_31.petTiers(), p51, v_u_31.number("World", 1))
end
function v_u_31.lockedPets() -- name: lockedPets
	-- upvalues: (copy) v_u_40
	local v52 = {}
	for v53, v54 in v_u_40("LockedPets") do
		if v54 ~= true then
			continue
		end
		v52[v53] = true
	end
	return v52
end
function v_u_31.autoDelete() -- name: autoDelete
	-- upvalues: (copy) v_u_8, (copy) v_u_40
	return v_u_8.cleanAutoDeletePets((v_u_40("AutoDeletePets")))
end
function v_u_31.equipped() -- name: equipped
	-- upvalues: (copy) v_u_31, (copy) v_u_1
	local v55 = {}
	local v_u_56 = v_u_31.string("Equipped", "[]")
	local function v57()
		-- upvalues: (ref) v_u_1, (copy) v_u_56
		return v_u_1:JSONDecode(v_u_56)
	end
	local v58, v59 = pcall(v57)
	if v58 and type(v59) == "table" then
		for _, v60 in v59 do
			if type(v60) ~= "string" then
				continue
			end
			table.insert(v55, v60)
		end
	end
	return v55
end
function v_u_31.counter(p61) -- name: counter
	-- upvalues: (copy) v_u_31
	if p61 == "kills" then
		return v_u_31.number("Kills")
	elseif p61 == "stages" then
		return v_u_31.number("StagesCleared")
	elseif p61 == "hatch" then
		return v_u_31.number("Hatched")
	elseif p61 == "minutes" then
		local v62 = v_u_31.number("PlayTime") / 60
		return math.floor(v62)
	elseif p61 == "rebirths" then
		return v_u_31.number("Rebirths")
	else
		return v_u_31.number("Clicks")
	end
end
function v_u_31.quests(p63) -- name: quests
	-- upvalues: (copy) v_u_40, (copy) v_u_9, (copy) v_u_31
	local v64 = v_u_40(p63 == "weekly" and "QuestWeekly" or "QuestDaily")
	local v65 = v64.base
	local v66 = type(v65) ~= "table" and {} or v65
	local v67 = v64.claimed
	local v68 = type(v67) ~= "table" and {} or v67
	local v69 = v64.starts
	local v70 = type(v69) ~= "table" and {} or v69
	local v71 = v64.quests
	local v72 = {}
	for v73, v74 in type(v71) ~= "table" and {} or v64.quests do
		local v75
		if type(v74) == "string" then
			v75 = v_u_9.byId[v74]
		else
			v75 = nil
		end
		if not v75 then
			continue
		end
		local v76 = v70[tostring(v73)]
		if type(v76) ~= "number" then
			v76 = v66[v75.kind]
		end
		local v77 = v_u_31.counter(v75.kind) - (type(v76) ~= "number" and 0 or v76)
		local v78 = {
			["quest"] = v75,
			["slot"] = v73
		}
		local v79 = v75.goal
		v78.have = math.clamp(v77, 0, v79)
		v78.done = v75.goal <= v77
		v78.claimed = v68[tostring(v73)] == true
		table.insert(v72, v78)
	end
	return v72
end
function v_u_31.questRefreshes(p80) -- name: questRefreshes
	-- upvalues: (copy) v_u_40
	local v81 = v_u_40(p80 == "weekly" and "QuestWeekly" or "QuestDaily").refreshes
	return type(v81) ~= "number" and 0 or v81
end
function v_u_31.questsOpen(p82) -- name: questsOpen
	-- upvalues: (copy) v_u_31
	local v83 = 0
	for _, v84 in v_u_31.quests(p82) do
		if v84.done or v84.claimed then
			continue
		end
		v83 = v83 + 1
	end
	return v83
end
function v_u_31.questsReady() -- name: questsReady
	-- upvalues: (copy) v_u_31
	local v85 = 0
	for _, v86 in { "daily", "weekly" } do
		for _, v87 in v_u_31.quests(v86) do
			if not v87.done or v87.claimed then
				continue
			end
			v85 = v85 + 1
		end
	end
	return v85
end
v_u_31.QUEST_FIELDS = {
	"Kills",
	"StagesCleared",
	"Hatched",
	"PlayTime",
	"Rebirths",
	"Clicks",
	"QuestDaily",
	"QuestWeekly"
}
function v_u_31.daily() -- name: daily
	-- upvalues: (copy) v_u_6, (copy) v_u_31, (copy) v_u_5
	local v88 = v_u_6.view(v_u_31.number("DailyStreak"), v_u_31.number("DailyLast", -1), v_u_31.number("DailyWeek"), v_u_31.number("Today", -2), v_u_5.DAYS)
	return v88.next, v88.claimed, v88.week
end
function v_u_31.boostLeft(p89) -- name: boostLeft
	-- upvalues: (copy) v_u_40
	local v90 = v_u_40("Boosts")[p89]
	if type(v90) ~= "number" then
		return 0
	end
	local v91 = v90 - DateTime.now().UnixTimestamp
	return math.max(0, v91)
end
function v_u_31.offline() -- name: offline
	-- upvalues: (copy) v_u_40
	local v92 = v_u_40("Offline")
	local v93 = v92.seconds
	local v94 = v92.chakra
	local v95 = v92.levels
	return type(v93) == "number" and (type(v94) == "number" and type(v95) == "number") and {
		["seconds"] = v93,
		["chakra"] = v94,
		["levels"] = v95
	} or nil
end
function v_u_31.freeEggs(p96) -- name: freeEggs
	-- upvalues: (copy) v_u_40
	local v97 = v_u_40("FreeEggs")[p96]
	return type(v97) ~= "number" and 0 or v97
end
function v_u_31.ownedAuras() -- name: ownedAuras
	-- upvalues: (copy) v_u_40
	local v98 = {}
	for v99, v100 in v_u_40("OwnedAuras") do
		if v100 ~= true then
			continue
		end
		v98[v99] = true
	end
	return v98
end
function v_u_31.gift(p101) -- name: gift
	-- upvalues: (copy) v_u_10, (copy) v_u_31, (copy) v_u_4
	local v102 = v_u_10[p101]
	local v103 = string.split(v_u_31.string("RewardsClaimed", ""), ",")[p101]
	local v104 = tonumber(v103) or 0
	local v105 = v_u_31.number("JoinedAt", v_u_4:GetServerTimeNow())
	local v106 = v_u_4:GetServerTimeNow() - v105
	local v107 = v102.minutes * 60
	local v108 = v102.max
	local v109 = v106 / v107
	local v110 = math.floor(v109)
	local v111 = math.min(v108, v110)
	local v112 = v102.max <= v111 and 0 or v107 - v106 % v107
	local v113 = v111 - v104
	return v104, math.max(0, v113), v112
end
function v_u_31.giftsReady() -- name: giftsReady
	-- upvalues: (copy) v_u_10, (copy) v_u_31
	local v114 = 0
	for v115 in v_u_10 do
		local _, v116 = v_u_31.gift(v115)
		v114 = v114 + v116
	end
	return v114
end
function v_u_31.inMode(p117) -- name: inMode
	-- upvalues: (copy) v_u_12
	local v118 = (p117 or v_u_12):GetAttribute("ModeUntil")
	local v119
	if type(v118) == "number" then
		v119 = workspace:GetServerTimeNow() < v118
	else
		v119 = false
	end
	return v119
end
return v_u_31