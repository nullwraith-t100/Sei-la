local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(255, 110, 120)
local v_u_5 = Enum.Material.SmoothPlastic
local v_u_6 = CFrame.Angles(1.5707963267948966, 0, 0)
return function(p_u_7)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6
	return {
		["w5_crimson_vortex"] = function(p_u_8, p9)
			-- upvalues: (ref) v_u_2, (copy) p_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6
			local v_u_10 = v_u_2.color(p9.color)
			local v11 = v_u_2.color(p9.color2)
			local v12 = p_u_8.headY / 1.5
			local v_u_13 = math.clamp(v12, 0.7, 3)
			local v_u_15 = p_u_7.throb(p_u_8, 4, 1.6, 1.2, function(p14)
				-- upvalues: (ref) v_u_2, (ref) p_u_7, (copy) p_u_8, (copy) v_u_10, (ref) v_u_3
				v_u_2.ring(p_u_7.feetAt(p_u_8, p14, 0.15), v_u_10, 5.5 * p_u_8.fx, 0.55, v_u_3.Ring)
			end)
			local v_u_16 = 0
			local v_u_17 = 0
			local v_u_18 = 1
			local v19 = p_u_8.ticks
			local function v23(_, _, p20)
				-- upvalues: (copy) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18
				local v21 = v_u_15()
				v_u_16 = v_u_16 + p20 * (1.1 + v21 * 6.5)
				v_u_17 = v_u_17 + p20 * (1.6 + v21 * 9)
				local v22 = math.min(v21, 1) * 3.141592653589793 * 0.5
				v_u_18 = math.sin(v22) * 0.28 + 1
			end
			table.insert(v19, v23)
			local v_u_25 = p_u_7.group(p_u_8, function(p24)
				-- upvalues: (copy) v_u_13
				return p24 * CFrame.new(0, v_u_13 * -0.3, 0) * CFrame.Angles(0.2, 0, 0.12)
			end)
			local v_u_26 = v_u_17
			local v_u_27 = v_u_16
			local v_u_28 = v_u_18
			local v_u_29 = {}
			for v_u_30 = 0, 2 do
				local v31 = nil
				for v32 = 1, 6 do
					local v_u_33 = (v32 - 1) / 5
					local v34 = p_u_7.ball
					local v35 = (0.5 - v_u_33 * 0.24) * v_u_13
					local v36
					if v32 == 1 then
						v36 = v_u_4
					else
						v36 = v_u_10
					end
					local v37 = v34(v35, v36, v_u_33 * 0.45 + 0.08)
					p_u_7.add(p_u_8, v37, function()
						-- upvalues: (ref) v_u_27, (copy) v_u_30, (copy) v_u_33, (copy) v_u_13, (ref) v_u_28, (copy) v_u_25
						local v38 = v_u_27 + v_u_30 * 3.141592653589793 * 2 / 3 - v_u_33 * 2.4
						local v39 = (v_u_33 * 1.9 + 1.5) * v_u_13 * v_u_28
						local v40 = math.cos(v38)
						local v41 = math.sin(v38)
						local v42 = Vector3.new(v40, 0, v41) * 1.9 * v_u_13 * v_u_28
						local v43 = math.sin(v38)
						local v44 = -math.cos(v38)
						local v45 = v42 + Vector3.new(v43, 0, v44) * v39 * 2.4
						local v46 = v_u_25.cf
						local v47 = CFrame.fromMatrix
						local v48 = math.cos(v38) * v39
						local v49 = math.sin(v38) * v39
						return v46 * v47(Vector3.new(v48, 0, v49), v45.Unit, Vector3.new(0, 1, 0))
					end)
					if v32 == 1 then
						v31 = v37
					else
						if v32 ~= 6 then
							continue
						end
						p_u_7.tail(v37, v_u_10, v11, v_u_13 * 0.3, 0.4)
						if not v31 then
							continue
						end
						local v50 = Instance.new("Attachment")
						v50.Parent = v31
						local v51 = Instance.new("Attachment")
						v51.Parent = v37
						local v52 = p_u_7.ray(v50, v51, v_u_10, v_u_13 * 1, v_u_13 * 0.22, v_u_3.Beam)
						v52.Color = ColorSequence.new(v_u_4, v_u_10)
						v52.Transparency = NumberSequence.new(0, 0.5)
						v52.LightEmission = 0.25
						v52.Segments = 16
						v52.CurveSize0 = v_u_13 * 2.3
						v52.CurveSize1 = v_u_13 * 2.3
						table.insert(v_u_29, v52)
					end
				end
			end
			local v_u_53 = 1
			local v54 = p_u_8.ticks
			local function v57()
				-- upvalues: (ref) v_u_28, (ref) v_u_53, (copy) v_u_29, (copy) v_u_13
				local v55 = v_u_28 - v_u_53
				if math.abs(v55) >= 0.005 then
					v_u_53 = v_u_28
					for _, v56 in v_u_29 do
						v56.CurveSize0 = v_u_13 * 2.3 * v_u_28
						v56.CurveSize1 = v_u_13 * 2.3 * v_u_28
					end
				end
			end
			table.insert(v54, v57)
			local v_u_63 = p_u_7.group(p_u_8, function(p58, p59)
				-- upvalues: (copy) p_u_8, (copy) v_u_13
				local v60 = CFrame.new
				local v61 = p_u_8.headY + v_u_13 * 0.1
				local v62 = p59 * 1.4
				return p58 * v60(0, v61 + math.sin(v62) * 0.06 * v_u_13, v_u_13 * 0.9)
			end)
			local v64 = p_u_7.disc
			local v65 = v_u_13 * 0.06
			local v66 = v_u_13 * 2.6
			local v67 = v_u_13 * 2.6
			local v68 = v64(Vector3.new(v65, v66, v67), v11, 0.12, v_u_5)
			p_u_7.pin(p_u_8, v_u_63, v68, CFrame.Angles(0, 1.5707963267948966, 0))
			p_u_7.fadeFromBehind(p_u_8, v68, 0.45)
			local v_u_69 = p_u_7.picture(v_u_13 * 3.1, v_u_3.CrimsonGalaxy, v_u_10, 0)
			p_u_7.add(p_u_8, v_u_69, function()
				-- upvalues: (copy) v_u_63, (copy) v_u_13, (ref) v_u_26, (ref) v_u_6
				return v_u_63.cf * CFrame.new(0, 0, v_u_13 * 0.06) * CFrame.Angles(0, 0, -v_u_26) * v_u_6
			end)
			p_u_7.pin(p_u_8, v_u_63, p_u_7.picture(v_u_13 * 3.4, v_u_3.Ring, v_u_10, 0.1), CFrame.new(0, 0, v_u_13 * 0.05) * v_u_6)
			local v_u_70 = -1
			local v71 = p_u_8.ticks
			local function v74()
				-- upvalues: (copy) v_u_15, (ref) v_u_70, (copy) v_u_13, (copy) v_u_69
				local v72 = v_u_15()
				if v72 ~= v_u_70 then
					v_u_70 = v72
					local v73 = v_u_13 * 3.1 * (1 + 0.3 * v72)
					v_u_69.Size = Vector3.new(v73, 0.05, v73)
				end
			end
			table.insert(v71, v74)
			p_u_7.particles(p_u_8, "AuraMode", v_u_10, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_7.particles(p_u_8, "Petals", v_u_10, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end