local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v3.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("33A7FF")
local v_u_8 = Color3.fromHex("DDF4FF")
local v_u_9 = Color3.fromRGB(25, 80, 230)
local v_u_10 = Color3.fromRGB(150, 220, 255)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Ball
local function v_u_19(p13, p14, p15, p16) -- name: egg
	-- upvalues: (copy) v_u_4
	local v17 = v_u_4.part(p13, p14, p15, {
		["transparency"] = p16
	})
	local v18 = Instance.new("SpecialMesh")
	v18.MeshType = Enum.MeshType.Sphere
	v18.Parent = v17
	return v17
end
local function v_u_31(p20, p21, p22, p23, p24) -- name: picture
	-- upvalues: (copy) v_u_4
	local v25 = v_u_4.part
	local v26 = p21 * 2
	local v27 = p21 * 2
	local v28 = v25(Vector3.new(v26, 0.05, v27), p20, p23, {
		["transparency"] = 1
	})
	for _, v29 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v30 = Instance.new("Decal")
		v30.Face = v29
		v30.Texture = p22
		v30.Color3 = p23
		v30.Transparency = p24
		v30.Parent = v28
	end
	return v28
end
local function v_u_35(p32, p33) -- name: fadeDecals
	for _, v34 in p32:GetChildren() do
		if not v34:IsA("Decal") then
			continue
		end
		v34.Transparency = p33
	end
end
local function v_u_54(p36, p37, p38, p39, p40, p41, p42) -- name: newCrystal
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_1, (copy) v_u_19, (copy) v_u_7, (copy) v_u_11
	local v43 = p37.X
	local v44 = p37.Z
	local v45 = Vector3.new(v43, 0, v44)
	local v46 = (v45.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v45.Unit):Cross(Vector3.new(0, 1, 0))
	local v47 = CFrame.fromAxisAngle(v46.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v46.Unit, -p38) * CFrame.Angles(0, 0.7853981633974483 + math.random() * 0.4, 0)
	local v48 = CFrame.new(p36)
	local v49 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v48, Color3.fromRGB(175, 228, 255), {
		["material"] = nil,
		["transparency"] = 0.4,
		["material"] = Enum.Material.Neon
	})
	local v50 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v48, v_u_10, {
		["transparency"] = 0.1
	})
	v_u_1:AddItem(v49, p42)
	v_u_1:AddItem(v50, p42)
	local v51 = {
		["shaft"] = nil,
		["point"] = nil,
		["fire"] = nil,
		["heart"] = nil,
		["base"] = nil,
		["tilt"] = nil,
		["h"] = nil,
		["w"] = nil,
		["phase"] = nil,
		["shaft"] = v49,
		["point"] = v50,
		["base"] = p36,
		["tilt"] = v47,
		["h"] = p39,
		["w"] = p40,
		["phase"] = math.random() * 6
	}
	if p41 then
		local v52 = v_u_19(Vector3.new(0.1, 0.1, 0.1), v48, v_u_7, 0.2)
		local v53 = v_u_19(Vector3.new(0.1, 0.1, 0.1), v48, v_u_11, 0.15)
		v_u_1:AddItem(v52, p42)
		v_u_1:AddItem(v53, p42)
		v51.fire = v52
		v51.heart = v53
	end
	return v51
end
local function v_u_83(p55, p56, p57, p58) -- name: placeCrystal
	local v59 = math.max(p56, 0.02)
	local v60 = p55.h * v59
	local v61 = p55.w * math.max(v59, 0.3)
	local v62 = CFrame.new(p55.base) * p55.tilt
	local v63 = p55.shaft
	local v64 = v60 * 0.68
	v63.Size = Vector3.new(v61, v64, v61)
	p55.shaft.CFrame = v62 * CFrame.new(0, v60 * 0.34, 0)
	local v65 = p55.point
	local v66 = v61 * 0.55
	local v67 = v60 * 0.42
	local v68 = v61 * 0.55
	v65.Size = Vector3.new(v66, v67, v68)
	p55.point.CFrame = v62 * CFrame.new(0, v60 * 0.68 + v60 * 0.19, 0)
	local v69 = p55.fire
	local v70 = p55.heart
	if v69 and v70 then
		local v71 = p58 * 17 + p55.phase
		local v72 = math.sin(v71) * 0.18 + 1
		local v73 = p58 * 29 + p55.phase * 2
		local v74 = v72 + math.sin(v73) * 0.1
		local v75 = (p55.w * 0.9 + 1.1) * v59 * p57 * v74
		local v76 = (v62 * CFrame.new(0, v60 * 0.9, 0)).Position
		local v77 = p55.w * 1.1 * v59 * p57
		local v78 = v75 * 1.6
		local v79 = p55.w * 1.1 * v59 * p57
		v69.Size = Vector3.new(v77, v78, v79)
		v69.CFrame = CFrame.new(v76 + Vector3.new(0, 1, 0) * v75 * 0.55)
		local v80 = p55.w * 0.45 * v59 * p57
		local v81 = v75 * 0.8
		local v82 = p55.w * 0.45 * v59 * p57
		v70.Size = Vector3.new(v80, v81, v82)
		v70.CFrame = CFrame.new(v76 + Vector3.new(0, 1, 0) * v75 * 0.3)
	end
end
return function(p_u_84)
	-- upvalues: (copy) v_u_31, (copy) v_u_1, (copy) v_u_35, (copy) v_u_54, (copy) v_u_83, (copy) v_u_4, (copy) v_u_7, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9, (copy) v_u_19, (copy) v_u_10, (copy) v_u_6, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5
	local function v_u_102(p_u_85, p_u_86, p_u_87, p88, p89, p_u_90, p_u_91, p92) -- name: flare
		-- upvalues: (ref) v_u_31, (ref) v_u_1, (copy) p_u_84, (ref) v_u_35
		local v_u_93 = p92 or 0
		local v_u_94 = v_u_31(p_u_85, p_u_86, p88, p89, v_u_93)
		v_u_1:AddItem(v_u_94, p_u_90 + 0.1)
		p_u_84.animate(p_u_90, 0, function(p95)
			-- upvalues: (copy) p_u_86, (copy) p_u_87, (copy) v_u_94, (copy) p_u_85, (copy) p_u_90, (copy) p_u_91, (ref) v_u_35, (copy) v_u_93
			local v96 = 1 - (1 - p95) ^ 3
			local v97 = p_u_86 + (p_u_87 - p_u_86) * v96
			local v98 = math.max(v97, 0.05)
			local v99 = v_u_94
			local v100 = v98 * 2
			local v101 = v98 * 2
			v99.Size = Vector3.new(v100, 0.05, v101)
			v_u_94.CFrame = p_u_85 * CFrame.Angles(0, p95 * p_u_90 * p_u_91, 0)
			v_u_35(v_u_94, v_u_93 + (1 - v_u_93) * p95 ^ 1.5)
			if p95 >= 1 then
				v_u_94:Destroy()
			end
		end)
	end
	local function v_u_128(p103, p104, p105, p106, p_u_107, p108) -- name: crystalBurst
		-- upvalues: (copy) p_u_84, (ref) v_u_54, (ref) v_u_83
		local v109 = p_u_84.ground(p103, 0)
		local v110 = math.random() * 3.141592653589793 * 2
		local v_u_111 = {}
		for v112 = 1, p104 do
			local v113 = v110 + v112 / p104 * 3.141592653589793 * 2
			local v114 = math.cos(v113)
			local v115 = math.sin(v113)
			local v116 = Vector3.new(v114, 0, v115)
			local v117 = v_u_54(v109 + v116 * (p105 * (0.25 + math.random() * 0.75)), v116, 0.25 + math.random() * 0.35, p106 * (0.6 + math.random() * 0.5), p106 * 0.22, p108, p_u_107 + 1)
			table.insert(v_u_111, v117)
		end
		local v_u_118 = os.clock()
		p_u_84.runNow(function()
			-- upvalues: (copy) v_u_118, (copy) p_u_107, (copy) v_u_111, (ref) v_u_83
			local v119 = os.clock() - v_u_118
			local v120 = v119 / 0.09
			local v121 = 1 - (1 - math.clamp(v120, 0, 1)) ^ 3
			local v122 = (v119 - p_u_107) / 0.25
			local v123 = math.clamp(v122, 0, 1)
			for _, v124 in v_u_111 do
				v_u_83(v124, v121 * (1 - v123 * 0.4), 1 - v123, v119)
				v124.shaft.Transparency = v123 * 0.6 + 0.4
				v124.point.Transparency = v123 * 0.9 + 0.1
			end
			if v123 < 1 then
				return true
			end
			for _, v125 in v_u_111 do
				v125.shaft:Destroy()
				v125.point:Destroy()
				local v126 = v125.fire
				local v127 = v125.heart
				if v126 then
					v126:Destroy()
				end
				if not v127 then
					continue
				end
				v127:Destroy()
			end
			return false
		end)
	end
	local function v150(p129, p130) -- name: emberShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_9, (ref) v_u_19, (ref) v_u_10, (copy) p_u_84
		local v131 = p129.size
		local v132 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p130, v_u_7, {
			["transparency"] = 1
		})
		local v133 = {
			["shape"] = v_u_12
		}
		local v134 = v_u_4.part(Vector3.new(0.75, 0.75, 0.75) * v131, p130, v_u_11, v133)
		local v135 = {
			["shape"] = nil,
			["transparency"] = 0.2,
			["shape"] = v_u_12
		}
		local v136 = v_u_4.part(Vector3.new(1.5, 1.5, 1.5) * v131, p130, v_u_7, v135)
		local v137 = {
			["shape"] = nil,
			["transparency"] = 0.68,
			["shape"] = v_u_12
		}
		local v138 = v_u_4.part(Vector3.new(2.1, 2.1, 2.1) * v131, p130, v_u_9, v137)
		local v139 = {
			{
				["p"] = v134,
				["off"] = CFrame.identity
			},
			{
				["p"] = v136,
				["off"] = CFrame.identity
			},
			{
				["p"] = v138,
				["off"] = CFrame.identity
			}
		}
		for v140 = 1, 3 do
			local v141 = v140 / 3 * 3.141592653589793 * 2
			local v142 = v_u_19
			local v143 = Vector3.new(0.6, 0.6, 1.9) * v131
			local v144
			if v140 == 1 then
				v144 = v_u_10
			else
				v144 = v_u_7
			end
			local v145 = {
				["p"] = v142(v143, p130, v144, 0.25),
				["off"] = CFrame.new(math.cos(v141) * 0.35 * v131, math.sin(v141) * 0.35 * v131, 1.05 * v131)
			}
			table.insert(v139, v145)
		end
		local v146 = {}
		p_u_84.streak(v132, v_u_7, v_u_9, 1.4 * v131, 0.18)
		if not p129.lite then
			local v147 = p_u_84.loop
			local v148 = v_u_7
			local v149 = 0.45 * v131
			table.insert(v146, v147("Trail", v134, v148, v149))
		end
		if p129.mine then
			p_u_84.light(v132, v_u_7, 10 * v131)
		end
		return p_u_84.assemble(v132, v139, {}, 0, 0, v146, 0.18, 9)
	end
	local function v154(p151, p152) -- name: emberImpact
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_84, (ref) v_u_11, (ref) v_u_10, (ref) v_u_6, (copy) v_u_128
		local v153 = p151.size
		v_u_4.flash(p152, v_u_7, 5 * v153, 0.16)
		p_u_84.pop(p152, v_u_7, 1.6 * v153, 6 * v153, 0.18, 0.3)
		p_u_84.pop(p152, v_u_11, 1.2 * v153, 0.3 * v153, 0.1)
		v_u_4.ring(p_u_84.ground(p152), v_u_10, p151.ability.radius * 0.8 * v153, 0.25, v_u_6.Ring)
		if not p151.lite then
			v_u_128(p152, 4, 1.6 * v153, 2.6 * v153, 0.35, false)
			p_u_84.burst("Fire", p_u_84.ground(p152), v_u_7, 0.4)
		end
		p_u_84.mark(p152, v_u_10, 2.4 * v153, 1, v_u_6.CrackGlow, 0.2)
		p_u_84.hitSound(p152)
	end
	local function v_u_164(p155, p156, p157, p158) -- name: snowfall
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1
		local v159 = v_u_4.part
		local v160 = p156 * 2
		local v161 = p156 * 2
		local v_u_162 = v159(Vector3.new(v160, 0.2, v161), CFrame.new(p155), v_u_11, {
			["transparency"] = 1
		})
		local v_u_163 = Instance.new("ParticleEmitter")
		v_u_163.Texture = v_u_6.Snowflake
		v_u_163.EmissionDirection = Enum.NormalId.Bottom
		v_u_163.Color = ColorSequence.new(v_u_8)
		v_u_163.LightEmission = 0.5
		v_u_163.LightInfluence = 0
		v_u_163.Lifetime = NumberRange.new(1.2, 1.8)
		v_u_163.Speed = NumberRange.new(3, 5)
		v_u_163.SpreadAngle = Vector2.new(15, 15)
		v_u_163.Rotation = NumberRange.new(0, 360)
		v_u_163.RotSpeed = NumberRange.new(-90, 90)
		v_u_163.Size = NumberSequence.new(0.35, 0.2)
		v_u_163.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.15, 0.1), NumberSequenceKeypoint.new(1, 1) })
		v_u_163.Rate = p157
		v_u_163.Parent = v_u_162
		v_u_1:AddItem(v_u_162, p158 + 2)
		return function()
			-- upvalues: (copy) v_u_163, (ref) v_u_1, (copy) v_u_162
			v_u_163.Enabled = false
			v_u_1:AddItem(v_u_162, 1.9)
		end
	end
	local function v227(p165, p_u_166, p_u_167) -- name: coldFire
		-- upvalues: (copy) p_u_84, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_31, (ref) v_u_54, (copy) v_u_164, (ref) v_u_35, (ref) v_u_83
		local v_u_168 = p165.size
		local v_u_169 = p165.ability.radius * v_u_168
		local v_u_170 = p165.lite
		local v_u_171 = p_u_84.ground(p_u_166, 0)
		local v_u_172 = p_u_167 + 2
		v_u_4.flash(p_u_84.ground(p_u_166, 2), v_u_7, 8 * v_u_168, 0.15)
		v_u_4.ring(v_u_171, v_u_10, v_u_169 * 1.3, 0.35, v_u_6.Shockwave)
		p_u_84.burst("Impact", p_u_84.ground(p_u_166, 1.5), v_u_7, 1.3)
		local v_u_173 = p_u_84.plate(p_u_84.ground(p_u_166, 0.07), 1, v_u_8, 0.35, Enum.Material.SmoothPlastic)
		v_u_173.Reflectance = 0.3
		v_u_1:AddItem(v_u_173, v_u_172)
		local v_u_174 = v_u_31(CFrame.new(p_u_84.ground(p_u_166, 0.16)), 0.5, v_u_6.CrackLines, v_u_7, 0.15)
		v_u_1:AddItem(v_u_174, v_u_172)
		p_u_84.mark(p_u_166, v_u_7, v_u_169 * 0.9, p_u_167, v_u_6.CrackGlow, 0.35)
		local v175 = v_u_170 and 4 or 8
		local v176 = math.random() * 3.141592653589793 * 2
		local v_u_177 = {}
		for v178 = 1, v175 do
			local v179 = v176 + v178 / v175 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.5
			local v180 = math.cos(v179)
			local v181 = math.sin(v179)
			local v182 = Vector3.new(v180, 0, v181)
			local v183 = v_u_54(v_u_171 + v182 * (v_u_169 * (v178 % 2 == 0 and 0.35 or 0.75) * (0.85 + math.random() * 0.3)), v182, 0.12 + math.random() * 0.25, (2.6 + math.random() * 1.8) * v_u_168, (0.9 + math.random() * 0.4) * v_u_168, true, v_u_172)
			table.insert(v_u_177, v183)
		end
		local v_u_184 = {}
		local v185 = p_u_84.loopAt
		local v186 = v_u_7
		table.insert(v_u_184, v185("Fire", v_u_171, v186, v_u_170 and 1.2 or 0.9))
		if not v_u_170 then
			for v187 = 1, 2 do
				local v188 = v176 + v187 * 3.141592653589793
				local v189 = math.cos(v188)
				local v190 = math.sin(v188)
				local v191 = v_u_171 + Vector3.new(v189, 0, v190) * v_u_169 * 0.55
				local v192 = p_u_84.loopAt
				local v193 = v_u_7
				table.insert(v_u_184, v192("Fire", v191, v193, 0.7))
			end
		end
		local v194 = v_u_164(p_u_84.ground(p_u_166, 8), v_u_169 * 0.9, v_u_170 and 5 or 14, v_u_172)
		table.insert(v_u_184, v194)
		local v_u_195 = os.clock()
		local v_u_196 = -10
		local v_u_197 = nil
		p_u_84.runNow(function()
			-- upvalues: (copy) v_u_195, (ref) v_u_197, (copy) v_u_169, (copy) v_u_173, (copy) v_u_174, (ref) v_u_35, (ref) v_u_196, (copy) v_u_177, (copy) v_u_171, (ref) v_u_83, (copy) v_u_172
			local v198 = os.clock()
			local v199 = v198 - v_u_195
			local v200 = v199 / 0.35
			local v201 = 1 - (1 - math.clamp(v200, 0, 1)) ^ 2
			local v202
			if v_u_197 then
				local v203 = (v198 - v_u_197) / 0.25
				v202 = math.clamp(v203, 0, 1)
			else
				v202 = 0
			end
			local v204 = v_u_169 * v201
			local v205 = math.max(v204, 0.5)
			local v206 = v_u_173
			local v207 = v205 * 2
			local v208 = v205 * 2
			v206.Size = Vector3.new(0.12, v207, v208)
			v_u_173.Transparency = v202 * 0.65 + 0.35
			local v209 = v_u_174
			local v210 = v205 * 1.9
			local v211 = v205 * 1.9
			v209.Size = Vector3.new(v210, 0.05, v211)
			v_u_35(v_u_174, v202 * 0.85 + 0.15)
			local v212 = 1 - (v198 - v_u_196) / 0.3
			local v213 = math.max(v212, 0) * 0.45 + 1
			for v214, v215 in v_u_177 do
				local v216 = v_u_169
				local v217 = (v199 - (v215.base - v_u_171).Magnitude / math.max(v216, 1) * 0.3) / 0.22
				v_u_83(v215, (1 - (1 - math.clamp(v217, 0, 1)) ^ 3) * (1 - v202 * 0.5), v213 * (1 - v202), v199 + v214)
				v215.shaft.Transparency = v202 * 0.6 + 0.4
				v215.point.Transparency = v202 * 0.9 + 0.1
			end
			if v202 < 1 then
				return v199 < v_u_172
			end
			v_u_173:Destroy()
			v_u_174:Destroy()
			for _, v218 in v_u_177 do
				v218.shaft:Destroy()
				v218.point:Destroy()
				local v219 = v218.fire
				local v220 = v218.heart
				if v219 then
					v219:Destroy()
				end
				if not v220 then
					continue
				end
				v220:Destroy()
			end
			return false
		end)
		local v_u_221 = true
		local v_u_222 = p165.ability.tick or 0.5
		task.spawn(function()
			-- upvalues: (copy) v_u_222, (ref) v_u_221, (copy) v_u_195, (copy) p_u_167, (ref) v_u_196, (ref) v_u_4, (ref) p_u_84, (copy) p_u_166, (ref) v_u_10, (copy) v_u_169, (ref) v_u_6, (copy) v_u_170, (copy) v_u_177, (ref) v_u_8
			task.wait(v_u_222 * 0.5)
			while v_u_221 and os.clock() - v_u_195 < p_u_167 + 0.3 do
				v_u_196 = os.clock()
				v_u_4.ring(p_u_84.ground(p_u_166), v_u_10, v_u_169 * 1.05, 0.4, v_u_6.Ring)
				if not v_u_170 then
					local v223 = v_u_177[math.random(1, #v_u_177)]
					p_u_84.glint((CFrame.new(v223.base) * v223.tilt * CFrame.new(0, v223.h, 0)).Position, v_u_8, 2.5, 0.18)
				end
				task.wait(v_u_222)
			end
		end)
		return function()
			-- upvalues: (ref) v_u_221, (ref) v_u_197, (copy) v_u_184, (copy) v_u_170, (copy) v_u_177, (ref) p_u_84, (ref) v_u_8, (ref) v_u_10, (copy) v_u_168, (copy) p_u_166
			v_u_221 = false
			v_u_197 = os.clock()
			for _, v224 in v_u_184 do
				v224()
			end
			if not v_u_170 then
				for _, v225 in v_u_177 do
					local v226 = { v_u_8, v_u_10 }
					p_u_84.chunks(v225.base + Vector3.new(0, 1, 0) * v225.h * 0.5, v226, 2, 22, 0.45 * v_u_168, 0.6, true, 0.7)
				end
			end
			p_u_84.burst("Impact", p_u_84.ground(p_u_166, 1), v_u_10, 1.2)
		end
	end
	local v_u_228 = {}
	setmetatable(v_u_228, {
		["__mode"] = "k"
	})
	local function v_u_280(p_u_229, p230, p_u_231) -- name: startTornado
		-- upvalues: (copy) p_u_84, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_6, (ref) v_u_9, (ref) v_u_10
		local v_u_232 = p_u_229.size
		local v233 = p_u_84.ground(p230, 0)
		local v_u_234 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v233), v_u_7, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_234, p_u_231 + 3)
		local v235 = p_u_229.lite and 3 or 6
		local v_u_236 = {}
		for v237 = 1, v235 do
			local v238 = {}
			local v239 = {}
			for v240 = 1, 5 do
				local v241 = Instance.new("Attachment")
				v241.Parent = v_u_234
				v238[v240] = v241
				if v240 <= 1 then
					continue
				end
				local v242 = Instance.new("Beam")
				v242.Attachment0 = v238[v240 - 1]
				v242.Attachment1 = v241
				v242.Texture = v_u_6.FireBeam
				v242.TextureMode = Enum.TextureMode.Wrap
				v242.TextureLength = 7
				v242.TextureSpeed = 3
				local v243 = ColorSequence.new
				local v244
				if v237 % 2 == 0 then
					v244 = v_u_9
				else
					v244 = v_u_7
				end
				v242.Color = v243(v244, v_u_10)
				v242.LightEmission = 0.35
				v242.LightInfluence = 0
				v242.FaceCamera = true
				v242.Segments = 8
				local v245 = (v240 - 1) / 4
				v242.Width0 = (5.6 - v245 * 2.2) * v_u_232
				v242.Width1 = (5 - v245 * 2.2) * v_u_232
				v242.Parent = v_u_234
				table.insert(v239, v242)
			end
			local v246 = {
				["points"] = v238,
				["beams"] = v239,
				["phase"] = v237 / v235 * 3.141592653589793 * 2
			}
			table.insert(v_u_236, v246)
		end
		local v_u_247 = {
			["holder"] = nil,
			["strands"] = nil,
			["center"] = nil,
			["born"] = nil,
			["span"] = nil,
			["blastAt"] = nil,
			["done"] = false,
			["holder"] = v_u_234,
			["strands"] = v_u_236,
			["center"] = v233,
			["born"] = os.clock(),
			["span"] = p_u_231
		}
		local v_u_248 = 0
		local v_u_249 = os.clock()
		p_u_84.runNow(function()
			-- upvalues: (copy) v_u_247, (copy) v_u_234, (ref) v_u_249, (copy) p_u_231, (ref) v_u_248, (copy) p_u_229, (copy) v_u_232, (copy) v_u_236
			if v_u_247.done or not v_u_234.Parent then
				return false
			end
			local v250 = os.clock()
			local v251 = v250 - v_u_247.born
			local v252 = v250 - v_u_249
			local v253 = math.min(v252, 0.05)
			v_u_249 = v250
			local v254 = p_u_231
			local v255 = v251 / math.max(v254, 0.05)
			local v256 = math.clamp(v255, 0, 1)
			local v257 = v_u_247.blastAt
			local v258
			if v257 then
				local v259 = (v250 - v257) / 0.38
				v258 = math.clamp(v259, 0, 1)
			else
				v258 = 0
			end
			v_u_248 = v_u_248 + v253 * (v256 * 12 + 7 + v258 * 10)
			local v260 = (1 - (1 - v256) ^ 2) * 0.65 + 0.35
			local v261 = p_u_229.ability.radius * v_u_232 * 0.95
			for _, v262 in v_u_236 do
				for v263, v264 in v262.points do
					local v265 = (v263 - 1) / 4
					local v266 = 26 * v_u_232 * v265 * v260 * (1 - v258 * 0.8)
					local v267 = (v265 * 7.5 + 1.4) * v_u_232 * v260
					local v268 = v267 + (v261 - v267) * v258 ^ 0.6
					local v269 = v_u_248 + v262.phase + v265 * 2.2
					local v270 = math.cos(v269) * v268
					local v271 = math.sin(v269) * v268
					local v272 = Vector3.new(v270, v266, v271)
					local v273 = -math.sin(v269)
					local v274 = math.cos(v269)
					local v275 = Vector3.new(v273, 0, v274) * v268 * 2.2 + Vector3.new(0, 26, 0) * v_u_232 * v260
					local v276 = v275.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v275.Unit
					local v277 = v276:Cross(Vector3.new(0, 1, 0))
					v264.CFrame = CFrame.fromMatrix(v272, v276, v277.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v277.Unit:Cross(v276))
				end
				local v278 = 26 * v_u_232 * v260 * (1 - v258 * 0.8) / 4
				for _, v279 in v262.beams do
					v279.CurveSize0 = v278 * 0.4
					v279.CurveSize1 = v278 * 0.4
					v279.Transparency = NumberSequence.new(v258 * 0.95 + 0.05, v258 * 0.75 + 0.25)
				end
			end
			if v258 >= 1 then
				v_u_247.done = true
				v_u_234:Destroy()
				return false
			end
			if v257 or p_u_231 + 1.2 >= v251 then
				return true
			end
			v_u_247.done = true
			v_u_234:Destroy()
			return false
		end)
		return v_u_247
	end
	local v_u_281 = 0
	local function v_u_285() -- name: frostFrame
		-- upvalues: (ref) v_u_281, (ref) v_u_2, (ref) v_u_4, (copy) p_u_84, (ref) v_u_11, (ref) v_u_1
		local v282 = os.clock()
		if v282 >= v_u_281 then
			v_u_281 = v282 + 0.8
			local v_u_283 = Instance.new("ColorCorrectionEffect")
			v_u_283.Name = "AzureInferno"
			v_u_283.Parent = v_u_2
			v_u_4.tween(v_u_283, 0.05, {
				["TintColor"] = nil,
				["Brightness"] = 0.12,
				["Contrast"] = 0.15,
				["TintColor"] = Color3.fromRGB(205, 232, 255)
			})
			p_u_84.after(0.14, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_283, (ref) v_u_11
				local v284 = {
					["TintColor"] = nil,
					["Brightness"] = 0,
					["Contrast"] = 0,
					["TintColor"] = v_u_11
				}
				v_u_4.tween(v_u_283, 0.55, v284)
			end)
			v_u_1:AddItem(v_u_283, 0.8)
		end
	end
	local function v_u_300(p286, p287) -- name: inferno
		-- upvalues: (copy) p_u_84, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11, (ref) v_u_10, (copy) v_u_128, (ref) v_u_5, (copy) v_u_285
		local v_u_288 = p286.size
		local v_u_289 = p286.ability.radius * v_u_288
		local v_u_290 = p286.lite
		local v_u_291 = p_u_84.ground(p287, 0)
		local v292 = p_u_84.ground(p287, 4)
		v_u_4.flash(v292, v_u_8, v_u_289 * 0.7, 0.14)
		p_u_84.burst("Flash", v292, v_u_7, 1, true)
		p_u_84.burst("Explosion", v292, v_u_7, 2.4)
		p_u_84.pop(v_u_291, v_u_7, 6, v_u_289 * 2.1, 0.5, 0.35)
		p_u_84.pop(v_u_291, v_u_8, 4, v_u_289 * 1.2, 0.3, 0.2)
		p_u_84.burst("Shockwave", v_u_291 + Vector3.new(0, 0.3, 0), v_u_7, 1.6)
		v_u_4.ring(v_u_291, v_u_7, v_u_289 * 1.05, 0.5, v_u_6.Shockwave)
		p_u_84.after(0.05, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_291, (ref) v_u_8, (copy) v_u_289, (ref) v_u_6
			v_u_4.ring(v_u_291, v_u_8, v_u_289 * 1.2, 0.45, v_u_6.Ring)
		end)
		p_u_84.after(0.1, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_291, (ref) v_u_11, (copy) v_u_289, (ref) v_u_6
			v_u_4.ring(v_u_291, v_u_11, v_u_289 * 1.3, 0.4, v_u_6.SpeedLines)
		end)
		p_u_84.spikes(p_u_84.ground(p287, 1), v_u_8, v_u_290 and 5 or 12, v_u_289 * 1.1, 0.4, nil, nil, true)
		p_u_84.chunks(p_u_84.ground(p287, 1), { v_u_8, v_u_10, v_u_7 }, v_u_290 and 6 or 14, 55, 1, 1.2, true, 0.8)
		local v293 = v_u_290 and 4 or 8
		local v294 = math.random() * 3.141592653589793 * 2
		for v_u_295 = 1, v293 do
			local v296 = v294 + v_u_295 / v293 * 3.141592653589793 * 2
			local v297 = math.cos(v296)
			local v298 = math.sin(v296)
			local v_u_299 = Vector3.new(v297, 0, v298)
			p_u_84.after(v_u_295 % 2 * 0.05 + 0.12, function()
				-- upvalues: (ref) p_u_84, (copy) v_u_291, (copy) v_u_299, (copy) v_u_289, (ref) v_u_7, (copy) v_u_290, (copy) v_u_295, (ref) v_u_128, (copy) v_u_288
				p_u_84.burst("Fire", v_u_291 + v_u_299 * v_u_289 * 0.85, v_u_7, 1)
				if not v_u_290 and v_u_295 % 2 == 0 then
					v_u_128(v_u_291 + v_u_299 * v_u_289 * 0.6, 2, 2.2 * v_u_288, 4.6 * v_u_288, 0.5, true)
				end
			end)
		end
		p_u_84.mark(p287, v_u_10, v_u_289 * 0.6, 2.5, v_u_6.CrackGlow, 0.15)
		p_u_84.mark(p287, v_u_7, v_u_289 * 0.45, 2, v_u_6.CrackLines, 0.2)
		v_u_5.play("Explosion", {
			["at"] = v_u_291,
			["volume"] = p286.mine and 1 or 0.6
		})
		if p286.mine then
			v_u_4.shake(0.6, 0.55)
			v_u_285()
		end
	end
	local v333 = {
		["azure_flame_a"] = {
			["cast"] = function(p301) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_84, (ref) v_u_11, (copy) v_u_102, (ref) v_u_6, (ref) v_u_8
				local v302 = p301.size
				local v303 = p301.eye + p301.dir * 1.1
				v_u_4.flash(v303, v_u_7, 3 * v302, 0.1)
				p_u_84.pop(v303, v_u_11, 1.1 * v302, 0.3 * v302, 0.1)
				if not p301.lite then
					v_u_102(p_u_84.facing(v303, p301.dir), 0.4 * v302, 2.4 * v302, v_u_6.Shockwave, v_u_7, 0.13, 0, 0.1)
					p_u_84.glint(v303, v_u_8, 2, 0.12)
				end
			end,
			["shot"] = v150,
			["impact"] = v154,
			["hit"] = function(p304, p305, _) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_7, (ref) v_u_8
				p_u_84.burst("Impact", p305, v_u_7, 0.6)
				if not p304.lite then
					p_u_84.glint(p305, v_u_8, 2.2, 0.14)
				end
			end
		},
		["azure_flame_e"] = {
			["castSound"] = "Fireball",
			["loopSound"] = "Flames",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["hit"] = nil,
			["cast"] = function(p306) -- name: cast
				-- upvalues: (copy) p_u_84, (ref) v_u_7
				p_u_84.skillCast(p306, v_u_7)
			end,
			["windup"] = function(p307, p308, p309) -- name: windup
				-- upvalues: (copy) p_u_84, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_1
				local v310 = p307.size
				local v_u_311 = p307.eye + p307.dir * 1.2
				local v_u_312 = p_u_84.ground(p308, 1)
				local v_u_313 = p_u_84.ball(v_u_311, v_u_7, 1.7 * v310, 0.15)
				local v_u_314 = p_u_84.ball(v_u_311, v_u_11, 0.8 * v310, 0)
				p_u_84.streak(v_u_313, v_u_7, v_u_9, 1.4 * v310, 0.18)
				p_u_84.animate(math.max(p309, 0.05), 0, function(p315)
					-- upvalues: (copy) v_u_311, (copy) v_u_312, (copy) v_u_313, (copy) v_u_314, (ref) v_u_1
					local v316 = v_u_311:Lerp(v_u_312, p315)
					local v317 = p315 * 3.141592653589793
					local v318 = v316 + Vector3.new(0, 1, 0) * math.sin(v317) * 4
					v_u_313.CFrame = CFrame.new(v318)
					v_u_314.CFrame = CFrame.new(v318)
					if p315 >= 1 then
						v_u_1:AddItem(v_u_313, 0.2)
						v_u_313.Transparency = 1
						v_u_314:Destroy()
					end
				end)
			end,
			["zone"] = v227,
			["hit"] = function(p319, p320, _) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_10, (copy) v_u_128
				p_u_84.burst("Impact", p320, v_u_10, 0.55)
				if not p319.lite then
					v_u_128(p320 - Vector3.new(0, 1.2, 0), 2, 0.8, 1.6, 0.25, false)
				end
			end
		},
		["azure_flame_r"] = {
			["cast"] = function(p321) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) p_u_84, (ref) v_u_7, (ref) v_u_6
				local v322 = p321.size
				local v323 = p321.feet
				v_u_4.flash(p321.eye, v_u_8, 6 * v322, 0.15)
				p_u_84.thin(p_u_84.pillar(v323, 26 * v322, 4.5 * v322, v_u_7, 0.55), 0.45, true)
				p_u_84.thin(p_u_84.pillar(v323, 22 * v322, 1.4 * v322, v_u_8, 0.35), 0.35, true)
				p_u_84.glowBeam(v323, v323 + Vector3.new(0, 30, 0) * v322, v_u_7, 8 * v322, 0.5, v_u_6.FireBeam)
				v_u_4.ring(v323, v_u_7, 10 * v322, 0.35, v_u_6.Shockwave)
				p_u_84.burst("Fire", v323, v_u_7, 1.1)
				if p321.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p324, p325, p326) -- name: windup
				-- upvalues: (copy) v_u_228, (copy) v_u_280, (copy) p_u_84, (ref) v_u_10, (ref) v_u_4
				local v327 = math.max(p326, 0.06)
				v_u_228[p324] = v_u_280(p324, p325, v327)
				if not p324.lite then
					p_u_84.inward(p_u_84.ground(p325, 3), v_u_10, 8, 14 * p324.size, v327)
				end
				if p324.mine then
					v_u_4.shake(0.2, v327 + 0.05)
				end
			end,
			["land"] = function(p328, p329) -- name: land
				-- upvalues: (copy) v_u_228, (copy) v_u_280, (copy) v_u_300
				local v330 = v_u_228[p328]
				v_u_228[p328] = nil
				if not v330 or v330.done then
					v330 = v_u_280(p328, p329, 0.05)
				end
				v330.blastAt = os.clock()
				v_u_300(p328, p329)
			end,
			["hit"] = function(p331, p332, _) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_7, (ref) v_u_8
				p_u_84.burst("Impact", p332, v_u_7, 1.1)
				if not p331.lite then
					p_u_84.glint(p332, v_u_8, 5, 0.18)
				end
			end
		}
	}
	return v333
end