local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("D3121B")
local v_u_9 = Color3.fromRGB(255, 34, 44)
local v_u_10 = Color3.fromRGB(255, 160, 150)
local v_u_11 = Color3.fromRGB(60, 0, 8)
local v_u_12 = Color3.fromHex("0A0002")
local v_u_13 = Color3.new(1, 1, 1)
local function v_u_26(p14) -- name: aimPoint
	local v15 = p14.target.X - p14.origin.X
	local v16 = p14.target.Z - p14.origin.Z
	local v17 = Vector3.new(v15, 0, v16)
	local v18 = v17.Magnitude
	local v19 = p14.ability.range
	local v20 = math.max(v19, 6)
	local v21 = math.clamp(v18, 6, v20)
	local v22
	if v17.Magnitude > 0.001 then
		v22 = v17.Unit
	else
		v22 = p14.dir
	end
	local v23 = p14.origin.X
	local v24 = p14.target.Y
	local v25 = p14.origin.Z
	return Vector3.new(v23, v24, v25) + v22 * v21
end
local function v_u_37(p27, p28, p29, p30, p31, p32) -- name: picture
	-- upvalues: (copy) v_u_5
	local v33 = v_u_5.part(Vector3.new(p28, 0.05, p29), p27, p31, {
		["transparency"] = 1
	})
	local v34 = {}
	for _, v35 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v36 = Instance.new("Decal")
		v36.Face = v35
		v36.Texture = p30
		v36.Color3 = p31
		v36.Transparency = p32
		v36.Parent = v33
		table.insert(v34, v36)
	end
	return v33, v34
end
local function v_u_45(p38, p39) -- name: toViewer
	-- upvalues: (copy) v_u_4
	local v40 = v_u_4.CurrentCamera
	local v41
	if v40 then
		local v42 = v40.CFrame.Position - p38
		v41 = v42.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v42.Unit
	else
		v41 = Vector3.new(0, 0, 1)
	end
	local v43 = v41.Y
	local v44 = math.abs(v43) > 0.98 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p38, p38 + v41, v44) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, p39, 0)
end
local v_u_46 = 0
local function v_u_51(p47) -- name: impactFrame
	-- upvalues: (ref) v_u_46, (copy) v_u_2, (copy) v_u_5, (copy) v_u_13, (copy) v_u_1
	local v48 = os.clock()
	if v48 >= v_u_46 then
		v_u_46 = v48 + p47 + 0.4
		local v_u_49 = Instance.new("ColorCorrectionEffect")
		v_u_49.Name = "RiftFrame"
		v_u_49.Parent = v_u_2
		v_u_5.tween(v_u_49, 0.03, {
			["TintColor"] = nil,
			["Contrast"] = 0.7,
			["Saturation"] = -0.6,
			["TintColor"] = Color3.fromRGB(255, 170, 170)
		})
		task.delay(p47, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_49, (ref) v_u_13
			local v50 = {
				["TintColor"] = nil,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = v_u_13
			}
			v_u_5.tween(v_u_49, 0.35, v50)
		end)
		v_u_1:AddItem(v_u_49, p47 + 0.4)
	end
end
local v_u_52 = 0
local function v_u_57(p53) -- name: darken
	-- upvalues: (ref) v_u_52, (copy) v_u_2, (copy) v_u_5, (copy) v_u_13, (copy) v_u_1
	local v54 = os.clock()
	if v54 >= v_u_52 then
		v_u_52 = v54 + p53 + 0.5
		local v_u_55 = Instance.new("ColorCorrectionEffect")
		v_u_55.Name = "RiftDark"
		v_u_55.Parent = v_u_2
		v_u_5.tween(v_u_55, 0.15, {
			["TintColor"] = nil,
			["Brightness"] = -0.08,
			["Contrast"] = 0.2,
			["TintColor"] = Color3.fromRGB(255, 205, 205)
		})
		task.delay(p53, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_55, (ref) v_u_13
			local v56 = {
				["TintColor"] = nil,
				["Brightness"] = 0,
				["Contrast"] = 0,
				["TintColor"] = v_u_13
			}
			v_u_5.tween(v_u_55, 0.4, v56)
		end)
		v_u_1:AddItem(v_u_55, p53 + 0.5)
	end
end
return function(p_u_58)
	-- upvalues: (copy) v_u_37, (copy) v_u_45, (copy) v_u_7, (copy) v_u_9, (copy) v_u_1, (copy) v_u_5, (copy) v_u_8, (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) v_u_6, (copy) v_u_13, (copy) v_u_51, (copy) v_u_26, (copy) v_u_57
	local function v_u_80(p59, p_u_60, p_u_61, p62, p63) -- name: blink
		-- upvalues: (ref) v_u_37, (ref) v_u_45, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) p_u_58
		local v_u_64, v_u_65 = v_u_37(v_u_45(p59, p63), p_u_60, 0.05, v_u_7.RiftSlit, v_u_9, 0)
		v_u_1:AddItem(v_u_64, p62 + 0.1)
		p_u_58.animate(p62, 0, function(p66)
			-- upvalues: (copy) v_u_64, (copy) p_u_60, (copy) p_u_61, (copy) v_u_65
			local v67
			if p66 < 0.3 then
				local v68 = p66 / 0.3 - 1
				v67 = v68 * 2.7 * v68 * v68 + 1 + v68 * 1.7 * v68
			else
				local v69 = (p66 - 0.7) / 0.3
				local v70 = math.clamp(v69, 0, 1)
				v67 = 1 - v70 * v70 * (3 - v70 * 2)
			end
			local v71 = v_u_64
			local v72 = p_u_60
			local v73 = p66 / 0.3
			local v74 = v72 * (math.min(v73, 1) * 0.4 + 0.6)
			local v75 = p_u_61 * v67
			local v76 = math.max(v75, 0.05)
			v71.Size = Vector3.new(v74, 0.05, v76)
			if p66 > 0.85 then
				local v77 = v_u_65
				local v78 = (p66 - 0.85) / 0.15
				for _, v79 in v77 do
					v79.Transparency = v78
				end
			end
			if p66 >= 1 then
				v_u_64:Destroy()
			end
		end)
	end
	local function v_u_98(p_u_81, p_u_82, p_u_83, p_u_84) -- name: flingBlade
		-- upvalues: (ref) v_u_37, (ref) v_u_45, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) p_u_58
		local v_u_85, v_u_86 = v_u_37(v_u_45(p_u_81, 0), p_u_83, p_u_83, v_u_7.RiftBlade, v_u_9, 0)
		v_u_1:AddItem(v_u_85, p_u_84 + 0.1)
		local v_u_87 = (math.random() - 0.5) * 30
		local v_u_88 = math.random() * 3.141592653589793 * 2
		p_u_58.animate(p_u_84, 0, function(p89)
			-- upvalues: (copy) p_u_81, (copy) p_u_82, (copy) p_u_83, (copy) v_u_85, (ref) v_u_45, (copy) v_u_88, (copy) p_u_84, (copy) v_u_87, (copy) v_u_86
			local v90 = p_u_81 + p_u_82 * (1 - (1 - p89) ^ 2) - Vector3.new(0, 1, 0) * p89 * p89 * 2
			local v91 = p_u_83
			local v92 = p89 * 3
			local v93 = math.min(v92, 1) * 3.141592653589793 / 2
			local v94 = v91 * (math.sin(v93) * 0.5 + 0.6 - 0.3 * p89)
			v_u_85.Size = Vector3.new(v94, 0.05, v94)
			v_u_85.CFrame = v_u_45(v90, v_u_88 + p89 * p_u_84 * v_u_87)
			local v95 = v_u_86
			local v96 = p89 ^ 2
			for _, v97 in v95 do
				v97.Transparency = v96
			end
			if p89 >= 1 then
				v_u_85:Destroy()
			end
		end)
	end
	local function v106(p99, p100) -- name: riftShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_37, (ref) v_u_7, (ref) v_u_9, (copy) p_u_58, (ref) v_u_12
		local v101 = p99.size
		local v102 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p100, v_u_8, {
			["transparency"] = 1
		})
		local v103 = CFrame.Angles(1.5707963267948966, 0, 0)
		local v104 = {
			{
				["p"] = v_u_37(p100 * v103, 3.1 * v101, 3.1 * v101, v_u_7.RiftBlade, v_u_9, 0),
				["off"] = v103
			}
		}
		if not p99.lite then
			local v105 = {
				["p"] = v_u_5.part(Vector3.new(1.6, 1.6, 1.6) * v101, p100, v_u_8, {
					["shape"] = nil,
					["transparency"] = 0.65,
					["shape"] = Enum.PartType.Ball
				}),
				["off"] = CFrame.identity
			}
			table.insert(v104, v105)
		end
		p_u_58.streak(v102, v_u_9, v_u_12, 1.3 * v101, 0.13)
		if p99.mine then
			p_u_58.light(v102, v_u_9, 9 * v101)
		end
		return p_u_58.assemble(v102, v104, {}, 0, 0, {}, 0.13, -15)
	end
	local function v110(p107, p108) -- name: riftImpact
		-- upvalues: (copy) v_u_80, (copy) p_u_58, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_12
		local v109 = p107.size
		v_u_80(p108, 6 * v109, 3 * v109, 0.2, (math.random() - 0.5) * 1.6)
		p_u_58.burst("Slash", p108, v_u_9, 1 * v109)
		p_u_58.burst("Impact", p108, v_u_8, 0.9 * v109)
		v_u_5.flash(p108, v_u_9, 3.8 * v109, 0.12)
		v_u_5.ring(p_u_58.ground(p108), v_u_8, 3.5 * v109, 0.22, v_u_7.Ring)
		if not p107.lite then
			p_u_58.spikes(p108, v_u_12, 3, 3 * v109, 0.14)
		end
		p_u_58.hitSound(p108)
	end
	local v_u_111 = {}
	setmetatable(v_u_111, {
		["__mode"] = "k"
	})
	local v_u_112 = {}
	setmetatable(v_u_112, {
		["__mode"] = "k"
	})
	local function v_u_155(p113) -- name: guillotineStep
		if p113.done then
			return false
		else
			local v114 = os.clock()
			local v115 = v114 - p113.born
			local v116 = v115 / 0.12
			local v117 = math.clamp(v116, 0, 1) - 1
			local v118 = v117 * 2.7 * v117 * v117 + 1 + v117 * 1.7 * v117
			local v119 = p113.closeAt
			if not v119 and (not p113.dropAt and v115 > 1) then
				p113.closeAt = v114
				v119 = v114
			end
			local v120
			if v119 then
				local v121 = (v114 - v119) / 0.08
				v120 = math.clamp(v121, 0, 1)
			else
				v120 = 0
			end
			local v122 = v115 * 24
			local v123 = math.sin(v122) * 0.04 + 1
			local v124 = p113.slit
			local v125 = v118 * 10 * (1 - v120) * v123
			local v126 = math.max(v125, 0.05)
			v124.Size = Vector3.new(26, 0.05, v126)
			local v127 = p113.slit
			local v128 = p113.sky
			local v129 = (Vector3.new(0, 1, 0) - p113.normal * (Vector3.new(0, 1, 0)):Dot(p113.normal)).Unit
			v127.CFrame = CFrame.fromMatrix(v128, p113.normal:Cross(v129), p113.normal, v129)
			local v130 = 0
			local v131 = p113.landAt
			local v132 = p113.dropAt
			local v133 = p113.floor + Vector3.new(0, 6.24, 0)
			local v134 = p113.sky - Vector3.new(0, 3.234, 0)
			local v135, v136
			if v131 and v131 <= v114 then
				local v137 = v114 - v131
				v135 = 1
				local v138 = p113.side
				local v139 = v137 * 70
				local v140 = v138 * math.sin(v139) * 0.12
				local v141 = 1 - v137 / 0.35
				v136 = v133 + v140 * math.max(v141, 0)
				if v137 > 0.35 then
					local v142 = (v137 - 0.35) / 0.25
					v130 = math.clamp(v142, 0, 1)
					v136 = v133 - Vector3.new(0, 10.164, 0) * v130 * v130
					if v130 >= 1 then
						if not p113.done then
							p113.done = true
							p113.slit:Destroy()
							p113.blade:Destroy()
						end
						return false
					end
				end
			elseif v132 and (v132 <= v114 and v131) then
				local v143 = v114 - v132
				local v144 = v131 - v132
				local v145 = v143 / math.max(v144, 0.001)
				local v146 = math.clamp(v145, 0, 1)
				v136 = v134:Lerp(v133, v146 * v146)
				v135 = v146 * 0.3 + 0.7
			else
				local v147 = v115 / 0.18
				local v148 = math.clamp(v147, 0, 1)
				local v149 = v148 * v148 * (3 - v148 * 2)
				v136 = p113.sky:Lerp(v134, v149)
				v135 = v149 * 0.45 + 0.25
				if v119 then
					v130 = v120
				end
			end
			local v150 = v135 * 22
			p113.blade.Size = Vector3.new(v150, 0.05, v150)
			local v151 = p113.blade
			local v152 = (Vector3.new(0, 1, 0) - p113.normal * (Vector3.new(0, 1, 0)):Dot(p113.normal)).Unit
			v151.CFrame = CFrame.fromMatrix(v136, p113.normal:Cross(v152), p113.normal, v152)
			for _, v153 in p113.bladeDecals do
				v153.Transparency = v130
			end
			if v119 and (v120 >= 1 and v130 >= 1) then
				if not p113.done then
					p113.done = true
					p113.slit:Destroy()
					p113.blade:Destroy()
				end
				return false
			else
				if v119 and v120 >= 1 then
					p113.slit.Size = Vector3.new(26, 0.05, 0.05)
					for _, v154 in p113.slitDecals do
						v154.Transparency = 1
					end
				end
				return true
			end
		end
	end
	local function v_u_168(p156, p157) -- name: startGuillotine
		-- upvalues: (copy) p_u_58, (ref) v_u_37, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) v_u_111, (copy) v_u_112, (ref) v_u_5, (copy) v_u_155
		local v158 = p_u_58.ground(p157, 0)
		local v159 = p_u_58.flatUnit(p156.feet - v158)
		local v160 = (v159 + Vector3.new(0, 0.22, 0)).Unit
		local v161, v162 = v_u_37(CFrame.new(v158), 1, 1, v_u_7.RiftSlit, v_u_9, 0)
		local v163, v164 = v_u_37(CFrame.new(v158), 1, 1, v_u_7.RiftBlade, v_u_9, 0)
		v_u_1:AddItem(v161, 4.6)
		v_u_1:AddItem(v163, 4.6)
		local v_u_165 = {
			["slit"] = nil,
			["slitDecals"] = nil,
			["blade"] = nil,
			["bladeDecals"] = nil,
			["normal"] = nil,
			["side"] = nil,
			["sky"] = nil,
			["floor"] = nil,
			["born"] = nil,
			["dropAt"] = nil,
			["landAt"] = nil,
			["closeAt"] = nil,
			["done"] = false,
			["slit"] = v161,
			["slitDecals"] = v162,
			["blade"] = v163,
			["bladeDecals"] = v164,
			["normal"] = v160,
			["side"] = v159:Cross(Vector3.new(0, 1, 0)),
			["sky"] = v158 + Vector3.new(0, 21, 0),
			["floor"] = v158,
			["born"] = os.clock()
		}
		local v166 = p156.caster
		if v166 then
			local v167 = v_u_111[v166]
			if v167 and not (v167.dropAt or v167.done) then
				v167.done = true
				v167.slit:Destroy()
				v167.blade:Destroy()
			end
			v_u_111[v166] = v_u_165
		else
			v_u_112[p156] = v_u_165
		end
		v_u_5.flash(v_u_165.sky, v_u_9, 12, 0.2)
		if not p156.lite then
			p_u_58.burst("Lightning", v_u_165.sky, v_u_9, 1.3)
		end
		p_u_58.runNow(function()
			-- upvalues: (ref) v_u_155, (copy) v_u_165
			return v_u_155(v_u_165)
		end)
		return v_u_165
	end
	local function v_u_179(p169, p170, p171) -- name: guillotineLand
		-- upvalues: (copy) p_u_58, (ref) v_u_9, (ref) v_u_11, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_12, (ref) v_u_6
		local v172 = p169.ability.radius
		local v173 = p169.lite
		local v174 = p_u_58.ground(p170)
		local v175
		if p171 then
			v175 = p171.side
		else
			v175 = p169.dir:Cross(Vector3.new(0, 1, 0))
		end
		local v176 = v174 - v175 * 9.24
		local v177 = v174 + v175 * 9.24
		p_u_58.groundLine(v176, v177, 1.6, v_u_9, 1.2, 0)
		p_u_58.groundLine(v176, v177, 5, v_u_11, 1.5, 0.4)
		v_u_5.flash(p_u_58.ground(p170, 2), v_u_10, v172 * 0.9, 0.14)
		p_u_58.pop(v174, v_u_9, v172 * 0.3, v172 * 1.2, 0.25, 0.7)
		p_u_58.burst("Explosion", p_u_58.ground(p170, 1.5), v_u_8, 1.6)
		p_u_58.burst("Shockwave", v174 + Vector3.new(0, 0.3, 0), v_u_8, v172 / 14)
		v_u_5.ring(v174, v_u_9, v172 * 1.2, 0.45, v_u_7.Shockwave)
		p_u_58.mark(p170, v_u_12, v172 * 0.6, 1.6, v_u_7.CrackLines, 0.05)
		for v178 = -1, 1 do
			p_u_58.burst("Slash", p_u_58.ground(p170 + v175 * v178 * 9.24 * 0.6, 1.5), v_u_9, 1.4)
		end
		p_u_58.spikes(p_u_58.ground(p170, 1), v_u_10, v173 and 4 or 8, v172 * 1.1, 0.3, nil, nil, true)
		if not v173 then
			p_u_58.chunks(p_u_58.ground(p170, 1), { p_u_58.EARTH[1], p_u_58.EARTH[2], v_u_11 }, 10, 45, 1.1, 1.1)
			p_u_58.spikes(p_u_58.ground(p170, 1.5), v_u_12, 6, v172, 0.3, Vector3.new(0, 1, 0), 0.8)
		end
		v_u_6.play("Crit", {
			["at"] = v174,
			["volume"] = p169.mine and 0.8 or 0.4
		})
		v_u_6.play("Explosion", {
			["at"] = v174,
			["volume"] = p169.mine and 0.8 or 0.45
		})
		if p169.mine then
			v_u_5.shake(0.45, 0.35)
		end
	end
	local v255 = {
		["rift_crescent_a"] = {
			["cast"] = function(p180) -- name: cast
				-- upvalues: (copy) v_u_80, (ref) v_u_5, (ref) v_u_9
				local v181 = p180.size
				local v182 = p180.eye + p180.dir * 1.8
				v_u_80(v182, 4.2 * v181, 2.4 * v181, 0.18, (math.random() - 0.5) * 1.2)
				v_u_5.flash(v182, v_u_9, 2.6 * v181, 0.1)
			end,
			["shot"] = v106,
			["impact"] = v110,
			["hit"] = function(_, p183, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_8
				p_u_58.burst("Impact", p183, v_u_8, 0.6)
			end
		},
		["rift_crescent_e"] = {
			["cast"] = function(p184) -- name: cast
				-- upvalues: (copy) p_u_58, (ref) v_u_9, (copy) v_u_168, (ref) v_u_26
				p_u_58.skillCast(p184, v_u_9)
				p_u_58.glint(p184.eye, v_u_9, 5, 0.16)
				v_u_168(p184, (v_u_26(p184)))
			end,
			["windup"] = function(p185, p186, p187) -- name: windup
				-- upvalues: (copy) v_u_111, (copy) v_u_112, (copy) v_u_168, (copy) p_u_58, (ref) v_u_9
				local v188 = p185.caster
				local v189
				if v188 then
					v189 = v_u_111[v188]
				else
					v189 = v_u_112[p185]
				end
				if not v189 or (v189.done or v189.dropAt) then
					v189 = nil
				end
				local v190 = v189 or v_u_168(p185, p186)
				v190.floor = p_u_58.ground(p186, 0)
				v190.sky = p_u_58.ground(p186, 21)
				local v191 = os.clock()
				v190.dropAt = v191
				v190.landAt = v191 + math.max(p187, 0.06)
				p_u_58.groundLine(p_u_58.ground(p186) - v190.side * 9.24, p_u_58.ground(p186) + v190.side * 9.24, 0.8, v_u_9, math.max(p187, 0.06) + 0.1, 0.2)
			end,
			["land"] = function(p192, p193) -- name: land
				-- upvalues: (copy) v_u_111, (copy) v_u_112, (copy) v_u_179
				local v194 = p192.caster
				local v195
				if v194 then
					v195 = v_u_111[v194]
				else
					v195 = v_u_112[p192]
				end
				if v195 and not v195.done then
					local v196 = os.clock()
					local v197 = v195.landAt or v196
					v195.landAt = math.min(v197, v196)
					v195.closeAt = v196 + 0.15
				end
				v_u_179(p192, p193, v195)
			end,
			["hit"] = function(p198, p199, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_9, (ref) v_u_8, (copy) v_u_80
				p_u_58.burst("Slash", p199, v_u_9, 1)
				p_u_58.burst("Impact", p199, v_u_8, 0.8)
				if not p198.lite then
					v_u_80(p199, 4, 2, 0.16, (math.random() - 0.5) * 1.6)
				end
			end
		},
		["rift_crescent_r"] = {
			["cast"] = function(p200) -- name: cast
				-- upvalues: (copy) p_u_58, (ref) v_u_9, (ref) v_u_13, (ref) v_u_7, (ref) v_u_6, (ref) v_u_57
				p_u_58.skillCast(p200, v_u_9, true)
				p_u_58.glint(p200.eye, v_u_9, 7, 0.2)
				p_u_58.sigil(p_u_58.facing(p200.eye + p200.dir * 1.6, p200.dir), 2.2, v_u_13, p_u_58.iris("rift_crescent", v_u_7.Ring), 0.35, -6)
				v_u_6.play("EyeActivate", {
					["at"] = p200.origin,
					["volume"] = p200.mine and 0.9 or 0.5
				})
				if p200.mine then
					v_u_57(0.9)
				end
			end,
			["windup"] = function(p201, p_u_202, p203) -- name: windup
				-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (copy) p_u_58
				local v204 = math.max(p203, 0.05)
				local v205 = p201.target.X
				local v206 = p_u_202.Y - 1.2
				local v207 = p201.target.Z
				local v_u_208 = Vector3.new(v205, v206, v207)
				local v_u_209 = v_u_5.part(Vector3.new(0.3, 0.3, 0.1), CFrame.new(p_u_202), v_u_9)
				v_u_1:AddItem(v_u_209, v204 + 0.5)
				p_u_58.animate(v204, 0, function(p210)
					-- upvalues: (copy) p_u_202, (copy) v_u_208, (copy) v_u_209, (ref) p_u_58
					local v211 = p_u_202:Lerp(v_u_208, p210)
					v_u_209.CFrame = CFrame.lookAt((p_u_202 + v211) / 2, v211 + (v_u_208 - p_u_202).Unit * 0.01)
					local v212 = v_u_209
					local v213 = (v211 - p_u_202).Magnitude
					local v214 = math.max(v213, 0.1)
					v212.Size = Vector3.new(0.3, 0.3, v214)
					if p210 >= 1 then
						p_u_58.thin(v_u_209, 0.12)
					end
				end)
				if not p201.lite then
					local v215 = p_u_58.loopAt("Charge", p201.eye + p201.dir * 1.5, v_u_9, 0.6)
					p_u_58.after(v204, v215)
					p_u_58.alongPath(p_u_202, v_u_208, 12, v204, function(p216)
						-- upvalues: (ref) p_u_58, (ref) v_u_9
						p_u_58.glint(p216, v_u_9, 3, 0.12)
					end)
				end
			end,
			["beam"] = function(p_u_217, p218, p_u_219) -- name: splitter
				-- upvalues: (ref) v_u_37, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) p_u_58, (ref) v_u_13, (ref) v_u_11, (copy) v_u_98, (ref) v_u_5, (ref) v_u_10, (ref) v_u_12, (ref) v_u_8, (ref) v_u_6, (ref) v_u_51
				local v_u_220 = p_u_217.lite
				local v221 = p_u_219 - p218
				local v_u_222
				if v221.Magnitude > 0.1 then
					v_u_222 = v221.Unit
				else
					v_u_222 = p_u_217.dir
				end
				local v_u_223 = p218 + v_u_222 * 2
				local v224 = (p_u_219 - v_u_223).Magnitude
				local v225 = (v_u_223 + p_u_219) / 2
				local v226 = (Vector3.new(0, 1, 0) - v_u_222 * (Vector3.new(0, 1, 0)):Dot(v_u_222)).Unit
				local v_u_227 = v_u_222:Cross(v226)
				local v_u_228 = (v226 * 0.9510565162951535 + v_u_227 * 0.3090169943749474).Unit
				local v229 = CFrame.fromMatrix(v225, v_u_222, v_u_228)
				local v_u_230 = v224 * 1.08
				local v_u_231, v232 = v_u_37(v229, v_u_230, 0.05, v_u_7.RiftSlit, v_u_9, 0)
				v_u_1:AddItem(v_u_231, 0.98)
				p_u_58.thin(p_u_58.rod(v_u_223, p_u_219, 0.6, v_u_13), 0.25, true)
				p_u_58.glowBeam(v_u_223, p_u_219, v_u_9, 2.5, 0.35)
				p_u_58.groundLine(p218, p_u_219, p_u_217.ability.width or 6, v_u_11, 1.3, 0.35)
				local v233 = v_u_220 and 3 or 7
				for v234 = 1, v233 do
					local v_u_235 = v_u_223:Lerp(p_u_219, v234 / v233)
					p_u_58.after(v234 * 0.015, function()
						-- upvalues: (ref) p_u_58, (copy) v_u_235, (ref) v_u_9
						p_u_58.burst("Slash", v_u_235, v_u_9, 1.6)
					end)
				end
				if not v_u_220 then
					for v236 = 1, 3 do
						p_u_58.after(v236 * 0.05, function()
							-- upvalues: (ref) p_u_58, (copy) v_u_223, (copy) p_u_219, (copy) v_u_228, (ref) v_u_9
							p_u_58.burst("Lightning", v_u_223:Lerp(p_u_219, math.random()) + v_u_228 * 2, v_u_9, 1.2)
						end)
					end
				end
				for v_u_237 = 1, v_u_220 and 3 or 9 do
					p_u_58.after(v_u_237 * 0.03 + 0.03, function()
						-- upvalues: (copy) v_u_223, (copy) p_u_219, (copy) v_u_227, (copy) v_u_237, (copy) v_u_222, (ref) v_u_98
						v_u_98(v_u_223:Lerp(p_u_219, 0.1 + 0.85 * math.random()), v_u_227 * (v_u_237 % 2 == 0 and 1 or -1) * (6 + math.random() * 5) + Vector3.new(0, 1, 0) * (4 + math.random() * 4) + v_u_222 * (math.random() - 0.5) * 4, 3.5 + math.random() * 2.5, 0.45)
					end)
				end
				local v_u_238 = os.clock()
				p_u_58.runNow(function()
					-- upvalues: (copy) v_u_238, (copy) v_u_231, (copy) v_u_230
					local v239 = os.clock() - v_u_238
					local v240
					if v239 < 0.42 then
						local v241 = v239 / 0.08
						local v242 = math.clamp(v241, 0, 1) - 1
						local v243 = (v242 * 2.7 * v242 * v242 + 1 + v242 * 1.7 * v242) * 32
						local v244 = v239 * 34
						v240 = v243 * (math.sin(v244) * 0.035 + 1)
					else
						local v245 = (v239 - 0.42) / 0.06
						local v246 = math.clamp(v245, 0, 1)
						v240 = (1 - v246 * v246 * (3 - v246 * 2)) * 32
					end
					local v247 = v_u_231
					local v248 = v_u_230
					local v249 = math.max(v240, 0.05)
					v247.Size = Vector3.new(v248, 0.05, v249)
					if v239 < 0.48 then
						return true
					end
					v_u_231:Destroy()
					return false
				end)
				for _, v250 in v232 do
					v250.Transparency = 0
				end
				p_u_58.after(0.48, function()
					-- upvalues: (ref) p_u_58, (copy) v_u_223, (copy) p_u_219, (ref) v_u_13, (ref) v_u_9, (copy) v_u_220, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_11, (ref) v_u_6, (copy) p_u_217, (ref) v_u_51
					p_u_58.thin(p_u_58.rod(v_u_223, p_u_219, 1.3, v_u_13), 0.22, true)
					p_u_58.thin(p_u_58.rod(v_u_223, p_u_219, 4.5, v_u_9, 0.45), 0.3, true)
					for v251 = 1, v_u_220 and 2 or 4 do
						local v252 = v_u_223:Lerp(p_u_219, v251 / (v_u_220 and 2 or 4) - 0.1)
						v_u_5.flash(v252, v_u_10, 9, 0.16)
						v_u_5.ring(p_u_58.ground(v252), v_u_9, 9, 0.4, v_u_7.Shockwave)
						if v_u_220 then
							continue
						end
						p_u_58.spikes(v252, v_u_12, 4, 8, 0.3)
						p_u_58.spikes(v252, v_u_9, 3, 7, 0.25)
					end
					p_u_58.burst("Explosion", p_u_219, v_u_8, 1.8)
					p_u_58.burst("Shockwave", p_u_58.ground(p_u_219, 0.3), v_u_9, 0.9)
					p_u_58.pop(p_u_219, v_u_9, 3, 16, 0.35, 0.4)
					if not v_u_220 then
						p_u_58.chunks(p_u_58.ground(p_u_219, 1), { p_u_58.EARTH[1], v_u_11, v_u_12 }, 8, 40, 0.9, 1)
					end
					v_u_6.play("Explosion", {
						["at"] = p_u_219,
						["volume"] = p_u_217.mine and 0.9 or 0.5
					})
					if p_u_217.mine then
						v_u_5.shake(0.6, 0.5)
						v_u_51(0.12)
					end
				end)
				v_u_6.play("Crit", {
					["at"] = p218,
					["volume"] = p_u_217.mine and 0.8 or 0.45
				})
				v_u_6.play("Lightning", {
					["at"] = v225,
					["volume"] = p_u_217.mine and 0.5 or 0.3
				})
				if p_u_217.mine then
					v_u_5.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(p253, p254, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_9, (ref) v_u_8, (copy) v_u_80
				p_u_58.burst("Slash", p254, v_u_9, 1.2)
				p_u_58.burst("Impact", p254, v_u_8, 1)
				if not p253.lite then
					v_u_80(p254, 5, 2.6, 0.2, (math.random() - 0.5) * 1.6)
				end
			end
		}
	}
	return v255
end