local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ProximityPromptService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.FuseMenu)
local v_u_7 = require(script.Parent.Perf)
local v_u_8 = require(script.Parent.State)
local v_u_9 = require(script.Parent.Tutorial)
local v_u_10 = require(v3.Shared.Config.Fuse)
local v_u_11 = require(v3.Shared.Config.Release)
local v_u_12 = require(v3.Shared.Logic.Fuse)
local v13 = {}
local v_u_14 = v1.LocalPlayer
local v_u_15 = {}
local v_u_16 = false
local v_u_17 = nil
local function v_u_28(p18, p19) -- name: flowing
	local v20 = #p18
	local v21 = {}
	for v22 = 0, 10 do
		local v23 = v22 / 10
		local v24 = (v23 + p19) % 1 * v20
		local v25 = math.floor(v24)
		local v26 = p18[v25 % v20 + 1]:Lerp(p18[(v25 + 1) % v20 + 1], v24 - v25)
		local v27 = ColorSequenceKeypoint.new
		table.insert(v21, v27(v23, v26))
	end
	return ColorSequence.new(v21)
end
local function v_u_30(p29) -- name: best
	-- upvalues: (copy) v_u_8
	return v_u_8.number(p29 == 1 and "BestStage" or "BestStage" .. tostring(p29))
end
local function v_u_34(p31) -- name: density
	-- upvalues: (copy) v_u_7
	for _, v32 in p31:GetDescendants() do
		if v32:IsA("ParticleEmitter") then
			local v33 = v32:GetAttribute("Rate")
			if type(v33) ~= "number" then
				v33 = v32.Rate
			end
			v32.Rate = v33 * v_u_7.mapRate()
		else
			if not v32:IsA("PointLight") then
				continue
			end
			v32.Enabled = v_u_7.level() > 1
		end
	end
end
local function v_u_39(p35) -- name: refresh
	-- upvalues: (copy) v_u_12, (copy) v_u_30, (copy) v_u_11, (copy) v_u_10, (copy) v_u_9
	local v36 = v_u_12.open(v_u_30)
	for _, v37 in p35:GetDescendants() do
		if v37:IsA("ProximityPrompt") and v37.Name == "FusePrompt" then
			local v38 = v_u_11.on(v_u_10.UPDATE) and v_u_9.known()
			if v38 then
				v38 = not v_u_9.active()
			end
			v37.Enabled = v38
			v37.ActionText = v36 and "Fuse Pets" or ("Reach World %*"):format(v_u_10.FROM_WORLD)
		else
			if not v37:IsA("TextLabel") or v37.Name ~= "Lock" then
				continue
			end
			v37.Text = ("UNLOCKS IN WORLD %*"):format(v_u_10.FROM_WORLD)
			v37.Visible = not v36
		end
	end
end
local function v_u_53(p40) -- name: track
	-- upvalues: (copy) v_u_15, (copy) v_u_34, (copy) v_u_39
	if p40:IsA("Model") and not v_u_15[p40] then
		local v41 = p40:FindFirstChild("Sign")
		if v41 then
			v41 = v41:FindFirstChild("Board")
		end
		local v42
		if v41 and v41:IsA("BillboardGui") then
			v42 = {
				["board"] = nil,
				["title"] = nil,
				["paint"] = nil,
				["palette"] = nil,
				["pulse"] = nil,
				["strokes"] = nil,
				["board"] = v41,
				["palette"] = {},
				["strokes"] = {}
			}
			local v43 = v41:FindFirstChild("Title")
			if v43 and v43:IsA("TextLabel") then
				v42.title = v43
				local v44 = v43:FindFirstChild("Paint")
				if v44 and v44:IsA("UIGradient") then
					local v45 = v44.Color.Keypoints
					for v46 = 1, #v45 - 1 do
						local v47 = v42.palette
						local v48 = v45[v46].Value
						table.insert(v47, v48)
					end
					if #v42.palette >= 2 then
						v42.paint = v44
					end
				end
			end
			local v49 = v41:FindFirstChild("Pulse")
			if v49 and v49:IsA("UIScale") then
				v42.pulse = v49
			end
			for _, v50 in v41:GetChildren() do
				local v51 = v50:FindFirstChildOfClass("UIStroke")
				if not (v50:IsA("TextLabel") and v51) then
					continue
				end
				local v52 = v42.strokes
				table.insert(v52, {
					["stroke"] = nil,
					["label"] = nil,
					["share"] = 0.085,
					["stroke"] = v51,
					["label"] = v50
				})
			end
		else
			v42 = nil
		end
		v_u_15[p40] = {
			["model"] = p40,
			["at"] = p40:GetPivot().Position,
			["words"] = v42
		}
		v_u_34(p40)
		v_u_39(p40)
	end
end
local function v_u_68(p_u_54) -- name: bind
	-- upvalues: (ref) v_u_16, (copy) v_u_39, (copy) v_u_53, (copy) v_u_15, (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_7, (copy) v_u_34, (copy) v_u_2, (copy) v_u_14, (copy) v_u_11, (copy) v_u_12, (copy) v_u_30, (copy) v_u_6, (ref) v_u_17
	if not v_u_16 then
		v_u_16 = true
		local function v56() -- name: all
			-- upvalues: (copy) p_u_54, (ref) v_u_39
			for _, v55 in p_u_54:GetChildren() do
				v_u_39(v55)
			end
		end
		p_u_54.ChildAdded:Connect(v_u_53)
		p_u_54.ChildRemoved:Connect(function(p57)
			-- upvalues: (ref) v_u_15
			if p57:IsA("Model") then
				v_u_15[p57] = nil
			end
		end)
		for _, v58 in p_u_54:GetChildren() do
			v_u_53(v58)
		end
		v_u_9.onChange(function()
			-- upvalues: (copy) p_u_54, (ref) v_u_39
			for _, v59 in p_u_54:GetChildren() do
				v_u_39(v59)
			end
		end)
		local v60 = v_u_10.FROM_WORLD
		if v60 > 1 then
			local v61 = v_u_8.watch
			local v62
			if v60 - 1 == 1 then
				v62 = "BestStage"
			else
				local v63 = v60 - 1
				v62 = "BestStage" .. tostring(v63)
			end
			v61(v62, v56)
		end
		v_u_7.onChanged(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_34
			for v64 in v_u_15 do
				v_u_34(v64)
			end
		end)
		v_u_2.PromptTriggered:Connect(function(p65, p66)
			-- upvalues: (ref) v_u_14, (copy) p_u_54, (ref) v_u_11, (ref) v_u_10, (ref) v_u_9, (ref) v_u_12, (ref) v_u_30, (ref) v_u_6, (ref) v_u_17
			if p66 == v_u_14 and (p65.Name == "FusePrompt" and p65:IsDescendantOf(p_u_54)) then
				local v67 = v_u_11.on(v_u_10.UPDATE) and v_u_9.known()
				if v67 then
					v67 = not v_u_9.active()
				end
				if v67 then
					if v_u_12.open(v_u_30) then
						v_u_6.open()
					elseif v_u_17 then
						v_u_17(v_u_12.lockedText())
					end
				end
			end
		end)
	end
end
local function v_u_80() -- name: step
	-- upvalues: (copy) v_u_5, (copy) v_u_15, (copy) v_u_28
	local v69 = v_u_5.CurrentCamera
	if v69 and next(v_u_15) ~= nil then
		local v70 = v69.CFrame.Position
		local v71 = os.clock()
		for _, v72 in v_u_15 do
			local v73 = v72.words
			if not v73 or (v72.at - v70).Magnitude > 220 then
				continue
			end
			local v74 = v73.paint
			if v74 then
				v74.Color = v_u_28(v73.palette, v71 / 5 % 1)
			end
			local v75 = v73.pulse
			if v75 then
				local v76 = v71 * 2.4
				v75.Scale = math.sin(v76) * 0.03 + 1
			end
			for _, v77 in v73.strokes do
				local v78 = v77.stroke
				local v79 = v77.label.AbsoluteSize.Y * v77.share
				v78.Thickness = math.clamp(v79, 1.5, 6)
			end
		end
	end
end
function v13.start(p81) -- name: start
	-- upvalues: (ref) v_u_17, (copy) v_u_5, (copy) v_u_68, (copy) v_u_4, (copy) v_u_80
	v_u_17 = p81
	local v82 = v_u_5:FindFirstChild("FuseMachines")
	if v82 then
		v_u_68(v82)
	else
		local v_u_83 = nil
		v_u_83 = v_u_5.ChildAdded:Connect(function(p84)
			-- upvalues: (ref) v_u_83, (ref) v_u_68
			if p84.Name == "FuseMachines" then
				v_u_83:Disconnect()
				v_u_68(p84)
			end
		end)
	end
	v_u_4.RenderStepped:Connect(v_u_80)
end
return v13