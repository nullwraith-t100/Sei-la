local v_u_1 = game:GetService("ReplicatedStorage")
require(v_u_1.Shared.Config.Enemies)
local v_u_2 = require(v_u_1.Shared.Config.Textures)
local v_u_3 = require(script.Parent.Fx.Kit)
local v4 = {}
local v_u_5 = Font.new("rbxasset://fonts/families/FredokaOne.json", Enum.FontWeight.Regular)
local v_u_6 = Color3.fromHex
local v_u_7 = Color3.fromRGB(38, 34, 40)
local v_u_8 = Color3.fromRGB(205, 212, 222)
local v_u_9 = Color3.fromRGB(112, 78, 48)
local v_u_10 = Color3.fromRGB(237, 230, 214)
local v_u_11 = Color3.fromRGB(242, 246, 250)
local v_u_12 = Color3.fromRGB(217, 176, 96)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = {
	["kunai"] = 0.9,
	["shuriken"] = 0.5,
	["katana"] = 1.05,
	["nodachi"] = 1.05,
	["bostaff"] = 0.8,
	["spear"] = 0.7,
	["trident"] = 0.7,
	["glaive"] = 0.7,
	["club"] = 0.95,
	["scimitar"] = 1.05,
	["axe"] = 0.95,
	["greatsword"] = 1.05,
	["claws"] = 0.25,
	["hammer"] = 0.95
}
local v_u_15 = {
	["normal"] = {
		["torso"] = Vector3.new(2, 2, 1),
		["head"] = 1.6,
		["arm"] = Vector3.new(1, 2, 1),
		["armX"] = 1.5,
		["leg"] = Vector3.new(1, 2, 1),
		["legX"] = 0.5,
		["neckZ"] = 0,
		["sink"] = 0
	},
	["slim"] = {
		["torso"] = Vector3.new(1.8, 2, 0.9),
		["head"] = 1.5,
		["arm"] = Vector3.new(0.8, 2, 0.8),
		["armX"] = 1.3,
		["leg"] = Vector3.new(0.85, 2.1, 0.85),
		["legX"] = 0.45,
		["neckZ"] = 0,
		["sink"] = 0
	},
	["bulky"] = {
		["torso"] = Vector3.new(2.8, 2.3, 1.5),
		["head"] = 1.5,
		["arm"] = Vector3.new(1.25, 2.3, 1.25),
		["armX"] = 2.05,
		["leg"] = Vector3.new(1.2, 1.7, 1.2),
		["legX"] = 0.75,
		["neckZ"] = -0.15,
		["sink"] = 0.15
	},
	["golem"] = {
		["torso"] = Vector3.new(3, 2.5, 1.8),
		["head"] = 1.3,
		["arm"] = Vector3.new(1.4, 2.7, 1.4),
		["armX"] = 2.25,
		["leg"] = Vector3.new(1.3, 1.6, 1.3),
		["legX"] = 0.8,
		["neckZ"] = -0.35,
		["sink"] = 0.35
	}
}
local v_u_16 = {
	["plastic"] = Enum.Material.Plastic,
	["cloth"] = Enum.Material.Fabric,
	["rock"] = Enum.Material.Slate,
	["lava"] = Enum.Material.Basalt,
	["sand"] = Enum.Material.Sandstone,
	["ice"] = Enum.Material.Ice,
	["crystal"] = Enum.Material.Glass,
	["fur"] = Enum.Material.Fabric,
	["cloud"] = Enum.Material.SmoothPlastic,
	["metal"] = Enum.Material.Metal,
	["marble"] = Enum.Material.Marble,
	["ghost"] = Enum.Material.SmoothPlastic
}
local v_u_17 = {
	["rock"] = true,
	["lava"] = true,
	["sand"] = true,
	["crystal"] = true,
	["metal"] = true,
	["marble"] = true
}
local function v_u_27(p18, p19, p20, p21, p22) -- name: newPart
	local v23
	if p22 and p22.wedge then
		v23 = Instance.new("WedgePart")
	else
		v23 = Instance.new("Part")
		if p22 and p22.shape then
			v23.Shape = p22.shape
		end
	end
	v23.Name = p19
	v23.Size = p20 * p18.s
	v23.Color = p21
	local v24 = Enum.Material.Plastic
	if p22 and p22.neon then
		v24 = Enum.Material.Neon
	elseif p22 and p22.material then
		v24 = p22.material
	end
	v23.Material = v24
	v23.CanCollide = false
	v23.CanTouch = false
	v23.CanQuery = false
	v23.Massless = true
	v23.Anchored = false
	local v25
	if p22 then
		v25 = p22.neon or p22.hidden
	else
		v25 = p22
	end
	local v26 = not v25
	if v26 then
		v26 = p20.Magnitude > 1.1
	end
	v23.CastShadow = v26
	if p22 and p22.studs then
		v23.TopSurface = Enum.SurfaceType.Studs
		v23.BottomSurface = Enum.SurfaceType.Inlet
	else
		v23.TopSurface = Enum.SurfaceType.Smooth
		v23.BottomSurface = Enum.SurfaceType.Smooth
	end
	if p22 and p22.hidden then
		v23.Transparency = 1
		p18.hidden[v23] = true
	elseif p22 and p22.alpha then
		v23.Transparency = p22.alpha
	end
	v23.Parent = p18.model
	return v23
end
local function v_u_40(p28, p29, p30, p31, p32, p33, p34, p35) -- name: joint
	-- upvalues: (copy) v_u_27
	local v36 = v_u_27(p28, p30, p31, p32, p35)
	local v37 = Instance.new("Motor6D")
	v37.Name = p30
	v37.Part0 = p29
	v37.Part1 = v36
	local v38 = p28.s
	v37.C0 = p33.Rotation + p33.Position * v38
	local v39 = p28.s
	v37.C1 = p34.Rotation + p34.Position * v39
	v36.CFrame = p29.CFrame * v37.C0 * v37.C1:Inverse()
	v37.Parent = v36
	return v36, v37
end
local function v_u_57(p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51, p52) -- name: flap
	-- upvalues: (copy) v_u_40
	local v53, v54 = v_u_40(p41, p42, p43, p44, p45, p46, p47, p52)
	local v55 = p41.swings
	local v56 = {
		["motor"] = v54,
		["axis"] = p48,
		["amount"] = p49,
		["speed"] = p50,
		["offset"] = math.random() * 6,
		["lean"] = p51
	}
	table.insert(v55, v56)
	return v53
end
local function v_u_68(p58, p59, p60, p61, p62, p63) -- name: trail
	local v64 = Instance.new("Attachment")
	v64.Name = "TrailA"
	v64.Position = p60 * p58.s
	v64.Parent = p59
	local v65 = Instance.new("Attachment")
	v65.Name = "TrailB"
	v65.Position = p61 * p58.s
	v65.Parent = p59
	local v66 = Instance.new("Trail")
	v66.Attachment0 = v64
	v66.Attachment1 = v65
	v66.Color = ColorSequence.new(p58.glow)
	v66.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, p63), NumberSequenceKeypoint.new(1, 1) })
	v66.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.25) })
	v66.Lifetime = p62
	v66.LightEmission = 1
	v66.LightInfluence = 0
	v66.MinLength = 0.05
	v66.FaceCamera = false
	v66.Parent = p59
	local v67 = p58.trails
	table.insert(v67, v66)
	return v66
end
local function v_u_114(p69, p70, p71, p72, p73, p74, p75, p76) -- name: branch
	-- upvalues: (copy) v_u_27
	local v77 = {
		["neon"] = true
	}
	local v78 = Vector3.new(p74, p73, p74)
	local v79 = p72 * CFrame.new(0, p73 / 2, 0)
	local v80 = Instance.new("Part")
	v80.Name = p71
	v80.Size = v78 * p69.s
	v80.Color = p75
	v80.Material = Enum.Material.Plastic
	v80.CanCollide = false
	v80.CanTouch = false
	v80.CanQuery = false
	v80.Massless = true
	v80.Anchored = false
	v80.CastShadow = v78.Magnitude > 1.1
	v80.TopSurface = Enum.SurfaceType.Smooth
	v80.BottomSurface = Enum.SurfaceType.Smooth
	v80.Parent = p69.model
	local v81 = p70.CFrame
	local v82 = p69.s
	v80.CFrame = v81 * (v79.Rotation + v79.Position * v82)
	local v83 = Instance.new("WeldConstraint")
	v83.Part0 = p70
	v83.Part1 = v80
	v83.Parent = v80
	local v84 = p71 .. "Tip"
	local v85 = p74 * 0.8
	local v86 = p74 * 0.8
	local v87 = Vector3.new(v85, 0.3, v86)
	local v88 = p69.glow
	local v89 = CFrame.new(0, p73 / 2 + 0.1, 0)
	local v90 = v_u_27(p69, v84, v87, v88, v77)
	local v91 = v80.CFrame
	local v92 = p69.s
	v90.CFrame = v91 * (v89.Rotation + v89.Position * v92)
	local v93 = Instance.new("WeldConstraint")
	v93.Part0 = v80
	v93.Part1 = v90
	v93.Parent = v90
	for _, v94 in p76 do
		local v95 = p74 * 0.75
		local v96 = v94[4]
		local v97 = p74 * 0.75
		local v98 = Vector3.new(v95, v96, v97)
		local v99 = CFrame.new(0, -p73 / 2 + v94[1] * p73, 0) * CFrame.Angles(v94[3], 0, v94[2]) * CFrame.new(0, v94[4] / 2, 0)
		local v100 = Instance.new("Part")
		v100.Name = p71
		v100.Size = v98 * p69.s
		v100.Color = p75
		v100.Material = Enum.Material.Plastic
		v100.CanCollide = false
		v100.CanTouch = false
		v100.CanQuery = false
		v100.Massless = true
		v100.Anchored = false
		v100.CastShadow = v98.Magnitude > 1.1
		v100.TopSurface = Enum.SurfaceType.Smooth
		v100.BottomSurface = Enum.SurfaceType.Smooth
		v100.Parent = p69.model
		local v101 = v80.CFrame
		local v102 = p69.s
		v100.CFrame = v101 * (v99.Rotation + v99.Position * v102)
		local v103 = Instance.new("WeldConstraint")
		v103.Part0 = v80
		v103.Part1 = v100
		v103.Parent = v100
		local v104 = p71 .. "Tip"
		local v105 = p74 * 0.65
		local v106 = p74 * 0.65
		local v107 = Vector3.new(v105, 0.26, v106)
		local v108 = p69.glow
		local v109 = CFrame.new(0, v94[4] / 2 + 0.08, 0)
		local v110 = v_u_27(p69, v104, v107, v108, v77)
		local v111 = v100.CFrame
		local v112 = p69.s
		v110.CFrame = v111 * (v109.Rotation + v109.Position * v112)
		local v113 = Instance.new("WeldConstraint")
		v113.Part0 = v100
		v113.Part1 = v110
		v113.Parent = v110
	end
	return v80
end
local function v_u_143(p115, p116, p117, p118, p119) -- name: cog
	-- upvalues: (copy) v_u_57, (copy) v_u_27
	local v120 = {
		["shape"] = Enum.PartType.Cylinder,
		["material"] = Enum.Material.Metal
	}
	local v121
	if p119 then
		v121 = v_u_57(p115, p116, "Cog", Vector3.new(0.22, p118, p118), p115.accent, p117, CFrame.identity, Vector3.new(1, 0, 0), 0.7, 2.2, 0, v120)
	else
		v121 = v_u_27(p115, "Cog", Vector3.new(0.22, p118, p118), p115.accent, v120)
		local v122 = p116.CFrame
		local v123 = p115.s
		v121.CFrame = v122 * (p117.Rotation + p117.Position * v123)
		local v124 = Instance.new("WeldConstraint")
		v124.Part0 = p116
		v124.Part1 = v121
		v124.Parent = v121
	end
	for v125 = 0, 3 do
		local v126 = p118 + 0.32
		local v127 = Vector3.new(0.2, v126, 0.24)
		local v128 = p115.accent
		local v129 = CFrame.Angles(v125 * 3.141592653589793 / 4, 0, 0)
		local v130 = v_u_27(p115, "Tooth", v127, v128, {
			["material"] = Enum.Material.Metal
		})
		local v131 = v121.CFrame
		local v132 = p115.s
		v130.CFrame = v131 * (v129.Rotation + v129.Position * v132)
		local v133 = Instance.new("WeldConstraint")
		v133.Part0 = v121
		v133.Part1 = v130
		v133.Parent = v130
	end
	local v134 = p118 * 0.36
	local v135 = p118 * 0.36
	local v136 = Vector3.new(0.3, v134, v135)
	local v137 = p115.glow
	local v138 = CFrame.identity
	local v139 = v_u_27(p115, "Hub", v136, v137, {
		["neon"] = true,
		["shape"] = nil,
		["shape"] = Enum.PartType.Cylinder
	})
	local v140 = v121.CFrame
	local v141 = p115.s
	v139.CFrame = v140 * (v138.Rotation + v138.Position * v141)
	local v142 = Instance.new("WeldConstraint")
	v142.Part0 = v121
	v142.Part1 = v139
	v142.Parent = v139
	return v121
end
local function v_u_147(p144, p145) -- name: fromTemplate
	-- upvalues: (copy) v_u_1
	local v146 = v_u_1:FindFirstChild("Fx")
	if v146 then
		v146 = v146:FindFirstChild(p144)
	end
	if v146 then
		v146 = v146:FindFirstChild(p145)
	end
	if v146 and v146:IsA("ParticleEmitter") then
		return v146:Clone()
	else
		return nil
	end
end
local function v_u_156(p148, p149) -- name: scaleSequence
	local v150 = {}
	for _, v151 in p148.Keypoints do
		local v152 = NumberSequenceKeypoint.new
		local v153 = v151.Time
		local v154 = v151.Value * p149
		local v155 = v151.Envelope * p149
		table.insert(v150, v152(v153, v154, v155))
	end
	return NumberSequence.new(v150)
end
local function v_u_158(p157) -- name: fade
	return NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.15, p157),
		NumberSequenceKeypoint.new(0.65, p157 + (1 - p157) * 0.35),
		NumberSequenceKeypoint.new(1, 1)
	})
end
local function v_u_160(p159) -- name: recipes3
	-- upvalues: (copy) v_u_6
	return p159 == "ash" and {
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -0.8, 0),
			["light"] = 0,
			["spread"] = true,
			["colors"] = { v_u_6("#C8C0BC"), v_u_6("#5A5250") },
			["life"] = NumberRange.new(1.4, 2.2),
			["speed"] = NumberRange.new(0.3, 0.9)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFB04A"), v_u_6("#FF3A1A") },
			["life"] = NumberRange.new(0.6, 1.1),
			["speed"] = NumberRange.new(1, 2.5)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["alpha"] = 0.5,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#5A5250"), v_u_6("#2A2424") },
			["life"] = NumberRange.new(1, 1.5),
			["speed"] = NumberRange.new(0.3, 0.9)
		}
	} or (p159 == "blood" and {
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.3, 0),
			["alpha"] = 0.45,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#8A0A1A"), v_u_6("#2A0408") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 0.8,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -7, 0),
			["light"] = 0.4,
			["spread"] = true,
			["colors"] = { v_u_6("#FF3A4A"), v_u_6("#8A0010") },
			["life"] = NumberRange.new(0.7, 1.1),
			["speed"] = NumberRange.new(0.5, 1.5)
		},
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.4,
			["life"] = nil,
			["light"] = 0.3,
			["alpha"] = 0.35,
			["locked"] = true,
			["colors"] = { v_u_6("#C8102A"), v_u_6("#3A0008") },
			["life"] = NumberRange.new(0.4, 0.6)
		}
	} or (p159 == "souls" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.42,
			["life"] = nil,
			["light"] = 0.5,
			["alpha"] = 0.45,
			["locked"] = true,
			["colors"] = { v_u_6("#FFD8DC"), v_u_6("#C8142E") },
			["life"] = NumberRange.new(0.5, 0.8)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1.8,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 1.4, 0),
			["light"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FF5A6A") },
			["life"] = NumberRange.new(1.2, 1.8),
			["speed"] = NumberRange.new(0.4, 1)
		}
	} or (p159 == "redleaves" and {
		{
			["template"] = "Petals",
			["emitter"] = "Petals",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1.3,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -1.2, 0),
			["light"] = 0.25,
			["spread"] = true,
			["colors"] = { v_u_6("#FF3A4A"), v_u_6("#8A0A1A") },
			["life"] = NumberRange.new(1.4, 2.2),
			["speed"] = NumberRange.new(0.8, 1.6)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFD0D8"), v_u_6("#FF3A6A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p159 == "magma" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 7,
			["size"] = 0.5,
			["life"] = nil,
			["light"] = 0.6,
			["locked"] = true,
			["colors"] = { v_u_6("#FFB020"), v_u_6("#FF3A0A") },
			["life"] = NumberRange.new(0.45, 0.7)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -6, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFE14B"), v_u_6("#FF4A0A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1, 2.5)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 2, 0),
			["alpha"] = 0.5,
			["spread"] = true,
			["colors"] = { v_u_6("#3A2A24"), v_u_6("#140E0C") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.5, 1.2)
		}
	} or (p159 == "curse" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 8,
			["size"] = 0.55,
			["life"] = nil,
			["light"] = 0.15,
			["alpha"] = 0.3,
			["locked"] = true,
			["colors"] = { v_u_6("#7A2AC8"), v_u_6("#14041E") },
			["life"] = NumberRange.new(0.5, 0.8)
		},
		{
			["template"] = "AuraMode",
			["emitter"] = "Crackle",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.5,
			["life"] = nil,
			["locked"] = true,
			["colors"] = { v_u_6("#FF5AF0"), v_u_6("#C04BFF") },
			["life"] = NumberRange.new(0.1, 0.2)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 3, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#E07AFF"), v_u_6("#5A1A8A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.5, 2)
		}
	} or (p159 == "eclipse" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 8,
			["size"] = 0.55,
			["life"] = nil,
			["light"] = 0,
			["alpha"] = 0.25,
			["locked"] = true,
			["colors"] = { v_u_6("#20142A"), v_u_6("#000000") },
			["life"] = NumberRange.new(0.5, 0.8)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 0.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 3, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFF2B0"), v_u_6("#FF9A2A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1, 2.5)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FFD27A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p159 == "hellfire" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 9,
			["size"] = 0.55,
			["life"] = nil,
			["light"] = 0.5,
			["locked"] = true,
			["colors"] = { v_u_6("#FF4A1A"), v_u_6("#5A0008") },
			["life"] = NumberRange.new(0.45, 0.7)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 0.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 6, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFD23A"), v_u_6("#FF2A0A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1.5, 3.5)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.8, 0),
			["alpha"] = 0.5,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#2A1414"), v_u_6("#0A0404") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.3, 0.9)
		}
	} or (p159 == "bloodmoon" and {
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1.9,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.8, 0),
			["light"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#FF6A7A"), v_u_6("#C8102A") },
			["life"] = NumberRange.new(1.4, 2),
			["speed"] = NumberRange.new(0.3, 0.9)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FF5A6A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p159 == "blizzard" and {
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 10,
			["size"] = 0.55,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(-10, -3, 0),
			["light"] = 0.4,
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#CFE8FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(3, 6)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.5,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(-6, 0, 0),
			["alpha"] = 0.55,
			["spread"] = true,
			["colors"] = { v_u_6("#F4FBFF"), v_u_6("#BFE0F4") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1, 3)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#9FE8FF") },
			["life"] = NumberRange.new(0.5, 0.8),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p159 == "bioglow" and {
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 7,
			["size"] = 2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["light"] = 0.8,
			["spread"] = true,
			["colors"] = { v_u_6("#FF7AE8"), v_u_6("#5AF2FF") },
			["life"] = NumberRange.new(1.4, 2.2),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#7AF2FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["alpha"] = 0.5,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#1A1E3A"), v_u_6("#06081A") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.3, 0.8)
		}
	} or {}))))))))))
end
local function v_u_162(p161) -- name: recipes5
	-- upvalues: (copy) v_u_6
	return p161 == "stardust" and {
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 0.24,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.5, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FF9BF0") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 1.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.5, 0),
			["light"] = 0.7,
			["spread"] = true,
			["colors"] = { v_u_6("#FFC8FA"), v_u_6("#9B7AFF") },
			["life"] = NumberRange.new(1.2, 1.9),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.55,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -1.8, 0),
			["light"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#FFF4FF"), v_u_6("#C89BFF") },
			["life"] = NumberRange.new(0.8, 1.3),
			["speed"] = NumberRange.new(0.4, 1)
		}
	} or (p161 == "asteroid" and {
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.95,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -5, 0),
			["light"] = 0,
			["spread"] = true,
			["colors"] = { v_u_6("#8A7A9A"), v_u_6("#3A2E4A") },
			["life"] = NumberRange.new(0.7, 1.1),
			["speed"] = NumberRange.new(0.6, 1.6)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.42,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["alpha"] = 0.5,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#6A5A7A"), v_u_6("#2A1E3A") },
			["life"] = NumberRange.new(0.9, 1.3),
			["speed"] = NumberRange.new(0.5, 1.3)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.3, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#E8FFFF"), v_u_6("#5AD8FF") },
			["life"] = NumberRange.new(0.5, 0.8),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p161 == "comet" and {
		{
			["template"] = "AuraMode",
			["emitter"] = "Streaks",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.5,
			["life"] = nil,
			["speed"] = nil,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#5AD8FF") },
			["life"] = NumberRange.new(0.3, 0.5),
			["speed"] = NumberRange.new(4, 7)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 0.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 5, 0),
			["light"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#E8FFFF"), v_u_6("#3AA8FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1.5, 3)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#9BE8FF") },
			["life"] = NumberRange.new(0.5, 0.9),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p161 == "nebula" and {
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 7,
			["size"] = 2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["light"] = 0.8,
			["spread"] = true,
			["colors"] = { v_u_6("#FF7AE8"), v_u_6("#7A5AFF") },
			["life"] = NumberRange.new(1.4, 2.2),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.3, 0),
			["light"] = 0.3,
			["alpha"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#C86BFF"), v_u_6("#5AD8FF") },
			["life"] = NumberRange.new(1, 1.5),
			["speed"] = NumberRange.new(0.2, 0.6)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#9BF0FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p161 == "prism" and {
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.24,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.5, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FF7AE8"), v_u_6("#FFE14B") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.24,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.5, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#5AFFE8"), v_u_6("#7AFF7A") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 1.5, 0),
			["light"] = 0.6,
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#9B7AFF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.5, 1.5)
		}
	} or (p161 == "gravity" and {
		{
			["template"] = "Charge",
			["emitter"] = "Rings",
			["colors"] = nil,
			["rate"] = 1.4,
			["size"] = 0.5,
			["life"] = nil,
			["locked"] = true,
			["colors"] = { v_u_6("#E0B0FF"), v_u_6("#7A2AFF") },
			["life"] = NumberRange.new(0.7, 0.9)
		},
		{
			["template"] = "AuraMode",
			["emitter"] = "Pulse",
			["colors"] = nil,
			["rate"] = 1.2,
			["size"] = 0.6,
			["life"] = nil,
			["locked"] = true,
			["colors"] = { v_u_6("#B06BFF"), v_u_6("#3A0A6A") },
			["life"] = NumberRange.new(0.8, 1)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.9,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -9, 0),
			["light"] = 0,
			["spread"] = true,
			["colors"] = { v_u_6("#4A3A5A"), v_u_6("#0A0614") },
			["life"] = NumberRange.new(0.6, 0.9),
			["speed"] = NumberRange.new(0.5, 1)
		},
		{
			["template"] = "AuraMode",
			["emitter"] = "Crackle",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.5,
			["life"] = nil,
			["locked"] = true,
			["colors"] = { v_u_6("#E0B0FF"), v_u_6("#7A2AFF") },
			["life"] = NumberRange.new(0.1, 0.2)
		}
	} or (p161 == "gasgiant" and {
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(2.5, 0.2, 0),
			["light"] = 0.2,
			["alpha"] = 0.55,
			["spread"] = true,
			["colors"] = { v_u_6("#FFC88A"), v_u_6("#D8783A") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1.8,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(1.5, 0.4, 0),
			["light"] = 0.7,
			["spread"] = true,
			["colors"] = { v_u_6("#FFE9B8"), v_u_6("#FF9A4A") },
			["life"] = NumberRange.new(1.2, 1.8),
			["speed"] = NumberRange.new(0.4, 1)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.2,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.3, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FFD27A") },
			["life"] = NumberRange.new(0.5, 0.9),
			["speed"] = NumberRange.new(0.3, 1)
		}
	} or (p161 == "darkmatter" and {
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 6,
			["size"] = 1,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, -7, 0),
			["light"] = 0.2,
			["spread"] = true,
			["colors"] = { v_u_6("#7A3AC8"), v_u_6("#14041E") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 0.9)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 1.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.8, 0),
			["light"] = 0.5,
			["spread"] = true,
			["colors"] = { v_u_6("#C88BFF"), v_u_6("#4A1A7A") },
			["life"] = NumberRange.new(1, 1.6),
			["speed"] = NumberRange.new(0.3, 0.8)
		},
		{
			["template"] = "Smoke",
			["emitter"] = "Soft",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.3, 0),
			["alpha"] = 0.45,
			["spread"] = true,
			["feet"] = true,
			["colors"] = { v_u_6("#2A0A3A"), v_u_6("#0A0414") },
			["life"] = NumberRange.new(1, 1.4),
			["speed"] = NumberRange.new(0.3, 0.8)
		}
	} or (p161 == "galaxy" and {
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.25,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FF9BE8") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#E8FFFF"), v_u_6("#5AD8FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 1.8,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["light"] = 0.7,
			["spread"] = true,
			["colors"] = { v_u_6("#B08BFF"), v_u_6("#4A2AA8") },
			["life"] = NumberRange.new(1.2, 1.8),
			["speed"] = NumberRange.new(0.4, 1)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 2,
			["size"] = 0.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 2, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFF2B0"), v_u_6("#FFB020") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.5, 1.5)
		}
	} or (p161 == "plasma" and {
		{
			["template"] = "AuraMode",
			["emitter"] = "Crackle",
			["rate"] = 4,
			["size"] = 0.55,
			["life"] = nil,
			["locked"] = true,
			["life"] = NumberRange.new(0.1, 0.2)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["rate"] = 6,
			["size"] = 0.6,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0, 0),
			["light"] = 0.8,
			["spread"] = true,
			["life"] = NumberRange.new(0.4, 0.7),
			["speed"] = NumberRange.new(2, 4)
		},
		{
			["template"] = "AuraMode",
			["emitter"] = "Glow",
			["rate"] = 1.5,
			["size"] = 0.35,
			["life"] = nil,
			["alpha"] = 0.7,
			["locked"] = true,
			["life"] = NumberRange.new(0.5, 0.7)
		}
	} or (p161 == "warp" and {
		{
			["template"] = "Vortex",
			["emitter"] = "Collapse",
			["rate"] = 1,
			["size"] = 0.3,
			["life"] = nil,
			["locked"] = true,
			["life"] = NumberRange.new(0.6, 0.8)
		},
		{
			["template"] = "AuraMode",
			["emitter"] = "Streaks",
			["colors"] = nil,
			["rate"] = 4,
			["size"] = 0.45,
			["life"] = nil,
			["speed"] = nil,
			["colors"] = { v_u_6("#E8FFFF"), v_u_6("#9B4DFF") },
			["life"] = NumberRange.new(0.3, 0.5),
			["speed"] = NumberRange.new(4, 7)
		},
		{
			["template"] = "Petals",
			["emitter"] = "Motes",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 1.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.6, 0),
			["light"] = 0.7,
			["spread"] = true,
			["colors"] = { v_u_6("#5AD8FF"), v_u_6("#B06BFF") },
			["life"] = NumberRange.new(1, 1.6),
			["speed"] = NumberRange.new(0.4, 1)
		}
	} or (p161 == "cosmic" and {
		{
			["template"] = "Aura",
			["emitter"] = "FlameBack",
			["colors"] = nil,
			["rate"] = 8,
			["size"] = 0.6,
			["life"] = nil,
			["light"] = 0.1,
			["alpha"] = 0.25,
			["locked"] = true,
			["colors"] = { v_u_6("#4A1A8A"), v_u_6("#0A0414") },
			["life"] = NumberRange.new(0.5, 0.8)
		},
		{
			["template"] = "Aura",
			["emitter"] = "Sparks",
			["colors"] = nil,
			["rate"] = 5,
			["size"] = 0.7,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 3, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFF2B0"), v_u_6("#FFB020") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(1, 2.5)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.25,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FF9BE8") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		},
		{
			["template"] = "Sparkle",
			["emitter"] = "Stars",
			["colors"] = nil,
			["rate"] = 3,
			["size"] = 0.22,
			["life"] = nil,
			["speed"] = nil,
			["accel"] = Vector3.new(0, 0.4, 0),
			["spread"] = true,
			["colors"] = { v_u_6("#E8FFFF"), v_u_6("#5AD8FF") },
			["life"] = NumberRange.new(0.6, 1),
			["speed"] = NumberRange.new(0.3, 1.2)
		}
	} or {})))))))))))
end
local function v_u_166(p163) -- name: recipes
	-- upvalues: (copy) v_u_160, (copy) v_u_162, (copy) v_u_6
	local v164 = v_u_160(p163)
	if #v164 > 0 then
		return v164
	else
		local v165 = v_u_162(p163)
		if #v165 > 0 then
			return v165
		else
			return p163 == "leaves" and {
				{
					["template"] = "Petals",
					["emitter"] = "Petals",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 1.3,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -1.4, 0),
					["light"] = 0.1,
					["spread"] = true,
					["colors"] = { v_u_6("#A6EB5E"), v_u_6("#4E9E3A") },
					["life"] = NumberRange.new(1.4, 2.2),
					["speed"] = NumberRange.new(0.8, 1.6)
				}
			} or (p163 == "petals" and {
				{
					["template"] = "Petals",
					["emitter"] = "Petals",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 1.3,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -1, 0),
					["light"] = 0.35,
					["spread"] = true,
					["colors"] = { v_u_6("#FFC4E2"), v_u_6("#FF7BC8") },
					["life"] = NumberRange.new(1.4, 2.2),
					["speed"] = NumberRange.new(0.8, 1.6)
				}
			} or (p163 == "sand" and {
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.45,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.6, 0),
					["alpha"] = 0.55,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#E8CC92"), v_u_6("#C9A060") },
					["life"] = NumberRange.new(1, 1.5),
					["speed"] = NumberRange.new(0.5, 1.5)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 2, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFE58A"), v_u_6("#FFB020") },
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(0.5, 1.5)
				}
			} or (p163 == "dust" and {
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.4,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.8, 0),
					["alpha"] = 0.5,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#D49A6A"), v_u_6("#8C5A3A") },
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(0.6, 1.6)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["rate"] = 3,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 2.5, 0),
					["spread"] = true,
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.5, 1.5)
				}
			} or (p163 == "embers" and {
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 8,
					["size"] = 0.7,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 5, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFE14B"), v_u_6("#FF5A1A") },
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(1, 3)
				},
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 0.4,
					["life"] = nil,
					["light"] = 0.6,
					["locked"] = true,
					["colors"] = { v_u_6("#FFB020"), v_u_6("#FF4A1A") },
					["life"] = NumberRange.new(0.4, 0.6)
				}
			} or (p163 == "snow" and {
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -2.5, 0),
					["light"] = 0.4,
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#CFE8FF") },
					["life"] = NumberRange.new(1.2, 1.8),
					["speed"] = NumberRange.new(0.5, 1.5)
				},
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 2,
					["size"] = 0.4,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.3, 0),
					["alpha"] = 0.6,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#F4FBFF"), v_u_6("#CFE8FF") },
					["life"] = NumberRange.new(0.8, 1.2),
					["speed"] = NumberRange.new(0.3, 1)
				}
			} or (p163 == "frost" and {
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.4,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -0.5, 0),
					["alpha"] = 0.6,
					["spread"] = true,
					["colors"] = { v_u_6("#E4F8FF"), v_u_6("#8FD8FF") },
					["life"] = NumberRange.new(0.8, 1.2),
					["speed"] = NumberRange.new(0.3, 1)
				},
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["rate"] = 3,
					["size"] = 0.2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0, 0),
					["spread"] = true,
					["life"] = NumberRange.new(0.5, 0.8),
					["speed"] = NumberRange.new(0.3, 1)
				}
			} or (p163 == "poison" and {
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 0.8,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 3, 0),
					["light"] = 0.6,
					["spread"] = true,
					["colors"] = { v_u_6("#D8FF5A"), v_u_6("#5AD82A") },
					["life"] = NumberRange.new(1, 1.6),
					["speed"] = NumberRange.new(0.4, 1.2)
				},
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 2,
					["size"] = 0.45,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.4, 0),
					["alpha"] = 0.6,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#9CD84A"), v_u_6("#4E7A2A") },
					["life"] = NumberRange.new(1, 1.4),
					["speed"] = NumberRange.new(0.3, 0.8)
				}
			} or (p163 == "shadow" and {
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 8,
					["size"] = 0.55,
					["life"] = nil,
					["light"] = 0,
					["alpha"] = 0.3,
					["locked"] = true,
					["colors"] = { v_u_6("#2A1E3A"), v_u_6("#120C1A") },
					["life"] = NumberRange.new(0.5, 0.8)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 3, 0),
					["spread"] = true,
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.5, 2)
				}
			} or (p163 == "crystal" and {
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["rate"] = 4,
					["size"] = 0.22,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.5, 0),
					["spread"] = true,
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.3, 1.2)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 1.5, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#5AF2FF"), v_u_6("#FF5AF0") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.5, 1.5)
				}
			} or (p163 == "storm" and {
				{
					["template"] = "AuraMode",
					["emitter"] = "Crackle",
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["locked"] = true,
					["life"] = NumberRange.new(0.1, 0.2)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 1, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FFE84A") },
					["life"] = NumberRange.new(0.5, 0.9),
					["speed"] = NumberRange.new(1, 3)
				}
			} or (p163 == "flame" and {
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 9,
					["size"] = 0.5,
					["life"] = nil,
					["light"] = 0.6,
					["locked"] = true,
					["colors"] = { v_u_6("#FF8A3A"), v_u_6("#FF1A2A") },
					["life"] = NumberRange.new(0.45, 0.7)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 0.7,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 4, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFD23A"), v_u_6("#FF3A2A") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(1, 3)
				}
			} or (p163 == "moon" and {
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.4, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#BFD4FF") },
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(0.3, 1)
				},
				{
					["template"] = "Petals",
					["emitter"] = "Motes",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 1.8,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.8, 0),
					["light"] = 0.5,
					["spread"] = true,
					["colors"] = { v_u_6("#E4ECFF"), v_u_6("#8FA8FF") },
					["life"] = NumberRange.new(1.4, 2.2),
					["speed"] = NumberRange.new(0.3, 0.9)
				}
			} or (p163 == "water" and {
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 0.9,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 3, 0),
					["light"] = 0.3,
					["spread"] = true,
					["colors"] = { v_u_6("#F0FCFF"), v_u_6("#6FD8FF") },
					["life"] = NumberRange.new(1, 1.6),
					["speed"] = NumberRange.new(0.3, 0.9)
				},
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 2,
					["size"] = 0.4,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.4, 0),
					["alpha"] = 0.6,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#D8F6FF"), v_u_6("#7FD8F0") },
					["life"] = NumberRange.new(0.8, 1.2),
					["speed"] = NumberRange.new(0.3, 1)
				}
			} or (p163 == "jade" and {
				{
					["template"] = "Petals",
					["emitter"] = "Petals",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 1.2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -1.2, 0),
					["light"] = 0.3,
					["spread"] = true,
					["colors"] = { v_u_6("#8FF0B8"), v_u_6("#2FA868") },
					["life"] = NumberRange.new(1.4, 2.2),
					["speed"] = NumberRange.new(0.8, 1.6)
				},
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.5, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#F0FFF4"), v_u_6("#5FE8A0") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.3, 1)
				}
			} or (p163 == "spores" and {
				{
					["template"] = "Petals",
					["emitter"] = "Motes",
					["rate"] = 7,
					["size"] = 2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.6, 0),
					["light"] = 0.6,
					["spread"] = true,
					["life"] = NumberRange.new(1.6, 2.4),
					["speed"] = NumberRange.new(0.3, 0.8)
				},
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 2,
					["size"] = 0.4,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.4, 0),
					["alpha"] = 0.65,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#C8B0FF"), v_u_6("#5FE0D0") },
					["life"] = NumberRange.new(1, 1.4),
					["speed"] = NumberRange.new(0.3, 0.8)
				}
			} or (p163 == "steam" and {
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.35,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 2, 0),
					["alpha"] = 0.5,
					["spread"] = true,
					["colors"] = { v_u_6("#FAFAFA"), v_u_6("#C8C8C8") },
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(0.5, 1.5)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -2, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFE08A"), v_u_6("#FF8A2A") },
					["life"] = NumberRange.new(0.5, 0.9),
					["speed"] = NumberRange.new(1, 3)
				}
			} or (p163 == "aurora" and {
				{
					["template"] = "Petals",
					["emitter"] = "Motes",
					["colors"] = nil,
					["rate"] = 7,
					["size"] = 2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.8, 0),
					["light"] = 0.6,
					["spread"] = true,
					["colors"] = { v_u_6("#5AFFC8"), v_u_6("#C86BFF") },
					["life"] = NumberRange.new(1.4, 2),
					["speed"] = NumberRange.new(0.4, 1)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -2.5, 0),
					["light"] = 0.4,
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#CFF4FF") },
					["life"] = NumberRange.new(1.2, 1.8),
					["speed"] = NumberRange.new(0.5, 1.5)
				}
			} or (p163 == "spirit" and {
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 0.45,
					["life"] = nil,
					["light"] = 0.4,
					["alpha"] = 0.45,
					["locked"] = true,
					["colors"] = { v_u_6("#D8FFF8"), v_u_6("#5FE8D8") },
					["life"] = NumberRange.new(0.5, 0.8)
				},
				{
					["template"] = "Petals",
					["emitter"] = "Motes",
					["rate"] = 6,
					["size"] = 1.8,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 1.2, 0),
					["light"] = 0.6,
					["spread"] = true,
					["life"] = NumberRange.new(1.2, 1.8),
					["speed"] = NumberRange.new(0.4, 1)
				}
			} or (p163 == "stars" and {
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["colors"] = nil,
					["rate"] = 5,
					["size"] = 0.24,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.3, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#8FD8FF") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.3, 1.2)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.7,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, -4, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFE58A"), v_u_6("#FF8A3A") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(1, 2.5)
				}
			} or (p163 == "void" and {
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 9,
					["size"] = 0.6,
					["life"] = nil,
					["light"] = 0,
					["alpha"] = 0.25,
					["locked"] = true,
					["colors"] = { v_u_6("#3A1060"), v_u_6("#0A0414") },
					["life"] = NumberRange.new(0.5, 0.8)
				},
				{
					["template"] = "AuraMode",
					["emitter"] = "Crackle",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.55,
					["life"] = nil,
					["locked"] = true,
					["colors"] = { v_u_6("#E07AFF"), v_u_6("#7A2AFF") },
					["life"] = NumberRange.new(0.1, 0.2)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 3, 0),
					["spread"] = true,
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.5, 2)
				}
			} or (p163 == "solar" and {
				{
					["template"] = "Aura",
					["emitter"] = "FlameBack",
					["colors"] = nil,
					["rate"] = 8,
					["size"] = 0.5,
					["life"] = nil,
					["light"] = 0.6,
					["locked"] = true,
					["colors"] = { v_u_6("#FFF27A"), v_u_6("#FFB020") },
					["life"] = NumberRange.new(0.45, 0.7)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 6,
					["size"] = 0.7,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 4, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFFFFF"), v_u_6("#FFD23A") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(1, 3)
				}
			} or (p163 == "abyss" and {
				{
					["template"] = "Smoke",
					["emitter"] = "Soft",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.45,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.4, 0),
					["alpha"] = 0.45,
					["spread"] = true,
					["feet"] = true,
					["colors"] = { v_u_6("#1E3A4A"), v_u_6("#0A141E") },
					["life"] = NumberRange.new(1, 1.4),
					["speed"] = NumberRange.new(0.3, 0.8)
				},
				{
					["template"] = "Petals",
					["emitter"] = "Motes",
					["rate"] = 6,
					["size"] = 1.8,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.8, 0),
					["light"] = 0.7,
					["spread"] = true,
					["life"] = NumberRange.new(1.2, 2),
					["speed"] = NumberRange.new(0.3, 0.9)
				}
			} or {
				{
					["template"] = "Sparkle",
					["emitter"] = "Stars",
					["colors"] = nil,
					["rate"] = 3,
					["size"] = 0.2,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 0.5, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFF2B0"), v_u_6("#FFC020") },
					["life"] = NumberRange.new(0.6, 1),
					["speed"] = NumberRange.new(0.3, 1)
				},
				{
					["template"] = "Aura",
					["emitter"] = "Sparks",
					["colors"] = nil,
					["rate"] = 4,
					["size"] = 0.6,
					["life"] = nil,
					["speed"] = nil,
					["accel"] = Vector3.new(0, 2, 0),
					["spread"] = true,
					["colors"] = { v_u_6("#FFE58A"), v_u_6("#FFB020") },
					["life"] = NumberRange.new(0.8, 1.2),
					["speed"] = NumberRange.new(0.5, 1.5)
				}
			}))))))))))))))))))))))
		end
	end
end
local function v_u_176(p167, p168, p169, p170) -- name: emitterFrom
	-- upvalues: (copy) v_u_147, (copy) v_u_156, (copy) v_u_158
	local v171 = v_u_147(p168.template, p168.emitter)
	if not v171 then
		return nil
	end
	local v172 = p167.s
	local v173 = p168.colors
	local v174
	if v173 then
		v174 = ColorSequence.new(v173[1], v173[2])
	else
		v174 = ColorSequence.new(p167.glow)
	end
	v171.Color = v174
	v171.Rate = p168.rate * p170
	v171.Size = v_u_156(v171.Size, p168.size * v172)
	if p168.life then
		v171.Lifetime = p168.life
	end
	local v175 = p168.speed or v171.Speed
	v171.Speed = NumberRange.new(v175.Min * v172, v175.Max * v172)
	if p168.accel then
		v171.Acceleration = p168.accel * math.sqrt(v172)
	end
	if p168.light then
		v171.LightEmission = p168.light
	end
	if p168.alpha then
		v171.Transparency = v_u_158(p168.alpha)
	end
	if p168.spread then
		v171.SpreadAngle = Vector2.new(180, 180)
	end
	if p168.locked ~= nil then
		v171.LockedToPart = p168.locked
	end
	v171.Shape = Enum.ParticleEmitterShape.Box
	v171.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v171.Enabled = true
	v171.Parent = p169
	return v171
end
local function v_u_187(p177, p178, p179, p180, p181) -- name: aura
	-- upvalues: (copy) v_u_166, (copy) v_u_176
	local v182 = {}
	for _, v183 in v_u_166(p177.look.aura) do
		local v184
		if v183.feet then
			v184 = Instance.new("Attachment")
			v184.Name = "Feet"
			local v185 = -p180 + p177.s * 0.4
			v184.Position = Vector3.new(0, v185, 0)
			v184.Parent = p179
		else
			v184 = p178
		end
		local v186 = v_u_176(p177, v183, v184, p181 and 2.2 or 1)
		if not v186 then
			continue
		end
		table.insert(v182, v186)
	end
	return v182
end
local function v_u_204(p188, p189, p190, p191, p192, p193) -- name: eyes
	-- upvalues: (copy) v_u_27
	local v194 = (p193 or 1) * p190 / 1.6
	local v195 = p192 or -p190 / 2 - 0.03
	for _, v196 in { -1, 1 } do
		local v197 = Vector3.new(0.36, 0.2, 0.08) * v194
		local v198 = p188.eye
		local v199 = CFrame.new(v196 * 0.32 * p190 / 1.6, p191, v195) * CFrame.Angles(0, 0, v196 * 0.28)
		local v200 = v_u_27(p188, "Eye", v197, v198, {
			["neon"] = true
		})
		local v201 = p189.CFrame
		local v202 = p188.s
		v200.CFrame = v201 * (v199.Rotation + v199.Position * v202)
		local v203 = Instance.new("WeldConstraint")
		v203.Part0 = p189
		v203.Part1 = v200
		v203.Parent = v200
	end
end
local function v_u_213(p205, p206, p207) -- name: features
	local v208 = Instance.new("SurfaceGui")
	v208.Name = "Face"
	v208.Face = Enum.NormalId.Front
	v208.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
	v208.CanvasSize = Vector2.new(100, 100)
	v208.Parent = p205
	local v209 = Color3.fromRGB(20, 15, 20)
	if p206 then
		for _, v210 in { -1, 1 } do
			local v211 = Instance.new("Frame")
			v211.BorderSizePixel = 0
			v211.BackgroundColor3 = v209
			v211.AnchorPoint = Vector2.new(0.5, 0.5)
			v211.Size = UDim2.fromScale(0.26, 0.07)
			v211.Position = UDim2.fromScale(0.5 + v210 * 0.2, 0.3)
			v211.Rotation = v210 * -18
			v211.Parent = v208
		end
	end
	if p207 then
		local v212 = Instance.new("Frame")
		v212.BorderSizePixel = 0
		v212.BackgroundColor3 = Color3.fromRGB(40, 20, 25)
		v212.AnchorPoint = Vector2.new(0.5, 0.5)
		v212.Size = UDim2.fromScale(0.34, 0.07)
		v212.Position = UDim2.fromScale(0.5, 0.74)
		v212.Parent = v208
	end
end
local function v_u_469(p214, p215, p216) -- name: face3
	-- upvalues: (copy) v_u_7, (copy) v_u_27, (copy) v_u_204, (copy) v_u_213, (copy) v_u_10, (copy) v_u_13, (copy) v_u_57
	local v217 = p214.look.face or "plain"
	local v218 = p216 / 1.6
	local v219 = -p216 / 2
	local v220 = {
		["neon"] = true
	}
	local v221 = CFrame.Angles(0, 0, 0.7853981633974483)
	if v217 == "beak" then
		local v222 = Vector3.new(0.6, 0.34, 0.8) * v218
		local v223 = p214.accent
		local v224 = CFrame.new(0, p216 * -0.12, v219 - v218 * 0.34) * CFrame.Angles(0.12, 0, 0)
		local v225 = Instance.new("Part")
		v225.Name = "Beak"
		v225.Size = v222 * p214.s
		v225.Color = v223
		v225.Material = Enum.Material.Plastic
		v225.CanCollide = false
		v225.CanTouch = false
		v225.CanQuery = false
		v225.Massless = true
		v225.Anchored = false
		v225.CastShadow = v222.Magnitude > 1.1
		v225.TopSurface = Enum.SurfaceType.Smooth
		v225.BottomSurface = Enum.SurfaceType.Smooth
		v225.Parent = p214.model
		local v226 = p215.CFrame
		local v227 = p214.s
		v225.CFrame = v226 * (v224.Rotation + v224.Position * v227)
		local v228 = Instance.new("WeldConstraint")
		v228.Part0 = p215
		v228.Part1 = v225
		v228.Parent = v225
		local v229 = Vector3.new(0.34, 0.3, 0.34) * v218
		local v230 = p214.accent
		local v231 = CFrame.new(0, p216 * -0.2, v219 - v218 * 0.74) * CFrame.Angles(0.7, 0, 0)
		local v232 = Instance.new("Part")
		v232.Name = "BeakTip"
		v232.Size = v229 * p214.s
		v232.Color = v230
		v232.Material = Enum.Material.Plastic
		v232.CanCollide = false
		v232.CanTouch = false
		v232.CanQuery = false
		v232.Massless = true
		v232.Anchored = false
		v232.CastShadow = v229.Magnitude > 1.1
		v232.TopSurface = Enum.SurfaceType.Smooth
		v232.BottomSurface = Enum.SurfaceType.Smooth
		v232.Parent = p214.model
		local v233 = p215.CFrame
		local v234 = p214.s
		v232.CFrame = v233 * (v231.Rotation + v231.Position * v234)
		local v235 = Instance.new("WeldConstraint")
		v235.Part0 = p215
		v235.Part1 = v232
		v235.Parent = v232
		local v236 = Vector3.new(0.48, 0.16, 0.6) * v218
		local v237 = p214.accent:Lerp(v_u_7, 0.3)
		local v238, v239 = CFrame.new(0, p216 * -0.32, v219 - v218 * 0.26)
		local v240 = v_u_27(p214, "BeakLow", v236, v237, v239)
		local v241 = p215.CFrame
		local v242 = p214.s
		v240.CFrame = v241 * (v238.Rotation + v238.Position * v242)
		local v243 = Instance.new("WeldConstraint")
		v243.Part0 = p215
		v243.Part1 = v240
		v243.Parent = v240
		v_u_204(p214, p215, p216, p216 * 0.15, nil, 1.15)
		v_u_213(p215, true, false)
	elseif v217 == "hannya" then
		local v244 = Color3.fromRGB(246, 240, 230)
		local v245 = Color3.fromRGB(242, 201, 74)
		local v246 = p216 * 0.98
		local v247 = p216 * 0.94
		local v248 = Vector3.new(v246, v247, 0.16)
		local v249 = CFrame.new(0, 0, v219 - 0.08)
		local v250 = v_u_27(p214, "Mask", v248, v244, {
			["material"] = Enum.Material.SmoothPlastic
		})
		local v251 = p215.CFrame
		local v252 = p214.s
		v250.CFrame = v251 * (v249.Rotation + v249.Position * v252)
		local v253 = Instance.new("WeldConstraint")
		v253.Part0 = p215
		v253.Part1 = v250
		v253.Parent = v250
		for _, v254 in { -1, 1 } do
			local v255 = Vector3.new(0.2, 0.62, 0.2) * v218
			local v256 = CFrame.new(v254 * 0.36 * v218, p216 * 0.5, v219 - 0.05) * CFrame.Angles(-0.25, 0, -v254 * 0.5)
			local v257 = v_u_27(p214, "MaskHorn", v255, v245, {
				["material"] = Enum.Material.Metal
			})
			local v258 = p215.CFrame
			local v259 = p214.s
			v257.CFrame = v258 * (v256.Rotation + v256.Position * v259)
			local v260 = Instance.new("WeldConstraint")
			v260.Part0 = p215
			v260.Part1 = v257
			v260.Parent = v257
			local v261 = Vector3.new(0.12, 0.3, 0.12) * v218
			local v262 = p214.glow
			local v263 = CFrame.new(0, v218 * 0.42, 0)
			local v264 = v_u_27(p214, "HornTip", v261, v262, v220)
			local v265 = v257.CFrame
			local v266 = p214.s
			v264.CFrame = v265 * (v263.Rotation + v263.Position * v266)
			local v267 = Instance.new("WeldConstraint")
			v267.Part0 = v257
			v267.Part1 = v264
			v267.Parent = v264
			local v268 = Vector3.new(0.44, 0.1, 0.04) * v218
			local v269 = p214.accent
			local v270 = CFrame.new(v254 * 0.3 * v218, p216 * 0.26, v219 - 0.17) * CFrame.Angles(0, 0, v254 * 0.45)
			local v271 = Instance.new("Part")
			v271.Name = "BrowMark"
			v271.Size = v268 * p214.s
			v271.Color = v269
			v271.Material = Enum.Material.Plastic
			v271.CanCollide = false
			v271.CanTouch = false
			v271.CanQuery = false
			v271.Massless = true
			v271.Anchored = false
			v271.CastShadow = v268.Magnitude > 1.1
			v271.TopSurface = Enum.SurfaceType.Smooth
			v271.BottomSurface = Enum.SurfaceType.Smooth
			v271.Parent = p214.model
			local v272 = p215.CFrame
			local v273 = p214.s
			v271.CFrame = v272 * (v270.Rotation + v270.Position * v273)
			local v274 = Instance.new("WeldConstraint")
			v274.Part0 = p215
			v274.Part1 = v271
			v274.Parent = v271
			local v275 = Vector3.new(0.12, 0.3, 0.05) * v218
			local v276, v277 = CFrame.new(v254 * 0.33 * v218, p216 * -0.27, v219 - 0.2)
			local v278 = v_u_27(p214, "Fang", v275, v245, v277)
			local v279 = p215.CFrame
			local v280 = p214.s
			v278.CFrame = v279 * (v276.Rotation + v276.Position * v280)
			local v281 = Instance.new("WeldConstraint")
			v281.Part0 = p215
			v281.Part1 = v278
			v281.Parent = v278
		end
		local v282 = Vector3.new(0.84, 0.24, 0.04) * v218
		local v283 = v_u_7
		local v284, v285 = CFrame.new(0, p216 * -0.27, v219 - 0.17)
		local v286 = v_u_27(p214, "Mouth", v282, v283, v285)
		local v287 = p215.CFrame
		local v288 = p214.s
		v286.CFrame = v287 * (v284.Rotation + v284.Position * v288)
		local v289 = Instance.new("WeldConstraint")
		v289.Part0 = p215
		v289.Part1 = v286
		v289.Parent = v286
		for v290 = -1.5, 1.5 do
			local v291 = Vector3.new(0.11, 0.11, 0.05) * v218
			local v292 = CFrame.new(v290 * 0.15 * v218, p216 * -0.22, v219 - 0.19) * v221
			local v293 = Instance.new("Part")
			v293.Name = "Tooth"
			v293.Size = v291 * p214.s
			v293.Color = v244
			v293.Material = Enum.Material.Plastic
			v293.CanCollide = false
			v293.CanTouch = false
			v293.CanQuery = false
			v293.Massless = true
			v293.Anchored = false
			v293.CastShadow = v291.Magnitude > 1.1
			v293.TopSurface = Enum.SurfaceType.Smooth
			v293.BottomSurface = Enum.SurfaceType.Smooth
			v293.Parent = p214.model
			local v294 = p215.CFrame
			local v295 = p214.s
			v293.CFrame = v294 * (v292.Rotation + v292.Position * v295)
			local v296 = Instance.new("WeldConstraint")
			v296.Part0 = p215
			v296.Part1 = v293
			v296.Parent = v293
		end
		v_u_204(p214, p215, p216, p216 * 0.08, v219 - 0.17, 1.1)
	elseif v217 == "mantis" then
		local v297 = p216 * 0.55
		local v298 = p216 * 0.36
		local v299 = p216 * 0.42
		local v300 = Vector3.new(v297, v298, v299)
		local v301 = p214.skin
		local v302, v303 = CFrame.new(0, -p216 * 0.36, v219 - 0.08)
		local v304 = v_u_27(p214, "InsectJaw", v300, v301, v303)
		local v305 = p215.CFrame
		local v306 = p214.s
		v304.CFrame = v305 * (v302.Rotation + v302.Position * v306)
		local v307 = Instance.new("WeldConstraint")
		v307.Part0 = p215
		v307.Part1 = v304
		v307.Parent = v304
		for _, v308 in { -1, 1 } do
			local v309 = Vector3.new(0.74, 0.74, 0.74) * v218
			local v310 = p214.eye
			local v311 = CFrame.new(v308 * 0.5 * p216, p216 * 0.14, v219 + v218 * 0.3)
			local v312 = v_u_27(p214, "CompoundEye", v309, v310, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v313 = p215.CFrame
			local v314 = p214.s
			v312.CFrame = v313 * (v311.Rotation + v311.Position * v314)
			local v315 = Instance.new("WeldConstraint")
			v315.Part0 = p215
			v315.Part1 = v312
			v315.Parent = v312
			local v316 = Vector3.new(0.14, 0.14, 0.5) * v218
			local v317 = p214.accent
			local v318 = CFrame.new(v308 * 0.16 * v218, -p216 * 0.52, v219 - 0.2) * CFrame.Angles(0, v308 * 0.5, 0)
			local v319 = Instance.new("Part")
			v319.Name = "Mandible"
			v319.Size = v316 * p214.s
			v319.Color = v317
			v319.Material = Enum.Material.Plastic
			v319.CanCollide = false
			v319.CanTouch = false
			v319.CanQuery = false
			v319.Massless = true
			v319.Anchored = false
			v319.CastShadow = v316.Magnitude > 1.1
			v319.TopSurface = Enum.SurfaceType.Smooth
			v319.BottomSurface = Enum.SurfaceType.Smooth
			v319.Parent = p214.model
			local v320 = p215.CFrame
			local v321 = p214.s
			v319.CFrame = v320 * (v318.Rotation + v318.Position * v321)
			local v322 = Instance.new("WeldConstraint")
			v322.Part0 = p215
			v322.Part1 = v319
			v322.Parent = v319
			local v323 = v308 * 0.2 * v218
			local v324 = p216 / 2
			local v325 = v219 + 0.2
			local v326 = Vector3.new(v323, v324, v325)
			local v327 = v308 * 0.45 * v218
			local v328 = p216 / 2 + v218 * 0.9
			local v329 = v219 - 0.25
			local v330 = Vector3.new(v327, v328, v329)
			local v331 = v308 * 0.75 * v218
			local v332 = p216 / 2 + v218 * 1.3
			local v333 = v219 + 0.5
			local v334 = Vector3.new(v331, v332, v333)
			local v335 = p214.skin
			local v336 = (v326 + v330) / 2
			local v337 = (v330 - v326).Magnitude
			local v338 = Vector3.new(0.09, 0.09, v337)
			local v339 = CFrame.lookAt(v336, v330)
			local v340 = Instance.new("Part")
			v340.Name = "Feeler"
			v340.Size = v338 * p214.s
			v340.Color = v335
			v340.Material = Enum.Material.Plastic
			v340.CanCollide = false
			v340.CanTouch = false
			v340.CanQuery = false
			v340.Massless = true
			v340.Anchored = false
			v340.CastShadow = v338.Magnitude > 1.1
			v340.TopSurface = Enum.SurfaceType.Smooth
			v340.BottomSurface = Enum.SurfaceType.Smooth
			v340.Parent = p214.model
			local v341 = p215.CFrame
			local v342 = p214.s
			v340.CFrame = v341 * (v339.Rotation + v339.Position * v342)
			local v343 = Instance.new("WeldConstraint")
			v343.Part0 = p215
			v343.Part1 = v340
			v343.Parent = v340
			local v344 = p214.skin
			local v345 = (v330 + v334) / 2
			local v346 = (v334 - v330).Magnitude
			local v347 = Vector3.new(0.08, 0.08, v346)
			local v348 = CFrame.lookAt(v345, v334)
			local v349 = Instance.new("Part")
			v349.Name = "Feeler"
			v349.Size = v347 * p214.s
			v349.Color = v344
			v349.Material = Enum.Material.Plastic
			v349.CanCollide = false
			v349.CanTouch = false
			v349.CanQuery = false
			v349.Massless = true
			v349.Anchored = false
			v349.CastShadow = v347.Magnitude > 1.1
			v349.TopSurface = Enum.SurfaceType.Smooth
			v349.BottomSurface = Enum.SurfaceType.Smooth
			v349.Parent = p214.model
			local v350 = p215.CFrame
			local v351 = p214.s
			v349.CFrame = v350 * (v348.Rotation + v348.Position * v351)
			local v352 = Instance.new("WeldConstraint")
			v352.Part0 = p215
			v352.Part1 = v349
			v352.Parent = v349
			local v353 = p214.glow
			local v354 = CFrame.new(v334)
			local v355 = v_u_27(p214, "FeelerTip", Vector3.new(0.18, 0.18, 0.18), v353, v220)
			local v356 = p215.CFrame
			local v357 = p214.s
			v355.CFrame = v356 * (v354.Rotation + v354.Position * v357)
			local v358 = Instance.new("WeldConstraint")
			v358.Part0 = p215
			v358.Part1 = v355
			v358.Parent = v355
		end
	elseif v217 == "grin" then
		local v359 = Vector3.new(0.86, 0.26, 0.05) * v218
		local v360 = p214.glow
		local v361 = CFrame.new(0, p216 * -0.26, v219 - 0.02)
		local v362 = v_u_27(p214, "Mouth", v359, v360, v220)
		local v363 = p215.CFrame
		local v364 = p214.s
		v362.CFrame = v363 * (v361.Rotation + v361.Position * v364)
		local v365 = Instance.new("WeldConstraint")
		v365.Part0 = p215
		v365.Part1 = v362
		v365.Parent = v362
		for v366 = -2, 2 do
			local v367 = v366 % 2 == 0
			local v368 = Vector3.new(0.14, 0.14, 0.06) * v218
			local v369 = v_u_10
			local v370 = CFrame.new(v366 * 0.16 * v218, (v367 and -0.19 or -0.33) * p216, v219 - 0.05) * v221
			local v371 = Instance.new("Part")
			v371.Name = "Tooth"
			v371.Size = v368 * p214.s
			v371.Color = v369
			v371.Material = Enum.Material.Plastic
			v371.CanCollide = false
			v371.CanTouch = false
			v371.CanQuery = false
			v371.Massless = true
			v371.Anchored = false
			v371.CastShadow = v368.Magnitude > 1.1
			v371.TopSurface = Enum.SurfaceType.Smooth
			v371.BottomSurface = Enum.SurfaceType.Smooth
			v371.Parent = p214.model
			local v372 = p215.CFrame
			local v373 = p214.s
			v371.CFrame = v372 * (v370.Rotation + v370.Position * v373)
			local v374 = Instance.new("WeldConstraint")
			v374.Part0 = p215
			v374.Part1 = v371
			v374.Parent = v371
		end
		v_u_204(p214, p215, p216, p216 * 0.1, nil, 1.2)
		v_u_213(p215, true, false)
	elseif v217 == "fangs" then
		local v375 = Color3.fromRGB(28, 20, 28)
		local v376 = p216 + 0.06
		local v377 = p216 + 0.06
		local v378 = Vector3.new(v376, 0.3, v377)
		local v379, v380 = CFrame.new(0, p216 / 2 - 0.1, 0)
		local v381 = v_u_27(p214, "Hair", v378, v375, v380)
		local v382 = p215.CFrame
		local v383 = p214.s
		v381.CFrame = v382 * (v379.Rotation + v379.Position * v383)
		local v384 = Instance.new("WeldConstraint")
		v384.Part0 = p215
		v384.Part1 = v381
		v384.Parent = v381
		local v385 = Vector3.new(0.36, 0.36, 0.06) * v218
		local v386 = CFrame.new(0, p216 * 0.36, v219 - 0.02) * v221
		local v387 = Instance.new("Part")
		v387.Name = "Peak"
		v387.Size = v385 * p214.s
		v387.Color = v375
		v387.Material = Enum.Material.Plastic
		v387.CanCollide = false
		v387.CanTouch = false
		v387.CanQuery = false
		v387.Massless = true
		v387.Anchored = false
		v387.CastShadow = v385.Magnitude > 1.1
		v387.TopSurface = Enum.SurfaceType.Smooth
		v387.BottomSurface = Enum.SurfaceType.Smooth
		v387.Parent = p214.model
		local v388 = p215.CFrame
		local v389 = p214.s
		v387.CFrame = v388 * (v386.Rotation + v386.Position * v389)
		local v390 = Instance.new("WeldConstraint")
		v390.Part0 = p215
		v390.Part1 = v387
		v390.Parent = v387
		local v391 = Vector3.new(0.5, 0.06, 0.04) * v218
		local v392 = v_u_7
		local v393, v394 = CFrame.new(0, p216 * -0.27, v219 - 0.02)
		local v395 = v_u_27(p214, "Mouth", v391, v392, v394)
		local v396 = p215.CFrame
		local v397 = p214.s
		v395.CFrame = v396 * (v393.Rotation + v393.Position * v397)
		local v398 = Instance.new("WeldConstraint")
		v398.Part0 = p215
		v398.Part1 = v395
		v398.Parent = v395
		for _, v399 in { -1, 1 } do
			local v400 = Vector3.new(0.09, 0.2, 0.05) * v218
			local v401 = v_u_13
			local v402, v403 = CFrame.new(v399 * 0.13 * v218, p216 * -0.33, v219 - 0.03)
			local v404 = v_u_27(p214, "Fang", v400, v401, v403)
			local v405 = p215.CFrame
			local v406 = p214.s
			v404.CFrame = v405 * (v402.Rotation + v402.Position * v406)
			local v407 = Instance.new("WeldConstraint")
			v407.Part0 = p215
			v407.Part1 = v404
			v407.Parent = v404
		end
		v_u_204(p214, p215, p216, p216 * 0.08)
		v_u_213(p215, true, false)
	elseif v217 == "tentacles" then
		for v408, v409 in {
			-0.42,
			-0.14,
			0.14,
			0.42
		} do
			local v410 = ((v408 == 1 or v408 == 4) and 1 or 1.35) * v218
			local v411 = v_u_57
			local v412 = v218 * 0.22
			local v413 = v218 * 0.22
			local v414 = v411(p214, p215, "Tentacle", Vector3.new(v412, v410, v413), p214.skin, CFrame.new(v409 * v218, p216 * -0.3, v219 - 0.08) * CFrame.Angles(0.15, 0, v409 * 0.5), CFrame.new(0, v410 / 2, 0), Vector3.new(1, 0, 0), 0.22, 2.5 + v408 * 0.3, -0.25)
			local v415 = Vector3.new(0.15, 0.4, 0.15) * v218
			local v416 = p214.glow
			local v417 = CFrame.new(0, -v410 / 2 - v218 * 0.12, -0.06) * CFrame.Angles(-0.5, 0, 0)
			local v418 = v_u_27(p214, "TentacleTip", v415, v416, v220)
			local v419 = v414.CFrame
			local v420 = p214.s
			v418.CFrame = v419 * (v417.Rotation + v417.Position * v420)
			local v421 = Instance.new("WeldConstraint")
			v421.Part0 = v414
			v421.Part1 = v418
			v421.Parent = v418
		end
		v_u_204(p214, p215, p216, p216 * 0.14, nil, 1.1)
		v_u_213(p215, true, false)
	elseif v217 == "eyepatch" then
		local v422 = Color3.fromRGB(30, 26, 30)
		local v423 = p216 + 0.06
		local v424 = p216 + 0.06
		local v425 = Vector3.new(v423, 0.1, v424)
		local v426 = CFrame.new(0, p216 * 0.14, 0) * CFrame.Angles(0, 0, -0.3)
		local v427 = Instance.new("Part")
		v427.Name = "Strap"
		v427.Size = v425 * p214.s
		v427.Color = v422
		v427.Material = Enum.Material.Plastic
		v427.CanCollide = false
		v427.CanTouch = false
		v427.CanQuery = false
		v427.Massless = true
		v427.Anchored = false
		v427.CastShadow = v425.Magnitude > 1.1
		v427.TopSurface = Enum.SurfaceType.Smooth
		v427.BottomSurface = Enum.SurfaceType.Smooth
		v427.Parent = p214.model
		local v428 = p215.CFrame
		local v429 = p214.s
		v427.CFrame = v428 * (v426.Rotation + v426.Position * v429)
		local v430 = Instance.new("WeldConstraint")
		v430.Part0 = p215
		v430.Part1 = v427
		v430.Parent = v427
		local v431 = Vector3.new(0.46, 0.4, 0.06) * v218
		local v432, v433 = CFrame.new(v218 * 0.31, p216 * 0.07, v219 - 0.04)
		local v434 = v_u_27(p214, "Patch", v431, v422, v433)
		local v435 = p215.CFrame
		local v436 = p214.s
		v434.CFrame = v435 * (v432.Rotation + v432.Position * v436)
		local v437 = Instance.new("WeldConstraint")
		v437.Part0 = p215
		v437.Part1 = v434
		v437.Parent = v434
		local v438 = Vector3.new(0.42, 0.24, 0.08) * v218
		local v439 = p214.eye
		local v440 = CFrame.new(v218 * -0.32, p216 * 0.07, v219 - 0.03) * CFrame.Angles(0, 0, -0.28)
		local v441 = v_u_27(p214, "Eye", v438, v439, v220)
		local v442 = p215.CFrame
		local v443 = p214.s
		v441.CFrame = v442 * (v440.Rotation + v440.Position * v443)
		local v444 = Instance.new("WeldConstraint")
		v444.Part0 = p215
		v444.Part1 = v441
		v444.Parent = v441
		v_u_213(p215, true, true)
	else
		if v217 ~= "maw" then
			return false
		end
		for _, v445 in { -1, 1 } do
			local v446 = Vector3.new(0.46, 0.38, 0.05) * v218
			local v447 = v_u_7
			local v448 = CFrame.new(v445 * 0.31 * v218, p216 * 0.1, v219 - 0.01) * CFrame.Angles(0, 0, v445 * 0.2)
			local v449 = Instance.new("Part")
			v449.Name = "Socket"
			v449.Size = v446 * p214.s
			v449.Color = v447
			v449.Material = Enum.Material.Plastic
			v449.CanCollide = false
			v449.CanTouch = false
			v449.CanQuery = false
			v449.Massless = true
			v449.Anchored = false
			v449.CastShadow = v446.Magnitude > 1.1
			v449.TopSurface = Enum.SurfaceType.Smooth
			v449.BottomSurface = Enum.SurfaceType.Smooth
			v449.Parent = p214.model
			local v450 = p215.CFrame
			local v451 = p214.s
			v449.CFrame = v450 * (v448.Rotation + v448.Position * v451)
			local v452 = Instance.new("WeldConstraint")
			v452.Part0 = p215
			v452.Part1 = v449
			v452.Parent = v449
		end
		v_u_204(p214, p215, p216, p216 * 0.1, v219 - 0.05, 0.75)
		local v453 = Vector3.new(0.8, 0.44, 0.05) * v218
		local v454 = p214.glow
		local v455 = CFrame.new(0, p216 * -0.24, v219 - 0.02)
		local v456 = v_u_27(p214, "Maw", v453, v454, v220)
		local v457 = p215.CFrame
		local v458 = p214.s
		v456.CFrame = v457 * (v455.Rotation + v455.Position * v458)
		local v459 = Instance.new("WeldConstraint")
		v459.Part0 = p215
		v459.Part1 = v456
		v459.Parent = v456
		for v460 = -1.5, 1.5 do
			for _, v461 in { 1, -1 } do
				local v462 = Vector3.new(0.14, 0.14, 0.05) * v218
				local v463 = v_u_10
				local v464 = CFrame.new(v460 * 0.18 * v218, p216 * -0.24 + v461 * 0.15 * v218, v219 - 0.05) * v221
				local v465 = Instance.new("Part")
				v465.Name = "Tooth"
				v465.Size = v462 * p214.s
				v465.Color = v463
				v465.Material = Enum.Material.Plastic
				v465.CanCollide = false
				v465.CanTouch = false
				v465.CanQuery = false
				v465.Massless = true
				v465.Anchored = false
				v465.CastShadow = v462.Magnitude > 1.1
				v465.TopSurface = Enum.SurfaceType.Smooth
				v465.BottomSurface = Enum.SurfaceType.Smooth
				v465.Parent = p214.model
				local v466 = p215.CFrame
				local v467 = p214.s
				v465.CFrame = v466 * (v464.Rotation + v464.Position * v467)
				local v468 = Instance.new("WeldConstraint")
				v468.Part0 = p215
				v468.Part1 = v465
				v468.Parent = v465
			end
		end
	end
	return true
end
local function v_u_714(p470, p471, p472) -- name: face
	-- upvalues: (copy) v_u_469, (copy) v_u_204, (copy) v_u_213, (copy) v_u_27, (copy) v_u_10, (copy) v_u_7, (copy) v_u_11
	if v_u_469(p470, p471, p472) then
		return
	else
		local v473 = p470.look.face or "plain"
		local v474 = p472 / 1.6
		local v475 = -p472 / 2
		if v473 == "plain" then
			v_u_204(p470, p471, p472, p472 * 0.06)
			v_u_213(p471, true, true)
			return
		elseif v473 == "cloth" then
			local v476 = p472 + 0.08
			local v477 = p472 * 0.46
			local v478 = p472 + 0.08
			local v479 = Vector3.new(v476, v477, v478)
			local v480 = p470.trim
			local v481 = CFrame.new(0, -p472 * 0.27, 0)
			local v482 = v_u_27(p470, "FaceCloth", v479, v480, {
				["material"] = Enum.Material.Fabric
			})
			local v483 = p471.CFrame
			local v484 = p470.s
			v482.CFrame = v483 * (v481.Rotation + v481.Position * v484)
			local v485 = Instance.new("WeldConstraint")
			v485.Part0 = p471
			v485.Part1 = v482
			v485.Parent = v482
			v_u_204(p470, p471, p472, p472 * 0.1)
			v_u_213(p471, true, false)
			return
		elseif v473 == "anbu" then
			local v486 = p472 * 0.94
			local v487 = p472 * 0.86
			local v488 = Vector3.new(v486, v487, 0.14)
			local v489 = Color3.fromRGB(245, 245, 242)
			local v490 = CFrame.new(0, p472 * 0.02, v475 - 0.07)
			local v491 = v_u_27(p470, "Mask", v488, v489, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v492 = p471.CFrame
			local v493 = p470.s
			v491.CFrame = v492 * (v490.Rotation + v490.Position * v493)
			local v494 = Instance.new("WeldConstraint")
			v494.Part0 = p471
			v494.Part1 = v491
			v494.Parent = v491
			for _, v495 in { -1, 1 } do
				local v496 = Vector3.new(0.1, 0.5, 0.04) * v474
				local v497 = p470.accent
				local v498, v499 = CFrame.new(v495 * 0.36 * v474, p472 * -0.15, v475 - 0.16)
				local v500 = v_u_27(p470, "Stripe", v496, v497, v499)
				local v501 = p471.CFrame
				local v502 = p470.s
				v500.CFrame = v501 * (v498.Rotation + v498.Position * v502)
				local v503 = Instance.new("WeldConstraint")
				v503.Part0 = p471
				v503.Part1 = v500
				v503.Parent = v500
			end
			v_u_204(p470, p471, p472, p472 * 0.08, v475 - 0.16, 0.9)
			return
		elseif v473 == "fox" then
			local v504 = Color3.fromRGB(250, 248, 245)
			local v505 = p472 * 0.94
			local v506 = p472 * 0.88
			local v507 = Vector3.new(v505, v506, 0.14)
			local v508 = CFrame.new(0, p472 * 0.02, v475 - 0.07)
			local v509 = v_u_27(p470, "Mask", v507, v504, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v510 = p471.CFrame
			local v511 = p470.s
			v509.CFrame = v510 * (v508.Rotation + v508.Position * v511)
			local v512 = Instance.new("WeldConstraint")
			v512.Part0 = p471
			v512.Part1 = v509
			v512.Parent = v509
			local v513 = Vector3.new(0.5, 0.4, 0.42) * v474
			local v514 = CFrame.new(0, p472 * -0.22, v475 - v474 * 0.32)
			local v515 = v_u_27(p470, "Muzzle", v513, v504, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v516 = p471.CFrame
			local v517 = p470.s
			v515.CFrame = v516 * (v514.Rotation + v514.Position * v517)
			local v518 = Instance.new("WeldConstraint")
			v518.Part0 = p471
			v518.Part1 = v515
			v518.Parent = v515
			for _, v519 in { -1, 1 } do
				local v520 = Vector3.new(0.07, 0.34, 0.04) * v474
				local v521 = p470.accent
				local v522 = CFrame.new(v519 * 0.42 * v474, p472 * -0.08, v475 - 0.15) * CFrame.Angles(0, 0, v519 * 0.6)
				local v523 = v_u_27(p470, "Mark", v520, v521, {
					["neon"] = true
				})
				local v524 = p471.CFrame
				local v525 = p470.s
				v523.CFrame = v524 * (v522.Rotation + v522.Position * v525)
				local v526 = Instance.new("WeldConstraint")
				v526.Part0 = p471
				v526.Part1 = v523
				v526.Parent = v523
			end
			v_u_204(p470, p471, p472, p472 * 0.08, v475 - 0.16, 0.9)
			return
		elseif v473 == "oni" then
			local v527 = p472 * 0.96
			local v528 = p472 * 0.9
			local v529 = Vector3.new(v527, v528, 0.16)
			local v530 = p470.glow
			local v531 = CFrame.new(0, 0, v475 - 0.08)
			local v532 = v_u_27(p470, "Mask", v529, v530, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v533 = p471.CFrame
			local v534 = p470.s
			v532.CFrame = v533 * (v531.Rotation + v531.Position * v534)
			local v535 = Instance.new("WeldConstraint")
			v535.Part0 = p471
			v535.Part1 = v532
			v535.Parent = v532
			for _, v536 in { -1, 1 } do
				local v537 = Vector3.new(0.16, 0.42, 0.16) * v474
				local v538 = v_u_10
				local v539 = CFrame.new(v536 * 0.36 * v474, p472 * 0.42, v475 - 0.1) * CFrame.Angles(0, 0, -v536 * 0.35)
				local v540 = Instance.new("Part")
				v540.Name = "MaskHorn"
				v540.Size = v537 * p470.s
				v540.Color = v538
				v540.Material = Enum.Material.Plastic
				v540.CanCollide = false
				v540.CanTouch = false
				v540.CanQuery = false
				v540.Massless = true
				v540.Anchored = false
				v540.CastShadow = v537.Magnitude > 1.1
				v540.TopSurface = Enum.SurfaceType.Smooth
				v540.BottomSurface = Enum.SurfaceType.Smooth
				v540.Parent = p470.model
				local v541 = p471.CFrame
				local v542 = p470.s
				v540.CFrame = v541 * (v539.Rotation + v539.Position * v542)
				local v543 = Instance.new("WeldConstraint")
				v543.Part0 = p471
				v543.Part1 = v540
				v543.Parent = v540
				local v544 = Vector3.new(0.12, 0.2, 0.05) * v474
				local v545 = v_u_10
				local v546, v547 = CFrame.new(v536 * 0.2 * v474, p472 * -0.33, v475 - 0.18)
				local v548 = v_u_27(p470, "Fang", v544, v545, v547)
				local v549 = p471.CFrame
				local v550 = p470.s
				v548.CFrame = v549 * (v546.Rotation + v546.Position * v550)
				local v551 = Instance.new("WeldConstraint")
				v551.Part0 = p471
				v551.Part1 = v548
				v551.Parent = v548
			end
			local v552 = Vector3.new(0.7, 0.12, 0.05) * v474
			local v553 = v_u_7
			local v554, v555 = CFrame.new(0, p472 * -0.26, v475 - 0.17)
			local v556 = v_u_27(p470, "Mouth", v552, v553, v555)
			local v557 = p471.CFrame
			local v558 = p470.s
			v556.CFrame = v557 * (v554.Rotation + v554.Position * v558)
			local v559 = Instance.new("WeldConstraint")
			v559.Part0 = p471
			v559.Part1 = v556
			v559.Parent = v556
			v_u_204(p470, p471, p472, p472 * 0.08, v475 - 0.17)
			return
		elseif v473 == "skull" then
			for _, v560 in { -1, 1 } do
				local v561 = Vector3.new(0.44, 0.38, 0.05) * v474
				local v562 = v_u_7
				local v563, v564 = CFrame.new(v560 * 0.3 * v474, p472 * 0.06, v475 - 0.01)
				local v565 = v_u_27(p470, "Socket", v561, v562, v564)
				local v566 = p471.CFrame
				local v567 = p470.s
				v565.CFrame = v566 * (v563.Rotation + v563.Position * v567)
				local v568 = Instance.new("WeldConstraint")
				v568.Part0 = p471
				v568.Part1 = v565
				v568.Parent = v565
			end
			local v569 = Vector3.new(0.16, 0.22, 0.05) * v474
			local v570 = v_u_7
			local v571, v572 = CFrame.new(0, p472 * -0.14, v475 - 0.01)
			local v573 = v_u_27(p470, "Nose", v569, v570, v572)
			local v574 = p471.CFrame
			local v575 = p470.s
			v573.CFrame = v574 * (v571.Rotation + v571.Position * v575)
			local v576 = Instance.new("WeldConstraint")
			v576.Part0 = p471
			v576.Part1 = v573
			v576.Parent = v573
			local v577 = Vector3.new(0.7, 0.07, 0.05) * v474
			local v578 = v_u_7
			local v579, v580 = CFrame.new(0, p472 * -0.32, v475 - 0.01)
			local v581 = v_u_27(p470, "Teeth", v577, v578, v580)
			local v582 = p471.CFrame
			local v583 = p470.s
			v581.CFrame = v582 * (v579.Rotation + v579.Position * v583)
			local v584 = Instance.new("WeldConstraint")
			v584.Part0 = p471
			v584.Part1 = v581
			v584.Parent = v581
			v_u_204(p470, p471, p472, p472 * 0.06, v475 - 0.05, 0.75)
			return
		elseif v473 == "menpo" then
			local v585 = p472 * 0.98
			local v586 = p472 * 0.5
			local v587 = Vector3.new(v585, v586, 0.18)
			local v588 = p470.trim
			local v589 = CFrame.new(0, p472 * -0.26, v475 - 0.06)
			local v590 = v_u_27(p470, "HalfMask", v587, v588, {
				["material"] = Enum.Material.SmoothPlastic
			})
			local v591 = p471.CFrame
			local v592 = p470.s
			v590.CFrame = v591 * (v589.Rotation + v589.Position * v592)
			local v593 = Instance.new("WeldConstraint")
			v593.Part0 = p471
			v593.Part1 = v590
			v593.Parent = v590
			local v594 = Vector3.new(0.62, 0.1, 0.05) * v474
			local v595 = p470.accent
			local v596 = CFrame.new(0, p472 * -0.14, v475 - 0.17)
			local v597 = v_u_27(p470, "Moustache", v594, v595, {
				["material"] = Enum.Material.Metal
			})
			local v598 = p471.CFrame
			local v599 = p470.s
			v597.CFrame = v598 * (v596.Rotation + v596.Position * v599)
			local v600 = Instance.new("WeldConstraint")
			v600.Part0 = p471
			v600.Part1 = v597
			v600.Parent = v597
			v_u_204(p470, p471, p472, p472 * 0.12)
			v_u_213(p471, true, false)
			return
		elseif v473 == "tengu" then
			local v601 = Vector3.new(0.26, 0.26, 1.1) * v474
			local v602 = p470.skin
			local v603, v604 = CFrame.new(0, p472 * -0.05, v475 - v474 * 0.55)
			local v605 = v_u_27(p470, "Nose", v601, v602, v604)
			local v606 = p471.CFrame
			local v607 = p470.s
			v605.CFrame = v606 * (v603.Rotation + v603.Position * v607)
			local v608 = Instance.new("WeldConstraint")
			v608.Part0 = p471
			v608.Part1 = v605
			v608.Parent = v605
			for _, v609 in { -1, 1 } do
				local v610 = Vector3.new(0.46, 0.14, 0.1) * v474
				local v611 = Color3.fromRGB(245, 245, 240)
				local v612 = CFrame.new(v609 * 0.32 * v474, p472 * 0.3, v475 - 0.03) * CFrame.Angles(0, 0, v609 * 0.3)
				local v613 = Instance.new("Part")
				v613.Name = "Brow"
				v613.Size = v610 * p470.s
				v613.Color = v611
				v613.Material = Enum.Material.Plastic
				v613.CanCollide = false
				v613.CanTouch = false
				v613.CanQuery = false
				v613.Massless = true
				v613.Anchored = false
				v613.CastShadow = v610.Magnitude > 1.1
				v613.TopSurface = Enum.SurfaceType.Smooth
				v613.BottomSurface = Enum.SurfaceType.Smooth
				v613.Parent = p470.model
				local v614 = p471.CFrame
				local v615 = p470.s
				v613.CFrame = v614 * (v612.Rotation + v612.Position * v615)
				local v616 = Instance.new("WeldConstraint")
				v616.Part0 = p471
				v616.Part1 = v613
				v616.Parent = v613
			end
			v_u_204(p470, p471, p472, p472 * 0.1)
			v_u_213(p471, false, true)
			return
		elseif v473 == "beard" then
			local v617 = p472 * 0.92
			local v618 = p472 * 0.62
			local v619 = Vector3.new(v617, v618, 0.5)
			local v620 = v_u_11
			local v621 = CFrame.new(0, p472 * -0.45, v475 - 0.15)
			local v622 = v_u_27(p470, "Beard", v619, v620, {
				["material"] = Enum.Material.Fabric
			})
			local v623 = p471.CFrame
			local v624 = p470.s
			v622.CFrame = v623 * (v621.Rotation + v621.Position * v624)
			local v625 = Instance.new("WeldConstraint")
			v625.Part0 = p471
			v625.Part1 = v622
			v625.Parent = v622
			local v626 = p472 * 0.75
			local v627 = Vector3.new(v626, 0.16, 0.2)
			local v628 = v_u_11
			local v629 = CFrame.new(0, p472 * -0.14, v475 - 0.12)
			local v630 = v_u_27(p470, "Moustache", v627, v628, {
				["material"] = Enum.Material.Fabric
			})
			local v631 = p471.CFrame
			local v632 = p470.s
			v630.CFrame = v631 * (v629.Rotation + v629.Position * v632)
			local v633 = Instance.new("WeldConstraint")
			v633.Part0 = p471
			v633.Part1 = v630
			v633.Parent = v630
			v_u_204(p470, p471, p472, p472 * 0.12)
			v_u_213(p471, true, false)
			return
		elseif v473 == "visor" then
			local v634 = Vector3.new(0.95, 0.14, 0.05) * v474
			local v635 = p470.eye
			local v636 = CFrame.new(0, p472 * 0.08, v475 - 0.17)
			local v637 = v_u_27(p470, "Slit", v634, v635, {
				["neon"] = true
			})
			local v638 = p471.CFrame
			local v639 = p470.s
			v637.CFrame = v638 * (v636.Rotation + v636.Position * v639)
			local v640 = Instance.new("WeldConstraint")
			v640.Part0 = p471
			v640.Part1 = v637
			v640.Parent = v637
			local v641 = Vector3.new(0.14, 0.5, 0.05) * v474
			local v642 = p470.eye
			local v643 = CFrame.new(0, p472 * -0.14, v475 - 0.17)
			local v644 = v_u_27(p470, "SlitDown", v641, v642, {
				["neon"] = true
			})
			local v645 = p471.CFrame
			local v646 = p470.s
			v644.CFrame = v645 * (v643.Rotation + v643.Position * v646)
			local v647 = Instance.new("WeldConstraint")
			v647.Part0 = p471
			v647.Part1 = v644
			v647.Parent = v644
			return
		elseif v473 == "panda" then
			for _, v648 in { -1, 1 } do
				local v649 = Vector3.new(0.48, 0.42, 0.05) * v474
				local v650 = p470.arm
				local v651 = CFrame.new(v648 * 0.32 * v474, p472 * 0.04, v475 - 0.01) * CFrame.Angles(0, 0, v648 * 0.35)
				local v652 = Instance.new("Part")
				v652.Name = "Patch"
				v652.Size = v649 * p470.s
				v652.Color = v650
				v652.Material = Enum.Material.Plastic
				v652.CanCollide = false
				v652.CanTouch = false
				v652.CanQuery = false
				v652.Massless = true
				v652.Anchored = false
				v652.CastShadow = v649.Magnitude > 1.1
				v652.TopSurface = Enum.SurfaceType.Smooth
				v652.BottomSurface = Enum.SurfaceType.Smooth
				v652.Parent = p470.model
				local v653 = p471.CFrame
				local v654 = p470.s
				v652.CFrame = v653 * (v651.Rotation + v651.Position * v654)
				local v655 = Instance.new("WeldConstraint")
				v655.Part0 = p471
				v655.Part1 = v652
				v655.Parent = v652
			end
			local v656 = Vector3.new(0.66, 0.44, 0.3) * v474
			local v657 = p470.skin
			local v658, v659 = CFrame.new(0, p472 * -0.25, v475 - 0.13)
			local v660 = v_u_27(p470, "Muzzle", v656, v657, v659)
			local v661 = p471.CFrame
			local v662 = p470.s
			v660.CFrame = v661 * (v658.Rotation + v658.Position * v662)
			local v663 = Instance.new("WeldConstraint")
			v663.Part0 = p471
			v663.Part1 = v660
			v663.Parent = v660
			local v664 = Vector3.new(0.26, 0.14, 0.08) * v474
			local v665 = v_u_7
			local v666, v667 = CFrame.new(0, p472 * -0.15, v475 - 0.3)
			local v668 = v_u_27(p470, "Nose", v664, v665, v667)
			local v669 = p471.CFrame
			local v670 = p470.s
			v668.CFrame = v669 * (v666.Rotation + v666.Position * v670)
			local v671 = Instance.new("WeldConstraint")
			v671.Part0 = p471
			v671.Part1 = v668
			v671.Parent = v668
			v_u_204(p470, p471, p472, p472 * 0.06, v475 - 0.05, 0.8)
			return
		elseif v473 == "snout" then
			local v672 = Vector3.new(0.66, 0.5, 0.9) * v474
			local v673 = p470.skin
			local v674, v675 = CFrame.new(0, p472 * -0.22, v475 - v474 * 0.42)
			local v676 = v_u_27(p470, "Snout", v672, v673, v675)
			local v677 = p471.CFrame
			local v678 = p470.s
			v676.CFrame = v677 * (v674.Rotation + v674.Position * v678)
			local v679 = Instance.new("WeldConstraint")
			v679.Part0 = p471
			v679.Part1 = v676
			v679.Parent = v676
			local v680 = Vector3.new(0.26, 0.18, 0.12) * v474
			local v681 = v_u_7
			local v682, v683 = CFrame.new(0, p472 * -0.08, v475 - v474 * 0.88)
			local v684 = v_u_27(p470, "Nose", v680, v681, v683)
			local v685 = p471.CFrame
			local v686 = p470.s
			v684.CFrame = v685 * (v682.Rotation + v682.Position * v686)
			local v687 = Instance.new("WeldConstraint")
			v687.Part0 = p471
			v687.Part1 = v684
			v687.Parent = v684
			if p470.look.hat == "foxears" then
				for _, v688 in { -1, 1 } do
					local v689 = Vector3.new(0.07, 0.34, 0.04) * v474
					local v690 = p470.glow
					local v691 = CFrame.new(v688 * 0.46 * v474, p472 * -0.12, v475 - 0.02) * CFrame.Angles(0, 0, v688 * 0.6)
					local v692 = v_u_27(p470, "Mark", v689, v690, {
						["neon"] = true
					})
					local v693 = p471.CFrame
					local v694 = p470.s
					v692.CFrame = v693 * (v691.Rotation + v691.Position * v694)
					local v695 = Instance.new("WeldConstraint")
					v695.Part0 = p471
					v695.Part1 = v692
					v695.Parent = v692
				end
			end
			v_u_204(p470, p471, p472, p472 * 0.1)
			v_u_213(p471, true, false)
			return
		elseif v473 == "wraps" then
			for v696, v697 in { 0.33, -0.02, -0.32 } do
				local v698 = p472 + 0.04
				local v699 = p472 + 0.04
				local v700 = Vector3.new(v698, 0.16, v699)
				local v701 = p470.trim
				local v702 = CFrame.new(0, v697 * p472, 0) * CFrame.Angles(0, 0, (v696 - 2) * 0.08)
				local v703 = v_u_27(p470, "Wrap", v700, v701, {
					["material"] = Enum.Material.Fabric
				})
				local v704 = p471.CFrame
				local v705 = p470.s
				v703.CFrame = v704 * (v702.Rotation + v702.Position * v705)
				local v706 = Instance.new("WeldConstraint")
				v706.Part0 = p471
				v706.Part1 = v703
				v706.Parent = v703
			end
			local v707 = Vector3.new(0.3, 0.26, 0.08) * v474
			local v708 = p470.eye
			local v709 = CFrame.new(v474 * 0.3, p472 * 0.13, v475 - 0.03)
			local v710 = v_u_27(p470, "Eye", v707, v708, {
				["neon"] = true
			})
			local v711 = p471.CFrame
			local v712 = p470.s
			v710.CFrame = v711 * (v709.Rotation + v709.Position * v712)
			local v713 = Instance.new("WeldConstraint")
			v713.Part0 = p471
			v713.Part1 = v710
			v713.Parent = v710
		else
			v_u_204(p470, p471, p472, p472 * 0.02, nil, 0.9)
		end
	end
end
local function v_u_1345(p715, p716, p717) -- name: hat
	-- upvalues: (copy) v_u_27, (copy) v_u_57, (copy) v_u_12, (copy) v_u_10, (copy) v_u_11, (copy) v_u_13, (copy) v_u_7, (copy) v_u_114
	local v718 = p715.look.hat
	local v719 = p717 / 2
	local v720 = -p717 / 2
	if v718 == "band" then
		local v721 = Color3.fromRGB(43, 47, 58)
		local v722 = p717 + 0.1
		local v723 = p717 + 0.1
		local v724 = Vector3.new(v722, 0.35, v723)
		local v725, v726 = CFrame.new(0, p717 * 0.34, 0)
		local v727 = v_u_27(p715, "Band", v724, v721, v726)
		local v728 = p716.CFrame
		local v729 = p715.s
		v727.CFrame = v728 * (v725.Rotation + v725.Position * v729)
		local v730 = Instance.new("WeldConstraint")
		v730.Part0 = p716
		v730.Part1 = v727
		v730.Parent = v727
		local v731 = p715.accent
		local v732 = CFrame.new(0, p717 * 0.34, v720 - 0.06)
		local v733 = v_u_27(p715, "Plate", Vector3.new(0.9, 0.38, 0.12), v731, {
			["material"] = Enum.Material.Metal
		})
		local v734 = p716.CFrame
		local v735 = p715.s
		v733.CFrame = v734 * (v732.Rotation + v732.Position * v735)
		local v736 = Instance.new("WeldConstraint")
		v736.Part0 = p716
		v736.Part1 = v733
		v736.Parent = v733
		v_u_57(p715, p716, "BandTail", Vector3.new(0.32, 0.1, 1.1), v721, CFrame.new(0.2, p717 * 0.34, p717 / 2 + 0.05) * CFrame.Angles(0.5, 0.15, 0), CFrame.new(0, 0, -0.55), Vector3.new(1, 0, 0), 0.25, 7, -0.4)
		return
	elseif v718 == "bandana" then
		local v737 = p717 + 0.1
		local v738 = p717 + 0.1
		local v739 = Vector3.new(v737, 0.5, v738)
		local v740 = p715.accent
		local v741, v742 = CFrame.new(0, p717 * 0.26, 0)
		local v743 = v_u_27(p715, "Bandana", v739, v740, v742)
		local v744 = p716.CFrame
		local v745 = p715.s
		v743.CFrame = v744 * (v741.Rotation + v741.Position * v745)
		local v746 = Instance.new("WeldConstraint")
		v746.Part0 = p716
		v746.Part1 = v743
		v746.Parent = v743
		local v747 = p715.accent
		local v748, v749 = CFrame.new(0, p717 * 0.26, p717 / 2 + 0.2)
		local v750 = v_u_27(p715, "Knot", Vector3.new(0.5, 0.45, 0.4), v747, v749)
		local v751 = p716.CFrame
		local v752 = p715.s
		v750.CFrame = v751 * (v748.Rotation + v748.Position * v752)
		local v753 = Instance.new("WeldConstraint")
		v753.Part0 = p716
		v753.Part1 = v750
		v753.Parent = v750
		v_u_57(p715, p716, "BandanaTail", Vector3.new(0.4, 0.1, 1.1), p715.accent, CFrame.new(0, p717 * 0.2, p717 / 2 + 0.3) * CFrame.Angles(0.6, 0, 0), CFrame.new(0, 0, -0.55), Vector3.new(1, 0, 0), 0.25, 7, -0.4)
		return
	elseif v718 == "hood" then
		local v754 = p717 + 0.3
		local v755 = p717 + 0.3
		local v756 = Vector3.new(v754, 0.6, v755)
		local v757 = p715.shirt
		local v758 = CFrame.new(0, v719 + 0.15, 0.1)
		local v759 = v_u_27(p715, "Hood", v756, v757, {
			["material"] = Enum.Material.Fabric
		})
		local v760 = p716.CFrame
		local v761 = p715.s
		v759.CFrame = v760 * (v758.Rotation + v758.Position * v761)
		local v762 = Instance.new("WeldConstraint")
		v762.Part0 = p716
		v762.Part1 = v759
		v762.Parent = v759
		local v763 = p717 + 0.3
		local v764 = Vector3.new(v763, p717, 0.4)
		local v765 = p715.shirt
		local v766 = CFrame.new(0, 0, p717 / 2 + 0.1)
		local v767 = v_u_27(p715, "HoodBack", v764, v765, {
			["material"] = Enum.Material.Fabric
		})
		local v768 = p716.CFrame
		local v769 = p715.s
		v767.CFrame = v768 * (v766.Rotation + v766.Position * v769)
		local v770 = Instance.new("WeldConstraint")
		v770.Part0 = p716
		v770.Part1 = v767
		v770.Parent = v767
		for _, v771 in { -1, 1 } do
			local v772 = p717 * 0.85
			local v773 = p717 + 0.2
			local v774 = Vector3.new(0.18, v772, v773)
			local v775 = p715.shirt
			local v776 = CFrame.new(v771 * (p717 / 2 + 0.1), p717 * 0.05, 0.1)
			local v777 = v_u_27(p715, "HoodSide", v774, v775, {
				["material"] = Enum.Material.Fabric
			})
			local v778 = p716.CFrame
			local v779 = p715.s
			v777.CFrame = v778 * (v776.Rotation + v776.Position * v779)
			local v780 = Instance.new("WeldConstraint")
			v780.Part0 = p716
			v780.Part1 = v777
			v780.Parent = v777
		end
		return
	elseif v718 == "cowl" then
		local v781 = {
			["material"] = Enum.Material.Fabric
		}
		local v782 = p717 + 0.5
		local v783 = p717 + 0.5
		local v784 = Vector3.new(v782, 0.5, v783)
		local v785 = p715.shirt
		local v786 = CFrame.new(0, v719 + 0.15, 0.05)
		local v787 = v_u_27(p715, "Cowl", v784, v785, v781)
		local v788 = p716.CFrame
		local v789 = p715.s
		v787.CFrame = v788 * (v786.Rotation + v786.Position * v789)
		local v790 = Instance.new("WeldConstraint")
		v790.Part0 = p716
		v790.Part1 = v787
		v790.Parent = v787
		local v791 = p717 + 0.5
		local v792 = p717 + 0.3
		local v793 = Vector3.new(v791, v792, 0.3)
		local v794 = p715.shirt
		local v795 = CFrame.new(0, -0.05, p717 / 2 + 0.15)
		local v796 = v_u_27(p715, "CowlBack", v793, v794, v781)
		local v797 = p716.CFrame
		local v798 = p715.s
		v796.CFrame = v797 * (v795.Rotation + v795.Position * v798)
		local v799 = Instance.new("WeldConstraint")
		v799.Part0 = p716
		v799.Part1 = v796
		v799.Parent = v796
		for _, v800 in { -1, 1 } do
			local v801 = p717 + 0.3
			local v802 = p717 + 0.5
			local v803 = Vector3.new(0.28, v801, v802)
			local v804 = p715.shirt
			local v805 = CFrame.new(v800 * (p717 / 2 + 0.14), -0.05, 0.05)
			local v806 = v_u_27(p715, "CowlSide", v803, v804, v781)
			local v807 = p716.CFrame
			local v808 = p715.s
			v806.CFrame = v807 * (v805.Rotation + v805.Position * v808)
			local v809 = Instance.new("WeldConstraint")
			v809.Part0 = p716
			v809.Part1 = v806
			v809.Parent = v806
		end
		local v810 = p715.shirt
		local v811 = CFrame.new(0, v719 + 0.35, p717 / 2 - 0.05) * CFrame.Angles(0.7, 0, 0)
		local v812 = v_u_27(p715, "CowlTip", Vector3.new(0.6, 0.7, 0.6), v810, v781)
		local v813 = p716.CFrame
		local v814 = p715.s
		v812.CFrame = v813 * (v811.Rotation + v811.Position * v814)
		local v815 = Instance.new("WeldConstraint")
		v815.Part0 = p716
		v815.Part1 = v812
		v815.Parent = v812
		return
	elseif v718 == "kasa" then
		local v816 = CFrame.new(0, v719, 0) * CFrame.Angles(-0.1, 0, 0)
		local v817 = CFrame.Angles(0, 0, 1.5707963267948966)
		local v818 = {
			["shape"] = Enum.PartType.Cylinder
		}
		for v819, v820 in {
			3.7,
			2.9,
			2.1,
			1.3,
			0.55
		} do
			local v821 = Vector3.new(0.17, v820, v820)
			local v822 = v_u_12:Lerp(Color3.new(0, 0, 0), (v819 - 1) * 0.04)
			local v823 = v816 * CFrame.new(0, 0.06 + (v819 - 1) * 0.15, 0) * v817
			local v824 = v_u_27(p715, "Kasa", v821, v822, v818)
			local v825 = p716.CFrame
			local v826 = p715.s
			v824.CFrame = v825 * (v823.Rotation + v823.Position * v826)
			local v827 = Instance.new("WeldConstraint")
			v827.Part0 = p716
			v827.Part1 = v824
			v827.Parent = v824
		end
		return
	elseif v718 == "kabuto" then
		local v828 = p717 + 0.3
		local v829 = p717 + 0.3
		local v830 = Vector3.new(v828, 0.7, v829)
		local v831 = p715.shirt
		local v832 = CFrame.new(0, v719 + 0.1, 0)
		local v833 = v_u_27(p715, "Kabuto", v830, v831, {
			["studs"] = true
		})
		local v834 = p716.CFrame
		local v835 = p715.s
		v833.CFrame = v834 * (v832.Rotation + v832.Position * v835)
		local v836 = Instance.new("WeldConstraint")
		v836.Part0 = p716
		v836.Part1 = v833
		v836.Parent = v833
		local v837 = p717 + 0.9
		local v838 = p717 + 0.5
		local v839 = Vector3.new(v837, 0.55, v838)
		local v840 = p715.shirt
		local v841, v842 = CFrame.new(0, v719 - 0.3, 0.25)
		local v843 = v_u_27(p715, "Shikoro", v839, v840, v842)
		local v844 = p716.CFrame
		local v845 = p715.s
		v843.CFrame = v844 * (v841.Rotation + v841.Position * v845)
		local v846 = Instance.new("WeldConstraint")
		v846.Part0 = p716
		v846.Part1 = v843
		v846.Parent = v843
		local v847 = p717 + 1.1
		local v848 = p717 + 0.7
		local v849 = Vector3.new(v847, 0.14, v848)
		local v850 = p715.trim
		local v851, v852 = CFrame.new(0, v719 - 0.58, 0.3)
		local v853 = v_u_27(p715, "ShikoroEdge", v849, v850, v852)
		local v854 = p716.CFrame
		local v855 = p715.s
		v853.CFrame = v854 * (v851.Rotation + v851.Position * v855)
		local v856 = Instance.new("WeldConstraint")
		v856.Part0 = p716
		v856.Part1 = v853
		v856.Parent = v853
		local v857 = p717 + 0.2
		local v858 = Vector3.new(v857, 0.12, 0.5)
		local v859 = p715.accent
		local v860 = CFrame.new(0, v719 - 0.05, v720 - 0.15)
		local v861 = v_u_27(p715, "Visor", v858, v859, {
			["material"] = Enum.Material.Metal
		})
		local v862 = p716.CFrame
		local v863 = p715.s
		v861.CFrame = v862 * (v860.Rotation + v860.Position * v863)
		local v864 = Instance.new("WeldConstraint")
		v864.Part0 = p716
		v864.Part1 = v861
		v864.Parent = v861
		for _, v865 in { -1, 1 } do
			local v866 = p715.accent
			local v867 = CFrame.new(v865 * 0.38, v719 + 0.8, v720 - 0.1) * CFrame.Angles(0, 0, -v865 * 0.45)
			local v868 = v_u_27(p715, "Crest", Vector3.new(0.18, 1.4, 0.1), v866, {
				["material"] = Enum.Material.Metal
			})
			local v869 = p716.CFrame
			local v870 = p715.s
			v868.CFrame = v869 * (v867.Rotation + v867.Position * v870)
			local v871 = Instance.new("WeldConstraint")
			v871.Part0 = p716
			v871.Part1 = v868
			v871.Parent = v868
		end
		local v872 = p715.glow
		local v873 = CFrame.new(0, v719 + 0.28, v720 - 0.2) * CFrame.Angles(0, 0, 0.7853981633974483)
		local v874 = v_u_27(p715, "Emblem", Vector3.new(0.34, 0.34, 0.1), v872, {
			["neon"] = true
		})
		local v875 = p716.CFrame
		local v876 = p715.s
		v874.CFrame = v875 * (v873.Rotation + v873.Position * v876)
		local v877 = Instance.new("WeldConstraint")
		v877.Part0 = p716
		v877.Part1 = v874
		v877.Parent = v874
		return
	elseif v718 == "crown" or v718 == "icecrown" then
		local v878 = v718 == "icecrown"
		local v879 = p717 + 0.15
		local v880 = p717 + 0.15
		local v881 = Vector3.new(v879, 0.35, v880)
		local v882 = p715.accent
		local v883 = CFrame.new(0, v719 + 0.05, 0)
		local v884 = v_u_27(p715, "Crown", v881, v882, {
			["material"] = Enum.Material.Metal
		})
		local v885 = p716.CFrame
		local v886 = p715.s
		v884.CFrame = v885 * (v883.Rotation + v883.Position * v886)
		local v887 = Instance.new("WeldConstraint")
		v887.Part0 = p716
		v887.Part1 = v884
		v887.Parent = v884
		for _, v888 in {
			{
				0,
				0.75,
				1.25,
				0
			},
			{
				0.5,
				0.55,
				0.85,
				-0.2
			},
			{
				-0.5,
				0.55,
				0.85,
				0.2
			},
			{
				0.85,
				0.45,
				0.65,
				-0.35
			},
			{
				-0.85,
				0.45,
				0.65,
				0.35
			}
		} do
			local v889 = v888[3]
			local v890 = Vector3.new(0.28, v889, 0.28)
			local v891
			if v878 then
				v891 = p715.glow
			else
				v891 = p715.accent
			end
			local v892 = CFrame.new(v888[1] * p717 / 1.6, v719 + v888[2], v720 + 0.1) * CFrame.Angles(0, 0, v888[4]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v893 = v_u_27(p715, "Spike", v890, v891, v878 and {
				["neon"] = true
			} or {
				["material"] = Enum.Material.Metal
			})
			local v894 = p716.CFrame
			local v895 = p715.s
			v893.CFrame = v894 * (v892.Rotation + v892.Position * v895)
			local v896 = Instance.new("WeldConstraint")
			v896.Part0 = p716
			v896.Part1 = v893
			v896.Parent = v893
		end
		return
	elseif v718 == "pandaears" then
		for _, v897 in { -1, 1 } do
			local v898 = p715.arm
			local v899 = CFrame.new(v897 * 0.62 * p717 / 1.6, v719 + 0.15, 0.1) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v900 = v_u_27(p715, "Ear", Vector3.new(0.3, 0.7, 0.7), v898, {
				["shape"] = Enum.PartType.Cylinder
			})
			local v901 = p716.CFrame
			local v902 = p715.s
			v900.CFrame = v901 * (v899.Rotation + v899.Position * v902)
			local v903 = Instance.new("WeldConstraint")
			v903.Part0 = p716
			v903.Part1 = v900
			v903.Parent = v900
		end
		return
	elseif v718 == "foxears" then
		for _, v904 in { -1, 1 } do
			local v905 = p715.skin
			local v906 = CFrame.new(v904 * 0.47 * p717 / 1.6, v719 + 0.02, 0.1) * CFrame.Angles(0, 0, 0.7853981633974483 - v904 * 0.12)
			local v907 = Instance.new("Part")
			v907.Name = "Ear"
			v907.Size = Vector3.new(0.62, 0.62, 0.24) * p715.s
			v907.Color = v905
			v907.Material = Enum.Material.Plastic
			v907.CanCollide = false
			v907.CanTouch = false
			v907.CanQuery = false
			v907.Massless = true
			v907.Anchored = false
			v907.CastShadow = (Vector3.new(0.62, 0.62, 0.24)).Magnitude > 1.1
			v907.TopSurface = Enum.SurfaceType.Smooth
			v907.BottomSurface = Enum.SurfaceType.Smooth
			v907.Parent = p715.model
			local v908 = p716.CFrame
			local v909 = p715.s
			v907.CFrame = v908 * (v906.Rotation + v906.Position * v909)
			local v910 = Instance.new("WeldConstraint")
			v910.Part0 = p716
			v910.Part1 = v907
			v910.Parent = v907
			local v911 = p715.trim
			local v912, v913 = CFrame.new(0.06, 0.06, -0.14)
			local v914 = v_u_27(p715, "EarInner", Vector3.new(0.36, 0.36, 0.05), v911, v913)
			local v915 = v907.CFrame
			local v916 = p715.s
			v914.CFrame = v915 * (v912.Rotation + v912.Position * v916)
			local v917 = Instance.new("WeldConstraint")
			v917.Part0 = v907
			v917.Part1 = v914
			v917.Parent = v914
		end
		return
	elseif v718 == "turban" then
		local v918 = p717 + 0.3
		local v919 = p717 + 0.3
		local v920 = Vector3.new(v918, 0.75, v919)
		local v921 = p715.pants
		local v922 = CFrame.new(0, v719 + 0.1, 0)
		local v923 = v_u_27(p715, "Turban", v920, v921, {
			["material"] = Enum.Material.Fabric
		})
		local v924 = p716.CFrame
		local v925 = p715.s
		v923.CFrame = v924 * (v922.Rotation + v922.Position * v925)
		local v926 = Instance.new("WeldConstraint")
		v926.Part0 = p716
		v926.Part1 = v923
		v926.Parent = v923
		local v927 = Vector3.new(p717, 0.45, p717)
		local v928 = p715.pants
		local v929 = CFrame.new(0, v719 + 0.55, 0.05)
		local v930 = v_u_27(p715, "TurbanTop", v927, v928, {
			["material"] = Enum.Material.Fabric
		})
		local v931 = p716.CFrame
		local v932 = p715.s
		v930.CFrame = v931 * (v929.Rotation + v929.Position * v932)
		local v933 = Instance.new("WeldConstraint")
		v933.Part0 = p716
		v933.Part1 = v930
		v933.Parent = v930
		local v934 = p715.accent
		local v935 = CFrame.new(0, v719 + 0.15, v720 - 0.17)
		local v936 = v_u_27(p715, "Setting", Vector3.new(0.45, 0.5, 0.06), v934, {
			["material"] = Enum.Material.Metal
		})
		local v937 = p716.CFrame
		local v938 = p715.s
		v936.CFrame = v937 * (v935.Rotation + v935.Position * v938)
		local v939 = Instance.new("WeldConstraint")
		v939.Part0 = p716
		v939.Part1 = v936
		v939.Parent = v936
		local v940 = p715.glow
		local v941 = CFrame.new(0, v719 + 0.15, v720 - 0.2)
		local v942 = v_u_27(p715, "Gem", Vector3.new(0.28, 0.34, 0.1), v940, {
			["neon"] = true
		})
		local v943 = p716.CFrame
		local v944 = p715.s
		v942.CFrame = v943 * (v941.Rotation + v941.Position * v944)
		local v945 = Instance.new("WeldConstraint")
		v945.Part0 = p716
		v945.Part1 = v942
		v945.Parent = v942
		return
	elseif v718 == "nemes" then
		local v946 = p717 + 0.2
		local v947 = p717 + 0.25
		local v948 = Vector3.new(v946, 0.45, v947)
		local v949 = p715.trim
		local v950, v951 = CFrame.new(0, v719 + 0.12, 0.02)
		local v952 = v_u_27(p715, "Nemes", v948, v949, v951)
		local v953 = p716.CFrame
		local v954 = p715.s
		v952.CFrame = v953 * (v950.Rotation + v950.Position * v954)
		local v955 = Instance.new("WeldConstraint")
		v955.Part0 = p716
		v955.Part1 = v952
		v955.Parent = v952
		local v956 = p717 + 0.24
		local v957 = p717 + 0.29
		local v958 = Vector3.new(v956, 0.14, v957)
		local v959 = p715.accent
		local v960 = CFrame.new(0, v719 - 0.05, 0.02)
		local v961 = v_u_27(p715, "NemesBand", v958, v959, {
			["material"] = Enum.Material.Metal
		})
		local v962 = p716.CFrame
		local v963 = p715.s
		v961.CFrame = v962 * (v960.Rotation + v960.Position * v963)
		local v964 = Instance.new("WeldConstraint")
		v964.Part0 = p716
		v964.Part1 = v961
		v964.Parent = v961
		for _, v965 in { -1, 1 } do
			local v966 = p717 * 1.15
			local v967 = Vector3.new(0.25, v966, 0.85)
			local v968 = p715.trim
			local v969, v970 = CFrame.new(v965 * (p717 / 2 + 0.15), p717 * -0.25, 0.05)
			local v971 = v_u_27(p715, "Lappet", v967, v968, v970)
			local v972 = p716.CFrame
			local v973 = p715.s
			v971.CFrame = v972 * (v969.Rotation + v969.Position * v973)
			local v974 = Instance.new("WeldConstraint")
			v974.Part0 = p716
			v974.Part1 = v971
			v974.Parent = v971
		end
		local v975 = p717 * 0.6
		local v976 = p717 * 0.9
		local v977 = Vector3.new(v975, v976, 0.3)
		local v978 = p715.trim
		local v979, v980 = CFrame.new(0, p717 * -0.2, p717 / 2 + 0.15)
		local v981 = v_u_27(p715, "NemesBack", v977, v978, v980)
		local v982 = p716.CFrame
		local v983 = p715.s
		v981.CFrame = v982 * (v979.Rotation + v979.Position * v983)
		local v984 = Instance.new("WeldConstraint")
		v984.Part0 = p716
		v984.Part1 = v981
		v984.Parent = v981
		local v985 = p715.glow
		local v986 = CFrame.new(0, v719 + 0.28, v720 - 0.12)
		local v987 = v_u_27(p715, "Cobra", Vector3.new(0.2, 0.45, 0.16), v985, {
			["neon"] = true
		})
		local v988 = p716.CFrame
		local v989 = p715.s
		v987.CFrame = v988 * (v986.Rotation + v986.Position * v989)
		local v990 = Instance.new("WeldConstraint")
		v990.Part0 = p716
		v990.Part1 = v987
		v990.Parent = v987
		local v991 = p715.accent
		local v992 = CFrame.new(0, -p717 / 2 - 0.25, v720 + 0.12)
		local v993 = v_u_27(p715, "Beard", Vector3.new(0.26, 0.65, 0.22), v991, {
			["material"] = Enum.Material.Metal
		})
		local v994 = p716.CFrame
		local v995 = p715.s
		v993.CFrame = v994 * (v992.Rotation + v992.Position * v995)
		local v996 = Instance.new("WeldConstraint")
		v996.Part0 = p716
		v996.Part1 = v993
		v996.Parent = v993
		return
	elseif v718 == "horns" then
		for _, v997 in { -1, 1 } do
			local v998 = v_u_10
			local v999 = CFrame.new(v997 * 0.5 * p717 / 1.6, v719 + 0.2, -0.1) * CFrame.Angles(0, 0, -v997 * 0.35)
			local v1000 = Instance.new("Part")
			v1000.Name = "Horn"
			v1000.Size = Vector3.new(0.36, 0.55, 0.36) * p715.s
			v1000.Color = v998
			v1000.Material = Enum.Material.Plastic
			v1000.CanCollide = false
			v1000.CanTouch = false
			v1000.CanQuery = false
			v1000.Massless = true
			v1000.Anchored = false
			v1000.CastShadow = (Vector3.new(0.36, 0.55, 0.36)).Magnitude > 1.1
			v1000.TopSurface = Enum.SurfaceType.Smooth
			v1000.BottomSurface = Enum.SurfaceType.Smooth
			v1000.Parent = p715.model
			local v1001 = p716.CFrame
			local v1002 = p715.s
			v1000.CFrame = v1001 * (v999.Rotation + v999.Position * v1002)
			local v1003 = Instance.new("WeldConstraint")
			v1003.Part0 = p716
			v1003.Part1 = v1000
			v1003.Parent = v1000
			local v1004 = p715.glow
			local v1005 = CFrame.new(0, 0.48, 0)
			local v1006 = v_u_27(p715, "HornTip", Vector3.new(0.22, 0.5, 0.22), v1004, {
				["neon"] = true
			})
			local v1007 = v1000.CFrame
			local v1008 = p715.s
			v1006.CFrame = v1007 * (v1005.Rotation + v1005.Position * v1008)
			local v1009 = Instance.new("WeldConstraint")
			v1009.Part0 = v1000
			v1009.Part1 = v1006
			v1009.Parent = v1006
		end
		return
	elseif v718 == "bighorns" then
		for _, v1010 in { -1, 1 } do
			local v1011 = p715.accent
			local v1012 = CFrame.new(v1010 * (p717 / 2 + 0.35), v719 - 0.05, 0) * CFrame.Angles(0, 0, v1010 * 0.35)
			local v1013 = Instance.new("Part")
			v1013.Name = "Horn"
			v1013.Size = Vector3.new(0.9, 0.5, 0.5) * p715.s
			v1013.Color = v1011
			v1013.Material = Enum.Material.Plastic
			v1013.CanCollide = false
			v1013.CanTouch = false
			v1013.CanQuery = false
			v1013.Massless = true
			v1013.Anchored = false
			v1013.CastShadow = (Vector3.new(0.9, 0.5, 0.5)).Magnitude > 1.1
			v1013.TopSurface = Enum.SurfaceType.Smooth
			v1013.BottomSurface = Enum.SurfaceType.Smooth
			v1013.Parent = p715.model
			local v1014 = p716.CFrame
			local v1015 = p715.s
			v1013.CFrame = v1014 * (v1012.Rotation + v1012.Position * v1015)
			local v1016 = Instance.new("WeldConstraint")
			v1016.Part0 = p716
			v1016.Part1 = v1013
			v1016.Parent = v1013
			local v1017 = p715.accent
			local v1018 = CFrame.new(v1010 * 0.4, -0.4, -0.15) * CFrame.Angles(0.3, 0, v1010 * 0.3)
			local v1019 = Instance.new("Part")
			v1019.Name = "HornCurl"
			v1019.Size = Vector3.new(0.42, 0.9, 0.42) * p715.s
			v1019.Color = v1017
			v1019.Material = Enum.Material.Plastic
			v1019.CanCollide = false
			v1019.CanTouch = false
			v1019.CanQuery = false
			v1019.Massless = true
			v1019.Anchored = false
			v1019.CastShadow = (Vector3.new(0.42, 0.9, 0.42)).Magnitude > 1.1
			v1019.TopSurface = Enum.SurfaceType.Smooth
			v1019.BottomSurface = Enum.SurfaceType.Smooth
			v1019.Parent = p715.model
			local v1020 = v1013.CFrame
			local v1021 = p715.s
			v1019.CFrame = v1020 * (v1018.Rotation + v1018.Position * v1021)
			local v1022 = Instance.new("WeldConstraint")
			v1022.Part0 = v1013
			v1022.Part1 = v1019
			v1022.Parent = v1019
		end
		return
	elseif v718 == "jackal" then
		local v1023 = p717 + 0.06
		local v1024 = p717 + 0.06
		local v1025 = Vector3.new(v1023, 0.18, v1024)
		local v1026 = p715.accent
		local v1027 = CFrame.new(0, p717 * 0.25, 0)
		local v1028 = v_u_27(p715, "Band", v1025, v1026, {
			["material"] = Enum.Material.Metal
		})
		local v1029 = p716.CFrame
		local v1030 = p715.s
		v1028.CFrame = v1029 * (v1027.Rotation + v1027.Position * v1030)
		local v1031 = Instance.new("WeldConstraint")
		v1031.Part0 = p716
		v1031.Part1 = v1028
		v1031.Parent = v1028
		for _, v1032 in { -1, 1 } do
			local v1033 = p715.skin
			local v1034 = CFrame.new(v1032 * 0.45 * p717 / 1.6, v719 + 0.48, 0.15) * CFrame.Angles(0, 0, -v1032 * 0.15)
			local v1035 = Instance.new("Part")
			v1035.Name = "Ear"
			v1035.Size = Vector3.new(0.34, 1.15, 0.2) * p715.s
			v1035.Color = v1033
			v1035.Material = Enum.Material.Plastic
			v1035.CanCollide = false
			v1035.CanTouch = false
			v1035.CanQuery = false
			v1035.Massless = true
			v1035.Anchored = false
			v1035.CastShadow = (Vector3.new(0.34, 1.15, 0.2)).Magnitude > 1.1
			v1035.TopSurface = Enum.SurfaceType.Smooth
			v1035.BottomSurface = Enum.SurfaceType.Smooth
			v1035.Parent = p715.model
			local v1036 = p716.CFrame
			local v1037 = p715.s
			v1035.CFrame = v1036 * (v1034.Rotation + v1034.Position * v1037)
			local v1038 = Instance.new("WeldConstraint")
			v1038.Part0 = p716
			v1038.Part1 = v1035
			v1038.Parent = v1035
			local v1039 = p715.accent
			local v1040, v1041 = CFrame.new(0, -0.05, -0.12)
			local v1042 = v_u_27(p715, "EarInner", Vector3.new(0.16, 0.75, 0.05), v1039, v1041)
			local v1043 = v1035.CFrame
			local v1044 = p715.s
			v1042.CFrame = v1043 * (v1040.Rotation + v1040.Position * v1044)
			local v1045 = Instance.new("WeldConstraint")
			v1045.Part0 = v1035
			v1045.Part1 = v1042
			v1045.Parent = v1042
		end
		return
	elseif v718 == "fins" then
		local v1046 = p715.trim
		local v1047, v1048 = CFrame.new(0, v719 + 0.3, 0.1)
		local v1049 = v_u_27(p715, "Crest", Vector3.new(0.15, 0.7, 1.4), v1046, v1048)
		local v1050 = p716.CFrame
		local v1051 = p715.s
		v1049.CFrame = v1050 * (v1047.Rotation + v1047.Position * v1051)
		local v1052 = Instance.new("WeldConstraint")
		v1052.Part0 = p716
		v1052.Part1 = v1049
		v1052.Parent = v1049
		for _, v1053 in { -1, 1 } do
			local v1054 = p715.trim
			local v1055 = CFrame.new(v1053 * (p717 / 2 + 0.12), -0.05, 0.2) * CFrame.Angles(0, v1053 * 0.4, 0)
			local v1056 = Instance.new("Part")
			v1056.Name = "Gill"
			v1056.Size = Vector3.new(0.12, 0.55, 0.65) * p715.s
			v1056.Color = v1054
			v1056.Material = Enum.Material.Plastic
			v1056.CanCollide = false
			v1056.CanTouch = false
			v1056.CanQuery = false
			v1056.Massless = true
			v1056.Anchored = false
			v1056.CastShadow = (Vector3.new(0.12, 0.55, 0.65)).Magnitude > 1.1
			v1056.TopSurface = Enum.SurfaceType.Smooth
			v1056.BottomSurface = Enum.SurfaceType.Smooth
			v1056.Parent = p715.model
			local v1057 = p716.CFrame
			local v1058 = p715.s
			v1056.CFrame = v1057 * (v1055.Rotation + v1055.Position * v1058)
			local v1059 = Instance.new("WeldConstraint")
			v1059.Part0 = p716
			v1059.Part1 = v1056
			v1059.Parent = v1056
		end
		return
	elseif v718 == "flame" then
		local v1060 = p715.glow
		local v1061 = CFrame.new(0, v719 + 0.4, 0.05) * CFrame.Angles(0, 0.7853981633974483, 0)
		local v1062 = v_u_27(p715, "Flame", Vector3.new(0.6, 0.95, 0.6), v1060, {
			["neon"] = true
		})
		local v1063 = p716.CFrame
		local v1064 = p715.s
		v1062.CFrame = v1063 * (v1061.Rotation + v1061.Position * v1064)
		local v1065 = Instance.new("WeldConstraint")
		v1065.Part0 = p716
		v1065.Part1 = v1062
		v1065.Parent = v1062
		for _, v1066 in { -1, 1 } do
			local v1067 = p715.eye
			local v1068 = CFrame.new(v1066 * 0.36, v719 + 0.22, 0.15) * CFrame.Angles(0, 0.7853981633974483, -v1066 * 0.3)
			local v1069 = v_u_27(p715, "Flame", Vector3.new(0.42, 0.6, 0.42), v1067, {
				["neon"] = true
			})
			local v1070 = p716.CFrame
			local v1071 = p715.s
			v1069.CFrame = v1070 * (v1068.Rotation + v1068.Position * v1071)
			local v1072 = Instance.new("WeldConstraint")
			v1072.Part0 = p716
			v1072.Part1 = v1069
			v1072.Parent = v1069
		end
		return
	elseif v718 == "crystals" then
		for v1073, v1074 in {
			{
				0,
				0.55,
				1.1,
				0
			},
			{
				0.45,
				0.35,
				0.8,
				-0.4
			},
			{
				-0.42,
				0.4,
				0.7,
				0.45
			}
		} do
			local v1075 = v1074[3]
			local v1076 = Vector3.new(0.34, v1075, 0.34)
			local v1077
			if v1073 == 1 then
				v1077 = p715.glow
			else
				v1077 = p715.eye
			end
			local v1078 = CFrame.new(v1074[1], v719 + v1074[2] - 0.1, 0.1) * CFrame.Angles(0, 0, v1074[4]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v1079 = v_u_27(p715, "Crystal", v1076, v1077, {
				["neon"] = true
			})
			local v1080 = p716.CFrame
			local v1081 = p715.s
			v1079.CFrame = v1080 * (v1078.Rotation + v1078.Position * v1081)
			local v1082 = Instance.new("WeldConstraint")
			v1082.Part0 = p716
			v1082.Part1 = v1079
			v1082.Parent = v1079
		end
		return
	elseif v718 == "tokin" then
		local v1083 = p715.trim
		local v1084 = CFrame.new(0, v719 + 0.15, v720 + 0.45) * CFrame.Angles(0, 0.7853981633974483, 0)
		local v1085 = Instance.new("Part")
		v1085.Name = "Tokin"
		v1085.Size = Vector3.new(0.55, 0.45, 0.55) * p715.s
		v1085.Color = v1083
		v1085.Material = Enum.Material.Plastic
		v1085.CanCollide = false
		v1085.CanTouch = false
		v1085.CanQuery = false
		v1085.Massless = true
		v1085.Anchored = false
		v1085.CastShadow = (Vector3.new(0.55, 0.45, 0.55)).Magnitude > 1.1
		v1085.TopSurface = Enum.SurfaceType.Smooth
		v1085.BottomSurface = Enum.SurfaceType.Smooth
		v1085.Parent = p715.model
		local v1086 = p716.CFrame
		local v1087 = p715.s
		v1085.CFrame = v1086 * (v1084.Rotation + v1084.Position * v1087)
		local v1088 = Instance.new("WeldConstraint")
		v1088.Part0 = p716
		v1088.Part1 = v1085
		v1088.Parent = v1085
		local v1089 = p717 + 0.12
		local v1090 = p717 * 0.75
		local v1091 = Vector3.new(v1089, v1090, 0.35)
		local v1092 = v_u_11
		local v1093, v1094 = CFrame.new(0, p717 * -0.05, p717 / 2 + 0.12)
		local v1095 = v_u_27(p715, "Hair", v1091, v1092, v1094)
		local v1096 = p716.CFrame
		local v1097 = p715.s
		v1095.CFrame = v1096 * (v1093.Rotation + v1093.Position * v1097)
		local v1098 = Instance.new("WeldConstraint")
		v1098.Part0 = p716
		v1098.Part1 = v1095
		v1098.Parent = v1095
		return
	elseif v718 == "cloud" then
		local v1099 = {
			["shape"] = Enum.PartType.Ball,
			["material"] = Enum.Material.SmoothPlastic
		}
		local v1100 = p715.shirt
		local v1101 = CFrame.new(0, v719 + 0.1, 0.25)
		local v1102 = v_u_27(p715, "Puff", Vector3.new(1.2, 1.2, 1.2), v1100, v1099)
		local v1103 = p716.CFrame
		local v1104 = p715.s
		v1102.CFrame = v1103 * (v1101.Rotation + v1101.Position * v1104)
		local v1105 = Instance.new("WeldConstraint")
		v1105.Part0 = p716
		v1105.Part1 = v1102
		v1105.Parent = v1102
		for _, v1106 in { -1, 1 } do
			local v1107 = p715.trim
			local v1108 = CFrame.new(v1106 * 0.62, v719 - 0.15, 0.3)
			local v1109 = v_u_27(p715, "Puff", Vector3.new(0.95, 0.95, 0.95), v1107, v1099)
			local v1110 = p716.CFrame
			local v1111 = p715.s
			v1109.CFrame = v1110 * (v1108.Rotation + v1108.Position * v1111)
			local v1112 = Instance.new("WeldConstraint")
			v1112.Part0 = p716
			v1112.Part1 = v1109
			v1112.Parent = v1109
		end
		return
	elseif v718 == "helm" then
		local v1113 = p717 + 0.3
		local v1114 = p717 + 0.3
		local v1115 = p717 + 0.3
		local v1116 = Vector3.new(v1113, v1114, v1115)
		local v1117 = p715.accent
		local v1118 = CFrame.identity
		local v1119 = v_u_27(p715, "Helm", v1116, v1117, {
			["material"] = nil,
			["studs"] = true,
			["material"] = Enum.Material.Metal
		})
		local v1120 = p716.CFrame
		local v1121 = p715.s
		v1119.CFrame = v1120 * (v1118.Rotation + v1118.Position * v1121)
		local v1122 = Instance.new("WeldConstraint")
		v1122.Part0 = p716
		v1122.Part1 = v1119
		v1122.Parent = v1119
		local v1123 = p717 + 0.4
		local v1124 = Vector3.new(0.25, 0.6, v1123)
		local v1125 = p715.glow
		local v1126 = CFrame.new(0, v719 + 0.42, 0.05)
		local v1127 = v_u_27(p715, "Plume", v1124, v1125, {
			["neon"] = true
		})
		local v1128 = p716.CFrame
		local v1129 = p715.s
		v1127.CFrame = v1128 * (v1126.Rotation + v1126.Position * v1129)
		local v1130 = Instance.new("WeldConstraint")
		v1130.Part0 = p716
		v1130.Part1 = v1127
		v1130.Parent = v1127
		for _, v1131 in { -1, 1 } do
			local v1132 = p715.glow
			local v1133 = CFrame.new(v1131 * (p717 / 2 + 0.12), v719 + 0.05, 0) * CFrame.Angles(0, 0, -v1131 * 0.5)
			local v1134 = v_u_27(p715, "HelmHorn", Vector3.new(0.26, 0.75, 0.26), v1132, {
				["neon"] = true
			})
			local v1135 = p716.CFrame
			local v1136 = p715.s
			v1134.CFrame = v1135 * (v1133.Rotation + v1133.Position * v1136)
			local v1137 = Instance.new("WeldConstraint")
			v1137.Part0 = p716
			v1137.Part1 = v1134
			v1137.Parent = v1134
		end
		return
	elseif v718 == "lotus" then
		local v1138 = p717 / 1.6
		local v1139 = CFrame.new(0, v719 + 0.12, 0.05)
		local v1140 = CFrame.Angles(0, 0, 0.7853981633974483)
		for v1141 = 0, 7 do
			local v1142 = Vector3.new(0.62, 0.62, 0.1) * v1138
			local v1143 = p715.trim
			local v1144 = v1139 * CFrame.Angles(0, v1141 * 3.141592653589793 / 4, 0) * CFrame.new(0, 0.14, v1138 * -0.5) * CFrame.Angles(-0.6, 0, 0) * v1140
			local v1145 = Instance.new("Part")
			v1145.Name = "Petal"
			v1145.Size = v1142 * p715.s
			v1145.Color = v1143
			v1145.Material = Enum.Material.Plastic
			v1145.CanCollide = false
			v1145.CanTouch = false
			v1145.CanQuery = false
			v1145.Massless = true
			v1145.Anchored = false
			v1145.CastShadow = v1142.Magnitude > 1.1
			v1145.TopSurface = Enum.SurfaceType.Smooth
			v1145.BottomSurface = Enum.SurfaceType.Smooth
			v1145.Parent = p715.model
			local v1146 = p716.CFrame
			local v1147 = p715.s
			v1145.CFrame = v1146 * (v1144.Rotation + v1144.Position * v1147)
			local v1148 = Instance.new("WeldConstraint")
			v1148.Part0 = p716
			v1148.Part1 = v1145
			v1148.Parent = v1145
		end
		for v1149 = 0, 4 do
			local v1150 = Vector3.new(0.42, 0.42, 0.08) * v1138
			local v1151 = p715.trim:Lerp(v_u_13, 0.65)
			local v1152 = v1139 * CFrame.Angles(0, v1149 * 3.141592653589793 * 2 / 5 + 0.3, 0) * CFrame.new(0, 0.26, v1138 * -0.24) * CFrame.Angles(-0.35, 0, 0) * v1140
			local v1153 = Instance.new("Part")
			v1153.Name = "Petal"
			v1153.Size = v1150 * p715.s
			v1153.Color = v1151
			v1153.Material = Enum.Material.Plastic
			v1153.CanCollide = false
			v1153.CanTouch = false
			v1153.CanQuery = false
			v1153.Massless = true
			v1153.Anchored = false
			v1153.CastShadow = v1150.Magnitude > 1.1
			v1153.TopSurface = Enum.SurfaceType.Smooth
			v1153.BottomSurface = Enum.SurfaceType.Smooth
			v1153.Parent = p715.model
			local v1154 = p716.CFrame
			local v1155 = p715.s
			v1153.CFrame = v1154 * (v1152.Rotation + v1152.Position * v1155)
			local v1156 = Instance.new("WeldConstraint")
			v1156.Part0 = p716
			v1156.Part1 = v1153
			v1156.Parent = v1153
		end
		local v1157 = Vector3.new(0.34, 0.22, 0.34) * v1138
		local v1158 = p715.glow
		local v1159 = v1139 * CFrame.new(0, 0.22, 0)
		local v1160 = v_u_27(p715, "LotusHeart", v1157, v1158, {
			["neon"] = true
		})
		local v1161 = p716.CFrame
		local v1162 = p715.s
		v1160.CFrame = v1161 * (v1159.Rotation + v1159.Position * v1162)
		local v1163 = Instance.new("WeldConstraint")
		v1163.Part0 = p716
		v1163.Part1 = v1160
		v1163.Parent = v1160
		return
	elseif v718 == "mushroom" then
		local v1164 = p717 / 1.6
		local v1165 = CFrame.Angles(0, 0, 1.5707963267948966)
		local v1166 = {
			["shape"] = Enum.PartType.Cylinder
		}
		local v1167 = CFrame.new(0, v719, 0.05)
		local v1168 = v1164 * 3.2
		local v1169 = v1164 * 3.2
		local v1170 = Vector3.new(0.14, v1168, v1169)
		local v1171 = p715.skin:Lerp(v_u_7, 0.2)
		local v1172 = v1167 * CFrame.new(0, -0.12, 0) * v1165
		local v1173 = v_u_27(p715, "Gills", v1170, v1171, v1166)
		local v1174 = p716.CFrame
		local v1175 = p715.s
		v1173.CFrame = v1174 * (v1172.Rotation + v1172.Position * v1175)
		local v1176 = Instance.new("WeldConstraint")
		v1176.Part0 = p716
		v1176.Part1 = v1173
		v1176.Parent = v1173
		for v1177, v1178 in {
			{ 3.35, 0.15, 0.5 },
			{ 2.4, 0.55, 0.45 },
			{ 1.36, 0.85, 0.35 }
		} do
			local v1179 = v1178[3]
			local v1180 = v1178[1] * v1164
			local v1181 = v1178[1] * v1164
			local v1182 = Vector3.new(v1179, v1180, v1181)
			local v1183 = p715.accent:Lerp(v_u_13, (v1177 - 1) * 0.06)
			local v1184 = v1167 * CFrame.new(0, v1178[2], 0) * v1165
			local v1185 = v_u_27(p715, "Cap", v1182, v1183, v1166)
			local v1186 = p716.CFrame
			local v1187 = p715.s
			v1185.CFrame = v1186 * (v1184.Rotation + v1184.Position * v1187)
			local v1188 = Instance.new("WeldConstraint")
			v1188.Part0 = p716
			v1188.Part1 = v1185
			v1188.Parent = v1185
		end
		for _, v1189 in {
			{ 1.45, 0.4, 0 },
			{ -1, 0.4, -1.05 },
			{ -0.7, 0.4, 1.27 },
			{ 0.55, 0.78, -0.75 },
			{ -0.9, 0.78, 0.2 }
		} do
			local v1190 = Vector3.new(0.34, 0.34, 0.34) * v1164
			local v1191 = p715.glow
			local v1192 = v1167 * CFrame.new(v1189[1] * v1164, v1189[2], v1189[3] * v1164)
			local v1193 = v_u_27(p715, "Spot", v1190, v1191, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v1194 = p716.CFrame
			local v1195 = p715.s
			v1193.CFrame = v1194 * (v1192.Rotation + v1192.Position * v1195)
			local v1196 = Instance.new("WeldConstraint")
			v1196.Part0 = p716
			v1196.Part1 = v1193
			v1196.Parent = v1193
		end
		return
	elseif v718 == "crescent" then
		local v1197 = p717 + 0.08
		local v1198 = p717 + 0.08
		local v1199 = Vector3.new(v1197, 0.18, v1198)
		local v1200 = p715.accent
		local v1201 = CFrame.new(0, p717 * 0.3, 0)
		local v1202 = v_u_27(p715, "Circlet", v1199, v1200, {
			["material"] = Enum.Material.Metal
		})
		local v1203 = p716.CFrame
		local v1204 = p715.s
		v1202.CFrame = v1203 * (v1201.Rotation + v1201.Position * v1204)
		local v1205 = Instance.new("WeldConstraint")
		v1205.Part0 = p716
		v1205.Part1 = v1202
		v1205.Parent = v1202
		local v1206 = CFrame.new(0, v719 + 0.3, v720 + 0.05)
		for v1207 = 0, 5 do
			local v1208 = 110 + v1207 * 45
			local v1209 = math.rad(v1208)
			local v1210 = 3.141592653589793 * v1207 / 5
			local v1211 = 0.09 + math.sin(v1210) * 0.14
			local v1212 = Vector3.new(v1211, 0.44, 0.1)
			local v1213 = p715.glow
			local v1214 = v1206 * CFrame.new(math.cos(v1209) * 0.5, math.sin(v1209) * 0.5, 0) * CFrame.Angles(0, 0, v1209)
			local v1215 = v_u_27(p715, "Crescent", v1212, v1213, {
				["neon"] = true
			})
			local v1216 = p716.CFrame
			local v1217 = p715.s
			v1215.CFrame = v1216 * (v1214.Rotation + v1214.Position * v1217)
			local v1218 = Instance.new("WeldConstraint")
			v1218.Part0 = p716
			v1218.Part1 = v1215
			v1218.Parent = v1215
		end
		return
	elseif v718 == "emperor" then
		local v1219 = p717 / 1.6
		local v1220 = {
			["material"] = Enum.Material.Metal
		}
		local v1221 = p717 * 0.7
		local v1222 = p717 * 0.75
		local v1223 = Vector3.new(v1221, 0.55, v1222)
		local v1224 = p715.trim
		local v1225, v1226 = CFrame.new(0, v719 + 0.2, 0.05)
		local v1227 = v_u_27(p715, "CrownCap", v1223, v1224, v1226)
		local v1228 = p716.CFrame
		local v1229 = p715.s
		v1227.CFrame = v1228 * (v1225.Rotation + v1225.Position * v1229)
		local v1230 = Instance.new("WeldConstraint")
		v1230.Part0 = p716
		v1230.Part1 = v1227
		v1230.Parent = v1227
		local v1231 = p717 + 0.08
		local v1232 = p717 + 0.08
		local v1233 = Vector3.new(v1231, 0.2, v1232)
		local v1234 = p715.accent
		local v1235 = CFrame.new(0, v719 - 0.1, 0)
		local v1236 = v_u_27(p715, "CrownBand", v1233, v1234, v1220)
		local v1237 = p716.CFrame
		local v1238 = p715.s
		v1236.CFrame = v1237 * (v1235.Rotation + v1235.Position * v1238)
		local v1239 = Instance.new("WeldConstraint")
		v1239.Part0 = p716
		v1239.Part1 = v1236
		v1239.Parent = v1236
		local v1240 = p717 * 1.4
		local v1241 = Vector3.new(v1240, 0.1, 0.1)
		local v1242 = p715.accent
		local v1243 = CFrame.new(0, v719 + 0.18, 0.05)
		local v1244 = v_u_27(p715, "Hairpin", v1241, v1242, v1220)
		local v1245 = p716.CFrame
		local v1246 = p715.s
		v1244.CFrame = v1245 * (v1243.Rotation + v1243.Position * v1246)
		local v1247 = Instance.new("WeldConstraint")
		v1247.Part0 = p716
		v1247.Part1 = v1244
		v1247.Parent = v1244
		local v1248 = p717 * 1.05
		local v1249 = p717 * 1.6
		local v1250 = Vector3.new(v1248, 0.12, v1249)
		local v1251 = p715.trim
		local v1252 = CFrame.new(0, v719 + 0.52, 0.05) * CFrame.Angles(0.06, 0, 0)
		local v1253 = Instance.new("Part")
		v1253.Name = "Board"
		v1253.Size = v1250 * p715.s
		v1253.Color = v1251
		v1253.Material = Enum.Material.Plastic
		v1253.CanCollide = false
		v1253.CanTouch = false
		v1253.CanQuery = false
		v1253.Massless = true
		v1253.Anchored = false
		v1253.CastShadow = v1250.Magnitude > 1.1
		v1253.TopSurface = Enum.SurfaceType.Smooth
		v1253.BottomSurface = Enum.SurfaceType.Smooth
		v1253.Parent = p715.model
		local v1254 = p716.CFrame
		local v1255 = p715.s
		v1253.CFrame = v1254 * (v1252.Rotation + v1252.Position * v1255)
		local v1256 = Instance.new("WeldConstraint")
		v1256.Part0 = p716
		v1256.Part1 = v1253
		v1256.Parent = v1253
		local v1257 = p717 * 1.08
		local v1258 = p717 * 1.63
		local v1259 = Vector3.new(v1257, 0.06, v1258)
		local v1260 = p715.accent
		local v1261 = CFrame.new(0, -0.08, 0)
		local v1262 = v_u_27(p715, "BoardEdge", v1259, v1260, v1220)
		local v1263 = v1253.CFrame
		local v1264 = p715.s
		v1262.CFrame = v1263 * (v1261.Rotation + v1261.Position * v1264)
		local v1265 = Instance.new("WeldConstraint")
		v1265.Part0 = v1253
		v1265.Part1 = v1262
		v1265.Parent = v1262
		for _, v1266 in { -1, 1 } do
			for v1267 = -2, 2 do
				local v1268 = p715.glow
				local v1269 = CFrame.new(v1267 * 0.2 * v1219, -0.41, v1266 * (p717 * 0.8 - 0.05))
				local v1270 = v_u_27(p715, "Beads", Vector3.new(0.09, 0.7, 0.09), v1268, {
					["neon"] = true
				})
				local v1271 = v1253.CFrame
				local v1272 = p715.s
				v1270.CFrame = v1271 * (v1269.Rotation + v1269.Position * v1272)
				local v1273 = Instance.new("WeldConstraint")
				v1273.Part0 = v1253
				v1273.Part1 = v1270
				v1273.Parent = v1270
			end
		end
		return
	elseif v718 == "sun" then
		local v1274 = CFrame.new(0, 0.1, p717 / 2 + 0.22)
		local v1275 = p717 * 1.6
		local v1276 = p717 * 1.6
		local v1277 = Vector3.new(0.2, v1275, v1276)
		local v1278 = p715.accent
		local v1279 = v1274 * CFrame.Angles(0, 1.5707963267948966, 0)
		local v1280 = v_u_27(p715, "SunDisc", v1277, v1278, {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v1281 = p716.CFrame
		local v1282 = p715.s
		v1280.CFrame = v1281 * (v1279.Rotation + v1279.Position * v1282)
		local v1283 = Instance.new("WeldConstraint")
		v1283.Part0 = p716
		v1283.Part1 = v1280
		v1283.Parent = v1280
		for v1284 = 0, 11 do
			local v1285 = v1284 * 3.141592653589793 / 6 + 1.5707963267948966
			local v1286 = v1284 % 2 == 0
			local v1287 = p717 * 0.8 + (v1286 and 0.45 or 0.3)
			local v1288 = Vector3.new(0.26, v1286 and 0.9 or 0.6, 0.14)
			local v1289
			if v1286 then
				v1289 = p715.glow
			else
				v1289 = p715.eye
			end
			local v1290 = v1274 * CFrame.new(math.cos(v1285) * v1287, math.sin(v1285) * v1287, 0.04) * CFrame.Angles(0, 0, v1285 - 1.5707963267948966)
			local v1291 = v_u_27(p715, "Ray", v1288, v1289, {
				["neon"] = true
			})
			local v1292 = p716.CFrame
			local v1293 = p715.s
			v1291.CFrame = v1292 * (v1290.Rotation + v1290.Position * v1293)
			local v1294 = Instance.new("WeldConstraint")
			v1294.Part0 = p716
			v1294.Part1 = v1291
			v1294.Parent = v1291
		end
		return
	elseif v718 == "antlers" then
		local v1295 = p717 / 1.6
		for _, v1296 in { -1, 1 } do
			v_u_114(p715, p716, "Antler", CFrame.new(v1296 * 0.42 * v1295, v719 - 0.1, 0.1) * CFrame.Angles(0.25, 0, -v1296 * 0.5), 1.5 * v1295, 0.24, p715.accent, {
				{
					0.3,
					-v1296 * 0.75,
					-0.4,
					v1295 * 0.75
				},
				{
					0.62,
					v1296 * 0.6,
					-0.3,
					v1295 * 0.65
				},
				{
					0.85,
					-v1296 * 0.55,
					0.2,
					v1295 * 0.55
				}
			})
		end
		return
	elseif v718 == "star" then
		local v1297 = CFrame.new(0, v719 + 0.75, 0)
		local v1298 = p715.glow
		local v1299 = v1297 * CFrame.Angles(0, 1.5707963267948966, 0)
		local v1300 = v_u_27(p715, "StarCore", Vector3.new(0.14, 0.5, 0.5), v1298, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v1301 = p716.CFrame
		local v1302 = p715.s
		v1300.CFrame = v1301 * (v1299.Rotation + v1299.Position * v1302)
		local v1303 = Instance.new("WeldConstraint")
		v1303.Part0 = p716
		v1303.Part1 = v1300
		v1303.Parent = v1300
		for v1304 = 0, 4 do
			local v1305 = v1304 * 3.141592653589793 * 2 / 5 + 1.5707963267948966
			local v1306 = CFrame.Angles(0, 0, v1305 - 1.5707963267948966)
			local v1307 = p715.glow
			local v1308 = v1297 * CFrame.new(math.cos(v1305) * 0.36, math.sin(v1305) * 0.36, 0) * v1306
			local v1309 = v_u_27(p715, "StarRay", Vector3.new(0.3, 0.42, 0.12), v1307, {
				["neon"] = true
			})
			local v1310 = p716.CFrame
			local v1311 = p715.s
			v1309.CFrame = v1310 * (v1308.Rotation + v1308.Position * v1311)
			local v1312 = Instance.new("WeldConstraint")
			v1312.Part0 = p716
			v1312.Part1 = v1309
			v1312.Parent = v1309
			local v1313 = p715.eye
			local v1314 = v1297 * CFrame.new(math.cos(v1305) * 0.65, math.sin(v1305) * 0.65, 0) * v1306
			local v1315 = v_u_27(p715, "StarTip", Vector3.new(0.16, 0.26, 0.12), v1313, {
				["neon"] = true
			})
			local v1316 = p716.CFrame
			local v1317 = p715.s
			v1315.CFrame = v1316 * (v1314.Rotation + v1314.Position * v1317)
			local v1318 = Instance.new("WeldConstraint")
			v1318.Part0 = p716
			v1318.Part1 = v1315
			v1318.Parent = v1315
		end
	elseif v718 == "wildhair" then
		local v1319 = p717 + 0.15
		local v1320 = p717 + 0.2
		local v1321 = Vector3.new(v1319, 0.4, v1320)
		local v1322 = p715.trim
		local v1323, v1324 = CFrame.new(0, v719 + 0.05, 0.05)
		local v1325 = v_u_27(p715, "Hair", v1321, v1322, v1324)
		local v1326 = p716.CFrame
		local v1327 = p715.s
		v1325.CFrame = v1326 * (v1323.Rotation + v1323.Position * v1327)
		local v1328 = Instance.new("WeldConstraint")
		v1328.Part0 = p716
		v1328.Part1 = v1325
		v1328.Parent = v1325
		for _, v1329 in {
			{
				0,
				0.5,
				0.35,
				0.6,
				0,
				1.3
			},
			{
				0.5,
				0.4,
				0.25,
				0.45,
				-0.6,
				1.05
			},
			{
				-0.5,
				0.4,
				0.25,
				0.45,
				0.6,
				1.05
			},
			{
				0.3,
				0.5,
				-0.1,
				0.25,
				-0.3,
				0.9
			},
			{
				-0.3,
				0.5,
				-0.1,
				0.25,
				0.3,
				0.9
			},
			{
				0,
				0.1,
				0.75,
				1.2,
				0,
				1.1
			}
		} do
			local v1330 = v1329[6]
			local v1331 = Vector3.new(0.4, v1330, 0.4)
			local v1332 = p715.trim
			local v1333 = CFrame.new(v1329[1], v719 + v1329[2], v1329[3]) * CFrame.Angles(v1329[4], 0, v1329[5]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v1334 = Instance.new("Part")
			v1334.Name = "HairSpike"
			v1334.Size = v1331 * p715.s
			v1334.Color = v1332
			v1334.Material = Enum.Material.Plastic
			v1334.CanCollide = false
			v1334.CanTouch = false
			v1334.CanQuery = false
			v1334.Massless = true
			v1334.Anchored = false
			v1334.CastShadow = v1331.Magnitude > 1.1
			v1334.TopSurface = Enum.SurfaceType.Smooth
			v1334.BottomSurface = Enum.SurfaceType.Smooth
			v1334.Parent = p715.model
			local v1335 = p716.CFrame
			local v1336 = p715.s
			v1334.CFrame = v1335 * (v1333.Rotation + v1333.Position * v1336)
			local v1337 = Instance.new("WeldConstraint")
			v1337.Part0 = p716
			v1337.Part1 = v1334
			v1337.Parent = v1334
		end
		for _, v1338 in { -1, 1 } do
			local v1339 = p715.glow
			local v1340 = CFrame.new(v1338 * 0.45 * p717 / 1.6, v719 + 0.25, v720 + 0.3) * CFrame.Angles(-0.2, 0, -v1338 * 0.35)
			local v1341 = v_u_27(p715, "Horn", Vector3.new(0.26, 0.8, 0.26), v1339, {
				["neon"] = true
			})
			local v1342 = p716.CFrame
			local v1343 = p715.s
			v1341.CFrame = v1342 * (v1340.Rotation + v1340.Position * v1343)
			local v1344 = Instance.new("WeldConstraint")
			v1344.Part0 = p716
			v1344.Part1 = v1341
			v1344.Parent = v1341
		end
	end
end
local function v_u_1821(p1346, p1347) -- name: weapon
	-- upvalues: (copy) v_u_27, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_176, (copy) v_u_17, (copy) v_u_68
	local v1348 = p1346.look.weapon or "none"
	local v1349 = p1347.rightArmPart
	local v1350 = p1347.leftArmPart
	if v1349 and (v1350 and v1348 ~= "none") then
		local v1351 = p1347.d.arm
		local v1352 = CFrame.new(0, -v1351.Y / 2 + 0.25, 0) * CFrame.Angles(0, -0.3, 0)
		local v1353 = {
			["neon"] = true
		}
		local v1354 = {
			["material"] = Enum.Material.Metal
		}
		local v1355 = nil
		local v1356 = 0
		if v1348 == "kunai" then
			local v1357 = v_u_7
			local v1358, v1359 = CFrame.new(0, 0, -0.1)
			local v1360 = v1352 * v1358
			local v1361 = v_u_27(p1346, "Grip", Vector3.new(0.18, 0.18, 0.5), v1357, v1359)
			local v1362 = v1349.CFrame
			local v1363 = p1346.s
			v1361.CFrame = v1362 * (v1360.Rotation + v1360.Position * v1363)
			local v1364 = Instance.new("WeldConstraint")
			v1364.Part0 = v1349
			v1364.Part1 = v1361
			v1364.Parent = v1361
			local v1365 = v_u_7
			local v1366, v1367 = CFrame.new(0, 0, 0.2)
			local v1368 = v1352 * v1366
			local v1369 = v_u_27(p1346, "Ring", Vector3.new(0.3, 0.3, 0.08), v1365, v1367)
			local v1370 = v1349.CFrame
			local v1371 = p1346.s
			v1369.CFrame = v1370 * (v1368.Rotation + v1368.Position * v1371)
			local v1372 = Instance.new("WeldConstraint")
			v1372.Part0 = v1349
			v1372.Part1 = v1369
			v1372.Parent = v1369
			local v1373 = p1346.glow
			local v1374 = v1352 * CFrame.new(0, 0, -0.9)
			v1355 = v_u_27(p1346, "Blade", Vector3.new(0.1, 0.3, 1.1), v1373, v1353)
			local v1375 = v1349.CFrame
			local v1376 = p1346.s
			v1355.CFrame = v1375 * (v1374.Rotation + v1374.Position * v1376)
			local v1377 = Instance.new("WeldConstraint")
			v1377.Part0 = v1349
			v1377.Part1 = v1355
			v1377.Parent = v1355
			v1356 = 1.1
		elseif v1348 == "shuriken" then
			for _, v1378 in { 1, -1 } do
				local v1379 = v_u_8
				local v1380 = v1352 * (CFrame.new(0, 0, -0.75) * CFrame.Angles(0, v1378 * 3.141592653589793 / 4, 0))
				local v1381 = v_u_27(p1346, "Star", Vector3.new(1.3, 0.08, 0.28), v1379, v1354)
				local v1382 = v1349.CFrame
				local v1383 = p1346.s
				v1381.CFrame = v1382 * (v1380.Rotation + v1380.Position * v1383)
				local v1384 = Instance.new("WeldConstraint")
				v1384.Part0 = v1349
				v1384.Part1 = v1381
				v1384.Parent = v1381
			end
			local v1385 = p1346.glow
			local v1386 = v1352 * CFrame.new(0, 0, -0.75)
			local v1387 = v_u_27(p1346, "StarCore", Vector3.new(0.34, 0.12, 0.34), v1385, v1353)
			local v1388 = v1349.CFrame
			local v1389 = p1346.s
			v1387.CFrame = v1388 * (v1386.Rotation + v1386.Position * v1389)
			local v1390 = Instance.new("WeldConstraint")
			v1390.Part0 = v1349
			v1390.Part1 = v1387
			v1390.Parent = v1387
		elseif v1348 == "katana" or v1348 == "nodachi" then
			local v1391 = v1348 == "nodachi"
			v1356 = v1391 and 4 or 3.2
			local v1392 = Vector3.new(0.2, 0.22, v1391 and 1.2 or 0.9)
			local v1393 = v_u_7
			local v1394, v1395 = CFrame.new(0, 0, -0.1)
			local v1396 = v1352 * v1394
			local v1397 = v_u_27(p1346, "Grip", v1392, v1393, v1395)
			local v1398 = v1349.CFrame
			local v1399 = p1346.s
			v1397.CFrame = v1398 * (v1396.Rotation + v1396.Position * v1399)
			local v1400 = Instance.new("WeldConstraint")
			v1400.Part0 = v1349
			v1400.Part1 = v1397
			v1400.Parent = v1397
			local v1401 = p1346.accent
			local v1402 = v1352 * CFrame.new(0, 0, -0.65)
			local v1403 = v_u_27(p1346, "Guard", Vector3.new(0.55, 0.55, 0.1), v1401, v1354)
			local v1404 = v1349.CFrame
			local v1405 = p1346.s
			v1403.CFrame = v1404 * (v1402.Rotation + v1402.Position * v1405)
			local v1406 = Instance.new("WeldConstraint")
			v1406.Part0 = v1349
			v1406.Part1 = v1403
			v1406.Parent = v1403
			local v1407 = Vector3.new(0.1, 0.3, v1356)
			local v1408 = v_u_8
			local v1409 = v1352 * CFrame.new(0, 0.02, -0.7 - v1356 / 2)
			v1355 = v_u_27(p1346, "Blade", v1407, v1408, v1354)
			local v1410 = v1349.CFrame
			local v1411 = p1346.s
			v1355.CFrame = v1410 * (v1409.Rotation + v1409.Position * v1411)
			local v1412 = Instance.new("WeldConstraint")
			v1412.Part0 = v1349
			v1412.Part1 = v1355
			v1412.Parent = v1355
			local v1413 = v1356 - 0.1
			local v1414 = Vector3.new(0.07, 0.1, v1413)
			local v1415 = p1346.glow
			local v1416 = CFrame.new(0, -0.15, 0)
			local v1417 = v_u_27(p1346, "Edge", v1414, v1415, v1353)
			local v1418 = v1355.CFrame
			local v1419 = p1346.s
			v1417.CFrame = v1418 * (v1416.Rotation + v1416.Position * v1419)
			local v1420 = Instance.new("WeldConstraint")
			v1420.Part0 = v1355
			v1420.Part1 = v1417
			v1420.Parent = v1417
		elseif v1348 == "bostaff" then
			local v1421 = Color3.fromRGB(201, 180, 88)
			local v1422, v1423 = CFrame.new(0, 0, -0.4)
			local v1424 = v1352 * v1422
			local v1425 = v_u_27(p1346, "Staff", Vector3.new(0.3, 0.3, 5.6), v1421, v1423)
			local v1426 = v1349.CFrame
			local v1427 = p1346.s
			v1425.CFrame = v1426 * (v1424.Rotation + v1424.Position * v1427)
			local v1428 = Instance.new("WeldConstraint")
			v1428.Part0 = v1349
			v1428.Part1 = v1425
			v1428.Parent = v1425
			for _, v1429 in { -1.8, 1.2 } do
				local v1430 = v1421:Lerp(v_u_7, 0.4)
				local v1431, v1432 = CFrame.new(0, 0, v1429)
				local v1433 = v1352 * v1431
				local v1434 = v_u_27(p1346, "Node", Vector3.new(0.38, 0.38, 0.14), v1430, v1432)
				local v1435 = v1349.CFrame
				local v1436 = p1346.s
				v1434.CFrame = v1435 * (v1433.Rotation + v1433.Position * v1436)
				local v1437 = Instance.new("WeldConstraint")
				v1437.Part0 = v1349
				v1437.Part1 = v1434
				v1437.Parent = v1434
			end
			local v1438 = p1346.glow
			local v1439 = v1352 * CFrame.new(0, 0, -3.15)
			v1355 = v_u_27(p1346, "Tip", Vector3.new(0.34, 0.34, 0.4), v1438, v1353)
			local v1440 = v1349.CFrame
			local v1441 = p1346.s
			v1355.CFrame = v1440 * (v1439.Rotation + v1439.Position * v1441)
			local v1442 = Instance.new("WeldConstraint")
			v1442.Part0 = v1349
			v1442.Part1 = v1355
			v1442.Parent = v1355
			v1356 = 5.6
		elseif v1348 == "orbstaff" then
			local v1443 = v_u_9
			local v1444, v1445 = CFrame.new(0, 1.3, -0.35)
			local v1446 = v1352 * v1444
			local v1447 = v_u_27(p1346, "Staff", Vector3.new(0.28, 5.2, 0.28), v1443, v1445)
			local v1448 = v1349.CFrame
			local v1449 = p1346.s
			v1447.CFrame = v1448 * (v1446.Rotation + v1446.Position * v1449)
			local v1450 = Instance.new("WeldConstraint")
			v1450.Part0 = v1349
			v1450.Part1 = v1447
			v1450.Parent = v1447
			local v1451 = p1346.accent
			local v1452 = v1352 * CFrame.new(0, 3.95, -0.35)
			local v1453 = v_u_27(p1346, "Head", Vector3.new(0.7, 0.25, 0.7), v1451, v1354)
			local v1454 = v1349.CFrame
			local v1455 = p1346.s
			v1453.CFrame = v1454 * (v1452.Rotation + v1452.Position * v1455)
			local v1456 = Instance.new("WeldConstraint")
			v1456.Part0 = v1349
			v1456.Part1 = v1453
			v1456.Parent = v1453
			for _, v1457 in { -1, 1 } do
				local v1458 = p1346.accent
				local v1459 = v1352 * (CFrame.new(v1457 * 0.42, 4.45, -0.35) * CFrame.Angles(0, 0, -v1457 * 0.25))
				local v1460 = v_u_27(p1346, "Prong", Vector3.new(0.14, 0.9, 0.14), v1458, v1354)
				local v1461 = v1349.CFrame
				local v1462 = p1346.s
				v1460.CFrame = v1461 * (v1459.Rotation + v1459.Position * v1462)
				local v1463 = Instance.new("WeldConstraint")
				v1463.Part0 = v1349
				v1463.Part1 = v1460
				v1463.Parent = v1460
			end
			local v1464 = p1346.glow
			local v1465 = CFrame.new(0, 4.55, -0.35)
			local v1466 = {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			}
			local v1467 = v1352 * v1465
			local v1468 = v_u_27(p1346, "Orb", Vector3.new(1, 1, 1), v1464, v1466)
			local v1469 = v1349.CFrame
			local v1470 = p1346.s
			v1468.CFrame = v1469 * (v1467.Rotation + v1467.Position * v1470)
			local v1471 = Instance.new("WeldConstraint")
			v1471.Part0 = v1349
			v1471.Part1 = v1468
			v1471.Parent = v1468
		elseif v1348 == "spear" or (v1348 == "trident" or v1348 == "glaive") then
			local v1472 = CFrame.Angles(0.35, 0, 0)
			local v1473
			if v1348 == "glaive" then
				v1473 = v_u_7
			else
				v1473 = v_u_9
			end
			local v1474 = v1352 * (v1472 * CFrame.new(0, 0, -1.3))
			v1355 = Instance.new("Part")
			v1355.Name = "Pole"
			v1355.Size = Vector3.new(0.25, 0.25, 6) * p1346.s
			v1355.Color = v1473
			v1355.Material = Enum.Material.Plastic
			v1355.CanCollide = false
			v1355.CanTouch = false
			v1355.CanQuery = false
			v1355.Massless = true
			v1355.Anchored = false
			v1355.CastShadow = (Vector3.new(0.25, 0.25, 6)).Magnitude > 1.1
			v1355.TopSurface = Enum.SurfaceType.Smooth
			v1355.BottomSurface = Enum.SurfaceType.Smooth
			v1355.Parent = p1346.model
			local v1475 = v1349.CFrame
			local v1476 = p1346.s
			v1355.CFrame = v1475 * (v1474.Rotation + v1474.Position * v1476)
			local v1477 = Instance.new("WeldConstraint")
			v1477.Part0 = v1349
			v1477.Part1 = v1355
			v1477.Parent = v1355
			if v1348 == "spear" then
				local v1478 = p1346.accent
				local v1479 = v1352 * (v1472 * CFrame.new(0, 0, -4.3))
				local v1480 = v_u_27(p1346, "Collar", Vector3.new(0.35, 0.35, 0.25), v1478, v1354)
				local v1481 = v1349.CFrame
				local v1482 = p1346.s
				v1480.CFrame = v1481 * (v1479.Rotation + v1479.Position * v1482)
				local v1483 = Instance.new("WeldConstraint")
				v1483.Part0 = v1349
				v1483.Part1 = v1480
				v1483.Parent = v1480
				local v1484 = p1346.glow
				local v1485 = v1352 * (v1472 * CFrame.new(0, 0, -4.9))
				local v1486 = v_u_27(p1346, "Tip", Vector3.new(0.16, 0.5, 1), v1484, v1353)
				local v1487 = v1349.CFrame
				local v1488 = p1346.s
				v1486.CFrame = v1487 * (v1485.Rotation + v1485.Position * v1488)
				local v1489 = Instance.new("WeldConstraint")
				v1489.Part0 = v1349
				v1489.Part1 = v1486
				v1489.Parent = v1486
			elseif v1348 == "trident" then
				local v1490 = p1346.accent
				local v1491 = v1352 * (v1472 * CFrame.new(0, 0, -4.2))
				local v1492 = v_u_27(p1346, "Bar", Vector3.new(1.1, 0.15, 0.15), v1490, v1354)
				local v1493 = v1349.CFrame
				local v1494 = p1346.s
				v1492.CFrame = v1493 * (v1491.Rotation + v1491.Position * v1494)
				local v1495 = Instance.new("WeldConstraint")
				v1495.Part0 = v1349
				v1495.Part1 = v1492
				v1495.Parent = v1492
				local v1496 = p1346.glow
				local v1497 = v1352 * (v1472 * CFrame.new(0, 0, -4.8))
				local v1498 = v_u_27(p1346, "Prong", Vector3.new(0.14, 0.14, 1.1), v1496, v1353)
				local v1499 = v1349.CFrame
				local v1500 = p1346.s
				v1498.CFrame = v1499 * (v1497.Rotation + v1497.Position * v1500)
				local v1501 = Instance.new("WeldConstraint")
				v1501.Part0 = v1349
				v1501.Part1 = v1498
				v1501.Parent = v1498
				for _, v1502 in { -1, 1 } do
					local v1503 = p1346.glow
					local v1504 = v1352 * (v1472 * CFrame.new(v1502 * 0.48, 0, -4.65))
					local v1505 = v_u_27(p1346, "Prong", Vector3.new(0.14, 0.14, 0.8), v1503, v1353)
					local v1506 = v1349.CFrame
					local v1507 = p1346.s
					v1505.CFrame = v1506 * (v1504.Rotation + v1504.Position * v1507)
					local v1508 = Instance.new("WeldConstraint")
					v1508.Part0 = v1349
					v1508.Part1 = v1505
					v1508.Parent = v1505
				end
			else
				local v1509 = p1346.accent
				local v1510 = v1352 * (v1472 * CFrame.new(0, 0.15, -4.8))
				local v1511 = v_u_27(p1346, "GlaiveBlade", Vector3.new(0.12, 0.7, 1.6), v1509, v1354)
				local v1512 = v1349.CFrame
				local v1513 = p1346.s
				v1511.CFrame = v1512 * (v1510.Rotation + v1510.Position * v1513)
				local v1514 = Instance.new("WeldConstraint")
				v1514.Part0 = v1349
				v1514.Part1 = v1511
				v1514.Parent = v1511
				local v1515 = p1346.glow
				local v1516 = CFrame.new(0, 0.38, 0)
				local v1517 = v_u_27(p1346, "Edge", Vector3.new(0.08, 0.14, 1.6), v1515, v1353)
				local v1518 = v1511.CFrame
				local v1519 = p1346.s
				v1517.CFrame = v1518 * (v1516.Rotation + v1516.Position * v1519)
				local v1520 = Instance.new("WeldConstraint")
				v1520.Part0 = v1511
				v1520.Part1 = v1517
				v1520.Parent = v1517
				local v1521 = p1346.accent
				local v1522 = v1352 * (v1472 * CFrame.new(0, -0.25, -4.15))
				local v1523 = v_u_27(p1346, "Hook", Vector3.new(0.12, 0.5, 0.4), v1521, v1354)
				local v1524 = v1349.CFrame
				local v1525 = p1346.s
				v1523.CFrame = v1524 * (v1522.Rotation + v1522.Position * v1525)
				local v1526 = Instance.new("WeldConstraint")
				v1526.Part0 = v1349
				v1526.Part1 = v1523
				v1526.Parent = v1523
			end
			v1356 = 6
		elseif v1348 == "club" then
			local v1527 = v_u_9
			local v1528, v1529 = CFrame.new(0, 0, -0.2)
			local v1530 = v1352 * v1528
			local v1531 = v_u_27(p1346, "Handle", Vector3.new(0.3, 0.3, 1.1), v1527, v1529)
			local v1532 = v1349.CFrame
			local v1533 = p1346.s
			v1531.CFrame = v1532 * (v1530.Rotation + v1530.Position * v1533)
			local v1534 = Instance.new("WeldConstraint")
			v1534.Part0 = v1349
			v1534.Part1 = v1531
			v1534.Parent = v1531
			local v1535 = p1346.accent
			local v1536 = v1352 * (CFrame.Angles(0.2, 0, 0) * CFrame.new(0, 0, -2))
			v1355 = v_u_27(p1346, "Kanabo", Vector3.new(0.75, 0.75, 2.6), v1535, v1354)
			local v1537 = v1349.CFrame
			local v1538 = p1346.s
			v1355.CFrame = v1537 * (v1536.Rotation + v1536.Position * v1538)
			local v1539 = Instance.new("WeldConstraint")
			v1539.Part0 = v1349
			v1539.Part1 = v1355
			v1539.Parent = v1355
			for v1540, v1541 in {
				Vector3.new(0.42, 0, -0.6),
				Vector3.new(-0.42, 0, 0.1),
				Vector3.new(0, 0.42, 0.7),
				Vector3.new(0, -0.42, -0.2)
			} do
				local v1542 = "Stud" .. v1540
				local v1543 = p1346.glow
				local v1544 = CFrame.new(v1541)
				local v1545 = v_u_27(p1346, v1542, Vector3.new(0.24, 0.24, 0.24), v1543, v1353)
				local v1546 = v1355.CFrame
				local v1547 = p1346.s
				v1545.CFrame = v1546 * (v1544.Rotation + v1544.Position * v1547)
				local v1548 = Instance.new("WeldConstraint")
				v1548.Part0 = v1355
				v1548.Part1 = v1545
				v1548.Parent = v1545
			end
			v1356 = 2.6
		elseif v1348 == "scimitar" then
			local v1549 = v_u_7
			local v1550, v1551 = CFrame.new(0, 0, -0.1)
			local v1552 = v1352 * v1550
			local v1553 = v_u_27(p1346, "Grip", Vector3.new(0.2, 0.2, 0.7), v1549, v1551)
			local v1554 = v1349.CFrame
			local v1555 = p1346.s
			v1553.CFrame = v1554 * (v1552.Rotation + v1552.Position * v1555)
			local v1556 = Instance.new("WeldConstraint")
			v1556.Part0 = v1349
			v1556.Part1 = v1553
			v1556.Parent = v1553
			local v1557 = p1346.accent
			local v1558 = v1352 * CFrame.new(0, 0, -0.5)
			local v1559 = v_u_27(p1346, "Guard", Vector3.new(0.7, 0.14, 0.18), v1557, v1354)
			local v1560 = v1349.CFrame
			local v1561 = p1346.s
			v1559.CFrame = v1560 * (v1558.Rotation + v1558.Position * v1561)
			local v1562 = Instance.new("WeldConstraint")
			v1562.Part0 = v1349
			v1562.Part1 = v1559
			v1562.Parent = v1559
			local v1563 = v_u_8
			local v1564 = v1352 * CFrame.new(0, 0.05, -1.35)
			v1355 = v_u_27(p1346, "Blade", Vector3.new(0.08, 0.42, 1.6), v1563, v1354)
			local v1565 = v1349.CFrame
			local v1566 = p1346.s
			v1355.CFrame = v1565 * (v1564.Rotation + v1564.Position * v1566)
			local v1567 = Instance.new("WeldConstraint")
			v1567.Part0 = v1349
			v1567.Part1 = v1355
			v1567.Parent = v1355
			local v1568 = p1346.glow
			local v1569 = CFrame.new(0, -0.22, 0)
			local v1570 = v_u_27(p1346, "Edge", Vector3.new(0.06, 0.1, 1.6), v1568, v1353)
			local v1571 = v1355.CFrame
			local v1572 = p1346.s
			v1570.CFrame = v1571 * (v1569.Rotation + v1569.Position * v1572)
			local v1573 = Instance.new("WeldConstraint")
			v1573.Part0 = v1355
			v1573.Part1 = v1570
			v1573.Parent = v1570
			local v1574 = v_u_8
			local v1575 = v1352 * (CFrame.new(0, 0.2, -2.55) * CFrame.Angles(0.3, 0, 0))
			local v1576 = v_u_27(p1346, "BladeTip", Vector3.new(0.08, 0.55, 1.3), v1574, v1354)
			local v1577 = v1349.CFrame
			local v1578 = p1346.s
			v1576.CFrame = v1577 * (v1575.Rotation + v1575.Position * v1578)
			local v1579 = Instance.new("WeldConstraint")
			v1579.Part0 = v1349
			v1579.Part1 = v1576
			v1579.Parent = v1576
			v1356 = 2.4
		elseif v1348 == "axe" then
			local v1580 = v_u_9
			local v1581, v1582 = CFrame.new(0, 0, -1.3)
			local v1583 = v1352 * v1581
			local v1584 = v_u_27(p1346, "Haft", Vector3.new(0.28, 0.28, 3.6), v1580, v1582)
			local v1585 = v1349.CFrame
			local v1586 = p1346.s
			v1584.CFrame = v1585 * (v1583.Rotation + v1583.Position * v1586)
			local v1587 = Instance.new("WeldConstraint")
			v1587.Part0 = v1349
			v1587.Part1 = v1584
			v1587.Parent = v1584
			local v1588 = p1346.glow
			local v1589 = v1352 * CFrame.new(0, 0.45, -3)
			v1355 = v_u_27(p1346, "AxeHead", Vector3.new(0.24, 1.9, 1.2), v1588, v1353)
			local v1590 = v1349.CFrame
			local v1591 = p1346.s
			v1355.CFrame = v1590 * (v1589.Rotation + v1589.Position * v1591)
			local v1592 = Instance.new("WeldConstraint")
			v1592.Part0 = v1349
			v1592.Part1 = v1355
			v1592.Parent = v1355
			local v1593 = v_u_8
			local v1594 = CFrame.new(0, -0.1, 0.75)
			local v1595 = v_u_27(p1346, "AxeBack", Vector3.new(0.3, 0.6, 0.7), v1593, v1354)
			local v1596 = v1355.CFrame
			local v1597 = p1346.s
			v1595.CFrame = v1596 * (v1594.Rotation + v1594.Position * v1597)
			local v1598 = Instance.new("WeldConstraint")
			v1598.Part0 = v1355
			v1598.Part1 = v1595
			v1598.Parent = v1595
			v1356 = 1.2
		elseif v1348 == "greatsword" then
			local v1599 = v_u_7
			local v1600, v1601 = CFrame.new(0, 0, 0)
			local v1602 = v1352 * v1600
			local v1603 = v_u_27(p1346, "Grip", Vector3.new(0.25, 0.25, 1), v1599, v1601)
			local v1604 = v1349.CFrame
			local v1605 = p1346.s
			v1603.CFrame = v1604 * (v1602.Rotation + v1602.Position * v1605)
			local v1606 = Instance.new("WeldConstraint")
			v1606.Part0 = v1349
			v1606.Part1 = v1603
			v1606.Parent = v1603
			local v1607 = p1346.accent
			local v1608 = v1352 * CFrame.new(0, 0, -0.6)
			local v1609 = v_u_27(p1346, "Guard", Vector3.new(0.35, 1.4, 0.3), v1607, v1354)
			local v1610 = v1349.CFrame
			local v1611 = p1346.s
			v1609.CFrame = v1610 * (v1608.Rotation + v1608.Position * v1611)
			local v1612 = Instance.new("WeldConstraint")
			v1612.Part0 = v1349
			v1612.Part1 = v1609
			v1612.Parent = v1609
			local v1613 = p1346.look.aura == "frost" and true or p1346.look.aura == "snow"
			local v1614
			if v1613 then
				v1614 = Color3.fromRGB(191, 233, 255)
			else
				v1614 = p1346.accent:Lerp(v_u_8, 0.35)
			end
			local v1615 = CFrame.new(0, 0, -2.95)
			local v1616 = {}
			local v1617
			if v1613 then
				v1617 = Enum.Material.Ice
			else
				v1617 = Enum.Material.Metal
			end
			v1616.material = v1617
			local v1618 = v1352 * v1615
			v1355 = v_u_27(p1346, "Blade", Vector3.new(0.2, 0.62, 4.4), v1614, v1616)
			local v1619 = v1349.CFrame
			local v1620 = p1346.s
			v1355.CFrame = v1619 * (v1618.Rotation + v1618.Position * v1620)
			local v1621 = Instance.new("WeldConstraint")
			v1621.Part0 = v1349
			v1621.Part1 = v1355
			v1621.Parent = v1355
			for _, v1622 in { 0.34, -0.34 } do
				local v1623 = p1346.glow
				local v1624 = CFrame.new(0, v1622, 0)
				local v1625 = v_u_27(p1346, "Edge", Vector3.new(0.12, 0.1, 4.3), v1623, v1353)
				local v1626 = v1355.CFrame
				local v1627 = p1346.s
				v1625.CFrame = v1626 * (v1624.Rotation + v1624.Position * v1627)
				local v1628 = Instance.new("WeldConstraint")
				v1628.Part0 = v1355
				v1628.Part1 = v1625
				v1628.Parent = v1625
			end
			v1356 = 4.4
		elseif v1348 == "scythe" then
			local v1629 = v_u_7
			local v1630, v1631 = CFrame.new(0, 1.6, -0.2)
			local v1632 = v1352 * v1630
			local v1633 = v_u_27(p1346, "Snath", Vector3.new(0.3, 7, 0.3), v1629, v1631)
			local v1634 = v1349.CFrame
			local v1635 = p1346.s
			v1633.CFrame = v1634 * (v1632.Rotation + v1632.Position * v1635)
			local v1636 = Instance.new("WeldConstraint")
			v1636.Part0 = v1349
			v1636.Part1 = v1633
			v1636.Parent = v1633
			local v1637 = p1346.accent
			local v1638 = v1352 * CFrame.new(0, 4.95, -0.2)
			local v1639 = v_u_27(p1346, "Collar", Vector3.new(0.45, 0.4, 0.45), v1637, v1354)
			local v1640 = v1349.CFrame
			local v1641 = p1346.s
			v1639.CFrame = v1640 * (v1638.Rotation + v1638.Position * v1641)
			local v1642 = Instance.new("WeldConstraint")
			v1642.Part0 = v1349
			v1642.Part1 = v1639
			v1642.Parent = v1639
			local v1643 = v_u_8
			local v1644 = v1352 * (CFrame.new(0, 4.9, -1.9) * CFrame.Angles(0.15, 0, 0))
			v1355 = v_u_27(p1346, "ScytheBlade", Vector3.new(0.14, 0.55, 3.4), v1643, v1354)
			local v1645 = v1349.CFrame
			local v1646 = p1346.s
			v1355.CFrame = v1645 * (v1644.Rotation + v1644.Position * v1646)
			local v1647 = Instance.new("WeldConstraint")
			v1647.Part0 = v1349
			v1647.Part1 = v1355
			v1647.Parent = v1355
			local v1648 = p1346.glow
			local v1649 = CFrame.new(0, -0.3, 0)
			local v1650 = v_u_27(p1346, "Edge", Vector3.new(0.08, 0.14, 3.3), v1648, v1353)
			local v1651 = v1355.CFrame
			local v1652 = p1346.s
			v1650.CFrame = v1651 * (v1649.Rotation + v1649.Position * v1652)
			local v1653 = Instance.new("WeldConstraint")
			v1653.Part0 = v1355
			v1653.Part1 = v1650
			v1653.Parent = v1650
			local v1654 = p1346.glow
			local v1655 = CFrame.new(0, -0.3, -2) * CFrame.Angles(0.6, 0, 0)
			local v1656 = v_u_27(p1346, "ScytheTip", Vector3.new(0.14, 0.4, 1), v1654, v1353)
			local v1657 = v1355.CFrame
			local v1658 = p1346.s
			v1656.CFrame = v1657 * (v1655.Rotation + v1655.Position * v1658)
			local v1659 = Instance.new("WeldConstraint")
			v1659.Part0 = v1355
			v1659.Part1 = v1656
			v1659.Parent = v1656
			v1356 = 3.4
		elseif v1348 == "claws" then
			for _, v1660 in { v1349, v1350 } do
				for _, v1661 in { -0.25, 0, 0.25 } do
					local v1662 = p1346.glow
					local v1663 = v1352 * CFrame.new(v1661 * v1351.X, -0.6, -0.2) * CFrame.Angles(-0.25, 0, 0)
					local v1664 = v_u_27(p1346, "Claw", Vector3.new(0.08, 1.1, 0.14), v1662, v1353)
					local v1665 = v1660.CFrame
					local v1666 = p1346.s
					v1664.CFrame = v1665 * (v1663.Rotation + v1663.Position * v1666)
					local v1667 = Instance.new("WeldConstraint")
					v1667.Part0 = v1660
					v1667.Part1 = v1664
					v1667.Parent = v1664
				end
			end
		elseif v1348 == "fan" then
			local v1668 = v_u_7
			local v1669, v1670 = CFrame.new(0, -0.35, -0.2)
			local v1671 = v1352 * v1669
			local v1672 = v_u_27(p1346, "FanHandle", Vector3.new(0.14, 0.7, 0.14), v1668, v1670)
			local v1673 = v1349.CFrame
			local v1674 = p1346.s
			v1672.CFrame = v1673 * (v1671.Rotation + v1671.Position * v1674)
			local v1675 = Instance.new("WeldConstraint")
			v1675.Part0 = v1349
			v1675.Part1 = v1672
			v1675.Parent = v1672
			local v1676 = {
				["shape"] = Enum.PartType.Cylinder
			}
			local v1677 = p1346.trim
			local v1678 = v1352 * CFrame.new(0, -1.45, -0.35)
			local v1679 = v_u_27(p1346, "Fan", Vector3.new(0.12, 1.9, 1.9), v1677, v1676)
			local v1680 = v1349.CFrame
			local v1681 = p1346.s
			v1679.CFrame = v1680 * (v1678.Rotation + v1678.Position * v1681)
			local v1682 = Instance.new("WeldConstraint")
			v1682.Part0 = v1349
			v1682.Part1 = v1679
			v1682.Parent = v1679
			local v1683 = p1346.glow
			local v1684 = CFrame.new(0, -1.45, -0.35)
			local v1685 = {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Cylinder
			}
			local v1686 = v1352 * v1684
			local v1687 = v_u_27(p1346, "FanRim", Vector3.new(0.08, 2.15, 2.15), v1683, v1685)
			local v1688 = v1349.CFrame
			local v1689 = p1346.s
			v1687.CFrame = v1688 * (v1686.Rotation + v1686.Position * v1689)
			local v1690 = Instance.new("WeldConstraint")
			v1690.Part0 = v1349
			v1690.Part1 = v1687
			v1690.Parent = v1687
		elseif v1348 == "lantern" then
			local v1691 = v_u_7
			local v1692, v1693 = CFrame.new(0, -0.5, -0.1)
			local v1694 = v1352 * v1692
			local v1695 = v_u_27(p1346, "Chain", Vector3.new(0.08, 0.8, 0.08), v1691, v1693)
			local v1696 = v1349.CFrame
			local v1697 = p1346.s
			v1695.CFrame = v1696 * (v1694.Rotation + v1694.Position * v1697)
			local v1698 = Instance.new("WeldConstraint")
			v1698.Part0 = v1349
			v1698.Part1 = v1695
			v1698.Parent = v1695
			local v1699 = p1346.accent
			local v1700 = v1352 * CFrame.new(0, -0.95, -0.1)
			local v1701 = v_u_27(p1346, "LanternTop", Vector3.new(0.8, 0.15, 0.8), v1699, v1354)
			local v1702 = v1349.CFrame
			local v1703 = p1346.s
			v1701.CFrame = v1702 * (v1700.Rotation + v1700.Position * v1703)
			local v1704 = Instance.new("WeldConstraint")
			v1704.Part0 = v1349
			v1704.Part1 = v1701
			v1704.Parent = v1701
			local v1705 = p1346.accent
			local v1706 = v1352 * CFrame.new(0, -1.8, -0.1)
			local v1707 = v_u_27(p1346, "LanternBase", Vector3.new(0.8, 0.15, 0.8), v1705, v1354)
			local v1708 = v1349.CFrame
			local v1709 = p1346.s
			v1707.CFrame = v1708 * (v1706.Rotation + v1706.Position * v1709)
			local v1710 = Instance.new("WeldConstraint")
			v1710.Part0 = v1349
			v1710.Part1 = v1707
			v1710.Parent = v1707
			local v1711 = p1346.glow
			local v1712 = v1352 * CFrame.new(0, -1.37, -0.1)
			local v1713 = v_u_27(p1346, "Flame", Vector3.new(0.55, 0.65, 0.55), v1711, v1353)
			local v1714 = v1349.CFrame
			local v1715 = p1346.s
			v1713.CFrame = v1714 * (v1712.Rotation + v1712.Position * v1715)
			local v1716 = Instance.new("WeldConstraint")
			v1716.Part0 = v1349
			v1716.Part1 = v1713
			v1716.Parent = v1713
			v_u_176(p1346, {
				["template"] = "Aura",
				["emitter"] = "FlameBack",
				["rate"] = 6,
				["size"] = 0.22,
				["life"] = nil,
				["light"] = 0.8,
				["locked"] = true,
				["life"] = NumberRange.new(0.3, 0.5)
			}, v1713, 1)
		elseif v1348 == "hammer" then
			local v1717 = v_u_9
			local v1718, v1719 = CFrame.new(0, 0, -1.2)
			local v1720 = v1352 * v1718
			v1355 = v_u_27(p1346, "Haft", Vector3.new(0.3, 0.3, 3.4), v1717, v1719)
			local v1721 = v1349.CFrame
			local v1722 = p1346.s
			v1355.CFrame = v1721 * (v1720.Rotation + v1720.Position * v1722)
			local v1723 = Instance.new("WeldConstraint")
			v1723.Part0 = v1349
			v1723.Part1 = v1355
			v1723.Parent = v1355
			local v1724 = p1346.accent
			local v1725 = v1352 * CFrame.new(0, 0, -2.95)
			local v1726 = v_u_27(p1346, "HammerHead", Vector3.new(1, 1.8, 1), v1724, v1354)
			local v1727 = v1349.CFrame
			local v1728 = p1346.s
			v1726.CFrame = v1727 * (v1725.Rotation + v1725.Position * v1728)
			local v1729 = Instance.new("WeldConstraint")
			v1729.Part0 = v1349
			v1729.Part1 = v1726
			v1729.Parent = v1726
			for _, v1730 in { -1, 1 } do
				local v1731 = p1346.glow
				local v1732 = CFrame.new(0, v1730 * 0.88, 0)
				local v1733 = v_u_27(p1346, "Face", Vector3.new(1.06, 0.14, 1.06), v1731, v1353)
				local v1734 = v1726.CFrame
				local v1735 = p1346.s
				v1733.CFrame = v1734 * (v1732.Rotation + v1732.Position * v1735)
				local v1736 = Instance.new("WeldConstraint")
				v1736.Part0 = v1726
				v1736.Part1 = v1733
				v1736.Parent = v1733
				local v1737 = v_u_7
				local v1738 = CFrame.new(0, v1730 * 0.45, 0)
				local v1739 = v_u_27(p1346, "Band", Vector3.new(1.1, 0.16, 1.1), v1737, v1354)
				local v1740 = v1726.CFrame
				local v1741 = p1346.s
				v1739.CFrame = v1740 * (v1738.Rotation + v1738.Position * v1741)
				local v1742 = Instance.new("WeldConstraint")
				v1742.Part0 = v1726
				v1742.Part1 = v1739
				v1742.Parent = v1739
			end
			v1356 = 3.4
		elseif v1348 == "bow" then
			local v1743 = {
				["material"] = Enum.Material.Wood
			}
			local v1744 = p1346.accent
			local v1745, v1746 = CFrame.new(0, 0, -0.3)
			local v1747 = v1352 * v1745
			local v1748 = v_u_27(p1346, "BowGrip", Vector3.new(0.24, 0.6, 0.24), v1744, v1746)
			local v1749 = v1349.CFrame
			local v1750 = p1346.s
			v1748.CFrame = v1749 * (v1747.Rotation + v1747.Position * v1750)
			local v1751 = Instance.new("WeldConstraint")
			v1751.Part0 = v1349
			v1751.Part1 = v1748
			v1751.Parent = v1748
			local v1752 = { Vector3.new(0, 0, -0.35), Vector3.new(0, 0.95, -0.25), Vector3.new(0, 1.7, 0.1) }
			for _, v1753 in { 1, -1 } do
				for v1754 = 1, 2 do
					local v1755 = v1752[v1754]
					local v1756 = v1752[v1754 + 1]
					local v1757 = v1352 * CFrame.new(v1755.X, v1755.Y * v1753, v1755.Z)
					local v1758 = v1352 * CFrame.new(v1756.X, v1756.Y * v1753, v1756.Z)
					local v1759 = v1757.Position
					local v1760 = v1758.Position
					local v1761 = v_u_9
					local v1762 = (v1759 + v1760) / 2
					local v1763 = (v1760 - v1759).Magnitude
					local v1764 = Vector3.new(0.2, 0.2, v1763)
					local v1765 = CFrame.lookAt(v1762, v1760)
					local v1766 = v_u_27(p1346, "Limb", v1764, v1761, v1743)
					local v1767 = v1349.CFrame
					local v1768 = p1346.s
					v1766.CFrame = v1767 * (v1765.Rotation + v1765.Position * v1768)
					local v1769 = Instance.new("WeldConstraint")
					v1769.Part0 = v1349
					v1769.Part1 = v1766
					v1769.Parent = v1766
				end
				local v1770 = p1346.glow
				local v1771 = v1352 * CFrame.new(0, 1.75 * v1753, 0.12)
				local v1772 = v_u_27(p1346, "BowTip", Vector3.new(0.2, 0.26, 0.2), v1770, v1353)
				local v1773 = v1349.CFrame
				local v1774 = p1346.s
				v1772.CFrame = v1773 * (v1771.Rotation + v1771.Position * v1774)
				local v1775 = Instance.new("WeldConstraint")
				v1775.Part0 = v1349
				v1775.Part1 = v1772
				v1775.Parent = v1772
			end
			local v1776 = p1346.glow
			local v1777 = v1352 * CFrame.new(0, 0, 0.12)
			local v1778 = v_u_27(p1346, "String", Vector3.new(0.05, 3.4, 0.05), v1776, v1353)
			local v1779 = v1349.CFrame
			local v1780 = p1346.s
			v1778.CFrame = v1779 * (v1777.Rotation + v1777.Position * v1780)
			local v1781 = Instance.new("WeldConstraint")
			v1781.Part0 = v1349
			v1781.Part1 = v1778
			v1781.Parent = v1778
			local v1782 = v_u_9
			local v1783, v1784 = CFrame.new(0.12, 0, -0.65)
			local v1785 = v1352 * v1783
			local v1786 = v_u_27(p1346, "Arrow", Vector3.new(0.07, 0.07, 1.9), v1782, v1784)
			local v1787 = v1349.CFrame
			local v1788 = p1346.s
			v1786.CFrame = v1787 * (v1785.Rotation + v1785.Position * v1788)
			local v1789 = Instance.new("WeldConstraint")
			v1789.Part0 = v1349
			v1789.Part1 = v1786
			v1789.Parent = v1786
			local v1790 = p1346.glow
			local v1791 = v1352 * CFrame.new(0.12, 0, -1.7)
			local v1792 = v_u_27(p1346, "ArrowHead", Vector3.new(0.12, 0.26, 0.36), v1790, v1353)
			local v1793 = v1349.CFrame
			local v1794 = p1346.s
			v1792.CFrame = v1793 * (v1791.Rotation + v1791.Position * v1794)
			local v1795 = Instance.new("WeldConstraint")
			v1795.Part0 = v1349
			v1795.Part1 = v1792
			v1795.Parent = v1792
		elseif v1348 == "fists" then
			local v1796 = v_u_17[p1346.look.body or "plastic"] and 0.25 or 0
			for _, v1797 in { v1349, v1350 } do
				local v1798 = v1351.X + 0.15 + v1796 * 2
				local v1799 = 0.7 + v1796
				local v1800 = v1351.Z + 0.15 + v1796 * 2
				local v1801 = Vector3.new(v1798, v1799, v1800)
				local v1802 = p1346.accent
				local v1803, v1804 = CFrame.new(0, -v1351.Y / 2 + 0.35, 0)
				local v1805 = v_u_27(p1346, "Gauntlet", v1801, v1802, v1804)
				local v1806 = v1797.CFrame
				local v1807 = p1346.s
				v1805.CFrame = v1806 * (v1803.Rotation + v1803.Position * v1807)
				local v1808 = Instance.new("WeldConstraint")
				v1808.Part0 = v1797
				v1808.Part1 = v1805
				v1808.Parent = v1805
				local v1809 = v1351.X + 0.2 + v1796 * 2
				local v1810 = Vector3.new(v1809, 0.18, 0.12)
				local v1811 = p1346.glow
				local v1812 = CFrame.new(0, -v1351.Y / 2 + 0.3, -(v1351.Z / 2 + 0.1 + v1796))
				local v1813 = v_u_27(p1346, "Knuckles", v1810, v1811, v1353)
				local v1814 = v1797.CFrame
				local v1815 = p1346.s
				v1813.CFrame = v1814 * (v1812.Rotation + v1812.Position * v1815)
				local v1816 = Instance.new("WeldConstraint")
				v1816.Part0 = v1797
				v1816.Part1 = v1813
				v1816.Parent = v1813
			end
		end
		if v1355 then
			local v1817 = v_u_68
			local v1818 = -v1356 / 2
			local v1819 = Vector3.new(0, 0, v1818)
			local v1820 = v1356 * 0.1
			v1817(p1346, v1355, v1819, Vector3.new(0, 0, v1820), 0.14, 0.3)
		end
	end
end
local function v_u_1830(p1822, p1823, p1824, p1825, p1826, p1827) -- name: orbit
	p1823.Anchored = true
	local v1828 = p1822.orbits
	local v1829 = {
		["part"] = p1823,
		["radius"] = p1824 * p1822.s,
		["height"] = p1825 * p1822.s,
		["speed"] = p1826,
		["phase"] = p1827
	}
	table.insert(v1828, v1829)
	p1823.CFrame = CFrame.new(math.cos(p1827) * p1824 * p1822.s, p1825 * p1822.s, math.sin(p1827) * p1824 * p1822.s)
end
local function v_u_2419(p1831, p1832, p1833) -- name: gear
	-- upvalues: (copy) v_u_27, (copy) v_u_7, (copy) v_u_11, (copy) v_u_57, (copy) v_u_1830, (copy) v_u_68, (copy) v_u_114, (copy) v_u_9, (copy) v_u_143, (copy) v_u_10
	local v1834 = p1832.torso
	local v1835 = p1832.d
	local v1836 = v1835.torso
	local v1837 = v1835.arm
	local v1838 = v1836.Y
	local v1839 = {
		["material"] = Enum.Material.Fabric
	}
	local v1840 = {
		["material"] = Enum.Material.Metal
	}
	local v1841 = {
		["neon"] = true
	}
	local v1842 = -(v1836.Z / 2)
	local v1843 = {}
	if p1832.rightArmPart then
		local v1844 = p1832.rightArmPart
		table.insert(v1843, v1844)
	end
	if p1832.leftArmPart then
		local v1845 = p1832.leftArmPart
		table.insert(v1843, v1845)
	end
	local v1846 = p1831.look.gear
	local v1847
	if v1846 == nil then
		v1847 = false
	else
		v1847 = table.find(v1846, "vest") ~= nil
	end
	if v1847 then
		local v1848 = v1836.X + 0.12
		local v1849 = v1838 * 0.8
		local v1850 = v1836.Z + 0.16
		local v1851 = Vector3.new(v1848, v1849, v1850)
		local v1852 = p1831.trim
		local v1853 = CFrame.new(0, 0.08, 0)
		local v1854 = v_u_27(p1831, "Vest", v1851, v1852, v1839)
		local v1855 = v1834.CFrame
		local v1856 = p1831.s
		v1854.CFrame = v1855 * (v1853.Rotation + v1853.Position * v1856)
		local v1857 = Instance.new("WeldConstraint")
		v1857.Part0 = v1834
		v1857.Part1 = v1854
		v1857.Parent = v1854
		local v1858 = v1836.X * 0.75
		local v1859 = v1836.Z + 0.26
		local v1860 = Vector3.new(v1858, 0.3, v1859)
		local v1861 = p1831.trim
		local v1862 = CFrame.new(0, v1838 / 2 - 0.05, 0)
		local v1863 = v_u_27(p1831, "VestCollar", v1860, v1861, v1839)
		local v1864 = v1834.CFrame
		local v1865 = p1831.s
		v1863.CFrame = v1864 * (v1862.Rotation + v1862.Position * v1865)
		local v1866 = Instance.new("WeldConstraint")
		v1866.Part0 = v1834
		v1866.Part1 = v1863
		v1866.Parent = v1863
		for _, v1867 in { -1, 1 } do
			local v1868 = p1831.trim:Lerp(v_u_7, 0.25)
			local v1869, v1870 = CFrame.new(v1867 * 0.45, -0.25, v1842 - 0.12)
			local v1871 = v_u_27(p1831, "Pouch", Vector3.new(0.45, 0.4, 0.15), v1868, v1870)
			local v1872 = v1834.CFrame
			local v1873 = p1831.s
			v1871.CFrame = v1872 * (v1869.Rotation + v1869.Position * v1873)
			local v1874 = Instance.new("WeldConstraint")
			v1874.Part0 = v1834
			v1874.Part1 = v1871
			v1874.Parent = v1871
		end
	end
	local v1875 = p1831.look.gear
	local v1876
	if v1875 == nil then
		v1876 = false
	else
		v1876 = table.find(v1875, "poncho") ~= nil
	end
	if v1876 then
		local v1877 = v1836.X + 0.5
		local v1878 = v1838 * 0.55
		local v1879 = v1836.Z + 0.45
		local v1880 = Vector3.new(v1877, v1878, v1879)
		local v1881 = p1831.trim
		local v1882 = CFrame.new(0, v1838 / 2 - v1838 * 0.25, 0)
		local v1883 = v_u_27(p1831, "Poncho", v1880, v1881, v1839)
		local v1884 = v1834.CFrame
		local v1885 = p1831.s
		v1883.CFrame = v1884 * (v1882.Rotation + v1882.Position * v1885)
		local v1886 = Instance.new("WeldConstraint")
		v1886.Part0 = v1834
		v1886.Part1 = v1883
		v1886.Parent = v1883
	end
	local v1887 = p1831.look.gear
	local v1888
	if v1887 == nil then
		v1888 = false
	else
		v1888 = table.find(v1887, "robe") ~= nil
	end
	if v1888 then
		local v1889 = v1836.X + 0.35
		local v1890 = v1835.leg.Y * 0.7
		local v1891 = v1836.Z + 0.4
		local v1892 = Vector3.new(v1889, v1890, v1891)
		local v1893 = p1831.shirt
		local v1894 = CFrame.new(0, -v1838 / 2 - v1835.leg.Y * 0.3, 0)
		local v1895 = v_u_27(p1831, "Robe", v1892, v1893, v1839)
		local v1896 = v1834.CFrame
		local v1897 = p1831.s
		v1895.CFrame = v1896 * (v1894.Rotation + v1894.Position * v1897)
		local v1898 = Instance.new("WeldConstraint")
		v1898.Part0 = v1834
		v1898.Part1 = v1895
		v1898.Parent = v1895
		local v1899 = v1836.X + 0.42
		local v1900 = v1836.Z + 0.46
		local v1901 = Vector3.new(v1899, 0.16, v1900)
		local v1902 = p1831.trim
		local v1903 = CFrame.new(0, -v1838 / 2 - v1835.leg.Y * 0.62, 0)
		local v1904 = v_u_27(p1831, "RobeHem", v1901, v1902, v1839)
		local v1905 = v1834.CFrame
		local v1906 = p1831.s
		v1904.CFrame = v1905 * (v1903.Rotation + v1903.Position * v1906)
		local v1907 = Instance.new("WeldConstraint")
		v1907.Part0 = v1834
		v1907.Part1 = v1904
		v1907.Parent = v1904
	end
	local v1908 = p1831.look.gear
	local v1909
	if v1908 == nil then
		v1909 = false
	else
		v1909 = table.find(v1908, "kilt") ~= nil
	end
	if v1909 then
		local v1910 = v1836.X + 0.1
		local v1911 = v1835.leg.Y * 0.45
		local v1912 = v1836.Z + 0.2
		local v1913 = Vector3.new(v1910, v1911, v1912)
		local v1914 = p1831.pants
		local v1915 = CFrame.new(0, -v1838 / 2 - v1835.leg.Y * 0.18, 0)
		local v1916 = v_u_27(p1831, "Kilt", v1913, v1914, v1839)
		local v1917 = v1834.CFrame
		local v1918 = p1831.s
		v1916.CFrame = v1917 * (v1915.Rotation + v1915.Position * v1918)
		local v1919 = Instance.new("WeldConstraint")
		v1919.Part0 = v1834
		v1919.Part1 = v1916
		v1919.Parent = v1916
		local v1920 = v1835.leg.Y * 0.42
		local v1921 = Vector3.new(0.5, v1920, 0.06)
		local v1922 = p1831.accent
		local v1923 = CFrame.new(0, -v1838 / 2 - v1835.leg.Y * 0.2, v1842 - 0.13)
		local v1924 = v_u_27(p1831, "KiltPanel", v1921, v1922, v1840)
		local v1925 = v1834.CFrame
		local v1926 = p1831.s
		v1924.CFrame = v1925 * (v1923.Rotation + v1923.Position * v1926)
		local v1927 = Instance.new("WeldConstraint")
		v1927.Part0 = v1834
		v1927.Part1 = v1924
		v1927.Parent = v1924
	end
	local v1928 = p1831.look.gear
	local v1929
	if v1928 == nil then
		v1929 = false
	else
		v1929 = table.find(v1928, "chest") ~= nil
	end
	if v1929 then
		local v1930 = p1831.look.gear
		local v1931
		if v1930 == nil then
			v1931 = false
		else
			v1931 = table.find(v1930, "sode") ~= nil
		end
		local v1932
		if v1931 then
			v1932 = p1831.trim
		else
			v1932 = p1831.accent
		end
		local v1933 = v1836.X + 0.1
		local v1934 = v1838 * 0.62
		local v1935 = Vector3.new(v1933, v1934, 0.22)
		local v1936 = CFrame.new(0, 0.25, v1842 - 0.06)
		local v1937 = v_u_27(p1831, "Chest", v1935, v1932, v1840)
		local v1938 = v1834.CFrame
		local v1939 = p1831.s
		v1937.CFrame = v1938 * (v1936.Rotation + v1936.Position * v1939)
		local v1940 = Instance.new("WeldConstraint")
		v1940.Part0 = v1834
		v1940.Part1 = v1937
		v1940.Parent = v1937
		local v1941 = v1836.X + 0.1
		local v1942 = v1838 * 0.62
		local v1943 = Vector3.new(v1941, v1942, 0.22)
		local v1944 = CFrame.new(0, 0.25, v1836.Z / 2 + 0.06)
		local v1945 = v_u_27(p1831, "Back", v1943, v1932, v1840)
		local v1946 = v1834.CFrame
		local v1947 = p1831.s
		v1945.CFrame = v1946 * (v1944.Rotation + v1944.Position * v1947)
		local v1948 = Instance.new("WeldConstraint")
		v1948.Part0 = v1834
		v1948.Part1 = v1945
		v1948.Parent = v1945
		local v1949 = p1831.glow
		local v1950 = CFrame.new(0, 0.3, v1842 - 0.2) * CFrame.Angles(0, 0, 0.7853981633974483)
		local v1951 = v_u_27(p1831, "Emblem", Vector3.new(0.45, 0.45, 0.06), v1949, v1841)
		local v1952 = v1834.CFrame
		local v1953 = p1831.s
		v1951.CFrame = v1952 * (v1950.Rotation + v1950.Position * v1953)
		local v1954 = Instance.new("WeldConstraint")
		v1954.Part0 = v1834
		v1954.Part1 = v1951
		v1954.Parent = v1951
	end
	local v1955 = p1831.look.gear
	local v1956
	if v1955 == nil then
		v1956 = false
	else
		v1956 = table.find(v1955, "collar") ~= nil
	end
	if v1956 then
		local v1957 = v1836.X * 0.92
		local v1958 = v1836.Z + 0.14
		local v1959 = Vector3.new(v1957, 0.42, v1958)
		local v1960 = p1831.accent
		local v1961 = CFrame.new(0, v1838 / 2 - 0.2, 0)
		local v1962 = v_u_27(p1831, "Collar", v1959, v1960, v1840)
		local v1963 = v1834.CFrame
		local v1964 = p1831.s
		v1962.CFrame = v1963 * (v1961.Rotation + v1961.Position * v1964)
		local v1965 = Instance.new("WeldConstraint")
		v1965.Part0 = v1834
		v1965.Part1 = v1962
		v1965.Parent = v1962
		local v1966 = v1836.X * 0.8
		local v1967 = v1836.Z + 0.16
		local v1968 = Vector3.new(v1966, 0.16, v1967)
		local v1969 = p1831.trim
		local v1970, v1971 = CFrame.new(0, v1838 / 2 - 0.3, 0)
		local v1972 = v_u_27(p1831, "CollarBand", v1968, v1969, v1971)
		local v1973 = v1834.CFrame
		local v1974 = p1831.s
		v1972.CFrame = v1973 * (v1970.Rotation + v1970.Position * v1974)
		local v1975 = Instance.new("WeldConstraint")
		v1975.Part0 = v1834
		v1975.Part1 = v1972
		v1975.Parent = v1972
		local v1976 = p1831.glow
		local v1977 = CFrame.new(0, v1838 / 2 - 0.32, v1842 - 0.1)
		local v1978 = v_u_27(p1831, "CollarGem", Vector3.new(0.3, 0.3, 0.08), v1976, v1841)
		local v1979 = v1834.CFrame
		local v1980 = p1831.s
		v1978.CFrame = v1979 * (v1977.Rotation + v1977.Position * v1980)
		local v1981 = Instance.new("WeldConstraint")
		v1981.Part0 = v1834
		v1981.Part1 = v1978
		v1981.Parent = v1978
	end
	local v1982 = p1831.look.gear
	local v1983
	if v1982 == nil then
		v1983 = false
	else
		v1983 = table.find(v1982, "sash") ~= nil
	end
	if v1983 then
		local v1984 = v1838 * 1.3
		local v1985 = v1836.Z + 0.12
		local v1986 = Vector3.new(0.38, v1984, v1985)
		local v1987 = p1831.trim
		local v1988 = CFrame.Angles(0, 0, 0.72)
		local v1989 = v_u_27(p1831, "Sash", v1986, v1987, v1839)
		local v1990 = v1834.CFrame
		local v1991 = p1831.s
		v1989.CFrame = v1990 * (v1988.Rotation + v1988.Position * v1991)
		local v1992 = Instance.new("WeldConstraint")
		v1992.Part0 = v1834
		v1992.Part1 = v1989
		v1992.Parent = v1989
	end
	local v1993 = p1831.look.gear
	local v1994
	if v1993 == nil then
		v1994 = false
	else
		v1994 = table.find(v1993, "wraps") ~= nil
	end
	if v1994 then
		for v1995, v1996 in { 0.5, -0.1, -0.6 } do
			local v1997 = v1836.X + 0.05
			local v1998 = v1836.Z + 0.05
			local v1999 = Vector3.new(v1997, 0.14, v1998)
			local v2000 = p1831.trim
			local v2001 = CFrame.new(0, v1996, 0) * CFrame.Angles(0, 0, (v1995 - 2) * 0.08)
			local v2002 = v_u_27(p1831, "Wrap", v1999, v2000, v1839)
			local v2003 = v1834.CFrame
			local v2004 = p1831.s
			v2002.CFrame = v2003 * (v2001.Rotation + v2001.Position * v2004)
			local v2005 = Instance.new("WeldConstraint")
			v2005.Part0 = v1834
			v2005.Part1 = v2002
			v2005.Parent = v2002
		end
		for _, v2006 in v1843 do
			local v2007 = v1837.X + 0.05
			local v2008 = v1837.Z + 0.05
			local v2009 = Vector3.new(v2007, 0.14, v2008)
			local v2010 = p1831.trim
			local v2011 = CFrame.new(0, -0.2, 0) * CFrame.Angles(0, 0, 0.1)
			local v2012 = v_u_27(p1831, "Wrap", v2009, v2010, v1839)
			local v2013 = v2006.CFrame
			local v2014 = p1831.s
			v2012.CFrame = v2013 * (v2011.Rotation + v2011.Position * v2014)
			local v2015 = Instance.new("WeldConstraint")
			v2015.Part0 = v2006
			v2015.Part1 = v2012
			v2015.Parent = v2012
		end
	end
	local v2016 = p1831.look.gear
	local v2017
	if v2016 == nil then
		v2017 = false
	else
		v2017 = table.find(v2016, "fur") ~= nil
	end
	if v2017 then
		for _, v2018 in { -1, 1 } do
			local v2019 = v1836.Z + 0.45
			local v2020 = Vector3.new(1.3, 0.75, v2019)
			local v2021 = v_u_11
			local v2022 = CFrame.new(v2018 * v1836.X * 0.42, v1838 / 2 + 0.05, 0)
			local v2023 = v_u_27(p1831, "Fur", v2020, v2021, v1839)
			local v2024 = v1834.CFrame
			local v2025 = p1831.s
			v2023.CFrame = v2024 * (v2022.Rotation + v2022.Position * v2025)
			local v2026 = Instance.new("WeldConstraint")
			v2026.Part0 = v1834
			v2026.Part1 = v2023
			v2026.Parent = v2023
		end
		local v2027 = v1836.X * 0.65
		local v2028 = v1836.Z + 0.5
		local v2029 = Vector3.new(v2027, 0.55, v2028)
		local v2030 = v_u_11
		local v2031 = CFrame.new(0, v1838 / 2 + 0.05, 0)
		local v2032 = v_u_27(p1831, "FurCollar", v2029, v2030, v1839)
		local v2033 = v1834.CFrame
		local v2034 = p1831.s
		v2032.CFrame = v2033 * (v2031.Rotation + v2031.Position * v2034)
		local v2035 = Instance.new("WeldConstraint")
		v2035.Part0 = v1834
		v2035.Part1 = v2032
		v2035.Parent = v2032
	end
	local v2036 = p1831.look.gear
	local v2037
	if v2036 == nil then
		v2037 = false
	else
		v2037 = table.find(v2036, "boulders") ~= nil
	end
	if v2037 then
		for _, v2038 in { -1, 1 } do
			local v2039 = p1831.accent
			local v2040 = CFrame.new(v2038 * (v1836.X / 2 - 0.2), v1838 / 2 + 0.2, 0.15) * CFrame.Angles(0.3, v2038 * 0.5, v2038 * 0.2)
			local v2041 = v_u_27(p1831, "Boulder", Vector3.new(1.1, 0.9, 1), v2039, {
				["material"] = p1831.mat
			})
			local v2042 = v1834.CFrame
			local v2043 = p1831.s
			v2041.CFrame = v2042 * (v2040.Rotation + v2040.Position * v2043)
			local v2044 = Instance.new("WeldConstraint")
			v2044.Part0 = v1834
			v2044.Part1 = v2041
			v2044.Parent = v2041
		end
	end
	local v2045 = p1831.look.gear
	local v2046
	if v2045 == nil then
		v2046 = false
	else
		v2046 = table.find(v2045, "cracks") ~= nil
	end
	if v2046 then
		for _, v2047 in {
			{
				-0.45,
				0.15,
				0.6,
				0.4
			},
			{
				0.5,
				-0.2,
				0.45,
				-0.5
			},
			{
				0.05,
				-0.55,
				0.35,
				0.2
			}
		} do
			local v2048 = v1838 * v2047[3]
			local v2049 = Vector3.new(0.14, v2048, 0.06)
			local v2050 = p1831.glow
			local v2051 = CFrame.new(v2047[1], v2047[2], v1842 - 0.02) * CFrame.Angles(0, 0, v2047[4])
			local v2052 = v_u_27(p1831, "Crack", v2049, v2050, v1841)
			local v2053 = v1834.CFrame
			local v2054 = p1831.s
			v2052.CFrame = v2053 * (v2051.Rotation + v2051.Position * v2054)
			local v2055 = Instance.new("WeldConstraint")
			v2055.Part0 = v1834
			v2055.Part1 = v2052
			v2055.Parent = v2052
		end
		local v2056 = p1831.eye
		local v2057 = CFrame.new(0, 0.4, v1842 - 0.03) * CFrame.Angles(0, 0, 0.7853981633974483)
		local v2058 = v_u_27(p1831, "Core", Vector3.new(0.6, 0.6, 0.08), v2056, v1841)
		local v2059 = v1834.CFrame
		local v2060 = p1831.s
		v2058.CFrame = v2059 * (v2057.Rotation + v2057.Position * v2060)
		local v2061 = Instance.new("WeldConstraint")
		v2061.Part0 = v1834
		v2061.Part1 = v2058
		v2061.Parent = v2058
		for _, v2062 in v1843 do
			local v2063 = v1837.Y * 0.5
			local v2064 = Vector3.new(0.12, v2063, 0.05)
			local v2065 = p1831.glow
			local v2066 = CFrame.new(0, -0.1, -(v1837.Z / 2 + 0.02)) * CFrame.Angles(0, 0, 0.3)
			local v2067 = v_u_27(p1831, "Crack", v2064, v2065, v1841)
			local v2068 = v2062.CFrame
			local v2069 = p1831.s
			v2067.CFrame = v2068 * (v2066.Rotation + v2066.Position * v2069)
			local v2070 = Instance.new("WeldConstraint")
			v2070.Part0 = v2062
			v2070.Part1 = v2067
			v2070.Parent = v2067
		end
	end
	local v2071 = p1831.look.gear
	local v2072
	if v2071 == nil then
		v2072 = false
	else
		v2072 = table.find(v2071, "crystals") ~= nil
	end
	if v2072 then
		for v2073, v2074 in {
			{
				v1836.X / 2 - 0.1,
				v1838 / 2 + 0.35,
				0.2,
				-0.45,
				1.3
			},
			{
				-(v1836.X / 2 - 0.1),
				v1838 / 2 + 0.3,
				0.2,
				0.45,
				1.1
			},
			{
				0.3,
				v1838 / 2 - 0.1,
				v1836.Z / 2 + 0.25,
				-0.2,
				1.4
			},
			{
				-0.45,
				-0.1,
				v1836.Z / 2 + 0.2,
				0.3,
				1
			}
		} do
			local v2075 = v2074[5]
			local v2076 = Vector3.new(0.42, v2075, 0.42)
			local v2077
			if v2073 % 2 == 1 then
				v2077 = p1831.glow
			else
				v2077 = p1831.eye
			end
			local v2078 = CFrame.new(v2074[1], v2074[2], v2074[3]) * CFrame.Angles(v2074[3] > 0.5 and 0.5 or 0, 0, v2074[4]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v2079 = v_u_27(p1831, "Crystal", v2076, v2077, v1841)
			local v2080 = v1834.CFrame
			local v2081 = p1831.s
			v2079.CFrame = v2080 * (v2078.Rotation + v2078.Position * v2081)
			local v2082 = Instance.new("WeldConstraint")
			v2082.Part0 = v1834
			v2082.Part1 = v2079
			v2082.Parent = v2079
		end
	end
	local v2083 = p1831.look.gear
	local v2084
	if v2083 == nil then
		v2084 = false
	else
		v2084 = table.find(v2083, "moss") ~= nil
	end
	if v2084 then
		local v2085 = v1836.X + 0.2
		local v2086 = v1836.Z + 0.3
		local v2087 = Vector3.new(v2085, 0.35, v2086)
		local v2088 = p1831.trim
		local v2089 = CFrame.new(0, v1838 / 2 + 0.1, 0)
		local v2090 = v_u_27(p1831, "Moss", v2087, v2088, {
			["material"] = Enum.Material.Grass
		})
		local v2091 = v1834.CFrame
		local v2092 = p1831.s
		v2090.CFrame = v2091 * (v2089.Rotation + v2089.Position * v2092)
		local v2093 = Instance.new("WeldConstraint")
		v2093.Part0 = v1834
		v2093.Part1 = v2090
		v2093.Parent = v2090
		local v2094 = Color3.fromRGB(226, 214, 180)
		for v2095, v2096 in {
			{
				0.6,
				0.65,
				0.25,
				1
			},
			{
				-0.75,
				0.55,
				0.35,
				0.8
			},
			{
				0.1,
				0.1,
				v1836.Z / 2 + 0.35,
				1.2
			}
		} do
			local v2097 = v2095 == 3
			local v2098 = CFrame.new(v2096[1], v1838 / 2 + v2096[2], v2096[3])
			if v2097 then
				v2098 = CFrame.new(v2096[1], v2096[2], v2096[3]) * CFrame.Angles(1.5707963267948966, 0, 0)
			end
			local v2099 = Instance.new("Part")
			v2099.Name = "Stem"
			v2099.Size = Vector3.new(0.28, 0.55, 0.28) * p1831.s
			v2099.Color = v2094
			v2099.Material = Enum.Material.Plastic
			v2099.CanCollide = false
			v2099.CanTouch = false
			v2099.CanQuery = false
			v2099.Massless = true
			v2099.Anchored = false
			v2099.CastShadow = (Vector3.new(0.28, 0.55, 0.28)).Magnitude > 1.1
			v2099.TopSurface = Enum.SurfaceType.Smooth
			v2099.BottomSurface = Enum.SurfaceType.Smooth
			v2099.Parent = p1831.model
			local v2100 = v1834.CFrame
			local v2101 = p1831.s
			v2099.CFrame = v2100 * (v2098.Rotation + v2098.Position * v2101)
			local v2102 = Instance.new("WeldConstraint")
			v2102.Part0 = v1834
			v2102.Part1 = v2099
			v2102.Parent = v2099
			local v2103 = v2096[4]
			local v2104 = v2096[4]
			local v2105 = Vector3.new(0.35, v2103, v2104)
			local v2106 = p1831.glow
			local v2107 = v2098 * CFrame.new(0, 0.35, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
			local v2108 = v_u_27(p1831, "Cap", v2105, v2106, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Cylinder
			})
			local v2109 = v1834.CFrame
			local v2110 = p1831.s
			v2108.CFrame = v2109 * (v2107.Rotation + v2107.Position * v2110)
			local v2111 = Instance.new("WeldConstraint")
			v2111.Part0 = v1834
			v2111.Part1 = v2108
			v2111.Parent = v2108
		end
	end
	local v2112 = p1831.look.gear
	local v2113
	if v2112 == nil then
		v2113 = false
	else
		v2113 = table.find(v2112, "fin") ~= nil
	end
	if v2113 then
		local v2114 = p1831.trim
		local v2115 = CFrame.new(0, 0.2, v1836.Z / 2 + 0.55) * CFrame.Angles(0, 3.141592653589793, 0)
		local v2116 = v_u_27(p1831, "Fin", Vector3.new(0.15, 1.6, 1.3), v2114, {
			["wedge"] = true
		})
		local v2117 = v1834.CFrame
		local v2118 = p1831.s
		v2116.CFrame = v2117 * (v2115.Rotation + v2115.Position * v2118)
		local v2119 = Instance.new("WeldConstraint")
		v2119.Part0 = v1834
		v2119.Part1 = v2116
		v2119.Parent = v2116
	end
	local v2120 = p1831.look.gear
	local v2121
	if v2120 == nil then
		v2121 = false
	else
		v2121 = table.find(v2120, "pauldrons") ~= nil
	end
	if v2121 then
		for _, v2122 in v1843 do
			local v2123 = v1837.X + 0.45
			local v2124 = v1837.Z + 0.45
			local v2125 = Vector3.new(v2123, 0.5, v2124)
			local v2126 = p1831.accent
			local v2127 = CFrame.new(0, v1837.Y / 2 - 0.05, 0)
			local v2128 = v_u_27(p1831, "Pauldron", v2125, v2126, v1840)
			local v2129 = v2122.CFrame
			local v2130 = p1831.s
			v2128.CFrame = v2129 * (v2127.Rotation + v2127.Position * v2130)
			local v2131 = Instance.new("WeldConstraint")
			v2131.Part0 = v2122
			v2131.Part1 = v2128
			v2131.Parent = v2128
			local v2132 = v1837.X + 0.5
			local v2133 = v1837.Z + 0.5
			local v2134 = Vector3.new(v2132, 0.12, v2133)
			local v2135 = p1831.glow
			local v2136 = CFrame.new(0, v1837.Y / 2 - 0.32, 0)
			local v2137 = v_u_27(p1831, "PauldronRim", v2134, v2135, v1841)
			local v2138 = v2122.CFrame
			local v2139 = p1831.s
			v2137.CFrame = v2138 * (v2136.Rotation + v2136.Position * v2139)
			local v2140 = Instance.new("WeldConstraint")
			v2140.Part0 = v2122
			v2140.Part1 = v2137
			v2140.Parent = v2137
		end
	end
	local v2141 = p1831.look.gear
	local v2142
	if v2141 == nil then
		v2142 = false
	else
		v2142 = table.find(v2141, "sode") ~= nil
	end
	if v2142 then
		for _, v2143 in v1843 do
			local v2144 = v1837.X + 0.5
			local v2145 = v1837.Z + 0.45
			local v2146 = Vector3.new(v2144, 0.42, v2145)
			local v2147 = p1831.shirt
			local v2148, v2149 = CFrame.new(0, v1837.Y / 2 - 0.05, 0)
			local v2150 = v_u_27(p1831, "Sode", v2146, v2147, v2149)
			local v2151 = v2143.CFrame
			local v2152 = p1831.s
			v2150.CFrame = v2151 * (v2148.Rotation + v2148.Position * v2152)
			local v2153 = Instance.new("WeldConstraint")
			v2153.Part0 = v2143
			v2153.Part1 = v2150
			v2153.Parent = v2150
			local v2154 = v1837.X + 0.6
			local v2155 = v1837.Z + 0.5
			local v2156 = Vector3.new(v2154, 0.42, v2155)
			local v2157 = p1831.shirt
			local v2158, v2159 = CFrame.new(0, v1837.Y / 2 - 0.45, 0)
			local v2160 = v_u_27(p1831, "Sode", v2156, v2157, v2159)
			local v2161 = v2143.CFrame
			local v2162 = p1831.s
			v2160.CFrame = v2161 * (v2158.Rotation + v2158.Position * v2162)
			local v2163 = Instance.new("WeldConstraint")
			v2163.Part0 = v2143
			v2163.Part1 = v2160
			v2163.Parent = v2160
			local v2164 = v1837.X + 0.62
			local v2165 = v1837.Z + 0.52
			local v2166 = Vector3.new(v2164, 0.1, v2165)
			local v2167 = p1831.accent
			local v2168 = CFrame.new(0, v1837.Y / 2 - 0.7, 0)
			local v2169 = v_u_27(p1831, "SodeEdge", v2166, v2167, v1840)
			local v2170 = v2143.CFrame
			local v2171 = p1831.s
			v2169.CFrame = v2170 * (v2168.Rotation + v2168.Position * v2171)
			local v2172 = Instance.new("WeldConstraint")
			v2172.Part0 = v2143
			v2172.Part1 = v2169
			v2172.Parent = v2169
		end
	end
	local v2173 = p1831.look.gear
	local v2174
	if v2173 == nil then
		v2174 = false
	else
		v2174 = table.find(v2173, "bracers") ~= nil
	end
	if v2174 then
		for _, v2175 in v1843 do
			local v2176 = v1837.X + 0.12
			local v2177 = v1837.Z + 0.12
			local v2178 = Vector3.new(v2176, 0.5, v2177)
			local v2179 = p1831.accent
			local v2180 = CFrame.new(0, -v1837.Y / 2 + 0.75, 0)
			local v2181 = v_u_27(p1831, "Bracer", v2178, v2179, v1840)
			local v2182 = v2175.CFrame
			local v2183 = p1831.s
			v2181.CFrame = v2182 * (v2180.Rotation + v2180.Position * v2183)
			local v2184 = Instance.new("WeldConstraint")
			v2184.Part0 = v2175
			v2184.Part1 = v2181
			v2184.Parent = v2181
		end
	end
	local v2185 = p1831.look.gear
	local v2186
	if v2185 == nil then
		v2186 = false
	else
		v2186 = table.find(v2185, "shield") ~= nil
	end
	if v2186 and p1832.leftArmPart then
		local v2187 = {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.Metal
		}
		local v2188 = p1832.leftArmPart
		local v2189 = p1831.accent
		local v2190 = CFrame.new(-(v1837.X / 2 + 0.15), -0.2, 0)
		local v2191 = v_u_27(p1831, "Shield", Vector3.new(0.22, 2.2, 2.2), v2189, v2187)
		local v2192 = v2188.CFrame
		local v2193 = p1831.s
		v2191.CFrame = v2192 * (v2190.Rotation + v2190.Position * v2193)
		local v2194 = Instance.new("WeldConstraint")
		v2194.Part0 = v2188
		v2194.Part1 = v2191
		v2194.Parent = v2191
		local v2195 = p1832.leftArmPart
		local v2196 = p1831.glow
		local v2197 = CFrame.new(-(v1837.X / 2 + 0.2), -0.2, 0)
		local v2198 = v_u_27(p1831, "Boss", Vector3.new(0.26, 0.7, 0.7), v2196, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v2199 = v2195.CFrame
		local v2200 = p1831.s
		v2198.CFrame = v2199 * (v2197.Rotation + v2197.Position * v2200)
		local v2201 = Instance.new("WeldConstraint")
		v2201.Part0 = v2195
		v2201.Part1 = v2198
		v2201.Parent = v2198
	end
	local v2202 = p1831.look.gear
	local v2203
	if v2202 == nil then
		v2203 = false
	else
		v2203 = table.find(v2202, "scarf") ~= nil
	end
	if v2203 then
		local v2204 = v1836.X * 0.8
		local v2205 = v1836.Z + 0.3
		local v2206 = Vector3.new(v2204, 0.45, v2205)
		local v2207 = p1831.trim
		local v2208 = CFrame.new(0, v1838 / 2 - 0.05, 0)
		local v2209 = v_u_27(p1831, "Scarf", v2206, v2207, v1839)
		local v2210 = v1834.CFrame
		local v2211 = p1831.s
		v2209.CFrame = v2210 * (v2208.Rotation + v2208.Position * v2211)
		local v2212 = Instance.new("WeldConstraint")
		v2212.Part0 = v1834
		v2212.Part1 = v2209
		v2212.Parent = v2209
		v_u_57(p1831, v1834, "ScarfTail", Vector3.new(0.5, 0.12, 2), p1831.trim, CFrame.new(0.35, v1838 / 2 - 0.1, v1836.Z / 2 + 0.1) * CFrame.Angles(0.5, 0.2, 0), CFrame.new(0, 0, -1), Vector3.new(1, 0, 0), 0.3, 7, -0.55, v1839)
	end
	local v2213 = p1831.look.gear
	local v2214
	if v2213 == nil then
		v2214 = false
	else
		v2214 = table.find(v2213, "cape") ~= nil
	end
	if v2214 then
		local v2215 = v1838 + v1835.leg.Y * 0.8
		local v2216 = v_u_57
		local v2217 = v1836.X + 0.2
		v2216(p1831, v1834, "Cape", Vector3.new(v2217, v2215, 0.14), p1831.trim, CFrame.new(0, v1838 / 2 - 0.1, v1836.Z / 2 + 0.12) * CFrame.Angles(0.12, 0, 0), CFrame.new(0, v2215 / 2, 0), Vector3.new(1, 0, 0), 0.08, 3, -0.45, v1839)
	end
	local v2218 = p1831.look.gear
	local v2219
	if v2218 == nil then
		v2219 = false
	else
		v2219 = table.find(v2218, "wings") ~= nil
	end
	if v2219 then
		for _, v2220 in { -1, 1 } do
			local v2221 = v_u_57(p1831, v1834, "Wing", Vector3.new(2.6, 1.2, 0.18), p1831.trim, CFrame.new(v2220 * 0.35, v1838 / 2 - 0.3, v1836.Z / 2 + 0.12) * CFrame.Angles(0, -v2220 * 0.35, v2220 * 0.35), CFrame.new(-v2220 * 1.3, -0.1, 0), Vector3.new(0, 0, v2220), 0.35, 8, 0)
			local v2222 = p1831.trim
			local v2223, v2224 = CFrame.new(v2220 * 0.4, -0.75, 0)
			local v2225 = v_u_27(p1831, "Feathers", Vector3.new(1.5, 0.8, 0.16), v2222, v2224)
			local v2226 = v2221.CFrame
			local v2227 = p1831.s
			v2225.CFrame = v2226 * (v2223.Rotation + v2223.Position * v2227)
			local v2228 = Instance.new("WeldConstraint")
			v2228.Part0 = v2221
			v2228.Part1 = v2225
			v2228.Parent = v2225
			local v2229 = p1831.glow
			local v2230 = CFrame.new(0, -0.62, 0)
			local v2231 = v_u_27(p1831, "WingEdge", Vector3.new(2.6, 0.12, 0.2), v2229, v1841)
			local v2232 = v2221.CFrame
			local v2233 = p1831.s
			v2231.CFrame = v2232 * (v2230.Rotation + v2230.Position * v2233)
			local v2234 = Instance.new("WeldConstraint")
			v2234.Part0 = v2221
			v2234.Part1 = v2231
			v2234.Parent = v2231
		end
	end
	local v2235 = p1831.look.gear
	local v2236
	if v2235 == nil then
		v2236 = false
	else
		v2236 = table.find(v2235, "tails") ~= nil
	end
	if v2236 then
		for v2237 = 1, 5 do
			local v2238 = v_u_57(p1831, v1834, "Tail", Vector3.new(0.85, 0.85, 3.1), p1831.skin, CFrame.new(0, -v1838 / 2 + 0.35, v1836.Z / 2 + 0.1) * CFrame.Angles(0, 0, (v2237 - 3) * 0.45) * CFrame.Angles(-1.1, 0, 0), CFrame.new(0, 0, -1.55), Vector3.new(0, 1, 0), 0.25, 2.5, 0.15)
			local v2239 = p1831.glow
			local v2240 = CFrame.new(0, 0, 1.6)
			local v2241 = v_u_27(p1831, "TailTip", Vector3.new(1.15, 1.15, 1.15), v2239, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v2242 = v2238.CFrame
			local v2243 = p1831.s
			v2241.CFrame = v2242 * (v2240.Rotation + v2240.Position * v2243)
			local v2244 = Instance.new("WeldConstraint")
			v2244.Part0 = v2238
			v2244.Part1 = v2241
			v2244.Parent = v2241
		end
	end
	local v2245 = p1831.look.gear
	local v2246
	if v2245 == nil then
		v2246 = false
	else
		v2246 = table.find(v2245, "banner") ~= nil
	end
	if v2246 then
		local v2247 = v_u_7
		local v2248, v2249 = CFrame.new(0.3, v1838 / 2 + 1.4, v1836.Z / 2 + 0.3)
		local v2250 = v_u_27(p1831, "BannerPole", Vector3.new(0.18, 5.5, 0.18), v2247, v2249)
		local v2251 = v1834.CFrame
		local v2252 = p1831.s
		v2250.CFrame = v2251 * (v2248.Rotation + v2248.Position * v2252)
		local v2253 = Instance.new("WeldConstraint")
		v2253.Part0 = v1834
		v2253.Part1 = v2250
		v2253.Parent = v2250
		local v2254 = v_u_57(p1831, v2250, "Banner", Vector3.new(1.6, 2.6, 0.1), p1831.shirt, CFrame.new(0.05, 1.3, 0), CFrame.new(-0.8, 0, 0), Vector3.new(0, 1, 0), 0.18, 4, 0.3, v1839)
		local v2255 = p1831.accent
		local v2256 = CFrame.Angles(0, 0, 0.7853981633974483)
		local v2257 = v_u_27(p1831, "BannerMark", Vector3.new(0.75, 0.75, 0.14), v2255, v1841)
		local v2258 = v2254.CFrame
		local v2259 = p1831.s
		v2257.CFrame = v2258 * (v2256.Rotation + v2256.Position * v2259)
		local v2260 = Instance.new("WeldConstraint")
		v2260.Part0 = v2254
		v2260.Part1 = v2257
		v2260.Parent = v2257
	end
	local v2261 = p1831.look.gear
	local v2262
	if v2261 == nil then
		v2262 = false
	else
		v2262 = table.find(v2261, "orbs") ~= nil
	end
	if v2262 then
		for v2263 = 1, 3 do
			local v2264 = v_u_27(p1831, "Orb", Vector3.new(0.9, 0.9, 0.9), p1831.glow, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			v_u_1830(p1831, v2264, v1836.X / 2 + 1.8, 0.3, 1.8, (v2263 - 1) * 3.141592653589793 * 2 / 3)
			v_u_68(p1831, v2264, Vector3.new(0, 0.35, 0), Vector3.new(0, -0.35, 0), 0.35, 0.2)
		end
	end
	local v2265 = p1831.look.gear
	local v2266
	if v2265 == nil then
		v2266 = false
	else
		v2266 = table.find(v2265, "shards") ~= nil
	end
	if v2266 then
		local v2267 = p1831.look.aura
		local v2268 = v2267 == "sand" and true or v2267 == "gold"
		local v2269 = p1833 and 4 or 2
		for v2270 = 1, v2269 do
			local v2271 = v_u_27
			local v2272 = "Shard"
			local v2273 = Vector3.new(0.55, 1, 0.55)
			local v2274
			if v2268 then
				v2274 = p1831.accent
			else
				v2274 = p1831.glow
			end
			v_u_1830(p1831, v2271(p1831, v2272, v2273, v2274, v2268 and {
				["material"] = Enum.Material.Sandstone
			} or {
				["neon"] = true
			}), v1836.X / 2 + 1.4, v2270 % 2 * 0.6 + 0.2, 1.2, (v2270 - 1) * 3.141592653589793 * 2 / v2269)
		end
	end
	local v2275 = p1831.look.gear
	local v2276
	if v2275 == nil then
		v2276 = false
	else
		v2276 = table.find(v2275, "apron") ~= nil
	end
	if v2276 then
		local v2277 = v1838 * 0.85 + v1835.leg.Y * 0.55
		local v2278 = v1836.X * 0.82
		local v2279 = Vector3.new(v2278, v2277, 0.12)
		local v2280 = p1831.trim
		local v2281 = CFrame.new(0, v1838 / 2 - 0.25 - v2277 / 2, v1842 - 0.1)
		local v2282 = v_u_27(p1831, "Apron", v2279, v2280, v1839)
		local v2283 = v1834.CFrame
		local v2284 = p1831.s
		v2282.CFrame = v2283 * (v2281.Rotation + v2281.Position * v2284)
		local v2285 = Instance.new("WeldConstraint")
		v2285.Part0 = v1834
		v2285.Part1 = v2282
		v2285.Parent = v2282
		local v2286 = v1836.X * 0.4
		local v2287 = Vector3.new(v2286, 0.45, 0.06)
		local v2288 = p1831.trim:Lerp(v_u_7, 0.3)
		local v2289 = CFrame.new(0, -0.1, -0.08)
		local v2290 = v_u_27(p1831, "Pocket", v2287, v2288, v1839)
		local v2291 = v2282.CFrame
		local v2292 = p1831.s
		v2290.CFrame = v2291 * (v2289.Rotation + v2289.Position * v2292)
		local v2293 = Instance.new("WeldConstraint")
		v2293.Part0 = v2282
		v2293.Part1 = v2290
		v2293.Parent = v2290
		for _, v2294 in { -1, 1 } do
			local v2295 = v1836.Z + 0.2
			local v2296 = Vector3.new(0.18, 0.12, v2295)
			local v2297 = p1831.trim:Lerp(v_u_7, 0.3)
			local v2298, v2299 = CFrame.new(v2294 * v1836.X * 0.3, v1838 / 2 + 0.02, 0)
			local v2300 = v_u_27(p1831, "Strap", v2296, v2297, v2299)
			local v2301 = v1834.CFrame
			local v2302 = p1831.s
			v2300.CFrame = v2301 * (v2298.Rotation + v2298.Position * v2302)
			local v2303 = Instance.new("WeldConstraint")
			v2303.Part0 = v1834
			v2303.Part1 = v2300
			v2303.Parent = v2300
		end
	end
	local v2304 = p1831.look.gear
	local v2305
	if v2304 == nil then
		v2305 = false
	else
		v2305 = table.find(v2304, "coral") ~= nil
	end
	if v2305 then
		for _, v2306 in { -1, 1 } do
			v_u_114(p1831, v1834, "Coral", CFrame.new(v2306 * (v1836.X / 2 - 0.2), v1838 / 2 - 0.1, 0.15) * CFrame.Angles(0.15, 0, -v2306 * 0.35), 1.1, 0.26, p1831.accent, {
				{
					0.4,
					-v2306 * 0.8,
					0,
					0.6
				},
				{
					0.65,
					v2306 * 0.7,
					0.3,
					0.5
				}
			})
		end
		v_u_114(p1831, v1834, "Coral", CFrame.new(-0.3, 0.1, v1836.Z / 2 + 0.05) * CFrame.Angles(0.7, 0, 0.2), 1.3, 0.28, p1831.accent, {
			{
				0.35,
				0.8,
				0,
				0.6
			},
			{
				0.6,
				-0.7,
				0.2,
				0.55
			}
		})
	end
	local v2307 = p1831.look.gear
	local v2308
	if v2307 == nil then
		v2308 = false
	else
		v2308 = table.find(v2307, "quiver") ~= nil
	end
	if v2308 then
		local v2309 = v1838 * 1.3
		local v2310 = v1836.Z + 0.1
		local v2311 = Vector3.new(0.22, v2309, v2310)
		local v2312 = p1831.trim
		local v2313 = CFrame.Angles(0, 0, -0.72)
		local v2314 = v_u_27(p1831, "QuiverStrap", v2311, v2312, v1839)
		local v2315 = v1834.CFrame
		local v2316 = p1831.s
		v2314.CFrame = v2315 * (v2313.Rotation + v2313.Position * v2316)
		local v2317 = Instance.new("WeldConstraint")
		v2317.Part0 = v1834
		v2317.Part1 = v2314
		v2317.Parent = v2314
		local v2318 = p1831.trim
		local v2319 = CFrame.new(0.25, 0.25, v1836.Z / 2 + 0.32) * CFrame.Angles(0, 0, -0.4)
		local v2320 = v_u_27(p1831, "Quiver", Vector3.new(0.55, 1.7, 0.55), v2318, v1839)
		local v2321 = v1834.CFrame
		local v2322 = p1831.s
		v2320.CFrame = v2321 * (v2319.Rotation + v2319.Position * v2322)
		local v2323 = Instance.new("WeldConstraint")
		v2323.Part0 = v1834
		v2323.Part1 = v2320
		v2323.Parent = v2320
		local v2324 = p1831.accent
		local v2325 = CFrame.new(0, 0.6, 0)
		local v2326 = v_u_27(p1831, "QuiverBand", Vector3.new(0.6, 0.12, 0.6), v2324, v1840)
		local v2327 = v2320.CFrame
		local v2328 = p1831.s
		v2326.CFrame = v2327 * (v2325.Rotation + v2325.Position * v2328)
		local v2329 = Instance.new("WeldConstraint")
		v2329.Part0 = v2320
		v2329.Part1 = v2326
		v2329.Parent = v2326
		for v2330, v2331 in { -0.13, 0.13, 0 } do
			local v2332 = (v2330 - 2) * 0.12
			local v2333 = v_u_9
			local v2334, v2335 = CFrame.new(v2331, 1.1, v2332)
			local v2336 = v_u_27(p1831, "Arrow", Vector3.new(0.08, 0.7, 0.08), v2333, v2335)
			local v2337 = v2320.CFrame
			local v2338 = p1831.s
			v2336.CFrame = v2337 * (v2334.Rotation + v2334.Position * v2338)
			local v2339 = Instance.new("WeldConstraint")
			v2339.Part0 = v2320
			v2339.Part1 = v2336
			v2339.Parent = v2336
			local v2340 = p1831.glow
			local v2341 = CFrame.new(v2331, 1.45, v2332)
			local v2342 = v_u_27(p1831, "Fletch", Vector3.new(0.2, 0.3, 0.05), v2340, v1841)
			local v2343 = v2320.CFrame
			local v2344 = p1831.s
			v2342.CFrame = v2343 * (v2341.Rotation + v2341.Position * v2344)
			local v2345 = Instance.new("WeldConstraint")
			v2345.Part0 = v2320
			v2345.Part1 = v2342
			v2345.Parent = v2342
		end
	end
	local v2346 = p1831.look.gear
	local v2347
	if v2346 == nil then
		v2347 = false
	else
		v2347 = table.find(v2346, "cogs") ~= nil
	end
	if v2347 then
		v_u_143(p1831, v1834, CFrame.new(0, 0.2, v1836.Z / 2 + 0.15) * CFrame.Angles(0, 1.5707963267948966, 0), v1836.X * 0.75, true)
		v_u_143(p1831, v1834, CFrame.new(-v1836.X * 0.22, -0.3, v1842 - 0.12) * CFrame.Angles(0, 1.5707963267948966, 0), 0.75, true)
		if p1831.look.build == "golem" then
			for _, v2348 in v1843 do
				local v2349 = v2348 == p1832.rightArmPart and 1 or -1
				v_u_143(p1831, v2348, CFrame.new(v2349 * (v1837.X / 2 + 0.12), v1837.Y / 2 - 0.95, 0), 0.95, false)
			end
		end
	end
	local v2350 = p1831.look.gear
	local v2351
	if v2350 == nil then
		v2351 = false
	else
		v2351 = table.find(v2350, "drums") ~= nil
	end
	if v2351 then
		local v2352 = v_u_57(p1831, v1834, "DrumRing", Vector3.new(0.4, 0.4, 0.4), p1831.accent, CFrame.new(0, v1838 / 2 + 0.5, v1836.Z / 2 + 0.7), CFrame.identity, Vector3.new(0, 0, 1), 0.1, 1.6, 0, {
			["hidden"] = true
		})
		local v2353 = v1836.X * 0.85
		for v2354 = 0, 15 do
			local v2355 = v2354 * 3.141592653589793 / 8
			local v2356 = v2353 * 0.42
			local v2357 = Vector3.new(0.26, v2356, 0.26)
			local v2358 = p1831.accent
			local v2359 = CFrame.new(math.cos(v2355) * v2353, math.sin(v2355) * v2353, 0) * CFrame.Angles(0, 0, v2355)
			local v2360 = v_u_27(p1831, "Ring", v2357, v2358, v1840)
			local v2361 = v2352.CFrame
			local v2362 = p1831.s
			v2360.CFrame = v2361 * (v2359.Rotation + v2359.Position * v2362)
			local v2363 = Instance.new("WeldConstraint")
			v2363.Part0 = v2352
			v2363.Part1 = v2360
			v2363.Parent = v2360
		end
		for v2364 = 0, 7 do
			local v2365 = v2364 * 3.141592653589793 / 4 + 0.39269908169872414
			local v2366 = CFrame.new(math.cos(v2365) * v2353, math.sin(v2365) * v2353, -0.05)
			local v2367 = p1831.trim
			local v2368 = v2366 * CFrame.Angles(0, 1.5707963267948966, 0)
			local v2369 = v_u_27(p1831, "Drum", Vector3.new(0.6, 1, 1), v2367, {
				["shape"] = Enum.PartType.Cylinder
			})
			local v2370 = v2352.CFrame
			local v2371 = p1831.s
			v2369.CFrame = v2370 * (v2368.Rotation + v2368.Position * v2371)
			local v2372 = Instance.new("WeldConstraint")
			v2372.Part0 = v2352
			v2372.Part1 = v2369
			v2372.Parent = v2369
			local v2373 = v_u_10
			local v2374 = CFrame.identity
			local v2375 = v_u_27(p1831, "DrumSkin", Vector3.new(0.64, 0.82, 0.82), v2373, {
				["shape"] = Enum.PartType.Cylinder
			})
			local v2376 = v2369.CFrame
			local v2377 = p1831.s
			v2375.CFrame = v2376 * (v2374.Rotation + v2374.Position * v2377)
			local v2378 = Instance.new("WeldConstraint")
			v2378.Part0 = v2369
			v2378.Part1 = v2375
			v2378.Parent = v2375
			local v2379 = p1831.glow
			local v2380 = CFrame.identity
			local v2381 = v_u_27(p1831, "DrumMark", Vector3.new(0.68, 0.34, 0.34), v2379, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Cylinder
			})
			local v2382 = v2369.CFrame
			local v2383 = p1831.s
			v2381.CFrame = v2382 * (v2380.Rotation + v2380.Position * v2383)
			local v2384 = Instance.new("WeldConstraint")
			v2384.Part0 = v2369
			v2384.Part1 = v2381
			v2384.Parent = v2381
		end
	end
	local v2385 = p1831.look.gear
	local v2386
	if v2385 == nil then
		v2386 = false
	else
		v2386 = table.find(v2385, "halo") ~= nil
	end
	if v2386 then
		local v2387 = p1832.head
		local v2388 = v1835.head
		local v2389 = v2388 / 2 + (p1831.look.hat == "none" and 0.6 or 1.15)
		local v2390 = v2388 * 0.55 / 1.6 + 0.25
		for v2391 = 0, 7 do
			local v2392 = v2391 * 3.141592653589793 / 4
			local v2393 = v2390 * 2 * 0.3826834323650898 + 0.1
			local v2394 = Vector3.new(0.16, 0.12, v2393)
			local v2395 = p1831.glow
			local v2396 = CFrame.new(math.cos(v2392) * v2390, v2389, math.sin(v2392) * v2390) * CFrame.Angles(0, -v2392, 0)
			local v2397 = v_u_27(p1831, "Halo", v2394, v2395, v1841)
			local v2398 = v2387.CFrame
			local v2399 = p1831.s
			v2397.CFrame = v2398 * (v2396.Rotation + v2396.Position * v2399)
			local v2400 = Instance.new("WeldConstraint")
			v2400.Part0 = v2387
			v2400.Part1 = v2397
			v2400.Parent = v2397
		end
	end
	local v2401 = p1831.look.gear
	local v2402
	if v2401 == nil then
		v2402 = false
	else
		v2402 = table.find(v2401, "runes") ~= nil
	end
	if v2402 then
		local v2403 = p1833 and 5 or 3
		for v2404 = 1, v2403 do
			local v2405 = v_u_27(p1831, "Rune", Vector3.new(0.85, 0.85, 0.1), p1831.glow, v1841)
			v_u_1830(p1831, v2405, v1836.X / 2 + 1.2, v2404 % 3 * 0.55 + -0.2, 1.4, (v2404 - 1) * 3.141592653589793 * 2 / v2403)
			local v2406 = v_u_7
			local v2407, v2408 = CFrame.Angles(0, 0, 0.7853981633974483)
			local v2409 = v_u_27(p1831, "RuneMark", Vector3.new(0.55, 0.55, 0.14), v2406, v2408)
			local v2410 = v2405.CFrame
			local v2411 = p1831.s
			v2409.CFrame = v2410 * (v2407.Rotation + v2407.Position * v2411)
			local v2412 = Instance.new("WeldConstraint")
			v2412.Part0 = v2405
			v2412.Part1 = v2409
			v2412.Parent = v2409
			local v2413 = p1831.glow
			local v2414 = CFrame.identity
			local v2415 = v_u_27(p1831, "RuneMark", Vector3.new(0.12, 0.6, 0.18), v2413, v1841)
			local v2416 = v2405.CFrame
			local v2417 = p1831.s
			v2415.CFrame = v2416 * (v2414.Rotation + v2414.Position * v2417)
			local v2418 = Instance.new("WeldConstraint")
			v2418.Part0 = v2405
			v2418.Part1 = v2415
			v2418.Parent = v2415
		end
	end
end
local function v_u_2541(p2420, p2421, p2422) -- name: biped
	-- upvalues: (copy) v_u_15, (copy) v_u_17, (copy) v_u_40, (copy) v_u_27, (copy) v_u_7
	local v2423 = p2420.look
	local v2424 = v_u_15[v2423.build or "normal"]
	local v2425 = v2424.torso
	local v2426 = v2425.Y
	local v2427 = v2423.body or "plastic"
	local v2428 = v2427 == "plastic" and true or v2427 == "cloth"
	local v2429 = v_u_17[v2427] == true
	local v2430 = {
		["material"] = p2420.mat,
		["studs"] = p2420.mat == Enum.Material.Plastic
	}
	local v2431 = not v2429 and v2427 ~= "ghost" and {
		["studs"] = true
	} or v2430
	local v2432, v2433 = v_u_40(p2420, p2421, "Torso", v2425, p2420.shirt, CFrame.identity, CFrame.identity, v2430)
	local v2434, v2435 = v_u_40(p2420, v2432, "Head", Vector3.new(1, 1, 1) * v2424.head, p2420.skin, CFrame.new(0, v2426 / 2, v2424.neckZ), CFrame.new(0, -v2424.head / 2 + v2424.sink, 0), v2431)
	local v2436 = CFrame.new(0, v2424.arm.Y / 2 - 0.4, 0)
	local v2437, v2438 = v_u_40(p2420, v2432, "RightArm", v2424.arm, p2420.arm, CFrame.new(v2424.armX, v2426 / 2 - 0.4, 0), v2436, v2430)
	local v2439, v2440 = v_u_40(p2420, v2432, "LeftArm", v2424.arm, p2420.arm, CFrame.new(-v2424.armX, v2426 / 2 - 0.4, 0), v2436, v2430)
	local v2441, v2442, v2443
	if p2422 then
		local v2444 = {}
		local v2445
		if v2428 then
			v2445 = Enum.Material.Fabric
		else
			v2445 = p2420.mat
		end
		v2444.material = v2445
		local v2446 = v2425.X + 0.2
		local v2447 = v2425.Z + 0.25
		local v2448 = Vector3.new(v2446, 0.9, v2447)
		local v2449 = p2420.shirt
		local v2450 = CFrame.new(0, -v2426 / 2 - 0.35, 0)
		local v2451 = v_u_27(p2420, "Skirt", v2448, v2449, v2444)
		local v2452 = v2432.CFrame
		local v2453 = p2420.s
		v2451.CFrame = v2452 * (v2450.Rotation + v2450.Position * v2453)
		local v2454 = Instance.new("WeldConstraint")
		v2454.Part0 = v2432
		v2454.Part1 = v2451
		v2454.Parent = v2451
		local v2455 = v2424.leg.X + 0.15
		local v2456 = v2424.leg.Z + 0.15
		local v2457 = Vector3.new(v2455, 1.5, v2456)
		local v2458 = CFrame.new(0, 0.75, 0)
		local v2459
		v2459, v2441 = v_u_40(p2420, v2432, "RightLeg", v2457, p2420.pants, CFrame.new(v2424.legX, -v2426 / 2 - 0.6, 0), v2458, v2444)
		local v2460
		v2460, v2442 = v_u_40(p2420, v2432, "LeftLeg", v2457, p2420.pants, CFrame.new(-v2424.legX, -v2426 / 2 - 0.6, 0), v2458, v2444)
		for _, v2461 in { v2437, v2439 } do
			local v2462 = v2424.arm.X + 0.35
			local v2463 = v2424.arm.Y * 0.5
			local v2464 = v2424.arm.Z + 0.35
			local v2465 = Vector3.new(v2462, v2463, v2464)
			local v2466 = p2420.shirt
			local v2467 = CFrame.new(0, v2424.arm.Y / 4, 0)
			local v2468 = v_u_27(p2420, "Sleeve", v2465, v2466, v2444)
			local v2469 = v2461.CFrame
			local v2470 = p2420.s
			v2468.CFrame = v2469 * (v2467.Rotation + v2467.Position * v2470)
			local v2471 = Instance.new("WeldConstraint")
			v2471.Part0 = v2461
			v2471.Part1 = v2468
			v2471.Parent = v2468
		end
		if v2427 == "cloud" then
			local v2472 = {
				["shape"] = Enum.PartType.Ball,
				["material"] = p2420.mat
			}
			for _, v2473 in { -1, 1 } do
				local v2474 = p2420.trim
				local v2475 = CFrame.new(v2473 * 0.85, -0.65, 0.1)
				local v2476 = v_u_27(p2420, "Puff", Vector3.new(1.3, 1.3, 1.3), v2474, v2472)
				local v2477 = v2432.CFrame
				local v2478 = p2420.s
				v2476.CFrame = v2477 * (v2475.Rotation + v2475.Position * v2478)
				local v2479 = Instance.new("WeldConstraint")
				v2479.Part0 = v2432
				v2479.Part1 = v2476
				v2479.Parent = v2476
			end
			local v2480 = p2420.glow
			local v2481 = CFrame.new(0.1, 0.3, -v2425.Z / 2 - 0.03) * CFrame.Angles(0, 0, -0.5)
			local v2482 = v_u_27(p2420, "Bolt", Vector3.new(0.18, 0.8, 0.06), v2480, {
				["neon"] = true
			})
			local v2483 = v2432.CFrame
			local v2484 = p2420.s
			v2482.CFrame = v2483 * (v2481.Rotation + v2481.Position * v2484)
			local v2485 = Instance.new("WeldConstraint")
			v2485.Part0 = v2432
			v2485.Part1 = v2482
			v2485.Parent = v2482
			local v2486 = p2420.glow
			local v2487 = CFrame.new(-0.05, -0.25, -v2425.Z / 2 - 0.03) * CFrame.Angles(0, 0, 0.5)
			local v2488 = v_u_27(p2420, "Bolt", Vector3.new(0.18, 0.8, 0.06), v2486, {
				["neon"] = true
			})
			local v2489 = v2432.CFrame
			local v2490 = p2420.s
			v2488.CFrame = v2489 * (v2487.Rotation + v2487.Position * v2490)
			local v2491 = Instance.new("WeldConstraint")
			v2491.Part0 = v2432
			v2491.Part1 = v2488
			v2491.Parent = v2488
		end
		v2443 = v2426 / 2 + 0.6 + 1.5 + 0.8
	else
		local v2492 = CFrame.new(0, v2424.leg.Y / 2, 0)
		local v2493
		v2493, v2441 = v_u_40(p2420, v2432, "RightLeg", v2424.leg, p2420.pants, CFrame.new(v2424.legX, -v2426 / 2, 0), v2492, v2430)
		local v2494
		v2494, v2442 = v_u_40(p2420, v2432, "LeftLeg", v2424.leg, p2420.pants, CFrame.new(-v2424.legX, -v2426 / 2, 0), v2492, v2430)
		if v2428 then
			for _, v2495 in { v2493, v2494 } do
				local v2496 = v2424.leg.X + 0.06
				local v2497 = v2424.leg.Z + 0.2
				local v2498 = Vector3.new(v2496, 0.35, v2497)
				local v2499 = p2420.pants:Lerp(v_u_7, 0.5)
				local v2500, v2501 = CFrame.new(0, -v2424.leg.Y / 2 + 0.17, -0.08)
				local v2502 = v_u_27(p2420, "Shoe", v2498, v2499, v2501)
				local v2503 = v2495.CFrame
				local v2504 = p2420.s
				v2502.CFrame = v2503 * (v2500.Rotation + v2500.Position * v2504)
				local v2505 = Instance.new("WeldConstraint")
				v2505.Part0 = v2495
				v2505.Part1 = v2502
				v2505.Parent = v2502
			end
			local v2506 = v2425.X + 0.06
			local v2507 = v2425.Z + 0.06
			local v2508 = Vector3.new(v2506, 0.32, v2507)
			local v2509 = p2420.accent
			local v2510, v2511 = CFrame.new(0, -v2426 / 2 + 0.2, 0)
			local v2512 = v_u_27(p2420, "Belt", v2508, v2509, v2511)
			local v2513 = v2432.CFrame
			local v2514 = p2420.s
			v2512.CFrame = v2513 * (v2510.Rotation + v2510.Position * v2514)
			local v2515 = Instance.new("WeldConstraint")
			v2515.Part0 = v2432
			v2515.Part1 = v2512
			v2515.Parent = v2512
		end
		v2443 = v2424.leg.Y + v2426 / 2
	end
	if v2428 and (not p2422 and v2423.arm == nil) then
		for _, v2516 in { v2437, v2439 } do
			local v2517 = v2424.arm.X + 0.06
			local v2518 = v2424.arm.Y * 0.45
			local v2519 = v2424.arm.Z + 0.06
			local v2520 = Vector3.new(v2517, v2518, v2519)
			local v2521 = p2420.shirt
			local v2522, v2523 = CFrame.new(0, v2424.arm.Y / 2 - v2424.arm.Y * 0.225, 0)
			local v2524 = v_u_27(p2420, "Sleeve", v2520, v2521, v2523)
			local v2525 = v2516.CFrame
			local v2526 = p2420.s
			v2524.CFrame = v2525 * (v2522.Rotation + v2522.Position * v2526)
			local v2527 = Instance.new("WeldConstraint")
			v2527.Part0 = v2516
			v2527.Part1 = v2524
			v2527.Parent = v2524
		end
	end
	if v2429 then
		for _, v2528 in { v2437, v2439 } do
			local v2529 = v2424.arm.X + 0.35
			local v2530 = v2424.arm.Z + 0.35
			local v2531 = Vector3.new(v2529, 0.85, v2530)
			local v2532 = p2420.accent
			local v2533 = CFrame.new(0, -v2424.arm.Y / 2 + 0.3, 0)
			local v2534 = v_u_27(p2420, "Fist", v2531, v2532, {
				["material"] = p2420.mat
			})
			local v2535 = v2528.CFrame
			local v2536 = p2420.s
			v2534.CFrame = v2535 * (v2533.Rotation + v2533.Position * v2536)
			local v2537 = Instance.new("WeldConstraint")
			v2537.Part0 = v2528
			v2537.Part1 = v2534
			v2537.Parent = v2534
		end
	end
	local v2538 = {
		["torso"] = nil,
		["head"] = nil,
		["rightArmPart"] = nil,
		["leftArmPart"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = nil,
		["trailTop"] = nil,
		["trailBottom"] = nil,
		["d"] = nil,
		["torso"] = v2432,
		["head"] = v2434,
		["rightArmPart"] = v2437,
		["leftArmPart"] = v2439,
		["waist"] = v2433,
		["neck"] = v2435,
		["rightArm"] = v2438,
		["leftArm"] = v2440,
		["rightLeg"] = v2441,
		["leftLeg"] = v2442,
		["lift"] = v2443
	}
	local v2539 = v2426 * 0.45
	v2538.trailTop = Vector3.new(0, v2539, 0)
	local v2540 = -v2426 / 2 - (p2422 and 1.6 or v2424.leg.Y * 0.6)
	v2538.trailBottom = Vector3.new(0, v2540, 0)
	v2538.d = v2424
	return v2538
end
local function v_u_2573(p2542, p2543, p2544) -- name: beastGear
	-- upvalues: (copy) v_u_27, (copy) v_u_143
	local v2545 = p2544.Z / 3.2
	local v2546 = p2542.look.gear
	local v2547
	if v2546 == nil then
		v2547 = false
	else
		v2547 = table.find(v2546, "stripes") ~= nil
	end
	if v2547 then
		for _, v2548 in {
			-0.95,
			-0.35,
			0.25,
			0.85
		} do
			local v2549 = p2544.X + 0.06
			local v2550 = p2544.Y * 0.7
			local v2551 = Vector3.new(v2549, v2550, 0.24)
			local v2552 = p2542.accent
			local v2553 = CFrame.new(0, p2544.Y * 0.16, v2548 * v2545) * CFrame.Angles(-0.25, 0, 0)
			local v2554 = v_u_27(p2542, "Stripe", v2551, v2552, {
				["material"] = p2542.mat
			})
			local v2555 = p2543.CFrame
			local v2556 = p2542.s
			v2554.CFrame = v2555 * (v2553.Rotation + v2553.Position * v2556)
			local v2557 = Instance.new("WeldConstraint")
			v2557.Part0 = p2543
			v2557.Part1 = v2554
			v2557.Parent = v2554
		end
	end
	local v2558 = p2542.look.gear
	local v2559
	if v2558 == nil then
		v2559 = false
	else
		v2559 = table.find(v2558, "spikes") ~= nil
	end
	if v2559 then
		for v2560, v2561 in { -0.9, 0, 0.9 } do
			local v2562 = 1 - v2560 * 0.12
			local v2563 = Vector3.new(0.3, v2562, 0.3)
			local v2564 = p2542.glow
			local v2565 = CFrame.new(0, p2544.Y / 2 + 0.2, v2561 * v2545) * CFrame.Angles(-0.35, 0.7853981633974483, 0)
			local v2566 = v_u_27(p2542, "Spike", v2563, v2564, {
				["neon"] = true
			})
			local v2567 = p2543.CFrame
			local v2568 = p2542.s
			v2566.CFrame = v2567 * (v2565.Rotation + v2565.Position * v2568)
			local v2569 = Instance.new("WeldConstraint")
			v2569.Part0 = p2543
			v2569.Part1 = v2566
			v2569.Parent = v2566
		end
	end
	local v2570 = p2542.look.gear
	local v2571
	if v2570 == nil then
		v2571 = false
	else
		v2571 = table.find(v2570, "cogs") ~= nil
	end
	if v2571 then
		for _, v2572 in { -1, 1 } do
			v_u_143(p2542, p2543, CFrame.new(v2572 * (p2544.X / 2 + 0.1), 0, 0.1), p2544.Y * 0.75, true)
		end
	end
end
local function v_u_2626(p2574, p2575) -- name: wolf
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_2573, (copy) v_u_15
	local v2576 = {
		["material"] = p2574.mat
	}
	local v2577, v2578 = v_u_40(p2574, p2575, "Torso", Vector3.new(1.8, 1.5, 3.2), p2574.shirt, CFrame.identity, CFrame.identity, v2576)
	local v2579, v2580 = v_u_40(p2574, v2577, "Head", Vector3.new(1.4, 1.3, 1.3), p2574.skin, CFrame.new(0, 0.55, -1.6), CFrame.new(0, 0, 0.55), v2576)
	local v2581 = p2574.skin
	local v2582 = CFrame.new(0, -0.25, -1)
	local v2583 = v_u_27(p2574, "Snout", Vector3.new(0.75, 0.6, 0.9), v2581, v2576)
	local v2584 = v2579.CFrame
	local v2585 = p2574.s
	v2583.CFrame = v2584 * (v2582.Rotation + v2582.Position * v2585)
	local v2586 = Instance.new("WeldConstraint")
	v2586.Part0 = v2579
	v2586.Part1 = v2583
	v2586.Parent = v2583
	local v2587 = v_u_7
	local v2588, v2589 = CFrame.new(0, -0.02, -1.45)
	local v2590 = v_u_27(p2574, "Nose", Vector3.new(0.3, 0.22, 0.15), v2587, v2589)
	local v2591 = v2579.CFrame
	local v2592 = p2574.s
	v2590.CFrame = v2591 * (v2588.Rotation + v2588.Position * v2592)
	local v2593 = Instance.new("WeldConstraint")
	v2593.Part0 = v2579
	v2593.Part1 = v2590
	v2593.Parent = v2590
	for _, v2594 in { -1, 1 } do
		local v2595 = p2574.skin
		local v2596 = CFrame.new(v2594 * 0.42, 0.85, 0.2) * CFrame.Angles(0, 0, -v2594 * 0.2)
		local v2597 = v_u_27(p2574, "Ear", Vector3.new(0.32, 0.6, 0.22), v2595, v2576)
		local v2598 = v2579.CFrame
		local v2599 = p2574.s
		v2597.CFrame = v2598 * (v2596.Rotation + v2596.Position * v2599)
		local v2600 = Instance.new("WeldConstraint")
		v2600.Part0 = v2579
		v2600.Part1 = v2597
		v2600.Parent = v2597
		local v2601 = p2574.eye
		local v2602 = CFrame.new(v2594 * 0.36, 0.18, -0.66) * CFrame.Angles(0, 0, v2594 * 0.28)
		local v2603 = v_u_27(p2574, "Eye", Vector3.new(0.3, 0.16, 0.08), v2601, {
			["neon"] = true
		})
		local v2604 = v2579.CFrame
		local v2605 = p2574.s
		v2603.CFrame = v2604 * (v2602.Rotation + v2602.Position * v2605)
		local v2606 = Instance.new("WeldConstraint")
		v2606.Part0 = v2579
		v2606.Part1 = v2603
		v2606.Parent = v2603
	end
	local v2607 = p2574.skin
	local v2608 = CFrame.new(0, 0.15, -1.25)
	local v2609 = v_u_27(p2574, "Mane", Vector3.new(2, 1.3, 1), v2607, v2576)
	local v2610 = v2577.CFrame
	local v2611 = p2574.s
	v2609.CFrame = v2610 * (v2608.Rotation + v2608.Position * v2611)
	local v2612 = Instance.new("WeldConstraint")
	v2612.Part0 = v2577
	v2612.Part1 = v2609
	v2612.Parent = v2609
	local v2613 = CFrame.new(0, 0.8, 0)
	local _, v2614 = v_u_40(p2574, v2577, "RightArm", Vector3.new(0.55, 1.6, 0.55), p2574.pants, CFrame.new(0.6, -0.4, -1.15), v2613, v2576)
	local _, v2615 = v_u_40(p2574, v2577, "LeftArm", Vector3.new(0.55, 1.6, 0.55), p2574.pants, CFrame.new(-0.6, -0.4, -1.15), v2613, v2576)
	local _, v2616 = v_u_40(p2574, v2577, "RightLeg", Vector3.new(0.55, 1.6, 0.55), p2574.pants, CFrame.new(0.6, -0.4, 1.15), v2613, v2576)
	local _, v2617 = v_u_40(p2574, v2577, "LeftLeg", Vector3.new(0.55, 1.6, 0.55), p2574.pants, CFrame.new(-0.6, -0.4, 1.15), v2613, v2576)
	local v2618, v2619 = v_u_40(p2574, v2577, "Tail", Vector3.new(0.45, 0.45, 1.6), p2574.shirt, CFrame.new(0, 0.45, 1.55) * CFrame.Angles(-0.55, 0, 0), CFrame.new(0, 0, -0.8), v2576)
	local v2620 = p2574.skin
	local v2621 = CFrame.new(0, 0, 0.95)
	local v2622 = v_u_27(p2574, "TailTip", Vector3.new(0.5, 0.5, 0.5), v2620, v2576)
	local v2623 = v2618.CFrame
	local v2624 = p2574.s
	v2622.CFrame = v2623 * (v2621.Rotation + v2621.Position * v2624)
	local v2625 = Instance.new("WeldConstraint")
	v2625.Part0 = v2618
	v2625.Part1 = v2622
	v2625.Parent = v2622
	v_u_2573(p2574, v2577, Vector3.new(1.8, 1.5, 3.2))
	return {
		["torso"] = nil,
		["head"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = 2,
		["trailTop"] = Vector3.new(0, 0.7, 0.4),
		["trailBottom"] = Vector3.new(0, -0.7, 0.4),
		["d"] = nil,
		["torso"] = v2577,
		["head"] = v2579,
		["waist"] = v2578,
		["neck"] = v2580,
		["rightArm"] = v2614,
		["leftArm"] = v2615,
		["rightLeg"] = v2616,
		["leftLeg"] = v2617,
		["tail"] = v2619,
		["d"] = v_u_15.normal
	}
end
local v_u_2627 = {
	["fox"] = {
		["torso"] = Vector3.new(1.5, 1.25, 2.9),
		["head"] = Vector3.new(1.3, 1.15, 1.2),
		["neck"] = Vector3.new(0, 0.5, -1.45),
		["snout"] = Vector3.new(0.6, 0.45, 0.85),
		["leg"] = Vector3.new(0.45, 1.5, 0.45),
		["legX"] = 0.5,
		["legZ"] = 1
	},
	["lion"] = {
		["torso"] = Vector3.new(2, 1.7, 3.1),
		["head"] = Vector3.new(1.6, 1.5, 1.4),
		["neck"] = Vector3.new(0, 0.6, -1.6),
		["snout"] = Vector3.new(0.85, 0.65, 0.6),
		["leg"] = Vector3.new(0.7, 1.6, 0.7),
		["legX"] = 0.65,
		["legZ"] = 1.1
	},
	["bear"] = {
		["torso"] = Vector3.new(2.4, 2, 3.2),
		["head"] = Vector3.new(1.6, 1.45, 1.4),
		["neck"] = Vector3.new(0, 0.4, -1.65),
		["snout"] = Vector3.new(0.8, 0.6, 0.6),
		["leg"] = Vector3.new(0.9, 1.3, 0.9),
		["legX"] = 0.75,
		["legZ"] = 1.1
	},
	["stag"] = {
		["torso"] = Vector3.new(1.5, 1.4, 2.9),
		["head"] = Vector3.new(1.05, 1.05, 1.15),
		["neck"] = Vector3.new(0, 1.75, -1.65),
		["snout"] = Vector3.new(0.6, 0.55, 0.8),
		["leg"] = Vector3.new(0.38, 2.3, 0.38),
		["legX"] = 0.5,
		["legZ"] = 1.05
	}
}
local function v_u_2795(p2628, p2629, p2630) -- name: beast
	-- upvalues: (copy) v_u_2627, (copy) v_u_40, (copy) v_u_27, (copy) v_u_13, (copy) v_u_7, (copy) v_u_114, (copy) v_u_2573, (copy) v_u_15
	local v2631 = v_u_2627[p2630] or v_u_2627.fox
	local v2632 = {
		["material"] = p2628.mat
	}
	local v2633 = {
		["neon"] = true
	}
	local v2634 = v2631.torso
	local v2635 = v2631.head
	local v2636, v2637 = v_u_40(p2628, p2629, "Torso", v2634, p2628.shirt, CFrame.identity, CFrame.identity, v2632)
	if p2630 == "stag" then
		local v2638 = p2628.shirt
		local v2639 = (Vector3.new(0, 1.25, -0.70000005)).Magnitude
		local v2640 = Vector3.new(0.65, 0.65, v2639)
		local v2641 = CFrame.lookAt(Vector3.new(0, 0.975, -1.4), Vector3.new(0, 1.6, -1.75))
		local v2642 = v_u_27(p2628, "Neck", v2640, v2638, v2632)
		local v2643 = v2636.CFrame
		local v2644 = p2628.s
		v2642.CFrame = v2643 * (v2641.Rotation + v2641.Position * v2644)
		local v2645 = Instance.new("WeldConstraint")
		v2645.Part0 = v2636
		v2645.Part1 = v2642
		v2645.Parent = v2642
	end
	local v2646, v2647 = v_u_40(p2628, v2636, "Head", v2635, p2628.skin, CFrame.new(v2631.neck), CFrame.new(0, 0, v2635.Z / 2 - 0.15), v2632)
	local v2648 = -v2635.Z / 2
	local v2649 = v2631.snout
	local v2650
	if p2630 == "fox" then
		v2650 = p2628.skin
	else
		v2650 = p2628.skin:Lerp(v_u_13, 0.25)
	end
	local v2651 = CFrame.new(0, -v2635.Y * 0.2, v2648 - v2649.Z / 2 + 0.1)
	local v2652 = v_u_27(p2628, "Snout", v2649, v2650, v2632)
	local v2653 = v2646.CFrame
	local v2654 = p2628.s
	v2652.CFrame = v2653 * (v2651.Rotation + v2651.Position * v2654)
	local v2655 = Instance.new("WeldConstraint")
	v2655.Part0 = v2646
	v2655.Part1 = v2652
	v2655.Parent = v2652
	local v2656 = v_u_7
	local v2657, v2658 = CFrame.new(0, -v2635.Y * 0.2 + v2649.Y / 2 - 0.08, v2648 - v2649.Z + 0.08)
	local v2659 = v_u_27(p2628, "Nose", Vector3.new(0.3, 0.2, 0.14), v2656, v2658)
	local v2660 = v2646.CFrame
	local v2661 = p2628.s
	v2659.CFrame = v2660 * (v2657.Rotation + v2657.Position * v2661)
	local v2662 = Instance.new("WeldConstraint")
	v2662.Part0 = v2646
	v2662.Part1 = v2659
	v2662.Parent = v2659
	for _, v2663 in { -1, 1 } do
		local v2664 = p2628.eye
		local v2665 = CFrame.new(v2663 * v2635.X * 0.27, v2635.Y * 0.16, v2648 - 0.03) * CFrame.Angles(0, 0, v2663 * 0.28)
		local v2666 = v_u_27(p2628, "Eye", Vector3.new(0.3, 0.16, 0.08), v2664, v2633)
		local v2667 = v2646.CFrame
		local v2668 = p2628.s
		v2666.CFrame = v2667 * (v2665.Rotation + v2665.Position * v2668)
		local v2669 = Instance.new("WeldConstraint")
		v2669.Part0 = v2646
		v2669.Part1 = v2666
		v2669.Parent = v2666
	end
	if p2630 == "fox" then
		for _, v2670 in { -1, 1 } do
			local v2671 = p2628.skin
			local v2672 = CFrame.new(v2670 * v2635.X * 0.3, v2635.Y / 2 + 0.05, 0.15) * CFrame.Angles(0, 0, 0.7853981633974483 - v2670 * 0.15)
			local v2673 = v_u_27(p2628, "Ear", Vector3.new(0.62, 0.62, 0.22), v2671, v2632)
			local v2674 = v2646.CFrame
			local v2675 = p2628.s
			v2673.CFrame = v2674 * (v2672.Rotation + v2672.Position * v2675)
			local v2676 = Instance.new("WeldConstraint")
			v2676.Part0 = v2646
			v2676.Part1 = v2673
			v2676.Parent = v2673
			local v2677 = p2628.accent
			local v2678, v2679 = CFrame.new(0.06, 0.06, -0.12)
			local v2680 = v_u_27(p2628, "EarInner", Vector3.new(0.34, 0.34, 0.05), v2677, v2679)
			local v2681 = v2673.CFrame
			local v2682 = p2628.s
			v2680.CFrame = v2681 * (v2678.Rotation + v2678.Position * v2682)
			local v2683 = Instance.new("WeldConstraint")
			v2683.Part0 = v2673
			v2683.Part1 = v2680
			v2683.Parent = v2680
		end
		local v2684 = v2634.X * 0.7
		local v2685 = v2634.Y * 0.75
		local v2686 = Vector3.new(v2684, v2685, 0.12)
		local v2687 = p2628.accent
		local v2688 = CFrame.new(0, -0.05, -v2634.Z / 2 - 0.03)
		local v2689 = v_u_27(p2628, "Chest", v2686, v2687, v2632)
		local v2690 = v2636.CFrame
		local v2691 = p2628.s
		v2689.CFrame = v2690 * (v2688.Rotation + v2688.Position * v2691)
		local v2692 = Instance.new("WeldConstraint")
		v2692.Part0 = v2636
		v2692.Part1 = v2689
		v2692.Parent = v2689
	elseif p2630 == "lion" then
		local v2693 = p2628.trim
		local v2694 = v2635.X + 1
		local v2695 = v2635.Y + 0.9
		local v2696 = Vector3.new(v2694, v2695, 0.9)
		local v2697 = CFrame.new(0, 0.05, 0.3)
		local v2698 = v_u_27(p2628, "Mane", v2696, v2693, v2632)
		local v2699 = v2646.CFrame
		local v2700 = p2628.s
		v2698.CFrame = v2699 * (v2697.Rotation + v2697.Position * v2700)
		local v2701 = Instance.new("WeldConstraint")
		v2701.Part0 = v2646
		v2701.Part1 = v2698
		v2701.Parent = v2698
		for _, v2702 in {
			{ 0, v2635.Y / 2 + 0.45 },
			{ v2635.X / 2 + 0.5, 0.15 },
			{ -(v2635.X / 2 + 0.5), 0.15 },
			{ 0, -v2635.Y / 2 - 0.42 }
		} do
			local v2703 = CFrame.new(v2702[1], v2702[2], 0.35) * CFrame.Angles(0, 0, 0.7853981633974483)
			local v2704 = v_u_27(p2628, "ManeTuft", Vector3.new(0.8, 0.8, 0.7), v2693, v2632)
			local v2705 = v2646.CFrame
			local v2706 = p2628.s
			v2704.CFrame = v2705 * (v2703.Rotation + v2703.Position * v2706)
			local v2707 = Instance.new("WeldConstraint")
			v2707.Part0 = v2646
			v2707.Part1 = v2704
			v2707.Parent = v2704
		end
		local v2708 = v2634.X * 0.8
		local v2709 = v2634.Y * 0.8
		local v2710 = Vector3.new(v2708, v2709, 0.5)
		local v2711 = CFrame.new(0, 0.15, -v2634.Z / 2 + 0.1)
		local v2712 = v_u_27(p2628, "ChestMane", v2710, v2693, v2632)
		local v2713 = v2636.CFrame
		local v2714 = p2628.s
		v2712.CFrame = v2713 * (v2711.Rotation + v2711.Position * v2714)
		local v2715 = Instance.new("WeldConstraint")
		v2715.Part0 = v2636
		v2715.Part1 = v2712
		v2715.Parent = v2712
		local v2716 = v2634.X * 0.85
		local v2717 = Vector3.new(v2716, 0.28, 0.6)
		local v2718 = p2628.glow
		local v2719 = CFrame.new(0, -0.25, -v2634.Z / 2 - 0.05)
		local v2720 = v_u_27(p2628, "Collar", v2717, v2718, v2633)
		local v2721 = v2636.CFrame
		local v2722 = p2628.s
		v2720.CFrame = v2721 * (v2719.Rotation + v2719.Position * v2722)
		local v2723 = Instance.new("WeldConstraint")
		v2723.Part0 = v2636
		v2723.Part1 = v2720
		v2723.Parent = v2720
		local v2724 = p2628.accent
		local v2725 = CFrame.new(0, -0.6, -v2634.Z / 2 - 0.25)
		local v2726 = v_u_27(p2628, "Bell", Vector3.new(0.55, 0.55, 0.55), v2724, {
			["material"] = Enum.Material.Metal,
			["shape"] = Enum.PartType.Ball
		})
		local v2727 = v2636.CFrame
		local v2728 = p2628.s
		v2726.CFrame = v2727 * (v2725.Rotation + v2725.Position * v2728)
		local v2729 = Instance.new("WeldConstraint")
		v2729.Part0 = v2636
		v2729.Part1 = v2726
		v2729.Parent = v2726
	elseif p2630 == "bear" then
		for _, v2730 in { -1, 1 } do
			local v2731 = p2628.skin
			local v2732 = CFrame.new(v2730 * v2635.X * 0.36, v2635.Y / 2 + 0.12, 0.15) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v2733 = v_u_27(p2628, "Ear", Vector3.new(0.3, 0.55, 0.55), v2731, {
				["shape"] = Enum.PartType.Cylinder,
				["material"] = p2628.mat
			})
			local v2734 = v2646.CFrame
			local v2735 = p2628.s
			v2733.CFrame = v2734 * (v2732.Rotation + v2732.Position * v2735)
			local v2736 = Instance.new("WeldConstraint")
			v2736.Part0 = v2646
			v2736.Part1 = v2733
			v2736.Parent = v2733
		end
		local v2737 = v2634.X * 0.8
		local v2738 = v2634.Z * 0.35
		local v2739 = Vector3.new(v2737, 0.5, v2738)
		local v2740 = p2628.shirt
		local v2741 = CFrame.new(0, v2634.Y / 2 + 0.15, -v2634.Z * 0.2)
		local v2742 = v_u_27(p2628, "Hump", v2739, v2740, v2632)
		local v2743 = v2636.CFrame
		local v2744 = p2628.s
		v2742.CFrame = v2743 * (v2741.Rotation + v2741.Position * v2744)
		local v2745 = Instance.new("WeldConstraint")
		v2745.Part0 = v2636
		v2745.Part1 = v2742
		v2745.Parent = v2742
	elseif p2630 == "stag" then
		for _, v2746 in { -1, 1 } do
			local v2747 = p2628.skin
			local v2748 = CFrame.new(v2746 * (v2635.X / 2 + 0.2), v2635.Y * 0.25, 0.15) * CFrame.Angles(0, 0, v2746 * 0.4)
			local v2749 = v_u_27(p2628, "Ear", Vector3.new(0.55, 0.25, 0.18), v2747, v2632)
			local v2750 = v2646.CFrame
			local v2751 = p2628.s
			v2749.CFrame = v2750 * (v2748.Rotation + v2748.Position * v2751)
			local v2752 = Instance.new("WeldConstraint")
			v2752.Part0 = v2646
			v2752.Part1 = v2749
			v2752.Parent = v2749
			v_u_114(p2628, v2646, "Antler", CFrame.new(v2746 * 0.28, v2635.Y / 2 - 0.05, 0.15) * CFrame.Angles(0.3, 0, -v2746 * 0.45), 1.3, 0.2, p2628.accent, {
				{
					0.3,
					-v2746 * 0.8,
					-0.5,
					0.65
				},
				{
					0.6,
					v2746 * 0.55,
					-0.3,
					0.6
				},
				{
					0.85,
					-v2746 * 0.6,
					0.2,
					0.5
				}
			})
		end
	end
	local v2753 = v2631.leg
	local v2754 = CFrame.new(0, v2753.Y / 2, 0)
	local v2755 = -v2634.Y / 2 + 0.35
	local v2756 = p2628.pants:Lerp(v_u_7, 0.45)
	local v2757 = {}
	for _, v2758 in {
		{
			["name"] = "RightArm",
			["x"] = nil,
			["z"] = nil,
			["x"] = v2631.legX,
			["z"] = -v2631.legZ
		},
		{
			["name"] = "LeftArm",
			["x"] = nil,
			["z"] = nil,
			["x"] = -v2631.legX,
			["z"] = -v2631.legZ
		},
		{
			["name"] = "RightLeg",
			["x"] = nil,
			["z"] = nil,
			["x"] = v2631.legX,
			["z"] = v2631.legZ
		},
		{
			["name"] = "LeftLeg",
			["x"] = nil,
			["z"] = nil,
			["x"] = -v2631.legX,
			["z"] = v2631.legZ
		}
	} do
		local v2759, v2760 = v_u_40(p2628, v2636, v2758.name, v2753, p2628.pants, CFrame.new(v2758.x, v2755, v2758.z), v2754, v2632)
		v2757[v2758.name] = v2760
		local v2761 = v2753.X + 0.1
		local v2762 = v2753.Z + 0.18
		local v2763 = Vector3.new(v2761, 0.3, v2762)
		local v2764 = CFrame.new(0, -v2753.Y / 2 + 0.15, -0.06)
		local v2765 = v_u_27(p2628, "Paw", v2763, v2756, v2632)
		local v2766 = v2759.CFrame
		local v2767 = p2628.s
		v2765.CFrame = v2766 * (v2764.Rotation + v2764.Position * v2767)
		local v2768 = Instance.new("WeldConstraint")
		v2768.Part0 = v2759
		v2768.Part1 = v2765
		v2768.Parent = v2765
	end
	local v2769
	if p2630 == "fox" then
		local v2770
		v2770, v2769 = v_u_40(p2628, v2636, "Tail", Vector3.new(0.85, 0.85, 2.2), p2628.shirt, CFrame.new(0, v2634.Y * 0.25, v2634.Z / 2 - 0.05) * CFrame.Angles(-0.65, 0, 0), CFrame.new(0, 0, -1.1), v2632)
		local v2771 = p2628.shirt
		local v2772 = CFrame.new(0, 0, 0.1)
		local v2773 = v_u_27(p2628, "TailFluff", Vector3.new(1.05, 1.05, 1), v2771, v2632)
		local v2774 = v2770.CFrame
		local v2775 = p2628.s
		v2773.CFrame = v2774 * (v2772.Rotation + v2772.Position * v2775)
		local v2776 = Instance.new("WeldConstraint")
		v2776.Part0 = v2770
		v2776.Part1 = v2773
		v2776.Parent = v2773
		local v2777 = p2628.accent
		local v2778 = CFrame.new(0, 0, 1.25)
		local v2779 = v_u_27(p2628, "TailTip", Vector3.new(0.95, 0.95, 0.7), v2777, v2632)
		local v2780 = v2770.CFrame
		local v2781 = p2628.s
		v2779.CFrame = v2780 * (v2778.Rotation + v2778.Position * v2781)
		local v2782 = Instance.new("WeldConstraint")
		v2782.Part0 = v2770
		v2782.Part1 = v2779
		v2782.Parent = v2779
	elseif p2630 == "lion" then
		local v2783
		v2783, v2769 = v_u_40(p2628, v2636, "Tail", Vector3.new(0.28, 0.28, 1.9), p2628.shirt, CFrame.new(0, v2634.Y * 0.3, v2634.Z / 2 - 0.05) * CFrame.Angles(-0.4, 0, 0), CFrame.new(0, 0, -0.95), v2632)
		local v2784 = p2628.trim
		local v2785 = CFrame.new(0, 0, 1.05)
		local v2786 = v_u_27(p2628, "TailTuft", Vector3.new(0.6, 0.6, 0.6), v2784, v2632)
		local v2787 = v2783.CFrame
		local v2788 = p2628.s
		v2786.CFrame = v2787 * (v2785.Rotation + v2785.Position * v2788)
		local v2789 = Instance.new("WeldConstraint")
		v2789.Part0 = v2783
		v2789.Part1 = v2786
		v2789.Parent = v2786
	elseif p2630 == "stag" then
		local v2790
		v2790, v2769 = v_u_40(p2628, v2636, "Tail", Vector3.new(0.45, 0.6, 0.3), p2628.accent, CFrame.new(0, v2634.Y * 0.3, v2634.Z / 2) * CFrame.Angles(-0.3, 0, 0), CFrame.new(0, 0, -0.1), v2632)
	else
		local v2791
		v2791, v2769 = v_u_40(p2628, v2636, "Tail", Vector3.new(0.5, 0.5, 0.5), p2628.shirt, CFrame.new(0, v2634.Y * 0.2, v2634.Z / 2), CFrame.new(0, 0, -0.15), v2632)
	end
	v_u_2573(p2628, v2636, v2634)
	local v2792 = {
		["torso"] = v2636,
		["head"] = v2646,
		["waist"] = v2637,
		["neck"] = v2647,
		["rightArm"] = v2757.RightArm,
		["leftArm"] = v2757.LeftArm,
		["rightLeg"] = v2757.RightLeg,
		["leftLeg"] = v2757.LeftLeg,
		["tail"] = v2769,
		["lift"] = v2634.Y / 2 - 0.35 + v2753.Y
	}
	local v2793 = v2634.Y * 0.45
	v2792.trailTop = Vector3.new(0, v2793, 0.4)
	local v2794 = -v2634.Y * 0.45
	v2792.trailBottom = Vector3.new(0, v2794, 0.4)
	v2792.d = v_u_15.normal
	return v2792
end
local function v_u_2978(p2796, p2797, p2798) -- name: fish
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_10, (copy) v_u_15
	local v2799 = p2798 == "koi"
	local v2800 = {
		["material"] = p2796.mat
	}
	local v2801 = {
		["neon"] = true
	}
	local v2802 = {
		["material"] = p2796.mat,
		["alpha"] = v2799 and 0.2 or nil
	}
	local v2803
	if v2799 then
		v2803 = p2796.trim
	else
		v2803 = p2796.pants
	end
	local v2804
	if v2799 then
		v2804 = p2796.skin
	else
		v2804 = p2796.accent
	end
	local v2805 = v2799 and Vector3.new(1.35, 1.25, 2.4) or Vector3.new(1.5, 1.4, 2.7)
	local v2806, v2807 = v_u_40(p2796, p2797, "Torso", v2805, p2796.shirt, CFrame.identity, CFrame.identity, v2800)
	local v2808 = v2805.X - 0.08
	local v2809 = v2805.Z - 0.3
	local v2810 = Vector3.new(v2808, 0.3, v2809)
	local v2811 = CFrame.new(0, -v2805.Y / 2 + 0.1, 0)
	local v2812 = v_u_27(p2796, "Belly", v2810, v2804, v2800)
	local v2813 = v2806.CFrame
	local v2814 = p2796.s
	v2812.CFrame = v2813 * (v2811.Rotation + v2811.Position * v2814)
	local v2815 = Instance.new("WeldConstraint")
	v2815.Part0 = v2806
	v2815.Part1 = v2812
	v2815.Parent = v2812
	local v2816 = v2799 and Vector3.new(1.25, 1.15, 1.1) or Vector3.new(1.35, 1.25, 1.3)
	local v2817, v2818 = v_u_40(p2796, v2806, "Head", v2816, p2796.skin, CFrame.new(0, 0, -v2805.Z / 2), CFrame.new(0, 0, v2816.Z / 2 - 0.15), v2800)
	local v2819 = -v2816.Z / 2
	for _, v2820 in { -1, 1 } do
		local v2821 = p2796.eye
		local v2822 = CFrame.new(v2820 * v2816.X * 0.36, v2816.Y * 0.18, v2819 - 0.03) * CFrame.Angles(0, 0, v2820 * 0.3)
		local v2823 = v_u_27(p2796, "Eye", Vector3.new(0.28, 0.18, 0.08), v2821, v2801)
		local v2824 = v2817.CFrame
		local v2825 = p2796.s
		v2823.CFrame = v2824 * (v2822.Rotation + v2822.Position * v2825)
		local v2826 = Instance.new("WeldConstraint")
		v2826.Part0 = v2817
		v2826.Part1 = v2823
		v2826.Parent = v2823
	end
	if v2799 then
		local v2827 = p2796.skin:Lerp(p2796.accent, 0.35)
		local v2828 = CFrame.new(0, -v2816.Y * 0.22, v2819 - 0.08)
		local v2829 = v_u_27(p2796, "Lips", Vector3.new(0.5, 0.36, 0.2), v2827, v2800)
		local v2830 = v2817.CFrame
		local v2831 = p2796.s
		v2829.CFrame = v2830 * (v2828.Rotation + v2828.Position * v2831)
		local v2832 = Instance.new("WeldConstraint")
		v2832.Part0 = v2817
		v2832.Part1 = v2829
		v2832.Parent = v2829
		local v2833 = v_u_7
		local v2834, v2835 = CFrame.new(0, -v2816.Y * 0.22, v2819 - 0.19)
		local v2836 = v_u_27(p2796, "Mouth", Vector3.new(0.28, 0.16, 0.06), v2833, v2835)
		local v2837 = v2817.CFrame
		local v2838 = p2796.s
		v2836.CFrame = v2837 * (v2834.Rotation + v2834.Position * v2838)
		local v2839 = Instance.new("WeldConstraint")
		v2839.Part0 = v2817
		v2839.Part1 = v2836
		v2839.Parent = v2836
		for _, v2840 in { -1, 1 } do
			local v2841 = v2840 * 0.22
			local v2842 = -v2816.Y * 0.18
			local v2843 = v2819 - 0.12
			local v2844 = Vector3.new(v2841, v2842, v2843)
			local v2845 = v2840 * 0.8
			local v2846 = -v2816.Y * 0.55
			local v2847 = v2819 - 0.6
			local v2848 = Vector3.new(v2845, v2846, v2847)
			local v2849 = p2796.glow
			local v2850 = (v2844 + v2848) / 2
			local v2851 = (v2848 - v2844).Magnitude
			local v2852 = Vector3.new(0.08, 0.08, v2851)
			local v2853 = CFrame.lookAt(v2850, v2848)
			local v2854 = v_u_27(p2796, "Whisker", v2852, v2849, v2801)
			local v2855 = v2817.CFrame
			local v2856 = p2796.s
			v2854.CFrame = v2855 * (v2853.Rotation + v2853.Position * v2856)
			local v2857 = Instance.new("WeldConstraint")
			v2857.Part0 = v2817
			v2857.Part1 = v2854
			v2857.Parent = v2854
		end
		local v2858 = v2816.X * 0.6
		local v2859 = v2816.Z * 0.6
		local v2860 = Vector3.new(v2858, 0.1, v2859)
		local v2861 = p2796.accent
		local v2862, v2863 = CFrame.new(v2816.X * 0.12, v2816.Y / 2 + 0.02, 0.05)
		local v2864 = v_u_27(p2796, "Patch", v2860, v2861, v2863)
		local v2865 = v2817.CFrame
		local v2866 = p2796.s
		v2864.CFrame = v2865 * (v2862.Rotation + v2862.Position * v2866)
		local v2867 = Instance.new("WeldConstraint")
		v2867.Part0 = v2817
		v2867.Part1 = v2864
		v2867.Parent = v2864
		local v2868 = v2805.X + 0.04
		local v2869 = v2805.Y * 0.5
		local v2870 = v2805.Z * 0.3
		local v2871 = Vector3.new(v2868, v2869, v2870)
		local v2872 = p2796.accent
		local v2873, v2874 = CFrame.new(0, v2805.Y * 0.28, -v2805.Z * 0.18)
		local v2875 = v_u_27(p2796, "Patch", v2871, v2872, v2874)
		local v2876 = v2806.CFrame
		local v2877 = p2796.s
		v2875.CFrame = v2876 * (v2873.Rotation + v2873.Position * v2877)
		local v2878 = Instance.new("WeldConstraint")
		v2878.Part0 = v2806
		v2878.Part1 = v2875
		v2878.Parent = v2875
		local v2879 = v2805.X * 0.6
		local v2880 = v2805.Z * 0.25
		local v2881 = Vector3.new(v2879, 0.1, v2880)
		local v2882 = p2796.accent
		local v2883, v2884 = CFrame.new(-v2805.X * 0.15, v2805.Y / 2 + 0.02, v2805.Z * 0.25)
		local v2885 = v_u_27(p2796, "Patch", v2881, v2882, v2884)
		local v2886 = v2806.CFrame
		local v2887 = p2796.s
		v2885.CFrame = v2886 * (v2883.Rotation + v2883.Position * v2887)
		local v2888 = Instance.new("WeldConstraint")
		v2888.Part0 = v2806
		v2888.Part1 = v2885
		v2888.Parent = v2885
	else
		local v2889 = v2816.X * 0.8
		local v2890 = v2816.Y * 0.55
		local v2891 = Vector3.new(v2889, v2890, 0.6)
		local v2892 = p2796.skin
		local v2893 = CFrame.new(0, v2816.Y * 0.12, v2819 - 0.25)
		local v2894 = v_u_27(p2796, "Snout", v2891, v2892, v2800)
		local v2895 = v2817.CFrame
		local v2896 = p2796.s
		v2894.CFrame = v2895 * (v2893.Rotation + v2893.Position * v2896)
		local v2897 = Instance.new("WeldConstraint")
		v2897.Part0 = v2817
		v2897.Part1 = v2894
		v2897.Parent = v2894
		local v2898 = v2816.X * 0.85
		local v2899 = v2816.Z * 0.9
		local v2900 = Vector3.new(v2898, 0.3, v2899)
		local v2901 = CFrame.new(0, -v2816.Y / 2 + 0.12, -0.05)
		local v2902 = v_u_27(p2796, "Jaw", v2900, v2804, v2800)
		local v2903 = v2817.CFrame
		local v2904 = p2796.s
		v2902.CFrame = v2903 * (v2901.Rotation + v2901.Position * v2904)
		local v2905 = Instance.new("WeldConstraint")
		v2905.Part0 = v2817
		v2905.Part1 = v2902
		v2905.Parent = v2902
		local v2906 = v2816.X * 0.75
		local v2907 = Vector3.new(v2906, 0.18, 0.08)
		local v2908 = v_u_7
		local v2909, v2910 = CFrame.new(0, -v2816.Y * 0.2, v2819 - 0.03)
		local v2911 = v_u_27(p2796, "Mouth", v2907, v2908, v2910)
		local v2912 = v2817.CFrame
		local v2913 = p2796.s
		v2911.CFrame = v2912 * (v2909.Rotation + v2909.Position * v2913)
		local v2914 = Instance.new("WeldConstraint")
		v2914.Part0 = v2817
		v2914.Part1 = v2911
		v2914.Parent = v2911
		for v2915 = -2, 2 do
			local v2916 = v_u_10
			local v2917 = CFrame.new(v2915 * 0.19, -v2816.Y * 0.15, v2819 - 0.07) * CFrame.Angles(0, 0, 0.7853981633974483)
			local v2918 = Instance.new("Part")
			v2918.Name = "Tooth"
			v2918.Size = Vector3.new(0.13, 0.13, 0.06) * p2796.s
			v2918.Color = v2916
			v2918.Material = Enum.Material.Plastic
			v2918.CanCollide = false
			v2918.CanTouch = false
			v2918.CanQuery = false
			v2918.Massless = true
			v2918.Anchored = false
			v2918.CastShadow = (Vector3.new(0.13, 0.13, 0.06)).Magnitude > 1.1
			v2918.TopSurface = Enum.SurfaceType.Smooth
			v2918.BottomSurface = Enum.SurfaceType.Smooth
			v2918.Parent = p2796.model
			local v2919 = v2817.CFrame
			local v2920 = p2796.s
			v2918.CFrame = v2919 * (v2917.Rotation + v2917.Position * v2920)
			local v2921 = Instance.new("WeldConstraint")
			v2921.Part0 = v2817
			v2921.Part1 = v2918
			v2921.Parent = v2918
		end
		for _, v2922 in { -1, 1 } do
			for v2923 = 0, 2 do
				local v2924 = v_u_7
				local v2925, v2926 = CFrame.new(v2922 * (v2816.X / 2 + 0.01), -0.05, v2923 * 0.18 + 0.05)
				local v2927 = v_u_27(p2796, "Gill", Vector3.new(0.05, 0.45, 0.07), v2924, v2926)
				local v2928 = v2817.CFrame
				local v2929 = p2796.s
				v2927.CFrame = v2928 * (v2925.Rotation + v2925.Position * v2929)
				local v2930 = Instance.new("WeldConstraint")
				v2930.Part0 = v2817
				v2930.Part1 = v2927
				v2930.Parent = v2927
			end
		end
	end
	local v2931 = Vector3.new(0.16, v2799 and 0.6 or 1.3, v2799 and 1.6 or 1.2)
	local v2932
	if v2799 then
		v2932 = v2803
	else
		v2932 = p2796.shirt
	end
	local v2933 = CFrame.new(0, v2805.Y / 2 + (v2799 and 0.3 or 0.65), v2799 and 0.1 or -0.1)
	local v2934 = v_u_27(p2796, "Dorsal", v2931, v2932, {
		["wedge"] = true,
		["material"] = nil,
		["alpha"] = nil,
		["material"] = p2796.mat,
		["alpha"] = v2802.alpha
	})
	local v2935 = v2806.CFrame
	local v2936 = p2796.s
	v2934.CFrame = v2935 * (v2933.Rotation + v2933.Position * v2936)
	local v2937 = Instance.new("WeldConstraint")
	v2937.Part0 = v2806
	v2937.Part1 = v2934
	v2937.Parent = v2934
	local v2938 = {}
	local v2939 = v2799 and Vector3.new(1.4, 0.08, 1) or Vector3.new(1.3, 0.12, 0.75)
	for _, v2940 in { 1, -1 } do
		local v2941 = v2940 == 1 and "Right" or "Left"
		local v2942, v2943 = v_u_40(p2796, v2806, v2941 .. "Arm", v2939, v2803, CFrame.new(v2940 * (v2805.X / 2 - 0.05), -v2805.Y * 0.25, -v2805.Z * 0.25) * CFrame.Angles(0, -v2940 * 0.4, 0) * CFrame.Angles(0, 0, -v2940 * 0.4), CFrame.new(-v2940 * v2939.X / 2, 0, 0), v2802)
		v2938[v2941 .. "Arm"] = v2943
		if v2799 then
			local v2944 = v2939.X
			local v2945 = Vector3.new(v2944, 0.1, 0.1)
			local v2946 = p2796.glow
			local v2947 = CFrame.new(0, 0, v2939.Z / 2)
			local v2948 = v_u_27(p2796, "FinEdge", v2945, v2946, v2801)
			local v2949 = v2942.CFrame
			local v2950 = p2796.s
			v2948.CFrame = v2949 * (v2947.Rotation + v2947.Position * v2950)
			local v2951 = Instance.new("WeldConstraint")
			v2951.Part0 = v2942
			v2951.Part1 = v2948
			v2951.Parent = v2948
		end
		local _, v2952 = v_u_40(p2796, v2806, v2941 .. "Leg", Vector3.new(0.6, 0.08, 0.45), v2803, CFrame.new(v2940 * v2805.X * 0.35, -v2805.Y / 2 + 0.05, v2805.Z * 0.25) * CFrame.Angles(0, 0, -v2940 * 0.8), CFrame.new(-v2940 * 0.3, 0, 0), v2802)
		v2938[v2941 .. "Leg"] = v2952
	end
	local v2953 = v_u_40
	local v2954 = v2805.X * 0.5
	local v2955 = v2805.Y * 0.55
	local v2956, v2957 = v2953(p2796, v2806, "Tail", Vector3.new(v2954, v2955, 1), p2796.shirt, CFrame.new(0, 0.05, v2805.Z / 2 - 0.1), CFrame.new(0, 0, -0.5), v2800)
	for _, v2958 in v2799 and {
		{
			0.55,
			0.6,
			1.6,
			0.9,
			0.55
		},
		{
			-0.5,
			0.55,
			1.6,
			0.9,
			-0.55
		}
	} or {
		{
			0.6,
			0.6,
			1.6,
			0.75,
			0.6
		},
		{
			-0.4,
			0.55,
			1,
			0.6,
			-0.6
		}
	} do
		local v2959 = v2958[3]
		local v2960 = v2958[4]
		local v2961 = Vector3.new(0.14, v2959, v2960)
		local v2962 = CFrame.new(0, v2958[1], v2958[2]) * CFrame.Angles(v2958[5], 0, 0)
		local v2963 = v_u_27(p2796, "TailFin", v2961, v2803, v2802)
		local v2964 = v2956.CFrame
		local v2965 = p2796.s
		v2963.CFrame = v2964 * (v2962.Rotation + v2962.Position * v2965)
		local v2966 = Instance.new("WeldConstraint")
		v2966.Part0 = v2956
		v2966.Part1 = v2963
		v2966.Parent = v2963
		if not v2799 then
			continue
		end
		local v2967 = v2958[3]
		local v2968 = Vector3.new(0.18, v2967, 0.1)
		local v2969 = p2796.glow
		local v2970 = CFrame.new(0, 0, v2958[4] / 2)
		local v2971 = v_u_27(p2796, "FinEdge", v2968, v2969, v2801)
		local v2972 = v2963.CFrame
		local v2973 = p2796.s
		v2971.CFrame = v2972 * (v2970.Rotation + v2970.Position * v2973)
		local v2974 = Instance.new("WeldConstraint")
		v2974.Part0 = v2963
		v2974.Part1 = v2971
		v2974.Parent = v2971
	end
	local v2975 = {
		["torso"] = v2806,
		["head"] = v2817,
		["waist"] = v2807,
		["neck"] = v2818,
		["rightArm"] = v2938.RightArm,
		["leftArm"] = v2938.LeftArm,
		["rightLeg"] = v2938.RightLeg,
		["leftLeg"] = v2938.LeftLeg,
		["tail"] = v2957,
		["lift"] = v2799 and 2.6 or 2.5
	}
	local v2976 = v2805.Y * 0.4
	v2975.trailTop = Vector3.new(0, v2976, 0.5)
	local v2977 = -v2805.Y * 0.4
	v2975.trailBottom = Vector3.new(0, v2977, 0.5)
	v2975.d = v_u_15.normal
	return v2975
end
local function v_u_3052(p2979, p2980) -- name: scorpion
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_15
	local v2981, v2982 = v_u_40(p2979, p2980, "Torso", Vector3.new(2.2, 0.9, 2.4), p2979.shirt, CFrame.identity, CFrame.identity, {
		["studs"] = true
	})
	local v2983 = p2979.skin
	local v2984 = CFrame.new(0, 0.55, 0.1)
	local v2985 = v_u_27(p2979, "Plate", Vector3.new(1.8, 0.3, 2), v2983, {
		["studs"] = true
	})
	local v2986 = v2981.CFrame
	local v2987 = p2979.s
	v2985.CFrame = v2986 * (v2984.Rotation + v2984.Position * v2987)
	local v2988 = Instance.new("WeldConstraint")
	v2988.Part0 = v2981
	v2988.Part1 = v2985
	v2988.Parent = v2985
	local v2989, v2990 = v_u_40(p2979, v2981, "Head", Vector3.new(1.3, 0.7, 0.8), p2979.skin, CFrame.new(0, 0.05, -1.2), CFrame.new(0, 0, 0.4))
	for _, v2991 in { -1, 1 } do
		local v2992 = p2979.eye
		local v2993 = CFrame.new(v2991 * 0.3, 0.14, -0.42) * CFrame.Angles(0, 0, v2991 * 0.28)
		local v2994 = v_u_27(p2979, "Eye", Vector3.new(0.26, 0.16, 0.08), v2992, {
			["neon"] = true
		})
		local v2995 = v2989.CFrame
		local v2996 = p2979.s
		v2994.CFrame = v2995 * (v2993.Rotation + v2993.Position * v2996)
		local v2997 = Instance.new("WeldConstraint")
		v2997.Part0 = v2989
		v2997.Part1 = v2994
		v2997.Parent = v2994
	end
	local v2998 = {}
	local v2999 = {}
	for _, v3000 in { 1, -1 } do
		local v3001, v3002 = v_u_40(p2979, v2981, v3000 == 1 and "RightArm" or "LeftArm", Vector3.new(0.45, 0.45, 1.3), p2979.skin, CFrame.new(v3000 * 0.95, 0, -1.2) * CFrame.Angles(0, -v3000 * 0.35, 0), CFrame.new(0, 0, 0.65))
		v2999[v3000] = v3002
		local v3003 = p2979.skin
		local v3004, v3005 = CFrame.new(0, 0, -0.95)
		local v3006 = v_u_27(p2979, "Pincer", Vector3.new(0.85, 0.55, 0.75), v3003, v3005)
		local v3007 = v3001.CFrame
		local v3008 = p2979.s
		v3006.CFrame = v3007 * (v3004.Rotation + v3004.Position * v3008)
		local v3009 = Instance.new("WeldConstraint")
		v3009.Part0 = v3001
		v3009.Part1 = v3006
		v3009.Parent = v3006
		local v3010 = p2979.pants
		local v3011, v3012 = CFrame.new(v3000 * 0.22, 0, -1.7)
		local v3013 = v_u_27(p2979, "Jaw", Vector3.new(0.22, 0.3, 0.85), v3010, v3012)
		local v3014 = v3001.CFrame
		local v3015 = p2979.s
		v3013.CFrame = v3014 * (v3011.Rotation + v3011.Position * v3015)
		local v3016 = Instance.new("WeldConstraint")
		v3016.Part0 = v3001
		v3016.Part1 = v3013
		v3016.Parent = v3013
		local v3017 = p2979.glow
		local v3018 = CFrame.new(-v3000 * 0.22, 0, -1.7)
		local v3019 = v_u_27(p2979, "Jaw", Vector3.new(0.22, 0.3, 0.85), v3017, {
			["neon"] = true
		})
		local v3020 = v3001.CFrame
		local v3021 = p2979.s
		v3019.CFrame = v3020 * (v3018.Rotation + v3018.Position * v3021)
		local v3022 = Instance.new("WeldConstraint")
		v3022.Part0 = v3001
		v3022.Part1 = v3019
		v3022.Parent = v3019
		local v3023, v3024 = v_u_40(p2979, v2981, v3000 == 1 and "RightLeg" or "LeftLeg", Vector3.new(0.2, 0.2, 0.2), v_u_7, CFrame.new(v3000 * 1.05, -0.15, 0.15), CFrame.identity, {
			["hidden"] = true
		})
		v2998[v3000] = v3024
		for _, v3025 in { -0.65, 0, 0.65 } do
			local v3026 = p2979.pants
			local v3027 = CFrame.new(v3000 * 0.6, -0.45, v3025) * CFrame.Angles(0, 0, -v3000 * 0.75)
			local v3028 = Instance.new("Part")
			v3028.Name = "Leg"
			v3028.Size = Vector3.new(1.6, 0.22, 0.22) * p2979.s
			v3028.Color = v3026
			v3028.Material = Enum.Material.Plastic
			v3028.CanCollide = false
			v3028.CanTouch = false
			v3028.CanQuery = false
			v3028.Massless = true
			v3028.Anchored = false
			v3028.CastShadow = (Vector3.new(1.6, 0.22, 0.22)).Magnitude > 1.1
			v3028.TopSurface = Enum.SurfaceType.Smooth
			v3028.BottomSurface = Enum.SurfaceType.Smooth
			v3028.Parent = p2979.model
			local v3029 = v3023.CFrame
			local v3030 = p2979.s
			v3028.CFrame = v3029 * (v3027.Rotation + v3027.Position * v3030)
			local v3031 = Instance.new("WeldConstraint")
			v3031.Part0 = v3023
			v3031.Part1 = v3028
			v3031.Parent = v3028
		end
	end
	local v3032, v3033 = v_u_40(p2979, v2981, "Tail", Vector3.new(0.6, 0.6, 1), p2979.skin, CFrame.new(0, 0.3, 1.1) * CFrame.Angles(-0.9, 0, 0), CFrame.new(0, 0, -0.5))
	local v3034 = 1
	for _, v3035 in {
		{ 0.52, 0.9, -0.8 },
		{ 0.46, 0.8, -0.8 },
		{ 0.4, 0.7, -0.7 }
	} do
		local v3036 = v3035[1]
		local v3037 = v3035[2]
		local v3038 = v3035[3]
		local v3039 = Vector3.new(v3036, v3036, v3037)
		local v3040 = p2979.skin
		local v3041 = CFrame.new(0, 0, v3034 / 2) * CFrame.Angles(v3038, 0, 0) * CFrame.new(0, 0, v3037 / 2)
		local v3042 = Instance.new("Part")
		v3042.Name = "Tail"
		v3042.Size = v3039 * p2979.s
		v3042.Color = v3040
		v3042.Material = Enum.Material.Plastic
		v3042.CanCollide = false
		v3042.CanTouch = false
		v3042.CanQuery = false
		v3042.Massless = true
		v3042.Anchored = false
		v3042.CastShadow = v3039.Magnitude > 1.1
		v3042.TopSurface = Enum.SurfaceType.Smooth
		v3042.BottomSurface = Enum.SurfaceType.Smooth
		v3042.Parent = p2979.model
		local v3043 = v3032.CFrame
		local v3044 = p2979.s
		v3042.CFrame = v3043 * (v3041.Rotation + v3041.Position * v3044)
		local v3045 = Instance.new("WeldConstraint")
		v3045.Part0 = v3032
		v3045.Part1 = v3042
		v3045.Parent = v3042
		v3034 = v3037
		v3032 = v3042
	end
	local v3046 = p2979.glow
	local v3047 = CFrame.new(0, 0, v3034 / 2) * CFrame.Angles(-0.6, 0, 0) * CFrame.new(0, 0, 0.3)
	local v3048 = v_u_27(p2979, "Stinger", Vector3.new(0.3, 0.3, 0.75), v3046, {
		["neon"] = true
	})
	local v3049 = v3032.CFrame
	local v3050 = p2979.s
	v3048.CFrame = v3049 * (v3047.Rotation + v3047.Position * v3050)
	local v3051 = Instance.new("WeldConstraint")
	v3051.Part0 = v3032
	v3051.Part1 = v3048
	v3051.Parent = v3048
	return {
		["torso"] = nil,
		["head"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = 1.2,
		["trailTop"] = Vector3.new(0, 0.45, 0.6),
		["trailBottom"] = Vector3.new(0, -0.45, 0.6),
		["d"] = nil,
		["torso"] = v2981,
		["head"] = v2989,
		["waist"] = v2982,
		["neck"] = v2990,
		["rightArm"] = v2999[1],
		["leftArm"] = v2999[-1],
		["rightLeg"] = v2998[1],
		["leftLeg"] = v2998[-1],
		["tail"] = v3033,
		["d"] = v_u_15.normal
	}
end
local function v_u_3141(p3053, p3054) -- name: spider
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_15
	local v3055 = {
		["material"] = nil,
		["studs"] = true,
		["material"] = p3053.mat
	}
	local v3056, v3057 = v_u_40(p3053, p3054, "Torso", Vector3.new(1.6, 1, 1.6), p3053.shirt, CFrame.identity, CFrame.identity, v3055)
	local v3058 = p3053.pants
	local v3059 = CFrame.new(0, 0.4, 1.85) * CFrame.Angles(0.25, 0, 0)
	local v3060 = v_u_27(p3053, "Abdomen", Vector3.new(2.2, 1.7, 2.4), v3058, v3055)
	local v3061 = v3056.CFrame
	local v3062 = p3053.s
	v3060.CFrame = v3061 * (v3059.Rotation + v3059.Position * v3062)
	local v3063 = Instance.new("WeldConstraint")
	v3063.Part0 = v3056
	v3063.Part1 = v3060
	v3063.Parent = v3060
	local v3064, v3065 = v_u_40(p3053, v3056, "Head", Vector3.new(1, 0.75, 0.7), p3053.skin, CFrame.new(0, 0.05, -0.8), CFrame.new(0, 0, 0.35))
	for _, v3066 in {
		{ 0.2, 0.1, 0.24 },
		{ -0.2, 0.1, 0.24 },
		{ 0.38, 0.24, 0.16 },
		{ -0.38, 0.24, 0.16 }
	} do
		local v3067 = v3066[3]
		local v3068 = v3066[3]
		local v3069 = Vector3.new(v3067, v3068, 0.08)
		local v3070 = p3053.eye
		local v3071 = CFrame.new(v3066[1], v3066[2], -0.37)
		local v3072 = v_u_27(p3053, "Eye", v3069, v3070, {
			["neon"] = true
		})
		local v3073 = v3064.CFrame
		local v3074 = p3053.s
		v3072.CFrame = v3073 * (v3071.Rotation + v3071.Position * v3074)
		local v3075 = Instance.new("WeldConstraint")
		v3075.Part0 = v3064
		v3075.Part1 = v3072
		v3075.Parent = v3072
	end
	for _, v3076 in { -1, 1 } do
		local v3077 = p3053.glow
		local v3078 = CFrame.new(v3076 * 0.18, -0.4, -0.25) * CFrame.Angles(0.3, 0, 0)
		local v3079 = v_u_27(p3053, "Fang", Vector3.new(0.14, 0.42, 0.14), v3077, {
			["neon"] = true
		})
		local v3080 = v3064.CFrame
		local v3081 = p3053.s
		v3079.CFrame = v3080 * (v3078.Rotation + v3078.Position * v3081)
		local v3082 = Instance.new("WeldConstraint")
		v3082.Part0 = v3064
		v3082.Part1 = v3079
		v3082.Parent = v3079
	end
	local v3083 = p3053.look.gear
	local v3084
	if v3083 == nil then
		v3084 = false
	else
		v3084 = table.find(v3083, "lure") ~= nil
	end
	if v3084 then
		local v3085 = p3053.skin
		local v3086 = (Vector3.new(0, 1.1500001, -0.3)).Magnitude
		local v3087 = Vector3.new(0.12, 0.12, v3086)
		local v3088 = CFrame.lookAt(Vector3.new(0, 0.875, -0.05), Vector3.new(0, 1.45, -0.2))
		local v3089 = Instance.new("Part")
		v3089.Name = "Lure"
		v3089.Size = v3087 * p3053.s
		v3089.Color = v3085
		v3089.Material = Enum.Material.Plastic
		v3089.CanCollide = false
		v3089.CanTouch = false
		v3089.CanQuery = false
		v3089.Massless = true
		v3089.Anchored = false
		v3089.CastShadow = v3087.Magnitude > 1.1
		v3089.TopSurface = Enum.SurfaceType.Smooth
		v3089.BottomSurface = Enum.SurfaceType.Smooth
		v3089.Parent = p3053.model
		local v3090 = v3064.CFrame
		local v3091 = p3053.s
		v3089.CFrame = v3090 * (v3088.Rotation + v3088.Position * v3091)
		local v3092 = Instance.new("WeldConstraint")
		v3092.Part0 = v3064
		v3092.Part1 = v3089
		v3092.Parent = v3089
		local v3093 = p3053.skin
		local v3094 = (Vector3.new(0, -0.1500001, -0.8)).Magnitude
		local v3095 = Vector3.new(0.1, 0.1, v3094)
		local v3096 = CFrame.lookAt(Vector3.new(0, 1.375, -0.6), Vector3.new(0, 1.3, -1))
		local v3097 = Instance.new("Part")
		v3097.Name = "Lure"
		v3097.Size = v3095 * p3053.s
		v3097.Color = v3093
		v3097.Material = Enum.Material.Plastic
		v3097.CanCollide = false
		v3097.CanTouch = false
		v3097.CanQuery = false
		v3097.Massless = true
		v3097.Anchored = false
		v3097.CastShadow = v3095.Magnitude > 1.1
		v3097.TopSurface = Enum.SurfaceType.Smooth
		v3097.BottomSurface = Enum.SurfaceType.Smooth
		v3097.Parent = p3053.model
		local v3098 = v3064.CFrame
		local v3099 = p3053.s
		v3097.CFrame = v3098 * (v3096.Rotation + v3096.Position * v3099)
		local v3100 = Instance.new("WeldConstraint")
		v3100.Part0 = v3064
		v3100.Part1 = v3097
		v3100.Parent = v3097
		local v3101 = p3053.glow
		local v3102 = CFrame.new(Vector3.new(0, 1.0999999, -1.05))
		local v3103 = v_u_27(p3053, "LureBulb", Vector3.new(0.55, 0.55, 0.55), v3101, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v3104 = v3064.CFrame
		local v3105 = p3053.s
		v3103.CFrame = v3104 * (v3102.Rotation + v3102.Position * v3105)
		local v3106 = Instance.new("WeldConstraint")
		v3106.Part0 = v3064
		v3106.Part1 = v3103
		v3106.Parent = v3103
	end
	local v3107 = {}
	for _, v3108 in {
		{
			["name"] = "Arm",
			["z"] = -0.3,
			["yaws"] = nil,
			["yaws"] = { 0.55, 0.18 }
		},
		{
			["name"] = "Leg",
			["z"] = 0.35,
			["yaws"] = nil,
			["yaws"] = { -0.18, -0.55 }
		}
	} do
		for _, v3109 in { 1, -1 } do
			local v3110 = (v3109 == 1 and "Right" or "Left") .. v3108.name
			local v3111, v3112 = v_u_40(p3053, v3056, v3110, Vector3.new(0.2, 0.2, 0.2), v_u_7, CFrame.new(v3109 * 0.75, 0, v3108.z), CFrame.identity, {
				["hidden"] = true
			})
			v3107[v3110] = v3112
			for _, v3113 in v3108.yaws do
				local v3114 = CFrame.Angles(0, v3109 * v3113, 0)
				local v3115 = p3053.pants
				local v3116 = v3114 * CFrame.new(v3109 * 0.6, 0.35, 0) * CFrame.Angles(0, 0, v3109 * 0.5)
				local v3117 = Instance.new("Part")
				v3117.Name = "Leg"
				v3117.Size = Vector3.new(1.4, 0.2, 0.2) * p3053.s
				v3117.Color = v3115
				v3117.Material = Enum.Material.Plastic
				v3117.CanCollide = false
				v3117.CanTouch = false
				v3117.CanQuery = false
				v3117.Massless = true
				v3117.Anchored = false
				v3117.CastShadow = (Vector3.new(1.4, 0.2, 0.2)).Magnitude > 1.1
				v3117.TopSurface = Enum.SurfaceType.Smooth
				v3117.BottomSurface = Enum.SurfaceType.Smooth
				v3117.Parent = p3053.model
				local v3118 = v3111.CFrame
				local v3119 = p3053.s
				v3117.CFrame = v3118 * (v3116.Rotation + v3116.Position * v3119)
				local v3120 = Instance.new("WeldConstraint")
				v3120.Part0 = v3111
				v3120.Part1 = v3117
				v3120.Parent = v3117
				local v3121 = p3053.skin
				local v3122 = v3114 * CFrame.new(v3109 * 1.36, -0.46, 0) * CFrame.Angles(0, 0, v3109 * 0.12)
				local v3123 = Instance.new("Part")
				v3123.Name = "Shin"
				v3123.Size = Vector3.new(0.2, 2.35, 0.2) * p3053.s
				v3123.Color = v3121
				v3123.Material = Enum.Material.Plastic
				v3123.CanCollide = false
				v3123.CanTouch = false
				v3123.CanQuery = false
				v3123.Massless = true
				v3123.Anchored = false
				v3123.CastShadow = (Vector3.new(0.2, 2.35, 0.2)).Magnitude > 1.1
				v3123.TopSurface = Enum.SurfaceType.Smooth
				v3123.BottomSurface = Enum.SurfaceType.Smooth
				v3123.Parent = p3053.model
				local v3124 = v3111.CFrame
				local v3125 = p3053.s
				v3123.CFrame = v3124 * (v3122.Rotation + v3122.Position * v3125)
				local v3126 = Instance.new("WeldConstraint")
				v3126.Part0 = v3111
				v3126.Part1 = v3123
				v3126.Parent = v3123
			end
		end
	end
	local v3127 = p3053.look.gear
	local v3128
	if v3127 == nil then
		v3128 = false
	else
		v3128 = table.find(v3127, "crystals") ~= nil
	end
	if v3128 then
		for v3129, v3130 in {
			{
				0,
				0.95,
				-0.2,
				0.2,
				0,
				1.3,
				0.45
			},
			{
				0.55,
				0.8,
				0.45,
				0.3,
				-0.4,
				0.95,
				0.35
			},
			{
				-0.55,
				0.75,
				0.3,
				0.2,
				0.45,
				0.9,
				0.35
			}
		} do
			local v3131 = v3130[7]
			local v3132 = v3130[6]
			local v3133 = v3130[7]
			local v3134 = Vector3.new(v3131, v3132, v3133)
			local v3135
			if v3129 == 1 then
				v3135 = p3053.glow
			else
				v3135 = p3053.eye
			end
			local v3136 = CFrame.new(v3130[1], v3130[2], v3130[3]) * CFrame.Angles(v3130[4], 0, v3130[5]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v3137 = v_u_27(p3053, "Crystal", v3134, v3135, {
				["neon"] = true
			})
			local v3138 = v3060.CFrame
			local v3139 = p3053.s
			v3137.CFrame = v3138 * (v3136.Rotation + v3136.Position * v3139)
			local v3140 = Instance.new("WeldConstraint")
			v3140.Part0 = v3060
			v3140.Part1 = v3137
			v3140.Parent = v3137
		end
	end
	return {
		["torso"] = nil,
		["head"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = 1.6,
		["trailTop"] = Vector3.new(0, 0.5, 0.5),
		["trailBottom"] = Vector3.new(0, -0.5, 0.5),
		["d"] = nil,
		["torso"] = v3056,
		["head"] = v3064,
		["waist"] = v3057,
		["neck"] = v3065,
		["rightArm"] = v3107.RightArm,
		["leftArm"] = v3107.LeftArm,
		["rightLeg"] = v3107.RightLeg,
		["leftLeg"] = v3107.LeftLeg,
		["d"] = v_u_15.normal
	}
end
v_u_14.kama = 1
v_u_14.mantis = 0.75
v_u_14.twinblades = 0.35
v_u_14.anchor = 0.95
v_u_14.halberd = 0.7
v_u_14.chainblade = 0.5
v_u_14.iceclub = 0.95
local v_u_3142 = Color3.fromRGB(214, 240, 255)
local v_u_3143 = Color3.fromRGB(240, 248, 255)
local v_u_3144 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_3145 = CFrame.Angles(0, 0, 0.7853981633974483)
local function v_u_3705(p3146, p3147, p3148) -- name: hat3
	-- upvalues: (copy) v_u_3144, (copy) v_u_27, (copy) v_u_3145, (copy) v_u_57, (copy) v_u_3142, (copy) v_u_3143, (copy) v_u_13
	local v3149 = p3146.look.hat
	local v3150 = p3148 / 2
	local v3151 = -p3148 / 2
	local v3152 = p3148 / 1.6
	local v3153 = {
		["neon"] = true
	}
	local v3154 = {
		["material"] = Enum.Material.Metal
	}
	local v3155 = {
		["shape"] = Enum.PartType.Cylinder
	}
	local v3156 = {
		["material"] = Enum.Material.Ice
	}
	if v3149 == "kappa" then
		local v3157 = p3148 * 0.92
		local v3158 = p3148 * 0.92
		local v3159 = Vector3.new(0.16, v3157, v3158)
		local v3160 = p3146.accent
		local v3161 = CFrame.new(0, v3150 + 0.05, 0) * v_u_3144
		local v3162 = v_u_27(p3146, "Dish", v3159, v3160, v3155)
		local v3163 = p3147.CFrame
		local v3164 = p3146.s
		v3162.CFrame = v3163 * (v3161.Rotation + v3161.Position * v3164)
		local v3165 = Instance.new("WeldConstraint")
		v3165.Part0 = p3147
		v3165.Part1 = v3162
		v3165.Parent = v3162
		local v3166 = p3148 * 0.72
		local v3167 = p3148 * 0.72
		local v3168 = Vector3.new(0.18, v3166, v3167)
		local v3169 = p3146.glow
		local v3170 = CFrame.new(0, v3150 + 0.07, 0) * v_u_3144
		local v3171 = v_u_27(p3146, "DishWater", v3168, v3169, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v3172 = p3147.CFrame
		local v3173 = p3146.s
		v3171.CFrame = v3172 * (v3170.Rotation + v3170.Position * v3173)
		local v3174 = Instance.new("WeldConstraint")
		v3174.Part0 = p3147
		v3174.Part1 = v3171
		v3174.Parent = v3171
		for v3175 = 0, 9 do
			local v3176 = Vector3.new(0.46, 0.5, 0.14) * v3152
			local v3177 = p3146.trim
			local v3178 = CFrame.Angles(0, v3175 * 3.141592653589793 / 5, 0) * CFrame.new(0, v3150 - 0.14, -p3148 * 0.56) * CFrame.Angles(-0.3, 0, 0)
			local v3179 = Instance.new("Part")
			v3179.Name = "Hair"
			v3179.Size = v3176 * p3146.s
			v3179.Color = v3177
			v3179.Material = Enum.Material.Plastic
			v3179.CanCollide = false
			v3179.CanTouch = false
			v3179.CanQuery = false
			v3179.Massless = true
			v3179.Anchored = false
			v3179.CastShadow = v3176.Magnitude > 1.1
			v3179.TopSurface = Enum.SurfaceType.Smooth
			v3179.BottomSurface = Enum.SurfaceType.Smooth
			v3179.Parent = p3146.model
			local v3180 = p3147.CFrame
			local v3181 = p3146.s
			v3179.CFrame = v3180 * (v3178.Rotation + v3178.Position * v3181)
			local v3182 = Instance.new("WeldConstraint")
			v3182.Part0 = p3147
			v3182.Part1 = v3179
			v3182.Parent = v3179
		end
		return
	elseif v3149 == "witch" then
		local v3183 = v3152 * 3.1
		local v3184 = v3152 * 3.1
		local v3185 = Vector3.new(0.12, v3183, v3184)
		local v3186 = p3146.shirt
		local v3187 = CFrame.new(0, v3150 + 0.02, 0.05) * CFrame.Angles(-0.08, 0, 0) * v_u_3144
		local v3188 = v_u_27(p3146, "Brim", v3185, v3186, v3155)
		local v3189 = p3147.CFrame
		local v3190 = p3146.s
		v3188.CFrame = v3189 * (v3187.Rotation + v3187.Position * v3190)
		local v3191 = Instance.new("WeldConstraint")
		v3191.Part0 = p3147
		v3191.Part1 = v3188
		v3191.Parent = v3188
		for v3192, v3193 in {
			{ 1.55, 0 },
			{ 1.25, 0.05 },
			{ 0.95, 0.14 },
			{ 0.68, 0.28 },
			{ 0.42, 0.46 }
		} do
			local v3194 = v3193[1] * v3152
			local v3195 = v3193[1] * v3152
			local v3196 = Vector3.new(0.45, v3194, v3195)
			local v3197 = p3146.shirt
			local v3198 = CFrame.new(0, v3150 + 0.25 + (v3192 - 1) * 0.4, v3193[2]) * CFrame.Angles(-0.04 * v3192, 0, 0) * v_u_3144
			local v3199 = v_u_27(p3146, "Cone", v3196, v3197, v3155)
			local v3200 = p3147.CFrame
			local v3201 = p3146.s
			v3199.CFrame = v3200 * (v3198.Rotation + v3198.Position * v3201)
			local v3202 = Instance.new("WeldConstraint")
			v3202.Part0 = p3147
			v3202.Part1 = v3199
			v3202.Parent = v3199
		end
		local v3203 = v3150 + 1.9
		local v3204 = Vector3.new(0, v3203, 0.45)
		local v3205 = v3150 + 2.05
		local v3206 = Vector3.new(0, v3205, 1.25)
		local v3207 = p3146.shirt
		local v3208 = (v3204 + v3206) / 2
		local v3209 = (v3206 - v3204).Magnitude
		local v3210 = Vector3.new(0.24, 0.24, v3209)
		local v3211 = CFrame.lookAt(v3208, v3206)
		local v3212 = Instance.new("Part")
		v3212.Name = "ConeTip"
		v3212.Size = v3210 * p3146.s
		v3212.Color = v3207
		v3212.Material = Enum.Material.Plastic
		v3212.CanCollide = false
		v3212.CanTouch = false
		v3212.CanQuery = false
		v3212.Massless = true
		v3212.Anchored = false
		v3212.CastShadow = v3210.Magnitude > 1.1
		v3212.TopSurface = Enum.SurfaceType.Smooth
		v3212.BottomSurface = Enum.SurfaceType.Smooth
		v3212.Parent = p3146.model
		local v3213 = p3147.CFrame
		local v3214 = p3146.s
		v3212.CFrame = v3213 * (v3211.Rotation + v3211.Position * v3214)
		local v3215 = Instance.new("WeldConstraint")
		v3215.Part0 = p3147
		v3215.Part1 = v3212
		v3215.Parent = v3212
		local v3216 = v3152 * 1.6
		local v3217 = v3152 * 1.6
		local v3218 = Vector3.new(0.2, v3216, v3217)
		local v3219 = p3146.trim
		local v3220 = CFrame.new(0, v3150 + 0.18, 0) * v_u_3144
		local v3221 = v_u_27(p3146, "Band", v3218, v3219, v3155)
		local v3222 = p3147.CFrame
		local v3223 = p3146.s
		v3221.CFrame = v3222 * (v3220.Rotation + v3220.Position * v3223)
		local v3224 = Instance.new("WeldConstraint")
		v3224.Part0 = p3147
		v3224.Part1 = v3221
		v3224.Parent = v3221
		for v3225 = 0, 3 do
			local v3226 = p3146.glow
			local v3227 = CFrame.Angles(0, v3225 * 3.141592653589793 / 2 + 0.7853981633974483, 0) * CFrame.new(0, v3150 + 0.2, v3152 * -0.8) * CFrame.Angles(-1.2, 0, 0)
			local v3228 = v_u_27(p3146, "Thorn", Vector3.new(0.1, 0.32, 0.1), v3226, v3153)
			local v3229 = p3147.CFrame
			local v3230 = p3146.s
			v3228.CFrame = v3229 * (v3227.Rotation + v3227.Position * v3230)
			local v3231 = Instance.new("WeldConstraint")
			v3231.Part0 = p3147
			v3231.Part1 = v3228
			v3231.Parent = v3228
		end
		local v3232 = CFrame.new(v3152 * 0.45, v3150 + 0.24, v3151 - 0.12)
		for v3233 = 0, 4 do
			local v3234 = p3146.glow
			local v3235 = v3232 * CFrame.Angles(0, 0, v3233 * 3.141592653589793 * 2 / 5) * CFrame.new(0, 0.15, 0) * v_u_3145
			local v3236 = v_u_27(p3146, "Bloom", Vector3.new(0.26, 0.26, 0.06), v3234, v3153)
			local v3237 = p3147.CFrame
			local v3238 = p3146.s
			v3236.CFrame = v3237 * (v3235.Rotation + v3235.Position * v3238)
			local v3239 = Instance.new("WeldConstraint")
			v3239.Part0 = p3147
			v3239.Part1 = v3236
			v3239.Parent = v3236
		end
		local v3240 = p3146.eye
		local v3241 = v3232 * CFrame.new(0, 0, -0.03)
		local v3242 = v_u_27(p3146, "BloomHeart", Vector3.new(0.16, 0.16, 0.08), v3240, v3153)
		local v3243 = p3147.CFrame
		local v3244 = p3146.s
		v3242.CFrame = v3243 * (v3241.Rotation + v3241.Position * v3244)
		local v3245 = Instance.new("WeldConstraint")
		v3245.Part0 = p3147
		v3245.Part1 = v3242
		v3245.Parent = v3242
		return
	elseif v3149 == "longhair" then
		local v3246 = p3148 + 0.12
		local v3247 = p3148 + 0.12
		local v3248 = Vector3.new(v3246, 0.34, v3247)
		local v3249 = p3146.trim
		local v3250, v3251 = CFrame.new(0, v3150 + 0.05, 0.02)
		local v3252 = v_u_27(p3146, "HairTop", v3248, v3249, v3251)
		local v3253 = p3147.CFrame
		local v3254 = p3146.s
		v3252.CFrame = v3253 * (v3250.Rotation + v3250.Position * v3254)
		local v3255 = Instance.new("WeldConstraint")
		v3255.Part0 = p3147
		v3255.Part1 = v3252
		v3255.Parent = v3252
		local v3256 = p3148 + 0.12
		local v3257 = Vector3.new(v3256, 0.3, 0.16)
		local v3258 = p3146.trim
		local v3259, v3260 = CFrame.new(0, v3150 - 0.18, v3151 - 0.06)
		local v3261 = v_u_27(p3146, "Bangs", v3257, v3258, v3260)
		local v3262 = p3147.CFrame
		local v3263 = p3146.s
		v3261.CFrame = v3262 * (v3259.Rotation + v3259.Position * v3263)
		local v3264 = Instance.new("WeldConstraint")
		v3264.Part0 = p3147
		v3264.Part1 = v3261
		v3264.Parent = v3261
		local v3265 = v_u_57
		local v3266 = p3148 + 0.14
		local v3267 = v3152 * 2.6
		v3265(p3146, p3147, "HairBack", Vector3.new(v3266, v3267, 0.3), p3146.trim, CFrame.new(0, v3150 - 0.05, p3148 / 2 + 0.14), CFrame.new(0, v3152 * 1.3, 0), Vector3.new(1, 0, 0), 0.07, 2.2, -0.35)
		for _, v3268 in { -1, 1 } do
			local v3269 = v3152 * 1.5
			local v3270 = Vector3.new(0.24, v3269, 0.45)
			local v3271 = p3146.trim
			local v3272, v3273 = CFrame.new(v3268 * (p3148 / 2 + 0.1), p3148 * -0.25, v3151 + 0.3)
			local v3274 = v_u_27(p3146, "Lock", v3270, v3271, v3273)
			local v3275 = p3147.CFrame
			local v3276 = p3146.s
			v3274.CFrame = v3275 * (v3272.Rotation + v3272.Position * v3276)
			local v3277 = Instance.new("WeldConstraint")
			v3277.Part0 = p3147
			v3277.Part1 = v3274
			v3277.Parent = v3274
		end
		local v3278 = p3146.glow
		local v3279 = CFrame.new(v3152 * 0.3, v3150 - 0.18, v3151 - 0.16) * v_u_3145
		local v3280 = v_u_27(p3146, "HairGem", Vector3.new(0.24, 0.24, 0.08), v3278, v3153)
		local v3281 = p3147.CFrame
		local v3282 = p3146.s
		v3280.CFrame = v3281 * (v3279.Rotation + v3279.Position * v3282)
		local v3283 = Instance.new("WeldConstraint")
		v3283.Part0 = p3147
		v3283.Part1 = v3280
		v3283.Parent = v3280
		return
	elseif v3149 == "tricorne" then
		local v3284 = p3148 * 0.92
		local v3285 = p3148 * 0.92
		local v3286 = Vector3.new(v3284, 0.55, v3285)
		local v3287 = p3146.trim
		local v3288, v3289 = CFrame.new(0, v3150 + 0.2, 0.02)
		local v3290 = v_u_27(p3146, "Crown", v3286, v3287, v3289)
		local v3291 = p3147.CFrame
		local v3292 = p3146.s
		v3290.CFrame = v3291 * (v3288.Rotation + v3288.Position * v3292)
		local v3293 = Instance.new("WeldConstraint")
		v3293.Part0 = p3147
		v3293.Part1 = v3290
		v3293.Parent = v3290
		for v3294 = 0, 2 do
			local v3295 = CFrame.new(0, v3150 + 0.15, 0.02) * CFrame.Angles(0, v3294 * 3.141592653589793 * 2 / 3, 0) * CFrame.new(0, 0.05, v3152 * 0.68) * CFrame.Angles(0.4, 0, 0)
			local v3296 = p3148 * 1.3
			local v3297 = Vector3.new(v3296, 0.42, 0.16)
			local v3298 = p3146.trim
			local v3299 = Instance.new("Part")
			v3299.Name = "Brim"
			v3299.Size = v3297 * p3146.s
			v3299.Color = v3298
			v3299.Material = Enum.Material.Plastic
			v3299.CanCollide = false
			v3299.CanTouch = false
			v3299.CanQuery = false
			v3299.Massless = true
			v3299.Anchored = false
			v3299.CastShadow = v3297.Magnitude > 1.1
			v3299.TopSurface = Enum.SurfaceType.Smooth
			v3299.BottomSurface = Enum.SurfaceType.Smooth
			v3299.Parent = p3146.model
			local v3300 = p3147.CFrame
			local v3301 = p3146.s
			v3299.CFrame = v3300 * (v3295.Rotation + v3295.Position * v3301)
			local v3302 = Instance.new("WeldConstraint")
			v3302.Part0 = p3147
			v3302.Part1 = v3299
			v3302.Parent = v3299
			local v3303 = p3148 * 1.32
			local v3304 = Vector3.new(v3303, 0.08, 0.18)
			local v3305 = p3146.accent
			local v3306 = v3295 * CFrame.new(0, 0.22, 0)
			local v3307 = v_u_27(p3146, "BrimEdge", v3304, v3305, v3154)
			local v3308 = p3147.CFrame
			local v3309 = p3146.s
			v3307.CFrame = v3308 * (v3306.Rotation + v3306.Position * v3309)
			local v3310 = Instance.new("WeldConstraint")
			v3310.Part0 = p3147
			v3310.Part1 = v3307
			v3310.Parent = v3307
		end
		local v3311 = p3146.glow
		local v3312 = CFrame.new(0, v3150 + 0.25, -p3148 * 0.46 - 0.05) * v_u_3145
		local v3313 = v_u_27(p3146, "Badge", Vector3.new(0.34, 0.34, 0.08), v3311, v3153)
		local v3314 = p3147.CFrame
		local v3315 = p3146.s
		v3313.CFrame = v3314 * (v3312.Rotation + v3312.Position * v3315)
		local v3316 = Instance.new("WeldConstraint")
		v3316.Part0 = p3147
		v3316.Part1 = v3313
		v3316.Parent = v3313
		return
	elseif v3149 == "eclipse" then
		local v3317 = CFrame.new(0, 0.15, p3148 / 2 + 0.25)
		local v3318 = p3148 * 0.95
		local v3319 = v3318 * 2
		local v3320 = v3318 * 2
		local v3321 = Vector3.new(0.18, v3319, v3320)
		local v3322 = Color3.fromRGB(12, 8, 14)
		local v3323 = v3317 * CFrame.Angles(0, 1.5707963267948966, 0)
		local v3324 = v_u_27(p3146, "Eclipse", v3321, v3322, {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v3325 = p3147.CFrame
		local v3326 = p3146.s
		v3324.CFrame = v3325 * (v3323.Rotation + v3323.Position * v3326)
		local v3327 = Instance.new("WeldConstraint")
		v3327.Part0 = p3147
		v3327.Part1 = v3324
		v3327.Parent = v3324
		for v3328 = 0, 11 do
			local v3329 = v3328 * 3.141592653589793 / 6
			local v3330 = v3318 * 2 * 0.25881904510252074 + 0.1
			local v3331 = Vector3.new(0.22, v3330, 0.12)
			local v3332 = p3146.glow
			local v3333 = v3317 * CFrame.new(math.cos(v3329) * v3318, math.sin(v3329) * v3318, 0.02) * CFrame.Angles(0, 0, v3329)
			local v3334 = v_u_27(p3146, "Corona", v3331, v3332, v3153)
			local v3335 = p3147.CFrame
			local v3336 = p3146.s
			v3334.CFrame = v3335 * (v3333.Rotation + v3333.Position * v3336)
			local v3337 = Instance.new("WeldConstraint")
			v3337.Part0 = p3147
			v3337.Part1 = v3334
			v3337.Parent = v3334
		end
		for v3338 = 0, 5 do
			local v3339 = v3338 * 3.141592653589793 / 3 + 0.5235987755982988
			local v3340 = v3338 % 2 == 0 and 1.5 or 0.9
			local v3341 = v3318 + v3340 / 2 + 0.1
			local v3342 = Vector3.new(0.16, v3340, 0.1)
			local v3343 = p3146.eye
			local v3344 = v3317 * CFrame.new(math.cos(v3339) * v3341, math.sin(v3339) * v3341, 0.03) * CFrame.Angles(0, 0, v3339 - 1.5707963267948966)
			local v3345 = v_u_27(p3146, "Flare", v3342, v3343, v3153)
			local v3346 = p3147.CFrame
			local v3347 = p3146.s
			v3345.CFrame = v3346 * (v3344.Rotation + v3344.Position * v3347)
			local v3348 = Instance.new("WeldConstraint")
			v3348.Part0 = p3147
			v3348.Part1 = v3345
			v3348.Parent = v3345
		end
		return
	elseif v3149 == "moontiara" then
		local v3349 = p3148 + 0.1
		local v3350 = p3148 + 0.1
		local v3351 = Vector3.new(v3349, 0.16, v3350)
		local v3352 = p3146.accent
		local v3353 = CFrame.new(0, p3148 * 0.32, 0)
		local v3354 = v_u_27(p3146, "Tiara", v3351, v3352, v3154)
		local v3355 = p3147.CFrame
		local v3356 = p3146.s
		v3354.CFrame = v3355 * (v3353.Rotation + v3353.Position * v3356)
		local v3357 = Instance.new("WeldConstraint")
		v3357.Part0 = p3147
		v3357.Part1 = v3354
		v3357.Parent = v3354
		for v3358 = -1, 1 do
			local v3359 = v3358 == 0 and 0.75 or 0.5
			local v3360 = CFrame.new(v3358 * 0.42 * v3152, p3148 * 0.32 + v3359 / 2, v3151 - 0.04) * CFrame.Angles(0, 0, -v3358 * 0.3)
			local v3361 = v_u_27(p3146, "TiaraPeak", Vector3.new(0.3, v3359, 0.1), p3146.accent, v3154)
			local v3362 = p3147.CFrame
			local v3363 = p3146.s
			v3361.CFrame = v3362 * (v3360.Rotation + v3360.Position * v3363)
			local v3364 = Instance.new("WeldConstraint")
			v3364.Part0 = p3147
			v3364.Part1 = v3361
			v3364.Parent = v3361
			local v3365 = p3146.glow
			local v3366 = v3360 * CFrame.new(0, -0.05, -0.06) * v_u_3145
			local v3367 = v_u_27(p3146, "TiaraGem", Vector3.new(0.18, 0.18, 0.06), v3365, v3153)
			local v3368 = p3147.CFrame
			local v3369 = p3146.s
			v3367.CFrame = v3368 * (v3366.Rotation + v3366.Position * v3369)
			local v3370 = Instance.new("WeldConstraint")
			v3370.Part0 = p3147
			v3370.Part1 = v3367
			v3370.Parent = v3367
		end
		local v3371 = CFrame.new(0, v3150 + v3152 * 1, 0.35)
		local v3372 = v3152 * 1.3
		local v3373 = Vector3.new(0.16, v3372, v3372)
		local v3374 = p3146.glow
		local v3375 = v3371 * CFrame.Angles(0, 1.5707963267948966, 0)
		local v3376 = v_u_27(p3146, "BloodMoon", v3373, v3374, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v3377 = p3147.CFrame
		local v3378 = p3146.s
		v3376.CFrame = v3377 * (v3375.Rotation + v3375.Position * v3378)
		local v3379 = Instance.new("WeldConstraint")
		v3379.Part0 = p3147
		v3379.Part1 = v3376
		v3379.Parent = v3376
		local v3380 = v3372 / 2 + 0.25
		for _, v3381 in { -1, 1 } do
			for v3382 = -1, 1 do
				local v3383 = (v3381 == 1 and 0 or 3.141592653589793) + v3382 * 0.65
				local v3384 = 0.2 - math.abs(v3382) * 0.06
				local v3385 = Vector3.new(v3384, 0.6, 0.12)
				local v3386 = p3146.accent
				local v3387 = v3371 * CFrame.new(math.cos(v3383) * v3380, math.sin(v3383) * v3380, 0) * CFrame.Angles(0, 0, v3383)
				local v3388 = v_u_27(p3146, "Crescent", v3385, v3386, v3154)
				local v3389 = p3147.CFrame
				local v3390 = p3146.s
				v3388.CFrame = v3389 * (v3387.Rotation + v3387.Position * v3390)
				local v3391 = Instance.new("WeldConstraint")
				v3391.Part0 = p3147
				v3391.Part1 = v3388
				v3391.Parent = v3388
			end
		end
		return
	elseif v3149 == "bloodcrown" then
		local v3392 = p3148 + 0.22
		local v3393 = p3148 + 0.22
		local v3394 = Vector3.new(v3392, 0.45, v3393)
		local v3395 = p3146.accent
		local v3396 = CFrame.new(0, v3150 + 0.1, 0)
		local v3397 = v_u_27(p3146, "CrownBand", v3394, v3395, v3154)
		local v3398 = p3147.CFrame
		local v3399 = p3146.s
		v3397.CFrame = v3398 * (v3396.Rotation + v3396.Position * v3399)
		local v3400 = Instance.new("WeldConstraint")
		v3400.Part0 = p3147
		v3400.Part1 = v3397
		v3400.Parent = v3397
		for v3401 = 0, 6 do
			local v3402 = v3401 * 3.141592653589793 * 2 / 7
			local v3403 = v3401 == 0 and 1.4 or (v3401 % 2 == 0 and 1 or 0.75)
			local v3404 = CFrame.new(0, v3150 + 0.3, 0) * CFrame.Angles(0, v3402, 0) * CFrame.new(0, 0, -(p3148 / 2 + 0.06))
			local v3405 = Vector3.new(0.3, v3403, 0.12)
			local v3406 = p3146.accent
			local v3407 = v3404 * CFrame.new(0, v3403 / 2, 0) * CFrame.Angles(-0.12, 0, 0)
			local v3408 = v_u_27(p3146, "CrownBlade", v3405, v3406, v3154)
			local v3409 = p3147.CFrame
			local v3410 = p3146.s
			v3408.CFrame = v3409 * (v3407.Rotation + v3407.Position * v3410)
			local v3411 = Instance.new("WeldConstraint")
			v3411.Part0 = p3147
			v3411.Part1 = v3408
			v3411.Parent = v3408
			local v3412 = p3146.glow
			local v3413 = v3404 * CFrame.new(0, -0.08, -0.08) * v_u_3145
			local v3414 = v_u_27(p3146, "CrownRuby", Vector3.new(0.2, 0.2, 0.08), v3412, v3153)
			local v3415 = p3147.CFrame
			local v3416 = p3146.s
			v3414.CFrame = v3415 * (v3413.Rotation + v3413.Position * v3416)
			local v3417 = Instance.new("WeldConstraint")
			v3417.Part0 = p3147
			v3417.Part1 = v3414
			v3417.Parent = v3414
		end
		for _, v3418 in { -1, 1 } do
			local v3419 = p3146.trim
			local v3420 = CFrame.new(v3418 * (p3148 / 2 + 0.22), v3150 + 0.4, 0.15) * CFrame.Angles(0.3, 0, -v3418 * 0.5)
			local v3421 = Instance.new("Part")
			v3421.Name = "CrownWing"
			v3421.Size = Vector3.new(0.1, 0.8, 1.05) * p3146.s
			v3421.Color = v3419
			v3421.Material = Enum.Material.Plastic
			v3421.CanCollide = false
			v3421.CanTouch = false
			v3421.CanQuery = false
			v3421.Massless = true
			v3421.Anchored = false
			v3421.CastShadow = (Vector3.new(0.1, 0.8, 1.05)).Magnitude > 1.1
			v3421.TopSurface = Enum.SurfaceType.Smooth
			v3421.BottomSurface = Enum.SurfaceType.Smooth
			v3421.Parent = p3146.model
			local v3422 = p3147.CFrame
			local v3423 = p3146.s
			v3421.CFrame = v3422 * (v3420.Rotation + v3420.Position * v3423)
			local v3424 = Instance.new("WeldConstraint")
			v3424.Part0 = p3147
			v3424.Part1 = v3421
			v3424.Parent = v3421
		end
		local v3425 = p3146.glow
		local v3426 = CFrame.new(0, v3150 + 0.12, v3151 - 0.18) * v_u_3145
		local v3427 = v_u_27(p3146, "GreatRuby", Vector3.new(0.42, 0.42, 0.1), v3425, v3153)
		local v3428 = p3147.CFrame
		local v3429 = p3146.s
		v3427.CFrame = v3428 * (v3426.Rotation + v3426.Position * v3429)
		local v3430 = Instance.new("WeldConstraint")
		v3430.Part0 = p3147
		v3430.Part1 = v3427
		v3430.Parent = v3427
		return
	elseif v3149 == "snowcrown" then
		local v3431 = p3148 + 0.14
		local v3432 = p3148 + 0.14
		local v3433 = Vector3.new(v3431, 0.3, v3432)
		local v3434 = p3146.accent
		local v3435 = CFrame.new(0, v3150 + 0.05, 0)
		local v3436 = v_u_27(p3146, "CrownBand", v3433, v3434, v3154)
		local v3437 = p3147.CFrame
		local v3438 = p3146.s
		v3436.CFrame = v3437 * (v3435.Rotation + v3435.Position * v3438)
		local v3439 = Instance.new("WeldConstraint")
		v3439.Part0 = p3147
		v3439.Part1 = v3436
		v3439.Parent = v3436
		for v3440 = 0, 7 do
			local v3441 = v3440 % 2 == 0 and 1.35 or 0.8
			local v3442 = v3440 % 2 == 0
			local v3443 = Vector3.new(0.3, v3441, 0.3)
			local v3444
			if v3442 then
				v3444 = p3146.glow
			else
				v3444 = v_u_3142
			end
			local v3445 = CFrame.new(0, v3150 + 0.15, 0) * CFrame.Angles(0, v3440 * 3.141592653589793 / 4, 0) * CFrame.new(0, v3441 / 2, -(p3148 / 2 + 0.02)) * CFrame.Angles(-0.2, 0, 0) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v3446
			if v3442 then
				v3446 = v3153
			else
				v3446 = v3156
			end
			local v3447 = v_u_27(p3146, "IceShard", v3443, v3444, v3446)
			local v3448 = p3147.CFrame
			local v3449 = p3146.s
			v3447.CFrame = v3448 * (v3445.Rotation + v3445.Position * v3449)
			local v3450 = Instance.new("WeldConstraint")
			v3450.Part0 = p3147
			v3450.Part1 = v3447
			v3450.Parent = v3447
		end
		local v3451 = CFrame.new(0, v3150 + 0.1, v3151 - 0.22)
		for v3452 = 0, 2 do
			local v3453 = p3146.eye
			local v3454 = v3451 * CFrame.Angles(0, 0, v3452 * 3.141592653589793 / 3)
			local v3455 = v_u_27(p3146, "Flake", Vector3.new(0.1, 0.8, 0.06), v3453, v3153)
			local v3456 = p3147.CFrame
			local v3457 = p3146.s
			v3455.CFrame = v3456 * (v3454.Rotation + v3454.Position * v3457)
			local v3458 = Instance.new("WeldConstraint")
			v3458.Part0 = p3147
			v3458.Part1 = v3455
			v3458.Parent = v3455
		end
		return
	elseif v3149 == "glacier" then
		local v3459 = p3148 + 0.25
		local v3460 = p3148 + 0.25
		local v3461 = Vector3.new(v3459, 0.32, v3460)
		local v3462 = v_u_3143
		local v3463 = CFrame.new(0, v3150 + 0.05, 0)
		local v3464 = v_u_27(p3146, "Snowcap", v3461, v3462, {
			["material"] = Enum.Material.Snow
		})
		local v3465 = p3147.CFrame
		local v3466 = p3146.s
		v3464.CFrame = v3465 * (v3463.Rotation + v3463.Position * v3466)
		local v3467 = Instance.new("WeldConstraint")
		v3467.Part0 = p3147
		v3467.Part1 = v3464
		v3467.Parent = v3464
		for v3468, v3469 in {
			{
				0,
				2.1,
				0,
				0
			},
			{
				0.6,
				1.5,
				-0.25,
				-0.3
			},
			{
				-0.6,
				1.6,
				0.2,
				0.25
			},
			{
				0.35,
				1.1,
				-0.6,
				0.45
			},
			{
				-0.4,
				1,
				0.65,
				-0.4
			}
		} do
			local v3470 = v3469[2]
			local v3471 = Vector3.new(0.62, v3470, 0.62) * v3152
			local v3472
			if v3468 == 1 then
				v3472 = p3146.glow
			else
				v3472 = v_u_3142
			end
			local v3473 = CFrame.new(v3469[1] * v3152, v3150 + v3469[2] * v3152 * 0.42, v3469[4] * v3152) * CFrame.Angles(0, 0, v3469[3]) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v3474
			if v3468 == 1 then
				v3474 = v3153
			else
				v3474 = v3156
			end
			local v3475 = v_u_27(p3146, "Peak", v3471, v3472, v3474)
			local v3476 = p3147.CFrame
			local v3477 = p3146.s
			v3475.CFrame = v3476 * (v3473.Rotation + v3473.Position * v3477)
			local v3478 = Instance.new("WeldConstraint")
			v3478.Part0 = p3147
			v3478.Part1 = v3475
			v3478.Parent = v3475
		end
		for _, v3479 in { -1, 1 } do
			local v3480 = Vector3.new(0.28, 0.8, 0.28) * v3152
			local v3481 = p3146.glow
			local v3482 = CFrame.new(v3479 * 0.3 * v3152, v3150 + v3152 * 0.35, -0.2 * v3479) * CFrame.Angles(0, 0, -v3479 * 0.35)
			local v3483 = v_u_27(p3146, "InnerShard", v3480, v3481, v3153)
			local v3484 = p3147.CFrame
			local v3485 = p3146.s
			v3483.CFrame = v3484 * (v3482.Rotation + v3482.Position * v3485)
			local v3486 = Instance.new("WeldConstraint")
			v3486.Part0 = p3147
			v3486.Part1 = v3483
			v3486.Parent = v3483
		end
		return
	elseif v3149 == "pine" then
		for v3487, v3488 in {
			{ 2.3, 0 },
			{ 1.75, 0.5 },
			{ 1.2, 0.95 },
			{ 0.65, 1.35 }
		} do
			local v3489 = CFrame.new(0, v3150 + 0.2 + v3488[2] * v3152, 0.05) * CFrame.Angles(0, v3487 % 2 * 3.141592653589793 / 4, 0)
			local v3490 = v3488[1] * v3152
			local v3491 = v3152 * 0.5
			local v3492 = v3488[1] * v3152
			local v3493 = Vector3.new(v3490, v3491, v3492)
			local v3494 = p3146.trim
			local v3495 = Instance.new("Part")
			v3495.Name = "Needles"
			v3495.Size = v3493 * p3146.s
			v3495.Color = v3494
			v3495.Material = Enum.Material.Plastic
			v3495.CanCollide = false
			v3495.CanTouch = false
			v3495.CanQuery = false
			v3495.Massless = true
			v3495.Anchored = false
			v3495.CastShadow = v3493.Magnitude > 1.1
			v3495.TopSurface = Enum.SurfaceType.Smooth
			v3495.BottomSurface = Enum.SurfaceType.Smooth
			v3495.Parent = p3146.model
			local v3496 = p3147.CFrame
			local v3497 = p3146.s
			v3495.CFrame = v3496 * (v3489.Rotation + v3489.Position * v3497)
			local v3498 = Instance.new("WeldConstraint")
			v3498.Part0 = p3147
			v3498.Part1 = v3495
			v3498.Parent = v3495
			local v3499 = v3488[1] * 0.8 * v3152
			local v3500 = v3488[1] * 0.8 * v3152
			local v3501 = Vector3.new(v3499, 0.12, v3500)
			local v3502 = v_u_3143
			local v3503 = v3489 * CFrame.new(0, v3152 * 0.28, 0)
			local v3504 = v_u_27(p3146, "Snow", v3501, v3502, {
				["material"] = Enum.Material.Snow
			})
			local v3505 = p3147.CFrame
			local v3506 = p3146.s
			v3504.CFrame = v3505 * (v3503.Rotation + v3503.Position * v3506)
			local v3507 = Instance.new("WeldConstraint")
			v3507.Part0 = p3147
			v3507.Part1 = v3504
			v3507.Parent = v3504
		end
		for _, v3508 in {
			{ 1.15, 0, 0 },
			{ -0.8, 0, 0.8 },
			{ 0.62, 0.5, -0.62 },
			{ -0.85, 0.5, 0 },
			{ 0, 0.95, 0.6 }
		} do
			local v3509 = p3146.glow
			local v3510 = CFrame.new(v3508[1] * v3152, v3150 + 0.12 + v3508[2] * v3152, v3508[3] * v3152 + 0.05)
			local v3511 = v_u_27(p3146, "Bauble", Vector3.new(0.3, 0.3, 0.3), v3509, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v3512 = p3147.CFrame
			local v3513 = p3146.s
			v3511.CFrame = v3512 * (v3510.Rotation + v3510.Position * v3513)
			local v3514 = Instance.new("WeldConstraint")
			v3514.Part0 = p3147
			v3514.Part1 = v3511
			v3514.Parent = v3511
		end
		local v3515 = p3146.eye
		local v3516 = CFrame.new(0, v3150 + v3152 * 1.9, 0.05) * v_u_3145
		local v3517 = v_u_27(p3146, "TreeStar", Vector3.new(0.42, 0.42, 0.14), v3515, v3153)
		local v3518 = p3147.CFrame
		local v3519 = p3146.s
		v3517.CFrame = v3518 * (v3516.Rotation + v3516.Position * v3519)
		local v3520 = Instance.new("WeldConstraint")
		v3520.Part0 = p3147
		v3520.Part1 = v3517
		v3520.Parent = v3517
		return
	elseif v3149 == "abysscrown" then
		local v3521 = p3148 + 0.18
		local v3522 = p3148 + 0.18
		local v3523 = Vector3.new(v3521, 0.38, v3522)
		local v3524 = p3146.trim
		local v3525 = CFrame.new(0, v3150 + 0.08, 0)
		local v3526 = v_u_27(p3146, "CrownBand", v3523, v3524, v3154)
		local v3527 = p3147.CFrame
		local v3528 = p3146.s
		v3526.CFrame = v3527 * (v3525.Rotation + v3525.Position * v3528)
		local v3529 = Instance.new("WeldConstraint")
		v3529.Part0 = p3147
		v3529.Part1 = v3526
		v3529.Parent = v3526
		for v3530 = 0, 6 do
			local v3531 = (v3530 - 3) * 0.5
			local v3532 = v3530 == 3 and 1.9 or ((v3530 == 2 or v3530 == 4) and 1.4 or 1)
			local v3533 = CFrame.new(0, v3150 + 0.25, 0) * CFrame.Angles(0, v3531, 0) * CFrame.new(0, 0, -(p3148 / 2 + 0.02))
			local v3534 = Vector3.new(0.18, v3532, 0.18)
			local v3535 = p3146.glow
			local v3536 = v3533 * CFrame.Angles(-0.15, 0, 0) * CFrame.new(0, v3532 / 2, 0) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v3537 = v_u_27(p3146, "Spire", v3534, v3535, v3153)
			local v3538 = p3147.CFrame
			local v3539 = p3146.s
			v3537.CFrame = v3538 * (v3536.Rotation + v3536.Position * v3539)
			local v3540 = Instance.new("WeldConstraint")
			v3540.Part0 = p3147
			v3540.Part1 = v3537
			v3540.Parent = v3537
			local v3541 = v_u_27(p3146, "Pearl", Vector3.new(0.3, 0.3, 0.3), p3146.accent, {
				["shape"] = Enum.PartType.Ball,
				["material"] = Enum.Material.SmoothPlastic
			})
			local v3542 = p3147.CFrame
			local v3543 = p3146.s
			v3541.CFrame = v3542 * (v3533.Rotation + v3533.Position * v3543)
			local v3544 = Instance.new("WeldConstraint")
			v3544.Part0 = p3147
			v3544.Part1 = v3541
			v3544.Parent = v3541
		end
		local v3545 = v_u_13
		local v3546 = CFrame.new(0, v3150 + 0.1, v3151 - 0.25)
		local v3547 = v_u_27(p3146, "GreatPearl", Vector3.new(0.52, 0.52, 0.52), v3545, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v3548 = p3147.CFrame
		local v3549 = p3146.s
		v3547.CFrame = v3548 * (v3546.Rotation + v3546.Position * v3549)
		local v3550 = Instance.new("WeldConstraint")
		v3550.Part0 = p3147
		v3550.Part1 = v3547
		v3550.Parent = v3547
		return
	elseif v3149 == "cobra" then
		local v3551 = p3148 * 1.5
		local v3552 = p3148 * 1.45
		local v3553 = Vector3.new(v3551, v3552, 0.2)
		local v3554 = p3146.shirt
		local v3555, v3556 = CFrame.new(0, p3148 * 0.1, p3148 / 2 + 0.12)
		local v3557 = v_u_27(p3146, "HoodBack", v3553, v3554, v3556)
		local v3558 = p3147.CFrame
		local v3559 = p3146.s
		v3557.CFrame = v3558 * (v3555.Rotation + v3555.Position * v3559)
		local v3560 = Instance.new("WeldConstraint")
		v3560.Part0 = p3147
		v3560.Part1 = v3557
		v3560.Parent = v3557
		for _, v3561 in { -1, 1 } do
			local v3562 = v3152 * 0.9
			local v3563 = p3148 * 1.35
			local v3564 = Vector3.new(v3562, v3563, 0.18)
			local v3565 = p3146.shirt
			local v3566 = CFrame.new(v3561 * (p3148 / 2 + v3152 * 0.35), p3148 * 0.1, 0.15) * CFrame.Angles(0, v3561 * 0.75, 0)
			local v3567 = Instance.new("Part")
			v3567.Name = "HoodSide"
			v3567.Size = v3564 * p3146.s
			v3567.Color = v3565
			v3567.Material = Enum.Material.Plastic
			v3567.CanCollide = false
			v3567.CanTouch = false
			v3567.CanQuery = false
			v3567.Massless = true
			v3567.Anchored = false
			v3567.CastShadow = v3564.Magnitude > 1.1
			v3567.TopSurface = Enum.SurfaceType.Smooth
			v3567.BottomSurface = Enum.SurfaceType.Smooth
			v3567.Parent = p3146.model
			local v3568 = p3147.CFrame
			local v3569 = p3146.s
			v3567.CFrame = v3568 * (v3566.Rotation + v3566.Position * v3569)
			local v3570 = Instance.new("WeldConstraint")
			v3570.Part0 = p3147
			v3570.Part1 = v3567
			v3570.Parent = v3567
			local v3571 = p3146.glow
			local v3572 = CFrame.new(0, 0.25, -0.1) * v_u_3145
			local v3573 = v_u_27(p3146, "HoodMark", Vector3.new(0.3, 0.5, 0.06), v3571, v3153)
			local v3574 = v3567.CFrame
			local v3575 = p3146.s
			v3573.CFrame = v3574 * (v3572.Rotation + v3572.Position * v3575)
			local v3576 = Instance.new("WeldConstraint")
			v3576.Part0 = v3567
			v3576.Part1 = v3573
			v3576.Parent = v3573
			local v3577 = p3146.glow
			local v3578 = CFrame.new(0, -0.35, -0.1) * v_u_3145
			local v3579 = v_u_27(p3146, "HoodMark", Vector3.new(0.2, 0.2, 0.06), v3577, v3153)
			local v3580 = v3567.CFrame
			local v3581 = p3146.s
			v3579.CFrame = v3580 * (v3578.Rotation + v3578.Position * v3581)
			local v3582 = Instance.new("WeldConstraint")
			v3582.Part0 = v3567
			v3582.Part1 = v3579
			v3582.Parent = v3579
		end
		local v3583 = p3148 + 0.2
		local v3584 = p3148 * 0.8
		local v3585 = Vector3.new(v3583, 0.25, v3584)
		local v3586 = p3146.shirt
		local v3587, v3588 = CFrame.new(0, v3150 + 0.08, 0.25)
		local v3589 = v_u_27(p3146, "HoodTop", v3585, v3586, v3588)
		local v3590 = p3147.CFrame
		local v3591 = p3146.s
		v3589.CFrame = v3590 * (v3587.Rotation + v3587.Position * v3591)
		local v3592 = Instance.new("WeldConstraint")
		v3592.Part0 = p3147
		v3592.Part1 = v3589
		v3592.Parent = v3589
		local v3593 = p3148 + 0.08
		local v3594 = p3148 + 0.08
		local v3595 = Vector3.new(v3593, 0.16, v3594)
		local v3596 = p3146.accent
		local v3597 = CFrame.new(0, p3148 * 0.3, 0)
		local v3598 = v_u_27(p3146, "Band", v3595, v3596, v3154)
		local v3599 = p3147.CFrame
		local v3600 = p3146.s
		v3598.CFrame = v3599 * (v3597.Rotation + v3597.Position * v3600)
		local v3601 = Instance.new("WeldConstraint")
		v3601.Part0 = p3147
		v3601.Part1 = v3598
		v3601.Parent = v3598
		local v3602 = p3146.glow
		local v3603 = CFrame.new(0, p3148 * 0.3, v3151 - 0.08) * v_u_3145
		local v3604 = v_u_27(p3146, "BandGem", Vector3.new(0.26, 0.26, 0.08), v3602, v3153)
		local v3605 = p3147.CFrame
		local v3606 = p3146.s
		v3604.CFrame = v3605 * (v3603.Rotation + v3603.Position * v3606)
		local v3607 = Instance.new("WeldConstraint")
		v3607.Part0 = p3147
		v3607.Part1 = v3604
		v3607.Parent = v3604
		return
	elseif v3149 == "demonhorns" then
		local v3608 = Color3.fromRGB(30, 22, 26)
		for _, v3609 in { -1, 1 } do
			local v3610 = Vector3.new(0.46, 0.8, 0.46) * v3152
			local v3611 = CFrame.new(v3609 * 0.45 * v3152, v3150 + 0.2, -0.05) * CFrame.Angles(0, 0, -v3609 * 0.55)
			local v3612 = Instance.new("Part")
			v3612.Name = "Horn"
			v3612.Size = v3610 * p3146.s
			v3612.Color = v3608
			v3612.Material = Enum.Material.Plastic
			v3612.CanCollide = false
			v3612.CanTouch = false
			v3612.CanQuery = false
			v3612.Massless = true
			v3612.Anchored = false
			v3612.CastShadow = v3610.Magnitude > 1.1
			v3612.TopSurface = Enum.SurfaceType.Smooth
			v3612.BottomSurface = Enum.SurfaceType.Smooth
			v3612.Parent = p3146.model
			local v3613 = p3147.CFrame
			local v3614 = p3146.s
			v3612.CFrame = v3613 * (v3611.Rotation + v3611.Position * v3614)
			local v3615 = Instance.new("WeldConstraint")
			v3615.Part0 = p3147
			v3615.Part1 = v3612
			v3615.Parent = v3612
			local v3616 = Vector3.new(0.36, 0.75, 0.36) * v3152
			local v3617 = CFrame.new(0, v3152 * 0.62, 0) * CFrame.Angles(-0.35, 0, v3609 * 0.45)
			local v3618 = Instance.new("Part")
			v3618.Name = "Horn"
			v3618.Size = v3616 * p3146.s
			v3618.Color = v3608
			v3618.Material = Enum.Material.Plastic
			v3618.CanCollide = false
			v3618.CanTouch = false
			v3618.CanQuery = false
			v3618.Massless = true
			v3618.Anchored = false
			v3618.CastShadow = v3616.Magnitude > 1.1
			v3618.TopSurface = Enum.SurfaceType.Smooth
			v3618.BottomSurface = Enum.SurfaceType.Smooth
			v3618.Parent = p3146.model
			local v3619 = v3612.CFrame
			local v3620 = p3146.s
			v3618.CFrame = v3619 * (v3617.Rotation + v3617.Position * v3620)
			local v3621 = Instance.new("WeldConstraint")
			v3621.Part0 = v3612
			v3621.Part1 = v3618
			v3621.Parent = v3618
			local v3622 = Vector3.new(0.24, 0.62, 0.24) * v3152
			local v3623 = p3146.glow
			local v3624 = CFrame.new(0, v3152 * 0.6, 0) * CFrame.Angles(-0.4, 0, v3609 * 0.35)
			local v3625 = v_u_27(p3146, "HornTip", v3622, v3623, v3153)
			local v3626 = v3618.CFrame
			local v3627 = p3146.s
			v3625.CFrame = v3626 * (v3624.Rotation + v3624.Position * v3627)
			local v3628 = Instance.new("WeldConstraint")
			v3628.Part0 = v3618
			v3628.Part1 = v3625
			v3628.Parent = v3625
			local v3629 = Vector3.new(0.52, 0.12, 0.52) * v3152
			local v3630 = p3146.glow
			local v3631 = CFrame.new(0, v3152 * 0.12, 0)
			local v3632 = v_u_27(p3146, "HornBand", v3629, v3630, v3153)
			local v3633 = v3612.CFrame
			local v3634 = p3146.s
			v3632.CFrame = v3633 * (v3631.Rotation + v3631.Position * v3634)
			local v3635 = Instance.new("WeldConstraint")
			v3635.Part0 = v3612
			v3635.Part1 = v3632
			v3635.Parent = v3632
		end
		local v3636 = p3148 + 0.3
		local v3637 = p3148 * 0.95
		local v3638 = Vector3.new(v3636, v3637, 0.5)
		local v3639 = p3146.trim
		local v3640, v3641 = CFrame.new(0, p3148 * -0.05, p3148 / 2 + 0.22)
		local v3642 = v_u_27(p3146, "Mane", v3638, v3639, v3641)
		local v3643 = p3147.CFrame
		local v3644 = p3146.s
		v3642.CFrame = v3643 * (v3640.Rotation + v3640.Position * v3644)
		local v3645 = Instance.new("WeldConstraint")
		v3645.Part0 = p3147
		v3645.Part1 = v3642
		v3645.Parent = v3642
		for v3646, v3647 in { -0.45, 0, 0.45 } do
			local v3648 = v3646 == 2 and 1.3 or 1
			local v3649 = Vector3.new(0.45, v3648, 0.4) * v3152
			local v3650 = p3146.trim
			local v3651 = CFrame.new(v3647 * v3152, v3150 - 0.05, p3148 / 2 + 0.25) * CFrame.Angles(0.7, 0, -v3647 * 0.6) * CFrame.new(0, v3152 * 0.45, 0)
			local v3652 = Instance.new("Part")
			v3652.Name = "ManeSpike"
			v3652.Size = v3649 * p3146.s
			v3652.Color = v3650
			v3652.Material = Enum.Material.Plastic
			v3652.CanCollide = false
			v3652.CanTouch = false
			v3652.CanQuery = false
			v3652.Massless = true
			v3652.Anchored = false
			v3652.CastShadow = v3649.Magnitude > 1.1
			v3652.TopSurface = Enum.SurfaceType.Smooth
			v3652.BottomSurface = Enum.SurfaceType.Smooth
			v3652.Parent = p3146.model
			local v3653 = p3147.CFrame
			local v3654 = p3146.s
			v3652.CFrame = v3653 * (v3651.Rotation + v3651.Position * v3654)
			local v3655 = Instance.new("WeldConstraint")
			v3655.Part0 = p3147
			v3655.Part1 = v3652
			v3655.Parent = v3652
		end
	elseif v3149 == "knighthelm" then
		local v3656 = p3148 + 0.3
		local v3657 = p3148 + 0.35
		local v3658 = p3148 + 0.3
		local v3659 = Vector3.new(v3656, v3657, v3658)
		local v3660 = p3146.accent
		local v3661 = CFrame.new(0, 0.05, 0)
		local v3662 = v_u_27(p3146, "GreatHelm", v3659, v3660, v3154)
		local v3663 = p3147.CFrame
		local v3664 = p3146.s
		v3662.CFrame = v3663 * (v3661.Rotation + v3661.Position * v3664)
		local v3665 = Instance.new("WeldConstraint")
		v3665.Part0 = p3147
		v3665.Part1 = v3662
		v3665.Parent = v3662
		local v3666 = p3148 * 0.78
		local v3667 = Vector3.new(v3666, 0.13, 0.06)
		local v3668 = p3146.eye
		local v3669 = CFrame.new(0, p3148 * 0.1, v3151 - 0.18)
		local v3670 = v_u_27(p3146, "Slit", v3667, v3668, v3153)
		local v3671 = p3147.CFrame
		local v3672 = p3146.s
		v3670.CFrame = v3671 * (v3669.Rotation + v3669.Position * v3672)
		local v3673 = Instance.new("WeldConstraint")
		v3673.Part0 = p3147
		v3673.Part1 = v3670
		v3673.Parent = v3670
		local v3674 = p3148 * 0.42
		local v3675 = Vector3.new(0.13, v3674, 0.06)
		local v3676 = p3146.eye
		local v3677 = CFrame.new(0, -0.14 * p3148, v3151 - 0.18)
		local v3678 = v_u_27(p3146, "SlitDown", v3675, v3676, v3153)
		local v3679 = p3147.CFrame
		local v3680 = p3146.s
		v3678.CFrame = v3679 * (v3677.Rotation + v3677.Position * v3680)
		local v3681 = Instance.new("WeldConstraint")
		v3681.Part0 = p3147
		v3681.Part1 = v3678
		v3681.Parent = v3678
		local v3682 = p3148 + 0.5
		local v3683 = Vector3.new(0.2, 0.7, v3682)
		local v3684 = p3146.trim
		local v3685 = CFrame.new(0, v3150 + 0.5, 0.1)
		local v3686 = v_u_27(p3146, "Crest", v3683, v3684, {
			["material"] = Enum.Material.Fabric
		})
		local v3687 = p3147.CFrame
		local v3688 = p3146.s
		v3686.CFrame = v3687 * (v3685.Rotation + v3685.Position * v3688)
		local v3689 = Instance.new("WeldConstraint")
		v3689.Part0 = p3147
		v3689.Part1 = v3686
		v3689.Parent = v3686
		local v3690 = p3148 + 0.5
		local v3691 = Vector3.new(0.24, 0.1, v3690)
		local v3692 = p3146.glow
		local v3693 = CFrame.new(0, v3150 + 0.86, 0.1)
		local v3694 = v_u_27(p3146, "CrestEdge", v3691, v3692, v3153)
		local v3695 = p3147.CFrame
		local v3696 = p3146.s
		v3694.CFrame = v3695 * (v3693.Rotation + v3693.Position * v3696)
		local v3697 = Instance.new("WeldConstraint")
		v3697.Part0 = p3147
		v3697.Part1 = v3694
		v3697.Parent = v3694
		for _, v3698 in { -1, 1 } do
			local v3699 = p3146.accent
			local v3700 = CFrame.new(v3698 * (p3148 / 2 + 0.2), 0.15, 0.1) * CFrame.Angles(0.35, 0, -v3698 * 0.3)
			local v3701 = v_u_27(p3146, "Flare", Vector3.new(0.12, 0.85, 0.7), v3699, v3154)
			local v3702 = p3147.CFrame
			local v3703 = p3146.s
			v3701.CFrame = v3702 * (v3700.Rotation + v3700.Position * v3703)
			local v3704 = Instance.new("WeldConstraint")
			v3704.Part0 = p3147
			v3704.Part1 = v3701
			v3704.Parent = v3701
		end
	end
end
local function v_u_4046(p3706, p3707) -- name: weapon3
	-- upvalues: (copy) v_u_27, (copy) v_u_9, (copy) v_u_8, (copy) v_u_57, (copy) v_u_7, (copy) v_u_68, (copy) v_u_3145, (copy) v_u_3142
	local v3708 = p3706.look.weapon or "none"
	local v3709 = p3707.rightArmPart
	local v3710 = p3707.leftArmPart
	if v3709 and v3710 then
		local v3711 = p3707.d.arm
		local v3712 = CFrame.new(0, -v3711.Y / 2 + 0.25, 0) * CFrame.Angles(0, -0.3, 0)
		local v3713 = CFrame.new(0, -v3711.Y / 2 + 0.25, 0) * CFrame.Angles(0, 0.3, 0)
		local v3714 = {
			["neon"] = true
		}
		local v3715 = {
			["material"] = Enum.Material.Metal
		}
		if v3708 == "kama" then
			local v3716 = v_u_9
			local v3717, v3718 = CFrame.new(0, 0, -0.3)
			local v3719 = v3712 * v3717
			local v3720 = v_u_27(p3706, "Grip", Vector3.new(0.2, 0.2, 1), v3716, v3718)
			local v3721 = v3709.CFrame
			local v3722 = p3706.s
			v3720.CFrame = v3721 * (v3719.Rotation + v3719.Position * v3722)
			local v3723 = Instance.new("WeldConstraint")
			v3723.Part0 = v3709
			v3723.Part1 = v3720
			v3723.Parent = v3720
			local v3724 = v_u_8
			local v3725 = v3712 * CFrame.new(0, 0.45, -0.9)
			local v3726 = v_u_27(p3706, "Sickle", Vector3.new(0.08, 1, 0.3), v3724, v3715)
			local v3727 = v3709.CFrame
			local v3728 = p3706.s
			v3726.CFrame = v3727 * (v3725.Rotation + v3725.Position * v3728)
			local v3729 = Instance.new("WeldConstraint")
			v3729.Part0 = v3709
			v3729.Part1 = v3726
			v3729.Parent = v3726
			local v3730 = p3706.glow
			local v3731 = CFrame.new(0, 0, 0.16)
			local v3732 = v_u_27(p3706, "Edge", Vector3.new(0.06, 0.95, 0.1), v3730, v3714)
			local v3733 = v3726.CFrame
			local v3734 = p3706.s
			v3732.CFrame = v3733 * (v3731.Rotation + v3731.Position * v3734)
			local v3735 = Instance.new("WeldConstraint")
			v3735.Part0 = v3726
			v3735.Part1 = v3732
			v3735.Parent = v3732
			local v3736 = v_u_8
			local v3737 = v3712 * (CFrame.new(0, 1.05, -0.65) * CFrame.Angles(-0.9, 0, 0))
			local v3738 = v_u_27(p3706, "SickleTip", Vector3.new(0.08, 0.6, 0.24), v3736, v3715)
			local v3739 = v3709.CFrame
			local v3740 = p3706.s
			v3738.CFrame = v3739 * (v3737.Rotation + v3737.Position * v3740)
			local v3741 = Instance.new("WeldConstraint")
			v3741.Part0 = v3709
			v3741.Part1 = v3738
			v3741.Parent = v3738
			local v3742 = v_u_57(p3706, v3709, "Chain", Vector3.new(0.12, 1.8, 0.12), v_u_7, v3712 * CFrame.new(0, -0.05, 0.25), CFrame.new(0, 0.9, 0), Vector3.new(1, 0, 0), 0.35, 6, 0.3, v3715)
			local v3743 = p3706.glow
			local v3744 = CFrame.new(0, -1, 0) * CFrame.Angles(0.7853981633974483, 0.7853981633974483, 0)
			local v3745 = v_u_27(p3706, "Weight", Vector3.new(0.4, 0.4, 0.4), v3743, v3714)
			local v3746 = v3742.CFrame
			local v3747 = p3706.s
			v3745.CFrame = v3746 * (v3744.Rotation + v3744.Position * v3747)
			local v3748 = Instance.new("WeldConstraint")
			v3748.Part0 = v3742
			v3748.Part1 = v3745
			v3748.Parent = v3745
			v_u_68(p3706, v3726, Vector3.new(0, 0.5, 0), Vector3.new(0, -0.4, 0), 0.14, 0.3)
			return
		elseif v3708 == "shakujo" then
			local v3749 = Color3.fromRGB(64, 42, 30)
			local v3750, v3751 = CFrame.new(0, 1.4, -0.35)
			local v3752 = v3712 * v3750
			local v3753 = v_u_27(p3706, "Staff", Vector3.new(0.24, 5.4, 0.24), v3749, v3751)
			local v3754 = v3709.CFrame
			local v3755 = p3706.s
			v3753.CFrame = v3754 * (v3752.Rotation + v3752.Position * v3755)
			local v3756 = Instance.new("WeldConstraint")
			v3756.Part0 = v3709
			v3756.Part1 = v3753
			v3756.Parent = v3753
			local v3757 = CFrame.new(0, 4.65, -0.35)
			for v3758 = 0, 7 do
				local v3759 = v3758 * 3.141592653589793 / 4
				local v3760 = p3706.accent
				local v3761 = v3712 * (v3757 * CFrame.new(math.cos(v3759) * 0.5, math.sin(v3759) * 0.62, 0) * CFrame.Angles(0, 0, v3759))
				local v3762 = v_u_27(p3706, "Loop", Vector3.new(0.14, 0.46, 0.14), v3760, v3715)
				local v3763 = v3709.CFrame
				local v3764 = p3706.s
				v3762.CFrame = v3763 * (v3761.Rotation + v3761.Position * v3764)
				local v3765 = Instance.new("WeldConstraint")
				v3765.Part0 = v3709
				v3765.Part1 = v3762
				v3765.Parent = v3762
			end
			local v3766 = p3706.glow
			local v3767 = v3712 * (v3757 * CFrame.new(0, 0.9, 0) * CFrame.Angles(0, 0.7853981633974483, 0))
			local v3768 = v_u_27(p3706, "LoopSpike", Vector3.new(0.18, 0.6, 0.18), v3766, v3714)
			local v3769 = v3709.CFrame
			local v3770 = p3706.s
			v3768.CFrame = v3769 * (v3767.Rotation + v3767.Position * v3770)
			local v3771 = Instance.new("WeldConstraint")
			v3771.Part0 = v3709
			v3771.Part1 = v3768
			v3771.Parent = v3768
			local v3772 = p3706.glow
			local v3773 = {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			}
			local v3774 = v3712 * v3757
			local v3775 = v_u_27(p3706, "CurseOrb", Vector3.new(0.42, 0.42, 0.42), v3772, v3773)
			local v3776 = v3709.CFrame
			local v3777 = p3706.s
			v3775.CFrame = v3776 * (v3774.Rotation + v3774.Position * v3777)
			local v3778 = Instance.new("WeldConstraint")
			v3778.Part0 = v3709
			v3778.Part1 = v3775
			v3778.Parent = v3775
			for _, v3779 in { -1, 1 } do
				for v3780 = 0, 1 do
					local v3781 = p3706.accent
					local v3782 = v3757 * CFrame.new(v3779 * 0.5, -0.05 - v3780 * 0.32, 0)
					local v3783 = {
						["material"] = Enum.Material.Metal,
						["shape"] = Enum.PartType.Cylinder
					}
					local v3784 = v3712 * v3782
					local v3785 = v_u_27(p3706, "Ring", Vector3.new(0.06, 0.34, 0.34), v3781, v3783)
					local v3786 = v3709.CFrame
					local v3787 = p3706.s
					v3785.CFrame = v3786 * (v3784.Rotation + v3784.Position * v3787)
					local v3788 = Instance.new("WeldConstraint")
					v3788.Part0 = v3709
					v3788.Part1 = v3785
					v3788.Parent = v3785
				end
			end
			return
		elseif v3708 == "mantis" then
			for v3789, v3790 in { v3709, v3710 } do
				local v3791
				if v3789 == 1 then
					v3791 = v3712
				else
					v3791 = v3713
				end
				local v3792 = p3706.accent
				local v3793 = v3791 * CFrame.new(0, 0, -1.2)
				local v3794 = v_u_27(p3706, "MantisBlade", Vector3.new(0.14, 0.45, 2.2), v3792, v3715)
				local v3795 = v3790.CFrame
				local v3796 = p3706.s
				v3794.CFrame = v3795 * (v3793.Rotation + v3793.Position * v3796)
				local v3797 = Instance.new("WeldConstraint")
				v3797.Part0 = v3790
				v3797.Part1 = v3794
				v3797.Parent = v3794
				local v3798 = p3706.glow
				local v3799 = CFrame.new(0, -0.24, 0)
				local v3800 = v_u_27(p3706, "Edge", Vector3.new(0.08, 0.1, 2.1), v3798, v3714)
				local v3801 = v3794.CFrame
				local v3802 = p3706.s
				v3800.CFrame = v3801 * (v3799.Rotation + v3799.Position * v3802)
				local v3803 = Instance.new("WeldConstraint")
				v3803.Part0 = v3794
				v3803.Part1 = v3800
				v3803.Parent = v3800
				local v3804 = p3706.accent
				local v3805 = CFrame.new(0, 0.25, -1.35) * CFrame.Angles(0.7, 0, 0)
				local v3806 = v_u_27(p3706, "MantisTip", Vector3.new(0.14, 0.36, 0.9), v3804, v3715)
				local v3807 = v3794.CFrame
				local v3808 = p3706.s
				v3806.CFrame = v3807 * (v3805.Rotation + v3805.Position * v3808)
				local v3809 = Instance.new("WeldConstraint")
				v3809.Part0 = v3794
				v3809.Part1 = v3806
				v3809.Parent = v3806
				local v3810 = p3706.glow
				local v3811 = CFrame.new(0, -0.2, 0)
				local v3812 = v_u_27(p3706, "Edge", Vector3.new(0.08, 0.08, 0.85), v3810, v3714)
				local v3813 = v3806.CFrame
				local v3814 = p3706.s
				v3812.CFrame = v3813 * (v3811.Rotation + v3811.Position * v3814)
				local v3815 = Instance.new("WeldConstraint")
				v3815.Part0 = v3806
				v3815.Part1 = v3812
				v3815.Parent = v3812
				for v3816 = 0, 2 do
					local v3817 = p3706.glow
					local v3818 = CFrame.new(0, -0.32, v3816 * 0.55 + -0.7) * CFrame.Angles(-0.5, 0, 0)
					local v3819 = v_u_27(p3706, "Spine", Vector3.new(0.1, 0.3, 0.1), v3817, v3714)
					local v3820 = v3794.CFrame
					local v3821 = p3706.s
					v3819.CFrame = v3820 * (v3818.Rotation + v3818.Position * v3821)
					local v3822 = Instance.new("WeldConstraint")
					v3822.Part0 = v3794
					v3822.Part1 = v3819
					v3822.Parent = v3819
				end
				if v3789 ~= 1 then
					break
				end
				v_u_68(p3706, v3794, Vector3.new(0, 0, -1.1), Vector3.new(0, 0, 0.2), 0.14, 0.3)
			end
			return
		elseif v3708 == "twinblades" then
			for v3823, v3824 in { v3709, v3710 } do
				local v3825
				if v3823 == 1 then
					v3825 = v3712
				else
					v3825 = v3713
				end
				local v3826 = v_u_7
				local v3827 = v3825 * CFrame.new(0, 0, -0.1)
				local v3828 = Instance.new("Part")
				v3828.Name = "Grip"
				v3828.Size = Vector3.new(0.18, 0.18, 0.55) * p3706.s
				v3828.Color = v3826
				v3828.Material = Enum.Material.Plastic
				v3828.CanCollide = false
				v3828.CanTouch = false
				v3828.CanQuery = false
				v3828.Massless = true
				v3828.Anchored = false
				v3828.CastShadow = (Vector3.new(0.18, 0.18, 0.55)).Magnitude > 1.1
				v3828.TopSurface = Enum.SurfaceType.Smooth
				v3828.BottomSurface = Enum.SurfaceType.Smooth
				v3828.Parent = p3706.model
				local v3829 = v3824.CFrame
				local v3830 = p3706.s
				v3828.CFrame = v3829 * (v3827.Rotation + v3827.Position * v3830)
				local v3831 = Instance.new("WeldConstraint")
				v3831.Part0 = v3824
				v3831.Part1 = v3828
				v3831.Parent = v3828
				local v3832 = p3706.trim
				local v3833 = v3825 * CFrame.new(0, 0, -0.42)
				local v3834 = v_u_27(p3706, "Guard", Vector3.new(0.45, 0.12, 0.12), v3832, v3715)
				local v3835 = v3824.CFrame
				local v3836 = p3706.s
				v3834.CFrame = v3835 * (v3833.Rotation + v3833.Position * v3836)
				local v3837 = Instance.new("WeldConstraint")
				v3837.Part0 = v3824
				v3837.Part1 = v3834
				v3837.Parent = v3834
				local v3838 = p3706.accent
				local v3839 = v3825 * CFrame.new(0, 0.03, -1.2)
				local v3840 = v_u_27(p3706, "Dagger", Vector3.new(0.08, 0.3, 1.5), v3838, v3715)
				local v3841 = v3824.CFrame
				local v3842 = p3706.s
				v3840.CFrame = v3841 * (v3839.Rotation + v3839.Position * v3842)
				local v3843 = Instance.new("WeldConstraint")
				v3843.Part0 = v3824
				v3843.Part1 = v3840
				v3843.Parent = v3840
				local v3844 = p3706.glow
				local v3845 = CFrame.new(0, -0.16, 0)
				local v3846 = v_u_27(p3706, "Edge", Vector3.new(0.06, 0.08, 1.45), v3844, v3714)
				local v3847 = v3840.CFrame
				local v3848 = p3706.s
				v3846.CFrame = v3847 * (v3845.Rotation + v3845.Position * v3848)
				local v3849 = Instance.new("WeldConstraint")
				v3849.Part0 = v3840
				v3849.Part1 = v3846
				v3849.Parent = v3846
				local v3850 = p3706.accent
				local v3851 = CFrame.new(0, 0.12, -0.92) * CFrame.Angles(0.45, 0, 0)
				local v3852 = v_u_27(p3706, "DaggerTip", Vector3.new(0.08, 0.24, 0.55), v3850, v3715)
				local v3853 = v3840.CFrame
				local v3854 = p3706.s
				v3852.CFrame = v3853 * (v3851.Rotation + v3851.Position * v3854)
				local v3855 = Instance.new("WeldConstraint")
				v3855.Part0 = v3840
				v3855.Part1 = v3852
				v3855.Parent = v3852
				v_u_68(p3706, v3840, Vector3.new(0, 0, -0.75), Vector3.new(0, 0, 0.3), 0.12, 0.3)
			end
			return
		elseif v3708 == "anchor" then
			local v3856 = p3706.accent
			local v3857 = v3712 * CFrame.new(0, 0, -1.7)
			local v3858 = v_u_27(p3706, "Shank", Vector3.new(0.42, 0.42, 4.2), v3856, v3715)
			local v3859 = v3709.CFrame
			local v3860 = p3706.s
			v3858.CFrame = v3859 * (v3857.Rotation + v3857.Position * v3860)
			local v3861 = Instance.new("WeldConstraint")
			v3861.Part0 = v3709
			v3861.Part1 = v3858
			v3861.Parent = v3858
			local v3862 = Color3.fromRGB(80, 60, 44)
			local v3863, v3864 = CFrame.new(0, 0, -0.45)
			local v3865 = v3712 * v3863
			local v3866 = v_u_27(p3706, "Stock", Vector3.new(1.7, 0.26, 0.26), v3862, v3864)
			local v3867 = v3709.CFrame
			local v3868 = p3706.s
			v3866.CFrame = v3867 * (v3865.Rotation + v3865.Position * v3868)
			local v3869 = Instance.new("WeldConstraint")
			v3869.Part0 = v3709
			v3869.Part1 = v3866
			v3869.Parent = v3866
			local v3870 = p3706.accent
			local v3871 = CFrame.new(0, 0, 0.55)
			local v3872 = {
				["material"] = Enum.Material.Metal,
				["shape"] = Enum.PartType.Cylinder
			}
			local v3873 = v3712 * v3871
			local v3874 = v_u_27(p3706, "AnchorRing", Vector3.new(0.12, 0.75, 0.75), v3870, v3872)
			local v3875 = v3709.CFrame
			local v3876 = p3706.s
			v3874.CFrame = v3875 * (v3873.Rotation + v3873.Position * v3876)
			local v3877 = Instance.new("WeldConstraint")
			v3877.Part0 = v3709
			v3877.Part1 = v3874
			v3877.Parent = v3874
			local v3878 = p3706.accent
			local v3879 = v3712 * CFrame.new(0, 0, -3.85)
			local v3880 = v_u_27(p3706, "AnchorCrown", Vector3.new(0.65, 0.55, 0.55), v3878, v3715)
			local v3881 = v3709.CFrame
			local v3882 = p3706.s
			v3880.CFrame = v3881 * (v3879.Rotation + v3879.Position * v3882)
			local v3883 = Instance.new("WeldConstraint")
			v3883.Part0 = v3709
			v3883.Part1 = v3880
			v3883.Parent = v3880
			for _, v3884 in { -1, 1 } do
				local v3885 = p3706.accent
				local v3886 = v3712 * (CFrame.new(v3884 * 0.62, 0, -3.55) * CFrame.Angles(0, -v3884 * 0.55, 0))
				local v3887 = v_u_27(p3706, "AnchorArm", Vector3.new(1.5, 0.38, 0.38), v3885, v3715)
				local v3888 = v3709.CFrame
				local v3889 = p3706.s
				v3887.CFrame = v3888 * (v3886.Rotation + v3886.Position * v3889)
				local v3890 = Instance.new("WeldConstraint")
				v3890.Part0 = v3709
				v3890.Part1 = v3887
				v3890.Parent = v3887
				local v3891 = p3706.glow
				local v3892 = CFrame.new(v3884 * 0.78, 0, 0) * v_u_3145
				local v3893 = v_u_27(p3706, "Fluke", Vector3.new(0.65, 0.65, 0.14), v3891, v3714)
				local v3894 = v3887.CFrame
				local v3895 = p3706.s
				v3893.CFrame = v3894 * (v3892.Rotation + v3892.Position * v3895)
				local v3896 = Instance.new("WeldConstraint")
				v3896.Part0 = v3887
				v3896.Part1 = v3893
				v3896.Parent = v3893
			end
			local v3897 = v_u_57(p3706, v3709, "Chain", Vector3.new(0.14, 1.6, 0.14), v_u_7, v3712 * CFrame.new(0, -0.1, 0.6), CFrame.new(0, 0.8, 0), Vector3.new(1, 0, 0), 0.3, 5, 0.2, v3715)
			local v3898 = p3706.glow
			local v3899 = CFrame.new(0, -0.85, 0) * v_u_3145
			local v3900 = v_u_27(p3706, "ChainEnd", Vector3.new(0.3, 0.3, 0.3), v3898, v3714)
			local v3901 = v3897.CFrame
			local v3902 = p3706.s
			v3900.CFrame = v3901 * (v3899.Rotation + v3899.Position * v3902)
			local v3903 = Instance.new("WeldConstraint")
			v3903.Part0 = v3897
			v3903.Part1 = v3900
			v3903.Parent = v3900
			v_u_68(p3706, v3858, Vector3.new(0, 0, -2.1), Vector3.new(0, 0, 0.4), 0.14, 0.3)
			return
		elseif v3708 == "halberd" then
			local v3904 = CFrame.Angles(0.35, 0, 0)
			local v3905 = Color3.fromRGB(46, 40, 48)
			local v3906 = v3712 * (v3904 * CFrame.new(0, 0, -1.5))
			local v3907 = Instance.new("Part")
			v3907.Name = "Pole"
			v3907.Size = Vector3.new(0.26, 0.26, 6.4) * p3706.s
			v3907.Color = v3905
			v3907.Material = Enum.Material.Plastic
			v3907.CanCollide = false
			v3907.CanTouch = false
			v3907.CanQuery = false
			v3907.Massless = true
			v3907.Anchored = false
			v3907.CastShadow = (Vector3.new(0.26, 0.26, 6.4)).Magnitude > 1.1
			v3907.TopSurface = Enum.SurfaceType.Smooth
			v3907.BottomSurface = Enum.SurfaceType.Smooth
			v3907.Parent = p3706.model
			local v3908 = v3709.CFrame
			local v3909 = p3706.s
			v3907.CFrame = v3908 * (v3906.Rotation + v3906.Position * v3909)
			local v3910 = Instance.new("WeldConstraint")
			v3910.Part0 = v3709
			v3910.Part1 = v3907
			v3910.Parent = v3907
			local v3911 = p3706.trim
			local v3912 = v3712 * (v3904 * CFrame.new(0, 0, -3.65))
			local v3913 = v_u_27(p3706, "Collar", Vector3.new(0.38, 0.38, 0.3), v3911, v3715)
			local v3914 = v3709.CFrame
			local v3915 = p3706.s
			v3913.CFrame = v3914 * (v3912.Rotation + v3912.Position * v3915)
			local v3916 = Instance.new("WeldConstraint")
			v3916.Part0 = v3709
			v3916.Part1 = v3913
			v3916.Parent = v3913
			local v3917 = p3706.accent
			local v3918 = v3712 * (v3904 * CFrame.new(0, 0.7, -4.3))
			local v3919 = v_u_27(p3706, "HalberdAxe", Vector3.new(0.14, 1.5, 1.1), v3917, v3715)
			local v3920 = v3709.CFrame
			local v3921 = p3706.s
			v3919.CFrame = v3920 * (v3918.Rotation + v3918.Position * v3921)
			local v3922 = Instance.new("WeldConstraint")
			v3922.Part0 = v3709
			v3922.Part1 = v3919
			v3922.Parent = v3919
			local v3923 = p3706.glow
			local v3924 = CFrame.new(0, 0.75, 0)
			local v3925 = v_u_27(p3706, "Edge", Vector3.new(0.1, 0.14, 1.2), v3923, v3714)
			local v3926 = v3919.CFrame
			local v3927 = p3706.s
			v3925.CFrame = v3926 * (v3924.Rotation + v3924.Position * v3927)
			local v3928 = Instance.new("WeldConstraint")
			v3928.Part0 = v3919
			v3928.Part1 = v3925
			v3928.Parent = v3925
			local v3929 = p3706.accent
			local v3930 = v3712 * (v3904 * CFrame.new(0, -0.45, -4.3) * CFrame.Angles(-0.4, 0, 0))
			local v3931 = v_u_27(p3706, "Hook", Vector3.new(0.12, 0.6, 0.35), v3929, v3715)
			local v3932 = v3709.CFrame
			local v3933 = p3706.s
			v3931.CFrame = v3932 * (v3930.Rotation + v3930.Position * v3933)
			local v3934 = Instance.new("WeldConstraint")
			v3934.Part0 = v3709
			v3934.Part1 = v3931
			v3934.Parent = v3931
			local v3935 = p3706.glow
			local v3936 = v3712 * (v3904 * CFrame.new(0, 0, -5.2))
			local v3937 = v_u_27(p3706, "Spike", Vector3.new(0.18, 0.18, 1.1), v3935, v3714)
			local v3938 = v3709.CFrame
			local v3939 = p3706.s
			v3937.CFrame = v3938 * (v3936.Rotation + v3936.Position * v3939)
			local v3940 = Instance.new("WeldConstraint")
			v3940.Part0 = v3709
			v3940.Part1 = v3937
			v3940.Parent = v3937
			v_u_68(p3706, v3907, Vector3.new(0, 0, -3.2), Vector3.new(0, 0, 0.6), 0.14, 0.3)
			return
		elseif v3708 == "chainblade" then
			local v3941 = v3711.X + 0.22
			local v3942 = v3711.Z + 0.22
			local v3943 = Vector3.new(v3941, 0.42, v3942)
			local v3944 = p3706.accent
			local v3945 = CFrame.new(0, -v3711.Y / 2 + 0.4, 0)
			local v3946 = v_u_27(p3706, "Cuff", v3943, v3944, v3715)
			local v3947 = v3709.CFrame
			local v3948 = p3706.s
			v3946.CFrame = v3947 * (v3945.Rotation + v3945.Position * v3948)
			local v3949 = Instance.new("WeldConstraint")
			v3949.Part0 = v3709
			v3949.Part1 = v3946
			v3949.Parent = v3946
			local v3950 = v_u_57(p3706, v3709, "Chain", Vector3.new(0.14, 2.6, 0.14), p3706.accent, v3712 * CFrame.new(0, -0.15, -0.1), CFrame.new(0, 1.3, 0), Vector3.new(1, 0, 0), 0.45, 4.5, 0.35, v3715)
			for v3951 = 0, 3 do
				local v3952 = p3706.accent
				local v3953 = CFrame.new(0, 1 - v3951 * 0.65, 0) * CFrame.Angles(0, v3951 * 3.141592653589793 / 2, 0)
				local v3954 = v_u_27(p3706, "Link", Vector3.new(0.24, 0.3, 0.08), v3952, v3715)
				local v3955 = v3950.CFrame
				local v3956 = p3706.s
				v3954.CFrame = v3955 * (v3953.Rotation + v3953.Position * v3956)
				local v3957 = Instance.new("WeldConstraint")
				v3957.Part0 = v3950
				v3957.Part1 = v3954
				v3957.Parent = v3954
			end
			local v3958 = v_u_8
			local v3959 = CFrame.new(0, -1.45, -0.6)
			local v3960 = v_u_27(p3706, "HookBlade", Vector3.new(0.12, 0.55, 1.7), v3958, v3715)
			local v3961 = v3950.CFrame
			local v3962 = p3706.s
			v3960.CFrame = v3961 * (v3959.Rotation + v3959.Position * v3962)
			local v3963 = Instance.new("WeldConstraint")
			v3963.Part0 = v3950
			v3963.Part1 = v3960
			v3963.Parent = v3960
			local v3964 = p3706.glow
			local v3965 = CFrame.new(0, -0.3, 0)
			local v3966 = v_u_27(p3706, "Edge", Vector3.new(0.08, 0.12, 1.65), v3964, v3714)
			local v3967 = v3960.CFrame
			local v3968 = p3706.s
			v3966.CFrame = v3967 * (v3965.Rotation + v3965.Position * v3968)
			local v3969 = Instance.new("WeldConstraint")
			v3969.Part0 = v3960
			v3969.Part1 = v3966
			v3969.Parent = v3966
			local v3970 = v_u_8
			local v3971 = CFrame.new(0, 0.3, -1) * CFrame.Angles(0.9, 0, 0)
			local v3972 = v_u_27(p3706, "HookTip", Vector3.new(0.12, 0.5, 0.7), v3970, v3715)
			local v3973 = v3960.CFrame
			local v3974 = p3706.s
			v3972.CFrame = v3973 * (v3971.Rotation + v3971.Position * v3974)
			local v3975 = Instance.new("WeldConstraint")
			v3975.Part0 = v3960
			v3975.Part1 = v3972
			v3975.Parent = v3972
			v_u_68(p3706, v3960, Vector3.new(0, 0, -0.85), Vector3.new(0, 0, 0.6), 0.16, 0.3)
			return
		elseif v3708 == "sceptre" then
			local v3976 = p3706.accent
			local v3977 = v3712 * CFrame.new(0, 1.2, -0.35)
			local v3978 = v_u_27(p3706, "Staff", Vector3.new(0.22, 5, 0.22), v3976, v3715)
			local v3979 = v3709.CFrame
			local v3980 = p3706.s
			v3978.CFrame = v3979 * (v3977.Rotation + v3977.Position * v3980)
			local v3981 = Instance.new("WeldConstraint")
			v3981.Part0 = v3709
			v3981.Part1 = v3978
			v3981.Parent = v3978
			local v3982 = p3706.accent
			local v3983 = v3712 * CFrame.new(0, 3.7, -0.35)
			local v3984 = v_u_27(p3706, "Collar", Vector3.new(0.5, 0.25, 0.5), v3982, v3715)
			local v3985 = v3709.CFrame
			local v3986 = p3706.s
			v3984.CFrame = v3985 * (v3983.Rotation + v3983.Position * v3986)
			local v3987 = Instance.new("WeldConstraint")
			v3987.Part0 = v3709
			v3987.Part1 = v3984
			v3987.Parent = v3984
			local v3988 = CFrame.new(0, 4.35, -0.35)
			local v3989 = p3706.glow
			local v3990 = {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			}
			local v3991 = v3712 * v3988
			local v3992 = v_u_27(p3706, "StarHeart", Vector3.new(0.6, 0.6, 0.6), v3989, v3990)
			local v3993 = v3709.CFrame
			local v3994 = p3706.s
			v3992.CFrame = v3993 * (v3991.Rotation + v3991.Position * v3994)
			local v3995 = Instance.new("WeldConstraint")
			v3995.Part0 = v3709
			v3995.Part1 = v3992
			v3995.Parent = v3992
			for v3996, v3997 in {
				0,
				0.9,
				-0.9,
				1.8,
				-1.8
			} do
				local v3998 = v3996 == 1 and 1.1 or 0.75
				local v3999 = Vector3.new(0.18, v3998, 0.18)
				local v4000
				if v3996 % 2 == 1 then
					v4000 = p3706.glow
				else
					v4000 = p3706.eye
				end
				local v4001 = v3712 * (v3988 * CFrame.Angles(0, 0, v3997) * CFrame.new(0, 0.5, 0) * CFrame.Angles(0, 0.7853981633974483, 0))
				local v4002 = v_u_27(p3706, "StarSpike", v3999, v4000, v3714)
				local v4003 = v3709.CFrame
				local v4004 = p3706.s
				v4002.CFrame = v4003 * (v4001.Rotation + v4001.Position * v4004)
				local v4005 = Instance.new("WeldConstraint")
				v4005.Part0 = v3709
				v4005.Part1 = v4002
				v4005.Parent = v4002
			end
			local v4006 = p3706.eye
			local v4007 = v3712 * v3988
			local v4008 = v_u_27(p3706, "StarSpike", Vector3.new(0.16, 0.16, 1.2), v4006, v3714)
			local v4009 = v3709.CFrame
			local v4010 = p3706.s
			v4008.CFrame = v4009 * (v4007.Rotation + v4007.Position * v4010)
			local v4011 = Instance.new("WeldConstraint")
			v4011.Part0 = v3709
			v4011.Part1 = v4008
			v4011.Parent = v4008
		elseif v3708 == "iceclub" then
			local v4012 = Color3.fromRGB(70, 84, 104)
			local v4013, v4014 = CFrame.new(0, 0, -0.2)
			local v4015 = v3712 * v4013
			local v4016 = v_u_27(p3706, "Handle", Vector3.new(0.3, 0.3, 1.1), v4012, v4014)
			local v4017 = v3709.CFrame
			local v4018 = p3706.s
			v4016.CFrame = v4017 * (v4015.Rotation + v4015.Position * v4018)
			local v4019 = Instance.new("WeldConstraint")
			v4019.Part0 = v3709
			v4019.Part1 = v4016
			v4019.Parent = v4016
			local v4020 = v_u_3142
			local v4021 = CFrame.Angles(0.2, 0, 0) * CFrame.new(0, 0, -2)
			local v4022 = {
				["material"] = Enum.Material.Ice
			}
			local v4023 = v3712 * v4021
			local v4024 = v_u_27(p3706, "IceClub", Vector3.new(0.85, 0.85, 2.7), v4020, v4022)
			local v4025 = v3709.CFrame
			local v4026 = p3706.s
			v4024.CFrame = v4025 * (v4023.Rotation + v4023.Position * v4026)
			local v4027 = Instance.new("WeldConstraint")
			v4027.Part0 = v3709
			v4027.Part1 = v4024
			v4027.Parent = v4024
			for _, v4028 in {
				{ Vector3.new(0.2, 0.2, -0.4), Vector3.new(0.75, 0.6, -0.7) },
				{ Vector3.new(-0.2, 0.25, 0.1), Vector3.new(-0.7, 0.7, -0.1) },
				{ Vector3.new(0.1, -0.25, -0.9), Vector3.new(0.5, -0.75, -1.1) },
				{ Vector3.new(-0.15, -0.2, 0.5), Vector3.new(-0.6, -0.6, 0.4) }
			} do
				local v4029 = v4028[1]
				local v4030 = v4028[2]
				local v4031 = p3706.glow
				local v4032 = (v4029 + v4030) / 2
				local v4033 = (v4030 - v4029).Magnitude
				local v4034 = Vector3.new(0.22, 0.22, v4033)
				local v4035 = CFrame.lookAt(v4032, v4030)
				local v4036 = v_u_27(p3706, "IceShard", v4034, v4031, v3714)
				local v4037 = v4024.CFrame
				local v4038 = p3706.s
				v4036.CFrame = v4037 * (v4035.Rotation + v4035.Position * v4038)
				local v4039 = Instance.new("WeldConstraint")
				v4039.Part0 = v4024
				v4039.Part1 = v4036
				v4039.Parent = v4036
			end
			local v4040 = p3706.glow
			local v4041 = CFrame.new(0, 0, -1.55) * v_u_3145
			local v4042 = v_u_27(p3706, "IceTip", Vector3.new(0.5, 0.5, 0.9), v4040, v3714)
			local v4043 = v4024.CFrame
			local v4044 = p3706.s
			v4042.CFrame = v4043 * (v4041.Rotation + v4041.Position * v4044)
			local v4045 = Instance.new("WeldConstraint")
			v4045.Part0 = v4024
			v4045.Part1 = v4042
			v4045.Parent = v4042
			v_u_68(p3706, v4024, Vector3.new(0, 0, -1.35), Vector3.new(0, 0, 0.3), 0.14, 0.3)
		end
	else
		return
	end
end
local function v_u_4622(p4047, p4048, p4049) -- name: gear3
	-- upvalues: (copy) v_u_3145, (copy) v_u_27, (copy) v_u_13, (copy) v_u_57, (copy) v_u_7, (copy) v_u_10, (copy) v_u_3142, (copy) v_u_1830
	local v4050 = p4048.torso
	local v4051 = p4048.d
	local v4052 = v4051.torso
	local v4053 = v4051.arm
	local v4054 = v4052.Y
	local v4055 = -(v4052.Z / 2)
	local v4056 = {
		["material"] = Enum.Material.Fabric
	}
	local v4057 = {
		["material"] = Enum.Material.Metal
	}
	local v4058 = {
		["neon"] = true
	}
	local v4059 = {}
	if p4048.rightArmPart then
		local v4060 = p4048.rightArmPart
		table.insert(v4059, v4060)
	end
	if p4048.leftArmPart then
		local v4061 = p4048.leftArmPart
		table.insert(v4059, v4061)
	end
	local v4062 = p4047.look.gear
	local v4063
	if v4062 == nil then
		v4063 = false
	else
		v4063 = table.find(v4062, "ribs") ~= nil
	end
	if v4063 then
		local v4064 = p4047.glow
		local v4065 = CFrame.new(0.2, 0.2, v4055 - 0.03) * v_u_3145
		local v4066 = v_u_27(p4047, "SoulFire", Vector3.new(0.55, 0.55, 0.08), v4064, v4058)
		local v4067 = v4050.CFrame
		local v4068 = p4047.s
		v4066.CFrame = v4067 * (v4065.Rotation + v4065.Position * v4068)
		local v4069 = Instance.new("WeldConstraint")
		v4069.Part0 = v4050
		v4069.Part1 = v4066
		v4069.Parent = v4066
		local v4070 = v4054 * 0.72
		local v4071 = Vector3.new(0.22, v4070, 0.12)
		local v4072 = p4047.skin
		local v4073, v4074 = CFrame.new(0, 0.1, v4055 - 0.07)
		local v4075 = v_u_27(p4047, "Sternum", v4071, v4072, v4074)
		local v4076 = v4050.CFrame
		local v4077 = p4047.s
		v4075.CFrame = v4076 * (v4073.Rotation + v4073.Position * v4077)
		local v4078 = Instance.new("WeldConstraint")
		v4078.Part0 = v4050
		v4078.Part1 = v4075
		v4078.Parent = v4075
		for v4079 = 1, 4 do
			local v4080 = v4054 * 0.34 - (v4079 - 1) * v4054 * 0.17
			local v4081 = v4052.X * (0.42 - (v4079 - 1) * 0.04)
			for _, v4082 in { -1, 1 } do
				local v4083 = Vector3.new(v4081, 0.15, 0.1)
				local v4084 = p4047.skin
				local v4085 = CFrame.new(v4082 * (v4081 / 2 + 0.08), v4080, v4055 - 0.07) * CFrame.Angles(0, 0, -v4082 * 0.15)
				local v4086 = Instance.new("Part")
				v4086.Name = "Rib"
				v4086.Size = v4083 * p4047.s
				v4086.Color = v4084
				v4086.Material = Enum.Material.Plastic
				v4086.CanCollide = false
				v4086.CanTouch = false
				v4086.CanQuery = false
				v4086.Massless = true
				v4086.Anchored = false
				v4086.CastShadow = v4083.Magnitude > 1.1
				v4086.TopSurface = Enum.SurfaceType.Smooth
				v4086.BottomSurface = Enum.SurfaceType.Smooth
				v4086.Parent = p4047.model
				local v4087 = v4050.CFrame
				local v4088 = p4047.s
				v4086.CFrame = v4087 * (v4085.Rotation + v4085.Position * v4088)
				local v4089 = Instance.new("WeldConstraint")
				v4089.Part0 = v4050
				v4089.Part1 = v4086
				v4089.Parent = v4086
			end
		end
	end
	local v4090 = p4047.look.gear
	local v4091
	if v4090 == nil then
		v4091 = false
	else
		v4091 = table.find(v4090, "shell") ~= nil
	end
	if v4091 then
		local v4092 = v4052.X + 0.3
		local v4093 = v4054 + 0.25
		local v4094 = Vector3.new(v4092, v4093, 0.7)
		local v4095 = p4047.trim
		local v4096, v4097 = CFrame.new(0, 0.05, v4052.Z / 2 + 0.33)
		local v4098 = v_u_27(p4047, "Shell", v4094, v4095, v4097)
		local v4099 = v4050.CFrame
		local v4100 = p4047.s
		v4098.CFrame = v4099 * (v4096.Rotation + v4096.Position * v4100)
		local v4101 = Instance.new("WeldConstraint")
		v4101.Part0 = v4050
		v4101.Part1 = v4098
		v4101.Parent = v4098
		for _, v4102 in { -1, 1 } do
			local v4103 = v4092 + 0.16
			local v4104 = Vector3.new(v4103, 0.14, 0.2)
			local v4105 = p4047.glow
			local v4106 = CFrame.new(0, v4102 * v4093 / 2, -0.1)
			local v4107 = v_u_27(p4047, "ShellRim", v4104, v4105, v4058)
			local v4108 = v4098.CFrame
			local v4109 = p4047.s
			v4107.CFrame = v4108 * (v4106.Rotation + v4106.Position * v4109)
			local v4110 = Instance.new("WeldConstraint")
			v4110.Part0 = v4098
			v4110.Part1 = v4107
			v4110.Parent = v4107
		end
		for _, v4111 in { -1, 1 } do
			local v4112 = v4093 + 0.16
			local v4113 = Vector3.new(0.14, v4112, 0.2)
			local v4114 = p4047.glow
			local v4115 = CFrame.new(v4111 * v4092 / 2, 0, -0.1)
			local v4116 = v_u_27(p4047, "ShellRim", v4113, v4114, v4058)
			local v4117 = v4098.CFrame
			local v4118 = p4047.s
			v4116.CFrame = v4117 * (v4115.Rotation + v4115.Position * v4118)
			local v4119 = Instance.new("WeldConstraint")
			v4119.Part0 = v4098
			v4119.Part1 = v4116
			v4119.Parent = v4116
		end
		for _, v4120 in { Vector2.new(0, 0.38), Vector2.new(-0.48, -0.35), Vector2.new(0.48, -0.35) } do
			local v4121 = p4047.trim:Lerp(v_u_13, 0.18)
			local v4122 = CFrame.new(v4120.X, v4120.Y, 0.38) * v_u_3145
			local v4123 = Instance.new("Part")
			v4123.Name = "ShellPlate"
			v4123.Size = Vector3.new(0.62, 0.62, 0.12) * p4047.s
			v4123.Color = v4121
			v4123.Material = Enum.Material.Plastic
			v4123.CanCollide = false
			v4123.CanTouch = false
			v4123.CanQuery = false
			v4123.Massless = true
			v4123.Anchored = false
			v4123.CastShadow = (Vector3.new(0.62, 0.62, 0.12)).Magnitude > 1.1
			v4123.TopSurface = Enum.SurfaceType.Smooth
			v4123.BottomSurface = Enum.SurfaceType.Smooth
			v4123.Parent = p4047.model
			local v4124 = v4098.CFrame
			local v4125 = p4047.s
			v4123.CFrame = v4124 * (v4122.Rotation + v4122.Position * v4125)
			local v4126 = Instance.new("WeldConstraint")
			v4126.Part0 = v4098
			v4126.Part1 = v4123
			v4126.Parent = v4123
		end
	end
	local v4127 = p4047.look.gear
	local v4128
	if v4127 == nil then
		v4128 = false
	else
		v4128 = table.find(v4127, "talismans") ~= nil
	end
	if v4128 then
		local v4129 = Color3.fromRGB(240, 228, 192)
		local v4130 = {
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 1,
				["on"] = v4050,
				["at"] = CFrame.new(-v4052.X * 0.25, v4054 / 2 - 0.1, v4055 - 0.06)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.85,
				["on"] = v4050,
				["at"] = CFrame.new(v4052.X * 0.3, 0.05, v4055 - 0.06) * CFrame.Angles(0, 0, 0.15)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 1.1,
				["on"] = v4050,
				["at"] = CFrame.new(0.2, v4054 / 2 - 0.1, v4052.Z / 2 + 0.06) * CFrame.Angles(0, 3.141592653589793, 0)
			}
		}
		if p4048.leftArmPart then
			local v4131 = {
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.8,
				["on"] = p4048.leftArmPart,
				["at"] = CFrame.new(-(v4053.X / 2 + 0.05), v4053.Y / 2 - 0.3, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
			}
			table.insert(v4130, v4131)
		end
		if p4047.look.face == "wraps" then
			local v4132 = v4051.head
			local v4133 = {
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.75,
				["on"] = p4048.head,
				["at"] = CFrame.new(v4132 * 0.28 / 1.6, v4132 * 0.42, -v4132 / 2 - 0.06) * CFrame.Angles(0, 0, -0.15)
			}
			table.insert(v4130, v4133)
		end
		for _, v4134 in v4130 do
			local v4135 = v_u_57
			local v4136 = v4134.on
			local v4137 = v4134.len
			local v4138 = v4135(p4047, v4136, "Talisman", Vector3.new(0.4, v4137, 0.04), v4129, v4134.at, CFrame.new(0, v4134.len / 2, 0), Vector3.new(1, 0, 0), 0.18, 5, -0.25)
			local v4139 = v4134.len * 0.65
			local v4140 = Vector3.new(0.12, v4139, 0.06)
			local v4141 = p4047.glow
			local v4142 = CFrame.new(0, -0.03, 0)
			local v4143 = v_u_27(p4047, "Script", v4140, v4141, v4058)
			local v4144 = v4138.CFrame
			local v4145 = p4047.s
			v4143.CFrame = v4144 * (v4142.Rotation + v4142.Position * v4145)
			local v4146 = Instance.new("WeldConstraint")
			v4146.Part0 = v4138
			v4146.Part1 = v4143
			v4146.Parent = v4143
		end
	end
	local v4147 = p4047.look.gear
	local v4148
	if v4147 == nil then
		v4148 = false
	else
		v4148 = table.find(v4147, "beads") ~= nil
	end
	if v4148 then
		local v4149 = Color3.fromRGB(70, 40, 26)
		for v4150 = 0, 11 do
			local v4151 = v4150 * 3.141592653589793 / 6
			local v4152 = math.cos(v4151)
			local v4153 = math.max(0, v4152)
			local v4154 = math.sin(v4151) * v4052.X * 0.38
			local v4155
			if v4153 > 0.3 then
				v4155 = v4055 - 0.15
			else
				v4155 = -math.cos(v4151) * v4052.Z / 2
			end
			local v4156 = v4054 / 2 + 0.12 - v4153 * v4153 * v4054 * 0.45
			local v4157 = v4150 == 0
			local v4158 = Vector3.new(1, 1, 1) * (v4157 and 0.55 or 0.38)
			local v4159
			if v4157 then
				v4159 = p4047.glow
			else
				v4159 = v4149
			end
			local v4160 = CFrame.new(v4154, v4156, v4155)
			local v4161
			if v4157 then
				v4161 = {
					["neon"] = true,
					["shape"] = nil,
					["shape"] = Enum.PartType.Ball
				}
			else
				v4161 = {
					["shape"] = Enum.PartType.Ball
				}
			end
			local v4162 = v_u_27(p4047, "Bead", v4158, v4159, v4161)
			local v4163 = v4050.CFrame
			local v4164 = p4047.s
			v4162.CFrame = v4163 * (v4160.Rotation + v4160.Position * v4164)
			local v4165 = Instance.new("WeldConstraint")
			v4165.Part0 = v4050
			v4165.Part1 = v4162
			v4165.Parent = v4162
		end
	end
	local v4166 = p4047.look.gear
	local v4167
	if v4166 == nil then
		v4167 = false
	else
		v4167 = table.find(v4166, "batwings") ~= nil
	end
	if v4167 then
		local v4168 = p4047.trim:Lerp(v_u_7, 0.45)
		local v4169 = #p4047.swings + 1
		for _, v4170 in { -1, 1 } do
			local v4171 = v_u_57(p4047, v4050, "BatWing", Vector3.new(2.8, 1.9, 0.1), v4168, CFrame.new(v4170 * 0.4, v4054 / 2 - 0.25, v4052.Z / 2 + 0.15) * CFrame.Angles(0, -v4170 * 0.3, v4170 * 0.35), CFrame.new(-v4170 * 1.4, 0.45, 0), Vector3.new(0, 0, v4170), 0.22, 4, 0)
			local v4172 = p4047.accent
			local v4173, v4174 = CFrame.new(0, 0.95, 0)
			local v4175 = v_u_27(p4047, "WingArm", Vector3.new(2.9, 0.18, 0.18), v4172, v4174)
			local v4176 = v4171.CFrame
			local v4177 = p4047.s
			v4175.CFrame = v4176 * (v4173.Rotation + v4173.Position * v4177)
			local v4178 = Instance.new("WeldConstraint")
			v4178.Part0 = v4171
			v4178.Part1 = v4175
			v4178.Parent = v4175
			for v4179 = 0, 2 do
				local v4180 = p4047.glow
				local v4181 = CFrame.new(v4170 * (v4179 * 0.75 + -0.6), 0, 0) * CFrame.Angles(0, 0, v4170 * (0.4 - v4179 * 0.3))
				local v4182 = v_u_27(p4047, "WingFinger", Vector3.new(0.12, 1.9, 0.14), v4180, v4058)
				local v4183 = v4171.CFrame
				local v4184 = p4047.s
				v4182.CFrame = v4183 * (v4181.Rotation + v4181.Position * v4184)
				local v4185 = Instance.new("WeldConstraint")
				v4185.Part0 = v4171
				v4185.Part1 = v4182
				v4185.Parent = v4182
			end
			local v4186 = v_u_10
			local v4187 = CFrame.new(v4170 * 1.45, 1.15, 0) * CFrame.Angles(0, 0, -v4170 * 0.4)
			local v4188 = Instance.new("Part")
			v4188.Name = "WingClaw"
			v4188.Size = Vector3.new(0.2, 0.42, 0.2) * p4047.s
			v4188.Color = v4186
			v4188.Material = Enum.Material.Plastic
			v4188.CanCollide = false
			v4188.CanTouch = false
			v4188.CanQuery = false
			v4188.Massless = true
			v4188.Anchored = false
			v4188.CastShadow = (Vector3.new(0.2, 0.42, 0.2)).Magnitude > 1.1
			v4188.TopSurface = Enum.SurfaceType.Smooth
			v4188.BottomSurface = Enum.SurfaceType.Smooth
			v4188.Parent = p4047.model
			local v4189 = v4171.CFrame
			local v4190 = p4047.s
			v4188.CFrame = v4189 * (v4187.Rotation + v4187.Position * v4190)
			local v4191 = Instance.new("WeldConstraint")
			v4191.Part0 = v4171
			v4191.Part1 = v4188
			v4191.Parent = v4188
		end
		local v4192 = math.random() * 6
		for v4193 = v4169, #p4047.swings do
			p4047.swings[v4193].offset = v4192
		end
	end
	local v4194 = p4047.look.gear
	local v4195
	if v4194 == nil then
		v4195 = false
	else
		v4195 = table.find(v4194, "chains") ~= nil
	end
	if v4195 then
		for _, v4196 in { 0.55, -0.55 } do
			local v4197 = v4052.X + 0.16
			local v4198 = v4052.Z + 0.16
			local v4199 = Vector3.new(v4197, 0.2, v4198)
			local v4200 = p4047.accent
			local v4201 = CFrame.Angles(0, 0, v4196)
			local v4202 = v_u_27(p4047, "ChainWrap", v4199, v4200, v4057)
			local v4203 = v4050.CFrame
			local v4204 = p4047.s
			v4202.CFrame = v4203 * (v4201.Rotation + v4201.Position * v4204)
			local v4205 = Instance.new("WeldConstraint")
			v4205.Part0 = v4050
			v4205.Part1 = v4202
			v4205.Parent = v4202
		end
		for v4206, v4207 in v4059 do
			local v4208 = v4053.X + 0.22
			local v4209 = v4053.Z + 0.22
			local v4210 = Vector3.new(v4208, 0.38, v4209)
			local v4211 = v_u_7
			local v4212 = CFrame.new(0, -v4053.Y / 2 + 0.55, 0)
			local v4213 = v_u_27(p4047, "Shackle", v4210, v4211, v4057)
			local v4214 = v4207.CFrame
			local v4215 = p4047.s
			v4213.CFrame = v4214 * (v4212.Rotation + v4212.Position * v4215)
			local v4216 = Instance.new("WeldConstraint")
			v4216.Part0 = v4207
			v4216.Part1 = v4213
			v4216.Parent = v4213
			local v4217 = v_u_57(p4047, v4207, "HangingChain", Vector3.new(0.14, 1.7, 0.14), p4047.accent, CFrame.new(0, -v4053.Y / 2 + 0.45, v4053.Z / 2 + 0.1), CFrame.new(0, 0.85, 0), Vector3.new(1, 0, 0), 0.35, v4206 + 5, 0.4, v4057)
			local v4218 = p4047.glow
			local v4219 = CFrame.new(0, -0.95, 0) * CFrame.Angles(0.7853981633974483, 0, 0.7853981633974483)
			local v4220 = v_u_27(p4047, "ChainEnd", Vector3.new(0.3, 0.3, 0.3), v4218, v4058)
			local v4221 = v4217.CFrame
			local v4222 = p4047.s
			v4220.CFrame = v4221 * (v4219.Rotation + v4219.Position * v4222)
			local v4223 = Instance.new("WeldConstraint")
			v4223.Part0 = v4217
			v4223.Part1 = v4220
			v4223.Parent = v4220
		end
	end
	local v4224 = p4047.look.gear
	local v4225
	if v4224 == nil then
		v4225 = false
	else
		v4225 = table.find(v4224, "eclipse") ~= nil
	end
	if v4225 then
		local v4226 = CFrame.new(0, 0.3, v4055 - 0.1)
		local v4227 = Color3.fromRGB(12, 8, 14)
		local v4228 = v4226 * CFrame.Angles(0, 1.5707963267948966, 0)
		local v4229 = v_u_27(p4047, "EclipseDisc", Vector3.new(0.1, 1, 1), v4227, {
			["shape"] = Enum.PartType.Cylinder
		})
		local v4230 = v4050.CFrame
		local v4231 = p4047.s
		v4229.CFrame = v4230 * (v4228.Rotation + v4228.Position * v4231)
		local v4232 = Instance.new("WeldConstraint")
		v4232.Part0 = v4050
		v4232.Part1 = v4229
		v4232.Parent = v4229
		for v4233 = 0, 7 do
			local v4234 = v4233 * 3.141592653589793 / 4
			local v4235 = p4047.glow
			local v4236 = v4226 * CFrame.new(math.cos(v4234) * 0.56, math.sin(v4234) * 0.56, -0.02) * CFrame.Angles(0, 0, v4234)
			local v4237 = v_u_27(p4047, "EclipseRing", Vector3.new(0.14, 0.44, 0.08), v4235, v4058)
			local v4238 = v4050.CFrame
			local v4239 = p4047.s
			v4237.CFrame = v4238 * (v4236.Rotation + v4236.Position * v4239)
			local v4240 = Instance.new("WeldConstraint")
			v4240.Part0 = v4050
			v4240.Part1 = v4237
			v4240.Parent = v4237
		end
	end
	local v4241 = p4047.look.gear
	local v4242
	if v4241 == nil then
		v4242 = false
	else
		v4242 = table.find(v4241, "icicles") ~= nil
	end
	if v4242 then
		local v4243 = {
			["material"] = Enum.Material.Ice
		}
		for _, v4244 in v4059 do
			local v4245 = v4244 == p4048.rightArmPart and 1 or -1
			for v4246, v4247 in {
				{ 0.1, 0.95, 0.25 },
				{ -0.25, 0.65, -0.3 },
				{ 0.3, 0.55, 0.7 }
			} do
				local v4248 = v4246 == 1
				local v4249 = v4247[2]
				local v4250 = Vector3.new(0.26, v4249, 0.26)
				local v4251
				if v4248 then
					v4251 = p4047.glow
				else
					v4251 = v_u_3142
				end
				local v4252 = CFrame.new(v4245 * v4247[1], v4053.Y / 2 + v4247[2] / 2 - 0.12, (v4246 - 2) * 0.2) * CFrame.Angles(0, 0, -v4245 * v4247[3]) * CFrame.Angles(0, 0.7853981633974483, 0)
				local v4253
				if v4248 then
					v4253 = v4058
				else
					v4253 = v4243
				end
				local v4254 = v_u_27(p4047, "Icicle", v4250, v4251, v4253)
				local v4255 = v4244.CFrame
				local v4256 = p4047.s
				v4254.CFrame = v4255 * (v4252.Rotation + v4252.Position * v4256)
				local v4257 = Instance.new("WeldConstraint")
				v4257.Part0 = v4244
				v4257.Part1 = v4254
				v4257.Parent = v4254
			end
		end
		for _, v4258 in { -0.45, 0.35 } do
			local v4259 = v_u_3142
			local v4260 = CFrame.new(v4258, -v4054 / 2 - 0.15, v4052.Z / 2 - 0.05) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v4261 = v_u_27(p4047, "Icicle", Vector3.new(0.24, 0.7, 0.24), v4259, v4243)
			local v4262 = v4050.CFrame
			local v4263 = p4047.s
			v4261.CFrame = v4262 * (v4260.Rotation + v4260.Position * v4263)
			local v4264 = Instance.new("WeldConstraint")
			v4264.Part0 = v4050
			v4264.Part1 = v4261
			v4264.Parent = v4261
		end
	end
	local v4265 = p4047.look.gear
	local v4266
	if v4265 == nil then
		v4266 = false
	else
		v4266 = table.find(v4265, "seaweed") ~= nil
	end
	if v4266 then
		local v4267 = {
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 1.8,
				["on"] = v4050,
				["at"] = CFrame.new(-v4052.X * 0.3, v4054 / 2 - 0.05, v4055 - 0.08)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 1.4,
				["on"] = v4050,
				["at"] = CFrame.new(v4052.X * 0.35, -v4054 / 2 + 0.2, v4055 - 0.08)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 2.2,
				["on"] = v4050,
				["at"] = CFrame.new(v4052.X * 0.15, v4054 / 2 - 0.05, v4052.Z / 2 + 0.08)
			}
		}
		for _, v4268 in v4059 do
			local v4269 = {
				["on"] = nil,
				["at"] = nil,
				["len"] = 1.3,
				["on"] = v4268,
				["at"] = CFrame.new((v4268 == p4048.rightArmPart and 1 or -1) * (v4053.X / 2 + 0.05), v4053.Y / 2 - 0.2, 0)
			}
			table.insert(v4267, v4269)
		end
		for v4270, v4271 in v4267 do
			local v4272 = v_u_57
			local v4273 = v4271.on
			local v4274 = v4271.len
			local v4275 = v4272(p4047, v4273, "Seaweed", Vector3.new(0.3, v4274, 0.08), p4047.trim, v4271.at, CFrame.new(0, v4271.len / 2, 0), Vector3.new(1, 0, 0), 0.2, v4270 * 0.3 + 2, -0.3)
			local v4276 = p4047.glow
			local v4277 = CFrame.new(0, -v4271.len / 2 + 0.12, 0)
			local v4278 = v_u_27(p4047, "WeedBud", Vector3.new(0.16, 0.16, 0.12), v4276, v4058)
			local v4279 = v4275.CFrame
			local v4280 = p4047.s
			v4278.CFrame = v4279 * (v4277.Rotation + v4277.Position * v4280)
			local v4281 = Instance.new("WeldConstraint")
			v4281.Part0 = v4275
			v4281.Part1 = v4278
			v4281.Parent = v4278
		end
		local v4282 = Color3.fromRGB(214, 206, 188)
		for _, v4283 in { CFrame.new(0.55, 0.45, v4055 - 0.08), CFrame.new(-0.6, -0.4, v4055 - 0.06) } do
			local v4284 = v_u_27(p4047, "Barnacle", Vector3.new(0.3, 0.3, 0.3), v4282, {
				["shape"] = Enum.PartType.Ball
			})
			local v4285 = v4050.CFrame
			local v4286 = p4047.s
			v4284.CFrame = v4285 * (v4283.Rotation + v4283.Position * v4286)
			local v4287 = Instance.new("WeldConstraint")
			v4287.Part0 = v4050
			v4287.Part1 = v4284
			v4287.Parent = v4284
		end
	end
	local v4288 = p4047.look.gear
	local v4289
	if v4288 == nil then
		v4289 = false
	else
		v4289 = table.find(v4288, "coat") ~= nil
	end
	if v4289 then
		local v4290 = v4051.leg.Y * 0.95
		for _, v4291 in { -1, 1 } do
			local v4292 = v_u_57
			local v4293 = v4052.X * 0.48
			v4292(p4047, v4050, "CoatTail", Vector3.new(v4293, v4290, 0.12), p4047.trim, CFrame.new(v4291 * v4052.X * 0.25, -v4054 / 2 + 0.15, v4052.Z / 2 + 0.08), CFrame.new(0, v4290 / 2, 0), Vector3.new(1, 0, 0), 0.08, 3, -0.45, v4056)
			local v4294 = v4054 * 0.75
			local v4295 = Vector3.new(0.32, v4294, 0.1)
			local v4296 = p4047.trim
			local v4297 = CFrame.new(v4291 * v4052.X * 0.22, 0.12, v4055 - 0.06) * CFrame.Angles(0, 0, v4291 * 0.18)
			local v4298 = v_u_27(p4047, "Lapel", v4295, v4296, v4056)
			local v4299 = v4050.CFrame
			local v4300 = p4047.s
			v4298.CFrame = v4299 * (v4297.Rotation + v4297.Position * v4300)
			local v4301 = Instance.new("WeldConstraint")
			v4301.Part0 = v4050
			v4301.Part1 = v4298
			v4301.Parent = v4298
		end
		for v4302 = 0, 3 do
			local v4303 = p4047.accent
			local v4304 = CFrame.new
			local v4305 = v4302 % 2 == 0 and 0.12 or -0.12
			local v4306 = v4054 * 0.3
			local v4307 = v4302 / 2
			local v4308 = v4304(v4305, v4306 - math.floor(v4307) * v4054 * 0.35, v4055 - 0.1)
			local v4309 = v_u_27(p4047, "Button", Vector3.new(0.18, 0.18, 0.08), v4303, v4057)
			local v4310 = v4050.CFrame
			local v4311 = p4047.s
			v4309.CFrame = v4310 * (v4308.Rotation + v4308.Position * v4311)
			local v4312 = Instance.new("WeldConstraint")
			v4312.Part0 = v4050
			v4312.Part1 = v4309
			v4312.Parent = v4309
		end
	end
	local v4313 = p4047.look.gear
	local v4314
	if v4313 == nil then
		v4314 = false
	else
		v4314 = table.find(v4313, "snowflakes") ~= nil
	end
	if v4314 then
		local v4315 = p4049 and 4 or 2
		for v4316 = 1, v4315 do
			local v4317 = v_u_27(p4047, "Snowflake", Vector3.new(0.34, 0.34, 0.12), p4047.glow, v4058)
			v_u_1830(p4047, v4317, v4052.X / 2 + (p4049 and 2.2 or 1.5), v4316 % 2 * 0.7 + 0.2, 1.1, (v4316 - 1) * 3.141592653589793 * 2 / v4315)
			for v4318 = 0, 2 do
				local v4319 = p4047.glow
				local v4320 = CFrame.Angles(0, 0, v4318 * 3.141592653589793 / 3)
				local v4321 = v_u_27(p4047, "FlakeArm", Vector3.new(0.12, 1.4, 0.1), v4319, v4058)
				local v4322 = v4317.CFrame
				local v4323 = p4047.s
				v4321.CFrame = v4322 * (v4320.Rotation + v4320.Position * v4323)
				local v4324 = Instance.new("WeldConstraint")
				v4324.Part0 = v4317
				v4324.Part1 = v4321
				v4324.Parent = v4321
				for _, v4325 in { -1, 1 } do
					local v4326 = p4047.eye
					local v4327 = CFrame.new(0, v4325 * 0.6, 0) * v_u_3145
					local v4328 = v_u_27(p4047, "FlakeTip", Vector3.new(0.22, 0.22, 0.08), v4326, v4058)
					local v4329 = v4321.CFrame
					local v4330 = p4047.s
					v4328.CFrame = v4329 * (v4327.Rotation + v4327.Position * v4330)
					local v4331 = Instance.new("WeldConstraint")
					v4331.Part0 = v4321
					v4331.Part1 = v4328
					v4331.Parent = v4328
				end
			end
		end
	end
	local v4332 = p4047.look.gear
	local v4333
	if v4332 == nil then
		v4333 = false
	else
		v4333 = table.find(v4332, "thorns") ~= nil
	end
	if v4333 then
		local v4334 = p4047.trim:Lerp(v_u_7, 0.4)
		local v4335 = v4052.X + 0.14
		local v4336 = v4052.Z + 0.14
		local v4337 = Vector3.new(v4335, 0.22, v4336)
		local v4338 = p4047.trim
		local v4339, v4340 = CFrame.Angles(0, 0, -0.6)
		local v4341 = v_u_27(p4047, "Vine", v4337, v4338, v4340)
		local v4342 = v4050.CFrame
		local v4343 = p4047.s
		v4341.CFrame = v4342 * (v4339.Rotation + v4339.Position * v4343)
		local v4344 = Instance.new("WeldConstraint")
		v4344.Part0 = v4050
		v4344.Part1 = v4341
		v4344.Parent = v4341
		local v4345 = {}
		local v4346 = { Vector3.new(0.55, 0.5, v4055), Vector3.new(0.3, 0.3, -1) }
		local v4347 = { Vector3.new(-0.45, -0.35, v4055), Vector3.new(-0.3, -0.2, -1) }
		local v4348 = {}
		local v4349 = v4052.Z / 2
		__set_list(v4348, 1, {Vector3.new(0.3, 0.2, v4349), Vector3.new(0.2, 0.4, 1)})
		local v4350 = {}
		local v4351 = -v4052.X / 2
		__set_list(v4350, 1, {Vector3.new(v4351, 0.5, 0), Vector3.new(-1, 0.4, 0)})
		__set_list(v4345, 1, {v4346, v4347, v4348, v4350})
		for _, v4352 in v4345 do
			local v4353 = v4352[1]
			local v4354 = v4352[1] + v4352[2].Unit * 0.6
			local v4355 = (v4353 + v4354) / 2
			local v4356 = (v4354 - v4353).Magnitude
			local v4357 = Vector3.new(0.16, 0.16, v4356)
			local v4358 = CFrame.lookAt(v4355, v4354)
			local v4359 = Instance.new("Part")
			v4359.Name = "Thorn"
			v4359.Size = v4357 * p4047.s
			v4359.Color = v4334
			v4359.Material = Enum.Material.Plastic
			v4359.CanCollide = false
			v4359.CanTouch = false
			v4359.CanQuery = false
			v4359.Massless = true
			v4359.Anchored = false
			v4359.CastShadow = v4357.Magnitude > 1.1
			v4359.TopSurface = Enum.SurfaceType.Smooth
			v4359.BottomSurface = Enum.SurfaceType.Smooth
			v4359.Parent = p4047.model
			local v4360 = v4050.CFrame
			local v4361 = p4047.s
			v4359.CFrame = v4360 * (v4358.Rotation + v4358.Position * v4361)
			local v4362 = Instance.new("WeldConstraint")
			v4362.Part0 = v4050
			v4362.Part1 = v4359
			v4362.Parent = v4359
		end
		for _, v4363 in v4059 do
			local v4364 = v4053.X + 0.1
			local v4365 = v4053.Z + 0.1
			local v4366 = Vector3.new(v4364, 0.2, v4365)
			local v4367 = p4047.trim
			local v4368 = CFrame.new(0, -0.2, 0) * CFrame.Angles(0, 0, 0.3)
			local v4369 = Instance.new("Part")
			v4369.Name = "Vine"
			v4369.Size = v4366 * p4047.s
			v4369.Color = v4367
			v4369.Material = Enum.Material.Plastic
			v4369.CanCollide = false
			v4369.CanTouch = false
			v4369.CanQuery = false
			v4369.Massless = true
			v4369.Anchored = false
			v4369.CastShadow = v4366.Magnitude > 1.1
			v4369.TopSurface = Enum.SurfaceType.Smooth
			v4369.BottomSurface = Enum.SurfaceType.Smooth
			v4369.Parent = p4047.model
			local v4370 = v4363.CFrame
			local v4371 = p4047.s
			v4369.CFrame = v4370 * (v4368.Rotation + v4368.Position * v4371)
			local v4372 = Instance.new("WeldConstraint")
			v4372.Part0 = v4363
			v4372.Part1 = v4369
			v4372.Parent = v4369
			local v4373 = v4363 == p4048.rightArmPart and 1 or -1
			local v4374 = v4373 * v4053.X / 2
			local v4375 = Vector3.new(v4374, 0.1, 0)
			local v4376 = v4373 * (v4053.X / 2 + 0.55)
			local v4377 = Vector3.new(v4376, 0.35, 0)
			local v4378 = (v4375 + v4377) / 2
			local v4379 = (v4377 - v4375).Magnitude
			local v4380 = Vector3.new(0.16, 0.16, v4379)
			local v4381 = CFrame.lookAt(v4378, v4377)
			local v4382 = Instance.new("Part")
			v4382.Name = "Thorn"
			v4382.Size = v4380 * p4047.s
			v4382.Color = v4334
			v4382.Material = Enum.Material.Plastic
			v4382.CanCollide = false
			v4382.CanTouch = false
			v4382.CanQuery = false
			v4382.Massless = true
			v4382.Anchored = false
			v4382.CastShadow = v4380.Magnitude > 1.1
			v4382.TopSurface = Enum.SurfaceType.Smooth
			v4382.BottomSurface = Enum.SurfaceType.Smooth
			v4382.Parent = p4047.model
			local v4383 = v4363.CFrame
			local v4384 = p4047.s
			v4382.CFrame = v4383 * (v4381.Rotation + v4381.Position * v4384)
			local v4385 = Instance.new("WeldConstraint")
			v4385.Part0 = v4363
			v4385.Part1 = v4382
			v4385.Parent = v4382
		end
		local v4386 = CFrame.new(-v4052.X * 0.28, v4054 * 0.28, v4055 - 0.12)
		for v4387 = 0, 4 do
			local v4388 = p4047.glow
			local v4389 = v4386 * CFrame.Angles(0, 0, v4387 * 3.141592653589793 * 2 / 5) * CFrame.new(0, 0.2, 0) * v_u_3145
			local v4390 = v_u_27(p4047, "Bloom", Vector3.new(0.34, 0.34, 0.06), v4388, v4058)
			local v4391 = v4050.CFrame
			local v4392 = p4047.s
			v4390.CFrame = v4391 * (v4389.Rotation + v4389.Position * v4392)
			local v4393 = Instance.new("WeldConstraint")
			v4393.Part0 = v4050
			v4393.Part1 = v4390
			v4393.Parent = v4390
		end
		local v4394 = p4047.eye
		local v4395 = v4386 * CFrame.new(0, 0, -0.03)
		local v4396 = v_u_27(p4047, "BloomHeart", Vector3.new(0.2, 0.2, 0.08), v4394, v4058)
		local v4397 = v4050.CFrame
		local v4398 = p4047.s
		v4396.CFrame = v4397 * (v4395.Rotation + v4395.Position * v4398)
		local v4399 = Instance.new("WeldConstraint")
		v4399.Part0 = v4050
		v4399.Part1 = v4396
		v4399.Parent = v4396
	end
	local v4400 = p4047.look.gear
	local v4401
	if v4400 == nil then
		v4401 = false
	else
		v4401 = table.find(v4400, "highcollar") ~= nil
	end
	if v4401 then
		local v4402 = p4047.glow:Lerp(v_u_7, 0.35)
		local v4403 = v4052.X * 0.95
		local v4404 = Vector3.new(v4403, 1.5, 0.14)
		local v4405 = p4047.trim
		local v4406 = CFrame.new(0, v4054 / 2 + 0.55, v4052.Z / 2 + 0.05) * CFrame.Angles(0.3, 0, 0)
		local v4407 = Instance.new("Part")
		v4407.Name = "HighCollar"
		v4407.Size = v4404 * p4047.s
		v4407.Color = v4405
		v4407.Material = Enum.Material.Plastic
		v4407.CanCollide = false
		v4407.CanTouch = false
		v4407.CanQuery = false
		v4407.Massless = true
		v4407.Anchored = false
		v4407.CastShadow = v4404.Magnitude > 1.1
		v4407.TopSurface = Enum.SurfaceType.Smooth
		v4407.BottomSurface = Enum.SurfaceType.Smooth
		v4407.Parent = p4047.model
		local v4408 = v4050.CFrame
		local v4409 = p4047.s
		v4407.CFrame = v4408 * (v4406.Rotation + v4406.Position * v4409)
		local v4410 = Instance.new("WeldConstraint")
		v4410.Part0 = v4050
		v4410.Part1 = v4407
		v4410.Parent = v4407
		local v4411 = v4052.X * 0.85
		local v4412 = Vector3.new(v4411, 1.35, 0.06)
		local v4413, v4414 = CFrame.new(0, 0.02, -0.08)
		local v4415 = v_u_27(p4047, "Lining", v4412, v4402, v4414)
		local v4416 = v4407.CFrame
		local v4417 = p4047.s
		v4415.CFrame = v4416 * (v4413.Rotation + v4413.Position * v4417)
		local v4418 = Instance.new("WeldConstraint")
		v4418.Part0 = v4407
		v4418.Part1 = v4415
		v4418.Parent = v4415
		for _, v4419 in { -1, 1 } do
			local v4420 = p4047.trim
			local v4421 = CFrame.new(v4419 * v4052.X * 0.47, v4054 / 2 + 0.45, 0.05) * CFrame.Angles(0, 0, -v4419 * 0.3)
			local v4422 = Instance.new("Part")
			v4422.Name = "CollarSide"
			v4422.Size = Vector3.new(0.14, 1.3, 0.85) * p4047.s
			v4422.Color = v4420
			v4422.Material = Enum.Material.Plastic
			v4422.CanCollide = false
			v4422.CanTouch = false
			v4422.CanQuery = false
			v4422.Massless = true
			v4422.Anchored = false
			v4422.CastShadow = (Vector3.new(0.14, 1.3, 0.85)).Magnitude > 1.1
			v4422.TopSurface = Enum.SurfaceType.Smooth
			v4422.BottomSurface = Enum.SurfaceType.Smooth
			v4422.Parent = p4047.model
			local v4423 = v4050.CFrame
			local v4424 = p4047.s
			v4422.CFrame = v4423 * (v4421.Rotation + v4421.Position * v4424)
			local v4425 = Instance.new("WeldConstraint")
			v4425.Part0 = v4050
			v4425.Part1 = v4422
			v4425.Parent = v4422
			local v4426, v4427 = CFrame.new(-v4419 * 0.08, 0.02, 0)
			local v4428 = v_u_27(p4047, "Lining", Vector3.new(0.06, 1.15, 0.75), v4402, v4427)
			local v4429 = v4422.CFrame
			local v4430 = p4047.s
			v4428.CFrame = v4429 * (v4426.Rotation + v4426.Position * v4430)
			local v4431 = Instance.new("WeldConstraint")
			v4431.Part0 = v4422
			v4431.Part1 = v4428
			v4431.Parent = v4428
			local v4432 = p4047.glow
			local v4433 = CFrame.new(0, 0.75, 0.3) * CFrame.Angles(0.3, 0, 0)
			local v4434 = v_u_27(p4047, "CollarPoint", Vector3.new(0.18, 0.5, 0.18), v4432, v4058)
			local v4435 = v4422.CFrame
			local v4436 = p4047.s
			v4434.CFrame = v4435 * (v4433.Rotation + v4433.Position * v4436)
			local v4437 = Instance.new("WeldConstraint")
			v4437.Part0 = v4422
			v4437.Part1 = v4434
			v4437.Parent = v4434
		end
	end
	local v4438 = p4047.look.gear
	local v4439
	if v4438 == nil then
		v4439 = false
	else
		v4439 = table.find(v4438, "sashimono") ~= nil
	end
	if v4439 then
		for _, v4440 in { -1, 1 } do
			local v4441 = v_u_7
			local v4442 = CFrame.new(v4440 * 0.45, v4054 / 2 + 1.5, v4052.Z / 2 + 0.3) * CFrame.Angles(0, 0, -v4440 * 0.12)
			local v4443 = Instance.new("Part")
			v4443.Name = "FlagPole"
			v4443.Size = Vector3.new(0.14, 4.6, 0.14) * p4047.s
			v4443.Color = v4441
			v4443.Material = Enum.Material.Plastic
			v4443.CanCollide = false
			v4443.CanTouch = false
			v4443.CanQuery = false
			v4443.Massless = true
			v4443.Anchored = false
			v4443.CastShadow = (Vector3.new(0.14, 4.6, 0.14)).Magnitude > 1.1
			v4443.TopSurface = Enum.SurfaceType.Smooth
			v4443.BottomSurface = Enum.SurfaceType.Smooth
			v4443.Parent = p4047.model
			local v4444 = v4050.CFrame
			local v4445 = p4047.s
			v4443.CFrame = v4444 * (v4442.Rotation + v4442.Position * v4445)
			local v4446 = Instance.new("WeldConstraint")
			v4446.Part0 = v4050
			v4446.Part1 = v4443
			v4446.Parent = v4443
			local v4447 = v_u_57(p4047, v4443, "WarFlag", Vector3.new(1, 2.3, 0.08), p4047.trim, CFrame.new(v4440 * 0.06, 1, 0), CFrame.new(-v4440 * 0.5, 0, 0), Vector3.new(0, 1, 0), 0.2, 3.5, -v4440 * 0.3, v4056)
			local v4448 = v_u_3145
			local v4449 = v_u_27(p4047, "FlagMark", Vector3.new(0.5, 0.5, 0.12), p4047.glow, v4058)
			local v4450 = v4447.CFrame
			local v4451 = p4047.s
			v4449.CFrame = v4450 * (v4448.Rotation + v4448.Position * v4451)
			local v4452 = Instance.new("WeldConstraint")
			v4452.Part0 = v4447
			v4452.Part1 = v4449
			v4452.Parent = v4449
		end
	end
	local v4453 = p4047.look.gear
	local v4454
	if v4453 == nil then
		v4454 = false
	else
		v4454 = table.find(v4453, "skulls") ~= nil
	end
	if v4454 then
		local v4455 = p4049 and 4 or 2
		for v4456 = 1, v4455 do
			local v4457 = v_u_10
			local v4458 = Instance.new("Part")
			v4458.Name = "Skull"
			v4458.Size = Vector3.new(0.8, 0.75, 0.8) * p4047.s
			v4458.Color = v4457
			v4458.Material = Enum.Material.Plastic
			v4458.CanCollide = false
			v4458.CanTouch = false
			v4458.CanQuery = false
			v4458.Massless = true
			v4458.Anchored = false
			v4458.CastShadow = (Vector3.new(0.8, 0.75, 0.8)).Magnitude > 1.1
			v4458.TopSurface = Enum.SurfaceType.Smooth
			v4458.BottomSurface = Enum.SurfaceType.Smooth
			v4458.Parent = p4047.model
			v_u_1830(p4047, v4458, v4052.X / 2 + 2, v4456 % 2 * 0.6 + 0.4, 1.3, (v4456 - 1) * 3.141592653589793 * 2 / v4455)
			for _, v4459 in { -1, 1 } do
				for _, v4460 in { -1, 1 } do
					local v4461 = p4047.glow
					local v4462 = CFrame.new(v4460 * 0.18, 0.05, v4459 * 0.41)
					local v4463 = v_u_27(p4047, "SkullEye", Vector3.new(0.24, 0.2, 0.06), v4461, v4058)
					local v4464 = v4458.CFrame
					local v4465 = p4047.s
					v4463.CFrame = v4464 * (v4462.Rotation + v4462.Position * v4465)
					local v4466 = Instance.new("WeldConstraint")
					v4466.Part0 = v4458
					v4466.Part1 = v4463
					v4466.Parent = v4463
				end
			end
			local v4467 = v_u_10
			local v4468, v4469 = CFrame.new(0, -0.45, -0.05)
			local v4470 = v_u_27(p4047, "SkullJaw", Vector3.new(0.6, 0.22, 0.6), v4467, v4469)
			local v4471 = v4458.CFrame
			local v4472 = p4047.s
			v4470.CFrame = v4471 * (v4468.Rotation + v4468.Position * v4472)
			local v4473 = Instance.new("WeldConstraint")
			v4473.Part0 = v4458
			v4473.Part1 = v4470
			v4473.Parent = v4470
		end
	end
	local v4474 = p4047.look.gear
	local v4475
	if v4474 == nil then
		v4475 = false
	else
		v4475 = table.find(v4474, "snaketail") ~= nil
	end
	if v4475 then
		local v4476 = -(v4054 / 2 + 0.6 + 1.5 + 0.8)
		local v4477 = {
			["material"] = Enum.Material.SmoothPlastic
		}
		local v4478 = -v4054 / 2 - 0.4
		local v4479 = Vector3.new(0, v4478, 0.15)
		local v4480 = v4476 + 0.55
		local v4481 = Vector3.new(0, v4480, 1.1)
		local v4482 = p4047.pants
		local v4483 = (v4479 + v4481) / 2
		local v4484 = (v4481 - v4479).Magnitude
		local v4485 = Vector3.new(1.05, 1.05, v4484)
		local v4486 = CFrame.lookAt(v4483, v4481)
		local v4487 = v_u_27(p4047, "SnakeTail", v4485, v4482, v4477)
		local v4488 = v4050.CFrame
		local v4489 = p4047.s
		v4487.CFrame = v4488 * (v4486.Rotation + v4486.Position * v4489)
		local v4490 = Instance.new("WeldConstraint")
		v4490.Part0 = v4050
		v4490.Part1 = v4487
		v4490.Parent = v4487
		local v4491 = v_u_57(p4047, v4050, "SnakeCoil", Vector3.new(0.3, 0.3, 0.3), p4047.pants, CFrame.new(0, v4476 + 0.55, 1.1), CFrame.identity, Vector3.new(0, 1, 0), 0.3, 2.5, 0, {
			["hidden"] = true
		})
		local v4492 = {
			Vector3.new(0, 0, 0),
			Vector3.new(0.7, -0.1, 1.5),
			Vector3.new(-0.1, -0.1, 2.9),
			Vector3.new(-0.9, 0.05, 4),
			Vector3.new(-0.7, 0.5, 4.8)
		}
		local v4493 = {
			0.95,
			0.8,
			0.62,
			0.42
		}
		for v4494 = 1, 4 do
			local v4495 = v4492[v4494]
			local v4496 = v4492[v4494 + 1]
			local v4497 = v4493[v4494]
			local v4498 = p4047.pants
			local v4499 = (v4495 + v4496) / 2
			local v4500 = (v4496 - v4495).Magnitude
			local v4501 = Vector3.new(v4497, v4497, v4500)
			local v4502 = CFrame.lookAt(v4499, v4496)
			local v4503 = v_u_27(p4047, "SnakeTail", v4501, v4498, v4477)
			local v4504 = v4491.CFrame
			local v4505 = p4047.s
			v4503.CFrame = v4504 * (v4502.Rotation + v4502.Position * v4505)
			local v4506 = Instance.new("WeldConstraint")
			v4506.Part0 = v4491
			v4506.Part1 = v4503
			v4506.Parent = v4503
			local v4507 = v4493[v4494] / 2
			local v4508 = Vector3.new(0, v4507, 0)
			local v4509 = v4492[v4494] + v4508
			local v4510 = v4492[v4494 + 1] + v4508
			local v4511 = p4047.glow
			local v4512 = (v4509 + v4510) / 2
			local v4513 = (v4510 - v4509).Magnitude
			local v4514 = Vector3.new(0.16, 0.16, v4513)
			local v4515 = CFrame.lookAt(v4512, v4510)
			local v4516 = v_u_27(p4047, "SnakeStripe", v4514, v4511, v4058)
			local v4517 = v4491.CFrame
			local v4518 = p4047.s
			v4516.CFrame = v4517 * (v4515.Rotation + v4515.Position * v4518)
			local v4519 = Instance.new("WeldConstraint")
			v4519.Part0 = v4491
			v4519.Part1 = v4516
			v4519.Parent = v4516
		end
		local v4520 = p4047.glow
		local v4521 = CFrame.new(v4492[5]) * v_u_3145
		local v4522 = v_u_27(p4047, "SnakeTip", Vector3.new(0.34, 0.34, 0.34), v4520, v4058)
		local v4523 = v4491.CFrame
		local v4524 = p4047.s
		v4522.CFrame = v4523 * (v4521.Rotation + v4521.Position * v4524)
		local v4525 = Instance.new("WeldConstraint")
		v4525.Part0 = v4491
		v4525.Part1 = v4522
		v4525.Parent = v4522
	end
	local v4526 = p4047.look.gear
	local v4527
	if v4526 == nil then
		v4527 = false
	else
		v4527 = table.find(v4526, "drips") ~= nil
	end
	if v4527 then
		local v4528 = {
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.8,
				["on"] = v4050,
				["at"] = CFrame.new(-0.7, -v4054 / 2 + 0.1, v4055 - 0.05)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.55,
				["on"] = v4050,
				["at"] = CFrame.new(0.4, -v4054 / 2 + 0.05, v4055 - 0.05)
			},
			{
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.6,
				["on"] = v4050,
				["at"] = CFrame.new(0.9, v4054 / 2 - 0.2, v4055 - 0.05)
			}
		}
		for _, v4529 in v4059 do
			local v4530 = {
				["on"] = nil,
				["at"] = nil,
				["len"] = 0.7,
				["on"] = v4529,
				["at"] = CFrame.new(0, -v4053.Y / 2 + 0.1, -(v4053.Z / 2))
			}
			table.insert(v4528, v4530)
		end
		for _, v4531 in v4528 do
			local v4532 = v4531.on
			local v4533 = v4531.len
			local v4534 = Vector3.new(0.18, v4533, 0.18)
			local v4535 = p4047.glow
			local v4536 = v4531.at * CFrame.new(0, -v4531.len / 2, 0)
			local v4537 = v_u_27(p4047, "Drip", v4534, v4535, v4058)
			local v4538 = v4532.CFrame
			local v4539 = p4047.s
			v4537.CFrame = v4538 * (v4536.Rotation + v4536.Position * v4539)
			local v4540 = Instance.new("WeldConstraint")
			v4540.Part0 = v4532
			v4540.Part1 = v4537
			v4540.Parent = v4537
			local v4541 = v4531.on
			local v4542 = p4047.glow
			local v4543 = v4531.at * CFrame.new(0, -v4531.len - 0.05, 0)
			local v4544 = v_u_27(p4047, "Drop", Vector3.new(0.3, 0.3, 0.3), v4542, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v4545 = v4541.CFrame
			local v4546 = p4047.s
			v4544.CFrame = v4545 * (v4543.Rotation + v4543.Position * v4546)
			local v4547 = Instance.new("WeldConstraint")
			v4547.Part0 = v4541
			v4547.Part1 = v4544
			v4547.Parent = v4544
		end
	end
	local v4548 = p4047.look.gear
	local v4549
	if v4548 == nil then
		v4549 = false
	else
		v4549 = table.find(v4548, "moondisc") ~= nil
	end
	if v4549 then
		local v4550 = CFrame.new(0, v4054 / 2 + 0.5, v4052.Z / 2 + 0.4) * CFrame.Angles(0, 1.5707963267948966, 0)
		local v4551 = v_u_27(p4047, "BloodMoon", Vector3.new(0.14, 2.6, 2.6), p4047.glow, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Cylinder
		})
		local v4552 = v4050.CFrame
		local v4553 = p4047.s
		v4551.CFrame = v4552 * (v4550.Rotation + v4550.Position * v4553)
		local v4554 = Instance.new("WeldConstraint")
		v4554.Part0 = v4050
		v4554.Part1 = v4551
		v4554.Parent = v4551
		for _, v4555 in {
			{ 0.4, 0.35, 0.6 },
			{ -0.5, -0.2, 0.45 },
			{ 0.2, -0.6, 0.35 }
		} do
			local v4556 = v4555[3]
			local v4557 = v4555[3]
			local v4558 = Vector3.new(0.16, v4556, v4557)
			local v4559 = p4047.glow:Lerp(v_u_7, 0.35)
			local v4560 = v4550 * CFrame.new(0, v4555[2], v4555[1])
			local v4561 = v_u_27(p4047, "Crater", v4558, v4559, {
				["shape"] = Enum.PartType.Cylinder
			})
			local v4562 = v4050.CFrame
			local v4563 = p4047.s
			v4561.CFrame = v4562 * (v4560.Rotation + v4560.Position * v4563)
			local v4564 = Instance.new("WeldConstraint")
			v4564.Part0 = v4050
			v4564.Part1 = v4561
			v4564.Parent = v4561
		end
	end
	local v4565 = p4047.look.gear
	local v4566
	if v4565 == nil then
		v4566 = false
	else
		v4566 = table.find(v4565, "shimenawa") ~= nil
	end
	if v4566 then
		local v4567 = Color3.fromRGB(214, 190, 130)
		local v4568 = -v4054 / 2 + 0.25
		for _, v4569 in { 0.07, -0.07 } do
			local v4570 = v4052.X + 0.4
			local v4571 = v4052.Z + 0.4
			local v4572 = Vector3.new(v4570, 0.3, v4571)
			local v4573 = CFrame.new(0, v4568, 0) * CFrame.Angles(0, 0, v4569)
			local v4574 = v_u_27(p4047, "Rope", v4572, v4567, v4056)
			local v4575 = v4050.CFrame
			local v4576 = p4047.s
			v4574.CFrame = v4575 * (v4573.Rotation + v4573.Position * v4576)
			local v4577 = Instance.new("WeldConstraint")
			v4577.Part0 = v4050
			v4577.Part1 = v4574
			v4577.Parent = v4574
		end
		for _, v4578 in { -0.6, 0, 0.6 } do
			for v4579 = 0, 2 do
				local v4580 = v_u_13
				local v4581, v4582 = CFrame.new(v4578 * v4052.X / 2 + (v4579 % 2 == 0 and 0.07 or -0.07), v4568 - 0.3 - v4579 * 0.26, v4055 - 0.24)
				local v4583 = v_u_27(p4047, "Shide", Vector3.new(0.3, 0.28, 0.04), v4580, v4582)
				local v4584 = v4050.CFrame
				local v4585 = p4047.s
				v4583.CFrame = v4584 * (v4581.Rotation + v4581.Position * v4585)
				local v4586 = Instance.new("WeldConstraint")
				v4586.Part0 = v4050
				v4586.Part1 = v4583
				v4586.Parent = v4583
			end
		end
	end
	local v4587 = p4047.look.gear
	local v4588
	if v4587 == nil then
		v4588 = false
	else
		v4588 = table.find(v4587, "rift") ~= nil
	end
	if v4588 then
		local v4589 = {}
		local v4590 = v4054 / 2
		local v4591 = v4055 - 0.04
		local v4592 = Vector3.new(0.1, v4590, v4591)
		local v4593 = v4054 * 0.2
		local v4594 = v4055 - 0.04
		local v4595 = Vector3.new(-0.2, v4593, v4594)
		local v4596 = -v4054 * 0.1
		local v4597 = v4055 - 0.04
		local v4598 = Vector3.new(0.18, v4596, v4597)
		local v4599 = -v4054 * 0.35
		local v4600 = v4055 - 0.04
		local v4601 = Vector3.new(-0.12, v4599, v4600)
		local v4602 = -v4054 / 2 - 0.3
		local v4603 = v4055 - 0.1
		__set_list(v4589, 1, {v4592, v4595, v4598, v4601, (Vector3.new(0.05, v4602, v4603))})
		for v4604 = 1, #v4589 - 1 do
			local v4605 = v4589[v4604]
			local v4606 = v4589[v4604 + 1]
			local v4607 = p4047.glow
			local v4608 = (v4605 + v4606) / 2
			local v4609 = (v4606 - v4605).Magnitude
			local v4610 = Vector3.new(0.16, 0.16, v4609)
			local v4611 = CFrame.lookAt(v4608, v4606)
			local v4612 = v_u_27(p4047, "Rift", v4610, v4607, v4058)
			local v4613 = v4050.CFrame
			local v4614 = p4047.s
			v4612.CFrame = v4613 * (v4611.Rotation + v4611.Position * v4614)
			local v4615 = Instance.new("WeldConstraint")
			v4615.Part0 = v4050
			v4615.Part1 = v4612
			v4615.Parent = v4612
		end
		local v4616 = p4047.eye
		local v4617 = CFrame.new(-0.02, v4054 * 0.05, v4055 - 0.06) * v_u_3145
		local v4618 = v_u_27(p4047, "RiftCore", Vector3.new(0.5, 0.5, 0.06), v4616, v4058)
		local v4619 = v4050.CFrame
		local v4620 = p4047.s
		v4618.CFrame = v4619 * (v4617.Rotation + v4617.Position * v4620)
		local v4621 = Instance.new("WeldConstraint")
		v4621.Part0 = v4050
		v4621.Part1 = v4618
		v4621.Parent = v4618
	end
end
local function v_u_4711(p4623, p4624) -- name: beastGear3
	-- upvalues: (copy) v_u_27, (copy) v_u_3145, (copy) v_u_3142
	local v4625 = p4624.torso
	local v4626 = v4625.Size / p4623.s
	local v4627 = {
		["neon"] = true
	}
	local v4628 = p4623.look.gear
	local v4629
	if v4628 == nil then
		v4629 = false
	else
		v4629 = table.find(v4628, "ribs") ~= nil
	end
	if v4629 then
		for _, v4630 in { -1, 1 } do
			for v4631 = -1.5, 1.5 do
				local v4632 = v4626.Y * 0.72
				local v4633 = Vector3.new(0.1, v4632, 0.22)
				local v4634 = p4623.skin
				local v4635 = CFrame.new(v4630 * (v4626.X / 2 + 0.03), -0.05, v4631 * v4626.Z * 0.16) * CFrame.Angles(0, 0, v4630 * 0.12)
				local v4636 = Instance.new("Part")
				v4636.Name = "Rib"
				v4636.Size = v4633 * p4623.s
				v4636.Color = v4634
				v4636.Material = Enum.Material.Plastic
				v4636.CanCollide = false
				v4636.CanTouch = false
				v4636.CanQuery = false
				v4636.Massless = true
				v4636.Anchored = false
				v4636.CastShadow = v4633.Magnitude > 1.1
				v4636.TopSurface = Enum.SurfaceType.Smooth
				v4636.BottomSurface = Enum.SurfaceType.Smooth
				v4636.Parent = p4623.model
				local v4637 = v4625.CFrame
				local v4638 = p4623.s
				v4636.CFrame = v4637 * (v4635.Rotation + v4635.Position * v4638)
				local v4639 = Instance.new("WeldConstraint")
				v4639.Part0 = v4625
				v4639.Part1 = v4636
				v4639.Parent = v4636
			end
		end
		local v4640 = v4626.Z * 0.85
		local v4641 = Vector3.new(0.3, 0.18, v4640)
		local v4642 = p4623.skin
		local v4643, v4644 = CFrame.new(0, v4626.Y / 2 + 0.05, 0)
		local v4645 = v_u_27(p4623, "Spine", v4641, v4642, v4644)
		local v4646 = v4625.CFrame
		local v4647 = p4623.s
		v4645.CFrame = v4646 * (v4643.Rotation + v4643.Position * v4647)
		local v4648 = Instance.new("WeldConstraint")
		v4648.Part0 = v4625
		v4648.Part1 = v4645
		v4648.Parent = v4645
	end
	local v4649 = p4623.look.gear
	local v4650
	if v4649 == nil then
		v4650 = false
	else
		v4650 = table.find(v4649, "thorns") ~= nil
	end
	if v4650 then
		for _, v4651 in {
			{
				0,
				1,
				-0.45,
				1.1
			},
			{
				0,
				1,
				0.05,
				1
			},
			{
				0,
				1,
				0.5,
				0.8
			},
			{
				1,
				0.45,
				-0.25,
				0.75
			},
			{
				-1,
				0.5,
				0.1,
				0.75
			},
			{
				1,
				0.3,
				0.45,
				0.6
			},
			{
				-1,
				0.25,
				-0.45,
				0.6
			}
		} do
			local v4652 = v4651[1] * v4626.X / 2
			local v4653 = v4651[2] * v4626.Y / 2
			local v4654 = v4651[3] * v4626.Z / 2
			local v4655 = Vector3.new(v4652, v4653, v4654)
			local v4656 = v4651[1] * 0.9
			local v4657 = v4651[2] + 0.2
			local v4658 = v4655 + Vector3.new(v4656, v4657, 0.45).Unit * v4651[4]
			local v4659 = p4623.trim
			local v4660 = (v4655 + v4658) / 2
			local v4661 = (v4658 - v4655).Magnitude
			local v4662 = Vector3.new(0.22, 0.22, v4661)
			local v4663 = CFrame.lookAt(v4660, v4658)
			local v4664 = Instance.new("Part")
			v4664.Name = "Thorn"
			v4664.Size = v4662 * p4623.s
			v4664.Color = v4659
			v4664.Material = Enum.Material.Plastic
			v4664.CanCollide = false
			v4664.CanTouch = false
			v4664.CanQuery = false
			v4664.Massless = true
			v4664.Anchored = false
			v4664.CastShadow = v4662.Magnitude > 1.1
			v4664.TopSurface = Enum.SurfaceType.Smooth
			v4664.BottomSurface = Enum.SurfaceType.Smooth
			v4664.Parent = p4623.model
			local v4665 = v4625.CFrame
			local v4666 = p4623.s
			v4664.CFrame = v4665 * (v4663.Rotation + v4663.Position * v4666)
			local v4667 = Instance.new("WeldConstraint")
			v4667.Part0 = v4625
			v4667.Part1 = v4664
			v4667.Parent = v4664
			local v4668 = p4623.glow
			local v4669 = CFrame.new(v4658) * v_u_3145
			local v4670 = v_u_27(p4623, "ThornTip", Vector3.new(0.18, 0.18, 0.18), v4668, v4627)
			local v4671 = v4625.CFrame
			local v4672 = p4623.s
			v4670.CFrame = v4671 * (v4669.Rotation + v4669.Position * v4672)
			local v4673 = Instance.new("WeldConstraint")
			v4673.Part0 = v4625
			v4673.Part1 = v4670
			v4673.Parent = v4670
		end
	end
	local v4674 = p4623.look.gear
	local v4675
	if v4674 == nil then
		v4675 = false
	else
		v4675 = table.find(v4674, "icicles") ~= nil
	end
	if v4675 then
		local v4676 = {
			["material"] = Enum.Material.Ice
		}
		for v4677, v4678 in {
			-0.55,
			-0.15,
			0.25,
			0.6
		} do
			local v4679 = v4677 % 2 == 1
			local v4680 = v4677 % 2 == 0 and 0.2 or -0.2
			local v4681 = v4626.Y / 2 - 0.1
			local v4682 = v4678 * v4626.Z / 2
			local v4683 = Vector3.new(v4680, v4681, v4682)
			local v4684 = v4683.X * 1.5
			local v4685 = 1 - v4677 * 0.1
			local v4686 = v4683 + Vector3.new(v4684, v4685, 0.25)
			local v4687
			if v4679 then
				v4687 = p4623.glow
			else
				v4687 = v_u_3142
			end
			local v4688
			if v4679 then
				v4688 = v4627
			else
				v4688 = v4676
			end
			local v4689 = (v4683 + v4686) / 2
			local v4690 = (v4686 - v4683).Magnitude
			local v4691 = Vector3.new(0.3, 0.3, v4690)
			local v4692 = CFrame.lookAt(v4689, v4686)
			local v4693 = v_u_27(p4623, "IceShard", v4691, v4687, v4688)
			local v4694 = v4625.CFrame
			local v4695 = p4623.s
			v4693.CFrame = v4694 * (v4692.Rotation + v4692.Position * v4695)
			local v4696 = Instance.new("WeldConstraint")
			v4696.Part0 = v4625
			v4696.Part1 = v4693
			v4696.Parent = v4693
		end
		for _, v4697 in { -0.35, 0.05, 0.4 } do
			local v4698 = -v4626.Y / 2 + 0.05
			local v4699 = v4697 * v4626.Z / 2
			local v4700 = Vector3.new(0, v4698, v4699)
			local v4701 = v4700 + Vector3.new(0, -0.55, 0)
			local v4702 = v_u_3142
			local v4703 = (v4700 + v4701) / 2
			local v4704 = (v4701 - v4700).Magnitude
			local v4705 = Vector3.new(0.18, 0.18, v4704)
			local v4706 = CFrame.lookAt(v4703, v4701)
			local v4707 = v_u_27(p4623, "Icicle", v4705, v4702, v4676)
			local v4708 = v4625.CFrame
			local v4709 = p4623.s
			v4707.CFrame = v4708 * (v4706.Rotation + v4706.Position * v4709)
			local v4710 = Instance.new("WeldConstraint")
			v4710.Part0 = v4625
			v4710.Part1 = v4707
			v4710.Parent = v4707
		end
	end
end
v_u_2627.boar = {
	["torso"] = Vector3.new(2.1, 1.7, 3),
	["head"] = Vector3.new(1.5, 1.35, 1.3),
	["neck"] = Vector3.new(0, 0.2, -1.55),
	["snout"] = Vector3.new(0.85, 0.75, 0.75),
	["leg"] = Vector3.new(0.6, 1.2, 0.6),
	["legX"] = 0.65,
	["legZ"] = 1
}
v_u_2627.lynx = {
	["torso"] = Vector3.new(1.55, 1.25, 2.8),
	["head"] = Vector3.new(1.3, 1.15, 1.15),
	["neck"] = Vector3.new(0, 0.5, -1.4),
	["snout"] = Vector3.new(0.75, 0.42, 0.42),
	["leg"] = Vector3.new(0.48, 1.5, 0.48),
	["legX"] = 0.5,
	["legZ"] = 1
}
v_u_2627.ram = {
	["torso"] = Vector3.new(1.9, 1.6, 2.8),
	["head"] = Vector3.new(1.1, 1.15, 1.3),
	["neck"] = Vector3.new(0, 0.65, -1.45),
	["snout"] = Vector3.new(0.65, 0.55, 0.6),
	["leg"] = Vector3.new(0.42, 1.5, 0.42),
	["legX"] = 0.55,
	["legZ"] = 1
}
v_u_2627.hare = {
	["torso"] = Vector3.new(1.35, 1.25, 2),
	["head"] = Vector3.new(1.15, 1.1, 1.1),
	["neck"] = Vector3.new(0, 0.6, -1.05),
	["snout"] = Vector3.new(0.5, 0.38, 0.3),
	["leg"] = Vector3.new(0.4, 1.3, 0.4),
	["legX"] = 0.42,
	["legZ"] = 0.75
}
v_u_2627.cerberus = {
	["torso"] = Vector3.new(1.9, 1.6, 3.3),
	["head"] = Vector3.new(1.3, 1.2, 1.25),
	["neck"] = Vector3.new(0, 0.6, -1.65),
	["snout"] = Vector3.new(0.75, 0.55, 0.9),
	["leg"] = Vector3.new(0.55, 1.65, 0.55),
	["legX"] = 0.6,
	["legZ"] = 1.15
}
v_u_2627.lizard = {
	["torso"] = Vector3.new(1.5, 0.85, 3),
	["head"] = Vector3.new(1.2, 0.75, 1.15),
	["neck"] = Vector3.new(0, 0.12, -1.55),
	["snout"] = Vector3.new(0.85, 0.45, 0.65),
	["leg"] = Vector3.new(0.5, 0.85, 0.5),
	["legX"] = 0.85,
	["legZ"] = 1
}
v_u_2627.seal = {
	["torso"] = Vector3.new(2, 1.45, 2.8),
	["head"] = Vector3.new(1.3, 1.15, 1.2),
	["neck"] = Vector3.new(0, 0.45, -1.45),
	["snout"] = Vector3.new(0.85, 0.5, 0.5),
	["leg"] = Vector3.new(0.8, 0.55, 0.95),
	["legX"] = 0.75,
	["legZ"] = 0.95
}
local function v_u_5034(p4712, p4713, p4714) -- name: dressBeast
	-- upvalues: (copy) v_u_2627, (copy) v_u_27, (copy) v_u_13, (copy) v_u_7, (copy) v_u_8
	local v4715 = v_u_2627[p4714]
	local v4716 = p4713.head
	local v4717 = p4713.torso
	local v4718 = v4715.head
	local v4719 = v4715.torso
	local v4720 = -v4718.Z / 2
	local v4721 = {
		["material"] = p4712.mat
	}
	local v4722 = {
		["neon"] = true
	}
	local v4723 = p4713.tail
	if v4723 then
		v4723 = p4713.tail.Part1
	end
	if p4714 == "boar" then
		for _, v4724 in { -1, 1 } do
			local v4725 = p4712.skin
			local v4726 = CFrame.new(v4724 * v4718.X * 0.38, v4718.Y / 2 + 0.05, 0.25) * CFrame.Angles(0.3, 0, -v4724 * 0.6)
			local v4727 = v_u_27(p4712, "Ear", Vector3.new(0.5, 0.45, 0.18), v4725, v4721)
			local v4728 = v4716.CFrame
			local v4729 = p4712.s
			v4727.CFrame = v4728 * (v4726.Rotation + v4726.Position * v4729)
			local v4730 = Instance.new("WeldConstraint")
			v4730.Part0 = v4716
			v4730.Part1 = v4727
			v4730.Parent = v4727
			local v4731 = v4724 * 0.3
			local v4732 = -v4718.Y * 0.35
			local v4733 = v4720 - 0.55
			local v4734 = Vector3.new(v4731, v4732, v4733)
			local v4735 = v4724 * 0.5
			local v4736 = -v4718.Y * 0.22
			local v4737 = v4720 - 0.95
			local v4738 = Vector3.new(v4735, v4736, v4737)
			local v4739 = v4724 * 0.52
			local v4740 = v4718.Y * 0.08
			local v4741 = v4720 - 1.05
			local v4742 = Vector3.new(v4739, v4740, v4741)
			local v4743 = p4712.accent
			local v4744 = (v4734 + v4738) / 2
			local v4745 = (v4738 - v4734).Magnitude
			local v4746 = Vector3.new(0.22, 0.22, v4745)
			local v4747 = CFrame.lookAt(v4744, v4738)
			local v4748 = Instance.new("Part")
			v4748.Name = "Tusk"
			v4748.Size = v4746 * p4712.s
			v4748.Color = v4743
			v4748.Material = Enum.Material.Plastic
			v4748.CanCollide = false
			v4748.CanTouch = false
			v4748.CanQuery = false
			v4748.Massless = true
			v4748.Anchored = false
			v4748.CastShadow = v4746.Magnitude > 1.1
			v4748.TopSurface = Enum.SurfaceType.Smooth
			v4748.BottomSurface = Enum.SurfaceType.Smooth
			v4748.Parent = p4712.model
			local v4749 = v4716.CFrame
			local v4750 = p4712.s
			v4748.CFrame = v4749 * (v4747.Rotation + v4747.Position * v4750)
			local v4751 = Instance.new("WeldConstraint")
			v4751.Part0 = v4716
			v4751.Part1 = v4748
			v4751.Parent = v4748
			local v4752 = p4712.glow
			local v4753 = (v4738 + v4742) / 2
			local v4754 = (v4742 - v4738).Magnitude
			local v4755 = Vector3.new(0.18, 0.18, v4754)
			local v4756 = CFrame.lookAt(v4753, v4742)
			local v4757 = v_u_27(p4712, "TuskTip", v4755, v4752, v4722)
			local v4758 = v4716.CFrame
			local v4759 = p4712.s
			v4757.CFrame = v4758 * (v4756.Rotation + v4756.Position * v4759)
			local v4760 = Instance.new("WeldConstraint")
			v4760.Part0 = v4716
			v4760.Part1 = v4757
			v4760.Parent = v4757
		end
		for v4761, v4762 in {
			-1.1,
			-0.5,
			0.1,
			0.7
		} do
			local v4763 = 0.8 - v4761 * 0.08
			local v4764 = Vector3.new(0.3, v4763, 0.45)
			local v4765 = p4712.trim
			local v4766 = CFrame.new(0, v4719.Y / 2 + 0.2, v4762) * CFrame.Angles(-0.45, 0, 0)
			local v4767 = v_u_27(p4712, "Bristle", v4764, v4765, v4721)
			local v4768 = v4717.CFrame
			local v4769 = p4712.s
			v4767.CFrame = v4768 * (v4766.Rotation + v4766.Position * v4769)
			local v4770 = Instance.new("WeldConstraint")
			v4770.Part0 = v4717
			v4770.Part1 = v4767
			v4770.Parent = v4767
		end
	elseif p4714 == "lynx" then
		for _, v4771 in { -1, 1 } do
			local v4772 = p4712.skin
			local v4773 = CFrame.new(v4771 * v4718.X * 0.32, v4718.Y / 2 + 0.05, 0.15) * CFrame.Angles(0, 0, 0.7853981633974483 - v4771 * 0.15)
			local v4774 = v_u_27(p4712, "Ear", Vector3.new(0.55, 0.55, 0.2), v4772, v4721)
			local v4775 = v4716.CFrame
			local v4776 = p4712.s
			v4774.CFrame = v4775 * (v4773.Rotation + v4773.Position * v4776)
			local v4777 = Instance.new("WeldConstraint")
			v4777.Part0 = v4716
			v4777.Part1 = v4774
			v4777.Parent = v4774
			local v4778 = p4712.accent
			local v4779 = CFrame.new(v4771 * v4718.X * 0.36, v4718.Y / 2 + 0.6, 0.15) * CFrame.Angles(0, 0, -v4771 * 0.15)
			local v4780 = Instance.new("Part")
			v4780.Name = "EarTuft"
			v4780.Size = Vector3.new(0.08, 0.5, 0.08) * p4712.s
			v4780.Color = v4778
			v4780.Material = Enum.Material.Plastic
			v4780.CanCollide = false
			v4780.CanTouch = false
			v4780.CanQuery = false
			v4780.Massless = true
			v4780.Anchored = false
			v4780.CastShadow = (Vector3.new(0.08, 0.5, 0.08)).Magnitude > 1.1
			v4780.TopSurface = Enum.SurfaceType.Smooth
			v4780.BottomSurface = Enum.SurfaceType.Smooth
			v4780.Parent = p4712.model
			local v4781 = v4716.CFrame
			local v4782 = p4712.s
			v4780.CFrame = v4781 * (v4779.Rotation + v4779.Position * v4782)
			local v4783 = Instance.new("WeldConstraint")
			v4783.Part0 = v4716
			v4783.Part1 = v4780
			v4783.Parent = v4780
			local v4784 = p4712.trim
			local v4785 = CFrame.new(v4771 * (v4718.X / 2 + 0.12), -v4718.Y * 0.2, 0.15) * CFrame.Angles(0, 0, v4771 * 0.35)
			local v4786 = v_u_27(p4712, "Ruff", Vector3.new(0.45, 0.75, 0.7), v4784, v4721)
			local v4787 = v4716.CFrame
			local v4788 = p4712.s
			v4786.CFrame = v4787 * (v4785.Rotation + v4785.Position * v4788)
			local v4789 = Instance.new("WeldConstraint")
			v4789.Part0 = v4716
			v4789.Part1 = v4786
			v4789.Parent = v4786
			for v4790, v4791 in {
				{ 0.15, -0.6 },
				{ -0.2, 0 },
				{ 0.2, 0.6 }
			} do
				local v4792 = 0.26 + v4790 * 0.03
				local v4793 = Vector3.new(0.05, v4792, 0.32)
				local v4794 = p4712.accent
				local v4795, v4796 = CFrame.new(v4771 * (v4719.X / 2 + 0.02), v4791[1], v4791[2])
				local v4797 = v_u_27(p4712, "Spot", v4793, v4794, v4796)
				local v4798 = v4717.CFrame
				local v4799 = p4712.s
				v4797.CFrame = v4798 * (v4795.Rotation + v4795.Position * v4799)
				local v4800 = Instance.new("WeldConstraint")
				v4800.Part0 = v4717
				v4800.Part1 = v4797
				v4800.Parent = v4797
			end
		end
		if v4723 then
			local v4801 = p4712.accent
			local v4802 = CFrame.new(0, 0, 0.3)
			local v4803 = v_u_27(p4712, "TailTip", Vector3.new(0.4, 0.4, 0.3), v4801, v4721)
			local v4804 = v4723.CFrame
			local v4805 = p4712.s
			v4803.CFrame = v4804 * (v4802.Rotation + v4802.Position * v4805)
			local v4806 = Instance.new("WeldConstraint")
			v4806.Part0 = v4723
			v4806.Part1 = v4803
			v4806.Parent = v4803
			return
		end
	else
		if p4714 == "ram" then
			local v4807 = {
				["shape"] = Enum.PartType.Ball,
				["material"] = p4712.mat
			}
			for _, v4808 in {
				Vector3.new(0.5, 0.65, -0.6),
				Vector3.new(-0.5, 0.65, -0.6),
				Vector3.new(0.45, 0.7, 0.6),
				Vector3.new(-0.45, 0.7, 0.6)
			} do
				local v4809 = p4712.shirt
				local v4810 = CFrame.new(v4808)
				local v4811 = v_u_27(p4712, "Wool", Vector3.new(1.15, 1.15, 1.15), v4809, v4807)
				local v4812 = v4717.CFrame
				local v4813 = p4712.s
				v4811.CFrame = v4812 * (v4810.Rotation + v4810.Position * v4813)
				local v4814 = Instance.new("WeldConstraint")
				v4814.Part0 = v4717
				v4814.Part1 = v4811
				v4814.Parent = v4811
			end
			for _, v4815 in { -1, 1 } do
				local v4816 = CFrame.new(v4815 * (v4718.X / 2 + 0.2), v4718.Y * 0.12, 0.1)
				for v4817 = 0, 4 do
					local v4818 = 0.42 - v4817 * 0.05
					local v4819 = v4817 == 4
					local v4820 = Vector3.new(v4818, v4818, 0.6)
					local v4821
					if v4819 then
						v4821 = p4712.glow
					else
						v4821 = p4712.accent
					end
					local v4822 = v4816 * CFrame.new(v4815 * 0.07 * v4817, 0, 0) * CFrame.Angles(v4817 * 1.15, 0, 0) * CFrame.new(0, 0.5, 0)
					local v4823
					if v4819 then
						v4823 = v4722
					else
						v4823 = v4721
					end
					local v4824 = v_u_27(p4712, "Horn", v4820, v4821, v4823)
					local v4825 = v4716.CFrame
					local v4826 = p4712.s
					v4824.CFrame = v4825 * (v4822.Rotation + v4822.Position * v4826)
					local v4827 = Instance.new("WeldConstraint")
					v4827.Part0 = v4716
					v4827.Part1 = v4824
					v4827.Parent = v4824
				end
			end
			return
		end
		if p4714 == "hare" then
			for _, v4828 in { -1, 1 } do
				local v4829 = p4712.skin
				local v4830 = CFrame.new(v4828 * 0.28, v4718.Y / 2 + 0.68, 0.15) * CFrame.Angles(0.2, 0, -v4828 * 0.15)
				local v4831 = v_u_27(p4712, "Ear", Vector3.new(0.32, 1.5, 0.16), v4829, v4721)
				local v4832 = v4716.CFrame
				local v4833 = p4712.s
				v4831.CFrame = v4832 * (v4830.Rotation + v4830.Position * v4833)
				local v4834 = Instance.new("WeldConstraint")
				v4834.Part0 = v4716
				v4834.Part1 = v4831
				v4834.Parent = v4831
				local v4835 = p4712.accent
				local v4836 = CFrame.new(0, -0.05, -0.08)
				local v4837 = v_u_27(p4712, "EarInner", Vector3.new(0.16, 1.1, 0.05), v4835, v4722)
				local v4838 = v4831.CFrame
				local v4839 = p4712.s
				v4837.CFrame = v4838 * (v4836.Rotation + v4836.Position * v4839)
				local v4840 = Instance.new("WeldConstraint")
				v4840.Part0 = v4831
				v4840.Part1 = v4837
				v4840.Parent = v4837
			end
			for _, v4841 in { p4713.rightLeg, p4713.leftLeg } do
				local v4842 = v4841.Part1
				if not v4842 then
					continue
				end
				local v4843 = p4712.shirt
				local v4844 = CFrame.new(0, 0.3, 0.1)
				local v4845 = v_u_27(p4712, "Thigh", Vector3.new(0.7, 0.85, 1), v4843, v4721)
				local v4846 = v4842.CFrame
				local v4847 = p4712.s
				v4845.CFrame = v4846 * (v4844.Rotation + v4844.Position * v4847)
				local v4848 = Instance.new("WeldConstraint")
				v4848.Part0 = v4842
				v4848.Part1 = v4845
				v4848.Parent = v4845
			end
			local v4849 = p4712.trim
			local v4850 = CFrame.new(0, v4719.Y * 0.15, v4719.Z / 2 + 0.2)
			local v4851 = v_u_27(p4712, "Puff", Vector3.new(0.75, 0.75, 0.75), v4849, {
				["shape"] = Enum.PartType.Ball,
				["material"] = p4712.mat
			})
			local v4852 = v4717.CFrame
			local v4853 = p4712.s
			v4851.CFrame = v4852 * (v4850.Rotation + v4850.Position * v4853)
			local v4854 = Instance.new("WeldConstraint")
			v4854.Part0 = v4717
			v4854.Part1 = v4851
			v4854.Parent = v4851
			local v4855 = v_u_13
			local v4856, v4857 = CFrame.new(0, -v4718.Y * 0.38, v4720 - 0.3)
			local v4858 = v_u_27(p4712, "Teeth", Vector3.new(0.22, 0.2, 0.06), v4855, v4857)
			local v4859 = v4716.CFrame
			local v4860 = p4712.s
			v4858.CFrame = v4859 * (v4856.Rotation + v4856.Position * v4860)
			local v4861 = Instance.new("WeldConstraint")
			v4861.Part0 = v4716
			v4861.Part1 = v4858
			v4861.Parent = v4858
			return
		end
		if p4714 == "cerberus" then
			for _, v4862 in { -1, 1 } do
				local v4863 = p4712.skin
				local v4864 = CFrame.new(v4862 * 0.42, v4718.Y / 2 + 0.25, 0.2) * CFrame.Angles(0, 0, -v4862 * 0.2)
				local v4865 = v_u_27(p4712, "Ear", Vector3.new(0.32, 0.65, 0.22), v4863, v4721)
				local v4866 = v4716.CFrame
				local v4867 = p4712.s
				v4865.CFrame = v4866 * (v4864.Rotation + v4864.Position * v4867)
				local v4868 = Instance.new("WeldConstraint")
				v4868.Part0 = v4716
				v4868.Part1 = v4865
				v4868.Parent = v4865
				local v4869 = p4712.skin
				local v4870 = CFrame.new(v4862 * 1, 0.55, -1.3) * CFrame.Angles(0, -v4862 * 0.45, 0)
				local v4871 = v_u_27(p4712, "SideHead", Vector3.new(1.05, 1, 1.05), v4869, v4721)
				local v4872 = v4717.CFrame
				local v4873 = p4712.s
				v4871.CFrame = v4872 * (v4870.Rotation + v4870.Position * v4873)
				local v4874 = Instance.new("WeldConstraint")
				v4874.Part0 = v4717
				v4874.Part1 = v4871
				v4874.Parent = v4871
				local v4875 = p4712.skin
				local v4876 = CFrame.new(0, -0.2, -0.75)
				local v4877 = v_u_27(p4712, "Snout", Vector3.new(0.6, 0.45, 0.7), v4875, v4721)
				local v4878 = v4871.CFrame
				local v4879 = p4712.s
				v4877.CFrame = v4878 * (v4876.Rotation + v4876.Position * v4879)
				local v4880 = Instance.new("WeldConstraint")
				v4880.Part0 = v4871
				v4880.Part1 = v4877
				v4880.Parent = v4877
				local v4881 = v_u_7
				local v4882, v4883 = CFrame.new(0, -0.05, -1.1)
				local v4884 = v_u_27(p4712, "Nose", Vector3.new(0.25, 0.18, 0.12), v4881, v4883)
				local v4885 = v4871.CFrame
				local v4886 = p4712.s
				v4884.CFrame = v4885 * (v4882.Rotation + v4882.Position * v4886)
				local v4887 = Instance.new("WeldConstraint")
				v4887.Part0 = v4871
				v4887.Part1 = v4884
				v4887.Parent = v4884
				local v4888 = p4712.glow
				local v4889 = CFrame.new(0, -0.38, -1.08)
				local v4890 = v_u_27(p4712, "Maw", Vector3.new(0.5, 0.08, 0.05), v4888, v4722)
				local v4891 = v4871.CFrame
				local v4892 = p4712.s
				v4890.CFrame = v4891 * (v4889.Rotation + v4889.Position * v4892)
				local v4893 = Instance.new("WeldConstraint")
				v4893.Part0 = v4871
				v4893.Part1 = v4890
				v4893.Parent = v4890
				for _, v4894 in { -1, 1 } do
					local v4895 = p4712.eye
					local v4896 = CFrame.new(v4894 * 0.26, 0.15, -0.53) * CFrame.Angles(0, 0, v4894 * 0.28)
					local v4897 = v_u_27(p4712, "Eye", Vector3.new(0.26, 0.15, 0.08), v4895, v4722)
					local v4898 = v4871.CFrame
					local v4899 = p4712.s
					v4897.CFrame = v4898 * (v4896.Rotation + v4896.Position * v4899)
					local v4900 = Instance.new("WeldConstraint")
					v4900.Part0 = v4871
					v4900.Part1 = v4897
					v4900.Parent = v4897
					local v4901 = p4712.skin
					local v4902 = CFrame.new(v4894 * 0.32, 0.65, 0.15) * CFrame.Angles(0, 0, -v4894 * 0.25)
					local v4903 = v_u_27(p4712, "Ear", Vector3.new(0.26, 0.55, 0.2), v4901, v4721)
					local v4904 = v4871.CFrame
					local v4905 = p4712.s
					v4903.CFrame = v4904 * (v4902.Rotation + v4902.Position * v4905)
					local v4906 = Instance.new("WeldConstraint")
					v4906.Part0 = v4871
					v4906.Part1 = v4903
					v4906.Parent = v4903
				end
			end
			for v4907, v4908 in {
				{ 0, -1.05, 1.1 },
				{ 0.5, -0.75, 0.85 },
				{ -0.5, -0.75, 0.85 },
				{ 0, -0.2, 0.95 },
				{ 0, 0.5, 0.75 }
			} do
				local v4909 = v4908[3]
				local v4910 = Vector3.new(0.45, v4909, 0.45)
				local v4911
				if v4907 % 2 == 1 then
					v4911 = p4712.glow
				else
					v4911 = p4712.accent
				end
				local v4912 = CFrame.new(v4908[1], v4719.Y / 2 + v4908[3] * 0.3, v4908[2]) * CFrame.Angles(-0.35, 0, v4908[1] * 0.4) * CFrame.Angles(0, 0.7853981633974483, 0)
				local v4913 = v_u_27(p4712, "FlameMane", v4910, v4911, v4722)
				local v4914 = v4717.CFrame
				local v4915 = p4712.s
				v4913.CFrame = v4914 * (v4912.Rotation + v4912.Position * v4915)
				local v4916 = Instance.new("WeldConstraint")
				v4916.Part0 = v4717
				v4916.Part1 = v4913
				v4916.Parent = v4913
			end
			local v4917 = v4719.X * 0.9
			local v4918 = Vector3.new(v4917, 0.35, 0.6)
			local v4919 = v_u_7
			local v4920 = CFrame.new(0, 0.3, -v4719.Z / 2 + 0.05)
			local v4921 = v_u_27(p4712, "Collar", v4918, v4919, {
				["material"] = Enum.Material.Metal
			})
			local v4922 = v4717.CFrame
			local v4923 = p4712.s
			v4921.CFrame = v4922 * (v4920.Rotation + v4920.Position * v4923)
			local v4924 = Instance.new("WeldConstraint")
			v4924.Part0 = v4717
			v4924.Part1 = v4921
			v4924.Parent = v4921
			for _, v4925 in { -0.55, 0, 0.55 } do
				local v4926 = v_u_8
				local v4927 = CFrame.new(v4925, 0.3, -v4719.Z / 2 - 0.35) * CFrame.Angles(-1.5707963267948966, 0, 0)
				local v4928 = v_u_27(p4712, "CollarSpike", Vector3.new(0.16, 0.4, 0.16), v4926, {
					["material"] = Enum.Material.Metal
				})
				local v4929 = v4717.CFrame
				local v4930 = p4712.s
				v4928.CFrame = v4929 * (v4927.Rotation + v4927.Position * v4930)
				local v4931 = Instance.new("WeldConstraint")
				v4931.Part0 = v4717
				v4931.Part1 = v4928
				v4931.Parent = v4928
			end
			if v4723 then
				local v4932 = p4712.shirt
				local v4933 = CFrame.new(0, 0.3, 0.9) * CFrame.Angles(0.4, 0, 0)
				local v4934 = v_u_27(p4712, "Tail", Vector3.new(0.28, 0.28, 1.6), v4932, v4721)
				local v4935 = v4723.CFrame
				local v4936 = p4712.s
				v4934.CFrame = v4935 * (v4933.Rotation + v4933.Position * v4936)
				local v4937 = Instance.new("WeldConstraint")
				v4937.Part0 = v4723
				v4937.Part1 = v4934
				v4937.Parent = v4934
				local v4938 = p4712.glow
				local v4939 = CFrame.new(0, 0.65, 1.65) * CFrame.Angles(0.4, 0, 0)
				local v4940 = v_u_27(p4712, "TailFlame", Vector3.new(0.4, 0.4, 0.6), v4938, v4722)
				local v4941 = v4723.CFrame
				local v4942 = p4712.s
				v4940.CFrame = v4941 * (v4939.Rotation + v4939.Position * v4942)
				local v4943 = Instance.new("WeldConstraint")
				v4943.Part0 = v4723
				v4943.Part1 = v4940
				v4943.Parent = v4940
				return
			end
		else
			if p4714 == "lizard" then
				if v4723 then
					for _, v4944 in {
						{
							0.85,
							0.6,
							1.4,
							0.85,
							0
						},
						{
							0.62,
							0.46,
							1.3,
							2.15,
							-0.05
						},
						{
							0.4,
							0.32,
							1.2,
							3.35,
							-0.1
						}
					} do
						local v4945 = v4944[1]
						local v4946 = v4944[2]
						local v4947 = v4944[3]
						local v4948 = Vector3.new(v4945, v4946, v4947)
						local v4949 = p4712.shirt
						local v4950 = CFrame.new(0, v4944[5], v4944[4])
						local v4951 = v_u_27(p4712, "Tail", v4948, v4949, v4721)
						local v4952 = v4723.CFrame
						local v4953 = p4712.s
						v4951.CFrame = v4952 * (v4950.Rotation + v4950.Position * v4953)
						local v4954 = Instance.new("WeldConstraint")
						v4954.Part0 = v4723
						v4954.Part1 = v4951
						v4954.Parent = v4951
						local v4955 = v4944[3] * 0.9
						local v4956 = Vector3.new(0.18, 0.06, v4955)
						local v4957 = p4712.accent
						local v4958 = CFrame.new(0, v4944[2] / 2, 0)
						local v4959 = v_u_27(p4712, "TailStripe", v4956, v4957, v4722)
						local v4960 = v4951.CFrame
						local v4961 = p4712.s
						v4959.CFrame = v4960 * (v4958.Rotation + v4958.Position * v4961)
						local v4962 = Instance.new("WeldConstraint")
						v4962.Part0 = v4951
						v4962.Part1 = v4959
						v4962.Parent = v4959
					end
				end
				for _, v4963 in { -1, 1 } do
					for v4964 = 0, 2 do
						local v4965 = p4712.trim
						local v4966 = CFrame.new(v4963 * (v4718.X / 2 + 0.05), 0, 0.25) * CFrame.Angles(0.5 - v4964 * 0.45, 0, -v4963 * 1.1) * CFrame.new(0, 0.3, 0)
						local v4967 = v_u_27(p4712, "Frill", Vector3.new(0.1, 0.6, 0.1), v4965, v4722)
						local v4968 = v4716.CFrame
						local v4969 = p4712.s
						v4967.CFrame = v4968 * (v4966.Rotation + v4966.Position * v4969)
						local v4970 = Instance.new("WeldConstraint")
						v4970.Part0 = v4716
						v4970.Part1 = v4967
						v4970.Parent = v4967
					end
				end
				for _, v4971 in {
					Vector3.new(0.35, 0, -0.9),
					Vector3.new(-0.4, 0, -0.3),
					Vector3.new(0.3, 0, 0.3),
					Vector3.new(-0.3, 0, 0.9)
				} do
					local v4972 = p4712.accent
					local v4973 = CFrame.new(v4971.X, v4719.Y / 2 + 0.02, v4971.Z) * CFrame.Angles(0, 0.7853981633974483, 0)
					local v4974 = v_u_27(p4712, "Spot", Vector3.new(0.32, 0.08, 0.32), v4972, v4722)
					local v4975 = v4717.CFrame
					local v4976 = p4712.s
					v4974.CFrame = v4975 * (v4973.Rotation + v4973.Position * v4976)
					local v4977 = Instance.new("WeldConstraint")
					v4977.Part0 = v4717
					v4977.Part1 = v4974
					v4977.Parent = v4974
				end
				local v4978 = p4712.glow
				local v4979 = CFrame.new(0, -v4718.Y * 0.32, v4720 - 0.3)
				local v4980 = v_u_27(p4712, "Mouth", Vector3.new(0.9, 0.08, 0.5), v4978, v4722)
				local v4981 = v4716.CFrame
				local v4982 = p4712.s
				v4980.CFrame = v4981 * (v4979.Rotation + v4979.Position * v4982)
				local v4983 = Instance.new("WeldConstraint")
				v4983.Part0 = v4716
				v4983.Part1 = v4980
				v4983.Parent = v4980
				return
			end
			if p4714 == "seal" then
				local v4984 = v4715.snout
				local v4985 = v4720 - v4984.Z + 0.1
				for _, v4986 in { -1, 1 } do
					local v4987 = p4712.accent
					local v4988, v4989 = CFrame.new(v4986 * 0.22, -v4718.Y * 0.2 - v4984.Y / 2 - 0.4, v4985 + 0.15)
					local v4990 = v_u_27(p4712, "Tusk", Vector3.new(0.16, 0.95, 0.16), v4987, v4989)
					local v4991 = v4716.CFrame
					local v4992 = p4712.s
					v4990.CFrame = v4991 * (v4988.Rotation + v4988.Position * v4992)
					local v4993 = Instance.new("WeldConstraint")
					v4993.Part0 = v4716
					v4993.Part1 = v4990
					v4993.Parent = v4990
					local v4994 = p4712.glow
					local v4995 = CFrame.new(v4986 * 0.22, -v4718.Y * 0.2 - v4984.Y / 2 - 0.95, v4985 + 0.15)
					local v4996 = v_u_27(p4712, "TuskTip", Vector3.new(0.12, 0.25, 0.12), v4994, v4722)
					local v4997 = v4716.CFrame
					local v4998 = p4712.s
					v4996.CFrame = v4997 * (v4995.Rotation + v4995.Position * v4998)
					local v4999 = Instance.new("WeldConstraint")
					v4999.Part0 = v4716
					v4999.Part1 = v4996
					v4999.Parent = v4996
					for v5000 = -1, 1 do
						local v5001 = v4986 * 0.3
						local v5002 = -v4718.Y * 0.2 + v5000 * 0.08
						local v5003 = v4985 + 0.15
						local v5004 = Vector3.new(v5001, v5002, v5003)
						local v5005 = v4986 * 0.85
						local v5006 = -v4718.Y * 0.2 + v5000 * 0.2
						local v5007 = v4985 + 0.3
						local v5008 = Vector3.new(v5005, v5006, v5007)
						local v5009 = v_u_13
						local v5010 = (v5004 + v5008) / 2
						local v5011 = (v5008 - v5004).Magnitude
						local v5012 = Vector3.new(0.05, 0.05, v5011)
						local v5013 = CFrame.lookAt(v5010, v5008)
						local v5014 = Instance.new("Part")
						v5014.Name = "Whisker"
						v5014.Size = v5012 * p4712.s
						v5014.Color = v5009
						v5014.Material = Enum.Material.Plastic
						v5014.CanCollide = false
						v5014.CanTouch = false
						v5014.CanQuery = false
						v5014.Massless = true
						v5014.Anchored = false
						v5014.CastShadow = v5012.Magnitude > 1.1
						v5014.TopSurface = Enum.SurfaceType.Smooth
						v5014.BottomSurface = Enum.SurfaceType.Smooth
						v5014.Parent = p4712.model
						local v5015 = v4716.CFrame
						local v5016 = p4712.s
						v5014.CFrame = v5015 * (v5013.Rotation + v5013.Position * v5016)
						local v5017 = Instance.new("WeldConstraint")
						v5017.Part0 = v4716
						v5017.Part1 = v5014
						v5017.Parent = v5014
					end
				end
				for _, v5018 in { p4713.rightArm, p4713.leftArm } do
					local v5019 = v5018.Part1
					if not v5019 then
						continue
					end
					local v5020 = v5018 == p4713.rightArm and 1 or -1
					local v5021 = p4712.pants
					local v5022 = CFrame.new(v5020 * 0.45, -v4715.leg.Y / 2 + 0.08, -0.1) * CFrame.Angles(0, -v5020 * 0.3, 0)
					local v5023 = v_u_27(p4712, "Flipper", Vector3.new(1.1, 0.12, 0.7), v5021, v4721)
					local v5024 = v5019.CFrame
					local v5025 = p4712.s
					v5023.CFrame = v5024 * (v5022.Rotation + v5022.Position * v5025)
					local v5026 = Instance.new("WeldConstraint")
					v5026.Part0 = v5019
					v5026.Part1 = v5023
					v5026.Parent = v5023
				end
				if v4723 then
					for _, v5027 in { -1, 1 } do
						local v5028 = p4712.pants
						local v5029 = CFrame.new(v5027 * 0.35, 0, 0.35) * CFrame.Angles(0, v5027 * 0.5, 0)
						local v5030 = v_u_27(p4712, "Fluke", Vector3.new(0.8, 0.12, 0.55), v5028, v4721)
						local v5031 = v4723.CFrame
						local v5032 = p4712.s
						v5030.CFrame = v5031 * (v5029.Rotation + v5029.Position * v5032)
						local v5033 = Instance.new("WeldConstraint")
						v5033.Part0 = v4723
						v5033.Part1 = v5030
						v5033.Parent = v5030
					end
				end
			end
		end
	end
end
local function v5225(p5035, p5036, p5037) -- name: flyer
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_13, (copy) v_u_3145, (copy) v_u_7, (copy) v_u_57, (copy) v_u_10, (copy) v_u_2573, (copy) v_u_15
	local v5038 = p5037 == "bat"
	local v5039 = {
		["material"] = p5035.mat
	}
	local v5040 = {
		["neon"] = true
	}
	local v5041 = v5038 and Vector3.new(1.25, 1.35, 1.3) or Vector3.new(1.3, 1.2, 2)
	local v5042, v5043 = v_u_40(p5035, p5036, "Torso", v5041, p5035.shirt, CFrame.identity, CFrame.identity, v5039)
	local v5044 = v5038 and Vector3.new(1.15, 1.05, 1) or Vector3.new(1, 0.95, 1)
	local v5045 = v_u_40
	local v5046 = "Head"
	local v5047 = p5035.skin
	local v5048
	if v5038 then
		v5048 = CFrame.new(0, v5041.Y / 2 + 0.1, -0.15)
	else
		v5048 = CFrame.new(0, 0.5, -v5041.Z / 2 - 0.1)
	end
	local v5049
	if v5038 then
		v5049 = CFrame.new(0, -v5044.Y / 2 + 0.1, 0)
	else
		v5049 = CFrame.new(0, -0.1, v5044.Z / 2 - 0.15)
	end
	local v5050, v5051 = v5045(p5035, v5042, v5046, v5044, v5047, v5048, v5049, v5039)
	local v5052 = -v5044.Z / 2
	for _, v5053 in { -1, 1 } do
		local v5054 = p5035.eye
		local v5055 = CFrame.new(v5053 * v5044.X * 0.28, v5044.Y * 0.12, v5052 - 0.03) * CFrame.Angles(0, 0, v5053 * 0.3)
		local v5056 = v_u_27(p5035, "Eye", Vector3.new(0.3, 0.17, 0.08), v5054, v5040)
		local v5057 = v5050.CFrame
		local v5058 = p5035.s
		v5056.CFrame = v5057 * (v5055.Rotation + v5055.Position * v5058)
		local v5059 = Instance.new("WeldConstraint")
		v5059.Part0 = v5050
		v5059.Part1 = v5056
		v5059.Parent = v5056
	end
	if v5038 then
		for _, v5060 in { -1, 1 } do
			local v5061 = p5035.skin
			local v5062 = CFrame.new(v5060 * 0.36, v5044.Y / 2 + 0.38, 0.05) * CFrame.Angles(0, 0, -v5060 * 0.3)
			local v5063 = v_u_27(p5035, "Ear", Vector3.new(0.42, 0.95, 0.16), v5061, v5039)
			local v5064 = v5050.CFrame
			local v5065 = p5035.s
			v5063.CFrame = v5064 * (v5062.Rotation + v5062.Position * v5065)
			local v5066 = Instance.new("WeldConstraint")
			v5066.Part0 = v5050
			v5066.Part1 = v5063
			v5066.Parent = v5063
			local v5067 = p5035.trim
			local v5068, v5069 = CFrame.new(0, -0.05, -0.08)
			local v5070 = v_u_27(p5035, "EarInner", Vector3.new(0.2, 0.6, 0.05), v5067, v5069)
			local v5071 = v5063.CFrame
			local v5072 = p5035.s
			v5070.CFrame = v5071 * (v5068.Rotation + v5068.Position * v5072)
			local v5073 = Instance.new("WeldConstraint")
			v5073.Part0 = v5063
			v5073.Part1 = v5070
			v5073.Parent = v5070
			local v5074 = v_u_13
			local v5075, v5076 = CFrame.new(v5060 * 0.13, -v5044.Y * 0.36, v5052 - 0.04)
			local v5077 = v_u_27(p5035, "Fang", Vector3.new(0.1, 0.24, 0.08), v5074, v5076)
			local v5078 = v5050.CFrame
			local v5079 = p5035.s
			v5077.CFrame = v5078 * (v5075.Rotation + v5075.Position * v5079)
			local v5080 = Instance.new("WeldConstraint")
			v5080.Part0 = v5050
			v5080.Part1 = v5077
			v5080.Parent = v5077
		end
		local v5081 = p5035.skin:Lerp(v_u_13, 0.15)
		local v5082 = CFrame.new(0, -v5044.Y * 0.12, v5052 - 0.1)
		local v5083 = v_u_27(p5035, "Nose", Vector3.new(0.46, 0.3, 0.22), v5081, v5039)
		local v5084 = v5050.CFrame
		local v5085 = p5035.s
		v5083.CFrame = v5084 * (v5082.Rotation + v5082.Position * v5085)
		local v5086 = Instance.new("WeldConstraint")
		v5086.Part0 = v5050
		v5086.Part1 = v5083
		v5086.Parent = v5083
		local v5087 = p5035.trim
		local v5088 = CFrame.new(0, 0.02, v5052 - 0.22) * v_u_3145
		local v5089 = Instance.new("Part")
		v5089.Name = "NoseLeaf"
		v5089.Size = Vector3.new(0.2, 0.2, 0.06) * p5035.s
		v5089.Color = v5087
		v5089.Material = Enum.Material.Plastic
		v5089.CanCollide = false
		v5089.CanTouch = false
		v5089.CanQuery = false
		v5089.Massless = true
		v5089.Anchored = false
		v5089.CastShadow = (Vector3.new(0.2, 0.2, 0.06)).Magnitude > 1.1
		v5089.TopSurface = Enum.SurfaceType.Smooth
		v5089.BottomSurface = Enum.SurfaceType.Smooth
		v5089.Parent = p5035.model
		local v5090 = v5050.CFrame
		local v5091 = p5035.s
		v5089.CFrame = v5090 * (v5088.Rotation + v5088.Position * v5091)
		local v5092 = Instance.new("WeldConstraint")
		v5092.Part0 = v5050
		v5092.Part1 = v5089
		v5092.Parent = v5089
		local v5093 = v5041.X + 0.2
		local v5094 = v5041.Z + 0.2
		local v5095 = Vector3.new(v5093, 0.4, v5094)
		local v5096 = p5035.trim:Lerp(p5035.shirt, 0.5)
		local v5097 = CFrame.new(0, v5041.Y / 2 - 0.1, 0)
		local v5098 = v_u_27(p5035, "Ruff", v5095, v5096, v5039)
		local v5099 = v5042.CFrame
		local v5100 = p5035.s
		v5098.CFrame = v5099 * (v5097.Rotation + v5097.Position * v5100)
		local v5101 = Instance.new("WeldConstraint")
		v5101.Part0 = v5042
		v5101.Part1 = v5098
		v5101.Parent = v5098
	else
		local v5102 = p5035.accent
		local v5103, v5104 = CFrame.new(0, -0.08, v5052 - 0.36)
		local v5105 = v_u_27(p5035, "Beak", Vector3.new(0.42, 0.32, 0.8), v5102, v5104)
		local v5106 = v5050.CFrame
		local v5107 = p5035.s
		v5105.CFrame = v5106 * (v5103.Rotation + v5103.Position * v5107)
		local v5108 = Instance.new("WeldConstraint")
		v5108.Part0 = v5050
		v5108.Part1 = v5105
		v5108.Parent = v5105
		local v5109 = p5035.accent
		local v5110 = CFrame.new(0, -0.18, v5052 - 0.78) * CFrame.Angles(0.7, 0, 0)
		local v5111 = Instance.new("Part")
		v5111.Name = "BeakTip"
		v5111.Size = Vector3.new(0.32, 0.28, 0.32) * p5035.s
		v5111.Color = v5109
		v5111.Material = Enum.Material.Plastic
		v5111.CanCollide = false
		v5111.CanTouch = false
		v5111.CanQuery = false
		v5111.Massless = true
		v5111.Anchored = false
		v5111.CastShadow = (Vector3.new(0.32, 0.28, 0.32)).Magnitude > 1.1
		v5111.TopSurface = Enum.SurfaceType.Smooth
		v5111.BottomSurface = Enum.SurfaceType.Smooth
		v5111.Parent = p5035.model
		local v5112 = v5050.CFrame
		local v5113 = p5035.s
		v5111.CFrame = v5112 * (v5110.Rotation + v5110.Position * v5113)
		local v5114 = Instance.new("WeldConstraint")
		v5114.Part0 = v5050
		v5114.Part1 = v5111
		v5114.Parent = v5111
		local v5115 = p5035.accent:Lerp(v_u_7, 0.3)
		local v5116, v5117 = CFrame.new(0, -0.27, v5052 - 0.28)
		local v5118 = v_u_27(p5035, "BeakLow", Vector3.new(0.34, 0.14, 0.55), v5115, v5117)
		local v5119 = v5050.CFrame
		local v5120 = p5035.s
		v5118.CFrame = v5119 * (v5116.Rotation + v5116.Position * v5120)
		local v5121 = Instance.new("WeldConstraint")
		v5121.Part0 = v5050
		v5121.Part1 = v5118
		v5121.Parent = v5118
		for _, v5122 in { -1, 1 } do
			local v5123 = p5035.shirt
			local v5124 = CFrame.new(v5122 * 0.28, v5044.Y * 0.3, v5052 - 0.04) * CFrame.Angles(0, 0, v5122 * 0.4)
			local v5125 = v_u_27(p5035, "Brow", Vector3.new(0.4, 0.12, 0.18), v5123, v5039)
			local v5126 = v5050.CFrame
			local v5127 = p5035.s
			v5125.CFrame = v5126 * (v5124.Rotation + v5124.Position * v5127)
			local v5128 = Instance.new("WeldConstraint")
			v5128.Part0 = v5050
			v5128.Part1 = v5125
			v5128.Parent = v5125
		end
		for v5129, v5130 in { -0.18, 0, 0.18 } do
			local v5131 = v5129 == 2
			local v5132
			if v5131 then
				v5132 = p5035.glow
			else
				v5132 = p5035.trim
			end
			local v5133 = CFrame.new(v5130, v5044.Y / 2 + 0.15, 0.2) * CFrame.Angles(0.7, 0, -v5130)
			local v5134
			if v5131 then
				v5134 = v5040
			else
				v5134 = v5039
			end
			local v5135 = v_u_27(p5035, "Crest", Vector3.new(0.16, 0.6, 0.12), v5132, v5134)
			local v5136 = v5050.CFrame
			local v5137 = p5035.s
			v5135.CFrame = v5136 * (v5133.Rotation + v5133.Position * v5137)
			local v5138 = Instance.new("WeldConstraint")
			v5138.Part0 = v5050
			v5138.Part1 = v5135
			v5138.Parent = v5135
		end
		for _, v5139 in { -0.4, 0, 0.4 } do
			local v5140 = p5035.shirt
			local v5141 = CFrame.new(0, 0.1, v5041.Z / 2 + 0.5) * CFrame.Angles(-0.15, v5139, 0) * CFrame.new(0, 0, 0.1)
			local v5142 = v_u_27(p5035, "TailFeather", Vector3.new(0.42, 0.12, 1.3), v5140, v5039)
			local v5143 = v5042.CFrame
			local v5144 = p5035.s
			v5142.CFrame = v5143 * (v5141.Rotation + v5141.Position * v5144)
			local v5145 = Instance.new("WeldConstraint")
			v5145.Part0 = v5042
			v5145.Part1 = v5142
			v5145.Parent = v5142
			local v5146 = p5035.glow
			local v5147 = CFrame.new(0, 0, 0.55)
			local v5148 = v_u_27(p5035, "FeatherTip", Vector3.new(0.44, 0.14, 0.3), v5146, v5040)
			local v5149 = v5142.CFrame
			local v5150 = p5035.s
			v5148.CFrame = v5149 * (v5147.Rotation + v5147.Position * v5150)
			local v5151 = Instance.new("WeldConstraint")
			v5151.Part0 = v5142
			v5151.Part1 = v5148
			v5151.Parent = v5148
		end
	end
	local v5152 = #p5035.swings + 1
	local v5153 = v5038 and 2.8 or 2.7
	local v5154 = v5038 and 1.9 or 1.35
	for _, v5155 in { -1, 1 } do
		local v5156 = v_u_57
		local v5157 = "Wing"
		local v5158 = Vector3.new(v5153, 0.12, v5154)
		local v5159
		if v5038 then
			v5159 = p5035.pants
		else
			v5159 = p5035.shirt
		end
		local v5160 = v5156(p5035, v5042, v5157, v5158, v5159, CFrame.new(v5155 * (v5041.X / 2 - 0.1), v5041.Y * 0.3, v5038 and 0.05 or -0.2), CFrame.new(-v5155 * v5153 / 2, 0, not v5038 and -0.1 or -v5154 / 2 + 0.2), Vector3.new(0, 0, v5155), v5038 and 0.6 or 0.55, v5038 and 11 or 9, 0.1, v5039)
		if v5038 then
			local v5161 = v5153 + 0.1
			local v5162 = Vector3.new(v5161, 0.18, 0.18)
			local v5163 = p5035.accent
			local v5164, v5165 = CFrame.new(0, 0.04, -v5154 / 2 + 0.08)
			local v5166 = v_u_27(p5035, "WingBone", v5162, v5163, v5165)
			local v5167 = v5160.CFrame
			local v5168 = p5035.s
			v5166.CFrame = v5167 * (v5164.Rotation + v5164.Position * v5168)
			local v5169 = Instance.new("WeldConstraint")
			v5169.Part0 = v5160
			v5169.Part1 = v5166
			v5169.Parent = v5166
			for v5170 = 0, 2 do
				local v5171 = v5155 * (-v5153 / 2 + 0.6 + v5170 * 0.85)
				local v5172 = -v5154 / 2 + 0.1
				local v5173 = Vector3.new(v5171, 0.03, v5172)
				local v5174 = v5171 + v5155 * (v5170 * 0.25 + 0.25)
				local v5175 = v5154 / 2 - 0.1
				local v5176 = Vector3.new(v5174, 0.03, v5175)
				local v5177 = p5035.glow
				local v5178 = (v5173 + v5176) / 2
				local v5179 = (v5176 - v5173).Magnitude
				local v5180 = Vector3.new(0.1, 0.1, v5179)
				local v5181 = CFrame.lookAt(v5178, v5176)
				local v5182 = v_u_27(p5035, "WingVein", v5180, v5177, v5040)
				local v5183 = v5160.CFrame
				local v5184 = p5035.s
				v5182.CFrame = v5183 * (v5181.Rotation + v5181.Position * v5184)
				local v5185 = Instance.new("WeldConstraint")
				v5185.Part0 = v5160
				v5185.Part1 = v5182
				v5185.Parent = v5182
			end
			local v5186 = v_u_10
			local v5187, v5188 = CFrame.new(v5155 * (v5153 / 2 + 0.1), 0.04, -v5154 / 2 - 0.1)
			local v5189 = v_u_27(p5035, "WingClaw", Vector3.new(0.18, 0.18, 0.4), v5186, v5188)
			local v5190 = v5160.CFrame
			local v5191 = p5035.s
			v5189.CFrame = v5190 * (v5187.Rotation + v5187.Position * v5191)
			local v5192 = Instance.new("WeldConstraint")
			v5192.Part0 = v5160
			v5192.Part1 = v5189
			v5192.Parent = v5189
		else
			for v5193 = 0, 2 do
				local v5194 = p5035.trim
				local v5195 = CFrame.new(v5155 * (v5153 / 2 - 0.2 - v5193 * 0.42), -0.02, v5154 / 2 + 0.3) * CFrame.Angles(0, v5155 * (0.25 - v5193 * 0.12), 0)
				local v5196 = v_u_27(p5035, "Primary", Vector3.new(0.36, 0.1, 1.1), v5194, v5039)
				local v5197 = v5160.CFrame
				local v5198 = p5035.s
				v5196.CFrame = v5197 * (v5195.Rotation + v5195.Position * v5198)
				local v5199 = Instance.new("WeldConstraint")
				v5199.Part0 = v5160
				v5199.Part1 = v5196
				v5199.Parent = v5196
			end
			local v5200 = v5153 - 0.2
			local v5201 = Vector3.new(v5200, 0.13, 0.14)
			local v5202 = p5035.glow
			local v5203 = CFrame.new(v5155 * 0.1, 0, v5154 / 2 - 0.05)
			local v5204 = v_u_27(p5035, "WingEdge", v5201, v5202, v5040)
			local v5205 = v5160.CFrame
			local v5206 = p5035.s
			v5204.CFrame = v5205 * (v5203.Rotation + v5203.Position * v5206)
			local v5207 = Instance.new("WeldConstraint")
			v5207.Part0 = v5160
			v5207.Part1 = v5204
			v5207.Parent = v5204
		end
	end
	local v5208 = math.random() * 6
	for v5209 = v5152, #p5035.swings do
		p5035.swings[v5209].offset = v5208
	end
	local v5210 = {}
	for _, v5211 in {
		{
			["name"] = "RightArm",
			["x"] = 0.3,
			["z"] = -0.2
		},
		{
			["name"] = "LeftArm",
			["x"] = -0.3,
			["z"] = -0.2
		},
		{
			["name"] = "RightLeg",
			["x"] = 0.32,
			["z"] = 0.3
		},
		{
			["name"] = "LeftLeg",
			["x"] = -0.32,
			["z"] = 0.3
		}
	} do
		if v5211.name == "RightArm" or v5211.name == "LeftArm" then
			local _, v5212 = v_u_40(p5035, v5042, v5211.name, Vector3.new(0.2, 0.2, 0.2), v_u_7, CFrame.new(v5211.x, 0, v5211.z), CFrame.identity, {
				["hidden"] = true
			})
			v5210[v5211.name] = v5212
		else
			local v5213, v5214 = v_u_40(p5035, v5042, v5211.name, Vector3.new(0.16, 0.8, 0.16), p5035.pants, CFrame.new(v5211.x, -v5041.Y / 2 + 0.1, v5211.z), CFrame.new(0, 0.4, 0), v5039)
			local v5215 = v_u_7
			local v5216, v5217 = CFrame.new(0, -0.42, -0.08)
			local v5218 = v_u_27(p5035, "Talon", Vector3.new(0.4, 0.12, 0.45), v5215, v5217)
			local v5219 = v5213.CFrame
			local v5220 = p5035.s
			v5218.CFrame = v5219 * (v5216.Rotation + v5216.Position * v5220)
			local v5221 = Instance.new("WeldConstraint")
			v5221.Part0 = v5213
			v5221.Part1 = v5218
			v5221.Parent = v5218
			v5210[v5211.name] = v5214
		end
	end
	v_u_2573(p5035, v5042, v5041)
	local v5222 = {
		["torso"] = nil,
		["head"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = nil,
		["trailTop"] = nil,
		["trailBottom"] = nil,
		["d"] = nil,
		["torso"] = v5042,
		["head"] = v5050,
		["waist"] = v5043,
		["neck"] = v5051,
		["rightArm"] = v5210.RightArm,
		["leftArm"] = v5210.LeftArm,
		["rightLeg"] = v5210.RightLeg,
		["leftLeg"] = v5210.LeftLeg,
		["lift"] = v5038 and 3.8 or 4.2
	}
	local v5223 = v5041.Y * 0.4
	v5222.trailTop = Vector3.new(0, v5223, 0.3)
	local v5224 = -v5041.Y * 0.4
	v5222.trailBottom = Vector3.new(0, v5224, 0.3)
	v5222.d = v_u_15.normal
	return v5222
end
local function v5414(p5226, p5227, p5228) -- name: deepfish
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_15
	local v5229 = p5228 == "angler"
	local v5230 = {
		["material"] = p5226.mat
	}
	local v5231 = {
		["neon"] = true
	}
	local v5232 = {
		["material"] = nil,
		["alpha"] = 0.15,
		["material"] = p5226.mat
	}
	local v5233 = v5229 and Vector3.new(2, 1.9, 1.9) or Vector3.new(1, 1.05, 2.6)
	local v5234, v5235 = v_u_40(p5226, p5227, "Torso", v5233, p5226.shirt, CFrame.identity, CFrame.identity, v5230)
	local v5236 = v5233.X - 0.1
	local v5237 = v5233.Z - 0.2
	local v5238 = Vector3.new(v5236, 0.35, v5237)
	local v5239 = p5226.pants
	local v5240 = CFrame.new(0, -v5233.Y / 2 + 0.12, 0)
	local v5241 = v_u_27(p5226, "Belly", v5238, v5239, v5230)
	local v5242 = v5234.CFrame
	local v5243 = p5226.s
	v5241.CFrame = v5242 * (v5240.Rotation + v5240.Position * v5243)
	local v5244 = Instance.new("WeldConstraint")
	v5244.Part0 = v5234
	v5244.Part1 = v5241
	v5244.Parent = v5241
	local v5245 = v5229 and Vector3.new(2.1, 1.6, 1.3) or Vector3.new(1, 0.95, 1.1)
	local v5246, v5247 = v_u_40(p5226, v5234, "Head", v5245, p5226.skin, CFrame.new(0, v5229 and 0.1 or 0, -v5233.Z / 2), CFrame.new(0, 0, v5245.Z / 2 - 0.2), v5230)
	local v5248 = -v5245.Z / 2
	if v5229 then
		local v5249 = p5226.skin
		local v5250 = CFrame.new(0, -v5245.Y / 2 - 0.05, -0.35) * CFrame.Angles(0.25, 0, 0)
		local v5251 = v_u_27(p5226, "Jaw", Vector3.new(2.2, 0.5, 1.5), v5249, v5230)
		local v5252 = v5246.CFrame
		local v5253 = p5226.s
		v5251.CFrame = v5252 * (v5250.Rotation + v5250.Position * v5253)
		local v5254 = Instance.new("WeldConstraint")
		v5254.Part0 = v5246
		v5254.Part1 = v5251
		v5254.Parent = v5251
		local v5255 = p5226.glow:Lerp(v_u_7, 0.55)
		local v5256, v5257 = CFrame.new(0, -0.45, v5248 - 0.02)
		local v5258 = v_u_27(p5226, "Throat", Vector3.new(1.8, 0.55, 0.1), v5255, v5257)
		local v5259 = v5246.CFrame
		local v5260 = p5226.s
		v5258.CFrame = v5259 * (v5256.Rotation + v5256.Position * v5260)
		local v5261 = Instance.new("WeldConstraint")
		v5261.Part0 = v5246
		v5261.Part1 = v5258
		v5261.Parent = v5258
		for v5262 = -2, 2 do
			local v5263 = p5226.accent
			local v5264 = CFrame.new(v5262 * 0.36, -v5245.Y / 2 + 0.15, v5248 - 0.08) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v5265 = Instance.new("Part")
			v5265.Name = "Tooth"
			v5265.Size = Vector3.new(0.12, 0.45, 0.12) * p5226.s
			v5265.Color = v5263
			v5265.Material = Enum.Material.Plastic
			v5265.CanCollide = false
			v5265.CanTouch = false
			v5265.CanQuery = false
			v5265.Massless = true
			v5265.Anchored = false
			v5265.CastShadow = (Vector3.new(0.12, 0.45, 0.12)).Magnitude > 1.1
			v5265.TopSurface = Enum.SurfaceType.Smooth
			v5265.BottomSurface = Enum.SurfaceType.Smooth
			v5265.Parent = p5226.model
			local v5266 = v5246.CFrame
			local v5267 = p5226.s
			v5265.CFrame = v5266 * (v5264.Rotation + v5264.Position * v5267)
			local v5268 = Instance.new("WeldConstraint")
			v5268.Part0 = v5246
			v5268.Part1 = v5265
			v5268.Parent = v5265
			local v5269 = p5226.accent
			local v5270 = CFrame.new(v5262 * 0.38 + 0.18, -0.4, -1) * CFrame.Angles(0.2, 0.7853981633974483, 0)
			local v5271 = Instance.new("Part")
			v5271.Name = "Tooth"
			v5271.Size = Vector3.new(0.13, 0.55, 0.13) * p5226.s
			v5271.Color = v5269
			v5271.Material = Enum.Material.Plastic
			v5271.CanCollide = false
			v5271.CanTouch = false
			v5271.CanQuery = false
			v5271.Massless = true
			v5271.Anchored = false
			v5271.CastShadow = (Vector3.new(0.13, 0.55, 0.13)).Magnitude > 1.1
			v5271.TopSurface = Enum.SurfaceType.Smooth
			v5271.BottomSurface = Enum.SurfaceType.Smooth
			v5271.Parent = p5226.model
			local v5272 = v5246.CFrame
			local v5273 = p5226.s
			v5271.CFrame = v5272 * (v5270.Rotation + v5270.Position * v5273)
			local v5274 = Instance.new("WeldConstraint")
			v5274.Part0 = v5246
			v5274.Part1 = v5271
			v5274.Parent = v5271
		end
		for _, v5275 in { -1, 1 } do
			local v5276 = p5226.eye
			local v5277 = CFrame.new(v5275 * 0.72, 0.42, v5248 - 0.02)
			local v5278 = v_u_27(p5226, "Eye", Vector3.new(0.26, 0.26, 0.08), v5276, v5231)
			local v5279 = v5246.CFrame
			local v5280 = p5226.s
			v5278.CFrame = v5279 * (v5277.Rotation + v5277.Position * v5280)
			local v5281 = Instance.new("WeldConstraint")
			v5281.Part0 = v5246
			v5281.Part1 = v5278
			v5281.Parent = v5278
		end
		local v5282 = v5245.Y / 2
		local v5283 = Vector3.new(0, v5282, -0.1)
		local v5284 = v5245.Y / 2 + 1.2
		local v5285 = Vector3.new(0, v5284, -0.5)
		local v5286 = v5245.Y / 2 + 1
		local v5287 = Vector3.new(0, v5286, -1.5)
		local v5288 = p5226.skin
		local v5289 = (v5283 + v5285) / 2
		local v5290 = (v5285 - v5283).Magnitude
		local v5291 = Vector3.new(0.14, 0.14, v5290)
		local v5292 = CFrame.lookAt(v5289, v5285)
		local v5293 = Instance.new("Part")
		v5293.Name = "Lure"
		v5293.Size = v5291 * p5226.s
		v5293.Color = v5288
		v5293.Material = Enum.Material.Plastic
		v5293.CanCollide = false
		v5293.CanTouch = false
		v5293.CanQuery = false
		v5293.Massless = true
		v5293.Anchored = false
		v5293.CastShadow = v5291.Magnitude > 1.1
		v5293.TopSurface = Enum.SurfaceType.Smooth
		v5293.BottomSurface = Enum.SurfaceType.Smooth
		v5293.Parent = p5226.model
		local v5294 = v5246.CFrame
		local v5295 = p5226.s
		v5293.CFrame = v5294 * (v5292.Rotation + v5292.Position * v5295)
		local v5296 = Instance.new("WeldConstraint")
		v5296.Part0 = v5246
		v5296.Part1 = v5293
		v5296.Parent = v5293
		local v5297 = p5226.skin
		local v5298 = (v5285 + v5287) / 2
		local v5299 = (v5287 - v5285).Magnitude
		local v5300 = Vector3.new(0.12, 0.12, v5299)
		local v5301 = CFrame.lookAt(v5298, v5287)
		local v5302 = Instance.new("Part")
		v5302.Name = "Lure"
		v5302.Size = v5300 * p5226.s
		v5302.Color = v5297
		v5302.Material = Enum.Material.Plastic
		v5302.CanCollide = false
		v5302.CanTouch = false
		v5302.CanQuery = false
		v5302.Massless = true
		v5302.Anchored = false
		v5302.CastShadow = v5300.Magnitude > 1.1
		v5302.TopSurface = Enum.SurfaceType.Smooth
		v5302.BottomSurface = Enum.SurfaceType.Smooth
		v5302.Parent = p5226.model
		local v5303 = v5246.CFrame
		local v5304 = p5226.s
		v5302.CFrame = v5303 * (v5301.Rotation + v5301.Position * v5304)
		local v5305 = Instance.new("WeldConstraint")
		v5305.Part0 = v5246
		v5305.Part1 = v5302
		v5305.Parent = v5302
		local v5306 = p5226.glow
		local v5307 = CFrame.new(v5287 + Vector3.new(0, -0.3, -0.1))
		local v5308 = v_u_27(p5226, "LureBulb", Vector3.new(0.7, 0.7, 0.7), v5306, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v5309 = v5246.CFrame
		local v5310 = p5226.s
		v5308.CFrame = v5309 * (v5307.Rotation + v5307.Position * v5310)
		local v5311 = Instance.new("WeldConstraint")
		v5311.Part0 = v5246
		v5311.Part1 = v5308
		v5311.Parent = v5308
		for v5312, v5313 in { -0.4, 0.1, 0.6 } do
			local v5314 = 0.9 - v5312 * 0.1
			local v5315 = Vector3.new(0.1, v5314, 0.1)
			local v5316 = p5226.trim
			local v5317 = CFrame.new(0, v5233.Y / 2 + 0.35, v5313) * CFrame.Angles(0.5, 0, 0)
			local v5318 = Instance.new("Part")
			v5318.Name = "Spine"
			v5318.Size = v5315 * p5226.s
			v5318.Color = v5316
			v5318.Material = Enum.Material.Plastic
			v5318.CanCollide = false
			v5318.CanTouch = false
			v5318.CanQuery = false
			v5318.Massless = true
			v5318.Anchored = false
			v5318.CastShadow = v5315.Magnitude > 1.1
			v5318.TopSurface = Enum.SurfaceType.Smooth
			v5318.BottomSurface = Enum.SurfaceType.Smooth
			v5318.Parent = p5226.model
			local v5319 = v5234.CFrame
			local v5320 = p5226.s
			v5318.CFrame = v5319 * (v5317.Rotation + v5317.Position * v5320)
			local v5321 = Instance.new("WeldConstraint")
			v5321.Part0 = v5234
			v5321.Part1 = v5318
			v5321.Parent = v5318
		end
	else
		for _, v5322 in { -1, 1 } do
			local v5323 = p5226.eye
			local v5324 = CFrame.new(v5322 * 0.45, 0.15, v5248 + 0.2)
			local v5325 = v_u_27(p5226, "LampEye", Vector3.new(0.45, 0.45, 0.45), v5323, {
				["neon"] = true,
				["shape"] = nil,
				["shape"] = Enum.PartType.Ball
			})
			local v5326 = v5246.CFrame
			local v5327 = p5226.s
			v5325.CFrame = v5326 * (v5324.Rotation + v5324.Position * v5327)
			local v5328 = Instance.new("WeldConstraint")
			v5328.Part0 = v5246
			v5328.Part1 = v5325
			v5328.Parent = v5325
			local v5329 = p5226.accent
			local v5330, v5331 = CFrame.new(v5322 * 0.25, -0.5, v5248 - 0.08)
			local v5332 = v_u_27(p5226, "Fang", Vector3.new(0.1, 0.5, 0.1), v5329, v5331)
			local v5333 = v5246.CFrame
			local v5334 = p5226.s
			v5332.CFrame = v5333 * (v5330.Rotation + v5330.Position * v5334)
			local v5335 = Instance.new("WeldConstraint")
			v5335.Part0 = v5246
			v5335.Part1 = v5332
			v5335.Parent = v5332
			for v5336 = 0, 3 do
				local v5337 = p5226.glow
				local v5338 = CFrame.new(v5322 * (v5233.X / 2 + 0.02), -0.25, v5336 * 0.6 + -0.9)
				local v5339 = v_u_27(p5226, "Light", Vector3.new(0.06, 0.18, 0.18), v5337, v5231)
				local v5340 = v5234.CFrame
				local v5341 = p5226.s
				v5339.CFrame = v5340 * (v5338.Rotation + v5338.Position * v5341)
				local v5342 = Instance.new("WeldConstraint")
				v5342.Part0 = v5234
				v5342.Part1 = v5339
				v5342.Parent = v5339
			end
		end
		local v5343 = p5226.skin
		local v5344 = CFrame.new(0, -0.45, v5248 - 0.2) * CFrame.Angles(-0.3, 0, 0)
		local v5345 = v_u_27(p5226, "Jaw", Vector3.new(0.85, 0.22, 1.1), v5343, v5230)
		local v5346 = v5246.CFrame
		local v5347 = p5226.s
		v5345.CFrame = v5346 * (v5344.Rotation + v5344.Position * v5347)
		local v5348 = Instance.new("WeldConstraint")
		v5348.Part0 = v5246
		v5348.Part1 = v5345
		v5348.Parent = v5345
		for _, v5349 in { -1, 1 } do
			local v5350 = p5226.accent
			local v5351, v5352 = CFrame.new(v5349 * 0.28, 0.25, -0.45)
			local v5353 = v_u_27(p5226, "Fang", Vector3.new(0.1, 0.4, 0.1), v5350, v5352)
			local v5354 = v5345.CFrame
			local v5355 = p5226.s
			v5353.CFrame = v5354 * (v5351.Rotation + v5351.Position * v5355)
			local v5356 = Instance.new("WeldConstraint")
			v5356.Part0 = v5345
			v5356.Part1 = v5353
			v5356.Parent = v5353
		end
		local v5357 = v5248 - 0.3
		local v5358 = Vector3.new(0, -0.6, v5357)
		local v5359 = v5248 - 0.5
		local v5360 = Vector3.new(0, -1.4, v5359)
		local v5361 = p5226.skin
		local v5362 = (v5358 + v5360) / 2
		local v5363 = (v5360 - v5358).Magnitude
		local v5364 = Vector3.new(0.07, 0.07, v5363)
		local v5365 = CFrame.lookAt(v5362, v5360)
		local v5366 = Instance.new("Part")
		v5366.Name = "Barbel"
		v5366.Size = v5364 * p5226.s
		v5366.Color = v5361
		v5366.Material = Enum.Material.Plastic
		v5366.CanCollide = false
		v5366.CanTouch = false
		v5366.CanQuery = false
		v5366.Massless = true
		v5366.Anchored = false
		v5366.CastShadow = v5364.Magnitude > 1.1
		v5366.TopSurface = Enum.SurfaceType.Smooth
		v5366.BottomSurface = Enum.SurfaceType.Smooth
		v5366.Parent = p5226.model
		local v5367 = v5246.CFrame
		local v5368 = p5226.s
		v5366.CFrame = v5367 * (v5365.Rotation + v5365.Position * v5368)
		local v5369 = Instance.new("WeldConstraint")
		v5369.Part0 = v5246
		v5369.Part1 = v5366
		v5369.Parent = v5366
		local v5370 = p5226.glow
		local v5371 = CFrame.new(v5360 + Vector3.new(0, -0.15, 0))
		local v5372 = v_u_27(p5226, "Lantern", Vector3.new(0.45, 0.45, 0.45), v5370, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v5373 = v5246.CFrame
		local v5374 = p5226.s
		v5372.CFrame = v5373 * (v5371.Rotation + v5371.Position * v5374)
		local v5375 = Instance.new("WeldConstraint")
		v5375.Part0 = v5246
		v5375.Part1 = v5372
		v5375.Parent = v5372
		local v5376 = p5226.trim
		local v5377 = CFrame.new(0, v5233.Y / 2 + 0.2, 0.2)
		local v5378 = v_u_27(p5226, "Dorsal", Vector3.new(0.1, 0.5, 0.9), v5376, v5232)
		local v5379 = v5234.CFrame
		local v5380 = p5226.s
		v5378.CFrame = v5379 * (v5377.Rotation + v5377.Position * v5380)
		local v5381 = Instance.new("WeldConstraint")
		v5381.Part0 = v5234
		v5381.Part1 = v5378
		v5381.Parent = v5378
	end
	local v5382 = {}
	for _, v5383 in { 1, -1 } do
		local v5384 = v5383 == 1 and "Right" or "Left"
		local v5385 = v5229 and Vector3.new(1, 0.1, 0.7) or Vector3.new(0.9, 0.08, 0.6)
		local _, v5386 = v_u_40(p5226, v5234, v5384 .. "Arm", v5385, p5226.trim, CFrame.new(v5383 * (v5233.X / 2 - 0.05), -v5233.Y * 0.2, -v5233.Z * 0.2) * CFrame.Angles(0, -v5383 * 0.4, -v5383 * 0.4), CFrame.new(-v5383 * v5385.X / 2, 0, 0), v5232)
		v5382[v5384 .. "Arm"] = v5386
		local _, v5387 = v_u_40(p5226, v5234, v5384 .. "Leg", Vector3.new(0.5, 0.08, 0.4), p5226.trim, CFrame.new(v5383 * v5233.X * 0.3, -v5233.Y / 2 + 0.05, v5233.Z * 0.2) * CFrame.Angles(0, 0, -v5383 * 0.8), CFrame.new(-v5383 * 0.25, 0, 0), v5232)
		v5382[v5384 .. "Leg"] = v5387
	end
	local v5388 = v_u_40
	local v5389 = v5233.X * 0.5
	local v5390 = v5233.Y * 0.55
	local v5391, v5392 = v5388(p5226, v5234, "Tail", Vector3.new(v5389, v5390, 0.9), p5226.shirt, CFrame.new(0, 0, v5233.Z / 2 - 0.1), CFrame.new(0, 0, -0.45), v5230)
	for _, v5393 in {
		{
			0.5,
			0.55,
			1.4,
			0.8,
			0.55
		},
		{
			-0.45,
			0.5,
			1.4,
			0.8,
			-0.55
		}
	} do
		local v5394 = v5393[3]
		local v5395 = v5393[4]
		local v5396 = Vector3.new(0.12, v5394, v5395)
		local v5397 = p5226.trim
		local v5398 = CFrame.new(0, v5393[1], v5393[2]) * CFrame.Angles(v5393[5], 0, 0)
		local v5399 = v_u_27(p5226, "TailFin", v5396, v5397, v5232)
		local v5400 = v5391.CFrame
		local v5401 = p5226.s
		v5399.CFrame = v5400 * (v5398.Rotation + v5398.Position * v5401)
		local v5402 = Instance.new("WeldConstraint")
		v5402.Part0 = v5391
		v5402.Part1 = v5399
		v5402.Parent = v5399
		local v5403 = v5393[3]
		local v5404 = Vector3.new(0.16, v5403, 0.1)
		local v5405 = p5226.glow
		local v5406 = CFrame.new(0, 0, v5393[4] / 2)
		local v5407 = v_u_27(p5226, "FinEdge", v5404, v5405, v5231)
		local v5408 = v5399.CFrame
		local v5409 = p5226.s
		v5407.CFrame = v5408 * (v5406.Rotation + v5406.Position * v5409)
		local v5410 = Instance.new("WeldConstraint")
		v5410.Part0 = v5399
		v5410.Part1 = v5407
		v5410.Parent = v5407
	end
	local v5411 = {
		["torso"] = v5234,
		["head"] = v5246,
		["waist"] = v5235,
		["neck"] = v5247,
		["rightArm"] = v5382.RightArm,
		["leftArm"] = v5382.LeftArm,
		["rightLeg"] = v5382.RightLeg,
		["leftLeg"] = v5382.LeftLeg,
		["tail"] = v5392,
		["lift"] = v5229 and 2.8 or 2.6
	}
	local v5412 = v5233.Y * 0.4
	v5411.trailTop = Vector3.new(0, v5412, 0.5)
	local v5413 = -v5233.Y * 0.4
	v5411.trailBottom = Vector3.new(0, v5413, 0.5)
	v5411.d = v_u_15.normal
	return v5411
end
local function v5546(p5415, p5416, p5417) -- name: drifter
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_7, (copy) v_u_57, (copy) v_u_15, (copy) v_u_3144
	local v5418 = {
		["material"] = p5415.mat
	}
	local v5419 = {
		["neon"] = true
	}
	local v5420 = {}
	local v5421 = {
		{
			["name"] = "RightArm",
			["x"] = 0.35,
			["z"] = -0.55
		},
		{
			["name"] = "LeftArm",
			["x"] = -0.35,
			["z"] = -0.55
		},
		{
			["name"] = "RightLeg",
			["x"] = 0.55,
			["z"] = 0.55
		},
		{
			["name"] = "LeftLeg",
			["x"] = -0.55,
			["z"] = 0.55
		}
	}
	if p5417 ~= "squid" then
		local v5422, v5423 = v_u_40(p5415, p5416, "Torso", Vector3.new(2.6, 2.6, 2.6), p5415.shirt, CFrame.identity, CFrame.identity, {
			["shape"] = nil,
			["material"] = nil,
			["alpha"] = 0.45,
			["shape"] = Enum.PartType.Ball,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v5424 = p5415.trim
		local v5425 = CFrame.new(0, -0.3, 0) * v_u_3144
		local v5426 = v_u_27(p5415, "Brim", Vector3.new(0.18, 2.9, 2.9), v5424, {
			["shape"] = nil,
			["material"] = nil,
			["alpha"] = 0.45,
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v5427 = v5422.CFrame
		local v5428 = p5415.s
		v5426.CFrame = v5427 * (v5425.Rotation + v5425.Position * v5428)
		local v5429 = Instance.new("WeldConstraint")
		v5429.Part0 = v5422
		v5429.Part1 = v5426
		v5429.Parent = v5426
		for v5430 = 0, 9 do
			local v5431 = v5430 * 3.141592653589793 / 5
			local v5432 = p5415.glow
			local v5433 = CFrame.new(math.cos(v5431) * 1.45, -0.3, math.sin(v5431) * 1.45) * CFrame.Angles(0, -v5431, 0)
			local v5434 = v_u_27(p5415, "Rim", Vector3.new(0.18, 0.16, 0.9461493), v5432, v5419)
			local v5435 = v5422.CFrame
			local v5436 = p5415.s
			v5434.CFrame = v5435 * (v5433.Rotation + v5433.Position * v5436)
			local v5437 = Instance.new("WeldConstraint")
			v5437.Part0 = v5422
			v5437.Part1 = v5434
			v5437.Parent = v5434
		end
		local v5438, v5439 = v_u_40(p5415, v5422, "Head", Vector3.new(1.1, 1.1, 1.1), p5415.skin, CFrame.new(0, 0.2, 0), CFrame.identity, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		for _, v5440 in { -1, 1 } do
			local v5441 = p5415.eye
			local v5442 = CFrame.new(v5440 * 0.38, 0.3, -1.2) * CFrame.Angles(0, v5440 * 0.3, v5440 * 0.28)
			local v5443 = v_u_27(p5415, "Eye", Vector3.new(0.34, 0.22, 0.08), v5441, v5419)
			local v5444 = v5422.CFrame
			local v5445 = p5415.s
			v5443.CFrame = v5444 * (v5442.Rotation + v5442.Position * v5445)
			local v5446 = Instance.new("WeldConstraint")
			v5446.Part0 = v5422
			v5446.Part1 = v5443
			v5446.Parent = v5443
		end
		for _, v5447 in v5421 do
			local v5448, v5449 = v_u_40(p5415, v5422, v5447.name, Vector3.new(0.2, 2.4, 0.2), p5415.pants, CFrame.new(v5447.x, -0.45, v5447.z), CFrame.new(0, 1.2, 0), v5418)
			v5420[v5447.name] = v5449
			local v5450 = p5415.glow
			local v5451 = CFrame.new(0, -1.7, 0.1) * CFrame.Angles(0.25, 0, 0)
			local v5452 = v_u_27(p5415, "TentacleTip", Vector3.new(0.16, 1.2, 0.16), v5450, v5419)
			local v5453 = v5448.CFrame
			local v5454 = p5415.s
			v5452.CFrame = v5453 * (v5451.Rotation + v5451.Position * v5454)
			local v5455 = Instance.new("WeldConstraint")
			v5455.Part0 = v5448
			v5455.Part1 = v5452
			v5455.Parent = v5452
		end
		for v5456, v5457 in {
			Vector2.new(0, 0.75),
			Vector2.new(0, -0.75),
			Vector2.new(0.75, 0),
			Vector2.new(-0.75, 0)
		} do
			local v5458 = v_u_57(p5415, v5422, "Tentacle", Vector3.new(0.16, 2.8, 0.16), p5415.pants, CFrame.new(v5457.X, -0.45, v5457.Y), CFrame.new(0, 1.4, 0), v5456 <= 2 and Vector3.new(1, 0, 0) or Vector3.new(0, 0, 1), 0.25, 2 + v5456 * 0.4, 0.2, v5418)
			local v5459 = p5415.glow
			local v5460 = CFrame.new(0, -1.75, 0)
			local v5461 = v_u_27(p5415, "TentacleTip", Vector3.new(0.12, 0.8, 0.12), v5459, v5419)
			local v5462 = v5458.CFrame
			local v5463 = p5415.s
			v5461.CFrame = v5462 * (v5460.Rotation + v5460.Position * v5463)
			local v5464 = Instance.new("WeldConstraint")
			v5464.Part0 = v5458
			v5464.Part1 = v5461
			v5464.Parent = v5461
		end
		for _, v5465 in { -1, 1 } do
			v_u_57(p5415, v5422, "MouthArm", Vector3.new(0.55, 2, 0.25), p5415.trim, CFrame.new(v5465 * 0.25, -0.6, 0), CFrame.new(0, 1, 0), Vector3.new(0, 0, 1), 0.18, 1.6, 0.25, {
				["material"] = nil,
				["alpha"] = 0.4,
				["material"] = Enum.Material.SmoothPlastic
			})
		end
		return {
			["torso"] = nil,
			["head"] = nil,
			["waist"] = nil,
			["neck"] = nil,
			["rightArm"] = nil,
			["leftArm"] = nil,
			["rightLeg"] = nil,
			["leftLeg"] = nil,
			["tail"] = nil,
			["lift"] = 3.8,
			["trailTop"] = Vector3.new(0, 1, 0),
			["trailBottom"] = Vector3.new(0, -1, 0),
			["d"] = nil,
			["torso"] = v5422,
			["head"] = v5438,
			["waist"] = v5423,
			["neck"] = v5439,
			["rightArm"] = v5420.RightArm,
			["leftArm"] = v5420.LeftArm,
			["rightLeg"] = v5420.RightLeg,
			["leftLeg"] = v5420.LeftLeg,
			["d"] = v_u_15.normal
		}
	end
	local v5466, v5467 = v_u_40(p5415, p5416, "Torso", Vector3.new(1.3, 1.2, 1.1), p5415.skin, CFrame.identity, CFrame.identity, v5418)
	local v5468 = p5415.shirt
	local v5469 = CFrame.new(0, 0.7, 1.45) * CFrame.Angles(-0.5, 0, 0)
	local v5470 = v_u_27(p5415, "Mantle", Vector3.new(1.5, 1.45, 2.9), v5468, v5418)
	local v5471 = v5466.CFrame
	local v5472 = p5415.s
	v5470.CFrame = v5471 * (v5469.Rotation + v5469.Position * v5472)
	local v5473 = Instance.new("WeldConstraint")
	v5473.Part0 = v5466
	v5473.Part1 = v5470
	v5473.Parent = v5470
	for _, v5474 in { -1, 1 } do
		local v5475 = p5415.trim
		local v5476 = CFrame.new(v5474 * 1.05, 0, 0.95) * CFrame.Angles(0, -v5474 * 0.35, 0)
		local v5477 = v_u_27(p5415, "MantleFin", Vector3.new(1.1, 0.1, 1), v5475, v5418)
		local v5478 = v5470.CFrame
		local v5479 = p5415.s
		v5477.CFrame = v5478 * (v5476.Rotation + v5476.Position * v5479)
		local v5480 = Instance.new("WeldConstraint")
		v5480.Part0 = v5470
		v5480.Part1 = v5477
		v5480.Parent = v5477
		for v5481 = 0, 1 do
			local v5482 = p5415.accent
			local v5483 = CFrame.new(v5474 * 0.76, 0.1, v5481 * 0.8 + -0.6)
			local v5484 = v_u_27(p5415, "Spot", Vector3.new(0.06, 0.34, 0.34), v5482, v5419)
			local v5485 = v5470.CFrame
			local v5486 = p5415.s
			v5484.CFrame = v5485 * (v5483.Rotation + v5483.Position * v5486)
			local v5487 = Instance.new("WeldConstraint")
			v5487.Part0 = v5470
			v5487.Part1 = v5484
			v5487.Parent = v5484
		end
	end
	local v5488 = p5415.accent
	local v5489 = CFrame.new(0, 0.73, -0.2)
	local v5490 = v_u_27(p5415, "Spot", Vector3.new(0.4, 0.06, 0.4), v5488, v5419)
	local v5491 = v5470.CFrame
	local v5492 = p5415.s
	v5490.CFrame = v5491 * (v5489.Rotation + v5489.Position * v5492)
	local v5493 = Instance.new("WeldConstraint")
	v5493.Part0 = v5470
	v5493.Part1 = v5490
	v5493.Parent = v5490
	local v5494, v5495 = v_u_40(p5415, v5466, "Head", Vector3.new(1.25, 1.05, 1), p5415.skin, CFrame.new(0, -0.1, -0.550000011920929), CFrame.new(0, 0, 0.35), v5418)
	for _, v5496 in { -1, 1 } do
		local v5497 = p5415.eye
		local v5498 = CFrame.new(v5496 * 0.55, 0.12, 0)
		local v5499 = v_u_27(p5415, "Eye", Vector3.new(0.5, 0.5, 0.5), v5497, {
			["neon"] = true,
			["shape"] = nil,
			["shape"] = Enum.PartType.Ball
		})
		local v5500 = v5494.CFrame
		local v5501 = p5415.s
		v5499.CFrame = v5500 * (v5498.Rotation + v5498.Position * v5501)
		local v5502 = Instance.new("WeldConstraint")
		v5502.Part0 = v5494
		v5502.Part1 = v5499
		v5502.Parent = v5499
		local v5503 = v_u_7
		local v5504, v5505 = CFrame.new(v5496 * 0.8, 0.12, 0)
		local v5506 = v_u_27(p5415, "Pupil", Vector3.new(0.06, 0.32, 0.12), v5503, v5505)
		local v5507 = v5494.CFrame
		local v5508 = p5415.s
		v5506.CFrame = v5507 * (v5504.Rotation + v5504.Position * v5508)
		local v5509 = Instance.new("WeldConstraint")
		v5509.Part0 = v5494
		v5509.Part1 = v5506
		v5509.Parent = v5506
	end
	for _, v5510 in v5421 do
		local v5511 = v_u_40
		local v5512 = v5510.name
		local v5513 = p5415.pants
		local v5514 = CFrame.new
		local v5515 = v5510.x * 0.9
		local v5516 = v5510.z
		local v5517, v5518 = v5511(p5415, v5494, v5512, Vector3.new(0.3, 0.3, 1.9), v5513, v5514(v5515, -0.3 - math.abs(v5516) * 0.2, -0.35) * CFrame.Angles(-0.6, v5510.x * 0.5, 0), CFrame.new(0, 0, 0.95), v5418)
		v5420[v5510.name] = v5518
		local v5519 = p5415.pants
		local v5520 = CFrame.new(0, 0.1, -1.25) * CFrame.Angles(0.35, 0, 0)
		local v5521 = v_u_27(p5415, "ArmTip", Vector3.new(0.22, 0.22, 0.8), v5519, v5418)
		local v5522 = v5517.CFrame
		local v5523 = p5415.s
		v5521.CFrame = v5522 * (v5520.Rotation + v5520.Position * v5523)
		local v5524 = Instance.new("WeldConstraint")
		v5524.Part0 = v5517
		v5524.Part1 = v5521
		v5524.Parent = v5521
		local v5525 = p5415.accent
		local v5526 = CFrame.new(0, -0.16, -0.5)
		local v5527 = v_u_27(p5415, "Sucker", Vector3.new(0.14, 0.06, 0.14), v5525, v5419)
		local v5528 = v5517.CFrame
		local v5529 = p5415.s
		v5527.CFrame = v5528 * (v5526.Rotation + v5526.Position * v5529)
		local v5530 = Instance.new("WeldConstraint")
		v5530.Part0 = v5517
		v5530.Part1 = v5527
		v5530.Parent = v5527
	end
	for _, v5531 in {
		-0.5,
		-0.15,
		0.15,
		0.5
	} do
		local v5532 = p5415.pants
		local v5533 = CFrame.new(v5531, -0.45, -0.9) * CFrame.Angles(-0.9, v5531 * 0.3, 0)
		local v5534 = v_u_27(p5415, "ShortArm", Vector3.new(0.24, 0.24, 1.2), v5532, v5418)
		local v5535 = v5494.CFrame
		local v5536 = p5415.s
		v5534.CFrame = v5535 * (v5533.Rotation + v5533.Position * v5536)
		local v5537 = Instance.new("WeldConstraint")
		v5537.Part0 = v5494
		v5537.Part1 = v5534
		v5537.Parent = v5534
	end
	for _, v5538 in { -1, 1 } do
		local v5539 = v_u_57(p5415, v5494, "Tentacle", Vector3.new(0.18, 0.18, 3), p5415.pants, CFrame.new(v5538 * 0.3, -0.2, -0.5) * CFrame.Angles(-0.3, v5538 * 0.25, 0), CFrame.new(0, 0, 1.5), Vector3.new(1, 0, 0), 0.3, 3.5, 0.2, v5418)
		local v5540 = p5415.glow
		local v5541 = CFrame.new(0, 0, -1.6)
		local v5542 = v_u_27(p5415, "Club", Vector3.new(0.4, 0.3, 0.7), v5540, v5419)
		local v5543 = v5539.CFrame
		local v5544 = p5415.s
		v5542.CFrame = v5543 * (v5541.Rotation + v5541.Position * v5544)
		local v5545 = Instance.new("WeldConstraint")
		v5545.Part0 = v5539
		v5545.Part1 = v5542
		v5545.Parent = v5542
	end
	return {
		["torso"] = nil,
		["head"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["lift"] = 2.6,
		["trailTop"] = Vector3.new(0, 0.9, 0.9),
		["trailBottom"] = Vector3.new(0, -0.5, 0.4),
		["d"] = nil,
		["torso"] = v5466,
		["head"] = v5494,
		["waist"] = v5467,
		["neck"] = v5495,
		["rightArm"] = v5420.RightArm,
		["leftArm"] = v5420.LeftArm,
		["rightLeg"] = v5420.RightLeg,
		["leftLeg"] = v5420.LeftLeg,
		["d"] = v_u_15.normal
	}
end
local function v5755(p5547, p5548, p5549) -- name: serpent
	-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_3145, (copy) v_u_57, (copy) v_u_7, (copy) v_u_15
	local v5550 = p5549 == "leviathan"
	local v5551 = {
		["material"] = p5547.mat
	}
	local v5552 = {
		["neon"] = true
	}
	local v5553 = {
		["material"] = nil,
		["alpha"] = 0.15,
		["material"] = p5547.mat
	}
	local v5554 = v5550 and Vector3.new(1.7, 1.6, 2.6) or Vector3.new(0.95, 0.95, 1.8)
	local v5555, v5556 = v_u_40(p5547, p5548, "Torso", v5554, p5547.shirt, CFrame.identity, CFrame.identity, v5551)
	local v5557 = v5554.X - 0.1
	local v5558 = v5554.Z
	local v5559 = Vector3.new(v5557, 0.22, v5558)
	local v5560 = p5547.pants
	local v5561 = CFrame.new(0, -v5554.Y / 2 + 0.09, 0)
	local v5562 = v_u_27(p5547, "Belly", v5559, v5560, v5551)
	local v5563 = v5555.CFrame
	local v5564 = p5547.s
	v5562.CFrame = v5563 * (v5561.Rotation + v5561.Position * v5564)
	local v5565 = Instance.new("WeldConstraint")
	v5565.Part0 = v5555
	v5565.Part1 = v5562
	v5565.Parent = v5562
	local v5566 = v5554.Z
	local v5567 = Vector3.new(0.18, 0.1, v5566)
	local v5568 = p5547.glow
	local v5569 = CFrame.new(0, v5554.Y / 2 + 0.02, 0)
	local v5570 = v_u_27(p5547, "Stripe", v5567, v5568, v5552)
	local v5571 = v5555.CFrame
	local v5572 = p5547.s
	v5570.CFrame = v5571 * (v5569.Rotation + v5569.Position * v5572)
	local v5573 = Instance.new("WeldConstraint")
	v5573.Part0 = v5555
	v5573.Part1 = v5570
	v5573.Parent = v5570
	local v5574 = v5550 and Vector3.new(1.7, 1.3, 2) or Vector3.new(1, 0.85, 1.35)
	local v5575, v5576
	if v5550 then
		local v5577 = p5547.shirt
		local v5578 = (Vector3.new(0, 2.1, -0.6)).Magnitude
		local v5579 = Vector3.new(1.35, 1.35, v5578)
		local v5580 = CFrame.lookAt(Vector3.new(0, 1.55, -1.2), Vector3.new(0, 2.6, -1.5))
		local v5581 = v_u_27(p5547, "Neck", v5579, v5577, v5551)
		local v5582 = v5555.CFrame
		local v5583 = p5547.s
		v5581.CFrame = v5582 * (v5580.Rotation + v5580.Position * v5583)
		local v5584 = Instance.new("WeldConstraint")
		v5584.Part0 = v5555
		v5584.Part1 = v5581
		v5584.Parent = v5581
		local v5585 = p5547.shirt
		local v5586 = (Vector3.new(0, 1.5, 0.35000002)).Magnitude
		local v5587 = Vector3.new(1.2, 1.2, v5586)
		local v5588 = CFrame.lookAt(Vector3.new(0, 3.35, -1.325), Vector3.new(0, 4.1, -1.15))
		local v5589 = v_u_27(p5547, "Neck", v5587, v5585, v5551)
		local v5590 = v5555.CFrame
		local v5591 = p5547.s
		v5589.CFrame = v5590 * (v5588.Rotation + v5588.Position * v5591)
		local v5592 = Instance.new("WeldConstraint")
		v5592.Part0 = v5555
		v5592.Part1 = v5589
		v5592.Parent = v5589
		local v5593 = p5547.glow
		local v5594 = (Vector3.new(0, 2.1, -0.60000014)).Magnitude
		local v5595 = Vector3.new(0.35, 0.35, v5594)
		local v5596 = CFrame.lookAt(Vector3.new(0, 1.45, -1.85), Vector3.new(0, 2.5, -2.15))
		local v5597 = v_u_27(p5547, "NeckGlow", v5595, v5593, v5552)
		local v5598 = v5555.CFrame
		local v5599 = p5547.s
		v5597.CFrame = v5598 * (v5596.Rotation + v5596.Position * v5599)
		local v5600 = Instance.new("WeldConstraint")
		v5600.Part0 = v5555
		v5600.Part1 = v5597
		v5600.Parent = v5597
		local v5601 = p5547.glow
		local v5602 = (Vector3.new(0, 1.4000001, 0.35000014)).Magnitude
		local v5603 = Vector3.new(0.32, 0.32, v5602)
		local v5604 = CFrame.lookAt(Vector3.new(0, 3.2, -1.975), Vector3.new(0, 3.9, -1.8))
		local v5605 = v_u_27(p5547, "NeckGlow", v5603, v5601, v5552)
		local v5606 = v5555.CFrame
		local v5607 = p5547.s
		v5605.CFrame = v5606 * (v5604.Rotation + v5604.Position * v5607)
		local v5608 = Instance.new("WeldConstraint")
		v5608.Part0 = v5555
		v5608.Part1 = v5605
		v5608.Parent = v5605
		for _, v5609 in { Vector3.new(0, 1.4, -0.55), Vector3.new(0, 2.5, -0.85), Vector3.new(0, 3.6, -0.55) } do
			local v5610 = p5547.trim
			local v5611 = CFrame.new(v5609) * CFrame.Angles(0.5, 0, 0)
			local v5612 = v_u_27(p5547, "NeckFin", Vector3.new(0.1, 0.8, 0.8), v5610, v5552)
			local v5613 = v5555.CFrame
			local v5614 = p5547.s
			v5612.CFrame = v5613 * (v5611.Rotation + v5611.Position * v5614)
			local v5615 = Instance.new("WeldConstraint")
			v5615.Part0 = v5555
			v5615.Part1 = v5612
			v5615.Parent = v5612
		end
		v5575, v5576 = v_u_40(p5547, v5555, "Head", v5574, p5547.skin, CFrame.new(0, 4.6, -1.45), CFrame.new(0, 0, 0.5), v5551)
	else
		v5575, v5576 = v_u_40(p5547, v5555, "Head", v5574, p5547.skin, CFrame.new(0, 0.05, -v5554.Z / 2), CFrame.new(0, 0, v5574.Z / 2 - 0.15), v5551)
	end
	local v5616 = -v5574.Z / 2
	local v5617 = v5550 and 1.6 or 1
	local v5618 = v5574.X * 0.9
	local v5619 = v5617 * 0.28
	local v5620 = v5574.Z * 0.88
	local v5621 = Vector3.new(v5618, v5619, v5620)
	local v5622 = p5547.pants
	local v5623 = CFrame.new(0, -v5574.Y / 2 - v5617 * 0.05, v5617 * -0.15) * CFrame.Angles(-0.28, 0, 0)
	local v5624 = v_u_27(p5547, "Jaw", v5621, v5622, v5551)
	local v5625 = v5575.CFrame
	local v5626 = p5547.s
	v5624.CFrame = v5625 * (v5623.Rotation + v5623.Position * v5626)
	local v5627 = Instance.new("WeldConstraint")
	v5627.Part0 = v5575
	v5627.Part1 = v5624
	v5627.Parent = v5624
	local v5628 = v5574.X * 0.75
	local v5629 = v5617 * 0.25
	local v5630 = Vector3.new(v5628, v5629, 0.08)
	local v5631 = p5547.glow
	local v5632 = CFrame.new(0, -v5574.Y * 0.32, v5616 - 0.02)
	local v5633 = v_u_27(p5547, "Throat", v5630, v5631, v5552)
	local v5634 = v5575.CFrame
	local v5635 = p5547.s
	v5633.CFrame = v5634 * (v5632.Rotation + v5632.Position * v5635)
	local v5636 = Instance.new("WeldConstraint")
	v5636.Part0 = v5575
	v5636.Part1 = v5633
	v5636.Parent = v5633
	for v5637 = -1.5, 1.5 do
		local v5638 = Vector3.new(0.1, 0.24, 0.1) * v5617
		local v5639 = p5547.accent
		local v5640 = CFrame.new(v5637 * v5574.X * 0.2, -v5574.Y * 0.38, v5616 - 0.06) * CFrame.Angles(0, 0.7853981633974483, 0)
		local v5641 = Instance.new("Part")
		v5641.Name = "Tooth"
		v5641.Size = v5638 * p5547.s
		v5641.Color = v5639
		v5641.Material = Enum.Material.Plastic
		v5641.CanCollide = false
		v5641.CanTouch = false
		v5641.CanQuery = false
		v5641.Massless = true
		v5641.Anchored = false
		v5641.CastShadow = v5638.Magnitude > 1.1
		v5641.TopSurface = Enum.SurfaceType.Smooth
		v5641.BottomSurface = Enum.SurfaceType.Smooth
		v5641.Parent = p5547.model
		local v5642 = v5575.CFrame
		local v5643 = p5547.s
		v5641.CFrame = v5642 * (v5640.Rotation + v5640.Position * v5643)
		local v5644 = Instance.new("WeldConstraint")
		v5644.Part0 = v5575
		v5644.Part1 = v5641
		v5644.Parent = v5641
	end
	for _, v5645 in { -1, 1 } do
		local v5646 = Vector3.new(0.26, 0.16, 0.08) * v5617
		local v5647 = p5547.eye
		local v5648 = CFrame.new(v5645 * v5574.X * 0.38, v5574.Y * 0.22, v5616 - 0.03) * CFrame.Angles(0, 0, v5645 * 0.3)
		local v5649 = v_u_27(p5547, "Eye", v5646, v5647, v5552)
		local v5650 = v5575.CFrame
		local v5651 = p5547.s
		v5649.CFrame = v5650 * (v5648.Rotation + v5648.Position * v5651)
		local v5652 = Instance.new("WeldConstraint")
		v5652.Part0 = v5575
		v5652.Part1 = v5649
		v5652.Parent = v5649
		if v5550 then
			local v5653 = v5645 * 0.45
			local v5654 = Vector3.new(v5653, 0.5, 0.2)
			local v5655 = v5645 * 0.85
			local v5656 = Vector3.new(v5655, 1.3, 1.6)
			local v5657 = p5547.accent
			local v5658 = (v5654 + v5656) / 2
			local v5659 = (v5656 - v5654).Magnitude
			local v5660 = Vector3.new(0.3, 0.3, v5659)
			local v5661 = CFrame.lookAt(v5658, v5656)
			local v5662 = Instance.new("Part")
			v5662.Name = "Horn"
			v5662.Size = v5660 * p5547.s
			v5662.Color = v5657
			v5662.Material = Enum.Material.Plastic
			v5662.CanCollide = false
			v5662.CanTouch = false
			v5662.CanQuery = false
			v5662.Massless = true
			v5662.Anchored = false
			v5662.CastShadow = v5660.Magnitude > 1.1
			v5662.TopSurface = Enum.SurfaceType.Smooth
			v5662.BottomSurface = Enum.SurfaceType.Smooth
			v5662.Parent = p5547.model
			local v5663 = v5575.CFrame
			local v5664 = p5547.s
			v5662.CFrame = v5663 * (v5661.Rotation + v5661.Position * v5664)
			local v5665 = Instance.new("WeldConstraint")
			v5665.Part0 = v5575
			v5665.Part1 = v5662
			v5665.Parent = v5662
			local v5666 = p5547.glow
			local v5667 = CFrame.new(v5645 * 0.87, 1.34, 1.66) * v_u_3145
			local v5668 = v_u_27(p5547, "HornTip", Vector3.new(0.26, 0.26, 0.26), v5666, v5552)
			local v5669 = v5575.CFrame
			local v5670 = p5547.s
			v5668.CFrame = v5669 * (v5667.Rotation + v5667.Position * v5670)
			local v5671 = Instance.new("WeldConstraint")
			v5671.Part0 = v5575
			v5671.Part1 = v5668
			v5671.Parent = v5668
			local v5672 = p5547.trim
			local v5673 = CFrame.new(v5645 * (v5574.X / 2 + 0.08), 0, 0.5) * CFrame.Angles(0, v5645 * 0.35, 0)
			local v5674 = v_u_27(p5547, "Frill", Vector3.new(0.1, 1.1, 1.3), v5672, v5552)
			local v5675 = v5575.CFrame
			local v5676 = p5547.s
			v5674.CFrame = v5675 * (v5673.Rotation + v5673.Position * v5676)
			local v5677 = Instance.new("WeldConstraint")
			v5677.Part0 = v5575
			v5677.Part1 = v5674
			v5677.Parent = v5674
			local v5678 = v5645 * 0.5
			local v5679 = Vector3.new(v5678, -0.2, v5616)
			local v5680 = v5645 * 1.3
			local v5681 = v5616 - 0.6
			local v5682 = Vector3.new(v5680, -0.9, v5681)
			local v5683 = p5547.glow
			local v5684 = (v5679 + v5682) / 2
			local v5685 = (v5682 - v5679).Magnitude
			local v5686 = Vector3.new(0.1, 0.1, v5685)
			local v5687 = CFrame.lookAt(v5684, v5682)
			local v5688 = v_u_27(p5547, "Whisker", v5686, v5683, v5552)
			local v5689 = v5575.CFrame
			local v5690 = p5547.s
			v5688.CFrame = v5689 * (v5687.Rotation + v5687.Position * v5690)
			local v5691 = Instance.new("WeldConstraint")
			v5691.Part0 = v5575
			v5691.Part1 = v5688
			v5691.Parent = v5688
		else
			local v5692 = p5547.trim
			local v5693 = CFrame.new(v5645 * (v5574.X / 2 + 0.04), 0.1, 0.35) * CFrame.Angles(0, v5645 * 0.4, 0)
			local v5694 = v_u_27(p5547, "HeadFin", Vector3.new(0.08, 0.4, 0.5), v5692, v5552)
			local v5695 = v5575.CFrame
			local v5696 = p5547.s
			v5694.CFrame = v5695 * (v5693.Rotation + v5693.Position * v5696)
			local v5697 = Instance.new("WeldConstraint")
			v5697.Part0 = v5575
			v5697.Part1 = v5694
			v5697.Parent = v5694
		end
	end
	local v5698 = v_u_40
	local v5699 = v5554.X * 0.92
	local v5700 = v5554.Y * 0.92
	local v5701, v5702 = v5698(p5547, v5555, "Tail", Vector3.new(v5699, v5700, 1.6), p5547.shirt, CFrame.new(0, 0, v5554.Z / 2), CFrame.new(0, 0, -0.8), v5551)
	local v5703 = p5547.glow
	local v5704 = CFrame.new(0, v5554.Y * 0.46 + 0.02, 0)
	local v5705 = v_u_27(p5547, "Stripe", Vector3.new(0.16, 0.1, 1.6), v5703, v5552)
	local v5706 = v5701.CFrame
	local v5707 = p5547.s
	v5705.CFrame = v5706 * (v5704.Rotation + v5704.Position * v5707)
	local v5708 = Instance.new("WeldConstraint")
	v5708.Part0 = v5701
	v5708.Part1 = v5705
	v5708.Parent = v5705
	local v5709 = v_u_57(p5547, v5701, "Wiggle", Vector3.new(0.2, 0.2, 0.2), p5547.shirt, CFrame.new(0, 0, 0.8), CFrame.identity, Vector3.new(0, 1, 0), v5550 and 0.12 or 0.45, v5550 and 2 or 5, 0, {
		["hidden"] = true
	})
	local v5710, v5711
	if v5550 then
		v5710 = {
			Vector3.new(0, 0, 0),
			Vector3.new(0.8, 1.3, 1.6),
			Vector3.new(1.3, -0.7, 3.2),
			Vector3.new(0.7, 1, 4.7),
			Vector3.new(-0.1, -0.6, 6.1)
		}
		v5711 = {
			1.35,
			1.2,
			1,
			0.8
		}
	else
		v5710 = {
			Vector3.new(0, 0, 0),
			Vector3.new(0.55, 0, 1.3),
			Vector3.new(0.1, 0, 2.6),
			Vector3.new(-0.45, 0, 3.7),
			Vector3.new(-0.35, 0, 4.6)
		}
		v5711 = {
			0.8,
			0.68,
			0.52,
			0.38
		}
	end
	for v5712 = 1, 4 do
		local v5713 = v5710[v5712]
		local v5714 = v5710[v5712 + 1]
		local v5715 = v5711[v5712]
		local v5716 = p5547.shirt
		local v5717 = (v5713 + v5714) / 2
		local v5718 = (v5714 - v5713).Magnitude
		local v5719 = Vector3.new(v5715, v5715, v5718)
		local v5720 = CFrame.lookAt(v5717, v5714)
		local v5721 = v_u_27(p5547, "Body", v5719, v5716, v5551)
		local v5722 = v5709.CFrame
		local v5723 = p5547.s
		v5721.CFrame = v5722 * (v5720.Rotation + v5720.Position * v5723)
		local v5724 = Instance.new("WeldConstraint")
		v5724.Part0 = v5709
		v5724.Part1 = v5721
		v5724.Parent = v5721
		local v5725 = v5711[v5712] / 2
		local v5726 = Vector3.new(0, v5725, 0)
		local v5727 = v5710[v5712] + v5726
		local v5728 = v5710[v5712 + 1] + v5726
		local v5729 = v5617 * 0.12
		local v5730 = p5547.glow
		local v5731 = (v5727 + v5728) / 2
		local v5732 = (v5728 - v5727).Magnitude
		local v5733 = Vector3.new(v5729, v5729, v5732)
		local v5734 = CFrame.lookAt(v5731, v5728)
		local v5735 = v_u_27(p5547, "Stripe", v5733, v5730, v5552)
		local v5736 = v5709.CFrame
		local v5737 = p5547.s
		v5735.CFrame = v5736 * (v5734.Rotation + v5734.Position * v5737)
		local v5738 = Instance.new("WeldConstraint")
		v5738.Part0 = v5709
		v5738.Part1 = v5735
		v5738.Parent = v5735
	end
	local v5739
	if v5550 then
		v5739 = CFrame.new(v5710[5] + Vector3.new(0, 0.9, 0.3))
	else
		v5739 = CFrame.new(v5710[5] + Vector3.new(0, 0, 0.45))
	end
	local v5740 = v5617 * 0.9
	local v5741 = v5617 * 1
	local v5742 = v_u_27(p5547, "TailFin", Vector3.new(0.12, v5740, v5741), p5547.trim, v5552)
	local v5743 = v5709.CFrame
	local v5744 = p5547.s
	v5742.CFrame = v5743 * (v5739.Rotation + v5739.Position * v5744)
	local v5745 = Instance.new("WeldConstraint")
	v5745.Part0 = v5709
	v5745.Part1 = v5742
	v5745.Parent = v5742
	local v5746 = {}
	for _, v5747 in { 1, -1 } do
		local v5748 = v5747 == 1 and "Right" or "Left"
		local v5749 = Vector3.new(0.7, 0.06, 0.5) * v5617
		local _, v5750 = v_u_40(p5547, v5555, v5748 .. "Arm", v5749, p5547.trim, CFrame.new(v5747 * (v5554.X / 2 - 0.05), -v5554.Y * 0.2, -v5554.Z * 0.3) * CFrame.Angles(0, -v5747 * 0.4, -v5747 * 0.35), CFrame.new(-v5747 * v5749.X / 2, 0, 0), v5553)
		v5746[v5748 .. "Arm"] = v5750
		local _, v5751 = v_u_40(p5547, v5555, v5748 .. "Leg", Vector3.new(0.2, 0.2, 0.2), v_u_7, CFrame.new(v5747 * 0.2, 0, 0.4), CFrame.identity, {
			["hidden"] = true
		})
		v5746[v5748 .. "Leg"] = v5751
	end
	local v5752 = {
		["torso"] = v5555,
		["head"] = v5575,
		["waist"] = v5556,
		["neck"] = v5576,
		["rightArm"] = v5746.RightArm,
		["leftArm"] = v5746.LeftArm,
		["rightLeg"] = v5746.RightLeg,
		["leftLeg"] = v5746.LeftLeg,
		["tail"] = v5702,
		["lift"] = v5550 and 1 or 2.2
	}
	local v5753 = v5554.Y * 0.4
	v5752.trailTop = Vector3.new(0, v5753, 0.4)
	local v5754 = -v5554.Y * 0.4
	v5752.trailBottom = Vector3.new(0, v5754, 0.4)
	v5752.d = v_u_15.normal
	return v5752
end
local v_u_5912 = {
	["crow"] = v5225,
	["bat"] = v5225,
	["drake"] = function(p5756, p5757, _) -- name: drake
		-- upvalues: (copy) v_u_40, (copy) v_u_27, (copy) v_u_13, (copy) v_u_57, (copy) v_u_2573, (copy) v_u_15
		local v5758 = {
			["material"] = p5756.mat
		}
		local v5759 = {
			["neon"] = true
		}
		local v5760, v5761 = v_u_40(p5756, p5757, "Torso", Vector3.new(1.8, 1.5, 3), p5756.shirt, CFrame.identity, CFrame.identity, v5758)
		local v5762 = p5756.glow
		local v5763 = CFrame.new(0, -0.7, -0.05)
		local v5764 = v_u_27(p5756, "Belly", Vector3.new(1.26, 0.3, 2.55), v5762, v5759)
		local v5765 = v5760.CFrame
		local v5766 = p5756.s
		v5764.CFrame = v5765 * (v5763.Rotation + v5763.Position * v5766)
		local v5767 = Instance.new("WeldConstraint")
		v5767.Part0 = v5760
		v5767.Part1 = v5764
		v5767.Parent = v5764
		local v5768 = p5756.shirt
		local v5769 = (Vector3.new(0, 1.1999999, -0.79999995)).Magnitude
		local v5770 = Vector3.new(0.8, 0.8, v5769)
		local v5771 = CFrame.lookAt(Vector3.new(0, 0.95, -1.6), Vector3.new(0, 1.55, -2))
		local v5772 = v_u_27(p5756, "Neck", v5770, v5768, v5758)
		local v5773 = v5760.CFrame
		local v5774 = p5756.s
		v5772.CFrame = v5773 * (v5771.Rotation + v5771.Position * v5774)
		local v5775 = Instance.new("WeldConstraint")
		v5775.Part0 = v5760
		v5775.Part1 = v5772
		v5775.Parent = v5772
		local v5776 = p5756.glow
		local v5777 = (Vector3.new(0, 1.15, -0.79999995)).Magnitude
		local v5778 = Vector3.new(0.3, 0.3, v5777)
		local v5779 = CFrame.lookAt(Vector3.new(0, 0.72499996, -1.9), Vector3.new(0, 1.3, -2.3))
		local v5780 = v_u_27(p5756, "NeckGlow", v5778, v5776, v5759)
		local v5781 = v5760.CFrame
		local v5782 = p5756.s
		v5780.CFrame = v5781 * (v5779.Rotation + v5779.Position * v5782)
		local v5783 = Instance.new("WeldConstraint")
		v5783.Part0 = v5760
		v5783.Part1 = v5780
		v5783.Parent = v5780
		local v5784, v5785 = v_u_40(p5756, v5760, "Head", Vector3.new(1.1, 0.9, 1.3), p5756.skin, CFrame.new(0, 1.75, -2.25), CFrame.new(0, 0, 0.35), v5758)
		local v5786 = p5756.skin
		local v5787 = CFrame.new(0, -0.1, -0.9699999761581422)
		local v5788 = v_u_27(p5756, "Snout", Vector3.new(0.8, 0.5, 0.8), v5786, v5758)
		local v5789 = v5784.CFrame
		local v5790 = p5756.s
		v5788.CFrame = v5789 * (v5787.Rotation + v5787.Position * v5790)
		local v5791 = Instance.new("WeldConstraint")
		v5791.Part0 = v5784
		v5791.Part1 = v5788
		v5791.Parent = v5788
		local v5792 = p5756.pants
		local v5793 = CFrame.new(0, -0.42, -0.7999999761581421) * CFrame.Angles(0.22, 0, 0)
		local v5794 = v_u_27(p5756, "Jaw", Vector3.new(0.72, 0.22, 1.05), v5792, v5758)
		local v5795 = v5784.CFrame
		local v5796 = p5756.s
		v5794.CFrame = v5795 * (v5793.Rotation + v5793.Position * v5796)
		local v5797 = Instance.new("WeldConstraint")
		v5797.Part0 = v5784
		v5797.Part1 = v5794
		v5797.Parent = v5794
		local v5798 = p5756.glow
		local v5799 = CFrame.new(0, -0.3, -0.8999999761581421) * CFrame.Angles(0.1, 0, 0)
		local v5800 = v_u_27(p5756, "Fire", Vector3.new(0.6, 0.12, 0.8), v5798, v5759)
		local v5801 = v5784.CFrame
		local v5802 = p5756.s
		v5800.CFrame = v5801 * (v5799.Rotation + v5799.Position * v5802)
		local v5803 = Instance.new("WeldConstraint")
		v5803.Part0 = v5784
		v5803.Part1 = v5800
		v5803.Parent = v5800
		for _, v5804 in { -1, 1 } do
			local v5805 = p5756.eye
			local v5806 = CFrame.new(v5804 * 0.4, 0.18, -0.6699999761581421) * CFrame.Angles(0, 0, v5804 * 0.3)
			local v5807 = v_u_27(p5756, "Eye", Vector3.new(0.3, 0.15, 0.08), v5805, v5759)
			local v5808 = v5784.CFrame
			local v5809 = p5756.s
			v5807.CFrame = v5808 * (v5806.Rotation + v5806.Position * v5809)
			local v5810 = Instance.new("WeldConstraint")
			v5810.Part0 = v5784
			v5810.Part1 = v5807
			v5810.Parent = v5807
			local v5811 = v5804 * 0.3
			local v5812 = Vector3.new(v5811, 0.35, 0.1)
			local v5813 = v5804 * 0.55
			local v5814 = Vector3.new(v5813, 0.75, 1.1)
			local v5815 = p5756.accent
			local v5816 = (v5812 + v5814) / 2
			local v5817 = (v5814 - v5812).Magnitude
			local v5818 = Vector3.new(0.22, 0.22, v5817)
			local v5819 = CFrame.lookAt(v5816, v5814)
			local v5820 = Instance.new("Part")
			v5820.Name = "Horn"
			v5820.Size = v5818 * p5756.s
			v5820.Color = v5815
			v5820.Material = Enum.Material.Plastic
			v5820.CanCollide = false
			v5820.CanTouch = false
			v5820.CanQuery = false
			v5820.Massless = true
			v5820.Anchored = false
			v5820.CastShadow = v5818.Magnitude > 1.1
			v5820.TopSurface = Enum.SurfaceType.Smooth
			v5820.BottomSurface = Enum.SurfaceType.Smooth
			v5820.Parent = p5756.model
			local v5821 = v5784.CFrame
			local v5822 = p5756.s
			v5820.CFrame = v5821 * (v5819.Rotation + v5819.Position * v5822)
			local v5823 = Instance.new("WeldConstraint")
			v5823.Part0 = v5784
			v5823.Part1 = v5820
			v5823.Parent = v5820
			local v5824 = v5804 * 0.45
			local v5825 = Vector3.new(v5824, 0.15, 0.3)
			local v5826 = v5804 * 0.85
			local v5827 = Vector3.new(v5826, 0.35, 0.9)
			local v5828 = p5756.accent
			local v5829 = (v5825 + v5827) / 2
			local v5830 = (v5827 - v5825).Magnitude
			local v5831 = Vector3.new(0.16, 0.16, v5830)
			local v5832 = CFrame.lookAt(v5829, v5827)
			local v5833 = Instance.new("Part")
			v5833.Name = "Horn"
			v5833.Size = v5831 * p5756.s
			v5833.Color = v5828
			v5833.Material = Enum.Material.Plastic
			v5833.CanCollide = false
			v5833.CanTouch = false
			v5833.CanQuery = false
			v5833.Massless = true
			v5833.Anchored = false
			v5833.CastShadow = v5831.Magnitude > 1.1
			v5833.TopSurface = Enum.SurfaceType.Smooth
			v5833.BottomSurface = Enum.SurfaceType.Smooth
			v5833.Parent = p5756.model
			local v5834 = v5784.CFrame
			local v5835 = p5756.s
			v5833.CFrame = v5834 * (v5832.Rotation + v5832.Position * v5835)
			local v5836 = Instance.new("WeldConstraint")
			v5836.Part0 = v5784
			v5836.Part1 = v5833
			v5836.Parent = v5833
			local v5837 = v_u_13
			local v5838, v5839 = CFrame.new(v5804 * 0.25, -0.38, -1.2699999761581422)
			local v5840 = v_u_27(p5756, "Fang", Vector3.new(0.1, 0.2, 0.08), v5837, v5839)
			local v5841 = v5784.CFrame
			local v5842 = p5756.s
			v5840.CFrame = v5841 * (v5838.Rotation + v5838.Position * v5842)
			local v5843 = Instance.new("WeldConstraint")
			v5843.Part0 = v5784
			v5843.Part1 = v5840
			v5843.Parent = v5840
			local v5844 = p5756.trim
			local v5845 = CFrame.new(v5804 * 0.600000011920929, -0.2, 0.2) * CFrame.Angles(0, v5804 * 0.3, 0)
			local v5846 = v_u_27(p5756, "Frill", Vector3.new(0.08, 0.45, 0.5), v5844, v5758)
			local v5847 = v5784.CFrame
			local v5848 = p5756.s
			v5846.CFrame = v5847 * (v5845.Rotation + v5845.Position * v5848)
			local v5849 = Instance.new("WeldConstraint")
			v5849.Part0 = v5784
			v5849.Part1 = v5846
			v5849.Parent = v5846
		end
		local v5850 = #p5756.swings + 1
		for _, v5851 in { -1, 1 } do
			local v5852 = v_u_57(p5756, v5760, "Wing", Vector3.new(3, 0.12, 2), p5756.trim, CFrame.new(v5851 * 0.75, 0.65, -0.5) * CFrame.Angles(0, 0, v5851 * 0.55), CFrame.new(-v5851 * 1.5, 0, -0.8), Vector3.new(0, 0, v5851), 0.28, 3.5, 0.1, v5758)
			local v5853 = p5756.shirt
			local v5854 = CFrame.new(0, 0.04, -0.95)
			local v5855 = v_u_27(p5756, "WingBone", Vector3.new(3.1, 0.2, 0.2), v5853, v5758)
			local v5856 = v5852.CFrame
			local v5857 = p5756.s
			v5855.CFrame = v5856 * (v5854.Rotation + v5854.Position * v5857)
			local v5858 = Instance.new("WeldConstraint")
			v5858.Part0 = v5852
			v5858.Part1 = v5855
			v5858.Parent = v5855
			for v5859 = 0, 2 do
				local v5860 = v5851 * (v5859 * 0.9 + -0.9)
				local v5861 = Vector3.new(v5860, 0.03, -0.9)
				local v5862 = v5860 + v5851 * (v5859 * 0.25 + 0.3)
				local v5863 = Vector3.new(v5862, 0.03, 0.9)
				local v5864 = p5756.glow
				local v5865 = (v5861 + v5863) / 2
				local v5866 = (v5863 - v5861).Magnitude
				local v5867 = Vector3.new(0.1, 0.1, v5866)
				local v5868 = CFrame.lookAt(v5865, v5863)
				local v5869 = v_u_27(p5756, "WingVein", v5867, v5864, v5759)
				local v5870 = v5852.CFrame
				local v5871 = p5756.s
				v5869.CFrame = v5870 * (v5868.Rotation + v5868.Position * v5871)
				local v5872 = Instance.new("WeldConstraint")
				v5872.Part0 = v5852
				v5872.Part1 = v5869
				v5872.Parent = v5869
			end
			local v5873 = p5756.accent
			local v5874, v5875 = CFrame.new(v5851 * 1.6, 0.04, -1.05)
			local v5876 = v_u_27(p5756, "WingClaw", Vector3.new(0.18, 0.18, 0.4), v5873, v5875)
			local v5877 = v5852.CFrame
			local v5878 = p5756.s
			v5876.CFrame = v5877 * (v5874.Rotation + v5874.Position * v5878)
			local v5879 = Instance.new("WeldConstraint")
			v5879.Part0 = v5852
			v5879.Part1 = v5876
			v5879.Parent = v5876
		end
		local v5880 = math.random() * 6
		for v5881 = v5850, #p5756.swings do
			p5756.swings[v5881].offset = v5880
		end
		local v5882 = {}
		for _, v5883 in {
			{
				["name"] = "RightArm",
				["x"] = 0.7,
				["z"] = -1
			},
			{
				["name"] = "LeftArm",
				["x"] = -0.7,
				["z"] = -1
			},
			{
				["name"] = "RightLeg",
				["x"] = 0.7,
				["z"] = 1
			},
			{
				["name"] = "LeftLeg",
				["x"] = -0.7,
				["z"] = 1
			}
		} do
			local v5884, v5885 = v_u_40(p5756, v5760, v5883.name, Vector3.new(0.6, 1.3, 0.6), p5756.pants, CFrame.new(v5883.x, -0.4, v5883.z), CFrame.new(0, 0.6499999761581421, 0), v5758)
			v5882[v5883.name] = v5885
			local v5886 = p5756.accent
			local v5887 = CFrame.new(0, -0.5299999761581421, -0.1)
			local v5888 = v_u_27(p5756, "Claws", Vector3.new(0.75, 0.25, 0.90000004), v5886, v5758)
			local v5889 = v5884.CFrame
			local v5890 = p5756.s
			v5888.CFrame = v5889 * (v5887.Rotation + v5887.Position * v5890)
			local v5891 = Instance.new("WeldConstraint")
			v5891.Part0 = v5884
			v5891.Part1 = v5888
			v5891.Parent = v5888
		end
		local v5892, v5893 = v_u_40(p5756, v5760, "Tail", Vector3.new(0.7, 0.6, 1.6), p5756.shirt, CFrame.new(0, 0.15, 1.4) * CFrame.Angles(0.2, 0, 0), CFrame.new(0, 0, -0.8), v5758)
		local v5894 = p5756.shirt
		local v5895 = CFrame.new(0, -0.05, 1.4) * CFrame.Angles(0.1, 0, 0)
		local v5896 = v_u_27(p5756, "Tail", Vector3.new(0.5, 0.42, 1.4), v5894, v5758)
		local v5897 = v5892.CFrame
		local v5898 = p5756.s
		v5896.CFrame = v5897 * (v5895.Rotation + v5895.Position * v5898)
		local v5899 = Instance.new("WeldConstraint")
		v5899.Part0 = v5892
		v5899.Part1 = v5896
		v5899.Parent = v5896
		local v5900 = p5756.shirt
		local v5901 = CFrame.new(0, -0.1, 2.6)
		local v5902 = v_u_27(p5756, "Tail", Vector3.new(0.34, 0.3, 1.2), v5900, v5758)
		local v5903 = v5892.CFrame
		local v5904 = p5756.s
		v5902.CFrame = v5903 * (v5901.Rotation + v5901.Position * v5904)
		local v5905 = Instance.new("WeldConstraint")
		v5905.Part0 = v5892
		v5905.Part1 = v5902
		v5905.Parent = v5902
		local v5906 = p5756.glow
		local v5907 = CFrame.new(0, -0.1, 3.35) * CFrame.Angles(0, 0.7853981633974483, 0)
		local v5908 = v_u_27(p5756, "TailSpade", Vector3.new(0.7, 0.12, 0.7), v5906, v5759)
		local v5909 = v5892.CFrame
		local v5910 = p5756.s
		v5908.CFrame = v5909 * (v5907.Rotation + v5907.Position * v5910)
		local v5911 = Instance.new("WeldConstraint")
		v5911.Part0 = v5892
		v5911.Part1 = v5908
		v5911.Parent = v5908
		v_u_2573(p5756, v5760, Vector3.new(1.8, 1.5, 3))
		return {
			["torso"] = nil,
			["head"] = nil,
			["waist"] = nil,
			["neck"] = nil,
			["rightArm"] = nil,
			["leftArm"] = nil,
			["rightLeg"] = nil,
			["leftLeg"] = nil,
			["tail"] = nil,
			["lift"] = 1.699999952316284,
			["trailTop"] = Vector3.new(0, 0.675, 0.4),
			["trailBottom"] = Vector3.new(0, -0.675, 0.4),
			["d"] = nil,
			["torso"] = v5760,
			["head"] = v5784,
			["waist"] = v5761,
			["neck"] = v5785,
			["rightArm"] = v5882.RightArm,
			["leftArm"] = v5882.LeftArm,
			["rightLeg"] = v5882.RightLeg,
			["leftLeg"] = v5882.LeftLeg,
			["tail"] = v5893,
			["d"] = v_u_15.normal
		}
	end,
	["angler"] = v5414,
	["lanternfish"] = v5414,
	["squid"] = v5546,
	["jelly"] = v5546,
	["eel"] = v5755,
	["leviathan"] = v5755
}
local v_u_5913 = {
	["boar"] = true,
	["lynx"] = true,
	["ram"] = true,
	["hare"] = true,
	["cerberus"] = true,
	["lizard"] = true,
	["seal"] = true
}
local function v_u_5927(p5914, p5915, p5916, p5917) -- name: nameTag
	-- upvalues: (copy) v_u_5
	local v5918 = Instance.new("BillboardGui")
	v5918.Name = "Tag"
	v5918.Adornee = p5915
	v5918.Size = UDim2.fromScale(math.min(p5917, 1.6) * 5, math.min(p5917, 1.6) * 1.2)
	v5918.StudsOffsetWorldSpace = Vector3.new(0, p5916, 0)
	v5918.LightInfluence = 0
	v5918.MaxDistance = 160
	local v5919 = Instance.new("TextLabel")
	v5919.Name = "Name"
	v5919.BackgroundTransparency = 1
	v5919.Size = UDim2.fromScale(1, 0.45)
	v5919.FontFace = v_u_5
	v5919.TextScaled = true
	v5919.Text = p5914.name
	local v5920
	if p5914.boss then
		v5920 = Color3.fromRGB(255, 80, 90)
	else
		v5920 = Color3.new(1, 1, 1)
	end
	v5919.TextColor3 = v5920
	local v5921 = Instance.new("UIStroke")
	v5921.Thickness = 2
	v5921.Parent = v5919
	v5919.Parent = v5918
	local v5922
	if p5914.boss then
		v5922 = nil
	else
		local v5923 = Instance.new("Frame")
		v5923.Name = "Back"
		v5923.BackgroundColor3 = Color3.fromRGB(25, 25, 30)
		v5923.BorderSizePixel = 0
		v5923.Position = UDim2.fromScale(0.1, 0.55)
		v5923.Size = UDim2.fromScale(0.8, 0.35)
		local v5924 = Instance.new("UICorner")
		v5924.CornerRadius = UDim.new(1, 0)
		v5924.Parent = v5923
		v5922 = Instance.new("Frame")
		v5922.Name = "Fill"
		v5922.BackgroundColor3 = Color3.fromRGB(96, 230, 90)
		v5922.BorderSizePixel = 0
		v5922.Size = UDim2.fromScale(1, 1)
		local v5925 = Instance.new("UICorner")
		v5925.CornerRadius = UDim.new(1, 0)
		v5925.Parent = v5922
		v5922.Parent = v5923
		local v5926 = Instance.new("UIStroke")
		v5926.Thickness = 1.5
		v5926.Parent = v5923
		v5923.Parent = v5918
	end
	return v5918, v5922
end
function v4.build(p5928, p5929) -- name: build
	-- upvalues: (copy) v_u_6, (copy) v_u_16, (copy) v_u_27, (copy) v_u_5912, (copy) v_u_2978, (copy) v_u_2626, (copy) v_u_2795, (copy) v_u_5913, (copy) v_u_5034, (copy) v_u_4711, (copy) v_u_3052, (copy) v_u_3141, (copy) v_u_2541, (copy) v_u_714, (copy) v_u_1345, (copy) v_u_3705, (copy) v_u_1821, (copy) v_u_4046, (copy) v_u_2419, (copy) v_u_4622, (copy) v_u_68, (copy) v_u_5927, (copy) v_u_187, (copy) v_u_3, (copy) v_u_2, (copy) v_u_14
	local v5930 = p5928.look
	local v5931 = p5928.scale
	local v5932 = p5928.boss == true
	local v5933 = Instance.new("Model")
	v5933.Name = "Foe" .. p5929
	v5933:SetAttribute("FoeId", p5929)
	local v5934 = v_u_6(v5930.skin)
	local v5935 = {
		["model"] = v5933,
		["s"] = v5931,
		["look"] = v5930,
		["skin"] = v5934
	}
	if v5930.arm then
		v5934 = v_u_6(v5930.arm)
	end
	v5935.arm = v5934
	v5935.shirt = v_u_6(v5930.shirt)
	v5935.pants = v_u_6(v5930.pants)
	v5935.accent = v_u_6(v5930.accent)
	v5935.trim = v_u_6(v5930.trim or v5930.accent)
	v5935.glow = v_u_6(v5930.glow)
	v5935.eye = v_u_6(v5930.eye)
	v5935.mat = v_u_16[v5930.body or "plastic"]
	v5935.swings = {}
	v5935.orbits = {}
	v5935.trails = {}
	v5935.hidden = {}
	local v5936 = v_u_27(v5935, "Root", Vector3.new(2, 2, 1), Color3.new(1, 1, 1), {
		["hidden"] = true
	})
	v5936.Anchored = true
	v5936.CFrame = CFrame.identity
	v5933.PrimaryPart = v5936
	local v5937 = v5930.rig or "biped"
	local v5938
	if v5937 == "wolf" then
		local v5939 = v5930.beast or "wolf"
		local v5940 = v_u_5912[v5939]
		if v5939 == "shark" or v5939 == "koi" then
			v5938 = v_u_2978(v5935, v5936, v5939)
		elseif v5939 == "wolf" then
			v5938 = v_u_2626(v5935, v5936)
		elseif v5940 then
			v5938 = v5940(v5935, v5936, v5939)
		else
			v5938 = v_u_2795(v5935, v5936, v5939)
			if v_u_5913[v5939] then
				v_u_5034(v5935, v5938, v5939)
			end
		end
		v_u_4711(v5935, v5938)
	elseif v5937 == "scorpion" then
		v5938 = v_u_3052(v5935, v5936)
	elseif v5937 == "spider" then
		v5938 = v_u_3141(v5935, v5936)
	else
		v5938 = v_u_2541(v5935, v5936, v5937 == "float")
		local v5941 = v5938.d.head
		v_u_714(v5935, v5938.head, v5941)
		v_u_1345(v5935, v5938.head, v5941)
		v_u_3705(v5935, v5938.head, v5941)
		v_u_1821(v5935, v5938)
		v_u_4046(v5935, v5938)
	end
	if v5937 == "biped" or v5937 == "float" then
		v_u_2419(v5935, v5938, v5932)
		v_u_4622(v5935, v5938, v5932)
	end
	if v5930.body == "ghost" then
		for _, v5942 in v5933:GetDescendants() do
			if not v5942:IsA("BasePart") or (v5942 == v5936 or (v5935.hidden[v5942] or (v5942.Material == Enum.Material.Neon or v5942.Transparency >= 0.35))) then
				continue
			end
			v5942.Transparency = 0.35
		end
	end
	v_u_68(v5935, v5938.torso, v5938.trailTop, v5938.trailBottom, v5937 == "float" and 0.35 or 0.2, 0.55)
	local v5943, v5944 = v5933:GetBoundingBox()
	local v5945 = v5943.Position.Y + v5944.Y / 2
	local v5946, v5947 = v_u_5927(p5928, v5938.head, v5945 - v5938.head.Position.Y + math.min(v5931, 1.6) * 0.9, v5931)
	v5946.Parent = v5933
	local v5948 = v5938.lift * v5931
	local v5949 = v_u_187(v5935, v5938.torso, v5936, v5948, v5932)
	local v5950 = {}
	local v5951
	if v5932 then
		local v5952 = v_u_3.loop
		local v5953 = v5938.torso
		local v5954 = v5935.glow
		local v5955 = v5931 * 0.5
		table.insert(v5950, v5952("Aura", v5953, v5954, v5955, 0.5))
		local v5956 = Instance.new("PointLight")
		v5956.Color = v5935.glow:Lerp(Color3.new(1, 1, 1), 0.55)
		v5956.Brightness = 1.3
		v5956.Range = 8 + v5931 * 4
		v5956.Shadows = false
		v5956.Parent = v5938.torso
		v5951 = v_u_27(v5935, "Ground", Vector3.new(6.5, 0.1, 6.5), v5935.glow, {
			["alpha"] = 1
		})
		v5951.Anchored = true
		v5951.CastShadow = false
		v5951.CFrame = CFrame.new(0, -v5948 + 0.12, 0)
		local v5957 = Instance.new("Decal")
		v5957.Face = Enum.NormalId.Top
		v5957.Texture = v_u_2.EnemySigil
		v5957.Color3 = v5935.glow
		v5957.Transparency = 0.25
		v5957.Parent = v5951
	else
		v5951 = nil
	end
	local v5958 = {}
	local v5959 = {}
	for _, v5960 in v5933:GetDescendants() do
		if not v5960:IsA("BasePart") or (v5960 == v5936 or (v5960 == v5951 or v5935.hidden[v5960])) then
			continue
		end
		table.insert(v5958, v5960)
		local v5961 = v5960.Color
		table.insert(v5959, v5961)
	end
	return {
		["model"] = v5933,
		["root"] = v5936,
		["torso"] = v5938.torso,
		["head"] = v5938.head,
		["parts"] = v5958,
		["colors"] = v5959,
		["waist"] = v5938.waist,
		["neck"] = v5938.neck,
		["rightArm"] = v5938.rightArm,
		["leftArm"] = v5938.leftArm,
		["rightLeg"] = v5938.rightLeg,
		["leftLeg"] = v5938.leftLeg,
		["tail"] = v5938.tail,
		["swings"] = v5935.swings,
		["orbits"] = v5935.orbits,
		["emitters"] = v5949,
		["trails"] = v5935.trails,
		["stops"] = v5950,
		["ground"] = v5951,
		["rig"] = v5937,
		["glow"] = v5935.glow,
		["boss"] = v5932,
		["ready"] = (v5937 == "biped" or v5937 == "float") and (v_u_14[v5930.weapon or "none"] or 0) or 0,
		["scale"] = v5931,
		["lift"] = v5948,
		["bar"] = v5947,
		["tag"] = v5946
	}
end
v4.nameTag = v_u_5927
function v4.aura(p5962, p5963, p5964, p5965, p5966) -- name: aura
	-- upvalues: (copy) v_u_6, (copy) v_u_187
	local v5967 = p5962.look
	local v5968 = v_u_6(v5967.skin)
	return v_u_187({
		["model"] = p5964.Parent,
		["s"] = p5966,
		["look"] = v5967,
		["skin"] = v5968,
		["arm"] = v5968,
		["shirt"] = v_u_6(v5967.shirt),
		["pants"] = v_u_6(v5967.pants),
		["accent"] = v_u_6(v5967.accent),
		["trim"] = v_u_6(v5967.trim or v5967.accent),
		["glow"] = v_u_6(v5967.glow),
		["eye"] = v_u_6(v5967.eye),
		["mat"] = Enum.Material.Plastic,
		["swings"] = {},
		["orbits"] = {},
		["trails"] = {},
		["hidden"] = {}
	}, p5963, p5964, p5965, p5962.boss == true)
end
return v4