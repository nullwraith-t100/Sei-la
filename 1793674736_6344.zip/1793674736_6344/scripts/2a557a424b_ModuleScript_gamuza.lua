local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF6FB5")
local v_u_8 = Color3.fromRGB(16, 110, 78)
local v_u_9 = Color3.fromRGB(205, 30, 120)
local v_u_10 = (Vector3.new(-0.438, 0.425, 0.792)).Unit
local function v_u_16(p11, p12) -- name: alignTo
	local v13 = p11:Cross(p12)
	local v14 = p11:Dot(p12)
	local v15 = math.clamp(v14, -1, 1)
	if v13.Magnitude < 0.0001 then
		if v15 > 0 then
			return CFrame.identity
		else
			return CFrame.Angles(0, 3.141592653589793, 0)
		end
	else
		return CFrame.fromAxisAngle(v13.Unit, (math.acos(v15)))
	end
end
local function v_u_27(p17, p18, p19, p20, p21, p22, p23, p24) -- name: stamp
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v25 = Instance.new("Attachment")
	v25.WorldCFrame = CFrame.new(p17) * CFrame.Angles(0, math.rad(p23), 0)
	v25.Parent = v_u_3.Terrain
	local v26 = Instance.new("ParticleEmitter")
	v26.Enabled = false
	v26.Texture = p18
	v26.Color = ColorSequence.new(p19)
	v26.LightEmission = 0.2
	v26.LightInfluence = 0
	v26.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v26.EmissionDirection = Enum.NormalId.Top
	v26.SpreadAngle = Vector2.zero
	v26.Speed = NumberRange.new(0.01)
	v26.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p20 / 2), NumberSequenceKeypoint.new(0.25, p21 / 2), NumberSequenceKeypoint.new(1, p21 / 2) })
	v26.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v26.Lifetime = NumberRange.new(p22)
	if p24 then
		v26.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v26.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v26.Parent = v25
	v26:Emit(1)
	v_u_1:AddItem(v25, p22 + 0.2)
end
return function(p_u_28)
	-- upvalues: (copy) v_u_4, (copy) v_u_27, (copy) v_u_6, (copy) v_u_8, (copy) v_u_2, (copy) v_u_16, (copy) v_u_10, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9
	return {
		["w7_gamuza"] = function(p_u_29, p30)
			-- upvalues: (ref) v_u_4, (copy) p_u_28, (ref) v_u_27, (ref) v_u_6, (ref) v_u_8, (ref) v_u_2, (ref) v_u_16, (ref) v_u_10, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9
			local v31 = v_u_4.color(p30.color)
			local v32 = p_u_29.headY / 1.5
			local v_u_33 = math.clamp(v32, 0.7, 3)
			local v34 = v_u_33 * 7.6
			local v_u_44 = p_u_28.throb(p_u_29, 5, 1.8, 1.4, function(p35)
				-- upvalues: (ref) p_u_28, (copy) p_u_29, (ref) v_u_27, (copy) v_u_33, (ref) v_u_6, (ref) v_u_8
				local v36 = p_u_28.feetAt(p_u_29, p35, 0.12)
				local v37 = p35.LookVector
				local v38 = p35.RightVector
				local v39 = -v37.X
				local v40 = -v37.Z
				local v41 = math.atan2(v39, v40)
				local v42 = math.deg(v41)
				for _, v43 in { -0.55, 0.55 } do
					v_u_27(v36 + v38 * v43 * v_u_33 + v37 * 0.5 * v_u_33, v_u_6.GamuzaHoof, v_u_8, v_u_33 * 0.8, v_u_33 * 1.9, 1.1, v42)
				end
				v_u_27(v36, v_u_6.HollowRing, v_u_8, v_u_33 * 2, v_u_33 * 7 * p_u_29.fx, 0.55, 0, true)
			end)
			local v60 = p_u_28.group(p_u_29, function(p45, p46)
				-- upvalues: (copy) v_u_33
				local v47 = CFrame.new
				local v48 = v_u_33 * 0.55
				local v49 = p46 * 1.3
				local v50 = p45 * v47(0, v48 + math.sin(v49) * 0.12 * v_u_33, v_u_33 * 1.15)
				local v51 = CFrame.Angles
				local v52 = 0
				local v53 = 0
				local v54 = p46 * 0.7
				local v55 = math.sin(v54) * 0.07 + 0.5585053606381855
				local v56
				if p46 < 1.8 then
					v56 = 0
				else
					local v57 = (p46 - 1.8) % 5
					if v57 > 0.6 then
						v56 = 0
					else
						local v58 = v57 / 0.6
						local v59 = math.clamp(v58, 0, 1)
						v56 = v59 * v59 * (3 - v59 * 2) * 3.141592653589793 * 2
					end
				end
				return v50 * v51(v52, v53, v55 + v56)
			end)
			local v61 = v_u_2:FindFirstChild("EyePieces")
			if v61 then
				v61 = v61:FindFirstChild("w7_gamuza")
			end
			local v62, v63, v64
			if v61 and v61:IsA("MeshPart") then
				v62 = v61:Clone()
				v62.Size = v61.Size * (v34 / (2.514 * v61.Size.Z / 2))
				if not v62:FindFirstChildWhichIsA("SurfaceAppearance") then
					v62.Color = v31
					v62.Material = Enum.Material.SmoothPlastic
				end
				v62.Anchored = true
				v62.CanCollide = false
				v62.CanQuery = false
				v62.CanTouch = false
				v62.CastShadow = false
				v62.Massless = true
				v62.Parent = v_u_4.folder()
				p_u_28.pin(p_u_29, v60, v62, v_u_16(v_u_10, Vector3.new(1, 0, 0)))
				v63 = v_u_10 * v34 / 2
				v64 = -v_u_10 * v34 / 2
			else
				local v65 = p_u_28.bar
				local v66 = v34 * 0.8
				local v67 = v_u_33 * 0.16
				local v68 = v_u_33 * 0.16
				v62 = v65(Vector3.new(v66, v67, v68), v31)
				v62.Material = Enum.Material.SmoothPlastic
				p_u_28.pin(p_u_29, v60, v62, CFrame.identity)
				for _, v69 in { 1, -1 } do
					local v70 = p_u_28.bar
					local v71 = v_u_33 * 0.5
					local v72 = v_u_33 * 0.5
					local v73 = v_u_33 * 0.12
					local v74 = v70(Vector3.new(v71, v72, v73), v_u_7)
					p_u_28.pin(p_u_29, v60, v74, CFrame.new(v69 * v34 * 0.42, 0, 0) * CFrame.Angles(0, 0, 0.7853981633974483))
				end
				local v75 = v34 * 0.45
				v63 = Vector3.new(v75, 0, 0)
				local v76 = -v34 * 0.45
				v64 = Vector3.new(v76, 0, 0)
			end
			for v77, v78 in { v63, v64 } do
				local v79 = Instance.new("Attachment")
				v79.Position = v78
				v79.Parent = v62
				local v80 = Instance.new("Attachment")
				v80.Position = v78 * 0.8
				v80.Parent = v62
				local v81 = Instance.new("Trail")
				v81.Attachment0 = v79
				v81.Attachment1 = v80
				local v82 = ColorSequence.new
				local v83
				if v77 == 1 then
					v83 = v_u_7
				else
					v83 = v31
				end
				v81.Color = v82(v83, v_u_8)
				v81.Transparency = NumberSequence.new(0.1, 1)
				v81.Lifetime = 0.3
				v81.MinLength = 0.2
				v81.LightEmission = 0.4
				v81.LightInfluence = 0
				v81.FaceCamera = true
				v81.Parent = v62
				local v84 = Instance.new("ParticleEmitter")
				v84.Texture = v_u_6.FxTwinkle
				v84.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v84.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v84.Color = ColorSequence.new(v_u_7)
				v84.LightEmission = 0.6
				v84.LightInfluence = 0
				v84.Size = NumberSequence.new(v_u_33 * 0.7 * p_u_29.fx)
				v84.Lifetime = NumberRange.new(0.5)
				v84.Speed = NumberRange.new(0)
				v84:SetAttribute("BaseRate", 0.8)
				v84.Rate = 0.8 * v_u_5.formRate()
				v84.Parent = v79
				p_u_28.own(p_u_29, v84)
			end
			local v85 = Instance.new("Attachment")
			v85.Position = v63 * 0.92
			v85.Parent = v62
			local v86 = Instance.new("Attachment")
			v86.Position = v64 * 0.92
			v86.Parent = v62
			local v87 = Instance.new("Beam")
			v87.Attachment0 = v85
			v87.Attachment1 = v86
			v87.Texture = v_u_6.Beam
			v87.TextureMode = Enum.TextureMode.Stretch
			v87.Color = ColorSequence.new({
				ColorSequenceKeypoint.new(0, v_u_7),
				ColorSequenceKeypoint.new(0.15, v31),
				ColorSequenceKeypoint.new(0.85, v31),
				ColorSequenceKeypoint.new(1, v_u_7)
			})
			v87.LightEmission = 0.5
			v87.LightInfluence = 0
			v87.Transparency = NumberSequence.new(0.25)
			v87.Width0 = v_u_33 * 0.75
			v87.Width1 = v_u_33 * 0.75
			v87.FaceCamera = true
			v87.Segments = 1
			v87.Parent = v62
			local v88 = p_u_28.bar(Vector3.new(0.2, 0.2, 0.2), v31, 1)
			v88.Massless = true
			p_u_28.add(p_u_29, v88, function(p89)
				-- upvalues: (copy) p_u_29, (copy) v_u_33
				return p89 * CFrame.new(0, p_u_29.headY + v_u_33 * 0.35, v_u_33 * 0.35)
			end)
			local v90 = Instance.new("Attachment")
			v90.Parent = v88
			local v_u_91 = Instance.new("Attachment")
			local v92 = v_u_33 * -1.7
			local v93 = v_u_33 * 2.6
			v_u_91.Position = Vector3.new(0, v92, v93)
			v_u_91.Parent = v88
			local v_u_94 = Instance.new("Beam")
			v_u_94.Attachment0 = v90
			v_u_94.Attachment1 = v_u_91
			v_u_94.Texture = v_u_6.GamuzaDrill
			v_u_94.TextureMode = Enum.TextureMode.Stretch
			v_u_94.TextureSpeed = 0.6
			v_u_94.Color = ColorSequence.new(v31, v_u_8)
			v_u_94.LightEmission = 0.4
			v_u_94.LightInfluence = 0
			v_u_94.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 1) })
			v_u_94.Width0 = v_u_33 * 1.2
			v_u_94.Width1 = v_u_33 * 0.25
			v_u_94.FaceCamera = true
			v_u_94.Segments = 12
			v_u_94.Parent = v88
			local v95 = p_u_29.ticks
			table.insert(v95, function(_, p96)
				-- upvalues: (copy) v_u_44, (copy) v_u_94, (copy) v_u_33, (copy) v_u_91
				local v97 = v_u_44()
				local v98 = v_u_94
				local v99 = p96 * 2.3
				v98.CurveSize0 = (math.sin(v99) * 0.5 + 0.6 + v97 * 1.5) * v_u_33
				local v100 = v_u_94
				local v101 = p96 * 2.3 + 1.4
				v100.CurveSize1 = (math.sin(v101) * 0.6 + -0.5 - v97 * 1.2) * v_u_33
				local v102 = v_u_91
				local v103 = p96 * 1.1
				local v104 = math.sin(v103) * 0.25 * v_u_33
				local v105 = (-1.7 + v97 * 0.9) * v_u_33
				local v106 = (2.6 + v97 * 0.8) * v_u_33
				v102.Position = Vector3.new(v104, v105, v106)
			end)
			local v107 = p_u_28.bar(Vector3.new(0.2, 0.2, 0.2), v31, 1)
			v107.Massless = true
			p_u_28.add(p_u_29, v107, function(p108)
				-- upvalues: (copy) p_u_29, (copy) v_u_33
				return p108 * CFrame.new(0, p_u_29.headY + v_u_33 * 0.55, v_u_33 * -0.05)
			end)
			for _, v109 in { -1, 1 } do
				local v110 = Instance.new("Attachment")
				local v111 = v109 * 0.4 * v_u_33
				v110.Position = Vector3.new(v111, 0, 0)
				local v112 = v109 * 0.55
				v110.Axis = Vector3.new(v112, 1, 0.25).Unit
				v110.SecondaryAxis = (Vector3.new(0, 0, 1)):Cross(v110.Axis).Unit
				v110.Parent = v107
				local v113 = Instance.new("Attachment")
				local v114 = v109 * 1.25 * v_u_33
				local v115 = v_u_33 * -0.5
				local v116 = v_u_33 * 0.5
				v113.Position = Vector3.new(v114, v115, v116)
				local v117 = v109 * 0.3
				v113.Axis = Vector3.new(v117, 1, -0.4).Unit
				v113.Parent = v107
				local v118 = Instance.new("Beam")
				v118.Attachment0 = v110
				v118.Attachment1 = v113
				v118.Texture = v_u_6.Beam
				v118.TextureMode = Enum.TextureMode.Stretch
				v118.Color = ColorSequence.new(Color3.fromRGB(210, 255, 236), v31)
				v118.LightEmission = 0.35
				v118.LightInfluence = 0
				v118.Transparency = NumberSequence.new(0, 0.1)
				v118.Width0 = v_u_33 * 0.55
				v118.Width1 = v_u_33 * 0.08
				v118.CurveSize0 = v_u_33 * 1.1
				v118.CurveSize1 = v_u_33 * -0.9
				v118.FaceCamera = true
				v118.Segments = 12
				v118.Parent = v107
				local v119 = v118:Clone()
				v119.Color = ColorSequence.new(v_u_8)
				v119.LightEmission = 0
				v119.Width0 = v_u_33 * 0.78
				v119.Width1 = v_u_33 * 0.18
				v119.Transparency = NumberSequence.new(0.1, 0.4)
				v119.ZOffset = -0.05
				v119.Parent = v107
			end
			local v120 = p_u_28.bar
			local v121 = v_u_33 * 2.6
			local v122 = v_u_33 * 3.2
			local v123 = v_u_33 * 2.2
			local v124 = v120(Vector3.new(v121, v122, v123), v31, 1)
			v124.Massless = true
			p_u_28.add(p_u_29, v124, function(p125)
				-- upvalues: (copy) v_u_33
				return p125 * CFrame.new(0, v_u_33 * -0.6, v_u_33 * 0.1)
			end)
			local v126 = Instance.new("ParticleEmitter")
			v126.Texture = v_u_6.GamuzaChevron
			v126.Color = ColorSequence.new(v31)
			v126.LightEmission = 0.25
			v126.LightInfluence = 0
			v126.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
			v126.EmissionDirection = Enum.NormalId.Top
			v126.SpreadAngle = Vector2.new(6, 6)
			v126.Speed = NumberRange.new(v_u_33 * 3, v_u_33 * 5)
			v126.Lifetime = NumberRange.new(0.7, 0.9)
			v126.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_33 * 0.25 * p_u_29.fx), NumberSequenceKeypoint.new(0.3, v_u_33 * 0.45 * p_u_29.fx), NumberSequenceKeypoint.new(1, v_u_33 * 0.3 * p_u_29.fx) })
			v126.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.2, 0.1),
				NumberSequenceKeypoint.new(0.7, 0.2),
				NumberSequenceKeypoint.new(1, 1)
			})
			v126.Shape = Enum.ParticleEmitterShape.Box
			v126.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v126:SetAttribute("BaseRate", 5)
			v126.Rate = 5 * v_u_5.formRate() * (p_u_29.fx > 1 and 2 or 1)
			v126.Parent = v124
			p_u_28.own(p_u_29, v126)
			local v_u_127 = v62:FindFirstChildWhichIsA("SurfaceAppearance")
			if v_u_127 then
				local v_u_128 = v_u_127.EmissiveStrength
				local v_u_129 = -1
				local v130 = p_u_29.ticks
				local function v133()
					-- upvalues: (copy) v_u_44, (ref) v_u_129, (copy) v_u_127, (copy) v_u_128
					local v131 = v_u_44() * 10
					local v132 = math.floor(v131) / 10
					if v132 ~= v_u_129 then
						v_u_129 = v132
						v_u_127.EmissiveStrength = v_u_128 * (v132 * 1.5 + 1)
					end
				end
				table.insert(v130, v133)
			end
			p_u_28.particles(p_u_29, "AuraMode", v31, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_28.particles(p_u_29, "AuraMode", v_u_9, {
				["rate"] = 0.12,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Sparks" }
			})
		end
	}
end