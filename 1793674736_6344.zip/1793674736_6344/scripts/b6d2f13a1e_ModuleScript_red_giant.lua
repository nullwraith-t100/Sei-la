local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("D8141E")
local v_u_8 = Color3.fromHex("2A0004")
local v_u_9 = Color3.fromRGB(255, 104, 34)
local v_u_10 = Color3.fromRGB(255, 196, 86)
local v_u_11 = Color3.fromRGB(255, 238, 206)
local v_u_12 = Color3.fromRGB(255, 104, 150)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.PartType.Ball
local function v_u_26(p15, p16, p17, p18, p19) -- name: picture
	-- upvalues: (copy) v_u_4
	local v20 = v_u_4.part
	local v21 = p16 * 2
	local v22 = p16 * 2
	local v23 = v20(Vector3.new(v21, 0.05, v22), p15, p18, {
		["transparency"] = 1
	})
	for _, v24 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v25 = Instance.new("Decal")
		v25.Face = v24
		v25.Texture = p17
		v25.Color3 = p18
		v25.Transparency = p19
		v25.Parent = v23
	end
	return v23
end
local function v_u_30(p27, p28) -- name: setAlpha
	for _, v29 in p27:GetChildren() do
		if not v29:IsA("Decal") then
			continue
		end
		v29.Transparency = p28
	end
end
local function v_u_40(p31) -- name: towardViewer
	-- upvalues: (copy) v_u_3
	local v32 = math.random() - 0.5
	local v33 = math.random() - 0.5
	local v34 = math.random() - 0.5
	local v35 = Vector3.new(v32, v33, v34) * 2
	local v36 = v_u_3.CurrentCamera
	local v37
	if v36 then
		local v38 = v36.CFrame.Position - p31
		v37 = v38.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v38.Unit
	else
		v37 = Vector3.new(0, 0, 1)
	end
	local v39 = v37 * 0.9 + v35
	return v39.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v39.Unit
end
return function(p_u_41)
	-- upvalues: (copy) v_u_26, (copy) v_u_1, (copy) v_u_30, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_4, (copy) v_u_11, (copy) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_13, (copy) v_u_12, (copy) v_u_10, (copy) v_u_5, (copy) v_u_40
	local function v_u_58(p_u_42, p_u_43, p_u_44, p45, p46, p_u_47, p_u_48, p49) -- name: flare
		-- upvalues: (ref) v_u_26, (ref) v_u_1, (copy) p_u_41, (ref) v_u_30
		local v_u_50 = p49 or 0
		local v_u_51 = v_u_26(p_u_42, p_u_43, p45, p46, v_u_50)
		v_u_1:AddItem(v_u_51, p_u_47 + 0.1)
		p_u_41.animate(p_u_47, 0, function(p52)
			-- upvalues: (copy) v_u_51, (copy) p_u_43, (copy) p_u_44, (copy) p_u_42, (copy) p_u_47, (copy) p_u_48, (ref) v_u_30, (copy) v_u_50
			local v53 = 1 - (1 - p52) ^ 3
			local v54 = v_u_51
			local v55 = p_u_43 + (p_u_44 - p_u_43) * v53
			local v56 = v55 * 2
			local v57 = v55 * 2
			v54.Size = Vector3.new(v56, 0.05, v57)
			v_u_51.CFrame = p_u_42 * CFrame.Angles(0, p52 * p_u_47 * p_u_48, 0)
			v_u_30(v_u_51, v_u_50 + (1 - v_u_50) * p52 ^ 1.5)
			if p52 >= 1 then
				v_u_51:Destroy()
			end
		end)
	end
	local function v_u_83(p59, p60, p_u_61, p_u_62, p63) -- name: flingTomoe
		-- upvalues: (ref) v_u_3, (ref) v_u_26, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) p_u_41, (ref) v_u_30
		local v64 = v_u_3.CurrentCamera
		local v65
		if v64 then
			local v66 = v64.CFrame.Position - p59
			v65 = v66.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v66.Unit
		else
			v65 = Vector3.new(0, 0, 1)
		end
		local v67 = v65.Y
		local v68 = math.abs(v67) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		local v_u_69 = CFrame.lookAt(p59, p59 + v65, v68)
		local v70 = math.random() * 3.141592653589793 * 2
		for v71 = 0, p60 - 1 do
			local v_u_72 = v70 + v71 / p60 * 3.141592653589793 * 2
			local v_u_73 = v_u_26(v_u_69 * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v_u_72, 0), p_u_61, v_u_6.RedTomoe, v_u_7, 0)
			v_u_1:AddItem(v_u_73, p63 + 0.1)
			p_u_41.animate(p63, 0, function(p74)
				-- upvalues: (copy) p_u_62, (copy) v_u_72, (copy) v_u_73, (copy) v_u_69, (copy) p_u_61, (ref) v_u_30
				local v75 = p_u_62 * (1 - (1 - p74) ^ 2)
				local v76 = v_u_72 + p74 * 7
				local v77 = v_u_72
				local v78 = v_u_72
				v_u_73.CFrame = v_u_69 * CFrame.new(math.cos(v77) * v75, math.sin(v78) * v75, 0.1) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v76, 0)
				local v79 = v_u_73
				local v80 = p_u_61 * (1 - 0.3 * p74)
				local v81 = v80 * 2
				local v82 = v80 * 2
				v79.Size = Vector3.new(v81, 0.05, v82)
				v_u_30(v_u_73, p74 <= 0.55 and 0 or (p74 - 0.55) / 0.45)
				if p74 >= 1 then
					v_u_73:Destroy()
				end
			end)
		end
	end
	local function v117(p84, p85) -- name: dwarfShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_11, (ref) v_u_14, (ref) v_u_9, (ref) v_u_26, (ref) v_u_6, (copy) p_u_41, (ref) v_u_1, (ref) v_u_3
		local v_u_86 = p84.size
		local v_u_87 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p85, v_u_7, {
			["transparency"] = 1
		})
		local v88 = {
			["shape"] = v_u_14
		}
		local v_u_89 = v_u_4.part(Vector3.new(0.8, 0.8, 0.8) * v_u_86, p85, v_u_11, v88)
		local v90 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_14
		}
		local v_u_91 = v_u_4.part(Vector3.new(1.5, 1.5, 1.5) * v_u_86, p85, v_u_7, v90)
		local v_u_92 = { v_u_89, v_u_91 }
		local v_u_93
		if p84.lite then
			v_u_93 = nil
		else
			local v94 = {
				["shape"] = nil,
				["transparency"] = 0.8,
				["shape"] = v_u_14
			}
			v_u_93 = v_u_4.part(Vector3.new(2.3, 2.3, 2.3) * v_u_86, p85, v_u_9, v94)
			table.insert(v_u_92, v_u_93)
		end
		local v_u_95 = {}
		for _ = 1, 3 do
			local v96 = v_u_26(p85, 0.42 * v_u_86, v_u_6.RedTomoe, v_u_7, 0)
			table.insert(v_u_95, v96)
			table.insert(v_u_92, v96)
		end
		p_u_41.streak(v_u_87, v_u_9, v_u_7, 1.3 * v_u_86, 0.15)
		if p84.mine then
			p_u_41.light(v_u_87, v_u_7, 9 * v_u_86)
		end
		for _, v97 in v_u_92 do
			v_u_1:AddItem(v97, 3)
		end
		v_u_1:AddItem(v_u_87, 3)
		local v_u_98 = false
		return {
			["place"] = function(p99, p100) -- name: place
				-- upvalues: (copy) v_u_87, (copy) v_u_89, (copy) v_u_91, (copy) v_u_86, (ref) v_u_93, (ref) v_u_3, (copy) v_u_95
				local v101 = p99.Position
				v_u_87.CFrame = p99
				v_u_89.CFrame = p99
				local v102 = v_u_91
				local v103 = Vector3.new(1.5, 1.5, 1.5) * v_u_86
				local v104 = p100 * 47
				v102.Size = v103 * (math.sin(v104) * 0.09 + 1)
				v_u_91.CFrame = p99
				if v_u_93 then
					v_u_93.CFrame = p99
				end
				local v105 = v_u_3.CurrentCamera
				local v106
				if v105 then
					local v107 = v105.CFrame.Position - v101
					v106 = v107.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v107.Unit
				else
					v106 = Vector3.new(0, 0, 1)
				end
				local v108 = v106.Y
				local v109 = math.abs(v108) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v110 = CFrame.lookAt(v101, v101 + v106, v109)
				for v111, v112 in v_u_95 do
					local v113 = p100 * 13 + v111 * 3.141592653589793 * 2 / 3
					local v114 = 1.25 * v_u_86
					v112.CFrame = v110 * CFrame.new(math.cos(v113) * v114, math.sin(v113) * v114, 0.3) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v113, 0)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_98, (copy) v_u_87, (ref) v_u_1, (copy) v_u_92
				if not v_u_98 then
					v_u_98 = true
					local v115 = v_u_87:FindFirstChildWhichIsA("PointLight")
					if v115 then
						v115:Destroy()
					end
					v_u_1:AddItem(v_u_87, 0.2)
					for _, v116 in v_u_92 do
						v116:Destroy()
					end
				end
			end
		}
	end
	local function v121(p118, p119) -- name: dwarfImpact
		-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4, (ref) v_u_6, (ref) v_u_9, (copy) v_u_83
		local v120 = p118.size
		p_u_41.pop(p119, v_u_7, 1.2 * v120, 4.8 * v120, 0.2, 0.3)
		p_u_41.pop(p119, v_u_11, 0.9 * v120, 2.2 * v120, 0.12)
		v_u_4.ring(p_u_41.ground(p119), v_u_7, p118.ability.radius * v120, 0.28, v_u_6.Ring)
		p_u_41.burst("Impact", p119, v_u_9, 0.9 * v120)
		if not p118.lite then
			v_u_83(p119, 3, 0.5 * v120, 3.4 * v120, 0.3)
			p_u_41.spikes(p119, v_u_9, 4, 3.6 * v120, 0.15)
		end
		p_u_41.hitSound(p119)
	end
	local function v148(p122, p123) -- name: tomoeShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_14, (ref) v_u_26, (ref) v_u_6, (copy) p_u_41, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (ref) v_u_3
		local v_u_124 = p122.size
		local v125 = {
			["shape"] = nil,
			["transparency"] = 0.5,
			["shape"] = v_u_14
		}
		local v_u_126 = v_u_4.part(Vector3.new(1.7, 1.7, 1.7) * v_u_124, p123, v_u_7, v125)
		local v_u_127 = v_u_26(p123, 1.15 * v_u_124, v_u_6.RedTomoe, v_u_7, 0)
		local v128 = { v_u_126, v_u_127 }
		p_u_41.streak(v_u_126, v_u_9, v_u_8, 1.2 * v_u_124, 0.18)
		if p122.mine then
			p_u_41.light(v_u_126, v_u_7, 9 * v_u_124)
		end
		for _, v129 in v128 do
			v_u_1:AddItem(v129, 3)
		end
		local v_u_130 = false
		return {
			["place"] = function(p131, p132) -- name: place
				-- upvalues: (copy) v_u_124, (copy) v_u_126, (copy) v_u_127, (ref) v_u_3
				local v133 = p132 * 15
				local v134 = p131.Position + (p131.RightVector * math.cos(v133) + p131.UpVector * math.sin(v133)) * 0.8 * v_u_124
				v_u_126.CFrame = CFrame.new(v134)
				local v135 = v_u_127
				local v136 = v_u_3.CurrentCamera
				local v137
				if v136 then
					local v138 = v136.CFrame.Position - v134
					v137 = v138.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v138.Unit
				else
					v137 = Vector3.new(0, 0, 1)
				end
				local v139 = v134 + v137 * 0.5 * v_u_124
				local v140 = v_u_3.CurrentCamera
				local v141
				if v140 then
					local v142 = v140.CFrame.Position - v139
					v141 = v142.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v142.Unit
				else
					v141 = Vector3.new(0, 0, 1)
				end
				local v143 = v141.Y
				local v144 = math.abs(v143) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				local v145 = CFrame.lookAt(v139, v139 + v141, v144)
				local v146 = -p132 * 18
				v135.CFrame = v145 * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v146, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_130, (copy) v_u_126, (ref) v_u_1, (copy) v_u_127
				if not v_u_130 then
					v_u_130 = true
					local v147 = v_u_126:FindFirstChildWhichIsA("PointLight")
					if v147 then
						v147:Destroy()
					end
					v_u_126.Transparency = 1
					v_u_1:AddItem(v_u_126, 0.2)
					v_u_127:Destroy()
				end
			end
		}
	end
	local function v152(p149, p150) -- name: bloomImpact
		-- upvalues: (copy) v_u_83, (copy) p_u_41, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4, (ref) v_u_6
		local v151 = p149.size
		v_u_83(p150, p149.lite and 3 or 5, 0.75 * v151, 3.8 * v151, 0.32)
		p_u_41.pop(p150, v_u_7, 1 * v151, 5 * v151, 0.22, 0.35)
		p_u_41.pop(p150, v_u_11, 0.8 * v151, 2 * v151, 0.12)
		v_u_4.ring(p_u_41.ground(p150), v_u_7, p149.ability.radius * v151 + 1, 0.3, v_u_6.Ring)
		p_u_41.burst("Impact", p150, v_u_7, 1 * v151)
		p_u_41.hitSound(p150)
	end
	local v_u_153 = {}
	setmetatable(v_u_153, {
		["__mode"] = "k"
	})
	local function v_u_177(p154, p_u_155, p156, p_u_157) -- name: nova
		-- upvalues: (ref) v_u_4, (ref) v_u_13, (copy) p_u_41, (ref) v_u_7, (ref) v_u_12, (ref) v_u_26, (ref) v_u_6, (ref) v_u_1, (ref) v_u_30, (copy) v_u_58, (ref) v_u_3, (ref) v_u_9, (ref) v_u_11, (copy) v_u_83, (ref) v_u_10, (ref) v_u_5
		local v158 = p154.lite
		v_u_4.flash(p_u_155, v_u_13, p_u_157 * 1.2, 0.25)
		p_u_41.burst("Flash", p_u_155, v_u_7, 1, true)
		for v_u_159, v160 in {
			{
				["color"] = nil,
				["reach"] = 2.3,
				["time"] = 0.75,
				["color"] = v_u_7
			},
			{
				["color"] = nil,
				["reach"] = 1.7,
				["time"] = 0.6,
				["color"] = v_u_12
			}
		} do
			local v161 = v160.color
			local v_u_162 = v160.reach
			local v163 = v160.time
			local v_u_164 = v_u_26(CFrame.new(p_u_155), 2, v_u_6.Ring, v161, 0)
			v_u_1:AddItem(v_u_164, v163 + 0.1)
			p_u_41.animate(v163, 0, function(p165)
				-- upvalues: (copy) v_u_164, (copy) p_u_157, (copy) v_u_162, (copy) p_u_155, (copy) v_u_159, (ref) v_u_30
				local v166 = v_u_164
				local v167 = 2 + p_u_157 * v_u_162 * (1 - (1 - p165) ^ 3)
				local v168 = v167 * 2
				local v169 = v167 * 2
				v166.Size = Vector3.new(v168, 0.05, v169)
				v_u_164.CFrame = CFrame.new(p_u_155) * CFrame.Angles(v_u_159 * 0.12, 0, 0.08)
				v_u_30(v_u_164, p165 <= 0.45 and 0 or (p165 - 0.45) / 0.55)
				if p165 >= 1 then
					v_u_164:Destroy()
				end
			end)
		end
		local v170 = v_u_58
		local v171 = v_u_3.CurrentCamera
		local v172
		if v171 then
			local v173 = v171.CFrame.Position - p_u_155
			v172 = v173.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v173.Unit
		else
			v172 = Vector3.new(0, 0, 1)
		end
		local v174 = v172.Y
		local v175 = math.abs(v174) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
		v170(CFrame.lookAt(p_u_155, p_u_155 + v172, v175) * CFrame.Angles(1.5707963267948966, 0, 0), 2, p_u_157 * 1.4, v_u_6.Shockwave, v_u_9, 0.5, 0)
		p_u_41.pop(p_u_155, v_u_12, 3, p_u_157 * 1.5, 0.6, 0.65)
		v_u_4.ring(p156, v_u_7, p_u_157 * 1.4, 0.6, v_u_6.Shockwave)
		v_u_4.ring(p156, v_u_9, p_u_157 * 1.1, 0.5, v_u_6.Ring)
		p_u_41.burst("Shockwave", p156 + Vector3.new(0, 0.3, 0), v_u_7, p_u_157 / 13)
		p_u_41.burst("Explosion", p_u_155, v_u_7, 2.5)
		p_u_41.spikes(p_u_155, v_u_11, v158 and 6 or 14, p_u_157, 0.32)
		v_u_83(p_u_155, v158 and 3 or 5, 2, p_u_157 * 0.9, 0.6)
		if not v158 then
			local v176 = { v_u_7, v_u_9, v_u_10 }
			p_u_41.chunks(p_u_155, v176, 12, 46, 0.8, 1.3, true, 0.5)
		end
		v_u_5.play("Explosion", {
			["at"] = p_u_155,
			["volume"] = p154.mine and 1 or 0.6
		})
		if p154.mine then
			v_u_4.shake(0.6, 0.5)
		end
	end
	local function v_u_284(p_u_178, p_u_179, p_u_180) -- name: giant
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_14, (ref) v_u_7, (ref) v_u_26, (ref) v_u_6, (ref) v_u_1, (ref) v_u_10, (ref) v_u_40, (copy) v_u_153, (copy) p_u_41, (copy) v_u_177, (ref) v_u_3, (ref) v_u_11, (ref) v_u_13, (ref) v_u_30
		local v_u_181 = p_u_178.lite
		local v_u_182 = p_u_179 + Vector3.new(0, 15, 0)
		local v183 = {
			["shape"] = v_u_14
		}
		local v_u_184 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_182), v_u_9, v183)
		local v185 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_14
		}
		local v_u_186 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_182), v_u_7, v185)
		local v187 = {
			["shape"] = nil,
			["transparency"] = 0.8,
			["shape"] = v_u_14
		}
		local v_u_188 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_182), v_u_7, v187)
		local v_u_189 = v_u_26(CFrame.new(v_u_182), 1, v_u_6.Glow, v_u_9, 0.25)
		local v_u_190 = {
			v_u_184,
			v_u_186,
			v_u_188,
			v_u_189
		}
		for _, v191 in v_u_190 do
			v_u_1:AddItem(v191, 2.3)
		end
		local v_u_192 = {}
		for _ = 1, v_u_181 and 4 or 10 do
			local v193 = {
				["shape"] = v_u_14
			}
			local v194 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v_u_182), v_u_10, v193)
			v_u_1:AddItem(v194, 2.3)
			local v195 = {
				["p"] = v194,
				["dir"] = v_u_40(v_u_182),
				["phase"] = math.random(),
				["cycle"] = 0.3 + math.random() * 0.15
			}
			table.insert(v_u_192, v195)
		end
		local v_u_196 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_182), v_u_7, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_196, 2.3)
		local v_u_197 = {}
		for v198 = 1, v_u_181 and 1 or 3 do
			local v199 = Instance.new("Attachment")
			v199.Parent = v_u_196
			local v200 = Instance.new("Attachment")
			v200.Parent = v_u_196
			local v201 = Instance.new("Beam")
			v201.Attachment0 = v199
			v201.Attachment1 = v200
			v201.Texture = v_u_6.Beam
			v201.TextureMode = Enum.TextureMode.Wrap
			v201.TextureLength = 5
			v201.TextureSpeed = 2
			v201.Color = ColorSequence.new(v_u_10, v_u_9)
			v201.LightEmission = 0.8
			v201.LightInfluence = 0
			v201.FaceCamera = true
			v201.Segments = 12
			v201.Width0 = 1.4
			v201.Width1 = 1.4
			v201.Parent = v_u_196
			local v202 = {
				["a0"] = v199,
				["a1"] = v200,
				["beam"] = v201,
				["center"] = v_u_40(v_u_182),
				["spread"] = 0.35 + math.random() * 0.2,
				["seed"] = v198 * 1.7
			}
			table.insert(v_u_197, v202)
		end
		local v_u_203 = {}
		for _ = 1, v_u_181 and 3 or 5 do
			local v204 = v_u_26(CFrame.new(v_u_182), 2, v_u_6.RedTomoe, v_u_7, 0)
			v_u_1:AddItem(v204, 2.3)
			table.insert(v_u_203, v204)
		end
		local v205 = v_u_153[p_u_178]
		v_u_153[p_u_178] = nil
		if v205 then
			v205:Destroy()
		end
		local v_u_206 = os.clock()
		local v_u_207 = v_u_206
		local v_u_208 = false
		local v_u_209 = false
		local v_u_210 = false
		p_u_41.runNow(function()
			-- upvalues: (copy) v_u_206, (ref) v_u_207, (ref) v_u_208, (copy) v_u_190, (copy) v_u_192, (copy) v_u_203, (copy) v_u_196, (ref) v_u_177, (copy) p_u_178, (copy) v_u_182, (copy) p_u_179, (copy) p_u_180, (ref) v_u_209, (ref) p_u_41, (ref) v_u_9, (copy) v_u_181, (ref) v_u_26, (ref) v_u_3, (ref) v_u_6, (ref) v_u_11, (ref) v_u_1, (ref) v_u_210, (ref) v_u_13, (copy) v_u_184, (ref) v_u_10, (copy) v_u_186, (ref) v_u_7, (copy) v_u_188, (copy) v_u_189, (ref) v_u_30, (ref) v_u_40, (copy) v_u_197
			local v211 = os.clock()
			local v212 = v211 - v_u_206
			local v213 = v211 - v_u_207
			local v214 = math.min(v213, 0.05)
			v_u_207 = v211
			if v212 >= 1.3 then
				if not v_u_208 then
					v_u_208 = true
					for _, v215 in v_u_190 do
						v215:Destroy()
					end
					for _, v216 in v_u_192 do
						v216.p:Destroy()
					end
					for _, v217 in v_u_203 do
						v217:Destroy()
					end
					v_u_196:Destroy()
					v_u_177(p_u_178, v_u_182, p_u_179, p_u_180)
				end
				return false
			end
			local v218
			if v212 < 0.2 then
				local v219 = v212 / 0.2 - 1
				v218 = (v219 * 2.7 * v219 * v219 + 1 + v219 * 1.7 * v219) * 16 + 4
			elseif v212 < 1.05 then
				v218 = 20 + 5 * (v212 - 0.2) / 0.8500000000000001
			elseif v212 < 1.2 then
				local v220 = (v212 - 1.05) / 0.15
				local v221 = 25 * (1 - v220 * v220 * v220)
				v218 = math.max(v221, 1.2)
				if not v_u_209 then
					v_u_209 = true
					p_u_41.inward(v_u_182, v_u_9, v_u_181 and 4 or 10, 22, 0.15)
					local v222 = v_u_26
					local v223 = v_u_182
					local v224 = v_u_3.CurrentCamera
					local v225
					if v224 then
						local v226 = v224.CFrame.Position - v223
						v225 = v226.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v226.Unit
					else
						v225 = Vector3.new(0, 0, 1)
					end
					local v227 = v225.Y
					local v228 = math.abs(v227) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
					local v_u_229 = v222(CFrame.lookAt(v223, v223 + v225, v228) * CFrame.Angles(1.5707963267948966, 0, 0), 15, v_u_6.Ring, v_u_11, 0)
					v_u_1:AddItem(v_u_229, 0.25)
					p_u_41.animate(0.15, 0, function(p230)
						-- upvalues: (copy) v_u_229
						local v231 = v_u_229
						local v232 = 15 * (1 - p230 * p230)
						local v233 = math.max(v232, 0.3)
						local v234 = v233 * 2
						local v235 = v233 * 2
						v231.Size = Vector3.new(v234, 0.05, v235)
						if p230 >= 1 then
							v_u_229:Destroy()
						end
					end)
				end
			else
				local v236 = v212 * 90
				v218 = math.sin(v236) * 0.4 + 1.2
				if not v_u_210 then
					v_u_210 = true
					p_u_41.glint(v_u_182, v_u_13, 9, 0.15000000000000002)
					p_u_41.pop(v_u_182, v_u_13, 3, 0.5, 0.1)
				end
			end
			local v237 = (v212 - 1.05) / 0.15
			local v238 = math.clamp(v237, 0, 1)
			local v239 = v212 * 21
			local v240 = math.sin(v239) * 0.5 + 0.5
			v_u_184.Size = Vector3.new(1, 1, 1) * v218 * 0.82
			v_u_184.Color = v_u_9:Lerp(v_u_10, v240 * 0.35):Lerp(v_u_13, v238)
			v_u_186.Size = Vector3.new(1, 1, 1) * v218
			v_u_186.Color = v_u_7:Lerp(v_u_11, v238)
			v_u_188.Size = Vector3.new(1, 1, 1) * v218 * 1.3
			v_u_188.Transparency = v238 * 0.2 + 0.8
			local v241 = v_u_182
			local v242 = v_u_3.CurrentCamera
			local v243
			if v242 then
				local v244 = v242.CFrame.Position - v241
				v243 = v244.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v244.Unit
			else
				v243 = Vector3.new(0, 0, 1)
			end
			v_u_189.CFrame = p_u_41.facing(v_u_182 - v243 * v218 * 0.2, v243) * CFrame.Angles(0, v212 * 0.6, 0)
			local v245 = v_u_189
			local v246 = v218 * 0.95
			local v247 = v246 * 2
			local v248 = v246 * 2
			v245.Size = Vector3.new(v247, 0.05, v248)
			v_u_30(v_u_189, v238 * 0.75 + 0.25)
			local v249 = v212 < 1.05 and 1 or 0
			for _, v250 in v_u_192 do
				local v251 = (v212 + v250.phase) % v250.cycle / v250.cycle
				if v251 < v214 / v250.cycle then
					v250.dir = v_u_40(v_u_182)
				end
				local v252 = v218 * 0.2
				local v253 = 3.141592653589793 * v251
				local v254 = v252 * math.sin(v253) * v249
				v250.p.Size = Vector3.new(1, 1, 1) * math.max(v254, 0.05)
				v250.p.CFrame = CFrame.new(v_u_182 + v250.dir * v218 * 0.47)
				v250.p.Color = v_u_10:Lerp(v_u_11, v251)
				v250.p.Transparency = v249 <= 0 and 1 or v251 * 0.6
			end
			for _, v255 in v_u_197 do
				local v256 = v255.center
				local v257 = v256:Cross(Vector3.new(0, 1, 0))
				local v258 = v257.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v257.Unit
				local v259 = v212 * 3 + v255.seed
				local v260 = math.sin(v259) * 0.15
				local v261 = (v256 + v258 * (v255.spread + v260)).Unit
				local v262 = (v256 - v258 * (v255.spread - v260)).Unit
				local v263 = v218 / 2
				v255.a0.WorldCFrame = CFrame.fromMatrix(v_u_182 + v261 * v263, v261, v261:Cross(v258).Unit)
				v255.a1.WorldCFrame = CFrame.fromMatrix(v_u_182 + v262 * v263, v262, v262:Cross(v258).Unit)
				local v264 = v212 * 5 + v255.seed
				local v265 = v263 * (math.sin(v264) * 0.1 + 0.45)
				v255.beam.CurveSize0 = v265
				v255.beam.CurveSize1 = -v265
				v255.beam.Transparency = NumberSequence.new(v212 < 1.05 and 0.1 or 1)
				local v266 = v255.beam
				local v267 = v218 * 0.06
				v266.Width0 = math.max(v267, 0.2)
				v255.beam.Width1 = v255.beam.Width0
			end
			local v268 = v_u_182
			local v269 = v_u_3.CurrentCamera
			local v270
			if v269 then
				local v271 = v269.CFrame.Position - v268
				v270 = v271.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v271.Unit
			else
				v270 = Vector3.new(0, 0, 1)
			end
			local v272 = v270.Y
			local v273 = math.abs(v272) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			local v274 = CFrame.lookAt(v268, v268 + v270, v273)
			for v275, v276 in v_u_203 do
				local v277 = v212 * 2.4 + v275 / #v_u_203 * 3.141592653589793 * 2
				local v278 = (v212 - 0.25) / 0.8
				local v279 = math.clamp(v278, 0, 1)
				local v280 = v218 / 2 + (1 - v279) * 7 + 1
				local v281 = math.sin(v277) * 0.35
				local v282 = v274 * CFrame.new(math.cos(v277) * v280, math.sin(v277) * v280 * 0.55, -v218 * 0.35 - v281 * v280 * 0.5)
				local v283 = v277 + v212 * 4
				v276.CFrame = v282 * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v283, 0)
				v_u_30(v276, v279 <= 0.85 and 0 or (v279 - 0.85) / 0.15)
			end
			return true
		end)
	end
	local v328 = {
		["red_giant_a"] = {
			["cast"] = function(p285) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_41, (ref) v_u_11
				local v286 = p285.size
				local v287 = p285.eye + p285.dir * 1.2
				v_u_4.flash(v287, v_u_7, 3.2 * v286, 0.1)
				p_u_41.pop(v287, v_u_11, 1.2 * v286, 0.3 * v286, 0.1)
			end,
			["shot"] = v117,
			["impact"] = v121,
			["hit"] = function(_, p288, _) -- name: hit
				-- upvalues: (copy) p_u_41, (ref) v_u_7
				p_u_41.burst("Impact", p288, v_u_7, 0.6)
			end
		},
		["red_giant_e"] = {
			["weave"] = 0.4,
			["cast"] = nil,
			["shot"] = nil,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p289) -- name: cast
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (copy) v_u_58, (ref) v_u_6, (ref) v_u_26, (ref) v_u_1, (ref) v_u_30
				p_u_41.skillCast(p289, v_u_7)
				local v_u_290 = p289.size
				local v291 = p289.eye + p289.dir * 2.4
				local v_u_292 = p_u_41.facing(v291, p289.dir)
				v_u_4.flash(v291, v_u_7, 5 * v_u_290, 0.18)
				p_u_41.pop(v291, v_u_11, 1.4 * v_u_290, 0.4 * v_u_290, 0.16)
				v_u_58(v_u_292, 1 * v_u_290, 4.5 * v_u_290, v_u_6.Glow, v_u_7, 0.35, 0, 0.2)
				local v293 = p289.lite and 5 or 9
				for v294 = 0, v293 - 1 do
					local v_u_295 = v294 / v293 * 3.141592653589793 * 2
					local v_u_296 = v_u_26(v_u_292, 0.2, v_u_6.RedTomoe, v_u_7, 0)
					v_u_1:AddItem(v_u_296, 0.5)
					p_u_41.animate(0.36, 0, function(p297)
						-- upvalues: (copy) v_u_295, (copy) v_u_290, (copy) v_u_296, (copy) v_u_292, (ref) v_u_30
						local v298 = 1 - (1 - p297) ^ 3
						local v299 = v_u_295 + 2.4 * v298
						local v300 = (0.3 + 4.2 * v298) * v_u_290
						v_u_296.CFrame = v_u_292 * CFrame.new(math.cos(v299) * v300, 0, math.sin(v299) * v300) * CFrame.Angles(0, -v299 - 1.5707963267948966, 0)
						local v301 = v_u_296
						local v302 = (0.3 + 0.85 * v298) * v_u_290
						local v303 = v302 * 2
						local v304 = v302 * 2
						v301.Size = Vector3.new(v303, 0.05, v304)
						v_u_30(v_u_296, p297 <= 0.65 and 0 or (p297 - 0.65) / 0.35)
						if p297 >= 1 then
							v_u_296:Destroy()
						end
					end)
				end
			end,
			["shot"] = v148,
			["impact"] = v152,
			["hit"] = function(p305, p306, _) -- name: hit
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_9
				p_u_41.burst("Impact", p306, v_u_7, 0.7)
				if not p305.lite then
					p_u_41.glint(p306, v_u_9, 3, 0.14)
				end
			end
		},
		["red_giant_r"] = {
			["cast"] = function(p307) -- name: cast
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (copy) v_u_58, (ref) v_u_13, (ref) v_u_6, (ref) v_u_4
				p_u_41.skillCast(p307, v_u_7, true)
				local v308 = p307.size
				local v309 = p307.eye + p307.dir * 1.6
				local v310 = p_u_41.facing(v309, p307.dir)
				v_u_58(v310, 1 * v308, 4 * v308, p_u_41.iris("red_giant"), v_u_13, 0.36, 6)
				v_u_58(v310 * CFrame.new(0, -0.05, 0), 1.6 * v308, 5.4 * v308, v_u_6.Glow, v_u_7, 0.3, 0, 0.3)
				if p307.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p311, p312, p313) -- name: windup
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11, (ref) v_u_14, (ref) v_u_1, (copy) v_u_153, (ref) v_u_6
				local v314 = p_u_41.ground(p312, 0)
				local v315 = v314 + Vector3.new(0, 15, 0)
				local v316 = math.max(p313, 0.1)
				p_u_41.inward(v315, v_u_7, p311.lite and 4 or 10, 18, v316)
				local v317 = {
					["shape"] = v_u_14
				}
				local v_u_318 = v_u_4.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(v315), v_u_11, v317)
				v_u_1:AddItem(v_u_318, v316 + 1)
				v_u_153[p311] = v_u_318
				p_u_41.animate(v316, 0, function(p319)
					-- upvalues: (copy) v_u_318
					if v_u_318.Parent then
						v_u_318.Size = Vector3.new(1, 1, 1) * (0.5 + 3.5 * p319 * p319)
					end
				end)
				v_u_4.ring(v314, v_u_7, p311.ability.radius * 0.4, v316 + 0.1, v_u_6.Ring)
			end,
			["land"] = function(p320, p321) -- name: land
				-- upvalues: (copy) p_u_41, (copy) v_u_284, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_5
				local v322 = p320.size
				local v323 = p320.ability.radius * v322
				local v324 = p_u_41.ground(p321, 0)
				local v325 = v324 + Vector3.new(0, 15, 0)
				v_u_284(p320, v324, v323)
				v_u_4.flash(v325, v_u_11, 16, 0.22)
				p_u_41.dome(p321, v323, v_u_7, 0.45)
				v_u_4.ring(v324, v_u_9, v323, 0.4, v_u_6.Shockwave)
				p_u_41.burst("Shockwave", v324 + Vector3.new(0, 0.3, 0), v_u_7, v323 / 16)
				if not p320.lite then
					p_u_41.mark(v324, v_u_7, v323 * 0.9, 1.65, v_u_6.Glow, 0.4)
				end
				v_u_5.play("Fireball", {
					["at"] = v325,
					["volume"] = p320.mine and 1 or 0.6
				})
				if p320.mine then
					v_u_4.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(p326, p327, _) -- name: hit
				-- upvalues: (copy) p_u_41, (ref) v_u_7, (ref) v_u_9
				p_u_41.burst("Impact", p327, v_u_7, 1.1)
				if not p326.lite then
					p_u_41.glint(p327, v_u_9, 3.5, 0.15)
				end
			end
		}
	}
	return v328
end