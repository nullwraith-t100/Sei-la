local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("BFE6FF")
local v_u_9 = Color3.fromHex("0A0F1A")
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(226, 245, 255)
local v_u_12 = Color3.fromRGB(95, 175, 255)
local v_u_13 = Color3.fromRGB(40, 95, 210)
local v_u_14 = Color3.fromRGB(70, 255, 200)
local v_u_15 = Color3.fromRGB(110, 190, 255)
local v_u_16 = Color3.fromRGB(165, 120, 255)
local v_u_17 = Enum.PartType.Ball
local v_u_18 = Enum.PartType.Cylinder
local v_u_19 = Enum.PartType.Wedge
local v_u_20 = Enum.Material.SmoothPlastic
local v_u_21 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_22 = CFrame.Angles(-1.5707963267948966, 0, 0)
local v_u_23 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_35(p24, p25, p26, p27, p28) -- name: disc
	-- upvalues: (copy) v_u_5
	local v29 = v_u_5.part
	local v30 = p25 * 2
	local v31 = p25 * 2
	local v32 = v29(Vector3.new(v30, 0.05, v31), p24, p27, {
		["transparency"] = 1
	})
	for _, v33 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v34 = Instance.new("Decal")
		v34.Face = v33
		v34.Texture = p26
		v34.Color3 = p27
		v34.Transparency = p28
		v34.Parent = v32
	end
	return v32
end
local function v_u_39(p36, p37) -- name: fadeDecals
	for _, v38 in p36:GetChildren() do
		if not v38:IsA("Decal") then
			continue
		end
		v38.Transparency = p37
	end
end
local function v_u_46(p40, p41, p42, p43) -- name: blob
	-- upvalues: (copy) v_u_5
	local v44 = v_u_5.part(p40, p41, p42, {
		["material"] = p43
	})
	local v45 = Instance.new("SpecialMesh")
	v45.MeshType = Enum.MeshType.Sphere
	v45.Parent = v44
	return v44
end
local v_u_47 = {}
local v_u_48 = {}
local function v_u_56(p49, p50) -- name: placeBits
	-- upvalues: (copy) v_u_47, (copy) v_u_48, (copy) v_u_4
	table.clear(v_u_47)
	table.clear(v_u_48)
	for _, v51 in p49 do
		if not v51.p.Parent then
			continue
		end
		local v52 = v_u_47
		local v53 = v51.p
		table.insert(v52, v53)
		local v54 = v_u_48
		local v55 = p50 * v51.off
		table.insert(v54, v55)
	end
	if #v_u_47 > 0 then
		v_u_4:BulkMoveTo(v_u_47, v_u_48, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_62(p57, p58) -- name: fadeBits
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v59 in p57 do
		local v60 = v59.p
		if not v60.Parent then
			continue
		end
		if v60.Transparency < 1 then
			v_u_5.tween(v60, p58, {
				["Transparency"] = 1
			})
		end
		for _, v61 in v60:GetChildren() do
			if not v61:IsA("Decal") then
				continue
			end
			v_u_5.tween(v61, p58, {
				["Transparency"] = 1
			})
		end
		v_u_1:AddItem(v60, p58 + 0.05)
	end
end
local function v_u_79(p63, p64, p65, p66, p67, p68, p69, p70, p71) -- name: triangle
	-- upvalues: (copy) v_u_5, (copy) v_u_19, (copy) v_u_20, (copy) v_u_1
	for _, v72 in { -1, 1 } do
		local v73 = v_u_5.part
		local v74 = p66 / 2
		local v75 = Vector3.new(p68, p67, v74)
		local v76 = {
			["shape"] = v_u_19,
			["material"] = v_u_20,
			["transparency"] = p71
		}
		local v77 = v73(v75, CFrame.identity, p69, v76)
		local v78 = p64 * CFrame.new(v72 * p66 / 4, p65 + p67 / 2, 0) * CFrame.Angles(0, -v72 * 3.141592653589793 / 2, 0)
		v_u_1:AddItem(v77, p70)
		table.insert(p63, {
			["p"] = v77,
			["off"] = v78
		})
	end
end
local function v_u_90(p80, p81, p82, p83) -- name: layRod
	local v84 = (p82 - p81).Magnitude
	local v85 = math.max(v84, 0.05)
	local v86 = ((p82 - p81).Magnitude <= 0.001 and Vector3.new(0, 1, 0) or (p82 - p81).Unit).Y
	local v87 = math.abs(v86) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v88 = math.max(p83, 0.02)
	local v89 = math.max(p83, 0.02)
	p80.Size = Vector3.new(v85, v88, v89)
	p80.CFrame = CFrame.lookAt((p81 + p82) / 2, p82, v87) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_102(p91, p92, p93, p94, p95) -- name: layStrip
	local v96 = (p93 - p92).Magnitude
	local v97 = math.max(v96, 0.05)
	local v98 = p93.X - p92.X
	local v99 = p93.Z - p92.Z
	local v100 = Vector3.new(v98, 0, v99)
	local v101 = v100.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v100.Unit
	p91.Size = Vector3.new(p94, p95, v97)
	p91.CFrame = CFrame.lookAt((p92 + p93) / 2, (p92 + p93) / 2 + v101)
end
local v_u_103 = 0
local function v_u_107(p104) -- name: polarNight
	-- upvalues: (ref) v_u_103, (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	if os.clock() >= v_u_103 then
		local v_u_105 = Instance.new("ColorCorrectionEffect")
		v_u_105.Name = "PolarNight"
		v_u_105.Parent = v_u_2
		v_u_5.tween(v_u_105, 0.15, {
			["TintColor"] = nil,
			["Brightness"] = -0.12,
			["Contrast"] = 0.14,
			["Saturation"] = -0.12,
			["TintColor"] = Color3.fromRGB(150, 182, 255)
		})
		task.delay(p104 + 0.15, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_105, (ref) v_u_10
			local v106 = {
				["TintColor"] = nil,
				["Brightness"] = 0,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = v_u_10
			}
			v_u_5.tween(v_u_105, 0.45, v106)
		end)
		v_u_1:AddItem(v_u_105, p104 + 0.7)
		v_u_103 = os.clock() + p104 + 0.7
	end
end
return function(p_u_108)
	-- upvalues: (copy) v_u_35, (copy) v_u_1, (copy) v_u_39, (copy) v_u_5, (copy) v_u_9, (copy) v_u_18, (copy) v_u_20, (copy) v_u_21, (copy) v_u_8, (copy) v_u_79, (copy) v_u_22, (copy) v_u_23, (copy) v_u_7, (copy) v_u_12, (copy) v_u_56, (copy) v_u_4, (copy) v_u_10, (copy) v_u_17, (copy) v_u_46, (copy) v_u_11, (copy) v_u_102, (copy) v_u_62, (copy) v_u_6, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15, (copy) v_u_16, (copy) v_u_107, (copy) v_u_90
	local v109 = {}
	local function v_u_124(p110, p_u_111, p_u_112, p113, p114, p115, p116) -- name: flare
		-- upvalues: (ref) v_u_35, (ref) v_u_1, (copy) p_u_108, (ref) v_u_39
		local v_u_117 = p116 or 0
		local v_u_118 = v_u_35(p110, p_u_111, p113, p114, v_u_117)
		v_u_1:AddItem(v_u_118, p115 + 0.1)
		p_u_108.animate(p115, 0, function(p119)
			-- upvalues: (copy) p_u_111, (copy) p_u_112, (copy) v_u_118, (ref) v_u_39, (copy) v_u_117
			local v120 = p_u_111 + (p_u_112 - p_u_111) * (1 - (1 - p119) ^ 3)
			local v121 = v_u_118
			local v122 = v120 * 2
			local v123 = v120 * 2
			v121.Size = Vector3.new(v122, 0.05, v123)
			v_u_39(v_u_118, v_u_117 + (1 - v_u_117) * p119 ^ 1.5)
			if p119 >= 1 then
				v_u_118:Destroy()
			end
		end)
	end
	v109.polar_dial_a = {
		["cast"] = function(p125) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_108, (ref) v_u_10, (copy) v_u_124, (ref) v_u_4, (ref) v_u_7
			local v126 = p125.size
			local v127 = p125.eye + p125.dir * 1.1
			v_u_5.flash(v127, v_u_8, 3 * v126, 0.12)
			p_u_108.pop(v127, v_u_10, 1.2 * v126, 0.3 * v126, 0.1)
			if not p125.lite then
				local v128 = v_u_124
				local v129 = p_u_108.facing
				local v130 = v_u_4.CurrentCamera
				local v131
				if v130 then
					local v132 = v130.CFrame.Position - v127
					v131 = v132.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v132.Unit
				else
					v131 = Vector3.new(0, 0, 1)
				end
				v128(v129(v127, v131), 0.5 * v126, 1.7 * v126, v_u_7.Ring, v_u_8, 0.14, 0.1)
			end
		end,
		["shot"] = function(p133, p134) -- name: handShot
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_18, (ref) v_u_20, (ref) v_u_21, (ref) v_u_1, (ref) v_u_8, (ref) v_u_79, (ref) v_u_22, (ref) v_u_35, (ref) v_u_23, (ref) v_u_7, (copy) p_u_108, (ref) v_u_12, (ref) v_u_56
			local v135 = p133.size
			local v_u_136 = {}
			local v137 = {
				["shape"] = v_u_18,
				["material"] = v_u_20
			}
			local v138 = v_u_5.part(Vector3.new(0.34, 0.95, 0.95) * v135, p134, v_u_9, v137)
			local v139 = v_u_21
			v_u_1:AddItem(v138, 3)
			table.insert(v_u_136, {
				["p"] = v138,
				["off"] = v139
			})
			v138.Reflectance = 0.25
			local v140 = {
				["shape"] = nil,
				["transparency"] = 0.15,
				["shape"] = v_u_18
			}
			local v141 = v_u_5.part(Vector3.new(0.16, 1.5, 1.5) * v135, p134, v_u_8, v140)
			local v142 = v_u_21
			v_u_1:AddItem(v141, 3)
			table.insert(v_u_136, {
				["p"] = v141,
				["off"] = v142
			})
			local v143 = 0.4 * v135 + 2.1 * v135
			local v144 = v_u_5.part
			local v145 = 0.3 * v135
			local v146 = 0.2 * v135
			local v147 = 2.1 * v135
			local v148 = v144(Vector3.new(v145, v146, v147), p134, v_u_9, {
				["material"] = v_u_20
			})
			local v149 = CFrame.new(0, 0, -(0.4 * v135 + 2.1 * v135 / 2))
			v_u_1:AddItem(v148, 3)
			table.insert(v_u_136, {
				["p"] = v148,
				["off"] = v149
			})
			v_u_79(v_u_136, v_u_22, v143, 1.05 * v135, 1.15 * v135, 0.24 * v135, v_u_9, 3)
			local v_u_150
			if p133.lite then
				v_u_150 = nil
			else
				local v151 = v_u_5.part
				local v152 = 0.62 * v135
				local v153 = 0.1 * v135
				local v154 = 2.1 * v135 + 0.5 * v135
				local v155 = v151(Vector3.new(v152, v153, v154), p134, v_u_8, {
					["transparency"] = 0.45
				})
				local v156 = CFrame.new(0, -0.06 * v135, -(0.4 * v135 + 2.1 * v135 / 2))
				v_u_1:AddItem(v155, 3)
				table.insert(v_u_136, {
					["p"] = v155,
					["off"] = v156
				})
				local v157 = {
					["material"] = v_u_20
				}
				local v158 = v_u_5.part(Vector3.new(0.3, 0.2, 0.75) * v135, p134, v_u_9, v157)
				local v159 = CFrame.new(0, 0, 0.75 * v135)
				v_u_1:AddItem(v158, 3)
				table.insert(v_u_136, {
					["p"] = v158,
					["off"] = v159
				})
				v_u_150 = v_u_35(p134 * v_u_23, v143 + 1 * v135, v_u_7.Ring, v_u_8, 0.15)
				v_u_1:AddItem(v_u_150, 3)
			end
			local v_u_160 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p134, v_u_8, {
				["transparency"] = 1
			})
			local v161 = CFrame.new(0, 0, -(v143 + 1.1 * v135))
			v_u_1:AddItem(v_u_160, 3)
			table.insert(v_u_136, {
				["p"] = v_u_160,
				["off"] = v161
			})
			p_u_108.streak(v_u_160, v_u_8, v_u_12, 0.4 * v135, p133.lite and 0.1 or 0.18)
			if p133.mine then
				p_u_108.light(v138, v_u_8, 9 * v135)
			end
			local v_u_162 = false
			return {
				["place"] = function(p163, p164) -- name: place
					-- upvalues: (ref) v_u_56, (copy) v_u_136, (ref) v_u_23, (ref) v_u_150
					v_u_56(v_u_136, p163 * CFrame.Angles(0, 0, -p164 * 26) * v_u_23)
					local v165 = v_u_150
					if v165 then
						v165.CFrame = p163 * v_u_23
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_162, (copy) v_u_136, (copy) v_u_160, (ref) v_u_1, (ref) v_u_150
					if not v_u_162 then
						v_u_162 = true
						for _, v166 in v_u_136 do
							if v166.p == v_u_160 then
								v_u_1:AddItem(v_u_160, 0.2)
							else
								v166.p:Destroy()
							end
						end
						local v167 = v_u_150
						if v167 then
							v167:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p168, p169) -- name: handImpact
			-- upvalues: (ref) v_u_4, (copy) v_u_124, (copy) p_u_108, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (ref) v_u_20, (ref) v_u_17, (ref) v_u_1, (ref) v_u_46
			local v_u_170 = p168.size
			local v171 = v_u_4.CurrentCamera
			local v172
			if v171 then
				local v173 = v171.CFrame.Position - p169
				v172 = v173.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v173.Unit
			else
				v172 = Vector3.new(0, 0, 1)
			end
			v_u_124(p_u_108.facing(p169, v172), 0.8 * v_u_170, 2.9 * v_u_170, v_u_7.Ring, v_u_8, 0.26, 0.05)
			p_u_108.burst("Impact", p169, v_u_8, 0.9 * v_u_170)
			p_u_108.pop(p169, v_u_10, 1.2 * v_u_170, 3.4 * v_u_170, 0.14)
			if not p168.lite then
				local v_u_174 = CFrame.lookAt(p169, p169 + v172)
				local v175 = {
					["material"] = v_u_20
				}
				local v_u_176 = v_u_5.part(Vector3.new(0.32, 2.4, 0.2) * v_u_170, v_u_174, v_u_9, v175)
				local v177 = {
					["shape"] = v_u_17,
					["material"] = v_u_20
				}
				local v_u_178 = v_u_5.part(Vector3.new(0.75, 0.75, 0.75) * v_u_170, v_u_174, v_u_9, v177)
				v_u_1:AddItem(v_u_176, 0.5)
				v_u_1:AddItem(v_u_178, 0.5)
				p_u_108.animate(0.42, 0, function(p179)
					-- upvalues: (copy) v_u_176, (copy) v_u_174, (copy) v_u_170, (copy) v_u_178
					local v180
					if p179 < 0.25 then
						local v181 = p179 / 0.25 - 1
						v180 = (1 - (v181 * 2.9 * v181 * v181 + 1 + v181 * 1.9 * v181)) * 1.5
					else
						local v182 = (p179 - 0.25) * 40
						v180 = math.sin(v182) * 0.08 * (1 - p179)
					end
					v_u_176.CFrame = v_u_174 * CFrame.Angles(0, 0, v180) * CFrame.new(0, 1.2 * v_u_170, -0.05)
					local v183 = (p179 - 0.55) / 0.45
					local v184 = math.clamp(v183, 0, 1)
					v_u_176.Transparency = v184
					v_u_178.Transparency = v184
					if p179 >= 1 then
						v_u_176:Destroy()
						v_u_178:Destroy()
					end
				end)
				for v185 = 0, 3 do
					local v186 = v_u_174 * CFrame.Angles(0, 0, -v185 * 3.141592653589793 / 2)
					local v187 = v_u_46(Vector3.new(0.4, 0.95, 0.25) * v_u_170, v186 * CFrame.new(0, 1.9 * v_u_170, 0), v_u_9, v_u_20)
					v_u_5.tween(v187, 0.26, {
						["CFrame"] = nil,
						["Transparency"] = 1,
						["CFrame"] = v186 * CFrame.new(0, 3.6 * v_u_170, 0)
					})
					v_u_1:AddItem(v187, 0.3)
				end
			end
			p_u_108.hitSound(p169)
		end,
		["hit"] = p_u_108.simpleHit(v_u_8, 0.5)
	}
	local v_u_188 = {}
	setmetatable(v_u_188, {
		["__mode"] = "k"
	})
	local v_u_189 = {}
	setmetatable(v_u_189, {
		["__mode"] = "k"
	})
	local function v_u_241(p190, p191, p192) -- name: buildDial
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_18, (ref) v_u_20, (ref) v_u_21, (ref) v_u_1, (ref) v_u_8, (ref) v_u_35, (ref) v_u_7, (ref) v_u_11, (ref) v_u_46, (ref) v_u_79, (ref) v_u_22
		local v193 = {}
		local v194 = v_u_5.part
		local v195 = p190 * 2 + 2
		local v196 = p190 * 2 + 2
		local v197 = Vector3.new(0.5, v195, v196)
		local v198 = {
			["shape"] = v_u_18,
			["material"] = v_u_20
		}
		local v199 = v194(v197, CFrame.identity, v_u_9, v198)
		local v200 = CFrame.new(0, 0.25, 0) * v_u_21
		v_u_1:AddItem(v199, p191)
		table.insert(v193, {
			["p"] = v199,
			["off"] = v200
		})
		local v201 = v_u_5.part
		local v202 = p190 * 2
		local v203 = p190 * 2
		local v204 = Vector3.new(0.7, v202, v203)
		local v205 = {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.25,
			["shape"] = v_u_18,
			["material"] = v_u_20
		}
		local v206 = v201(v204, CFrame.identity, v_u_8, v205)
		local v207 = CFrame.new(0, 0.4, 0) * v_u_21
		v_u_1:AddItem(v206, p191)
		table.insert(v193, {
			["p"] = v206,
			["off"] = v207
		})
		v206.Reflectance = 0.15
		local v208 = v_u_35(CFrame.identity, p190 * 0.97, v_u_7.Ring, v_u_11, 0.1)
		local v209 = CFrame.new(0, 0.78, 0)
		v_u_1:AddItem(v208, p191)
		table.insert(v193, {
			["p"] = v208,
			["off"] = v209
		})
		local v210 = v_u_35(CFrame.identity, p190 * 0.76, v_u_7.Ring, v_u_9, 0.3)
		local v211 = CFrame.new(0, 0.84, 0)
		v_u_1:AddItem(v210, p191)
		table.insert(v193, {
			["p"] = v210,
			["off"] = v211
		})
		local v212 = {}
		for v213 = 0, 11 do
			local v214 = v213 * 3.141592653589793 / 6
			local v215 = math.sin(v214)
			local v216 = -math.cos(v214)
			local v217 = Vector3.new(v215, 0, v216)
			if v213 % 3 == 0 then
				local v218 = v217 * p190 * 0.76 + Vector3.new(0, 0.9, 0)
				local v219 = v_u_46
				local v220 = p190 * 0.17
				local v221 = p190 * 0.36
				local v222 = v219(Vector3.new(v220, 0.5, v221), CFrame.identity, v_u_9, v_u_20)
				local v223 = CFrame.lookAt(v218, v218 + v217)
				v_u_1:AddItem(v222, p191)
				table.insert(v193, {
					["p"] = v222,
					["off"] = v223
				})
				table.insert(v212, v218)
			else
				if p192 then
					continue
				end
				local v224 = v217 * p190 * 0.72 + Vector3.new(0, 0.9, 0)
				local v225 = v_u_5.part
				local v226 = p190 * 0.17
				local v227 = p190 * 0.17
				local v228 = Vector3.new(0.4, v226, v227)
				local v229 = {
					["shape"] = v_u_18,
					["material"] = v_u_20
				}
				local v230 = v225(v228, CFrame.identity, v_u_9, v229)
				local v231 = CFrame.new(v224) * v_u_21
				v_u_1:AddItem(v230, p191)
				table.insert(v193, {
					["p"] = v230,
					["off"] = v231
				})
				table.insert(v212, v224)
			end
		end
		local v232 = {}
		local v233 = v_u_5.part
		local v234 = p190 * 0.34
		local v235 = p190 * 0.34
		local v236 = Vector3.new(1, v234, v235)
		local v237 = {
			["shape"] = v_u_18,
			["material"] = v_u_20
		}
		local v238 = v233(v236, CFrame.identity, v_u_9, v237)
		local v239 = CFrame.new(0, 1.3, 0) * v_u_21
		v_u_1:AddItem(v238, p191)
		table.insert(v232, {
			["p"] = v238,
			["off"] = v239
		})
		for _, v240 in { 0, 3.141592653589793 } do
			v_u_79(v232, CFrame.new(0, 1.25, 0) * CFrame.Angles(0, v240, 0) * v_u_22, p190 * 0.16, p190 * 0.26, p190 * 0.34, 0.7, v_u_9, p191)
		end
		return {
			["frame"] = nil,
			["bits"] = nil,
			["needle"] = nil,
			["slab"] = nil,
			["marks"] = nil,
			["born"] = nil,
			["fall"] = 0,
			["landAt"] = nil,
			["frame"] = CFrame.identity,
			["bits"] = v193,
			["needle"] = v232,
			["slab"] = v206,
			["marks"] = v212,
			["born"] = os.clock()
		}
	end
	local function v_u_261(p242, p243, p244) -- name: frozenDial
		-- upvalues: (copy) p_u_108, (copy) v_u_241, (ref) v_u_56
		local v245 = p242.ability.radius
		local v246 = p_u_108.flatUnit(p243 - p242.origin)
		local v_u_247 = v_u_241(v245, p244 + (p242.ability.freeze or 3) + 1.5, p242.lite)
		v_u_247.frame = CFrame.lookAt(p_u_108.ground(p243, 0), p_u_108.ground(p243, 0) + v246)
		v_u_247.fall = p244
		local v_u_248 = false
		p_u_108.runNow(function()
			-- upvalues: (copy) v_u_247, (ref) v_u_56, (ref) v_u_248
			local v249 = os.clock()
			local v250 = v_u_247.landAt
			if v250 then
				local v251 = v249 - v250
				local v252
				if v251 < 0.32 then
					v252 = 12.566370614359172 * (1 - (1 - v251 / 0.32) ^ 2)
				else
					local v253 = (v251 - 0.32) * 32
					local v254 = math.sin(v253) * 0.16
					local v255 = -(v251 - 0.32) * 7
					v252 = v254 * math.exp(v255)
				end
				v_u_56(v_u_247.needle, v_u_247.frame * CFrame.Angles(0, -v252, 0))
				if v251 <= 1.22 then
					return true
				end
				if not v_u_248 then
					v_u_248 = true
					v_u_56(v_u_247.needle, v_u_247.frame)
				end
				return false
			end
			local v256 = v249 - v_u_247.born
			local v257 = v_u_247.fall
			local v258 = v256 / math.max(v257, 0.001)
			local v259 = math.clamp(v258, 0, 1)
			local v260 = v_u_247.frame * CFrame.new(0, (1 - v259 * v259) * 26, 0) * CFrame.Angles((1 - v259) * 0.35, 0, 0)
			v_u_56(v_u_247.bits, v260)
			v_u_56(v_u_247.needle, v260 * CFrame.Angles(0, -v249 * 14, 0))
			return v249 - v_u_247.born < v_u_247.fall + 1.5
		end)
		return v_u_247
	end
	local function v_u_278(p262, p_u_263) -- name: frostOver
		-- upvalues: (copy) p_u_108, (ref) v_u_10, (ref) v_u_5, (ref) v_u_11, (ref) v_u_7, (ref) v_u_102, (ref) v_u_1
		local v_u_264 = p262.ability.radius
		local v265 = p_u_263.frame * Vector3.new(0, 1.4, 0)
		p_u_108.pop(v265, v_u_10, 3, 10, 0.22, 0.2)
		v_u_5.ring(p_u_108.ground(p_u_263.frame.Position, 0.6), v_u_11, v_u_264 * 0.6, 0.3, v_u_7.Ring)
		local v266 = {
			["Color"] = nil,
			["Transparency"] = 0.12,
			["Color"] = v_u_11
		}
		v_u_5.tween(p_u_263.slab, 0.4, v266)
		if not p262.lite then
			for v267, v_u_268 in p_u_263.marks do
				p_u_108.after((v267 - 1) * 0.03, function()
					-- upvalues: (copy) v_u_268, (copy) p_u_263, (copy) v_u_264, (ref) v_u_5, (ref) v_u_11, (ref) v_u_102, (ref) v_u_1, (ref) p_u_108, (ref) v_u_10
					local v269 = v_u_268.X
					local v270 = v_u_268.Z
					local v271 = Vector3.new(v269, 0, v270)
					local v272 = p_u_263.frame * (v271.Unit * v_u_264 * 0.2 + Vector3.new(0, 0.85, 0))
					local v273 = p_u_263.frame
					local v274 = v_u_268.X
					local v275 = v_u_268.Z
					local v276 = v273 * Vector3.new(v274, 0.85, v275)
					local v277 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.identity, v_u_11)
					v_u_102(v277, v272, v276, 0.5, 0.1)
					v_u_5.tween(v277, 0.9, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v277, 0.95)
					p_u_108.pop(v276 + Vector3.new(0, 0.6, 0), v_u_10, 1.4, 4.4, 0.28, 0.1)
				end)
			end
		end
	end
	local function v_u_284(p279, p280) -- name: shatter
		-- upvalues: (copy) p_u_108, (ref) v_u_8, (ref) v_u_5, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_62, (ref) v_u_6
		local v281 = p279.ability.radius
		local v282 = p280.frame.Position
		p_u_108.burst("Shockwave", p_u_108.ground(v282, 0.3), v_u_8, v281 / 22)
		v_u_5.ring(p_u_108.ground(v282), v_u_11, v281, 0.35, v_u_7.Ring)
		if not p279.lite then
			local v283 = { v_u_8, v_u_11, v_u_9 }
			p_u_108.chunks(p_u_108.ground(v282, 1), v283, 14, 36, 1.4, 1)
			p_u_108.mark(v282, v_u_11, v281 * 0.9, 0.6, v_u_7.CrackLines, 0.1)
		end
		v_u_62(p280.bits, 0.25)
		v_u_62(p280.needle, 0.25)
		v_u_6.play("Burst", {
			["at"] = nil,
			["volume"] = 0.45,
			["at"] = v282
		})
	end
	v109.polar_dial_e = {
		["cast"] = function(p285) -- name: cast
			-- upvalues: (copy) p_u_108, (ref) v_u_12, (ref) v_u_8
			p_u_108.skillCast(p285, v_u_12)
			if not p285.lite then
				p_u_108.glint(p285.eye, v_u_8, 4 * p285.size, 0.2)
			end
		end,
		["windup"] = function(p286, p287, p288) -- name: windup
			-- upvalues: (copy) p_u_108, (ref) v_u_13, (ref) v_u_7, (copy) v_u_188, (copy) v_u_261
			p_u_108.mark(p287, v_u_13, p286.ability.radius * 0.8, p288 + 0.25, v_u_7.Glow, 0.35)
			v_u_188[p286] = v_u_261(p286, p287, p288)
		end,
		["land"] = function(p_u_289, p290) -- name: land
			-- upvalues: (copy) v_u_188, (copy) v_u_261, (ref) v_u_56, (copy) p_u_108, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (copy) v_u_278, (copy) v_u_284
			local v291 = p_u_289.ability.radius
			local v_u_292 = v_u_188[p_u_289] or v_u_261(p_u_289, p290, 0)
			v_u_188[p_u_289] = nil
			v_u_292.landAt = os.clock()
			v_u_56(v_u_292.bits, v_u_292.frame)
			local v_u_293 = p_u_108.ground(p290)
			p_u_108.burst("Shockwave", v_u_293 + Vector3.new(0, 0.3, 0), v_u_8, v291 / 16)
			v_u_5.ring(v_u_293, v_u_10, v291 * 1.15, 0.35, v_u_7.SpeedLines)
			v_u_6.play("Crit", {
				["at"] = nil,
				["volume"] = 0.75,
				["at"] = v_u_293
			})
			if p_u_289.mine then
				v_u_5.shake(0.35, 0.3)
			end
			if not p_u_289.lite then
				for v294 = 0, 3 do
					local v295 = v294 * 3.141592653589793 / 2 + 0.7853981633974483
					local v296 = p_u_108.burst
					local v297 = math.cos(v295) * v291
					local v298 = math.sin(v295) * v291
					v296("Smoke", v_u_293 + Vector3.new(v297, 1, v298), nil, 1.2)
				end
				local v299 = { v_u_8, v_u_11, v_u_9 }
				p_u_108.chunks(v_u_293 + Vector3.new(0, 1, 0), v299, 10, 34, 1.1, 0.9, false, 0.6)
			end
			p_u_108.after(0.32, function()
				-- upvalues: (ref) v_u_278, (copy) p_u_289, (copy) v_u_292, (ref) v_u_6, (copy) v_u_293
				v_u_278(p_u_289, v_u_292)
				local v300 = {
					["at"] = nil,
					["volume"] = 0.5,
					["at"] = v_u_293
				}
				v_u_6.play("Hit", v300)
			end)
			if not p_u_289.lite then
				for v301 = 1, 5 do
					p_u_108.after(v301 * 0.45 + 0.62, function()
						-- upvalues: (copy) v_u_292, (ref) p_u_108, (ref) v_u_11
						local v302 = v_u_292.marks[math.random(1, #v_u_292.marks)]
						p_u_108.glint(v_u_292.frame * v302 + Vector3.new(0, 0.8, 0), v_u_11, 4, 0.2)
					end)
				end
			end
			p_u_108.after(p_u_289.ability.freeze or 3, function()
				-- upvalues: (ref) v_u_284, (copy) p_u_289, (copy) v_u_292
				v_u_284(p_u_289, v_u_292)
			end)
		end,
		["hit"] = function(p303, p304, p305) -- name: hit
			-- upvalues: (copy) p_u_108, (ref) v_u_8, (copy) v_u_189, (ref) v_u_35, (ref) v_u_7, (ref) v_u_1, (ref) v_u_46, (ref) v_u_9, (ref) v_u_20, (ref) v_u_4, (ref) v_u_11, (ref) v_u_56
			local v_u_306 = p303.ability.freeze or 3
			p_u_108.burst("Impact", p304, v_u_8, 0.6)
			local v307 = (v_u_189[p303] or 0) + 1
			v_u_189[p303] = v307
			local v_u_308 = p304 + Vector3.new(0, -0.4, 0)
			local v309 = v_u_35(CFrame.new(v_u_308), 2.3, v_u_7.Ring, v_u_8, 0.05)
			v_u_1:AddItem(v309, v_u_306 + 0.5)
			local v_u_310 = {
				{
					["p"] = v309,
					["off"] = CFrame.identity
				}
			}
			if not p303.lite and v307 <= 10 then
				for v311 = 0, 3 do
					local v312 = v311 * 3.141592653589793 / 2
					local v313 = math.sin(v312)
					local v314 = -math.cos(v312)
					local v315 = Vector3.new(v313, 0, v314)
					local v316 = v315 * 2.15
					local v317 = v_u_46(Vector3.new(0.4, 0.3, 0.95), CFrame.new(v_u_308), v_u_9, v_u_20)
					local v318 = CFrame.lookAt(v316, v316 + v315)
					v_u_1:AddItem(v317, v_u_306 + 0.5)
					table.insert(v_u_310, {
						["p"] = v317,
						["off"] = v318
					})
				end
			end
			local v319 = v_u_4:FindFirstChild("MyEnemies")
			local v_u_320
			if v319 then
				v_u_320 = v319:FindFirstChild("Foe" .. p305)
			else
				v_u_320 = nil
			end
			local v_u_321 = os.clock()
			p_u_108.runNow(function()
				-- upvalues: (copy) v_u_321, (copy) v_u_320, (copy) v_u_306, (ref) p_u_108, (copy) v_u_308, (ref) v_u_11, (copy) v_u_310, (ref) v_u_56
				local v322 = os.clock() - v_u_321
				local v323
				if v_u_320 == nil then
					v323 = false
				else
					v323 = v_u_320.Parent == nil
				end
				if v_u_306 > v322 and not v323 then
					if v322 < 0.5 then
						local v324 = v322 / 0.35
						local v325 = (1 - (1 - math.min(v324, 1)) ^ 2) * 3
						local v326
						if v322 > 0.35 then
							local v327 = (v322 - 0.35) * 40
							v326 = math.sin(v327) * 0.08
						else
							v326 = 0
						end
						local v328 = v325 + v326
						v_u_56(v_u_310, CFrame.new(v_u_308) * CFrame.Angles(0, -v328, 0))
					end
					return true
				end
				if not v323 then
					p_u_108.pop(v_u_308, v_u_11, 1.5, 4.5, 0.2)
				end
				for _, v329 in v_u_310 do
					v329.p:Destroy()
				end
				return false
			end)
		end
	}
	local v_u_330 = {}
	setmetatable(v_u_330, {
		["__mode"] = "k"
	})
	local function v_u_377(p331, p332) -- name: openStar
		-- upvalues: (copy) p_u_108, (ref) v_u_4, (ref) v_u_35, (ref) v_u_1, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_17
		local v333 = p_u_108.facing
		local v334 = v_u_4.CurrentCamera
		local v335
		if v334 then
			local v336 = v334.CFrame.Position - p332
			v335 = v336.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v336.Unit
		else
			v335 = Vector3.new(0, 0, 1)
		end
		local v_u_337 = v333(p332, v335)
		local v_u_338 = {
			["at"] = p332,
			["face"] = v_u_337,
			["pics"] = {},
			["lights"] = {},
			["born"] = os.clock()
		}
		local function v346(p339, p340, p341, p342, p343) -- name: pic
			-- upvalues: (ref) v_u_35, (copy) v_u_337, (ref) v_u_1, (copy) v_u_338
			local v344 = v_u_35(v_u_337, 0.1, p340, p341, p342)
			v_u_1:AddItem(v344, 3)
			local v345 = v_u_338.pics
			table.insert(v345, {
				["p"] = v344,
				["r"] = p339,
				["spin"] = p343
			})
		end
		v346(8.549999999999999, v_u_7.Glow, v_u_12, 0.35, 0)
		v346(12.15, v_u_7.Ring, v_u_8, 0.1, 0.6)
		v346(9, v_u_7.PolarStar, v_u_10, 0, 0.15)
		v346(5.3999999999999995, v_u_7.PolarStar, v_u_8, 0, 0.9353981633974483)
		if not p331.lite then
			for v347 = 0, 11 do
				local v348 = v347 % 3 == 0
				local v349 = v_u_5.part
				local v350 = Vector3.new(0.1, 0.1, 0.1)
				local v351
				if v348 then
					v351 = v_u_10
				else
					v351 = v_u_8
				end
				local v352 = v349(v350, v_u_337, v351, {
					["shape"] = v_u_17
				})
				v_u_1:AddItem(v352, 3)
				local v353 = v_u_338.lights
				local v354 = {
					["p"] = v352,
					["a"] = v347 * 3.141592653589793 / 6,
					["d"] = v348 and 1.1 or 0.65
				}
				table.insert(v353, v354)
			end
		end
		p_u_108.runNow(function()
			-- upvalues: (copy) v_u_338, (copy) v_u_337
			local v355 = os.clock()
			local v356 = v355 - v_u_338.born
			local v357 = v356 / 0.3
			local v358 = math.clamp(v357, 0, 1) - 1
			local v359 = v358 * 2.9 * v358 * v358 + 1 + v358 * 1.9 * v358
			local v360 = v_u_338.closeAt
			if v360 then
				local v361 = 1 - (v355 - v360) / 0.28
				v359 = v359 * math.max(v361, 0)
			end
			local v362 = v356 * 23
			local v363 = math.sin(v362) * 0.05 + 1
			for _, v364 in v_u_338.pics do
				local v365 = v364.r * v359 * v363
				local v366 = math.max(v365, 0.05)
				local v367 = v364.p
				local v368 = v366 * 2
				local v369 = v366 * 2
				v367.Size = Vector3.new(v368, 0.05, v369)
				v364.p.CFrame = v_u_337 * CFrame.Angles(0, v364.spin + v356 * 0.4, 0)
			end
			local v370 = v359 * 11.700000000000001
			for _, v371 in v_u_338.lights do
				local v372 = v371.a + v356 * 0.6
				local v373 = v371.p
				local v374 = v371.d * v359
				v373.Size = Vector3.new(1, 1, 1) * math.max(v374, 0.05)
				v371.p.CFrame = v_u_337 * CFrame.new(math.sin(v372) * v370, 0, -math.cos(v372) * v370)
			end
			if not v360 or v355 - v360 < 0.28 then
				return v356 < 3
			end
			for _, v375 in v_u_338.pics do
				v375.p:Destroy()
			end
			for _, v376 in v_u_338.lights do
				v376.p:Destroy()
			end
			return false
		end)
		return v_u_338
	end
	local function v_u_402(p378, p_u_379) -- name: aurora
		-- upvalues: (copy) p_u_108, (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (ref) v_u_7, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16
		local v380 = p_u_108.ground(p378.origin, 0)
		local v381 = p378.dir
		local v382 = v381:Cross(Vector3.new(0, 1, 0))
		local v_u_383 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v380), v_u_10, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_383, p_u_379 + 0.2)
		local v_u_384 = {}
		for v385 = 0, 2 do
			local v386 = Instance.new("Attachment")
			v386.Parent = v_u_383
			v386.WorldCFrame = CFrame.fromMatrix(v380 + v381 * (v385 * 9 + 34) + v382 * (v385 * 7 + -40) + Vector3.new(0, 1, 0) * (v385 * 3 + 24), Vector3.new(0, 1, 0), v382)
			local v387 = Instance.new("Attachment")
			v387.Parent = v_u_383
			v387.WorldCFrame = CFrame.fromMatrix(v380 + v381 * (v385 * 10 + 72) + v382 * (40 - v385 * 6) + Vector3.new(0, 1, 0) * (v385 * 2 + 27), Vector3.new(0, 1, 0), v382)
			local v388 = Instance.new("Beam")
			v388.Attachment0 = v386
			v388.Attachment1 = v387
			v388.Texture = v_u_7.Beam
			v388.TextureMode = Enum.TextureMode.Wrap
			v388.TextureLength = 24
			v388.TextureSpeed = 0.5
			v388.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_14), ColorSequenceKeypoint.new(0.5, v_u_15), ColorSequenceKeypoint.new(1, v_u_16) })
			v388.LightEmission = 1
			v388.LightInfluence = 0
			v388.Brightness = 2
			v388.FaceCamera = true
			v388.Segments = 20
			v388.Width0 = 12 - v385 * 2
			v388.Width1 = 9 - v385
			v388.Transparency = NumberSequence.new(1)
			v388.Parent = v_u_383
			local v389 = {
				["beam"] = v388,
				["phase"] = v385 * 1.7
			}
			table.insert(v_u_384, v389)
		end
		p_u_108.animate(p_u_379, 0, function(p390)
			-- upvalues: (copy) p_u_379, (copy) v_u_384, (copy) v_u_383
			local v391 = p390 / 0.18
			local v392 = math.min(v391, 1)
			local v393 = (1 - p390) / 0.35
			local v394 = 1 - v392 * math.min(v393, 1) * 0.62
			local v395 = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.2, v394),
				NumberSequenceKeypoint.new(0.8, v394),
				NumberSequenceKeypoint.new(1, 1)
			})
			local v396 = p390 * p_u_379
			for _, v397 in v_u_384 do
				v397.beam.Transparency = v395
				local v398 = v397.beam
				local v399 = v396 * 2.2 + v397.phase
				v398.CurveSize0 = math.sin(v399) * 9
				local v400 = v397.beam
				local v401 = v396 * 1.8 + v397.phase
				v400.CurveSize1 = math.cos(v401) * 7
			end
			if p390 >= 1 then
				v_u_383:Destroy()
			end
		end)
	end
	local function v_u_408(p403, p404) -- name: farBlast
		-- upvalues: (copy) p_u_108, (ref) v_u_10, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6
		local v405 = p_u_108.ground(p404)
		local v406 = v405 + Vector3.new(0, 2, 0)
		p_u_108.pop(v406, v_u_10, 3, 14, 0.3, 0.2)
		p_u_108.pop(v406, v_u_12, 5, 18, 0.4, 0.5)
		p_u_108.burst("Explosion", v406, v_u_8, 1.2)
		p_u_108.burst("Shockwave", v405 + Vector3.new(0, 0.3, 0), v_u_8, 0.8)
		v_u_5.ring(v405, v_u_11, 14, 0.4, v_u_7.Ring)
		if not p403.lite then
			local v407 = { v_u_8, v_u_11, v_u_9 }
			p_u_108.chunks(v405 + Vector3.new(0, 1, 0), v407, 10, 40, 1.1, 0.9)
			p_u_108.spikes(v406, v_u_10, 8, 10, 0.25)
		end
		v_u_6.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v405
		})
		if p403.mine then
			v_u_5.shake(0.45, 0.35)
		end
	end
	v109.polar_dial_r = {
		["cast"] = function(p409) -- name: cast
			-- upvalues: (copy) p_u_108, (ref) v_u_12, (ref) v_u_8, (ref) v_u_107, (copy) v_u_402
			p_u_108.skillCast(p409, v_u_12, true)
			p_u_108.glint(p409.eye, v_u_8, 5 * p409.size, 0.25)
			if p409.mine then
				v_u_107(1.15)
			end
			if not p409.lite then
				v_u_402(p409, 1.8)
			end
		end,
		["windup"] = function(p410, _, p411) -- name: windup
			-- upvalues: (copy) p_u_108, (copy) v_u_330, (copy) v_u_377, (ref) v_u_8
			local v412 = p_u_108.ground(p410.origin + p410.dir * 36, 19)
			v_u_330[p410] = v_u_377(p410, v412)
			if not p410.lite then
				p_u_108.inward(v412, v_u_8, 8, 14, (math.max(p411, 0.15)))
			end
		end,
		["beam"] = function(p_u_413, p414, p415) -- name: beam
			-- upvalues: (copy) v_u_330, (copy) v_u_377, (copy) p_u_108, (ref) v_u_5, (ref) v_u_10, (ref) v_u_18, (ref) v_u_8, (ref) v_u_12, (ref) v_u_20, (ref) v_u_9, (ref) v_u_1, (ref) v_u_90, (ref) v_u_102, (ref) v_u_11, (ref) v_u_7, (copy) v_u_408, (ref) v_u_79, (ref) v_u_22, (ref) v_u_56, (ref) v_u_62
			local v_u_416 = v_u_330[p_u_413] or v_u_377(p_u_413, p_u_108.ground(p_u_413.origin + p_u_413.dir * 36, 19))
			v_u_330[p_u_413] = nil
			local v_u_417 = v_u_416.at
			local v_u_418 = p_u_108.flatUnit(p415 - p414)
			local v_u_419 = v_u_418:Cross(Vector3.new(0, 1, 0))
			local v_u_420 = p_u_108.ground(p414 + v_u_418 * 3, 0)
			local v_u_421 = p_u_108.ground(p415, 0)
			local v422 = {
				["shape"] = v_u_18
			}
			local v_u_423 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_417), v_u_10, v422)
			local v424 = {
				["shape"] = nil,
				["transparency"] = 0.45,
				["shape"] = v_u_18
			}
			local v_u_425 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_417), v_u_8, v424)
			local v_u_426
			if p_u_413.lite then
				v_u_426 = nil
			else
				local v427 = {
					["shape"] = nil,
					["transparency"] = 0.75,
					["shape"] = v_u_18
				}
				v_u_426 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_417), v_u_12, v427)
			end
			local v428 = {
				["material"] = nil,
				["transparency"] = 0.2,
				["material"] = v_u_20
			}
			local v_u_429 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_420), v_u_8, v428)
			local v430 = {
				["material"] = v_u_20
			}
			local v_u_431 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_420), v_u_9, v430)
			for _, v432 in {
				v_u_423,
				v_u_425,
				v_u_429,
				v_u_431
			} do
				v_u_1:AddItem(v432, 2.45)
			end
			if v_u_426 then
				v_u_1:AddItem(v_u_426, 2.45)
			end
			if p_u_413.mine then
				p_u_108.light(v_u_423, v_u_8, 16)
			end
			local v_u_433 = os.clock()
			local v_u_434 = -1
			local v_u_435 = false
			local v_u_436 = {}
			p_u_108.runNow(function()
				-- upvalues: (copy) v_u_433, (copy) v_u_420, (copy) v_u_421, (copy) v_u_419, (ref) v_u_90, (copy) v_u_423, (copy) v_u_417, (copy) v_u_425, (ref) v_u_426, (ref) v_u_102, (copy) v_u_429, (copy) v_u_431, (ref) v_u_434, (ref) p_u_108, (ref) v_u_11, (copy) p_u_413, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_435, (ref) v_u_408, (copy) v_u_418, (ref) v_u_79, (copy) v_u_436, (ref) v_u_22, (ref) v_u_9, (ref) v_u_56, (copy) v_u_416, (ref) v_u_1, (ref) v_u_62
				local v437 = os.clock() - v_u_433
				local v438 = v437 / 0.3
				local v439 = math.clamp(v438, 0, 1)
				local v440 = 1 - (1 - v439) ^ 2
				local v441 = v_u_420:Lerp(v_u_421, v440)
				if v439 >= 1 then
					local v442 = v437 - 0.3
					local v443 = v_u_419
					local v444 = v442 * 30
					local v445 = v443 * math.sin(v444) * 1.4
					local v446 = -v442 * 8
					v441 = v441 + v445 * math.exp(v446)
				end
				local v447
				if v437 < 0.05 then
					v447 = v437 / 0.05
				elseif v437 < 0.6499999999999999 then
					v447 = 1
				else
					local v448 = 1 - (v437 - 0.3 - 0.35) / 0.3
					v447 = math.max(v448, 0)
				end
				local v449 = v441 + Vector3.new(0, 0.6, 0)
				v_u_90(v_u_423, v_u_417, v449, 1.6 * v447)
				v_u_90(v_u_425, v_u_417, v449, 4.2 * v447)
				local v450 = v_u_426
				if v450 then
					v_u_90(v450, v_u_417, v449, 8 * v447)
				end
				local v451 = v_u_420:Lerp(v_u_421, v440)
				v_u_102(v_u_429, v_u_420 + Vector3.new(0, 0.1, 0), v451 + Vector3.new(0, 0.1, 0), 5.5, 0.12)
				v_u_102(v_u_431, v_u_420 + Vector3.new(0, 0.2, 0), v451 + Vector3.new(0, 0.2, 0), 1.1, 0.16)
				if v439 < 1 and v437 - v_u_434 > 0.04 then
					v_u_434 = v437
					p_u_108.pop(v449, v_u_11, 2.4, 7, 0.24, 0.2)
					if not p_u_413.lite then
						p_u_108.spikes(v449, v_u_10, 2, 5, 0.18, Vector3.new(0, 1, 0), 0.6)
						v_u_5.ring(v451, v_u_8, 4, 0.25, v_u_7.Ring)
					end
				end
				if v439 >= 1 and not v_u_435 then
					v_u_435 = true
					v_u_408(p_u_413, v_u_421)
					local v452 = CFrame.lookAt(v_u_421 + Vector3.new(0, 0.2, 0), v_u_421 + Vector3.new(0, 0.2, 0) + v_u_418)
					local v453 = CFrame.lookAt(v_u_420 + Vector3.new(0, 0.2, 0), v_u_420 + Vector3.new(0, 0.2, 0) - v_u_418)
					v_u_79(v_u_436, v_u_22, 0, 4.2, 5.5, 0.16, v_u_9, 2.45)
					v_u_79(v_u_436, v_u_22, 0, 4.2, 5.5, 0.16, v_u_9, 2.45)
					v_u_56({ v_u_436[1], v_u_436[2] }, v452)
					v_u_56({ v_u_436[3], v_u_436[4] }, v453)
				end
				if v437 <= 0.95 then
					return true
				end
				v_u_423:Destroy()
				v_u_425:Destroy()
				if v450 then
					v450:Destroy()
				end
				v_u_416.closeAt = os.clock()
				p_u_108.after(0.35, function()
					-- upvalues: (ref) v_u_429, (ref) v_u_431, (ref) v_u_5, (ref) v_u_1, (ref) v_u_62, (ref) v_u_436
					for _, v454 in { v_u_429, v_u_431 } do
						v_u_5.tween(v454, 0.6, {
							["Transparency"] = 1
						})
						v_u_1:AddItem(v454, 0.65)
					end
					v_u_62(v_u_436, 0.6)
				end)
				return false
			end)
		end,
		["hit"] = function(p455, p456, _) -- name: hit
			-- upvalues: (copy) p_u_108, (ref) v_u_8, (ref) v_u_11
			p_u_108.burst("Impact", p456, v_u_8, 0.7)
			if not p455.lite then
				p_u_108.glint(p456, v_u_11, 3.5, 0.16)
			end
		end
	}
	return v109
end