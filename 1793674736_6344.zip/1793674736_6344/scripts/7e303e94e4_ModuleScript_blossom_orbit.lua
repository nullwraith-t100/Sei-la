local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return {
		["w3_blossom_orbit"] = function(p_u_5, p6)
			-- upvalues: (copy) p_u_4, (ref) v_u_2, (ref) v_u_3
			local v_u_7 = Color3.fromHex(p6.color)
			local v8 = Color3.fromHex(p6.color2)
			local v9 = p_u_4.rgb(14, 8, 16)
			local v_u_10 = p_u_5.fx <= 1 and 1 or p_u_5.fx / 1.35
			local v_u_11 = { Vector3.new(0, 0, 0), Vector3.new(0, 0, 0), Vector3.new(0, 0, 0) }
			local v_u_14 = p_u_4.throb(p_u_5, 4, 1.5, 1.8, function(p12)
				-- upvalues: (ref) v_u_2, (ref) p_u_4, (copy) p_u_5, (copy) v_u_7, (ref) v_u_3, (copy) v_u_11, (copy) v_u_10
				v_u_2.ring(p_u_4.feetAt(p_u_5, p12, 0.15), v_u_7, 5.5 * p_u_5.fx, 0.5, v_u_3.Ring)
				for _, v13 in v_u_11 do
					v_u_2.flash(v13, v_u_7, 3 * v_u_10, 0.3)
				end
			end)
			local v_u_15 = 0
			local v16 = p_u_5.ticks
			local function v18(_, _, p17)
				-- upvalues: (ref) v_u_15, (copy) v_u_14
				v_u_15 = v_u_15 + p17 * (1.3 + v_u_14() * 1.5)
			end
			table.insert(v16, v18)
			local function v_u_28(p19, p20) -- name: moonFrame
				-- upvalues: (copy) v_u_10, (ref) v_u_15, (copy) v_u_14
				local v21 = p19 * CFrame.new(0, 0.25 * v_u_10, 0) * CFrame.Angles(0, (p20 - 1) * 3.141592653589793 * 2 / 3, 0) * CFrame.Angles(0.95, 0, 0)
				local v22 = v_u_15 + (p20 - 1) * 3.141592653589793 * 2 / 3
				local v23 = 2.9 * v_u_10 * (1 + v_u_14() * 0.18)
				local v24 = math.cos(v22) * v23
				local v25 = math.sin(v22) * v23
				local v26 = v21 * Vector3.new(v24, 0, v25)
				local v27 = v26 - p19.Position
				if v27.Magnitude > 0.001 then
					return v26, v27.Unit
				else
					return v26, Vector3.new(0, 0, 1)
				end
			end
			local v_u_29 = v_u_15
			for v_u_30 = 1, 3 do
				local v33 = p_u_4.truthOrb(p_u_5, function(p31) -- name: place
					-- upvalues: (copy) v_u_28, (copy) v_u_30, (copy) v_u_11
					local v32 = v_u_28(p31, v_u_30)
					v_u_11[v_u_30] = v32
					return CFrame.new(v32)
				end, v_u_7, 1.05 * v_u_10, v9, 0.4)
				p_u_4.tail(v33, v_u_7, v8, 0.4 * v_u_10, 0.5)
				for v34 = 1, 5 do
					local v_u_35 = (v34 - 1) / 5 * 3.141592653589793 * 2
					p_u_4.add(p_u_5, p_u_4.blob(Vector3.new(0.6, 0.12, 1.05) * v_u_10, v_u_7, 0.08), function(p36)
						-- upvalues: (copy) v_u_28, (copy) v_u_30, (copy) v_u_14, (copy) v_u_35, (copy) v_u_10
						local v37, v38 = v_u_28(p36, v_u_30)
						local v39 = v38:Cross(Vector3.new(0, 1, 0))
						local v40 = v39.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v39.Unit
						local v41 = v40:Cross(v38).Unit
						local v42 = v_u_14()
						local v43 = 0.55 - 0.45 * v42
						local v44 = v_u_35
						local v45 = v_u_35
						local v46 = (v40 * math.cos(v44) + v41 * math.sin(v45)) * math.cos(v43) + v38 * math.sin(v43)
						local v47 = 1.05 * v_u_10 * (1 + 0.35 * v42)
						local v48 = v37 + v46 * (0.47250000000000003 * v_u_10 + v47 / 2)
						return CFrame.lookAt(v48, v48 + v46, v38)
					end)
				end
			end
			for v_u_49 = 1, 3 do
				local v50 = p_u_4.picture(1.2, v_u_3.Ring, v8, 0)
				p_u_4.add(p_u_5, v50, function(p51, p52)
					-- upvalues: (copy) p_u_5, (ref) p_u_4, (ref) v_u_29, (copy) v_u_49, (copy) v_u_14
					local v53 = p51.Position
					local v54 = p_u_5.headY + p_u_5.eyeLift
					local v55 = v53 + Vector3.new(0, v54, 0)
					local v56 = p_u_4.camPos() - v55
					local v57 = v56.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v56.Unit
					local v58 = -v57:Cross(Vector3.new(0, 1, 0))
					local v59 = v58.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v58.Unit
					local v60 = v57:Cross(v59).Unit
					local v61 = -v_u_29 * 1.4 + (v_u_49 - 1) * 3.141592653589793 * 2 / 3 + math.sin(p52) * 0.1
					local v62 = 2.15 * (1 + v_u_14() * 0.15)
					local v63 = v55 + (v59 * math.cos(v61) + v60 * math.sin(v61)) * v62
					return CFrame.fromMatrix(v63, v59, v57)
				end)
			end
			p_u_4.particles(p_u_5, "Petals", v_u_7, {
				["rate"] = 0.9,
				["glow"] = 0.55,
				["only"] = nil,
				["only"] = { "Petals", "Motes" }
			})
			p_u_4.particles(p_u_5, "AuraMode", v_u_7, {
				["rate"] = 0.4,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end