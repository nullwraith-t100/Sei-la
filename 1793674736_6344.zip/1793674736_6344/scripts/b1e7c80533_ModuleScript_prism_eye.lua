local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromRGB(255, 90, 209)
local v_u_9 = Color3.fromRGB(107, 231, 255)
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(236, 246, 255)
local v_u_12 = {
	Color3.fromRGB(255, 60, 70),
	Color3.fromRGB(255, 145, 35),
	Color3.fromRGB(255, 228, 50),
	Color3.fromRGB(70, 232, 95),
	Color3.fromRGB(60, 190, 255),
	Color3.fromRGB(95, 100, 255),
	Color3.fromRGB(200, 85, 255)
}
return function(p_u_13)
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_5, (copy) v_u_8, (copy) v_u_1, (copy) v_u_2, (copy) v_u_9, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4
	local function v34(p14, p15, p16) -- name: prismRay
		-- upvalues: (copy) p_u_13, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (ref) v_u_8
		local v17 = p14.size
		local v18 = p14.lite
		local v19 = p16 - p15
		local v20 = v19.Magnitude
		if v20 >= 1 then
			local v21 = v19.Unit
			local v22 = v20 * 0.26
			local v23 = p15 + v21 * math.min(v22, 16)
			p_u_13.thin(p_u_13.rod(p15, v23, 0.6 * v17, v_u_10), 0.17)
			p_u_13.thin(p_u_13.rod(p15, v23, 1.5 * v17, v_u_11, 0.55), 0.15)
			local v24 = v21:Cross(Vector3.new(0, 1, 0))
			local v25 = v24.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v24.Unit
			local v26 = v25:Cross(v21)
			local v27 = (p14.ability.width or 4) * 0.55 * v17
			local v28 = v18 and 3 or 6
			for v29 = 1, v28 do
				local v30 = (v29 - 1) / (v28 - 1) - 0.5
				local v31 = (v29 - 1) * 6 / (v28 - 1) + 1
				local v32 = v_u_12[(math.floor(v31) - 1) % #v_u_12 + 1]
				local v33 = p16 + v25 * v30 * v27 * 2 + v26 * v30 * 0.5
				p_u_13.thin(p_u_13.rod(v23, v33, 0.34 * v17, v32), 0.17)
			end
			if not v18 then
				p_u_13.glint(v23, v_u_10, 2.6 * v17, 0.12)
				p_u_13.glowBeam(v23, p16, v_u_11, 3.4 * v17, 0.17)
			end
			v_u_5.flash(p15, v_u_8, 2.6 * v17, 0.1)
		end
	end
	local v_u_35 = {}
	setmetatable(v_u_35, {
		["__mode"] = "k"
	})
	local v_u_36 = {}
	setmetatable(v_u_36, {
		["__mode"] = "k"
	})
	local function v51(p_u_37, p38) -- name: shardShot
		-- upvalues: (copy) v_u_35, (ref) v_u_12, (ref) v_u_5, (ref) v_u_10, (copy) p_u_13, (copy) v_u_36
		local v39 = p_u_37.size
		local v40 = (v_u_35[p_u_37] or 0) + 1
		v_u_35[p_u_37] = v40
		local v_u_41 = v_u_12[(math.floor(v40) - 1) % #v_u_12 + 1]
		local v42 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p38, v_u_41, {
			["transparency"] = 1
		})
		local v43 = v_u_5.part(Vector3.new(0.75, 0.75, 2.8) * v39, p38, v_u_41)
		local v44 = v_u_5.part(Vector3.new(0.3, 0.3, 2.2) * v39, p38, v_u_10)
		local v45 = CFrame.Angles(0, 0, 0.7853981633974483)
		local v46 = {
			{
				["p"] = v43,
				["off"] = v45
			},
			{
				["p"] = v44,
				["off"] = CFrame.identity
			}
		}
		if not p_u_37.lite then
			local v47 = {
				["p"] = v_u_5.part(Vector3.new(1.25, 1.25, 3.2) * v39, p38, v_u_41, {
					["transparency"] = 0.6
				}),
				["off"] = v45
			}
			table.insert(v46, v47)
			local v48 = {
				["p"] = v_u_5.part(Vector3.new(0.55, 0.55, 1.1) * v39, p38, v_u_10),
				["off"] = CFrame.new(0, 0, -1.7 * v39) * v45
			}
			table.insert(v46, v48)
		end
		p_u_13.streak(v42, v_u_41, v_u_10, 1.2 * v39, 0.16)
		if p_u_37.mine and v40 == 4 then
			p_u_13.light(v42, v_u_10, 12 * v39)
		end
		local v_u_49 = p_u_13.assemble(v42, v46, {}, 0, 0, {}, 0.16, 14)
		return {
			["place"] = v_u_49.place,
			["stop"] = function(p50) -- name: stop
				-- upvalues: (ref) v_u_36, (copy) p_u_37, (copy) v_u_41, (copy) v_u_49
				v_u_36[p_u_37] = v_u_41
				v_u_49.stop(p50)
			end
		}
	end
	local v_u_52 = {}
	setmetatable(v_u_52, {
		["__mode"] = "k"
	})
	local function v_u_92(p53, p_u_54) -- name: buildPrism
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (ref) v_u_11, (ref) v_u_8, (ref) v_u_10
		local v_u_55 = {}
		local v_u_56 = {}
		local function v75(p57, p58, p59, p60) -- name: wedge
			-- upvalues: (ref) v_u_5, (ref) v_u_1, (copy) p_u_54, (copy) v_u_55, (copy) v_u_56
			local v61 = {}
			for _, v62 in { -1, 1 } do
				local v63 = v_u_5.part
				local v64 = p57 * 5
				local v65 = p57 * 10.392304845413264
				local v66 = p57 * 6
				local v67 = Vector3.new(v64, v65, v66)
				local v68 = CFrame.identity
				local v69 = {
					["shape"] = Enum.PartType.Wedge
				}
				local v70
				if p60 then
					v70 = Enum.Material.Neon
				else
					v70 = Enum.Material.SmoothPlastic
				end
				v69.material = v70
				v69.transparency = p59
				local v71 = v63(v67, v68, p58, v69)
				if not p60 then
					v71.Reflectance = 0.3
				end
				v_u_1:AddItem(v71, p_u_54)
				local v72 = v_u_55
				table.insert(v72, v71)
				table.insert(v61, v71)
				local v73 = v_u_56
				local v74 = CFrame.new(0, 0, v62 * 12 / 4 * p57) * CFrame.Angles(0, v62 > 0 and 3.141592653589793 or 0, 0)
				table.insert(v73, v74)
			end
			return v61
		end
		v75(1, v_u_11, 0.45, false)
		local v76 = {}
		for _, v77 in v75(0.55, v_u_8, 0.2, true) do
			table.insert(v76, v77)
		end
		local v78 = { Vector3.new(0, 5.196152, 0), Vector3.new(0, -5.196152, -6), Vector3.new(0, -5.196152, 6) }
		for _, v79 in p53 and { 1 } or { 1, -1 } do
			for v80 = 1, 3 do
				local v81 = v78[v80]
				local v82 = v79 * 5 / 2
				local v83 = v81 + Vector3.new(v82, 0, 0)
				local v84 = v78[v80 % 3 + 1]
				local v85 = v79 * 5 / 2
				local v86 = v84 + Vector3.new(v85, 0, 0)
				local v87 = v_u_5.part
				local v88 = (v86 - v83).Magnitude + 0.3
				local v89 = v87(Vector3.new(0.3, 0.3, v88), CFrame.identity, v_u_10)
				v_u_1:AddItem(v89, p_u_54)
				table.insert(v_u_55, v89)
				local v90 = CFrame.lookAt
				local v91 = (v83 + v86) / 2
				table.insert(v_u_56, v90(v91, v86))
			end
		end
		return v_u_55, v76, v_u_56
	end
	local v_u_93 = 0
	local function v_u_99(p94) -- name: rainbowFlicker
		-- upvalues: (ref) v_u_93, (ref) v_u_2, (ref) v_u_1, (copy) p_u_13, (ref) v_u_5, (ref) v_u_10
		local v95 = os.clock()
		if v95 >= v_u_93 then
			v_u_93 = v95 + p94 + 0.4
			local v_u_96 = Instance.new("ColorCorrectionEffect")
			v_u_96.Name = "PrismJudgement"
			v_u_96.Saturation = 0.5
			v_u_96.Contrast = 0.15
			v_u_96.Brightness = 0.12
			v_u_96.Parent = v_u_2
			v_u_1:AddItem(v_u_96, p94 + 0.4)
			p_u_13.animate(p94, 0, function(p97)
				-- upvalues: (copy) v_u_96, (ref) v_u_5, (ref) v_u_10
				v_u_96.TintColor = Color3.fromHSV(p97 * 1.6 % 1, 0.22 * (1 - p97), 1)
				if p97 >= 1 then
					local v98 = {
						["Saturation"] = 0,
						["Contrast"] = 0,
						["Brightness"] = 0,
						["TintColor"] = nil,
						["TintColor"] = v_u_10
					}
					v_u_5.tween(v_u_96, 0.3, v98)
				end
			end)
		end
	end
	local function v_u_134(p100, p_u_101, p_u_102, p_u_103) -- name: refract
		-- upvalues: (ref) v_u_12, (ref) v_u_5, (ref) v_u_1, (copy) p_u_13
		local v104 = p100.ability.radius
		local v105 = p100.lite and 7 or 14
		local v_u_106 = math.random() < 0.5 and 1 or -1
		local v_u_107 = {}
		for v108 = 1, v105 do
			local v109 = v_u_12[(math.floor(v108) - 1) % #v_u_12 + 1]
			local v110 = v_u_5.part(Vector3.new(0.9, 0.9, 1), CFrame.new(p_u_101), v109)
			v_u_1:AddItem(v110, p_u_103 + 1)
			local v111
			if p100.lite then
				v111 = nil
			else
				v111 = v_u_5.part(Vector3.new(2.4, 2.4, 1), CFrame.new(p_u_101), v109, {
					["transparency"] = 0.6
				})
				v_u_1:AddItem(v111, p_u_103 + 1)
			end
			local v112 = v_u_5.part(Vector3.new(1.6, 1.6, 1.6), CFrame.new(p_u_102), v109, {
				["shape"] = Enum.PartType.Ball
			})
			v_u_1:AddItem(v112, p_u_103 + 1.5)
			p_u_13.streak(v112, v109, v109, 2.2, 0.55)
			local v113 = {
				["rod"] = v110,
				["glow"] = v111,
				["foot"] = v112,
				["a"] = v108 / v105 * 3.141592653589793 * 2 + math.random() * 0.3,
				["rho"] = v104 * (v108 * 0.618 % 1 * 0.7 + 0.3),
				["colour"] = v109
			}
			table.insert(v_u_107, v113)
		end
		local v_u_114 = os.clock()
		p_u_13.runNow(function()
			-- upvalues: (copy) v_u_114, (copy) p_u_103, (copy) v_u_107, (copy) v_u_106, (ref) p_u_13, (copy) p_u_102, (copy) p_u_101
			local v115 = (os.clock() - v_u_114) / p_u_103
			local v116 = math.clamp(v115, 0, 1)
			local v117 = 1 - v116 * v116
			for _, v118 in v_u_107 do
				local v119 = v118.a + v_u_106 * v116 * 1.5
				local v120 = p_u_13.ground(p_u_102, 0.6)
				local v121 = math.cos(v119)
				local v122 = math.sin(v119)
				local v123 = v120 + Vector3.new(v121, 0, v122) * v118.rho
				local v124 = (v123 - p_u_101).Magnitude
				local v125 = p_u_13.aimAt((p_u_101 + v123) / 2, v123 - p_u_101)
				v118.rod.CFrame = v125
				local v126 = v118.rod
				local v127 = v117 * 0.9 + 0.05
				local v128 = v117 * 0.9 + 0.05
				v126.Size = Vector3.new(v127, v128, v124)
				local v129 = v118.glow
				if v129 then
					v129.CFrame = v125
					local v130 = v117 * 2.4 + 0.05
					local v131 = v117 * 2.4 + 0.05
					v129.Size = Vector3.new(v130, v131, v124)
				end
				v118.foot.CFrame = CFrame.new(v123)
				v118.foot.Transparency = v116
			end
			if v116 < 1 then
				return true
			end
			for _, v132 in v_u_107 do
				v132.rod:Destroy()
				local v133 = v132.glow
				if v133 then
					v133:Destroy()
				end
				v132.foot.Transparency = 1
			end
			return false
		end)
	end
	local function v_u_153(p135, p136, p137) -- name: shatter
		-- upvalues: (copy) p_u_13, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_12, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6
		if not p136.blown then
			p136.blown = true
			local v_u_138 = p135.ability.radius
			local v139 = p136.at
			local v_u_140 = p_u_13.ground(p137)
			for _, v141 in p136.parts do
				v141:Destroy()
			end
			p_u_13.pop(v139, v_u_10, 4, v_u_138 * 1.7, 0.35, 0.05)
			p_u_13.pop(v139, v_u_8, 5, v_u_138 * 1.3, 0.45, 0.35)
			p_u_13.burst("Flash", v139, v_u_8, 1.2, true)
			p_u_13.burst("Explosion", v139, v_u_8, v_u_138 / 9)
			p_u_13.burst("Explosion", p_u_13.ground(p137, 2), v_u_9, v_u_138 / 9)
			p_u_13.burst("Sparkle", v139, nil, 1.6)
			for v142 = 1, #v_u_12 do
				p_u_13.spikes(v139, v_u_12[v142], p135.lite and 1 or 2, v_u_138 * 1.2, 0.4)
			end
			p_u_13.chunks(v139, v_u_12, p135.lite and 7 or 16, 48, 1.1, 1.2, true, 0.5)
			local v143 = p135.lite and 3 or #v_u_12
			for v_u_144 = 1, v143 do
				local v145 = (v_u_144 - 1) * (#v_u_12 - 1)
				local v146 = v143 - 1
				local v147 = v145 / math.max(v146, 1) + 1
				local v_u_148 = v_u_12[(math.floor(v147) - 1) % #v_u_12 + 1]
				p_u_13.after((v_u_144 - 1) * 0.035, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_140, (copy) v_u_148, (copy) v_u_138, (copy) v_u_144, (ref) v_u_7
					v_u_5.ring(v_u_140, v_u_148, v_u_138 * (1.45 - v_u_144 * 0.09), 0.55, v_u_7.Ring)
				end)
			end
			local v149 = p_u_13.burst
			local v150 = v_u_140 + Vector3.new(0, 0.3, 0)
			local v151 = v_u_9
			local v152 = v_u_138 / 15
			v149("Shockwave", v150, v151, (math.min(v152, 1.6)))
			p_u_13.mark(p137, v_u_8, v_u_138 * 0.75, 2, v_u_7.CrackGlow, 0.15)
			v_u_6.play("Explosion", {
				["at"] = v139,
				["volume"] = p135.mine and 1 or 0.6
			})
			if p135.mine then
				v_u_5.shake(0.6, 0.5)
			end
		end
	end
	local v224 = {
		["prism_eye_a"] = {
			["cast"] = function(p154) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_13, (ref) v_u_8, (ref) v_u_9
				local v155 = p154.eye + p154.dir * 1.1
				v_u_5.flash(v155, v_u_10, 2.8 * p154.size, 0.1)
				p_u_13.pop(v155, v_u_8, 1.2, 2.6, 0.1, 0.3)
				if not p154.lite then
					p_u_13.glint(v155, v_u_9, 2.4, 0.1)
				end
			end,
			["beam"] = v34,
			["hit"] = function(p156, p157, _) -- name: hit
				-- upvalues: (copy) p_u_13, (ref) v_u_12
				p_u_13.burst("Impact", p157, v_u_12[math.random(1, #v_u_12)], 0.7)
				p_u_13.beamHitSound(p156, p157, "Orb")
			end
		},
		["prism_eye_e"] = {
			["cast"] = function(p158) -- name: cast
				-- upvalues: (copy) p_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5
				p_u_13.skillCast(p158, v_u_8)
				p_u_13.glint(p158.eye, v_u_10, 5, 0.18)
				local v159 = p158.ability.spreadAngle or 60
				local v160 = math.rad(v159)
				for v161 = 1, #v_u_12 do
					local v162 = -v160 / 2 + v160 * (v161 - 1) / (#v_u_12 - 1)
					local v163 = CFrame.Angles(0, v162, 0):VectorToWorldSpace(p158.dir)
					local v164 = p158.eye + v163 * 3
					v_u_5.flash(v164, v_u_12[v161], 2.4, 0.18)
					if p158.lite then
						continue
					end
					p_u_13.pop(v164, v_u_10, 0.8, 0.2, 0.15)
				end
			end,
			["shot"] = v51,
			["impact"] = function(p165, p166) -- name: impact
				-- upvalues: (copy) v_u_36, (ref) v_u_8, (copy) p_u_13, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_6
				local v167 = p165.size
				local v168 = v_u_36[p165] or v_u_8
				p_u_13.burst("Impact", p166, v168, 0.95 * v167)
				v_u_5.flash(p166, v168, 4.5 * v167, 0.16)
				p_u_13.pop(p166, v_u_10, 1, 3 * v167, 0.12)
				if not p165.lite then
					local v169 = { v168, v_u_10 }
					p_u_13.chunks(p166, v169, 4, 22, 0.4 * v167, 0.45, true, 0.8)
				end
				v_u_5.ring(p_u_13.ground(p166), v168, p165.ability.radius * v167, 0.25, v_u_7.Ring)
				v_u_6.play("Hit", {
					["at"] = nil,
					["volume"] = 0.35,
					["at"] = p166
				})
			end,
			["hit"] = function(_, p170, _) -- name: hit
				-- upvalues: (copy) p_u_13, (ref) v_u_12, (ref) v_u_10
				p_u_13.burst("Impact", p170, v_u_12[math.random(1, #v_u_12)], 0.65)
				p_u_13.glint(p170, v_u_10, 3, 0.12)
			end
		},
		["prism_eye_r"] = {
			["cast"] = function(p171) -- name: cast
				-- upvalues: (copy) p_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5, (ref) v_u_7
				p_u_13.skillCast(p171, v_u_8, true)
				p_u_13.glint(p171.eye, v_u_10, 7, 0.22)
				for v172, v173 in { v_u_12[1], v_u_12[4], v_u_12[7] } do
					v_u_5.ring(p171.feet, v173, 4 + v172 * 2.2, 0.3 + v172 * 0.05, v_u_7.Ring)
				end
			end,
			["windup"] = function(p174, p175, p_u_176) -- name: windup
				-- upvalues: (ref) v_u_12, (copy) p_u_13, (ref) v_u_7, (ref) v_u_4, (copy) v_u_92, (copy) v_u_52, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11
				local v177 = p174.ability.radius
				local v_u_178 = p174.lite
				local v_u_179 = math.max(p_u_176, 0.08)
				local v_u_180 = p_u_176 + 0.9
				local v181 = v_u_178 and 3 or #v_u_12
				for v182 = 1, v181 do
					local v183 = (v182 - 1) * (#v_u_12 - 1)
					local v184 = v181 - 1
					local v185 = v183 / math.max(v184, 1) + 1
					local v186 = v_u_12[(math.floor(v185) - 1) % #v_u_12 + 1]
					p_u_13.sigil(CFrame.new(p_u_13.ground(p175, v182 * 0.01 + 0.12)), v177 * (1 - (v182 - 1) * 0.11), v186, v_u_7.Ring, v_u_180, v182 % 2 == 0 and 0.6 or -0.6)
				end
				local v_u_187 = p_u_13.ground(p175, 17)
				local v188 = p_u_13.flatUnit
				local v189 = v_u_4.CurrentCamera
				local v190
				if v189 then
					local v191 = v189.CFrame.Position - v_u_187
					v190 = v191.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v191.Unit
				else
					v190 = Vector3.new(0, 0, 1)
				end
				local v192 = v188(v190)
				local v_u_193 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v192, Vector3.new(0, 1, 0))
				local v_u_194, v_u_195, v_u_196 = v_u_92(v_u_178, v_u_180 + 1)
				local v_u_197 = {
					["parts"] = nil,
					["inner"] = nil,
					["at"] = nil,
					["sky"] = nil,
					["frame"] = nil,
					["born"] = nil,
					["blown"] = false,
					["parts"] = v_u_194,
					["inner"] = v_u_195,
					["at"] = v_u_187,
					["sky"] = v_u_187 + Vector3.new(0, 90, 0) + v_u_193.ZVector * 10,
					["frame"] = v_u_193,
					["born"] = os.clock()
				}
				v_u_52[p174] = v_u_197
				local v_u_198 = v_u_187 + Vector3.new(0, 55, 0)
				p_u_13.runNow(function()
					-- upvalues: (copy) v_u_197, (copy) v_u_179, (copy) v_u_198, (copy) v_u_187, (copy) v_u_193, (copy) v_u_194, (copy) v_u_196, (copy) v_u_195, (copy) v_u_180
					if v_u_197.blown then
						return false
					end
					local v199 = os.clock() - v_u_197.born
					local v200 = v199 / v_u_179
					local v201 = v_u_198:Lerp(v_u_187, 1 - (1 - math.clamp(v200, 0, 1)) ^ 4)
					local v202 = CFrame.Angles
					local v203 = v199 * 1.3
					local v204 = math.sin(v203) * 0.18
					local v205 = v199 * 2.1
					local v206 = v202(0, v204, math.sin(v205) * 0.04)
					local v207 = CFrame.new(v201) * v_u_193 * v206
					for v208, v209 in v_u_194 do
						v209.CFrame = v207 * v_u_196[v208]
					end
					for _, v210 in v_u_195 do
						v210.Color = Color3.fromHSV(v199 * 1.4 % 1, 0.7, 1)
					end
					return v199 < v_u_180 + 1
				end)
				p_u_13.streak(v_u_194[1], v_u_10, v_u_9, 6, 0.25)
				p_u_13.after(v_u_179 * 0.6, function()
					-- upvalues: (copy) v_u_197, (ref) p_u_13, (copy) v_u_187, (ref) v_u_10, (copy) p_u_176, (copy) v_u_178, (ref) v_u_11
					if not v_u_197.blown then
						p_u_13.thin(p_u_13.rod(v_u_197.sky, v_u_187, 2.4, v_u_10, 0.1), p_u_176 * 0.4 + 0.5, true)
						if not v_u_178 then
							p_u_13.glowBeam(v_u_197.sky, v_u_187, v_u_11, 5, p_u_176 * 0.4 + 0.5)
						end
					end
				end)
				p_u_13.burst("Flash", v_u_187, v_u_9, 0.5)
			end,
			["land"] = function(p_u_211, p_u_212) -- name: land
				-- upvalues: (copy) p_u_13, (copy) v_u_52, (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (copy) v_u_134, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (copy) v_u_99, (copy) v_u_153
				local v213 = p_u_211.ability.radius
				local v214 = p_u_13.ground(p_u_212)
				local v215 = v_u_52[p_u_211]
				local v216
				if v215 then
					v216 = v215.at
				else
					v216 = p_u_13.ground(p_u_212, 17)
				end
				local v217
				if v215 then
					v217 = v215.sky
				else
					v217 = v216 + Vector3.new(0, 90, 0)
				end
				v_u_5.flash(v216, v_u_10, 16, 0.25)
				p_u_13.burst("Flash", v216, v_u_9, 0.9, true)
				p_u_13.thin(p_u_13.rod(v217, v216, 5, v_u_10, 0.05), 0.35, true)
				v_u_134(p_u_211, v216, p_u_212, 0.45)
				v_u_5.ring(v214, v_u_10, v213, 0.45, v_u_7.Ring)
				v_u_5.ring(v214, v_u_8, v213 * 1.2, 0.4, v_u_7.SpeedLines)
				local v218 = p_u_13.burst
				local v219 = v214 + Vector3.new(0, 0.3, 0)
				local v220 = v_u_8
				local v221 = v213 / 16
				v218("Shockwave", v219, v220, (math.min(v221, 1.6)))
				v_u_6.play("Laser", {
					["at"] = v216,
					["volume"] = p_u_211.mine and 0.9 or 0.5
				})
				if p_u_211.mine then
					v_u_5.shake(0.35, 0.3)
					v_u_99(0.5)
				end
				p_u_13.after(0.42, function()
					-- upvalues: (ref) v_u_52, (copy) p_u_211, (ref) v_u_153, (copy) p_u_212
					local v222 = v_u_52[p_u_211]
					v_u_52[p_u_211] = nil
					if v222 then
						v_u_153(p_u_211, v222, p_u_212)
					end
				end)
			end,
			["hit"] = function(_, p223, _) -- name: hit
				-- upvalues: (copy) p_u_13, (ref) v_u_12, (ref) v_u_10
				p_u_13.burst("Impact", p223, v_u_12[math.random(1, #v_u_12)], 1)
				p_u_13.glint(p223, v_u_10, 4.5, 0.18)
			end
		}
	}
	return v224
end