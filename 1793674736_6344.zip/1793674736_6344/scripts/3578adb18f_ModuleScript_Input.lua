local v_u_1 = game:GetService("ContextActionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.Enemies)
local v_u_8 = require(script.Parent.Device)
local v_u_9 = require(script.Parent.Gamepad)
local v_u_10 = require(script.Parent.Look)
local v_u_11 = require(script.Parent.Sfx)
local v_u_12 = require(script.Parent.Fx.Abilities)
local v_u_13 = require(script.Parent.State)
local v_u_14 = require(v3.Shared.Net)
local v_u_15 = require(v3.Shared.Config.Abilities)
local v_u_16 = require(v3.Shared.Config.Eyes)
local v_u_17 = require(v3.Shared.Config.World)
local v_u_18 = require(v3.Shared.Logic.Aim)
local v_u_19 = require(v3.Shared.Logic.PadAim)
local v_u_20 = {}
local v_u_21 = v2.LocalPlayer
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = {
	["attack"] = 0,
	["E"] = 0,
	["R"] = 0
}
local v_u_25 = {
	["attack"] = 0.4,
	["E"] = 1,
	["R"] = 1
}
local v_u_26 = false
local v_u_27 = false
local v_u_28 = false
local v_u_29 = false
local v_u_30 = nil
function v_u_20.ability(p31) -- name: ability
	-- upvalues: (copy) v_u_16, (copy) v_u_13, (copy) v_u_15
	local v32 = v_u_16.byId[v_u_13.string("Eye", v_u_16.STARTER)] or v_u_16.byId[v_u_16.STARTER]
	local v33 = v_u_15.byId
	local v34
	if p31 == "attack" then
		v34 = v32.attack
	elseif p31 == "E" then
		v34 = v32.skillE
	else
		v34 = v32.skillR
	end
	return v33[v34]
end
function v_u_20.cooldown(p35) -- name: cooldown
	-- upvalues: (copy) v_u_24, (copy) v_u_25
	local v36 = v_u_24[p35] - os.clock()
	return math.max(0, v36), v_u_25[p35]
end
local function v_u_51(p37) -- name: lockOn
	-- upvalues: (copy) v_u_7, (ref) v_u_30
	local v38 = v_u_7.list()
	if v_u_30 then
		for _, v39 in v38 do
			if v39.id ~= v_u_30 then
				continue
			end
			local v40 = v39.pos
			local v41 = v40.X - p37.X
			local v42 = v40.Z - p37.Z
			if Vector3.new(v41, 0, v42).Magnitude > 85 then
				continue
			end
			return v39
		end
	end
	local v43 = 70
	local v44 = nil
	for _, v45 in v38 do
		local v46 = v45.pos
		local v47 = v46.X - p37.X
		local v48 = v46.Z - p37.Z
		local v49 = Vector3.new(v47, 0, v48).Magnitude
		if v49 > v43 then
			continue
		end
		v44 = v45
		v43 = v49
	end
	local v50
	if v44 then
		v50 = v44.id
	else
		v50 = nil
	end
	v_u_30 = v50
	return v44
end
local function v_u_96(p52, p53, p54) -- name: aim
	-- upvalues: (copy) v_u_21, (copy) v_u_6, (copy) v_u_7, (copy) v_u_18, (copy) v_u_19, (ref) v_u_30, (copy) v_u_51, (copy) v_u_5, (copy) v_u_17
	local v55 = v_u_21.Character
	local v56
	if v55 then
		v56 = v55:FindFirstChild("HumanoidRootPart")
	else
		v56 = v55
	end
	if v55 then
		v55 = v55:FindFirstChildOfClass("Humanoid")
	end
	if not v56 or (not v56:IsA("BasePart") or (not v55 or v55.Health <= 0)) then
		v56 = nil
	end
	local v57 = v_u_6.CurrentCamera
	if v56 and v57 then
		local v58 = v56.Position
		if p52 then
			if p54 then
				local v59 = v_u_7.list()
				local v60
				if p53 and p53.cooldown >= 3 then
					local v61 = p53.range
					v60 = math.max(70, v61)
					if (p53.at == "target" or p53.kind == "zone") and true or p53.kind == "rain" then
						local v62 = v_u_18.cluster
						local v63 = p53.radius
						local v64 = v62(v58, v59, v60, (math.max(v63, 6)))
						if v64 then
							return v64.pos, v64.id
						end
					end
				else
					v60 = 70
				end
				local v65 = v_u_19.pick(v58, v57.CFrame.LookVector, v59, v60, 85, v_u_30)
				if v65 then
					v_u_30 = v65.id
					return v65.pos, v65.id
				end
			else
				if p53 and p53.cooldown >= 3 then
					local v66 = p53.range
					local v67 = math.max(70, v66)
					local v68 = (p53.at == "target" or p53.kind == "zone") and true or p53.kind == "rain"
					local v69 = v_u_7.list()
					local v70
					if v68 then
						local v71 = v_u_18.cluster
						local v72 = p53.radius
						v70 = v71(v58, v69, v67, (math.max(v72, 6)))
					else
						v70 = v_u_18.nearest(v58, v69, v67)
					end
					if v70 then
						return v70.pos, v70.id
					end
				end
				local v73 = v_u_51(v58)
				if v73 then
					return v73.pos, v73.id
				end
			end
			local v74 = v57.CFrame.LookVector
			local v75 = v74.X
			local v76 = v74.Z
			local v77 = Vector3.new(v75, 0, v76)
			return v58 + (v77.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v77.Unit) * 30, nil
		else
			local v78 = v_u_5:GetMouseLocation()
			local v79 = v57:ViewportPointToRay(v78.X, v78.Y)
			local v80 = v_u_17.FLOOR_Y + 2.5
			local v81
			if v79.Direction.Y < -0.001 then
				local v82 = (v80 - v79.Origin.Y) / v79.Direction.Y
				v81 = v79.Origin + v79.Direction * v82
			else
				local v83 = v79.Origin + v79.Direction * 200
				local v84 = v83.X
				local v85 = v83.Z
				v81 = Vector3.new(v84, v80, v85)
			end
			local v86 = v81.X - v58.X
			local v87 = v81.Z - v58.Z
			local v88 = Vector3.new(v86, 0, v87).Magnitude * 0.18
			local v89 = math.max(6, v88)
			local v90 = (1 / 0)
			local v91 = nil
			for _, v92 in v_u_7.list() do
				local v93 = v92.pos.X - v81.X
				local v94 = v92.pos.Z - v81.Z
				local v95 = Vector3.new(v93, 0, v94).Magnitude
				if v95 >= v89 or v95 >= v90 then
					continue
				end
				v91 = v92
				v90 = v95
			end
			if v91 then
				return v91.pos, v91.id
			else
				return v81, nil
			end
		end
	else
		return Vector3.new(0, 0, 0), nil
	end
end
local function v_u_107(p97, p98) -- name: fire
	-- upvalues: (copy) v_u_21, (copy) v_u_24, (copy) v_u_20, (copy) v_u_25, (copy) v_u_9, (copy) v_u_8, (copy) v_u_96, (copy) v_u_10, (ref) v_u_22, (copy) v_u_12
	local v99 = v_u_21.Character
	local v100
	if v99 then
		v100 = v99:FindFirstChild("HumanoidRootPart")
	else
		v100 = v99
	end
	if v99 then
		v99 = v99:FindFirstChildOfClass("Humanoid")
	end
	if not v100 or (not v100:IsA("BasePart") or (not v99 or v99.Health <= 0)) then
		v100 = nil
	end
	if v100 then
		local v101 = os.clock()
		if v101 >= v_u_24[p97] then
			local v102 = v_u_20.ability(p97)
			local v103 = v102.cooldown
			v_u_24[p97] = v101 + v103
			v_u_25[p97] = v103
			local v104 = v_u_9.active()
			if v104 then
				v104 = not v_u_8.touch()
			end
			local v105, v106 = v_u_96(p98 or (v104 or v_u_8.touch()), v102, v104)
			v_u_10.pose(v_u_21, v105, p97 ~= "attack")
			v_u_22:FireServer(p97, v105, v106)
			v_u_12.predict(v102, v105)
		end
	else
		return
	end
end
function v_u_20.press(p108) -- name: press
	-- upvalues: (copy) v_u_107
	v_u_107(p108, false)
end
function v_u_20.hold(p109) -- name: hold
	-- upvalues: (ref) v_u_26
	v_u_26 = p109
end
local v_u_110 = nil
local v_u_111 = false
function v_u_20.takeClick() -- name: takeClick
	-- upvalues: (ref) v_u_110, (ref) v_u_111
	local v112 = v_u_110
	local v113 = v_u_111
	v_u_110 = nil
	v_u_111 = false
	return v112, v113
end
function v_u_20.autoClick() -- name: autoClick
	-- upvalues: (copy) v_u_21, (ref) v_u_110, (ref) v_u_111, (ref) v_u_23, (copy) v_u_11, (copy) v_u_107
	local v114 = v_u_21.Character
	local v115
	if v114 then
		v115 = v114:FindFirstChild("HumanoidRootPart")
	else
		v115 = v114
	end
	if v114 then
		v114 = v114:FindFirstChildOfClass("Humanoid")
	end
	if not v115 or (not v115:IsA("BasePart") or (not v114 or v114.Health <= 0)) then
		v115 = nil
	end
	if v115 then
		v_u_110 = Vector2.zero
		v_u_111 = true
		v_u_23:FireServer()
		v_u_11.play("Gain", {
			["volume"] = 0.35
		})
		v_u_107("attack", true)
	end
end
function v_u_20.start() -- name: start
	-- upvalues: (ref) v_u_22, (copy) v_u_14, (ref) v_u_23, (copy) v_u_5, (ref) v_u_110, (ref) v_u_111, (copy) v_u_11, (ref) v_u_27, (copy) v_u_107, (ref) v_u_28, (copy) v_u_20, (copy) v_u_1, (copy) v_u_9, (ref) v_u_29, (copy) v_u_21, (copy) v_u_4, (ref) v_u_26, (copy) v_u_8, (copy) v_u_24
	v_u_22 = v_u_14.event("Cast")
	v_u_23 = v_u_14.event("Train")
	v_u_5.InputBegan:Connect(function(p116, p117)
		-- upvalues: (ref) v_u_110, (ref) v_u_111, (ref) v_u_23, (ref) v_u_11, (ref) v_u_27, (ref) v_u_107, (ref) v_u_28, (ref) v_u_20
		if p117 then
			return
		elseif p116.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_110 = Vector2.new(p116.Position.X, p116.Position.Y) or Vector2.zero
			v_u_111 = false
			v_u_23:FireServer()
			v_u_11.play("Gain", nil)
			v_u_27 = true
			v_u_107("attack", false)
			return
		elseif p116.KeyCode == Enum.KeyCode.F then
			v_u_28 = true
			return
		elseif p116.KeyCode == Enum.KeyCode.E then
			v_u_20.press("E")
		elseif p116.KeyCode == Enum.KeyCode.R then
			v_u_20.press("R")
		end
	end)
	v_u_5.InputEnded:Connect(function(p118)
		-- upvalues: (ref) v_u_27, (ref) v_u_28
		if p118.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_27 = false
		elseif p118.KeyCode == Enum.KeyCode.F then
			v_u_28 = false
		end
	end)
	v_u_5.TouchTapInWorld:Connect(function(p119, p120)
		-- upvalues: (ref) v_u_110, (ref) v_u_111, (ref) v_u_23, (ref) v_u_11, (ref) v_u_107
		if not p120 then
			v_u_110 = p119 or Vector2.zero
			v_u_111 = false
			v_u_23:FireServer()
			v_u_11.play("Gain", nil)
			v_u_107("attack", true)
		end
	end)
	v_u_1:BindActionAtPriority("PadCombat", function(_, p121, p122)
		-- upvalues: (ref) v_u_9, (ref) v_u_29, (ref) v_u_110, (ref) v_u_111, (ref) v_u_23, (ref) v_u_11, (ref) v_u_107
		local v123 = p122.KeyCode
		if v123 == Enum.KeyCode.ButtonR2 then
			if p121 == Enum.UserInputState.Begin then
				if v_u_9.busy() then
					return Enum.ContextActionResult.Pass
				end
				v_u_29 = true
				v_u_110 = Vector2.zero
				v_u_111 = false
				v_u_23:FireServer()
				v_u_11.play("Gain", nil)
				v_u_107("attack", true)
				return Enum.ContextActionResult.Sink
			elseif p121 == Enum.UserInputState.End or p121 == Enum.UserInputState.Cancel then
				local v124 = v_u_29
				v_u_29 = false
				if v124 then
					return Enum.ContextActionResult.Sink
				else
					return Enum.ContextActionResult.Pass
				end
			else
				return Enum.ContextActionResult.Pass
			end
		else
			if p121 ~= Enum.UserInputState.Begin or v_u_9.busy() then
				return Enum.ContextActionResult.Pass
			end
			v_u_107(v123 == Enum.KeyCode.ButtonL1 and "E" or "R", true)
			return Enum.ContextActionResult.Sink
		end
	end, false, Enum.ContextActionPriority.Medium.Value, Enum.KeyCode.ButtonR2, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
	v_u_9.changed:Connect(function(p125)
		-- upvalues: (ref) v_u_29
		if not p125 then
			v_u_29 = false
		end
	end)
	v_u_21.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_29
		v_u_29 = false
	end)
	v_u_4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_29, (ref) v_u_9, (ref) v_u_107, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_8
		if v_u_29 then
			if v_u_9.busy() then
				v_u_29 = false
			else
				v_u_107("attack", true)
			end
		else
			if v_u_26 or (v_u_27 or v_u_28) then
				local v126 = v_u_107
				local v127 = "attack"
				local v128 = v_u_26
				if v128 then
					v128 = v_u_8.touch()
				end
				v126(v127, v128)
			end
			return
		end
	end)
	v_u_21:GetAttributeChangedSignal("Eye"):Connect(function()
		-- upvalues: (ref) v_u_24
		v_u_24.E = 0
		v_u_24.R = 0
	end)
end
return v_u_20