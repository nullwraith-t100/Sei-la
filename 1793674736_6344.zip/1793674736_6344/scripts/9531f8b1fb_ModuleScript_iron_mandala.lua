local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("B8C2CC")
local v_u_9 = Color3.fromHex("2B3036")
local v_u_10 = Color3.fromRGB(18, 20, 24)
local v_u_11 = Color3.fromRGB(226, 238, 250)
local v_u_12 = Color3.fromRGB(255, 176, 64)
local v_u_13 = Color3.fromRGB(255, 112, 32)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.PartType.Cylinder
local v_u_17 = Enum.Material.SmoothPlastic
local v_u_18 = Enum.Material.Metal
local v_u_19 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_20 = CFrame.Angles(0, 1.5707963267948966, 0)
local function v_u_32(p21, p22, p23, p24, p25) -- name: disc
	-- upvalues: (copy) v_u_5
	local v26 = v_u_5.part
	local v27 = p22 * 2
	local v28 = p22 * 2
	local v29 = v26(Vector3.new(v27, 0.05, v28), p21, p24, {
		["transparency"] = 1
	})
	for _, v30 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v31 = Instance.new("Decal")
		v31.Face = v30
		v31.Texture = p23
		v31.Color3 = p24
		v31.Transparency = p25
		v31.Parent = v29
	end
	return v29
end
local function v_u_36(p33, p34) -- name: fadeDecals
	for _, v35 in p33:GetChildren() do
		if not v35:IsA("Decal") then
			continue
		end
		v35.Transparency = p34
	end
end
local function v_u_37() -- name: newBody
	return {
		["parts"] = nil,
		["offs"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["cfs"] = nil,
		["k"] = -1,
		["f"] = -1,
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {},
		["alphas"] = {},
		["cfs"] = {}
	}
end
local function v_u_56(p38, p39, p40, p41) -- name: placeBody
	-- upvalues: (copy) v_u_4
	local v42 = math.max(p40, 0.02)
	local v43 = math.clamp(p41, 0, 1)
	local v44 = p38.parts
	local v45 = p38.offs
	local v46 = p38.cfs
	for v47 = 1, #v44 do
		local v48 = v45[v47]
		v46[v47] = p39 * (v48 - v48.Position + v48.Position * v42)
	end
	if #v44 > 0 then
		v_u_4:BulkMoveTo(v44, v46, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v49 = v42 - p38.k
	if math.abs(v49) > 0.0001 then
		p38.k = v42
		for v50, v51 in v44 do
			v51.Size = p38.sizes[v50] * v42
		end
	end
	local v52 = v43 - p38.f
	if math.abs(v52) > 0.001 then
		p38.f = v43
		for v53, v54 in v44 do
			local v55 = p38.alphas[v53]
			v54.Transparency = v55 + (1 - v55) * v43
		end
	end
end
return function(p_u_57)
	-- upvalues: (copy) v_u_32, (copy) v_u_1, (copy) v_u_36, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_16, (copy) v_u_18, (copy) v_u_20, (copy) v_u_17, (copy) v_u_11, (copy) v_u_15, (copy) v_u_12, (copy) v_u_4, (copy) v_u_7, (copy) v_u_13, (copy) v_u_37, (copy) v_u_19, (copy) v_u_10, (copy) v_u_56, (copy) v_u_14, (copy) v_u_6, (copy) v_u_2
	local function v_u_74(p_u_58, p_u_59, p_u_60, p61, p62, p_u_63, p_u_64, p65) -- name: flare
		-- upvalues: (ref) v_u_32, (ref) v_u_1, (copy) p_u_57, (ref) v_u_36
		local v_u_66 = p65 or 0
		local v_u_67 = v_u_32(p_u_58, p_u_59, p61, p62, v_u_66)
		v_u_1:AddItem(v_u_67, p_u_63 + 0.1)
		p_u_57.animate(p_u_63, 0, function(p68)
			-- upvalues: (copy) p_u_59, (copy) p_u_60, (copy) v_u_67, (copy) p_u_58, (copy) p_u_63, (copy) p_u_64, (ref) v_u_36, (copy) v_u_66
			local v69 = 1 - (1 - p68) ^ 3
			local v70 = p_u_59 + (p_u_60 - p_u_59) * v69
			local v71 = v_u_67
			local v72 = v70 * 2
			local v73 = v70 * 2
			v71.Size = Vector3.new(v72, 0.05, v73)
			v_u_67.CFrame = p_u_58 * CFrame.Angles(0, p68 * p_u_63 * p_u_64, 0)
			v_u_36(v_u_67, v_u_66 + (1 - v_u_66) * p68 ^ 1.5)
			if p68 >= 1 then
				v_u_67:Destroy()
			end
		end)
	end
	local function v_u_84(p75, p76, p77, p78) -- name: steam
		-- upvalues: (copy) p_u_57
		for v79 = 1, p76 do
			local v80 = (v79 + math.random() * 0.5) / p76 * 3.141592653589793 * 2
			local v81 = p_u_57.burst
			local v82 = math.cos(v80) * p77
			local v83 = math.sin(v80) * p77
			v81("Smoke", p75 + Vector3.new(v82, 0, v83), nil, p78)
		end
	end
	local function v_u_105(p85, p86, p87, p_u_88) -- name: scatter
		-- upvalues: (ref) v_u_1, (copy) p_u_57
		local v_u_89 = {}
		for _, v90 in p85 do
			if not v90.Parent then
				continue
			end
			local v91 = v90.Position - p86
			local v92 = v91.X
			local v93 = v91.Z
			local v94 = Vector3.new(v92, 0, v93)
			local v95 = {
				["p"] = v90,
				["v"] = (v94.Magnitude <= 0.1 and Vector3.new(1, 0, 0) or v94.Unit) * p87 * (0.5 + math.random() * 0.6) + Vector3.new(0, 1, 0) * p87 * (0.5 + math.random() * 0.6),
				["spin"] = CFrame.Angles((math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4, 0),
				["a"] = v90.Transparency
			}
			table.insert(v_u_89, v95)
			v_u_1:AddItem(v90, p_u_88 + 0.1)
		end
		local v_u_96 = os.clock()
		local v_u_97 = v_u_96
		p_u_57.frame(function()
			-- upvalues: (ref) v_u_97, (copy) v_u_96, (copy) p_u_88, (copy) v_u_89
			local v98 = os.clock()
			local v99 = v98 - v_u_97
			local v100 = math.min(v99, 0.05)
			v_u_97 = v98
			local v101 = (v98 - v_u_96) / p_u_88
			local v102 = math.clamp(v101, 0, 1)
			for _, v103 in v_u_89 do
				if not v103.p.Parent then
					continue
				end
				v103.v = v103.v - Vector3.new(0, 100, 0) * v100
				v103.p.CFrame = (v103.p.CFrame + v103.v * v100) * v103.spin
				v103.p.Transparency = v103.a + (1 - v103.a) * v102 ^ 1.5
			end
			if v102 < 1 then
				return true
			end
			for _, v104 in v_u_89 do
				v104.p:Destroy()
			end
			return false
		end)
	end
	local function v141(p106, p107) -- name: cogShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_57, (ref) v_u_9, (ref) v_u_1, (ref) v_u_16, (ref) v_u_18, (ref) v_u_20, (ref) v_u_17, (ref) v_u_11, (ref) v_u_15, (ref) v_u_12
		local v_u_108 = p106.size
		local v_u_109 = p106.lite
		local v_u_110 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p107, v_u_8, {
			["transparency"] = 1
		})
		p_u_57.streak(v_u_110, v_u_8, v_u_9, 1 * v_u_108, 0.13)
		local v_u_111 = {}
		local v112 = Vector3.new(0.4, 1.9, 1.9) * v_u_108
		local v113 = {
			["shape"] = v_u_16,
			["material"] = v_u_18
		}
		local v114 = v_u_5.part(v112, CFrame.identity, v_u_8, v113)
		local v115 = v_u_20
		v114.CFrame = p107 * v115
		v_u_1:AddItem(v114, 3)
		table.insert(v_u_111, {
			["p"] = v114,
			["off"] = v115
		})
		for v116 = 0, v_u_109 and 1 or 2 do
			local v117 = 0.45 * v_u_108
			local v118 = 2.6 * v_u_108
			local v119 = 0.32 * v_u_108
			local v120 = Vector3.new(v117, v118, v119)
			local v121 = {
				["shape"] = nil,
				["material"] = nil,
				["material"] = v_u_18
			}
			local v122 = v_u_5.part(v120, CFrame.identity, v_u_8, v121)
			local v123 = CFrame.Angles(0, 0, v116 * 3.141592653589793 / (v_u_109 and 2 or 3))
			v122.CFrame = p107 * v123
			v_u_1:AddItem(v122, 3)
			table.insert(v_u_111, {
				["p"] = v122,
				["off"] = v123
			})
		end
		local v124 = Vector3.new(0.5, 0.8, 0.8) * v_u_108
		local v125 = {
			["shape"] = v_u_16,
			["material"] = v_u_17
		}
		local v126 = v_u_5.part(v124, CFrame.identity, v_u_9, v125)
		v126.Reflectance = 0.15
		local v127 = v_u_20
		v126.CFrame = p107 * v127
		v_u_1:AddItem(v126, 3)
		table.insert(v_u_111, {
			["p"] = v126,
			["off"] = v127
		})
		if not v_u_109 then
			local v128 = {
				["shape"] = nil,
				["transparency"] = 0.75,
				["shape"] = v_u_15
			}
			local v129 = v_u_5.part(Vector3.new(2.7, 2.7, 2.7) * v_u_108, CFrame.identity, v_u_11, v128)
			local v130 = CFrame.identity
			v129.CFrame = p107 * v130
			v_u_1:AddItem(v129, 3)
			table.insert(v_u_111, {
				["p"] = v129,
				["off"] = v130
			})
		end
		if p106.mine then
			p_u_57.light(v_u_110, v_u_11, 9 * v_u_108)
		end
		v_u_1:AddItem(v_u_110, 3)
		local v_u_131 = 0
		local v_u_132 = false
		return {
			["place"] = function(p133, p134) -- name: place
				-- upvalues: (copy) v_u_110, (copy) v_u_111, (copy) v_u_109, (ref) v_u_131, (ref) p_u_57, (copy) v_u_108, (ref) v_u_12
				v_u_110.CFrame = p133
				local v135 = p133 * CFrame.Angles(0, 0, -p134 * 26)
				for _, v136 in v_u_111 do
					v136.p.CFrame = v135 * v136.off
				end
				if not v_u_109 and v_u_131 <= p134 then
					v_u_131 = p134 + 0.08
					local v137 = math.random() * 3.141592653589793 * 2
					local v138 = p133.RightVector * math.cos(v137) + p133.UpVector * math.sin(v137)
					p_u_57.spikes(p133.Position + v138 * 1.2 * v_u_108, v_u_12, 1, 1.8 * v_u_108, 0.12, v138 + p133.LookVector * -0.6, 0.3)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_132, (copy) v_u_110, (ref) v_u_1, (copy) v_u_111
				if not v_u_132 then
					v_u_132 = true
					local v139 = v_u_110:FindFirstChildWhichIsA("PointLight")
					if v139 then
						v139:Destroy()
					end
					v_u_1:AddItem(v_u_110, 0.15)
					for _, v140 in v_u_111 do
						v140.p:Destroy()
					end
				end
			end
		}
	end
	local function v152(p142, p143) -- name: cogImpact
		-- upvalues: (copy) v_u_74, (copy) p_u_57, (ref) v_u_4, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_5, (ref) v_u_8
		local v144 = p142.size
		local v145 = p142.lite
		local v146 = v_u_74
		local v147 = p_u_57.facing
		local v148 = v_u_4.CurrentCamera
		local v149
		if v148 then
			local v150 = v148.CFrame.Position - p143
			v149 = v150.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v150.Unit
		else
			v149 = Vector3.new(0, 0, 1)
		end
		v146(v147(p143, v149), 1 * v144, 3.6 * v144, v_u_7.GearCircle, v_u_11, 0.22, 10)
		p_u_57.pop(p143, v_u_11, 1.4 * v144, 3.6 * v144, 0.14, 0.35)
		p_u_57.burst("Impact", p143, v_u_11, 0.9 * v144)
		p_u_57.spikes(p143, v_u_12, v145 and 3 or 7, 4 * v144, 0.18)
		if not v145 then
			local v151 = { v_u_12, v_u_13 }
			p_u_57.chunks(p143, v151, 5, 22, 0.25 * v144, 0.45, true, 0.8)
		end
		v_u_5.ring(p_u_57.ground(p143), v_u_8, p142.ability.radius * 0.6 * v144, 0.22, v_u_7.Ring)
		p_u_57.hitSound(p143)
	end
	local function v_u_222(p153, p154) -- name: buildPiston
		-- upvalues: (ref) v_u_37, (ref) v_u_19, (ref) v_u_16, (ref) v_u_5, (ref) v_u_8, (ref) v_u_18, (ref) v_u_1, (ref) v_u_9, (ref) v_u_17, (ref) v_u_11, (ref) v_u_10, (ref) v_u_15
		local v155 = v_u_37()
		local v156 = {
			["shape"] = v_u_16,
			["material"] = v_u_18
		}
		local v157 = v_u_5.part(Vector3.new(0.9, 13.6, 13.6), CFrame.identity, v_u_8, v156)
		local v158 = CFrame.new(0, 0.45, 0) * v_u_19
		v157.Transparency = 1
		v_u_1:AddItem(v157, p154)
		local v159 = v155.parts
		table.insert(v159, v157)
		local v160 = v155.offs
		table.insert(v160, v158)
		local v161 = v155.sizes
		local v162 = v157.Size
		table.insert(v161, v162)
		local v163 = v155.alphas
		table.insert(v163, 0)
		local v164 = {
			["shape"] = v_u_16,
			["material"] = v_u_17
		}
		local v165 = v_u_5.part(Vector3.new(4.4, 12.8, 12.8), CFrame.identity, v_u_9, v164)
		v165.Reflectance = 0.15
		local v166 = CFrame.new(0, 3.1, 0) * v_u_19
		v165.Transparency = 1
		v_u_1:AddItem(v165, p154)
		local v167 = v155.parts
		table.insert(v167, v165)
		local v168 = v155.offs
		table.insert(v168, v166)
		local v169 = v155.sizes
		local v170 = v165.Size
		table.insert(v169, v170)
		local v171 = v155.alphas
		table.insert(v171, 0)
		local v172 = {
			["shape"] = v_u_16,
			["material"] = v_u_18
		}
		local v173 = v_u_5.part(Vector3.new(0.9, 13.5, 13.5), CFrame.identity, v_u_8, v172)
		local v174 = CFrame.new(0, 4.6, 0) * v_u_19
		v173.Transparency = 1
		v_u_1:AddItem(v173, p154)
		local v175 = v155.parts
		table.insert(v175, v173)
		local v176 = v155.offs
		table.insert(v176, v174)
		local v177 = v155.sizes
		local v178 = v173.Size
		table.insert(v177, v178)
		local v179 = v155.alphas
		table.insert(v179, 0)
		local v180 = {
			["shape"] = v_u_16,
			["material"] = v_u_17
		}
		local v181 = v_u_5.part(Vector3.new(1.8, 6.4, 6.4), CFrame.identity, v_u_9, v180)
		v181.Reflectance = 0.15
		local v182 = CFrame.new(0, 6.2, 0) * v_u_19
		v181.Transparency = 1
		v_u_1:AddItem(v181, p154)
		local v183 = v155.parts
		table.insert(v183, v181)
		local v184 = v155.offs
		table.insert(v184, v182)
		local v185 = v155.sizes
		local v186 = v181.Size
		table.insert(v185, v186)
		local v187 = v155.alphas
		table.insert(v187, 0)
		local v188 = {
			["shape"] = v_u_16,
			["material"] = v_u_18
		}
		local v189 = v_u_5.part(Vector3.new(34, 4.2, 4.2), CFrame.identity, v_u_8, v188)
		local v190 = CFrame.new(0, 24.1, 0) * v_u_19
		v189.Transparency = 1
		v_u_1:AddItem(v189, p154)
		local v191 = v155.parts
		table.insert(v191, v189)
		local v192 = v155.offs
		table.insert(v192, v190)
		local v193 = v155.sizes
		local v194 = v189.Size
		table.insert(v193, v194)
		local v195 = v155.alphas
		table.insert(v195, 0)
		if not p153 then
			local v196 = {
				["shape"] = v_u_16
			}
			local v197 = v_u_5.part(Vector3.new(0.3, 12.6, 12.6), CFrame.identity, v_u_11, v196)
			local v198 = CFrame.new(0, 0.12, 0) * v_u_19
			v197.Transparency = 1
			v_u_1:AddItem(v197, p154)
			local v199 = v155.parts
			table.insert(v199, v197)
			local v200 = v155.offs
			table.insert(v200, v198)
			local v201 = v155.sizes
			local v202 = v197.Size
			table.insert(v201, v202)
			local v203 = v155.alphas
			table.insert(v203, 0.25)
			local v204 = {
				["shape"] = v_u_16
			}
			local v205 = v_u_5.part(Vector3.new(0.25, 13, 13), CFrame.identity, v_u_11, v204)
			local v206 = CFrame.new(0, 2, 0) * v_u_19
			v205.Transparency = 1
			v_u_1:AddItem(v205, p154)
			local v207 = v155.parts
			table.insert(v207, v205)
			local v208 = v155.offs
			table.insert(v208, v206)
			local v209 = v155.sizes
			local v210 = v205.Size
			table.insert(v209, v210)
			local v211 = v155.alphas
			table.insert(v211, 0.2)
			for v212 = 1, 6 do
				local v213 = v212 / 6 * 3.141592653589793 * 2
				local v214 = {
					["shape"] = v_u_15,
					["material"] = v_u_17
				}
				local v215 = v_u_5.part(Vector3.new(0.9, 0.9, 0.9), CFrame.identity, v_u_10, v214)
				local v216 = CFrame.new(math.cos(v213) * 6.45, 3.1, math.sin(v213) * 6.45)
				v215.Transparency = 1
				v_u_1:AddItem(v215, p154)
				local v217 = v155.parts
				table.insert(v217, v215)
				local v218 = v155.offs
				table.insert(v218, v216)
				local v219 = v155.sizes
				local v220 = v215.Size
				table.insert(v219, v220)
				local v221 = v155.alphas
				table.insert(v221, 0)
			end
		end
		return v155
	end
	local v_u_223 = {}
	setmetatable(v_u_223, {
		["__mode"] = "k"
	})
	local function v_u_247(p224, p225, p226) -- name: pistonStep
		-- upvalues: (copy) p_u_57, (ref) v_u_56
		if p225.done then
			return false
		end
		local v227 = os.clock()
		local v228 = p_u_57.ground(p226, 0)
		local v229 = CFrame.Angles(0, p225.born % 1 * 3.141592653589793 * 2, 0)
		local v230 = 0
		local v231 = CFrame.identity
		local v232
		if v227 < p225.landAt then
			local v233 = p225.landAt - p225.born
			local v234 = (v227 - p225.born) / math.max(v233, 0.001)
			local v235 = math.clamp(v234, 0, 1)
			if v235 < 0.4 then
				v232 = v235 / 0.4 * 2.5 + 15
			else
				v232 = (1 - ((v235 - 0.4) / 0.6) ^ 2) * 17.5
			end
			local v236 = v235 * 4
			v230 = 1 - math.min(v236, 1)
		elseif v227 < p225.landAt + 0.5 then
			local v237 = (v227 - p225.landAt) / 0.5
			local v238 = v237 * 22
			local v239 = math.sin(v238)
			v232 = math.abs(v239) * 0.5 * (1 - v237)
			local v240 = CFrame.Angles
			local v241 = v237 * 40
			local v242 = math.sin(v241) * 0.015 * (1 - v237)
			local v243 = v237 * 37
			v231 = v240(v242, 0, math.cos(v243) * 0.015 * (1 - v237))
		else
			local v244 = (v227 - p225.landAt - 0.5) / 0.45
			local v245 = math.clamp(v244, 0, 1)
			v232 = v245 * 26 * v245
			v230 = v245 ^ 1.5
			if v245 >= 1 then
				p225.done = true
				for _, v246 in p225.body.parts do
					v246:Destroy()
				end
				return false
			end
		end
		v_u_56(p225.body, CFrame.new(v228 + Vector3.new(0, 1, 0) * v232) * v229 * v231, p224.size, v230)
		return true
	end
	local v_u_248 = { 0.95, 0.66, 0.38 }
	local v_u_249 = { 7, 5, 4 }
	local v_u_250 = { 5, 4, 0 }
	local v_u_251 = { 4, 3, 0 }
	local v_u_252 = { 2, 0, 0 }
	local v_u_253 = { 1, -1, 1 }
	local v_u_254 = {}
	setmetatable(v_u_254, {
		["__mode"] = "k"
	})
	local function v_u_323(p255, p_u_256, p_u_257) -- name: buildTrap
		-- upvalues: (copy) p_u_57, (ref) v_u_1, (copy) v_u_248, (copy) v_u_250, (copy) v_u_249, (copy) v_u_252, (copy) v_u_251, (ref) v_u_5, (ref) v_u_8, (ref) v_u_18, (ref) v_u_9, (ref) v_u_17, (ref) v_u_11, (ref) v_u_16, (ref) v_u_19, (ref) v_u_15, (ref) v_u_10, (ref) v_u_32, (ref) v_u_7
		local v258 = p255.lite
		local v259 = p255.ability.radius * p255.size
		local v_u_260 = {
			["parts"] = nil,
			["offs"] = nil,
			["ringOf"] = nil,
			["halfOf"] = nil,
			["cfs"] = nil,
			["chompAt"] = nil,
			["yaw"] = nil,
			["born"] = nil,
			["closeAt"] = nil,
			["sky"] = nil,
			["r"] = nil,
			["life"] = nil,
			["done"] = false,
			["parts"] = {},
			["offs"] = {},
			["ringOf"] = {},
			["halfOf"] = {},
			["cfs"] = {},
			["chompAt"] = { -10, -10, -10 },
			["yaw"] = { 0, 0.4, 0.9 },
			["born"] = os.clock(),
			["sky"] = {},
			["r"] = v259,
			["life"] = p_u_257
		}
		local function v269(p261, p262, p263, p264) -- name: add
			-- upvalues: (ref) p_u_57, (copy) p_u_256, (ref) v_u_1, (copy) p_u_257, (copy) v_u_260
			p261.CFrame = CFrame.new(p_u_57.ground(p_u_256, -4))
			v_u_1:AddItem(p261, p_u_257)
			local v265 = v_u_260.parts
			table.insert(v265, p261)
			local v266 = v_u_260.offs
			table.insert(v266, p264)
			local v267 = v_u_260.ringOf
			table.insert(v267, p262)
			local v268 = v_u_260.halfOf
			table.insert(v268, p263)
		end
		for v270, v271 in v_u_248 do
			local v272 = v259 * v271
			local v273
			if v258 then
				v273 = v_u_250[v270]
			else
				v273 = v_u_249[v270]
			end
			local v274
			if v258 then
				v274 = v_u_252[v270]
			else
				v274 = v_u_251[v270]
			end
			if v273 == 0 then
				continue
			end
			local v275 = 2 * v272
			local v276 = 3.141592653589793 / (2 * v273)
			local v277 = v275 * math.sin(v276) + 0.35
			for _, v278 in { 1, -1 } do
				local v279 = v278 == 1 and 0 or 3.141592653589793
				for v280 = 1, v273 do
					local v281 = v279 + (v280 - 0.5) / v273 * 3.141592653589793
					local v282 = math.cos(v281) * v272
					local v283 = math.sin(v281) * v272
					local v284 = Vector3.new(v282, 0.75, v283)
					local v285 = -math.sin(v281)
					local v286 = math.cos(v281)
					local v287 = Vector3.new(v285, 0, v286)
					local v288 = Vector3.new(1.1, 1.5, v277)
					local v289
					if v270 == 2 then
						local v290 = {
							["shape"] = nil,
							["material"] = nil,
							["material"] = v_u_18
						}
						v289 = v_u_5.part(v288, CFrame.identity, v_u_8, v290)
					else
						local v291 = {
							["shape"] = nil,
							["material"] = nil,
							["material"] = v_u_17
						}
						v289 = v_u_5.part(v288, CFrame.identity, v_u_9, v291)
						v289.Reflectance = 0.15
					end
					v269(v289, v270, v278, CFrame.lookAt(v284, v284 + v287))
				end
				for v292 = 1, v274 do
					local v293 = v279 + (v292 - 0.5 + (v278 == 1 and 0 or 0.5)) / (v274 + 0.5) * 3.141592653589793
					local v294 = math.cos(v293)
					local v295 = math.sin(v293)
					local v296 = Vector3.new(v294, 0, v295)
					local v297 = -math.sin(v293)
					local v298 = math.cos(v293)
					local v299 = Vector3.new(v297, 0, v298)
					local v300 = (Vector3.new(0, 0.9553365, 0) - v296 * 0.29552020666133955).Unit
					local v301 = v296 * (v272 - 0.55) + Vector3.new(0, 1.5, 0) + v300 * 1.2
					v269(v_u_5.part(Vector3.new(0.5, 2.6, 0.9), CFrame.identity, v_u_11, {
						["shape"] = Enum.PartType.Wedge
					}), v270, v278, CFrame.fromMatrix(v301, v299, v300))
				end
			end
		end
		local v302 = {
			["shape"] = v_u_16,
			["material"] = v_u_17
		}
		local v303 = v_u_5.part(Vector3.new(5, 2.6, 2.6), CFrame.identity, v_u_9, v302)
		v303.Reflectance = 0.15
		v269(v303, 0, 0, CFrame.new(0, 2.5, 0) * v_u_19)
		local v304 = {
			["shape"] = v_u_15,
			["material"] = v_u_18
		}
		v269(v_u_5.part(Vector3.new(3, 3, 3), CFrame.identity, v_u_8, v304), 0, 0, CFrame.new(0, 5, 0))
		if not v258 then
			local v305 = {
				["shape"] = nil,
				["transparency"] = 0.2,
				["shape"] = v_u_16
			}
			v269(v_u_5.part(Vector3.new(0.4, 3.6, 3.6), CFrame.identity, v_u_11, v305), 0, 0, CFrame.new(0, 3.8, 0) * v_u_19)
			local v306 = v259 * v_u_248[3]
			for v307 = 0, 2 do
				local v308 = v307 * 3.141592653589793 * 2 / 3
				local v309 = math.cos(v308)
				local v310 = math.sin(v308)
				local v311 = Vector3.new(v309, 0, v310)
				local v312 = v311 * (v306 + 1.3) / 2 + Vector3.new(0, 0.35, 0)
				local v313 = v306 - 1.3
				local v314 = Vector3.new(0.9, 0.7, v313)
				local v315 = {
					["shape"] = nil,
					["material"] = nil,
					["material"] = v_u_17
				}
				local v316 = v_u_5.part(v314, CFrame.identity, v_u_9, v315)
				v316.Reflectance = 0.15
				v269(v316, 3, 0, CFrame.lookAt(v312, v312 + v311))
				local v317 = {
					["shape"] = v_u_15,
					["material"] = v_u_17
				}
				v269(v_u_5.part(Vector3.new(1.3, 1.3, 1.3), CFrame.identity, v_u_10, v317), 3, 0, CFrame.new(v311 * (v306 * 0.6) + Vector3.new(0, 0.8, 0)))
			end
		end
		local v318 = p_u_57.ground(p_u_256, v259 * 0.85 + 4)
		local v319 = v_u_32(CFrame.new(v318), v259 * 0.8, v_u_7.GearCircle, v_u_8, 1)
		v_u_1:AddItem(v319, p_u_257)
		local v320 = v_u_260.sky
		table.insert(v320, v319)
		if not v258 then
			local v321 = v_u_32(CFrame.new(v318), v259 * 0.5, v_u_7.GearCircle, v_u_11, 1)
			v_u_1:AddItem(v321, p_u_257)
			local v322 = v_u_260.sky
			table.insert(v322, v321)
		end
		return v_u_260
	end
	local function v_u_371(p324, p325) -- name: trapStep
		-- upvalues: (copy) p_u_57, (copy) v_u_253, (ref) v_u_4, (ref) v_u_36
		if p324.done then
			return false
		end
		local v326 = os.clock()
		local v327 = v326 - p324.born
		local v328 = p_u_57.ground(p325, 0)
		local v329 = v327 / 0.3
		local v330 = math.clamp(v329, 0, 1)
		local v331 = v330 - 1
		local v332 = (1 - (v331 * 2.9 * v331 * v331 + 1 + v331 * 1.9 * v331)) * -2.6
		local v333 = CFrame.new(v328 + Vector3.new(0, 1, 0) * v332)
		local v334 = p324.closeAt
		local v335
		if v334 then
			local v336 = (v326 - v334) / 0.1
			v335 = math.clamp(v336, 0, 1)
		else
			v335 = 0
		end
		local v337 = {}
		local v338 = {}
		for v339 = 1, 3 do
			if not v334 then
				local v340 = p324.yaw
				local v341 = (v339 - 1) * 0.45
				local v342 = v327 * 3
				local v343 = math.floor(v342)
				local v344 = (v327 * 3 - v343) / 0.3
				local v345 = 1 - (1 - math.min(v344, 1)) ^ 3
				v340[v339] = v341 + v_u_253[v339] * 0.2 * (v343 + v345)
			end
			local v346 = v333 * CFrame.Angles(0, p324.yaw[v339], 0)
			v337[v339] = v346
			local v347 = (v326 - p324.chompAt[v339]) / 0.26
			local v348
			if v347 >= 0 and v347 < 1 then
				local v349 = 3.141592653589793 * v347
				v348 = math.sin(v349) * 0.6
			else
				v348 = 0
			end
			local v350 = 1.5707963267948966 * v335 * v335
			local v351 = math.max(v348, v350)
			v338[v339] = {
				[1] = v346 * CFrame.new(0, 0, 0.5) * CFrame.Angles(-v351, 0, 0),
				[-1] = v346 * CFrame.new(0, 0, -0.5) * CFrame.Angles(v351, 0, 0)
			}
		end
		local v352 = p324.cfs
		for v353, v354 in p324.offs do
			local v355 = p324.ringOf[v353]
			local v356 = p324.halfOf[v353]
			local v357
			if v355 == 0 then
				v357 = v333
			elseif v356 == 0 then
				v357 = v337[v355]
			else
				v357 = v338[v355][v356]
			end
			v352[v353] = v357 * v354
		end
		if #p324.parts > 0 then
			v_u_4:BulkMoveTo(p324.parts, v352, Enum.BulkMoveMode.FireCFrameChanged)
		end
		local v358 = p324.r
		local v359 = v_u_4.CurrentCamera
		local v360 = not v359 and Vector3.new(0, 0, 1) or (v359.CFrame.Position - v328).Unit
		for v361, v362 in p324.sky do
			local v363 = (v328 + Vector3.new(0, 1, 0) * (v358 * 0.85 + 4)):Lerp(v328 + Vector3.new(0, 3, 0), v335)
			local v364
			if v361 == 1 then
				v364 = v358 * 0.8
			else
				v364 = v358 * 0.5
			end
			local v365 = v330 - 1
			local v366 = v364 * ((v365 * 2.9 * v365 * v365 + 1 + v365 * 1.9 * v365) * 0.6 + 0.4) * (1 - v335 * 0.6)
			local v367 = v366 * 2
			local v368 = v366 * 2
			v362.Size = Vector3.new(v367, 0.05, v368)
			v362.CFrame = p_u_57.facing(v363, v360) * CFrame.Angles(0, v327 * (v361 == 1 and 0.9 or -1.6), 0)
			local v369 = v_u_36
			local v370
			if v361 == 1 then
				v370 = (1 - v330) * 0.9 + 0.1
			else
				v370 = (1 - v330) * 0.7 + 0.3
			end
			v369(v362, v370)
		end
		return v327 < p324.life
	end
	local v425 = {
		["iron_mandala_a"] = {
			["cast"] = function(p372) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_11, (copy) p_u_57, (ref) v_u_14, (copy) v_u_74, (ref) v_u_7, (ref) v_u_8, (ref) v_u_12
				local v373 = p372.size
				local v374 = p372.eye + p372.dir * 1.2
				v_u_5.flash(v374, v_u_11, 3 * v373, 0.12)
				p_u_57.pop(v374, v_u_14, 1.2 * v373, 0.3 * v373, 0.1)
				if not p372.lite then
					v_u_74(p_u_57.facing(v374, p372.dir), 0.6 * v373, 2.4 * v373, v_u_7.GearCircle, v_u_8, 0.14, 12, 0.1)
					p_u_57.spikes(v374, v_u_12, 3, 2.6 * v373, 0.12, p372.dir, 0.5)
				end
			end,
			["shot"] = v141,
			["impact"] = v152,
			["hit"] = function(p375, p376, _) -- name: hit
				-- upvalues: (copy) p_u_57, (ref) v_u_12
				p_u_57.burst("Impact", p376, v_u_12, 0.6)
				if not p375.lite then
					p_u_57.spikes(p376, v_u_12, 2, 2.5, 0.12)
				end
			end
		},
		["iron_mandala_e"] = {
			["cast"] = function(p377) -- name: cast
				-- upvalues: (copy) p_u_57, (ref) v_u_8, (copy) v_u_74, (ref) v_u_7, (ref) v_u_11
				p_u_57.skillCast(p377, v_u_8)
				if not p377.lite then
					v_u_74(p_u_57.facing(p377.eye, p377.dir), 1, 4, v_u_7.GearCircle, v_u_11, 0.2, 8, 0.1)
				end
			end,
			["windup"] = function(p_u_378, p_u_379, p380) -- name: windup
				-- upvalues: (copy) v_u_222, (copy) v_u_223, (copy) p_u_57, (copy) v_u_247, (ref) v_u_8, (ref) v_u_7, (ref) v_u_10
				local v381 = p_u_378.ability.radius * p_u_378.size
				local v382 = p380 + 0.5 + 0.45 + 2
				local v383 = os.clock()
				local v_u_384 = {
					["body"] = nil,
					["born"] = nil,
					["landAt"] = nil,
					["done"] = false,
					["body"] = v_u_222(p_u_378.lite, v382),
					["born"] = v383,
					["landAt"] = v383 + math.max(p380, 0)
				}
				v_u_223[p_u_378] = v_u_384
				p_u_57.runNow(function()
					-- upvalues: (ref) v_u_247, (copy) p_u_378, (copy) v_u_384, (copy) p_u_379
					return v_u_247(p_u_378, v_u_384, p_u_379)
				end)
				p_u_57.sigil(CFrame.new(p_u_57.ground(p_u_379, 0.12)), v381 * 0.8, v_u_8, v_u_7.GearCircle, p380 + 0.6, 1.4)
				p_u_57.mark(p_u_379, v_u_10, v381 * 0.55, p380 + 0.3, v_u_7.Glow, 0.3)
			end,
			["land"] = function(p385, p_u_386) -- name: land
				-- upvalues: (copy) p_u_57, (ref) v_u_5, (ref) v_u_11, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (copy) v_u_84, (ref) v_u_14, (ref) v_u_12, (ref) v_u_9, (ref) v_u_6
				local v_u_387 = p385.ability.radius * p385.size
				local v388 = p385.lite
				local v_u_389 = p_u_57.ground(p_u_386)
				v_u_5.flash(p_u_57.ground(p_u_386, 2), v_u_11, v_u_387 * 0.8, 0.12)
				p_u_57.mark(p_u_386, v_u_10, v_u_387 * 0.7, 2.2, v_u_7.CrackGlow, 0.05)
				p_u_57.mark(p_u_386, v_u_8, v_u_387 * 0.6, 1.8, v_u_7.CrackLines, 0.2)
				p_u_57.burst("Shockwave", v_u_389 + Vector3.new(0, 0.3, 0), v_u_8, v_u_387 / 14)
				v_u_5.ring(v_u_389, v_u_11, v_u_387 * 1.1, 0.4, v_u_7.Shockwave)
				p_u_57.after(0.05, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_389, (ref) v_u_8, (copy) v_u_387, (ref) v_u_7
					v_u_5.ring(v_u_389, v_u_8, v_u_387 * 1.3, 0.5, v_u_7.Ring)
				end)
				v_u_84(p_u_57.ground(p_u_386, 1.2), v388 and 2 or 4, 7.5, 1.4)
				p_u_57.pop(p_u_57.ground(p_u_386, 1), v_u_14, v_u_387 * 0.6, v_u_387 * 1.7, 0.5, 0.55)
				p_u_57.spikes(p_u_57.ground(p_u_386, 1), v_u_14, v388 and 4 or 10, v_u_387 * 0.9, 0.35, nil, nil, true)
				p_u_57.spikes(p_u_57.ground(p_u_386, 1), v_u_12, v388 and 3 or 6, v_u_387 * 0.6, 0.25, nil, nil, true)
				p_u_57.chunks(p_u_57.ground(p_u_386, 1), { p_u_57.EARTH[1], p_u_57.EARTH[2], v_u_9 }, v388 and 5 or 12, 45, 1.2, 1.2, false, 1)
				if not v388 then
					p_u_57.after(0.25, function()
						-- upvalues: (ref) v_u_84, (ref) p_u_57, (copy) p_u_386
						v_u_84(p_u_57.ground(p_u_386, 1), 2, 7, 1)
					end)
				end
				v_u_6.play("Crit", {
					["at"] = v_u_389,
					["volume"] = p385.mine and 1 or 0.6
				})
				if p385.mine then
					v_u_5.shake(0.45, 0.35)
				end
			end,
			["hit"] = function(p390, p391, _) -- name: hit
				-- upvalues: (copy) p_u_57, (ref) v_u_8, (ref) v_u_12
				p_u_57.burst("Impact", p391, v_u_8, 0.8)
				if not p390.lite then
					p_u_57.spikes(p391, v_u_12, 2, 2.5, 0.14)
				end
			end
		},
		["iron_mandala_r"] = {
			["castSound"] = "Charge",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p392) -- name: cast
				-- upvalues: (copy) p_u_57, (ref) v_u_8
				p_u_57.skillCast(p392, v_u_8, true)
			end,
			["windup"] = function(p393, p394, p395) -- name: windup
				-- upvalues: (copy) v_u_74, (copy) p_u_57, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_12
				local v396 = p393.ability.radius * p393.size
				local v397 = math.max(p395, 0.06)
				v_u_74(CFrame.new(p_u_57.ground(p394, 0.12)), v396 * 1.15, v396 * 0.95, v_u_7.Ring, v_u_11, v397 + 0.15, 2, 0.2)
				p_u_57.mark(p394, v_u_9, v396, v397 + 3, v_u_7.CrackLines, 0.35)
				if not p393.lite then
					p_u_57.spikes(p_u_57.ground(p394, 0.5), v_u_12, 6, v396 * 0.5, 0.25, Vector3.new(0, 1, 0), 0.8)
				end
			end,
			["zone"] = function(p_u_398, p_u_399, p400) -- name: zone
				-- upvalues: (copy) v_u_323, (copy) v_u_254, (copy) p_u_57, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_9, (copy) v_u_371, (copy) v_u_248, (ref) v_u_12, (ref) v_u_6, (ref) v_u_11
				local v_u_401 = p_u_398.lite
				local v_u_402 = v_u_323(p_u_398, p_u_399, p400 + 3)
				v_u_254[p_u_398] = v_u_402
				local v_u_403 = v_u_402.r
				local v_u_404 = p_u_57.ground(p_u_399)
				p_u_57.burst("Shockwave", v_u_404 + Vector3.new(0, 0.3, 0), v_u_8, v_u_403 / 14)
				v_u_5.ring(v_u_404, v_u_8, v_u_403 * 1.2, 0.4, v_u_7.Shockwave)
				p_u_57.chunks(p_u_57.ground(p_u_399, 1), { p_u_57.EARTH[1], p_u_57.EARTH[2], v_u_9 }, v_u_401 and 4 or 10, 30, 1, 1)
				p_u_57.runNow(function()
					-- upvalues: (ref) v_u_371, (copy) v_u_402, (copy) p_u_399
					return v_u_371(v_u_402, p_u_399)
				end)
				local v_u_405 = p_u_398.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (copy) v_u_402, (copy) v_u_401, (copy) v_u_403, (ref) v_u_248, (ref) p_u_57, (copy) v_u_404, (ref) v_u_12, (ref) v_u_6, (copy) p_u_398, (copy) p_u_399, (ref) v_u_11, (copy) v_u_405
					task.wait(0.12)
					local v406 = 0
					while not (v_u_402.done or v_u_402.closeAt) do
						local v407 = v406 % 3 + 1
						v406 = v_u_401 and v407 == 3 and 1 or v407
						v_u_402.chompAt[v406] = os.clock()
						local v_u_408 = v_u_403 * v_u_248[v406]
						p_u_57.after(0.13, function()
							-- upvalues: (ref) v_u_401, (ref) v_u_404, (copy) v_u_408, (ref) p_u_57, (ref) v_u_12, (ref) v_u_6, (ref) p_u_398
							for _ = 1, v_u_401 and 1 or 3 do
								local v409 = math.random() * 3.141592653589793 * 2
								local v410 = v_u_404
								local v411 = math.cos(v409) * v_u_408
								local v412 = math.sin(v409) * v_u_408
								local v413 = v410 + Vector3.new(v411, 1.5, v412)
								p_u_57.spikes(v413, v_u_12, 3, 4, 0.2, Vector3.new(0, 1, 0), 0.9)
							end
							v_u_6.play("EyeActivate", {
								["at"] = nil,
								["volume"] = nil,
								["pitch"] = 0.55,
								["at"] = v_u_404,
								["volume"] = p_u_398.mine and 0.5 or 0.3
							})
						end)
						if not v_u_401 then
							p_u_57.inward(p_u_57.ground(p_u_399, 1.2), v_u_11, 6, v_u_403, 0.3)
						end
						task.wait(v_u_405)
					end
				end)
				return function()
					-- upvalues: (copy) v_u_402
					v_u_402.closeAt = os.clock()
				end
			end,
			["finish"] = function(p414, p415) -- name: finish
				-- upvalues: (copy) p_u_57, (ref) v_u_5, (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (ref) v_u_12, (ref) v_u_14, (copy) v_u_84, (ref) v_u_10, (ref) v_u_9, (copy) v_u_254, (copy) v_u_105, (ref) v_u_6, (ref) v_u_2, (ref) v_u_1
				local v_u_416 = p414.ability.radius * p414.size
				local v417 = p414.lite
				local v_u_418 = p_u_57.ground(p415)
				local v419 = p_u_57.ground(p415, 3)
				v_u_5.flash(v419, v_u_11, v_u_416 * 1.3, 0.15)
				p_u_57.burst("Explosion", v419, v_u_8, v_u_416 / 6)
				p_u_57.burst("Shockwave", v_u_418 + Vector3.new(0, 0.3, 0), v_u_8, v_u_416 / 14)
				v_u_5.ring(v_u_418, v_u_11, v_u_416 * 1.3, 0.5, v_u_7.Shockwave)
				p_u_57.after(0.06, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_418, (ref) v_u_8, (copy) v_u_416, (ref) v_u_7
					v_u_5.ring(v_u_418, v_u_8, v_u_416 * 1.5, 0.45, v_u_7.Ring)
				end)
				p_u_57.spikes(v419, v_u_12, v417 and 6 or 16, v_u_416 * 1.2, 0.35)
				p_u_57.pop(p_u_57.ground(p415, 1), v_u_14, v_u_416 * 0.5, v_u_416 * 1.8, 0.55, 0.55)
				v_u_84(p_u_57.ground(p415, 1.5), v417 and 1 or 3, v_u_416 * 0.4, 2)
				p_u_57.mark(p415, v_u_10, v_u_416 * 0.8, 2.5, v_u_7.CrackGlow, 0.05)
				p_u_57.mark(p415, v_u_8, v_u_416 * 0.7, 2, v_u_7.CrackLines, 0.15)
				p_u_57.chunks(p_u_57.ground(p415, 1), {
					v_u_9,
					v_u_8,
					v_u_10,
					v_u_12
				}, v417 and 6 or 14, 50, 1.2, 1.2, false, 1.1)
				local v420 = v_u_254[p414]
				if v420 and not v420.done then
					if not v420.done then
						v420.done = true
						for _, v421 in v420.sky do
							v421:Destroy()
						end
					end
					v_u_105(v420.parts, v_u_418, 34, 0.8)
				end
				v_u_6.play("Explosion", {
					["at"] = v_u_418,
					["volume"] = p414.mine and 0.9 or 0.5
				})
				v_u_6.play("Crit", {
					["at"] = v_u_418,
					["volume"] = p414.mine and 0.8 or 0.4
				})
				if p414.mine then
					v_u_5.shake(0.6, 0.5)
					local v_u_422 = Instance.new("ColorCorrectionEffect")
					v_u_422.Name = "MandalaCrusher"
					v_u_422.Parent = v_u_2
					v_u_5.tween(v_u_422, 0.04, {
						["Contrast"] = 0.3,
						["Brightness"] = 0.08,
						["Saturation"] = -0.4
					})
					p_u_57.after(0.1, function()
						-- upvalues: (ref) v_u_5, (copy) v_u_422
						v_u_5.tween(v_u_422, 0.4, {
							["Contrast"] = 0,
							["Brightness"] = 0,
							["Saturation"] = 0
						})
					end)
					v_u_1:AddItem(v_u_422, 0.6)
				end
			end,
			["hit"] = function(p423, p424, _) -- name: hit
				-- upvalues: (copy) p_u_57, (ref) v_u_11, (ref) v_u_12
				p_u_57.burst("Impact", p424, v_u_11, 0.8)
				if not p423.lite then
					p_u_57.spikes(p424, v_u_12, 3, 3, 0.15)
				end
			end
		}
	}
	return v425
end