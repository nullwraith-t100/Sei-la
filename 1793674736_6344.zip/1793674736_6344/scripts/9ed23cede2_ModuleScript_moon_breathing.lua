local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Mythic8)
local v_u_6 = require(script.Parent.Parent.Parent.Perf)
local v_u_7 = require(script.Parent.Parent.Preload)
local v_u_8 = require(v2.Shared.Config.Textures)
local v_u_9 = Color3.fromHex("FFD23D")
local v_u_10 = Color3.fromHex("8A0F2A")
local v_u_11 = Color3.fromRGB(230, 40, 70)
local v_u_12 = Color3.fromRGB(26, 6, 12)
local v_u_13 = Enum.Material.SmoothPlastic
local v_u_14 = Enum.Material.Neon
local v_u_15 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_24(p16, p17, p18) -- name: moonBoard
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v19 = Instance.new("BillboardGui")
	v19.Size = UDim2.fromScale(p17, p17)
	v19.LightInfluence = 0
	v19.Brightness = 1.6
	v19.AlwaysOnTop = false
	v19.ResetOnSpawn = false
	v19.Parent = p16
	local v20 = Instance.new("ImageLabel")
	v20.BackgroundTransparency = 1
	v20.Size = UDim2.fromScale(1, 1)
	v20.Image = v_u_8.MoonCrescents
	v20.ImageRectSize = Vector2.new(256, 256)
	local v21 = Vector2.new
	local v22 = p18 % 2 * 256
	local v23 = p18 / 2
	v20.ImageRectOffset = v21(v22, math.floor(v23) * 256)
	v20.ImageColor3 = v_u_9
	v20.Parent = v19
	return v19, v20
end
return function(p_u_25)
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_1, (copy) v_u_5, (copy) v_u_9, (copy) v_u_6, (copy) v_u_11, (copy) v_u_4, (copy) v_u_15, (copy) v_u_10, (copy) v_u_13, (copy) v_u_14, (copy) v_u_12, (copy) v_u_3, (copy) v_u_24
	return {
		["w8_moon_breathing"] = function(p_u_26, _)
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_1, (copy) p_u_25, (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_11, (ref) v_u_4, (ref) v_u_15, (ref) v_u_10, (ref) v_u_13, (ref) v_u_14, (ref) v_u_12, (ref) v_u_3, (ref) v_u_24
			v_u_7.images({ v_u_8.MoonCrescents, v_u_8.MoonSeal, v_u_8.MoonArc })
			local v27 = p_u_26.headY / 1.5
			local v_u_28 = math.clamp(v27, 0.7, 3)
			local v_u_29 = p_u_26.fx
			local v30 = p_u_26.character == v_u_1.LocalPlayer.Character
			local v_u_31 = p_u_25.backOf(p_u_26)
			local function v_u_32()
				-- upvalues: (copy) p_u_26
				return p_u_26.root.Position + Vector3.new(0, 1, 0) * p_u_26.headY
			end
			local v_u_36 = p_u_25.throb(p_u_26, 5, 2.2, 1.1, function(p33)
				-- upvalues: (copy) v_u_28, (ref) v_u_5, (copy) v_u_29, (ref) v_u_8, (ref) v_u_9, (ref) v_u_6, (ref) v_u_11, (ref) v_u_4, (ref) v_u_32
				local v34 = p33.Position + Vector3.new(0, 0.2, 0) * v_u_28
				for v35 = 1, 2 do
					v_u_5.planePic(CFrame.new(v34 + Vector3.new(0, 1, 0) * (v35 - 1.5) * 0.5 * v_u_28) * CFrame.Angles(0, math.random() * 6.3, 0), v_u_28 * 2, (v35 == 1 and 10 or 8) * v_u_28 * v_u_29, v_u_8.MoonArc, v_u_9, 0, 0.14, 0.12, 0.35, v35 == 1 and 3 or -3, 0.25)
				end
				if v_u_6.level() > 1 then
					v_u_5.spray(v34, v_u_8.MoonCrescents, 12, v_u_28 * 0.7, v_u_28 * 14, 0.8, v_u_9, {
						["layout"] = nil,
						["mode"] = nil,
						["color2"] = nil,
						["spin"] = 200,
						["layout"] = Enum.ParticleFlipbookLayout.Grid2x2,
						["mode"] = Enum.ParticleFlipbookMode.Random,
						["color2"] = v_u_11
					})
				end
				v_u_4.flash(v_u_32(), v_u_9, v_u_28 * 2.6 * v_u_29, 0.2)
			end)
			local v_u_43 = p_u_25.group(p_u_26, function(p37, p38)
				-- upvalues: (copy) v_u_31, (copy) v_u_28
				local v39 = p37 * v_u_31
				local v40 = CFrame.new
				local v41 = v_u_28 * 0.1
				local v42 = p38 * 1.2
				return v39 * v40(0, v41 + math.sin(v42) * 0.04 * v_u_28, v_u_28 * 0.5)
			end)
			local v44 = v_u_5.piece("w8_moon_breathing", v_u_28 * 4.4, 4)
			if v44 then
				p_u_25.pin(p_u_26, v_u_43, v44, v_u_15)
				v_u_32 = function()
					-- upvalues: (copy) v_u_43, (copy) v_u_28
					return (v_u_43.cf * CFrame.new(v_u_28 * 1.7, v_u_28 * 1.2, 0)).Position
				end
			else
				local v_u_45 = Vector3.new(1.05, 1.15, 0) * v_u_28
				local v46 = {}
				for v47 = 0, 4 do
					local v48 = v47 / 4
					local v49 = 1.05 - v48 * 2.35
					local v50 = 1.15 - v48 * 2.55
					local v51 = v48 * 3.141592653589793
					local v52 = v50 + math.sin(v51) * 0.35
					local v53 = Vector3.new(v49, v52, 0) * v_u_28
					table.insert(v46, v53)
				end
				for v54 = 1, 4 do
					local v55 = v46[v54]
					local v56 = v46[v54 + 1]
					local v57, v58 = p_u_25.between(v55, v56)
					local v59 = (0.34 - v54 * 0.03) * v_u_28
					local v60 = p_u_25.pin
					local v61 = p_u_25.bar
					local v62 = v_u_28 * 0.07
					local v63 = v58 + v_u_28 * 0.06
					v60(p_u_26, v_u_43, v61(Vector3.new(v62, v59, v63), v_u_10, 0, v_u_13), v57)
					local v64 = p_u_25.pin
					local v65 = p_u_25.bar
					local v66 = v_u_28 * 0.09
					local v67 = v_u_28 * 0.06
					local v68 = v58 + v_u_28 * 0.04
					v64(p_u_26, v_u_43, v65(Vector3.new(v66, v67, v68), v_u_9, 0, v_u_14), v57 * CFrame.new(0, v59 * 0.5, 0))
					local v69 = (v55 + v56) / 2
					p_u_25.pin(p_u_26, v_u_43, p_u_25.ball(v_u_28 * 0.24, v_u_9, 0, v_u_14), CFrame.new(v69) * CFrame.new(0, 0, v_u_28 * 0.05))
					local v70 = p_u_25.pin
					local v71 = p_u_25.bar
					local v72 = v_u_28 * 0.05
					local v73 = v_u_28 * 0.17
					local v74 = v_u_28 * 0.06
					v70(p_u_26, v_u_43, v71(Vector3.new(v72, v73, v74), v_u_12, 0, v_u_13), CFrame.new(v69) * CFrame.new(0, 0, v_u_28 * 0.14))
				end
				local v75 = v46[5]
				local v76 = (v46[5] - v46[4]).Unit
				local v77 = v_u_5.blade(v_u_10, v_u_13)
				local v78 = CFrame.lookAt(v75, v75 + v76, (Vector3.new(0, 0, 1)):Cross(v76))
				v_u_5.placeBlade(v77, v78, v_u_28 * 0.75, v_u_28 * 0.24, v_u_28 * 0.07)
				for _, v79 in v77 do
					p_u_25.pin(p_u_26, v_u_43, v79, v79.CFrame)
				end
				p_u_25.pin(p_u_26, v_u_43, p_u_25.blob(Vector3.new(0.55, 0.55, 0.16) * v_u_28, v_u_9, 0, v_u_14), CFrame.new(v_u_45))
				local v80 = v_u_45 + Vector3.new(0.5, 0.55, 0) * v_u_28
				local v81, v82 = p_u_25.between(v_u_45, v80)
				local v83 = p_u_25.pin
				local v84 = p_u_25.bar
				local v85 = v_u_28 * 0.14
				local v86 = v_u_28 * 0.14
				v83(p_u_26, v_u_43, v84(Vector3.new(v85, v86, v82), v_u_12, 0, v_u_13), v81)
				v_u_32 = function()
					-- upvalues: (copy) v_u_43, (copy) v_u_45
					return (v_u_43.cf * CFrame.new(v_u_45)).Position
				end
			end
			local v_u_87 = {}
			for v88 = 1, 6 do
				local v89 = Instance.new("Attachment")
				v89.Parent = v_u_3.Terrain
				local _, v90 = v_u_24(v89, (v30 and 1.05 or 1.25) * v_u_28 * v_u_29, (v88 - 1) % 4)
				p_u_25.own(p_u_26, v89)
				table.insert(v_u_87, {
					["at"] = v89,
					["img"] = v90
				})
			end
			local v91 = p_u_26.ticks
			table.insert(v91, function(p92, p93)
				-- upvalues: (copy) v_u_36, (copy) v_u_87, (copy) v_u_28
				local v94 = v_u_36()
				for v95, v96 in v_u_87 do
					local v97 = p93 * 0.7 + v95 * 3.141592653589793 * 2 / 6
					local v98 = (1.9 + 1.4 * v94) * v_u_28
					local v99 = v96.at
					local v100 = math.cos(v97) * v98
					local v101 = p93 * 1.6 + v95
					local v102 = (math.sin(v101) * 0.25 + 0.45) * v_u_28
					local v103 = math.sin(v97) * v98 * 0.8
					v99.WorldPosition = p92 * Vector3.new(v100, v102, v103)
					v96.img.Rotation = (p93 * (40 + 300 * v94) + v95 * 60) % 360
				end
			end)
			local v104 = p_u_26.stops
			table.insert(v104, function()
				-- upvalues: (copy) v_u_87
				for _, v105 in v_u_87 do
					v105.at:Destroy()
				end
			end)
			local v106 = Instance.new("Part")
			local v107 = v_u_28 * 2.6
			local v108 = v_u_28 * 3.4
			local v109 = v_u_28 * 1.6
			v106.Size = Vector3.new(v107, v108, v109)
			v106.Transparency = 1
			v106.Anchored = true
			v106.CanCollide = false
			v106.CanQuery = false
			v106.CanTouch = false
			v106.CastShadow = false
			v106.Parent = v_u_4.folder()
			p_u_25.add(p_u_26, v106, function(p110)
				-- upvalues: (copy) v_u_28
				return p110 * CFrame.new(0, v_u_28 * 0.2, 0)
			end)
			p_u_25.own(p_u_26, v106)
			local v_u_111 = Instance.new("ParticleEmitter")
			v_u_111.Texture = v_u_8.MoonCrescents
			v_u_111.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v_u_111.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_111.Color = ColorSequence.new(v_u_9, v_u_11)
			v_u_111.LightEmission = 0.35
			v_u_111.LightInfluence = 0
			v_u_111.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, v_u_28 * 0.22 * v_u_29), NumberSequenceKeypoint.new(1, v_u_28 * 0.1 * v_u_29) })
			v_u_111.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
			v_u_111.Lifetime = NumberRange.new(0.9, 1.5)
			v_u_111.Speed = NumberRange.new(0.8, 2)
			v_u_111.SpreadAngle = Vector2.new(180, 180)
			v_u_111.Drag = 1
			v_u_111.Rotation = NumberRange.new(0, 360)
			v_u_111.RotSpeed = NumberRange.new(-120, 120)
			v_u_111.Shape = Enum.ParticleEmitterShape.Box
			v_u_111.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_111:SetAttribute("BaseRate", 3 * v_u_29)
			v_u_111.Rate = 3 * v_u_29 * v_u_6.formRate()
			v_u_111.Parent = v106
			local v112 = p_u_26.stops
			table.insert(v112, function()
				-- upvalues: (copy) v_u_111
				v_u_111.Enabled = false
			end)
			local v113 = p_u_25.picture(v_u_28 * 5.6, v_u_8.Glow, v_u_10, 0.3)
			p_u_25.add(p_u_26, v113, function(p114)
				-- upvalues: (ref) p_u_25, (copy) p_u_26
				return CFrame.new(p_u_25.feetAt(p_u_26, p114, 0.05))
			end)
			local v115 = v_u_5.card(v_u_28 * 6.8, v_u_8.MoonSeal, v_u_9, 0.05, 1.5)
			p_u_25.add(p_u_26, v115, function(p116, p117)
				-- upvalues: (ref) p_u_25, (copy) p_u_26
				return CFrame.new(p_u_25.feetAt(p_u_26, p116, 0.09)) * CFrame.Angles(0, -p117 * 0.25, 0)
			end)
		end
	}
end