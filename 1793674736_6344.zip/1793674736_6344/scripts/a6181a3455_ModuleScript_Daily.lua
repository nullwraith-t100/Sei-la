local v1 = require(script.Parent.Parent.Logic.Prizes)
local v_u_3 = {
	["DAYS"] = 7,
	["weeks"] = {
		{
			v1.trophies(2, 10),
			v1.boost("chakra", 5),
			v1.aura("crimson_storm"),
			v1.trophies(6, 30),
			v1.worldEgg(2, 3),
			v1.boost("wins", 15),
			v1.pet("celestial_dragon")
		},
		{
			v1.trophies(3, 15),
			v1.boost("wins", 10),
			v1.aura("emerald_storm"),
			v1.trophies(5, 25),
			v1.worldEgg(2, 3),
			v1.boost("chakra", 10),
			v1.pet("sunfire_phoenix")
		},
		{
			v1.trophies(2, 10),
			v1.boost("chakra", 10),
			v1.aura("violet_storm"),
			v1.trophies(6, 30),
			v1.worldEgg(2, 3),
			v1.boost("wins", 10),
			v1.pet("storm_tiger")
		},
		{
			v1.trophies(3, 15),
			v1.boost("wins", 15),
			v1.aura("shadow_storm"),
			v1.trophies(5, 25),
			v1.worldEgg(2, 3),
			v1.boost("chakra", 5),
			v1.pet("shadow_pegasus")
		}
	},
	["week"] = function(p2) -- name: week
		-- upvalues: (copy) v_u_3
		return v_u_3.weeks[math.max(0, p2) % #v_u_3.weeks + 1]
	end
}
return v_u_3