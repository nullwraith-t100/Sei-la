local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_4 = require(script.Parent.Parent.Parent.Sfx)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(255, 111, 158)
local v_u_7 = Color3.fromRGB(255, 227, 236)
local v_u_8 = Color3.fromRGB(225, 50, 115)
local v_u_9 = Color3.fromRGB(255, 214, 120)
local v_u_10 = Color3.fromRGB(255, 255, 255)
local v_u_11 = CFrame.Angles(0.55, 0, 0)
return function(p_u_12)
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_11, (copy) v_u_5, (copy) v_u_4, (copy) v_u_10, (copy) v_u_8
	local function v_u_20(p13, p14, p15, p16, p17) -- name: ellip
		-- upvalues: (ref) v_u_3, (ref) v_u_1
		local v18 = v_u_3.part(p13, p14, p15, {
			["transparency"] = p16,
			["material"] = p17
		})
		local v19 = Instance.new("SpecialMesh")
		v19.MeshType = Enum.MeshType.Sphere
		v19.Parent = v18
		v_u_1:AddItem(v18, 8)
		return v18
	end
	local function v_u_29(p21, p22, p23) -- name: shed
		-- upvalues: (copy) v_u_20, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1
		local v24 = CFrame.Angles(math.random() * 6, math.random() * 6, math.random() * 6)
		local v25 = v_u_20(Vector3.new(0.12, 0.9, 0.45) * p22, CFrame.new(p21) * v24, v_u_6, 0.1)
		local v26 = (math.random() - 0.5) * 3
		local v27 = (math.random() - 0.5) * 3
		local v28 = Vector3.new(v26, -1.5, v27)
		v_u_3.tween(v25, p23, {
			["CFrame"] = nil,
			["Transparency"] = 1,
			["CFrame"] = CFrame.new(p21 + v28) * v24 * CFrame.Angles(2.5, 1.5, 0)
		}, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
		v_u_1:AddItem(v25, p23 + 0.05)
	end
	local function v_u_46(p30, p31, p32, p33) -- name: scatter
		-- upvalues: (copy) v_u_20, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1
		for _ = 1, p31 do
			local v34 = CFrame.Angles(math.random() * 6, math.random() * 6, math.random() * 6)
			local v35 = v_u_20
			local v36 = Vector3.new(0.15, 1.2, 0.6) * p33
			local v37 = CFrame.new(p30) * v34
			local v38
			if math.random() < 0.3 then
				v38 = v_u_7
			else
				v38 = v_u_6
			end
			local v39 = v35(v36, v37, v38, 0)
			local v40 = math.random() * 3.141592653589793 * 2
			local v41 = math.cos(v40)
			local v42 = 0.4 + math.random() * 0.8
			local v43 = math.sin(v40)
			local v44 = Vector3.new(v41, v42, v43)
			local v45 = 0.5 + math.random() * 0.3
			v_u_3.tween(v39, v45, {
				["CFrame"] = nil,
				["Transparency"] = 1,
				["CFrame"] = CFrame.new(p30 + v44 * p32 * v45 - Vector3.new(0, 1.5, 0)) * v34 * CFrame.Angles(3, 2, 0)
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			v_u_1:AddItem(v39, v45 + 0.05)
		end
	end
	local function v_u_73(p47, p48, p49, p_u_50, p_u_51) -- name: flower
		-- upvalues: (copy) p_u_12, (copy) v_u_20, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1
		local v_u_52 = p_u_12.facing(p47, p48)
		for v53 = 1, p49 do
			local v_u_54 = v53 / p49 * 3.141592653589793 * 2
			local function v_u_56(p55) -- name: petalAt
				-- upvalues: (copy) v_u_52, (copy) v_u_54, (copy) p_u_50
				return v_u_52 * CFrame.Angles(0, v_u_54, 0) * CFrame.new(p_u_50 * 0.5 * p55 + 0.3, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
			end
			local v57 = v_u_20
			local v58 = p_u_50 * 0.3
			local v59 = p_u_50 * 0.15
			local v60 = Vector3.new(0.2, v58, v59)
			local v61 = v_u_56(0.3)
			local v62
			if v53 % 2 == 0 then
				v62 = v_u_7
			else
				v62 = v_u_6
			end
			local v_u_63 = v57(v60, v61, v62, 0)
			local v64 = v_u_3.tween
			local v65 = {
				["CFrame"] = v_u_56(1)
			}
			local v66 = p_u_50 * 0.42
			v65.Size = Vector3.new(0.25, p_u_50, v66)
			v64(v_u_63, 0.08, v65)
			p_u_12.after(0.08, function()
				-- upvalues: (copy) v_u_63, (ref) v_u_3, (copy) p_u_51, (copy) v_u_56, (copy) p_u_50
				if v_u_63.Parent then
					local v67 = v_u_3.tween
					local v68 = v_u_63
					local v69 = p_u_51
					local v70 = {
						["CFrame"] = nil,
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = v_u_56(1.4)
					}
					local v71 = p_u_50 * 1.1
					local v72 = p_u_50 * 0.3
					v70.Size = Vector3.new(0.1, v71, v72)
					v67(v68, v69, v70, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
			end)
			v_u_1:AddItem(v_u_63, p_u_51 + 0.15)
		end
	end
	local function v_u_91(p74, p75, p76, p77, p78, p79, p80, p81, p82, p83, p84, p85, p86) -- name: addPetals
		-- upvalues: (copy) v_u_20, (ref) v_u_1
		for v87 = 1, p75 do
			local v88 = Vector3.new(p79, p77, p78)
			local v89 = v_u_20(v88, CFrame.new(0, -50, 0), p80, p81, p86)
			v_u_1:AddItem(v89, p85)
			local v90 = {
				["p"] = v89,
				["a"] = (v87 + p82) / p75 * 3.141592653589793 * 2,
				["ring"] = p76,
				["len"] = p77,
				["size"] = v88,
				["shut"] = p83,
				["open"] = p84
			}
			table.insert(p74, v90)
		end
	end
	local function v_u_109(p92, p93, p94, p95, p96, p97, p98, p99) -- name: placeLotus
		local v100 = p99 and Vector3.new(-0, -1, -0) or Vector3.new(0, 1, 0)
		for v101, v102 in p92 do
			local v103 = v102.a + p96
			local v104 = math.cos(v103)
			local v105 = math.sin(v103)
			local v106 = Vector3.new(v104, 0, v105)
			local v107 = v102.shut + (v102.open - v102.shut) * p94
			v102.p.CFrame = CFrame.fromMatrix(p93 + v106 * v102.ring * p95, v106, v100) * CFrame.Angles(0, 0, -v107) * CFrame.new(0, v102.len * p95 / 2, 0)
			v102.p.Size = v102.size * p95
			local v108 = p98[v101]
			v102.p.Transparency = v108 + (1 - v108) * math.clamp(p97, 0, 1)
		end
	end
	local v_u_110 = {}
	local function v_u_131(p111) -- name: driveLotus
		-- upvalues: (copy) v_u_109
		local v112 = os.clock()
		local v113 = v112 - p111.born
		local v114 = 1
		local v115 = 0
		local v116 = 0
		local v117 = p111.landAt
		local v118
		if v117 then
			local v119 = v112 - v117
			v115 = v119 * 0.35
			if v119 < 0.12 then
				local v120 = v119 / 0.12
				v118 = 1 - v120 * v120
			elseif v119 < p111.freeze then
				local v121 = v119 * 7
				v118 = math.sin(v121) * 0.03
				local v122 = v119 * 9
				v116 = (math.sin(v122) * 0.5 + 0.5) * 0.12
			else
				local v123 = (v119 - p111.freeze) / 0.35
				v116 = math.clamp(v123, 0, 1)
				v118 = v116 * 1.6
				v114 = v116 * 0.25 + 1
				if v116 >= 1 then
					for _, v124 in p111.petals do
						v124.p:Destroy()
					end
					p111.pod:Destroy()
					return false
				end
			end
		else
			local v125 = v113 / p111.bloom
			local v126 = math.clamp(v125, 0, 1)
			local v127 = 1 - (1 - v126) ^ 2
			v118 = v127 * 0.85 + 0.15
			v114 = v127 * 0.7 + 0.3
			local v128 = v126 * 2
			v116 = 1 - math.min(v128, 1)
			if p111.bloom + 1.5 < v113 then
				local v129 = (v113 - p111.bloom - 1.5) / 0.3
				v116 = math.clamp(v129, 0, 1)
				if v116 >= 1 then
					for _, v130 in p111.petals do
						v130.p:Destroy()
					end
					p111.pod:Destroy()
					return false
				end
			end
		end
		v_u_109(p111.petals, p111.base, v118, v114, v115, v116, p111.alphas)
		p111.pod.CFrame = CFrame.new(p111.base + Vector3.new(0, 0.8, 0) * v114) * CFrame.Angles(0, v115, 0)
		p111.pod.Size = Vector3.new(4, 1.6, 4) * v114
		p111.pod.Transparency = math.clamp(v116, 0, 1) * 0.9 + 0.1
		return true
	end
	local function v_u_159(p132, p133, p134) -- name: startLotus
		-- upvalues: (copy) v_u_91, (ref) v_u_6, (ref) v_u_7, (copy) v_u_20, (ref) v_u_9, (ref) v_u_1, (copy) p_u_12, (copy) v_u_131
		local v135 = p132.ability.radius
		local v136 = p132.ability.freeze or 2
		local v137 = p134 + v136 + 2
		local v138 = {}
		local v139 = v135 * 0.5
		local v140 = v135 * 0.82
		local v141 = v_u_91
		local v142 = p132.lite and 6 or 8
		local v143 = v135 * 0.47
		local v144 = v_u_6
		local v145 = v139 / v140
		local v146 = math.min(v145, 0.95)
		v141(v138, v142, v139, v140, v143, 0.9, v144, 0.2, 0, -math.asin(v146) + 0.06, 1.15, v137, Enum.Material.SmoothPlastic)
		if not p132.lite then
			local v147 = v135 * 0.3
			local v148 = v135 * 0.56
			local v149 = v_u_91
			local v150 = v135 * 0.32
			local v151 = v_u_7
			local v152 = v147 / v148
			local v153 = math.min(v152, 0.95)
			v149(v138, 8, v147, v148, v150, 0.7, v151, 0.2, 0.5, -math.asin(v153) + 0.06, 0.85, v137)
		end
		local v154 = {}
		for _, v155 in v138 do
			local v156 = v155.p.Transparency
			table.insert(v154, v156)
		end
		local v157 = v_u_20(Vector3.new(4, 1.6, 4), CFrame.new(p133), v_u_9, 0.1)
		v_u_1:AddItem(v157, v137)
		local v_u_158 = {
			["petals"] = nil,
			["alphas"] = nil,
			["pod"] = nil,
			["base"] = nil,
			["born"] = nil,
			["bloom"] = nil,
			["landAt"] = nil,
			["freeze"] = nil,
			["petals"] = v138,
			["alphas"] = v154,
			["pod"] = v157,
			["base"] = p_u_12.ground(p133, 0),
			["born"] = os.clock(),
			["bloom"] = math.max(p134, 0.06),
			["freeze"] = v136
		}
		p_u_12.runNow(function()
			-- upvalues: (ref) v_u_131, (copy) v_u_158
			return v_u_131(v_u_158)
		end)
		return v_u_158
	end
	local v_u_160 = {}
	local function v_u_179(p161, p162, p_u_163) -- name: bud
		-- upvalues: (copy) v_u_160, (copy) v_u_91, (ref) v_u_6, (copy) p_u_12, (copy) v_u_109
		local v164 = os.clock()
		if v164 >= (v_u_160[p162] or 0) then
			v_u_160[p162] = v164 + p_u_163
			for v165, v166 in v_u_160 do
				if v166 >= v164 then
					continue
				end
				v_u_160[v165] = nil
			end
			local v_u_167 = {}
			v_u_91(v_u_167, 4, 1.4, 4.4, 2.6, 0.35, v_u_6, 0.2, 0, -0.3, 0.9, p_u_163 + 1)
			local v_u_168 = {}
			for _ = 1, #v_u_167 do
				table.insert(v_u_168, 0.2)
			end
			local v169 = p161.X
			local v170 = p_u_12.FLOOR + 0.1
			local v171 = p161.Z
			local v_u_172 = Vector3.new(v169, v170, v171)
			local v_u_173 = os.clock()
			p_u_12.runNow(function()
				-- upvalues: (copy) v_u_173, (copy) p_u_163, (ref) v_u_109, (copy) v_u_167, (copy) v_u_172, (copy) v_u_168
				local v174 = os.clock() - v_u_173
				local v175 = 0
				local v176 = 0
				if v174 < 0.1 then
					v175 = 1 - v174 / 0.1
				elseif p_u_163 < v174 then
					local v177 = (v174 - p_u_163) / 0.3
					v176 = math.clamp(v177, 0, 1)
					v175 = v176 * 1.3
				end
				v_u_109(v_u_167, v_u_172, v175, 1, v174 * 0.8, v176, v_u_168)
				if p_u_163 + 0.3 >= v174 then
					return true
				end
				for _, v178 in v_u_167 do
					v178.p:Destroy()
				end
				return false
			end)
		end
	end
	local function v_u_194(p180, p181) -- name: bladeShot
		-- upvalues: (copy) v_u_20, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1, (copy) p_u_12
		local v182 = p180.size
		local v_u_183 = CFrame.Angles(1.5707963267948966, 0, 0)
		local v184 = v_u_20
		local v185 = Vector3.new(0.35, 4, 1.6) * v182
		local v186 = p181 * v_u_183
		local v187
		if math.random() < 0.3 then
			v187 = v_u_7
		else
			v187 = v_u_6
		end
		local v_u_188 = v184(v185, v186, v187)
		local v_u_189 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p181, v_u_6, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_189, 6)
		p_u_12.streak(v_u_189, v_u_6, v_u_7, 1.2 * v182, 0.12)
		local v_u_190 = false
		return {
			["place"] = function(p191, p192) -- name: place
				-- upvalues: (copy) v_u_189, (copy) v_u_188, (copy) v_u_183
				v_u_189.CFrame = p191
				v_u_188.CFrame = p191 * CFrame.Angles(0, 0, p192 * 30) * v_u_183
			end,
			["stop"] = function(p193) -- name: stop
				-- upvalues: (ref) v_u_190, (ref) v_u_1, (copy) v_u_189, (ref) p_u_12, (copy) v_u_188
				if v_u_190 then
					return
				else
					v_u_190 = true
					v_u_1:AddItem(v_u_189, 0.15)
					if p193 then
						p_u_12.fadeOut(v_u_188, p193)
					else
						v_u_188:Destroy()
					end
				end
			end
		}
	end
	local v301 = {
		["lotus_eye_a"] = {
			["cast"] = function(p195) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (copy) v_u_73
				p_u_12.muzzle(p195, v_u_6)
				if not p195.lite then
					v_u_73(p195.eye + p195.dir * 1.6, -p195.dir, 5, 1.6, 0.12)
				end
			end,
			["shot"] = function(p_u_196, p197) -- name: starShot
				-- upvalues: (ref) v_u_3, (ref) v_u_6, (copy) v_u_20, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) p_u_12, (ref) v_u_11, (copy) v_u_29
				local v_u_198 = p_u_196.size
				local v_u_199 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), p197, v_u_6, {
					["transparency"] = 1
				})
				local v_u_200 = {}
				for v201 = 1, 5 do
					local v202 = v201 / 5 * 3.141592653589793 * 2
					local v203 = CFrame.Angles(0, v202, 0) * CFrame.new(1.25 * v_u_198, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
					local v204 = {
						["p"] = v_u_20(Vector3.new(0.3, 2.6, 1.15) * v_u_198, p197 * v203, v_u_6),
						["off"] = v203
					}
					table.insert(v_u_200, v204)
					if p_u_196.lite then
						continue
					end
					local v205 = CFrame.Angles(0, v202 + 0.6283185307179586, 0) * CFrame.new(0.8 * v_u_198, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
					local v206 = {
						["p"] = v_u_20(Vector3.new(0.32, 1.5, 0.75) * v_u_198, p197 * v205, v_u_7),
						["off"] = v205
					}
					table.insert(v_u_200, v206)
				end
				local v207 = {
					["p"] = v_u_20(Vector3.new(0.9, 0.55, 0.9) * v_u_198, p197, v_u_9),
					["off"] = CFrame.identity
				}
				table.insert(v_u_200, v207)
				v_u_1:AddItem(v_u_199, 6)
				p_u_12.streak(v_u_199, v_u_6, v_u_7, 2.6 * v_u_198, 0.14)
				if p_u_196.mine then
					p_u_12.light(v_u_199, v_u_6, 9 * v_u_198)
				end
				local v_u_208 = 0.03
				local v_u_209 = false
				return {
					["place"] = function(p210, p211) -- name: place
						-- upvalues: (copy) v_u_199, (ref) v_u_11, (copy) v_u_200, (copy) p_u_196, (ref) v_u_208, (ref) v_u_29, (copy) v_u_198
						v_u_199.CFrame = p210 * CFrame.Angles(0, 0, 1.5707963267948966)
						local v212 = p210 * v_u_11 * CFrame.Angles(0, p211 * 24, 0)
						for _, v213 in v_u_200 do
							v213.p.CFrame = v212 * v213.off
						end
						if not p_u_196.lite and v_u_208 <= p211 then
							v_u_208 = p211 + 0.05
							v_u_29(p210.Position, v_u_198, 0.45)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_209, (copy) v_u_199, (ref) v_u_1, (copy) v_u_200
						if not v_u_209 then
							v_u_209 = true
							local v214 = v_u_199:FindFirstChildWhichIsA("PointLight")
							if v214 then
								v214:Destroy()
							end
							v_u_1:AddItem(v_u_199, 0.2)
							for _, v215 in v_u_200 do
								v215.p:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p216, p217) -- name: impact
				-- upvalues: (copy) v_u_73, (copy) p_u_12, (ref) v_u_6, (ref) v_u_3, (ref) v_u_7, (ref) v_u_5, (copy) v_u_46
				local v218 = p216.size
				v_u_73(p217, -p216.dir, 6, 3.6 * v218, 0.25)
				p_u_12.burst("Slash", p217, v_u_6, 1 * v218)
				p_u_12.burst("Impact", p217, v_u_6, 0.9 * v218)
				v_u_3.flash(p217, v_u_6, 5 * v218, 0.15)
				v_u_3.ring(p_u_12.ground(p217), v_u_7, 4.5 * v218, 0.3, v_u_5.Ring)
				v_u_46(p217, p216.lite and 2 or 5, 12, v218)
				p_u_12.hitSound(p217)
			end,
			["hit"] = function(_, p219, _) -- name: hit
				-- upvalues: (copy) p_u_12, (ref) v_u_6
				p_u_12.burst("Slash", p219, v_u_6, 0.55)
			end
		},
		["lotus_eye_e"] = {
			["cast"] = function(p220) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (copy) v_u_73
				p_u_12.skillCast(p220, v_u_6)
				v_u_73(p220.eye + p220.dir * 1.6, -p220.dir, 6, 2.2, 0.18)
			end,
			["windup"] = function(p221, p222, p223) -- name: windup
				-- upvalues: (copy) v_u_110, (copy) v_u_159, (copy) p_u_12, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3, (ref) v_u_7
				local v224 = p221.ability.radius
				local v225 = p221.ability.freeze or 2
				v_u_110[p221] = v_u_159(p221, p222, p223)
				p_u_12.sigil(CFrame.new(p_u_12.ground(p222, 0.12)), v224, v_u_6, v_u_5.MagicCircle, p223 + v225, 0.7)
				v_u_3.ring(p_u_12.ground(p222), v_u_7, v224, p223 + 0.15, v_u_5.Ring)
				p_u_12.pop(p_u_12.ground(p222, 2), v_u_7, 2, 8, p223 + 0.1, 0.3)
			end,
			["land"] = function(p_u_226, p_u_227) -- name: land
				-- upvalues: (copy) p_u_12, (copy) v_u_110, (copy) v_u_159, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_46, (ref) v_u_4, (ref) v_u_5
				local v_u_228 = p_u_226.ability.radius
				local v_u_229 = p_u_12.ground(p_u_227, 0)
				local v230 = v_u_110[p_u_226]
				v_u_110[p_u_226] = nil
				local v231 = v230 or v_u_159(p_u_226, p_u_227, 0)
				v231.landAt = os.clock()
				p_u_12.after(0.12, function()
					-- upvalues: (ref) p_u_12, (copy) v_u_229, (ref) v_u_6, (ref) v_u_7, (copy) v_u_228, (ref) v_u_3, (copy) p_u_227, (copy) p_u_226, (ref) v_u_46, (ref) v_u_4
					p_u_12.burst("Flash", v_u_229 + Vector3.new(0, 8, 0), v_u_6, 0.4)
					p_u_12.pop(v_u_229 + Vector3.new(0, 7, 0), v_u_7, 3, v_u_228 * 0.8, 0.2, 0.4)
					v_u_3.ring(v_u_229, v_u_6, v_u_228 * 1.1, 0.35)
					local v232 = p_u_12.burst
					local v233 = p_u_12.ground(p_u_227, 0.3)
					local v234 = v_u_6
					local v235 = v_u_228 / 18
					v232("Shockwave", v233, v234, (math.min(v235, 1)))
					if not p_u_226.lite then
						v_u_46(v_u_229 + Vector3.new(0, 9, 0), 8, 14, 1.3)
					end
					v_u_4.play("Crit", {
						["at"] = v_u_229,
						["volume"] = p_u_226.mine and 0.6 or 0.35
					})
					if p_u_226.mine then
						v_u_3.shake(0.25, 0.25)
					end
				end)
				p_u_12.after(v231.freeze, function()
					-- upvalues: (ref) p_u_12, (copy) v_u_229, (ref) v_u_7, (copy) v_u_228, (ref) v_u_3, (ref) v_u_5, (ref) v_u_46, (copy) p_u_226, (ref) v_u_6, (ref) v_u_4
					p_u_12.pop(v_u_229 + Vector3.new(0, 6, 0), v_u_7, 3, v_u_228, 0.3, 0.5)
					v_u_3.ring(v_u_229, v_u_7, v_u_228 * 1.2, 0.4, v_u_5.Ring)
					v_u_46(v_u_229 + Vector3.new(0, 6, 0), p_u_226.lite and 5 or 14, 18, 1.6)
					p_u_12.burst("Impact", v_u_229 + Vector3.new(0, 5, 0), v_u_6, 1.5)
					v_u_4.play("Burst", {
						["at"] = v_u_229,
						["volume"] = p_u_226.mine and 0.6 or 0.35
					})
				end)
			end,
			["hit"] = function(p236, p237, p238) -- name: hit
				-- upvalues: (copy) v_u_179, (copy) p_u_12, (ref) v_u_6
				v_u_179(p237, p238, p236.ability.freeze or 2)
				p_u_12.burst("Impact", p237, v_u_6, 0.6)
			end
		},
		["lotus_eye_r"] = {
			["cast"] = function(p239) -- name: cast
				-- upvalues: (copy) p_u_12, (ref) v_u_6, (ref) v_u_7, (copy) v_u_46
				p_u_12.skillCast(p239, v_u_6, true)
				p_u_12.glint(p239.eye, v_u_7, 8, 0.22)
				if not p239.lite then
					v_u_46(p239.feet + Vector3.new(0, 1.5, 0), 8, 10, 1.2)
				end
			end,
			["windup"] = function(p240, p241, p_u_242) -- name: windup
				-- upvalues: (copy) p_u_12, (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (copy) v_u_91, (ref) v_u_7, (copy) v_u_20, (ref) v_u_9, (ref) v_u_1, (copy) v_u_109, (ref) v_u_3
				local v_u_243 = p240.ability.radius
				local v_u_244 = p240.lite
				local v_u_245 = p_u_12.ground(p241, 0)
				local v246 = p_u_242 + 0.3
				local v_u_247 = p_u_12.ground(p241, 25)
				p_u_12.sigil(p_u_12.facing(v_u_247 - Vector3.new(0, 0.9, 0), Vector3.new(-0, -1, -0)), 3.6, v_u_10, p_u_12.iris("lotus_eye"), v246, 0.5)
				p_u_12.sigil(p_u_12.facing(v_u_247 + Vector3.new(0, 3, 0), Vector3.new(-0, -1, -0)), v_u_243 * 0.55, v_u_6, v_u_5.MagicCircle, v246, 1.3)
				p_u_12.sigil(CFrame.new(p_u_12.ground(p241, 0.12)), v_u_243, v_u_6, v_u_5.Ring, v246, 0.8)
				p_u_12.burst("Flash", v_u_247, v_u_6, 0.45)
				local v_u_248 = {}
				v_u_91(v_u_248, v_u_244 and 6 or 10, 3, 9, 4.6, 0.6, v_u_6, 0.15, 0, -0.2, 1.25, v246 + 1, Enum.Material.SmoothPlastic)
				if not v_u_244 then
					v_u_91(v_u_248, 8, 1.8, 6, 3.2, 0.5, v_u_7, 0.15, 0.5, -0.2, 1, v246 + 1)
				end
				local v_u_249 = {}
				for _, v250 in v_u_248 do
					local v251 = v250.p.Transparency
					table.insert(v_u_249, v251)
				end
				local v_u_252 = v_u_20(Vector3.new(3.4, 1.4, 3.4), CFrame.new(v_u_247), v_u_9, 0.1)
				v_u_1:AddItem(v_u_252, v246 + 1)
				local v_u_253 = {}
				for v254 = 1, v_u_244 and 8 or 30 do
					local v255 = v_u_20
					local v256 = Vector3.new(0.3, 3, 1.4)
					local v257 = CFrame.new(v_u_245 + Vector3.new(0, 10, 0))
					local v258
					if v254 % 3 == 0 then
						v258 = v_u_7
					else
						v258 = v_u_6
					end
					local v259 = v255(v256, v257, v258, 0.05)
					v_u_1:AddItem(v259, v246 + 1)
					local v260 = {
						["p"] = v259,
						["a"] = math.random() * 3.141592653589793 * 2,
						["f"] = math.random()
					}
					table.insert(v_u_253, v260)
				end
				local v_u_261 = os.clock()
				local v_u_262 = 0
				p_u_12.runNow(function()
					-- upvalues: (copy) v_u_261, (copy) p_u_242, (copy) v_u_253, (copy) v_u_243, (copy) v_u_245, (ref) v_u_109, (copy) v_u_248, (copy) v_u_247, (copy) v_u_249, (copy) v_u_252, (copy) v_u_244, (ref) v_u_262, (ref) p_u_12, (ref) v_u_7
					local v263 = os.clock() - v_u_261
					local v264 = p_u_242
					local v265 = v263 / math.max(v264, 0.2)
					local v266 = math.clamp(v265, 0, 1)
					local v267 = (v263 - p_u_242) / 0.35
					local v268 = math.clamp(v267, 0, 1)
					local v269 = 1.3 - (1 - (1 - v266) ^ 2) * 0.55
					for v270, v271 in v_u_253 do
						local v272 = v271.a + v263 * (v271.f * 0.9 + 2.4)
						local v273 = v_u_243 * v269 * (v271.f * 0.4 + 0.8) * (v268 * 0.8 + 1)
						local v274 = math.cos(v272)
						local v275 = math.sin(v272)
						local v276 = v_u_245 + Vector3.new(v274, 0, v275) * v273 + Vector3.new(0, 1, 0) * (v271.f * 11 + 5 + v266 * 3 + v268 * 4)
						local v277 = -math.sin(v272)
						local v278 = math.cos(v272)
						local v279 = Vector3.new(v277, 0, v278)
						v271.p.CFrame = CFrame.lookAt(v276, v276 + v279) * CFrame.Angles(0, 0, v263 * 7 + v270) * CFrame.Angles(1.5707963267948966, 0, 0)
						v271.p.Transparency = v268 * 0.95 + 0.05
					end
					local v280 = v263 / 0.35
					local v281 = math.clamp(v280, 0, 1)
					v_u_109(v_u_248, v_u_247, 1 - (1 - v281) ^ 2 + v268 * 0.6, v281 * 0.6 + 0.4 + v268 * 0.3, v263 * 0.6, v268, v_u_249, true)
					v_u_252.CFrame = CFrame.new(v_u_247) * CFrame.Angles(0, v263 * 0.6, 0)
					v_u_252.Transparency = v268 * 0.9 + 0.1
					if not v_u_244 and (v_u_262 <= v263 and v268 == 0) then
						v_u_262 = v263 + 0.25
						p_u_12.inward(v_u_245 + Vector3.new(0, 8, 0), v_u_7, 2, v_u_243 * 1.2, 0.4)
					end
					if v268 < 1 then
						return true
					end
					for _, v282 in v_u_253 do
						v282.p:Destroy()
					end
					for _, v283 in v_u_248 do
						v283.p:Destroy()
					end
					v_u_252:Destroy()
					return false
				end)
				if p240.mine then
					v_u_3.shake(0.2, 0.25)
				end
			end,
			["strike"] = function(p_u_284, p_u_285, p286) -- name: strike
				-- upvalues: (copy) p_u_12, (copy) v_u_194, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (copy) v_u_73, (ref) v_u_8, (copy) v_u_46, (ref) v_u_4
				local v_u_287 = p_u_284.ability.strikeRadius or 6.5
				for v_u_288 = 1, p_u_284.lite and 1 or 4 do
					local v289 = math.random() * 3.141592653589793 * 2
					local v290 = p_u_12.ground(p_u_285, 18 + math.random() * 4)
					local v291 = math.cos(v289)
					local v292 = math.sin(v289)
					local v293 = v290 + Vector3.new(v291, 0, v292) * (4 + math.random() * 5)
					local v294 = p_u_12.ground(p_u_285, 0.7)
					local v295 = (math.random() - 0.5) * 3
					local v296 = (math.random() - 0.5) * 3
					local v297 = v294 + Vector3.new(v295, 0, v296)
					p_u_12.drop(p_u_284, v_u_194, v293, v297, 0.17, p286 + (v_u_288 - 1) * 0.03, 0.45, function(p298)
						-- upvalues: (ref) p_u_12, (ref) v_u_6, (copy) v_u_288, (copy) p_u_285, (ref) v_u_3, (copy) v_u_287, (ref) v_u_5, (ref) v_u_73, (copy) p_u_284, (ref) v_u_8, (ref) v_u_46, (ref) v_u_4
						p_u_12.burst("Slash", p298 + Vector3.new(0, 0.6, 0), v_u_6, 0.8)
						if v_u_288 == 1 then
							local v299 = p_u_12.ground(p_u_285, 0)
							v_u_3.ring(v299, v_u_6, v_u_287, 0.3, v_u_5.Ring)
							p_u_12.burst("Impact", p_u_12.ground(p_u_285, 1), v_u_6, 1.1)
							v_u_73(p_u_12.ground(p_u_285, 0.3), Vector3.new(0, 1, 0), 6, v_u_287 * 0.55, 0.3)
							v_u_3.flash(p_u_12.ground(p_u_285, 1.5), v_u_6, 5, 0.12)
							if not p_u_284.lite then
								p_u_12.mark(p_u_285, v_u_8, v_u_287 * 0.5, 0.8, v_u_5.CrackLines, 0.25)
								v_u_46(p_u_12.ground(p_u_285, 1), 3, 10, 1)
							end
							v_u_4.play("Hit", {
								["at"] = nil,
								["volume"] = 0.45,
								["at"] = p298
							})
							if p_u_284.mine then
								v_u_3.shake(0.14, 0.1)
							end
						end
					end)
				end
			end,
			["hit"] = function(_, p300, _) -- name: hit
				-- upvalues: (copy) p_u_12, (ref) v_u_6
				p_u_12.burst("Slash", p300, v_u_6, 0.55)
			end
		}
	}
	return v301
end