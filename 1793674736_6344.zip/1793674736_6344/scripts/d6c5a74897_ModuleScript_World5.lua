local v1 = {
	["stardust_imp"] = {
		["shirt"] = 10859804104,
		["pants"] = 116637888425938,
		["accessories"] = nil,
		["skin"] = "#B48CE8",
		["accessories"] = { 73876287069233, 107197485356499, 18641399341 }
	},
	["star_crab"] = {
		["shirt"] = 6428567574,
		["pants"] = 6428556068,
		["accessories"] = nil,
		["skin"] = "#FF6F5E",
		["accessories"] = { 14301509258, 15536498642, 133819394394752 }
	},
	["rock_drifter"] = {
		["shirt"] = 111974769751590,
		["pants"] = 123659177680493,
		["accessories"] = nil,
		["skin"] = "#6E6A82",
		["accessories"] = { 12588355546, 93131428951135, 136233660223809 }
	},
	["asteroid_beetle"] = {
		["shirt"] = 139972212216950,
		["pants"] = 84721181146178,
		["accessories"] = nil,
		["skin"] = "#2A1E3A",
		["accessories"] = { 85215918637989, 136135980266216, 13469906945 }
	},
	["comet_scavenger"] = {
		["shirt"] = 9346773488,
		["pants"] = 9346789313,
		["accessories"] = nil,
		["skin"] = "#A8C4DC",
		["accessories"] = { 16179414079, 13955286701, 96798343074432 }
	},
	["comet_golem"] = {
		["shirt"] = 12245273146,
		["pants"] = 12245277973,
		["accessories"] = nil,
		["skin"] = "#4F8FD0",
		["accessories"] = { 5972749364, 135004945324541, 87841758569015 }
	},
	["comet_titan"] = {
		["shirt"] = 133185753554461,
		["pants"] = 118375228982054,
		["accessories"] = nil,
		["skin"] = "#2E4A8C",
		["accessories"] = {
			14236401468,
			77883904230370,
			14235391432,
			14235397846
		}
	},
	["nebula_sprite"] = {
		["shirt"] = 1151906337,
		["pants"] = 328316617,
		["accessories"] = nil,
		["skin"] = "#F2C6EC",
		["accessories"] = { 79505159825038, 18767055491, 15665923288 }
	},
	["spore_alien"] = {
		["shirt"] = 5066778115,
		["pants"] = 5066783411,
		["accessories"] = nil,
		["skin"] = "#7ED957",
		["accessories"] = { 9057312161, 123926497088654, 9126477585 }
	},
	["crystal_sentinel"] = {
		["shirt"] = 126647278393065,
		["pants"] = 84862964219547,
		["accessories"] = nil,
		["skin"] = "#8FE6F0",
		["accessories"] = { 110751409783180, 3267573976, 10419365435 }
	},
	["prism_mantis"] = {
		["shirt"] = 11476163063,
		["pants"] = 11476143210,
		["accessories"] = nil,
		["skin"] = "#86D06E",
		["accessories"] = { 11367001892, 6283679109, 3160995197 }
	},
	["gravity_wraith"] = {
		["shirt"] = 14390549044,
		["pants"] = 14391520995,
		["accessories"] = nil,
		["skin"] = "#2B1B4F",
		["accessories"] = { 86356115142691, 14391163007, 11092580432 }
	},
	["void_walker"] = {
		["shirt"] = 113007401492565,
		["pants"] = 126908882654843,
		["accessories"] = nil,
		["skin"] = "#140A24",
		["accessories"] = { 118102478691454, 86394437341611 }
	},
	["singularity_lord"] = {
		["shirt"] = 17832568281,
		["pants"] = 17832778130,
		["accessories"] = nil,
		["skin"] = "#1A0F2E",
		["accessories"] = {
			89868011511659,
			123194233482486,
			70978104209610,
			15867642304
		}
	},
	["alien_priest"] = {
		["shirt"] = 12385407351,
		["pants"] = 12391590963,
		["accessories"] = nil,
		["skin"] = "#6CCB4A",
		["accessories"] = { 16824130254, 15467660846, 15518334473 }
	},
	["ruin_guardian"] = {
		["shirt"] = 122812697416511,
		["pants"] = 9849329684,
		["accessories"] = nil,
		["skin"] = "#3E6A6E",
		["accessories"] = { 52489921, 107569932222036 }
	},
	["ring_drifter"] = {
		["shirt"] = 1757863388,
		["pants"] = 1757865473,
		["accessories"] = nil,
		["skin"] = "#D9A46A",
		["accessories"] = { 18681249375, 16031478979, 116761417810944 }
	},
	["gas_jelly"] = {
		["shirt"] = 132335576550747,
		["pants"] = 97397672607372,
		["accessories"] = nil,
		["skin"] = "#E070C8",
		["accessories"] = { 32661648, 104531743794528, 136515953644998 }
	},
	["star_sentry"] = {
		["shirt"] = 13416169167,
		["pants"] = 13416170119,
		["accessories"] = nil,
		["skin"] = "#D8D8E0",
		["accessories"] = { 74020836922886, 13687973871 }
	},
	["astronomer"] = {
		["shirt"] = 14959779139,
		["pants"] = 14959780789,
		["accessories"] = nil,
		["skin"] = "#F2DCC4",
		["accessories"] = { 104683736588315, 89670557352751, 10998523257 }
	},
	["star_sage"] = {
		["shirt"] = 75982924436144,
		["pants"] = 110568384702494,
		["accessories"] = nil,
		["skin"] = "#F4E4D0",
		["accessories"] = {
			107516393690637,
			139773243881112,
			118404329146629,
			11710151904
		}
	},
	["meteor_brute"] = {
		["shirt"] = 9006527896,
		["pants"] = 9006479100,
		["accessories"] = nil,
		["skin"] = "#3A2420",
		["accessories"] = { 11537291491, 11422974937, 14282503590 }
	},
	["fire_comet"] = {
		["shirt"] = 1038982214,
		["pants"] = 2702383011,
		["accessories"] = nil,
		["skin"] = "#FF8A2A",
		["accessories"] = { 76856991148700, 133798762595576, 16153108954 }
	},
	["dark_slime"] = {
		["shirt"] = 130477300646544,
		["pants"] = 75456136300254,
		["accessories"] = nil,
		["skin"] = "#3B1C6E",
		["accessories"] = { 88586994553304, 12990850025, 6798261851 }
	},
	["null_shade"] = {
		["shirt"] = 132663694358135,
		["pants"] = 125597757901249,
		["accessories"] = nil,
		["skin"] = "#0A0A12",
		["accessories"] = { 97337540050955, 92601022200753, 5355301507 }
	},
	["galaxy_knight"] = {
		["shirt"] = 86129001507439,
		["pants"] = 129348489846831,
		["accessories"] = nil,
		["skin"] = "#B8A8F0",
		["accessories"] = { 96783186161476, 74953893175477, 114156872334758 }
	},
	["star_serpent"] = {
		["shirt"] = 11696991659,
		["pants"] = 11696992713,
		["accessories"] = nil,
		["skin"] = "#4A2478",
		["accessories"] = { 12481044992, 100266568870744 }
	},
	["galaxy_guardian"] = {
		["shirt"] = 108175811482166,
		["pants"] = 117514492672446,
		["accessories"] = nil,
		["skin"] = "#D8A8F0",
		["accessories"] = {
			110046480083950,
			87833918004887,
			110663980549608,
			10419312647
		}
	},
	["quasar_mage"] = {
		["shirt"] = 14840106649,
		["pants"] = 14840107952,
		["accessories"] = nil,
		["skin"] = "#1C2E44",
		["accessories"] = { 95075072600173, 14974183903, 129550540273896 }
	},
	["plasma_drone"] = {
		["shirt"] = 11582740527,
		["pants"] = 11582749258,
		["accessories"] = nil,
		["skin"] = "#2E2A3A",
		["accessories"] = { 12590500826, 17333419894, 12661223452 }
	},
	["warp_hunter"] = {
		["shirt"] = 13405918391,
		["pants"] = 13405715499,
		["accessories"] = nil,
		["skin"] = "#3A2C55",
		["accessories"] = { 118225570895410, 131577122939956, 5890486319 }
	},
	["warp_beast"] = {
		["shirt"] = 10900660805,
		["pants"] = 10900659519,
		["accessories"] = nil,
		["skin"] = "#1A1026",
		["accessories"] = { 91159950040972, 82328211463765, 95127688938776 }
	},
	["star_ronin"] = {
		["shirt"] = 6433556743,
		["pants"] = 6433557505,
		["accessories"] = nil,
		["skin"] = "#CDB4E6",
		["accessories"] = { 13435193459, 13689790636, 139263084723563 }
	},
	["cosmic_assassin"] = {
		["shirt"] = 101442460498683,
		["pants"] = 73953804780796,
		["accessories"] = nil,
		["skin"] = "#1E1438",
		["accessories"] = { 17611656402, 113332969505791, 99132697081248 }
	},
	["void_emperor"] = {
		["shirt"] = 82699965841108,
		["pants"] = 72703122573466,
		["accessories"] = nil,
		["skin"] = "#24103A",
		["accessories"] = {
			96917476474822,
			95733570057242,
			12693471131,
			120452949161776
		}
	}
}
return v1