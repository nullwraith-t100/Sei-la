local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.Parent.EpicKit8)
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v4 = require(script.Parent.Parent.Preload)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v1.Shared.Config.Textures)
v4.images({
	v_u_6.BloodBloom,
	v_u_6.BloodDrop,
	v_u_6.BloodFlame,
	v_u_6.BloodBurst
})
local v_u_7 = Color3.fromRGB(42, 0, 16)
local v_u_8 = Color3.fromRGB(150, 0, 48)
local v_u_9 = Color3.fromRGB(255, 200, 228)
local v_u_10 = Color3.fromRGB(104, 168, 70)
local v_u_11 = Color3.fromRGB(58, 104, 40)
local v_u_12 = Color3.fromRGB(200, 30, 40)
local v_u_13 = Enum.Material.SmoothPlastic
local v_u_14 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_15 = Enum.ParticleFlipbookMode.OneShot
local v_u_16 = CFrame.identity
local function v_u_25(p17, p_u_18, p19, p_u_20) -- name: weldTo
	p19.Anchored = false
	p19.Massless = true
	local v21 = Instance.new("Weld")
	v21.Part0 = p_u_18
	v21.Part1 = p19
	v21.C0 = p_u_20
	v21.Parent = p19
	local v22 = p17.pieces
	local v24 = {
		["part"] = p19,
		["place"] = function(p23, _) -- name: place
			-- upvalues: (copy) p_u_18, (copy) p_u_20
			if p_u_18.Parent then
				return p_u_18.CFrame * p_u_20
			else
				return p23
			end
		end,
		["alpha"] = p19.Transparency,
		["weld"] = v21
	}
	table.insert(v22, v24)
end
local function v_u_30(p26, p27) -- name: bodyPart
	for _, v28 in p27 do
		local v29 = p26.character:FindFirstChild(v28)
		if not (v29 and v29:IsA("BasePart")) then
			continue
		end
		return v29
	end
	return nil
end
local function v_u_35(p31, p32, p33) -- name: floorEmitter
	local v34 = Instance.new("ParticleEmitter")
	v34.Texture = p31
	v34.Color = ColorSequence.new(p32)
	v34.LightEmission = p33
	v34.LightInfluence = 0
	v34.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v34.EmissionDirection = Enum.NormalId.Top
	v34.SpreadAngle = Vector2.zero
	v34.Speed = NumberRange.new(0.01)
	v34.Rate = 0
	v34.Enabled = false
	v34.LockedToPart = true
	return v34
end
return function(p_u_36)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_14, (copy) v_u_15, (copy) v_u_8, (copy) v_u_2, (copy) v_u_35, (copy) v_u_9, (copy) v_u_30, (copy) v_u_25, (copy) v_u_16, (copy) v_u_10, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12
	return {
		["w8_exploding_blood"] = function(p_u_37, p38)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_7, (copy) p_u_36, (ref) v_u_6, (ref) v_u_14, (ref) v_u_15, (ref) v_u_8, (ref) v_u_2, (ref) v_u_35, (ref) v_u_9, (ref) v_u_30, (ref) v_u_25, (ref) v_u_16, (ref) v_u_10, (ref) v_u_13, (ref) v_u_11, (ref) v_u_12
			local v39 = v_u_3.color(p38.color)
			local v40 = p_u_37.headY / 1.5
			local v_u_41 = math.clamp(v40, 0.7, 3)
			local v42 = p_u_37.fx
			local v43 = math.min(v42, 1.6)
			local v_u_44 = v_u_5.formRate()
			local v45 = v_u_3.part
			local v46 = v_u_41 * 2.6
			local v47 = v_u_41 * 2.6
			local v48 = v45(Vector3.new(v46, 0.2, v47), CFrame.identity, v_u_7, {
				["transparency"] = 1
			})
			v48.Massless = true
			p_u_36.add(p_u_37, v48, function(p49)
				-- upvalues: (ref) p_u_36, (copy) p_u_37
				return CFrame.new(p_u_36.feetAt(p_u_37, p49, 0.1))
			end)
			p_u_36.own(p_u_37, v48)
			local v50 = Instance.new("Attachment")
			v50.Parent = v48
			local v_u_51 = Instance.new("ParticleEmitter")
			v_u_51.Texture = v_u_6.BloodFlame
			v_u_51.FlipbookLayout = v_u_14
			v_u_51.FlipbookMode = v_u_15
			v_u_51.Color = ColorSequence.new(v39, v_u_8)
			v_u_51.LightEmission = 0.12
			v_u_51.LightInfluence = 0
			v_u_51.Lifetime = NumberRange.new(0.55, 0.85)
			v_u_51.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_41 * 1 * p_u_37.fx), NumberSequenceKeypoint.new(0.5, v_u_41 * 1.45 * p_u_37.fx), NumberSequenceKeypoint.new(1, v_u_41 * 0.8 * p_u_37.fx) })
			v_u_51.Transparency = v_u_2.seq({
				{ 0, 0.15 },
				{ 0.8, 0.2 },
				{ 1, 1 }
			})
			v_u_51.Speed = NumberRange.new(v_u_41 * 0.8, v_u_41 * 2)
			v_u_51.SpreadAngle = Vector2.new(10, 10)
			v_u_51.EmissionDirection = Enum.NormalId.Top
			v_u_51.Shape = Enum.ParticleEmitterShape.Box
			v_u_51.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_51:SetAttribute("BaseRate", 9)
			v_u_51.Rate = 9 * v_u_44
			v_u_51.Parent = v48
			local v_u_52 = v_u_35(v_u_6.BloodBloom, v39, 0.45)
			v_u_52.Lifetime = NumberRange.new(0.7)
			v_u_52.Size = v_u_2.seq({
				{ 0, 1 },
				{ 0.3, 3.4 },
				{ 1, 4 }
			}, v_u_41 * v43)
			v_u_52.Transparency = v_u_2.seq({
				{ 0, 0.4 },
				{ 0.25, 0 },
				{ 0.6, 0.15 },
				{ 1, 1 }
			})
			v_u_52.Rotation = NumberRange.new(0, 360)
			v_u_52.RotSpeed = NumberRange.new(-260, -260)
			v_u_52.Parent = v50
			local v_u_53 = Instance.new("ParticleEmitter")
			v_u_53.Texture = v_u_6.BloodBurst
			v_u_53.FlipbookLayout = v_u_14
			v_u_53.FlipbookMode = v_u_15
			v_u_53.Color = ColorSequence.new(v_u_9, v39)
			v_u_53.LightEmission = 0.5
			v_u_53.LightInfluence = 0
			v_u_53.Lifetime = NumberRange.new(0.5, 0.7)
			v_u_53.Size = v_u_2.seq({
				{ 0, 1.2 },
				{ 1, 2.2 }
			}, v_u_41 * v43)
			v_u_53.Speed = NumberRange.new(v_u_41 * 5, v_u_41 * 8)
			v_u_53.SpreadAngle = Vector2.new(70, 70)
			v_u_53.EmissionDirection = Enum.NormalId.Top
			local v54 = v_u_41 * -4
			v_u_53.Acceleration = Vector3.new(0, v54, 0)
			v_u_53.Drag = 3
			v_u_53.Rotation = NumberRange.new(0, 360)
			v_u_53.Shape = Enum.ParticleEmitterShape.Box
			v_u_53.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v_u_53.Rate = 0
			v_u_53.Enabled = false
			v_u_53.Parent = v48
			local v_u_55 = Instance.new("ParticleEmitter")
			v_u_55.Texture = v_u_6.BloodDrop
			v_u_55.LightEmission = 0
			v_u_55.LightInfluence = 0
			v_u_55.Orientation = Enum.ParticleOrientation.VelocityParallel
			v_u_55.Lifetime = NumberRange.new(0.5, 0.8)
			v_u_55.Size = NumberSequence.new(v_u_41 * 0.35 * v43)
			v_u_55.Speed = NumberRange.new(v_u_41 * 9, v_u_41 * 14)
			v_u_55.SpreadAngle = Vector2.new(65, 65)
			v_u_55.EmissionDirection = Enum.NormalId.Top
			local v56 = v_u_41 * -45
			v_u_55.Acceleration = Vector3.new(0, v56, 0)
			v_u_55.Rate = 0
			v_u_55.Enabled = false
			v_u_55.Parent = v50
			local v_u_57 = p_u_36.throb(p_u_37, 5.5, 1.6, 1.2, function()
				-- upvalues: (copy) v_u_52, (copy) v_u_53, (ref) v_u_5, (copy) v_u_55
				v_u_52:Emit(1)
				v_u_53:Emit(v_u_5.level() >= 2 and 10 or 5)
				v_u_55:Emit(v_u_5.level() >= 2 and 12 or 5)
			end)
			local v_u_58 = -1
			local v59 = p_u_37.ticks
			local function v62()
				-- upvalues: (copy) v_u_57, (ref) v_u_58, (copy) v_u_51, (copy) v_u_44, (copy) v_u_41
				local v60 = v_u_57() * 10
				local v61 = math.floor(v60) / 10
				if v61 ~= v_u_58 then
					v_u_58 = v61
					v_u_51.Rate = 9 * v_u_44 * (v61 * 2.5 + 1)
					v_u_51.Speed = NumberRange.new((v61 * 3 + 0.8) * v_u_41, (v61 * 5 + 2) * v_u_41)
				end
			end
			table.insert(v59, v62)
			for _, v63 in {
				{ "RightHand", "Right Arm" },
				{ "LeftHand", "Left Arm" }
			} do
				local v64 = v_u_30(p_u_37, v63)
				if not v64 then
					continue
				end
				local v65 = Instance.new("Attachment")
				local v66 = -v64.Size.Y * 0.45
				v65.Position = Vector3.new(0, v66, 0)
				v65.Parent = v64
				p_u_36.own(p_u_37, v65)
				local v67 = Instance.new("ParticleEmitter")
				v67.Texture = v_u_6.BloodDrop
				v67.LightEmission = 0
				v67.LightInfluence = 0
				v67.Orientation = Enum.ParticleOrientation.VelocityParallel
				v67.Lifetime = NumberRange.new(0.45)
				v67.Size = NumberSequence.new(v_u_41 * 0.22)
				v67.Speed = NumberRange.new(1)
				v67.EmissionDirection = Enum.NormalId.Bottom
				v67.SpreadAngle = Vector2.new(5, 5)
				v67.Acceleration = Vector3.new(0, -40, 0)
				v67:SetAttribute("BaseRate", 1.2)
				v67.Rate = 1.2 * v_u_44
				v67.Parent = v65
			end
			local v68 = v_u_30(p_u_37, { "Head" })
			if v68 then
				local v69 = v68.Size
				local v70 = CFrame.new(Vector3.new(0, -0.24, -0.52) * v69)
				local v71 = v_u_2.piece("w8_exploding_blood", v69.X * 1.3)
				if v71 then
					v_u_25(p_u_37, v68, v71, v70 * v_u_16 * v_u_2.longX(v71))
				else
					local v72 = v69.X * 1.3
					local v73 = 0.26 * v69.Y
					for _, v74 in { 0, 0.7853981633974483 } do
						v_u_25(p_u_37, v68, p_u_36.bar(Vector3.new(v72, v73, v73), v_u_10, 0, v_u_13), v70 * CFrame.Angles(v74, 0, 0))
					end
					for _, v75 in { -0.32, 0.32 } do
						local v76 = p_u_36.bar
						local v77 = 0.08 * v72
						local v78 = v73 * 1.15
						local v79 = v73 * 1.15
						v_u_25(p_u_37, v68, v76(Vector3.new(v77, v78, v79), v_u_11, 0, v_u_13), v70 * CFrame.new(v75 * v72, 0, 0))
					end
					for _, v80 in { -0.5, 0.5 } do
						local v81 = p_u_36.bar
						local v82 = 0.06 * v69.X
						local v83 = 0.06 * v69.X
						local v84 = v69.Z * 0.6
						v_u_25(p_u_37, v68, v81(Vector3.new(v82, v83, v84), v_u_12, 0, v_u_13), v70 * CFrame.new(v80 * v72 * 0.98, 0, v69.Z * 0.3))
					end
				end
			end
			p_u_36.particles(p_u_37, "AuraMode", v39, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end