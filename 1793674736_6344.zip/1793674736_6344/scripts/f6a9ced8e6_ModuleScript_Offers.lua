local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.Device)
local v_u_7 = require(script.Parent.Events)
local v_u_8 = require(script.Parent.Gamepad)
local v_u_9 = require(script.Parent.Gifting)
local v_u_10 = require(script.Parent.Menus)
local v_u_11 = require(script.Parent.OfferLog)
local v_u_12 = require(script.Parent.Promo)
local v_u_13 = require(script.Parent.Sfx)
local v_u_14 = require(script.Parent.State)
local v_u_15 = require(script.Parent.Store)
local v_u_16 = require(script.Parent.Tutorial)
local v17 = v3.Shared
local v_u_18 = require(v17.Net)
local v_u_19 = require(v17.Config.Daily)
local v_u_20 = require(v17.Config.Images)
local v_u_21 = require(v17.Config.Packs)
local v_u_22 = require(v17.Config.Products)
local v_u_23 = require(v17.Logic.Offers)
local v_u_24 = require(v17.Logic.NextStep)
local v_u_25 = require(v17.Logic.Format)
local v_u_26 = require(v17.Logic.DailyStreak)
local v27 = {}
local v_u_28 = v2.LocalPlayer
local function v_u_29(_) end
local v_u_30 = nil
local v_u_31 = nil
local function v35(p32, p33, p34) -- name: rgb
	return Color3.fromRGB(p32, p33, p34)
end
local function v_u_41(p36) -- name: fresh
	for _, v37 in p36:GetDescendants() do
		local v38 = v37.Parent
		local v39
		if v37.Name == "Shine" and v38 ~= nil then
			v39 = v38:GetAttribute("Ui-Effect") == "Shine"
		else
			v39 = false
		end
		if v39 or v37.Name == "PadHint" then
			v37:Destroy()
		elseif v37:IsA("ImageLabel") then
			local v40 = v37:GetAttribute("Ui-Effect")
			if v40 ~= "Bg_X" and v40 ~= "Bg_Y" then
				continue
			end
			v37.Position = UDim2.fromScale(v37.Position.X.Scale, v37.Position.Y.Scale)
			v37.Size = UDim2.fromScale(v37.Size.X.Scale, v37.Size.Y.Scale)
		else
			if not v37:IsA("UIScale") or v37.Name ~= "Pop" then
				continue
			end
			v37.Scale = 1
		end
	end
end
local v_u_42 = Color3.fromRGB(58, 255, 14)
local v_u_43 = Color3.fromRGB(132, 255, 16)
local function v_u_65() -- name: bindDaily
	-- upvalues: (ref) v_u_31, (copy) v_u_41, (copy) v_u_42, (copy) v_u_43, (copy) v_u_15, (copy) v_u_4, (copy) v_u_5, (copy) v_u_26, (copy) v_u_14, (copy) v_u_19, (copy) v_u_23, (copy) v_u_11, (copy) v_u_7, (copy) v_u_13, (ref) v_u_29
	local v_u_44 = v_u_31:FindFirstChild("Daily")
	local v45
	if v_u_44 then
		v45 = v_u_44:FindFirstChild("Top")
	else
		v45 = v_u_44
	end
	if v45 then
		v45 = v45:FindFirstChild("SkipDay")
	end
	if v_u_44 and (v_u_44:IsA("GuiObject") and (v45 and v45:IsA("GuiButton"))) then
		local v_u_46 = v45:Clone()
		v_u_41(v_u_46)
		v_u_46.Name = "UnlockAll"
		v_u_46.AnchorPoint = Vector2.new(0.5, 0)
		v_u_46.Position = UDim2.fromScale(0.79, 1.015)
		v_u_46.Size = UDim2.fromScale(0.42, 0.105)
		v_u_46.ZIndex = 6
		v_u_46.Visible = false
		v_u_46:SetAttribute("Pad", true)
		local v47 = v_u_42
		local v48 = v_u_43
		local v49 = v_u_46:FindFirstChildOfClass("UIGradient")
		if v49 then
			v49.Color = ColorSequence.new(v47, v48)
		end
		v_u_46.Parent = v_u_44
		v_u_46.Activated:Connect(function()
			-- upvalues: (ref) v_u_15
			v_u_15.buyProduct("dailyAll", "UnlockAll")
		end)
		local v_u_50 = false
		local function v_u_59() -- name: refresh
			-- upvalues: (copy) v_u_44, (ref) v_u_50, (ref) v_u_15, (ref) v_u_4, (ref) v_u_5, (ref) v_u_26, (ref) v_u_14, (ref) v_u_19, (copy) v_u_46, (ref) v_u_23, (ref) v_u_11
			if not v_u_44.Visible then
				v_u_50 = false
			end
			local v51 = v_u_15.product("dailyAll")
			if v51 then
				if v51.id == 0 then
					local v52 = v_u_4:IsStudio()
					if v52 then
						v52 = v_u_5:GetAttribute("DevOffers") == true
					end
					if not v52 then
						v51 = nil
					end
				end
			else
				v51 = nil
			end
			local v53 = v_u_26.left(v_u_14.number("DailyStreak"), v_u_14.number("DailyLast", -1), v_u_14.number("DailyWeek"), v_u_14.number("Today", -2), v_u_19.DAYS)
			local v54 = v_u_46
			local v55
			if v51 == nil then
				v55 = false
			else
				v55 = v_u_23.unlockShown(v53)
			end
			v54.Visible = v55
			if v51 then
				local v56 = v_u_46
				local v57 = "UNLOCK ALL " .. v_u_15.priceText(v51.price)
				local v58 = v56:FindFirstChild("TextLabel")
				if v58 and v58:IsA("TextLabel") then
					v58.Text = v57
				end
			end
			if v_u_44.Visible and (v_u_46.Visible and not v_u_50) then
				v_u_50 = true
				v_u_11.shown("UnlockAll", "product", "dailyAll")
			end
		end
		for _, v60 in {
			"DailyStreak",
			"DailyLast",
			"DailyWeek",
			"Today"
		} do
			v_u_14.watch(v60, v_u_59)
		end
		v_u_44:GetPropertyChangedSignal("Visible"):Connect(v_u_59)
		v_u_15.pricesChanged:Connect(v_u_59)
		v_u_15.randomChanged:Connect(v_u_59)
		v_u_59()
		v_u_7.onNotify("DailyAll", function(p61)
			-- upvalues: (ref) v_u_13, (ref) v_u_29, (copy) v_u_59
			local v62 = type(p61) ~= "table" and {} or p61
			local v63 = v62[1]
			local v64 = v62[#v62]
			v_u_13.play("DailyClaim")
			v_u_29((type(v63) ~= "number" or (type(v64) ~= "number" or v63 == v64)) and "Daily rewards unlocked!" or ("Daily rewards unlocked: Days %*-%*!"):format(v63, v64))
			v_u_59()
		end)
	end
end
local v_u_66 = {
	["chakra"] = { Color3.fromRGB(69, 200, 255), v35(0, 128, 255) },
	["wins"] = { Color3.fromRGB(120, 255, 90), v35(30, 190, 60) },
	["autoclick"] = { Color3.fromRGB(255, 226, 60), v35(255, 150, 0) }
}
local function v_u_78(p67, p68, p69, p70, p71) -- name: fillTile
	if p67:IsA("GuiObject") then
		p67.Visible = true
		local v72 = p67:FindFirstChild("Count")
		if v72 and v72:IsA("TextLabel") then
			v72.Text = p69
		end
		local v73 = p67:FindFirstChild("Name")
		if v73 and v73:IsA("TextLabel") then
			v73.Text = p70
		end
		local v74 = p67:FindFirstChild("Icon")
		if v74 and v74:IsA("ImageLabel") then
			v74.Image = p68
		end
		local v75 = p71[1]
		local v76 = p71[2]
		local v77 = p67:FindFirstChildOfClass("UIGradient")
		if v77 then
			v77.Color = ColorSequence.new(v75, v76)
		end
	end
end
local function v_u_107() -- name: potionCard
	-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_5, (ref) v_u_31, (copy) v_u_41, (copy) v_u_22, (copy) v_u_78, (copy) v_u_20, (copy) v_u_66, (copy) v_u_23, (copy) v_u_9
	local v_u_79 = v_u_15.product("potionPack")
	if v_u_79 then
		if v_u_79.id == 0 then
			local v80 = v_u_4:IsStudio()
			if v80 then
				v80 = v_u_5:GetAttribute("DevOffers") == true
			end
			if not v80 then
				v_u_79 = nil
			end
		end
	else
		v_u_79 = nil
	end
	local v81 = v_u_31:FindFirstChild("Store")
	if v81 then
		v81 = v81:FindFirstChild("Holder", true)
	end
	local v82
	if v81 then
		v82 = v81:FindFirstChild("Pack_starter")
	else
		v82 = v81
	end
	if v_u_79 and (v81 and (v82 and not v81:FindFirstChild("Pack_potionPack"))) then
		local v83 = v82:Clone()
		v_u_41(v83)
		v83.Name = "Pack_potionPack"
		v83.LayoutOrder = 4
		for _, v84 in { "GiftButton", "Gloss" } do
			local v85 = v83:FindFirstChild(v84)
			if not v85 then
				continue
			end
			v85:Destroy()
		end
		local v86 = v83:FindFirstChild("Owned")
		if v86 and v86:IsA("GuiObject") then
			v86.Visible = false
		end
		local v_u_87 = nil
		for _, v88 in v83:GetChildren() do
			if not v88:IsA("TextLabel") or v88.Name ~= "Title" then
				continue
			end
			if v88.Rotation == 0 then
				v88.Text = "POTION PACK"
			else
				v_u_87 = v88
			end
		end
		local v_u_89 = v_u_79.contents or {}
		local v90 = v83:FindFirstChild("Tiles")
		if v90 then
			for _, v91 in v90:GetChildren() do
				if not v91:IsA("GuiObject") then
					continue
				end
				v91.Visible = false
			end
			for v92, v93 in v_u_89 do
				local v94 = v_u_22.productByKey[v93.key]
				local v95 = v90:FindFirstChild("Tile" .. v92)
				if not (v94 and v95) then
					continue
				end
				local v96 = (v94.minutes or 0) * v93.count
				local v97
				if v96 < 60 then
					v97 = ("%*m"):format(v96)
				else
					local v98 = v96 % 60
					if v98 == 0 then
						v97 = ("%*h"):format(v96 // 60)
					else
						v97 = ("%*h %*m"):format(v96 // 60, v98)
					end
				end
				local v99 = ("x%*"):format(v94.mult or 2)
				if v94.kind == "boost" and v94.boost == "wins" then
					v_u_78(v95, v_u_20.Icon.BoostWins, "x1", ("%* Trophies %*"):format(v99, v97), v_u_66.wins)
				elseif v94.kind == "boost" then
					v_u_78(v95, v_u_20.Icon.BoostChakra, "x1", ("%* Chakra %*"):format(v99, v97), v_u_66.chakra)
				else
					if v94.kind ~= "autoclick" then
						continue
					end
					v_u_78(v95, v_u_20.Icon.AutoClickOp, "OP", ("Auto Click %*"):format(v97), v_u_66.autoclick)
				end
			end
		end
		local v_u_100 = v83:FindFirstChild("Purchase1")
		if v_u_100 and v_u_100:IsA("GuiButton") then
			v_u_100:SetAttribute("Ui-Pass", nil)
			v_u_100:SetAttribute("Ui-Pack", nil)
			v_u_100:SetAttribute("Ui-Product", "potionPack")
			local v101 = v_u_100:FindFirstChild("PriceTag")
			if v101 then
				v101:SetAttribute("Ui-Pack-Robux", nil)
			end
			local function v106() -- name: show
				-- upvalues: (copy) v_u_100, (ref) v_u_15, (copy) v_u_79, (ref) v_u_23, (copy) v_u_89, (ref) v_u_22, (ref) v_u_87
				local v102 = v_u_100
				local v103 = v_u_15.priceText(v_u_79.price)
				local v104 = v102:FindFirstChild("PriceTag")
				if v104 and v104:IsA("TextLabel") then
					v104.Text = v103
				end
				local v105 = v_u_23.savePercent(v_u_79.price, v_u_23.bundleWorth(v_u_89, v_u_22.productByKey))
				if v_u_87 then
					v_u_87.Visible = v105 ~= nil
					v_u_87.Text = not v105 and "" or ("SAVE %*%%!"):format(v105)
				end
			end
			v106()
			v_u_15.pricesChanged:Connect(v106)
			v_u_100.Activated:Connect(function()
				-- upvalues: (ref) v_u_9, (ref) v_u_15
				if not v_u_9.storeBuy("potionPack") then
					v_u_15.buyProduct("potionPack")
				end
			end)
			v83.Parent = v81
		end
	else
		return
	end
end
local v_u_108 = Color3.fromRGB(255, 214, 64)
local v_u_109 = Color3.fromRGB(255, 136, 26)
local v_u_110 = nil
local v_u_111 = nil
local v_u_112 = {}
local function v_u_124(p113, p114) -- name: struckLabel
	local v_u_115 = Instance.new("TextLabel")
	v_u_115.Name = "Was"
	v_u_115.BackgroundTransparency = 1
	v_u_115.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_115.Position = UDim2.fromScale(0.88, 0)
	v_u_115.Size = UDim2.fromScale(0.55, 0.72)
	v_u_115.TextScaled = true
	v_u_115.Text = ""
	v_u_115.TextColor3 = Color3.fromRGB(255, 72, 72)
	v_u_115.ZIndex = 12
	if p114 then
		v_u_115.FontFace = p114
	end
	local v116 = Instance.new("UIStroke")
	v116.Thickness = 2
	v116.Parent = v_u_115
	local v_u_117 = Instance.new("Frame")
	v_u_117.Name = "Line"
	v_u_117.BorderSizePixel = 0
	v_u_117.BackgroundColor3 = Color3.fromRGB(255, 40, 40)
	v_u_117.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_117.Position = UDim2.fromScale(0.5, 0.52)
	v_u_117.Rotation = -16
	v_u_117.ZIndex = 13
	local v118 = Instance.new("UIStroke")
	v118.Thickness = 1.5
	v118.Parent = v_u_117
	v_u_117.Parent = v_u_115
	v_u_115:GetPropertyChangedSignal("TextBounds"):Connect(function() -- name: fit
		-- upvalues: (copy) v_u_117, (copy) v_u_115
		local v119 = v_u_117
		local v120 = UDim2.new
		local v121 = v_u_115.TextBounds.X * 1.2
		v119.Size = v120(0, math.max(v121, 8), 0.12, 0)
	end)
	local v122 = UDim2.new
	local v123 = v_u_115.TextBounds.X * 1.2
	v_u_117.Size = v122(0, math.max(v123, 8), 0.12, 0)
	v_u_115.Parent = p113
	return v_u_115
end
local function v_u_154(p125, p126, p127) -- name: buildPanel
	-- upvalues: (ref) v_u_31, (copy) v_u_41, (copy) v_u_6, (copy) v_u_20, (copy) v_u_108, (copy) v_u_109, (copy) v_u_8, (copy) v_u_112, (copy) v_u_124
	local v128 = v_u_31:FindFirstChild("Offline")
	local v129 = v_u_31:FindFirstChild("Store")
	if v129 then
		v129 = v129:FindFirstChild("Pack_starter", true)
	end
	local v130
	if v129 then
		v130 = v129:FindFirstChild("Purchase1")
	else
		v130 = v129
	end
	if not (v128 and (v128:IsA("Frame") and (v129 and v130))) then
		return nil, nil, nil
	end
	local v131 = v128:Clone()
	v131.Name = p125
	v131.Visible = false
	for _, v132 in v131:GetChildren() do
		if v132.Name == "Top" or v132:IsA("UIStroke") or (v132:IsA("UIAspectRatioConstraint") or v132:IsA("UICorner")) then
			continue
		end
		v132:Destroy()
	end
	v_u_41(v131)
	local v133 = v131:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v133 then
		v133.AspectRatio = 3
	end
	local v134
	if v_u_6.touch() then
		v134 = UDim2.fromScale(0.8, 0.6)
	else
		v134 = UDim2.fromScale(0.54, 0.4)
	end
	v131.Size = v134
	local v135 = v131:FindFirstChild("Top")
	if v135 and v135:IsA("GuiObject") then
		v135.Size = UDim2.fromScale(1, 0.24)
		v135.Position = UDim2.fromScale(0.5, 0.12)
		for _, v136 in v135:GetChildren() do
			if v136:IsA("TextLabel") then
				v136.Text = p126
			else
				if not v136:IsA("ImageLabel") or v136.Name ~= "Icon" then
					continue
				end
				v136.Image = v_u_20.Icon.Deal
			end
		end
		local v137 = v_u_108
		local v138 = v_u_109
		local v139 = v135:FindFirstChildOfClass("UIGradient")
		if v139 then
			v139.Color = ColorSequence.new(v137, v138)
		end
		local v140 = v135:FindFirstChild("Close")
		if v140 and v140:IsA("GuiObject") then
			v_u_8.hint(v140, Enum.KeyCode.ButtonB, 26)
		end
	end
	local v141 = nil
	for _, v142 in v129:GetChildren() do
		if not v142:IsA("TextLabel") or (v142.Name ~= "Title" or v142.Rotation == 0) then
			continue
		end
		v141 = v142
	end
	if v141 and p127 then
		local v143 = v141:Clone()
		v143.Name = "OneTime"
		v143.Text = "ONE TIME DEAL!"
		v143.AnchorPoint = Vector2.new(0.5, 0.5)
		v143.Position = UDim2.fromScale(0.845, 0.36)
		v143.Size = UDim2.fromScale(0.28, 0.12)
		v143.Rotation = 4
		v143.ZIndex = 8
		v143.Parent = v131
		local v144 = v_u_112
		table.insert(v144, v143)
		local v145 = v141:Clone()
		v145.Name = "Value"
		v145.Text = "INSANE VALUE!"
		v145.TextColor3 = Color3.fromRGB(255, 232, 60)
		v145.AnchorPoint = Vector2.new(0.5, 0.5)
		v145.Position = UDim2.fromScale(0.845, 0.53)
		v145.Size = UDim2.fromScale(0.28, 0.15)
		v145.Rotation = -3
		v145.ZIndex = 8
		local v146 = v145:FindFirstChildOfClass("UIGradient")
		if v146 then
			v146:Destroy()
		end
		v145.Parent = v131
		local v147 = v_u_112
		table.insert(v147, v145)
	end
	local v148 = v130:Clone()
	v_u_41(v148)
	v148.Name = "Buy"
	for _, v149 in { "Ui-Pass", "Ui-Pack", "Ui-Product" } do
		v148:SetAttribute(v149, nil)
	end
	v148:SetAttribute("Pad", true)
	if v148:IsA("GuiObject") then
		v148.AnchorPoint = Vector2.new(0.5, 0.5)
		v148.Position = UDim2.fromScale(0.845, 0.79)
		v148.Size = UDim2.fromScale(0.26, 0.3)
		v148.ZIndex = 8
	end
	local v150 = v148:FindFirstChild("PriceTag")
	if v150 then
		v150:SetAttribute("Ui-Pack-Robux", nil)
	end
	local v151 = v_u_124
	local v152
	if v150 and v150:IsA("TextLabel") then
		v152 = v150.FontFace
	else
		v152 = nil
	end
	local v153 = v151(v148, v152)
	v148.Parent = v131
	v131.Parent = v_u_31
	v_u_8.root(v131)
	if not v148:IsA("GuiButton") then
		v148 = nil
	end
	return v131, v148, v153
end
local function v_u_166(p155, p156) -- name: fillOffer
	-- upvalues: (ref) v_u_31, (copy) v_u_41, (copy) v_u_15, (copy) v_u_23, (copy) v_u_21, (copy) v_u_22
	local v157 = v_u_31:FindFirstChild("Store")
	if v157 then
		v157 = v157:FindFirstChild("Pack_starter", true)
	end
	if v157 then
		v157 = v157:FindFirstChild("Tiles")
	end
	local v158 = p155:FindFirstChild("Tiles")
	if v158 then
		v158:Destroy()
	end
	if v157 and v157:IsA("GuiObject") then
		local v159 = v157:Clone()
		v_u_41(v159)
		v159.AnchorPoint = Vector2.new(0, 0.5)
		v159.Position = UDim2.fromScale(0.025, 0.62)
		v159.Size = UDim2.fromScale(0.62, 0.68)
		local v160 = v159:FindFirstChildOfClass("UIListLayout")
		if v160 then
			v160.VerticalAlignment = Enum.VerticalAlignment.Center
		end
		v159.Parent = p155
	end
	local v161 = v_u_15.pass("starter")
	local v162 = p155:FindFirstChild("Buy")
	if v161 and v162 then
		local v163 = v_u_15.priceText(v161.price)
		local v164 = v162:FindFirstChild("PriceTag")
		if v164 and v164:IsA("TextLabel") then
			v164.Text = v163
		end
		local v165 = v_u_23.struck(v161.price, v_u_23.packWorth(v_u_21.starter, v_u_22.products))
		if p156 then
			p156.Visible = v165 ~= nil
			p156.Text = not v165 and "" or tostring(v165)
		end
	end
end
local function v_u_173() -- name: calm
	-- upvalues: (copy) v_u_16, (copy) v_u_1, (copy) v_u_28, (copy) v_u_15, (copy) v_u_10, (ref) v_u_31, (ref) v_u_30
	if not v_u_16.known() or v_u_16.active() then
		return false
	end
	if v_u_1.MenuIsOpen or v_u_28:GetAttribute("InWave") == true then
		return false
	end
	if v_u_15.sincePrompt() < 4 or v_u_10.current() ~= nil then
		return false
	end
	for _, v167 in v_u_31:GetChildren() do
		if not (v167:IsA("GuiObject") and v167.Visible) then
			continue
		end
		return false
	end
	local v168 = v_u_30:FindFirstChild("HUD")
	if v168 then
		v168 = v168:FindFirstChild("Overlay")
	end
	if v168 then
		v168 = v168:FindFirstChild("Hatch")
	end
	if v168 and (v168:IsA("GuiObject") and v168.Visible) then
		return false
	end
	if v_u_30:FindFirstChild("GiftPopUp") then
		return false
	end
	local v169 = v_u_30:FindFirstChild("GiftPicker")
	if v169 and (v169:IsA("GuiObject") and v169.Visible) then
		return false
	end
	local v170 = v_u_28:FindFirstChildOfClass("PlayerGui")
	for _, v171 in { "Odds", "Revive", "Arcade" } do
		local v172
		if v170 then
			v172 = v170:FindFirstChild(v171)
		else
			v172 = v170
		end
		if not (v172 and (v172:IsA("ScreenGui") and v172.Enabled)) then
			continue
		end
		return false
	end
	return true
end
local v_u_174 = false
local v_u_175 = ""
local v_u_176 = false
local v_u_177 = (-1 / 0)
local function v_u_200() -- name: bindStarter
	-- upvalues: (copy) v_u_154, (ref) v_u_110, (ref) v_u_111, (copy) v_u_15, (copy) v_u_16, (copy) v_u_14, (copy) v_u_28, (ref) v_u_174, (ref) v_u_175, (copy) v_u_173, (copy) v_u_166, (copy) v_u_10, (copy) v_u_13, (ref) v_u_176, (copy) v_u_11, (copy) v_u_112, (copy) v_u_4, (ref) v_u_177
	local v178, v179, v180 = v_u_154("StarterOffer", "Starter Pack", true)
	v_u_110 = v178
	v_u_111 = v180
	local v_u_181 = v_u_110
	if v_u_181 then
		if v179 then
			v179.Activated:Connect(function()
				-- upvalues: (ref) v_u_15
				v_u_15.buyPass("starter", "Starter")
			end)
		end
		local v_u_182 = false
		v_u_16.onChange(function(p183)
			-- upvalues: (ref) v_u_14, (ref) v_u_28, (ref) v_u_182, (ref) v_u_174, (ref) v_u_175, (ref) v_u_15, (ref) v_u_173, (ref) v_u_110, (ref) v_u_166, (ref) v_u_111, (ref) v_u_10, (ref) v_u_13, (ref) v_u_176, (ref) v_u_11
			if p183 == "done" then
				if v_u_182 then
					v_u_182 = false
					if not v_u_174 and v_u_28:GetAttribute("Pass_starter") ~= true then
						if v_u_175 == "starter" then
							return
						end
						v_u_174 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_15, (ref) v_u_28, (ref) v_u_173, (ref) v_u_110, (ref) v_u_166, (ref) v_u_111, (ref) v_u_10, (ref) v_u_13, (ref) v_u_176, (ref) v_u_11
							local v184 = os.clock()
							task.wait(5)
							while os.clock() - v184 < 300 do
								local v185 = v_u_15.pass("starter")
								if v_u_28:GetAttribute("Pass_starter") == true or (not v185 or v185.id == 0) then
									return
								end
								if v_u_173() then
									task.wait(1.5)
									local v186 = v_u_110
									if v186 and v_u_173() and v_u_28:GetAttribute("Pass_starter") ~= true then
										v_u_166(v186, v_u_111)
										v_u_10.open("StarterOffer")
										v_u_13.play("RevealBig", {
											["volume"] = 0.5
										})
										v_u_176 = true
										v_u_11.shown("Starter", "pass", "starter")
										return
									end
								end
								task.wait(0.5)
							end
						end)
					end
				end
			elseif v_u_14.number("Rebirths") == 0 and v_u_28:GetAttribute("TutorialDone") ~= true then
				v_u_182 = true
				return
			end
		end)
		v_u_28:GetAttributeChangedSignal("Pass_starter"):Connect(function()
			-- upvalues: (ref) v_u_28, (ref) v_u_10
			if v_u_28:GetAttribute("Pass_starter") == true and v_u_10.current() == "StarterOffer" then
				v_u_10.close()
			end
		end)
		v_u_15.randomChanged:Connect(function()
			-- upvalues: (copy) v_u_181, (ref) v_u_166, (ref) v_u_111
			task.defer(function()
				-- upvalues: (ref) v_u_181, (ref) v_u_166, (ref) v_u_111
				if v_u_181.Visible then
					v_u_166(v_u_181, v_u_111)
				end
			end)
		end)
		local v_u_187 = {}
		for _, v188 in v_u_112 do
			local v189 = Instance.new("UIScale")
			v189.Name = "Beat"
			v189.Parent = v188
			table.insert(v_u_187, v189)
		end
		local v_u_190 = nil
		v_u_181:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (ref) v_u_190, (copy) v_u_181, (ref) v_u_4, (copy) v_u_187, (ref) v_u_176, (ref) v_u_177
			local v191 = v_u_190
			if v_u_181.Visible and not v191 then
				v_u_190 = v_u_4.RenderStepped:Connect(function()
					-- upvalues: (ref) v_u_187
					local v192 = os.clock()
					for v193, v194 in v_u_187 do
						local v195 = v192 * 5 + v193 * 1.7
						local v196 = math.sin(v195)
						v194.Scale = math.max(v196, 0) * 0.07 + 1
					end
				end)
			elseif not v_u_181.Visible and v191 then
				v191:Disconnect()
				v_u_190 = nil
			end
			if not v_u_181.Visible and v_u_176 then
				v_u_177 = os.clock()
			end
		end)
		if v_u_4:IsStudio() then
			v_u_28:GetAttributeChangedSignal("DevStarterOffer"):Connect(function()
				-- upvalues: (ref) v_u_28, (ref) v_u_174, (ref) v_u_175, (ref) v_u_15, (ref) v_u_173, (ref) v_u_110, (ref) v_u_166, (ref) v_u_111, (ref) v_u_10, (ref) v_u_13, (ref) v_u_176, (ref) v_u_11
				if v_u_28:GetAttribute("DevStarterOffer") == true then
					v_u_28:SetAttribute("DevStarterOffer", nil)
					v_u_174 = false
					if not v_u_174 and v_u_28:GetAttribute("Pass_starter") ~= true then
						if v_u_175 == "starter" then
							return
						end
						v_u_174 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_15, (ref) v_u_28, (ref) v_u_173, (ref) v_u_110, (ref) v_u_166, (ref) v_u_111, (ref) v_u_10, (ref) v_u_13, (ref) v_u_176, (ref) v_u_11
							local v197 = os.clock()
							task.wait(5)
							while os.clock() - v197 < 300 do
								local v198 = v_u_15.pass("starter")
								if v_u_28:GetAttribute("Pass_starter") == true or (not v198 or v198.id == 0) then
									return
								end
								if v_u_173() then
									task.wait(1.5)
									local v199 = v_u_110
									if v199 and v_u_173() and v_u_28:GetAttribute("Pass_starter") ~= true then
										v_u_166(v199, v_u_111)
										v_u_10.open("StarterOffer")
										v_u_13.play("RevealBig", {
											["volume"] = 0.5
										})
										v_u_176 = true
										v_u_11.shown("Starter", "pass", "starter")
										return
									end
								end
								task.wait(0.5)
							end
						end)
					end
				end
			end)
		end
	end
end
local v_u_201 = Color3.fromRGB(176, 176, 188)
local v_u_202 = Color3.fromRGB(112, 112, 128)
local v_u_203 = nil
local v_u_204 = nil
local v_u_205 = nil
local v_u_206 = ""
local v_u_207 = false
local function v_u_209(p208) -- name: ownsPass
	-- upvalues: (copy) v_u_28
	return v_u_28:GetAttribute("Pass_" .. p208) == true
end
local function v_u_215(p210, p211, p212) -- name: setTitle
	local v213 = p210:FindFirstChild("Top")
	if v213 then
		for _, v214 in v213:GetChildren() do
			if v214:IsA("TextLabel") then
				v214.Text = p211
			else
				if not v214:IsA("ImageLabel") or v214.Name ~= "Icon" then
					continue
				end
				v214.Image = p212
			end
		end
	end
end
local function v_u_235(p216) -- name: fillNext
	-- upvalues: (ref) v_u_203, (ref) v_u_206, (ref) v_u_205, (copy) v_u_215, (copy) v_u_20, (copy) v_u_166, (ref) v_u_204, (copy) v_u_15, (copy) v_u_24, (copy) v_u_209, (copy) v_u_25
	local v217 = v_u_203
	if v217 then
		v_u_206 = p216
		local v218 = v_u_205
		if p216 == "starter" then
			v_u_215(v217, "Starter Pack", v_u_20.Icon.Deal)
			if v218 then
				v218.Visible = false
			end
			v_u_166(v217, v_u_204)
			return
		else
			local v219 = v217:FindFirstChild("Tiles")
			if v219 then
				v219:Destroy()
			end
			local v220 = v_u_15.pass(p216)
			if v220 then
				v_u_215(v217, v220.name, v_u_20.Icon.BoostChakra)
				local v221 = v_u_24.gain(v220, v_u_209)
				local v222 = ("x%* CHAKRA"):format(v220.mult or 1)
				local v223 = v_u_25.mult(v221)
				local v224 = ("%*x MORE THAN NOW"):format((string.sub(v223, 2)))
				if v218 then
					v218.Visible = true
					local v225 = v218:FindFirstChild("Tile")
					if v225 then
						local v226 = ("x%* Chakra"):format(v220.mult or 1)
						local v227 = v225:FindFirstChild("Count")
						if v227 and v227:IsA("TextLabel") then
							v227.Text = v226
						end
						local v228 = v225:FindFirstChild("Name")
						if v228 and v228:IsA("TextLabel") then
							v228.Text = "Forever"
						end
					end
					local v229 = v218:FindFirstChild("Name")
					if v229 and v229:IsA("TextLabel") then
						v229.Text = v222
					end
					local v230 = v218:FindFirstChild("Gain")
					if v230 and v230:IsA("TextLabel") then
						v230.Text = v224
					end
				end
				local v231 = v217:FindFirstChild("Buy")
				if v231 then
					local v232 = v_u_15.priceText(v220.price)
					local v233 = v231:FindFirstChild("PriceTag")
					if v233 and v233:IsA("TextLabel") then
						v233.Text = v232
					end
				end
				local v234 = v_u_204
				if v234 then
					v234.Visible = false
				end
			end
		end
	else
		return
	end
end
local function v_u_255() -- name: buildNext
	-- upvalues: (copy) v_u_154, (ref) v_u_203, (ref) v_u_204, (copy) v_u_201, (copy) v_u_202, (ref) v_u_206, (copy) v_u_15, (copy) v_u_10, (ref) v_u_31, (copy) v_u_41, (copy) v_u_78, (copy) v_u_20, (copy) v_u_66, (ref) v_u_205, (copy) v_u_28, (copy) v_u_235
	local v_u_236, v237, v238 = v_u_154("NextStepOffer", "Starter Pack", false)
	if v_u_236 and v237 then
		v_u_203 = v_u_236
		v_u_204 = v238
		v237.Position = UDim2.fromScale(0.845, 0.5)
		v237.Size = UDim2.fromScale(0.26, 0.3)
		local v239 = v237:Clone()
		v239.Name = "NoThanks"
		local v240 = v239:FindFirstChild("Was")
		if v240 then
			v240:Destroy()
		end
		v239.Position = UDim2.fromScale(0.845, 0.82)
		v239.Size = UDim2.fromScale(0.22, 0.19)
		local v241 = v_u_201
		local v242 = v_u_202
		local v243 = v239:FindFirstChildOfClass("UIGradient")
		if v243 then
			v243.Color = ColorSequence.new(v241, v242)
		end
		local v244 = v239:FindFirstChild("PriceTag")
		if v244 and v244:IsA("TextLabel") then
			v244.Text = "NO THANKS"
		end
		v239.Parent = v_u_236
		v237.Activated:Connect(function()
			-- upvalues: (ref) v_u_206, (ref) v_u_15
			if v_u_206 ~= "" then
				v_u_15.buyPass(v_u_206, "NextStep")
			end
		end)
		v239.Activated:Connect(function()
			-- upvalues: (ref) v_u_10
			if v_u_10.current() == "NextStepOffer" then
				v_u_10.close()
			end
		end)
		local v245 = v_u_31:FindFirstChild("Store")
		if v245 then
			v245 = v245:FindFirstChild("Pack_starter", true)
		end
		local v246
		if v245 then
			v246 = v245:FindFirstChild("Tiles")
		else
			v246 = v245
		end
		if v246 then
			v246 = v246:FindFirstChild("Tile1")
		end
		local v247 = Instance.new("Frame")
		v247.Name = "Rung"
		v247.BackgroundTransparency = 1
		v247.AnchorPoint = Vector2.new(0, 0.5)
		v247.Position = UDim2.fromScale(0.03, 0.62)
		v247.Size = UDim2.fromScale(0.64, 0.66)
		v247.Visible = false
		if v246 and v246:IsA("GuiObject") then
			local v248 = v246:Clone()
			v_u_41(v248)
			v248.Name = "Tile"
			v248.AnchorPoint = Vector2.new(0, 0.5)
			v248.Position = UDim2.fromScale(0, 0.5)
			v248.Size = UDim2.fromScale(0.3, 1)
			v_u_78(v248, v_u_20.Icon.BoostChakra, "x4 Chakra", "Forever", v_u_66.chakra)
			v248.Parent = v247
		end
		local v249 = nil
		if v245 then
			for _, v250 in v245:GetChildren() do
				if not v250:IsA("TextLabel") or (v250.Name ~= "Title" or v250.Rotation ~= 0) then
					continue
				end
				v249 = v250
			end
		end
		for _, v251 in {
			{
				["name"] = "Name",
				["y"] = 0.32,
				["h"] = 0.36,
				["color"] = nil,
				["color"] = Color3.fromRGB(255, 232, 60)
			},
			{
				["name"] = "Gain",
				["y"] = 0.7,
				["h"] = 0.26,
				["color"] = nil,
				["color"] = Color3.fromRGB(255, 255, 255)
			}
		} do
			local v252
			if v249 then
				v252 = v249:Clone()
			else
				v252 = Instance.new("TextLabel")
			end
			v252.Name = v251.name
			v252.BackgroundTransparency = 1
			v252.AnchorPoint = Vector2.new(0, 0.5)
			v252.Position = UDim2.fromScale(0.36, v251.y)
			v252.Size = UDim2.fromScale(0.64, v251.h)
			v252.TextScaled = true
			v252.TextXAlignment = Enum.TextXAlignment.Left
			v252.TextColor3 = v251.color
			v252.Rotation = 0
			v252.ZIndex = 8
			local v253 = v252:FindFirstChildOfClass("UIGradient")
			if v253 then
				v253:Destroy()
			end
			v252.Parent = v247
		end
		v247.Parent = v_u_236
		v_u_205 = v247
		v_u_28.AttributeChanged:Connect(function(p254)
			-- upvalues: (ref) v_u_206, (ref) v_u_28, (ref) v_u_10
			if v_u_206 ~= "" and p254 == "Pass_" .. v_u_206 and (v_u_28:GetAttribute("Pass_" .. v_u_206) == true and v_u_10.current() == "NextStepOffer") then
				v_u_10.close()
			end
		end)
		v_u_15.pricesChanged:Connect(function()
			-- upvalues: (copy) v_u_236, (ref) v_u_206, (ref) v_u_235
			if v_u_236.Visible and v_u_206 ~= "" then
				v_u_235(v_u_206)
			end
		end)
	end
end
local function v_u_261() -- name: queueNext
	-- upvalues: (ref) v_u_207, (copy) v_u_24, (copy) v_u_14, (copy) v_u_4, (copy) v_u_28, (copy) v_u_15, (copy) v_u_18, (ref) v_u_176, (ref) v_u_177, (copy) v_u_173, (copy) v_u_12, (ref) v_u_203, (copy) v_u_235, (copy) v_u_10, (copy) v_u_13, (ref) v_u_175, (copy) v_u_11
	if not v_u_207 and v_u_24.pending(v_u_14.string("NextStep")) then
		v_u_207 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_28, (ref) v_u_14, (ref) v_u_24, (ref) v_u_15, (ref) v_u_18, (ref) v_u_176, (ref) v_u_177, (ref) v_u_173, (ref) v_u_12, (ref) v_u_203, (ref) v_u_235, (ref) v_u_10, (ref) v_u_13, (ref) v_u_175, (ref) v_u_11, (ref) v_u_207
			local v256 = os.clock()
			while os.clock() - v256 < 45 and (not v_u_4:IsStudio() or v_u_28:GetAttribute("DevNextStep") ~= true) do
				task.wait(1)
			end
			while true do
				local v257 = v_u_14.string("NextStep")
				if not v_u_24.pending(v257) then
					break
				end
				local v258 = v_u_15.pass(v257)
				if not v258 or (v258.id == 0 or v258.retired) or v_u_28:GetAttribute("Pass_" .. v257) == true then
					task.spawn(function()
						-- upvalues: (ref) v_u_18
						v_u_18.event("NextStep"):FireServer("seen")
					end)
					break
				end
				if v257 == "starter" and v_u_176 then
					task.spawn(function()
						-- upvalues: (ref) v_u_18
						v_u_18.event("NextStep"):FireServer("seen")
					end)
					break
				end
				if v_u_28:GetAttribute("PassesReady") == true and os.clock() - v_u_177 > 120 then
					local v259 = v_u_173()
					if v259 then
						if v_u_28:GetAttribute("InStages") == true or v_u_28:GetAttribute("Downed") == true then
							v259 = false
						else
							v259 = not v_u_12.fighting()
						end
					end
					if v259 then
						task.wait(1.5)
						if v_u_203 then
							local v260 = v_u_173()
							if v260 then
								if v_u_28:GetAttribute("InStages") == true or v_u_28:GetAttribute("Downed") == true then
									v260 = false
								else
									v260 = not v_u_12.fighting()
								end
							end
							if v260 and v_u_28:GetAttribute("Pass_" .. v257) ~= true then
								v_u_235(v257)
								v_u_10.open("NextStepOffer")
								v_u_13.play("RevealBig", {
									["volume"] = 0.5
								})
								v_u_175 = v257
								v_u_11.shown("NextStep", "pass", v257)
								task.spawn(function()
									-- upvalues: (ref) v_u_18
									v_u_18.event("NextStep"):FireServer("seen")
								end)
								break
							end
						end
					end
				end
				task.wait(0.5)
			end
			v_u_207 = false
		end)
	end
end
function v27.start(p262) -- name: start
	-- upvalues: (ref) v_u_29, (ref) v_u_30, (copy) v_u_28, (ref) v_u_31, (copy) v_u_107, (copy) v_u_65, (copy) v_u_200, (copy) v_u_255, (ref) v_u_203, (copy) v_u_14, (copy) v_u_261
	v_u_29 = p262
	v_u_30 = v_u_28:WaitForChild("PlayerGui"):WaitForChild("Main")
	v_u_31 = v_u_30:WaitForChild("Frames")
	v_u_107()
	v_u_65()
	v_u_200()
	v_u_255()
	if v_u_203 then
		v_u_14.watch("NextStep", v_u_261)
		v_u_261()
	end
end
return v27