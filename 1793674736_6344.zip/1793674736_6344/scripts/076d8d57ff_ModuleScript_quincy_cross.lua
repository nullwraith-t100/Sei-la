local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(80, 150, 255)
local v_u_7 = Color3.fromRGB(150, 200, 255)
local v_u_8 = Color3.fromHex("F4F8FF")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_19(p11, p12) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v13 = v_u_2:FindFirstChild("EyePieces")
	if v13 then
		v13 = v13:FindFirstChild(p11)
	end
	if not (v13 and v13:IsA("MeshPart")) then
		return nil
	end
	local v14 = v13:Clone()
	local v15 = v13.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	v14.Size = v15 * (p12 / math.max(v16, v17, v18, 0.01))
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanQuery = false
	v14.CanTouch = false
	v14.Massless = true
	v14.CastShadow = false
	v14.Parent = v_u_3.folder()
	return v14
end
return function(p_u_20)
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1, (copy) v_u_6, (copy) v_u_19, (copy) v_u_8, (copy) v_u_4
	return {
		["w6_quincy_cross"] = function(p_u_21, p22)
			-- upvalues: (ref) v_u_3, (copy) p_u_20, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1, (ref) v_u_6, (ref) v_u_19, (ref) v_u_8, (ref) v_u_4
			local v23 = v_u_3.color(p22.color)
			local v24 = p_u_21.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v_u_26 = CFrame.identity
			local v_u_34 = p_u_20.throb(p_u_21, 4, 1.4, 1.8, function(p27)
				-- upvalues: (ref) v_u_3, (ref) p_u_20, (copy) p_u_21, (ref) v_u_7, (ref) v_u_5, (copy) v_u_25, (ref) v_u_9, (ref) v_u_26, (ref) v_u_10, (ref) v_u_1
				v_u_3.ring(p_u_20.feetAt(p_u_21, p27, 0.15), v_u_7, 5.5 * p_u_21.fx, 0.5, v_u_5.Ring)
				local v28 = p_u_20.picture(v_u_25 * 1.5, v_u_5.QuincyPentacle, v_u_9, 0)
				v28.CFrame = v_u_26 * CFrame.new(0, 0, v_u_25 * -0.3) * v_u_10
				local v29 = v_u_3.tween
				local v30 = {}
				local v31 = v_u_25 * 5.5
				local v32 = v_u_25 * 5.5
				v30.Size = Vector3.new(v31, 0.05, v32)
				v29(v28, 0.5, v30)
				for _, v33 in v28:GetChildren() do
					if not v33:IsA("Decal") then
						continue
					end
					v_u_3.tween(v33, 0.5, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
				v_u_1:AddItem(v28, 0.55)
			end)
			local v52 = p_u_20.group(p_u_21, function(p35, p36)
				-- upvalues: (copy) v_u_25, (copy) v_u_34, (ref) v_u_26
				local v37 = CFrame.new
				local v38 = v_u_25 * -2.4
				local v39 = v_u_25 * 1
				local v40 = p36 * 1.6
				local v41 = p35 * v37(v38, v39 + math.sin(v40) * 0.15 * v_u_25, v_u_25 * 0.5)
				local v42 = CFrame.Angles
				local v43 = 0
				local v44 = p36 * 0.7
				local v45 = math.sin(v44) * 0.25
				local v46 = v_u_34()
				local v47
				if v46 <= 0 then
					v47 = 0
				else
					local v48 = 1 - v46
					v47 = v48 * v48 * (3 - 2 * v48) * 3.141592653589793 * 2
				end
				local v49 = v45 + v47
				local v50 = p36 * 1.1
				local v51 = v41 * v42(v43, v49, math.sin(v50) * 0.08)
				v_u_26 = v51
				return v51
			end)
			local v_u_53 = p_u_20.picture(v_u_25 * 7.5, v_u_5.Glow, v_u_6, 0.3)
			p_u_20.pin(p_u_21, v52, v_u_53, CFrame.new(0, 0, v_u_25 * -0.35) * v_u_10)
			local v54 = v_u_19("w6_quincy_cross", v_u_25 * 3.2)
			local v_u_55 = nil
			local v_u_56 = 1
			if v54 then
				local v57 = v54:FindFirstChildOfClass("SurfaceAppearance")
				if v57 then
					v_u_56 = v57.EmissiveStrength
				else
					v54.Color = v_u_7
					v54.Material = Enum.Material.Glass
					v54.Transparency = 0.1
					v57 = v_u_55
				end
				p_u_20.pin(p_u_21, v52, v54, CFrame.identity)
				v_u_55 = v57
			else
				for v58 = 0, 4 do
					local v59 = 1.5707963267948966 + v58 * 3.141592653589793 * 2 / 5
					local v60 = (v58 == 0 and 0.9 or 0.75) * v_u_25
					if v58 == 2 or v58 == 3 then
						v60 = v_u_25 * 0.85
					end
					local v61 = p_u_20.bar
					local v62 = v_u_25 * 0.2
					local v63 = v_u_25 * 0.12
					local v64 = v61(Vector3.new(v62, v60, v63), v_u_8)
					p_u_20.pin(p_u_21, v52, v64, CFrame.Angles(0, 0, v59 - 1.5707963267948966) * CFrame.new(0, v60 / 2 + v_u_25 * 0.1, 0))
				end
				p_u_20.pin(p_u_21, v52, p_u_20.ball(v_u_25 * 0.4, v_u_7), CFrame.identity)
			end
			local v_u_65 = p_u_20.picture(v_u_25 * 4, v_u_5.Ring, v_u_7, 0)
			p_u_20.add(p_u_21, v_u_65, function(_, p66)
				-- upvalues: (copy) v_u_34, (copy) v_u_65, (copy) v_u_25, (ref) v_u_26
				local v67 = v_u_34() * 3.141592653589793
				local v68 = math.sin(v67) * 0.5 + 1
				local v69 = v_u_65
				local v70 = v_u_25 * 4 * v68
				local v71 = v_u_25 * 4 * v68
				v69.Size = Vector3.new(v70, 0.05, v71)
				return v_u_26 * CFrame.Angles(0.35, p66 * 1.3, 0) * CFrame.Angles(p66 * 1.7, 0, 0)
			end)
			local v_u_72 = p_u_20.picture(v_u_25 * 3.2, v_u_5.Ring, v_u_8, 0.1)
			p_u_20.add(p_u_21, v_u_72, function(_, p73)
				-- upvalues: (copy) v_u_34, (copy) v_u_72, (copy) v_u_25, (ref) v_u_26
				local v74 = v_u_34() * 3.141592653589793
				local v75 = math.sin(v74) * 0.4 + 1
				local v76 = v_u_72
				local v77 = v_u_25 * 3.2 * v75
				local v78 = v_u_25 * 3.2 * v75
				v76.Size = Vector3.new(v77, 0.05, v78)
				return v_u_26 * CFrame.Angles(0, 0, -p73 * 1.9) * CFrame.Angles(1.8707963267948966, 0, 0)
			end)
			local v79 = p_u_20.ball(v_u_25 * 5, v_u_9, 1)
			p_u_20.add(p_u_21, v79, function()
				-- upvalues: (ref) v_u_26
				return v_u_26
			end)
			local v80 = Instance.new("ParticleEmitter")
			v80.Texture = v_u_5.Glow
			v80.Color = ColorSequence.new(v_u_6, v_u_8)
			v80.LightEmission = 0.8
			v80.LightInfluence = 0
			v80.Lifetime = NumberRange.new(0.55, 0.7)
			v80.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.3, v_u_25 * 0.9 * p_u_21.fx), NumberSequenceKeypoint.new(1, v_u_25 * 0.25) })
			v80.Speed = NumberRange.new(v_u_25 * 3.6, v_u_25 * 4.4)
			v80.Shape = Enum.ParticleEmitterShape.Sphere
			v80.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v80.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
			v80.Rate = 12 * v_u_4.formRate() * (p_u_21.fx > 1 and 1.6 or 1)
			v80.Parent = v79
			p_u_20.own(p_u_21, v80)
			local v_u_81 = -1
			local v82 = p_u_21.ticks
			local function v87()
				-- upvalues: (copy) v_u_34, (ref) v_u_81, (copy) v_u_25, (copy) v_u_53, (ref) v_u_55, (ref) v_u_56
				local v83 = v_u_34()
				local v84 = v83 - v_u_81
				if math.abs(v84) >= 0.01 then
					v_u_81 = v83
					local v85 = v_u_25 * 7.5 * (1 + v83 * 0.4)
					v_u_53.Size = Vector3.new(v85, 0.05, v85)
					local v86 = v_u_55
					if v86 then
						v86.EmissiveStrength = v_u_56 * (1 + v83 * 1.5)
					end
				end
			end
			table.insert(v82, v87)
			p_u_20.particles(p_u_21, "AuraMode", v23:Lerp(v_u_6, 0.6), {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end