local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF8A00")
local v_u_9 = Color3.fromHex("FFE14B")
local v_u_10 = Color3.fromRGB(14, 9, 8)
local v_u_11 = Color3.fromRGB(255, 250, 215)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(205, 240, 255)
local v_u_14 = Color3.fromRGB(110, 200, 255)
local v_u_15 = Color3.fromRGB(45, 140, 255)
local v_u_16 = Color3.fromRGB(10, 4, 18)
local v_u_17 = Color3.fromRGB(70, 18, 120)
local v_u_18 = Color3.fromRGB(150, 60, 255)
local v_u_19 = Color3.fromRGB(205, 165, 255)
local v_u_20 = Enum.PartType.Ball
local function v_u_32(p21, p22, p23, p24, p25) -- name: disc
	-- upvalues: (copy) v_u_5
	local v26 = v_u_5.part
	local v27 = p22 * 2
	local v28 = p22 * 2
	local v29 = v26(Vector3.new(v27, 0.05, v28), p21, p24, {
		["transparency"] = 1
	})
	for _, v30 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v31 = Instance.new("Decal")
		v31.Face = v30
		v31.Texture = p23
		v31.Color3 = p24
		v31.Transparency = p25
		v31.Parent = v29
	end
	return v29
end
local function v_u_36(p33, p34) -- name: fadeDecals
	for _, v35 in p33:GetChildren() do
		if not v35:IsA("Decal") then
			continue
		end
		v35.Transparency = p34
	end
end
local function v_u_37() -- name: newBody
	return {
		["parts"] = nil,
		["offs"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["cfs"] = nil,
		["k"] = -1,
		["f"] = -1,
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {},
		["alphas"] = {},
		["cfs"] = {}
	}
end
local function v_u_55(p38, p39, p40, p41, p42, p43, p44, p45) -- name: piece
	-- upvalues: (copy) v_u_5, (copy) v_u_20, (copy) v_u_1
	local v46 = v_u_5.part
	local v47 = {
		["shape"] = nil,
		["material"] = nil,
		["transparency"] = 1
	}
	local v48
	if p39 == "ball" then
		v48 = v_u_20
	elseif p39 == "wedge" then
		v48 = Enum.PartType.Wedge
	else
		v48 = nil
	end
	v47.shape = v48
	v47.material = p45
	local v49 = v46(p40, p41, p42, v47)
	if p39 == "egg" then
		local v50 = Instance.new("SpecialMesh")
		v50.MeshType = Enum.MeshType.Sphere
		v50.Parent = v49
	end
	v_u_1:AddItem(v49, p44)
	local v51 = p38.parts
	table.insert(v51, v49)
	local v52 = p38.offs
	table.insert(v52, p41)
	local v53 = p38.sizes
	table.insert(v53, p40)
	local v54 = p38.alphas
	table.insert(v54, p43)
	return v49
end
local function v_u_74(p56, p57, p58, p59) -- name: placeBody
	-- upvalues: (copy) v_u_4
	local v60 = math.max(p58, 0.02)
	local v61 = math.clamp(p59, 0, 1)
	local v62 = p56.parts
	local v63 = p56.offs
	local v64 = p56.cfs
	for v65 = 1, #v62 do
		local v66 = v63[v65]
		v64[v65] = p57 * (v66 - v66.Position + v66.Position * v60)
	end
	v_u_4:BulkMoveTo(v62, v64, Enum.BulkMoveMode.FireCFrameChanged)
	local v67 = v60 - p56.k
	if math.abs(v67) > 0.0001 then
		p56.k = v60
		for v68, v69 in v62 do
			v69.Size = p56.sizes[v68] * v60
		end
	end
	local v70 = v61 - p56.f
	if math.abs(v70) > 0.001 then
		p56.f = v61
		for v71, v72 in v62 do
			local v73 = p56.alphas[v71]
			v72.Transparency = v73 + (1 - v73) * v61
		end
	end
end
local function v_u_86(p75, p76, p77, p78, p79, p80, p81, p82) -- name: triangle
	-- upvalues: (copy) v_u_55
	for _, v83 in { -1, 1 } do
		local v84 = v_u_55
		local v85 = p77 / 2
		v84(p75, "wedge", Vector3.new(p79, p78, v85), p76 * CFrame.new(v83 * p77 / 4, p78 / 2, 0) * CFrame.Angles(0, -v83 * 3.141592653589793 / 2, 0), p80, p81, p82)
	end
end
return function(p_u_87)
	-- upvalues: (copy) v_u_32, (copy) v_u_1, (copy) v_u_36, (copy) v_u_5, (copy) v_u_14, (copy) v_u_12, (copy) v_u_20, (copy) v_u_7, (copy) v_u_15, (copy) v_u_13, (copy) v_u_4, (copy) v_u_37, (copy) v_u_55, (copy) v_u_74, (copy) v_u_86, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_16, (copy) v_u_18, (copy) v_u_17, (copy) v_u_19, (copy) v_u_2, (copy) v_u_8, (copy) v_u_6
	local function v_u_104(p_u_88, p_u_89, p_u_90, p91, p92, p_u_93, p_u_94, p95) -- name: flare
		-- upvalues: (ref) v_u_32, (ref) v_u_1, (copy) p_u_87, (ref) v_u_36
		local v_u_96 = p95 or 0
		local v_u_97 = v_u_32(p_u_88, p_u_89, p91, p92, v_u_96)
		v_u_1:AddItem(v_u_97, p_u_93 + 0.1)
		p_u_87.animate(p_u_93, 0, function(p98)
			-- upvalues: (copy) p_u_89, (copy) p_u_90, (copy) v_u_97, (copy) p_u_88, (copy) p_u_93, (copy) p_u_94, (ref) v_u_36, (copy) v_u_96
			local v99 = 1 - (1 - p98) ^ 3
			local v100 = p_u_89 + (p_u_90 - p_u_89) * v99
			local v101 = v_u_97
			local v102 = v100 * 2
			local v103 = v100 * 2
			v101.Size = Vector3.new(v102, 0.05, v103)
			v_u_97.CFrame = p_u_88 * CFrame.Angles(0, p98 * p_u_93 * p_u_94, 0)
			v_u_36(v_u_97, v_u_96 + (1 - v_u_96) * p98 ^ 1.5)
			if p98 >= 1 then
				v_u_97:Destroy()
			end
		end)
	end
	local function v133(p105, p106) -- name: rasenganShot
		-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_12, (ref) v_u_20, (ref) v_u_32, (ref) v_u_7, (ref) v_u_15, (copy) p_u_87, (ref) v_u_13, (ref) v_u_1, (ref) v_u_4
		local v_u_107 = p105.size
		local v_u_108 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p106, v_u_14, {
			["transparency"] = 1
		})
		local v109 = {
			["shape"] = v_u_20
		}
		local v_u_110 = v_u_5.part(Vector3.new(1.15, 1.15, 1.15) * v_u_107, p106, v_u_12, v109)
		local v111 = {
			["shape"] = nil,
			["transparency"] = 0.5,
			["shape"] = v_u_20
		}
		local v_u_112 = v_u_5.part(Vector3.new(2.4, 2.4, 2.4) * v_u_107, p106, v_u_14, v111)
		local v_u_113 = v_u_32(p106, 1.55 * v_u_107, v_u_7.Swirl, v_u_12, 0)
		local v_u_114 = { v_u_110, v_u_112, v_u_113 }
		local v_u_115, v_u_116
		if p105.lite then
			v_u_115 = nil
			v_u_116 = nil
		else
			local v117 = v_u_32(p106, 1.6 * v_u_107, v_u_7.Ring, v_u_12, 0.1)
			table.insert(v_u_114, v117)
			v_u_115 = v117
			v_u_116 = v_u_32(p106, 1.9 * v_u_107, v_u_7.Swirl, v_u_15, 0.15)
			table.insert(v_u_114, v_u_116)
			p_u_87.streak(v_u_108, v_u_12, v_u_13, 0.5 * v_u_107, 0.09)
		end
		p_u_87.streak(v_u_108, v_u_13, v_u_15, 1.8 * v_u_107, 0.14)
		if p105.mine then
			p_u_87.light(v_u_108, v_u_14, 9 * v_u_107)
		end
		for _, v118 in v_u_114 do
			v_u_1:AddItem(v118, 3)
		end
		v_u_1:AddItem(v_u_108, 3)
		local v_u_119 = false
		return {
			["place"] = function(p120, p121) -- name: place
				-- upvalues: (copy) v_u_108, (copy) v_u_110, (copy) v_u_112, (copy) v_u_107, (ref) v_u_4, (copy) v_u_113, (ref) p_u_87, (ref) v_u_116, (ref) v_u_115
				local v122 = p120.Position
				v_u_108.CFrame = p120
				v_u_110.CFrame = p120
				v_u_112.CFrame = p120
				local v123 = v_u_112
				local v124 = Vector3.new(2.4, 2.4, 2.4) * v_u_107
				local v125 = p121 * 70
				v123.Size = v124 * (math.sin(v125) * 0.08 + 1)
				local v126 = v_u_4.CurrentCamera
				local v127
				if v126 then
					local v128 = v126.CFrame.Position - v122
					v127 = v128.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v128.Unit
				else
					v127 = Vector3.new(0, 0, 1)
				end
				v_u_113.CFrame = p_u_87.facing(v122 + v127 * 1.3 * v_u_107, v127) * CFrame.Angles(0, -p121 * 34, 0)
				local v129 = v_u_116
				if v129 then
					v129.CFrame = p_u_87.facing(v122 + v127 * 1.1 * v_u_107, v127) * CFrame.Angles(0, p121 * 22, 0)
				end
				local v130 = v_u_115
				if v130 then
					v130.CFrame = p120 * CFrame.Angles(1.1, p121 * 9, 0) * CFrame.Angles(0, p121 * 30, 0)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_119, (copy) v_u_108, (ref) v_u_1, (copy) v_u_114
				if not v_u_119 then
					v_u_119 = true
					local v131 = v_u_108:FindFirstChildWhichIsA("PointLight")
					if v131 then
						v131:Destroy()
					end
					v_u_1:AddItem(v_u_108, 0.16)
					for _, v132 in v_u_114 do
						v132:Destroy()
					end
				end
			end
		}
	end
	local function v140(p134, p135) -- name: rasenganImpact
		-- upvalues: (ref) v_u_4, (copy) v_u_104, (copy) p_u_87, (ref) v_u_7, (ref) v_u_13, (ref) v_u_14, (ref) v_u_12, (ref) v_u_5
		local v136 = p134.size
		local v137 = v_u_4.CurrentCamera
		local v138
		if v137 then
			local v139 = v137.CFrame.Position - p135
			v138 = v139.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v139.Unit
		else
			v138 = Vector3.new(0, 0, 1)
		end
		v_u_104(p_u_87.facing(p135, v138), 1.6 * v136, 6 * v136, v_u_7.Swirl, v_u_13, 0.24, -26)
		p_u_87.pop(p135, v_u_14, 2.4 * v136, 7 * v136, 0.18, 0.4)
		p_u_87.pop(p135, v_u_12, 1.6 * v136, 3.4 * v136, 0.1)
		p_u_87.burst("Impact", p135, v_u_14, 1 * v136)
		v_u_5.ring(p_u_87.ground(p135), v_u_13, p134.ability.radius * 0.75 * v136, 0.25, v_u_7.Ring)
		if not p134.lite then
			v_u_104(p_u_87.facing(p135 + v138 * 0.3, v138), 1 * v136, 4.5 * v136, v_u_7.Ring, v_u_12, 0.16, 0, 0.1)
			p_u_87.spikes(p135, v_u_12, 4, 5 * v136, 0.15, nil, nil, true)
		end
		p_u_87.hitSound(p135)
	end
	local v_u_141 = {}
	setmetatable(v_u_141, {
		["__mode"] = "k"
	})
	local function v_u_158(p142, p143) -- name: buildShuriken
		-- upvalues: (ref) v_u_37, (ref) v_u_55, (ref) v_u_12, (ref) v_u_14, (ref) v_u_13, (ref) v_u_32, (ref) v_u_7, (ref) v_u_1
		local v144 = v_u_37()
		v_u_55(v144, "ball", Vector3.new(1.9, 1.9, 1.9), CFrame.identity, v_u_12, 0, p143)
		v_u_55(v144, "ball", Vector3.new(3.6, 3.6, 3.6), CFrame.identity, v_u_14, 0.45, p143)
		for v145 = 0, 3 do
			local v146 = v145 * 3.141592653589793 / 2
			local v147 = math.cos(v146)
			local v148 = math.sin(v146)
			local v149 = Vector3.new(v147, 0, v148)
			local v150 = -math.sin(v146)
			local v151 = math.cos(v146)
			local v152 = Vector3.new(v150, 0, v151)
			local v153 = v_u_13
			local v154 = v149 * 3.1999999999999997 - v152 * 0.9
			v_u_55(v144, "wedge", Vector3.new(0.3, 1.8, 4.6), CFrame.fromMatrix(v154, Vector3.new(0, 1, 0), -v152), v153, 0.05, p143)
			if p142 then
				continue
			end
			local v155 = v_u_14
			local v156 = v149 * 3.476 - v152 * 1.305
			v_u_55(v144, "wedge", Vector3.new(0.6, 2.61, 5.152), CFrame.fromMatrix(v156, Vector3.new(0, 1, 0), -v152), v155, 0.6, p143)
		end
		local v157 = v_u_32(CFrame.identity, 0.1, v_u_7.Ring, v_u_12, 0)
		v_u_1:AddItem(v157, p143)
		return {
			["body"] = nil,
			["ring"] = nil,
			["taken"] = false,
			["body"] = v144,
			["ring"] = v157
		}
	end
	local function v_u_169(p159, p160, p161, p162, p163) -- name: placeShuriken
		-- upvalues: (ref) v_u_74, (ref) v_u_36
		local v164 = p160 * CFrame.Angles(0, p162, 0)
		v_u_74(p159.body, v164, p161, p163)
		local v165 = math.max(p161, 0.02) * 3.4299999999999997
		local v166 = p159.ring
		local v167 = v165 * 2
		local v168 = v165 * 2
		v166.Size = Vector3.new(v167, 0.05, v168)
		p159.ring.CFrame = v164
		v_u_36(p159.ring, p163 * 0.85 + 0.15)
	end
	local function v_u_179(p170, p171, p172) -- name: windArcs
		-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_12
		local v173 = {}
		for v174 = 1, p171 do
			local v175 = Instance.new("Attachment")
			v175.Parent = p170
			local v176 = Instance.new("Attachment")
			v176.Parent = p170
			local v177 = Instance.new("Beam")
			v177.Attachment0 = v175
			v177.Attachment1 = v176
			v177.Texture = v_u_7.Beam
			v177.TextureMode = Enum.TextureMode.Wrap
			v177.TextureLength = 5
			v177.TextureSpeed = 3
			v177.LightEmission = 0.6
			v177.LightInfluence = 0
			v177.Color = ColorSequence.new(v_u_14, v_u_12)
			v177.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.55, 0.35), NumberSequenceKeypoint.new(1, 0.05) })
			v177.FaceCamera = true
			v177.Segments = p172 and 6 or 10
			v177.Parent = p170
			local v178 = {
				["a0"] = v175,
				["a1"] = v176,
				["beam"] = v177,
				["at"] = v174 / p171 * 3.141592653589793 * 2,
				["span"] = v174 % 3 * 0.35 + 1.3,
				["h"] = v174 * 0.37 % 0.7 + 0.12
			}
			table.insert(v173, v178)
		end
		return v173
	end
	local function v_u_206(p180, p181, p182) -- name: shapeArcs
		for _, v183 in p180 do
			local v184 = v183.h * p181
			local v185 = p181 * p181 - v184 * v184
			local v186 = math.max(v185, 0)
			local v187 = math.sqrt(v186) * 0.98
			local v188 = v183.a0
			local v189 = v183.at
			local v190 = math.cos(v189) * v187
			local v191 = math.sin(v189) * v187
			local v192 = Vector3.new(v190, v184, v191)
			local v193 = -math.sin(v189)
			local v194 = math.cos(v189)
			local v195 = Vector3.new(v193, 0, v194)
			v188.CFrame = CFrame.fromMatrix(v192, v195, Vector3.new(0, 1, 0))
			local v196 = v183.a1
			local v197 = v183.at + v183.span
			local v198 = math.cos(v197) * v187
			local v199 = math.sin(v197) * v187
			local v200 = Vector3.new(v198, v184, v199)
			local v201 = -math.sin(v197)
			local v202 = math.cos(v197)
			local v203 = Vector3.new(v201, 0, v202)
			v196.CFrame = CFrame.fromMatrix(v200, v203, Vector3.new(0, 1, 0))
			local v204 = v183.span / 4
			local v205 = math.tan(v204) * 1.3333333333333333 * v187
			v183.beam.CurveSize0 = v205
			v183.beam.CurveSize1 = v205
			v183.beam.Width0 = p182 * 0.3
			v183.beam.Width1 = p182
		end
	end
	local function v_u_231(p207, p208, p209) -- name: needles
		-- upvalues: (copy) p_u_87, (ref) v_u_12, (ref) v_u_13
		for _ = 1, p209 do
			local v210 = math.random() * 3.141592653589793 * 2
			local v211 = p208 * (0.25 + math.random() * 0.65)
			local v212 = p_u_87.ground(p207, 0.8 + math.random() * p208 * 0.55)
			local v213 = math.cos(v210)
			local v214 = math.sin(v210)
			local v215 = v212 + Vector3.new(v213, 0, v214) * v211
			local v216 = -math.sin(v210)
			local v217 = (math.random() - 0.5) * 0.9
			local v218 = math.cos(v210)
			local v219 = Vector3.new(v216, v217, v218)
			local v220 = math.random() - 0.5
			local v221 = math.random() - 0.5
			local v222 = v219 + Vector3.new(v220, 0, v221) * 0.8
			local v223 = 3 + math.random() * 4
			local v224 = v222.Unit * v223 / 2
			local v225 = p_u_87.thin
			local v226 = p_u_87.rod
			local v227 = v215 - v224
			local v228 = v215 + v224
			local v229 = 0.22
			local v230
			if math.random() < 0.6 then
				v230 = v_u_12
			else
				v230 = v_u_13
			end
			v225(v226(v227, v228, v229, v230), 0.16)
		end
	end
	local function v_u_249(p232, p233, p234) -- name: flingBlades
		-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_1, (copy) p_u_87
		local v235 = math.random() * 3.141592653589793 * 2
		for v236 = 0, 3 do
			local v237 = v235 + v236 * 3.141592653589793 / 2
			local v238 = math.cos(v237)
			local v239 = math.sin(v237)
			local v240 = Vector3.new(v238, 0, v239)
			local v241 = -math.sin(v237)
			local v242 = math.cos(v237)
			local v_u_243 = Vector3.new(v241, 0, v242)
			local v_u_244 = v_u_5.part(Vector3.new(0.4, 2.88, 7.36), CFrame.fromMatrix(p232, Vector3.new(0, 1, 0), -v_u_243), v_u_13, {
				["shape"] = nil,
				["transparency"] = 0.05,
				["shape"] = Enum.PartType.Wedge
			})
			v_u_1:AddItem(v_u_244, 0.5)
			local v_u_245 = p232 + v240 * 2
			local v_u_246 = p232 + v240 * p233 * 1.5
			p_u_87.animate(0.42, 0, function(p247)
				-- upvalues: (copy) v_u_244, (copy) v_u_245, (copy) v_u_246, (copy) v_u_243
				local v248 = 1 - (1 - p247) ^ 2
				v_u_244.CFrame = CFrame.fromMatrix(v_u_245:Lerp(v_u_246, v248), Vector3.new(0, 1, 0), -v_u_243) * CFrame.Angles(p247 * 9, 0, 0)
				v_u_244.Transparency = 0.05 + 0.95 * p247 ^ 1.4
				if p247 >= 1 then
					v_u_244:Destroy()
				end
			end)
			if p234 then
				continue
			end
			p_u_87.groundLine(p232, v_u_246, 1.6, v_u_13, 0.5, 0.35)
		end
	end
	local v_u_250 = CFrame.new(0, 7, 4)
	local v_u_251 = { Vector3.new(4, 4, 7), Vector3.new(3.3, 3.3, 6.5), Vector3.new(2.4, 2.4, 5.5) }
	local v_u_252 = Color3.fromRGB(255, 100, 0)
	local v_u_253 = {}
	setmetatable(v_u_253, {
		["__mode"] = "k"
	})
	local v_u_254 = {}
	setmetatable(v_u_254, {
		["__mode"] = "k"
	})
	local function v_u_262(p255, p256, p257, p258, p259, p260, p261) -- name: spike
		-- upvalues: (ref) v_u_86
		v_u_86(p255, p256, p257, p258, 1.3, p259, p260, p261)
		v_u_86(p255, p256 * CFrame.Angles(0, 1.5707963267948966, 0), p257 * 0.7, p258, 1.3, p259, p260, p261)
	end
	local function v_u_332(p263, p264) -- name: buildFox
		-- upvalues: (ref) v_u_37, (ref) v_u_55, (ref) v_u_5, (ref) v_u_1, (copy) v_u_252, (ref) v_u_9, (ref) v_u_10, (copy) v_u_262, (ref) v_u_86, (ref) v_u_11, (ref) v_u_12
		local v265 = v_u_37()
		local v266 = v_u_37()
		v_u_55(v265, "egg", Vector3.new(9.5, 11, 8.5), CFrame.new(Vector3.new(0, 8, 0)) * CFrame.Angles(0.15, 0, 0), v_u_252, 0.3, p264)
		v_u_55(v265, "egg", Vector3.new(6.5, 7.5, 6.5), CFrame.new(0, 13, -1) * CFrame.Angles(-0.2, 0, 0), v_u_252, 0.3, p264)
		v_u_55(v265, "egg", Vector3.new(10, 8, 9), CFrame.new(Vector3.new(0, 17, -3)), v_u_252, 0.18, p264)
		if not p263 then
			v_u_55(v265, "egg", Vector3.new(11.6, 9.6, 10.6), CFrame.new(Vector3.new(0, 17, -3)), v_u_9, 0.75, p264)
			v_u_55(v265, "egg", Vector3.new(11, 12.5, 10), CFrame.new(Vector3.new(0, 8, 0)) * CFrame.Angles(0.15, 0, 0), v_u_9, 0.8, p264)
		end
		v_u_55(v265, "egg", Vector3.new(5, 3.4, 7.2), CFrame.new(0, 15.4, -8) * CFrame.Angles(-0.22, 0, 0), v_u_252, 0.15, p264)
		v_u_55(v265, "egg", Vector3.new(3.8, 1.8, 4.8), CFrame.new(0, 14.4, -7.6) * CFrame.Angles(-0.22, 0, 0), v_u_10, 0.15, p264)
		v_u_55(v265, "egg", Vector3.new(2, 1.3, 1.5), CFrame.new(0, 15.6, -11.6), v_u_10, 0, p264)
		for _, v267 in { -1, 1 } do
			v_u_55(v265, "egg", Vector3.new(6.5, 6.5, 6.5), CFrame.new(5 * v267, 9.8, -0.5), v_u_252, 0.3, p264)
			local v268 = 5.4 * v267
			local v269 = Vector3.new(v268, 10, -1.8)
			local v270 = 5.8 * v267
			local v271 = Vector3.new(v270, 7.8, -8.6)
			local v272 = (v269 + v271) / 2
			local v273 = (v271 - v269).Magnitude + 1.5
			v_u_55(v265, "egg", Vector3.new(3.2, 3.2, v273), CFrame.lookAt(v272, v271), v_u_252, 0.3, p264)
			v_u_55(v265, "egg", Vector3.new(3.8, 1.7, 4.6), CFrame.new(v271), v_u_252, 0.3, p264)
			for v274 = -1, 1 do
				v_u_55(v265, "egg", Vector3.new(0.8, 0.8, 2.2), CFrame.new(v271 + Vector3.new(v274, -0.1, -2.6)) * CFrame.Angles(-0.2, 0, 0), v_u_9, 0, p264)
			end
			local v275 = CFrame.new(3.2 * v267, 19.8, -2.6) * CFrame.Angles(0.2, 0, -0.42 * v267)
			v_u_262(v265, v275, 4.2, 8.5, v_u_252, 0.25, p264)
			if not p263 then
				v_u_86(v265, v275 * CFrame.new(0, 0.5, -0.75), 2.3, 5.6, 0.3, v_u_10, 0.1, p264)
			end
			for v276, v277 in { Vector3.new(v267, -0.2, 0.3), (Vector3.new(v267, -0.75, 0.35)) } do
				local v278 = 4.1 * v267
				local v279 = v276 == 1 and 16.6 or 15.1
				local v280 = Vector3.new(v278, v279, -4.4) + v277.Unit * 2.6
				v_u_55(v265, "egg", Vector3.new(1.8, 1.8, 6), CFrame.lookAt(v280, v280 + v277), v_u_252, 0.28, p264)
			end
			local v281 = CFrame.new(2.4 * v267, 17.7, -6.8) * CFrame.Angles(0, -0.4 * v267, 0) * CFrame.Angles(0, 0, 0.36 * v267)
			local v282 = v281 * CFrame.new(0, 0.05, 0.1)
			local v283 = v_u_10
			local v284 = v_u_5.part(Vector3.new(4, 1.75, 0.45), v282, v283, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v284, p264)
			local v285 = v265.parts
			table.insert(v285, v284)
			local v286 = v265.offs
			table.insert(v286, v282)
			local v287 = v265.sizes
			table.insert(v287, Vector3.new(4, 1.75, 0.45))
			local v288 = v265.alphas
			table.insert(v288, 0)
			local v289 = v281 * CFrame.new(0, 0, -0.12)
			local v290 = v_u_11
			local v291 = v_u_5.part(Vector3.new(3, 1.05, 0.5), v289, v290, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v291, p264)
			local v292 = v265.parts
			table.insert(v292, v291)
			local v293 = v265.offs
			table.insert(v293, v289)
			local v294 = v265.sizes
			table.insert(v294, Vector3.new(3, 1.05, 0.5))
			local v295 = v265.alphas
			table.insert(v295, 0)
			local v296 = v281 * CFrame.new(0.1 * v267, 0, -0.22)
			local v297 = v_u_10
			local v298 = v_u_5.part(Vector3.new(0.32, 0.95, 0.55), v296, v297, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v298, p264)
			local v299 = v265.parts
			table.insert(v299, v298)
			local v300 = v265.offs
			table.insert(v300, v296)
			local v301 = v265.sizes
			table.insert(v301, Vector3.new(0.32, 0.95, 0.55))
			local v302 = v265.alphas
			table.insert(v302, 0)
			local v303 = CFrame.new(2.3 * v267, 18.8, -6.5) * CFrame.Angles(0, -0.4 * v267, 0) * CFrame.Angles(0, 0, 0.55 * v267)
			local v304 = v_u_9
			local v305 = v_u_5.part(Vector3.new(3.8, 0.65, 1.5), v303, v304, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v305, p264)
			local v306 = v265.parts
			table.insert(v306, v305)
			local v307 = v265.offs
			table.insert(v307, v303)
			local v308 = v265.sizes
			table.insert(v308, Vector3.new(3.8, 0.65, 1.5))
			local v309 = v265.alphas
			table.insert(v309, 0)
			if p263 then
				break
			end
			for v310 = 0, 1 do
				local v311 = CFrame.new(3.4 * v267, 16 - v310 * 0.75, v310 * 0.2 + -6.1) * CFrame.Angles(0, -0.9 * v267, 0) * CFrame.Angles(0, 0, (-0.12 - v310 * 0.12) * v267)
				local v312 = v_u_10
				local v313 = v_u_5.part(Vector3.new(2.6, 0.28, 0.35), v311, v312, {
					["shape"] = nil,
					["material"] = nil,
					["transparency"] = 1
				})
				v_u_1:AddItem(v313, p264)
				local v314 = v265.parts
				table.insert(v314, v313)
				local v315 = v265.offs
				table.insert(v315, v311)
				local v316 = v265.sizes
				table.insert(v316, Vector3.new(2.6, 0.28, 0.35))
				local v317 = v265.alphas
				table.insert(v317, 0)
			end
			local v318 = CFrame.new(1.35 * v267, 13.7, -10.4) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v319 = v_u_12
			local v320 = v_u_5.part(Vector3.new(0.55, 1.5, 0.55), v318, v319, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v320, p264)
			local v321 = v265.parts
			table.insert(v321, v320)
			local v322 = v265.offs
			table.insert(v322, v318)
			local v323 = v265.sizes
			table.insert(v323, Vector3.new(0.55, 1.5, 0.55))
			local v324 = v265.alphas
			table.insert(v324, 0)
			local v325 = CFrame.new(1.3 * v267, 0.2, -5.6) * CFrame.Angles(0, 0.7853981633974483, 0)
			local v326 = v_u_12
			local v327 = v_u_5.part(Vector3.new(0.5, 1.2, 0.5), v325, v326, {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 1
			})
			v_u_1:AddItem(v327, p264)
			local v328 = v266.parts
			table.insert(v328, v327)
			local v329 = v266.offs
			table.insert(v329, v325)
			local v330 = v266.sizes
			table.insert(v330, Vector3.new(0.5, 1.2, 0.5))
			local v331 = v266.alphas
			table.insert(v331, 0)
		end
		v_u_55(v266, "egg", Vector3.new(4.3, 1.8, 6.6), CFrame.new(0, -0.6, -3.5) * CFrame.Angles(-0.2, 0, 0), v_u_252, 0.15, p264)
		return v265, v266
	end
	local function v_u_342(p333, p334) -- name: buildTails
		-- upvalues: (copy) v_u_251, (ref) v_u_5, (copy) v_u_252, (ref) v_u_1
		local v335 = {}
		for v336 = 1, p333 do
			local v337 = {}
			for _, v338 in v_u_251 do
				local v339 = v_u_5.part(v338, CFrame.identity, v_u_252, {
					["transparency"] = 1
				})
				local v340 = Instance.new("SpecialMesh")
				v340.MeshType = Enum.MeshType.Sphere
				v340.Parent = v339
				v_u_1:AddItem(v339, p334)
				table.insert(v337, v339)
			end
			local v341 = {
				["parts"] = v337,
				["fan"] = (p333 == 1 and 0 or (v336 - 1) / (p333 - 1) * 2 - 1) * 1.2,
				["phase"] = v336 * 1.7
			}
			table.insert(v335, v341)
		end
		return v335
	end
	local function v_u_369(p343, p344, p345, p346, p347) -- name: poseTails
		-- upvalues: (copy) v_u_251, (ref) v_u_4
		local v348 = p343.tailParts
		local v349 = p343.tailCfs
		local v350 = p346 - p343.tailK
		local v351 = math.abs(v350) > 0.0001
		local v352 = p347 - p343.tailF
		local v353 = math.abs(v352) > 0.001
		local v354 = 0
		for _, v355 in p343.tails do
			local v356 = p344:PointToWorldSpace(Vector3.new(0, 5, 8) * p346)
			for v357, v358 in v355.parts do
				local v359 = v357 - 1
				local v360 = v355.fan * (v359 * 0.22 + 1)
				local v361 = p345 * 5 + v355.phase + v359 * 0.9
				local v362 = v360 + math.sin(v361) * 0.1 * v357
				local v363 = v359 * 0.14 + 0.3
				local v364 = p345 * 4 + v355.phase
				local v365 = v363 + math.sin(v364) * 0.05
				local v366 = p344:VectorToWorldSpace((CFrame.Angles(v365, 0, 0) * CFrame.Angles(0, 0, v362)):VectorToWorldSpace(Vector3.new(0, 1, 0)))
				local v367 = v_u_251[v357] * p346
				local v368 = v356 + v366 * v367.Z * 0.42
				v354 = v354 + 1
				v348[v354] = v358
				v349[v354] = CFrame.lookAt(v368, v368 + v366)
				if v351 then
					v358.Size = v367
				end
				if v353 then
					v358.Transparency = p347 * 0.7 + 0.3
				end
				v356 = v368 + v366 * v367.Z * 0.42
			end
		end
		if not v351 then
			p346 = p343.tailK
		end
		p343.tailK = p346
		if not v353 then
			p347 = p343.tailF
		end
		p343.tailF = p347
		if v354 > 0 then
			v_u_4:BulkMoveTo(v348, v349, Enum.BulkMoveMode.FireCFrameChanged)
		end
	end
	local function v_u_378(p370, p371, p372) -- name: newBomb
		-- upvalues: (copy) p_u_87, (ref) v_u_16, (ref) v_u_18, (ref) v_u_1, (ref) v_u_17, (ref) v_u_32, (ref) v_u_7, (ref) v_u_19
		local v373 = p_u_87.ball(p371, v_u_16, 0.5, 0, Enum.Material.SmoothPlastic)
		local v374 = p_u_87.ball(p371, v_u_18, 0.5, 0.62)
		v_u_1:AddItem(v373, p372)
		v_u_1:AddItem(v374, p372)
		local v375 = {
			["core"] = nil,
			["shell"] = nil,
			["halo"] = nil,
			["swirl"] = nil,
			["core"] = v373,
			["shell"] = v374
		}
		if not p370 then
			local v376 = p_u_87.ball(p371, v_u_17, 0.5, 0.82)
			v_u_1:AddItem(v376, p372)
			v375.halo = v376
			local v377 = v_u_32(CFrame.new(p371), 0.5, v_u_7.Swirl, v_u_19, 0.35)
			v_u_1:AddItem(v377, p372)
			v375.swirl = v377
		end
		return v375
	end
	local function v_u_395(p379, p380, p381, p382) -- name: placeBomb
		-- upvalues: (copy) p_u_87, (ref) v_u_4
		local v383 = math.max(p381, 0.1)
		local v384 = p382 * 55
		local v385 = math.sin(v384) * 0.06 + 1
		p379.core.CFrame = CFrame.new(p380)
		p379.core.Size = Vector3.new(1, 1, 1) * v383 * 0.84
		p379.shell.CFrame = CFrame.new(p380)
		p379.shell.Size = Vector3.new(1, 1, 1) * v383 * v385
		local v386 = p379.halo
		if v386 then
			v386.CFrame = CFrame.new(p380)
			v386.Size = Vector3.new(1, 1, 1) * v383 * 1.45 / v385
		end
		local v387 = p379.swirl
		if v387 then
			local v388 = v383 * 0.85
			local v389 = v388 * 2
			local v390 = v388 * 2
			v387.Size = Vector3.new(v389, 0.05, v390)
			local v391 = p_u_87.facing
			local v392 = v_u_4.CurrentCamera
			local v393
			if v392 then
				local v394 = v392.CFrame.Position - p380
				v393 = v394.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v394.Unit
			else
				v393 = Vector3.new(0, 0, 1)
			end
			v387.CFrame = v391(p380, v393) * CFrame.Angles(0, p382 * 14, 0)
		end
	end
	local function v_u_407(p396) -- name: endFox
		if not p396.done then
			p396.done = true
			for _, v397 in p396.upper.parts do
				v397:Destroy()
			end
			for _, v398 in p396.jaw.parts do
				v398:Destroy()
			end
			for _, v399 in p396.tails do
				for _, v400 in v399.parts do
					v400:Destroy()
				end
			end
			for _, v401 in p396.balls do
				v401:Destroy()
			end
			for _, v402 in p396.rims do
				v402:Destroy()
			end
			for _, v403 in p396.stops do
				v403()
			end
			local v404 = p396.bomb
			if v404 and not p396.fireAt then
				v404.core:Destroy()
				v404.shell:Destroy()
				local v405 = v404.halo
				if v405 then
					v405:Destroy()
				end
				local v406 = v404.swirl
				if v406 then
					v406:Destroy()
				end
			end
		end
	end
	local function v_u_454(p408) -- name: foxStep
		-- upvalues: (copy) v_u_407, (copy) v_u_250, (ref) v_u_74, (copy) v_u_369, (ref) v_u_4, (copy) v_u_395
		if p408.done then
			return false
		end
		local v409 = os.clock()
		local v410 = v409 - p408.born
		local v411 = v410 / 0.2
		local v412 = math.clamp(v411, 0, 1)
		local v413 = v412 - 1
		local v414 = ((v413 * 2.9 * v413 * v413 + 1 + v413 * 1.9 * v413) * 0.55 + 0.45) * 1.35
		local v415 = v412 * 2.5
		local v416 = 1 - math.min(v415, 1)
		local v417 = (1 - v412) * 0.2 + 0.04
		local v418 = v410 * 7
		local v419 = v417 + math.sin(v418) * 0.012
		local v420 = v412 * 0.25 + 0.12
		local v421 = p408.fireAt
		local v422
		if v421 then
			local v423 = (v409 - v421) / 0.07
			local v424 = math.clamp(v423, 0, 1)
			local v425 = (v409 - v421 - 0.25) / 0.4
			local v426 = math.clamp(v425, 0, 1)
			v419 = v419 - v424 * 0.14 * (1 - v426 * 0.7)
			v420 = v420 + v424 * 0.3 * (1 - v426 * 0.6)
			v422 = v424 * 2.5 * (1 - v426 * 0.5)
			v414 = v414 * (v424 * 0.05 + 1)
		else
			v422 = 0
		end
		local v427 = p408.landAt
		local v428
		if v427 then
			v428 = v427 + 0.7
		else
			v428 = p408.born + 0.2 + 1.3
		end
		if v428 < v409 then
			local v429 = (v409 - v428) / 0.45
			local v430 = math.clamp(v429, 0, 1)
			v416 = math.max(v416, v430)
			v414 = v414 * (v430 * 0.12 + 1)
			if v430 >= 1 then
				v_u_407(p408)
				return false
			end
		end
		local v431 = v_u_250.Position * v414
		local v432 = p408.base * CFrame.new(0, -((1 - v412) * 8 + 7) * v414, -v422) * CFrame.new(v431) * CFrame.Angles(v419, 0, 0) * CFrame.new(-v431)
		v_u_74(p408.upper, v432, v414, v416)
		v_u_74(p408.jaw, v432 * CFrame.new(Vector3.new(0, 14.6, -5) * v414) * CFrame.Angles(-v420, 0, 0), v414, v416)
		v_u_369(p408, v432, v410, v414, v416)
		p408.mouth = v432:PointToWorldSpace(Vector3.new(0, 13.6, -12.6) * v414)
		if #p408.balls > 0 then
			local v433 = v432:PointToWorldSpace(Vector3.new(0, 17, -3) * v414)
			local v434 = v_u_4.CurrentCamera
			local v435
			if v434 then
				v435 = v434.CFrame
			else
				v435 = CFrame.lookAt(v433 + Vector3.new(0, 0, 1), v433)
			end
			local v436 = v_u_4.CurrentCamera
			local v437
			if v436 then
				local v438 = v436.CFrame.Position - v433
				v437 = v438.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v438.Unit
			else
				v437 = Vector3.new(0, 0, 1)
			end
			local v439 = v433 - v437 * 3 * v414 + Vector3.new(0, 1, 0) * v414
			local v440 = v414 * 8
			local v441 = v410 * 6
			local v442 = v440 * (math.sin(v441) * 0.03 + 1)
			local v443 = v414 * 1.8
			for v444, v445 in p408.balls do
				local v446 = 1.5707963267948966 + (v444 - 4) * 3.141592653589793 / 4
				local v447 = v439 + (v435.RightVector * math.cos(v446) + v435.UpVector * math.sin(v446)) * v442
				local v448 = v410 * 5 + v444
				local v449 = v447 + Vector3.new(0, 1, 0) * math.sin(v448) * 0.15 * v414
				v445.CFrame = CFrame.new(v449)
				v445.Size = Vector3.new(1, 1, 1) * v443
				v445.Transparency = v416
				local v450 = p408.rims[v444]
				if not v450 then
					continue
				end
				v450.CFrame = CFrame.new(v449 - v437 * v443 * 0.3)
				v450.Size = Vector3.new(1, 1, 1) * v443 * 1.2
				v450.Transparency = v416
			end
		end
		local v451 = p408.bomb
		if v451 and not v421 then
			local v452 = v410 / 0.24
			local v453 = math.clamp(v452, 0.12, 1)
			v_u_395(v451, p408.mouth, v414 * 5.5 * (1 - (1 - v453) ^ 2), v410)
		end
		return true
	end
	local function v_u_481(p455) -- name: startFox
		-- upvalues: (copy) v_u_332, (copy) p_u_87, (copy) v_u_342, (ref) v_u_10, (ref) v_u_1, (ref) v_u_9, (ref) v_u_18, (ref) v_u_12, (copy) v_u_252, (ref) v_u_7, (copy) v_u_378, (copy) v_u_253, (copy) v_u_407, (copy) v_u_254, (copy) v_u_454
		local v456 = p455.lite
		local v457, v458 = v_u_332(v456, 4.65)
		local v459 = p455.target.X
		local v460 = p_u_87.FLOOR
		local v461 = p455.target.Z
		local v462 = Vector3.new(v459, v460, v461)
		local v463 = p455.feet.X
		local v464 = p_u_87.FLOOR
		local v465 = p455.feet.Z
		local v466 = Vector3.new(v463, v464, v465)
		local v467
		if (v462 - v466).Magnitude > 1 then
			v467 = p_u_87.flatUnit(v462 - v466)
		else
			v467 = p_u_87.flatUnit(p455.dir)
		end
		local v468 = v462 + v467 * 30
		local v469 = CFrame.lookAt(v468, v468 - v467)
		local v_u_470 = {
			["upper"] = nil,
			["jaw"] = nil,
			["tails"] = nil,
			["balls"] = nil,
			["rims"] = nil,
			["stops"] = nil,
			["base"] = nil,
			["born"] = nil,
			["fireAt"] = nil,
			["landAt"] = nil,
			["mouth"] = nil,
			["bomb"] = nil,
			["done"] = false,
			["tailParts"] = nil,
			["tailCfs"] = nil,
			["tailK"] = -1,
			["tailF"] = -1,
			["upper"] = v457,
			["jaw"] = v458,
			["tails"] = v_u_342(v456 and 3 or 9, 4.65),
			["balls"] = {},
			["rims"] = {},
			["stops"] = {},
			["base"] = v469,
			["born"] = os.clock(),
			["mouth"] = v469:PointToWorldSpace(Vector3.new(0, 8.910001, -17.01)),
			["tailParts"] = {},
			["tailCfs"] = {}
		}
		if not v456 then
			for _ = 1, 7 do
				local v471 = p_u_87.ball(v468, v_u_10, 1, 1, Enum.Material.SmoothPlastic)
				v_u_1:AddItem(v471, 4.65)
				local v472 = v_u_470.balls
				table.insert(v472, v471)
				local v473 = p_u_87.ball(v468, v_u_9, 1, 1)
				v_u_1:AddItem(v473, 4.65)
				local v474 = v_u_470.rims
				table.insert(v474, v473)
			end
			p_u_87.inward(v_u_470.mouth, v_u_18, 8, 14, 0.24)
			p_u_87.inward(v_u_470.mouth, v_u_12, 5, 12, 0.2)
			local v475 = v_u_470.stops
			local v476 = p_u_87.loop
			local v477 = v457.parts[1]
			local v478 = v_u_252
			table.insert(v475, v476("Aura", v477, v478, 2.6))
			p_u_87.tongues(v468, 8, 6, 9, v_u_252, v_u_9, 1.2, true, 0.5)
			p_u_87.glowBeam(p455.eye, v469:PointToWorldSpace(Vector3.new(0, 1.35, 0)), v_u_252, 4, 0.4, v_u_7.FireBeam)
			if p455.mine then
				p_u_87.light(v457.parts[1], v_u_252, 40)
			end
		end
		v_u_470.bomb = v_u_378(v456, v_u_470.mouth, 4.65)
		local v479 = p455.caster
		if v479 then
			local v480 = v_u_253[v479]
			if v480 and not v480.fireAt then
				v_u_407(v480)
			end
			v_u_253[v479] = v_u_470
		else
			v_u_254[p455] = v_u_470
		end
		p_u_87.runNow(function()
			-- upvalues: (ref) v_u_454, (copy) v_u_470
			return v_u_454(v_u_470)
		end)
		return v_u_470
	end
	local v_u_482 = 0
	local function v_u_486() -- name: bombFrame
		-- upvalues: (ref) v_u_482, (ref) v_u_2, (ref) v_u_5, (copy) p_u_87, (ref) v_u_12, (ref) v_u_1
		local v483 = os.clock()
		if v483 >= v_u_482 then
			v_u_482 = v483 + 0.7
			local v_u_484 = Instance.new("ColorCorrectionEffect")
			v_u_484.Name = "TailedBeastBomb"
			v_u_484.Parent = v_u_2
			v_u_5.tween(v_u_484, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.25,
				["Saturation"] = 0.15,
				["Brightness"] = 0.05,
				["TintColor"] = Color3.fromRGB(235, 215, 255)
			})
			p_u_87.after(0.12, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_484, (ref) v_u_12
				local v485 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["Brightness"] = 0,
					["TintColor"] = v_u_12
				}
				v_u_5.tween(v_u_484, 0.5, v485)
			end)
			v_u_1:AddItem(v_u_484, 0.7)
		end
	end
	local function v_u_495(p487, p488) -- name: blast
		-- upvalues: (copy) p_u_87, (ref) v_u_5, (ref) v_u_12, (ref) v_u_16, (ref) v_u_1, (ref) v_u_18, (ref) v_u_17, (ref) v_u_8, (ref) v_u_7, (ref) v_u_19, (copy) v_u_104, (ref) v_u_6, (copy) v_u_486
		local v_u_489 = p487.ability.radius
		local v490 = p487.lite
		local v_u_491 = p_u_87.ground(p488)
		local v492 = p_u_87.ground(p488, 4)
		v_u_5.flash(v492, v_u_12, v_u_489 * 0.8, 0.12)
		local v_u_493 = p_u_87.ball(v_u_491, v_u_16, 6, 0, Enum.Material.SmoothPlastic)
		v_u_5.tween(v_u_493, 0.14, {
			["Size"] = Vector3.new(1, 1, 1) * v_u_489 * 1.15
		}, Enum.EasingStyle.Quart)
		p_u_87.after(0.2, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_493, (copy) v_u_489
			v_u_5.tween(v_u_493, 0.35, {
				["Size"] = nil,
				["Transparency"] = 1,
				["Size"] = Vector3.new(1, 1, 1) * v_u_489 * 0.2
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end)
		v_u_1:AddItem(v_u_493, 0.6)
		p_u_87.pop(v_u_491, v_u_18, v_u_489 * 0.7, v_u_489 * 2.3, 0.5, 0.2)
		p_u_87.pop(v_u_491, v_u_17, v_u_489, v_u_489 * 2.8, 0.7, 0.55)
		p_u_87.pop(p_u_87.ground(p488, 2), v_u_8, v_u_489 * 0.5, v_u_489 * 1.8, 0.32, 0.3)
		p_u_87.burst("Flash", v492, v_u_18, 1, true)
		p_u_87.burst("Explosion", v492, v_u_18, 2.5)
		p_u_87.burst("Shockwave", v_u_491 + Vector3.new(0, 0.3, 0), v_u_18, 1.6)
		v_u_5.ring(v_u_491, v_u_18, v_u_489 * 1.2, 0.55, v_u_7.Shockwave)
		p_u_87.after(0.05, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_491, (ref) v_u_8, (copy) v_u_489, (ref) v_u_7
			v_u_5.ring(v_u_491, v_u_8, v_u_489 * 1.4, 0.5, v_u_7.Ring)
		end)
		p_u_87.after(0.1, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_491, (ref) v_u_12, (copy) v_u_489, (ref) v_u_7
			v_u_5.ring(v_u_491, v_u_12, v_u_489 * 1.6, 0.45, v_u_7.SpeedLines)
		end)
		p_u_87.thin(p_u_87.pillar(v_u_491, 70, v_u_489 * 0.3, v_u_18, 0.3), 0.35, true)
		p_u_87.thin(p_u_87.pillar(v_u_491, 60, v_u_489 * 0.12, v_u_19, 0), 0.3, true)
		v_u_104(CFrame.new(v_u_491 + Vector3.new(0, 34, 0)), 4, v_u_489 * 1.1, v_u_7.Ring, v_u_19, 0.6, 2, 0.1)
		p_u_87.spikes(v492, v_u_18, v490 and 5 or 10, v_u_489 * 1.3, 0.35)
		p_u_87.spikes(p_u_87.ground(p488, 1), v_u_8, v490 and 4 or 8, v_u_489 * 1.2, 0.4, nil, nil, true)
		p_u_87.chunks(p_u_87.ground(p488, 1), {
			p_u_87.EARTH[1],
			p_u_87.EARTH[2],
			v_u_17,
			p_u_87.EARTH[4]
		}, v490 and 6 or 16, 60, 1.6, 1.5, false, 1.1)
		p_u_87.mark(p488, v_u_16, v_u_489 * 0.8, 2.5, v_u_7.CrackGlow, 0.05)
		p_u_87.mark(p488, v_u_18, v_u_489 * 0.65, 2, v_u_7.CrackLines, 0.15)
		if not v490 then
			p_u_87.burst("Explosion", p_u_87.ground(p488, 2), v_u_8, 1.8)
			local v494 = { v_u_18, v_u_8, v_u_19 }
			p_u_87.chunks(v492, v494, 10, 45, 0.6, 1, true, 0.9)
			p_u_87.tongues(p488, v_u_489 * 0.8, 8, 9, v_u_17, v_u_8, 0.45, true, 0.4)
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_491,
			["volume"] = p487.mine and 1 or 0.6
		})
		if p487.mine then
			v_u_5.shake(0.6, 0.6)
			v_u_486()
		end
	end
	local v629 = {
		["six_paths_sage_a"] = {
			["cast"] = function(p496) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) p_u_87, (ref) v_u_13, (copy) v_u_104, (ref) v_u_7, (ref) v_u_8
				local v497 = p496.size
				local v498 = p496.eye + p496.dir * 1.2
				v_u_5.flash(v498, v_u_9, 3.2 * v497, 0.1)
				p_u_87.pop(v498, v_u_13, 1.4 * v497, 2.6 * v497, 0.1, 0.3)
				if not p496.lite then
					v_u_104(p_u_87.facing(v498, p496.dir), 0.6 * v497, 2.8 * v497, v_u_7.Ring, v_u_13, 0.14, 0, 0.1)
					p_u_87.spikes(v498, v_u_8, 2, 2.6 * v497, 0.1, p496.dir, 0.9)
				end
			end,
			["shot"] = v133,
			["impact"] = v140,
			["hit"] = function(_, p499, _) -- name: hit
				-- upvalues: (copy) p_u_87, (ref) v_u_14
				p_u_87.burst("Impact", p499, v_u_14, 0.6)
			end
		},
		["six_paths_sage_e"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p500) -- name: cast
				-- upvalues: (copy) p_u_87, (ref) v_u_9, (ref) v_u_5, (ref) v_u_13, (ref) v_u_12
				p_u_87.skillCast(p500, v_u_9)
				local v501 = p500.eye + Vector3.new(0, 2.6, 0)
				v_u_5.flash(v501, v_u_13, 6, 0.18)
				p_u_87.pop(v501, v_u_12, 1, 3, 0.14)
				if not p500.lite then
					p_u_87.spikes(v501, v_u_12, 5, 6, 0.16, nil, nil, true)
					p_u_87.glint(v501, v_u_13, 5, 0.16)
				end
			end,
			["windup"] = function(p502, p503, p504) -- name: windup
				-- upvalues: (copy) p_u_87, (copy) v_u_158, (copy) v_u_141, (ref) v_u_5, (ref) v_u_14, (ref) v_u_1, (ref) v_u_13, (copy) v_u_169, (ref) v_u_4, (copy) v_u_104, (ref) v_u_7
				local v_u_505 = p502.size
				local v506 = p502.ability.radius
				local v_u_507 = p502.eye + Vector3.new(0, 2.6, 0) + p502.dir * 1.2
				local v_u_508 = p_u_87.ground(p503, 4)
				local v_u_509 = math.max(p504, 0.06)
				local v_u_510 = v_u_158(p502.lite, v_u_509 + 4)
				v_u_141[p502] = v_u_510
				local v_u_511 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_507), v_u_14, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_511, v_u_509 + 0.4)
				p_u_87.streak(v_u_511, v_u_13, v_u_14, 3.5 * v_u_505, 0.18)
				local v_u_512 = os.clock()
				p_u_87.runNow(function()
					-- upvalues: (copy) v_u_512, (copy) v_u_509, (copy) v_u_507, (copy) v_u_508, (copy) v_u_511, (copy) v_u_510, (ref) v_u_169, (ref) p_u_87, (ref) v_u_4, (copy) v_u_505
					local v513 = os.clock() - v_u_512
					local v514 = v513 / v_u_509
					local v515 = math.clamp(v514, 0, 1)
					local v516 = v_u_507:Lerp(v_u_508, v515)
					local v517 = v515 * 3.141592653589793
					local v518 = v516 + Vector3.new(0, 1, 0) * math.sin(v517) * 2
					v_u_511.CFrame = CFrame.new(v518)
					if v_u_510.taken then
						return false
					end
					local v519 = v_u_169
					local v520 = v_u_510
					local v521 = v513 * 6
					local v522 = p_u_87.flatUnit
					local v523 = v_u_4.CurrentCamera
					local v524
					if v523 then
						local v525 = v523.CFrame.Position - v518
						v524 = v525.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v525.Unit
					else
						v524 = Vector3.new(0, 0, 1)
					end
					local v526 = v522(v524) * 0.35
					v519(v520, p_u_87.facing(v518, (Vector3.new(0, 1, 0) + v526).Unit) * CFrame.Angles(math.sin(v521) * 0.06, 0, 0), (v515 * 0.3 + 0.9) * v_u_505, -v513 * 30, 0)
					return v515 < 1
				end)
				v_u_104(CFrame.new(p_u_87.ground(p503, 0.15)), v506 * 1.2, v506 * 0.5, v_u_7.Ring, v_u_13, v_u_509 + 0.1, 3, 0.2)
			end,
			["zone"] = function(p527, p_u_528, p_u_529) -- name: zone
				-- upvalues: (copy) p_u_87, (copy) v_u_141, (copy) v_u_158, (ref) v_u_5, (ref) v_u_13, (ref) v_u_20, (ref) v_u_1, (ref) v_u_32, (ref) v_u_7, (ref) v_u_14, (ref) v_u_12, (copy) v_u_179, (copy) v_u_169, (ref) v_u_4, (copy) v_u_206, (copy) v_u_231
				local v_u_530 = p527.size
				local v_u_531 = p527.ability.radius * v_u_530
				local v_u_532 = p527.lite
				local v_u_533 = p_u_87.ground(p_u_528, 0)
				local v_u_534 = p_u_87.ground(p_u_528, 4)
				local v535 = p_u_529 + 2
				local v536 = v_u_141[p527]
				v_u_141[p527] = nil
				local v_u_537 = v536 or v_u_158(v_u_532, v535)
				v_u_537.taken = true
				local v_u_538 = v_u_531 / 5.5
				local v_u_539 = v_u_5.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(v_u_533), v_u_13, {
					["shape"] = nil,
					["material"] = nil,
					["transparency"] = 0,
					["shape"] = v_u_20,
					["material"] = Enum.Material.ForceField
				})
				v_u_1:AddItem(v_u_539, v535)
				local v_u_540 = v_u_32(CFrame.new(p_u_87.ground(p_u_528, 0.12)), 0.5, v_u_7.Swirl, v_u_13, 0.25)
				v_u_1:AddItem(v_u_540, v535)
				local v_u_541 = v_u_32(CFrame.new(p_u_87.ground(p_u_528, 0.16)), 0.5, v_u_7.Ring, v_u_14, 0.1)
				v_u_1:AddItem(v_u_541, v535)
				local v_u_542 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_533), v_u_12, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_542, v535)
				local v_u_543 = v_u_179(v_u_542, v_u_532 and 4 or 8, v_u_532)
				local v_u_544
				if v_u_532 then
					v_u_544 = nil
				else
					v_u_544 = p_u_87.loopAt("Charge", v_u_534, v_u_14, 1.2)
				end
				p_u_87.pop(v_u_534, v_u_12, 2, v_u_531 * 1.1, 0.2, 0.3)
				v_u_5.ring(p_u_87.ground(p_u_528), v_u_13, v_u_531 * 1.3, 0.35, v_u_7.Shockwave)
				p_u_87.burst("Impact", v_u_534, v_u_14, 1.6)
				local v_u_545 = os.clock()
				local v_u_546 = v_u_545
				local v_u_547 = 0
				local v_u_548 = nil
				p_u_87.runNow(function()
					-- upvalues: (copy) v_u_545, (ref) v_u_546, (ref) v_u_547, (ref) v_u_548, (ref) v_u_169, (copy) v_u_537, (copy) v_u_534, (ref) p_u_87, (ref) v_u_4, (copy) v_u_538, (copy) v_u_539, (copy) v_u_531, (copy) v_u_533, (copy) v_u_540, (copy) p_u_528, (copy) v_u_541, (copy) v_u_542, (ref) v_u_206, (copy) v_u_543, (copy) v_u_530, (copy) p_u_529
					local v549 = os.clock()
					local v550 = v549 - v_u_545
					local v551 = v549 - v_u_546
					local v552 = math.min(v551, 0.05)
					v_u_546 = v549
					v_u_547 = v_u_547 - v552 * 26
					local v553 = v550 / 0.2
					local v554 = math.clamp(v553, 0, 1) - 1
					local v555 = v554 * 2.9 * v554 * v554 + 1 + v554 * 1.9 * v554
					local v556
					if v_u_548 then
						local v557 = (v549 - v_u_548) / 0.12
						v556 = math.clamp(v557, 0, 1)
					else
						v556 = 0
					end
					local v558 = v555 * (1 - v556)
					local v559 = math.max(v558, 0.02)
					local v560 = v_u_169
					local v561 = v_u_537
					local v562 = v_u_534
					local v563 = v550 * 5
					local v564 = p_u_87.flatUnit
					local v565 = v_u_4.CurrentCamera
					local v566
					if v565 then
						local v567 = v565.CFrame.Position - v562
						v566 = v567.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v567.Unit
					else
						v566 = Vector3.new(0, 0, 1)
					end
					local v568 = v564(v566) * 0.35
					v560(v561, p_u_87.facing(v562, (Vector3.new(0, 1, 0) + v568).Unit) * CFrame.Angles(math.sin(v563) * 0.06, 0, 0), (1.2 + (v_u_538 - 1.2) * v555) * (1 - v556 * 0.9), v_u_547, 0)
					local v569 = v550 * 22
					local v570 = math.sin(v569) * 0.015 + 1
					v_u_539.Size = Vector3.new(1, 1, 1) * v_u_531 * 2 * v559 * v570
					v_u_539.CFrame = CFrame.new(v_u_533) * CFrame.Angles(0, v_u_547 * 0.2, 0)
					local v571 = v_u_540
					local v572 = v_u_531 * 2 * v559
					local v573 = v_u_531 * 2 * v559
					v571.Size = Vector3.new(v572, 0.05, v573)
					v_u_540.CFrame = CFrame.new(p_u_87.ground(p_u_528, 0.12)) * CFrame.Angles(0, v_u_547 * 0.35, 0)
					local v574 = v_u_541
					local v575 = v_u_531 * 2.1 * v559
					local v576 = v_u_531 * 2.1 * v559
					v574.Size = Vector3.new(v575, 0.05, v576)
					v_u_541.CFrame = CFrame.new(p_u_87.ground(p_u_528, 0.16)) * CFrame.Angles(0, -v_u_547 * 0.15, 0)
					v_u_542.CFrame = CFrame.new(v_u_533) * CFrame.Angles(0, v_u_547 * 0.45, 0)
					v_u_206(v_u_543, v_u_531 * v559, 1.6 * v_u_530)
					if v556 < 1 then
						return v550 < p_u_529 + 1
					end
					local v577 = v_u_537
					for _, v578 in v577.body.parts do
						v578:Destroy()
					end
					v577.ring:Destroy()
					v_u_539:Destroy()
					v_u_540:Destroy()
					v_u_541:Destroy()
					v_u_542:Destroy()
					return false
				end)
				local v_u_579 = true
				local v_u_580 = p527.ability.tick or 0.32
				task.spawn(function()
					-- upvalues: (ref) v_u_579, (copy) v_u_545, (copy) p_u_529, (ref) v_u_231, (copy) p_u_528, (copy) v_u_531, (copy) v_u_532, (ref) p_u_87, (ref) v_u_13, (ref) v_u_5, (ref) v_u_12, (ref) v_u_7, (copy) v_u_580
					while v_u_579 and os.clock() - v_u_545 < p_u_529 + 0.5 do
						v_u_231(p_u_528, v_u_531, v_u_532 and 3 or 8)
						if not v_u_532 then
							p_u_87.inward(p_u_87.ground(p_u_528, 1.5), v_u_13, 4, v_u_531 * 1.4, 0.25)
							v_u_5.ring(p_u_87.ground(p_u_528), v_u_12, v_u_531 * 1.05, 0.22, v_u_7.Ring)
						end
						task.wait(v_u_580)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_579, (ref) v_u_548, (ref) v_u_544
					v_u_579 = false
					v_u_548 = os.clock()
					local v581 = v_u_544
					if v581 then
						v581()
					end
				end
			end,
			["finish"] = function(p582, p583) -- name: finish
				-- upvalues: (copy) p_u_87, (ref) v_u_5, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_104, (ref) v_u_4, (ref) v_u_7, (copy) v_u_249, (ref) v_u_6
				local v584 = p582.ability.radius * p582.size
				local v585 = p582.lite
				local v586 = p_u_87.ground(p583, 4)
				local v587 = p_u_87.ground(p583)
				v_u_5.flash(v586, v_u_12, v584 * 1.2, 0.14)
				p_u_87.pop(v586, v_u_13, 3, v584 * 1.6, 0.32, 0.25)
				p_u_87.pop(v587, v_u_14, v584, v584 * 2.4, 0.45, 0.6)
				p_u_87.burst("Explosion", v586, v_u_14, v584 / 6)
				p_u_87.burst("Shockwave", v587 + Vector3.new(0, 0.3, 0), v_u_13, v584 / 14)
				local v588 = v_u_104
				local v589 = p_u_87.facing
				local v590 = v_u_4.CurrentCamera
				local v591
				if v590 then
					local v592 = v590.CFrame.Position - v586
					v591 = v592.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v592.Unit
				else
					v591 = Vector3.new(0, 0, 1)
				end
				v588(v589(v586, v591), 3, v584 * 1.3, v_u_7.Swirl, v_u_13, 0.4, -14)
				v_u_5.ring(v587, v_u_12, v584 * 1.4, 0.45, v_u_7.SpeedLines)
				v_u_5.ring(v587, v_u_14, v584 * 1.2, 0.5, v_u_7.Shockwave)
				v_u_249(v586, v584, v585)
				p_u_87.spikes(v586, v_u_12, v585 and 5 or 12, v584 * 1.3, 0.3, nil, nil, true)
				if not v585 then
					p_u_87.chunks(p_u_87.ground(p583, 1), { p_u_87.EARTH[1], p_u_87.EARTH[2], v_u_13 }, 8, 40, 0.9, 1)
				end
				v_u_6.play("Explosion", {
					["at"] = v587,
					["volume"] = p582.mine and 0.85 or 0.5
				})
				if p582.mine then
					v_u_5.shake(0.4, 0.35)
				end
			end,
			["hit"] = function(p593, p594, _) -- name: hit
				-- upvalues: (copy) p_u_87, (ref) v_u_13, (ref) v_u_12
				p_u_87.burst("Impact", p594, v_u_13, 0.6)
				if not p593.lite then
					for v595 = 0, 1 do
						local v596 = math.random() * 3.141592653589793
						local v597 = math.cos(v596)
						local v598 = (v595 - 0.5) * 1.2
						local v599 = math.sin(v596)
						local v600 = Vector3.new(v597, v598, v599).Unit * 1.6
						p_u_87.thin(p_u_87.rod(p594 - v600, p594 + v600, 0.18, v_u_12), 0.12)
					end
				end
			end
		},
		["six_paths_sage_r"] = {
			["cast"] = function(p601) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) p_u_87, (ref) v_u_8, (ref) v_u_7, (copy) v_u_481
				v_u_5.flash(p601.eye, v_u_9, 3.5, 0.14)
				p_u_87.thin(p_u_87.pillar(p601.feet, 8, 3, v_u_8, 0.5), 0.25)
				v_u_5.ring(p601.feet, v_u_8, 14, 0.4, v_u_7.Shockwave)
				if p601.mine then
					v_u_5.shake(0.14, 0.14)
				end
				v_u_481(p601)
			end,
			["windup"] = function(p602, p603, p604) -- name: windup
				-- upvalues: (copy) v_u_253, (copy) v_u_254, (copy) v_u_481, (copy) p_u_87, (ref) v_u_18, (ref) v_u_5, (ref) v_u_19, (copy) v_u_104, (ref) v_u_7, (ref) v_u_16, (copy) v_u_395
				local v605 = p602.caster
				local v606
				if v605 then
					v606 = v_u_253[v605]
				else
					v606 = v_u_254[p602]
				end
				if not v606 or (v606.done or v606.fireAt) then
					v606 = nil
				end
				local v_u_607 = v606 or v_u_481(p602)
				local v_u_608 = p_u_87.ground(p603, 4)
				local v609 = p604 * 0.4
				local v_u_610 = p604 - v609
				p_u_87.after(v609, function()
					-- upvalues: (copy) v_u_607, (ref) p_u_87, (ref) v_u_18, (ref) v_u_5, (ref) v_u_19, (ref) v_u_104, (copy) v_u_608, (ref) v_u_7, (copy) v_u_610, (ref) v_u_16, (ref) v_u_395
					if v_u_607.done then
						return
					else
						local v_u_611 = v_u_607.bomb
						if v_u_611 then
							v_u_607.fireAt = os.clock()
							local v_u_612 = v_u_607.mouth
							p_u_87.burst("Flash", v_u_612, v_u_18, 0.6, true)
							v_u_5.flash(v_u_612, v_u_19, 12, 0.14)
							v_u_104(p_u_87.facing(v_u_612, (v_u_608 - v_u_612).Unit), 3, 14, v_u_7.SpeedLines, v_u_19, 0.3, 0, 0.1)
							if v_u_610 < 0.03 then
								v_u_611.core:Destroy()
								v_u_611.shell:Destroy()
								local v613 = v_u_611.halo
								if v613 then
									v613:Destroy()
								end
								local v614 = v_u_611.swirl
								if v614 then
									v614:Destroy()
								end
							else
								p_u_87.streak(v_u_611.core, v_u_18, v_u_16, 5, 0.22)
								local v_u_615 = os.clock()
								p_u_87.runNow(function()
									-- upvalues: (copy) v_u_615, (ref) v_u_610, (copy) v_u_612, (ref) v_u_608, (ref) v_u_395, (copy) v_u_611, (ref) v_u_607
									local v616 = (os.clock() - v_u_615) / v_u_610
									local v617 = math.clamp(v616, 0, 1)
									local v618 = v_u_612:Lerp(v_u_608, v617)
									local v619 = v617 * 3.141592653589793
									v_u_395(v_u_611, v618 + Vector3.new(0, 1, 0) * math.sin(v619) * 3, (v617 * 0.25 + 1) * 7.425000000000001, os.clock() - v_u_607.born)
									if v617 < 1 then
										return true
									end
									local v620 = v_u_611
									v620.core:Destroy()
									v620.shell:Destroy()
									local v621 = v620.halo
									if v621 then
										v621:Destroy()
									end
									local v622 = v620.swirl
									if v622 then
										v622:Destroy()
									end
									return false
								end)
							end
						else
							return
						end
					end
				end)
				if p602.mine then
					v_u_5.shake(0.2, 0.25)
				end
			end,
			["land"] = function(p623, p624) -- name: land
				-- upvalues: (copy) v_u_253, (copy) v_u_254, (copy) v_u_495
				local v625 = p623.caster
				local v626
				if v625 then
					v626 = v_u_253[v625]
				else
					v626 = v_u_254[p623]
				end
				if v626 and not v626.done then
					v626.landAt = os.clock()
				end
				v_u_495(p623, p624)
			end,
			["hit"] = function(p627, p628, _) -- name: hit
				-- upvalues: (copy) p_u_87, (ref) v_u_18, (ref) v_u_8
				p_u_87.burst("Impact", p628, v_u_18, 1.1)
				if not p627.lite then
					p_u_87.glint(p628, v_u_8, 4, 0.15)
				end
			end
		}
	}
	return v629
end