local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Mythic8)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(v2.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF2E6A")
local v_u_9 = Color3.fromHex("C9D2E6")
local v_u_10 = Color3.fromRGB(150, 0, 48)
local v_u_11 = Color3.fromRGB(22, 6, 14)
local v_u_12 = Enum.Material.SmoothPlastic
local v_u_13 = Enum.Material.Metal
local v_u_14 = Enum.Material.Neon
local v_u_15 = CFrame.Angles(0, 3.141592653589793, 0)
return function(p_u_16)
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_1, (copy) v_u_3, (copy) v_u_8, (copy) v_u_4, (copy) v_u_10, (copy) v_u_5, (copy) v_u_15, (copy) v_u_9, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12, (copy) v_u_14
	return {
		["w8_demon_seal"] = function(p_u_17, _)
			-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) p_u_16, (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10, (ref) v_u_5, (ref) v_u_15, (ref) v_u_9, (ref) v_u_13, (ref) v_u_11, (ref) v_u_12, (ref) v_u_14
			v_u_6.images({ v_u_7.DSealDial, v_u_7.DSealCross })
			local v18 = p_u_17.headY / 1.5
			local v_u_19 = math.clamp(v18, 0.7, 3)
			local v_u_20 = p_u_17.fx
			local v21 = p_u_17.character == v_u_1.LocalPlayer.Character
			local v_u_22 = p_u_16.backOf(p_u_17)
			local v_u_23 = CFrame.identity
			local v_u_26 = p_u_16.throb(p_u_17, 6, 3, 1.2, function(p24)
				-- upvalues: (ref) p_u_16, (copy) p_u_17, (ref) v_u_3, (ref) v_u_23, (ref) v_u_8, (copy) v_u_19, (copy) v_u_20, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_5
				local v25 = p_u_16.feetAt(p_u_17, p24, 0.12)
				v_u_3.flash(v_u_23.Position, v_u_8, v_u_19 * 4.2 * v_u_20, 0.25)
				v_u_4.groundPic(v25, v_u_19 * 1, v_u_19 * 9 * v_u_20, v_u_7.DSealCross, v_u_8, 0, 0.12, 0.2, 0.5, 0, 0.2)
				v_u_4.groundPic(v25 + Vector3.new(0, 0.04, 0), v_u_19 * 5, v_u_19 * 15 * v_u_20, v_u_7.DSealDial, v_u_10, 0.1, 0.4, 0, 0.35, 0.6)
				if v_u_5.level() > 1 then
					v_u_4.spray(v_u_23.Position, v_u_7.FxTwinkle, 8, v_u_19 * 0.7, v_u_19 * 9, 0.6, v_u_8, {
						["layout"] = Enum.ParticleFlipbookLayout.Grid4x4
					})
				end
			end)
			local v_u_38 = p_u_16.group(p_u_17, function(p27, p28)
				-- upvalues: (ref) v_u_4, (copy) v_u_19, (ref) v_u_23, (copy) v_u_22
				local v29 = p28 < 3 and 99 or (p28 - 3) % 6
				local v30 = v29 >= 0.45 and 0 or 6.283185307179586 * v_u_4.outBack(v29 / 0.45)
				local v31 = p28 * 1.3
				local v32 = math.sin(v31) * 0.08 * v_u_19
				local v33 = p27 * v_u_22 * CFrame.new(0, v_u_19 * 1.3 + v32, v_u_19 * 0.8)
				local v34 = CFrame.Angles
				local v35 = p28 / 1
				local v36 = math.floor(v35)
				local v37 = p28 - v36 * 1
				v_u_23 = v33 * v34(0, 0, -(0.5235987755982988 * (v36 + v_u_4.outBack(v37 / 0.14))) - v30)
				return v_u_23
			end)
			local v39 = v_u_4.standingCard(v_u_19 * 3.5, v_u_19 * 3.5, v_u_7.DSealDial, v_u_8, 0, 1.6)
			p_u_16.add(p_u_17, v39, function(_, p40)
				-- upvalues: (copy) v_u_38, (ref) v_u_4, (copy) v_u_19
				local v41 = v_u_38.cf
				local v42 = CFrame.Angles
				local v43 = p40 / 1
				local v44 = math.floor(v43)
				local v45 = p40 - v44 * 1
				return v41 * v42(0, 0, 0.5235987755982988 * (v44 + v_u_4.outBack(v45 / 0.14)) * 2) * CFrame.new(0, 0, v_u_19 * -0.16)
			end)
			local v46 = v_u_4.piece("w8_demon_seal", v_u_19 * 2.4, 5)
			if v46 then
				p_u_16.pin(p_u_17, v_u_38, v46, v_u_15)
			else
				for v47, v48 in {
					0,
					1.5707963267948966,
					-1.5707963267948966,
					3.141592653589793
				} do
					local v49 = v47 == 4
					local v50 = v_u_4.blade(v_u_9, v_u_13)
					for _, v51 in v50 do
						v51.Reflectance = 0.25
					end
					local v52 = -math.sin(v48)
					local v53 = math.cos(v48)
					local v54 = Vector3.new(v52, v53, 0)
					local v55 = CFrame.lookAt(v54 * 0.25 * v_u_19, v54 * 2 * v_u_19, (Vector3.new(0, 0, 1)):Cross(v54))
					v_u_4.placeBlade(v50, v55, (v49 and 1.5 or 1.05) * v_u_19, (v49 and 0.36 or 0.55) * v_u_19, v_u_19 * 0.12)
					for _, v56 in v50 do
						p_u_16.pin(p_u_17, v_u_38, v56, v56.CFrame)
					end
				end
				p_u_16.pin(p_u_17, v_u_38, p_u_16.ball(v_u_19 * 0.75, v_u_11, 0, v_u_12), CFrame.new(0, 0, v_u_19 * 0.1))
			end
			local v57 = p_u_16.ball(v_u_19 * 0.42, v_u_8, 0.05, v_u_14)
			p_u_16.pin(p_u_17, v_u_38, v57, CFrame.new(0, 0, v_u_19 * -0.3))
			local v58 = v_u_4.card(v_u_19 * 6.4, v_u_7.DSealDial, v_u_8, 0.05, 1.5)
			p_u_16.add(p_u_17, v58, function(p59, p60)
				-- upvalues: (ref) p_u_16, (copy) p_u_17, (ref) v_u_4
				local v61 = CFrame.new(p_u_16.feetAt(p_u_17, p59, 0.08))
				local v62 = CFrame.Angles
				local v63 = p60 / 1
				local v64 = math.floor(v63)
				local v65 = p60 - v64 * 1
				return v61 * v62(0, 0.5235987755982988 * (v64 + v_u_4.outBack(v65 / 0.14)), 0)
			end)
			local v66 = p_u_16.picture(v_u_19 * 5.4, v_u_7.Glow, v_u_10, 0.45)
			p_u_16.add(p_u_17, v66, function(p67)
				-- upvalues: (ref) p_u_16, (copy) p_u_17
				return CFrame.new(p_u_16.feetAt(p_u_17, p67, 0.05))
			end)
			local function v_u_78(p68, p69, p70) -- name: handAt
				-- upvalues: (ref) v_u_4, (ref) p_u_16, (copy) p_u_17
				local v71 = p69 - 3
				local v72 = v71 / 0.5
				local v73 = math.floor(v72)
				local v74 = v71 - v73 * 0.5
				local v75 = 0.5235987755982988 * (v73 + v_u_4.outBack(v74 / 0.14))
				local v76 = p_u_16.feetAt(p_u_17, p68, p70)
				local v77 = (p68.Rotation * CFrame.Angles(0, -v75, 0)).LookVector
				return CFrame.lookAt(v76, v76 + v_u_4.flat(v77), Vector3.new(0, 1, 0)) * CFrame.Angles(0, 0, 1.5707963267948966)
			end
			v_u_4.formBlade(p_u_16, p_u_17, v_u_9, v_u_13, function(p79, p80)
				-- upvalues: (copy) v_u_78, (copy) v_u_19
				return v_u_78(p79, p80, 0.16), v_u_19 * 2.4, v_u_19 * 0.3, v_u_19 * 0.06
			end)
			v_u_4.formBlade(p_u_16, p_u_17, v_u_8, v_u_14, function(p81, p82)
				-- upvalues: (copy) v_u_78, (copy) v_u_19
				return v_u_78(p81, p82, 0.2) * CFrame.new(0, 0, v_u_19 * -1.75), v_u_19 * 0.8, v_u_19 * 0.5, v_u_19 * 0.07
			end)
			for v_u_83 = 1, 4 do
				local v84 = v_u_83 % 2 == 0
				local v85 = v_u_4.formBlade
				local v86 = p_u_16
				local v87
				if v84 then
					v87 = v_u_9
				else
					v87 = v_u_8
				end
				v85(v86, p_u_17, v87, v_u_14, function(p88, p89)
					-- upvalues: (copy) v_u_26, (ref) v_u_4, (copy) v_u_83, (copy) v_u_19
					local v90 = v_u_26()
					local v91 = p89 / 0.5
					local v92 = math.floor(v91)
					local v93 = p89 - v92 * 0.5
					local v94 = 0.2617993877991494 * (v92 + v_u_4.outBack(v93 / 0.14)) + v_u_83 * 3.141592653589793 / 2
					local v95 = (1.7 + 1.1 * v90) * v_u_19
					local v96 = math.cos(v94)
					local v97 = math.sin(v94)
					local v98 = Vector3.new(v96, 0, v97)
					local v99 = v98.X * v95
					local v100 = v_u_19 * 0.6
					local v101 = v98.Z * v95 * 0.85
					local v102 = p88 * Vector3.new(v99, v100, v101)
					local v103 = p88:VectorToWorldSpace(v98)
					return CFrame.lookAt(v102 - v103 * 0.35 * v_u_19, v102 + v103, Vector3.new(0, 1, 0)), v_u_19 * 1.25, v_u_19 * 0.44, v_u_19 * 0.1
				end)
			end
			p_u_16.particles(p_u_17, "AuraMode", v_u_8, {
				["rate"] = nil,
				["glow"] = 0.4,
				["only"] = nil,
				["rate"] = v21 and 0.2 or 0.3,
				["only"] = { "Sparks" }
			})
		end
	}
end