local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.Parent.EpicKit8)
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v4 = require(script.Parent.Parent.Preload)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v1.Shared.Config.Textures)
v4.images({ v_u_6.BlackBolt, v_u_6.BlackFork, v_u_6.Glow })
local v_u_7 = Color3.fromRGB(14, 4, 18)
local v_u_8 = Color3.fromRGB(40, 20, 50)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.Material.Neon
local v_u_12 = CFrame.Angles(0.4363323129985824, 0, 0)
local v_u_13 = CFrame.Angles(0, 0, -0.57246799465414)
local function v_u_18(p14, p15, p16) -- name: floorEmitter
	local v17 = Instance.new("ParticleEmitter")
	v17.Texture = p14
	v17.Color = ColorSequence.new(p15)
	v17.LightEmission = p16
	v17.LightInfluence = 0
	v17.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v17.EmissionDirection = Enum.NormalId.Top
	v17.SpreadAngle = Vector2.zero
	v17.Speed = NumberRange.new(0.01)
	v17.Rate = 0
	v17.Enabled = false
	v17.LockedToPart = true
	return v17
end
return function(p_u_19)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_12, (copy) v_u_2, (copy) v_u_13, (copy) v_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_8, (copy) v_u_6, (copy) v_u_9, (copy) v_u_18
	return {
		["w8_black_thunder"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) p_u_19, (ref) v_u_12, (ref) v_u_2, (ref) v_u_13, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_18
			local v22 = v_u_3.color(p21.color)
			local v23 = p_u_20.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v25 = p_u_20.fx
			local v26 = math.min(v25, 1.6)
			local v27 = v_u_5.formRate()
			local v_u_28 = p_u_19.throb(p_u_20, 5.5, 2.2, 2.2)
			local v_u_29 = CFrame.new(Vector3.new(-0.95, -0.55, 0.15) * v_u_24) * v_u_12
			local v30 = v_u_2.piece("w8_black_thunder", v_u_24 * 3.6)
			if v30 then
				p_u_19.glue(p_u_20, v30, function(p31)
					-- upvalues: (copy) v_u_29, (ref) v_u_13
					return p31 * v_u_29 * CFrame.Angles(0, -1.5707963267948966, 0) * v_u_13
				end)
			else
				local v_u_32 = v_u_24 * 3.6
				local v33 = p_u_19.bar
				local v34 = v_u_24 * 0.1
				local v35 = v_u_24 * 0.32
				local v36 = v_u_32 * 0.72
				local v37 = v33(Vector3.new(v34, v35, v36), v_u_7, 0, v_u_10)
				v37.Reflectance = 0.2
				p_u_19.glue(p_u_20, v37, function(p38)
					-- upvalues: (copy) v_u_29, (copy) v_u_32
					return p38 * v_u_29 * CFrame.new(0, 0, v_u_32 * 0.18)
				end)
				for v_u_39 = 1, 5 do
					local v_u_40 = v_u_32 * (v_u_39 * 0.12 + -0.14)
					local v41 = p_u_19.bar(Vector3.new(0.06, 0.16, 0.36) * v_u_24, v22, 0, v_u_11)
					p_u_19.glue(p_u_20, v41, function(p42)
						-- upvalues: (copy) v_u_29, (copy) v_u_24, (copy) v_u_40, (copy) v_u_39
						return p42 * v_u_29 * CFrame.new(0, v_u_24 * 0.2, v_u_40) * CFrame.Angles(v_u_39 % 2 == 0 and 0.6 or -0.6, 0, 0)
					end)
				end
				local v43 = p_u_19.bar(Vector3.new(0.3, 0.55, 0.12) * v_u_24, v_u_8, 0, v_u_10)
				p_u_19.glue(p_u_20, v43, function(p44)
					-- upvalues: (copy) v_u_29, (copy) v_u_32
					return p44 * v_u_29 * CFrame.new(0, 0, -v_u_32 * 0.18)
				end)
				local v45 = p_u_19.bar
				local v46 = v_u_24 * 0.16
				local v47 = v_u_24 * 0.18
				local v48 = v_u_32 * 0.24
				local v49 = v45(Vector3.new(v46, v47, v48), v_u_8, 0, v_u_10)
				p_u_19.glue(p_u_20, v49, function(p50)
					-- upvalues: (copy) v_u_29, (copy) v_u_32
					return p50 * v_u_29 * CFrame.new(0, 0, -v_u_32 * 0.31)
				end)
			end
			local v51 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v22, {
				["transparency"] = 1
			})
			p_u_19.add(p_u_20, v51, function(p52)
				return p52
			end)
			p_u_19.own(p_u_20, v51)
			local v_u_53 = {}
			for v54 = 1, 3 do
				local v55 = Instance.new("Attachment")
				v55.Parent = v51
				local v56 = Instance.new("Attachment")
				v56.Parent = v51
				local v57 = v_u_2.beam(v55, v56, v_u_6.BlackBolt, v_u_9, v_u_24 * 0.45, 0, v_u_24 * 1.6, 6)
				v57.Enabled = false
				local v58 = {
					["a0"] = v55,
					["a1"] = v56,
					["beam"] = v57,
					["next"] = v54 * 0.2
				}
				table.insert(v_u_53, v58)
			end
			local function v_u_62() -- name: somewhere
				-- upvalues: (copy) v_u_24, (copy) p_u_20
				local v59 = (math.random() - 0.5) * 2.4 * v_u_24
				local v60 = (math.random() - 0.35) * (p_u_20.headY + v_u_24 * 0.8)
				local v61 = (math.random() - 0.5) * 1.6 * v_u_24
				return Vector3.new(v59, v60, v61)
			end
			local v63 = p_u_20.ticks
			table.insert(v63, function(_, p64)
				-- upvalues: (copy) v_u_28, (copy) v_u_53, (copy) v_u_62, (copy) v_u_24
				local v65 = v_u_28()
				for _, v66 in v_u_53 do
					if v66.next > p64 then
						continue
					end
					local v67 = not v66.beam.Enabled or v65 > 0.3
					local v68 = v66.beam
					if v67 then
						v67 = math.random() < 0.55 + v65
					end
					v68.Enabled = v67
					v66.a0.Position = v_u_62()
					v66.a1.Position = v66.a0.Position + (v_u_62() - v66.a0.Position) * 0.6
					v66.beam.Width0 = (0.35 + v65 * 0.5) * v_u_24
					v66.beam.Width1 = (0.2 + v65 * 0.3) * v_u_24
					v66.next = p64 + 0.08 + math.random() * (0.25 - v65 * 0.15)
				end
			end)
			local v69 = Instance.new("Attachment")
			local v70 = v_u_24 * 26
			v69.Position = Vector3.new(0, v70, 0)
			v69.Parent = v51
			local v71 = Instance.new("Attachment")
			local v72 = p_u_20.headY
			v71.Position = Vector3.new(0, v72, 0)
			v71.Parent = v51
			local v_u_73 = v_u_2.beam(v69, v71, v_u_6.BlackBolt, v_u_9, v_u_24 * 1.6 * v26, 0, v_u_24 * 6, 12)
			v_u_73.Enabled = false
			local v74 = v_u_3.part
			local v75 = v_u_24 * 2.4
			local v76 = v_u_24 * 2.4
			local v77 = v74(Vector3.new(v75, 0.2, v76), CFrame.identity, v_u_7, {
				["transparency"] = 1
			})
			v77.Massless = true
			p_u_19.add(p_u_20, v77, function(p78)
				-- upvalues: (ref) p_u_19, (copy) p_u_20
				return CFrame.new(p_u_19.feetAt(p_u_20, p78, 0.1))
			end)
			p_u_19.own(p_u_20, v77)
			local v79 = Instance.new("Attachment")
			v79.Parent = v77
			local v80 = v_u_18(v_u_6.BlackFork, v_u_9, 0.15)
			v80.Lifetime = NumberRange.new(0.18, 0.3)
			v80.Size = v_u_2.seq({
				{ 0, 1.6 },
				{ 1, 2 }
			}, v_u_24 * v26)
			v80.Transparency = v_u_2.seq({
				{ 0, 0 },
				{ 0.6, 0.2 },
				{ 1, 1 }
			})
			v80.Rotation = NumberRange.new(0, 360)
			v80:SetAttribute("BaseRate", 0.9)
			v80.Rate = 0.9 * v27
			v80.Enabled = true
			v80.Parent = v79
			local v_u_81 = v_u_18(v_u_6.BlackFork, v_u_9, 0.2)
			v_u_81.Lifetime = NumberRange.new(0.6)
			v_u_81.Size = v_u_2.seq({
				{ 0, 2 },
				{ 0.15, 5.5 },
				{ 1, 6 }
			}, v_u_24 * v26)
			v_u_81.Transparency = v_u_2.seq({
				{ 0, 0 },
				{ 0.5, 0.15 },
				{ 1, 1 }
			})
			v_u_81.Rotation = NumberRange.new(0, 360)
			v_u_81.Parent = v79
			local v_u_82 = Instance.new("ParticleEmitter")
			v_u_82.Texture = v_u_6.Glow
			v_u_82.Color = ColorSequence.new(v22)
			v_u_82.LightEmission = 0.8
			v_u_82.LightInfluence = 0
			v_u_82.Lifetime = NumberRange.new(0.3)
			v_u_82.Size = v_u_2.seq({
				{ 0, 3 },
				{ 1, 6 }
			}, v_u_24 * v26)
			v_u_82.Transparency = v_u_2.seq({
				{ 0, 0.2 },
				{ 1, 1 }
			})
			v_u_82.Speed = NumberRange.new(0)
			v_u_82.LockedToPart = true
			v_u_82.Rate = 0
			v_u_82.Enabled = false
			v_u_82.Parent = v79
			local v_u_83 = Instance.new("ParticleEmitter")
			v_u_83.Texture = v_u_6.Glow
			v_u_83.Color = ColorSequence.new(v_u_9, v22)
			v_u_83.LightEmission = 1
			v_u_83.LightInfluence = 0
			v_u_83.Orientation = Enum.ParticleOrientation.VelocityParallel
			v_u_83.Squash = NumberSequence.new(1.5)
			v_u_83.Lifetime = NumberRange.new(0.25, 0.45)
			v_u_83.Size = v_u_2.seq({
				{ 0, 0.35 },
				{ 1, 0.05 }
			}, v_u_24)
			v_u_83.Speed = NumberRange.new(v_u_24 * 8, v_u_24 * 14)
			v_u_83.SpreadAngle = Vector2.new(80, 80)
			v_u_83.EmissionDirection = Enum.NormalId.Top
			v_u_83.Acceleration = Vector3.new(0, -30, 0)
			v_u_83.Rate = 0
			v_u_83.Enabled = false
			v_u_83.Parent = v79
			local v_u_84 = -1
			local v85 = p_u_20.ticks
			local function v89(p86)
				-- upvalues: (copy) v_u_28, (ref) v_u_84, (ref) p_u_19, (copy) v_u_81, (copy) v_u_82, (copy) v_u_83, (ref) v_u_5, (copy) v_u_73
				local v87 = v_u_28() * 20
				local v88 = math.floor(v87) / 20
				if v88 ~= v_u_84 then
					if v88 > 0.95 and (v_u_84 <= 0.95 and (p86.Position - p_u_19.camPos()).Magnitude < 150) then
						v_u_81:Emit(1)
						v_u_82:Emit(1)
						v_u_83:Emit(v_u_5.level() >= 2 and 14 or 6)
					end
					v_u_73.Enabled = v88 > 0.55
					v_u_73.TextureSpeed = v88 * 10 + 12
					v_u_84 = v88
				end
			end
			table.insert(v85, v89)
		end
	}
end