local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("38D6FF")
local v_u_8 = Color3.fromHex("04222E")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(205, 245, 255)
local v_u_11 = Color3.fromRGB(150, 230, 255)
local v_u_12 = Color3.fromRGB(8, 14, 20)
local v_u_13 = Enum.PartType.Ball
local v_u_14 = Enum.Material.Glass
local v_u_15 = Enum.Material.SmoothPlastic
local function v_u_18(p16, p17) -- name: glowing
	return Color3.new(p16.R * p17, p16.G * p17, p16.B * p17)
end
local v_u_19 = Color3.new(v_u_7.R * 1.7, v_u_7.G * 1.7, v_u_7.B * 1.7)
local v_u_20 = Color3.new(v_u_10.R * 1.6, v_u_10.G * 1.6, v_u_10.B * 1.6)
local function v_u_27(p21, p22, p23) -- name: face
	local v24 = p23 - p22 * p23:Dot(p22)
	local v25
	if v24.Magnitude > 0.001 then
		v25 = v24.Unit
	else
		local v26 = p22.Y
		v25 = math.abs(v26) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p21, p22:Cross(v25), p22, v25)
end
local function v_u_37(p28, p29, p30) -- name: toward
	-- upvalues: (copy) v_u_3, (copy) v_u_27
	local v31 = v_u_3.CurrentCamera
	local v32
	if v31 then
		local v33 = v31.CFrame.Position - p28
		v32 = v33.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v33.Unit
	else
		v32 = Vector3.new(0, 0, 1)
	end
	local v34 = Vector3.new(0, 1, 0) - v32 * (Vector3.new(0, 1, 0)):Dot(v32)
	local v35 = v34.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v34.Unit
	local v36 = v35:Cross(v32)
	return v_u_27(p28 + v32 * (p30 or 0), v32, v35 * math.cos(p29) + v36 * math.sin(p29))
end
local function v_u_56(p38, p39, p40, p41, p42) -- name: picture
	-- upvalues: (copy) v_u_4
	local v43 = Color3.new
	local v44 = p41.R
	local v45 = math.min(v44, 1)
	local v46 = p41.G
	local v47 = math.min(v46, 1)
	local v48 = p41.B
	local v49 = v43(v45, v47, (math.min(v48, 1)))
	local v50 = v_u_4.part
	local v51 = p39 * 2
	local v52 = p39 * 2
	local v53 = v50(Vector3.new(v51, 0.05, v52), p38, v49, {
		["transparency"] = 1
	})
	for _, v54 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v55 = Instance.new("Decal")
		v55.Face = v54
		v55.Texture = p40
		v55.Color3 = p41
		v55.Transparency = p42
		v55.Parent = v53
	end
	return v53
end
local function v_u_60(p57, p58) -- name: setAlpha
	for _, v59 in p57:GetChildren() do
		if not v59:IsA("Decal") then
			continue
		end
		v59.Transparency = p58
	end
end
local function v_u_64(p61, p62) -- name: setTint
	for _, v63 in p61:GetChildren() do
		if not v63:IsA("Decal") then
			continue
		end
		v63.Color3 = p62
	end
end
return function(p_u_65)
	-- upvalues: (copy) v_u_56, (copy) v_u_37, (copy) v_u_1, (copy) v_u_60, (copy) v_u_4, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_14, (copy) v_u_7, (copy) v_u_12, (copy) v_u_13, (copy) v_u_15, (copy) v_u_6, (copy) v_u_19, (copy) v_u_27, (copy) v_u_3, (copy) v_u_5, (copy) v_u_64, (copy) v_u_18, (copy) v_u_20, (copy) v_u_8
	local v66 = {}
	local function v_u_84(p_u_67, p_u_68, p_u_69, p70, p71, p_u_72, p_u_73, p74) -- name: flare
		-- upvalues: (ref) v_u_56, (ref) v_u_37, (ref) v_u_1, (copy) p_u_65, (ref) v_u_60
		local v_u_75 = p74 or 0
		local v_u_76 = math.random() * 6.283185307179586
		local v_u_77 = v_u_56(v_u_37(p_u_67, v_u_76), p_u_68, p70, p71, v_u_75)
		v_u_1:AddItem(v_u_77, p_u_72 + 0.1)
		p_u_65.animate(p_u_72, 0, function(p78)
			-- upvalues: (copy) v_u_77, (copy) p_u_68, (copy) p_u_69, (ref) v_u_37, (copy) p_u_67, (copy) v_u_76, (copy) p_u_72, (copy) p_u_73, (ref) v_u_60, (copy) v_u_75
			local v79 = v_u_77
			local v80 = p_u_68 + (p_u_69 - p_u_68) * (1 - (1 - p78) ^ 3)
			local v81 = math.max(v80, 0.03)
			local v82 = v81 * 2
			local v83 = v81 * 2
			v79.Size = Vector3.new(v82, 0.05, v83)
			v_u_77.CFrame = v_u_37(p_u_67, v_u_76 + p78 * p_u_72 * p_u_73)
			v_u_60(v_u_77, v_u_75 + (1 - v_u_75) * p78 ^ 1.6)
			if p78 >= 1 then
				v_u_77:Destroy()
			end
		end)
	end
	local function v_u_108(p85, p86, p87, p88, p89) -- name: shards
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_14, (ref) v_u_1
		for v90 = 1, p86 do
			local v91 = v90 / p86 * 6.283185307179586 + math.random() * 0.6
			local v92 = math.cos(v91)
			local v93 = 0.35 + math.random() * 0.8
			local v94 = math.sin(v91)
			local v95 = Vector3.new(v92, v93, v94).Unit
			local v96 = p88 * (0.8 + math.random() * 0.7)
			local v97 = v_u_4.part
			local v98 = v96 * 0.3
			local v99 = v96 * 0.3
			local v100 = Vector3.new(v98, v99, v96)
			local v101 = CFrame.lookAt(p85, p85 + v95) * CFrame.Angles(0, 0, 0.7853981633974483)
			local v102
			if v90 % 3 == 0 then
				v102 = v_u_9
			elseif v90 % 3 == 1 then
				v102 = v_u_10
			else
				v102 = v_u_11
			end
			local v103 = v97(v100, v101, v102, {
				["material"] = nil,
				["transparency"] = 0.1,
				["material"] = v_u_14
			})
			local v104 = CFrame.lookAt(p85 + v95 * p87, p85 + v95 * (p87 + 1)) * CFrame.Angles(math.random() * 3, math.random() * 3, math.random() * 3)
			local v105 = v_u_4.tween
			local v106 = {
				["CFrame"] = nil,
				["Size"] = nil,
				["Transparency"] = 1,
				["CFrame"] = v104
			}
			local v107 = v96 * 0.4
			v106.Size = Vector3.new(0.05, 0.05, v107)
			v105(v103, p89, v106, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			v_u_1:AddItem(v103, p89 + 0.05)
		end
	end
	local function v_u_139(p_u_109, p_u_110, p_u_111, p112, p113, p114) -- name: crystal
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_14, (copy) p_u_65, (ref) v_u_1
		local v_u_115 = (Vector3.new(0, 1, 0) + (p112 or Vector3.new(0, 0, 0))).Unit
		local v_u_116 = math.random() * 6.283185307179586
		local function v_u_121(p117) -- name: frame
			-- upvalues: (copy) p_u_109, (copy) v_u_115, (copy) v_u_116
			local v118 = p_u_109 + v_u_115 * (p117 * 0.5 - 0.3)
			local v119 = v_u_115.Y
			local v120 = math.abs(v119) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
			return CFrame.lookAt(v118, v118 + v_u_115, v120) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, v_u_116, 0) * CFrame.Angles(0, 0.7853981633974483, 0)
		end
		local v_u_122 = v_u_4.part(Vector3.new(p_u_111, 0.1, p_u_111), v_u_121(0.1), p114 or v_u_11, {
			["material"] = nil,
			["transparency"] = 0.12,
			["material"] = v_u_14
		})
		local v123 = p113 * 0.3
		local v124 = math.min(0.12, v123)
		p_u_65.animate(v124, 0, function(p125)
			-- upvalues: (copy) p_u_110, (copy) v_u_122, (copy) p_u_111, (copy) v_u_121
			local v126 = p_u_110
			local v127 = p125 - 1
			local v128 = v126 * (v127 * 2.7 * v127 * v127 + 1 + v127 * 1.7 * v127)
			local v129 = math.max(v128, 0.1)
			local v130 = v_u_122
			local v131 = p_u_111 * (0.6 + 0.4 * p125)
			local v132 = p_u_111 * (0.6 + 0.4 * p125)
			v130.Size = Vector3.new(v131, v129, v132)
			v_u_122.CFrame = v_u_121(v129)
		end)
		p_u_65.after(p113, function()
			-- upvalues: (copy) v_u_122, (ref) v_u_4, (copy) p_u_111, (copy) p_u_110, (ref) v_u_1
			if v_u_122.Parent then
				local v133 = v_u_4.tween
				local v134 = v_u_122
				local v135 = {
					["Transparency"] = 1,
					["Size"] = nil
				}
				local v136 = p_u_111 * 0.2
				local v137 = p_u_110 * 0.4
				local v138 = p_u_111 * 0.2
				v135.Size = Vector3.new(v136, v137, v138)
				v133(v134, 0.3, v135)
				v_u_1:AddItem(v_u_122, 0.32)
			end
		end)
		v_u_1:AddItem(v_u_122, p113 + 1)
	end
	v66.glacier_sharingan_a = {
		["cast"] = function(p140) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_65, (ref) v_u_9, (copy) v_u_84, (ref) v_u_6, (ref) v_u_19
			local v141 = p140.size
			local v142 = p140.eye + p140.dir * 1.2
			v_u_4.flash(v142, v_u_7, 3 * v141, 0.12)
			p_u_65.pop(v142, v_u_9, 1.2 * v141, 0.3 * v141, 0.1)
			if not p140.lite then
				v_u_84(v142, 1.6 * v141, 0.4 * v141, v_u_6.GlacierMark, v_u_19, 0.13, 22, 0)
			end
		end,
		["shot"] = function(p143, p144) -- name: tomoeShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_14, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15, (ref) v_u_1, (copy) p_u_65
			local v_u_145 = p143.size
			local v_u_146 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p144, v_u_7, {
				["transparency"] = 1
			})
			local v147 = {
				["material"] = nil,
				["transparency"] = 0.35,
				["material"] = v_u_14
			}
			local v_u_148 = v_u_4.part(Vector3.new(1, 1, 1.9) * v_u_145, p144, v_u_10, v147)
			local v149 = {
				["shape"] = v_u_13,
				["material"] = v_u_15
			}
			local v_u_150 = v_u_4.part(Vector3.new(0.52, 0.52, 0.52) * v_u_145, p144, v_u_12, v149)
			local v151 = {
				["material"] = v_u_15
			}
			local v_u_152 = v_u_4.part(Vector3.new(0.16, 0.42, 0.16) * v_u_145, p144, v_u_12, v151)
			local v_u_153 = { v_u_148, v_u_150, v_u_152 }
			local v_u_154
			if p143.lite then
				v_u_154 = nil
			else
				local v155 = {
					["shape"] = nil,
					["transparency"] = 0.65,
					["shape"] = v_u_13
				}
				v_u_154 = v_u_4.part(Vector3.new(1.5, 1.5, 1.5) * v_u_145, p144, v_u_7, v155)
				table.insert(v_u_153, v_u_154)
			end
			for _, v156 in v_u_153 do
				v_u_1:AddItem(v156, 4)
			end
			v_u_1:AddItem(v_u_146, 4)
			p_u_65.streak(v_u_146, v_u_10, v_u_7, 1.2 * v_u_145, p143.lite and 0.1 or 0.16)
			if p143.mine then
				p_u_65.light(v_u_146, v_u_7, 9 * v_u_145)
			end
			local v_u_157 = false
			return {
				["place"] = function(p158, p159) -- name: place
					-- upvalues: (copy) v_u_146, (copy) v_u_148, (copy) v_u_150, (copy) v_u_145, (copy) v_u_152, (ref) v_u_154
					v_u_146.CFrame = p158
					local v160 = p158 * CFrame.Angles(0, 0, p159 * 16)
					v_u_148.CFrame = v160 * CFrame.Angles(0, 0, 0.7853981633974483)
					v_u_150.CFrame = v160 * CFrame.new(0, 0, 0.12 * v_u_145)
					v_u_152.CFrame = v160 * CFrame.new(0.22 * v_u_145, 0.12 * v_u_145, -0.12 * v_u_145) * CFrame.Angles(0, 0, -0.9)
					local v161 = v_u_154
					if v161 then
						v161.CFrame = p158
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_157, (copy) v_u_146, (ref) v_u_1, (copy) v_u_153
					if not v_u_157 then
						v_u_157 = true
						local v162 = v_u_146:FindFirstChildWhichIsA("PointLight")
						if v162 then
							v162:Destroy()
						end
						v_u_1:AddItem(v_u_146, 0.25)
						for _, v163 in v_u_153 do
							v163:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p164, p165) -- name: tomoeImpact
			-- upvalues: (copy) v_u_108, (copy) v_u_84, (ref) v_u_6, (ref) v_u_19, (copy) p_u_65, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4, (ref) v_u_11
			local v166 = p164.size
			v_u_108(p165, p164.lite and 3 or 6, 4.5 * v166, 1.3 * v166, 0.32)
			v_u_84(p165, 0.7 * v166, 2.6 * v166, v_u_6.GlacierMark, v_u_19, 0.24, -20, 0)
			p_u_65.pop(p165, v_u_9, 1 * v166, 2.6 * v166, 0.14)
			p_u_65.pop(p165, v_u_7, 1.4 * v166, 4.2 * v166, 0.22, 0.45)
			v_u_4.ring(p_u_65.ground(p165), v_u_11, p164.ability.radius * 0.7 * v166, 0.28, v_u_6.Ring)
			p_u_65.burst("Impact", p165, v_u_7, 0.8 * v166)
			p_u_65.hitSound(p165)
		end,
		["hit"] = p_u_65.simpleHit(v_u_7, 0.55)
	}
	local function v_u_190(p_u_167) -- name: pinwheel
		-- upvalues: (ref) v_u_56, (ref) v_u_27, (ref) v_u_6, (ref) v_u_19, (ref) v_u_7, (ref) v_u_1, (copy) p_u_65, (ref) v_u_60, (ref) v_u_4, (ref) v_u_10, (ref) v_u_9
		local v_u_168 = p_u_167.size
		local v_u_169 = p_u_167.eye + p_u_167.dir * 4.5 + Vector3.new(0, 0.6, 0)
		local v_u_170 = -p_u_167.dir
		local v_u_171 = v_u_56(v_u_27(v_u_169, v_u_170, Vector3.new(0, 1, 0)), 0.4 * v_u_168, v_u_6.GlacierMark, v_u_19, 0)
		local v_u_172 = v_u_56(v_u_27(v_u_169 - v_u_170 * 0.15, v_u_170, Vector3.new(0, 1, 0)), 0.4 * v_u_168, v_u_6.Glow, v_u_7, 0.35)
		v_u_1:AddItem(v_u_171, 0.5)
		v_u_1:AddItem(v_u_172, 0.5)
		local v_u_173 = 0
		local v_u_174 = os.clock()
		p_u_65.animate(0.32, 0, function(p175)
			-- upvalues: (ref) v_u_173, (ref) v_u_174, (copy) v_u_168, (copy) v_u_171, (copy) v_u_172, (ref) v_u_27, (copy) v_u_169, (copy) v_u_170, (ref) v_u_60
			local v176 = os.clock()
			v_u_173 = v_u_173 + (v176 - v_u_174) * (6 + 40 * p175)
			v_u_174 = v176
			local v177 = 3.4 * v_u_168
			local v178 = p175 / 0.45
			local v179 = math.min(v178, 1) - 1
			local v180 = v177 * (v179 * 2.7 * v179 * v179 + 1 + v179 * 1.7 * v179)
			local v181 = v_u_171
			local v182 = math.max(v180, 0.03)
			local v183 = v182 * 2
			local v184 = v182 * 2
			v181.Size = Vector3.new(v183, 0.05, v184)
			local v185 = v_u_172
			local v186 = v180 * 1.3
			local v187 = math.max(v186, 0.03)
			local v188 = v187 * 2
			local v189 = v187 * 2
			v185.Size = Vector3.new(v188, 0.05, v189)
			v_u_171.CFrame = v_u_27(v_u_169, v_u_170, CFrame.fromAxisAngle(v_u_170, v_u_173):VectorToWorldSpace(Vector3.new(0, 1, 0)))
			if p175 > 0.75 then
				v_u_60(v_u_171, (p175 - 0.75) / 0.25)
				v_u_60(v_u_172, 0.35 + 0.65 * (p175 - 0.75) / 0.25)
			end
			if p175 >= 1 then
				v_u_171:Destroy()
				v_u_172:Destroy()
			end
		end)
		p_u_65.after(0.26, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_169, (ref) v_u_10, (copy) v_u_168, (copy) p_u_167, (ref) p_u_65, (ref) v_u_9
			v_u_4.flash(v_u_169, v_u_10, 6 * v_u_168, 0.18)
			if not p_u_167.lite then
				p_u_65.spikes(v_u_169, v_u_9, 6, 6 * v_u_168, 0.2, p_u_167.dir, 0.9)
			end
		end)
	end
	v66.glacier_sharingan_e = {
		["cast"] = nil,
		["shot"] = nil,
		["weave"] = 1.6,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p191) -- name: cast
			-- upvalues: (copy) p_u_65, (ref) v_u_7, (copy) v_u_190
			p_u_65.skillCast(p191, v_u_7)
			v_u_190(p191)
		end,
		["shot"] = function(p192, p193) -- name: bladeShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_56, (ref) v_u_6, (ref) v_u_19, (ref) v_u_13, (ref) v_u_1, (copy) p_u_65, (ref) v_u_9, (ref) v_u_37, (copy) v_u_139
			local v_u_194 = p192.size
			local v_u_195 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p193, v_u_7, {
				["transparency"] = 1
			})
			local v_u_196 = v_u_56(p193, 1.25 * v_u_194, v_u_6.GlacierBlade, v_u_19, 0)
			local v197 = {
				["shape"] = nil,
				["transparency"] = 0.72,
				["shape"] = v_u_13
			}
			local v_u_198 = v_u_4.part(Vector3.new(1.6, 1.6, 1.6) * v_u_194, p193, v_u_7, v197)
			for _, v199 in { v_u_195, v_u_196, v_u_198 } do
				v_u_1:AddItem(v199, 4)
			end
			p_u_65.streak(v_u_195, v_u_9, v_u_7, 0.9 * v_u_194, p192.lite and 0.1 or 0.18)
			local v_u_200 = p_u_65.ground(p193.Position, 0.08)
			local v_u_201
			if p192.lite then
				v_u_201 = nil
			else
				local v202 = v_u_4.part
				local v203 = 1 * v_u_194
				v_u_201 = v202(Vector3.new(v203, 0.1, 0.1), CFrame.new(v_u_200), v_u_7, {
					["transparency"] = 0.45
				})
				v_u_1:AddItem(v_u_201, 4)
			end
			local v_u_204 = 0
			local v_u_205 = false
			return {
				["place"] = function(p206, p207) -- name: place
					-- upvalues: (copy) v_u_195, (copy) v_u_198, (copy) v_u_196, (ref) v_u_37, (ref) v_u_201, (ref) p_u_65, (copy) v_u_200, (copy) v_u_194, (ref) v_u_204, (ref) v_u_139
					local v208 = p206.Position
					v_u_195.CFrame = p206
					v_u_198.CFrame = p206
					v_u_196.CFrame = v_u_37(v208, -p207 * 26, 0.3)
					local v209 = v_u_201
					if v209 then
						local v210 = p_u_65.ground(v208, 0.08)
						local v211 = (v210 - v_u_200).Magnitude
						if v211 > 0.2 then
							local v212 = 1 * v_u_194
							v209.Size = Vector3.new(v212, 0.1, v211)
							v209.CFrame = CFrame.lookAt((v_u_200 + v210) / 2, v210)
						end
						if v211 - v_u_204 > 9 then
							v_u_204 = v211
							v_u_139(v210, 2.2 * v_u_194, 0.7 * v_u_194, nil, 0.35)
						end
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_205, (ref) v_u_1, (copy) v_u_195, (copy) v_u_196, (copy) v_u_198, (ref) v_u_201, (ref) v_u_4
					if not v_u_205 then
						v_u_205 = true
						v_u_1:AddItem(v_u_195, 0.3)
						v_u_196:Destroy()
						v_u_198:Destroy()
						local v213 = v_u_201
						if v213 then
							v_u_4.tween(v213, 0.6, {
								["Transparency"] = 1
							}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
							v_u_1:AddItem(v213, 0.65)
						end
					end
				end
			}
		end,
		["impact"] = function(p214, p215) -- name: bladeImpact
			-- upvalues: (copy) p_u_65, (copy) v_u_84, (ref) v_u_6, (ref) v_u_19, (ref) v_u_10, (ref) v_u_4, (ref) v_u_7, (copy) v_u_139, (copy) v_u_108
			local v216 = p214.size
			local v217 = p_u_65.ground(p215, 0)
			v_u_84(p215, 1.2 * v216, 3.4 * v216, v_u_6.GlacierBlade, v_u_19, 0.22, 14, 0.1)
			p_u_65.pop(p215, v_u_10, 1.2 * v216, 4.6 * v216, 0.22, 0.25)
			v_u_4.ring(v217, v_u_7, p214.ability.radius * 1.2 * v216, 0.3, v_u_6.Shockwave)
			if not p214.lite then
				for v218 = 1, 3 do
					local v219 = v218 * 6.283185307179586 / 3 + math.random()
					local v220 = v_u_139
					local v221 = 2.6 * v216
					local v222 = 0.75 * v216
					local v223 = math.cos(v219)
					local v224 = math.sin(v219)
					v220(v217, v221, v222, Vector3.new(v223, 0, v224) * 0.6, 0.4)
				end
				v_u_108(p215, 4, 4 * v216, 1.1 * v216, 0.3)
			end
			p_u_65.burst("Impact", p215, v_u_7, 0.9 * v216)
			p_u_65.hitSound(p215)
		end,
		["hit"] = function(p225, p226, _) -- name: hit
			-- upvalues: (copy) p_u_65, (ref) v_u_7, (ref) v_u_11, (ref) v_u_14
			p_u_65.burst("Impact", p226, v_u_7, 0.65)
			if not p225.lite then
				p_u_65.pop(p226, v_u_11, 1.5, 3.4, 0.25, 0.3, v_u_14)
			end
		end
	}
	local v_u_227 = {}
	setmetatable(v_u_227, {
		["__mode"] = "k"
	})
	local function v_u_253(_, p228, p_u_229) -- name: openSky
		-- upvalues: (copy) p_u_65, (ref) v_u_56, (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1
		local v230 = p_u_65.ground(p228, 0)
		local v231 = v230 + Vector3.new(0, 26, 0)
		local v_u_232 = CFrame.new(v231) * CFrame.Angles(3.141592653589793, 0, 0)
		local v_u_233 = v_u_56(v_u_232, 0.1, p_u_65.iris("glacier_sharingan"), v_u_9, 0)
		local v_u_234 = v_u_56(CFrame.new(v231 + Vector3.new(0, 0.3, 0)), 0.1, v_u_6.Glow, v_u_7, 0.25)
		v_u_1:AddItem(v_u_233, p_u_229 + 1)
		v_u_1:AddItem(v_u_234, p_u_229 + 1)
		local v_u_235 = {
			["g"] = nil,
			["eye"] = nil,
			["glow"] = nil,
			["born"] = nil,
			["closeAt"] = nil,
			["g"] = v230,
			["eye"] = v_u_233,
			["glow"] = v_u_234,
			["born"] = os.clock()
		}
		p_u_65.runNow(function()
			-- upvalues: (copy) v_u_235, (copy) v_u_233, (copy) v_u_234, (copy) v_u_232, (copy) p_u_229
			local v236 = os.clock()
			local v237 = v236 - v_u_235.born
			local v238 = v237 / 0.22
			local v239 = math.clamp(v238, 0, 1) - 1
			local v240 = v239 * 2.7 * v239 * v239 + 1 + v239 * 1.7 * v239
			local v241 = v_u_235.closeAt
			if v241 then
				local v242 = 1 - (v236 - v241) / 0.25
				v240 = v240 * math.max(v242, 0)
				if v236 - v241 >= 0.25 then
					v_u_233:Destroy()
					v_u_234:Destroy()
					return false
				end
			end
			local v243 = v_u_233
			local v244 = v240 * 9.5
			local v245 = math.max(v244, 0.03)
			local v246 = v245 * 2
			local v247 = v245 * 2
			v243.Size = Vector3.new(v246, 0.05, v247)
			local v248 = v_u_234
			local v249 = v240 * 14.25
			local v250 = math.max(v249, 0.03)
			local v251 = v250 * 2
			local v252 = v250 * 2
			v248.Size = Vector3.new(v251, 0.05, v252)
			v_u_233.CFrame = v_u_232 * CFrame.Angles(0, -v237 * 1.4, 0)
			return v237 < p_u_229 + 0.5
		end)
		return v_u_235
	end
	local function v_u_349(p_u_254, p255, p_u_256) -- name: freeze
		-- upvalues: (ref) v_u_56, (ref) v_u_6, (ref) v_u_19, (ref) v_u_1, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (copy) p_u_65, (ref) v_u_3, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (ref) v_u_64, (ref) v_u_18, (ref) v_u_20, (ref) v_u_60, (copy) v_u_139
		local v_u_257 = p_u_254.ability.radius
		local v_u_258 = p255.g
		local v_u_259 = p_u_254.lite
		local v260 = p_u_256 + 1.5
		local v261 = math.random() * 6.283185307179586
		local v_u_262 = {}
		for v263 = 1, 3 do
			local v264 = v_u_56(CFrame.new(v_u_258 + Vector3.new(0, 26, 0)), 6.2, v_u_6.GlacierBlade, v_u_19, 0)
			v_u_1:AddItem(v264, v260)
			local v265 = {
				["p"] = v264,
				["a"] = v261 + (v263 - 1) * 6.283185307179586 / 3
			}
			table.insert(v_u_262, v265)
		end
		local v_u_266 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_258), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_266, v260)
		local v267 = {}
		local v268 = {}
		for v269 = 1, 3 do
			local v270 = v_u_262[v269].p
			local v271 = Instance.new("Attachment")
			v271.Position = Vector3.new(0, 0, 3.41)
			v271.Parent = v270
			local v272 = Instance.new("Attachment")
			v272.Position = Vector3.new(0, 0, -3.6828)
			v272.Parent = v270
			v267[v269] = v271
			v268[v269] = v272
		end
		local v_u_273 = {}
		for v274 = 1, 3 do
			local v275 = v274 % 3 + 1
			local v276
			if v_u_259 then
				v276 = {
					{ v267[v274], v267[v275] }
				}
			else
				v276 = {
					{ v267[v274], v267[v275] },
					{ v268[v274], v268[v275] }
				}
			end
			for _, v277 in v276 do
				local v278 = Instance.new("Beam")
				v278.Attachment0 = v277[1]
				v278.Attachment1 = v277[2]
				v278.Texture = v_u_6.Beam
				v278.TextureMode = Enum.TextureMode.Wrap
				v278.TextureLength = 10
				v278.TextureSpeed = 3
				v278.Color = ColorSequence.new(v_u_10, v_u_7)
				v278.LightEmission = 1
				v278.LightInfluence = 0
				v278.FaceCamera = true
				v278.Segments = 1
				v278.Width0 = 2.6
				v278.Width1 = 2.6
				v278.Transparency = NumberSequence.new(1)
				v278.Parent = v_u_266
				table.insert(v_u_273, v278)
			end
		end
		p_u_65.mark(v_u_258, v_u_10, v_u_257 * 1.05, p_u_256 + 0.6, v_u_6.CrackLines, 0.15)
		p_u_65.mark(v_u_258, v_u_7, v_u_257 * 1.1, p_u_256 + 0.4, v_u_6.Glow, 0.4)
		local v_u_279 = v_u_259 and function() end or p_u_65.loopAt("Charge", v_u_258 + Vector3.new(0, 3, 0), v_u_10, 1.2)
		local v_u_280 = os.clock()
		local v_u_281 = false
		local v_u_282 = 0.4
		local v_u_283 = false
		local v_u_284 = nil
		local v_u_285 = {}
		local v_u_286 = {}
		p_u_65.runNow(function()
			-- upvalues: (copy) v_u_280, (ref) v_u_283, (ref) v_u_284, (copy) p_u_256, (copy) v_u_257, (copy) v_u_285, (copy) v_u_286, (copy) v_u_262, (copy) v_u_258, (ref) v_u_3, (ref) v_u_281, (copy) v_u_273, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) p_u_65, (ref) v_u_10, (ref) v_u_7, (copy) v_u_259, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (copy) p_u_254, (ref) v_u_282, (ref) v_u_64, (ref) v_u_18, (ref) v_u_19, (ref) v_u_56, (ref) v_u_20, (ref) v_u_1, (ref) v_u_60, (ref) v_u_139, (copy) v_u_266, (copy) v_u_279
			local v287 = os.clock()
			local v288 = v287 - v_u_280
			if v_u_283 and not v_u_284 then
				v_u_284 = v287
			end
			local v289 = v288 / 0.2
			local v290 = math.clamp(v289, 0, 1)
			local v291 = v288 - 0.2
			local v292 = p_u_256 - 0.2
			local v293 = v291 / math.max(v292, 0.1)
			local v294 = math.clamp(v293, 0, 1)
			local v295 = v_u_257
			local v296 = math.clamp(v294, 0, 1)
			local v_u_297 = v295 * (v296 * v296 * (3 - v296 * 2) * -0.78 + 0.9)
			local v298 = -(v294 * 1.2 + v294 * 4.2 * v294)
			local v299 = (1 - v290 * v290) * 26
			table.clear(v_u_285)
			table.clear(v_u_286)
			for _, v300 in v_u_262 do
				local v301 = v300.a + v298
				local v302 = math.cos(v301)
				local v303 = math.sin(v301)
				local v304 = Vector3.new(v302, 0, v303)
				local v305 = v_u_258 + v304 * v_u_297 + Vector3.new(0, 1, 0) * (v299 + 4.0920000000000005 - 0.4)
				local v306 = v_u_285
				local v307 = v300.p
				table.insert(v306, v307)
				local v308 = v_u_286
				local v309 = CFrame.fromMatrix
				local v310 = v304:Cross(Vector3.new(0, 1, 0))
				table.insert(v308, v309(v305, v310, v304, Vector3.new(0, 1, 0)))
			end
			v_u_3:BulkMoveTo(v_u_285, v_u_286, Enum.BulkMoveMode.FireCFrameChanged)
			if v290 >= 1 and not v_u_281 then
				v_u_281 = true
				local v311 = NumberSequence.new(0.25)
				for _, v312 in v_u_273 do
					v312.Transparency = v311
				end
				v_u_4.ring(v_u_258, v_u_9, v_u_257 * 1.2, 0.4, v_u_6.Shockwave)
				p_u_65.burst("Shockwave", v_u_258 + Vector3.new(0, 0.3, 0), v_u_10, v_u_257 / 16)
				for _, v313 in v_u_262 do
					local v314 = v313.p.Position
					local v315 = v314.X
					local v316 = v_u_258.Y
					local v317 = v314.Z
					local v318 = Vector3.new(v315, v316, v317)
					v_u_4.ring(v318, v_u_7, 6, 0.35, v_u_6.Shockwave)
					if v_u_259 then
						continue
					end
					local v319 = { v_u_10, v_u_11, v_u_12 }
					p_u_65.chunks(v318 + Vector3.new(0, 1, 0), v319, 5, 30, 1, 0.8)
				end
				v_u_5.play("Crit", {
					["at"] = v_u_258,
					["volume"] = p_u_254.mine and 0.8 or 0.5
				})
				if p_u_254.mine then
					v_u_4.shake(0.4, 0.3)
				end
			end
			if v_u_281 and (not v_u_284 and v_u_282 <= v288) then
				v_u_282 = v_u_282 + 0.4
				for _, v320 in v_u_262 do
					v_u_64(v320.p, v_u_18(v_u_9, 1.8))
				end
				p_u_65.after(0.08, function()
					-- upvalues: (ref) v_u_262, (ref) v_u_64, (ref) v_u_19
					for _, v321 in v_u_262 do
						if not v321.p.Parent then
							continue
						end
						v_u_64(v321.p, v_u_19)
					end
				end)
				local v_u_322 = v_u_56(CFrame.new(v_u_258 + Vector3.new(0, 0.5, 0)), v_u_297 * 1.1, v_u_6.Ring, v_u_20, 0.1)
				v_u_1:AddItem(v_u_322, 0.4)
				p_u_65.animate(0.32, 0, function(p323)
					-- upvalues: (copy) v_u_322, (copy) v_u_297, (ref) v_u_60
					local v324 = v_u_322
					local v325 = v_u_297 * 1.1 * (1 - 0.85 * p323)
					local v326 = math.max(v325, 0.03)
					local v327 = v326 * 2
					local v328 = v326 * 2
					v324.Size = Vector3.new(v327, 0.05, v328)
					v_u_60(v_u_322, 0.1 + 0.9 * p323 * p323)
					if p323 >= 1 then
						v_u_322:Destroy()
					end
				end)
				for _ = 1, v_u_259 and 1 or 3 do
					local v329 = math.random() * 6.283185307179586
					local v330 = math.random() * v_u_297 * 0.9
					local v331 = v_u_258
					local v332 = math.cos(v329) * v330
					local v333 = math.sin(v329) * v330
					local v334 = v331 + Vector3.new(v332, 0, v333)
					for v335 = 1, 3 do
						local v336 = v329 + v335 * 2.1
						local v337 = math.cos(v336)
						local v338 = v329 + v335 * 2.1
						local v339 = math.sin(v338)
						local v340 = Vector3.new(v337, 0, v339) * 0.45
						local v341 = v_u_139
						local v342 = (v335 + 2) * 1.1
						local v343 = 0.9
						if v335 == 1 then
							v340 = nil
						end
						v341(v334, v342, v343, v340, 0.45)
					end
				end
				if not v_u_259 then
					p_u_65.inward(v_u_258 + Vector3.new(0, 2, 0), v_u_9, 6, v_u_297 + 2, 0.3)
				end
			end
			local v344 = v_u_284
			if v344 then
				if v287 - v344 >= 0.12 then
					for _, v345 in v_u_262 do
						v345.p:Destroy()
					end
					v_u_266:Destroy()
					v_u_279()
					return false
				end
				local v346 = (v287 - v344) / 0.12
				for _, v347 in v_u_262 do
					v_u_60(v347.p, v346)
				end
				for _, v348 in v_u_273 do
					v348.Transparency = NumberSequence.new(0.25 + 0.75 * v346)
				end
			end
			return v288 < p_u_256 + 1
		end)
		return function()
			-- upvalues: (ref) v_u_283
			v_u_283 = true
		end
	end
	local function v_u_360(p_u_350, p351) -- name: spire
		-- upvalues: (copy) p_u_65, (copy) v_u_139, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_11, (ref) v_u_6, (copy) v_u_108, (ref) v_u_8, (ref) v_u_5
		local v_u_352 = p_u_350.ability.radius
		local v_u_353 = p_u_65.ground(p351, 0)
		local v_u_354 = p_u_350.lite
		v_u_139(v_u_353, 22, 4.2, nil, 0.3, v_u_10)
		if not v_u_354 then
			for v355 = 1, 5 do
				local v356 = v355 * 6.283185307179586 / 5 + 0.3
				local v357 = math.cos(v356)
				local v358 = math.sin(v356)
				local v359 = Vector3.new(v357, 0, v358) * 0.55
				v_u_139(v_u_353 + v359 * 3, v355 % 2 * 4 + 11, 2.4, v359, 0.3)
			end
		end
		v_u_4.flash(v_u_353 + Vector3.new(0, 6, 0), v_u_9, 18, 0.2)
		p_u_65.after(0.3, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_353, (ref) v_u_9, (copy) v_u_352, (ref) p_u_65, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_6, (ref) v_u_108, (copy) v_u_354, (ref) v_u_8, (ref) v_u_5, (copy) p_u_350
			v_u_4.flash(v_u_353 + Vector3.new(0, 4, 0), v_u_9, v_u_352 * 1.8, 0.3)
			p_u_65.pop(v_u_353 + Vector3.new(0, 3, 0), v_u_7, 4, v_u_352 * 2.4, 0.5, 0.2, Enum.Material.ForceField)
			p_u_65.pop(v_u_353 + Vector3.new(0, 3, 0), v_u_10, 3, v_u_352 * 1.5, 0.35, 0.3)
			p_u_65.dome(v_u_353, v_u_352 * 1.3, v_u_11, 0.5)
			v_u_4.ring(v_u_353, v_u_9, v_u_352 * 1.6, 0.5, v_u_6.Shockwave)
			v_u_4.ring(v_u_353, v_u_7, v_u_352 * 1.9, 0.7, v_u_6.Ring)
			p_u_65.burst("Shockwave", v_u_353 + Vector3.new(0, 0.3, 0), v_u_10, v_u_352 / 12)
			p_u_65.burst("Explosion", v_u_353 + Vector3.new(0, 3, 0), v_u_7, 2)
			v_u_108(v_u_353 + Vector3.new(0, 6, 0), v_u_354 and 6 or 16, v_u_352 * 1.2, 3.4, 0.6)
			p_u_65.chunks(v_u_353 + Vector3.new(0, 1, 0), {
				v_u_10,
				v_u_11,
				v_u_9,
				v_u_8
			}, v_u_354 and 5 or 10, 55, 0.8, 1.2, false, 1)
			p_u_65.spikes(v_u_353 + Vector3.new(0, 3, 0), v_u_9, v_u_354 and 6 or 12, v_u_352 * 1.5, 0.35, Vector3.new(0, 1, 0), 1)
			p_u_65.mark(v_u_353, v_u_10, v_u_352 * 1.1, 1.2, v_u_6.CrackLines, 0.05)
			v_u_5.play("Explosion", {
				["at"] = v_u_353,
				["volume"] = p_u_350.mine and 1 or 0.6
			})
			if p_u_350.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end)
	end
	v66.glacier_sharingan_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p361) -- name: cast
			-- upvalues: (copy) p_u_65, (ref) v_u_7, (copy) v_u_84, (ref) v_u_6, (ref) v_u_19, (ref) v_u_10, (ref) v_u_4
			p_u_65.skillCast(p361, v_u_7, true)
			local v362 = p361.size
			v_u_84(p361.eye + p361.dir * 1.4, 3.8 * v362, 0.5 * v362, v_u_6.GlacierMark, v_u_19, 0.3, 16, 0)
			if not p361.lite then
				p_u_65.glint(p361.eye, v_u_10, 5 * v362, 0.22)
			end
			if p361.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p363, p364, p365) -- name: windup
			-- upvalues: (copy) v_u_253, (copy) v_u_227, (copy) p_u_65, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10
			local v366 = v_u_253(p363, p364, p365 + (p363.ability.duration or 2.4) + 0.4)
			v_u_227[p363] = v366
			p_u_65.mark(v366.g, v_u_7, p363.ability.radius, p365 + 0.4, v_u_6.Glow, 0.45)
			if not p363.lite then
				p_u_65.inward(v366.g + Vector3.new(0, 26, 0), v_u_10, 8, 16, (math.max(p365, 0.15)))
			end
		end,
		["zone"] = function(p367, p368, p369) -- name: zone
			-- upvalues: (copy) v_u_227, (copy) v_u_253, (copy) v_u_349, (copy) p_u_65
			local v_u_370 = v_u_227[p367] or v_u_253(p367, p368, p369 + 0.4)
			v_u_227[p367] = nil
			local v371 = v_u_349(p367, v_u_370, p369)
			p_u_65.after(0.7, function()
				-- upvalues: (copy) v_u_370
				v_u_370.closeAt = os.clock()
			end)
			return v371
		end,
		["finish"] = function(p372, p373) -- name: finish
			-- upvalues: (copy) v_u_360
			v_u_360(p372, p373)
		end,
		["hit"] = function(p374, p375, _) -- name: hit
			-- upvalues: (copy) p_u_65, (ref) v_u_7, (ref) v_u_11, (ref) v_u_14
			p_u_65.burst("Impact", p375, v_u_7, 0.7)
			if not p374.lite then
				p_u_65.pop(p375, v_u_11, 1.8, 4, 0.3, 0.25, v_u_14)
			end
		end
	}
	return v66
end