local v1 = {
	["rukon_thug"] = {
		["shirt"] = 182766575,
		["pants"] = 15491712758,
		["accessories"] = nil,
		["skin"] = "#D8A27A",
		["accessories"] = { 14977654551, 18711032340, 127525077406458 }
	},
	["stray_soul"] = {
		["shirt"] = 12021901784,
		["pants"] = 12021916961,
		["accessories"] = nil,
		["skin"] = "#C8DCF4",
		["accessories"] = { 103475905719488, 74169165820168 }
	},
	["market_brawler"] = {
		["shirt"] = 9250923712,
		["pants"] = 556476152,
		["accessories"] = nil,
		["skin"] = "#C88A60",
		["accessories"] = { 13344416609, 17361515649 }
	},
	["wandering_plus"] = {
		["shirt"] = 121383675327368,
		["pants"] = 92395641405684,
		["accessories"] = nil,
		["skin"] = "#E8F0FF",
		["accessories"] = { 6410155916, 74068695044320, 133266084521182 }
	},
	["gate_sentry"] = {
		["shirt"] = 4912964707,
		["pants"] = 14542703336,
		["accessories"] = nil,
		["skin"] = "#F0C8A0",
		["accessories"] = { 10148635503, 135795355342615 }
	},
	["wall_guard"] = {
		["shirt"] = 13123288540,
		["pants"] = 6891895756,
		["accessories"] = nil,
		["skin"] = "#E2B48C",
		["accessories"] = { 132623156507428, 18711036594, 80890689202774 }
	},
	["gate_giant"] = {
		["shirt"] = 86594073978050,
		["pants"] = 80373814330788,
		["accessories"] = nil,
		["skin"] = "#C8865A",
		["accessories"] = {
			80753116013909,
			108483135024289,
			13344413900,
			117633125827782
		}
	},
	["squad_recruit"] = {
		["shirt"] = 13265596767,
		["pants"] = 12392816767,
		["accessories"] = nil,
		["skin"] = "#F2CCA8",
		["accessories"] = { 140144384100518, 15477923628, 73976177609662 }
	},
	["barracks_officer"] = {
		["shirt"] = 9265218385,
		["pants"] = 14542701735,
		["accessories"] = nil,
		["skin"] = "#DDA97E",
		["accessories"] = {
			17409824306,
			14569349472,
			100977722789486,
			122422566509395
		}
	},
	["petal_dancer"] = {
		["shirt"] = 8899240749,
		["pants"] = 8899259569,
		["accessories"] = nil,
		["skin"] = "#F6D2C0",
		["accessories"] = {
			14354595041,
			116383713447776,
			99621949576404,
			12979537173
		}
	},
	["courtyard_guard"] = {
		["shirt"] = 14553167808,
		["pants"] = 14553207021,
		["accessories"] = nil,
		["skin"] = "#C99A70",
		["accessories"] = { 12167093765, 89142106136582 }
	},
	["tower_warden"] = {
		["shirt"] = 17434717915,
		["pants"] = 18277547227,
		["accessories"] = nil,
		["skin"] = "#E8C9A8",
		["accessories"] = { 103424254022825, 118225772141814 }
	},
	["cell_keeper"] = {
		["shirt"] = 17878212796,
		["pants"] = 17878218044,
		["accessories"] = nil,
		["skin"] = "#C99A72",
		["accessories"] = { 17335914257, 7747978279, 16029454280 }
	},
	["tower_captain"] = {
		["shirt"] = 85406453160553,
		["pants"] = 14542704087,
		["accessories"] = nil,
		["skin"] = "#F2D8C0",
		["accessories"] = {
			117261582440205,
			109346475122702,
			14900023033,
			82286653295351
		}
	},
	["sparring_shinigami"] = {
		["shirt"] = 16564637750,
		["pants"] = 5743023849,
		["accessories"] = nil,
		["skin"] = "#D49A6A",
		["accessories"] = { 134455615530343, 18408996739, 18409003788 }
	},
	["kido_trainee"] = {
		["shirt"] = 14841791490,
		["pants"] = 6541281737,
		["accessories"] = nil,
		["skin"] = "#F0D0AC",
		["accessories"] = { 116566594061559, 119814737585181, 81568883743632 }
	},
	["lab_tech"] = {
		["shirt"] = 171322222,
		["pants"] = 171323126,
		["accessories"] = nil,
		["skin"] = "#D8C8B8",
		["accessories"] = { 13471429975, 127491705557830, 17769559096 }
	},
	["mod_soul"] = {
		["shirt"] = 8925565175,
		["pants"] = 8925565877,
		["accessories"] = nil,
		["skin"] = "#F2B544",
		["accessories"] = { 99424045773374, 136106705407695, 132708752428686 }
	},
	["kido_adept"] = {
		["shirt"] = 104313908413052,
		["pants"] = 88488003538709,
		["accessories"] = nil,
		["skin"] = "#C8A888",
		["accessories"] = { 15696634771, 99602581064200, 94340483830844 }
	},
	["seal_keeper"] = {
		["shirt"] = 118623135050637,
		["pants"] = 410057630,
		["accessories"] = nil,
		["skin"] = "#E0B890",
		["accessories"] = { 110104610418996, 18136595042, 89241481938246 }
	},
	["kido_master"] = {
		["shirt"] = 95232033641519,
		["pants"] = 90202098767495,
		["accessories"] = nil,
		["skin"] = "#F0DCC8",
		["accessories"] = {
			14025341978,
			97874531257675,
			18997828161,
			16029566738
		}
	},
	["cave_hermit"] = {
		["shirt"] = 97499350471969,
		["pants"] = 10753900009,
		["accessories"] = nil,
		["skin"] = "#C8986C",
		["accessories"] = { 110068260566739, 15803385047, 16143965444 }
	},
	["training_spirit"] = {
		["shirt"] = 8562272472,
		["pants"] = 129850787152210,
		["accessories"] = nil,
		["skin"] = "#4A4450",
		["accessories"] = { 138621983965254, 14916377422, 15258305016 }
	},
	["judge_clerk"] = {
		["shirt"] = 77309062298690,
		["pants"] = 14542700992,
		["accessories"] = nil,
		["skin"] = "#E6D6C6",
		["accessories"] = { 127023916725042, 76907125225421, 83915265460994 }
	},
	["chamber_guard"] = {
		["shirt"] = 125048348198368,
		["pants"] = 99562371519839,
		["accessories"] = nil,
		["skin"] = "#C89A70",
		["accessories"] = { 100120004824514, 124606466687131 }
	},
	["execution_guard"] = {
		["shirt"] = 17697138264,
		["pants"] = 7249484566,
		["accessories"] = nil,
		["skin"] = "#B07850",
		["accessories"] = { 105335671091674, 15668746323, 16573578377 }
	},
	["sokyoku_monk"] = {
		["shirt"] = 77485493849946,
		["pants"] = 122261011692847,
		["accessories"] = nil,
		["skin"] = "#C8905E",
		["accessories"] = { 90258212140090, 80217865280332, 16280592733 }
	},
	["sokyoku_executioner"] = {
		["shirt"] = 5212075204,
		["pants"] = 15170281896,
		["accessories"] = nil,
		["skin"] = "#5A3020",
		["accessories"] = {
			362032819,
			137865599773843,
			128896215357351,
			87537545306073
		}
	},
	["rooftop_runner"] = {
		["shirt"] = 87515057605027,
		["pants"] = 74821334680521,
		["accessories"] = nil,
		["skin"] = "#E8BE96",
		["accessories"] = { 102074011210840, 17361503906, 12480970556 }
	},
	["flash_assassin"] = {
		["shirt"] = 15556962709,
		["pants"] = 15592926005,
		["accessories"] = nil,
		["skin"] = "#A87050",
		["accessories"] = { 104270953360576, 78018312906426, 86102667904414 }
	},
	["senkai_keeper"] = {
		["shirt"] = 136844942704534,
		["pants"] = 116694613454024,
		["accessories"] = nil,
		["skin"] = "#E0C4A4",
		["accessories"] = { 129905554851516, 121526090751657, 138427401844942 }
	},
	["dangai_stalker"] = {
		["shirt"] = 76504521332871,
		["pants"] = 100158973498257,
		["accessories"] = nil,
		["skin"] = "#2A2A36",
		["accessories"] = { 102092476906836, 99790770222061, 84361931803052 }
	},
	["captain_guard"] = {
		["shirt"] = 15315897977,
		["pants"] = 793255760,
		["accessories"] = nil,
		["skin"] = "#F0CCA6",
		["accessories"] = { 99532456598360, 72996936008336 }
	},
	["lieutenant_elite"] = {
		["shirt"] = 8551843861,
		["pants"] = 8551846027,
		["accessories"] = nil,
		["skin"] = "#D8A884",
		["accessories"] = { 76272767581061, 11546103801, 116528490206617 }
	},
	["head_captain"] = {
		["shirt"] = 4150749507,
		["pants"] = 14841156140,
		["accessories"] = nil,
		["skin"] = "#E8C6A0",
		["accessories"] = {
			18997874407,
			16345821501,
			97471555301484,
			131873641508713
		}
	}
}
return v1