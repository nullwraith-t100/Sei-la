local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Mythic8)
local v6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v2.Shared.Config.Textures)
v6.images({ v_u_8.DSealDial, v_u_8.DSealCross, v_u_8.FxTwinkle })
local v_u_9 = Color3.fromHex("FF2E6A")
local v_u_10 = Color3.fromHex("C9D2E6")
local v_u_11 = Color3.fromRGB(150, 0, 48)
local v_u_12 = Color3.fromRGB(22, 6, 14)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Color3.fromRGB(70, 40, 30)
local v_u_15 = Enum.Material.Neon
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_23(p17, p18, p19, p20) -- name: board
	local v21 = Instance.new("BillboardGui")
	v21.Size = UDim2.fromScale(p18, p18)
	v21.LightInfluence = 0
	v21.Brightness = 1.5
	v21.AlwaysOnTop = false
	v21.ResetOnSpawn = false
	v21.Parent = p17
	local v22 = Instance.new("ImageLabel")
	v22.BackgroundTransparency = 1
	v22.Size = UDim2.fromScale(1, 1)
	v22.Image = p19
	v22.ImageColor3 = p20
	v22.Parent = v21
	return v21, v22
end
return function(p_u_24)
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_10, (copy) v_u_15, (copy) v_u_5, (copy) v_u_11, (copy) v_u_8, (copy) v_u_16, (copy) v_u_3, (copy) v_u_23, (copy) v_u_13, (copy) v_u_1, (copy) v_u_7, (copy) v_u_14, (copy) v_u_12
	local v47 = {
		["demon_seal_a"] = {
			["cast"] = function(p25) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8, (ref) v_u_10
				local v26 = p25.size
				local v27 = p25.eye + p25.dir * 1.1
				v_u_4.flash(v27, v_u_9, 2.6 * v26, 0.1)
				v_u_5.facePic(v27, 0.6 * v26, 2.4 * v26, v_u_8.DSealCross, v_u_10, 0.14, nil, 0.2, 0)
			end,
			["shot"] = function(p28, p29) -- name: sealShot
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (ref) v_u_5, (copy) p_u_24, (ref) v_u_11
				local v30 = p28.size
				local v31 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p29, v_u_9, {
					["transparency"] = 1
				})
				local v32 = {
					{
						["p"] = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * v30, p29, v_u_9, {
							["shape"] = Enum.PartType.Ball
						}),
						["off"] = CFrame.identity
					}
				}
				for _, v33 in { 0.7853981633974483, -0.7853981633974483 } do
					local v34 = v_u_4.part
					local v35 = 0.16 * v30
					local v36 = 1.9 * v30
					local v37 = 0.16 * v30
					local v38 = v34(Vector3.new(v35, v36, v37), p29, v_u_10, {
						["material"] = v_u_15
					})
					v38.Reflectance = 0.3
					local v39 = {
						["p"] = v38,
						["off"] = CFrame.Angles(0, 0, v33)
					}
					table.insert(v32, v39)
				end
				for _, v40 in v_u_5.shotBlade(CFrame.new(0, 0, -0.25 * v30), 1.2 * v30, 0.4 * v30, 0.1 * v30, v_u_9, v_u_15) do
					table.insert(v32, v40)
				end
				p_u_24.streak(v31, v_u_9, v_u_11, 0.9 * v30, 0.12)
				if not p28.lite then
					p_u_24.light(v31, v_u_9, 8 * v30)
				end
				return p_u_24.assemble(v31, v32, {}, 0, 0, {}, 0.12, 14)
			end,
			["impact"] = function(p41, p42) -- name: sealStamp
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_16
				local v43 = p41.size
				v_u_5.facePic(p42, 1 * v43, 5 * v43, v_u_8.DSealCross, v_u_9, 0.32, nil, 0.2, 0)
				v_u_4.flash(p42, v_u_9, 3.4 * v43, 0.13)
				if not p41.lite then
					v_u_5.facePic(p42, 2 * v43, 7 * v43, v_u_8.DSealDial, v_u_10, 0.28, nil, 0.1)
					local v44 = 0.5 * v43
					local v45 = 9 * v43
					local v46 = {
						["layout"] = nil,
						["color2"] = nil,
						["emission"] = 0.4,
						["layout"] = v_u_16,
						["color2"] = v_u_10
					}
					v_u_5.spray(p42, v_u_8.FxTwinkle, 3, v44, v45, 0.6, v_u_9, v46)
				end
			end,
			["hit"] = p_u_24.simpleHit(v_u_9, 0.55)
		}
	}
	local v_u_48 = {}
	setmetatable(v_u_48, {
		["__mode"] = "k"
	})
	local function v_u_98(p_u_49, p50, p51, p52) -- name: lock
		-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_23, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_15, (copy) p_u_24, (ref) v_u_4, (ref) v_u_16, (ref) v_u_13
		local v_u_53 = p_u_49.ability.freeze or 3
		local v54 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_55
		if v54 then
			v_u_55 = v54:FindFirstChild("Foe" .. p51)
		else
			v_u_55 = nil
		end
		local v_u_56
		if v_u_55 and v_u_55:IsA("Model") then
			local _, v57 = v_u_55:GetBoundingBox()
			local v58 = v57.Y
			v_u_56 = math.clamp(v58, 4, 14)
		else
			v_u_56 = 6
		end
		local v_u_59 = p50 + Vector3.new(0, 0.2, 0)
		local v_u_60 = v_u_5.holder(CFrame.new(v_u_59), v_u_53 + 1)
		local v_u_61, v_u_62 = v_u_23(v_u_60, v_u_56 * 1.2, v_u_8.DSealDial, v_u_10)
		v_u_62.ImageTransparency = 0.1
		local v_u_63 = Instance.new("ImageLabel")
		v_u_63.BackgroundTransparency = 1
		v_u_63.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_63.Position = UDim2.fromScale(0.5, 0.5)
		v_u_63.Size = UDim2.fromScale(0.68, 0.68)
		v_u_63.Image = v_u_8.DSealCross
		v_u_63.ImageColor3 = v_u_9
		v_u_63.ZIndex = 2
		v_u_63.Parent = v_u_61
		local v64 = v_u_56 * 0.3
		v_u_61.StudsOffset = Vector3.new(0, 0, v64)
		local v_u_65 = {}
		if p52 then
			for v66 = 1, 4 do
				local v67 = v_u_5.blade
				local v68
				if v66 % 2 == 0 then
					v68 = v_u_10
				else
					v68 = v_u_9
				end
				local v69 = v_u_15
				table.insert(v_u_65, v67(v68, v69))
			end
		end
		local v_u_70 = os.clock()
		p_u_24.runNow(function()
			-- upvalues: (copy) v_u_70, (copy) v_u_55, (copy) v_u_53, (copy) v_u_65, (copy) v_u_60, (ref) v_u_5, (copy) v_u_59, (ref) v_u_56, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (copy) p_u_49, (ref) v_u_16, (ref) v_u_10, (copy) v_u_61, (copy) v_u_62, (copy) v_u_63, (ref) v_u_13, (ref) v_u_3
			local v71 = os.clock() - v_u_70
			local v72
			if v_u_55 == nil then
				v72 = false
			else
				v72 = v_u_55.Parent == nil
			end
			if v_u_53 <= v71 or v72 then
				for _, v73 in v_u_65 do
					for _, v74 in v73 do
						v74:Destroy()
					end
				end
				v_u_60:Destroy()
				v_u_5.facePic(v_u_59, v_u_56 * 0.6, v_u_56 * 1.6, v_u_8.DSealCross, v_u_9, 0.35, nil, 0.25, 0)
				v_u_4.flash(v_u_59, v_u_9, v_u_56 * 0.9, 0.2)
				if not p_u_49.lite then
					local v75 = v_u_59
					local v76 = {
						["layout"] = nil,
						["color2"] = nil,
						["emission"] = 0.4,
						["layout"] = v_u_16,
						["color2"] = v_u_10
					}
					v_u_5.spray(v75, v_u_8.FxTwinkle, 8, 0.7, 14, 0.6, v_u_9, v76)
				end
				return false
			end
			local v77 = v_u_5.outBack(v71 / 0.25)
			v_u_61.Size = UDim2.fromScale(v_u_56 * 1.2 * v77, v_u_56 * 1.2 * v77)
			local v78 = v_u_62
			local v79 = v71 / 0.5
			local v80 = math.floor(v79)
			local v81 = 0.5235987755982988 * (v80 + v_u_5.outBack((v71 - v80 * 0.5) / 0.12))
			v78.Rotation = math.deg(v81)
			local v82 = v_u_63
			local v83 = v71 / 1
			local v84 = math.floor(v83)
			local v85 = 0.2617993877991494 * (v84 + v_u_5.outBack((v71 - v84 * 1) / 0.12))
			v82.Rotation = -math.deg(v85)
			local v86 = 1 - v71 % 0.5 / 0.15
			v_u_63.ImageColor3 = v_u_9:Lerp(v_u_13, math.max(v86, 0) * 0.6)
			local v87 = v_u_3.CurrentCamera
			if v87 and #v_u_65 > 0 then
				local v88 = v87.CFrame
				local v89 = v_u_56 * (1.6 - 0.85 * v_u_5.outBack(v71 / 0.3))
				local v90 = v71 / 0.5
				local v91 = math.floor(v90)
				local v92 = 0.5235987755982988 * (v91 + v_u_5.outBack((v71 - v91 * 0.5) / 0.12))
				for v93, v94 in v_u_65 do
					local v95 = v92 + v93 * 3.141592653589793 / 2
					local v96 = v88.RightVector * math.cos(v95) + v88.UpVector * math.sin(v95)
					local v97 = v_u_59 + v96 * v89 + v88.LookVector * -v_u_56 * 0.2
					v_u_5.placeBlade(v94, CFrame.lookAt(v97, v_u_59, v88.LookVector:Cross(v96)), v_u_56 * 0.42, v_u_56 * 0.16, 0.12)
				end
			end
			return true
		end)
		p_u_24.burst("Impact", p50, v_u_9, 0.6)
	end
	v47.demon_seal_e = {
		["cast"] = function(p99) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_24, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8
			local v100 = p99.size
			v_u_4.flash(p99.eye, v_u_9, 4 * v100, 0.16)
			p_u_24.glint(p99.eye, v_u_10, 4 * v100, 0.2)
			v_u_5.groundPic(p99.feet + Vector3.new(0, 0.1, 0), 2 * v100, 7 * v100, v_u_8.DSealDial, v_u_9, 0, 0.12, 0, 0.3, 2)
			if p99.mine then
				v_u_4.shake(0.08, 0.12)
			end
		end,
		["windup"] = function(p101, p102, p103) -- name: windup
			-- upvalues: (copy) p_u_24, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9
			local v104 = p101.size
			local v105 = math.max(p103, 0.1)
			p_u_24.inward(p_u_24.ground(p102, 2), v_u_10, p101.lite and 4 or 10, 10 * v104, v105 + 0.05)
			v_u_4.flash(p_u_24.ground(p102, 2), v_u_9, 5 * v104, v105)
		end,
		["land"] = function(p_u_106, p107) -- name: land
			-- upvalues: (copy) p_u_24, (ref) v_u_5, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9, (ref) v_u_1, (ref) v_u_10, (ref) v_u_15, (ref) v_u_13, (ref) v_u_4, (ref) v_u_7
			local v108 = p_u_106.size
			local v_u_109 = p_u_106.ability.radius * v108
			local v_u_110 = p_u_106.ability.freeze or 3
			local v_u_111 = p_u_24.ground(p107, 0.1)
			v_u_5.groundPic(v_u_111 - Vector3.new(0, 0.04, 0), v_u_109 * 0.8, v_u_109 * 2.5, v_u_8.Glow, v_u_11, 0.35, 0.3, v_u_110 - 0.3, 0.5, 0)
			v_u_5.groundPic(v_u_111 + Vector3.new(0, 0.06, 0), v_u_109 * 0.4, v_u_109 * 1.1, v_u_8.DSealCross, v_u_9, 0.25, 0.3, v_u_110 - 0.3, 0.4, 0)
			local v_u_112, v_u_113 = v_u_5.card(v_u_109 * 2.2, v_u_8.DSealDial, v_u_9, 0, 1.7)
			v_u_112.CFrame = CFrame.new(v_u_111)
			v_u_1:AddItem(v_u_112, v_u_110 + 1)
			local v_u_114 = v_u_5.blade(v_u_10, v_u_15)
			local v_u_115 = v_u_5.blade(v_u_9, v_u_15)
			for _, v116 in { v_u_114, v_u_115 } do
				for _, v117 in v116 do
					v_u_1:AddItem(v117, v_u_110 + 1)
				end
			end
			local v_u_118 = v_u_5.flat(p107 - p_u_106.origin)
			local v_u_119 = os.clock()
			p_u_24.runNow(function()
				-- upvalues: (copy) v_u_119, (copy) v_u_110, (copy) v_u_112, (copy) v_u_114, (copy) v_u_115, (ref) v_u_5, (copy) v_u_109, (copy) v_u_111, (copy) v_u_118, (copy) v_u_113, (ref) v_u_9, (ref) v_u_13
				local v120 = os.clock() - v_u_119
				if v_u_110 <= v120 or not v_u_112.Parent then
					v_u_112:Destroy()
					for _, v121 in { v_u_114, v_u_115 } do
						for _, v122 in v121 do
							v122:Destroy()
						end
					end
					return false
				end
				local v123 = v_u_5.outBack(v120 / 0.3)
				local v124 = v_u_109 * 2.2 * v123
				local v125 = math.max(v124, 0.1)
				v_u_112.Size = Vector3.new(v125, 0.05, v125)
				local v126 = v_u_112
				local v127 = CFrame.new(v_u_111)
				local v128 = CFrame.Angles
				local v129 = v120 / 0.5
				local v130 = math.floor(v129)
				v126.CFrame = v127 * v128(0, -(0.2617993877991494 * (v130 + v_u_5.outBack((v120 - v130 * 0.5) / 0.12))), 0)
				local v131 = v_u_110 / 12
				local v132 = v120 / v131
				local v133 = math.floor(v132)
				local v134 = 0.5235987755982988 * (v133 + v_u_5.outBack((v120 - v133 * v131) / 0.12))
				local v135 = CFrame.fromAxisAngle(Vector3.new(0, 1, 0), -v134):VectorToWorldSpace(v_u_118)
				local v136 = CFrame.lookAt(v_u_111 + Vector3.new(0, 0.1, 0), v_u_111 + Vector3.new(0, 0.1, 0) + v135) * CFrame.Angles(0, 0, 1.5707963267948966)
				v_u_5.placeBlade(v_u_114, v136, v_u_109 * 0.95 * v123, v_u_109 * 0.12, 0.12)
				v_u_5.placeBlade(v_u_115, v136 * CFrame.new(0, 0, -v_u_109 * 0.7 * v123), v_u_109 * 0.32, v_u_109 * 0.2, 0.14)
				local v137 = 1 - v120 % (v_u_110 / 12) / 0.15
				local v138 = math.max(v137, 0)
				for _, v139 in v_u_113 do
					v139.ImageColor3 = v_u_9:Lerp(v_u_13, v138 * 0.35)
				end
				return true
			end)
			v_u_4.ring(v_u_111, v_u_9, v_u_109 * 1.1, 0.5, v_u_8.Ring)
			v_u_7.play("Bind", {
				["at"] = v_u_111,
				["volume"] = p_u_106.mine and 0.8 or 0.45
			})
			if p_u_106.mine then
				v_u_4.shake(0.2, 0.2)
			end
			p_u_24.after(v_u_110, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_111, (copy) v_u_109, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (copy) p_u_106
				v_u_5.groundPic(v_u_111 + Vector3.new(0, 0.1, 0), v_u_109 * 1, v_u_109 * 2.8, v_u_8.DSealDial, v_u_9, 0, 0.25, 0, 0.35, 1.5, 0.2)
				v_u_4.ring(v_u_111, v_u_10, v_u_109 * 1.3, 0.55, v_u_8.Shockwave)
				v_u_7.play("Crit", {
					["at"] = v_u_111,
					["volume"] = p_u_106.mine and 0.6 or 0.35
				})
			end)
		end,
		["hit"] = function(p140, p141, p142) -- name: hit
			-- upvalues: (copy) v_u_48, (copy) p_u_24, (ref) v_u_9, (copy) v_u_98
			local v143 = (v_u_48[p140] or 0) + 1
			v_u_48[p140] = v143
			if (p140.lite and 3 or 6) < v143 then
				p_u_24.burst("Impact", p141, v_u_9, 0.6)
			else
				local v144 = v_u_98
				local v145 = not p140.lite
				if v145 then
					v145 = v143 <= 4
				end
				v144(p140, p141, p142, v145)
			end
		end
	}
	local v_u_146 = {}
	setmetatable(v_u_146, {
		["__mode"] = "k"
	})
	v47.demon_seal_r = {
		["cast"] = function(p147) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_24, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_16
			local v148 = p147.size
			v_u_4.flash(p147.eye, v_u_9, 6 * v148, 0.2)
			p_u_24.glint(p147.eye, v_u_10, 5 * v148, 0.25)
			local v149 = p147.eye
			local v150 = p147.lite and 2 or 6
			local v151 = 0.6 * v148
			local v152 = 10 * v148
			local v153 = {
				["layout"] = nil,
				["color2"] = nil,
				["emission"] = 0.4,
				["layout"] = v_u_16,
				["color2"] = v_u_10
			}
			v_u_5.spray(v149, v_u_8.FxTwinkle, v150, v151, v152, 0.6, v_u_9, v153)
			if p147.mine then
				v_u_4.shake(0.12, 0.15)
				v_u_5.tint("DemonSeal", Color3.fromRGB(255, 222, 232), -0.04, 0.12, 0.12, 0.7, 0.5)
			end
		end,
		["windup"] = function(p154, p155, p156) -- name: windup
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (ref) v_u_1, (copy) v_u_146, (copy) p_u_24, (ref) v_u_4, (ref) v_u_7
			local v_u_157 = p154.size
			local v_u_158 = math.max(p156, 0.12)
			local v_u_159 = v_u_158 + 1.4
			local v160 = p154.dir
			local v_u_161 = CFrame.lookAt(p155 - v160 * 1.2 * v_u_157, p155 + v160)
			local v162 = p154.mine and 0.4 or 0
			local v_u_163 = 11 * v_u_157
			local v_u_164, v_u_165 = v_u_5.standingCard(v_u_163, v_u_163, v_u_8.DSealDial, v_u_10, v162, 1.6)
			local v_u_166
			if p154.lite then
				v_u_166 = nil
			else
				v_u_166 = v_u_5.piece("w8_demon_seal", 5.5 * v_u_157, 6)
			end
			local v_u_167 = {}
			for _, v168 in v_u_165 do
				local v169 = Instance.new("ImageLabel")
				v169.BackgroundTransparency = 1
				v169.AnchorPoint = Vector2.new(0.5, 0.5)
				v169.Position = UDim2.fromScale(0.5, 0.5)
				v169.Size = UDim2.fromScale(0.55, 0.55)
				v169.Image = v_u_8.DSealCross
				v169.ImageColor3 = v_u_9
				v169.ImageTransparency = math.max(v162, v_u_166 and 0.3 or 0)
				v169.ZIndex = 2
				v169.Parent = v168.Parent
				table.insert(v_u_167, v169)
			end
			local v170 = {}
			local v171 = { v_u_164 }
			for _, v172 in v_u_165 do
				table.insert(v170, v172)
			end
			for _, v173 in v_u_167 do
				table.insert(v170, v173)
			end
			if v_u_166 then
				v_u_166.Transparency = p154.mine and 0.35 or 0
				table.insert(v171, v_u_166)
			end
			for _, v174 in v171 do
				v_u_1:AddItem(v174, v_u_159)
			end
			v_u_146[p154] = {
				["parts"] = v171,
				["labels"] = v170,
				["at"] = v_u_161,
				["born"] = os.clock()
			}
			local v_u_175 = os.clock()
			p_u_24.runNow(function()
				-- upvalues: (copy) v_u_175, (copy) v_u_159, (copy) v_u_164, (ref) v_u_5, (copy) v_u_158, (copy) v_u_163, (copy) v_u_161, (copy) v_u_157, (copy) v_u_165, (copy) v_u_167, (copy) v_u_166
				local v176 = os.clock() - v_u_175
				if v_u_159 <= v176 or not v_u_164.Parent then
					return false
				end
				local v177 = v_u_5.outBack(v176 / 0.18)
				local v178 = v_u_158 / 3
				local v179 = v176 / v178
				local v180 = math.floor(v179)
				local v181 = 0.5235987755982988 * (v180 + v_u_5.outBack((v176 - v180 * v178) / 0.12))
				local v182 = math.min(v181, 1.5707963267948966)
				local v183 = v_u_158 + 0.75 >= v176 and 0 or v_u_5.smooth((v176 - v_u_158 - 0.75) / 0.4) * 3.141592653589793 * 2
				local v184 = 1.5707963267948966 - v182 + v183
				local v185 = v_u_163 * v177
				v_u_164.Size = Vector3.new(v185, v185, 0.05)
				v_u_164.CFrame = v_u_161 * CFrame.new(0, 0, 0.3 * v_u_157)
				for _, v186 in v_u_165 do
					v186.Rotation = math.deg(v184)
				end
				for _, v187 in v_u_167 do
					v187.Rotation = -math.deg(v183)
				end
				if v_u_166 then
					v_u_166.CFrame = v_u_161 * CFrame.Angles(0, 0, v184) * CFrame.new(0, 0, 0.05 * v_u_157)
				end
				return true
			end)
			v_u_4.flash(p155, v_u_9, 8 * v_u_157, v_u_158 + 0.1)
			p_u_24.inward(p155, v_u_10, p154.lite and 4 or 12, 9 * v_u_157, v_u_158)
			v_u_7.play("EyeActivate", {
				["at"] = p155,
				["volume"] = p154.mine and 0.6 or 0.3
			})
		end,
		["beam"] = function(p_u_188, p189, p_u_190) -- name: beam
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_15, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (copy) p_u_24, (ref) v_u_8, (ref) v_u_14, (ref) v_u_12, (ref) v_u_11, (ref) v_u_4, (ref) v_u_16, (ref) v_u_7, (copy) v_u_146
			local v_u_191 = p_u_188.size
			local v_u_192 = p_u_188.lite
			local v193 = p_u_190 - p189
			local v_u_194 = v193.Magnitude
			if v_u_194 >= 2 then
				local v_u_195 = v193.Unit
				local v_u_196 = v_u_5.flat(v_u_195):Cross(Vector3.new(0, 1, 0))
				local v_u_197 = CFrame.lookAt(p189, p_u_190) * CFrame.Angles(0, 0, 1.5707963267948966)
				local v_u_198 = v_u_5.blade(v_u_9, v_u_15)
				local v_u_199 = v_u_5.blade(v_u_10, Enum.Material.Glass, 0.45)
				local v_u_200 = v_u_5.blade(v_u_13, v_u_15)
				local v_u_201 = { v_u_198, v_u_199, v_u_200 }
				for _, v202 in v_u_201 do
					for _, v203 in v202 do
						v_u_1:AddItem(v203, 1.4)
					end
				end
				p_u_24.animate(0.78, p_u_188.skip, function(p204)
					-- upvalues: (ref) v_u_5, (copy) v_u_194, (copy) v_u_199, (copy) v_u_197, (copy) v_u_191, (copy) v_u_198, (copy) v_u_200, (copy) v_u_201
					local v205 = p204 * 0.78
					local v206 = v_u_5.outBack(v205 / 0.1)
					local v207 = math.max(v206, 0.02) * v_u_194
					local v208 = 1 - v_u_5.smooth((v205 - 0.1 - 0.38) / 0.3)
					v_u_5.placeBlade(v_u_199, v_u_197, v207, 5.2 * v_u_191 * v208 + 0.05, 0.6 * v_u_191)
					v_u_5.placeBlade(v_u_198, v_u_197, v207 * 0.98, 3 * v_u_191 * v208 + 0.05, 0.9 * v_u_191)
					v_u_5.placeBlade(v_u_200, v_u_197, v207 * 0.95, 0.9 * v_u_191 * v208 + 0.05, 1.1 * v_u_191)
					if p204 >= 1 then
						for _, v209 in v_u_201 do
							for _, v210 in v209 do
								v210:Destroy()
							end
						end
					end
				end)
				local v211 = v_u_194 / (v_u_192 and 22 or 11)
				local v212 = math.floor(v211)
				local v213 = math.max(v212, 1)
				for v_u_214 = 1, v213 do
					local v215 = v_u_214 / (v213 + 0.5)
					local v_u_216 = p189:Lerp(p_u_190, v215)
					p_u_24.after(v215 * 0.1, function()
						-- upvalues: (copy) v_u_214, (copy) v_u_192, (ref) v_u_5, (copy) v_u_216, (ref) v_u_195, (copy) v_u_191, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) p_u_24, (copy) v_u_196, (ref) v_u_14, (ref) v_u_12
						if v_u_214 % 2 == 1 or not v_u_192 then
							local v217 = v_u_5.planePic
							local v218 = v_u_5.facing(v_u_216, v_u_195)
							local v219 = 3 * v_u_191
							local v220 = (v_u_214 % 2 == 0 and 9 or 11) * v_u_191
							local v221 = v_u_8.DSealDial
							local v222
							if v_u_214 % 2 == 0 then
								v222 = v_u_9
							else
								v222 = v_u_10
							end
							v217(v218, v219, v220, v221, v222, 0, 0.12, 0.2, 0.35, v_u_214 % 2 == 0 and 3 or -3, 0.15)
						end
						v_u_5.groundPic(p_u_24.ground(v_u_216, 0.12), 2 * v_u_191, 7 * v_u_191, v_u_8.DSealCross, v_u_9, 0, 0.12, 0.35, 0.4, 0)
						if not v_u_192 and v_u_214 % 2 == 0 then
							local v223 = { v_u_14, v_u_12, v_u_10 }
							p_u_24.chunks(p_u_24.ground(v_u_216, 0.4) + v_u_196 * 2 * v_u_191, v223, 2, 14 * v_u_191, 0.5 * v_u_191, 0.8, false, 0.7)
							local v224 = { v_u_14, v_u_12, v_u_10 }
							p_u_24.chunks(p_u_24.ground(v_u_216, 0.4) - v_u_196 * 2 * v_u_191, v224, 2, 14 * v_u_191, 0.5 * v_u_191, 0.8, false, 0.7)
						end
					end)
				end
				p_u_24.groundLine(p189, p_u_190, 2.6 * v_u_191, v_u_11, 1.1, 0.1)
				p_u_24.after(0.1, function()
					-- upvalues: (ref) v_u_5, (copy) p_u_190, (copy) v_u_191, (ref) v_u_8, (ref) v_u_9, (ref) p_u_24, (ref) v_u_4, (ref) v_u_10, (copy) v_u_192, (ref) v_u_16, (ref) v_u_14, (ref) v_u_12, (ref) v_u_7, (copy) p_u_188
					v_u_5.facePic(p_u_190, 4 * v_u_191, 16 * v_u_191, v_u_8.DSealCross, v_u_9, 0.45, nil, 0.25, 0)
					v_u_5.groundPic(p_u_24.ground(p_u_190, 0.15), 4 * v_u_191, 18 * v_u_191, v_u_8.DSealDial, v_u_9, 0, 0.2, 0.2, 0.5, 2, 0.2)
					v_u_4.flash(p_u_190, v_u_9, 10 * v_u_191, 0.25)
					v_u_4.ring(p_u_24.ground(p_u_190, 0), v_u_10, 9 * v_u_191, 0.45, v_u_8.Shockwave)
					if not v_u_192 then
						local v225 = p_u_190
						local v226 = 0.9 * v_u_191
						local v227 = 22 * v_u_191
						local v228 = {
							["layout"] = nil,
							["color2"] = nil,
							["emission"] = 0.4,
							["layout"] = v_u_16,
							["color2"] = v_u_10
						}
						v_u_5.spray(v225, v_u_8.FxTwinkle, 14, v226, v227, 0.6, v_u_9, v228)
						local v229 = { v_u_14, v_u_12, v_u_9 }
						p_u_24.chunks(p_u_24.ground(p_u_190, 0.5), v229, 8, 26 * v_u_191, 0.8 * v_u_191, 1.1, false, 0.9)
					end
					v_u_7.play("Explosion", {
						["at"] = p_u_190,
						["volume"] = p_u_188.mine and 0.8 or 0.4
					})
				end)
				local v_u_230 = v_u_146[p_u_188]
				v_u_146[p_u_188] = nil
				if v_u_230 then
					p_u_24.after(0.75, function()
						-- upvalues: (copy) v_u_230, (ref) v_u_4
						for _, v231 in v_u_230.labels do
							v_u_4.tween(v231, 0.45, {
								["ImageTransparency"] = 1
							})
						end
						for _, v232 in v_u_230.parts do
							if not v232:IsA("MeshPart") then
								continue
							end
							v_u_4.tween(v232, 0.45, {
								["Transparency"] = 1
							})
						end
					end)
					p_u_24.after(1.15, function()
						-- upvalues: (copy) v_u_230, (copy) v_u_192, (copy) v_u_191, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_16, (ref) v_u_10, (ref) v_u_4
						local v233 = v_u_230.at.Position
						local v234 = v_u_192 and 4 or 18
						local v235 = 1 * v_u_191
						local v236 = 18 * v_u_191
						local v237 = {
							["layout"] = nil,
							["color2"] = nil,
							["emission"] = 0.4,
							["layout"] = v_u_16,
							["color2"] = v_u_10
						}
						v_u_5.spray(v233, v_u_8.FxTwinkle, v234, v235, v236, 0.6, v_u_9, v237)
						v_u_4.flash(v233, v_u_9, 9 * v_u_191, 0.2)
					end)
				end
				if p_u_188.mine then
					v_u_4.shake(0.45, 0.4)
				end
			end
		end,
		["hit"] = function(p238, p239, _) -- name: hit
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (copy) p_u_24
			v_u_5.facePic(p239, 1 * p238.size, 3.6 * p238.size, v_u_8.DSealCross, v_u_9, 0.25, nil, 0.2, 0)
			p_u_24.burst("Impact", p239, v_u_9, 0.7)
		end
	}
	return v47
end