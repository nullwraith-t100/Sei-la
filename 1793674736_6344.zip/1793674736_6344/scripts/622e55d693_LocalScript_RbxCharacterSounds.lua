local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("SoundService")
local v4 = require(script:WaitForChild("AtomicBinding"))
local v_u_5 = "UserSoundsUseRelativeVelocity2"
local v6, v7 = pcall(function()
	-- upvalues: (copy) v_u_5
	return UserSettings():IsUserFeatureEnabled(v_u_5)
end)
local v_u_8 = v6 and v7
local v_u_9 = "UserNewCharacterSoundsApi3"
local v10, v11 = pcall(function()
	-- upvalues: (copy) v_u_9
	return UserSettings():IsUserFeatureEnabled(v_u_9)
end)
local v_u_12 = v10 and v11
local v_u_13 = "UserFixCharSoundsEmitters"
local v14, v15 = pcall(function()
	-- upvalues: (copy) v_u_13
	return UserSettings():IsUserFeatureEnabled(v_u_13)
end)
local v_u_16 = v14 and v15
local v_u_17 = "UserFixCharSoundsEmitterRootPart"
local v18, v19 = pcall(function()
	-- upvalues: (copy) v_u_17
	return UserSettings():IsUserFeatureEnabled(v_u_17)
end)
local v_u_20 = v18 and v19
local v_u_21 = {
	["Climbing"] = {
		["SoundId"] = "rbxasset://sounds/action_footsteps_plastic.mp3",
		["Looped"] = true
	},
	["Died"] = {
		["SoundId"] = "rbxasset://sounds/uuhhh.mp3"
	},
	["FreeFalling"] = {
		["SoundId"] = "rbxasset://sounds/action_falling.ogg",
		["Looped"] = true
	},
	["GettingUp"] = {
		["SoundId"] = "rbxasset://sounds/action_get_up.mp3"
	},
	["Jumping"] = {
		["SoundId"] = "rbxasset://sounds/action_jump.mp3"
	},
	["Landing"] = {
		["SoundId"] = "rbxasset://sounds/action_jump_land.mp3"
	},
	["Running"] = {
		["SoundId"] = "rbxasset://sounds/action_footsteps_plastic.mp3",
		["Looped"] = true,
		["Pitch"] = 1.85
	},
	["Splash"] = {
		["SoundId"] = "rbxasset://sounds/impact_water.mp3"
	},
	["Swimming"] = {
		["SoundId"] = "rbxasset://sounds/action_swim.mp3",
		["Looped"] = true,
		["Pitch"] = 1.6
	}
}
local v_u_22 = {
	["Climbing"] = {
		["AssetId"] = "rbxasset://sounds/action_footsteps_plastic.mp3",
		["Looping"] = true
	},
	["Died"] = {
		["AssetId"] = "rbxasset://sounds/uuhhh.mp3"
	},
	["FreeFalling"] = {
		["AssetId"] = "rbxasset://sounds/action_falling.ogg",
		["Looping"] = true
	},
	["GettingUp"] = {
		["AssetId"] = "rbxasset://sounds/action_get_up.mp3"
	},
	["Jumping"] = {
		["AssetId"] = "rbxasset://sounds/action_jump.mp3"
	},
	["Landing"] = {
		["AssetId"] = "rbxasset://sounds/action_jump_land.mp3"
	},
	["Running"] = {
		["AssetId"] = "rbxasset://sounds/action_footsteps_plastic.mp3",
		["Looping"] = true,
		["PlaybackSpeed"] = 1.85
	},
	["Splash"] = {
		["AssetId"] = "rbxasset://sounds/impact_water.mp3"
	},
	["Swimming"] = {
		["AssetId"] = "rbxasset://sounds/action_swim.mp3",
		["Looping"] = true,
		["PlaybackSpeed"] = 1.6
	}
}
local function v_u_26(p23, p24) -- name: getRelativeVelocity
	if p23 then
		local v25 = p23.ActiveController and (not (p23.ActiveController:IsA("GroundController") and p23.GroundSensor) and p23.ActiveController:IsA("ClimbController"))
		if v25 then
			v25 = p23.ClimbSensor
		end
		if v25 and v25.SensedPart then
			return p24 - v25.SensedPart:GetVelocityAtPosition(p23.RootPart.Position)
		else
			return p24
		end
	else
		return p24
	end
end
local v_u_103 = v4.new({
	["humanoid"] = "Humanoid",
	["rootPart"] = "HumanoidRootPart"
}, function(p27) -- name: initializeSoundSystem
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_3, (copy) v_u_16, (copy) v_u_20, (copy) v_u_1, (copy) v_u_22, (copy) v_u_21, (copy) v_u_26, (copy) v_u_2
	local v_u_28 = p27.humanoid
	local v_u_29 = p27.rootPart
	local v_u_30 = nil
	local v_u_31
	if v_u_8 then
		v_u_31 = v_u_28.Parent:FindFirstChild("ControllerManager")
	else
		v_u_31 = nil
	end
	local v_u_32 = {}
	if v_u_12 and v_u_3.CharacterSoundsUseNewApi == Enum.RolloutState.Enabled then
		local v33 = nil
		local v34 = nil
		if v_u_16 then
			if v_u_20 then
				v34 = v_u_28.RootPart or v_u_28.Parent
			else
				v34 = v_u_28.RootPart
			end
		else
			v33 = v_u_1.LocalPlayer.Character
		end
		local v35 = 5
		local v36 = {}
		while v35 < 150 do
			v36[v35] = 5 / v35
			v35 = v35 * 1.25
		end
		v36[150] = 0
		if v_u_16 then
			v_u_30 = Instance.new("AudioEmitter", v34)
		else
			v_u_30 = Instance.new("AudioEmitter", v33)
		end
		v_u_30.Name = "RbxCharacterSoundsEmitter"
		v_u_30:SetDistanceAttenuation(v36)
		for v37, v38 in pairs(v_u_22) do
			local v39 = Instance.new("AudioPlayer")
			local v40 = Instance.new("Wire")
			v39.Name = v37
			v40.Name = v37 .. "Wire"
			v39.Archivable = false
			v39.Volume = 0.65
			for v41, v42 in pairs(v38) do
				v39[v41] = v42
			end
			v39.Parent = v_u_29
			v40.Parent = v39
			v40.SourceInstance = v39
			v40.TargetInstance = v_u_30
			v_u_32[v37] = v39
		end
	else
		for v43, v44 in pairs(v_u_21) do
			local v45 = Instance.new("Sound")
			v45.Name = v43
			v45.Archivable = false
			v45.RollOffMinDistance = 5
			v45.RollOffMaxDistance = 150
			v45.Volume = 0.65
			for v46, v47 in pairs(v44) do
				v45[v46] = v47
			end
			v45.Parent = v_u_29
			v_u_32[v43] = v45
		end
	end
	local v_u_48 = {}
	local function v_u_57(p49) -- name: stopPlayingLoopedSounds
		-- upvalues: (copy) v_u_48, (ref) v_u_12
		local v50 = pairs
		local v51 = v_u_48
		local v52 = {}
		local v53 = p49 or nil
		for v54, v55 in pairs(v51) do
			v52[v54] = v55
		end
		for v56 in v50(v52) do
			if v56 == v53 then
				continue
			end
			if v_u_12 and v56:IsA("AudioPlayer") then
				v56:Stop()
			else
				v56.Playing = false
			end
			v_u_48[v56] = nil
		end
	end
	local v_u_78 = {
		[Enum.HumanoidStateType.FallingDown] = function()
			-- upvalues: (copy) v_u_57
			v_u_57()
		end,
		[Enum.HumanoidStateType.GettingUp] = function()
			-- upvalues: (copy) v_u_57, (copy) v_u_32, (ref) v_u_12
			v_u_57()
			local v58 = v_u_32.GettingUp
			v58.TimePosition = 0
			if v_u_12 and v58:IsA("AudioPlayer") then
				v58:Play()
			else
				v58.Playing = true
			end
		end,
		[Enum.HumanoidStateType.Jumping] = function()
			-- upvalues: (copy) v_u_57, (copy) v_u_32, (ref) v_u_12
			v_u_57()
			local v59 = v_u_32.Jumping
			v59.TimePosition = 0
			if v_u_12 and v59:IsA("AudioPlayer") then
				v59:Play()
			else
				v59.Playing = true
			end
		end,
		[Enum.HumanoidStateType.Swimming] = function()
			-- upvalues: (copy) v_u_29, (copy) v_u_32, (ref) v_u_12, (copy) v_u_57, (copy) v_u_48
			local v60 = v_u_29.AssemblyLinearVelocity.Y
			local v61 = math.abs(v60)
			if v61 > 0.1 then
				local v62 = v_u_32.Splash
				local v63 = (v61 - 100) * 0.72 / 250 + 0.28
				v62.Volume = math.clamp(v63, 0, 1)
				local v64 = v_u_32.Splash
				v64.TimePosition = 0
				if v_u_12 and v64:IsA("AudioPlayer") then
					v64:Play()
				else
					v64.Playing = true
				end
			end
			v_u_57(v_u_32.Swimming)
			local v65 = v_u_32.Swimming
			if v_u_12 and v65:IsA("AudioPlayer") then
				v65:Play()
			else
				v65.Playing = true
			end
			v_u_48[v_u_32.Swimming] = true
		end,
		[Enum.HumanoidStateType.Freefall] = function()
			-- upvalues: (copy) v_u_32, (copy) v_u_57, (ref) v_u_12, (copy) v_u_48
			v_u_32.FreeFalling.Volume = 0
			v_u_57(v_u_32.FreeFalling)
			local v66 = v_u_32.FreeFalling
			if v_u_12 and v66:IsA("AudioPlayer") then
				v66.Looping = true
			else
				v66.Looped = true
			end
			if v_u_32.FreeFalling:IsA("Sound") then
				v_u_32.FreeFalling.PlaybackRegionsEnabled = true
			end
			v_u_32.FreeFalling.LoopRegion = NumberRange.new(2, 9)
			local v67 = v_u_32.FreeFalling
			v67.TimePosition = 0
			if v_u_12 and v67:IsA("AudioPlayer") then
				v67:Play()
			else
				v67.Playing = true
			end
			v_u_48[v_u_32.FreeFalling] = true
		end,
		[Enum.HumanoidStateType.Landed] = function()
			-- upvalues: (copy) v_u_57, (copy) v_u_29, (copy) v_u_32, (ref) v_u_12
			v_u_57()
			local v68 = v_u_29.AssemblyLinearVelocity.Y
			local v69 = math.abs(v68)
			if v69 > 75 then
				local v70 = v_u_32.Landing
				local v71 = (v69 - 50) * 1 / 50 + 0
				v70.Volume = math.clamp(v71, 0, 1)
				local v72 = v_u_32.Landing
				v72.TimePosition = 0
				if v_u_12 and v72:IsA("AudioPlayer") then
					v72:Play()
					return
				end
				v72.Playing = true
			end
		end,
		[Enum.HumanoidStateType.Running] = function()
			-- upvalues: (copy) v_u_57, (copy) v_u_32, (ref) v_u_12, (copy) v_u_48
			v_u_57(v_u_32.Running)
			local v73 = v_u_32.Running
			if v_u_12 and v73:IsA("AudioPlayer") then
				v73:Play()
			else
				v73.Playing = true
			end
			v_u_48[v_u_32.Running] = true
		end,
		[Enum.HumanoidStateType.Climbing] = function()
			-- upvalues: (copy) v_u_32, (copy) v_u_29, (ref) v_u_8, (ref) v_u_26, (ref) v_u_31, (ref) v_u_12, (copy) v_u_57, (copy) v_u_48
			local v74 = v_u_32.Climbing
			local v75 = v_u_29.AssemblyLinearVelocity
			if v_u_8 then
				v75 = v_u_26(v_u_31, v75)
			end
			local v76 = v75.Y
			if math.abs(v76) > 0.1 then
				if v_u_12 and v74:IsA("AudioPlayer") then
					v74:Play()
				else
					v74.Playing = true
				end
				v_u_57(v74)
			else
				v_u_57()
			end
			v_u_48[v74] = true
		end,
		[Enum.HumanoidStateType.Seated] = function()
			-- upvalues: (copy) v_u_57
			v_u_57()
		end,
		[Enum.HumanoidStateType.Dead] = function()
			-- upvalues: (copy) v_u_57, (copy) v_u_32, (ref) v_u_12
			v_u_57()
			local v77 = v_u_32.Died
			v77.TimePosition = 0
			if v_u_12 and v77:IsA("AudioPlayer") then
				v77:Play()
			else
				v77.Playing = true
			end
		end
	}
	local v_u_89 = {
		[v_u_32.Climbing] = function(_, p79, p80)
			-- upvalues: (ref) v_u_8, (ref) v_u_26, (ref) v_u_31, (ref) v_u_12
			if v_u_8 then
				p80 = v_u_26(v_u_31, p80)
			end
			local v81 = p80.Magnitude > 0.1
			if v_u_12 and p79:IsA("AudioPlayer") then
				if p79.IsPlaying and not v81 then
					p79:Stop()
					return
				end
				if not p79.IsPlaying and v81 then
					p79:Play()
					return
				end
			else
				p79.Playing = v81
			end
		end,
		[v_u_32.FreeFalling] = function(p82, p83, p84)
			if p84.Magnitude > 75 then
				local v85 = p83.Volume + p82 * 0.9
				p83.Volume = math.clamp(v85, 0, 1)
			else
				p83.Volume = 0
			end
		end,
		[v_u_32.Running] = function(_, p86, p87)
			-- upvalues: (copy) v_u_28, (ref) v_u_12
			local v88
			if p87.Magnitude > 0.5 then
				v88 = v_u_28.MoveDirection.Magnitude > 0.5
			else
				v88 = false
			end
			if v_u_12 and p86:IsA("AudioPlayer") then
				if p86.IsPlaying and not v88 then
					p86:Stop()
					return
				end
				if not p86.IsPlaying and v88 then
					p86:Play()
					return
				end
			else
				p86.Playing = v88
			end
		end
	}
	local v_u_90 = {
		[Enum.HumanoidStateType.RunningNoPhysics] = Enum.HumanoidStateType.Running
	}
	local v_u_91 = v_u_90[v_u_28:GetState()] or v_u_28:GetState()
	local v92 = v_u_91
	local v93 = v_u_78[v92]
	if v93 then
		v93()
	end
	v_u_91 = v92
	local v_u_97 = v_u_28.StateChanged:Connect(function(_, p94)
		-- upvalues: (copy) v_u_90, (ref) v_u_91, (copy) v_u_78
		local v95 = v_u_90[p94] or p94
		if v95 ~= v_u_91 then
			local v96 = v_u_78[v95]
			if v96 then
				v96()
			end
			v_u_91 = v95
		end
	end)
	local v_u_101 = v_u_2.Stepped:Connect(function(_, p98)
		-- upvalues: (copy) v_u_48, (copy) v_u_89, (copy) v_u_29
		for v99 in pairs(v_u_48) do
			local v100 = v_u_89[v99]
			if not v100 then
				continue
			end
			v100(p98, v99, v_u_29.AssemblyLinearVelocity)
		end
	end)
	return function() -- name: terminate
		-- upvalues: (copy) v_u_97, (copy) v_u_101, (ref) v_u_20, (ref) v_u_30, (copy) v_u_32
		v_u_97:Disconnect()
		v_u_101:Disconnect()
		if v_u_20 and v_u_30 then
			v_u_30:Destroy()
		end
		for _, v102 in pairs(v_u_32) do
			v102:Destroy()
		end
		table.clear(v_u_32)
	end
end)
local v_u_104 = {}
local function v_u_106(p105) -- name: characterAdded
	-- upvalues: (copy) v_u_103
	v_u_103:bindRoot(p105)
end
local function v_u_108(p107) -- name: characterRemoving
	-- upvalues: (copy) v_u_103
	v_u_103:unbindRoot(p107)
end
local function v115(p109) -- name: playerAdded
	-- upvalues: (copy) v_u_104, (copy) v_u_103, (copy) v_u_106, (copy) v_u_108
	local v110 = v_u_104[p109]
	if not v110 then
		v110 = {}
		v_u_104[p109] = v110
	end
	if p109.Character then
		v_u_103:bindRoot(p109.Character)
	end
	local v111 = p109.CharacterAdded
	local v112 = v_u_106
	table.insert(v110, v111:Connect(v112))
	local v113 = p109.CharacterRemoving
	local v114 = v_u_108
	table.insert(v110, v113:Connect(v114))
end
local function v119(p116) -- name: playerRemoving
	-- upvalues: (copy) v_u_104, (copy) v_u_103
	local v117 = v_u_104[p116]
	if v117 then
		for _, v118 in ipairs(v117) do
			v118:Disconnect()
		end
		v_u_104[p116] = nil
	end
	if p116.Character then
		v_u_103:unbindRoot(p116.Character)
	end
end
for _, v120 in ipairs(v_u_1:GetPlayers()) do
	task.spawn(v115, v120)
end
v_u_1.PlayerAdded:Connect(v115)
v_u_1.PlayerRemoving:Connect(v119)