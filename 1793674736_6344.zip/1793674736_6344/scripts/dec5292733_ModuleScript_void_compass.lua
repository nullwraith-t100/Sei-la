local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("4FC8FF")
local v_u_9 = Color3.fromHex("7A3BE0")
local v_u_10 = Color3.fromRGB(8, 6, 20)
local v_u_11 = Color3.fromRGB(30, 60, 220)
local v_u_12 = Color3.fromRGB(205, 242, 255)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.PartType.Cylinder
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_18 = CFrame.Angles(0, 0, 1.5707963267948966)
local v_u_19 = CFrame.Angles(0, 1.5707963267948966, 0)
local v_u_20 = {
	Vector3.new(0, 0, -1),
	Vector3.new(1, 0, 0),
	Vector3.new(0, 0, 1),
	Vector3.new(-1, 0, 0)
}
local function v_u_32(p21, p22, p23, p24, p25) -- name: disc
	-- upvalues: (copy) v_u_5
	local v26 = v_u_5.part
	local v27 = p22 * 2
	local v28 = p22 * 2
	local v29 = v26(Vector3.new(v27, 0.05, v28), p21, p24, {
		["transparency"] = 1
	})
	for _, v30 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v31 = Instance.new("Decal")
		v31.Face = v30
		v31.Texture = p23
		v31.Color3 = p24
		v31.Transparency = p25
		v31.Parent = v29
	end
	return v29
end
local function v_u_36(p33, p34) -- name: fadeDecals
	for _, v35 in p33:GetChildren() do
		if not v35:IsA("Decal") then
			continue
		end
		v35.Transparency = p34
	end
end
local function v_u_43(p37, p38, p39, p40) -- name: egg
	-- upvalues: (copy) v_u_5
	local v41 = v_u_5.part(p37, CFrame.identity, p38, {
		["transparency"] = p39,
		["material"] = p40
	})
	local v42 = Instance.new("SpecialMesh")
	v42.MeshType = Enum.MeshType.Sphere
	v42.Parent = v41
	return v41
end
local function v_u_44() -- name: newBody
	return {
		["parts"] = nil,
		["offs"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["decals"] = nil,
		["dalphas"] = nil,
		["cfs"] = nil,
		["k"] = -1,
		["f"] = -1,
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {},
		["alphas"] = {},
		["decals"] = {},
		["dalphas"] = {},
		["cfs"] = {}
	}
end
local function v_u_61(p45, p46, p47, p48, p49, p50, p51) -- name: picturePiece
	-- upvalues: (copy) v_u_32, (copy) v_u_1
	local v52 = v_u_32(CFrame.identity, p46, p47, p48, 1)
	v52.Transparency = 1
	v_u_1:AddItem(v52, p51)
	local v53 = p45.parts
	table.insert(v53, v52)
	local v54 = p45.offs
	table.insert(v54, p50)
	local v55 = p45.sizes
	local v56 = v52.Size
	table.insert(v55, v56)
	local v57 = p45.alphas
	table.insert(v57, 1)
	for _, v58 in v52:GetChildren() do
		if not v58:IsA("Decal") then
			continue
		end
		local v59 = p45.decals
		table.insert(v59, v58)
		local v60 = p45.dalphas
		table.insert(v60, p49)
	end
	return v52
end
local function v_u_83(p62, p63, p64, p65) -- name: placeBody
	-- upvalues: (copy) v_u_4
	local v66 = math.max(p64, 0.02)
	local v67 = math.clamp(p65, 0, 1)
	local v68 = p62.parts
	local v69 = p62.offs
	local v70 = p62.cfs
	for v71 = 1, #v68 do
		local v72 = v69[v71]
		v70[v71] = p63 * (v72 - v72.Position + v72.Position * v66)
	end
	if #v68 > 0 then
		v_u_4:BulkMoveTo(v68, v70, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v73 = v66 - p62.k
	if math.abs(v73) > 0.0001 then
		p62.k = v66
		for v74, v75 in v68 do
			v75.Size = p62.sizes[v74] * v66
		end
	end
	local v76 = v67 - p62.f
	if math.abs(v76) > 0.001 then
		p62.f = v67
		for v77, v78 in v68 do
			local v79 = p62.alphas[v77]
			v78.Transparency = v79 + (1 - v79) * v67
		end
		for v80, v81 in p62.decals do
			local v82 = p62.dalphas[v80]
			v81.Transparency = v82 + (1 - v82) * v67
		end
	end
end
return function(p_u_84)
	-- upvalues: (copy) v_u_32, (copy) v_u_1, (copy) v_u_36, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_43, (copy) v_u_10, (copy) v_u_14, (copy) v_u_16, (copy) v_u_7, (copy) v_u_4, (copy) v_u_20, (copy) v_u_12, (copy) v_u_44, (copy) v_u_61, (copy) v_u_15, (copy) v_u_18, (copy) v_u_83, (copy) v_u_17, (copy) v_u_11, (copy) v_u_19, (copy) v_u_2, (copy) v_u_13, (copy) v_u_6
	local function v_u_101(p_u_85, p_u_86, p_u_87, p88, p89, p_u_90, p_u_91, p92) -- name: flare
		-- upvalues: (ref) v_u_32, (ref) v_u_1, (copy) p_u_84, (ref) v_u_36
		local v_u_93 = p92 or 0
		local v_u_94 = v_u_32(p_u_85, p_u_86, p88, p89, v_u_93)
		v_u_1:AddItem(v_u_94, p_u_90 + 0.1)
		p_u_84.animate(p_u_90, 0, function(p95)
			-- upvalues: (copy) p_u_86, (copy) p_u_87, (copy) v_u_94, (copy) p_u_85, (copy) p_u_90, (copy) p_u_91, (ref) v_u_36, (copy) v_u_93
			local v96 = 1 - (1 - p95) ^ 3
			local v97 = p_u_86 + (p_u_87 - p_u_86) * v96
			local v98 = v_u_94
			local v99 = v97 * 2
			local v100 = v97 * 2
			v98.Size = Vector3.new(v99, 0.05, v100)
			v_u_94.CFrame = p_u_85 * CFrame.Angles(0, p95 * p_u_90 * p_u_91, 0)
			v_u_36(v_u_94, v_u_93 + (1 - v_u_93) * p95 ^ 1.5)
			if p95 >= 1 then
				v_u_94:Destroy()
			end
		end)
	end
	local v_u_102 = CFrame.Angles(0.8726646259971648, 0, 0)
	local function v123(p103, p104) -- name: needleShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_84, (ref) v_u_9, (ref) v_u_43, (ref) v_u_10, (ref) v_u_14, (ref) v_u_16, (ref) v_u_32, (ref) v_u_7, (ref) v_u_1, (copy) v_u_102
		local v_u_105 = p103.size
		local v106 = p103.lite
		local v_u_107 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p104, v_u_8, {
			["transparency"] = 1
		})
		p_u_84.streak(v_u_107, v_u_8, v_u_9, 1.1 * v_u_105, 0.14)
		local v_u_108 = v_u_43(Vector3.new(0.5, 0.22, 2) * v_u_105, v_u_8, 0)
		local v_u_109 = v_u_43(Vector3.new(0.5, 0.22, 1.6) * v_u_105, v_u_9, 0)
		local v110 = {
			["shape"] = v_u_14,
			["material"] = v_u_16
		}
		local v_u_111 = v_u_5.part(Vector3.new(0.6, 0.6, 0.6) * v_u_105, p104, v_u_10, v110)
		local v_u_112 = { v_u_108, v_u_109, v_u_111 }
		local v_u_113
		if v106 then
			v_u_113 = nil
		else
			v_u_113 = v_u_32(p104, 1.55 * v_u_105, v_u_7.Ring, v_u_8, 0.2)
			table.insert(v_u_112, v_u_113)
		end
		if p103.mine then
			p_u_84.light(v_u_107, v_u_8, 9 * v_u_105)
		end
		for _, v114 in v_u_112 do
			v_u_1:AddItem(v114, 3)
		end
		v_u_1:AddItem(v_u_107, 3)
		local v_u_115 = false
		return {
			["place"] = function(p116, p117) -- name: place
				-- upvalues: (copy) v_u_107, (ref) v_u_102, (copy) v_u_108, (copy) v_u_105, (copy) v_u_109, (copy) v_u_111, (ref) v_u_113
				v_u_107.CFrame = p116
				local v118 = p116 * v_u_102
				local v119 = v118 * CFrame.Angles(0, p117 * 30, 0)
				v_u_108.CFrame = v119 * CFrame.new(0, 0, -0.95 * v_u_105)
				v_u_109.CFrame = v119 * CFrame.new(0, 0, 0.8 * v_u_105)
				v_u_111.CFrame = v118
				local v120 = v_u_113
				if v120 then
					v120.CFrame = v118
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_115, (copy) v_u_107, (ref) v_u_1, (copy) v_u_112
				if not v_u_115 then
					v_u_115 = true
					local v121 = v_u_107:FindFirstChildWhichIsA("PointLight")
					if v121 then
						v121:Destroy()
					end
					v_u_1:AddItem(v_u_107, 0.16)
					for _, v122 in v_u_112 do
						v122:Destroy()
					end
				end
			end
		}
	end
	local function v134(p124, p125) -- name: needleImpact
		-- upvalues: (copy) v_u_101, (copy) p_u_84, (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_20, (ref) v_u_12, (ref) v_u_5, (ref) v_u_9
		local v126 = p124.size
		local v127 = p124.lite
		local v128 = v_u_101
		local v129 = p_u_84.facing
		local v130 = v_u_4.CurrentCamera
		local v131
		if v130 then
			local v132 = v130.CFrame.Position - p125
			v131 = v132.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v132.Unit
		else
			v131 = Vector3.new(0, 0, 1)
		end
		v128(v129(p125, v131), 1 * v126, 4.6 * v126, v_u_7.VoidStar, v_u_8, 0.24, 0)
		p_u_84.pop(p125, v_u_8, 1.4 * v126, 4.6 * v126, 0.18, 0.35)
		p_u_84.burst("Impact", p125, v_u_8, 1 * v126)
		if not v127 then
			for _, v133 in v_u_20 do
				p_u_84.spikes(p125, v_u_12, 1, 5 * v126, 0.16, v133, 0.02, true)
			end
		end
		v_u_5.ring(p_u_84.ground(p125), v_u_9, p124.ability.radius * 0.7 * v126, 0.25, v_u_7.Ring)
		p_u_84.hitSound(p125)
	end
	local v_u_135 = {}
	setmetatable(v_u_135, {
		["__mode"] = "k"
	})
	local function v_u_168(p136, p137, p138) -- name: buildSeal
		-- upvalues: (ref) v_u_44, (ref) v_u_61, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_1, (ref) v_u_20, (ref) v_u_14, (ref) v_u_10, (ref) v_u_15, (ref) v_u_16, (ref) v_u_18
		local v139 = v_u_44()
		v_u_61(v139, p137, v_u_7.CompassRose, v_u_8, 0, CFrame.new(0, 0.06, 0), p138)
		v_u_61(v139, p137 * 0.42, v_u_7.VoidStar, v_u_9, 0, CFrame.new(0, 0.1, 0), p138)
		for _, v140 in { 0.7853981633974483, -0.7853981633974483 } do
			local v141 = v_u_5.part
			local v142 = p137 * 1.9
			local v143 = v141(Vector3.new(0.9, 0.15, v142), CFrame.identity, v_u_9)
			local v144 = CFrame.new(0, 0.08, 0) * CFrame.Angles(0, v140, 0)
			v143.Transparency = 1
			v_u_1:AddItem(v143, p138)
			local v145 = v139.parts
			table.insert(v145, v143)
			local v146 = v139.offs
			table.insert(v146, v144)
			local v147 = v139.sizes
			local v148 = v143.Size
			table.insert(v147, v148)
			local v149 = v139.alphas
			table.insert(v149, 0.2)
		end
		for _, v150 in v_u_20 do
			local v151 = v150 * p137 * 0.78
			local v152 = {
				["shape"] = v_u_14
			}
			local v153 = v_u_5.part(Vector3.new(2.4, 2.4, 2.4), CFrame.identity, v_u_8, v152)
			local v154 = CFrame.new(v151 + Vector3.new(0, 1.3, 0))
			v153.Transparency = 1
			v_u_1:AddItem(v153, p138)
			local v155 = v139.parts
			table.insert(v155, v153)
			local v156 = v139.offs
			table.insert(v156, v154)
			local v157 = v139.sizes
			local v158 = v153.Size
			table.insert(v157, v158)
			local v159 = v139.alphas
			table.insert(v159, 0)
			if p136 then
				continue
			end
			local v160 = {
				["shape"] = v_u_15,
				["material"] = v_u_16
			}
			local v161 = v_u_5.part(Vector3.new(0.2, 3.6, 3.6), CFrame.identity, v_u_10, v160)
			local v162 = CFrame.new(v151 + Vector3.new(0, 0.12, 0)) * v_u_18
			v161.Transparency = 1
			v_u_1:AddItem(v161, p138)
			local v163 = v139.parts
			table.insert(v163, v161)
			local v164 = v139.offs
			table.insert(v164, v162)
			local v165 = v139.sizes
			local v166 = v161.Size
			table.insert(v165, v166)
			local v167 = v139.alphas
			table.insert(v167, 0)
		end
		return v139
	end
	local function v_u_191(p169, p170, p171) -- name: sealStep
		-- upvalues: (copy) p_u_84, (ref) v_u_83
		if p169.done then
			return false
		else
			local v172 = os.clock()
			local v173 = p_u_84.ground(p170, 0.05)
			if v172 < p169.landAt then
				local v174 = p169.landAt - p169.born
				local v175 = (v172 - p169.born) / math.max(v174, 0.001)
				local v176 = math.clamp(v175, 0, 1)
				local v177 = (1 - v176) ^ 2 * 6
				local v178 = v_u_83
				local v179 = p169.body
				local v180 = CFrame.new(v173 + Vector3.new(0, 14, 0) * (1 - v176 * v176)) * CFrame.Angles(0, v177, 0)
				local v181 = (v176 * 0.45 + 0.55) * p171
				local v182 = 1 - (v172 - p169.born) / 0.05
				v178(v179, v180, v181, (math.max(0, v182)))
				return true
			elseif v172 < p169.endAt then
				local v183 = v172 - p169.landAt
				local v184 = v_u_83
				local v185 = p169.body
				local v186 = CFrame.new(v173)
				local v187 = v183 * 9
				v184(v185, v186, p171 * (math.sin(v187) * 0.015 + 1), 0)
				return true
			else
				local v188 = (v172 - p169.endAt) / 0.4
				local v189 = math.clamp(v188, 0, 1)
				v_u_83(p169.body, CFrame.new(v173 + Vector3.new(0, 1, 0) * v189 * 1.5), p171 * (v189 * 0.1 + 1), v189)
				if v189 < 1 then
					return true
				end
				p169.done = true
				for _, v190 in p169.body.parts do
					v190:Destroy()
				end
				return false
			end
		end
	end
	local v_u_192 = {}
	local v_u_193 = {}
	setmetatable(v_u_193, {
		["__mode"] = "k"
	})
	local v_u_194 = {}
	setmetatable(v_u_194, {
		["__mode"] = "k"
	})
	local v_u_195 = {
		Vector3.new(0, 1, 0),
		Vector3.new(1, 0, 0),
		Vector3.new(0, -1, 0),
		Vector3.new(-1, 0, 0)
	}
	local function v_u_235(p196, p197) -- name: buildCross
		-- upvalues: (ref) v_u_44, (ref) v_u_61, (ref) v_u_7, (ref) v_u_8, (ref) v_u_17, (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_11, (ref) v_u_14, (copy) v_u_195, (ref) v_u_10, (ref) v_u_15, (ref) v_u_16, (ref) v_u_19
		local v198 = v_u_44()
		v_u_61(v198, 7.4399999999999995, v_u_7.CompassRose, v_u_8, 0.25, CFrame.new(0, 0, -0.15) * v_u_17, p197)
		v_u_61(v198, 6.510000000000001, v_u_7.VoidStar, v_u_8, 0, v_u_17, p197)
		for _, v199 in { 0.7853981633974483, -0.7853981633974483 } do
			local v200 = v_u_5.part(Vector3.new(0.55, 13.02, 0.3), CFrame.identity, v_u_9)
			local v201 = CFrame.new(0, 0, -0.08) * CFrame.Angles(0, 0, v199)
			v200.Transparency = 1
			v_u_1:AddItem(v200, p197)
			local v202 = v198.parts
			table.insert(v202, v200)
			local v203 = v198.offs
			table.insert(v203, v201)
			local v204 = v198.sizes
			local v205 = v200.Size
			table.insert(v204, v205)
			local v206 = v198.alphas
			table.insert(v206, 0.1)
		end
		local v207 = {
			["shape"] = v_u_14
		}
		local v208 = v_u_5.part(Vector3.new(1.7, 1.7, 1.7), CFrame.identity, v_u_11, v207)
		local v209 = CFrame.new(0, 0, 0.2)
		v208.Transparency = 1
		v_u_1:AddItem(v208, p197)
		local v210 = v198.parts
		table.insert(v210, v208)
		local v211 = v198.offs
		table.insert(v211, v209)
		local v212 = v198.sizes
		local v213 = v208.Size
		table.insert(v212, v213)
		local v214 = v198.alphas
		table.insert(v214, 0)
		local v215 = {
			["shape"] = v_u_14
		}
		local v216 = v_u_5.part(Vector3.new(2.8, 2.8, 2.8), CFrame.identity, v_u_8, v215)
		local v217 = CFrame.identity
		v216.Transparency = 1
		v_u_1:AddItem(v216, p197)
		local v218 = v198.parts
		table.insert(v218, v216)
		local v219 = v198.offs
		table.insert(v219, v217)
		local v220 = v198.sizes
		local v221 = v216.Size
		table.insert(v220, v221)
		local v222 = v198.alphas
		table.insert(v222, 0.55)
		if not p196 then
			for _, v223 in v_u_195 do
				local v224 = {
					["shape"] = v_u_15,
					["material"] = v_u_16
				}
				local v225 = v_u_5.part(Vector3.new(0.25, 2.6, 2.6), CFrame.identity, v_u_10, v224)
				local v226 = CFrame.new(v223 * 6.2 + Vector3.new(0, 0, 0.1)) * v_u_19
				v225.Transparency = 1
				v_u_1:AddItem(v225, p197)
				local v227 = v198.parts
				table.insert(v227, v225)
				local v228 = v198.offs
				table.insert(v228, v226)
				local v229 = v198.sizes
				local v230 = v225.Size
				table.insert(v229, v230)
				local v231 = v198.alphas
				table.insert(v231, 0)
			end
		end
		local v232 = {}
		for _ = 1, 4 do
			local v233 = {
				["shape"] = nil,
				["transparency"] = 1,
				["shape"] = v_u_14
			}
			local v234 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.identity, v_u_8, v233)
			v_u_1:AddItem(v234, p197)
			table.insert(v232, v234)
		end
		return v198, v232
	end
	local function v_u_241(p236) -- name: tipsOf
		-- upvalues: (copy) v_u_195
		local v237 = {}
		for _, v238 in v_u_195 do
			local v239 = p236.frame
			local v240 = v238 * 6.2 * p236.scale + Vector3.new(0, 0, 0.35)
			table.insert(v237, v239:PointToWorldSpace(v240))
		end
		return v237
	end
	local function v_u_268(p242, p243) -- name: crossStep
		-- upvalues: (ref) v_u_83, (copy) v_u_195
		if p243.done then
			return false
		end
		local v244 = os.clock()
		local v245 = v244 - p243.born
		local v246 = v245 / 0.16
		local v247 = math.clamp(v246, 0, 1)
		local v248 = v247 - 1
		local v249 = ((v248 * 2.9 * v248 * v248 + 1 + v248 * 1.9 * v248) * 0.7 + 0.3) * p242.size
		local v250 = (1 - v247) ^ 2 * 1.6
		local v251 = v245 * 5
		local v252 = v250 + math.sin(v251) * 0.02
		local v253 = v247 * 3
		local v254 = 1 - math.min(v253, 1)
		local v255 = v245 / 0.3
		local v256 = math.clamp(v255, 0, 1)
		local v257 = p243.fireAt
		local v258
		if v257 then
			v258 = v257 + 0.12
		else
			v258 = p243.born + 1.2
		end
		if v258 < v244 then
			local v259 = (v244 - v258) / 0.35
			local v260 = math.clamp(v259, 0, 1)
			v254 = math.max(v254, v260)
			v249 = v249 * (v260 * 0.15 + 1)
			if v260 >= 1 then
				if not p243.done then
					p243.done = true
					for _, v261 in p243.body.parts do
						v261:Destroy()
					end
					for _, v262 in p243.orbs do
						v262:Destroy()
					end
				end
				return false
			end
		end
		p243.scale = v249
		p243.frame = CFrame.lookAt(p243.center, p243.center + p243.dir) * CFrame.Angles(0, 0, v252)
		v_u_83(p243.body, p243.frame, v249, v254)
		local v263 = (v256 * 1.6 + 1.4) * p242.size
		local v264 = v245 * 40
		local v265 = v263 * (math.sin(v264) * 0.08 + 1)
		for v266, v267 in p243.orbs do
			v267.CFrame = CFrame.new(p243.frame:PointToWorldSpace(v_u_195[v266] * 6.2 * v249 + Vector3.new(0, 0, 0.35)))
			v267.Size = Vector3.new(1, 1, 1) * v265
			v267.Transparency = v254
		end
		return true
	end
	local function v_u_282(p_u_269) -- name: startCross
		-- upvalues: (copy) v_u_235, (copy) p_u_84, (copy) v_u_193, (copy) v_u_194, (copy) v_u_195, (ref) v_u_8, (copy) v_u_268
		local v270 = p_u_269.lite
		local v271, v272 = v_u_235(v270, 4.2)
		local v273 = p_u_84.flatUnit(p_u_269.dir)
		local v274 = p_u_269.eye + v273 * 4 + Vector3.new(0, 1.6, 0)
		local v_u_275 = {
			["body"] = nil,
			["orbs"] = nil,
			["born"] = nil,
			["fireAt"] = nil,
			["center"] = nil,
			["dir"] = nil,
			["frame"] = nil,
			["scale"] = 0.3,
			["done"] = false,
			["body"] = v271,
			["orbs"] = v272,
			["born"] = os.clock(),
			["center"] = v274,
			["dir"] = v273,
			["frame"] = CFrame.lookAt(v274, v274 + v273)
		}
		local v276 = p_u_269.caster
		if v276 then
			local v277 = v_u_193[v276]
			if v277 and not (v277.fireAt or v277.done) then
				v277.done = true
				for _, v278 in v277.body.parts do
					v278:Destroy()
				end
				for _, v279 in v277.orbs do
					v279:Destroy()
				end
			end
			v_u_193[v276] = v_u_275
		else
			v_u_194[p_u_269] = v_u_275
		end
		if not v270 then
			for _, v280 in v_u_195 do
				local v281 = v274 + CFrame.lookAt(v274, v274 + v273):VectorToWorldSpace(v280 * 6.2)
				p_u_84.inward(v281, v_u_8, 3, 5, 0.22)
			end
		end
		p_u_84.runNow(function()
			-- upvalues: (ref) v_u_268, (copy) p_u_269, (copy) v_u_275
			return v_u_268(p_u_269, v_u_275)
		end)
		return v_u_275
	end
	local v_u_283 = 0
	local function v_u_287() -- name: rayFrame
		-- upvalues: (ref) v_u_283, (ref) v_u_2, (ref) v_u_5, (copy) p_u_84, (ref) v_u_13, (ref) v_u_1
		local v284 = os.clock()
		if v284 >= v_u_283 then
			v_u_283 = v284 + 0.6
			local v_u_285 = Instance.new("ColorCorrectionEffect")
			v_u_285.Name = "MeridianRay"
			v_u_285.Parent = v_u_2
			v_u_5.tween(v_u_285, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.2,
				["Brightness"] = 0.06,
				["TintColor"] = Color3.fromRGB(205, 240, 255)
			})
			p_u_84.after(0.12, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_285, (ref) v_u_13
				local v286 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Brightness"] = 0,
					["TintColor"] = v_u_13
				}
				v_u_5.tween(v_u_285, 0.4, v286)
			end)
			v_u_1:AddItem(v_u_285, 0.6)
		end
	end
	local function v_u_321(p_u_288, p289, p290) -- name: fireRay
		-- upvalues: (copy) v_u_241, (copy) p_u_84, (ref) v_u_8, (ref) v_u_13, (ref) v_u_5, (ref) v_u_12, (copy) v_u_101, (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_32, (ref) v_u_1, (ref) v_u_36, (ref) v_u_6, (copy) v_u_287
		local v_u_291 = p_u_288.size
		local v_u_292 = p_u_288.lite
		p289.fireAt = os.clock()
		local v_u_293 = p289.center + p289.dir * 9
		local v294 = p290.X
		local v295 = p290.Y
		local v296 = p290.Z
		local v_u_297 = Vector3.new(v294, v295, v296)
		local v_u_298 = (v_u_297 - v_u_293).Unit
		for _, v299 in v_u_241(p289) do
			p_u_84.glowBeam(v299, v_u_293, v_u_8, 1.6 * v_u_291, 0.4)
			if not v_u_292 then
				p_u_84.glowBeam(v299, v_u_293, v_u_13, 0.5 * v_u_291, 0.3)
			end
			v_u_5.flash(v299, v_u_12, 3 * v_u_291, 0.14)
		end
		v_u_5.flash(v_u_293, v_u_12, 8 * v_u_291, 0.16)
		local v300 = v_u_101
		local v301 = p_u_84.facing
		local v302 = v_u_4.CurrentCamera
		local v303
		if v302 then
			local v304 = v302.CFrame.Position - v_u_293
			v303 = v304.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v304.Unit
		else
			v303 = Vector3.new(0, 0, 1)
		end
		v300(v301(v_u_293, v303), 2 * v_u_291, 8 * v_u_291, v_u_7.VoidStar, v_u_8, 0.32, 0)
		p_u_84.glowBeam(v_u_293, v_u_297, v_u_9, 12 * v_u_291, 0.6)
		local v305 = p_u_84.glowBeam
		local v306 = v_u_8
		local v307 = 6.5 * v_u_291
		local v308 = 0.55
		local v309
		if v_u_292 then
			v309 = nil
		else
			v309 = v_u_7.LightningArc
		end
		v305(v_u_293, v_u_297, v306, v307, v308, v309)
		p_u_84.glowBeam(v_u_293, v_u_297, v_u_13, 2.2 * v_u_291, 0.45)
		p_u_84.thin(p_u_84.rod(v_u_293, v_u_297, 2.6 * v_u_291, v_u_12), 0.45, true)
		if not v_u_292 then
			p_u_84.thin(p_u_84.rod(v_u_293, v_u_297, 8 * v_u_291, v_u_8, 0.75), 0.5, true)
			for v310 = 0, 3 do
				p_u_84.after(v310 * 0.07, function()
					-- upvalues: (ref) v_u_32, (ref) p_u_84, (copy) v_u_293, (copy) v_u_298, (copy) v_u_291, (ref) v_u_7, (ref) v_u_12, (ref) v_u_1, (copy) v_u_297, (ref) v_u_36
					local v_u_311 = v_u_32(p_u_84.facing(v_u_293, v_u_298), 5.5 * v_u_291, v_u_7.CompassRose, v_u_12, 0.1)
					v_u_1:AddItem(v_u_311, 0.4)
					p_u_84.animate(0.3, 0, function(p312)
						-- upvalues: (copy) v_u_311, (ref) p_u_84, (ref) v_u_293, (ref) v_u_297, (ref) v_u_298, (ref) v_u_36
						v_u_311.CFrame = p_u_84.facing(v_u_293:Lerp(v_u_297, p312), v_u_298) * CFrame.Angles(0, p312 * 8, 0)
						v_u_36(v_u_311, 0.1 + 0.9 * p312 ^ 2)
						if p312 >= 1 then
							v_u_311:Destroy()
						end
					end)
				end)
			end
			p_u_84.alongPath(v_u_293, v_u_297, 14, 0.12, function(p313)
				-- upvalues: (ref) p_u_84, (ref) v_u_8
				p_u_84.burst("Impact", p313, v_u_8, 1.2)
			end)
		end
		p_u_84.groundLine(v_u_293, v_u_297, 9 * v_u_291, v_u_8, 0.9, 0.55)
		p_u_84.groundLine(v_u_293, v_u_297, 3 * v_u_291, v_u_12, 0.7, 0.3)
		p_u_84.after(0.1, function()
			-- upvalues: (ref) p_u_84, (copy) v_u_297, (ref) v_u_8, (copy) v_u_291, (ref) v_u_5, (ref) v_u_12, (ref) v_u_9, (ref) v_u_7, (ref) v_u_101, (ref) v_u_4, (copy) v_u_292, (ref) v_u_6, (copy) p_u_288
			p_u_84.burst("Explosion", v_u_297, v_u_8, 1.8 * v_u_291)
			v_u_5.flash(v_u_297, v_u_12, 14 * v_u_291, 0.2)
			v_u_5.ring(p_u_84.ground(v_u_297), v_u_9, 14 * v_u_291, 0.5, v_u_7.Shockwave)
			local v314 = v_u_101
			local v315 = p_u_84.facing
			local v316 = v_u_297
			local v317 = v_u_297
			local v318 = v_u_4.CurrentCamera
			local v319
			if v318 then
				local v320 = v318.CFrame.Position - v317
				v319 = v320.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v320.Unit
			else
				v319 = Vector3.new(0, 0, 1)
			end
			v314(v315(v316, v319), 3 * v_u_291, 12 * v_u_291, v_u_7.VoidStar, v_u_9, 0.4, 0)
			if not v_u_292 then
				p_u_84.spikes(v_u_297, v_u_12, 8, 10 * v_u_291, 0.3)
			end
			v_u_6.play("Explosion", {
				["at"] = v_u_297,
				["volume"] = p_u_288.mine and 0.8 or 0.45
			})
		end)
		if p_u_288.mine then
			v_u_5.shake(0.45, 0.45)
			v_u_287()
		end
	end
	local v365 = {
		["void_compass_a"] = {
			["cast"] = function(p322) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_84, (ref) v_u_13, (copy) v_u_101, (ref) v_u_7
				local v323 = p322.size
				local v324 = p322.eye + p322.dir * 1.2
				v_u_5.flash(v324, v_u_8, 3 * v323, 0.12)
				p_u_84.pop(v324, v_u_13, 1.2 * v323, 0.3 * v323, 0.1)
				if not p322.lite then
					v_u_101(p_u_84.facing(v324, p322.dir), 0.5 * v323, 2.4 * v323, v_u_7.CompassRose, v_u_8, 0.14, 6, 0.1)
				end
			end,
			["shot"] = v123,
			["impact"] = v134,
			["hit"] = function(p325, p326, _) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_8, (ref) v_u_12
				p_u_84.burst("Impact", p326, v_u_8, 0.6)
				if not p325.lite then
					p_u_84.glint(p326, v_u_12, 2.5, 0.12)
				end
			end
		},
		["void_compass_e"] = {
			["cast"] = function(p327) -- name: cast
				-- upvalues: (copy) p_u_84, (ref) v_u_8, (copy) v_u_101, (ref) v_u_7
				p_u_84.skillCast(p327, v_u_8)
				if not p327.lite then
					v_u_101(p_u_84.facing(p327.eye, p327.dir), 1, 4, v_u_7.CompassRose, v_u_8, 0.2, 6, 0.1)
				end
			end,
			["windup"] = function(p328, p_u_329, p330) -- name: windup
				-- upvalues: (copy) v_u_168, (copy) v_u_135, (copy) p_u_84, (copy) v_u_191
				local v331 = p328.size
				local v332 = p328.ability.radius * 0.95 * v331
				local v333 = p328.ability.freeze or 2.5
				local v334 = os.clock()
				local v_u_335 = {
					["body"] = nil,
					["born"] = nil,
					["landAt"] = nil,
					["endAt"] = nil,
					["done"] = false,
					["body"] = v_u_168(p328.lite, v332, p330 + v333 + 2),
					["born"] = v334,
					["landAt"] = v334 + math.max(p330, 0),
					["endAt"] = v334 + math.max(p330, 0) + v333
				}
				v_u_135[p328] = v_u_335
				p_u_84.runNow(function()
					-- upvalues: (ref) v_u_191, (copy) v_u_335, (copy) p_u_329
					return v_u_191(v_u_335, p_u_329, 1)
				end)
			end,
			["land"] = function(p336, p337) -- name: land
				-- upvalues: (copy) p_u_84, (ref) v_u_5, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_20, (ref) v_u_9, (ref) v_u_6
				local v338 = p336.size
				local v339 = p336.lite
				local v340 = p336.ability.radius * v338
				local v341 = v340 * 0.95
				local v342 = p336.ability.freeze or 2.5
				local v343 = p_u_84.ground(p337)
				v_u_5.flash(p_u_84.ground(p337, 1), v_u_12, v340 * 0.7, 0.12)
				v_u_5.ring(v343, v_u_8, v340 * 1.2, 0.4, v_u_7.Shockwave)
				p_u_84.burst("Shockwave", v343 + Vector3.new(0, 0.3, 0), v_u_8, v340 / 14)
				local v344 = {}
				for _, v345 in v_u_20 do
					local v346 = v343 + v345 * v341 * 0.78
					local v347 = v346 + Vector3.new(0, 1.3, 0)
					table.insert(v344, v347)
					p_u_84.thin(p_u_84.pillar(v346, 16, 2.6, v_u_8, 0.35), 0.6)
					p_u_84.burst("Impact", v346 + Vector3.new(0, 1.3, 0), v_u_8, 1.2)
				end
				p_u_84.glowBeam(v344[1], v344[3], v_u_8, 1.5, v342, v_u_7.LightningArc)
				p_u_84.glowBeam(v344[2], v344[4], v_u_8, 1.5, v342, v_u_7.LightningArc)
				if not v339 then
					for v348 = 1, 4 do
						p_u_84.glowBeam(v344[v348], v344[v348 % 4 + 1], v_u_9, 0.9, v342)
					end
					p_u_84.spikes(p_u_84.ground(p337, 1), v_u_12, 8, v340 * 0.8, 0.25, nil, nil, true)
				end
				v_u_6.play("Burst", {
					["at"] = v343,
					["volume"] = p336.mine and 0.7 or 0.4
				})
				if p336.mine then
					v_u_5.shake(0.3, 0.25)
				end
			end,
			["hit"] = function(p349, p350, p_u_351) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_8, (copy) v_u_192, (ref) v_u_9, (copy) v_u_101, (ref) v_u_7
				local v352 = os.clock()
				p_u_84.burst("Impact", p350, v_u_8, 0.7)
				if v352 >= (v_u_192[p_u_351] or 0) then
					local v353 = p349.ability.freeze or 2.5
					local v_u_354 = v352 + v353
					v_u_192[p_u_351] = v_u_354
					task.delay(v353 + 0.1, function()
						-- upvalues: (ref) v_u_192, (copy) p_u_351, (copy) v_u_354
						if v_u_192[p_u_351] == v_u_354 then
							v_u_192[p_u_351] = nil
						end
					end)
					p_u_84.bindHit(p349, p350, p_u_351, v_u_8, v_u_9)
					if not p349.lite then
						v_u_101(CFrame.new(p350 - Vector3.new(0, 1.6, 0)), 1, 3.2, v_u_7.CompassRose, v_u_8, 0.35, 4, 0.1)
					end
				end
			end
		},
		["void_compass_r"] = {
			["cast"] = function(p355) -- name: cast
				-- upvalues: (copy) p_u_84, (ref) v_u_8, (copy) v_u_282
				p_u_84.skillCast(p355, v_u_8, true)
				v_u_282(p355)
			end,
			["windup"] = function(p356, _, _) -- name: windup
				-- upvalues: (copy) v_u_193, (copy) v_u_194, (copy) v_u_282, (ref) v_u_5
				local v357 = p356.caster
				local v358
				if v357 then
					v358 = v_u_193[v357]
				else
					v358 = v_u_194[p356]
				end
				if not v358 or (v358.done or v358.fireAt) then
					v358 = nil
				end
				if not v358 then
					v_u_282(p356)
				end
				if p356.mine then
					v_u_5.shake(0.15, 0.25)
				end
			end,
			["beam"] = function(p359, _, p360) -- name: beam
				-- upvalues: (copy) v_u_193, (copy) v_u_194, (copy) v_u_282, (copy) v_u_321
				local v361 = p359.caster
				local v362
				if v361 then
					v362 = v_u_193[v361]
				else
					v362 = v_u_194[p359]
				end
				if not v362 or (v362.done or v362.fireAt) then
					v362 = nil
				end
				v_u_321(p359, v362 or v_u_282(p359), p360)
			end,
			["hit"] = function(p363, p364, _) -- name: hit
				-- upvalues: (copy) p_u_84, (ref) v_u_8, (ref) v_u_9
				p_u_84.burst("Impact", p364, v_u_8, 0.9)
				if not p363.lite then
					p_u_84.spikes(p364, v_u_9, 3, 4, 0.15)
				end
			end
		}
	}
	return v365
end