local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.CeroOrb,
	v_u_7.InfernoFlame,
	v_u_7.HollowRing,
	v_u_7.Glow,
	v_u_7.FxSmoke
})
local v_u_8 = Color3.fromHex("FF2A2A")
local v_u_9 = Color3.fromRGB(150, 0, 10)
local v_u_10 = Color3.fromRGB(18, 0, 0)
local v_u_11 = Color3.fromRGB(255, 120, 40)
local v_u_12 = Color3.fromRGB(40, 4, 6)
local v_u_13 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_14 = Enum.ParticleFlipbookMode.OneShot
local v_u_15 = Enum.Material.Neon
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_23(p17) -- name: seq
	local v18 = {}
	for _, v19 in p17 do
		local v20 = NumberSequenceKeypoint.new
		local v21 = v19[1]
		local v22 = v19[2]
		table.insert(v18, v20(v21, v22))
	end
	return NumberSequence.new(v18)
end
local function v_u_30(p24, p25, p26, p27) -- name: flameEmitter
	-- upvalues: (copy) v_u_7, (copy) v_u_13, (copy) v_u_14, (copy) v_u_8, (copy) v_u_9, (copy) v_u_23
	local v28 = p25 / 0.625
	local v29 = Instance.new("ParticleEmitter")
	v29.Texture = v_u_7.InfernoFlame
	v29.FlipbookLayout = v_u_13
	v29.FlipbookMode = v_u_14
	v29.Color = ColorSequence.new(v_u_8, v_u_9)
	v29.LightEmission = 0
	v29.LightInfluence = 0
	v29.Brightness = 1.3
	v29.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
	v29.Size = v_u_23({
		{ 0, p24 * 0.32 },
		{ 0.25, p24 * 0.5 },
		{ 1, p24 * 0.42 }
	})
	v29.Lifetime = NumberRange.new(v28 * 0.85, v28)
	v29.Speed = NumberRange.new(p26 * 0.5, p26)
	v29.EmissionDirection = Enum.NormalId.Top
	v29.SpreadAngle = Vector2.new(p27, p27)
	v29.Rotation = NumberRange.new(-12, 12)
	v29.Drag = 2.5
	v29.Rate = 0
	v29.Enabled = false
	return v29
end
local function v_u_39(p31, p32, p33, p34, p35) -- name: embers
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_7, (copy) v_u_11, (copy) v_u_8, (copy) v_u_23
	local v36 = p35 + 0.2
	local v37 = Instance.new("Attachment")
	v37.WorldPosition = p31
	v37.Parent = v_u_3.Terrain
	v_u_1:AddItem(v37, v36)
	local v38 = Instance.new("ParticleEmitter")
	v38.Texture = v_u_7.Glow
	v38.Color = ColorSequence.new(v_u_11, v_u_8)
	v38.LightEmission = 1
	v38.LightInfluence = 0
	v38.Size = v_u_23({
		{ 0, p34 },
		{ 1, 0 }
	})
	v38.Lifetime = NumberRange.new(p35 * 0.6, p35)
	v38.Speed = NumberRange.new(p33 * 0.4, p33)
	v38.EmissionDirection = Enum.NormalId.Top
	v38.SpreadAngle = Vector2.new(75, 75)
	v38.Acceleration = Vector3.new(0, -30, 0)
	v38.Drag = 1.5
	v38.Rate = 0
	v38.Enabled = false
	v38.Parent = v37
	v38:Emit(p32)
end
local function v_u_73(p40, p41, p42, p43, p44, p45, p46, p47, p48, p49, p50, p51) -- name: sprite
	-- upvalues: (copy) v_u_3, (copy) v_u_1, (copy) v_u_13, (copy) v_u_14
	local v52 = p47 + p48 + p49
	local v53 = math.max(v52, 0.05)
	local v54 = {}
	local v55 = {}
	for v56 = 0, 10 do
		local v57 = v56 / 10
		local v58 = v57 * v53
		local v59 = v58 / math.max(p47, 0.001)
		local v60 = 1 - (1 - math.clamp(v59, 0, 1)) ^ 3
		local v61 = (v58 - p47 - p48) / math.max(p49, 0.001)
		local v62 = math.clamp(v61, 0, 1)
		local v63 = v62 * v62 * (3 - v62 * 2)
		local v64 = NumberSequenceKeypoint.new
		local v65 = p44 + (p45 - p44) * v60
		local v66 = math.max(v65, 0.05) / 2
		table.insert(v55, v64(v57, v66))
		local v67 = NumberSequenceKeypoint.new
		local v68 = p46 + (1 - p46) * v63
		local v69 = math.clamp(v68, 0, 1)
		table.insert(v54, v67(v57, v69))
	end
	local v70 = v53 + 0.2
	local v71 = Instance.new("Attachment")
	v71.WorldPosition = p40
	v71.Parent = v_u_3.Terrain
	v_u_1:AddItem(v71, v70)
	local v72 = Instance.new("ParticleEmitter")
	v72.Enabled = false
	v72.Texture = p42
	if p51 then
		v72.FlipbookLayout = v_u_13
		v72.FlipbookMode = v_u_14
	end
	v72.Color = ColorSequence.new(p43)
	v72.LightEmission = p50
	v72.LightInfluence = 0
	if p41 then
		v72.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v72.EmissionDirection = Enum.NormalId.Top
		v72.SpreadAngle = Vector2.zero
		v72.Speed = NumberRange.new(0.01)
		v72.Rotation = NumberRange.new(0, 360)
	else
		v72.Orientation = Enum.ParticleOrientation.FacingCamera
		v72.Speed = NumberRange.new(0)
		v72.Rotation = NumberRange.new(-20, 20)
	end
	v72.Size = NumberSequence.new(v55)
	v72.Transparency = NumberSequence.new(v54)
	v72.Lifetime = NumberRange.new(v53)
	v72.Parent = v71
	v72:Emit(1)
end
local function v_u_82(p74, p75, p76, p77, p78, p79, p80) -- name: riding
	-- upvalues: (copy) v_u_13, (copy) v_u_23
	local v81 = Instance.new("ParticleEmitter")
	v81.Texture = p75
	if p80 then
		v81.FlipbookLayout = v_u_13
		v81.FlipbookMode = Enum.ParticleFlipbookMode.Loop
		v81.FlipbookFramerate = NumberRange.new(18)
	end
	v81.Color = ColorSequence.new(p76)
	v81.LightEmission = p78
	v81.LightInfluence = 0
	v81.LockedToPart = true
	v81.Orientation = Enum.ParticleOrientation.FacingCamera
	v81.Size = NumberSequence.new(p77 / 2)
	v81.Transparency = v_u_23({
		{ 0, 0.3 },
		{ 0.5, 0 },
		{ 1, 0.5 }
	})
	v81.Lifetime = NumberRange.new(0.08)
	v81.Speed = NumberRange.new(0)
	v81.Rotation = NumberRange.new(0)
	v81.Rate = 30
	v81.ZOffset = p79
	v81.Parent = p74
	return v81
end
local function v_u_94(p83, p84, p85, p86) -- name: crackPoints
	local v87 = -p84.Z
	local v88 = p84.X
	local v89 = Vector3.new(v87, 0, v88)
	local v90 = { p83 }
	for v91 = 1, p86 do
		local v92 = v91 >= p86 and 0 or (math.random() - 0.5) * 2 * p85 * 0.07
		local v93 = p83 + p84 * p85 * v91 / p86 + v89 * v92
		table.insert(v90, v93)
	end
	return v90
end
return function(p_u_95)
	-- upvalues: (copy) v_u_73, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10, (copy) v_u_39, (copy) v_u_4, (copy) v_u_1, (copy) v_u_9, (copy) v_u_23, (copy) v_u_82, (copy) v_u_3, (copy) v_u_30, (copy) v_u_94, (copy) v_u_15, (copy) v_u_16, (copy) v_u_13, (copy) v_u_12, (copy) v_u_6
	local v96 = {}
	local function v_u_101(p97, p98) -- name: castFlash
		-- upvalues: (ref) v_u_73, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (copy) p_u_95, (ref) v_u_39, (ref) v_u_4
		local v99 = p97.size * (p98 and 1.35 or 1)
		local v100 = p97.eye + p97.dir * 1.2
		v_u_73(v100, false, v_u_7.Glow, v_u_8, 1 * v99, 7 * v99, 0.1, 0.1, 0.05, 0.2, 0.7)
		v_u_73(v100, false, v_u_7.CeroOrb, v_u_8, 1 * v99, 4.5 * v99, 0, 0.12, 0.05, 0.12, 0.25, true)
		v_u_73(v100, false, v_u_7.Glow, v_u_10, 0.5 * v99, 1.8 * v99, 0, 0.12, 0.05, 0.12, 0)
		v_u_73(p_u_95.ground(p97.feet, 0.12), true, v_u_7.HollowRing, v_u_8, 2 * v99, 13 * v99, 0, 0.4, 0, 0.05, 0.3, true)
		if not p97.lite then
			v_u_39(p97.feet + Vector3.new(0, 1, 0), p98 and 12 or 6, 16 * v99, 0.35 * v99, 0.6)
		end
		if p97.mine then
			v_u_4.shake(p98 and 0.14 or 0.07, 0.14)
		end
	end
	v96.cero_inferno_a = {
		["cast"] = function(p102) -- name: cast
			-- upvalues: (ref) v_u_73, (ref) v_u_7, (ref) v_u_8, (ref) v_u_39
			local v103 = p102.size
			local v104 = p102.eye + p102.dir * 1.3
			v_u_73(v104, false, v_u_7.HollowRing, v_u_8, 1 * v103, 3.4 * v103, 0, 0.18, 0, 0.05, 0.3, true)
			if not p102.lite then
				v_u_39(v104, 4, 10 * v103, 0.3 * v103, 0.4)
			end
		end,
		["shot"] = function(p105, p106) -- name: spearShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_23, (ref) v_u_82, (ref) v_u_7, (copy) p_u_95
			local v107 = p105.size * 1.25
			local v_u_108 = 5.5 * v107
			local v_u_109 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p106, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_109, 3)
			local v110 = Instance.new("Attachment")
			local v111 = -v_u_108 * 0.5
			v110.Position = Vector3.new(0, 0, v111)
			v110.Parent = v_u_109
			local v112 = Instance.new("Attachment")
			local v113 = -v_u_108 * 0.25
			v112.Position = Vector3.new(0, 0, v113)
			v112.Parent = v_u_109
			local v114 = Instance.new("Attachment")
			local v115 = v_u_108 * 0.5
			v114.Position = Vector3.new(0, 0, v115)
			v114.Parent = v_u_109
			for v116, v117 in {
				{
					["color"] = nil,
					["w"] = 1.6,
					["glow"] = 0,
					["z"] = 0,
					["color"] = v_u_9
				},
				{
					["color"] = nil,
					["w"] = 1.05,
					["glow"] = 0.45,
					["z"] = 0.05,
					["color"] = v_u_8
				},
				{
					["color"] = nil,
					["w"] = 0.42,
					["glow"] = 0,
					["z"] = 0.1,
					["color"] = v_u_10
				}
			} do
				if p105.lite and v116 == 1 then
					continue
				end
				for v118 = 1, 2 do
					local v119 = Instance.new("Beam")
					local v120
					if v118 == 1 then
						v120 = v110
					else
						v120 = v112
					end
					v119.Attachment0 = v120
					local v121
					if v118 == 1 then
						v121 = v112
					else
						v121 = v114
					end
					v119.Attachment1 = v121
					v119.Color = ColorSequence.new(v117.color)
					v119.LightEmission = v117.glow
					v119.LightInfluence = 0
					v119.FaceCamera = true
					v119.Segments = 1
					v119.ZOffset = v117.z
					v119.Width0 = v118 == 1 and 0.05 or v117.w * v107
					local v122
					if v118 == 1 then
						v122 = v117.w * v107
					else
						v122 = v117.w * 0.18 * v107
					end
					v119.Width1 = v122
					local v123
					if v118 == 1 then
						v123 = NumberSequence.new(0)
					else
						v123 = v_u_23({
							{ 0, 0 },
							{ 0.7, 0.1 },
							{ 1, 0.6 }
						})
					end
					v119.Transparency = v123
					v119.Parent = v_u_109
				end
			end
			local v_u_124 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p106, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_124, 3)
			v_u_82(v_u_124, v_u_7.CeroOrb, v_u_8, 2.2 * v107, 0.25, 0.4, true)
			v_u_82(v_u_124, v_u_7.Glow, v_u_8, 4 * v107, 0.6, -0.2)
			p_u_95.streak(v_u_109, v_u_8, v_u_10, 0.9 * v107, 0.14)
			local v_u_125 = false
			return {
				["place"] = function(p126, _) -- name: place
					-- upvalues: (copy) v_u_109, (copy) v_u_124, (copy) v_u_108
					v_u_109.CFrame = p126
					v_u_124.CFrame = p126 * CFrame.new(0, 0, -v_u_108 * 0.42)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_125, (copy) v_u_109, (copy) v_u_124, (ref) v_u_1
					if not v_u_125 then
						v_u_125 = true
						for _, v127 in v_u_109:GetChildren() do
							if not v127:IsA("Beam") then
								continue
							end
							v127:Destroy()
						end
						for _, v128 in v_u_124:GetChildren() do
							if not v128:IsA("ParticleEmitter") then
								continue
							end
							v128.Enabled = false
						end
						v_u_1:AddItem(v_u_109, 0.3)
						v_u_1:AddItem(v_u_124, 0.2)
					end
				end
			}
		end,
		["impact"] = function(p129, p130) -- name: impact
			-- upvalues: (copy) p_u_95, (ref) v_u_3, (ref) v_u_1, (ref) v_u_30, (ref) v_u_73, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_39
			local v131 = p129.size
			local v132 = p_u_95.ground(p130, 0.1)
			local v133 = p129.lite and 2 or 4
			local v134 = 5 * v131
			local v135 = 7 * v131
			local v136 = Instance.new("Attachment")
			v136.WorldPosition = v132
			v136.Parent = v_u_3.Terrain
			v_u_1:AddItem(v136, 0.9199999999999999)
			local v137 = v_u_30(v134, 0.45, v135, 28)
			v137.Parent = v136
			v137:Emit(v133)
			v_u_73(v132, true, v_u_7.HollowRing, v_u_8, 1.5 * v131, p129.ability.radius * 1.7 * v131, 0, 0.45, 0, 0.05, 0.25, true)
			v_u_73(v132 + Vector3.new(0, 0.05, 0), true, v_u_7.Glow, v_u_10, 3 * v131, 8 * v131, 0.05, 0.1, 0.5, 0.7, 0)
			if not p129.lite then
				v_u_39(p130, 10, 18 * v131, 0.35 * v131, 0.6)
			end
			p_u_95.hitSound(p130)
		end,
		["hit"] = function(_, p138, _) -- name: hit
			-- upvalues: (ref) v_u_3, (ref) v_u_1, (ref) v_u_30
			local v139 = p138 - Vector3.new(0, 1.5, 0)
			local v140 = Instance.new("Attachment")
			v140.WorldPosition = v139
			v140.Parent = v_u_3.Terrain
			v_u_1:AddItem(v140, 0.76)
			local v141 = v_u_30(2.4, 0.35, 3, 10)
			v141.Parent = v140
			v141:Emit(1)
		end
	}
	v96.cero_inferno_e = {
		["cast"] = function(p142) -- name: cast
			-- upvalues: (copy) v_u_101, (ref) v_u_73, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10
			v_u_101(p142, false)
			local v143 = p142.size
			for v144 = -2, 2 do
				local v145 = v144 / 2
				local v146 = p142.size
				local v147 = p142.dir:Cross(Vector3.new(0, 1, 0))
				local v148 = v145 * 1.2217304763960306
				local v149 = p142.eye - p142.dir * 1.3 * v146 + v147 * math.sin(v148) * 3.3 * v146 + Vector3.new(0, 1, 0) * (math.cos(v148) * 2.6 - 0.5) * v146
				v_u_73(v149, false, v_u_7.Glow, v_u_8, 0.5 * v143, 6.5 * v143, 0.1, 0.12, 0.05, 0.15, 0.6)
				v_u_73(v149, false, v_u_7.CeroOrb, v_u_8, 0.4 * v143, 4 * v143, 0, 0.12, 0.05, 0.15, 0.2, true)
				v_u_73(v149, false, v_u_7.Glow, v_u_10, 0.2 * v143, 2 * v143, 0, 0.12, 0.05, 0.15, 0)
			end
		end,
		["shot"] = function(p150, p151) -- name: ceroShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_82, (ref) v_u_7, (ref) v_u_10, (copy) p_u_95
			local v152 = p150.size
			local v153 = p151.LookVector
			local v154 = p150.dir:Cross(Vector3.new(0, 1, 0))
			local v155 = v153.X
			local v156 = v153.Z
			local v157 = Vector3.new(v155, 0, v156)
			local v158 = (v157.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v157.Unit):Dot(v154) / 0.5
			local v159 = math.clamp(v158, -1, 1)
			local v160 = p150.size
			local v161 = p150.dir:Cross(Vector3.new(0, 1, 0))
			local v162 = v159 * 1.2217304763960306
			local v_u_163 = p150.eye - p150.dir * 1.3 * v160 + v161 * math.sin(v162) * 3.3 * v160 + Vector3.new(0, 1, 0) * (math.cos(v162) * 2.6 - 0.5) * v160 - p151.Position
			local v_u_164 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p151, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_164, 3)
			v_u_82(v_u_164, v_u_7.Glow, v_u_8, 6.5 * v152, 0.6, 0)
			v_u_82(v_u_164, v_u_7.CeroOrb, v_u_8, 4 * v152, 0.2, 0.3, true)
			v_u_82(v_u_164, v_u_7.Glow, v_u_10, 2.1 * v152, 0, 0.4)
			p_u_95.streak(v_u_164, v_u_8, v_u_10, 1.8 * v152, 0.22)
			local v_u_165 = false
			return {
				["place"] = function(p166, p167) -- name: place
					-- upvalues: (copy) v_u_164, (copy) v_u_163
					local v168 = v_u_164
					local v169 = v_u_163
					local v170 = p167 / 0.16
					local v171 = math.clamp(v170, 0, 1)
					v168.CFrame = p166 + v169 * (1 - v171 * v171 * (3 - v171 * 2))
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_165, (copy) v_u_164, (ref) v_u_1
					if not v_u_165 then
						v_u_165 = true
						for _, v172 in v_u_164:GetChildren() do
							if not v172:IsA("ParticleEmitter") then
								continue
							end
							v172.Enabled = false
						end
						v_u_1:AddItem(v_u_164, 0.3)
					end
				end
			}
		end,
		["impact"] = function(p173, p174) -- name: impact
			-- upvalues: (ref) v_u_73, (ref) v_u_7, (ref) v_u_8, (copy) p_u_95, (ref) v_u_3, (ref) v_u_1, (ref) v_u_30, (ref) v_u_10, (ref) v_u_39
			local v175 = p173.size
			v_u_73(p174, false, v_u_7.HollowRing, v_u_8, 2 * v175, 11 * v175, 0, 0.35, 0, 0.05, 0.25, true)
			local v176 = p_u_95.ground(p174, 0.1)
			local v177 = p173.lite and 1 or 2
			local v178 = 5 * v175
			local v179 = 6 * v175
			local v180 = Instance.new("Attachment")
			v180.WorldPosition = v176
			v180.Parent = v_u_3.Terrain
			v_u_1:AddItem(v180, 0.8400000000000001)
			local v181 = v_u_30(v178, 0.4, v179, 16)
			v181.Parent = v180
			v181:Emit(v177)
			v_u_73(v176 + Vector3.new(0, 0.05, 0), true, v_u_7.Glow, v_u_10, 2 * v175, 6 * v175, 0.1, 0.1, 0.3, 0.5, 0)
			if not p173.lite then
				v_u_39(p174, 8, 16 * v175, 0.35 * v175, 0.5)
			end
			p_u_95.hitSound(p174)
		end,
		["hit"] = function(_, p182, _) -- name: hit
			-- upvalues: (ref) v_u_3, (ref) v_u_1, (ref) v_u_30
			local v183 = p182 - Vector3.new(0, 1.5, 0)
			local v184 = Instance.new("Attachment")
			v184.WorldPosition = v183
			v184.Parent = v_u_3.Terrain
			v_u_1:AddItem(v184, 0.76)
			local v185 = v_u_30(2.6, 0.35, 3, 10)
			v185.Parent = v184
			v185:Emit(1)
		end
	}
	local v_u_186 = {}
	setmetatable(v_u_186, {
		["__mode"] = "k"
	})
	local function v_u_201(p187, p188) -- name: crossArms
		-- upvalues: (ref) v_u_94
		local v189 = p187.ability.radius * p187.size
		local v190 = p187.dir.Z
		local v191 = p187.dir.X
		local v192 = math.atan2(v190, v191) + 0.7853981633974483
		local v193 = p187.lite and 4 or 6
		local v194 = {}
		for v195 = 0, 3 do
			local v196 = v192 + v195 * 3.141592653589793 / 2
			local v197 = v_u_94
			local v198 = math.cos(v196)
			local v199 = math.sin(v196)
			local v200 = v197(p188, Vector3.new(v198, 0, v199), v189 * 0.95, v193)
			table.insert(v194, v200)
		end
		return v194
	end
	local function v_u_224(p202, p203, p_u_204) -- name: drawCracks
		-- upvalues: (ref) v_u_8, (ref) v_u_15, (ref) v_u_10, (ref) v_u_16, (ref) v_u_4, (ref) v_u_1, (copy) p_u_95
		local v205 = p202.size
		local v206 = {}
		for _, v207 in p203 do
			local v_u_208 = #v207 - 1
			for v209 = 1, v_u_208 do
				local v210 = v207[v209]
				local v211 = v207[v209 + 1]
				local v212 = (v211 - v210).Magnitude
				local v213 = (1.5 - (v209 - 1) * 1.05 / v_u_208) * v205
				local v214 = CFrame.lookAt(v210, v211)
				local v215 = {
					{
						["color"] = nil,
						["material"] = nil,
						["width"] = nil,
						["lift"] = 0.1,
						["color"] = v_u_8,
						["material"] = v_u_15,
						["width"] = v213
					}
				}
				if not p202.lite then
					local v216 = {
						["color"] = nil,
						["material"] = nil,
						["width"] = nil,
						["lift"] = 0.06,
						["color"] = v_u_10,
						["material"] = v_u_16,
						["width"] = v213 * 2.1
					}
					table.insert(v215, 1, v216)
				end
				for _, v217 in v215 do
					local v218 = v_u_4.part
					local v219 = v217.width
					local v_u_220 = v218(Vector3.new(v219, 0.1, 0.05), v214 + Vector3.new(0, 1, 0) * v217.lift, v217.color, {
						["material"] = v217.material
					})
					v_u_1:AddItem(v_u_220, p_u_204 + 4)
					table.insert(v206, v_u_220)
					local v_u_221 = {}
					local v222 = v217.width
					local v223 = v212 + v217.width * 0.5
					v_u_221.Size = Vector3.new(v222, 0.1, v223)
					v_u_221.CFrame = v214 * CFrame.new(0, 0, -v212 / 2) + Vector3.new(0, 1, 0) * v217.lift
					p_u_95.after(p_u_204 * (v209 - 1) / v_u_208, function()
						-- upvalues: (copy) v_u_220, (ref) v_u_4, (copy) p_u_204, (copy) v_u_208, (copy) v_u_221
						if v_u_220.Parent then
							v_u_4.tween(v_u_220, p_u_204 / v_u_208 + 0.02, v_u_221, Enum.EasingStyle.Linear)
						end
					end)
				end
			end
		end
		return v206
	end
	v96.cero_inferno_r = {
		["cast"] = function(p225) -- name: cast
			-- upvalues: (copy) v_u_101
			v_u_101(p225, true)
		end,
		["windup"] = function(p226, p227, p228) -- name: windup
			-- upvalues: (copy) p_u_95, (copy) v_u_201, (copy) v_u_186, (copy) v_u_224, (ref) v_u_73, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_39
			local v229 = p226.size
			local v230 = p226.ability.radius * v229
			local v231 = p_u_95.ground(p227, 0.1)
			local v232 = math.max(p228, 0.12) * 0.9
			local v233 = v_u_201(p226, v231)
			v_u_186[p226] = {
				["parts"] = v_u_224(p226, v233, v232),
				["arms"] = v233
			}
			for _, v234 in { v230 * 1.7, v230 * 1.05 } do
				v_u_73(v231 + Vector3.new(0, 0.02, 0), true, v_u_7.Glow, v_u_10, v230 * 0.3, v234, 0, v232, 1.3, 0.8, 0)
			end
			v_u_73(v231 + Vector3.new(0, 0.04, 0), true, v_u_7.Glow, v_u_8, v230 * 0.2, v230 * 0.9, 0.35, v232, 0.3, 0.4, 0.5)
			if not p226.lite then
				v_u_39(v231 + Vector3.new(0, 1, 0), 8, 10 * v229, 0.35 * v229, 0.5)
			end
		end,
		["land"] = function(p235, p236) -- name: burstOut
			-- upvalues: (copy) p_u_95, (copy) v_u_186, (copy) v_u_201, (copy) v_u_224, (ref) v_u_3, (ref) v_u_1, (ref) v_u_30, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_13, (ref) v_u_12, (ref) v_u_10, (ref) v_u_23, (ref) v_u_73, (ref) v_u_9, (ref) v_u_39, (ref) v_u_6
			local v_u_237 = p235.size
			local v_u_238 = p235.lite
			local v239 = p235.ability.radius * v_u_237
			local v240 = p_u_95.ground(p236, 0.1)
			local v_u_241 = v_u_186[p235]
			if not v_u_241 then
				local v242 = v_u_201(p235, v240)
				v_u_241 = {
					["parts"] = v_u_224(p235, v242, 0.08),
					["arms"] = v242
				}
			end
			v_u_186[p235] = nil
			for _, v243 in v_u_241.arms do
				local v244 = #v243 - 1
				for v245 = 2, v244 + 1 do
					local v_u_246 = (v245 - 1) / v244
					local v_u_247 = v243[v245]
					p_u_95.after((v245 - 2) * 0.035, function()
						-- upvalues: (copy) v_u_247, (copy) v_u_238, (copy) v_u_246, (copy) v_u_237, (ref) v_u_3, (ref) v_u_1, (ref) v_u_30
						local v248 = v_u_247
						local v249 = v_u_238 and 1 or 3
						local v250 = (13 - v_u_246 * 6) * v_u_237
						local v251 = (11 - v_u_246 * 5) * v_u_237
						local v252 = Instance.new("Attachment")
						v252.WorldPosition = v248
						v252.Parent = v_u_3.Terrain
						v_u_1:AddItem(v252, 1.16)
						local v253 = v_u_30(v250, 0.6, v251, 14)
						v253.Parent = v252
						v253:Emit(v249)
					end)
				end
				local v254 = v243[1]
				local v255 = v243[#v243]
				local v256 = v_u_4.part
				local v257 = 1.4 * v_u_237
				local v258 = (v255 - v254).Magnitude
				local v259 = math.max(v258, 0.5)
				local v260 = v256(Vector3.new(v257, 0.2, v259), CFrame.lookAt((v254 + v255) / 2, v255), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v260, 2.6)
				local v_u_261 = v_u_30(6.5 * v_u_237, 0.6, 7 * v_u_237, 12)
				v_u_261.Shape = Enum.ParticleEmitterShape.Box
				v_u_261.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
				v_u_261.Rate = v_u_238 and 6 or 16
				v_u_261.Enabled = true
				v_u_261.Parent = v260
				task.delay(1.05, function()
					-- upvalues: (copy) v_u_261
					v_u_261.Enabled = false
				end)
			end
			local v262 = Instance.new("Attachment")
			v262.WorldPosition = v240
			v262.Parent = v_u_3.Terrain
			v_u_1:AddItem(v262, 3)
			local v_u_263 = v_u_30(9 * v_u_237, 0.6, 48 * v_u_237, 9)
			v_u_263.Speed = NumberRange.new(28 * v_u_237, 48 * v_u_237)
			v_u_263.Drag = 1.6
			v_u_263.Brightness = 1.4
			v_u_263.Rate = v_u_238 and 10 or 34
			v_u_263.Enabled = true
			v_u_263.Parent = v262
			v_u_263:Emit(v_u_238 and 6 or 14)
			task.delay(0.4, function()
				-- upvalues: (copy) v_u_263
				v_u_263.Enabled = false
			end)
			if not v_u_238 then
				local v264 = Instance.new("ParticleEmitter")
				v264.Texture = v_u_7.FxSmoke
				v264.FlipbookLayout = v_u_13
				v264.FlipbookMode = Enum.ParticleFlipbookMode.Random
				v264.Color = ColorSequence.new(v_u_12, v_u_10)
				v264.LightEmission = 0
				v264.LightInfluence = 0
				v264.Size = v_u_23({
					{ 0, 2.5 * v_u_237 },
					{ 1, 6 * v_u_237 }
				})
				v264.Transparency = v_u_23({
					{ 0, 0.15 },
					{ 0.6, 0.35 },
					{ 1, 1 }
				})
				v264.Lifetime = NumberRange.new(1, 1.5)
				v264.Speed = NumberRange.new(12 * v_u_237, 22 * v_u_237)
				v264.EmissionDirection = Enum.NormalId.Top
				v264.SpreadAngle = Vector2.new(18, 18)
				v264.Rotation = NumberRange.new(0, 360)
				v264.RotSpeed = NumberRange.new(-60, 60)
				v264.Drag = 1.8
				v264.Rate = 0
				v264.Enabled = false
				v264.Parent = v262
				v264:Emit(10)
			end
			v_u_73(v240 + Vector3.new(0, 0.1, 0), true, v_u_7.HollowRing, v_u_8, v239 * 0.4, v239 * 2.5, 0, 0.6, 0, 0.05, 0.3, true)
			v_u_73(v240 + Vector3.new(0, 5, 0) * v_u_237, false, v_u_7.HollowRing, v_u_8, 6 * v_u_237, 24 * v_u_237, 0, 0.45, 0, 0.05, 0.3, true)
			p_u_95.chunks(v240, { v_u_10, v_u_9, v_u_8 }, v_u_238 and 4 or 10, 45 * v_u_237, 1.3 * v_u_237, 1.3, false, 1.1)
			v_u_39(v240 + Vector3.new(0, 2, 0), v_u_238 and 8 or 30, 40 * v_u_237, 0.5 * v_u_237, 1.4)
			v_u_6.play("Explosion", {
				["at"] = v240,
				["volume"] = p235.mine and 1 or 0.55
			})
			if p235.mine then
				v_u_4.shake(0.5, 0.45)
			end
			p_u_95.after(1.05, function()
				-- upvalues: (copy) v_u_241, (ref) v_u_4, (ref) v_u_10, (ref) v_u_1
				for _, v265 in v_u_241.parts do
					if not v265.Parent then
						continue
					end
					local v266 = {
						["Color"] = nil,
						["Transparency"] = 1,
						["Color"] = v_u_10
					}
					v_u_4.tween(v265, 0.7, v266, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v265, 0.75)
				end
			end)
		end,
		["hit"] = function(p267, p268, _) -- name: hit
			-- upvalues: (ref) v_u_3, (ref) v_u_1, (ref) v_u_30, (ref) v_u_39
			local v269 = p268 - Vector3.new(0, 1.5, 0)
			local v270 = p267.lite and 1 or 2
			local v271 = Instance.new("Attachment")
			v271.WorldPosition = v269
			v271.Parent = v_u_3.Terrain
			v_u_1:AddItem(v271, 0.9199999999999999)
			local v272 = v_u_30(4, 0.45, 4, 15)
			v272.Parent = v271
			v272:Emit(v270)
			if not p267.lite then
				v_u_39(p268, 4, 12, 0.3, 0.5)
			end
		end
	}
	return v96
end