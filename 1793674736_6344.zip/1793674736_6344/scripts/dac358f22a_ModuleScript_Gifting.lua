local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("UserInputService")
game:GetService("Workspace")
local v_u_6 = require(v_u_2.Shared.Config.Market)
local v_u_7 = require(v_u_2.Shared.Config.Release)
local v_u_8 = require(v_u_2.Shared.Config.Products)
local v_u_9 = require(v_u_2.Shared.Logic.GiftMode)
local v_u_10 = require(script.Parent.Gamepad)
local v_u_11 = require(script.Parent.LimitedCards)
local v_u_12 = require(script.Parent.Sfx)
local v_u_13 = require(script.Parent.State)
local v_u_14 = require(script.Parent.Store)
local v_u_15 = {}
local v_u_16 = v_u_1.LocalPlayer
local function v_u_17(_) end
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = false
local v_u_27 = nil
local v_u_28 = {}
local v_u_29 = false
local function v_u_30(_) end
local function v_u_31() end
function v_u_15.can(p32) -- name: can
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_14, (copy) v_u_13, (copy) v_u_11
	local v33 = v_u_6.UPDATE_ITEMS[p32]
	local v34 = v_u_9.can
	local v35 = {
		["exists"] = v_u_8.passByKey[p32] ~= nil and true or v_u_8.productByKey[p32] ~= nil,
		["never"] = v_u_6.NOT_GIFTABLE[p32] == true
	}
	local v36
	if v33 == nil then
		v36 = false
	else
		v36 = not v_u_7.on(v33)
	end
	v35.held = v36
	local v37
	if v_u_8.productByKey[p32] == nil then
		v37 = false
	else
		v37 = v_u_14.randomBlocked("product", p32)
	end
	v35.randomBlocked = v37
	local v38 = v_u_13.string("GiftCredits", "{}")
	local v39 = string.match(v38, (("\"%*\":(%%d+)"):format(p32))) or ""
	v35.credits = tonumber(v39) or 0
	v35.giftId = v_u_6.GIFT_IDS[p32] or 0
	local v40 = v_u_11.active(p32) ~= nil and v_u_11.known()
	if v40 then
		v40 = v_u_11.left(p32) == 0
	end
	v35.soldOut = v40
	v35.retired = v_u_8.RETIRED[p32] == true
	return v34(v35)
end
local v_u_41 = {}
local v_u_42 = nil
local v_u_43 = nil
local function v_u_47() -- name: close
	-- upvalues: (ref) v_u_20, (ref) v_u_42, (ref) v_u_25, (ref) v_u_29, (copy) v_u_10, (ref) v_u_27, (ref) v_u_43
	local v44 = v_u_20
	if v44 then
		v44.Visible = false
	end
	if v_u_42 then
		v_u_42.Visible = false
	end
	v_u_25 = nil
	v_u_29 = false
	v_u_10.capture("Gifting", false)
	local v45 = v_u_27
	v_u_27 = nil
	if v45 then
		v45()
	end
	local v46 = v_u_43
	v_u_43 = nil
	if v46 and (v46.Parent and v_u_10.shown(v46)) then
		v_u_10.select(v46)
	end
end
local function v_u_59(p_u_48, p_u_49, p_u_50) -- name: send
	-- upvalues: (ref) v_u_18, (ref) v_u_26, (copy) v_u_13, (ref) v_u_17, (copy) v_u_14, (copy) v_u_8
	local v_u_51 = v_u_18
	if v_u_51 and not v_u_26 then
		local v52 = v_u_13.string("GiftCredits", "{}")
		local v53 = string.match(v52, (("\"%*\":(%%d+)"):format(p_u_48))) or ""
		if (tonumber(v53) or 0) > 0 then
			v_u_26 = true
			local v54, v55 = v_u_51:InvokeServer("credit", p_u_48, p_u_49.UserId)
			v_u_26 = false
			if v54 == true then
				p_u_50()
			elseif type(v55) == "string" then
				v_u_17(v55)
			end
		else
			v_u_14.oddsFirst(v_u_8.passByKey[p_u_48] and "pass" or "product", p_u_48, function()
				-- upvalues: (ref) v_u_26, (copy) v_u_51, (copy) p_u_48, (copy) p_u_49, (copy) p_u_50, (ref) v_u_14, (ref) v_u_17
				v_u_26 = true
				local v56, v57, v58 = v_u_51:InvokeServer("gift", p_u_48, p_u_49.UserId)
				v_u_26 = false
				if v56 == true and type(v58) == "number" then
					p_u_50()
					v_u_14.promptProduct(v58)
				elseif type(v57) == "string" then
					v_u_17(v57)
				end
			end)
			return
		end
	else
		return
	end
end
local function v_u_63(p60, p61) -- name: matches
	if p61 == "" then
		return true
	end
	local v62 = string.lower(p61)
	return string.find(string.lower(p60.DisplayName), v62, 1, true) ~= nil and true or string.find(string.lower(p60.Name), v62, 1, true) ~= nil
end
local function v_u_90() -- name: fill
	-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_20, (ref) v_u_23, (copy) v_u_1, (copy) v_u_16, (copy) v_u_3, (copy) v_u_63, (ref) v_u_29, (ref) v_u_43, (copy) v_u_47, (ref) v_u_30, (ref) v_u_25, (copy) v_u_59
	local v64 = v_u_21
	local v65 = v_u_22
	local v66 = v_u_20
	if v64 and (v65 and (v66 and v66.Visible)) then
		for _, v67 in v64:GetChildren() do
			if v67.Name ~= "Row" then
				continue
			end
			v67:Destroy()
		end
		local v68 = not v_u_23 and "" or v_u_23.Text
		local v69 = {}
		for _, v70 in v_u_1:GetPlayers() do
			local v71 = v70 == v_u_16 and v_u_3:IsStudio()
			if v71 then
				v71 = v_u_16:GetAttribute("DevGiftSelf") == true
			end
			if not (v71 and v_u_63(v70, v68)) then
				continue
			end
			table.insert(v69, v70)
		end
		table.sort(v69, function(p72, p73)
			return string.lower(p72.DisplayName) < string.lower(p73.DisplayName)
		end)
		local v74 = v64.Parent
		local v75 = not (v74 and v74:IsA("GuiObject")) and 60 or v74.AbsoluteSize.Y * 0.24
		for v76, v_u_77 in v69 do
			local v78 = v65:Clone()
			v78.Name = "Row"
			v78.Visible = true
			v78.LayoutOrder = v76 + 1
			v78.Size = UDim2.new(0.948, 0, 0, v75)
			local v79 = v78:FindFirstChild("DisplayUser")
			local v80 = v78:FindFirstChild("MainUser")
			if v79 and v79:IsA("TextLabel") then
				v79.Text = v_u_77.DisplayName
			end
			if v80 and v80:IsA("TextLabel") then
				v80.Text = "@" .. v_u_77.Name
			end
			local v_u_81 = v78:FindFirstChild("Icon")
			if v_u_81 and v_u_81:IsA("ImageLabel") then
				v_u_81.Image = ""
				task.spawn(function()
					-- upvalues: (ref) v_u_1, (copy) v_u_77, (copy) v_u_81
					local function v82()
						-- upvalues: (ref) v_u_1, (ref) v_u_77
						return v_u_1:GetUserThumbnailAsync(v_u_77.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
					end
					local v83, v84 = pcall(v82)
					if v83 and v_u_81.Parent then
						v_u_81.Image = v84
					end
				end)
			end
			local v85 = v78:FindFirstChild("Confirm")
			if v85 and v85:IsA("GuiButton") then
				v85:SetAttribute("Pad", true)
				v85.Activated:Connect(function()
					-- upvalues: (copy) v_u_77, (ref) v_u_29, (ref) v_u_43, (ref) v_u_47, (ref) v_u_30, (ref) v_u_25, (ref) v_u_59
					local v86 = v_u_77
					if v_u_29 then
						v_u_43 = nil
						v_u_47()
						v_u_30(v86)
					else
						local v87 = v_u_25
						if v87 then
							v_u_59(v87, v86, v_u_47)
						end
					end
				end)
			end
			v78.Parent = v64
		end
		local v88 = v64:FindFirstChild("Empty")
		if v88 and v88:IsA("TextLabel") then
			v88.Visible = #v69 == 0
			v88.Text = v68 == "" and "No one else is in this server yet" or "No player by that name here"
		end
		local v89 = v64:FindFirstChildWhichIsA("UIListLayout")
		if v74 and (v74:IsA("ScrollingFrame") and v89) then
			v74.CanvasSize = UDim2.fromOffset(0, v89.AbsoluteContentSize.Y + 12)
		end
	end
end
local function v_u_120() -- name: build
	-- upvalues: (ref) v_u_20, (ref) v_u_19, (copy) v_u_16, (copy) v_u_47, (ref) v_u_42, (ref) v_u_24, (ref) v_u_21, (ref) v_u_22, (copy) v_u_90, (copy) v_u_10, (ref) v_u_23, (copy) v_u_1, (copy) v_u_3, (copy) v_u_63, (ref) v_u_17, (ref) v_u_29, (ref) v_u_43, (ref) v_u_30, (ref) v_u_25, (copy) v_u_59, (copy) v_u_28
	if v_u_20 then
		return v_u_20
	end
	local v91 = v_u_19
	if v91 then
		v91 = v_u_19:FindFirstChild("Gifting")
	end
	local v92 = v_u_16:WaitForChild("PlayerGui"):FindFirstChild("Main")
	if not (v91 and (v91:IsA("Frame") and v92)) then
		return nil
	end
	local v_u_93 = v91:Clone()
	v_u_93.Name = "GiftPicker"
	v_u_93.Visible = false
	v_u_93.ZIndex = 40
	v_u_93.BackgroundTransparency = 0
	for v94 in v_u_93:GetAttributes() do
		v_u_93:SetAttribute(v94, nil)
	end
	local v95 = Instance.new("TextButton")
	v95.Name = "GiftPickerDim"
	v95.Text = ""
	v95.AutoButtonColor = false
	v95.BackgroundColor3 = Color3.new(0, 0, 0)
	v95.BackgroundTransparency = 0.35
	v95.BorderSizePixel = 0
	v95.Size = UDim2.fromScale(1, 1)
	v95.ZIndex = 39
	v95.Visible = false
	v95:SetAttribute("Pad", false)
	v95.Selectable = false
	v95.Activated:Connect(v_u_47)
	v95.Parent = v92
	v_u_42 = v95
	local v96 = Instance.new("UIScale")
	v96.Name = "Pop"
	v96.Parent = v_u_93
	local v_u_97 = v_u_93:FindFirstChild("Main")
	local v98
	if v_u_97 then
		v98 = v_u_97:FindFirstChild("Holder")
	else
		v98 = v_u_97
	end
	local v99
	if v98 then
		v99 = v98:FindFirstChild("Template")
	else
		v99 = v98
	end
	if not (v_u_97 and (v_u_97:IsA("ScrollingFrame") and (v98 and v98:IsA("Frame")))) then
		return nil
	end
	if not (v99 and v99:IsA("Frame")) then
		return nil
	end
	v_u_97.AutomaticCanvasSize = Enum.AutomaticSize.None
	v_u_97.ScrollingDirection = Enum.ScrollingDirection.Y
	v98.Size = UDim2.fromScale(1, 1)
	v98.AutomaticSize = Enum.AutomaticSize.Y
	v99.Visible = false
	v99.Parent = nil
	local v100 = v98:FindFirstChild("HeadngText")
	if v100 and v100:IsA("TextLabel") then
		v100.LayoutOrder = 0
		v100.Size = UDim2.new(0.95, 0, 0, 30)
		v100.AutomaticSize = Enum.AutomaticSize.None
		v_u_24 = v100
	end
	local v_u_101 = v98:FindFirstChildWhichIsA("UIListLayout")
	if v_u_101 then
		v_u_101.SortOrder = Enum.SortOrder.LayoutOrder
		v_u_101.Padding = UDim.new(0, 6)
		v_u_101:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function()
			-- upvalues: (copy) v_u_97, (copy) v_u_101
			v_u_97.CanvasSize = UDim2.fromOffset(0, v_u_101.AbsoluteContentSize.Y + 12)
		end)
	end
	local v102 = Instance.new("TextLabel")
	v102.Name = "Empty"
	v102.BackgroundTransparency = 1
	v102.LayoutOrder = 1
	v102.Size = UDim2.new(0.9, 0, 0, 40)
	v102.TextScaled = true
	v102.TextColor3 = Color3.new(1, 1, 1)
	v102.Visible = false
	if v100 and v100:IsA("TextLabel") then
		v102.FontFace = v100.FontFace
	end
	local v103 = Instance.new("UIStroke")
	v103.Thickness = 2
	v103.Parent = v102
	v102.Parent = v98
	v_u_21 = v98
	v_u_22 = v99
	local v104 = v_u_93:FindFirstChild("UserSearch")
	if v104 and v104:IsA("TextBox") then
		v104.PlaceholderText = "Search a player..."
		v104.Text = ""
		v104.ClearTextOnFocus = false
		v104:GetPropertyChangedSignal("Text"):Connect(v_u_90)
		v104.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_10, (copy) v_u_93, (ref) v_u_21
			v_u_10.selectSoon(function()
				-- upvalues: (ref) v_u_93, (ref) v_u_21, (ref) v_u_10
				if v_u_93.Visible and v_u_21 then
					return v_u_10.first(v_u_21)
				else
					return nil
				end
			end)
		end)
		v_u_23 = v104
	end
	local v105 = v_u_93:FindFirstChild("Confirm")
	if v105 and v105:IsA("GuiButton") then
		v105:SetAttribute("Pad", true)
		v105.Activated:Connect(function()
			-- upvalues: (ref) v_u_23, (ref) v_u_1, (ref) v_u_16, (ref) v_u_3, (ref) v_u_63, (ref) v_u_17, (ref) v_u_29, (ref) v_u_43, (ref) v_u_47, (ref) v_u_30, (ref) v_u_25, (ref) v_u_59
			local v106 = not v_u_23 and "" or v_u_23.Text
			local v107 = {}
			for _, v108 in v_u_1:GetPlayers() do
				local v109 = v108 == v_u_16 and v_u_3:IsStudio()
				if v109 then
					v109 = v_u_16:GetAttribute("DevGiftSelf") == true
				end
				if not (v109 and v_u_63(v108, v106)) then
					continue
				end
				table.insert(v107, v108)
			end
			table.sort(v107, function(p110, p111)
				return string.lower(p110.DisplayName) < string.lower(p111.DisplayName)
			end)
			if #v107 == 0 then
				v_u_17("No player by that name here")
				return
			elseif v106 == "" and #v107 > 1 then
				v_u_17("Type a name, or pick a player below")
				return
			else
				local v112 = v107[1]
				if v_u_29 then
					v_u_43 = nil
					v_u_47()
					v_u_30(v112)
				else
					local v113 = v_u_25
					if v113 then
						v_u_59(v113, v112, v_u_47)
					end
				end
			end
		end)
	end
	local v114 = v_u_93:FindFirstChild("Top")
	if v114 then
		for _, v115 in v114:GetChildren() do
			if not v115:IsA("TextLabel") or v115.Name ~= "MainTitle" then
				continue
			end
			local v116 = v_u_28
			local v117 = {
				["label"] = v115,
				["text"] = v115.Text,
				["pos"] = v115.Position,
				["size"] = v115.Size
			}
			table.insert(v116, v117)
		end
	end
	if v114 then
		v114 = v114:FindFirstChild("Close")
	end
	if v114 and v114:IsA("GuiButton") then
		v114:SetAttribute("Ui-Close", nil)
		v114.Activated:Connect(v_u_47)
		v_u_10.hint(v114, Enum.KeyCode.ButtonB)
	end
	v_u_93.Parent = v92
	v_u_10.root(v_u_93)
	v_u_20 = v_u_93
	v_u_10.onEnter(function()
		-- upvalues: (copy) v_u_93, (ref) v_u_10, (ref) v_u_21
		if not v_u_93.Visible then
			return false
		end
		local v118 = v_u_10.select
		local v119
		if v_u_21 then
			v119 = v_u_10.first(v_u_21)
		else
			v119 = nil
		end
		v118(v119 or v_u_10.first(v_u_93))
		return v_u_10.selected() ~= nil
	end, 20)
	v_u_1.PlayerAdded:Connect(v_u_90)
	v_u_1.PlayerRemoving:Connect(function()
		-- upvalues: (ref) v_u_90
		task.defer(v_u_90)
	end)
	return v_u_93
end
local function v_u_127(p121) -- name: titleFor
	-- upvalues: (copy) v_u_28
	for _, v122 in v_u_28 do
		v122.label.Text = p121 and "Players In Server" or v122.text
		local v123 = v122.label
		local v124
		if p121 then
			v124 = UDim2.fromScale(0.6, v122.size.Y.Scale)
		else
			v124 = v122.size
		end
		v123.Size = v124
		local v125 = v122.label
		local v126
		if p121 then
			v126 = UDim2.fromScale(0.5, v122.pos.Y.Scale)
		else
			v126 = v122.pos
		end
		v125.Position = v126
	end
end
local function v_u_132(p_u_128) -- name: showPicker
	-- upvalues: (ref) v_u_23, (ref) v_u_42, (copy) v_u_12, (copy) v_u_4, (copy) v_u_90, (copy) v_u_10, (ref) v_u_43, (ref) v_u_27, (copy) v_u_47, (ref) v_u_21
	if v_u_23 then
		v_u_23.Text = ""
	end
	p_u_128.Visible = true
	if v_u_42 then
		v_u_42.Visible = true
	end
	v_u_12.play("Open")
	local v129 = p_u_128:FindFirstChild("Pop")
	if v129 and v129:IsA("UIScale") then
		v129.Scale = 0.75
		v_u_4:Create(v129, TweenInfo.new(0.25, Enum.EasingStyle.Back), {
			["Scale"] = 1
		}):Play()
	end
	task.defer(v_u_90)
	local v130 = v_u_10.selected()
	if v130 and not v130:IsDescendantOf(p_u_128) then
		v_u_43 = v130
	end
	v_u_10.capture("Gifting", true)
	if v_u_27 then
		v_u_27()
	end
	v_u_27 = v_u_10.onBack(function()
		-- upvalues: (copy) p_u_128, (ref) v_u_47
		if not p_u_128.Visible then
			return false
		end
		v_u_47()
		return true
	end, 50)
	v_u_10.selectSoon(function()
		-- upvalues: (ref) v_u_21, (copy) p_u_128, (ref) v_u_10
		local v131 = v_u_21
		if p_u_128.Visible and v131 then
			return v_u_10.first(v131) or v_u_10.first(p_u_128)
		else
			return nil
		end
	end)
end
function v_u_15.open(p_u_133) -- name: open
	-- upvalues: (copy) v_u_15, (ref) v_u_17, (copy) v_u_120, (ref) v_u_25, (ref) v_u_29, (copy) v_u_127, (copy) v_u_8, (copy) v_u_13, (ref) v_u_24, (copy) v_u_14, (copy) v_u_41, (copy) v_u_6, (copy) v_u_132
	if v_u_15.can(p_u_133) then
		local v134 = v_u_120()
		if v134 then
			v_u_25 = p_u_133
			v_u_29 = false
			v_u_127(false)
			local v135 = string.upper
			local v136 = v_u_8.passByKey[p_u_133]
			local v137
			if v136 then
				v137 = v136.name
			else
				local v138 = v_u_8.productByKey[p_u_133]
				if v138 then
					v137 = v138.name
				else
					v137 = p_u_133
				end
			end
			local v_u_139 = v135(v137)
			local v140 = v_u_13.string("GiftCredits", "{}")
			local v141 = string.match(v140, (("\"%*\":(%%d+)"):format(p_u_133))) or ""
			local v_u_142 = (tonumber(v141) or 0) > 0
			if v_u_24 then
				local v143 = v_u_24
				local v144
				if v_u_142 then
					v144 = ("- SEND YOUR FREE %* TO -"):format(v_u_139)
				else
					local v145 = "- GIFT %* (%*) TO -"
					local v146 = v_u_14.priceText
					local v147 = v_u_41[p_u_133]
					if not v147 then
						local v148 = v_u_8.passByKey[p_u_133]
						local v149 = v_u_8.productByKey[p_u_133]
						if v148 then
							v147 = v148.price
						else
							v147 = not v149 and 0 or v149.price
						end
					end
					v144 = v145:format(v_u_139, (v146(v147)))
				end
				v143.Text = v144
			end
			task.spawn(function()
				-- upvalues: (copy) p_u_133, (ref) v_u_6, (ref) v_u_41, (ref) v_u_14, (ref) v_u_25, (ref) v_u_24, (copy) v_u_142, (copy) v_u_139, (ref) v_u_8
				local v150 = p_u_133
				local v151 = v_u_6.GIFT_IDS[v150] or 0
				local v152 = v151 ~= 0 and (not v_u_41[v150] and v_u_14.livePrice(v151, Enum.InfoType.Product))
				if v152 then
					v_u_41[v150] = v152
				end
				if v_u_25 == p_u_133 and v_u_24 then
					local v153 = v_u_24
					local v154
					if v_u_142 then
						v154 = ("- SEND YOUR FREE %* TO -"):format(v_u_139)
					else
						local v155 = "- GIFT %* (%*) TO -"
						local v156 = v_u_139
						local v157 = v_u_14.priceText
						local v158 = p_u_133
						local v159 = v_u_41[v158]
						if not v159 then
							local v160 = v_u_8.passByKey[v158]
							local v161 = v_u_8.productByKey[v158]
							if v160 then
								v159 = v160.price
							else
								v159 = not v161 and 0 or v161.price
							end
						end
						v154 = v155:format(v156, (v157(v159)))
					end
					v153.Text = v154
				end
			end)
			v_u_132(v134)
		else
			v_u_17("Gifting is not available right now")
		end
	else
		v_u_17("This can\'t be gifted right now")
		return
	end
end
function v_u_15.openPlayers() -- name: openPlayers
	-- upvalues: (copy) v_u_120, (ref) v_u_17, (ref) v_u_25, (ref) v_u_29, (copy) v_u_127, (ref) v_u_24, (copy) v_u_132
	local v162 = v_u_120()
	if v162 then
		v_u_25 = nil
		v_u_29 = true
		v_u_127(true)
		if v_u_24 then
			v_u_24.Text = "- WHO IS THE GIFT FOR? -"
		end
		v_u_132(v162)
	else
		v_u_17("Gifting is not available right now")
	end
end
local function v_u_165(p163) -- name: layoutFor
	local v164 = string.match(p163.Name, "^(%a+)_") or ""
	if v164 == "Pass" then
		return nil, {
			["pos"] = UDim2.fromScale(0.804, 0.851),
			["size"] = UDim2.fromScale(0.196, 0.156)
		}
	elseif v164 == "Train" then
		return {
			["pos"] = UDim2.fromScale(0.369, 0.86),
			["size"] = UDim2.fromScale(0.559, 0.16)
		}, {
			["pos"] = UDim2.fromScale(0.804, 0.86),
			["size"] = UDim2.fromScale(0.196, 0.156)
		}
	elseif v164 == "Product" then
		return {
			["pos"] = UDim2.fromScale(0.655, 0.787),
			["size"] = UDim2.fromScale(0.278, 0.284)
		}, {
			["pos"] = UDim2.fromScale(0.893, 0.787),
			["size"] = UDim2.fromScale(0.147, 0.284)
		}
	else
		return nil, {
			["pos"] = UDim2.fromScale(0.86, 0.405),
			["size"] = UDim2.fromScale(0.235, 0.17)
		}
	end
end
local v_u_166 = {}
local function v_u_177(p167, p168, p169) -- name: giftButton
	-- upvalues: (ref) v_u_19
	local v170 = v_u_19
	if v170 then
		v170 = v_u_19:FindFirstChild("Gift")
	end
	if not (v170 and v170:IsA("GuiButton")) then
		return nil
	end
	local v171 = v170:Clone()
	v171.Name = "GiftButton"
	v171.AnchorPoint = Vector2.new(0.5, 0.5)
	for v172 in v171:GetAttributes() do
		if string.sub(v172, 1, 7) ~= "Ui-Gift" then
			continue
		end
		v171:SetAttribute(v172, nil)
	end
	v171:SetAttribute("Pad", true)
	v171.ZIndex = p169
	local v173 = v171:FindFirstChild("ImageLabel")
	if v173 and v173:IsA("ImageLabel") then
		local v174 = Instance.new("UIAspectRatioConstraint")
		v174.AspectRatio = 1
		v174.Parent = v173
		if p167 then
			v173.AnchorPoint = Vector2.new(0.5, 0.5)
			v173.Position = UDim2.fromScale(0.27, 0.5)
			v173.Size = UDim2.fromScale(0.3, 0.86)
			local v175 = Instance.new("TextLabel")
			v175.Name = "Word"
			v175.BackgroundTransparency = 1
			v175.AnchorPoint = Vector2.new(0.5, 0.5)
			v175.Position = UDim2.fromScale(0.6, 0.5)
			v175.Size = UDim2.fromScale(0.5, 0.78)
			v175.Text = "GIFT"
			v175.TextScaled = true
			v175.TextColor3 = Color3.new(1, 1, 1)
			v175.ZIndex = v173.ZIndex
			if p168 then
				v175.FontFace = p168
			end
			local v176 = Instance.new("UIStroke")
			v176.Thickness = 2
			v176.Parent = v175
			v175.Parent = v171
		end
	end
	return v171
end
local function v_u_207(p178, p_u_179, p_u_180) -- name: addGift
	-- upvalues: (copy) v_u_165, (copy) v_u_177, (copy) v_u_15, (copy) v_u_166
	if p178:FindFirstChild("GiftButton") then
		return
	else
		local v_u_181, v182 = v_u_165(p178)
		local v183 = p178:FindFirstChild("Title")
		local v184
		if v182.size.X.Scale > 0.2 then
			v184 = v182.size.Y.Scale < 0.2
		else
			v184 = false
		end
		local v185 = v_u_177
		local v186
		if v183 and v183:IsA("TextLabel") then
			v186 = v183.FontFace
		else
			v186 = nil
		end
		local v_u_187 = v185(v184, v186, p_u_179.ZIndex)
		if v_u_187 then
			v_u_187.Position = v182.pos
			v_u_187.Size = v182.size
			local v_u_188 = p178:FindFirstChild("Owned")
			local v_u_189 = {
				["pos"] = p_u_179.Position,
				["size"] = p_u_179.Size
			}
			local function v200() -- name: refresh
				-- upvalues: (ref) v_u_15, (copy) p_u_180, (copy) v_u_187, (copy) v_u_181, (copy) v_u_189, (copy) p_u_179, (copy) v_u_188
				local v190 = v_u_15.can(p_u_180)
				v_u_187.Visible = v190
				local v191
				if v190 and v_u_181 then
					v191 = v_u_181
				else
					v191 = v_u_189
				end
				local v192 = p_u_179
				local v193 = p_u_179
				local v194 = v191.pos
				local v195 = v191.size
				v192.Position = v194
				v193.Size = v195
				if v_u_188 and v_u_188:IsA("GuiObject") then
					local v196 = v_u_188
					local v197 = v_u_188
					local v198 = v191.pos
					local v199 = v191.size
					v196.Position = v198
					v197.Size = v199
				end
			end
			v_u_187.Activated:Connect(function()
				-- upvalues: (ref) v_u_15, (copy) p_u_180
				v_u_15.open(p_u_180)
			end)
			v_u_187.Parent = p178
			local v201 = v_u_166
			table.insert(v201, v200)
			local v202 = v_u_15.can(p_u_180)
			v_u_187.Visible = v202
			if v202 then
				v_u_189 = v_u_181 or v_u_189
			end
			local v203 = v_u_189.pos
			local v204 = v_u_189.size
			p_u_179.Position = v203
			p_u_179.Size = v204
			if v_u_188 and v_u_188:IsA("GuiObject") then
				local v205 = v_u_189.pos
				local v206 = v_u_189.size
				v_u_188.Position = v205
				v_u_188.Size = v206
			end
		end
	end
end
local function v_u_209() -- name: refreshAll
	-- upvalues: (copy) v_u_166, (ref) v_u_31
	for _, v208 in v_u_166 do
		v208()
	end
	v_u_31()
end
local v_u_210 = nil
local v_u_211 = nil
function v_u_15.eggButton(p212, p213) -- name: eggButton
	-- upvalues: (ref) v_u_211, (ref) v_u_210, (copy) v_u_177, (copy) v_u_15
	v_u_211 = p213
	local v214 = v_u_210
	if not v214 or v214.Parent ~= p212 then
		local v215 = p212:FindFirstChild("Cost")
		local v216 = v_u_177
		local v217 = true
		local v218
		if v215 and v215:IsA("TextLabel") then
			v218 = v215.FontFace
		else
			v218 = nil
		end
		v214 = v216(v217, v218, 6)
		if not v214 then
			return
		end
		v214.Position = UDim2.fromScale(0.8, 0.74)
		v214.Size = UDim2.fromScale(0.22, 0.1)
		v214.Activated:Connect(function()
			-- upvalues: (ref) v_u_211, (ref) v_u_15
			local v219 = v_u_211
			if v219 then
				v_u_15.open(v219)
			end
		end)
		v214.Parent = p212
		v_u_210 = v214
	end
	if v214 then
		local v220
		if p213 == nil then
			v220 = false
		else
			v220 = v_u_15.can(p213)
		end
		v214.Visible = v220
	end
end
function v_u_15.beside(p221, p_u_222) -- name: beside
	-- upvalues: (copy) v_u_15, (copy) v_u_177
	if p221:FindFirstChild("GiftButton") or not v_u_15.can(p_u_222) then
		return
	else
		local v223 = v_u_177(false, nil, p221.ZIndex + 1)
		if v223 then
			v223.AnchorPoint = Vector2.new(1, 0.5)
			v223.Position = UDim2.new(0, -6, 0.5, 0)
			v223.Size = UDim2.fromScale(1, 1)
			local v224 = Instance.new("UIAspectRatioConstraint")
			v224.AspectRatio = 1
			v224.DominantAxis = Enum.DominantAxis.Height
			v224.Parent = v223
			v223.Activated:Connect(function()
				-- upvalues: (ref) v_u_15, (copy) p_u_222
				v_u_15.open(p_u_222)
			end)
			v223.Parent = p221
		end
	end
end
local function v_u_229(p225) -- name: scan
	-- upvalues: (copy) v_u_207
	if false then
		for _, v226 in p225:GetDescendants() do
			if not v226:IsA("GuiButton") or v226.Name == "GiftButton" then
				continue
			end
			local v227 = v226:GetAttribute("Ui-Pass") or v226:GetAttribute("Ui-Product")
			local v228 = v226.Parent
			if type(v227) ~= "string" or (not v228 or (not v228:IsA("GuiObject") or v228.Name == "Store")) then
				continue
			end
			v_u_207(v228, v226, v227)
		end
	end
end
local v_u_230 = nil
local v_u_231 = nil
local v_u_232 = nil
local v_u_233 = nil
local v_u_234 = nil
local v_u_235 = nil
local v_u_236 = nil
local v_u_237 = nil
local function v_u_241(p238) -- name: itemOf
	for _, v239 in p238:GetDescendants() do
		if not v239:IsA("GuiButton") or v239.Name == "GiftButton" then
			continue
		end
		local v240 = v239:GetAttribute("Ui-Pass") or v239:GetAttribute("Ui-Product")
		if type(v240) ~= "string" then
			continue
		end
		return v240
	end
	return nil
end
local v_u_242 = {}
local v_u_243 = {}
local function v_u_249() -- name: releaseAll
	-- upvalues: (copy) v_u_242, (copy) v_u_243
	local v244 = {}
	for v245 in v_u_242 do
		table.insert(v244, v245)
	end
	for _, v246 in v244 do
		local v247 = v_u_243[v246]
		if v247 then
			v247:Disconnect()
		end
		v_u_243[v246] = nil
		local v248 = v_u_242[v246]
		v_u_242[v246] = nil
		v246.Visible = v248 == true
	end
end
local function v_u_262() -- name: applyGiftMode
	-- upvalues: (copy) v_u_249, (ref) v_u_231, (ref) v_u_233, (copy) v_u_241, (copy) v_u_15, (copy) v_u_242, (copy) v_u_243, (copy) v_u_9
	v_u_249()
	local v250 = v_u_231
	if v_u_233 and v250 then
		local v251 = {}
		local v252 = {}
		for _, v_u_253 in v250:GetChildren() do
			if not v_u_253:IsA("GuiObject") then
				continue
			end
			if v_u_253:IsA("TextLabel") then
				local v254 = {
					["order"] = nil,
					["title"] = true,
					["shown"] = false,
					["order"] = v_u_253.LayoutOrder
				}
				table.insert(v251, v254)
				v252[#v251] = v_u_253
			else
				local v255 = v_u_241(v_u_253)
				local v256 = v_u_253.Visible
				if v256 then
					if v255 == nil then
						v256 = false
					else
						v256 = v_u_15.can(v255)
					end
				end
				if not v256 and v_u_242[v_u_253] == nil then
					v_u_242[v_u_253] = v_u_253.Visible
					v_u_243[v_u_253] = v_u_253:GetPropertyChangedSignal("Visible"):Connect(function()
						-- upvalues: (copy) v_u_253, (ref) v_u_242
						if v_u_253.Visible then
							v_u_242[v_u_253] = true
							v_u_253.Visible = false
						end
					end)
					v_u_253.Visible = false
				end
				local v_u_257 = v_u_253:FindFirstChild("Owned")
				if v_u_257 and (v_u_257:IsA("GuiObject") and v_u_242[v_u_257] == nil) then
					v_u_242[v_u_257] = v_u_257.Visible
					v_u_243[v_u_257] = v_u_257:GetPropertyChangedSignal("Visible"):Connect(function()
						-- upvalues: (copy) v_u_257, (ref) v_u_242
						if v_u_257.Visible then
							v_u_242[v_u_257] = true
							v_u_257.Visible = false
						end
					end)
					v_u_257.Visible = false
				end
				local v258 = {
					["order"] = nil,
					["title"] = false,
					["shown"] = nil,
					["order"] = v_u_253.LayoutOrder,
					["shown"] = v256
				}
				table.insert(v251, v258)
			end
		end
		local v259 = v_u_9.titles(v251)
		for v260, v_u_261 in v252 do
			if v259[v260] then
				continue
			end
			if v_u_242[v_u_261] ~= nil then
				continue
			end
			v_u_242[v_u_261] = v_u_261.Visible
			v_u_243[v_u_261] = v_u_261:GetPropertyChangedSignal("Visible"):Connect(function()
				-- upvalues: (copy) v_u_261, (ref) v_u_242
				if v_u_261.Visible then
					v_u_242[v_u_261] = true
					v_u_261.Visible = false
				end
			end)
			v_u_261.Visible = false
		end
	end
end
local function v_u_268() -- name: showGiftOpen
	-- upvalues: (ref) v_u_234, (ref) v_u_231, (ref) v_u_233, (copy) v_u_241, (copy) v_u_15
	local v263 = v_u_234
	local v264 = v_u_231
	if v263 and v264 then
		local v265 = false
		if not v_u_233 then
			for _, v266 in v264:GetChildren() do
				local v267
				if v266:IsA("GuiObject") then
					v267 = v_u_241(v266)
				else
					v267 = nil
				end
				if not (v267 and v_u_15.can(v267)) then
					continue
				end
				v265 = true
			end
		end
		v263.Visible = v265
	end
end
local function v_u_273(p269) -- name: leaveGiftMode
	-- upvalues: (ref) v_u_233, (copy) v_u_262, (ref) v_u_235, (ref) v_u_237, (copy) v_u_268, (ref) v_u_17, (ref) v_u_230, (copy) v_u_10, (ref) v_u_234
	if v_u_233 then
		v_u_233 = nil
		v_u_262()
		if v_u_235 then
			v_u_235.Visible = false
		end
		local v270 = v_u_237
		v_u_237 = nil
		if v270 then
			v270()
		end
		v_u_268()
		if p269 then
			v_u_17(p269)
		end
		local v_u_271 = v_u_230
		v_u_10.selectSoon(function()
			-- upvalues: (ref) v_u_234, (copy) v_u_271
			local v272 = v_u_234
			if v_u_271 and (v_u_271.Visible and (v272 and v272.Visible)) then
				return v272
			else
				return nil
			end
		end)
	end
end
v_u_30 = function(p274)
	-- upvalues: (ref) v_u_230, (ref) v_u_235, (copy) v_u_1, (ref) v_u_17, (ref) v_u_233, (copy) v_u_262, (ref) v_u_236, (copy) v_u_9, (copy) v_u_4, (copy) v_u_268, (ref) v_u_232, (copy) v_u_12, (ref) v_u_237, (copy) v_u_10, (ref) v_u_20, (copy) v_u_273, (ref) v_u_231
	local v275 = v_u_230
	local v276 = v_u_235
	if v275 and (v276 and v275.Visible) then
		if p274.Parent == v_u_1 then
			v_u_233 = p274
			v_u_262()
			if v_u_236 then
				v_u_236.Text = v_u_9.label(p274.DisplayName)
			end
			v276.Visible = true
			local v277 = v276:FindFirstChildOfClass("UIScale")
			if v277 then
				v277.Scale = 0.6
				v_u_4:Create(v277, TweenInfo.new(0.3, Enum.EasingStyle.Back), {
					["Scale"] = 1
				}):Play()
			end
			v_u_268()
			if v_u_232 then
				v_u_232.CanvasPosition = Vector2.zero
			end
			v_u_12.play("Open")
			if v_u_237 then
				v_u_237()
			end
			v_u_237 = v_u_10.onBack(function()
				-- upvalues: (ref) v_u_20, (ref) v_u_233, (ref) v_u_273, (ref) v_u_12
				local v278 = v_u_20
				if not v_u_233 or v278 and v278.Visible then
					return false
				end
				v_u_273()
				v_u_12.play("Close")
				return true
			end, 30)
			v_u_10.selectSoon(function()
				-- upvalues: (ref) v_u_231, (ref) v_u_233, (ref) v_u_10
				local v279 = v_u_231
				if v_u_233 and v279 then
					return v_u_10.first(v279)
				else
					return nil
				end
			end)
		else
			v_u_17((("%* left the server"):format(p274.DisplayName)))
		end
	else
		return
	end
end
v_u_31 = function()
	-- upvalues: (ref) v_u_233, (copy) v_u_262, (copy) v_u_268
	if v_u_233 then
		v_u_262()
	end
	v_u_268()
end
local function v_u_281(p280) -- name: recipientLeft
	-- upvalues: (ref) v_u_233, (copy) v_u_273
	if v_u_233 == p280 then
		v_u_273((("%* left the server, gifting stopped"):format(p280.DisplayName)))
	end
end
function v_u_15.storeBuy(p282) -- name: storeBuy
	-- upvalues: (ref) v_u_233, (copy) v_u_1, (copy) v_u_273, (copy) v_u_15, (ref) v_u_17, (copy) v_u_59
	local v283 = v_u_233
	if v283 then
		if v283.Parent == v_u_1 then
			if v_u_15.can(p282) then
				v_u_59(p282, v283, function() end)
				return true
			else
				v_u_17("This can\'t be gifted right now")
				return true
			end
		else
			if v_u_233 == v283 then
				v_u_273((("%* left the server, gifting stopped"):format(v283.DisplayName)))
			end
			return true
		end
	else
		return false
	end
end
function v_u_15.giftMode() -- name: giftMode
	-- upvalues: (ref) v_u_233
	return v_u_233
end
local function v_u_294(p284, p285, p286, p287, p288) -- name: wordButton
	-- upvalues: (copy) v_u_177
	local v289 = v_u_177(false, p286, 6)
	if not v289 then
		return nil
	end
	v289.Name = p284
	local v290 = v289:FindFirstChild("ImageLabel")
	if v290 and v290:IsA("ImageLabel") then
		if p288 then
			v290.AnchorPoint = Vector2.new(0.5, 0.5)
			v290.Position = UDim2.fromScale(0.83, 0.5)
			v290.Size = UDim2.fromScale(0.28, 0.8)
		else
			v290:Destroy()
		end
	end
	if p287 and p287:IsA("UIGradient") then
		local v291 = v289:FindFirstChildOfClass("UIGradient")
		if v291 then
			v291:Destroy()
		end
		p287:Clone().Parent = v289
	end
	local v292 = Instance.new("TextLabel")
	v292.Name = "Word"
	v292.BackgroundTransparency = 1
	v292.AnchorPoint = Vector2.new(0.5, 0.5)
	v292.Position = UDim2.fromScale(p288 and 0.38 or 0.5, 0.5)
	v292.Size = UDim2.fromScale(p288 and 0.56 or 0.84, 0.72)
	v292.Text = p285
	v292.TextScaled = true
	v292.TextColor3 = Color3.new(1, 1, 1)
	v292.FontFace = p286
	v292.ZIndex = 3
	local v293 = Instance.new("UIStroke")
	v293.Thickness = 2.5
	v293.Parent = v292
	v292.Parent = v289
	return v289
end
local function v_u_308(p_u_295, p296) -- name: buildGiftMode
	-- upvalues: (ref) v_u_230, (ref) v_u_231, (ref) v_u_232, (ref) v_u_19, (copy) v_u_294, (copy) v_u_15, (ref) v_u_234, (copy) v_u_5, (copy) v_u_273, (copy) v_u_12, (copy) v_u_10, (ref) v_u_236, (ref) v_u_235, (copy) v_u_1, (copy) v_u_281, (ref) v_u_31, (copy) v_u_268
	v_u_230 = p_u_295
	v_u_231 = p296
	local v297 = p296.Parent
	if v297 and v297:IsA("ScrollingFrame") then
		v_u_232 = v297
	end
	local v298 = p_u_295:FindFirstChild("Top")
	local v299
	if v298 then
		v299 = v298:FindFirstChild("ShopText1")
	else
		v299 = v298
	end
	local v300
	if v299 and v299:IsA("TextLabel") then
		v300 = v299.FontFace
	else
		v300 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
	end
	local v301 = v_u_19
	if v301 then
		v301 = v_u_19:FindFirstChild("Gifting")
	end
	if v301 then
		v301 = v301:FindFirstChild("Confirm")
	end
	if v301 then
		v301 = v301:FindFirstChildOfClass("UIGradient")
	end
	local v302
	if v298 then
		v302 = v298:FindFirstChild("Close")
	else
		v302 = v298
	end
	if v302 then
		v302 = v302:FindFirstChildOfClass("UIGradient")
	end
	local v303 = v_u_294("GiftStore", "GIFT!", v300, v301, true)
	if v298 and v303 then
		v303.AnchorPoint = Vector2.new(0.5, 0.5)
		v303.Position = UDim2.fromScale(0.72, 0.5)
		v303.Size = UDim2.fromScale(0.21, 0.74)
		v303.ZIndex = 5
		v303.Visible = false
		v303.Activated:Connect(function()
			-- upvalues: (ref) v_u_15
			v_u_15.openPlayers()
		end)
		v303.Parent = v298
		v_u_234 = v303
	end
	local v304 = Instance.new("Frame")
	v304.Name = "GiftMode"
	v304.BackgroundTransparency = 1
	v304.AnchorPoint = Vector2.new(1, 0)
	v304.Position = UDim2.new(1, 0, 1, 8)
	v304.Size = UDim2.fromScale(1, v_u_5.TouchEnabled and 0.14 or 0.1)
	v304.Visible = false
	v304.ZIndex = 8
	Instance.new("UIScale").Parent = v304
	local v305 = v_u_294("Cancel", "CANCEL", v300, v302, false)
	if v305 then
		v305.AnchorPoint = Vector2.new(1, 0.5)
		v305.Position = UDim2.fromScale(1, 0.5)
		v305.Size = UDim2.fromScale(0.24, 1)
		v305.ZIndex = 8
		v305.Activated:Connect(function()
			-- upvalues: (ref) v_u_273, (ref) v_u_12
			v_u_273()
			v_u_12.play("Close")
		end)
		v305.Parent = v304
		v_u_10.hint(v305, Enum.KeyCode.ButtonB, 26)
	end
	local v306 = Instance.new("TextLabel")
	v306.Name = "GiftingTo"
	v306.BackgroundTransparency = 1
	v306.AnchorPoint = Vector2.new(1, 0.5)
	v306.Position = UDim2.fromScale(0.74, 0.5)
	v306.Size = UDim2.fromScale(0.72, 0.58)
	v306.TextScaled = true
	v306.TextXAlignment = Enum.TextXAlignment.Right
	v306.TextColor3 = Color3.new(1, 1, 1)
	v306.FontFace = v300
	v306.ZIndex = 8
	local v307 = Instance.new("UIStroke")
	v307.Thickness = 2.5
	v307.Parent = v306
	v306.Parent = v304
	v_u_236 = v306
	v304.Parent = p_u_295
	v_u_235 = v304
	p_u_295:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) p_u_295, (ref) v_u_273
		if not p_u_295.Visible then
			v_u_273()
		end
	end)
	v_u_1.PlayerRemoving:Connect(v_u_281)
	p296.ChildAdded:Connect(function()
		-- upvalues: (ref) v_u_31
		task.defer(v_u_31)
	end)
	v_u_268()
end
local function v_u_313(p309) -- name: pictureOf
	-- upvalues: (copy) v_u_16
	local v310 = v_u_16:WaitForChild("PlayerGui"):FindFirstChild("Main")
	if v310 then
		v310 = v310:FindFirstChild("Frames")
	end
	if v310 then
		v310 = v310:FindFirstChild("Store")
	end
	if v310 then
		v310 = v310:FindFirstChild("Holder", true)
	end
	if v310 then
		for _, v311 in {
			"Deal_",
			"Pass_",
			"Train_",
			"Product_",
			"Pack_"
		} do
			local v312 = v310:FindFirstChild(v311 .. p309)
			if v312 then
				v312 = v312:FindFirstChild("Picture") or v312:FindFirstChild("Icon")
			end
			if not v312 or (not v312:IsA("ImageLabel") or v312.Image == "") then
				continue
			end
			return v312.Image
		end
	end
	return ""
end
local function v_u_338(p314, p315) -- name: popUp
	-- upvalues: (ref) v_u_19, (copy) v_u_16, (ref) v_u_17, (copy) v_u_8, (copy) v_u_313, (copy) v_u_12, (copy) v_u_4
	local v316 = v_u_19
	if v316 then
		v316 = v_u_19:FindFirstChild("Gifting")
	end
	if v316 then
		v316 = v316:FindFirstChild("Top")
	end
	local v317 = v_u_16:WaitForChild("PlayerGui"):FindFirstChild("Main")
	if v316 and (v316:IsA("GuiObject") and v317) then
		local v_u_318 = Instance.new("Frame")
		v_u_318.Name = "GiftPopUp"
		v_u_318.BackgroundTransparency = 1
		v_u_318.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_318.Position = UDim2.fromScale(0.5, 0.4)
		v_u_318.Size = UDim2.fromScale(0.62, 0.34)
		v_u_318.ZIndex = 60
		local v319 = Instance.new("UIAspectRatioConstraint")
		v319.AspectRatio = 2.6
		v319.Parent = v_u_318
		local v_u_320 = Instance.new("UIScale")
		v_u_320.Scale = 0
		v_u_320.Parent = v_u_318
		local v321 = v316:Clone()
		v321.Name = "Banner"
		v321.AnchorPoint = Vector2.new(0.5, 0)
		v321.Position = UDim2.fromScale(0.5, 0)
		v321.Size = UDim2.fromScale(1, 0.34)
		local v322 = v321:FindFirstChild("Close")
		if v322 then
			v322:Destroy()
		end
		for _, v323 in v321:GetChildren() do
			if not v323:IsA("TextLabel") or v323.Name ~= "MainTitle" then
				continue
			end
			local v324 = "%* GIFTED YOU %*!"
			local v325 = string.upper(p314)
			local v326 = string.upper
			local v327 = v_u_8.passByKey[p315]
			local v328
			if v327 then
				v328 = v327.name
			else
				local v329 = v_u_8.productByKey[p315]
				if v329 then
					v328 = v329.name
				else
					v328 = p315
				end
			end
			v323.Text = v324:format(v325, (v326(v328)))
			v323.Size = UDim2.fromScale(0.78, v323.Size.Y.Scale)
			v323.Position = UDim2.fromScale(0.58, v323.Position.Y.Scale)
			v323.TextScaled = true
		end
		v321.Parent = v_u_318
		local v330 = v_u_313(p315)
		if v330 ~= "" then
			local v_u_331 = Instance.new("ImageLabel")
			v_u_331.Name = "Rays"
			v_u_331.BackgroundTransparency = 1
			v_u_331.Image = "rbxassetid://96427887277553"
			v_u_331.ImageColor3 = Color3.fromRGB(255, 240, 170)
			v_u_331.ImageTransparency = 0.2
			v_u_331.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_331.Position = UDim2.fromScale(0.5, 0.69)
			v_u_331.Size = UDim2.fromScale(0.5, 0.5)
			v_u_331.SizeConstraint = Enum.SizeConstraint.RelativeXX
			v_u_331.Parent = v_u_318
			task.spawn(function()
				-- upvalues: (copy) v_u_331
				while v_u_331.Parent do
					v_u_331.Rotation = os.clock() * 40 % 360
					task.wait()
				end
			end)
			local v332 = Instance.new("ImageLabel")
			v332.Name = "Picture"
			v332.BackgroundTransparency = 1
			v332.Image = v330
			v332.ScaleType = Enum.ScaleType.Fit
			v332.AnchorPoint = Vector2.new(0.5, 0)
			v332.Position = UDim2.fromScale(0.5, 0.38)
			v332.Size = UDim2.fromScale(0.6, 0.62)
			v332.Parent = v_u_318
		end
		v_u_318.Parent = v317
		v_u_12.play("RevealBig")
		v_u_4:Create(v_u_320, TweenInfo.new(0.45, Enum.EasingStyle.Back), {
			["Scale"] = 1
		}):Play()
		task.delay(4, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_320, (copy) v_u_318
			v_u_4:Create(v_u_320, TweenInfo.new(0.25, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
				["Scale"] = 0
			}):Play()
			task.wait(0.3)
			v_u_318:Destroy()
		end)
	else
		local v333 = v_u_17
		local v334 = "%* gifted you %*!"
		local v335 = string.upper
		local v336 = v_u_8.passByKey[p315]
		if v336 then
			p315 = v336.name
		else
			local v337 = v_u_8.productByKey[p315]
			if v337 then
				p315 = v337.name
			end
		end
		v333((v334:format(p314, (v335(p315)))))
	end
end
local function v_u_361(p339, p340) -- name: onEvent
	-- upvalues: (copy) v_u_8, (copy) v_u_338, (copy) v_u_16, (ref) v_u_17, (copy) v_u_1, (copy) v_u_12
	if type(p340) ~= "table" then
		return
	end
	local v341 = p340.item
	if type(v341) ~= "string" then
		return
	end
	local v342 = string.upper
	local v343 = v_u_8.passByKey[v341]
	local v344
	if v343 then
		v344 = v343.name
	else
		local v345 = v_u_8.productByKey[v341]
		if v345 then
			v344 = v345.name
		else
			v344 = v341
		end
	end
	local v346 = v342(v344)
	if p339 == "giftedYou" then
		local v347 = p340.from
		if type(v347) == "string" then
			v_u_338(p340.from, v341)
			return
		end
	end
	local v348, v349, v350, v351, v352
	if p339 == "gifted" then
		local v353 = p340.from
		if type(v353) == "string" then
			local v354 = p340.to
			if type(v354) == "string" then
				if p340.to ~= v_u_16.DisplayName and p340.from ~= v_u_16.DisplayName then
					local v355 = v_u_17
					local v356 = "%* gifted %* %*!"
					local v357 = p340.from
					local v358 = p340.to
					local v359 = v_u_8.passByKey[v341]
					if v359 then
						v341 = v359.name
					else
						local v360 = v_u_8.productByKey[v341]
						if v360 then
							v341 = v360.name
						end
					end
					v355((v356:format(v357, v358, v341)))
					return
				end
			else
				if p339 == "giftSent" then
					v348 = p340.to
					if type(v348) == "number" then
						v349 = v_u_1:GetPlayerByUserId(p340.to)
					else
						v349 = nil
					end
					v_u_12.play("Coin")
					v350 = v_u_17
					if v349 then
						v351 = ("Gift sent to %*!"):format(v349.DisplayName)
					else
						v351 = ("%* gift sent! They get it when they next play"):format(v346)
					end
					v350(v351)
					return
				end
				if p339 == "giftCredit" then
					v_u_17((("Your %* gift could not be given: send it for free with GIFT"):format(v346)))
					return
				end
				if p339 == "creditBack" then
					v352 = p340.name
					v_u_17((("%* already had %*: gift it to someone else for free"):format(type(v352) ~= "string" and "They" or p340.name, v346)))
				end
			end
		else
			if p339 == "giftSent" then
				v348 = p340.to
				if type(v348) == "number" then
					v349 = v_u_1:GetPlayerByUserId(p340.to)
				else
					v349 = nil
				end
				v_u_12.play("Coin")
				v350 = v_u_17
				if v349 then
					v351 = ("Gift sent to %*!"):format(v349.DisplayName)
				else
					v351 = ("%* gift sent! They get it when they next play"):format(v346)
				end
				v350(v351)
				return
			end
			if p339 == "giftCredit" then
				v_u_17((("Your %* gift could not be given: send it for free with GIFT"):format(v346)))
				return
			end
			if p339 == "creditBack" then
				v352 = p340.name
				v_u_17((("%* already had %*: gift it to someone else for free"):format(type(v352) ~= "string" and "They" or p340.name, v346)))
			end
			return
		end
	else
		if p339 == "giftSent" then
			v348 = p340.to
			if type(v348) == "number" then
				v349 = v_u_1:GetPlayerByUserId(p340.to)
			else
				v349 = nil
			end
			v_u_12.play("Coin")
			v350 = v_u_17
			if v349 then
				v351 = ("Gift sent to %*!"):format(v349.DisplayName)
			else
				v351 = ("%* gift sent! They get it when they next play"):format(v346)
			end
			v350(v351)
			return
		end
		if p339 == "giftCredit" then
			v_u_17((("Your %* gift could not be given: send it for free with GIFT"):format(v346)))
			return
		end
		if p339 == "creditBack" then
			v352 = p340.name
			v_u_17((("%* already had %*: gift it to someone else for free"):format(type(v352) ~= "string" and "They" or p340.name, v346)))
		end
		return
	end
end
function v_u_15.start(p362) -- name: start
	-- upvalues: (ref) v_u_17, (copy) v_u_2, (ref) v_u_18, (copy) v_u_361, (ref) v_u_19, (copy) v_u_16, (copy) v_u_229, (copy) v_u_308, (copy) v_u_13, (copy) v_u_209, (copy) v_u_11, (copy) v_u_14, (copy) v_u_3, (copy) v_u_15, (ref) v_u_30, (copy) v_u_273, (ref) v_u_233
	v_u_17 = p362
	local v363 = v_u_2:WaitForChild("Remotes")
	local v364 = v363:WaitForChild("MarketAsk", 30)
	if v364 and v364:IsA("RemoteFunction") then
		v_u_18 = v364
	end
	local v365 = v363:WaitForChild("Market", 30)
	if v365 and v365:IsA("RemoteEvent") then
		v365.OnClientEvent:Connect(v_u_361)
	end
	v_u_19 = v_u_2:WaitForChild("MarketUi", 30)
	if v_u_19 then
		local v366 = v_u_16:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
		if v366 then
			v366 = v366:FindFirstChild("Frames")
		end
		if v366 then
			v366 = v366:FindFirstChild("Store")
		end
		local v_u_367
		if v366 then
			v_u_367 = v366:FindFirstChild("Holder", true)
		else
			v_u_367 = v366
		end
		if v_u_367 then
			v_u_229(v_u_367)
			v_u_367.ChildAdded:Connect(function()
				-- upvalues: (ref) v_u_229, (copy) v_u_367
				task.defer(v_u_229, v_u_367)
			end)
			if v366 and v366:IsA("GuiObject") then
				v_u_308(v366, v_u_367)
			end
		end
		v_u_13.watch("GiftCredits", v_u_209)
		v_u_11.changed:Connect(v_u_209)
		v_u_14.randomChanged:Connect(v_u_209)
		v_u_16:WaitForChild("PlayerGui").ChildAdded:Connect(function(p368)
			if p368.Name == "Odds" then
				for _, v369 in p368:GetDescendants() do
					if v369.Name ~= "GiftButton" then
						continue
					end
					v369:Destroy()
				end
			end
		end)
		if v_u_3:IsStudio() then
			v_u_16:GetAttributeChangedSignal("DevGift"):Connect(function()
				-- upvalues: (ref) v_u_16, (ref) v_u_15
				local v370 = v_u_16:GetAttribute("DevGift")
				if type(v370) == "string" then
					v_u_15.open(v370)
				end
			end)
			v_u_16:GetAttributeChangedSignal("DevGiftMode"):Connect(function()
				-- upvalues: (ref) v_u_16, (ref) v_u_30, (ref) v_u_273
				if v_u_16:GetAttribute("DevGiftMode") == true then
					v_u_30(v_u_16)
				else
					v_u_273()
				end
			end)
			v_u_16:GetAttributeChangedSignal("DevGiftGone"):Connect(function()
				-- upvalues: (ref) v_u_233, (ref) v_u_16, (ref) v_u_273
				local v371 = v_u_233
				if v_u_16:GetAttribute("DevGiftGone") == true and (v371 and v_u_233 == v371) then
					v_u_273((("%* left the server, gifting stopped"):format(v371.DisplayName)))
				end
			end)
		end
	end
end
return v_u_15