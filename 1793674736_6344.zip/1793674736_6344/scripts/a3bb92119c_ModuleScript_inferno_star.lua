local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF7A12")
local v_u_8 = Color3.fromHex("FFD23A")
local v_u_9 = Color3.fromRGB(235, 28, 16)
local v_u_10 = Color3.fromRGB(200, 50, 8)
local v_u_11 = Color3.fromRGB(255, 66, 10)
local v_u_12 = Color3.fromRGB(14, 6, 4)
local v_u_13 = Color3.fromRGB(34, 16, 10)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.PartType.Wedge
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_28(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_4
	local v22 = v_u_4.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: fadePicture
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
return function(p_u_33)
	-- upvalues: (copy) v_u_28, (copy) v_u_1, (copy) v_u_32, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_12, (copy) v_u_8, (copy) v_u_11, (copy) v_u_4, (copy) v_u_9, (copy) v_u_14, (copy) v_u_13, (copy) v_u_15, (copy) v_u_16, (copy) v_u_10, (copy) v_u_5
	local function v_u_50(p_u_34, p_u_35, p_u_36, p37, p38, p_u_39, p_u_40, p41) -- name: spinOut
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_33, (ref) v_u_32
		local v_u_42 = p41 or 0
		local v_u_43 = v_u_28(p_u_34, p_u_35, p37, p38, v_u_42)
		v_u_1:AddItem(v_u_43, p_u_39 + 0.1)
		p_u_33.animate(p_u_39, 0, function(p44)
			-- upvalues: (copy) v_u_43, (copy) p_u_35, (copy) p_u_36, (copy) p_u_34, (copy) p_u_39, (copy) p_u_40, (ref) v_u_32, (copy) v_u_42
			local v45 = 1 - (1 - p44) ^ 3
			local v46 = v_u_43
			local v47 = p_u_35 + (p_u_36 - p_u_35) * v45
			local v48 = v47 * 2
			local v49 = v47 * 2
			v46.Size = Vector3.new(v48, 0.05, v49)
			v_u_43.CFrame = p_u_34 * CFrame.Angles(0, p44 * p_u_39 * p_u_40, 0)
			v_u_32(v_u_43, v_u_42 + (1 - v_u_42) * p44 ^ 1.5)
			if p44 >= 1 then
				v_u_43:Destroy()
			end
		end)
	end
	local function v_u_61(p51, p52, p53, p54) -- name: starBurst
		-- upvalues: (ref) v_u_3, (copy) v_u_50, (copy) p_u_33, (ref) v_u_6, (ref) v_u_7, (ref) v_u_12
		local v55 = v_u_3.CurrentCamera
		local v56
		if v55 then
			local v57 = v55.CFrame.Position - p51
			v56 = v57.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v57.Unit
		else
			v56 = Vector3.new(0, 0, 1)
		end
		local v58 = math.random() * 0.3
		local v59 = v_u_50
		local v60 = p51 - v56 * 0.3
		v59(p_u_33.facing(v60, v56) * CFrame.Angles(0, v58 + 0, 0), p52 * 1.3, p53 * 1.3, v_u_6.InfernoStar, v_u_7, p54, 2)
		v_u_50(p_u_33.facing(p51, v56) * CFrame.Angles(0, v58 + 0, 0), p52, p53, v_u_6.InfernoStar, v_u_12, p54 * 0.8, 2)
	end
	local function v_u_73(p62, p63, p64, p65) -- name: starRays
		-- upvalues: (ref) v_u_3, (copy) p_u_33, (ref) v_u_8, (ref) v_u_11
		local v66 = v_u_3.CurrentCamera
		local v67, v68
		if v66 then
			v67 = v66.CFrame.RightVector
			v68 = v66.CFrame.UpVector
		else
			v67 = Vector3.new(1, 0, 0)
			v68 = Vector3.new(0, 1, 0)
		end
		for v69 = 0, 5 do
			local v70 = 1.5707963267948966 + v69 * 3.141592653589793 / 3
			local v71 = v67 * math.cos(v70) + v68 * math.sin(v70)
			local v72
			if v69 % 3 == 0 then
				v72 = p63 * 1.35
			else
				v72 = p63
			end
			p_u_33.thin(p_u_33.rod(p62 + v71 * 0.5, p62 + v71 * v72, p64, v_u_8, 0.05), p65)
			p_u_33.thin(p_u_33.rod(p62 + v71 * 0.3, p62 + v71 * v72 * 1.08, p64 * 2.2, v_u_11, 0.45), p65 * 1.2)
		end
	end
	local function v103(p74, p75) -- name: emberShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_28, (ref) v_u_6, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_14, (copy) p_u_33, (ref) v_u_1, (ref) v_u_3
		local v_u_76 = p74.size
		local v77 = 1.2 * v_u_76
		local v_u_78 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p75, v_u_7, {
			["transparency"] = 1
		})
		local v_u_79 = v_u_28(p75, v77, v_u_6.InfernoStar, v_u_12, 0)
		local v_u_80 = v_u_28(p75, v77 * 1.3, v_u_6.InfernoStar, v_u_7, 0)
		local v_u_81 = { v_u_79, v_u_80 }
		local v_u_82, v_u_83, v_u_84
		if p74.lite then
			v_u_82 = nil
			v_u_83 = nil
			v_u_84 = nil
		else
			local v85 = v_u_28(p75, v77 * 1.9, v_u_6.Glow, v_u_8, 0.3)
			table.insert(v_u_81, v85)
			v_u_83 = v85
			local v86 = {
				["shape"] = v_u_14
			}
			v_u_84 = v_u_4.part(Vector3.new(0.42, 0.42, 0.42) * v_u_76, p75, v_u_9, v86)
			table.insert(v_u_81, v_u_84)
			v_u_82 = p_u_33.loop("Trail", v_u_78, v_u_7, 0.35 * v_u_76)
			p_u_33.streak(v_u_78, v_u_8, v_u_7, 0.55 * v_u_76, 0.09)
		end
		p_u_33.streak(v_u_78, v_u_7, v_u_9, 1.8 * v_u_76, 0.15)
		if p74.mine then
			p_u_33.light(v_u_78, v_u_7, 10 * v_u_76)
		end
		for _, v87 in v_u_81 do
			v_u_1:AddItem(v87, 3)
		end
		v_u_1:AddItem(v_u_78, 3)
		local v_u_88 = false
		return {
			["place"] = function(p89, p90) -- name: place
				-- upvalues: (copy) v_u_78, (ref) v_u_3, (copy) v_u_79, (copy) v_u_76, (ref) p_u_33, (copy) v_u_80, (ref) v_u_83, (ref) v_u_84
				local v91 = p89.Position
				v_u_78.CFrame = p89
				local v92 = v_u_3.CurrentCamera
				local v93
				if v92 then
					local v94 = v92.CFrame.Position - v91
					v93 = v94.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v94.Unit
				else
					v93 = Vector3.new(0, 0, 1)
				end
				local v95 = -p90 * 9
				local v96 = v_u_79
				local v97 = v91 + v93 * 0.15 * v_u_76
				v96.CFrame = p_u_33.facing(v97, v93) * CFrame.Angles(0, v95 + 0, 0)
				v_u_80.CFrame = p_u_33.facing(v91, v93) * CFrame.Angles(0, v95 + 0, 0)
				local v98 = v_u_83
				if v98 then
					v98.CFrame = p_u_33.facing(v91 - v93 * 0.3 * v_u_76, v93)
				end
				local v99 = v_u_84
				if v99 then
					v99.CFrame = CFrame.new(v91 + v93 * 0.4 * v_u_76)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_88, (ref) v_u_82, (copy) v_u_78, (ref) v_u_1, (copy) v_u_81
				if not v_u_88 then
					v_u_88 = true
					local v100 = v_u_82
					if v100 then
						v100()
					end
					local v101 = v_u_78:FindFirstChildWhichIsA("PointLight")
					if v101 then
						v101:Destroy()
					end
					v_u_1:AddItem(v_u_78, 1)
					for _, v102 in v_u_81 do
						v102:Destroy()
					end
				end
			end
		}
	end
	local function v107(p104, p105) -- name: emberImpact
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_33, (ref) v_u_8, (copy) v_u_61, (copy) v_u_73, (ref) v_u_13
		local v106 = p104.size
		v_u_4.flash(p105, v_u_7, 5 * v106, 0.12)
		p_u_33.pop(p105, v_u_8, 1.3 * v106, 3.4 * v106, 0.13, 0.2)
		v_u_61(p105, 1.2 * v106, 3 * v106, 0.18)
		p_u_33.burst("Impact", p105, v_u_7, 0.9 * v106)
		if not p104.lite then
			v_u_73(p105, 3 * v106, 0.3 * v106, 0.14)
			p_u_33.burst("Fire", p_u_33.ground(p105), v_u_7, 0.32 * v106)
		end
		p_u_33.mark(p105, v_u_13, 2.4 * v106, 0.9)
		p_u_33.hitSound(p105)
	end
	local function v_u_155(p108, p_u_109, p110, p_u_111) -- name: fireRing
		-- upvalues: (copy) p_u_33, (ref) v_u_4, (ref) v_u_8, (ref) v_u_15, (ref) v_u_11, (ref) v_u_1, (ref) v_u_3
		local v_u_112 = p_u_33.ground(p108, 0)
		local v113 = math.random() * 3.141592653589793 * 2
		local v114 = p_u_111 + 0.3
		local v_u_115 = {}
		for v116 = 1, p110 do
			local v117 = {
				["shape"] = v_u_15
			}
			local v118 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_112), v_u_8, v117)
			local v119 = {
				["shape"] = nil,
				["transparency"] = 0.3,
				["shape"] = v_u_15
			}
			local v120 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_112), v_u_11, v119)
			v_u_1:AddItem(v118, v114 + 0.2)
			v_u_1:AddItem(v120, v114 + 0.2)
			local v121 = {
				["core"] = v118,
				["sheath"] = v120,
				["a"] = v113 + (v116 + math.random() * 0.4) / p110 * 3.141592653589793 * 2,
				["h"] = 5.5 + math.random() * 3,
				["w"] = 1.6 + math.random() * 0.9,
				["phase"] = math.random() * 6
			}
			table.insert(v_u_115, v121)
		end
		local v_u_122 = os.clock()
		local v_u_123 = {}
		local v_u_124 = {}
		p_u_33.runNow(function()
			-- upvalues: (copy) v_u_122, (copy) p_u_111, (copy) p_u_109, (copy) v_u_115, (copy) v_u_112, (copy) v_u_123, (copy) v_u_124, (ref) v_u_3
			local v125 = os.clock() - v_u_122
			local v126 = v125 / p_u_111
			local v127 = 1 - (1 - math.clamp(v126, 0, 1)) ^ 2.2
			local v128 = (v125 - p_u_111) / 0.3
			local v129 = math.clamp(v128, 0, 1)
			local v130 = (p_u_109 - 1.5) * v127 + 1.5
			local v131 = v125 / 0.06
			local v132 = math.clamp(v131, 0, 1)
			local v133 = 0
			for _, v134 in v_u_115 do
				local v135 = v134.h * v132 * (1 - v127 * 0.55) * (1 - v129)
				local v136 = v125 * 34 + v134.phase
				local v137 = v135 * (math.sin(v136) * 0.12 + 1)
				local v138 = math.max(v137, 0.2)
				local v139 = v134.w * (1 - v127 * 0.3)
				local v140 = CFrame.new
				local v141 = v_u_112
				local v142 = v134.a
				local v143 = math.cos(v142) * v130
				local v144 = v134.a
				local v145 = math.sin(v144) * v130
				local v146 = v140(v141 + Vector3.new(v143, 0, v145)) * CFrame.Angles(0, -v134.a, 0) * CFrame.Angles(0, 0, -0.38)
				local v147 = v134.core
				local v148 = v139 * 0.3
				local v149 = v138 * 0.72
				local v150 = v139 * 0.55
				v147.Size = Vector3.new(v148, v149, v150)
				local v151 = v134.sheath
				local v152 = v139 * 0.5
				v151.Size = Vector3.new(v152, v138, v139)
				local v153 = v133 + 1
				v_u_123[v153] = v134.core
				v_u_124[v153] = v146 * CFrame.new(0, v138 * 0.36, v139 * 0.18)
				v133 = v153 + 1
				v_u_123[v133] = v134.sheath
				v_u_124[v133] = v146 * CFrame.new(0, v138 / 2, 0)
			end
			v_u_3:BulkMoveTo(v_u_123, v_u_124, Enum.BulkMoveMode.FireCFrameChanged)
			if v129 < 1 then
				return true
			end
			for _, v154 in v_u_115 do
				v154.core:Destroy()
				v154.sheath:Destroy()
			end
			return false
		end)
	end
	local v_u_156 = {}
	setmetatable(v_u_156, {
		["__mode"] = "k"
	})
	local function v_u_160(p157) -- name: dropStar
		if not p157.done then
			p157.done = true
			p157.body:Destroy()
			p157.rim:Destroy()
			p157.glow:Destroy()
			local v158 = p157.ring
			if v158 then
				v158:Destroy()
			end
			local v159 = p157.pupil
			if v159 then
				v159:Destroy()
			end
		end
	end
	local function v_u_199(p161, p162) -- name: starStep
		-- upvalues: (copy) v_u_160, (copy) p_u_33, (ref) v_u_32
		if p162.done then
			return false
		end
		local v163 = p161.size
		local v164 = os.clock()
		local v165 = v164 - p162.born
		local v166 = v165 / p162.span
		local v167 = math.clamp(v166, 0, 1) - 1
		local v168 = v167 * 2.7 * v167 * v167 + 1 + v167 * 1.7 * v167
		local v169 = p162.at
		local v170 = v168 * 0.8 + 0.2
		local v171 = v165 / p162.span
		local v172 = v165 * (math.clamp(v171, 0, 1) * 6 + 2)
		local v173 = p162.firedAt
		local v174 = 0
		if v173 then
			local v175 = (v164 - v173) / 0.14
			local v176 = math.clamp(v175, 0, 1)
			v169 = p162.at:Lerp(p162.to, v176 * v176)
			v170 = v176 * 0.4 + 1
			v172 = v172 + (v164 - v173) * 20
			if v176 >= 1 then
				v_u_160(p162)
				return false
			end
		elseif p162.span + 1.2 < v165 then
			local v177 = (v165 - p162.span - 1.2) / 0.3
			v174 = math.clamp(v177, 0, 1)
			if v174 >= 1 then
				v_u_160(p162)
				return false
			end
		end
		local v178 = 3.4 * v163 * v170
		local v179 = p162.dir
		local v180 = p162.body
		local v181 = v178 * 2
		local v182 = v178 * 2
		v180.Size = Vector3.new(v181, 0.05, v182)
		local v183 = p162.body
		local v184 = v169 + v179 * 0.2
		v183.CFrame = p_u_33.facing(v184, v179) * CFrame.Angles(0, v172 + 0, 0)
		local v185 = p162.rim
		local v186 = v178 * 1.25
		local v187 = v186 * 2
		local v188 = v186 * 2
		v185.Size = Vector3.new(v187, 0.05, v188)
		p162.rim.CFrame = p_u_33.facing(v169, v179) * CFrame.Angles(0, v172 + 0, 0)
		local v189 = p162.glow
		local v190 = v178 * 2
		local v191 = v190 * 2
		local v192 = v190 * 2
		v189.Size = Vector3.new(v191, 0.05, v192)
		p162.glow.CFrame = p_u_33.facing(v169 - v179 * 0.4, v179)
		local v193 = p162.ring
		if v193 then
			local v194 = v178 * 0.42
			local v195 = v194 * 2
			local v196 = v194 * 2
			v193.Size = Vector3.new(v195, 0.05, v196)
			v193.CFrame = p_u_33.facing(v169 + v179 * 0.35, v179) * CFrame.Angles(0, -v172 * 2, 0)
		end
		local v197 = p162.pupil
		if v197 then
			v197.Size = Vector3.new(1, 1, 1) * v178 * 0.32
			v197.CFrame = CFrame.new(v169 + v179 * 0.3)
		end
		if v174 > 0 then
			for _, v198 in { p162.body, p162.rim, p162.glow } do
				v_u_32(v198, v174)
			end
		end
		return true
	end
	local function v_u_214(p_u_200, p201, p202) -- name: startStar
		-- upvalues: (ref) v_u_28, (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_8, (ref) v_u_1, (ref) v_u_9, (ref) v_u_4, (ref) v_u_14, (copy) v_u_156, (copy) p_u_33, (copy) v_u_199
		local v203 = p_u_200.dir
		local v204 = p201 + v203 * 4.5 * p_u_200.size
		local v205 = p202 + 3
		local v206 = v_u_28(CFrame.new(v204), 1, v_u_6.InfernoStar, v_u_12, 0)
		local v207 = v_u_28(CFrame.new(v204), 1, v_u_6.InfernoStar, v_u_7, 0)
		local v208 = v_u_28(CFrame.new(v204), 1, v_u_6.Glow, v_u_8, 0.2)
		for _, v209 in { v206, v207, v208 } do
			v_u_1:AddItem(v209, v205)
		end
		local v_u_210 = {
			["body"] = nil,
			["rim"] = nil,
			["glow"] = nil,
			["ring"] = nil,
			["pupil"] = nil,
			["at"] = nil,
			["dir"] = nil,
			["born"] = nil,
			["span"] = nil,
			["firedAt"] = nil,
			["to"] = nil,
			["done"] = false,
			["body"] = v206,
			["rim"] = v207,
			["glow"] = v208,
			["at"] = v204,
			["dir"] = v203,
			["born"] = os.clock(),
			["span"] = p202,
			["to"] = v204
		}
		if not p_u_200.lite then
			local v211 = v_u_28(CFrame.new(v204), 1, v_u_6.Ring, v_u_9, 0)
			v_u_1:AddItem(v211, v205)
			v_u_210.ring = v211
			local v212 = {
				["shape"] = v_u_14
			}
			local v213 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v204), v_u_9, v212)
			v_u_1:AddItem(v213, v205)
			v_u_210.pupil = v213
		end
		v_u_156[p_u_200] = v_u_210
		p_u_33.runNow(function()
			-- upvalues: (ref) v_u_199, (copy) p_u_200, (copy) v_u_210
			return v_u_199(p_u_200, v_u_210)
		end)
		return v_u_210
	end
	local v266 = {
		["inferno_star_a"] = {
			["cast"] = function(p215) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_33, (ref) v_u_8
				local v216 = p215.size
				local v217 = p215.eye + p215.dir * 1.2
				v_u_4.flash(v217, v_u_7, 3.2 * v216, 0.1)
				p_u_33.pop(v217, v_u_8, 1.2 * v216, 0.3 * v216, 0.08)
				if not p215.lite then
					p_u_33.burst("Fire", v217, v_u_7, 0.2 * v216)
				end
			end,
			["shot"] = v103,
			["impact"] = v107,
			["hit"] = function(p218, p219, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_7
				p_u_33.burst("Impact", p219, v_u_7, 0.6)
				if not p218.lite then
					p_u_33.burst("Fire", p219 - Vector3.new(0, 1.5, 0), v_u_7, 0.25)
				end
			end
		},
		["inferno_star_e"] = {
			["cast"] = function(p220) -- name: cast
				-- upvalues: (copy) p_u_33, (ref) v_u_7, (copy) v_u_61
				local v221 = p220.size
				p_u_33.skillCast(p220, v_u_7)
				v_u_61(p220.eye + Vector3.new(0, 2.4, 0) * v221, 1 * v221, 4.2 * v221, 0.32)
				p_u_33.burst("Fire", p220.feet, v_u_7, 0.6 * v221)
			end,
			["windup"] = function(p222, p223, p224) -- name: windup
				-- upvalues: (copy) p_u_33, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
				local v225 = p222.size
				local v226 = p_u_33.ground(p223, 1)
				p_u_33.inward(v226, v_u_8, p222.lite and 4 or 8, 7 * v225, (math.max(p224, 0.06)))
				v_u_4.ring(p_u_33.ground(p223), v_u_9, 3 * v225, math.max(p224, 0.06) + 0.05, v_u_6.Ring)
			end,
			["land"] = function(p227, p_u_228) -- name: land
				-- upvalues: (copy) p_u_33, (copy) v_u_155, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (ref) v_u_13
				local v229 = p227.size
				local v_u_230 = p227.ability.radius * v229
				local v231 = p227.lite
				local v_u_232 = p_u_33.ground(p_u_228)
				v_u_155(p_u_228, v_u_230, v231 and 9 or 18, 0.36)
				v_u_4.flash(p_u_33.ground(p_u_228, 2), v_u_8, 9 * v229, 0.14)
				p_u_33.burst("Explosion", p_u_33.ground(p_u_228, 1.5), v_u_7, 1.1 * v229)
				local v233 = p_u_33.burst
				local v234 = v_u_232 + Vector3.new(0, 0.3, 0)
				local v235 = v_u_7
				local v236 = v_u_230 / 16
				v233("Shockwave", v234, v235, (math.min(v236, 1.5)))
				v_u_4.ring(v_u_232, v_u_7, v_u_230, 0.41, v_u_6.Shockwave)
				p_u_33.after(0.05, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_232, (ref) v_u_9, (copy) v_u_230, (ref) v_u_6
					v_u_4.ring(v_u_232, v_u_9, v_u_230 * 1.15, 0.45999999999999996, v_u_6.Ring)
				end)
				p_u_33.mark(p_u_228, v_u_13, v_u_230 * 0.85, 2, v_u_6.CrackGlow, 0.15)
				if not v231 then
					p_u_33.after(0.306, function()
						-- upvalues: (ref) p_u_33, (copy) p_u_228, (copy) v_u_230, (ref) v_u_7
						for v237 = 1, 6 do
							local v238 = (v237 + math.random() * 0.5) / 6 * 3.141592653589793 * 2
							local v239 = p_u_33.ground(p_u_228, 0)
							local v240 = math.cos(v238)
							local v241 = math.sin(v238)
							local v242 = v239 + Vector3.new(v240, 0, v241) * v_u_230
							p_u_33.burst("Fire", v242, v_u_7, 0.55)
						end
					end)
					local v243 = { v_u_7, v_u_8, v_u_9 }
					p_u_33.chunks(p_u_33.ground(p_u_228, 1), v243, 8, 40, 0.5, 0.8, true, 0.7)
				end
				if p227.mine then
					v_u_4.shake(0.3, 0.3)
				end
			end,
			["hit"] = function(p244, p245, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_7
				p_u_33.burst("Impact", p245, v_u_7, 0.8)
				if not p244.lite then
					p_u_33.burst("Fire", p245 - Vector3.new(0, 1.5, 0), v_u_7, 0.3)
				end
			end
		},
		["inferno_star_r"] = {
			["cast"] = function(p246) -- name: cast
				-- upvalues: (copy) p_u_33, (ref) v_u_7
				p_u_33.skillCast(p246, v_u_7, true)
			end,
			["windup"] = function(p247, p248, p249) -- name: windup
				-- upvalues: (copy) v_u_214, (copy) p_u_33, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
				local v250 = p247.size
				local v251 = math.max(p249, 0.06)
				local v252 = v_u_214(p247, p248, v251)
				if not p247.lite then
					local v253 = p_u_33.loopAt("Charge", v252.at, v_u_7, 1 * v250)
					task.delay(v251, v253)
					p_u_33.inward(v252.at, v_u_8, 8, 10 * v250, v251)
				end
				if p247.mine then
					v_u_4.shake(0.12, v251)
				end
			end,
			["beam"] = function(p_u_254, p255, p_u_256) -- name: beam
				-- upvalues: (copy) v_u_156, (copy) v_u_214, (copy) p_u_33, (ref) v_u_7, (ref) v_u_6, (ref) v_u_11, (ref) v_u_8, (ref) v_u_12, (ref) v_u_16, (ref) v_u_13, (ref) v_u_4, (copy) v_u_61, (copy) v_u_73, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
				local v_u_257 = p_u_254.size
				local v_u_258 = p_u_254.lite
				local v259 = v_u_156[p_u_254]
				v_u_156[p_u_254] = nil
				if not v259 or v259.done then
					v259 = v_u_214(p_u_254, p255, 0.01)
				end
				v259.firedAt = os.clock()
				v259.to = p_u_256
				local v260 = (p_u_256 - p255).Unit
				p_u_33.glowBeam(p255, p_u_256, v_u_7, 13 * v_u_257, 0.6, v_u_6.FireBeam)
				p_u_33.thin(p_u_33.rod(p255, p_u_256, 5.5 * v_u_257, v_u_11, 0.55), 0.55, true)
				p_u_33.thin(p_u_33.rod(p255, p_u_256, 2.8 * v_u_257, v_u_8, 0.35), 0.45, true)
				p_u_33.thin(p_u_33.rod(p255, p_u_256, 1.5 * v_u_257, v_u_12, 0, v_u_16), 0.4, true)
				p_u_33.groundLine(p255, p_u_256, 5 * v_u_257, v_u_7, 1.2, 0.35)
				p_u_33.groundLine(p255, p_u_256, 2 * v_u_257, v_u_13, 2, 0.1)
				p_u_33.alongPath(p255, p_u_256, v_u_258 and 26 or 13, 0.14, function(p261)
					-- upvalues: (ref) p_u_33, (ref) v_u_7, (copy) v_u_258
					p_u_33.burst("Fire", p_u_33.ground(p261), v_u_7, v_u_258 and 0.4 or 0.55)
				end)
				local v262 = p255 + v260 * 2 * v_u_257
				v_u_4.flash(v262, v_u_8, 9 * v_u_257, 0.13)
				p_u_33.burst("Flash", v262, v_u_7, 0.5)
				p_u_33.after(0.14, function()
					-- upvalues: (ref) v_u_4, (copy) p_u_256, (ref) v_u_8, (copy) v_u_257, (ref) p_u_33, (ref) v_u_7, (ref) v_u_61, (ref) v_u_73, (copy) v_u_258, (ref) v_u_9, (ref) v_u_10, (ref) v_u_13, (ref) v_u_6, (ref) v_u_5, (copy) p_u_254
					v_u_4.flash(p_u_256, v_u_8, 14 * v_u_257, 0.16)
					p_u_33.burst("Explosion", p_u_256, v_u_7, 1.7 * v_u_257)
					v_u_61(p_u_256, 3 * v_u_257, 9 * v_u_257, 0.32)
					v_u_73(p_u_256, 9 * v_u_257, 0.7 * v_u_257, 0.3)
					if not v_u_258 then
						local v263 = {
							v_u_7,
							v_u_8,
							v_u_9,
							v_u_10
						}
						p_u_33.chunks(p_u_256, v263, 8, 40, 0.6, 0.9, true, 0.8)
					end
					p_u_33.mark(p_u_256, v_u_13, 5 * v_u_257, 1.6, v_u_6.CrackGlow, 0.1)
					v_u_5.play("Explosion", {
						["at"] = p_u_256,
						["volume"] = p_u_254.mine and 0.9 or 0.5
					})
				end)
				if p_u_254.mine then
					v_u_4.shake(0.45, 0.4)
				end
			end,
			["hit"] = function(p264, p265, _) -- name: hit
				-- upvalues: (copy) p_u_33, (ref) v_u_7, (ref) v_u_8
				p_u_33.burst("Impact", p265, v_u_7, 1)
				if not p264.lite then
					p_u_33.glint(p265, v_u_8, 4, 0.15)
					p_u_33.burst("Fire", p265 - Vector3.new(0, 1.5, 0), v_u_7, 0.35)
				end
			end
		}
	}
	return v266
end