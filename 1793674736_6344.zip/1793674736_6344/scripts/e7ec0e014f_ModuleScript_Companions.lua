local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.Fx.AuraLooks)
local v_u_7 = require(script.Parent.Fx.Kit)
local v_u_8 = require(script.Parent.PetLooks)
local v_u_9 = require(script.Parent.PetModels)
local v_u_10 = require(script.Parent.Perf)
local v_u_11 = require(v3.Shared.Config.Auras)
local v12 = {}
local v_u_13 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 70, 90)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 170, 40)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(255, 240, 70)),
	ColorSequenceKeypoint.new(0.6, Color3.fromRGB(70, 230, 110)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(60, 170, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(190, 90, 255))
})
local v_u_14 = {}
local function v_u_15() -- name: folder
	-- upvalues: (copy) v_u_7
	return v_u_7.folder()
end
local function v_u_23(p16) -- name: kinds
	-- upvalues: (copy) v_u_2
	local v_u_17 = p16:GetAttribute("PetKinds")
	local v18 = {}
	if type(v_u_17) ~= "string" then
		return v18
	end
	local function v19()
		-- upvalues: (ref) v_u_2, (copy) v_u_17
		return v_u_2:JSONDecode(v_u_17)
	end
	local v20, v21 = pcall(v19)
	if v20 and type(v21) == "table" then
		for _, v22 in v21 do
			if type(v22) ~= "string" then
				continue
			end
			table.insert(v18, v22)
		end
	end
	return v18
end
local function v_u_35(p24, p25) -- name: tiers
	-- upvalues: (copy) v_u_8, (copy) v_u_1, (copy) v_u_4, (copy) v_u_2
	local v26 = table.create(p25, 0)
	if not v_u_8.enabled() then
		return v26
	end
	local v27 = p24:GetAttribute("DevPetTier")
	if p24 == v_u_1.LocalPlayer and (v_u_4:IsStudio() and (type(v27) == "number" and v27 >= 1)) then
		for v28 = 1, p25 do
			v26[v28] = math.floor(v27)
		end
		return v26
	end
	local v_u_29 = p24:GetAttribute("PetKindTiers")
	if type(v_u_29) ~= "string" then
		return v26
	end
	local function v30()
		-- upvalues: (ref) v_u_2, (copy) v_u_29
		return v_u_2:JSONDecode(v_u_29)
	end
	local v31, v32 = pcall(v30)
	if v31 and type(v32) == "table" then
		for v33 = 1, p25 do
			local v34 = v32[v33]
			if type(v34) ~= "number" then
				continue
			end
			v26[v33] = v34
		end
	end
	return v26
end
local function v_u_49(p36) -- name: refreshPets
	-- upvalues: (copy) v_u_23, (copy) v_u_35, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8
	local v37 = not p36.shown and {} or v_u_23(p36.player)
	local v38 = v_u_35(p36.player, #v37)
	local v39 = #v37 == #p36.pets
	if v39 then
		for v40, v41 in v37 do
			if p36.pets[v40].kind == v41 and p36.pets[v40].tier == v38[v40] then
				continue
			end
			v39 = false
		end
	end
	if not v39 then
		for _, v42 in p36.pets do
			v42.model:Destroy()
		end
		p36.pets = {}
		for v43, v44 in v37 do
			local v45 = v_u_9.follower(v44, 0.85)
			if not v45 then
				continue
			end
			v45.model.Parent = v_u_7.folder()
			local v46 = v38[v43]
			if v46 > 0 then
				v_u_8.apply(v45.model, v46)
			end
			local v47 = p36.pets
			local v48 = {
				["model"] = nil,
				["kind"] = nil,
				["tier"] = nil,
				["pet"] = nil,
				["yaw"] = 0,
				["move"] = 0,
				["model"] = v45.model,
				["kind"] = v44,
				["tier"] = v46,
				["pet"] = v45
			}
			table.insert(v47, v48)
		end
	end
end
local function v_u_83(p50) -- name: refreshAura
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_13
	local v51 = p50.player:GetAttribute("Aura")
	local v52 = p50.player:GetAttribute("HideAura") == true
	local v53 = (type(v51) ~= "string" or v52) and "" or v51
	local v54 = p50.player.Character
	if v54 then
		v54 = v54:FindFirstChild("HumanoidRootPart")
	end
	if v53 == p50.auraId and v54 == p50.auraRoot then
		return
	else
		p50.auraId = v53
		p50.auraRoot = v54
		for _, v55 in p50.stopAura do
			v55()
		end
		p50.stopAura = {}
		local v56 = v_u_11.byId[v53]
		if v56 and (v54 and p50.shown) then
			local v57 = Color3.fromHex(v56.color)
			local v58 = v_u_10.formRate()
			local v59 = v_u_6.start(v56.id, v54, v58, v_u_10.level() >= 3 and true or p50.player == v_u_1.LocalPlayer)
			if v59 then
				local v60 = p50.stopAura
				table.insert(v60, v59)
			else
				local v61 = {}
				for _, v62 in v54:GetChildren() do
					v61[v62] = true
				end
				local v63 = p50.stopAura
				local v64 = v_u_7.loop
				local v65 = v56.look
				local v66 = v56.scale * 1.25
				table.insert(v63, v64(v65, v54, v57, v66, 0.25, v58))
				if v56.extra and (v_u_10.level() >= 3 or p50.player == v_u_1.LocalPlayer) then
					local v67 = p50.stopAura
					local v68 = v_u_7.loop
					local v69 = v56.extra
					local v70 = v56.scale * 1.1
					table.insert(v67, v68(v69, v54, v57, v70, 0.3, v58))
				end
				if v56.rainbow then
					for _, v71 in v54:GetChildren() do
						if v61[v71] then
							continue
						end
						for _, v72 in v71:GetDescendants() do
							if not (v72:IsA("ParticleEmitter") or (v72:IsA("Beam") or v72:IsA("Trail"))) then
								continue
							end
							v72.Color = v_u_13
						end
					end
				end
				local v73 = v56.colors
				if v73 and #v73 >= 2 then
					local v74 = {}
					for v75, v76 in v73 do
						local v77 = ColorSequenceKeypoint.new
						local v78 = (v75 - 1) / (#v73 - 1)
						local v79 = Color3.fromHex
						table.insert(v74, v77(v78, v79(v76)))
					end
					local v80 = ColorSequence.new(v74)
					for _, v81 in v54:GetChildren() do
						if v61[v81] then
							continue
						end
						for _, v82 in v81:GetDescendants() do
							if v82:IsA("ParticleEmitter") then
								v82.Color = v80
							end
							if v82:IsA("Beam") then
								v82.Color = v80
							end
							if not v82:IsA("Trail") then
								continue
							end
							v82.Color = v80
						end
					end
				end
			end
		else
			return
		end
	end
end
local function v_u_89(p84) -- name: add
	-- upvalues: (copy) v_u_1, (copy) v_u_14, (copy) v_u_49, (copy) v_u_83
	local v_u_85 = {
		["player"] = nil,
		["pets"] = nil,
		["stopAura"] = nil,
		["auraId"] = "?",
		["movedAt"] = nil,
		["shown"] = nil,
		["player"] = p84,
		["pets"] = {},
		["stopAura"] = {},
		["movedAt"] = math.random() * 0.25,
		["shown"] = p84 == v_u_1.LocalPlayer
	}
	v_u_14[p84] = v_u_85
	p84:GetAttributeChangedSignal("PetKinds"):Connect(function()
		-- upvalues: (ref) v_u_49, (copy) v_u_85
		v_u_49(v_u_85)
	end)
	for _, v86 in { "PetKindTiers", "DevPetTier" } do
		p84:GetAttributeChangedSignal(v86):Connect(function()
			-- upvalues: (ref) v_u_49, (copy) v_u_85
			v_u_49(v_u_85)
		end)
	end
	for _, v87 in { "Aura", "HideAura" } do
		p84:GetAttributeChangedSignal(v87):Connect(function()
			-- upvalues: (ref) v_u_83, (copy) v_u_85
			v_u_83(v_u_85)
		end)
	end
	p84.CharacterAdded:Connect(function(p88)
		-- upvalues: (ref) v_u_83, (copy) v_u_85
		p88:WaitForChild("HumanoidRootPart", 10)
		v_u_83(v_u_85)
	end)
	v_u_49(v_u_85)
	v_u_83(v_u_85)
end
local function v_u_107() -- name: cull
	-- upvalues: (copy) v_u_5, (copy) v_u_14, (copy) v_u_1, (copy) v_u_49, (copy) v_u_83, (copy) v_u_10
	local v90 = v_u_5.CurrentCamera
	if v90 then
		local v91 = v90.CFrame.Position
		local v92 = {}
		for v93, v94 in v_u_14 do
			if v93 == v_u_1.LocalPlayer then
				continue
			end
			local v95 = v93.Character
			if v95 then
				v95 = v95:FindFirstChild("HumanoidRootPart")
			end
			if v95 and v95:IsA("BasePart") then
				local v96 = {
					["rig"] = v94,
					["d"] = (v95.Position - v91).Magnitude
				}
				table.insert(v92, v96)
			else
				if v94.shown == false then
					continue
				end
				v94.shown = false
				v94.auraId = "?"
				v_u_49(v94)
				v_u_83(v94)
			end
		end
		table.sort(v92, function(p97, p98)
			return p97.d < p98.d
		end)
		local v99 = v_u_10.formBudget()
		local v100 = 0
		for v101, v102 in v92 do
			local v103
			if v102.d <= 400 then
				local v104
				if v102.rig.shown then
					v104 = v99 + 1
				else
					v104 = v99
				end
				v103 = v101 <= v104
			else
				v103 = false
			end
			if v103 and not v102.rig.shown then
				if v100 >= 2 then
					continue
				end
				v100 = v100 + 1
				local v105 = v102.rig
				if v105.shown == true then
					continue
				end
				v105.shown = true
				v105.auraId = "?"
				v_u_49(v105)
				v_u_83(v105)
			else
				if v103 then
					continue
				end
				local v106 = v102.rig
				if v106.shown == false then
					continue
				end
				v106.shown = false
				v106.auraId = "?"
				v_u_49(v106)
				v_u_83(v106)
			end
		end
	end
end
local function v_u_112(p108) -- name: remove
	-- upvalues: (copy) v_u_14
	local v109 = v_u_14[p108]
	if v109 then
		v_u_14[p108] = nil
		for _, v110 in v109.pets do
			v110.model:Destroy()
		end
		for _, v111 in v109.stopAura do
			v111()
		end
	end
end
function v12.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_89, (copy) v_u_112, (copy) v_u_107, (copy) v_u_10, (copy) v_u_14, (copy) v_u_83, (copy) v_u_4, (copy) v_u_15, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9
	v_u_1.PlayerAdded:Connect(v_u_89)
	v_u_1.PlayerRemoving:Connect(v_u_112)
	for _, v113 in v_u_1:GetPlayers() do
		task.spawn(v_u_89, v113)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_107
		while true do
			task.wait(0.5)
			v_u_107()
		end
	end)
	v_u_10.onChanged(function()
		-- upvalues: (ref) v_u_14, (ref) v_u_83
		for _, v114 in v_u_14 do
			v114.auraId = "?"
			v_u_83(v114)
		end
	end)
	local v_u_115 = RaycastParams.new()
	v_u_115.FilterType = Enum.RaycastFilterType.Exclude
	v_u_115.IgnoreWater = true
	local v_u_116 = (-1 / 0)
	v_u_4.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_116, (ref) v_u_15, (ref) v_u_1, (copy) v_u_115, (ref) v_u_5, (ref) v_u_14, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9
		local v117 = os.clock()
		if v117 - v_u_116 >= 1 then
			v_u_116 = v117
			local v118 = { v_u_15() }
			for _, v119 in v_u_1:GetPlayers() do
				if not v119.Character then
					continue
				end
				local v120 = v119.Character
				table.insert(v118, v120)
			end
			v_u_115.FilterDescendantsInstances = v118
		end
		local v121 = v_u_5.CurrentCamera
		local v122 = not v121 and Vector3.new(0, 0, 0) or v121.CFrame.Position
		for _, v123 in v_u_14 do
			local v124 = v123.player.Character
			local v125
			if v124 then
				v125 = v124:FindFirstChild("HumanoidRootPart")
			else
				v125 = v124
			end
			if not (v124 and (v125 and v125:IsA("BasePart"))) then
				continue
			end
			local v126 = (v125.Position - v122).Magnitude
			if v117 - v123.movedAt < v_u_10.frameGap(v126) then
				continue
			end
			local v127 = v117 - v123.movedAt
			local v128 = math.min(v127, 0.5)
			v123.movedAt = v117
			local v129 = v126 < 140
			local v130 = -v128 * 7
			local v131 = 1 - math.exp(v130)
			local v132 = -v128 * 10
			local v133 = 1 - math.exp(v132)
			local v134 = -v128 * 14
			local v135 = 1 - math.exp(v134)
			local v136 = -v128 * 8
			local v137 = 1 - math.exp(v136)
			local v138 = v124:FindFirstChildOfClass("Humanoid")
			local v139 = v125.Position.Y - (not v138 and 3 or v138.HipHeight + v125.Size.Y / 2)
			local v140 = v125.CFrame.LookVector
			local v141 = -v140.X
			local v142 = -v140.Z
			local v143 = math.atan2(v141, v142)
			local v144 = #v123.pets
			local v145 = 1
			for _, v146 in v123.pets do
				local v147 = v146.pet.scale / 0.85
				v145 = math.max(v145, v147)
			end
			for v148, v149 in v123.pets do
				local v150 = v144 == 1 and 0 or (v148 - (v144 + 1) / 2) * 3.8 * v145
				local v151 = (math.abs(v150) * 0.35 + 4.6) * (v145 * 0.4 + 0.6)
				local v152 = v125.CFrame * Vector3.new(v150, 0, v151)
				local v153 = v152.X
				local v154 = v152.Z
				local v155 = Vector3.new(v153, 0, v154)
				local v156 = v149.pos
				if not v156 or (v155 - v156).Magnitude > 50 then
					v149.ground = nil
					v149.yaw = v143
					v156 = v155
				end
				local v157 = v156:Lerp(v155, v131)
				v149.pos = v157
				local v158 = (v157 - v156) / math.max(v128, 0.004166666666666667)
				local v159 = v158.Magnitude
				local v160
				if v129 then
					local v161 = v_u_5
					local v162 = v157.X
					local v163 = v139 + 3
					local v164 = v157.Z
					v160 = v161:Raycast(Vector3.new(v162, v163, v164), Vector3.new(0, -14, 0), v_u_115)
				else
					v160 = nil
				end
				local v165
				if v160 then
					v165 = v160.Position.Y
				else
					v165 = v139
				end
				local v166 = v149.ground
				if v166 then
					v165 = v166 + (v165 - v166) * v135
				end
				v149.ground = v165
				local v167
				if v159 > 1.5 then
					local v168 = -v158.X
					local v169 = -v158.Z
					v167 = math.atan2(v168, v169)
				else
					v167 = v143
				end
				v149.yaw = v149.yaw + ((v167 - v149.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v133
				v149.yaw = (v149.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
				local v170 = v149.move
				local v171 = v159 / 14
				v149.move = v170 + (math.clamp(v171, 0, 1) - v149.move) * v137
				local v172 = v149.pet
				local v173 = v149.yaw
				local v174, v175
				if v172.fly then
					local v176 = v117 * 2.2 + v148
					v174 = v165 + (math.sin(v176) * 0.25 + 1.7)
					v175 = v149.move * 0.22
				else
					local v177 = v117 * v172.hopRate + v148 * 1.3
					local v178 = math.sin(v177)
					v174 = v165 + math.abs(v178) * v172.hop * v172.scale * v149.move
					v175 = v149.move * 0.06
					if v172.slither then
						local v179 = v117 * 7 + v148
						v173 = v173 + math.sin(v179) * 0.22 * v149.move
					end
				end
				local v180 = CFrame.new(v157.X, v174, v157.Z) * CFrame.Angles(0, v173, 0) * CFrame.Angles(-v175, 0, 0)
				if v149.tier > 0 then
					local v181 = v_u_8.jitter(v149.model)
					if v181 then
						v180 = v180 * v181
					end
				end
				v_u_9.place(v172, v180)
				if not v129 then
					continue
				end
				v_u_9.animate(v172, v117 + v148 * 0.37, v149.move)
			end
		end
	end)
end
return v12