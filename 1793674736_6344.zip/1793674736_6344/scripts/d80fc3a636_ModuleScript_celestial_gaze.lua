local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_3.Shared.Config.Textures)
local v_u_8 = Color3.fromRGB(255, 194, 26)
local v_u_9 = Color3.fromRGB(255, 247, 209)
local v_u_10 = Color3.fromRGB(255, 150, 40)
local v_u_11 = Color3.fromRGB(16, 13, 34)
local v_u_12 = Color3.new(1, 1, 1)
local function v_u_16(p13, p14) -- name: fadePicture
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v15 in p13:GetChildren() do
		if not v15:IsA("Decal") then
			continue
		end
		v_u_5.tween(v15, p14, {
			["Transparency"] = 1
		})
	end
	v_u_1:AddItem(p13, p14 + 0.05)
end
return function(p_u_17)
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_1, (copy) v_u_3, (copy) v_u_12, (copy) v_u_16, (copy) v_u_6, (copy) v_u_2, (copy) v_u_11, (copy) v_u_10
	local function v_u_53(p18, p19, p20, p_u_21, p_u_22) -- name: starlets
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (copy) p_u_17, (ref) v_u_4
		if p19 > 0 then
			local v_u_23 = {}
			for v24 = 1, p19 do
				local v25 = v_u_5.part(Vector3.new(p_u_21, 0.05, p_u_21), CFrame.new(p18), v_u_8, {
					["transparency"] = 1
				})
				local v26 = {}
				for _, v27 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
					local v28 = Instance.new("Decal")
					v28.Face = v27
					v28.Texture = v_u_7.PetStar
					local v29
					if v24 % 2 == 0 then
						v29 = v_u_8
					else
						v29 = v_u_9
					end
					v28.Color3 = v29
					v28.Parent = v25
					table.insert(v26, v28)
				end
				v_u_1:AddItem(v25, p_u_22 + 0.1)
				local v30 = math.random() - 0.5
				local v31 = math.random() * 0.8 - 0.1
				local v32 = math.random() - 0.5
				local v33 = Vector3.new(v30, v31, v32)
				local v34 = {
					["p"] = v25,
					["decals"] = v26,
					["v"] = (v33.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v33.Unit) * p20 * (0.55 + math.random() * 0.6),
					["spin"] = (math.random() - 0.5) * 12,
					["turn"] = math.random() * 6
				}
				table.insert(v_u_23, v34)
			end
			local v_u_35 = os.clock()
			local v_u_36 = v_u_35
			p_u_17.runNow(function()
				-- upvalues: (ref) v_u_36, (copy) v_u_35, (copy) p_u_22, (ref) v_u_4, (copy) v_u_23, (copy) p_u_21, (ref) p_u_17
				local v37 = os.clock()
				local v38 = v37 - v_u_36
				local v39 = math.min(v38, 0.05)
				v_u_36 = v37
				local v40 = (v37 - v_u_35) / p_u_22
				local v41 = math.clamp(v40, 0, 1)
				local v42 = v_u_4.CurrentCamera
				local v43 = not v42 and Vector3.new(0, 0, 1) or -v42.CFrame.LookVector
				for _, v44 in v_u_23 do
					local v45 = v44.v
					local v46 = 1 - v39 * 3.5
					local v47 = v45 * math.max(v46, 0)
					local v48 = v39 * 14
					v44.v = v47 - Vector3.new(0, v48, 0)
					v44.turn = v44.turn + v44.spin * v39
					local v49 = v44.p.Position + v44.v * v39
					local v50 = p_u_21 * (1 - v41 * 0.7)
					v44.p.Size = Vector3.new(v50, 0.05, v50)
					v44.p.CFrame = p_u_17.facing(v49, v43) * CFrame.Angles(0, v44.turn, 0)
					for _, v51 in v44.decals do
						v51.Transparency = v41 * v41
					end
				end
				if v41 < 1 then
					return true
				end
				for _, v52 in v_u_23 do
					v52.p:Destroy()
				end
				return false
			end)
		end
	end
	local function v_u_60(p54, p55) -- name: sparkleTail
		-- upvalues: (ref) v_u_3, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_1
		local v56 = v_u_3:FindFirstChild("Fx")
		if v56 then
			v56 = v56:FindFirstChild("Sparkle")
		end
		if v56 then
			v56 = v56:FindFirstChild("Stars")
		end
		if not (v56 and v56:IsA("ParticleEmitter")) then
			v56 = nil
		end
		if not v56 then
			return function() end
		end
		local v_u_57 = Instance.new("Attachment")
		v_u_57.Parent = p54
		local v_u_58 = v56:Clone()
		v_u_58.Rate = 40
		v_u_58.Lifetime = NumberRange.new(0.25, 0.45)
		v_u_58.Speed = NumberRange.new(1, 4)
		v_u_58.SpreadAngle = Vector2.new(180, 180)
		v_u_58.Acceleration = Vector3.new(0, -6, 0)
		v_u_58.Drag = 2
		v_u_58.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p55 * 1.5), NumberSequenceKeypoint.new(1, 0) })
		v_u_58.Color = ColorSequence.new(v_u_9, v_u_8)
		v_u_58.LightEmission = 0.6
		v_u_58.Enabled = true
		v_u_58.Parent = v_u_57
		return function()
			-- upvalues: (copy) v_u_58, (copy) v_u_57, (ref) v_u_4, (ref) v_u_1
			v_u_58.Enabled = false
			local v59 = v_u_57.WorldPosition
			v_u_57.Parent = v_u_4.Terrain
			v_u_57.WorldPosition = v59
			v_u_1:AddItem(v_u_57, 0.6)
		end
	end
	local function v_u_74(p61, p62, p63) -- name: starShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_12, (copy) p_u_17, (ref) v_u_9, (copy) v_u_60
		local v64 = p61.size * p63
		local v65 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p62, v_u_8, {
			["transparency"] = 1
		})
		local v66 = v_u_5.part(Vector3.new(3, 0.05, 3) * v64, p62, v_u_8, {
			["transparency"] = 1
		})
		for _, v67 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v68 = Instance.new("Decal")
			v68.Face = v67
			v68.Texture = v_u_7.PetStar
			v68.Color3 = v_u_8
			v68.Parent = v66
		end
		local v69 = v_u_5.part(Vector3.new(0.8, 0.8, 0.8) * v64, p62, v_u_12, {
			["shape"] = Enum.PartType.Ball
		})
		local v70 = v_u_5.part(Vector3.new(1.9, 1.9, 1.9) * v64, p62, v_u_8, {
			["shape"] = nil,
			["transparency"] = 0.55,
			["shape"] = Enum.PartType.Ball
		})
		local v71 = {
			{
				["p"] = v66,
				["off"] = CFrame.Angles(1.5707963267948966, 0, 0)
			},
			{
				["p"] = v69,
				["off"] = CFrame.identity
			},
			{
				["p"] = v70,
				["off"] = CFrame.identity
			}
		}
		p_u_17.streak(v65, v_u_8, v_u_9, 1.5 * v64, 0.3)
		local v72 = {}
		if not p61.lite then
			local v73 = v_u_60(v65, v64)
			table.insert(v72, v73)
		end
		if p61.mine then
			p_u_17.light(v65, v_u_8, 9 * v64)
		end
		return p_u_17.assemble(v65, v71, {}, 0, 0, v72, 0.3, 9)
	end
	local v_u_75 = {}
	setmetatable(v_u_75, {
		["__mode"] = "k"
	})
	local function v_u_81(p76, p77, p78) -- name: flare
		-- upvalues: (ref) v_u_12, (ref) v_u_5, (copy) p_u_17, (ref) v_u_16, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6
		if not p77.finished then
			p77.finished = true
			for _, v_u_79 in p77.lines do
				if not v_u_79.Parent then
					continue
				end
				v_u_79.Color = v_u_12
				v_u_5.tween(v_u_79, 0.12, {
					["Size"] = v_u_79.Size * Vector3.new(2.2, 2.2, 1)
				})
				task.delay(0.12, function()
					-- upvalues: (ref) p_u_17, (copy) v_u_79
					p_u_17.thin(v_u_79, 0.5)
				end)
			end
			for _, v_u_80 in p77.nodes do
				if not v_u_80.Parent then
					continue
				end
				v_u_5.tween(v_u_80, 0.15, {
					["Size"] = v_u_80.Size * 1.6
				})
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_16, (copy) v_u_80
					v_u_16(v_u_80, 0.45)
				end)
			end
			v_u_5.ring(p_u_17.ground(p78), v_u_9, p76.ability.radius, 0.45, v_u_7.Ring)
			if not p76.lite then
				p_u_17.burst("Sparkle", p_u_17.ground(p78, 2), nil, 0.9)
			end
			v_u_6.play("Orb", {
				["at"] = p_u_17.ground(p78, 2),
				["volume"] = p76.mine and 0.7 or 0.4
			})
		end
	end
	local function v_u_102(p82, p_u_83, p_u_84, p_u_85) -- name: link
		-- upvalues: (ref) v_u_5, (copy) p_u_17, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1
		local v_u_86 = p_u_85 - p_u_84
		if v_u_86.Magnitude >= 0.5 then
			for v87, v_u_88 in p82.lite and { 0.3 } or { 0.3, 0.95 } do
				local v89 = v_u_5.part
				local v90 = Vector3.new(v_u_88, v_u_88, 0.1)
				local v91 = p_u_17.aimAt(p_u_84, v_u_86)
				local v92
				if v87 == 1 then
					v92 = v_u_9
				else
					v92 = v_u_8
				end
				local v_u_93 = v89(v90, v91, v92, {
					["transparency"] = v87 == 1 and 0 or 0.6
				})
				v_u_1:AddItem(v_u_93, 5)
				local v94 = p_u_83.lines
				table.insert(v94, v_u_93)
				p_u_17.animate(0.12, 0, function(p95)
					-- upvalues: (copy) v_u_93, (copy) p_u_83, (copy) p_u_84, (copy) p_u_85, (copy) v_u_88, (ref) p_u_17, (copy) v_u_86
					if v_u_93.Parent and not p_u_83.finished then
						local v96 = p_u_84:Lerp(p_u_85, p95)
						local v97 = v_u_93
						local v98 = v_u_88
						local v99 = v_u_88
						local v100 = (v96 - p_u_84).Magnitude
						local v101 = math.max(v100, 0.1)
						v97.Size = Vector3.new(v98, v99, v101)
						v_u_93.CFrame = p_u_17.aimAt((p_u_84 + v96) / 2, v_u_86)
					end
				end)
			end
		end
	end
	local v_u_103 = {}
	setmetatable(v_u_103, {
		["__mode"] = "k"
	})
	local v_u_104 = 0
	local function v_u_108() -- name: blind
		-- upvalues: (ref) v_u_104, (ref) v_u_2, (ref) v_u_5, (ref) v_u_12, (ref) v_u_1
		local v105 = os.clock()
		if v105 >= v_u_104 then
			v_u_104 = v105 + 0.6
			local v106 = Instance.new("ColorCorrectionEffect")
			v106.Name = "BigBang"
			v106.Brightness = 0.55
			v106.Contrast = -0.2
			v106.TintColor = Color3.fromRGB(255, 244, 214)
			v106.Parent = v_u_2
			local v107 = {
				["Brightness"] = 0,
				["Contrast"] = 0,
				["TintColor"] = nil,
				["TintColor"] = v_u_12
			}
			v_u_5.tween(v106, 0.45, v107)
			v_u_1:AddItem(v106, 0.5)
		end
	end
	local v303 = {
		["celestial_gaze_a"] = {
			["cast"] = function(p109) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_17, (ref) v_u_9
				local v110 = p109.eye + p109.dir * 1.2
				v_u_5.flash(v110, v_u_8, 3, 0.12)
				p_u_17.glint(v110, v_u_9, 3.6, 0.14)
			end,
			["shot"] = function(p111, p112) -- name: shot
				-- upvalues: (copy) v_u_74
				return v_u_74(p111, p112, 1)
			end,
			["impact"] = function(p113, p114) -- name: impact
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_17, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (copy) v_u_53
				local v115 = p113.size
				v_u_5.flash(p114, v_u_8, 6.5 * v115, 0.18)
				p_u_17.pop(p114, v_u_12, 1.6 * v115, 4.6 * v115, 0.14)
				local v116 = 3.4 * v115
				local v117 = v_u_9
				local v118 = p_u_17.sigil
				local v119 = p_u_17.facing
				local v120 = v_u_4.CurrentCamera
				local v121
				if v120 then
					local v122 = v120.CFrame.Position - p114
					v121 = v122.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v122.Unit
				else
					v121 = Vector3.new(0, 0, 1)
				end
				v118(v119(p114, v121), v116, v117, v_u_7.PetStar, 0.08, 6)
				p_u_17.glint(p114, v_u_9, 7 * v115, 0.22)
				p_u_17.burst("Impact", p114, v_u_8, 0.9 * v115)
				v_u_5.ring(p_u_17.ground(p114), v_u_8, p113.ability.radius * 0.85 * v115, 0.3, v_u_7.Ring)
				if not p113.lite then
					v_u_53(p114, 5, 22, 0.9 * v115, 0.5)
				end
				p_u_17.hitSound(p114)
			end,
			["hit"] = function(_, p123, _) -- name: hit
				-- upvalues: (copy) p_u_17, (ref) v_u_8, (ref) v_u_9
				p_u_17.burst("Impact", p123, v_u_8, 0.6)
				p_u_17.glint(p123, v_u_9, 3, 0.14)
			end
		},
		["celestial_gaze_e"] = {
			["cast"] = function(p124) -- name: cast
				-- upvalues: (copy) p_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (copy) v_u_53
				p_u_17.skillCast(p124, v_u_8)
				local v125 = p124.eye + Vector3.new(0, 2.6, 0)
				local v126 = v_u_9
				local v127 = p_u_17.sigil
				local v128 = p_u_17.facing
				local v129 = v_u_4.CurrentCamera
				local v130
				if v129 then
					local v131 = v129.CFrame.Position - v125
					v130 = v131.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v131.Unit
				else
					v130 = Vector3.new(0, 0, 1)
				end
				v127(v128(v125, v130), 1.6, v126, v_u_7.PetStar, 0.35, 4)
				if not p124.lite then
					v_u_53(p124.eye + Vector3.new(0, 1.5, 0), 3, 14, 0.8, 0.45)
				end
			end,
			["windup"] = function(p132, p133, p134) -- name: windup
				-- upvalues: (copy) v_u_75, (copy) p_u_17, (ref) v_u_11, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7
				local v135 = p132.ability.radius
				v_u_75[p132] = {
					["spots"] = nil,
					["lines"] = nil,
					["nodes"] = nil,
					["finished"] = false,
					["spots"] = {},
					["lines"] = {},
					["nodes"] = {}
				}
				local v_u_136 = p_u_17.plate(p_u_17.ground(p133, 0.06), v135, v_u_11, 1, Enum.Material.SmoothPlastic)
				v_u_5.tween(v_u_136, 0.2, {
					["Transparency"] = 0.4
				})
				task.delay(p134 + 0.4, function()
					-- upvalues: (ref) p_u_17, (copy) v_u_136
					p_u_17.fadeOut(v_u_136, 0.5)
				end)
				p_u_17.sigil(CFrame.new(p_u_17.ground(p133, 0.15)), v135, v_u_8, v_u_7.Ring, p134 + 0.6, 0.4)
			end,
			["strike"] = function(p_u_137, p138, p139) -- name: strike
				-- upvalues: (copy) v_u_75, (copy) p_u_17, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (copy) v_u_74, (ref) v_u_5, (ref) v_u_8, (ref) v_u_6, (copy) v_u_102, (copy) v_u_81
				local v_u_140 = p_u_137.ability.strikeRadius or 5
				local v_u_141 = v_u_75[p_u_137]
				local v_u_142 = p_u_17.ground(p138, 1.6)
				local v_u_143 = nil
				local v_u_144
				if v_u_141 then
					local v145 = (1 / 0)
					for _, v146 in v_u_141.spots do
						local v147 = (v146 - v_u_142).Magnitude
						if v147 >= v145 then
							continue
						end
						v_u_143 = v146
						v145 = v147
					end
					local v148 = v_u_141.spots
					table.insert(v148, v_u_142)
					v_u_144 = #v_u_141.spots
				else
					v_u_144 = 0
				end
				local v149 = p_u_137.dir:Cross(Vector3.new(0, 1, 0))
				local v150 = p_u_17.ground(p138, 26) + v149 * 10
				local v151 = (math.random() - 0.5) * 4
				local v152 = (math.random() - 0.5) * 4
				local v153 = v150 + Vector3.new(v151, 0, v152)
				if p139 - 0.22 > 0.05 and not p_u_137.lite then
					local v154 = v_u_9
					local v155 = p139 - 0.22
					local v156 = p_u_17.sigil
					local v157 = p_u_17.facing
					local v158 = v_u_4.CurrentCamera
					local v159
					if v158 then
						local v160 = v158.CFrame.Position - v153
						v159 = v160.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v160.Unit
					else
						v159 = Vector3.new(0, 0, 1)
					end
					v156(v157(v153, v159), 1.1, v154, v_u_7.PetStar, v155, 3)
				end
				local function v163(p161, p162) -- name: falling
					-- upvalues: (ref) v_u_74
					return v_u_74(p161, p162, 0.85)
				end
				p_u_17.drop(p_u_137, v163, v153, v_u_142, 0.22, p139, nil, function(p164)
					-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) p_u_17, (ref) v_u_9, (copy) v_u_140, (ref) v_u_7, (ref) v_u_6, (copy) p_u_137, (copy) v_u_141, (copy) v_u_142, (ref) v_u_4, (ref) v_u_143, (ref) v_u_102, (ref) v_u_144, (ref) v_u_81
					v_u_5.flash(p164, v_u_8, 5, 0.18)
					p_u_17.burst("Impact", p164, v_u_8, 0.9)
					p_u_17.glint(p164, v_u_9, 5, 0.18)
					v_u_5.ring(p_u_17.ground(p164), v_u_8, v_u_140, 0.3, v_u_7.Ring)
					v_u_6.play("Hit", {
						["at"] = nil,
						["volume"] = 0.5,
						["at"] = p164
					})
					if p_u_137.mine then
						v_u_5.shake(0.06, 0.08)
					end
					if v_u_141 and not v_u_141.finished then
						local v165 = v_u_142
						local v166 = v_u_8
						local v167 = p_u_17.sigil
						local v168 = p_u_17.facing
						local v169 = v_u_4.CurrentCamera
						local v170
						if v169 then
							local v171 = v169.CFrame.Position - v165
							v170 = v171.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v171.Unit
						else
							v170 = Vector3.new(0, 0, 1)
						end
						local v172 = v167(v168(v165, v170), 1.3, v166, v_u_7.PetStar, 4, 1.2)
						local v173 = v_u_141.nodes
						table.insert(v173, v172)
						if v_u_143 then
							v_u_102(p_u_137, v_u_141, v_u_143, v_u_142)
						end
						if v_u_144 == #v_u_141.spots then
							p_u_17.after(0.15, function()
								-- upvalues: (ref) v_u_81, (ref) p_u_137, (ref) v_u_141
								v_u_81(p_u_137, v_u_141, p_u_137.target)
							end)
						end
					end
				end)
			end,
			["hit"] = function(_, p174, _) -- name: hit
				-- upvalues: (copy) p_u_17, (ref) v_u_8, (ref) v_u_9
				p_u_17.burst("Impact", p174, v_u_8, 0.7)
				p_u_17.glint(p174, v_u_9, 3.5, 0.15)
			end
		},
		["celestial_gaze_r"] = {
			["loopSound"] = "Vortex",
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p175) -- name: cast
				-- upvalues: (copy) p_u_17, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7
				p_u_17.skillCast(p175, v_u_8, true)
				p_u_17.glint(p175.eye, v_u_9, 6, 0.22)
				local v176 = p175.eye + p175.dir * 1.5
				local v177 = v_u_8
				local v178 = p_u_17.sigil
				local v179 = p_u_17.facing
				local v180 = v_u_4.CurrentCamera
				local v181
				if v180 then
					local v182 = v180.CFrame.Position - v176
					v181 = v182.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v182.Unit
				else
					v181 = Vector3.new(0, 0, 1)
				end
				v178(v179(v176, v181), 1.8, v177, v_u_7.PetStar, 0.3, 8)
			end,
			["windup"] = function(p183, p184, p185) -- name: windup
				-- upvalues: (copy) p_u_17, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5
				local v_u_186 = p_u_17.ground(p184, 7)
				local v_u_187 = p_u_17.ground(p184, 1)
				local v_u_188 = p_u_17.ball(v_u_187, v_u_12, 1.3, 0)
				p_u_17.streak(v_u_188, v_u_8, v_u_9, 1, 0.2)
				p_u_17.animate(math.max(p185, 0.05), 0, function(p189)
					-- upvalues: (copy) v_u_188, (copy) v_u_187, (copy) v_u_186, (ref) v_u_1
					v_u_188.CFrame = CFrame.new(v_u_187:Lerp(v_u_186, p189))
					if p189 >= 1 then
						v_u_188.Transparency = 1
						v_u_1:AddItem(v_u_188, 0.25)
					end
				end)
				local v190 = v_u_9
				local v191 = p185 + 0.1
				local v192 = p_u_17.sigil
				local v193 = p_u_17.facing
				local v194 = v_u_4.CurrentCamera
				local v195
				if v194 then
					local v196 = v194.CFrame.Position - v_u_186
					v195 = v196.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v196.Unit
				else
					v195 = Vector3.new(0, 0, 1)
				end
				v192(v193(v_u_186, v195), 3, v190, v_u_7.PetStar, v191, 5)
				v_u_5.ring(p_u_17.ground(p184), v_u_8, p183.ability.radius, p185 + 0.15, v_u_7.Ring)
			end,
			["zone"] = function(p197, p_u_198, p_u_199) -- name: galaxyZone
				-- upvalues: (copy) p_u_17, (ref) v_u_4, (copy) v_u_103, (ref) v_u_11, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1
				local v_u_200 = p197.ability.radius
				local v201 = p197.lite
				local v_u_202 = p_u_17.ground(p_u_198, 7)
				local v203 = Vector3.new(0, 2.2, 0)
				local v204 = p_u_17.flatUnit
				local v205 = v_u_4.CurrentCamera
				local v206
				if v205 then
					local v207 = v205.CFrame.Position - v_u_202
					v206 = v207.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v207.Unit
				else
					v206 = Vector3.new(0, 0, 1)
				end
				local v208 = (v203 + v204(v206)).Unit
				local v_u_209 = p_u_17.facing(v_u_202, v208)
				local v_u_210 = {
					["plane"] = nil,
					["endAt"] = nil,
					["plane"] = v_u_209
				}
				v_u_103[p197] = v_u_210
				local v_u_211 = p_u_17.plate(p_u_17.ground(p_u_198, 0.07), v_u_200, v_u_11, 1, Enum.Material.SmoothPlastic)
				v_u_5.tween(v_u_211, 0.25, {
					["Transparency"] = 0.3
				})
				p_u_17.sigil(CFrame.new(p_u_17.ground(p_u_198, 0.14)), v_u_200, v_u_8, v_u_7.Ring, p_u_199, 0.3)
				local v_u_212 = p_u_17.ball(v_u_202, v_u_12, 2, 0)
				local v_u_213 = p_u_17.ball(v_u_202, v_u_8, 4.2, 0.45)
				local v_u_214 = p_u_17.ball(v_u_202, v_u_9, 7, 0.82)
				v_u_5.tween(v_u_212, p_u_199, {
					["Size"] = Vector3.new(3.4, 3.4, 3.4)
				}, Enum.EasingStyle.Linear)
				v_u_5.tween(v_u_213, p_u_199, {
					["Size"] = Vector3.new(6.5, 6.5, 6.5)
				}, Enum.EasingStyle.Linear)
				if p197.mine then
					p_u_17.light(v_u_212, v_u_8, 30)
				end
				local v_u_215 = { p_u_17.sigil(v_u_209, v_u_200 * 1.05, v_u_8, v_u_7.Swirl, p_u_199, -1.6), p_u_17.sigil(v_u_209 * CFrame.new(0, 0.12, 0), v_u_200 * 0.62, v_u_9, v_u_7.Swirl, p_u_199, -2.8) }
				if not v201 then
					local v216 = p_u_17.sigil
					local v217 = v_u_209 * CFrame.new(0, -0.12, 0)
					local v218 = v_u_200 * 1.15
					local v219 = v_u_10
					local v220 = v_u_7.Ring
					table.insert(v_u_215, v216(v217, v218, v219, v220, p_u_199, 0.6))
				end
				local v221 = v201 and 2 or 3
				local v222 = v_u_200 * 0.14
				local v223 = {
					v_u_12,
					v_u_9,
					v_u_8,
					v_u_9,
					v_u_10
				}
				local v224 = v201 and 6 or 11
				local v_u_225 = {}
				for v226 = 1, v221 do
					for v227 = 1, v224 do
						local v228 = (v227 - 0.6 + math.random() * 0.6) / v224
						local v229 = v222 + (v_u_200 - v222) * v228
						local v230 = (0.35 + math.random() * 0.6) * (1.2 - v228 * 0.5)
						local v231 = p_u_17.ball(v_u_202, v223[(v227 + v226) % #v223 + 1], v230, 0)
						v_u_1:AddItem(v231, p_u_199 + 1)
						local v232 = {
							["p"] = v231,
							["rho"] = v229
						}
						local v233 = v226 / v221 * 3.141592653589793 * 2
						local v234 = v229 / v222
						v232.theta = v233 + math.log(v234) * 1.7 + (math.random() - 0.5) * 0.3
						v232.h = (math.random() - 0.5) * 0.9
						v232.size = v230
						v232.phase = math.random() * 6
						table.insert(v_u_225, v232)
					end
				end
				local v_u_235 = os.clock()
				local v_u_236 = v_u_235
				p_u_17.runNow(function()
					-- upvalues: (ref) v_u_236, (copy) v_u_235, (copy) p_u_199, (copy) v_u_210, (copy) v_u_225, (copy) v_u_200, (copy) v_u_209
					local v237 = os.clock()
					local v238 = v237 - v_u_236
					local v239 = math.min(v238, 0.05)
					v_u_236 = v237
					local v240 = v237 - v_u_235
					local v241 = v240 / p_u_199
					local v242 = math.clamp(v241, 0, 1)
					local v243 = 1 - v242 ^ 1.6 * 0.42
					local v244 = v_u_210.endAt
					local v245
					if v244 then
						local v246 = (v237 - v244) / 0.12
						v245 = math.clamp(v246, 0, 1)
					else
						v245 = 0
					end
					local v247 = v243 * (1 - v245)
					local v248 = v242 * 2.8 + 0.8
					for _, v249 in v_u_225 do
						v249.theta = v249.theta + v239 * v248 * (1 + 1.3 * (1 - v249.rho / v_u_200))
						local v250 = v249.rho * v247
						local v251 = v249.p
						local v252 = v_u_209
						local v253 = CFrame.new
						local v254 = v249.theta
						local v255 = math.cos(v254) * v250
						local v256 = v249.h * (1 - v245)
						local v257 = v249.theta
						v251.CFrame = v252 * v253(v255, v256, math.sin(v257) * v250)
						local v258 = v249.p
						local v259 = Vector3.new(1, 1, 1) * v249.size
						local v260 = v240 * 7 + v249.phase
						v258.Size = v259 * (math.sin(v260) * 0.35 + 0.75)
					end
					if v245 < 1 then
						return v240 < p_u_199 + 0.5
					end
					for _, v261 in v_u_225 do
						v261.p:Destroy()
					end
					return false
				end)
				local v_u_262 = { p_u_17.loopAt("Charge", v_u_202, v_u_8, 1.4) }
				local v_u_263 = true
				if not v201 then
					task.spawn(function()
						-- upvalues: (copy) p_u_199, (ref) v_u_263, (ref) p_u_17, (copy) v_u_202, (ref) v_u_9, (copy) v_u_200, (copy) p_u_198, (ref) v_u_4, (ref) v_u_7
						local v264 = os.clock() + p_u_199
						local v265 = 0
						while v_u_263 and os.clock() < v264 do
							p_u_17.inward(v_u_202, v_u_9, 3, v_u_200 * 1.1, 0.35)
							if v265 <= os.clock() then
								v265 = os.clock() + 0.4
								for _ = 1, 2 do
									local v266 = math.random() * 3.141592653589793 * 2
									local v267 = v_u_200
									local v268 = math.random()
									local v269 = v267 * math.sqrt(v268) * 0.9
									local v270 = p_u_17.ground
									local v271 = p_u_198
									local v272 = math.cos(v266) * v269
									local v273 = math.sin(v266) * v269
									local v274 = v270(v271 + Vector3.new(v272, 0, v273), 0.6)
									local v275 = v_u_9
									local v276 = p_u_17.sigil
									local v277 = p_u_17.facing
									local v278 = v_u_4.CurrentCamera
									local v279
									if v278 then
										local v280 = v278.CFrame.Position - v274
										v279 = v280.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v280.Unit
									else
										v279 = Vector3.new(0, 0, 1)
									end
									v276(v277(v274, v279), 0.7, v275, v_u_7.PetStar, 0.25, 4)
								end
							end
							task.wait(0.14)
						end
					end)
				end
				return function()
					-- upvalues: (ref) v_u_263, (copy) v_u_210, (copy) v_u_262, (copy) v_u_215, (ref) v_u_5, (copy) v_u_212, (copy) v_u_213, (copy) v_u_214, (ref) v_u_1, (copy) v_u_211
					v_u_263 = false
					v_u_210.endAt = os.clock()
					for _, v281 in v_u_262 do
						v281()
					end
					for _, v282 in v_u_215 do
						if not v282.Parent then
							continue
						end
						v_u_5.tween(v282, 0.12, {
							["Size"] = Vector3.new(0.2, 0.05, 0.2)
						}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					end
					for _, v283 in { v_u_212, v_u_213, v_u_214 } do
						v_u_5.tween(v283, 0.12, {
							["Size"] = Vector3.new(0.6, 0.6, 0.6)
						}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						v_u_1:AddItem(v283, 0.13)
					end
					v_u_5.tween(v_u_211, 0.5, {
						["Transparency"] = 1
					})
					v_u_1:AddItem(v_u_211, 0.55)
				end
			end,
			["finish"] = function(p284, p285) -- name: finish
				-- upvalues: (copy) p_u_17, (copy) v_u_103, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_9, (copy) v_u_53, (ref) v_u_7, (ref) v_u_5, (ref) v_u_11, (ref) v_u_6, (copy) v_u_108
				local v286 = p284.ability.radius
				local v287 = p_u_17.ground(p285, 7)
				local v288 = p_u_17.ground(p285)
				local v289 = v_u_103[p284]
				v_u_103[p284] = nil
				local v290
				if v289 then
					v290 = v289.plane
				else
					local v291 = Vector3.new(0, 2.2, 0)
					local v292 = p_u_17.flatUnit
					local v293 = v_u_4.CurrentCamera
					local v294
					if v293 then
						local v295 = v293.CFrame.Position - v287
						v294 = v295.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v295.Unit
					else
						v294 = Vector3.new(0, 0, 1)
					end
					local v296 = (v291 + v292(v294)).Unit
					v290 = p_u_17.facing(v287, v296)
				end
				p_u_17.pop(v287, v_u_12, 2, v286 * 3, 0.5, 0)
				p_u_17.pop(v287, v_u_8, 3, v286 * 2.2, 0.65, 0.35)
				p_u_17.burst("Flash", v287, v_u_8, 1.3, true)
				p_u_17.burst("Explosion", v287, v_u_8, v286 / 6)
				p_u_17.burst("Sparkle", v287, nil, 2)
				p_u_17.spikes(v287, v_u_9, p284.lite and 8 or 16, v286 * 1.8, 0.45)
				p_u_17.spikes(v287, v_u_8, p284.lite and 4 or 10, v286 * 1.4, 0.4, nil, nil, true)
				if not p284.lite then
					v_u_53(v287, 12, 60, 1.6, 0.9)
				end
				local v297 = p_u_17.sigil(v290, v286 * 0.5, v_u_9, v_u_7.Ring, 0.3, 0)
				local v298 = v_u_5.tween
				local v299 = {}
				local v300 = v286 * 6
				local v301 = v286 * 6
				v299.Size = Vector3.new(v300, 0.05, v301)
				v298(v297, 0.5, v299)
				p_u_17.burst("Shockwave", v288 + Vector3.new(0, 0.3, 0), v_u_8, v286 / 14)
				v_u_5.ring(v288, v_u_8, v286 * 1.5, 0.6)
				v_u_5.ring(v288, v_u_9, v286 * 1.8, 0.5, v_u_7.SpeedLines)
				p_u_17.mark(p285, v_u_11, v286 * 0.7, 1.6)
				p_u_17.mark(p285, v_u_8, v286 * 0.8, 2, v_u_7.CrackGlow, 0.15)
				v_u_6.play("Explosion", {
					["at"] = v288
				})
				if p284.mine then
					v_u_5.shake(0.6, 0.5)
					v_u_108()
				end
			end,
			["hit"] = function(_, p302, _) -- name: hit
				-- upvalues: (copy) p_u_17, (ref) v_u_8
				p_u_17.burst("Impact", p302, v_u_8, 0.6)
			end
		}
	}
	return v303
end