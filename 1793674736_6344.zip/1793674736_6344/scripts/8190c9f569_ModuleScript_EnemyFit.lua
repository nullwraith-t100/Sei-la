local v_u_7 = {
	["BOSS_SCALE"] = 1.3,
	["scale"] = function(p1, p2) -- name: scale
		-- upvalues: (copy) v_u_7
		if p2 then
			return not p1.boss and 1 or v_u_7.BOSS_SCALE
		else
			return p1.scale
		end
	end,
	["reach"] = function(p3, p4) -- name: reach
		-- upvalues: (copy) v_u_7
		return p3.reach * v_u_7.scale(p3, p4) / p3.scale
	end,
	["radius"] = function(p5, p6) -- name: radius
		-- upvalues: (copy) v_u_7
		return 1.4 * v_u_7.scale(p5, p6)
	end
}
return v_u_7