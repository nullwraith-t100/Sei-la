local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("C8D4FF")
local v_u_8 = Color3.fromHex("5A6BFF")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(150, 215, 255)
local v_u_11 = Color3.fromRGB(40, 52, 170)
local v_u_12 = Color3.fromRGB(10, 12, 34)
local v13 = Color3.fromRGB(205, 215, 255)
local v_u_14 = Color3.new(v13.R * 2.55, v13.G * 2.55, v13.B * 2.55)
local v15 = Color3.fromRGB(160, 180, 255)
local v_u_16 = Color3.new(v15.R * 2.35, v15.G * 2.35, v15.B * 2.35)
local v_u_17 = Enum.PartType.Ball
local v_u_18 = Enum.PartType.Cylinder
local v_u_19 = Enum.Material.ForceField
local v_u_20 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_39(p21, p22, p23, p24, p25) -- name: picture
	-- upvalues: (copy) v_u_4
	local v26 = Color3.new
	local v27 = p24.R
	local v28 = math.min(v27, 1)
	local v29 = p24.G
	local v30 = math.min(v29, 1)
	local v31 = p24.B
	local v32 = v26(v28, v30, (math.min(v31, 1)))
	local v33 = v_u_4.part
	local v34 = p22 * 2
	local v35 = p22 * 2
	local v36 = v33(Vector3.new(v34, 0.05, v35), p21, v32, {
		["transparency"] = 1
	})
	for _, v37 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v38 = Instance.new("Decal")
		v38.Face = v37
		v38.Texture = p23
		v38.Color3 = p24
		v38.Transparency = p25
		v38.Parent = v36
	end
	return v36
end
local function v_u_43(p40, p41) -- name: setAlpha
	for _, v42 in p40:GetChildren() do
		if not v42:IsA("Decal") then
			continue
		end
		v42.Transparency = p41
	end
end
return function(p_u_44)
	-- upvalues: (copy) v_u_3, (copy) v_u_39, (copy) v_u_1, (copy) v_u_43, (copy) v_u_6, (copy) v_u_10, (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_17, (copy) v_u_8, (copy) v_u_19, (copy) v_u_11, (copy) v_u_5, (copy) v_u_14, (copy) v_u_16, (copy) v_u_20, (copy) v_u_12, (copy) v_u_18
	local v45 = {}
	local function v_u_73(p_u_46, p_u_47, p_u_48, p49, p50, p_u_51, p_u_52, p53) -- name: flare
		-- upvalues: (ref) v_u_39, (ref) v_u_3, (copy) p_u_44, (ref) v_u_1, (ref) v_u_43
		local v_u_54 = p53 or 0
		local v_u_55 = math.random() * 3.141592653589793 * 2
		local v56 = v_u_39
		local v57 = v_u_3.CurrentCamera
		local v58
		if v57 then
			local v59 = v57.CFrame.Position - p_u_46
			v58 = v59.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v59.Unit
		else
			v58 = Vector3.new(0, 0, 1)
		end
		local v_u_60 = v56(p_u_44.facing(p_u_46 + v58 * 0.3, v58) * CFrame.Angles(0, v_u_55, 0), p_u_47, p49, p50, v_u_54)
		v_u_1:AddItem(v_u_60, p_u_51 + 0.1)
		p_u_44.animate(p_u_51, 0, function(p61)
			-- upvalues: (copy) v_u_60, (copy) p_u_47, (copy) p_u_48, (copy) p_u_46, (copy) v_u_55, (copy) p_u_51, (copy) p_u_52, (ref) v_u_3, (ref) p_u_44, (ref) v_u_43, (copy) v_u_54
			local v62 = v_u_60
			local v63 = p_u_47 + (p_u_48 - p_u_47) * (1 - (1 - p61) ^ 3)
			local v64 = math.max(v63, 0.03)
			local v65 = v64 * 2
			local v66 = v64 * 2
			v62.Size = Vector3.new(v65, 0.05, v66)
			local v67 = v_u_60
			local v68 = p_u_46
			local v69 = v_u_55 + p61 * p_u_51 * p_u_52
			local v70 = v_u_3.CurrentCamera
			local v71
			if v70 then
				local v72 = v70.CFrame.Position - v68
				v71 = v72.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v72.Unit
			else
				v71 = Vector3.new(0, 0, 1)
			end
			v67.CFrame = p_u_44.facing(v68 + v71 * 0.3, v71) * CFrame.Angles(0, v69, 0)
			v_u_43(v_u_60, v_u_54 + (1 - v_u_54) * p61 ^ 1.5)
			if p61 >= 1 then
				v_u_60:Destroy()
			end
		end)
	end
	local function v_u_94(p_u_74, p_u_75, p76) -- name: implode
		-- upvalues: (ref) v_u_39, (ref) v_u_3, (copy) p_u_44, (ref) v_u_6, (ref) v_u_10, (ref) v_u_1
		local v77 = v_u_39
		local v78 = v_u_3.CurrentCamera
		local v79
		if v78 then
			local v80 = v78.CFrame.Position - p_u_74
			v79 = v80.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v80.Unit
		else
			v79 = Vector3.new(0, 0, 1)
		end
		local v_u_81 = v77(p_u_44.facing(p_u_74 + v79 * 0.3, v79) * CFrame.Angles(0, 0, 0), p_u_75, v_u_6.ChikaSwirl, v_u_10, 0)
		v_u_1:AddItem(v_u_81, p76 + 0.1)
		p_u_44.animate(p76, 0, function(p82)
			-- upvalues: (copy) v_u_81, (copy) p_u_75, (copy) p_u_74, (ref) v_u_3, (ref) p_u_44
			local v83 = v_u_81
			local v84 = p_u_75 * (1 - p82 * p82) + 0.1
			local v85 = math.max(v84, 0.03)
			local v86 = v85 * 2
			local v87 = v85 * 2
			v83.Size = Vector3.new(v86, 0.05, v87)
			local v88 = v_u_81
			local v89 = p_u_74
			local v90 = -p82 * 9
			local v91 = v_u_3.CurrentCamera
			local v92
			if v91 then
				local v93 = v91.CFrame.Position - v89
				v92 = v93.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v93.Unit
			else
				v92 = Vector3.new(0, 0, 1)
			end
			v88.CFrame = p_u_44.facing(v89 + v92 * 0.3, v92) * CFrame.Angles(0, v90, 0)
			if p82 >= 1 then
				v_u_81:Destroy()
			end
		end)
	end
	local v_u_95 = { 0.55, 1, 1.45 }
	v45.chikaragan_a = {
		["cast"] = function(p96) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_10, (copy) p_u_44, (ref) v_u_9, (copy) v_u_73, (ref) v_u_6, (ref) v_u_7
			local v97 = p96.size
			local v98 = p96.eye + p96.dir * 1.2
			v_u_4.flash(v98, v_u_10, 3 * v97, 0.12)
			p_u_44.pop(v98, v_u_9, 1.2 * v97, 0.3 * v97, 0.1)
			if not p96.lite then
				v_u_73(v98, 1.6 * v97, 0.3 * v97, v_u_6.Ring, v_u_7, 0.12, 0, 0)
			end
		end,
		["shot"] = function(p99, p100) -- name: pulseShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_9, (ref) v_u_17, (ref) v_u_8, (copy) v_u_95, (ref) v_u_39, (ref) v_u_6, (ref) v_u_10, (copy) p_u_44, (ref) v_u_3
			local v_u_101 = p99.size
			local v_u_102 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p100, v_u_7, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_102, 3)
			local v103 = {
				["shape"] = v_u_17
			}
			local v_u_104 = { (v_u_4.part(Vector3.new(0.6, 0.6, 0.6) * v_u_101, p100, v_u_9, v103)) }
			if not p99.lite then
				local v105 = v_u_4.part
				local v106 = Vector3.new(2.1, 2.1, 2.1) * v_u_101
				local v107 = v_u_8
				local v108 = {
					["shape"] = nil,
					["transparency"] = 0.72,
					["shape"] = v_u_17
				}
				table.insert(v_u_104, v105(v106, p100, v107, v108))
			end
			local v_u_109 = {}
			for v110, v111 in v_u_95 do
				if p99.lite and v110 == 2 then
					continue
				end
				local v112 = v_u_39
				local v113 = v111 * v_u_101
				local v114 = v_u_6.Ring
				local v115
				if v110 == 2 then
					v115 = v_u_9
				else
					v115 = v_u_7
				end
				local v116 = v112(p100, v113, v114, v115, 0)
				table.insert(v_u_109, v116)
			end
			local v_u_117 = v_u_39(p100, 1.6 * v_u_101, v_u_6.ChikaSwirl, v_u_10, 0.15)
			for _, v118 in v_u_104 do
				v_u_1:AddItem(v118, 3)
			end
			for _, v119 in v_u_109 do
				v_u_1:AddItem(v119, 3)
			end
			v_u_1:AddItem(v_u_117, 3)
			p_u_44.streak(v_u_102, v_u_7, v_u_8, 1.4 * v_u_101, p99.lite and 0.12 or 0.2)
			if p99.mine then
				p_u_44.light(v_u_102, v_u_10, 9 * v_u_101)
			end
			local v_u_120 = false
			return {
				["place"] = function(p121, p122) -- name: place
					-- upvalues: (copy) v_u_102, (copy) v_u_104, (copy) v_u_109, (ref) v_u_95, (copy) v_u_101, (ref) v_u_3, (ref) p_u_44, (copy) v_u_117
					local v123 = p121.Position
					v_u_102.CFrame = p121
					for _, v124 in v_u_104 do
						v124.CFrame = p121
					end
					for v125, v126 in v_u_109 do
						local v127 = (p122 * 5 + v125 / #v_u_109) % 1
						local v128 = v_u_95[v125] * v_u_101 * (1.15 - v127 * 0.3)
						local v129 = math.max(v128, 0.03)
						local v130 = v129 * 2
						local v131 = v129 * 2
						v126.Size = Vector3.new(v130, 0.05, v131)
						local v132 = 0.5 * v_u_101 + v125 * 0.02
						local v133 = v_u_3.CurrentCamera
						local v134
						if v133 then
							local v135 = v133.CFrame.Position - v123
							v134 = v135.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v135.Unit
						else
							v134 = Vector3.new(0, 0, 1)
						end
						v126.CFrame = p_u_44.facing(v123 + v134 * (v132 or 0.3), v134) * CFrame.Angles(0, 0, 0)
					end
					local v136 = v_u_117
					local v137 = -p122 * 14
					local v138 = 0.45 * v_u_101
					local v139 = v_u_3.CurrentCamera
					local v140
					if v139 then
						local v141 = v139.CFrame.Position - v123
						v140 = v141.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v141.Unit
					else
						v140 = Vector3.new(0, 0, 1)
					end
					v136.CFrame = p_u_44.facing(v123 + v140 * (v138 or 0.3), v140) * CFrame.Angles(0, v137, 0)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_120, (copy) v_u_102, (ref) v_u_1, (copy) v_u_104, (copy) v_u_109, (copy) v_u_117
					if not v_u_120 then
						v_u_120 = true
						local v142 = v_u_102:FindFirstChildWhichIsA("PointLight")
						if v142 then
							v142:Destroy()
						end
						v_u_1:AddItem(v_u_102, 0.3)
						for _, v143 in v_u_104 do
							v143:Destroy()
						end
						for _, v144 in v_u_109 do
							v144:Destroy()
						end
						v_u_117:Destroy()
					end
				end
			}
		end,
		["impact"] = function(p_u_145, p_u_146) -- name: pulseImpact
			-- upvalues: (copy) v_u_94, (copy) p_u_44, (copy) v_u_73, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_19, (ref) v_u_4, (ref) v_u_10
			local v_u_147 = p_u_145.size
			v_u_94(p_u_146, 2.2 * v_u_147, 0.1)
			p_u_44.after(0.08, function()
				-- upvalues: (copy) p_u_145, (ref) v_u_73, (copy) p_u_146, (copy) v_u_147, (ref) v_u_6, (ref) v_u_7, (ref) p_u_44, (ref) v_u_9, (ref) v_u_8, (ref) v_u_19
				for v148 = 1, p_u_145.lite and 2 or 3 do
					v_u_73(p_u_146, 0.6 * v_u_147, (v148 * 1.1 + 2.2) * v_u_147, v_u_6.Ring, v_u_7, v148 * 0.05 + 0.16, 0, 0)
				end
				p_u_44.pop(p_u_146, v_u_9, 1 * v_u_147, 2.4 * v_u_147, 0.14)
				if not p_u_145.lite then
					p_u_44.pop(p_u_146, v_u_8, 1 * v_u_147, 5.5 * v_u_147, 0.26, 0.1, v_u_19)
				end
			end)
			p_u_44.pop(p_u_146, v_u_8, 1.4 * v_u_147, 4 * v_u_147, 0.2, 0.4)
			v_u_4.ring(p_u_44.ground(p_u_146), v_u_7, p_u_145.ability.radius * v_u_147 * 0.8, 0.3, v_u_6.Ring)
			p_u_44.burst("Impact", p_u_146, v_u_10, 0.9 * v_u_147)
			p_u_44.hitSound(p_u_146)
		end,
		["hit"] = p_u_44.simpleHit(v_u_10, 0.6)
	}
	local v_u_149 = {
		{
			["at"] = 0,
			["lift"] = 2.6
		},
		{
			["at"] = 0.17,
			["lift"] = 2
		},
		{
			["at"] = 0.34,
			["lift"] = 1.4
		}
	}
	local v_u_150 = {}
	local v_u_151 = {}
	local function v_u_212(p152, p153) -- name: ripple
		-- upvalues: (copy) p_u_44, (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (copy) v_u_150, (copy) v_u_151, (copy) v_u_149, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3, (ref) v_u_39, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_43, (ref) v_u_5
		local v_u_154 = p152.ability.radius
		local v_u_155 = p_u_44.ground(p153, 0)
		local v_u_156 = p152.lite
		local v_u_157 = {}
		for v158, v159 in v_u_156 and {
			{
				["r"] = 5,
				["n"] = 6
			},
			{
				["r"] = 11,
				["n"] = 12
			}
		} or {
			{
				["r"] = 3.5,
				["n"] = 6
			},
			{
				["r"] = 6.8,
				["n"] = 10
			},
			{
				["r"] = 10.1,
				["n"] = 14
			},
			{
				["r"] = 13.4,
				["n"] = 18
			}
		} do
			local v160 = v158 * 0.4
			for v161 = 1, v159.n do
				local v162 = v160 + (v161 - 1) / v159.n * 3.141592653589793 * 2
				local v163 = math.cos(v162)
				local v164 = math.sin(v162)
				local v165 = Vector3.new(v163, 0, v164)
				local v166 = v_u_155 + v165 * v159.r + Vector3.new(0, 0.25, 0)
				local v167 = v159.r * 2
				local v168 = 3.141592653589793 / v159.n
				local v169 = v167 * math.sin(v168) * 0.82
				local v170 = math.min(v169, 3)
				local v171 = v_u_4.part(Vector3.new(v170, 0.45, 2.4), CFrame.lookAt(v166, v166 + v165), v_u_11, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v171, 1.3499999999999999)
				local v172 = {
					["p"] = v171,
					["at"] = v166,
					["d"] = v159.r,
					["out"] = v165
				}
				table.insert(v_u_157, v172)
			end
		end
		local v_u_173 = v_u_154 / 0.42
		local v_u_174 = os.clock()
		p_u_44.runNow(function()
			-- upvalues: (copy) v_u_174, (ref) v_u_150, (ref) v_u_151, (copy) v_u_157, (ref) v_u_149, (copy) v_u_173, (ref) v_u_8, (ref) v_u_9, (ref) v_u_3
			local v175 = os.clock() - v_u_174
			table.clear(v_u_150)
			table.clear(v_u_151)
			local v176 = (v175 - 0.8499999999999999) / 0.3
			local v177 = math.clamp(v176, 0, 1)
			local v178 = v175 / 0.08
			local v179 = math.clamp(v178, 0, 1)
			for _, v180 in v_u_157 do
				local v181 = 0
				local v182 = 0
				for _, v183 in v_u_149 do
					local v184 = (v175 - v183.at - v180.d / v_u_173) / 0.3
					if v184 <= 0 or v184 >= 1 then
						continue
					end
					local v185 = v184 * 3.141592653589793
					local v186 = math.sin(v185)
					local v187 = v183.lift * v186
					v181 = math.max(v181, v187)
					v182 = math.max(v182, v186)
				end
				local v188 = v181 * 0.22
				v180.p.Color = v_u_8:Lerp(v_u_9, v182 * 0.85)
				v180.p.Transparency = 1 - v179 * 0.7 + v177 * 0.7
				local v189 = v_u_150
				local v190 = v180.p
				table.insert(v189, v190)
				local v191 = v_u_151
				local v192 = CFrame.lookAt(v180.at + Vector3.new(0, 1, 0) * v181, v180.at + Vector3.new(0, 1, 0) * v181 + v180.out) * CFrame.Angles(v188, 0, 0)
				table.insert(v191, v192)
			end
			v_u_3:BulkMoveTo(v_u_150, v_u_151, Enum.BulkMoveMode.FireCFrameChanged)
			if v175 < 1.15 then
				return true
			end
			for _, v193 in v_u_157 do
				v193.p:Destroy()
			end
			return false
		end)
		for v_u_194, v195 in v_u_149 do
			p_u_44.after(v195.at, function()
				-- upvalues: (ref) v_u_39, (copy) v_u_155, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) v_u_156, (copy) v_u_194, (ref) v_u_10, (ref) p_u_44, (copy) v_u_154, (ref) v_u_43, (ref) v_u_4, (ref) v_u_8, (ref) v_u_5
				local v_u_196 = v_u_39(CFrame.new(v_u_155 + Vector3.new(0, 0.6, 0)), 1, v_u_6.Ring, v_u_7, 0)
				v_u_1:AddItem(v_u_196, 0.62)
				local v_u_197
				if v_u_156 or v_u_194 ~= 1 then
					v_u_197 = nil
				else
					v_u_197 = v_u_39(CFrame.new(v_u_155 + Vector3.new(0, 0.5, 0)), 1, v_u_6.ChikaSwirl, v_u_10, 0.2)
					v_u_1:AddItem(v_u_197, 0.62)
				end
				p_u_44.animate(0.52, 0, function(p198)
					-- upvalues: (ref) v_u_154, (copy) v_u_196, (ref) v_u_43, (ref) v_u_197, (ref) v_u_155
					local v199 = v_u_154 * 1.1 - 1
					local v200 = p198 * 0.52 / 0.42
					local v201 = 1 + v199 * math.min(v200, 1.1)
					local v202 = v_u_196
					local v203 = math.max(v201, 0.03)
					local v204 = v203 * 2
					local v205 = v203 * 2
					v202.Size = Vector3.new(v204, 0.05, v205)
					v_u_43(v_u_196, p198 ^ 2)
					local v206 = v_u_197
					if v206 then
						local v207 = v201 * 0.9
						local v208 = math.max(v207, 0.03)
						local v209 = v208 * 2
						local v210 = v208 * 2
						v206.Size = Vector3.new(v209, 0.05, v210)
						v206.CFrame = CFrame.new(v_u_155 + Vector3.new(0, 0.5, 0)) * CFrame.Angles(0, -p198 * 4, 0)
						v_u_43(v206, 0.2 + 0.8 * p198)
					end
					if p198 >= 1 then
						v_u_196:Destroy()
						if v206 then
							v206:Destroy()
						end
					end
				end)
				v_u_4.ring(v_u_155, v_u_8, v_u_154 * 1.15, 0.52, v_u_6.Shockwave)
				if v_u_194 > 1 then
					local v211 = {
						["at"] = nil,
						["volume"] = 0.35,
						["at"] = v_u_155
					}
					v_u_5.play("Hit", v211)
				end
			end)
		end
	end
	v45.chikaragan_e = {
		["cast"] = function(p213) -- name: cast
			-- upvalues: (copy) p_u_44, (ref) v_u_8, (copy) v_u_73, (ref) v_u_6, (ref) v_u_10
			p_u_44.skillCast(p213, v_u_8)
			if not p213.lite then
				local v214 = p213.size
				v_u_73(p213.eye + p213.dir * 1.2, 2.6 * v214, 0.4 * v214, v_u_6.ChikaSwirl, v_u_10, 0.2, -10)
			end
		end,
		["windup"] = function(p_u_215, p216, p217) -- name: windup
			-- upvalues: (copy) p_u_44, (ref) v_u_4, (ref) v_u_9, (ref) v_u_17, (ref) v_u_1, (ref) v_u_7, (ref) v_u_8, (ref) v_u_39, (ref) v_u_6
			local v_u_218 = p_u_44.ground(p216, 0)
			local v219 = math.max(p217, 0.1)
			local v220 = {
				["shape"] = v_u_17
			}
			local v_u_221 = v_u_4.part(Vector3.new(1.6, 1.6, 1.6), CFrame.new(v_u_218 + Vector3.new(0, 16, 0)), v_u_9, v220)
			v_u_1:AddItem(v_u_221, v219 + 0.1)
			p_u_44.streak(v_u_221, v_u_7, v_u_8, 1.2, 0.15)
			p_u_44.animate(v219, 0, function(p222)
				-- upvalues: (copy) v_u_221, (copy) v_u_218
				v_u_221.CFrame = CFrame.new(v_u_218 + Vector3.new(0, 1, 0) * (1 + 15 * (1 - p222 * p222)))
				if p222 >= 1 then
					v_u_221.Transparency = 1
				end
			end)
			local v_u_223 = v_u_39(CFrame.new(v_u_218 + Vector3.new(0, 0.4, 0)), p_u_215.ability.radius, v_u_6.Ring, v_u_7, 0.4)
			v_u_1:AddItem(v_u_223, v219 + 0.1)
			p_u_44.animate(v219, 0, function(p224)
				-- upvalues: (copy) v_u_223, (copy) p_u_215
				local v225 = v_u_223
				local v226 = p_u_215.ability.radius * (1 - 0.9 * p224)
				local v227 = math.max(v226, 0.03)
				local v228 = v227 * 2
				local v229 = v227 * 2
				v225.Size = Vector3.new(v228, 0.05, v229)
				if p224 >= 1 then
					v_u_223:Destroy()
				end
			end)
		end,
		["land"] = function(p230, p231) -- name: land
			-- upvalues: (copy) p_u_44, (copy) v_u_212, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_8, (ref) v_u_19, (ref) v_u_5
			local v232 = p230.ability.radius
			local v233 = p_u_44.ground(p231, 0)
			v_u_212(p230, p231)
			v_u_4.flash(v233 + Vector3.new(0, 1.5, 0), v_u_9, 8, 0.2)
			p_u_44.pop(v233 + Vector3.new(0, 1, 0), v_u_10, 2, v232 * 0.7, 0.3, 0.3)
			if not p230.lite then
				p_u_44.pop(v233 + Vector3.new(0, 1, 0), v_u_8, 2, v232 * 1.1, 0.4, 0.15, v_u_19)
				p_u_44.spikes(v233 + Vector3.new(0, 1, 0), v_u_9, 8, 9, 0.25, Vector3.new(0, 1, 0), 0.7)
			end
			p_u_44.burst("Shockwave", v233 + Vector3.new(0, 0.3, 0), v_u_8, v232 / 16)
			v_u_5.play("Crit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v233
			})
			if p230.mine then
				v_u_4.shake(0.35, 0.3)
			end
		end,
		["hit"] = function(p234, p235, _) -- name: hit
			-- upvalues: (copy) p_u_44, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6
			p_u_44.burst("Impact", p235, v_u_10, 0.7)
			if not p234.lite then
				p_u_44.thin(p_u_44.rod(p235, p235 + Vector3.new(0, 5, 0), 0.5, v_u_7, 0.2), 0.25)
				v_u_4.ring(p_u_44.ground(p235), v_u_7, 3, 0.25, v_u_6.Ring)
			end
		end
	}
	local v_u_236 = {}
	setmetatable(v_u_236, {
		["__mode"] = "k"
	})
	local function v_u_308(p237, p238) -- name: openWorm
		-- upvalues: (copy) p_u_44, (ref) v_u_39, (ref) v_u_9, (ref) v_u_6, (ref) v_u_14, (ref) v_u_16, (ref) v_u_10, (ref) v_u_4, (ref) v_u_20, (ref) v_u_12, (ref) v_u_18, (ref) v_u_1, (ref) v_u_43
		local v239 = p_u_44.ground(p238, 0)
		local v_u_240 = v239 + Vector3.new(0, 30, 0)
		local v241 = (p237.ability.duration or 2) + 3
		local v_u_242 = CFrame.new(v_u_240) * CFrame.Angles(3.141592653589793, 0, 0)
		local v_u_243 = v_u_39(v_u_242, 0.1, p_u_44.iris("chikaragan"), v_u_9, 0)
		local v_u_244 = {}
		local v_u_245 = {}
		for v246 = 1, 6 do
			local v247 = v_u_39
			local v248 = CFrame.new(v_u_240)
			local v249 = 0.1
			local v250 = v_u_6.Ring
			local v251
			if v246 % 2 == 1 then
				v251 = v_u_14
			else
				v251 = v_u_16
			end
			local v252 = v247(v248, v249, v250, v251, 0)
			table.insert(v_u_244, v252)
		end
		for _ = 1, p237.lite and 1 or 3 do
			local v253 = v_u_39(CFrame.new(v_u_240), 0.1, v_u_6.ChikaSwirl, v_u_10, 0.1)
			table.insert(v_u_245, v253)
		end
		local v_u_254 = v_u_4.part(Vector3.new(0.3, 1, 1), CFrame.new(v_u_240) * v_u_20, v_u_12, {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 1,
			["shape"] = v_u_18,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v_u_255 = v_u_39(CFrame.new(v_u_240), 0.1, v_u_6.Glow, v_u_14, 1)
		for _, v256 in { v_u_243, v_u_254, v_u_255 } do
			v_u_1:AddItem(v256, v241)
		end
		for _, v257 in v_u_244 do
			v_u_1:AddItem(v257, v241)
		end
		for _, v258 in v_u_245 do
			v_u_1:AddItem(v258, v241)
		end
		local v_u_259 = {
			["g"] = nil,
			["top"] = nil,
			["iris"] = nil,
			["rings"] = nil,
			["swirls"] = nil,
			["cap"] = nil,
			["far"] = nil,
			["born"] = nil,
			["opened"] = nil,
			["closing"] = nil,
			["g"] = v239,
			["top"] = v_u_240,
			["iris"] = v_u_243,
			["rings"] = v_u_244,
			["swirls"] = v_u_245,
			["cap"] = v_u_254,
			["far"] = v_u_255,
			["born"] = os.clock()
		}
		p_u_44.runNow(function()
			-- upvalues: (copy) v_u_259, (copy) v_u_243, (copy) v_u_254, (copy) v_u_255, (copy) v_u_244, (copy) v_u_245, (copy) v_u_242, (ref) v_u_43, (copy) v_u_240, (ref) v_u_20
			local v260 = os.clock()
			local v261 = v260 - v_u_259.born
			local v262 = v261 / 0.2
			local v263 = math.clamp(v262, 0, 1) - 1
			local v264 = v263 * 2.7 * v263 * v263 + 1 + v263 * 1.7 * v263
			local v265 = v_u_259.opened
			local v266
			if v265 then
				local v267 = (v260 - v265) / 0.4
				local v268 = math.clamp(v267, 0, 1) - 1
				v266 = v268 * 2.7 * v268 * v268 + 1 + v268 * 1.7 * v268
			else
				v266 = 0
			end
			local v269 = v_u_259.closing
			local v270
			if v269 then
				local v271 = (v260 - v269) / 0.15
				v270 = math.clamp(v271, 0, 1)
			else
				v270 = 0
			end
			if v270 >= 1 then
				for _, v272 in { v_u_243, v_u_254, v_u_255 } do
					v272:Destroy()
				end
				for _, v273 in v_u_244 do
					v273:Destroy()
				end
				for _, v274 in v_u_245 do
					v274:Destroy()
				end
				return false
			end
			local v275 = (1 - v270) * (1 - v270)
			local v276 = v_u_243
			local v277 = v264 * 9.775 * (1 - v266 * 0.6) * v275
			local v278 = math.max(v277, 0.03)
			local v279 = v278 * 2
			local v280 = v278 * 2
			v276.Size = Vector3.new(v279, 0.05, v280)
			v_u_243.CFrame = v_u_242 * CFrame.Angles(0, -v261 * 1.5, 0)
			v_u_43(v_u_243, v266 * 0.75)
			for v281, v282 in v_u_244 do
				local v283 = (v281 - 1) * 3.4 * v266 * v275
				local v284 = 0.88 ^ (v281 - 1) * 11.5 * math.max(v264, v266) * v275
				local v285 = (v261 * 2.5 + v281 * 0.17) % 1
				local v286 = math.max(v284, 0.03)
				local v287 = v286 * 2
				local v288 = v286 * 2
				v282.Size = Vector3.new(v287, 0.05, v288)
				v282.CFrame = CFrame.new(v_u_240 + Vector3.new(0, 1, 0) * v283) * CFrame.Angles(0, v261 * (v281 % 2 == 1 and 1 or -1), 0)
				v_u_43(v282, v281 == 1 and 0 or (not v265 and 1 or 0.15 + 0.6 * v285))
			end
			for v289, v290 in v_u_245 do
				local v291 = (v289 * 1.6 - 0.5) * 3.4 * v266 * v275
				local v292 = (0.9 - v289 * 0.14) * 11.5 * v266 * v275
				local v293 = math.max(v292, 0.03)
				local v294 = v293 * 2
				local v295 = v293 * 2
				v290.Size = Vector3.new(v294, 0.05, v295)
				v290.CFrame = CFrame.new(v_u_240 + Vector3.new(0, 1, 0) * v291) * CFrame.Angles(0, v261 * (v289 % 2 == 1 and -3 or 2.4), 0)
			end
			local v296 = v_u_240 + Vector3.new(0, 17, 0) * v266 * v275
			local v297 = v266 * 6.0689170432 * v275
			local v298 = v_u_254
			local v299 = v297 * 2.1
			local v300 = math.max(v299, 0.1)
			local v301 = v297 * 2.1
			local v302 = math.max(v301, 0.1)
			v298.Size = Vector3.new(0.3, v300, v302)
			v_u_254.CFrame = CFrame.new(v296 + Vector3.new(0, 0.4, 0)) * v_u_20
			v_u_254.Transparency = 1 - v266 * v275
			local v303 = v_u_255
			local v304 = v297 * 1.3
			local v305 = math.max(v304, 0.03)
			local v306 = v305 * 2
			local v307 = v305 * 2
			v303.Size = Vector3.new(v306, 0.05, v307)
			v_u_255.CFrame = CFrame.new(v296)
			v_u_43(v_u_255, 1 - v266 * v275)
			return true
		end)
		return v_u_259
	end
	local function v_u_376(p309, p310, p_u_311) -- name: pour
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_18, (ref) v_u_10, (ref) v_u_19, (ref) v_u_8, (ref) v_u_1, (ref) v_u_6, (copy) p_u_44, (ref) v_u_20, (ref) v_u_7
		local v_u_312 = p309.ability.radius
		local v_u_313 = p310.g
		local v_u_314 = p310.top
		local v_u_315 = p309.lite
		local v316 = p_u_311 + 1.5
		local v317 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_18
		}
		local v318 = {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0,
			["shape"] = v_u_18,
			["material"] = v_u_19
		}
		local v_u_319 = { v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_314), v_u_9, v317), (v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_314), v_u_10, v318)) }
		if not v_u_315 then
			local v320 = v_u_4.part
			local v321 = CFrame.new(v_u_314)
			local v322 = v_u_8
			local v323 = {
				["shape"] = nil,
				["transparency"] = 0.82,
				["shape"] = v_u_18
			}
			table.insert(v_u_319, v320(Vector3.new(1, 1, 1), v321, v322, v323))
		end
		local v_u_324 = { 2.6, 9.5, v_u_312 * 1.3 }
		for _, v325 in v_u_319 do
			v_u_1:AddItem(v325, v316)
		end
		local v_u_326 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_314), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_326, v316)
		local v327 = v_u_315 and 1 or 4
		local v_u_328 = {}
		for v329 = 1, v327 do
			local v330 = (v329 - 1) / v327 * 3.141592653589793 * 2
			local v331 = math.cos(v330)
			local v332 = math.sin(v330)
			local v333 = Vector3.new(v331, 0, v332) * (v329 == 1 and 0 or 3.2)
			local v334 = Instance.new("Attachment")
			v334.Parent = v_u_326
			v334.WorldPosition = v_u_314 + v333
			local v335 = Instance.new("Attachment")
			v335.Parent = v_u_326
			v335.WorldPosition = v_u_313 + v333 + Vector3.new(0, 0.5, 0)
			local v336 = Instance.new("Beam")
			v336.Attachment0 = v334
			v336.Attachment1 = v335
			v336.Texture = v_u_6.Beam
			v336.TextureMode = Enum.TextureMode.Wrap
			v336.TextureLength = 9
			v336.TextureSpeed = v329 + 5
			local v337 = ColorSequence.new
			local v338
			if v329 % 2 == 1 then
				v338 = v_u_9
			else
				v338 = v_u_10
			end
			v336.Color = v337(v338)
			v336.LightEmission = 1
			v336.LightInfluence = 0
			v336.FaceCamera = true
			v336.Segments = 1
			v336.Width0 = v329 == 1 and 7 or 3
			v336.Width1 = v329 == 1 and 8 or 3.5
			v336.Transparency = NumberSequence.new(0.2)
			v336.Parent = v_u_326
			table.insert(v_u_328, v336)
		end
		local v_u_339 = {
			["parts"] = nil,
			["beams"] = nil,
			["stopped"] = false,
			["parts"] = v_u_319,
			["beams"] = v_u_328
		}
		local v_u_340 = os.clock()
		local v_u_341 = false
		local v_u_342 = 0
		local v_u_343 = 0
		local v_u_344 = nil
		p_u_44.runNow(function()
			-- upvalues: (copy) v_u_340, (copy) v_u_339, (ref) v_u_344, (copy) v_u_328, (copy) v_u_314, (copy) v_u_313, (copy) v_u_319, (copy) v_u_326, (copy) v_u_324, (ref) v_u_20, (ref) v_u_341, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (copy) v_u_312, (ref) v_u_6, (ref) p_u_44, (ref) v_u_10, (copy) v_u_315, (ref) v_u_342, (ref) v_u_1, (ref) v_u_343, (copy) p_u_311
			local v345 = os.clock()
			local v346 = v345 - v_u_340
			if v_u_339.stopped and not v_u_344 then
				v_u_344 = v345
				for _, v347 in v_u_328 do
					v347.Enabled = false
				end
			end
			local v348 = v346 / 0.22
			local v349 = math.clamp(v348, 0, 1)
			local v350 = v_u_314.Y - (v_u_314.Y - v_u_313.Y) * v349 * v349
			local v351 = v_u_344
			local v352
			if v351 then
				local v353 = 1 - (v345 - v351) / 0.15
				v352 = math.max(v353, 0)
				if v352 <= 0 then
					for _, v354 in v_u_319 do
						v354:Destroy()
					end
					v_u_326:Destroy()
					return false
				end
			else
				v352 = 1
			end
			local v355 = v346 * 40
			local v356 = math.sin(v355) * 0.06 + 1
			for v357, v358 in v_u_319 do
				local v359 = v_u_314
				local v360 = v_u_324[v357] * v352 * v356
				local v361 = v359.Y - v350
				local v362 = math.max(v361, 0.1)
				local v363 = math.max(v360, 0.05)
				local v364 = math.max(v360, 0.05)
				v358.Size = Vector3.new(v362, v363, v364)
				v358.CFrame = CFrame.new(v359.X, v359.Y - v362 / 2, v359.Z) * v_u_20
			end
			if v349 >= 1 and not v_u_341 then
				v_u_341 = true
				v_u_4.flash(v_u_313 + Vector3.new(0, 2, 0), v_u_9, 14, 0.25)
				v_u_4.ring(v_u_313, v_u_7, v_u_312 * 1.3, 0.4, v_u_6.Shockwave)
				p_u_44.burst("Shockwave", v_u_313 + Vector3.new(0, 0.3, 0), v_u_10, v_u_312 / 14)
				p_u_44.spikes(v_u_313 + Vector3.new(0, 1, 0), v_u_9, v_u_315 and 5 or 12, v_u_312, 0.3, nil, nil, true)
			end
			if v349 >= 1 and not v351 then
				if v_u_342 <= v346 then
					v_u_342 = v346 + (v_u_315 and 0.15 or 0.05)
					local v365 = math.random() * 3.141592653589793 * 2
					local v366 = math.random() * 4.5
					local v367 = math.cos(v365) * v366
					local v368 = math.sin(v365) * v366
					local v_u_369 = Vector3.new(v367, 0, v368)
					local v370 = v_u_4.part
					local v371 = Vector3.new(0.35, 0.35, 7)
					local v372 = p_u_44.aimAt(v_u_314 + v_u_369, Vector3.new(-0, -1, -0))
					local v373
					if math.random() < 0.5 then
						v373 = v_u_9
					else
						v373 = v_u_10
					end
					local v_u_374 = v370(v371, v372, v373)
					v_u_1:AddItem(v_u_374, 0.3)
					p_u_44.animate(0.22, 0, function(p375)
						-- upvalues: (copy) v_u_374, (ref) p_u_44, (ref) v_u_314, (copy) v_u_369, (ref) v_u_313
						v_u_374.CFrame = p_u_44.aimAt(v_u_314 + v_u_369 - Vector3.new(0, 1, 0) * (v_u_314.Y - v_u_313.Y) * p375, Vector3.new(-0, -1, -0))
						if p375 >= 1 then
							v_u_374:Destroy()
						end
					end)
				end
				if v_u_343 <= v346 then
					v_u_343 = v346 + 0.2
					v_u_4.ring(v_u_313, v_u_7, v_u_312 * 0.85, 0.3, v_u_6.Ring)
					if not v_u_315 then
						p_u_44.spikes(v_u_313 + Vector3.new(0, 1, 0), v_u_9, 3, 7, 0.25, Vector3.new(0, 1, 0), 1.3)
					end
				end
			end
			return v346 < p_u_311 + 1
		end)
		return v_u_339
	end
	local function v_u_388(p_u_377, p378) -- name: surge
		-- upvalues: (ref) v_u_39, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1, (copy) p_u_44, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_10
		local v_u_379 = p378.g
		local v_u_380 = p378.top
		local v_u_381 = v_u_39(CFrame.new(v_u_380), 6, v_u_6.Ring, v_u_9, 0)
		v_u_1:AddItem(v_u_381, 0.3)
		p_u_44.animate(0.18, 0, function(p382)
			-- upvalues: (copy) v_u_381, (copy) v_u_380, (copy) v_u_379, (ref) v_u_4, (ref) v_u_8, (copy) p_u_377, (ref) v_u_6, (ref) p_u_44, (ref) v_u_7, (ref) v_u_10
			v_u_381.CFrame = CFrame.new(v_u_380:Lerp(v_u_379 + Vector3.new(0, 1, 0), p382 * p382))
			local v383 = v_u_381
			local v384 = 6 + 3 * p382
			local v385 = math.max(v384, 0.03)
			local v386 = v385 * 2
			local v387 = v385 * 2
			v383.Size = Vector3.new(v386, 0.05, v387)
			if p382 >= 1 then
				v_u_381:Destroy()
				v_u_4.ring(v_u_379, v_u_8, p_u_377.ability.radius * 1.2, 0.35, v_u_6.Shockwave)
				p_u_44.pop(v_u_379 + Vector3.new(0, 1.5, 0), v_u_7, 4, 12, 0.22, 0.4)
				if not p_u_377.lite then
					p_u_44.inward(v_u_379 + Vector3.new(0, 1, 0), v_u_10, 6, p_u_377.ability.radius, 0.3)
				end
				if p_u_377.mine then
					v_u_4.shake(0.12, 0.12)
				end
			end
		end)
	end
	local function v_u_394(p389, p390) -- name: blast
		-- upvalues: (copy) p_u_44, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_19, (ref) v_u_10, (ref) v_u_7, (ref) v_u_6, (ref) v_u_12, (ref) v_u_11, (ref) v_u_5
		local v391 = p389.ability.radius
		local v392 = p_u_44.ground(p390, 0)
		local v393 = p389.lite
		v_u_4.flash(v392 + Vector3.new(0, 30, 0), v_u_9, 16, 0.2)
		v_u_4.flash(v392 + Vector3.new(0, 3, 0), v_u_9, v391 * 1.6, 0.25)
		p_u_44.pop(v392 + Vector3.new(0, 2, 0), v_u_8, 4, v391 * 2.4, 0.55, 0.15, v_u_19)
		p_u_44.pop(v392 + Vector3.new(0, 2, 0), v_u_10, 3, v391 * 1.4, 0.35, 0.35)
		p_u_44.dome(v392, v391 * 1.3, v_u_7, 0.5)
		v_u_4.ring(v392, v_u_9, v391 * 1.5, 0.5, v_u_6.Shockwave)
		v_u_4.ring(v392, v_u_8, v391 * 1.8, 0.65, v_u_6.Ring)
		p_u_44.burst("Shockwave", v392 + Vector3.new(0, 0.3, 0), v_u_7, v391 / 12)
		p_u_44.burst("Explosion", v392 + Vector3.new(0, 2, 0), v_u_8, 2)
		p_u_44.chunks(v392 + Vector3.new(0, 1, 0), { v_u_12, v_u_11, v_u_7 }, v393 and 6 or 14, 55, 1.2, 1.2, false, 1)
		p_u_44.spikes(v392 + Vector3.new(0, 2, 0), v_u_9, v393 and 6 or 14, v391 * 1.6, 0.35, Vector3.new(0, 1, 0), 1)
		p_u_44.mark(v392, v_u_8, v391 * 1.1, 1, v_u_6.Glow, 0.3)
		v_u_5.play("Explosion", {
			["at"] = v392,
			["volume"] = p389.mine and 1 or 0.6
		})
		if p389.mine then
			v_u_4.shake(0.6, 0.5)
		end
	end
	v45.chikaragan_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p395) -- name: cast
			-- upvalues: (copy) p_u_44, (ref) v_u_8, (copy) v_u_73, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4
			p_u_44.skillCast(p395, v_u_8, true)
			local v396 = p395.size
			local v397 = p395.eye + p395.dir * 1.4
			v_u_73(v397, 3.6 * v396, 0.5 * v396, v_u_6.ChikaSwirl, v_u_10, 0.3, -12)
			for v398 = 1, p395.lite and 1 or 3 do
				v_u_73(v397, 0.6 * v396, (v398 * 1.4 + 2) * v396, v_u_6.Ring, v_u_7, v398 * 0.07 + 0.2, 0)
			end
			if p395.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p399, p400, p401) -- name: windup
			-- upvalues: (copy) v_u_308, (copy) v_u_236, (ref) v_u_4, (ref) v_u_9, (copy) p_u_44, (ref) v_u_8, (ref) v_u_6
			local v402 = v_u_308(p399, p400)
			v_u_236[p399] = v402
			v_u_4.flash(v402.top, v_u_9, 12, math.max(p401, 0.12) + 0.1)
			p_u_44.mark(v402.g, v_u_8, p399.ability.radius, p401 + 0.4, v_u_6.Glow, 0.4)
			if not p399.lite then
				p_u_44.inward(v402.top, v_u_9, 8, 18, (math.max(p401, 0.15)))
			end
		end,
		["zone"] = function(p_u_403, p404, p_u_405) -- name: zone
			-- upvalues: (copy) v_u_236, (copy) v_u_308, (copy) v_u_376, (copy) p_u_44, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (copy) v_u_388
			local v_u_406 = v_u_236[p_u_403] or v_u_308(p_u_403, p404)
			v_u_236[p_u_403] = nil
			v_u_406.opened = os.clock()
			local v_u_407 = v_u_376(p_u_403, v_u_406, p_u_405)
			p_u_44.mark(v_u_406.g, v_u_7, p_u_403.ability.radius, p_u_405 + 0.2, v_u_6.Glow, 0.3)
			if p_u_403.mine then
				v_u_4.shake(0.35, 0.35)
			end
			local v_u_408 = os.clock()
			local v_u_409 = 0.4
			p_u_44.runNow(function()
				-- upvalues: (copy) v_u_407, (copy) v_u_408, (ref) v_u_409, (ref) v_u_388, (copy) p_u_403, (copy) v_u_406, (copy) p_u_405
				if v_u_407.stopped then
					return false
				end
				local v410 = os.clock() - v_u_408
				if v_u_409 <= v410 then
					v_u_409 = v_u_409 + 0.4
					v_u_388(p_u_403, v_u_406)
				end
				return v410 < p_u_405 + 0.5
			end)
			return function()
				-- upvalues: (copy) v_u_407, (copy) v_u_406
				v_u_407.stopped = true
				v_u_406.closing = os.clock()
			end
		end,
		["finish"] = function(p411, p412) -- name: finish
			-- upvalues: (copy) v_u_394
			v_u_394(p411, p412)
		end,
		["hit"] = function(p413, p414, _) -- name: hit
			-- upvalues: (copy) p_u_44, (ref) v_u_10, (ref) v_u_9
			p_u_44.burst("Impact", p414, v_u_10, 0.8)
			if not p413.lite then
				p_u_44.glint(p414, v_u_9, 3, 0.14)
			end
		end
	}
	return v45
end