local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(14, 6, 8)
local v_u_6 = Color3.fromRGB(255, 132, 70)
local v_u_7 = CFrame.Angles(1.5707963267948966, 0, 0)
return function(p_u_8)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_1, (copy) v_u_5
	return {
		["w5_crimson_comet"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_3, (copy) p_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_1, (ref) v_u_5
			local v_u_11 = v_u_3.color(p10.color)
			local v12 = v_u_3.color(p10.color2)
			local v13 = p_u_9.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_15 = v_u_14 * 2.2
			local v_u_16 = 0
			local v_u_22 = p_u_8.group(p_u_9, function(p17, p18)
				-- upvalues: (copy) v_u_14
				local v19 = CFrame.new
				local v20 = v_u_14 * 0.85
				local v21 = p18 * 1.3
				return p17 * v19(0, v20 + math.sin(v21) * 0.08 * v_u_14, v_u_14 * 1.45) * CFrame.Angles(-0.12, 0, 0.3)
			end)
			local v23 = p_u_8.picture(v_u_15 * 2.9, v_u_4.Glow, v_u_11, 0.45)
			p_u_8.pin(p_u_9, v_u_22, v23, CFrame.new(0, 0, v_u_14 * -0.25) * v_u_7)
			p_u_8.fadeFromBehind(p_u_9, v23, 0.6)
			local v24 = p_u_8.picture(v_u_15 * 2.1, v_u_4.CometShuriken, v_u_11, 0.72)
			p_u_8.add(p_u_9, v24, function()
				-- upvalues: (copy) v_u_22, (copy) v_u_14, (ref) v_u_16, (ref) v_u_7
				return v_u_22.cf * CFrame.new(0, 0, v_u_14 * -0.08) * CFrame.Angles(0, 0, -v_u_16 + 0.4) * v_u_7
			end)
			local v25 = p_u_8.picture(v_u_15 * 2, v_u_4.CometShuriken, v_u_11, 0)
			p_u_8.add(p_u_9, v25, function()
				-- upvalues: (copy) v_u_22, (ref) v_u_16, (ref) v_u_7
				return v_u_22.cf * CFrame.Angles(0, 0, -v_u_16) * v_u_7
			end)
			p_u_8.pin(p_u_9, v_u_22, p_u_8.ball(v_u_14 * 0.5, v_u_11, 0), CFrame.new(0, 0, v_u_14 * 0.08))
			local function v36(p26) -- name: whirl
				-- upvalues: (copy) p_u_9, (ref) v_u_3, (ref) p_u_8, (copy) v_u_11, (ref) v_u_4, (copy) v_u_22, (copy) v_u_14, (ref) v_u_16, (copy) v_u_15, (ref) v_u_6, (ref) v_u_1
				local v27 = p_u_9.fx
				v_u_3.ring(p_u_8.feetAt(p_u_9, p26, 0.15), v_u_11, 5.5 * v27, 0.5, v_u_4.Ring)
				v_u_3.flash(v_u_22.cf.Position, v_u_11, v_u_14 * 3.4, 0.22)
				for v28 = 0, 3 do
					local v29 = v_u_16 + 0.7853981633974483 + v28 * 3.141592653589793 / 2
					local v30 = v_u_22.cf
					local v31 = math.cos(v29)
					local v32 = -math.sin(v29)
					local v33 = v30:VectorToWorldSpace((Vector3.new(v31, v32, 0)))
					local v34 = v_u_22.cf.Position + v33 * v_u_15 * 0.95
					local v35 = v_u_3.part(Vector3.new(0.18, 0.18, 1) * v_u_14, CFrame.lookAt(v34, v34 + v33), v_u_6)
					v_u_3.tween(v35, 0.35, {
						["CFrame"] = nil,
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = CFrame.lookAt(v34 + v33 * 2.6 * v_u_14, v34 + v33 * 3.6 * v_u_14),
						["Size"] = Vector3.new(0.05, 0.05, 0.4) * v_u_14
					})
					v_u_1:AddItem(v35, 0.4)
				end
			end
			local v_u_37 = p_u_8.throb(p_u_9, 3.4, 1.4, 1.6, v36)
			local v38 = p_u_9.ticks
			local function v40(_, _, p39)
				-- upvalues: (ref) v_u_16, (copy) v_u_37
				v_u_16 = v_u_16 + p39 * (5 + 22 * v_u_37())
			end
			table.insert(v38, v40)
			for v_u_41 = 1, 4 do
				local v_u_42 = (v_u_41 - 1) * 3.141592653589793 / 2
				local function v_u_53(p43, p44) -- name: at
					-- upvalues: (copy) v_u_42, (copy) v_u_41, (copy) v_u_14
					local v45 = v_u_42 + p44 * 2.3
					local v46 = CFrame.new
					local v47 = p43.Position
					local v48 = math.cos(v45) * 3.1
					local v49 = math.sin(v45) * 0.9 + -0.2
					local v50 = p44 * 1.7 + v_u_41
					local v51 = v49 + math.sin(v50) * 0.1
					local v52 = math.sin(v45) * 2.5
					return v46(v47 + Vector3.new(v48, v51, v52) * v_u_14)
				end
				local v_u_54 = p_u_8.ball(v_u_14 * 0.48, v_u_11, 0)
				p_u_8.add(p_u_9, v_u_54, function(p55, p56)
					-- upvalues: (copy) v_u_53, (copy) v_u_37, (copy) v_u_54, (copy) v_u_14
					local v57 = v_u_53(p55, p56)
					v_u_54.Size = Vector3.new(1, 1, 1) * (0.48 + 0.3 * v_u_37()) * v_u_14
					return v57
				end)
				p_u_8.add(p_u_9, p_u_8.dark(p_u_8.ball(v_u_14 * 0.74, v_u_5, 0, Enum.Material.SmoothPlastic)), p_u_8.behind(v_u_53, v_u_14 * 0.22))
				p_u_8.tail(v_u_54, v_u_11, v12, v_u_14 * 0.62, 0.65)
			end
			p_u_8.particles(p_u_9, "AuraMode", v_u_11, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
			p_u_8.particles(p_u_9, "Aura", v_u_11, {
				["rate"] = 0.7,
				["glow"] = 0.55,
				["only"] = nil,
				["only"] = { "Sparks" }
			})
		end
	}
end