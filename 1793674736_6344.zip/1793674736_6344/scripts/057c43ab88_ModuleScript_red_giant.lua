local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(255, 104, 34)
local v_u_5 = Color3.fromRGB(255, 66, 22)
local v_u_6 = Color3.fromRGB(255, 196, 86)
local v_u_7 = Color3.fromRGB(255, 238, 206)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4
	return {
		["w5_red_giant"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_3, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4
			local v_u_11 = p_u_9.character:GetScale()
			local v_u_12 = v_u_2.color(p10.color)
			local v_u_14 = p_u_8.throb(p_u_9, 4.6, 1.6, 0.9, function(p13)
				-- upvalues: (ref) v_u_2, (ref) p_u_8, (copy) p_u_9, (copy) v_u_12, (ref) v_u_3
				v_u_2.ring(p_u_8.feetAt(p_u_9, p13, 0.15), v_u_12, 5.5 * p_u_9.fx, 0.55, v_u_3.Shockwave)
			end)
			local v15 = 2.5 * v_u_11
			local v16 = p_u_9.headY + 1.6 * v_u_11
			local v17 = 1.6 * v_u_11
			local v_u_18 = Vector3.new(v15, v16, v17)
			local v_u_25 = p_u_8.group(p_u_9, function(p19, p20)
				-- upvalues: (copy) v_u_18, (copy) v_u_11
				local v21 = CFrame.new
				local v22 = v_u_18
				local v23 = p20 * 1.1
				local v24 = math.sin(v23) * 0.15 * v_u_11
				return v21(p19:PointToWorldSpace(v22 + Vector3.new(0, v24, 0)))
			end)
			local v_u_26 = 1.65 * v_u_11
			local v27 = p_u_9.ticks
			local function v28()
				-- upvalues: (ref) v_u_26, (copy) v_u_11, (copy) v_u_14
				v_u_26 = 1.65 * v_u_11 * (1 + 0.25 * v_u_14())
			end
			table.insert(v27, v28)
			local v_u_29 = p_u_8.ball(2.6 * v_u_11, v_u_5, 0)
			p_u_8.add(p_u_9, v_u_29, function()
				-- upvalues: (copy) v_u_14, (copy) v_u_29, (ref) v_u_26, (ref) v_u_5, (ref) v_u_7, (copy) v_u_25
				local v30 = v_u_14()
				v_u_29.Size = Vector3.new(1, 1, 1) * v_u_26 * 1.6
				v_u_29.Color = v_u_5:Lerp(v_u_7, v30)
				return v_u_25.cf
			end)
			p_u_8.fadeFromBehind(p_u_9, v_u_29, 0.5)
			local v_u_31 = p_u_8.ball(3.3 * v_u_11, v_u_12, 0.4)
			p_u_8.add(p_u_9, v_u_31, function()
				-- upvalues: (copy) v_u_31, (ref) v_u_26, (copy) v_u_25
				v_u_31.Size = Vector3.new(1, 1, 1) * v_u_26 * 2
				return v_u_25.cf
			end)
			p_u_8.fadeFromBehind(p_u_9, v_u_31, 0.5)
			local v_u_32 = p_u_8.picture(6.6 * v_u_11, v_u_3.Glow, v_u_12, 0.3)
			p_u_8.add(p_u_9, v_u_32, function(_, p33)
				-- upvalues: (copy) v_u_25, (ref) p_u_8, (ref) v_u_26, (copy) v_u_32
				local v34 = v_u_25.cf.Position
				local v35 = p_u_8.camPos() - v34
				local v36 = v35.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v35.Unit
				local v37 = v_u_26 * 4
				v_u_32.Size = Vector3.new(v37, 0.05, v37)
				return CFrame.lookAt(v34 - v36 * v_u_26 * 0.6, v34 + v36) * CFrame.Angles(1.5707963267948966, p33 * 0.4, 0)
			end)
			p_u_8.fadeFromBehind(p_u_9, v_u_32, 0.5)
			local v_u_38 = v_u_26
			for v39 = 1, 6 do
				local v_u_40 = {
					["dir"] = Vector3.new(0, 1, 0),
					["phase"] = nil,
					["cycle"] = nil,
					["last"] = 1,
					["phase"] = v39 / 6,
					["cycle"] = v39 % 3 * 0.12 + 0.55
				}
				local v_u_41 = p_u_8.ball(0.1, v_u_6, 0)
				p_u_8.add(p_u_9, v_u_41, function(_, p42)
					-- upvalues: (copy) v_u_25, (copy) v_u_40, (ref) p_u_8, (copy) v_u_11, (copy) v_u_41, (ref) v_u_6, (ref) v_u_7, (ref) v_u_38
					local v43 = v_u_25.cf.Position
					local v44 = (p42 + v_u_40.phase) % v_u_40.cycle / v_u_40.cycle
					if v44 < v_u_40.last then
						local v45 = math.random() - 0.5
						local v46 = math.random() - 0.5
						local v47 = math.random() - 0.5
						local v48 = Vector3.new(v45, v46, v47)
						local v49 = v_u_40
						local v50 = p_u_8.camPos() - v43
						v49.dir = ((v50.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v50.Unit) * 0.8 + v48 * 1.6).Unit
					end
					v_u_40.last = v44
					local v51 = 0.9 * v_u_11
					local v52 = 3.141592653589793 * v44
					local v53 = v51 * math.sin(v52)
					v_u_41.Size = Vector3.new(1, 1, 1) * math.max(v53, 0.05)
					v_u_41.Color = v_u_6:Lerp(v_u_7, v44)
					return CFrame.new(v43 + v_u_40.dir * v_u_38 * 1.02)
				end)
				p_u_8.fadeFromBehind(p_u_9, v_u_41, 0.5)
			end
			local v_u_54 = {}
			for v55 = 1, 2 do
				local v56 = Instance.new("Attachment")
				v56.Parent = v_u_29
				local v57 = Instance.new("Attachment")
				v57.Parent = v_u_29
				local v58 = p_u_8.ray(v56, v57, v_u_6, 0.35 * v_u_11, 0.35 * v_u_11, v_u_3.Beam)
				v58.Color = ColorSequence.new(v_u_6, v_u_12)
				v58.Segments = 10
				v58.LightEmission = 0.8
				local v59 = {
					["a0"] = v56,
					["a1"] = v57,
					["beam"] = v58,
					["seed"] = v55 * 2.3
				}
				table.insert(v_u_54, v59)
			end
			local v60 = p_u_9.ticks
			local function v82(_, p61)
				-- upvalues: (copy) v_u_25, (ref) p_u_8, (copy) v_u_54, (ref) v_u_38
				local v62 = v_u_25.cf.Position
				local v63 = p_u_8.camPos() - v62
				local v64 = v63.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v63.Unit
				local v65 = v64:Cross(Vector3.new(0, 1, 0))
				local v66 = v65.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v65.Unit
				for v67, v68 in v_u_54 do
					local v69 = p61 * 0.5 + v68.seed
					local v70 = Vector3.new(0, 1, 0) * math.sin(v69) * 0.7 + v66 * math.cos(v69) * 0.7
					local v71 = (v64 * 0.75 + v70).Unit
					local v72 = v71:Cross(v64)
					local v73
					if v72.Magnitude > 0.001 then
						v73 = v72.Unit
					else
						v73 = v66
					end
					local v74 = p61 * 2 + v67
					local v75 = math.sin(v74) * 0.08 + 0.38
					local v76 = (v71 + v73 * v75).Unit
					local v77 = (v71 - v73 * v75).Unit
					local v78 = v_u_38 * 0.8
					v68.a0.CFrame = CFrame.fromMatrix(v76 * v78, v76, v76:Cross(v73).Unit)
					v68.a1.CFrame = CFrame.fromMatrix(v77 * v78, v77, v77:Cross(v73).Unit)
					local v79 = v_u_38
					local v80 = p61 * 3 + v67
					local v81 = v79 * (math.sin(v80) * 0.15 + 0.75)
					v68.beam.CurveSize0 = v81
					v68.beam.CurveSize1 = -v81
				end
			end
			table.insert(v60, v82)
			local v_u_85 = p_u_8.group(p_u_9, function(p83, p84)
				-- upvalues: (copy) v_u_25
				return v_u_25.cf * p83.Rotation * CFrame.Angles(0.35, 0, 0.2) * CFrame.Angles(0, p84 * 0.9, 0)
			end)
			for v_u_86 = 0, 4 do
				local v87 = p_u_8.picture(1 * v_u_11, v_u_3.RedTomoe, v_u_12, 0)
				p_u_8.add(p_u_9, v87, function()
					-- upvalues: (copy) v_u_86, (ref) v_u_38, (copy) v_u_11, (copy) v_u_14, (copy) v_u_85, (ref) p_u_8, (copy) v_u_25
					local v88 = v_u_86 * 3.141592653589793 * 2 / 5
					local v89 = v_u_38 + 1.05 * v_u_11 * (1 + 0.6 * v_u_14())
					local v90 = v_u_85.cf
					local v91 = math.cos(v88) * v89
					local v92 = math.sin(v88) * v89
					local v93 = v90 * Vector3.new(v91, 0, v92)
					local v94 = CFrame.lookAt
					local v95 = p_u_8.camPos() - v93
					local v96 = v94(v93, v93 + (v95.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v95.Unit))
					local v97 = v93 - v_u_25.cf.Position
					local v98 = v97:Dot(v96.UpVector)
					local v99 = v97:Dot(v96.RightVector)
					local v100 = math.atan2(v98, v99)
					return v96 * CFrame.Angles(1.5707963267948966, v100, 0)
				end)
			end
			local v_u_101, v_u_102 = p_u_8.picture(3.6 * v_u_11, v_u_3.Ring, v_u_12, 1)
			p_u_8.add(p_u_9, v_u_101, function()
				-- upvalues: (copy) v_u_14, (copy) v_u_25, (ref) p_u_8, (ref) v_u_38, (copy) v_u_11, (copy) v_u_101, (copy) v_u_102
				local v103 = v_u_14()
				local v104 = v_u_25.cf.Position
				local v105 = p_u_8.camPos() - v104
				local v106 = v105.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v105.Unit
				local v107 = (v_u_38 + 4.5 * v_u_11 * (1 - v103)) * 2.2
				v_u_101.Size = Vector3.new(v107, 0.05, v107)
				for _, v108 in v_u_102 do
					v108.Transparency = v103 <= 0 and 1 or 1 - 0.85 * v103
				end
				return CFrame.lookAt(v104, v104 + v106) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			p_u_8.particles(p_u_9, "Fire", v_u_4, {
				["rate"] = 0.45,
				["glow"] = 0.6,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Embers" },
				["at"] = v_u_18
			})
			p_u_8.particles(p_u_9, "AuraMode", v_u_12, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end