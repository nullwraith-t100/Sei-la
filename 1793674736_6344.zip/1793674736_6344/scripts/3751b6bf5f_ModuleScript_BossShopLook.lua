local v_u_1 = game:GetService("RunService")
local v_u_2 = require(script.Parent.StoreLook)
local v_u_3 = {}
local function v7(p4, p5, p6) -- name: rgb
	return Color3.fromRGB(p4, p5, p6)
end
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.new(0, 0, 0)
local v10 = {
	Color3.fromHSV(0, 0.7, 1),
	Color3.fromHSV(0.12, 0.75, 1),
	Color3.fromHSV(0.3, 0.7, 1),
	Color3.fromHSV(0.52, 0.75, 1),
	Color3.fromHSV(0.75, 0.6, 1),
	Color3.fromHSV(0.9, 0.65, 1)
}
local v_u_11 = {
	["genin"] = {
		["card"] = { Color3.fromRGB(130, 238, 112), v7(22, 150, 62) },
		["stroke"] = Color3.fromRGB(8, 78, 32),
		["text"] = {
			Color3.fromRGB(240, 255, 232),
			Color3.fromRGB(160, 255, 140),
			Color3.fromRGB(60, 225, 100),
			v7(160, 255, 140)
		}
	},
	["jonin"] = {
		["card"] = { Color3.fromRGB(108, 214, 255), v7(26, 96, 238) },
		["stroke"] = Color3.fromRGB(6, 36, 126),
		["text"] = {
			Color3.fromRGB(240, 252, 255),
			Color3.fromRGB(140, 228, 255),
			Color3.fromRGB(60, 168, 255),
			v7(140, 228, 255)
		}
	},
	["kage"] = {
		["card"] = nil,
		["stroke"] = nil,
		["text"] = nil,
		["gloss"] = true,
		["card"] = { Color3.fromRGB(198, 122, 255), v7(100, 34, 210) },
		["stroke"] = Color3.fromRGB(255, 196, 48),
		["text"] = {
			Color3.fromRGB(255, 255, 225),
			Color3.fromRGB(255, 224, 70),
			Color3.fromRGB(255, 160, 0),
			v7(255, 224, 70)
		}
	},
	["mythical"] = {
		["card"] = nil,
		["stroke"] = nil,
		["text"] = nil,
		["rainbow"] = true,
		["gloss"] = true,
		["card"] = { Color3.fromRGB(255, 61, 110), v7(255, 196, 50) },
		["stroke"] = v_u_8,
		["text"] = v10
	},
	["coins"] = {
		["card"] = nil,
		["stroke"] = nil,
		["text"] = nil,
		["gloss"] = true,
		["card"] = { Color3.fromRGB(255, 214, 72), v7(242, 110, 20) },
		["stroke"] = Color3.fromRGB(110, 44, 0),
		["text"] = {
			Color3.fromRGB(255, 255, 225),
			Color3.fromRGB(255, 222, 60),
			Color3.fromRGB(255, 56, 40),
			v7(255, 222, 60)
		}
	},
	["luck"] = {
		["card"] = nil,
		["stroke"] = nil,
		["text"] = nil,
		["gloss"] = true,
		["card"] = { Color3.fromRGB(96, 236, 128), v7(8, 128, 84) },
		["stroke"] = Color3.fromRGB(255, 196, 48),
		["text"] = {
			Color3.fromRGB(255, 255, 225),
			Color3.fromRGB(255, 230, 90),
			Color3.fromRGB(160, 255, 120),
			v7(255, 230, 90)
		}
	}
}
local v_u_12 = {
	Color3.fromRGB(255, 255, 225),
	Color3.fromRGB(255, 222, 60),
	Color3.fromRGB(255, 56, 40),
	v7(255, 222, 60)
}
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = {}
local function v_u_26(p16, p17, p18) -- name: rainbowAt
	-- upvalues: (copy) v_u_2, (copy) v_u_9
	local v19 = v_u_2.rainbow(p16, p17)
	if p18 <= 0 then
		return v19
	end
	local v20 = {}
	for _, v21 in v19.Keypoints do
		local v22 = ColorSequenceKeypoint.new
		local v23 = v21.Time
		local v24 = v21.Value
		local v25 = v_u_9
		table.insert(v20, v22(v23, v24:Lerp(v25, p18)))
	end
	return ColorSequence.new(v20)
end
local function v_u_29(p27) -- name: gradientOf
	for _, v28 in p27:GetChildren() do
		if not v28:IsA("UIGradient") or v28.Name == "TitlePaint" then
			continue
		end
		return v28
	end
	return nil
end
local function v_u_33(p30) -- name: strokesOf
	local v31 = {}
	for _, v32 in p30:GetChildren() do
		if not v32:IsA("UIStroke") then
			continue
		end
		table.insert(v31, v32)
	end
	return v31
end
local function v_u_40(p34, p35) -- name: setGloss
	-- upvalues: (copy) v_u_15, (copy) v_u_2
	local v36 = v_u_15[p34]
	if p35 and not v36 then
		local v37 = v_u_2.gloss(p34)
		local v38 = v37.Parent
		if v38 and v38:IsA("GuiObject") then
			local v39 = p34.ZIndex
			v38.ZIndex = math.max(v39, 1) + 1
			v_u_15[p34] = {
				["band"] = v37,
				["sheet"] = v38
			}
			return
		end
	elseif not p35 and v36 then
		v36.sheet:Destroy()
		v_u_15[p34] = nil
	end
end
function v_u_3.card(p41, p42, p43, p44) -- name: card
	-- upvalues: (copy) v_u_11, (copy) v_u_29, (copy) v_u_8, (copy) v_u_26, (copy) v_u_9, (copy) v_u_33, (copy) v_u_13, (copy) v_u_40
	local v45 = v_u_11[p42] or v_u_11.genin
	local v46 = p43 or 0
	local v47 = v_u_29(p41)
	p41.BackgroundColor3 = v_u_8
	local v48 = {
		["paint"] = nil,
		["ring"] = nil,
		["dim"] = nil,
		["dim"] = v46
	}
	if v47 then
		if v45.rainbow then
			v47.Rotation = -25
			v47.Color = v_u_26(os.clock() * 0.12, 0.62, v46)
			v48.paint = v47
		else
			v47.Rotation = 90
			v47.Color = ColorSequence.new(v45.card[1]:Lerp(v_u_9, v46), v45.card[2]:Lerp(v_u_9, v46))
		end
	end
	for _, v49 in v_u_33(p41) do
		if v45.rainbow then
			v49.Color = v_u_8
			local v50 = v49:FindFirstChild("Rainbow")
			if not (v50 and v50:IsA("UIGradient")) then
				v50 = Instance.new("UIGradient")
				v50.Name = "Rainbow"
				v50.Parent = v49
			end
			v50.Color = v_u_26(os.clock() * 0.12, 1, v46)
			v48.ring = v50
		else
			local v51 = v49:FindFirstChild("Rainbow")
			if v51 then
				v51:Destroy()
			end
			v49.Color = v45.stroke:Lerp(v_u_9, v46)
		end
	end
	if v48.paint or v48.ring then
		v_u_13[p41] = v48
	else
		v_u_13[p41] = nil
	end
	local v52 = v_u_40
	local v53
	if p44 == false or v45.gloss ~= true then
		v53 = false
	else
		v53 = v46 <= 0
	end
	v52(p41, v53)
end
function v_u_3.text(p54, p55, p56) -- name: text
	-- upvalues: (copy) v_u_11, (copy) v_u_3
	local v57 = v_u_11[p55] or v_u_11.genin
	v_u_3.palette(p54, v57.text, p56)
end
function v_u_3.palette(p58, p59, p60) -- name: palette
	-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_14
	p58.TextColor3 = v_u_8
	local v61 = p58:FindFirstChild("TitlePaint")
	if not (v61 and v61:IsA("UIGradient")) then
		v61 = Instance.new("UIGradient")
	end
	v61.Name = "TitlePaint"
	if p60 then
		v61.Rotation = 90
		v61.Color = v_u_2.spread({ p59[1], p59[2], p59[3] or p59[2] })
		v_u_14[p58] = nil
	else
		v61.Rotation = 0
		v61.Color = v_u_2.flowing(p59, 0, 1, 0, nil)
		v_u_14[p58] = {
			["paint"] = v61,
			["palette"] = p59,
			["label"] = p58
		}
	end
	v61.Parent = p58
end
function v_u_3.title(p62) -- name: title
	-- upvalues: (copy) v_u_3, (copy) v_u_12
	v_u_3.palette(p62, v_u_12)
end
function v_u_3.tab(p63, p64, p65) -- name: tab
	-- upvalues: (copy) v_u_3
	v_u_3.card(p63, p64, p65 and 0 or 0.45, false)
	local v66 = p63:FindFirstChild("TextLabel")
	if v66 and v66:IsA("TextLabel") then
		v_u_3.text(v66, p64, not p65)
	end
end
function v_u_3.colors(p67) -- name: colors
	-- upvalues: (copy) v_u_11
	local v68 = v_u_11[p67] or v_u_11.genin
	return v68.card[1], v68.card[2]
end
function v_u_3.forget(p69) -- name: forget
	-- upvalues: (copy) v_u_14, (copy) v_u_13, (copy) v_u_15
	if p69:IsA("TextLabel") then
		v_u_14[p69] = nil
	elseif p69:IsA("GuiObject") then
		v_u_13[p69] = nil
		v_u_15[p69] = nil
	end
end
local function v_u_83() -- name: step
	-- upvalues: (copy) v_u_13, (copy) v_u_26, (copy) v_u_15, (copy) v_u_14, (copy) v_u_2
	local v70 = os.clock()
	local v71 = v70 * 0.12 % 1
	for _, v72 in v_u_13 do
		local v73 = v72.paint
		if v73 then
			v73.Color = v_u_26(v71, 0.62, v72.dim)
		end
		local v74 = v72.ring
		if not v74 then
			continue
		end
		v74.Rotation = v70 * 120 % 360
		v74.Color = v_u_26(v71, 1, v72.dim)
	end
	local v75 = 0
	for _, v76 in v_u_15 do
		v75 = v75 + 1
		local v77 = (v70 + v75 * 0.35) % 3.6 / 1.1
		v76.band.Offset = Vector2.new(v77 >= 1 and -1 or -0.75 + v77 * 1.5, 0)
	end
	local v78 = v70 * 0.25 % 1
	for v79, v80 in v_u_14 do
		if not (v79.Parent and v79.Visible) then
			continue
		end
		local v81, v82 = v_u_2.span(v79)
		v80.paint.Color = v_u_2.flowing(v80.palette, v81, v82, v78, nil)
	end
end
function v_u_3.run(p_u_84) -- name: run
	-- upvalues: (copy) v_u_83, (copy) v_u_1
	local v_u_85 = nil
	local function v86() -- name: sync
		-- upvalues: (copy) p_u_84, (ref) v_u_85, (ref) v_u_83, (ref) v_u_1
		if p_u_84.Visible and not v_u_85 then
			v_u_83()
			v_u_85 = v_u_1.RenderStepped:Connect(v_u_83)
		elseif not p_u_84.Visible and v_u_85 then
			v_u_85:Disconnect()
			v_u_85 = nil
		end
	end
	p_u_84:GetPropertyChangedSignal("Visible"):Connect(v86)
	if p_u_84.Visible and not v_u_85 then
		v_u_83()
		v_u_85 = v_u_1.RenderStepped:Connect(v_u_83)
	elseif not p_u_84.Visible and v_u_85 then
		v_u_85:Disconnect()
		v_u_85 = nil
	end
end
return v_u_3