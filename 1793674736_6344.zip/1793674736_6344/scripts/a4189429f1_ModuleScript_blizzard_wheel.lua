local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("F4F6F8")
local v_u_9 = Color3.fromHex("0B0B0B")
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(200, 226, 255)
local v_u_12 = Color3.fromRGB(226, 245, 255)
local v_u_13 = Enum.PartType.Ball
local v_u_14 = Enum.PartType.Cylinder
local v_u_15 = Enum.PartType.Wedge
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_29(p18, p19, p20, p21, p22) -- name: disc
	-- upvalues: (copy) v_u_5
	local v23 = v_u_5.part
	local v24 = p19 * 2
	local v25 = p19 * 2
	local v26 = v23(Vector3.new(v24, 0.05, v25), p18, p21, {
		["transparency"] = 1
	})
	for _, v27 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v28 = Instance.new("Decal")
		v28.Face = v27
		v28.Texture = p20
		v28.Color3 = p21
		v28.Transparency = p22
		v28.Parent = v26
	end
	return v26
end
local function v_u_36(p30, p31, p32, p33) -- name: blob
	-- upvalues: (copy) v_u_5
	local v34 = v_u_5.part(p30, p31, p32, {
		["material"] = p33
	})
	local v35 = Instance.new("SpecialMesh")
	v35.MeshType = Enum.MeshType.Sphere
	v35.Parent = v34
	return v34
end
local v_u_37 = {}
local v_u_38 = {}
local function v_u_57(p39, p40, p41, p42) -- name: placeBits
	-- upvalues: (copy) v_u_37, (copy) v_u_38, (copy) v_u_4
	table.clear(v_u_37)
	table.clear(v_u_38)
	local v43 = math.max(p41, 0.02)
	for _, v44 in p39 do
		local v45 = v44.p
		if not v45.Parent then
			continue
		end
		local v46 = v44.off
		local v47 = v_u_37
		table.insert(v47, v45)
		local v48 = v_u_38
		local v49 = p40 * (v46 - v46.Position + v46.Position * v43)
		table.insert(v48, v49)
		if not p42 then
			continue
		end
		local v50 = v44.size * v43
		local v51 = v50.X
		local v52 = math.max(v51, 0.02)
		local v53 = v50.Y
		local v54 = math.max(v53, 0.02)
		local v55 = v50.Z
		local v56 = math.max(v55, 0.02)
		v45.Size = Vector3.new(v52, v54, v56)
	end
	if #v_u_37 > 0 then
		v_u_4:BulkMoveTo(v_u_37, v_u_38, Enum.BulkMoveMode.FireCFrameChanged)
	end
end
local function v_u_63(p58, p59) -- name: fadeBits
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v60 in p58 do
		local v61 = v60.p
		if not v61.Parent then
			continue
		end
		if v61.Transparency < 1 then
			v_u_5.tween(v61, p59, {
				["Transparency"] = 1
			})
		end
		for _, v62 in v61:GetChildren() do
			if not v62:IsA("Decal") then
				continue
			end
			v_u_5.tween(v62, p59, {
				["Transparency"] = 1
			})
		end
		v_u_1:AddItem(v61, p59 + 0.05)
	end
end
local function v_u_77(p64, p65, p66, p67) -- name: comma
	-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_13, (copy) v_u_16, (copy) v_u_1, (copy) v_u_36
	local v68 = {
		["shape"] = v_u_13,
		["material"] = v_u_16
	}
	local v69 = v_u_5.part(Vector3.new(1, 1, 1) * p66, CFrame.identity, v_u_9, v68)
	v69.Reflectance = 0.2
	v_u_1:AddItem(v69, p67)
	local v70 = {
		["p"] = v69,
		["off"] = p65,
		["size"] = v69.Size
	}
	table.insert(p64, v70)
	local v71 = v_u_36(Vector3.new(0.52, 0.42, 1.05) * p66, CFrame.identity, v_u_9, v_u_16)
	local v72 = p65 * CFrame.new(p66 * 0.14, 0, p66 * 0.6) * CFrame.Angles(0, 0.35, 0)
	v_u_1:AddItem(v71, p67)
	local v73 = {
		["p"] = v71,
		["off"] = v72,
		["size"] = v71.Size
	}
	table.insert(p64, v73)
	local v74 = v_u_36(Vector3.new(0.3, 0.28, 0.8) * p66, CFrame.identity, v_u_9, v_u_16)
	local v75 = p65 * CFrame.new(p66 * 0.5, 0, p66 * 1.08) * CFrame.Angles(0, 1.05, 0)
	v_u_1:AddItem(v74, p67)
	local v76 = {
		["p"] = v74,
		["off"] = v75,
		["size"] = v74.Size
	}
	table.insert(p64, v76)
	return v69
end
local function v_u_82(p78, p79, p80) -- name: snowEmitter
	-- upvalues: (copy) v_u_7, (copy) v_u_10
	local v81 = Instance.new("ParticleEmitter")
	v81.Texture = v_u_7.Glow
	v81.Color = ColorSequence.new(v_u_10)
	v81.LightEmission = 0.55
	v81.LightInfluence = 0
	v81.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p78), NumberSequenceKeypoint.new(1, p78 * 0.35) })
	v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.7, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v81.Lifetime = NumberRange.new(p80 * 0.6, p80)
	v81.Speed = NumberRange.new(p79 * 0.4, p79)
	v81.SpreadAngle = Vector2.new(180, 180)
	v81.Acceleration = Vector3.new(0, -9, 0)
	v81.Drag = 2
	v81.Rate = 0
	v81.Enabled = false
	return v81
end
local v_u_83 = 0
local function v_u_87(p84) -- name: whiteout
	-- upvalues: (ref) v_u_83, (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	if os.clock() >= v_u_83 then
		local v_u_85 = Instance.new("ColorCorrectionEffect")
		v_u_85.Name = "Whiteout"
		v_u_85.Parent = v_u_2
		v_u_5.tween(v_u_85, 0.05, {
			["Brightness"] = 0.4,
			["Contrast"] = -0.25,
			["Saturation"] = -0.5,
			["TintColor"] = nil,
			["TintColor"] = Color3.fromRGB(235, 245, 255)
		})
		task.delay(p84 + 0.05, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_85, (ref) v_u_10
			local v86 = {
				["Brightness"] = 0,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = nil,
				["TintColor"] = v_u_10
			}
			v_u_5.tween(v_u_85, 0.4, v86)
		end)
		v_u_1:AddItem(v_u_85, p84 + 0.55)
		v_u_83 = os.clock() + p84 + 0.55
	end
end
return function(p_u_88)
	-- upvalues: (copy) v_u_77, (copy) v_u_5, (copy) v_u_10, (copy) v_u_13, (copy) v_u_1, (copy) v_u_11, (copy) v_u_82, (copy) v_u_57, (copy) v_u_4, (copy) v_u_7, (copy) v_u_36, (copy) v_u_9, (copy) v_u_16, (copy) v_u_12, (copy) v_u_6, (copy) v_u_87, (copy) v_u_8, (copy) v_u_14, (copy) v_u_17, (copy) v_u_15, (copy) v_u_29, (copy) v_u_63
	local v89 = {}
	local v_u_90 = CFrame.Angles(0.9, 0, 0)
	v89.blizzard_wheel_a = {
		["cast"] = function(p91) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_11, (copy) p_u_88, (ref) v_u_10, (ref) v_u_4, (ref) v_u_82, (ref) v_u_1
			local v92 = p91.size
			local v93 = p91.eye + p91.dir * 1.1
			v_u_5.flash(v93, v_u_11, 3.2 * v92, 0.12)
			p_u_88.pop(v93, v_u_10, 1.3 * v92, 0.3 * v92, 0.1)
			if not p91.lite then
				local v94 = 0.22 * v92
				local v95 = 8 * v92
				local v96 = Instance.new("Attachment")
				v96.WorldPosition = v93
				v96.Parent = v_u_4.Terrain
				local v97 = v_u_82(v94, v95, 0.4)
				v97.Parent = v96
				v97:Emit(6)
				v_u_1:AddItem(v96, 0.5)
			end
		end,
		["shot"] = function(p98, p99) -- name: commaShot
			-- upvalues: (ref) v_u_77, (ref) v_u_5, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (copy) p_u_88, (ref) v_u_11, (ref) v_u_82, (ref) v_u_57, (copy) v_u_90, (ref) v_u_4
			local v_u_100 = p98.size
			local v_u_101 = {}
			v_u_77(v_u_101, CFrame.new(-0.3 * v_u_100, 0, -0.65 * v_u_100), 1.25 * v_u_100, 3)
			local v102 = {
				["shape"] = nil,
				["transparency"] = 0.6,
				["shape"] = v_u_13
			}
			local v_u_103 = v_u_5.part(Vector3.new(1.4, 1.4, 1.4) * v_u_100, p99, v_u_10, v102)
			v_u_1:AddItem(v_u_103, 3)
			local v_u_104 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p99, v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_104, 3)
			p_u_88.streak(v_u_104, v_u_10, v_u_11, 1.4 * v_u_100, p98.lite and 0.12 or 0.22)
			local v_u_105
			if p98.lite then
				v_u_105 = nil
			else
				v_u_105 = Instance.new("Attachment")
				v_u_105.Parent = v_u_104
				local v106 = v_u_82(0.28 * v_u_100, 4 * v_u_100, 0.6)
				v106.Rate = 30
				v106.Enabled = true
				v106.Parent = v_u_105
			end
			if p98.mine then
				p_u_88.light(v_u_104, v_u_10, 8 * v_u_100)
			end
			local v_u_107 = false
			return {
				["place"] = function(p108, p109) -- name: place
					-- upvalues: (copy) v_u_104, (ref) v_u_57, (copy) v_u_101, (ref) v_u_90, (copy) v_u_103, (ref) v_u_4, (copy) v_u_100
					v_u_104.CFrame = p108
					v_u_57(v_u_101, p108 * v_u_90 * CFrame.Angles(0, p109 * 24, 0), 1, false)
					local v110 = v_u_103
					local v111 = CFrame.new
					local v112 = p108.Position
					local v113 = p108.Position
					local v114 = v_u_4.CurrentCamera
					local v115
					if v114 then
						local v116 = v114.CFrame.Position - v113
						v115 = v116.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v116.Unit
					else
						v115 = Vector3.new(0, 0, 1)
					end
					v110.CFrame = v111(v112 - v115 * 1.3 * v_u_100)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_107, (copy) v_u_101, (copy) v_u_103, (ref) v_u_105, (ref) v_u_4, (ref) v_u_1, (copy) v_u_104
					if not v_u_107 then
						v_u_107 = true
						for _, v117 in v_u_101 do
							v117.p:Destroy()
						end
						v_u_103:Destroy()
						local v118 = v_u_105
						if v118 then
							local v119 = v118.WorldPosition
							v118.Parent = v_u_4.Terrain
							v118.WorldPosition = v119
							for _, v120 in v118:GetChildren() do
								if not v120:IsA("ParticleEmitter") then
									continue
								end
								v120.Enabled = false
							end
							v_u_1:AddItem(v118, 0.7)
						end
						local v121 = v_u_104:FindFirstChildWhichIsA("PointLight")
						if v121 then
							v121:Destroy()
						end
						v_u_1:AddItem(v_u_104, 0.25)
					end
				end
			}
		end,
		["impact"] = function(p122, p_u_123) -- name: commaImpact
			-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_82, (ref) v_u_1, (ref) v_u_36, (ref) v_u_9, (ref) v_u_16
			local v_u_124 = p122.size
			p_u_88.burst("Smoke", p_u_123, nil, 0.55 * v_u_124)
			p_u_88.pop(p_u_123, v_u_10, 1.4 * v_u_124, 4.6 * v_u_124, 0.16, 0.15)
			p_u_88.burst("Impact", p_u_123, v_u_11, 0.8 * v_u_124)
			v_u_5.ring(p_u_88.ground(p_u_123), v_u_10, p122.ability.radius * 0.7 * v_u_124, 0.28, v_u_7.Ring)
			if not p122.lite then
				local v125 = 0.3 * v_u_124
				local v126 = 16 * v_u_124
				local v127 = Instance.new("Attachment")
				v127.WorldPosition = p_u_123
				v127.Parent = v_u_4.Terrain
				local v128 = v_u_82(v125, v126, 0.7)
				v128.Parent = v127
				v128:Emit(14)
				v_u_1:AddItem(v127, 0.7999999999999999)
				local v_u_129 = v_u_36(Vector3.new(0.3, 0.28, 0.85) * v_u_124, CFrame.new(p_u_123), v_u_9, v_u_16)
				v_u_1:AddItem(v_u_129, 0.45)
				local v130 = math.random() - 0.5
				local v131 = math.random() - 0.5
				local v_u_132 = Vector3.new(v130, 0.8, v131).Unit
				p_u_88.animate(0.38, 0, function(p133)
					-- upvalues: (copy) v_u_129, (copy) p_u_123, (copy) v_u_132, (copy) v_u_124
					v_u_129.CFrame = CFrame.new(p_u_123 + v_u_132 * 5 * v_u_124 * p133) * CFrame.Angles(p133 * 12, p133 * 9, 0)
					v_u_129.Transparency = p133 * p133
					if p133 >= 1 then
						v_u_129:Destroy()
					end
				end)
			end
			p_u_88.hitSound(p_u_123)
		end,
		["hit"] = p_u_88.simpleHit(v_u_10, 0.5)
	}
	local v_u_134 = {}
	setmetatable(v_u_134, {
		["__mode"] = "k"
	})
	local function v_u_163(p135, p_u_136) -- name: whirlCommas
		-- upvalues: (ref) v_u_77, (copy) p_u_88, (ref) v_u_57
		local v_u_137 = p135.size
		local v_u_138 = {
			["commas"] = nil,
			["born"] = nil,
			["taken"] = false,
			["radius"] = 0,
			["spin"] = 0,
			["commas"] = {},
			["born"] = os.clock()
		}
		for v139 = 0, 5, p135.lite and 2 or 1 do
			local v140 = {}
			local v141 = v_u_77(v140, CFrame.identity, 1.4 * v_u_137, 2)
			local v142 = v_u_138.commas
			local v143 = {
				["bits"] = v140,
				["head"] = v141,
				["a"] = v139 * 3.141592653589793 / 3
			}
			table.insert(v142, v143)
		end
		p_u_88.runNow(function()
			-- upvalues: (copy) v_u_138, (copy) v_u_137, (ref) v_u_57, (copy) p_u_136
			if v_u_138.taken then
				return false
			end
			local v144 = os.clock() - v_u_138.born
			local v145 = v_u_138
			local v146 = 3.2 * v_u_137
			local v147 = v144 / 0.1
			v145.radius = v146 * math.min(v147, 1)
			v_u_138.spin = v144 * 9
			for _, v148 in v_u_138.commas do
				local v149 = v_u_57
				local v150 = v148.bits
				local v151 = p_u_136
				local v152 = v148.a + v_u_138.spin
				local v153 = v_u_138.radius
				local v154 = 2.2 * v_u_137
				local v155 = math.cos(v152) * v153
				local v156 = math.sin(v152) * v153
				local v157 = v151 + Vector3.new(v155, v154, v156)
				local v158 = -math.sin(v152)
				local v159 = math.cos(v152)
				local v160 = Vector3.new(v158, 0, v159)
				v149(v150, CFrame.lookAt(v157, v157 + v160), 1, false)
			end
			if v144 <= 1.2 then
				return true
			end
			for _, v161 in v_u_138.commas do
				for _, v162 in v161.bits do
					v162.p:Destroy()
				end
			end
			return false
		end)
		return v_u_138
	end
	v89.blizzard_wheel_e = {
		["cast"] = function(p164) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_88, (ref) v_u_11, (ref) v_u_7
			local v165 = p164.size
			v_u_5.flash(p164.eye, v_u_10, 5 * v165, 0.16)
			p_u_88.burst("Flash", p164.eye, v_u_11, 0.22 * v165)
			v_u_5.ring(p164.feet, v_u_11, 6 * v165, 0.25, v_u_7.Ring)
			if p164.mine then
				v_u_5.shake(0.08, 0.12)
			end
		end,
		["windup"] = function(p166, p167, _) -- name: windup
			-- upvalues: (copy) v_u_134, (copy) v_u_163, (copy) p_u_88
			v_u_134[p166] = v_u_163(p166, p_u_88.ground(p167, 0))
		end,
		["land"] = function(p168, p169) -- name: land
			-- upvalues: (copy) p_u_88, (copy) v_u_134, (copy) v_u_163, (ref) v_u_10, (ref) v_u_5, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_6, (ref) v_u_87, (ref) v_u_4, (ref) v_u_82, (ref) v_u_1, (ref) v_u_36, (ref) v_u_8, (ref) v_u_16, (ref) v_u_57
			local v_u_170 = p168.size
			local v_u_171 = p168.ability.radius
			local v_u_172 = p_u_88.ground(p169, 0)
			local v_u_173 = v_u_134[p168] or v_u_163(p168, v_u_172)
			v_u_134[p168] = nil
			v_u_173.taken = true
			p_u_88.pop(v_u_172 + Vector3.new(0, 2.5, 0), v_u_10, 4, 16, 0.25, 0.15)
			v_u_5.ring(p_u_88.ground(p169), v_u_10, v_u_171, 0.45, v_u_7.Shockwave)
			v_u_5.ring(p_u_88.ground(p169), v_u_11, v_u_171 * 1.05, 0.4, v_u_7.SpeedLines)
			p_u_88.mark(p169, v_u_12, v_u_171 * 0.95, 1.1, v_u_7.Glow, 0.5)
			v_u_6.play("Rain", {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v_u_172
			})
			if p168.mine then
				v_u_87(0.12)
				v_u_5.shake(0.35, 0.3)
			end
			if not p168.lite then
				local v174 = v_u_172 + Vector3.new(0, 2, 0)
				local v175 = Instance.new("Attachment")
				v175.WorldPosition = v174
				v175.Parent = v_u_4.Terrain
				local v176 = v_u_82(0.45, 40, 0.9)
				v176.Parent = v175
				v176:Emit(40)
				v_u_1:AddItem(v175, 1)
			end
			local v_u_177 = p168.lite and 10 or 16
			local v_u_178 = {}
			for _ = 1, v_u_177 do
				local v179 = v_u_36(Vector3.new(2, 2, 2), CFrame.new(v_u_172), v_u_8, v_u_16)
				v179.Transparency = 0.05
				v_u_1:AddItem(v179, 1)
				table.insert(v_u_178, v179)
			end
			local v_u_180 = math.random() * 3.141592653589793 * 2
			p_u_88.animate(0.5, 0, function(p181)
				-- upvalues: (copy) v_u_171, (copy) v_u_170, (copy) v_u_177, (copy) v_u_178, (copy) v_u_180, (copy) v_u_172
				local v182 = 1 - (1 - p181) ^ 2
				local v183 = 2.5 + (v_u_171 - 2.5) * v182
				local v184 = (3 + 3 * v182) * v_u_170
				local v185 = v183 * 3.141592653589793 * 2 / v_u_177 * 1.15
				local v186 = math.min(v185, 11)
				local v187 = p181 < 0.55 and 0.05 or 0.05 + 0.95 * (p181 - 0.55) / 0.45
				for v188, v189 in v_u_178 do
					local v190 = v_u_180 + v188 / v_u_177 * 3.141592653589793 * 2 + p181 * 0.6
					local v191 = math.cos(v190)
					local v192 = math.sin(v190)
					local v193 = Vector3.new(v191, 0, v192)
					local v194 = v_u_172 + v193 * v183 + Vector3.new(0, 1, 0) * v184 * 0.4
					local v195 = 2.4 * v_u_170
					v189.Size = Vector3.new(v186, v184, v195)
					v189.CFrame = CFrame.lookAt(v194, v194 + v193)
					v189.Transparency = v187
				end
				if p181 >= 1 then
					for _, v196 in v_u_178 do
						v196:Destroy()
					end
				end
			end)
			if not p168.lite then
				for _, v197 in v_u_173.commas do
					p_u_88.streak(v197.head, v_u_10, v_u_11, 1.2 * v_u_170, 0.25)
				end
			end
			local v_u_198 = v_u_173.radius
			local v_u_199 = v_u_173.spin
			p_u_88.animate(0.55, 0, function(p200)
				-- upvalues: (copy) v_u_198, (copy) v_u_171, (copy) v_u_173, (ref) v_u_57, (copy) v_u_172, (copy) v_u_199, (copy) v_u_170
				local v201 = 1 - (1 - p200) ^ 2
				local v202 = v_u_198 + (v_u_171 + 2 - v_u_198) * v201
				for _, v203 in v_u_173.commas do
					local v204 = v_u_57
					local v205 = v203.bits
					local v206 = v_u_172
					local v207 = v203.a + v_u_199 + p200 * 2.5
					local v208 = (2.2 + 3.2 * v201) * v_u_170
					local v209 = math.cos(v207) * v202
					local v210 = math.sin(v207) * v202
					local v211 = v206 + Vector3.new(v209, v208, v210)
					local v212 = -math.sin(v207)
					local v213 = math.cos(v207)
					local v214 = Vector3.new(v212, 0, v213)
					v204(v205, CFrame.lookAt(v211, v211 + v214), 1, false)
					if p200 <= 0.7 then
						continue
					end
					for _, v215 in v203.bits do
						v215.p.Transparency = (p200 - 0.7) / 0.3
					end
				end
				if p200 >= 1 then
					for _, v216 in v_u_173.commas do
						for _, v217 in v216.bits do
							v217.p:Destroy()
						end
					end
				end
			end)
		end,
		["hit"] = function(p218, p219, _) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_10
			p_u_88.burst("Impact", p219, v_u_10, 0.6)
			if not p218.lite then
				p_u_88.burst("Smoke", p219, nil, 0.4)
			end
		end
	}
	local v_u_220 = {}
	setmetatable(v_u_220, {
		["__mode"] = "k"
	})
	local function v_u_307(p221, p222) -- name: buildEngine
		-- upvalues: (copy) p_u_88, (ref) v_u_5, (ref) v_u_9, (ref) v_u_14, (ref) v_u_16, (ref) v_u_17, (ref) v_u_1, (ref) v_u_10, (ref) v_u_15, (ref) v_u_29, (ref) v_u_7, (ref) v_u_11, (ref) v_u_77, (ref) v_u_57
		local v223 = (p221.ability.delay or 0.2) + (p221.ability.duration or 2) + 3
		local v_u_224 = p_u_88.ground(p222, 0)
		local v225 = p_u_88.flatUnit(p221.origin - v_u_224)
		local v226 = Vector3.new(0, 0.64278764, 0) + v225 * 0.766044443118978
		local v227 = v225:Cross(Vector3.new(0, 1, 0)).Unit
		local v_u_228 = {
			["ground"] = nil,
			["turn"] = nil,
			["frame"] = nil,
			["core"] = nil,
			["halo"] = nil,
			["commas"] = nil,
			["blur"] = nil,
			["born"] = nil,
			["last"] = nil,
			["spin"] = 0,
			["whirl"] = 0,
			["duration"] = nil,
			["flungAt"] = nil,
			["shown"] = -1,
			["ground"] = v_u_224,
			["turn"] = CFrame.fromMatrix(Vector3.new(0, 0, 0), v227, v226),
			["frame"] = CFrame.new(v_u_224),
			["core"] = {},
			["halo"] = {},
			["commas"] = {},
			["born"] = os.clock(),
			["last"] = os.clock(),
			["duration"] = p221.ability.duration or 2
		}
		local v229 = v_u_228.core
		local v230 = {
			["shape"] = v_u_14,
			["material"] = v_u_16
		}
		local v231 = v_u_5.part(Vector3.new(0.9, 9.2, 9.2), CFrame.identity, v_u_9, v230)
		local v232 = v_u_17
		v_u_1:AddItem(v231, v223)
		local v233 = {
			["p"] = v231,
			["off"] = v232,
			["size"] = v231.Size
		}
		table.insert(v229, v233)
		for v234 = 0, 5 do
			local v235 = v234 * 3.141592653589793 / 3
			local v236 = math.cos(v235)
			local v237 = math.sin(v235)
			local v238 = Vector3.new(v236, 0, v237)
			local v239 = v_u_228.core
			local v240 = {
				["shape"] = v_u_15
			}
			local v241 = v_u_5.part(Vector3.new(1, 2.7, 2.1), CFrame.identity, v_u_10, v240)
			local v242 = CFrame.fromMatrix(v238 * 2.95, Vector3.new(0, 1, 0), v238)
			v_u_1:AddItem(v241, v223)
			local v243 = {
				["p"] = v241,
				["off"] = v242,
				["size"] = v241.Size
			}
			table.insert(v239, v243)
		end
		local v244 = v_u_228.core
		local v245 = {
			["shape"] = v_u_14
		}
		local v246 = v_u_5.part(Vector3.new(1.05, 3, 3), CFrame.identity, v_u_10, v245)
		local v247 = v_u_17
		v_u_1:AddItem(v246, v223)
		local v248 = {
			["p"] = v246,
			["off"] = v247,
			["size"] = v246.Size
		}
		table.insert(v244, v248)
		local v249 = v_u_228.core
		local v250 = {
			["shape"] = v_u_14,
			["material"] = v_u_16
		}
		local v251 = v_u_5.part(Vector3.new(1.15, 1.2, 1.2), CFrame.identity, v_u_9, v250)
		local v252 = v_u_17
		v_u_1:AddItem(v251, v223)
		local v253 = {
			["p"] = v251,
			["off"] = v252,
			["size"] = v251.Size
		}
		table.insert(v249, v253)
		if not p221.lite then
			local v254 = v_u_228.core
			local v255 = {
				["shape"] = nil,
				["transparency"] = 1,
				["shape"] = v_u_14
			}
			local v256 = v_u_5.part(Vector3.new(1.25, 8.8, 8.8), CFrame.identity, v_u_10, v255)
			local v257 = v_u_17
			v_u_1:AddItem(v256, v223)
			local v258 = {
				["p"] = v256,
				["off"] = v257,
				["size"] = v256.Size
			}
			table.insert(v254, v258)
			v_u_228.blur = v_u_228.core[#v_u_228.core]
			v256.Transparency = 1
		end
		local v259 = v_u_228.halo
		local v260 = v_u_29(CFrame.identity, 9.6, v_u_7.Ring, v_u_10, 0.05)
		local v261 = CFrame.identity
		v_u_1:AddItem(v260, v223)
		local v262 = {
			["p"] = v260,
			["off"] = v261,
			["size"] = v260.Size
		}
		table.insert(v259, v262)
		local v263 = v_u_228.halo
		local v264 = v_u_29(CFrame.identity, 11.6, v_u_7.Ring, v_u_11, 0.35)
		local v265 = CFrame.new(0, -0.06, 0)
		v_u_1:AddItem(v264, v223)
		local v266 = {
			["p"] = v264,
			["off"] = v265,
			["size"] = v264.Size
		}
		table.insert(v263, v266)
		local v267 = v_u_228.halo
		local v268 = v_u_29(CFrame.identity, 12.6, v_u_7.Ring, v_u_9, 0.2)
		local v269 = CFrame.new(0, -0.12, 0)
		v_u_1:AddItem(v268, v223)
		local v270 = {
			["p"] = v268,
			["off"] = v269,
			["size"] = v268.Size
		}
		table.insert(v267, v270)
		for v271 = 0, 5, p221.lite and 2 or 1 do
			local v272 = {}
			local v273 = v_u_77(v272, CFrame.identity, 2.6, v223)
			local v274 = v_u_228.commas
			local v275 = {
				["bits"] = v272,
				["head"] = v273,
				["a"] = v271 * 3.141592653589793 / 3
			}
			table.insert(v274, v275)
		end
		p_u_88.runNow(function()
			-- upvalues: (copy) v_u_228, (copy) v_u_224, (ref) v_u_57
			local v276 = os.clock()
			local v277 = v276 - v_u_228.last
			local v278 = math.min(v277, 0.05)
			v_u_228.last = v276
			local v279 = v276 - v_u_228.born
			local v280 = v279 / 0.38
			local v281 = math.clamp(v280, 0, 1) - 1
			local v282 = v281 * 2.7 * v281 * v281 + 1 + v281 * 1.7 * v281
			local v283 = (v279 - 0.19) / v_u_228.duration
			local v284 = math.clamp(v283, 0, 1)
			local v285 = v_u_228.flungAt
			local v286
			if v285 then
				local v287 = (v276 - v285) / 0.5
				v286 = math.clamp(v287, 0, 1)
			else
				v286 = 0
			end
			local v288 = math.max(v282, 0.02) * (v286 * 0.35 + 1)
			local v289 = v_u_228
			v289.spin = v289.spin + v278 * (v284 ^ 1.5 * 17 + 1.5)
			local v290 = v_u_228
			v290.whirl = v290.whirl - v278 * (v284 * 4 + 1)
			v_u_228.frame = CFrame.new(v_u_224 + Vector3.new(0, 1, 0) * (math.min(v282, 1) * 8.5 + 1)) * v_u_228.turn
			local v291 = v288 - v_u_228.shown
			local v292 = math.abs(v291) > 0.001
			v_u_228.shown = v288
			v_u_57(v_u_228.core, v_u_228.frame * CFrame.Angles(0, v_u_228.spin, 0), v288, v292)
			v_u_57(v_u_228.halo, v_u_228.frame * CFrame.Angles(0, v279 * 0.3, 0), v288, v292)
			local v293 = v_u_228.blur
			if v293 and not v285 then
				v293.p.Transparency = 1 - v284 * 0.35 * v284
			end
			local v294 = (9 - v284 * 3.6 + v286 * 22) * v288
			for _, v295 in v_u_228.commas do
				local v296 = v_u_228.whirl + v295.a
				local v297 = math.cos(v296) * v294
				local v298 = math.sin(v296) * v294
				local v299 = Vector3.new(v297, 0.2, v298)
				local v300 = math.sin(v296)
				local v301 = -math.cos(v296)
				local v302 = Vector3.new(v300, 0, v301)
				v_u_57(v295.bits, v_u_228.frame * CFrame.lookAt(v299, v299 + v302), math.min(v288, 1.2), v292)
			end
			if (not v285 or v286 < 1) and v_u_228.duration + 0.38 + 3 >= v279 then
				return true
			end
			for _, v303 in v_u_228.core do
				v303.p:Destroy()
			end
			for _, v304 in v_u_228.halo do
				v304.p:Destroy()
			end
			for _, v305 in v_u_228.commas do
				for _, v306 in v305.bits do
					v306.p:Destroy()
				end
			end
			return false
		end)
		return v_u_228
	end
	local function v_u_319(p_u_308, p_u_309, p310) -- name: throwComma
		-- upvalues: (ref) v_u_77, (copy) p_u_88, (ref) v_u_10, (ref) v_u_11, (ref) v_u_57
		local v_u_311 = {}
		local v312 = v_u_77(v_u_311, CFrame.new(-0.4, 0, -0.9), 1.6, p310 + 0.5)
		p_u_88.streak(v312, v_u_10, v_u_11, 1.4, 0.2)
		local v_u_313 = p_u_308.eye + p_u_308.dir
		p_u_88.animate(p310, 0, function(p314)
			-- upvalues: (copy) v_u_313, (copy) p_u_309, (ref) v_u_57, (copy) v_u_311, (copy) p_u_308
			local v315 = v_u_313:Lerp(p_u_309, p314)
			local v316 = p314 * 3.141592653589793
			local v317 = v315 + Vector3.new(0, 1, 0) * math.sin(v316) * 3
			v_u_57(v_u_311, CFrame.lookAt(v317, v317 + p_u_308.dir) * CFrame.Angles(0, p314 * 20, 0), 1, false)
			if p314 >= 1 then
				for _, v318 in v_u_311 do
					v318.p:Destroy()
				end
			end
		end)
	end
	v89.blizzard_wheel_r = {
		["loopSound"] = "Vortex",
		["castSound"] = "Charge",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p320) -- name: cast
			-- upvalues: (copy) p_u_88, (ref) v_u_11, (copy) v_u_319
			p_u_88.skillCast(p320, v_u_11, true)
			if not p320.lite then
				local v321 = v_u_319
				local v322 = p_u_88.ground(p320.target, 2)
				local v323 = (p320.ability.delay or 0.2) - p320.skip
				v321(p320, v322, (math.max(v323, 0.12)))
			end
		end,
		["windup"] = function(p324, p325, _) -- name: windup
			-- upvalues: (copy) v_u_220, (copy) v_u_307, (copy) p_u_88, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7
			v_u_220[p324] = v_u_307(p324, p325)
			p_u_88.burst("Smoke", p_u_88.ground(p325, 1), nil, 1.4)
			v_u_5.ring(p_u_88.ground(p325), v_u_10, 9, 0.3, v_u_7.Ring)
		end,
		["zone"] = function(p_u_326, p_u_327, p328) -- name: zone
			-- upvalues: (copy) v_u_220, (copy) v_u_307, (copy) p_u_88, (ref) v_u_12, (ref) v_u_7, (ref) v_u_29, (ref) v_u_10, (ref) v_u_1, (ref) v_u_5, (ref) v_u_11, (ref) v_u_82
			local v_u_329 = v_u_220[p_u_326] or v_u_307(p_u_326, p_u_327)
			v_u_220[p_u_326] = v_u_329
			v_u_329.duration = p328
			local v_u_330 = p_u_326.ability.radius
			local v_u_331 = p_u_88.ground(p_u_327, 0)
			p_u_88.mark(p_u_327, v_u_12, v_u_330, p328 + 0.6, v_u_7.Glow, 0.45)
			local v_u_332 = v_u_29(CFrame.new(p_u_88.ground(p_u_327, 0.15)), v_u_330, v_u_7.Ring, v_u_10, 0.15)
			v_u_1:AddItem(v_u_332, p328 + 1)
			local v_u_333 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_331), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_333, p328 + 1)
			local v_u_334 = p_u_326.lite and 2 or 3
			local v_u_335 = {}
			for _ = 1, v_u_334 do
				local v336 = Instance.new("Attachment")
				v336.Parent = v_u_333
				local v337 = Instance.new("Attachment")
				v337.Parent = v_u_333
				local v338 = Instance.new("Beam")
				v338.Attachment0 = v336
				v338.Attachment1 = v337
				v338.Texture = v_u_7.BlizzardWind
				v338.TextureMode = Enum.TextureMode.Wrap
				v338.TextureLength = 7
				v338.TextureSpeed = 2.4
				v338.Color = ColorSequence.new(v_u_11, v_u_10)
				v338.Transparency = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 1),
					NumberSequenceKeypoint.new(0.18, 0.3),
					NumberSequenceKeypoint.new(0.8, 0.25),
					NumberSequenceKeypoint.new(1, 1)
				})
				v338.LightEmission = 0.5
				v338.LightInfluence = 0
				v338.FaceCamera = true
				v338.Segments = 16
				v338.Width0 = 6
				v338.Width1 = 2.2
				v338.CurveSize0 = 7.5
				v338.CurveSize1 = 7.5
				v338.Parent = v_u_333
				table.insert(v_u_335, {
					["a0"] = v336,
					["a1"] = v337
				})
			end
			local v_u_339
			if p_u_326.lite then
				v_u_339 = nil
			else
				local v340 = v_u_5.part
				local v341 = v_u_330 * 2.2
				local v342 = v_u_330 * 2.2
				v_u_339 = v340(Vector3.new(v341, 4, v342), CFrame.new(v_u_331 + Vector3.new(0, 2.5, 0)), v_u_10, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_339, p328 + 1.5)
				local v343 = v_u_82(0.45, 20, 0.75)
				v343.Shape = Enum.ParticleEmitterShape.Cylinder
				v343.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
				v343.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
				v343.SpreadAngle = Vector2.new(12, 12)
				v343.Speed = NumberRange.new(14, 20)
				v343.Lifetime = NumberRange.new(0.6, 0.8)
				v343.Acceleration = Vector3.new(0, -2, 0)
				v343.Drag = 0
				v343.Rate = 30
				v343.Enabled = true
				v343.Parent = v_u_339
			end
			local v_u_344 = p_u_326.ability.tick or 0.4
			local function v_u_352() -- name: drag
				-- upvalues: (ref) v_u_29, (ref) p_u_88, (copy) p_u_327, (copy) v_u_330, (ref) v_u_7, (ref) v_u_10, (ref) v_u_1, (copy) v_u_331, (copy) p_u_326, (ref) v_u_5, (copy) v_u_329
				local v_u_345 = v_u_29(CFrame.new(p_u_88.ground(p_u_327, 0.3)), v_u_330 + 1, v_u_7.Ring, v_u_10, 0.15)
				v_u_1:AddItem(v_u_345, 0.4)
				p_u_88.animate(0.35, 0, function(p346)
					-- upvalues: (ref) v_u_330, (copy) v_u_345
					local v347 = v_u_330 + 1 - (v_u_330 - 1.5) * (1 - (1 - p346) ^ 2)
					local v348 = v_u_345
					local v349 = v347 * 2
					local v350 = v347 * 2
					v348.Size = Vector3.new(v349, 0.05, v350)
					for _, v351 in v_u_345:GetChildren() do
						if not v351:IsA("Decal") then
							continue
						end
						v351.Transparency = 0.15 + 0.85 * p346 * p346
					end
					if p346 >= 1 then
						v_u_345:Destroy()
					end
				end)
				p_u_88.inward(v_u_331 + Vector3.new(0, 3, 0), v_u_10, p_u_326.lite and 3 or 6, v_u_330 + 2, 0.3)
				if not p_u_326.lite then
					v_u_5.flash(v_u_329.frame.Position, v_u_10, 7, 0.15)
				end
			end
			local v_u_353 = os.clock()
			local v_u_354 = 0
			local v_u_355 = true
			p_u_88.runNow(function()
				-- upvalues: (ref) v_u_355, (copy) v_u_353, (copy) v_u_335, (copy) v_u_334, (copy) v_u_330, (copy) v_u_331, (ref) v_u_354, (copy) v_u_344, (copy) v_u_352
				if not v_u_355 then
					return false
				end
				local v356 = os.clock() - v_u_353
				local v357 = v356 * 2.6
				for v358, v359 in v_u_335 do
					local v360 = v357 + v358 / v_u_334 * 3.141592653589793 * 2
					local v361 = v360 + 2.2
					local v362 = v_u_330 + 2
					local v363 = math.cos(v360)
					local v364 = math.sin(v360)
					local v365 = Vector3.new(v363, 0, v364)
					local v366 = math.cos(v361)
					local v367 = math.sin(v361)
					local v368 = Vector3.new(v366, 0, v367)
					local v369 = -v365.Z
					local v370 = v365.X
					local v371 = (Vector3.new(v369, 0, v370) - v365 * 0.4).Unit
					local v372 = -v368.Z
					local v373 = v368.X
					local v374 = (Vector3.new(v372, 0, v373) - v368 * 0.4).Unit
					v359.a0.WorldCFrame = CFrame.fromMatrix(v_u_331 + v365 * v362 + Vector3.new(0, 1, 0), v371, Vector3.new(0, 1, 0))
					v359.a1.WorldCFrame = CFrame.fromMatrix(v_u_331 + v368 * 3.5 + Vector3.new(0, 5, 0), v374, Vector3.new(0, 1, 0))
				end
				if v_u_354 <= v356 then
					v_u_354 = v_u_354 + v_u_344
					v_u_352()
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_355, (copy) v_u_333, (ref) v_u_339, (ref) v_u_1, (copy) v_u_332, (ref) v_u_5
				v_u_355 = false
				v_u_333:Destroy()
				local v375 = v_u_339
				if v375 then
					for _, v376 in v375:GetChildren() do
						if not v376:IsA("ParticleEmitter") then
							continue
						end
						v376.Enabled = false
					end
					v_u_1:AddItem(v375, 0.9)
				end
				for _, v377 in v_u_332:GetChildren() do
					if not v377:IsA("Decal") then
						continue
					end
					v_u_5.tween(v377, 0.3, {
						["Transparency"] = 1
					})
				end
				v_u_1:AddItem(v_u_332, 0.35)
			end
		end,
		["finish"] = function(p378, p379) -- name: finish
			-- upvalues: (copy) p_u_88, (copy) v_u_220, (ref) v_u_63, (ref) v_u_10, (ref) v_u_11, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_82, (ref) v_u_1, (ref) v_u_9, (ref) v_u_6, (ref) v_u_87
			local v380 = p_u_88.ground(p379)
			local v381 = v_u_220[p378]
			v_u_220[p378] = nil
			local v382
			if v381 then
				v382 = v381.frame.Position
			else
				v382 = v380 + Vector3.new(0, 9.5, 0)
			end
			if v381 then
				v381.flungAt = os.clock()
				v_u_63(v381.core, 0.5)
				v_u_63(v381.halo, 0.35)
				for _, v383 in v381.commas do
					if not p378.lite then
						p_u_88.streak(v383.head, v_u_10, v_u_11, 2, 0.3)
					end
					v_u_63(v383.bits, 0.5)
				end
			end
			p_u_88.pop(v382, v_u_10, 6, 34, 0.35, 0.15)
			p_u_88.burst("Explosion", v382, v_u_10, 2)
			p_u_88.burst("Shockwave", v380 + Vector3.new(0, 0.3, 0), v_u_10, 1.1)
			v_u_5.ring(v380, v_u_10, 22, 0.5, v_u_7.Shockwave)
			v_u_5.ring(v380, v_u_11, 18, 0.4, v_u_7.SpeedLines)
			if not p378.lite then
				local v384 = Instance.new("Attachment")
				v384.WorldPosition = v382
				v384.Parent = v_u_4.Terrain
				local v385 = v_u_82(0.6, 60, 1.1)
				v385.Parent = v384
				v385:Emit(48)
				v_u_1:AddItem(v384, 1.2000000000000002)
				local v386 = { v_u_9, v_u_10, v_u_11 }
				p_u_88.chunks(v380 + Vector3.new(0, 1, 0), v386, 12, 50, 1.3, 1.1)
			end
			v_u_6.play("Explosion", {
				["at"] = nil,
				["volume"] = 1,
				["at"] = v380
			})
			if p378.mine then
				v_u_5.shake(0.5, 0.4)
				v_u_87(0.08)
			end
		end,
		["hit"] = function(_, p387, _) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_10
			p_u_88.burst("Impact", p387, v_u_10, 0.45)
		end
	}
	return v89
end