local v_u_20 = {
	["new"] = function(p1, p2) -- name: new
		return {
			["left"] = nil,
			["since"] = nil,
			["paused"] = false,
			["pausedFor"] = 0,
			["waitUntil"] = nil,
			["left"] = p1,
			["since"] = p2
		}
	end,
	["left"] = function(p3, p4) -- name: left
		if p3.paused then
			local v5 = p3.left
			return math.max(0, v5)
		else
			local v6 = p3.left - (p4 - p3.since)
			return math.max(0, v6)
		end
	end,
	["pausedFor"] = function(p7, p8) -- name: pausedFor
		return p7.pausedFor + (not p7.paused and 0 or p8 - p7.since)
	end,
	["pause"] = function(p9, p10) -- name: pause
		-- upvalues: (copy) v_u_20
		if not p9.paused then
			p9.left = v_u_20.left(p9, p10)
			p9.since = p10
			p9.paused = true
		end
	end,
	["resume"] = function(p11, p12) -- name: resume
		if p11.paused then
			p11.pausedFor = p11.pausedFor + (p12 - p11.since)
			p11.since = p12
			p11.paused = false
			p11.waitUntil = nil
		end
	end,
	["wait"] = function(p13, p14, p15) -- name: wait
		-- upvalues: (copy) v_u_20
		v_u_20.pause(p13, p14)
		p13.waitUntil = p14 + p15
	end,
	["step"] = function(p16, p17, p18) -- name: step
		-- upvalues: (copy) v_u_20
		if not p16.paused then
			return v_u_20.left(p16, p17) <= 0 and "over" or "running"
		end
		local v19 = p16.waitUntil
		if v19 then
			if p17 < v19 then
				return "paused"
			end
		elseif v_u_20.pausedFor(p16, p17) < p18 then
			return "paused"
		end
		v_u_20.resume(p16, p17)
		return "resumed"
	end
}
return v_u_20