local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("1E3CC8")
local v_u_8 = Color3.fromRGB(80, 150, 255)
local v_u_9 = Color3.fromRGB(150, 200, 255)
local v_u_10 = Color3.fromHex("F4F8FF")
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Wedge
local function v_u_21(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part(Vector3.new(p14, 0.05, p14), p13, p16, {
		["transparency"] = 1
	})
	for _, v19 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v20 = Instance.new("Decal")
		v20.Face = v19
		v20.Texture = p15
		v20.Color3 = p16
		v20.Transparency = p17
		v20.Parent = v18
	end
	return v18
end
local function v_u_25(p22, p23) -- name: setAlpha
	for _, v24 in p22:GetChildren() do
		if not v24:IsA("Decal") then
			continue
		end
		v24.Transparency = p23
	end
end
local function v_u_38(p26, p27, p28, p29, p30, p31) -- name: lightBow
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_10, (copy) v_u_6, (copy) v_u_11
	local v32 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p26), p31, {
		["transparency"] = 1
	})
	v_u_1:AddItem(v32, p30 + 0.1)
	local v33 = p26 - p27 * p29 * 0.35
	local v34 = Instance.new("Attachment")
	v34.WorldCFrame = CFrame.fromMatrix(v33 + p28 * p29, p27, p28)
	v34.Parent = v32
	local v35 = Instance.new("Attachment")
	v35.WorldCFrame = CFrame.fromMatrix(v33 - p28 * p29, p27, p28)
	v35.Parent = v32
	local v36 = Instance.new("Beam")
	v36.Attachment0 = v34
	v36.Attachment1 = v35
	v36.CurveSize0 = p29 * 0.95
	v36.CurveSize1 = -p29 * 0.95
	v36.Segments = 16
	v36.Width0 = p29 * 0.16
	v36.Width1 = p29 * 0.16
	v36.Color = ColorSequence.new(v_u_10, p31)
	v36.LightEmission = 0.8
	v36.LightInfluence = 0
	v36.FaceCamera = true
	v36.Texture = v_u_6.Beam
	v36.TextureMode = Enum.TextureMode.Stretch
	v36.Parent = v32
	local v37 = Instance.new("Beam")
	v37.Attachment0 = v34
	v37.Attachment1 = v35
	v37.Width0 = p29 * 0.04
	v37.Width1 = p29 * 0.04
	v37.Color = ColorSequence.new(v_u_11)
	v37.LightEmission = 1
	v37.LightInfluence = 0
	v37.FaceCamera = true
	v37.Parent = v32
	v_u_4.tween(v36, p30, {
		["Width0"] = 0,
		["Width1"] = 0
	}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	v_u_4.tween(v37, p30, {
		["Width0"] = 0,
		["Width1"] = 0
	}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
end
local function v_u_70(p39, p40, p41, p42) -- name: newArrow
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9
	local v43 = {}
	local v44 = {}
	local v45 = p40 * 3.2
	local v46 = v_u_4.part(Vector3.new(p40, p40, p39), CFrame.identity, v_u_10)
	local v47 = CFrame.identity
	v_u_1:AddItem(v46, p42)
	table.insert(v43, v46)
	table.insert(v44, v47)
	if p41 < 1 then
		return {
			["parts"] = v43,
			["offs"] = v44
		}
	end
	for _, v48 in { 1, -1 } do
		local v49 = v_u_4.part
		local v50 = p40 * 0.6
		local v51 = v45 / 2
		local v52 = v45 * 1.5
		local v53 = Vector3.new(v50, v51, v52)
		local v54 = {
			["shape"] = v_u_12
		}
		local v55 = v49(v53, CFrame.identity, v_u_11, v54)
		local v56 = CFrame.new(v48 * v45 / 4, 0, -p39 / 2 - v45 * 0.75) * CFrame.Angles(0, 0, -v48 * 3.141592653589793 / 2)
		v_u_1:AddItem(v55, p42)
		table.insert(v43, v55)
		table.insert(v44, v56)
	end
	if p41 >= 2 then
		local v57 = v_u_4.part
		local v58 = p40 * 3
		local v59 = p40 * 3
		local v60 = p39 * 1.1
		local v61 = v57(Vector3.new(v58, v59, v60), CFrame.identity, v_u_8, {
			["transparency"] = 0.55
		})
		local v62 = CFrame.identity
		v_u_1:AddItem(v61, p42)
		table.insert(v43, v61)
		table.insert(v44, v62)
		for _, v63 in { 1, -1 } do
			local v64 = v_u_4.part
			local v65 = p40 * 0.4
			local v66 = v45 * 0.45
			local v67 = {
				["shape"] = v_u_12
			}
			local v68 = v64(Vector3.new(v65, v66, v45), CFrame.identity, v_u_9, v67)
			local v69 = CFrame.new(v63 * v45 * 0.3, 0, p39 / 2 - v45 * 0.3) * CFrame.Angles(0, 0, -v63 * 3.141592653589793 / 2) * CFrame.Angles(0, 3.141592653589793, 0)
			v_u_1:AddItem(v68, p42)
			table.insert(v43, v68)
			table.insert(v44, v69)
		end
	end
	return {
		["parts"] = v43,
		["offs"] = v44
	}
end
return function(p_u_71)
	-- upvalues: (copy) v_u_21, (copy) v_u_1, (copy) v_u_25, (copy) v_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_11, (copy) v_u_70, (copy) v_u_4, (copy) v_u_7, (copy) v_u_38, (copy) v_u_9, (copy) v_u_10, (copy) v_u_5, (copy) v_u_12
	local function v_u_85(p_u_72, p_u_73, p_u_74, p75, p76, p_u_77, p_u_78) -- name: bloom
		-- upvalues: (ref) v_u_21, (ref) v_u_1, (copy) p_u_71, (ref) v_u_25
		local v_u_79 = v_u_21(p_u_72, p_u_73, p75, p76, 0)
		v_u_1:AddItem(v_u_79, p_u_77 + 0.1)
		p_u_71.animate(p_u_77, 0, function(p80)
			-- upvalues: (copy) v_u_79, (copy) p_u_73, (copy) p_u_74, (copy) p_u_72, (copy) p_u_77, (copy) p_u_78, (ref) v_u_25
			local v81 = 1 - (1 - p80) ^ 3
			local v82 = v_u_79
			local v83 = p_u_73 + (p_u_74 - p_u_73) * v81
			local v84 = math.max(v83, 0.05)
			v82.Size = Vector3.new(v84, 0.05, v84)
			v_u_79.CFrame = p_u_72 * CFrame.Angles(0, p80 * p_u_77 * p_u_78, 0)
			v_u_25(v_u_79, p80 ^ 1.6)
			if p80 >= 1 then
				v_u_79:Destroy()
			end
		end)
	end
	local function v_u_93(p86, p87, p88, p89) -- name: starFlash
		-- upvalues: (ref) v_u_3, (copy) v_u_85, (copy) p_u_71, (ref) v_u_6, (ref) v_u_8, (ref) v_u_11
		local v90 = v_u_3.CurrentCamera
		local v91
		if v90 then
			local v92 = v90.CFrame.Position - p86
			v91 = v92.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v92.Unit
		else
			v91 = Vector3.new(0, 0, 1)
		end
		v_u_85(p_u_71.facing(p86 + v91 * 0.4, v91), p87 * 1.4, p88 * 1.5, v_u_6.Glow, v_u_8, p89, 0)
		v_u_85(p_u_71.facing(p86 + v91 * 0.6, v91), p87, p88, v_u_6.QuincyPentacle, v_u_11, p89, 2.5)
	end
	local function v_u_122(p_u_94, p_u_95, p_u_96, p_u_97, p98, p99, p_u_100, p_u_101) -- name: fall
		-- upvalues: (ref) v_u_70, (copy) p_u_71, (ref) v_u_4
		local v_u_102 = (p_u_95 - p_u_94).Unit
		local v_u_103 = v_u_70(p_u_96, p_u_97, p99, p98 + 1.2)
		local v104 = p_u_94:Lerp(p_u_95, 0)
		local v105 = p_u_71.aimAt(v104 - v_u_102 * (p_u_96 / 2 + p_u_97 * 2.4), v_u_102)
		for v106, v107 in v_u_103.parts do
			v107.CFrame = v105 * v_u_103.offs[v106]
		end
		p_u_71.animate(p98, 0, function(p108)
			-- upvalues: (copy) v_u_103, (copy) p_u_94, (copy) p_u_95, (ref) p_u_71, (copy) v_u_102, (copy) p_u_96, (copy) p_u_97, (copy) p_u_101, (copy) p_u_100, (ref) v_u_4
			local v109 = v_u_103
			local v110 = p_u_94:Lerp(p_u_95, p108)
			local v111 = p_u_71.aimAt(v110 - v_u_102 * (p_u_96 / 2 + p_u_97 * 2.4), v_u_102)
			for v112, v113 in v109.parts do
				v113.CFrame = v111 * v109.offs[v112]
			end
			if p108 >= 1 then
				if p_u_101 then
					p_u_101()
				end
				if p_u_100 then
					local v114 = v_u_103
					local v115 = p_u_94:Lerp(p_u_95, 1)
					local v116 = p_u_71.aimAt(v115 - v_u_102 * (p_u_96 / 2 + p_u_97 * 2.4), v_u_102) + v_u_102 * p_u_96 * 0.3
					for v117, v118 in v114.parts do
						v118.CFrame = v116 * v114.offs[v117]
					end
					for _, v119 in v_u_103.parts do
						v_u_4.tween(v119, 0.5, {
							["Transparency"] = 1
						}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					end
					task.delay(0.55, function()
						-- upvalues: (ref) v_u_103
						for _, v120 in v_u_103.parts do
							v120:Destroy()
						end
					end)
					return
				end
				for _, v121 in v_u_103.parts do
					v121:Destroy()
				end
			end
		end)
	end
	local v144 = {
		["quincy_cross_a"] = {
			["cast"] = function(p123) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_38
				local v124 = p123.size
				local v125 = p123.eye + p123.dir * 1.6 - Vector3.new(0, 0.3, 0)
				v_u_4.flash(v125, v_u_8, 2.6 * v124, 0.1)
				if not p123.lite then
					v_u_38(v125, p123.dir, Vector3.new(0, 1, 0), 1.5 * v124, 0.16, v_u_8)
				end
			end,
			["shot"] = function(p126, p127) -- name: pfeilShot
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_70, (copy) p_u_71, (ref) v_u_7
				local v128 = p126.size
				local v_u_129 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p127, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_129, 3)
				local v_u_130 = v_u_70(2.6 * v128, 0.16 * v128, p126.lite and 1 or 2, 3)
				p_u_71.streak(v_u_129, v_u_8, v_u_7, 0.7 * v128, 0.14)
				if p126.mine then
					p_u_71.light(v_u_129, v_u_8, 8 * v128)
				end
				for v131, v132 in v_u_130.parts do
					v132.CFrame = p127 * v_u_130.offs[v131]
				end
				local v_u_133 = false
				return {
					["place"] = function(p134, _) -- name: place
						-- upvalues: (copy) v_u_129, (copy) v_u_130
						v_u_129.CFrame = p134
						local v135 = v_u_130
						for v136, v137 in v135.parts do
							v137.CFrame = p134 * v135.offs[v136]
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_133, (copy) v_u_129, (ref) v_u_1, (copy) v_u_130
						if not v_u_133 then
							v_u_133 = true
							local v138 = v_u_129:FindFirstChildWhichIsA("PointLight")
							if v138 then
								v138:Destroy()
							end
							v_u_1:AddItem(v_u_129, 0.3)
							for _, v139 in v_u_130.parts do
								v139:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p140, p141) -- name: impact
				-- upvalues: (copy) v_u_93, (copy) p_u_71, (ref) v_u_8, (ref) v_u_11, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
				local v142 = p140.size
				v_u_93(p141, 1 * v142, 4.6 * v142, 0.24)
				p_u_71.pop(p141, v_u_8, 1 * v142, 3.6 * v142, 0.18, 0.4)
				p_u_71.glint(p141, v_u_11, 3.4 * v142, 0.14)
				if not p140.lite then
					v_u_4.ring(p_u_71.ground(p141), v_u_9, p140.ability.radius * v142, 0.25, v_u_6.Ring)
				end
				p_u_71.hitSound(p141)
			end,
			["hit"] = function(_, p143, _) -- name: hit
				-- upvalues: (copy) p_u_71, (ref) v_u_8
				p_u_71.burst("Impact", p143, v_u_8, 0.6)
			end
		}
	}
	local v_u_145 = {}
	setmetatable(v_u_145, {
		["__mode"] = "k"
	})
	v144.quincy_cross_e = {
		["cast"] = function(p146) -- name: cast
			-- upvalues: (copy) p_u_71, (ref) v_u_8, (ref) v_u_38, (copy) v_u_122
			p_u_71.skillCast(p146, v_u_8)
			local v_u_147 = p146.size
			local v_u_148 = p146.eye + p146.dir * 1.6
			local v149 = (p146.dir + Vector3.new(0, 1.6, 0)).Unit
			local v150 = p146.dir:Cross(Vector3.new(0, 1, 0))
			v_u_38(v_u_148, v149, v149:Cross(v150).Unit * -1, 2.2 * v_u_147, 0.35, v_u_8)
			local v151 = p146.lite and 3 or 7
			for v152 = 1, v151 do
				local v_u_153 = (v149 + v150 * ((v152 - (v151 + 1) / 2) * 0.12)).Unit
				p_u_71.after(v152 * 0.02, function()
					-- upvalues: (ref) v_u_122, (copy) v_u_148, (copy) v_u_153, (copy) v_u_147
					v_u_122(v_u_148, v_u_148 + v_u_153 * 40, 3.2 * v_u_147, 0.2 * v_u_147, 0.25, 1, false, nil)
				end)
			end
		end,
		["windup"] = function(p_u_154, p155, p156) -- name: windup
			-- upvalues: (copy) p_u_71, (copy) v_u_145, (ref) v_u_11, (ref) v_u_6, (ref) v_u_8, (ref) v_u_9
			local v157 = p_u_154.size
			local v158 = p_u_71.ground(p155, 26)
			v_u_145[p_u_154] = {
				["sky"] = v158,
				["from"] = v158 - p_u_154.dir * 6
			}
			task.delay(p156 + 1, function()
				-- upvalues: (ref) v_u_145, (copy) p_u_154
				v_u_145[p_u_154] = nil
			end)
			local v159 = p_u_154.ability.radius * v157
			p_u_71.sigil(p_u_71.facing(v158, Vector3.new(-0, -1, -0)), v159 * 0.75, v_u_11, v_u_6.QuincyPentacle, p156 + 0.15, 0.6)
			p_u_71.sigil(p_u_71.facing(v158 + Vector3.new(0, 0.2, 0), Vector3.new(-0, -1, -0)), v159 * 0.95, v_u_8, v_u_6.Glow, p156 + 0.15, 0)
			p_u_71.sigil(p_u_71.facing(v158 - Vector3.new(0, 0.2, 0), Vector3.new(-0, -1, -0)), v159 * 0.9, v_u_9, v_u_6.Ring, p156 + 0.15, -0.8)
			p_u_71.burst("Flash", v158, v_u_8, 0.5)
		end,
		["strike"] = function(p_u_160, p161, p162) -- name: strike
			-- upvalues: (copy) v_u_145, (copy) p_u_71, (copy) v_u_122, (copy) v_u_93, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5
			local v163 = v_u_145[p_u_160]
			if v163 then
				local v_u_164 = p_u_160.size
				local v_u_165 = (p_u_160.ability.strikeRadius or 5) * v_u_164
				local v_u_166 = p_u_71.ground(p161, 0.3)
				local v167 = v163.from
				local v168 = (math.random() - 0.5) * 8
				local v169 = (math.random() - 0.5) * 8
				local v_u_170 = v167 + Vector3.new(v168, 0, v169)
				local v171 = p_u_71.after
				local v172 = p162 - 0.2
				v171(math.max(v172, 0), function()
					-- upvalues: (ref) v_u_122, (copy) v_u_170, (copy) v_u_166, (copy) v_u_164, (copy) p_u_160, (ref) v_u_93, (copy) v_u_165, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) p_u_71, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5
					v_u_122(v_u_170, v_u_166, 4.4 * v_u_164, 0.26 * v_u_164, 0.2, p_u_160.lite and 1 or 2, true, function()
						-- upvalues: (ref) v_u_93, (ref) v_u_166, (ref) v_u_164, (ref) v_u_165, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) p_u_71, (ref) v_u_8, (ref) p_u_160, (ref) v_u_10, (ref) v_u_5
						v_u_93(v_u_166 + Vector3.new(0, 1.6, 0), 1.2 * v_u_164, v_u_165 * 1.2, 0.3)
						v_u_4.ring(v_u_166, v_u_9, v_u_165, 0.3, v_u_6.Ring)
						p_u_71.burst("Impact", v_u_166 + Vector3.new(0, 1, 0), v_u_8, 0.9 * v_u_164)
						if not p_u_160.lite then
							p_u_71.spikes(v_u_166 + Vector3.new(0, 0.6, 0), v_u_10, 4, 4 * v_u_164, 0.18, Vector3.new(0, 1, 0), 0.8)
						end
						v_u_5.play("Hit", {
							["at"] = v_u_166,
							["volume"] = p_u_160.mine and 0.45 or 0.25
						})
					end)
				end)
			end
		end,
		["hit"] = function(_, p173, _) -- name: hit
			-- upvalues: (copy) p_u_71, (ref) v_u_8
			p_u_71.burst("Impact", p173, v_u_8, 0.8)
		end
	}
	local function v_u_248(p_u_174, p_u_175) -- name: wings
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_11, (ref) v_u_12, (ref) v_u_21, (ref) v_u_6, (copy) p_u_71, (ref) v_u_25
		local v_u_176 = p_u_174.size
		local v_u_177 = p_u_174.lite
		local v_u_178 = p_u_174.caster
		if v_u_178 then
			v_u_178 = p_u_174.caster.Character
		end
		if v_u_178 then
			v_u_178 = v_u_178:FindFirstChild("HumanoidRootPart")
		end
		if not (v_u_178 and v_u_178:IsA("BasePart")) then
			v_u_178 = nil
		end
		local v179 = p_u_174.origin - Vector3.new(0, 1.5, 0)
		local v_u_180 = CFrame.lookAt(v179, v179 + p_u_174.dir)
		local v181 = v_u_177 and 4 or 7
		local v_u_182 = {}
		for _, v183 in { 1, -1 } do
			for v184 = 1, v181 do
				local v185 = (v184 - 1) / (v181 - 1)
				local v186 = (0.6 - v185 * 0.15) * v_u_176
				local v187 = {}
				local v188 = v_u_4.part
				local v189 = 0.1 * v_u_176
				local v190 = Vector3.new(v186, v189, 1)
				local v191 = CFrame.identity
				local v192
				if v184 % 2 == 0 then
					v192 = v_u_9
				else
					v192 = v_u_8
				end
				v187.body = v188(v190, v191, v192, {
					["transparency"] = 0.05
				})
				v187.side = v183
				local v193 = v185 * 115 + -60
				v187.a = math.rad(v193)
				v187.len = (v185 * 1.8 + 3.2) * v_u_176
				v187.w = v186
				local v194 = v183 * (v185 * 2.6 + 0.5)
				local v195 = v185 * 2.4 + 1.6 - v185 * 0.8 * v185
				local v196 = v185 * 0.5 + 0.7
				v187.root = Vector3.new(v194, v195, v196) * v_u_176
				if not v_u_177 then
					local v197 = v_u_4.part
					local v198 = 0.1 * v_u_176
					local v199 = v186 / 2
					local v200 = v186 * 1.6
					local v201 = Vector3.new(v198, v199, v200)
					local v202 = {
						["shape"] = v_u_12
					}
					v187.tipA = v197(v201, CFrame.identity, v_u_11, v202)
					local v203 = v_u_4.part
					local v204 = 0.1 * v_u_176
					local v205 = v186 / 2
					local v206 = v186 * 1.6
					local v207 = Vector3.new(v204, v205, v206)
					local v208 = {
						["shape"] = v_u_12
					}
					v187.tipB = v203(v207, CFrame.identity, v_u_11, v208)
				end
				table.insert(v_u_182, v187)
			end
		end
		local v_u_209 = v_u_21(CFrame.identity, 3 * v_u_176, v_u_6.Ring, v_u_9, 0)
		local v_u_210 = v_u_21(CFrame.identity, 7 * v_u_176, v_u_6.Glow, v_u_8, 0.3)
		local v_u_211 = os.clock()
		p_u_71.runNow(function()
			-- upvalues: (copy) v_u_211, (copy) p_u_175, (copy) v_u_182, (copy) v_u_177, (ref) p_u_71, (ref) v_u_9, (copy) v_u_209, (copy) v_u_210, (copy) v_u_178, (copy) p_u_174, (copy) v_u_180, (copy) v_u_176, (ref) v_u_25
			local v212 = os.clock() - v_u_211
			if p_u_175 <= v212 then
				for _, v213 in v_u_182 do
					local v214 = v213.body.Position
					v213.body:Destroy()
					local v215 = v213.tipA
					local v216 = v213.tipB
					if v215 and v216 then
						v215:Destroy()
						v216:Destroy()
					end
					if v_u_177 then
						continue
					end
					p_u_71.glint(v214, v_u_9, 2, 0.2)
				end
				v_u_209:Destroy()
				v_u_210:Destroy()
				return false
			end
			local v217 = v212 / 0.28
			local v218 = 1 - (1 - math.clamp(v217, 0, 1)) ^ 3
			local v219 = (v212 - p_u_175 + 0.3) / 0.3
			local v220 = math.clamp(v219, 0, 1)
			local v221 = v_u_178
			local v222
			if v221 and v221.Parent then
				local v223 = v221.CFrame.LookVector
				local v224 = v223.X
				local v225 = v223.Z
				local v226 = Vector3.new(v224, 0, v225)
				local v227
				if v226.Magnitude > 0.001 then
					v227 = v226.Unit
				else
					v227 = p_u_174.dir
				end
				v222 = CFrame.lookAt(v221.Position, v221.Position + v227)
			else
				v222 = v_u_180
			end
			for _, v228 in v_u_182 do
				local v229 = v228.a * v218 + (1 - v218) * -1.5707963267948966
				local v230 = v212 * 3
				local v231 = math.sin(v230) * 0.06
				local v232 = v228.len * (v218 * 0.65 + 0.35) * (1 - v220 * 0.6)
				local v233 = v222 * CFrame.new(v228.root * (v218 * 0.7 + 0.3))
				local v234 = v228.side
				local v235 = v229 + v231
				local v236 = v234 * math.cos(v235)
				local v237 = v229 + v231
				local v238 = math.sin(v237)
				local v239 = Vector3.new(v236, v238, 0.3)
				local v240 = CFrame.lookAt(v233.Position, v233.Position + v233:VectorToWorldSpace(v239))
				local v241 = v228.body
				local v242 = v228.w
				local v243 = 0.1 * v_u_176
				v241.Size = Vector3.new(v242, v243, v232)
				v228.body.CFrame = v240 * CFrame.new(0, 0, -v232 / 2)
				v228.body.Transparency = v220 * 0.95 + 0.05
				local v244 = v228.tipA
				local v245 = v228.tipB
				if not (v244 and v245) then
					continue
				end
				local v246 = v240 * CFrame.new(0, 0, -v232 - v228.w * 0.8)
				v244.CFrame = v246 * CFrame.new(v228.w / 4, 0, 0) * CFrame.Angles(0, 0, -1.5707963267948966)
				v245.CFrame = v246 * CFrame.new(-v228.w / 4, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
				v244.Transparency = v220
				v245.Transparency = v220
			end
			local v247 = v222 * CFrame.new(0, 3.1 * v_u_176, 0.2 * v_u_176)
			v_u_209.CFrame = CFrame.new(v247.Position) * CFrame.Angles(0, v212 * 1.5, 0)
			v_u_210.CFrame = CFrame.new(v247.Position - Vector3.new(0, 0.05, 0))
			v_u_25(v_u_209, v220)
			v_u_25(v_u_210, v220 * 0.65 + 0.35)
			return true
		end)
	end
	local v_u_249 = {}
	setmetatable(v_u_249, {
		["__mode"] = "k"
	})
	v144.quincy_cross_r = {
		["cast"] = function(p250) -- name: cast
			-- upvalues: (copy) p_u_71, (ref) v_u_8, (ref) v_u_9, (copy) v_u_248, (ref) v_u_4
			p_u_71.skillCast(p250, v_u_8, true)
			p_u_71.burst("Flash", p250.eye, v_u_9, 0.35)
			local v251 = p250.ability
			v_u_248(p250, (v251.delay or 0.2) + (v251.duration or 1.1) + 0.6)
			if p250.mine then
				v_u_4.shake(0.15, 0.2)
			end
		end,
		["windup"] = function(p_u_252, p253, p254) -- name: windup
			-- upvalues: (copy) p_u_71, (copy) v_u_249, (ref) v_u_8, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (copy) v_u_85, (ref) v_u_5
			local v255 = p_u_252.size
			local v_u_256 = p_u_252.ability.radius * v255
			local v_u_257 = p_u_71.ground(p253, 0)
			local v258 = v_u_257 + Vector3.new(0, 32, 0)
			v_u_249[p_u_252] = {
				["sky"] = v258,
				["ring"] = v_u_256 * 0.8
			}
			task.delay(p254 + 1, function()
				-- upvalues: (ref) v_u_249, (copy) p_u_252
				v_u_249[p_u_252] = nil
			end)
			local v_u_259 = v_u_257 + Vector3.new(0, 46, 0)
			local v260 = -p_u_252.dir.X
			local v261 = -p_u_252.dir.Z
			local v262 = Vector3.new(v260, 0, v261)
			local v_u_263 = p_u_71.facing(v_u_259, v262)
			local v264 = p254 + 0.1
			p_u_71.sigil(v_u_263 * CFrame.new(0, -0.3, 0), v_u_256 * 1.5, v_u_8, v_u_6.Glow, v264, 0)
			p_u_71.sigil(v_u_263, v_u_256 * 1.1, v_u_11, v_u_6.QuincyPentacle, v264, 0.25)
			p_u_71.sigil(v_u_263 * CFrame.new(0, 0.4, 0), v_u_256 * 0.3, v_u_11, p_u_71.iris("quincy_cross"), v264, -0.5)
			p_u_71.sigil(p_u_71.facing(v258, Vector3.new(-0, -1, -0)), v_u_256 * 0.95, v_u_9, v_u_6.Ring, v264, 0.6)
			p_u_71.sigil(p_u_71.facing(v258 + Vector3.new(0, 0.2, 0), Vector3.new(-0, -1, -0)), v_u_256 * 1.1, v_u_8, v_u_6.Glow, v264, 0)
			p_u_71.glowBeam(v_u_259, v258, v_u_8, v_u_256 * 0.5, v264, v_u_6.Beam)
			p_u_71.burst("Flash", v_u_259, v_u_8, 0.9, true)
			if not p_u_252.lite then
				p_u_71.inward(v_u_259, v_u_10, 10, v_u_256 * 1.2, 0.35)
			end
			p_u_71.after(p254, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_259, (ref) v_u_11, (copy) v_u_256, (ref) v_u_85, (copy) v_u_263, (ref) v_u_6, (ref) v_u_9, (copy) p_u_252, (ref) p_u_71, (ref) v_u_10, (ref) v_u_5, (copy) v_u_257
				v_u_4.flash(v_u_259, v_u_11, v_u_256 * 1.4, 0.3)
				v_u_85(v_u_263 * CFrame.new(0, 0.3, 0), v_u_256 * 2.2, v_u_256 * 3, v_u_6.QuincyPentacle, v_u_9, 0.35, 0.8)
				if not p_u_252.lite then
					p_u_71.spikes(v_u_259, v_u_10, 12, v_u_256, 0.35)
				end
				v_u_5.play("Explosion", {
					["at"] = v_u_257,
					["volume"] = p_u_252.mine and 0.8 or 0.4
				})
				if p_u_252.mine then
					v_u_4.shake(0.35, 0.35)
				end
			end)
		end,
		["strike"] = function(p_u_265, p266, p267) -- name: strike
			-- upvalues: (copy) v_u_249, (copy) p_u_71, (copy) v_u_122, (ref) v_u_9, (copy) v_u_93, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) v_u_5
			local v268 = v_u_249[p_u_265]
			if v268 then
				local v_u_269 = p_u_265.size
				local v_u_270 = (p_u_265.ability.strikeRadius or 6) * v_u_269
				local v_u_271 = p_u_71.ground(p266, 0.3)
				for v272 = 1, p_u_265.lite and 2 or 6 do
					local v273 = (math.random() - 0.5) * 2
					local v274 = (math.random() - 0.5) * 2
					local v_u_275 = Vector3.new(v273, 0, v274) * v_u_270 * 0.8
					local v276 = math.random() * 3.141592653589793 * 2
					local v277 = v268.sky
					local v278 = math.cos(v276)
					local v279 = math.sin(v276)
					local v_u_280 = v277 + Vector3.new(v278, 0, v279) * v268.ring * math.random()
					local v281 = (v272 - 1) * 0.025
					local v282 = p_u_71.after
					local v283 = p267 - 0.22 + v281 - 0.06
					v282(math.max(v283, 0), function()
						-- upvalues: (ref) v_u_122, (copy) v_u_280, (copy) v_u_271, (copy) v_u_275, (copy) v_u_269, (ref) p_u_71, (ref) v_u_9
						v_u_122(v_u_280, v_u_271 + v_u_275, 2.6 * v_u_269, 0.11 * v_u_269, 0.22, 0, false, function()
							-- upvalues: (ref) p_u_71, (ref) v_u_271, (ref) v_u_275, (ref) v_u_9, (ref) v_u_269
							p_u_71.pop(v_u_271 + v_u_275 + Vector3.new(0, 0.5, 0), v_u_9, 0.6 * v_u_269, 2.2 * v_u_269, 0.15, 0.3)
						end)
					end)
				end
				p_u_71.after(p267, function()
					-- upvalues: (ref) v_u_93, (copy) v_u_271, (copy) v_u_269, (copy) v_u_270, (ref) v_u_4, (ref) v_u_8, (ref) v_u_6, (ref) p_u_71, (copy) p_u_265, (ref) v_u_5
					v_u_93(v_u_271 + Vector3.new(0, 1.8, 0), 1.4 * v_u_269, v_u_270 * 1.3, 0.32)
					v_u_4.ring(v_u_271, v_u_8, v_u_270 * 1.1, 0.3, v_u_6.Ring)
					p_u_71.burst("Impact", v_u_271 + Vector3.new(0, 1, 0), v_u_8, 1.1 * v_u_269)
					if not p_u_265.lite then
						p_u_71.mark(v_u_271, v_u_8, v_u_270 * 0.7, 0.7, v_u_6.Glow, 0.35)
					end
					v_u_5.play("Hit", {
						["at"] = v_u_271,
						["volume"] = p_u_265.mine and 0.5 or 0.3
					})
				end)
			end
		end,
		["hit"] = function(p284, p285, _) -- name: hit
			-- upvalues: (copy) p_u_71, (ref) v_u_8, (ref) v_u_10
			p_u_71.burst("Impact", p285, v_u_8, 0.9)
			if not p284.lite then
				p_u_71.glint(p285, v_u_10, 3, 0.14)
			end
		end
	}
	return v144
end