local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF2A2A")
local v_u_8 = Color3.fromRGB(150, 0, 10)
local v_u_9 = Color3.fromRGB(18, 0, 0)
local v_u_10 = Color3.fromRGB(255, 120, 40)
local v_u_11 = Color3.fromRGB(60, 6, 8)
local v_u_12 = Color3.fromRGB(242, 235, 217)
local v_u_13 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_14 = CFrame.identity
local function v_u_23(p15, p16) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v17 = v_u_2:FindFirstChild("EyePieces")
	if v17 then
		v17 = v17:FindFirstChild(p15)
	end
	if not (v17 and v17:IsA("MeshPart")) then
		return nil
	end
	local v18 = v17:Clone()
	local v19 = v17.Size
	local v20 = v19.X
	local v21 = v19.Y
	local v22 = v19.Z
	v18.Size = v19 * (p16 / math.max(v20, v21, v22, 0.01))
	v18.Anchored = true
	v18.CanCollide = false
	v18.CanQuery = false
	v18.CanTouch = false
	v18.Massless = true
	v18.CastShadow = false
	v18.Parent = v_u_4.folder()
	return v18
end
local function v_u_30(p24) -- name: seq
	local v25 = {}
	for _, v26 in p24 do
		local v27 = NumberSequenceKeypoint.new
		local v28 = v26[1]
		local v29 = v26[2]
		table.insert(v25, v27(v28, v29))
	end
	return NumberSequence.new(v25)
end
local function v_u_39(p31, p32, p33, p34, p35, p36, p37) -- name: steady
	-- upvalues: (copy) v_u_13, (copy) v_u_30
	local v38 = Instance.new("ParticleEmitter")
	v38.Texture = p32
	if p37 then
		v38.FlipbookLayout = v_u_13
		v38.FlipbookMode = Enum.ParticleFlipbookMode.Loop
		v38.FlipbookFramerate = NumberRange.new(12)
	end
	v38.Color = ColorSequence.new(p33)
	v38.LightEmission = p35
	v38.LightInfluence = 0
	v38.LockedToPart = true
	v38.Orientation = Enum.ParticleOrientation.FacingCamera
	v38.Size = NumberSequence.new(p34 / 2)
	v38.Transparency = v_u_30({
		{ 0, 1 },
		{ 0.12, 0 },
		{ 0.88, 0 },
		{ 1, 1 }
	})
	v38.Lifetime = NumberRange.new(1)
	v38.Speed = NumberRange.new(0)
	v38.Rotation = NumberRange.new(0, 360)
	v38.Rate = 1.12
	v38.ZOffset = p36
	v38.Parent = p31
	v38:Emit(1)
	return v38
end
local function v_u_43(p40, p41) -- name: flasher
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_30
	local v42 = Instance.new("ParticleEmitter")
	v42.Texture = v_u_6.Glow
	v42.Color = ColorSequence.new(v_u_7)
	v42.LightEmission = 0.7
	v42.LightInfluence = 0
	v42.LockedToPart = true
	v42.Size = v_u_30({
		{ 0, p41 * 0.2 },
		{ 0.3, p41 / 2 },
		{ 1, p41 * 0.3 }
	})
	v42.Transparency = v_u_30({
		{ 0, 0.1 },
		{ 1, 1 }
	})
	v42.Lifetime = NumberRange.new(0.45)
	v42.Speed = NumberRange.new(0)
	v42.Rate = 0
	v42.Enabled = false
	v42.ZOffset = -0.3
	v42.Parent = p40
	return v42
end
local function v_u_62(p44, p45, p46) -- name: cross
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6, (copy) v_u_13, (copy) v_u_30
	for v47 = 0, 3 do
		local v48 = p46 + 0.7853981633974483 + v47 * 3.141592653589793 / 2
		local v49 = math.cos(v48)
		local v50 = math.sin(v48)
		local v51 = Vector3.new(v49, 0, v50)
		for _, v52 in {
			{ 0.2, 1.7, 0.42 },
			{ 1.7, 3.5, 0.2 }
		} do
			local v53 = p44 + v51 * v52[1] * p45
			local v54 = p44 + v51 * v52[2] * p45
			local v55 = v_u_4.part
			local v56 = v52[3] * p45
			local v57 = (v54 - v53).Magnitude
			local v58 = v55(Vector3.new(v56, 0.08, v57), CFrame.lookAt((v53 + v54) / 2, v54), v_u_7)
			local v59 = {
				["Color"] = nil,
				["Transparency"] = 1,
				["Color"] = v_u_8
			}
			v_u_4.tween(v58, 1.1, v59, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v58, 1.15)
		end
		local v60 = Instance.new("Attachment")
		v60.WorldPosition = p44 + v51 * 1.6 * p45
		v60.Parent = v_u_3.Terrain
		v_u_1:AddItem(v60, 1.2)
		local v61 = Instance.new("ParticleEmitter")
		v61.Texture = v_u_6.InfernoFlame
		v61.FlipbookLayout = v_u_13
		v61.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v61.Color = ColorSequence.new(v_u_7, v_u_8)
		v61.LightEmission = 0
		v61.LightInfluence = 0
		v61.Brightness = 1.3
		v61.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
		v61.Size = v_u_30({
			{ 0, p45 * 0.5 },
			{ 0.3, p45 * 0.8 },
			{ 1, p45 * 0.6 }
		})
		v61.Lifetime = NumberRange.new(0.8, 0.96)
		v61.Speed = NumberRange.new(p45 * 2, p45 * 4)
		v61.EmissionDirection = Enum.NormalId.Top
		v61.SpreadAngle = Vector2.new(15, 15)
		v61.Drag = 2
		v61.Rate = 0
		v61.Enabled = false
		v61.Parent = v60
		v61:Emit(2)
	end
end
return function(p_u_63)
	-- upvalues: (copy) v_u_4, (copy) v_u_62, (copy) v_u_23, (copy) v_u_12, (copy) v_u_14, (copy) v_u_39, (copy) v_u_6, (copy) v_u_7, (copy) v_u_9, (copy) v_u_43, (copy) v_u_13, (copy) v_u_11, (copy) v_u_30, (copy) v_u_5, (copy) v_u_10
	return {
		["w7_cero_inferno"] = function(p_u_64, p65)
			-- upvalues: (ref) v_u_4, (copy) p_u_63, (ref) v_u_62, (ref) v_u_23, (ref) v_u_12, (ref) v_u_14, (ref) v_u_39, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_43, (ref) v_u_13, (ref) v_u_11, (ref) v_u_30, (ref) v_u_5, (ref) v_u_10
			local v66 = v_u_4.color(p65.color)
			local v67 = p_u_64.headY / 1.5
			local v_u_68 = math.clamp(v67, 0.7, 3)
			local v_u_69 = {}
			local v_u_78 = p_u_63.throb(p_u_64, 5, 2.2, 1.4, function(p70)
				-- upvalues: (ref) v_u_62, (ref) p_u_63, (copy) p_u_64, (copy) v_u_68, (copy) v_u_69
				local v71 = p70.LookVector
				local v72 = v_u_62
				local v73 = p_u_63.feetAt(p_u_64, p70, 0.06)
				local v74 = v_u_68 * p_u_64.fx
				local v75 = v71.Z
				local v76 = v71.X
				v72(v73, v74, (math.atan2(v75, v76)))
				for _, v77 in v_u_69 do
					v77:Emit(1)
				end
			end)
			local v85 = p_u_63.group(p_u_64, function(p79, p80)
				-- upvalues: (copy) v_u_68
				local v81 = CFrame.new
				local v82 = v_u_68 * 2
				local v83 = v_u_68 * 0.05
				local v84 = p80 * 1.6
				return p79 * v81(v82, v83 + math.sin(v84) * 0.15 * v_u_68, v_u_68 * -0.5) * CFrame.Angles(0, p80 * 0.7, 0)
			end)
			local v86 = v_u_68 * 2.9
			local v87 = v_u_23("w7_cero_inferno", v86)
			if v87 then
				local v_u_88 = v87:FindFirstChildOfClass("SurfaceAppearance")
				if not v_u_88 then
					v87.Color = v_u_12
					v87.Material = Enum.Material.SmoothPlastic
				end
				p_u_63.pin(p_u_64, v85, v87, v_u_14)
				if v_u_88 then
					local v_u_89 = v_u_88.EmissiveStrength
					local v_u_90 = -1
					local v91 = p_u_64.ticks
					local function v94()
						-- upvalues: (copy) v_u_78, (ref) v_u_90, (copy) v_u_88, (copy) v_u_89
						local v92 = v_u_78() * 20
						local v93 = math.floor(v92) / 20
						if v93 ~= v_u_90 then
							v_u_90 = v93
							v_u_88.EmissiveStrength = v_u_89 * (v93 * 1.5 + 1)
						end
					end
					table.insert(v91, v94)
				end
			else
				for v95 = 1, 3 do
					local v96 = p_u_63.bar
					local v97 = v_u_68 * 0.14
					local v98 = v_u_68 * 1.35
					local v99 = v_u_68 * 0.34
					local v100 = v96(Vector3.new(v97, v98, v99), v_u_12, 0, Enum.Material.SmoothPlastic)
					v100.Shape = Enum.PartType.Wedge
					p_u_63.pin(p_u_64, v85, v100, CFrame.Angles(0, v95 * 3.141592653589793 * 2 / 3, 0) * CFrame.new(0, v_u_68 * 0.1, v_u_68 * -0.45) * CFrame.Angles(-0.3, 0, 0))
				end
			end
			local v101 = p_u_63.bar(Vector3.new(0.2, 0.2, 0.2), v66, 1)
			local v102 = p_u_63.pin
			local v103 = CFrame.new
			local v104 = 0
			local v105
			if v87 then
				v105 = v86 * -0.28
			else
				v105 = v_u_68 * -0.35
			end
			v102(p_u_64, v85, v101, v103(v104, v105, 0))
			v_u_39(v101, v_u_6.Glow, v_u_7, v_u_68 * 3.8, 0.7, -0.5)
			if not v87 then
				v_u_39(v101, v_u_6.Glow, v_u_9, v_u_68 * 1.1, 0, 0.2)
				v_u_39(v101, v_u_6.CeroOrb, v_u_7, v_u_68 * 1.2, 0.2, 0.3, true)
			end
			local v106 = v_u_43(v101, v_u_68 * 4 * p_u_64.fx)
			table.insert(v_u_69, v106)
			local v_u_108 = p_u_63.group(p_u_64, function(p107)
				-- upvalues: (copy) v_u_68
				return p107 * CFrame.new(0, v_u_68 * 0.45, 0) * CFrame.Angles(0.32, 0, 0.18)
			end)
			local v_u_109 = 0
			local v110 = p_u_64.ticks
			local function v112(_, _, p111)
				-- upvalues: (ref) v_u_109, (copy) v_u_78
				v_u_109 = v_u_109 + p111 * (1.1 + v_u_78() * 3)
			end
			table.insert(v110, v112)
			local v_u_113 = v_u_109
			for v_u_114 = 1, 5 do
				local v115 = p_u_63.bar(Vector3.new(0.2, 0.2, 0.2), v66, 1)
				p_u_63.add(p_u_64, v115, function(_, p116)
					-- upvalues: (ref) v_u_113, (copy) v_u_114, (copy) v_u_78, (copy) v_u_68, (copy) v_u_108
					local v117 = v_u_113 + v_u_114 * 3.141592653589793 * 2 / 5
					local v118 = v_u_78() * 3.141592653589793
					local v119 = (math.sin(v118) * 0.9 + 2.5) * v_u_68
					local v120 = v_u_108.cf
					local v121 = CFrame.new
					local v122 = math.cos(v117) * v119
					local v123 = p116 * 2 + v_u_114
					return v120 * v121(v122, math.sin(v123) * 0.12 * v_u_68, math.sin(v117) * v119)
				end)
				v_u_39(v115, v_u_6.Glow, v_u_7, v_u_68 * 3 * p_u_64.fx, 0.7, 0)
				v_u_39(v115, v_u_6.CeroOrb, v_u_7, v_u_68 * 1.7 * p_u_64.fx, 0.2, 0.3, true)
				v_u_39(v115, v_u_6.Glow, v_u_9, v_u_68 * 0.75 * p_u_64.fx, 0, 0.4)
				p_u_63.tail(v115, v_u_7, v_u_9, v_u_68 * 0.55, 0.3)
				local v124 = v_u_43(v115, v_u_68 * 2.6 * p_u_64.fx)
				table.insert(v_u_69, v124)
			end
			local v125 = v_u_4.part
			local v126 = v_u_68 * 2.4
			local v127 = v_u_68 * 2.4
			local v128 = v125(Vector3.new(v126, 0.3, v127), CFrame.identity, v_u_9, {
				["transparency"] = 1
			})
			v128.Massless = true
			p_u_63.add(p_u_64, v128, function(p129)
				-- upvalues: (ref) p_u_63, (copy) p_u_64
				return CFrame.new(p_u_63.feetAt(p_u_64, p129, 0.3))
			end)
			local v130 = Instance.new("ParticleEmitter")
			v130.Texture = v_u_6.FxSmoke
			v130.FlipbookLayout = v_u_13
			v130.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v130.Color = ColorSequence.new(v_u_11, v_u_9)
			v130.LightEmission = 0
			v130.LightInfluence = 0
			v130.Size = v_u_30({
				{ 0, v_u_68 * 1 * p_u_64.fx },
				{ 1, v_u_68 * 2.6 * p_u_64.fx }
			})
			v130.Transparency = v_u_30({
				{ 0, 1 },
				{ 0.2, 0.15 },
				{ 0.7, 0.45 },
				{ 1, 1 }
			})
			v130.Lifetime = NumberRange.new(1.4, 2)
			v130.Speed = NumberRange.new(0.5, 1.4)
			v130.EmissionDirection = Enum.NormalId.Top
			v130.SpreadAngle = Vector2.new(30, 30)
			v130.Rotation = NumberRange.new(0, 360)
			v130.RotSpeed = NumberRange.new(-40, 40)
			v130.Acceleration = Vector3.new(0, 0.5, 0)
			v130:SetAttribute("BaseRate", 9)
			v130.Rate = 9 * v_u_5.formRate()
			v130.Parent = v128
			local v131 = Instance.new("ParticleEmitter")
			v131.Texture = v_u_6.Glow
			v131.Color = ColorSequence.new(v_u_10, v_u_7)
			v131.LightEmission = 1
			v131.LightInfluence = 0
			v131.Size = v_u_30({
				{ 0, v_u_68 * 0.12 * p_u_64.fx },
				{ 1, 0 }
			})
			v131.Lifetime = NumberRange.new(0.9, 1.4)
			v131.Speed = NumberRange.new(2, 4)
			v131.EmissionDirection = Enum.NormalId.Top
			v131.SpreadAngle = Vector2.new(30, 30)
			v131.Acceleration = Vector3.new(0, 1.5, 0)
			v131:SetAttribute("BaseRate", 3)
			v131.Rate = 3 * v_u_5.formRate() * (p_u_64.fx > 1 and 2 or 1)
			v131.Parent = v128
			p_u_63.own(p_u_64, v128)
			p_u_63.particles(p_u_64, "AuraMode", v66, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end