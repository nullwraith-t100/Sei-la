local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v_u_1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(255, 176, 220)
local v_u_6 = Color3.fromHex("2A1030")
local v_u_7 = Color3.fromRGB(26, 10, 18)
local v_u_8 = Color3.fromRGB(92, 40, 30)
local v_u_9 = Color3.fromRGB(150, 84, 56)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = CFrame.identity
local function v_u_19(p12) -- name: eyePiece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v13 = v_u_1:FindFirstChild("EyePieces")
	if v13 then
		v13 = v13:FindFirstChild("w8_biwa_castle")
	end
	if not (v13 and v13:IsA("MeshPart")) then
		return nil
	end
	local v14 = v13:Clone()
	local v15 = v13.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	v14.Size = v15 * (p12 / math.max(v16, v17, v18, 0.01))
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanQuery = false
	v14.CanTouch = false
	v14.Massless = true
	v14.CastShadow = false
	v14.Parent = v_u_2.folder()
	return v14
end
return function(p_u_20)
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_10, (copy) v_u_7, (copy) v_u_4, (copy) v_u_19, (copy) v_u_11, (copy) v_u_8, (copy) v_u_9
	return {
		["w8_biwa_castle"] = function(p_u_21, p22)
			-- upvalues: (ref) v_u_2, (copy) p_u_20, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_19, (ref) v_u_11, (ref) v_u_8, (ref) v_u_9
			local v_u_23 = v_u_2.color(p22.color)
			local v24 = p_u_21.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v_u_26 = -100
			p_u_20.throb(p_u_21, 5.5, 2, 1.5, function(p27)
				-- upvalues: (ref) v_u_26, (ref) p_u_20, (copy) p_u_21, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3, (copy) v_u_23
				v_u_26 = os.clock()
				local v28 = p_u_20.feetAt(p_u_21, p27, 0.15)
				v_u_2.ring(v28, v_u_6, 4.5 * p_u_21.fx, 0.45, v_u_3.Ring)
				v_u_2.ring(v28, v_u_23, 6.5 * p_u_21.fx, 0.6, v_u_3.BiwaCorridor)
			end)
			local v_u_30 = p_u_20.group(p_u_21, function(p29)
				-- upvalues: (copy) v_u_25
				return p29 * CFrame.new(0, v_u_25 * 0.45, v_u_25 * 0.85)
			end)
			local v31 = {}
			for v_u_32 = 0, 3 do
				local v33 = (1.75 - v_u_32 * 0.36) * v_u_25
				v31[v_u_32 + 1] = v33
				local v34 = (0.12 - v_u_32 * 0.015) * v_u_25
				local v35 = v_u_32 * 0.1
				local v_u_36 = {
					["parts"] = {},
					["offs"] = {},
					["z"] = v_u_32 * 0.75 * v_u_25
				}
				for _, v37 in { -1, 1 } do
					local v38 = p_u_20.bar
					local v39 = v33 * 2 + v34
					local v40 = v38(Vector3.new(v39, v34, v34), v_u_23, v35)
					local v41 = p_u_20.bar
					local v42 = v33 * 2
					local v43 = v41(Vector3.new(v34, v42, v34), v_u_23, v35)
					local v44 = v_u_36.parts
					table.insert(v44, v40)
					local v45 = v_u_36.offs
					local v46 = CFrame.new
					local v47 = v37 * v33
					table.insert(v45, v46(0, v47, 0))
					local v48 = v_u_36.parts
					table.insert(v48, v43)
					local v49 = v_u_36.offs
					local v50 = CFrame.new
					local v51 = v37 * v33
					table.insert(v49, v50(v51, 0, 0))
				end
				for v52, v53 in v_u_36.parts do
					local v_u_54 = v_u_36.offs[v52]
					p_u_20.add(p_u_21, v53, function(_, p55)
						-- upvalues: (copy) v_u_30, (copy) v_u_36, (ref) v_u_26, (copy) v_u_32, (copy) v_u_25, (copy) v_u_54
						local v56 = v_u_30.cf
						local v57 = CFrame.new
						local v58 = 0
						local v59 = 0
						local v60 = v_u_36.z
						local v61 = os.clock() - v_u_26
						local v62
						if v61 < 0 or v61 > 0.9 then
							v62 = 0
						else
							local v63 = v61 / 0.9
							local v64 = math.clamp(v63, 0, 1)
							local v65 = v64 * v64 * (3 - v64 * 2) * 3.141592653589793
							v62 = math.sin(v65)
						end
						local v66 = v60 * (v62 * 0.8 + 1)
						local v67 = p55 * 1.5 + v_u_32
						return v56 * v57(v58, v59, v66 + math.sin(v67) * 0.08 * v_u_25) * v_u_54
					end)
					p_u_20.fadeFromBehind(p_u_21, v53, 0.55)
				end
			end
			local v68 = v_u_25 * 2.25
			for _, v69 in { -1, 1 } do
				for _, v70 in { -1, 1 } do
					local v71 = v69 * v31[1]
					local v72 = v70 * v31[1]
					local v73 = Vector3.new(v71, v72, 0)
					local v74 = v69 * v31[4]
					local v75 = v70 * v31[4]
					local v76 = Vector3.new(v74, v75, v68)
					local v77, v78 = p_u_20.between(v73, v76)
					local v79 = p_u_20.bar
					local v80 = v_u_25 * 0.05
					local v81 = v_u_25 * 0.05
					local v82 = v79(Vector3.new(v80, v81, v78), v_u_5, 0.2)
					p_u_20.pin(p_u_21, v_u_30, v82, v77)
					p_u_20.fadeFromBehind(p_u_21, v82, 0.55)
				end
			end
			local v83 = p_u_20.bar
			local v84 = v31[4] * 1.6
			local v85 = v31[4] * 1.6
			local v86 = v_u_25 * 0.05
			local v87 = v83(Vector3.new(v84, v85, v86), v_u_6, 0, v_u_10)
			p_u_20.pin(p_u_21, v_u_30, v87, CFrame.new(0, 0, v68 + v_u_25 * 0.1))
			p_u_20.fadeFromBehind(p_u_21, v87, 0.55)
			local v_u_88 = v31[1]
			local v_u_89 = {}
			for _, v_u_90 in { -1, 1 } do
				local v91 = p_u_20.bar
				local v92 = v_u_88 * 2
				local v93 = v_u_25 * 0.06
				local v94 = v91(Vector3.new(v_u_88, v92, v93), v_u_7, 1)
				p_u_20.bothFaces(v94, v_u_3.BiwaShoji, v_u_4)
				local v95 = {}
				for _, v96 in v94:GetChildren() do
					if not v96:IsA("Decal") then
						continue
					end
					v96.Transparency = 1
					table.insert(v95, v96)
				end
				p_u_20.add(p_u_21, v94, function()
					-- upvalues: (ref) v_u_26, (copy) v_u_90, (copy) v_u_88, (copy) v_u_30, (copy) v_u_25
					local v97 = os.clock() - v_u_26
					local v98 = (v97 - 0.06) / 0.12
					local v99 = math.clamp(v98, 0, 1)
					local v100 = v99 * v99 * (3 - v99 * 2)
					local v101 = (v97 - 0.55) / 0.25
					local v102 = math.clamp(v101, 0, 1)
					local v103 = v100 * (1 - v102 * v102 * (3 - v102 * 2))
					local v104 = v_u_90 * (v_u_88 * 0.5 + v_u_88 * 1.2 * (1 - v103))
					return v_u_30.cf * CFrame.new(v104, 0, v_u_25 * -0.05)
				end)
				p_u_20.fadeFromBehind(p_u_21, v94, 0.5)
				table.insert(v_u_89, {
					["part"] = v94,
					["decals"] = v95,
					["side"] = v_u_90
				})
			end
			local v_u_114 = p_u_20.group(p_u_21, function(p105, p106)
				-- upvalues: (copy) v_u_25
				local v107 = CFrame.new
				local v108 = v_u_25 * 1.55
				local v109 = v_u_25 * 0.05
				local v110 = p106 * 1.2
				local v111 = p105 * v107(v108, v109 + math.sin(v110) * 0.1 * v_u_25, v_u_25 * -0.25)
				local v112 = CFrame.Angles
				local v113 = p106 * 0.8
				return v111 * v112(0, -0.35, math.sin(v113) * 0.04 + -0.22) * CFrame.Angles(0, -2.356194490192345, 0)
			end)
			local v_u_115 = {}
			local v116 = v_u_19(v_u_25 * 2.7)
			if v116 then
				p_u_20.pin(p_u_21, v_u_114, v116, v_u_11)
			else
				p_u_20.pin(p_u_21, v_u_114, p_u_20.blob(Vector3.new(1.2, 1.75, 0.34) * v_u_25, v_u_8, 0, v_u_10), CFrame.identity)
				p_u_20.pin(p_u_21, v_u_114, p_u_20.blob(Vector3.new(1.02, 1.5, 0.06) * v_u_25, v_u_9, 0, v_u_10), CFrame.new(0, v_u_25 * -0.02, v_u_25 * -0.16))
				p_u_20.pin(p_u_21, v_u_114, p_u_20.bar(Vector3.new(0.95, 0.16, 0.06) * v_u_25, v_u_7, 0, v_u_10), CFrame.new(0, v_u_25 * -0.3, v_u_25 * -0.2))
				p_u_20.pin(p_u_21, v_u_114, p_u_20.bar(Vector3.new(0.22, 1.25, 0.16) * v_u_25, v_u_8, 0, v_u_10), CFrame.new(0, v_u_25 * 1.4, 0))
				p_u_20.pin(p_u_21, v_u_114, p_u_20.bar(Vector3.new(0.26, 0.55, 0.2) * v_u_25, v_u_7, 0, v_u_10), CFrame.new(0, v_u_25 * 2.1, v_u_25 * 0.12) * CFrame.Angles(0.55, 0, 0))
				for v117 = 1, 4 do
					local v118 = (v117 - 2.5) * 0.07 * v_u_25
					local v119 = p_u_20.bar
					local v120 = v_u_25 * 0.025
					local v121 = v_u_25 * 2.45
					local v122 = v_u_25 * 0.025
					local v123 = v119(Vector3.new(v120, v121, v122), v_u_23, 0)
					p_u_20.pin(p_u_21, v_u_114, v123, CFrame.new(v118, v_u_25 * 0.75, v_u_25 * -0.22))
					table.insert(v_u_115, {
						["part"] = v123
					})
				end
			end
			local v124 = p_u_20.picture(v_u_25 * 0.95, v_u_3.BiwaBachi, v_u_5, 0)
			p_u_20.add(p_u_21, v124, function()
				-- upvalues: (ref) v_u_26, (copy) v_u_114, (copy) v_u_25
				local v125 = os.clock() - v_u_26
				local v126
				if v125 < 0.14 then
					local v127 = v125 / 0.14
					local v128 = math.clamp(v127, 0, 1)
					v126 = 0.7 - v128 * v128 * (3 - v128 * 2) * 1.4
				else
					local v129 = (v125 - 0.14) / 0.6
					local v130 = math.clamp(v129, 0, 1)
					v126 = v130 * v130 * (3 - v130 * 2) * 1.4 + -0.7
				end
				return v_u_114.cf * CFrame.new(v_u_25 * 0.15, v_u_25 * 0.1, v_u_25 * -0.5) * CFrame.Angles(0, 0, v126) * CFrame.new(0, v_u_25 * 0.3, 0) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v131 = p_u_21.ticks
			local function v143()
				-- upvalues: (ref) v_u_26, (copy) v_u_115, (copy) v_u_23, (ref) v_u_4, (copy) v_u_89
				local v132 = os.clock() - v_u_26
				local v133 = (v132 < 0.07 or v132 >= 0.6) and 0 or 1 - (v132 - 0.07) / 0.6
				for _, v134 in v_u_115 do
					v134.part.Color = v_u_23:Lerp(v_u_4, v133)
				end
				local v135 = (v132 - 0.04) / 0.08
				local v136 = math.clamp(v135, 0, 1)
				local v137 = v136 * v136 * (3 - v136 * 2)
				local v138 = (v132 - 0.6) / 0.3
				local v139 = math.clamp(v138, 0, 1)
				local v140 = v137 * (1 - v139 * v139 * (3 - v139 * 2))
				for _, v141 in v_u_89 do
					for _, v142 in v141.decals do
						v142.Transparency = 1 - v140
					end
				end
			end
			table.insert(v131, v143)
			local v144 = p_u_20.bar(Vector3.new(0.2, 0.2, 0.2), v_u_4, 1)
			p_u_20.add(p_u_21, v144, function(p145)
				-- upvalues: (ref) p_u_20, (copy) p_u_21
				return CFrame.new(p_u_20.feetAt(p_u_21, p145, 0.1))
			end)
			local v_u_146 = Instance.new("ParticleEmitter")
			v_u_146.Texture = v_u_3.BiwaCorridor
			v_u_146.Color = ColorSequence.new(v_u_23)
			v_u_146.LightEmission = 0.25
			v_u_146.LightInfluence = 0
			v_u_146.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_146.EmissionDirection = Enum.NormalId.Top
			v_u_146.SpreadAngle = Vector2.zero
			v_u_146.Speed = NumberRange.new(0.01)
			v_u_146.LockedToPart = true
			v_u_146.Lifetime = NumberRange.new(6)
			v_u_146.Size = NumberSequence.new(v_u_25 * 2.3 * p_u_21.fx)
			v_u_146.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.06, 0.2),
				NumberSequenceKeypoint.new(0.94, 0.2),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_146.Rotation = NumberRange.new(0, 0)
			v_u_146.Rate = 0.16666666666666666
			v_u_146.Parent = v144
			v_u_146:Emit(1)
			local v147 = p_u_21.stops
			table.insert(v147, function()
				-- upvalues: (copy) v_u_146
				v_u_146.Enabled = false
			end)
			p_u_20.particles(p_u_21, "AuraMode", v_u_23, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end