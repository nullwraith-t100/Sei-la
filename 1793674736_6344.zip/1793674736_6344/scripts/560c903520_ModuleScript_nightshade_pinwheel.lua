local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = {
	{
		["angle"] = 38,
		["len"] = 2.5,
		["wide"] = 1.15
	},
	{
		["angle"] = 142,
		["len"] = 2.5,
		["wide"] = 1.15
	},
	{
		["angle"] = 218,
		["len"] = 1.85,
		["wide"] = 0.95
	},
	{
		["angle"] = 322,
		["len"] = 1.85,
		["wide"] = 0.95
	}
}
return function(p_u_6)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_2, (copy) v_u_5
	local v_u_7 = Enum.Material.SmoothPlastic
	local function v_u_18(p8, p9, p10) -- name: whirlFlare
		-- upvalues: (copy) p_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_2
		local v11, v12 = p_u_6.picture(p9, v_u_4.NightPinwheel, p10, 0.15)
		v11.CFrame = p8
		local v13 = v_u_3.tween
		local v14 = {}
		local v15 = p9 * 2.4
		local v16 = p9 * 2.4
		v14.Size = Vector3.new(v15, 0.05, v16)
		v13(v11, 0.55, v14)
		for _, v17 in v12 do
			v_u_3.tween(v17, 0.55, {
				["Transparency"] = 1
			})
		end
		v_u_2:AddItem(v11, 0.6)
	end
	return {
		["w3_nightshade_pinwheel"] = function(p_u_19, p20) -- name: w3_nightshade_pinwheel
			-- upvalues: (copy) p_u_6, (copy) v_u_18, (ref) v_u_3, (ref) v_u_5, (copy) v_u_7, (ref) v_u_4
			local v_u_21 = p_u_19.fx <= 1 and 1 or p_u_19.fx / 1.35
			local v_u_22 = Color3.fromHex(p20.color)
			local v23 = Color3.fromHex(p20.color2)
			local v24 = p_u_6.rgb(12, 5, 22)
			local v_u_25 = p_u_6.rgb(176, 110, 255)
			local v26 = p_u_6.rgb(224, 200, 255)
			local v_u_27 = 0
			local v_u_28 = 0
			local v_u_29 = -10
			local v_u_30 = 2.5
			local v31 = p_u_19.ticks
			local function v40(p32, p33, p34)
				-- upvalues: (ref) v_u_30, (ref) v_u_29, (copy) p_u_19, (ref) p_u_6, (copy) v_u_21, (ref) v_u_18, (copy) v_u_25, (ref) v_u_3, (copy) v_u_22, (ref) v_u_27, (ref) v_u_28
				if v_u_30 <= p33 then
					v_u_30 = p33 + 5
					v_u_29 = p33
					p_u_19.pulse = 1
					if (p32.Position - p_u_6.camPos()).Magnitude < 150 then
						local v35 = p32 * CFrame.new(0, 0.85 * v_u_21, 1 * v_u_21) * CFrame.Angles(1.5707963267948966, 0, 0)
						v_u_18(v35, 4 * v_u_21, v_u_25)
						v_u_3.flash(v35.Position, v_u_22, 4.5 * p_u_19.fx, 0.35)
					end
				end
				local v36 = (p33 - v_u_29) / 0.9
				if v36 >= 0 and v36 < 1 then
					v_u_27 = -(v36 * v36 * (3 - 2 * v36)) * 3.141592653589793 * 2
					local v37 = v36 * 3.141592653589793
					v_u_28 = math.sin(v37)
				else
					v_u_27 = 0
					v_u_28 = 0
				end
				local v38 = p_u_19
				local v39 = p_u_19.pulse - p34 * 2
				v38.pulse = math.max(v39, 0)
			end
			table.insert(v31, v40)
			local v_u_50 = p_u_6.group(p_u_19, function(p41, p42)
				-- upvalues: (copy) v_u_21, (ref) v_u_27
				local v43 = CFrame.new
				local v44 = 0.85 * v_u_21
				local v45 = p42 * 1.4
				local v46 = p41 * v43(0, v44 + math.sin(v45) * 0.05 * v_u_21, 0.8 * v_u_21)
				local v47 = CFrame.Angles
				local v48 = v_u_27
				local v49 = p42 * 0.7
				return v46 * v47(0, 0, v48 + math.sin(v49) * 0.05)
			end)
			local v_u_51 = v_u_28
			for _, v52 in v_u_5 do
				local v53 = v52.angle
				local v_u_54 = math.rad(v53)
				local v_u_55 = v52.len * v_u_21
				local v56 = v52.wide * v_u_21
				local function v_u_60(p57) -- name: root
					-- upvalues: (ref) v_u_51, (copy) v_u_50, (copy) v_u_54, (copy) v_u_21
					local v58 = p57 * 2.4
					local v59 = (math.sin(v58) * 0.22 + 0.35) * (1 - v_u_51)
					return v_u_50.cf * CFrame.Angles(0, 0, v_u_54 - 1.5707963267948966) * CFrame.new(0, 0.25 * v_u_21, 0) * CFrame.Angles(v59, 0, 0)
				end
				local function v62(_, p61) -- name: blade
					-- upvalues: (copy) v_u_60, (copy) v_u_55
					return v_u_60(p61) * CFrame.new(0, v_u_55 / 2, 0)
				end
				local v63 = p_u_6.add
				local v64 = p_u_6.blob
				local v65 = 0.12 * v_u_21
				v63(p_u_19, v64(Vector3.new(v56, v_u_55, v65), v24, 0, v_u_7), v62)
				local v66 = p_u_6.add
				local v67 = p_u_6.blob
				local v68 = v56 * 1.3
				local v69 = v_u_55 * 1.12
				local v70 = 0.1 * v_u_21
				v66(p_u_19, v67(Vector3.new(v68, v69, v70), v_u_25, 0.35), p_u_6.behind(v62, 0.1 * v_u_21))
				local v71 = p_u_6.add
				local v72 = p_u_6.blob
				local v73 = v56 * 0.55
				local v74 = v_u_55 * 0.5
				local v75 = 0.12 * v_u_21
				v71(p_u_19, v72(Vector3.new(v73, v74, v75), v24, 0, v_u_7), function(_, p76)
					-- upvalues: (copy) v_u_60, (copy) v_u_55
					return v_u_60(p76) * CFrame.new(0, v_u_55 * 0.92, 0) * CFrame.Angles(0, 0, 0.75) * CFrame.new(0, v_u_55 * 0.22, 0)
				end)
				p_u_6.add(p_u_19, p_u_6.ball(0.42 * v_u_21, v_u_25, 0), function(_, p77)
					-- upvalues: (copy) v_u_60, (copy) v_u_55, (copy) v_u_21
					return v_u_60(p77) * CFrame.new(0, v_u_55 * 0.62, 0.08 * v_u_21)
				end)
			end
			for v_u_78 = 1, 3 do
				local v_u_79 = p_u_6.picture(1.3 * v_u_21, v_u_4.NightMoth, v_u_25, 0.05)
				p_u_6.tail(v_u_79, v_u_25, v23, 0.25 * v_u_21, 0.35)
				local v80 = p_u_19.ticks
				table.insert(v80, function(_, p81)
					-- upvalues: (copy) v_u_78, (copy) v_u_79, (copy) v_u_21
					local v82 = p81 * 20 + v_u_78 * 1.7
					local v83 = math.cos(v82)
					local v84 = math.abs(v83)
					local v85 = v_u_79
					local v86 = 1.3 * v_u_21 * (v84 * 0.75 + 0.25)
					local v87 = 1.3 * v_u_21
					v85.Size = Vector3.new(v86, 0.05, v87)
				end)
				p_u_6.add(p_u_19, v_u_79, function(p88, p89)
					-- upvalues: (copy) v_u_78, (copy) v_u_21, (ref) p_u_6
					local v90 = p89 * (v_u_78 * 0.17 + 0.9) + v_u_78 * 2.1
					local v91 = p89 * 1.3 + v_u_78
					local v92 = (math.sin(v91) * 0.4 + 2.4) * v_u_21
					local v93 = p88.Position
					local v94 = math.cos(v90) * v92
					local v95 = (v_u_78 - 2) * 0.9 + -0.6
					local v96 = p89 * 2.2 + v_u_78
					local v97 = (v95 + math.sin(v96) * 0.5) * v_u_21
					local v98 = math.sin(v90) * v92
					local v99 = v93 + Vector3.new(v94, v97, v98)
					return CFrame.lookAt(v99, p_u_6.camPos()) * CFrame.Angles(-1.5707963267948966, 0, 0)
				end)
			end
			p_u_6.particles(p_u_19, "AuraMode", v_u_22, {
				["rate"] = 0.45,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "FlameBack" }
			})
			p_u_6.particles(p_u_19, "Petals", v26, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end