local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromRGB(16, 64, 178)
local v_u_8 = Color3.fromRGB(110, 205, 255)
local function v_u_17(p9, p10) -- name: piece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v11 = v_u_2:FindFirstChild("EyePieces")
	if v11 then
		v11 = v11:FindFirstChild("w6_raging_current")
	end
	if not (v11 and v11:IsA("MeshPart")) then
		return nil
	end
	local v12 = v11:Clone()
	v12.Anchored = true
	v12.CanCollide = false
	v12.CanQuery = false
	v12.CanTouch = false
	v12.CastShadow = false
	v12.Massless = true
	local v13 = v11.Size.X
	local v14 = v11.Size.Y
	local v15 = v11.Size.Z
	local v16 = math.max(v13, v14, v15, 0.01)
	v12.Size = v11.Size * (p9 / v16)
	if not v12:FindFirstChildWhichIsA("SurfaceAppearance") then
		v12.Color = p10
	end
	v12.Parent = v_u_4.folder()
	return v12
end
return function(p_u_18)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_3, (copy) v_u_1, (copy) v_u_17, (copy) v_u_8, (copy) v_u_7, (copy) v_u_5
	return {
		["w6_raging_current"] = function(p_u_19, p20)
			-- upvalues: (ref) v_u_4, (copy) p_u_18, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1, (ref) v_u_17, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5
			local v_u_21 = v_u_4.color(p20.color)
			local v_u_22 = v_u_4.color(p20.color2)
			local v23 = p_u_19.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v_u_29 = p_u_18.throb(p_u_19, 4.2, 2.2, 1.6, function(p25)
				-- upvalues: (ref) p_u_18, (copy) p_u_19, (ref) v_u_4, (copy) v_u_21, (ref) v_u_6, (ref) v_u_3, (copy) v_u_22, (ref) v_u_1
				local v26 = p_u_18.feetAt(p_u_19, p25, 0.2)
				v_u_4.ring(v26, v_u_21, 5.5 * p_u_19.fx, 0.5, v_u_6.Ring)
				local v27 = Instance.new("Attachment")
				v27.Parent = v_u_3.Terrain
				v27.WorldPosition = v26
				local v28 = Instance.new("ParticleEmitter")
				v28.Texture = v_u_6.CurrentRing
				v28.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v28.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v28.Color = ColorSequence.new(v_u_22)
				v28.Size = NumberSequence.new(6 * p_u_19.fx)
				v28.Transparency = NumberSequence.new(0)
				v28.Lifetime = NumberRange.new(0.5)
				v28.Speed = NumberRange.new(0.02)
				v28.SpreadAngle = Vector2.zero
				v28.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
				v28.LightEmission = 0.2
				v28.LightInfluence = 0
				v28.Rate = 0
				v28.Parent = v27
				v28:Emit(1)
				v_u_1:AddItem(v27, 0.8)
			end)
			local v_u_30 = 0
			local v31 = p_u_19.ticks
			local function v33(_, _, p32)
				-- upvalues: (ref) v_u_30, (copy) v_u_29
				v_u_30 = v_u_30 + p32 * (0.9 + 9 * v_u_29())
			end
			table.insert(v31, v33)
			local v_u_40 = p_u_18.group(p_u_19, function(p34, p35)
				-- upvalues: (copy) v_u_24
				local v36 = CFrame.new
				local v37 = v_u_24 * 0.85
				local v38 = v_u_24 * 0.12
				local v39 = p35 * 1.6
				return p34 * v36(0, v37 + v38 * math.sin(v39), v_u_24 * 1.2)
			end)
			local v41 = p_u_18.picture(v_u_24 * 4.2, v_u_6.Glow, v_u_21, 0.5)
			p_u_18.add(p_u_19, v41, function()
				-- upvalues: (copy) v_u_40, (copy) v_u_24
				return v_u_40.cf * CFrame.new(0, 0, v_u_24 * -0.25) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v42 = p_u_18.picture(v_u_24 * 1.9, v_u_6.Swirl, v_u_22, 0.35)
			p_u_18.add(p_u_19, v42, function()
				-- upvalues: (copy) v_u_40, (ref) v_u_30
				return v_u_40.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v_u_30 * 1.6, 0)
			end)
			local v43 = v_u_17(v_u_24 * 2.9, v_u_21)
			if v43 then
				p_u_18.add(p_u_19, v43, function()
					-- upvalues: (copy) v_u_40, (ref) v_u_30
					return v_u_40.cf * CFrame.Angles(0, 0, -v_u_30)
				end)
			else
				local v44 = p_u_18.group(p_u_19, function()
					-- upvalues: (copy) v_u_40, (ref) v_u_30
					return v_u_40.cf * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, v_u_30, 0)
				end)
				p_u_18.ring(p_u_19, v44, 10, v_u_24 * 1.2, v_u_24 * 0.24, v_u_21)
				p_u_18.pin(p_u_19, v44, p_u_18.ball(v_u_24 * 0.5, v_u_22), CFrame.new(v_u_24 * 1.2, 0, 0))
			end
			local v_u_45 = p_u_19.headY - p_u_19.feet
			for v_u_46 = 1, 3 do
				local v47 = p_u_18.bar(Vector3.new(0.15, 0.15, 0.15), v_u_21, 1)
				p_u_18.add(p_u_19, v47, function(p48, p49)
					-- upvalues: (copy) v_u_46, (copy) v_u_24, (copy) p_u_19, (copy) v_u_45
					local v50 = p49 * 3.1 + v_u_46 * 2.09
					local v51 = p49 * 1.9 + v_u_46 * 2.4
					local v52 = math.sin(v51) * 0.5 + 0.5
					local v53 = (1.55 - v52 * 0.3) * v_u_24
					return p48 * CFrame.new(math.cos(v50) * v53, p_u_19.feet + 0.3 + v52 * v_u_45 * 0.9, math.sin(v50) * v53)
				end)
				local v54 = p_u_18.tail
				local v55
				if v_u_46 == 2 then
					v55 = v_u_22
				else
					v55 = v_u_8
				end
				v54(v47, v55, v_u_7, v_u_24 * 0.34, 0.5)
			end
			local v_u_56 = Instance.new("Attachment")
			local v57 = p_u_19.feet + 0.3
			v_u_56.Position = Vector3.new(0, v57, 0)
			local v_u_58 = Instance.new("ParticleEmitter")
			v_u_58.Texture = v_u_6.Glow
			v_u_58.Color = ColorSequence.new(v_u_22, v_u_8)
			v_u_58.LightEmission = 0.35
			v_u_58.LightInfluence = 0
			v_u_58.Size = NumberSequence.new(0.28 * p_u_19.fx, 0.1 * p_u_19.fx)
			v_u_58.Lifetime = NumberRange.new(0.6, 0.9)
			v_u_58.Speed = NumberRange.new(5 * p_u_19.fx, 8 * p_u_19.fx)
			v_u_58.SpreadAngle = Vector2.new(35, 35)
			local v59 = -28 * p_u_19.fx
			v_u_58.Acceleration = Vector3.new(0, v59, 0)
			v_u_58:SetAttribute("BaseRate", 7)
			v_u_58.Rate = 7 * v_u_5.formRate()
			v_u_58.Parent = v_u_56
			v_u_56.Parent = p_u_19.root
			p_u_18.own(p_u_19, v_u_56)
			local v60 = p_u_19.stops
			local function v61()
				-- upvalues: (copy) v_u_58, (ref) v_u_1, (copy) v_u_56
				v_u_58.Enabled = false
				v_u_1:AddItem(v_u_56, 1)
			end
			table.insert(v60, v61)
			p_u_18.particles(p_u_19, "AuraMode", v_u_21, {
				["rate"] = 0.35,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_18.particles(p_u_19, "Petals", v_u_22, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end