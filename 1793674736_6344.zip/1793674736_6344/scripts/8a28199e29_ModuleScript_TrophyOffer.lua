local v_u_1 = require(script.Parent.Parent.Config.Perks)
local v_u_2 = require(script.Parent.Parent.Config.Products)
local v_u_3 = require(script.Parent.Parent.Config.Stages)
local v_u_4 = require(script.Parent.AutoWin)
local v_u_5 = require(script.Parent.Format)
local v_u_35 = {
	["ITEMS"] = {
		{
			["key"] = "winsPad",
			["kind"] = "pass"
		},
		{
			["key"] = "vip",
			["kind"] = "pass"
		},
		{
			["key"] = "autoWin",
			["kind"] = "pass"
		},
		{
			["key"] = "boostWins",
			["kind"] = "product"
		}
	},
	["ARRIVAL_GAP"] = 20,
	["EVERY"] = 240,
	["WAIT_UP_TO"] = 180,
	["pick"] = function(p6, p7) -- name: pick
		-- upvalues: (copy) v_u_35
		local v8 = {}
		for _, v9 in v_u_35.ITEMS do
			if not p6[v9.key] or v9.kind == "pass" and p7[v9.key] then
				continue
			end
			table.insert(v8, v9)
		end
		return v8
	end,
	["autoWin"] = function(p10, p11, p12) -- name: autoWin
		-- upvalues: (copy) v_u_4, (copy) v_u_3
		local v13 = v_u_4.stage(v_u_3.forWorld(p10), p11, p12)
		if v13 <= 0 then
			return nil, nil
		else
			return v13, v_u_4.interval(v13)
		end
	end,
	["every"] = function(p14) -- name: every
		local v15 = p14 + 0.5
		local v16 = math.floor(v15)
		local v17 = math.max(v16, 1)
		if v17 < 60 then
			return ("%* s"):format(v17)
		else
			local v18 = v17 // 60
			local v19 = v17 % 60
			if v19 == 0 then
				return ("%* min"):format(v18)
			else
				return ("%* min %* s"):format(v18, v19)
			end
		end
	end,
	["line"] = function(p20, p21, p22) -- name: line
		-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_1, (copy) v_u_35, (copy) v_u_2
		if p20 == "winsPad" then
			return ("%* Trophies from the purple pads"):format((v_u_5.mult(v_u_3.PURPLE_PAD)))
		end
		if p20 == "vip" then
			return ("%* Trophies from every pad"):format((v_u_5.mult(v_u_1.VIP_TROPHIES)))
		end
		if p20 == "autoWin" then
			return not (p21 and p22) and "Wins your best stage\'s Trophies while you train" or ("Stage %*\'s Trophies every %* while you train"):format(p21, (v_u_35.every(p22)))
		end
		if p20 ~= "boostWins" then
			return ""
		end
		local v23 = v_u_2.productByKey.boostWins
		local v24 = v23 and (v23.mult or 2) or 2
		local v25 = v23 and v23.minutes or 10
		return ("%* Trophies from every pad for %* min"):format(v_u_5.mult(v24), v25)
	end,
	["memory"] = function() -- name: memory
		return {
			["at"] = (-1 / 0),
			["world"] = 0,
			["stage"] = 0,
			["shownAt"] = (-1 / 0)
		}
	end,
	["arrive"] = function(p26, p27, p28, p29) -- name: arrive
		-- upvalues: (copy) v_u_35
		local v30 = (p28 ~= p26.world or p29 ~= p26.stage) and true or p27 - p26.at > v_u_35.ARRIVAL_GAP
		p26.at = p27
		p26.world = p28
		p26.stage = p29
		return v30
	end,
	["due"] = function(p31, p32) -- name: due
		-- upvalues: (copy) v_u_35
		return p32 - p31.shownAt >= v_u_35.EVERY
	end,
	["shown"] = function(p33, p34) -- name: shown
		p33.shownAt = p34
	end
}
return v_u_35