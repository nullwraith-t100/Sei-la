local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v_u_1.Shared.Config.Textures)
local v_u_4 = Color3.fromHex("D8DCE8")
local v_u_5 = Color3.fromRGB(205, 170, 255)
local v_u_6 = Color3.fromRGB(60, 16, 110)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Enum.PartType.Wedge
local v_u_9 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_10 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_19(p11, p12) -- name: eyePiece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v13 = v_u_1:FindFirstChild("EyePieces")
	if v13 then
		v13 = v13:FindFirstChild(p11)
	end
	if not (v13 and v13:IsA("MeshPart")) then
		return nil
	end
	local v14 = v13:Clone()
	local v15 = v13.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	v14.Size = v15 * (p12 / math.max(v16, v17, v18, 0.01))
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanQuery = false
	v14.CanTouch = false
	v14.Massless = true
	v14.CastShadow = false
	v14.Parent = v_u_2.folder()
	return v14
end
return function(p_u_20)
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (copy) v_u_9, (copy) v_u_19, (copy) v_u_4, (copy) v_u_10, (copy) v_u_8, (copy) v_u_6, (copy) v_u_7
	return {
		["w6_shinso_edge"] = function(p_u_21, p22)
			-- upvalues: (ref) v_u_2, (copy) p_u_20, (ref) v_u_5, (ref) v_u_3, (ref) v_u_9, (ref) v_u_19, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
			local v_u_23 = v_u_2.color(p22.color)
			local v24 = p_u_21.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v_u_27 = p_u_20.throb(p_u_21, 3.5, 1.2, 2.6, function(p26)
				-- upvalues: (ref) v_u_2, (ref) p_u_20, (copy) p_u_21, (ref) v_u_5, (ref) v_u_3, (copy) v_u_25, (copy) v_u_23
				v_u_2.ring(p_u_20.feetAt(p_u_21, p26, 0.15), v_u_5, 5 * p_u_21.fx, 0.45, v_u_3.Ring)
				v_u_2.flash((p26 * CFrame.new(0, v_u_25 * 1.1, v_u_25 * 1.9)).Position, v_u_23, v_u_25 * 4, 0.25)
			end)
			local v_u_28 = 0
			local v29 = p_u_21.ticks
			local function v31(_, _, p30)
				-- upvalues: (ref) v_u_28, (copy) v_u_27
				v_u_28 = v_u_28 + p30 * (0.7 + v_u_27() * 9)
			end
			table.insert(v29, v31)
			local v_u_37 = p_u_20.group(p_u_21, function(p32, p33)
				-- upvalues: (copy) v_u_25
				local v34 = CFrame.new
				local v35 = v_u_25 * 1.1
				local v36 = p33 * 1.3
				return p32 * v34(0, v35 + math.sin(v36) * 0.12 * v_u_25, v_u_25 * 1.9)
			end)
			local v_u_38 = p_u_20.picture(v_u_25 * 10, v_u_3.Glow, v_u_23, 0.15)
			p_u_20.pin(p_u_21, v_u_37, v_u_38, CFrame.new(0, 0, v_u_25 * -0.3) * v_u_9)
			p_u_20.fadeFromBehind(p_u_21, v_u_38, 0.5)
			local v_u_39 = p_u_20.picture(v_u_25 * 3.1, v_u_3.Ring, v_u_23, 0.15)
			p_u_20.pin(p_u_21, v_u_37, v_u_39, CFrame.new(0, 0, v_u_25 * -0.1) * v_u_9)
			local v40 = v_u_19("w6_shinso_edge", v_u_25 * 4.2)
			local v_u_41 = nil
			local v_u_42 = 1
			if v40 then
				local v43 = v40:FindFirstChildOfClass("SurfaceAppearance")
				if v43 then
					v_u_42 = v43.EmissiveStrength
				else
					v40.Color = v_u_4
					v40.Material = Enum.Material.Metal
					v43 = v_u_41
				end
				p_u_20.add(p_u_21, v40, function(_, p44)
					-- upvalues: (copy) v_u_37, (ref) v_u_28, (ref) v_u_10
					local v45 = v_u_37.cf
					local v46 = CFrame.Angles
					local v47 = v_u_28
					local v48 = p44 * 0.9
					return v45 * v46(0, v47, math.sin(v48) * 0.12) * v_u_10
				end)
				v_u_41 = v43
			else
				local v54 = p_u_20.group(p_u_21, function(_, p49)
					-- upvalues: (copy) v_u_37, (ref) v_u_28
					local v50 = v_u_37.cf
					local v51 = CFrame.Angles
					local v52 = v_u_28
					local v53 = p49 * 0.9
					return v50 * v51(0, v52, math.sin(v53) * 0.12)
				end)
				local v55 = p_u_20.bar
				local v56 = v_u_25 * 0.34
				local v57 = v_u_25 * 1.8
				local v58 = v_u_25 * 0.08
				local v59 = v55(Vector3.new(v56, v57, v58), v_u_4)
				p_u_20.pin(p_u_21, v54, v59, CFrame.new(0, v_u_25 * 0.35, 0))
				for _, v60 in { 1, -1 } do
					local v61 = p_u_20.bar
					local v62 = v_u_25 * 0.08
					local v63 = v_u_25 * 0.17
					local v64 = v_u_25 * 0.5
					local v65 = v61(Vector3.new(v62, v63, v64), v_u_4)
					v65.Shape = v_u_8
					p_u_20.pin(p_u_21, v54, v65, CFrame.new(v60 * 0.085 * v_u_25, v_u_25 * 1.5, 0) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, 0, -v60 * 3.141592653589793 / 2))
				end
				local v66 = p_u_20.pin
				local v67 = p_u_20.bar
				local v68 = v_u_25 * 0.7
				local v69 = v_u_25 * 0.12
				local v70 = v_u_25 * 0.22
				v66(p_u_21, v54, v67(Vector3.new(v68, v69, v70), v_u_23), CFrame.new(0, v_u_25 * -0.6, 0))
				local v71 = p_u_20.pin
				local v72 = p_u_20.bar
				local v73 = v_u_25 * 0.16
				local v74 = v_u_25 * 0.7
				local v75 = v_u_25 * 0.16
				v71(p_u_21, v54, v72(Vector3.new(v73, v74, v75), v_u_6, 0, Enum.Material.SmoothPlastic), CFrame.new(0, v_u_25 * -1, 0))
			end
			local v_u_76 = v_u_25 * 0.3
			local v_u_77 = {}
			for v78 = 0, 2 do
				local v79 = p_u_20.bar
				local v80 = v_u_25 * 0.06
				local v81 = v79(Vector3.new(v_u_76, v80, 1), v_u_4)
				local v82 = p_u_20.bar
				local v83 = v_u_25 * 0.06
				local v84 = v_u_76 / 2
				local v85 = v_u_76 * 1.8
				local v86 = v82(Vector3.new(v83, v84, v85), v_u_4)
				v86.Shape = v_u_8
				local v87 = p_u_20.bar
				local v88 = v_u_25 * 0.06
				local v89 = v_u_76 / 2
				local v90 = v_u_76 * 1.8
				local v91 = v87(Vector3.new(v88, v89, v90), v_u_4)
				v91.Shape = v_u_8
				local v92 = {
					["body"] = v81,
					["tipA"] = v86,
					["tipB"] = v91,
					["a"] = v78 * 3.141592653589793 * 2 / 3
				}
				table.insert(v_u_77, v92)
			end
			local v_u_93 = 0
			local v94 = p_u_21.ticks
			local function v96(_, _, p95)
				-- upvalues: (ref) v_u_93
				v_u_93 = v_u_93 + p95 * 0.6
			end
			table.insert(v94, v96)
			local function v_u_106(p97) -- name: lay
				-- upvalues: (copy) v_u_27, (copy) v_u_25, (ref) v_u_93
				local v98 = v_u_27()
				local v99 = math.min(v98, 1) * 3.141592653589793 * 0.5
				local v100 = (math.sin(v99) ^ 2 * 2.6 + 1.1) * v_u_25
				local v101 = p97.a + v_u_93
				local v102 = math.cos(v101)
				local v103 = math.sin(v101)
				local v104 = Vector3.new(v102, v103, 0)
				local v105 = v104 * 1.15 * v_u_25
				return CFrame.lookAt(v105, v105 + v104, Vector3.new(0, 0, 1)), v100
			end
			for _, v_u_107 in v_u_77 do
				p_u_20.add(p_u_21, v_u_107.body, function()
					-- upvalues: (copy) v_u_106, (copy) v_u_107, (copy) v_u_76, (copy) v_u_25, (copy) v_u_37
					local v108, v109 = v_u_106(v_u_107)
					local v110 = v_u_107.body
					local v111 = v_u_76
					local v112 = v_u_25 * 0.06
					v110.Size = Vector3.new(v111, v112, v109)
					return v_u_37.cf * v108 * CFrame.new(0, 0, -v109 / 2)
				end)
				p_u_20.add(p_u_21, v_u_107.tipA, function()
					-- upvalues: (copy) v_u_106, (copy) v_u_107, (copy) v_u_37, (copy) v_u_76
					local v113, v114 = v_u_106(v_u_107)
					return v_u_37.cf * v113 * CFrame.new(v_u_76 / 4, 0, -v114 - v_u_76 * 0.9) * CFrame.Angles(0, 0, -1.5707963267948966)
				end)
				p_u_20.add(p_u_21, v_u_107.tipB, function()
					-- upvalues: (copy) v_u_106, (copy) v_u_107, (copy) v_u_37, (copy) v_u_76
					local v115, v116 = v_u_106(v_u_107)
					return v_u_37.cf * v115 * CFrame.new(-v_u_76 / 4, 0, -v116 - v_u_76 * 0.9) * CFrame.Angles(0, 0, 1.5707963267948966)
				end)
			end
			local v_u_117 = -1
			local v118 = p_u_21.ticks
			local function v126()
				-- upvalues: (copy) v_u_27, (ref) v_u_117, (copy) v_u_25, (copy) v_u_38, (copy) v_u_39, (ref) v_u_41, (ref) v_u_42, (copy) v_u_77, (ref) v_u_4, (ref) v_u_7
				local v119 = v_u_27()
				local v120 = v119 - v_u_117
				if math.abs(v120) >= 0.01 then
					v_u_117 = v119
					local v121 = v_u_25 * 10 * (1 + v119 * 0.35)
					v_u_38.Size = Vector3.new(v121, 0.05, v121)
					local v122 = v_u_25 * 3.1 * (1 + v119 * 0.25)
					v_u_39.Size = Vector3.new(v122, 0.05, v122)
					local v123 = v_u_41
					if v123 then
						v123.EmissiveStrength = v_u_42 * (1 + v119 * 2)
					end
					for _, v124 in v_u_77 do
						local v125 = v_u_4:Lerp(v_u_7, v119)
						v124.body.Color = v125
						v124.tipA.Color = v125
						v124.tipB.Color = v125
					end
				end
			end
			table.insert(v118, v126)
			p_u_20.particles(p_u_21, "AuraMode", v_u_23, {
				["rate"] = 0.35,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_20.particles(p_u_21, "Petals", v_u_5, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end