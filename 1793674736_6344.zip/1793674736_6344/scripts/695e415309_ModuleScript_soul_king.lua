local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Bars)
local v_u_6 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v7 = require(script.Parent.Parent.Preload)
local v_u_8 = require(script.Parent.Parent.Parent.Sfx)
local v_u_9 = require(v_u_3.Shared.Config.Textures)
v7.images({ v_u_9.SoulSeal, v_u_9.SoulGem })
local v_u_10 = Color3.fromHex("34E5FF")
local v_u_11 = Color3.fromHex("0A1A3A")
local v_u_12 = Color3.fromRGB(10, 70, 160)
local v_u_13 = Color3.fromRGB(196, 250, 255)
local v_u_14 = Color3.fromRGB(255, 196, 70)
local v_u_15 = Color3.new(1, 1, 1)
local v_u_16 = Enum.Material.Glass
local v_u_17 = Enum.Material.Neon
local function v_u_49(p18, p19, p20, p21, p22, p23, p24, p25, p26, p27) -- name: groundPic
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v28 = p24 + p25 + p26
	local v29 = math.max(v28, 0.05)
	local v30 = {}
	local v31 = {}
	for v32 = 0, 12 do
		local v33 = v32 / 12
		local v34 = v33 * v29
		local v35 = v34 / math.max(p24, 0.001)
		local v36 = math.clamp(v35, 0, 1) - 1
		local v37 = v36 * 2.7 * v36 * v36 + 1 + v36 * 1.7 * v36
		local v38 = (v34 - p24 - p25) / math.max(p26, 0.001)
		local v39 = math.clamp(v38, 0, 1)
		local v40 = v39 * v39 * (3 - v39 * 2)
		local v41 = NumberSequenceKeypoint.new
		local v42 = p19 + (p20 - p19) * v37 + p20 * 0.1 * v40
		local v43 = math.max(v42, 0.05) / 2
		table.insert(v31, v41(v33, v43))
		local v44 = NumberSequenceKeypoint.new
		local v45 = p23 + (1 - p23) * v40
		local v46 = math.clamp(v45, 0, 1)
		table.insert(v30, v44(v33, v46))
	end
	local v47 = Instance.new("Attachment")
	v47.WorldPosition = p18
	v47.Parent = v_u_4.Terrain
	local v48 = Instance.new("ParticleEmitter")
	v48.Enabled = false
	v48.Texture = p21
	v48.Color = ColorSequence.new(p22)
	v48.LightEmission = 0
	v48.LightInfluence = 0
	v48.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v48.EmissionDirection = Enum.NormalId.Top
	v48.SpreadAngle = Vector2.zero
	v48.Speed = NumberRange.new(0.01)
	v48.Size = NumberSequence.new(v31)
	v48.Transparency = NumberSequence.new(v30)
	v48.Lifetime = NumberRange.new(v29)
	v48.Rotation = NumberRange.new(0, 360)
	v48.RotSpeed = NumberRange.new((math.deg(p27)))
	v48.Parent = v47
	v48:Emit(1)
	v_u_1:AddItem(v47, v29 + 0.2)
end
local function v_u_56(p50, p51, p52, p53) -- name: starFlash
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_1
	local v54 = Instance.new("Attachment")
	v54.WorldPosition = p50
	v54.Parent = v_u_4.Terrain
	local v55 = Instance.new("ParticleEmitter")
	v55.Enabled = false
	v55.Texture = v_u_9.SoulSeal
	v55.Color = ColorSequence.new(p53)
	v55.LightEmission = 0.2
	v55.LightInfluence = 0
	v55.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p51 * 0.1), NumberSequenceKeypoint.new(0.3, p51 * 0.48), NumberSequenceKeypoint.new(1, p51 * 0.55) })
	v55.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v55.Lifetime = NumberRange.new(p52)
	v55.Speed = NumberRange.new(0)
	v55.RotSpeed = NumberRange.new(40, 60)
	v55.ZOffset = 1
	v55.Parent = v54
	v55:Emit(1)
	v_u_1:AddItem(v54, p52 + 0.2)
end
local function v_u_64(p57, p58, p59, p60, p61) -- name: diamonds
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_1
	if p58 > 0 then
		local v62 = Instance.new("Attachment")
		v62.WorldPosition = p57
		v62.Parent = v_u_4.Terrain
		local v63 = Instance.new("ParticleEmitter")
		v63.Enabled = false
		v63.Texture = v_u_9.SoulGem
		v63.Color = ColorSequence.new(v_u_10, v_u_13)
		v63.LightEmission = 0.35
		v63.LightInfluence = 0
		v63.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p59), NumberSequenceKeypoint.new(0.75, p59 * 0.8), NumberSequenceKeypoint.new(1, 0) })
		v63.Lifetime = NumberRange.new(p61 * 0.6, p61)
		v63.Speed = NumberRange.new(p60 * 0.35, p60)
		v63.SpreadAngle = Vector2.new(180, 180)
		v63.Drag = 1.6
		v63.Acceleration = Vector3.new(0, -6, 0)
		v63.Rotation = NumberRange.new(0, 360)
		v63.RotSpeed = NumberRange.new(-180, 180)
		v63.Parent = v62
		v63:Emit(p58)
		v_u_1:AddItem(v62, p61 + 0.3)
	end
end
local function v_u_73(p65, p66, p67, p68, p69, p_u_70) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_15, (copy) v_u_1
	local v_u_71 = Instance.new("ColorCorrectionEffect")
	v_u_71.Name = "SoulKing"
	v_u_71.Parent = v_u_2
	v_u_6.tween(v_u_71, p68, {
		["TintColor"] = p65,
		["Brightness"] = p66,
		["Saturation"] = p67
	})
	task.delay(p68 + p69, function()
		-- upvalues: (ref) v_u_6, (copy) v_u_71, (copy) p_u_70, (ref) v_u_15
		local v72 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_15
		}
		v_u_6.tween(v_u_71, p_u_70, v72)
	end)
	v_u_1:AddItem(v_u_71, p68 + p69 + p_u_70 + 0.1)
end
local function v_u_96(p74, p75, p76, p77, p78) -- name: gemParts
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_13, (copy) v_u_17, (copy) v_u_16, (copy) v_u_1
	local v79 = p74 / 2
	local v80 = p75 / 2
	local v81 = Vector3.new(p76, v79, v80)
	local v82 = {}
	local v83 = {}
	for v84, v85 in {
		CFrame.new(0, p74 / 4, -p75 / 4),
		CFrame.new(0, p74 / 4, p75 / 4) * CFrame.Angles(0, 3.141592653589793, 0),
		CFrame.new(0, -p74 / 4, p75 / 4) * CFrame.Angles(3.141592653589793, 0, 0),
		CFrame.new(0, -p74 / 4, -p75 / 4) * CFrame.Angles(3.141592653589793, 0, 0) * CFrame.Angles(0, 3.141592653589793, 0)
	} do
		local v86 = v84 == 1 and true or v84 == 4
		local v87 = v_u_6.part
		local v88 = CFrame.new(0, -500, 0)
		local v89
		if v86 then
			v89 = v_u_10
		else
			v89 = v_u_13
		end
		local v90 = {}
		local v91
		if v86 then
			v91 = v_u_17
		else
			v91 = v_u_16
		end
		v90.material = v91
		local v92
		if v86 then
			v92 = p78
		else
			local v93 = p78 + 0.1
			v92 = math.min(v93, 1)
		end
		v90.transparency = v92
		local v94 = v87(v81, v88, v89, v90)
		local v95 = Instance.new("SpecialMesh")
		v95.MeshType = Enum.MeshType.Wedge
		v95.Parent = v94
		v_u_1:AddItem(v94, p77)
		table.insert(v82, v94)
		table.insert(v83, v85)
	end
	return v82, v83
end
local function v_u_107(p97, p98) -- name: crystalPiece
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1
	local v99 = v_u_3:FindFirstChild("EyePieces")
	if v99 then
		v99 = v99:FindFirstChild("w7_soul_king")
	end
	if not (v99 and v99:IsA("MeshPart")) then
		return nil
	end
	local v100 = v99:Clone()
	local v101 = v99.Size
	local v102 = v99.Size.X
	local v103 = v99.Size.Y
	local v104 = v99.Size.Z
	v100.Size = v101 * (p97 / math.max(v102, v103, v104, 0.01))
	v100.Anchored = true
	v100.CanCollide = false
	v100.CanQuery = false
	v100.CanTouch = false
	v100.CastShadow = false
	local v105 = v100:FindFirstChildOfClass("SurfaceAppearance")
	if v105 then
		local v106 = v105.EmissiveStrength
		v105.EmissiveStrength = math.max(v106, 6)
	end
	v100.CFrame = CFrame.new(0, -500, 0)
	v100.Parent = v_u_6.folder()
	v_u_1:AddItem(v100, p98)
	return v100
end
local function v_u_136(p_u_108, p109, p110) -- name: newCrystal
	-- upvalues: (copy) v_u_107, (copy) v_u_96, (copy) v_u_5, (copy) v_u_14, (copy) v_u_1
	local v_u_111 = v_u_107(p_u_108, p109)
	if v_u_111 then
		local v_u_112 = v_u_111.Size
		v_u_111.Transparency = p110
		return {
			["parts"] = { v_u_111 },
			["place"] = function(p113, p114) -- name: place
				-- upvalues: (copy) v_u_111, (copy) v_u_112
				v_u_111.Size = v_u_112 * math.max(p114, 0.02)
				v_u_111.CFrame = p113
			end,
			["gone"] = function() -- name: gone
				-- upvalues: (copy) v_u_111
				v_u_111:Destroy()
			end
		}
	end
	local v_u_115, v_u_116 = v_u_96(p_u_108, p_u_108 * 0.48, p_u_108 * 0.48, p109, p110)
	local v117, v118 = v_u_96(p_u_108, p_u_108 * 0.48, p_u_108 * 0.48, p109, p110)
	for v119, v120 in v117 do
		table.insert(v_u_115, v120)
		local v121 = CFrame.Angles(0, 1.5707963267948966, 0) * v118[v119]
		table.insert(v_u_116, v121)
	end
	local v_u_122 = v_u_5.new(v_u_14, 0, Enum.Material.Metal)
	local v_u_123 = {}
	for _, v124 in v_u_115 do
		local v125 = v124.Size
		table.insert(v_u_123, v125)
	end
	local v_u_126 = {}
	for _, v127 in v_u_115 do
		table.insert(v_u_126, v127)
	end
	for _, v128 in v_u_122 do
		v_u_1:AddItem(v128, p109)
		table.insert(v_u_126, v128)
	end
	return {
		["parts"] = v_u_126,
		["place"] = function(p129, p130) -- name: place
			-- upvalues: (copy) v_u_115, (copy) v_u_116, (copy) v_u_123, (ref) v_u_5, (copy) v_u_122, (copy) p_u_108
			local v131 = math.max(p130, 0.02)
			for v132, v133 in v_u_115 do
				local v134 = v_u_116[v132]
				v133.Size = v_u_123[v132] * v131
				v133.CFrame = p129 * (v134 - v134.Position + v134.Position * v131)
			end
			v_u_5.placeAt(v_u_122, p129 * CFrame.new(0, p_u_108 * 0.12 * v131, 0) * CFrame.Angles(0, 0, 1.5707963267948966), p_u_108 * 0.12 * v131, p_u_108 * 0.5 * v131)
		end,
		["gone"] = function() -- name: gone
			-- upvalues: (copy) v_u_126
			for _, v135 in v_u_126 do
				v135:Destroy()
			end
		end
	}
end
return function(p_u_137)
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_96, (copy) v_u_11, (copy) v_u_9, (copy) v_u_13, (copy) v_u_56, (copy) v_u_64, (copy) v_u_4, (copy) v_u_136, (copy) v_u_15, (copy) v_u_49, (copy) v_u_12, (copy) v_u_8, (copy) v_u_1, (copy) v_u_17, (copy) v_u_16, (copy) v_u_14, (copy) v_u_73
	local v159 = {
		["soul_king_a"] = {
			["cast"] = function(p138) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (copy) p_u_137, (ref) v_u_13
				local v139 = p138.size
				local v140 = p138.eye + p138.dir * 1.1
				v_u_6.flash(v140, v_u_10, 2.6 * v139, 0.1)
				p_u_137.glint(v140, v_u_13, 1.8 * v139, 0.1)
			end,
			["shot"] = function(p141, p142) -- name: shardShot
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_96, (ref) v_u_11, (copy) p_u_137, (ref) v_u_9, (ref) v_u_13
				local v143 = p141.size
				local v144 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), p142, v_u_10, {
					["transparency"] = 1
				})
				local v145, v146 = v_u_96(2.2 * v143, 0.85 * v143, 0.85 * v143, 6, 0)
				local v147 = CFrame.Angles(-1.5707963267948966, 0, 0)
				local v148 = {}
				for v149, v150 in v145 do
					local v151 = {
						["p"] = v150,
						["off"] = v147 * v146[v149]
					}
					table.insert(v148, v151)
				end
				local v152 = {
					["p"] = v_u_6.part(Vector3.new(0.18, 0.18, 1.6) * v143, p142, v_u_11, {
						["material"] = Enum.Material.SmoothPlastic
					}),
					["off"] = CFrame.identity
				}
				table.insert(v148, v152)
				p_u_137.streak(v144, v_u_10, v_u_11, 0.8 * v143, 0.14)
				local v153 = {}
				if not p141.lite then
					p_u_137.light(v144, v_u_10, 8 * v143)
					local v154 = Instance.new("Attachment")
					v154.Parent = v144
					local v_u_155 = Instance.new("ParticleEmitter")
					v_u_155.Texture = v_u_9.SoulGem
					v_u_155.Color = ColorSequence.new(v_u_10, v_u_13)
					v_u_155.LightEmission = 0.35
					v_u_155.LightInfluence = 0
					v_u_155.Size = NumberSequence.new(0.35 * v143, 0)
					v_u_155.Lifetime = NumberRange.new(0.3, 0.45)
					v_u_155.Speed = NumberRange.new(1, 3)
					v_u_155.SpreadAngle = Vector2.new(180, 180)
					v_u_155.RotSpeed = NumberRange.new(-200, 200)
					v_u_155.Rate = 30
					v_u_155.Parent = v154
					table.insert(v153, function()
						-- upvalues: (copy) v_u_155
						v_u_155.Enabled = false
					end)
				end
				return p_u_137.assemble(v144, v148, {}, 0, 0, v153, 0.14, 14)
			end,
			["impact"] = function(p156, p157) -- name: shardBreak
				-- upvalues: (ref) v_u_56, (ref) v_u_10, (ref) v_u_6, (ref) v_u_13, (ref) v_u_64
				local v158 = p156.size
				v_u_56(p157, 5 * v158, 0.32, v_u_10)
				v_u_6.flash(p157, v_u_13, 3 * v158, 0.12)
				v_u_64(p157, p156.lite and 3 or 8, 0.45 * v158, 12 * v158, 0.7)
			end,
			["hit"] = p_u_137.simpleHit(v_u_10, 0.55)
		}
	}
	local v_u_160 = {}
	setmetatable(v_u_160, {
		["__mode"] = "k"
	})
	local function v_u_191(p_u_161, p162, p163) -- name: seal
		-- upvalues: (ref) v_u_4, (copy) p_u_137, (ref) v_u_136, (ref) v_u_6, (ref) v_u_10, (ref) v_u_9, (ref) v_u_56, (ref) v_u_13, (ref) v_u_64, (ref) v_u_15
		local v_u_164 = p_u_161.ability.freeze or 3.5
		local v165 = v_u_4:FindFirstChild("MyEnemies")
		local v_u_166
		if v165 then
			v_u_166 = v165:FindFirstChild("Foe" .. p163)
		else
			v_u_166 = nil
		end
		local v_u_167
		if v_u_166 and v_u_166:IsA("Model") then
			local _, v168 = v_u_166:GetBoundingBox()
			local v169 = v168.Y * 1.6
			v_u_167 = math.clamp(v169, 5, 11)
		else
			v_u_167 = 6
		end
		local v_u_170 = p_u_137.ground(p162, 0)
		local v_u_171 = v_u_136(v_u_167, v_u_164 + 1, 0.3)
		local v_u_172 = math.random() * 3.141592653589793
		local v_u_173
		if p_u_161.lite then
			v_u_173 = nil
		else
			local v174 = v_u_6.beam(v_u_170, v_u_170 + Vector3.new(0, 14, 0), v_u_10, v_u_167 * 0.35, v_u_164 + 0.5, v_u_9.Beam)
			v174.LightEmission = 0.55
			v174.Brightness = 1.6
			v_u_173 = v174.Parent
		end
		local v_u_175 = os.clock()
		p_u_137.runNow(function()
			-- upvalues: (copy) v_u_175, (copy) v_u_166, (copy) v_u_164, (copy) v_u_171, (ref) v_u_173, (copy) v_u_170, (ref) v_u_167, (ref) v_u_56, (ref) v_u_10, (ref) v_u_6, (ref) v_u_13, (ref) v_u_64, (copy) p_u_161, (ref) p_u_137, (ref) v_u_15, (copy) v_u_172
			local v176 = os.clock() - v_u_175
			local v177
			if v_u_166 == nil then
				v177 = false
			else
				v177 = v_u_166.Parent == nil
			end
			if v_u_164 <= v176 or v177 then
				v_u_171.gone()
				local v178 = v_u_173
				if v178 then
					v178:Destroy()
				end
				local v179 = v_u_170 + Vector3.new(0, 1, 0) * v_u_167 * 0.5
				v_u_56(v179, v_u_167 * 1.1, 0.4, v_u_10)
				v_u_6.flash(v179, v_u_13, v_u_167 * 0.9, 0.2)
				v_u_64(v179, p_u_161.lite and 5 or 16, 0.7, 16, 1.1)
				p_u_137.glint(v179, v_u_15, 4, 0.2)
				return false
			end
			local v180 = v176 / 0.25
			local v181 = math.clamp(v180, 0, 1) - 1
			local v182 = v181 * 2.7 * v181 * v181 + 1 + v181 * 1.7 * v181
			local v183 = (v176 - 0.25) / 0.6
			local v184 = math.clamp(v183, 0, 1)
			local v185 = v184 * v184 * (3 - v184 * 2) * 0.6
			local v186 = v176 * 2.2
			local v187 = math.sin(v186) * 0.15
			local v188 = v176 - 0.4
			local v189 = math.clamp(v188, 0, 1)
			local v190 = v185 + v187 * (v189 * v189 * (3 - v189 * 2))
			v_u_171.place(CFrame.new(v_u_170 + Vector3.new(0, 1, 0) * (v_u_167 * 0.42 * v182 + v190)) * CFrame.Angles(0, v_u_172 + v176 * 0.6, 0), v182)
			return true
		end)
	end
	v159.soul_king_e = {
		["cast"] = function(p192) -- name: cast
			-- upvalues: (copy) p_u_137, (ref) v_u_10, (ref) v_u_13
			local v193 = p192.size
			p_u_137.skillCast(p192, v_u_10, false, true)
			p_u_137.glint(p192.eye, v_u_13, 4 * v193, 0.2)
		end,
		["windup"] = function(p194, p195, p196) -- name: windup
			-- upvalues: (copy) p_u_137, (ref) v_u_13, (ref) v_u_6, (ref) v_u_10
			local v197 = p194.size
			local v198 = math.max(p196, 0.1)
			p_u_137.inward(p_u_137.ground(p195, 2), v_u_13, p194.lite and 4 or 9, 9 * v197, v198 + 0.05)
			v_u_6.flash(p_u_137.ground(p195, 2), v_u_10, 5 * v197, v198)
		end,
		["land"] = function(p_u_199, p200) -- name: land
			-- upvalues: (copy) p_u_137, (ref) v_u_49, (ref) v_u_9, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10, (ref) v_u_13, (ref) v_u_64, (ref) v_u_8
			local v201 = p_u_199.size
			local v_u_202 = p_u_199.ability.radius * v201
			local v203 = p_u_199.ability.freeze or 3.5
			local v_u_204 = p_u_137.ground(p200, 0.1)
			local v205 = p200 - p_u_199.origin
			local v206 = v205.X
			local v207 = v205.Z
			local v208 = Vector3.new(v206, 0, v207)
			local v209 = v208.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v208.Unit
			local v210 = -v209.X
			local v211 = -v209.Z
			local v212 = math.atan2(v210, v211)
			v_u_49(v_u_204, v_u_202 * 0.6, v_u_202 * 2.3, v_u_9.Glow, v_u_12, 0.4, 0.3, v203 - 0.4, 0.6, 0)
			v_u_49(v_u_204 + Vector3.new(0, 0.06, 0), v_u_202 * 0.5, v_u_202 * 2.1, v_u_9.SoulSeal, v_u_12, 0, 0.3, v203 - 0.4, 0.6, 0.1)
			v_u_6.ring(v_u_204, v_u_10, v_u_202 * 1.1, 0.5, v_u_9.Ring)
			if not p_u_199.lite then
				for v213 = 0, 3 do
					local v214 = v212 + v213 * 3.141592653589793 / 2
					local v215 = math.sin(v214)
					local v216 = math.cos(v214)
					local v217 = v_u_204 + Vector3.new(v215, 0, v216) * v_u_202 * 0.85
					p_u_137.glowBeam(v217, v217 + Vector3.new(0, 30, 0) * v201, v_u_10, 2.6 * v201, v203 * 0.6, v_u_9.Beam)
					p_u_137.glowBeam(v217, v217 + Vector3.new(0, 24, 0) * v201, v_u_13, 1 * v201, v203 * 0.8, v_u_9.Beam)
				end
				v_u_64(v_u_204 + Vector3.new(0, 2, 0), 12, 0.5 * v201, v_u_202 * 0.7, 1.3)
			end
			v_u_8.play("Bind", {
				["at"] = v_u_204,
				["volume"] = p_u_199.mine and 0.8 or 0.45
			})
			if p_u_199.mine then
				v_u_6.shake(0.2, 0.2)
			end
			p_u_137.after(v203, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_204, (ref) v_u_13, (copy) v_u_202, (ref) v_u_9, (ref) v_u_8, (copy) p_u_199
				v_u_6.ring(v_u_204, v_u_13, v_u_202 * 1.3, 0.55, v_u_9.SoulSeal)
				v_u_8.play("Crit", {
					["at"] = v_u_204,
					["volume"] = p_u_199.mine and 0.6 or 0.35
				})
			end)
		end,
		["hit"] = function(p218, p219, p220) -- name: hit
			-- upvalues: (copy) p_u_137, (ref) v_u_10, (copy) v_u_160, (copy) v_u_191
			p_u_137.burst("Impact", p219, v_u_10, 0.6)
			local v221 = (v_u_160[p218] or 0) + 1
			v_u_160[p218] = v221
			if (p218.lite and 3 or 8) >= v221 then
				v_u_191(p218, p219, p220)
			end
		end
	}
	local v_u_222 = {}
	setmetatable(v_u_222, {
		["__mode"] = "k"
	})
	local function v_u_267(p223, p_u_224) -- name: buildPalace
		-- upvalues: (ref) v_u_1, (ref) v_u_6, (ref) v_u_10, (ref) v_u_17, (ref) v_u_11, (ref) v_u_16, (ref) v_u_13, (ref) v_u_14
		local v_u_225 = {}
		local v_u_226 = {}
		local function v240(p227, p228, p229, p230, p231, p232) -- name: disc
			-- upvalues: (ref) v_u_6, (ref) v_u_1, (copy) p_u_224, (copy) v_u_225, (copy) v_u_226
			local v233 = v_u_6.part
			local v234 = p227 * 0.78
			local v235 = p227 * 0.78
			local v236 = v233(Vector3.new(v234, p228, v235), CFrame.identity, p229, {
				["material"] = p230,
				["transparency"] = p231
			})
			local v237 = CFrame.new(0, p232, 0) * CFrame.Angles(0, 0.7853981633974483, 0)
			v236.CFrame = CFrame.new(0, -500, 0)
			v_u_1:AddItem(v236, p_u_224)
			local v238 = v_u_225
			table.insert(v238, v236)
			local v239 = v_u_226
			table.insert(v239, v237)
		end
		local v241 = p223 * 0.5
		v240(v241 * 2.1, 0.5, v_u_10, v_u_17, 0.1, -0.3)
		v240(v241 * 2, 1.6, v_u_11, v_u_16, 0.15, 0.5)
		local v242 = 1.3
		for v243 = 1, 3 do
			local v244 = v241 * (1.25 - v243 * 0.3)
			local v245 = p223 * (0.13 - v243 * 0.015)
			local v246 = {
				["material"] = nil,
				["transparency"] = 0.15,
				["material"] = v_u_16
			}
			local v247 = v_u_6.part(Vector3.new(v244, v245, v244), CFrame.identity, v_u_11, v246)
			local v248 = CFrame.new(0, v242 + v245 / 2, 0)
			v247.CFrame = CFrame.new(0, -500, 0)
			v_u_1:AddItem(v247, p_u_224)
			table.insert(v_u_225, v247)
			table.insert(v_u_226, v248)
			local v249 = v_u_6.part
			local v250 = v244 * 1.04
			local v251 = v245 * 0.12
			local v252 = v244 * 1.04
			local v253 = v249(Vector3.new(v250, v251, v252), CFrame.identity, v_u_10)
			local v254 = CFrame.new(0, v242 + v245 * 0.8, 0)
			v253.CFrame = CFrame.new(0, -500, 0)
			v_u_1:AddItem(v253, p_u_224)
			table.insert(v_u_225, v253)
			table.insert(v_u_226, v254)
			local v255 = v245 * 0.55
			for _, v256 in { 1, -1 } do
				local v257 = Instance.new("WedgePart")
				v257.Anchored = true
				v257.CanCollide = false
				v257.CanQuery = false
				v257.CanTouch = false
				v257.CastShadow = false
				v257.Material = v_u_17
				local v258
				if v243 % 2 == 1 then
					v258 = v_u_10
				else
					v258 = v_u_13
				end
				v257.Color = v258
				local v259 = v244 * 1.25
				local v260 = v244 * 0.62
				v257.Size = Vector3.new(v259, v255, v260)
				v257.Parent = v_u_6.folder()
				local v261 = CFrame.new(0, v242 + v245 + v255 / 2, v256 * v244 * 0.31) * CFrame.Angles(0, v256 > 0 and 3.141592653589793 or 0, 0)
				v257.CFrame = CFrame.new(0, -500, 0)
				v_u_1:AddItem(v257, p_u_224)
				table.insert(v_u_225, v257)
				table.insert(v_u_226, v261)
			end
			v242 = v242 + (v245 + v255 * 0.8)
		end
		local v262 = p223 * 0.25
		local v263 = v_u_6.part(Vector3.new(0.5, v262, 0.5), CFrame.identity, v_u_14, {
			["material"] = Enum.Material.Metal
		})
		local v264 = CFrame.new(0, v242 + v262 / 2, 0)
		v263.CFrame = CFrame.new(0, -500, 0)
		v_u_1:AddItem(v263, p_u_224)
		table.insert(v_u_225, v263)
		table.insert(v_u_226, v264)
		local v265 = v_u_6.part(Vector3.new(1.4, 1.4, 1.4), CFrame.identity, v_u_14, {
			["shape"] = Enum.PartType.Ball
		})
		local v266 = CFrame.new(0, v242 + v262, 0)
		v265.CFrame = CFrame.new(0, -500, 0)
		v_u_1:AddItem(v265, p_u_224)
		table.insert(v_u_225, v265)
		table.insert(v_u_226, v266)
		return v_u_225, v_u_226
	end
	v159.soul_king_r = {
		["cast"] = function(p268) -- name: cast
			-- upvalues: (copy) p_u_137, (ref) v_u_10, (ref) v_u_13, (ref) v_u_6, (ref) v_u_73
			local v269 = p268.size
			p_u_137.skillCast(p268, v_u_10, true, true)
			p_u_137.glint(p268.eye, v_u_13, 5 * v269, 0.25)
			if p268.mine then
				v_u_6.shake(0.12, 0.15)
				v_u_73(Color3.fromRGB(205, 240, 255), 0.03, -0.2, 0.2, 1.3, 0.6)
			end
		end,
		["windup"] = function(p270, p271, p272) -- name: windup
			-- upvalues: (copy) p_u_137, (copy) v_u_267, (ref) v_u_136, (copy) v_u_222, (ref) v_u_10, (ref) v_u_9, (ref) v_u_49, (ref) v_u_12, (ref) v_u_64, (ref) v_u_8
			local v273 = p270.size
			local v_u_274 = p270.ability.radius * v273
			local v275 = math.max(p272, 0.15)
			local v276 = p_u_137.ground(p271, 0)
			local v277 = v275 + 3
			local v_u_278, v_u_279 = v_u_267(v_u_274, v277)
			local v_u_280 = v_u_274 * 0.6
			local v_u_281 = v_u_136(v_u_280, v277, 0)
			local v_u_282 = v276 + Vector3.new(0, 1, 0) * (v_u_274 * 0.55 + v_u_280)
			local v283 = CFrame.Angles
			local v284 = -p270.dir.X
			local v285 = -p270.dir.Z
			local v_u_286 = v283(0, math.atan2(v284, v285), 0)
			v_u_222[p270] = {
				["parts"] = v_u_278,
				["offs"] = v_u_279,
				["crystal"] = v_u_281,
				["at"] = v_u_282,
				["tall"] = v_u_280
			}
			local function v_u_293(p287, p288) -- name: place
				-- upvalues: (copy) v_u_282, (copy) v_u_286, (copy) v_u_278, (copy) v_u_279, (copy) v_u_281, (copy) v_u_280
				local v289 = CFrame.new(v_u_282 + Vector3.new(0, 1, 0) * p287) * v_u_286
				local v290 = v_u_279
				for v291, v292 in v_u_278 do
					v292.CFrame = v289 * v290[v291]
				end
				v_u_281.place(v289 * CFrame.new(0, -v_u_280 * 0.5 - 0.3, 0) * CFrame.Angles(0, p288 * 2, 0), 1)
			end
			p_u_137.animate(v275 + 0.05, 0, function(p294)
				-- upvalues: (copy) v_u_293, (copy) v_u_274
				local v295 = v_u_293
				local v296 = v_u_274 * 1.4
				local v297 = math.clamp(p294, 0, 1) - 1
				v295(v296 * (1 - (v297 * 2.7 * v297 * v297 + 1 + v297 * 1.7 * v297)), p294)
			end)
			p_u_137.glowBeam(v_u_282, v276, v_u_10, v_u_274 * 0.5, v275 + 0.2, v_u_9.Beam)
			v_u_49(v276 + Vector3.new(0, 0.08, 0), v_u_274 * 0.5, v_u_274 * 2, v_u_9.SoulSeal, v_u_12, 0.2, v275 + 0.1, 0.1, 0.3, 0.3)
			if not p270.lite then
				v_u_64(v_u_282, 12, 0.7 * v273, v_u_274 * 0.5, 1)
			end
			v_u_8.play("EyeActivate", {
				["at"] = v276,
				["volume"] = p270.mine and 0.6 or 0.3
			})
		end,
		["land"] = function(p_u_298, p299) -- name: land
			-- upvalues: (copy) p_u_137, (copy) v_u_222, (ref) v_u_56, (ref) v_u_13, (ref) v_u_64, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8, (ref) v_u_49, (ref) v_u_9, (ref) v_u_12, (ref) v_u_6, (ref) v_u_15, (ref) v_u_73
			local v_u_300 = p_u_298.size
			local v_u_301 = p_u_298.lite
			local v_u_302 = p_u_298.ability.radius * v_u_300
			local v_u_303 = p_u_137.ground(p299, 0)
			local v_u_304 = v_u_222[p_u_298]
			v_u_222[p_u_298] = nil
			local v305 = p299 - p_u_298.origin
			local v306 = v305.X
			local v307 = v305.Z
			local v308 = Vector3.new(v306, 0, v307)
			local v309 = v308.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v308.Unit
			local v310 = -v309.X
			local v311 = -v309.Z
			local v_u_312 = math.atan2(v310, v311)
			if v_u_304 then
				local v_u_313 = v_u_304.crystal
				local v_u_314 = v_u_304.at - Vector3.new(0, 1, 0) * (v_u_304.tall * 0.5 + 0.3)
				local v_u_315 = v_u_303 + Vector3.new(0, 1, 0) * v_u_304.tall * 0.38
				p_u_137.animate(0.14, 0, function(p316)
					-- upvalues: (copy) v_u_313, (copy) v_u_314, (copy) v_u_315
					v_u_313.place(CFrame.new(v_u_314:Lerp(v_u_315, p316 * p316)), 1)
				end)
				p_u_137.after(0.6900000000000001, function()
					-- upvalues: (copy) v_u_313, (ref) v_u_56, (copy) v_u_315, (copy) v_u_304, (ref) v_u_13, (ref) v_u_64, (copy) v_u_301, (copy) v_u_300, (copy) v_u_302, (ref) p_u_137, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8, (copy) v_u_303, (copy) p_u_298
					v_u_313.gone()
					v_u_56(v_u_315, v_u_304.tall * 1.4, 0.45, v_u_13)
					v_u_64(v_u_315, v_u_301 and 8 or 28, 1 * v_u_300, v_u_302 * 0.9, 1.4)
					if not v_u_301 then
						local v317 = { v_u_10, v_u_13, v_u_11 }
						p_u_137.chunks(v_u_315, v317, 10, 30 * v_u_300, 1 * v_u_300, 1.2, true, 0.8)
					end
					v_u_8.play("Crit", {
						["at"] = v_u_303,
						["volume"] = p_u_298.mine and 0.7 or 0.35
					})
				end)
				local v_u_318 = v_u_304.parts
				local v_u_319 = v_u_304.offs
				local v_u_320 = v_u_304.at
				local v321 = CFrame.Angles
				local v322 = -p_u_298.dir.X
				local v323 = -p_u_298.dir.Z
				local v_u_324 = v321(0, math.atan2(v322, v323), 0)
				p_u_137.animate(1.6, 0, function(p325)
					-- upvalues: (copy) v_u_318, (copy) v_u_319, (copy) v_u_320, (copy) v_u_302, (copy) v_u_324
					local v326 = (p325 * 1.6 - 0.3) / 1.3
					local v327 = math.clamp(v326, 0, 1)
					local v328 = v327 * v327 * (3 - v327 * 2)
					local v329 = v_u_318
					local v330 = v_u_319
					local v331 = CFrame.new(v_u_320 + Vector3.new(0, 1, 0) * v328 * v_u_302 * 1.6) * v_u_324
					for v332, v333 in v329 do
						v333.CFrame = v331 * v330[v332]
					end
					for _, v334 in v_u_318 do
						local v335 = v334.Transparency
						v334.Transparency = math.max(v335, v328)
					end
					if p325 >= 1 then
						for _, v336 in v_u_318 do
							v336:Destroy()
						end
					end
				end)
			end
			p_u_137.after(0.14, function()
				-- upvalues: (ref) v_u_49, (copy) v_u_303, (copy) v_u_302, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (copy) v_u_312, (ref) p_u_137, (copy) v_u_300, (ref) v_u_11, (copy) v_u_301, (ref) v_u_13, (ref) v_u_6, (ref) v_u_15, (ref) v_u_56, (ref) v_u_8, (copy) p_u_298, (ref) v_u_73
				v_u_49(v_u_303 + Vector3.new(0, 0.12, 0), v_u_302 * 0.5, v_u_302 * 2.7, v_u_9.SoulSeal, v_u_12, 0, 0.15, 0.6, 0.7, 0.4)
				v_u_49(v_u_303 + Vector3.new(0, 0.06, 0), v_u_302, v_u_302 * 2.8, v_u_9.Glow, v_u_10, 0.4, 0.15, 0.3, 0.6, 0)
				for v337 = 0, 3 do
					local v338 = v_u_312 + v337 * 3.141592653589793 / 2
					local v339 = math.sin(v338)
					local v340 = math.cos(v338)
					local v341 = Vector3.new(v339, 0, v340)
					p_u_137.groundLine(v_u_303 + v341 * 2, v_u_303 + v341 * v_u_302 * 1.15, 3 * v_u_300, v_u_11, 1.2, 0.1)
					p_u_137.groundLine(v_u_303 + v341 * 2, v_u_303 + v341 * v_u_302 * 1.15, 1.1 * v_u_300, v_u_10, 1, 0)
					if v_u_301 then
						continue
					end
					p_u_137.spikes(v_u_303 + v341 * v_u_302 * 0.5 + Vector3.new(0, 1, 0), v_u_13, 2, v_u_302 * 0.5, 0.3, v341, 0.1, true)
				end
				p_u_137.dome(v_u_303, v_u_302, v_u_10, 0.55)
				v_u_6.flash(v_u_303 + Vector3.new(0, 3, 0), v_u_15, v_u_302 * 1.1, 0.22)
				v_u_6.ring(v_u_303, v_u_12, v_u_302 * 1.4, 0.55, v_u_9.Shockwave)
				p_u_137.burst("Shockwave", v_u_303 + Vector3.new(0, 0.3, 0), v_u_10, v_u_302 / 14)
				v_u_56(v_u_303 + Vector3.new(0, 1, 0) * v_u_302 * 0.25, v_u_302 * 1.5, 0.5, v_u_10)
				v_u_8.play("Explosion", {
					["at"] = v_u_303,
					["volume"] = p_u_298.mine and 1 or 0.5
				})
				if p_u_298.mine then
					v_u_6.shake(0.55, 0.45)
					v_u_73(Color3.fromRGB(200, 245, 255), 0.2, 0, 0.03, 0.08, 0.45)
				end
			end)
		end,
		["hit"] = function(p342, p343, _) -- name: hit
			-- upvalues: (copy) p_u_137, (ref) v_u_10, (ref) v_u_64
			p_u_137.burst("Impact", p343, v_u_10, 0.8)
			if not p342.lite then
				v_u_64(p343, 3, 0.4, 8, 0.6)
			end
		end
	}
	return v159
end