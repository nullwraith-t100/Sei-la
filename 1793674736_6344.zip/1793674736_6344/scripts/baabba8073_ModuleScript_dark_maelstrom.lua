local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(214, 36, 40)
local v_u_7 = Color3.fromRGB(110, 12, 16)
local v_u_8 = Color3.fromRGB(70, 6, 10)
local v_u_9 = Color3.fromRGB(12, 4, 4)
local v_u_10 = Color3.fromRGB(255, 120, 100)
local v_u_11 = CFrame.Angles(0, 3.141592653589793, 0)
return function(p_u_12)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_1, (copy) v_u_3, (copy) v_u_8
	return {
		["w4_dark_maelstrom"] = function(p_u_13, p14)
			-- upvalues: (ref) v_u_4, (copy) p_u_12, (ref) v_u_6, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_1, (ref) v_u_3, (ref) v_u_8
			local v15 = v_u_4.color(p14.color)
			local v16 = p_u_13.headY / 1.5
			local v_u_17 = math.clamp(v16, 0.7, 3)
			local v_u_18 = v_u_17 * 1.7
			p_u_12.throb(p_u_13, 4.5, 2.2, 2.2, function(p19)
				-- upvalues: (ref) v_u_4, (ref) p_u_12, (copy) p_u_13, (ref) v_u_6, (ref) v_u_5
				v_u_4.ring(p_u_12.feetAt(p_u_13, p19, 0.15), v_u_6, 5 * p_u_13.fx, 0.5, v_u_5.Ring)
			end)
			local v_u_20 = 0
			local v_u_21 = 0.55
			local v_u_22 = 0
			local v23 = p_u_13.ticks
			local function v32(_, p24, p25)
				-- upvalues: (ref) v_u_21, (ref) v_u_22, (ref) v_u_20
				local v26 = p24 * 1.3
				local v27 = math.sin(v26) * 0.08 + 0.55
				local v28 = p24 < 2.2 and 99 or (p24 - 2.2) % 4.5
				if v28 < 0.1 then
					v27 = v27 + (1.02 - v27) * (v28 / 0.1) ^ 2
				elseif v28 < 0.4 then
					v27 = 1.02
				elseif v28 < 0.52 then
					v27 = 1.02 - (v28 - 0.4) / 0.12 * 1
				elseif v28 < 1.5 then
					local v29 = (v28 - 0.52) / 0.98
					v27 = (v27 - 0.02) * (v29 * v29 * (3 - v29 * 2)) + 0.02
				end
				v_u_21 = v27
				local v30
				if v28 >= 0.4 and v28 < 1.2 then
					local v31 = v28 - 0.52
					v30 = 1 - math.abs(v31) / 0.7
				else
					v30 = 0
				end
				v_u_22 = v30
				v_u_20 = v_u_20 + p25 * ((v28 < 0.52 and 3 or 0) + 0.5)
			end
			table.insert(v23, v32)
			local v_u_43 = p_u_12.group(p_u_13, function(p33, p34)
				-- upvalues: (copy) v_u_17, (ref) p_u_12
				local v35 = (p33 * CFrame.new(0, v_u_17 * 1, v_u_17 * 1.6)).Position
				local v36 = p34 * 1.4
				local v37 = math.sin(v36) * 0.1 * v_u_17
				local v38 = v35 + Vector3.new(0, v37, 0)
				local v39 = p_u_12.camPos() - v38
				local v40
				if v39.Magnitude > 0.01 then
					v40 = v39.Unit
				else
					v40 = p33.LookVector * -1
				end
				local v41 = v40.Y
				local v42 = math.abs(v41) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v38, v38 + v40, v42) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v44 = p_u_12.disc
			local v45 = v_u_18 * 2.18
			local v46 = v_u_18 * 2.18
			local v47 = v44(Vector3.new(0.05, v45, v46), v_u_9, 0, Enum.Material.SmoothPlastic)
			p_u_12.pin(p_u_13, v_u_43, v47, CFrame.new(0, -0.12, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
			local v48 = p_u_12.disc
			local v49 = v_u_18 * 1.98
			local v50 = v_u_18 * 1.98
			local v_u_51 = v48(Vector3.new(0.05, v49, v50), v_u_7, 0.05)
			p_u_12.pin(p_u_13, v_u_43, v_u_51, CFrame.new(0, -0.06, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
			local v_u_52 = -1
			local v53 = p_u_13.ticks
			local function v54()
				-- upvalues: (ref) v_u_22, (ref) v_u_52, (copy) v_u_51, (ref) v_u_7, (ref) v_u_10
				if v_u_22 ~= v_u_52 then
					v_u_52 = v_u_22
					v_u_51.Color = v_u_7:Lerp(v_u_10, v_u_22 * 0.7)
				end
			end
			table.insert(v53, v54)
			local v_u_55 = v_u_18 * 1.35
			local v_u_56 = table.create(8, CFrame.identity)
			local v57 = p_u_13.ticks
			local function v62()
				-- upvalues: (copy) v_u_43, (ref) v_u_20, (ref) v_u_21, (copy) v_u_56, (copy) v_u_18, (copy) v_u_55, (ref) v_u_11
				local v58 = v_u_43.cf
				for v59 = 1, 8 do
					local v60 = v_u_20 + (v59 - 1) / 8 * 3.141592653589793 * 2
					local v61 = v60 + 1.5707963267948966 + 1.9477874452256718 * v_u_21
					v_u_56[v59] = v58 * CFrame.new(math.cos(v60) * v_u_18 * 0.95, v59 * 0.012, math.sin(v60) * v_u_18 * 0.95) * CFrame.Angles(0, -v61, 0) * CFrame.new(Vector3.new(0.42, -0, -0.06) * v_u_55) * v_u_11
				end
			end
			table.insert(v57, v62)
			local v_u_63 = {}
			for v_u_64 = 1, 8 do
				local v65 = v_u_4.part(Vector3.new(v_u_55, 0.05, v_u_55), CFrame.identity, v_u_6, {
					["transparency"] = 1
				})
				local v66 = Instance.new("Decal")
				v66.Face = Enum.NormalId.Top
				v66.Texture = v_u_5.MaelstromBlade
				v66.Color3 = v_u_6
				v66.Parent = v65
				table.insert(v_u_63, v66)
				p_u_12.add(p_u_13, v65, function()
					-- upvalues: (copy) v_u_56, (copy) v_u_64
					return v_u_56[v_u_64]
				end)
			end
			local v67, v68 = p_u_12.picture(v_u_18 * 2.3, v_u_5.Ring, v_u_6, 0.1)
			p_u_12.add(p_u_13, v67, function(_, p69)
				-- upvalues: (copy) v_u_43
				return v_u_43.cf * CFrame.new(0, 0.14, 0) * CFrame.Angles(0, -p69 * 0.6, 0)
			end)
			for _, v70 in v68 do
				table.insert(v_u_63, v70)
			end
			local v71 = p_u_12.dark(p_u_12.ball(v_u_17 * 0.62, v_u_9, 0, Enum.Material.SmoothPlastic))
			p_u_12.pin(p_u_13, v_u_43, v71, CFrame.new(0, 0.1, 0))
			if p_u_13.character == v_u_1.LocalPlayer.Character then
				local v_u_72 = { v47, v_u_51, v71 }
				local v_u_73 = -1
				local v74 = p_u_13.ticks
				local function v83(p75)
					-- upvalues: (ref) v_u_3, (ref) v_u_73, (copy) v_u_72, (copy) v_u_63
					local v76 = v_u_3.CurrentCamera
					if v76 then
						local v77 = (v76.CFrame.LookVector:Dot(p75.LookVector) + 0.1) * 1.6
						local v78 = math.clamp(v77, 0, 1) * 20 + 0.5
						local v79 = math.floor(v78) / 20
						if v79 ~= v_u_73 then
							v_u_73 = v79
							local v80 = v79 * 0.55
							for _, v81 in v_u_72 do
								v81.LocalTransparencyModifier = v80
							end
							for _, v82 in v_u_63 do
								v82.LocalTransparencyModifier = v80
							end
						end
					else
						return
					end
				end
				table.insert(v74, v83)
			end
			for v_u_84 = 1, 2 do
				local v85 = (v_u_84 == 1 and 5.4 or 3.2) * v_u_17
				local v86 = p_u_12.picture
				local v87 = v85
				local v88 = v_u_5.MaelstromVortex
				local v89
				if v_u_84 == 1 then
					v89 = v15
				else
					v89 = v_u_6
				end
				local v90 = v86(v87, v88, v89, 0.1)
				p_u_12.add(p_u_13, v90, function(p91, p92)
					-- upvalues: (ref) p_u_12, (copy) p_u_13, (copy) v_u_84
					return CFrame.new(p_u_12.feetAt(p_u_13, p91, v_u_84 * 0.03 + 0.08)) * CFrame.Angles(0, -p92 * (v_u_84 == 1 and 1.2 or 2.6), 0)
				end)
			end
			for v_u_93 = 1, 4 do
				local v94 = p_u_12.ball(v_u_17 * 0.32, v_u_6, 0)
				local v_u_95 = p_u_12.tail(v94, v_u_6, v_u_8, v_u_17 * 0.24, 0.35)
				local v_u_96 = 0
				p_u_12.add(p_u_13, v94, function(p97, p98)
					-- upvalues: (copy) v_u_93, (ref) v_u_96, (copy) v_u_95, (copy) v_u_17, (copy) p_u_13
					local v99 = (p98 * 0.32 + v_u_93 / 4) % 1
					if v99 < v_u_96 then
						v_u_95:Clear()
					end
					v_u_96 = v99
					local v100 = v_u_93 * 3.141592653589793 / 2 + v99 * 3.141592653589793 * 5
					local v101 = v_u_17 * 2.6 * (1 - v99 * 0.85)
					local v102 = v_u_17 * 1.6 + (p_u_13.feet + 0.3 - v_u_17 * 1.6) * v99
					local v103 = CFrame.new
					local v104 = p97.Position
					local v105 = math.cos(v100) * v101
					local v106 = math.sin(v100) * v101
					return v103(v104 + Vector3.new(v105, v102, v106))
				end)
			end
			p_u_12.particles(p_u_13, "AuraMode", v_u_6, {
				["rate"] = 0.4,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "FlameBack", "Sparks" }
			})
		end
	}
end