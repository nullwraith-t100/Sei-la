local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.Fx.Kit)
require(script.Parent.KuramaRig)
local v_u_8 = require(script.Parent.Perf)
local v_u_9 = require(script.Parent.Fx.Preload)
local v_u_10 = require(script.Parent.Sfx)
local v_u_11 = require(v4.Shared.Logic.Boss)
local v_u_12 = require(v4.Shared.Config.Textures)
local v_u_13 = {}
local v_u_14 = Color3.fromRGB
v_u_13.FIRE = v_u_14(255, 128, 28)
v_u_13.RED = v_u_14(230, 30, 30)
v_u_13.GOLD = v_u_14(255, 205, 60)
v_u_13.DARK = v_u_14(70, 8, 8)
local v_u_15 = v_u_14(150, 14, 14)
local v_u_16 = v_u_14(255, 104, 26)
local v_u_17 = Color3.new(1, 1, 1)
local v_u_18 = v_u_14(24, 6, 34)
local v_u_19 = v_u_14(150, 40, 255)
local v_u_20 = v_u_14(214, 150, 255)
local v_u_21 = v_u_14(236, 214, 186)
local v_u_22 = v_u_14(255, 72, 20)
local v_u_23 = v_u_11.CENTRE.Y
local v_u_24 = v_u_11.CENTRE
local v_u_25 = v_u_23 + 0.22
local v_u_26 = {}
local v_u_27 = nil
local v_u_28 = 0
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = false
function v_u_13.shake(p32, p33) -- name: shake
	-- upvalues: (ref) v_u_28, (ref) v_u_30, (ref) v_u_29, (ref) v_u_31, (copy) v_u_5, (copy) v_u_6
	local v34 = os.clock()
	local v35
	if v34 < v_u_28 then
		local v36 = v_u_30 * (v_u_28 - v34)
		local v37 = v_u_28 - v_u_29
		v35 = v36 / math.max(v37, 0.001)
	else
		v35 = 0
	end
	if p32 < v35 then
		return
	else
		local v38 = v34 + p33
		v_u_30 = p32
		v_u_29 = v34
		v_u_28 = v38
		if not v_u_31 then
			v_u_31 = true
			v_u_5:BindToRenderStep("BossShake", Enum.RenderPriority.Camera.Value + 2, function()
				-- upvalues: (ref) v_u_6, (ref) v_u_28, (ref) v_u_5, (ref) v_u_31, (ref) v_u_29, (ref) v_u_30
				local v39 = os.clock()
				local v40 = v_u_6.CurrentCamera
				if v_u_28 <= v39 then
					v_u_5:UnbindFromRenderStep("BossShake")
					v_u_31 = false
				elseif v40 then
					local v41 = v_u_28 - v39
					local v42 = v_u_28 - v_u_29
					local v43 = v41 / math.max(v42, 0.001)
					local v44 = v_u_30 * v43 * v43
					v40.CFrame = v40.CFrame * (CFrame.new((math.random() - 0.5) * v44, (math.random() - 0.5) * v44, 0) * CFrame.Angles(0, 0, (math.random() - 0.5) * v44 * 0.02))
				end
			end)
		end
	end
end
local v_u_45 = { 0, 0, 1 }
local v_u_46 = {
	["ring"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.5,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.4,
		["bright"] = 1.3,
		["facing"] = "flat",
		["texture"] = v_u_12.KyubiRing,
		["size"] = {
			3,
			9.5,
			11.2,
			11.6
		},
		["fade"] = {
			0,
			0,
			0.15,
			1
		}
	},
	["dust"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.95,
		["size"] = nil,
		["fade"] = nil,
		["color"] = nil,
		["facing"] = "flat",
		["texture"] = v_u_12.KyubiDustRing,
		["size"] = {
			4,
			10,
			12.4,
			13
		},
		["fade"] = {
			0.05,
			0.1,
			0.35,
			1
		},
		["color"] = v_u_21
	},
	["star"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.38,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.75,
		["bright"] = 2,
		["texture"] = v_u_12.KyubiSpikeRing,
		["size"] = { 3, 6.6, 7.4 },
		["fade"] = { 0, 0, 0.25 }
	},
	["burst"] = {
		["texture"] = nil,
		["grid"] = 2,
		["frames"] = "pick",
		["life"] = 0.22,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.7,
		["bright"] = 1.8,
		["texture"] = v_u_12.KyubiBurst,
		["size"] = { 1.4, 4.4, 5 },
		["fade"] = { 0, 0.1, 1 }
	},
	["toonStar"] = {
		["texture"] = nil,
		["life"] = 0.2,
		["size"] = nil,
		["fade"] = nil,
		["bright"] = 1.4,
		["texture"] = v_u_12.KyubiToonStar,
		["size"] = { 1, 3.4, 3.8 },
		["fade"] = { 0, 0, 1 }
	},
	["erupt"] = {
		["texture"] = nil,
		["grid"] = 2,
		["life"] = 0.6,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.5,
		["bright"] = 1.6,
		["facing"] = "upright",
		["rotationSpread"] = 0,
		["texture"] = v_u_12.KyubiErupt,
		["size"] = { 6, 8, 8.5 },
		["fade"] = {
			0,
			0,
			0.1,
			1
		}
	},
	["spikes"] = {
		["texture"] = nil,
		["grid"] = 2,
		["life"] = 0.5,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.15,
		["bright"] = 1.2,
		["facing"] = "upright",
		["rotationSpread"] = 0,
		["texture"] = v_u_12.KyubiSpikes,
		["size"] = { 4.4, 5.4, 5.6 },
		["fade"] = { 0, 0, 0.25 }
	},
	["boom"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.7,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.15,
		["bright"] = 1.3,
		["texture"] = v_u_12.KyubiFireBoom,
		["size"] = { 4, 6, 6.4 },
		["fade"] = {
			0,
			0,
			0,
			0.4
		}
	},
	["blast"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.95,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.35,
		["bright"] = 1.5,
		["texture"] = v_u_12.KyubiFireBlast,
		["size"] = { 6, 9, 10 },
		["fade"] = {
			0,
			0,
			0,
			0.3
		}
	},
	["flame"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.6,
		["lifeSpread"] = 0.15,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.1,
		["bright"] = 1.2,
		["rotationSpread"] = 12,
		["speed"] = 3,
		["speedSpread"] = 0.5,
		["cone"] = 20,
		["gravity"] = -6,
		["texture"] = v_u_12.KyubiToonFlame,
		["size"] = { 2, 2.8, 3 },
		["fade"] = { 0, 0, 0.2 }
	},
	["foxFire"] = {
		["texture"] = nil,
		["grid"] = 4,
		["frames"] = "loop",
		["fps"] = 20,
		["life"] = 0.7,
		["lifeSpread"] = 0.2,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.25,
		["bright"] = 1.3,
		["rotationSpread"] = 10,
		["speed"] = 5,
		["speedSpread"] = 0.4,
		["cone"] = 18,
		["gravity"] = -8,
		["texture"] = v_u_12.KyubiFoxFlame,
		["size"] = { 2, 2.6, 0.6 },
		["fade"] = { 0, 0, 0.6 }
	},
	["column"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.75,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.5,
		["bright"] = 1.7,
		["facing"] = "upright",
		["rotationSpread"] = 0,
		["texture"] = v_u_12.KyubiFlameColumn,
		["size"] = { 7, 9, 9 },
		["fade"] = { 0, 0, 0.2 }
	},
	["crescent"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.42,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.2,
		["bright"] = 1.5,
		["rotationSpread"] = 15,
		["texture"] = v_u_12.KyubiFireCrescent,
		["size"] = { 7, 9.5 },
		["fade"] = { 0, 0, 0.1 }
	},
	["bolts"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.35,
		["lifeSpread"] = 0.2,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 1,
		["bright"] = 2.5,
		["texture"] = v_u_12.KyubiBolts,
		["size"] = { 3, 3.6 },
		["fade"] = { 0, 0, 0.3 }
	},
	["wave"] = {
		["texture"] = nil,
		["grid"] = 4,
		["life"] = 0.6,
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.7,
		["bright"] = 2,
		["facing"] = "aim",
		["speed"] = 75,
		["drag"] = 1.5,
		["texture"] = v_u_12.KyubiRing,
		["size"] = { 3, 13, 19 },
		["fade"] = {
			0.15,
			0.3,
			0.55,
			1
		}
	},
	["gather"] = {
		["texture"] = nil,
		["life"] = 0.45,
		["grid"] = 4,
		["frames"] = "pick",
		["size"] = nil,
		["fade"] = nil,
		["glow"] = 0.8,
		["bright"] = 2,
		["texture"] = v_u_12.KyubiDustRing,
		["size"] = { 9, 4, 0.5 },
		["fade"] = { 1, 0.2, 0 }
	}
}
local v_u_47 = {
	[2] = Enum.ParticleFlipbookLayout.Grid2x2,
	[4] = Enum.ParticleFlipbookLayout.Grid4x4
}
local function v_u_57(p48, p49) -- name: curveOf
	local v50 = #p48
	if v50 == 1 then
		return NumberSequence.new(p48[1] * p49)
	end
	local v51 = {}
	for v52, v53 in p48 do
		local v54 = NumberSequenceKeypoint.new
		local v55 = (v52 - 1) / (v50 - 1)
		local v56 = v53 * p49
		table.insert(v51, v54(v55, v56))
	end
	return NumberSequence.new(v51)
end
local function v_u_74(p58, p59, p60) -- name: emitterOf
	-- upvalues: (copy) v_u_47, (copy) v_u_57, (copy) v_u_45, (copy) v_u_17
	local v61 = Instance.new("ParticleEmitter")
	v61.Enabled = false
	v61.Rate = 0
	v61.Texture = p58.texture
	local v62 = p58.grid
	if v62 then
		v61.FlipbookLayout = v_u_47[v62] or Enum.ParticleFlipbookLayout.None
		local v63 = p58.frames or "once"
		if v63 == "loop" then
			v61.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v61.FlipbookFramerate = NumberRange.new(p58.fps or 20)
			v61.FlipbookStartRandom = true
		elseif v63 == "pick" then
			v61.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v61.FlipbookFramerate = NumberRange.new(0)
			v61.FlipbookStartRandom = true
		else
			v61.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
	end
	local v64 = p58.lifeSpread or 0
	v61.Lifetime = NumberRange.new(p58.life * (1 - v64), p58.life * (1 + v64))
	v61.Size = v_u_57(p58.size, p59)
	v61.Transparency = v_u_57(p58.fade or v_u_45, 1)
	v61.Color = ColorSequence.new(p60 or (p58.color or v_u_17))
	v61.LightEmission = p58.glow or 0
	v61.LightInfluence = 0
	v61.Brightness = p58.bright or 1
	v61.ZOffset = p58.z or 0
	v61.LockedToPart = p58.locked == true
	local v65 = p58.facing or "camera"
	local v66 = p58.rotation or 0
	local v67 = p58.rotationSpread or 180
	v61.Rotation = NumberRange.new(v66 - v67, v66 + v67)
	local v68 = p58.spin or 0
	v61.RotSpeed = NumberRange.new(-v68, v68)
	v61.Drag = p58.drag or 0
	local v69 = -(p58.gravity or 0) * p59
	v61.Acceleration = Vector3.new(0, v69, 0)
	if v65 == "flat" then
		v61.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v61.EmissionDirection = Enum.NormalId.Top
		v61.Speed = NumberRange.new(0.02)
		v61.SpreadAngle = Vector2.zero
		v61.Acceleration = Vector3.new(0, 0, 0)
	elseif v65 == "aim" then
		v61.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v61.EmissionDirection = Enum.NormalId.Front
		local v70 = (p58.speed or 1) * p59
		v61.Speed = NumberRange.new(v70)
		v61.SpreadAngle = Vector2.zero
	else
		if v65 == "upright" then
			v61.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
		end
		v61.EmissionDirection = Enum.NormalId.Top
		local v71 = (p58.speed or 0) * p59
		local v72 = p58.speedSpread or 0
		v61.Speed = NumberRange.new(v71 * (1 - v72), v71 * (1 + v72))
		local v73 = p58.cone or 0
		v61.SpreadAngle = Vector2.new(v73, v73)
	end
	if p58.box then
		v61.Shape = Enum.ParticleEmitterShape.Box
		v61.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	end
	return v61
end
local function v_u_85(p75, p76, p77, p78, p79) -- name: sprite
	-- upvalues: (copy) v_u_46, (copy) v_u_74, (copy) v_u_7, (copy) v_u_17, (copy) v_u_6, (copy) v_u_1
	local v80 = v_u_46[p75]
	if v80 and p77 > 0 then
		local v81 = p78 or 1
		local v82 = v_u_74(v80, v81, p79)
		local v83 = v80.box
		local v84
		if v83 then
			if typeof(p76) ~= "CFrame" then
				p76 = CFrame.new(p76)
			end
			v84 = v_u_7.part(v83 * v81, p76, v_u_17, {
				["transparency"] = 1
			})
		else
			v84 = Instance.new("Attachment")
			if typeof(p76) ~= "CFrame" then
				p76 = CFrame.new(p76)
			end
			v84.CFrame = p76
			v84.Parent = v_u_6.Terrain
		end
		v82.Parent = v84
		v82:Emit(p77)
		v_u_1:AddItem(v84, v80.life * (1 + (v80.lifeSpread or 0)) + 0.3)
	end
end
local v_u_86 = {
	["erupt"] = 4.8,
	["spikes"] = 3.78,
	["column"] = 7.6499999999999995
}
local v_u_87 = {
	["crescent"] = {
		["texture"] = nil,
		["grid"] = 4,
		["cell"] = 256,
		["texture"] = v_u_12.KyubiFireCrescent
	},
	["claw"] = {
		["texture"] = nil,
		["grid"] = 2,
		["cell"] = 256,
		["texture"] = v_u_12.KyubiClawMark
	}
}
local function v_u_127(p88, p89, p90, p_u_91, p_u_92, p_u_93) -- name: sheet
	-- upvalues: (copy) v_u_87, (copy) v_u_7, (copy) v_u_23, (copy) v_u_17, (copy) v_u_26, (ref) v_u_27, (copy) v_u_5, (copy) v_u_1
	local v_u_94 = v_u_87[p88]
	if v_u_94 then
		local v95 = v_u_7.part
		local v96 = Vector3.new(p_u_91, 0.1, p_u_92)
		local v97 = CFrame.new(p89.X, v_u_23 + (p_u_93.lift or 0.35), p89.Z) * CFrame.Angles(0, p90 + 0, 0)
		local v98
		if p_u_93.mirror then
			v98 = CFrame.Angles(0, 0, 3.141592653589793)
		else
			v98 = CFrame.identity
		end
		local v_u_99 = v95(v96, v97 * v98, v_u_17, {
			["transparency"] = 1
		})
		local v100 = Instance.new("SurfaceGui")
		local v101
		if p_u_93.mirror then
			v101 = Enum.NormalId.Bottom
		else
			v101 = Enum.NormalId.Top
		end
		v100.Face = v101
		v100.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
		v100.CanvasSize = Vector2.new(256, 256)
		v100.LightInfluence = 0
		v100.Brightness = p_u_93.bright or 1
		v100.Parent = v_u_99
		local v_u_102 = Instance.new("ImageLabel")
		v_u_102.BackgroundTransparency = 1
		v_u_102.Size = UDim2.fromScale(1, 1)
		v_u_102.Image = v_u_94.texture
		v_u_102.ImageColor3 = p_u_93.color or v_u_17
		local v_u_103 = p_u_93.alpha or 0
		v_u_102.ImageTransparency = v_u_103
		v_u_102.ImageRectSize = Vector2.new(v_u_94.cell, v_u_94.cell)
		v_u_102.Parent = v100
		local v_u_104 = v_u_94.grid * v_u_94.grid
		local v105 = p_u_93.frame or 0
		v_u_102.ImageRectOffset = Vector2.new(v105 % v_u_94.grid * v_u_94.cell, v105 // v_u_94.grid * v_u_94.cell)
		local v_u_106 = os.clock()
		local v_u_107 = p_u_93.fadeFrom or 0.6
		local v_u_108 = p_u_93.from or 1
		local v109 = v_u_26
		table.insert(v109, function(p110)
			-- upvalues: (copy) v_u_99, (copy) v_u_106, (copy) p_u_93, (copy) v_u_104, (copy) v_u_102, (copy) v_u_94, (copy) v_u_108, (copy) p_u_91, (copy) p_u_92, (copy) v_u_107, (copy) v_u_103
			if not v_u_99.Parent then
				return true
			end
			local v111 = (p110 - v_u_106) / p_u_93.time
			local v112 = math.clamp(v111, 0, 1)
			if not p_u_93.frame then
				local v113 = v112 * v_u_104
				local v114 = math.floor(v113)
				local v115 = v_u_104 - 1
				local v116 = math.min(v114, v115)
				v_u_102.ImageRectOffset = Vector2.new(v116 % v_u_94.grid * v_u_94.cell, v116 // v_u_94.grid * v_u_94.cell)
			end
			if v_u_108 ~= 1 then
				local v117 = v_u_108
				local v118 = 1 - v_u_108
				local v119 = v112 * 2
				local v120 = v117 + v118 * (1 - (1 - math.min(v119, 1)) ^ 3)
				local v121 = v_u_99
				local v122 = p_u_91 * v120
				local v123 = p_u_92 * v120
				v121.Size = Vector3.new(v122, 0.1, v123)
			end
			if v_u_107 < v112 then
				v_u_102.ImageTransparency = v_u_103 + (1 - v_u_103) * (v112 - v_u_107) / (1 - v_u_107)
			end
			if v112 < 1 then
				return false
			end
			v_u_99:Destroy()
			return true
		end)
		if not v_u_27 then
			v_u_27 = v_u_5.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_26, (ref) v_u_27
				local v124 = os.clock()
				for v125 = #v_u_26, 1, -1 do
					if not v_u_26[v125](v124) then
						continue
					end
					table.remove(v_u_26, v125)
				end
				local v126 = v_u_27
				if #v_u_26 == 0 and v126 then
					v126:Disconnect()
					v_u_27 = nil
				end
			end)
		end
		v_u_1:AddItem(v_u_99, p_u_93.time + 1)
	end
end
local function v_u_136(p128, p129, p130, p131, p_u_132, p133) -- name: decalPart
	-- upvalues: (copy) v_u_7, (copy) v_u_1
	local v134 = v_u_7.part(Vector3.new(p129, 0.1, p129), CFrame.new(p128) * CFrame.Angles(0, p133 or math.random() * 3.141592653589793 * 2, 0), p131, {
		["transparency"] = 1
	})
	local v_u_135 = Instance.new("Decal")
	v_u_135.Face = Enum.NormalId.Top
	v_u_135.Texture = p130
	v_u_135.Color3 = p131
	v_u_135.Parent = v134
	task.delay(p_u_132 * 0.4, function()
		-- upvalues: (ref) v_u_7, (copy) v_u_135, (copy) p_u_132
		v_u_7.tween(v_u_135, p_u_132 * 0.6, {
			["Transparency"] = 1
		})
	end)
	v_u_1:AddItem(v134, p_u_132 + 0.1)
	return v134
end
local function v_u_163(p137, p138, p139, p140) -- name: rocks
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_14, (copy) v_u_23, (copy) v_u_1
	local v141 = v_u_8.level()
	local v142 = p138 * (v141 >= 3 and 1 or (v141 == 2 and 0.6 or 0.35))
	local v143 = math.round(v142)
	for _ = 1, math.max(1, v143) do
		local v144 = math.random() * 3.141592653589793 * 2
		local v145 = math.random() * p139
		local v146 = v_u_7.part
		local v147 = Vector3.new(1, 1, 1) * p140 * (0.6 + math.random() * 0.8)
		local v148 = CFrame.new
		local v149 = math.cos(v144) * v145
		local v150 = math.sin(v144) * v145
		local v_u_151 = v146(v147, v148(p137 + Vector3.new(v149, 0.5, v150)) * CFrame.Angles(math.random() * 3, math.random() * 3, math.random() * 3), v_u_14(70, 52, 48), {
			["material"] = Enum.Material.Slate
		})
		local v152 = v_u_151.Position
		local v153 = math.cos(v144) * p139 * 0.6
		local v154 = 5 + math.random() * 7
		local v155 = math.sin(v144) * p139 * 0.6
		local v_u_156 = v152 + Vector3.new(v153, v154, v155)
		v_u_7.tween(v_u_151, 0.35, {
			["Position"] = v_u_156
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		task.delay(0.35, function()
			-- upvalues: (copy) v_u_151, (ref) v_u_7, (copy) v_u_156, (ref) v_u_23
			if v_u_151.Parent then
				local v157 = v_u_7.tween
				local v158 = v_u_151
				local v159 = {
					["Position"] = nil,
					["Transparency"] = 1
				}
				local v160 = v_u_156.X
				local v161 = v_u_23 - 1
				local v162 = v_u_156.Z
				v159.Position = Vector3.new(v160, v161, v162)
				v157(v158, 0.45, v159, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			end
		end)
		v_u_1:AddItem(v_u_151, 0.9)
	end
end
local function v_u_194(p164, p_u_165, p_u_166, p_u_167, p168) -- name: firePillar
	-- upvalues: (copy) v_u_23, (copy) v_u_7, (copy) v_u_17, (copy) v_u_12, (copy) v_u_26, (ref) v_u_27, (copy) v_u_5, (copy) v_u_1
	local v169 = p164.X
	local v170 = p164.Z
	local v171 = v_u_23 + 0
	local v172 = Vector3.new(v169, v171, v170)
	local v_u_173 = v_u_7.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v172), v_u_17, {
		["transparency"] = 1
	})
	local v174 = Instance.new("Attachment")
	v174.Parent = v_u_173
	local v_u_175 = Instance.new("Attachment")
	local v176 = p_u_166 * 0.5
	v_u_175.Position = Vector3.new(0, v176, 0)
	v_u_175.Parent = v_u_173
	local v_u_177 = Instance.new("Beam")
	v_u_177.Attachment0 = v174
	v_u_177.Attachment1 = v_u_175
	v_u_177.Texture = v_u_12.CometFlame
	v_u_177.TextureMode = Enum.TextureMode.Wrap
	v_u_177.TextureLength = p_u_165 * 1.4
	v_u_177.TextureSpeed = -1.6
	v_u_177.FaceCamera = true
	v_u_177.LightEmission = 0.2
	v_u_177.LightInfluence = 0
	v_u_177.Brightness = 1.6
	v_u_177.Color = ColorSequence.new(p168 or v_u_17)
	v_u_177.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.05), NumberSequenceKeypoint.new(1, 1) })
	v_u_177.Width0 = p_u_165
	v_u_177.Width1 = p_u_165 * 0.5
	v_u_177.Segments = 1
	v_u_177.Parent = v_u_173
	local v_u_178 = os.clock()
	local v179 = v_u_26
	table.insert(v179, function(p180)
		-- upvalues: (copy) v_u_173, (copy) v_u_178, (copy) p_u_167, (copy) p_u_165, (copy) v_u_177, (copy) v_u_175, (copy) p_u_166
		if not v_u_173.Parent then
			return true
		end
		local v181 = (p180 - v_u_178) / p_u_167
		local v182 = math.clamp(v181, 0, 1)
		local v183 = p_u_165 * (1 - v182 * v182)
		local v184 = v_u_177
		local v185 = v_u_177
		local v186 = v183 * 0.5
		v184.Width0 = v183
		v185.Width1 = v186
		local v187 = v_u_175
		local v188 = p_u_166
		local v189 = v182 * 5
		local v190 = v188 * (math.min(v189, 1) * 0.5 + 0.5)
		v187.Position = Vector3.new(0, v190, 0)
		if v182 < 1 then
			return false
		end
		v_u_173:Destroy()
		return true
	end)
	if not v_u_27 then
		v_u_27 = v_u_5.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_26, (ref) v_u_27
			local v191 = os.clock()
			for v192 = #v_u_26, 1, -1 do
				if not v_u_26[v192](v191) then
					continue
				end
				table.remove(v_u_26, v192)
			end
			local v193 = v_u_27
			if #v_u_26 == 0 and v193 then
				v193:Disconnect()
				v_u_27 = nil
			end
		end)
	end
	v_u_1:AddItem(v_u_173, p_u_167 + 0.5)
end
local v_u_195 = nil
local function v_u_205(p196, p197, p198, p199) -- name: impactFrame
	-- upvalues: (copy) v_u_6, (ref) v_u_195, (copy) v_u_17, (copy) v_u_2, (copy) v_u_7, (copy) v_u_1
	local v200 = v_u_6.CurrentCamera
	local v201
	if v200 == nil then
		v201 = false
	else
		v201 = (v200.CFrame.Position - p196).Magnitude < 260
	end
	if v201 then
		local v202 = v_u_195
		if v202 then
			v202:Destroy()
		end
		local v203 = Instance.new("ColorCorrectionEffect")
		v203.Name = "BossImpact"
		v203.TintColor = v_u_17:Lerp(p197, p198 * 0.35)
		v203.Brightness = p198 * 0.1
		v203.Contrast = p198 * 0.45
		v203.Saturation = p198 * 0.3
		v203.Parent = v_u_2
		v_u_195 = v203
		local v204 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_17
		}
		v_u_7.tween(v203, p199, v204)
		v_u_1:AddItem(v203, p199 + 0.05)
	end
end
local function v_u_222(p206, p207, p_u_208) -- name: focusLines
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_3, (copy) v_u_12, (copy) v_u_26, (ref) v_u_27, (copy) v_u_5, (copy) v_u_1
	if v_u_8.level() >= 2 then
		local v209 = v_u_6.CurrentCamera
		local v210
		if v209 == nil then
			v210 = false
		else
			v210 = (v209.CFrame.Position - p206).Magnitude < 220
		end
		if v210 then
			local v211 = v_u_3.LocalPlayer
			if v211 then
				v211 = v211:FindFirstChildOfClass("PlayerGui")
			end
			if v211 then
				local v212 = v211:FindFirstChild("BossFocus")
				if not (v212 and v212:IsA("ScreenGui")) then
					v212 = Instance.new("ScreenGui")
					v212.Name = "BossFocus"
					v212.IgnoreGuiInset = true
					v212.ResetOnSpawn = false
					v212.DisplayOrder = -10
					v212.Parent = v211
				end
				local v_u_213 = Instance.new("ImageLabel")
				v_u_213.AnchorPoint = Vector2.new(0.5, 0.5)
				v_u_213.Position = UDim2.fromScale(0.5, 0.5)
				v_u_213.SizeConstraint = Enum.SizeConstraint.RelativeXX
				v_u_213.Size = UDim2.fromScale(1.45, 1.45)
				v_u_213.BackgroundTransparency = 1
				v_u_213.Image = v_u_12.SpeedLines
				v_u_213.ImageColor3 = p207
				v_u_213.ImageTransparency = 0.1
				v_u_213.Rotation = math.random(0, 359)
				v_u_213.Parent = v212
				local v_u_214 = os.clock()
				local v215 = v_u_26
				table.insert(v215, function(p216)
					-- upvalues: (copy) v_u_213, (copy) v_u_214, (copy) p_u_208
					if not v_u_213.Parent then
						return true
					end
					local v217 = (p216 - v_u_214) / p_u_208
					local v218 = math.clamp(v217, 0, 1)
					v_u_213.Rotation = (v_u_213.Rotation + 7) % 360
					v_u_213.ImageTransparency = v218 * 0.9 * v218 + 0.1
					v_u_213.Size = UDim2.fromScale(v218 * 0.25 + 1.45, v218 * 0.25 + 1.45)
					if v218 < 1 then
						return false
					end
					v_u_213:Destroy()
					return true
				end)
				if not v_u_27 then
					v_u_27 = v_u_5.RenderStepped:Connect(function()
						-- upvalues: (ref) v_u_26, (ref) v_u_27
						local v219 = os.clock()
						for v220 = #v_u_26, 1, -1 do
							if not v_u_26[v220](v219) then
								continue
							end
							table.remove(v_u_26, v220)
						end
						local v221 = v_u_27
						if #v_u_26 == 0 and v221 then
							v221:Disconnect()
							v_u_27 = nil
						end
					end)
				end
				v_u_1:AddItem(v_u_213, p_u_208 + 0.5)
			end
		end
	end
end
local function v_u_267(p223, p224, p225) -- name: slam
	-- upvalues: (copy) v_u_23, (copy) v_u_13, (copy) v_u_85, (copy) v_u_8, (copy) v_u_86, (copy) v_u_136, (copy) v_u_12, (copy) v_u_17, (copy) v_u_163
	local v226 = p223.X
	local v227 = p223.Z
	local v228 = v_u_23 + 0
	local v_u_229 = Vector3.new(v226, v228, v227)
	local v230 = p225.color or v_u_13.FIRE
	local v231 = p225.hot or v_u_13.GOLD
	local v_u_232 = p224 / 10
	local v233 = v_u_85
	local v234 = p224 * 0.35
	v233("star", v_u_229 + Vector3.new(0, v234, 0), 1, v_u_232 * 0.9, v231)
	v_u_85("ring", v_u_229 + Vector3.new(0, 0.45, 0), 1, v_u_232 * 1.1, v230)
	task.delay(0.08, function()
		-- upvalues: (ref) v_u_85, (copy) v_u_229, (copy) v_u_232, (ref) v_u_13
		v_u_85("ring", v_u_229 + Vector3.new(0, 0.5, 0), 1, v_u_232 * 0.85, v_u_13.RED)
	end)
	if v_u_8.level() >= 2 then
		v_u_85("dust", v_u_229 + Vector3.new(0, 0.6, 0), 1, v_u_232 * 1.25)
	end
	local v235 = v_u_232 * 0.8
	local v236 = v_u_85
	local v237 = v_u_229.X
	local v238 = v_u_23 + (v_u_86.erupt or 0) * v235
	local v239 = v_u_229.Z
	v236("erupt", Vector3.new(v237, v238, v239), 1, v235, v230)
	local v240 = p225.spikes or 0
	if v240 > 0 then
		local v241 = v_u_8.level()
		local v242 = v240 * (v241 >= 3 and 1 or (v241 == 2 and 0.6 or 0.35))
		local v243 = math.round(v242)
		local v244 = math.max(1, v243)
		local v245 = math.random() * 3.141592653589793 * 2
		for v246 = 1, v244 do
			local v247 = v245 + v246 / v244 * 3.141592653589793 * 2
			local v248 = p224 * (0.55 + math.random() * 0.25)
			local v249 = math.cos(v247) * v248
			local v250 = math.sin(v247) * v248
			local v251 = v_u_229 + Vector3.new(v249, 0, v250)
			local v252 = v_u_232 * (0.45 + math.random() * 0.2)
			local v253 = v_u_85
			local v254 = v251.X
			local v255 = v_u_23 + (v_u_86.spikes or 0) * v252
			local v256 = v251.Z
			v253("spikes", Vector3.new(v254, v255, v256), 1, v252, v231)
		end
	end
	if p225.boom ~= false then
		local v257 = v_u_85
		local v258 = p224 * 0.4
		v257("boom", v_u_229 + Vector3.new(0, v258, 0), 1, v_u_232 * 0.85)
	end
	if p225.crater ~= false then
		local v259 = v_u_229.X
		local v260 = v_u_229.Z
		local v261 = v_u_23 + 0
		local v262 = Vector3.new(v259, v261, v260)
		v_u_136(v262 + Vector3.new(0, 0.26, 0), p224 * 2.6, v_u_12.CrackGlow, v230, 2.4)
		v_u_136(v262 + Vector3.new(0, 0.3, 0), p224 * 1.5, v_u_12.KyubiCrater, v_u_17, 2.4)
	end
	local v263 = p225.rocks or 0
	if v263 > 0 then
		local v264 = v_u_163
		local v265 = p224 * 0.8
		local v266 = p224 / 9
		v264(v_u_229, v263, v265, (math.clamp(v266, 1.5, 3.5)))
	end
end
local function v_u_278(p268, p269, p270, p271) -- name: crackle
	-- upvalues: (copy) v_u_8, (copy) v_u_85
	if v_u_8.level() >= 2 then
		local v272 = v_u_8.level()
		local v273 = p271 * (v272 >= 3 and 1 or (v272 == 2 and 0.6 or 0.35))
		local v274 = math.round(v273)
		for _ = 1, math.max(1, v274) do
			local v275 = (math.random() - 0.5) * p269.X
			local v276 = (math.random() - 0.5) * p269.Y
			local v277 = (math.random() - 0.5) * p269.Z
			v_u_85("bolts", p268 + Vector3.new(v275, v276, v277), 1, 3 + math.random() * 2, p270)
		end
	end
end
local v_u_279 = false
function v_u_13.warm() -- name: warm
	-- upvalues: (ref) v_u_279, (copy) v_u_46, (copy) v_u_87, (copy) v_u_12, (copy) v_u_9, (ref) v_u_24, (copy) v_u_23, (copy) v_u_6, (copy) v_u_1
	if not v_u_279 then
		v_u_279 = true
		local v280 = {}
		for _, v281 in v_u_46 do
			local v282 = v281.texture
			table.insert(v280, v282)
		end
		for _, v283 in v_u_87 do
			local v284 = v283.texture
			table.insert(v280, v284)
		end
		for _, v285 in {
			v_u_12.KyubiCrater,
			v_u_12.KyubiBombCore,
			v_u_12.KyubiFireball,
			v_u_12.CometFlame,
			v_u_12.CrackGlow
		} do
			table.insert(v280, v285)
		end
		v_u_9.images(v280)
		local v286 = v_u_24.X
		local v287 = v_u_24.Z
		local v288 = v_u_23 + 20
		local v289 = Vector3.new(v286, v288, v287)
		for _, v290 in v280 do
			local v291 = Instance.new("Attachment")
			v291.Position = v289
			local v292 = Instance.new("ParticleEmitter")
			v292.Enabled = false
			v292.Texture = v290
			v292.Size = NumberSequence.new(0.6)
			v292.Transparency = NumberSequence.new(0.97)
			v292.Lifetime = NumberRange.new(0.5)
			v292.Speed = NumberRange.new(0)
			v292.Parent = v291
			v291.Parent = v_u_6.Terrain
			v292:Emit(1)
			v_u_1:AddItem(v291, 1)
		end
	end
end
local function v_u_334(p293, p294, p_u_295, p_u_296) -- name: roundArea
	-- upvalues: (copy) v_u_7, (copy) v_u_25, (copy) v_u_15, (copy) v_u_16, (copy) v_u_17
	local v_u_297 = p_u_295 * 2
	local v_u_298 = v_u_7.part(Vector3.new(v_u_297, 0.1, v_u_297), CFrame.new(p293, v_u_25, p294), v_u_15, {
		["transparency"] = 1
	})
	local v_u_299 = Instance.new("SurfaceGui")
	v_u_299.Face = Enum.NormalId.Top
	v_u_299.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
	local v300 = 900 / v_u_297
	v_u_299.PixelsPerStud = math.clamp(v300, 2, 12)
	v_u_299.LightInfluence = 0
	v_u_299.Brightness = 1.6
	v_u_299.ClipsDescendants = false
	v_u_299.Parent = v_u_298
	local v_u_301 = v_u_299.PixelsPerStud
	local function v308(p302, p303, p304, p305) -- name: disc
		-- upvalues: (copy) v_u_301, (copy) v_u_299
		local v306 = Instance.new("Frame")
		v306.AnchorPoint = Vector2.new(0.5, 0.5)
		v306.Position = UDim2.fromScale(0.5, 0.5)
		v306.Size = UDim2.fromOffset(p302 * v_u_301, p302 * v_u_301)
		v306.BackgroundColor3 = p303
		v306.BackgroundTransparency = p304
		v306.BorderSizePixel = 0
		v306.ZIndex = p305
		local v307 = Instance.new("UICorner")
		v307.CornerRadius = UDim.new(0.5, 0)
		v307.Parent = v306
		v306.Parent = v_u_299
		return v306
	end
	local v_u_309 = nil
	local v_u_310 = nil
	if p_u_296 > 0 then
		local v311 = p_u_296 * 2
		local v312 = p_u_295 - p_u_296
		local v313 = v_u_15
		local v314 = v308(v311, v313, 1, 1)
		local v315 = Instance.new("UIStroke")
		v315.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v315.Color = v313
		v315.Transparency = 0.55
		v315.Thickness = v312 * v_u_301
		v315.Parent = v314
		local v316 = v_u_16
		local v317 = v308(p_u_296 * 2, v316, 1, 2)
		local v318 = Instance.new("UIStroke")
		v318.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v318.Color = v316
		v318.Transparency = 0.3
		v318.Thickness = 0 * v_u_301
		v318.Parent = v317
		v_u_310 = v318
		local v319 = v_u_16
		local v320 = v308(p_u_296 * 2, v319, 1, 3)
		local v321 = Instance.new("UIStroke")
		v321.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v321.Color = v319
		v321.Transparency = 0
		v321.Thickness = 0.6 * v_u_301
		v321.Parent = v320
		local v322 = v_u_16
		local v323 = v308(p_u_295 * 2 - 1.2, v322, 1, 3)
		local v324 = Instance.new("UIStroke")
		v324.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v324.Color = v322
		v324.Transparency = 0
		v324.Thickness = 0.6 * v_u_301
		v324.Parent = v323
	else
		v308(v_u_297, v_u_15, 0.55, 1)
		v_u_309 = v308(0, v_u_16, 0.3, 2)
		local v325 = v_u_16
		local v326 = v308(v_u_297 - 1.2, v325, 1, 3)
		local v327 = Instance.new("UIStroke")
		v327.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
		v327.Color = v325
		v327.Transparency = 0
		v327.Thickness = 0.6 * v_u_301
		v327.Parent = v326
	end
	return {
		["fill"] = function(p328) -- name: fill
			-- upvalues: (ref) v_u_309, (copy) v_u_297, (copy) v_u_301, (ref) v_u_310, (copy) p_u_295, (copy) p_u_296
			local v329 = math.clamp(p328, 0, 1)
			local v330 = v_u_309
			if v330 then
				local v331 = v_u_297 * v329 * v_u_301
				v330.Size = UDim2.fromOffset(v331, v331)
			end
			local v332 = v_u_310
			if v332 then
				v332.Thickness = (p_u_295 - p_u_296) * v329 * v_u_301
			end
		end,
		["flash"] = function() -- name: flash
			-- upvalues: (copy) v_u_299, (ref) v_u_17
			for _, v333 in v_u_299:GetDescendants() do
				if v333:IsA("Frame") and v333.BackgroundTransparency < 1 then
					v333.BackgroundColor3 = v_u_17
				else
					if not v333:IsA("UIStroke") then
						continue
					end
					v333.Color = v_u_17
				end
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) v_u_298
			v_u_298:Destroy()
		end
	}
end
local function v_u_362(p335, p336, p337, p338, p339) -- name: triangle
	local v340 = p336 - p335
	local v341 = p337 - p335
	local v342 = p337 - p336
	local v343 = v340:Dot(v340)
	local v344 = v341:Dot(v341)
	local v345 = v342:Dot(v342)
	if v344 < v343 and v345 < v343 then
		local v346 = p337
		p337 = p335
		p335 = p336
		p336 = v346
	elseif v345 < v344 then
		if v343 >= v344 then
			local v347 = p336
			p336 = p335
			p335 = v347
		end
	else
		local v348 = p336
		p336 = p335
		p335 = v348
	end
	local v349 = p335 - p336
	local v350 = p337 - p336
	local v351 = p337 - p335
	local v352 = v350:Cross(v349)
	if v352.Magnitude < 1e-6 then
		p338.Size = Vector3.new(0.05, 0.05, 0.05)
		p339.Size = Vector3.new(0.05, 0.05, 0.05)
	else
		local v353 = v352.Unit
		local v354 = v351:Cross(v353).Unit
		local v355 = v351.Unit
		local v356 = v349:Dot(v354)
		local v357 = math.abs(v356)
		local v358 = v349:Dot(v355)
		local v359 = math.abs(v358)
		p338.Size = Vector3.new(0.05, v357, v359)
		p338.CFrame = CFrame.fromMatrix((p336 + p335) / 2, v353, v354, v355)
		local v360 = v350:Dot(v355)
		local v361 = math.abs(v360)
		p339.Size = Vector3.new(0.05, v357, v361)
		p339.CFrame = CFrame.fromMatrix((p336 + p337) / 2, -v353, v354, -v355)
	end
end
local function v_u_414(p_u_363) -- name: coneArea
	-- upvalues: (copy) v_u_25, (copy) v_u_15, (copy) v_u_7, (copy) v_u_362, (copy) v_u_16, (copy) v_u_17
	local v_u_364 = p_u_363.half or 0.9
	local v_u_365 = p_u_363.yaw or 0
	local v366 = p_u_363.x
	local v367 = v_u_25
	local v368 = p_u_363.z
	local v_u_369 = Vector3.new(v366, v367, v368)
	local v_u_370 = {}
	local v_u_371 = {}
	for v372 = 1, 8 do
		local v373 = v_u_15
		local v374 = Instance.new("WedgePart")
		v374.Anchored = true
		v374.CanCollide = false
		v374.CanQuery = false
		v374.CanTouch = false
		v374.CastShadow = false
		v374.Material = Enum.Material.Neon
		v374.Color = v373
		v374.Transparency = 0.55
		v374.Parent = v_u_7.folder()
		local v375 = v_u_15
		local v376 = Instance.new("WedgePart")
		v376.Anchored = true
		v376.CanCollide = false
		v376.CanQuery = false
		v376.CanTouch = false
		v376.CastShadow = false
		v376.Material = Enum.Material.Neon
		v376.Color = v375
		v376.Transparency = 0.55
		v376.Parent = v_u_7.folder()
		local v377 = v_u_362
		local v378 = v372 - 1
		local v379 = v_u_365 - v_u_364 + 2 * v_u_364 * v378 / 8
		local v380 = p_u_363.radius * 1
		local v381 = p_u_363.x - math.sin(v379) * v380
		local v382 = v_u_25
		local v383 = p_u_363.z - math.cos(v379) * v380
		local v384 = Vector3.new(v381, v382, v383)
		local v385 = v_u_365 - v_u_364 + 2 * v_u_364 * v372 / 8
		local v386 = p_u_363.radius * 1
		local v387 = p_u_363.x - math.sin(v385) * v386
		local v388 = v_u_25
		local v389 = p_u_363.z - math.cos(v385) * v386
		v377(v_u_369, v384, Vector3.new(v387, v388, v389), v374, v376)
		table.insert(v_u_370, v374)
		table.insert(v_u_370, v376)
		local v390 = v_u_16
		local v391 = Instance.new("WedgePart")
		v391.Anchored = true
		v391.CanCollide = false
		v391.CanQuery = false
		v391.CanTouch = false
		v391.CastShadow = false
		v391.Material = Enum.Material.Neon
		v391.Color = v390
		v391.Transparency = 0.3
		v391.Parent = v_u_7.folder()
		local v392 = v_u_16
		local v393 = Instance.new("WedgePart")
		v393.Anchored = true
		v393.CanCollide = false
		v393.CanQuery = false
		v393.CanTouch = false
		v393.CastShadow = false
		v393.Material = Enum.Material.Neon
		v393.Color = v392
		v393.Transparency = 0.3
		v393.Parent = v_u_7.folder()
		v391.CFrame = CFrame.new(v_u_369 - Vector3.new(0, 0.5, 0))
		v393.CFrame = v391.CFrame
		v391.Size = Vector3.new(0.05, 0.05, 0.05)
		v393.Size = Vector3.new(0.05, 0.05, 0.05)
		table.insert(v_u_371, v391)
		table.insert(v_u_371, v393)
	end
	return {
		["fill"] = function(p394) -- name: fill
			-- upvalues: (ref) v_u_362, (copy) v_u_369, (copy) v_u_365, (copy) v_u_364, (copy) p_u_363, (ref) v_u_25, (copy) v_u_371
			local v395 = math.clamp(p394, 0.02, 1)
			for v396 = 1, 8 do
				local v397 = v_u_362
				local v398 = v_u_369 + Vector3.new(0, 0.03, 0)
				local v399 = v396 - 1
				local v400 = v_u_365 - v_u_364 + 2 * v_u_364 * v399 / 8
				local v401 = p_u_363.radius * v395
				local v402 = p_u_363.x - math.sin(v400) * v401
				local v403 = v_u_25
				local v404 = p_u_363.z - math.cos(v400) * v401
				local v405 = Vector3.new(v402, v403, v404) + Vector3.new(0, 0.03, 0)
				local v406 = v_u_365 - v_u_364 + 2 * v_u_364 * v396 / 8
				local v407 = p_u_363.radius * v395
				local v408 = p_u_363.x - math.sin(v406) * v407
				local v409 = v_u_25
				local v410 = p_u_363.z - math.cos(v406) * v407
				v397(v398, v405, Vector3.new(v408, v409, v410) + Vector3.new(0, 0.03, 0), v_u_371[v396 * 2 - 1], v_u_371[v396 * 2])
			end
		end,
		["flash"] = function() -- name: flash
			-- upvalues: (copy) v_u_371, (ref) v_u_17
			for _, v411 in v_u_371 do
				v411.Color = v_u_17
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (copy) v_u_370, (copy) v_u_371
			for _, v412 in v_u_370 do
				v412:Destroy()
			end
			for _, v413 in v_u_371 do
				v413:Destroy()
			end
		end
	}
end
function v_u_13.warn(p415, p416) -- name: warn
	-- upvalues: (copy) v_u_414, (copy) v_u_334, (copy) v_u_5
	local v_u_417 = {}
	for _, v418 in p415 do
		if v418.kind == "cone" then
			local v419 = v_u_414(v418)
			table.insert(v_u_417, v419)
		elseif v418.kind == "ring" then
			local v420 = v_u_334(v418.x, v418.z, v418.radius, v418.inner or 0)
			table.insert(v_u_417, v420)
		else
			local v421 = v_u_334(v418.x, v418.z, v418.radius, 0)
			table.insert(v_u_417, v421)
		end
	end
	local v_u_422 = os.clock()
	local v_u_423 = math.max(p416, 0.05)
	local v_u_424 = nil
	v_u_424 = v_u_5.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_422, (copy) v_u_423, (copy) v_u_417, (ref) v_u_424
		local v425 = (os.clock() - v_u_422) / v_u_423
		for _, v426 in v_u_417 do
			v426.fill(v425)
		end
		if v425 >= 1 then
			v_u_424:Disconnect()
			for _, v427 in v_u_417 do
				v427.flash()
			end
			task.delay(0.12, function()
				-- upvalues: (ref) v_u_417
				for _, v428 in v_u_417 do
					v428.destroy()
				end
			end)
		end
	end)
end
function v_u_13.setCentre(p429) -- name: setCentre
	-- upvalues: (ref) v_u_24
	v_u_24 = p429
end
local function v_u_442(p430, p431, p_u_432, p433) -- name: roarBlast
	-- upvalues: (copy) v_u_85, (copy) v_u_13, (copy) v_u_7
	local v_u_434 = CFrame.lookAt(p430, p430 + p431)
	v_u_85("star", p430, 1, 2.4, v_u_13.GOLD)
	v_u_7.flash(p430, p_u_432, 26, 0.3)
	for v_u_435 = 0, p433 - 1 do
		task.delay(v_u_435 * 0.09, function()
			-- upvalues: (ref) v_u_85, (copy) v_u_434, (copy) v_u_435, (copy) p_u_432, (ref) v_u_13
			local v436 = v_u_85
			local v437 = "wave"
			local v438 = v_u_434
			local v439 = 1
			local v440 = v_u_435 * 0.25 + 1
			local v441
			if v_u_435 % 2 == 0 then
				v441 = p_u_432
			else
				v441 = v_u_13.GOLD
			end
			v436(v437, v438, v439, v440, v441)
		end)
	end
end
function v_u_13.leapOff(p443) -- name: leapOff
	-- upvalues: (copy) v_u_23, (copy) v_u_11, (copy) v_u_85, (copy) v_u_13, (copy) v_u_8, (copy) v_u_86, (copy) v_u_7, (copy) v_u_17, (copy) v_u_163, (copy) v_u_10
	local v444 = p443.X
	local v445 = p443.Z
	local v446 = v_u_23 + 0
	local v447 = Vector3.new(v444, v446, v445)
	local v448 = v_u_11.BODY_RADIUS
	v_u_85("ring", v447 + Vector3.new(0, 0.45, 0), 1, v448 / 10 * 1.5, v_u_13.FIRE)
	if v_u_8.level() >= 2 then
		v_u_85("dust", v447 + Vector3.new(0, 0.6, 0), 1, v448 / 10 * 2)
	end
	local v449 = v_u_8.level()
	local v450 = (v449 >= 3 and 1 or (v449 == 2 and 0.6 or 0.35)) * 6
	local v451 = math.round(v450)
	local v452 = math.max(1, v451)
	for v453 = 1, v452 do
		local v454 = v453 / v452 * 3.141592653589793 * 2
		local v455 = math.cos(v454)
		local v456 = math.sin(v454)
		local v457 = v447 + Vector3.new(v455, 0, v456) * v448 * 0.9
		local v458 = 1.1 + math.random() * 0.4
		local v459 = v_u_13.GOLD
		local v460 = v_u_85
		local v461 = v457.X
		local v462 = v_u_23 + (v_u_86.spikes or 0) * v458
		local v463 = v457.Z
		v460("spikes", Vector3.new(v461, v462, v463), 1, v458, v459)
	end
	local v464 = v_u_8.level()
	local v465 = (v464 >= 3 and 1 or (v464 == 2 and 0.6 or 0.35)) * 8
	local v466 = math.round(v465)
	for _ = 1, math.max(1, v466) do
		local v467 = math.random() * 3.141592653589793 * 2
		local v468 = v448 * (0.6 + math.random() * 0.6)
		local v469 = math.cos(v467) * v468
		local v470 = math.sin(v467) * v468
		local v471 = v447 + Vector3.new(v469, 0, v470)
		local v472 = 30 + math.random() * 30
		local v473 = v471 + Vector3.new(0, v472, 0)
		v_u_7.beam(v471, v473, v_u_17, 0.6 + math.random() * 0.6, 0.35)
	end
	v_u_163(v447, 6, v448, 2)
	v_u_13.shake(0.8, 0.3)
	v_u_10.play("KyubiLeap")
end
local function v_u_520(p474, p475, p476, p_u_477) -- name: claws
	-- upvalues: (ref) v_u_24, (copy) v_u_11, (copy) v_u_23, (copy) v_u_85, (copy) v_u_13, (copy) v_u_7, (copy) v_u_127, (copy) v_u_14, (copy) v_u_136, (copy) v_u_12, (copy) v_u_8, (copy) v_u_86, (copy) v_u_163, (copy) v_u_205, (copy) v_u_10
	local v478 = v_u_24
	if p475 and p475.yaw then
		p_u_477 = p475.yaw
	end
	local v_u_479
	if p475 and p475.half then
		v_u_479 = p475.half
	else
		v_u_479 = v_u_11.CLAW_HALF
	end
	local v_u_480
	if p475 then
		local v481 = p475.x
		local v482 = p475.z
		local v483 = v_u_23 + 0
		v_u_480 = Vector3.new(v481, v483, v482)
	else
		local v484 = v478.X
		local v485 = v478.Z
		local v486 = v_u_23 + 0
		v_u_480 = Vector3.new(v484, v486, v485)
	end
	local v487 = p474 == "claw_left"
	local v488
	if p476 then
		v488 = p476:point(v487 and "hand_left" or "hand_right")
	else
		local v489 = v478.X
		local v490 = v478.Z
		local v491 = v_u_23 + 8
		v488 = Vector3.new(v489, v491, v490)
	end
	local v492 = -math.sin(p_u_477)
	local v493 = -math.cos(p_u_477)
	local v494 = Vector3.new(v492, 0, v493)
	v_u_85("crescent", v488, 1, 2.2)
	v_u_85("burst", v488, 1, 2.2, v_u_13.GOLD)
	v_u_7.flash(v488, v_u_13.FIRE, 18, 0.25)
	local v_u_495 = v_u_11.CLAW_REACH
	v_u_127("crescent", v_u_480 + v494 * v_u_495 * 0.3, p_u_477, v_u_495 * 1.55, v_u_495 * 1.9, {
		["time"] = 0.42,
		["mirror"] = nil,
		["bright"] = 1.8,
		["fadeFrom"] = 0.7,
		["mirror"] = v487
	})
	local v496 = v494.Z
	local v497 = -v494.X
	local v498 = Vector3.new(v496, 0, v497)
	local v499 = math.random(0, 3)
	for v500 = -1, 1 do
		local v501 = v_u_480 + v494 * (v_u_495 * 0.6 + v500 * 3) + v498 * v500 * 10
		v_u_127("claw", v501, p_u_477 + (v487 and 0.35 or -0.35), v_u_495 * 0.6, v_u_495 * 0.36, {
			["mirror"] = nil,
			["time"] = 1.8,
			["frame"] = nil,
			["color"] = nil,
			["bright"] = 3,
			["from"] = 0.3,
			["fadeFrom"] = 0.3,
			["lift"] = nil,
			["mirror"] = v487,
			["frame"] = v499,
			["color"] = v_u_14(255, 150, 50),
			["lift"] = (v500 + 1) * 0.02 + 0.4
		})
		v_u_85("burst", v501 + Vector3.new(0, 3, 0), 1, 1.8, v_u_13.FIRE)
	end
	v_u_136(v_u_480 + v494 * v_u_495 * 0.55 + Vector3.new(0, 0.26, 0), v_u_495 * 1.1, v_u_12.CrackGlow, v_u_13.FIRE, 2, p_u_477)
	for v_u_502 = 1, 4 do
		task.delay((v_u_502 - 1) * 0.05, function()
			-- upvalues: (copy) v_u_495, (copy) v_u_502, (ref) v_u_8, (copy) p_u_477, (copy) v_u_479, (copy) v_u_480, (ref) v_u_85, (ref) v_u_13, (ref) v_u_23, (ref) v_u_86
			local v503 = v_u_495 * (v_u_502 * 0.55 / 4 + 0.45)
			local v504 = v_u_502 + 1
			local v505 = v_u_8.level()
			local v506 = v504 * (v505 >= 3 and 1 or (v505 == 2 and 0.6 or 0.35))
			local v507 = math.round(v506)
			local v508 = math.max(1, v507)
			for v509 = 0, v508 - 1 do
				local v510 = p_u_477 + (v508 <= 1 and 0 or v509 / (v508 - 1) - 0.5) * 2 * v_u_479 * 0.85
				local v511 = v_u_480
				local v512 = -math.sin(v510)
				local v513 = -math.cos(v510)
				local v514 = v511 + Vector3.new(v512, 0, v513) * v503
				v_u_85("flame", v514 + Vector3.new(0, 2.5, 0), 1, 1.6)
				if v_u_502 ~= 4 then
					continue
				end
				local v515 = v_u_13.FIRE
				local v516 = v_u_85
				local v517 = v514.X
				local v518 = v_u_23 + (v_u_86.spikes or 0) * 1.2
				local v519 = v514.Z
				v516("spikes", Vector3.new(v517, v518, v519), 1, 1.2, v515)
			end
		end)
	end
	v_u_163(v_u_480 + v494 * 28, 8, 18, 2.5)
	v_u_13.shake(1, 0.35)
	v_u_205(v488, v_u_13.FIRE, 0.5, 0.18)
	v_u_10.play("KyubiClawHit")
end
local function v_u_547(p521) -- name: tailSweep
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_11, (copy) v_u_8, (copy) v_u_127, (copy) v_u_85, (copy) v_u_13, (copy) v_u_10
	local v522 = v_u_24
	local v523 = v522.X
	local v524 = v522.Z
	local v525 = v_u_23 + 0
	local v_u_526 = Vector3.new(v523, v525, v524)
	local v527 = v_u_11.TAIL_INNER
	local v_u_528 = v_u_11.TAIL_OUTER
	local v_u_529 = (v527 + v_u_528) / 2
	local v_u_530 = p521 + 3.141592653589793
	local v_u_531 = v_u_8.level() >= 2 and 6 or 3
	for v_u_532 = 0, v_u_531 - 1 do
		task.delay(v_u_532 * 0.4 / v_u_531, function()
			-- upvalues: (copy) v_u_530, (copy) v_u_532, (copy) v_u_531, (copy) v_u_526, (copy) v_u_529, (ref) v_u_127, (copy) v_u_528
			local v533 = v_u_530 + v_u_532 / v_u_531 * 3.141592653589793 * 2
			local v534 = v_u_526
			local v535 = -math.sin(v533)
			local v536 = -math.cos(v533)
			v_u_127("crescent", v534 + Vector3.new(v535, 0, v536) * v_u_529, v533, v_u_528 * 1.15, v_u_528 * 1.15, {
				["time"] = 0.38,
				["bright"] = 1.8,
				["fadeFrom"] = 0.7,
				["lift"] = nil,
				["lift"] = v_u_532 * 0.01 + 0.36
			})
		end)
	end
	local v537 = v_u_8.level()
	local v538 = (v537 >= 3 and 1 or (v537 == 2 and 0.6 or 0.35)) * 16
	local v539 = math.round(v538)
	local v_u_540 = math.max(1, v539)
	for v_u_541 = 0, v_u_540 - 1 do
		task.delay(v_u_541 * 0.4 / v_u_540, function()
			-- upvalues: (copy) v_u_530, (copy) v_u_541, (copy) v_u_540, (copy) v_u_526, (copy) v_u_529, (ref) v_u_85, (ref) v_u_13
			local v542 = v_u_530 + v_u_541 / v_u_540 * 3.141592653589793 * 2
			local v543 = v_u_526
			local v544 = -math.sin(v542)
			local v545 = -math.cos(v542)
			local v546 = v543 + Vector3.new(v544, 0, v545) * v_u_529
			v_u_85("flame", v546 + Vector3.new(0, 3, 0), 1, 2.2)
			if v_u_541 % 2 == 0 then
				v_u_85("burst", v546 + Vector3.new(0, 2, 0), 1, 2, v_u_13.FIRE)
			end
		end)
	end
	v_u_85("ring", v_u_526 + Vector3.new(0, 0.45, 0), 1, v_u_528 / 10, v_u_13.FIRE)
	task.delay(0.1, function()
		-- upvalues: (ref) v_u_85, (copy) v_u_526, (copy) v_u_528, (ref) v_u_13
		v_u_85("ring", v_u_526 + Vector3.new(0, 0.5, 0), 1, v_u_528 / 10 * 0.85, v_u_13.RED)
	end)
	if v_u_8.level() >= 2 then
		v_u_85("dust", v_u_526 + Vector3.new(0, 0.6, 0), 1, v_u_528 / 10 * 1.05)
	end
	v_u_13.shake(1.2, 0.5)
	v_u_10.play("KyubiTail")
end
local function v_u_593(p548, p549) -- name: roar
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_442, (copy) v_u_13, (copy) v_u_8, (copy) v_u_85, (copy) v_u_11, (copy) v_u_278, (copy) v_u_7, (copy) v_u_12, (copy) v_u_222, (copy) v_u_205, (copy) v_u_10
	local v550 = v_u_24
	local v551 = v550.X
	local v552 = v550.Z
	local v553 = v_u_23 + 0
	local v_u_554 = Vector3.new(v551, v553, v552)
	local v_u_555
	if p548 then
		v_u_555 = p548:point("mouth")
	else
		local v556 = v550.X
		local v557 = v550.Z
		local v558 = v_u_23 + 30
		v_u_555 = Vector3.new(v556, v558, v557)
	end
	local v559 = v_u_442
	local v560, v561, v562, v563
	if p548 then
		local v564 = p548:getCFrame().LookVector
		local v565 = v564.X
		local v566 = v564.Z
		local v567 = Vector3.new(v565, 0, v566)
		if v567.Magnitude > 0.1 then
			v560 = v567.Unit
		else
			v561 = p549 or 0
			v562 = -math.sin(v561)
			v563 = -math.cos(v561)
			v560 = Vector3.new(v562, 0, v563)
		end
	else
		v561 = p549 or 0
		v562 = -math.sin(v561)
		v563 = -math.cos(v561)
		v560 = Vector3.new(v562, 0, v563)
	end
	v559(v_u_555, v560, v_u_13.FIRE, v_u_8.level() >= 2 and 4 or 2)
	for v_u_568 = 0, 2 do
		task.delay(v_u_568 * 0.12, function()
			-- upvalues: (ref) v_u_85, (copy) v_u_554, (copy) v_u_568, (ref) v_u_11, (ref) v_u_13
			local v569 = v_u_85
			local v570 = "ring"
			local v571 = v_u_554
			local v572 = v_u_568 * 0.03 + 0.45
			local v573 = v571 + Vector3.new(0, v572, 0)
			local v574 = 1
			local v575 = v_u_11.ROAR_RADIUS / 10 * (v_u_568 * 0.22 + 1)
			local v576
			if v_u_568 == 1 then
				v576 = v_u_13.RED
			else
				v576 = v_u_13.FIRE
			end
			v569(v570, v573, v574, v575, v576)
		end)
	end
	if v_u_8.level() >= 2 then
		v_u_85("dust", v_u_554 + Vector3.new(0, 0.6, 0), 1, v_u_11.ROAR_RADIUS / 10 * 1.2)
	end
	v_u_85("star", v_u_554 + Vector3.new(0, 6, 0), 1, 3.5, v_u_13.GOLD)
	local v577 = v_u_278
	local v578 = v_u_554 + Vector3.new(0, 22, 0)
	local v579 = v_u_11.BODY_RADIUS * 2
	local v580 = v_u_11.BODY_RADIUS * 2
	v577(v578, Vector3.new(v579, 36, v580), v_u_13.FIRE, 10)
	if v_u_8.level() >= 2 then
		local v581 = v_u_8.level()
		local v582 = (v581 >= 3 and 1 or (v581 == 2 and 0.6 or 0.35)) * 4
		local v583 = math.round(v582)
		for _ = 1, math.max(1, v583) do
			local v584 = math.random() * 3.141592653589793 * 2
			local v585 = v_u_11.ROAR_RADIUS * (0.5 + math.random() * 0.45)
			local v586 = math.cos(v584) * v585
			local v587 = math.sin(v584) * v585
			local v_u_588 = v_u_554 + Vector3.new(v586, 0, v587)
			local v_u_589 = v_u_13.FIRE
			for v590 = 0, 1 do
				local v_u_591 = 3
				task.delay(v590 * 0.07, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_555, (copy) v_u_588, (copy) v_u_589, (copy) v_u_591, (ref) v_u_12
					local v592 = v_u_7.beam(v_u_555, v_u_588, v_u_589, v_u_591, 0.12, v_u_12.LightningArc)
					v592.TextureLength = v_u_591 * 3
					v592.TextureSpeed = 0
					v592.Brightness = 3
				end)
			end
			v_u_85("burst", v_u_588 + Vector3.new(0, 2, 0), 1, 2, v_u_13.GOLD)
		end
	end
	v_u_222(v_u_554, v_u_13.FIRE, 0.6)
	v_u_205(v_u_554, v_u_13.FIRE, 0.7, 0.3)
	v_u_13.shake(1.8, 0.8)
	v_u_10.play("KyubiRoar")
end
function v_u_13.land(p594, p595, p596, p597) -- name: land
	-- upvalues: (ref) v_u_24, (copy) v_u_520, (copy) v_u_547, (copy) v_u_267, (copy) v_u_23, (copy) v_u_13, (copy) v_u_205, (copy) v_u_10, (copy) v_u_593, (copy) v_u_11, (copy) v_u_85, (copy) v_u_86, (copy) v_u_222, (copy) v_u_8, (copy) v_u_136, (copy) v_u_12, (copy) v_u_22
	local v598 = v_u_24
	if p594 == "claw_left" or p594 == "claw_right" then
		v_u_520(p594, p595[1], p596, p597)
		return
	elseif p594 == "tail_sweep" then
		v_u_547(p597)
		return
	elseif p594 == "stomp" then
		local v_u_599 = #p595 > 2
		for v_u_600, v_u_601 in p595 do
			task.delay((v_u_600 - 1) * 0.03, function()
				-- upvalues: (ref) v_u_267, (copy) v_u_601, (ref) v_u_23, (copy) v_u_599, (copy) v_u_600
				local v602 = v_u_267
				local v603 = v_u_601.x
				local v604 = v_u_601.z
				local v605 = v_u_23 + 0
				v602(Vector3.new(v603, v605, v604), v_u_601.radius, {
					["spikes"] = v_u_599 and 0 or 5,
					["rocks"] = v_u_599 and 3 or 6,
					["boom"] = not v_u_599 or v_u_600 % 2 == 1
				})
			end)
		end
		v_u_13.shake(1.5, 0.45)
		local v606 = v_u_205
		local v607 = v598.X
		local v608 = v598.Z
		local v609 = v_u_23 + 0
		v606(Vector3.new(v607, v609, v608), v_u_13.FIRE, 0.6, 0.22)
		v_u_10.play("KyubiSlam")
		return
	elseif p594 == "roar" then
		v_u_593(p596, p597)
		return
	elseif p594 == "leap" then
		local v610 = p595[1]
		local v_u_611
		if v610 then
			local v612 = v610.x
			local v613 = v610.z
			local v614 = v_u_23 + 0
			v_u_611 = Vector3.new(v612, v614, v613)
		else
			local v615 = v598.X
			local v616 = v598.Z
			local v617 = v_u_23 + 0
			v_u_611 = Vector3.new(v615, v617, v616)
		end
		local v_u_618
		if v610 then
			v_u_618 = v610.radius
		else
			v_u_618 = v_u_11.LEAP_RADIUS
		end
		v_u_267(v_u_611, v_u_618, {
			["spikes"] = 8,
			["rocks"] = 10
		})
		task.delay(0.1, function()
			-- upvalues: (ref) v_u_85, (copy) v_u_611, (copy) v_u_618, (ref) v_u_13
			v_u_85("ring", v_u_611 + Vector3.new(0, 0.55, 0), 1, v_u_618 / 10 * 1.6, v_u_13.GOLD)
		end)
		local v619 = v_u_618 / 10 * 0.9
		local v620 = v_u_13.FIRE
		local v621 = v_u_85
		local v622 = v_u_611.X
		local v623 = v_u_23 + (v_u_86.column or 0) * v619
		local v624 = v_u_611.Z
		v621("column", Vector3.new(v622, v623, v624), 1, v619, v620)
		v_u_222(v_u_611, v_u_13.FIRE, 0.5)
		v_u_205(v_u_611, v_u_13.FIRE, 1, 0.3)
		v_u_13.shake(2.2, 0.6)
		v_u_10.play("KyubiLand")
		return
	elseif p594 == "bomb" then
		local v625 = p595[1]
		local v626
		if v625 then
			local v627 = v625.x
			local v628 = v625.z
			local v629 = v_u_23 + 0
			v626 = Vector3.new(v627, v629, v628)
		else
			local v630 = v598.X
			local v631 = v598.Z
			local v632 = v_u_23 + 0
			v626 = Vector3.new(v630, v632, v631)
		end
		local v633 = v_u_13.explode
		local v634
		if v625 then
			v634 = v625.radius
		else
			v634 = v_u_11.BOMB_RADIUS
		end
		v633(v626, v634)
	elseif p594 == "fox_rain" then
		for v_u_635, v_u_636 in p595 do
			local v637 = v_u_636.x
			local v638 = v_u_636.z
			local v639 = v_u_23 + 0
			local v_u_640 = Vector3.new(v637, v639, v638)
			task.delay(v_u_635 % 4 * 0.03, function()
				-- upvalues: (copy) v_u_636, (ref) v_u_85, (copy) v_u_640, (ref) v_u_13, (copy) v_u_635, (ref) v_u_8, (ref) v_u_23, (ref) v_u_86, (ref) v_u_136, (ref) v_u_12
				local v641 = v_u_636.radius / 10
				local v642 = v_u_85
				local v643 = v_u_640
				local v644 = v_u_636.radius * 0.45
				v642("boom", v643 + Vector3.new(0, v644, 0), 1, v641)
				v_u_85("ring", v_u_640 + Vector3.new(0, 0.45, 0), 1, v641 * 1.2, v_u_13.FIRE)
				if v_u_635 % 2 == 0 or v_u_8.level() >= 3 then
					local v645 = v_u_640
					local v646 = v641 * 0.6
					local v647 = v_u_13.FIRE
					local v648 = v_u_85
					local v649 = v645.X
					local v650 = v_u_23 + (v_u_86.erupt or 0) * v646
					local v651 = v645.Z
					v648("erupt", Vector3.new(v649, v650, v651), 1, v646, v647)
				end
				if v_u_8.level() >= 2 then
					v_u_85("flame", v_u_640 + Vector3.new(0, 2, 0), 2, v641 * 1.4)
				end
				v_u_136(v_u_640 + Vector3.new(0, 0.25, 0), v_u_636.radius * 2.2, v_u_12.CrackGlow, v_u_13.FIRE, 1.6)
			end)
		end
		v_u_13.shake(1.6, 0.6)
		local v652 = v_u_205
		local v653 = v598.X
		local v654 = v598.Z
		local v655 = v_u_23 + 0
		v652(Vector3.new(v653, v655, v654), v_u_22, 0.6, 0.25)
		v_u_10.play("KyubiClawHit")
	end
end
function v_u_13.explode(p_u_656, p_u_657) -- name: explode
	-- upvalues: (copy) v_u_7, (copy) v_u_18, (copy) v_u_1, (copy) v_u_19, (copy) v_u_85, (copy) v_u_20, (copy) v_u_13, (copy) v_u_8, (copy) v_u_23, (copy) v_u_86, (copy) v_u_194, (copy) v_u_136, (copy) v_u_12, (copy) v_u_17, (copy) v_u_163, (copy) v_u_278, (copy) v_u_222, (copy) v_u_205, (copy) v_u_10
	local v_u_658 = v_u_7.part(Vector3.new(1, 1, 1) * p_u_657 * 0.3, CFrame.new(p_u_656), v_u_18, {
		["shape"] = nil,
		["transparency"] = 0.1,
		["shape"] = Enum.PartType.Ball
	})
	v_u_7.tween(v_u_658, 0.14, {
		["Size"] = Vector3.new(1, 1, 1) * p_u_657 * 1.5
	}, Enum.EasingStyle.Quad)
	task.delay(0.14, function()
		-- upvalues: (ref) v_u_7, (copy) v_u_658, (copy) p_u_657
		v_u_7.tween(v_u_658, 0.22, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(1, 1, 1) * p_u_657 * 1.9
		})
	end)
	v_u_1:AddItem(v_u_658, 0.4)
	local v659 = v_u_7.part(Vector3.new(1, 1, 1) * p_u_657 * 0.4, CFrame.new(p_u_656), v_u_19, {
		["shape"] = nil,
		["transparency"] = 0.5,
		["shape"] = Enum.PartType.Ball
	})
	v_u_7.tween(v659, 0.3, {
		["Size"] = nil,
		["Transparency"] = 1,
		["Size"] = Vector3.new(1, 1, 1) * p_u_657 * 2.2
	})
	v_u_1:AddItem(v659, 0.35)
	local v_u_660 = p_u_657 / 10
	local v661 = v_u_85
	local v662 = p_u_657 * 0.5
	v661("star", p_u_656 + Vector3.new(0, v662, 0), 1, v_u_660 * 1.3, v_u_20)
	v_u_85("ring", p_u_656 + Vector3.new(0, 0.45, 0), 1, v_u_660 * 1.35, v_u_19)
	task.delay(0.1, function()
		-- upvalues: (ref) v_u_85, (copy) p_u_656, (copy) v_u_660, (ref) v_u_13, (copy) p_u_657
		v_u_85("ring", p_u_656 + Vector3.new(0, 0.5, 0), 1, v_u_660 * 1.1, v_u_13.FIRE)
		local v663 = v_u_85
		local v664 = p_u_656
		local v665 = p_u_657 * 0.55
		v663("blast", v664 + Vector3.new(0, v665, 0), 1, v_u_660 * 0.9)
	end)
	if v_u_8.level() >= 2 then
		v_u_85("dust", p_u_656 + Vector3.new(0, 0.6, 0), 1, v_u_660 * 1.45)
		task.delay(0.2, function()
			-- upvalues: (ref) v_u_8, (copy) p_u_657, (ref) v_u_85, (copy) p_u_656, (copy) v_u_660
			local v666 = v_u_8.level()
			local v667 = (v666 >= 3 and 1 or (v666 == 2 and 0.6 or 0.35)) * 4
			local v668 = math.round(v667)
			for _ = 1, math.max(1, v668) do
				local v669 = math.random() * 3.141592653589793 * 2
				local v670 = p_u_657 * (0.35 + math.random() * 0.4)
				local v671 = v_u_85
				local v672 = p_u_656
				local v673 = math.cos(v669) * v670
				local v674 = p_u_657 * 0.25
				local v675 = math.sin(v669) * v670
				v671("boom", v672 + Vector3.new(v673, v674, v675), 1, v_u_660 * 0.55)
			end
		end)
	end
	local v676 = v_u_660 * 1.1
	local v677 = v_u_19
	local v678 = v_u_85
	local v679 = p_u_656.X
	local v680 = v_u_23 + (v_u_86.erupt or 0) * v676
	local v681 = p_u_656.Z
	v678("erupt", Vector3.new(v679, v680, v681), 1, v676, v677)
	v_u_194(p_u_656, p_u_657 * 0.75, 90, 0.7, v_u_20)
	local v682 = v_u_19
	local v683 = p_u_656.X
	local v684 = p_u_656.Z
	local v685 = v_u_23 + 0
	local v686 = Vector3.new(v683, v685, v684)
	v_u_136(v686 + Vector3.new(0, 0.26, 0), p_u_657 * 2.6, v_u_12.CrackGlow, v682, 3)
	v_u_136(v686 + Vector3.new(0, 0.3, 0), p_u_657 * 1.5, v_u_12.KyubiCrater, v_u_17, 3)
	v_u_163(p_u_656, 14, p_u_657 * 0.8, 3)
	local v687 = v_u_278
	local v688 = p_u_657 * 0.4
	local v689 = p_u_656 + Vector3.new(0, v688, 0)
	local v690 = p_u_657 * 0.8
	v687(v689, Vector3.new(p_u_657, v690, p_u_657), v_u_20, 8)
	v_u_222(p_u_656, v_u_20, 0.6)
	v_u_205(p_u_656, v_u_19, 1.2, 0.4)
	v_u_13.shake(3, 1.1)
	v_u_10.play("KyubiBlast")
end
function v_u_13.bomb(p_u_691, p_u_692, p_u_693, p_u_694) -- name: bomb
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_7, (copy) v_u_18, (copy) v_u_19, (copy) v_u_74, (copy) v_u_12, (copy) v_u_20, (copy) v_u_46, (copy) v_u_8, (copy) v_u_10, (copy) v_u_12, (copy) v_u_57, (copy) v_u_85, (copy) v_u_13, (copy) v_u_26, (ref) v_u_27, (copy) v_u_5
	local v695 = v_u_24
	local v696 = v695.X
	local v697 = v695.Z
	local v698 = v_u_23 + 30
	local v_u_699 = Vector3.new(v696, v698, v697)
	local v700 = v_u_7.part
	local v701 = Vector3.new(2, 2, 2)
	local v702 = CFrame.new
	if p_u_691 and p_u_691.model.Parent then
		v_u_699 = p_u_691:point("mouth")
	end
	local v_u_703 = v700(v701, v702(v_u_699), v_u_18, {
		["shape"] = nil,
		["transparency"] = 0,
		["shape"] = Enum.PartType.Ball
	})
	local v704 = v_u_7.part
	local v705 = Vector3.new(3, 3, 3)
	local v706 = CFrame.new
	if p_u_691 and p_u_691.model.Parent then
		v_u_699 = p_u_691:point("mouth")
	end
	local v_u_707 = v704(v705, v706(v_u_699), v_u_19, {
		["shape"] = nil,
		["transparency"] = 0.78,
		["shape"] = Enum.PartType.Ball
	})
	local v_u_708 = v_u_74({
		["texture"] = nil,
		["grid"] = 4,
		["frames"] = "loop",
		["fps"] = 24,
		["life"] = 0.25,
		["size"] = nil,
		["fade"] = nil,
		["bright"] = 2.4,
		["z"] = 2,
		["locked"] = true,
		["texture"] = v_u_12.KyubiBombCore,
		["size"] = { 1 },
		["fade"] = { 0, 0, 0.6 }
	}, 1, v_u_20)
	v_u_708.Rate = 14
	v_u_708.Enabled = true
	v_u_708.Parent = v_u_703
	v_u_708.Shape = Enum.ParticleEmitterShape.Sphere
	v_u_708.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v_u_708.ShapePartial = 0
	local v_u_709 = v_u_74(v_u_46.gather, 1, v_u_20)
	v_u_709.Parent = v_u_703
	v_u_709.LockedToPart = true
	local v710 = Instance.new("PointLight")
	v710.Color = v_u_19
	v710.Brightness = 3
	v710.Range = 30
	v710.Shadows = false
	v710.Parent = v_u_703
	local v711 = Instance.new("Attachment")
	v711.Name = "BombCharge"
	v711.Parent = v_u_703
	local v_u_712 = v_u_7.loop("Charge", v711, v_u_19, 4)
	for _, v713 in v711:GetDescendants() do
		if not v713:IsA("ParticleEmitter") then
			continue
		end
		v713.LockedToPart = true
	end
	local v_u_714
	if v_u_8.level() >= 2 then
		local v715 = v_u_20
		local v716 = v_u_46.bolts
		if v716 then
			v_u_714 = v_u_74(v716, 1.2, v715)
			local v717 = v_u_8.level()
			v_u_714.Rate = (v717 >= 3 and 1 or (v717 == 2 and 0.6 or 0.35)) * 5
			v_u_714.Enabled = true
			v_u_714.Parent = v_u_703
		else
			v_u_714 = nil
		end
	else
		v_u_714 = nil
	end
	if v_u_714 then
		v_u_714.Shape = Enum.ParticleEmitterShape.Sphere
		v_u_714.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
		v_u_714.LockedToPart = true
	end
	local v_u_718 = v_u_10.play("KyubiBombCharge")
	local v_u_719 = os.clock()
	local v_u_720 = false
	if p_u_691 and p_u_691.model.Parent then
		v_u_699 = p_u_691:point("mouth")
	end
	local v_u_721 = v_u_699
	local v_u_722 = 0
	local v723 = Instance.new("Attachment")
	v723.Position = Vector3.new(0, 1, 0)
	v723.Parent = v_u_703
	local v724 = Instance.new("Attachment")
	v724.Position = Vector3.new(0, -1, 0)
	v724.Parent = v_u_703
	local v_u_725 = Instance.new("Trail")
	v_u_725.Attachment0 = v723
	v_u_725.Attachment1 = v724
	v_u_725.Texture = v_u_12.CometFlame
	v_u_725.TextureMode = Enum.TextureMode.Stretch
	v_u_725.Color = ColorSequence.new(v_u_20, v_u_19)
	v_u_725.LightEmission = 0.4
	v_u_725.LightInfluence = 0
	v_u_725.Lifetime = 0.3
	v_u_725.FaceCamera = true
	v_u_725.Transparency = NumberSequence.new(0, 1)
	v_u_725.Enabled = false
	v_u_725.Parent = v_u_703
	local function v742(p726)
		-- upvalues: (copy) v_u_703, (copy) v_u_712, (copy) v_u_714, (copy) v_u_708, (copy) v_u_719, (copy) p_u_693, (copy) p_u_691, (ref) v_u_699, (copy) v_u_707, (ref) v_u_722, (copy) v_u_709, (ref) v_u_57, (ref) v_u_46, (ref) v_u_721, (ref) v_u_720, (copy) v_u_718, (ref) v_u_10, (copy) v_u_725, (ref) v_u_7, (ref) v_u_19, (ref) v_u_85, (ref) v_u_20, (ref) v_u_13, (copy) p_u_694, (copy) p_u_692
		if not v_u_703.Parent then
			v_u_712()
			if v_u_714 then
				v_u_714.Enabled = false
			end
			v_u_708.Enabled = false
			return true
		end
		local v727 = p726 - v_u_719
		if v727 >= p_u_693 then
			if not v_u_720 then
				v_u_720 = true
				if p_u_691 and p_u_691.model.Parent then
					v_u_699 = p_u_691:point("mouth")
				end
				v_u_721 = v_u_699
				v_u_712()
				if v_u_714 then
					v_u_714.Enabled = false
				end
				v_u_708.Enabled = false
				if v_u_718 then
					v_u_718:Stop()
				end
				v_u_10.play("KyubiBombFire")
				v_u_725.Enabled = true
				v_u_7.flash(v_u_721, v_u_19, 30, 0.25)
				v_u_85("star", v_u_721, 1, 2.6, v_u_20)
				v_u_13.shake(1.2, 0.3)
			end
			local v728 = p_u_694
			local v729 = (v727 - p_u_693) / math.max(v728, 0.001)
			local v730 = math.clamp(v729, 0, 1)
			local v731 = v_u_721:Lerp(p_u_692 + Vector3.new(0, 3, 0), v730)
			local v732 = v730 * 3.141592653589793
			local v733 = math.sin(v732) * 6
			local v734 = v731 + Vector3.new(0, v733, 0)
			v_u_703.CFrame = CFrame.new(v734)
			v_u_707.CFrame = v_u_703.CFrame
			if v730 < 1 then
				return false
			end
			v_u_703:Destroy()
			v_u_707:Destroy()
			return true
		end
		local v735 = p_u_693
		local v736 = v727 / math.max(v735, 0.001)
		local v737 = 2 + 12 * v736
		if p_u_691 and p_u_691.model.Parent then
			v_u_699 = p_u_691:point("mouth")
		end
		local v738 = v_u_699
		v_u_703.Size = Vector3.new(1, 1, 1) * v737
		v_u_703.CFrame = CFrame.new(v738)
		local v739 = v_u_707
		local v740 = v737 * 1.5
		local v741 = v727 * 30
		v739.Size = Vector3.new(1, 1, 1) * (v740 + math.sin(v741) * 1.2)
		v_u_707.CFrame = v_u_703.CFrame
		v_u_708.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v737 * 0.7), NumberSequenceKeypoint.new(1, v737 * 0.9) })
		v_u_708.ZOffset = v737 * 0.8
		if v_u_722 <= v727 then
			v_u_722 = v727 + 0.42 - 0.22 * v736
			v_u_709.Size = v_u_57(v_u_46.gather.size, 1 + v737 / 6)
			v_u_709:Emit(1)
		end
		v_u_721 = v738
		return false
	end
	local v743 = v_u_26
	table.insert(v743, v742)
	if not v_u_27 then
		v_u_27 = v_u_5.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_26, (ref) v_u_27
			local v744 = os.clock()
			for v745 = #v_u_26, 1, -1 do
				if not v_u_26[v745](v744) then
					continue
				end
				table.remove(v_u_26, v745)
			end
			local v746 = v_u_27
			if #v_u_26 == 0 and v746 then
				v746:Disconnect()
				v_u_27 = nil
			end
		end)
	end
	task.delay(p_u_693 + p_u_694 + 2, function()
		-- upvalues: (copy) v_u_712, (copy) v_u_714, (copy) v_u_708, (copy) v_u_703, (copy) v_u_707
		v_u_712()
		if v_u_714 then
			v_u_714.Enabled = false
		end
		v_u_708.Enabled = false
		v_u_703:Destroy()
		v_u_707:Destroy()
	end)
end
function v_u_13.intro(p_u_747, p748) -- name: intro
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_194, (copy) v_u_13, (copy) v_u_85, (copy) v_u_86, (copy) v_u_7, (copy) v_u_267, (copy) v_u_8, (copy) v_u_222, (copy) v_u_205, (copy) v_u_10, (copy) v_u_442, (copy) v_u_278, (copy) v_u_11
	local v749 = v_u_24
	local v750 = v749.X
	local v751 = v749.Z
	local v752 = v_u_23 + 0
	local v_u_753 = Vector3.new(v750, v752, v751)
	local v754 = p748 or 1
	v_u_194(v_u_753, 60, 170, 0.9)
	v_u_194(v_u_753, 34, 190, 0.7, v_u_13.RED)
	local v755 = v_u_13.FIRE
	local v756 = v_u_85
	local v757 = v_u_753.X
	local v758 = v_u_23 + (v_u_86.column or 0) * 5
	local v759 = v_u_753.Z
	v756("column", Vector3.new(v757, v758, v759), 1, 5, v755)
	v_u_7.flash(v_u_753 + Vector3.new(0, 20, 0), v_u_13.FIRE, 70, 0.4)
	local v760 = (p_u_747 and (p_u_747:marker("intro", "land") or 0.5) or 0.5) / v754
	task.delay(v760, function()
		-- upvalues: (ref) v_u_267, (copy) v_u_753, (ref) v_u_85, (ref) v_u_13, (ref) v_u_8, (ref) v_u_222, (ref) v_u_205, (ref) v_u_10
		v_u_267(v_u_753, 45, {
			["spikes"] = 10,
			["rocks"] = 16
		})
		local v_u_761 = 0
		task.delay(0.15, function()
			-- upvalues: (ref) v_u_85, (ref) v_u_753, (copy) v_u_761, (ref) v_u_13
			local v762 = v_u_85
			local v763 = "ring"
			local v764 = v_u_753
			local v765 = v_u_761 * 0.03 + 0.55
			local v766 = v764 + Vector3.new(0, v765, 0)
			local v767 = 1
			local v768 = v_u_761 * 2 + 7
			local v769
			if v_u_761 == 0 then
				v769 = v_u_13.RED
			else
				v769 = v_u_13.GOLD
			end
			v762(v763, v766, v767, v768, v769)
		end)
		local v_u_770 = 1
		task.delay(0.3, function()
			-- upvalues: (ref) v_u_85, (ref) v_u_753, (copy) v_u_770, (ref) v_u_13
			local v771 = v_u_85
			local v772 = "ring"
			local v773 = v_u_753
			local v774 = v_u_770 * 0.03 + 0.55
			local v775 = v773 + Vector3.new(0, v774, 0)
			local v776 = 1
			local v777 = v_u_770 * 2 + 7
			local v778
			if v_u_770 == 0 then
				v778 = v_u_13.RED
			else
				v778 = v_u_13.GOLD
			end
			v771(v772, v775, v776, v777, v778)
		end)
		if v_u_8.level() >= 2 then
			v_u_85("dust", v_u_753 + Vector3.new(0, 0.6, 0), 1, 8)
		end
		v_u_222(v_u_753, v_u_13.FIRE, 0.5)
		v_u_205(v_u_753, v_u_13.FIRE, 1, 0.35)
		v_u_13.shake(2.2, 0.7)
		v_u_10.play("KyubiEntrance")
	end)
	local v779 = (p_u_747 and (p_u_747:marker("intro", "roar") or 1.6) or 1.6) / v754
	task.delay(v779, function()
		-- upvalues: (ref) v_u_10, (ref) v_u_13, (ref) v_u_85, (copy) v_u_753, (copy) p_u_747, (ref) v_u_442, (ref) v_u_8, (ref) v_u_278, (ref) v_u_11, (ref) v_u_222, (ref) v_u_205
		v_u_10.play("KyubiHowl")
		v_u_13.shake(2.6, 1.2)
		v_u_85("ring", v_u_753 + Vector3.new(0, 0.5, 0), 1, 11, v_u_13.FIRE)
		if p_u_747 and p_u_747.model.Parent then
			local v780 = v_u_442
			local v781 = p_u_747:point("mouth")
			local v782 = p_u_747
			local v783
			if v782 then
				local v784 = v782:getCFrame().LookVector
				local v785 = v784.X
				local v786 = v784.Z
				local v787 = Vector3.new(v785, 0, v786)
				v783 = v787.Magnitude <= 0.1 and Vector3.new(-0, 0, -1) or v787.Unit
			else
				v783 = Vector3.new(-0, 0, -1)
			end
			v780(v781, v783, v_u_13.FIRE, v_u_8.level() >= 2 and 5 or 2)
			local v788 = v_u_278
			local v789 = v_u_753 + Vector3.new(0, 24, 0)
			local v790 = v_u_11.BODY_RADIUS * 2.2
			local v791 = v_u_11.BODY_RADIUS * 2.2
			v788(v789, Vector3.new(v790, 40, v791), v_u_13.FIRE, 12)
		end
		v_u_222(v_u_753, v_u_13.RED, 0.8)
		v_u_205(v_u_753, v_u_13.RED, 0.8, 0.35)
	end)
end
function v_u_13.fall(p_u_792) -- name: fall
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_10, (copy) v_u_85, (copy) v_u_21, (copy) v_u_86, (copy) v_u_163, (copy) v_u_205, (copy) v_u_17, (copy) v_u_13, (copy) v_u_8, (copy) v_u_194, (copy) v_u_7
	local v793 = v_u_24
	local v794 = v793.X
	local v795 = v793.Z
	local v796 = v_u_23 + 0
	local v_u_797 = Vector3.new(v794, v796, v795)
	v_u_10.play("KyubiDeath")
	local v798 = p_u_792 and (p_u_792:marker("death", "hit") or 2.3) or 2.3
	task.delay(v798, function()
		-- upvalues: (ref) v_u_85, (copy) v_u_797, (ref) v_u_21, (ref) v_u_23, (ref) v_u_86, (ref) v_u_163, (ref) v_u_205, (ref) v_u_17, (ref) v_u_13, (ref) v_u_10
		v_u_85("ring", v_u_797 + Vector3.new(0, 0.45, 0), 1, 9, v_u_21)
		v_u_85("dust", v_u_797 + Vector3.new(0, 0.6, 0), 1, 8)
		local v799 = v_u_797 + Vector3.new(14, 0, 0)
		local v800 = v_u_21
		local v801 = v_u_85
		local v802 = v799.X
		local v803 = v_u_23 + (v_u_86.spikes or 0) * 2.4
		local v804 = v799.Z
		v801("spikes", Vector3.new(v802, v803, v804), 1, 2.4, v800)
		local v805 = v_u_797 - Vector3.new(14, 0, 0)
		local v806 = v_u_21
		local v807 = v_u_85
		local v808 = v805.X
		local v809 = v_u_23 + (v_u_86.spikes or 0) * 2.4
		local v810 = v805.Z
		v807("spikes", Vector3.new(v808, v809, v810), 1, 2.4, v806)
		v_u_163(v_u_797, 18, 40, 3)
		v_u_205(v_u_797, v_u_17, 0.8, 0.3)
		v_u_13.shake(2.4, 0.8)
		v_u_10.play("KyubiLand")
	end)
	task.delay(v798 + 0.8, function()
		-- upvalues: (ref) v_u_10, (ref) v_u_8, (copy) v_u_797, (ref) v_u_85, (ref) v_u_13, (ref) v_u_23, (ref) v_u_86, (ref) v_u_194, (copy) p_u_792, (ref) v_u_7
		v_u_10.play("KyubiBurn")
		local v811 = v_u_8.level()
		local v812 = (v811 >= 3 and 1 or (v811 == 2 and 0.6 or 0.35)) * 12
		local v813 = math.round(v812)
		for v_u_814 = 1, math.max(1, v813) do
			task.delay(v_u_814 * 0.11, function()
				-- upvalues: (ref) v_u_797, (ref) v_u_85, (copy) v_u_814, (ref) v_u_13, (ref) v_u_23, (ref) v_u_86
				local v815 = math.random() * 3.141592653589793 * 2
				local v816 = math.random() * 30
				local v817 = v_u_797
				local v818 = math.cos(v815) * v816
				local v819 = math.sin(v815) * v816
				local v820 = v817 + Vector3.new(v818, 2, v819)
				v_u_85("foxFire", v820, 3, 2.4)
				if v_u_814 % 3 == 0 then
					local v821 = v_u_13.FIRE
					local v822 = v_u_85
					local v823 = v820.X
					local v824 = v_u_23 + (v_u_86.column or 0) * 1.6
					local v825 = v820.Z
					v822("column", Vector3.new(v823, v824, v825), 1, 1.6, v821)
				end
			end)
		end
		v_u_194(v_u_797, 50, 130, 1.6)
		if p_u_792 then
			v_u_13.fade(p_u_792, 1.6, 0)
		end
		task.delay(1.5, function()
			-- upvalues: (ref) v_u_85, (ref) v_u_797, (ref) v_u_13, (ref) v_u_7
			v_u_85("star", v_u_797 + Vector3.new(0, 18, 0), 1, 6, v_u_13.GOLD)
			v_u_85("ring", v_u_797 + Vector3.new(0, 0.5, 0), 1, 10, v_u_13.GOLD)
			v_u_7.burst("Sparkle", v_u_797 + Vector3.new(0, 14, 0), nil, 4)
		end)
	end)
end
function v_u_13.escape(p_u_826) -- name: escape
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_10, (copy) v_u_13, (copy) v_u_442, (copy) v_u_194, (copy) v_u_85, (copy) v_u_86, (copy) v_u_8, (copy) v_u_11
	local v827 = v_u_24
	local v828 = v827.X
	local v829 = v827.Z
	local v830 = v_u_23 + 0
	local v_u_831 = Vector3.new(v828, v830, v829)
	v_u_10.play("KyubiRoar")
	v_u_13.shake(1.6, 0.8)
	if p_u_826 and p_u_826.model.Parent then
		local v832 = v_u_442
		local v833 = p_u_826:point("mouth")
		local v834
		if p_u_826 then
			local v835 = p_u_826:getCFrame().LookVector
			local v836 = v835.X
			local v837 = v835.Z
			local v838 = Vector3.new(v836, 0, v837)
			v834 = v838.Magnitude <= 0.1 and Vector3.new(-0, 0, -1) or v838.Unit
		else
			v834 = Vector3.new(-0, 0, -1)
		end
		v832(v833, v834, v_u_13.RED, 3)
	end
	task.delay(1.2, function()
		-- upvalues: (ref) v_u_10, (ref) v_u_194, (copy) v_u_831, (ref) v_u_13, (ref) v_u_85, (ref) v_u_23, (ref) v_u_86, (ref) v_u_8, (copy) p_u_826, (ref) v_u_11
		v_u_10.play("KyubiBurn")
		v_u_194(v_u_831, 60, 170, 1.2)
		v_u_194(v_u_831, 36, 190, 1, v_u_13.RED)
		local v839 = v_u_831
		local v840 = v_u_13.RED
		local v841 = v_u_85
		local v842 = v839.X
		local v843 = v_u_23 + (v_u_86.column or 0) * 5
		local v844 = v839.Z
		v841("column", Vector3.new(v842, v843, v844), 1, 5, v840)
		v_u_85("ring", v_u_831 + Vector3.new(0, 0.5, 0), 1, 9, v_u_13.FIRE)
		if v_u_8.level() >= 2 then
			v_u_85("dust", v_u_831 + Vector3.new(0, 0.6, 0), 1, 9)
		end
		if p_u_826 then
			v_u_13.fade(p_u_826, 1.2, v_u_11.HEIGHT)
		end
	end)
end
function v_u_13.fade(p_u_845, p_u_846, p_u_847) -- name: fade
	-- upvalues: (copy) v_u_5
	local v_u_848 = p_u_845:getCFrame()
	local v_u_849 = os.clock()
	local v_u_850 = {}
	local v_u_851 = {}
	for _, v852 in p_u_845.model:GetDescendants() do
		if not v852:IsA("BasePart") then
			continue
		end
		table.insert(v_u_850, v852)
		v_u_851[v852] = v852.Transparency
	end
	local v_u_853 = nil
	v_u_853 = v_u_5.RenderStepped:Connect(function()
		-- upvalues: (copy) p_u_845, (ref) v_u_853, (copy) v_u_849, (copy) p_u_846, (copy) v_u_848, (copy) p_u_847, (copy) v_u_850, (copy) v_u_851
		if p_u_845.model.Parent then
			local v854 = (os.clock() - v_u_849) / p_u_846
			local v855 = math.clamp(v854, 0, 1)
			local v856 = p_u_845
			local v857 = v_u_848
			local v858 = p_u_847 * v855 * v855
			v856:setCFrame(v857 - Vector3.new(0, v858, 0))
			for _, v859 in v_u_850 do
				v859.Transparency = v_u_851[v859] + (1 - v_u_851[v859]) * v855
			end
			if v855 >= 1 then
				v_u_853:Disconnect()
			end
		else
			v_u_853:Disconnect()
		end
	end)
end
function v_u_13.hitSpark(p860, p861) -- name: hitSpark
	-- upvalues: (copy) v_u_85, (copy) v_u_13, (copy) v_u_17, (copy) v_u_7, (copy) v_u_8
	if p861 then
		v_u_85("toonStar", p860, 1, 1.4, v_u_13.GOLD)
		v_u_85("burst", p860, 1, 1.3, v_u_17)
		v_u_7.burst("Flash", p860, v_u_13.GOLD, 1)
	else
		v_u_85("burst", p860, 1, 0.9, v_u_13.FIRE)
		if v_u_8.level() >= 2 then
			v_u_7.burst("Impact", p860, v_u_13.FIRE, 1)
		end
	end
end
function v_u_13.rain(p862, p863) -- name: rain
	-- upvalues: (copy) v_u_23, (copy) v_u_7, (copy) v_u_13, (copy) v_u_74, (copy) v_u_12, (copy) v_u_12, (copy) v_u_1, (copy) v_u_10
	local v864 = p863 - 0.7
	local v865 = math.max(v864, 0)
	local v_u_866 = math.min(0.7, p863)
	for v867, v_u_868 in p862 do
		task.delay(v865 + v867 % 3 * 0.02, function()
			-- upvalues: (copy) v_u_868, (ref) v_u_23, (ref) v_u_7, (ref) v_u_13, (ref) v_u_74, (ref) v_u_12, (copy) v_u_866, (ref) v_u_12, (ref) v_u_1
			local v869 = v_u_868.x
			local v870 = v_u_868.z
			local v871 = v_u_23 + 1
			local v872 = Vector3.new(v869, v871, v870)
			local v873 = (math.random() - 0.5) * 30
			local v874 = (math.random() - 0.5) * 30
			local v875 = v872 + Vector3.new(v873, 120, v874)
			local v876 = v_u_868.radius * 0.9
			local v877 = v_u_7.part(Vector3.new(1, 1, 1) * v876 * 0.5, CFrame.lookAt(v875, v872), v_u_13.FIRE, {
				["shape"] = nil,
				["transparency"] = 0.1,
				["shape"] = Enum.PartType.Ball
			})
			local v878 = v_u_74({
				["texture"] = nil,
				["grid"] = 4,
				["frames"] = "loop",
				["fps"] = 24,
				["life"] = nil,
				["size"] = nil,
				["fade"] = nil,
				["glow"] = 0.3,
				["bright"] = 1.6,
				["z"] = 1,
				["locked"] = true,
				["texture"] = v_u_12.KyubiFireball,
				["life"] = v_u_866 + 0.1,
				["size"] = { v876 * 0.75 },
				["fade"] = { 0 }
			}, 1, nil)
			v878.Parent = v877
			v878:Emit(1)
			local v879 = Instance.new("Attachment")
			local v880 = v876 * 0.4
			v879.Position = Vector3.new(v880, 0, 0)
			v879.Parent = v877
			local v881 = Instance.new("Attachment")
			local v882 = -v876 * 0.4
			v881.Position = Vector3.new(v882, 0, 0)
			v881.Parent = v877
			local v883 = Instance.new("Trail")
			v883.Attachment0 = v879
			v883.Attachment1 = v881
			v883.Texture = v_u_12.CometFlame
			v883.TextureMode = Enum.TextureMode.Stretch
			v883.LightEmission = 0.2
			v883.LightInfluence = 0
			v883.Brightness = 1.5
			v883.Lifetime = 0.22
			v883.FaceCamera = true
			v883.WidthScale = NumberSequence.new(1, 0.3)
			v883.Transparency = NumberSequence.new(0, 0.6)
			v883.Parent = v877
			v_u_7.tween(v877, v_u_866, {
				["Position"] = v872
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			v_u_1:AddItem(v877, v_u_866 + 0.05)
		end)
	end
	task.delay(v865, function()
		-- upvalues: (ref) v_u_10
		v_u_10.play("KyubiFireRain")
	end)
end
function v_u_13.rage(p884) -- name: rage
	-- upvalues: (ref) v_u_24, (copy) v_u_23, (copy) v_u_194, (copy) v_u_14, (copy) v_u_13, (copy) v_u_85, (copy) v_u_86, (copy) v_u_8, (copy) v_u_278, (copy) v_u_11, (copy) v_u_442, (copy) v_u_222, (copy) v_u_205, (copy) v_u_10
	local v885 = v_u_24
	local v886 = v885.X
	local v887 = v885.Z
	local v888 = v_u_23 + 0
	local v_u_889 = Vector3.new(v886, v888, v887)
	v_u_194(v_u_889, 56, 160, 0.9, v_u_14(255, 90, 90))
	local v890 = v_u_13.RED
	local v891 = v_u_85
	local v892 = v_u_889.X
	local v893 = v_u_23 + (v_u_86.erupt or 0) * 6
	local v894 = v_u_889.Z
	v891("erupt", Vector3.new(v892, v893, v894), 1, 6, v890)
	v_u_85("star", v_u_889 + Vector3.new(0, 30, 0), 1, 7, v_u_13.RED)
	for v_u_895 = 0, 2 do
		task.delay(v_u_895 * 0.12, function()
			-- upvalues: (ref) v_u_85, (copy) v_u_889, (copy) v_u_895, (ref) v_u_13
			local v896 = v_u_85
			local v897 = "ring"
			local v898 = v_u_889
			local v899 = v_u_895 * 0.03 + 0.45
			local v900 = v898 + Vector3.new(0, v899, 0)
			local v901 = 1
			local v902 = v_u_895 * 2.5 + 6
			local v903
			if v_u_895 == 1 then
				v903 = v_u_13.FIRE
			else
				v903 = v_u_13.RED
			end
			v896(v897, v900, v901, v902, v903)
		end)
	end
	if v_u_8.level() >= 2 then
		v_u_85("dust", v_u_889 + Vector3.new(0, 0.6, 0), 1, 9)
	end
	local v904 = v_u_278
	local v905 = v_u_889 + Vector3.new(0, 24, 0)
	local v906 = v_u_11.BODY_RADIUS * 2.2
	local v907 = v_u_11.BODY_RADIUS * 2.2
	v904(v905, Vector3.new(v906, 40, v907), v_u_13.RED, 14)
	if p884 and p884.model.Parent then
		local v908 = v_u_442
		local v909 = p884:point("mouth")
		local v910
		if p884 then
			local v911 = p884:getCFrame().LookVector
			local v912 = v911.X
			local v913 = v911.Z
			local v914 = Vector3.new(v912, 0, v913)
			v910 = v914.Magnitude <= 0.1 and Vector3.new(-0, 0, -1) or v914.Unit
		else
			v910 = Vector3.new(-0, 0, -1)
		end
		v908(v909, v910, v_u_13.RED, v_u_8.level() >= 2 and 4 or 2)
	end
	v_u_222(v_u_889, v_u_13.RED, 0.8)
	v_u_205(v_u_889, v_u_13.RED, 1.2, 0.45)
	v_u_13.shake(2, 0.9)
	v_u_10.play("KyubiRoar")
	if p884 then
		v_u_13.glow(p884)
	end
end
function v_u_13.glow(p915) -- name: glow
	-- upvalues: (copy) v_u_13, (copy) v_u_14, (copy) v_u_7, (copy) v_u_8, (copy) v_u_46, (copy) v_u_74
	if not p915.model:FindFirstChild("Rage") then
		local v916 = Instance.new("Highlight")
		v916.Name = "Rage"
		v916.FillColor = v_u_13.RED
		v916.FillTransparency = 0.6
		v916.OutlineColor = v_u_14(255, 150, 40)
		v916.OutlineTransparency = 0
		v916.DepthMode = Enum.HighlightDepthMode.Occluded
		v916.Parent = p915.model
		local v917 = p915.model.PrimaryPart or p915.model:FindFirstChildWhichIsA("BasePart", true)
		if v917 then
			for _, v918 in {
				{
					["at"] = nil,
					["size"] = 7,
					["at"] = p915:point("chest")
				},
				{
					["at"] = nil,
					["size"] = 4.5,
					["at"] = p915:point("head")
				}
			} do
				local v919 = Instance.new("Attachment")
				v919.Name = "RageFire"
				v919.Parent = v917
				v919.WorldPosition = v918.at - Vector3.new(0, 6, 0)
				v_u_7.loop("AuraMode", v919, v_u_13.RED, v918.size)
			end
			if v_u_8.level() >= 2 then
				local v920 = Instance.new("Attachment")
				v920.Name = "RageBolts"
				v920.Parent = v917
				v920.WorldPosition = p915:point("chest")
				local v921 = v_u_14(255, 70, 50)
				local v922 = v_u_46.bolts
				local v923
				if v922 then
					v923 = v_u_74(v922, 2.6, v921)
					local v924 = v_u_8.level()
					v923.Rate = (v924 >= 3 and 1 or (v924 == 2 and 0.6 or 0.35)) * 4
					v923.Enabled = true
					v923.Parent = v920
				else
					v923 = nil
				end
				if v923 then
					v923.Shape = Enum.ParticleEmitterShape.Sphere
					v923.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
					v923.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
				end
			end
		end
	end
end
function v_u_13.revived(p925) -- name: revived
	-- upvalues: (copy) v_u_23, (copy) v_u_14, (copy) v_u_194, (copy) v_u_85, (copy) v_u_13, (copy) v_u_7
	local v926 = p925.X
	local v927 = v_u_23
	local v928 = p925.Z
	local v929 = Vector3.new(v926, v927, v928)
	local v930 = v_u_14(110, 255, 120)
	v_u_194(v929, 9, 40, 0.6, v930)
	v_u_85("ring", v929 + Vector3.new(0, 0.45, 0), 1, 1.4, v930)
	v_u_85("star", p925, 1, 1.2, v_u_13.GOLD)
	v_u_7.burst("Sparkle", p925, nil, 1.5)
	v_u_7.flash(p925, v930, 14, 0.3)
end
function v_u_13.portal(p931) -- name: portal
	-- upvalues: (copy) v_u_23, (copy) v_u_194, (copy) v_u_13, (copy) v_u_85, (copy) v_u_7, (copy) v_u_10
	local v932 = p931.X
	local v933 = v_u_23
	local v934 = p931.Z
	local v_u_935 = Vector3.new(v932, v933, v934)
	v_u_194(v_u_935, 26, 120, 0.9, v_u_13.GOLD)
	for v_u_936 = 0, 2 do
		task.delay(v_u_936 * 0.15, function()
			-- upvalues: (ref) v_u_85, (copy) v_u_935, (copy) v_u_936, (ref) v_u_13
			local v937 = v_u_85
			local v938 = "ring"
			local v939 = v_u_935
			local v940 = v_u_936 * 0.03 + 0.45
			local v941 = v939 + Vector3.new(0, v940, 0)
			local v942 = 1
			local v943 = v_u_936 * 1.8 + 3
			local v944
			if v_u_936 == 1 then
				v944 = v_u_13.FIRE
			else
				v944 = v_u_13.GOLD
			end
			v937(v938, v941, v942, v943, v944)
		end)
	end
	v_u_85("star", v_u_935 + Vector3.new(0, 10, 0), 1, 2.5, v_u_13.GOLD)
	v_u_7.flash(v_u_935 + Vector3.new(0, 10, 0), v_u_13.GOLD, 40, 0.4)
	v_u_10.play("GateOpen", {
		["at"] = nil,
		["volume"] = 1.6,
		["at"] = v_u_935
	})
end
return v_u_13