local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = require(script.Parent:WaitForChild("ControlModule"))
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v5 = require(script.Parent:WaitForChild("CommonUtils"))
local v6 = v5.get("FlagUtil")
local v_u_7 = v5.get("PlayerModuleEventBus")
local v_u_8 = v6.getUserFlag("UserDisableForceLocalHumanoidPrediction")
local v_u_9 = false
function v_u_1.PredictLocalHumanoid() -- name: PredictLocalHumanoid
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local function v11(p10)
		-- upvalues: (ref) v_u_4
		v_u_4:SetPredictionMode(p10:WaitForChild("HumanoidRootPart"), Enum.PredictionMode.On)
	end
	if v_u_3.LocalPlayer.Character then
		v_u_4:SetPredictionMode(v_u_3.LocalPlayer.Character:WaitForChild("HumanoidRootPart"), Enum.PredictionMode.On)
	else
		v_u_3.LocalPlayer.CharacterAdded:Connect(v11)
	end
end
function v_u_1.initialize(p12) -- name: initialize
	-- upvalues: (ref) v_u_9
	p12.isServerAuthority = v_u_9
end
function v_u_1.Initialize() -- name: Initialize
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_1, (copy) v_u_7, (copy) v_u_2, (ref) v_u_9
	if not v_u_8 and v_u_4:IsClient() then
		v_u_1.PredictLocalHumanoid()
	end
	if not v_u_7.data.inputsSetupComplete and v_u_4:IsServer() then
		v_u_7:subscribe("INPUTS_SETUP"):Wait()
	end
	v_u_2:InitializeServerAuthority()
	v_u_9 = true
end
return v_u_1