local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.EnemyModels)
local v_u_5 = require(script.Parent.Fx.Kit)
local v_u_6 = require(script.Parent.Perf)
local v7 = require(v_u_2.Shared.Logic.EnemyFit)
require(v_u_2.Shared.Config.Enemies)
local v_u_8 = require(v_u_2.Shared.Config.Stages)
local v_u_9 = require(v_u_2.Shared.Config.Textures)
local v_u_10 = require(v_u_2.Shared.Config.World)
local v_u_11 = {}
local v_u_12 = v7.BOSS_SCALE
local v_u_13 = { 2, 3, 5 }
local v_u_14 = {
	"Root",
	"Waist",
	"Neck",
	"RightShoulder",
	"RightElbow",
	"RightWrist",
	"LeftShoulder",
	"LeftElbow",
	"LeftWrist",
	"RightHip",
	"RightKnee",
	"RightAnkle",
	"LeftHip",
	"LeftKnee",
	"LeftAnkle"
}
local v_u_15 = {
	1,
	2,
	3,
	7,
	8,
	9,
	4,
	5,
	6,
	13,
	14,
	15,
	10,
	11,
	12
}
local function v28(p16) -- name: mirrored
	-- upvalues: (copy) v_u_15
	local v17 = {}
	for v18, v19 in p16.angles do
		local v20 = v_u_15[v18]
		local v21 = v19.X
		local v22 = -v19.Y
		local v23 = -v19.Z
		v17[v20] = Vector3.new(v21, v22, v23)
	end
	local v24 = {
		["angles"] = v17
	}
	local v25 = -p16.shift.X
	local v26 = p16.shift.Y
	local v27 = p16.shift.Z
	v24.shift = Vector3.new(v25, v26, v27)
	return v24
end
local v_u_29 = {}
local v30 = {
	["angles"] = {
		[1] = Vector3.new(0.05, -0.12, 0),
		[2] = Vector3.new(0, -0.45, 0),
		[3] = Vector3.new(0, 0.4, 0),
		[4] = Vector3.new(0.4, 0.2, 0.3),
		[5] = Vector3.new(2.4, 0, 0),
		[7] = Vector3.new(0.75, -0.45, -0.05),
		[8] = Vector3.new(1.8, 0, 0)
	},
	["shift"] = Vector3.new(0, -0.1, 0.25)
}
v_u_29.cocked = v30
local v31 = {
	["angles"] = {
		[1] = Vector3.new(-0.18, 0.1, 0),
		[2] = Vector3.new(-0.08, 0.4, 0),
		[3] = Vector3.new(0.05, -0.4, 0),
		[4] = Vector3.new(1.8, -0.45, -0.1),
		[5] = Vector3.new(0.05, 0, 0),
		[7] = Vector3.new(0.55, -0.45, -0.05),
		[8] = Vector3.new(2.2, 0, 0),
		[13] = Vector3.new(0.75, 0, 0),
		[14] = Vector3.new(-0.95, 0, 0),
		[15] = Vector3.new(0.2, 0, 0),
		[10] = Vector3.new(-0.35, 0, 0),
		[11] = Vector3.new(-0.3, 0, 0),
		[12] = Vector3.new(0.3, 0, 0)
	},
	["shift"] = Vector3.new(0, -0.2, -0.9)
}
v_u_29.hit = v31
local v_u_32 = {
	["cocked"] = v28(v_u_29.cocked),
	["hit"] = v28(v_u_29.hit)
}
local v_u_33 = {}
local v34 = {
	["angles"] = {
		[1] = Vector3.new(0.05, -0.15, 0),
		[2] = Vector3.new(0, -0.65, 0),
		[3] = Vector3.new(0, 0.55, 0),
		[4] = Vector3.new(0, -0.45, 1.35),
		[5] = Vector3.new(1.55, 0, 0),
		[7] = Vector3.new(0.7, -0.45, -0.1),
		[8] = Vector3.new(1.9, 0, 0)
	},
	["shift"] = Vector3.new(0, -0.15, 0.25)
}
v_u_33.cocked = v34
local v35 = {
	["angles"] = {
		[1] = Vector3.new(-0.14, 0.22, 0),
		[2] = Vector3.new(-0.05, 0.75, 0),
		[3] = Vector3.new(0.05, -0.6, 0),
		[4] = Vector3.new(0, 1.3, 1.35),
		[5] = Vector3.new(1.45, 0, 0),
		[7] = Vector3.new(0.5, -0.45, -0.05),
		[8] = Vector3.new(2.2, 0, 0),
		[13] = Vector3.new(0.6, 0, 0),
		[14] = Vector3.new(-0.8, 0, 0),
		[10] = Vector3.new(-0.3, 0, 0),
		[11] = Vector3.new(-0.4, 0, 0)
	},
	["shift"] = Vector3.new(0, -0.25, -0.8)
}
v_u_33.hit = v35
local v_u_36 = {
	["cocked"] = v28(v_u_33.cocked),
	["hit"] = v28(v_u_33.hit)
}
local v_u_37 = {}
local v38 = {
	["angles"] = {
		[1] = Vector3.new(0.12, 0, 0),
		[2] = Vector3.new(0.3, 0, 0),
		[3] = Vector3.new(-0.1, 0, 0),
		[4] = Vector3.new(2.85, 0, 0.3),
		[5] = Vector3.new(0.6, 0, 0),
		[7] = Vector3.new(2.85, 0, -0.3),
		[8] = Vector3.new(0.6, 0, 0),
		[10] = Vector3.new(0.05, 0, 0),
		[11] = Vector3.new(-0.1, 0, 0),
		[12] = Vector3.new(0.05, 0, 0),
		[13] = Vector3.new(0.05, 0, 0),
		[14] = Vector3.new(-0.1, 0, 0),
		[15] = Vector3.new(0.05, 0, 0)
	},
	["shift"] = Vector3.new(0, 0.25, 0.3)
}
v_u_37.cocked = v38
local v39 = {
	["angles"] = {
		[1] = Vector3.new(-0.25, 0, 0),
		[2] = Vector3.new(-0.5, 0, 0),
		[3] = Vector3.new(0.4, 0, 0),
		[4] = Vector3.new(0.75, 0, 0.05),
		[5] = Vector3.new(0.25, 0, 0),
		[7] = Vector3.new(0.75, 0, -0.05),
		[8] = Vector3.new(0.25, 0, 0),
		[10] = Vector3.new(0.95, 0, 0),
		[11] = Vector3.new(-1.35, 0, 0),
		[12] = Vector3.new(0.4, 0, 0),
		[13] = Vector3.new(0.95, 0, 0),
		[14] = Vector3.new(-1.35, 0, 0),
		[15] = Vector3.new(0.4, 0, 0)
	},
	["shift"] = Vector3.new(0, -0.65, -0.7)
}
v_u_37.hit = v39
local function v_u_48(p40, p41, p42) -- name: wear
	local v43 = p42:FindFirstChild("Handle")
	if v43 and v43:IsA("BasePart") then
		for _, v44 in v43:GetChildren() do
			local v45
			if v44:IsA("Attachment") then
				v45 = p41[v44.Name]
			else
				v45 = nil
			end
			if not (v45 and v44:IsA("Attachment")) then
				continue
			end
			local v46 = v45.Parent
			local v47 = Instance.new("Weld")
			v47.Part0 = v46
			v47.Part1 = v43
			v47.C0 = v45.CFrame
			v47.C1 = v44.CFrame
			v47.Parent = v43
			v43.CFrame = v46.CFrame * v45.CFrame * v44.CFrame:Inverse()
			p42.Parent = p40
			return
		end
	end
end
local v_u_49 = {
	"LowerTorso",
	"UpperTorso",
	"Head",
	"RightUpperArm",
	"RightLowerArm",
	"RightHand",
	"LeftUpperArm",
	"LeftLowerArm",
	"LeftHand",
	"RightUpperLeg",
	"RightLowerLeg",
	"RightFoot",
	"LeftUpperLeg",
	"LeftLowerLeg",
	"LeftFoot"
}
local function v_u_53(p50) -- name: outfitOf
	-- upvalues: (copy) v_u_2
	local v51 = v_u_2:FindFirstChild("EnemyGear")
	if v51 then
		v51 = v51:FindFirstChild("Outfits")
	end
	if v51 then
		v51 = v51:FindFirstChild(p50)
	end
	local v52 = v_u_2:FindFirstChild("EnemyRigs")
	if v52 then
		v52 = v52:FindFirstChild("Base")
	end
	if v51 and (v52 and v52:IsA("Model")) then
		return v51, v52
	else
		return nil, nil
	end
end
local function v_u_82(p54, p55) -- name: dress
	-- upvalues: (copy) v_u_2, (copy) v_u_13, (copy) v_u_6, (copy) v_u_48
	local v56 = p54:Clone()
	local v57 = v56:FindFirstChild("HumanoidRootPart")
	local v58 = v56:FindFirstChild("Head")
	local v59 = p55:GetAttribute("Skin")
	local v60 = {}
	for _, v61 in v56:GetChildren() do
		if not v61:IsA("BasePart") or v61 == v57 then
			continue
		end
		if typeof(v59) == "Color3" then
			v61.Color = v59
		end
		for _, v62 in v61:GetChildren() do
			if not v62:IsA("Attachment") then
				continue
			end
			v60[v62.Name] = v62
		end
	end
	local v63 = p55:GetAttribute("Shirt")
	local v64 = type(v63) ~= "string" and "" or v63
	if v64 ~= "" then
		local v65 = Instance.new("Shirt")
		v65.ShirtTemplate = v64
		v65.Parent = v56
	end
	local v66 = p55:GetAttribute("Pants")
	local v67 = type(v66) ~= "string" and "" or v66
	if v67 ~= "" then
		local v68 = Instance.new("Pants")
		v68.PantsTemplate = v67
		v68.Parent = v56
	end
	local v69 = p55:GetAttribute("Graphic")
	local v70 = type(v69) ~= "string" and "" or v69
	if v70 ~= "" then
		local v71 = Instance.new("ShirtGraphic")
		v71.Graphic = v70
		v71.Parent = v56
	end
	local v72 = p55:GetAttribute("Face")
	local v73 = type(v72) ~= "string" and "" or v72
	local v74 = v58:FindFirstChild("face")
	if v73 ~= "" and (v74 and v74:IsA("Decal")) then
		v74.Texture = v73
	end
	local v75 = v_u_2:FindFirstChild("EnemyGear")
	if v75 then
		v75 = v75:FindFirstChild("Accessories")
	end
	local v76 = v_u_13[v_u_6.level()] or 5
	local v77 = string.gmatch
	local v78 = p55:GetAttribute("Accessories")
	local v79 = 0
	for v80 in v77(type(v78) ~= "string" and "" or v78, "[^,]+") do
		if v76 <= v79 then
			break
		end
		local v81
		if v75 then
			v81 = v75:FindFirstChild(v80)
		else
			v81 = v75
		end
		if not (v81 and v81:IsA("Accoutrement")) then
			continue
		end
		v_u_48(v56, v60, v81:Clone())
		v79 = v79 + 1
	end
	return v56
end
function v_u_11.build(p83, p84) -- name: build
	-- upvalues: (copy) v_u_53, (copy) v_u_4, (copy) v_u_12, (copy) v_u_82, (copy) v_u_14, (copy) v_u_49, (copy) v_u_5, (copy) v_u_9, (copy) v_u_37, (copy) v_u_29
	local v85, v86 = v_u_53(p83.id)
	if not (v85 and v86) then
		return v_u_4.build(p83, p84), nil
	end
	local v87 = p83.boss == true
	local v88 = not v87 and 1 or v_u_12
	local v89 = Color3.fromHex(p83.look.glow)
	local v90 = v_u_82(v86, v85)
	v90.Name = "Foe" .. p84
	v90:SetAttribute("FoeId", p84)
	local v91 = v90:FindFirstChild("HumanoidRootPart")
	local v92 = v90:FindFirstChild("Head")
	local v93 = v90:FindFirstChild("UpperTorso")
	if v88 ~= 1 then
		v90:ScaleTo(v88)
	end
	local v94 = {}
	local v95 = {}
	for v96, v97 in v_u_14 do
		local v98 = v90:FindFirstChild(v_u_49[v96])
		if v98 then
			v98 = v98:FindFirstChild(v97)
		end
		local v99
		if v98 then
			v99 = v98:IsA("Motor6D")
		else
			v99 = v98
		end
		local v100 = ("EnemyRigs.Base is missing its %* joint"):format(v97)
		assert(v99, v100)
		v94[v96] = v98
		v95[v96] = Vector3.new(0, 0, 0)
	end
	local v101 = v90:FindFirstChild("LeftFoot")
	local v102 = v91.Position.Y - (v101.Position.Y - v101.Size.Y / 2)
	local v103, v104 = v90:GetBoundingBox()
	local v105 = v103.Position.Y + v104.Y / 2
	local v106, v107 = v_u_4.nameTag(p83, v92, v105 - v92.Position.Y + 0.9 * v88, v88)
	v106.Parent = v90
	local v108 = v_u_4.aura(p83, v93, v91, v102, v88)
	local v109 = {}
	local v110
	if v87 then
		local v111 = v_u_5.loop
		local v112 = v88 * 0.5
		table.insert(v109, v111("Aura", v93, v89, v112, 0.5))
		local v113 = Instance.new("PointLight")
		v113.Color = v89:Lerp(Color3.new(1, 1, 1), 0.55)
		v113.Brightness = 1.3
		v113.Range = 8 + v88 * 4
		v113.Shadows = false
		v113.Parent = v93
		v110 = Instance.new("Part")
		v110.Name = "Ground"
		local v114 = 6.5 * v88
		local v115 = 6.5 * v88
		v110.Size = Vector3.new(v114, 0.1, v115)
		v110.Transparency = 1
		v110.Anchored = true
		v110.CanCollide = false
		v110.CanTouch = false
		v110.CanQuery = false
		v110.CastShadow = false
		v110.CFrame = CFrame.new(0, -v102 + 0.12, 0)
		local v116 = Instance.new("Decal")
		v116.Face = Enum.NormalId.Top
		v116.Texture = v_u_9.EnemySigil
		v116.Color3 = v89
		v116.Transparency = 0.25
		v116.Parent = v110
	else
		v110 = nil
	end
	local v117 = Instance.new("Highlight")
	v117.FillColor = Color3.new(1, 1, 1)
	v117.FillTransparency = 0.12
	v117.OutlineTransparency = 1
	v117.DepthMode = Enum.HighlightDepthMode.Occluded
	v117.Enabled = false
	v117.Parent = v90
	local v118 = {
		["model"] = nil,
		["motors"] = nil,
		["angles"] = nil,
		["scale"] = nil,
		["boss"] = nil,
		["seed"] = nil,
		["highlight"] = nil,
		["phase"] = nil,
		["swings"] = 0,
		["move"] = nil,
		["model"] = v90,
		["motors"] = v94,
		["angles"] = v95,
		["scale"] = v88,
		["boss"] = v87,
		["seed"] = p84 % 97,
		["highlight"] = v117,
		["phase"] = math.random() * 6
	}
	local v119
	if v87 then
		v119 = v_u_37
	else
		v119 = v_u_29
	end
	v118.move = v119
	return {
		["model"] = nil,
		["root"] = nil,
		["torso"] = nil,
		["head"] = nil,
		["parts"] = nil,
		["colors"] = nil,
		["waist"] = nil,
		["neck"] = nil,
		["rightArm"] = nil,
		["leftArm"] = nil,
		["rightLeg"] = nil,
		["leftLeg"] = nil,
		["tail"] = nil,
		["swings"] = nil,
		["orbits"] = nil,
		["emitters"] = nil,
		["trails"] = nil,
		["stops"] = nil,
		["ground"] = nil,
		["rig"] = "biped",
		["glow"] = nil,
		["boss"] = nil,
		["ready"] = 0,
		["scale"] = nil,
		["lift"] = nil,
		["bar"] = nil,
		["tag"] = nil,
		["model"] = v90,
		["root"] = v91,
		["torso"] = v93,
		["head"] = v92,
		["parts"] = {},
		["colors"] = {},
		["waist"] = v94[2],
		["neck"] = v94[3],
		["rightArm"] = v94[4],
		["leftArm"] = v94[7],
		["rightLeg"] = v94[10],
		["leftLeg"] = v94[13],
		["swings"] = {},
		["orbits"] = {},
		["emitters"] = v108,
		["trails"] = {},
		["stops"] = v109,
		["ground"] = v110,
		["glow"] = v89,
		["boss"] = v87,
		["scale"] = v88,
		["lift"] = v102,
		["bar"] = v107,
		["tag"] = v106
	}, v118
end
local v_u_120 = {}
local v_u_121 = Vector3.new(0, -0.08, 0)
local v_u_122 = {
	Vector3.new(-0.04, 0, 0),
	Vector3.new(0, -0.12, 0),
	Vector3.new(0.04, 0.12, 0),
	Vector3.new(0.55, 0.45, 0.05),
	Vector3.new(2, 0, 0),
	Vector3.new(0, 0, 0),
	Vector3.new(0.65, -0.45, -0.05),
	Vector3.new(1.95, 0, 0),
	Vector3.new(0, 0, 0),
	Vector3.new(0.25, 0, 0),
	Vector3.new(-0.5, 0, 0),
	Vector3.new(0.25, 0, 0),
	Vector3.new(0.25, 0, 0),
	Vector3.new(-0.5, 0, 0),
	Vector3.new(0.25, 0, 0)
}
local v_u_123 = {}
for v124, v125 in v_u_8.worlds do
	for v126, v127 in v125 do
		local v128 = table.clone(v127.enemies)
		if v127.boss then
			local v129 = v127.boss
			table.insert(v128, v129)
		end
		for _, v130 in v128 do
			if v_u_120[v130] then
				continue
			end
			v_u_120[v130] = {
				["world"] = v124,
				["stage"] = v126
			}
		end
	end
end
function v_u_11.warm(p131, p132) -- name: warm
	-- upvalues: (copy) v_u_123, (copy) v_u_53, (copy) v_u_82, (copy) v_u_3, (copy) v_u_1
	for _, v133 in p131 do
		if v_u_123[v133] then
			continue
		end
		local v134, v135 = v_u_53(v133)
		if not (v134 and v135) then
			continue
		end
		v_u_123[v133] = true
		local v136 = v_u_82(v135, v134)
		v136.Name = "WarmUp"
		for _, v137 in v136:GetDescendants() do
			if not v137:IsA("BasePart") then
				continue
			end
			v137.Transparency = 1
		end
		local v138 = v136:FindFirstChild("face", true)
		if v138 and v138:IsA("Decal") then
			v138.Transparency = 1
		end
		v136:PivotTo(CFrame.new(p132 - Vector3.new(0, 40, 0)))
		v136.Parent = v_u_3
		v_u_1:AddItem(v136, 4)
	end
end
function v_u_11.warmWorld(p139, p140) -- name: warmWorld
	-- upvalues: (copy) v_u_11, (copy) v_u_8
	local v141 = v_u_11.warm
	local v142 = v_u_8.worlds[p139]
	if v142 then
		v142 = v142[1]
	end
	local v143
	if v142 then
		v143 = table.clone(v142.enemies)
		if v142.boss then
			local v144 = v142.boss
			table.insert(v143, v144)
		end
	else
		v143 = {}
	end
	v141(v143, p140)
end
function v_u_11.warmAfter(p145, p146) -- name: warmAfter
	-- upvalues: (copy) v_u_120, (copy) v_u_11, (copy) v_u_8
	local v147 = v_u_120[p145]
	if v147 then
		local v148 = v_u_11.warm
		local v149 = v147.world
		local v150 = v147.stage + 1
		local v151 = v_u_8.worlds[v149]
		if v151 then
			v151 = v151[v150]
		end
		local v152
		if v151 then
			v152 = table.clone(v151.enemies)
			if v151.boss then
				local v153 = v151.boss
				table.insert(v152, v153)
			end
		else
			v152 = {}
		end
		v148(v152, p146)
	end
end
function v_u_11.swing(p154) -- name: swing
	-- upvalues: (copy) v_u_37, (copy) v_u_33, (copy) v_u_36, (copy) v_u_29, (copy) v_u_32
	p154.swings = p154.swings + 1
	local v155 = p154.swings
	if p154.boss then
		local v156
		if v155 % 2 == 1 then
			v156 = v_u_37
		elseif v155 % 4 == 0 then
			v156 = v_u_33
		else
			v156 = v_u_36
		end
		p154.move = v156
	else
		local v157
		if v155 % 2 == 1 then
			v157 = v_u_29
		else
			v157 = v_u_32
		end
		p154.move = v157
	end
end
function v_u_11.pose(p158, p159, p160, p161, p162, p163, p164, p165, p166) -- name: pose
	-- upvalues: (copy) v_u_122, (copy) v_u_121
	local v167 = p158.scale
	local v168 = p158.angles
	for v169, v170 in v_u_122 do
		v168[v169] = v170
	end
	local v171 = v_u_121
	local v172 = p161 / (v167 * 3)
	local v173 = math.clamp(v172, 0, 1)
	if not p162 then
		local v174 = p158.phase
		local v175 = 6.283185307179586 * p161 / (v167 * 4.4)
		p158.phase = v174 + p160 * math.min(v175, 18)
	end
	if v173 > 0.01 then
		local v176 = p158.phase
		local v177 = math.sin(v176)
		local v178 = p158.phase
		local v179 = math.cos(v178)
		local v180 = v168[10]
		local v181 = v177 * 0.75 * v173
		v168[10] = v180 + Vector3.new(v181, 0, 0)
		local v182 = v168[13]
		local v183 = v177 * -0.75 * v173
		v168[13] = v182 + Vector3.new(v183, 0, 0)
		local v184 = v168[11]
		local v185 = math.max(v179, 0) * -1.2 * v173
		v168[11] = v184 + Vector3.new(v185, 0, 0)
		local v186 = v168[14]
		local v187 = -v179
		local v188 = math.max(v187, 0) * -1.2 * v173
		v168[14] = v186 + Vector3.new(v188, 0, 0)
		local v189 = v168[12]
		local v190 = math.max(v179, 0) * 0.25 * v173
		v168[12] = v189 + Vector3.new(v190, 0, 0)
		local v191 = v168[15]
		local v192 = -v179
		local v193 = math.max(v192, 0) * 0.25 * v173
		v168[15] = v191 + Vector3.new(v193, 0, 0)
		local v194 = v168[4]
		local v195 = v177 * -0.35 * v173
		v168[4] = v194 + Vector3.new(v195, 0, 0)
		local v196 = v168[7]
		local v197 = v177 * 0.35 * v173
		v168[7] = v196 + Vector3.new(v197, 0, 0)
		local v198 = v168[2]
		local v199 = v177 * -0.12 * v173
		v168[2] = v198 + Vector3.new(0, v199, 0)
		local v200 = v168[1]
		local v201 = v173 * -0.14
		local v202 = v177 * 0.06 * v173
		v168[1] = v200 + Vector3.new(v201, v202, 0)
		local v203 = math.abs(v177) * -0.2 * v173
		v171 = v171 + Vector3.new(0, v203, 0)
	end
	if not p162 then
		local v204 = p159 * 2.4 + p158.seed
		local v205 = math.sin(v204)
		local v206 = v168[2]
		local v207 = v205 * 0.035
		v168[2] = v206 + Vector3.new(v207, 0, 0)
		local v208 = v168[4]
		local v209 = v205 * 0.03
		v168[4] = v208 + Vector3.new(0, 0, v209)
		local v210 = v168[7]
		local v211 = v205 * -0.03
		v168[7] = v210 + Vector3.new(0, 0, v211)
		local v212 = v205 * 0.02
		v171 = v171 + Vector3.new(0, v212, 0)
	end
	local v213 = p158.move
	local v214 = nil
	local v215 = nil
	local v216 = 0
	local v217 = p158.boss and 0.42 or 0.28
	if p163 then
		v215 = v213.cocked
		v216 = 1 - (1 - p163) * (1 - p163)
	elseif p164 < 0.18 then
		v214 = v213.cocked
		v215 = v213.hit
		local v218 = p164 / 0.1
		v216 = 1 - (1 - math.clamp(v218, 0, 1)) ^ 3
	elseif p164 < v217 + 0.18 then
		v214 = v213.hit
		local v219 = (p164 - 0.18) / v217
		local v220 = math.clamp(v219, 0, 1)
		v216 = v220 * v220 * (3 - v220 * 2)
	end
	if v214 or v215 then
		local v221
		if v214 then
			v221 = v214.angles
		else
			v221 = nil
		end
		local v222
		if v215 then
			v222 = v215.angles
		else
			v222 = nil
		end
		for v223 = 1, #v168 do
			local v224 = v168[v223]
			local v225
			if v221 then
				v225 = v221[v223] or v224
			else
				v225 = v224
			end
			if v222 then
				v224 = v222[v223] or v224
			end
			v168[v223] = v225:Lerp(v224, v216)
		end
		local v226
		if v214 then
			v226 = v214.shift
		else
			v226 = v171
		end
		if v215 then
			v171 = v215.shift
		end
		v171 = v226:Lerp(v171, v216)
	end
	if p165 > 0 then
		local v227 = v168[3]
		local v228 = p165 * 0.4
		v168[3] = v227 + Vector3.new(v228, 0, 0)
		local v229 = v168[2]
		local v230 = p165 * 0.18
		v168[2] = v229 + Vector3.new(v230, 0, 0)
	end
	if p162 then
		v168[3] = Vector3.new(-0.35, 0, 0)
	end
	if p166 > 0 then
		local v231 = p166 / 4
		local v232 = math.clamp(v231, 0, 1)
		local v233 = v168[10]
		local v234 = v232 * 0.9
		v168[10] = v233 + Vector3.new(v234, 0, 0)
		local v235 = v168[13]
		local v236 = v232 * 0.9
		v168[13] = v235 + Vector3.new(v236, 0, 0)
		local v237 = v168[11]
		local v238 = v232 * -1.4
		v168[11] = v237 + Vector3.new(v238, 0, 0)
		local v239 = v168[14]
		local v240 = v232 * -1.4
		v168[14] = v239 + Vector3.new(v240, 0, 0)
		local v241 = v168[4]
		local v242 = v232 * 1.3
		local v243 = v232 * 0.2
		v168[4] = v241 + Vector3.new(v242, 0, v243)
		local v244 = v168[7]
		local v245 = v232 * 1.3
		local v246 = v232 * -0.2
		v168[7] = v244 + Vector3.new(v245, 0, v246)
	end
	local v247 = p158.motors
	local v248 = v168[1]
	v247[1].Transform = CFrame.new(v171 * v167) * CFrame.fromEulerAnglesYXZ(v248.X, v248.Y, v248.Z)
	for v249 = 2, #v247 do
		local v250 = v168[v249]
		v247[v249].Transform = CFrame.fromEulerAnglesYXZ(v250.X, v250.Y, v250.Z)
	end
end
function v_u_11.flash(p251, p252) -- name: flash
	p251.highlight.Enabled = p252
end
local v_u_253 = {
	3,
	4,
	7,
	10,
	13
}
function v_u_11.die(p254, p255) -- name: die
	-- upvalues: (copy) v_u_6, (copy) v_u_253, (copy) v_u_10, (copy) v_u_5
	p254.highlight.Enabled = false
	local v_u_256 = p254.model
	local v257 = p254.scale
	local v258 = {}
	for v259 = 0, v_u_6.level() <= 1 and 1 or #v_u_253 do
		local v260 = p254.motors[v259 == 0 and 1 or v_u_253[v259]]
		local v261 = v260.Part1
		if v261 then
			table.insert(v258, v261)
		end
		v260:Destroy()
	end
	local v_u_262 = {}
	for _, v263 in v_u_256:GetDescendants() do
		if not v263:IsA("BasePart") or (v263.Name == "HumanoidRootPart" or v263.Name == "Ground") then
			continue
		end
		v263.Massless = false
		table.insert(v_u_262, v263)
	end
	for v264, v265 in v258 do
		v265.CanCollide = true
		v265.CollisionGroup = v_u_10.DEBRIS_GROUP
		local v266 = v265.Position - p255
		local v267 = v266.X
		local v268 = v266.Z
		local v269 = Vector3.new(v267, 0, v268)
		if v269.Magnitude < 0.1 then
			local v270 = math.random() - 0.5
			local v271 = math.random() - 0.5
			v269 = Vector3.new(v270, 0, v271)
		end
		local v272 = v264 == 2 and 30 or 16
		local v273 = v269.Unit * (14 + math.random() * 10) * math.sqrt(v257)
		local v274 = v272 + math.random() * 10
		v265.AssemblyLinearVelocity = v273 + Vector3.new(0, v274, 0)
		local v275 = math.random() - 0.5
		local v276 = math.random() - 0.5
		local v277 = math.random() - 0.5
		v265.AssemblyAngularVelocity = Vector3.new(v275, v276, v277) * 16
	end
	task.delay(0.6, function()
		-- upvalues: (copy) v_u_262, (ref) v_u_5, (copy) v_u_256
		for _, v278 in v_u_262 do
			if not v278.Parent then
				continue
			end
			v_u_5.tween(v278, 0.4, {
				["Transparency"] = 1
			})
		end
		local v279 = v_u_256:FindFirstChild("face", true)
		if v279 and v279:IsA("Decal") then
			v_u_5.tween(v279, 0.4, {
				["Transparency"] = 1
			})
		end
	end)
end
return v_u_11