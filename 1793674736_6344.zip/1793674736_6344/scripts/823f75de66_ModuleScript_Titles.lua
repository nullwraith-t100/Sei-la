local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TextChatService")
local v4 = {}
local v_u_5 = Color3.fromRGB(255, 214, 64)
local v_u_6 = Color3.fromRGB(255, 140, 0)
local v_u_7 = Font.new("rbxasset://fonts/families/FredokaOne.json", Enum.FontWeight.Bold)
local v_u_8 = {}
local v_u_9 = {
	["FOX SLAYER"] = {
		["shine"] = nil,
		["stroke"] = nil,
		["chat"] = nil,
		["mark"] = "\240\159\148\165",
		["shine"] = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromHex("#D9161E")),
			ColorSequenceKeypoint.new(0.3, Color3.fromHex("#FF5A14")),
			ColorSequenceKeypoint.new(0.5, Color3.fromHex("#FFE89A")),
			ColorSequenceKeypoint.new(0.7, Color3.fromHex("#FF5A14")),
			ColorSequenceKeypoint.new(1, Color3.fromHex("#D9161E"))
		}),
		["stroke"] = Color3.fromHex("#3A0800"),
		["chat"] = {
			"#FFC23A",
			"#FF9A1A",
			"#FF7A1A",
			"#FF5A14",
			"#FF3A14",
			"#E8221A"
		}
	},
	["VIP+"] = {
		["shine"] = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 196, 40)),
			ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 90, 120)),
			ColorSequenceKeypoint.new(0.4, Color3.fromRGB(190, 100, 255)),
			ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)),
			ColorSequenceKeypoint.new(0.6, Color3.fromRGB(90, 200, 255)),
			ColorSequenceKeypoint.new(0.8, Color3.fromRGB(110, 255, 140)),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 196, 40))
		}),
		["stroke"] = Color3.fromRGB(60, 10, 90),
		["chat"] = {
			"#FFD640",
			"#FF8A3D",
			"#FF5AD2",
			"#B57BFF"
		}
	},
	["HOKAGE"] = {
		["shine"] = ColorSequence.new({
			ColorSequenceKeypoint.new(0, Color3.fromRGB(220, 40, 30)),
			ColorSequenceKeypoint.new(0.35, Color3.fromRGB(255, 140, 20)),
			ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 250, 210)),
			ColorSequenceKeypoint.new(0.65, Color3.fromRGB(255, 140, 20)),
			ColorSequenceKeypoint.new(1, Color3.fromRGB(220, 40, 30))
		}),
		["stroke"] = Color3.fromRGB(80, 10, 0),
		["chat"] = {
			"#FFE070",
			"#FFB030",
			"#FF8A1A",
			"#FF6A14",
			"#FF4A10",
			"#E8301A"
		}
	}
}
local function v_u_21(p10) -- name: chatPrefix
	-- upvalues: (copy) v_u_9
	local v11 = v_u_9[p10]
	if not v11 then
		return ("<font color=\"#FFD640\">[%*]</font>"):format(p10)
	end
	local v12 = { (("<font color=\"%*\">[</font>"):format(v11.chat[1])) }
	local v13 = #p10
	for v14 = 1, v13 do
		local v15 = v11.chat
		local v16 = #v11.chat
		local v17 = (v14 - 1) / v13 * #v11.chat
		local v18 = math.floor(v17) + 1
		local v19 = ("<font color=\"%*\">%*</font>"):format(v15[math.min(v16, v18)], (string.sub(p10, v14, v14)))
		table.insert(v12, v19)
	end
	local v20 = ("<font color=\"%*\">]</font>"):format(v11.chat[#v11.chat])
	table.insert(v12, v20)
	return table.concat(v12)
end
local function v_u_24(p22) -- name: drop
	-- upvalues: (copy) v_u_8
	local v23 = v_u_8[p22]
	if v23 then
		v23:Destroy()
		v_u_8[p22] = nil
	end
end
local function v_u_37(p25) -- name: build
	-- upvalues: (copy) v_u_8, (copy) v_u_7, (copy) v_u_9, (copy) v_u_6, (copy) v_u_5
	local v26 = v_u_8[p25]
	if v26 then
		v26:Destroy()
		v_u_8[p25] = nil
	end
	local v27 = p25:GetAttribute("Title")
	local v28 = p25.Character
	if v28 then
		v28 = v28:FindFirstChild("Head")
	end
	if type(v27) == "string" and (v28 and v28:IsA("BasePart")) then
		local v29 = Instance.new("BillboardGui")
		v29.Name = "Title"
		v29.Size = UDim2.fromScale(5.5, 1.1)
		v29.StudsOffsetWorldSpace = Vector3.new(0, 6.4, 0)
		v29.MaxDistance = 90
		v29.LightInfluence = 0
		v29.AlwaysOnTop = false
		v29.Adornee = v28
		local v30 = Instance.new("TextLabel")
		v30.BackgroundTransparency = 1
		v30.Size = UDim2.fromScale(1, 1)
		v30.FontFace = v_u_7
		v30.TextScaled = true
		local v31 = v_u_9[v27]
		local v32 = v31 and (v31.mark or "\240\159\145\145") or "\240\159\145\145"
		v30.Text = v32 .. " " .. v27 .. " " .. v32
		v30.TextColor3 = Color3.new(1, 1, 1)
		local v33 = Instance.new("UIStroke")
		v33.Thickness = 2
		local v34
		if v31 then
			v34 = v31.stroke
		else
			v34 = Color3.fromRGB(70, 30, 0)
		end
		v33.Color = v34
		v33.Parent = v30
		local v35 = Instance.new("UIGradient")
		v35.Name = "Shine"
		local v36
		if v31 then
			v36 = v31.shine
		else
			v36 = ColorSequence.new({
				ColorSequenceKeypoint.new(0, v_u_6),
				ColorSequenceKeypoint.new(0.42, v_u_5),
				ColorSequenceKeypoint.new(0.5, Color3.new(1, 1, 1)),
				ColorSequenceKeypoint.new(0.58, v_u_5),
				ColorSequenceKeypoint.new(1, v_u_6)
			})
		end
		v35.Color = v36
		v35.Parent = v30
		v30.Parent = v29
		v29.Parent = v28
		v_u_8[p25] = v29
	end
end
local function v_u_40(p_u_38) -- name: watch
	-- upvalues: (copy) v_u_37
	p_u_38:GetAttributeChangedSignal("Title"):Connect(function()
		-- upvalues: (ref) v_u_37, (copy) p_u_38
		v_u_37(p_u_38)
	end)
	p_u_38.CharacterAdded:Connect(function(p39)
		-- upvalues: (ref) v_u_37, (copy) p_u_38
		p39:WaitForChild("Head", 10)
		v_u_37(p_u_38)
	end)
	if p_u_38.Character then
		task.spawn(v_u_37, p_u_38)
	end
end
function v4.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_40, (copy) v_u_24, (copy) v_u_2, (copy) v_u_8, (copy) v_u_3, (copy) v_u_21
	for _, v41 in v_u_1:GetPlayers() do
		v_u_40(v41)
	end
	v_u_1.PlayerAdded:Connect(v_u_40)
	v_u_1.PlayerRemoving:Connect(v_u_24)
	v_u_2.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_8
		local v42 = os.clock() * 0.6 % 2 - 1
		for _, v43 in v_u_8 do
			if not v43.Parent then
				continue
			end
			local v44 = v43:FindFirstChildOfClass("TextLabel")
			if v44 then
				v44 = v44:FindFirstChild("Shine")
			end
			if not (v44 and v44:IsA("UIGradient")) then
				continue
			end
			v44.Offset = Vector2.new(v42, 0)
		end
	end)
	function v_u_3.OnIncomingMessage(p45)
		-- upvalues: (ref) v_u_1, (ref) v_u_21
		local v46 = Instance.new("TextChatMessageProperties")
		local v47 = p45.TextSource
		if v47 then
			v47 = v_u_1:GetPlayerByUserId(v47.UserId)
		end
		if v47 then
			v47 = v47:GetAttribute("Title")
		end
		if type(v47) == "string" then
			v46.PrefixText = v_u_21(v47) .. " " .. p45.PrefixText
		end
		return v46
	end
end
return v4