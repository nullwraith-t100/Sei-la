local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("8E86A3")
local v_u_8 = Color3.fromHex("2A2733")
local v_u_9 = Color3.fromRGB(228, 222, 248)
local v_u_10 = Color3.fromRGB(176, 160, 226)
local v_u_11 = Color3.fromRGB(196, 188, 232)
local v_u_12 = Color3.fromRGB(6, 4, 10)
local v_u_13 = Color3.new(1, 1, 1)
local function v_u_20(p14, p15) -- name: hoop
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_1
	local v16 = v_u_4.part(Vector3.new(1, 0.05, 1), CFrame.new(0, -50, 0), p14, {
		["transparency"] = 1
	})
	local v17 = {}
	for _, v18 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v19 = Instance.new("Decal")
		v19.Face = v18
		v19.Texture = v_u_6.Ring
		v19.Color3 = p14
		v19.Parent = v16
		table.insert(v17, v19)
	end
	v_u_1:AddItem(v16, p15)
	return v16, v17
end
local function v_u_35(p21, p22, p23, p24, p25) -- name: closingRing
	-- upvalues: (copy) v_u_20, (copy) v_u_4
	local v26, v27 = v_u_20(p22, p25 + 0.05)
	v26.CFrame = CFrame.new(p21)
	local v28 = p23 * 2
	local v29 = p23 * 2
	v26.Size = Vector3.new(v28, 0.05, v29)
	for _, v30 in v27 do
		v30.Transparency = 0.1
		v_u_4.tween(v30, p25, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	local v31 = v_u_4.tween
	local v32 = {}
	local v33 = p24 * 2
	local v34 = p24 * 2
	v32.Size = Vector3.new(v33, 0.05, v34)
	v31(v26, p25, v32, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
end
local v_u_36 = {
	{
		["x"] = -0.38,
		["l1"] = 0.5,
		["l2"] = 0.42
	},
	{
		["x"] = -0.13,
		["l1"] = 0.6,
		["l2"] = 0.5
	},
	{
		["x"] = 0.13,
		["l1"] = 0.62,
		["l2"] = 0.5
	},
	{
		["x"] = 0.38,
		["l1"] = 0.55,
		["l2"] = 0.45
	}
}
local function v_u_54(p_u_37, p_u_38, p_u_39) -- name: newHand
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_7, (copy) v_u_11, (copy) v_u_36, (copy) v_u_9
	local v_u_40 = {}
	local function v46(p41, p42) -- name: piece
		-- upvalues: (ref) v_u_4, (copy) p_u_37, (copy) p_u_39, (ref) v_u_1, (copy) p_u_38, (copy) v_u_40
		local v43 = {
			["transparency"] = p_u_39
		}
		local v44 = v_u_4.part(p41 * p_u_37, CFrame.new(0, -50, 0), p42, v43)
		v_u_1:AddItem(v44, p_u_38)
		local v45 = v_u_40
		table.insert(v45, v44)
		return v44
	end
	local v47 = v46(Vector3.new(0.62, 2.2, 0.5), v_u_7)
	local v48 = v46(Vector3.new(1, 1, 0.32), v_u_11)
	local v49 = {}
	for _, v50 in v_u_36 do
		local v51 = {}
		local v52 = v50.l1 + 0.06
		v51.a = v46(Vector3.new(0.2, v52, 0.2), v_u_11)
		local v53 = v50.l2 + 0.06
		v51.b = v46(Vector3.new(0.16, v53, 0.16), v_u_9)
		v51.x = v50.x
		v51.l1 = v50.l1
		v51.l2 = v50.l2
		table.insert(v49, v51)
	end
	return {
		["forearm"] = v47,
		["palm"] = v48,
		["thumb"] = v46(Vector3.new(0.22, 0.66, 0.22), v_u_11),
		["fingers"] = v49,
		["size"] = p_u_37,
		["all"] = v_u_40
	}
end
local function v_u_66(p55, p56, p57, p58) -- name: poseHand
	local v59 = p55.size
	local v60 = p56 * CFrame.new(0, -(1 - p57) * 3.6 * v59, 0)
	p55.forearm.CFrame = v60 * CFrame.new(0, v59 * -1, v59 * 0.05)
	local v61 = v60 * CFrame.new(0, v59 * 0.5, 0) * CFrame.Angles(-p58 * 0.25, 0, 0)
	p55.palm.CFrame = v61
	local v62 = v61 * CFrame.new(0, v59 * 0.5, 0)
	for _, v63 in p55.fingers do
		local v64 = v62 * CFrame.new(v63.x * v59, 0, 0) * CFrame.Angles(0, 0, -v63.x * 0.9 * (1 - p58)) * CFrame.Angles(-p58 * 1.3 - 0.1, 0, 0)
		v63.a.CFrame = v64 * CFrame.new(0, v63.l1 * v59 / 2, 0)
		local v65 = v64 * CFrame.new(0, v63.l1 * v59, 0) * CFrame.Angles(-p58 * 1.2 - 0.25, 0, 0)
		v63.b.CFrame = v65 * CFrame.new(0, v63.l2 * v59 / 2, 0)
	end
	p55.thumb.CFrame = v60 * CFrame.new(v59 * 0.55, v59 * 0.35, v59 * -0.05) * CFrame.Angles(-p58 * 0.9, 0, p58 * 0.45 + -0.75) * CFrame.new(0, v59 * 0.32, 0)
end
local function v_u_81(p67, p68, p69) -- name: newGate
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_6, (copy) v_u_10, (copy) v_u_1
	local v70 = {}
	for _, v71 in { -1, 1 } do
		local v72 = v_u_4.part
		local v73 = p68 * 2
		local v74 = v72(Vector3.new(p68, 0.7, v73), p67, v_u_8, {
			["material"] = Enum.Material.Slate
		})
		for _, v75 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v76 = Instance.new("Decal")
			v76.Face = v75
			local v77
			if v75 == Enum.NormalId.Top then
				v77 = v_u_6.CrackLines
			else
				v77 = v_u_6.CrackGlow
			end
			v76.Texture = v77
			v76.Color3 = v_u_10
			v76.Transparency = v75 == Enum.NormalId.Top and 0.25 or 0.1
			v76.Parent = v74
		end
		local v78 = v_u_4.part
		local v79 = p68 * 2
		local v80 = v78(Vector3.new(0.35, 0.78, v79), p67, v_u_10)
		v_u_1:AddItem(v74, p69)
		v_u_1:AddItem(v80, p69)
		table.insert(v70, {
			["slab"] = v74,
			["seam"] = v80,
			["side"] = v71
		})
	end
	return {
		["frame"] = p67,
		["hw"] = p68,
		["doors"] = v70
	}
end
local function v_u_87(p82, p83) -- name: poseGate
	local v84 = p83 * 1.8325957145940461
	for _, v85 in p82.doors do
		local v86 = p82.frame * CFrame.new(v85.side * p82.hw, 0.36, 0) * CFrame.Angles(0, 0, -v85.side * v84)
		v85.slab.CFrame = v86 * CFrame.new(-v85.side * p82.hw / 2, 0, 0)
		v85.seam.CFrame = v86 * CFrame.new(-v85.side * (p82.hw - 0.17), 0.02, 0)
	end
end
return function(p_u_88)
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (copy) v_u_1, (copy) v_u_4, (copy) v_u_11, (copy) v_u_8, (copy) v_u_10, (copy) v_u_54, (copy) v_u_3, (copy) v_u_66, (copy) v_u_6, (copy) v_u_13, (copy) v_u_5, (copy) v_u_81, (copy) v_u_87, (copy) v_u_12, (copy) v_u_20, (copy) v_u_35
	local function v_u_109(p_u_89, p90, p_u_91, p_u_92, p93) -- name: freeSouls
		-- upvalues: (copy) p_u_88, (ref) v_u_9, (ref) v_u_7, (ref) v_u_1
		for v94 = 1, p90 do
			local v_u_95 = p_u_88.ball(p_u_89, v_u_9, 0.55, 0)
			p_u_88.streak(v_u_95, v_u_9, v_u_7, 0.45, 0.25)
			local v_u_96 = math.random() * 3.141592653589793 * 2
			local v_u_97 = (v94 % 2 == 0 and 1 or -1) * (4 + math.random() * 2)
			p_u_88.animate(p93, 0, function(p98)
				-- upvalues: (copy) v_u_96, (copy) v_u_97, (copy) p_u_92, (copy) v_u_95, (copy) p_u_89, (copy) p_u_91, (ref) v_u_1
				local v99 = v_u_96 + p98 * v_u_97
				local v100 = p_u_92
				local v101 = p98 * 3.141592653589793 * 0.8
				local v102 = v100 * math.sin(v101)
				local v103 = v_u_95
				local v104 = CFrame.new
				local v105 = p_u_89
				local v106 = math.cos(v99) * v102
				local v107 = p98 * p_u_91
				local v108 = math.sin(v99) * v102
				v103.CFrame = v104(v105 + Vector3.new(v106, v107, v108))
				v_u_95.Transparency = p98 * p98
				if p98 >= 1 then
					v_u_95.Transparency = 1
					v_u_1:AddItem(v_u_95, 0.3)
				end
			end)
		end
	end
	local function v_u_137(p110, p111, p112, p_u_113) -- name: grab
		-- upvalues: (copy) p_u_88, (ref) v_u_54, (ref) v_u_3, (ref) v_u_66
		local v114 = p111.Y - p_u_88.FLOOR
		local v115 = math.max(v114, 1) * 2
		local v116 = p_u_88.ground(p111, 0)
		local v117 = v116 + p_u_88.flatUnit(v116 - p110.origin) * v115 * 0.32
		local v_u_118 = v_u_54(v115 / 1.9, p_u_113 + 1.5, 0.15)
		local v_u_119 = CFrame.lookAt(v117, v116) * CFrame.Angles(0.12, 0, 0)
		local v120 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_121
		if v120 then
			v_u_121 = v120:FindFirstChild("Foe" .. p112)
		else
			v_u_121 = nil
		end
		local v_u_122 = os.clock()
		local v_u_123 = nil
		p_u_88.burst("Smoke", v116 + Vector3.new(0, 0.5, 0), nil, v115 / 6)
		p_u_88.runNow(function()
			-- upvalues: (copy) v_u_122, (ref) v_u_123, (copy) p_u_113, (copy) v_u_121, (copy) v_u_118, (ref) v_u_66, (copy) v_u_119
			local v124 = os.clock()
			local v125 = v124 - v_u_122
			if not v_u_123 and (p_u_113 < v125 or v_u_121 ~= nil and v_u_121.Parent == nil) then
				v_u_123 = v124
			end
			local v126 = v125 / 0.12
			local v127 = 1 - (1 - math.clamp(v126, 0, 1)) ^ 3
			local v128 = (v125 - 0.08) / 0.12
			local v129 = math.clamp(v128, 0, 1) * 0.7 + 0.15
			if v_u_123 then
				local v130 = (v124 - v_u_123) / 0.3
				local v131 = math.clamp(v130, 0, 1)
				local v132 = v131 * 2
				v129 = v129 * (1 - math.clamp(v132, 0, 1))
				v127 = v127 * (1 - v131 * v131)
				local v133 = v_u_118
				local v134 = v131 * 0.85 + 0.15
				for _, v135 in v133.all do
					v135.Transparency = v134
				end
				if v131 >= 1 then
					for _, v136 in v_u_118.all do
						v136:Destroy()
					end
					return false
				end
			elseif v125 > 0.25 then
				return true
			end
			v_u_66(v_u_118, v_u_119, v127, v129)
			return true
		end)
	end
	local v160 = {
		["grave_rinne_a"] = {
			["weave"] = 1.1,
			["cast"] = nil,
			["shot"] = nil,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p138) -- name: cast
				-- upvalues: (copy) p_u_88, (ref) v_u_10
				p_u_88.muzzle(p138, v_u_10, 0.9)
			end,
			["shot"] = function(p139, p140) -- name: skullShot
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8, (ref) v_u_10, (copy) p_u_88
				local v141 = p139.size
				local v142 = p139.lite
				local v143 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p140, v_u_7, {
					["transparency"] = 1
				})
				local v144 = {}
				local v145 = v_u_4.part(Vector3.new(1.55, 1.55, 1.55) * v141, p140, v_u_9, {
					["shape"] = nil,
					["transparency"] = 0.05,
					["shape"] = Enum.PartType.Ball
				})
				local v146 = {
					["p"] = v145,
					["off"] = CFrame.new(0, 0.15 * v141, 0.1 * v141)
				}
				table.insert(v144, v146)
				local v147 = {
					["p"] = v_u_4.part(Vector3.new(1.1, 0.62, 0.75) * v141, p140, v_u_9, {
						["transparency"] = 0.05
					}),
					["off"] = CFrame.new(0, -0.38 * v141, -0.32 * v141)
				}
				table.insert(v144, v147)
				local v148 = {
					["p"] = v_u_4.part(Vector3.new(0.85, 0.28, 0.6) * v141, p140, v_u_11),
					["off"] = CFrame.new(0, -0.82 * v141, -0.28 * v141) * CFrame.Angles(0.25, 0, 0)
				}
				table.insert(v144, v148)
				for _, v149 in { -0.3, 0.3 } do
					local v150 = {
						["p"] = v_u_4.part(Vector3.new(0.44, 0.44, 0.44) * v141, p140, v_u_8, {
							["shape"] = Enum.PartType.Ball,
							["material"] = Enum.Material.SmoothPlastic
						}),
						["off"] = CFrame.new(v149 * v141, 0.02 * v141, -0.6 * v141)
					}
					table.insert(v144, v150)
				end
				if not v142 then
					local v151 = {
						["p"] = v_u_4.part(Vector3.new(2.5, 2.5, 2.5) * v141, p140, v_u_10, {
							["shape"] = nil,
							["transparency"] = 0.72,
							["shape"] = Enum.PartType.Ball
						}),
						["off"] = CFrame.identity
					}
					table.insert(v144, v151)
				end
				p_u_88.streak(v143, v_u_10, v_u_8, 2.2 * v141, 0.32)
				p_u_88.streak(v145, v_u_9, v_u_7, 0.7 * v141, 0.18)
				local v152 = {}
				if not v142 then
					local v153 = p_u_88.loop
					local v154 = v_u_10
					local v155 = 0.35 * v141
					table.insert(v152, v153("Trail", v145, v154, v155))
				end
				if p139.mine then
					p_u_88.light(v143, v_u_10, 9 * v141)
				end
				return p_u_88.assemble(v143, v144, {}, 0, 0, v152, 0.32)
			end,
			["impact"] = function(p156, p157) -- name: impact
				-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_9, (ref) v_u_4, (copy) v_u_109, (ref) v_u_6
				local v158 = p156.size
				p_u_88.burst("Smoke", p157, nil, 0.8 * v158)
				p_u_88.burst("Impact", p157, v_u_10, 0.9 * v158)
				p_u_88.pop(p157, v_u_9, 1.4 * v158, 6 * v158, 0.18, 0.3)
				v_u_4.flash(p157, v_u_10, 5 * v158, 0.18)
				if not p156.lite then
					v_u_109(p157, 3, 7 * v158, 1.6 * v158, 0.6)
				end
				v_u_4.ring(p_u_88.ground(p157), v_u_10, 6 * v158, 0.3, v_u_6.Ring)
				p_u_88.hitSound(p157)
			end,
			["hit"] = function(_, p159, _) -- name: hit
				-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_9
				p_u_88.burst("Impact", p159, v_u_10, 0.6)
				p_u_88.pop(p159, v_u_9, 0.8, 2.6, 0.14, 0.35)
			end
		}
	}
	local v_u_161 = {}
	v160.grave_rinne_e = {
		["cast"] = function(p162) -- name: cast
			-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_13
			p_u_88.skillCast(p162, v_u_10)
			p_u_88.sigil(p_u_88.facing(p162.eye + p162.dir * 1.6, p162.dir), 2.4 * p162.size, v_u_13, p_u_88.iris("grave_rinne"), 0.3, 0)
		end,
		["windup"] = function(p163, p164, p165) -- name: windup
			-- upvalues: (copy) p_u_88, (ref) v_u_8, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7
			local v166 = p163.ability.radius
			local v_u_167 = p_u_88.plate(p_u_88.ground(p164, 0.06), 0.5, v_u_8, 0.3, Enum.Material.SmoothPlastic)
			local v168 = v_u_4.tween
			local v169 = math.max(p165, 0.08)
			local v170 = {}
			local v171 = v166 * 2
			local v172 = v166 * 2
			v170.Size = Vector3.new(0.12, v171, v172)
			v168(v_u_167, v169, v170)
			task.delay(p165 + 1, function()
				-- upvalues: (ref) p_u_88, (copy) v_u_167
				p_u_88.fadeOut(v_u_167, 0.4)
			end)
			p_u_88.sigil(CFrame.new(p_u_88.ground(p164, 0.14)), v166, v_u_10, v_u_6.Ring, p165 + 1, 1)
			p_u_88.sigil(CFrame.new(p_u_88.ground(p164, 0.16)), v166 * 0.6, v_u_7, v_u_6.MagicCircle, p165 + 1, -1.5)
			p_u_88.mark(p164, v_u_8, v166 * 0.85, p165 + 1.4, v_u_6.CrackLines, 0.05)
			if not p163.lite then
				p_u_88.burst("Smoke", p_u_88.ground(p164, 0.8), nil, v166 / 8)
			end
		end,
		["land"] = function(p173, p174) -- name: land
			-- upvalues: (copy) p_u_88, (ref) v_u_54, (ref) v_u_66, (ref) v_u_7, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (ref) v_u_5
			local v175 = p173.ability.radius
			local v176 = p173.lite
			local v177 = p_u_88.ground(p174, 0)
			local v178 = v176 and 3 or 5
			for v179 = 1, v178 do
				local v180 = (v179 + math.random() * 0.5) / v178 * 3.141592653589793 * 2
				local v181 = v175 * (0.3 + 0.5 * math.random())
				local v182 = math.cos(v180)
				local v183 = math.sin(v180)
				local v184 = v177 + Vector3.new(v182, 0, v183) * v181
				local v185 = CFrame.lookAt
				local v186 = p174.X
				local v187 = v184.Y
				local v188 = p174.Z
				local v_u_189 = v185(v184, (Vector3.new(v186, v187, v188))) * CFrame.Angles(0.3, 0, 0)
				local v_u_190 = v_u_54(2.3 + math.random() * 0.9, 2, 0.15)
				local v191 = v179 % 3 * 0.03
				local v_u_192 = os.clock() + v191
				p_u_88.runNow(function()
					-- upvalues: (copy) v_u_192, (copy) v_u_190, (ref) v_u_66, (copy) v_u_189
					local v193 = os.clock() - v_u_192
					local v194 = v193 / 0.14
					local v195 = 1 - (1 - math.clamp(v194, 0, 1)) ^ 3
					local v196 = (v193 - 0.32) / 0.1
					local v197 = math.clamp(v196, 0, 1)
					if v193 > 0.8 then
						local v198 = (v193 - 0.8) / 0.25
						local v199 = math.clamp(v198, 0, 1)
						v195 = v195 * (1 - v199 * v199)
						local v200 = v_u_190
						local v201 = v199 * 0.85 + 0.15
						for _, v202 in v200.all do
							v202.Transparency = v201
						end
						if v199 >= 1 then
							for _, v203 in v_u_190.all do
								v203:Destroy()
							end
							return false
						end
					end
					v_u_66(v_u_190, v_u_189, math.max(v195, 0), v197)
					return true
				end)
				if v176 then
					continue
				end
				p_u_88.burst("Smoke", v184 + Vector3.new(0, 0.5, 0), nil, 0.6)
			end
			p_u_88.burst("Shockwave", v177 + Vector3.new(0, 0.3, 0), v_u_7, v175 / 18)
			v_u_4.ring(v177, v_u_10, v175, 0.4, v_u_6.Ring)
			v_u_4.ring(v177, v_u_9, v175 * 0.8, 0.3, v_u_6.SpeedLines)
			p_u_88.pop(p_u_88.ground(p174, 1), v_u_10, 3, v175 * 0.7, 0.25, 0.6)
			v_u_5.play("Burst", {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v177
			})
			if p173.mine then
				v_u_4.shake(0.22, 0.25)
			end
		end,
		["hit"] = function(p_u_204, p205, p206) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_10, (copy) v_u_161, (ref) v_u_9, (copy) v_u_137
			local v207 = p_u_204.ability.freeze or 3
			p_u_88.burst("Impact", p205, v_u_10, 0.7)
			local v208 = (v_u_161[p_u_204] or 0) + 1
			v_u_161[p_u_204] = v208
			if v208 == 1 then
				task.delay(v207 + 1, function()
					-- upvalues: (ref) v_u_161, (copy) p_u_204
					v_u_161[p_u_204] = nil
				end)
			end
			if v208 > 6 then
				p_u_88.pop(p205, v_u_9, 1, 3.5, 0.2, 0.3)
			else
				v_u_137(p_u_204, p205, p206, v207)
			end
		end
	}
	local v_u_209 = {}
	v160.grave_rinne_r = {
		["loopSound"] = "Vortex",
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p210) -- name: cast
			-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_13
			p_u_88.skillCast(p210, v_u_10, true)
			p_u_88.burst("Flash", p210.eye, v_u_10, 0.45)
			p_u_88.sigil(p_u_88.facing(p210.eye + p210.dir * 1.8, p210.dir), 3.2 * p210.size, v_u_13, p_u_88.iris("grave_rinne"), 0.35, 2)
		end,
		["windup"] = function(p_u_211, p212, p213) -- name: windup
			-- upvalues: (copy) p_u_88, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4, (ref) v_u_10, (ref) v_u_81, (ref) v_u_87, (copy) v_u_209
			local v214 = p_u_211.ability.radius
			local v215 = p_u_88.ground(p212, 0)
			local v216 = p_u_211.ability.duration or 2.4
			p_u_88.mark(p212, v_u_8, v214 * 0.95, p213 + v216 + 0.8, v_u_6.CrackLines, 0)
			v_u_4.ring(v215, v_u_10, v214, 0.3, v_u_6.Ring)
			p_u_88.burst("Smoke", p_u_88.ground(p212, 1), nil, v214 / 8)
			local v_u_217 = v_u_81(CFrame.lookAt(v215, v215 + p_u_211.dir), v214 * 0.42, p213 + v216 + 3)
			v_u_87(v_u_217, 0)
			v_u_209[p_u_211] = v_u_217
			task.delay(p213 + 1, function()
				-- upvalues: (ref) v_u_209, (copy) p_u_211, (copy) v_u_217
				if v_u_209[p_u_211] == v_u_217 then
					v_u_209[p_u_211] = nil
					for _, v218 in v_u_217.doors do
						v218.slab:Destroy()
						v218.seam:Destroy()
					end
				end
			end)
		end,
		["zone"] = function(p219, p_u_220, p_u_221) -- name: zone
			-- upvalues: (copy) p_u_88, (copy) v_u_209, (ref) v_u_81, (ref) v_u_12, (ref) v_u_1, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_20, (ref) v_u_87, (ref) v_u_35
			local v_u_222 = p219.ability.radius
			local v223 = p219.lite
			local v_u_224 = p219.ability.tick or 0.4
			local v_u_225 = p_u_88.ground(p_u_220, 0)
			local v_u_226 = v_u_222 * 0.42
			local v_u_227 = v_u_209[p219] or v_u_81(CFrame.lookAt(v_u_225, v_u_225 + p219.dir), v_u_226, p_u_221 + 3)
			v_u_209[p219] = nil
			local v_u_228 = p_u_88.plate(p_u_88.ground(p_u_220, 0.05), v_u_226 * 1.05, v_u_12, 0, Enum.Material.SmoothPlastic)
			v_u_1:AddItem(v_u_228, p_u_221 + 2)
			p_u_88.sigil(CFrame.new(p_u_88.ground(p_u_220, 0.1)), v_u_226 * 1.05, v_u_10, v_u_6.Swirl, p_u_221, -4)
			p_u_88.sigil(CFrame.new(p_u_88.ground(p_u_220, 0.14)), v_u_222, v_u_10, v_u_6.Ring, p_u_221, 0.9)
			p_u_88.sigil(CFrame.new(p_u_88.ground(p_u_220, 0.16)), v_u_222 * 0.76, v_u_7, v_u_6.Ring, p_u_221, -1.4)
			local v229 = v223 and 4 or 8
			local v_u_230 = {}
			for v231 = 1, v229 do
				local v232 = (v231 - 0.5) / v229 * 3.141592653589793 * 2
				local v233 = math.cos(v232)
				local v234 = math.sin(v232)
				local v235 = Vector3.new(v233, 0, v234)
				local v236 = v231 % 2 * 1.6 + 4
				local v237 = v_u_225 + v235 * v_u_222 * 0.9
				local v238 = CFrame.lookAt(v237, v237 + v235) * CFrame.Angles(1.2217304763960306, 0, 0)
				local v239 = v_u_4.part(Vector3.new(1, 1, v236), v238, v_u_8, {
					["material"] = Enum.Material.Slate
				})
				v_u_1:AddItem(v239, p_u_221 + 2)
				table.insert(v_u_230, {
					["p"] = v239,
					["cf"] = v238,
					["h"] = v236
				})
			end
			local v_u_240 = {}
			for v241 = 1, v223 and 4 or 10 do
				local v242 = p_u_88.ball(v_u_225, v_u_9, 0.9, 1)
				p_u_88.streak(v242, v_u_9, v_u_7, 0.7, 0.4)
				local v243 = {
					["p"] = nil,
					["trail"] = nil,
					["phase"] = nil,
					["a0"] = nil,
					["last"] = 0,
					["p"] = v242
				}
				local v244 = v242:FindFirstChildWhichIsA("Trail")
				if not (v244 and v244:IsA("Trail")) then
					v244 = nil
				end
				v243.trail = v244
				v243.phase = v241 / (v223 and 4 or 10)
				v243.a0 = math.random() * 3.141592653589793 * 2
				table.insert(v_u_240, v243)
			end
			local v_u_245 = {}
			if not v223 then
				for v246 = 1, 2 do
					local v247, v248 = v_u_20(v_u_10, p_u_221 + 2)
					local v249 = {
						["p"] = v247,
						["decals"] = v248,
						["phase"] = v246 / 2
					}
					table.insert(v_u_245, v249)
				end
			end
			local v_u_250 = {}
			if not v223 then
				local v251 = p_u_88.loopAt
				local v252 = p_u_88.ground(p_u_220, 0.2)
				local v253 = v_u_10
				table.insert(v_u_250, v251("Fire", v252, v253, 1.6))
			end
			p_u_88.burst("Flash", p_u_88.ground(p_u_220, 2), v_u_10, 0.6)
			local v_u_254 = os.clock()
			local v_u_255 = nil
			local v_u_256 = 0
			p_u_88.runNow(function()
				-- upvalues: (copy) v_u_254, (ref) v_u_255, (ref) v_u_87, (copy) v_u_227, (ref) v_u_256, (copy) v_u_224, (ref) v_u_35, (ref) p_u_88, (copy) p_u_220, (ref) v_u_10, (copy) v_u_222, (copy) v_u_226, (copy) v_u_230, (copy) v_u_240, (copy) v_u_225, (copy) v_u_245, (copy) v_u_228, (copy) p_u_221
				local v257 = os.clock()
				local v258 = v257 - v_u_254
				local v259 = v258 / 0.28
				local v260 = math.clamp(v259, 0, 1)
				local v261 = 1 - (1 - v260) ^ 3
				local v262 = v260 * 3.141592653589793
				local v263 = v261 + math.sin(v262) * 0.08
				local v264
				if v_u_255 then
					local v265 = (v257 - v_u_255) / 0.12
					v264 = math.clamp(v265, 0, 1)
				else
					v264 = 0
				end
				v_u_87(v_u_227, v263 * (1 - v264 * v264))
				if not v_u_255 and v_u_256 <= v258 then
					v_u_256 = v_u_256 + v_u_224
					v_u_35(p_u_88.ground(p_u_220, 0.3), v_u_10, v_u_222 * 1.2, v_u_226, 0.32)
				end
				local v266 = v260 * 1.4
				local v267 = math.min(v266, 1) * (1 - v264)
				for _, v268 in v_u_230 do
					v268.p.CFrame = v268.cf * CFrame.new(0, 0, -v268.h * 0.5 * v267 + v268.h * 0.5 * (1 - v267))
				end
				for _, v269 in v_u_240 do
					local v270 = (v258 * 0.75 + v269.phase) % 1
					local v271 = v269.trail
					if v271 then
						v271.Enabled = v269.last <= v270
						if v270 < v269.last then
							v271:Clear()
						end
					end
					v269.last = v270
					local v272 = v269.a0 + v258 * 3.4 + v270 * 2
					local v273 = v_u_226 * 0.8 * (1 - 0.55 * v270)
					local v274 = v258 * 3 + v269.a0
					local v275 = v273 + math.sin(v274) * 0.4
					local v276 = v_u_225
					local v277 = math.cos(v272) * v275
					local v278 = 0.6 + v270 * 15
					local v279 = math.sin(v272) * v275
					local v280 = v276 + Vector3.new(v277, v278, v279)
					v269.p.CFrame = CFrame.new(v280:Lerp(p_u_88.ground(p_u_220, 0.5), v264))
					local v281 = v269.p
					local v282 = 1 - v270 / 0.1
					local v283 = (v270 - 0.8) / 0.2
					v281.Transparency = math.max(v282, v283, 0)
				end
				for _, v284 in v_u_245 do
					local v285 = (v258 * 0.6 + v284.phase) % 1
					local v286 = v_u_226 * 2 * (1 - 0.55 * v285)
					v284.p.Size = Vector3.new(v286, 0.05, v286)
					local v287 = v284.p
					local v288 = CFrame.new
					local v289 = v_u_225
					local v290 = 0.3 + v285 * 12
					v287.CFrame = v288(v289 + Vector3.new(0, v290, 0))
					for _, v291 in v284.decals do
						v291.Transparency = v_u_255 and 1 or 0.15 + 0.85 * v285
					end
				end
				if not v_u_255 or v264 < 1 then
					return v258 < p_u_221 + 2
				end
				for _, v292 in v_u_240 do
					v292.p:Destroy()
				end
				for _, v293 in v_u_245 do
					v293.p:Destroy()
				end
				for _, v294 in v_u_230 do
					v294.p:Destroy()
				end
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_227, (ref) p_u_88, (ref) v_u_228
					for _, v295 in v_u_227.doors do
						local v296 = v295.slab
						p_u_88.fadeOut(v296, 0.35)
						local v297 = v295.seam
						p_u_88.fadeOut(v297, 0.35)
					end
					local v298 = v_u_228
					p_u_88.fadeOut(v298, 0.35)
				end)
				return false
			end)
			return function()
				-- upvalues: (ref) v_u_255, (copy) v_u_250
				v_u_255 = os.clock()
				for _, v299 in v_u_250 do
					v299()
				end
			end
		end,
		["finish"] = function(p300, p301) -- name: finish
			-- upvalues: (copy) p_u_88, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (copy) v_u_109, (ref) v_u_8, (ref) v_u_5
			local v302 = p300.ability.radius
			local v303 = p300.lite
			local v304 = p_u_88.ground(p301)
			p_u_88.pop(p_u_88.ground(p301, 2), v_u_9, 3, v302 * 1.3, 0.28, 0.3)
			p_u_88.burst("Explosion", p_u_88.ground(p301, 2), v_u_10, v302 / 7)
			p_u_88.burst("Shockwave", v304 + Vector3.new(0, 0.3, 0), v_u_7, v302 / 14)
			p_u_88.burst("Smoke", p_u_88.ground(p301, 1.5), nil, v302 / 6)
			v_u_4.ring(v304, v_u_10, v302 * 1.4, 0.55)
			v_u_4.ring(v304, v_u_9, v302 * 1.2, 0.45, v_u_6.SpeedLines)
			p_u_88.spikes(p_u_88.ground(p301, 2), v_u_9, v303 and 5 or 12, v302 * 1.3, 0.4, Vector3.new(0, 1, 0), 0.9)
			if not v303 then
				v_u_109(p_u_88.ground(p301, 1), 6, 16, 5, 0.9)
			end
			p_u_88.chunks(p_u_88.ground(p301, 1), { v_u_8, p_u_88.EARTH[2], v_u_7 }, v303 and 5 or 12, 44, 1.3, 1.1)
			p_u_88.mark(p301, v_u_10, v302 * 0.7, 1.6, v_u_6.CrackGlow, 0.15)
			v_u_5.play("Explosion", {
				["at"] = v304
			})
			v_u_5.play("Crit", {
				["at"] = v304,
				["volume"] = p300.mine and 0.8 or 0.5
			})
			if p300.mine then
				v_u_4.shake(0.55, 0.45)
			end
		end,
		["hit"] = function(_, p305, _) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_10, (ref) v_u_9
			p_u_88.burst("Impact", p305, v_u_10, 0.7)
			p_u_88.pop(p305, v_u_9, 0.8, 2.8, 0.15, 0.35)
		end
	}
	return v160
end