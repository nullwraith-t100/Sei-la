local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(255, 170, 225)
local v_u_6 = Color3.fromRGB(255, 110, 200)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = CFrame.Angles(-1.5707963267948966, 0, 0)
local function v_u_16(p9) -- name: piece
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_2
	local v10 = v_u_1:FindFirstChild("EyePieces")
	if v10 then
		v10 = v10:FindFirstChild("w6_kyoka_suigetsu")
	end
	if not (v10 and v10:IsA("MeshPart")) then
		return nil
	end
	local v11 = v10:Clone()
	v11.Anchored = true
	v11.CanCollide = false
	v11.CanQuery = false
	v11.CanTouch = false
	v11.CastShadow = false
	v11.Massless = true
	local v12 = v10.Size.X
	local v13 = v10.Size.Y
	local v14 = v10.Size.Z
	local v15 = math.max(v12, v13, v14, 0.01)
	v11.Size = v10.Size * (p9 / v15)
	if not v11:FindFirstChildOfClass("SurfaceAppearance") then
		v11.Color = v_u_5
		v11.Material = Enum.Material.Glass
		v11.Transparency = 0.1
	end
	v11.Parent = v_u_2.folder()
	return v11
end
local function v_u_20(p17, p18) -- name: setAlpha
	for _, v19 in p17:GetChildren() do
		if not v19:IsA("Decal") then
			continue
		end
		v19.Transparency = p18
	end
end
return function(p_u_21)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_8, (copy) v_u_6, (copy) v_u_16, (copy) v_u_5, (copy) v_u_7, (copy) v_u_20
	return {
		["w6_kyoka_suigetsu"] = function(p_u_22, p23)
			-- upvalues: (ref) v_u_2, (copy) p_u_21, (ref) v_u_4, (ref) v_u_3, (ref) v_u_8, (ref) v_u_6, (ref) v_u_16, (ref) v_u_5, (ref) v_u_7, (ref) v_u_20
			local v_u_24 = v_u_2.color(p23.color)
			local v25 = p_u_22.headY / 1.5
			local v_u_26 = math.clamp(v25, 0.7, 3)
			local v_u_27 = 0
			local v_u_28 = 1
			local v_u_29 = 0
			local v_u_30 = nil
			local v_u_33 = p_u_21.throb(p_u_22, 5, 2.2, 1.3, function(p31)
				-- upvalues: (ref) v_u_2, (ref) p_u_21, (copy) p_u_22, (copy) v_u_24, (ref) v_u_4, (ref) v_u_30, (ref) v_u_3
				v_u_2.ring(p_u_21.feetAt(p_u_22, p31, 0.15), v_u_24, 5.5 * p_u_22.fx, 0.5, v_u_4.Ring)
				local v32 = v_u_30
				if v32 then
					v32:Emit(v_u_3.level() <= 1 and 3 or 8)
				end
			end)
			local v34 = p_u_22.ticks
			local function v38(_, _, p35)
				-- upvalues: (copy) v_u_33, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29
				local v36 = v_u_33()
				if v_u_27 + 0.5 < v36 then
					v_u_28 = 0
				end
				v_u_27 = v36
				local v37 = v_u_28 + p35 * 2.2
				v_u_28 = math.min(v37, 1)
				v_u_29 = v_u_29 + p35 * (0.5 + 5 * v36)
			end
			table.insert(v34, v38)
			local v_u_58 = p_u_21.group(p_u_22, function(p39, p40)
				-- upvalues: (copy) v_u_26, (ref) p_u_21, (ref) v_u_28
				local v41 = CFrame.new
				local v42 = v_u_26 * 1.95
				local v43 = v_u_26 * 1.35
				local v44 = p40 * 1.4
				local v45 = (p39 * v41(v42, v43 + math.sin(v44) * 0.12 * v_u_26, v_u_26 * 0.35)).Position
				local v46 = p_u_21.camPos() - v45
				local v47 = v46.X
				local v48 = v46.Z
				local v49 = Vector3.new(v47, 0, v48)
				local v50
				if v49.Magnitude > 0.05 then
					v50 = v49.Unit
				else
					v50 = p39.LookVector
				end
				local v51 = CFrame.lookAt(v45, v45 + v50)
				local v52 = CFrame.Angles
				local v53 = p40 * 1.1
				local v54 = math.sin(v53) * 0.07
				local v55 = v_u_28 - 1
				local v56 = (v55 * 2.8 * v55 * v55 + 1 + v55 * 1.8 * v55) * 3.141592653589793 * 2
				local v57 = p40 * 0.8
				return v51 * v52(v54, v56, math.sin(v57) * 0.09)
			end)
			local v59 = p_u_21.picture(v_u_26 * 3.2, v_u_4.Glow, v_u_24, 0.45)
			p_u_21.add(p_u_22, v59, function()
				-- upvalues: (copy) v_u_58, (copy) v_u_26, (ref) v_u_8
				return v_u_58.cf * CFrame.new(0, 0, v_u_26 * 0.3) * v_u_8
			end)
			local v60 = p_u_21.picture(v_u_26 * 2.5, v_u_4.Swirl, v_u_6, 0.2)
			p_u_21.add(p_u_22, v60, function()
				-- upvalues: (copy) v_u_58, (copy) v_u_26, (ref) v_u_8, (ref) v_u_29
				return v_u_58.cf * CFrame.new(0, 0, v_u_26 * 0.22) * v_u_8 * CFrame.Angles(0, -v_u_29, 0)
			end)
			local v61 = v_u_16(v_u_26 * 2.1)
			local v_u_62
			if v61 then
				v_u_62 = v61:FindFirstChildOfClass("SurfaceAppearance")
			else
				v_u_62 = nil
			end
			local v_u_63 = not v_u_62 and 0 or v_u_62.EmissiveStrength
			if v61 then
				p_u_21.add(p_u_22, v61, function()
					-- upvalues: (copy) v_u_58
					return v_u_58.cf
				end)
			else
				local v64 = p_u_21.picture(v_u_26 * 1.5, v_u_4.Glow, v_u_5, 0)
				p_u_21.add(p_u_22, v64, function()
					-- upvalues: (copy) v_u_58, (ref) v_u_8
					return v_u_58.cf * v_u_8
				end)
				local v65 = p_u_21.picture(v_u_26 * 1.75, v_u_4.Ring, v_u_24, 0)
				p_u_21.add(p_u_22, v65, function()
					-- upvalues: (copy) v_u_58, (copy) v_u_26, (ref) v_u_8
					return v_u_58.cf * CFrame.new(0, 0, v_u_26 * -0.02) * v_u_8
				end)
				local v66 = p_u_21.picture(v_u_26 * 1.45, v_u_4.KyokaCrack, v_u_7, 0.2)
				p_u_21.add(p_u_22, v66, function()
					-- upvalues: (copy) v_u_58, (copy) v_u_26, (ref) v_u_8
					return v_u_58.cf * CFrame.new(0, 0, v_u_26 * -0.04) * v_u_8
				end)
			end
			local v_u_67 = p_u_21.picture(1, v_u_4.KyokaCrack, v_u_5, 1)
			p_u_21.add(p_u_22, v_u_67, function()
				-- upvalues: (copy) v_u_58, (copy) v_u_26, (ref) v_u_8
				return v_u_58.cf * CFrame.new(0, 0, v_u_26 * -0.3) * v_u_8
			end)
			local v_u_68 = -1
			local v69 = p_u_22.ticks
			local function v74()
				-- upvalues: (ref) v_u_27, (ref) v_u_68, (copy) v_u_26, (copy) v_u_67, (ref) v_u_20, (copy) v_u_62, (copy) v_u_63
				local v70 = v_u_27 - v_u_68
				if math.abs(v70) >= 0.01 then
					v_u_68 = v_u_27
					local v71 = 1 - v_u_27
					local v72 = v_u_27 > 0.01
					local v73 = not v72 and 0.2 or (math.sqrt(v71) * 4.2 + 1.2) * v_u_26
					v_u_67.Size = Vector3.new(v73, 0.05, v73)
					v_u_20(v_u_67, not v72 and 1 or v71 * 0.95 * v71 + 0.05)
					if v_u_62 then
						v_u_62.EmissiveStrength = v_u_63 * (v_u_27 * 2.5 + 1)
					end
				end
			end
			table.insert(v69, v74)
			local v_u_75 = v_u_27
			for v_u_76 = 1, 5 do
				local v77 = (v_u_76 % 3 * 0.15 + 0.8) * v_u_26
				local v78 = p_u_21.bar
				local v79 = v_u_26 * 0.06
				local v80 = v77 * 0.6
				local v_u_81 = v78(Vector3.new(v79, v77, v80), v_u_6, 0.2)
				v_u_81.Shape = Enum.PartType.Wedge
				local v82 = CFrame.Angles
				local v83 = v_u_76 * 1.7
				local v84 = math.cos(v83) * 0.45
				local v85 = v_u_76 * 1.26
				local v86 = v_u_76 * 2.3
				local v_u_87 = v82(v84, v85, math.sin(v86) * 0.4)
				local v_u_88 = v_u_76 * 0.17 + 0.9
				local v_u_89 = (v_u_76 % 3 * 0.4 + 0.1) * v_u_26
				p_u_21.add(p_u_22, v_u_81, function(p90, p91)
					-- upvalues: (copy) v_u_88, (copy) v_u_76, (ref) v_u_75, (copy) v_u_26, (copy) v_u_89, (copy) v_u_87, (ref) p_u_21, (copy) v_u_81, (ref) v_u_6, (ref) v_u_7
					local v92 = p91 * v_u_88 + v_u_76 * 3.141592653589793 * 2 / 5
					local v93 = (v_u_75 * 1.6 + 2.3) * v_u_26
					local v94 = v_u_89
					local v95 = CFrame.new(p90.Position + Vector3.new(0, v94, 0)) * v_u_87 * CFrame.new(math.cos(v92) * v93, 0, math.sin(v92) * v93)
					local v96 = CFrame.new(v95.Position) * CFrame.Angles(p91 * 1.3 + v_u_76, p91 * 2.1 + v_u_76 * 2, 0)
					local v97 = p_u_21.camPos() - v96.Position
					local v98
					if v97.Magnitude > 0.01 then
						local v99 = v96.RightVector:Dot(v97.Unit)
						v98 = math.abs(v99)
					else
						v98 = 0
					end
					local v100 = v_u_81
					local v101 = v_u_6
					local v102 = v_u_7
					local v103 = (v98 - 0.8) * 5
					v100.Color = v101:Lerp(v102, (math.clamp(v103, 0, 1)))
					return v96
				end)
			end
			local v104 = p_u_21.ball(0.1, v_u_24, 1)
			p_u_21.add(p_u_22, v104, function()
				-- upvalues: (copy) v_u_58
				return CFrame.new(v_u_58.cf.Position)
			end)
			local v105 = Instance.new("ParticleEmitter")
			v105.Texture = "rbxassetid://76741008972969"
			v105.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v105.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v105.Color = ColorSequence.new(v_u_7, v_u_5)
			v105.LightEmission = 0.8
			v105.LightInfluence = 0
			v105.Lifetime = NumberRange.new(0.4, 0.7)
			v105.Size = NumberSequence.new(v_u_26 * 0.6 * p_u_22.fx, v_u_26 * 0.2 * p_u_22.fx)
			v105.Speed = NumberRange.new(1.5 * p_u_22.fx, 4 * p_u_22.fx)
			v105.SpreadAngle = Vector2.new(180, 180)
			v105.Drag = 3
			v105.Rate = 3 * v_u_3.formRate()
			v105.Parent = v104
			v_u_30 = v105
			p_u_21.particles(p_u_22, "AuraMode", v_u_24, {
				["rate"] = 0.3,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_21.particles(p_u_22, "Petals", v_u_6, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end