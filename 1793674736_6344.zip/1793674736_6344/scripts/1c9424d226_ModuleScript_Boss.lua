local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.BossCoins)
local v_u_6 = require(script.Parent.BossFx)
local v_u_7 = require(script.Parent.BossHud)
local v_u_8 = require(script.Parent.BossShop)
local v_u_9 = require(script.Parent.Enemies)
local v_u_10 = require(script.Parent.KuramaRig)
local v_u_11 = require(script.Parent.Numbers)
local v_u_12 = require(script.Parent.Revive)
local v_u_13 = require(script.Parent.Sfx)
local v_u_14 = require(v_u_2.Shared.Config.Release)
local v_u_15 = require(v_u_2.Shared.Logic.Boss)
local v16 = {}
local v_u_17 = v1.LocalPlayer
local v_u_18 = v_u_15.CENTRE
local v_u_19 = nil
local v_u_20 = false
local v_u_21 = nil
local v_u_22 = -1
local v_u_23 = false
local v_u_24 = 0
local v_u_25 = 0
local v_u_26 = v_u_18.X
local v_u_27 = v_u_18.Z
local v_u_28 = v_u_18.X
local v_u_29 = v_u_18.Z
local v_u_30 = nil
local v_u_31 = 0
local v_u_32 = 0
local v_u_33 = 0
local v_u_34 = 0
local v_u_35 = 0
local v_u_36 = nil
local v_u_37 = false
local function v_u_63() -- name: keepRig
	-- upvalues: (copy) v_u_4, (ref) v_u_37, (copy) v_u_18, (copy) v_u_10, (copy) v_u_6, (ref) v_u_22, (ref) v_u_21, (ref) v_u_23, (ref) v_u_25, (ref) v_u_24, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (ref) v_u_27, (ref) v_u_30, (copy) v_u_15
	local v38 = v_u_4:GetAttribute("BossPhase")
	local v39 = type(v38) ~= "string" and "wait" or v38
	local v40 = v_u_4:GetAttribute("BossAt")
	local v41 = type(v40) ~= "number" and 0 or v40
	if v39 == "coming" and not v_u_37 then
		local v42 = v_u_4.CurrentCamera
		local v43
		if v42 then
			local v44 = v42.Focus.Position
			v43 = Vector2.new(v44.X - v_u_18.X, v44.Z - v_u_18.Z).Magnitude <= 650
		else
			v43 = false
		end
		if v43 then
			v_u_37 = true
			v_u_10.length("idle")
			v_u_6.warm()
		end
	end
	local v45
	if v39 == "fight" or v39 == "over" then
		local v46 = v_u_4.CurrentCamera
		if v46 then
			local v47 = v46.Focus.Position
			v45 = Vector2.new(v47.X - v_u_18.X, v47.Z - v_u_18.Z).Magnitude <= 650
		else
			v45 = false
		end
	else
		v45 = false
	end
	if v39 == "over" and v_u_22 ~= v41 then
		v45 = false
	end
	if v45 then
		if not v_u_21 or v_u_22 ~= v41 then
			local v48 = v_u_21
			v_u_21 = nil
			v_u_22 = -1
			v_u_23 = false
			if v48 then
				v48:destroy()
			end
			local v49 = v_u_4:GetAttribute("BossYaw")
			v_u_25 = type(v49) ~= "number" and 0 or v49
			v_u_24 = v_u_25
			local v50 = v_u_18.X
			local v51 = v_u_4:GetAttribute("BossX")
			if type(v51) ~= "number" then
				v51 = v50
			end
			local v52 = v_u_18.Z
			local v53 = v_u_4:GetAttribute("BossZ")
			if type(v53) == "number" then
				v52 = v53
			end
			v_u_28 = v51
			v_u_29 = v52
			local v54 = v_u_29
			v_u_26 = v_u_28
			v_u_27 = v54
			v_u_30 = nil
			local v55 = v_u_24
			local v56 = v_u_10.build(CFrame.new(v_u_26, v_u_18.Y, v_u_27) * CFrame.Angles(0, v55, 0), v_u_15.HEIGHT)
			v_u_21 = v56
			v_u_22 = v41
			local v57 = v_u_4:GetServerTimeNow() - v41
			if v57 < v_u_15.ENTRANCE then
				local v58 = v_u_15.ENTRANCE_SPEED
				v56:play("intro", {
					["at"] = math.max(v57, 0) * v58,
					["speed"] = v58
				})
				if v57 < 0.5 / v58 then
					v_u_6.intro(v56, v58)
				end
			end
			local v59 = v_u_4:GetAttribute("BossPhase")
			local v60
			if (type(v59) ~= "string" and "wait" or v59) == "fight" then
				local v61 = v_u_4:GetAttribute("BossHp")
				v60 = (type(v61) ~= "number" and 1 or v61) < v_u_15.ENRAGE
			else
				v60 = false
			end
			if v60 then
				v_u_6.glow(v56)
			end
		end
	else
		if v_u_21 and not v_u_23 then
			local v62 = v_u_21
			v_u_21 = nil
			v_u_22 = -1
			v_u_23 = false
			if v62 then
				v62:destroy()
			end
		end
		return
	end
end
local function v_u_68(p64) -- name: onEnd
	-- upvalues: (ref) v_u_21, (ref) v_u_23, (copy) v_u_6, (ref) v_u_22, (copy) v_u_15
	local v_u_65 = v_u_21
	if v_u_65 and not v_u_23 then
		v_u_23 = true
		if p64 then
			v_u_65:play("death", {
				["fade"] = 0.15
			})
			v_u_6.fall(v_u_65)
		else
			v_u_65:play("roar")
			v_u_6.escape(v_u_65)
		end
		local v_u_66 = v_u_22
		task.delay(v_u_15.RESULTS - 0.5, function()
			-- upvalues: (ref) v_u_21, (copy) v_u_65, (ref) v_u_22, (copy) v_u_66, (ref) v_u_23
			if v_u_21 == v_u_65 and v_u_22 == v_u_66 then
				local v67 = v_u_21
				v_u_21 = nil
				v_u_22 = -1
				v_u_23 = false
				if v67 then
					v67:destroy()
				end
			end
		end)
	end
end
local function v_u_80(p69) -- name: shapesFrom
	local v70 = {}
	if type(p69) ~= "table" then
		return v70
	end
	for _, v71 in p69 do
		if type(v71) ~= "table" then
			continue
		end
		local v72 = v71.kind
		local v73 = v71.x
		local v74 = v71.z
		local v75 = v71.radius
		if v72 ~= "circle" and (v72 ~= "ring" and v72 ~= "cone") or (type(v73) ~= "number" or (type(v74) ~= "number" or type(v75) ~= "number")) then
			continue
		end
		local v76 = v71.inner
		local v77 = v71.yaw
		local v78 = v71.half
		local v79 = {
			["kind"] = v72,
			["x"] = v73,
			["z"] = v74,
			["radius"] = v75
		}
		if type(v76) ~= "number" then
			v76 = nil
		end
		v79.inner = v76
		if type(v77) ~= "number" then
			v77 = nil
		end
		v79.yaw = v77
		if type(v78) ~= "number" then
			v78 = nil
		end
		v79.half = v78
		table.insert(v70, v79)
	end
	return v70
end
local function v_u_123(p81) -- name: onAttack
	-- upvalues: (copy) v_u_15, (copy) v_u_80, (ref) v_u_25, (copy) v_u_4, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (ref) v_u_27, (ref) v_u_30, (copy) v_u_6, (copy) v_u_18, (copy) v_u_13, (ref) v_u_21, (ref) v_u_23
	local v82 = p81.k
	for v83 = 1, #v_u_15.ALL do
		v_u_84 = v_u_15.ALL[v83]
		if v_u_84 ~= v82 then
			continue
		end
	end
	local v_u_84 = nil
	local v85 = p81.hit
	local v86 = p81.s
	local v87 = p81.yaw
	if v_u_84 and type(v85) == "number" then
		local v_u_88 = v_u_80(p81.sh)
		if type(v87) == "number" then
			v_u_25 = v87
		end
		local v_u_89 = type(v86) ~= "number" and 1 or math.clamp(v86, 0.5, 3)
		local v90 = v85 - v_u_4:GetServerTimeNow()
		local v91 = math.max(v90, 0.05)
		local v_u_92 = p81.x
		local v_u_93 = p81.z
		if type(v_u_92) == "number" and type(v_u_93) == "number" then
			v_u_28 = v_u_92
			v_u_29 = v_u_93
		end
		local v94 = p81.tx
		local v95 = p81.tz
		local v96 = p81.launch
		if v_u_84 == "leap" and (type(v94) == "number" and (type(v95) == "number" and type(v96) == "number")) then
			if type(v_u_92) ~= "number" then
				v_u_92 = v_u_26
			end
			if type(v_u_93) ~= "number" then
				v_u_93 = v_u_27
			end
			v_u_30 = {
				["fromX"] = v_u_92,
				["fromZ"] = v_u_93,
				["toX"] = v94,
				["toZ"] = v95,
				["launch"] = v96,
				["land"] = v85
			}
			local v97 = task.delay
			local v98 = v96 - v_u_4:GetServerTimeNow()
			v97(math.max(v98, 0), function()
				-- upvalues: (ref) v_u_4, (ref) v_u_6, (copy) v_u_92, (ref) v_u_18, (copy) v_u_93
				local v99 = v_u_4:GetAttribute("BossPhase")
				if (type(v99) ~= "string" and "wait" or v99) == "fight" then
					local v100 = v_u_6.leapOff
					local v101 = v_u_92
					local v102 = v_u_18.Y
					local v103 = v_u_93
					v100((Vector3.new(v101, v102, v103)))
				end
			end)
		end
		v_u_6.warn(v_u_88, v91)
		if v_u_84 == "fox_rain" then
			v_u_13.play("KyubiHowl")
			v_u_6.rain(v_u_88, v91)
		elseif v_u_84 == "claw_left" or v_u_84 == "claw_right" then
			local v104 = task.delay
			local v105 = v91 - 0.3
			v104(math.max(v105, 0), function()
				-- upvalues: (ref) v_u_4, (ref) v_u_13
				local v106 = v_u_4:GetAttribute("BossPhase")
				if (type(v106) ~= "string" and "wait" or v106) == "fight" then
					v_u_13.play("KyubiClaw")
				end
			end)
		end
		local v_u_107 = v_u_21
		local v108 = v_u_15.ATTACKS[v_u_84]
		if v_u_107 then
			if v_u_84 == "bomb" then
				local v109 = (v_u_107:marker("bomb_fire", "hit") or 0.35) / v_u_89
				local v110 = v91 - v109
				local v111 = math.max(v110, 0.1)
				v_u_107:play("bomb_charge", {
					["speed"] = v_u_89
				})
				local v112 = v_u_88[1]
				local v113
				if v112 then
					local v114 = v112.x
					local v115 = v_u_18.Y
					local v116 = v112.z
					v113 = Vector3.new(v114, v115, v116)
				else
					local v117 = v_u_26
					local v118 = v_u_18.Y
					local v119 = v_u_27
					v113 = Vector3.new(v117, v118, v119)
				end
				v_u_6.bomb(v_u_107, v113, v111, v109)
				task.delay(v111, function()
					-- upvalues: (ref) v_u_21, (copy) v_u_107, (ref) v_u_23, (copy) v_u_89
					if v_u_21 == v_u_107 and not v_u_23 then
						v_u_107:play("bomb_fire", {
							["speed"] = v_u_89
						})
					end
				end)
			else
				local v120 = (v_u_107:marker(v108.clip, "hit") or v108.windup) / v91
				local v121 = {
					["speed"] = math.max(v_u_89, v120)
				}
				v_u_107:play(v108.clip, v121)
			end
		end
		task.delay(v91, function()
			-- upvalues: (ref) v_u_4, (ref) v_u_6, (copy) v_u_84, (copy) v_u_88, (ref) v_u_21, (ref) v_u_25
			local v122 = v_u_4:GetAttribute("BossPhase")
			if (type(v122) ~= "string" and "wait" or v122) == "fight" then
				v_u_6.land(v_u_84, v_u_88, v_u_21, v_u_25)
			end
		end)
	end
end
local function v_u_142(p124) -- name: onHit
	-- upvalues: (ref) v_u_21, (ref) v_u_26, (copy) v_u_18, (copy) v_u_15, (ref) v_u_27, (copy) v_u_17, (copy) v_u_11, (copy) v_u_6, (copy) v_u_13, (ref) v_u_23, (ref) v_u_32, (ref) v_u_31
	local v125 = p124.d
	if type(v125) == "number" then
		local v126 = p124.c == true
		local v127 = v_u_21
		local v128
		if v127 then
			v128 = v127:point("chest")
		else
			local v129 = v_u_26
			local v130 = v_u_18.Y + v_u_15.CHEST
			local v131 = v_u_27
			v128 = Vector3.new(v129, v130, v131)
		end
		local v132 = v_u_17.Character
		if v132 then
			v132 = v132:FindFirstChild("HumanoidRootPart")
		end
		if not (v132 and v132:IsA("BasePart")) then
			v132 = nil
		end
		local v133
		if v132 then
			local v134 = v132.Position.X - v128.X
			local v135 = v132.Position.Z - v128.Z
			local v136 = Vector3.new(v134, 0, v135)
			if v136.Magnitude > 1 then
				v133 = v128 + v136.Unit * v_u_15.BODY_RADIUS * 0.6
			else
				v133 = v128
			end
		else
			v133 = v128
		end
		local v137 = (math.random() - 0.5) * 8
		local v138 = (math.random() - 0.5) * 6
		local v139 = (math.random() - 0.5) * 8
		local v140 = v133 + Vector3.new(v137, v138, v139)
		v_u_11.show(v140, v125, v126, 2.6, v_u_15.FOE_ID)
		v_u_6.hitSpark(v140, v126)
		if v126 then
			v_u_13.play("Crit", {
				["at"] = nil,
				["volume"] = 0.8,
				["at"] = v140
			})
		else
			v_u_13.play("Hit", {
				["at"] = nil,
				["volume"] = 0.4,
				["at"] = v140
			})
		end
		local v141 = os.clock()
		if not v_u_23 and v141 - v_u_32 >= 0.7 then
			v_u_32 = v141
			v_u_13.play("KyubiHurt", {
				["at"] = v128
			})
		end
		if v127 and (not v_u_23 and v141 - v_u_31 > 0.7) then
			v_u_31 = v141
			v127:play("flinch")
		end
	end
end
local function v_u_146(p143) -- name: onHurt
	-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) v_u_7, (copy) v_u_17
	v_u_13.play("Hurt", {
		["volume"] = 1
	})
	v_u_6.shake(p143.ko == true and 2 or 1, 0.35)
	v_u_7.hurt(p143.ko == true)
	local v144 = p143.push
	local v145 = v_u_17.Character
	if v145 then
		v145 = v145:FindFirstChild("HumanoidRootPart")
	end
	if not (v145 and v145:IsA("BasePart")) then
		v145 = nil
	end
	if typeof(v144) == "Vector3" and v145 then
		v145.AssemblyLinearVelocity = v144
	end
end
local function v_u_163(p147) -- name: onEvent
	-- upvalues: (copy) v_u_123, (copy) v_u_142, (copy) v_u_146, (ref) v_u_35, (copy) v_u_12, (copy) v_u_13, (copy) v_u_7, (copy) v_u_17, (copy) v_u_6, (copy) v_u_68, (ref) v_u_23, (ref) v_u_21, (copy) v_u_5
	local v148 = p147.t
	if v148 == "atk" then
		v_u_123(p147)
		return
	elseif v148 == "hit" then
		v_u_142(p147)
		return
	elseif v148 == "hurt" then
		v_u_146(p147)
		return
	elseif v148 == "down" then
		v_u_35 = (1 / 0)
		v_u_12.showBoss(p147)
		return
	elseif v148 == "dtime" then
		v_u_12.bossTime(p147)
	elseif v148 == "dend" then
		v_u_35 = 0
		v_u_12.hide()
		if p147.why == "revived" then
			v_u_13.play("LevelUp")
			v_u_7.say("Revived! Back in the fight!")
			local v149 = v_u_17.Character
			if v149 then
				v149 = v149:FindFirstChild("HumanoidRootPart")
			end
			if not (v149 and v149:IsA("BasePart")) then
				v149 = nil
			end
			if v149 then
				v_u_6.revived(v149.Position)
				return
			end
		end
	else
		if v148 == "back" then
			v_u_13.play("LevelUp")
			v_u_7.say("Revived! Back in the fight!")
			return
		end
		if v148 == "saved" then
			v_u_7.say("Boss revive saved: it is FREE the next time Kyubi knocks you out")
			return
		end
		if v148 == "up" then
			v_u_35 = 0
			v_u_7.up()
			return
		end
		if v148 == "end" then
			v_u_68(p147.won == true)
			return
		end
		if v148 == "rage" then
			local v150 = v_u_6.rage
			local v151
			if v_u_23 then
				v151 = nil
			else
				v151 = v_u_21
			end
			v150(v151)
			v_u_7.enraged()
			return
		end
		if v148 == "result" then
			local v152 = p147.coins
			local v153 = type(v152) ~= "number" and 0 or p147.coins
			local v154 = p147.part
			local v155 = type(v154) ~= "number" and 1 or p147.part
			local v156 = p147.dmg
			local v157
			if type(v156) == "number" then
				v157 = p147.dmg
			else
				v157 = nil
			end
			v_u_7.result(p147.won == true, v153, p147.fair == true, v155, v157)
			if v153 > 0 then
				local v158 = v_u_5.won
				local v159 = p147.total
				local v160
				if type(v159) == "number" then
					v160 = p147.total
				else
					v160 = nil
				end
				v158(v153, v160)
				return
			end
		else
			if v148 == "summon" then
				local v161 = p147.name
				v_u_7.summoned(type(v161) ~= "string" and "Someone" or v161)
				return
			end
			if v148 == "deny" then
				local v162 = p147.why
				if type(v162) == "string" and v162 ~= "" then
					v_u_7.say(v162)
				end
			end
		end
	end
end
local function v_u_166(p164) -- name: keepTint
	-- upvalues: (ref) v_u_36
	if p164 and not v_u_36 then
		local v165 = Instance.new("ColorCorrectionEffect")
		v165.Name = "KuramaArena"
		v165.TintColor = Color3.fromRGB(255, 232, 218)
		v165.Saturation = 0.12
		v165.Contrast = 0.1
		v165.Parent = game:GetService("Lighting")
		v_u_36 = v165
	elseif not p164 and v_u_36 then
		v_u_36:Destroy()
		v_u_36 = nil
	end
end
local v_u_167 = false
local function v_u_173(p168) -- name: keepShop
	-- upvalues: (copy) v_u_17, (ref) v_u_35, (copy) v_u_4, (copy) v_u_15, (ref) v_u_167, (copy) v_u_8
	local v169 = v_u_17.Character
	if v169 then
		v169 = v169:FindFirstChild("HumanoidRootPart")
	end
	if not (v169 and v169:IsA("BasePart")) then
		v169 = nil
	end
	local v170
	if p168 and (v169 and v_u_35 <= v_u_4:GetServerTimeNow()) then
		local v171 = Vector2.new(v169.Position.X - v_u_15.SHOP.X, v169.Position.Z - v_u_15.SHOP.Z).Magnitude
		local v172
		if v_u_167 then
			v172 = v_u_15.SHOP_REACH + 3
		else
			v172 = v_u_15.SHOP_REACH
		end
		v170 = v171 <= v172
	else
		v170 = false
	end
	if v170 and not v_u_167 then
		v_u_8.open()
	end
	v_u_167 = v170
end
local v_u_174 = Color3.fromRGB(110, 255, 120)
local v_u_175 = ""
local function v_u_186(p176, p177, p178) -- name: keepSigns
	-- upvalues: (copy) v_u_4, (copy) v_u_15, (ref) v_u_175, (copy) v_u_174
	local v179 = v_u_4:FindFirstChild("BossPortals")
	if v179 then
		local v180 = p176 == "coming" and true or p176 == "fight"
		local v181
		if p176 == "fight" then
			v181 = "FIGHT ON! JOIN"
		elseif p176 == "coming" then
			v181 = "JOIN NOW! " .. v_u_15.clock(p178 - p177)
		else
			v181 = "NEXT FIGHT " .. v_u_15.clock(p178 - p177)
		end
		local v182 = v181 ~= v_u_175
		v_u_175 = v181
		for _, v183 in v179:GetChildren() do
			local v184 = v183:FindFirstChild("Sign")
			if v184 then
				v184 = v184:FindFirstChild("Board")
			end
			if v184 then
				v184 = v184:FindFirstChild("Timer")
			end
			if not v184 or (not v184:IsA("TextLabel") or not v182 and v184.Text == v181) then
				continue
			end
			local v185 = v184:GetAttribute("OwnColor")
			if typeof(v185) ~= "Color3" then
				v184:SetAttribute("OwnColor", v184.TextColor3)
				v185 = v184.TextColor3
			end
			v184.Text = v181
			if v180 then
				v185 = v_u_174
			elseif typeof(v185) ~= "Color3" then
				v185 = Color3.new(1, 1, 1)
			end
			v184.TextColor3 = v185
		end
	end
end
local v_u_187 = nil
local function v_u_192(p188) -- name: keepExit
	-- upvalues: (copy) v_u_4, (ref) v_u_187, (copy) v_u_18, (copy) v_u_6, (copy) v_u_7
	local v189 = v_u_4:FindFirstChild("BossArena")
	if v189 then
		v189 = v189:FindFirstChild("ExitPortal")
	end
	if v189 ~= v_u_187 then
		v_u_187 = v189
		if v189 and p188 then
			local v190 = v_u_4:GetAttribute("BossPhase")
			if (type(v190) ~= "string" and "wait" or v190) == "over" then
				local v191
				if v189:IsA("Model") then
					v191 = v189:GetPivot().Position
				elseif v189:IsA("BasePart") then
					v191 = v189.Position
				else
					v191 = v_u_18
				end
				v_u_6.portal(v191)
				v_u_7.say("A portal home opened where Kyubi fell!")
			end
		end
	end
end
local function v_u_280() -- name: begin
	-- upvalues: (ref) v_u_20, (copy) v_u_2, (ref) v_u_19, (copy) v_u_163, (copy) v_u_12, (copy) v_u_7, (copy) v_u_9, (copy) v_u_17, (copy) v_u_4, (ref) v_u_35, (copy) v_u_18, (copy) v_u_15, (ref) v_u_26, (ref) v_u_27, (copy) v_u_3, (ref) v_u_21, (ref) v_u_23, (ref) v_u_25, (ref) v_u_24, (ref) v_u_30, (ref) v_u_28, (ref) v_u_29, (copy) v_u_6, (ref) v_u_33, (copy) v_u_13, (ref) v_u_34, (copy) v_u_14, (copy) v_u_63, (copy) v_u_166, (copy) v_u_173, (copy) v_u_192, (copy) v_u_186, (ref) v_u_22, (ref) v_u_36
	if v_u_20 then
		return
	else
		v_u_20 = true
		local v193 = v_u_2:WaitForChild("Remotes"):WaitForChild("Boss", 60)
		if v193 and v193:IsA("RemoteEvent") then
			v_u_19 = v193
			v193.OnClientEvent:Connect(function(p194)
				-- upvalues: (ref) v_u_163
				if type(p194) == "table" then
					for _, v195 in p194 do
						if type(v195) ~= "table" then
							continue
						end
						v_u_163(v195)
					end
				end
			end)
			local v198 = {
				["buy"] = function() -- name: buy
					-- upvalues: (ref) v_u_19
					local v196 = v_u_19
					if v196 then
						v196:FireServer("revive")
					end
				end,
				["no"] = function() -- name: no
					-- upvalues: (ref) v_u_19
					local v197 = v_u_19
					if v197 then
						v197:FireServer("home")
					end
				end
			}
			v_u_12.onBoss(v198)
			local v201 = {
				["join"] = function() -- name: join
					-- upvalues: (ref) v_u_19
					local v199 = v_u_19
					if v199 then
						v199:FireServer("join")
					end
				end,
				["leave"] = function() -- name: leave
					-- upvalues: (ref) v_u_19
					local v200 = v_u_19
					if v200 then
						v200:FireServer("leave")
					end
				end
			}
			if not v_u_7.start(v201) then
				warn("[Boss] the HUD pieces to copy were not found")
			end
			v_u_9.addTarget(function()
				-- upvalues: (ref) v_u_17, (ref) v_u_4, (ref) v_u_35, (ref) v_u_18, (ref) v_u_15, (ref) v_u_26, (ref) v_u_27
				local v202 = v_u_17.Character
				if v202 then
					v202 = v202:FindFirstChild("HumanoidRootPart")
				end
				if not (v202 and v202:IsA("BasePart")) then
					v202 = nil
				end
				if v202 then
					local v203 = v_u_4:GetAttribute("BossPhase")
					local v204
					if (type(v203) ~= "string" and "wait" or v203) == "fight" then
						local v205 = v_u_4:GetAttribute("BossHp")
						v204 = (type(v205) ~= "number" and 1 or v205) > 0
					else
						v204 = false
					end
					if v204 and v_u_35 <= v_u_4:GetServerTimeNow() then
						local v206 = v_u_17.Character
						if v206 then
							v206 = v206:FindFirstChild("HumanoidRootPart")
						end
						if not (v206 and v206:IsA("BasePart")) then
							v206 = nil
						end
						local v207
						if v206 then
							local v208 = v206.Position
							local v209 = v208.X - v_u_18.X
							local v210 = v208.Z - v_u_18.Z
							if v209 * v209 + v210 * v210 <= v_u_15.INSIDE_RADIUS * v_u_15.INSIDE_RADIUS then
								local v211 = v208.Y - v_u_18.Y
								v207 = math.abs(v211) < 80
							else
								v207 = false
							end
						else
							v207 = false
						end
						if v207 then
							return {
								["id"] = nil,
								["pos"] = nil,
								["boss"] = true,
								["id"] = v_u_15.FOE_ID,
								["pos"] = v_u_15.aimPoint(v202.Position.X, v202.Position.Z, v_u_26, v_u_27)
							}
						end
					end
				end
				return nil
			end)
			v_u_3.RenderStepped:Connect(function(p212)
				-- upvalues: (ref) v_u_21, (ref) v_u_23, (ref) v_u_25, (ref) v_u_24, (ref) v_u_4, (ref) v_u_30, (ref) v_u_26, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_6, (ref) v_u_18, (ref) v_u_15, (ref) v_u_33, (ref) v_u_13, (ref) v_u_34
				local v213 = v_u_21
				if v213 and not v_u_23 then
					local v214 = (v_u_25 - v_u_24 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
					local v215 = v_u_24
					local v216 = p212 * 6
					v_u_24 = v215 + v214 * math.min(1, v216)
					local v217 = v_u_4:GetServerTimeNow()
					local v218 = v_u_30
					if v218 and v218.land <= v217 then
						v_u_30 = nil
						local v219 = v218.toX
						local v220 = v218.toZ
						v_u_26 = v219
						v_u_27 = v220
					elseif v218 then
						local v221 = v217 - v218.launch
						local v222 = v218.land - v218.launch
						local v223 = v221 / math.max(v222, 0.05)
						local v224 = math.clamp(v223, 0, 1)
						local v225 = v224 * v224 * (3 - v224 * 2)
						v_u_26 = v218.fromX + (v218.toX - v218.fromX) * v225
						v_u_27 = v218.fromZ + (v218.toZ - v218.fromZ) * v225
					else
						local v226 = v_u_28 - v_u_26
						local v227 = v_u_29 - v_u_27
						if v226 * v226 + v227 * v227 > 3600 then
							local v228 = v_u_29
							v_u_26 = v_u_28
							v_u_27 = v228
						else
							local v229 = -p212 * 8
							local v230 = 1 - math.exp(v229)
							v_u_26 = v_u_26 + v226 * v230
							v_u_27 = v_u_27 + v227 * v230
						end
					end
					local v231 = v_u_6.setCentre
					local v232 = v_u_26
					local v233 = v_u_18.Y
					local v234 = v_u_27
					v231((Vector3.new(v232, v233, v234)))
					local v235 = v_u_4:GetAttribute("BossWalk")
					local v236 = type(v235) ~= "number" and 0 or v235
					local v237 = v213:current()
					if v236 > 0.5 and (not v_u_30 and v237 == "idle") then
						local v238 = {
							["speed"] = nil,
							["fade"] = 0.2
						}
						local v239 = v236 / v_u_15.WALK_SPEED
						v238.speed = math.clamp(v239, 0.6, 2)
						v213:play("walk", v238)
					elseif (v236 <= 0.5 or v_u_30) and v237 == "walk" then
						v213:play("idle", {
							["fade"] = 0.3
						})
					end
					local v240 = os.clock()
					if v237 == "walk" and v_u_33 <= v240 then
						local v241 = v236 / v_u_15.WALK_SPEED
						v_u_33 = v240 + 0.6 / math.clamp(v241, 0.6, 2)
						local v242 = v_u_13.play
						local v243 = {}
						local v244 = v_u_26
						local v245 = v_u_18.Y
						local v246 = v_u_27
						v243.at = Vector3.new(v244, v245, v246)
						v242("KyubiStep", v243)
					end
					if v_u_34 <= v240 then
						local v247 = v_u_34 == 0
						v_u_34 = v240 + 7 + math.random() * 6
						if not v247 and (v237 == "idle" or v237 == "walk") then
							v_u_13.play("KyubiGrowl", {
								["at"] = v213:point("head")
							})
						end
					end
					local v248 = v_u_24
					v213:setCFrame(CFrame.new(v_u_26, v_u_18.Y, v_u_27) * CFrame.Angles(0, v248, 0))
				end
			end)
			v_u_4:GetAttributeChangedSignal("BossYaw"):Connect(function()
				-- upvalues: (ref) v_u_25, (ref) v_u_4
				local v249 = v_u_25
				local v250 = v_u_4:GetAttribute("BossYaw")
				if type(v250) ~= "number" then
					v250 = v249
				end
				v_u_25 = v250
			end)
			local function v255() -- name: onPlace
				-- upvalues: (ref) v_u_28, (ref) v_u_29, (ref) v_u_4
				local v251 = v_u_28
				local v252 = v_u_4:GetAttribute("BossX")
				if type(v252) ~= "number" then
					v252 = v251
				end
				local v253 = v_u_29
				local v254 = v_u_4:GetAttribute("BossZ")
				if type(v254) == "number" then
					v253 = v254
				end
				v_u_28 = v252
				v_u_29 = v253
			end
			v_u_4:GetAttributeChangedSignal("BossX"):Connect(v255)
			v_u_4:GetAttributeChangedSignal("BossZ"):Connect(v255)
			task.spawn(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_63, (ref) v_u_17, (ref) v_u_18, (ref) v_u_15, (ref) v_u_166, (ref) v_u_173, (ref) v_u_192, (ref) v_u_4, (ref) v_u_186, (ref) v_u_7, (ref) v_u_35, (ref) v_u_21, (ref) v_u_22, (ref) v_u_23, (ref) v_u_36
				while true do
					if v_u_14.on(2) then
						v_u_63()
						local v256 = v_u_17.Character
						if v256 then
							v256 = v256:FindFirstChild("HumanoidRootPart")
						end
						if not (v256 and v256:IsA("BasePart")) then
							v256 = nil
						end
						local v257
						if v256 then
							local v258 = v256.Position
							local v259 = v258.X - v_u_18.X
							local v260 = v258.Z - v_u_18.Z
							if v259 * v259 + v260 * v260 <= v_u_15.INSIDE_RADIUS * v_u_15.INSIDE_RADIUS then
								local v261 = v258.Y - v_u_18.Y
								v257 = math.abs(v261) < 80
							else
								v257 = false
							end
						else
							v257 = false
						end
						v_u_166(v257)
						v_u_173(v257)
						v_u_192(v257)
						local v262 = v_u_4:GetServerTimeNow()
						local v263 = v_u_4:GetAttribute("BossPhase")
						local v264 = type(v263) ~= "string" and "wait" or v263
						local v265 = v_u_4:GetAttribute("BossAt")
						local v266 = type(v265) ~= "number" and 0 or v265
						local v267 = v_u_4:GetAttribute("BossNext")
						local v268 = type(v267) ~= "number" and 0 or v267
						v_u_186(v264, v262, v268)
						local v269 = v_u_7.step
						local v270 = {
							["now"] = v262,
							["phase"] = v264,
							["nextAt"] = v268,
							["arrivedAt"] = v266
						}
						local v271 = v_u_4:GetAttribute("BossEnd")
						v270.ends = type(v271) ~= "number" and 0 or v271
						local v272 = v_u_4:GetAttribute("BossHp")
						v270.hp = type(v272) ~= "number" and 1 or v272
						v270.inArena = v257
						v270.ko = v262 < v_u_35
						local v273 = v_u_4:GetAttribute("BossFighters")
						v270.fighters = type(v273) ~= "number" and 0 or v273
						local v274
						if v264 == "coming" then
							v274 = v_u_15.countdown(v262, v268)
						elseif v264 == "fight" then
							v274 = v_u_15.countdown(v262, v266)
						else
							v274 = nil
						end
						v270.countdown = v274
						v270.running = v_u_17:GetAttribute("InStages") == true and true or v_u_17:GetAttribute("InWave") == true
						v270.won = v_u_4:GetAttribute("BossWon") == true
						local v275 = v_u_4:GetAttribute("BossOver")
						v270.overUntil = type(v275) ~= "number" and 0 or v275
						local v276 = v_u_4:GetAttribute("BossPhase")
						local v277
						if (type(v276) ~= "string" and "wait" or v276) == "fight" then
							local v278 = v_u_4:GetAttribute("BossHp")
							v277 = (type(v278) ~= "number" and 1 or v278) < v_u_15.ENRAGE
						else
							v277 = false
						end
						v270.enraged = v277
						v269(v270)
					else
						local v279 = v_u_21
						v_u_21 = nil
						v_u_22 = -1
						v_u_23 = false
						if v279 then
							v279:destroy()
						end
						if v_u_36 then
							v_u_36:Destroy()
							v_u_36 = nil
						end
						v_u_7.hide()
					end
					task.wait(0.1)
				end
			end)
		else
			warn("[Boss] the Boss remote never came")
		end
	end
end
function v16.start() -- name: start
	-- upvalues: (copy) v_u_14, (copy) v_u_3, (copy) v_u_4, (copy) v_u_280
	if v_u_14.on(2) or v_u_3:IsStudio() then
		task.spawn(function()
			-- upvalues: (ref) v_u_14, (ref) v_u_4, (ref) v_u_280
			while not v_u_14.on(2) do
				v_u_4:GetAttributeChangedSignal("DevUpdate2"):Wait()
			end
			v_u_280()
		end)
	end
end
return v16