local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("E6D2FF")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(175, 125, 255)
local v_u_11 = Enum.PartType.Wedge
local function v_u_19(p12, p13, p14, p15, p16) -- name: spindle
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v17 = v_u_5.part(p12, p13, p14, {
		["transparency"] = p15
	})
	local v18 = Instance.new("SpecialMesh")
	v18.MeshType = Enum.MeshType.Sphere
	v18.Parent = v17
	v_u_1:AddItem(v17, p16 or 6)
	return v17
end
local function v_u_31(p20, p21, p22, p23, p24) -- name: card
	-- upvalues: (copy) v_u_5
	local v25 = v_u_5.part
	local v26 = p21 * 2
	local v27 = p21 * 2
	local v28 = v25(Vector3.new(v26, 0.05, v27), p20, p23, {
		["transparency"] = 1
	})
	for _, v29 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v30 = Instance.new("Decal")
		v30.Face = v29
		v30.Texture = p22
		v30.Color3 = p23
		v30.Transparency = p24
		v30.Parent = v28
	end
	return v28
end
local function v_u_35(p32, p33) -- name: fadeDecals
	for _, v34 in p32:GetChildren() do
		if not v34:IsA("Decal") then
			continue
		end
		v34.Transparency = p33
	end
end
local function v_u_41(p36, p37, p38) -- name: triangle
	local v39 = p36 / 2
	local v40 = Vector3.new(p38, p37, v39)
	return { v40, v40 }, { CFrame.new(p36 / 4, p37 / 2, 0) * CFrame.Angles(0, -1.5707963267948966, 0), CFrame.new(-p36 / 4, p37 / 2, 0) * CFrame.Angles(0, 1.5707963267948966, 0) }
end
local function v_u_48(p42, p43, p44) -- name: pointing
	local v45 = p43.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or p43.Unit
	local v46 = p44 - v45 * p44:Dot(v45)
	if v46.Magnitude < 0.001 then
		local v47 = v45.Y
		v46 = math.abs(v47) >= 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0) - v45 * v45.Y
	end
	return CFrame.fromMatrix(p42, v45:Cross(v46.Unit), v45)
end
return function(p_u_49)
	-- upvalues: (copy) v_u_31, (copy) v_u_1, (copy) v_u_35, (copy) v_u_4, (copy) v_u_7, (copy) v_u_5, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_19, (copy) v_u_41, (copy) v_u_11, (copy) v_u_48, (copy) v_u_2, (copy) v_u_6
	local function v_u_66(p_u_50, p_u_51, p_u_52, p53, p54, p_u_55, p_u_56, p57) -- name: flare
		-- upvalues: (ref) v_u_31, (ref) v_u_1, (copy) p_u_49, (ref) v_u_35
		local v_u_58 = p57 or 0
		local v_u_59 = v_u_31(p_u_50, p_u_51, p53, p54, v_u_58)
		v_u_1:AddItem(v_u_59, p_u_55 + 0.1)
		p_u_49.animate(p_u_55, 0, function(p60)
			-- upvalues: (copy) p_u_51, (copy) p_u_52, (copy) v_u_59, (copy) p_u_50, (copy) p_u_55, (copy) p_u_56, (ref) v_u_35, (copy) v_u_58
			local v61 = 1 - (1 - p60) ^ 3
			local v62 = p_u_51 + (p_u_52 - p_u_51) * v61
			local v63 = v_u_59
			local v64 = v62 * 2
			local v65 = v62 * 2
			v63.Size = Vector3.new(v64, 0.05, v65)
			v_u_59.CFrame = p_u_50 * CFrame.Angles(0, p60 * p_u_55 * p_u_56, 0)
			v_u_35(v_u_59, v_u_58 + (1 - v_u_58) * p60 ^ 1.5)
			if p60 >= 1 then
				v_u_59:Destroy()
			end
		end)
	end
	local function v_u_102(p67, p68, p69, p70, p_u_71, p72) -- name: shatter
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (copy) p_u_49
		if p68 > 0 then
			local v_u_73 = {}
			for v74 = 1, p68 do
				local v75 = math.random() - 0.5
				local v76 = math.random() * 0.9 - 0.15
				local v77 = math.random() - 0.5
				local v78 = Vector3.new(v75, v76, v77)
				if p72 then
					v78 = v78 + p72 * 0.7
				end
				local v79 = v78.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v78.Unit
				local v80 = CFrame.lookAt
				local v81 = v79.Y
				local v82 = v80(Vector3.new(0, 0, 0), v79, math.abs(v81) > 0.95 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0))
				local v83 = v_u_5.part
				local v84 = Vector3.new(0.16, 0.16, 0.95) * p69
				local v85 = CFrame.new(p67) * v82
				local v86
				if v74 % 3 == 0 then
					v86 = v_u_10
				elseif v74 % 3 == 1 then
					v86 = v_u_9
				else
					v86 = v_u_8
				end
				local v87 = v83(v84, v85, v86)
				v_u_1:AddItem(v87, p_u_71 + 0.1)
				local v88 = {
					["p"] = v87,
					["v"] = v79 * p70 * (0.6 + math.random() * 0.6),
					["r"] = v82,
					["spin"] = CFrame.Angles((math.random() - 0.5) * 0.6, (math.random() - 0.5) * 0.6, (math.random() - 0.5) * 0.6)
				}
				table.insert(v_u_73, v88)
			end
			local v_u_89 = os.clock()
			local v_u_90 = v_u_89
			p_u_49.frame(function()
				-- upvalues: (ref) v_u_90, (copy) v_u_89, (copy) p_u_71, (copy) v_u_73
				local v91 = os.clock()
				local v92 = v91 - v_u_90
				local v93 = math.min(v92, 0.05)
				v_u_90 = v91
				local v94 = (v91 - v_u_89) / p_u_71
				local v95 = math.clamp(v94, 0, 1)
				for _, v96 in v_u_73 do
					local v97 = v96.v
					local v98 = v93 * 4
					local v99 = v97 * (1 - math.min(v98, 0.5))
					local v100 = v93 * 34
					v96.v = v99 - Vector3.new(0, v100, 0)
					v96.r = v96.r * v96.spin
					v96.p.CFrame = CFrame.new(v96.p.Position + v96.v * v93) * v96.r
					v96.p.Transparency = v95 * v95
				end
				if v95 < 1 then
					return true
				end
				for _, v101 in v_u_73 do
					v101.p:Destroy()
				end
				return false
			end)
		end
	end
	local function v_u_114(p103, p104, p105) -- name: thornShot
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_19, (ref) v_u_9, (ref) v_u_8, (copy) p_u_49
		local v106 = p103.size * p105
		local v107 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p104, v_u_10, {
			["transparency"] = 1
		})
		local v108 = v_u_19(Vector3.new(0.36, 0.36, 3.4) * v106, p104, v_u_9)
		local v109 = v_u_19(Vector3.new(1, 1, 4.4) * v106, p104, v_u_10, 0.62)
		local v110 = {
			{
				["p"] = v108,
				["off"] = CFrame.identity
			},
			{
				["p"] = v109,
				["off"] = CFrame.identity
			}
		}
		if not p103.lite then
			for v111 = 0, 2 do
				local v112 = v111 / 3 * 3.141592653589793 * 2
				local v113 = {
					["p"] = v_u_19(Vector3.new(0.15, 0.15, 1.15) * v106, p104, v_u_8),
					["off"] = CFrame.Angles(0, 0, v112) * CFrame.new(0, 0.34 * v106, 0.6 * v106) * CFrame.Angles(-0.75, 0, 0)
				}
				table.insert(v110, v113)
			end
		end
		p_u_49.streak(v107, v_u_9, v_u_10, 0.8 * v106, 0.12)
		if p103.mine then
			p_u_49.light(v107, v_u_10, 9 * v106)
		end
		return p_u_49.assemble(v107, v110, {}, 0, 0, {}, 0.12, 14)
	end
	local function v126(p115, p116) -- name: thornBreak
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_49, (ref) v_u_9, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7, (copy) v_u_102, (ref) v_u_8
		local v117 = p115.size
		v_u_5.flash(p116, v_u_10, 4 * v117, 0.13)
		p_u_49.pop(p116, v_u_9, 1.5 * v117, 0.2, 0.1)
		local v118 = v_u_9
		local v119 = 0.6 * v117
		local v120 = 2.6 * v117
		local v121 = v_u_66
		local v122 = p_u_49.facing
		local v123 = v_u_4.CurrentCamera
		local v124
		if v123 then
			local v125 = v123.CFrame.Position - p116
			v124 = v125.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v125.Unit
		else
			v124 = Vector3.new(0, 0, 1)
		end
		v121(v122(p116, v124), v119, v120, v_u_7.PetStar, v118, 0.2, 2.5, 0)
		v_u_102(p116, p115.lite and 2 or 6, v117, 22 * v117, 0.38, p115.dir)
		if p116.Y - p_u_49.FLOOR < 5 then
			v_u_5.ring(p_u_49.ground(p116), v_u_8, p115.ability.radius * 0.55 * v117, 0.28, v_u_7.Ring)
		end
		p_u_49.hitSound(p116)
	end
	local function v_u_157(p127) -- name: crownFan
		-- upvalues: (ref) v_u_19, (ref) v_u_9, (copy) p_u_49, (ref) v_u_8, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10
		local v_u_128 = p127.size
		local v_u_129 = p127.eye - p127.dir * 1.3 + Vector3.new(0, 0.7, 0)
		local v130 = p127.dir:Cross(Vector3.new(0, 1, 0))
		local v131 = v130.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v130.Unit
		local v132 = p127.lite and 4 or 7
		for v133 = 1, v132 do
			local v134 = (v133 - 1) * 156 / (v132 - 1) + -78
			local v135 = math.rad(v134)
			local v_u_136 = (Vector3.new(0, 1, 0) * math.cos(v135) + v131 * math.sin(v135)).Unit
			local v_u_137 = (v133 % 2 == 1 and 6.5 or 4.6) * v_u_128
			local v_u_138 = v_u_19(Vector3.new(0.45, 0.45, 1) * v_u_128, CFrame.lookAt(v_u_129, v_u_129 + v_u_136), v_u_9, 0, 1)
			p_u_49.animate(0.28, 0, function(p139)
				-- upvalues: (copy) v_u_137, (copy) v_u_128, (copy) v_u_138, (copy) v_u_129, (copy) v_u_136
				local v140 = 1 - (1 - p139) ^ 3
				local v141 = v_u_137 * (0.25 + 0.75 * v140)
				local v142 = 0.45 * v_u_128 * (1 - p139 * 0.6)
				v_u_138.Size = Vector3.new(v142, v142, v141)
				local v143 = v_u_129 + v_u_136 * (0.8 + v141 / 2 + v140 * 1.4)
				v_u_138.CFrame = CFrame.lookAt(v143, v143 + v_u_136)
				v_u_138.Transparency = p139 * p139
				if p139 >= 1 then
					v_u_138:Destroy()
				end
			end)
		end
		local v144 = v_u_8
		local v145 = 0.6 * v_u_128
		local v146 = 3.4 * v_u_128
		local v147 = v_u_66
		local v148 = p_u_49.facing
		local v149 = v_u_4.CurrentCamera
		local v150
		if v149 then
			local v151 = v149.CFrame.Position - v_u_129
			v150 = v151.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v151.Unit
		else
			v150 = Vector3.new(0, 0, 1)
		end
		v147(v148(v_u_129, v150), v145, v146, v_u_7.PetStar, v144, 0.24, 2.5, 0)
		if not p127.lite then
			local v152 = v_u_66
			local v153 = p_u_49.facing
			local v154 = v_u_4.CurrentCamera
			local v155
			if v154 then
				local v156 = v154.CFrame.Position - v_u_129
				v155 = v156.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v156.Unit
			else
				v155 = Vector3.new(0, 0, 1)
			end
			v152(v153(v_u_129, v155), 0.8 * v_u_128, 4 * v_u_128, v_u_7.Ring, v_u_10, 0.24, 0, 0.1)
		end
	end
	local function v185(p_u_158, p159) -- name: plant
		-- upvalues: (copy) p_u_49, (ref) v_u_19, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (copy) v_u_66, (ref) v_u_4, (copy) v_u_102
		local v_u_160 = p_u_158.size
		local v161 = p_u_49.ground(p159, 0)
		local v_u_162 = (p_u_49.flatUnit(p_u_158.dir) * 0.9 - Vector3.new(0, 1, 0)).Unit
		local v_u_163 = 5.2 * v_u_160
		local v_u_164 = v161 - v_u_162 * v_u_163 * 0.15000000000000002
		local v165 = v_u_19
		local v166 = 0.6 * v_u_160
		local v167 = 0.6 * v_u_160
		local v_u_168 = v165(Vector3.new(v166, v167, v_u_163), CFrame.lookAt(v_u_164, v_u_164 + v_u_162), v_u_9, 0, 1)
		local v_u_169
		if p_u_158.lite then
			v_u_169 = nil
		else
			local v170 = v_u_19
			local v171 = 1.5 * v_u_160
			local v172 = 1.5 * v_u_160
			local v173 = v_u_163 * 1.15
			v_u_169 = v170(Vector3.new(v171, v172, v173), CFrame.lookAt(v_u_164, v_u_164 + v_u_162), v_u_10, 0.6, 1)
		end
		v_u_5.flash(v161 + Vector3.new(0, 1, 0), v_u_10, 4.5 * v_u_160, 0.14)
		v_u_5.ring(v161, v_u_8, 4 * v_u_160, 0.3, v_u_7.Ring)
		if not p_u_158.lite then
			local v174 = v161 + Vector3.new(0, 1.2, 0)
			local v175 = v_u_9
			local v176 = 0.8 * v_u_160
			local v177 = 3.6 * v_u_160
			local v178 = v_u_66
			local v179 = p_u_49.facing
			local v180 = v_u_4.CurrentCamera
			local v181
			if v180 then
				local v182 = v180.CFrame.Position - v174
				v181 = v182.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v182.Unit
			else
				v181 = Vector3.new(0, 0, 1)
			end
			v178(v179(v174, v181), v176, v177, v_u_7.PetStar, v175, 0.22, 2.5, 0)
			p_u_49.spikes(v161 + Vector3.new(0, 0.4, 0), v_u_8, 3, 4 * v_u_160, 0.18, Vector3.new(0, 1, 0), 0.7)
		end
		p_u_49.hitSound(v161 + Vector3.new(0, 1, 0))
		p_u_49.after(0.3, function()
			-- upvalues: (copy) v_u_164, (copy) v_u_162, (copy) v_u_163, (ref) v_u_102, (copy) p_u_158, (copy) v_u_160, (ref) p_u_49, (ref) v_u_9, (copy) v_u_168, (ref) v_u_169
			local v183 = v_u_164 - v_u_162 * v_u_163 * 0.25
			v_u_102(v183, p_u_158.lite and 0 or 5, v_u_160, 18 * v_u_160, 0.4, Vector3.new(0, 1, 0))
			p_u_49.pop(v183, v_u_9, 1.2 * v_u_160, 2.6 * v_u_160, 0.12, 0.3)
			p_u_49.fadeOut(v_u_168, 0.1)
			local v184 = v_u_169
			if v184 then
				p_u_49.fadeOut(v184, 0.1)
			end
		end)
	end
	local v_u_186 = {}
	setmetatable(v_u_186, {
		["__mode"] = "k"
	})
	local v_u_187 = {}
	setmetatable(v_u_187, {
		["__mode"] = "k"
	})
	local function v_u_191(p188) -- name: endCrown
		if not p188.done then
			p188.done = true
			for _, v189 in p188.spikes do
				for _, v190 in v189.parts do
					v190:Destroy()
				end
			end
			p188.ring:Destroy()
			p188.core:Destroy()
			p188.glow:Destroy()
		end
	end
	local function v_u_213(p192) -- name: buildCrown
		-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_41, (ref) v_u_5, (ref) v_u_11, (ref) v_u_1, (ref) v_u_31, (ref) v_u_7, (copy) p_u_49
		local v193 = p192.lite
		local v194 = p192.size
		local v195 = p192.eye + Vector3.new(0, 6.5, 0) * v194
		local v196 = {}
		for v197 = 0, 15 do
			local v198 = v197 % 4 == 0
			local v199 = not v198
			if v199 then
				v199 = v197 % 2 == 0
			end
			if v193 and not (v198 or v199) then
				continue
			end
			local v200 = (v198 and 5.6 or (v199 and 3.6 or 2.2)) * v194
			local v201 = (v198 and 1.6 or (v199 and 1.15 or 0.8)) * v194
			local v202
			if v198 then
				v202 = v_u_9
			elseif v199 then
				v202 = v_u_8
			else
				v202 = v_u_10
			end
			local v203, v204 = v_u_41(v201, v200, 0.32 * v194)
			local v205 = {}
			for _, v206 in v203 do
				local v207 = {
					["shape"] = nil,
					["transparency"] = 1,
					["shape"] = v_u_11
				}
				local v208 = v_u_5.part(v206, CFrame.new(v195), v202, v207)
				v_u_1:AddItem(v208, 4.3)
				table.insert(v205, v208)
			end
			local v209 = {
				["parts"] = nil,
				["offs"] = nil,
				["sizes"] = nil,
				["angle"] = nil,
				["len"] = nil,
				["launch"] = (1 / 0),
				["travel"] = 0.16,
				["goal"] = nil,
				["p0"] = nil,
				["p1"] = nil,
				["planted"] = nil,
				["landedAt"] = nil,
				["broken"] = false,
				["drawn"] = -1,
				["parts"] = v205,
				["offs"] = v204,
				["sizes"] = v203,
				["angle"] = 1.5707963267948966 + v197 * 3.141592653589793 / 8,
				["len"] = v200,
				["goal"] = v195
			}
			table.insert(v196, v209)
		end
		local v210 = v_u_31(CFrame.new(v195), 2.3, v_u_7.Ring, v_u_8, 0.05)
		v_u_1:AddItem(v210, 4.3)
		local v211 = p_u_49.ball(v195, v_u_9, 1.6 * v194, 0)
		local v212 = p_u_49.ball(v195, v_u_10, 3.4 * v194, 0.55)
		v_u_1:AddItem(v211, 4.3)
		v_u_1:AddItem(v212, 4.3)
		return {
			["lite"] = nil,
			["at"] = nil,
			["radius"] = nil,
			["spikes"] = nil,
			["ring"] = nil,
			["core"] = nil,
			["glow"] = nil,
			["born"] = nil,
			["last"] = nil,
			["spin"] = 0,
			["k"] = -1,
			["fireAt"] = nil,
			["done"] = false,
			["cfs"] = nil,
			["parts"] = nil,
			["lite"] = v193,
			["at"] = v195,
			["radius"] = p192.ability.radius,
			["spikes"] = v196,
			["ring"] = v210,
			["core"] = v211,
			["glow"] = v212,
			["born"] = os.clock(),
			["last"] = os.clock(),
			["cfs"] = {},
			["parts"] = {}
		}
	end
	local function v_u_225(p214, p215, p216) -- name: spikeLands
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (copy) v_u_66, (copy) p_u_49, (ref) v_u_4
		local v217 = p215.goal
		v_u_5.flash(v217 + Vector3.new(0, 0.8, 0), v_u_10, 3.4, 0.12)
		if not p214.lite then
			if p216 % 2 == 0 then
				v_u_5.ring(v217, v_u_8, 3, 0.25, v_u_7.Ring)
			end
			if p216 % 3 == 0 then
				local v218 = v217 + Vector3.new(0, 1.5, 0)
				local v219 = v_u_9
				local v220 = v_u_66
				local v221 = p_u_49.facing
				local v222 = v_u_4.CurrentCamera
				local v223
				if v222 then
					local v224 = v222.CFrame.Position - v218
					v223 = v224.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v224.Unit
				else
					v223 = Vector3.new(0, 0, 1)
				end
				v220(v221(v218, v223), 0.6, 2.8, v_u_7.PetStar, v219, 0.18, 2.5, 0)
			end
		end
	end
	local function v_u_232(p226, p227) -- name: spikeBreaks
		-- upvalues: (copy) v_u_102, (copy) p_u_49
		p227.broken = true
		local v228 = p227.planted
		local v229
		if v228 then
			local v230 = p227.len * 0.6
			v229 = v228:PointToWorldSpace((Vector3.new(0, v230, 0)))
		else
			v229 = p227.goal
		end
		if not p226.lite then
			v_u_102(v229, 3, 1, 16, 0.35, Vector3.new(0, 1, 0))
		end
		for _, v231 in p227.parts do
			p_u_49.fadeOut(v231, 0.12)
		end
	end
	local function v_u_314(p233) -- name: crownStep
		-- upvalues: (ref) v_u_4, (copy) v_u_232, (ref) v_u_48, (copy) v_u_225, (copy) p_u_49, (ref) v_u_9, (copy) v_u_66, (ref) v_u_7, (ref) v_u_5, (ref) v_u_10
		if p233.done then
			return false
		end
		local v234 = os.clock()
		local v235 = v234 - p233.born
		local v236 = v234 - p233.last
		local v237 = math.min(v236, 0.05)
		p233.last = v234
		local v238 = p233.fireAt
		local v239
		if v238 then
			local v240 = 1 - (v234 - v238) / 0.6
			v239 = math.max(v240, 0.15) * 40
		else
			local v241 = v235 / 0.32
			local v242 = math.clamp(v241, 0, 1)
			v239 = v242 * 42 * v242 + 2.5
		end
		p233.spin = p233.spin + v239 * v237
		local v243
		if v238 then
			v243 = v238 + 0.55
		else
			v243 = p233.born + 0.14 + 1.3
		end
		local v244 = (v234 - v243) / 0.16
		local v245 = math.clamp(v244, 0, 1)
		local v246 = v235 / 0.14
		local v247 = math.clamp(v246, 0, 1) - 1
		local v248 = (v247 * 2.9 * v247 * v247 + 1 + v247 * 1.9 * v247) * (1 - v245)
		local v249 = math.max(v248, 0.02)
		local v250 = p233.at
		local v251 = v_u_4.CurrentCamera
		local v252
		if v251 then
			local v253 = v251.CFrame.Position - v250
			v252 = v253.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v253.Unit
		else
			v252 = Vector3.new(0, 0, 1)
		end
		local v254 = CFrame.lookAt(p233.at, p233.at + v252)
		local v255 = v254.RightVector
		local v256 = v254.UpVector
		p233.k = v249
		local v257 = p233.parts
		local v258 = p233.cfs
		table.clear(v257)
		table.clear(v258)
		for v259, v260 in p233.spikes do
			if v260.broken then
				continue
			end
			local v261 = v260.angle + p233.spin
			local v262 = v255 * math.cos(v261)
			local v263 = v260.angle + p233.spin
			local v264 = v262 + v256 * math.sin(v263)
			local v265 = (v234 - v260.launch) / v260.travel
			local v266 = v260.planted
			local v267, v268, v269, v270, v271, v272
			if v266 then
				local v273 = v260.landedAt
				if v273 and v234 - v273 > 0.32 then
					v_u_232(p233, v260)
				else
					v267 = v266
					v268 = (v266 ~= nil and true or v265 > 0) and 1.5 or v249
					v269 = v268 - v260.drawn
					v270 = math.abs(v269) > 0.001
					if v270 then
						v260.drawn = v268
					end
					for v294, v295 in v260.parts do
						v271 = v260.offs[v294]
						table.insert(v257, v295)
						v272 = v267 * (v271 - v271.Position + v271.Position * v268)
						table.insert(v258, v272)
						if v270 then
							v295.Size = v260.sizes[v294] * v268
						end
						if v295.Transparency < 1 then
							continue
						end
						v295.Transparency = 0
					end
				end
			else
				if v265 > 0 then
					if not v260.p0 then
						local v276 = p233.at + v264 * 1.7 * v249
						v260.p0 = v276
						v260.p1 = v276 + v264 * 7 + Vector3.new(0, 2.5, 0)
					end
					local v277 = v260.p0
					local v278 = v260.p1
					local v279 = v260.goal
					local v280 = math.min(v265, 1)
					local v281 = v277 * (1 - v280) * (1 - v280) + v278 * 2 * (1 - v280) * v280 + v279 * v280 * v280
					local v282 = (v278 - v277) * 2 * (1 - v280) + (v279 - v278) * 2 * v280
					if v280 >= 1 then
						local v283 = v282.Unit
						local v284 = v_u_48
						local v285 = v279 - v283 * v260.len * 0.55
						local v286 = v_u_4.CurrentCamera
						local v287
						if v286 then
							local v288 = v286.CFrame.Position - v279
							v287 = v288.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v288.Unit
						else
							v287 = Vector3.new(0, 0, 1)
						end
						v267 = v284(v285, v283, v287)
						v260.planted = v267
						v260.landedAt = v234
						v_u_225(p233, v260, v259)
					else
						local v289 = v_u_48
						local v290 = v281 - v282.Unit * v260.len * 0.5
						local v291 = v_u_4.CurrentCamera
						local v292
						if v291 then
							local v293 = v291.CFrame.Position - v281
							v292 = v293.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v293.Unit
						else
							v292 = Vector3.new(0, 0, 1)
						end
						v267 = v289(v290, v282, v292)
					end
				else
					v267 = v_u_48(p233.at + v264 * 1.7 * v249, v264, v252)
				end
				v268 = (v266 ~= nil and true or v265 > 0) and 1.5 or v249
				v269 = v268 - v260.drawn
				v270 = math.abs(v269) > 0.001
				if v270 then
					v260.drawn = v268
				end
				for v294, v295 in v260.parts do
					v271 = v260.offs[v294]
					table.insert(v257, v295)
					v272 = v267 * (v271 - v271.Position + v271.Position * v268)
					table.insert(v258, v272)
					if v270 then
						v295.Size = v260.sizes[v294] * v268
					end
					if v295.Transparency < 1 then
						continue
					end
					v295.Transparency = 0
				end
			end
		end
		if #v257 > 0 then
			v_u_4:BulkMoveTo(v257, v258, Enum.BulkMoveMode.FireCFrameChanged)
		end
		local v296 = v235 / 0.32
		local v297 = math.clamp(v296, 0, 1) * 0.5 + 1
		local v298 = v249 * 2.3
		local v299 = p233.ring
		local v300 = v298 * 2
		local v301 = v298 * 2
		v299.Size = Vector3.new(v300, 0.05, v301)
		p233.ring.CFrame = p_u_49.facing(p233.at, v252) * CFrame.Angles(0, -p233.spin * 0.5, 0)
		p233.core.CFrame = CFrame.new(p233.at)
		p233.core.Size = Vector3.new(1.6, 1.6, 1.6) * v249 * v297
		p233.glow.CFrame = CFrame.new(p233.at)
		local v302 = p233.glow
		local v303 = Vector3.new(3.4, 3.4, 3.4) * v249 * v297
		local v304 = v235 * 40
		v302.Size = v303 * (math.sin(v304) * 0.06 + 1)
		if v245 < 1 then
			return true
		end
		local v305 = p233.at
		local v306 = v_u_9
		local v307 = v_u_66
		local v308 = p_u_49.facing
		local v309 = v_u_4.CurrentCamera
		local v310
		if v309 then
			local v311 = v309.CFrame.Position - v305
			v310 = v311.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v311.Unit
		else
			v310 = Vector3.new(0, 0, 1)
		end
		v307(v308(v305, v310), 1, 7, v_u_7.PetStar, v306, 0.26, 2.5, 0)
		v_u_5.flash(p233.at, v_u_10, 6, 0.16)
		for _, v312 in p233.spikes do
			if v312.broken then
				continue
			end
			v312.broken = true
			for _, v313 in v312.parts do
				p_u_49.fadeOut(v313, 0.1)
			end
		end
		p233.done = true
		p233.ring:Destroy()
		p233.core:Destroy()
		p233.glow:Destroy()
		return false
	end
	local function v_u_319(p315) -- name: startCrown
		-- upvalues: (copy) v_u_213, (copy) v_u_186, (copy) v_u_191, (copy) v_u_187, (copy) p_u_49, (copy) v_u_314
		local v_u_316 = v_u_213(p315)
		local v317 = p315.caster
		if v317 then
			local v318 = v_u_186[v317]
			if v318 and not v318.fireAt then
				v_u_191(v318)
			end
			v_u_186[v317] = v_u_316
		else
			v_u_187[p315] = v_u_316
		end
		p_u_49.runNow(function()
			-- upvalues: (ref) v_u_314, (copy) v_u_316
			return v_u_314(v_u_316)
		end)
		return v_u_316
	end
	local function v_u_331(p320, p321) -- name: fire
		-- upvalues: (copy) p_u_49
		local v322 = os.clock()
		p320.fireAt = v322
		local v323 = p_u_49.ground(p321, 0)
		local v324 = #p320.spikes
		for v325, v326 in p320.spikes do
			local v327 = (v325 - 1) / v324 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.3
			local v328 = p320.radius * (v325 * 0.618 % 1 * 0.6 + 0.35)
			local v329 = math.cos(v327)
			local v330 = math.sin(v327)
			v326.goal = v323 + Vector3.new(v329, 0, v330) * v328
			v326.launch = v322 + (v325 - 1) * 0.012
			v326.travel = v325 * 0.37 % 1 * 0.08 + 0.14
		end
	end
	local v_u_332 = 0
	local function v_u_336() -- name: screenFlash
		-- upvalues: (ref) v_u_332, (ref) v_u_2, (ref) v_u_5, (copy) p_u_49, (ref) v_u_9, (ref) v_u_1
		local v333 = os.clock()
		if v333 >= v_u_332 then
			v_u_332 = v333 + 0.6
			local v_u_334 = Instance.new("ColorCorrectionEffect")
			v_u_334.Name = "StarburstCrown"
			v_u_334.Parent = v_u_2
			v_u_5.tween(v_u_334, 0.04, {
				["TintColor"] = nil,
				["Brightness"] = 0.12,
				["Contrast"] = 0.15,
				["TintColor"] = Color3.fromRGB(240, 228, 255)
			})
			p_u_49.after(0.08, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_334, (ref) v_u_9
				local v335 = {
					["TintColor"] = nil,
					["Brightness"] = 0,
					["Contrast"] = 0,
					["TintColor"] = v_u_9
				}
				v_u_5.tween(v_u_334, 0.45, v335)
			end)
			v_u_1:AddItem(v_u_334, 0.6)
		end
	end
	local function v_u_352(p337, p338, p339) -- name: starburst
		-- upvalues: (copy) p_u_49, (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (copy) v_u_336
		local v_u_340 = p337.ability.radius
		local v341 = p337.lite
		local v_u_342 = p_u_49.ground(p338, 0)
		v_u_5.flash(p339, v_u_9, 14, 0.18)
		p_u_49.burst("Flash", p339, v_u_10, 0.7, true)
		local v343 = v_u_9
		local v344 = v_u_66
		local v345 = p_u_49.facing
		local v346 = v_u_4.CurrentCamera
		local v347
		if v346 then
			local v348 = v346.CFrame.Position - p339
			v347 = v348.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v348.Unit
		else
			v347 = Vector3.new(0, 0, 1)
		end
		v344(v345(p339, v347), 2, 12, v_u_7.PetStar, v343, 0.3, 2.5, 0)
		p_u_49.spikes(p339, v_u_9, v341 and 6 or 12, 16, 0.3)
		local v349 = p_u_49.thin
		local v350 = p_u_49.pillar
		local v351 = p339.Y - v_u_342.Y
		v349(v350(v_u_342, math.max(v351, 1), 3, v_u_8, 0.25), 0.3, true)
		p_u_49.burst("Shockwave", v_u_342 + Vector3.new(0, 0.3, 0), v_u_10, 1.4)
		v_u_5.ring(v_u_342, v_u_8, v_u_340, 0.5, v_u_7.Shockwave)
		p_u_49.after(0.05, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_342, (ref) v_u_9, (copy) v_u_340, (ref) v_u_7
			v_u_5.ring(v_u_342, v_u_9, v_u_340 * 1.1, 0.45, v_u_7.Ring)
		end)
		if not v341 then
			p_u_49.after(0.1, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_342, (ref) v_u_10, (copy) v_u_340, (ref) v_u_7
				v_u_5.ring(v_u_342, v_u_10, v_u_340 * 0.95, 0.4, v_u_7.SpeedLines)
			end)
			p_u_49.spikes(v_u_342 + Vector3.new(0, 0.6, 0), v_u_8, 10, v_u_340 * 0.9, 0.35, nil, nil, true)
		end
		p_u_49.mark(p338, v_u_10, v_u_340 * 0.45, 1.4, v_u_7.Glow, 0.35)
		v_u_6.play("Explosion", {
			["at"] = v_u_342,
			["volume"] = p337.mine and 1 or 0.6
		})
		if p337.mine then
			v_u_5.shake(0.55, 0.5)
			v_u_336()
		end
	end
	local v406 = {
		["thorn_halo_a"] = {
			["cast"] = function(p353) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_49, (ref) v_u_9, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7
				local v354 = p353.size
				local v355 = p353.eye + p353.dir * 1.2
				v_u_5.flash(v355, v_u_10, 3 * v354, 0.1)
				p_u_49.pop(v355, v_u_9, 1.2 * v354, 0.2, 0.08)
				if not p353.lite then
					local v356 = v_u_9
					local v357 = 0.4 * v354
					local v358 = 1.8 * v354
					local v359 = v_u_66
					local v360 = p_u_49.facing
					local v361 = v_u_4.CurrentCamera
					local v362
					if v361 then
						local v363 = v361.CFrame.Position - v355
						v362 = v363.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v363.Unit
					else
						v362 = Vector3.new(0, 0, 1)
					end
					v359(v360(v355, v362), v357, v358, v_u_7.PetStar, v356, 0.12, 2.5, 0)
				end
			end,
			["shot"] = function(p364, p365) -- name: shot
				-- upvalues: (copy) v_u_114
				return v_u_114(p364, p365, 1)
			end,
			["impact"] = v126,
			["hit"] = function(p366, p367, _) -- name: hit
				-- upvalues: (copy) p_u_49, (ref) v_u_10, (ref) v_u_9, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7
				p_u_49.burst("Impact", p367, v_u_10, 0.55)
				if not p366.lite then
					local v368 = v_u_9
					local v369 = v_u_66
					local v370 = p_u_49.facing
					local v371 = v_u_4.CurrentCamera
					local v372
					if v371 then
						local v373 = v371.CFrame.Position - p367
						v372 = v373.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v373.Unit
					else
						v372 = Vector3.new(0, 0, 1)
					end
					v369(v370(p367, v372), 0.4, 1.8, v_u_7.PetStar, v368, 0.12, 2.5, 0)
				end
			end
		},
		["thorn_halo_e"] = {
			["cast"] = function(p374) -- name: cast
				-- upvalues: (copy) p_u_49, (ref) v_u_10, (copy) v_u_157
				p_u_49.skillCast(p374, v_u_10)
				v_u_157(p374)
			end,
			["shot"] = function(p375, p376) -- name: shot
				-- upvalues: (copy) v_u_114
				return v_u_114(p375, p376, 1.5)
			end,
			["impact"] = v185,
			["hit"] = function(p377, p378, _) -- name: hit
				-- upvalues: (copy) p_u_49, (ref) v_u_10, (ref) v_u_9, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7
				p_u_49.burst("Impact", p378, v_u_10, 0.75)
				if not p377.lite then
					local v379 = v_u_9
					local v380 = v_u_66
					local v381 = p_u_49.facing
					local v382 = v_u_4.CurrentCamera
					local v383
					if v382 then
						local v384 = v382.CFrame.Position - p378
						v383 = v384.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v384.Unit
					else
						v383 = Vector3.new(0, 0, 1)
					end
					v380(v381(p378, v383), 0.5, 2.4, v_u_7.PetStar, v379, 0.14, 2.5, 0)
				end
			end
		},
		["thorn_halo_r"] = {
			["cast"] = function(p385) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (copy) p_u_49, (ref) v_u_9, (copy) v_u_319
				v_u_5.flash(p385.eye, v_u_10, 4, 0.14)
				v_u_5.ring(p385.feet, v_u_8, 10, 0.35, v_u_7.Ring)
				p_u_49.thin(p_u_49.pillar(p385.feet, 8.5, 2.6, v_u_9, 0.45), 0.25)
				if p385.mine then
					v_u_5.shake(0.12, 0.14)
				end
				v_u_319(p385)
			end,
			["windup"] = function(p386, p387, p388) -- name: windup
				-- upvalues: (copy) v_u_186, (copy) v_u_187, (copy) v_u_319, (copy) v_u_66, (copy) p_u_49, (ref) v_u_7, (ref) v_u_8, (ref) v_u_5
				local v389 = p386.caster
				local v390
				if v389 then
					v390 = v_u_186[v389]
				else
					v390 = v_u_187[p386]
				end
				if not v390 or (v390.done or v390.fireAt) then
					v390 = nil
				end
				local v391 = v390 or v_u_319(p386)
				local v392 = p386.ability.radius
				v_u_66(CFrame.new(p_u_49.ground(p387, 0.2)), v392 * 1.05, v392 * 0.4, v_u_7.Ring, v_u_8, math.max(p388, 0.08), 2, 0.35)
				if not p386.lite then
					p_u_49.inward(v391.at, v_u_8, 6, 9, (math.max(p388, 0.1)))
				end
				if p386.mine then
					v_u_5.shake(0.15, 0.2)
				end
			end,
			["land"] = function(p393, p394) -- name: land
				-- upvalues: (copy) v_u_186, (copy) v_u_187, (copy) v_u_331, (copy) v_u_352
				local v395 = p393.caster
				local v396
				if v395 then
					v396 = v_u_186[v395]
				else
					v396 = v_u_187[p393]
				end
				local v397 = p393.eye + Vector3.new(0, 6.5, 0) * p393.size
				if v396 and not (v396.done or v396.fireAt) then
					v_u_331(v396, p394)
					v397 = v396.at
				end
				v_u_352(p393, p394, v397)
			end,
			["hit"] = function(p398, p399, _) -- name: hit
				-- upvalues: (copy) p_u_49, (ref) v_u_10, (ref) v_u_9, (copy) v_u_66, (ref) v_u_4, (ref) v_u_7
				p_u_49.burst("Impact", p399, v_u_10, 1.1)
				if not p398.lite then
					local v400 = v_u_9
					local v401 = v_u_66
					local v402 = p_u_49.facing
					local v403 = v_u_4.CurrentCamera
					local v404
					if v403 then
						local v405 = v403.CFrame.Position - p399
						v404 = v405.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v405.Unit
					else
						v404 = Vector3.new(0, 0, 1)
					end
					v401(v402(p399, v404), 0.6, 3, v_u_7.PetStar, v400, 0.16, 2.5, 0)
				end
			end
		}
	}
	return v406
end