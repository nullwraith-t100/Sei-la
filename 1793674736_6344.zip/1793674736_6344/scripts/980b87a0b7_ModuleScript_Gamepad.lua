local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(script.Parent.Sfx)
local v_u_8 = {}
local v_u_9 = v3.LocalPlayer
local v_u_10 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_11 = Color3.fromRGB(255, 226, 60)
local v_u_12 = Color3.new(0, 0, 0)
local v_u_13 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local v_u_14 = Instance.new("BindableEvent")
v_u_8.changed = v_u_14.Event
local v_u_15 = v_u_13[v_u_6:GetLastInputType()] ~= true and v_u_2:IsTenFootInterface()
if v_u_15 then
	v_u_15 = v_u_6.GamepadEnabled
end
local v_u_16 = Enum.UserInputType.Gamepad1
function v_u_8.active() -- name: active
	-- upvalues: (ref) v_u_15
	return v_u_15
end
function v_u_8.tv() -- name: tv
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_9
	if v_u_2:IsTenFootInterface() then
		return true
	end
	local v17 = v_u_4:IsStudio()
	if v17 then
		v17 = v_u_9:GetAttribute("DevTV") == true
	end
	return v17
end
function v_u_8.glyph(p18) -- name: glyph
	-- upvalues: (copy) v_u_6
	return v_u_6:GetImageForKeyCode(p18)
end
function v_u_8.playstation() -- name: playstation
	-- upvalues: (copy) v_u_8
	local v19 = string.lower(v_u_8.glyph(Enum.KeyCode.ButtonA))
	return (string.find(v19, "playstation", 1, true) ~= nil or (string.find(v19, "cross", 1, true) ~= nil or string.find(v19, "ps4", 1, true) ~= nil)) and true or string.find(v19, "ps5", 1, true) ~= nil
end
local v_u_20 = {
	[Enum.KeyCode.ButtonA] = { "A", "CROSS" },
	[Enum.KeyCode.ButtonB] = { "B", "CIRCLE" },
	[Enum.KeyCode.ButtonX] = { "X", "SQUARE" },
	[Enum.KeyCode.ButtonY] = { "Y", "TRIANGLE" },
	[Enum.KeyCode.ButtonL1] = { "LB", "L1" },
	[Enum.KeyCode.ButtonR1] = { "RB", "R1" },
	[Enum.KeyCode.ButtonL2] = { "LT", "L2" },
	[Enum.KeyCode.ButtonR2] = { "RT", "R2" },
	[Enum.KeyCode.ButtonL3] = { "LS", "L3" },
	[Enum.KeyCode.ButtonR3] = { "RS", "R3" },
	[Enum.KeyCode.ButtonSelect] = { "VIEW", "TOUCHPAD" },
	[Enum.KeyCode.ButtonStart] = { "MENU", "OPTIONS" },
	[Enum.KeyCode.DPadLeft] = { "D-PAD LEFT", "D-PAD LEFT" },
	[Enum.KeyCode.DPadRight] = { "D-PAD RIGHT", "D-PAD RIGHT" },
	[Enum.KeyCode.DPadUp] = { "D-PAD UP", "D-PAD UP" },
	[Enum.KeyCode.DPadDown] = { "D-PAD DOWN", "D-PAD DOWN" }
}
function v_u_8.name(p21) -- name: name
	-- upvalues: (copy) v_u_20, (copy) v_u_8
	local v22 = v_u_20[p21]
	if v22 then
		if v_u_8.playstation() then
			return v22[2]
		else
			return v22[1]
		end
	else
		return string.upper(p21.Name)
	end
end
local v_u_23 = {}
setmetatable(v_u_23, {
	["__mode"] = "k"
})
function v_u_8.hint(p24, p25, p26, p27) -- name: hint
	-- upvalues: (copy) v_u_10, (copy) v_u_23, (copy) v_u_8, (ref) v_u_15
	local v28 = p26 or 28
	local v_u_29 = Instance.new("ImageLabel")
	v_u_29.Name = "PadHint"
	v_u_29.BackgroundColor3 = Color3.fromRGB(22, 22, 30)
	v_u_29.BackgroundTransparency = 0.2
	v_u_29.Size = UDim2.fromOffset(v28, v28)
	v_u_29.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_29.Position = p27 or UDim2.new(1, -v28 * 0.25, 0, v28 * 0.25)
	v_u_29.ZIndex = p24.ZIndex + 5
	v_u_29.ScaleType = Enum.ScaleType.Fit
	local v30 = Instance.new("UICorner")
	v30.CornerRadius = UDim.new(0.5, 0)
	v30.Parent = v_u_29
	local v31 = Instance.new("TextLabel")
	v31.Name = "Word"
	v31.BackgroundColor3 = Color3.fromRGB(30, 30, 36)
	v31.BackgroundTransparency = 0.1
	v31.Size = UDim2.fromScale(1, 1)
	v31.FontFace = v_u_10
	v31.TextScaled = true
	v31.TextColor3 = Color3.new(1, 1, 1)
	v31.ZIndex = v_u_29.ZIndex
	local v32 = Instance.new("UICorner")
	v32.CornerRadius = UDim.new(0.3, 0)
	v32.Parent = v31
	v31.Parent = v_u_29
	local v33 = {
		["key"] = p25,
		["word"] = v31
	}
	v_u_23[v_u_29] = v33
	local v34 = v_u_8.glyph(v33.key)
	v_u_29.Image = v34
	v_u_29.Visible = v_u_15
	v33.word.Text = v_u_8.name(v33.key)
	v33.word.Visible = v34 == ""
	v_u_29.Parent = p24
	v_u_29.Destroying:Connect(function()
		-- upvalues: (ref) v_u_23, (copy) v_u_29
		v_u_23[v_u_29] = nil
	end)
	return v_u_29
end
local function v_u_38() -- name: paintHints
	-- upvalues: (copy) v_u_23, (copy) v_u_8, (ref) v_u_15
	for v35, v36 in pairs(v_u_23) do
		if not v35.Parent then
			continue
		end
		local v37 = v_u_8.glyph(v36.key)
		v35.Image = v37
		v35.Visible = v_u_15
		v36.word.Text = v_u_8.name(v36.key)
		v36.word.Visible = v37 == ""
	end
end
local v_u_39 = {
	["Purchase"] = true,
	["Purchase1"] = true,
	["Button"] = true,
	["Claim"] = true,
	["Redeem"] = true,
	["Join"] = true,
	["Hatch"] = true,
	["Hatch1"] = true,
	["Hatch3"] = true,
	["Equip"] = true,
	["Delete"] = true,
	["EquipPlus"] = true,
	["SpacePlus"] = true,
	["EquipBest"] = true,
	["UnequipAll"] = true,
	["PetCard"] = true,
	["Daily"] = true,
	["Weekly"] = true,
	["Auto"] = true,
	["Skip"] = true,
	["SkipDay"] = true,
	["ReplayTutorial"] = true,
	["Dragger"] = true,
	["Buy"] = true,
	["Locked"] = true,
	["Upgrade"] = true,
	["Invite"] = true,
	["chakra1"] = true,
	["chakra2"] = true,
	["chakra3"] = true,
	["AutoOp"] = true,
	["AutoFree"] = true,
	["Offer"] = true,
	["Close"] = true,
	["TextCode"] = true
}
local v_u_40 = {
	"Ui-Frame",
	"Ui-Close",
	"Ui-Pass",
	"Ui-Product",
	"Ui-Pack"
}
function v_u_8.actionable(p41) -- name: actionable
	-- upvalues: (copy) v_u_40, (copy) v_u_39
	local v42 = p41:GetAttribute("Pad")
	if type(v42) == "boolean" then
		return v42
	end
	if p41:IsA("TextBox") then
		return true
	end
	if not p41:IsA("GuiButton") then
		return false
	end
	local v43 = p41:FindFirstAncestorWhichIsA("ScreenGui")
	if not v43 or v43.Name ~= "Main" then
		return p41.Selectable
	end
	for _, v44 in v_u_40 do
		if p41:GetAttribute(v44) == nil then
			continue
		end
		return true
	end
	return v_u_39[p41.Name] == true
end
function v_u_8.skip(p45) -- name: skip
	p45:SetAttribute("Pad", false)
	p45.Selectable = false
end
function v_u_8.shown(p46) -- name: shown
	while p46 do
		if p46:IsA("GuiObject") then
			if not p46.Visible then
				return false
			end
		elseif p46:IsA("LayerCollector") then
			local v47 = p46.Enabled
			if v47 then
				v47 = p46:FindFirstAncestorWhichIsA("PlayerGui") ~= nil
			end
			return v47
		end
		p46 = p46.Parent
	end
	return false
end
local function v_u_50(p48) -- name: candidate
	-- upvalues: (copy) v_u_8
	if not (p48:IsA("GuiButton") or p48:IsA("TextBox")) then
		return false
	end
	local v49 = p48.Selectable and v_u_8.actionable(p48)
	if v49 then
		if p48.AbsoluteSize.X > 1 and p48.AbsoluteSize.Y > 1 then
			v49 = v_u_8.shown(p48)
		else
			v49 = false
		end
	end
	return v49
end
function v_u_8.first(p51) -- name: first
	-- upvalues: (copy) v_u_50
	local v52 = nil
	local v53 = 0
	local v54 = 0
	local v55 = nil
	local v56 = 0
	local v57 = 0
	local v58 = nil
	for _, v59 in p51:GetDescendants() do
		if not v_u_50(v59) then
			continue
		end
		if v59.Name == "Close" then
			v58 = v58 or v59
		else
			local v60 = v59.AbsolutePosition
			if v59.Name == "GiftButton" then
				if v55 and v60.Y >= v56 - 6 then
					local v61 = v60.Y - v56
					if math.abs(v61) > 6 or v60.X >= v57 then
						continue
					end
				end
				v57 = v60.X
				v56 = v60.Y
				v55 = v59
			else
				if v52 and v60.Y >= v53 - 6 then
					local v62 = v60.Y - v53
					if math.abs(v62) > 6 or v60.X >= v54 then
						continue
					end
				end
				v54 = v60.X
				v53 = v60.Y
				v52 = v59
			end
		end
	end
	return v52 or (v55 or v58)
end
local v_u_63 = false
local v_u_64 = 0
function v_u_8.selected() -- name: selected
	-- upvalues: (copy) v_u_2
	return v_u_2.SelectedObject
end
function v_u_8.quiet() -- name: quiet
	-- upvalues: (ref) v_u_64
	return os.clock() < v_u_64
end
function v_u_8.clear() -- name: clear
	-- upvalues: (copy) v_u_2, (ref) v_u_63
	if v_u_2.SelectedObject then
		v_u_63 = true
		v_u_2.SelectedObject = nil
		v_u_63 = false
	end
end
function v_u_8.select(p65) -- name: select
	-- upvalues: (ref) v_u_15, (copy) v_u_8, (copy) v_u_2
	if p65 and v_u_15 then
		if (p65:IsA("GuiButton") or p65:IsA("TextBox")) and (p65.Selectable and v_u_8.actionable(p65)) then
			if not v_u_8.shown(p65) then
				p65 = nil
			end
		else
			p65 = v_u_8.first(p65)
		end
		if p65 then
			v_u_2.SelectedObject = p65
		end
	end
end
local function v_u_67() -- name: stickMoving
	-- upvalues: (copy) v_u_6, (ref) v_u_16
	for _, v66 in v_u_6:GetGamepadState(v_u_16) do
		if v66.KeyCode ~= Enum.KeyCode.Thumbstick1 or v66.Position.Magnitude <= 0.35 then
			continue
		end
		return true
	end
	return false
end
local v_u_68 = 0
function v_u_8.selectSoon(p_u_69, p_u_70) -- name: selectSoon
	-- upvalues: (ref) v_u_68, (ref) v_u_15, (copy) v_u_4, (copy) v_u_2, (copy) v_u_67, (copy) v_u_8
	v_u_68 = v_u_68 + 1
	local v_u_71 = v_u_68
	if v_u_15 then
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) v_u_71, (ref) v_u_68, (ref) v_u_15, (ref) v_u_2, (copy) p_u_70, (ref) v_u_67, (copy) p_u_69, (ref) v_u_8
			local v72 = os.clock()
			v_u_4.Heartbeat:Wait()
			while v_u_71 == v_u_68 and (v_u_15 and os.clock() - v72 < 60) do
				if not (v_u_2.MenuIsOpen or p_u_70 and v_u_67()) then
					local v73 = p_u_69()
					if v73 then
						v_u_8.select(v73)
					end
					return
				end
				v_u_4.Heartbeat:Wait()
			end
		end)
	end
end
function v_u_8.root(p74) -- name: root
	p74.SelectionGroup = true
	p74.SelectionBehaviorUp = Enum.SelectionBehavior.Stop
	p74.SelectionBehaviorDown = Enum.SelectionBehavior.Stop
	p74.SelectionBehaviorLeft = Enum.SelectionBehavior.Stop
	p74.SelectionBehaviorRight = Enum.SelectionBehavior.Stop
	p74:SetAttribute("PadRoot", true)
end
local v_u_75 = nil
function v_u_8.noRing(p76) -- name: noRing
	-- upvalues: (ref) v_u_75
	local v77 = v_u_75
	if not v77 then
		v77 = Instance.new("Frame")
		v77.Name = "PadNoRing"
		v77.BackgroundTransparency = 1
		v77.Size = UDim2.fromScale(0, 0)
		v_u_75 = v77
	end
	p76.SelectionImageObject = v77
end
local v_u_78 = {}
function v_u_8.capture(p79, p80) -- name: capture
	-- upvalues: (copy) v_u_78
	if p80 then
		v_u_78[p79] = true
	else
		v_u_78[p79] = nil
	end
end
function v_u_8.captured() -- name: captured
	-- upvalues: (copy) v_u_78
	return next(v_u_78) ~= nil
end
function v_u_8.busy() -- name: busy
	-- upvalues: (copy) v_u_8, (copy) v_u_2
	return v_u_8.captured() or (v_u_2.SelectedObject ~= nil and true or v_u_2.MenuIsOpen)
end
local v_u_81 = {}
local v_u_82 = {}
function v_u_8.onBack(p83, p84) -- name: onBack
	-- upvalues: (copy) v_u_81
	local v_u_85 = {
		["fn"] = p83,
		["priority"] = p84 or 0
	}
	local v86 = v_u_81
	table.insert(v86, v_u_85)
	table.sort(v_u_81, function(p87, p88)
		return p87.priority > p88.priority
	end)
	return function()
		-- upvalues: (ref) v_u_81, (copy) v_u_85
		local v89 = table.find(v_u_81, v_u_85)
		if v89 then
			table.remove(v_u_81, v89)
		end
	end
end
function v_u_8.onEnter(p90, p91) -- name: onEnter
	-- upvalues: (copy) v_u_82
	local v_u_92 = {
		["fn"] = p90,
		["priority"] = p91 or 0
	}
	local v93 = v_u_82
	table.insert(v93, v_u_92)
	table.sort(v_u_82, function(p94, p95)
		return p94.priority > p95.priority
	end)
	return function()
		-- upvalues: (ref) v_u_82, (copy) v_u_92
		local v96 = table.find(v_u_82, v_u_92)
		if v96 then
			table.remove(v_u_82, v96)
		end
	end
end
local v_u_97 = nil
local v_u_98 = Vector2.zero
local v_u_99 = nil
local v_u_100 = (-1 / 0)
local v_u_101 = (-1 / 0)
local v_u_102 = false
local function v_u_105() -- name: back
	-- upvalues: (copy) v_u_2, (ref) v_u_100, (ref) v_u_97, (copy) v_u_81, (copy) v_u_8
	local v103 = v_u_2.SelectedObject
	if not v103 and os.clock() - v_u_100 < 0.3 then
		v103 = v_u_97
	end
	for _, v104 in table.clone(v_u_81) do
		if not v104.fn(v103) then
			continue
		end
		return true
	end
	if not v_u_2.SelectedObject then
		return false
	end
	v_u_8.clear()
	return true
end
local function v_u_108(p106) -- name: rootOf
	local v107 = p106.Parent
	while v107 do
		if v107:IsA("GuiObject") and v107:GetAttribute("PadRoot") == true then
			return v107
		end
		v107 = v107.Parent
	end
	return nil
end
local function v_u_115(p109, p110) -- name: nearest
	-- upvalues: (copy) v_u_50
	local v111 = (1 / 0)
	local v112 = nil
	for _, v113 in p109:GetDescendants() do
		if not v_u_50(v113) then
			continue
		end
		local v114 = (v113.AbsolutePosition + v113.AbsoluteSize / 2 - p110).Magnitude
		if v114 >= v111 then
			continue
		end
		v112 = v113
		v111 = v114
	end
	return v112
end
local v_u_116 = false
local function v_u_138(p117) -- name: follow
	-- upvalues: (copy) v_u_5
	local v118 = p117.Parent
	while v118 and not v118:IsA("ScrollingFrame") do
		v118 = v118.Parent
	end
	if not (v118 and v118:IsA("ScrollingFrame")) then
		return
	end
	local v119 = v118.AbsoluteWindowSize
	local v120 = v118.AbsoluteCanvasSize
	local v121 = v119 * 0.06
	local v122 = p117.Parent
	while v122 and (v122 ~= v118 and v122:IsA("GuiObject")) do
		local v123 = v122.AbsoluteSize
		if v123.X > v119.X + 1 or v123.Y > v119.Y - 2 * v121.Y then
			break
		end
		local v124 = v122.Parent
		p117 = v122
		v122 = v124
	end
	local v125 = p117.AbsolutePosition - v118.AbsolutePosition
	local v126 = v125 + p117.AbsoluteSize
	local v127 = v118.CanvasPosition
	local v128 = v127.X
	local v129 = v127.Y
	if v125.Y < v121.Y then
		v129 = v129 + (v125.Y - v121.Y)
	elseif v126.Y > v119.Y - v121.Y then
		v129 = v129 + (v126.Y - v119.Y + v121.Y)
	end
	if v125.X < v121.X then
		v128 = v128 + (v125.X - v121.X)
	elseif v126.X > v119.X - v121.X then
		v128 = v128 + (v126.X - v119.X + v121.X)
	end
	local v130 = v120.X - v119.X
	local v131 = math.max(0, v130)
	local v132 = math.clamp(v128, 0, v131)
	local v133 = v120.Y - v119.Y
	local v134 = math.max(0, v133)
	local v135 = math.clamp(v129, 0, v134)
	local v136 = v132 - v127.X
	if math.abs(v136) > 0.5 then
		v_u_5:Create(v118, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["CanvasPosition"] = Vector2.new(v132, v135)
		}):Play()
		return
	else
		local v137 = v135 - v127.Y
		if math.abs(v137) > 0.5 then
			v_u_5:Create(v118, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["CanvasPosition"] = Vector2.new(v132, v135)
			}):Play()
		end
	end
end
local v_u_139 = nil
local v_u_140 = nil
local function v_u_148(p141, p142, p143, p144) -- name: ringLayer
	local v145 = Instance.new("Frame")
	v145.BackgroundTransparency = 1
	v145.AnchorPoint = Vector2.new(0.5, 0.5)
	v145.Position = UDim2.fromScale(0.5, 0.5)
	v145.Size = UDim2.new(1, p142, 1, p142)
	local v146 = Instance.new("UICorner")
	v146.CornerRadius = UDim.new(0, p142 / 2 + 10)
	v146.Parent = v145
	local v147 = Instance.new("UIStroke")
	v147.Thickness = p143
	v147.Color = p144
	v147.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v147.LineJoinMode = Enum.LineJoinMode.Round
	v147.Parent = v145
	v145.Parent = p141
	return v145
end
local function v_u_153() -- name: makeRing
	-- upvalues: (copy) v_u_148, (copy) v_u_12, (copy) v_u_11, (ref) v_u_140, (copy) v_u_8, (ref) v_u_139
	local v149 = Instance.new("Frame")
	v149.Name = "PadSelection"
	v149.BackgroundTransparency = 1
	v149.Size = UDim2.fromScale(1, 1)
	v_u_148(v149, 0, 2, v_u_12)
	local v150 = v_u_148(v149, 4, 6, v_u_11)
	v_u_148(v149, 16, 3, v_u_12)
	v_u_140 = v150:FindFirstChildOfClass("UIStroke")
	local v151 = Instance.new("ImageLabel")
	v151.Name = "Press"
	v151.BackgroundColor3 = Color3.fromRGB(22, 22, 30)
	v151.BackgroundTransparency = 0.2
	v151.AnchorPoint = Vector2.new(0.5, 0.5)
	v151.Position = UDim2.new(1, 4, 1, 4)
	v151.Size = UDim2.fromOffset(30, 30)
	v151.ScaleType = Enum.ScaleType.Fit
	local v152 = Instance.new("UICorner")
	v152.CornerRadius = UDim.new(0.5, 0)
	v152.Parent = v151
	v151.Image = v_u_8.glyph(Enum.KeyCode.ButtonA)
	v151.ZIndex = 10
	v151.Parent = v149
	v_u_139 = v151
	return v149
end
local v_u_154 = false
function v_u_8.start() -- name: start
	-- upvalues: (ref) v_u_154, (copy) v_u_2, (copy) v_u_9, (copy) v_u_153, (ref) v_u_97, (ref) v_u_98, (ref) v_u_99, (copy) v_u_108, (copy) v_u_8, (copy) v_u_7, (copy) v_u_138, (ref) v_u_63, (ref) v_u_100, (ref) v_u_116, (ref) v_u_15, (copy) v_u_4, (copy) v_u_115, (ref) v_u_64, (copy) v_u_82, (ref) v_u_102, (ref) v_u_101, (copy) v_u_105, (copy) v_u_6, (ref) v_u_140, (copy) v_u_11, (copy) v_u_1
	if not v_u_154 then
		v_u_154 = true
		v_u_2.AutoSelectGuiEnabled = false
		v_u_9:WaitForChild("PlayerGui").SelectionImageObject = v_u_153()
		v_u_2:GetPropertyChangedSignal("SelectedObject"):Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_97, (ref) v_u_98, (ref) v_u_99, (ref) v_u_108, (ref) v_u_8, (ref) v_u_7, (ref) v_u_138, (ref) v_u_63, (ref) v_u_100, (ref) v_u_116, (ref) v_u_15, (ref) v_u_4, (ref) v_u_115, (ref) v_u_64, (ref) v_u_82, (ref) v_u_102, (ref) v_u_101, (ref) v_u_105
			local v155 = v_u_2.SelectedObject
			if v155 then
				v_u_97 = v155
				v_u_98 = v155.AbsolutePosition + v155.AbsoluteSize / 2
				v_u_99 = v_u_108(v155)
				if not v_u_8.quiet() then
					v_u_7.play("Hover")
				end
				v_u_138(v155)
				return
			elseif v_u_63 then
				v_u_97 = nil
				return
			else
				v_u_100 = os.clock()
				local v156 = v_u_97
				if v156 and (v156.Parent == nil or not v_u_8.shown(v156)) then
					if not v_u_116 then
						if not v_u_15 then
							return
						end
						v_u_116 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_4, (ref) v_u_116, (ref) v_u_2, (ref) v_u_15, (ref) v_u_99, (ref) v_u_8, (ref) v_u_115, (ref) v_u_98, (ref) v_u_64, (ref) v_u_82
							v_u_4.RenderStepped:Wait()
							v_u_4.Heartbeat:Wait()
							v_u_116 = false
							if v_u_2.SelectedObject or not v_u_15 then
								return
							else
								local v157 = v_u_99
								local v158
								if v157 and v_u_8.shown(v157) then
									v158 = v_u_115(v157, v_u_98)
								else
									v158 = nil
								end
								v_u_64 = os.clock() + 0.15
								if v158 then
									v_u_2.SelectedObject = v158
								else
									local v159 = Enum.KeyCode.None
									for _, v160 in table.clone(v_u_82) do
										if not v160.fn(v159) then
											continue
										end
										return
									end
								end
							end
						end)
					end
				elseif v156 then
					local v161 = v156:FindFirstAncestorWhichIsA("ScreenGui")
					local v_u_162
					if v161 == nil then
						v_u_162 = false
					else
						v_u_162 = v161.Name == "Main" and true or v161.Name == "Revive"
					end
					task.delay(0.05, function()
						-- upvalues: (copy) v_u_162, (ref) v_u_102, (ref) v_u_101, (ref) v_u_105
						if v_u_162 and (not v_u_102 and os.clock() - v_u_101 < 0.3) then
							v_u_102 = true
							v_u_105()
						end
					end)
				end
			end
		end)
		v_u_6.InputBegan:Connect(function(p163)
			-- upvalues: (ref) v_u_101, (ref) v_u_102
			if p163.KeyCode == Enum.KeyCode.ButtonB then
				v_u_101 = os.clock()
				v_u_102 = false
			end
		end)
		v_u_4.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_8, (ref) v_u_63, (ref) v_u_116, (ref) v_u_15, (ref) v_u_4, (ref) v_u_99, (ref) v_u_115, (ref) v_u_98, (ref) v_u_64, (ref) v_u_82, (ref) v_u_140, (ref) v_u_11
			local v164 = v_u_2.SelectedObject
			if v164 then
				if v_u_8.shown(v164) then
					v_u_98 = v164.AbsolutePosition + v164.AbsoluteSize / 2
					local v165 = v_u_140
					if v165 then
						local v166 = os.clock() * 6
						local v167 = math.sin(v166) * 0.5 + 0.5
						v165.Color = v_u_11:Lerp(Color3.new(1, 1, 1), v167 * 0.55)
					end
				else
					v_u_63 = true
					v_u_2.SelectedObject = nil
					v_u_63 = false
					if not v_u_116 then
						if not v_u_15 then
							return
						end
						v_u_116 = true
						task.spawn(function()
							-- upvalues: (ref) v_u_4, (ref) v_u_116, (ref) v_u_2, (ref) v_u_15, (ref) v_u_99, (ref) v_u_8, (ref) v_u_115, (ref) v_u_98, (ref) v_u_64, (ref) v_u_82
							v_u_4.RenderStepped:Wait()
							v_u_4.Heartbeat:Wait()
							v_u_116 = false
							if v_u_2.SelectedObject or not v_u_15 then
								return
							else
								local v168 = v_u_99
								local v169
								if v168 and v_u_8.shown(v168) then
									v169 = v_u_115(v168, v_u_98)
								else
									v169 = nil
								end
								v_u_64 = os.clock() + 0.15
								if v169 then
									v_u_2.SelectedObject = v169
								else
									local v170 = Enum.KeyCode.None
									for _, v171 in table.clone(v_u_82) do
										if not v171.fn(v170) then
											continue
										end
										return
									end
								end
							end
						end)
					end
				end
			else
				return
			end
		end)
		v_u_1:BindActionAtPriority("PadBack", function(_, p172)
			-- upvalues: (ref) v_u_6, (ref) v_u_102, (ref) v_u_105
			if p172 == Enum.UserInputState.Begin and not v_u_6:GetFocusedTextBox() then
				v_u_102 = true
				if v_u_105() then
					return Enum.ContextActionResult.Sink
				else
					return Enum.ContextActionResult.Pass
				end
			else
				return Enum.ContextActionResult.Pass
			end
		end, false, Enum.ContextActionPriority.Medium.Value, Enum.KeyCode.ButtonB)
		v_u_1:BindActionAtPriority("PadEnter", function(_, p173, p174)
			-- upvalues: (ref) v_u_6, (ref) v_u_2, (ref) v_u_8, (ref) v_u_82
			if p173 == Enum.UserInputState.Begin and not v_u_6:GetFocusedTextBox() then
				if v_u_2.SelectedObject then
					if p174.KeyCode ~= Enum.KeyCode.ButtonSelect then
						return Enum.ContextActionResult.Pass
					end
					v_u_8.clear()
					return Enum.ContextActionResult.Sink
				elseif v_u_2.MenuIsOpen then
					return Enum.ContextActionResult.Pass
				else
					local v175 = p174.KeyCode
					for _, v176 in table.clone(v_u_82) do
						if not v176.fn(v175) then
							continue
						end
						v177 = true
					end
					local v177 = false
					if v177 then
						return Enum.ContextActionResult.Sink
					else
						return Enum.ContextActionResult.Pass
					end
				end
			else
				return Enum.ContextActionResult.Pass
			end
		end, false, Enum.ContextActionPriority.Low.Value, Enum.KeyCode.DPadLeft, Enum.KeyCode.DPadRight, Enum.KeyCode.DPadUp, Enum.KeyCode.DPadDown, Enum.KeyCode.ButtonSelect)
	end
end
local v_u_178 = {
	[Enum.UserInputType.MouseMovement] = true,
	[Enum.UserInputType.Focus] = true,
	[Enum.UserInputType.None] = true
}
if v_u_4:IsStudio() then
	v_u_9:GetAttributeChangedSignal("DevPad"):Connect(function()
		-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_13, (copy) v_u_6, (ref) v_u_15, (copy) v_u_14
		local v179 = v_u_4:IsStudio()
		if v179 then
			v179 = v_u_9:GetAttribute("DevPad") == true
		end
		local v180 = v179 or v_u_13[v_u_6:GetLastInputType()] == true
		if v180 ~= v_u_15 then
			v_u_15 = v180
			v_u_14:Fire(v180)
		end
	end)
end
v_u_6.LastInputTypeChanged:Connect(function(p181)
	-- upvalues: (copy) v_u_178, (copy) v_u_4, (copy) v_u_9, (copy) v_u_13, (ref) v_u_16, (ref) v_u_15, (copy) v_u_14
	if not v_u_178[p181] then
		local v182 = v_u_4:IsStudio()
		if v182 then
			v182 = v_u_9:GetAttribute("DevPad") == true
		end
		if not v182 then
			if v_u_13[p181] then
				v_u_16 = p181
			end
			local v183 = v_u_13[p181] == true
			if v183 ~= v_u_15 then
				v_u_15 = v183
				v_u_14:Fire(v183)
			end
			return
		end
	end
end)
local function v184() -- name: repaint
	-- upvalues: (copy) v_u_38, (ref) v_u_139, (copy) v_u_8
	v_u_38()
	if v_u_139 then
		v_u_139.Image = v_u_8.glyph(Enum.KeyCode.ButtonA)
	end
end
v_u_8.changed:Connect(function(p185)
	-- upvalues: (copy) v_u_38, (ref) v_u_139, (copy) v_u_8, (copy) v_u_6
	v_u_38()
	if v_u_139 then
		v_u_139.Image = v_u_8.glyph(Enum.KeyCode.ButtonA)
	end
	if not (p185 or v_u_6:GetFocusedTextBox()) then
		v_u_8.clear()
	end
end)
v_u_6.GamepadConnected:Connect(v184)
return v_u_8