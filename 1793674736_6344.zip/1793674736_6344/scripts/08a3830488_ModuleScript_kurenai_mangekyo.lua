local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF2A2A")
local v_u_8 = Color3.fromRGB(170, 0, 12)
local v_u_9 = Color3.fromRGB(60, 0, 4)
local v_u_10 = Color3.fromRGB(20, 4, 6)
local v_u_11 = Color3.fromRGB(255, 140, 90)
local v_u_12 = Color3.new(1, 1, 1)
local v13 = Color3.fromRGB(255, 30, 24)
local v_u_14 = Color3.new(v13.R * 1.6, v13.G * 1.6, v13.B * 1.6)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.Material.ForceField
local v_u_17 = Enum.Material.SmoothPlastic
local function v_u_37(p18, p19, p20, p21, p22) -- name: picture
	-- upvalues: (copy) v_u_4
	local v23 = Color3.new
	local v24 = p21.R
	local v25 = math.min(v24, 1)
	local v26 = p21.G
	local v27 = math.min(v26, 1)
	local v28 = p21.B
	local v29 = v23(v25, v27, (math.min(v28, 1)))
	local v30 = math.max(p19, 0.03)
	local v31 = v_u_4.part
	local v32 = v30 * 2
	local v33 = v30 * 2
	local v34 = v31(Vector3.new(v32, 0.05, v33), p18, v29, {
		["transparency"] = 1
	})
	for _, v35 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v36 = Instance.new("Decal")
		v36.Face = v35
		v36.Texture = p20
		v36.Color3 = p21
		v36.Transparency = p22
		v36.Parent = v34
	end
	return v34
end
local function v_u_41(p38, p39) -- name: setAlpha
	for _, v40 in p38:GetChildren() do
		if not v40:IsA("Decal") then
			continue
		end
		v40.Transparency = p39
	end
end
local function v_u_52(p42, p43, p44, p45, p46) -- name: ribbon
	local v47 = Instance.new("Attachment")
	local v48 = p45 / 2
	v47.Position = Vector3.new(0, v48, 0)
	v47.Parent = p42
	local v49 = Instance.new("Attachment")
	local v50 = -p45 / 2
	v49.Position = Vector3.new(0, v50, 0)
	v49.Parent = p42
	local v51 = Instance.new("Trail")
	v51.Attachment0 = v47
	v51.Attachment1 = v49
	v51.Color = ColorSequence.new(p43, p44)
	v51.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v51.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.1) })
	v51.Lifetime = p46
	v51.LightEmission = 0.5
	v51.LightInfluence = 0
	v51.FaceCamera = true
	v51.MinLength = 0.05
	v51.Parent = p42
	return v51
end
local function v_u_58(p53, p54) -- name: axisFrame
	local v55 = p54.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p54.Unit
	local v56 = v55.Y
	local v57 = v55:Cross(math.abs(v56) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)).Unit
	return CFrame.fromMatrix(p53, v55, v57:Cross(v55), v57)
end
local function v_u_74(p_u_59, p_u_60, p_u_61, p62) -- name: makeTail
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_11
	local v_u_63 = Instance.new("Attachment")
	v_u_63.Parent = p_u_59
	local v_u_64 = Instance.new("Attachment")
	v_u_64.Parent = p_u_59
	local v_u_65 = {}
	local function v73(p66, p67, p68, p69, p70) -- name: layer
		-- upvalues: (copy) v_u_63, (copy) v_u_64, (copy) p_u_60, (copy) p_u_61, (copy) p_u_59, (copy) v_u_65
		local v71 = Instance.new("Beam")
		v71.Attachment0 = v_u_63
		v71.Attachment1 = v_u_64
		v71.Texture = p66
		v71.TextureMode = Enum.TextureMode.Wrap
		v71.TextureLength = 7
		v71.TextureSpeed = p70
		v71.Color = ColorSequence.new(p67)
		v71.LightEmission = p69
		v71.LightInfluence = 0
		v71.FaceCamera = true
		v71.Segments = 14
		v71.Width0 = p_u_60 * p68
		v71.Width1 = p_u_61 * p68
		v71.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.85, 0.05), NumberSequenceKeypoint.new(1, 0.6) })
		v71.Parent = p_u_59
		local v72 = v_u_65
		table.insert(v72, v71)
	end
	v73(v_u_6.FireBeam, v_u_7, 1, 0.6, -2.5)
	if not p62 then
		v73(v_u_6.Beam, v_u_11, 0.35, 1, -4)
	end
	return {
		["a0"] = v_u_63,
		["a1"] = v_u_64,
		["beams"] = v_u_65
	}
end
local function v_u_79(p75, p76) -- name: setTailAlpha
	local v77 = NumberSequence.new({ NumberSequenceKeypoint.new(0, (math.max(p76, 0.1))), NumberSequenceKeypoint.new(0.85, (math.max(p76, 0.05))), NumberSequenceKeypoint.new(1, (math.max(p76, 0.6))) })
	for _, v78 in p75.beams do
		v78.Transparency = v77
	end
end
local function v_u_87(p80, p81, p82, p83, p84) -- name: bendTail
	-- upvalues: (copy) v_u_58
	local v85 = (p83 - p81).Magnitude
	p80.a0.WorldCFrame = v_u_58(p81, p82)
	p80.a1.WorldCFrame = v_u_58(p83, p84)
	for _, v86 in p80.beams do
		v86.CurveSize0 = v85 * 0.45
		v86.CurveSize1 = v85 * 0.35
	end
end
return function(p_u_88)
	-- upvalues: (copy) v_u_3, (copy) v_u_37, (copy) v_u_1, (copy) v_u_41, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6, (copy) v_u_14, (copy) v_u_12, (copy) v_u_15, (copy) v_u_10, (copy) v_u_17, (copy) v_u_9, (copy) v_u_8, (copy) v_u_52, (copy) v_u_11, (copy) v_u_74, (copy) v_u_87, (copy) v_u_79, (copy) v_u_16, (copy) v_u_5
	local v89 = {}
	local function v_u_117(p_u_90, p_u_91, p_u_92, p93, p94, p_u_95, p_u_96, p97) -- name: flare
		-- upvalues: (ref) v_u_37, (ref) v_u_3, (copy) p_u_88, (ref) v_u_1, (ref) v_u_41
		local v_u_98 = p97 or 0
		local v_u_99 = math.random() * 3.141592653589793 * 2
		local v100 = v_u_37
		local v101 = v_u_3.CurrentCamera
		local v102
		if v101 then
			local v103 = v101.CFrame.Position - p_u_90
			v102 = v103.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v103.Unit
		else
			v102 = Vector3.new(0, 0, 1)
		end
		local v_u_104 = v100(p_u_88.facing(p_u_90 + v102 * 0.3, v102) * CFrame.Angles(0, v_u_99, 0), p_u_91, p93, p94, v_u_98)
		v_u_1:AddItem(v_u_104, p_u_95 + 0.1)
		p_u_88.animate(p_u_95, 0, function(p105)
			-- upvalues: (copy) v_u_104, (copy) p_u_91, (copy) p_u_92, (copy) p_u_90, (copy) v_u_99, (copy) p_u_95, (copy) p_u_96, (ref) v_u_3, (ref) p_u_88, (ref) v_u_41, (copy) v_u_98
			local v106 = v_u_104
			local v107 = p_u_91 + (p_u_92 - p_u_91) * (1 - (1 - p105) ^ 3)
			local v108 = math.max(v107, 0.03)
			local v109 = v108 * 2
			local v110 = v108 * 2
			v106.Size = Vector3.new(v109, 0.05, v110)
			local v111 = v_u_104
			local v112 = p_u_90
			local v113 = v_u_99 + p105 * p_u_95 * p_u_96
			local v114 = v_u_3.CurrentCamera
			local v115
			if v114 then
				local v116 = v114.CFrame.Position - v112
				v115 = v116.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v116.Unit
			else
				v115 = Vector3.new(0, 0, 1)
			end
			v111.CFrame = p_u_88.facing(v112 + v115 * 0.3, v115) * CFrame.Angles(0, v113, 0)
			v_u_41(v_u_104, v_u_98 + (1 - v_u_98) * p105 ^ 1.5)
			if p105 >= 1 then
				v_u_104:Destroy()
			end
		end)
	end
	v89.kurenai_mangekyo_a = {
		["cast"] = function(p118) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_88, (ref) v_u_12, (copy) v_u_117, (ref) v_u_6, (ref) v_u_14
			local v119 = p118.size
			local v120 = p118.eye + p118.dir * 1.2
			v_u_4.flash(v120, v_u_7, 2.8 * v119, 0.12)
			p_u_88.pop(v120, v_u_12, 1.1 * v119, 0.3 * v119, 0.1)
			if not p118.lite then
				v_u_117(v120, 1.9 * v119, 0.4 * v119, v_u_6.KurenaiTrinity, v_u_14, 0.12, -14)
			end
		end,
		["shot"] = function(p121, p122) -- name: bladeShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_37, (ref) v_u_6, (ref) v_u_14, (ref) v_u_12, (ref) v_u_15, (ref) v_u_10, (ref) v_u_17, (ref) v_u_1, (copy) p_u_88, (ref) v_u_9, (ref) v_u_3
			local v_u_123 = p121.size
			local v124 = p121.lite
			local v_u_125 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p122, v_u_7, {
				["transparency"] = 1
			})
			local v_u_126 = v_u_37(p122, 1.7 * v_u_123, v_u_6.KurenaiBlade, v_u_14, 0)
			local v127 = {
				["shape"] = v_u_15
			}
			local v_u_128 = v_u_4.part(Vector3.new(0.4, 0.4, 0.4) * v_u_123, p122, v_u_12, v127)
			local v_u_129 = { v_u_126, v_u_128 }
			local v_u_130 = {}
			local v_u_131
			if v124 then
				v_u_131 = nil
			else
				v_u_131 = v_u_37(p122, 2.2 * v_u_123, v_u_6.Ring, v_u_14, 0.35)
				table.insert(v_u_129, v_u_131)
				for _ = 1, 2 do
					local v132 = {
						["shape"] = nil,
						["transparency"] = 0.35,
						["shape"] = v_u_15
					}
					local v133 = v_u_4.part(Vector3.new(0.85, 0.85, 0.85) * v_u_123, p122, v_u_7, v132)
					local v134 = {
						["shape"] = v_u_15,
						["material"] = v_u_17
					}
					local v135 = v_u_4.part(Vector3.new(0.55, 0.55, 0.55) * v_u_123, p122, v_u_10, v134)
					table.insert(v_u_129, v133)
					table.insert(v_u_129, v135)
					table.insert(v_u_130, v135)
					table.insert(v_u_130, v133)
				end
			end
			for _, v136 in v_u_129 do
				v_u_1:AddItem(v136, 3)
			end
			v_u_1:AddItem(v_u_125, 3)
			p_u_88.streak(v_u_125, v_u_7, v_u_9, 1.1 * v_u_123, v124 and 0.1 or 0.16)
			if p121.mine then
				p_u_88.light(v_u_125, v_u_7, 9 * v_u_123)
			end
			local v_u_137 = false
			return {
				["place"] = function(p138, p139) -- name: place
					-- upvalues: (copy) v_u_125, (copy) v_u_128, (copy) v_u_123, (ref) v_u_3, (ref) p_u_88, (copy) v_u_126, (ref) v_u_131, (copy) v_u_130
					local v140 = p138.Position
					v_u_125.CFrame = p138
					v_u_128.CFrame = p138
					local v141 = -p139 * 22
					local v142 = 0.2 * v_u_123
					local v143 = v_u_3.CurrentCamera
					local v144
					if v143 then
						local v145 = v143.CFrame.Position - v140
						v144 = v145.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v145.Unit
					else
						v144 = Vector3.new(0, 0, 1)
					end
					v_u_126.CFrame = p_u_88.facing(v140 + v144 * (v142 or 0.3), v144) * CFrame.Angles(0, v141, 0)
					local v146 = v_u_131
					if v146 then
						local v147 = 0.1 * v_u_123
						local v148 = v_u_3.CurrentCamera
						local v149
						if v148 then
							local v150 = v148.CFrame.Position - v140
							v149 = v150.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v150.Unit
						else
							v149 = Vector3.new(0, 0, 1)
						end
						v146.CFrame = p_u_88.facing(v140 + v149 * (v147 or 0.3), v149) * CFrame.Angles(0, 0, 0)
						local v151 = p_u_88.facing
						local v152 = v_u_3.CurrentCamera
						local v153
						if v152 then
							local v154 = v152.CFrame.Position - v140
							v153 = v154.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v154.Unit
						else
							v153 = Vector3.new(0, 0, 1)
						end
						local v155 = v151(v140, v153)
						for v156 = 1, #v_u_130, 2 do
							local v157 = p139 * 14 + (v156 - 1) * 3.141592653589793 / 2
							local v158 = (v155.RightVector * math.cos(v157) + v155.LookVector * math.sin(v157)) * 2 * v_u_123
							local v159 = v_u_130[v156]
							local v160 = CFrame.new
							local v161 = v140 + v158
							local v162 = v_u_3.CurrentCamera
							local v163
							if v162 then
								local v164 = v162.CFrame.Position - v140
								v163 = v164.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v164.Unit
							else
								v163 = Vector3.new(0, 0, 1)
							end
							v159.CFrame = v160(v161 + v163 * 0.3 * v_u_123)
							v_u_130[v156 + 1].CFrame = CFrame.new(v140 + v158)
						end
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_137, (copy) v_u_125, (ref) v_u_1, (copy) v_u_129
					if not v_u_137 then
						v_u_137 = true
						local v165 = v_u_125:FindFirstChildWhichIsA("PointLight")
						if v165 then
							v165:Destroy()
						end
						v_u_1:AddItem(v_u_125, 0.2)
						for _, v166 in v_u_129 do
							v166:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p167, p168) -- name: bladeImpact
			-- upvalues: (copy) v_u_117, (ref) v_u_6, (ref) v_u_14, (copy) p_u_88, (ref) v_u_3, (ref) v_u_7, (ref) v_u_12, (ref) v_u_4
			local v169 = p167.size
			v_u_117(p168, 1.2 * v169, 4.8 * v169, v_u_6.KurenaiTrinity, v_u_14, 0.24, -10)
			local v170 = p_u_88.facing
			local v171 = v_u_3.CurrentCamera
			local v172
			if v171 then
				local v173 = v171.CFrame.Position - p168
				v172 = v173.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v173.Unit
			else
				v172 = Vector3.new(0, 0, 1)
			end
			local v174 = v170(p168, v172)
			local v175 = math.random() * 3.141592653589793 * 2
			for v176 = 0, 2 do
				local v177 = v175 + v176 * 3.141592653589793 * 2 / 3
				local v178 = v174.RightVector * math.cos(v177) + v174.LookVector * math.sin(v177)
				local v179 = v174.RightVector
				local v180 = v177 - 0.6
				local v181 = v179 * math.cos(v180)
				local v182 = v174.LookVector
				local v183 = v177 - 0.6
				local v184 = v181 + v182 * math.sin(v183)
				p_u_88.thin(p_u_88.rod(p168 + v178 * 0.6 * v169, p168 + v184 * 3.8 * v169, 0.4 * v169, v_u_7), 0.18)
			end
			p_u_88.pop(p168, v_u_7, 1.2 * v169, 4.2 * v169, 0.2, 0.35)
			p_u_88.pop(p168, v_u_12, 0.8 * v169, 2 * v169, 0.12)
			v_u_4.ring(p_u_88.ground(p168), v_u_7, p167.ability.radius * 1.1, 0.3, v_u_6.Ring)
			p_u_88.burst("Impact", p168, v_u_7, 0.85 * v169)
			p_u_88.hitSound(p168)
		end,
		["hit"] = p_u_88.simpleHit(v_u_7, 0.6)
	}
	v89.kurenai_mangekyo_e = {
		["castSound"] = "Fireball",
		["loopSound"] = "Flames",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["hit"] = nil,
		["cast"] = function(p185) -- name: cast
			-- upvalues: (copy) p_u_88, (ref) v_u_7, (copy) v_u_117, (ref) v_u_6, (ref) v_u_14
			p_u_88.skillCast(p185, v_u_7)
			if not p185.lite then
				local v186 = p185.size
				v_u_117(p185.eye + p185.dir * 1.2, 0.5 * v186, 3 * v186, v_u_6.KurenaiTrinity, v_u_14, 0.22, -8)
			end
		end,
		["windup"] = function(p187, p188, p189) -- name: windup
			-- upvalues: (copy) p_u_88, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6
			local v190 = p187.ability.radius
			local v191 = p_u_88.ground(p188, 0)
			v_u_4.flash(v191 + Vector3.new(0, 1.5, 0), v_u_7, 6, math.max(p189, 0.1) + 0.1)
			v_u_4.ring(v191, v_u_7, v190 * 1.1, math.max(p189, 0.1) + 0.15, v_u_6.Ring)
		end,
		["zone"] = function(p192, p193, p_u_194) -- name: zone
			-- upvalues: (copy) p_u_88, (ref) v_u_37, (ref) v_u_6, (ref) v_u_14, (ref) v_u_1, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_15, (ref) v_u_17, (ref) v_u_52, (ref) v_u_3, (ref) v_u_11
			local v_u_195 = p192.ability.radius
			local v_u_196 = p_u_88.ground(p193, 0)
			local v_u_197 = p192.lite
			local v198 = p_u_194 + 1
			local v_u_199 = v_u_37(CFrame.new(v_u_196 + Vector3.new(0, 0.4, 0)), 0.1, v_u_6.Ring, v_u_14, 0)
			local v_u_200 = v_u_37(CFrame.new(v_u_196 + Vector3.new(0, 0.45, 0)), 0.1, v_u_6.Ring, v_u_14, 0.1)
			v_u_1:AddItem(v_u_199, v198)
			v_u_1:AddItem(v_u_200, v198)
			local v_u_201 = { p_u_88.loopAt("Fire", v_u_196, v_u_7, v_u_195 / 4.5) }
			if not v_u_197 then
				for v202 = 0, 2 do
					local v203 = v202 * 3.141592653589793 * 2 / 3
					local v204 = math.cos(v203)
					local v205 = math.sin(v203)
					local v206 = v_u_196 + Vector3.new(v204, 0, v205) * v_u_195 * 0.55
					local v207 = p_u_88.loopAt
					local v208 = v_u_8
					table.insert(v_u_201, v207("Fire", v206, v208, 1))
				end
				for v209 = 0, 3 do
					local v210 = 0.7853981633974483 + v209 * 3.141592653589793 / 2
					local v211 = math.cos(v210)
					local v212 = math.sin(v210)
					local v213 = v_u_196 + Vector3.new(v211, 0, v212) * v_u_195 * 1.05
					local v214 = p_u_88.loopAt
					local v215 = v_u_7
					table.insert(v_u_201, v214("Fire", v213, v215, 0.8))
				end
			end
			p_u_88.mark(v_u_196, v_u_9, v_u_195 * 1.05, p_u_194 + 0.6, v_u_6.Glow, 0.3)
			local v_u_216 = {}
			for _, v217 in {
				{
					["track"] = 1,
					["speed"] = 2.4,
					["phase"] = 0
				},
				{
					["track"] = 1,
					["speed"] = 2.4,
					["phase"] = 3.141592653589793
				},
				{
					["track"] = 0.55,
					["speed"] = -3.2,
					["phase"] = 1.5707963267948966
				}
			} do
				local v218 = {
					["shape"] = v_u_15,
					["material"] = v_u_17
				}
				local v219 = v_u_4.part(Vector3.new(2, 2, 2), CFrame.new(v_u_196), v_u_10, v218)
				local v220 = {
					["shape"] = nil,
					["transparency"] = 0.45,
					["shape"] = v_u_15
				}
				local v221 = v_u_4.part(Vector3.new(3, 3, 3), CFrame.new(v_u_196), v_u_7, v220)
				v_u_1:AddItem(v219, v198)
				v_u_1:AddItem(v221, v198)
				v_u_52(v221, v_u_7, v_u_9, 1.5, v_u_197 and 0.25 or 0.45)
				if not v_u_197 then
					local v222 = p_u_88.loop
					local v223 = v_u_7
					table.insert(v_u_201, v222("Trail", v221, v223, 0.6))
				end
				local v224 = {
					["head"] = v219,
					["glow"] = v221,
					["track"] = v217.track,
					["speed"] = v217.speed,
					["phase"] = v217.phase
				}
				table.insert(v_u_216, v224)
			end
			local v_u_225 = os.clock()
			local v_u_226 = 0.5
			local v_u_227 = nil
			p_u_88.runNow(function()
				-- upvalues: (copy) v_u_225, (ref) v_u_227, (copy) v_u_199, (copy) v_u_195, (copy) v_u_200, (copy) v_u_196, (copy) v_u_216, (ref) v_u_3, (ref) v_u_226, (ref) p_u_88, (ref) v_u_7, (copy) v_u_197, (ref) v_u_11, (ref) v_u_4, (ref) v_u_6, (ref) v_u_1, (copy) p_u_194
				local v228 = os.clock()
				local v229 = v228 - v_u_225
				local v230 = v229 / 0.25
				local v231 = math.clamp(v230, 0, 1) - 1
				local v232 = v231 * 2.7 * v231 * v231 + 1 + v231 * 1.7 * v231
				local v233 = v_u_227
				local v234
				if v233 then
					local v235 = (v228 - v233) / 0.22
					v234 = math.clamp(v235, 0, 1)
				else
					v234 = 0
				end
				local v236 = v232 * (1 - v234 * v234)
				local v237 = v_u_199
				local v238 = v_u_195 * 1.1 * v236
				local v239 = math.max(v238, 0.03)
				local v240 = v239 * 2
				local v241 = v239 * 2
				v237.Size = Vector3.new(v240, 0.05, v241)
				local v242 = v_u_200
				local v243 = v_u_195 * 0.62 * v236
				local v244 = math.max(v243, 0.03)
				local v245 = v244 * 2
				local v246 = v244 * 2
				v242.Size = Vector3.new(v245, 0.05, v246)
				v_u_199.CFrame = CFrame.new(v_u_196 + Vector3.new(0, 0.4, 0)) * CFrame.Angles(0, v229 * 0.8, 0)
				v_u_200.CFrame = CFrame.new(v_u_196 + Vector3.new(0, 0.45, 0)) * CFrame.Angles(0, -v229 * 1.1, 0)
				for _, v247 in v_u_216 do
					local v248 = v247.phase + v229 * v247.speed
					local v249 = v_u_195 * v247.track * v236
					local v250 = v_u_196
					local v251 = math.cos(v248) * v249
					local v252 = math.sin(v248) * v249
					local v253 = v250 + Vector3.new(v251, 1.3, v252)
					v247.head.CFrame = CFrame.new(v253)
					local v254 = v247.glow
					local v255 = CFrame.new
					local v256 = v_u_3.CurrentCamera
					local v257
					if v256 then
						local v258 = v256.CFrame.Position - v253
						v257 = v258.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v258.Unit
					else
						v257 = Vector3.new(0, 0, 1)
					end
					v254.CFrame = v255(v253 - v257 * 0.9)
				end
				if v_u_226 <= v229 and not v233 then
					v_u_226 = v_u_226 + 0.5
					local v259 = math.random() * 3.141592653589793 * 2
					local v260 = math.random() * v_u_195 * 0.8
					local v261 = v_u_196
					local v262 = math.cos(v259) * v260
					local v263 = math.sin(v259) * v260
					local v264 = v261 + Vector3.new(v262, 0, v263)
					p_u_88.burst("Fire", v264, v_u_7, 0.9)
					if not v_u_197 then
						p_u_88.spikes(v264 + Vector3.new(0, 1, 0), v_u_11, 3, 6, 0.3, Vector3.new(0, 1, 0), 0.5)
						p_u_88.thin(p_u_88.pillar(v264, 7, 1.6, v_u_7, 0.2), 0.3)
					end
					v_u_4.ring(v_u_196, v_u_7, v_u_195 * 0.9, 0.3, v_u_6.Ring)
				end
				if not v233 or v234 < 1 then
					return v229 < p_u_194 + 1
				end
				v_u_199:Destroy()
				v_u_200:Destroy()
				for _, v265 in v_u_216 do
					v265.head:Destroy()
					v_u_1:AddItem(v265.glow, 0.5)
					v265.glow.Transparency = 1
				end
				return false
			end)
			return function()
				-- upvalues: (ref) v_u_227, (copy) v_u_201, (ref) p_u_88, (copy) v_u_196, (ref) v_u_7, (copy) v_u_195, (copy) v_u_197
				if not v_u_227 then
					v_u_227 = os.clock()
					for _, v266 in v_u_201 do
						v266()
					end
					p_u_88.after(0.22, function()
						-- upvalues: (ref) p_u_88, (ref) v_u_196, (ref) v_u_7, (ref) v_u_195, (ref) v_u_197
						p_u_88.pop(v_u_196 + Vector3.new(0, 1.5, 0), v_u_7, 2, v_u_195 * 1.4, 0.3, 0.3)
						p_u_88.burst("Impact", v_u_196 + Vector3.new(0, 1, 0), v_u_7, 1.4)
						if not v_u_197 then
							p_u_88.burst("Fire", v_u_196, v_u_7, 1.3)
						end
					end)
				end
			end
		end,
		["hit"] = function(p267, p268, _) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_7, (ref) v_u_11
			p_u_88.burst("Impact", p268, v_u_7, 0.6)
			if not p267.lite then
				p_u_88.spikes(p268, v_u_11, 2, 3, 0.2, Vector3.new(0, 1, 0), 0.6)
			end
		end
	}
	local v_u_269 = {}
	setmetatable(v_u_269, {
		["__mode"] = "k"
	})
	local function v_u_339(p270, p271, p272) -- name: raise
		-- upvalues: (copy) p_u_88, (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_15, (ref) v_u_37, (ref) v_u_6, (ref) v_u_10, (ref) v_u_14, (ref) v_u_1, (ref) v_u_74, (ref) v_u_41, (ref) v_u_87, (ref) v_u_79
		local v273 = p270.ability.radius
		local v_u_274 = p_u_88.ground(p271, 0)
		local v_u_275 = math.max(p272, 0.14)
		local v276 = p270.lite
		local v277 = v_u_275 + 0.55 + 0.45 + 2.5
		local v_u_278 = v_u_274 + p270.dir * 22 + Vector3.new(0, 32, 0)
		local v279 = v_u_3.CurrentCamera
		local v_u_280
		if v279 then
			local v281 = v279.CFrame.Position - v_u_278
			v_u_280 = v281.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v281.Unit
		else
			v_u_280 = Vector3.new(0, 0, 1)
		end
		local v282 = {
			["shape"] = v_u_15
		}
		local v_u_283 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v_u_278), v_u_7, v282)
		local v_u_284 = v_u_37(p_u_88.facing(v_u_278 + v_u_280 * 28 * 0.52, v_u_280), 0.1, v_u_6.KurenaiTrinity, v_u_10, 0)
		local v_u_285 = v_u_37(p_u_88.facing(v_u_278 - v_u_280 * 3, v_u_280), 0.1, v_u_6.Glow, v_u_14, 0.25)
		local v_u_286 = { v_u_283, v_u_284, v_u_285 }
		for _, v287 in v_u_286 do
			v_u_1:AddItem(v287, v277)
		end
		local v_u_288 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_274), v_u_7, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_288, v277)
		local v289 = p270.dir.Z
		local v290 = p270.dir.X
		local v291 = math.atan2(v289, v290)
		local v_u_292 = {}
		for v293 = 1, 9 do
			local v294 = v291 + (v293 - 0.5) / 9 * 3.141592653589793 * 2
			local v295 = math.cos(v294)
			local v296 = math.sin(v294)
			local v297 = Vector3.new(v295, 0, v296)
			local v298 = {
				["tail"] = v_u_74(v_u_288, 5, 1.4, v276),
				["root"] = v_u_274 + v297 * v273 * 0.95,
				["out"] = v297,
				["phase"] = v293 * 1.3
			}
			table.insert(v_u_292, v298)
		end
		local v_u_299 = {
			["g"] = nil,
			["moon"] = nil,
			["born"] = nil,
			["span"] = nil,
			["landed"] = nil,
			["g"] = v_u_274,
			["moon"] = v_u_286,
			["born"] = os.clock(),
			["span"] = v_u_275
		}
		p_u_88.runNow(function()
			-- upvalues: (copy) v_u_299, (copy) v_u_275, (copy) v_u_283, (copy) v_u_284, (ref) p_u_88, (copy) v_u_278, (copy) v_u_280, (copy) v_u_285, (ref) v_u_41, (copy) v_u_292, (copy) v_u_274, (ref) v_u_87, (ref) v_u_79, (copy) v_u_288, (copy) v_u_286
			local v300 = os.clock()
			local v301 = v300 - v_u_299.born
			local v302 = v301 / v_u_275
			local v303 = v_u_299.landed
			local v304 = not v303 and 0 or v300 - v303
			local v305 = (v304 - 0.55) / 1.05
			local v306 = math.clamp(v305, 0, 1)
			local v307 = v301 / 0.22
			local v308 = math.clamp(v307, 0, 1) - 1
			local v309 = v308 * 2.7 * v308 * v308 + 1 + v308 * 1.7 * v308
			v_u_283.Size = Vector3.new(28, 28, 28) * v309
			local v310 = v_u_284
			local v311 = v309 * 11.76
			local v312 = math.max(v311, 0.03)
			local v313 = v312 * 2
			local v314 = v312 * 2
			v310.Size = Vector3.new(v313, 0.05, v314)
			v_u_284.CFrame = p_u_88.facing(v_u_278 + v_u_280 * 28 * 0.52, v_u_280) * CFrame.Angles(0, -v301 * 0.6, 0)
			local v315 = v_u_285
			local v316 = v309 * 42
			local v317 = math.max(v316, 0.03)
			local v318 = v317 * 2
			local v319 = v317 * 2
			v315.Size = Vector3.new(v318, 0.05, v319)
			v_u_283.Transparency = v306
			v_u_41(v_u_284, v306)
			v_u_41(v_u_285, v306 * 0.75 + 0.25)
			local v320 = (v304 - 0.55) / 0.45
			local v321 = math.clamp(v320, 0, 1)
			for _, v322 in v_u_292 do
				local v323 = v322.root
				local v324 = v301 * 6 + v322.phase
				local v325 = math.sin(v324)
				local v326, v327
				if v302 < 0.6 then
					local v328 = 1 - (1 - v302 / 0.6) ^ 3
					v326 = v323 + v322.out * (2 + 5 * v328) + Vector3.new(0, 1, 0) * (2 + 24 * v328) + v322.out:Cross(Vector3.new(0, 1, 0)) * v325 * 2
					v327 = (v322.out * 0.3 + Vector3.new(0, 1, 0)).Unit
				elseif v302 < 1 then
					local v329 = (v302 - 0.6) / 0.4
					local v330 = v323 + v322.out * 7 + Vector3.new(0, 26, 0)
					local v331 = v_u_274 + Vector3.new(0, 1, 0) - v322.out * 1.5
					local v332 = v329 * v329
					local v333 = v330:Lerp(v331, v332)
					local v334 = v332 * 3.141592653589793
					v326 = v333 + Vector3.new(0, 1, 0) * math.sin(v334) * 6
					v327 = (Vector3.new(0, 1, 0) * (1 - 2 * v332) - v322.out * v332).Unit
				else
					local v335 = v_u_274 + Vector3.new(0, 1, 0) * (v321 * 6 + 1) - v322.out * 1.5
					local v336 = v322.out:Cross(Vector3.new(0, 1, 0))
					local v337 = v301 * 9 + v322.phase
					v326 = v335 + v336 * math.sin(v337) * 0.8
					v327 = (Vector3.new(-0, -1, -0) - v322.out * 0.4).Unit
				end
				v_u_87(v322.tail, v323, Vector3.new(0, 1, 0), v326, v327)
				if v321 <= 0 then
					continue
				end
				v_u_79(v322.tail, v321)
			end
			if v306 < 1 then
				return v301 < v_u_275 + 0.55 + 0.45 + 2.4
			end
			v_u_288:Destroy()
			for _, v338 in v_u_286 do
				v338:Destroy()
			end
			return false
		end)
		return v_u_299
	end
	local function v_u_358(p340, p341, p342, p343) -- name: carve
		-- upvalues: (copy) p_u_88, (ref) v_u_7
		local v344 = p343 and 4 or 7
		for v345 = 0, 2 do
			local v346 = p342 + v345 * 3.141592653589793 * 2 / 3
			local v347 = math.cos(v346)
			local v348 = math.sin(v346)
			local v349 = p340 + Vector3.new(v347, 0, v348) * 2.5
			for v350 = 1, v344 do
				local v351 = v350 / v344
				local v352 = v346 - v351 * 1.1
				local v353 = (p341 * 0.95 - 2.5) * v351 + 2.5
				local v354 = math.cos(v352)
				local v355 = math.sin(v352)
				local v356 = p340 + Vector3.new(v354, 0, v355) * v353
				local v357 = (1 - v351 * 0.75) * 3.2
				p_u_88.groundLine(v349, v356, v357, v_u_7, 1.8, 0.05)
				v349 = v356
			end
		end
	end
	v89.kurenai_mangekyo_r = {
		["cast"] = function(p359) -- name: cast
			-- upvalues: (copy) p_u_88, (ref) v_u_7, (copy) v_u_117, (ref) v_u_6, (ref) v_u_14, (ref) v_u_4
			p_u_88.skillCast(p359, v_u_7, true)
			local v360 = p359.size
			local v361 = p359.eye + p359.dir * 1.4
			v_u_117(v361, 0.6 * v360, 5 * v360, v_u_6.KurenaiTrinity, v_u_14, 0.3, -9)
			if not p359.lite then
				v_u_117(v361, 4 * v360, 0.5 * v360, v_u_6.KurenaiTrinity, v_u_14, 0.25, 12, 0.2)
			end
			if p359.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p362, p363, p364) -- name: windup
			-- upvalues: (copy) v_u_339, (copy) v_u_269, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (copy) p_u_88, (ref) v_u_11
			local v365 = v_u_339(p362, p363, p364)
			v_u_269[p362] = v365
			local v366 = p362.ability.radius
			v_u_4.ring(v365.g, v_u_7, v366 * 1.05, math.max(p364, 0.14) + 0.15, v_u_6.Ring)
			p_u_88.mark(v365.g, v_u_7, v366, math.max(p364, 0.14) + 0.3, v_u_6.Glow, 0.4)
			if not p362.lite then
				p_u_88.spikes(v365.g + Vector3.new(0, 1, 0), v_u_11, 9, v366, math.max(p364, 0.14), Vector3.new(0, 1, 0), 0.9)
			end
		end,
		["land"] = function(p367, p368) -- name: land
			-- upvalues: (copy) p_u_88, (copy) v_u_269, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7, (ref) v_u_16, (ref) v_u_11, (ref) v_u_6, (copy) v_u_358, (copy) v_u_117, (ref) v_u_14, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5
			local v369 = p367.ability.radius
			local v370 = p_u_88.ground(p368, 0)
			local v371 = p367.lite
			local v372 = v_u_269[p367]
			v_u_269[p367] = nil
			if v372 then
				v372.landed = os.clock()
			end
			v_u_4.flash(v370 + Vector3.new(0, 3, 0), v_u_12, 16, 0.2)
			v_u_4.flash(v370 + Vector3.new(0, 3, 0), v_u_7, v369 * 1.7, 0.3)
			p_u_88.pop(v370 + Vector3.new(0, 2, 0), v_u_7, 4, v369 * 2.4, 0.55, 0.15, v_u_16)
			p_u_88.pop(v370 + Vector3.new(0, 2, 0), v_u_11, 3, v369 * 1.2, 0.3, 0.35)
			p_u_88.dome(v370, v369 * 1.25, v_u_7, 0.5)
			v_u_4.ring(v370, v_u_12, v369 * 1.4, 0.45, v_u_6.Shockwave)
			v_u_4.ring(v370, v_u_7, v369 * 1.8, 0.65, v_u_6.Ring)
			p_u_88.burst("Shockwave", v370 + Vector3.new(0, 0.3, 0), v_u_7, v369 / 12)
			p_u_88.burst("Explosion", v370 + Vector3.new(0, 2, 0), v_u_7, 2.2)
			local v373 = v_u_358
			local v374 = p367.dir.Z
			local v375 = p367.dir.X
			v373(v370, v369, math.atan2(v374, v375), v371)
			v_u_117(v370 + Vector3.new(0, 4, 0), 3, v369 * 1.2, v_u_6.KurenaiTrinity, v_u_14, 0.45, -6, 0.1)
			p_u_88.chunks(v370 + Vector3.new(0, 1, 0), { v_u_10, v_u_8, v_u_9 }, v371 and 6 or 14, 50, 1.2, 1.2, false, 1)
			p_u_88.spikes(v370 + Vector3.new(0, 2, 0), v_u_11, v371 and 6 or 14, v369 * 1.5, 0.35, nil, nil, true)
			p_u_88.mark(v370, v_u_9, v369 * 1.1, 2, v_u_6.CrackGlow, 0.15)
			if not v371 then
				p_u_88.burst("Fire", v370, v_u_7, 2)
			end
			v_u_5.play("Explosion", {
				["at"] = v370,
				["volume"] = p367.mine and 1 or 0.6
			})
			if p367.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end,
		["hit"] = function(p376, p377, _) -- name: hit
			-- upvalues: (copy) p_u_88, (ref) v_u_7, (ref) v_u_11
			p_u_88.burst("Impact", p377, v_u_7, 0.8)
			if not p376.lite then
				p_u_88.glint(p377, v_u_11, 3, 0.14)
			end
		end
	}
	return v89
end