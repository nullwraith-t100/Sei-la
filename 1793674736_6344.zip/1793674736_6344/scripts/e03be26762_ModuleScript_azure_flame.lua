local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(8, 10, 22)
local v_u_6 = Color3.fromRGB(150, 220, 255)
local v_u_7 = Color3.new(1, 1, 1)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_3
	return {
		["w4_azure_flame"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (ref) v_u_3
			local v_u_11 = v_u_2.color(p10.color)
			local v_u_12 = v_u_2.color(p10.color2)
			local v13 = p_u_9.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_17 = p_u_8.throb(p_u_9, 3, 1, 1.8, function(p15)
				-- upvalues: (ref) p_u_8, (copy) p_u_9, (ref) v_u_2, (copy) v_u_11, (ref) v_u_4, (copy) v_u_12
				local v16 = p_u_8.feetAt(p_u_9, p15, 0.15)
				v_u_2.ring(v16, v_u_11, 6 * p_u_9.fx, 0.5, v_u_4.Shockwave)
				v_u_2.ring(v16, v_u_12, 7.5 * p_u_9.fx, 0.45, v_u_4.Ring)
			end)
			local v_u_18 = 0
			local v19 = p_u_9.ticks
			local function v21(_, _, p20)
				-- upvalues: (ref) v_u_18, (copy) v_u_17
				v_u_18 = v_u_18 + p20 * (0.8 + v_u_17() * 5)
			end
			table.insert(v19, v21)
			local v_u_31 = p_u_8.group(p_u_9, function(p22)
				-- upvalues: (copy) p_u_9, (ref) p_u_8
				local v23 = p22.Position
				local v24 = p_u_9.headY + p_u_9.eyeLift
				local v25 = v23 + Vector3.new(0, v24, 0)
				local v26 = p_u_8.camPos() - v25
				local v27 = v26.X
				local v28 = v26.Z
				local v29 = Vector3.new(v27, 0, v28)
				local v30
				if v29.Magnitude > 0.001 then
					v30 = v29.Unit
				else
					v30 = p22.LookVector
				end
				return CFrame.lookAt(v25, v25 + v30)
			end)
			local v_u_32 = v_u_18
			for v_u_33 = 1, 6 do
				local v_u_34 = v_u_33 * 1.7
				p_u_8.add(p_u_9, p_u_8.dark(p_u_8.ball(v_u_14 * 0.46, v_u_5, 0, Enum.Material.SmoothPlastic)), function()
					-- upvalues: (ref) v_u_32, (copy) v_u_33, (copy) v_u_31, (copy) v_u_14
					local v35 = CFrame.new
					local v36 = v_u_32 + v_u_33 / 6 * 3.141592653589793 * 2
					return v35((v_u_31.cf * CFrame.new(math.cos(v36) * 2.05 * v_u_14, math.sin(v36) * 2.05 * v_u_14, 0)).Position)
				end)
				local v37 = p_u_8.blob(Vector3.new(0.6, 1.4, 0.6) * v_u_14, v_u_11, 0.22)
				local v38 = p_u_8.blob(Vector3.new(0.26, 0.75, 0.26) * v_u_14, v_u_7, 0.1)
				local v_u_39 = v37:FindFirstChildOfClass("SpecialMesh")
				if not v_u_39 then
					v_u_39 = Instance.new("SpecialMesh")
					v_u_39.MeshType = Enum.MeshType.Sphere
					v_u_39.Parent = v37
				end
				local v_u_40 = v38:FindFirstChildOfClass("SpecialMesh")
				if not v_u_40 then
					v_u_40 = Instance.new("SpecialMesh")
					v_u_40.MeshType = Enum.MeshType.Sphere
					v_u_40.Parent = v38
				end
				p_u_8.add(p_u_9, v37, function(_, p41)
					-- upvalues: (copy) v_u_34, (copy) v_u_17, (copy) v_u_39, (ref) v_u_32, (copy) v_u_33, (copy) v_u_31, (copy) v_u_14
					local v42 = v_u_34
					local v43 = p41 * 13 + v42
					local v44 = math.sin(v43) * 0.12 + 1
					local v45 = p41 * 23 + v42 * 2.3
					local v46 = v44 + math.sin(v45) * 0.07 + v_u_17() * 0.45
					v_u_39.Scale = Vector3.new(1, v46, 1)
					local v47 = CFrame.new
					local v48 = v_u_32 + v_u_33 / 6 * 3.141592653589793 * 2
					local v49 = (v_u_31.cf * CFrame.new(math.cos(v48) * 2.05 * v_u_14, math.sin(v48) * 2.05 * v_u_14, 0)).Position
					local v50 = v_u_14 * 0.15 + v_u_14 * 1.4 * v46 * 0.42
					return v47(v49 + Vector3.new(0, v50, 0))
				end)
				p_u_8.add(p_u_9, v38, function(_, p51)
					-- upvalues: (copy) v_u_34, (copy) v_u_17, (copy) v_u_40, (ref) v_u_32, (copy) v_u_33, (copy) v_u_31, (copy) v_u_14
					local v52 = v_u_34 + 0.5
					local v53 = p51 * 13 + v52
					local v54 = math.sin(v53) * 0.12 + 1
					local v55 = p51 * 23 + v52 * 2.3
					local v56 = v54 + math.sin(v55) * 0.07 + v_u_17() * 0.45
					v_u_40.Scale = Vector3.new(1, v56, 1)
					local v57 = CFrame.new
					local v58 = v_u_32 + v_u_33 / 6 * 3.141592653589793 * 2
					local v59 = (v_u_31.cf * CFrame.new(math.cos(v58) * 2.05 * v_u_14, math.sin(v58) * 2.05 * v_u_14, 0)).Position
					local v60 = v_u_14 * 0.1 + v_u_14 * 0.75 * v56 * 0.4
					return v57(v59 + Vector3.new(0, v60, 0))
				end)
			end
			for v61 = 1, 5 do
				local v_u_62 = (v61 - 3) / 2
				local v_u_63 = v61 * 2.9
				local v_u_64 = ((1 - math.abs(v_u_62)) * 1.4 + 2.4) * v_u_14
				local v65 = v_u_62 * 0.75 * v_u_14
				local v66 = p_u_9.headY * 0.55
				local v67 = v_u_14 * 0.55
				local v_u_68 = Vector3.new(v65, v66, v67)
				local function v_u_83(p69, p70) -- name: along
					-- upvalues: (copy) v_u_62, (copy) v_u_63, (copy) v_u_64, (copy) v_u_17, (copy) v_u_68
					local v71 = v_u_62 * 0.55
					local v72 = p69 * 3.1 + v_u_63
					local v73 = v71 + math.sin(v72) * 0.07
					local v74 = p69 * 2.3 + v_u_63
					local v75 = math.sin(v74) * 0.05 + 0.32
					local v76 = CFrame.Angles(v75, 0, -v73):VectorToWorldSpace(Vector3.new(0, 1, 0))
					local v77 = v_u_64 * p70
					local v78 = v_u_63
					local v79 = p69 * 13 + v78
					local v80 = math.sin(v79) * 0.12 + 1
					local v81 = p69 * 23 + v78 * 2.3
					local v82 = v_u_68 + v76 * (v77 * (v80 + math.sin(v81) * 0.07 + v_u_17() * 0.45)) * 0.5
					return CFrame.lookAt(v82, v82 + v76) * CFrame.Angles(1.5707963267948966, 0, 0)
				end
				local v84 = p_u_8.blob
				local v85 = v_u_14 * 0.95
				local v86 = v_u_14 * 0.95
				local v87 = v84(Vector3.new(v85, v_u_64, v86), v_u_11, 0.3)
				local v88 = p_u_8.blob
				local v89 = v_u_14 * 0.42
				local v90 = v_u_64 * 0.7
				local v91 = v_u_14 * 0.42
				local v92 = v88(Vector3.new(v89, v90, v91), v_u_12, 0.12)
				local v_u_93 = v87:FindFirstChildOfClass("SpecialMesh")
				if not v_u_93 then
					v_u_93 = Instance.new("SpecialMesh")
					v_u_93.MeshType = Enum.MeshType.Sphere
					v_u_93.Parent = v87
				end
				local v_u_94 = v92:FindFirstChildOfClass("SpecialMesh")
				if not v_u_94 then
					v_u_94 = Instance.new("SpecialMesh")
					v_u_94.MeshType = Enum.MeshType.Sphere
					v_u_94.Parent = v92
				end
				p_u_8.add(p_u_9, v87, function(p95, p96)
					-- upvalues: (copy) v_u_93, (copy) v_u_63, (copy) v_u_17, (copy) v_u_83
					local v97 = v_u_93
					local v98 = v_u_63
					local v99 = p96 * 13 + v98
					local v100 = math.sin(v99) * 0.12 + 1
					local v101 = p96 * 23 + v98 * 2.3
					local v102 = v100 + math.sin(v101) * 0.07 + v_u_17() * 0.45
					v97.Scale = Vector3.new(1, v102, 1)
					return p95 * v_u_83(p96, 1)
				end)
				p_u_8.add(p_u_9, v92, function(p103, p104)
					-- upvalues: (copy) v_u_94, (copy) v_u_63, (copy) v_u_17, (copy) v_u_83, (copy) v_u_64
					local v105 = v_u_94
					local v106 = v_u_63
					local v107 = p104 * 13 + v106
					local v108 = math.sin(v107) * 0.12 + 1
					local v109 = p104 * 23 + v106 * 2.3
					local v110 = v108 + math.sin(v109) * 0.07 + v_u_17() * 0.45
					v105.Scale = Vector3.new(1, v110, 1)
					return p103 * v_u_83(p104, 0.7) * CFrame.new(0, -v_u_64 * 0.08, 0)
				end)
				p_u_8.fadeFromBehind(p_u_9, v87, 0.45)
				p_u_8.fadeFromBehind(p_u_9, v92, 0.45)
			end
			for v111 = 1, 4 do
				local v112 = v111 / 4 * 3.141592653589793 * 2 + 0.4
				local v113 = math.cos(v112)
				local v114 = math.sin(v112)
				local v115 = Vector3.new(v113, 0, v114)
				local v_u_116 = (v111 % 2 * 0.6 + 1.2) * v_u_14
				local v117 = v_u_14 * 0.42
				local v_u_118 = CFrame.fromAxisAngle(v115:Cross(Vector3.new(0, 1, 0)).Unit, -0.3) * CFrame.Angles(0, 0.7853981633974483 + v111, 0)
				local v_u_119 = v115 * 1.9 * v_u_14
				local v120 = p_u_8.bar
				local v121 = v_u_116 * 0.68
				local v122 = v120(Vector3.new(v117, v121, v117), v_u_12, 0.15, Enum.Material.SmoothPlastic)
				v122.Reflectance = 0.25
				p_u_8.add(p_u_9, v122, function(p123)
					-- upvalues: (ref) p_u_8, (copy) p_u_9, (copy) v_u_119, (copy) v_u_118, (copy) v_u_116
					return CFrame.new(p_u_8.feetAt(p_u_9, p123, 0) + v_u_119) * v_u_118 * CFrame.new(0, v_u_116 * 0.34, 0)
				end)
				local v124 = p_u_8.add
				local v125 = p_u_8.bar
				local v126 = v117 * 0.55
				local v127 = v_u_116 * 0.42
				local v128 = v117 * 0.55
				v124(p_u_9, v125(Vector3.new(v126, v127, v128), v_u_6, 0.1), function(p129)
					-- upvalues: (ref) p_u_8, (copy) p_u_9, (copy) v_u_119, (copy) v_u_118, (copy) v_u_116
					return CFrame.new(p_u_8.feetAt(p_u_9, p129, 0) + v_u_119) * v_u_118 * CFrame.new(0, v_u_116 * 0.87, 0)
				end)
			end
			local v130 = p_u_8.particles
			local v131 = {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Base", "Tongues", "Embers" }
			}
			local v132 = p_u_9.feet + 0.1
			v131.at = Vector3.new(0, v132, 0)
			v130(p_u_9, "Fire", v_u_11, v131)
			local v133 = p_u_8.particles(p_u_9, "AuraMode", v_u_11, {
				["rate"] = 0.5,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "FlameBack", "Sparks" }
			})
			if v133 then
				local v134 = Instance.new("ParticleEmitter")
				v134.Name = "Frost"
				v134.Texture = v_u_4.Snowflake
				v134.Color = ColorSequence.new(v_u_12)
				v134.LightEmission = 0.6
				v134.LightInfluence = 0
				v134.Lifetime = NumberRange.new(1.2, 1.8)
				v134.Speed = NumberRange.new(1.5 * p_u_9.fx, 3 * p_u_9.fx)
				v134.SpreadAngle = Vector2.new(70, 70)
				v134.EmissionDirection = Enum.NormalId.Top
				v134.Rotation = NumberRange.new(0, 360)
				v134.RotSpeed = NumberRange.new(-90, 90)
				v134.Size = NumberSequence.new(0.28 * p_u_9.fx, 0.1 * p_u_9.fx)
				v134.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.2, 0.2), NumberSequenceKeypoint.new(1, 1) })
				v134:SetAttribute("BaseRate", 5)
				v134.Rate = 5 * v_u_3.formRate()
				v134.Parent = v133
			end
		end
	}
end