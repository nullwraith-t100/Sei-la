local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("6A3FC8")
local v_u_8 = Color3.fromRGB(170, 112, 255)
local v_u_9 = Color3.fromRGB(238, 222, 255)
local v_u_10 = Color3.fromHex("120A2A")
local v_u_11 = Color3.fromRGB(10, 6, 18)
local v_u_12 = Color3.fromRGB(58, 16, 118)
local v_u_13 = Color3.fromRGB(84, 26, 176)
local v_u_14 = Color3.fromRGB(30, 22, 44)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.PartType.Cylinder
local v_u_17 = Enum.PartType.Wedge
local v_u_18 = Enum.Material.SmoothPlastic
local v_u_19 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_25(p20, p21, p22) -- name: facingAlong
	local v23 = p22 - p21 * p22:Dot(p21)
	if v23.Magnitude < 0.001 then
		local v24 = p21.Y
		v23 = p21:Cross(math.abs(v24) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0))
	end
	return CFrame.fromMatrix(p20, v23.Unit, p21)
end
local function v_u_37(p26, p27, p28, p29, p30) -- name: picture
	-- upvalues: (copy) v_u_4
	local v31 = v_u_4.part
	local v32 = p27 * 2
	local v33 = p27 * 2
	local v34 = v31(Vector3.new(v32, 0.05, v33), p26, p29, {
		["transparency"] = 1
	})
	for _, v35 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v36 = Instance.new("Decal")
		v36.Face = v35
		v36.Texture = p28
		v36.Color3 = p29
		v36.Transparency = p30
		v36.Parent = v34
	end
	return v34
end
local function v_u_41(p38, p39) -- name: setAlpha
	for _, v40 in p38:GetChildren() do
		if not v40:IsA("Decal") then
			continue
		end
		v40.Transparency = p39
	end
end
local function v_u_46(p42, p43, p44) -- name: hellFlames
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_12
	local v45 = Instance.new("ParticleEmitter")
	v45.Texture = v_u_6.HellFlame
	v45.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v45.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v45.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, v_u_9),
		ColorSequenceKeypoint.new(0.3, v_u_8),
		ColorSequenceKeypoint.new(0.75, v_u_7),
		ColorSequenceKeypoint.new(1, v_u_12)
	})
	v45.LightEmission = 0.35
	v45.LightInfluence = 0
	v45.Lifetime = NumberRange.new(p44 * 0.8, p44)
	v45.Size = NumberSequence.new(p43)
	v45.Rotation = NumberRange.new(-8, 8)
	v45.Speed = NumberRange.new(0)
	v45.EmissionDirection = Enum.NormalId.Top
	v45.Rate = 0
	v45.Enabled = false
	v45.Parent = p42
	return v45
end
local function v_u_54(p47, p48, p49, p50, p51) -- name: flameBurst
	-- upvalues: (copy) v_u_3, (copy) v_u_46, (copy) v_u_1
	local v52 = Instance.new("Attachment")
	v52.WorldPosition = p47 + Vector3.new(0, 1, 0) * p49 * 0.85
	v52.Parent = v_u_3.Terrain
	local v53 = v_u_46(v52, p49, 0.55)
	v53.SpreadAngle = Vector2.new(p50, p50)
	v53.Speed = NumberRange.new(p51 * 0.5, p51)
	v53.Drag = 3
	v53:Emit(p48)
	v_u_1:AddItem(v52, 0.8)
end
local function v_u_62(p55, p56, p57) -- name: flameColumn
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_1, (copy) v_u_6, (copy) v_u_9, (copy) v_u_8
	local v58 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p55), v_u_7, {
		["transparency"] = 1
	})
	v_u_1:AddItem(v58, p57)
	local v59 = Instance.new("Attachment")
	v59.Parent = v58
	local v60 = Instance.new("Attachment")
	v60.Position = Vector3.new(0, 0.1, 0)
	v60.Parent = v58
	local v61 = Instance.new("Beam")
	v61.Attachment0 = v59
	v61.Attachment1 = v60
	v61.Texture = v_u_6.FireBeam
	v61.TextureMode = Enum.TextureMode.Wrap
	v61.TextureLength = p56 * 3
	v61.TextureSpeed = 2.2
	v61.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_9), ColorSequenceKeypoint.new(0.35, v_u_8), ColorSequenceKeypoint.new(1, v_u_7) })
	v61.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.75, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v61.LightEmission = 0.7
	v61.LightInfluence = 0
	v61.FaceCamera = true
	v61.Width0 = p56 * 2.2
	v61.Width1 = p56 * 1.3
	v61.Segments = 1
	v61.Parent = v58
	return v61, v60
end
return function(p_u_63)
	-- upvalues: (copy) v_u_37, (copy) v_u_1, (copy) v_u_41, (copy) v_u_4, (copy) v_u_8, (copy) v_u_7, (copy) v_u_15, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_3, (copy) v_u_25, (copy) v_u_54, (copy) v_u_19, (copy) v_u_13, (copy) v_u_16, (copy) v_u_62, (copy) v_u_46, (copy) v_u_11, (copy) v_u_18, (copy) v_u_17, (copy) v_u_5, (copy) v_u_14
	local function v_u_80(p_u_64, p_u_65, p_u_66, p67, p68, p_u_69, p_u_70, p71) -- name: flare
		-- upvalues: (ref) v_u_37, (ref) v_u_1, (copy) p_u_63, (ref) v_u_41
		local v_u_72 = p71 or 0
		local v_u_73 = v_u_37(p_u_64, p_u_65, p67, p68, v_u_72)
		v_u_1:AddItem(v_u_73, p_u_69 + 0.1)
		p_u_63.animate(p_u_69, 0, function(p74)
			-- upvalues: (copy) v_u_73, (copy) p_u_65, (copy) p_u_66, (copy) p_u_64, (copy) p_u_69, (copy) p_u_70, (ref) v_u_41, (copy) v_u_72
			local v75 = 1 - (1 - p74) ^ 3
			local v76 = v_u_73
			local v77 = p_u_65 + (p_u_66 - p_u_65) * v75
			local v78 = v77 * 2
			local v79 = v77 * 2
			v76.Size = Vector3.new(v78, 0.05, v79)
			v_u_73.CFrame = p_u_64 * CFrame.Angles(0, p74 * p_u_69 * p_u_70, 0)
			v_u_41(v_u_73, v_u_72 + (1 - v_u_72) * p74 ^ 1.5)
			if p74 >= 1 then
				v_u_73:Destroy()
			end
		end)
	end
	local function v_u_99(p_u_81, p82, p_u_83, p84) -- name: racingCracks
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_1, (copy) p_u_63
		local v_u_85 = math.max(p84, 0.08)
		local v_u_86 = v_u_85 + 0.3
		for _, v_u_87 in p82 do
			local v_u_88 = v_u_4.part(Vector3.new(0.6, 0.12, 0.1), CFrame.new(p_u_81), v_u_8)
			local v_u_89 = v_u_4.part(Vector3.new(1.8, 0.08, 0.1), CFrame.new(p_u_81), v_u_7, {
				["transparency"] = 0.45
			})
			v_u_1:AddItem(v_u_88, v_u_86 + 0.2)
			v_u_1:AddItem(v_u_89, v_u_86 + 0.2)
			p_u_63.animate(v_u_86, 0, function(p90)
				-- upvalues: (copy) v_u_86, (copy) v_u_85, (copy) p_u_83, (copy) p_u_81, (copy) v_u_87, (copy) v_u_88, (copy) v_u_89
				local v91 = p90 * v_u_86 / v_u_85
				local v92 = math.min(v91, 1)
				local v93 = p_u_83 * (1 - (1 - v92) ^ 2)
				local v94 = math.max(v93, 0.1)
				local v95 = p_u_81 + v_u_87 * v94 / 2
				local v96 = CFrame.lookAt(v95 + Vector3.new(0, 0.14, 0), v95 + Vector3.new(0, 0.14, 0) + v_u_87)
				v_u_88.Size = Vector3.new(0.6, 0.12, v94)
				v_u_88.CFrame = v96
				v_u_89.Size = Vector3.new(1.8, 0.08, v94)
				v_u_89.CFrame = v96 * CFrame.new(0, -0.04, 0)
				if v92 >= 1 then
					local v97 = (p90 * v_u_86 - v_u_85) / 0.3
					local v98 = math.clamp(v97, 0, 1)
					v_u_88.Transparency = v98
					v_u_89.Transparency = v98 * 0.55 + 0.45
				end
				if p90 >= 1 then
					v_u_88:Destroy()
					v_u_89:Destroy()
				end
			end)
		end
	end
	local function v130(p_u_100, p101) -- name: starShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_15, (ref) v_u_9, (ref) v_u_37, (ref) v_u_6, (ref) v_u_8, (copy) p_u_63, (ref) v_u_10, (ref) v_u_1, (ref) v_u_3, (ref) v_u_25, (ref) v_u_41
		local v_u_102 = p_u_100.size
		local v_u_103 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p101, v_u_7, {
			["transparency"] = 1
		})
		local v104 = {
			["shape"] = nil,
			["transparency"] = 0.45,
			["shape"] = v_u_15
		}
		local v_u_105 = v_u_4.part(Vector3.new(1.8, 1.8, 1.8) * v_u_102, p101, v_u_7, v104)
		local v106 = {
			["shape"] = v_u_15
		}
		local v_u_107 = v_u_4.part(Vector3.new(0.62, 0.62, 0.62) * v_u_102, p101, v_u_9, v106)
		local v_u_108 = v_u_37(p101, 1, v_u_6.JigokuStar, v_u_8, 0)
		local v109 = 3.8 * v_u_102
		local v110 = 2.6 * v_u_102
		v_u_108.Size = Vector3.new(v109, 0.05, v110)
		local v_u_111 = { v_u_105, v_u_107, v_u_108 }
		p_u_63.streak(v_u_103, v_u_8, v_u_10, 1.3 * v_u_102, 0.14)
		if p_u_100.mine then
			p_u_63.light(v_u_103, v_u_8, 9 * v_u_102)
		end
		for _, v112 in v_u_111 do
			v_u_1:AddItem(v112, 3)
		end
		v_u_1:AddItem(v_u_103, 3)
		local v_u_113 = 0
		local v_u_114 = false
		return {
			["place"] = function(p115, p116) -- name: place
				-- upvalues: (copy) v_u_103, (copy) v_u_105, (copy) v_u_107, (ref) v_u_3, (ref) v_u_25, (copy) v_u_102, (copy) v_u_108, (copy) p_u_100, (ref) v_u_113, (ref) v_u_37, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (ref) p_u_63, (ref) v_u_41
				local v117 = p115.Position
				v_u_103.CFrame = p115
				v_u_105.CFrame = p115
				v_u_107.CFrame = p115
				local v118 = v_u_3.CurrentCamera
				local v119
				if v118 then
					local v120 = v118.CFrame.Position - v117
					v119 = v120.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v120.Unit
				else
					v119 = Vector3.new(0, 0, 1)
				end
				local v121 = v_u_25(v117 + v119 * 0.6 * v_u_102, v119, p115.LookVector)
				v_u_108.CFrame = v121
				if not p_u_100.lite and p116 - v_u_113 > 0.05 then
					v_u_113 = p116
					local v_u_122 = v_u_37(v121, 1, v_u_6.JigokuStar, v_u_7, 0.4)
					v_u_122.Size = v_u_108.Size
					v_u_1:AddItem(v_u_122, 0.3)
					p_u_63.animate(0.2, 0, function(p123)
						-- upvalues: (copy) v_u_122, (ref) v_u_102, (ref) v_u_41
						local v124 = 1 - 0.45 * p123
						local v125 = v_u_122
						local v126 = 3.8 * v_u_102 * v124
						local v127 = 2.6 * v_u_102 * v124
						v125.Size = Vector3.new(v126, 0.05, v127)
						v_u_41(v_u_122, 0.4 + 0.6 * p123)
						if p123 >= 1 then
							v_u_122:Destroy()
						end
					end)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_114, (copy) v_u_103, (ref) v_u_1, (copy) v_u_111
				if not v_u_114 then
					v_u_114 = true
					local v128 = v_u_103:FindFirstChildWhichIsA("PointLight")
					if v128 then
						v128:Destroy()
					end
					v_u_1:AddItem(v_u_103, 0.2)
					for _, v129 in v_u_111 do
						v129:Destroy()
					end
				end
			end
		}
	end
	local function v145(p131, p132) -- name: starImpact
		-- upvalues: (ref) v_u_3, (copy) p_u_63, (ref) v_u_37, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_54
		local v_u_133 = p131.size
		local v134 = v_u_3.CurrentCamera
		local v135
		if v134 then
			local v136 = v134.CFrame.Position - p132
			v135 = v136.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v136.Unit
		else
			v135 = Vector3.new(0, 0, 1)
		end
		local v_u_137 = p_u_63.facing(p132 + v135 * 0.8, v135)
		local v_u_138 = v_u_37(v_u_137, 1.6 * v_u_133, v_u_6.JigokuStar, v_u_8, 0)
		v_u_1:AddItem(v_u_138, 0.45)
		p_u_63.animate(0.3, 0, function(p139)
			-- upvalues: (copy) v_u_138, (copy) v_u_133, (copy) v_u_137
			local v140
			if p139 < 0.3 then
				v140 = 1.6 + 1.7 * (p139 / 0.3)
			else
				v140 = 3.3 * (1 - (p139 - 0.3) / 0.7) ^ 2
			end
			local v141 = v_u_138
			local v142 = math.max(v140, 0.05) * v_u_133
			local v143 = v142 * 2
			local v144 = v142 * 2
			v141.Size = Vector3.new(v143, 0.05, v144)
			v_u_138.CFrame = v_u_137 * CFrame.Angles(0, p139 * 2.6, 0)
			if p139 >= 1 then
				v_u_138:Destroy()
			end
		end)
		p_u_63.pop(p132, v_u_7, 1.2 * v_u_133, 4.6 * v_u_133, 0.2, 0.35)
		p_u_63.pop(p132, v_u_9, 1.3 * v_u_133, 0.1, 0.22)
		v_u_4.ring(p_u_63.ground(p132), v_u_7, p131.ability.radius * v_u_133, 0.3, v_u_6.Ring)
		p_u_63.burst("Impact", p132, v_u_8, 0.9 * v_u_133)
		v_u_54(p_u_63.ground(p132, 0), p131.lite and 2 or 4, 1.6 * v_u_133, 35, 6)
		p_u_63.hitSound(p132)
	end
	local function v_u_161(p146, p147, p148, p149, p150) -- name: newPillar
		-- upvalues: (ref) v_u_4, (ref) v_u_19, (ref) v_u_13, (ref) v_u_16, (ref) v_u_9, (ref) v_u_1, (ref) v_u_62
		local v151 = {
			["shape"] = nil,
			["transparency"] = 1,
			["shape"] = v_u_16
		}
		local v152 = v_u_4.part(Vector3.new(0.1, p148, p148), CFrame.new(p146) * v_u_19, v_u_13, v151)
		local v153 = v_u_4.part
		local v154 = p148 * 0.2
		local v155 = p148 * 0.2
		local v156 = Vector3.new(0.1, v154, v155)
		local v157 = {
			["shape"] = nil,
			["transparency"] = 1,
			["shape"] = v_u_16
		}
		local v158 = v153(v156, CFrame.new(p146) * v_u_19, v_u_9, v157)
		v_u_1:AddItem(v152, p150)
		v_u_1:AddItem(v158, p150)
		local v159, v160 = v_u_62(p146, p148, p150)
		v159.Enabled = false
		return {
			["col"] = nil,
			["core"] = nil,
			["base"] = nil,
			["h"] = nil,
			["w"] = nil,
			["at"] = nil,
			["host"] = nil,
			["up"] = false,
			["fire"] = nil,
			["top"] = nil,
			["col"] = v152,
			["core"] = v158,
			["base"] = p146,
			["h"] = p147,
			["w"] = p148,
			["at"] = p149,
			["fire"] = v159,
			["top"] = v160
		}
	end
	local function v_u_171(p162, p163, p164, p165) -- name: erupt
		-- upvalues: (copy) p_u_63, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_54, (ref) v_u_1, (ref) v_u_46
		p163.up = true
		p163.fire.Enabled = true
		p_u_63.pop(p163.base + Vector3.new(0, 1, 0), v_u_8, 1, p163.w * 2.6, 0.22, 0.3)
		v_u_4.ring(p163.base, v_u_7, p163.w * 1.7, 0.3, v_u_6.Ring)
		if not p162.lite then
			v_u_54(p163.base, p164 and 5 or 3, 2.4, 25, 12)
			local v166 = v_u_4.part
			local v167 = p163.w
			local v168 = p163.w
			local v169 = v166(Vector3.new(v167, 0.4, v168), CFrame.new(p163.base + Vector3.new(0, 1.8, 0)), v_u_7, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v169, p165 + 1)
			local v170 = v_u_46(v169, p164 and 4 or 3.2, 0.65)
			v170.Speed = NumberRange.new(13, 21)
			v170.Acceleration = Vector3.new(0, 6, 0)
			v170.SpreadAngle = Vector2.new(6, 6)
			v170.Rate = p164 and 16 or 11
			v170.Enabled = true
			p163.host = v169
		end
	end
	local function v_u_179(p_u_172) -- name: climbRing
		-- upvalues: (ref) v_u_37, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (copy) p_u_63, (ref) v_u_41
		local v_u_173 = v_u_37(CFrame.new(p_u_172.base), p_u_172.w, v_u_6.Ring, v_u_8, 0)
		v_u_1:AddItem(v_u_173, 0.35)
		p_u_63.animate(0.28, 0, function(p174)
			-- upvalues: (copy) v_u_173, (copy) p_u_172, (ref) v_u_41
			v_u_173.CFrame = CFrame.new(p_u_172.base + Vector3.new(0, 1, 0) * (0.5 + p_u_172.h * p174))
			local v175 = v_u_173
			local v176 = p_u_172.w * (1.3 - 0.5 * p174)
			local v177 = v176 * 2
			local v178 = v176 * 2
			v175.Size = Vector3.new(v177, 0.05, v178)
			v_u_41(v_u_173, p174 * p174)
			if p174 >= 1 then
				v_u_173:Destroy()
			end
		end)
	end
	local function v_u_189(p180, p181, p182, p183) -- name: hellOrb
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_15, (ref) v_u_18, (ref) v_u_7, (ref) v_u_1, (ref) v_u_46
		local v184 = {
			["shape"] = v_u_15,
			["material"] = v_u_18
		}
		local v185 = v_u_4.part(Vector3.new(1, 1, 1) * p181, CFrame.new(p180), v_u_11, v184)
		local v186 = {
			["shape"] = nil,
			["transparency"] = 0.6,
			["shape"] = v_u_15
		}
		local v187 = v_u_4.part(Vector3.new(1, 1, 1) * p181 * 1.45, CFrame.new(p180), v_u_7, v186)
		v_u_1:AddItem(v185, p183)
		v_u_1:AddItem(v187, p183)
		if not p182 then
			local v188 = v_u_46(v185, p181 * 0.75, 0.55)
			v188.Speed = NumberRange.new(2, 3)
			v188.Rate = 7
			v188.Enabled = true
		end
		return v185, v187
	end
	local v_u_190 = {}
	setmetatable(v_u_190, {
		["__mode"] = "k"
	})
	local function v_u_215(p191, p192, p193, p194, p195, p196, p197) -- name: starRig
		-- upvalues: (copy) p_u_63, (ref) v_u_17
		local v198 = p_u_63.newRig()
		local v199 = p192 / 1.4142135623730951
		local v200 = p_u_63.rigAdd
		local v201 = v199 * 2
		local v202 = v199 * 2
		v200(v198, Vector3.new(v201, 0.1, v202), CFrame.new(0, p196, 0), p193, p194, p195, p197)
		for v203 = 0, 3 do
			local v204 = v203 * 3.141592653589793 / 2
			local v205 = math.cos(v204)
			local v206 = math.sin(v204)
			local v207 = Vector3.new(v205, 0, v206)
			local v208 = v207:Cross(Vector3.new(0, 1, 0))
			local v209 = v207 * v199 + Vector3.new(0, p196, 0)
			local v210 = p191 - v199
			for _, v211 in { v208, -v208 } do
				local v212 = v209 + v211 * (v199 / 2) + v207 * (v210 / 2)
				local v213 = Vector3.new(0.1, v210, v199)
				local v214 = CFrame.fromMatrix(v212, v211:Cross(v207), v207, -v211)
				p_u_63.rigAdd(v198, v213, v214, p193, p194, p195, p197).Shape = v_u_17
			end
		end
		return v198
	end
	local v519 = {
		["mangekyou_jigokugan_a"] = {
			["cast"] = function(p216) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_63, (ref) v_u_9, (copy) v_u_80, (ref) v_u_6, (ref) v_u_8
				local v217 = p216.size
				local v218 = p216.eye + p216.dir * 1.2
				v_u_4.flash(v218, v_u_7, 3.2 * v217, 0.1)
				p_u_63.pop(v218, v_u_9, 1.2 * v217, 0.3 * v217, 0.1)
				if not p216.lite then
					v_u_80(p_u_63.facing(v218, -p216.dir), 0.5 * v217, 1.5 * v217, v_u_6.JigokuStar, v_u_8, 0.12, 14)
				end
			end,
			["shot"] = v130,
			["impact"] = v145,
			["hit"] = function(p219, p220, _) -- name: hit
				-- upvalues: (copy) p_u_63, (ref) v_u_8, (ref) v_u_9
				p_u_63.burst("Impact", p220, v_u_8, 0.6)
				if not p219.lite then
					p_u_63.glint(p220, v_u_9, 2.4, 0.12)
				end
			end
		},
		["mangekyou_jigokugan_e"] = {
			["loopSound"] = "Flames",
			["castSound"] = "Bind",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["hit"] = nil,
			["cast"] = function(p221) -- name: cast
				-- upvalues: (copy) p_u_63, (ref) v_u_7, (copy) v_u_80, (ref) v_u_6, (ref) v_u_8
				p_u_63.skillCast(p221, v_u_7)
				local v222 = p221.size
				local v223 = p221.eye + p221.dir * 1.6
				v_u_80(p_u_63.facing(v223, p221.dir), 0.8 * v222, 3 * v222, v_u_6.JigokuStar, v_u_8, 0.32, -10)
			end,
			["windup"] = function(p224, p225, p226) -- name: windup
				-- upvalues: (copy) v_u_99, (copy) p_u_63, (ref) v_u_4, (ref) v_u_9
				local v227 = p224.dir.X
				local v228 = p224.dir.Z
				local v229 = Vector3.new(v227, 0, v228)
				local v230 = v229.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v229.Unit
				local v231 = v230:Cross(Vector3.new(0, 1, 0))
				local v232 = p224.ability.radius * p224.size
				v_u_99(p_u_63.ground(p225, 0), {
					v230,
					-v230,
					v231,
					-v231
				}, v232, p226)
				v_u_4.flash(p_u_63.ground(p225, 1), v_u_9, 4, 0.15)
			end,
			["zone"] = function(p_u_233, p234, p235) -- name: zone
				-- upvalues: (copy) p_u_63, (ref) v_u_4, (ref) v_u_7, (ref) v_u_11, (ref) v_u_18, (ref) v_u_1, (ref) v_u_37, (ref) v_u_6, (copy) v_u_189, (copy) v_u_161, (ref) v_u_8, (copy) v_u_179, (copy) v_u_171, (ref) v_u_9, (ref) v_u_5, (ref) v_u_19, (ref) v_u_13
				local v236 = p_u_233.size
				local v_u_237 = p_u_233.lite
				local v_u_238 = p_u_233.ability.radius * v236
				local v_u_239 = p_u_63.ground(p234, 0)
				local v240 = p_u_233.dir.X
				local v241 = p_u_233.dir.Z
				local v242 = Vector3.new(v240, 0, v241)
				local v243 = v242.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v242.Unit
				local v244 = v243:Cross(Vector3.new(0, 1, 0))
				local v_u_245 = p235 + 1.5
				local v_u_246 = {}
				for _, v247 in { v243, v244 } do
					local v248 = v_u_4.part
					local v249 = v_u_238 * 2 + 2
					local v250 = v248(Vector3.new(3, 0.08, v249), CFrame.lookAt(v_u_239 + Vector3.new(0, 0.07, 0), v_u_239 + Vector3.new(0, 0.07, 0) + v247), v_u_7, {
						["transparency"] = 0.25
					})
					local v251 = v_u_4.part
					local v252 = v_u_238 * 2 + 1
					local v253 = Vector3.new(1.3, 0.1, v252)
					local v254 = {
						["material"] = v_u_18
					}
					local v255 = v251(v253, CFrame.lookAt(v_u_239 + Vector3.new(0, 0.1, 0), v_u_239 + Vector3.new(0, 0.1, 0) + v247), v_u_11, v254)
					table.insert(v_u_246, v250)
					table.insert(v_u_246, v255)
					v_u_1:AddItem(v250, v_u_245)
					v_u_1:AddItem(v255, v_u_245)
				end
				local v_u_256 = v_u_37(CFrame.new(v_u_239 + Vector3.new(0, 0.12, 0)), v_u_238 * 0.62, v_u_6.Ring, v_u_7, 0.25)
				v_u_1:AddItem(v_u_256, v_u_245)
				local v257 = (v243 + v244).Unit
				local v_u_258 = {}
				for v259 = 0, 3 do
					local v260, v261 = v_u_189(v_u_239 + CFrame.fromAxisAngle(Vector3.new(0, 1, 0), v259 * 3.141592653589793 / 2):VectorToWorldSpace(v257) * v_u_238 * 0.62 + Vector3.new(0, 2.2, 0), 1.5, v_u_237, v_u_245)
					table.insert(v_u_258, v260)
					table.insert(v_u_258, v261)
				end
				local v_u_262 = {}
				local v263 = v_u_161(v_u_239, 15, 3.4, 0, v_u_245)
				table.insert(v_u_262, v263)
				for _, v264 in {
					v243,
					-v243,
					v244,
					-v244
				} do
					local v265 = v_u_161(v_u_239 + v264 * v_u_238 * 0.5, 11, 2.5, 0.07, v_u_245)
					table.insert(v_u_262, v265)
					local v266 = v_u_161(v_u_239 + v264 * v_u_238 * 0.95, 9, 2.2, 0.14, v_u_245)
					table.insert(v_u_262, v266)
				end
				local v_u_267 = p_u_233.ability.tick or 0.4
				local v_u_268 = os.clock()
				local v_u_269 = v_u_268
				local v_u_270 = v_u_267
				local v_u_271 = 0
				local v_u_272 = true
				local v_u_273 = 0
				p_u_63.runNow(function()
					-- upvalues: (copy) v_u_268, (ref) v_u_269, (ref) v_u_272, (ref) v_u_270, (copy) v_u_267, (ref) v_u_271, (ref) p_u_63, (copy) v_u_239, (ref) v_u_8, (copy) v_u_237, (copy) v_u_238, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (copy) v_u_262, (ref) v_u_179, (ref) v_u_273, (ref) v_u_171, (copy) p_u_233, (copy) v_u_245, (ref) v_u_9, (ref) v_u_5, (ref) v_u_19, (ref) v_u_13
					local v274 = os.clock()
					local v275 = v274 - v_u_268
					local v276 = v274 - v_u_269
					local v277 = math.min(v276, 0.05)
					v_u_269 = v274
					if v_u_272 and v_u_270 <= v275 then
						v_u_270 = v_u_270 + v_u_267
						v_u_271 = 1
						p_u_63.inward(v_u_239 + Vector3.new(0, 1.5, 0), v_u_8, v_u_237 and 3 or 6, v_u_238 + 2, 0.3)
						v_u_4.ring(v_u_239, v_u_7, v_u_238, 0.3, v_u_6.Ring)
						if not v_u_237 then
							for _, v278 in v_u_262 do
								if not v278.up then
									continue
								end
								v_u_179(v278)
							end
						end
					end
					local v279 = v_u_271 - v277 * 3.5
					v_u_271 = math.max(v279, 0)
					local v280
					if v_u_272 then
						v280 = 0
					else
						local v281 = (v274 - v_u_273) / 0.3
						v280 = math.clamp(v281, 0, 1)
					end
					for v282, v283 in v_u_262 do
						local v284 = v275 - v283.at
						if v284 < 0 then
							continue
						end
						if not v283.up then
							v_u_171(p_u_233, v283, v282 == 1, v_u_245)
							if v282 == 1 then
								v_u_4.flash(v_u_239 + Vector3.new(0, 3, 0), v_u_9, 9, 0.2)
								v_u_5.play("Fireball", {
									["at"] = v_u_239,
									["volume"] = p_u_233.mine and 0.8 or 0.45
								})
							end
						end
						local v285 = v284 / 0.16
						local v286 = math.clamp(v285, 0, 1) - 1
						local v287 = v286 * 2.7 * v286 * v286 + 1 + v286 * 1.7 * v286
						local v288 = v275 * 23 + v282 * 1.7
						local v289 = math.sin(v288) * 0.06 + 1
						local v290 = v283.h * v287 * (v_u_271 * 0.18 + 1) * (1 - v280)
						local v291 = math.max(v290, 0.1)
						local v292 = v283.w * v289 * (v_u_271 * 0.15 + 1) * (1 - v280 * 0.6)
						v283.col.Size = Vector3.new(v291, v292, v292)
						v283.col.CFrame = CFrame.new(v283.base + Vector3.new(0, 1, 0) * v291 / 2) * v_u_19
						v283.col.Transparency = 0.72 - v_u_271 * 0.2 + v280 * 0.28
						v283.col.Color = v_u_13:Lerp(v_u_8, v_u_271)
						local v293 = v283.core
						local v294 = v291 * 1.02
						local v295 = v292 * 0.2
						local v296 = v292 * 0.2
						v293.Size = Vector3.new(v294, v295, v296)
						v283.core.CFrame = v283.col.CFrame
						v283.core.Transparency = v280 * 0.95 + 0.05
						local v297 = v283.top
						local v298 = v291 * 1.12
						v297.Position = Vector3.new(0, v298, 0)
						v283.fire.Width0 = v292 * 2.2
						v283.fire.Width1 = v292 * 1.3
						if v280 <= 0 then
							continue
						end
						v283.fire.Transparency = NumberSequence.new(v280)
					end
					if v_u_272 or v280 < 1 then
						return true
					end
					for _, v299 in v_u_262 do
						v299.col:Destroy()
						v299.core:Destroy()
						v299.fire.Enabled = false
					end
					return false
				end)
				return function()
					-- upvalues: (ref) v_u_272, (ref) v_u_273, (copy) v_u_262, (copy) v_u_246, (ref) v_u_4, (ref) v_u_1, (copy) v_u_258, (copy) v_u_256, (copy) v_u_238
					v_u_272 = false
					v_u_273 = os.clock()
					for _, v300 in v_u_262 do
						local v301 = v300.host
						if not v301 then
							continue
						end
						for _, v302 in v301:GetChildren() do
							if not v302:IsA("ParticleEmitter") then
								continue
							end
							v302.Enabled = false
						end
					end
					for _, v303 in v_u_246 do
						v_u_4.tween(v303, 0.4, {
							["Transparency"] = 1
						})
						v_u_1:AddItem(v303, 0.45)
					end
					for _, v304 in v_u_258 do
						v_u_4.tween(v304, 0.3, {
							["Transparency"] = 1,
							["Size"] = nil,
							["Size"] = v304.Size * 0.3
						})
						v_u_1:AddItem(v304, 0.35)
					end
					local v305 = v_u_4.tween
					local v306 = v_u_256
					local v307 = {}
					local v308 = v_u_238 * 1.6
					local v309 = v_u_238 * 1.6
					v307.Size = Vector3.new(v308, 0.05, v309)
					v305(v306, 0.4, v307)
					for _, v310 in v_u_256:GetChildren() do
						if not v310:IsA("Decal") then
							continue
						end
						v_u_4.tween(v310, 0.4, {
							["Transparency"] = 1
						})
					end
					v_u_1:AddItem(v_u_256, 0.45)
				end
			end,
			["hit"] = function(p311, p312, _) -- name: hit
				-- upvalues: (copy) p_u_63, (ref) v_u_8, (ref) v_u_54
				p_u_63.burst("Impact", p312, v_u_8, 0.6)
				if not p311.lite then
					v_u_54(p_u_63.ground(p312, 0), 1, 1.8, 10, 4)
				end
			end
		},
		["mangekyou_jigokugan_r"] = {
			["loopSound"] = "Vortex",
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p313) -- name: cast
				-- upvalues: (copy) p_u_63, (ref) v_u_7, (copy) v_u_80, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4
				p_u_63.skillCast(p313, v_u_7, true)
				local v314 = p313.size
				local v315 = p313.eye + p313.dir * 1.6
				local v316 = p_u_63.facing(v315, p313.dir)
				v_u_80(v316, 1 * v314, 4.4 * v314, v_u_6.JigokuStar, v_u_8, 0.36, 9)
				v_u_80(v316 * CFrame.new(0, -0.05, 0), 1.6 * v314, 5.2 * v314, v_u_6.Glow, v_u_7, 0.3, 0, 0.3)
				if p313.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p317, p318, p319) -- name: windup
				-- upvalues: (copy) p_u_63, (copy) v_u_99, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7
				local v320 = p317.dir.X
				local v321 = p317.dir.Z
				local v322 = Vector3.new(v320, 0, v321)
				local v323 = v322.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v322.Unit
				local v324 = v323:Cross(Vector3.new(0, 1, 0))
				local v325 = p317.ability.radius * p317.size
				local v326 = p_u_63.ground(p318, 0)
				v_u_99(v326, {
					v323,
					-v323,
					v324,
					-v324
				}, v325 * 1.05, p319)
				v_u_4.flash(v326 + Vector3.new(0, 1, 0), v_u_9, 5, 0.18)
				p_u_63.burst("Shockwave", v326 + Vector3.new(0, 0.3, 0), v_u_7, 0.6)
			end,
			["zone"] = function(p327, p328, p329) -- name: zone
				-- upvalues: (copy) p_u_63, (copy) v_u_215, (ref) v_u_11, (ref) v_u_18, (ref) v_u_8, (copy) v_u_190, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_46, (ref) v_u_6, (ref) v_u_9, (copy) v_u_189
				local v330 = p327.size
				local v_u_331 = p327.lite
				local v_u_332 = p327.ability.radius * v330
				local v_u_333 = p_u_63.ground(p328, 0)
				local v334 = p327.dir.X
				local v335 = p327.dir.Z
				local v336 = Vector3.new(v334, 0, v335)
				local v337 = v336.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v336.Unit
				local v338 = v337:Cross(Vector3.new(0, 1, 0))
				local v339 = p329 + 2.5
				local v_u_340 = CFrame.fromMatrix(v_u_333, v338, Vector3.new(0, 1, 0))
				local v_u_341 = v_u_215(v_u_332 * 1.02, v_u_332 * 0.36, v_u_11, 0, v_u_18, 0.12, v339)
				local v_u_342 = v_u_215(v_u_332 * 1.14, v_u_332 * 0.46, v_u_8, 0.15, Enum.Material.Neon, 0.06, v339)
				local v_u_343 = {
					["chasm"] = nil,
					["rim"] = nil,
					["frame"] = nil,
					["scale"] = 0.02,
					["hosts"] = nil,
					["orbs"] = nil,
					["alive"] = true,
					["erupted"] = false,
					["chasm"] = v_u_341,
					["rim"] = v_u_342,
					["frame"] = v_u_340,
					["hosts"] = {},
					["orbs"] = {}
				}
				v_u_190[p327] = v_u_343
				p_u_63.rigPlace(v_u_341, v_u_340, 0.02)
				p_u_63.rigPlace(v_u_342, v_u_340, 0.02)
				if not v_u_331 then
					for _, v344 in {
						v337,
						-v337,
						v338,
						-v338
					} do
						local v345 = v_u_333 + v344 * v_u_332 * 0.5 + Vector3.new(0, 1.6, 0)
						local v346 = v_u_4.part
						local v347 = v_u_332 * 0.8
						local v348 = v346(Vector3.new(2.4, 0.4, v347), CFrame.lookAt(v345, v345 + v344), v_u_7, {
							["transparency"] = 1
						})
						v_u_1:AddItem(v348, v339)
						local v_u_349 = v_u_46(v348, 2.2, 0.65)
						v_u_349.Speed = NumberRange.new(3, 6)
						v_u_349.Acceleration = Vector3.new(0, 4, 0)
						v_u_349.SpreadAngle = Vector2.new(15, 15)
						v_u_349.Rate = 9
						local v350 = v_u_343.hosts
						table.insert(v350, v348)
						p_u_63.after(0.15, function()
							-- upvalues: (copy) v_u_349, (copy) v_u_343
							v_u_349.Enabled = v_u_343.alive
						end)
					end
				end
				local v_u_351 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_333), v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_351, v339)
				local v_u_352 = {}
				for _ = 1, v_u_331 and 2 or 4 do
					local v353 = Instance.new("Attachment")
					v353.Parent = v_u_351
					local v354 = Instance.new("Attachment")
					v354.Parent = v_u_351
					local v355 = Instance.new("Beam")
					v355.Attachment0 = v353
					v355.Attachment1 = v354
					v355.Texture = v_u_6.Beam
					v355.TextureMode = Enum.TextureMode.Wrap
					v355.TextureLength = 6
					v355.TextureSpeed = 3
					v355.Color = ColorSequence.new(v_u_8, v_u_9)
					v355.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.2, 0.25), NumberSequenceKeypoint.new(1, 0.1) })
					v355.LightEmission = 0.6
					v355.LightInfluence = 0
					v355.FaceCamera = true
					v355.Segments = 14
					v355.Width0 = 3.2
					v355.Width1 = 0.5
					v355.CurveSize0 = v_u_332 * 0.45
					v355.CurveSize1 = v_u_332 * 0.2
					v355.Parent = v_u_351
					table.insert(v_u_352, {
						["a0"] = v353,
						["a1"] = v354
					})
				end
				for _ = 1, 4 do
					local v356, v357 = v_u_189(v_u_333 + Vector3.new(0, 6, 0), 1.7, v_u_331, v339)
					local v358 = v_u_343.orbs
					table.insert(v358, v356)
					local v359 = v_u_343.orbs
					table.insert(v359, v357)
				end
				local v_u_360 = p327.ability.tick or 0.4
				local v_u_361 = os.clock()
				local v_u_362 = v_u_361
				local v_u_363 = v_u_360
				local v_u_364 = 0
				p_u_63.runNow(function()
					-- upvalues: (copy) v_u_343, (copy) v_u_361, (ref) v_u_362, (ref) p_u_63, (copy) v_u_341, (copy) v_u_340, (copy) v_u_342, (ref) v_u_363, (copy) v_u_360, (ref) v_u_364, (copy) v_u_333, (ref) v_u_8, (copy) v_u_331, (copy) v_u_332, (ref) v_u_9, (copy) v_u_352
					if v_u_343.erupted then
						return false
					end
					local v365 = os.clock()
					local v366 = v365 - v_u_361
					local v367 = v365 - v_u_362
					local v368 = math.min(v367, 0.05)
					v_u_362 = v365
					local v369 = v366 / 0.32
					local v370 = math.clamp(v369, 0, 1) - 1
					local v371 = v370 * 2.7 * v370 * v370 + 1 + v370 * 1.7 * v370
					v_u_343.scale = v371
					p_u_63.rigPlace(v_u_341, v_u_340, v371)
					p_u_63.rigPlace(v_u_342, v_u_340, v371)
					if v_u_343.alive and v_u_363 <= v366 then
						v_u_363 = v_u_363 + v_u_360
						v_u_364 = 1
						p_u_63.inward(v_u_333 + Vector3.new(0, 1.2, 0), v_u_8, v_u_331 and 3 or 6, v_u_332 + 3, 0.32)
						if not v_u_331 then
							for _ = 1, 3 do
								local v372 = math.random() * 3.141592653589793 * 2
								local v373 = v_u_333
								local v374 = math.cos(v372)
								local v375 = math.sin(v372)
								local v376 = v373 + Vector3.new(v374, 0, v375) * v_u_332 * 0.5 * math.random() + Vector3.new(0, 4, 0)
								p_u_63.spikes(v376, v_u_8, 1, 5, 0.22, Vector3.new(-0, -1, -0), 0.1)
							end
						end
					end
					local v377 = v_u_364 - v368 * 4
					v_u_364 = math.max(v377, 0)
					local v378 = v_u_8:Lerp(v_u_9, v_u_364)
					for _, v379 in v_u_342.parts do
						v379.Color = v378
					end
					local v380 = v366 * 1.6
					for v381, v382 in v_u_352 do
						local v383 = v380 + v381 / #v_u_352 * 3.141592653589793 * 2
						local v384 = math.cos(v383)
						local v385 = math.sin(v383)
						local v386 = Vector3.new(v384, 0, v385)
						local v387 = -v386.Z
						local v388 = v386.X
						local v389 = Vector3.new(v387, 0, v388)
						local v390 = v_u_333 + v386 * v_u_332 * 0.95 * v371 + Vector3.new(0, 1.5, 0)
						v382.a0.WorldCFrame = CFrame.fromMatrix(v390, (v389 - v386 * 0.3).Unit, Vector3.new(0, 1, 0))
						v382.a1.WorldCFrame = CFrame.fromMatrix(v_u_333 - Vector3.new(0, 1.5, 0), -v386, Vector3.new(0, 1, 0))
					end
					for v391 = 1, #v_u_343.orbs, 2 do
						local v392 = (v391 - 1) / 2
						local v393 = -v366 * 0.9 + v392 * 3.141592653589793 / 2 + 0.7853981633974483
						local v394 = v_u_333
						local v395 = math.cos(v393)
						local v396 = math.sin(v393)
						local v397 = v394 + Vector3.new(v395, 0, v396) * v_u_332 * 0.6
						local v398 = v366 * 3 + v392
						local v399 = v397 + Vector3.new(0, 1, 0) * (math.sin(v398) * 0.5 + 6)
						v_u_343.orbs[v391].CFrame = CFrame.new(v399)
						v_u_343.orbs[v391 + 1].CFrame = CFrame.new(v399)
					end
					return true
				end)
				return function()
					-- upvalues: (copy) v_u_343, (copy) v_u_351, (ref) p_u_63, (copy) v_u_341, (copy) v_u_342
					v_u_343.alive = false
					for _, v400 in v_u_343.hosts do
						for _, v401 in v400:GetChildren() do
							if not v401:IsA("ParticleEmitter") then
								continue
							end
							v401.Enabled = false
						end
					end
					v_u_351:Destroy()
					p_u_63.after(0.8, function()
						-- upvalues: (ref) v_u_343, (ref) p_u_63, (ref) v_u_341, (ref) v_u_342
						if not v_u_343.erupted then
							v_u_343.erupted = true
							p_u_63.rigDestroy(v_u_341)
							p_u_63.rigDestroy(v_u_342)
							for _, v402 in v_u_343.orbs do
								v402:Destroy()
							end
						end
					end)
				end
			end,
			["finish"] = function(p403, p404) -- name: finish
				-- upvalues: (copy) p_u_63, (copy) v_u_190, (ref) v_u_4, (ref) v_u_1, (ref) v_u_9, (ref) v_u_19, (ref) v_u_13, (ref) v_u_16, (ref) v_u_62, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (ref) v_u_37, (ref) v_u_41, (ref) v_u_54, (ref) v_u_3, (ref) v_u_46, (ref) v_u_11, (ref) v_u_14, (ref) v_u_5
				local v405 = p403.size
				local v406 = p403.lite
				local v407 = p403.ability.radius * v405
				local v_u_408 = p_u_63.ground(p404, 0)
				local v409 = p403.dir.X
				local v410 = p403.dir.Z
				local v411 = Vector3.new(v409, 0, v410)
				local v412 = v411.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v411.Unit
				local v413 = v412:Cross(Vector3.new(0, 1, 0))
				local v414 = v_u_190[p403]
				v_u_190[p403] = nil
				if v414 and not v414.erupted then
					v414.erupted = true
					for _, v415 in v414.orbs do
						local v416 = v415.Position.X
						local v417 = v_u_408.Y - 1
						local v418 = v415.Position.Z
						local v419 = Vector3.new(v416, v417, v418):Lerp(v_u_408 - Vector3.new(0, 1, 0), 0.5)
						v_u_4.tween(v415, 0.12, {
							["CFrame"] = nil,
							["Transparency"] = 1,
							["CFrame"] = CFrame.new(v419)
						}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						v_u_1:AddItem(v415, 0.15)
					end
					for _, v420 in v414.rim.parts do
						v420.Color = v_u_9
					end
					local v_u_421 = v414.chasm
					local v_u_422 = v414.rim
					local v_u_423 = v414.frame
					local v_u_424 = v414.scale
					p_u_63.animate(0.5, 0, function(p425)
						-- upvalues: (ref) p_u_63, (copy) v_u_421, (copy) v_u_423, (copy) v_u_424, (copy) v_u_422
						local v426 = p425 < 0.4 and 1 or 1 - (p425 - 0.4) / 0.6
						p_u_63.rigPlace(v_u_421, v_u_423, v_u_424 * v426)
						p_u_63.rigPlace(v_u_422, v_u_423, v_u_424 * v426)
						if p425 >= 1 then
							p_u_63.rigDestroy(v_u_421)
							p_u_63.rigDestroy(v_u_422)
						end
					end)
				end
				v_u_4.flash(v_u_408 + Vector3.new(0, 4, 0), v_u_9, v407 * 1.2, 0.22)
				local v_u_427 = p403.lite
				local v_u_428 = 7
				local v_u_429 = 42
				p_u_63.after(0.04, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_428, (copy) v_u_408, (ref) v_u_19, (ref) v_u_13, (ref) v_u_16, (ref) v_u_62, (ref) v_u_9, (ref) v_u_1, (ref) p_u_63, (copy) v_u_429, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_427, (ref) v_u_37, (ref) v_u_41, (ref) v_u_54, (ref) v_u_3, (ref) v_u_46
					local v430 = v_u_428
					local v431 = v_u_428
					local v432 = Vector3.new(0.5, v430, v431)
					local v433 = {
						["shape"] = nil,
						["transparency"] = 0.7,
						["shape"] = v_u_16
					}
					local v_u_434 = v_u_4.part(v432, CFrame.new(v_u_408) * v_u_19, v_u_13, v433)
					local v_u_435, v_u_436 = v_u_62(v_u_408, v_u_428, 1)
					local v437 = v_u_4.part
					local v438 = v_u_428 * 0.36
					local v439 = v_u_428 * 0.36
					local v440 = Vector3.new(0.5, v438, v439)
					local v441 = {
						["shape"] = v_u_16
					}
					local v_u_442 = v437(v440, CFrame.new(v_u_408) * v_u_19, v_u_9, v441)
					v_u_1:AddItem(v_u_434, 1)
					v_u_1:AddItem(v_u_442, 1)
					p_u_63.animate(0.8, 0, function(p443)
						-- upvalues: (ref) v_u_429, (ref) v_u_428, (copy) v_u_434, (ref) v_u_408, (ref) v_u_19, (copy) v_u_442, (copy) v_u_436, (copy) v_u_435
						local v444 = p443 / 0.18
						local v445 = math.min(v444, 1)
						local v446 = v_u_429 * (1 - (1 - v445) ^ 3)
						local v447 = math.max(v446, 0.5)
						local v448 = p443 <= 0.35 and 1 or 1 - (p443 - 0.35) / 0.65
						local v449 = v_u_428 * (v445 * 0.35 + 1) * math.max(v448, 0.05)
						v_u_434.Size = Vector3.new(v447, v449, v449)
						v_u_434.CFrame = CFrame.new(v_u_408 + Vector3.new(0, 1, 0) * v447 / 2) * v_u_19
						local v450 = v_u_442
						local v451 = v447 * 1.03
						local v452 = v449 * 0.36
						local v453 = v449 * 0.36
						v450.Size = Vector3.new(v451, v452, v453)
						v_u_442.CFrame = v_u_434.CFrame
						local v454 = v_u_434
						local v455 = p443 - 0.55
						v454.Transparency = math.max(v455, 0) * 0.3 / 0.45 + 0.7
						local v456 = v_u_442
						local v457 = p443 - 0.45
						v456.Transparency = math.max(v457, 0) / 0.55
						local v458 = v_u_436
						local v459 = v447 * 1.1
						v458.Position = Vector3.new(0, v459, 0)
						v_u_435.Width0 = v449 * 2.3
						v_u_435.Width1 = v449 * 1.5
						if p443 > 0.5 then
							v_u_435.Transparency = NumberSequence.new((p443 - 0.5) / 0.5)
						end
						if p443 >= 1 then
							v_u_434:Destroy()
							v_u_442:Destroy()
							v_u_435.Enabled = false
						end
					end)
					p_u_63.pop(v_u_408 + Vector3.new(0, 1, 0), v_u_8, v_u_428, v_u_428 * 3, 0.28, 0.3)
					v_u_4.ring(v_u_408, v_u_7, v_u_428 * 2.2, 0.45, v_u_6.Shockwave)
					for v_u_460 = 0, v_u_427 and 0 or 2 do
						local v_u_461 = v_u_37(CFrame.new(v_u_408), v_u_428, v_u_6.Ring, v_u_8, 0)
						v_u_1:AddItem(v_u_461, 0.6)
						p_u_63.animate(0.32, 0, function(p462)
							-- upvalues: (copy) v_u_460, (copy) v_u_461, (ref) v_u_408, (ref) v_u_429, (ref) v_u_428, (ref) v_u_41
							local v463 = p462 * 1.5 - v_u_460 * 0.25
							local v464 = math.clamp(v463, 0, 1)
							v_u_461.CFrame = CFrame.new(v_u_408 + Vector3.new(0, 1, 0) * v_u_429 * v464)
							local v465 = v_u_461
							local v466 = v_u_428 * (1.5 - v464 * 0.6)
							local v467 = v466 * 2
							local v468 = v466 * 2
							v465.Size = Vector3.new(v467, 0.05, v468)
							v_u_41(v_u_461, v464 ^ 3)
							if p462 >= 1 then
								v_u_461:Destroy()
							end
						end)
					end
					p_u_63.after(0.15, function()
						-- upvalues: (ref) p_u_63, (ref) v_u_408, (ref) v_u_429, (ref) v_u_8, (ref) v_u_428, (ref) v_u_427, (ref) v_u_54
						p_u_63.pop(v_u_408 + Vector3.new(0, 1, 0) * v_u_429, v_u_8, v_u_428, v_u_428 * 2.6, 0.3, 0.35)
						if not v_u_427 then
							v_u_54(v_u_408 + Vector3.new(0, 1, 0) * (v_u_429 - v_u_428), 5, v_u_428 * 0.8, 70, 10)
						end
					end)
					if not v_u_427 then
						local v469 = Instance.new("Attachment")
						v469.WorldPosition = v_u_408 + Vector3.new(0, 1, 0) * v_u_428
						v469.Parent = v_u_3.Terrain
						local v470 = v_u_46(v469, v_u_428 * 0.85, 0.6)
						v470.Speed = NumberRange.new(v_u_429 * 0.6, v_u_429 * 1.1)
						v470.SpreadAngle = Vector2.new(10, 10)
						v470.Drag = 2.5
						v470:Emit(v_u_428 > 5 and 8 or 4)
						v_u_1:AddItem(v469, 1)
					end
				end)
				for _, v471 in {
					v412,
					-v412,
					v413,
					-v413
				} do
					local v_u_472 = v_u_408 + v471 * v407 * 0.82
					local v_u_473 = p403.lite
					local v_u_474 = 3.6
					local v_u_475 = 22
					p_u_63.after(0.1, function()
						-- upvalues: (ref) v_u_4, (copy) v_u_474, (copy) v_u_472, (ref) v_u_19, (ref) v_u_13, (ref) v_u_16, (ref) v_u_62, (ref) v_u_9, (ref) v_u_1, (ref) p_u_63, (copy) v_u_475, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_473, (ref) v_u_37, (ref) v_u_41, (ref) v_u_54, (ref) v_u_3, (ref) v_u_46
						local v476 = v_u_474
						local v477 = v_u_474
						local v478 = Vector3.new(0.5, v476, v477)
						local v479 = {
							["shape"] = nil,
							["transparency"] = 0.7,
							["shape"] = v_u_16
						}
						local v_u_480 = v_u_4.part(v478, CFrame.new(v_u_472) * v_u_19, v_u_13, v479)
						local v_u_481, v_u_482 = v_u_62(v_u_472, v_u_474, 1)
						local v483 = v_u_4.part
						local v484 = v_u_474 * 0.36
						local v485 = v_u_474 * 0.36
						local v486 = Vector3.new(0.5, v484, v485)
						local v487 = {
							["shape"] = v_u_16
						}
						local v_u_488 = v483(v486, CFrame.new(v_u_472) * v_u_19, v_u_9, v487)
						v_u_1:AddItem(v_u_480, 1)
						v_u_1:AddItem(v_u_488, 1)
						p_u_63.animate(0.8, 0, function(p489)
							-- upvalues: (ref) v_u_475, (ref) v_u_474, (copy) v_u_480, (ref) v_u_472, (ref) v_u_19, (copy) v_u_488, (copy) v_u_482, (copy) v_u_481
							local v490 = p489 / 0.18
							local v491 = math.min(v490, 1)
							local v492 = v_u_475 * (1 - (1 - v491) ^ 3)
							local v493 = math.max(v492, 0.5)
							local v494 = p489 <= 0.35 and 1 or 1 - (p489 - 0.35) / 0.65
							local v495 = v_u_474 * (v491 * 0.35 + 1) * math.max(v494, 0.05)
							v_u_480.Size = Vector3.new(v493, v495, v495)
							v_u_480.CFrame = CFrame.new(v_u_472 + Vector3.new(0, 1, 0) * v493 / 2) * v_u_19
							local v496 = v_u_488
							local v497 = v493 * 1.03
							local v498 = v495 * 0.36
							local v499 = v495 * 0.36
							v496.Size = Vector3.new(v497, v498, v499)
							v_u_488.CFrame = v_u_480.CFrame
							local v500 = v_u_480
							local v501 = p489 - 0.55
							v500.Transparency = math.max(v501, 0) * 0.3 / 0.45 + 0.7
							local v502 = v_u_488
							local v503 = p489 - 0.45
							v502.Transparency = math.max(v503, 0) / 0.55
							local v504 = v_u_482
							local v505 = v493 * 1.1
							v504.Position = Vector3.new(0, v505, 0)
							v_u_481.Width0 = v495 * 2.3
							v_u_481.Width1 = v495 * 1.5
							if p489 > 0.5 then
								v_u_481.Transparency = NumberSequence.new((p489 - 0.5) / 0.5)
							end
							if p489 >= 1 then
								v_u_480:Destroy()
								v_u_488:Destroy()
								v_u_481.Enabled = false
							end
						end)
						p_u_63.pop(v_u_472 + Vector3.new(0, 1, 0), v_u_8, v_u_474, v_u_474 * 3, 0.28, 0.3)
						v_u_4.ring(v_u_472, v_u_7, v_u_474 * 2.2, 0.45, v_u_6.Shockwave)
						for v_u_506 = 0, v_u_473 and 0 or 2 do
							local v_u_507 = v_u_37(CFrame.new(v_u_472), v_u_474, v_u_6.Ring, v_u_8, 0)
							v_u_1:AddItem(v_u_507, 0.6)
							p_u_63.animate(0.32, 0, function(p508)
								-- upvalues: (copy) v_u_506, (copy) v_u_507, (ref) v_u_472, (ref) v_u_475, (ref) v_u_474, (ref) v_u_41
								local v509 = p508 * 1.5 - v_u_506 * 0.25
								local v510 = math.clamp(v509, 0, 1)
								v_u_507.CFrame = CFrame.new(v_u_472 + Vector3.new(0, 1, 0) * v_u_475 * v510)
								local v511 = v_u_507
								local v512 = v_u_474 * (1.5 - v510 * 0.6)
								local v513 = v512 * 2
								local v514 = v512 * 2
								v511.Size = Vector3.new(v513, 0.05, v514)
								v_u_41(v_u_507, v510 ^ 3)
								if p508 >= 1 then
									v_u_507:Destroy()
								end
							end)
						end
						p_u_63.after(0.15, function()
							-- upvalues: (ref) p_u_63, (ref) v_u_472, (ref) v_u_475, (ref) v_u_8, (ref) v_u_474, (ref) v_u_473, (ref) v_u_54
							p_u_63.pop(v_u_472 + Vector3.new(0, 1, 0) * v_u_475, v_u_8, v_u_474, v_u_474 * 2.6, 0.3, 0.35)
							if not v_u_473 then
								v_u_54(v_u_472 + Vector3.new(0, 1, 0) * (v_u_475 - v_u_474), 5, v_u_474 * 0.8, 70, 10)
							end
						end)
						if not v_u_473 then
							local v515 = Instance.new("Attachment")
							v515.WorldPosition = v_u_472 + Vector3.new(0, 1, 0) * v_u_474
							v515.Parent = v_u_3.Terrain
							local v516 = v_u_46(v515, v_u_474 * 0.85, 0.6)
							v516.Speed = NumberRange.new(v_u_475 * 0.6, v_u_475 * 1.1)
							v516.SpreadAngle = Vector2.new(10, 10)
							v516.Drag = 2.5
							v516:Emit(v_u_474 > 5 and 8 or 4)
							v_u_1:AddItem(v515, 1)
						end
					end)
				end
				p_u_63.pop(v_u_408 + Vector3.new(0, 2, 0), v_u_7, v407 * 0.5, v407 * 2.2, 0.5, 0.45)
				v_u_4.ring(v_u_408, v_u_8, v407 * 1.4, 0.5, v_u_6.Shockwave)
				v_u_4.ring(v_u_408, v_u_7, v407 * 1.8, 0.65, v_u_6.Ring)
				p_u_63.burst("Shockwave", v_u_408 + Vector3.new(0, 0.3, 0), v_u_7, v407 / 13)
				p_u_63.burst("Explosion", v_u_408 + Vector3.new(0, 2, 0), v_u_7, 2.2)
				p_u_63.spikes(v_u_408 + Vector3.new(0, 3, 0), v_u_8, v406 and 6 or 14, v407 * 1.2, 0.32, Vector3.new(0, 1, 0), 0.9)
				p_u_63.chunks(v_u_408 + Vector3.new(0, 1, 0), { v_u_11, v_u_14, v_u_7 }, v406 and 6 or 16, 48, 1.2, 1.4, false, 1.1)
				if not v406 then
					p_u_63.mark(v_u_408, v_u_7, v407 * 0.9, 1.6, v_u_6.Glow, 0.35)
				end
				v_u_5.play("Explosion", {
					["at"] = v_u_408,
					["volume"] = p403.mine and 1 or 0.6
				})
				if p403.mine then
					v_u_4.shake(0.6, 0.5)
				end
			end,
			["hit"] = function(p517, p518, _) -- name: hit
				-- upvalues: (copy) p_u_63, (ref) v_u_8
				p_u_63.burst("Impact", p518, v_u_8, 0.7)
				if not p517.lite then
					p_u_63.spikes(p518 + Vector3.new(0, 2.5, 0), v_u_8, 2, 4, 0.18, Vector3.new(-0, -1, -0), 0.15)
				end
			end
		}
	}
	return v519
end