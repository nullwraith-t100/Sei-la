local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("2338D8")
local v_u_9 = Color3.fromHex("050A3A")
local v_u_10 = Color3.fromRGB(70, 125, 255)
local v_u_11 = Color3.fromRGB(196, 222, 255)
local v_u_12 = Color3.fromRGB(6, 8, 22)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.PartType.Ball
local function v_u_22(p15, p16, p17, p18, p19) -- name: egg
	-- upvalues: (copy) v_u_5
	local v20 = v_u_5.part(p15, p16, p17, {
		["transparency"] = p18,
		["material"] = p19
	})
	local v21 = Instance.new("SpecialMesh")
	v21.MeshType = Enum.MeshType.Sphere
	v21.Parent = v20
	return v20
end
local function v_u_34(p23, p24, p25, p26, p27) -- name: picture
	-- upvalues: (copy) v_u_5
	local v28 = v_u_5.part
	local v29 = p24 * 2
	local v30 = p24 * 2
	local v31 = v28(Vector3.new(v29, 0.05, v30), p23, p26, {
		["transparency"] = 1
	})
	for _, v32 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v33 = Instance.new("Decal")
		v33.Face = v32
		v33.Texture = p25
		v33.Color3 = p26
		v33.Transparency = p27
		v33.Parent = v31
	end
	return v31
end
local function v_u_38(p35, p36) -- name: fadeDecals
	for _, v37 in p35:GetChildren() do
		if not v37:IsA("Decal") then
			continue
		end
		v37.Transparency = p36
	end
end
local function v_u_49(p39, p40, p41, p42, p43, p44, p45, p46) -- name: sheet
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v47 = Instance.new("Attachment")
	v47.WorldPosition = p39
	v47.Parent = v_u_4.Terrain
	local v48 = Instance.new("ParticleEmitter")
	v48.Texture = p40
	v48.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v48.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v48.Color = ColorSequence.new(p41)
	v48.LightEmission = 0.35
	v48.LightInfluence = 0
	v48.ZOffset = p46 or 0
	v48.Lifetime = NumberRange.new(p44 * 0.8, p44)
	v48.Speed = NumberRange.new((p45 or 0) * 0.6, p45 or 0)
	v48.SpreadAngle = Vector2.new(180, 180)
	v48.Rotation = NumberRange.new(-20, 20)
	v48.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p42 * 0.4), NumberSequenceKeypoint.new(1, p42 * 0.55) })
	v48.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.75, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v48.Enabled = false
	v48.Parent = v47
	v48:Emit(p43)
	v_u_1:AddItem(v47, p44 + 0.2)
end
local function v_u_57(p50, p51, p52, p53, p54) -- name: bubbler
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	local v55 = Instance.new("ParticleEmitter")
	v55.Texture = v_u_7.TideBubble
	v55.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v55.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v55.Color = ColorSequence.new(v_u_11)
	v55.LightEmission = 0.3
	v55.LightInfluence = 0
	v55.Lifetime = NumberRange.new(p54 * 0.7, p54)
	v55.Speed = NumberRange.new(p53 * 0.5, p53)
	local v56 = p53 * 1.5
	v55.Acceleration = Vector3.new(0, v56, 0)
	v55.SpreadAngle = Vector2.new(35, 35)
	v55.EmissionDirection = Enum.NormalId.Top
	v55.Size = NumberSequence.new(p52 * 0.7, p52)
	v55.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 0.6) })
	v55.Rate = p51
	v55.Enabled = p51 > 0
	v55.Parent = p50
	return v55
end
return function(p_u_58)
	-- upvalues: (copy) v_u_34, (copy) v_u_1, (copy) v_u_38, (copy) v_u_4, (copy) v_u_22, (copy) v_u_10, (copy) v_u_13, (copy) v_u_7, (copy) v_u_5, (copy) v_u_12, (copy) v_u_8, (copy) v_u_11, (copy) v_u_14, (copy) v_u_9, (copy) v_u_57, (copy) v_u_49, (copy) v_u_2, (copy) v_u_6
	local function v_u_76(p_u_59, p_u_60, p_u_61, p62, p63, p_u_64, p_u_65, p66) -- name: flare
		-- upvalues: (ref) v_u_34, (ref) v_u_1, (copy) p_u_58, (ref) v_u_38
		local v_u_67 = p66 or 0
		local v_u_68 = v_u_34(p_u_59, p_u_60, p62, p63, v_u_67)
		v_u_1:AddItem(v_u_68, p_u_64 + 0.1)
		p_u_58.animate(p_u_64, 0, function(p69)
			-- upvalues: (copy) p_u_60, (copy) p_u_61, (copy) v_u_68, (copy) p_u_59, (copy) p_u_64, (copy) p_u_65, (ref) v_u_38, (copy) v_u_67
			local v70 = 1 - (1 - p69) ^ 3
			local v71 = p_u_60 + (p_u_61 - p_u_60) * v70
			local v72 = math.max(v71, 0.05)
			local v73 = v_u_68
			local v74 = v72 * 2
			local v75 = v72 * 2
			v73.Size = Vector3.new(v74, 0.05, v75)
			v_u_68.CFrame = p_u_59 * CFrame.Angles(0, p69 * p_u_64 * p_u_65, 0)
			v_u_38(v_u_68, v_u_67 + (1 - v_u_67) * p69 ^ 1.5)
			if p69 >= 1 then
				v_u_68:Destroy()
			end
		end)
	end
	local function v_u_105(p77, p_u_78, p_u_79, p80) -- name: spindleFlash
		-- upvalues: (copy) p_u_58, (ref) v_u_4, (ref) v_u_22, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1
		local v81 = p_u_58.flatUnit
		local v82 = v_u_4.CurrentCamera
		local v83
		if v82 then
			local v84 = v82.CFrame.Position - p77
			v83 = v84.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v84.Unit
		else
			v83 = Vector3.new(0, 0, 1)
		end
		local v85 = v81(v83)
		local v86 = CFrame.lookAt(p77, p77 - v85)
		local v87 = v_u_22
		local v88 = p_u_78 * 0.3
		local v_u_89 = v87(Vector3.new(p_u_79, v88, 0.3), v86, v_u_10, 0.2)
		local v90 = v_u_22
		local v91 = p_u_79 * 0.4
		local v92 = p_u_78 * 0.3
		local v_u_93 = v90(Vector3.new(v91, v92, 0.35), v86, v_u_13, 0)
		v_u_1:AddItem(v_u_89, p80 + 0.1)
		v_u_1:AddItem(v_u_93, p80 + 0.1)
		p_u_58.animate(p80, 0, function(p94)
			-- upvalues: (copy) p_u_78, (copy) v_u_89, (copy) p_u_79, (copy) v_u_93
			local v95 = p94 / 0.25
			local v96 = p_u_78 * ((1 - (1 - math.min(v95, 1)) ^ 2) * 0.7 + 0.3)
			local v97 = 1 - p94 ^ 1.6
			local v98 = v_u_89
			local v99 = p_u_79 * v97
			local v100 = math.max(v99, 0.05)
			v98.Size = Vector3.new(v100, v96, 0.3)
			local v101 = v_u_93
			local v102 = p_u_79 * 0.4 * v97
			local v103 = math.max(v102, 0.05)
			local v104 = v96 * 0.92
			v101.Size = Vector3.new(v103, v104, 0.35)
			v_u_89.Transparency = 0.2 + 0.8 * p94
			v_u_93.Transparency = p94
			if p94 >= 1 then
				v_u_89:Destroy()
				v_u_93:Destroy()
			end
		end)
	end
	local function v124(p106, p107) -- name: needleShot
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_22, (ref) v_u_12, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14, (copy) p_u_58, (ref) v_u_9, (ref) v_u_57
		local v108 = p106.size
		local v109 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p107, v_u_10, {
			["transparency"] = 1
		})
		local v110 = v_u_22(Vector3.new(0.6, 0.22, 3.4) * v108, p107, v_u_12, 0, Enum.Material.SmoothPlastic)
		v110.Reflectance = 0.25
		local v111 = v_u_22(Vector3.new(1.05, 0.5, 4) * v108, p107, v_u_8, 0.45)
		local v112 = v_u_22(Vector3.new(0.12, 0.3, 3) * v108, p107, v_u_10, 0)
		local v113 = {
			["shape"] = v_u_14
		}
		local v114 = v_u_5.part(Vector3.new(0.34, 0.34, 0.34) * v108, p107, v_u_11, v113)
		local v115 = {
			{
				["p"] = v110,
				["off"] = CFrame.identity
			},
			{
				["p"] = v111,
				["off"] = CFrame.identity
			},
			{
				["p"] = v112,
				["off"] = CFrame.identity
			},
			{
				["p"] = v114,
				["off"] = CFrame.new(0, 0, -1.65 * v108)
			}
		}
		local v116 = {}
		local v117 = {}
		p_u_58.streak(v109, v_u_10, v_u_9, 0.55 * v108, 0.16)
		if not p106.lite then
			for _ = 1, 2 do
				local v118 = v_u_5.part
				local v119 = Vector3.new(0.26, 0.26, 0.26) * v108
				local v120 = v_u_11
				local v121 = {
					["shape"] = v_u_14
				}
				table.insert(v116, v118(v119, p107, v120, v121))
			end
			local v122 = Instance.new("Attachment")
			v122.Parent = v110
			local v_u_123 = v_u_57(v122, 26, 0.45 * v108, 2, 0.45)
			table.insert(v117, function()
				-- upvalues: (copy) v_u_123
				v_u_123.Enabled = false
			end)
		end
		if p106.mine then
			p_u_58.light(v109, v_u_10, 9 * v108)
		end
		return p_u_58.assemble(v109, v115, v116, 0.6 * v108, 24, v117, 0.16, 16)
	end
	local function v131(p125, p126) -- name: needleImpact
		-- upvalues: (ref) v_u_4, (copy) v_u_105, (copy) p_u_58, (ref) v_u_8, (ref) v_u_13, (copy) v_u_76, (ref) v_u_7, (ref) v_u_11, (ref) v_u_5, (ref) v_u_49, (ref) v_u_10
		local v127 = p125.size
		local v128 = v_u_4.CurrentCamera
		local v129
		if v128 then
			local v130 = v128.CFrame.Position - p126
			v129 = v130.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v130.Unit
		else
			v129 = Vector3.new(0, 0, 1)
		end
		v_u_105(p126 - Vector3.new(0, 0.6, 0), 7 * v127, 1.3 * v127, 0.22)
		p_u_58.pop(p126, v_u_8, 1.6 * v127, 5.5 * v127, 0.16, 0.35)
		p_u_58.pop(p126, v_u_13, 1.2 * v127, 0.4 * v127, 0.1)
		v_u_76(p_u_58.facing(p126 + v129 * 0.4, v129), 0.6 * v127, 3.4 * v127, v_u_7.Ring, v_u_11, 0.2, 0, 0.05)
		v_u_5.ring(p_u_58.ground(p126), v_u_8, p125.ability.radius * 0.6 * v127, 0.25, v_u_7.Ring)
		if not p125.lite then
			v_u_49(p126, v_u_7.TideSplash, v_u_10, 4.5 * v127, 2, 0.4, 0, 1)
			p_u_58.spikes(p126, v_u_11, 3, 3.2 * v127, 0.14, nil, nil, true)
		end
		p_u_58.hitSound(p126)
	end
	local v_u_132 = {}
	setmetatable(v_u_132, {
		["__mode"] = "k"
	})
	local function v_u_161(p133, p134, p135) -- name: newCrush
		-- upvalues: (copy) p_u_58, (ref) v_u_5, (ref) v_u_8, (ref) v_u_14, (ref) v_u_9, (ref) v_u_34, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_1
		local v_u_136 = p133.ability.radius * p133.size
		local v137 = p_u_58.ground(p134, 2)
		local v_u_138 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_136 * 2.6, CFrame.new(v137), v_u_8, {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0,
			["shape"] = v_u_14,
			["material"] = Enum.Material.ForceField
		})
		local v_u_139 = v_u_5.part(Vector3.new(1, 1, 1) * v_u_136 * 2.5, CFrame.new(v137), v_u_9, {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.62,
			["shape"] = v_u_14,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v_u_140 = {}
		local v141 = { v_u_138, v_u_139 }
		for v142, v143 in { -0.15, 0.35 } do
			local v144 = v_u_34
			local v145 = CFrame.new(v137 + Vector3.new(0, 1, 0) * v_u_136 * v143)
			local v146 = v_u_136 * 1.4
			local v147 = v_u_7.Ring
			local v148
			if v142 == 1 then
				v148 = v_u_10
			else
				v148 = v_u_11
			end
			local v149 = v144(v145, v146, v147, v148, 0.15)
			table.insert(v_u_140, v149)
		end
		for _, v150 in v141 do
			v_u_1:AddItem(v150, p135 + 1.5)
		end
		for _, v151 in v_u_140 do
			v_u_1:AddItem(v151, p135 + 1.5)
		end
		local v_u_152 = {
			["parts"] = nil,
			["rings"] = nil,
			["mid"] = nil,
			["taken"] = false,
			["parts"] = v141,
			["rings"] = v_u_140,
			["mid"] = v137
		}
		local v153 = math.max(p135, 0.05)
		p_u_58.animate(v153, 0, function(p154)
			-- upvalues: (copy) v_u_152, (copy) v_u_138, (copy) v_u_136, (copy) v_u_139, (copy) v_u_140
			if not v_u_152.taken then
				local v155 = 1 - (1 - p154) ^ 2
				v_u_138.Size = Vector3.new(1, 1, 1) * v_u_136 * (2.6 - 0.55 * v155)
				v_u_139.Size = Vector3.new(1, 1, 1) * v_u_136 * (2.5 - 0.55 * v155)
				v_u_139.Transparency = 0.62 - 0.12 * v155
				for v156, v157 in v_u_140 do
					local v158 = v_u_136 * (1.4 - 0.4 * v155) * (v156 == 1 and 1 or 0.85)
					local v159 = v158 * 2
					local v160 = v158 * 2
					v157.Size = Vector3.new(v159, 0.05, v160)
					v157.CFrame = CFrame.new(v157.Position) * CFrame.Angles(0, p154 * (v156 == 1 and 2 or -2), 0)
				end
			end
		end)
		return v_u_152
	end
	local function v_u_175(p162, p163, p164) -- name: release
		-- upvalues: (copy) p_u_58, (ref) v_u_5, (ref) v_u_11, (ref) v_u_10, (ref) v_u_13, (copy) v_u_105, (ref) v_u_8, (ref) v_u_7, (ref) v_u_49, (ref) v_u_9, (ref) v_u_4, (ref) v_u_57, (ref) v_u_1
		local v165 = p162.size
		local v166 = p162.ability.radius * v165
		local v167 = p162.lite
		local v168 = p_u_58.ground(p163)
		v_u_5.flash(p164, v_u_11, v166 * 0.75, 0.12)
		p_u_58.pop(p164, v_u_10, 2, v166 * 1.7, 0.35, 0.35)
		p_u_58.pop(p164, v_u_13, 1.5, 7, 0.14)
		v_u_105(v168, 26, 3.2, 0.4)
		v_u_5.ring(v168, v_u_8, v166 * 1.25, 0.45, v_u_7.Shockwave)
		v_u_5.ring(v168, v_u_11, v166, 0.35, v_u_7.Ring)
		local v169 = p_u_58.burst
		local v170 = v168 + Vector3.new(0, 0.3, 0)
		local v171 = v_u_8
		local v172 = v166 / 16
		v169("Shockwave", v170, v171, (math.min(v172, 1.5)))
		v_u_49(p_u_58.ground(p163, 1.5), v_u_7.TideSplash, v_u_10, 11, v167 and 2 or 4, 0.5, 6, 2)
		p_u_58.chunks(p_u_58.ground(p163, 1), { v_u_8, v_u_10, v_u_11 }, v167 and 4 or 10, 45, 0.7, 1, true)
		p_u_58.mark(p163, v_u_9, v166 * 0.75, 2, v_u_7.CrackLines, 0.1)
		if not v167 then
			local v173 = Instance.new("Attachment")
			v173.WorldPosition = p164
			v173.Parent = v_u_4.Terrain
			local v174 = v_u_57(v173, 0, 1.1, 26, 0.7)
			v174.SpreadAngle = Vector2.new(180, 180)
			v174.Acceleration = Vector3.new(0, 6, 0)
			v174:Emit(14)
			v_u_1:AddItem(v173, 1)
			p_u_58.spikes(p164, v_u_11, 6, v166 * 0.9, 0.25, nil, nil, true)
		end
		p_u_58.hitSound(v168, true)
		if p162.mine then
			v_u_5.shake(0.35, 0.3)
		end
	end
	local v_u_176 = {}
	setmetatable(v_u_176, {
		["__mode"] = "k"
	})
	local function v_u_185(p177, p178, p179) -- name: newSpindle
		-- upvalues: (ref) v_u_22, (ref) v_u_12, (ref) v_u_8, (ref) v_u_10, (ref) v_u_1
		local v180 = CFrame.new(p179)
		local v181 = v_u_22(Vector3.new(2.4, 18, 0.8), v180, v_u_12, 0, Enum.Material.SmoothPlastic)
		v181.Reflectance = 0.2
		local v182 = v_u_22(Vector3.new(3.6000001, 19.44, 1.4399999), v180, v_u_8, p177 and 0.55 or 0.4)
		local v183 = v_u_22(Vector3.new(0.3, 15.84, 0.92), v180, v_u_10, 0)
		for _, v184 in { v181, v182, v183 } do
			v_u_1:AddItem(v184, p178)
		end
		return {
			["core"] = nil,
			["sheath"] = nil,
			["seam"] = nil,
			["taken"] = false,
			["gone"] = false,
			["core"] = v181,
			["sheath"] = v182,
			["seam"] = v183
		}
	end
	local function v_u_194(p186, p187) -- name: currents
		-- upvalues: (ref) v_u_7, (ref) v_u_13
		local v188 = {}
		for v189 = 1, p187 do
			local v190 = Instance.new("Attachment")
			v190.Parent = p186
			local v191 = Instance.new("Attachment")
			v191.Parent = p186
			local v192 = Instance.new("Beam")
			v192.Attachment0 = v190
			v192.Attachment1 = v191
			v192.Texture = v_u_7.AbyssWater
			v192.TextureMode = Enum.TextureMode.Wrap
			v192.TextureLength = 6
			v192.TextureSpeed = 2.5
			v192.LightEmission = 0.25
			v192.LightInfluence = 0
			v192.Color = ColorSequence.new(v_u_13)
			v192.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.3, 0.15),
				NumberSequenceKeypoint.new(0.8, 0.2),
				NumberSequenceKeypoint.new(1, 1)
			})
			v192.FaceCamera = false
			v192.Segments = 10
			v192.Parent = p186
			local v193 = {
				["a0"] = v190,
				["a1"] = v191,
				["beam"] = v192,
				["at"] = v189 / p187 * 3.141592653589793 * 2,
				["r0"] = 0.95 - v189 % 2 * 0.15,
				["r1"] = v189 % 3 * 0.08 + 0.35
			}
			table.insert(v188, v193)
		end
		return v188
	end
	local function v_u_223(p195, p196, p197, p198) -- name: shapeCurrents
		for _, v199 in p195 do
			local v200 = v199.r0 * p196
			local v201 = v199.r1 * p196
			local v202 = v199.at
			local v203 = math.cos(v202) * v200
			local v204 = v199.at
			local v205 = math.sin(v204) * v200
			local v206 = Vector3.new(v203, p197, v205)
			local v207 = v199.at + 1.9
			local v208 = math.cos(v207) * v201
			local v209 = v199.at + 1.9
			local v210 = math.sin(v209) * v201
			local v211 = Vector3.new(v208, p197, v210)
			local v212 = v199.at
			local v213 = -math.sin(v212)
			local v214 = v199.at
			local v215 = math.cos(v214)
			local v216 = Vector3.new(v213, 0, v215)
			local v217 = v199.at + 1.9
			local v218 = -math.sin(v217)
			local v219 = v199.at + 1.9
			local v220 = math.cos(v219)
			local v221 = Vector3.new(v218, 0, v220)
			v199.a0.CFrame = CFrame.fromMatrix(v206, v216, Vector3.new(0, 1, 0))
			v199.a1.CFrame = CFrame.fromMatrix(v211, v221, Vector3.new(0, 1, 0))
			local v222 = (v200 + v201) * 0.6856961508979934 / 2
			v199.beam.CurveSize0 = v222
			v199.beam.CurveSize1 = v222
			v199.beam.Width0 = p198
			v199.beam.Width1 = p198 * 0.55
		end
	end
	local v_u_224 = 0
	local function v_u_228() -- name: deepFrame
		-- upvalues: (ref) v_u_224, (ref) v_u_2, (ref) v_u_5, (copy) p_u_58, (ref) v_u_13, (ref) v_u_1
		local v225 = os.clock()
		if v225 >= v_u_224 then
			v_u_224 = v225 + 0.8
			local v_u_226 = Instance.new("ColorCorrectionEffect")
			v_u_226.Name = "DrowningDepths"
			v_u_226.Parent = v_u_2
			v_u_5.tween(v_u_226, 0.06, {
				["TintColor"] = nil,
				["Contrast"] = 0.2,
				["Saturation"] = 0.2,
				["TintColor"] = Color3.fromRGB(190, 210, 255)
			})
			p_u_58.after(0.16, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_226, (ref) v_u_13
				local v227 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_13
				}
				v_u_5.tween(v_u_226, 0.55, v227)
			end)
			v_u_1:AddItem(v_u_226, 0.8)
		end
	end
	local function v_u_280(p229, p230, p_u_231) -- name: geyser
		-- upvalues: (copy) p_u_58, (ref) v_u_5, (ref) v_u_13, (ref) v_u_1, (ref) v_u_7, (ref) v_u_11, (ref) v_u_49, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_6, (copy) v_u_228
		local v_u_232 = p229.size
		local v_u_233 = p229.ability.radius * v_u_232
		local v_u_234 = p229.lite
		local v_u_235 = p_u_58.ground(p230, 0)
		local v_u_236 = 46 * v_u_232
		local v_u_237 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_235), v_u_13, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_237, 1.5)
		local v238 = Instance.new("Attachment")
		v238.Parent = v_u_237
		local v_u_239 = Instance.new("Attachment")
		v_u_239.Position = Vector3.new(0, 2, 0)
		v_u_239.Parent = v_u_237
		local v240
		if v_u_234 then
			v240 = {
				{
					["width"] = nil,
					["texture"] = nil,
					["color"] = nil,
					["glow"] = 0.25,
					["width"] = v_u_233 * 0.75,
					["texture"] = v_u_7.AbyssWater,
					["color"] = v_u_13
				}
			}
		else
			v240 = {
				{
					["width"] = nil,
					["texture"] = nil,
					["color"] = nil,
					["glow"] = 0.25,
					["width"] = v_u_233 * 0.95,
					["texture"] = v_u_7.AbyssWater,
					["color"] = v_u_13
				},
				{
					["width"] = nil,
					["texture"] = nil,
					["color"] = nil,
					["glow"] = 0.3,
					["width"] = v_u_233 * 0.55,
					["texture"] = v_u_7.AbyssWater,
					["color"] = v_u_11
				},
				{
					["width"] = nil,
					["texture"] = nil,
					["color"] = nil,
					["glow"] = 0.8,
					["width"] = v_u_233 * 0.22,
					["texture"] = v_u_7.Beam,
					["color"] = v_u_11
				}
			}
		end
		local v_u_241 = {}
		for v242, v243 in v240 do
			local v244 = Instance.new("Beam")
			v244.Attachment0 = v238
			v244.Attachment1 = v_u_239
			v244.Texture = v243.texture
			v244.TextureMode = Enum.TextureMode.Wrap
			v244.TextureLength = 9
			v244.TextureSpeed = -4 - v242
			v244.Color = ColorSequence.new(v243.color)
			v244.LightEmission = v243.glow
			v244.LightInfluence = 0
			v244.FaceCamera = true
			v244.Segments = 1
			v244.Parent = v_u_237
			local v245 = {
				["beam"] = v244,
				["width"] = v243.width
			}
			table.insert(v_u_241, v245)
		end
		local v_u_246 = p_u_58.pillar(v_u_235, 4, v_u_233 * 0.18, v_u_11, 0.25)
		v_u_1:AddItem(v_u_246, 1.3)
		local v_u_247 = false
		p_u_58.animate(1.2, 0, function(p248)
			-- upvalues: (copy) v_u_236, (copy) v_u_239, (copy) v_u_241, (copy) v_u_246, (copy) v_u_233, (copy) v_u_235, (ref) v_u_247, (ref) v_u_49, (ref) v_u_7, (ref) v_u_11, (copy) v_u_232, (copy) v_u_234, (ref) p_u_58, (ref) v_u_10, (ref) v_u_8, (copy) v_u_237
			local v249 = p248 * 1.2
			local v250 = v249 / 0.16
			local v251 = math.clamp(v250, 0, 1)
			local v252 = 4 + (v_u_236 - 4) * (1 - (1 - v251) ^ 3)
			local v253 = (v249 - 0.55) / 0.6499999999999999
			local v254 = math.clamp(v253, 0, 1)
			v_u_239.Position = Vector3.new(0, 1, 0) * v252
			for _, v255 in v_u_241 do
				local v256 = v255.width
				local v257 = v251 * 2
				local v258 = v256 * math.min(v257, 1) * (1 - v254 * 0.85)
				local v259 = v255.beam
				local v260 = v258 * 1.15
				v259.Width0 = math.max(v260, 0.05)
				local v261 = v255.beam
				local v262 = v258 * 0.8
				v261.Width1 = math.max(v262, 0.05)
				v255.beam.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v254 * 0.95 + 0.05), NumberSequenceKeypoint.new(0.85, v254 * 0.9 + 0.1), NumberSequenceKeypoint.new(1, v254 * 0.4 + 0.6) })
			end
			if v_u_246.Parent then
				local v263 = v_u_233 * 0.18 * (1 - v254)
				local v264 = math.max(v263, 0.05)
				v_u_246.Size = Vector3.new(v252, v264, v264)
				v_u_246.CFrame = CFrame.new(v_u_235 + Vector3.new(0, 1, 0) * v252 / 2) * CFrame.Angles(0, 0, 1.5707963267948966)
				v_u_246.Transparency = v254 * 0.75 + 0.25
			end
			if v251 >= 1 and not v_u_247 then
				v_u_247 = true
				local v265 = v_u_235 + Vector3.new(0, 1, 0) * v_u_236
				v_u_49(v265, v_u_7.TideSplash, v_u_11, 16 * v_u_232, v_u_234 and 2 or 4, 0.6, 10)
				p_u_58.chunks(v265, { v_u_11, v_u_10, v_u_8 }, v_u_234 and 6 or 16, 34, 0.8, 1.5, true, 0.5)
				p_u_58.pop(v265, v_u_11, 4, 14 * v_u_232, 0.3, 0.4)
			end
			if p248 >= 1 then
				v_u_237:Destroy()
			end
		end)
		v_u_5.flash(p_u_58.ground(p230, 4), v_u_11, v_u_233 * 0.9, 0.14)
		p_u_58.pop(p_u_58.ground(p230, 3), v_u_10, 4, v_u_233 * 1.7, 0.42, 0.4)
		v_u_49(p_u_58.ground(p230, 1), v_u_7.TideSplash, v_u_10, 14 * v_u_232, v_u_234 and 3 or 6, 0.55, 8, 2)
		v_u_5.ring(v_u_235, v_u_11, v_u_233 * 1.45, 0.5, v_u_7.Shockwave)
		v_u_5.ring(v_u_235, v_u_8, v_u_233 * 1.2, 0.6, v_u_7.Ring)
		local v266 = p_u_58.burst
		local v267 = v_u_235 + Vector3.new(0, 0.3, 0)
		local v268 = v_u_8
		local v269 = v_u_233 / 14
		v266("Shockwave", v267, v268, (math.min(v269, 1.6)))
		p_u_58.mark(p230, v_u_9, v_u_233 * 0.8, 2.5, v_u_7.CrackLines, 0.1)
		p_u_58.spikes(p_u_58.ground(p230, 1), v_u_11, v_u_234 and 5 or 10, v_u_233 * 1.2, 0.35, nil, nil, true)
		if not v_u_234 then
			p_u_58.chunks(p_u_58.ground(p230, 1), { p_u_58.EARTH[1], p_u_58.EARTH[2], v_u_9 }, 10, 50, 1.2, 1.3)
		end
		if p_u_231 and not p_u_231.gone then
			local v_u_270 = p_u_231.core.Position
			local v_u_271 = v_u_235 + Vector3.new(0, 1, 0) * (v_u_236 + 12)
			p_u_58.animate(0.9, 0, function(p272)
				-- upvalues: (copy) p_u_231, (copy) v_u_270, (copy) v_u_271, (ref) v_u_10, (ref) v_u_13
				local v273 = 1 - (1 - p272) ^ 2
				local v274 = p_u_231
				local v275 = CFrame.new(v_u_270:Lerp(v_u_271, v273)) * CFrame.Angles(0, p272 * 30, p272 * 1.2)
				local v276 = 1 - p272
				if not v274.gone then
					v274.core.CFrame = v275
					v274.sheath.CFrame = v275
					v274.seam.CFrame = v275
					v274.seam.Color = v_u_10:Lerp(v_u_13, (math.clamp(v276, 0, 1)))
				end
				if not p_u_231.gone then
					local v277 = p_u_231.core
					local v278 = (p272 - 0.5) * 2
					v277.Transparency = math.clamp(v278, 0, 1)
					p_u_231.sheath.Transparency = 0.4 + 0.6 * p272
					p_u_231.seam.Transparency = p272
				end
				if p272 >= 1 then
					local v279 = p_u_231
					if v279.gone then
						return
					end
					v279.gone = true
					v279.core:Destroy()
					v279.sheath:Destroy()
					v279.seam:Destroy()
				end
			end)
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_235,
			["volume"] = p229.mine and 1 or 0.6
		})
		if p229.mine then
			v_u_5.shake(0.6, 0.55)
			v_u_228()
		end
	end
	local v407 = {
		["abyss_spindle_a"] = {
			["cast"] = function(p281) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_58, (ref) v_u_11, (copy) v_u_76, (ref) v_u_7, (ref) v_u_10
				local v282 = p281.size
				local v283 = p281.eye + p281.dir * 1.1
				v_u_5.flash(v283, v_u_8, 2.8 * v282, 0.1)
				p_u_58.pop(v283, v_u_11, 1.1 * v282, 0.3 * v282, 0.1)
				if not p281.lite then
					v_u_76(p_u_58.facing(v283, p281.dir), 0.5 * v282, 2.3 * v282, v_u_7.Ring, v_u_10, 0.13, 0, 0.1)
				end
			end,
			["shot"] = v124,
			["impact"] = v131,
			["hit"] = function(p284, p285, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_8, (copy) v_u_105
				p_u_58.burst("Impact", p285, v_u_8, 0.6)
				if not p284.lite then
					v_u_105(p285 - Vector3.new(0, 0.5, 0), 3.5, 0.7, 0.14)
				end
			end
		},
		["abyss_spindle_e"] = {
			["cast"] = function(p286) -- name: cast
				-- upvalues: (copy) p_u_58, (ref) v_u_8, (copy) v_u_105
				p_u_58.skillCast(p286, v_u_8)
				v_u_105(p286.eye - Vector3.new(0, 1.2, 0) + p286.dir * 1.2, 4, 0.9, 0.2)
			end,
			["windup"] = function(p287, p288, p289) -- name: windup
				-- upvalues: (copy) v_u_132, (copy) v_u_161, (copy) p_u_58, (ref) v_u_11
				v_u_132[p287] = v_u_161(p287, p288, p289)
				local v290 = p287.ability.radius * p287.size
				p_u_58.inward(p_u_58.ground(p288, 3), v_u_11, p287.lite and 4 or 10, v290 * 1.4, math.max(p289, 0.08) + 0.05)
			end,
			["land"] = function(p_u_291, p_u_292) -- name: land
				-- upvalues: (copy) v_u_132, (copy) v_u_161, (copy) p_u_58, (copy) v_u_175
				local v293 = v_u_132[p_u_291]
				v_u_132[p_u_291] = nil
				local v_u_294 = v293 or v_u_161(p_u_291, p_u_292, 0)
				v_u_294.taken = true
				local v_u_295 = p_u_291.ability.radius * p_u_291.size
				local v_u_296 = v_u_294.parts[1]
				local v_u_297 = v_u_294.parts[2]
				local v_u_298 = v_u_296.Size.X
				p_u_58.animate(0.09, 0, function(p299)
					-- upvalues: (copy) v_u_298, (copy) v_u_296, (copy) v_u_297, (copy) v_u_294, (copy) v_u_295, (ref) v_u_175, (copy) p_u_291, (copy) p_u_292
					local v300 = p299 * p299
					local v301 = v_u_298 * (1 - v300) + 0.8 * v300
					local v302 = math.max(v301, 0.1)
					v_u_296.Size = Vector3.new(1, 1, 1) * v302
					v_u_297.Size = Vector3.new(1, 1, 1) * v302 * 0.97
					v_u_297.Transparency = 0.5 - 0.3 * p299
					for v303, v304 in v_u_294.rings do
						local v305 = v_u_295 * (1 - v300) * (v303 == 1 and 1 or 0.85)
						local v306 = math.max(v305, 0.05)
						local v307 = v306 * 2
						local v308 = v306 * 2
						v304.Size = Vector3.new(v307, 0.05, v308)
					end
					if p299 >= 1 then
						for _, v309 in v_u_294.parts do
							v309:Destroy()
						end
						for _, v310 in v_u_294.rings do
							v310:Destroy()
						end
						v_u_175(p_u_291, p_u_292, v_u_294.mid)
					end
				end)
			end,
			["hit"] = function(p311, p312, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_1
				p_u_58.burst("Impact", p312, v_u_8, 0.8)
				if not p311.lite then
					local v313 = p_u_58.ball(p312, v_u_9, 3.2, 0.5, Enum.Material.SmoothPlastic)
					v_u_5.tween(v313, 0.14, {
						["Size"] = Vector3.new(0.3, 0.3, 0.3),
						["Transparency"] = 0.9
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v313, 0.16)
				end
			end
		},
		["abyss_spindle_r"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p314) -- name: cast
				-- upvalues: (copy) p_u_58, (ref) v_u_8, (copy) v_u_105
				p_u_58.skillCast(p314, v_u_8, true)
				v_u_105(p314.eye - Vector3.new(0, 1.5, 0) + p314.dir * 1.2, 6, 1.2, 0.25)
			end,
			["windup"] = function(p315, p316, p317) -- name: windup
				-- upvalues: (copy) v_u_185, (copy) p_u_58, (copy) v_u_176, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (copy) v_u_76, (ref) v_u_7
				local v318 = p315.size
				local v_u_319 = math.max(p317, 0.05)
				local v_u_320 = v_u_185(p315.lite, v_u_319 + 6, p_u_58.ground(p316, 48 * v318))
				v_u_176[p315] = v_u_320
				local v_u_321 = p_u_58.ground(p316, 48 * v318)
				local v_u_322 = p_u_58.ground(p316, 4 * v318)
				p_u_58.streak(v_u_320.core, v_u_10, v_u_9, 2.2 * v318, 0.22)
				local v_u_323 = os.clock()
				p_u_58.runNow(function()
					-- upvalues: (copy) v_u_320, (copy) v_u_323, (copy) v_u_319, (copy) v_u_321, (copy) v_u_322, (ref) v_u_10, (ref) v_u_13
					if v_u_320.taken or v_u_320.gone then
						return false
					end
					local v324 = (os.clock() - v_u_323) / v_u_319
					local v325 = math.clamp(v324, 0, 1)
					local v326 = v_u_320
					local v327 = CFrame.new(v_u_321:Lerp(v_u_322, v325 * v325)) * CFrame.Angles(0, v325 * 8, 0)
					if not v326.gone then
						v326.core.CFrame = v327
						v326.sheath.CFrame = v327
						v326.seam.CFrame = v327
						v326.seam.Color = v_u_10:Lerp(v_u_13, 0.4)
					end
					return v325 < 1
				end)
				v_u_76(CFrame.new(p_u_58.ground(p316, 0.15)), 2, p315.ability.radius * v318, v_u_7.Ring, v_u_10, v_u_319 + 0.15, 2, 0.2)
			end,
			["zone"] = function(p_u_328, p_u_329, p_u_330) -- name: zone
				-- upvalues: (copy) v_u_176, (copy) v_u_185, (copy) p_u_58, (ref) v_u_5, (ref) v_u_11, (ref) v_u_49, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (ref) v_u_13, (copy) v_u_194, (ref) v_u_57, (copy) v_u_223, (copy) v_u_76
				local v_u_331 = p_u_328.size
				local v_u_332 = p_u_328.ability.radius * v_u_331
				local v_u_333 = p_u_328.lite
				local v334 = p_u_330 + 3
				local v_u_335 = v_u_176[p_u_328]
				if not v_u_335 or v_u_335.gone then
					v_u_335 = v_u_185(v_u_333, v334, p_u_58.ground(p_u_329, 4 * v_u_331))
				end
				v_u_335.taken = true
				v_u_176[p_u_328] = v_u_335
				local v336 = p_u_58.ground(p_u_329, 0)
				v_u_5.flash(p_u_58.ground(p_u_329, 3), v_u_11, 11 * v_u_331, 0.15)
				v_u_49(p_u_58.ground(p_u_329, 1), v_u_7.TideSplash, v_u_10, 12 * v_u_331, v_u_333 and 2 or 4, 0.5, 6, 2)
				v_u_5.ring(v336, v_u_11, v_u_332 * 1.15, 0.4, v_u_7.Shockwave)
				local v337 = p_u_58.burst
				local v338 = v336 + Vector3.new(0, 0.3, 0)
				local v339 = v_u_8
				local v340 = v_u_332 / 16
				v337("Shockwave", v338, v339, (math.min(v340, 1.4)))
				if p_u_328.mine then
					v_u_5.shake(0.3, 0.3)
				end
				local v_u_341 = p_u_58.plate(v336, 1, v_u_9, 0.22, Enum.Material.SmoothPlastic)
				v_u_341.Reflectance = 0.15
				local v_u_342 = p_u_58.plate(v336, 1, v_u_8, 0.62)
				v_u_1:AddItem(v_u_341, v334)
				v_u_1:AddItem(v_u_342, v334)
				local v343 = v336.X
				local v344 = p_u_58.FLOOR
				local v345 = v336.Z
				local v_u_346 = Vector3.new(v343, v344, v345)
				local v_u_347 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_346), v_u_13, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_347, v334)
				local v_u_348 = v_u_194(v_u_347, v_u_333 and 3 or 6)
				local v349 = v_u_5.part
				local v350 = v_u_332 * 1.5
				local v351 = v_u_332 * 1.5
				local v_u_352 = v349(Vector3.new(v350, 0.2, v351), CFrame.new(v_u_346), v_u_13, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_352, v334)
				local v_u_353 = v_u_57(v_u_352, v_u_333 and 6 or 16, 1, 5, 1.1)
				local v_u_354 = os.clock()
				local v_u_355 = v_u_354
				local v_u_356 = 0
				local v_u_357 = nil
				p_u_58.runNow(function()
					-- upvalues: (copy) v_u_354, (ref) v_u_355, (ref) v_u_356, (ref) v_u_357, (copy) v_u_332, (copy) v_u_341, (copy) v_u_346, (copy) v_u_342, (copy) v_u_347, (ref) v_u_223, (copy) v_u_348, (copy) v_u_331, (copy) v_u_352, (copy) p_u_330, (copy) v_u_335, (ref) p_u_58, (copy) p_u_329, (ref) v_u_10, (ref) v_u_13
					local v358 = os.clock()
					local v359 = v358 - v_u_354
					local v360 = v358 - v_u_355
					local v361 = math.min(v360, 0.05)
					v_u_355 = v358
					v_u_356 = v_u_356 + v361 * 1.1
					local v362 = v359 / 0.35
					local v363 = 1 - (1 - math.clamp(v362, 0, 1)) ^ 2
					local v364
					if v_u_357 then
						local v365 = (v358 - v_u_357) / 0.12
						v364 = math.clamp(v365, 0, 1)
					else
						v364 = 0
					end
					local v366 = v_u_332 * v363 * (1 - v364 * 0.85)
					local v367 = math.max(v366, 0.5)
					local v368 = v363 * 1.2 * (1 - v364) + 0.1
					local v369 = v_u_341
					local v370 = v368 * 2
					local v371 = v367 * 2
					local v372 = v367 * 2
					v369.Size = Vector3.new(v370, v371, v372)
					v_u_341.CFrame = CFrame.new(v_u_346) * CFrame.Angles(0, 0, 1.5707963267948966)
					local v373 = v_u_342
					local v374 = v367 * 2.02
					local v375 = v367 * 2.02
					v373.Size = Vector3.new(0.12, v374, v375)
					v_u_342.CFrame = CFrame.new(v_u_346 + Vector3.new(0, 1, 0) * (v368 + 0.04)) * CFrame.Angles(0, 0, 1.5707963267948966)
					local v376 = v_u_342
					local v377 = v359 * 6
					v376.Transparency = math.sin(v377) * 0.1 + 0.62
					v_u_347.CFrame = CFrame.new(v_u_346) * CFrame.Angles(0, -v_u_356, 0)
					v_u_223(v_u_348, v367, v368 + 0.1, 3.2 * v_u_331)
					v_u_352.CFrame = CFrame.new(v_u_346 + Vector3.new(0, 1, 0) * v368)
					local v378 = p_u_330
					local v379 = v359 / math.max(v378, 0.1)
					local v380 = math.clamp(v379, 0, 1)
					if not v_u_357 then
						local v381 = v_u_335
						local v382 = CFrame.new(p_u_58.ground(p_u_329, (4 - v380 * 5) * v_u_331))
						local v383 = CFrame.Angles
						local v384 = v359 * 1.6
						local v385 = v359 * 2
						local v386 = v382 * v383(0, v384, math.sin(v385) * 0.05)
						local v387 = v359 * 8
						local v388 = math.sin(v387) * 0.3 + 0.3
						if not v381.gone then
							v381.core.CFrame = v386
							v381.sheath.CFrame = v386
							v381.seam.CFrame = v386
							v381.seam.Color = v_u_10:Lerp(v_u_13, (math.clamp(v388, 0, 1)))
						end
					end
					if v364 < 1 then
						return v359 < p_u_330 + 2
					end
					v_u_341:Destroy()
					v_u_342:Destroy()
					v_u_347:Destroy()
					v_u_352:Destroy()
					return false
				end)
				local v_u_389 = true
				local v_u_390 = p_u_328.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (ref) v_u_389, (copy) v_u_354, (copy) p_u_330, (copy) v_u_346, (copy) v_u_332, (ref) v_u_11, (copy) v_u_390, (ref) v_u_76, (ref) v_u_7, (copy) v_u_333, (ref) p_u_58, (copy) p_u_329
					while v_u_389 and os.clock() - v_u_354 < p_u_330 + 0.5 do
						local v391 = v_u_346 + Vector3.new(0, 1.45, 0)
						local v392 = v_u_332 * 1.05
						local v393 = v_u_332 * 0.15
						local v394 = v_u_11
						local v395 = v_u_390 * 0.9
						v_u_76(CFrame.new(v391), v392, v393, v_u_7.Ring, v394, v395, 1.5, 0.25)
						if not v_u_333 then
							p_u_58.inward(p_u_58.ground(p_u_329, 1.5), v_u_11, 4, v_u_332 * 1.1, 0.3)
						end
						task.wait(v_u_390)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_389, (copy) v_u_353, (ref) v_u_357, (copy) p_u_328, (copy) v_u_335
					v_u_389 = false
					v_u_353.Enabled = false
					v_u_357 = os.clock()
					if not p_u_328.ability.finalPower then
						local v396 = v_u_335
						if v396.gone then
							return
						end
						v396.gone = true
						v396.core:Destroy()
						v396.sheath:Destroy()
						v396.seam:Destroy()
					end
				end
			end,
			["finish"] = function(p397, p398) -- name: finish
				-- upvalues: (copy) v_u_176, (copy) v_u_280
				local v399 = v_u_176[p397]
				v_u_176[p397] = nil
				v_u_280(p397, p398, v399)
			end,
			["hit"] = function(p400, p401, _) -- name: hit
				-- upvalues: (copy) p_u_58, (ref) v_u_11, (copy) v_u_76, (ref) v_u_7, (ref) v_u_8
				local v402 = p401.X
				local v403 = p_u_58.FLOOR + 1.45
				local v404 = p401.Z
				local v405 = Vector3.new(v402, v403, v404)
				local v406 = v_u_11
				v_u_76(CFrame.new(v405), 2.4, 0.4, v_u_7.Ring, v406, 0.3, 1.5, 0.15)
				if not p400.lite then
					p_u_58.burst("Impact", p401, v_u_8, 0.5)
				end
			end
		}
	}
	return v407
end