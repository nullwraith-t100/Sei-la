local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = require(script.Parent.Device)
local v_u_6 = require(script.Parent.Gamepad)
local v_u_7 = require(script.Parent.Menus)
local v_u_8 = require(script.Parent.OfferLog)
local v_u_9 = require(script.Parent.State)
local v_u_10 = require(script.Parent.Store)
local v_u_11 = require(script.Parent.Tutorial)
local v12 = v3.Shared
local v_u_13 = require(v12.Config.Images)
local v_u_14 = require(v12.Config.Release)
local v_u_15 = require(v12.Logic.Format)
local v_u_16 = require(v12.Logic.StageGate)
local v_u_17 = require(v12.Logic.TrophyOffer)
local v18 = {}
local v_u_19 = v2.LocalPlayer
local v_u_20 = Color3.fromRGB(255, 214, 64)
local v_u_21 = Color3.fromRGB(255, 136, 26)
local v_u_22 = {
	["winsPad"] = {
		["a"] = Color3.fromRGB(205, 125, 255),
		["b"] = Color3.fromRGB(118, 48, 230),
		["icon"] = v_u_13.Icon.Trophy
	},
	["vip"] = {
		["a"] = Color3.fromRGB(255, 226, 60),
		["b"] = Color3.fromRGB(255, 150, 0),
		["icon"] = v_u_13.Aura.vip_aura
	},
	["autoWin"] = {
		["a"] = Color3.fromRGB(255, 112, 112),
		["b"] = Color3.fromRGB(205, 32, 64),
		["icon"] = v_u_13.Icon.Trophy
	},
	["boostWins"] = {
		["a"] = Color3.fromRGB(125, 240, 95),
		["b"] = Color3.fromRGB(30, 168, 70),
		["icon"] = v_u_13.Icon.BoostWins
	}
}
local v_u_23 = v_u_17.memory()
local v_u_24 = nil
local v_u_25 = nil
local v_u_26 = nil
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = false
local function v_u_36(p31) -- name: fresh
	for _, v32 in p31:GetDescendants() do
		local v33 = v32.Parent
		local v34
		if v32.Name == "Shine" and v33 ~= nil then
			v34 = v33:GetAttribute("Ui-Effect") == "Shine"
		else
			v34 = false
		end
		if v34 or (v32.Name == "PadHint" or (v32.Name == "Gloss" or (v32.Name == "TitlePaint" or v32.Name == "Beat"))) then
			v32:Destroy()
		elseif v32:IsA("ImageLabel") then
			local v35 = v32:GetAttribute("Ui-Effect")
			if v35 ~= "Bg_X" and v35 ~= "Bg_Y" then
				continue
			end
			v32.Position = UDim2.fromScale(v32.Position.X.Scale, v32.Position.Y.Scale)
			v32.Size = UDim2.fromScale(v32.Size.X.Scale, v32.Size.Y.Scale)
		else
			if not v32:IsA("UIScale") or v32.Name ~= "Pop" then
				continue
			end
			v32.Scale = 1
		end
	end
end
local function v_u_42(p37, p38, p39, p40, p41) -- name: place
	if p37 and p37:IsA("GuiObject") then
		p37.AnchorPoint = Vector2.new(0.5, 0.5)
		p37.Position = UDim2.fromScale(p38, p39)
		p37.Size = UDim2.fromScale(p40, p41)
	end
end
local function v_u_54() -- name: makeTemplate
	-- upvalues: (ref) v_u_24, (copy) v_u_19, (copy) v_u_36, (copy) v_u_42
	local v43
	if v_u_24 and v_u_24.Parent then
		v43 = v_u_24
	else
		local v44 = v_u_19:FindFirstChildOfClass("PlayerGui")
		if v44 then
			v44 = v44:FindFirstChild("Main")
		end
		if v44 then
			v44 = v44:FindFirstChild("Frames")
		end
		v_u_24 = v44
		v43 = v_u_24
	end
	if v43 then
		v43 = v43:FindFirstChild("Store")
	end
	if v43 then
		v43 = v43:FindFirstChild("Holder", true)
	end
	if v43 then
		v43 = v43:FindFirstChild("Pass_winsPad")
	end
	if not v43 then
		if v_u_24 and v_u_24.Parent then
			v43 = v_u_24
		else
			local v45 = v_u_19:FindFirstChildOfClass("PlayerGui")
			if v45 then
				v45 = v45:FindFirstChild("Main")
			end
			if v45 then
				v45 = v45:FindFirstChild("Frames")
			end
			v_u_24 = v45
			v43 = v_u_24
		end
		if v43 then
			v43 = v43:FindFirstChild("Store")
		end
		if v43 then
			v43 = v43:FindFirstChild("Holder", true)
		end
		if v43 then
			v43 = v43:FindFirstChild("Pass_autoRebirth")
		end
	end
	if not (v43 and v43:IsA("GuiObject")) then
		return nil
	end
	local v46 = v43:Clone()
	v_u_36(v46)
	for _, v47 in v46:GetChildren() do
		if v47.Name ~= "Owned" and (v47.Name ~= "GiftButton" and v47.Name ~= "Gift") then
			continue
		end
		v47:Destroy()
	end
	local v48 = v46:FindFirstChild("Purchase")
	if not v48 then
		return nil
	end
	for _, v49 in { "Ui-Pass", "Ui-Pack", "Ui-Product" } do
		v48:SetAttribute(v49, nil)
	end
	v48:SetAttribute("Pad", true)
	if v48:IsA("GuiObject") then
		v48.Visible = true
	end
	local v50 = v48:FindFirstChild("PriceTag")
	if v50 then
		for _, v51 in { "Ui-Pass-Robux", "Ui-Product-Robux", "Ui-Pack-Robux" } do
			v50:SetAttribute(v51, nil)
		end
	end
	v_u_42(v48, 0.5, 0.875, 0.72, 0.15)
	v_u_42(v46:FindFirstChild("Icon"), 0.5, 0.385, 0.46, 0.32)
	v_u_42(v46:FindFirstChild("Sunburst"), 0.5, 0.385, 0.76, 0.5)
	local v52 = v46:FindFirstChild("Title")
	if v52 and v52:IsA("TextLabel") then
		v_u_42(v52, 0.5, 0.11, 0.92, 0.14)
		local v53 = v52:Clone()
		v53.Name = "Line"
		v53.TextWrapped = true
		v53.TextScaled = true
		v53.TextColor3 = Color3.fromRGB(255, 255, 255)
		v53.ZIndex = v52.ZIndex
		v53.Parent = v46
		v_u_42(v53, 0.5, 0.675, 0.92, 0.21)
	end
	v46.Name = "Card"
	v46.LayoutOrder = 0
	v46.Size = UDim2.fromScale(0.235, 1)
	v46.Visible = true
	return v46
end
local function v_u_70() -- name: build
	-- upvalues: (ref) v_u_25, (ref) v_u_24, (copy) v_u_19, (ref) v_u_26, (copy) v_u_54, (copy) v_u_36, (copy) v_u_13, (copy) v_u_20, (copy) v_u_21, (copy) v_u_6, (copy) v_u_42, (ref) v_u_28, (ref) v_u_27
	if v_u_25 and v_u_25.Parent then
		return v_u_25
	end
	local v55
	if v_u_24 and v_u_24.Parent then
		v55 = v_u_24
	else
		local v56 = v_u_19:FindFirstChildOfClass("PlayerGui")
		if v56 then
			v56 = v56:FindFirstChild("Main")
		end
		if v56 then
			v56 = v56:FindFirstChild("Frames")
		end
		v_u_24 = v56
		v55 = v_u_24
	end
	local v57
	if v55 then
		v57 = v55:FindFirstChild("Offline")
	else
		v57 = v55
	end
	v_u_26 = v_u_54()
	if not (v55 and (v57 and (v57:IsA("Frame") and v_u_26))) then
		return nil
	end
	local v58 = v57:Clone()
	v58.Name = "TrophyOffer"
	v58.Visible = false
	local v59 = v58:FindFirstChild("MainDescription")
	for _, v60 in v58:GetChildren() do
		if v60.Name == "Top" or v60 == v59 or v60:IsA("UIStroke") or (v60:IsA("UIAspectRatioConstraint") or v60:IsA("UICorner")) then
			continue
		end
		v60:Destroy()
	end
	v_u_36(v58)
	local v61 = v58:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v61 then
		v61.AspectRatio = 2.1
	end
	local v62 = v58:FindFirstChild("Top")
	if v62 and v62:IsA("GuiObject") then
		v62.Size = UDim2.fromScale(1, 0.17)
		v62.Position = UDim2.fromScale(0.5, 0.085)
		for _, v63 in v62:GetChildren() do
			if v63:IsA("TextLabel") then
				v63.Text = "More Trophies"
			else
				if not v63:IsA("ImageLabel") or v63.Name ~= "Icon" then
					continue
				end
				v63.Image = v_u_13.Icon.Trophy
			end
		end
		local v64 = v_u_20
		local v65 = v_u_21
		local v66 = v62:FindFirstChildOfClass("UIGradient")
		if v66 then
			v66.Color = ColorSequence.new(v64, v65)
		end
		local v67 = v62:FindFirstChild("Close")
		if v67 and v67:IsA("GuiObject") then
			v_u_6.hint(v67, Enum.KeyCode.ButtonB, 26)
		end
	end
	if v59 and v59:IsA("TextLabel") then
		v_u_42(v59, 0.5, 0.245, 0.92, 0.09)
		v59.TextScaled = true
		v_u_28 = v59
	end
	local v68 = Instance.new("Frame")
	v68.Name = "Row"
	v68.BackgroundTransparency = 1
	v_u_42(v68, 0.5, 0.62, 0.96, 0.66)
	local v69 = Instance.new("UIListLayout")
	v69.FillDirection = Enum.FillDirection.Horizontal
	v69.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v69.VerticalAlignment = Enum.VerticalAlignment.Center
	v69.SortOrder = Enum.SortOrder.LayoutOrder
	v69.Padding = UDim.new(0.012, 0)
	v69.Parent = v68
	v68.Parent = v58
	v_u_27 = v68
	v58.Parent = v55
	v_u_6.root(v58)
	v_u_25 = v58
	return v58
end
local function v_u_80() -- name: soldNow
	-- upvalues: (copy) v_u_17, (copy) v_u_10, (copy) v_u_14
	local v71 = {}
	for _, v72 in v_u_17.ITEMS do
		if v72.kind == "pass" then
			local v73 = v_u_10.pass(v72.key)
			local v74 = v72.key ~= "vip" and v72.key ~= "autoWin" and true or v_u_14.on(v_u_14.PERKS)
			local v75 = v72.key
			if v73 == nil or v73.id == 0 then
				v74 = false
			else
				local v76 = not v73.retired
				if not v76 then
					v74 = v76
				end
			end
			v71[v75] = v74
		else
			local v77 = v_u_10.product(v72.key)
			local v78 = v72.key
			local v79
			if v77 == nil then
				v79 = false
			else
				v79 = v77.id ~= 0
			end
			v71[v78] = v79
		end
	end
	return v71
end
local function v_u_83() -- name: ownedNow
	-- upvalues: (copy) v_u_17, (copy) v_u_19
	local v81 = {}
	for _, v82 in v_u_17.ITEMS do
		v81[v82.key] = v_u_19:GetAttribute("Pass_" .. v82.key) == true
	end
	return v81
end
local function v_u_121() -- name: fill
	-- upvalues: (ref) v_u_27, (ref) v_u_26, (ref) v_u_25, (copy) v_u_5, (copy) v_u_9, (copy) v_u_17, (copy) v_u_80, (copy) v_u_83, (copy) v_u_22, (ref) v_u_24, (copy) v_u_19, (copy) v_u_10, (copy) v_u_8, (ref) v_u_29, (ref) v_u_28, (copy) v_u_15
	local v84 = v_u_27
	local v85 = v_u_26
	if v84 and v85 then
		local v86 = v_u_25
		if v86 then
			local v87 = v_u_5.touch()
			local v88
			if v87 then
				v88 = UDim2.fromScale(0.94, 0.84)
			else
				v88 = UDim2.fromScale(0.62, 0.62)
			end
			v86.Size = v88
			local v89 = "Home"
			local v90
			if v87 then
				v90 = UDim2.fromScale(0.5, 0.57)
			else
				v90 = UDim2.fromScale(0.5, 0.5)
			end
			v86:SetAttribute(v89, v90)
		end
		for _, v91 in v84:GetChildren() do
			if not v91:IsA("GuiObject") then
				continue
			end
			v91:Destroy()
		end
		local v92 = v_u_9.number("World", 1)
		local v93 = v_u_9.number(v92 == 1 and "BestStage" or "BestStage" .. tostring(v92))
		local v94, v95 = v_u_17.autoWin(v92, v93, v_u_9.number("Chakra"))
		for v96, v97 in v_u_17.pick(v_u_80(), (v_u_83())) do
			local v98 = v85:Clone()
			v98.Name = "Offer_" .. v97.key
			v98.LayoutOrder = v96
			local v99 = v_u_22[v97.key]
			local v100 = (v97.kind == "pass" and "Pass_" or "Product_") .. v97.key
			local v101
			if v_u_24 and v_u_24.Parent then
				v101 = v_u_24
			else
				local v102 = v_u_19:FindFirstChildOfClass("PlayerGui")
				if v102 then
					v102 = v102:FindFirstChild("Main")
				end
				if v102 then
					v102 = v102:FindFirstChild("Frames")
				end
				v_u_24 = v102
				v101 = v_u_24
			end
			if v101 then
				v101 = v101:FindFirstChild("Store")
			end
			if v101 then
				v101 = v101:FindFirstChild("Holder", true)
			end
			if v101 then
				v101 = v101:FindFirstChild(v100)
			end
			local v103
			if v101 then
				v103 = v101:FindFirstChild("Icon")
			else
				v103 = v101
			end
			local v104 = v98:FindFirstChild("Icon")
			if v104 and v104:IsA("ImageLabel") then
				local v105
				if v103 and v103:IsA("ImageLabel") then
					v105 = v103.Image
				else
					v105 = v99 and v99.icon or v104.Image
				end
				v104.Image = v105
			end
			if v101 then
				v101 = v101:FindFirstChildOfClass("UIGradient")
			end
			local v106 = v98:FindFirstChildOfClass("UIGradient")
			if v106 and v101 then
				v106.Color = v101.Color
			elseif v106 and v99 then
				v106.Color = ColorSequence.new(v99.a, v99.b)
			end
			local v107
			if v97.kind == "pass" then
				local v108 = v_u_10.pass(v97.key)
				if v108 then
					v107 = v108.name
				else
					v107 = v97.key
				end
			else
				local v109 = v_u_10.product(v97.key)
				if v109 then
					v107 = v109.name
				else
					v107 = v97.key
				end
			end
			local v110 = v98:FindFirstChild("Title")
			if v110 and v110:IsA("TextLabel") then
				v110.Text = v107
			end
			local v111 = v_u_17.line(v97.key, v94, v95)
			local v112 = v98:FindFirstChild("Line")
			if v112 and v112:IsA("TextLabel") then
				v112.Text = v111
			end
			local v113 = v98:FindFirstChild("Purchase")
			local v114
			if v97.kind == "pass" then
				v114 = v_u_10.pass(v97.key)
				if v114 then
					v114 = v114.price
				end
			else
				v114 = v_u_10.product(v97.key)
				if v114 then
					v114 = v114.price
				end
			end
			if v113 then
				local v115 = not v114 and "?" or v_u_10.priceText(v114)
				local v116 = v113:FindFirstChild("PriceTag")
				if v116 and v116:IsA("TextLabel") then
					v116.Text = v115
				end
				if v113:IsA("GuiButton") then
					local v_u_117 = v97.key
					local v_u_118 = v97.kind
					v113.Activated:Connect(function()
						-- upvalues: (copy) v_u_118, (ref) v_u_10, (copy) v_u_117
						if v_u_118 == "pass" then
							v_u_10.buyPass(v_u_117, "TrophyNudge", "Barrier")
						else
							v_u_10.buyProduct(v_u_117, "TrophyNudge", "Barrier")
						end
					end)
				end
			end
			v98.Parent = v84
			v_u_8.shown("TrophyNudge", v97.kind, v97.key, "Barrier")
		end
		local v119 = v_u_29
		local v120 = v_u_28
		if v119 and v120 then
			v120.Text = ("Stage %* needs %* Trophies. Get them faster:"):format(v119.stage, (v_u_15.short(v119.need)))
		end
	end
end
local function v_u_132() -- name: calm
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_1, (copy) v_u_19, (copy) v_u_7, (ref) v_u_24
	if not v_u_11.known() or v_u_10.quiet() then
		return false
	end
	if v_u_1.MenuIsOpen or (v_u_19:GetAttribute("InStages") == true or (v_u_19:GetAttribute("InWave") == true or v_u_19:GetAttribute("Downed") == true)) then
		return false
	end
	local v122 = v_u_19.Character
	if v122 then
		v122 = v122:FindFirstChild("HumanoidRootPart")
	end
	if not v122 or (not v122:IsA("BasePart") or v122.Position.X < -1500) then
		return false
	end
	if v_u_10.sincePrompt() < 4 or v_u_7.current() ~= nil then
		return false
	end
	local v123
	if v_u_24 and v_u_24.Parent then
		v123 = v_u_24
	else
		local v124 = v_u_19:FindFirstChildOfClass("PlayerGui")
		if v124 then
			v124 = v124:FindFirstChild("Main")
		end
		if v124 then
			v124 = v124:FindFirstChild("Frames")
		end
		v_u_24 = v124
		v123 = v_u_24
	end
	if not v123 then
		return false
	end
	for _, v125 in v123:GetChildren() do
		if not (v125:IsA("GuiObject") and v125.Visible) then
			continue
		end
		return false
	end
	local v126 = v123.Parent
	if not v126 then
		return false
	end
	local v127 = v126:FindFirstChild("HUD")
	if v127 then
		v127 = v127:FindFirstChild("Overlay")
	end
	if v127 then
		v127 = v127:FindFirstChild("Hatch")
	end
	if v127 and (v127:IsA("GuiObject") and v127.Visible) then
		return false
	end
	if v126:FindFirstChild("GiftPopUp") then
		return false
	end
	local v128 = v126:FindFirstChild("GiftPicker")
	if v128 and (v128:IsA("GuiObject") and v128.Visible) then
		return false
	end
	local v129 = v_u_19:FindFirstChildOfClass("PlayerGui")
	for _, v130 in { "Odds", "Revive", "Arcade" } do
		local v131
		if v129 then
			v131 = v129:FindFirstChild(v130)
		else
			v131 = v129
		end
		if not (v131 and (v131:IsA("ScreenGui") and v131.Enabled)) then
			continue
		end
		return false
	end
	return true
end
function v18.arrived(p133, p134) -- name: arrived
	-- upvalues: (copy) v_u_9, (copy) v_u_17, (ref) v_u_23, (copy) v_u_10, (ref) v_u_29, (ref) v_u_30, (copy) v_u_16, (copy) v_u_80, (copy) v_u_83, (copy) v_u_132, (copy) v_u_70, (copy) v_u_121, (copy) v_u_7
	local v135 = v_u_9.number("RunWorld", v_u_9.number("World", 1))
	if v_u_17.arrive(v_u_23, os.clock(), v135, p133) and (not v_u_10.quiet() and v_u_17.due(v_u_23, os.clock())) then
		v_u_29 = {
			["world"] = nil,
			["stage"] = nil,
			["need"] = nil,
			["dev"] = false,
			["world"] = v135,
			["stage"] = p133,
			["need"] = p134
		}
		if not v_u_30 then
			v_u_30 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_17, (ref) v_u_29, (ref) v_u_9, (ref) v_u_16, (ref) v_u_80, (ref) v_u_83, (ref) v_u_132, (ref) v_u_70, (ref) v_u_121, (ref) v_u_23, (ref) v_u_7, (ref) v_u_30
				local v136 = os.clock()
				while true do
					local v137 = os.clock() - v136 < v_u_17.WAIT_UP_TO and v_u_29
					if not v137 then
						break
					end
					local v138
					if v137.dev then
						v138 = true
					else
						local v139 = v_u_9.number
						local v140
						if v137.world == 1 then
							v140 = "BestStage"
						else
							local v141 = v137.world
							v140 = "BestStage" .. tostring(v141)
						end
						local v142 = v139(v140)
						v138 = v_u_16.need(v137.world, v137.stage, v142, v_u_9.number("TotalWins")) ~= nil
					end
					if not v138 or #v_u_17.pick(v_u_80(), (v_u_83())) == 0 then
						break
					end
					if v_u_132() then
						task.wait(1.5)
						if v_u_70() and (v_u_132() and #v_u_17.pick(v_u_80(), (v_u_83())) > 0) then
							v_u_121()
							v_u_17.shown(v_u_23, os.clock())
							v_u_7.open("TrophyOffer")
						end
						break
					end
					task.wait(0.5)
				end
				v_u_30 = false
			end)
		end
	else
		return
	end
end
v_u_19.AttributeChanged:Connect(function(p143)
	-- upvalues: (copy) v_u_7, (copy) v_u_17, (copy) v_u_80, (copy) v_u_83, (copy) v_u_121
	if string.sub(p143, 1, 5) == "Pass_" and v_u_7.current() == "TrophyOffer" then
		if #v_u_17.pick(v_u_80(), (v_u_83())) == 0 then
			v_u_7.close()
		else
			v_u_121()
		end
	else
		return
	end
end)
v_u_10.pricesChanged:Connect(function()
	-- upvalues: (copy) v_u_7, (copy) v_u_121
	if v_u_7.current() == "TrophyOffer" then
		v_u_121()
	end
end)
if v4:IsStudio() then
	v_u_19:GetAttributeChangedSignal("DevTrophyOffer"):Connect(function()
		-- upvalues: (copy) v_u_19, (copy) v_u_9, (ref) v_u_23, (copy) v_u_17, (ref) v_u_29, (ref) v_u_30, (copy) v_u_16, (copy) v_u_80, (copy) v_u_83, (copy) v_u_132, (copy) v_u_70, (copy) v_u_121, (copy) v_u_7
		if v_u_19:GetAttribute("DevTrophyOffer") == true then
			v_u_19:SetAttribute("DevTrophyOffer", nil)
			local v144 = v_u_9.number("World", 1)
			v_u_23 = v_u_17.memory()
			v_u_29 = {
				["world"] = nil,
				["stage"] = 5,
				["need"] = 1200000000000,
				["dev"] = true,
				["world"] = v144
			}
			if not v_u_30 then
				v_u_30 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_17, (ref) v_u_29, (ref) v_u_9, (ref) v_u_16, (ref) v_u_80, (ref) v_u_83, (ref) v_u_132, (ref) v_u_70, (ref) v_u_121, (ref) v_u_23, (ref) v_u_7, (ref) v_u_30
					local v145 = os.clock()
					while true do
						local v146 = os.clock() - v145 < v_u_17.WAIT_UP_TO and v_u_29
						if not v146 then
							break
						end
						local v147
						if v146.dev then
							v147 = true
						else
							local v148 = v_u_9.number
							local v149
							if v146.world == 1 then
								v149 = "BestStage"
							else
								local v150 = v146.world
								v149 = "BestStage" .. tostring(v150)
							end
							local v151 = v148(v149)
							v147 = v_u_16.need(v146.world, v146.stage, v151, v_u_9.number("TotalWins")) ~= nil
						end
						if not v147 or #v_u_17.pick(v_u_80(), (v_u_83())) == 0 then
							break
						end
						if v_u_132() then
							task.wait(1.5)
							if v_u_70() and (v_u_132() and #v_u_17.pick(v_u_80(), (v_u_83())) > 0) then
								v_u_121()
								v_u_17.shown(v_u_23, os.clock())
								v_u_7.open("TrophyOffer")
							end
							break
						end
						task.wait(0.5)
					end
					v_u_30 = false
				end)
			end
		else
			return
		end
	end)
end
return v18