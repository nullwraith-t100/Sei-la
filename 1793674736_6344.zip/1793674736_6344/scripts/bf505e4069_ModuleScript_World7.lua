local v1 = {
	["sand_hollow"] = {
		["shirt"] = 135788107490205,
		["pants"] = 114117285125178,
		["accessories"] = nil,
		["skin"] = "#EDE8DC",
		["accessories"] = { 14215926459, 78632821028296, 107133185728718 }
	},
	["lizard_hollow"] = {
		["shirt"] = 8390016825,
		["pants"] = 8390052639,
		["accessories"] = nil,
		["skin"] = "#E8E2D2",
		["accessories"] = { 74286183376672, 6902174721, 137618379727764 }
	},
	["quartz_crawler"] = {
		["shirt"] = 11526405286,
		["pants"] = 11526410212,
		["accessories"] = nil,
		["skin"] = "#EEF4F6",
		["accessories"] = { 128913823019563, 17457839288, 136309350499812 }
	},
	["adjuchas_scout"] = {
		["shirt"] = 1079374993,
		["pants"] = 8916442711,
		["accessories"] = nil,
		["skin"] = "#E8E0CE",
		["accessories"] = { 79008830132155, 94115514643861, 6441410582 }
	},
	["gillian_brute"] = {
		["shirt"] = 689327477,
		["pants"] = 1345650970,
		["accessories"] = nil,
		["skin"] = "#1E1E22",
		["accessories"] = { 110899437996109, 94560165162753, 109400776087177 }
	},
	["menos_drifter"] = {
		["shirt"] = 3811928068,
		["pants"] = 116983632814765,
		["accessories"] = nil,
		["skin"] = "#26262C",
		["accessories"] = { 71800154922077, 126432063474845 }
	},
	["adjuchas_alpha"] = {
		["shirt"] = 8347136068,
		["pants"] = 8347137972,
		["accessories"] = nil,
		["skin"] = "#F2EEE4",
		["accessories"] = {
			121938034167060,
			134199739413087,
			105007888103203,
			18867315821
		}
	},
	["grave_hollow"] = {
		["shirt"] = 7797157599,
		["pants"] = 13188519270,
		["accessories"] = nil,
		["skin"] = "#D8D0BC",
		["accessories"] = { 128627527626868, 80473811522319, 5509973293 }
	},
	["bone_picker"] = {
		["shirt"] = 5822831677,
		["pants"] = 123134380581956,
		["accessories"] = nil,
		["skin"] = "#2A2A30",
		["accessories"] = { 136564429550811, 103565924063094 }
	},
	["garganta_walker"] = {
		["shirt"] = 14533258101,
		["pants"] = 14310264334,
		["accessories"] = nil,
		["skin"] = "#E6C2A0",
		["accessories"] = { 12458808005, 87758846533866, 137276260826792 }
	},
	["rift_hollow"] = {
		["shirt"] = 80043300069915,
		["pants"] = 16029310246,
		["accessories"] = nil,
		["skin"] = "#EDE8DC",
		["accessories"] = { 8716091990, 120022553999326 }
	},
	["numeros_guard"] = {
		["shirt"] = 14793335398,
		["pants"] = 14617969151,
		["accessories"] = nil,
		["skin"] = "#E2B894",
		["accessories"] = { 17570655717, 10714333589 }
	},
	["gate_arrancar"] = {
		["shirt"] = 14310281747,
		["pants"] = 14310266376,
		["accessories"] = nil,
		["skin"] = "#C8946A",
		["accessories"] = { 137164374955619, 138060708210374 }
	},
	["gate_numeros"] = {
		["shirt"] = 14793332541,
		["pants"] = 14617977750,
		["accessories"] = nil,
		["skin"] = "#B88058",
		["accessories"] = {
			12266877860,
			13832918624,
			106508668192569,
			13871994041
		}
	},
	["corridor_sentry"] = {
		["shirt"] = 14617948649,
		["pants"] = 14310263614,
		["accessories"] = nil,
		["skin"] = "#EAC8A8",
		["accessories"] = { 110528607237517, 91936108970387 }
	},
	["sonido_runner"] = {
		["shirt"] = 10881616955,
		["pants"] = 10881613621,
		["accessories"] = nil,
		["skin"] = "#E8C4A0",
		["accessories"] = { 13832937839, 18316839198, 70509889497538 }
	},
	["dome_watcher"] = {
		["shirt"] = 9209170574,
		["pants"] = 88803815728704,
		["accessories"] = nil,
		["skin"] = "#F0EEE8",
		["accessories"] = { 129095761893114, 14695136697 }
	},
	["sky_mimic"] = {
		["shirt"] = 8471350507,
		["pants"] = 5024345253,
		["accessories"] = nil,
		["skin"] = "#BFE0FF",
		["accessories"] = { 139103341537541 }
	},
	["fraccion_brute"] = {
		["shirt"] = 14617946053,
		["pants"] = 14533249414,
		["accessories"] = nil,
		["skin"] = "#B07A52",
		["accessories"] = { 10932888414, 12363369795 }
	},
	["fraccion_lancer"] = {
		["shirt"] = 14793339035,
		["pants"] = 14310264903,
		["accessories"] = nil,
		["skin"] = "#E4BC98",
		["accessories"] = { 16924774689, 10224284313 }
	},
	["fraccion_leader"] = {
		["shirt"] = 433648708,
		["pants"] = 433648682,
		["accessories"] = nil,
		["skin"] = "#E0B890",
		["accessories"] = {
			15208590067,
			13131182466,
			16035335315,
			15474881355
		}
	},
	["lab_experiment"] = {
		["shirt"] = 11156664458,
		["pants"] = 117230138125812,
		["accessories"] = nil,
		["skin"] = "#C8E0B8",
		["accessories"] = { 17771051336, 108948304791878, 80001942408597 }
	},
	["szayel_clone"] = {
		["shirt"] = 14737000314,
		["pants"] = 14310260824,
		["accessories"] = nil,
		["skin"] = "#F0D2B4",
		["accessories"] = { 15748979065, 72546399185880 }
	},
	["privaron_espada"] = {
		["shirt"] = 14533257579,
		["pants"] = 14617970619,
		["accessories"] = nil,
		["skin"] = "#D4A07A",
		["accessories"] = { 79992965966677, 126819918519405 }
	},
	["tower_arrancar"] = {
		["shirt"] = 14793336196,
		["pants"] = 14617968015,
		["accessories"] = nil,
		["skin"] = "#E8C8A8",
		["accessories"] = { 113839447755970, 12785998017, 15310563876 }
	},
	["throne_guard"] = {
		["shirt"] = 10552827164,
		["pants"] = 10552829755,
		["accessories"] = nil,
		["skin"] = "#D8B08C",
		["accessories"] = { 97585897085822, 70854343750355 }
	},
	["espada_lieutenant"] = {
		["shirt"] = 14711754052,
		["pants"] = 14711756031,
		["accessories"] = nil,
		["skin"] = "#ECD4BC",
		["accessories"] = { 132006354178398, 91405345049867 }
	},
	["espada_cuatro"] = {
		["shirt"] = 104723147612921,
		["pants"] = 13923658718,
		["accessories"] = nil,
		["skin"] = "#F2F2EC",
		["accessories"] = { 89262543942392, 119491516109531, 93240171559173 }
	},
	["rooftop_arrancar"] = {
		["shirt"] = 14617944060,
		["pants"] = 14617971249,
		["accessories"] = nil,
		["skin"] = "#DCAE88",
		["accessories"] = { 71920936279966, 15922309844, 15874530429 }
	},
	["black_cero_hollow"] = {
		["shirt"] = 137423301342657,
		["pants"] = 15962675091,
		["accessories"] = nil,
		["skin"] = "#16161A",
		["accessories"] = { 15812614960, 100409968647414, 5778710236 }
	},
	["sternritter_soldier"] = {
		["shirt"] = 14336969065,
		["pants"] = 14336989178,
		["accessories"] = nil,
		["skin"] = "#F2D2B4",
		["accessories"] = { 78421091682761, 100534482825928, 111058530251183 }
	},
	["quincy_trooper"] = {
		["shirt"] = 14336957494,
		["pants"] = 14336983285,
		["accessories"] = nil,
		["skin"] = "#E8C4A0",
		["accessories"] = { 136814684511813, 15301040935, 73245083494835 }
	},
	["royal_sentinel"] = {
		["shirt"] = 14731577728,
		["pants"] = 14731619850,
		["accessories"] = nil,
		["skin"] = "#E0B894",
		["accessories"] = { 92407652553849, 109176431368227, 73019270811537 }
	},
	["sternritter_elite"] = {
		["shirt"] = 91224919883930,
		["pants"] = 4751070057,
		["accessories"] = nil,
		["skin"] = "#F4DCC4",
		["accessories"] = { 81504132720461, 12758151626, 110292494685509 }
	},
	["quincy_emperor"] = {
		["shirt"] = 18237248969,
		["pants"] = 18237251584,
		["accessories"] = nil,
		["skin"] = "#D8A47C",
		["accessories"] = {
			106136116270459,
			133925200162226,
			108684178086287,
			134758895017024
		}
	}
}
return v1