local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF4A1A")
local v_u_9 = Color3.fromHex("FFD24A")
local v_u_10 = Color3.fromRGB(255, 138, 30)
local v_u_11 = Color3.fromRGB(255, 246, 220)
local v_u_12 = Color3.fromRGB(170, 30, 12)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_27(p16, p17, p18, p19, p20) -- name: pic
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_33(p28, p29, p30) -- name: setPic
	local v31 = math.max(p29, 0.03) * 2
	p28.Size = Vector3.new(v31, 0.05, v31)
	if p30 then
		for _, v32 in p28:GetChildren() do
			if not v32:IsA("Decal") then
				continue
			end
			v32.Transparency = p30
		end
	end
end
local function v_u_39(p34, p35, p36) -- name: planeFrame
	local v37 = p35.Unit
	local v38 = p36 - v37 * p36:Dot(v37)
	if v38.Magnitude < 0.001 then
		v38 = v37:Cross(Vector3.new(1, 0, 0))
		if v38.Magnitude < 0.001 then
			v38 = v37:Cross(Vector3.new(0, 0, 1))
		end
	end
	return CFrame.fromMatrix(p34, v38.Unit, v37)
end
local function v_u_48(p40, p41) -- name: blade
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_5, (copy) v_u_1
	local v42 = v_u_3:FindFirstChild("EyePieces")
	if v42 then
		v42 = v42:FindFirstChild("w6_ryujin_jakka")
	end
	local v43
	if v42 and v42:IsA("MeshPart") then
		v43 = v42:Clone()
		local v44 = v42.Size
		local v45 = v42.Size.X
		v43.Size = v44 * (p40 / math.max(v45, 0.01))
	else
		v43 = Instance.new("WedgePart")
		local v46 = p40 * 0.16
		local v47 = p40 * 0.04
		v43.Size = Vector3.new(p40, v46, v47)
		v43.Color = v_u_10
		v43.Material = Enum.Material.Neon
	end
	v43.Anchored = true
	v43.CanCollide = false
	v43.CanQuery = false
	v43.CanTouch = false
	v43.CastShadow = false
	v43.Parent = v_u_5.folder()
	v_u_1:AddItem(v43, p41)
	return v43
end
local function v_u_55(p49, p50, p51) -- name: bladeFrame
	local v52 = p50.Unit
	local v53 = p51 - v52 * p51:Dot(v52)
	if v53.Magnitude < 0.001 then
		v53 = v52:Cross(Vector3.new(1, 0, 0))
	end
	local v54 = v53.Unit
	return CFrame.fromMatrix(p49, v52, v54:Cross(v52)) * CFrame.Angles(0, 0, 0.3839724354387525)
end
local v_u_56 = {
	["texture"] = nil,
	["life"] = 0.6,
	["size"] = 1,
	["speed"] = 5,
	["spread"] = 35,
	["rise"] = 6,
	["glow"] = 0.15,
	["upright"] = true,
	["texture"] = v_u_7.RyujinFlame
}
local v_u_57 = {
	["texture"] = nil,
	["life"] = 0.4,
	["size"] = 1,
	["speed"] = 0,
	["spread"] = 0,
	["rise"] = 0,
	["glow"] = 0.2,
	["upright"] = false,
	["texture"] = v_u_7.RyujinSlash
}
local function v_u_62(p58, p59) -- name: emitterOf
	-- upvalues: (copy) v_u_13
	local v60 = Instance.new("ParticleEmitter")
	v60.Enabled = false
	v60.Texture = p58.texture
	v60.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v60.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v60.Color = ColorSequence.new(v_u_13)
	v60.LightEmission = p58.glow
	v60.LightInfluence = 0
	v60.Lifetime = NumberRange.new(p58.life * 0.8, p58.life * 1.15)
	v60.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p59 * 0.7), NumberSequenceKeypoint.new(0.35, p59), NumberSequenceKeypoint.new(1, p59 * 0.85) })
	v60.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.85, 0), NumberSequenceKeypoint.new(1, 1) })
	v60.Speed = NumberRange.new(p58.speed * 0.6, p58.speed * 1.2)
	v60.SpreadAngle = Vector2.new(p58.spread, p58.spread)
	v60.EmissionDirection = Enum.NormalId.Top
	local v61 = p58.rise
	v60.Acceleration = Vector3.new(0, v61, 0)
	if not p58.upright then
		v60.Rotation = NumberRange.new(0, 360)
		return v60
	end
	v60.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
	v60.Rotation = NumberRange.new(-12, 12)
	return v60
end
local function v_u_69(p63, p64, p65, p66) -- name: sprite
	-- upvalues: (copy) v_u_4, (copy) v_u_62, (copy) v_u_1
	if p65 > 0 then
		local v67 = Instance.new("Attachment")
		v67.WorldPosition = p64
		v67.Parent = v_u_4.Terrain
		local v68 = v_u_62(p63, p66)
		v68.Parent = v67
		v68:Emit(p65)
		v_u_1:AddItem(v67, p63.life * 1.3 + 0.2)
	end
end
local function v_u_78(p70, p71, p72, p73, p74, p_u_75) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_13, (copy) v_u_1
	local v_u_76 = Instance.new("ColorCorrectionEffect")
	v_u_76.Name = "RyujinJakka"
	v_u_76.Parent = v_u_2
	v_u_5.tween(v_u_76, p73, {
		["TintColor"] = p70,
		["Brightness"] = p71,
		["Contrast"] = p72
	})
	task.delay(p73 + p74, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_76, (copy) p_u_75, (ref) v_u_13
		local v77 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_13
		}
		v_u_5.tween(v_u_76, p_u_75, v77)
	end)
	v_u_1:AddItem(v_u_76, p73 + p74 + p_u_75 + 0.1)
end
return function(p_u_79)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_33, (copy) v_u_5, (copy) v_u_10, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_13, (copy) v_u_62, (copy) v_u_56, (copy) v_u_4, (copy) v_u_39, (copy) v_u_15, (copy) v_u_57, (copy) v_u_11, (copy) v_u_6, (copy) v_u_69, (copy) v_u_55, (copy) v_u_12, (copy) v_u_78, (copy) v_u_14, (copy) v_u_48
	local v80 = {}
	local function v_u_91(p81, p_u_82, p_u_83, p84, p85, p86, p87) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_79, (ref) v_u_33
		local v_u_88 = p87 or 0
		local v_u_89 = v_u_27(p81, p_u_82, p84, p85, v_u_88)
		v_u_1:AddItem(v_u_89, p86 + 0.1)
		p_u_79.animate(p86, 0, function(p90)
			-- upvalues: (ref) v_u_33, (copy) v_u_89, (copy) p_u_82, (copy) p_u_83, (copy) v_u_88
			v_u_33(v_u_89, p_u_82 + (p_u_83 - p_u_82) * (1 - (1 - p90) ^ 3), v_u_88 + (1 - v_u_88) * p90 ^ 1.6)
			if p90 >= 1 then
				v_u_89:Destroy()
			end
		end)
	end
	v80.ryujin_jakka_a = {
		["cast"] = function(p92) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_79, (ref) v_u_11, (ref) v_u_57, (ref) v_u_4, (ref) v_u_62, (ref) v_u_1
			local v93 = p92.size
			local v94 = p92.eye + p92.dir * 1.2
			v_u_5.flash(v94, v_u_10, 3.4 * v93, 0.12)
			p_u_79.pop(v94, v_u_11, 1.3 * v93, 0.3 * v93, 0.1)
			if not p92.lite then
				local v95 = v_u_57
				local v96 = 5 * v93
				local v97 = Instance.new("Attachment")
				v97.WorldPosition = v94
				v97.Parent = v_u_4.Terrain
				local v98 = v_u_62(v95, v96)
				v98.Parent = v97
				v98:Emit(1)
				v_u_1:AddItem(v97, v95.life * 1.3 + 0.2)
			end
		end,
		["shot"] = function(p_u_99, p100) -- name: slashShot
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (copy) p_u_79, (ref) v_u_9, (ref) v_u_8, (ref) v_u_27, (ref) v_u_7, (ref) v_u_13, (ref) v_u_62, (ref) v_u_56, (ref) v_u_4, (ref) v_u_39, (ref) v_u_15
			local v_u_101 = p_u_99.size
			local v_u_102 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p100, v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_102, 3)
			p_u_79.streak(v_u_102, v_u_9, v_u_8, 1.5 * v_u_101, p_u_99.lite and 0.1 or 0.2)
			local v_u_103 = v_u_27(p100, 3 * v_u_101, v_u_7.Glow, v_u_10, 0.45)
			local v_u_104 = v_u_27(p100, 2.7 * v_u_101, v_u_7.RyujinCrescent, v_u_13, 0)
			v_u_1:AddItem(v_u_103, 3)
			v_u_1:AddItem(v_u_104, 3)
			local v_u_105
			if p_u_99.lite then
				v_u_105 = nil
			else
				v_u_105 = v_u_62(v_u_56, 1.3 * v_u_101)
				v_u_105.Lifetime = NumberRange.new(0.25, 0.35)
				v_u_105.Rate = 28
				v_u_105.Enabled = true
				v_u_105.Parent = v_u_102
			end
			if p_u_99.mine then
				p_u_79.light(v_u_102, v_u_10, 9 * v_u_101)
			end
			local v_u_106 = false
			return {
				["place"] = function(p107, p108) -- name: place
					-- upvalues: (copy) v_u_102, (ref) v_u_4, (ref) v_u_39, (copy) v_u_104, (ref) v_u_15, (copy) v_u_101, (copy) v_u_103
					v_u_102.CFrame = p107
					local v109 = p107.Position
					local v110 = p107.LookVector
					local v111 = Vector3.new(0, 0.8, 0)
					local v112 = v_u_4.CurrentCamera
					local v113
					if v112 then
						local v114 = v112.CFrame.Position - v109
						v113 = v114.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v114.Unit
					else
						v113 = Vector3.new(0, 0, 1)
					end
					local v115 = v_u_39(v109, (v111 + v113).Unit, v110)
					v_u_104.CFrame = v115 * v_u_15
					local v116 = v_u_104
					local v117 = 3.1 * v_u_101
					local v118 = p108 * 40
					local v119 = v117 * (math.sin(v118) * 0.06 + 1)
					local v120 = math.max(v119, 0.03) * 2
					v116.Size = Vector3.new(v120, 0.05, v120)
					v_u_103.CFrame = v115 * CFrame.new(0, -0.05, 0)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_106, (copy) v_u_104, (copy) v_u_103, (ref) v_u_105, (copy) v_u_102, (ref) v_u_1, (copy) p_u_99
					if not v_u_106 then
						v_u_106 = true
						v_u_104:Destroy()
						v_u_103:Destroy()
						local v121 = v_u_105
						if v121 then
							v121.Enabled = false
						end
						local v122 = v_u_102:FindFirstChildWhichIsA("PointLight")
						if v122 then
							v122:Destroy()
						end
						v_u_1:AddItem(v_u_102, p_u_99.lite and 0.2 or 0.6)
					end
				end
			}
		end,
		["impact"] = function(p123, p124) -- name: flameCross
			-- upvalues: (ref) v_u_4, (copy) v_u_91, (ref) v_u_39, (ref) v_u_15, (ref) v_u_7, (ref) v_u_13, (ref) v_u_57, (ref) v_u_62, (ref) v_u_1, (copy) p_u_79, (ref) v_u_10, (ref) v_u_56, (ref) v_u_9
			local v125 = p123.size
			local v126 = v_u_4.CurrentCamera
			local v127
			if v126 then
				local v128 = v126.CFrame.Position - p124
				v127 = v128.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v128.Unit
			else
				v127 = Vector3.new(0, 0, 1)
			end
			local v129 = v_u_4.CurrentCamera
			local v130 = not v129 and Vector3.new(1, 0, 0) or v129.CFrame.RightVector
			for _, v131 in { 0.75, -0.75 } do
				v_u_91(v_u_39(p124, v127, v130 * math.cos(v131) + Vector3.new(0, 1, 0) * math.sin(v131)) * v_u_15, 1.2 * v125, 3.6 * v125, v_u_7.RyujinCrescent, v_u_13, 0.24, 0)
			end
			local v132 = v_u_57
			local v133 = 7 * v125
			local v134 = Instance.new("Attachment")
			v134.WorldPosition = p124
			v134.Parent = v_u_4.Terrain
			local v135 = v_u_62(v132, v133)
			v135.Parent = v134
			v135:Emit(1)
			v_u_1:AddItem(v134, v132.life * 1.3 + 0.2)
			p_u_79.burst("Impact", p124, v_u_10, 0.8 * v125)
			if not p123.lite then
				local v136 = v_u_56
				local v137 = p124 - Vector3.new(0, 0.5, 0)
				local v138 = 2.4 * v125
				local v139 = Instance.new("Attachment")
				v139.WorldPosition = v137
				v139.Parent = v_u_4.Terrain
				local v140 = v_u_62(v136, v138)
				v140.Parent = v139
				v140:Emit(4)
				v_u_1:AddItem(v139, v136.life * 1.3 + 0.2)
				p_u_79.glint(p124, v_u_9, 3 * v125, 0.14)
			end
			p_u_79.hitSound(p124)
		end,
		["hit"] = p_u_79.simpleHit(v_u_10, 0.55)
	}
	local v_u_141 = {}
	setmetatable(v_u_141, {
		["__mode"] = "k"
	})
	local function v_u_176(p142, p143, p144) -- name: buildCage
		-- upvalues: (copy) p_u_79, (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (ref) v_u_62, (ref) v_u_56, (ref) v_u_4, (ref) v_u_7, (ref) v_u_13
		local v145 = p142.ability.radius
		local v146 = p_u_79.ground(p143, 0)
		local v147 = p142.lite and 6 or 10
		local v148 = p142.lite and 4 or 8
		local v149 = {
			["walls"] = {},
			["bars"] = {},
			["born"] = os.clock()
		}
		local v150 = math.random() * 3.141592653589793 * 2
		for v151 = 1, v147 do
			local v152 = v150 + (v151 - 0.5) * 3.141592653589793 * 2 / v147
			local v153 = math.cos(v152)
			local v154 = math.sin(v152)
			local v155 = Vector3.new(v153, 0, v154)
			local v156 = 2 * v145
			local v157 = 3.141592653589793 / v147
			local v158 = v156 * math.sin(v157)
			local v159 = v_u_5.part(Vector3.new(v158, 0.4, 0.6), CFrame.lookAt(v146 + v155 * v145 + Vector3.new(0, 0.4, 0), v146 + v155 * v145 + Vector3.new(0, 0.4, 0) + v155), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v159, p144 + 1)
			local v160 = v_u_62(v_u_56, 3.4)
			v160.Lifetime = NumberRange.new(0.5, 0.7)
			v160.Speed = NumberRange.new(7, 11)
			v160.SpreadAngle = Vector2.new(6, 6)
			v160.Acceleration = Vector3.new(0, 4, 0)
			v160.Shape = Enum.ParticleEmitterShape.Box
			v160.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v160.Rate = p142.lite and 7 or 13
			v160.Enabled = true
			v160.Parent = v159
			local v161 = v149.walls
			table.insert(v161, v160)
		end
		for v162 = 1, v148 do
			local v163 = v150 + (v162 - 1) * 3.141592653589793 * 2 / v148
			local v164 = math.cos(v163)
			local v165 = math.sin(v163)
			local v166 = Vector3.new(v164, 0, v165)
			local v167 = v146 + v166 * v145
			local v168 = CFrame.fromMatrix(v167, Vector3.new(0, 1, 0), v166)
			local v169 = p144 + 1
			local v170 = Instance.new("Attachment")
			v170.CFrame = v168
			v170.Parent = v_u_4.Terrain
			v_u_1:AddItem(v170, v169)
			local v171 = CFrame.fromMatrix(v146 + Vector3.new(0, 16, 0), -v166, Vector3.new(0, 1, 0))
			local v172 = p144 + 1
			local v173 = Instance.new("Attachment")
			v173.CFrame = v171
			v173.Parent = v_u_4.Terrain
			v_u_1:AddItem(v173, v172)
			local v174 = Instance.new("Beam")
			v174.Attachment0 = v170
			v174.Attachment1 = v173
			v174.Texture = v_u_7.CometFlame
			v174.TextureMode = Enum.TextureMode.Wrap
			v174.TextureLength = 7
			v174.TextureSpeed = 2.2
			v174.Color = ColorSequence.new(v_u_13)
			v174.LightEmission = 0.35
			v174.LightInfluence = 0
			v174.Brightness = 1.4
			v174.FaceCamera = true
			v174.Segments = 16
			v174.Width0 = 0.1
			v174.Width1 = 0.1
			v174.CurveSize0 = 8.8
			v174.CurveSize1 = v145 * 0.7
			v174.Parent = v170
			local v175 = v149.bars
			table.insert(v175, v174)
		end
		return v149
	end
	v80.ryujin_jakka_e = {
		["castSound"] = "Fireball",
		["loopSound"] = "Flames",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["hit"] = nil,
		["cast"] = function(p177) -- name: cast
			-- upvalues: (copy) p_u_79, (ref) v_u_10, (ref) v_u_9
			p_u_79.skillCast(p177, v_u_10)
			if not p177.lite then
				p_u_79.glint(p177.eye, v_u_9, 4 * p177.size, 0.2)
			end
		end,
		["windup"] = function(p178, p179, p180) -- name: windup
			-- upvalues: (copy) p_u_79, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_10
			local v181 = p178.ability.radius
			local v182 = p_u_79.ground(p179)
			v_u_5.ring(v182, v_u_9, v181, math.max(p180, 0.1) + 0.2, v_u_7.Ring)
			p_u_79.burst("Fire", v182, v_u_10, 0.6)
		end,
		["zone"] = function(p_u_183, p184, p185) -- name: zone
			-- upvalues: (copy) p_u_79, (copy) v_u_176, (copy) v_u_141, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_69, (ref) v_u_56
			local v_u_186 = p_u_183.ability.radius
			local v_u_187 = p_u_79.ground(p184)
			local v_u_188 = p185 + 0.6
			local v_u_189 = v_u_176(p_u_183, p184, v_u_188)
			v_u_141[p_u_183] = v_u_189
			v_u_5.disc(v_u_187, v_u_10, v_u_186, p185, v_u_7.Ring, 0.5)
			p_u_79.mark(p184, v_u_8, v_u_186 * 0.95, p185 + 0.3, v_u_7.Glow, 0.5)
			p_u_79.burst("Shockwave", v_u_187 + Vector3.new(0, 0.3, 0), v_u_10, v_u_186 / 16)
			v_u_6.play("Explosion", {
				["at"] = nil,
				["volume"] = 0.45,
				["at"] = v_u_187
			})
			if p_u_183.mine then
				v_u_5.shake(0.22, 0.2)
			end
			local v_u_190 = p_u_183.ability.tick or 0.5
			local v_u_191 = v_u_190
			local v_u_192 = false
			p_u_79.runNow(function()
				-- upvalues: (copy) v_u_189, (ref) v_u_192, (copy) v_u_190, (ref) v_u_191, (copy) p_u_183, (copy) v_u_188
				local v193 = os.clock() - v_u_189.born
				if v_u_192 then
					return false
				end
				local v194 = v193 / 0.35
				local v195 = math.clamp(v194, 0, 1) - 1
				local v196 = v195 * 2.7 * v195 * v195 + 1 + v195 * 1.7 * v195
				local v197 = 1 - v193 % v_u_190 / v_u_190 * 3
				local v198 = math.max(0, v197)
				for v199, v200 in v_u_189.bars do
					local v201 = v193 * 17 + v199
					local v202 = (math.sin(v201) * 0.25 + 1.8 + v198 * 0.8) * math.max(v196, 0.02)
					v200.Width0 = v202 * 1.3
					v200.Width1 = v202 * 0.55
				end
				if v_u_191 <= v193 then
					v_u_191 = v_u_191 + v_u_190
					for _, v203 in v_u_189.walls do
						v203:Emit(p_u_183.lite and 1 or 3)
					end
				end
				return v193 < v_u_188
			end)
			return function()
				-- upvalues: (ref) v_u_192, (copy) v_u_189, (ref) p_u_79, (copy) v_u_187, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (copy) v_u_186, (ref) v_u_7, (ref) v_u_69, (ref) v_u_56, (copy) p_u_183, (ref) v_u_8, (ref) v_u_6
				v_u_192 = true
				for _, v204 in v_u_189.walls do
					v204.Enabled = false
				end
				local v_u_205 = v_u_189.bars
				p_u_79.animate(0.18, 0, function(p206)
					-- upvalues: (copy) v_u_205
					for _, v207 in v_u_205 do
						v207.CurveSize0 = 8.8 * (1 - p206)
						v207.Width0 = 2.2 * (1 - p206)
						v207.Width1 = 1 * (1 - p206)
						v207.Transparency = NumberSequence.new(p206)
					end
				end)
				p_u_79.after(0.15, function()
					-- upvalues: (ref) p_u_79, (ref) v_u_187, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (ref) v_u_186, (ref) v_u_7, (ref) v_u_69, (ref) v_u_56, (ref) p_u_183, (ref) v_u_8, (ref) v_u_6
					p_u_79.burst("Explosion", v_u_187 + Vector3.new(0, 3, 0), v_u_10, 1.5)
					v_u_5.ring(v_u_187, v_u_9, v_u_186 * 1.4, 0.4, v_u_7.Shockwave)
					v_u_69(v_u_56, v_u_187, p_u_183.lite and 4 or 12, 6)
					if not p_u_183.lite then
						local v208 = { v_u_9, v_u_10, v_u_8 }
						p_u_79.chunks(v_u_187 + Vector3.new(0, 2, 0), v208, 8, 30, 0.8, 0.9, true)
					end
					local v209 = {
						["at"] = nil,
						["volume"] = 0.6,
						["at"] = v_u_187
					}
					v_u_6.play("Fireball", v209)
				end)
			end
		end,
		["hit"] = function(p210, p211, _) -- name: hit
			-- upvalues: (copy) p_u_79, (ref) v_u_10, (ref) v_u_56, (ref) v_u_4, (ref) v_u_62, (ref) v_u_1
			p_u_79.burst("Impact", p211, v_u_10, 0.45)
			if not p210.lite then
				local v212 = v_u_56
				local v213 = p211 - Vector3.new(0, 1, 0)
				local v214 = Instance.new("Attachment")
				v214.WorldPosition = v213
				v214.Parent = v_u_4.Terrain
				local v215 = v_u_62(v212, 2.6)
				v215.Parent = v214
				v215:Emit(1)
				v_u_1:AddItem(v214, v212.life * 1.3 + 0.2)
			end
		end
	}
	local v_u_216 = {}
	setmetatable(v_u_216, {
		["__mode"] = "k"
	})
	local function v_u_250(p_u_217, p218) -- name: sunBurst
		-- upvalues: (copy) p_u_79, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (copy) v_u_91, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5, (ref) v_u_11, (ref) v_u_1, (ref) v_u_69, (ref) v_u_56, (ref) v_u_8, (ref) v_u_12, (ref) v_u_6, (ref) v_u_78
		local v_u_219 = p_u_217.ability.radius
		local v_u_220 = p_u_79.ground(p218, 0)
		p_u_79.pop(v_u_220 + Vector3.new(0, 4, 0), v_u_13, 4, 36, 0.3)
		p_u_79.pop(v_u_220 + Vector3.new(0, 4, 0), v_u_9, 6, 28, 0.5, 0.45)
		p_u_79.dome(p218, v_u_219 * 1.3, v_u_10, 0.75)
		local v221 = v_u_91
		local v222 = p_u_79.facing
		local v223 = v_u_220 + Vector3.new(0, 8, 0)
		local v224 = v_u_220 + Vector3.new(0, 8, 0)
		local v225 = v_u_4.CurrentCamera
		local v226
		if v225 then
			local v227 = v225.CFrame.Position - v224
			v226 = v227.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v227.Unit
		else
			v226 = Vector3.new(0, 0, 1)
		end
		v221(v222(v223, v226), 4, v_u_219 * 1.6, v_u_7.Glow, v_u_9, 0.6, 0)
		local v228 = p_u_217.lite and 6 or 12
		local v229 = math.random() * 3.141592653589793 * 2
		for v230 = 1, v228 do
			local v231 = v229 + (v230 - 1) * 3.141592653589793 * 2 / v228
			local v232 = math.cos(v231)
			local v233 = math.sin(v231)
			local v_u_234 = Vector3.new(v232, 0, v233)
			local v235 = v_u_5.part
			local v236 = Vector3.new(1.2, 0.2, 2)
			local v237 = CFrame.lookAt(v_u_220 + Vector3.new(0, 0.6, 0), v_u_220 + Vector3.new(0, 0.6, 0) + v_u_234)
			local v238
			if v230 % 2 == 0 then
				v238 = v_u_11
			else
				v238 = v_u_9
			end
			local v_u_239 = v235(v236, v237, v238)
			v_u_1:AddItem(v_u_239, 0.5)
			p_u_79.animate(0.4, 0, function(p240)
				-- upvalues: (copy) v_u_219, (copy) v_u_239, (copy) v_u_220, (copy) v_u_234
				local v241 = v_u_219 * 1.3 * (1 - (1 - p240) ^ 2)
				local v242 = v_u_239
				local v243 = 1.4 * (1 - p240 * 0.6)
				local v244 = math.max(v241, 0.1)
				v242.Size = Vector3.new(v243, 0.2, v244)
				v_u_239.CFrame = CFrame.lookAt(v_u_220 + Vector3.new(0, 0.6, 0) + v_u_234 * v241 / 2, v_u_220 + Vector3.new(0, 0.6, 0) + v_u_234 * v241)
				local v245 = v_u_239
				local v246 = (p240 - 0.5) / 0.5
				v245.Transparency = math.clamp(v246, 0, 1)
				if p240 >= 1 then
					v_u_239:Destroy()
				end
			end)
			local v247
			if p_u_217.lite then
				v247 = v_u_219
			else
				v247 = v_u_219 / 3
			end
			p_u_79.alongPath(v_u_220 + v_u_234 * 2, v_u_220 + v_u_234 * v_u_219 * 1.05, v247, 0.35, function(p248)
				-- upvalues: (ref) v_u_69, (ref) v_u_56, (copy) p_u_217
				v_u_69(v_u_56, p248, p_u_217.lite and 2 or 3, 5.5)
			end)
		end
		v_u_5.ring(v_u_220, v_u_11, v_u_219 * 1.5, 0.45, v_u_7.Shockwave)
		v_u_5.ring(v_u_220, v_u_10, v_u_219 * 2.1, 0.75, v_u_7.Ring)
		p_u_79.burst("Shockwave", v_u_220 + Vector3.new(0, 0.3, 0), v_u_10, v_u_219 / 12)
		p_u_79.burst("Explosion", v_u_220 + Vector3.new(0, 4, 0), v_u_10, 2.3)
		p_u_79.burst("Explosion", v_u_220 + Vector3.new(0, 2, 0), v_u_8, 1.6)
		p_u_79.mark(p218, v_u_8, v_u_219 * 1.1, 2.8, v_u_7.CrackGlow, 0.15)
		p_u_79.mark(p218, v_u_10, v_u_219 * 0.9, 2, v_u_7.Glow, 0.4)
		if not p_u_217.lite then
			local v249 = {
				v_u_9,
				v_u_10,
				v_u_8,
				v_u_12
			}
			p_u_79.chunks(v_u_220 + Vector3.new(0, 2, 0), v249, 14, 46, 1.1, 1.3, true)
			p_u_79.spikes(v_u_220 + Vector3.new(0, 3, 0), v_u_9, 12, v_u_219 * 1.1, 0.4, Vector3.new(0, 1, 0), 1.2)
		end
		v_u_6.play("Explosion", {
			["at"] = nil,
			["volume"] = 1,
			["at"] = v_u_220
		})
		if p_u_217.mine then
			v_u_5.shake(0.6, 0.5)
			v_u_78(Color3.fromRGB(255, 240, 215), 0.2, 0, 0.03, 0.05, 0.4)
		end
	end
	local function v_u_255(p251, p252) -- name: pillar
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (ref) v_u_62, (ref) v_u_56
		local v253 = v_u_5.part(Vector3.new(3, 1, 3), CFrame.new(p252 + Vector3.new(0, 0.6, 0)), v_u_10, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v253, 2.5)
		local v_u_254 = v_u_62(v_u_56, 5)
		v_u_254.Lifetime = NumberRange.new(0.7, 0.95)
		v_u_254.Speed = NumberRange.new(20, 28)
		v_u_254.SpreadAngle = Vector2.new(8, 8)
		v_u_254.Shape = Enum.ParticleEmitterShape.Box
		v_u_254.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		v_u_254.Rate = p251.lite and 10 or 28
		v_u_254.Enabled = true
		v_u_254.Parent = v253
		task.delay(0.9, function()
			-- upvalues: (copy) v_u_254
			v_u_254.Enabled = false
		end)
	end
	v80.ryujin_jakka_r = {
		["cast"] = function(p256) -- name: cast
			-- upvalues: (copy) p_u_79, (ref) v_u_10, (ref) v_u_9, (ref) v_u_78
			p_u_79.skillCast(p256, v_u_10, true)
			p_u_79.glint(p256.eye, v_u_9, 5 * p256.size, 0.25)
			if p256.mine then
				v_u_78(Color3.fromRGB(255, 214, 180), -0.08, 0.18, 0.15, 0.35, 0.5)
			end
		end,
		["windup"] = function(p257, p258, p259) -- name: windup
			-- upvalues: (copy) p_u_79, (ref) v_u_5, (ref) v_u_11, (ref) v_u_14, (ref) v_u_9, (ref) v_u_10, (ref) v_u_27, (ref) v_u_7, (ref) v_u_1, (ref) v_u_48, (ref) v_u_4, (ref) v_u_55, (copy) v_u_216
			local v_u_260 = p_u_79.ground(p258, 0)
			local v_u_261 = v_u_260 + Vector3.new(0, 24, 0)
			local v262 = p259 + 1.5 + 1
			local v263 = {
				["shape"] = v_u_14
			}
			local v_u_264 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_261), v_u_11, v263)
			local v265 = {
				["shape"] = nil,
				["transparency"] = 0.15,
				["shape"] = v_u_14
			}
			local v_u_266 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_261), v_u_9, v265)
			local v267 = {
				["shape"] = nil,
				["transparency"] = 0.55,
				["shape"] = v_u_14
			}
			local v_u_268 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_261), v_u_10, v267)
			local v_u_269 = v_u_27(CFrame.new(v_u_261), 0.5, v_u_7.Glow, v_u_10, 0.2)
			for _, v270 in {
				v_u_264,
				v_u_266,
				v_u_268,
				v_u_269
			} do
				v_u_1:AddItem(v270, p259 + 0.6)
			end
			local v_u_271 = v_u_48(20, v262)
			local v272 = v_u_4.CurrentCamera
			local v273
			if v272 then
				local v274 = v272.CFrame.Position - v_u_261
				v273 = v274.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v274.Unit
			else
				v273 = Vector3.new(0, 0, 1)
			end
			local v275 = v273.X
			local v276 = v273.Z
			local v277 = Vector3.new(v275, 0, v276)
			local v278 = v277.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v277.Unit
			v_u_271.CFrame = v_u_55(v_u_261 + Vector3.new(0, 10, 0), Vector3.new(-0, -1, -0), v278)
			if p257.mine then
				p_u_79.light(v_u_264, v_u_9, 60)
			end
			local v_u_279 = {
				["core"] = v_u_264,
				["body"] = v_u_266,
				["corona"] = v_u_268,
				["glow"] = v_u_269,
				["blade"] = v_u_271,
				["born"] = os.clock()
			}
			v_u_216[p257] = v_u_279
			local v_u_280 = math.max(p259, 0.08)
			p_u_79.inward(v_u_261, v_u_9, p257.lite and 4 or 10, 30.800000000000004, v_u_280 + 0.05)
			p_u_79.runNow(function()
				-- upvalues: (copy) v_u_279, (copy) v_u_264, (copy) v_u_280, (copy) v_u_266, (copy) v_u_268, (copy) v_u_269, (ref) p_u_79, (copy) v_u_261, (ref) v_u_4, (copy) v_u_260, (copy) v_u_271, (ref) v_u_55
				local v281 = os.clock() - v_u_279.born
				if not v_u_264.Parent then
					return false
				end
				local v282 = v281 / v_u_280
				local v283 = math.clamp(v282, 0, 1)
				local v284 = v283 * 1.6
				local v285 = math.min(v284, 1) - 1
				local v286 = (v285 * 2.7 * v285 * v285 + 1 + v285 * 1.7 * v285) * 14
				local v287 = v281 * 30
				local v288 = v286 * (math.sin(v287) * 0.04 + 1)
				local v289 = v_u_264
				local v290 = v288 * 0.55
				v289.Size = Vector3.new(1, 1, 1) * math.max(v290, 0.2)
				local v291 = v_u_266
				local v292 = v288 * 0.8
				v291.Size = Vector3.new(1, 1, 1) * math.max(v292, 0.2)
				local v293 = v_u_268
				local v294 = v288 * 1.1
				v293.Size = Vector3.new(1, 1, 1) * math.max(v294, 0.2)
				local v295 = v_u_269
				local v296 = v288 * 1.3
				local v297 = math.max(v296, 0.03) * 2
				v295.Size = Vector3.new(v297, 0.05, v297)
				local v298 = v_u_269
				local v299 = p_u_79.facing
				local v300 = v_u_261
				local v301 = v_u_261
				local v302 = v_u_4.CurrentCamera
				local v303
				if v302 then
					local v304 = v302.CFrame.Position - v301
					v303 = v304.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v304.Unit
				else
					v303 = Vector3.new(0, 0, 1)
				end
				v298.CFrame = v299(v300, v303) * CFrame.new(0, -v288 * 0.6, 0)
				local v305 = v_u_261:Lerp(v_u_260 - Vector3.new(0, 2, 0), v283 * v283)
				local v306 = v_u_271
				local v307 = v_u_4.CurrentCamera
				local v308
				if v307 then
					local v309 = v307.CFrame.Position - v305
					v308 = v309.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v309.Unit
				else
					v308 = Vector3.new(0, 0, 1)
				end
				local v310 = v308.X
				local v311 = v308.Z
				local v312 = Vector3.new(v310, 0, v311)
				local v313 = v312.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v312.Unit
				v306.CFrame = v_u_55(v305 + Vector3.new(0, 10, 0), Vector3.new(-0, -1, -0), v313)
				return v283 < 1
			end)
		end,
		["land"] = function(p_u_314, p315) -- name: land
			-- upvalues: (copy) p_u_79, (copy) v_u_216, (ref) v_u_48, (ref) v_u_4, (ref) v_u_55, (copy) v_u_250, (copy) v_u_255, (ref) v_u_5, (ref) v_u_69, (ref) v_u_56, (ref) v_u_1
			local v_u_316 = p_u_79.ground(p315, 0)
			local v317 = v_u_216[p_u_314]
			v_u_216[p_u_314] = nil
			if v317 then
				v317.core:Destroy()
				v317.body:Destroy()
				v317.corona:Destroy()
				v317.glow:Destroy()
			end
			local v_u_318
			if v317 then
				v_u_318 = v317.blade
			else
				v_u_318 = v_u_48(20, 2.5)
			end
			local v319 = v_u_316 - Vector3.new(0, 2, 0)
			local v320 = v_u_4.CurrentCamera
			local v321
			if v320 then
				local v322 = v320.CFrame.Position - v319
				v321 = v322.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v322.Unit
			else
				v321 = Vector3.new(0, 0, 1)
			end
			local v323 = v321.X
			local v324 = v321.Z
			local v325 = Vector3.new(v323, 0, v324)
			local v326 = v325.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v325.Unit
			v_u_318.CFrame = v_u_55(v319 + Vector3.new(0, 10, 0), Vector3.new(-0, -1, -0), v326)
			v_u_250(p_u_314, p315)
			v_u_255(p_u_314, v_u_316)
			local v327 = v_u_318:FindFirstChildWhichIsA("SurfaceAppearance")
			if v327 then
				v327.EmissiveStrength = v327.EmissiveStrength * 2.5
			end
			p_u_79.after(1.5, function()
				-- upvalues: (copy) v_u_318, (ref) v_u_5, (ref) v_u_69, (ref) v_u_56, (copy) v_u_316, (copy) p_u_314, (ref) v_u_1
				if v_u_318.Parent then
					v_u_5.tween(v_u_318, 0.35, {
						["Transparency"] = 1
					})
					v_u_69(v_u_56, v_u_316 + Vector3.new(0, 2, 0), p_u_314.lite and 3 or 8, 5)
					v_u_1:AddItem(v_u_318, 0.4)
				end
			end)
		end,
		["hit"] = function(_, p328, _) -- name: hit
			-- upvalues: (copy) p_u_79, (ref) v_u_10, (ref) v_u_56, (ref) v_u_4, (ref) v_u_62, (ref) v_u_1
			p_u_79.burst("Impact", p328, v_u_10, 0.7)
			local v329 = v_u_56
			local v330 = p328 - Vector3.new(0, 1, 0)
			local v331 = Instance.new("Attachment")
			v331.WorldPosition = v330
			v331.Parent = v_u_4.Terrain
			local v332 = v_u_62(v329, 3)
			v332.Parent = v331
			v332:Emit(1)
			v_u_1:AddItem(v331, v329.life * 1.3 + 0.2)
		end
	}
	return v80
end