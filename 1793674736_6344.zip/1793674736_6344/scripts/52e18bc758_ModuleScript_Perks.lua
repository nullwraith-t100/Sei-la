return {
	["VIP_PASS"] = "vip",
	["VIP_CHAKRA"] = 1.5,
	["VIP_TROPHIES"] = 1.5,
	["VIP_SPEED"] = 1.25,
	["AUTO_WIN_PASS"] = "autoWin",
	["RUN_SECONDS_PER_STAGE"] = 6,
	["AUTO_WIN_SLOWER"] = 1.5,
	["AUTO_WIN_MIN_SECONDS"] = 30,
	["VIP_PLUS_PASS"] = "vipPlus",
	["VIP_PLUS_COINS"] = 1.2,
	["VIP_PLUS_AURA"] = "vip_plus_aura",
	["VIP_PLUS_PET"] = "royal_lion",
	["VIP_PLUS_UPGRADE"] = "vipPlusUpgrade",
	["HOKAGE_PASS"] = "hokage",
	["HOKAGE_COINS"] = 1500,
	["PROMO_MIN_PASSES"] = 3,
	["PROMO_WEIGHT"] = 0.5
}