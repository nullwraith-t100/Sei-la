local v_u_46 = {
	["toSegment"] = function(p1, p2, p3, p4, p5, p6) -- name: toSegment
		local v7 = p3 - p1
		local v8 = p4 - p2
		local v9 = v7 * v7 + v8 * v8
		local v10
		if v9 > 1e-9 then
			local v11 = ((p5 - p1) * v7 + (p6 - p2) * v8) / v9
			v10 = math.clamp(v11, 0, 1)
		else
			v10 = 0
		end
		local v12 = p1 + v7 * v10
		local v13 = p2 + v8 * v10
		local v14 = p5 - v12
		local v15 = p6 - v13
		local v16 = v14 * v14 + v15 * v15
		return math.sqrt(v16), v10
	end,
	["touches"] = function(p17, p18, p19, p20, p21, p22) -- name: touches
		local v23 = p20 - p17
		local v24 = p21 - p18
		local v25 = p19 + p22
		return v23 * v23 + v24 * v24 <= v25 * v25
	end,
	["distance"] = function(p26, p27, p28, p29) -- name: distance
		local v30 = p28 - p26
		local v31 = p29 - p27
		local v32 = v30 * v30 + v31 * v31
		return math.sqrt(v32)
	end,
	["clampReach"] = function(p33, p34, p35, p36, p37) -- name: clampReach
		-- upvalues: (copy) v_u_46
		local v38 = v_u_46.distance(p33, p34, p35, p36)
		if v38 <= p37 or v38 < 1e-6 then
			return p35, p36
		end
		local v39 = p37 / v38
		return p33 + (p35 - p33) * v39, p34 + (p36 - p34) * v39
	end,
	["lineEnd"] = function(p40, p41, p42, p43, p44) -- name: lineEnd
		-- upvalues: (copy) v_u_46
		local v45 = v_u_46.distance(p40, p41, p42, p43)
		if v45 < 1e-6 then
			return p40, p41 - p44
		else
			return p40 + (p42 - p40) / v45 * p44, p41 + (p43 - p41) / v45 * p44
		end
	end
}
return v_u_46