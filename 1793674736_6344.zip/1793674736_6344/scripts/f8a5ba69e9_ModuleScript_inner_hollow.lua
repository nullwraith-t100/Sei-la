local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.InnerChain,
	v_u_7.InnerSlash,
	v_u_7.InnerFlame,
	v_u_7.InnerFangs,
	v_u_7.InnerRoar
})
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FFD21F")
local v_u_10 = Color3.fromRGB(10, 10, 10)
local v_u_11 = Color3.fromRGB(236, 232, 220)
local v_u_12 = Enum.Material.SmoothPlastic
local function v_u_21(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part(Vector3.new(p14, 0.05, p14), p13, p16, {
		["transparency"] = 1
	})
	for _, v19 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v20 = Instance.new("Decal")
		v20.Face = v19
		v20.Texture = p15
		v20.Color3 = p16
		v20.Transparency = p17
		v20.Parent = v18
	end
	return v18
end
local function v_u_29(p22, p23, p24, p25, p_u_26) -- name: cut
	-- upvalues: (copy) v_u_21, (copy) v_u_1, (copy) v_u_4
	local v_u_27 = v_u_21(p22, p23 * 0.35, p24, p25, 0)
	v_u_1:AddItem(v_u_27, p_u_26 + 0.1)
	v_u_4.tween(v_u_27, p_u_26 * 0.3, {
		["Size"] = Vector3.new(p23, 0.05, p23)
	}, Enum.EasingStyle.Quart)
	task.delay(p_u_26 * 0.3, function()
		-- upvalues: (copy) v_u_27, (ref) v_u_4, (copy) p_u_26
		for _, v28 in v_u_27:GetChildren() do
			if not v28:IsA("Decal") then
				continue
			end
			v_u_4.tween(v28, p_u_26 * 0.7, {
				["Transparency"] = 1
			})
		end
	end)
end
local function v_u_39(p30, p31, p32, p33, p34, p35, p36) -- name: facePop
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_1
	local v37 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p30), v_u_8, {
		["transparency"] = 1
	})
	local v38 = Instance.new("ParticleEmitter")
	v38.Enabled = false
	v38.Texture = p31
	v38.Color = ColorSequence.new(p32)
	v38.LightEmission = 0
	v38.LightInfluence = 0
	v38.Lifetime = NumberRange.new(p35)
	v38.Speed = NumberRange.new(0)
	v38.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p33), NumberSequenceKeypoint.new(0.3, p34), NumberSequenceKeypoint.new(1, p34 * 1.05) })
	v38.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 0), NumberSequenceKeypoint.new(1, 1) })
	v38.ZOffset = p36
	v38.Parent = v37
	v38:Emit(1)
	v_u_1:AddItem(v37, p35 + 0.1)
end
local function v_u_47(p40, p41, p42, p43, p44) -- name: blackFire
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_7, (copy) v_u_1
	local v45 = v_u_4.part(Vector3.new(p43, 0.2, p43), CFrame.new(p40), v_u_8, {
		["transparency"] = 1
	})
	local v46 = Instance.new("ParticleEmitter")
	v46.Enabled = false
	v46.Texture = v_u_7.InnerFlame
	v46.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v46.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v46.Color = ColorSequence.new(v_u_8)
	v46.LightEmission = 0
	v46.LightInfluence = 0
	v46.Lifetime = NumberRange.new(0.45, 0.65)
	v46.Size = NumberSequence.new(p41 * 0.8, p41)
	v46.Speed = NumberRange.new(p44 * 0.5, p44)
	v46.EmissionDirection = Enum.NormalId.Top
	v46.SpreadAngle = Vector2.new(20, 20)
	v46.Rotation = NumberRange.new(-15, 15)
	v46.Shape = Enum.ParticleEmitterShape.Box
	v46.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v46.Parent = v45
	v46:Emit(p42)
	v_u_1:AddItem(v45, 0.9)
end
local function v_u_70(p_u_48, p49, p_u_50) -- name: newBlade
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1, (copy) v_u_8, (copy) v_u_12, (copy) v_u_10, (copy) v_u_9
	local v_u_51 = {
		["parts"] = {},
		["offs"] = {},
		["hilt"] = p_u_48 * 0.46
	}
	local v52 = v_u_2:FindFirstChild("EyePieces")
	if v52 then
		v52 = v52:FindFirstChild("w7_inner_hollow")
	end
	if p49 or not (v52 and v52:IsA("MeshPart")) then
		local function v61(p53, p54, p55, p56) -- name: add
			-- upvalues: (ref) v_u_4, (copy) p_u_48, (ref) v_u_1, (copy) p_u_50, (copy) v_u_51
			local v57 = v_u_4.part(p53 * p_u_48, p54, p55, {
				["material"] = p56
			})
			v_u_1:AddItem(v57, p_u_50)
			local v58 = v_u_51.parts
			table.insert(v58, v57)
			local v59 = v_u_51.offs
			local v60 = CFrame.new(p54.Position * p_u_48) * p54.Rotation
			table.insert(v59, v60)
		end
		v61(Vector3.new(0.22, 0.78, 0.035), CFrame.new(0.02, -0.08, 0), v_u_8, v_u_12)
		v61(Vector3.new(0.06, 0.78, 0.045), CFrame.new(0.15, -0.08, 0), v_u_10, v_u_12)
		v61(Vector3.new(0.025, 0.7, 0.05), CFrame.new(0, -0.08, 0), v_u_9)
		v61(Vector3.new(0.07, 0.2, 0.07), CFrame.new(0, 0.4, 0), v_u_10, v_u_12)
		v61(Vector3.new(0.2, 0.04, 0.08), CFrame.new(0, 0.3, 0), v_u_9)
		return v_u_51
	end
	local v62 = v52:Clone()
	local v63 = v52.Size
	local v64 = v52.Size.X
	local v65 = v52.Size.Y
	local v66 = v52.Size.Z
	v62.Size = v63 * (p_u_48 / math.max(v64, v65, v66, 0.01))
	v62.Anchored = true
	v62.CanCollide = false
	v62.CanQuery = false
	v62.CanTouch = false
	v62.CastShadow = false
	v62.Parent = v_u_4.folder()
	v_u_1:AddItem(v62, p_u_50)
	local v67 = v_u_51.parts
	table.insert(v67, v62)
	local v68 = v_u_51.offs
	local v69 = CFrame.identity
	table.insert(v68, v69)
	return v_u_51
end
local function v_u_74(p71, p72) -- name: dropBlade
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	for _, v73 in p71.parts do
		v_u_4.tween(v73, p72, {
			["Transparency"] = 1
		})
		v_u_1:AddItem(v73, p72 + 0.05)
	end
end
local function v_u_80(p75, p76, p77, p78) -- name: chain
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v79 = Instance.new("Beam")
	v79.Attachment0 = p75
	v79.Attachment1 = p76
	v79.Texture = v_u_7.InnerChain
	v79.TextureMode = Enum.TextureMode.Wrap
	v79.TextureLength = p77 * 2.2
	v79.Color = ColorSequence.new(v_u_8)
	v79.LightEmission = 0
	v79.LightInfluence = 0
	v79.FaceCamera = true
	v79.Segments = 10
	v79.Width0 = p77
	v79.Width1 = p77
	v79.Parent = p78
	return v79
end
local function v_u_89(p81, p82, p83) -- name: swirl
	-- upvalues: (copy) v_u_8, (copy) v_u_10
	local v84 = Instance.new("Attachment")
	local v85 = p82 * 0.45
	v84.Position = Vector3.new(0, v85, 0)
	v84.Parent = p81
	local v86 = Instance.new("Attachment")
	local v87 = -p82 * 0.5
	v86.Position = Vector3.new(0, v87, 0)
	v86.Parent = p81
	local v88 = Instance.new("Trail")
	v88.Attachment0 = v84
	v88.Attachment1 = v86
	v88.Color = ColorSequence.new(v_u_8, v_u_10)
	v88.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.5, 0.45), NumberSequenceKeypoint.new(1, 1) })
	v88.Lifetime = p83
	v88.LightEmission = 0
	v88.LightInfluence = 0
	v88.MinLength = 0.05
	v88.Parent = p81
	return v88
end
return function(p_u_90)
	-- upvalues: (copy) v_u_3, (copy) v_u_29, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_9, (copy) v_u_70, (copy) v_u_89, (copy) v_u_1, (copy) v_u_80, (copy) v_u_47, (copy) v_u_39, (copy) v_u_10, (copy) v_u_21, (copy) v_u_12, (copy) v_u_74, (copy) v_u_11, (copy) v_u_6
	local v91 = {}
	local function v_u_99(p92, p93, p94) -- name: cross
		-- upvalues: (ref) v_u_3, (copy) p_u_90, (ref) v_u_29, (ref) v_u_7, (ref) v_u_8
		local v95 = v_u_3.CurrentCamera
		local v96
		if v95 then
			local v97 = v95.CFrame.Position - p92
			v96 = v97.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v97.Unit
		else
			v96 = Vector3.new(0, 0, 1)
		end
		local v98 = p_u_90.facing(p92 + v96 * 0.5, v96)
		v_u_29(v98 * CFrame.Angles(0, 0.6981317007977318, 0), p93, v_u_7.InnerSlash, v_u_8, p94)
		v_u_29(v98 * CFrame.new(0, 0.05, 0) * CFrame.Angles(0, -2.2689280275926285, 0), p93 * 0.9, v_u_7.InnerSlash, v_u_8, p94)
	end
	v91.inner_hollow_a = {
		["cast"] = function(p100) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_90
			local v101 = p100.size
			local v102 = p100.eye + p100.dir * 1.2
			v_u_4.flash(v102, v_u_9, 2 * v101, 0.1)
			if not p100.lite then
				p_u_90.glint(p100.eye, v_u_9, 2.4 * v101, 0.12)
			end
		end,
		["shot"] = function(p103, p104) -- name: shot
			-- upvalues: (ref) v_u_70, (ref) v_u_89, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_80, (copy) p_u_90
			local v105 = p103.size
			local v106 = 3.4 * v105
			local v_u_107 = v_u_70(v106, p103.lite, 3)
			local v108 = v_u_107.parts[1]
			local v_u_109
			if p103.lite then
				v_u_109 = nil
			else
				v_u_109 = v_u_89(v108, v106, 0.14)
			end
			local v_u_110, v_u_111
			if p103.lite then
				v_u_110 = nil
				v_u_111 = nil
			else
				v_u_110 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p104, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_110, 3)
				local v112 = Instance.new("Attachment")
				v112.Parent = v_u_110
				local v113 = Instance.new("Attachment")
				v113.Parent = v108
				local v114 = v_u_107.hilt
				v113.Position = Vector3.new(0, v114, 0)
				v_u_111 = v_u_80(v112, v113, 0.32 * v105, v_u_110)
			end
			local v_u_115 = p104.Position
			local v_u_116 = p104
			local v_u_117 = false
			return {
				["place"] = function(p118, p119) -- name: place
					-- upvalues: (ref) v_u_116, (copy) v_u_107
					v_u_116 = p118
					local v120 = v_u_107
					local v121 = p118 * CFrame.Angles(0, 0, p119 * 24)
					for v122, v123 in v120.parts do
						v123.CFrame = v121 * v120.offs[v122]
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_117, (copy) v_u_109, (ref) v_u_116, (ref) p_u_90, (copy) v_u_107, (copy) v_u_115, (ref) v_u_110, (ref) v_u_111
					if not v_u_117 then
						v_u_117 = true
						local v124 = v_u_109
						if v124 then
							v124.Enabled = false
						end
						local v_u_125 = v_u_116
						p_u_90.animate(0.12, 0, function(p126)
							-- upvalues: (ref) v_u_107, (copy) v_u_125, (ref) v_u_115, (ref) v_u_110
							local v127 = v_u_107
							local v128 = CFrame.new(v_u_125.Position:Lerp(v_u_115, p126 * p126)) * v_u_125.Rotation * CFrame.Angles(0, 0, p126 * 6)
							for v129, v130 in v127.parts do
								v130.CFrame = v128 * v127.offs[v129]
							end
							if p126 >= 1 then
								for _, v131 in v_u_107.parts do
									v131:Destroy()
								end
								local v132 = v_u_110
								if v132 then
									v132:Destroy()
								end
							end
						end)
						local v133 = v_u_111
						if v133 then
							v133.Transparency = NumberSequence.new(0.3)
						end
					end
				end
			}
		end,
		["impact"] = function(p134, p135) -- name: impact
			-- upvalues: (copy) v_u_99, (ref) v_u_4, (ref) v_u_9, (copy) p_u_90, (ref) v_u_47
			local v136 = p134.size
			v_u_99(p135, 5.5 * v136, 0.3)
			v_u_4.flash(p135, v_u_9, 3 * v136, 0.14)
			if not p134.lite then
				p_u_90.glint(p135, v_u_9, 3.5 * v136, 0.14)
				v_u_47(p_u_90.ground(p135, 0.3), 2.2 * v136, 2, 1.5 * v136, 4)
			end
			p_u_90.hitSound(p135)
		end,
		["hit"] = function(p137, p138, _) -- name: hit
			-- upvalues: (ref) v_u_3, (ref) v_u_29, (copy) p_u_90, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
			local v139 = v_u_3.CurrentCamera
			local v140
			if v139 then
				local v141 = v139.CFrame.Position - p138
				v140 = v141.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v141.Unit
			else
				v140 = Vector3.new(0, 0, 1)
			end
			v_u_29(p_u_90.facing(p138 + v140, v140) * CFrame.Angles(0, math.random() * 6.28, 0), 3 * p137.size, v_u_7.InnerSlash, v_u_8, 0.2)
			p_u_90.burst("Impact", p138, v_u_9, 0.5)
		end
	}
	v91.inner_hollow_e = {
		["cast"] = nil,
		["shot"] = nil,
		["weave"] = 0.3,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p142) -- name: cast
			-- upvalues: (copy) p_u_90, (ref) v_u_9, (ref) v_u_39, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_47, (ref) v_u_4
			p_u_90.skillCast(p142, v_u_9, false, true)
			local v143 = p142.size
			local v144 = p142.eye + p142.dir * 2.2 - Vector3.new(0, 0.4, 0)
			v_u_39(v144, v_u_7.Glow, v_u_10, 2 * v143, 7.5 * v143, 0.6, 0)
			v_u_39(v144, v_u_7.InnerFangs, v_u_8, 1.5 * v143, 5.5 * v143, 0.55, 1)
			p_u_90.glint(p142.eye, v_u_9, 4 * v143, 0.2)
			if not p142.lite then
				v_u_47(p142.feet, 2.4 * v143, 5, 3 * v143, 6)
			end
			if p142.mine then
				v_u_4.shake(0.18, 0.2)
			end
		end,
		["shot"] = function(p145, p146) -- name: shot
			-- upvalues: (ref) v_u_21, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (copy) p_u_90, (ref) v_u_4
			local v_u_147 = p145.size
			local v148 = (p145.target - p145.eye).Magnitude / (p145.ability.speed or 180)
			local v_u_149 = math.max(v148, 0.05)
			local v_u_150 = v_u_21(p146, 1.5 * v_u_147, v_u_7.InnerRoar, v_u_8, 0)
			local v_u_151
			if p145.lite then
				v_u_151 = nil
			else
				v_u_151 = v_u_21(p146, 1.8 * v_u_147, v_u_7.InnerRoar, v_u_9, 0.25)
			end
			v_u_1:AddItem(v_u_150, 3)
			if v_u_151 then
				v_u_1:AddItem(v_u_151, 3)
			end
			local v_u_152 = false
			return {
				["place"] = function(p153, p154) -- name: place
					-- upvalues: (copy) v_u_149, (copy) v_u_147, (ref) p_u_90, (copy) v_u_150, (copy) v_u_151
					local v155 = p154 / v_u_149
					local v156 = (math.clamp(v155, 0, 1) * 3.5 + 2.5) * v_u_147
					local v157 = p_u_90.facing(p153.Position, p153.LookVector)
					local v158 = CFrame.Angles
					local v159 = p154 * 20
					local v160 = v157 * v158(0, math.sin(v159) * 0.25, 0)
					v_u_150.CFrame = v160
					v_u_150.Size = Vector3.new(v156, 0.05, v156)
					local v161 = v_u_151
					if v161 then
						v161.CFrame = v160 * CFrame.new(0, -0.6 * v_u_147, 0)
						local v162 = v156 * 1.2
						local v163 = v156 * 1.2
						v161.Size = Vector3.new(v162, 0.05, v163)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_152, (copy) v_u_150, (copy) v_u_151, (ref) v_u_4, (ref) v_u_1
					if not v_u_152 then
						v_u_152 = true
						local v164 = { v_u_150 }
						local v165 = v_u_151
						if v165 then
							table.insert(v164, v165)
						end
						for _, v166 in v164 do
							v_u_4.tween(v166, 0.28, {
								["Size"] = v166.Size * Vector3.new(1.5, 1, 1.5)
							})
							for _, v167 in v166:GetChildren() do
								if not v167:IsA("Decal") then
									continue
								end
								v_u_4.tween(v167, 0.28, {
									["Transparency"] = 1
								})
							end
							v_u_1:AddItem(v166, 0.32)
						end
					end
				end
			}
		end,
		["impact"] = function(p168, p169) -- name: impact
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) p_u_90, (ref) v_u_10, (ref) v_u_12, (ref) v_u_47, (ref) v_u_9, (ref) v_u_7
			local v170 = p168.size
			v_u_4.flash(p169, v_u_8, 2.4 * v170, 0.1)
			p_u_90.pop(p169, v_u_10, 1 * v170, 4.5 * v170, 0.25, 0.2, v_u_12)
			v_u_47(p_u_90.ground(p169, 0.3), 2.6 * v170, p168.lite and 1 or 3, 2 * v170, 5)
			if not p168.lite then
				p_u_90.spikes(p169, v_u_9, 4, 4 * v170, 0.18)
			end
			v_u_4.ring(p_u_90.ground(p169, 0.12), v_u_10, 3.6 * v170, 0.25, v_u_7.Ring)
			p_u_90.hitSound(p169)
		end,
		["hit"] = function(_, p171, _) -- name: hit
			-- upvalues: (copy) p_u_90, (ref) v_u_9
			p_u_90.burst("Impact", p171, v_u_9, 0.7)
		end
	}
	local v_u_172 = {}
	v91.inner_hollow_r = {
		["cast"] = nil,
		["castSound"] = "Fireball",
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p173) -- name: cast
			-- upvalues: (copy) p_u_90, (ref) v_u_9, (ref) v_u_47
			p_u_90.skillCast(p173, v_u_9, true, true)
			if not p173.lite then
				v_u_47(p173.feet, 2.6 * p173.size, 6, 3 * p173.size, 7)
			end
		end,
		["windup"] = function(p174, p175, p176) -- name: windup
			-- upvalues: (copy) p_u_90, (ref) v_u_70, (copy) v_u_172, (ref) v_u_10, (ref) v_u_7
			local v_u_177 = p174.size
			local v178 = p174.ability.radius * v_u_177
			local v179 = p_u_90.ground(p175, 6 * v_u_177)
			local v_u_180 = v_u_70(8.5 * v_u_177, p174.lite, p176 + (p174.ability.duration or 2.4) + 1)
			local v_u_181 = p174.eye
			local v182 = v178 * 0.5
			local v183 = -2 * v_u_177
			local v_u_184 = v179 + Vector3.new(v182, v183, 0)
			local v185 = math.max(p176, 0.1)
			p_u_90.animate(v185, 0, function(p186)
				-- upvalues: (copy) v_u_181, (copy) v_u_184, (copy) v_u_177, (copy) v_u_180
				local v187 = v_u_181:Lerp(v_u_184, p186)
				local v188 = p186 * 3.141592653589793
				local v189 = v187 + Vector3.new(0, 1, 0) * math.sin(v188) * 3 * v_u_177
				local v190 = v_u_180
				local v191 = CFrame.new(v189) * CFrame.Angles(-p186 * 12, 0, 1.5707963267948966)
				for v192, v193 in v190.parts do
					v193.CFrame = v191 * v190.offs[v192]
				end
			end)
			v_u_172[p174] = {
				["blade"] = nil,
				["pivot"] = nil,
				["angle"] = 0,
				["radius"] = nil,
				["blade"] = v_u_180,
				["pivot"] = v179,
				["radius"] = v178 * 0.5
			}
			p_u_90.sigil(CFrame.new(p_u_90.ground(p175, 0.12)), v178, v_u_10, v_u_7.Ring, v185 + (p174.ability.duration or 2.4), 0)
		end,
		["zone"] = function(p_u_194, p195, p196) -- name: zone
			-- upvalues: (copy) p_u_90, (copy) v_u_172, (ref) v_u_70, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_80, (ref) v_u_89, (ref) v_u_7, (ref) v_u_9, (copy) v_u_99, (ref) v_u_74
			local v_u_197 = p_u_194.size
			local v_u_198 = p_u_194.lite
			local v_u_199 = p_u_194.ability.radius * v_u_197
			local v_u_200 = p_u_90.ground(p195, 0.2)
			local v_u_201 = v_u_172[p_u_194] or {
				["blade"] = nil,
				["pivot"] = nil,
				["angle"] = 0,
				["radius"] = nil,
				["blade"] = v_u_70(8.5 * v_u_197, v_u_198, p196 + 1),
				["pivot"] = p_u_90.ground(p195, 6 * v_u_197),
				["radius"] = v_u_199 * 0.5
			}
			local v_u_202 = v_u_201.blade
			local v203 = v_u_202.parts[1]
			local v_u_204 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_201.pivot), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_204, p196 + 1)
			local v205 = Instance.new("Attachment")
			v205.Parent = v_u_204
			local v206 = Instance.new("Attachment")
			v206.Parent = v203
			local v207 = 8.5 * v_u_197 * 0.46
			v206.Position = Vector3.new(0, v207, 0)
			local v_u_208 = v_u_80(v205, v206, 0.6 * v_u_197, v_u_204)
			local v_u_209 = v_u_89(v203, 8.5 * v_u_197, v_u_198 and 0.2 or 0.4)
			local v_u_210 = {}
			if not v_u_198 then
				for _ = 1, 2 do
					local v211 = v_u_70(8.5 * v_u_197, true, p196 + 1)
					for _, v212 in v211.parts do
						v212.Transparency = 0.6
					end
					table.insert(v_u_210, v211)
				end
			end
			local v_u_213 = {}
			if not v_u_198 then
				local v214 = Instance.new("ParticleEmitter")
				v214.Texture = v_u_7.FxTwinkle
				v214.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v214.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v214.Color = ColorSequence.new(v_u_9)
				v214.LightEmission = 0.6
				v214.LightInfluence = 0
				v214.Lifetime = NumberRange.new(0.25, 0.4)
				v214.Size = NumberSequence.new(0.9 * v_u_197, 0.2)
				v214.Speed = NumberRange.new(6, 14)
				v214.SpreadAngle = Vector2.new(60, 60)
				v214.Acceleration = Vector3.new(0, -30, 0)
				v214.Rate = 40
				v214.Parent = v203
				table.insert(v_u_213, v214)
				local v215 = v_u_4.part
				local v216 = v_u_199 * 2
				local v217 = v_u_199 * 2
				local v218 = v215(Vector3.new(v216, 1, v217), CFrame.new(v_u_200 + Vector3.new(0, 0.3, 0)), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v218, p196 + 1.5)
				local v219 = Instance.new("ParticleEmitter")
				v219.Texture = v_u_7.InnerFlame
				v219.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v219.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v219.Color = ColorSequence.new(v_u_8)
				v219.LightEmission = 0
				v219.LightInfluence = 0
				v219.Lifetime = NumberRange.new(0.5, 0.7)
				v219.Size = NumberSequence.new(2.2 * v_u_197, 2.8 * v_u_197)
				v219.Speed = NumberRange.new(0.5, 1.5)
				v219.Acceleration = Vector3.new(0, 12, 0)
				v219.EmissionDirection = Enum.NormalId.Top
				v219.SpreadAngle = Vector2.new(10, 10)
				v219.Shape = Enum.ParticleEmitterShape.Cylinder
				v219.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
				v219.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
				v219.Rate = 30
				v219.Parent = v218
				table.insert(v_u_213, v219)
			end
			local v_u_220 = os.clock()
			local v_u_221 = 0
			local v_u_222 = p_u_194.ability.tick or 0.4
			local v_u_223 = true
			p_u_90.frame(function()
				-- upvalues: (ref) v_u_223, (copy) v_u_220, (copy) v_u_201, (copy) v_u_197, (copy) v_u_202, (copy) v_u_210, (ref) v_u_221, (copy) v_u_222, (copy) v_u_199, (copy) v_u_200, (ref) v_u_99, (copy) v_u_198, (ref) p_u_90, (ref) v_u_9
				if not v_u_223 then
					return false
				end
				local v224 = os.clock() - v_u_220
				local v225 = v224 * 14.451326206513047
				local v226 = v_u_202
				local v227 = math.cos(v225)
				local v228 = math.sin(v225)
				local v229 = Vector3.new(v227, 0, v228)
				local v230 = v_u_201.pivot + v229 * v_u_201.radius - Vector3.new(0, 2, 0) * v_u_197
				local v231 = -math.sin(v225)
				local v232 = math.cos(v225)
				local v233 = Vector3.new(v231, 0, v232)
				local v234 = CFrame.fromMatrix(v230, v233, -v229)
				for v235, v236 in v226.parts do
					v236.CFrame = v234 * v226.offs[v235]
				end
				for v237, v238 in v_u_210 do
					local v239 = v225 - v237 * 0.45
					local v240 = math.cos(v239)
					local v241 = math.sin(v239)
					local v242 = Vector3.new(v240, 0, v241)
					local v243 = v_u_201.pivot + v242 * v_u_201.radius - Vector3.new(0, 2, 0) * v_u_197
					local v244 = -math.sin(v239)
					local v245 = math.cos(v239)
					local v246 = Vector3.new(v244, 0, v245)
					local v247 = CFrame.fromMatrix(v243, v246, -v242)
					for v248, v249 in v238.parts do
						v249.CFrame = v247 * v238.offs[v248]
					end
				end
				if v_u_221 <= v224 then
					v_u_221 = v_u_221 + v_u_222
					local v250 = v_u_199 * 0.8
					local v251 = math.random()
					local v252 = v250 * math.sqrt(v251)
					local v253 = math.random() * 3.141592653589793 * 2
					local v254 = v_u_200
					local v255 = math.cos(v253) * v252
					local v256 = (2 + math.random() * 3) * v_u_197
					local v257 = math.sin(v253) * v252
					local v258 = v254 + Vector3.new(v255, v256, v257)
					v_u_99(v258, 5 * v_u_197, 0.3)
					if not v_u_198 then
						p_u_90.glint(v258, v_u_9, 3 * v_u_197, 0.14)
					end
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_223, (copy) v_u_209, (copy) v_u_213, (copy) v_u_208, (ref) v_u_74, (copy) v_u_202, (copy) v_u_210, (ref) v_u_1, (copy) v_u_204, (ref) v_u_172, (copy) p_u_194
				v_u_223 = false
				v_u_209.Enabled = false
				for _, v259 in v_u_213 do
					v259.Enabled = false
				end
				v_u_208.Transparency = NumberSequence.new(0.5)
				v_u_74(v_u_202, 0.15)
				for _, v260 in v_u_210 do
					v_u_74(v260, 0.15)
				end
				v_u_1:AddItem(v_u_204, 0.2)
				v_u_172[p_u_194] = nil
			end
		end,
		["finish"] = function(p_u_261, p262) -- name: finish
			-- upvalues: (copy) p_u_90, (ref) v_u_70, (ref) v_u_74, (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_12, (ref) v_u_9, (ref) v_u_7, (ref) v_u_47, (ref) v_u_11, (ref) v_u_6
			local v_u_263 = p_u_261.size
			local v_u_264 = p_u_261.lite
			local v_u_265 = p_u_261.ability.radius * v_u_263
			local v_u_266 = p_u_90.ground(p262, 0.15)
			local v_u_267 = v_u_70(6.5 * v_u_263, v_u_264, 1.6)
			p_u_90.animate(0.1, 0, function(p268)
				-- upvalues: (copy) v_u_267, (copy) v_u_266, (copy) v_u_263, (ref) p_u_90, (ref) v_u_74
				local v269 = v_u_267
				local v270 = CFrame.new(v_u_266 + Vector3.new(0, 1, 0) * (3.2 * v_u_263 + (1 - p268) * 12 * v_u_263)) * CFrame.Angles(0, 0.5235987755982988, 0)
				for v271, v272 in v269.parts do
					v272.CFrame = v270 * v269.offs[v271]
				end
				if p268 >= 1 then
					p_u_90.after(0.7, function()
						-- upvalues: (ref) v_u_74, (ref) v_u_267
						v_u_74(v_u_267, 0.3)
					end)
				end
			end)
			p_u_90.after(0.1, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_266, (ref) v_u_8, (copy) v_u_263, (ref) p_u_90, (ref) v_u_10, (copy) v_u_265, (ref) v_u_12, (ref) v_u_9, (ref) v_u_7, (copy) v_u_264, (ref) v_u_47, (ref) v_u_11, (ref) v_u_6, (copy) p_u_261
				v_u_4.flash(v_u_266 + Vector3.new(0, 2, 0), v_u_8, 8 * v_u_263, 0.14)
				p_u_90.pop(v_u_266 + Vector3.new(0, 1, 0), v_u_10, 3 * v_u_263, v_u_265 * 1.5, 0.45, 0.1, v_u_12)
				p_u_90.pop(v_u_266 + Vector3.new(0, 1, 0), v_u_9, 2 * v_u_263, v_u_265 * 0.8, 0.25, 0.5)
				v_u_4.ring(v_u_266, v_u_10, v_u_265 * 1.2, 0.5, v_u_7.Shockwave)
				v_u_4.ring(v_u_266, v_u_8, v_u_265 * 1.45, 0.55, v_u_7.Ring)
				local v273 = math.random() * 3.141592653589793 * 2
				for v274 = 1, v_u_264 and 4 or 8 do
					local v275 = v273 + v274 / (v_u_264 and 4 or 8) * 3.141592653589793 * 2
					local v276 = v_u_266
					local v277 = math.cos(v275)
					local v278 = math.sin(v275)
					local v279 = v276 + Vector3.new(v277, 0, v278) * v_u_265 * (0.7 + math.random() * 0.4)
					p_u_90.groundLine(v_u_266, v279, 0.9 * v_u_263, v_u_10, 0.9, 0)
					p_u_90.groundLine(v_u_266, v279, 0.3 * v_u_263, v_u_8, 0.9, 0)
				end
				if not v_u_264 then
					for v280 = 1, 8 do
						local v281 = v280 / 8 * 3.141592653589793 * 2
						local v282 = v_u_47
						local v283 = v_u_266
						local v284 = math.cos(v281)
						local v285 = math.sin(v281)
						v282(v283 + Vector3.new(v284, 0, v285) * v_u_265 * 0.6, 3 * v_u_263, 2, 2 * v_u_263, 7)
					end
					p_u_90.spikes(v_u_266 + Vector3.new(0, 2, 0), v_u_9, 8, 9 * v_u_263, 0.25)
					local v286 = { v_u_11, v_u_10, v_u_8 }
					p_u_90.chunks(v_u_266 + Vector3.new(0, 0.5, 0), v286, 8, 30, 0.55 * v_u_263, 0.9, false, 1)
				end
				v_u_6.play("Explosion", {
					["at"] = v_u_266,
					["volume"] = p_u_261.mine and 1 or 0.55
				})
				if p_u_261.mine then
					v_u_4.shake(0.45, 0.35)
				end
			end)
		end,
		["hit"] = function(_, p287, _) -- name: hit
			-- upvalues: (copy) p_u_90, (ref) v_u_9
			p_u_90.glint(p287, v_u_9, 2.4, 0.12)
			p_u_90.burst("Impact", p287, v_u_9, 0.6)
		end
	}
	return v91
end