require(script.Parent.Training)
return {
	{
		["id"] = "w2_dummy",
		["name"] = "Moon Dummy",
		["theme"] = "dummy",
		["rebirths"] = 64,
		["mult"] = 75,
		["color"] = "#9FD8FF"
	},
	{
		["id"] = "w2_ring",
		["name"] = "Lotus Ring",
		["theme"] = "ring",
		["rebirths"] = 66,
		["mult"] = 240,
		["color"] = "#FF9BD2"
	},
	{
		["id"] = "w2_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 740,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w2_falls",
		["name"] = "Starfall Falls",
		["theme"] = "waterfall",
		["rebirths"] = 69,
		["mult"] = 740,
		["color"] = "#7FB8FF"
	},
	{
		["id"] = "w2_forge",
		["name"] = "Sun Forge",
		["theme"] = "forge",
		["rebirths"] = 72,
		["mult"] = 2300,
		["color"] = "#FFB347"
	},
	{
		["id"] = "w2_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 7400,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w2_temple",
		["name"] = "Jade Temple",
		["theme"] = "temple",
		["rebirths"] = 77,
		["mult"] = 7400,
		["color"] = "#7CFFB2"
	},
	{
		["id"] = "w2_storm",
		["name"] = "Aurora Tower",
		["theme"] = "storm",
		["rebirths"] = 85,
		["mult"] = 23000,
		["color"] = "#B9F3FF"
	},
	{
		["id"] = "w2_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 73000,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w2_gravity",
		["name"] = "Abyss Chamber",
		["theme"] = "gravity",
		["rebirths"] = 97,
		["mult"] = 73000,
		["color"] = "#8C7BFF"
	},
	{
		["id"] = "w2_blood",
		["name"] = "Starfall Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 109,
		["mult"] = 230000,
		["color"] = "#C77DFF"
	},
	{
		["id"] = "w2_six_paths",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 3700000,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w2_void",
		["name"] = "Heaven\'s Altar",
		["theme"] = "void",
		["rebirths"] = 121,
		["mult"] = 730000,
		["color"] = "#FFF6CC"
	}
}