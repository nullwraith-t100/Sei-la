require(script.Parent.Training)
return {
	{
		["id"] = "w4_icedummy",
		["name"] = "Ice Dummy",
		["theme"] = "dummy",
		["rebirths"] = 240,
		["mult"] = 39000000000,
		["color"] = "#E8F7FF"
	},
	{
		["id"] = "w4_frostring",
		["name"] = "Frost Ring",
		["theme"] = "ring",
		["rebirths"] = 247,
		["mult"] = 125000000000,
		["color"] = "#9EDCFF"
	},
	{
		["id"] = "w4_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 399000000000,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w4_frozenfalls",
		["name"] = "Frozen Falls",
		["theme"] = "waterfall",
		["rebirths"] = 254,
		["mult"] = 399000000000,
		["color"] = "#7FD8FF"
	},
	{
		["id"] = "w4_iceforge",
		["name"] = "Ice Forge",
		["theme"] = "forge",
		["rebirths"] = 262,
		["mult"] = 1280000000000,
		["color"] = "#4FC8FF"
	},
	{
		["id"] = "w4_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 4090000000000,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w4_glaciertemple",
		["name"] = "Glacier Temple",
		["theme"] = "temple",
		["rebirths"] = 269,
		["mult"] = 4090000000000,
		["color"] = "#4D7CFF"
	},
	{
		["id"] = "w4_blizzardtower",
		["name"] = "Blizzard Tower",
		["theme"] = "storm",
		["rebirths"] = 276,
		["mult"] = 13100000000000,
		["color"] = "#CFE1FF"
	},
	{
		["id"] = "w4_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 41900000000000,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w4_deepchamber",
		["name"] = "Deep Chamber",
		["theme"] = "gravity",
		["rebirths"] = 283,
		["mult"] = 41900000000000,
		["color"] = "#2338D8"
	},
	{
		["id"] = "w4_frostshrine",
		["name"] = "Frost Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 290,
		["mult"] = 134000000000000,
		["color"] = "#3FB8FF"
	},
	{
		["id"] = "w4_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 2140000000000000,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w4_abyssaltar",
		["name"] = "Abyss Altar",
		["theme"] = "void",
		["rebirths"] = 298,
		["mult"] = 429000000000000,
		["color"] = "#3BE0FF"
	}
}