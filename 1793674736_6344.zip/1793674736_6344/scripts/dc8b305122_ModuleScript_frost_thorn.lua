local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("4FE0C8")
local v_u_8 = Color3.fromHex("0B2E2A")
local v_u_9 = Color3.fromRGB(16, 32, 38)
local v_u_10 = Color3.fromRGB(214, 255, 247)
local v_u_11 = Color3.fromRGB(160, 232, 222)
local v_u_12 = Color3.fromRGB(44, 62, 72)
local v_u_13 = CFrame.Angles(0, 0.7853981633974483, 0)
local function v_u_21(p14, p15, p16, p17) -- name: placeBits
	local v18 = p16 or 1
	for _, v19 in p14 do
		local v20 = v19.off
		if v18 == 1 then
			v19.p.CFrame = p15 * v20
			if not p17 then
				continue
			end
			v19.p.Size = v19.size
		else
			v19.p.CFrame = p15 * (v20 - v20.Position + v20.Position * v18)
			v19.p.Size = v19.size * math.max(v18, 0.02)
		end
	end
end
local function v_u_27(p22, p23, p24, p25) -- name: flakes
	-- upvalues: (copy) v_u_6
	local v26 = Instance.new("ParticleEmitter")
	v26.Texture = v_u_6.Snowflake
	v26.Color = ColorSequence.new(p22)
	v26.LightEmission = 0.35
	v26.LightInfluence = 0
	v26.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p23 * 0.4), NumberSequenceKeypoint.new(0.2, p23), NumberSequenceKeypoint.new(1, p23 * 0.5) })
	v26.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.75, 0.25), NumberSequenceKeypoint.new(1, 1) })
	v26.Lifetime = NumberRange.new(p25 * 0.6, p25)
	v26.Speed = NumberRange.new(p24 * 0.4, p24)
	v26.SpreadAngle = Vector2.new(180, 180)
	v26.Rotation = NumberRange.new(0, 360)
	v26.RotSpeed = NumberRange.new(-160, 160)
	v26.Drag = 3
	v26.Acceleration = Vector3.new(0, -6, 0)
	v26.Rate = 0
	v26.Enabled = false
	return v26
end
local function v_u_35(p28, p29, p30, p31, p32) -- name: flakeBurst
	-- upvalues: (copy) v_u_3, (copy) v_u_27, (copy) v_u_1
	local v33 = Instance.new("Attachment")
	v33.WorldPosition = p28
	v33.Parent = v_u_3.Terrain
	local v34 = v_u_27(p29, p31, p32, 0.9)
	v34.Parent = v33
	v34:Emit(p30)
	v_u_1:AddItem(v33, 1.1)
end
local function v_u_80(p36, p37, p38, p39, p40) -- name: thornBits
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_9, (copy) v_u_13, (copy) v_u_10, (copy) v_u_7
	local v41 = {}
	local v42 = v_u_4.part
	local v43 = p36 * 0.62
	local v44 = v42(Vector3.new(p37, v43, p37), CFrame.identity, v_u_9, {
		["material"] = Enum.Material.SmoothPlastic
	})
	v44.Reflectance = 0.3
	local v45 = CFrame.new(0, p36 * 0.31, 0) * v_u_13
	v_u_1:AddItem(v44, p38)
	local v46 = {
		["p"] = v44,
		["off"] = v45,
		["size"] = v44.Size
	}
	table.insert(v41, v46)
	local v47 = v_u_4.part
	local v48 = p37 * 0.55
	local v49 = p36 * 0.45
	local v50 = p37 * 0.55
	local v51 = v47(Vector3.new(v48, v49, v50), CFrame.identity, v_u_10)
	local v52 = CFrame.new(0, p36 * 0.78, 0) * v_u_13
	v_u_1:AddItem(v51, p38)
	local v53 = {
		["p"] = v51,
		["off"] = v52,
		["size"] = v51.Size
	}
	table.insert(v41, v53)
	for _, v54 in { -1, 1 } do
		local v55 = {}
		local v56 = p36 * 0.03
		local v57 = Vector3.new(0, v56, 0)
		local v58 = v54 * p36 * 0.24
		local v59 = -p36 * 0.14
		local v60 = Vector3.new(v58, v59, 0)
		local v61 = v54 * p36 * 0.31
		local v62 = -p36 * 0.38
		__set_list(v55, 1, {v57, v60, (Vector3.new(v61, v62, 0))})
		for v63 = 1, p40 do
			local v64 = v55[v63]
			local v65 = v55[v63 + 1]
			local v66 = v_u_4.part
			local v67 = p37 * 0.62
			local v68 = p37 * 0.62
			local v69 = (v65 - v64).Magnitude + p37 * 0.4
			local v70 = v66(Vector3.new(v67, v68, v69), CFrame.identity, v_u_9, {
				["material"] = Enum.Material.SmoothPlastic
			})
			v70.Reflectance = 0.3
			local v71 = CFrame.lookAt((v64 + v65) / 2, v65)
			v_u_1:AddItem(v70, p38)
			local v72 = {
				["p"] = v70,
				["off"] = v71,
				["size"] = v70.Size
			}
			table.insert(v41, v72)
		end
	end
	if p39 then
		local v73 = v_u_4.part
		local v74 = p37 * 1.4
		local v75 = p36 * 0.66
		local v76 = p37 * 1.4
		local v77 = v73(Vector3.new(v74, v75, v76), CFrame.identity, v_u_7, {
			["transparency"] = 0.72
		})
		local v78 = CFrame.new(0, p36 * 0.4, 0) * v_u_13
		v_u_1:AddItem(v77, p38)
		local v79 = {
			["p"] = v77,
			["off"] = v78,
			["size"] = v77.Size
		}
		table.insert(v41, v79)
	end
	return v41
end
local function v_u_95(p81, p82, p83, p84) -- name: barbX
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_1
	local v85 = CFrame.lookAt(p81, p81 + p82)
	for v86 = 0, 3 do
		local v87 = 0.7853981633974483 + v86 * 3.141592653589793 / 2
		local v88 = math.cos(v87)
		local v89 = math.sin(v87)
		local v90 = v85:VectorToWorldSpace((Vector3.new(v88, v89, 0)))
		local v91 = CFrame.lookAt(p81, p81 + v90)
		local v92 = v_u_4.part
		local v93 = p83 * 0.35
		local v94 = v92(Vector3.new(0.42, 0.42, v93), v91 * CFrame.new(0, 0, -p83 * 0.2), v_u_9, {
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_4.tween(v94, p84, {
			["Size"] = nil,
			["CFrame"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(0.08, 0.08, p83),
			["CFrame"] = v91 * CFrame.new(0, 0, -p83 * 0.75)
		})
		v_u_1:AddItem(v94, p84 + 0.05)
	end
end
return function(p_u_96)
	-- upvalues: (copy) v_u_80, (copy) v_u_21, (copy) v_u_9, (copy) v_u_11, (copy) v_u_10, (copy) v_u_4, (copy) v_u_7, (copy) v_u_1, (copy) v_u_8, (copy) v_u_3, (copy) v_u_13, (copy) v_u_35, (copy) v_u_12, (copy) v_u_6, (copy) v_u_27, (copy) v_u_95, (copy) v_u_5
	local function v_u_119(p_u_97, p_u_98, p_u_99, p_u_100, p_u_101, p102, p103, p_u_104) -- name: growThorn
		-- upvalues: (ref) v_u_80, (copy) p_u_96, (ref) v_u_21, (ref) v_u_9, (ref) v_u_11, (ref) v_u_10
		local v_u_105 = v_u_80(p_u_98, p_u_99, p_u_100 + p_u_101 + 2, p102, p103)
		local v106 = p_u_97 * CFrame.new(0, -p_u_98 * 0.7, 0)
		for _, v107 in v_u_105 do
			local v108 = v107.off
			v107.p.CFrame = v106 * (v108 - v108.Position + v108.Position * 0.4)
			v107.p.Size = v107.size * 0.4
		end
		local v_u_109 = os.clock()
		local v_u_110 = false
		p_u_96.frame(function()
			-- upvalues: (copy) v_u_109, (copy) p_u_100, (ref) v_u_21, (copy) v_u_105, (copy) p_u_97, (copy) p_u_98, (ref) v_u_110, (copy) p_u_101, (copy) p_u_104, (ref) p_u_96, (ref) v_u_9, (ref) v_u_11, (ref) v_u_10, (copy) p_u_99
			local v111 = os.clock() - v_u_109
			if v111 < p_u_100 then
				local v112 = 1 - (1 - v111 / p_u_100) ^ 3
				v_u_21(v_u_105, p_u_97 * CFrame.new(0, -p_u_98 * 0.7 * (1 - v112), 0), 0.4 + 0.6 * v112)
				return true
			end
			if not v_u_110 then
				v_u_110 = true
				local v113 = p_u_97
				for _, v114 in v_u_105 do
					local v115 = v114.off
					v114.p.CFrame = v113 * v115
					v114.p.Size = v114.size
				end
			end
			if p_u_100 + p_u_101 > v111 then
				return true
			end
			local v116 = (p_u_97 * CFrame.new(0, p_u_98 * 0.45, 0)).Position
			for _, v117 in v_u_105 do
				v117.p:Destroy()
			end
			if p_u_104 > 0 then
				local v118 = { v_u_9, v_u_11, v_u_10 }
				p_u_96.chunks(v116, v118, p_u_104, 22, p_u_99 * 0.6, 0.55, false, 0.6)
			end
			return false
		end)
	end
	local function v_u_159(p120, p121, p_u_122) -- name: encase
		-- upvalues: (copy) p_u_96, (ref) v_u_4, (ref) v_u_11, (ref) v_u_10, (ref) v_u_9, (ref) v_u_1, (ref) v_u_3, (ref) v_u_13, (ref) v_u_35
		local v123 = p120.Y - p_u_96.FLOOR
		local v_u_124 = math.max(v123, 1.2) * 2 + 0.6
		local v125 = v_u_124 * 0.62
		local v_u_126 = math.max(v125, 2.4)
		local v_u_127 = p_u_96.ground(p120, 0)
		local v_u_128 = CFrame.Angles(0, math.random() * 3.141592653589793, 0)
		local v_u_129 = v_u_4.part(Vector3.new(v_u_126, 0.2, v_u_126), CFrame.new(v_u_127) * v_u_128, v_u_11, {
			["material"] = nil,
			["transparency"] = 0.5,
			["material"] = Enum.Material.Glass
		})
		v_u_129.Reflectance = 0.2
		local v130 = v_u_4.part
		local v131 = v_u_126 * 1.08
		local v132 = v_u_126 * 1.08
		local v_u_133 = v130(Vector3.new(v131, 0.2, v132), CFrame.new(v_u_127) * v_u_128, v_u_10, {
			["material"] = nil,
			["transparency"] = 0.8,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v_u_134 = v_u_4.part(Vector3.new(0.55, 0.2, 0.55), CFrame.new(v_u_127), v_u_9, {
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_134.Reflectance = 0.3
		for _, v135 in { v_u_129, v_u_133, v_u_134 } do
			v_u_1:AddItem(v135, p_u_122 + 2)
		end
		local v_u_136 = (CFrame.new(v_u_127) * v_u_128):VectorToWorldSpace(Vector3.new(v_u_126, 0, v_u_126) * 0.32)
		local v_u_137 = CFrame.fromAxisAngle(v_u_136.Unit:Cross(Vector3.new(0, 1, 0)), -0.2792526803190927)
		local v138 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_139
		if v138 then
			v_u_139 = v138:FindFirstChild("Foe" .. p121)
		else
			v_u_139 = nil
		end
		local v_u_140 = os.clock()
		p_u_96.runNow(function()
			-- upvalues: (copy) v_u_140, (copy) v_u_124, (copy) v_u_129, (copy) v_u_126, (copy) v_u_127, (copy) v_u_128, (copy) v_u_133, (copy) v_u_134, (copy) v_u_136, (copy) v_u_137, (ref) v_u_13, (copy) v_u_139, (copy) p_u_122, (ref) p_u_96, (ref) v_u_11, (ref) v_u_10, (ref) v_u_9, (ref) v_u_35
			local v141 = os.clock() - v_u_140
			if v141 < 0.2 then
				local v142 = v141 / 0.14
				local v143 = math.clamp(v142, 0, 1)
				local v144 = v_u_124 * (1 - (1 - v143) ^ 2)
				local v145 = math.max(v144, 0.2)
				local v146 = v_u_126
				local v147 = v_u_126
				v_u_129.Size = Vector3.new(v146, v145, v147)
				v_u_129.CFrame = CFrame.new(v_u_127 + Vector3.new(0, 1, 0) * v145 / 2) * v_u_128
				local v148 = v_u_133
				local v149 = v_u_126 * 1.08
				local v150 = v145 * 1.03
				local v151 = v_u_126 * 1.08
				v148.Size = Vector3.new(v149, v150, v151)
				v_u_133.CFrame = v_u_129.CFrame
				local v152 = v_u_124 * 1.3 * v143
				local v153 = math.max(v152, 0.2)
				v_u_134.Size = Vector3.new(0.55, v153, 0.55)
				v_u_134.CFrame = CFrame.new(v_u_127 + v_u_136) * v_u_137 * CFrame.new(0, v153 / 2, 0) * v_u_13
			end
			local v154
			if v_u_139 == nil then
				v154 = false
			else
				v154 = v_u_139.Parent == nil
			end
			if p_u_122 >= v141 and not v154 then
				return true
			end
			local v155 = v_u_127 + Vector3.new(0, 1, 0) * v_u_124 * 0.5
			v_u_129:Destroy()
			v_u_133:Destroy()
			v_u_134:Destroy()
			if not v154 then
				local v156 = p_u_96.chunks
				local v157 = { v_u_11, v_u_10, v_u_9 }
				local v158 = v_u_126 * 0.25
				v156(v155, v157, 5, 24, math.min(v158, 1.2), 0.6)
				v_u_35(v155, v_u_10, 8, 0.4, 10)
				p_u_96.glint(v155, v_u_10, v_u_124 * 0.8, 0.15)
			end
			return false
		end)
	end
	local function v_u_212(p160, p161, p_u_162) -- name: stormCloud
		-- upvalues: (copy) p_u_96, (ref) v_u_4, (ref) v_u_12, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10, (ref) v_u_27
		local v163 = p160.ability.radius
		local v_u_164 = p160.lite
		local v_u_165 = p_u_96.ground(p161, 24)
		local v166 = v_u_164 and 4 or 7
		local v_u_167 = {}
		for v168 = 1, v166 do
			local v169 = (v168 + math.random() * 0.5) / (v166 - 1) * 3.141592653589793 * 2
			local v170
			if v168 == 1 then
				v170 = Vector3.new(0, 0, 0)
			else
				local v171 = math.cos(v169)
				local v172 = math.sin(v169)
				v170 = Vector3.new(v171, 0, v172) * v163 * (0.45 + math.random() * 0.2)
			end
			local v173 = 14 + math.random() * 6
			local v174 = 3.6 + math.random() * 1.6
			local v175 = v173 * (0.8 + math.random() * 0.3)
			local v176 = Vector3.new(v173, v174, v175)
			local v177 = v_u_4.part
			local v178 = v176 * 0.3
			local v179 = CFrame.new(v_u_165 + v170)
			local v180
			if v168 % 2 == 0 then
				v180 = v_u_12
			else
				v180 = v_u_12:Lerp(v_u_8, 0.5)
			end
			local v181 = v177(v178, v179, v180, {
				["material"] = nil,
				["transparency"] = 0.1,
				["material"] = Enum.Material.SmoothPlastic
			})
			local v182 = Instance.new("SpecialMesh")
			v182.MeshType = Enum.MeshType.Sphere
			v182.Parent = v181
			v_u_1:AddItem(v181, p_u_162 + 1.5)
			table.insert(v_u_167, {
				["p"] = v181,
				["off"] = v170,
				["size"] = v176
			})
		end
		local v183 = v_u_4.part
		local v184 = v163 * 2.6
		local v185 = v163 * 2.6
		local v_u_186 = v183(Vector3.new(v184, 0.05, v185), CFrame.new(v_u_165 - Vector3.new(0, 1.4, 0)), v_u_7, {
			["transparency"] = 1
		})
		local v_u_187 = Instance.new("Decal")
		v_u_187.Face = Enum.NormalId.Bottom
		v_u_187.Texture = v_u_6.Glow
		v_u_187.Color3 = v_u_7
		v_u_187.Transparency = 0.25
		v_u_187.Parent = v_u_186
		v_u_1:AddItem(v_u_186, p_u_162 + 1.5)
		local v188 = v_u_4.part
		local v189 = v163 * 1.7
		local v190 = v163 * 1.7
		local v191 = v188(Vector3.new(v189, 0.4, v190), CFrame.new(v_u_165 - Vector3.new(0, 2, 0)), v_u_10, {
			["transparency"] = 1
		})
		local v_u_192 = v_u_27(v_u_10, 0.45, 3, 1.6)
		v_u_192.EmissionDirection = Enum.NormalId.Bottom
		v_u_192.SpreadAngle = Vector2.new(15, 15)
		v_u_192.Acceleration = Vector3.new(0, -16, 0)
		v_u_192.Drag = 0.4
		v_u_192.Rate = v_u_164 and 8 or 26
		v_u_192.Enabled = true
		v_u_192.Parent = v191
		v_u_1:AddItem(v191, p_u_162 + 2)
		task.delay(p_u_162, function()
			-- upvalues: (copy) v_u_192
			v_u_192.Enabled = false
		end)
		local v_u_193 = os.clock()
		local v_u_194 = 0.15
		p_u_96.runNow(function()
			-- upvalues: (copy) v_u_193, (copy) p_u_162, (copy) v_u_167, (copy) v_u_165, (copy) v_u_187, (copy) v_u_164, (ref) v_u_194, (ref) p_u_96, (ref) v_u_10, (copy) v_u_186
			local v195 = os.clock() - v_u_193
			local v196 = v195 / 0.3
			local v197 = 1 - (1 - math.min(v196, 1)) ^ 3
			local v198 = (v195 - p_u_162) / 0.5
			local v199 = math.clamp(v198, 0, 1)
			local v200 = CFrame.Angles(0, v195 * 0.25, 0)
			for v201, v202 in v_u_167 do
				v202.p.Size = v202.size * (v197 * 0.7 + 0.3)
				local v203 = v202.p
				local v204 = CFrame.new
				local v205 = v_u_165 + v200:VectorToWorldSpace(v202.off)
				local v206 = v195 * 1.3 + v201
				v203.CFrame = v204(v205 + Vector3.new(0, 1, 0) * math.sin(v206) * 0.4)
				v202.p.Transparency = v199 * 0.9 + 0.1
			end
			local v207 = v_u_187
			local v208 = 1 - v197
			v207.Transparency = math.max(v199, v208) * 0.75 + 0.25
			if not v_u_164 and (v_u_194 <= v195 and (v199 == 0 and #v_u_167 > 2)) then
				v_u_194 = v195 + 0.18 + math.random() * 0.12
				local v209 = v_u_167[math.random(1, #v_u_167)].p.Position
				local v210 = v_u_167[math.random(1, #v_u_167)].p.Position
				if (v209 - v210).Magnitude > 3 then
					p_u_96.drawPath(p_u_96.boltPath(v209 - Vector3.new(0, 1.5, 0), v210 - Vector3.new(0, 1.5, 0), 1.2, 3), 0.28, v_u_10, 0.1)
				end
			end
			if v199 < 1 then
				return true
			end
			for _, v211 in v_u_167 do
				v211.p:Destroy()
			end
			v_u_186:Destroy()
			return false
		end)
	end
	local function v_u_225(p213, p214) -- name: hailShot
		-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (copy) p_u_96
		local v215 = p213.size
		local v216 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p214, v_u_10, {
			["transparency"] = 1
		})
		local v217 = {}
		for v218 = 1, p213.lite and 1 or 2 do
			local v219 = v_u_4.part
			local v220 = Vector3.new(1, 1, 1) * (v218 == 1 and 3.8 or 3.2) * v215
			local v221
			if v218 == 1 then
				v221 = v_u_11
			else
				v221 = v_u_10
			end
			local v222 = {
				["p"] = v219(v220, p214, v221, {
					["material"] = nil,
					["transparency"] = 0.08,
					["material"] = Enum.Material.Ice
				}),
				["off"] = CFrame.Angles(math.random() * 3, math.random() * 3, math.random() * 3)
			}
			table.insert(v217, v222)
		end
		local v223 = {
			["p"] = v_u_4.part(Vector3.new(2.6, 2.6, 2.6) * v215, p214, v_u_7, {
				["shape"] = Enum.PartType.Ball
			}),
			["off"] = CFrame.identity
		}
		table.insert(v217, v223)
		if not p213.lite then
			local v224 = {
				["p"] = v_u_4.part(Vector3.new(5.8, 5.8, 5.8) * v215, p214, v_u_10, {
					["shape"] = nil,
					["transparency"] = 0.78,
					["shape"] = Enum.PartType.Ball
				}),
				["off"] = CFrame.identity
			}
			table.insert(v217, v224)
		end
		p_u_96.streak(v216, v_u_10, v_u_7, 3.4 * v215, 0.2)
		return p_u_96.assemble(v216, v217, {}, 0, 0, {}, 0.2, 7)
	end
	local v_u_226 = {}
	local v329 = {
		["frost_thorn_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["keep"] = 0.1,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p227) -- name: cast
				-- upvalues: (copy) p_u_96, (ref) v_u_7, (ref) v_u_95
				p_u_96.muzzle(p227, v_u_7, 0.9)
				if not p227.lite then
					v_u_95(p227.eye + p227.dir * 1.3, p227.dir, 2.2, 0.12)
				end
			end,
			["shot"] = function(p228, p229) -- name: thornShot
				-- upvalues: (ref) v_u_80, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (copy) p_u_96, (ref) v_u_8
				local v230 = p228.size
				local v231 = 3.3 * v230
				local v_u_232 = v_u_80(v231, 0.5 * v230, 6, not p228.lite, p228.lite and 1 or 2)
				local v_u_233 = CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.new(0, -v231 * 0.35, 0)
				local v_u_234 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p229, v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_234, 6)
				p_u_96.streak(v_u_234, v_u_7, v_u_8, 1.1 * v230, 0.14)
				if p228.mine then
					p_u_96.light(v_u_234, v_u_7, 9 * v230)
				end
				local v_u_235 = false
				return {
					["place"] = function(p236, p237) -- name: place
						-- upvalues: (copy) v_u_234, (copy) v_u_232, (copy) v_u_233
						v_u_234.CFrame = p236
						local v238 = v_u_232
						local v239 = p236 * CFrame.Angles(0, 0, p237 * 9) * v_u_233
						for _, v240 in v238 do
							local v241 = v240.off
							v240.p.CFrame = v239 * v241
						end
					end,
					["stop"] = function(p242) -- name: stop
						-- upvalues: (ref) v_u_235, (copy) v_u_234, (ref) v_u_1, (copy) v_u_232, (ref) p_u_96
						if not v_u_235 then
							v_u_235 = true
							local v243 = v_u_234:FindFirstChildWhichIsA("PointLight")
							if v243 then
								v243:Destroy()
							end
							v_u_1:AddItem(v_u_234, 0.2)
							for _, v244 in v_u_232 do
								if p242 then
									p_u_96.fadeOut(v244.p, p242)
								else
									v244.p:Destroy()
								end
							end
						end
					end
				}
			end,
			["impact"] = function(p245, p246) -- name: impact
				-- upvalues: (copy) p_u_96, (ref) v_u_7, (ref) v_u_10, (ref) v_u_95, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6, (ref) v_u_35, (ref) v_u_11, (ref) v_u_9
				local v247 = p245.size
				p_u_96.burst("Impact", p246, v_u_7, 0.9 * v247)
				p_u_96.pop(p246, v_u_10, 1.2 * v247, 4.6 * v247, 0.14, 0.25)
				local v248 = v_u_95
				local v249 = v_u_3.CurrentCamera
				local v250
				if v249 then
					local v251 = v249.CFrame.Position - p246
					v250 = v251.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v251.Unit
				else
					v250 = Vector3.new(0, 1, 0)
				end
				v248(p246, v250, 5 * v247, 0.16)
				p_u_96.spikes(p246, v_u_7, p245.lite and 2 or 4, 3.6 * v247, 0.13)
				v_u_4.ring(p_u_96.ground(p246), v_u_7, 5 * v247, 0.25, v_u_6.Ring)
				if not p245.lite then
					v_u_35(p246, v_u_10, 7, 0.32 * v247, 10 * v247)
					local v252 = { v_u_11, v_u_9, v_u_10 }
					p_u_96.chunks(p246, v252, 3, 22, 0.4 * v247, 0.5, false, 0.7)
				end
				p_u_96.hitSound(p246)
			end,
			["hit"] = function(_, p253, _) -- name: hit
				-- upvalues: (copy) p_u_96, (ref) v_u_7
				p_u_96.burst("Impact", p253, v_u_7, 0.6)
			end
		},
		["frost_thorn_e"] = {
			["cast"] = function(p254) -- name: cast
				-- upvalues: (copy) p_u_96, (ref) v_u_7, (ref) v_u_95, (ref) v_u_35, (ref) v_u_10
				p_u_96.skillCast(p254, v_u_7)
				v_u_95(p254.eye + p254.dir * 1.4, p254.dir, 3.2, 0.18)
				if not p254.lite then
					v_u_35(p254.eye + p254.dir, v_u_10, 6, 0.3, 8)
				end
			end,
			["windup"] = function(p255, p256, p257) -- name: windup
				-- upvalues: (copy) p_u_96, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_10
				local v258 = p255.ability.radius
				local v259 = p255.ability.freeze or 2.5
				local v260 = p_u_96.ground(p256)
				v_u_4.ring(v260, v_u_7, v258, p257 + 0.2, v_u_6.Ring)
				p_u_96.mark(p256, v_u_8, v258 * 0.85, p257 + v259, v_u_6.CrackLines, 0.05)
				p_u_96.sigil(CFrame.new(p_u_96.ground(p256, 0.14)), v258, v_u_10, v_u_6.Ring, p257 + v259, 0.25)
				if not p255.lite then
					p_u_96.inward(p_u_96.ground(p256, 1), v_u_10, 6, v258, p257 + 0.06)
				end
			end,
			["land"] = function(p261, p262) -- name: land
				-- upvalues: (copy) p_u_96, (copy) v_u_119, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_35, (ref) v_u_10, (ref) v_u_5
				local v263 = p261.ability.radius
				local v264 = p261.ability.freeze or 2.5
				local v_u_265 = p261.lite
				local v266 = p_u_96.ground(p262, 0)
				local v267 = p_u_96.flatUnit(p261.dir)
				local v_u_268 = v_u_265 and 9 or 11
				for v269 = 0, 3 do
					local v270 = CFrame.Angles(0, 0.7853981633974483 + v269 * 3.141592653589793 / 2, 0):VectorToWorldSpace(v267)
					local v271 = v266 + v270 * v263 * 0.72
					local v_u_272 = CFrame.lookAt(v271 + Vector3.new(0, 1, 0) * v_u_268 * 0.16, v271 + Vector3.new(0, 1, 0) * v_u_268 * 0.16 + v270) * CFrame.Angles(0.6981317007977318, 0, 0)
					v_u_119(v_u_272, v_u_268, 1.6, 0.13, v264, not v_u_265, 2, v_u_265 and 0 or 5)
					v_u_4.ring(p_u_96.ground(v271), v_u_7, 4, 0.3, v_u_6.Shockwave)
					p_u_96.after(v264 + 0.13, function()
						-- upvalues: (copy) v_u_272, (copy) v_u_268, (copy) v_u_265, (ref) v_u_35, (ref) v_u_10, (ref) p_u_96
						local v273 = (v_u_272 * CFrame.new(0, v_u_268 * 0.5, 0)).Position
						if not v_u_265 then
							v_u_35(v273, v_u_10, 8, 0.45, 12)
						end
						p_u_96.glint(v273, v_u_10, 6, 0.16)
					end)
				end
				local v274 = v_u_265 and 3 or 7
				for v275 = 1, v274 do
					local v276 = (v275 + math.random() * 0.6) / v274 * 3.141592653589793 * 2
					local v277 = math.cos(v276)
					local v278 = math.sin(v276)
					local v279 = Vector3.new(v277, 0, v278)
					local v280 = v266 + v279 * v263 * (0.25 + math.random() * 0.5)
					local v_u_281 = 3.8 + math.random() * 2.6
					local v282 = CFrame.lookAt(v280 + Vector3.new(0, 1, 0) * v_u_281 * 0.12, v280 + Vector3.new(0, 1, 0) * v_u_281 * 0.12 + v279)
					local v283 = CFrame.Angles
					local v284 = 14 + math.random() * 16
					local v_u_285 = v282 * v283(-math.rad(v284), 0, 0)
					p_u_96.after(math.random() * 0.08, function()
						-- upvalues: (ref) v_u_119, (copy) v_u_285, (copy) v_u_281, (copy) v_u_265
						v_u_119(v_u_285, v_u_281, 0.75, 0.1, 0.7 + math.random() * 0.4, false, v_u_265 and 0 or 1, v_u_265 and 0 or 2)
					end)
				end
				p_u_96.burst("Shockwave", v266 + Vector3.new(0, 0.3, 0), v_u_7, v263 / 20)
				v_u_4.ring(v266, v_u_10, v263 * 0.95, 0.4, v_u_6.SpeedLines)
				p_u_96.pop(p_u_96.ground(p262, 1.5), v_u_10, 3, v263 * 0.9, 0.3, 0.6)
				p_u_96.mark(p262, v_u_7, v263 * 0.6, 1.6, v_u_6.CrackGlow, 0.3)
				if not v_u_265 then
					v_u_35(p_u_96.ground(p262, 2), v_u_10, 20, 0.5, 18)
					p_u_96.burst("Smoke", p_u_96.ground(p262, 1), nil, 1.1)
				end
				v_u_5.play("Burst", {
					["at"] = v266,
					["volume"] = p261.mine and 0.7 or 0.4
				})
				if p261.mine then
					v_u_4.shake(0.25, 0.25)
				end
			end,
			["hit"] = function(p_u_286, p287, p288) -- name: hit
				-- upvalues: (copy) p_u_96, (ref) v_u_7, (copy) v_u_226, (ref) v_u_10, (copy) v_u_159
				local v289 = p_u_286.ability.freeze or 2.5
				p_u_96.burst("Impact", p287, v_u_7, 0.8)
				local v290 = (v_u_226[p_u_286] or 0) + 1
				v_u_226[p_u_286] = v290
				if v290 == 1 then
					task.delay(v289 + 1, function()
						-- upvalues: (ref) v_u_226, (copy) p_u_286
						v_u_226[p_u_286] = nil
					end)
				end
				if v290 > 10 then
					p_u_96.glint(p287, v_u_10, 4, 0.15)
				else
					v_u_159(p287, p288, v289)
				end
			end
		},
		["frost_thorn_r"] = {
			["cast"] = function(p291) -- name: cast
				-- upvalues: (copy) p_u_96, (ref) v_u_7, (ref) v_u_10, (ref) v_u_95
				p_u_96.skillCast(p291, v_u_7, true)
				p_u_96.burst("Flash", p291.eye, v_u_10, 0.4)
				v_u_95(p291.eye + p291.dir * 1.5, p291.dir, 4, 0.2)
				p_u_96.thin(p_u_96.rod(p291.eye, p291.eye + Vector3.new(0, 30, 0), 0.9, v_u_7, 0.15), 0.35)
				p_u_96.thin(p_u_96.rod(p291.eye, p291.eye + Vector3.new(0, 30, 0), 0.3, v_u_10), 0.3)
			end,
			["windup"] = function(p292, p293, p294) -- name: windup
				-- upvalues: (copy) v_u_212, (copy) p_u_96, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10, (ref) v_u_4
				local v295 = p292.ability.radius
				local v296 = p294 + 0.4
				v_u_212(p292, p293, v296)
				p_u_96.sigil(CFrame.new(p_u_96.ground(p293, 0.12)), v295, v_u_7, v_u_6.Ring, v296, 0.3)
				p_u_96.mark(p293, v_u_10, v295 * 0.9, v296 + 0.8, v_u_6.CrackLines, 0.45)
				v_u_4.ring(p_u_96.ground(p293), v_u_10, v295, 0.5, v_u_6.Ring)
				if not p292.lite then
					for _ = 1, 12 do
						local v297 = math.random() * 3.141592653589793 * 2
						local v298 = math.random()
						local v299 = v295 * math.sqrt(v298)
						local v300 = p_u_96.ground
						local v301 = math.cos(v297) * v299
						local v302 = math.sin(v297) * v299
						local v_u_303 = v300(p293 + Vector3.new(v301, 0, v302))
						local v304 = p_u_96.after
						local v305 = math.random()
						local v306 = p294 - 0.2
						v304(0.2 + v305 * math.max(v306, 0.1), function()
							-- upvalues: (copy) v_u_303, (ref) p_u_96, (ref) v_u_10
							local v_u_307 = v_u_303 + Vector3.new(0, 22, 0)
							local v_u_308 = p_u_96.ball(v_u_307, v_u_10, 0.55, 0)
							p_u_96.animate(0.24, 0, function(p309)
								-- upvalues: (copy) v_u_308, (copy) v_u_307, (ref) v_u_303, (ref) p_u_96, (ref) v_u_10
								v_u_308.CFrame = CFrame.new(v_u_307:Lerp(v_u_303 + Vector3.new(0, 0.3, 0), p309 * p309))
								if p309 >= 1 then
									v_u_308:Destroy()
									p_u_96.burst("Impact", v_u_303 + Vector3.new(0, 0.4, 0), v_u_10, 0.35)
								end
							end)
						end)
					end
				end
				if p292.mine then
					v_u_4.shake(0.15, 0.2)
				end
			end,
			["strike"] = function(p_u_310, p_u_311, p312) -- name: strike
				-- upvalues: (copy) p_u_96, (copy) v_u_225, (ref) v_u_7, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (copy) v_u_119, (ref) v_u_35, (ref) v_u_5
				local v_u_313 = p_u_310.ability.strikeRadius or 8
				local v_u_314 = p_u_310.lite
				local v315 = p_u_96.ground(p_u_311, 1.6)
				local v316 = p_u_96.ground(p_u_311, 22) - p_u_96.flatUnit(p_u_311 - p_u_310.target) * 5
				p_u_96.drop(p_u_310, v_u_225, v316, v315, 0.32, p312, 0.3, function(p317)
					-- upvalues: (ref) p_u_96, (copy) p_u_311, (ref) v_u_7, (copy) v_u_313, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (copy) v_u_314, (ref) v_u_119, (ref) v_u_35, (ref) v_u_5, (copy) p_u_310
					local v318 = p_u_96.ground(p_u_311, 0)
					p_u_96.burst("Shockwave", p_u_96.ground(p_u_311, 0.3), v_u_7, v_u_313 / 16)
					p_u_96.burst("Impact", p_u_96.ground(p_u_311, 1.2), v_u_7, 1.4)
					v_u_4.ring(v318, v_u_7, v_u_313, 0.35)
					v_u_4.flash(p_u_96.ground(p_u_311, 2), v_u_10, 8, 0.15)
					p_u_96.mark(p_u_311, v_u_8, v_u_313 * 0.7, 1.4, v_u_6.CrackLines, 0.05)
					p_u_96.mark(p_u_311, v_u_7, v_u_313 * 0.45, 1, v_u_6.CrackGlow, 0.2)
					p_u_96.chunks(p_u_96.ground(p_u_311, 0.8), { v_u_11, v_u_10, v_u_9 }, v_u_314 and 2 or 5, 30, 0.8, 0.8)
					local v319 = v_u_314 and 2 or 4
					local v320 = math.random() * 3.141592653589793 * 2
					for v321 = 1, v319 do
						local v322 = v320 + v321 / v319 * 3.141592653589793 * 2
						local v323 = math.cos(v322)
						local v324 = math.sin(v322)
						local v325 = Vector3.new(v323, 0, v324)
						local v326 = v318 + v325 * 2.4
						local v327 = 3.4 + math.random() * 1.4
						v_u_119(CFrame.lookAt(v326 + Vector3.new(0, 1, 0) * v327 * 0.1, v326 + Vector3.new(0, 1, 0) * v327 * 0.1 + v325) * CFrame.Angles(-0.5585053606381855, 0, 0), v327, 0.62, 0.08, 0.4, false, v_u_314 and 0 or 1, 0)
					end
					if not v_u_314 then
						v_u_35(p_u_96.ground(p_u_311, 1.5), v_u_10, 10, 0.45, 14)
					end
					v_u_5.play("Explosion", {
						["at"] = p317,
						["volume"] = p_u_310.mine and 0.55 or 0.3
					})
					v_u_5.play("Hit", {
						["at"] = nil,
						["volume"] = 0.5,
						["at"] = p317
					})
					if p_u_310.mine then
						v_u_4.shake(0.28, 0.2)
					end
				end)
			end,
			["hit"] = function(_, p328, _) -- name: hit
				-- upvalues: (copy) p_u_96, (ref) v_u_7
				p_u_96.burst("Impact", p328, v_u_7, 0.9)
			end
		}
	}
	return v329
end