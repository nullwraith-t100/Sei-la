local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.Config.Pets)
local v_u_3 = require(v_u_1.Shared.Config.Eyes)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = require(script.Parent.Perf)
require(script.Parent.PetKit)
local v6 = require(script.Parent.PetModelsW8)
local v_u_7 = {}
local v_u_8 = Vector3.new
local v_u_9 = CFrame.new
local v_u_10 = CFrame.Angles
local v_u_11 = Enum.Material.SmoothPlastic
local v_u_12 = Enum.Material.Neon
local v_u_13 = Color3.fromRGB(26, 22, 32)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Color3.fromRGB(255, 128, 160)
local v_u_16 = Color3.fromRGB(255, 150, 180)
local v_u_17 = Color3.fromRGB(255, 96, 130)
local v_u_18 = Color3.fromRGB(255, 196, 52)
local v_u_19 = Color3.fromRGB(255, 226, 110)
local v_u_20 = Color3.fromRGB(196, 206, 220)
local v_u_21 = Color3.fromRGB(60, 60, 74)
local v_u_22 = Color3.fromRGB(245, 184, 65)
local v_u_23 = Color3.fromRGB(255, 45, 85)
local v_u_24 = Color3.fromRGB(60, 165, 255)
local v_u_25 = Color3.fromRGB(112, 196, 72)
local v_u_26 = Color3.fromRGB(70, 140, 50)
local v_u_27 = Color3.fromRGB(80, 225, 95)
local v_u_28 = Color3.fromRGB(110, 66, 38)
local v_u_29 = Color3.fromRGB(60, 42, 32)
local v_u_30 = Color3.fromRGB(255, 120, 40)
local v_u_31 = Color3.fromRGB(245, 234, 205)
local v_u_32 = Color3.fromRGB(58, 32, 24)
local v_u_33 = Color3.fromRGB(255, 214, 60)
local v_u_34 = Color3.fromRGB(255, 60, 20)
local v_u_35 = Color3.fromRGB(230, 40, 60)
local v_u_36 = Color3.fromRGB(255, 160, 205)
local v_u_37 = Color3.fromRGB(255, 242, 214)
local v_u_38 = Color3.fromRGB(46, 30, 40)
local v_u_39 = Color3.fromRGB(205, 240, 255)
local v_u_40 = Color3.fromRGB(78, 66, 84)
local v_u_41 = Color3.fromRGB(232, 24, 48)
local v_u_42 = Color3.fromRGB(38, 22, 30)
local v_u_43 = Color3.fromRGB(34, 24, 28)
local v_u_44 = Color3.fromRGB(26, 12, 20)
local v_u_45 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 95, 170)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 170, 60)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(255, 240, 90)),
	ColorSequenceKeypoint.new(0.6, Color3.fromRGB(90, 255, 150)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(80, 200, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(185, 110, 255))
})
local v_u_46 = {
	["Common"] = 1,
	["Rare"] = 2,
	["Epic"] = 3,
	["Legendary"] = 4,
	["Mythic"] = 5
}
local v_u_47 = {
	["quad"] = { 0.45, 10 },
	["toad"] = { 0.9, 6.5 },
	["penguin"] = { 0.28, 11 },
	["spider"] = { 0.12, 16 },
	["slime"] = { 0.7, 7 }
}
local function v_u_49(p48) -- name: hex
	return Color3.fromHex(p48)
end
local function v_u_62(p50, p51, p52) -- name: newBuilder
	local v53 = Instance.new("Model")
	v53.Name = p51
	local v54 = {
		["name"] = "Body",
		["hinge"] = Vector3.new(0, 0, 0),
		["anim"] = "",
		["phase"] = 0,
		["side"] = 0,
		["parts"] = nil,
		["parts"] = {}
	}
	local v55 = {
		["model"] = nil,
		["kind"] = "",
		["s"] = nil,
		["look"] = nil,
		["bones"] = nil,
		["byName"] = nil,
		["cur"] = nil,
		["body"] = nil,
		["accent"] = nil,
		["belly"] = nil,
		["limbs"] = nil,
		["glow"] = nil,
		["cloth"] = nil,
		["headC"] = Vector3.new(0, 0, 0),
		["headS"] = Vector3.new(1, 1, 1),
		["face"] = 0,
		["eyeX"] = 0.5,
		["eyeY"] = 2.4,
		["mouthY"] = 1.9,
		["bandY"] = 2.9,
		["plateW"] = 0.95,
		["neck"] = Vector3.new(0, 0, 0),
		["back"] = Vector3.new(0, 0, 0),
		["tailAt"] = Vector3.new(0, 0, 0),
		["bodyC"] = Vector3.new(0, 0, 0),
		["bodyS"] = Vector3.new(0, 0, 0),
		["model"] = v53,
		["s"] = p52,
		["look"] = p50,
		["bones"] = { v54 },
		["byName"] = {
			["Body"] = v54
		},
		["cur"] = v54
	}
	local v56 = p50.body
	v55.body = Color3.fromHex(v56)
	local v57 = p50.accent
	v55.accent = Color3.fromHex(v57)
	local v58 = p50.belly or p50.accent
	v55.belly = Color3.fromHex(v58)
	local v59 = p50.limbs or p50.body
	v55.limbs = Color3.fromHex(v59)
	local v60 = p50.glow or p50.accent
	v55.glow = Color3.fromHex(v60)
	local v61 = p50.cloth or "#E5322D"
	v55.cloth = Color3.fromHex(v61)
	return v55
end
local function v_u_72(p63, p64, p65, p66, p67, p68, p69) -- name: bone
	local v70 = {
		["name"] = p64,
		["parent"] = p65,
		["hinge"] = p66,
		["anim"] = p67,
		["phase"] = p68 or 0,
		["side"] = p69 or 0,
		["parts"] = {}
	}
	local v71 = p63.bones
	table.insert(v71, v70)
	p63.byName[p64] = v70
	p63.cur = v70
end
local function v_u_80(p73, p74, p75, p76, p77, p78) -- name: put
	-- upvalues: (copy) v_u_11
	p74.Size = p75 * p73.s
	p74.CFrame = p76.Rotation + p76.Position * p73.s
	p74.Color = p77
	p74.Material = p78 or v_u_11
	p74.Anchored = true
	p74.CanCollide = false
	p74.CanQuery = false
	p74.CanTouch = false
	p74.CastShadow = false
	p74.Massless = true
	p74.TopSurface = Enum.SurfaceType.Smooth
	p74.BottomSurface = Enum.SurfaceType.Smooth
	p74.Parent = p73.model
	local v79 = p73.cur.parts
	table.insert(v79, p74)
end
local function v_u_93(p81, p82, p83, p84, p85, p86, p87) -- name: tri
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	local v88 = -p83.Unit
	local v89 = p84.Unit
	local v90 = CFrame.fromMatrix(p82 + p83 / 2 + p84 / 2, v89:Cross(v88), v89, v88)
	local v91 = v_u_8(p85, p84.Magnitude, p83.Magnitude)
	local v92 = Instance.new("WedgePart")
	v_u_80(p81, v92, v91, v90, p86, p87)
	return v92
end
local function v_u_124(p94, p95, p96, p97, p98, p99, p100) -- name: tri3
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	local v101 = p96 - p95
	local v102 = p97 - p95
	local v103 = p97 - p96
	local v104 = v101:Dot(v101)
	local v105 = v102:Dot(v102)
	local v106 = v103:Dot(v103)
	if v105 < v104 and v106 < v104 then
		local v107 = p97
		p97 = p95
		p95 = p96
		p96 = v107
	elseif v106 < v105 then
		if v104 >= v105 then
			local v108 = p96
			p96 = p95
			p95 = v108
		end
	else
		local v109 = p96
		p96 = p95
		p95 = v109
	end
	local v110 = p95 - p96
	local v111 = p97 - p96
	local v112 = p97 - p95
	local v113 = v111:Cross(v110).Unit
	local v114 = v112:Cross(v113).Unit
	local v115 = v112.Unit
	local v116 = v110:Dot(v114)
	local v117 = math.abs(v116)
	local v118 = v110:Dot(v115)
	local v119 = v_u_8(p98, v117, (math.abs(v118)))
	local v120 = CFrame.fromMatrix((p96 + p95) / 2, v113, v114, v115)
	v_u_80(p94, Instance.new("WedgePart"), v119, v120, p99, p100)
	local v121 = v111:Dot(v115)
	local v122 = v_u_8(p98, v117, (math.abs(v121)))
	local v123 = CFrame.fromMatrix((p96 + p97) / 2, -v113, v114, -v115)
	v_u_80(p94, Instance.new("WedgePart"), v122, v123, p99, p100)
end
local function v_u_162(p125, p126, p127, p128) -- name: eyes
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_80, (copy) v_u_13, (copy) v_u_14
	local v129 = p125.look
	local v130 = p125.face
	for v131 = -1, 1, 2 do
		local v132 = v131 * p125.eyeX
		local v133 = p125.eyeY
		if v129.eye then
			local v134 = v_u_8(p126, p127, 0.08)
			local v135 = v_u_9(v132, v133, v130 - 0.03)
			local v136 = v129.eye
			local v137 = Color3.fromHex(v136)
			local v138 = v_u_12
			v_u_80(p125, Instance.new("Part"), v134, v135, v137, v138)
			if p128 then
				local v139 = v_u_8(p126 * 0.72, p127 * 0.26, 0.06)
				local v140 = v_u_9(v132, v133, v130 - 0.08)
				local v141 = v_u_13
				v_u_80(p125, Instance.new("Part"), v139, v140, v141, nil)
			else
				local v142 = v_u_8(p126 * 0.3, p127 * 0.78, 0.06)
				local v143 = v_u_9(v132, v133, v130 - 0.08)
				local v144 = v_u_13
				v_u_80(p125, Instance.new("Part"), v142, v143, v144, nil)
			end
			local v145 = v_u_8(p126 * 0.26, p126 * 0.26, 0.05)
			local v146 = v_u_9(v132 + p126 * 0.24, v133 + p127 * 0.26, v130 - 0.11)
			local v147 = v_u_14
			v_u_80(p125, Instance.new("Part"), v145, v146, v147, nil)
		else
			local v148 = v129.gear
			local v149
			if v148 == nil then
				v149 = false
			else
				v149 = table.find(v148, "patches") ~= nil
			end
			if v149 then
				local v150 = v_u_8(p126 + 0.12, p127 + 0.12, 0.06)
				local v151 = v_u_9(v132, v133, v130 - 0.02)
				local v152 = v_u_14
				v_u_80(p125, Instance.new("Part"), v150, v151, v152, nil)
			end
			local v153 = v_u_8(p126, p127, 0.08)
			local v154 = v_u_9(v132, v133, v130 - 0.04)
			local v155 = v_u_13
			v_u_80(p125, Instance.new("Part"), v153, v154, v155, nil)
			local v156 = v_u_8(p126 * 0.42, p126 * 0.42, 0.05)
			local v157 = v_u_9(v132 + p126 * 0.18, v133 + p127 * 0.2, v130 - 0.09)
			local v158 = v_u_14
			v_u_80(p125, Instance.new("Part"), v156, v157, v158, nil)
			local v159 = v_u_8(p126 * 0.2, p126 * 0.2, 0.05)
			local v160 = v_u_9(v132 - p126 * 0.2, v133 - p127 * 0.24, v130 - 0.09)
			local v161 = v_u_14
			v_u_80(p125, Instance.new("Part"), v159, v160, v161, nil)
		end
	end
end
local function v_u_167(p163) -- name: cheeks
	-- upvalues: (copy) v_u_9, (copy) v_u_15, (copy) v_u_80
	if not p163.look.eye then
		for v164 = -1, 1, 2 do
			local v165 = v_u_9(v164 * (p163.eyeX + 0.33), p163.eyeY - 0.4, p163.face - 0.03)
			local v166 = v_u_15
			v_u_80(p163, Instance.new("Part"), Vector3.new(0.34, 0.16, 0.06), v165, v166, nil)
		end
	end
end
local function v_u_184(p168) -- name: muzzle
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_13, (copy) v_u_16
	local v169 = p168.face
	local v170 = p168.mouthY
	local v171 = p168.look.ears
	if v171 == "fox" or (v171 == "long" or v171 == "arctic") then
		local v172 = v_u_9(0, v170, v169 - 0.26)
		local v173 = p168.belly
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.9, 0.5, 0.55), v172, v173, nil)
		local v174 = v_u_9(0, v170 + 0.16, v169 - 0.58)
		local v175 = v_u_13
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.3, 0.2, 0.12), v174, v175, nil)
		return
	elseif v171 == "bunny" then
		local v176 = v_u_9(0, v170, v169 - 0.09)
		local v177 = p168.belly
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.62, 0.4, 0.2), v176, v177, nil)
		local v178 = v_u_9(0, v170 + 0.12, v169 - 0.22)
		local v179 = v_u_16
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.22, 0.14, 0.08), v178, v179, nil)
	else
		local v180 = v_u_9(0, v170, v169 - 0.15)
		local v181 = p168.belly
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.95, 0.55, 0.32), v180, v181, nil)
		local v182 = v_u_9(0, v170 + 0.15, v169 - 0.35)
		local v183 = v_u_13
		v_u_80(p168, Instance.new("Part"), Vector3.new(0.34, 0.2, 0.12), v182, v183, nil)
	end
end
local v_u_185 = {
	["dog"] = { 0.78, 0.9, 0.08 },
	["cat"] = { 0.74, 0.78, 0.14 },
	["fox"] = { 0.86, 1.15, 0.1 },
	["long"] = { 0.8, 1.65, 0.16 },
	["arctic"] = { 0.86, 1.05, 0.14 }
}
local function v_u_216(p186) -- name: ears
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_80, (copy) v_u_12, (copy) v_u_185, (copy) v_u_93, (copy) v_u_16, (copy) v_u_32
	local v187 = p186.look.ears
	if v187 ~= "none" then
		local v188 = p186.headC.Y + p186.headS.Y / 2
		local v189 = p186.headC.Z
		for v190 = -1, 1, 2 do
			local v191 = v190 < 0 and "EarL" or "EarR"
			if v187 == "bunny" then
				v_u_72(p186, v191, "Head", v_u_8(v190 * 0.5, v188, v189 - 0.1), "ear", v190 * 1.3, v190)
				local v192 = v_u_9(v190 * 0.52, v188 + 0.72, v189 - 0.1) * v_u_10(0, 0, -v190 * 0.14)
				local v193 = p186.body
				v_u_80(p186, Instance.new("Part"), Vector3.new(0.46, 1.6, 0.32), v192, v193, nil)
				local v194 = v192 * v_u_9(0, -0.05, -0.17)
				local v195 = p186.glow
				local v196
				if p186.look.glow then
					v196 = v_u_12
				else
					v196 = nil
				end
				v_u_80(p186, Instance.new("Part"), Vector3.new(0.26, 1.15, 0.06), v194, v195, v196)
			elseif v187 == "round" then
				v_u_72(p186, v191, "Head", v_u_8(v190 * 0.82, v188, v189), "ear", v190 * 1.3, v190)
				local v197 = v_u_9(v190 * 0.82, v188 + 0.1, v189 + 0.05) * v_u_10(0, 1.5707963267948966, 0)
				local v198 = p186.limbs
				local v199 = Instance.new("Part")
				v199.Shape = Enum.PartType.Cylinder
				v_u_80(p186, v199, Vector3.new(0.32, 0.82, 0.82), v197, v198, nil)
			else
				local v200 = v_u_185[v187] or v_u_185.dog
				local v201 = v200[1]
				local v202 = v200[2]
				local v203 = v200[3]
				local v204 = v_u_8(v190 * (p186.headS.X / 2 - 0.1), v188 - 0.06, v189 - 0.25)
				local v205 = v_u_8(-v190 * v201, 0, 0)
				local v206 = -v190 * v203
				local v207 = math.cos(v206)
				local v208 = math.sin(v206)
				local v209 = v_u_8(v205.X * v207 - v205.Y * v208, v205.X * v208 + v205.Y * v207, v205.Z)
				local v210 = v_u_8(0, v202, 0)
				local v211 = -v190 * v203
				local v212 = math.cos(v211)
				local v213 = math.sin(v211)
				local v214 = v_u_8(v210.X * v212 - v210.Y * v213, v210.X * v213 + v210.Y * v212, v210.Z)
				v_u_72(p186, v191, "Head", v204 + v209 / 2, "ear", v190 * 1.3, v190)
				v_u_93(p186, v204, v209, v214, 0.32, p186.limbs)
				local v215
				if v187 == "cat" then
					v215 = v_u_16
				else
					v215 = p186.accent
				end
				v_u_93(p186, v204 + v209 * 0.12 + v214 * 0.06 + Vector3.new(0, 0, -0.05), v209 * 0.62, v214 * 0.62, 0.3, v215)
				if v187 ~= "fox" then
					continue
				end
				v_u_93(p186, v204 + v214 * 0.68, v209 * 0.32, v214 * 0.32, 0.34, v_u_32)
			end
		end
	end
end
local function v_u_273(p217) -- name: tails
	-- upvalues: (copy) v_u_12, (copy) v_u_72, (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_10
	local v218 = p217.look
	local v219 = v218.tails
	if v219 > 0 then
		local v220 = v218.tail or ((v218.ears == "fox" or v218.ears == "long") and "fluffy" or (v218.ears == "bunny" and "puff" or "thin"))
		local v221 = p217.tailAt
		local v222
		if v218.tip then
			local v223 = v218.tip
			v222 = Color3.fromHex(v223)
		else
			v222 = p217.accent
		end
		local v224
		if v218.tip then
			v224 = v_u_12
		else
			v224 = nil
		end
		for v225 = 1, v219 do
			local v226 = v219 == 1 and 0 or (v225 - (v219 + 1) / 2) / ((v219 - 1) / 2)
			v_u_72(p217, "Tail" .. v225, "Body", v221, "tail", v225 * 0.7)
			if v220 == "curl" then
				local v227 = v_u_9(v221 + Vector3.new(0, 0.42, -0.1))
				local v228 = p217.body
				local v229 = Instance.new("Part")
				v229.Shape = Enum.PartType.Cylinder
				v_u_80(p217, v229, Vector3.new(0.5, 1, 1), v227, v228, nil)
				local v230 = Instance.new("Part")
				v230.Shape = Enum.PartType.Cylinder
				v_u_80(p217, v230, Vector3.new(0.54, 0.46, 0.46), v227, v222, v224)
			elseif v220 == "stinger" then
				local v231 = v221 + Vector3.new(0, 1, -0.35)
				local v232 = nil
				for v233 = 0, 4 do
					local v234 = v233 * 45 + -60
					local v235 = math.rad(v234)
					local v236 = v231 + v_u_8(0, math.sin(v235) * 1.05, math.cos(v235) * 1.05)
					if v232 then
						local v237 = 0.52 - v233 * 0.05
						local v238
						if v233 % 2 == 0 then
							v238 = p217.limbs
						else
							v238 = p217.body
						end
						local v239 = (v232 + v236) / 2
						local v240 = v_u_8(v237, v237, (v236 - v232).Magnitude)
						local v241 = CFrame.lookAt(v239, v236)
						v_u_80(p217, Instance.new("Part"), v240, v241, v238, nil)
					end
					v232 = v236
				end
				local v242 = v231 + Vector3.new(0, 0.9093267, -0.525)
				local v243 = CFrame.lookAt(v242 + Vector3.new(0, -0.175, -0.30449998), v242 + Vector3.new(0, -0.5, -0.87))
				local v244 = p217.glow
				local v245 = v_u_12
				v_u_80(p217, Instance.new("WedgePart"), Vector3.new(0.34, 0.34, 0.7), v243, v244, v245)
			elseif v220 == "spade" then
				local v246 = v_u_9(v221) * v_u_10(0.55, 0, 0)
				local v247 = v246 * v_u_9(0, 0, 0.36)
				local v248 = p217.body
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.18, 0.18, 0.8), v247, v248, nil)
				local v249 = v_u_9((v246 * v_u_9(0, 0, 0.72)).Position) * v_u_10(-0.75, 0, 0)
				local v250 = v249 * v_u_9(0, 0, 0.3)
				local v251 = p217.body
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.16, 0.16, 0.72), v250, v251, nil)
				local v252 = v_u_9((v249 * v_u_9(0, 0, 0.72)).Position) * v_u_10(0, 0, 0.7853981633974483)
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.36, 0.36, 0.2), v252, v222, v224)
			elseif v220 == "puff" then
				local v253 = v221 + Vector3.new(0, -0.15, 0.1)
				local v254 = p217.accent
				local v255 = Instance.new("Part")
				v255.Shape = Enum.PartType.Ball
				v_u_80(p217, v255, Vector3.new(0.75, 0.75, 0.75), v_u_9(v253), v254, nil)
			elseif v220 == "fluffy" then
				local v256
				if v219 == 1 then
					v256 = 0
				else
					local v257 = 0.3 * v219
					v256 = math.min(1.15, v257)
				end
				local v258 = v219 > 3 and 1.85 or 1.7
				local v259 = v219 > 3 and 0.56 or 0.74
				local v260 = v_u_9(v221) * v_u_10(0, 0, -v226 * v256) * v_u_10(-(1.3 - math.abs(v226) * 0.35), 0, 0)
				local v261 = v_u_8(v259, v259, v258)
				local v262 = v260 * v_u_9(0, 0, v258 / 2)
				local v263 = p217.body
				v_u_80(p217, Instance.new("Part"), v261, v262, v263, nil)
				local v264 = v_u_8(v259 + 0.04, v259 + 0.04, 0.45)
				local v265 = v260 * v_u_9(0, 0, v258 + 0.12)
				v_u_80(p217, Instance.new("Part"), v264, v265, v222, v224)
			else
				local v266 = v_u_9(v221) * v_u_10(-0.55, 0, 0)
				local v267 = v266 * v_u_9(0, 0, 0.45)
				local v268 = p217.body
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.3, 0.3, 1), v267, v268, nil)
				local v269 = (v266 * v_u_9(0, 0, 0.95)).Position
				local v270 = v_u_9(v269 + Vector3.new(0, 0.38, 0))
				local v271 = p217.body
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.3, 0.85, 0.3), v270, v271, nil)
				local v272 = v_u_9(v269 + Vector3.new(0, 0.85, -0.08))
				v_u_80(p217, Instance.new("Part"), Vector3.new(0.32, 0.3, 0.42), v272, v222, v224)
			end
		end
	end
end
local function v_u_290(p274, p275, p276, p277, p278) -- name: legs
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	for v279, v280 in {
		{ -p275, p276, 0 },
		{ p275, p276, 3.141592653589793 },
		{ -p275, p277, 3.141592653589793 },
		{ p275, p277, 0 }
	} do
		local v281 = v280[1]
		local v282 = v280[2]
		v_u_72(p274, "Leg" .. v279, "Body", v_u_8(v281, p278.Y, v282), "leg", v280[3])
		local v283 = v_u_9(v281, p278.Y / 2, v282)
		local v284 = p274.limbs
		v_u_80(p274, Instance.new("Part"), p278, v283, v284, nil)
		local v285 = p274.look.gear
		local v286
		if v285 == nil then
			v286 = false
		else
			v286 = table.find(v285, "socks") ~= nil
		end
		if not v286 then
			continue
		end
		local v287 = v_u_8(p278.X + 0.03, 0.22, p278.Z + 0.03)
		local v288 = v_u_9(v281, 0.11, v282)
		local v289 = p274.belly
		v_u_80(p274, Instance.new("Part"), v287, v288, v289, nil)
	end
end
local function v_u_331(p291, p292, p293, p294) -- name: batWings
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_124, (copy) v_u_80, (copy) v_u_12
	local v295 = p291.look
	local v296 = v295.wings or {}
	local v297
	if v296[1] then
		local v298 = v296[1]
		v297 = Color3.fromHex(v298)
	else
		v297 = p291.body:Lerp(p291.accent, 0.4)
	end
	local v299
	if v296[2] then
		local v300 = v296[2]
		v299 = Color3.fromHex(v300)
	else
		v299 = p291.limbs:Lerp(v_u_13, 0.45)
	end
	local v301 = v296[3]
	local v302
	if v301 then
		v302 = Color3.fromHex(v301)
	else
		v302 = v299
	end
	local v303
	if v301 == nil then
		v303 = false
	else
		v303 = v301 == v295.glow
	end
	for v304 = -1, 1, 2 do
		local v305 = v_u_8(v304 * p292.X, p292.Y, p292.Z)
		v_u_72(p291, v304 < 0 and "WingL" or "WingR", "Body", v305, "batwing", 0, v304)
		local v306 = v_u_9(v305) * v_u_10(0, 0, v304 * p294)
		local v307 = (v306 * v_u_9(v304 * 0 * p293, p293 * 0, p293 * 0)).Position
		local v308 = (v306 * v_u_9(v304 * 0.5 * p293, p293 * 0.3, p293 * 0.1)).Position
		local v309 = (v306 * v_u_9(v304 * 1.05 * p293, p293 * 0.42, p293 * 0.25)).Position
		local v310 = (v306 * v_u_9(v304 * 0.95 * p293, p293 * -0.28, p293 * 0.45)).Position
		local v311 = (v306 * v_u_9(v304 * 0.42 * p293, p293 * -0.52, p293 * 0.42)).Position
		v_u_124(p291, v308, v309, v310, 0.07, v297)
		v_u_124(p291, v308, v310, v311, 0.07, v297)
		v_u_124(p291, v307, v308, v311, 0.07, v297)
		local v312 = math.sqrt(p293) * 0.17
		local v313 = (v308 - v307).Unit * v312 * 0.4
		local v314 = v307 - v313
		local v315 = v308 + v313
		local v316 = (v314 + v315) / 2
		local v317 = v_u_8(v312, v312, (v315 - v314).Magnitude)
		local v318 = CFrame.lookAt(v316, v315)
		v_u_80(p291, Instance.new("Part"), v317, v318, v299, nil)
		local v319 = math.sqrt(p293) * 0.12
		local v320
		if v303 then
			v320 = v_u_12
		else
			v320 = nil
		end
		local v321 = (v309 - v308).Unit * v319 * 0.4
		local v322 = v308 - v321
		local v323 = v309 + v321
		local v324 = (v322 + v323) / 2
		local v325 = v_u_8(v319, v319, (v323 - v322).Magnitude)
		local v326 = CFrame.lookAt(v324, v323)
		v_u_80(p291, Instance.new("Part"), v325, v326, v302, v320)
		local v327 = math.sqrt(p293) * 0.09
		local v328 = (v308 + v310) / 2
		local v329 = v_u_8(v327, v327, (v310 - v308).Magnitude)
		local v330 = CFrame.lookAt(v328, v310)
		v_u_80(p291, Instance.new("Part"), v329, v330, v299, nil)
	end
end
local function v_u_356(p332, p333, p334, p335) -- name: wings
	-- upvalues: (copy) v_u_331, (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	local v336 = p332.look
	if v336.membrane then
		v_u_331(p332, p333, p334, p335)
	else
		local v337 = v336.wings or { v336.body }
		for v338 = -1, 1, 2 do
			local v339 = v_u_8(v338 * p333.X, p333.Y, p333.Z)
			v_u_72(p332, v338 < 0 and "WingL" or "WingR", "Body", v339, "wing", 0, v338)
			local v340 = v_u_9(v339) * v_u_10(0, 0, v338 * p335)
			for v341 = 1, 3 do
				local v342 = #v337
				local v343 = v337[math.min(v341, v342)]
				local v344 = Color3.fromHex(v343)
				local v345 = v344.R
				local v346 = v344.G
				local v347 = v344.B
				local v348 = math.min(v345, v346, v347) > 0.8
				local v349 = v336.aura == "rainbow" and true or v336.aura == "cosmic"
				if v343 == v336.glow then
					v349 = true
				elseif v349 then
					v349 = not v348
				end
				local v350 = p334 * (1.55 - v341 * 0.2)
				local v351 = v340 * v_u_10(0, -v338 * (v341 - 1) * 0.42, 0)
				local v352 = v_u_8(v350, 0.14, 0.55)
				local v353 = v351 * v_u_9(v338 * v350 / 2, v341 * -0.03, 0)
				local v354 = Color3.fromHex(v343)
				local v355
				if v349 then
					v355 = v_u_12
				else
					v355 = nil
				end
				v_u_80(p332, Instance.new("Part"), v352, v353, v354, v355)
			end
		end
	end
end
local function v_u_366(p357) -- name: quad
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_290, (copy) v_u_72, (copy) v_u_162, (copy) v_u_184, (copy) v_u_167, (copy) v_u_216, (copy) v_u_273, (copy) v_u_356
	p357.cur = p357.byName.Body or p357.bones[1]
	p357.bodyC = Vector3.new(0, 1.1, 0.4)
	p357.bodyS = Vector3.new(1.8, 1.35, 2.1)
	local v358 = p357.bodyS
	local v359 = v_u_9(p357.bodyC)
	local v360 = p357.body
	v_u_80(p357, Instance.new("Part"), v358, v359, v360, nil)
	local v361 = v_u_9(0, 1, -0.68)
	local v362 = p357.belly
	v_u_80(p357, Instance.new("Part"), Vector3.new(1.25, 0.85, 0.1), v361, v362, nil)
	v_u_290(p357, 0.55, -0.25, 1.1, Vector3.new(0.55, 0.7, 0.55))
	p357.headC = Vector3.new(0, 2.35, -0.55)
	p357.headS = Vector3.new(2.2, 1.85, 1.8)
	p357.face = p357.headC.Z - p357.headS.Z / 2
	p357.eyeX = 0.5
	p357.eyeY = 2.45
	p357.mouthY = 1.88
	p357.bandY = 2.98
	p357.neck = Vector3.new(0, 1.27, -0.71)
	p357.back = Vector3.new(0, 1.78, 0.8)
	p357.tailAt = Vector3.new(0, 1.55, 1.42)
	v_u_72(p357, "Head", "Body", Vector3.new(0, 1.6, -0.35), "head")
	local v363 = p357.headS
	local v364 = v_u_9(p357.headC)
	local v365 = p357.body
	v_u_80(p357, Instance.new("Part"), v363, v364, v365, nil)
	v_u_162(p357, 0.4, 0.56)
	v_u_184(p357)
	v_u_167(p357)
	v_u_216(p357)
	v_u_273(p357)
	if p357.look.wings then
		v_u_356(p357, Vector3.new(0.7, 1.7, 0.45), 1, 0.5)
	end
end
local function v442(p367) -- name: fish
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_72, (copy) v_u_12, (copy) v_u_162, (copy) v_u_13, (copy) v_u_167
	local v368 = p367.look.shape == "whale"
	local v369
	if p367.look.limbs then
		v369 = p367.limbs
	else
		v369 = p367.accent
	end
	local v370 = p367.look.glow ~= nil
	p367.cur = p367.byName.Body or p367.bones[1]
	p367.bodyC = Vector3.new(0, 1.45, 0.65)
	p367.bodyS = v368 and Vector3.new(1.8, 1.65, 1.8) or Vector3.new(1.6, 1.5, 1.7)
	local v371 = p367.bodyS
	local v372 = v_u_9(p367.bodyC)
	local v373 = p367.body
	v_u_80(p367, Instance.new("Part"), v371, v372, v373, nil)
	local v374 = p367.bodyC.Y - p367.bodyS.Y / 2
	local v375 = v_u_8(p367.bodyS.X - 0.2, 0.12, p367.bodyS.Z - 0.1)
	local v376 = v_u_9(0, v374 - 0.03, 0.65)
	local v377 = p367.belly
	v_u_80(p367, Instance.new("Part"), v375, v376, v377, nil)
	if v368 then
		local v378 = -(Vector3.new(0, 0, -0.6)).Unit
		local v379 = (Vector3.new(0, 0.35, 0)).Unit
		local v380 = CFrame.fromMatrix(Vector3.new(0, 2.425, 1.05), v379:Cross(v378), v379, v378)
		local v381 = v_u_8(0.2, (Vector3.new(0, 0.35, 0)).Magnitude, (Vector3.new(0, 0, -0.6)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v381, v380, v369, nil)
	else
		local v382 = -(Vector3.new(0, 0, -1.1)).Unit
		local v383 = (Vector3.new(0, 0.75, 0)).Unit
		local v384 = CFrame.fromMatrix(Vector3.new(0, 2.555, 0.8), v383:Cross(v382), v383, v382)
		local v385 = v_u_8(0.14, (Vector3.new(0, 0.75, 0)).Magnitude, (Vector3.new(0, 0, -1.1)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v385, v384, v369, nil)
	end
	local v386 = v_u_8(-0.45, v374, 0.9)
	local v387 = -(Vector3.new(0, 0, -0.45)).Unit
	local v388 = (Vector3.new(-0.25, -0.35, 0)).Unit
	local v389 = CFrame.fromMatrix(v386 + Vector3.new(0, 0, -0.225) + Vector3.new(-0.125, -0.175, 0), v388:Cross(v387), v388, v387)
	local v390 = v_u_8(0.08, (Vector3.new(-0.25, -0.35, 0)).Magnitude, (Vector3.new(0, 0, -0.45)).Magnitude)
	v_u_80(p367, Instance.new("WedgePart"), v390, v389, v369, nil)
	local v391 = v_u_8(0.45, v374, 0.9)
	local v392 = -(Vector3.new(0, 0, -0.45)).Unit
	local v393 = (Vector3.new(0.25, -0.35, 0)).Unit
	local v394 = CFrame.fromMatrix(v391 + Vector3.new(0, 0, -0.225) + Vector3.new(0.125, -0.175, 0), v393:Cross(v392), v393, v392)
	local v395 = v_u_8(0.08, (Vector3.new(0.25, -0.35, 0)).Magnitude, (Vector3.new(0, 0, -0.45)).Magnitude)
	v_u_80(p367, Instance.new("WedgePart"), v395, v394, v369, nil)
	for v396 = -1, 1, 2 do
		local v397 = v_u_8(v396 * (p367.bodyS.X / 2 - 0.05), 1.15, 0.35)
		v_u_72(p367, v396 < 0 and "WingL" or "WingR", "Body", v397, "wing", 0, v396)
		local v398 = v_u_8(v396 * 0.9, -0.3, 0)
		local v399 = -v398.Unit
		local v400 = (Vector3.new(0, 0, 0.7)).Unit
		local v401 = CFrame.fromMatrix(v397 + v398 / 2 + Vector3.new(0, 0, 0.35), v400:Cross(v399), v400, v399)
		local v402 = v_u_8(0.1, (Vector3.new(0, 0, 0.7)).Magnitude, v398.Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v402, v401, v369, nil)
	end
	local v403 = p367.bodyC.Z + p367.bodyS.Z / 2
	p367.tailAt = v_u_8(0, 1.45, v403)
	v_u_72(p367, "Tail1", "Body", p367.tailAt, "tail", 0)
	local v404 = v_u_9(0, 1.45, v403 + 0.35)
	local v405 = p367.body
	v_u_80(p367, Instance.new("Part"), Vector3.new(0.8, 0.85, 0.9), v404, v405, nil)
	local v406 = v403 + 1.6
	if v368 then
		local v407 = v_u_8(0, 1.45, v406)
		local v408 = -(Vector3.new(0, 0, -0.85)).Unit
		local v409 = (Vector3.new(-1.1, 0, 0)).Unit
		local v410 = CFrame.fromMatrix(v407 + Vector3.new(0, 0, -0.425) + Vector3.new(-0.55, 0, 0), v409:Cross(v408), v409, v408)
		local v411 = v_u_8(0.16, (Vector3.new(-1.1, 0, 0)).Magnitude, (Vector3.new(0, 0, -0.85)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v411, v410, v369, nil)
		local v412 = v_u_8(0, 1.45, v406)
		local v413 = -(Vector3.new(0, 0, -0.85)).Unit
		local v414 = (Vector3.new(1.1, 0, 0)).Unit
		local v415 = CFrame.fromMatrix(v412 + Vector3.new(0, 0, -0.425) + Vector3.new(0.55, 0, 0), v414:Cross(v413), v414, v413)
		local v416 = v_u_8(0.16, (Vector3.new(1.1, 0, 0)).Magnitude, (Vector3.new(0, 0, -0.85)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v416, v415, v369, nil)
	else
		local v417 = v_u_8(0, 1.45, v406)
		local v418 = -(Vector3.new(0, 0, -0.85)).Unit
		local v419 = (Vector3.new(0, 1, 0)).Unit
		local v420 = CFrame.fromMatrix(v417 + Vector3.new(0, 0, -0.425) + Vector3.new(0, 0.5, 0), v419:Cross(v418), v419, v418)
		local v421 = v_u_8(0.14, (Vector3.new(0, 1, 0)).Magnitude, (Vector3.new(0, 0, -0.85)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v421, v420, v369, nil)
		local v422 = v_u_8(0, 1.45, v406)
		local v423 = -(Vector3.new(0, 0, -0.85)).Unit
		local v424 = (Vector3.new(0, -0.85, 0)).Unit
		local v425 = CFrame.fromMatrix(v422 + Vector3.new(0, 0, -0.425) + Vector3.new(0, -0.425, 0), v424:Cross(v423), v424, v423)
		local v426 = v_u_8(0.14, (Vector3.new(0, -0.85, 0)).Magnitude, (Vector3.new(0, 0, -0.85)).Magnitude)
		v_u_80(p367, Instance.new("WedgePart"), v426, v425, v369, nil)
		if v370 then
			local v427 = v_u_9(0, 1.52, v406)
			local v428 = p367.glow
			local v429 = v_u_12
			v_u_80(p367, Instance.new("Part"), Vector3.new(0.16, 1.85, 0.12), v427, v428, v429)
		end
	end
	p367.headC = Vector3.new(0, 1.55, -0.8)
	p367.headS = v368 and Vector3.new(2.1, 1.9, 1.5) or Vector3.new(2, 1.85, 1.5)
	p367.face = p367.headC.Z - p367.headS.Z / 2
	p367.eyeX = 0.5
	p367.eyeY = 1.75
	p367.mouthY = 1.05
	p367.bandY = 2.2
	p367.plateW = 0.9
	p367.neck = v_u_8(0, 0.75, p367.face - 0.01)
	p367.back = Vector3.new(0, 2.2, 0.6)
	v_u_72(p367, "Head", "Body", Vector3.new(0, 1.45, -0.1), "head")
	local v430 = p367.headS
	local v431 = v_u_9(p367.headC)
	local v432 = p367.body
	v_u_80(p367, Instance.new("Part"), v430, v431, v432, nil)
	local v433 = v_u_8(p367.headS.X - 0.2, 0.12, p367.headS.Z - 0.1)
	local v434 = v_u_9(0, p367.headC.Y - p367.headS.Y / 2 - 0.03, p367.headC.Z)
	local v435 = p367.belly
	v_u_80(p367, Instance.new("Part"), v433, v434, v435, nil)
	v_u_162(p367, 0.42, 0.56)
	if v368 then
		local v436 = v_u_9(0, p367.mouthY, p367.face - 0.03)
		local v437 = v_u_13
		v_u_80(p367, Instance.new("Part"), Vector3.new(0.9, 0.08, 0.06), v436, v437, nil)
	else
		local v438 = v_u_9(0, p367.mouthY, p367.face - 0.07)
		local v439 = p367.belly
		v_u_80(p367, Instance.new("Part"), Vector3.new(0.56, 0.38, 0.16), v438, v439, nil)
		local v440 = v_u_9(0, p367.mouthY, p367.face - 0.16)
		local v441 = v_u_13
		v_u_80(p367, Instance.new("Part"), Vector3.new(0.3, 0.18, 0.06), v440, v441, nil)
	end
	v_u_167(p367)
end
local v_u_443 = {
	Vector3.new(0, 1.95, -0.3),
	Vector3.new(0.3, 1.85, 0.45),
	Vector3.new(0, 1.95, 1.2),
	Vector3.new(-0.32, 1.85, 1.95),
	Vector3.new(-0.1, 1.95, 2.65)
}
local v_u_444 = {
	1.3,
	1.12,
	0.95,
	0.76
}
local function v_u_468(p445, p446, p447) -- name: angelWings
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	local v448 = p445.look
	local v449 = v448.wings or { v448.body }
	local v450 = v448.aura == "rainbow" and true or v448.aura == "cosmic"
	for v451 = -1, 1, 2 do
		local v452 = v_u_8(v451 * p446.X, p446.Y, p446.Z)
		v_u_72(p445, v451 < 0 and "WingL" or "WingR", "Body", v452, "wing", 0, v451)
		local v453 = v_u_9(v452) * v_u_10(0, -v451 * 0.2, 0)
		for v454 = 1, 3 do
			local v455 = #v449
			local v456 = v449[math.min(v454, v455)]
			local v457 = Color3.fromHex(v456)
			local v458 = v457.R
			local v459 = v457.G
			local v460 = v457.B
			local v461 = math.min(v458, v459, v460) > 0.8
			local v462
			if v456 == v448.glow then
				v462 = true
			elseif v450 then
				v462 = not v461
			else
				v462 = v450
			end
			local v463 = 0.85 - (v454 - 1) * 0.34
			local v464 = p447 * (1.3 - v454 * 0.17)
			local v465 = v_u_8(v464, 0.6, 0.14)
			local v466 = v453 * v_u_9(v451 * math.cos(v463) * v464 / 2, math.sin(v463) * v464 / 2, v454 * 0.05) * v_u_10(0, 0, v451 * v463)
			local v467
			if v462 then
				v467 = v_u_12
			else
				v467 = nil
			end
			v_u_80(p445, Instance.new("Part"), v465, v466, v457, v467)
		end
	end
end
local v_u_925 = {
	["quad"] = v_u_366,
	["toad"] = function(p469) -- name: toad
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_13, (copy) v_u_162
		p469.cur = p469.byName.Body or p469.bones[1]
		p469.bodyC = Vector3.new(0, 0.75, 0.25)
		p469.bodyS = Vector3.new(2.3, 1.1, 1.9)
		local v470 = p469.bodyS
		local v471 = v_u_9(p469.bodyC)
		local v472 = p469.body
		v_u_80(p469, Instance.new("Part"), v470, v471, v472, nil)
		local v473 = v_u_9(0, 0.65, -0.72)
		local v474 = p469.belly
		v_u_80(p469, Instance.new("Part"), Vector3.new(1.7, 0.75, 0.1), v473, v474, nil)
		for v475 = -1, 1, 2 do
			local v476 = v_u_9(v475 * 1.2, 0.55, 0.55)
			local v477 = p469.body
			v_u_80(p469, Instance.new("Part"), Vector3.new(0.75, 0.85, 1.25), v476, v477, nil)
			local v478 = v_u_9(v475 * 1.28, 0.1, -0.05)
			local v479 = p469.belly
			v_u_80(p469, Instance.new("Part"), Vector3.new(0.8, 0.2, 0.75), v478, v479, nil)
			local v480 = v_u_9(v475 * 0.82, 0.3, -0.72)
			local v481 = p469.body
			v_u_80(p469, Instance.new("Part"), Vector3.new(0.42, 0.6, 0.42), v480, v481, nil)
		end
		p469.headC = Vector3.new(0, 1.85, -0.45)
		p469.headS = Vector3.new(2.5, 1.25, 1.9)
		p469.face = -1.4
		p469.eyeX = 0.75
		p469.eyeY = 2.62
		p469.mouthY = 1.55
		p469.bandY = 2.24
		p469.plateW = 0.62
		p469.back = Vector3.new(0, 1.3, 0.75)
		v_u_72(p469, "Head", "Body", Vector3.new(0, 1.25, -0.3), "head")
		local v482 = p469.headS
		local v483 = v_u_9(p469.headC)
		local v484 = p469.body
		v_u_80(p469, Instance.new("Part"), v482, v483, v484, nil)
		local v485 = v_u_9(-0.75, 2.62, -0.85)
		local v486 = p469.body
		v_u_80(p469, Instance.new("Part"), Vector3.new(0.85, 0.7, 0.8), v485, v486, nil)
		local v487 = v_u_9(0.75, 2.62, -0.85)
		local v488 = p469.body
		v_u_80(p469, Instance.new("Part"), Vector3.new(0.85, 0.7, 0.8), v487, v488, nil)
		local v489 = v_u_9(0, 1.55, -1.43)
		local v490 = v_u_13
		v_u_80(p469, Instance.new("Part"), Vector3.new(1.9, 0.09, 0.06), v489, v490, nil)
		p469.face = -1.25
		v_u_162(p469, 0.64, 0.5, true)
		p469.face = -1.4
	end,
	["bird"] = function(p491) -- name: bird
		-- upvalues: (copy) v_u_22, (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_10, (copy) v_u_8, (copy) v_u_12, (copy) v_u_356, (copy) v_u_162, (copy) v_u_13
		p491.cur = p491.byName.Body or p491.bones[1]
		local v492
		if p491.look.beak then
			local v493 = p491.look.beak
			v492 = Color3.fromHex(v493)
		else
			v492 = v_u_22
		end
		p491.bodyC = Vector3.new(0, 1.2, 0.25)
		p491.bodyS = Vector3.new(1.5, 1.35, 1.7)
		local v494 = p491.bodyS
		local v495 = v_u_9(p491.bodyC)
		local v496 = p491.body
		v_u_80(p491, Instance.new("Part"), v494, v495, v496, nil)
		local v497 = v_u_9(0, 1.1, -0.63)
		local v498 = p491.belly
		v_u_80(p491, Instance.new("Part"), Vector3.new(1.1, 0.95, 0.1), v497, v498, nil)
		for v499 = -1, 1, 2 do
			local v500 = v_u_9(v499 * 0.35, 0.3, 0.2)
			v_u_80(p491, Instance.new("Part"), Vector3.new(0.2, 0.45, 0.2), v500, v492, nil)
			local v501 = v_u_9(v499 * 0.35, 0.05, 0.1)
			v_u_80(p491, Instance.new("Part"), Vector3.new(0.34, 0.1, 0.45), v501, v492, nil)
		end
		v_u_72(p491, "Tail1", "Body", Vector3.new(0, 1, 1.05), "tail", 0)
		for v502 = 1, 3 do
			local v503 = v_u_9(0, 1, 1.05) * v_u_10(0, (v502 - 2) * 0.38, 0) * v_u_10(-0.2, 0, 0)
			local v504
			if v502 == 2 then
				v504 = p491.look.glow ~= nil
			else
				v504 = false
			end
			local v505 = v_u_8(0.36, 0.12, v504 and 1.15 or 1)
			local v506 = v503 * v_u_9(0, 0, 0.5)
			local v507
			if v504 then
				v507 = p491.glow
			else
				v507 = p491.body
			end
			local v508
			if v504 then
				v508 = v_u_12
			else
				v508 = nil
			end
			v_u_80(p491, Instance.new("Part"), v505, v506, v507, v508)
		end
		v_u_356(p491, Vector3.new(0.6, 1.6, 0.15), 1.1, 0.4)
		p491.headC = Vector3.new(0, 2.45, -0.45)
		p491.headS = Vector3.new(1.75, 1.55, 1.55)
		p491.face = p491.headC.Z - p491.headS.Z / 2
		p491.eyeX = 0.45
		p491.eyeY = 2.6
		p491.mouthY = 2.1
		p491.bandY = 3
		p491.plateW = 0.85
		p491.back = Vector3.new(0, 1.85, 0.5)
		v_u_72(p491, "Head", "Body", Vector3.new(0, 1.75, -0.2), "head")
		local v509 = p491.headS
		local v510 = v_u_9(p491.headC)
		local v511 = p491.body
		v_u_80(p491, Instance.new("Part"), v509, v510, v511, nil)
		v_u_162(p491, 0.42, 0.48)
		local v512 = v_u_9(0, 2.2, p491.face - 0.27)
		v_u_80(p491, Instance.new("WedgePart"), Vector3.new(0.42, 0.26, 0.55), v512, v492, nil)
		local v513 = v_u_9(0, 2.02, p491.face - 0.15)
		local v514, v515 = v492:Lerp(v_u_13, 0.3)
		v_u_80(p491, Instance.new("Part"), Vector3.new(0.3, 0.1, 0.32), v513, v514, v515)
	end,
	["serpent"] = function(p516) -- name: serpent
		-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_162, (copy) v_u_35
		p516.cur = p516.byName.Body or p516.bones[1]
		p516.bodyC = Vector3.new(0, 0.7, 0.35)
		p516.bodyS = Vector3.new(2.8, 1, 2.6)
		local v517 = {}
		for v518 = 0, 9 do
			local v519 = 1.5707963267948966 + v518 * 0.78
			local v520 = 1.05 - v518 * 0.06
			local v521 = v_u_8(math.cos(v519) * v520, v518 * 0.1 + 0.32, math.sin(v519) * v520 + 0.35)
			table.insert(v517, v521)
		end
		local v522 = p516.body:Lerp(p516.glow, 0.18)
		for v523 = 1, #v517 - 1 do
			local v524 = v517[v523]
			local v525 = v517[v523 + 1]
			local v526 = v_u_8(0.8, 0.64, (v525 - v524).Magnitude + 0.38)
			local v527 = CFrame.lookAt((v524 + v525) / 2, v525)
			local v528
			if v523 % 2 == 0 then
				v528 = v522
			else
				v528 = p516.body
			end
			v_u_80(p516, Instance.new("Part"), v526, v527, v528, nil)
		end
		local v529 = (v517[1] - v517[2]).Unit
		local v530 = v517[1] + v529 * 0.75 - Vector3.new(0, 0.12, 0)
		local v531 = CFrame.lookAt(v530, v530 + v529)
		local v532 = p516.body
		v_u_80(p516, Instance.new("WedgePart"), Vector3.new(0.5, 0.4, 1), v531, v532, nil)
		v_u_72(p516, "Neck1", "Body", Vector3.new(0, 1.2, 0.3), "neck", 0)
		local v533 = v_u_9(0, 1.7, 0.15) * v_u_10(0.25, 0, 0)
		local v534 = p516.body
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.8, 1, 0.8), v533, v534, nil)
		local v535 = v_u_9(0, 1.68, -0.26) * v_u_10(0.25, 0, 0)
		local v536 = p516.belly
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.55, 0.8, 0.1), v535, v536, nil)
		v_u_72(p516, "Neck2", "Neck1", Vector3.new(0, 2.15, 0.05), "neck", 0.8)
		local v537 = v_u_9(0, 2.5, -0.15)
		local v538 = p516.body
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.75, 0.85, 0.75), v537, v538, nil)
		local v539 = v_u_9(0, 2.45, -0.55)
		local v540 = p516.belly
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.5, 0.65, 0.1), v539, v540, nil)
		p516.headC = Vector3.new(0, 3.15, -0.6)
		p516.headS = Vector3.new(1.9, 1.25, 1.6)
		p516.face = p516.headC.Z - p516.headS.Z / 2
		p516.eyeX = 0.5
		p516.eyeY = 3.28
		p516.mouthY = 2.7
		p516.bandY = 3.5
		p516.neck = Vector3.new(0, 1.38, -0.3)
		p516.back = Vector3.new(0, 1.5, 0.6)
		v_u_72(p516, "Head", "Neck2", Vector3.new(0, 2.8, -0.3), "head")
		local v541 = p516.headS
		local v542 = v_u_9(p516.headC)
		local v543 = p516.body
		v_u_80(p516, Instance.new("Part"), v541, v542, v543, nil)
		local v544 = v_u_9(0, 2.72, p516.face - 0.18)
		local v545 = p516.body
		v_u_80(p516, Instance.new("Part"), Vector3.new(1.3, 0.5, 0.45), v544, v545, nil)
		local v546 = v_u_9(-0.25, 2.86, p516.face - 0.42)
		local v547 = v_u_13
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.12, 0.08, 0.05), v546, v547, nil)
		local v548 = v_u_9(0.25, 2.86, p516.face - 0.42)
		local v549 = v_u_13
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.12, 0.08, 0.05), v548, v549, nil)
		v_u_162(p516, 0.44, 0.52)
		v_u_72(p516, "Tongue", "Head", v_u_8(0, 2.58, p516.face - 0.3), "tongue")
		local v550 = v_u_9(0, 2.58, p516.face - 0.6)
		local v551 = v_u_35
		v_u_80(p516, Instance.new("Part"), Vector3.new(0.12, 0.05, 0.5), v550, v551, nil)
		for v552 = -1, 1, 2 do
			local v553 = v_u_9(v552 * 0.07, 2.58, p516.face - 0.9) * v_u_10(0, v552 * 0.45, 0)
			local v554 = v_u_35
			v_u_80(p516, Instance.new("Part"), Vector3.new(0.07, 0.05, 0.26), v553, v554, nil)
		end
	end,
	["dragon"] = function(p555) -- name: dragon
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_12, (copy) v_u_8, (copy) v_u_290, (copy) v_u_72, (copy) v_u_10, (copy) v_u_356, (copy) v_u_13, (copy) v_u_162
		p555.cur = p555.byName.Body or p555.bones[1]
		p555.bodyC = Vector3.new(0, 1.25, 0.3)
		p555.bodyS = Vector3.new(1.6, 1.4, 1.9)
		local v556 = p555.bodyS
		local v557 = v_u_9(p555.bodyC)
		local v558 = p555.body
		v_u_80(p555, Instance.new("Part"), v556, v557, v558, nil)
		local v559 = v_u_9(0, 1.15, -0.68)
		local v560 = p555.belly
		v_u_80(p555, Instance.new("Part"), Vector3.new(1.1, 1, 0.1), v559, v560, nil)
		local v561 = p555.glow
		local v562 = v_u_12
		local v563 = -(Vector3.new(0, 0, -0.55)).Unit
		local v564 = (Vector3.new(0, 0.45, 0)).Unit
		local v565 = CFrame.fromMatrix(Vector3.new(0, 2.155, 0.475), v564:Cross(v563), v564, v563)
		local v566 = v_u_8(0.16, (Vector3.new(0, 0.45, 0)).Magnitude, (Vector3.new(0, 0, -0.55)).Magnitude)
		v_u_80(p555, Instance.new("WedgePart"), v566, v565, v561, v562)
		local v567 = p555.glow
		local v568 = v_u_12
		local v569 = -(Vector3.new(0, 0, -0.45)).Unit
		local v570 = (Vector3.new(0, 0.35, 0)).Unit
		local v571 = CFrame.fromMatrix(Vector3.new(0, 2.105, 1.025), v570:Cross(v569), v570, v569)
		local v572 = v_u_8(0.16, (Vector3.new(0, 0.35, 0)).Magnitude, (Vector3.new(0, 0, -0.45)).Magnitude)
		v_u_80(p555, Instance.new("WedgePart"), v572, v571, v567, v568)
		v_u_290(p555, 0.5, -0.3, 0.95, Vector3.new(0.45, 0.6, 0.45))
		v_u_72(p555, "Tail1", "Body", Vector3.new(0, 1.05, 1.2), "tail", 0)
		local v573 = v_u_9(0, 0.95, 1.7) * v_u_10(0.25, 0, 0)
		local v574 = p555.body
		v_u_80(p555, Instance.new("Part"), Vector3.new(0.75, 0.7, 1.2), v573, v574, nil)
		v_u_72(p555, "Tail2", "Tail1", Vector3.new(0, 0.8, 2.25), "tail", 0.9)
		local v575 = v_u_9(0, 0.98, 2.62) * v_u_10(-0.5, 0, 0)
		local v576 = p555.body
		v_u_80(p555, Instance.new("Part"), Vector3.new(0.5, 0.5, 1), v575, v576, nil)
		local v577 = p555.glow
		local v578 = v_u_12
		local v579 = -(Vector3.new(0, 0, -0.7)).Unit
		local v580 = (Vector3.new(0, 0.7, 0)).Unit
		local v581 = CFrame.fromMatrix(Vector3.new(0, 1.5, 3.25), v580:Cross(v579), v580, v579)
		local v582 = v_u_8(0.14, (Vector3.new(0, 0.7, 0)).Magnitude, (Vector3.new(0, 0, -0.7)).Magnitude)
		v_u_80(p555, Instance.new("WedgePart"), v582, v581, v577, v578)
		v_u_356(p555, Vector3.new(0.6, 1.85, 0.4), 1.4, 0.6)
		p555.headC = Vector3.new(0, 2.6, -0.5)
		p555.headS = Vector3.new(2, 1.7, 1.75)
		p555.face = p555.headC.Z - p555.headS.Z / 2
		p555.eyeX = 0.48
		p555.eyeY = 2.78
		p555.mouthY = 2.08
		p555.bandY = 3.1
		p555.back = Vector3.new(0, 1.95, 0.6)
		v_u_72(p555, "Head", "Body", Vector3.new(0, 1.85, -0.2), "head")
		local v583 = p555.headS
		local v584 = v_u_9(p555.headC)
		local v585 = p555.body
		v_u_80(p555, Instance.new("Part"), v583, v584, v585, nil)
		local v586 = v_u_9(0, p555.mouthY, p555.face - 0.22)
		local v587 = p555.body
		v_u_80(p555, Instance.new("Part"), Vector3.new(1.3, 0.7, 0.55), v586, v587, nil)
		local v588 = v_u_9(-0.28, p555.mouthY + 0.2, p555.face - 0.51)
		local v589 = v_u_13
		v_u_80(p555, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v588, v589, nil)
		local v590 = v_u_9(0.28, p555.mouthY + 0.2, p555.face - 0.51)
		local v591 = v_u_13
		v_u_80(p555, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v590, v591, nil)
		v_u_162(p555, 0.44, 0.55)
	end,
	["fish"] = v442,
	["whale"] = v442,
	["bat"] = function(p592) -- name: bat
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_8, (copy) v_u_331, (copy) v_u_16, (copy) v_u_162, (copy) v_u_167
		p592.cur = p592.byName.Body or p592.bones[1]
		p592.bodyC = Vector3.new(0, 1.2, 0.25)
		p592.bodyS = Vector3.new(1.5, 1.25, 1.3)
		local v593 = p592.bodyS
		local v594 = v_u_9(p592.bodyC)
		local v595 = p592.body
		v_u_80(p592, Instance.new("Part"), v593, v594, v595, nil)
		local v596 = v_u_9(0, 1.12, -0.42)
		local v597 = p592.belly
		v_u_80(p592, Instance.new("Part"), Vector3.new(1.05, 0.85, 0.1), v596, v597, nil)
		for v598 = -1, 1, 2 do
			local v599 = v598 * 0.35
			v_u_72(p592, v598 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v599, 0.62, 0.3), "leg", v598 < 0 and 0 or 3.141592653589793)
			local v600 = v_u_9(v599, 0.4, 0.3)
			local v601 = p592.limbs
			v_u_80(p592, Instance.new("Part"), Vector3.new(0.3, 0.42, 0.3), v600, v601, nil)
		end
		v_u_331(p592, Vector3.new(0.68, 1.5, 0.3), 1.6, 0.35)
		p592.headC = Vector3.new(0, 2.4, -0.2)
		p592.headS = Vector3.new(2.15, 1.8, 1.75)
		p592.face = p592.headC.Z - p592.headS.Z / 2
		p592.eyeX = 0.48
		p592.eyeY = 2.5
		p592.mouthY = 1.98
		p592.bandY = 3
		p592.neck = Vector3.new(0, 1.6, -0.42)
		p592.back = Vector3.new(0, 1.85, 0.9)
		p592.tailAt = Vector3.new(0, 1, 0.9)
		v_u_72(p592, "Head", "Body", Vector3.new(0, 1.75, -0.15), "head")
		local v602 = p592.headS
		local v603 = v_u_9(p592.headC)
		local v604 = p592.body
		v_u_80(p592, Instance.new("Part"), v602, v603, v604, nil)
		local v605 = v_u_9(0, p592.mouthY + 0.05, p592.face - 0.06)
		local v606 = p592.belly
		v_u_80(p592, Instance.new("Part"), Vector3.new(0.75, 0.42, 0.14), v605, v606, nil)
		local v607 = v_u_9(0, p592.mouthY + 0.14, p592.face - 0.16)
		local v608 = v_u_16
		v_u_80(p592, Instance.new("Part"), Vector3.new(0.3, 0.16, 0.08), v607, v608, nil)
		v_u_162(p592, 0.42, 0.54)
		v_u_167(p592)
		local v609 = p592.headC.Y + p592.headS.Y / 2
		for v610 = -1, 1, 2 do
			local v611 = v_u_8(v610 * (p592.headS.X / 2 - 0.06), v609 - 0.1, p592.headC.Z - 0.2)
			local v612 = v_u_8(-v610 * 0.85, 0, 0)
			local v613 = -v610 * 0.28
			local v614 = math.cos(v613)
			local v615 = math.sin(v613)
			local v616 = v_u_8(v612.X * v614 - v612.Y * v615, v612.X * v615 + v612.Y * v614, v612.Z)
			local v617 = -v610 * 0.28
			local v618 = math.cos(v617)
			local v619 = math.sin(v617)
			local v620 = v_u_8(v618 * 0 - v619 * 1.2999999523162842, v619 * 0 + v618 * 1.2999999523162842, 0)
			v_u_72(p592, v610 < 0 and "EarL" or "EarR", "Head", v611 + v616 / 2, "ear", v610 * 1.3, v610)
			local v621 = p592.limbs
			local v622 = -v616.Unit
			local v623 = v620.Unit
			local v624 = CFrame.fromMatrix(v611 + v616 / 2 + v620 / 2, v623:Cross(v622), v623, v622)
			local v625 = v_u_8(0.3, v620.Magnitude, v616.Magnitude)
			v_u_80(p592, Instance.new("WedgePart"), v625, v624, v621, nil)
			local v626 = v611 + v616 * 0.14 + v620 * 0.08 + Vector3.new(0, 0, -0.05)
			local v627 = v616 * 0.62
			local v628 = v620 * 0.62
			local v629 = p592.accent
			local v630 = -v627.Unit
			local v631 = v628.Unit
			local v632 = CFrame.fromMatrix(v626 + v627 / 2 + v628 / 2, v631:Cross(v630), v631, v630)
			local v633 = v_u_8(0.28, v628.Magnitude, v627.Magnitude)
			v_u_80(p592, Instance.new("WedgePart"), v633, v632, v629, nil)
		end
	end,
	["imp"] = function(p634) -- name: imp
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_8, (copy) v_u_10, (copy) v_u_273, (copy) v_u_331, (copy) v_u_162, (copy) v_u_167, (copy) v_u_13
		p634.cur = p634.byName.Body or p634.bones[1]
		p634.bodyC = Vector3.new(0, 1.2, 0.1)
		p634.bodyS = Vector3.new(1.45, 1.3, 1.2)
		local v635 = p634.bodyS
		local v636 = v_u_9(p634.bodyC)
		local v637 = p634.body
		v_u_80(p634, Instance.new("Part"), v635, v636, v637, nil)
		local v638 = v_u_9(0, 1.12, -0.52)
		local v639 = p634.belly
		v_u_80(p634, Instance.new("Part"), Vector3.new(1, 0.85, 0.1), v638, v639, nil)
		for v640 = -1, 1, 2 do
			local v641 = v640 * 0.38
			v_u_72(p634, v640 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v641, 0.6, 0.1), "leg", v640 < 0 and 0 or 3.141592653589793)
			local v642 = v_u_9(v641, 0.3, 0.05)
			local v643 = p634.limbs
			v_u_80(p634, Instance.new("Part"), Vector3.new(0.46, 0.6, 0.5), v642, v643, nil)
		end
		for v644 = -1, 1, 2 do
			v_u_72(p634, v644 < 0 and "ArmL" or "ArmR", "Body", v_u_8(v644 * 0.74, 1.6, 0.05), "arm", v644 * 0.9, v644)
			local v645 = v_u_9(v644 * 0.88, 1.28, 0) * v_u_10(0, 0, v644 * 0.22)
			local v646 = p634.limbs
			v_u_80(p634, Instance.new("Part"), Vector3.new(0.36, 0.8, 0.4), v645, v646, nil)
		end
		p634.tailAt = Vector3.new(0, 0.8, 0.68)
		v_u_273(p634)
		v_u_331(p634, Vector3.new(0.42, 1.62, 0.6), 0.95, 0.6)
		p634.headC = Vector3.new(0, 2.62, -0.1)
		p634.headS = Vector3.new(2.15, 1.8, 1.7)
		p634.face = p634.headC.Z - p634.headS.Z / 2
		p634.eyeX = 0.5
		p634.eyeY = 2.7
		p634.mouthY = 2.1
		p634.bandY = 3.15
		p634.neck = Vector3.new(0, 1.72, -0.55)
		p634.back = Vector3.new(0, 1.75, 0.7)
		v_u_72(p634, "Head", "Body", Vector3.new(0, 1.85, -0.05), "head")
		local v647 = p634.headS
		local v648 = v_u_9(p634.headC)
		local v649 = p634.body
		v_u_80(p634, Instance.new("Part"), v647, v648, v649, nil)
		v_u_162(p634, 0.42, 0.56)
		v_u_167(p634)
		local v650 = p634.face - 0.03
		local v651 = v_u_9(0, p634.mouthY, v650)
		local v652 = v_u_13
		v_u_80(p634, Instance.new("Part"), Vector3.new(0.56, 0.1, 0.06), v651, v652, nil)
		for v653 = -1, 1, 2 do
			local v654 = v_u_9(v653 * 0.31, p634.mouthY + 0.05, v650) * v_u_10(0, 0, v653 * 0.5)
			local v655 = v_u_13
			v_u_80(p634, Instance.new("Part"), Vector3.new(0.1, 0.18, 0.06), v654, v655, nil)
		end
		for v656 = -1, 1, 2 do
			local v657 = v_u_8(v656 * (p634.headS.X / 2 - 0.05), p634.eyeY + 0.12, p634.headC.Z + 0.15)
			v_u_72(p634, v656 < 0 and "EarL" or "EarR", "Head", v657, "ear", v656 * 1.3, v656)
			local v658 = v_u_8(v656 * 0.62, 0, 0)
			local v659 = v656 * 0.4
			local v660 = math.cos(v659)
			local v661 = math.sin(v659)
			local v662 = v_u_8(v658.X * v660 - v658.Y * v661, v658.X * v661 + v658.Y * v660, v658.Z)
			local v663 = v656 * 0.4
			local v664 = math.cos(v663)
			local v665 = math.sin(v663)
			local v666 = v_u_8(v664 * 0 - v665 * -0.41999998688697815, v665 * 0 + v664 * -0.41999998688697815, 0)
			local v667 = p634.limbs
			local v668 = -v662.Unit
			local v669 = v666.Unit
			local v670 = CFrame.fromMatrix(v657 + v662 / 2 + v666 / 2, v669:Cross(v668), v669, v668)
			local v671 = v_u_8(0.22, v666.Magnitude, v662.Magnitude)
			v_u_80(p634, Instance.new("WedgePart"), v671, v670, v667, nil)
		end
	end,
	["spider"] = function(p672) -- name: spider
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_72, (copy) v_u_162, (copy) v_u_12, (copy) v_u_167
		p672.cur = p672.byName.Body or p672.bones[1]
		local v673 = v_u_9(0, 1.05, -0.05)
		local v674 = p672.body
		v_u_80(p672, Instance.new("Part"), Vector3.new(1.5, 1, 1.1), v673, v674, nil)
		local v675 = {
			-0.42,
			-0.14,
			0.14,
			0.42
		}
		local v676 = {
			-0.8,
			-0.28,
			0.28,
			0.8
		}
		for v677 = -1, 1, 2 do
			for v678, v679 in v675 do
				local v680 = v_u_8(v677 * 0.68, 1.1, v679)
				local v681 = v_u_8(v677 * 1.45, 1.8, v679 + v676[v678] * 0.55)
				local v682 = v_u_8(v677 * 2, 0.08, v679 + v676[v678])
				local v683 = (v678 + (v677 < 0 and 0 or 1)) % 2 == 0 and 0 or 3.141592653589793
				v_u_72(p672, (v677 < 0 and "LegL" or "LegR") .. v678, "Body", v680, "scuttle", v683, v677)
				local v684 = p672.limbs
				local v685 = (v681 - v680).Unit * 0.26 * 0.4
				local v686 = v680 - v685
				local v687 = v681 + v685
				local v688 = (v686 + v687) / 2
				local v689 = v_u_8(0.26, 0.26, (v687 - v686).Magnitude)
				local v690 = CFrame.lookAt(v688, v687)
				v_u_80(p672, Instance.new("Part"), v689, v690, v684, nil)
				local v691 = p672.limbs
				local v692 = (v682 - v681).Unit * 0.22 * 0.4
				local v693 = v681 - v692
				local v694 = v682 + v692
				local v695 = (v693 + v694) / 2
				local v696 = v_u_8(0.22, 0.22, (v694 - v693).Magnitude)
				local v697 = CFrame.lookAt(v695, v694)
				v_u_80(p672, Instance.new("Part"), v696, v697, v691, nil)
			end
		end
		p672.bodyC = Vector3.new(0, 1.5, 1.2)
		p672.bodyS = Vector3.new(2.1, 1.6, 1.95)
		v_u_72(p672, "Tail1", "Body", Vector3.new(0, 1.3, 0.45), "bob")
		local v698 = p672.bodyS
		local v699 = v_u_9(p672.bodyC)
		local v700 = p672.body
		v_u_80(p672, Instance.new("Part"), v698, v699, v700, nil)
		local v701 = v_u_9(0, 1.45, p672.bodyC.Z + p672.bodyS.Z / 2 + 0.03)
		local v702 = p672.belly
		v_u_80(p672, Instance.new("Part"), Vector3.new(1.5, 1.1, 0.1), v701, v702, nil)
		p672.tailAt = Vector3.new(0, 1.45, 2.2)
		p672.headC = Vector3.new(0, 1.45, -0.85)
		p672.headS = Vector3.new(1.85, 1.45, 1.3)
		p672.face = p672.headC.Z - p672.headS.Z / 2
		p672.eyeX = 0.42
		p672.eyeY = 1.55
		p672.mouthY = 1
		p672.bandY = 1.95
		p672.plateW = 0.85
		p672.neck = Vector3.new(0, 0.85, -1.2)
		p672.back = Vector3.new(0, 2.3, 1.2)
		v_u_72(p672, "Head", "Body", Vector3.new(0, 1.2, -0.5), "head")
		local v703 = p672.headS
		local v704 = v_u_9(p672.headC)
		local v705 = p672.body
		v_u_80(p672, Instance.new("Part"), v703, v704, v705, nil)
		v_u_162(p672, 0.4, 0.5)
		local v706 = p672.look.spirit or (p672.look.glow or "#FFB02B")
		local v707 = Color3.fromHex(v706)
		for v708 = -1, 1, 2 do
			local v709 = v_u_9(v708 * 0.17, p672.eyeY + 0.43, p672.face - 0.03)
			local v710 = v_u_12
			v_u_80(p672, Instance.new("Part"), Vector3.new(0.17, 0.17, 0.05), v709, v707, v710)
			local v711 = v_u_9(v708 * 0.66, p672.eyeY + 0.38, p672.face - 0.03)
			local v712 = v_u_12
			v_u_80(p672, Instance.new("Part"), Vector3.new(0.13, 0.13, 0.05), v711, v707, v712)
		end
		for v713 = -1, 1, 2 do
			local v714 = v_u_9(v713 * 0.24, 0.64, p672.face + 0.15)
			local v715 = p672.limbs
			v_u_80(p672, Instance.new("Part"), Vector3.new(0.22, 0.34, 0.22), v714, v715, nil)
			local v716 = v_u_9(v713 * 0.24, 0.4, p672.face + 0.13)
			local v717 = p672.glow
			local v718 = v_u_12
			v_u_80(p672, Instance.new("Part"), Vector3.new(0.14, 0.18, 0.14), v716, v717, v718)
		end
		v_u_167(p672)
	end,
	["penguin"] = function(p719) -- name: penguin
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_10, (copy) v_u_72, (copy) v_u_8, (copy) v_u_162, (copy) v_u_167
		p719.cur = p719.byName.Body or p719.bones[1]
		p719.bodyC = Vector3.new(0, 1.3, 0.15)
		p719.bodyS = Vector3.new(1.75, 1.9, 1.55)
		local v720 = p719.bodyS
		local v721 = v_u_9(p719.bodyC)
		local v722 = p719.body
		v_u_80(p719, Instance.new("Part"), v720, v721, v722, nil)
		local v723 = v_u_9(0, 1.2, p719.bodyC.Z - p719.bodyS.Z / 2 - 0.03)
		local v724 = p719.belly
		v_u_80(p719, Instance.new("Part"), Vector3.new(1.3, 1.6, 0.1), v723, v724, nil)
		local v725 = v_u_9(0, 0.45, 1) * v_u_10(-0.35, 0, 0)
		local v726 = p719.body
		v_u_80(p719, Instance.new("Part"), Vector3.new(0.62, 0.16, 0.45), v725, v726, nil)
		for v727 = -1, 1, 2 do
			local v728 = v727 * 0.4
			v_u_72(p719, v727 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v728, 0.35, -0.15), "leg", v727 < 0 and 0 or 3.141592653589793)
			local v729 = v_u_9(v728, 0.08, -0.3)
			local v730 = p719.accent
			v_u_80(p719, Instance.new("Part"), Vector3.new(0.5, 0.16, 0.72), v729, v730, nil)
		end
		for v731 = -1, 1, 2 do
			v_u_72(p719, v731 < 0 and "WingL" or "WingR", "Body", v_u_8(v731 * 0.86, 1.95, 0.15), "wing", 0, v731)
			local v732 = v_u_9(v731 * 1, 1.4, 0.15) * v_u_10(0, 0, v731 * 0.22)
			local v733 = p719.body
			v_u_80(p719, Instance.new("Part"), Vector3.new(0.2, 1.2, 0.62), v732, v733, nil)
		end
		p719.tailAt = Vector3.new(0, 0.55, 0.95)
		p719.headC = Vector3.new(0, 2.85, -0.05)
		p719.headS = Vector3.new(1.8, 1.45, 1.5)
		p719.face = p719.headC.Z - p719.headS.Z / 2
		p719.eyeX = 0.4
		p719.eyeY = 2.92
		p719.mouthY = 2.52
		p719.bandY = 3.3
		p719.plateW = 0.85
		p719.neck = Vector3.new(0, 2, -0.66)
		p719.back = Vector3.new(0, 2.1, 0.95)
		v_u_72(p719, "Head", "Body", Vector3.new(0, 2.25, 0), "head")
		local v734 = p719.headS
		local v735 = v_u_9(p719.headC)
		local v736 = p719.body
		v_u_80(p719, Instance.new("Part"), v734, v735, v736, nil)
		local v737 = v_u_9(0, 2.72, p719.face - 0.02)
		local v738 = p719.belly
		v_u_80(p719, Instance.new("Part"), Vector3.new(1.5, 1, 0.08), v737, v738, nil)
		local v739 = p719.face
		p719.face = v739 - 0.06
		v_u_162(p719, 0.36, 0.46)
		v_u_167(p719)
		p719.face = v739
		local v740 = v_u_9(0, p719.mouthY, p719.face - 0.3)
		local v741 = p719.accent
		v_u_80(p719, Instance.new("WedgePart"), Vector3.new(0.42, 0.26, 0.48), v740, v741, nil)
	end,
	["jelly"] = function(p742) -- name: jelly
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_12, (copy) v_u_72, (copy) v_u_8, (copy) v_u_10, (copy) v_u_162, (copy) v_u_13, (copy) v_u_167
		p742.cur = p742.byName.Body or p742.bones[1]
		p742.bodyC = Vector3.new(0, 2.3, 0.05)
		p742.bodyS = Vector3.new(2.1, 1.3, 2)
		local v743 = p742.bodyS
		local v744 = v_u_9(p742.bodyC)
		local v745 = p742.body
		local v746 = Instance.new("Part")
		v_u_80(p742, v746, v743, v744, v745, nil)
		v746.Transparency = 0.22
		local v747 = v_u_9(0, 3.15, 0.05)
		local v748 = p742.body
		local v749 = Instance.new("Part")
		v_u_80(p742, v749, Vector3.new(1.55, 0.45, 1.5), v747, v748, nil)
		v749.Transparency = 0.22
		local v750 = p742.look.spirit or "#FFFFFF"
		local v751 = Color3.fromHex(v750)
		local v752 = v_u_12
		local v753 = Instance.new("Part")
		v753.Shape = Enum.PartType.Ball
		v_u_80(p742, v753, Vector3.new(0.95, 0.95, 0.95), v_u_9(Vector3.new(0, 2.45, 0.2)), v751, v752)
		local v754 = v_u_9(0, 1.68, 0.05)
		local v755 = p742.accent
		local v756
		if p742.look.glow then
			v756 = v_u_12
		else
			v756 = nil
		end
		v_u_80(p742, Instance.new("Part"), Vector3.new(2.3, 0.2, 2.2), v754, v755, v756)
		for v757, v758 in {
			Vector3.new(-0.62, 1.62, -0.5),
			Vector3.new(0.62, 1.62, -0.5),
			Vector3.new(-0.62, 1.62, 0.6),
			Vector3.new(0.62, 1.62, 0.6)
		} do
			v_u_72(p742, "Tent" .. v757, "Body", v758, "dangle", v757 * 1.3)
			local v759 = v_u_9(v758 + Vector3.new(0, -0.38, 0))
			local v760 = p742.belly
			v_u_80(p742, Instance.new("Part"), Vector3.new(0.2, 0.75, 0.2), v759, v760, nil)
			local v761 = v_u_9(v758 + Vector3.new(0, -1.02, 0.04))
			local v762 = p742.glow
			local v763 = v_u_12
			v_u_80(p742, Instance.new("Part"), Vector3.new(0.16, 0.6, 0.16), v761, v762, v763)
		end
		for v764 = -1, 1, 2 do
			local v765 = v_u_8(v764 * 0.22, 1.62, 0.05)
			v_u_72(p742, v764 < 0 and "ArmL" or "ArmR", "Body", v765, "dangle", v764 * 2.1)
			local v766 = v_u_9(v765 + Vector3.new(0, -0.42, 0)) * v_u_10(0, 0, v764 * 0.12)
			local v767 = p742.accent
			v_u_80(p742, Instance.new("Part"), Vector3.new(0.36, 0.8, 0.14), v766, v767, nil)
			local v768 = v_u_9(v765 + v_u_8(v764 * 0.12, -1.15, 0)) * v_u_10(0, 0, -v764 * 0.15)
			local v769 = p742.accent
			v_u_80(p742, Instance.new("Part"), Vector3.new(0.3, 0.75, 0.12), v768, v769, nil)
		end
		p742.cur = p742.byName.Body or p742.bones[1]
		p742.headC = Vector3.new(0, 2.5, 0.05)
		p742.headS = Vector3.new(2.1, 1.75, 2)
		p742.face = p742.headC.Z - p742.headS.Z / 2
		p742.eyeX = 0.45
		p742.eyeY = 2.38
		p742.mouthY = 1.98
		p742.bandY = 2.85
		p742.neck = Vector3.new(0, 1.7, -0.95)
		p742.back = Vector3.new(0, 3, 0.9)
		p742.tailAt = Vector3.new(0, 1.75, 1)
		v_u_162(p742, 0.4, 0.5)
		local v770 = v_u_9(0, p742.mouthY, p742.face - 0.03)
		local v771 = v_u_13
		v_u_80(p742, Instance.new("Part"), Vector3.new(0.3, 0.08, 0.05), v770, v771, nil)
		v_u_167(p742)
	end,
	["seaturtle"] = function(p772) -- name: seaturtle
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_12, (copy) v_u_72, (copy) v_u_8, (copy) v_u_10, (copy) v_u_162, (copy) v_u_13, (copy) v_u_167
		p772.cur = p772.byName.Body or p772.bones[1]
		local v773 = v_u_9(0, 1.38, 0.35)
		local v774 = p772.belly
		v_u_80(p772, Instance.new("Part"), Vector3.new(2, 0.6, 2.3), v773, v774, nil)
		local v775 = v_u_9(0, 1.68, 0.35)
		local v776 = p772.accent
		local v777
		if p772.look.glow then
			v777 = v_u_12
		else
			v777 = nil
		end
		v_u_80(p772, Instance.new("Part"), Vector3.new(2.45, 0.2, 2.75), v775, v776, v777)
		local v778 = v_u_9(0, 1.98, 0.35)
		local v779 = p772.cloth
		v_u_80(p772, Instance.new("Part"), Vector3.new(2.25, 0.45, 2.55), v778, v779, nil)
		local v780 = v_u_9(0, 2.33, 0.35)
		local v781 = p772.cloth
		v_u_80(p772, Instance.new("Part"), Vector3.new(1.75, 0.35, 2), v780, v781, nil)
		local v782 = v_u_9(0, 2.6, 0.35)
		local v783 = p772.cloth
		v_u_80(p772, Instance.new("Part"), Vector3.new(1.1, 0.22, 1.3), v782, v783, nil)
		local v784 = v_u_9(0, 1.4, 1.7)
		local v785 = p772.body
		v_u_80(p772, Instance.new("Part"), Vector3.new(0.32, 0.22, 0.5), v784, v785, nil)
		p772.bodyC = Vector3.new(0, 2, 0.35)
		p772.bodyS = Vector3.new(2.25, 0.8, 2.55)
		p772.tailAt = Vector3.new(0, 1.4, 1.75)
		for v786 = -1, 1, 2 do
			v_u_72(p772, v786 < 0 and "WingL" or "WingR", "Body", v_u_8(v786 * 0.95, 1.45, -0.3), "paddle", 0, v786)
			local v787 = v_u_9(v786 * 1.55, 1.38, -0.05) * v_u_10(0, -v786 * 0.45, -v786 * 0.12)
			local v788 = p772.body
			v_u_80(p772, Instance.new("Part"), Vector3.new(1.4, 0.16, 0.62), v787, v788, nil)
			v_u_72(p772, v786 < 0 and "FinL" or "FinR", "Body", v_u_8(v786 * 0.85, 1.4, 1.2), "paddle", 1.8, v786)
			local v789 = v_u_9(v786 * 1.2, 1.36, 1.4) * v_u_10(0, -v786 * 0.55, 0)
			local v790 = p772.body
			v_u_80(p772, Instance.new("Part"), Vector3.new(0.8, 0.14, 0.45), v789, v790, nil)
		end
		p772.headC = Vector3.new(0, 1.8, -1.3)
		p772.headS = Vector3.new(1.55, 1.3, 1.3)
		p772.face = p772.headC.Z - p772.headS.Z / 2
		p772.eyeX = 0.38
		p772.eyeY = 1.9
		p772.mouthY = 1.42
		p772.bandY = 2.15
		p772.plateW = 0.8
		p772.neck = Vector3.new(0, 1.35, -0.85)
		p772.back = Vector3.new(0, 2.72, 0.35)
		v_u_72(p772, "Head", "Body", Vector3.new(0, 1.5, -0.6), "head")
		local v791 = v_u_9(0, 1.55, -0.65)
		local v792 = p772.body
		v_u_80(p772, Instance.new("Part"), Vector3.new(0.95, 0.75, 0.7), v791, v792, nil)
		local v793 = p772.headS
		local v794 = v_u_9(p772.headC)
		local v795 = p772.body
		v_u_80(p772, Instance.new("Part"), v793, v794, v795, nil)
		local v796 = v_u_9(0, p772.mouthY - 0.02, p772.face - 0.04)
		local v797 = p772.belly
		v_u_80(p772, Instance.new("Part"), Vector3.new(1.05, 0.34, 0.1), v796, v797, nil)
		v_u_162(p772, 0.36, 0.46)
		local v798 = v_u_9(0, p772.mouthY + 0.02, p772.face - 0.1)
		local v799 = v_u_13
		v_u_80(p772, Instance.new("Part"), Vector3.new(0.5, 0.07, 0.05), v798, v799, nil)
		v_u_167(p772)
	end,
	["octopus"] = function(p800) -- name: octopus
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_72, (copy) v_u_162, (copy) v_u_13, (copy) v_u_167
		p800.cur = p800.byName.Body or p800.bones[1]
		local v801 = v_u_9(0, 1.5, 0.2)
		local v802 = p800.body
		v_u_80(p800, Instance.new("Part"), Vector3.new(2, 0.8, 2), v801, v802, nil)
		for v803 = 0, 7 do
			local v804 = (v803 + 0.5) * 3.141592653589793 / 4
			local v805 = v_u_8(math.sin(v804), 0, -math.cos(v804))
			local v806 = Vector3.new(0, 1.3, 0.2) + v805 * 0.6
			local v807 = Vector3.new(0, 0.62, 0.2) + v805 * 1.3
			local v808 = Vector3.new(0, 0.9, 0.2) + v805 * 1.95
			v_u_72(p800, "Arm" .. v803, "Body", v806, "dangle", v803 * 0.8)
			local v809 = p800.body
			local v810 = (v807 - v806).Unit * 0.5 * 0.4
			local v811 = v806 - v810
			local v812 = v807 + v810
			local v813 = (v811 + v812) / 2
			local v814 = v_u_8(0.5, 0.5, (v812 - v811).Magnitude)
			local v815 = CFrame.lookAt(v813, v812)
			v_u_80(p800, Instance.new("Part"), v814, v815, v809, nil)
			local v816 = p800.belly
			local v817 = (v808 - v807).Unit * 0.34 * 0.4
			local v818 = v807 - v817
			local v819 = v808 + v817
			local v820 = (v818 + v819) / 2
			local v821 = v_u_8(0.34, 0.34, (v819 - v818).Magnitude)
			local v822 = CFrame.lookAt(v820, v819)
			v_u_80(p800, Instance.new("Part"), v821, v822, v816, nil)
		end
		p800.headC = Vector3.new(0, 2.62, 0.2)
		p800.headS = Vector3.new(2.3, 1.95, 2.05)
		p800.face = p800.headC.Z - p800.headS.Z / 2
		p800.eyeX = 0.52
		p800.eyeY = 2.55
		p800.mouthY = 1.98
		v_u_72(p800, "Head", "Body", Vector3.new(0, 1.85, 0.2), "head")
		local v823 = p800.headS
		local v824 = v_u_9(p800.headC)
		local v825 = p800.body
		v_u_80(p800, Instance.new("Part"), v823, v824, v825, nil)
		local v826 = v_u_9(0, 3.82, 0.3)
		local v827 = p800.body
		v_u_80(p800, Instance.new("Part"), Vector3.new(1.75, 0.5, 1.65), v826, v827, nil)
		v_u_162(p800, 0.44, 0.56)
		local v828 = v_u_9(0, p800.mouthY, p800.face - 0.06)
		local v829 = p800.belly
		v_u_80(p800, Instance.new("Part"), Vector3.new(0.4, 0.3, 0.14), v828, v829, nil)
		local v830 = v_u_9(0, p800.mouthY, p800.face - 0.13)
		local v831 = v_u_13
		v_u_80(p800, Instance.new("Part"), Vector3.new(0.22, 0.14, 0.06), v830, v831, nil)
		v_u_167(p800)
		local v832 = p800.headC
		local v833 = p800.headS
		p800.bodyC = v832
		p800.bodyS = v833
		p800.headC = Vector3.new(0, 2.83, 0.2)
		p800.headS = Vector3.new(2.3, 2.38, 2.05)
		p800.bandY = 3.2
		p800.neck = Vector3.new(0, 1.5, -0.85)
		p800.back = Vector3.new(0, 3.4, 1.2)
		p800.tailAt = Vector3.new(0, 1.4, 1.1)
	end,
	["leviathan"] = function(p834) -- name: leviathan
		-- upvalues: (copy) v_u_443, (copy) v_u_72, (copy) v_u_444, (copy) v_u_8, (copy) v_u_80, (copy) v_u_9, (copy) v_u_12, (copy) v_u_10, (copy) v_u_124, (copy) v_u_13, (copy) v_u_162
		p834.cur = p834.byName.Body or p834.bones[1]
		local v835 = p834.body:Lerp(p834.glow, 0.15)
		local v836 = p834.look.gear
		local v837
		if v836 == nil then
			v837 = false
		else
			v837 = table.find(v836, "glowdots") ~= nil
		end
		for v838 = 1, 4 do
			local v839 = v_u_443[v838]
			local v840 = v_u_443[v838 + 1]
			if v838 > 1 then
				v_u_72(p834, "Seg" .. v838, v838 == 2 and "Body" or "Seg" .. v838 - 1, v839, "swim", v838 * 0.9)
			end
			local v841 = v_u_444[v838]
			local v842 = CFrame.lookAt((v839 + v840) / 2, v840)
			local v843 = (v840 - v839).Magnitude + 0.32
			local v844 = v_u_8(v841, v841 * 0.95, v843)
			local v845
			if v838 % 2 == 0 then
				v845 = v835
			else
				v845 = p834.body
			end
			v_u_80(p834, Instance.new("Part"), v844, v842, v845, nil)
			local v846 = v_u_8(v841 * 0.7, 0.1, v843 - 0.2)
			local v847 = v842 * v_u_9(0, -v841 * 0.475, 0)
			local v848 = p834.belly
			v_u_80(p834, Instance.new("Part"), v846, v847, v848, nil)
			local v849 = v_u_8(v840.X - v839.X, 0, v840.Z - v839.Z).Unit
			local v850 = (v839 + v840) / 2 + v_u_8(0, v841 * 0.45, 0) + v849 * 0.3
			local v851 = -v849 * 0.75
			local v852 = v_u_8(0, 0.5 * v841 + 0.1, 0)
			local v853 = p834.glow
			local v854 = v_u_12
			local v855 = -v851.Unit
			local v856 = v852.Unit
			local v857 = CFrame.fromMatrix(v850 + v851 / 2 + v852 / 2, v856:Cross(v855), v856, v855)
			local v858 = v_u_8(0.12, v852.Magnitude, v851.Magnitude)
			v_u_80(p834, Instance.new("WedgePart"), v858, v857, v853, v854)
			if not v837 then
				continue
			end
			for v859 = -1, 1, 2 do
				local v860 = v842 * v_u_9(v859 * (v841 / 2 + 0.02), 0.05, 0) * v_u_10(0.7853981633974483, 0, 0)
				local v861 = p834.glow
				local v862 = v_u_12
				v_u_80(p834, Instance.new("Part"), Vector3.new(0.06, 0.17, 0.17), v860, v861, v862)
			end
		end
		local v863 = v_u_443[5]
		v_u_72(p834, "Fin", "Seg4", v863, "swim", 4.5)
		local v864 = v_u_9(v863 + Vector3.new(0, 0, 0.15))
		local v865 = p834.body
		v_u_80(p834, Instance.new("Part"), Vector3.new(0.5, 0.5, 0.55), v864, v865, nil)
		v_u_124(p834, v863 + Vector3.new(0, 0.12, 0.1), v863 + Vector3.new(0, 0.95, 0.85), v863 + Vector3.new(0, 0.1, 1.05), 0.12, p834.glow, v_u_12)
		v_u_124(p834, v863 + Vector3.new(0, -0.12, 0.1), v863 + Vector3.new(0, -0.8, 0.8), v863 + Vector3.new(0, -0.1, 1), 0.12, p834.glow, v_u_12)
		p834.bodyC = (v_u_443[1] + v_u_443[2]) / 2
		p834.bodyS = Vector3.new(1.3, 1.25, 1.3)
		p834.tailAt = v863
		p834.headC = Vector3.new(0, 2.25, -1.05)
		p834.headS = Vector3.new(1.9, 1.5, 1.55)
		p834.face = p834.headC.Z - p834.headS.Z / 2
		p834.eyeX = 0.48
		p834.eyeY = 2.5
		p834.mouthY = 1.92
		p834.bandY = 2.7
		p834.neck = Vector3.new(0, 1.45, -0.45)
		p834.back = Vector3.new(0, 2.6, 0.1)
		v_u_72(p834, "Head", "Body", v_u_443[1], "head")
		local v866 = p834.headS
		local v867 = v_u_9(p834.headC)
		local v868 = p834.body
		v_u_80(p834, Instance.new("Part"), v866, v867, v868, nil)
		local v869 = v_u_9(0, p834.mouthY, p834.face - 0.24)
		local v870 = p834.body
		v_u_80(p834, Instance.new("Part"), Vector3.new(1.3, 0.62, 0.58), v869, v870, nil)
		local v871 = v_u_9(0, p834.mouthY - 0.3, p834.face - 0.22)
		local v872 = p834.belly
		v_u_80(p834, Instance.new("Part"), Vector3.new(1, 0.12, 0.5), v871, v872, nil)
		local v873 = v_u_9(-0.28, p834.mouthY + 0.18, p834.face - 0.535)
		local v874 = v_u_13
		v_u_80(p834, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v873, v874, nil)
		local v875 = v_u_9(0.28, p834.mouthY + 0.18, p834.face - 0.535)
		local v876 = v_u_13
		v_u_80(p834, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v875, v876, nil)
		v_u_162(p834, 0.46, 0.5)
	end,
	["slime"] = function(p877) -- name: slime
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_10, (copy) v_u_14, (copy) v_u_162, (copy) v_u_167, (copy) v_u_13, (copy) v_u_17
		p877.cur = p877.byName.Body or p877.bones[1]
		local v878 = v_u_9(0, 0.275, 0.1)
		local v879 = p877.body
		v_u_80(p877, Instance.new("Part"), Vector3.new(2.5, 0.55, 2.3), v878, v879, nil)
		p877.bodyC = Vector3.new(0, 1.1, 0.1)
		p877.bodyS = Vector3.new(2.5, 2.2, 2.3)
		p877.tailAt = Vector3.new(0, 0.5, 1.25)
		v_u_72(p877, "Head", "Body", Vector3.new(0, 0.55, 0.1), "jiggle")
		local v880 = v_u_9(0, 1.1, 0.1)
		local v881 = p877.body
		v_u_80(p877, Instance.new("Part"), Vector3.new(2.36, 1.15, 2.18), v880, v881, nil)
		local v882 = v_u_9(0, 1.875, 0.1)
		local v883 = p877.body
		v_u_80(p877, Instance.new("Part"), Vector3.new(1.95, 0.45, 1.85), v882, v883, nil)
		local v884 = v_u_9(0, 2.19, 0.12)
		local v885 = p877.body
		v_u_80(p877, Instance.new("Part"), Vector3.new(1.25, 0.22, 1.2), v884, v885, nil)
		local v886 = v_u_9(-0.42, 1.88, -0.85) * v_u_10(0, 0, 0.25)
		local v887 = v_u_14
		v_u_80(p877, Instance.new("Part"), Vector3.new(0.46, 0.11, 0.05), v886, v887, nil)
		local v888 = v_u_9(-0.06, 1.95, -0.85)
		local v889 = v_u_14
		v_u_80(p877, Instance.new("Part"), Vector3.new(0.13, 0.13, 0.05), v888, v889, nil)
		local v890 = v_u_9(-0.2, 2.31, -0.05)
		local v891, v892 = p877.body:Lerp(v_u_14, 0.45)
		v_u_80(p877, Instance.new("Part"), Vector3.new(0.5, 0.05, 0.4), v890, v891, v892)
		p877.headC = Vector3.new(0, 1.4, 0.1)
		p877.headS = Vector3.new(2.36, 1.8, 2.18)
		p877.face = p877.headC.Z - p877.headS.Z / 2
		p877.eyeX = 0.5
		p877.eyeY = 1.25
		p877.mouthY = 0.8
		p877.bandY = 1.9
		p877.plateW = 0.9
		p877.neck = Vector3.new(0, 0.62, -1.12)
		p877.back = Vector3.new(0, 2.1, 0.75)
		v_u_162(p877, 0.42, 0.56)
		v_u_167(p877)
		local v893 = v_u_9(0, p877.mouthY, p877.face - 0.03)
		local v894 = v_u_13
		v_u_80(p877, Instance.new("Part"), Vector3.new(0.36, 0.15, 0.05), v893, v894, nil)
		local v895 = v_u_9(0, p877.mouthY - 0.045, p877.face - 0.04)
		local v896 = v_u_17
		v_u_80(p877, Instance.new("Part"), Vector3.new(0.2, 0.06, 0.05), v895, v896, nil)
	end,
	["horse"] = function(p897) -- name: horse
		-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_18, (copy) v_u_72, (copy) v_u_8, (copy) v_u_273, (copy) v_u_468, (copy) v_u_10, (copy) v_u_13, (copy) v_u_162, (copy) v_u_167, (copy) v_u_216
		p897.cur = p897.byName.Body or p897.bones[1]
		p897.bodyC = Vector3.new(0, 1.7, 0.45)
		p897.bodyS = Vector3.new(1.7, 1.3, 2.3)
		local v898 = p897.bodyS
		local v899 = v_u_9(p897.bodyC)
		local v900 = p897.body
		v_u_80(p897, Instance.new("Part"), v898, v899, v900, nil)
		local v901 = v_u_9(0, 1.68, -0.73)
		local v902 = p897.belly
		v_u_80(p897, Instance.new("Part"), Vector3.new(1.2, 0.85, 0.1), v901, v902, nil)
		local v903
		if p897.look.beak then
			local v904 = p897.look.beak
			v903 = Color3.fromHex(v904)
		else
			v903 = v_u_18
		end
		for v905, v906 in {
			{ -0.5, -0.25, 0 },
			{ 0.5, -0.25, 3.141592653589793 },
			{ -0.5, 1.2, 3.141592653589793 },
			{ 0.5, 1.2, 0 }
		} do
			local v907 = v906[1]
			local v908 = v906[2]
			v_u_72(p897, "Leg" .. v905, "Body", v_u_8(v907, 1.12, v908), "leg", v906[3])
			local v909 = v_u_9(v907, 0.56, v908)
			local v910 = p897.limbs
			v_u_80(p897, Instance.new("Part"), Vector3.new(0.46, 1.12, 0.46), v909, v910, nil)
			local v911 = v_u_9(v907, 0.12, v908)
			v_u_80(p897, Instance.new("Part"), Vector3.new(0.52, 0.24, 0.52), v911, v903, nil)
		end
		p897.tailAt = Vector3.new(0, 2.1, 1.58)
		v_u_273(p897)
		if p897.look.wings then
			v_u_468(p897, Vector3.new(0.55, 2.3, 0.35), 1.75)
		end
		p897.headC = Vector3.new(0, 3.6, -1.2)
		p897.headS = Vector3.new(1.75, 1.55, 1.6)
		p897.face = p897.headC.Z - p897.headS.Z / 2
		p897.eyeX = 0.45
		p897.eyeY = 3.8
		p897.mouthY = 2.95
		p897.bandY = 4.1
		p897.plateW = 0.9
		p897.neck = Vector3.new(0, 2.25, -1)
		p897.back = Vector3.new(0, 2.4, 0.5)
		v_u_72(p897, "Head", "Body", Vector3.new(0, 2.1, -0.45), "head")
		local v912 = v_u_9(0, 2.6, -0.8) * v_u_10(-0.35, 0, 0)
		local v913 = p897.body
		v_u_80(p897, Instance.new("Part"), Vector3.new(0.95, 1.4, 0.95), v912, v913, nil)
		local v914 = p897.headS
		local v915 = v_u_9(p897.headC)
		local v916 = p897.body
		v_u_80(p897, Instance.new("Part"), v914, v915, v916, nil)
		local v917 = v_u_9(0, 3.1, p897.face - 0.3)
		local v918 = p897.belly
		v_u_80(p897, Instance.new("Part"), Vector3.new(1.25, 0.8, 0.7), v917, v918, nil)
		local v919 = v_u_9(-0.28, 3.27, p897.face - 0.67)
		local v920 = v_u_13
		v_u_80(p897, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v919, v920, nil)
		local v921 = v_u_9(0.28, 3.27, p897.face - 0.67)
		local v922 = v_u_13
		v_u_80(p897, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.05), v921, v922, nil)
		local v923 = v_u_9(0, 2.92, p897.face - 0.67)
		local v924 = v_u_13
		v_u_80(p897, Instance.new("Part"), Vector3.new(0.46, 0.07, 0.05), v923, v924, nil)
		v_u_162(p897, 0.42, 0.56)
		v_u_167(p897)
		v_u_216(p897)
	end
}
local v_u_926 = {}
local v_u_927 = {}
function v_u_926.socks(_) -- name: socks end
function v_u_926.brows(p928) -- name: brows
	-- upvalues: (copy) v_u_9, (copy) v_u_80
	p928.cur = p928.byName.Head or p928.bones[1]
	for v929 = -1, 1, 2 do
		local v930 = v_u_9(v929 * p928.eyeX, p928.eyeY + 0.45, p928.face - 0.03)
		local v931 = p928.belly
		v_u_80(p928, Instance.new("Part"), Vector3.new(0.28, 0.14, 0.06), v930, v931, nil)
	end
end
function v_u_926.bandana(p932) -- name: bandana
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8
	p932.cur = p932.byName.Body or p932.bones[1]
	local v933 = v_u_9(p932.neck)
	local v934 = p932.cloth
	v_u_80(p932, Instance.new("Part"), Vector3.new(1.5, 0.22, 0.12), v933, v934, nil)
	local v935 = p932.neck + Vector3.new(0, -0.08, -0.03)
	local v936 = p932.cloth
	local v937 = -(Vector3.new(-0.6, 0, 0)).Unit
	local v938 = (Vector3.new(0, -0.55, 0)).Unit
	local v939 = CFrame.fromMatrix(v935 + Vector3.new(-0.3, 0, 0) + Vector3.new(0, -0.275, 0), v938:Cross(v937), v938, v937)
	local v940 = v_u_8(0.1, (Vector3.new(0, -0.55, 0)).Magnitude, (Vector3.new(-0.6, 0, 0)).Magnitude)
	v_u_80(p932, Instance.new("WedgePart"), v940, v939, v936, nil)
	local v941 = p932.neck + Vector3.new(0, -0.08, -0.03)
	local v942 = p932.cloth
	local v943 = -(Vector3.new(0.6, 0, 0)).Unit
	local v944 = (Vector3.new(0, -0.55, 0)).Unit
	local v945 = CFrame.fromMatrix(v941 + Vector3.new(0.3, 0, 0) + Vector3.new(0, -0.275, 0), v944:Cross(v943), v944, v943)
	local v946 = v_u_8(0.1, (Vector3.new(0, -0.55, 0)).Magnitude, (Vector3.new(0.6, 0, 0)).Magnitude)
	v_u_80(p932, Instance.new("WedgePart"), v946, v945, v942, nil)
end
function v_u_926.tongue(p947) -- name: tongue
	-- upvalues: (copy) v_u_9, (copy) v_u_17, (copy) v_u_80
	p947.cur = p947.byName.Head or p947.bones[1]
	local v948 = v_u_9(0.14, p947.mouthY - 0.32, p947.face - 0.27)
	local v949 = v_u_17
	v_u_80(p947, Instance.new("Part"), Vector3.new(0.26, 0.28, 0.08), v948, v949, nil)
end
function v_u_926.stripes(p950) -- name: stripes
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	p950.cur = p950.byName.Head or p950.bones[1]
	local v951 = p950.headC.Y + p950.headS.Y / 2
	local v952 = p950.body:Lerp(Color3.new(0, 0, 0), 0.35)
	for v953 = -1, 1 do
		local v954 = v953 == 0 and 0.5 or 0.38
		local v955 = v_u_8(0.15, v954, 0.06)
		local v956 = v_u_9(v953 * 0.3, v951 - v954 / 2, p950.face - 0.03)
		v_u_80(p950, Instance.new("Part"), v955, v956, v952, nil)
	end
end
function v_u_926.whiskers(p957) -- name: whiskers
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_21, (copy) v_u_80
	p957.cur = p957.byName.Head or p957.bones[1]
	for v958 = -1, 1, 2 do
		for v959 = 0, 1 do
			local v960 = v_u_9(v958 * 0.9, p957.mouthY + 0.04 - v959 * 0.14, p957.face - 0.05) * v_u_10(0, 0, v958 * (0.14 - v959 * 0.24))
			local v961 = v_u_21
			v_u_80(p957, Instance.new("Part"), Vector3.new(0.62, 0.05, 0.04), v960, v961, nil)
		end
	end
end
function v_u_926.collar(p962) -- name: collar
	-- upvalues: (copy) v_u_9, (copy) v_u_80
	p962.cur = p962.byName.Body or p962.bones[1]
	local v963 = v_u_9(p962.neck)
	local v964 = p962.cloth
	v_u_80(p962, Instance.new("Part"), Vector3.new(1.5, 0.24, 0.12), v963, v964, nil)
end
function v_u_926.bell(p965) -- name: bell
	-- upvalues: (copy) v_u_18, (copy) v_u_80, (copy) v_u_9
	p965.cur = p965.byName.Body or p965.bones[1]
	local v966 = p965.neck + Vector3.new(0, -0.24, -0.1)
	local v967 = v_u_18
	local v968 = Instance.new("Part")
	v968.Shape = Enum.PartType.Ball
	v_u_80(p965, v968, Vector3.new(0.36, 0.36, 0.36), v_u_9(v966), v967, nil)
end
function v_u_926.teeth(p969) -- name: teeth
	-- upvalues: (copy) v_u_9, (copy) v_u_14, (copy) v_u_80
	p969.cur = p969.byName.Head or p969.bones[1]
	local v970 = v_u_9(0, p969.mouthY - 0.26, p969.face - 0.16)
	local v971 = v_u_14
	v_u_80(p969, Instance.new("Part"), Vector3.new(0.26, 0.18, 0.06), v970, v971, nil)
end
function v_u_926.bow(p972) -- name: bow
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_10
	p972.cur = p972.byName.Head or p972.bones[1]
	local v973 = v_u_8(0.62, p972.headC.Y + p972.headS.Y / 2 + 0.02, p972.face + 0.25)
	local v974 = v_u_9(v973)
	local v975 = p972.cloth
	v_u_80(p972, Instance.new("Part"), Vector3.new(0.24, 0.24, 0.2), v974, v975, nil)
	for v976 = -1, 1, 2 do
		local v977 = v_u_9(v973 + v_u_8(v976 * 0.3, 0, 0)) * v_u_10(0, 0, v976 * 0.35)
		local v978 = p972.cloth
		v_u_80(p972, Instance.new("Part"), Vector3.new(0.42, 0.3, 0.14), v977, v978, nil)
	end
end
function v_u_926.patches(p979) -- name: patches
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_80
	p979.cur = p979.byName.Head or p979.bones[1]
	for v980 = -1, 1, 2 do
		local v981 = v_u_9(v980 * (p979.eyeX + 0.04), p979.eyeY - 0.06, p979.face - 0.015) * v_u_10(0, 0, v980 * 0.35)
		local v982 = p979.limbs
		v_u_80(p979, Instance.new("Part"), Vector3.new(0.62, 0.8, 0.06), v981, v982, nil)
	end
end
function v_u_926.band(p983) -- name: band
	-- upvalues: (copy) v_u_9, (copy) v_u_80
	p983.cur = p983.byName.Body or p983.bones[1]
	local v984 = v_u_9(0, 1.1, -0.3)
	local v985 = p983.limbs
	v_u_80(p983, Instance.new("Part"), Vector3.new(1.84, 1.39, 0.6), v984, v985, nil)
end
function v_u_926.headband(p986) -- name: headband
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_10
	p986.cur = p986.byName.Head or p986.bones[1]
	local v987 = v_u_8(p986.headS.X + 0.06, 0.34, p986.headS.Z + 0.06)
	local v988 = v_u_9(0, p986.bandY, p986.headC.Z)
	local v989 = p986.cloth
	v_u_80(p986, Instance.new("Part"), v987, v988, v989, nil)
	local v990 = v_u_8(0, p986.bandY, p986.headC.Z + p986.headS.Z / 2 + 0.08)
	local v991 = v_u_9(v990)
	local v992 = p986.cloth
	v_u_80(p986, Instance.new("Part"), Vector3.new(0.3, 0.3, 0.18), v991, v992, nil)
	v_u_72(p986, "Knot", "Head", v990, "flag")
	for v993 = -1, 1, 2 do
		local v994 = v_u_9(v990) * v_u_10(0, v993 * 0.35, 0) * v_u_10(0.6, 0, 0) * v_u_9(0, 0, 0.42)
		local v995 = p986.cloth
		v_u_80(p986, Instance.new("Part"), Vector3.new(0.24, 0.08, 0.85), v994, v995, nil)
	end
end
function v_u_926.plate(p996) -- name: plate
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_20, (copy) v_u_80, (copy) v_u_10, (copy) v_u_13
	p996.cur = p996.byName.Head or p996.bones[1]
	local v997 = p996.face - 0.06
	local v998 = v_u_8(p996.plateW, 0.4, 0.08)
	local v999 = v_u_9(0, p996.bandY, v997)
	local v1000 = v_u_20
	v_u_80(p996, Instance.new("Part"), v998, v999, v1000, nil)
	local v1001 = v_u_9(-0.04, p996.bandY + 0.03, v997 - 0.05) * v_u_10(0, 1.5707963267948966, 0)
	local v1002 = v_u_13
	local v1003 = Instance.new("Part")
	v1003.Shape = Enum.PartType.Cylinder
	v_u_80(p996, v1003, Vector3.new(0.04, 0.2, 0.2), v1001, v1002, nil)
	local v1004 = v_u_9(0.1, p996.bandY - 0.07, v997 - 0.05) * v_u_10(0, 0, -0.6)
	local v1005 = v_u_13
	v_u_80(p996, Instance.new("Part"), Vector3.new(0.2, 0.05, 0.04), v1004, v1005, nil)
end
function v_u_926.scratch(p1006) -- name: scratch
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_80
	p1006.cur = p1006.byName.Head or p1006.bones[1]
	local v1007 = v_u_8(p1006.plateW * 0.95, 0.05, 0.04)
	local v1008 = v_u_9(0, p1006.bandY, p1006.face - 0.13) * v_u_10(0, 0, 0.14)
	local v1009 = v_u_13
	v_u_80(p1006, Instance.new("Part"), v1007, v1008, v1009, nil)
end
function v_u_926.bamboo(p1010) -- name: bamboo
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_25, (copy) v_u_80, (copy) v_u_26, (copy) v_u_27
	p1010.cur = p1010.byName.Body or p1010.bones[1]
	local v1011 = v_u_9(p1010.back + Vector3.new(0, 0.4, 0.15)) * v_u_10(0, 0, 0.9)
	local v1012 = v1011 * v_u_9(-0.55, 0, 0)
	local v1013 = v_u_25
	local v1014 = Instance.new("Part")
	v1014.Shape = Enum.PartType.Cylinder
	v_u_80(p1010, v1014, Vector3.new(1.15, 0.26, 0.26), v1012, v1013, nil)
	local v1015 = v1011 * v_u_9(0.62, 0, 0)
	local v1016 = v_u_25
	local v1017 = Instance.new("Part")
	v1017.Shape = Enum.PartType.Cylinder
	v_u_80(p1010, v1017, Vector3.new(1.15, 0.26, 0.26), v1015, v1016, nil)
	local v1018 = v1011 * v_u_9(0.04, 0, 0)
	local v1019 = v_u_26
	local v1020 = Instance.new("Part")
	v1020.Shape = Enum.PartType.Cylinder
	v_u_80(p1010, v1020, Vector3.new(0.1, 0.32, 0.32), v1018, v1019, nil)
	for v1021 = -1, 1, 2 do
		local v1022 = v1011 * v_u_9(1.15, v1021 * 0.14, 0) * v_u_10(0, 0, v1021 * 0.6)
		local v1023 = v_u_27
		v_u_80(p1010, Instance.new("Part"), Vector3.new(0.55, 0.06, 0.22), v1022, v1023, nil)
	end
end
function v_u_926.crown(p1024) -- name: crown
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_18, (copy) v_u_80, (copy) v_u_10, (copy) v_u_23, (copy) v_u_24, (copy) v_u_12
	p1024.cur = p1024.byName.Head or p1024.bones[1]
	local v1025 = v_u_8(0, p1024.headC.Y + p1024.headS.Y / 2 + 0.16, p1024.headC.Z - 0.1)
	local v1026 = v_u_9(v1025)
	local v1027 = v_u_18
	v_u_80(p1024, Instance.new("Part"), Vector3.new(1.05, 0.32, 0.95), v1026, v1027, nil)
	for v1028 = -1, 1 do
		local v1029 = v1028 == 0 and 0.36 or 0.28
		local v1030 = v_u_9(v1025 + v_u_8(v1028 * 0.38, v1029, -0.37)) * v_u_10(0, 0, 0.7853981633974483)
		local v1031 = v_u_18
		v_u_80(p1024, Instance.new("Part"), Vector3.new(0.26, 0.26, 0.2), v1030, v1031, nil)
		local v1032 = v_u_9(v1025 + v_u_8(v1028 * 0.33, 0, -0.5))
		local v1033
		if v1028 == 0 then
			v1033 = v_u_23
		else
			v1033 = v_u_24
		end
		local v1034 = v_u_12
		v_u_80(p1024, Instance.new("Part"), Vector3.new(0.18, 0.18, 0.06), v1032, v1033, v1034)
	end
end
function v_u_926.cape(p1035) -- name: cape
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_12, (copy) v_u_14
	local v1036 = p1035.back.Y
	v_u_72(p1035, "Cape", "Body", v_u_8(0, v1036 + 0.07, 0.15), "flag")
	local v1037 = v_u_9(0, v1036 + 0.05, 0.8)
	local v1038 = p1035.cloth
	v_u_80(p1035, Instance.new("Part"), Vector3.new(1.96, 0.1, 1.35), v1037, v1038, nil)
	local v1039 = v_u_9(0, v1036 - 0.36, 1.52)
	local v1040 = p1035.cloth
	v_u_80(p1035, Instance.new("Part"), Vector3.new(1.96, 0.85, 0.1), v1039, v1040, nil)
	local v1041 = v_u_9(0, v1036 - 0.78, 1.52)
	local v1042 = p1035.glow
	local v1043 = v_u_12
	v_u_80(p1035, Instance.new("Part"), Vector3.new(2, 0.12, 0.14), v1041, v1042, v1043)
	p1035.cur = p1035.byName.Body or p1035.bones[1]
	local v1044 = v_u_9(0, v1036 + 0.1, 0.45)
	local v1045 = v_u_14
	v_u_80(p1035, Instance.new("Part"), Vector3.new(2.05, 0.32, 0.5), v1044, v1045, nil)
end
function v_u_926.pipe(p1046) -- name: pipe
	-- upvalues: (copy) v_u_8, (copy) v_u_28, (copy) v_u_80, (copy) v_u_9, (copy) v_u_10, (copy) v_u_29, (copy) v_u_30, (copy) v_u_12
	p1046.cur = p1046.byName.Head or p1046.bones[1]
	local v1047 = v_u_8(-0.95, p1046.mouthY, p1046.face - 0.03)
	local v1048 = v_u_8(-1.45, p1046.mouthY - 0.15, p1046.face - 0.65)
	local v1049 = v_u_28
	local v1050 = (v1047 + v1048) / 2
	local v1051 = v_u_8(0.1, 0.1, (v1048 - v1047).Magnitude)
	local v1052 = CFrame.lookAt(v1050, v1048)
	v_u_80(p1046, Instance.new("Part"), v1051, v1052, v1049, nil)
	local v1053 = v_u_9(v1048 + Vector3.new(0, 0.12, 0)) * v_u_10(0, 0, 1.5707963267948966)
	local v1054 = v_u_29
	local v1055 = Instance.new("Part")
	v1055.Shape = Enum.PartType.Cylinder
	v_u_80(p1046, v1055, Vector3.new(0.36, 0.3, 0.3), v1053, v1054, nil)
	local v1056 = v_u_9(v1048 + Vector3.new(0, 0.31, 0))
	local v1057 = v_u_30
	local v1058 = v_u_12
	v_u_80(p1046, Instance.new("Part"), Vector3.new(0.22, 0.05, 0.22), v1056, v1057, v1058)
end
function v_u_926.scroll(p1059) -- name: scroll
	-- upvalues: (copy) v_u_9, (copy) v_u_31, (copy) v_u_80, (copy) v_u_35
	p1059.cur = p1059.byName.Body or p1059.bones[1]
	local v1060 = p1059.back + Vector3.new(0, 0.25, 0.1)
	local v1061 = v_u_9(v1060)
	local v1062 = v_u_31
	local v1063 = Instance.new("Part")
	v1063.Shape = Enum.PartType.Cylinder
	v_u_80(p1059, v1063, Vector3.new(1.9, 0.55, 0.55), v1061, v1062, nil)
	local v1064 = v_u_9(v1060 + Vector3.new(-0.98, 0, 0))
	local v1065 = v_u_35
	local v1066 = Instance.new("Part")
	v1066.Shape = Enum.PartType.Cylinder
	v_u_80(p1059, v1066, Vector3.new(0.14, 0.6, 0.6), v1064, v1065, nil)
	local v1067 = v_u_9(v1060 + Vector3.new(0.98, 0, 0))
	local v1068 = v_u_35
	local v1069 = Instance.new("Part")
	v1069.Shape = Enum.PartType.Cylinder
	v_u_80(p1059, v1069, Vector3.new(0.14, 0.6, 0.6), v1067, v1068, nil)
end
function v_u_926.marks(p1070) -- name: marks
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_12, (copy) v_u_10
	p1070.cur = p1070.byName.Head or p1070.bones[1]
	local v1071 = p1070.face - 0.03
	if p1070.look.shape == "toad" then
		for v1072 = -1, 1, 2 do
			local v1073 = v_u_9(v1072 * p1070.eyeX, p1070.mouthY + 0.47, v1071)
			local v1074 = p1070.accent
			v_u_80(p1070, Instance.new("Part"), Vector3.new(0.18, 0.45, 0.06), v1073, v1074, nil)
		end
	else
		local v1075 = v_u_9(0, p1070.eyeY + 0.5, v1071)
		local v1076 = p1070.glow
		local v1077 = v_u_12
		v_u_80(p1070, Instance.new("Part"), Vector3.new(0.16, 0.42, 0.05), v1075, v1076, v1077)
		for v1078 = -1, 1, 2 do
			local v1079 = v_u_9(v1078 * (p1070.eyeX + 0.42), p1070.eyeY - 0.12, v1071) * v_u_10(0, 0, v1078 * 0.3)
			local v1080 = p1070.glow
			local v1081 = v_u_12
			v_u_80(p1070, Instance.new("Part"), Vector3.new(0.4, 0.1, 0.05), v1079, v1080, v1081)
		end
	end
end
function v_u_926.rope(p1082) -- name: rope
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_80, (copy) v_u_8, (copy) v_u_18, (copy) v_u_14
	p1082.cur = p1082.byName.Body or p1082.bones[1]
	local v1083 = p1082.neck
	if p1082.look.shape == "serpent" then
		local v1084 = v_u_9(v1083 + Vector3.new(0, 0, 0.55)) * v_u_10(0, 0, 1.5707963267948966)
		local v1085 = p1082.cloth
		local v1086 = Instance.new("Part")
		v1086.Shape = Enum.PartType.Cylinder
		v_u_80(p1082, v1086, Vector3.new(0.22, 1.05, 1.05), v1084, v1085, nil)
		local v1087 = v_u_9(v1083 + Vector3.new(0, 0, -0.04))
		local v1088 = p1082.cloth
		v_u_80(p1082, Instance.new("Part"), Vector3.new(0.22, 0.22, 0.16), v1087, v1088, nil)
		for v1089 = -1, 1, 2 do
			local v1090 = v_u_9(v1083 + v_u_8(v1089 * 0.27, 0.03, -0.06)) * v_u_10(0, 0, v1089 * 0.35)
			local v1091 = p1082.cloth
			v_u_80(p1082, Instance.new("Part"), Vector3.new(0.4, 0.26, 0.1), v1090, v1091, nil)
			local v1092 = v_u_9(v1083 + v_u_8(v1089 * 0.12, -0.25, -0.08)) * v_u_10(0, 0, v1089 * 0.2)
			local v1093 = p1082.cloth
			v_u_80(p1082, Instance.new("Part"), Vector3.new(0.11, 0.42, 0.08), v1092, v1093, nil)
		end
	else
		local v1094 = v_u_9(v1083)
		local v1095 = p1082.cloth
		v_u_80(p1082, Instance.new("Part"), Vector3.new(1.55, 0.26, 0.14), v1094, v1095, nil)
		local v1096 = v1083 + Vector3.new(0, -0.26, -0.1)
		local v1097 = v_u_18
		local v1098 = Instance.new("Part")
		v1098.Shape = Enum.PartType.Ball
		v_u_80(p1082, v1098, Vector3.new(0.36, 0.36, 0.36), v_u_9(v1096), v1097, nil)
		for v1099 = -1, 1, 2 do
			local v1100 = v_u_9(v1083 + v_u_8(v1099 * 0.42, -0.3, -0.06)) * v_u_10(0, 0, v1099 * 0.1)
			local v1101 = v_u_14
			v_u_80(p1082, Instance.new("Part"), Vector3.new(0.16, 0.42, 0.05), v1100, v1101, nil)
		end
	end
end
function v_u_926.mask(p1102) -- name: mask
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_14, (copy) v_u_80, (copy) v_u_12
	p1102.cur = p1102.byName.Head or p1102.bones[1]
	local v1103 = v_u_9(-(p1102.headS.X / 2 + 0.06), p1102.eyeY + 0.05, p1102.headC.Z - 0.15) * v_u_10(0, 0, 0.12)
	local v1104 = v_u_14
	v_u_80(p1102, Instance.new("Part"), Vector3.new(0.12, 0.85, 0.8), v1103, v1104, nil)
	for v1105 = -1, 1, 2 do
		local v1106 = v1103 * v_u_9(-0.07, 0.1, v1105 * 0.18) * v_u_10(v1105 * 0.3, 0, 0)
		local v1107 = p1102.glow
		local v1108 = v_u_12
		v_u_80(p1102, Instance.new("Part"), Vector3.new(0.04, 0.07, 0.24), v1106, v1107, v1108)
	end
end
function v_u_926.foxfire(p1109) -- name: foxfire
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_12, (copy) v_u_80, (copy) v_u_9
	local v1110 = p1109.look.spirit or "#5FD4FF"
	local v1111 = Color3.fromHex(v1110)
	for v1112 = 1, 2 do
		local v1113 = v1112 == 1 and 1 or -1
		v_u_72(p1109, "Orb" .. v1112, "Body", Vector3.new(0, 1.6, 0.3), "orbit", v1112 * 1.7, v1113)
		local v1114 = v_u_8(v1113 * 1.9, 2.1, 0.3)
		local v1115 = v_u_12
		local v1116 = Instance.new("Part")
		v1116.Shape = Enum.PartType.Ball
		v_u_80(p1109, v1116, Vector3.new(0.5, 0.5, 0.5), v_u_9(v1114), v1111, v1115)
	end
end
function v_u_926.fangs(p1117) -- name: fangs
	-- upvalues: (copy) v_u_8, (copy) v_u_14, (copy) v_u_80
	p1117.cur = p1117.byName.Head or p1117.bones[1]
	local v1118 = v_u_8(-0.24, p1117.mouthY - 0.24, p1117.face - 0.48)
	local v1119 = v_u_14
	local v1120 = -(Vector3.new(0.14, 0, 0)).Unit
	local v1121 = (Vector3.new(0, -0.22, 0)).Unit
	local v1122 = CFrame.fromMatrix(v1118 + Vector3.new(0.07, 0, 0) + Vector3.new(0, -0.11, 0), v1121:Cross(v1120), v1121, v1120)
	local v1123 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(0.14, 0, 0)).Magnitude)
	v_u_80(p1117, Instance.new("WedgePart"), v1123, v1122, v1119, nil)
	local v1124 = v_u_8(0.24, p1117.mouthY - 0.24, p1117.face - 0.48)
	local v1125 = v_u_14
	local v1126 = -(Vector3.new(-0.14, 0, 0)).Unit
	local v1127 = (Vector3.new(0, -0.22, 0)).Unit
	local v1128 = CFrame.fromMatrix(v1124 + Vector3.new(-0.07, 0, 0) + Vector3.new(0, -0.11, 0), v1127:Cross(v1126), v1127, v1126)
	local v1129 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(-0.14, 0, 0)).Magnitude)
	v_u_80(p1117, Instance.new("WedgePart"), v1129, v1128, v1125, nil)
end
function v_u_926.eyeline(p1130) -- name: eyeline
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_80
	p1130.cur = p1130.byName.Head or p1130.bones[1]
	for v1131 = -1, 1, 2 do
		local v1132 = v_u_9(v1131 * (p1130.eyeX + 0.12), p1130.eyeY + 0.36, p1130.face - 0.025) * v_u_10(0, 0, v1131 * 0.3)
		local v1133 = p1130.accent
		v_u_80(p1130, Instance.new("Part"), Vector3.new(0.62, 0.16, 0.05), v1132, v1133, nil)
	end
end
function v_u_926.crest(p1134) -- name: crest
	-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_12
	p1134.cur = p1134.byName.Head or p1134.bones[1]
	local v1135 = p1134.headC.Y + p1134.headS.Y / 2 - 0.02
	local v1136 = v_u_8(0, v1135, p1134.headC.Z + 0.4)
	local v1137 = p1134.body
	local v1138 = -(Vector3.new(0, 0, -0.75)).Unit
	local v1139 = (Vector3.new(0, 0.6, 0)).Unit
	local v1140 = CFrame.fromMatrix(v1136 + Vector3.new(0, 0, -0.375) + Vector3.new(0, 0.3, 0), v1139:Cross(v1138), v1139, v1138)
	local v1141 = v_u_8(0.18, (Vector3.new(0, 0.6, 0)).Magnitude, (Vector3.new(0, 0, -0.75)).Magnitude)
	v_u_80(p1134, Instance.new("WedgePart"), v1141, v1140, v1137, nil)
	local v1142 = v_u_8(0, v1135, p1134.headC.Z + 0.75)
	local v1143 = p1134.glow
	local v1144 = v_u_12
	local v1145 = -(Vector3.new(0, 0, -0.6)).Unit
	local v1146 = (Vector3.new(0, 0.42, 0)).Unit
	local v1147 = CFrame.fromMatrix(v1142 + Vector3.new(0, 0, -0.3) + Vector3.new(0, 0.21, 0), v1146:Cross(v1145), v1146, v1145)
	local v1148 = v_u_8(0.18, (Vector3.new(0, 0.42, 0)).Magnitude, (Vector3.new(0, 0, -0.6)).Magnitude)
	v_u_80(p1134, Instance.new("WedgePart"), v1148, v1147, v1143, v1144)
end
function v_u_926.horns(p1149) -- name: horns
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	p1149.cur = p1149.byName.Head or p1149.bones[1]
	for v1150 = -1, 1, 2 do
		local v1151 = v_u_9(v1150 * 0.55, p1149.headC.Y + p1149.headS.Y / 2 - 0.1, p1149.headC.Z + 0.3) * v_u_10(1.05, 0, -v1150 * 0.4)
		local v1152 = v1151 * v_u_9(0, 0.4, 0)
		local v1153 = p1149.glow
		local v1154 = v_u_12
		v_u_80(p1149, Instance.new("Part"), Vector3.new(0.2, 0.8, 0.2), v1152, v1153, v1154)
		local v1155 = v1151 * v_u_9(0, 0.85, 0) * v_u_10(0.35, 0, 0)
		local v1156 = p1149.accent
		v_u_80(p1149, Instance.new("Part"), Vector3.new(0.14, 0.4, 0.14), v1155, v1156, nil)
	end
end
function v_u_926.antlers(p1157) -- name: antlers
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_18, (copy) v_u_80, (copy) v_u_19, (copy) v_u_12
	p1157.cur = p1157.byName.Head or p1157.bones[1]
	for v1158 = -1, 1, 2 do
		local v1159 = v_u_9(v1158 * 0.55, p1157.headC.Y + p1157.headS.Y / 2 - 0.1, p1157.headC.Z + 0.2) * v_u_10(0.45, 0, -v1158 * 0.25)
		local v1160 = v1159 * v_u_9(0, 0.5, 0)
		local v1161 = v_u_18
		v_u_80(p1157, Instance.new("Part"), Vector3.new(0.26, 1, 0.26), v1160, v1161, nil)
		local v1162 = v1159 * v_u_9(0, 0.5, 0) * v_u_10(0, 0, -v1158 * 0.95) * v_u_9(0, 0.25, 0)
		local v1163 = v_u_19
		local v1164 = v_u_12
		v_u_80(p1157, Instance.new("Part"), Vector3.new(0.2, 0.5, 0.2), v1162, v1163, v1164)
	end
end
function v_u_926.mane(p1165) -- name: mane
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p1165.cur = p1165.byName.Head or p1165.bones[1]
	local v1166 = p1165.headC.Y + p1165.headS.Y / 2 - 0.02
	local v1167 = p1165.headC.Z + p1165.headS.Z / 2
	local v1168 = v_u_8(0, v1166, v1167)
	local v1169 = p1165.glow
	local v1170 = v_u_12
	local v1171 = -(Vector3.new(0, 0, -0.55)).Unit
	local v1172 = (Vector3.new(0, 0.5, 0)).Unit
	local v1173 = CFrame.fromMatrix(v1168 + Vector3.new(0, 0, -0.275) + Vector3.new(0, 0.25, 0), v1172:Cross(v1171), v1172, v1171)
	local v1174 = v_u_8(0.16, (Vector3.new(0, 0.5, 0)).Magnitude, (Vector3.new(0, 0, -0.55)).Magnitude)
	v_u_80(p1165, Instance.new("WedgePart"), v1174, v1173, v1169, v1170)
	local v1175 = v_u_8(0, v1166 - 0.35, v1167 - 0.02)
	local v1176 = p1165.glow
	local v1177 = v_u_12
	local v1178 = -(Vector3.new(0, -0.55, 0)).Unit
	local v1179 = (Vector3.new(0, 0, 0.5)).Unit
	local v1180 = CFrame.fromMatrix(v1175 + Vector3.new(0, -0.275, 0) + Vector3.new(0, 0, 0.25), v1179:Cross(v1178), v1179, v1178)
	local v1181 = v_u_8(0.16, (Vector3.new(0, 0, 0.5)).Magnitude, (Vector3.new(0, -0.55, 0)).Magnitude)
	v_u_80(p1165, Instance.new("WedgePart"), v1181, v1180, v1176, v1177)
end
function v_u_926.frills(p1182) -- name: frills
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p1182.cur = p1182.byName.Head or p1182.bones[1]
	for v1183 = -1, 1, 2 do
		local v1184 = v_u_8(v1183 * (p1182.headS.X / 2 - 0.05), p1182.eyeY + 0.45, p1182.headC.Z + 0.2)
		local v1185 = v_u_8(v1183 * 0.8, 0, 0)
		local v1186 = p1182.glow
		local v1187 = v_u_12
		local v1188 = -v1185.Unit
		local v1189 = (Vector3.new(0, -0.85, 0)).Unit
		local v1190 = CFrame.fromMatrix(v1184 + v1185 / 2 + Vector3.new(0, -0.425, 0), v1189:Cross(v1188), v1189, v1188)
		local v1191 = v_u_8(0.12, (Vector3.new(0, -0.85, 0)).Magnitude, v1185.Magnitude)
		v_u_80(p1182, Instance.new("WedgePart"), v1191, v1190, v1186, v1187)
	end
end
local function v_u_1200(p1192, p1193) -- name: cloud
	-- upvalues: (copy) v_u_14, (copy) v_u_80, (copy) v_u_9
	local v1194 = Color3.fromRGB(214, 20, 34)
	local v1195 = v_u_14
	v_u_80(p1192, Instance.new("Part"), Vector3.new(0.05, 0.46, 0.92), p1193, v1195, nil)
	local v1196 = p1193 * v_u_9(0, 0.22, -0.1)
	local v1197 = v_u_14
	v_u_80(p1192, Instance.new("Part"), Vector3.new(0.05, 0.3, 0.48), v1196, v1197, nil)
	local v1198 = p1193 * v_u_9(0.01, -0.02, 0)
	v_u_80(p1192, Instance.new("Part"), Vector3.new(0.07, 0.32, 0.78), v1198, v1194, nil)
	local v1199 = p1193 * v_u_9(0.01, 0.2, -0.1)
	v_u_80(p1192, Instance.new("Part"), Vector3.new(0.07, 0.2, 0.36), v1199, v1194, nil)
end
function v_u_926.clouds(p1201) -- name: clouds
	-- upvalues: (copy) v_u_8, (copy) v_u_1200, (copy) v_u_9, (copy) v_u_10
	p1201.cur = p1201.byName.Body or p1201.bones[1]
	for v1202 = -1, 1, 2 do
		local v1203 = v_u_1200
		local v1204 = v_u_9(p1201.bodyC + v_u_8(v1202 * (p1201.bodyS.X / 2 + 0.03), 0.05, 0.15))
		local v1205
		if v1202 < 0 then
			v1205 = v_u_10(0, 3.141592653589793, 0)
		else
			v1205 = CFrame.identity
		end
		v1203(p1201, v1204 * v1205)
	end
end
function v_u_926.claws(p1206) -- name: claws
	-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_9, (copy) v_u_10
	p1206.cur = p1206.byName.Body or p1206.bones[1]
	for v1207 = -1, 1, 2 do
		local v1208 = v_u_8(v1207 * 0.85, 0.55, -0.35)
		local v1209 = v_u_8(v1207 * 1.15, 0.65, -1.55)
		local v1210 = p1206.limbs
		local v1211 = (v1208 + v1209) / 2
		local v1212 = v_u_8(0.32, 0.32, (v1209 - v1208).Magnitude)
		local v1213 = CFrame.lookAt(v1211, v1209)
		v_u_80(p1206, Instance.new("Part"), v1212, v1213, v1210, nil)
		local v1214 = CFrame.lookAt(v1209, v1209 + (v1209 - v1208).Unit)
		local v1215 = v1214 * v_u_9(0, 0.13, -0.22) * v_u_10(0.25, 0, 0)
		local v1216 = p1206.body
		v_u_80(p1206, Instance.new("Part"), Vector3.new(0.3, 0.16, 0.55), v1215, v1216, nil)
		local v1217 = v1214 * v_u_9(0, -0.11, -0.2) * v_u_10(-0.2, 0, 0)
		local v1218 = p1206.body
		v_u_80(p1206, Instance.new("Part"), Vector3.new(0.3, 0.16, 0.5), v1217, v1218, nil)
	end
end
function v_u_926.fins(p1219) -- name: fins
	-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_9
	p1219.cur = p1219.byName.Head or p1219.bones[1]
	local v1220 = p1219.headC.Z + p1219.headS.Z / 2
	local v1221 = v_u_8(0, p1219.headC.Y + p1219.headS.Y / 2 - 0.02, v1220)
	local v1222 = p1219.body
	local v1223 = -(Vector3.new(0, 0, -1)).Unit
	local v1224 = (Vector3.new(0, 1, 0)).Unit
	local v1225 = CFrame.fromMatrix(v1221 + Vector3.new(0, 0, -0.5) + Vector3.new(0, 0.5, 0), v1224:Cross(v1223), v1224, v1223)
	local v1226 = v_u_8(0.2, (Vector3.new(0, 1, 0)).Magnitude, (Vector3.new(0, 0, -1)).Magnitude)
	v_u_80(p1219, Instance.new("WedgePart"), v1226, v1225, v1222, nil)
	for v1227 = -1, 1, 2 do
		local v1228 = v1227 * p1219.headS.X / 2
		local v1229 = v_u_8(v1228 - v1227 * 0.05, p1219.headC.Y - 0.35, p1219.headC.Z + 0.3)
		local v1230 = v_u_8(v1227 * 0.75, 0, 0)
		local v1231 = p1219.body
		local v1232 = -v1230.Unit
		local v1233 = (Vector3.new(0, 0, 0.6)).Unit
		local v1234 = CFrame.fromMatrix(v1229 + v1230 / 2 + Vector3.new(0, 0, 0.3), v1233:Cross(v1232), v1233, v1232)
		local v1235 = v_u_8(0.14, (Vector3.new(0, 0, 0.6)).Magnitude, v1230.Magnitude)
		v_u_80(p1219, Instance.new("WedgePart"), v1235, v1234, v1231, nil)
		for v1236 = 0, 1 do
			local v1237 = v_u_9(v1228 + v1227 * 0.01, p1219.headC.Y, p1219.headC.Z + 0.05 + v1236 * 0.22)
			local v1238 = p1219.accent
			v_u_80(p1219, Instance.new("Part"), Vector3.new(0.05, 0.4, 0.07), v1237, v1238, nil)
		end
	end
end
function v_u_926.gem(p1239) -- name: gem
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_18, (copy) v_u_80, (copy) v_u_12
	p1239.cur = p1239.byName.Head or p1239.bones[1]
	local v1240 = v_u_9(0, p1239.eyeY + 0.52, p1239.face - 0.04) * v_u_10(0, 0, 0.7853981633974483)
	local v1241 = v_u_18
	v_u_80(p1239, Instance.new("Part"), Vector3.new(0.34, 0.34, 0.06), v1240, v1241, nil)
	local v1242 = v1240 * v_u_9(0, 0, -0.03)
	local v1243 = p1239.look.spirit or "#7FE9FF"
	local v1244 = Color3.fromHex(v1243)
	local v1245 = v_u_12
	v_u_80(p1239, Instance.new("Part"), Vector3.new(0.22, 0.22, 0.08), v1242, v1244, v1245)
end
function v_u_926.tufts(p1246) -- name: tufts
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	p1246.cur = p1246.byName.Head or p1246.bones[1]
	for v1247 = -1, 1, 2 do
		local v1248 = v_u_8(v1247 * (p1246.headS.X / 2 - 0.05), p1246.headC.Y + p1246.headS.Y / 2 - 0.04, p1246.headC.Z - 0.2)
		local v1249 = v_u_8(-v1247 * 0.45, 0, 0)
		local v1250 = -v1247 * 0.3
		local v1251 = math.cos(v1250)
		local v1252 = math.sin(v1250)
		local v1253 = v_u_8(v1249.X * v1251 - v1249.Y * v1252, v1249.X * v1252 + v1249.Y * v1251, v1249.Z)
		local v1254 = -v1247 * 0.3
		local v1255 = math.cos(v1254)
		local v1256 = math.sin(v1254)
		local v1257 = v_u_8(v1255 * 0 - v1256 * 0.699999988079071, v1256 * 0 + v1255 * 0.699999988079071, 0)
		local v1258 = p1246.body
		local v1259 = -v1253.Unit
		local v1260 = v1257.Unit
		local v1261 = CFrame.fromMatrix(v1248 + v1253 / 2 + v1257 / 2, v1260:Cross(v1259), v1260, v1259)
		local v1262 = v_u_8(0.22, v1257.Magnitude, v1253.Magnitude)
		v_u_80(p1246, Instance.new("WedgePart"), v1262, v1261, v1258, nil)
	end
end
function v_u_926.barbels(p1263) -- name: barbels
	-- upvalues: (copy) v_u_8, (copy) v_u_19, (copy) v_u_12, (copy) v_u_80
	p1263.cur = p1263.byName.Head or p1263.bones[1]
	for v1264 = -1, 1, 2 do
		local v1265 = v_u_8(v1264 * 0.6, p1263.mouthY + 0.05, p1263.face - 0.35)
		local v1266 = v1265 + v_u_8(v1264 * 0.85, -0.4, 0.45)
		local v1267 = v_u_19
		local v1268 = v_u_12
		local v1269 = (v1265 + v1266) / 2
		local v1270 = v_u_8(0.08, 0.08, (v1266 - v1265).Magnitude)
		local v1271 = CFrame.lookAt(v1269, v1266)
		v_u_80(p1263, Instance.new("Part"), v1270, v1271, v1267, v1268)
	end
end
function v_u_926.halo(p1272) -- name: halo
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_19, (copy) v_u_12, (copy) v_u_80
	local v1273 = v_u_8(0, p1272.headC.Y + p1272.headS.Y / 2 + 0.95, p1272.headC.Z + 0.1)
	v_u_72(p1272, "Halo", "Head", v1273, "spin")
	for v1274 = 0, 5 do
		local v1275 = v1274 * 3.141592653589793 / 3
		local v1276 = v_u_9(v1273 + v_u_8(math.cos(v1275) * 0.55, 0, math.sin(v1275) * 0.55)) * v_u_10(0, -v1275, 0)
		local v1277 = v_u_19
		local v1278 = v_u_12
		v_u_80(p1272, Instance.new("Part"), Vector3.new(0.12, 0.1, 0.616), v1276, v1277, v1278)
	end
end
function v_u_926.pearl(p1279) -- name: pearl
	-- upvalues: (copy) v_u_72, (copy) v_u_12, (copy) v_u_80, (copy) v_u_9
	v_u_72(p1279, "Pearl", "Body", Vector3.new(0, 1.5, 0.3), "orbit", 0.6, 1)
	local v1280 = p1279.look.spirit or "#FFFFFF"
	local v1281 = Color3.fromHex(v1280)
	local v1282 = v_u_12
	local v1283 = Instance.new("Part")
	v1283.Shape = Enum.PartType.Ball
	v_u_80(p1279, v1283, Vector3.new(0.6, 0.6, 0.6), v_u_9(Vector3.new(2, 2.2, -0.3)), v1281, v1282)
end
function v_u_926.lotus(p1284) -- name: lotus
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_36, (copy) v_u_80, (copy) v_u_14, (copy) v_u_19, (copy) v_u_12
	p1284.cur = p1284.byName.Head or p1284.bones[1]
	local v1285 = p1284.look.shape == "toad" and 0.4 or 0
	local v1286 = v_u_9(0, p1284.headC.Y + p1284.headS.Y / 2 + 0.05, p1284.headC.Z + v1285)
	local v1287 = v_u_10(0, 0, 0.7853981633974483)
	for v1288 = 0, 5 do
		local v1289 = v1286 * v_u_10(0, v1288 * 3.141592653589793 / 3, 0) * v_u_9(0, 0.12, -0.34) * v_u_10(-0.6, 0, 0) * v1287
		local v1290 = v_u_36
		v_u_80(p1284, Instance.new("Part"), Vector3.new(0.5, 0.5, 0.08), v1289, v1290, nil)
	end
	for v1291 = 0, 3 do
		local v1292 = v1286 * v_u_10(0, v1291 * 3.141592653589793 / 2 + 0.4, 0) * v_u_9(0, 0.22, -0.15) * v_u_10(-0.35, 0, 0) * v1287
		local v1293 = v_u_14
		v_u_80(p1284, Instance.new("Part"), Vector3.new(0.34, 0.34, 0.06), v1292, v1293, nil)
	end
	local v1294 = v1286 * v_u_9(0, 0.2, 0)
	local v1295 = v_u_19
	local v1296 = v_u_12
	v_u_80(p1284, Instance.new("Part"), Vector3.new(0.24, 0.16, 0.24), v1294, v1295, v1296)
end
function v_u_926.shell(p1297) -- name: shell
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	p1297.cur = p1297.byName.Body or p1297.bones[1]
	local v1298 = p1297.bodyC.Y + p1297.bodyS.Y / 2
	local v1299 = p1297.bodyC.Z + 0.15
	local v1300 = p1297.bodyS.X
	local v1301 = p1297.bodyS.Z
	local v1302 = v_u_8(v1300 + 0.5, 0.14, v1301 + 0.45)
	local v1303 = v_u_9(0, v1298 - 0.22, v1299)
	local v1304 = p1297.accent
	v_u_80(p1297, Instance.new("Part"), v1302, v1303, v1304, nil)
	local v1305 = v_u_8(v1300 + 0.36, 0.55, v1301 + 0.3)
	local v1306 = v_u_9(0, v1298 + 0.05, v1299)
	local v1307 = p1297.cloth
	v_u_80(p1297, Instance.new("Part"), v1305, v1306, v1307, nil)
	local v1308 = v_u_8(v1300, 0.45, v1301 - 0.1)
	local v1309 = v_u_9(0, v1298 + 0.5, v1299)
	local v1310 = p1297.cloth
	v_u_80(p1297, Instance.new("Part"), v1308, v1309, v1310, nil)
	local v1311 = v_u_8(v1300 * 0.62, 0.3, v1301 * 0.58)
	local v1312 = v_u_9(0, v1298 + 0.82, v1299)
	local v1313 = p1297.cloth
	v_u_80(p1297, Instance.new("Part"), v1311, v1312, v1313, nil)
	for v1314 = -1, 1, 2 do
		local v1315 = v_u_8(0.08, 0.47, v1301 - 0.05)
		local v1316 = v_u_9(v1314 * v1300 * 0.22, v1298 + 0.5, v1299)
		local v1317 = p1297.accent
		v_u_80(p1297, Instance.new("Part"), v1315, v1316, v1317, nil)
	end
	local v1318 = v_u_8(v1300 + 0.02, 0.47, 0.08)
	local v1319 = v_u_9(0, v1298 + 0.5, v1299 + 0.1)
	local v1320 = p1297.accent
	v_u_80(p1297, Instance.new("Part"), v1318, v1319, v1320, nil)
end
function v_u_926.spots(p1321) -- name: spots
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	p1321.cur = p1321.byName.Head or p1321.bones[1]
	local v1322 = p1321.headC.Y + p1321.headS.Y / 2
	local v1323 = v_u_8(p1321.headS.X * 0.5, 0.08, p1321.headS.Z * 0.55)
	local v1324 = v_u_9(p1321.headS.X * 0.18, v1322 + 0.02, p1321.headC.Z + 0.1)
	local v1325 = p1321.accent
	v_u_80(p1321, Instance.new("Part"), v1323, v1324, v1325, nil)
	local v1326 = v_u_9(0.15, v1322 - 0.2, p1321.face - 0.02)
	local v1327 = p1321.accent
	v_u_80(p1321, Instance.new("Part"), Vector3.new(0.9, 0.3, 0.06), v1326, v1327, nil)
	local v1328 = v_u_8(0.08, p1321.headS.Y * 0.4, p1321.headS.Z * 0.45)
	local v1329 = v_u_9(-(p1321.headS.X / 2 + 0.02), p1321.headC.Y + p1321.headS.Y * 0.2, p1321.headC.Z + 0.15)
	local v1330 = p1321.accent
	v_u_80(p1321, Instance.new("Part"), v1328, v1329, v1330, nil)
	p1321.cur = p1321.byName.Body or p1321.bones[1]
	local v1331 = p1321.bodyC.Y + p1321.bodyS.Y / 2
	local v1332 = v_u_8(p1321.bodyS.X * 0.6, 0.08, p1321.bodyS.Z * 0.5)
	local v1333 = v_u_9(-p1321.bodyS.X * 0.12, v1331 + 0.02, p1321.bodyC.Z + 0.15)
	local v1334 = p1321.accent
	v_u_80(p1321, Instance.new("Part"), v1332, v1333, v1334, nil)
	for v1335 = -1, 1, 2 do
		local v1336 = v_u_8(0.08, p1321.bodyS.Y * 0.5, p1321.bodyS.Z * 0.4)
		local v1337 = v_u_9(v1335 * (p1321.bodyS.X / 2 + 0.02), p1321.bodyC.Y + 0.15, p1321.bodyC.Z + v1335 * 0.25)
		local v1338 = p1321.accent
		v_u_80(p1321, Instance.new("Part"), v1336, v1337, v1338, nil)
	end
end
function v_u_926.crescent(p1339) -- name: crescent
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_19, (copy) v_u_12, (copy) v_u_80
	p1339.cur = p1339.byName.Head or p1339.bones[1]
	local v1340 = p1339.eyeY + 0.55
	local v1341 = p1339.headC.Y + p1339.headS.Y / 2 - 0.3
	local v1342 = v_u_8(0, math.min(v1340, v1341), p1339.face - 0.04)
	for v1343 = 0, 4 do
		local v1344 = v1343 * 50 + 120
		local v1345 = math.rad(v1344)
		local v1346 = 3.141592653589793 * v1343 / 4
		local v1347 = v_u_8(math.sin(v1346) * 0.08 + 0.07, 0.2, 0.06)
		local v1348 = v_u_9(v1342 + v_u_8(math.cos(v1345) * 0.22, math.sin(v1345) * 0.22, 0)) * v_u_10(0, 0, v1345)
		local v1349 = v_u_19
		local v1350 = v_u_12
		v_u_80(p1339, Instance.new("Part"), v1347, v1348, v1349, v1350)
	end
end
function v_u_926.star(p1351) -- name: star
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_19, (copy) v_u_12, (copy) v_u_80
	p1351.cur = p1351.byName.Head or p1351.bones[1]
	local v1352 = p1351.eyeY + 0.55
	local v1353 = p1351.headC.Y + p1351.headS.Y / 2 - 0.3
	local v1354 = v_u_8(0, math.min(v1352, v1353), p1351.face - 0.04)
	local v1355 = v_u_9(v1354) * v_u_10(0, 0, 0.7853981633974483)
	local v1356 = v_u_19
	local v1357 = v_u_12
	v_u_80(p1351, Instance.new("Part"), Vector3.new(0.16, 0.16, 0.06), v1355, v1356, v1357)
	for v1358 = 0, 4 do
		local v1359 = v1358 * 3.141592653589793 * 2 / 5 + 1.5707963267948966
		local v1360 = v_u_9(v1354 + v_u_8(math.cos(v1359) * 0.14, math.sin(v1359) * 0.14, 0)) * v_u_10(0, 0, v1359 - 1.5707963267948966)
		local v1361 = v_u_19
		local v1362 = v_u_12
		v_u_80(p1351, Instance.new("Part"), Vector3.new(0.1, 0.2, 0.05), v1360, v1361, v1362)
	end
end
function v_u_926.starry(p1363) -- name: starry
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_19, (copy) v_u_12, (copy) v_u_80
	p1363.cur = p1363.byName.Body or p1363.bones[1]
	local v1364 = p1363.bodyC
	local v1365 = p1363.bodyS
	for _, v1366 in {
		{ 1, 0.25, -0.3 },
		{ 1, -0.15, 0.3 },
		{ -1, 0.2, 0.2 },
		{ -1, -0.2, -0.3 }
	} do
		local v1367 = v_u_9(v1364 + v_u_8(v1366[1] * (v1365.X / 2 + 0.02), v1366[2] * v1365.Y, v1366[3] * v1365.Z)) * v_u_10(0.7853981633974483, 0, 0)
		local v1368 = v_u_19
		local v1369 = v_u_12
		v_u_80(p1363, Instance.new("Part"), Vector3.new(0.06, 0.17, 0.17), v1367, v1368, v1369)
	end
	for v1370 = -1, 1, 2 do
		local v1371 = v_u_9(v1364 + v_u_8(v1370 * v1365.X * 0.25, v1365.Y / 2 + 0.02, v1370 * v1365.Z * 0.2)) * v_u_10(0, 0.7853981633974483, 0)
		local v1372 = v_u_19
		local v1373 = v_u_12
		v_u_80(p1363, Instance.new("Part"), Vector3.new(0.17, 0.06, 0.17), v1371, v1372, v1373)
	end
end
function v_u_926.rinne(p1374) -- name: rinne
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (copy) v_u_35, (copy) v_u_13, (copy) v_u_12, (copy) v_u_80
	p1374.cur = p1374.byName.Head or p1374.bones[1]
	local v1375 = v_u_8(0, p1374.eyeY + 0.48, p1374.face)
	local v1376 = v_u_10(0, 1.5707963267948966, 0)
	for v1377, v1378 in {
		0.68,
		0.58,
		0.48,
		0.42,
		0.3,
		0.24,
		0.1
	} do
		local v1379 = v1377 % 2 == 0
		local v1380 = v_u_9(v1375 + v_u_8(0, 0, -0.02 - v1377 * 0.012)) * v1376
		local v1381
		if v1379 then
			v1381 = v_u_35
		else
			v1381 = v_u_13
		end
		local v1382
		if v1379 then
			v1382 = v_u_12
		else
			v1382 = nil
		end
		local v1383 = Instance.new("Part")
		v1383.Shape = Enum.PartType.Cylinder
		v_u_80(p1374, v1383, v_u_8(0.04, v1378, v1378), v1380, v1381, v1382)
	end
	for v1384 = 0, 2 do
		local v1385 = v1384 * 3.141592653589793 * 2 / 3 + 1.5707963267948966
		local v1386 = v1375 + v_u_8(math.cos(v1385) * 0.265, math.sin(v1385) * 0.265, -0.1)
		local v1387 = v_u_13
		local v1388 = Instance.new("Part")
		v1388.Shape = Enum.PartType.Ball
		v_u_80(p1374, v1388, Vector3.new(0.09, 0.09, 0.09), v_u_9(v1386), v1387, nil)
	end
end
local function v_u_1392(p1389) -- name: snoutFront
	local v1390 = p1389.look.shape or "quad"
	if v1390 == "quad" then
		local v1391 = p1389.look.ears
		if v1391 == "fox" or (v1391 == "long" or v1391 == "arctic") then
			return p1389.face - 0.535
		elseif v1391 == "bunny" then
			return p1389.face - 0.19
		else
			return p1389.face - 0.31
		end
	elseif v1390 == "bat" then
		return p1389.face - 0.13
	elseif v1390 == "dragon" or v1390 == "leviathan" then
		return p1389.face - 0.5
	else
		return p1389.face - 0.06
	end
end
function v_u_926.fang(p1393) -- name: fang
	-- upvalues: (copy) v_u_1392, (copy) v_u_8, (copy) v_u_14, (copy) v_u_80
	p1393.cur = p1393.byName.Head or p1393.bones[1]
	local v1394 = v_u_8(0.26, p1393.mouthY - (p1393.look.shape == "bat" and 0.14 or 0.02), v_u_1392(p1393) + 0.03)
	local v1395 = v_u_14
	local v1396 = -(Vector3.new(-0.13, 0, 0)).Unit
	local v1397 = (Vector3.new(0, -0.22, 0)).Unit
	local v1398 = CFrame.fromMatrix(v1394 + Vector3.new(-0.065, 0, 0) + Vector3.new(0, -0.11, 0), v1397:Cross(v1396), v1397, v1396)
	local v1399 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(-0.13, 0, 0)).Magnitude)
	v_u_80(p1393, Instance.new("WedgePart"), v1399, v1398, v1395, nil)
end
function v_u_926.bite(p1400) -- name: bite
	-- upvalues: (copy) v_u_1392, (copy) v_u_8, (copy) v_u_14, (copy) v_u_80
	p1400.cur = p1400.byName.Head or p1400.bones[1]
	local v1401 = v_u_1392(p1400)
	local v1402 = v_u_8(-0.22, p1400.mouthY - 0.25, v1401 + 0.04)
	local v1403 = v_u_14
	local v1404 = -(Vector3.new(0.13, 0, 0)).Unit
	local v1405 = (Vector3.new(0, -0.24, 0)).Unit
	local v1406 = CFrame.fromMatrix(v1402 + Vector3.new(0.065, 0, 0) + Vector3.new(0, -0.12, 0), v1405:Cross(v1404), v1405, v1404)
	local v1407 = v_u_8(0.06, (Vector3.new(0, -0.24, 0)).Magnitude, (Vector3.new(0.13, 0, 0)).Magnitude)
	v_u_80(p1400, Instance.new("WedgePart"), v1407, v1406, v1403, nil)
	local v1408 = v_u_8(0.22, p1400.mouthY - 0.25, v1401 + 0.04)
	local v1409 = v_u_14
	local v1410 = -(Vector3.new(-0.13, 0, 0)).Unit
	local v1411 = (Vector3.new(0, -0.24, 0)).Unit
	local v1412 = CFrame.fromMatrix(v1408 + Vector3.new(-0.065, 0, 0) + Vector3.new(0, -0.12, 0), v1411:Cross(v1410), v1411, v1410)
	local v1413 = v_u_8(0.06, (Vector3.new(0, -0.24, 0)).Magnitude, (Vector3.new(-0.13, 0, 0)).Magnitude)
	v_u_80(p1400, Instance.new("WedgePart"), v1413, v1412, v1409, nil)
end
function v_u_926.tusks(p1414) -- name: tusks
	-- upvalues: (copy) v_u_1392, (copy) v_u_8, (copy) v_u_37, (copy) v_u_80
	p1414.cur = p1414.byName.Head or p1414.bones[1]
	local v1415 = v_u_1392(p1414)
	local v1416 = v_u_8(-0.36, p1414.mouthY - 0.24, v1415 - 0.02)
	local v1417 = v_u_37
	local v1418 = -(Vector3.new(0.14, 0, 0)).Unit
	local v1419 = (Vector3.new(0, 0.3, 0)).Unit
	local v1420 = CFrame.fromMatrix(v1416 + Vector3.new(0.07, 0, 0) + Vector3.new(0, 0.15, 0), v1419:Cross(v1418), v1419, v1418)
	local v1421 = v_u_8(0.08, (Vector3.new(0, 0.3, 0)).Magnitude, (Vector3.new(0.14, 0, 0)).Magnitude)
	v_u_80(p1414, Instance.new("WedgePart"), v1421, v1420, v1417, nil)
	local v1422 = v_u_8(0.36, p1414.mouthY - 0.24, v1415 - 0.02)
	local v1423 = v_u_37
	local v1424 = -(Vector3.new(-0.14, 0, 0)).Unit
	local v1425 = (Vector3.new(0, 0.3, 0)).Unit
	local v1426 = CFrame.fromMatrix(v1422 + Vector3.new(-0.07, 0, 0) + Vector3.new(0, 0.15, 0), v1425:Cross(v1424), v1425, v1424)
	local v1427 = v_u_8(0.08, (Vector3.new(0, 0.3, 0)).Magnitude, (Vector3.new(-0.14, 0, 0)).Magnitude)
	v_u_80(p1414, Instance.new("WedgePart"), v1427, v1426, v1423, nil)
end
function v_u_926.sabers(p1428) -- name: sabers
	-- upvalues: (copy) v_u_1392, (copy) v_u_14, (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p1428.cur = p1428.byName.Head or p1428.bones[1]
	local v1429 = v_u_1392(p1428)
	local v1430 = v_u_14:Lerp(p1428.glow, 0.4)
	local v1431 = v_u_8(-0.3, p1428.mouthY - 0.22, v1429 + 0.05)
	local v1432 = v_u_12
	local v1433 = -(Vector3.new(0.16, 0, 0)).Unit
	local v1434 = (Vector3.new(0, -0.72, 0)).Unit
	local v1435 = CFrame.fromMatrix(v1431 + Vector3.new(0.08, 0, 0) + Vector3.new(0, -0.36, 0), v1434:Cross(v1433), v1434, v1433)
	local v1436 = v_u_8(0.08, (Vector3.new(0, -0.72, 0)).Magnitude, (Vector3.new(0.16, 0, 0)).Magnitude)
	v_u_80(p1428, Instance.new("WedgePart"), v1436, v1435, v1430, v1432)
	local v1437 = v_u_8(0.3, p1428.mouthY - 0.22, v1429 + 0.05)
	local v1438 = v_u_12
	local v1439 = -(Vector3.new(-0.16, 0, 0)).Unit
	local v1440 = (Vector3.new(0, -0.72, 0)).Unit
	local v1441 = CFrame.fromMatrix(v1437 + Vector3.new(-0.08, 0, 0) + Vector3.new(0, -0.36, 0), v1440:Cross(v1439), v1440, v1439)
	local v1442 = v_u_8(0.08, (Vector3.new(0, -0.72, 0)).Magnitude, (Vector3.new(-0.16, 0, 0)).Magnitude)
	v_u_80(p1428, Instance.new("WedgePart"), v1442, v1441, v1430, v1438)
end
function v_u_926.onihorns(p1443) -- name: onihorns
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_37, (copy) v_u_80
	p1443.cur = p1443.byName.Head or p1443.bones[1]
	local v1444 = p1443.headC.Y + p1443.headS.Y / 2
	for v1445 = -1, 1, 2 do
		local v1446 = v_u_9(v1445 * 0.45, v1444 - 0.05, p1443.headC.Z - 0.2) * v_u_10(0, 0, -v1445 * 0.3)
		local v1447 = v1446 * v_u_9(0, 0.22, 0)
		local v1448 = v_u_37
		v_u_80(p1443, Instance.new("Part"), Vector3.new(0.34, 0.5, 0.34), v1447, v1448, nil)
		local v1449 = v1446 * v_u_9(0, 0.6, 0)
		local v1450 = v_u_37
		v_u_80(p1443, Instance.new("Part"), Vector3.new(0.2, 0.32, 0.2), v1449, v1450, nil)
	end
end
function v_u_926.demonhorns(p1451) -- name: demonhorns
	-- upvalues: (copy) v_u_38, (copy) v_u_14, (copy) v_u_12, (copy) v_u_8, (copy) v_u_80
	p1451.cur = p1451.byName.Head or p1451.bones[1]
	local v1452 = p1451.headS.X / 2.2 * (p1451.look.shape == "imp" and 0.72 or 1)
	local v1453 = p1451.headC.Y + p1451.headS.Y / 2
	local v1454
	if p1451.look.glow then
		v1454 = p1451.glow
	else
		v1454 = v_u_38:Lerp(v_u_14, 0.3)
	end
	local v1455
	if p1451.look.glow then
		v1455 = v_u_12
	else
		v1455 = nil
	end
	for v1456 = -1, 1, 2 do
		local v1457 = v_u_8(v1456 * 0.6 * p1451.headS.X / 2.2, v1453 - 0.15, p1451.headC.Z + 0.1)
		local v1458 = v1457 + v_u_8(v1456 * 0.42, 0.34, 0.06) * v1452
		local v1459 = v1458 + v_u_8(v1456 * 0.14, 0.42, 0.06) * v1452
		local v1460 = v1459 + v_u_8(-v1456 * 0.12, 0.34, 0.06) * v1452
		local v1461 = 0.36 * v1452
		local v1462 = v_u_38
		local v1463 = (v1458 - v1457).Unit * v1461 * 0.4
		local v1464 = v1457 - v1463
		local v1465 = v1458 + v1463
		local v1466 = (v1464 + v1465) / 2
		local v1467 = v_u_8(v1461, v1461, (v1465 - v1464).Magnitude)
		local v1468 = CFrame.lookAt(v1466, v1465)
		v_u_80(p1451, Instance.new("Part"), v1467, v1468, v1462, nil)
		local v1469 = 0.27 * v1452
		local v1470 = v_u_38
		local v1471 = (v1459 - v1458).Unit * v1469 * 0.4
		local v1472 = v1458 - v1471
		local v1473 = v1459 + v1471
		local v1474 = (v1472 + v1473) / 2
		local v1475 = v_u_8(v1469, v1469, (v1473 - v1472).Magnitude)
		local v1476 = CFrame.lookAt(v1474, v1473)
		v_u_80(p1451, Instance.new("Part"), v1475, v1476, v1470, nil)
		local v1477 = 0.18 * v1452
		local v1478 = (v1460 - v1459).Unit * v1477 * 0.4
		local v1479 = v1459 - v1478
		local v1480 = v1460 + v1478
		local v1481 = (v1479 + v1480) / 2
		local v1482 = v_u_8(v1477, v1477, (v1480 - v1479).Magnitude)
		local v1483 = CFrame.lookAt(v1481, v1480)
		v_u_80(p1451, Instance.new("Part"), v1482, v1483, v1454, v1455)
	end
end
function v_u_926.pitchfork(p1484) -- name: pitchfork
	-- upvalues: (copy) v_u_80, (copy) v_u_9, (copy) v_u_20, (copy) v_u_8
	p1484.cur = p1484.byName.ArmR or p1484.bones[1]
	local v1485 = p1484.limbs
	local v1486 = Instance.new("Part")
	v1486.Shape = Enum.PartType.Ball
	v_u_80(p1484, v1486, Vector3.new(0.36, 0.36, 0.36), v_u_9(Vector3.new(1.12, 0.92, -0.05)), v1485, nil)
	local v1487 = v_u_9(1.32, 1.25, -0.2)
	local v1488 = p1484.accent
	v_u_80(p1484, Instance.new("Part"), Vector3.new(0.13, 2.2, 0.13), v1487, v1488, nil)
	local v1489 = v_u_9(1.32, 2.38, -0.2)
	local v1490 = v_u_20
	v_u_80(p1484, Instance.new("Part"), Vector3.new(0.64, 0.12, 0.13), v1489, v1490, nil)
	for v1491 = -1, 1 do
		local v1492 = v1491 == 0 and 0.5 or 0.4
		local v1493 = v_u_8(0.11, v1492, 0.11)
		local v1494 = v_u_9(v1491 * 0.26 + 1.32, v1492 / 2 + 2.42, -0.2)
		local v1495 = v_u_20
		v_u_80(p1484, Instance.new("Part"), v1493, v1494, v1495, nil)
	end
end
function v_u_926.hourglass(p1496) -- name: hourglass
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	local v1497 = p1496.look.shape == "spider" and "Tail1" or "Body"
	p1496.cur = p1496.byName[v1497] or p1496.bones[1]
	local v1498 = p1496.bodyC
	local v1499 = p1496.bodyS
	local v1500 = v1498.Y + v1499.Y / 2 + 0.02
	local v1501 = v1499.Z * 0.3
	for v1502 = -1, 1, 2 do
		for v1503 = -1, 1, 2 do
			local v1504 = v_u_8(0, v1500, v1498.Z + v1502 * v1501)
			local v1505 = v_u_8(v1503 * 0.42, 0, 0)
			local v1506 = v_u_8(0, 0, -v1502 * v1501)
			local v1507 = p1496.glow
			local v1508 = v_u_12
			local v1509 = -v1505.Unit
			local v1510 = v1506.Unit
			local v1511 = CFrame.fromMatrix(v1504 + v1505 / 2 + v1506 / 2, v1510:Cross(v1509), v1510, v1509)
			local v1512 = v_u_8(0.06, v1506.Magnitude, v1505.Magnitude)
			v_u_80(p1496, Instance.new("WedgePart"), v1512, v1511, v1507, v1508)
		end
	end
	for v1513 = -1, 1, 2 do
		local v1514 = v1513 * (v1499.X / 2 + 0.01)
		local v1515 = v_u_8(v1514, v1498.Y - v1499.Y * 0.05, v1498.Z)
		local v1516 = v_u_8(v1514, v1498.Y + v1499.Y * 0.3, v1498.Z - v1499.Z * 0.3)
		local v1517 = p1496.glow
		local v1518 = v_u_12
		local v1519 = (v1515 - v1516).Unit * 0.08 * 0.4
		local v1520 = v1516 - v1519
		local v1521 = v1515 + v1519
		local v1522 = (v1520 + v1521) / 2
		local v1523 = v_u_8(0.08, 0.08, (v1521 - v1520).Magnitude)
		local v1524 = CFrame.lookAt(v1522, v1521)
		v_u_80(p1496, Instance.new("Part"), v1523, v1524, v1517, v1518)
		local v1525 = v_u_8(v1514, v1498.Y + v1499.Y * 0.15, v1498.Z + v1499.Z * 0.32)
		local v1526 = p1496.glow
		local v1527 = v_u_12
		local v1528 = (v1525 - v1515).Unit * 0.08 * 0.4
		local v1529 = v1515 - v1528
		local v1530 = v1525 + v1528
		local v1531 = (v1529 + v1530) / 2
		local v1532 = v_u_8(0.08, 0.08, (v1530 - v1529).Magnitude)
		local v1533 = CFrame.lookAt(v1531, v1530)
		v_u_80(p1496, Instance.new("Part"), v1532, v1533, v1526, v1527)
	end
end
function v_u_926.lionmane(p1534) -- name: lionmane
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_13, (copy) v_u_80, (copy) v_u_12
	p1534.cur = p1534.byName.Head or p1534.bones[1]
	local v1535 = v_u_8(0, p1534.headC.Y - 0.05, p1534.headC.Z + 0.55)
	local v1536 = p1534.headS.X + 0.8
	local v1537 = p1534.headS.Y + 0.7
	local v1538 = v_u_8(v1536, v1537, 1)
	local v1539 = v_u_9(v1535)
	local v1540, v1541 = p1534.body:Lerp(v_u_13, 0.55)
	v_u_80(p1534, Instance.new("Part"), v1538, v1539, v1540, v1541)
	local v1542 = v1535.Z - 0.3
	for v1543 = 0, 8 do
		local v1544 = v1543 * 33.75 + -45
		local v1545 = math.rad(v1544)
		local v1546 = v_u_8(math.cos(v1545), math.sin(v1545), 0)
		local v1547 = v_u_8(v1546.X * v1536 * 0.47, v1535.Y + v1546.Y * v1537 * 0.47, v1542)
		local v1548 = v_u_8(-v1546.Y, v1546.X, 0) * 0.5
		local v1549 = v1546 * 0.62
		local v1550 = p1534.glow
		local v1551 = v_u_12
		local v1552 = -v1548.Unit
		local v1553 = v1549.Unit
		local v1554 = CFrame.fromMatrix(v1547 + v1548 / 2 + v1549 / 2, v1553:Cross(v1552), v1553, v1552)
		local v1555 = v_u_8(0.34, v1549.Magnitude, v1548.Magnitude)
		v_u_80(p1534, Instance.new("WedgePart"), v1555, v1554, v1550, v1551)
	end
end
function v_u_926.lava(p1556) -- name: lava
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p1556.cur = p1556.byName.Body or p1556.bones[1]
	local v1557 = p1556.bodyC
	local v1558 = p1556.bodyS
	for v1559 = -1, 1, 2 do
		local v1560 = v1559 * (v1558.X / 2 + 0.01)
		local v1561 = {
			v_u_8(v1560, v1557.Y + v1558.Y * 0.32, v1557.Z - v1558.Z * 0.36),
			v_u_8(v1560, v1557.Y + v1558.Y * 0.02, v1557.Z - v1558.Z * 0.1),
			v_u_8(v1560, v1557.Y + v1558.Y * 0.2, v1557.Z + v1558.Z * 0.15),
			(v_u_8(v1560, v1557.Y - v1558.Y * 0.2, v1557.Z + v1558.Z * 0.38))
		}
		local v1562 = v1561[1]
		local v1563 = v1561[2]
		local v1564 = p1556.glow
		local v1565 = v_u_12
		local v1566 = (v1563 - v1562).Unit * 0.09 * 0.4
		local v1567 = v1562 - v1566
		local v1568 = v1563 + v1566
		local v1569 = (v1567 + v1568) / 2
		local v1570 = v_u_8(0.09, 0.09, (v1568 - v1567).Magnitude)
		local v1571 = CFrame.lookAt(v1569, v1568)
		v_u_80(p1556, Instance.new("Part"), v1570, v1571, v1564, v1565)
		local v1572 = v1561[2]
		local v1573 = v1561[3]
		local v1574 = p1556.glow
		local v1575 = v_u_12
		local v1576 = (v1573 - v1572).Unit * 0.09 * 0.4
		local v1577 = v1572 - v1576
		local v1578 = v1573 + v1576
		local v1579 = (v1577 + v1578) / 2
		local v1580 = v_u_8(0.09, 0.09, (v1578 - v1577).Magnitude)
		local v1581 = CFrame.lookAt(v1579, v1578)
		v_u_80(p1556, Instance.new("Part"), v1580, v1581, v1574, v1575)
		local v1582 = v1561[3]
		local v1583 = v1561[4]
		local v1584 = p1556.glow
		local v1585 = v_u_12
		local v1586 = (v1583 - v1582).Unit * 0.09 * 0.4
		local v1587 = v1582 - v1586
		local v1588 = v1583 + v1586
		local v1589 = (v1587 + v1588) / 2
		local v1590 = v_u_8(0.09, 0.09, (v1588 - v1587).Magnitude)
		local v1591 = CFrame.lookAt(v1589, v1588)
		v_u_80(p1556, Instance.new("Part"), v1590, v1591, v1584, v1585)
	end
end
function v_u_926.ruff(p1592) -- name: ruff
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	p1592.cur = p1592.byName.Head or p1592.bones[1]
	for v1593 = -1, 1, 2 do
		local v1594 = v_u_8(v1593 * (p1592.headS.X / 2 - 0.05), p1592.headC.Y - 0.2, p1592.headC.Z + 0.15)
		local v1595 = v_u_8(v1593 * 0.5, 0, 0)
		local v1596 = p1592.belly
		local v1597 = -v1595.Unit
		local v1598 = (Vector3.new(0, -0.6, 0)).Unit
		local v1599 = CFrame.fromMatrix(v1594 + v1595 / 2 + Vector3.new(0, -0.3, 0), v1598:Cross(v1597), v1598, v1597)
		local v1600 = v_u_8(0.6, (Vector3.new(0, -0.6, 0)).Magnitude, v1595.Magnitude)
		v_u_80(p1592, Instance.new("WedgePart"), v1600, v1599, v1596, nil)
	end
	p1592.cur = p1592.byName.Body or p1592.bones[1]
	local v1601 = p1592.neck + Vector3.new(0, 0.2, -0.04)
	local v1602 = p1592.belly
	local v1603 = -(Vector3.new(-0.62, 0, 0)).Unit
	local v1604 = (Vector3.new(0, -0.72, 0)).Unit
	local v1605 = CFrame.fromMatrix(v1601 + Vector3.new(-0.31, 0, 0) + Vector3.new(0, -0.36, 0), v1604:Cross(v1603), v1604, v1603)
	local v1606 = v_u_8(0.14, (Vector3.new(0, -0.72, 0)).Magnitude, (Vector3.new(-0.62, 0, 0)).Magnitude)
	v_u_80(p1592, Instance.new("WedgePart"), v1606, v1605, v1602, nil)
	local v1607 = p1592.neck + Vector3.new(0, 0.2, -0.04)
	local v1608 = p1592.belly
	local v1609 = -(Vector3.new(0.62, 0, 0)).Unit
	local v1610 = (Vector3.new(0, -0.72, 0)).Unit
	local v1611 = CFrame.fromMatrix(v1607 + Vector3.new(0.31, 0, 0) + Vector3.new(0, -0.36, 0), v1610:Cross(v1609), v1610, v1609)
	local v1612 = v_u_8(0.14, (Vector3.new(0, -0.72, 0)).Magnitude, (Vector3.new(0.62, 0, 0)).Magnitude)
	v_u_80(p1592, Instance.new("WedgePart"), v1612, v1611, v1608, nil)
end
function v_u_926.moonhalo(p1613) -- name: moonhalo
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (copy) v_u_12, (copy) v_u_80, (copy) v_u_44
	p1613.cur = p1613.byName.Head or p1613.bones[1]
	local v1614 = v_u_8(0, p1613.headC.Y + 0.65, p1613.headC.Z + p1613.headS.Z / 2 + 0.35)
	local v1615 = v_u_10(0, 1.5707963267948966, 0)
	local v1616 = v_u_9(v1614) * v1615
	local v1617 = p1613.glow
	local v1618 = v_u_12
	local v1619 = Instance.new("Part")
	v1619.Shape = Enum.PartType.Cylinder
	v_u_80(p1613, v1619, Vector3.new(0.14, 2.7, 2.7), v1616, v1617, v1618)
	local v1620 = v_u_9(v1614) * v1615
	local v1621, v1622 = p1613.glow:Lerp(v_u_44, 0.6)
	local v1623 = Instance.new("Part")
	v1623.Shape = Enum.PartType.Cylinder
	v_u_80(p1613, v1623, Vector3.new(0.06, 3, 3), v1620, v1621, v1622)
end
function v_u_926.vcape(p1624) -- name: vcape
	-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_23, (copy) v_u_12
	p1624.cur = p1624.byName.Head or p1624.bones[1]
	local v1625 = p1624.headC.Z + p1624.headS.Z / 2 + 0.06
	local v1626 = p1624.headC.Y - p1624.headS.Y / 2 + 0.1
	for v1627 = -1, 1, 2 do
		local v1628 = v_u_8(v1627 * 1.8, v1626, v1625 - 0.2)
		local v1629 = v_u_8(-v1627 * 1.55, 0, 0.2)
		local v1630 = p1624.cloth
		local v1631 = -v1629.Unit
		local v1632 = (Vector3.new(0, 2.05, 0)).Unit
		local v1633 = CFrame.fromMatrix(v1628 + v1629 / 2 + Vector3.new(0, 1.025, 0), v1632:Cross(v1631), v1632, v1631)
		local v1634 = v_u_8(0.1, (Vector3.new(0, 2.05, 0)).Magnitude, v1629.Magnitude)
		v_u_80(p1624, Instance.new("WedgePart"), v1634, v1633, v1630, nil)
		local v1635 = v_u_8(v1627 * 1.66, v1626 + 0.15, v1625 - 0.27)
		local v1636 = v_u_8(-v1627 * 1.3, 0, 0.16)
		local v1637 = p1624.accent
		local v1638 = -v1636.Unit
		local v1639 = (Vector3.new(0, 1.7, 0)).Unit
		local v1640 = CFrame.fromMatrix(v1635 + v1636 / 2 + Vector3.new(0, 0.85, 0), v1639:Cross(v1638), v1639, v1638)
		local v1641 = v_u_8(0.06, (Vector3.new(0, 1.7, 0)).Magnitude, v1636.Magnitude)
		v_u_80(p1624, Instance.new("WedgePart"), v1641, v1640, v1637, nil)
	end
	local v1642 = p1624.back.Y
	v_u_72(p1624, "Cape", "Body", v_u_8(0, v1642 + 0.07, 0.15), "flag")
	local v1643 = v_u_9(0, v1642 + 0.05, 0.8)
	local v1644 = p1624.cloth
	v_u_80(p1624, Instance.new("Part"), Vector3.new(1.96, 0.1, 1.35), v1643, v1644, nil)
	local v1645 = v_u_9(0, v1642 - 0.38, 1.52)
	local v1646 = p1624.cloth
	v_u_80(p1624, Instance.new("Part"), Vector3.new(1.96, 0.9, 0.1), v1645, v1646, nil)
	local v1647 = v_u_9(0, v1642 - 0.84, 1.52)
	local v1648 = p1624.accent
	v_u_80(p1624, Instance.new("Part"), Vector3.new(2, 0.14, 0.14), v1647, v1648, nil)
	p1624.cur = p1624.byName.Body or p1624.bones[1]
	local v1649 = v_u_9(p1624.neck + Vector3.new(0, 0.08, -0.04)) * v_u_10(0, 0, 0.7853981633974483)
	local v1650 = v_u_23
	local v1651 = v_u_12
	v_u_80(p1624, Instance.new("Part"), Vector3.new(0.3, 0.3, 0.1), v1649, v1650, v1651)
end
function v_u_926.lily(p1652) -- name: lily
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_41, (copy) v_u_80, (copy) v_u_8, (copy) v_u_12
	p1652.cur = p1652.byName.Head or p1652.bones[1]
	local v1653 = v_u_9(p1652.headS.X / 2 - 0.05, p1652.headC.Y + p1652.headS.Y / 2 + 0.02, p1652.headC.Z - 0.05) * v_u_10(0, 0, -0.4)
	for v1654 = 0, 5 do
		local v1655 = v1653 * v_u_10(0, v1654 * 3.141592653589793 / 3, 0) * v_u_10(0.6, 0, 0) * v_u_9(0, 0, -0.4)
		local v1656 = v_u_41
		v_u_80(p1652, Instance.new("Part"), Vector3.new(0.22, 0.09, 0.85), v1655, v1656, nil)
	end
	for v1657 = 0, 2 do
		local v1658 = v1657 * 3.141592653589793 * 2 / 3 + 0.5
		local v1659 = v1653 * v_u_8(math.cos(v1658) * 0.45, 0.95, math.sin(v1658) * 0.45)
		local v1660 = v1653.Position
		local v1661 = p1652.glow
		local v1662 = v_u_12
		local v1663 = (v1660 + v1659) / 2
		local v1664 = v_u_8(0.09, 0.09, (v1659 - v1660).Magnitude)
		local v1665 = CFrame.lookAt(v1663, v1659)
		v_u_80(p1652, Instance.new("Part"), v1664, v1665, v1661, v1662)
	end
	local v1666 = p1652.glow
	local v1667 = v_u_12
	v_u_80(p1652, Instance.new("Part"), Vector3.new(0.3, 0.2, 0.3), v1653, v1666, v1667)
end
function v_u_926.thorns(p1668) -- name: thorns
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_42, (copy) v_u_80, (copy) v_u_12
	p1668.cur = p1668.byName.Head or p1668.bones[1]
	local v1669 = p1668.headC.Y + p1668.headS.Y / 2 - 0.2
	local v1670 = v_u_8(p1668.headS.X + 0.1, 0.18, p1668.headS.Z + 0.1)
	local v1671 = v_u_9(0, v1669, p1668.headC.Z)
	local v1672 = v_u_42
	v_u_80(p1668, Instance.new("Part"), v1670, v1671, v1672, nil)
	for v1673 = 0, 6 do
		local v1674 = v1673 * 3.141592653589793 * 2 / 7 + 0.2
		local v1675 = v_u_8(math.cos(v1674), 0, (math.sin(v1674)))
		local v1676 = v_u_8(v1675.X * (p1668.headS.X / 2 + 0.05), v1669 + 0.05, p1668.headC.Z + v1675.Z * (p1668.headS.Z / 2 + 0.05))
		local v1677 = CFrame.lookAt(v1676, v1676 + v1675 + Vector3.new(0, 1.1, 0)) * v_u_9(0, 0, -0.16)
		local v1678 = v_u_42
		v_u_80(p1668, Instance.new("Part"), Vector3.new(0.12, 0.12, 0.4), v1677, v1678, nil)
	end
	local v1679 = v_u_8(-0.42, v1669 + 0.06, p1668.face - 0.04)
	local v1680 = p1668.glow
	local v1681 = v_u_12
	local v1682 = Instance.new("Part")
	v1682.Shape = Enum.PartType.Ball
	v_u_80(p1668, v1682, Vector3.new(0.22, 0.22, 0.22), v_u_9(v1679), v1680, v1681)
	local v1683 = v_u_8(0.42, v1669 + 0.06, p1668.face - 0.04)
	local v1684 = p1668.glow
	local v1685 = v_u_12
	local v1686 = Instance.new("Part")
	v1686.Shape = Enum.PartType.Ball
	v_u_80(p1668, v1686, Vector3.new(0.22, 0.22, 0.22), v_u_9(v1683), v1684, v1685)
end
function v_u_926.drop(p1687) -- name: drop
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80, (copy) v_u_9, (copy) v_u_10
	p1687.cur = p1687.byName.Head or p1687.bones[1]
	local v1688 = p1687.eyeY + 0.55
	local v1689 = p1687.headC.Y + p1687.headS.Y / 2 - 0.3
	local v1690 = v_u_8(0, math.min(v1688, v1689), p1687.face - 0.04)
	local v1691 = 0
	local v1692 = p1687.look.gear
	local v1693
	if v1692 == nil then
		v1693 = false
	else
		v1693 = table.find(v1692, "thorns") ~= nil
	end
	local v1694 = v1690 - v_u_8(v1691, v1693 and 0.14 or 0, 0)
	local v1695 = p1687.glow
	local v1696 = v_u_12
	local v1697 = Instance.new("Part")
	v1697.Shape = Enum.PartType.Ball
	v_u_80(p1687, v1697, Vector3.new(0.3, 0.3, 0.3), v_u_9(v1694), v1695, v1696)
	local v1698 = v_u_9(v1694 + Vector3.new(0, 0.15, 0)) * v_u_10(0, 0, 0.7853981633974483)
	local v1699 = p1687.glow
	local v1700 = v_u_12
	v_u_80(p1687, Instance.new("Part"), Vector3.new(0.17, 0.17, 0.1), v1698, v1699, v1700)
end
local function v_u_1719(p1701, p1702) -- name: scarf
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_10, (copy) v_u_13, (copy) v_u_43
	p1701.cur = p1701.byName.Body or p1701.bones[1]
	local v1703 = p1701.neck
	local v1704 = p1701.bodyS.X + 0.15
	local v1705 = v_u_8(math.max(v1704, 1.6), 0.46, 0.95)
	local v1706 = v_u_9(0, v1703.Y + 0.04, v1703.Z + 0.4)
	local v1707 = p1701.cloth
	v_u_80(p1701, Instance.new("Part"), v1705, v1706, v1707, nil)
	local v1708 = v_u_9(v1703 + Vector3.new(0.45, -0.38, -0.12)) * v_u_10(0, 0, 0.1)
	local v1709 = p1701.cloth
	v_u_80(p1701, Instance.new("Part"), Vector3.new(0.4, 0.78, 0.12), v1708, v1709, nil)
	local v1710 = v_u_9(v1703 + Vector3.new(0.8, -0.26, -0.08)) * v_u_10(0, 0, -0.18)
	local v1711, v1712 = p1701.cloth:Lerp(v_u_13, 0.2)
	v_u_80(p1701, Instance.new("Part"), Vector3.new(0.32, 0.55, 0.1), v1710, v1711, v1712)
	if p1702 then
		local v1713 = v_u_9(-0.42, v1703.Y + 0.04, v1703.Z + 0.4)
		local v1714 = v_u_43
		v_u_80(p1701, Instance.new("Part"), Vector3.new(0.16, 0.48, 0.97), v1713, v1714, nil)
		local v1715 = v_u_9(0.42, v1703.Y + 0.04, v1703.Z + 0.4)
		local v1716 = v_u_43
		v_u_80(p1701, Instance.new("Part"), Vector3.new(0.16, 0.48, 0.97), v1715, v1716, nil)
		local v1717 = v_u_9(v1703 + Vector3.new(0.46, -0.46, -0.12)) * v_u_10(0, 0, 0.1)
		local v1718 = v_u_43
		v_u_80(p1701, Instance.new("Part"), Vector3.new(0.42, 0.13, 0.14), v1717, v1718, nil)
	end
end
function v_u_926.scarf(p1720) -- name: scarf
	-- upvalues: (copy) v_u_1719
	v_u_1719(p1720, false)
end
function v_u_926.tigerscarf(p1721) -- name: tigerscarf
	-- upvalues: (copy) v_u_1719
	v_u_1719(p1721, true)
end
function v_u_926.kanabo(p1722) -- name: kanabo
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_28, (copy) v_u_80, (copy) v_u_40, (copy) v_u_18
	p1722.cur = p1722.byName.Body or p1722.bones[1]
	local v1723 = v_u_9(p1722.back + Vector3.new(0, 0.4, 0.15)) * v_u_10(0, 0, 0.8)
	local v1724 = v1723 * v_u_9(-0.6, 0, 0)
	local v1725 = v_u_28
	local v1726 = Instance.new("Part")
	v1726.Shape = Enum.PartType.Cylinder
	v_u_80(p1722, v1726, Vector3.new(1, 0.24, 0.24), v1724, v1725, nil)
	local v1727 = v1723 * v_u_9(0.5, 0, 0)
	local v1728 = v_u_40
	local v1729 = Instance.new("Part")
	v1729.Shape = Enum.PartType.Cylinder
	v_u_80(p1722, v1729, Vector3.new(1.25, 0.5, 0.5), v1727, v1728, nil)
	for v1730 = 0, 3 do
		local v1731 = v1730 * 3.141592653589793 / 2 + 0.4
		local v1732 = v1723 * v_u_9(v1730 % 2 * 0.5 + 0.25, math.cos(v1731) * 0.27, math.sin(v1731) * 0.27)
		local v1733 = v_u_18
		v_u_80(p1722, Instance.new("Part"), Vector3.new(0.16, 0.16, 0.16), v1732, v1733, nil)
	end
end
function v_u_926.beanie(p1734) -- name: beanie
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_14, (copy) v_u_80
	p1734.cur = p1734.byName.Head or p1734.bones[1]
	local v1735 = p1734.headC.Y + p1734.headS.Y / 2
	local v1736 = v_u_8(p1734.headS.X + 0.08, 0.26, p1734.headS.Z + 0.08)
	local v1737 = v_u_9(0, v1735 - 0.1, p1734.headC.Z)
	local v1738, v1739 = v_u_14:Lerp(p1734.cloth, 0.25)
	v_u_80(p1734, Instance.new("Part"), v1736, v1737, v1738, v1739)
	local v1740 = v_u_8(p1734.headS.X * 0.88, 0.5, p1734.headS.Z * 0.88)
	local v1741 = v_u_9(0, v1735 + 0.22, p1734.headC.Z + 0.05)
	local v1742 = p1734.cloth
	v_u_80(p1734, Instance.new("Part"), v1740, v1741, v1742, nil)
	local v1743 = v_u_8(0, v1735 + 0.6, p1734.headC.Z + 0.1)
	local v1744 = v_u_14
	local v1745 = Instance.new("Part")
	v1745.Shape = Enum.PartType.Ball
	v_u_80(p1734, v1745, Vector3.new(0.5, 0.5, 0.5), v_u_9(v1743), v1744, nil)
end
function v_u_926.snowflake(p1746) -- name: snowflake
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	p1746.cur = p1746.byName.Head or p1746.bones[1]
	local v1747 = p1746.eyeY + 0.55
	local v1748 = p1746.headC.Y + p1746.headS.Y / 2 - 0.3
	local v1749 = v_u_8(0, math.min(v1747, v1748), p1746.face - 0.04)
	local v1750 = p1746.look.glow or "#6FC8FF"
	local v1751 = Color3.fromHex(v1750)
	for v1752 = 0, 2 do
		local v1753 = v_u_9(v1749) * v_u_10(0, 0, v1752 * 3.141592653589793 / 3)
		local v1754 = v_u_12
		v_u_80(p1746, Instance.new("Part"), Vector3.new(0.08, 0.42, 0.05), v1753, v1751, v1754)
	end
end
function v_u_926.icecrown(p1755) -- name: icecrown
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_39, (copy) v_u_12, (copy) v_u_80
	p1755.cur = p1755.byName.Head or p1755.bones[1]
	local v1756 = p1755.headC.Y + p1755.headS.Y / 2
	for v1757, v1758 in {
		0.42,
		0.62,
		0.82,
		0.62,
		0.42
	} do
		local v1759 = v1757 - 3
		local v1760 = v_u_9(v1759 * 0.28, v1756 - 0.08 + v1758 / 2, p1755.headC.Z - 0.15 + math.abs(v1759) * 0.14) * v_u_10(0, 0, -v1759 * 0.16) * v_u_10(0, 0.7853981633974483, 0)
		local v1761 = v1757 % 2 == 1
		local v1762 = v_u_8(0.2, v1758, 0.2)
		local v1763
		if v1761 then
			v1763 = p1755.glow
		else
			v1763 = v_u_39
		end
		local v1764
		if v1761 then
			v1764 = v_u_12
		else
			v1764 = nil
		end
		v_u_80(p1755, Instance.new("Part"), v1762, v1760, v1763, v1764)
	end
end
function v_u_926.crystals(p1765) -- name: crystals
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_39, (copy) v_u_12, (copy) v_u_80
	p1765.cur = p1765.byName.Body or p1765.bones[1]
	for v1766, v1767 in {
		{
			-0.42,
			0,
			0.62,
			0.35
		},
		{
			0,
			-0.1,
			0.95,
			0
		},
		{
			0.42,
			0,
			0.7,
			-0.35
		},
		{
			0.1,
			0.5,
			0.55,
			-0.15
		}
	} do
		local v1768 = v1767[3]
		local v1769 = v_u_9(p1765.back + v_u_8(v1767[1], 0, v1767[2])) * v_u_10(0.35, 0, v1767[4]) * v_u_9(0, v1768 / 2 - 0.05, 0) * v_u_10(0, 0.7853981633974483, 0)
		local v1770 = v1766 % 2 == 0
		local v1771 = v_u_8(0.26, v1768, 0.26)
		local v1772
		if v1770 then
			v1772 = p1765.glow
		else
			v1772 = v_u_39
		end
		local v1773
		if v1770 then
			v1773 = v_u_12
		else
			v1773 = nil
		end
		v_u_80(p1765, Instance.new("Part"), v1771, v1769, v1772, v1773)
	end
end
function v_u_926.tigerstripes(p1774) -- name: tigerstripes
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	p1774.cur = p1774.byName.Body or p1774.bones[1]
	local v1775 = p1774.bodyC
	local v1776 = p1774.bodyS
	for v1777 = -1, 1 do
		local v1778 = v1775.Z + v1777 * v1776.Z * 0.28
		local v1779 = v_u_8(v1776.X * 0.7, 0.06, 0.16)
		local v1780 = v_u_9(0, v1775.Y + v1776.Y / 2 + 0.02, v1778)
		local v1781 = p1774.accent
		v_u_80(p1774, Instance.new("Part"), v1779, v1780, v1781, nil)
		for v1782 = -1, 1, 2 do
			local v1783 = v_u_8(0.06, v1776.Y * 0.5, 0.16)
			local v1784 = v_u_9(v1782 * (v1776.X / 2 + 0.02), v1775.Y + v1776.Y * 0.2, v1778)
			local v1785 = p1774.accent
			v_u_80(p1774, Instance.new("Part"), v1783, v1784, v1785, nil)
		end
	end
	p1774.cur = p1774.byName.Head or p1774.bones[1]
	local v1786 = p1774.headC.Y + p1774.headS.Y / 2
	for v1787 = -1, 1 do
		local v1788 = v1787 == 0 and 0.5 or 0.36
		local v1789 = v_u_8(0.15, v1788, 0.06)
		local v1790 = v_u_9(v1787 * 0.32, v1786 - v1788 / 2, p1774.face - 0.03)
		local v1791 = p1774.accent
		v_u_80(p1774, Instance.new("Part"), v1789, v1790, v1791, nil)
	end
	for v1792 = -1, 1, 2 do
		local v1793 = v_u_9(v1792 * (p1774.headS.X / 2 + 0.02), p1774.mouthY + 0.15, p1774.headC.Z - 0.3)
		local v1794 = p1774.accent
		v_u_80(p1774, Instance.new("Part"), Vector3.new(0.06, 0.12, 0.45), v1793, v1794, nil)
	end
end
function v_u_926.plumes(p1795) -- name: plumes
	-- upvalues: (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_80, (copy) v_u_12
	local v1796 = p1795.look.shape == "bird" and Vector3.new(0, 1.05, 1) or p1795.tailAt
	for v1797 = 1, 3 do
		v_u_72(p1795, "Plume" .. v1797, "Body", v1796, "flag", v1797 * 0.9)
		local v1798 = v1797 == 2 and 1.9 or 1.45
		local v1799 = v_u_9(v1796) * v_u_10(0, (v1797 - 2) * 0.38, 0) * v_u_10(0.05, 0, 0)
		local v1800 = v_u_8(0.32, 0.1, v1798)
		local v1801 = v1799 * v_u_9(0, 0, v1798 / 2)
		local v1802 = p1795.body
		v_u_80(p1795, Instance.new("Part"), v1800, v1801, v1802, nil)
		local v1803 = v1799 * v_u_9(0, 0, v1798 + 0.22) * v_u_10(0, 0.7853981633974483, 0)
		local v1804 = p1795.glow
		local v1805 = v_u_12
		v_u_80(p1795, Instance.new("Part"), Vector3.new(0.46, 0.12, 0.55), v1803, v1804, v1805)
	end
end
function v_u_926.lure(p1806) -- name: lure
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_80, (copy) v_u_12, (copy) v_u_9
	local v1807 = p1806.headC.Y + p1806.headS.Y / 2
	local v1808 = v_u_8(0, v1807 - 0.05, p1806.headC.Z + 0.15)
	v_u_72(p1806, "Lure", "Head", v1808, "lure", 0.4)
	local v1809 = v_u_8(0, v1807 + 0.8, p1806.headC.Z - 0.3)
	local v1810 = v_u_8(0, v1807 + 0.6, p1806.face - 0.5)
	local v1811 = p1806.limbs
	local v1812 = (v1809 - v1808).Unit * 0.1 * 0.4
	local v1813 = v1808 - v1812
	local v1814 = v1809 + v1812
	local v1815 = (v1813 + v1814) / 2
	local v1816 = v_u_8(0.1, 0.1, (v1814 - v1813).Magnitude)
	local v1817 = CFrame.lookAt(v1815, v1814)
	v_u_80(p1806, Instance.new("Part"), v1816, v1817, v1811, nil)
	local v1818 = p1806.limbs
	local v1819 = (v1810 - v1809).Unit * 0.09 * 0.4
	local v1820 = v1809 - v1819
	local v1821 = v1810 + v1819
	local v1822 = (v1820 + v1821) / 2
	local v1823 = v_u_8(0.09, 0.09, (v1821 - v1820).Magnitude)
	local v1824 = CFrame.lookAt(v1822, v1821)
	v_u_80(p1806, Instance.new("Part"), v1823, v1824, v1818, nil)
	local v1825 = v1810 + Vector3.new(0, -0.15, 0)
	local v1826 = p1806.look.spirit or (p1806.look.glow or "#7FFFE0")
	local v1827 = Color3.fromHex(v1826)
	local v1828 = v_u_12
	local v1829 = Instance.new("Part")
	v1829.Shape = Enum.PartType.Ball
	v_u_80(p1806, v1829, Vector3.new(0.46, 0.46, 0.46), v_u_9(v1825), v1827, v1828)
end
function v_u_926.jaws(p1830) -- name: jaws
	-- upvalues: (copy) v_u_9, (copy) v_u_13, (copy) v_u_80, (copy) v_u_8, (copy) v_u_14
	p1830.cur = p1830.byName.Head or p1830.bones[1]
	local v1831 = p1830.face
	local v1832 = p1830.mouthY
	local v1833 = v_u_9(0, v1832 + 0.1, v1831 - 0.2)
	local v1834 = v_u_13
	v_u_80(p1830, Instance.new("Part"), Vector3.new(1.25, 0.32, 0.1), v1833, v1834, nil)
	local v1835 = v_u_9(0, v1832 - 0.2, v1831 - 0.25)
	local v1836 = p1830.body
	v_u_80(p1830, Instance.new("Part"), Vector3.new(1.55, 0.34, 0.5), v1835, v1836, nil)
	for v1837 = 0, 3 do
		local v1838 = v_u_8(v1837 * 0.3 + -0.55, v1832 - 0.03, v1831 - 0.45)
		local v1839 = v_u_14
		local v1840 = -(Vector3.new(0.14, 0, 0)).Unit
		local v1841 = (Vector3.new(0, 0.24, 0)).Unit
		local v1842 = CFrame.fromMatrix(v1838 + Vector3.new(0.07, 0, 0) + Vector3.new(0, 0.12, 0), v1841:Cross(v1840), v1841, v1840)
		local v1843 = v_u_8(0.06, (Vector3.new(0, 0.24, 0)).Magnitude, (Vector3.new(0.14, 0, 0)).Magnitude)
		v_u_80(p1830, Instance.new("WedgePart"), v1843, v1842, v1839, nil)
	end
	local v1844 = v_u_8(-0.34, v1832 + 0.26, v1831 - 0.27)
	local v1845 = v_u_14
	local v1846 = -(Vector3.new(0.12, 0, 0)).Unit
	local v1847 = (Vector3.new(0, -0.2, 0)).Unit
	local v1848 = CFrame.fromMatrix(v1844 + Vector3.new(0.06, 0, 0) + Vector3.new(0, -0.1, 0), v1847:Cross(v1846), v1847, v1846)
	local v1849 = v_u_8(0.06, (Vector3.new(0, -0.2, 0)).Magnitude, (Vector3.new(0.12, 0, 0)).Magnitude)
	v_u_80(p1830, Instance.new("WedgePart"), v1849, v1848, v1845, nil)
	local v1850 = v_u_8(0.34, v1832 + 0.26, v1831 - 0.27)
	local v1851 = v_u_14
	local v1852 = -(Vector3.new(-0.12, 0, 0)).Unit
	local v1853 = (Vector3.new(0, -0.2, 0)).Unit
	local v1854 = CFrame.fromMatrix(v1850 + Vector3.new(-0.06, 0, 0) + Vector3.new(0, -0.1, 0), v1853:Cross(v1852), v1853, v1852)
	local v1855 = v_u_8(0.06, (Vector3.new(0, -0.2, 0)).Magnitude, (Vector3.new(-0.12, 0, 0)).Magnitude)
	v_u_80(p1830, Instance.new("WedgePart"), v1855, v1854, v1851, nil)
end
function v_u_926.glowdots(p1856) -- name: glowdots
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	if p1856.look.shape ~= "leviathan" then
		p1856.cur = p1856.byName.Body or p1856.bones[1]
		local v1857 = p1856.bodyC
		local v1858 = p1856.bodyS
		local v1859 = {
			{ 0.22, -0.3 },
			{ -0.12, 0.02 },
			{ 0.15, 0.32 }
		}
		for v1860 = -1, 1, 2 do
			for _, v1861 in v1859 do
				local v1862 = v_u_9(v1860 * (v1858.X / 2 + 0.02), v1857.Y + v1861[1] * v1858.Y, v1857.Z + v1861[2] * v1858.Z) * v_u_10(0.7853981633974483, 0, 0)
				local v1863 = p1856.glow
				local v1864 = v_u_12
				v_u_80(p1856, Instance.new("Part"), Vector3.new(0.06, 0.17, 0.17), v1862, v1863, v1864)
			end
		end
	end
end
function v_u_926.coral(p1865) -- name: coral
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p1865.cur = p1865.byName.Body or p1865.bones[1]
	local v1866 = Color3.fromRGB(255, 120, 190)
	for v1867, v1868 in { Vector3.new(-0.45, 0, -0.35), Vector3.new(0.4, 0, 0.1), Vector3.new(-0.1, 0, 0.6) } do
		local v1869 = p1865.back + v1868 - Vector3.new(0, 0.08, 0)
		local v1870
		if v1867 == 2 then
			v1870 = v1866
		else
			v1870 = p1865.glow
		end
		local v1871 = v1869 + v_u_8(0, 0.5 + v1867 % 2 * 0.15, 0)
		local v1872 = v_u_12
		local v1873 = (v1871 - v1869).Unit * 0.14 * 0.4
		local v1874 = v1869 - v1873
		local v1875 = v1871 + v1873
		local v1876 = (v1874 + v1875) / 2
		local v1877 = v_u_8(0.14, 0.14, (v1875 - v1874).Magnitude)
		local v1878 = CFrame.lookAt(v1876, v1875)
		v_u_80(p1865, Instance.new("Part"), v1877, v1878, v1870, v1872)
		local v1879 = v1869 + Vector3.new(0, 0.22, 0)
		local v1880 = v1869 + Vector3.new(0.28, 0.48, 0.05)
		local v1881 = v_u_12
		local v1882 = (v1880 - v1879).Unit * 0.11 * 0.4
		local v1883 = v1879 - v1882
		local v1884 = v1880 + v1882
		local v1885 = (v1883 + v1884) / 2
		local v1886 = v_u_8(0.11, 0.11, (v1884 - v1883).Magnitude)
		local v1887 = CFrame.lookAt(v1885, v1884)
		v_u_80(p1865, Instance.new("Part"), v1886, v1887, v1870, v1881)
		local v1888 = v1869 + Vector3.new(0, 0.3, 0)
		local v1889 = v1869 + Vector3.new(-0.24, 0.6, -0.04)
		local v1890 = v_u_12
		local v1891 = (v1889 - v1888).Unit * 0.1 * 0.4
		local v1892 = v1888 - v1891
		local v1893 = v1889 + v1891
		local v1894 = (v1892 + v1893) / 2
		local v1895 = v_u_8(0.1, 0.1, (v1893 - v1892).Magnitude)
		local v1896 = CFrame.lookAt(v1894, v1893)
		v_u_80(p1865, Instance.new("Part"), v1895, v1896, v1870, v1890)
	end
end
local v_u_1897 = Color3.fromRGB(196, 238, 255)
local v_u_1898 = Color3.fromRGB(242, 244, 252)
local v_u_1899 = Color3.fromRGB(238, 234, 216)
local v_u_1900 = Color3.fromRGB(196, 190, 172)
local function v_u_1915(p1901, p1902, p1903, p1904) -- name: twinkle
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_80
	local v1905 = p1903 * 0.24
	local v1906 = v_u_8(p1903, v1905, v1905)
	local v1907 = v_u_9(p1902)
	local v1908 = v_u_12
	v_u_80(p1901, Instance.new("Part"), v1906, v1907, p1904, v1908)
	local v1909 = v_u_8(v1905, p1903, v1905)
	local v1910 = v_u_9(p1902)
	local v1911 = v_u_12
	v_u_80(p1901, Instance.new("Part"), v1909, v1910, p1904, v1911)
	local v1912 = v_u_8(v1905, v1905, p1903 * 0.75)
	local v1913 = v_u_9(p1902)
	local v1914 = v_u_12
	v_u_80(p1901, Instance.new("Part"), v1912, v1913, p1904, v1914)
end
local function v_u_1927(p1916, p1917, p1918, p1919, p1920) -- name: star4
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_10
	local v1921 = v_u_8(p1918 * 0.26, p1918, 0.05)
	local v1922 = v_u_9(p1917)
	v_u_80(p1916, Instance.new("Part"), v1921, v1922, p1919, p1920)
	local v1923 = v_u_8(p1918, p1918 * 0.26, 0.05)
	local v1924 = v_u_9(p1917)
	v_u_80(p1916, Instance.new("Part"), v1923, v1924, p1919, p1920)
	local v1925 = v_u_8(p1918 * 0.42, p1918 * 0.42, 0.06)
	local v1926 = v_u_9(p1917) * v_u_10(0, 0, 0.7853981633974483)
	v_u_80(p1916, Instance.new("Part"), v1925, v1926, p1919, p1920)
end
local v_u_1928 = v_u_10(1.5707963267948966, 0, 0)
function v_u_926.floppy(p1929) -- name: floppy
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_80
	local v1930 = p1929.headC.Y + p1929.headS.Y / 2
	local v1931
	if p1929.look.limbs then
		v1931 = p1929.limbs
	else
		v1931 = p1929.body:Lerp(v_u_13, 0.22)
	end
	for v1932 = -1, 1, 2 do
		local v1933 = v_u_8(v1932 * (p1929.headS.X / 2 + 0.05), v1930 - 0.2, p1929.headC.Z + 0.1)
		v_u_72(p1929, v1932 < 0 and "EarL" or "EarR", "Head", v1933, "ear", v1932 * 1.3, v1932)
		local v1934 = v_u_9(v1933 + v_u_8(v1932 * 0.1, -0.5, 0)) * v_u_10(0, 0, v1932 * 0.12)
		v_u_80(p1929, Instance.new("Part"), Vector3.new(0.26, 1.1, 0.75), v1934, v1931, nil)
	end
end
function v_u_926.helmet(p1935) -- name: helmet
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_1898, (copy) v_u_80, (copy) v_u_1897, (copy) v_u_10, (copy) v_u_14, (copy) v_u_20, (copy) v_u_12
	p1935.cur = p1935.byName.Head or p1935.bones[1]
	local v1936 = p1935.headC
	local v1937 = p1935.headS
	local v1938 = v1937.X + 0.8
	local v1939 = v1937.Z + 0.5
	local v1940 = v1936.Z - 0.2
	local v1941 = v1936.Y - v1937.Y / 2 + 0.28
	local v1942 = v1936.Y + v1937.Y / 2 + 0.48
	local v1943 = v_u_8(v1938, 0.32, v1939)
	local v1944 = v_u_9(0, v1941 - 0.16, v1940)
	local v1945 = v_u_1898
	v_u_80(p1935, Instance.new("Part"), v1943, v1944, v1945, nil)
	local v1946 = v_u_8(v1938 + 0.06, 0.12, v1939 + 0.06)
	local v1947 = v_u_9(0, v1941 - 0.16, v1940)
	local v1948 = p1935.cloth
	v_u_80(p1935, Instance.new("Part"), v1946, v1947, v1948, nil)
	local v1949 = v_u_8(v1938, v1942 - v1941, v1939)
	local v1950 = v_u_9(0, (v1942 + v1941) / 2, v1940)
	local v1951 = v_u_1897
	local v1952 = Instance.new("Part")
	v_u_80(p1935, v1952, v1949, v1950, v1951, nil)
	v1952.Transparency = 0.7
	local v1953 = v1940 - v1939 / 2 - 0.03
	local v1954 = v_u_9(-v1938 * 0.28, v1942 - 0.3, v1953) * v_u_10(0, 0, 0.6)
	local v1955 = v_u_14
	v_u_80(p1935, Instance.new("Part"), Vector3.new(0.55, 0.1, 0.04), v1954, v1955, nil)
	local v1956 = v_u_9(-v1938 * 0.13, v1942 - 0.2, v1953) * v_u_10(0, 0, 0.6)
	local v1957 = v_u_14
	v_u_80(p1935, Instance.new("Part"), Vector3.new(0.18, 0.1, 0.04), v1956, v1957, nil)
	local v1958 = v_u_8(v1938 * 0.22, v1942, v1940 + 0.2)
	local v1959 = v1958 + Vector3.new(0.12, 0.6, 0.05)
	local v1960 = v_u_20
	local v1961 = (v1958 + v1959) / 2
	local v1962 = v_u_8(0.08, 0.08, (v1959 - v1958).Magnitude)
	local v1963 = CFrame.lookAt(v1961, v1959)
	v_u_80(p1935, Instance.new("Part"), v1962, v1963, v1960, nil)
	local v1964 = p1935.cloth
	local v1965 = v_u_12
	local v1966 = Instance.new("Part")
	v1966.Shape = Enum.PartType.Ball
	v_u_80(p1935, v1966, Vector3.new(0.28, 0.28, 0.28), v_u_9(v1959), v1964, v1965)
end
function v_u_926.jetpack(p1967) -- name: jetpack
	-- upvalues: (copy) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_1898, (copy) v_u_80, (copy) v_u_20, (copy) v_u_12
	p1967.cur = p1967.byName.Body or p1967.bones[1]
	local v1968 = p1967.bodyC.Y + p1967.bodyS.Y / 2
	local v1969 = p1967.headC.Z + p1967.headS.Z / 2 + 0.22
	local v1970 = p1967.look.spirit or "#7FE9FF"
	local v1971 = Color3.fromHex(v1970)
	local v1972 = v_u_10(0, 1.5707963267948966, 0)
	for v1973 = -1, 1, 2 do
		local v1974 = v_u_8(v1973 * 0.33, v1968 + 0.26, v1969 + 0.45)
		local v1975 = v_u_9(v1974) * v1972
		local v1976 = v_u_1898
		local v1977 = Instance.new("Part")
		v1977.Shape = Enum.PartType.Cylinder
		v_u_80(p1967, v1977, Vector3.new(0.9, 0.54, 0.54), v1975, v1976, nil)
		local v1978 = v_u_9(v1974) * v1972
		local v1979 = p1967.cloth
		local v1980 = Instance.new("Part")
		v1980.Shape = Enum.PartType.Cylinder
		v_u_80(p1967, v1980, Vector3.new(0.16, 0.58, 0.58), v1978, v1979, nil)
		local v1981 = v1974 + Vector3.new(0, 0, 0.45)
		local v1982 = v_u_9(v1981 + Vector3.new(0, 0, 0.08)) * v1972
		local v1983 = v_u_20
		local v1984 = Instance.new("Part")
		v1984.Shape = Enum.PartType.Cylinder
		v_u_80(p1967, v1984, Vector3.new(0.2, 0.36, 0.36), v1982, v1983, nil)
		local v1985 = v_u_9(v1981 + Vector3.new(0, 0, 0.32)) * v_u_10(0, 0, 0.7853981633974483)
		local v1986 = v_u_12
		v_u_80(p1967, Instance.new("Part"), Vector3.new(0.24, 0.24, 0.3), v1985, v1971, v1986)
	end
end
function v_u_926.nebula(p1987) -- name: nebula
	-- upvalues: (copy) v_u_9, (copy) v_u_1928, (copy) v_u_80, (copy) v_u_8, (copy) v_u_14, (copy) v_u_10, (copy) v_u_12
	local v1988 = p1987.accent
	local v1989 = p1987.look.tip or (p1987.look.glow or "#7FF0FF")
	local v1990 = Color3.fromHex(v1989)
	p1987.cur = p1987.byName.Body or p1987.bones[1]
	local v1991 = p1987.bodyC
	local v1992 = p1987.bodyS
	local v1993 = v1991.Y + v1992.Y / 2
	local v1994 = v1991.Z + v1992.Z / 2
	local v1995 = v_u_9(0.28, v1993 + 0.02, v1994 - 0.68) * v_u_1928
	v_u_80(p1987, Instance.new("Part"), Vector3.new(1.1, 0.527, 0.08), v1995, v1988, nil)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.682, 0.85, 0.1), v1995, v1988, nil)
	local v1996 = v_u_9(-0.45, v1993 + 0.045, v1994 - 0.32) * v_u_1928
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.75, 0.372, 0.08), v1996, v1990, nil)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.465, 0.6, 0.1), v1996, v1990, nil)
	local v1997 = v_u_14
	local v1998 = v_u_9((v_u_8(0.62, v1993 + 0.03, v1994 - 0.12))) * v_u_10(0, 0.7853981633974483, 0)
	local v1999 = v_u_12
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.15, 0.05, 0.15), v1998, v1997, v1999)
	local v2000 = v_u_14
	local v2001 = v_u_9((v_u_8(-0.62, v1993 + 0.03, v1994 - 0.95))) * v_u_10(0, 0.7853981633974483, 0)
	local v2002 = v_u_12
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.15, 0.05, 0.15), v2001, v2000, v2002)
	for v2003 = -1, 1, 2 do
		local v2004 = v2003 * (v1992.X / 2 + 0.02)
		local v2005
		if v2003 > 0 then
			v2005 = v1988
		else
			v2005 = v1990
		end
		local v2006
		if v2003 > 0 then
			v2006 = v1990
		else
			v2006 = v1988
		end
		local v2007 = v_u_9(v2004, v1991.Y + v1992.Y * 0.08, v1991.Z - v1992.Z * 0.14) * v_u_10(0, -v2003 * 3.141592653589793 / 2, 0)
		v_u_80(p1987, Instance.new("Part"), Vector3.new(1.15, 0.465, 0.08), v2007, v2005, nil)
		v_u_80(p1987, Instance.new("Part"), Vector3.new(0.713, 0.75, 0.1), v2007, v2005, nil)
		local v2008 = v_u_9(v2004, v1991.Y - v1992.Y * 0.16, v1991.Z + v1992.Z * 0.28) * v_u_10(0, -v2003 * 3.141592653589793 / 2, 0)
		v_u_80(p1987, Instance.new("Part"), Vector3.new(0.75, 0.341, 0.08), v2008, v2006, nil)
		v_u_80(p1987, Instance.new("Part"), Vector3.new(0.465, 0.55, 0.1), v2008, v2006, nil)
		local v2009 = v_u_14
		local v2010 = v_u_9((v_u_8(v2004 + v2003 * 0.01, v1991.Y + v1992.Y * 0.3, v1991.Z + v1992.Z * 0.3))) * v_u_10(0.7853981633974483, 0, 0)
		local v2011 = v_u_12
		v_u_80(p1987, Instance.new("Part"), Vector3.new(0.05, 0.15, 0.15), v2010, v2009, v2011)
	end
	p1987.cur = p1987.byName.Head or p1987.bones[1]
	local v2012 = p1987.face - 0.012
	local v2013 = v_u_9(0.58, p1987.eyeY + 0.3, v2012)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.95, 0.62, 0.025), v2013, v1988, nil)
	local v2014 = v_u_9(0.58, p1987.eyeY + 0.3, v2012)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.62, 0.95, 0.03), v2014, v1988, nil)
	local v2015 = v_u_8(-(p1987.headS.X / 2 - 0.32), p1987.headC.Y + p1987.headS.Y / 2 - 0.3, v2012)
	local v2016 = v_u_9(v2015)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.6, 0.4, 0.025), v2016, v1990, nil)
	local v2017 = v_u_9(v2015 + Vector3.new(0, -0.05, 0))
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.4, 0.6, 0.03), v2017, v1990, nil)
	local v2018 = p1987.headC.Y + p1987.headS.Y / 2
	local v2019 = p1987.headC.Z
	local v2020 = v_u_9(-0.3, v2018 + 0.02, v2019 + 0.4) * v_u_1928
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.8, 0.434, 0.08), v2020, v1990, nil)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.496, 0.7, 0.1), v2020, v1990, nil)
	local v2021 = v_u_9(0.45, v2018 + 0.045, v2019 + 0.6) * v_u_1928
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.45, 0.248, 0.08), v2021, v1988, nil)
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.279, 0.4, 0.1), v2021, v1988, nil)
	local v2022 = v_u_14
	local v2023 = v_u_9((v_u_8(0.8, v2018 + 0.03, v2019 + 0.25))) * v_u_10(0, 0.7853981633974483, 0)
	local v2024 = v_u_12
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.13, 0.05, 0.13), v2023, v2022, v2024)
	local v2025 = v_u_14
	local v2026 = v_u_9((v_u_8(-0.85, v2018 + 0.03, v2019 + 0.75))) * v_u_10(0, 0.7853981633974483, 0)
	local v2027 = v_u_12
	v_u_80(p1987, Instance.new("Part"), Vector3.new(0.13, 0.05, 0.13), v2026, v2025, v2027)
end
function v_u_926.starcharm(p2028) -- name: starcharm
	-- upvalues: (copy) v_u_1927, (copy) v_u_19, (copy) v_u_12
	p2028.cur = p2028.byName.Body or p2028.bones[1]
	v_u_1927(p2028, p2028.neck + Vector3.new(0, -0.38, -0.12), 0.48, v_u_19, v_u_12)
end
function v_u_926.cometmark(p2029) -- name: cometmark
	-- upvalues: (copy) v_u_8, (copy) v_u_1927, (copy) v_u_14, (copy) v_u_12, (copy) v_u_80
	p2029.cur = p2029.byName.Head or p2029.bones[1]
	local v2030 = p2029.eyeY + 0.55
	local v2031 = p2029.headC.Y + p2029.headS.Y / 2 - 0.3
	local v2032 = v_u_8(0, math.min(v2030, v2031), p2029.face - 0.04)
	v_u_1927(p2029, v2032, 0.32, v_u_14, v_u_12)
	local v2033 = v2032 + Vector3.new(0.1, 0.05, 0.01)
	local v2034 = v2032 + Vector3.new(0.44, 0.2, 0.01)
	local v2035 = p2029.glow
	local v2036 = v_u_12
	local v2037 = (v2033 + v2034) / 2
	local v2038 = v_u_8(0.09, 0.09, (v2034 - v2033).Magnitude)
	local v2039 = CFrame.lookAt(v2037, v2034)
	v_u_80(p2029, Instance.new("Part"), v2038, v2039, v2035, v2036)
	local v2040 = v2032 + Vector3.new(0.09, -0.03, 0.01)
	local v2041 = v2032 + Vector3.new(0.4, 0.04, 0.01)
	local v2042 = p2029.glow:Lerp(v_u_14, 0.5)
	local v2043 = v_u_12
	local v2044 = (v2040 + v2041) / 2
	local v2045 = v_u_8(0.06, 0.06, (v2041 - v2040).Magnitude)
	local v2046 = CFrame.lookAt(v2044, v2041)
	v_u_80(p2029, Instance.new("Part"), v2045, v2046, v2042, v2043)
end
function v_u_926.comettail(p2047) -- name: comettail
	-- upvalues: (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_80, (copy) v_u_12, (copy) v_u_14, (copy) v_u_8, (copy) v_u_1915
	local v2048 = p2047.tailAt
	v_u_72(p2047, "Tail1", "Body", v2048, "tail", 0.7)
	local v2049 = v_u_9(v2048) * v_u_10(-1.2, 0, 0)
	local v2050 = v2049 * v_u_9(0, 0, 0.55)
	local v2051 = p2047.body
	v_u_80(p2047, Instance.new("Part"), Vector3.new(0.72, 0.72, 1.25), v2050, v2051, nil)
	local v2052 = v2049 * v_u_9(0, 0, 1.6)
	local v2053 = p2047.glow
	local v2054 = v_u_12
	v_u_80(p2047, Instance.new("Part"), Vector3.new(0.88, 0.88, 1), v2052, v2053, v2054)
	local v2055 = (v2049 * v_u_9(0, 0, 2.05)).Position
	local v2056 = p2047.glow:Lerp(v_u_14, 0.45)
	for v2057 = -1, 1 do
		local v2058 = v2057 == 0 and 1.5 or 1.15
		local v2059 = v2057 == 0 and 0.48 or 0.36
		local v2060 = v_u_9(v2055) * v_u_10(0, v2057 * 0.5, 0) * v_u_10(-0.9, 0, 0)
		local v2061 = v_u_8(v2059, v2059, v2058)
		local v2062 = v2060 * v_u_9(0, 0, v2058 / 2)
		local v2063 = v_u_12
		v_u_80(p2047, Instance.new("Part"), v2061, v2062, v2056, v2063)
		local v2064 = v_u_8(v2059 * 0.75, v2059 * 0.75, v2059 * 0.75)
		local v2065 = v2060 * v_u_9(0, 0, v2058 + 0.12) * v_u_10(0, 0.7853981633974483, 0.7853981633974483)
		local v2066 = v_u_14
		local v2067 = v_u_12
		v_u_80(p2047, Instance.new("Part"), v2064, v2065, v2066, v2067)
	end
	v_u_1915(p2047, (v2049 * v_u_9(0.6, 0.15, 1.7)).Position, 0.32, v_u_14)
	v_u_1915(p2047, (v2049 * v_u_9(-0.55, -0.1, 2.3)).Position, 0.26, v_u_14)
end
function v_u_926.facedisc(p2068) -- name: facedisc
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_10, (copy) v_u_80
	p2068.cur = p2068.byName.Head or p2068.bones[1]
	local v2069 = p2068.glow:Lerp(v_u_14, 0.55)
	for v2070 = -1, 1, 2 do
		local v2071 = v_u_9(v2070 * p2068.eyeX, p2068.eyeY, p2068.face - 0.015) * v_u_10(0, 0, 0.7853981633974483)
		v_u_80(p2068, Instance.new("Part"), Vector3.new(0.64, 0.64, 0.04), v2071, v2069, nil)
	end
end
local v_u_2072 = {
	Vector2.new(-0.42, 0.12),
	Vector2.new(-0.16, 0.32),
	Vector2.new(0.1, 0.16),
	Vector2.new(0.38, 0.34),
	Vector2.new(0.44, -0.08),
	Vector2.new(0.12, -0.32)
}
local v_u_2073 = {
	Vector2.new(-0.36, 0.18),
	Vector2.new(-0.04, 0.34),
	Vector2.new(0.26, 0.1),
	Vector2.new(0.08, -0.28)
}
local function v_u_2091(p2074, p2075, p2076, p2077, p2078, p2079) -- name: constellation
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	local v2080 = p2074.accent:Lerp(p2074.body, 0.4)
	local v2081 = nil
	for _, v2082 in p2075 do
		local v2083 = (p2076 * v_u_9(v2082.X * p2077, v2082.Y * p2078, -0.03)).Position
		local v2084 = v_u_8(p2079, p2079, 0.06)
		local v2085 = (p2076.Rotation + v2083) * v_u_10(0, 0, 0.7853981633974483)
		local v2086 = p2074.accent
		local v2087 = v_u_12
		v_u_80(p2074, Instance.new("Part"), v2084, v2085, v2086, v2087)
		if v2081 then
			local v2088 = (v2081 + v2083) / 2
			local v2089 = v_u_8(0.05, 0.05, (v2083 - v2081).Magnitude)
			local v2090 = CFrame.lookAt(v2088, v2083)
			v_u_80(p2074, Instance.new("Part"), v2089, v2090, v2080, nil)
		end
		v2081 = v2083
	end
end
function v_u_926.constellation(p2092) -- name: constellation
	-- upvalues: (copy) v_u_2091, (copy) v_u_2072, (copy) v_u_9, (copy) v_u_10, (copy) v_u_2073
	p2092.cur = p2092.byName.Body or p2092.bones[1]
	local v2093 = p2092.bodyC
	local v2094 = p2092.bodyS
	if p2092.look.shape == "bird" then
		v_u_2091(p2092, v_u_2072, v_u_9(0, v2093.Y - 0.05, v2093.Z - v2094.Z / 2 - 0.08), 1, 0.9, 0.17)
	else
		for v2095 = -1, 1, 2 do
			v_u_2091(p2092, v_u_2072, v_u_9(v2095 * v2094.X / 2, v2093.Y + 0.05, v2093.Z) * v_u_10(0, -v2095 * 3.141592653589793 / 2, 0), v2094.Z * 0.85, v2094.Y * 0.8, 0.22)
		end
		p2092.cur = p2092.byName.Head or p2092.bones[1]
		local v2096 = p2092.headC
		local v2097 = p2092.headS
		for v2098 = -1, 1, 2 do
			v_u_2091(p2092, v_u_2073, v_u_9(v2098 * v2097.X / 2, v2096.Y + 0.15, v2096.Z) * v_u_10(0, -v2098 * 3.141592653589793 / 2, 0), v2097.Z * 0.85, v2097.Y * 0.62, 0.2)
		end
	end
end
function v_u_926.planet(p2099) -- name: planet
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_80, (copy) v_u_9, (copy) v_u_10
	v_u_72(p2099, "Planet", "Body", v_u_8(0, p2099.bodyC.Y + 0.3, p2099.bodyC.Z), "orbit", 1.1, 1)
	local v2100 = v_u_8(1.95, p2099.bodyC.Y + 1, p2099.bodyC.Z - 0.3)
	local v2101 = p2099.look.spirit or "#FF8AD8"
	local v2102, v2103 = Color3.fromHex(v2101)
	local v2104 = Instance.new("Part")
	v2104.Shape = Enum.PartType.Ball
	v_u_80(p2099, v2104, Vector3.new(0.62, 0.62, 0.62), v_u_9(v2100), v2102, v2103)
	local v2105 = v_u_9(v2100) * v_u_10(0.4, 0, 0) * v_u_10(0, 0, 1.5707963267948966)
	local v2106 = p2099.accent
	local v2107 = Instance.new("Part")
	v2107.Shape = Enum.PartType.Cylinder
	v_u_80(p2099, v2107, Vector3.new(0.06, 1.15, 1.15), v2105, v2106, nil)
end
function v_u_926.nebulamane(p2108) -- name: nebulamane
	-- upvalues: (copy) v_u_49, (copy) v_u_124, (copy) v_u_8, (copy) v_u_12
	p2108.cur = p2108.byName.Head or p2108.bones[1]
	local v2109 = {}
	local v2110 = p2108.glow
	local v2111 = p2108.look.spirit or "#B48CFF"
	__set_list(v2109, 1, {v2110, Color3.fromHex(v2111), v_u_49(p2108.look.tip or "#7FE9FF")})
	local v2112 = p2108.headC.Y + p2108.headS.Y / 2 - 0.02
	for v2113 = 0, 2 do
		local v2114 = p2108.face + 0.3 + v2113 * 0.4
		local v2115 = v2113 == 1 and 1.2 or 0.95
		v_u_124(p2108, v_u_8(0, v2112, v2114 - 0.25), v_u_8(0, v2112, v2114 + 0.25), v_u_8(0, v2112 + v2115, v2114 + 0.38), 0.34, v2109[v2113 % 3 + 1], v_u_12)
	end
	local v2116 = v_u_8(0, v2112 + 0.02, p2108.headC.Z + 0.6)
	local v2117 = v_u_8(0, p2108.back.Y, p2108.back.Z - 0.7)
	local v2118 = (v2117 - v2116).Unit
	local v2119 = v_u_8(0, v2118.Z, -v2118.Y)
	for v2120 = 0, 4 do
		local v2121 = v2116:Lerp(v2117, v2120 / 4)
		local v2122 = 1 - v2120 * 0.1
		v_u_124(p2108, v2121 - v2118 * 0.12, v2121 + v2118 * 0.5, v2121 + v2118 * 0.6 + v2119 * 0.75 * v2122, 0.26, v2109[v2120 % 3 + 1], v_u_12)
	end
end
function v_u_926.startail(p2123) -- name: startail
	-- upvalues: (copy) v_u_72, (copy) v_u_49, (copy) v_u_9, (copy) v_u_10, (copy) v_u_80, (copy) v_u_8, (copy) v_u_12, (copy) v_u_14
	local v2124 = p2123.tailAt
	v_u_72(p2123, "Tail1", "Body", v2124, "tail", 0.4)
	local v2125 = {}
	local v2126 = p2123.look.spirit or "#B48CFF"
	__set_list(v2125, 1, {Color3.fromHex(v2126), p2123.glow, v_u_49(p2123.look.tip or "#7FE9FF")})
	for v2127 = -1, 1 do
		local v2128 = v_u_9(v2124) * v_u_10(0, v2127 * 0.36, 0) * v_u_10(0.55, 0, 0)
		local v2129 = v2128 * v_u_9(0, 0, 0.45)
		local v2130 = p2123.body
		v_u_80(p2123, Instance.new("Part"), Vector3.new(0.34, 0.34, 1), v2129, v2130, nil)
		local v2131 = v2128 * v_u_9(0, 0, 0.95) * v_u_10(-0.85, 0, 0)
		local v2132 = v2127 == 0 and 1.05 or 0.85
		local v2133 = v_u_8(0.38, 0.38, v2132)
		local v2134 = v2131 * v_u_9(0, 0, v2132 / 2 - 0.05)
		local v2135 = v2125[v2127 + 2]
		local v2136 = v_u_12
		v_u_80(p2123, Instance.new("Part"), v2133, v2134, v2135, v2136)
		local v2137 = v2131 * v_u_9(0, 0, v2132 + 0.08) * v_u_10(0, 0.7853981633974483, 0.7853981633974483)
		local v2138 = v_u_14
		local v2139 = v_u_12
		v_u_80(p2123, Instance.new("Part"), Vector3.new(0.26, 0.26, 0.26), v2137, v2138, v2139)
	end
end
function v_u_926.startiara(p2140) -- name: startiara
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_18, (copy) v_u_80, (copy) v_u_1927, (copy) v_u_19, (copy) v_u_12
	p2140.cur = p2140.byName.Head or p2140.bones[1]
	local v2141 = p2140.face - 0.04
	local v2142 = p2140.headC.Y + p2140.headS.Y / 2 - 0.14
	local v2143 = v_u_8(p2140.headS.X * 0.78, 0.1, 0.06)
	local v2144 = v_u_9(0, v2142, v2141 + 0.01)
	local v2145 = v_u_18
	v_u_80(p2140, Instance.new("Part"), v2143, v2144, v2145, nil)
	v_u_1927(p2140, v_u_8(0, v2142 + 0.06, v2141 - 0.03), 0.48, v_u_19, v_u_12)
	v_u_1927(p2140, v_u_8(-0.48, v2142 + 0.02, v2141 - 0.02), 0.26, v_u_19, v_u_12)
	v_u_1927(p2140, v_u_8(0.48, v2142 + 0.02, v2141 - 0.02), 0.26, v_u_19, v_u_12)
end
function v_u_926.saturnring(p2146) -- name: saturnring
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_14, (copy) v_u_80
	local v2147 = v_u_8(0, p2146.bodyC.Y - 0.12, p2146.bodyC.Z)
	v_u_72(p2146, "Ring", "Body", v2147, "spin")
	local v2148 = v_u_9(v2147) * v_u_10(-0.22, 0, 0.12)
	local v2149 = p2146.accent:Lerp(v_u_14, 0.3)
	for v2150 = 0, 11 do
		local v2151 = v2150 * 3.141592653589793 * 2 / 12
		local v2152 = v2148 * v_u_9(math.cos(v2151) * 1.78, 0, math.sin(v2151) * 1.78) * v_u_10(0, -v2151, 0)
		local v2153
		if v2150 % 2 == 0 then
			v2153 = p2146.accent
		else
			v2153 = v2149
		end
		v_u_80(p2146, Instance.new("Part"), Vector3.new(0.42, 0.08, 0.9968), v2152, v2153, nil)
	end
end
function v_u_926.moon(p2154) -- name: moon
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_1899, (copy) v_u_80, (copy) v_u_9, (copy) v_u_1900
	v_u_72(p2154, "Moon", "Body", v_u_8(0, p2154.bodyC.Y, p2154.bodyC.Z), "orbit", 2.4, 1)
	local v2155 = v_u_8(-1.95, p2154.bodyC.Y + 0.95, p2154.bodyC.Z - 0.2)
	local v2156 = v_u_1899
	local v2157 = Instance.new("Part")
	v2157.Shape = Enum.PartType.Ball
	v_u_80(p2154, v2157, Vector3.new(0.56, 0.56, 0.56), v_u_9(v2155), v2156, nil)
	local v2158 = v2155 + Vector3.new(0.12, 0.1, -0.22)
	local v2159 = v_u_1900
	local v2160 = Instance.new("Part")
	v2160.Shape = Enum.PartType.Ball
	v_u_80(p2154, v2160, Vector3.new(0.18, 0.18, 0.18), v_u_9(v2158), v2159, nil)
	local v2161 = v2155 + Vector3.new(-0.14, -0.08, -0.22)
	local v2162 = v_u_1900
	local v2163 = Instance.new("Part")
	v2163.Shape = Enum.PartType.Ball
	v_u_80(p2154, v2163, Vector3.new(0.12, 0.12, 0.12), v_u_9(v2161), v2162, nil)
end
function v_u_926.alienears(p2164) -- name: alienears
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_80
	for v2165 = -1, 1, 2 do
		local v2166 = v_u_8(v2165 * (p2164.headS.X / 2 - 0.05), p2164.eyeY + 0.3, p2164.headC.Z + 0.1)
		v_u_72(p2164, v2165 < 0 and "EarL" or "EarR", "Head", v2166, "ear", v2165 * 1.3, v2165)
		local v2167 = v_u_8(v2165 * 1, 0, 0)
		local v2168 = v2165 * 0.35
		local v2169 = math.cos(v2168)
		local v2170 = math.sin(v2168)
		local v2171 = v_u_8(v2167.X * v2169 - v2167.Y * v2170, v2167.X * v2170 + v2167.Y * v2169, v2167.Z)
		local v2172 = v2165 * 0.35
		local v2173 = math.cos(v2172)
		local v2174 = math.sin(v2172)
		local v2175 = v_u_8(v2173 * 0 - v2174 * 0.699999988079071, v2174 * 0 + v2173 * 0.699999988079071, 0)
		local v2176 = p2164.limbs
		local v2177 = -v2171.Unit
		local v2178 = v2175.Unit
		local v2179 = CFrame.fromMatrix(v2166 + v2171 / 2 + v2175 / 2, v2178:Cross(v2177), v2178, v2177)
		local v2180 = v_u_8(0.24, v2175.Magnitude, v2171.Magnitude)
		v_u_80(p2164, Instance.new("WedgePart"), v2180, v2179, v2176, nil)
		local v2181 = v2166 + v2171 * 0.14 + v2175 * 0.12 + Vector3.new(0, 0, -0.05)
		local v2182 = v2171 * 0.6
		local v2183 = v2175 * 0.6
		local v2184 = p2164.accent
		local v2185 = -v2182.Unit
		local v2186 = v2183.Unit
		local v2187 = CFrame.fromMatrix(v2181 + v2182 / 2 + v2183 / 2, v2186:Cross(v2185), v2186, v2185)
		local v2188 = v_u_8(0.22, v2183.Magnitude, v2182.Magnitude)
		v_u_80(p2164, Instance.new("WedgePart"), v2188, v2187, v2184, nil)
	end
end
function v_u_926.antennae(p2189) -- name: antennae
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_80, (copy) v_u_12, (copy) v_u_9
	local v2190 = p2189.headC.Y + p2189.headS.Y / 2
	local v2191 = p2189.look.spirit or (p2189.look.glow or "#FF6AD5")
	local v2192 = Color3.fromHex(v2191)
	for v2193 = -1, 1, 2 do
		local v2194 = v_u_8(v2193 * 0.4, v2190 - 0.05, p2189.headC.Z - 0.05)
		v_u_72(p2189, v2193 < 0 and "AntennaL" or "AntennaR", "Head", v2194, "lure", v2193 * 1.1)
		local v2195 = v2194 + v_u_8(v2193 * 0.22, 0.6, 0.05)
		local v2196 = v2195 + v_u_8(v2193 * 0.12, 0.42, -0.12)
		local v2197 = p2189.limbs
		local v2198 = (v2195 - v2194).Unit * 0.11 * 0.4
		local v2199 = v2194 - v2198
		local v2200 = v2195 + v2198
		local v2201 = (v2199 + v2200) / 2
		local v2202 = v_u_8(0.11, 0.11, (v2200 - v2199).Magnitude)
		local v2203 = CFrame.lookAt(v2201, v2200)
		v_u_80(p2189, Instance.new("Part"), v2202, v2203, v2197, nil)
		local v2204 = p2189.limbs
		local v2205 = (v2196 - v2195).Unit * 0.1 * 0.4
		local v2206 = v2195 - v2205
		local v2207 = v2196 + v2205
		local v2208 = (v2206 + v2207) / 2
		local v2209 = v_u_8(0.1, 0.1, (v2207 - v2206).Magnitude)
		local v2210 = CFrame.lookAt(v2208, v2207)
		v_u_80(p2189, Instance.new("Part"), v2209, v2210, v2204, nil)
		local v2211 = v2196 + Vector3.new(0, 0.1, 0)
		local v2212 = v_u_12
		local v2213 = Instance.new("Part")
		v2213.Shape = Enum.PartType.Ball
		v_u_80(p2189, v2213, Vector3.new(0.36, 0.36, 0.36), v_u_9(v2211), v2192, v2212)
	end
end
function v_u_926.bigeyes(p2214) -- name: bigeyes
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_80, (copy) v_u_14
	p2214.cur = p2214.byName.Head or p2214.bones[1]
	local v2215 = p2214.face - 0.13
	for v2216 = -1, 1, 2 do
		local v2217 = v_u_9(v2216 * (p2214.eyeX + 0.04), p2214.eyeY + 0.04, v2215) * v_u_10(0, 0, -v2216 * 0.3)
		local v2218 = v_u_13
		v_u_80(p2214, Instance.new("Part"), Vector3.new(0.6, 0.82, 0.06), v2217, v2218, nil)
		local v2219 = v2217 * v_u_9(v2216 * 0.08, 0.2, -0.04)
		local v2220 = v_u_14
		v_u_80(p2214, Instance.new("Part"), Vector3.new(0.24, 0.24, 0.04), v2219, v2220, nil)
		local v2221 = v2217 * v_u_9(-v2216 * 0.1, -0.2, -0.04)
		local v2222 = v_u_14
		v_u_80(p2214, Instance.new("Part"), Vector3.new(0.11, 0.11, 0.04), v2221, v2222, nil)
	end
end
function v_u_926.alienspots(p2223) -- name: alienspots
	-- upvalues: (copy) v_u_9, (copy) v_u_1928, (copy) v_u_80, (copy) v_u_10
	p2223.cur = p2223.byName.Body or p2223.bones[1]
	local v2224 = p2223.bodyC
	local v2225 = p2223.bodyS
	local v2226 = v2224.Y + v2225.Y / 2
	local v2227 = v2224.Z + v2225.Z / 2
	local v2228 = v_u_9(0.32, v2226 + 0.02, v2227 - 0.75) * v_u_1928
	local v2229 = p2223.accent
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.55, 0.341, 0.08), v2228, v2229, nil)
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.341, 0.55, 0.1), v2228, v2229, nil)
	local v2230 = v_u_9(-0.35, v2226 + 0.02, v2227 - 0.3) * v_u_1928
	local v2231 = p2223.accent
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.4, 0.248, 0.08), v2230, v2231, nil)
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.248, 0.4, 0.1), v2230, v2231, nil)
	for v2232 = -1, 1, 2 do
		local v2233 = v_u_9(v2232 * (v2225.X / 2 + 0.02), v2224.Y + 0.15, v2227 - 0.55) * v_u_10(0, -v2232 * 3.141592653589793 / 2, 0)
		local v2234 = p2223.accent
		v_u_80(p2223, Instance.new("Part"), Vector3.new(0.45, 0.279, 0.08), v2233, v2234, nil)
		v_u_80(p2223, Instance.new("Part"), Vector3.new(0.279, 0.45, 0.1), v2233, v2234, nil)
	end
	p2223.cur = p2223.byName.Head or p2223.bones[1]
	local v2235 = v_u_9(0.05, p2223.headC.Y + p2223.headS.Y / 2 + 0.02, p2223.headC.Z + 0.45) * v_u_1928
	local v2236 = p2223.accent
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.42, 0.2604, 0.08), v2235, v2236, nil)
	v_u_80(p2223, Instance.new("Part"), Vector3.new(0.2604, 0.42, 0.1), v2235, v2236, nil)
end
local v_u_2237 = {
	{ -0.3, 0.05 },
	{ 0.28, 0.18 },
	{ -0.22, 0.38 },
	{ 0.32, 0.42 }
}
local v_u_2238 = {
	{ 0.35, -0.4 },
	{ -0.3, 0.42 },
	{ 0.3, 0.38 }
}
function v_u_926.stardust(p2239) -- name: stardust
	-- upvalues: (copy) v_u_14, (copy) v_u_49, (copy) v_u_2237, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80, (copy) v_u_2238
	local v2240 = { v_u_14, v_u_49(p2239.look.tip or "#7FE9FF") }
	p2239.cur = p2239.byName.Body or p2239.bones[1]
	local v2241 = p2239.bodyC
	local v2242 = p2239.bodyS
	for v2243, v2244 in v_u_2237 do
		local v2245 = v_u_8(v2244[1] * v2242.X, v2241.Y + v2242.Y / 2 + 0.03, v2241.Z + v2244[2] * v2242.Z)
		local v2246 = v2240[v2243 % 2 + 1]
		local v2247 = v_u_9(v2245) * v_u_10(0, 0.7853981633974483, 0)
		local v2248 = v_u_12
		v_u_80(p2239, Instance.new("Part"), Vector3.new(0.15, 0.05, 0.15), v2247, v2246, v2248)
	end
	for v2249 = -1, 1, 2 do
		for v2250, v2251 in v_u_2238 do
			local v2252 = v_u_8(v2249 * (v2242.X / 2 + 0.03), v2241.Y + v2251[1] * v2242.Y, v2241.Z + v2251[2] * v2242.Z)
			local v2253 = v2240[v2250 % 2 + 1]
			local v2254 = v_u_9(v2252) * v_u_10(0.7853981633974483, 0, 0)
			local v2255 = v_u_12
			v_u_80(p2239, Instance.new("Part"), Vector3.new(0.05, 0.15, 0.15), v2254, v2253, v2255)
		end
	end
	p2239.cur = p2239.byName.Head or p2239.bones[1]
	local v2256 = p2239.headC
	local v2257 = p2239.headS
	local v2258 = p2239.headC.Y + p2239.headS.Y / 2 + 0.03
	local v2259 = v_u_14
	local v2260 = v_u_9((v_u_8(0.32 * v2257.X, v2258, v2256.Z + 0.35 * v2257.Z))) * v_u_10(0, 0.7853981633974483, 0)
	local v2261 = v_u_12
	v_u_80(p2239, Instance.new("Part"), Vector3.new(0.14, 0.05, 0.14), v2260, v2259, v2261)
	local v2262 = v_u_8(-0.3 * v2257.X, v2258, v2256.Z + 0.12 * v2257.Z)
	local v2263 = v2240[2]
	local v2264 = v_u_9(v2262) * v_u_10(0, 0.7853981633974483, 0)
	local v2265 = v_u_12
	v_u_80(p2239, Instance.new("Part"), Vector3.new(0.14, 0.05, 0.14), v2264, v2263, v2265)
	for v2266 = -1, 1, 2 do
		local v2267 = v_u_14
		local v2268 = v_u_9((v_u_8(v2266 * (v2257.X / 2 + 0.03), v2256.Y + 0.25 * v2257.Y, v2256.Z + 0.2 * v2257.Z))) * v_u_10(0.7853981633974483, 0, 0)
		local v2269 = v_u_12
		v_u_80(p2239, Instance.new("Part"), Vector3.new(0.05, 0.14, 0.14), v2268, v2267, v2269)
	end
	local v2270 = p2239.face - 0.03
	local v2271 = p2239.eyeY + 0.6
	local v2272 = p2239.headC.Y + p2239.headS.Y / 2 - 0.22
	local v2273 = math.min(v2271, v2272)
	for v2274 = -1, 1, 2 do
		local v2275 = v_u_9((v_u_8(v2274 * (v2257.X / 2 - 0.25), v2273, v2270))) * v_u_10(0, 0, 0.7853981633974483)
		local v2276 = v2240[(v2274 + 3) / 2]
		local v2277 = v_u_12
		v_u_80(p2239, Instance.new("Part"), Vector3.new(0.14, 0.14, 0.05), v2275, v2276, v2277)
	end
	local v2278 = v_u_9((v_u_8(v2257.X / 2 - 0.2, p2239.mouthY - 0.1, v2270))) * v_u_10(0, 0, 0.7853981633974483)
	local v2279 = v_u_14
	local v2280 = v_u_12
	v_u_80(p2239, Instance.new("Part"), Vector3.new(0.12, 0.12, 0.05), v2278, v2279, v2280)
end
function v_u_926.voidwisps(p2281) -- name: voidwisps
	-- upvalues: (copy) v_u_49, (copy) v_u_124, (copy) v_u_8, (copy) v_u_12
	local v2282 = { p2281.glow, v_u_49(p2281.look.tip or "#62F2FF") }
	p2281.cur = p2281.byName.Head or p2281.bones[1]
	local v2283 = p2281.headC.Y + p2281.headS.Y / 2 - 0.03
	for v2284 = 0, 1 do
		local v2285 = p2281.headC.Z + v2284 * 0.55
		local v2286 = v2284 == 0 and 0.85 or 0.62
		v_u_124(p2281, v_u_8(0, v2283, v2285 - 0.24), v_u_8(0, v2283, v2285 + 0.2), v_u_8(0, v2283 + v2286, v2285 + 0.38), 0.24, v2282[v2284 + 1], v_u_12)
	end
	p2281.cur = p2281.byName.Body or p2281.bones[1]
	local v2287 = p2281.bodyC.Y + p2281.bodyS.Y / 2 - 0.05
	local v2288 = p2281.headC.Z + p2281.headS.Z / 2 + 0.1
	local v2289 = p2281.bodyC.Z + p2281.bodyS.Z / 2 - 0.2
	for v2290 = 0, 2 do
		local v2291 = v2288 + (v2289 - v2288) * v2290 / 2
		local v2292 = 0.8 - v2290 * 0.14
		v_u_124(p2281, v_u_8(0, v2287, v2291 - 0.24), v_u_8(0, v2287, v2291 + 0.22), v_u_8(0, v2287 + v2292, v2291 + 0.42), 0.22, v2282[v2290 % 2 + 1], v_u_12)
	end
end
function v_u_926.starspout(p2293) -- name: starspout
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_12, (copy) v_u_80, (copy) v_u_1915, (copy) v_u_14, (copy) v_u_9, (copy) v_u_10
	local v2294 = v_u_8(0, p2293.headC.Y + p2293.headS.Y / 2 - 0.05, p2293.headC.Z + 0.3)
	v_u_72(p2293, "Spout", "Head", v2294, "lure", 0.8)
	local v2295 = v2294 + Vector3.new(0, 0.95, 0)
	local v2296 = p2293.glow
	local v2297 = v_u_12
	local v2298 = (v2295 - v2294).Unit * 0.24 * 0.4
	local v2299 = v2294 - v2298
	local v2300 = v2295 + v2298
	local v2301 = (v2299 + v2300) / 2
	local v2302 = v_u_8(0.24, 0.24, (v2300 - v2299).Magnitude)
	local v2303 = CFrame.lookAt(v2301, v2300)
	v_u_80(p2293, Instance.new("Part"), v2302, v2303, v2296, v2297)
	for v2304 = 0, 2 do
		local v2305 = v2304 * 3.141592653589793 * 2 / 3 + 0.5
		v_u_1915(p2293, v2294 + v_u_8(math.cos(v2305) * 0.45, 0.75, math.sin(v2305) * 0.45), 0.28, v_u_14)
	end
	local v2306 = v2294 + Vector3.new(0, 1.4, 0)
	local v2307 = p2293.look.spirit or "#FF8AD8"
	local v2308, v2309 = Color3.fromHex(v2307)
	local v2310 = Instance.new("Part")
	v2310.Shape = Enum.PartType.Ball
	v_u_80(p2293, v2310, Vector3.new(0.52, 0.52, 0.52), v_u_9(v2306), v2308, v2309)
	local v2311 = v_u_9(v2306) * v_u_10(0.35, 0, 0) * v_u_10(0, 0, 1.5707963267948966)
	local v2312 = p2293.accent
	local v2313 = Instance.new("Part")
	v2313.Shape = Enum.PartType.Cylinder
	v_u_80(p2293, v2313, Vector3.new(0.05, 0.95, 0.95), v2311, v2312, nil)
end
function v_u_926.starhorns(p2314) -- name: starhorns
	-- upvalues: (copy) v_u_8, (copy) v_u_80, (copy) v_u_12, (copy) v_u_1915, (copy) v_u_14
	p2314.cur = p2314.byName.Head or p2314.bones[1]
	local v2315 = p2314.headC.Y + p2314.headS.Y / 2
	local v2316 = p2314.accent
	local v2317 = p2314.look.tip or "#7FFFF4"
	local v2318 = Color3.fromHex(v2317)
	for v2319 = -1, 1, 2 do
		local v2320 = v_u_8(v2319 * 0.5, v2315 - 0.12, p2314.headC.Z + 0.15)
		local v2321 = v2320 + v_u_8(v2319 * 0.25, 0.55, 0.3)
		local v2322 = v2321 + v_u_8(v2319 * 0.1, 0.35, 0.5)
		local v2323 = v2322 + Vector3.new(0, 0.1, 0.45)
		local v2324 = (v2321 - v2320).Unit * 0.3 * 0.4
		local v2325 = v2320 - v2324
		local v2326 = v2321 + v2324
		local v2327 = (v2325 + v2326) / 2
		local v2328 = v_u_8(0.3, 0.3, (v2326 - v2325).Magnitude)
		local v2329 = CFrame.lookAt(v2327, v2326)
		v_u_80(p2314, Instance.new("Part"), v2328, v2329, v2316, nil)
		local v2330 = (v2322 - v2321).Unit * 0.22 * 0.4
		local v2331 = v2321 - v2330
		local v2332 = v2322 + v2330
		local v2333 = (v2331 + v2332) / 2
		local v2334 = v_u_8(0.22, 0.22, (v2332 - v2331).Magnitude)
		local v2335 = CFrame.lookAt(v2333, v2332)
		v_u_80(p2314, Instance.new("Part"), v2334, v2335, v2316, nil)
		local v2336 = v_u_12
		local v2337 = (v2323 - v2322).Unit * 0.16 * 0.4
		local v2338 = v2322 - v2337
		local v2339 = v2323 + v2337
		local v2340 = (v2338 + v2339) / 2
		local v2341 = v_u_8(0.16, 0.16, (v2339 - v2338).Magnitude)
		local v2342 = CFrame.lookAt(v2340, v2339)
		v_u_80(p2314, Instance.new("Part"), v2341, v2342, v2318, v2336)
		v_u_1915(p2314, v2323 + Vector3.new(0, 0.02, 0.1), 0.4, v_u_14)
	end
end
local function v_u_2363(p2343, p2344, p2345, p2346, p2347) -- name: spiral
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_14, (copy) v_u_12, (copy) v_u_80
	local v2348 = v_u_8(p2345 * 0.28, p2345 * 0.28, 0.07)
	local v2349 = p2344 * v_u_10(0, 0, 0.7853981633974483)
	local v2350 = v_u_14
	local v2351 = v_u_12
	v_u_80(p2343, Instance.new("Part"), v2348, v2349, v2350, v2351)
	for v2352 = 0, 1 do
		for v2353 = 1, 4 do
			local v2354 = v2352 * 3.141592653589793 + v2353 * 0.75
			local v2355 = (v2353 * 0.13 + 0.1) * p2345
			local v2356 = v_u_8(math.cos(v2354) * v2355, math.sin(v2354) * v2355, 0)
			local v2357 = v_u_8(-math.sin(v2354), math.cos(v2354), 0)
			local v2358 = CFrame.fromMatrix(v2356, v2357, (Vector3.new(0, 0, 1)):Cross(v2357), Vector3.new(0, 0, 1))
			local v2359 = v_u_8((v2353 * 0.04 + 0.2) * p2345, (0.13 - v2353 * 0.015) * p2345, 0.05)
			local v2360 = p2344 * v2358
			local v2361
			if v2352 == 0 then
				v2361 = p2346
			else
				v2361 = p2347
			end
			local v2362 = v_u_12
			v_u_80(p2343, Instance.new("Part"), v2359, v2360, v2361, v2362)
		end
	end
end
function v_u_926.galaxy(p2364) -- name: galaxy
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_2363
	p2364.cur = p2364.byName.Body or p2364.bones[1]
	local v2365 = p2364.bodyC
	local v2366 = p2364.bodyS
	local v2367 = p2364.look.tip or "#7FFFF4"
	local v2368 = Color3.fromHex(v2367)
	for v2369 = -1, 1, 2 do
		v_u_2363(p2364, v_u_9(v2369 * (v2366.X / 2 + 0.03), v2365.Y + 0.05, v2365.Z + 0.05) * v_u_10(0, -v2369 * 3.141592653589793 / 2, 0), 1, p2364.glow, v2368)
	end
	v_u_2363(p2364, v_u_9(0, v2365.Y - 0.12, v2365.Z - v2366.Z / 2 - 0.11), 0.85, v2368, p2364.glow)
end
function v_u_926.orbitstars(p2370) -- name: orbitstars
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_1915
	local v2371 = p2370.look.tip or "#7FFFF4"
	local v2372 = Color3.fromHex(v2371)
	for v2373 = 1, 2 do
		local v2374 = v2373 == 1 and 1 or -1
		v_u_72(p2370, "Star" .. v2373, "Body", v_u_8(0, p2370.bodyC.Y + 0.4, p2370.bodyC.Z), "orbit", v2373 * 2.1, v2374)
		v_u_1915(p2370, v_u_8(v2374 * 2, p2370.bodyC.Y + 1.1, p2370.bodyC.Z + v2374 * 0.3), 0.5, v2372)
	end
end
local v_u_2375 = Color3.fromRGB(30, 26, 28)
local function v_u_2414(p2376, p2377, p2378) -- name: aegisEye
	-- upvalues: (copy) v_u_10, (copy) v_u_18, (copy) v_u_80, (copy) v_u_9, (copy) v_u_12, (copy) v_u_13, (copy) v_u_8
	local v2379 = v_u_10(0, 0, 0.7853981633974483)
	local v2380 = Vector3.new(0.4, 0.4, 0.06) * p2378
	local v2381 = p2377 * v2379
	local v2382 = v_u_18
	v_u_80(p2376, Instance.new("Part"), v2380, v2381, v2382, nil)
	local v2383 = Vector3.new(0.27, 0.27, 0.08) * p2378
	local v2384 = p2377 * v_u_9(0, 0, p2378 * -0.03) * v2379
	local v2385 = p2376.look.spirit or "#FF8A1A"
	local v2386 = Color3.fromHex(v2385)
	local v2387 = v_u_12
	v_u_80(p2376, Instance.new("Part"), v2383, v2384, v2386, v2387)
	local v2388 = Vector3.new(0.07, 0.3, 0.04) * p2378
	local v2389 = p2377 * v_u_9(0, 0, p2378 * -0.08)
	local v2390 = v_u_13
	v_u_80(p2376, Instance.new("Part"), v2388, v2389, v2390, nil)
	for v2391 = -1, 1, 2 do
		local v2392 = v_u_8(v2391 * 0.13, 0, 0) * p2378
		local v2393 = p2377.Position
		local v2394 = p2377.UpVector
		local v2395 = p2377.RightVector
		local v2396 = v2393 + v2394 * 0.27 * p2378
		local v2397 = v2395 * v2392.X
		local v2398 = v2394 * 0.2 * p2378
		local v2399 = p2378 * 0.05
		local v2400 = v_u_18
		local v2401 = -v2397.Unit
		local v2402 = v2398.Unit
		local v2403 = CFrame.fromMatrix(v2396 + v2397 / 2 + v2398 / 2, v2402:Cross(v2401), v2402, v2401)
		local v2404 = v_u_8(v2399, v2398.Magnitude, v2397.Magnitude)
		v_u_80(p2376, Instance.new("WedgePart"), v2404, v2403, v2400, nil)
		local v2405 = v2393 - v2394 * 0.27 * p2378
		local v2406 = v2395 * v2392.X
		local v2407 = -v2394 * 0.14 * p2378
		local v2408 = p2378 * 0.05
		local v2409 = v_u_18
		local v2410 = -v2406.Unit
		local v2411 = v2407.Unit
		local v2412 = CFrame.fromMatrix(v2405 + v2406 / 2 + v2407 / 2, v2411:Cross(v2410), v2411, v2410)
		local v2413 = v_u_8(v2408, v2407.Magnitude, v2406.Magnitude)
		v_u_80(p2376, Instance.new("WedgePart"), v2413, v2412, v2409, nil)
	end
end
function v_u_926.aegiseye(p2415) -- name: aegiseye
	-- upvalues: (copy) v_u_2414, (copy) v_u_9, (copy) v_u_10
	if p2415.look.shape == "seaturtle" then
		p2415.cur = p2415.byName.Body or p2415.bones[1]
		v_u_2414(p2415, v_u_9(0, 2.9, 0.32) * v_u_10(1.1207963267948966, 0, 0), 1.5)
	else
		p2415.cur = p2415.byName.Head or p2415.bones[1]
		v_u_2414(p2415, v_u_9(0, p2415.eyeY + 0.45, p2415.face - 0.04), 1)
	end
end
function v_u_926.aegis(p2416) -- name: aegis
	-- upvalues: (copy) v_u_9, (copy) v_u_2375, (copy) v_u_80, (copy) v_u_10, (copy) v_u_18, (copy) v_u_8, (copy) v_u_12, (copy) v_u_2414
	p2416.cur = p2416.byName.Body or p2416.bones[1]
	local v2417 = p2416.bodyC
	local v2418 = p2416.bodyS.X / 2 + 0.12
	local v2419 = v2417.Y + 0.1
	local v2420 = v2417.Z - 0.05
	local v2421 = v_u_9(v2418, v2419 + 0.1, v2420)
	local v2422 = v_u_2375
	v_u_80(p2416, Instance.new("Part"), Vector3.new(0.12, 1, 1), v2421, v2422, nil)
	local v2423 = v_u_9(v2418, v2419 - 0.4, v2420) * v_u_10(0.7853981633974483, 0, 0)
	local v2424 = v_u_2375
	v_u_80(p2416, Instance.new("Part"), Vector3.new(0.12, 0.72, 0.72), v2423, v2424, nil)
	local v2425 = v_u_9(v2418, v2419 + 0.6, v2420)
	local v2426 = v_u_18
	v_u_80(p2416, Instance.new("Part"), Vector3.new(0.18, 0.14, 1.12), v2425, v2426, nil)
	for v2427 = -1, 1, 2 do
		local v2428 = v_u_9(v2418, v2419 + 0.1, v2420 + v2427 * 0.5)
		local v2429 = v_u_18
		v_u_80(p2416, Instance.new("Part"), Vector3.new(0.18, 1, 0.12), v2428, v2429, nil)
		local v2430 = v_u_8(v2418, v2419 - 0.4, v2420 + v2427 * 0.5)
		local v2431 = v_u_8(v2418, v2419 - 0.91, v2420)
		local v2432 = v_u_18
		local v2433 = (v2431 - v2430).Unit * 0.12 * 0.4
		local v2434 = v2430 - v2433
		local v2435 = v2431 + v2433
		local v2436 = (v2434 + v2435) / 2
		local v2437 = v_u_8(0.12, 0.12, (v2435 - v2434).Magnitude)
		local v2438 = CFrame.lookAt(v2436, v2435)
		v_u_80(p2416, Instance.new("Part"), v2437, v2438, v2432, nil)
		local v2439 = v_u_8(v2418, v2419 + 0.66, v2420 + v2427 * 0.5)
		local v2440 = v_u_8(0, 0, -v2427 * 0.22)
		local v2441 = v_u_18
		local v2442 = -v2440.Unit
		local v2443 = (Vector3.new(0, 0.34, 0)).Unit
		local v2444 = CFrame.fromMatrix(v2439 + v2440 / 2 + Vector3.new(0, 0.17, 0), v2443:Cross(v2442), v2443, v2442)
		local v2445 = v_u_8(0.12, (Vector3.new(0, 0.34, 0)).Magnitude, v2440.Magnitude)
		v_u_80(p2416, Instance.new("WedgePart"), v2445, v2444, v2441, nil)
	end
	for v2446 = -1, 1, 2 do
		local v2447 = v_u_8(v2418 + 0.05, v2419 + 0.42 + v2446 * 0.08, v2420 - 0.38)
		local v2448 = v_u_8(v2418 + 0.05, v2419 - 0.22 + v2446 * 0.08, v2420 + 0.38)
		local v2449 = p2416.glow
		local v2450 = v_u_12
		local v2451 = (v2447 + v2448) / 2
		local v2452 = v_u_8(0.07, 0.07, (v2448 - v2447).Magnitude)
		local v2453 = CFrame.lookAt(v2451, v2448)
		v_u_80(p2416, Instance.new("Part"), v2452, v2453, v2449, v2450)
	end
	v_u_2414(p2416, v_u_9(v2418 + 0.08, v2419 + 0.08, v2420) * v_u_10(0, -1.5707963267948966, 0), 1.1)
end
function v_u_926.goldhorns(p2454) -- name: goldhorns
	-- upvalues: (copy) v_u_19, (copy) v_u_8, (copy) v_u_18, (copy) v_u_80, (copy) v_u_12
	p2454.cur = p2454.byName.Head or p2454.bones[1]
	local v2455 = p2454.headS.X / 2.2
	local v2456 = p2454.headC.Y + p2454.headS.Y / 2
	local v2457
	if p2454.look.glow then
		v2457 = p2454.glow
	else
		v2457 = v_u_19
	end
	for v2458 = -1, 1, 2 do
		local v2459 = v_u_8(v2458 * 0.62 * v2455, v2456 - 0.15, p2454.headC.Z + 0.1)
		local v2460 = v2459 + v_u_8(v2458 * 0.38, 0.32, 0.16) * v2455
		local v2461 = v2460 + v_u_8(v2458 * 0.1, 0.45, 0.22) * v2455
		local v2462 = v2461 + v_u_8(-v2458 * 0.1, 0.36, 0.3) * v2455
		local v2463 = 0.36 * v2455
		local v2464 = v_u_18
		local v2465 = (v2460 - v2459).Unit * v2463 * 0.4
		local v2466 = v2459 - v2465
		local v2467 = v2460 + v2465
		local v2468 = (v2466 + v2467) / 2
		local v2469 = v_u_8(v2463, v2463, (v2467 - v2466).Magnitude)
		local v2470 = CFrame.lookAt(v2468, v2467)
		v_u_80(p2454, Instance.new("Part"), v2469, v2470, v2464, nil)
		local v2471 = 0.27 * v2455
		local v2472 = v_u_18
		local v2473 = (v2461 - v2460).Unit * v2471 * 0.4
		local v2474 = v2460 - v2473
		local v2475 = v2461 + v2473
		local v2476 = (v2474 + v2475) / 2
		local v2477 = v_u_8(v2471, v2471, (v2475 - v2474).Magnitude)
		local v2478 = CFrame.lookAt(v2476, v2475)
		v_u_80(p2454, Instance.new("Part"), v2477, v2478, v2472, nil)
		local v2479 = 0.18 * v2455
		local v2480 = v_u_12
		local v2481 = (v2462 - v2461).Unit * v2479 * 0.4
		local v2482 = v2461 - v2481
		local v2483 = v2462 + v2481
		local v2484 = (v2482 + v2483) / 2
		local v2485 = v_u_8(v2479, v2479, (v2483 - v2482).Magnitude)
		local v2486 = CFrame.lookAt(v2484, v2483)
		v_u_80(p2454, Instance.new("Part"), v2485, v2486, v2457, v2480)
	end
end
function v_u_926.pauldrons(p2487) -- name: pauldrons
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_18, (copy) v_u_80, (copy) v_u_12
	p2487.cur = p2487.byName.Body or p2487.bones[1]
	local v2488 = p2487.bodyC
	local v2489 = p2487.bodyS
	for v2490 = -1, 1, 2 do
		local v2491 = v_u_9((v_u_8(v2490 * (v2489.X / 2 + 0.14), v2488.Y + v2489.Y * 0.3 + 0.05, v2488.Z - v2489.Z * 0.28))) * v_u_10(0, 0, -v2490 * 0.3)
		local v2492 = v_u_18
		v_u_80(p2487, Instance.new("Part"), Vector3.new(0.46, 0.62, 0.95), v2491, v2492, nil)
		local v2493 = v2491 * v_u_9(v2490 * 0.04, -0.33, 0)
		local v2494 = p2487.glow
		local v2495 = v_u_12
		v_u_80(p2487, Instance.new("Part"), Vector3.new(0.4, 0.09, 0.97), v2493, v2494, v2495)
		local v2496 = (v2491 * v_u_9(0, 0.26, 0)).Position
		local v2497 = v_u_8(v2490 * 0.14, 0.48, 0)
		local v2498 = v_u_18
		local v2499 = -(Vector3.new(0, 0, -0.24)).Unit
		local v2500 = v2497.Unit
		local v2501 = CFrame.fromMatrix(v2496 + Vector3.new(0, 0, -0.12) + v2497 / 2, v2500:Cross(v2499), v2500, v2499)
		local v2502 = v_u_8(0.12, v2497.Magnitude, (Vector3.new(0, 0, -0.24)).Magnitude)
		v_u_80(p2487, Instance.new("WedgePart"), v2502, v2501, v2498, nil)
		local v2503 = v_u_8(v2490 * 0.14, 0.48, 0)
		local v2504 = v_u_18
		local v2505 = -(Vector3.new(0, 0, 0.24)).Unit
		local v2506 = v2503.Unit
		local v2507 = CFrame.fromMatrix(v2496 + Vector3.new(0, 0, 0.12) + v2503 / 2, v2506:Cross(v2505), v2506, v2505)
		local v2508 = v_u_8(0.12, v2503.Magnitude, (Vector3.new(0, 0, 0.24)).Magnitude)
		v_u_80(p2487, Instance.new("WedgePart"), v2508, v2507, v2504, nil)
	end
end
local v_u_2509 = {
	{
		["x"] = 0.34,
		["z"] = 0.05,
		["y"] = -0.12,
		["size"] = Vector3.new(0.36, 0.26, 0.5),
		["turn"] = 0.3
	},
	{
		["x"] = -0.33,
		["z"] = -0.12,
		["y"] = -0.14,
		["size"] = Vector3.new(0.34, 0.22, 0.42),
		["turn"] = -0.4
	},
	{
		["x"] = -0.05,
		["z"] = 0.38,
		["y"] = -0.12,
		["size"] = Vector3.new(0.5, 0.24, 0.3),
		["turn"] = 0.15
	}
}
function v_u_926.crust(p2510) -- name: crust
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2375, (copy) v_u_80, (copy) v_u_12, (copy) v_u_2509, (copy) v_u_10
	p2510.cur = p2510.byName.Head or p2510.bones[1]
	local v2511 = p2510.headC.Y + p2510.headS.Y / 2
	local v2512 = p2510.headC.Z + 0.02
	local v2513 = v_u_8(p2510.headS.X * 0.58, 0.16, p2510.headS.Z * 0.6)
	local v2514 = v_u_9(0, v2511 + 0.04, v2512)
	local v2515 = v_u_2375
	v_u_80(p2510, Instance.new("Part"), v2513, v2514, v2515, nil)
	local v2516 = v2511 + 0.13
	local v2517 = v_u_8(0.02, v2516, v2512 + 0.12)
	local v2518 = v_u_8(-0.42, v2516, v2512 - 0.22)
	local v2519 = p2510.glow
	local v2520 = v_u_12
	local v2521 = (v2517 - v2518).Unit * 0.09 * 0.4
	local v2522 = v2518 - v2521
	local v2523 = v2517 + v2521
	local v2524 = (v2522 + v2523) / 2
	local v2525 = v_u_8(0.09, 0.09, (v2523 - v2522).Magnitude)
	local v2526 = CFrame.lookAt(v2524, v2523)
	v_u_80(p2510, Instance.new("Part"), v2525, v2526, v2519, v2520)
	local v2527 = v_u_8(0.4, v2516, v2512 - 0.12)
	local v2528 = p2510.glow
	local v2529 = v_u_12
	local v2530 = (v2527 - v2517).Unit * 0.09 * 0.4
	local v2531 = v2517 - v2530
	local v2532 = v2527 + v2530
	local v2533 = (v2531 + v2532) / 2
	local v2534 = v_u_8(0.09, 0.09, (v2532 - v2531).Magnitude)
	local v2535 = CFrame.lookAt(v2533, v2532)
	v_u_80(p2510, Instance.new("Part"), v2534, v2535, v2528, v2529)
	local v2536 = v_u_8(0.14, v2516, v2512 + 0.5)
	local v2537 = p2510.glow
	local v2538 = v_u_12
	local v2539 = (v2536 - v2517).Unit * 0.09 * 0.4
	local v2540 = v2517 - v2539
	local v2541 = v2536 + v2539
	local v2542 = (v2540 + v2541) / 2
	local v2543 = v_u_8(0.09, 0.09, (v2541 - v2540).Magnitude)
	local v2544 = CFrame.lookAt(v2542, v2541)
	v_u_80(p2510, Instance.new("Part"), v2543, v2544, v2537, v2538)
	for _, v2545 in v_u_2509 do
		local v2546 = v_u_8(v2545.x * p2510.headS.X, v2511 + v2545.y, p2510.headC.Z + v2545.z * p2510.headS.Z)
		local v2547 = v2545.size
		local v2548 = v_u_9(v2546) * v_u_10(0.12, v2545.turn, -0.1)
		local v2549 = v_u_2375
		v_u_80(p2510, Instance.new("Part"), v2547, v2548, v2549, nil)
	end
end
function v_u_926.shellcracks(p2550) -- name: shellcracks
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p2550.cur = p2550.byName.Body or p2550.bones[1]
	if p2550.look.shape == "seaturtle" then
		for v2551 = -1, 1, 2 do
			local v2552 = v2551 * 1.135
			local v2553 = {
				v_u_8(v2552, 2.1, -0.65),
				v_u_8(v2552, 1.88, -0.030000000000000027),
				v_u_8(v2552, 2.08, 0.59),
				(v_u_8(v2552, 1.88, 1.25))
			}
			local v2554 = v2553[1]
			local v2555 = v2553[2]
			local v2556 = p2550.glow
			local v2557 = v_u_12
			local v2558 = (v2555 - v2554).Unit * 0.09 * 0.4
			local v2559 = v2554 - v2558
			local v2560 = v2555 + v2558
			local v2561 = (v2559 + v2560) / 2
			local v2562 = v_u_8(0.09, 0.09, (v2560 - v2559).Magnitude)
			local v2563 = CFrame.lookAt(v2561, v2560)
			v_u_80(p2550, Instance.new("Part"), v2562, v2563, v2556, v2557)
			local v2564 = v2553[2]
			local v2565 = v2553[3]
			local v2566 = p2550.glow
			local v2567 = v_u_12
			local v2568 = (v2565 - v2564).Unit * 0.09 * 0.4
			local v2569 = v2564 - v2568
			local v2570 = v2565 + v2568
			local v2571 = (v2569 + v2570) / 2
			local v2572 = v_u_8(0.09, 0.09, (v2570 - v2569).Magnitude)
			local v2573 = CFrame.lookAt(v2571, v2570)
			v_u_80(p2550, Instance.new("Part"), v2572, v2573, v2566, v2567)
			local v2574 = v2553[3]
			local v2575 = v2553[4]
			local v2576 = p2550.glow
			local v2577 = v_u_12
			local v2578 = (v2575 - v2574).Unit * 0.09 * 0.4
			local v2579 = v2574 - v2578
			local v2580 = v2575 + v2578
			local v2581 = (v2579 + v2580) / 2
			local v2582 = v_u_8(0.09, 0.09, (v2580 - v2579).Magnitude)
			local v2583 = CFrame.lookAt(v2581, v2580)
			v_u_80(p2550, Instance.new("Part"), v2582, v2583, v2576, v2577)
			local v2584 = v_u_8(v2551 * 0.52, 2.51, 0.6499999999999999)
			local v2585 = v_u_8(v2551 * 0.82, 2.51, 1.1)
			local v2586 = p2550.glow
			local v2587 = v_u_12
			local v2588 = (v2585 - v2584).Unit * 0.09 * 0.4
			local v2589 = v2584 - v2588
			local v2590 = v2585 + v2588
			local v2591 = (v2589 + v2590) / 2
			local v2592 = v_u_8(0.09, 0.09, (v2590 - v2589).Magnitude)
			local v2593 = CFrame.lookAt(v2591, v2590)
			v_u_80(p2550, Instance.new("Part"), v2592, v2593, v2586, v2587)
		end
	else
		local v2594 = p2550.bodyC.Y + p2550.bodyS.Y / 2
		local v2595 = p2550.bodyC.Z + 0.15
		local v2596 = p2550.bodyS.X
		local v2597 = p2550.bodyS.Z
		for v2598 = -1, 1, 2 do
			local v2599 = v2598 * ((v2596 + 0.36) / 2 + 0.01)
			local v2600 = {
				v_u_8(v2599, v2594 + 0.2, v2595 - v2597 * 0.4),
				v_u_8(v2599, v2594 - 0.08, v2595 - v2597 * 0.12),
				v_u_8(v2599, v2594 + 0.18, v2595 + v2597 * 0.14),
				(v_u_8(v2599, v2594 - 0.06, v2595 + v2597 * 0.4))
			}
			local v2601 = v2600[1]
			local v2602 = v2600[2]
			local v2603 = p2550.glow
			local v2604 = v_u_12
			local v2605 = (v2602 - v2601).Unit * 0.09 * 0.4
			local v2606 = v2601 - v2605
			local v2607 = v2602 + v2605
			local v2608 = (v2606 + v2607) / 2
			local v2609 = v_u_8(0.09, 0.09, (v2607 - v2606).Magnitude)
			local v2610 = CFrame.lookAt(v2608, v2607)
			v_u_80(p2550, Instance.new("Part"), v2609, v2610, v2603, v2604)
			local v2611 = v2600[2]
			local v2612 = v2600[3]
			local v2613 = p2550.glow
			local v2614 = v_u_12
			local v2615 = (v2612 - v2611).Unit * 0.09 * 0.4
			local v2616 = v2611 - v2615
			local v2617 = v2612 + v2615
			local v2618 = (v2616 + v2617) / 2
			local v2619 = v_u_8(0.09, 0.09, (v2617 - v2616).Magnitude)
			local v2620 = CFrame.lookAt(v2618, v2617)
			v_u_80(p2550, Instance.new("Part"), v2619, v2620, v2613, v2614)
			local v2621 = v2600[3]
			local v2622 = v2600[4]
			local v2623 = p2550.glow
			local v2624 = v_u_12
			local v2625 = (v2622 - v2621).Unit * 0.09 * 0.4
			local v2626 = v2621 - v2625
			local v2627 = v2622 + v2625
			local v2628 = (v2626 + v2627) / 2
			local v2629 = v_u_8(0.09, 0.09, (v2627 - v2626).Magnitude)
			local v2630 = CFrame.lookAt(v2628, v2627)
			v_u_80(p2550, Instance.new("Part"), v2629, v2630, v2623, v2624)
		end
		local v2631 = v2594 + 0.98
		local v2632 = v_u_8(-v2596 * 0.2, v2631, v2595 - v2597 * 0.2)
		local v2633 = v_u_8(0.02, v2631, v2595)
		local v2634 = p2550.glow
		local v2635 = v_u_12
		local v2636 = (v2633 - v2632).Unit * 0.09 * 0.4
		local v2637 = v2632 - v2636
		local v2638 = v2633 + v2636
		local v2639 = (v2637 + v2638) / 2
		local v2640 = v_u_8(0.09, 0.09, (v2638 - v2637).Magnitude)
		local v2641 = CFrame.lookAt(v2639, v2638)
		v_u_80(p2550, Instance.new("Part"), v2640, v2641, v2634, v2635)
		local v2642 = v_u_8(0.02, v2631, v2595)
		local v2643 = v_u_8(v2596 * 0.16, v2631, v2595 + v2597 * 0.22)
		local v2644 = p2550.glow
		local v2645 = v_u_12
		local v2646 = (v2643 - v2642).Unit * 0.09 * 0.4
		local v2647 = v2642 - v2646
		local v2648 = v2643 + v2646
		local v2649 = (v2647 + v2648) / 2
		local v2650 = v_u_8(0.09, 0.09, (v2648 - v2647).Magnitude)
		local v2651 = CFrame.lookAt(v2649, v2648)
		v_u_80(p2550, Instance.new("Part"), v2650, v2651, v2644, v2645)
	end
end
local v_u_2652 = Color3.fromRGB(255, 176, 210)
local v_u_2653 = Color3.fromRGB(255, 108, 165)
local v_u_2654 = Color3.fromRGB(222, 228, 240)
local v_u_2655 = Color3.fromRGB(248, 240, 222)
local v_u_2656 = Color3.fromRGB(205, 26, 42)
local v_u_2657 = Color3.fromRGB(250, 250, 252)
local v_u_2658 = {
	Vector3.new(0, 2, -0.2),
	Vector3.new(1, 2.2, 0.35),
	Vector3.new(1.6, 1.8, 1.2),
	Vector3.new(0.4, 1.5, 1.8),
	Vector3.new(-1.1, 1.9, 1.9),
	Vector3.new(-1.7, 2.8, 2.3)
}
local v_u_2659 = {
	1.3,
	1.12,
	0.96,
	0.8,
	0.62
}
local function v_u_2666(p2660, p2661, p2662, p2663, p2664, p2665) -- name: flameTongue
	-- upvalues: (copy) v_u_124, (copy) v_u_9, (copy) v_u_12
	v_u_124(p2660, (p2661 * v_u_9(-p2662 / 2, 0, 0)).Position, (p2661 * v_u_9(p2662 / 2, 0, 0)).Position, (p2661 * v_u_9(0, p2663, 0)).Position, 0.12, p2664, v_u_12)
	v_u_124(p2660, (p2661 * v_u_9(-p2662 * 0.28, 0.06, 0)).Position, (p2661 * v_u_9(p2662 * 0.28, 0.06, 0)).Position, (p2661 * v_u_9(0, p2663 * 0.55, 0)).Position, 0.18, p2665, v_u_12)
end
function v_u_925.butterfly(p2667) -- name: butterfly
	-- upvalues: (copy) v_u_12, (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_8, (copy) v_u_13, (copy) v_u_10, (copy) v_u_162, (copy) v_u_167
	local v2668 = p2667.look
	local v2669 = v2668.wings or { v2668.body }
	local v2670 = v2669[1]
	local v2671 = Color3.fromHex(v2670)
	local v2672 = v2669[2] or v2668.accent
	local v2673 = Color3.fromHex(v2672)
	local v2674
	if v2672 == v2668.glow then
		v2674 = v_u_12
	else
		v2674 = nil
	end
	p2667.cur = p2667.byName.Body or p2667.bones[1]
	p2667.bodyC = Vector3.new(0, 1.45, 0.3)
	p2667.bodyS = Vector3.new(1.2, 1.1, 1.25)
	local v2675 = p2667.bodyS
	local v2676 = v_u_9(p2667.bodyC)
	local v2677 = p2667.body
	v_u_80(p2667, Instance.new("Part"), v2675, v2676, v2677, nil)
	local v2678 = v_u_9(0, 1.38, -0.33)
	local v2679 = p2667.belly
	v_u_80(p2667, Instance.new("Part"), Vector3.new(0.85, 0.72, 0.1), v2678, v2679, nil)
	local v2680 = v_u_9(0, 1.95, 0.05)
	local v2681 = p2667.belly
	v_u_80(p2667, Instance.new("Part"), Vector3.new(1.45, 0.42, 1), v2680, v2681, nil)
	for v2682 = -1, 1, 2 do
		local v2683 = v2682 * 0.3
		v_u_72(p2667, v2682 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v2683, 0.95, 0.2), "leg", v2682 < 0 and 0 or 3.141592653589793)
		local v2684 = v_u_9(v2683, 0.75, 0.2)
		local v2685, v2686 = p2667.limbs:Lerp(v_u_13, 0.3)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.2, 0.45, 0.2), v2684, v2685, v2686)
	end
	p2667.tailAt = Vector3.new(0, 1.3, 0.9)
	v_u_72(p2667, "Tail1", "Body", p2667.tailAt, "tail", 0.3)
	local v2687 = v_u_9(0, 1.25, 1.2)
	local v2688 = p2667.body
	v_u_80(p2667, Instance.new("Part"), Vector3.new(0.85, 0.8, 0.75), v2687, v2688, nil)
	local v2689 = v_u_9(0, 1.25, 1.36)
	v_u_80(p2667, Instance.new("Part"), Vector3.new(0.9, 0.85, 0.14), v2689, v2673, v2674)
	local v2690 = v_u_9(0, 1.15, 1.75)
	local v2691 = p2667.body
	v_u_80(p2667, Instance.new("Part"), Vector3.new(0.6, 0.55, 0.5), v2690, v2691, nil)
	for v2692 = -1, 1, 2 do
		local v2693 = v_u_8(v2692 * 0.4, 1.8, 0.75)
		v_u_72(p2667, v2692 < 0 and "WingL" or "WingR", "Body", v2693, "wing", 0, v2692)
		local v2694 = v_u_9(v2693) * v_u_10(0.25, 0, 0)
		local v2695 = v2694 * v_u_10(0, 0, v2692 * 0.35) * v_u_9(v2692 * 1.12, 0.65, 0)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(2.1, 1.65, 0.1), v2695, v2671, nil)
		local v2696 = v2695 * v_u_9(v2692 * 0.93, 0, 0)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.3, 1.55, 0.13), v2696, v2673, v2674)
		local v2697 = v2695 * v_u_9(v2692 * 0.05, 0.1, 0) * v_u_10(0, 0, 0.7853981633974483)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.45, 0.45, 0.13), v2697, v2673, v2674)
		local v2698 = v2694 * v_u_9(0, 0, 0.07) * v_u_10(0, 0, -v2692 * 0.45) * v_u_9(v2692 * 0.8, -0.45, 0)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(1.3, 1, 0.1), v2698, v2671, nil)
		local v2699 = v2698 * v_u_9(v2692 * 0.2, 0, 0) * v_u_10(0, 0, 0.7853981633974483)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.36, 0.36, 0.13), v2699, v2673, v2674)
		local v2700 = v2698 * v_u_9(v2692 * 0.5, -0.5, 0) * v_u_10(0, 0, v2692 * 0.35) * v_u_9(0, -0.45, 0)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.26, 0.95, 0.1), v2700, v2671, nil)
		local v2701 = v2700 * v_u_9(0, -0.5, 0) * v_u_10(0, 0, 0.7853981633974483)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.32, 0.32, 0.13), v2701, v2673, v2674)
	end
	p2667.headC = Vector3.new(0, 2.6, -0.4)
	p2667.headS = Vector3.new(1.85, 1.6, 1.5)
	p2667.face = p2667.headC.Z - p2667.headS.Z / 2
	p2667.eyeX = 0.45
	p2667.eyeY = 2.62
	p2667.mouthY = 2.12
	p2667.bandY = 3.05
	p2667.plateW = 0.85
	p2667.neck = Vector3.new(0, 1.75, -0.4)
	p2667.back = Vector3.new(0, 2, 0.6)
	v_u_72(p2667, "Head", "Body", Vector3.new(0, 2, -0.2), "head")
	local v2702 = p2667.headS
	local v2703 = v_u_9(p2667.headC)
	local v2704 = p2667.body
	v_u_80(p2667, Instance.new("Part"), v2702, v2703, v2704, nil)
	local v2705 = v_u_9(0, 2.5, p2667.face - 0.02)
	local v2706 = p2667.belly
	v_u_80(p2667, Instance.new("Part"), Vector3.new(1.5, 1.05, 0.08), v2705, v2706, nil)
	local v2707 = p2667.face
	p2667.face = v2707 - 0.06
	v_u_162(p2667, 0.42, 0.54)
	v_u_167(p2667)
	local v2708 = v_u_9(0, p2667.mouthY, p2667.face - 0.03)
	local v2709 = v_u_13
	v_u_80(p2667, Instance.new("Part"), Vector3.new(0.26, 0.08, 0.05), v2708, v2709, nil)
	p2667.face = v2707
	local v2710 = p2667.headC.Y + p2667.headS.Y / 2
	for v2711 = -1, 1, 2 do
		local v2712 = v_u_8(v2711 * 0.35, v2710 - 0.05, p2667.headC.Z - 0.1)
		v_u_72(p2667, v2711 < 0 and "AntennaL" or "AntennaR", "Head", v2712, "lure", v2711 * 1.1)
		local v2713 = v2712 + v_u_8(v2711 * 0.3, 0.72, -0.15)
		local v2714 = v2713 + v_u_8(v2711 * 0.28, 0.22, -0.1)
		local v2715 = v_u_13
		local v2716 = (v2713 - v2712).Unit * 0.1 * 0.4
		local v2717 = v2712 - v2716
		local v2718 = v2713 + v2716
		local v2719 = (v2717 + v2718) / 2
		local v2720 = v_u_8(0.1, 0.1, (v2718 - v2717).Magnitude)
		local v2721 = CFrame.lookAt(v2719, v2718)
		v_u_80(p2667, Instance.new("Part"), v2720, v2721, v2715, nil)
		local v2722 = v_u_13
		local v2723 = (v2714 - v2713).Unit * 0.09 * 0.4
		local v2724 = v2713 - v2723
		local v2725 = v2714 + v2723
		local v2726 = (v2724 + v2725) / 2
		local v2727 = v_u_8(0.09, 0.09, (v2725 - v2724).Magnitude)
		local v2728 = CFrame.lookAt(v2726, v2725)
		v_u_80(p2667, Instance.new("Part"), v2727, v2728, v2722, nil)
		local v2729 = v_u_9(v2714) * v_u_10(0, 0.7853981633974483, 0.7853981633974483)
		v_u_80(p2667, Instance.new("Part"), Vector3.new(0.24, 0.24, 0.24), v2729, v2673, v2674)
	end
end
function v_u_925.spirit(p2730) -- name: spiritBody
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_8, (copy) v_u_10, (copy) v_u_12, (copy) v_u_124, (copy) v_u_162, (copy) v_u_167, (copy) v_u_13
	p2730.cur = p2730.byName.Body or p2730.bones[1]
	p2730.bodyC = Vector3.new(0, 1.55, 0.15)
	p2730.bodyS = Vector3.new(1.4, 1.05, 1.25)
	local v2731 = p2730.bodyS
	local v2732 = v_u_9(p2730.bodyC)
	local v2733 = p2730.body
	v_u_80(p2730, Instance.new("Part"), v2731, v2732, v2733, nil)
	local v2734 = v_u_9(0, 1.5, -0.48)
	local v2735 = p2730.belly
	v_u_80(p2730, Instance.new("Part"), Vector3.new(0.95, 0.7, 0.1), v2734, v2735, nil)
	for v2736 = -1, 1, 2 do
		v_u_72(p2730, v2736 < 0 and "ArmL" or "ArmR", "Body", v_u_8(v2736 * 0.68, 1.85, 0.05), "arm", v2736 * 0.9, v2736)
		local v2737 = v_u_9(v2736 * 0.84, 1.55, -0.05) * v_u_10(0, 0, v2736 * 0.3)
		local v2738 = p2730.body
		v_u_80(p2730, Instance.new("Part"), Vector3.new(0.34, 0.6, 0.38), v2737, v2738, nil)
	end
	p2730.tailAt = Vector3.new(0, 1.15, 0.65)
	v_u_72(p2730, "Tail1", "Body", p2730.tailAt, "tail", 0)
	local v2739 = v_u_9(0, 1, 0.9) * v_u_10(0.35, 0, 0)
	local v2740 = p2730.body
	v_u_80(p2730, Instance.new("Part"), Vector3.new(1.05, 0.8, 0.85), v2739, v2740, nil)
	v_u_72(p2730, "Tail2", "Tail1", Vector3.new(0, 0.75, 1.25), "tail", 0.9)
	local v2741 = v_u_9(0, 0.8, 1.5) * v_u_10(-0.2, 0, 0)
	local v2742 = p2730.body
	v_u_80(p2730, Instance.new("Part"), Vector3.new(0.72, 0.58, 0.7), v2741, v2742, nil)
	local v2743
	if p2730.look.tip then
		local v2744 = p2730.look.tip
		v2743 = Color3.fromHex(v2744)
	else
		v2743 = p2730.accent
	end
	local v2745
	if p2730.look.tip then
		v2745 = v_u_12
	else
		v2745 = nil
	end
	v_u_124(p2730, Vector3.new(-0.24, 0.85, 1.78), Vector3.new(0.24, 0.85, 1.78), Vector3.new(0, 1.6, 2.05), 0.34, v2743, v2745)
	v_u_124(p2730, Vector3.new(0, 0.85, 1.6), Vector3.new(0, 0.85, 2), Vector3.new(0, 1.45, 2.1), 0.3, v2743, v2745)
	p2730.headC = Vector3.new(0, 2.8, -0.15)
	p2730.headS = Vector3.new(2.05, 1.75, 1.7)
	p2730.face = p2730.headC.Z - p2730.headS.Z / 2
	p2730.eyeX = 0.48
	p2730.eyeY = 2.82
	p2730.mouthY = 2.3
	p2730.bandY = 3.3
	p2730.plateW = 0.9
	p2730.neck = Vector3.new(0, 1.98, -0.5)
	p2730.back = Vector3.new(0, 2.08, 0.75)
	v_u_72(p2730, "Head", "Body", Vector3.new(0, 2.05, -0.05), "head")
	local v2746 = p2730.headS
	local v2747 = v_u_9(p2730.headC)
	local v2748 = p2730.body
	v_u_80(p2730, Instance.new("Part"), v2746, v2747, v2748, nil)
	v_u_162(p2730, 0.42, 0.56)
	v_u_167(p2730)
	for v2749 = -1, 1, 2 do
		local v2750 = v_u_9(v2749 * 0.08, p2730.mouthY, p2730.face - 0.03) * v_u_10(0, 0, v2749 * 0.45)
		local v2751 = v_u_13
		v_u_80(p2730, Instance.new("Part"), Vector3.new(0.2, 0.07, 0.05), v2750, v2751, nil)
	end
	local v2752 = p2730.headC.Y + p2730.headS.Y / 2
	for v2753 = -1, 1, 2 do
		local v2754 = v_u_8(v2753 * 0.55, v2752 - 0.1, p2730.headC.Z)
		v_u_72(p2730, v2753 < 0 and "EarL" or "EarR", "Head", v2754, "ear", v2753 * 1.3, v2753)
		local v2755 = v_u_9(v2754) * v_u_10(0, 0, -v2753 * 0.85) * v_u_9(0, 0.4, 0)
		local v2756 = p2730.body
		v_u_80(p2730, Instance.new("Part"), Vector3.new(0.64, 0.82, 0.26), v2755, v2756, nil)
		local v2757 = v2755 * v_u_9(0, -0.02, -0.14)
		local v2758 = p2730.glow
		local v2759
		if p2730.look.glow then
			v2759 = v_u_12
		else
			v2759 = nil
		end
		v_u_80(p2730, Instance.new("Part"), Vector3.new(0.3, 0.56, 0.06), v2757, v2758, v2759)
	end
end
function v_u_925.firebird(p2760) -- name: firebird
	-- upvalues: (copy) v_u_22, (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_10, (copy) v_u_8, (copy) v_u_124, (copy) v_u_12, (copy) v_u_162, (copy) v_u_13
	p2760.cur = p2760.byName.Body or p2760.bones[1]
	local v2761 = p2760.look
	local v2762
	if v2761.beak then
		local v2763 = v2761.beak
		v2762 = Color3.fromHex(v2763)
	else
		v2762 = v_u_22
	end
	local v2764 = v2761.wings or { v2761.glow or v2761.accent }
	p2760.bodyC = Vector3.new(0, 1.2, 0.25)
	p2760.bodyS = Vector3.new(1.5, 1.35, 1.7)
	local v2765 = p2760.bodyS
	local v2766 = v_u_9(p2760.bodyC)
	local v2767 = p2760.body
	v_u_80(p2760, Instance.new("Part"), v2765, v2766, v2767, nil)
	local v2768 = v_u_9(0, 1.1, -0.63)
	local v2769 = p2760.belly
	v_u_80(p2760, Instance.new("Part"), Vector3.new(1.1, 0.95, 0.1), v2768, v2769, nil)
	for v2770 = -1, 1, 2 do
		local v2771 = v_u_9(v2770 * 0.35, 0.3, 0.2)
		v_u_80(p2760, Instance.new("Part"), Vector3.new(0.2, 0.45, 0.2), v2771, v2762, nil)
		local v2772 = v_u_9(v2770 * 0.35, 0.05, 0.1)
		v_u_80(p2760, Instance.new("Part"), Vector3.new(0.34, 0.1, 0.45), v2772, v2762, nil)
	end
	p2760.tailAt = Vector3.new(0, 1, 1.05)
	v_u_72(p2760, "Tail1", "Body", p2760.tailAt, "tail", 0)
	for v2773 = 1, 3 do
		local v2774 = v2773 - 2
		local v2775 = v2774 == 0 and 1.45 or 1.1
		local v2776 = v_u_9(p2760.tailAt) * v_u_10(0, v2774 * 0.42, 0) * v_u_10(v2774 == 0 and -0.45 or -0.25, 0, 0)
		local v2777 = v_u_8(0.34, 0.12, v2775)
		local v2778 = v2776 * v_u_9(0, 0, v2775 / 2)
		local v2779 = p2760.body
		v_u_80(p2760, Instance.new("Part"), v2777, v2778, v2779, nil)
		local v2780 = #v2764
		local v2781 = v2764[math.min(v2773, v2780)]
		local v2782 = Color3.fromHex(v2781)
		local v2783 = v2776 * v_u_9(0, 0, v2775 - 0.05)
		v_u_124(p2760, (v2783 * v_u_9(-0.24, 0, 0)).Position, (v2783 * v_u_9(0.24, 0, 0)).Position, (v2783 * v_u_9(0, 0.55, 0.75)).Position, 0.12, v2782, v_u_12)
	end
	for v2784 = -1, 1, 2 do
		local v2785 = v_u_8(v2784 * 0.6, 1.6, 0.15)
		v_u_72(p2760, v2784 < 0 and "WingL" or "WingR", "Body", v2785, "wing", 0, v2784)
		local v2786 = v_u_9(v2785) * v_u_10(0, 0, v2784 * 0.45)
		for v2787 = 1, 3 do
			local v2788 = (1.55 - v2787 * 0.2) * 1.25
			local v2789 = v2786 * v_u_10(0, -v2784 * (v2787 - 1) * 0.42, 0)
			local v2790 = v_u_8(v2788, 0.14, 0.55)
			local v2791 = v2789 * v_u_9(v2784 * v2788 / 2, v2787 * -0.03, 0) * v_u_10(-0.7, 0, 0)
			local v2792 = p2760.body
			v_u_80(p2760, Instance.new("Part"), v2790, v2791, v2792, nil)
			local v2793 = v2789 * v_u_9(v2784 * (v2788 - 0.05), v2787 * -0.03, 0) * v_u_10(-0.7, 0, 0)
			local v2794 = v_u_124
			local v2795 = (v2793 * v_u_9(0, 0, -0.27)).Position
			local v2796 = (v2793 * v_u_9(0, 0, 0.27)).Position
			local v2797 = (v2793 * v_u_9(v2784 * 0.95, 0.15, 0.3)).Position
			local v2798 = #v2764
			local v2799 = v2764[math.min(v2787, v2798)]
			v2794(p2760, v2795, v2796, v2797, 0.14, Color3.fromHex(v2799), v_u_12)
		end
	end
	p2760.headC = Vector3.new(0, 2.45, -0.45)
	p2760.headS = Vector3.new(1.75, 1.55, 1.55)
	p2760.face = p2760.headC.Z - p2760.headS.Z / 2
	p2760.eyeX = 0.45
	p2760.eyeY = 2.6
	p2760.mouthY = 2.1
	p2760.bandY = 3
	p2760.plateW = 0.85
	p2760.neck = Vector3.new(0, 1.55, -0.62)
	p2760.back = Vector3.new(0, 1.85, 0.5)
	v_u_72(p2760, "Head", "Body", Vector3.new(0, 1.75, -0.2), "head")
	local v2800 = p2760.headS
	local v2801 = v_u_9(p2760.headC)
	local v2802 = p2760.body
	v_u_80(p2760, Instance.new("Part"), v2800, v2801, v2802, nil)
	v_u_162(p2760, 0.42, 0.48)
	local v2803 = v_u_9(0, 2.2, p2760.face - 0.27)
	v_u_80(p2760, Instance.new("WedgePart"), Vector3.new(0.42, 0.26, 0.55), v2803, v2762, nil)
	local v2804 = v_u_9(0, 2.02, p2760.face - 0.15)
	local v2805, v2806 = v2762:Lerp(v_u_13, 0.3)
	v_u_80(p2760, Instance.new("Part"), Vector3.new(0.3, 0.1, 0.32), v2804, v2805, v2806)
end
function v_u_925.skydragon(p2807) -- name: skydragon
	-- upvalues: (copy) v_u_2658, (copy) v_u_72, (copy) v_u_2659, (copy) v_u_8, (copy) v_u_80, (copy) v_u_9, (copy) v_u_10, (copy) v_u_39, (copy) v_u_12, (copy) v_u_124, (copy) v_u_162
	p2807.cur = p2807.byName.Body or p2807.bones[1]
	local v2808 = p2807.look
	local v2809 = p2807.body:Lerp(p2807.glow, 0.15)
	for v2810 = 1, 5 do
		local v2811 = v_u_2658[v2810]
		local v2812 = v_u_2658[v2810 + 1]
		if v2810 > 1 then
			v_u_72(p2807, "Seg" .. v2810, v2810 == 2 and "Body" or "Seg" .. v2810 - 1, v2811, "swim", v2810 * 0.9)
		end
		local v2813 = v_u_2659[v2810]
		local v2814 = CFrame.lookAt((v2811 + v2812) / 2, v2812)
		local v2815 = (v2812 - v2811).Magnitude + 0.3
		local v2816 = v_u_8(v2813, v2813 * 0.92, v2815)
		local v2817
		if v2810 % 2 == 0 then
			v2817 = v2809
		else
			v2817 = p2807.body
		end
		v_u_80(p2807, Instance.new("Part"), v2816, v2814, v2817, nil)
		if v2810 <= 3 then
			local v2818 = v_u_8(v2813 * 0.66, 0.1, v2815 - 0.15)
			local v2819 = v2814 * v_u_9(0, -v2813 * 0.46, 0)
			local v2820 = p2807.belly
			v_u_80(p2807, Instance.new("Part"), v2818, v2819, v2820, nil)
		end
		local v2821 = 0.3 + v2813 * 0.35
		local v2822 = v2810 % 2 == 1
		local v2823 = v_u_8(0.24, v2821, 0.24)
		local v2824 = v2814 * v_u_9(0, v2813 * 0.42, 0) * v_u_10(-0.45, 0, 0) * v_u_9(0, v2821 / 2, 0) * v_u_10(0, 0.7853981633974483, 0)
		local v2825
		if v2822 then
			v2825 = p2807.glow
		else
			v2825 = v_u_39
		end
		local v2826
		if v2822 then
			v2826 = v_u_12
		else
			v2826 = nil
		end
		v_u_80(p2807, Instance.new("Part"), v2823, v2824, v2825, v2826)
		if v2810 ~= 1 and v2810 ~= 3 then
			continue
		end
		for v2827 = -1, 1, 2 do
			local v2828 = (v2814 * v_u_9(v2827 * v2813 * 0.4, -v2813 * 0.28, 0)).Position
			local v2829 = v2828 + v_u_8(v2827 * 0.12, -0.6, -0.12)
			local v2830 = p2807.limbs
			local v2831 = (v2829 - v2828).Unit * 0.26 * 0.4
			local v2832 = v2828 - v2831
			local v2833 = v2829 + v2831
			local v2834 = (v2832 + v2833) / 2
			local v2835 = v_u_8(0.26, 0.26, (v2833 - v2832).Magnitude)
			local v2836 = CFrame.lookAt(v2834, v2833)
			v_u_80(p2807, Instance.new("Part"), v2835, v2836, v2830, nil)
			local v2837 = v_u_9(v2829 + Vector3.new(0, -0.06, -0.1))
			local v2838 = p2807.limbs
			v_u_80(p2807, Instance.new("Part"), Vector3.new(0.34, 0.14, 0.4), v2837, v2838, nil)
		end
	end
	local v2839 = v_u_2658[6]
	v_u_72(p2807, "Fin", "Seg5", v2839, "swim", 5.4)
	local v2840 = v_u_9(v2839 + Vector3.new(0, 0, 0.1))
	local v2841 = p2807.body
	v_u_80(p2807, Instance.new("Part"), Vector3.new(0.46, 0.46, 0.5), v2840, v2841, nil)
	local v2842 = v2808.gear
	local v2843
	if v2842 == nil then
		v2843 = false
	else
		v2843 = table.find(v2842, "icecrescent") ~= nil
	end
	if not v2843 then
		v_u_124(p2807, v2839 + Vector3.new(0, 0.1, 0.1), v2839 + Vector3.new(0, 0.95, 0.75), v2839 + Vector3.new(0, 0.1, 1), 0.12, p2807.glow, v_u_12)
		v_u_124(p2807, v2839 + Vector3.new(0, -0.1, 0.1), v2839 + Vector3.new(0, -0.75, 0.7), v2839 + Vector3.new(0, -0.1, 0.9), 0.12, p2807.glow, v_u_12)
	end
	local v2844 = v2808.wings or { v2808.body }
	for v2845 = -1, 1, 2 do
		local v2846 = v_u_8(v2845 * 0.45 + 0.3, 2.6, 0.1)
		v_u_72(p2807, v2845 < 0 and "WingL" or "WingR", "Body", v2846, "wing", 0, v2845)
		local v2847 = v_u_9(v2846) * v_u_10(0, 0, v2845 * 0.55)
		for v2848 = 1, 3 do
			local v2849 = #v2844
			local v2850 = v2844[math.min(v2848, v2849)]
			local v2851
			if v2850 == v2808.glow then
				v2851 = v_u_12
			else
				v2851 = nil
			end
			local v2852 = Color3.fromHex(v2850)
			local v2853 = (1.5 - v2848 * 0.22) * 1.5
			local v2854 = 0.62 - v2848 * 0.08
			local v2855 = v2847 * v_u_10(0, -v2845 * (v2848 - 1) * 0.45, 0)
			local v2856 = v_u_8(v2853, 0.12, v2854)
			local v2857 = v2855 * v_u_9(v2845 * v2853 / 2, v2848 * -0.03, 0) * v_u_10(-0.8, 0, 0)
			v_u_80(p2807, Instance.new("Part"), v2856, v2857, v2852, v2851)
			local v2858 = v2855 * v_u_9(v2845 * v2853, v2848 * -0.03, 0) * v_u_10(-0.8, 0, 0)
			local v2859 = (v2858 * v_u_9(0, 0, -v2854 / 2)).Position
			local v2860 = v2858.XVector * v2845 * 0.55
			local v2861 = v2858.ZVector * v2854
			local v2862 = -v2860.Unit
			local v2863 = v2861.Unit
			local v2864 = CFrame.fromMatrix(v2859 + v2860 / 2 + v2861 / 2, v2863:Cross(v2862), v2863, v2862)
			local v2865 = v_u_8(0.12, v2861.Magnitude, v2860.Magnitude)
			v_u_80(p2807, Instance.new("WedgePart"), v2865, v2864, v2852, v2851)
		end
	end
	p2807.bodyC = (v_u_2658[1] + v_u_2658[2]) / 2
	p2807.bodyS = Vector3.new(1.3, 1.2, 1.3)
	p2807.tailAt = v2839
	p2807.headC = Vector3.new(0, 2.35, -1.05)
	p2807.headS = Vector3.new(1.95, 1.55, 1.6)
	p2807.face = p2807.headC.Z - p2807.headS.Z / 2
	p2807.eyeX = 0.48
	p2807.eyeY = 2.58
	p2807.mouthY = 1.98
	p2807.bandY = 2.85
	p2807.neck = Vector3.new(0, 1.5, -0.5)
	p2807.back = Vector3.new(0, 2.75, 0.2)
	v_u_72(p2807, "Head", "Body", v_u_2658[1], "head")
	local v2866 = p2807.headS
	local v2867 = v_u_9(p2807.headC)
	local v2868 = p2807.body
	v_u_80(p2807, Instance.new("Part"), v2866, v2867, v2868, nil)
	local v2869 = v_u_9(0, p2807.mouthY + 0.02, p2807.face - 0.32)
	local v2870 = p2807.body
	v_u_80(p2807, Instance.new("Part"), Vector3.new(1.25, 0.6, 0.75), v2869, v2870, nil)
	local v2871 = v_u_9(0, p2807.mouthY - 0.3, p2807.face - 0.3)
	local v2872 = p2807.belly
	v_u_80(p2807, Instance.new("Part"), Vector3.new(0.95, 0.14, 0.7), v2871, v2872, nil)
	local v2873 = v_u_9(0, p2807.eyeY + 0.36, p2807.face - 0.1)
	local v2874 = v_u_39
	v_u_80(p2807, Instance.new("Part"), Vector3.new(1.55, 0.2, 0.36), v2873, v2874, nil)
	v_u_162(p2807, 0.46, 0.5)
end
function v_u_925.firedragon(p2875) -- name: firedragon
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_290, (copy) v_u_72, (copy) v_u_10, (copy) v_u_2666, (copy) v_u_8, (copy) v_u_13, (copy) v_u_162
	p2875.cur = p2875.byName.Body or p2875.bones[1]
	local v2876 = p2875.look.wings or { p2875.look.glow or p2875.look.accent }
	p2875.bodyC = Vector3.new(0, 1.3, 0.35)
	p2875.bodyS = Vector3.new(1.9, 1.55, 1.9)
	local v2877 = p2875.bodyS
	local v2878 = v_u_9(p2875.bodyC)
	local v2879 = p2875.body
	v_u_80(p2875, Instance.new("Part"), v2877, v2878, v2879, nil)
	local v2880 = v_u_9(0, 1.2, -0.62)
	local v2881 = p2875.belly
	v_u_80(p2875, Instance.new("Part"), Vector3.new(1.4, 1.15, 0.1), v2880, v2881, nil)
	for v2882 = 0, 1 do
		local v2883 = v_u_9(0, v2882 * 0.36 + 1, -0.68)
		local v2884, v2885 = p2875.belly:Lerp(p2875.body, 0.45)
		v_u_80(p2875, Instance.new("Part"), Vector3.new(1.2, 0.06, 0.04), v2883, v2884, v2885)
	end
	v_u_290(p2875, 0.62, -0.3, 1, Vector3.new(0.5, 0.55, 0.5))
	p2875.tailAt = Vector3.new(0, 1, 1.3)
	v_u_72(p2875, "Tail1", "Body", p2875.tailAt, "tail", 0)
	local v2886 = v_u_9(0, 0.88, 1.75) * v_u_10(0.3, 0, 0)
	local v2887 = p2875.body
	v_u_80(p2875, Instance.new("Part"), Vector3.new(0.8, 0.72, 1.15), v2886, v2887, nil)
	v_u_72(p2875, "Tail2", "Tail1", Vector3.new(0, 0.68, 2.25), "tail", 0.9)
	local v2888 = v_u_9(0, 0.75, 2.62) * v_u_10(-0.45, 0, 0)
	local v2889 = p2875.body
	v_u_80(p2875, Instance.new("Part"), Vector3.new(0.55, 0.5, 0.95), v2888, v2889, nil)
	local v2890 = v2876[1]
	local v2891 = Color3.fromHex(v2890)
	local v2892 = #v2876
	local v2893 = v2876[math.min(2, v2892)]
	local v2894 = Color3.fromHex(v2893)
	local v2895 = v2876[#v2876]
	local v2896 = Color3.fromHex(v2895)
	v_u_2666(p2875, v_u_9(0, 0.92, 3.02) * v_u_10(-0.25, 0, 0), 0.7, 1.25, v2894, v2891)
	for v2897 = -1, 1, 2 do
		local v2898 = v_u_8(v2897 * 0.8, 2, 0.6)
		v_u_72(p2875, v2897 < 0 and "WingL" or "WingR", "Body", v2898, "wing", 0, v2897)
		for v2899, v2900 in {
			{
				["tilt"] = 68,
				["h"] = 1.9,
				["w"] = 0.9,
				["color"] = nil,
				["color"] = v2894
			},
			{
				["tilt"] = 40,
				["h"] = 2.25,
				["w"] = 1,
				["color"] = nil,
				["color"] = v2894
			},
			{
				["tilt"] = 12,
				["h"] = 1.7,
				["w"] = 0.85,
				["color"] = nil,
				["color"] = v2896
			}
		} do
			local v2901 = v_u_9(v2898)
			local v2902 = v_u_10
			local v2903 = -v2897
			local v2904 = v2900.tilt
			v_u_2666(p2875, v2901 * v2902(0, 0, v2903 * math.rad(v2904)) * v_u_9(0, 0.05, (v2899 - 2) * 0.06), v2900.w, v2900.h, v2900.color, v2891)
		end
	end
	p2875.headC = Vector3.new(0, 2.75, -0.45)
	p2875.headS = Vector3.new(2.05, 1.7, 1.75)
	p2875.face = p2875.headC.Z - p2875.headS.Z / 2
	p2875.eyeX = 0.5
	p2875.eyeY = 2.92
	p2875.mouthY = 2.25
	p2875.bandY = 3.25
	p2875.plateW = 0.9
	p2875.neck = Vector3.new(0, 1.75, -0.62)
	p2875.back = Vector3.new(0, 2.1, 0.65)
	v_u_72(p2875, "Head", "Body", Vector3.new(0, 2, -0.25), "head")
	local v2905 = p2875.headS
	local v2906 = v_u_9(p2875.headC)
	local v2907 = p2875.body
	v_u_80(p2875, Instance.new("Part"), v2905, v2906, v2907, nil)
	local v2908 = v_u_9(0, p2875.mouthY, p2875.face - 0.25)
	local v2909 = p2875.body
	v_u_80(p2875, Instance.new("Part"), Vector3.new(1.35, 0.72, 0.6), v2908, v2909, nil)
	local v2910 = v_u_9(-0.3, p2875.mouthY + 0.2, p2875.face - 0.56)
	local v2911 = v_u_13
	v_u_80(p2875, Instance.new("Part"), Vector3.new(0.15, 0.1, 0.05), v2910, v2911, nil)
	local v2912 = v_u_9(0.3, p2875.mouthY + 0.2, p2875.face - 0.56)
	local v2913 = v_u_13
	v_u_80(p2875, Instance.new("Part"), Vector3.new(0.15, 0.1, 0.05), v2912, v2913, nil)
	v_u_162(p2875, 0.44, 0.52)
end
local function v_u_2929(p2914, p2915, p2916, p2917) -- name: blossom
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (copy) v_u_80, (copy) v_u_2653, (copy) v_u_19, (copy) v_u_12
	for v2918 = 0, 4 do
		local v2919 = v2918 * 3.141592653589793 * 2 / 5
		local v2920 = v_u_8(p2916 * 0.3, p2916 * 0.4, 0.06)
		local v2921 = p2915 * v_u_10(0, 0, v2919) * v_u_9(0, p2916 * 0.22, 0)
		v_u_80(p2914, Instance.new("Part"), v2920, v2921, p2917, nil)
	end
	local v2922 = v_u_8(p2916 * 0.2, p2916 * 0.2, 0.08)
	local v2923 = p2915 * v_u_9(0, 0, -0.01) * v_u_10(0, 0, 0.7853981633974483)
	local v2924 = v_u_2653
	v_u_80(p2914, Instance.new("Part"), v2922, v2923, v2924, nil)
	local v2925 = v_u_8(p2916 * 0.1, p2916 * 0.1, 0.1)
	local v2926 = p2915 * v_u_9(0, 0, -0.03)
	local v2927 = v_u_19
	local v2928 = v_u_12
	v_u_80(p2914, Instance.new("Part"), v2925, v2926, v2927, v2928)
end
function v_u_926.sakura(p2930) -- name: sakura
	-- upvalues: (copy) v_u_2652, (copy) v_u_2929, (copy) v_u_9, (copy) v_u_10, (copy) v_u_2653, (copy) v_u_14
	p2930.cur = p2930.byName.Head or p2930.bones[1]
	local v2931 = p2930.headC.Y + p2930.headS.Y / 2
	local v2932 = -(p2930.headS.X / 2 - 0.38)
	local v2933 = p2930.face + 0.35
	local v2934 = p2930.body
	local v2935 = (v2934.R - v_u_2652.R) ^ 2 + (v2934.G - v_u_2652.G) ^ 2 + (v2934.B - v_u_2652.B) ^ 2 < 0.05
	local v2936 = v_u_2929
	local v2937 = v_u_9(v2932, v2931 + 0.16, v2933) * v_u_10(0.7, 0, 0.35)
	local v2938 = 1.35
	local v2939
	if v2935 then
		v2939 = v_u_2653
	else
		v2939 = v_u_2652
	end
	v2936(p2930, v2937, v2938, v2939)
	v_u_2929(p2930, v_u_9(v2932 + 0.62, v2931 + 0.1, v2933 + 0.22) * v_u_10(0.9, 0, -0.2), 0.75, v_u_14)
end
function v_u_926.cord(p2940) -- name: cord
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_10, (copy) v_u_18
	p2940.cur = p2940.byName.Body or p2940.bones[1]
	local v2941 = p2940.neck
	local v2942 = p2940.bodyS.X * 0.85
	local v2943 = v_u_8(math.max(v2942, 1.3), 0.16, 0.16)
	local v2944 = v_u_9(v2941)
	local v2945 = p2940.cloth
	v_u_80(p2940, Instance.new("Part"), v2943, v2944, v2945, nil)
	local v2946 = v2941 + Vector3.new(0.25, -0.02, -0.08)
	local v2947 = v_u_9(v2946)
	local v2948 = p2940.cloth
	v_u_80(p2940, Instance.new("Part"), Vector3.new(0.2, 0.2, 0.14), v2947, v2948, nil)
	for v2949 = -1, 1, 2 do
		local v2950 = v_u_9(v2946 + v_u_8(v2949 * 0.2, 0.06, 0)) * v_u_10(0, 0, v2949 * 0.45)
		local v2951 = p2940.cloth
		v_u_80(p2940, Instance.new("Part"), Vector3.new(0.3, 0.2, 0.1), v2950, v2951, nil)
		local v2952 = v2946 + v_u_8(v2949 * 0.1, -0.28, -0.02)
		local v2953 = v_u_9(v2952) * v_u_10(0, 0, v2949 * 0.15)
		local v2954 = p2940.cloth
		v_u_80(p2940, Instance.new("Part"), Vector3.new(0.06, 0.32, 0.06), v2953, v2954, nil)
		local v2955 = v_u_9(v2952 + v_u_8(v2949 * 0.02, -0.2, 0))
		local v2956 = v_u_18
		v_u_80(p2940, Instance.new("Part"), Vector3.new(0.14, 0.1, 0.14), v2955, v2956, nil)
		local v2957 = v_u_9(v2952 + v_u_8(v2949 * 0.03, -0.38, 0))
		local v2958 = p2940.cloth
		v_u_80(p2940, Instance.new("Part"), Vector3.new(0.16, 0.26, 0.16), v2957, v2958, nil)
	end
end
function v_u_926.shihakusho(p2959) -- name: shihakusho
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_14
	p2959.cur = p2959.byName.Body or p2959.bones[1]
	local v2960 = p2959.bodyC
	local v2961 = p2959.bodyS
	local v2962 = v2961 + Vector3.new(0.1, 0.06, 0.2)
	local v2963 = v_u_9(v2960 + Vector3.new(0, 0.03, 0))
	local v2964 = p2959.cloth
	v_u_80(p2959, Instance.new("Part"), v2962, v2963, v2964, nil)
	local v2965 = v2960.Z - v2961.Z / 2 - 0.17
	local v2966 = v2960.Y + v2961.Y / 2
	local v2967 = p2959.headC.Y - p2959.headS.Y / 2
	local v2968 = math.min(v2966, v2967) + 0.02
	local v2969 = v2960.Y - v2961.Y * 0.12
	local v2970 = v_u_8(-0.42, v2968, v2965)
	local v2971 = v_u_8(0.05, v2969, v2965)
	local v2972 = v_u_14
	local v2973 = (v2970 + v2971) / 2
	local v2974 = v_u_8(0.15, 0.15, (v2971 - v2970).Magnitude)
	local v2975 = CFrame.lookAt(v2973, v2971)
	v_u_80(p2959, Instance.new("Part"), v2974, v2975, v2972, nil)
	local v2976 = v_u_8(0.42, v2968, v2965)
	local v2977 = v_u_8(-0.05, v2969, v2965)
	local v2978 = v_u_14
	local v2979 = (v2976 + v2977) / 2
	local v2980 = v_u_8(0.15, 0.15, (v2977 - v2976).Magnitude)
	local v2981 = CFrame.lookAt(v2979, v2977)
	v_u_80(p2959, Instance.new("Part"), v2980, v2981, v2978, nil)
	for v2982 = 1, 4 do
		local v2983 = p2959.byName["Leg" .. v2982]
		if not v2983 then
			continue
		end
		local v2984 = v2983.name
		p2959.cur = p2959.byName[v2984] or p2959.bones[1]
		local v2985 = v_u_9(v2983.hinge - Vector3.new(0, 0.2, 0))
		local v2986 = p2959.cloth
		v_u_80(p2959, Instance.new("Part"), Vector3.new(0.64, 0.42, 0.64), v2985, v2986, nil)
	end
end
function v_u_926.zangetsu(p2987) -- name: zangetsu
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_2654, (copy) v_u_80, (copy) v_u_12, (copy) v_u_8, (copy) v_u_13, (copy) v_u_14, (copy) v_u_72
	p2987.cur = p2987.byName.Body or p2987.bones[1]
	local v2988 = v_u_9(p2987.back + Vector3.new(0, 0.7, 0.25)) * v_u_10(0, 0, 0.75)
	local v2989 = v2988 * v_u_9(0.65, 0, 0)
	local v2990 = v_u_2654
	v_u_80(p2987, Instance.new("Part"), Vector3.new(2.4, 0.62, 0.14), v2989, v2990, nil)
	local v2991 = v2988 * v_u_9(0.65, -0.3, 0)
	local v2992 = p2987.glow
	local v2993 = v_u_12
	v_u_80(p2987, Instance.new("Part"), Vector3.new(2.4, 0.12, 0.17), v2991, v2992, v2993)
	local v2994 = (v2988 * v_u_9(1.85, -0.31, 0)).Position
	local v2995 = v2988.XVector * 0.5
	local v2996 = v2988.YVector * 0.62
	local v2997 = v_u_2654
	local v2998 = -v2995.Unit
	local v2999 = v2996.Unit
	local v3000 = CFrame.fromMatrix(v2994 + v2995 / 2 + v2996 / 2, v2999:Cross(v2998), v2999, v2998)
	local v3001 = v_u_8(0.14, v2996.Magnitude, v2995.Magnitude)
	v_u_80(p2987, Instance.new("WedgePart"), v3001, v3000, v2997, nil)
	local v3002 = v2988 * v_u_9(-0.52, 0, 0)
	local v3003 = v_u_13
	v_u_80(p2987, Instance.new("Part"), Vector3.new(0.18, 0.66, 0.2), v3002, v3003, nil)
	local v3004 = v2988 * v_u_9(-1, 0, 0)
	local v3005 = v_u_14
	v_u_80(p2987, Instance.new("Part"), Vector3.new(0.8, 0.24, 0.24), v3004, v3005, nil)
	local v3006 = (v2988 * v_u_9(-1.4, 0, 0)).Position
	v_u_72(p2987, "Wrap", "Body", v3006, "flag", 0.6)
	local v3007 = v_u_9(v3006) * v_u_10(0.6, 0.35, 0) * v_u_9(0, 0, 0.48)
	local v3008 = v_u_14
	v_u_80(p2987, Instance.new("Part"), Vector3.new(0.2, 0.06, 1), v3007, v3008, nil)
end
function v_u_926.scowl(p3009) -- name: scowl
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_13, (copy) v_u_80
	p3009.cur = p3009.byName.Head or p3009.bones[1]
	for v3010 = -1, 1, 2 do
		local v3011 = v_u_9(v3010 * (p3009.eyeX + 0.02), p3009.eyeY + 0.43, p3009.face - 0.03) * v_u_10(0, 0, v3010 * 0.35)
		local v3012 = v_u_13
		v_u_80(p3009, Instance.new("Part"), Vector3.new(0.4, 0.1, 0.05), v3011, v3012, nil)
	end
end
function v_u_926.spikytuft(p3013) -- name: spikytuft
	-- upvalues: (copy) v_u_124, (copy) v_u_8
	p3013.cur = p3013.byName.Head or p3013.bones[1]
	local v3014 = p3013.headC.Y + p3013.headS.Y / 2 - 0.04
	local v3015 = p3013.headC.Z - p3013.headS.Z * 0.3
	for v3016 = -1, 1 do
		local v3017 = v3016 * 0.2
		local v3018 = v3016 == 0 and 0.62 or 0.45
		v_u_124(p3013, v_u_8(v3017 - 0.19, v3014, v3015), v_u_8(v3017 + 0.19, v3014, v3015), v_u_8(v3017 * 2.1, v3014 + v3018, v3015 - 0.1), 0.26, p3013.body)
	end
end
function v_u_926.kazahana(p3019) -- name: kazahana
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_10, (copy) v_u_72
	p3019.cur = p3019.byName.Body or p3019.bones[1]
	local v3020 = p3019.neck
	local v3021 = v_u_8(p3019.bodyS.X + 0.2, 0.36, p3019.bodyS.Z + 0.1)
	local v3022 = v_u_9(0, v3020.Y - 0.02, p3019.bodyC.Z)
	local v3023 = p3019.cloth
	v_u_80(p3019, Instance.new("Part"), v3021, v3022, v3023, nil)
	local v3024 = v_u_9(-0.42, v3020.Y - 0.45, v3020.Z - 0.04) * v_u_10(0, 0, -0.08)
	local v3025 = p3019.cloth
	v_u_80(p3019, Instance.new("Part"), Vector3.new(0.4, 0.8, 0.1), v3024, v3025, nil)
	local v3026 = v_u_8(0.45, v3020.Y, p3019.bodyC.Z + p3019.bodyS.Z / 2)
	v_u_72(p3019, "Scarf", "Body", v3026, "flag", 1.2)
	local v3027 = v_u_9(v3026) * v_u_10(0.35, 0.4, 0)
	local v3028 = v3027 * v_u_9(0, 0, 0.6)
	local v3029 = p3019.cloth
	v_u_80(p3019, Instance.new("Part"), Vector3.new(0.42, 0.08, 1.3), v3028, v3029, nil)
	local v3030 = v3027 * v_u_9(0, 0, 1.2) * v_u_10(-0.25, 0.2, 0) * v_u_9(0, 0, 0.5)
	local v3031 = p3019.cloth
	v_u_80(p3019, Instance.new("Part"), Vector3.new(0.36, 0.08, 0.95), v3030, v3031, nil)
end
function v_u_926.petalring(p3032) -- name: petalring
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_9, (copy) v_u_10, (copy) v_u_2652, (copy) v_u_12, (copy) v_u_80
	local v3033 = v_u_8(0, p3032.bodyC.Y + 0.25, p3032.bodyC.Z)
	v_u_72(p3032, "Petals", "Body", v3033, "spin")
	for v3034 = 0, 5 do
		local v3035 = v3034 * 3.141592653589793 / 3 + 0.3
		local v3036 = math.cos(v3035) * 1.75
		local v3037 = v3034 * 2.1
		local v3038 = v3033 + v_u_8(v3036, math.sin(v3037) * 0.35, math.sin(v3035) * 1.75)
		local v3039 = v3034 % 2 == 0
		local v3040 = v_u_9(v3038) * v_u_10(0, -v3035, 0)
		local v3041 = v_u_10
		local v3042 = v3034 * 1.3
		local v3043 = v3040 * v3041(0.5, 0, math.cos(v3042) * 0.4)
		local v3044
		if v3039 then
			v3044 = p3032.glow
		else
			v3044 = v_u_2652
		end
		local v3045
		if v3039 then
			v3045 = v_u_12
		else
			v3045 = nil
		end
		v_u_80(p3032, Instance.new("Part"), Vector3.new(0.34, 0.07, 0.48), v3043, v3044, v3045)
	end
end
function v_u_926.ofuda(p3046) -- name: ofuda
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_31, (copy) v_u_80, (copy) v_u_2656
	p3046.cur = p3046.byName.Head or p3046.bones[1]
	local v3047 = p3046.headC.Y + p3046.headS.Y / 2
	local v3048 = v3047 - p3046.eyeY + 0.1
	local v3049 = math.min(0.85, v3048)
	local v3050 = v_u_9(0.04, v3047 - v3049 / 2 + 0.06, p3046.face - 0.035) * v_u_10(0, 0, -0.1)
	local v3051 = v_u_8(0.36, v3049, 0.04)
	local v3052 = v_u_31
	v_u_80(p3046, Instance.new("Part"), v3051, v3050, v3052, nil)
	local v3053 = v_u_8(0.06, v3049 * 0.7, 0.03)
	local v3054 = v3050 * v_u_9(0, -0.02, -0.03)
	local v3055 = v_u_2656
	v_u_80(p3046, Instance.new("Part"), v3053, v3054, v3055, nil)
	for v3056 = -1, 1 do
		local v3057 = v_u_8(0.22 - math.abs(v3056) * 0.04, 0.05, 0.03)
		local v3058 = v3050 * v_u_9(0, v3056 * v3049 * 0.22, -0.03)
		local v3059 = v_u_2656
		v_u_80(p3046, Instance.new("Part"), v3057, v3058, v3059, nil)
	end
end
function v_u_926.kidoseal(p3060) -- name: kidoseal
	-- upvalues: (copy) v_u_8, (copy) v_u_72, (copy) v_u_19, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80
	local v3061 = v_u_8(0, 0.25, p3060.bodyC.Z)
	v_u_72(p3060, "Seal", "Body", v3061, "spin")
	local v3062
	if p3060.look.glow then
		v3062 = p3060.glow
	else
		v3062 = v_u_19
	end
	for v3063 = 0, 11 do
		local v3064 = v3063 * 3.141592653589793 / 6
		local v3065 = v_u_9(v3061 + v_u_8(math.cos(v3064) * 1.35, 0, math.sin(v3064) * 1.35)) * v_u_10(0, -v3064, 0)
		local v3066 = v_u_12
		v_u_80(p3060, Instance.new("Part"), Vector3.new(0.12, 0.06, 0.7425), v3065, v3062, v3066)
	end
	for v3067 = 0, 3 do
		local v3068 = v3067 * 3.141592653589793 / 2
		local v3069 = v_u_9(v3061 + v_u_8(math.cos(v3068) * 0.81, 0, math.sin(v3068) * 0.81)) * v_u_10(0, -v3068, 0)
		local v3070 = v_u_12
		v_u_80(p3060, Instance.new("Part"), Vector3.new(0.08, 0.06, 1.62), v3069, v3062, v3070)
		local v3071 = v3068 + 0.7853981633974483
		local v3072 = v_u_9(v3061 + v_u_8(math.cos(v3071), 0, (math.sin(v3071))) * 0.81 * 1.4142135623730951) * v_u_10(0, 0.7853981633974483 - v3068, 0)
		local v3073 = v_u_12
		v_u_80(p3060, Instance.new("Part"), Vector3.new(0.22, 0.07, 0.22), v3072, v3062, v3073)
	end
end
local function v_u_3079() -- name: coilPoints
	-- upvalues: (copy) v_u_8
	local v3074 = {}
	for v3075 = 0, 9 do
		local v3076 = 1.5707963267948966 + v3075 * 0.78
		local v3077 = 1.05 - v3075 * 0.06
		local v3078 = v_u_8(math.cos(v3076) * v3077, v3075 * 0.1 + 0.32, math.sin(v3076) * v3077 + 0.35)
		table.insert(v3074, v3078)
	end
	return v3074
end
function v_u_926.boneplates(p3080) -- name: boneplates
	-- upvalues: (copy) v_u_3079, (copy) v_u_8, (copy) v_u_2655, (copy) v_u_80
	p3080.cur = p3080.byName.Body or p3080.bones[1]
	local v3081 = v_u_3079()
	for v3082 = 3, 9 do
		local v3083 = v3081[v3082 - 1]
		local v3084 = v3081[v3082]
		local v3085 = (v3083 + v3084) / 2
		local v3086 = v3084 - v3083
		local v3087 = v_u_8(v3086.X, 0, v3086.Z).Unit
		local v3088 = v3085 + Vector3.new(0, 0.28, 0) + v3087 * 0.2
		local v3089 = -v3087 * 0.45
		local v3090 = v_u_2655
		local v3091 = -v3089.Unit
		local v3092 = (Vector3.new(0, 0.42, 0)).Unit
		local v3093 = CFrame.fromMatrix(v3088 + v3089 / 2 + Vector3.new(0, 0.21, 0), v3092:Cross(v3091), v3092, v3091)
		local v3094 = v_u_8(0.16, (Vector3.new(0, 0.42, 0)).Magnitude, v3089.Magnitude)
		v_u_80(p3080, Instance.new("WedgePart"), v3094, v3093, v3090, nil)
	end
end
function v_u_926.baboonskull(p3095) -- name: baboonskull
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2655, (copy) v_u_80, (copy) v_u_13
	p3095.cur = p3095.byName.Head or p3095.bones[1]
	local v3096 = p3095.face
	local v3097 = v_u_8(p3095.headS.X + 0.12, 0.3, 0.42)
	local v3098 = v_u_9(0, p3095.eyeY + 0.42, v3096 - 0.08)
	local v3099 = v_u_2655
	v_u_80(p3095, Instance.new("Part"), v3097, v3098, v3099, nil)
	for v3100 = -1, 1, 2 do
		local v3101 = v_u_9(v3100 * p3095.eyeX, p3095.eyeY, v3096 - 0.025)
		local v3102 = v_u_13
		v_u_80(p3095, Instance.new("Part"), Vector3.new(0.62, 0.7, 0.04), v3101, v3102, nil)
		local v3103 = v_u_9(v3100 * (p3095.eyeX + 0.42), p3095.eyeY - 0.42, v3096 - 0.05)
		local v3104 = v_u_2655
		v_u_80(p3095, Instance.new("Part"), Vector3.new(0.4, 0.3, 0.3), v3103, v3104, nil)
		local v3105 = v_u_9(v3100 * 0.28, p3095.mouthY + 0.27, v3096 - 0.25)
		local v3106 = p3095.accent
		v_u_80(p3095, Instance.new("Part"), Vector3.new(0.1, 0.08, 0.48), v3105, v3106, nil)
	end
end
function v_u_926.redmane(p3107) -- name: redmane
	-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_80, (copy) v_u_124
	p3107.cur = p3107.byName.Head or p3107.bones[1]
	local v3108 = v_u_8(0, p3107.headC.Y - 0.05, p3107.headC.Z + p3107.headS.Z / 2 + 0.2)
	local v3109 = p3107.headS.X + 0.5
	local v3110 = p3107.headS.Y + 0.45
	local v3111 = p3107.accent:Lerp(v_u_13, 0.35)
	local v3112 = v_u_8(v3109, v3110, 0.6)
	local v3113 = v_u_9(v3108)
	local v3114 = p3107.accent
	v_u_80(p3107, Instance.new("Part"), v3112, v3113, v3114, nil)
	for v3115 = 0, 6 do
		local v3116 = v3115 * 36.6 + -20
		local v3117 = math.rad(v3116)
		local v3118 = v_u_8(math.cos(v3117), math.sin(v3117), 0)
		local v3119 = v_u_8(v3118.X * v3109 * 0.45, v3108.Y + v3118.Y * v3110 * 0.45, v3108.Z + 0.1)
		local v3120 = v_u_8(-v3118.Y, v3118.X, 0) * 0.28
		local v3121 = v_u_124
		local v3122 = v3119 - v3120
		local v3123 = v3119 + v3120
		local v3124 = v3119 + v3118 * 0.62 + Vector3.new(0, 0, 0.25)
		local v3125 = 0.26
		local v3126
		if v3115 % 2 == 0 then
			v3126 = p3107.accent
		else
			v3126 = v3111
		end
		v3121(p3107, v3122, v3123, v3124, v3125, v3126)
	end
end
function v_u_926.icehorns(p3127) -- name: icehorns
	-- upvalues: (copy) v_u_8, (copy) v_u_39, (copy) v_u_80, (copy) v_u_12
	p3127.cur = p3127.byName.Head or p3127.bones[1]
	local v3128 = p3127.headC.Y + p3127.headS.Y / 2
	for v3129 = -1, 1, 2 do
		local v3130 = v_u_8(v3129 * 0.55, v3128 - 0.12, p3127.headC.Z + 0.1)
		local v3131 = v3130 + v_u_8(v3129 * 0.3, 0.45, 0.4)
		local v3132 = v3131 + v_u_8(v3129 * 0.12, 0.25, 0.55)
		local v3133 = v3132 + Vector3.new(0, 0.05, 0.45)
		local v3134 = v_u_39
		local v3135 = (v3131 - v3130).Unit * 0.28 * 0.4
		local v3136 = v3130 - v3135
		local v3137 = v3131 + v3135
		local v3138 = (v3136 + v3137) / 2
		local v3139 = v_u_8(0.28, 0.28, (v3137 - v3136).Magnitude)
		local v3140 = CFrame.lookAt(v3138, v3137)
		v_u_80(p3127, Instance.new("Part"), v3139, v3140, v3134, nil)
		local v3141 = v_u_39
		local v3142 = (v3132 - v3131).Unit * 0.22 * 0.4
		local v3143 = v3131 - v3142
		local v3144 = v3132 + v3142
		local v3145 = (v3143 + v3144) / 2
		local v3146 = v_u_8(0.22, 0.22, (v3144 - v3143).Magnitude)
		local v3147 = CFrame.lookAt(v3145, v3144)
		v_u_80(p3127, Instance.new("Part"), v3146, v3147, v3141, nil)
		local v3148 = p3127.glow
		local v3149 = v_u_12
		local v3150 = (v3133 - v3132).Unit * 0.16 * 0.4
		local v3151 = v3132 - v3150
		local v3152 = v3133 + v3150
		local v3153 = (v3151 + v3152) / 2
		local v3154 = v_u_8(0.16, 0.16, (v3152 - v3151).Magnitude)
		local v3155 = CFrame.lookAt(v3153, v3152)
		v_u_80(p3127, Instance.new("Part"), v3154, v3155, v3148, v3149)
	end
end
function v_u_926.frostmane(p3156) -- name: frostmane
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_39, (copy) v_u_12, (copy) v_u_80
	p3156.cur = p3156.byName.Head or p3156.bones[1]
	local v3157 = p3156.headC.Y + p3156.headS.Y / 2
	local v3158 = p3156.headC.Z + p3156.headS.Z / 2
	for v3159 = 0, 2 do
		local v3160 = 0.75 - v3159 * 0.15
		local v3161 = v_u_8(0, v3157 - 0.1 - v3159 * 0.3, v3158 - 0.25 + v3159 * 0.2)
		local v3162 = v3159 % 2 == 0
		local v3163 = v_u_8(0.22, v3160, 0.22)
		local v3164 = v_u_9(v3161) * v_u_10(-0.9, 0, 0) * v_u_9(0, v3160 / 2, 0) * v_u_10(0, 0.7853981633974483, 0)
		local v3165
		if v3162 then
			v3165 = p3156.glow
		else
			v3165 = v_u_39
		end
		local v3166
		if v3162 then
			v3166 = v_u_12
		else
			v3166 = nil
		end
		v_u_80(p3156, Instance.new("Part"), v3163, v3164, v3165, v3166)
	end
end
function v_u_926.icecrescent(p3167) -- name: icecrescent
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_80, (copy) v_u_20
	p3167.cur = p3167.byName.Fin or p3167.bones[1]
	local v3168 = p3167.tailAt
	local v3169 = v3168 + Vector3.new(0, 0.8, 0.75)
	for v3170 = 0, 3 do
		local v3171 = v3170 * 50 + 195
		local v3172 = math.rad(v3171)
		local v3173 = 3.141592653589793 * v3170 / 3
		local v3174 = v_u_8(0.6624, math.sin(v3173) * 0.12 + 0.1, 0.12)
		local v3175 = v_u_9(v3169 + v_u_8(math.cos(v3172) * 0.72, math.sin(v3172) * 0.72, 0)) * v_u_10(0, 0, v3172 + 1.5707963267948966)
		local v3176 = p3167.glow
		local v3177 = v_u_12
		v_u_80(p3167, Instance.new("Part"), v3174, v3175, v3176, v3177)
	end
	local v3178 = v3169 - Vector3.new(0, 0.72, 0)
	local v3179 = v3168 + Vector3.new(0, 0, 0.2)
	local v3180 = v_u_20
	local v3181 = (v3178 - v3179).Unit * 0.1 * 0.4
	local v3182 = v3179 - v3181
	local v3183 = v3178 + v3181
	local v3184 = (v3182 + v3183) / 2
	local v3185 = v_u_8(0.1, 0.1, (v3183 - v3182).Magnitude)
	local v3186 = CFrame.lookAt(v3184, v3183)
	v_u_80(p3167, Instance.new("Part"), v3185, v3186, v3180, nil)
end
function v_u_926.beard(p3187) -- name: beard
	-- upvalues: (copy) v_u_9, (copy) v_u_2657, (copy) v_u_80, (copy) v_u_10
	p3187.cur = p3187.byName.Head or p3187.bones[1]
	local v3188 = p3187.face - 0.15
	local v3189 = p3187.mouthY - 0.35
	local v3190 = v_u_9(0, v3189 - 0.2, v3188)
	local v3191 = v_u_2657
	v_u_80(p3187, Instance.new("Part"), Vector3.new(1.25, 0.7, 0.55), v3190, v3191, nil)
	local v3192 = v_u_9(0, v3189 - 0.72, v3188 + 0.05)
	local v3193 = v_u_2657
	v_u_80(p3187, Instance.new("Part"), Vector3.new(0.85, 0.55, 0.45), v3192, v3193, nil)
	local v3194 = v_u_9(0, v3189 - 0.62, v3188 + 0.05)
	local v3195 = p3187.cloth
	v_u_80(p3187, Instance.new("Part"), Vector3.new(0.9, 0.14, 0.49), v3194, v3195, nil)
	local v3196 = v_u_9(0, v3189 - 1.05, v3188 + 0.08) * v_u_10(0, 0, 0.7853981633974483)
	local v3197 = v_u_2657
	v_u_80(p3187, Instance.new("Part"), Vector3.new(0.4, 0.4, 0.34), v3196, v3197, nil)
	for v3198 = -1, 1, 2 do
		local v3199 = v_u_9(v3198 * 0.5, p3187.mouthY - 0.15, p3187.face - 0.52) * v_u_10(0, 0, -v3198 * 0.5)
		local v3200 = v_u_2657
		v_u_80(p3187, Instance.new("Part"), Vector3.new(0.55, 0.18, 0.22), v3199, v3200, nil)
		local v3201 = v_u_9(v3198 * (p3187.eyeX + 0.05), p3187.eyeY + 0.42, p3187.face - 0.06) * v_u_10(0, 0, -v3198 * 0.3)
		local v3202 = v_u_2657
		v_u_80(p3187, Instance.new("Part"), Vector3.new(0.6, 0.2, 0.2), v3201, v3202, nil)
	end
end
function v_u_926.elderhorns(p3203) -- name: elderhorns
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	p3203.cur = p3203.byName.Head or p3203.bones[1]
	local v3204 = p3203.headC.Y + p3203.headS.Y / 2
	for v3205 = -1, 1, 2 do
		local v3206 = v_u_8(v3205 * 0.6, v3204 - 0.1, p3203.headC.Z + 0.2)
		local v3207 = v3206 + v_u_8(v3205 * 0.2, 0.42, 0.18)
		local v3208 = v3207 + v_u_8(v3205 * 0.02, 0.16, 0.4)
		local v3209 = p3203.accent
		local v3210 = (v3207 - v3206).Unit * 0.3 * 0.4
		local v3211 = v3206 - v3210
		local v3212 = v3207 + v3210
		local v3213 = (v3211 + v3212) / 2
		local v3214 = v_u_8(0.3, 0.3, (v3212 - v3211).Magnitude)
		local v3215 = CFrame.lookAt(v3213, v3212)
		v_u_80(p3203, Instance.new("Part"), v3214, v3215, v3209, nil)
		local v3216 = p3203.accent
		local v3217 = (v3208 - v3207).Unit * 0.2 * 0.4
		local v3218 = v3207 - v3217
		local v3219 = v3208 + v3217
		local v3220 = (v3218 + v3219) / 2
		local v3221 = v_u_8(0.2, 0.2, (v3219 - v3218).Magnitude)
		local v3222 = CFrame.lookAt(v3220, v3219)
		v_u_80(p3203, Instance.new("Part"), v3221, v3222, v3216, nil)
	end
end
function v_u_926.flamecrest(p3223) -- name: flamecrest
	-- upvalues: (copy) v_u_124, (copy) v_u_8, (copy) v_u_12
	p3223.cur = p3223.byName.Head or p3223.bones[1]
	local v3224 = p3223.look.wings or { p3223.look.glow or p3223.look.accent }
	local v3225 = v3224[1]
	local v3226 = Color3.fromHex(v3225)
	local v3227 = #v3224
	local v3228 = v3224[math.min(2, v3227)]
	local v3229 = Color3.fromHex(v3228)
	local v3230 = v3224[#v3224]
	local v3231 = Color3.fromHex(v3230)
	local v3232 = p3223.headC.Y + p3223.headS.Y / 2 - 0.04
	local v3233 = p3223.headC.Z
	v_u_124(p3223, v_u_8(-0.3, v3232, v3233), v_u_8(0.3, v3232, v3233), v_u_8(0, v3232 + 1.05, v3233 + 0.25), 0.22, v3231, v_u_12)
	for v3234 = -1, 1, 2 do
		v_u_124(p3223, v_u_8(v3234 * 0.2, v3232, v3233 + 0.05), v_u_8(v3234 * 0.68, v3232 - 0.05, v3233 + 0.05), v_u_8(v3234 * 0.82, v3232 + 0.72, v3233 + 0.25), 0.2, v3229, v_u_12)
	end
	v_u_124(p3223, v_u_8(-0.16, v3232, v3233 - 0.15), v_u_8(0.16, v3232, v3233 - 0.15), v_u_8(0, v3232 + 0.6, v3233 - 0.05), 0.1, v3226, v_u_12)
end
function v_u_926.kikoumask(p3235) -- name: kikoumask
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_18, (copy) v_u_80, (copy) v_u_12
	p3235.cur = p3235.byName.Head or p3235.bones[1]
	local v3236 = p3235.eyeY + 0.55
	local v3237 = p3235.headC.Y + p3235.headS.Y / 2 - 0.3
	local v3238 = v_u_8(0, math.min(v3236, v3237), p3235.face - 0.04)
	local v3239 = v_u_9(v3238) * v_u_10(0, 0, 0.7853981633974483)
	local v3240 = v_u_18
	v_u_80(p3235, Instance.new("Part"), Vector3.new(0.36, 0.36, 0.06), v3239, v3240, nil)
	local v3241 = v_u_9(v3238 + Vector3.new(0, 0, -0.02)) * v_u_10(0, 0, 0.7853981633974483)
	local v3242 = p3235.glow
	local v3243 = v_u_12
	v_u_80(p3235, Instance.new("Part"), Vector3.new(0.2, 0.2, 0.08), v3241, v3242, v3243)
	for v3244 = -1, 1, 2 do
		local v3245 = v_u_8(v3244 * (p3235.eyeX + 0.2), p3235.eyeY + 0.08, p3235.face - 0.03)
		local v3246 = v_u_8(v3244 * (p3235.headS.X / 2 + 0.03), p3235.eyeY + 0.32, p3235.face + 0.3)
		local v3247 = v_u_18
		local v3248 = (v3245 + v3246) / 2
		local v3249 = v_u_8(0.09, 0.09, (v3246 - v3245).Magnitude)
		local v3250 = CFrame.lookAt(v3248, v3246)
		v_u_80(p3235, Instance.new("Part"), v3249, v3250, v3247, nil)
	end
end
local v_u_3251 = Color3.fromRGB(16, 13, 20)
local v_u_3252 = Color3.fromRGB(226, 246, 255)
v_u_47.hound = { 0.45, 10 }
v_u_47.panther = { 0.4, 9 }
v_u_47.scorpion = { 0.12, 16 }
v_u_47.lizard = { 0.14, 15 }
v_u_47.menos = { 0.22, 6 }
local function v_u_3296(p3253, p3254, p3255, p3256, p3257, p3258, p3259) -- name: holedBox
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8
	local v3260 = p3254 - p3255 / 2
	local v3261 = p3254 + p3255 / 2
	local v3262 = p3256 - Vector3.new(1, 1, 1) * p3257 / 2
	local v3263 = p3256 + Vector3.new(1, 1, 1) * p3257 / 2
	if p3258 == "X" then
		local v3264 = v_u_8(v3260.X, v3260.Y, v3260.Z)
		local v3265 = v_u_8(v3261.X, v3261.Y, v3262.Z)
		local v3266 = v3265 - v3264
		local v3267 = v_u_9((v3264 + v3265) / 2)
		v_u_80(p3253, Instance.new("Part"), v3266, v3267, p3259, nil)
		local v3268 = v_u_8(v3260.X, v3260.Y, v3263.Z)
		local v3269 = v_u_8(v3261.X, v3261.Y, v3261.Z)
		local v3270 = v3269 - v3268
		local v3271 = v_u_9((v3268 + v3269) / 2)
		v_u_80(p3253, Instance.new("Part"), v3270, v3271, p3259, nil)
		local v3272 = v_u_8(v3260.X, v3263.Y, v3262.Z - 0.25)
		local v3273 = v_u_8(v3261.X, v3261.Y, v3263.Z + 0.25)
		local v3274 = v3273 - v3272
		local v3275 = v_u_9((v3272 + v3273) / 2)
		v_u_80(p3253, Instance.new("Part"), v3274, v3275, p3259, nil)
		local v3276 = v_u_8(v3260.X, v3260.Y, v3262.Z - 0.25)
		local v3277 = v_u_8(v3261.X, v3262.Y, v3263.Z + 0.25)
		local v3278 = v3277 - v3276
		local v3279 = v_u_9((v3276 + v3277) / 2)
		v_u_80(p3253, Instance.new("Part"), v3278, v3279, p3259, nil)
	else
		local v3280 = v_u_8(v3260.X, v3260.Y, v3260.Z)
		local v3281 = v_u_8(v3262.X, v3261.Y, v3261.Z)
		local v3282 = v3281 - v3280
		local v3283 = v_u_9((v3280 + v3281) / 2)
		v_u_80(p3253, Instance.new("Part"), v3282, v3283, p3259, nil)
		local v3284 = v_u_8(v3263.X, v3260.Y, v3260.Z)
		local v3285 = v_u_8(v3261.X, v3261.Y, v3261.Z)
		local v3286 = v3285 - v3284
		local v3287 = v_u_9((v3284 + v3285) / 2)
		v_u_80(p3253, Instance.new("Part"), v3286, v3287, p3259, nil)
		local v3288 = v_u_8(v3262.X - 0.25, v3263.Y, v3260.Z)
		local v3289 = v_u_8(v3263.X + 0.25, v3261.Y, v3261.Z)
		local v3290 = v3289 - v3288
		local v3291 = v_u_9((v3288 + v3289) / 2)
		v_u_80(p3253, Instance.new("Part"), v3290, v3291, p3259, nil)
		local v3292 = v_u_8(v3262.X - 0.25, v3260.Y, v3260.Z)
		local v3293 = v_u_8(v3263.X + 0.25, v3262.Y, v3261.Z)
		local v3294 = v3293 - v3292
		local v3295 = v_u_9((v3292 + v3293) / 2)
		v_u_80(p3253, Instance.new("Part"), v3294, v3295, p3259, nil)
	end
end
local function v_u_3310(p3297, p3298, p3299) -- name: maskFace
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_2655
	local v3300 = p3297.headC
	local v3301 = p3297.headS
	local v3302 = v_u_9(v3300)
	local v3303 = p3297.body
	v_u_80(p3297, Instance.new("Part"), v3301, v3302, v3303, nil)
	local v3304 = v3300.Z - v3301.Z / 2 - 0.06
	local v3305 = v3300.Y + v3301.Y / 2 + 0.03
	local v3306 = p3299 or v3300.Y - v3301.Y / 2 - 0.03
	local v3307 = v_u_8(v3301.X + 0.08, v3305 - v3306, p3298)
	local v3308 = v_u_9(v3300.X, (v3305 + v3306) / 2, v3304 + p3298 / 2)
	local v3309 = v_u_2655
	v_u_80(p3297, Instance.new("Part"), v3307, v3308, v3309, nil)
	p3297.face = v3304
end
local function v_u_3319(p3311, p3312, p3313, p3314) -- name: sockets
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_3251, (copy) v_u_80
	for v3315 = -1, 1, 2 do
		local v3316 = v_u_8(p3312 + 0.18, p3313 + 0.16, 0.06)
		local v3317 = v_u_9(v3315 * p3311.eyeX, p3311.eyeY, p3311.face - 0.015) * v_u_10(0, 0, v3315 * p3314)
		local v3318 = v_u_3251
		v_u_80(p3311, Instance.new("Part"), v3316, v3317, v3318, nil)
	end
end
local function v_u_3332(p3320, p3321, p3322, p3323) -- name: grin
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_3251, (copy) v_u_80, (copy) v_u_2655
	local v3324 = v_u_8(p3321, 0.18, 0.05)
	local v3325 = v_u_9(0, p3323, p3320.face - 0.02)
	local v3326 = v_u_3251
	v_u_80(p3320, Instance.new("Part"), v3324, v3325, v3326, nil)
	for v3327 = 1, p3322 do
		local v3328 = -p3321 / 2 + p3321 * (v3327 - 0.5) / p3322
		local v3329 = v_u_8(p3321 / p3322 * 0.5, 0.26, 0.07)
		local v3330 = v_u_9(v3328, p3323, p3320.face - 0.03)
		local v3331 = v_u_2655
		v_u_80(p3320, Instance.new("Part"), v3329, v3330, v3331, nil)
	end
end
local v_u_3333 = {
	Vector3.new(-0.25, 2.15, -0.25),
	Vector3.new(0.3, 2, 0.5),
	Vector3.new(0.45, 1.7, 1.3),
	Vector3.new(-0.3, 1.55, 1.85),
	Vector3.new(-1, 1.75, 2.4),
	Vector3.new(-1.25, 2.3, 2.95)
}
local v_u_3334 = {
	1.2,
	1.05,
	0.88,
	0.7,
	0.54
}
function v_u_925.hound(p3335) -- name: hound
	-- upvalues: (copy) v_u_3296, (copy) v_u_9, (copy) v_u_80, (copy) v_u_290, (copy) v_u_72, (copy) v_u_3310, (copy) v_u_3319, (copy) v_u_162, (copy) v_u_13, (copy) v_u_8, (copy) v_u_14, (copy) v_u_167, (copy) v_u_216, (copy) v_u_273
	p3335.cur = p3335.byName.Body or p3335.bones[1]
	p3335.bodyC = Vector3.new(0, 1.1, 0.4)
	p3335.bodyS = Vector3.new(1.8, 1.35, 2.1)
	v_u_3296(p3335, p3335.bodyC, p3335.bodyS, Vector3.new(0, 1.08, 0.78), 0.7, "X", p3335.body)
	local v3336 = v_u_9(0, 1, -0.68)
	local v3337 = p3335.belly
	v_u_80(p3335, Instance.new("Part"), Vector3.new(1.25, 0.85, 0.1), v3336, v3337, nil)
	v_u_290(p3335, 0.55, -0.25, 1.1, Vector3.new(0.55, 0.7, 0.55))
	p3335.headC = Vector3.new(0, 2.35, -0.55)
	p3335.headS = Vector3.new(2.2, 1.85, 1.8)
	p3335.eyeX = 0.5
	p3335.eyeY = 2.45
	p3335.mouthY = 1.88
	p3335.bandY = 2.98
	p3335.neck = Vector3.new(0, 1.27, -0.71)
	p3335.back = Vector3.new(0, 1.78, 0.8)
	p3335.tailAt = Vector3.new(0, 1.55, 1.42)
	v_u_72(p3335, "Head", "Body", Vector3.new(0, 1.6, -0.35), "head")
	v_u_3310(p3335, 0.5)
	v_u_3319(p3335, 0.4, 0.56, 0)
	v_u_162(p3335, 0.4, 0.56)
	local v3338 = v_u_9(0, p3335.mouthY - 0.02, p3335.face - 0.2)
	local v3339 = p3335.belly
	v_u_80(p3335, Instance.new("Part"), Vector3.new(1.05, 0.62, 0.46), v3338, v3339, nil)
	local v3340 = v_u_9(0, p3335.mouthY + 0.16, p3335.face - 0.45)
	local v3341 = v_u_13
	v_u_80(p3335, Instance.new("Part"), Vector3.new(0.42, 0.24, 0.14), v3340, v3341, nil)
	local v3342 = v_u_9(0, p3335.mouthY - 0.14, p3335.face - 0.44)
	local v3343 = v_u_13
	v_u_80(p3335, Instance.new("Part"), Vector3.new(0.5, 0.07, 0.05), v3342, v3343, nil)
	local v3344 = v_u_8(-0.24, p3335.mouthY - 0.33, p3335.face - 0.38)
	local v3345 = v_u_14
	local v3346 = -(Vector3.new(0.13, 0, 0)).Unit
	local v3347 = (Vector3.new(0, -0.22, 0)).Unit
	local v3348 = CFrame.fromMatrix(v3344 + Vector3.new(0.065, 0, 0) + Vector3.new(0, -0.11, 0), v3347:Cross(v3346), v3347, v3346)
	local v3349 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(0.13, 0, 0)).Magnitude)
	v_u_80(p3335, Instance.new("WedgePart"), v3349, v3348, v3345, nil)
	local v3350 = v_u_8(0.24, p3335.mouthY - 0.33, p3335.face - 0.38)
	local v3351 = v_u_14
	local v3352 = -(Vector3.new(-0.13, 0, 0)).Unit
	local v3353 = (Vector3.new(0, -0.22, 0)).Unit
	local v3354 = CFrame.fromMatrix(v3350 + Vector3.new(-0.065, 0, 0) + Vector3.new(0, -0.11, 0), v3353:Cross(v3352), v3353, v3352)
	local v3355 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(-0.13, 0, 0)).Magnitude)
	v_u_80(p3335, Instance.new("WedgePart"), v3355, v3354, v3351, nil)
	v_u_167(p3335)
	v_u_216(p3335)
	v_u_273(p3335)
end
function v_u_925.bonebat(p3356) -- name: bonebat
	-- upvalues: (copy) v_u_3296, (copy) v_u_72, (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_331, (copy) v_u_3310, (copy) v_u_3319, (copy) v_u_162, (copy) v_u_16, (copy) v_u_13, (copy) v_u_14
	p3356.cur = p3356.byName.Body or p3356.bones[1]
	p3356.bodyC = Vector3.new(0, 1.2, 0.25)
	p3356.bodyS = Vector3.new(1.5, 1.25, 1.3)
	v_u_3296(p3356, p3356.bodyC, p3356.bodyS, Vector3.new(0, 1.02, 0.25), 0.48, "Z", p3356.body)
	for v3357 = -1, 1, 2 do
		local v3358 = v3357 * 0.42
		v_u_72(p3356, v3357 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v3358, 0.62, 0.3), "leg", v3357 < 0 and 0 or 3.141592653589793)
		local v3359 = v_u_9(v3358, 0.4, 0.3)
		local v3360 = p3356.limbs
		v_u_80(p3356, Instance.new("Part"), Vector3.new(0.3, 0.42, 0.3), v3359, v3360, nil)
	end
	v_u_331(p3356, Vector3.new(0.68, 1.5, 0.3), 1.6, 0.35)
	p3356.headC = Vector3.new(0, 2.4, -0.2)
	p3356.headS = Vector3.new(2.15, 1.8, 1.75)
	p3356.eyeX = 0.48
	p3356.eyeY = 2.52
	p3356.mouthY = 1.92
	p3356.bandY = 3
	p3356.neck = Vector3.new(0, 1.6, -0.42)
	p3356.back = Vector3.new(0, 1.85, 0.9)
	p3356.tailAt = Vector3.new(0, 1, 0.9)
	v_u_72(p3356, "Head", "Body", Vector3.new(0, 1.75, -0.15), "head")
	v_u_3310(p3356, 0.42, p3356.eyeY - 0.42)
	v_u_3319(p3356, 0.42, 0.52, 0.22)
	v_u_162(p3356, 0.42, 0.52)
	local v3361 = p3356.face + 0.06
	local v3362 = v_u_9(0, p3356.mouthY + 0.02, v3361 - 0.08)
	local v3363, v3364 = p3356.limbs:Lerp(v_u_16, 0.35)
	v_u_80(p3356, Instance.new("Part"), Vector3.new(0.5, 0.3, 0.16), v3362, v3363, v3364)
	local v3365 = v_u_9(-0.11, p3356.mouthY, v3361 - 0.17)
	local v3366 = v_u_13
	v_u_80(p3356, Instance.new("Part"), Vector3.new(0.1, 0.1, 0.05), v3365, v3366, nil)
	local v3367 = v_u_9(0.11, p3356.mouthY, v3361 - 0.17)
	local v3368 = v_u_13
	v_u_80(p3356, Instance.new("Part"), Vector3.new(0.1, 0.1, 0.05), v3367, v3368, nil)
	local v3369 = v_u_9(0, p3356.mouthY - 0.22, v3361 - 0.03)
	local v3370 = v_u_13
	v_u_80(p3356, Instance.new("Part"), Vector3.new(0.42, 0.07, 0.05), v3369, v3370, nil)
	local v3371 = v_u_8(-0.2, p3356.mouthY - 0.24, v3361 - 0.05)
	local v3372 = v_u_14
	local v3373 = -(Vector3.new(0.13, 0, 0)).Unit
	local v3374 = (Vector3.new(0, -0.22, 0)).Unit
	local v3375 = CFrame.fromMatrix(v3371 + Vector3.new(0.065, 0, 0) + Vector3.new(0, -0.11, 0), v3374:Cross(v3373), v3374, v3373)
	local v3376 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(0.13, 0, 0)).Magnitude)
	v_u_80(p3356, Instance.new("WedgePart"), v3376, v3375, v3372, nil)
	local v3377 = v_u_8(0.2, p3356.mouthY - 0.24, v3361 - 0.05)
	local v3378 = v_u_14
	local v3379 = -(Vector3.new(-0.13, 0, 0)).Unit
	local v3380 = (Vector3.new(0, -0.22, 0)).Unit
	local v3381 = CFrame.fromMatrix(v3377 + Vector3.new(-0.065, 0, 0) + Vector3.new(0, -0.11, 0), v3380:Cross(v3379), v3380, v3379)
	local v3382 = v_u_8(0.06, (Vector3.new(0, -0.22, 0)).Magnitude, (Vector3.new(-0.13, 0, 0)).Magnitude)
	v_u_80(p3356, Instance.new("WedgePart"), v3382, v3381, v3378, nil)
	local v3383 = p3356.headC.Y + p3356.headS.Y / 2
	for v3384 = -1, 1, 2 do
		local v3385 = v_u_8(v3384 * (p3356.headS.X / 2 - 0.06), v3383 - 0.1, p3356.headC.Z + 0.05)
		local v3386 = v_u_8(-v3384 * 0.85, 0, 0)
		local v3387 = -v3384 * 0.28
		local v3388 = math.cos(v3387)
		local v3389 = math.sin(v3387)
		local v3390 = v_u_8(v3386.X * v3388 - v3386.Y * v3389, v3386.X * v3389 + v3386.Y * v3388, v3386.Z)
		local v3391 = -v3384 * 0.28
		local v3392 = math.cos(v3391)
		local v3393 = math.sin(v3391)
		local v3394 = v_u_8(v3392 * 0 - v3393 * 1.2999999523162842, v3393 * 0 + v3392 * 1.2999999523162842, 0)
		v_u_72(p3356, v3384 < 0 and "EarL" or "EarR", "Head", v3385 + v3390 / 2, "ear", v3384 * 1.3, v3384)
		local v3395 = p3356.limbs
		local v3396 = -v3390.Unit
		local v3397 = v3394.Unit
		local v3398 = CFrame.fromMatrix(v3385 + v3390 / 2 + v3394 / 2, v3397:Cross(v3396), v3397, v3396)
		local v3399 = v_u_8(0.3, v3394.Magnitude, v3390.Magnitude)
		v_u_80(p3356, Instance.new("WedgePart"), v3399, v3398, v3395, nil)
		local v3400 = v3385 + v3390 * 0.14 + v3394 * 0.08 + Vector3.new(0, 0, -0.05)
		local v3401 = v3390 * 0.62
		local v3402 = v3394 * 0.62
		local v3403 = p3356.accent
		local v3404 = -v3401.Unit
		local v3405 = v3402.Unit
		local v3406 = CFrame.fromMatrix(v3400 + v3401 / 2 + v3402 / 2, v3405:Cross(v3404), v3405, v3404)
		local v3407 = v_u_8(0.28, v3402.Magnitude, v3401.Magnitude)
		v_u_80(p3356, Instance.new("WedgePart"), v3407, v3406, v3403, nil)
	end
end
function v_u_925.scorpion(p3408) -- name: scorpion
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_2655, (copy) v_u_8, (copy) v_u_72, (copy) v_u_12, (copy) v_u_10, (copy) v_u_3310, (copy) v_u_3319, (copy) v_u_162, (copy) v_u_3332
	p3408.cur = p3408.byName.Body or p3408.bones[1]
	p3408.bodyC = Vector3.new(0, 0.85, 0.4)
	p3408.bodyS = Vector3.new(1.8, 0.85, 1.5)
	local v3409 = p3408.bodyS
	local v3410 = v_u_9(p3408.bodyC)
	local v3411 = p3408.body
	v_u_80(p3408, Instance.new("Part"), v3409, v3410, v3411, nil)
	local v3412 = v_u_9(0, 1.32, 0.45)
	local v3413 = v_u_2655
	v_u_80(p3408, Instance.new("Part"), Vector3.new(1.45, 0.14, 1.15), v3412, v3413, nil)
	local v3414 = v_u_9(0, 0.8, 1.42)
	local v3415 = p3408.limbs
	v_u_80(p3408, Instance.new("Part"), Vector3.new(1.45, 0.68, 0.7), v3414, v3415, nil)
	local v3416 = v_u_9(0, 1.18, 1.42)
	local v3417 = v_u_2655
	v_u_80(p3408, Instance.new("Part"), Vector3.new(1.15, 0.12, 0.5), v3416, v3417, nil)
	local v3418 = { 0.05, 0.5, 0.95 }
	local v3419 = { -0.45, 0, 0.45 }
	for v3420 = -1, 1, 2 do
		for v3421, v3422 in v3418 do
			local v3423 = v_u_8(v3420 * 0.85, 0.85, v3422)
			local v3424 = v_u_8(v3420 * 1.45, 1.15, v3422 + v3419[v3421] * 0.5)
			local v3425 = v_u_8(v3420 * 1.8, 0.06, v3422 + v3419[v3421])
			local v3426 = (v3421 + (v3420 < 0 and 0 or 1)) % 2 == 0 and 0 or 3.141592653589793
			v_u_72(p3408, (v3420 < 0 and "LegL" or "LegR") .. v3421, "Body", v3423, "scuttle", v3426, v3420)
			local v3427 = p3408.limbs
			local v3428 = (v3424 - v3423).Unit * 0.22 * 0.4
			local v3429 = v3423 - v3428
			local v3430 = v3424 + v3428
			local v3431 = (v3429 + v3430) / 2
			local v3432 = v_u_8(0.22, 0.22, (v3430 - v3429).Magnitude)
			local v3433 = CFrame.lookAt(v3431, v3430)
			v_u_80(p3408, Instance.new("Part"), v3432, v3433, v3427, nil)
			local v3434 = p3408.limbs
			local v3435 = (v3425 - v3424).Unit * 0.18 * 0.4
			local v3436 = v3424 - v3435
			local v3437 = v3425 + v3435
			local v3438 = (v3436 + v3437) / 2
			local v3439 = v_u_8(0.18, 0.18, (v3437 - v3436).Magnitude)
			local v3440 = CFrame.lookAt(v3438, v3437)
			v_u_80(p3408, Instance.new("Part"), v3439, v3440, v3434, nil)
		end
	end
	local v3441 = {}
	for v3442 = 0, 5 do
		local v3443 = v3442 * 38 + -75
		local v3444 = math.rad(v3443)
		local v3445 = Vector3.new(0, 1.95, 1.25) + v_u_8(0, math.sin(v3444), (math.cos(v3444)))
		table.insert(v3441, v3445)
	end
	p3408.tailAt = v3441[1]
	v_u_72(p3408, "Tail1", "Body", v3441[1], "tail", 0)
	for v3446 = 1, 5 do
		if v3446 == 4 then
			v_u_72(p3408, "Tail2", "Tail1", v3441[4], "tail", 0.9)
		end
		local v3447 = v3441[v3446]
		local v3448 = v3441[v3446 + 1]
		local v3449 = (v3447 + v3448) / 2 - Vector3.new(0, 1.95, 1.25)
		local v3450 = (v3447 - v3448).Unit
		local v3451 = (v3449 - v3450 * v3449:Dot(v3450)).Unit
		local v3452 = CFrame.fromMatrix((v3447 + v3448) / 2, v3451:Cross(v3450), v3451, v3450)
		local v3453 = 0.66 - v3446 * 0.05
		local v3454 = (v3448 - v3447).Magnitude
		local v3455 = v_u_8(v3453, v3453, v3454 + 0.22)
		local v3456
		if v3446 % 2 == 1 then
			v3456 = p3408.body
		else
			v3456 = p3408.limbs
		end
		v_u_80(p3408, Instance.new("Part"), v3455, v3452, v3456, nil)
		local v3457 = v_u_8(v3453 * 0.72, 0.1, v3454 * 0.7)
		local v3458 = v3452 * v_u_9(0, v3453 / 2 + 0.03, 0)
		local v3459 = v_u_2655
		v_u_80(p3408, Instance.new("Part"), v3457, v3458, v3459, nil)
	end
	local v3460 = v3441[6]
	local v3461 = CFrame.lookAt(v3460, v3460 + Vector3.new(0, -0.42261827, -0.9063078))
	local v3462 = p3408.body
	v_u_80(p3408, Instance.new("Part"), Vector3.new(0.48, 0.48, 0.5), v3461, v3462, nil)
	local v3463 = CFrame.lookAt(v3460 + Vector3.new(0, -0.25357097, -0.54378474), v3460 + Vector3.new(0, -0.84523654, -1.8126156))
	local v3464 = p3408.glow
	local v3465 = v_u_12
	v_u_80(p3408, Instance.new("WedgePart"), Vector3.new(0.26, 0.3, 0.75), v3463, v3464, v3465)
	for v3466 = -1, 1, 2 do
		local v3467 = v_u_8(v3466 * 1.08, 0.75, -0.3)
		local v3468 = v_u_8(v3466 * 1.62, 0.8, -0.85)
		local v3469 = v_u_8(v3466 * 1.48, 0.85, -1.5)
		v_u_72(p3408, v3466 < 0 and "ArmL" or "ArmR", "Body", v3467, "arm", v3466 * 0.9, v3466)
		local v3470 = p3408.limbs
		local v3471 = (v3468 - v3467).Unit * 0.3 * 0.4
		local v3472 = v3467 - v3471
		local v3473 = v3468 + v3471
		local v3474 = (v3472 + v3473) / 2
		local v3475 = v_u_8(0.3, 0.3, (v3473 - v3472).Magnitude)
		local v3476 = CFrame.lookAt(v3474, v3473)
		v_u_80(p3408, Instance.new("Part"), v3475, v3476, v3470, nil)
		local v3477 = p3408.limbs
		local v3478 = (v3469 - v3468).Unit * 0.28 * 0.4
		local v3479 = v3468 - v3478
		local v3480 = v3469 + v3478
		local v3481 = (v3479 + v3480) / 2
		local v3482 = v_u_8(0.28, 0.28, (v3480 - v3479).Magnitude)
		local v3483 = CFrame.lookAt(v3481, v3480)
		v_u_80(p3408, Instance.new("Part"), v3482, v3483, v3477, nil)
		local v3484 = CFrame.lookAt(v3469, v3469 + v_u_8(-v3466 * 0.15, 0, -1)) * v_u_9(0, 0, -0.2)
		local v3485 = p3408.body
		v_u_80(p3408, Instance.new("Part"), Vector3.new(0.72, 0.58, 0.7), v3484, v3485, nil)
		local v3486 = v3484 * v_u_9(v3466 * 0.2, 0, -0.32) * v_u_10(0, -v3466 * 0.1, 0) * v_u_9(0, 0, -0.3)
		local v3487 = p3408.body
		v_u_80(p3408, Instance.new("Part"), Vector3.new(0.3, 0.34, 0.78), v3486, v3487, nil)
		local v3488 = v3484 * v_u_9(-v3466 * 0.2, -0.02, -0.32) * v_u_10(0, v3466 * 0.4, 0) * v_u_9(0, 0, -0.22)
		local v3489 = p3408.limbs
		v_u_80(p3408, Instance.new("Part"), Vector3.new(0.24, 0.28, 0.58), v3488, v3489, nil)
	end
	p3408.headC = Vector3.new(0, 1.45, -0.88)
	p3408.headS = Vector3.new(2.05, 1.6, 1.4)
	p3408.eyeX = 0.48
	p3408.eyeY = 1.62
	p3408.mouthY = 0.98
	p3408.bandY = 1.98
	p3408.plateW = 0.85
	p3408.neck = Vector3.new(0, 0.8, -1.25)
	p3408.back = Vector3.new(0, 1.4, 0.6)
	v_u_72(p3408, "Head", "Body", Vector3.new(0, 1, -0.35), "head")
	v_u_3310(p3408, 0.4)
	v_u_3319(p3408, 0.4, 0.5, 0.25)
	v_u_162(p3408, 0.4, 0.5)
	v_u_3332(p3408, 0.72, 4, p3408.mouthY)
end
function v_u_925.panther(p3490) -- name: panther
	-- upvalues: (copy) v_u_3296, (copy) v_u_9, (copy) v_u_80, (copy) v_u_290, (copy) v_u_12, (copy) v_u_72, (copy) v_u_8, (copy) v_u_13, (copy) v_u_162, (copy) v_u_216
	p3490.cur = p3490.byName.Body or p3490.bones[1]
	p3490.bodyC = Vector3.new(0, 1.4, 0.6)
	p3490.bodyS = Vector3.new(1.5, 1.15, 2.5)
	v_u_3296(p3490, p3490.bodyC, p3490.bodyS, Vector3.new(0, 1.38, 0.95), 0.55, "X", p3490.body)
	local v3491 = v_u_9(0, 1.3, -0.68)
	local v3492 = p3490.belly
	v_u_80(p3490, Instance.new("Part"), Vector3.new(1.05, 0.8, 0.1), v3491, v3492, nil)
	v_u_290(p3490, 0.45, -0.3, 1.45, Vector3.new(0.46, 0.85, 0.46))
	p3490.tailAt = Vector3.new(0, 1.75, 1.85)
	local v3493
	if p3490.look.tip then
		local v3494 = p3490.look.tip
		v3493 = Color3.fromHex(v3494)
	else
		v3493 = p3490.accent
	end
	local v3495
	if p3490.look.tip then
		v3495 = v_u_12
	else
		v3495 = nil
	end
	v_u_72(p3490, "Tail1", "Body", p3490.tailAt, "tail", 0)
	local v3496 = p3490.tailAt
	local v3497 = v3496 + Vector3.new(0, -0.3, 0.75)
	local v3498 = v3497 + Vector3.new(0, 0.55, 0.5)
	local v3499 = p3490.body
	local v3500 = (v3497 - v3496).Unit * 0.3 * 0.4
	local v3501 = v3496 - v3500
	local v3502 = v3497 + v3500
	local v3503 = (v3501 + v3502) / 2
	local v3504 = v_u_8(0.3, 0.3, (v3502 - v3501).Magnitude)
	local v3505 = CFrame.lookAt(v3503, v3502)
	v_u_80(p3490, Instance.new("Part"), v3504, v3505, v3499, nil)
	local v3506 = p3490.body
	local v3507 = (v3498 - v3497).Unit * 0.28 * 0.4
	local v3508 = v3497 - v3507
	local v3509 = v3498 + v3507
	local v3510 = (v3508 + v3509) / 2
	local v3511 = v_u_8(0.28, 0.28, (v3509 - v3508).Magnitude)
	local v3512 = CFrame.lookAt(v3510, v3509)
	v_u_80(p3490, Instance.new("Part"), v3511, v3512, v3506, nil)
	v_u_72(p3490, "Tail2", "Tail1", v3498, "tail", 0.9)
	local v3513 = v3498 + Vector3.new(0, 0.7, 0.05)
	local v3514 = v3513 + Vector3.new(0, 0.22, -0.32)
	local v3515 = p3490.body
	local v3516 = (v3513 - v3498).Unit * 0.26 * 0.4
	local v3517 = v3498 - v3516
	local v3518 = v3513 + v3516
	local v3519 = (v3517 + v3518) / 2
	local v3520 = v_u_8(0.26, 0.26, (v3518 - v3517).Magnitude)
	local v3521 = CFrame.lookAt(v3519, v3518)
	v_u_80(p3490, Instance.new("Part"), v3520, v3521, v3515, nil)
	local v3522 = (v3514 - v3513).Unit * 0.26 * 0.4
	local v3523 = v3513 - v3522
	local v3524 = v3514 + v3522
	local v3525 = (v3523 + v3524) / 2
	local v3526 = v_u_8(0.26, 0.26, (v3524 - v3523).Magnitude)
	local v3527 = CFrame.lookAt(v3525, v3524)
	v_u_80(p3490, Instance.new("Part"), v3526, v3527, v3493, v3495)
	p3490.headC = Vector3.new(0, 2.3, -1)
	p3490.headS = Vector3.new(1.9, 1.55, 1.5)
	p3490.face = p3490.headC.Z - p3490.headS.Z / 2
	p3490.eyeX = 0.46
	p3490.eyeY = 2.4
	p3490.mouthY = 1.86
	p3490.bandY = 2.85
	p3490.plateW = 0.85
	p3490.neck = Vector3.new(0, 1.55, -0.72)
	p3490.back = Vector3.new(0, 2, 1.1)
	v_u_72(p3490, "Head", "Body", Vector3.new(0, 1.75, -0.7), "head")
	local v3528 = p3490.headS
	local v3529 = v_u_9(p3490.headC)
	local v3530 = p3490.body
	v_u_80(p3490, Instance.new("Part"), v3528, v3529, v3530, nil)
	local v3531 = v_u_9(0, p3490.mouthY, p3490.face - 0.14)
	local v3532 = p3490.belly
	v_u_80(p3490, Instance.new("Part"), Vector3.new(0.9, 0.48, 0.3), v3531, v3532, nil)
	local v3533 = v_u_9(0, p3490.mouthY + 0.14, p3490.face - 0.32)
	local v3534 = v_u_13
	v_u_80(p3490, Instance.new("Part"), Vector3.new(0.3, 0.17, 0.1), v3533, v3534, nil)
	v_u_162(p3490, 0.42, 0.5)
	v_u_216(p3490)
end
function v_u_925.menos(p3535) -- name: menos
	-- upvalues: (copy) v_u_72, (copy) v_u_8, (copy) v_u_9, (copy) v_u_2655, (copy) v_u_80, (copy) v_u_3296, (copy) v_u_3310, (copy) v_u_3319, (copy) v_u_162, (copy) v_u_3332, (copy) v_u_12
	p3535.cur = p3535.byName.Body or p3535.bones[1]
	for v3536 = -1, 1, 2 do
		local v3537 = v3536 * 0.45
		v_u_72(p3535, v3536 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v3537, 0.35, -0.2), "leg", v3536 < 0 and 0 or 3.141592653589793)
		local v3538 = v_u_9(v3537, 0.17, -0.55)
		local v3539 = v_u_2655
		v_u_80(p3535, Instance.new("Part"), Vector3.new(0.5, 0.34, 0.8), v3538, v3539, nil)
		local v3540 = v_u_9(v3537, 0.12, -1.11)
		local v3541 = v_u_2655
		v_u_80(p3535, Instance.new("WedgePart"), Vector3.new(0.5, 0.24, 0.32), v3540, v3541, nil)
	end
	p3535.cur = p3535.byName.Body or p3535.bones[1]
	p3535.bodyC = Vector3.new(0, 1.3, 0.1)
	p3535.bodyS = Vector3.new(1.95, 1.1, 1.75)
	local v3542 = v_u_9(0, 0.56, 0.1)
	local v3543 = p3535.body
	v_u_80(p3535, Instance.new("Part"), Vector3.new(2.2, 0.48, 2), v3542, v3543, nil)
	v_u_3296(p3535, p3535.bodyC, p3535.bodyS, Vector3.new(0, 1.27, 0.1), 0.5, "Z", p3535.body)
	local v3544 = v_u_9(0, 2, 0.1)
	local v3545 = p3535.body
	v_u_80(p3535, Instance.new("Part"), Vector3.new(1.7, 0.38, 1.55), v3544, v3545, nil)
	for v3546 = 0, 5 do
		local v3547 = v3546 * 0.36 + -1.08
		local v3548 = v_u_8(v3547, 0.34, -0.88)
		local v3549 = p3535.body
		local v3550 = -(Vector3.new(0.36, 0, 0)).Unit
		local v3551 = (Vector3.new(0, -0.27, 0)).Unit
		local v3552 = CFrame.fromMatrix(v3548 + Vector3.new(0.18, 0, 0) + Vector3.new(0, -0.135, 0), v3551:Cross(v3550), v3551, v3550)
		local v3553 = v_u_8(0.1, (Vector3.new(0, -0.27, 0)).Magnitude, (Vector3.new(0.36, 0, 0)).Magnitude)
		v_u_80(p3535, Instance.new("WedgePart"), v3553, v3552, v3549, nil)
		if v3546 >= 5 then
			continue
		end
		local v3554 = v_u_8(-v3547, 0.34, 1.08)
		local v3555 = p3535.body
		local v3556 = -(Vector3.new(-0.36, 0, 0)).Unit
		local v3557 = (Vector3.new(0, -0.27, 0)).Unit
		local v3558 = CFrame.fromMatrix(v3554 + Vector3.new(-0.18, 0, 0) + Vector3.new(0, -0.135, 0), v3557:Cross(v3556), v3557, v3556)
		local v3559 = v_u_8(0.1, (Vector3.new(0, -0.27, 0)).Magnitude, (Vector3.new(-0.36, 0, 0)).Magnitude)
		v_u_80(p3535, Instance.new("WedgePart"), v3559, v3558, v3555, nil)
	end
	for v3560 = -1, 1, 2 do
		for v3561 = 0, 2 do
			local v3562 = v3561 * 0.6 + -0.8
			local v3563 = v_u_8(v3560 * 1.08, 0.34, v3562)
			local v3564 = p3535.body
			local v3565 = -(Vector3.new(0, 0, 0.45)).Unit
			local v3566 = (Vector3.new(0, -0.27, 0)).Unit
			local v3567 = CFrame.fromMatrix(v3563 + Vector3.new(0, 0, 0.225) + Vector3.new(0, -0.135, 0), v3566:Cross(v3565), v3566, v3565)
			local v3568 = v_u_8(0.1, (Vector3.new(0, -0.27, 0)).Magnitude, (Vector3.new(0, 0, 0.45)).Magnitude)
			v_u_80(p3535, Instance.new("WedgePart"), v3568, v3567, v3564, nil)
		end
	end
	for v3569 = 0, 6 do
		local v3570 = v3569 * 36.7 + 70
		local v3571 = math.rad(v3570)
		local v3572 = v_u_8(math.sin(v3571), 0, -math.cos(v3571))
		local v3573 = Vector3.new(0, 2.12, 0.1) + v3572 * 0.78
		local v3574 = v3572 * 0.75
		local v3575 = v_u_2655
		local v3576 = -v3574.Unit
		local v3577 = (Vector3.new(0, 0.45, 0)).Unit
		local v3578 = CFrame.fromMatrix(v3573 + v3574 / 2 + Vector3.new(0, 0.225, 0), v3577:Cross(v3576), v3577, v3576)
		local v3579 = v_u_8(0.14, (Vector3.new(0, 0.45, 0)).Magnitude, v3574.Magnitude)
		v_u_80(p3535, Instance.new("WedgePart"), v3579, v3578, v3575, nil)
	end
	p3535.headC = Vector3.new(0, 3.1, -0.1)
	p3535.headS = Vector3.new(2.25, 2, 1.9)
	p3535.eyeX = 0.52
	p3535.eyeY = 3.42
	p3535.mouthY = 2.48
	p3535.bandY = 3.8
	p3535.plateW = 0.9
	p3535.neck = Vector3.new(0, 2.1, -0.6)
	p3535.back = Vector3.new(0, 2, 0.9)
	p3535.tailAt = Vector3.new(0, 1.1, 0.95)
	v_u_72(p3535, "Head", "Body", Vector3.new(0, 2.15, -0.1), "head")
	v_u_3310(p3535, 0.4)
	v_u_3319(p3535, 0.34, 0.42, 0.15)
	v_u_162(p3535, 0.34, 0.42)
	local v3580 = v_u_8(0, p3535.eyeY - 0.4, p3535.face + 0.1)
	local v3581 = v3580 + Vector3.new(0, -0.1, -0.72)
	local v3582 = v3581 + Vector3.new(0, -0.1, -0.6)
	local v3583 = v_u_2655
	local v3584 = (v3581 - v3580).Unit * 0.42 * 0.4
	local v3585 = v3580 - v3584
	local v3586 = v3581 + v3584
	local v3587 = (v3585 + v3586) / 2
	local v3588 = v_u_8(0.42, 0.42, (v3586 - v3585).Magnitude)
	local v3589 = CFrame.lookAt(v3587, v3586)
	v_u_80(p3535, Instance.new("Part"), v3588, v3589, v3583, nil)
	local v3590 = v_u_2655
	local v3591 = (v3582 - v3581).Unit * 0.27 * 0.4
	local v3592 = v3581 - v3591
	local v3593 = v3582 + v3591
	local v3594 = (v3592 + v3593) / 2
	local v3595 = v_u_8(0.27, 0.27, (v3593 - v3592).Magnitude)
	local v3596 = CFrame.lookAt(v3594, v3593)
	v_u_80(p3535, Instance.new("Part"), v3595, v3596, v3590, nil)
	v_u_3332(p3535, 0.95, 4, p3535.mouthY)
	local v3597 = v_u_8(0, p3535.mouthY - 0.12, p3535.face - 0.75)
	v_u_72(p3535, "Cero", "Head", v3597, "orbit", 0.4)
	local v3598 = p3535.glow
	local v3599 = v_u_12
	local v3600 = Instance.new("Part")
	v3600.Shape = Enum.PartType.Ball
	v_u_80(p3535, v3600, Vector3.new(0.52, 0.52, 0.52), v_u_9(v3597), v3598, v3599)
end
function v_u_925.lizard(p3601) -- name: lizard
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_72, (copy) v_u_12, (copy) v_u_162, (copy) v_u_167, (copy) v_u_13, (copy) v_u_10
	p3601.cur = p3601.byName.Body or p3601.bones[1]
	p3601.bodyC = Vector3.new(0, 0.82, 0.45)
	p3601.bodyS = Vector3.new(1.45, 0.78, 2)
	local v3602 = p3601.bodyS
	local v3603 = v_u_9(p3601.bodyC)
	local v3604 = p3601.body
	v_u_80(p3601, Instance.new("Part"), v3602, v3603, v3604, nil)
	local v3605 = v_u_9(0, 0.42, 0.45)
	local v3606 = p3601.belly
	v_u_80(p3601, Instance.new("Part"), Vector3.new(1.1, 0.1, 1.7), v3605, v3606, nil)
	for v3607, v3608 in {
		{ -1, -0.2, 0 },
		{ 1, -0.2, 3.141592653589793 },
		{ -1, 1.1, 3.141592653589793 },
		{ 1, 1.1, 0 }
	} do
		local v3609 = v3608[1]
		local v3610 = v3608[2]
		local v3611 = v_u_8(v3609 * 0.62, 0.78, v3610)
		local v3612 = v_u_8(v3609 * 1.15, 0.82, v3610 - 0.05)
		local v3613 = v_u_8(v3609 * 1.25, 0.12, v3610 - 0.12)
		v_u_72(p3601, "Leg" .. v3607, "Body", v3611, "leg", v3608[3])
		local v3614 = p3601.limbs
		local v3615 = (v3612 - v3611).Unit * 0.34 * 0.4
		local v3616 = v3611 - v3615
		local v3617 = v3612 + v3615
		local v3618 = (v3616 + v3617) / 2
		local v3619 = v_u_8(0.34, 0.34, (v3617 - v3616).Magnitude)
		local v3620 = CFrame.lookAt(v3618, v3617)
		v_u_80(p3601, Instance.new("Part"), v3619, v3620, v3614, nil)
		local v3621 = p3601.limbs
		local v3622 = (v3613 - v3612).Unit * 0.3 * 0.4
		local v3623 = v3612 - v3622
		local v3624 = v3613 + v3622
		local v3625 = (v3623 + v3624) / 2
		local v3626 = v_u_8(0.3, 0.3, (v3624 - v3623).Magnitude)
		local v3627 = CFrame.lookAt(v3625, v3624)
		v_u_80(p3601, Instance.new("Part"), v3626, v3627, v3621, nil)
		local v3628 = v_u_9(v3613 + v_u_8(v3609 * 0.06, -0.05, -0.12))
		local v3629 = p3601.limbs
		v_u_80(p3601, Instance.new("Part"), Vector3.new(0.46, 0.14, 0.55), v3628, v3629, nil)
	end
	p3601.tailAt = Vector3.new(0, 0.8, 1.4)
	v_u_72(p3601, "Tail1", "Body", Vector3.new(0, 0.8, 1.4), "swim", 0.9)
	local v3630 = v_u_8(0.72, 0.55, (Vector3.new(0.18, -0.13999999, 0.8000001)).Magnitude + 0.25)
	local v3631 = CFrame.lookAt(Vector3.new(0.09, 0.73, 1.8), Vector3.new(0.18, 0.66, 2.2))
	local v3632 = p3601.body
	v_u_80(p3601, Instance.new("Part"), v3630, v3631, v3632, nil)
	v_u_72(p3601, "Tail2", "Tail1", Vector3.new(0.18, 0.66, 2.2), "swim", 1.8)
	local v3633 = v_u_8(0.5, 0.4, (Vector3.new(-0.28, -0.110000014, 0.75)).Magnitude + 0.2)
	local v3634 = CFrame.lookAt(Vector3.new(0.040000003, 0.605, 2.575), Vector3.new(-0.1, 0.55, 2.95))
	local v3635 = p3601.body
	v_u_80(p3601, Instance.new("Part"), v3633, v3634, v3635, nil)
	v_u_72(p3601, "Tail3", "Tail2", Vector3.new(-0.1, 0.55, 2.95), "swim", 2.7)
	local v3636 = v_u_8(0.32, 0.26, (Vector3.new(-0.35, -0.07000002, 0.5999999)).Magnitude + 0.15)
	local v3637 = CFrame.lookAt(Vector3.new(-0.275, 0.515, 3.25), Vector3.new(-0.45, 0.48, 3.55))
	local v3638
	if p3601.look.tip then
		local v3639 = p3601.look.tip
		v3638 = Color3.fromHex(v3639)
	else
		v3638 = p3601.body
	end
	local v3640
	if p3601.look.tip then
		v3640 = v_u_12
	else
		v3640 = nil
	end
	v_u_80(p3601, Instance.new("Part"), v3636, v3637, v3638, v3640)
	p3601.headC = Vector3.new(0, 1.3, -0.95)
	p3601.headS = Vector3.new(1.9, 1.2, 1.55)
	p3601.face = p3601.headC.Z - p3601.headS.Z / 2
	p3601.eyeX = 0.48
	p3601.eyeY = 1.45
	p3601.mouthY = 0.95
	p3601.bandY = 1.82
	p3601.plateW = 0.85
	p3601.neck = Vector3.new(0, 0.7, -0.6)
	p3601.back = Vector3.new(0, 1.3, 0.6)
	v_u_72(p3601, "Head", "Body", Vector3.new(0, 0.95, -0.4), "head")
	local v3641 = p3601.headS
	local v3642 = v_u_9(p3601.headC)
	local v3643 = p3601.body
	v_u_80(p3601, Instance.new("Part"), v3641, v3642, v3643, nil)
	v_u_162(p3601, 0.44, 0.5)
	v_u_167(p3601)
	local v3644 = p3601.face - 0.45
	local v3645 = v_u_9(0, p3601.mouthY, p3601.face - 0.2)
	local v3646 = p3601.body
	v_u_80(p3601, Instance.new("Part"), Vector3.new(1.45, 0.5, 0.5), v3645, v3646, nil)
	local v3647 = v_u_9(0, p3601.mouthY - 0.27, p3601.face - 0.2)
	local v3648 = p3601.belly
	v_u_80(p3601, Instance.new("Part"), Vector3.new(1.25, 0.12, 0.46), v3647, v3648, nil)
	local v3649 = v_u_9(0, p3601.mouthY - 0.1, v3644 - 0.03)
	local v3650 = v_u_13
	v_u_80(p3601, Instance.new("Part"), Vector3.new(1.1, 0.07, 0.05), v3649, v3650, nil)
	for v3651 = -1, 1, 2 do
		local v3652 = v_u_9(v3651 * 0.57, p3601.mouthY - 0.05, v3644 - 0.03) * v_u_10(0, 0, v3651 * 0.5)
		local v3653 = v_u_13
		v_u_80(p3601, Instance.new("Part"), Vector3.new(0.1, 0.16, 0.05), v3652, v3653, nil)
		local v3654 = v_u_9(v3651 * 0.2, p3601.mouthY + 0.14, v3644 - 0.03)
		local v3655 = v_u_13
		v_u_80(p3601, Instance.new("Part"), Vector3.new(0.12, 0.08, 0.05), v3654, v3655, nil)
	end
end
function v_u_925.batserpent(p3656) -- name: batserpent
	-- upvalues: (copy) v_u_3333, (copy) v_u_72, (copy) v_u_3334, (copy) v_u_8, (copy) v_u_80, (copy) v_u_9, (copy) v_u_124, (copy) v_u_12, (copy) v_u_331, (copy) v_u_162, (copy) v_u_13
	p3656.cur = p3656.byName.Body or p3656.bones[1]
	local v3657 = p3656.body:Lerp(p3656.limbs, 0.12)
	for v3658 = 1, 5 do
		local v3659 = v_u_3333[v3658]
		local v3660 = v_u_3333[v3658 + 1]
		if v3658 > 1 then
			v_u_72(p3656, "Seg" .. v3658, v3658 == 2 and "Body" or "Seg" .. v3658 - 1, v3659, "swim", v3658 * 0.9)
		end
		local v3661 = v_u_3334[v3658]
		local v3662 = CFrame.lookAt((v3659 + v3660) / 2, v3660)
		local v3663 = (v3660 - v3659).Magnitude + 0.3
		local v3664
		if v3658 >= 4 then
			v3664 = p3656.limbs
		elseif v3658 == 2 then
			v3664 = v3657
		else
			v3664 = p3656.body
		end
		local v3665 = v_u_8(v3661, v3661 * 0.92, v3663)
		v_u_80(p3656, Instance.new("Part"), v3665, v3662, v3664, nil)
		if v3658 > 3 then
			continue
		end
		local v3666 = v_u_8(v3661 * 0.66, 0.1, v3663 - 0.15)
		local v3667 = v3662 * v_u_9(0, -v3661 * 0.46, 0)
		local v3668 = p3656.belly
		v_u_80(p3656, Instance.new("Part"), v3666, v3667, v3668, nil)
	end
	local v3669 = v_u_3333[6]
	local v3670 = (v3669 - v_u_3333[5]).Unit
	local v3671 = v3670:Cross(Vector3.new(0, 1, 0)).Unit
	v_u_72(p3656, "Fin", "Seg5", v3669, "swim", 5.4)
	v_u_124(p3656, v3669 - v3671 * 0.42, v3669 + v3671 * 0.42, v3669 + v3670 * 0.9, 0.14, p3656.limbs)
	v_u_124(p3656, v3669 - v3671 * 0.2, v3669 + v3671 * 0.2, v3669 + v3670 * 0.5, 0.18, p3656.glow, v_u_12)
	v_u_331(p3656, Vector3.new(0.5, 2.45, 0.2), 1.95, 0.45)
	p3656.bodyC = (v_u_3333[1] + v_u_3333[2]) / 2
	p3656.bodyS = Vector3.new(1.2, 1.1, 1.2)
	p3656.tailAt = v3669
	p3656.headC = Vector3.new(0, 2.5, -1.05)
	p3656.headS = Vector3.new(1.85, 1.6, 1.55)
	p3656.face = p3656.headC.Z - p3656.headS.Z / 2
	p3656.eyeX = 0.46
	p3656.eyeY = 2.5
	p3656.mouthY = 1.98
	p3656.bandY = 2.95
	p3656.plateW = 0.85
	p3656.neck = Vector3.new(0, 1.6, -0.55)
	p3656.back = Vector3.new(0, 2.75, 0.2)
	v_u_72(p3656, "Head", "Body", v_u_3333[1], "head")
	local v3672 = p3656.headS
	local v3673 = v_u_9(p3656.headC)
	local v3674 = p3656.body
	v_u_80(p3656, Instance.new("Part"), v3672, v3673, v3674, nil)
	v_u_162(p3656, 0.42, 0.52)
	local v3675 = v_u_9(0, p3656.mouthY, p3656.face - 0.03)
	local v3676 = v_u_13
	v_u_80(p3656, Instance.new("Part"), Vector3.new(0.3, 0.07, 0.05), v3675, v3676, nil)
end
function v_u_925.eagle(p3677) -- name: eagle
	-- upvalues: (copy) v_u_18, (copy) v_u_12, (copy) v_u_9, (copy) v_u_80, (copy) v_u_72, (copy) v_u_8, (copy) v_u_10, (copy) v_u_162, (copy) v_u_13
	p3677.cur = p3677.byName.Body or p3677.bones[1]
	local v3678 = p3677.look
	local v3679
	if v3678.beak then
		local v3680 = v3678.beak
		v3679 = Color3.fromHex(v3680)
	else
		v3679 = v_u_18
	end
	local v3681 = v3678.wings or { v3678.body }
	p3677.bodyC = Vector3.new(0, 1.35, 0.3)
	p3677.bodyS = Vector3.new(1.6, 1.5, 1.7)
	local v3682 = p3677.bodyS
	local v3683 = v_u_9(p3677.bodyC)
	local v3684 = p3677.body
	v_u_80(p3677, Instance.new("Part"), v3682, v3683, v3684, nil)
	local v3685 = v_u_9(0, 1.25, -0.57)
	local v3686 = p3677.belly
	v_u_80(p3677, Instance.new("Part"), Vector3.new(1.2, 1.15, 0.1), v3685, v3686, nil)
	for v3687 = -1, 1, 2 do
		local v3688 = v3687 * 0.4
		v_u_72(p3677, v3687 < 0 and "Leg1" or "Leg2", "Body", v_u_8(v3688, 0.7, 0.3), "leg", v3687 < 0 and 0 or 3.141592653589793)
		local v3689 = v_u_9(v3688, 0.42, 0.3)
		v_u_80(p3677, Instance.new("Part"), Vector3.new(0.26, 0.55, 0.26), v3689, v3679, nil)
		local v3690 = v_u_9(v3688, 0.1, 0.18)
		v_u_80(p3677, Instance.new("Part"), Vector3.new(0.44, 0.12, 0.5), v3690, v3679, nil)
	end
	p3677.tailAt = Vector3.new(0, 1, 1.1)
	v_u_72(p3677, "Tail1", "Body", p3677.tailAt, "tail", 0)
	for v3691 = -2, 2 do
		local v3692 = v_u_9(p3677.tailAt) * v_u_10(0, v3691 * 0.24, 0) * v_u_10(-0.3, 0, 0)
		local v3693 = 1.25 - math.abs(v3691) * 0.12
		local v3694 = v_u_8(0.36, 0.1, v3693)
		local v3695 = v3692 * v_u_9(0, 0, v3693 / 2)
		local v3696 = p3677.body
		v_u_80(p3677, Instance.new("Part"), v3694, v3695, v3696, nil)
		local v3697 = v3692 * v_u_9(0, 0, v3693 - 0.1)
		local v3698 = p3677.accent
		v_u_80(p3677, Instance.new("Part"), Vector3.new(0.38, 0.12, 0.32), v3697, v3698, nil)
	end
	local v3699 = #v3681
	local v3700 = v3681[math.min(1, v3699)]
	local v3701 = Color3.fromHex(v3700)
	local v3702
	if v3700 == v3678.glow then
		v3702 = v_u_12
	else
		v3702 = nil
	end
	local v3703 = #v3681
	local v3704 = v3681[math.min(2, v3703)]
	local v3705 = Color3.fromHex(v3704)
	local v3706
	if v3704 == v3678.glow then
		v3706 = v_u_12
	else
		v3706 = nil
	end
	local v3707 = #v3681
	local v3708 = v3681[math.min(3, v3707)]
	local v3709 = Color3.fromHex(v3708)
	local v3710
	if v3708 == v3678.glow then
		v3710 = v_u_12
	else
		v3710 = nil
	end
	local v3711 = #v3681
	local v3712 = v3681[math.min(4, v3711)]
	local v3713 = Color3.fromHex(v3712)
	local v3714
	if v3712 == v3678.glow then
		v3714 = v_u_12
	else
		v3714 = nil
	end
	local v3715 = {
		{ 1, 2.05 },
		{ 0.68, 1.9 },
		{ 0.36, 1.65 },
		{ 0.06, 1.35 }
	}
	for v3716 = -1, 1, 2 do
		local v3717 = v_u_8(v3716 * 0.72, 1.95, 0.4)
		v_u_72(p3677, v3716 < 0 and "WingL" or "WingR", "Body", v3717, "wing", 0, v3716)
		local v3718 = v_u_9(v3717) * v_u_10(0, -v3716 * 0.25, 0)
		local v3719 = v3718 * v_u_9(v3716 * 0.18, 0.05, 0.1)
		local v3720 = p3677.body
		v_u_80(p3677, Instance.new("Part"), Vector3.new(0.62, 0.62, 0.34), v3719, v3720, nil)
		for v3721, v3722 in v3715 do
			local v3723 = v3718 * v_u_10(0, 0, v3716 * v3722[1]) * v_u_9(0, 0, 0.06 * v3721)
			local v3724 = v3722[2]
			local v3725 = v3721 % 2 == 1
			local v3726 = v_u_8(v3724, 0.5, 0.14)
			local v3727 = v3723 * v_u_9(v3716 * v3724 / 2, 0, 0)
			local v3728
			if v3725 then
				v3728 = v3701
			else
				v3728 = v3705
			end
			local v3729
			if v3725 then
				v3729 = v3702
			else
				v3729 = v3706
			end
			v_u_80(p3677, Instance.new("Part"), v3726, v3727, v3728, v3729)
			local v3730 = v3723 * v_u_9(v3716 * (v3724 - 0.17), 0, 0)
			local v3731
			if v3721 <= 2 then
				v3731 = v3713
			else
				v3731 = v3709
			end
			local v3732
			if v3721 <= 2 then
				v3732 = v3714
			else
				v3732 = v3710
			end
			v_u_80(p3677, Instance.new("Part"), Vector3.new(0.42, 0.52, 0.17), v3730, v3731, v3732)
		end
	end
	p3677.headC = Vector3.new(0, 2.7, -0.45)
	p3677.headS = Vector3.new(1.7, 1.5, 1.55)
	p3677.face = p3677.headC.Z - p3677.headS.Z / 2
	p3677.eyeX = 0.44
	p3677.eyeY = 2.78
	p3677.mouthY = 2.22
	p3677.bandY = 3.2
	p3677.plateW = 0.85
	p3677.neck = Vector3.new(0, 1.95, -0.62)
	p3677.back = Vector3.new(0, 2, 0.6)
	v_u_72(p3677, "Head", "Body", Vector3.new(0, 2, -0.2), "head")
	local v3733 = p3677.headS
	local v3734 = v_u_9(p3677.headC)
	local v3735 = v3678.cloth or "#FFFFFF"
	local v3736, v3737 = Color3.fromHex(v3735)
	v_u_80(p3677, Instance.new("Part"), v3733, v3734, v3736, v3737)
	local v3738 = v_u_8(p3677.headS.X + 0.1, 0.2, p3677.headS.Z + 0.1)
	local v3739 = v_u_9(0, 2.02, p3677.headC.Z)
	v_u_80(p3677, Instance.new("Part"), v3738, v3739, v3679, nil)
	v_u_162(p3677, 0.4, 0.48)
	for v3740 = -1, 1, 2 do
		local v3741 = v_u_9(v3740 * (p3677.eyeX + 0.04), p3677.eyeY + 0.36, p3677.face - 0.06) * v_u_10(0, 0, v3740 * 0.28)
		v_u_80(p3677, Instance.new("Part"), Vector3.new(0.58, 0.16, 0.22), v3741, v3679, nil)
	end
	local v3742 = p3677.face
	local v3743 = v_u_9(0, p3677.mouthY + 0.12, v3742 - 0.24)
	v_u_80(p3677, Instance.new("Part"), Vector3.new(0.56, 0.32, 0.55), v3743, v3679, nil)
	local v3744 = v_u_9(0, p3677.mouthY - 0.02, v3742 - 0.48)
	v_u_80(p3677, Instance.new("Part"), Vector3.new(0.4, 0.4, 0.22), v3744, v3679, nil)
	local v3745 = v_u_9(0, p3677.mouthY - 0.1, v3742 - 0.16)
	local v3746, v3747 = v3679:Lerp(v_u_13, 0.3)
	v_u_80(p3677, Instance.new("Part"), Vector3.new(0.42, 0.12, 0.36), v3745, v3746, v3747)
end
function v_u_926.maskstripes(p3748) -- name: maskstripes
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80
	p3748.cur = p3748.byName.Head or p3748.bones[1]
	local v3749 = p3748.headC.Y + p3748.headS.Y / 2
	for v3750 = -1, 1, 2 do
		local v3751 = v3750 * (p3748.eyeX + 0.02)
		local v3752 = p3748.eyeY + 0.42
		local v3753 = v_u_8(0.13, v3749 - 0.04 - v3752, 0.04)
		local v3754 = v_u_9(v3751, (v3749 - 0.04 + v3752) / 2, p3748.face - 0.02)
		local v3755 = p3748.accent
		v_u_80(p3748, Instance.new("Part"), v3753, v3754, v3755, nil)
		local v3756 = p3748.eyeY - 0.42
		local v3757 = p3748.eyeY - 0.85
		local v3758 = v_u_8(0.13, v3756 - v3757, 0.04)
		local v3759 = v_u_9(v3751, (v3756 + v3757) / 2, p3748.face - 0.02)
		local v3760 = p3748.accent
		v_u_80(p3748, Instance.new("Part"), v3758, v3759, v3760, nil)
	end
end
function v_u_926.maskband(p3761) -- name: maskband
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2655, (copy) v_u_80
	p3761.cur = p3761.byName.Head or p3761.bones[1]
	local v3762 = p3761.face - 0.06
	local v3763 = p3761.headS.X * 0.84
	local v3764 = p3761.eyeY
	local v3765 = v3764 - 0.34 - 0.04
	local v3766 = v3764 + 0.34 + 0.16
	local v3767 = -v3763 / 2
	local v3768 = v3763 / 2 - 0.22
	local v3769 = -p3761.eyeX
	local v3770 = p3761.eyeX
	local v3771 = v3764 + 0.34
	local v3772 = v_u_8(v3768 - v3767, v3766 - v3771, 0.12)
	local v3773 = v_u_9((v3767 + v3768) / 2, (v3771 + v3766) / 2, v3762)
	local v3774 = v_u_2655
	v_u_80(p3761, Instance.new("Part"), v3772, v3773, v3774, nil)
	local v3775 = v3764 - 0.34
	local v3776 = v_u_8(v3768 - v3767, v3775 - v3765, 0.12)
	local v3777 = v_u_9((v3767 + v3768) / 2, (v3765 + v3775) / 2, v3762)
	local v3778 = v_u_2655
	v_u_80(p3761, Instance.new("Part"), v3776, v3777, v3778, nil)
	local v3779 = v3769 + 0.32
	local v3780 = v3764 - 0.34
	local v3781 = v3770 - 0.32
	local v3782 = v3764 + 0.34
	local v3783 = v_u_8(v3781 - v3779, v3782 - v3780, 0.12)
	local v3784 = v_u_9((v3779 + v3781) / 2, (v3780 + v3782) / 2, v3762)
	local v3785 = v_u_2655
	v_u_80(p3761, Instance.new("Part"), v3783, v3784, v3785, nil)
	local v3786 = v3764 - 0.34
	local v3787 = v3769 - 0.32
	local v3788 = v3764 + 0.34
	local v3789 = v_u_8(v3787 - v3767, v3788 - v3786, 0.12)
	local v3790 = v_u_9((v3767 + v3787) / 2, (v3786 + v3788) / 2, v3762)
	local v3791 = v_u_2655
	v_u_80(p3761, Instance.new("Part"), v3789, v3790, v3791, nil)
	local v3792 = v3770 + 0.32
	local v3793 = v3764 - 0.34
	local v3794 = v3764 + 0.34
	local v3795 = v_u_8(v3768 - v3792, v3794 - v3793, 0.12)
	local v3796 = v_u_9((v3792 + v3768) / 2, (v3793 + v3794) / 2, v3762)
	local v3797 = v_u_2655
	v_u_80(p3761, Instance.new("Part"), v3795, v3796, v3797, nil)
	local v3798 = v_u_8(v3768, v3766 - 0.05, v3762)
	local v3799 = v_u_2655
	local v3800 = -(Vector3.new(0.22, 0, 0)).Unit
	local v3801 = (Vector3.new(0, -0.36, 0)).Unit
	local v3802 = CFrame.fromMatrix(v3798 + Vector3.new(0.11, 0, 0) + Vector3.new(0, -0.18, 0), v3801:Cross(v3800), v3801, v3800)
	local v3803 = v_u_8(0.12, (Vector3.new(0, -0.36, 0)).Magnitude, (Vector3.new(0.22, 0, 0)).Magnitude)
	v_u_80(p3761, Instance.new("WedgePart"), v3803, v3802, v3799, nil)
	local v3804 = v_u_8(0.12, v3766 - v3765 - 0.1, 0.04)
	local v3805 = v_u_9((v3767 + v3769 - 0.32) / 2, (v3765 + v3766) / 2, v3762 - 0.07)
	local v3806 = p3761.accent
	v_u_80(p3761, Instance.new("Part"), v3804, v3805, v3806, nil)
	local v3807 = v_u_8(v3769 - 0.15, v3766 - 0.05, v3762 + 0.02)
	local v3808 = v3807 + Vector3.new(-0.18, 0.42, 0.1)
	local v3809 = v_u_2655
	local v3810 = (v3808 - v3807).Unit * 0.24 * 0.4
	local v3811 = v3807 - v3810
	local v3812 = v3808 + v3810
	local v3813 = (v3811 + v3812) / 2
	local v3814 = v_u_8(0.24, 0.24, (v3812 - v3811).Magnitude)
	local v3815 = CFrame.lookAt(v3813, v3812)
	v_u_80(p3761, Instance.new("Part"), v3814, v3815, v3809, nil)
	local v3816 = v3807 + Vector3.new(-0.18, 0.42, 0.1)
	local v3817 = v3807 + Vector3.new(-0.12, 0.72, 0.22)
	local v3818 = v_u_2655
	local v3819 = (v3817 - v3816).Unit * 0.16 * 0.4
	local v3820 = v3816 - v3819
	local v3821 = v3817 + v3819
	local v3822 = (v3820 + v3821) / 2
	local v3823 = v_u_8(0.16, 0.16, (v3821 - v3820).Magnitude)
	local v3824 = CFrame.lookAt(v3822, v3821)
	v_u_80(p3761, Instance.new("Part"), v3823, v3824, v3818, nil)
end
function v_u_926.wolfskull(p3825) -- name: wolfskull
	-- upvalues: (copy) v_u_9, (copy) v_u_2655, (copy) v_u_80, (copy) v_u_8, (copy) v_u_14
	p3825.cur = p3825.byName.Head or p3825.bones[1]
	local v3826 = p3825.face
	local v3827 = p3825.mouthY
	local v3828 = v_u_9(0, v3827 + 0.3, v3826 - 0.27)
	local v3829 = v_u_2655
	v_u_80(p3825, Instance.new("Part"), Vector3.new(1, 0.18, 0.62), v3828, v3829, nil)
	local v3830 = v_u_9(0, v3827 + 0.6, v3826 - 0.04)
	local v3831 = v_u_2655
	v_u_80(p3825, Instance.new("Part"), Vector3.new(0.36, 0.5, 0.1), v3830, v3831, nil)
	local v3832 = v_u_8(-0.42, v3827 + 0.22, v3826 - 0.52)
	local v3833 = v_u_14
	local v3834 = -(Vector3.new(0.12, 0, 0)).Unit
	local v3835 = (Vector3.new(0, -0.3, 0)).Unit
	local v3836 = CFrame.fromMatrix(v3832 + Vector3.new(0.06, 0, 0) + Vector3.new(0, -0.15, 0), v3835:Cross(v3834), v3835, v3834)
	local v3837 = v_u_8(0.06, (Vector3.new(0, -0.3, 0)).Magnitude, (Vector3.new(0.12, 0, 0)).Magnitude)
	v_u_80(p3825, Instance.new("WedgePart"), v3837, v3836, v3833, nil)
	local v3838 = v_u_8(0.42, v3827 + 0.22, v3826 - 0.52)
	local v3839 = v_u_14
	local v3840 = -(Vector3.new(-0.12, 0, 0)).Unit
	local v3841 = (Vector3.new(0, -0.3, 0)).Unit
	local v3842 = CFrame.fromMatrix(v3838 + Vector3.new(-0.06, 0, 0) + Vector3.new(0, -0.15, 0), v3841:Cross(v3840), v3841, v3840)
	local v3843 = v_u_8(0.06, (Vector3.new(0, -0.3, 0)).Magnitude, (Vector3.new(-0.12, 0, 0)).Magnitude)
	v_u_80(p3825, Instance.new("WedgePart"), v3843, v3842, v3839, nil)
end
function v_u_926.maskbrows(p3844) -- name: maskbrows
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_80
	p3844.cur = p3844.byName.Head or p3844.bones[1]
	for v3845 = -1, 1, 2 do
		local v3846 = v_u_9(v3845 * (p3844.eyeX + 0.02), p3844.eyeY + 0.47, p3844.face - 0.02) * v_u_10(0, 0, v3845 * 0.35)
		local v3847 = p3844.accent
		v_u_80(p3844, Instance.new("Part"), Vector3.new(0.5, 0.12, 0.04), v3846, v3847, nil)
	end
end
function v_u_926.maskchevron(p3848) -- name: maskchevron
	-- upvalues: (copy) v_u_8, (copy) v_u_80
	p3848.cur = p3848.byName.Head or p3848.bones[1]
	local v3849 = p3848.eyeY + 0.5
	local v3850 = p3848.headC.Y + p3848.headS.Y / 2 - 0.15
	local v3851 = math.min(v3849, v3850)
	for v3852 = -1, 1, 2 do
		local v3853 = v_u_8(v3852 * 0.45, v3851 + 0.18, p3848.face - 0.02)
		local v3854 = v_u_8(0, v3851 - 0.12, p3848.face - 0.02)
		local v3855 = p3848.accent
		local v3856 = (v3853 + v3854) / 2
		local v3857 = v_u_8(0.12, 0.12, (v3854 - v3853).Magnitude)
		local v3858 = CFrame.lookAt(v3856, v3854)
		v_u_80(p3848, Instance.new("Part"), v3857, v3858, v3855, nil)
	end
end
function v_u_926.arrancarcoat(p3859) -- name: arrancarcoat
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_8, (copy) v_u_13
	p3859.cur = p3859.byName.Body or p3859.bones[1]
	local v3860 = p3859.bodyC
	local v3861 = p3859.bodyS
	local v3862 = v3861 + Vector3.new(0.1, 0.06, 0.2)
	local v3863 = v_u_9(v3860 + Vector3.new(0, 0.03, 0))
	local v3864 = p3859.cloth
	v_u_80(p3859, Instance.new("Part"), v3862, v3863, v3864, nil)
	local v3865 = v_u_8(v3861.X + 0.14, 0.12, v3861.Z + 0.24)
	local v3866 = v_u_9(v3860.X, v3860.Y - v3861.Y * 0.18, v3860.Z)
	local v3867 = v_u_13
	v_u_80(p3859, Instance.new("Part"), v3865, v3866, v3867, nil)
	local v3868 = p3859.headC.Z + p3859.headS.Z / 2 + 0.12
	local v3869 = v3860.Y + v3861.Y / 2 + 0.5
	local v3870 = v_u_8(v3861.X + 0.14, 0.62, 0.28)
	local v3871 = v_u_9(0, v3869 - 0.31, v3868)
	local v3872 = p3859.cloth
	v_u_80(p3859, Instance.new("Part"), v3870, v3871, v3872, nil)
	local v3873 = v_u_8(v3861.X + 0.16, 0.08, 0.3)
	local v3874 = v_u_9(0, v3869, v3868)
	local v3875 = v_u_13
	v_u_80(p3859, Instance.new("Part"), v3873, v3874, v3875, nil)
end
function v_u_926.jawmask(p3876) -- name: jawmask
	-- upvalues: (copy) v_u_9, (copy) v_u_10, (copy) v_u_2655, (copy) v_u_80, (copy) v_u_8, (copy) v_u_14
	p3876.cur = p3876.byName.Head or p3876.bones[1]
	local v3877 = p3876.face
	local v3878 = p3876.eyeX + 0.12
	local v3879 = v_u_9(v3878, p3876.mouthY - 0.06, v3877 - 0.12) * v_u_10(0, 0, 0.12)
	local v3880 = v_u_2655
	v_u_80(p3876, Instance.new("Part"), Vector3.new(0.95, 0.32, 0.5), v3879, v3880, nil)
	for v3881 = 0, 3 do
		local v3882 = v_u_8(v3878 - 0.4 + v3881 * 0.22, p3876.mouthY + 0.02 + v3881 * 0.025, v3877 - 0.38)
		local v3883 = v_u_14
		local v3884 = -(Vector3.new(0.14, 0, 0)).Unit
		local v3885 = (Vector3.new(0, 0.2, 0)).Unit
		local v3886 = CFrame.fromMatrix(v3882 + Vector3.new(0.07, 0, 0) + Vector3.new(0, 0.1, 0), v3885:Cross(v3884), v3885, v3884)
		local v3887 = v_u_8(0.06, (Vector3.new(0, 0.2, 0)).Magnitude, (Vector3.new(0.14, 0, 0)).Magnitude)
		v_u_80(p3876, Instance.new("WedgePart"), v3887, v3886, v3883, nil)
	end
end
function v_u_926.pantheramarks(p3888) -- name: pantheramarks
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p3888.cur = p3888.byName.Head or p3888.bones[1]
	for v3889 = -1, 1, 2 do
		local v3890 = v_u_8(v3889 * (p3888.eyeX + 0.22), p3888.eyeY - 0.02, p3888.face - 0.03)
		local v3891 = v_u_8(v3889 * (p3888.eyeX + 0.44), p3888.eyeY - 0.36, p3888.face - 0.03)
		local v3892 = p3888.glow
		local v3893 = v_u_12
		local v3894 = (v3890 + v3891) / 2
		local v3895 = v_u_8(0.1, 0.1, (v3891 - v3890).Magnitude)
		local v3896 = CFrame.lookAt(v3894, v3891)
		v_u_80(p3888, Instance.new("Part"), v3895, v3896, v3892, v3893)
	end
end
function v_u_926.bluemane(p3897) -- name: bluemane
	-- upvalues: (copy) v_u_124, (copy) v_u_8
	p3897.cur = p3897.byName.Head or p3897.bones[1]
	local v3898 = p3897.headC.Y + p3897.headS.Y / 2 - 0.05
	local v3899 = p3897.headC.Z - p3897.headS.Z * 0.15
	for v3900 = -1, 1 do
		local v3901 = v3900 * 0.3
		v_u_124(p3897, v_u_8(v3901 - 0.22, v3898, v3899 - 0.2), v_u_8(v3901 + 0.22, v3898, v3899 - 0.2), v_u_8(v3901 * 1.4, v3898 + 0.55 - math.abs(v3900) * 0.12, v3899 + 0.45), 0.28, p3897.cloth)
	end
end
function v_u_926.pawclaws(p3902) -- name: pawclaws
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_80
	for v3903 = 1, 2 do
		local v3904 = p3902.byName["Leg" .. v3903]
		if not v3904 then
			continue
		end
		local v3905 = v3904.name
		p3902.cur = p3902.byName[v3905] or p3902.bones[1]
		local v3906 = v_u_8(v3904.hinge.X, 0.06, v3904.hinge.Z - 0.27)
		for v3907 = -1, 1 do
			local v3908 = v_u_9(v3906 + v_u_8(v3907 * 0.14, 0, -0.04))
			local v3909 = p3902.glow
			local v3910 = v_u_12
			v_u_80(p3902, Instance.new("Part"), Vector3.new(0.08, 0.12, 0.16), v3908, v3909, v3910)
		end
	end
end
local function v_u_3924(p3911, p3912, p3913, p3914, p3915, p3916) -- name: crystal
	-- upvalues: (copy) v_u_3252, (copy) v_u_12, (copy) v_u_9, (copy) v_u_10, (copy) v_u_8, (copy) v_u_80
	local v3917
	if p3916 then
		v3917 = p3911.glow
	else
		v3917 = v_u_3252
	end
	local v3918
	if p3916 then
		v3918 = v_u_12
	else
		v3918 = nil
	end
	local v3919 = v_u_9(p3912) * p3915 * v_u_10(0, 0.7853981633974483, 0)
	local v3920 = v_u_8(p3914, p3913, p3914)
	local v3921 = v3919 * v_u_9(0, p3913 / 2, 0)
	v_u_80(p3911, Instance.new("Part"), v3920, v3921, v3917, v3918)
	local v3922 = v_u_8(p3914, p3914, p3914) * 0.72
	local v3923 = v3919 * v_u_9(0, p3913, 0) * v_u_10(0.6155, 0, 0.7853981633974483)
	v_u_80(p3911, Instance.new("Part"), v3922, v3923, v3917, v3918)
end
function v_u_926.quartz(p3925) -- name: quartz
	-- upvalues: (copy) v_u_3924, (copy) v_u_8, (copy) v_u_10
	p3925.cur = p3925.byName.Body or p3925.bones[1]
	local v3926 = p3925.bodyC
	local v3927 = p3925.bodyS
	local v3928 = v3926.Y + v3927.Y / 2 - 0.05
	v_u_3924(p3925, v_u_8(0.1, v3928, v3926.Z - 0.35), 1.15, 0.38, v_u_10(-0.25, 0, 0.2), true)
	v_u_3924(p3925, v_u_8(-0.25, v3928, v3926.Z + 0.15), 0.9, 0.34, v_u_10(0.1, 0, -0.35), false)
	v_u_3924(p3925, v_u_8(0.25, v3928, v3926.Z + 0.6), 0.75, 0.3, v_u_10(0.35, 0, 0.3), true)
	p3925.cur = p3925.byName.Head or p3925.bones[1]
	v_u_3924(p3925, v_u_8(0, p3925.headC.Y + p3925.headS.Y / 2 - 0.05, p3925.headC.Z + 0.2), 0.5, 0.24, v_u_10(0.3, 0, 0), false)
end
function v_u_926.batfringe(p3929) -- name: batfringe
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_80, (copy) v_u_124
	p3929.cur = p3929.byName.Head or p3929.bones[1]
	local v3930 = p3929.headC.Y + p3929.headS.Y / 2
	local v3931 = p3929.limbs
	local v3932 = v_u_8(p3929.headS.X + 0.08, 0.32, p3929.headS.Z * 0.85)
	local v3933 = v_u_9(0, v3930 + 0.1, p3929.headC.Z + p3929.headS.Z * 0.08)
	v_u_80(p3929, Instance.new("Part"), v3932, v3933, v3931, nil)
	local v3934 = p3929.face - 0.04
	for v3935 = -2, 1 do
		local v3936 = v3935 * 0.42 + 0.21
		v_u_124(p3929, v_u_8(v3936 - 0.22, v3930 + 0.05, v3934), v_u_8(v3936 + 0.22, v3930 + 0.05, v3934), v_u_8(v3936 + v3935 * 0.05, v3930 - 0.42 - ((v3935 == -1 or v3935 == 0) and 0.12 or 0), v3934 - 0.02), 0.12, v3931)
	end
end
function v_u_926.ulquihelmet(p3937) -- name: ulquihelmet
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_2655, (copy) v_u_80
	p3937.cur = p3937.byName.Head or p3937.bones[1]
	local v3938 = p3937.headC.Y + p3937.headS.Y / 2 + 0.22
	local v3939 = -p3937.headS.X * 0.24
	local v3940 = v_u_8(p3937.headS.X * 0.56, 0.28, p3937.headS.Z * 0.9)
	local v3941 = v_u_9(v3939, v3938 + 0.08, p3937.headC.Z)
	local v3942 = v_u_2655
	v_u_80(p3937, Instance.new("Part"), v3940, v3941, v3942, nil)
	local v3943 = v_u_8(v3939 - 0.18, v3938 + 0.15, p3937.headC.Z - 0.1)
	local v3944 = v3943 + Vector3.new(-0.22, 0.5, 0.05)
	local v3945 = v3944 + Vector3.new(0.02, 0.42, 0.18)
	local v3946 = v_u_2655
	local v3947 = (v3944 - v3943).Unit * 0.3 * 0.4
	local v3948 = v3943 - v3947
	local v3949 = v3944 + v3947
	local v3950 = (v3948 + v3949) / 2
	local v3951 = v_u_8(0.3, 0.3, (v3949 - v3948).Magnitude)
	local v3952 = CFrame.lookAt(v3950, v3949)
	v_u_80(p3937, Instance.new("Part"), v3951, v3952, v3946, nil)
	local v3953 = v_u_2655
	local v3954 = (v3945 - v3944).Unit * 0.2 * 0.4
	local v3955 = v3944 - v3954
	local v3956 = v3945 + v3954
	local v3957 = (v3955 + v3956) / 2
	local v3958 = v_u_8(0.2, 0.2, (v3956 - v3955).Magnitude)
	local v3959 = CFrame.lookAt(v3957, v3956)
	v_u_80(p3937, Instance.new("Part"), v3958, v3959, v3953, nil)
end
function v_u_926.tearlines(p3960) -- name: tearlines
	-- upvalues: (copy) v_u_9, (copy) v_u_12, (copy) v_u_80
	p3960.cur = p3960.byName.Head or p3960.bones[1]
	for v3961 = -1, 1, 2 do
		local v3962 = v_u_9(v3961 * p3960.eyeX, p3960.eyeY - 0.6, p3960.face - 0.03)
		local v3963 = p3960.glow
		local v3964 = v_u_12
		v_u_80(p3960, Instance.new("Part"), Vector3.new(0.1, 0.55, 0.05), v3962, v3963, v3964)
	end
end
function v_u_926.quincycross(p3965) -- name: quincycross
	-- upvalues: (copy) v_u_8, (copy) v_u_12, (copy) v_u_80
	p3965.cur = p3965.byName.Body or p3965.bones[1]
	local v3966 = v_u_8(0, p3965.bodyC.Y - 0.08, p3965.bodyC.Z - p3965.bodyS.Z / 2 - 0.1)
	local v3967 = {}
	for v3968 = 0, 4 do
		local v3969 = 1.5707963267948966 + v3968 * 3.141592653589793 * 2 / 5
		local v3970 = v3966 + v_u_8(math.cos(v3969) * 0.44, math.sin(v3969) * 0.44, 0)
		table.insert(v3967, v3970)
	end
	for v3971 = 1, 5 do
		local v3972 = v3967[v3971]
		local v3973 = v3967[(v3971 + 1) % 5 + 1]
		local v3974 = p3965.glow
		local v3975 = v_u_12
		local v3976 = (v3972 + v3973) / 2
		local v3977 = v_u_8(0.07, 0.07, (v3973 - v3972).Magnitude)
		local v3978 = CFrame.lookAt(v3976, v3973)
		v_u_80(p3965, Instance.new("Part"), v3977, v3978, v3974, v3975)
	end
	for v3979 = 0, 9 do
		local v3980 = v3979 * 3.141592653589793 / 5
		local v3981 = (v3979 + 1) * 3.141592653589793 / 5
		local v3982 = v3966 + v_u_8(math.cos(v3980) * 0.52, math.sin(v3980) * 0.52, 0)
		local v3983 = v3966 + v_u_8(math.cos(v3981) * 0.52, math.sin(v3981) * 0.52, 0)
		local v3984 = p3965.glow
		local v3985 = v_u_12
		local v3986 = (v3982 + v3983) / 2
		local v3987 = v_u_8(0.07, 0.07, (v3983 - v3982).Magnitude)
		local v3988 = CFrame.lookAt(v3986, v3983)
		v_u_80(p3965, Instance.new("Part"), v3987, v3988, v3984, v3985)
	end
end
function v_u_926.goldcrest(p3989) -- name: goldcrest
	-- upvalues: (copy) v_u_18, (copy) v_u_8, (copy) v_u_80
	p3989.cur = p3989.byName.Head or p3989.bones[1]
	local v3990 = p3989.headC.Y + p3989.headS.Y / 2
	local v3991
	if p3989.look.beak then
		local v3992 = p3989.look.beak
		v3991 = Color3.fromHex(v3992)
	else
		v3991 = v_u_18
	end
	for v3993 = -1, 1 do
		local v3994 = v_u_8(v3993 * 0.32, v3990 - 0.1, p3989.headC.Z + 0.15)
		local v3995 = v_u_8(0, 0, 0.85 - math.abs(v3993) * 0.2)
		local v3996 = v_u_8(v3993 * 0.12, 0.5 - math.abs(v3993) * 0.12, 0)
		local v3997 = -v3995.Unit
		local v3998 = v3996.Unit
		local v3999 = CFrame.fromMatrix(v3994 + v3995 / 2 + v3996 / 2, v3998:Cross(v3997), v3998, v3997)
		local v4000 = v_u_8(0.12, v3996.Magnitude, v3995.Magnitude)
		v_u_80(p3989, Instance.new("WedgePart"), v4000, v3999, v3991, nil)
	end
end
local function v_u_4018(p4001) -- name: meshify
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v4002 = v_u_1:FindFirstChild("PetMeshes")
	if v4002 then
		v4002 = v4002:FindFirstChild(p4001.kind)
	end
	if v4002 then
		local v4003 = v_u_2.byId[p4001.kind]
		local v4004 = p4001.s / (v4003 and v4003.look.size or 1)
		local v4005 = {}
		for _, v4006 in v4002:GetChildren() do
			local v4007 = v4006:GetAttribute("Bone")
			if not v4006:IsA("MeshPart") or type(v4007) ~= "string" then
				continue
			end
			local v4008 = v4005[v4007]
			if not v4008 then
				v4008 = {}
				v4005[v4007] = v4008
			end
			table.insert(v4008, v4006)
		end
		for _, v4009 in p4001.bones do
			local v4010 = v4005[v4009.name]
			if not v4010 then
				continue
			end
			table.sort(v4010, function(p4011, p4012)
				local v4013 = p4011:GetAttribute("Group") == "main"
				if v4013 == (p4012:GetAttribute("Group") == "main") then
					return p4011.Name < p4012.Name
				else
					return v4013
				end
			end)
			for _, v4014 in v4009.parts do
				v4014:Destroy()
			end
			local v4015 = {}
			for _, v4016 in v4010 do
				local v4017 = v4016:Clone()
				v4017.Size = v4016.Size * v4004
				v4017.CFrame = v4016.CFrame.Rotation + v4016.CFrame.Position * v4004
				v4017.Anchored = true
				v4017.Parent = p4001.model
				table.insert(v4015, v4017)
			end
			v4009.parts = v4015
		end
	end
end
local function v_u_4031(p4019, p4020) -- name: finish
	-- upvalues: (copy) v_u_4018, (copy) v_u_9
	v_u_4018(p4019)
	local v4021 = p4019.bones[1].parts[1]
	v4021.Name = "Body"
	p4019.model.PrimaryPart = v4021
	v4021.PivotOffset = v4021.CFrame:Inverse()
	if not p4020 then
		return p4019.model
	end
	for _, v4022 in p4019.bones do
		local v4023 = v4022.parts[1]
		if not v4023 then
			continue
		end
		if v4023 ~= v4021 then
			v4023.Name = v4022.name
		end
		for v4024, v4025 in v4022.parts do
			if v4025 == v4021 then
				continue
			end
			v4025.Anchored = false
			if v4024 <= 1 then
				continue
			end
			local v4026 = Instance.new("Weld")
			v4026.Part0 = v4023
			v4026.Part1 = v4025
			v4026.C0 = v4023.CFrame:ToObjectSpace(v4025.CFrame)
			v4026.Parent = v4025
		end
		if v4022 == p4019.bones[1] then
			break
		end
		local v4027
		if v4022.parent then
			v4027 = p4019.byName[v4022.parent]
		else
			v4027 = nil
		end
		local v4028
		if v4027 then
			v4028 = v4027.parts[1] or v4021
		else
			v4028 = v4021
		end
		local v4029 = v_u_9(v4022.hinge * p4019.s)
		local v4030 = Instance.new("Motor6D")
		v4030.Name = v4022.name
		v4030.Part0 = v4028
		v4030.Part1 = v4023
		v4030.C0 = v4028.CFrame:ToObjectSpace(v4029)
		v4030.C1 = v4023.CFrame:ToObjectSpace(v4029)
		v4030:SetAttribute("Anim", v4022.anim)
		v4030:SetAttribute("Phase", v4022.phase)
		v4030:SetAttribute("Side", v4022.side)
		v4030.Parent = v4023
	end
	return p4019.model
end
function v_u_7.build(p4032, p4033, p4034) -- name: build
	-- upvalues: (copy) v_u_2, (copy) v_u_62, (copy) v_u_925, (copy) v_u_366, (copy) v_u_926, (copy) v_u_927, (copy) v_u_4031, (copy) v_u_47
	local v4035 = v_u_2.byId[p4032]
	if not v4035 then
		return nil
	end
	local v4036 = v4035.look
	local v4037 = v4036.shape or "quad"
	local v4038 = v_u_62(v4036, v4035.name, (p4033 or 1) * (v4036.size or 1))
	v4038.kind = p4032;
	(v_u_925[v4037] or v_u_366)(v4038)
	for _, v4039 in v4036.gear or {} do
		local v4040 = v_u_926[v4039]
		if v4040 then
			v4040(v4038)
		else
			if v_u_927[v4039] then
				continue
			end
			v_u_927[v4039] = true
			warn((("PetModels: %* has unknown gear \"%*\" (see Config/Pets)"):format(p4032, v4039)))
		end
	end
	local v4041 = v_u_4031(v4038, p4034 == true)
	local v4042 = v_u_47[v4037]
	v4041:SetAttribute("Scale", v4038.s)
	v4041:SetAttribute("Fly", v4036.fly == true)
	v4041:SetAttribute("Hop", not v4042 and 0 or v4042[1])
	v4041:SetAttribute("HopRate", not v4042 and 0 or v4042[2])
	v4041:SetAttribute("Slither", v4037 == "serpent")
	return v4041
end
local function v_u_4048(p4043, p4044, p4045) -- name: emitter
	-- upvalues: (copy) v_u_1
	local v4046 = v_u_1:FindFirstChild("Fx")
	if v4046 then
		v4046 = v4046:FindFirstChild(p4043)
	end
	if v4046 then
		v4046 = v4046:FindFirstChild(p4044)
	end
	if not (v4046 and v4046:IsA("ParticleEmitter")) then
		return nil
	end
	local v4047 = v4046:Clone()
	v4047.Enabled = true
	if p4045:IsA("BasePart") then
		v4047.Shape = Enum.ParticleEmitterShape.Box
		v4047.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
		v4047.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	end
	v4047.Parent = p4045
	return v4047
end
local function v_u_4052(p4049, p4050, p4051) -- name: curve
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p4049), NumberSequenceKeypoint.new(0.35, p4050), NumberSequenceKeypoint.new(1, p4051) })
end
local function v4056(p4053, p4054, p4055) -- name: shades
	-- upvalues: (copy) v_u_49
	return ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_49(p4053)), ColorSequenceKeypoint.new(0.45, v_u_49(p4054)), ColorSequenceKeypoint.new(1, v_u_49(p4055)) })
end
local v_u_4057 = {
	["blood"] = {
		["flame"] = nil,
		["flameGlow"] = 0.3,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FF5A6A", "#E3122E", "#A0001E"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#FF7A86"), v_u_49("#B0001C")),
		["stars"] = ColorSequence.new(v_u_14, v_u_49("#FF2A3A")),
		["light"] = v_u_49("#FF2A3A")
	},
	["hellfire"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFD23A", "#FF4A14", "#B0200C"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#FFC23A"), v_u_49("#FF3A0A")),
		["stars"] = ColorSequence.new(v_u_49("#FFE08A"), v_u_49("#FF5A1A")),
		["light"] = v_u_49("#FF6A1A")
	},
	["frost"] = {
		["flame"] = nil,
		["flameGlow"] = 0.3,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["starTexture"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFFFFF", "#9FE8FF", "#3A8BFF"),
		["motes"] = { "Petals", "Motes" },
		["moteColor"] = ColorSequence.new(v_u_14, v_u_49("#9FE8FF")),
		["stars"] = ColorSequence.new(v_u_14, v_u_49("#7FDBFF")),
		["starTexture"] = v_u_4.Snowflake,
		["light"] = v_u_49("#9FE8FF")
	},
	["abyss"] = {
		["flame"] = nil,
		["flameGlow"] = 0.3,
		["motes"] = nil,
		["moteColor"] = nil,
		["moteBubbles"] = true,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#7FFFF0", "#2FB8FF", "#3A1A9A"),
		["motes"] = { "Petals", "Motes" },
		["moteColor"] = ColorSequence.new(v_u_49("#CFFFFA"), v_u_49("#6FD8FF")),
		["stars"] = ColorSequence.new(v_u_14, v_u_49("#3BE0FF")),
		["light"] = v_u_49("#3BE0FF")
	},
	["cosmic"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["moteTexture"] = nil,
		["stars"] = nil,
		["starTexture"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFA8F0", "#9B5CFF", "#2E2AA0"),
		["motes"] = { "Petals", "Motes" },
		["moteColor"] = ColorSequence.new(v_u_14, v_u_49("#8FF2FF")),
		["moteTexture"] = v_u_4.PetStar,
		["stars"] = ColorSequence.new(v_u_49("#FFB8F2"), v_u_49("#7FE9FF")),
		["starTexture"] = v_u_4.PolarStar,
		["light"] = v_u_49("#B07BFF")
	},
	["aegis"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFF2B0", "#FFC23A", "#FF5A0A"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#FFE08A"), v_u_49("#FF7A1A")),
		["stars"] = ColorSequence.new(v_u_49("#FFF2B0"), v_u_49("#FFC23A")),
		["light"] = v_u_49("#FFB21F")
	},
	["royal"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["moteTexture"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFF4C2", "#FFC93C", "#9B3BFF"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#E6C2FF"), v_u_49("#8A2BE2")),
		["moteTexture"] = v_u_4.PetStar,
		["stars"] = ColorSequence.new(v_u_49("#FFFFFF"), v_u_49("#FFD23C")),
		["light"] = v_u_49("#FFC93C")
	},
	["shadow"] = {
		["flame"] = nil,
		["flameGlow"] = 0.25,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FF3A4A", "#9B1AE0", "#2A0A3A"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#D45BFF"), v_u_49("#FF1A3A")),
		["stars"] = ColorSequence.new(v_u_49("#FF5A6A"), v_u_49("#A62BFF")),
		["light"] = v_u_49("#B01CFF")
	},
	["glacier"] = {
		["flame"] = nil,
		["flameGlow"] = 0.3,
		["motes"] = nil,
		["moteColor"] = nil,
		["moteTexture"] = nil,
		["stars"] = nil,
		["starTexture"] = nil,
		["light"] = nil,
		["flame"] = v4056("#F2FFFF", "#6FF0E8", "#1E86E0"),
		["motes"] = { "Petals", "Motes" },
		["moteColor"] = ColorSequence.new(v_u_14, v_u_49("#8FF6FF")),
		["moteTexture"] = v_u_4.Snowflake,
		["stars"] = ColorSequence.new(v_u_14, v_u_49("#5FF0E8")),
		["starTexture"] = v_u_4.PolarStar,
		["light"] = v_u_49("#7FF0FF")
	},
	["blaze"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FFF6B0", "#FF9A1F", "#E3261A"),
		["motes"] = { "Fire", "Embers" },
		["moteColor"] = ColorSequence.new(v_u_49("#FFE28A"), v_u_49("#FF4A1A")),
		["stars"] = ColorSequence.new(v_u_49("#FFF2B0"), v_u_49("#FF7A1A")),
		["light"] = v_u_49("#FF7A1A")
	},
	["menos"] = {
		["flame"] = nil,
		["flameGlow"] = 0.25,
		["motes"] = nil,
		["moteColor"] = nil,
		["stars"] = nil,
		["light"] = nil,
		["flame"] = v4056("#FF4A4A", "#C0102A", "#3A0510"),
		["motes"] = { "Aura", "Sparks" },
		["moteColor"] = ColorSequence.new(v_u_49("#FF9A9A"), v_u_49("#E0102A")),
		["stars"] = ColorSequence.new(v_u_49("#FFD6D6"), v_u_49("#FF2A3A")),
		["light"] = v_u_49("#FF2A3A")
	},
	["quincy"] = {
		["flame"] = nil,
		["flameGlow"] = 0.35,
		["motes"] = nil,
		["moteColor"] = nil,
		["moteTexture"] = nil,
		["stars"] = nil,
		["starTexture"] = nil,
		["light"] = nil,
		["flame"] = v4056("#F2FAFF", "#6FD0FF", "#2A5BE0"),
		["motes"] = { "Petals", "Motes" },
		["moteColor"] = ColorSequence.new(v_u_14, v_u_49("#6FD0FF")),
		["moteTexture"] = v_u_4.PetStar,
		["stars"] = ColorSequence.new(v_u_49("#FFF2B0"), v_u_49("#FFC83A")),
		["starTexture"] = v_u_4.PolarStar,
		["light"] = v_u_49("#7FD8FF")
	}
}
local function v_u_4079(p4058, p4059) -- name: eyeSpots
	local v4060 = p4058:GetPivot()
	local v4061 = {}
	for _, v4062 in p4058:GetDescendants() do
		if not v4062:IsA("BasePart") or v4062.Material ~= Enum.Material.Neon then
			continue
		end
		local v4063 = v4062.Color
		local v4064 = v4063.R - p4059.R
		local v4065 = math.abs(v4064)
		local v4066 = v4063.G - p4059.G
		local v4067 = v4065 + math.abs(v4066)
		local v4068 = v4063.B - p4059.B
		if v4067 + math.abs(v4068) > 0.06 then
			continue
		end
		local v4069 = v4062.Size
		local v4070 = v4060.LookVector * (v4069.Z * 0.5 + 0.05)
		local v4071 = v4069.X
		local v4072 = v4069.Z
		local v4073 = math.max(v4071, v4072)
		if v4069.Y * 2 < v4073 then
			local v4074 = v4073 * 0.5 - v4069.Y * 0.4
			for v4075 = -1, 1, 2 do
				local v4076 = v4062.Position + v4060.RightVector * v4074 * v4075 + v4070
				local v4077 = {
					["part"] = v4062,
					["at"] = v4062.CFrame:PointToObjectSpace(v4076)
				}
				table.insert(v4061, v4077)
			end
		else
			local v4078 = {
				["part"] = v4062,
				["at"] = v4062.CFrame:PointToObjectSpace(v4062.Position + v4070)
			}
			table.insert(v4061, v4078)
		end
	end
	return v4061
end
local function v_u_4100(p4080, p4081, p4082, p4083) -- name: shadowAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_49, (copy) v_u_4052, (copy) v_u_8, (copy) v_u_4079
	local v4084 = v_u_5.formRate()
	local v4085 = v_u_5.level() >= 2
	local v4086 = Color3.fromHex("#B03BFF")
	local v4087 = Color3.fromHex("#FF2A4A")
	for _, v4088 in p4080:GetDescendants() do
		if not v4088:IsA("ParticleEmitter") or v4088.Name ~= "FlameBack" then
			continue
		end
		v4088.Texture = v_u_4.ShadowFlame
		v4088.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v4088.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v4088.FlipbookStartRandom = false
		v4088.Color = ColorSequence.new(Color3.fromHex("#8A2BE2"), v_u_49("#E0103A"))
		v4088.LightEmission = 0
		v4088.LightInfluence = 0
		v4088.Brightness = 1.4
		v4088.Size = v_u_4052(p4082 * 1.25, p4082 * 1.45, p4082 * 0.8)
		v4088.Lifetime = NumberRange.new(0.5, 0.7)
		v4088.Rotation = NumberRange.new(-12, 12)
		v4088.RotSpeed = NumberRange.new(0, 0)
	end
	local v4089 = Instance.new("ParticleEmitter")
	v4089.Name = "Wisps"
	v4089.Texture = v_u_4.ShadowWisp
	v4089.Rate = 2.2 * v4084
	v4089.Lifetime = NumberRange.new(1.1, 1.6)
	v4089.Size = v_u_4052(p4082 * 0.32, p4082 * 0.42, 0)
	v4089.Transparency = v_u_4052(0.1, 0.15, 1)
	v4089.Speed = NumberRange.new(p4082 * 0.6, p4082 * 1.2)
	v4089.SpreadAngle = Vector2.new(40, 40)
	v4089.EmissionDirection = Enum.NormalId.Top
	v4089.Acceleration = v_u_8(0, p4082 * 0.9, 0)
	v4089.Rotation = NumberRange.new(-15, 15)
	v4089.RotSpeed = NumberRange.new(-40, 40)
	v4089.Color = ColorSequence.new(Color3.fromHex("#D46BFF"), v4087)
	v4089.LightEmission = 0.55
	v4089.LightInfluence = 0
	v4089.Brightness = 1.5
	v4089.Shape = Enum.ParticleEmitterShape.Box
	v4089.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	v4089.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	v4089.Parent = p4081
	for v4090, v4091 in v_u_4079(p4080, (Color3.fromHex(p4083 or "#FF1A2A"))) do
		local v4092 = Instance.new("Attachment")
		v4092.Name = "EyeGlow" .. v4090
		v4092.Position = v4091.at
		v4092.Parent = v4091.part
		local v4093 = Instance.new("ParticleEmitter")
		v4093.Name = "EyeGlow"
		v4093.Texture = v_u_4.Glow
		v4093.Rate = 5
		v4093.Lifetime = NumberRange.new(0.35, 0.5)
		v4093.Size = v_u_4052(p4082 * 0.36, p4082 * 0.5, p4082 * 0.34)
		v4093.Transparency = v_u_4052(0.25, 0.05, 1)
		v4093.Speed = NumberRange.new(0, 0)
		v4093.Color = ColorSequence.new(v_u_49("#FF3A4A"))
		v4093.LightEmission = 1
		v4093.LightInfluence = 0
		v4093.Brightness = 3
		v4093.ZOffset = 0.3
		v4093.LockedToPart = true
		v4093.Parent = v4092
		if not v4085 then
			continue
		end
		local v4094 = Instance.new("Attachment")
		v4094.Name = "EyeStreakTop" .. v4090
		v4094.Position = v4091.at + v_u_8(0, p4082 * 0.09, 0)
		v4094.Parent = v4091.part
		local v4095 = Instance.new("Attachment")
		v4095.Name = "EyeStreakLow" .. v4090
		v4095.Position = v4091.at - v_u_8(0, p4082 * 0.09, 0)
		v4095.Parent = v4091.part
		local v4096 = Instance.new("Trail")
		v4096.Name = "EyeStreak"
		v4096.Attachment0 = v4094
		v4096.Attachment1 = v4095
		v4096.Color = ColorSequence.new(Color3.fromHex("#FF2A3A"), v4086)
		v4096.Transparency = NumberSequence.new(0.1, 1)
		v4096.Lifetime = 0.28
		v4096.MinLength = 0.05
		v4096.LightEmission = 1
		v4096.LightInfluence = 0
		v4096.Brightness = 2
		v4096.FaceCamera = true
		v4096.Parent = v4091.part
	end
	if v4085 then
		local v4097 = Instance.new("Attachment")
		v4097.Name = "ShadowFeet"
		v4097.Parent = p4081
		v4097.Position = p4081.CFrame:PointToObjectSpace(p4080:GetPivot().Position + Vector3.new(0, 0.12, 0))
		local v4098 = Instance.new("ParticleEmitter")
		v4098.Name = "ShadowPool"
		v4098.Texture = v_u_4.MaelstromVortex
		v4098.Rate = 0.8 * v4084
		v4098.Lifetime = NumberRange.new(2.2)
		v4098.Size = NumberSequence.new(p4082 * 1.7)
		v4098.Transparency = v_u_4052(1, 0.35, 1)
		v4098.Rotation = NumberRange.new(0, 360)
		v4098.RotSpeed = NumberRange.new(-50, -35)
		v4098.Color = ColorSequence.new(v_u_49("#7A1FE0"))
		v4098.LightEmission = 0.35
		v4098.Brightness = 1.3
		v4098.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v4098.EmissionDirection = Enum.NormalId.Top
		v4098.Speed = NumberRange.new(0.02)
		v4098.SpreadAngle = Vector2.zero
		v4098.LockedToPart = true
		v4098.LightInfluence = 0
		v4098.Parent = v4097
		local v4099 = Instance.new("ParticleEmitter")
		v4099.Name = "ShadowRing"
		v4099.Texture = v_u_4.Ring
		v4099.Rate = 0.9 * v4084
		v4099.Lifetime = NumberRange.new(1.4)
		v4099.Size = v_u_4052(p4082 * 0.6, p4082 * 1.8, p4082 * 2.6)
		v4099.Transparency = v_u_4052(0.15, 0.45, 1)
		v4099.Rotation = NumberRange.new(0, 360)
		v4099.Color = ColorSequence.new(v4086)
		v4099.LightEmission = 0.7
		v4099.Brightness = 1.5
		v4099.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v4099.EmissionDirection = Enum.NormalId.Top
		v4099.Speed = NumberRange.new(0.02)
		v4099.SpreadAngle = Vector2.zero
		v4099.LockedToPart = true
		v4099.LightInfluence = 0
		v4099.Parent = v4097
	end
end
local function v_u_4108(p4101, p4102, p4103, p4104, p4105) -- name: feetRing
	-- upvalues: (copy) v_u_4, (copy) v_u_4052
	local v4106 = Instance.new("Attachment")
	v4106.Name = "AuraFeet"
	v4106.Parent = p4102
	v4106.Position = p4102.CFrame:PointToObjectSpace(p4101:GetPivot().Position + Vector3.new(0, 0.12, 0))
	local v4107 = Instance.new("ParticleEmitter")
	v4107.Name = "AuraRing"
	v4107.Texture = v_u_4.Ring
	v4107.Rate = p4105
	v4107.Lifetime = NumberRange.new(1.3)
	v4107.Size = v_u_4052(p4103 * 0.6, p4103 * 1.9, p4103 * 2.7)
	v4107.Transparency = v_u_4052(0.2, 0.45, 1)
	v4107.Rotation = NumberRange.new(0, 360)
	v4107.Color = ColorSequence.new(p4104)
	v4107.LightEmission = 0.7
	v4107.Brightness = 1.4
	v4107.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v4107.EmissionDirection = Enum.NormalId.Top
	v4107.Speed = NumberRange.new(0.02)
	v4107.SpreadAngle = Vector2.zero
	v4107.LockedToPart = true
	v4107.LightInfluence = 0
	v4107.Parent = v4106
end
local function v_u_4114(p4109, p4110, p4111) -- name: glacierAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_4052, (copy) v_u_8, (copy) v_u_14, (copy) v_u_49, (copy) v_u_4108
	local v4112 = v_u_5.formRate()
	local v4113 = Instance.new("ParticleEmitter")
	v4113.Name = "Snow"
	v4113.Texture = v_u_4.Snowflake
	v4113.Rate = 3 * v4112
	v4113.Lifetime = NumberRange.new(1.4, 2)
	v4113.Size = v_u_4052(p4111 * 0.24, p4111 * 0.3, 0)
	v4113.Transparency = v_u_4052(0.1, 0.1, 1)
	v4113.Speed = NumberRange.new(p4111 * 0.2, p4111 * 0.5)
	v4113.SpreadAngle = Vector2.new(60, 60)
	v4113.EmissionDirection = Enum.NormalId.Bottom
	v4113.Acceleration = v_u_8(0, p4111 * -0.5, 0)
	v4113.Rotation = NumberRange.new(0, 360)
	v4113.RotSpeed = NumberRange.new(-60, 60)
	v4113.Color = ColorSequence.new(v_u_14, v_u_49("#9FF4FF"))
	v4113.LightEmission = 0.4
	v4113.LightInfluence = 0
	v4113.Shape = Enum.ParticleEmitterShape.Box
	v4113.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
	v4113.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
	v4113.Parent = p4110
	if v_u_5.level() >= 2 then
		v_u_4108(p4109, p4110, p4111, Color3.fromHex("#7FF0FF"), 0.8 * v4112)
	end
end
local function v_u_4119(p4115, p4116, p4117) -- name: blazeAura
	-- upvalues: (copy) v_u_4, (copy) v_u_14, (copy) v_u_49, (copy) v_u_4052, (copy) v_u_5, (copy) v_u_4108
	for _, v4118 in p4115:GetDescendants() do
		if not v4118:IsA("ParticleEmitter") or v4118.Name ~= "FlameBack" then
			continue
		end
		v4118.Texture = v_u_4.KyubiFoxFlame
		v4118.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v4118.FlipbookMode = Enum.ParticleFlipbookMode.Loop
		v4118.FlipbookStartRandom = true
		v4118.Color = ColorSequence.new(v_u_14, v_u_49("#FFD8A0"))
		v4118.LightEmission = 0.25
		v4118.LightInfluence = 0
		v4118.Size = v_u_4052(p4117 * 1.3, p4117 * 1.5, p4117 * 0.7)
		v4118.Rotation = NumberRange.new(-10, 10)
		v4118.RotSpeed = NumberRange.new(0, 0)
	end
	if v_u_5.level() >= 2 then
		v_u_4108(p4115, p4116, p4117, Color3.fromHex("#FF7A1A"), 0.9 * v_u_5.formRate())
	end
end
local function v_u_4130(p4120, p4121, p4122, p4123, p4124, p4125, p4126, p4127) -- name: feetPicture
	-- upvalues: (copy) v_u_5, (copy) v_u_4052
	local v4128 = Instance.new("Attachment")
	v4128.Name = p4122 .. "Feet"
	v4128.Parent = p4121
	v4128.Position = p4121.CFrame:PointToObjectSpace(p4120:GetPivot().Position + Vector3.new(0, 0.1, 0))
	local v4129 = Instance.new("ParticleEmitter")
	v4129.Name = p4122
	v4129.Texture = p4123
	v4129.Rate = 0.45 * v_u_5.formRate()
	v4129.Lifetime = NumberRange.new(2.4)
	v4129.Size = NumberSequence.new(p4124)
	v4129.Transparency = v_u_4052(1, 0.3, 1)
	v4129.Rotation = NumberRange.new(0, 360)
	v4129.RotSpeed = p4126
	v4129.Color = ColorSequence.new(p4125)
	v4129.LightEmission = p4127
	v4129.Brightness = 1.5
	v4129.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v4129.EmissionDirection = Enum.NormalId.Top
	v4129.Speed = NumberRange.new(0.02)
	v4129.SpreadAngle = Vector2.zero
	v4129.LockedToPart = true
	v4129.LightInfluence = 0
	v4129.Parent = v4128
end
local function v_u_4135(p4131, p4132, p4133) -- name: menosAura
	-- upvalues: (copy) v_u_4, (copy) v_u_49, (copy) v_u_4052, (copy) v_u_5, (copy) v_u_4130, (copy) v_u_4108
	for _, v4134 in p4131:GetDescendants() do
		if not v4134:IsA("ParticleEmitter") or v4134.Name ~= "FlameBack" then
			continue
		end
		v4134.Texture = v_u_4.ShadowFlame
		v4134.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v4134.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v4134.FlipbookStartRandom = false
		v4134.Color = ColorSequence.new(Color3.fromHex("#FF3A3A"), v_u_49("#B0101E"))
		v4134.LightEmission = 0
		v4134.LightInfluence = 0
		v4134.Brightness = 1.4
		v4134.Size = v_u_4052(p4133 * 1.25, p4133 * 1.45, p4133 * 0.8)
		v4134.Lifetime = NumberRange.new(0.5, 0.7)
		v4134.Rotation = NumberRange.new(-12, 12)
		v4134.RotSpeed = NumberRange.new(0, 0)
	end
	if v_u_5.level() >= 2 then
		v_u_4130(p4131, p4132, "MenosVoid", v_u_4.MaelstromVortex, p4133 * 1.9, Color3.fromHex("#A0101E"), NumberRange.new(-50, -35), 0.3)
		v_u_4108(p4131, p4132, p4133, Color3.fromHex("#FF2A3A"), 0.8 * v_u_5.formRate())
	end
end
local function v_u_4139(p4136, p4137, p4138) -- name: quincyAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4130, (copy) v_u_4, (copy) v_u_4108
	if v_u_5.level() >= 2 then
		v_u_4130(p4136, p4137, "QuincyStar", v_u_4.QuincyPentacle, p4138 * 2.3, Color3.fromHex("#8FDCFF"), NumberRange.new(20, 30), 0.8)
		v_u_4108(p4136, p4137, p4138, Color3.fromHex("#6FD0FF"), 0.8 * v_u_5.formRate())
	end
end
local v_u_4140 = {}
function v_u_7.effects(p4141, p4142) -- name: effects
	-- upvalues: (copy) v_u_2, (copy) v_u_46, (copy) v_u_3, (copy) v_u_4057, (copy) v_u_4048, (copy) v_u_4052, (copy) v_u_14, (copy) v_u_8, (copy) v_u_4, (copy) v_u_49, (copy) v_u_45, (copy) v_u_19, (copy) v_u_18, (copy) v_u_33, (copy) v_u_34, (copy) v_u_4100, (copy) v_u_4114, (copy) v_u_4119, (copy) v_u_4135, (copy) v_u_4139, (copy) v_u_4140
	local v4143 = v_u_2.byId[p4142]
	local v4144 = p4141.PrimaryPart
	if v4143 and v4144 then
		local v4145 = v4143.look
		local v4146 = p4141:GetAttribute("Scale")
		local v4147 = type(v4146) ~= "number" and 1 or v4146
		local v4148 = v_u_46[v4143.rarity] or 1
		local v4149 = v4145.glow or (v_u_3.RARITY_COLOR[v4143.rarity] or "#FFFFFF")
		local v4150 = Color3.fromHex(v4149)
		local v4151 = v4145.aura == "rainbow"
		local v4152 = v4145.aura == "flames"
		local v4153
		if v4145.aura then
			v4153 = v_u_4057[v4145.aura]
		else
			v4153 = nil
		end
		local v4154 = v4145.spirit or "#FFFFFF"
		local v4155 = Color3.fromHex(v4154)
		for _, v4156 in { "Orb1", "Orb2" } do
			local v4157 = p4141:FindFirstChild(v4156)
			if not (v4157 and v4157:IsA("BasePart")) then
				continue
			end
			local v4158 = v_u_4048("Trail", "Flames", v4157)
			if not v4158 then
				continue
			end
			v4158.Rate = 7
			v4158.Size = v_u_4052(0.45 * v4147, 0.35 * v4147, 0)
			v4158.Lifetime = NumberRange.new(0.3, 0.45)
			v4158.Speed = NumberRange.new(0.2 * v4147, 0.5 * v4147)
			v4158.Color = ColorSequence.new(v4155, v_u_14)
			v4158.LightEmission = 0.8
		end
		if v4145.embers then
			local v4159 = p4141:FindFirstChild("Head")
			local v4160 = v_u_4048
			local v4161 = "Fire"
			local v4162 = "Embers"
			if v4159 then
				if not v4159:IsA("BasePart") then
					v4159 = v4144
				end
			else
				v4159 = v4144
			end
			local v4163 = v4160(v4161, v4162, v4159)
			local v4164 = v4145.tip or "#FFD23F"
			local v4165 = Color3.fromHex(v4164)
			if v4163 then
				v4163.Rate = 3 + v4148
				v4163.Lifetime = NumberRange.new(0.7, 1.2)
				v4163.Size = v_u_4052(0.55 * v4147, 0.45 * v4147, 0)
				v4163.Speed = NumberRange.new(0.8 * v4147, 1.6 * v4147)
				v4163.EmissionDirection = Enum.NormalId.Top
				v4163.SpreadAngle = Vector2.new(30, 30)
				v4163.Acceleration = v_u_8(0, 1.2 * v4147, 0)
				v4163.Color = ColorSequence.new(v4165, v4150)
				v4163.LightEmission = 0.6
			end
			for _, v4166 in { "Plume1", "Plume2", "Plume3" } do
				local v4167 = p4141:FindFirstChild(v4166)
				if not (v4167 and v4167:IsA("BasePart")) then
					continue
				end
				local v4168 = v_u_4048("Trail", "Flames", v4167)
				if not v4168 then
					continue
				end
				v4168.Rate = 4
				v4168.Size = v_u_4052(0.4 * v4147, 0.3 * v4147, 0)
				v4168.Lifetime = NumberRange.new(0.25, 0.4)
				v4168.Speed = NumberRange.new(0.2 * v4147, 0.5 * v4147)
				v4168.Color = ColorSequence.new(v4165, v4150)
				v4168.LightEmission = 0.6
			end
		end
		if v4145.aura == "royal" then
			local v4169 = p4141:FindFirstChild("Head")
			if v4169 and v4169:IsA("BasePart") then
				local v4170 = Instance.new("Attachment")
				v4170.Name = "CrownGlint"
				v4170.Position = v_u_8(0, v4169.Size.Y * 0.5 + 0.2 * v4147, -v4169.Size.Z * 0.1)
				v4170.Parent = v4169
				local v4171 = v_u_4048("Sparkle", "Stars", v4170)
				if v4171 then
					v4171.Rate = 2.5
					v4171.Lifetime = NumberRange.new(0.35, 0.6)
					v4171.Texture = v_u_4.PolarStar
					v4171.FlipbookLayout = Enum.ParticleFlipbookLayout.None
					v4171.Size = v_u_4052(0, 1.1 * v4147, 0)
					v4171.Speed = NumberRange.new(0, 0)
					v4171.Acceleration = Vector3.new(0, 0, 0)
					v4171.Drag = 0
					v4171.SpreadAngle = Vector2.new(0, 0)
					v4171.Rotation = NumberRange.new(-20, 20)
					v4171.RotSpeed = NumberRange.new(-60, 60)
					v4171.Color = ColorSequence.new(v_u_14, v_u_49("#FFD23C"))
					v4171.LightEmission = 0.6
					v4171.LockedToPart = true
				end
			end
		end
		if v4148 < 2 then
			return
		else
			local v4172 = p4141:FindFirstChild("Head")
			if v4172 then
				if not v4172:IsA("BasePart") then
					v4172 = v4144
				end
			else
				v4172 = v4144
			end
			local v4173 = v_u_4048("Sparkle", "Stars", v4172)
			if v4173 then
				v4173.Rate = 3 + v4148
				v4173.Lifetime = NumberRange.new(0.8, 1.2)
				v4173.Texture = v_u_4.PetStar
				v4173.FlipbookLayout = Enum.ParticleFlipbookLayout.None
				v4173.Rotation = NumberRange.new(-30, 30)
				v4173.RotSpeed = NumberRange.new(-90, 90)
				v4173.Size = v_u_4052(0, 0.75 * v4147, 0)
				v4173.Speed = NumberRange.new(0.3 * v4147, 0.8 * v4147)
				v4173.SpreadAngle = Vector2.new(180, 180)
				v4173.Acceleration = v_u_8(0, 0.8 * v4147, 0)
				v4173.Drag = 0
				v4173.LightEmission = 0.2
				local v4174
				if v4153 then
					v4174 = v4153.stars
				elseif v4151 then
					v4174 = v_u_45
				elseif v4148 == 4 then
					v4174 = ColorSequence.new(v_u_19, v_u_18)
				else
					v4174 = ColorSequence.new(v_u_14, v4150)
				end
				v4173.Color = v4174
				if v4153 and v4153.starTexture then
					v4173.Texture = v4153.starTexture
				end
			end
			if v4148 < 3 then
				return
			else
				local v4175
				if v4153 then
					v4175 = v4153.flame
				elseif v4151 then
					v4175 = v_u_45
				elseif v4152 then
					v4175 = ColorSequence.new(v_u_33, v_u_34)
				elseif v4148 == 4 then
					v4175 = ColorSequence.new(v_u_19, v_u_18)
				else
					v4175 = ColorSequence.new(v4150, v4150:Lerp(Color3.new(0, 0, 0), 0.25))
				end
				local v4176 = v4148 >= 5
				for _, v4177 in { v4144, v4172 } do
					local v4178 = v_u_4048("Aura", "FlameBack", v4177)
					if not v4178 then
						continue
					end
					v4178.Rate = v4176 and 9 or 6
					v4178.Lifetime = NumberRange.new(0.45, 0.7)
					local v4179
					if v4176 then
						v4179 = v_u_4052(2.1 * v4147, 1.8 * v4147, 0.4 * v4147)
					else
						v4179 = v_u_4052(1.7 * v4147, 1.4 * v4147, 0.3 * v4147)
					end
					v4178.Size = v4179
					v4178.Speed = NumberRange.new(1.4 * v4147, 2.4 * v4147)
					v4178.EmissionDirection = Enum.NormalId.Top
					v4178.SpreadAngle = Vector2.new(20, 20)
					v4178.Color = v4175
					local v4180
					if v4153 then
						v4180 = v4153.flameGlow
					else
						v4180 = v4152 and 0.3 or 0.15
					end
					v4178.LightEmission = v4180
				end
				if v4148 < 4 then
					return
				else
					local v4181
					if v4153 then
						v4181 = v4153.motes[1]
					else
						v4181 = v4152 and "Aura" or "Petals"
					end
					local v4182
					if v4153 then
						v4182 = v4153.motes[2]
					else
						v4182 = v4152 and "Sparks" or "Motes"
					end
					local v4183 = v_u_4048(v4181, v4182, v4144)
					if v4183 then
						v4183.Rate = 8
						v4183.Lifetime = NumberRange.new(1, 1.6)
						v4183.Size = v_u_4052(0.55 * v4147, 0.45 * v4147, 0)
						v4183.LightEmission = 0.2
						v4183.Speed = NumberRange.new(0.8 * v4147, 1.6 * v4147)
						v4183.EmissionDirection = Enum.NormalId.Top
						v4183.SpreadAngle = Vector2.new(25, 25)
						v4183.Acceleration = v_u_8(0, 0.6 * v4147, 0)
						local v4184
						if v4153 then
							v4184 = v4153.moteColor
						elseif v4151 then
							v4184 = v_u_45
						elseif v4152 then
							local v4185 = ColorSequence.new
							local v4186 = v4145.tip or "#FFB43A"
							v4184 = v4185(Color3.fromHex(v4186), v4150)
						else
							v4184 = ColorSequence.new(v_u_19, v_u_18)
						end
						v4183.Color = v4184
						if v4153 and v4153.moteBubbles then
							v4183.Texture = v_u_4.TideBubble
							v4183.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
							v4183.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							v4183.Rotation = NumberRange.new(-20, 20)
							v4183.RotSpeed = NumberRange.new(0, 0)
							v4183.Size = v_u_4052(0.3 * v4147, 0.42 * v4147, 0.5 * v4147)
							v4183.Lifetime = NumberRange.new(1.3, 1.9)
							v4183.LightEmission = 0.35
						end
						if v4153 and v4153.moteTexture then
							v4183.Texture = v4153.moteTexture
							v4183.FlipbookLayout = Enum.ParticleFlipbookLayout.None
							v4183.Rotation = NumberRange.new(-30, 30)
							v4183.RotSpeed = NumberRange.new(-70, 70)
							v4183.Size = v_u_4052(0.42 * v4147, 0.34 * v4147, 0)
							v4183.LightEmission = 0.4
						end
					end
					local v4187 = Instance.new("PointLight")
					v4187.Shadows = false
					v4187.Range = v4148 >= 5 and 7 or 6
					v4187.Brightness = v4148 >= 5 and 1 or 0.7
					if v4153 then
						v4150 = v4153.light
					elseif v4151 then
						v4150 = Color3.fromRGB(190, 240, 255)
					elseif v4148 == 4 then
						v4150 = v_u_18
					end
					v4187.Color = v4150
					local v4188 = p4141:FindFirstChild("Pearl")
					if v4188 then
						if not v4188:IsA("BasePart") then
							v4188 = v4144
						end
					else
						v4188 = v4144
					end
					v4187.Parent = v4188
					if v4145.aura == "shadow" then
						v_u_4100(p4141, v4144, v4147, v4145.eye)
						return
					elseif v4145.aura == "glacier" then
						v_u_4114(p4141, v4144, v4147)
						return
					elseif v4145.aura == "blaze" then
						v_u_4119(p4141, v4144, v4147)
						return
					elseif v4145.aura == "menos" then
						v_u_4135(p4141, v4144, v4147)
						return
					elseif v4145.aura == "quincy" then
						v_u_4139(p4141, v4144, v4147)
					elseif v4145.aura and v_u_4140[v4145.aura] then
						v_u_4140[v4145.aura](p4141, v4144, v4147)
					end
				end
			end
		end
	else
		return
	end
end
function v_u_7.rig(p4189) -- name: rig
	local v4190 = p4189.PrimaryPart
	if not v4190 then
		return nil
	end
	local v4191 = {}
	for _, v4192 in p4189:GetDescendants() do
		if not v4192:IsA("Motor6D") then
			continue
		end
		local v4193 = v4192:GetAttribute("Anim")
		local v4194 = v4192:GetAttribute("Phase")
		local v4195 = v4192:GetAttribute("Side")
		local v4196 = {
			["motor"] = v4192,
			["base"] = v4192.C0,
			["anim"] = type(v4193) ~= "string" and "" or v4193,
			["phase"] = type(v4194) ~= "number" and 0 or v4194,
			["side"] = type(v4195) ~= "number" and 0 or v4195
		}
		table.insert(v4191, v4196)
	end
	local v4197 = {
		["model"] = p4189,
		["root"] = v4190,
		["offset"] = p4189:GetPivot():ToObjectSpace(v4190.CFrame),
		["joints"] = v4191
	}
	local v4198 = p4189:GetAttribute("Scale")
	v4197.scale = type(v4198) ~= "number" and 1 or v4198
	v4197.fly = p4189:GetAttribute("Fly") == true
	local v4199 = p4189:GetAttribute("Hop")
	v4197.hop = type(v4199) ~= "number" and 0 or v4199
	local v4200 = p4189:GetAttribute("HopRate")
	v4197.hopRate = type(v4200) ~= "number" and 10 or v4200
	v4197.slither = p4189:GetAttribute("Slither") == true
	return v4197
end
function v_u_7.follower(p4201, p4202) -- name: follower
	-- upvalues: (copy) v_u_7
	local v4203 = v_u_7.build(p4201, p4202, true)
	if not v4203 then
		return nil
	end
	v_u_7.effects(v4203, p4201)
	return v_u_7.rig(v4203)
end
function v_u_7.place(p4204, p4205) -- name: place
	p4204.root.CFrame = p4205 * p4204.offset
end
function v_u_7.animate(p4206, p4207, p4208) -- name: animate
	-- upvalues: (copy) v_u_10, (copy) v_u_9
	local v4209 = p4206.scale
	for _, v4210 in p4206.joints do
		local v4211 = v4210.anim
		local v4212 = v4210.phase
		local v4213
		if v4211 == "head" then
			local v4214 = v_u_10
			local v4215 = p4207 * 1.7 + v4212
			local v4216 = math.sin(v4215) * 0.05
			local v4217 = p4207 * 12
			local v4218 = v4216 + math.sin(v4217) * 0.04 * p4208
			local v4219 = p4207 * 0.8 + v4212
			local v4220 = math.sin(v4219) * 0.12 * (1 - p4208)
			local v4221 = p4207 * 1.3 + v4212
			v4213 = v4214(v4218, v4220, math.sin(v4221) * 0.07)
		elseif v4211 == "tail" then
			local v4222 = p4208 * 6 + 3.5
			local v4223 = v_u_10
			local v4224 = p4207 * v4222 * 0.5 + v4212
			local v4225 = math.sin(v4224) * 0.08
			local v4226 = p4207 * v4222 + v4212
			v4213 = v4223(v4225, math.sin(v4226) * (p4208 * 0.15 + 0.3), 0)
		elseif v4211 == "wing" then
			local v4227
			if p4206.fly then
				v4227 = p4208 * 5 + 6
			else
				v4227 = p4208 * 8 + 2
			end
			local v4228 = p4206.fly and 0.45 or p4208 * 0.3 + 0.12
			local v4229 = v_u_10
			local v4230 = v4210.side
			local v4231 = p4207 * v4227 + v4212
			v4213 = v4229(0, 0, v4230 * math.sin(v4231) * v4228)
		elseif v4211 == "leg" then
			if p4206.fly then
				local v4232 = v_u_10
				local v4233 = p4207 * 3 + v4212
				v4213 = v4232(math.sin(v4233) * 0.15 + -0.35, 0, 0)
			else
				local v4234 = v_u_10
				local v4235 = p4207 * 13 + v4212
				v4213 = v4234(math.sin(v4235) * 0.7 * p4208, 0, 0)
			end
		elseif v4211 == "ear" then
			local v4236 = p4207 * 1.1 + v4212
			local v4237 = math.sin(v4236)
			local v4238 = math.max(0, v4237) ^ 16
			v4213 = v_u_10(-v4238 * 0.35, 0, -v4210.side * v4238 * 0.2)
		elseif v4211 == "flag" then
			local v4239 = v_u_10
			local v4240 = p4207 * 7 + v4212
			local v4241 = math.sin(v4240) * 0.12 - p4208 * 0.45
			local v4242 = p4207 * 4.5 + v4212
			v4213 = v4239(v4241, math.sin(v4242) * 0.18, 0)
		elseif v4211 == "orbit" then
			local v4243 = v_u_9
			local v4244 = p4207 * 2.2 + v4212
			v4213 = v4243(0, math.sin(v4244) * 0.3 * v4209, 0) * v_u_10(0, p4207 * 1.6, 0)
		elseif v4211 == "spin" then
			v4213 = v_u_10(0, p4207 * 1.4, 0)
		elseif v4211 == "tongue" then
			local v4245 = p4207 * 2.4 + v4212
			local v4246 = math.sin(v4245)
			v4213 = v_u_9(0, 0, (1 - math.max(0, v4246) ^ 3) * 0.45 * v4209)
		elseif v4211 == "neck" then
			local v4247 = v_u_10
			local v4248 = p4207 * 1.5 + v4212
			local v4249 = math.sin(v4248) * 0.06
			local v4250 = p4207 * 1.2 + v4212
			local v4251 = math.sin(v4250) * 0.16
			local v4252 = p4207 * 1.9 + v4212
			v4213 = v4247(v4249, v4251, math.sin(v4252) * 0.05)
		elseif v4211 == "batwing" then
			local v4253
			if p4206.fly then
				v4253 = p4208 * 4 + 8
			else
				v4253 = p4208 * 7 + 2
			end
			local v4254 = p4206.fly and 1 or p4208 * 0.6 + 0.25
			local v4255 = p4207 * v4253 + v4212
			local v4256 = math.sin(v4255)
			v4213 = v_u_10(0, v4210.side * v4256 * 0.5 * v4254, v4210.side * v4256 * 0.25 * v4254)
		elseif v4211 == "arm" then
			local v4257 = v_u_10
			local v4258 = p4207 * 2.4 + v4212
			local v4259 = math.sin(v4258) * 0.2 + -0.2 - p4208 * 0.3
			local v4260 = v4210.side
			local v4261 = p4207 * 1.7 + v4212
			v4213 = v4257(v4259, 0, v4260 * (math.sin(v4261) * 0.06 + 0.1))
		elseif v4211 == "scuttle" then
			local v4262 = p4207 * 14 + v4212
			local v4263 = v_u_10
			local v4264 = math.sin(v4262) * 0.32 * p4208
			local v4265 = v4210.side
			local v4266 = math.cos(v4262)
			local v4267 = v4263(0, v4264, v4265 * math.max(0, v4266) * 0.22 * p4208)
			local v4268 = v_u_10
			local v4269 = v4210.side
			local v4270 = p4207 * 2 + v4212
			v4213 = v4267 * v4268(0, 0, v4269 * math.sin(v4270) * 0.03)
		elseif v4211 == "bob" then
			local v4271 = v_u_10
			local v4272 = p4207 * 2.2 + v4212
			local v4273 = math.sin(v4272) * 0.06
			local v4274 = p4207 * 16
			local v4275 = v4273 + math.sin(v4274) * 0.04 * p4208
			local v4276 = p4207 * 1.4 + v4212
			v4213 = v4271(v4275, 0, math.sin(v4276) * 0.05)
		elseif v4211 == "dangle" then
			local v4277 = v_u_10
			local v4278 = p4207 * 1.8 + v4212
			local v4279 = math.sin(v4278) * 0.18 - p4208 * 0.45
			local v4280 = p4207 * 1.5 + v4212
			v4213 = v4277(v4279, 0, math.cos(v4280) * 0.15)
		elseif v4211 == "paddle" then
			local v4281 = p4207 * (p4208 * 2.5 + 2.4) + v4212
			local v4282 = v_u_10
			local v4283 = v4210.side * math.sin(v4281) * 0.3
			local v4284 = v4210.side
			local v4285 = v4281 + 1.2
			v4213 = v4282(0, v4283, v4284 * math.sin(v4285) * 0.32)
		elseif v4211 == "swim" then
			local v4286 = p4207 * (p4208 * 2.5 + 2.2) + v4212
			local v4287 = v_u_10
			local v4288 = v4286 * 0.5 + v4212
			v4213 = v4287(math.sin(v4288) * 0.06, math.sin(v4286) * 0.26, 0)
		elseif v4211 == "lure" then
			local v4289 = v_u_10
			local v4290 = p4207 * 2.2 + v4212
			local v4291 = math.sin(v4290) * 0.12
			local v4292 = p4207 * 1.7 + v4212
			v4213 = v4289(v4291, 0, math.sin(v4292) * 0.1)
		else
			if v4211 ~= "jiggle" then
				continue
			end
			local v4293 = p4207 * (p4208 * 5 + 3) + v4212
			local v4294 = v_u_10
			local v4295 = v4293 * 0.8
			local v4296 = math.sin(v4295) * 0.05
			local v4297 = p4207 * 0.9 + v4212
			v4213 = v4294(v4296, math.sin(v4297) * 0.1, math.sin(v4293) * 0.07)
		end
		v4210.motor.C0 = v4210.base * v4213
	end
end
function v_u_7.showcase(p4298, p4299, p_u_4300, p4301) -- name: showcase
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_5
	local v_u_4302 = v_u_7.follower(p4298, p4299)
	if not v_u_4302 then
		return nil, function() end
	end
	v_u_4302.model.Parent = p4301
	local v_u_4303 = true
	task.spawn(function()
		-- upvalues: (ref) v_u_4303, (copy) v_u_4302, (ref) v_u_7, (copy) p_u_4300, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
		while v_u_4303 and v_u_4302.model.Parent do
			local v4304 = os.clock()
			local v4305
			if v_u_4302.fly then
				local v4306 = v4304 * 2
				v4305 = (math.sin(v4306) * 0.2 + 1.4) * v_u_4302.scale
			else
				v4305 = 0
			end
			local v4307 = v_u_7.place
			local v4308 = v_u_4302
			local v4309 = p_u_4300 * v_u_9(0, v4305, 0)
			local v4310 = v_u_10
			local v4311 = v4304 * 0.5
			v4307(v4308, v4309 * v4310(0, math.sin(v4311) * 0.6, 0))
			v_u_7.animate(v_u_4302, v4304, 0)
			local v4312 = workspace.CurrentCamera
			task.wait(not v4312 and 0.5 or v_u_5.frameGap((v4312.CFrame.Position - p_u_4300.Position).Magnitude))
		end
	end)
	return v_u_4302.model, function()
		-- upvalues: (ref) v_u_4303, (copy) v_u_4302
		v_u_4303 = false
		v_u_4302.model:Destroy()
	end
end
function v_u_7.show(p_u_4313, p_u_4314, p4315) -- name: show
	for _, v4316 in p_u_4313:GetChildren() do
		if not (v4316:IsA("Model") or (v4316:IsA("Camera") or v4316:IsA("WorldModel"))) then
			continue
		end
		v4316:Destroy()
	end
	local v4317 = Instance.new("Camera")
	v4317.FieldOfView = 30
	v4317.Parent = p_u_4313
	p_u_4313.CurrentCamera = v4317
	p_u_4314:PivotTo(CFrame.new(0, 0, 0) * CFrame.Angles(0, 0.4363323129985824, 0))
	p_u_4314.Parent = p_u_4313
	local v4318, v4319 = p_u_4314:GetBoundingBox()
	local v4320 = v4319.Magnitude / 2
	local v4321 = v4317.FieldOfView / 2
	local v4322 = math.rad(v4321)
	local v4323 = v4320 / math.tan(v4322) * 1.05
	local v4324 = v4318.Position
	local v4325 = CFrame.lookAt
	local v4326 = v4320 * 0.35
	local v4327 = -v4323
	v4317.CFrame = v4325(v4324 + Vector3.new(0, v4326, v4327), v4324)
	if p4315 then
		task.spawn(function()
			-- upvalues: (copy) p_u_4314, (copy) p_u_4313
			while p_u_4314.Parent == p_u_4313 do
				local v4328 = p_u_4314
				local v4329 = CFrame.Angles
				local v4330 = os.clock() * 1.5
				local v4331 = math.sin(v4330) * 30 + 25
				v4328:PivotTo(v4329(0, math.rad(v4331), 0))
				task.wait(0.03333333333333333)
			end
		end)
	end
end
v6.install({
	["SHAPES"] = v_u_925,
	["GEAR"] = v_u_926,
	["HOP"] = v_u_47,
	["AURA_STYLES"] = v_u_4057,
	["AURAS"] = v_u_4140,
	["DARK"] = v_u_13,
	["WHITE"] = v_u_14,
	["BLUSH"] = v_u_15,
	["PINK"] = v_u_16,
	["GOLD"] = v_u_18,
	["hex"] = v_u_49,
	["has"] = function(p4332, p4333) -- name: has
		local v4334 = p4332.gear
		local v4335
		if v4334 == nil then
			v4335 = false
		else
			v4335 = table.find(v4334, p4333) ~= nil
		end
		return v4335
	end,
	["rotZ"] = function(p4336, p4337) -- name: rotZ
		-- upvalues: (copy) v_u_8
		local v4338 = math.cos(p4337)
		local v4339 = math.sin(p4337)
		return v_u_8(p4336.X * v4338 - p4336.Y * v4339, p4336.X * v4339 + p4336.Y * v4338, p4336.Z)
	end,
	["headTop"] = function(p4340) -- name: headTop
		return p4340.headC.Y + p4340.headS.Y / 2
	end,
	["bone"] = v_u_72,
	["onto"] = function(p4341, p4342) -- name: onto
		p4341.cur = p4341.byName[p4342] or p4341.bones[1]
	end,
	["box"] = function(p4343, p4344, p4345, p4346, p4347) -- name: box
		-- upvalues: (copy) v_u_80
		local v4348 = Instance.new("Part")
		v_u_80(p4343, v4348, p4344, p4345, p4346, p4347)
		return v4348
	end,
	["ball"] = function(p4349, p4350, p4351, p4352, p4353) -- name: ball
		-- upvalues: (copy) v_u_80, (copy) v_u_9
		local v4354 = Instance.new("Part")
		v4354.Shape = Enum.PartType.Ball
		v_u_80(p4349, v4354, Vector3.new(1, 1, 1) * p4350, v_u_9(p4351), p4352, p4353)
		return v4354
	end,
	["cyl"] = function(p4355, p4356, p4357, p4358, p4359, p4360) -- name: cyl
		-- upvalues: (copy) v_u_80, (copy) v_u_8
		local v4361 = Instance.new("Part")
		v4361.Shape = Enum.PartType.Cylinder
		v_u_80(p4355, v4361, v_u_8(p4356, p4357, p4357), p4358, p4359, p4360)
		return v4361
	end,
	["wedge"] = function(p4362, p4363, p4364, p4365, p4366) -- name: wedge
		-- upvalues: (copy) v_u_80
		local v4367 = Instance.new("WedgePart")
		v_u_80(p4362, v4367, p4363, p4364, p4365, p4366)
		return v4367
	end,
	["tri"] = v_u_93,
	["tri3"] = v_u_124,
	["bar"] = function(p4368, p4369, p4370, p4371, p4372, p4373) -- name: bar
		-- upvalues: (copy) v_u_8, (copy) v_u_80
		local v4374 = (p4369 + p4370) / 2
		local v4375 = v_u_8(p4371, p4371, (p4370 - p4369).Magnitude)
		local v4376 = CFrame.lookAt(v4374, p4370)
		v_u_80(p4368, Instance.new("Part"), v4375, v4376, p4372, p4373)
	end,
	["limb"] = function(p4377, p4378, p4379, p4380, p4381, p4382) -- name: limb
		-- upvalues: (copy) v_u_8, (copy) v_u_80
		local v4383 = (p4379 - p4378).Unit * p4380 * 0.4
		local v4384 = p4378 - v4383
		local v4385 = p4379 + v4383
		local v4386 = (v4384 + v4385) / 2
		local v4387 = v_u_8(p4380, p4380, (v4385 - v4384).Magnitude)
		local v4388 = CFrame.lookAt(v4386, v4385)
		v_u_80(p4377, Instance.new("Part"), v4387, v4388, p4381, p4382)
	end,
	["eyes"] = v_u_162,
	["cheeks"] = v_u_167,
	["ears"] = v_u_216,
	["tails"] = v_u_273,
	["legs"] = v_u_290,
	["flameTongue"] = v_u_2666,
	["emitter"] = v_u_4048,
	["curve"] = v_u_4052,
	["shades"] = v4056,
	["feetRing"] = v_u_4108,
	["feetPicture"] = v_u_4130
})
return v_u_7