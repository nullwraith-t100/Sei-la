local v_u_1 = require(script.Parent.Parent.Config.Pets)
local v_u_2 = require(script.Parent.Parent.Config.Stages)
local v_u_3 = require(script.Parent.Parent.Config.Worlds)
local v_u_4 = require(script.Parent.Parent.Config.Release)
local v_u_29 = {
	["worldOut"] = function(p5) -- name: worldOut
		-- upvalues: (copy) v_u_3
		for _, v6 in v_u_3 do
			if v6.id ~= p5 then
				continue
			end
			return v6.ready
		end
		return true
	end,
	["mapName"] = function(p7) -- name: mapName
		return p7 == 1 and "Map" or "Map" .. p7
	end,
	["worlds"] = function() -- name: worlds
		-- upvalues: (copy) v_u_3
		local v8 = {}
		for _, v9 in v_u_3 do
			if v9.ready then
				continue
			end
			local v10 = v9.id
			table.insert(v8, v10)
		end
		return v8
	end,
	["pets"] = function() -- name: pets
		-- upvalues: (copy) v_u_1, (copy) v_u_29, (copy) v_u_4
		local v11 = {}
		local v12 = {}
		for _, v13 in v_u_1.eggs do
			local v14 = v_u_29.worldOut(v13.world or 1)
			if v14 then
				v14 = v_u_4.on(v13.update)
			end
			for _, v15 in v13.pool do
				if v14 then
					v11[v15.pet] = true
				else
					v12[v15.pet] = true
				end
			end
		end
		for v16 in v11 do
			v12[v16] = nil
		end
		return v12
	end,
	["eyePiece"] = function(p17) -- name: eyePiece
		-- upvalues: (copy) v_u_29
		local v18 = string.match
		local v19 = tonumber(v18(p17, "^w(%d+)_"))
		local v20
		if v19 == nil then
			v20 = false
		else
			v20 = not v_u_29.worldOut(v19)
		end
		return v20
	end,
	["enemies"] = function() -- name: enemies
		-- upvalues: (copy) v_u_2, (copy) v_u_29
		local v21 = {}
		local v22 = {}
		for v23, v24 in v_u_2.worlds do
			local v25
			if v_u_29.worldOut(v23) then
				v25 = v21
			else
				v25 = v22
			end
			for _, v26 in v24 do
				for _, v27 in v26.enemies do
					v25[v27] = true
				end
				if not v26.boss then
					break
				end
				v25[v26.boss] = true
			end
		end
		for v28 in v21 do
			v22[v28] = nil
		end
		return v22
	end
}
return v_u_29