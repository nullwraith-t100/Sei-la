local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("E8141F")
local v_u_9 = Color3.fromRGB(255, 55, 55)
local v_u_10 = Color3.fromRGB(255, 175, 165)
local v_u_11 = Color3.fromRGB(150, 0, 16)
local v_u_12 = Color3.fromRGB(70, 0, 10)
local v_u_13 = Color3.fromHex("0D0405")
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.PartType.Wedge
local function v_u_28(p16) -- name: aimPoint
	local v17 = p16.target.X - p16.origin.X
	local v18 = p16.target.Z - p16.origin.Z
	local v19 = Vector3.new(v17, 0, v18)
	local v20 = v19.Magnitude
	local v21 = p16.ability.range
	local v22 = math.max(v21, 6)
	local v23 = math.clamp(v20, 6, v22)
	local v24
	if v19.Magnitude > 0.001 then
		v24 = v19.Unit
	else
		v24 = p16.dir
	end
	local v25 = p16.origin.X
	local v26 = p16.target.Y
	local v27 = p16.origin.Z
	return Vector3.new(v25, v26, v27) + v24 * v23
end
local function v_u_40(p29, p30, p31, p32, p33) -- name: picture
	-- upvalues: (copy) v_u_5
	local v34 = v_u_5.part
	local v35 = p30 * 2
	local v36 = p30 * 2
	local v37 = v34(Vector3.new(v35, 0.05, v36), p29, p32, {
		["transparency"] = 1
	})
	for _, v38 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v39 = Instance.new("Decal")
		v39.Face = v38
		v39.Texture = p31
		v39.Color3 = p32
		v39.Transparency = p33
		v39.Parent = v37
	end
	return v37
end
local function v_u_41() -- name: newBody
	return {
		["parts"] = nil,
		["offs"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["decals"] = nil,
		["cfs"] = nil,
		["k"] = -1,
		["f"] = -1,
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {},
		["alphas"] = {},
		["decals"] = {},
		["cfs"] = {}
	}
end
local function v_u_55(p42, p43, p44, p45, p46) -- name: hold
	-- upvalues: (copy) v_u_1
	v_u_1:AddItem(p43, p46)
	local v47 = {}
	for _, v48 in p43:GetChildren() do
		if not v48:IsA("Decal") then
			continue
		end
		table.insert(v47, v48)
	end
	local v49 = p42.parts
	table.insert(v49, p43)
	local v50 = p42.offs
	table.insert(v50, p44)
	local v51 = p42.sizes
	local v52 = p43.Size
	table.insert(v51, v52)
	local v53 = p42.alphas
	table.insert(v53, p45)
	local v54 = p42.decals
	table.insert(v54, v47)
	p43.Transparency = 1
end
local function v_u_82(p56, p57, p58, p59) -- name: placeBody
	-- upvalues: (copy) v_u_4
	local v60 = math.max(p58, 0.02)
	local v61 = math.clamp(p59, 0, 1)
	local v62 = p56.parts
	local v63 = p56.offs
	local v64 = p56.cfs
	for v65 = 1, #v62 do
		local v66 = v63[v65]
		v64[v65] = p57 * (v66 - v66.Position + v66.Position * v60)
	end
	v_u_4:BulkMoveTo(v62, v64, Enum.BulkMoveMode.FireCFrameChanged)
	local v67 = v60 - p56.k
	if math.abs(v67) > 0.0001 then
		p56.k = v60
		for v68, v69 in v62 do
			local v70 = p56.sizes[v68]
			local v71
			if #p56.decals[v68] > 0 then
				local v72 = v70.X * v60
				local v73 = v70.Y
				local v74 = v70.Z * v60
				v71 = Vector3.new(v72, v73, v74)
			else
				v71 = v70 * v60
			end
			v69.Size = v71
		end
	end
	local v75 = v61 - p56.f
	if math.abs(v75) > 0.001 then
		p56.f = v61
		for v76, v77 in v62 do
			local v78 = p56.alphas[v76]
			local v79 = v78 + (1 - v78) * v61
			local v80 = p56.decals[v76]
			if #v80 > 0 then
				for _, v81 in v80 do
					v81.Transparency = v79
				end
			else
				v77.Transparency = v79
			end
		end
	end
end
local v_u_83 = 0
local function v_u_89(p84, p85) -- name: impactFrame
	-- upvalues: (ref) v_u_83, (copy) v_u_2, (copy) v_u_5, (copy) v_u_14, (copy) v_u_1
	local v86 = os.clock()
	if v86 >= v_u_83 then
		v_u_83 = v86 + p85 + 0.4
		local v_u_87 = Instance.new("ColorCorrectionEffect")
		v_u_87.Name = "BloodTrident"
		v_u_87.Parent = v_u_2
		v_u_5.tween(v_u_87, 0.04, {
			["TintColor"] = nil,
			["Contrast"] = 0.45,
			["Saturation"] = -0.25,
			["TintColor"] = p84
		})
		task.delay(p85, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_87, (ref) v_u_14
			local v88 = {
				["TintColor"] = nil,
				["Contrast"] = 0,
				["Saturation"] = 0,
				["TintColor"] = v_u_14
			}
			v_u_5.tween(v_u_87, 0.35, v88)
		end)
		v_u_1:AddItem(v_u_87, p85 + 0.4)
	end
end
return function(p_u_90)
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_15, (copy) v_u_13, (copy) v_u_10, (copy) v_u_12, (copy) v_u_7, (copy) v_u_11, (copy) v_u_6, (copy) v_u_41, (copy) v_u_55, (copy) v_u_40, (copy) v_u_82, (copy) v_u_28, (copy) v_u_89, (copy) v_u_14
	local function v_u_114(p91, p92, p93, p94) -- name: triCut
		-- upvalues: (copy) p_u_90, (ref) v_u_4, (ref) v_u_5, (ref) v_u_1
		local v95 = p_u_90.facing
		local v96 = v_u_4.CurrentCamera
		local v97
		if v96 then
			local v98 = v96.CFrame.Position - p91
			v97 = v98.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v98.Unit
		else
			v97 = Vector3.new(0, 0, 1)
		end
		local v99 = v95(p91, v97)
		local v100 = math.random() * 3.141592653589793 * 2
		for v101 = 0, 2 do
			local v102 = v100 + v101 * 2.0943951023931953
			local v103 = math.cos(v102)
			local v104 = math.sin(v102)
			local v105 = v99:VectorToWorldSpace((Vector3.new(v103, 0, v104)))
			local v106 = v_u_5.part
			local v107 = p92 * 0.4
			local v108 = p92 * 0.4
			local v109 = p92 * 0.5
			local v110 = v106(Vector3.new(v107, v108, v109), CFrame.lookAt(p91 + v105 * p92 * 0.25, p91 + v105 * p92), p93)
			local v111 = v_u_5.tween
			local v112 = {
				["Size"] = nil,
				["CFrame"] = nil,
				["Transparency"] = 1
			}
			local v113 = p92 * 1.3
			v112.Size = Vector3.new(0.05, 0.05, v113)
			v112.CFrame = CFrame.lookAt(p91 + v105 * p92 * 0.75, p91 + v105 * p92 * 2)
			v111(v110, p94, v112, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			v_u_1:AddItem(v110, p94 + 0.05)
		end
	end
	local function v147(p115, p116) -- name: tipShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_15, (ref) v_u_13, (ref) v_u_10, (copy) p_u_90, (ref) v_u_12
		local v117 = p115.size
		local v118 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p116, v_u_8, {
			["transparency"] = 1
		})
		local v119 = 1.9 * v117
		local v120 = {}
		for v121 = 0, 2 do
			local v122 = v121 * 2.0943951023931953
			local v123 = math.cos(v122)
			local v124 = math.sin(v122)
			local v125 = Vector3.new(v123, v124, 0)
			local v126 = -math.sin(v122)
			local v127 = math.cos(v122)
			local v128 = Vector3.new(v126, v127, 0)
			local v129 = v125 * 0.2 * v117
			local v130 = 0.95 * v117
			local v131 = 0.28 * v117
			local v132 = v129 + v125 * (v119 / 2) + v128 * (v130 / 2)
			local v133 = CFrame.fromMatrix(v132, v128:Cross(-v125), v128)
			local v134 = Vector3.new(v131, v130, v119)
			local v135 = {}
			local v136 = {
				["shape"] = v_u_15
			}
			v135.p = v_u_5.part(v134, p116 * v133, v_u_9, v136)
			v135.off = v133
			table.insert(v120, v135)
			if p115.lite then
				continue
			end
			local v137 = v125 * 0.5 * v117
			local v138 = v119 * 0.66
			local v139 = 0.45 * v117
			local v140 = 0.3 * v117
			local v141 = v137 + v125 * (v138 / 2) + v128 * (v139 / 2)
			local v142 = CFrame.fromMatrix(v141, v128:Cross(-v125), v128)
			local v143 = Vector3.new(v140, v139, v138)
			local v144 = v142 * CFrame.new(0.08 * v117, 0, 0)
			local v145 = {
				["p"] = v_u_5.part(v143, p116 * v144, v_u_13, {
					["shape"] = v_u_15,
					["material"] = Enum.Material.SmoothPlastic
				}),
				["off"] = v144
			}
			table.insert(v120, v145)
		end
		local v146 = {
			["p"] = v_u_5.part(Vector3.new(0.75, 0.75, 0.75) * v117, p116, v_u_10, {
				["shape"] = Enum.PartType.Ball
			}),
			["off"] = CFrame.identity
		}
		table.insert(v120, v146)
		p_u_90.streak(v118, v_u_9, v_u_12, 1.3 * v117, 0.12)
		if p115.mine then
			p_u_90.light(v118, v_u_9, 9 * v117)
		end
		return p_u_90.assemble(v118, v120, {}, 0, 0, {}, 0.12, -24)
	end
	local function v152(p148, p149) -- name: tipImpact
		-- upvalues: (copy) v_u_114, (ref) v_u_9, (copy) p_u_90, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11
		local v150 = p148.size
		v_u_114(p149, 3.2 * v150, v_u_9, 0.16)
		p_u_90.burst("Impact", p149, v_u_8, 0.9 * v150)
		v_u_5.flash(p149, v_u_9, 4 * v150, 0.12)
		p_u_90.pop(p149, v_u_10, 1 * v150, 3 * v150, 0.1)
		v_u_5.ring(p_u_90.ground(p149), v_u_8, 3.6 * v150, 0.22, v_u_7.Ring)
		if not p148.lite then
			p_u_90.burst("Slash", p149, v_u_9, 0.8 * v150)
			local v151 = { v_u_9, v_u_11 }
			p_u_90.chunks(p149, v151, 3, 18, 0.3 * v150, 0.35, true, 0.6)
		end
		p_u_90.hitSound(p149)
	end
	local function v_u_188(p153, p154, p_u_155, p156, p_u_157, p158) -- name: spear
		-- upvalues: (ref) v_u_1, (ref) v_u_5, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_15, (copy) p_u_90, (ref) v_u_4
		local v159 = p_u_157 + 0.07 + 0.16 + 0.3
		local v_u_160 = {}
		local v_u_161 = {}
		local v162 = p_u_155 * 0.74
		local v163 = v_u_5.part(Vector3.new(v162, p156, p156), CFrame.new(p153), v_u_11, {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		})
		local v164 = CFrame.new(0, v162 / 2, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
		v_u_1:AddItem(v163, v159)
		table.insert(v_u_160, v163)
		table.insert(v_u_161, v164)
		local v165 = p_u_155 - v162 + p156
		local v166 = p156 * 3
		for v167 = 0, p158 and 0 or 1 do
			for _, v168 in { -1, 1 } do
				local v169 = v_u_5.part
				local v170 = p156 * 0.5
				local v171 = v166 / 2
				local v172 = Vector3.new(v170, v165, v171)
				local v173 = CFrame.new(p153)
				local v174
				if v167 == 0 then
					v174 = v_u_9
				else
					v174 = v_u_8
				end
				local v175 = v169(v172, v173, v174, {
					["shape"] = v_u_15
				})
				local v176 = CFrame.new(0, v162 - p156, 0) * CFrame.Angles(0, v167 * 3.141592653589793 / 2, 0) * CFrame.new(v168 * v166 / 4, v165 / 2, 0) * CFrame.Angles(0, -v168 * 3.141592653589793 / 2, 0)
				v_u_1:AddItem(v175, v159)
				table.insert(v_u_160, v175)
				table.insert(v_u_161, v176)
			end
		end
		local v_u_177 = p_u_90.facing(p153, p154)
		local v_u_178 = os.clock()
		local v_u_179 = table.create(#v_u_160)
		p_u_90.runNow(function()
			-- upvalues: (copy) v_u_178, (copy) p_u_157, (copy) v_u_177, (copy) p_u_155, (copy) v_u_161, (copy) v_u_179, (ref) v_u_4, (copy) v_u_160
			local v180 = os.clock() - v_u_178
			local v181
			if v180 < 0.07 then
				local v182 = v180 / 0.07 - 1
				v181 = v182 * 2.7 * v182 * v182 + 1 + v182 * 1.7 * v182
			elseif v180 < p_u_157 + 0.07 then
				v181 = 1
			else
				local v183 = (v180 - 0.07 - p_u_157) / 0.16
				v181 = 1 - math.clamp(v183, 0, 1) ^ 2
			end
			local v184 = v_u_177 * CFrame.new(0, -(1 - v181) * p_u_155, 0)
			for v185, v186 in v_u_161 do
				v_u_179[v185] = v184 * v186
			end
			v_u_4:BulkMoveTo(v_u_160, v_u_179, Enum.BulkMoveMode.FireCFrameChanged)
			if p_u_157 + 0.07 + 0.16 > v180 then
				return true
			end
			for _, v187 in v_u_160 do
				v187:Destroy()
			end
			return false
		end)
	end
	local function v_u_209(p_u_189, p190, p191, p192) -- name: spearLine
		-- upvalues: (copy) p_u_90, (copy) v_u_188, (ref) v_u_8, (ref) v_u_12, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6
		local v_u_193 = p_u_189.lite
		local v194 = p_u_90.flatUnit(p191 - p190)
		local v195 = v194:Cross(Vector3.new(0, 1, 0))
		local v196 = (p191 - p190).Magnitude
		local v197 = p_u_189.ability.width or 10
		local v198 = v196 / (v_u_193 and 12 or 6.5)
		local v199 = math.floor(v198)
		local v200 = math.clamp(v199, 3, 12)
		for v_u_201 = 1, v200 do
			local v_u_202 = v_u_201 / v200
			local v_u_203 = v_u_201 == v200
			local v204 = v_u_201 % 2 == 0 and 1 or -1
			local v205 = v195 * v204 * v197 * 0.22 * (0.6 + math.random() * 0.6)
			local v_u_206 = p_u_90.ground(p190:Lerp(p191, v_u_202) + (v_u_203 and Vector3.new(0, 0, 0) or v205), -0.3)
			local v_u_207
			if v_u_203 then
				v_u_207 = (Vector3.new(0, 2, 0) + v194 * 0.3).Unit
			else
				v_u_207 = (Vector3.new(0, 1.6, 0) + v194 * 0.75 + v195 * v204 * 0.45).Unit
			end
			local v_u_208 = v_u_203 and 17 or v_u_202 * 5 + 7 + math.random() * 1.5
			p_u_90.after(p192 * (v_u_201 - 1), function()
				-- upvalues: (ref) v_u_188, (copy) v_u_206, (copy) v_u_207, (copy) v_u_208, (copy) v_u_203, (copy) v_u_202, (copy) v_u_193, (ref) p_u_90, (ref) v_u_8, (copy) v_u_201, (ref) v_u_12, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (copy) p_u_189
				v_u_188(v_u_206, v_u_207, v_u_208, v_u_203 and 1.1 or v_u_202 * 0.2 + 0.55, v_u_203 and 0.55 or 0.32, v_u_193)
				p_u_90.burst("Impact", p_u_90.ground(v_u_206, 1), v_u_8, v_u_203 and 1.6 or 0.8)
				if not v_u_193 or v_u_201 % 2 == 0 then
					p_u_90.mark(v_u_206, v_u_12, v_u_203 and 4 or 1.8, 0.9, v_u_7.CrackLines, 0.05)
				end
				if not v_u_193 then
					p_u_90.chunks(p_u_90.ground(v_u_206, 0.6), { p_u_90.EARTH[1], v_u_11, v_u_9 }, 2, 24, 0.5, 0.6, false, 0.9)
				end
				if v_u_203 then
					p_u_90.thin(p_u_90.pillar(p_u_90.ground(v_u_206, 0), 14, 3.2, v_u_9, 0.35), 0.4, true)
					p_u_90.burst("Shockwave", p_u_90.ground(v_u_206, 0.3), v_u_8, 0.8)
					v_u_5.ring(p_u_90.ground(v_u_206), v_u_9, 9, 0.35, v_u_7.Shockwave)
					p_u_90.chunks(p_u_90.ground(v_u_206, 2), { v_u_9, v_u_11, v_u_10 }, v_u_193 and 4 or 9, 34, 0.5, 0.7, true, 1.1)
					v_u_6.play("Hit", {
						["at"] = v_u_206,
						["volume"] = p_u_189.mine and 0.8 or 0.4
					})
				end
			end)
		end
	end
	local v_u_210 = {}
	setmetatable(v_u_210, {
		["__mode"] = "k"
	})
	local v_u_211 = {}
	setmetatable(v_u_211, {
		["__mode"] = "k"
	})
	local function v_u_228(p212, p213) -- name: buildSeal
		-- upvalues: (ref) v_u_41, (ref) v_u_55, (ref) v_u_5, (ref) v_u_8, (ref) v_u_15, (ref) v_u_13, (ref) v_u_40, (ref) v_u_7, (ref) v_u_9
		local v214 = v_u_41()
		for v215 = 0, 2 do
			local v216 = v215 * 2.0943951023931953
			local v217 = math.cos(v216)
			local v218 = math.sin(v216)
			local v219 = Vector3.new(v217, 0, v218)
			local v220 = -math.sin(v216)
			local v221 = math.cos(v216)
			local v222 = Vector3.new(v220, 0, v221)
			local v223 = v219 * 1.5 + v219 * 9.5 + v222 * 4.75
			local v224 = CFrame.fromMatrix(v223, v222:Cross(-v219), v222)
			local v225 = {
				["shape"] = v_u_15
			}
			v_u_55(v214, v_u_5.part(Vector3.new(1.1, 9.5, 19), v224, v_u_8, v225), v224, 0, p213)
			local v226 = v219 * 3.2 + v219 * 7.41 + v222 * 2.85
			local v227 = CFrame.fromMatrix(v226, v222:Cross(-v219), v222)
			v_u_55(v214, v_u_5.part(Vector3.new(1.2, 5.7, 14.82), v227, v_u_13, {
				["shape"] = v_u_15,
				["material"] = Enum.Material.SmoothPlastic
			}), v227 * CFrame.new(-0.12, 0, 0), 0, p213)
		end
		v_u_55(v214, v_u_40(CFrame.identity, 15.579999999999998, v_u_7.Ring, v_u_9, 0), CFrame.new(0, 0.7, 0), 0, p213)
		if not p212 then
			v_u_55(v214, v_u_40(CFrame.identity, 8.55, v_u_7.Ring, v_u_8, 0), CFrame.new(0, 0.75, 0), 0.1, p213)
			v_u_55(v214, v_u_40(CFrame.identity, 21.849999999999998, v_u_7.Glow, v_u_8, 0.35), CFrame.new(0, -0.6, 0), 0.35, p213)
		end
		v_u_55(v214, v_u_5.part(Vector3.new(1.4, 4.2, 4.2), CFrame.identity, v_u_9, {
			["shape"] = Enum.PartType.Cylinder
		}), CFrame.Angles(0, 0, 1.5707963267948966), 0, p213)
		v_u_55(v214, v_u_5.part(Vector3.new(1.6, 1.8, 1.8), CFrame.identity, v_u_13, {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		}), CFrame.Angles(0, 0, 1.5707963267948966), 0, p213)
		return v214
	end
	local function v_u_256(p229) -- name: sealStep
		-- upvalues: (ref) v_u_82
		if p229.done then
			return false
		end
		local v230 = os.clock()
		local v231 = v230 - p229.last
		local v232 = math.min(v231, 0.05)
		p229.last = v230
		local v233 = v230 - p229.born
		local v234 = v233 / 0.16
		local v235 = math.clamp(v234, 0, 1) - 1
		local v236 = v235 * 2.7 * v235 * v235 + 1 + v235 * 1.7 * v235
		local v237 = p229.sky
		local v238 = v233 * 5
		local v239 = v237 + Vector3.new(0, 1, 0) * math.sin(v238) * 0.4
		local v240 = 1
		local v241 = v236 * 0.85 + 0.15
		local v242 = v233 / 0.08
		local v243 = 1 - math.clamp(v242, 0, 1)
		local v244 = p229.dropAt
		local v245 = p229.landAt
		if v245 and v245 <= v230 then
			local v246 = v230 - v245
			local v247 = 1 - v246 / 0.7
			p229.spin = math.max(v247, 0.1) * 26
			local v248 = p229.floor
			local v249 = v246 / 0.08
			v239 = v248 - Vector3.new(0, 1, 0) * math.min(v249, 1) * 0.5
			v240 = 0
			if v246 > 0.7 then
				v243 = (v246 - 0.7) / 0.35
				v241 = 1 + 0.15 * v243
				if v243 >= 1 then
					if not p229.done then
						p229.done = true
						for _, v250 in p229.body.parts do
							v250:Destroy()
						end
					end
					return false
				end
			else
				v241 = 1
			end
		elseif v244 and v244 <= v230 then
			local v251 = (v230 - v244) / 0.13
			local v252 = math.clamp(v251, 0, 1)
			v239 = p229.sky:Lerp(p229.floor, v252 * v252)
			v240 = 1 - v252
			p229.spin = v252 * 10 + 14
		elseif v233 > 1.2 then
			local v253 = (v233 - 1.2) / 0.35
			v243 = math.clamp(v253, 0, 1)
			if v243 >= 1 then
				if not p229.done then
					p229.done = true
					for _, v254 in p229.body.parts do
						v254:Destroy()
					end
				end
				return false
			end
		end
		p229.angle = p229.angle + p229.spin * v232
		local v255 = p229.lean:Lerp(CFrame.identity, 1 - v240)
		v_u_82(p229.body, CFrame.new(v239) * v255 * CFrame.Angles(0, p229.angle, 0), v241, v243)
		return true
	end
	local function v_u_266(p257) -- name: startSeal
		-- upvalues: (ref) v_u_28, (copy) p_u_90, (copy) v_u_228, (copy) v_u_210, (copy) v_u_211, (ref) v_u_5, (ref) v_u_9, (ref) v_u_8, (copy) v_u_256
		local v258 = v_u_28(p257)
		local v259 = p_u_90.ground(v258, 0)
		local v260 = v259 + Vector3.new(0, 26, 0)
		local v261 = p_u_90.flatUnit(p257.feet - v259):Cross(Vector3.new(0, 1, 0))
		local v_u_262 = {
			["body"] = nil,
			["born"] = nil,
			["sky"] = nil,
			["floor"] = nil,
			["lean"] = nil,
			["dropAt"] = nil,
			["landAt"] = nil,
			["spin"] = 9,
			["last"] = nil,
			["done"] = false,
			["angle"] = nil,
			["body"] = v_u_228(p257.lite, 4.75),
			["born"] = os.clock(),
			["sky"] = v260,
			["floor"] = p_u_90.ground(v258, 1.4),
			["lean"] = CFrame.fromAxisAngle(v261, -0.85),
			["last"] = os.clock(),
			["angle"] = math.random() * 3.141592653589793 * 2
		}
		local v263 = p257.caster
		if v263 then
			local v264 = v_u_210[v263]
			if v264 and not (v264.dropAt or v264.done) then
				v264.done = true
				for _, v265 in v264.body.parts do
					v265:Destroy()
				end
			end
			v_u_210[v263] = v_u_262
		else
			v_u_211[p257] = v_u_262
		end
		v_u_5.flash(v260, v_u_9, 14, 0.2)
		if not p257.lite then
			p_u_90.glowBeam(p257.eye, v260, v_u_8, 1.6, 0.35)
			p_u_90.burst("Flash", v260, v_u_8, 0.8)
		end
		p_u_90.runNow(function()
			-- upvalues: (ref) v_u_256, (copy) v_u_262
			return v_u_256(v_u_262)
		end)
		return v_u_262
	end
	local function v_u_281(p267, p_u_268, p269) -- name: judgement
		-- upvalues: (copy) p_u_90, (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_8, (ref) v_u_7, (ref) v_u_13, (ref) v_u_12, (ref) v_u_11, (ref) v_u_6, (ref) v_u_89
		local v_u_270 = p267.ability.radius
		local v_u_271 = p267.lite
		local v_u_272 = p_u_90.ground(p_u_268)
		local v273 = p_u_90.ground(p_u_268, 3)
		v_u_5.flash(v273, v_u_10, v_u_270 * 0.9, 0.14)
		p_u_90.pop(v_u_272, v_u_9, v_u_270 * 0.3, v_u_270 * 1.3, 0.3, 0.6)
		p_u_90.burst("Explosion", v273, v_u_8, 2.4)
		p_u_90.burst("Shockwave", v_u_272 + Vector3.new(0, 0.3, 0), v_u_8, 1.6)
		v_u_5.ring(v_u_272, v_u_9, v_u_270 * 1.2, 0.5, v_u_7.Shockwave)
		p_u_90.after(0.06, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_272, (ref) v_u_10, (copy) v_u_270, (ref) v_u_7
			v_u_5.ring(v_u_272, v_u_10, v_u_270 * 1.45, 0.45, v_u_7.SpeedLines)
		end)
		p_u_90.mark(p_u_268, v_u_13, v_u_270 * 0.75, 2.2, v_u_7.CrackLines, 0.05)
		p_u_90.mark(p_u_268, v_u_8, v_u_270 * 0.55, 1.6, v_u_7.CrackGlow, 0.2)
		local v274
		if p269 then
			v274 = p269.angle
		else
			v274 = math.random() * 3.141592653589793 * 2
		end
		for v275 = 0, 2 do
			local v276 = v274 + v275 * 2.0943951023931953
			local v277 = math.cos(v276)
			local v278 = math.sin(v276)
			local v_u_279 = v_u_272 + Vector3.new(v277, 0, v278) * v_u_270 * 0.95
			p_u_90.groundLine(v_u_272, v_u_279, 3.2, v_u_9, 1.3, 0.1)
			p_u_90.groundLine(v_u_272, v_u_279, 7, v_u_12, 1.6, 0.35)
			p_u_90.after(v275 * 0.04 + 0.05, function()
				-- upvalues: (ref) p_u_90, (copy) v_u_279, (ref) v_u_9, (ref) v_u_10, (ref) v_u_8, (ref) v_u_11, (copy) v_u_271
				p_u_90.thin(p_u_90.pillar(p_u_90.ground(v_u_279, 0), 15, 2.6, v_u_9, 0.3), 0.32, true)
				p_u_90.thin(p_u_90.pillar(p_u_90.ground(v_u_279, 0), 18, 1, v_u_10, 0), 0.25, true)
				p_u_90.burst("Impact", p_u_90.ground(v_u_279, 2), v_u_8, 1.6)
				p_u_90.chunks(p_u_90.ground(v_u_279, 1), { v_u_9, v_u_11, v_u_10 }, v_u_271 and 3 or 7, 40, 0.6, 0.8, true, 1.2)
			end)
		end
		p_u_90.spikes(v273, v_u_9, v_u_271 and 5 or 10, v_u_270 * 1.2, 0.35, nil, nil, true)
		p_u_90.spikes(v273, v_u_10, v_u_271 and 3 or 6, v_u_270 * 0.9, 0.3)
		if not v_u_271 then
			p_u_90.chunks(p_u_90.ground(p_u_268, 1), {
				p_u_90.EARTH[1],
				p_u_90.EARTH[2],
				v_u_12,
				p_u_90.EARTH[4]
			}, 14, 55, 1.4, 1.3, false, 1)
			for v280 = 1, 5 do
				p_u_90.after(v280 * 0.11, function()
					-- upvalues: (ref) p_u_90, (copy) p_u_268, (ref) v_u_10, (copy) v_u_270
					p_u_90.spikes(p_u_90.ground(p_u_268, 1.2), v_u_10, 6, v_u_270 * 0.9, 0.18, nil, nil, true)
				end)
			end
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_272,
			["volume"] = p267.mine and 1 or 0.6
		})
		v_u_6.play("Crit", {
			["at"] = v_u_272,
			["volume"] = p267.mine and 0.7 or 0.35
		})
		if p267.mine then
			v_u_5.shake(0.6, 0.55)
			v_u_89(Color3.fromRGB(255, 200, 200), 0.1)
		end
	end
	local v324 = {
		["blood_trident_a"] = {
			["cast"] = function(p282) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) p_u_90, (ref) v_u_10
				local v283 = p282.size
				local v284 = p282.eye + p282.dir * 1.2
				v_u_5.flash(v284, v_u_9, 3.2 * v283, 0.1)
				p_u_90.pop(v284, v_u_10, 1.2 * v283, 0.3 * v283, 0.08)
				if not p282.lite then
					p_u_90.spikes(v284, v_u_9, 3, 2.8 * v283, 0.1, p282.dir, 0.5)
				end
			end,
			["shot"] = v147,
			["impact"] = v152,
			["hit"] = function(_, p285, _) -- name: hit
				-- upvalues: (copy) p_u_90, (ref) v_u_8
				p_u_90.burst("Impact", p285, v_u_8, 0.6)
			end
		},
		["blood_trident_e"] = {
			["cast"] = function(p286) -- name: cast
				-- upvalues: (copy) p_u_90, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7
				p_u_90.skillCast(p286, v_u_8)
				p_u_90.glint(p286.eye, v_u_9, 5, 0.16)
				v_u_5.ring(p286.feet, v_u_9, 5, 0.25, v_u_7.Shockwave)
			end,
			["windup"] = function(p287, _, p288) -- name: windup
				-- upvalues: (copy) p_u_90, (ref) v_u_9, (ref) v_u_7, (copy) v_u_209
				local v289 = p_u_90.ground(p287.feet + p287.dir * 2.5, 0)
				local v290 = p_u_90.ground(p287.target, 0)
				if (v290 - v289).Magnitude < 2 then
					v290 = v289 + p287.dir * 30
				end
				local v291 = math.max(p288, 0.05) + 0.12
				p_u_90.alongPath(v289, v290, 7, v291, function(p292)
					-- upvalues: (ref) p_u_90, (ref) v_u_9, (ref) v_u_7
					p_u_90.mark(p292, v_u_9, 2.2, 0.5, v_u_7.Glow, 0.2)
				end)
				p_u_90.groundLine(v289, v290, 1.2, v_u_9, v291 + 0.4, 0.15)
				v_u_209(p287, v289, v290, 0.026)
			end,
			["beam"] = function(p293, p294, p295) -- name: beam
				-- upvalues: (copy) p_u_90, (ref) v_u_14, (ref) v_u_9, (ref) v_u_12, (ref) v_u_6, (ref) v_u_5
				local v296 = p293.lite
				local v297 = p294 + p293.dir * 1.5
				local v298 = p_u_90.ground(v297, 1.4)
				local v299 = p_u_90.ground(p295, 1.4)
				p_u_90.thin(p_u_90.rod(v298, v299, 0.5, v_u_14), 0.18, true)
				p_u_90.thin(p_u_90.rod(v298, v299, 2.2, v_u_9, 0.4), 0.3, true)
				p_u_90.groundLine(p294, p295, p293.ability.width or 10, v_u_12, 1, 0.5)
				local v300 = v296 and 3 or 6
				for v301 = 1, v300 do
					local v_u_302 = v298:Lerp(v299, v301 / v300)
					p_u_90.after(v301 * 0.02, function()
						-- upvalues: (ref) p_u_90, (copy) v_u_302, (ref) v_u_9
						p_u_90.burst("Slash", v_u_302, v_u_9, 1.2)
					end)
				end
				v_u_6.play("Crit", {
					["at"] = p294,
					["volume"] = p293.mine and 0.8 or 0.45
				})
				if p293.mine then
					v_u_5.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(p303, p304, _) -- name: hit
				-- upvalues: (copy) p_u_90, (ref) v_u_8, (copy) v_u_114, (ref) v_u_9
				p_u_90.burst("Impact", p304, v_u_8, 1)
				if not p303.lite then
					v_u_114(p304, 2, v_u_9, 0.14)
				end
			end
		},
		["blood_trident_r"] = {
			["cast"] = function(p305) -- name: cast
				-- upvalues: (copy) p_u_90, (ref) v_u_8, (ref) v_u_9, (ref) v_u_14, (ref) v_u_7, (ref) v_u_6, (copy) v_u_266
				p_u_90.skillCast(p305, v_u_8, true)
				p_u_90.glint(p305.eye, v_u_9, 7, 0.2)
				p_u_90.sigil(p_u_90.facing(p305.eye + p305.dir * 1.6, p305.dir), 2.2, v_u_14, p_u_90.iris("blood_trident", v_u_7.Ring), 0.3, 7)
				v_u_6.play("EyeActivate", {
					["at"] = p305.origin,
					["volume"] = p305.mine and 0.9 or 0.5
				})
				v_u_266(p305)
			end,
			["windup"] = function(p306, p307, p308) -- name: windup
				-- upvalues: (copy) v_u_210, (copy) v_u_211, (copy) v_u_266, (copy) p_u_90, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
				local v309 = p306.caster
				local v310
				if v309 then
					v310 = v_u_210[v309]
				else
					v310 = v_u_211[p306]
				end
				if not v310 or (v310.done or v310.dropAt) then
					v310 = nil
				end
				local v311 = v310 or v_u_266(p306)
				v311.floor = p_u_90.ground(p307, 1.4)
				v311.sky = p_u_90.ground(p307, 26)
				local v312 = os.clock()
				local v313 = p308 - 0.13
				local v314 = v312 + math.max(v313, 0)
				v311.dropAt = v314
				v311.landAt = v314 + 0.13
				local v315 = p306.ability.radius
				p_u_90.sigil(CFrame.new(p_u_90.ground(p307, 0.15)), v315, v_u_8, v_u_7.Ring, p308 + 0.1, -2)
				if not p306.lite then
					p_u_90.inward(p_u_90.ground(p307, 2), v_u_9, 8, v315, (math.max(p308, 0.1)))
				end
			end,
			["land"] = function(p316, p317) -- name: land
				-- upvalues: (copy) v_u_210, (copy) v_u_211, (copy) v_u_281
				local v318 = p316.caster
				local v319
				if v318 then
					v319 = v_u_210[v318]
				else
					v319 = v_u_211[p316]
				end
				if v319 and not v319.done then
					local v320 = os.clock()
					local v321 = v319.landAt or v320
					v319.landAt = math.min(v321, v320)
				end
				v_u_281(p316, p317, v319)
			end,
			["hit"] = function(p322, p323, _) -- name: hit
				-- upvalues: (copy) p_u_90, (ref) v_u_8, (copy) v_u_114, (ref) v_u_9
				p_u_90.burst("Impact", p323, v_u_8, 1.1)
				if not p322.lite then
					v_u_114(p323, 2.6, v_u_9, 0.16)
				end
			end
		}
	}
	return v324
end