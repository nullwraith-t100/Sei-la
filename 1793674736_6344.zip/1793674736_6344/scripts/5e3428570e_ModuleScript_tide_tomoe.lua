local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v2.Shared.Config.Textures)
local function v_u_13(p7, p8, p9, p10) -- name: splash
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1
	local v11 = Instance.new("Attachment")
	v11.WorldPosition = p7
	v11.Parent = v_u_3.Terrain
	local v12 = Instance.new("ParticleEmitter")
	v12.Texture = v_u_6.TideSplash
	v12.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v12.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v12.LightInfluence = 0
	v12.Color = ColorSequence.new(p8)
	v12.LightEmission = 0.3
	v12.Size = NumberSequence.new(p10 * 0.8, p10 * 1.1)
	v12.Lifetime = NumberRange.new(0.35, 0.45)
	v12.Speed = NumberRange.new(5, 9)
	v12.SpreadAngle = Vector2.new(50, 50)
	v12.EmissionDirection = Enum.NormalId.Top
	v12.Rotation = NumberRange.new(-25, 25)
	v12.Acceleration = Vector3.new(0, -30, 0)
	v12.Enabled = false
	v12.Parent = v11
	v12:Emit(p9)
	v_u_1:AddItem(v11, 0.8)
end
return function(p_u_14)
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_13, (copy) v_u_5, (copy) v_u_1
	return {
		["w4_tide_tomoe"] = function(p_u_15, p16)
			-- upvalues: (ref) v_u_4, (copy) p_u_14, (ref) v_u_6, (ref) v_u_13, (ref) v_u_5, (ref) v_u_1
			local v_u_17 = p_u_15.character:GetScale()
			local v_u_18 = v_u_4.color(p16.color)
			local v19 = p_u_14.rgb(130, 240, 226)
			local v20 = p_u_14.rgb(150, 105, 235)
			local v21 = p_u_14.rgb(8, 16, 18)
			local v_u_22 = p_u_14.rgb(228, 255, 250)
			local v_u_26 = p_u_14.throb(p_u_15, 3.8, 1.4, 1.2, function(p23)
				-- upvalues: (ref) p_u_14, (copy) p_u_15, (ref) v_u_4, (copy) v_u_18, (ref) v_u_6, (ref) v_u_13, (copy) v_u_22, (copy) v_u_17
				local v24 = p_u_14.feetAt(p_u_15, p23, 0.15)
				v_u_4.ring(v24, v_u_18, 5 * p_u_15.fx, 0.5, v_u_6.Ring)
				local v25 = v_u_17
				v_u_13(v24 + Vector3.new(0, 0.4, 0), v_u_22, 3, 2.2 * v_u_17 * p_u_15.fx / math.max(v25, 1))
			end)
			local v_u_27 = 2.7 * v_u_17
			local v_u_37 = p_u_14.group(p_u_15, function(p28, p29)
				-- upvalues: (copy) v_u_26, (copy) v_u_17
				local v30 = CFrame.new
				local v31 = 0
				local v32 = v_u_26()
				local v33
				if v32 > 0 then
					local v34 = (1 - v32) * 3.141592653589793
					v33 = math.sin(v34)
				else
					v33 = 0
				end
				local v35 = v33 * 1.7 + -0.55
				local v36 = p29 * 1.3
				return p28 * v30(v31, (v35 + math.sin(v36) * 0.06) * v_u_17, 0) * CFrame.Angles(0.2, 0, -0.12)
			end)
			local v_u_38 = p_u_14.bar(Vector3.new(0.2, 0.2, 0.2), v_u_18, 1)
			p_u_14.pin(p_u_15, v_u_37, v_u_38, CFrame.identity)
			local function v57(p39, p40, p41, p42, p43, p44) -- name: arc
				-- upvalues: (copy) v_u_27, (copy) v_u_38, (copy) v_u_17
				local function v53(p45) -- name: at
					-- upvalues: (ref) v_u_27, (ref) v_u_38
					local v46 = Instance.new("Attachment")
					local v47 = math.cos(p45) * v_u_27
					local v48 = math.sin(p45) * v_u_27
					local v49 = Vector3.new(v47, 0, v48)
					local v50 = CFrame.fromMatrix
					local v51 = -math.sin(p45)
					local v52 = math.cos(p45)
					v46.CFrame = v50(v49, Vector3.new(v51, 0, v52), Vector3.new(0, 1, 0))
					v46.Parent = v_u_38
					return v46
				end
				local v54 = Instance.new("Beam")
				v54.Attachment0 = v53(p39)
				v54.Attachment1 = v53(p40)
				local v55 = (p40 - p39) / 4
				local v56 = math.tan(v55) * 1.3333333333333333 * v_u_27
				v54.CurveSize0 = v56
				v54.CurveSize1 = v56
				v54.Width0 = p41
				v54.Width1 = p41
				v54.Segments = 10
				v54.FaceCamera = true
				v54.Color = ColorSequence.new(p43)
				v54.Transparency = NumberSequence.new(p44)
				v54.LightInfluence = 0
				if p42 then
					v54.Texture = p42
					v54.TextureMode = Enum.TextureMode.Wrap
					v54.TextureLength = 3 * v_u_17
					v54.TextureSpeed = 1.6
					v54.LightEmission = 0.25
				else
					v54.LightEmission = 0.8
				end
				v54.Parent = v_u_38
			end
			for v58 = 0, 3 do
				local v59 = v58 * 3.141592653589793 / 2
				v57(v59, v59 + 1.5707963267948966, 1.5 * v_u_17, v_u_6.TideWater, Color3.new(1, 1, 1), 0)
				v57(v59, v59 + 1.5707963267948966, 0.55 * v_u_17, nil, v_u_18, 0.45)
			end
			p_u_14.pin(p_u_15, v_u_37, p_u_14.picture((v_u_27 + 0.6 * v_u_17) * 2, v_u_6.Ring, v20, 0.3), CFrame.identity)
			for v_u_60 = 0, 5 do
				local v61 = p_u_14.dark(p_u_14.ball(0.62 * v_u_17, v21, 0, Enum.Material.SmoothPlastic))
				p_u_14.add(p_u_15, v61, function(_, p62)
					-- upvalues: (copy) v_u_60, (copy) v_u_37, (copy) v_u_27, (copy) v_u_17
					local v63 = p62 * 1.8 + v_u_60 * 3.141592653589793 / 3
					return v_u_37.cf * CFrame.new(math.cos(v63) * v_u_27, 0.2 * v_u_17, math.sin(v63) * v_u_27)
				end)
				local v64 = p_u_14.blob(Vector3.new(0.28, 0.28, 0.7) * v_u_17, v21, 0, Enum.Material.SmoothPlastic)
				p_u_14.add(p_u_15, v64, function(_, p65)
					-- upvalues: (copy) v_u_60, (copy) v_u_27, (copy) v_u_17, (copy) v_u_37
					local v66 = p65 * 1.8 + v_u_60 * 3.141592653589793 / 3 - 0.2
					local v67 = v_u_27 - 0.12 * v_u_17
					local v68 = math.cos(v66) * v67
					local v69 = 0.2 * v_u_17
					local v70 = math.sin(v66) * v67
					local v71 = Vector3.new(v68, v69, v70)
					local v72 = -math.sin(v66)
					local v73 = math.cos(v66)
					local v74 = Vector3.new(v72, 0, v73)
					return v_u_37.cf * CFrame.lookAt(v71, v71 + v74)
				end)
			end
			local v_u_75 = Instance.new("Attachment")
			local v76 = 0.3 * v_u_17
			v_u_75.Position = Vector3.new(0, v76, 0)
			local v_u_77 = Instance.new("ParticleEmitter")
			v_u_77.Texture = v_u_6.TideBubble
			v_u_77.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_77.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_77.LightInfluence = 0
			v_u_77.Color = ColorSequence.new(v19)
			v_u_77.LightEmission = 0.3
			v_u_77.Size = NumberSequence.new(0.42 * v_u_17 * p_u_15.fx / math.max(v_u_17, 1), 0.3 * v_u_17)
			v_u_77.Lifetime = NumberRange.new(1.2, 1.7)
			v_u_77.Speed = NumberRange.new(1.5, 3)
			v_u_77.Drag = 1.2
			v_u_77.Acceleration = Vector3.new(0, 2.5, 0)
			v_u_77.SpreadAngle = Vector2.new(180, 180)
			v_u_77.Rate = (p_u_15.fx > 1 and 1.6 or 1) * 5
			v_u_77:SetAttribute("BaseRate", v_u_77.Rate)
			v_u_77.Rate = v_u_77.Rate * v_u_5.formRate()
			v_u_77.Parent = v_u_75
			v_u_75.Parent = p_u_15.root
			p_u_14.own(p_u_15, v_u_75)
			local v78 = p_u_15.stops
			local function v79()
				-- upvalues: (copy) v_u_77, (ref) v_u_1, (copy) v_u_75
				v_u_77.Enabled = false
				v_u_1:AddItem(v_u_75, 2)
			end
			table.insert(v78, v79)
			p_u_14.particles(p_u_15, "AuraMode", v_u_18, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
			p_u_14.particles(p_u_15, "Petals", v19, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end