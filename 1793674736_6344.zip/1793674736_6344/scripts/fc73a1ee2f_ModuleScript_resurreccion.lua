local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("F2EBD9")
local v_u_8 = Color3.fromRGB(196, 186, 165)
local v_u_9 = Color3.fromRGB(8, 110, 100)
local v_u_10 = Color3.fromRGB(14, 40, 38)
local v_u_11 = Color3.fromRGB(200, 214, 220)
local v_u_12 = Enum.PartType.Wedge
local v_u_13 = Enum.Material.SmoothPlastic
local v_u_14 = CFrame.identity
local function v_u_23(p15, p16, p17, p18, p19, p20) -- name: stamp
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v21 = Instance.new("Attachment")
	v21.WorldCFrame = CFrame.new(p15)
	v21.Parent = v_u_3.Terrain
	local v22 = Instance.new("ParticleEmitter")
	v22.Enabled = false
	v22.Texture = p16
	v22.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v22.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v22.Color = ColorSequence.new(p17)
	v22.LightEmission = 0.2
	v22.LightInfluence = 0
	v22.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v22.EmissionDirection = Enum.NormalId.Top
	v22.SpreadAngle = Vector2.zero
	v22.Speed = NumberRange.new(0.01)
	v22.Size = NumberSequence.new(p18 / 2, p19 / 2)
	v22.Transparency = NumberSequence.new(0, 0.3)
	v22.Lifetime = NumberRange.new(p20)
	v22.Parent = v21
	v22:Emit(1)
	v_u_1:AddItem(v21, p20 + 0.2)
end
return function(p_u_24)
	-- upvalues: (copy) v_u_4, (copy) v_u_23, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7, (copy) v_u_13, (copy) v_u_14, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_5, (copy) v_u_8, (copy) v_u_9
	return {
		["w7_resurreccion"] = function(p_u_25, p26)
			-- upvalues: (ref) v_u_4, (copy) p_u_24, (ref) v_u_23, (ref) v_u_6, (ref) v_u_2, (ref) v_u_7, (ref) v_u_13, (ref) v_u_14, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
			local v_u_27 = v_u_4.color(p26.color)
			local v28 = p_u_25.headY / 1.5
			local v_u_29 = math.clamp(v28, 0.7, 3)
			local v_u_31 = p_u_24.throb(p_u_25, 5.5, 2.45, 1.6, function(p30)
				-- upvalues: (ref) v_u_23, (ref) p_u_24, (copy) p_u_25, (ref) v_u_6, (copy) v_u_27, (copy) v_u_29
				v_u_23(p_u_24.feetAt(p_u_25, p30, 0.12), v_u_6.HollowRing, v_u_27, v_u_29 * 2, v_u_29 * 9 * p_u_25.fx, 0.55)
			end)
			local v41 = p_u_24.group(p_u_25, function(p32, p33)
				-- upvalues: (copy) v_u_29, (copy) p_u_25
				local v34 = CFrame.new
				local v35 = v_u_29 * -0.95
				local v36 = p_u_25.headY + v_u_29 * 0.45
				local v37 = p33 * 1.6
				local v38 = p32 * v34(v35, v36 + math.sin(v37) * 0.08 * v_u_29, v_u_29 * -0.1)
				local v39 = CFrame.Angles
				local v40 = p33 * 1.1
				return v38 * v39(-0.13962634015954636, 0.4886921905584123, math.sin(v40) * 0.05 + 0.3839724354387525)
			end)
			local v42 = v_u_2:FindFirstChild("EyePieces")
			if v42 then
				v42 = v42:FindFirstChild("w7_resurreccion")
			end
			local v_u_43 = nil
			if v42 and v42:IsA("MeshPart") then
				local v44 = v42:Clone()
				local v45 = v42.Size
				local v46 = v_u_29 * 1.9
				local v47 = v42.Size.X
				local v48 = v42.Size.Y
				local v49 = v42.Size.Z
				v44.Size = v45 * (v46 / math.max(v47, v48, v49, 0.01))
				v_u_43 = v44:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_43 then
					v44.Color = v_u_7
					v44.Material = v_u_13
				end
				v44.Anchored = true
				v44.CanCollide = false
				v44.CanQuery = false
				v44.CanTouch = false
				v44.CastShadow = false
				v44.Massless = true
				v44.Parent = v_u_4.folder()
				p_u_24.pin(p_u_25, v41, v44, v_u_14)
			else
				local v50 = p_u_24.pin
				local v51 = p_u_24.bar
				local v52 = v_u_29 * 1.3
				local v53 = v_u_29 * 0.5
				local v54 = v_u_29 * 0.3
				v50(p_u_25, v41, v51(Vector3.new(v52, v53, v54), v_u_7, 0, v_u_13), CFrame.new(0, v_u_29 * 0.35, 0))
				local v55 = p_u_24.pin
				local v56 = p_u_24.bar
				local v57 = v_u_29 * 0.75
				local v58 = v_u_29 * 0.9
				local v59 = v_u_29 * 0.25
				v55(p_u_25, v41, v56(Vector3.new(v57, v58, v59), v_u_7, 0, v_u_13), CFrame.new(v_u_29 * 0.25, v_u_29 * -0.3, 0))
				local v60 = p_u_24.pin
				local v61 = p_u_24.bar
				local v62 = v_u_29 * 0.32
				local v63 = v_u_29 * 0.22
				local v64 = v_u_29 * 0.1
				v60(p_u_25, v41, v61(Vector3.new(v62, v63, v64), v_u_10, 0, v_u_13), CFrame.new(v_u_29 * -0.2, v_u_29 * 0.02, v_u_29 * -0.16))
			end
			local v_u_74 = p_u_24.group(p_u_25, function(p65, p66)
				-- upvalues: (copy) v_u_29
				local v67 = CFrame.new
				local v68 = v_u_29 * -1.25
				local v69 = v_u_29 * -0.55
				local v70 = p66 * 1.3 + 1
				local v71 = p65 * v67(v68, v69 + math.sin(v70) * 0.08 * v_u_29, v_u_29 * 0.15)
				local v72 = CFrame.Angles
				local v73 = p66 * 0.9
				return v71 * v72(0, 0, math.sin(v73) * 0.05 + -1.0821041362364843)
			end)
			local v75 = p_u_24.pin
			local v76 = p_u_24.bar
			local v77 = v_u_29 * 0.75
			local v78 = v_u_29 * 0.17
			local v79 = v_u_29 * 0.17
			v75(p_u_25, v_u_74, v76(Vector3.new(v77, v78, v79), v_u_10, 0, v_u_13), CFrame.new(v_u_29 * -1.25, 0, 0))
			local v80 = p_u_24.pin
			local v81 = p_u_24.bar
			local v82 = v_u_29 * 0.09
			local v83 = v_u_29 * 0.42
			local v84 = v_u_29 * 0.3
			v80(p_u_25, v_u_74, v81(Vector3.new(v82, v83, v84), v_u_27, 0, v_u_13), CFrame.new(v_u_29 * -0.85, 0, 0))
			local v85 = p_u_24.pin
			local v86 = p_u_24.bar
			local v87 = v_u_29 * 1
			local v88 = v_u_29 * 0.17
			local v89 = v_u_29 * 0.05
			v85(p_u_25, v_u_74, v86(Vector3.new(v87, v88, v89), v_u_11, 0, v_u_13), CFrame.new(v_u_29 * -0.3, 0, 0))
			local v98 = p_u_24.group(p_u_25, function(_, p90)
				-- upvalues: (copy) v_u_74, (copy) v_u_29
				local v91 = v_u_74.cf
				local v92 = CFrame.new
				local v93 = v_u_29 * 1.05
				local v94 = p90 * 2.1
				local v95 = v91 * v92(v93 + math.sin(v94) * 0.06 * v_u_29, v_u_29 * 0.08, 0)
				local v96 = CFrame.Angles
				local v97 = p90 * 1.7
				return v95 * v96(0, 0, math.sin(v97) * 0.06 + 0.15707963267948966)
			end)
			local v99 = p_u_24.pin
			local v100 = p_u_24.bar
			local v101 = v_u_29 * 0.7
			local v102 = v_u_29 * 0.17
			local v103 = v_u_29 * 0.05
			v99(p_u_25, v98, v100(Vector3.new(v101, v102, v103), v_u_11, 0, v_u_13), CFrame.identity)
			local v104 = p_u_24.bar
			local v105 = v_u_29 * 0.05
			local v106 = v_u_29 * 0.085
			local v107 = v_u_29 * 0.3
			local v108 = v104(Vector3.new(v105, v106, v107), v_u_11, 0, v_u_13)
			v108.Shape = v_u_12
			p_u_24.pin(p_u_25, v98, v108, CFrame.new(v_u_29 * 0.5, v_u_29 * 0.042, 0) * CFrame.Angles(0, -1.5707963267948966, 0))
			local v109 = p_u_24.bar
			local v110 = v_u_29 * 0.3
			local v111 = v_u_29 * 0.3
			local v112 = v_u_29 * 0.3
			local v113 = v109(Vector3.new(v110, v111, v112), v_u_27, 1)
			v113.Massless = true
			p_u_24.add(p_u_25, v113, function()
				-- upvalues: (copy) v_u_74, (copy) v_u_29
				return v_u_74.cf * CFrame.new(v_u_29 * 0.42, 0, 0)
			end)
			local v114 = Instance.new("ParticleEmitter")
			v114.Texture = v_u_6.FxTwinkle
			v114.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v114.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v114.Color = ColorSequence.new(v_u_27)
			v114.LightEmission = 0.5
			v114.LightInfluence = 0
			v114.Size = NumberSequence.new(v_u_29 * 0.35 * p_u_25.fx, 0.1)
			v114.Lifetime = NumberRange.new(0.4, 0.6)
			v114.Speed = NumberRange.new(0.5, 1.5)
			v114.SpreadAngle = Vector2.new(180, 180)
			v114:SetAttribute("BaseRate", 6)
			v114.Rate = 6 * v_u_5.formRate()
			v114.Parent = v113
			p_u_24.own(p_u_25, v114)
			local v_u_115 = 0
			local v116 = p_u_25.ticks
			local function v118(_, _, p117)
				-- upvalues: (ref) v_u_115, (copy) v_u_31
				v_u_115 = v_u_115 + p117 * (1.1 + v_u_31() * 3)
			end
			table.insert(v116, v118)
			local v_u_119 = v_u_115
			for v_u_120 = 1, 6 do
				local v121 = p_u_24.bar
				local v122 = v_u_29 * 0.2
				local v123 = v_u_29 * 0.8
				local v124 = v_u_29 * 1.25
				local v125 = Vector3.new(v122, v123, v124)
				local v126
				if v_u_120 % 2 == 0 then
					v126 = v_u_7
				else
					v126 = v_u_8
				end
				local v127 = v121(v125, v126, 0, v_u_13)
				v127.Shape = v_u_12
				p_u_24.tail(v127, v_u_27, v_u_9, v_u_29 * 0.5, 0.3)
				p_u_24.add(p_u_25, v127, function(p128, p129)
					-- upvalues: (ref) v_u_119, (copy) v_u_120, (copy) v_u_29, (copy) p_u_25
					local v130 = v_u_119 + v_u_120 * 3.141592653589793 * 2 / 6
					local v131
					if p129 < 2.2 then
						v131 = 0
					else
						local v132 = (p129 - 2.2) % 5.5
						if v132 < 0.25 then
							local v133 = v132 / 0.25
							local v134 = math.clamp(v133, 0, 1)
							v131 = v134 * v134 * (3 - v134 * 2)
						elseif v132 < 0.6 then
							v131 = 1
						elseif v132 < 1.05 then
							local v135 = (v132 - 0.25 - 0.35) / 0.45
							local v136 = math.clamp(v135, 0, 1)
							v131 = 1 - v136 * v136 * (3 - v136 * 2)
						else
							v131 = 0
						end
					end
					local v137 = v_u_29 * 2.3
					local v138 = CFrame.new
					local v139 = p128.Position
					local v140 = v_u_29 * -0.3
					local v141 = v138(v139 + Vector3.new(0, v140, 0)) * CFrame.Angles(0.3, 0, -0.15) * CFrame.Angles(0, -v130, 0)
					local v142 = CFrame.new
					local v143 = p129 * 2 + v_u_120
					return (v141 * v142(v137, math.sin(v143) * 0.12 * v_u_29, 0)):Lerp(p128 * CFrame.new(0, p_u_25.headY + v_u_29 * 0.1, 0) * CFrame.Angles(0, v_u_120 * 3.141592653589793 * 2 / 6 + p129 * 0.4, 0) * CFrame.new(v_u_29 * 0.95, 0, 0) * CFrame.Angles(1.5707963267948966, 0, 1.5707963267948966), v131)
				end)
			end
			if v_u_43 then
				local v_u_144 = v_u_43.EmissiveStrength
				local v_u_145 = -1
				local v146 = p_u_25.ticks
				local function v149()
					-- upvalues: (copy) v_u_31, (ref) v_u_145, (copy) v_u_43, (copy) v_u_144
					local v147 = v_u_31() * 10
					local v148 = math.floor(v147) / 10
					if v148 ~= v_u_145 then
						v_u_145 = v148
						v_u_43.EmissiveStrength = v_u_144 * (v148 * 2 + 1)
					end
				end
				table.insert(v146, v149)
			end
			p_u_24.particles(p_u_25, "AuraMode", v_u_27, {
				["rate"] = 0.32,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end