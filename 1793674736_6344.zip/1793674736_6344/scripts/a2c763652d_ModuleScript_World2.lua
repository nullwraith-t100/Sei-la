local v1 = {
	["moon_monk"] = {
		["shirt"] = 11978455535,
		["pants"] = 11978459211,
		["accessories"] = nil,
		["skin"] = "#F0D6BE",
		["accessories"] = { 136596639280402, 90087260422573, 111471878638425 }
	},
	["night_fox"] = {
		["shirt"] = 15711302750,
		["pants"] = 14542702516,
		["accessories"] = nil,
		["skin"] = "#2E3366",
		["accessories"] = { 123405869482327, 134756701954397 }
	},
	["lotus_guard"] = {
		["shirt"] = 97378947938447,
		["pants"] = 7550010114,
		["accessories"] = nil,
		["skin"] = "#F2C9A8",
		["accessories"] = { 99332060071454, 77549150127127 }
	},
	["koi_spirit"] = {
		["shirt"] = 15384349583,
		["pants"] = 6283435552,
		["accessories"] = nil,
		["skin"] = "#FFF6EE",
		["accessories"] = { 15365722229, 4627462330 }
	},
	["jade_warrior"] = {
		["shirt"] = 115813719754849,
		["pants"] = 117909609670200,
		["accessories"] = nil,
		["skin"] = "#E8C8A0",
		["accessories"] = { 95901950161741, 100446057710859 }
	},
	["jade_lion"] = {
		["shirt"] = 295595788,
		["pants"] = 6770858124,
		["accessories"] = nil,
		["skin"] = "#4FB888",
		["accessories"] = { 80407217883529, 14022765607 }
	},
	["jade_emperor"] = {
		["shirt"] = 8993154754,
		["pants"] = 13716136781,
		["accessories"] = nil,
		["skin"] = "#F2D2B0",
		["accessories"] = { 117506233319246, 81863791624377, 110666714783481 }
	},
	["shroom_brute"] = {
		["shirt"] = 11464990284,
		["pants"] = 7156542047,
		["accessories"] = nil,
		["skin"] = "#EFE4D0",
		["accessories"] = { 88574238464556, 114626928743605 }
	},
	["spore_imp"] = {
		["shirt"] = 111271110850998,
		["pants"] = 131353069498383,
		["accessories"] = nil,
		["skin"] = "#8A55D8",
		["accessories"] = { 93808277803658, 109218753030088 }
	},
	["coral_knight"] = {
		["shirt"] = 118400353455601,
		["pants"] = 122966619667825,
		["accessories"] = nil,
		["skin"] = "#7FC8D8",
		["accessories"] = { 90856729434570, 18233866934 }
	},
	["reef_shark"] = {
		["shirt"] = 7947410000,
		["pants"] = 14354201249,
		["accessories"] = nil,
		["skin"] = "#5A7A9A",
		["accessories"] = { 101625321669647, 124073101520604 }
	},
	["gear_soldier"] = {
		["shirt"] = 14579806641,
		["pants"] = 14579692797,
		["accessories"] = nil,
		["skin"] = "#B8864A",
		["accessories"] = { 14676485148, 74989820749647 }
	},
	["brass_hound"] = {
		["shirt"] = 136655608899866,
		["pants"] = 15306549344,
		["accessories"] = nil,
		["skin"] = "#C8964A",
		["accessories"] = { 84424902945562, 131983131822675, 91067024199955 }
	},
	["clockwork_titan"] = {
		["shirt"] = 120939863284196,
		["pants"] = 17507733525,
		["accessories"] = nil,
		["skin"] = "#B8864A",
		["accessories"] = { 12307591620, 136566997944979, 19005089567 }
	},
	["obsidian_golem"] = {
		["shirt"] = 136897201295241,
		["pants"] = 509552818,
		["accessories"] = nil,
		["skin"] = "#1E1A26",
		["accessories"] = { 15121204670, 121029432800989, 71535703398170 }
	},
	["glass_wraith"] = {
		["shirt"] = 78809563046005,
		["pants"] = 73394723766210,
		["accessories"] = nil,
		["skin"] = "#120E1C",
		["accessories"] = { 83740623501097, 93988441783824 }
	},
	["aurora_yeti"] = {
		["shirt"] = 11874450330,
		["pants"] = 11874442941,
		["accessories"] = nil,
		["skin"] = "#3A2E5A",
		["accessories"] = { 83642459657208, 76163725225067 }
	},
	["polar_spirit"] = {
		["shirt"] = 6020880741,
		["pants"] = 102074078527181,
		["accessories"] = nil,
		["skin"] = "#E8F4FF",
		["accessories"] = { 11947607560, 117577891760550 }
	},
	["storm_oni"] = {
		["shirt"] = 187669800,
		["pants"] = 9960607390,
		["accessories"] = nil,
		["skin"] = "#4A7AE0",
		["accessories"] = { 16393083293 }
	},
	["thunder_beast"] = {
		["shirt"] = 10274788329,
		["pants"] = 10716963303,
		["accessories"] = nil,
		["skin"] = "#2A2A3A",
		["accessories"] = { 133770962854815, 17039281680 }
	},
	["raijin"] = {
		["shirt"] = 15929055817,
		["pants"] = 324580462,
		["accessories"] = nil,
		["skin"] = "#3A62D8",
		["accessories"] = { 17191637827, 14603359406, 79540317602981 }
	},
	["forge_smith"] = {
		["shirt"] = 987696890,
		["pants"] = 987696995,
		["accessories"] = nil,
		["skin"] = "#C98B5E",
		["accessories"] = { 81324103746983, 91050231532549 }
	},
	["solar_golem"] = {
		["shirt"] = 17051197214,
		["pants"] = 85439979237455,
		["accessories"] = nil,
		["skin"] = "#F2B83A",
		["accessories"] = { 130221062202389, 8721404757 }
	},
	["abyss_lurker"] = {
		["shirt"] = 116821829849409,
		["pants"] = 78833853836616,
		["accessories"] = nil,
		["skin"] = "#1A2E3A",
		["accessories"] = { 89202510770546, 127136148586772 }
	},
	["rune_wraith"] = {
		["shirt"] = 120033948587093,
		["pants"] = 111944718118130,
		["accessories"] = nil,
		["skin"] = "#0E0A14",
		["accessories"] = { 98483751636814, 82114350396634 }
	},
	["spirit_archer"] = {
		["shirt"] = 60636050,
		["pants"] = 11872287136,
		["accessories"] = nil,
		["skin"] = "#D8FFF4",
		["accessories"] = { 82541542368069, 111038659250364 }
	},
	["ghost_stag"] = {
		["shirt"] = 116486600766183,
		["pants"] = 108218794495031,
		["accessories"] = nil,
		["skin"] = "#E8FFF8",
		["accessories"] = { 129926068267141, 78400663320816 }
	},
	["elder_spirit"] = {
		["shirt"] = 132989973675847,
		["pants"] = 120063009719509,
		["accessories"] = nil,
		["skin"] = "#F4F0E0",
		["accessories"] = {
			109241550793892,
			136829803243987,
			113994107596962,
			86466354693252
		}
	},
	["star_drifter"] = {
		["shirt"] = 9920464326,
		["pants"] = 10587242291,
		["accessories"] = nil,
		["skin"] = "#1A1E4A",
		["accessories"] = { 15611430170, 71812076663713 }
	},
	["meteor_golem"] = {
		["shirt"] = 8359531984,
		["pants"] = 8359532241,
		["accessories"] = nil,
		["skin"] = "#4A4A5E",
		["accessories"] = { 7669682109, 128292289091037 }
	},
	["gate_guardian"] = {
		["shirt"] = 10852106631,
		["pants"] = 4532216123,
		["accessories"] = nil,
		["skin"] = "#F2D2B0",
		["accessories"] = { 15017946150, 106795412984963, 75537076991526 }
	},
	["seraph_knight"] = {
		["shirt"] = 18567355278,
		["pants"] = 18567344116,
		["accessories"] = nil,
		["skin"] = "#F8E0C8",
		["accessories"] = { 82647107573644, 79701908174596, 120799305738049 }
	},
	["void_samurai"] = {
		["shirt"] = 13120962582,
		["pants"] = 4705764374,
		["accessories"] = nil,
		["skin"] = "#2A2238",
		["accessories"] = { 18787405095, 114945382809006, 104515455478937 }
	},
	["void_assassin"] = {
		["shirt"] = 358008966,
		["pants"] = 77091223987516,
		["accessories"] = nil,
		["skin"] = "#1A1428",
		["accessories"] = { 137992110649122, 90913704816008 }
	},
	["void_king"] = {
		["shirt"] = 110758528948554,
		["pants"] = 76006351475219,
		["accessories"] = nil,
		["skin"] = "#1E1828",
		["accessories"] = {
			15329227838,
			133327439931912,
			91178295536837,
			71535703398170
		}
	}
}
return v1