local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.GamuzaMaw,
	v_u_7.GamuzaChevron,
	v_u_7.GamuzaHoof,
	v_u_7.GamuzaDrill,
	v_u_7.HollowRing,
	v_u_7.CeroOrb,
	v_u_7.FxTwinkle
})
local v_u_8 = Color3.fromHex("3FD9A0")
local v_u_9 = Color3.fromHex("FF6FB5")
local v_u_10 = Color3.fromRGB(16, 110, 78)
local v_u_11 = Color3.fromRGB(205, 30, 120)
local v_u_12 = Color3.fromRGB(170, 255, 220)
local v_u_13 = Color3.new(1, 1, 1)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_16 = (Vector3.new(-0.438, 0.425, 0.792)).Unit
local function v_u_22(p17, p18) -- name: alignTo
	local v19 = p17:Cross(p18)
	local v20 = p17:Dot(p18)
	local v21 = math.clamp(v20, -1, 1)
	if v19.Magnitude < 0.0001 then
		if v21 > 0 then
			return CFrame.identity
		else
			return CFrame.Angles(0, 3.141592653589793, 0)
		end
	else
		return CFrame.fromAxisAngle(v19.Unit, (math.acos(v21)))
	end
end
local function v_u_27(p23, p24, p25) -- name: sized
	local v26 = math.clamp(p25 or 0.25, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p23 / 2), NumberSequenceKeypoint.new(v26, p24 / 2), NumberSequenceKeypoint.new(1, p24 / 2) })
end
local function v_u_30(p28) -- name: fading
	local v29 = math.clamp(p28 or 0.55, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(v29, 0.1), NumberSequenceKeypoint.new(1, 1) })
end
local function v_u_37(p31, p32, p33, p34) -- name: once
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v35 = Instance.new("Attachment")
	v35.WorldCFrame = p31
	v35.Parent = v_u_3.Terrain
	local v36 = Instance.new("ParticleEmitter")
	v36.Enabled = false
	v36.LightInfluence = 0
	v36.Speed = NumberRange.new(0)
	v36.Lifetime = NumberRange.new(p32)
	p34(v36)
	v36.Parent = v35
	v36:Emit(p33)
	v_u_1:AddItem(v35, p32 + 0.3)
end
local function v_u_53(p38, p39, p_u_40, p_u_41, p_u_42, p_u_43, p44, p45, p_u_46, p_u_47, p_u_48) -- name: plane
	-- upvalues: (copy) v_u_37, (copy) v_u_27, (copy) v_u_30, (copy) v_u_15
	local v49 = p39.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p39.Unit
	local v50 = v49.Y
	local v51
	if math.abs(v50) > 0.98 then
		v51 = CFrame.new(p38) * CFrame.Angles(0, math.rad(p45 or 0), 0)
	else
		v51 = CFrame.fromMatrix(p38, v49:Cross(Vector3.new(0, 1, 0)).Unit, v49)
	end
	v_u_37(v51, p44, 1, function(p52)
		-- upvalues: (copy) p_u_40, (copy) p_u_41, (copy) p_u_48, (ref) v_u_27, (copy) p_u_42, (copy) p_u_43, (ref) v_u_30, (copy) p_u_47, (copy) p_u_46, (ref) v_u_15
		p52.Texture = p_u_40
		p52.Color = ColorSequence.new(p_u_41)
		p52.LightEmission = p_u_48 or 0.2
		p52.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		p52.EmissionDirection = Enum.NormalId.Top
		p52.SpreadAngle = Vector2.zero
		p52.Speed = NumberRange.new(0.01)
		p52.Size = v_u_27(p_u_42, p_u_43)
		p52.Transparency = v_u_30()
		p52.Rotation = NumberRange.new(0)
		p52.RotSpeed = NumberRange.new(p_u_47 or 0)
		if p_u_46 then
			p52.FlipbookLayout = v_u_15
			p52.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
	end)
end
local function v_u_67(p54, p55, p_u_56, p_u_57, p58, p_u_59) -- name: chevronBurst
	-- upvalues: (copy) v_u_37, (copy) v_u_7, (copy) v_u_27, (copy) v_u_30
	local v60 = math.random() * 3.141592653589793 * 2
	for v61 = 1, p55 do
		local v62 = v60 + v61 * 3.141592653589793 * 2 / p55
		local v63 = math.cos(v62)
		local v64 = math.sin(v62)
		local v65 = Vector3.new(v63, 0.08, v64)
		v_u_37(CFrame.lookAt(p54, p54 + v65), p58, 1, function(p66)
			-- upvalues: (ref) v_u_7, (copy) p_u_59, (copy) p_u_56, (ref) v_u_27, (copy) p_u_57, (ref) v_u_30
			p66.Texture = v_u_7.GamuzaChevron
			p66.Color = ColorSequence.new(p_u_59)
			p66.LightEmission = 0.3
			p66.Orientation = Enum.ParticleOrientation.VelocityParallel
			p66.EmissionDirection = Enum.NormalId.Front
			p66.SpreadAngle = Vector2.zero
			p66.Speed = NumberRange.new(p_u_56)
			p66.Drag = 5
			p66.Size = v_u_27(p_u_57 * 0.6, p_u_57, 0.3)
			p66.Transparency = v_u_30(0.4)
		end)
	end
end
local function v_u_74(p68) -- name: newLance
	-- upvalues: (copy) v_u_2, (copy) v_u_8, (copy) v_u_4, (copy) v_u_1, (copy) v_u_22, (copy) v_u_16
	local v69 = v_u_2:FindFirstChild("EyePieces")
	if v69 then
		v69 = v69:FindFirstChild("w7_gamuza")
	end
	if not (v69 and v69:IsA("MeshPart")) then
		local v70 = v_u_4.part(Vector3.new(0.18, 0.18, p68), CFrame.identity, v_u_8)
		v_u_1:AddItem(v70, 6)
		local v71 = CFrame.identity
		local v72 = -p68 / 2
		return v70, v71, Vector3.new(0, 0, v72), false
	end
	local v73 = v69:Clone()
	v73.Size = v69.Size * (p68 / (2.514 * v69.Size.Z / 2))
	if not v73:FindFirstChildWhichIsA("SurfaceAppearance") then
		v73.Color = v_u_8
		v73.Material = Enum.Material.SmoothPlastic
	end
	v73.Anchored = true
	v73.CanCollide = false
	v73.CanQuery = false
	v73.CanTouch = false
	v73.CastShadow = false
	v73.Massless = true
	v73.Parent = v_u_4.folder()
	v_u_1:AddItem(v73, 6)
	return v73, v_u_22(v_u_16, Vector3.new(-0, -0, -1)), v_u_16 * p68 / 2, true
end
local function v_u_81(p75, p76, p77) -- name: shine
	-- upvalues: (copy) v_u_7, (copy) v_u_9, (copy) v_u_8
	local v78 = Instance.new("Attachment")
	v78.Position = p76 * 0.95
	v78.Parent = p75
	local v79 = Instance.new("Attachment")
	v79.Position = -p76 * 0.95
	v79.Parent = p75
	local v80 = Instance.new("Beam")
	v80.Attachment0 = v78
	v80.Attachment1 = v79
	v80.Texture = v_u_7.Beam
	v80.TextureMode = Enum.TextureMode.Stretch
	v80.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, v_u_9),
		ColorSequenceKeypoint.new(0.15, v_u_8),
		ColorSequenceKeypoint.new(0.85, v_u_8),
		ColorSequenceKeypoint.new(1, v_u_9)
	})
	v80.LightEmission = 0.5
	v80.LightInfluence = 0
	v80.Transparency = NumberSequence.new(0.2)
	v80.Width0 = p77
	v80.Width1 = p77
	v80.FaceCamera = true
	v80.Segments = 1
	v80.Parent = p75
end
local function v_u_87(p82, p83, p84) -- name: tipGlow
	-- upvalues: (copy) v_u_7, (copy) v_u_9
	local v85 = Instance.new("Attachment")
	v85.Position = p83
	v85.Parent = p82
	local v86 = Instance.new("ParticleEmitter")
	v86.Texture = v_u_7.Glow
	v86.Color = ColorSequence.new(v_u_9)
	v86.LightEmission = 0.6
	v86.LightInfluence = 0
	v86.LockedToPart = true
	v86.Speed = NumberRange.new(0)
	v86.Lifetime = NumberRange.new(0.12)
	v86.Size = NumberSequence.new(p84 / 2)
	v86.Transparency = NumberSequence.new(0.15, 0.6)
	v86.Rate = 40
	v86.Parent = v85
end
local v_u_88 = {
	{
		["at"] = Vector3.new(-1.1, 4.4, -2.2),
		["phase"] = 0
	},
	{
		["at"] = Vector3.new(1.1, 4.4, -2.2),
		["phase"] = 0.22
	},
	{
		["at"] = Vector3.new(-1.1, 4.4, 3.6),
		["phase"] = 0.55
	},
	{
		["at"] = Vector3.new(1.1, 4.4, 3.6),
		["phase"] = 0.78
	}
}
local function v_u_120(p_u_89, p90, p91) -- name: newCentaur
	-- upvalues: (copy) v_u_14, (copy) v_u_8, (copy) v_u_10, (copy) v_u_74, (copy) v_u_87, (copy) v_u_81, (copy) v_u_4, (copy) v_u_1
	local v_u_92 = Instance.new("Model")
	v_u_92.Name = "GamuzaCentaur"
	local v_u_93 = {}
	local function v101(p94, p95, p96, p97, p98) -- name: block
		-- upvalues: (ref) v_u_14, (copy) p_u_89, (copy) v_u_92, (copy) v_u_93
		local v99
		if p98 then
			v99 = Instance.new("WedgePart")
		else
			v99 = Instance.new("Part")
		end
		v99.Anchored = true
		v99.CanCollide = false
		v99.CanQuery = false
		v99.CanTouch = false
		v99.CastShadow = false
		v99.Material = v_u_14
		v99.Color = p96
		v99.Transparency = p97
		v99.Size = p94 * p_u_89
		v99.CFrame = CFrame.new(0, -500, 0)
		v99.Parent = v_u_92
		local v100 = v_u_93
		table.insert(v100, {
			["p"] = v99,
			["off"] = p95
		})
		return v99
	end
	v101(Vector3.new(3.1, 2.9, 6.4), CFrame.new(p_u_89 * 0, p_u_89 * 5.6, p_u_89 * 0.7), v_u_8, 0.45)
	v101(Vector3.new(2.9, 2.4, 1.8), CFrame.new(p_u_89 * 0, p_u_89 * 5.9, p_u_89 * -3) * CFrame.Angles(0.3141592653589793, 0, 0), v_u_8, 0.45)
	v101(Vector3.new(2.9, 2.5, 2), CFrame.new(p_u_89 * 0, p_u_89 * 5.5, p_u_89 * 4.4) * CFrame.Angles(-0.2792526803190927, 0, 0), v_u_8, 0.45)
	v101(Vector3.new(2.5, 3.2, 1.5), CFrame.new(p_u_89 * 0, p_u_89 * 8.6, p_u_89 * -2.9) * CFrame.Angles(-0.24434609527920614, 0, 0), v_u_8, 0.45)
	v101(Vector3.new(1.5, 1.6, 1.5), CFrame.new(p_u_89 * 0, p_u_89 * 11, p_u_89 * -3.4), v_u_8, 0.25)
	if not p90 then
		for _, v102 in { -1, 1 } do
			local v103 = v102 * 0.75
			local v104 = CFrame.new(v103 * p_u_89, p_u_89 * 11.7, p_u_89 * -2.6)
			local v105 = CFrame.Angles
			local v106 = v102 * 20
			v101(Vector3.new(0.5, 1.2, 2.6), v104 * v105(-0.5235987755982988, math.rad(v106), 0), v_u_10, 0.1, true)
		end
		v101(Vector3.new(0.75, 2.6, 0.75), CFrame.new(p_u_89 * 1.6, p_u_89 * 8.9, p_u_89 * -3.6) * CFrame.Angles(-1.2217304763960306, 0, 0), v_u_8, 0.45)
		v101(Vector3.new(0.75, 2.6, 0.75), CFrame.new(p_u_89 * -0.6, p_u_89 * 8.9, p_u_89 * -4.4) * CFrame.Angles(-1.3962634015954636, -0.4363323129985824, 0), v_u_8, 0.45)
	end
	for v107 = 1, 4 do
		v101(Vector3.new(0.85, 4, 0.95), CFrame.identity, v_u_8, 0.45)
		v_u_93[#v_u_93].leg = v107
		v_u_93[#v_u_93].down = 2
		if p90 then
			continue
		end
		v101(Vector3.new(1, 0.55, 1.15), CFrame.identity, v_u_10, 0.05)
		v_u_93[#v_u_93].leg = v107
		v_u_93[#v_u_93].down = 4.2
	end
	local v108, v109, v110 = v_u_74(p_u_89 * 20)
	v108.Parent = v_u_92
	v_u_87(v108, v110, p_u_89 * 4)
	v_u_81(v108, v110, p_u_89 * 1.7)
	local v111 = Instance.new("Attachment")
	if not p90 then
		local v112 = v_u_93[3].p
		local v113 = Instance.new("Attachment")
		local v114 = p_u_89 * 0.6
		local v115 = p_u_89 * 1
		v113.Position = Vector3.new(0, v114, v115)
		v113.Parent = v112
		v111 = Instance.new("Attachment")
		local v116 = p_u_89 * -0.6
		local v117 = p_u_89 * 1
		v111.Position = Vector3.new(0, v116, v117)
		v111.Parent = v112
		local v118 = Instance.new("Trail")
		v118.Attachment0 = v113
		v118.Attachment1 = v111
		v118.Color = ColorSequence.new(v_u_8, v_u_10)
		v118.Transparency = NumberSequence.new(0.2, 1)
		v118.Lifetime = 0.35
		v118.LightEmission = 0.4
		v118.LightInfluence = 0
		v118.FaceCamera = true
		v118.Parent = v112
		local v119 = Instance.new("Highlight")
		v119.FillColor = v_u_8
		v119.FillTransparency = 1
		v119.OutlineColor = v_u_10
		v119.OutlineTransparency = 0
		v119.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
		v119.Parent = v_u_92
	end
	v_u_92.Parent = v_u_4.folder()
	v_u_1:AddItem(v_u_92, p91)
	return {
		["model"] = v_u_92,
		["bits"] = v_u_93,
		["lance"] = v108,
		["lanceTurn"] = v109,
		["lanceAt"] = CFrame.new(p_u_89 * 1.5, p_u_89 * 8.1, p_u_89 * -5.2),
		["tip"] = v110,
		["k"] = p_u_89,
		["tail"] = v111
	}
end
local function v_u_140(p121, p122, p123, p124) -- name: poseCentaur
	-- upvalues: (copy) v_u_88, (copy) v_u_3
	local v125 = p121.k
	local v126 = math.sin(p123)
	local v127 = math.abs(v126) * 0.45 * v125
	local v128 = p122 * CFrame.new(0, v127, 0) * CFrame.Angles(math.sin(p123) * 0.05, 0, 0)
	local v129 = {}
	local v130 = {}
	for _, v131 in p121.bits do
		local v132 = v131.leg
		local v133
		if v132 then
			local v134 = v_u_88[v132]
			local v135 = p123 + v134.phase * 3.141592653589793 * 2
			local v136 = math.sin(v135)
			v133 = v128 * CFrame.new(v134.at * v125) * CFrame.Angles(v136 * 0.75, 0, 0) * CFrame.new(0, -(v131.down or 0) * v125, (v131.down or 0) <= 4 and 0 or v125 * -0.15)
		else
			v133 = v128 * v131.off
		end
		local v137 = v131.p
		table.insert(v129, v137)
		table.insert(v130, v133)
	end
	local v138 = p121.lance
	table.insert(v129, v138)
	local v139 = v128 * p121.lanceAt * CFrame.new(0, 0, -p124) * p121.lanceTurn
	table.insert(v130, v139)
	v_u_3:BulkMoveTo(v129, v130, Enum.BulkMoveMode.FireCFrameChanged)
end
local function v_u_145(p141, p142) -- name: fadeCentaur
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	for _, v143 in p141.bits do
		v_u_4.tween(v143.p, p142, {
			["Transparency"] = 1,
			["Size"] = nil,
			["Size"] = v143.p.Size * 1.2
		})
	end
	v_u_4.tween(p141.lance, p142, {
		["Transparency"] = 1
	})
	local v144 = p141.model:FindFirstChildOfClass("Highlight")
	if v144 then
		v_u_4.tween(v144, p142, {
			["OutlineTransparency"] = 1,
			["FillTransparency"] = 1
		})
	end
	v_u_1:AddItem(p141.model, p142 + 0.1)
end
return function(p_u_146)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_74, (copy) v_u_7, (copy) v_u_10, (copy) v_u_87, (copy) v_u_81, (copy) v_u_27, (copy) v_u_30, (copy) v_u_53, (copy) v_u_9, (copy) v_u_37, (copy) v_u_15, (copy) v_u_67, (copy) v_u_13, (copy) v_u_11, (copy) v_u_6, (copy) v_u_120, (copy) v_u_140, (copy) v_u_12, (copy) v_u_145
	local v324 = {
		["gamuza_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["keep"] = 0.12,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p147) -- name: cast
				-- upvalues: (ref) v_u_53, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15
				local v148 = p147.size
				local v149 = p147.eye + p147.dir * 1.6
				v_u_53(v149, p147.dir, v_u_7.HollowRing, v_u_8, 1 * v148, 4.5 * v148, 0.25, 0, true, 0, 0.3)
				local v_u_150 = v_u_7.FxTwinkle
				local v_u_151 = v_u_9
				local v_u_152 = 1.5 * v148
				local v_u_153 = 2.5 * v148
				local v_u_154 = 0.5
				local v_u_155 = nil
				local v_u_156 = true
				v_u_37(CFrame.new(v149), 0.2, 1, function(p157)
					-- upvalues: (copy) v_u_150, (copy) v_u_151, (copy) v_u_154, (ref) v_u_27, (copy) v_u_152, (copy) v_u_153, (ref) v_u_30, (copy) v_u_155, (copy) v_u_156, (ref) v_u_15
					p157.Texture = v_u_150
					p157.Color = ColorSequence.new(v_u_151)
					p157.LightEmission = v_u_154 or 0.4
					p157.Size = v_u_27(v_u_152, v_u_153)
					p157.Transparency = v_u_30()
					p157.Rotation = NumberRange.new(0, 360)
					p157.RotSpeed = NumberRange.new(v_u_155 or 0)
					if v_u_156 then
						p157.FlipbookLayout = v_u_15
						p157.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
			end,
			["shot"] = function(p158, p159) -- name: lanceShot
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_74, (ref) v_u_7, (copy) p_u_146, (ref) v_u_10, (ref) v_u_87, (ref) v_u_81, (ref) v_u_27, (ref) v_u_30
				local v160 = p158.size
				local v161 = 5.2 * v160
				local v_u_162 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p159, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_162, 4)
				local v_u_163, v_u_164, v165, _ = v_u_74(v161)
				local v166 = Instance.new("Attachment")
				local v167 = v161 * 0.5
				v166.Position = Vector3.new(0, 0, v167)
				v166.Parent = v_u_162
				local v168 = Instance.new("Attachment")
				local v169 = -v161 * 0.62
				v168.Position = Vector3.new(0, 0, v169)
				v168.Parent = v_u_162
				local v_u_170 = Instance.new("Beam")
				v_u_170.Attachment0 = v166
				v_u_170.Attachment1 = v168
				v_u_170.Texture = v_u_7.GamuzaDrill
				v_u_170.TextureMode = Enum.TextureMode.Wrap
				v_u_170.TextureLength = 1.6 * v160
				v_u_170.TextureSpeed = -7
				v_u_170.Color = ColorSequence.new(v_u_8)
				v_u_170.LightEmission = 0.45
				v_u_170.LightInfluence = 0
				v_u_170.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(0.4, 0.1), NumberSequenceKeypoint.new(1, 0.15) })
				v_u_170.Width0 = 1.6 * v160
				v_u_170.Width1 = 0.25 * v160
				v_u_170.FaceCamera = true
				v_u_170.Segments = 1
				v_u_170.Parent = v_u_162
				p_u_146.streak(v_u_162, v_u_8, v_u_10, 0.9 * v160, 0.14)
				v_u_87(v_u_163, v165, 1.6 * v160)
				v_u_81(v_u_163, v165, 0.45 * v160)
				local v_u_171
				if p158.lite then
					v_u_171 = nil
				else
					v_u_171 = Instance.new("ParticleEmitter")
					v_u_171.Texture = v_u_7.GamuzaChevron
					v_u_171.Color = ColorSequence.new(v_u_8)
					v_u_171.LightEmission = 0.3
					v_u_171.LightInfluence = 0
					v_u_171.Orientation = Enum.ParticleOrientation.VelocityParallel
					v_u_171.EmissionDirection = Enum.NormalId.Back
					v_u_171.SpreadAngle = Vector2.zero
					v_u_171.Rotation = NumberRange.new(180)
					v_u_171.Speed = NumberRange.new(1)
					v_u_171.Lifetime = NumberRange.new(0.22, 0.3)
					v_u_171.Size = v_u_27(0.9 * v160, 0.5 * v160, 0.2)
					v_u_171.Transparency = v_u_30(0.3)
					v_u_171.Rate = 40
					v_u_171.Parent = v166
				end
				local v_u_172 = false
				return {
					["place"] = function(p173, _) -- name: place
						-- upvalues: (copy) v_u_162, (copy) v_u_163, (copy) v_u_164
						v_u_162.CFrame = p173
						v_u_163.CFrame = p173 * v_u_164
					end,
					["stop"] = function(p174) -- name: stop
						-- upvalues: (ref) v_u_172, (ref) v_u_171, (copy) v_u_170, (copy) v_u_163, (ref) v_u_1, (copy) v_u_162, (ref) v_u_4
						if v_u_172 then
							return
						else
							v_u_172 = true
							local v175 = v_u_171
							if v175 then
								v175.Enabled = false
							end
							v_u_170:Destroy()
							local v176 = v_u_163:FindFirstChildWhichIsA("Attachment")
							if v176 then
								v176:Destroy()
							end
							v_u_1:AddItem(v_u_162, 0.4)
							if p174 and p174 > 0 then
								v_u_4.tween(v_u_163, p174, {
									["Transparency"] = 1
								})
								v_u_1:AddItem(v_u_163, p174 + 0.05)
							else
								v_u_163:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p177, p178) -- name: impact
				-- upvalues: (copy) p_u_146, (ref) v_u_53, (ref) v_u_7, (ref) v_u_10, (ref) v_u_67, (ref) v_u_8, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15
				local v179 = p177.size
				local v180 = p_u_146.ground(p178, 0.15)
				v_u_53(v180, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 1.5 * v179, p177.ability.radius * 2.4 * v179, 0.45, 0, true)
				v_u_67(v180 + Vector3.new(0, 0.6, 0), p177.lite and 4 or 7, 26 * v179, 1.3 * v179, 0.32, v_u_8)
				local v_u_181 = v_u_7.Glow
				local v_u_182 = v_u_9
				local v_u_183 = 1.5 * v179
				local v_u_184 = 4 * v179
				local v_u_185 = 0.5
				local v_u_186 = nil
				local v_u_187 = nil
				v_u_37(CFrame.new(p178), 0.16, 1, function(p188)
					-- upvalues: (copy) v_u_181, (copy) v_u_182, (copy) v_u_185, (ref) v_u_27, (copy) v_u_183, (copy) v_u_184, (ref) v_u_30, (copy) v_u_186, (copy) v_u_187, (ref) v_u_15
					p188.Texture = v_u_181
					p188.Color = ColorSequence.new(v_u_182)
					p188.LightEmission = v_u_185 or 0.4
					p188.Size = v_u_27(v_u_183, v_u_184)
					p188.Transparency = v_u_30()
					p188.Rotation = NumberRange.new(0, 360)
					p188.RotSpeed = NumberRange.new(v_u_186 or 0)
					if v_u_187 then
						p188.FlipbookLayout = v_u_15
						p188.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				p_u_146.glint(p178, v_u_9, 3.4 * v179, 0.14)
				p_u_146.hitSound(p178)
			end,
			["hit"] = function(_, p189, _) -- name: hit
				-- upvalues: (copy) p_u_146, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15
				p_u_146.burst("Impact", p189, v_u_8, 0.6)
				local v_u_190 = v_u_7.FxTwinkle
				local v_u_191 = v_u_9
				local v_u_192 = 0.5
				local v_u_193 = 1.5
				local v_u_194 = 3
				local v_u_195 = nil
				local v_u_196 = true
				v_u_37(CFrame.new(p189), 0.3, 1, function(p197)
					-- upvalues: (copy) v_u_190, (copy) v_u_191, (copy) v_u_192, (ref) v_u_27, (copy) v_u_193, (copy) v_u_194, (ref) v_u_30, (copy) v_u_195, (copy) v_u_196, (ref) v_u_15
					p197.Texture = v_u_190
					p197.Color = ColorSequence.new(v_u_191)
					p197.LightEmission = v_u_192 or 0.4
					p197.Size = v_u_27(v_u_193, v_u_194)
					p197.Transparency = v_u_30()
					p197.Rotation = NumberRange.new(0, 360)
					p197.RotSpeed = NumberRange.new(v_u_195 or 0)
					if v_u_196 then
						p197.FlipbookLayout = v_u_15
						p197.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
			end
		},
		["gamuza_e"] = {
			["cast"] = function(p198) -- name: cast
				-- upvalues: (copy) p_u_146, (ref) v_u_9
				p_u_146.skillCast(p198, v_u_9, false, true)
			end,
			["windup"] = function(p199, p200, p201) -- name: windup
				-- upvalues: (ref) v_u_37, (ref) v_u_7, (ref) v_u_13, (ref) v_u_9, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (copy) p_u_146, (ref) v_u_53, (ref) v_u_8, (ref) v_u_4, (ref) v_u_1
				local v_u_202 = p199.size
				local v203 = p199.ability.radius * v_u_202
				local v_u_204 = p199.eye + p199.dir * 3.4 * p199.size + Vector3.new(0, 0.4, 0)
				local v205 = p201 + 0.5
				local v206 = 0.12 / v205
				local v_u_207 = math.clamp(v206, 0.02, 0.5)
				local v208 = (p201 + 0.02) / v205
				local v209 = v_u_207 + 0.02
				local v_u_210 = math.clamp(v208, v209, 0.9)
				v_u_37(CFrame.new(v_u_204), v205, 1, function(p211)
					-- upvalues: (ref) v_u_7, (ref) v_u_13, (copy) v_u_207, (copy) v_u_202, (copy) v_u_210
					p211.Texture = v_u_7.GamuzaMaw
					p211.Color = ColorSequence.new(v_u_13)
					p211.LightEmission = 0
					local v212 = NumberSequence.new
					local v213 = {}
					local v214 = NumberSequenceKeypoint.new(0, 0)
					local v215 = NumberSequenceKeypoint.new(v_u_207, 3.6 * v_u_202)
					local v216 = NumberSequenceKeypoint.new(v_u_210, 2.9 * v_u_202)
					local v217 = NumberSequenceKeypoint.new
					local v218 = v_u_210 + 0.12
					__set_list(v213, 1, {v214, v215, v216, v217(math.min(v218, 0.95), 3.8 * v_u_202), NumberSequenceKeypoint.new(1, 0)})
					p211.Size = v212(v213)
					p211.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.85, 0), NumberSequenceKeypoint.new(1, 1) })
					p211.Rotation = NumberRange.new(0, 360)
					p211.RotSpeed = NumberRange.new(-90)
				end)
				local v_u_219 = v_u_7.Glow
				local v_u_220 = v_u_9
				local v_u_221 = 3 * v_u_202
				local v_u_222 = 10 * v_u_202
				local v_u_223 = 0.4
				local v_u_224 = nil
				local v_u_225 = nil
				v_u_37(CFrame.new(v_u_204), v205, 1, function(p226)
					-- upvalues: (copy) v_u_219, (copy) v_u_220, (copy) v_u_223, (ref) v_u_27, (copy) v_u_221, (copy) v_u_222, (ref) v_u_30, (copy) v_u_224, (copy) v_u_225, (ref) v_u_15
					p226.Texture = v_u_219
					p226.Color = ColorSequence.new(v_u_220)
					p226.LightEmission = v_u_223 or 0.4
					p226.Size = v_u_27(v_u_221, v_u_222)
					p226.Transparency = v_u_30()
					p226.Rotation = NumberRange.new(0, 360)
					p226.RotSpeed = NumberRange.new(v_u_224 or 0)
					if v_u_225 then
						p226.FlipbookLayout = v_u_15
						p226.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v227 = p_u_146.ground(p200, 0.12)
				v_u_53(v227, Vector3.new(0, 1, 0), v_u_7.Glow, v_u_8, v203 * 2.2, v203 * 0.2, p201 + 0.15, 0, false, 0, 0.3)
				local v228 = p199.lite and 4 or 9
				local v229 = p201 + 0.12
				local v230 = math.max(v229, 0.18)
				for _ = 1, v228 do
					local v231 = math.random() * 3.141592653589793 * 2
					local v232 = v203 * (0.2 + math.random() * 0.7)
					local v233 = math.cos(v231) * v232
					local v234 = 1 + math.random() * 2.5
					local v235 = math.sin(v231) * v232
					local v_u_236 = v227 + Vector3.new(v233, v234, v235)
					local v_u_237 = v_u_4.part(Vector3.new(0.35, 0.35, 2.5) * v_u_202, CFrame.lookAt(v_u_236, v_u_204), v_u_8)
					v_u_1:AddItem(v_u_237, v230 + 0.1)
					p_u_146.animate(v230, 0, function(p238)
						-- upvalues: (copy) v_u_236, (copy) v_u_204, (copy) v_u_202, (copy) v_u_237
						local v239 = v_u_236:Lerp(v_u_204, p238 * p238)
						local v240 = (2.5 + 5 * p238) * v_u_202 * (1 - p238 * 0.8)
						local v241 = v_u_237
						local v242 = 0.35 * v_u_202 * (1 - p238 * 0.5)
						local v243 = 0.35 * v_u_202 * (1 - p238 * 0.5)
						local v244 = math.max(v240, 0.2)
						v241.Size = Vector3.new(v242, v243, v244)
						v_u_237.CFrame = CFrame.lookAt(v239, v_u_204)
						if p238 >= 1 then
							v_u_237:Destroy()
						end
					end)
				end
			end,
			["land"] = function(p_u_245, p246) -- name: land
				-- upvalues: (copy) p_u_146, (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (ref) v_u_53, (ref) v_u_10, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_11, (ref) v_u_13, (ref) v_u_6
				local v_u_247 = p_u_245.size
				local v_u_248 = p_u_245.lite
				local v_u_249 = p_u_245.ability.radius * v_u_247
				local v_u_250 = p_u_245.eye + p_u_245.dir * 3.4 * p_u_245.size + Vector3.new(0, 0.4, 0)
				local v_u_251 = p_u_146.ground(p246, 0.15)
				local v_u_252 = v_u_251 + Vector3.new(0, 2, 0)
				local v_u_253 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_250), v_u_9, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_253, 1)
				local v_u_254 = Instance.new("ParticleEmitter")
				v_u_254.Texture = v_u_7.CeroOrb
				v_u_254.FlipbookLayout = v_u_15
				v_u_254.FlipbookMode = Enum.ParticleFlipbookMode.Loop
				v_u_254.Color = ColorSequence.new(v_u_9)
				v_u_254.LightEmission = 0.2
				v_u_254.LightInfluence = 0
				v_u_254.LockedToPart = true
				v_u_254.Speed = NumberRange.new(0)
				v_u_254.Lifetime = NumberRange.new(0.12)
				v_u_254.Size = NumberSequence.new(2.4 * v_u_247)
				v_u_254.Rate = 30
				v_u_254.Parent = v_u_253
				local v_u_255 = Instance.new("ParticleEmitter")
				v_u_255.Texture = v_u_7.Glow
				v_u_255.Color = ColorSequence.new(v_u_8)
				v_u_255.LightEmission = 0.5
				v_u_255.LightInfluence = 0
				v_u_255.LockedToPart = true
				v_u_255.Speed = NumberRange.new(0)
				v_u_255.Lifetime = NumberRange.new(0.1)
				v_u_255.Size = NumberSequence.new(3.6 * v_u_247)
				v_u_255.Transparency = NumberSequence.new(0.3)
				v_u_255.Rate = 30
				v_u_255.Parent = v_u_253
				v_u_254:Emit(1)
				v_u_255:Emit(1)
				p_u_146.streak(v_u_253, v_u_9, v_u_8, 2 * v_u_247, 0.18)
				p_u_146.animate(0.16, 0, function(p256)
					-- upvalues: (copy) v_u_253, (copy) v_u_250, (copy) v_u_252, (copy) v_u_254, (copy) v_u_255, (ref) v_u_1, (ref) v_u_53, (copy) v_u_251, (ref) v_u_7, (ref) v_u_10, (copy) v_u_247, (copy) v_u_249, (ref) v_u_8, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) p_u_146, (copy) v_u_248, (ref) v_u_11, (ref) v_u_9, (ref) v_u_13, (ref) v_u_6, (copy) p_u_245, (ref) v_u_4
					local v257 = v_u_253
					local v258 = CFrame.new
					local v259 = v_u_250:Lerp(v_u_252, p256)
					local v260 = p256 * 3.141592653589793
					v257.CFrame = v258(v259 + Vector3.new(0, 1, 0) * math.sin(v260) * 1.5)
					if p256 >= 1 then
						v_u_254.Enabled = false
						v_u_255.Enabled = false
						v_u_1:AddItem(v_u_253, 0.3)
						v_u_53(v_u_251, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 3 * v_u_247, v_u_249 * 1.6, 0.5, 0, true, 120)
						local v261 = v_u_252
						local v_u_262 = v_u_7.Glow
						local v_u_263 = v_u_8
						local v_u_264 = v_u_249 * 0.3
						local v_u_265 = v_u_249 * 0.9
						local v_u_266 = 0.5
						local v_u_267 = nil
						local v_u_268 = nil
						v_u_37(CFrame.new(v261), 0.22, 1, function(p269)
							-- upvalues: (copy) v_u_262, (copy) v_u_263, (copy) v_u_266, (ref) v_u_27, (copy) v_u_264, (copy) v_u_265, (ref) v_u_30, (copy) v_u_267, (copy) v_u_268, (ref) v_u_15
							p269.Texture = v_u_262
							p269.Color = ColorSequence.new(v_u_263)
							p269.LightEmission = v_u_266 or 0.4
							p269.Size = v_u_27(v_u_264, v_u_265)
							p269.Transparency = v_u_30()
							p269.Rotation = NumberRange.new(0, 360)
							p269.RotSpeed = NumberRange.new(v_u_267 or 0)
							if v_u_268 then
								p269.FlipbookLayout = v_u_15
								p269.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						local v270 = v_u_252
						local v_u_271 = v_u_7.HollowRing
						local v_u_272 = v_u_8
						local v_u_273 = 2 * v_u_247
						local v_u_274 = v_u_249 * 1.2
						local v_u_275 = 0.3
						local v_u_276 = 120
						local v_u_277 = true
						v_u_37(CFrame.new(v270), 0.4, 1, function(p278)
							-- upvalues: (copy) v_u_271, (copy) v_u_272, (copy) v_u_275, (ref) v_u_27, (copy) v_u_273, (copy) v_u_274, (ref) v_u_30, (copy) v_u_276, (copy) v_u_277, (ref) v_u_15
							p278.Texture = v_u_271
							p278.Color = ColorSequence.new(v_u_272)
							p278.LightEmission = v_u_275 or 0.4
							p278.Size = v_u_27(v_u_273, v_u_274)
							p278.Transparency = v_u_30()
							p278.Rotation = NumberRange.new(0, 360)
							p278.RotSpeed = NumberRange.new(v_u_276 or 0)
							if v_u_277 then
								p278.FlipbookLayout = v_u_15
								p278.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						p_u_146.spikes(v_u_252, v_u_8, v_u_248 and 4 or 9, 12 * v_u_247, 0.28, nil, nil, true)
						p_u_146.hitSound(v_u_252, false)
						p_u_146.after(0.14, function()
							-- upvalues: (ref) v_u_53, (ref) v_u_251, (ref) v_u_7, (ref) v_u_11, (ref) v_u_247, (ref) v_u_249, (ref) v_u_9, (ref) v_u_252, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_13, (ref) p_u_146, (ref) v_u_248, (ref) v_u_8, (ref) v_u_10, (ref) v_u_6, (ref) p_u_245, (ref) v_u_4
							v_u_53(v_u_251, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_11, 4 * v_u_247, v_u_249 * 2.3, 0.6, 0, true, -150)
							v_u_53(v_u_251 + Vector3.new(0, 0.05, 0), Vector3.new(0, 1, 0), v_u_7.Glow, v_u_9, v_u_249 * 0.6, v_u_249 * 2, 0.5, 0, false, 0, 0.3)
							local v279 = v_u_252
							local v_u_280 = v_u_7.Glow
							local v_u_281 = v_u_9
							local v_u_282 = v_u_249 * 0.4
							local v_u_283 = v_u_249 * 1.3
							local v_u_284 = 0.5
							local v_u_285 = nil
							local v_u_286 = nil
							v_u_37(CFrame.new(v279), 0.28, 1, function(p287)
								-- upvalues: (copy) v_u_280, (copy) v_u_281, (copy) v_u_284, (ref) v_u_27, (copy) v_u_282, (copy) v_u_283, (ref) v_u_30, (copy) v_u_285, (copy) v_u_286, (ref) v_u_15
								p287.Texture = v_u_280
								p287.Color = ColorSequence.new(v_u_281)
								p287.LightEmission = v_u_284 or 0.4
								p287.Size = v_u_27(v_u_282, v_u_283)
								p287.Transparency = v_u_30()
								p287.Rotation = NumberRange.new(0, 360)
								p287.RotSpeed = NumberRange.new(v_u_285 or 0)
								if v_u_286 then
									p287.FlipbookLayout = v_u_15
									p287.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
								end
							end)
							local v288 = v_u_252
							local v_u_289 = v_u_7.HollowRing
							local v_u_290 = v_u_11
							local v_u_291 = 3 * v_u_247
							local v_u_292 = v_u_249 * 1.8
							local v_u_293 = 0.3
							local v_u_294 = -150
							local v_u_295 = true
							v_u_37(CFrame.new(v288), 0.45, 1, function(p296)
								-- upvalues: (copy) v_u_289, (copy) v_u_290, (copy) v_u_293, (ref) v_u_27, (copy) v_u_291, (copy) v_u_292, (ref) v_u_30, (copy) v_u_294, (copy) v_u_295, (ref) v_u_15
								p296.Texture = v_u_289
								p296.Color = ColorSequence.new(v_u_290)
								p296.LightEmission = v_u_293 or 0.4
								p296.Size = v_u_27(v_u_291, v_u_292)
								p296.Transparency = v_u_30()
								p296.Rotation = NumberRange.new(0, 360)
								p296.RotSpeed = NumberRange.new(v_u_294 or 0)
								if v_u_295 then
									p296.FlipbookLayout = v_u_15
									p296.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
								end
							end)
							local v297 = v_u_252
							local v_u_298 = v_u_7.GamuzaMaw
							local v_u_299 = v_u_13
							local v_u_300 = v_u_249 * 0.5
							local v_u_301 = v_u_249 * 0.9
							local v_u_302 = 0
							local v_u_303 = 200
							local v_u_304 = false
							v_u_37(CFrame.new(v297), 0.25, 1, function(p305)
								-- upvalues: (copy) v_u_298, (copy) v_u_299, (copy) v_u_302, (ref) v_u_27, (copy) v_u_300, (copy) v_u_301, (ref) v_u_30, (copy) v_u_303, (copy) v_u_304, (ref) v_u_15
								p305.Texture = v_u_298
								p305.Color = ColorSequence.new(v_u_299)
								p305.LightEmission = v_u_302 or 0.4
								p305.Size = v_u_27(v_u_300, v_u_301)
								p305.Transparency = v_u_30()
								p305.Rotation = NumberRange.new(0, 360)
								p305.RotSpeed = NumberRange.new(v_u_303 or 0)
								if v_u_304 then
									p305.FlipbookLayout = v_u_15
									p305.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
								end
							end)
							p_u_146.spikes(v_u_252, v_u_9, v_u_248 and 5 or 12, 16 * v_u_247, 0.35, Vector3.new(0, 1, 0), 0.8)
							if not v_u_248 then
								local v306 = { v_u_9, v_u_8, v_u_10 }
								p_u_146.chunks(v_u_252, v306, 6, 26 * v_u_247, 0.6 * v_u_247, 0.7, true, 0.9)
							end
							v_u_6.play("Explosion", {
								["at"] = v_u_252,
								["volume"] = p_u_245.mine and 0.8 or 0.4
							})
							if p_u_245.mine then
								v_u_4.shake(0.25, 0.25)
							end
						end)
					end
				end)
			end,
			["hit"] = function(_, p307, _) -- name: hit
				-- upvalues: (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_8
				local v_u_308 = v_u_7.FxTwinkle
				local v_u_309 = v_u_9
				local v_u_310 = 0.5
				local v_u_311 = 2
				local v_u_312 = 4
				local v_u_313 = nil
				local v_u_314 = true
				v_u_37(CFrame.new(p307), 0.35, 1, function(p315)
					-- upvalues: (copy) v_u_308, (copy) v_u_309, (copy) v_u_310, (ref) v_u_27, (copy) v_u_311, (copy) v_u_312, (ref) v_u_30, (copy) v_u_313, (copy) v_u_314, (ref) v_u_15
					p315.Texture = v_u_308
					p315.Color = ColorSequence.new(v_u_309)
					p315.LightEmission = v_u_310 or 0.4
					p315.Size = v_u_27(v_u_311, v_u_312)
					p315.Transparency = v_u_30()
					p315.Rotation = NumberRange.new(0, 360)
					p315.RotSpeed = NumberRange.new(v_u_313 or 0)
					if v_u_314 then
						p315.FlipbookLayout = v_u_15
						p315.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v_u_316 = v_u_7.HollowRing
				local v_u_317 = v_u_8
				local v_u_318 = 0.3
				local v_u_319 = 1
				local v_u_320 = 4.5
				local v_u_321 = nil
				local v_u_322 = true
				v_u_37(CFrame.new(p307), 0.35, 1, function(p323)
					-- upvalues: (copy) v_u_316, (copy) v_u_317, (copy) v_u_318, (ref) v_u_27, (copy) v_u_319, (copy) v_u_320, (ref) v_u_30, (copy) v_u_321, (copy) v_u_322, (ref) v_u_15
					p323.Texture = v_u_316
					p323.Color = ColorSequence.new(v_u_317)
					p323.LightEmission = v_u_318 or 0.4
					p323.Size = v_u_27(v_u_319, v_u_320)
					p323.Transparency = v_u_30()
					p323.Rotation = NumberRange.new(0, 360)
					p323.RotSpeed = NumberRange.new(v_u_321 or 0)
					if v_u_322 then
						p323.FlipbookLayout = v_u_15
						p323.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
			end
		}
	}
	local v_u_325 = {}
	setmetatable(v_u_325, {
		["__mode"] = "k"
	})
	local v_u_326 = {}
	setmetatable(v_u_326, {
		["__mode"] = "k"
	})
	v324.gamuza_r = {
		["cast"] = function(p327) -- name: cast
			-- upvalues: (copy) p_u_146, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_4
			p_u_146.skillCast(p327, v_u_8, true, true)
			local v328 = p327.eye
			local v_u_329 = v_u_7.FxTwinkle
			local v_u_330 = v_u_9
			local v_u_331 = 2 * p327.size
			local v_u_332 = 5 * p327.size
			local v_u_333 = 0.5
			local v_u_334 = nil
			local v_u_335 = true
			v_u_37(CFrame.new(v328), 0.3, 1, function(p336)
				-- upvalues: (copy) v_u_329, (copy) v_u_330, (copy) v_u_333, (ref) v_u_27, (copy) v_u_331, (copy) v_u_332, (ref) v_u_30, (copy) v_u_334, (copy) v_u_335, (ref) v_u_15
				p336.Texture = v_u_329
				p336.Color = ColorSequence.new(v_u_330)
				p336.LightEmission = v_u_333 or 0.4
				p336.Size = v_u_27(v_u_331, v_u_332)
				p336.Transparency = v_u_30()
				p336.Rotation = NumberRange.new(0, 360)
				p336.RotSpeed = NumberRange.new(v_u_334 or 0)
				if v_u_335 then
					p336.FlipbookLayout = v_u_15
					p336.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			if p327.mine then
				v_u_4.shake(0.12, 0.15)
			end
		end,
		["windup"] = function(p337, _, p338) -- name: windup
			-- upvalues: (copy) p_u_146, (ref) v_u_53, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (copy) v_u_325, (ref) v_u_120, (ref) v_u_140
			local v_u_339 = p337.size
			local v340 = p_u_146.ground(p337.feet, 0.12)
			local v341 = -p337.dir.X
			local v342 = -p337.dir.Z
			local v343 = math.atan2(v341, v342)
			local v344 = math.deg(v343)
			local v345 = p337.dir:Cross(Vector3.new(0, 1, 0))
			for _, v346 in { -1, 1 } do
				v_u_53(v340 + v345 * v346 * 1.2 * v_u_339, Vector3.new(0, 1, 0), v_u_7.GamuzaHoof, v_u_10, 1 * v_u_339, 2.6 * v_u_339, 1.2, v344)
			end
			v_u_53(v340, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 2 * v_u_339, 12 * v_u_339, 0.5, 0, true)
			p_u_146.inward(v340 + Vector3.new(0, 3, 0), v_u_8, p337.lite and 4 or 9, 9 * v_u_339, (math.max(p338, 0.12)))
			local v_u_347 = v_u_325[p337]
			if not v_u_347 then
				v_u_347 = v_u_120(p337.size * 1.35, p337.lite, 3)
				v_u_325[p337] = v_u_347
			end
			local v348 = p_u_146.ground(p337.feet + p337.dir * 1.5 * v_u_339, 0)
			local v_u_349 = CFrame.lookAt(v348, v348 + p337.dir)
			local v350 = math.max(p338, 0.12)
			p_u_146.animate(v350, 0, function(p351)
				-- upvalues: (ref) v_u_140, (copy) v_u_347, (copy) v_u_349, (copy) v_u_339
				local v352 = 1 - (1 - p351) ^ 2
				v_u_140(v_u_347, v_u_349 * CFrame.new(0, -11 * v_u_339 * (1 - v352), 0), p351 * 3, 0)
			end)
		end,
		["beam"] = function(p_u_353, _, p354) -- name: beam
			-- upvalues: (copy) v_u_325, (ref) v_u_120, (copy) p_u_146, (copy) v_u_326, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_27, (ref) v_u_30, (ref) v_u_140, (ref) v_u_53, (ref) v_u_9, (ref) v_u_37, (ref) v_u_15, (ref) v_u_11, (ref) v_u_67, (ref) v_u_12, (ref) v_u_6, (ref) v_u_145
			local v_u_355 = p_u_353.size
			local v_u_356 = p_u_353.lite
			local v_u_357 = v_u_325[p_u_353]
			if not v_u_357 then
				v_u_357 = v_u_120(p_u_353.size * 1.35, p_u_353.lite, 3)
				v_u_325[p_u_353] = v_u_357
			end
			local v_u_358 = p_u_146.ground(p_u_353.feet + p_u_353.dir * 1.5 * v_u_355, 0)
			local v_u_359 = p_u_146.ground(p354, 0)
			local v360 = v_u_359 - v_u_358
			local v361 = v360.Magnitude
			local v_u_362 = math.max(v361, 1)
			local v_u_363 = v360.Unit
			local v_u_364 = CFrame.lookAt(v_u_358, v_u_358 + v_u_363)
			local v_u_365 = v_u_363:Cross(Vector3.new(0, 1, 0))
			local v366 = -v_u_363.X
			local v367 = -v_u_363.Z
			local v368 = math.atan2(v366, v367)
			local v_u_369 = math.deg(v368)
			v_u_326[p_u_353] = {
				["at"] = os.clock(),
				["from"] = v_u_358,
				["long"] = v_u_362
			}
			local v370 = v_u_4.part
			local v371 = 4.2 * v_u_355
			local v_u_372 = v370(Vector3.new(v371, 0.1, 0.1), v_u_364, v_u_10, {
				["transparency"] = 0.25
			})
			local v373 = v_u_4.part
			local v374 = 2.2 * v_u_355
			local v_u_375 = v373(Vector3.new(v374, 0.12, 0.1), v_u_364, v_u_8, {
				["transparency"] = 0.1
			})
			v_u_1:AddItem(v_u_372, 2.5)
			v_u_1:AddItem(v_u_375, 2.5)
			local v_u_376
			if v_u_356 then
				v_u_376 = nil
			else
				v_u_376 = Instance.new("ParticleEmitter")
				v_u_376.Texture = v_u_7.GamuzaChevron
				v_u_376.Color = ColorSequence.new(v_u_8)
				v_u_376.LightEmission = 0.3
				v_u_376.LightInfluence = 0
				v_u_376.Orientation = Enum.ParticleOrientation.VelocityParallel
				v_u_376.EmissionDirection = Enum.NormalId.Back
				v_u_376.SpreadAngle = Vector2.new(25, 10)
				v_u_376.Rotation = NumberRange.new(180)
				v_u_376.Speed = NumberRange.new(8, 14)
				v_u_376.Drag = 3
				v_u_376.Lifetime = NumberRange.new(0.35, 0.5)
				v_u_376.Size = v_u_27(2 * v_u_355, 3.2 * v_u_355, 0.3)
				v_u_376.Transparency = v_u_30(0.4)
				v_u_376.Rate = 60
				v_u_376.Parent = v_u_357.tail
			end
			local v_u_377 = 3
			local v_u_378 = 0
			local v_u_379 = 1
			local v_u_380 = 4.6 * v_u_355
			local v_u_381 = os.clock()
			p_u_146.animate(0.5, 0, function(p382)
				-- upvalues: (ref) v_u_377, (ref) v_u_381, (copy) v_u_362, (copy) v_u_364, (copy) v_u_363, (ref) v_u_140, (copy) v_u_357, (copy) v_u_358, (copy) v_u_372, (copy) v_u_355, (copy) v_u_375, (ref) v_u_378, (copy) v_u_380, (ref) v_u_379, (copy) v_u_365, (ref) v_u_53, (ref) v_u_7, (ref) v_u_10, (copy) v_u_369, (copy) v_u_356, (ref) p_u_146, (ref) v_u_8, (ref) v_u_376, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_11, (ref) v_u_67, (copy) v_u_359, (ref) v_u_12, (ref) v_u_6, (copy) p_u_353, (ref) v_u_4, (ref) v_u_145
				local v383 = os.clock()
				v_u_377 = v_u_377 + (v383 - v_u_381) * 17
				v_u_381 = v383
				local v384 = v_u_362 * p382 ^ 1.35
				local v_u_385 = v_u_364 + v_u_363 * v384
				v_u_140(v_u_357, v_u_385, v_u_377, 0)
				local v386 = v_u_358 + v_u_363 * v384 / 2 + Vector3.new(0, 0.08, 0)
				local v387 = v_u_372
				local v388 = 4.2 * v_u_355
				local v389 = math.max(v384, 0.1)
				v387.Size = Vector3.new(v388, 0.1, v389)
				v_u_372.CFrame = CFrame.lookAt(v386, v386 + v_u_363)
				local v390 = v_u_375
				local v391 = 2.2 * v_u_355
				local v392 = math.max(v384, 0.1)
				v390.Size = Vector3.new(v391, 0.12, v392)
				v_u_375.CFrame = CFrame.lookAt(v386 + Vector3.new(0, 0.02, 0), v386 + Vector3.new(0, 0.02, 0) + v_u_363)
				while v_u_380 <= v384 - v_u_378 do
					v_u_378 = v_u_378 + v_u_380
					v_u_379 = -v_u_379
					local v393 = v_u_358 + v_u_363 * v_u_378 + v_u_365 * v_u_379 * 1.3 * v_u_355 + Vector3.new(0, 0.12, 0)
					v_u_53(v393, Vector3.new(0, 1, 0), v_u_7.GamuzaHoof, v_u_10, 1.5 * v_u_355, 3 * v_u_355, 1.4, v_u_369)
					if v_u_356 then
						continue
					end
					v_u_53(v393, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 1 * v_u_355, 6 * v_u_355, 0.4, 0, true)
					local v394 = { v_u_10, v_u_8 }
					p_u_146.chunks(v393, v394, 2, 16 * v_u_355, 0.4 * v_u_355, 0.5, true, 0.8)
				end
				if p382 >= 1 then
					local v395 = v_u_376
					if v395 then
						v395.Enabled = false
					end
					local v_u_396 = (v_u_385 * v_u_357.lanceAt * CFrame.new(0, 0, -v_u_357.tip.Magnitude)).Position
					p_u_146.animate(0.12, 0, function(p397)
						-- upvalues: (ref) v_u_140, (ref) v_u_357, (copy) v_u_385, (ref) v_u_377, (ref) v_u_355, (copy) v_u_396, (ref) v_u_363, (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_53, (ref) v_u_11, (ref) v_u_8, (ref) v_u_67, (ref) p_u_146, (ref) v_u_356, (ref) v_u_359, (ref) v_u_10, (ref) v_u_12, (ref) v_u_6, (ref) p_u_353, (ref) v_u_4, (ref) v_u_145, (ref) v_u_372, (ref) v_u_375
						local v398 = v_u_140
						local v399 = v_u_357
						local v400 = v_u_385
						local v401 = v_u_377
						local v402 = math.clamp(p397, 0, 1)
						v398(v399, v400, v401, v402 * v402 * (3 - v402 * 2) * 3 * v_u_355)
						if p397 >= 1 then
							local v403 = v_u_396 + v_u_363 * 3 * v_u_355
							local v_u_404 = v_u_7.Glow
							local v_u_405 = v_u_9
							local v_u_406 = 3 * v_u_355
							local v_u_407 = 16 * v_u_355
							local v_u_408 = 0.5
							local v_u_409 = nil
							local v_u_410 = nil
							v_u_37(CFrame.new(v403), 0.3, 1, function(p411)
								-- upvalues: (copy) v_u_404, (copy) v_u_405, (copy) v_u_408, (ref) v_u_27, (copy) v_u_406, (copy) v_u_407, (ref) v_u_30, (copy) v_u_409, (copy) v_u_410, (ref) v_u_15
								p411.Texture = v_u_404
								p411.Color = ColorSequence.new(v_u_405)
								p411.LightEmission = v_u_408 or 0.4
								p411.Size = v_u_27(v_u_406, v_u_407)
								p411.Transparency = v_u_30()
								p411.Rotation = NumberRange.new(0, 360)
								p411.RotSpeed = NumberRange.new(v_u_409 or 0)
								if v_u_410 then
									p411.FlipbookLayout = v_u_15
									p411.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
								end
							end)
							v_u_53(v403, v_u_363, v_u_7.HollowRing, v_u_11, 3 * v_u_355, 18 * v_u_355, 0.45, 0, true, 0, 0.3)
							local v_u_412 = v_u_7.HollowRing
							local v_u_413 = v_u_8
							local v_u_414 = 2 * v_u_355
							local v_u_415 = 12 * v_u_355
							local v_u_416 = 0.3
							local v_u_417 = nil
							local v_u_418 = true
							v_u_37(CFrame.new(v403), 0.4, 1, function(p419)
								-- upvalues: (copy) v_u_412, (copy) v_u_413, (copy) v_u_416, (ref) v_u_27, (copy) v_u_414, (copy) v_u_415, (ref) v_u_30, (copy) v_u_417, (copy) v_u_418, (ref) v_u_15
								p419.Texture = v_u_412
								p419.Color = ColorSequence.new(v_u_413)
								p419.LightEmission = v_u_416 or 0.4
								p419.Size = v_u_27(v_u_414, v_u_415)
								p419.Transparency = v_u_30()
								p419.Rotation = NumberRange.new(0, 360)
								p419.RotSpeed = NumberRange.new(v_u_417 or 0)
								if v_u_418 then
									p419.FlipbookLayout = v_u_15
									p419.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
								end
							end)
							v_u_67(p_u_146.ground(v403, 0.6), v_u_356 and 5 or 10, 34 * v_u_355, 2.4 * v_u_355, 0.4, v_u_8)
							v_u_53(p_u_146.ground(v_u_359, 0.14), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 3 * v_u_355, 16 * v_u_355, 0.5, 0, true)
							if not v_u_356 then
								for _ = 1, 3 do
									local v420 = (v_u_385 * CFrame.new(0, 6 * v_u_355, 0)).Position
									local v421 = math.random() - 0.5
									local v422 = math.random() - 0.5
									local v423 = math.random() - 0.5
									local v424 = v420 + Vector3.new(v421, v422, v423) * 6 * v_u_355
									local v_u_425 = v_u_7.FxTwinkle
									local v_u_426 = v_u_12
									local v_u_427 = 2 * v_u_355
									local v_u_428 = 5 * v_u_355
									local v_u_429 = 0.5
									local v_u_430 = nil
									local v_u_431 = true
									v_u_37(CFrame.new(v424), 0.6, 1, function(p432)
										-- upvalues: (copy) v_u_425, (copy) v_u_426, (copy) v_u_429, (ref) v_u_27, (copy) v_u_427, (copy) v_u_428, (ref) v_u_30, (copy) v_u_430, (copy) v_u_431, (ref) v_u_15
										p432.Texture = v_u_425
										p432.Color = ColorSequence.new(v_u_426)
										p432.LightEmission = v_u_429 or 0.4
										p432.Size = v_u_27(v_u_427, v_u_428)
										p432.Transparency = v_u_30()
										p432.Rotation = NumberRange.new(0, 360)
										p432.RotSpeed = NumberRange.new(v_u_430 or 0)
										if v_u_431 then
											p432.FlipbookLayout = v_u_15
											p432.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
										end
									end)
								end
							end
							v_u_6.play("Explosion", {
								["at"] = v403,
								["volume"] = p_u_353.mine and 0.8 or 0.4
							})
							if p_u_353.mine then
								v_u_4.shake(0.3, 0.3)
							end
							v_u_145(v_u_357, 0.35)
							v_u_4.tween(v_u_372, 0.9, {
								["Transparency"] = 1
							})
							local v433 = v_u_4.tween
							local v434 = v_u_375
							local v435 = {
								["Transparency"] = 1,
								["Size"] = nil
							}
							local v436 = v_u_375.Size.Z
							v435.Size = Vector3.new(0.2, 0.12, v436)
							v433(v434, 0.9, v435)
						end
					end)
				end
			end)
			v_u_6.play("Hit", {
				["at"] = v_u_358,
				["volume"] = p_u_353.mine and 0.7 or 0.35
			})
			if p_u_353.mine then
				v_u_4.shake(0.18, 0.5)
			end
		end,
		["hit"] = function(p437, p_u_438, _) -- name: hit
			-- upvalues: (copy) v_u_326, (copy) p_u_146, (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) v_u_8
			local v439 = v_u_326[p437]
			local v440
			if v439 then
				local v441 = (p_u_438 - v439.from):Dot(p437.dir) / v439.long
				local v442 = math.clamp(v441, 0, 1)
				v440 = v439.at + v442 ^ 0.7407407407407407 * 0.5 - os.clock()
			else
				v440 = 0
			end
			p_u_146.after(v440, function()
				-- upvalues: (copy) p_u_438, (ref) v_u_7, (ref) v_u_9, (ref) v_u_37, (ref) v_u_27, (ref) v_u_30, (ref) v_u_15, (ref) p_u_146, (ref) v_u_8
				local v443 = p_u_438
				local v_u_444 = v_u_7.Glow
				local v_u_445 = v_u_9
				local v_u_446 = 0.5
				local v_u_447 = 2
				local v_u_448 = 6
				local v_u_449 = nil
				local v_u_450 = nil
				v_u_37(CFrame.new(v443), 0.2, 1, function(p451)
					-- upvalues: (copy) v_u_444, (copy) v_u_445, (copy) v_u_446, (ref) v_u_27, (copy) v_u_447, (copy) v_u_448, (ref) v_u_30, (copy) v_u_449, (copy) v_u_450, (ref) v_u_15
					p451.Texture = v_u_444
					p451.Color = ColorSequence.new(v_u_445)
					p451.LightEmission = v_u_446 or 0.4
					p451.Size = v_u_27(v_u_447, v_u_448)
					p451.Transparency = v_u_30()
					p451.Rotation = NumberRange.new(0, 360)
					p451.RotSpeed = NumberRange.new(v_u_449 or 0)
					if v_u_450 then
						p451.FlipbookLayout = v_u_15
						p451.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v452 = p_u_438
				local v_u_453 = v_u_7.FxTwinkle
				local v_u_454 = v_u_9
				local v_u_455 = 0.5
				local v_u_456 = 2
				local v_u_457 = 4.5
				local v_u_458 = nil
				local v_u_459 = true
				v_u_37(CFrame.new(v452), 0.35, 1, function(p460)
					-- upvalues: (copy) v_u_453, (copy) v_u_454, (copy) v_u_455, (ref) v_u_27, (copy) v_u_456, (copy) v_u_457, (ref) v_u_30, (copy) v_u_458, (copy) v_u_459, (ref) v_u_15
					p460.Texture = v_u_453
					p460.Color = ColorSequence.new(v_u_454)
					p460.LightEmission = v_u_455 or 0.4
					p460.Size = v_u_27(v_u_456, v_u_457)
					p460.Transparency = v_u_30()
					p460.Rotation = NumberRange.new(0, 360)
					p460.RotSpeed = NumberRange.new(v_u_458 or 0)
					if v_u_459 then
						p460.FlipbookLayout = v_u_15
						p460.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				p_u_146.burst("Impact", p_u_438, v_u_8, 0.8)
			end)
		end
	}
	return v324
end