local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(255, 140, 90)
local v_u_6 = Color3.fromRGB(70, 0, 6)
local v_u_7 = Color3.fromRGB(20, 4, 6)
local v_u_8 = { 1.7, 3.2, 0.6 }
local function v_u_14(p9, p10) -- name: axisFrame
	local v11 = p10.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p10.Unit
	local v12 = v11.Y
	local v13 = v11:Cross(math.abs(v12) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)).Unit
	return CFrame.fromMatrix(p9, v11, v13:Cross(v11), v13)
end
return function(p_u_15)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5, (copy) v_u_3, (copy) v_u_8, (copy) v_u_14, (copy) v_u_7, (copy) v_u_6
	return {
		["w0_kurenai_mangekyo"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_2, (copy) p_u_15, (ref) v_u_4, (ref) v_u_5, (ref) v_u_3, (ref) v_u_8, (ref) v_u_14, (ref) v_u_7, (ref) v_u_6
			local v_u_18 = v_u_2.color(p17.color)
			local v19 = Color3.fromRGB(255, 30, 24)
			local v20 = Color3.new(v19.R * 1.6, v19.G * 1.6, v19.B * 1.6)
			local v21 = p_u_16.headY / 1.5
			local v_u_22 = math.clamp(v21, 0.7, 3)
			local v_u_23 = p_u_16.fx
			local v_u_24 = CFrame.new(0, v_u_22 * -0.55, v_u_22 * 0.55)
			local v_u_26 = p_u_15.throb(p_u_16, 4.2, 2, 1.5, function(p25)
				-- upvalues: (ref) v_u_2, (ref) p_u_15, (copy) p_u_16, (copy) v_u_18, (copy) v_u_23, (ref) v_u_4, (copy) v_u_24, (copy) v_u_22, (ref) v_u_5
				v_u_2.ring(p_u_15.feetAt(p_u_16, p25, 0.15), v_u_18, 10 * v_u_23, 0.6, v_u_4.Ring)
				v_u_2.flash((p25 * v_u_24 * CFrame.new(0, v_u_22 * 1.2, v_u_22 * 1.2)).Position, v_u_5, v_u_22 * 5 * v_u_23, 0.25)
			end)
			local v27 = p_u_15.bar(Vector3.new(0.2, 0.2, 0.2), v_u_18, 1)
			p_u_15.add(p_u_16, v27, function(p28)
				-- upvalues: (copy) v_u_24
				return p28 * v_u_24
			end)
			local v29 = v_u_3.level() >= 2
			local v_u_30 = {}
			local v_u_31 = {}
			for v32 = 1, 9 do
				local v33 = Instance.new("Attachment")
				v33.Parent = v27
				local v34 = Instance.new("Attachment")
				v34.Parent = v27
				local v35 = {}
				local v36 = p_u_15.ray(v33, v34, v_u_18, v_u_8[1] * v_u_22, v_u_8[1] * 0.3 * v_u_22, v_u_4.Beam)
				v36.Segments = 12
				v36.LightEmission = 0.8
				v36.TextureSpeed = -1
				table.insert(v35, v36)
				local v37 = p_u_15.ray(v33, v34, v_u_18, v_u_8[2] * v_u_22, v_u_8[2] * 0.3 * v_u_22, v_u_4.FireBeam)
				v37.Segments = 12
				v37.TextureLength = v_u_22 * 3
				v37.TextureSpeed = -1.6
				v37.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(0.8, 0.05), NumberSequenceKeypoint.new(1, 0.55) })
				table.insert(v35, v37)
				if v29 then
					local v38 = p_u_15.ray(v33, v34, v_u_5, v_u_8[3] * v_u_22, v_u_8[3] * 0.3 * v_u_22, v_u_4.Beam)
					v38.Segments = 12
					v38.LightEmission = 1
					v38.TextureSpeed = -3
					table.insert(v35, v38)
				end
				for _, v39 in v35 do
					table.insert(v_u_30, v39)
				end
				local v40 = {
					["a0"] = v33,
					["a1"] = v34,
					["beams"] = v35,
					["fan"] = (v32 - 5) / 4
				}
				table.insert(v_u_31, v40)
			end
			local v41 = p_u_16.ticks
			local function v68(_, p42)
				-- upvalues: (copy) v_u_26, (copy) v_u_31, (copy) v_u_22, (ref) v_u_14, (ref) v_u_8
				local v43 = v_u_26()
				for v44, v45 in v_u_31 do
					local v46 = v45.fan * (1.25 + 0.35 * v43)
					local v47 = p42 * 1.7 + v44 * 0.75
					local v48 = math.sin(v47)
					local v49 = p42 * 1.1 + v44
					local v50 = (math.sin(v49) * 0.6 + 6.4) * v_u_22 * (1 + 0.2 * v43)
					local v51 = math.sin(v46) * 1.1
					local v52 = math.cos(v46) * 0.35 + 0.7 + 0.3 * v43
					local v53 = Vector3.new(v51, v52, 0.75).Unit * v50
					local v54 = v48 * 0.7 * v_u_22
					local v55 = p42 * 1.3 + v44
					local v56 = math.cos(v55) * 0.4 * v_u_22
					local v57 = v53 + Vector3.new(v54, v56, 0)
					local v58 = v45.a0
					local v59 = v_u_14
					local v60 = math.sin(v46) * 0.5
					v58.CFrame = v59(Vector3.new(0, 0, 0), (Vector3.new(v60, -0.2, 1)))
					local v61 = v45.a1
					local v62 = v_u_14
					local v63 = v48 * 0.35
					v61.CFrame = v62(v57, (Vector3.new(v63, 1, -0.25)))
					local v64 = 1 + 0.4 * v43
					for v65, v66 in v45.beams do
						v66.CurveSize0 = v50 * 0.5
						v66.CurveSize1 = v50 * 0.3
						local v67 = v_u_8[v65]
						v66.Width0 = v67 * v_u_22 * v64
						v66.Width1 = v67 * 0.3 * v_u_22 * v64
					end
				end
			end
			table.insert(v41, v68)
			local v69 = p_u_16.stops
			table.insert(v69, function()
				-- upvalues: (copy) v_u_30
				for _, v70 in v_u_30 do
					v70.Enabled = false
				end
			end)
			for _, v_u_71 in {
				{
					["r"] = nil,
					["tilt"] = nil,
					["y"] = nil,
					["spin"] = 1.6,
					["count"] = 2,
					["r"] = v_u_22 * 2.3,
					["tilt"] = CFrame.Angles(0.42, 0, 0.18),
					["y"] = v_u_22 * 0.35
				},
				{
					["r"] = nil,
					["tilt"] = nil,
					["y"] = nil,
					["spin"] = -1.2,
					["count"] = 1,
					["r"] = v_u_22 * 2.9,
					["tilt"] = CFrame.Angles(-0.3, 0, -0.26),
					["y"] = v_u_22 * -0.2
				}
			} do
				local v_u_73 = p_u_15.group(p_u_16, function(p72)
					-- upvalues: (copy) v_u_71
					return p72 * CFrame.new(0, v_u_71.y, 0) * v_u_71.tilt
				end)
				local v74, v75 = p_u_15.picture(v_u_71.r * 2 / 0.9, v_u_4.Ring, v_u_18, 0.3)
				for _, v76 in v75 do
					v76.Color3 = v20
				end
				p_u_15.pin(p_u_16, v_u_73, v74, CFrame.identity)
				for v_u_77 = 1, v_u_71.count do
					local function v80(_, p78) -- name: place
						-- upvalues: (copy) v_u_71, (copy) v_u_77, (copy) v_u_73
						local v79 = p78 * v_u_71.spin + (v_u_77 - 1) * 3.141592653589793
						return v_u_73.cf * CFrame.Angles(0, v79, 0) * CFrame.new(v_u_71.r, 0, 0)
					end
					local v81 = p_u_15.ball(v_u_22 * 0.45, v_u_7, 0, Enum.Material.SmoothPlastic)
					p_u_15.add(p_u_16, v81, v80)
					p_u_15.tail(v81, v_u_18, v_u_6, v_u_22 * 0.32, 0.35)
					p_u_15.add(p_u_16, p_u_15.ball(v_u_22 * 0.78, v_u_18, 0.45), p_u_15.behind(v80, v_u_22 * 0.3))
				end
			end
			p_u_15.particles(p_u_16, "AuraMode", v_u_18, {
				["rate"] = 0.5,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = {
					"Glow",
					"FlameBack",
					"Crackle",
					"Sparks"
				}
			})
		end
	}
end