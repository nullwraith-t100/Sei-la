local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Input)
local v_u_6 = require(script.Parent.State)
local v_u_7 = require(v2.Shared.Net)
local v_u_8 = require(v2.Shared.Config.Economy)
local v_u_9 = require(v2.Shared.Logic.AutoFree)
local v_u_10 = {}
local v_u_11 = v1.LocalPlayer
local v_u_12 = false
local v_u_13 = -1
local v_u_14 = {}
local function v_u_16() -- name: tell
	-- upvalues: (copy) v_u_14
	for _, v15 in v_u_14 do
		task.spawn(v15)
	end
end
function v_u_10.onChange(p17) -- name: onChange
	-- upvalues: (copy) v_u_14
	local v18 = v_u_14
	table.insert(v18, p17)
end
function v_u_10.freePhase() -- name: freePhase
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_9
	local v19 = v_u_4:GetServerTimeNow()
	local v20 = v_u_6.number("JoinedAt", v19)
	return v_u_9.phase(v19 - v20)
end
function v_u_10.freeLeft() -- name: freeLeft
	-- upvalues: (copy) v_u_10
	local v21 = v_u_10.freePhase()
	return v21.ready and 0 or v21.left
end
function v_u_10.freeUseLeft() -- name: freeUseLeft
	-- upvalues: (copy) v_u_10
	local v22 = v_u_10.freePhase()
	return not v22.ready and 0 or v22.left
end
function v_u_10.freeOn() -- name: freeOn
	-- upvalues: (copy) v_u_10, (ref) v_u_12, (ref) v_u_13
	local v23 = v_u_10.freePhase()
	local v24 = v_u_12 and v23.ready
	if v24 then
		v24 = v23.cycle == v_u_13
	end
	return v24
end
function v_u_10.opLeft() -- name: opLeft
	-- upvalues: (copy) v_u_6
	return v_u_6.number("AutoOpLeft")
end
function v_u_10.opOn() -- name: opOn
	-- upvalues: (copy) v_u_11, (copy) v_u_10
	local v25
	if v_u_11:GetAttribute("AutoOpOn") == true then
		v25 = v_u_10.opLeft() > 0
	else
		v25 = false
	end
	return v25
end
function v_u_10.rate() -- name: rate
	-- upvalues: (copy) v_u_10, (copy) v_u_8
	if v_u_10.opOn() then
		return v_u_8.autoOpRate
	else
		return not v_u_10.freeOn() and 0 or v_u_8.autoFreeRate
	end
end
function v_u_10.toggleFree() -- name: toggleFree
	-- upvalues: (copy) v_u_10, (ref) v_u_12, (ref) v_u_13, (copy) v_u_14
	local v26 = v_u_10.freePhase()
	if not v26.ready then
		return false
	end
	v_u_12 = not v_u_10.freeOn()
	v_u_13 = v26.cycle
	for _, v27 in v_u_14 do
		task.spawn(v27)
	end
	return true
end
function v_u_10.toggleOp() -- name: toggleOp
	-- upvalues: (copy) v_u_10, (copy) v_u_7
	if v_u_10.opLeft() <= 0 then
		return false
	end
	local v_u_28 = not v_u_10.opOn()
	task.spawn(function()
		-- upvalues: (ref) v_u_7, (copy) v_u_28
		local function v29()
			-- upvalues: (ref) v_u_7, (ref) v_u_28
			return v_u_7.func("AutoOp"):InvokeServer(v_u_28)
		end
		pcall(v29)
	end)
	return true
end
function v_u_10.start() -- name: start
	-- upvalues: (copy) v_u_3, (copy) v_u_10, (copy) v_u_5, (copy) v_u_11, (copy) v_u_16
	local v_u_30 = 0
	v_u_3.Heartbeat:Connect(function(p31)
		-- upvalues: (ref) v_u_10, (ref) v_u_30, (ref) v_u_5
		local v32 = v_u_10.rate()
		if v32 <= 0 then
			v_u_30 = 0
		else
			local v33 = v_u_30 + p31 * v32
			v_u_30 = math.min(v33, 2)
			while v_u_30 >= 1 do
				v_u_30 = v_u_30 - 1
				v_u_5.autoClick()
			end
		end
	end)
	for _, v34 in { "AutoOpOn", "AutoOpLeft" } do
		v_u_11:GetAttributeChangedSignal(v34):Connect(v_u_16)
	end
end
return v_u_10