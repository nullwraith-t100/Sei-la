local v1 = require(script.Parent.Parent.Logic.Prizes)
return {
	["starter"] = {
		v1.worldEgg(2, 3),
		v1.trophies(30, 1000),
		v1.boost("chakra", 30),
		v1.boost("wins", 30)
	},
	["pro"] = {
		v1.egg("akatsuki", 2),
		v1.worldEgg(2, 10),
		v1.trophies(200, 25000),
		v1.boost("chakra5", 60),
		v1.boost("wins", 60)
	}
}