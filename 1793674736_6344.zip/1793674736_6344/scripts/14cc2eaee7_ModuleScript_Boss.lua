local v_u_1 = {
	["EVERY"] = 300,
	["WARN"] = 30,
	["FIGHT_SECONDS"] = 180,
	["TARGET_SECONDS"] = 65,
	["FIGHT_SECONDS_SOLO"] = 240,
	["BOOST_PER_TEN"] = 0.5,
	["BOOST_MAX"] = 3,
	["COUNTDOWN"] = 10,
	["RESPAWN"] = 4,
	["COINS_PER_WIN"] = 100,
	["COINS_MAX"] = 150,
	["COINS_FLOOR"] = 75,
	["SKIP_PRODUCT"] = "bossSkip",
	["TIERS"] = {
		{
			["id"] = "genin",
			["name"] = "GENIN",
			["color"] = "#7CD992"
		},
		{
			["id"] = "jonin",
			["name"] = "JONIN",
			["color"] = "#3FA9FF"
		},
		{
			["id"] = "kage",
			["name"] = "KAGE",
			["color"] = "#FFC93C"
		},
		{
			["id"] = "mythical",
			["name"] = "MYTHICAL",
			["color"] = "#FF3D6E"
		}
	},
	["GRAND_PRIZE_LOOK"] = "dark_star",
	["GRAND_PRIZE_RECOLOR"] = {
		["look"] = "dark_star",
		["color"] = "#FFA21F",
		["color2"] = "#FFF0C8",
		["iris"] = "rbxassetid://70714339534945"
	},
	["GRAND_PRIZE"] = "grand_prize"
}
v_u_1.SHOP = {
	{
		["id"] = "fox_fire",
		["tier"] = "genin",
		["kind"] = "aura",
		["item"] = "fox_fire",
		["cost"] = 160
	},
	{
		["id"] = "boost_chakra",
		["tier"] = "genin",
		["kind"] = "boost",
		["item"] = "chakra",
		["cost"] = 200,
		["minutes"] = 30
	},
	{
		["id"] = "boost_wins",
		["tier"] = "genin",
		["kind"] = "boost",
		["item"] = "wins",
		["cost"] = 200,
		["minutes"] = 30
	},
	{
		["id"] = "chakra_cloak",
		["tier"] = "genin",
		["kind"] = "aura",
		["item"] = "chakra_cloak",
		["cost"] = 500
	},
	{
		["id"] = "kanjogan",
		["tier"] = "jonin",
		["kind"] = "eye",
		["item"] = "kanjogan_v2",
		["cost"] = 1000
	},
	{
		["id"] = "tailed_cloak",
		["tier"] = "jonin",
		["kind"] = "aura",
		["item"] = "tailed_cloak",
		["cost"] = 1000
	},
	{
		["id"] = "fuma_mangekyo",
		["tier"] = "kage",
		["kind"] = "eye",
		["item"] = "fuma_mangekyo_v2",
		["cost"] = 2400
	},
	{
		["id"] = "bijuu_mode",
		["tier"] = "kage",
		["kind"] = "aura",
		["item"] = "bijuu_mode",
		["cost"] = 3000
	},
	{
		["id"] = "kurenai_mangekyo",
		["tier"] = "kage",
		["kind"] = "eye",
		["item"] = "kurenai_mangekyo_v2",
		["cost"] = 3200
	},
	{
		["id"] = nil,
		["tier"] = "mythical",
		["kind"] = "eye",
		["item"] = nil,
		["cost"] = 8000,
		["id"] = v_u_1.GRAND_PRIZE,
		["item"] = v_u_1.GRAND_PRIZE .. "_v2"
	}
}
v_u_1.byId = {}
for _, v2 in v_u_1.SHOP do
	v_u_1.byId[v2.id] = v2
end
function v_u_1.untilNext(p3, p4) -- name: untilNext
	-- upvalues: (copy) v_u_1
	local v5 = (p3 - p4) % v_u_1.EVERY
	return v_u_1.EVERY - v5
end
return v_u_1