local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(255, 200, 74)
local v_u_9 = Color3.fromRGB(226, 248, 255)
local v_u_10 = CFrame.identity
local v_u_11 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_19(p12) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v13 = v_u_2:FindFirstChild("EyePieces")
	if v13 then
		v13 = v13:FindFirstChild("w8_cryo_lotus")
	end
	if not (v13 and v13:IsA("MeshPart")) then
		return nil
	end
	local v14 = v13:Clone()
	local v15 = v13.Size
	local v16 = v15.X
	local v17 = v15.Y
	local v18 = v15.Z
	v14.Size = v15 * (p12 / math.max(v16, v17, v18, 0.01))
	v14.Anchored = true
	v14.CanCollide = false
	v14.CanQuery = false
	v14.CanTouch = false
	v14.Massless = true
	v14.CastShadow = false
	v14.Parent = v_u_4.folder()
	return v14
end
return function(p_u_20)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_9, (copy) v_u_8, (copy) v_u_1, (copy) v_u_19, (copy) v_u_10, (copy) v_u_11, (copy) v_u_7, (copy) v_u_5
	return {
		["w8_cryo_lotus"] = function(p_u_21, p22)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) p_u_20, (ref) v_u_6, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (ref) v_u_19, (ref) v_u_10, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5
			local v23 = v_u_4.color(p22.color)
			local v24 = v_u_4.color(p22.color2)
			local v25 = p_u_21.headY / 1.5
			local v_u_26 = math.clamp(v25, 0.7, 3)
			local v_u_27 = Instance.new("Attachment")
			v_u_27.Parent = v_u_3.Terrain
			p_u_20.own(p_u_21, v_u_27)
			local v_u_28 = Instance.new("ParticleEmitter")
			v_u_28.Enabled = false
			v_u_28.Texture = v_u_6.FxSmoke
			v_u_28.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_28.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_28.Color = ColorSequence.new(v_u_9, v24)
			v_u_28.LightEmission = 0.35
			v_u_28.LightInfluence = 0
			v_u_28.Lifetime = NumberRange.new(0.5, 0.8)
			v_u_28.Size = NumberSequence.new(v_u_26 * 0.5 * p_u_21.fx, v_u_26 * 1.6 * p_u_21.fx)
			v_u_28.Transparency = NumberSequence.new(0.35, 1)
			v_u_28.Speed = NumberRange.new(v_u_26 * 6, v_u_26 * 12)
			v_u_28.Drag = 3
			v_u_28.SpreadAngle = Vector2.new(35, 35)
			v_u_28.Rotation = NumberRange.new(0, 360)
			v_u_28.Parent = v_u_27
			local v_u_29 = Instance.new("ParticleEmitter")
			v_u_29.Enabled = false
			v_u_29.Texture = v_u_6.FxTwinkle
			v_u_29.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_29.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_29.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v23), ColorSequenceKeypoint.new(0.5, v24), ColorSequenceKeypoint.new(1, v_u_8) })
			v_u_29.LightEmission = 0.6
			v_u_29.LightInfluence = 0
			v_u_29.Lifetime = NumberRange.new(0.5, 0.7)
			v_u_29.Size = NumberSequence.new(v_u_26 * 0.6 * p_u_21.fx)
			v_u_29.Speed = NumberRange.new(2, 6)
			v_u_29.SpreadAngle = Vector2.new(180, 180)
			v_u_29.Parent = v_u_27
			local v30 = p_u_21.stops
			local function v31()
				-- upvalues: (ref) v_u_1, (copy) v_u_27
				v_u_1:AddItem(v_u_27, 1)
			end
			table.insert(v30, v31)
			local v_u_32 = -100
			p_u_20.throb(p_u_21, 5.5, 2.4, 1, function()
				-- upvalues: (ref) v_u_32
				v_u_32 = os.clock()
			end)
			local v_u_33 = v_u_19(v_u_26 * 3.8)
			local v_u_34 = v_u_26 * 3.8
			local v_u_48 = p_u_20.group(p_u_21, function(p35, p36)
				-- upvalues: (ref) v_u_32, (copy) v_u_26
				local v37 = p36 * 1.6
				local v38 = math.sin(v37) * 0.12
				local v39 = os.clock() - v_u_32
				local v40
				if v39 < 0 or v39 > 0.9 then
					v40 = 0
				elseif v39 < 0.18 then
					local v41 = v39 / 0.18
					local v42 = math.clamp(v41, 0, 1)
					v40 = v42 * v42 * (3 - v42 * 2)
				else
					local v43 = (v39 - 0.18) / 0.7
					local v44 = math.clamp(v43, 0, 1)
					v40 = 1 - v44 * v44 * (3 - v44 * 2)
				end
				local v45 = CFrame.new
				local v46 = v_u_26 * 0.75 + v40 * 0.25 * v_u_26
				local v47 = p36 * 1.2
				return p35 * v45(0, v46 + math.sin(v47) * 0.08 * v_u_26, v_u_26 * 0.85) * CFrame.Angles(-0.25 - v40 * 0.3, 0, v38)
			end)
			if v_u_33 then
				local v49 = v_u_33:FindFirstChildWhichIsA("SurfaceAppearance")
				if v49 then
					v49.Color = v_u_8
				else
					v_u_33.Color = v_u_8
				end
				local v_u_50 = v_u_33.Size
				p_u_20.pin(p_u_21, v_u_48, v_u_33, v_u_10)
				p_u_20.fadeFromBehind(p_u_21, v_u_33, 0.35)
				local v51 = p_u_21.ticks
				local function v60()
					-- upvalues: (copy) v_u_33, (copy) v_u_50, (ref) v_u_32
					local v52 = v_u_33
					local v53 = v_u_50
					local v54 = os.clock() - v_u_32
					local v55
					if v54 < 0 or v54 > 0.9 then
						v55 = 0
					elseif v54 < 0.18 then
						local v56 = v54 / 0.18
						local v57 = math.clamp(v56, 0, 1)
						v55 = v57 * v57 * (3 - v57 * 2)
					else
						local v58 = (v54 - 0.18) / 0.7
						local v59 = math.clamp(v58, 0, 1)
						v55 = 1 - v59 * v59 * (3 - v59 * 2)
					end
					v52.Size = v53 * (v55 * 0.18 + 1)
				end
				table.insert(v51, v60)
			else
				for _, v61 in { -1, 1 } do
					local v62 = CFrame.new(v61 * v_u_34 * 0.27, 0, 0) * CFrame.Angles(0, 0, -v61 * 0.55)
					local v63 = p_u_20.picture(v_u_26 * 2.4, v_u_6.Glow, v24, 0.55)
					p_u_20.pin(p_u_21, v_u_48, v63, v62 * CFrame.new(0, 0, v_u_26 * 0.06) * v_u_11)
					local v64 = p_u_20.picture(v_u_26 * 2, v_u_6.CryoFan, v_u_8, 0)
					p_u_20.pin(p_u_21, v_u_48, v64, v62 * v_u_11)
				end
			end
			local v65 = p_u_20.bar(Vector3.new(0.2, 0.2, 0.2), v_u_7, 1)
			p_u_20.add(p_u_21, v65, function(p66)
				-- upvalues: (ref) p_u_20, (copy) p_u_21
				return CFrame.new(p_u_20.feetAt(p_u_21, p66, 0.1))
			end)
			local v_u_67 = Instance.new("ParticleEmitter")
			v_u_67.Texture = v_u_6.CryoLotus
			v_u_67.Color = ColorSequence.new(v_u_7)
			v_u_67.LightEmission = 0.15
			v_u_67.LightInfluence = 0
			v_u_67.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_67.EmissionDirection = Enum.NormalId.Top
			v_u_67.SpreadAngle = Vector2.zero
			v_u_67.Speed = NumberRange.new(0.01)
			v_u_67.LockedToPart = true
			v_u_67.Lifetime = NumberRange.new(8)
			v_u_67.Size = NumberSequence.new(v_u_26 * 2.3 * p_u_21.fx)
			v_u_67.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.05, 0.1),
				NumberSequenceKeypoint.new(0.95, 0.1),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_67.Rotation = NumberRange.new(0, 0)
			v_u_67.RotSpeed = NumberRange.new(5.625, 5.625)
			v_u_67.Rate = 0.125
			v_u_67.Parent = v65
			v_u_67:Emit(1)
			local v_u_68 = Instance.new("ParticleEmitter")
			v_u_68.Texture = v_u_6.FxSmoke
			v_u_68.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_68.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_68.Color = ColorSequence.new(v_u_9, v23:Lerp(v_u_7, 0.6))
			v_u_68.LightEmission = 0.25
			v_u_68.LightInfluence = 0
			v_u_68.Lifetime = NumberRange.new(1.4, 2)
			v_u_68.Size = NumberSequence.new(v_u_26 * 0.9 * p_u_21.fx, v_u_26 * 2.4 * p_u_21.fx)
			v_u_68.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.25, 0.6), NumberSequenceKeypoint.new(1, 1) })
			v_u_68.Speed = NumberRange.new(1, 2.5)
			v_u_68.EmissionDirection = Enum.NormalId.Top
			v_u_68.SpreadAngle = Vector2.new(85, 85)
			v_u_68.Acceleration = Vector3.new(0, -0.6, 0)
			v_u_68.Rotation = NumberRange.new(0, 360)
			v_u_68.RotSpeed = NumberRange.new(-20, 20)
			v_u_68.Rate = 5 * v_u_5.formRate()
			v_u_68:SetAttribute("BaseRate", 5)
			v_u_68.Parent = v65
			local v69 = p_u_21.stops
			table.insert(v69, function()
				-- upvalues: (copy) v_u_67, (copy) v_u_68
				v_u_67.Enabled = false
				v_u_68.Enabled = false
			end)
			local v_u_70 = {}
			local function v_u_87(p71) -- name: bloomRing
				-- upvalues: (ref) v_u_5, (ref) p_u_20, (copy) p_u_21, (copy) v_u_26, (ref) v_u_4, (ref) v_u_8, (copy) v_u_70
				if v_u_5.level() >= 2 then
					local v72 = p_u_20.feetAt(p_u_21, p71, 0.05)
					local v73 = math.random() * 3.141592653589793 * 2
					for v74 = 1, 5 do
						local v75 = v73 + v74 / 5 * 3.141592653589793 * 2
						local v76 = math.cos(v75)
						local v77 = math.sin(v75)
						local v78 = v72 + Vector3.new(v76, 0, v77) * 3.2 * v_u_26 * p_u_21.fx
						local v79 = {}
						for v80 = 1, 6 do
							local v81 = (v80 / 6 + v74 * 0.13) % 1
							local v82 = v_u_4.part(Vector3.new(0.38, 0.95, 0.12) * v_u_26 * p_u_21.fx, CFrame.new(v78), Color3.fromHSV(v81, 0.38, 1), {
								["transparency"] = 0.25
							})
							local v83 = Instance.new("SpecialMesh")
							v83.MeshType = Enum.MeshType.Sphere
							v83.Parent = v82
							table.insert(v79, v82)
						end
						local v84 = v_u_4.part(Vector3.new(0.32, 0.32, 0.32) * v_u_26 * p_u_21.fx, CFrame.new(v78), v_u_8, {
							["shape"] = Enum.PartType.Ball
						})
						local v85 = v_u_70
						local v86 = {
							["born"] = os.clock(),
							["at"] = v78,
							["petals"] = v79,
							["heart"] = v84,
							["turn"] = v75
						}
						table.insert(v85, v86)
					end
				end
			end
			local v88 = p_u_21.stops
			table.insert(v88, function()
				-- upvalues: (copy) v_u_70
				for _, v89 in v_u_70 do
					for _, v90 in v89.petals do
						v90:Destroy()
					end
					v89.heart:Destroy()
				end
				table.clear(v_u_70)
			end)
			local v_u_91 = true
			local v_u_92 = 0
			local v93 = p_u_21.ticks
			local function v122(p94, p95)
				-- upvalues: (ref) v_u_32, (ref) v_u_91, (ref) p_u_20, (copy) v_u_48, (copy) v_u_34, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28, (copy) v_u_29, (copy) v_u_87, (ref) v_u_92, (copy) v_u_70, (copy) p_u_21
				local v96 = os.clock() - v_u_32
				if v_u_91 or v96 < 0.12 then
					if v96 < 0.12 then
						v_u_91 = false
					end
				else
					v_u_91 = true
					if (p94.Position - p_u_20.camPos()).Magnitude < 150 then
						for _, v97 in { -1, 1 } do
							local v98 = v_u_48.cf * CFrame.new(v97 * v_u_34 * 0.35, v_u_26 * 0.4, 0)
							v_u_27.WorldCFrame = CFrame.lookAt(v98.Position, v98.Position + p94.RightVector * v97 - p94.LookVector * 0.5 + Vector3.new(0, 0.4, 0))
							v_u_28.EmissionDirection = Enum.NormalId.Front
							v_u_28:Emit(8)
							v_u_29:Emit(6)
						end
						v_u_87(p94)
					end
				end
				if p95 - v_u_92 >= 0.33 and (p94.Position - p_u_20.camPos()).Magnitude < 90 then
					v_u_92 = p95
					local v99 = v_u_27
					local v100 = p94.Position
					local v101 = math.random() - 0.5
					local v102 = math.random() - 0.3
					local v103 = math.random() - 0.5
					v99.WorldPosition = v100 + Vector3.new(v101, v102, v103) * 3 * v_u_26
					v_u_29:Emit(1)
				end
				local v104 = os.clock()
				for v105 = #v_u_70, 1, -1 do
					local v106 = v_u_70[v105]
					local v107 = v104 - v106.born
					if v107 >= 1.8 then
						local v108 = v_u_27
						local v109 = v106.at
						local v110 = v_u_26 * 0.6
						v108.WorldPosition = v109 + Vector3.new(0, v110, 0)
						v_u_29:Emit(3)
						for _, v111 in v106.petals do
							v111:Destroy()
						end
						v106.heart:Destroy()
						table.remove(v_u_70, v105)
					else
						local v112 = v107 / 0.35
						local v113 = math.clamp(v112, 0, 1)
						local v114 = v113 * v113 * (3 - v113 * 2)
						local v115 = (v107 - 1.8 + 0.35) / 0.35
						local v116 = math.clamp(v115, 0, 1)
						local v117 = v116 * v116 * (3 - v116 * 2)
						local v118 = v114 * 0.95 + 0.15 + v117 * 0.6
						for v119, v120 in v106.petals do
							local v121 = v106.turn + v119 / 6 * 3.141592653589793 * 2 + v107 * 0.4
							v120.CFrame = CFrame.new(v106.at) * CFrame.Angles(0, v121, 0) * CFrame.Angles(v118, 0, 0) * CFrame.new(0, v_u_26 * 0.45 * p_u_21.fx, 0)
							v120.Transparency = v117 * 0.75 + 0.25
						end
						v106.heart.Transparency = v117
					end
				end
			end
			table.insert(v93, v122)
			p_u_20.particles(p_u_21, "AuraMode", v24, {
				["rate"] = 0.25,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end