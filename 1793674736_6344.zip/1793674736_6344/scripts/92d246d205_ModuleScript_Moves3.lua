require(script.Parent.LookTypes)
local v_u_1 = {
	["blossom_orbit"] = function() -- name: blossom_orbit
		return require(script.blossom_orbit)
	end,
	["thorn_blossom"] = function() -- name: thorn_blossom
		return require(script.thorn_blossom)
	end,
	["crimson_bloom"] = function() -- name: crimson_bloom
		return require(script.crimson_bloom)
	end,
	["nightshade_pinwheel"] = function() -- name: nightshade_pinwheel
		return require(script.nightshade_pinwheel)
	end,
	["iron_mandala"] = function() -- name: iron_mandala
		return require(script.iron_mandala)
	end,
	["void_compass"] = function() -- name: void_compass
		return require(script.void_compass)
	end,
	["blood_trident"] = function() -- name: blood_trident
		return require(script.blood_trident)
	end,
	["moon_rinne"] = function() -- name: moon_rinne
		return require(script.moon_rinne)
	end,
	["rift_crescent"] = function() -- name: rift_crescent
		return require(script.rift_crescent)
	end,
	["scarlet_whirl"] = function() -- name: scarlet_whirl
		return require(script.scarlet_whirl)
	end,
	["eclipse_spiral"] = function() -- name: eclipse_spiral
		return require(script.eclipse_spiral)
	end,
	["inferno_star"] = function() -- name: inferno_star
		return require(script.inferno_star)
	end,
	["thorn_halo"] = function() -- name: thorn_halo
		return require(script.thorn_halo)
	end,
	["arcane_sigil"] = function() -- name: arcane_sigil
		return require(script.arcane_sigil)
	end,
	["tide_tomoe"] = function() -- name: tide_tomoe
		return require(script.tide_tomoe)
	end,
	["frost_thorn"] = function() -- name: frost_thorn
		return require(script.frost_thorn)
	end,
	["glacier_star"] = function() -- name: glacier_star
		return require(script.glacier_star)
	end,
	["frozen_rinne"] = function() -- name: frozen_rinne
		return require(script.frozen_rinne)
	end,
	["abyss_spindle"] = function() -- name: abyss_spindle
		return require(script.abyss_spindle)
	end,
	["starsea_rinne"] = function() -- name: starsea_rinne
		return require(script.starsea_rinne)
	end,
	["azure_flame"] = function() -- name: azure_flame
		return require(script.azure_flame)
	end,
	["polar_dial"] = function() -- name: polar_dial
		return require(script.polar_dial)
	end,
	["blizzard_wheel"] = function() -- name: blizzard_wheel
		return require(script.blizzard_wheel)
	end,
	["dark_maelstrom"] = function() -- name: dark_maelstrom
		return require(script.dark_maelstrom)
	end,
	["ember_trinity"] = function() -- name: ember_trinity
		return require(script.ember_trinity)
	end,
	["astral_bloom"] = function() -- name: astral_bloom
		return require(script.astral_bloom)
	end,
	["crimson_vortex"] = function() -- name: crimson_vortex
		return require(script.crimson_vortex)
	end,
	["corona_gear"] = function() -- name: corona_gear
		return require(script.corona_gear)
	end,
	["mangekyou_byakugan"] = function() -- name: mangekyou_byakugan
		return require(script.mangekyou_byakugan)
	end,
	["crimson_comet"] = function() -- name: crimson_comet
		return require(script.crimson_comet)
	end,
	["pulsar_tomoe"] = function() -- name: pulsar_tomoe
		return require(script.pulsar_tomoe)
	end,
	["mangekyou_jigokugan"] = function() -- name: mangekyou_jigokugan
		return require(script.mangekyou_jigokugan)
	end,
	["astral_sigil"] = function() -- name: astral_sigil
		return require(script.astral_sigil)
	end,
	["red_giant"] = function() -- name: red_giant
		return require(script.red_giant)
	end,
	["void_gaze"] = function() -- name: void_gaze
		return require(script.void_gaze)
	end,
	["nova_trinity"] = function() -- name: nova_trinity
		return require(script.nova_trinity)
	end,
	["dark_star"] = function() -- name: dark_star
		return require(script.dark_star)
	end,
	["nebula_rinne"] = function() -- name: nebula_rinne
		return require(script.nebula_rinne)
	end,
	["chikaragan"] = function() -- name: chikaragan
		return require(script.chikaragan)
	end,
	["raging_current"] = function() -- name: raging_current
		return require(script.raging_current)
	end,
	["hell_butterfly"] = function() -- name: hell_butterfly
		return require(script.hell_butterfly)
	end,
	["raiko_gaze"] = function() -- name: raiko_gaze
		return require(script.raiko_gaze)
	end,
	["kido_seal"] = function() -- name: kido_seal
		return require(script.kido_seal)
	end,
	["shinso_edge"] = function() -- name: shinso_edge
		return require(script.shinso_edge)
	end,
	["shirayuki"] = function() -- name: shirayuki
		return require(script.shirayuki)
	end,
	["quincy_cross"] = function() -- name: quincy_cross
		return require(script.quincy_cross)
	end,
	["sanrei_lattice"] = function() -- name: sanrei_lattice
		return require(script.sanrei_lattice)
	end,
	["kyoka_suigetsu"] = function() -- name: kyoka_suigetsu
		return require(script.kyoka_suigetsu)
	end,
	["black_coffin"] = function() -- name: black_coffin
		return require(script.black_coffin)
	end,
	["senbonzakura"] = function() -- name: senbonzakura
		return require(script.senbonzakura)
	end,
	["hyorinmaru"] = function() -- name: hyorinmaru
		return require(script.hyorinmaru)
	end,
	["ryujin_jakka"] = function() -- name: ryujin_jakka
		return require(script.ryujin_jakka)
	end,
	["getsuga_tensho"] = function() -- name: getsuga_tensho
		return require(script.getsuga_tensho)
	end,
	["hakka_no_togame"] = function() -- name: hakka_no_togame
		return require(script.hakka_no_togame)
	end,
	["gamuza"] = function() -- name: gamuza
		return require(script.gamuza)
	end,
	["resurreccion"] = function() -- name: resurreccion
		return require(script.resurreccion)
	end,
	["gran_rey_cero"] = function() -- name: gran_rey_cero
		return require(script.gran_rey_cero)
	end,
	["cero_inferno"] = function() -- name: cero_inferno
		return require(script.cero_inferno)
	end,
	["tatarforas"] = function() -- name: tatarforas
		return require(script.tatarforas)
	end,
	["los_lobos"] = function() -- name: los_lobos
		return require(script.los_lobos)
	end,
	["pantera"] = function() -- name: pantera
		return require(script.pantera)
	end,
	["compulsory"] = function() -- name: compulsory
		return require(script.compulsory)
	end,
	["murcielago"] = function() -- name: murcielago
		return require(script.murcielago)
	end,
	["inner_hollow"] = function() -- name: inner_hollow
		return require(script.inner_hollow)
	end,
	["vasto_lorde"] = function() -- name: vasto_lorde
		return require(script.vasto_lorde)
	end,
	["hogyoku"] = function() -- name: hogyoku
		return require(script.hogyoku)
	end,
	["soul_king"] = function() -- name: soul_king
		return require(script.soul_king)
	end,
	["almighty"] = function() -- name: almighty
		return require(script.almighty)
	end,
	["exploding_blood"] = function() -- name: exploding_blood
		return require(script.exploding_blood)
	end,
	["lower_moon"] = function() -- name: lower_moon
		return require(script.lower_moon)
	end,
	["blood_sickle"] = function() -- name: blood_sickle
		return require(script.blood_sickle)
	end,
	["black_thunder"] = function() -- name: black_thunder
		return require(script.black_thunder)
	end,
	["thousand_needles"] = function() -- name: thousand_needles
		return require(script.thousand_needles)
	end,
	["zohakuten"] = function() -- name: zohakuten
		return require(script.zohakuten)
	end,
	["dead_calm"] = function() -- name: dead_calm
		return require(script.dead_calm)
	end,
	["biwa_castle"] = function() -- name: biwa_castle
		return require(script.biwa_castle)
	end,
	["destructive_death"] = function() -- name: destructive_death
		return require(script.destructive_death)
	end,
	["cryo_lotus"] = function() -- name: cryo_lotus
		return require(script.cryo_lotus)
	end,
	["demon_seal"] = function() -- name: demon_seal
		return require(script.demon_seal)
	end,
	["moon_breathing"] = function() -- name: moon_breathing
		return require(script.moon_breathing)
	end,
	["sun_breathing"] = function() -- name: sun_breathing
		return require(script.sun_breathing)
	end,
	["demon_king"] = function() -- name: demon_king
		return require(script.demon_king)
	end,
	["glacier_sharingan"] = function() -- name: glacier_sharingan
		return require(script.glacier_sharingan)
	end,
	["kurobyougan"] = function() -- name: kurobyougan
		return require(script.kurobyougan)
	end,
	["yumegan"] = function() -- name: yumegan
		return require(script.yumegan)
	end,
	["kanjogan"] = function() -- name: kanjogan
		return require(script.kanjogan)
	end,
	["fuma_mangekyo"] = function() -- name: fuma_mangekyo
		return require(script.fuma_mangekyo)
	end,
	["kurenai_mangekyo"] = function() -- name: kurenai_mangekyo
		return require(script.kurenai_mangekyo)
	end
}
return function(p_u_2)
	-- upvalues: (copy) v_u_1
	local v_u_3 = {}
	return function(p4)
		-- upvalues: (ref) v_u_1, (copy) v_u_3, (copy) p_u_2
		local v5 = string.match(p4, "^(.+)_[aer]$")
		local v6
		if v5 then
			v6 = v_u_1[v5]
		else
			v6 = nil
		end
		if not (v5 and v6) then
			return nil
		end
		local v7 = v_u_3[v5]
		if not v7 then
			v7 = v6()(p_u_2)
			v_u_3[v5] = v7
		end
		return v7[p4]
	end
end