local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(226, 46, 18)
local v_u_6 = Color3.fromRGB(255, 246, 214)
local v_u_7 = Color3.fromRGB(196, 230, 255)
local v_u_8 = Color3.fromRGB(235, 248, 255)
return function(p_u_9)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8, (copy) v_u_5
	return {
		["w4_ember_trinity"] = function(p_u_10, p11)
			-- upvalues: (ref) v_u_2, (copy) p_u_9, (ref) v_u_4, (ref) v_u_3, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (ref) v_u_5
			local v_u_12 = v_u_2.color(p11.color)
			local v_u_13 = v_u_2.color(p11.color2)
			local v14 = p_u_10.headY / 1.5
			local v_u_15 = math.clamp(v14, 0.7, 3)
			local v_u_16 = nil
			local v_u_19 = p_u_9.throb(p_u_10, 4.2, 1.6, 1.6, function(p17)
				-- upvalues: (ref) v_u_2, (ref) p_u_9, (copy) p_u_10, (copy) v_u_12, (ref) v_u_4, (ref) v_u_16, (ref) v_u_3
				v_u_2.ring(p_u_9.feetAt(p_u_10, p17, 0.15), v_u_12, 5.5 * p_u_10.fx, 0.55, v_u_4.Ring)
				local v18 = v_u_16
				if v18 then
					v18:Emit(v_u_3.level() <= 1 and 2 or 5)
				end
			end)
			local v_u_20 = 0
			local v21 = p_u_10.ticks
			local function v23(_, _, p22)
				-- upvalues: (ref) v_u_20, (copy) v_u_19
				v_u_20 = v_u_20 + p22 * (0.8 + v_u_19() * 12)
			end
			table.insert(v21, v23)
			local v_u_29 = p_u_9.group(p_u_10, function(p24, p25)
				-- upvalues: (copy) v_u_15
				local v26 = CFrame.new
				local v27 = v_u_15 * 1.15
				local v28 = p25 * 1.2
				return p24 * v26(0, v27 + math.sin(v28) * 0.1 * v_u_15, v_u_15 * 1.75) * CFrame.Angles(0, p25 * 0.45, 0)
			end)
			local v_u_35 = p_u_9.group(p_u_10, function()
				-- upvalues: (copy) v_u_29, (ref) p_u_9
				local v30 = v_u_29.cf.Position
				local v31 = p_u_9.camPos() - v30
				local v32 = v31.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v31.Unit
				local v33 = v32.Y
				local v34 = math.abs(v33) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v30, v30 + v32, v34) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v_u_36 = p_u_9.ball(v_u_15 * 1.1, v_u_13, 0)
			p_u_9.pin(p_u_10, v_u_29, v_u_36, CFrame.identity)
			local v_u_37 = p_u_9.ball(v_u_15 * 1.7, v_u_12, 0.45)
			p_u_9.pin(p_u_10, v_u_29, v_u_37, CFrame.identity)
			local v_u_38 = v_u_20
			local v_u_39 = {}
			for v40 = 0, 2 do
				local v41 = p_u_9.bar(Vector3.new(1.55, 3.1, 0.9) * v_u_15, v_u_7, 0.6, Enum.Material.SmoothPlastic)
				p_u_9.pin(p_u_10, v_u_29, v41, CFrame.Angles(0, v40 * 3.141592653589793 / 3, 0))
				table.insert(v_u_39, v41)
			end
			for _, v42 in { 1, -1 } do
				local v43 = p_u_9.bar(Vector3.new(0.95, 0.95, 0.95) * v_u_15, v_u_7, 0.6, Enum.Material.SmoothPlastic)
				p_u_9.pin(p_u_10, v_u_29, v43, CFrame.new(0, v42 * 1.55 * v_u_15, 0) * CFrame.Angles(0.7853981633974483, 0, 0.7853981633974483))
				table.insert(v_u_39, v43)
			end
			for v44 = 0, 2 do
				local v45 = v44 * 3.141592653589793 * 2 / 3 + 0.5
				local v46 = p_u_9.bar(Vector3.new(0.08, 1.5, 0.08) * v_u_15, v_u_13, 0.1)
				p_u_9.pin(p_u_10, v_u_29, v46, CFrame.new(math.cos(v45) * 0.72 * v_u_15, (v44 - 1) * 0.35 * v_u_15, math.sin(v45) * 0.72 * v_u_15) * CFrame.Angles(0, -v45, (v44 - 1) * 0.35 + 0.3))
			end
			local v_u_47 = -1
			local v48 = p_u_10.ticks
			local function v52()
				-- upvalues: (copy) v_u_19, (ref) v_u_47, (copy) v_u_36, (copy) v_u_15, (copy) v_u_37, (copy) v_u_13, (ref) v_u_6, (copy) v_u_39, (ref) v_u_7, (ref) v_u_8
				local v49 = v_u_19()
				if v49 ~= v_u_47 then
					v_u_47 = v49
					local v50 = 1 + v49 * 0.35
					v_u_36.Size = Vector3.new(1.1, 1.1, 1.1) * v_u_15 * v50
					v_u_37.Size = Vector3.new(1.7, 1.7, 1.7) * v_u_15 * v50
					v_u_36.Color = v_u_13:Lerp(v_u_6, v49)
					for _, v51 in v_u_39 do
						v51.Color = v_u_7:Lerp(v_u_8, v49)
						v51.Transparency = 0.6 - 0.25 * v49
					end
				end
			end
			table.insert(v48, v52)
			local v53 = p_u_9.picture(v_u_15 * 4.4, v_u_4.EmberSun, v_u_13, 0.3)
			p_u_9.add(p_u_10, v53, function(_, p54)
				-- upvalues: (copy) v_u_35, (copy) v_u_15
				return v_u_35.cf * CFrame.new(0, v_u_15 * 0.92, 0) * CFrame.Angles(0, p54 * 0.25, 0)
			end)
			local v55 = p_u_9.picture(v_u_15 * 2.4, v_u_4.EmberTrinity, v_u_12, 0)
			p_u_9.add(p_u_10, v55, function()
				-- upvalues: (copy) v_u_35, (copy) v_u_15, (ref) v_u_38
				return v_u_35.cf * CFrame.new(0, v_u_15 * 1, 0) * CFrame.Angles(0, -v_u_38, 0)
			end)
			local v56 = p_u_9.picture(v_u_15 * 0.85, v_u_4.Ring, v_u_5, 0)
			p_u_9.add(p_u_10, v56, function()
				-- upvalues: (copy) v_u_35, (copy) v_u_15
				return v_u_35.cf * CFrame.new(0, v_u_15 * 1.04, 0)
			end)
			local v_u_57 = v_u_15 * 2.35
			local v58 = p_u_9.picture(v_u_57 * 2, v_u_4.Ring, v_u_12, 0.1)
			p_u_9.add(p_u_10, v58, function(_, p59)
				-- upvalues: (copy) v_u_35, (copy) v_u_15
				return v_u_35.cf * CFrame.new(0, v_u_15 * 0.6, 0) * CFrame.Angles(0, p59 * 0.4, 0)
			end)
			for v_u_60 = 1, 3 do
				local v61 = p_u_9.picture(v_u_15 * 1.05, v_u_4.EmberComma, v_u_12, 0)
				p_u_9.add(p_u_10, v61, function(_, p62)
					-- upvalues: (ref) v_u_38, (copy) v_u_60, (copy) v_u_35, (copy) v_u_57, (copy) v_u_15
					local v63 = p62 * 0.9 + v_u_38 * 0.15 + (v_u_60 - 1) * 3.141592653589793 * 2 / 3
					return v_u_35.cf * CFrame.new(math.cos(v63) * v_u_57, v_u_15 * 0.66, math.sin(v63) * v_u_57) * CFrame.Angles(0, -v63 + 3.141592653589793, 0)
				end)
			end
			for v64 = 1, 5 do
				local v_u_65 = (v64 - 1) / 5 * 3.141592653589793 * 2
				local v_u_66 = (v64 % 2 * 0.45 + 0.9) * v_u_15
				local v67 = p_u_9.bar
				local v68 = v_u_15 * 0.34
				local v69 = v_u_15 * 0.34
				local v70 = v67(Vector3.new(v68, v_u_66, v69), v_u_7, 0.35, Enum.Material.SmoothPlastic)
				p_u_9.add(p_u_10, v70, function(p71, p72)
					-- upvalues: (copy) v_u_65, (ref) p_u_9, (copy) p_u_10, (copy) v_u_66, (copy) v_u_15
					local v73 = v_u_65 + p72 * 0.15
					local v74 = p_u_9.feetAt(p_u_10, p71, v_u_66 * 0.4)
					local v75 = math.cos(v73)
					local v76 = math.sin(v73)
					local v77 = v74 + Vector3.new(v75, 0, v76) * 1.8 * v_u_15
					return CFrame.new(v77) * CFrame.Angles(0, -v73, 0) * CFrame.Angles(0, 0, -0.35) * CFrame.Angles(0, 0.7853981633974483, 0)
				end)
			end
			local v78 = Instance.new("ParticleEmitter")
			v78.Texture = v_u_4.EmberCurl
			v78.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v78.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v78.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_13), ColorSequenceKeypoint.new(0.45, v_u_12), ColorSequenceKeypoint.new(1, v_u_5) })
			v78.LightEmission = 0.55
			v78.LightInfluence = 0
			v78.Lifetime = NumberRange.new(0.4, 0.6)
			v78.Size = NumberSequence.new(v_u_15 * 0.9 * p_u_10.fx, v_u_15 * 1.4 * p_u_10.fx)
			v78.Rotation = NumberRange.new(0, 360)
			v78.RotSpeed = NumberRange.new(-90, 90)
			v78.Speed = NumberRange.new(4 * p_u_10.fx, 8 * p_u_10.fx)
			v78.SpreadAngle = Vector2.new(180, 180)
			v78.Drag = 4
			v78.Rate = 0
			v78.Enabled = false
			v78.Parent = v_u_36
			v_u_16 = v78
			local v79 = p_u_9.particles
			local v80 = {
				["rate"] = 0.5,
				["glow"] = 0.6,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Embers" }
			}
			local v81 = v_u_15 * 1.15
			local v82 = v_u_15 * 1.75
			v80.at = Vector3.new(0, v81, v82)
			v79(p_u_10, "Fire", v_u_12, v80)
			p_u_9.particles(p_u_10, "AuraMode", v_u_12, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end