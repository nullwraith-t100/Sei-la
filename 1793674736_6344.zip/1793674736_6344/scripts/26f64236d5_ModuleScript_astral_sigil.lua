local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(205, 255, 255)
local v_u_5 = Color3.new(1, 1, 1)
return function(p_u_6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	return {
		["w5_astral_sigil"] = function(p_u_7, p8)
			-- upvalues: (ref) v_u_2, (copy) p_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5
			local v_u_9 = p_u_7.character:GetScale()
			local v_u_10 = v_u_2.color(p8.color)
			local v_u_11 = (1 / 0)
			local v_u_13 = p_u_6.throb(p_u_7, 5, 1.8, 1.6, function(p12)
				-- upvalues: (ref) v_u_2, (ref) p_u_6, (copy) p_u_7, (copy) v_u_10, (ref) v_u_3
				v_u_2.ring(p_u_6.feetAt(p_u_7, p12, 0.15), v_u_10, 5.5 * p_u_7.fx, 0.55, v_u_3.Ring)
			end)
			local v_u_14 = 0
			local v_u_15 = 0
			local v16 = p_u_7.ticks
			local function v22(_, _, p17)
				-- upvalues: (copy) v_u_13, (ref) v_u_15, (ref) v_u_11, (ref) v_u_14
				local v18 = v_u_13()
				if v_u_15 < v18 then
					v_u_11 = 0
				else
					v_u_11 = v_u_11 + p17
				end
				v_u_15 = v18
				if v_u_11 < 0.3 then
					local v19 = v_u_11 / 0.3
					v_u_14 = v19 * v19 * (3 - v19 * 2)
					return
				elseif v_u_11 < 1.4 then
					v_u_14 = 1
				else
					local v20 = 1 - (v_u_11 - 1.4) / 0.8
					local v21 = math.max(v20, 0)
					v_u_14 = v21 * v21 * (3 - v21 * 2)
				end
			end
			table.insert(v16, v22)
			local v23 = 0.35 * v_u_9
			local v_u_24 = Vector3.new(0, v23, 0)
			local v_u_30 = p_u_6.group(p_u_7, function(p25)
				-- upvalues: (copy) v_u_24, (ref) p_u_6, (copy) v_u_9
				local v26 = p25.Position + v_u_24
				local v27 = p_u_6.camPos() - v26
				local v28
				if v27.Magnitude > 0.001 then
					v28 = v27.Unit
				else
					v28 = -p25.LookVector
				end
				local v29 = v26 - v28 * 1.3 * v_u_9
				return CFrame.lookAt(v29, v29 + v28)
			end)
			local v33 = p_u_6.group(p_u_7, function(p31, p32)
				-- upvalues: (copy) v_u_24
				return CFrame.new(p31.Position + v_u_24) * CFrame.Angles(0.5, 0, 0.25) * CFrame.Angles(0, p32 * 0.7, 0)
			end)
			local v36 = p_u_6.group(p_u_7, function(p34, p35)
				-- upvalues: (copy) v_u_24
				return CFrame.new(p34.Position + v_u_24) * CFrame.Angles(-0.45, 0, -0.3) * CFrame.Angles(0, -p35 * 0.55, 0)
			end)
			local v_u_37 = 2.7 * v_u_9
			local v_u_38 = 3.4 * v_u_9
			local v_u_39 = v_u_14
			local v40 = {}
			for v_u_41 = 1, 6 do
				local v42 = v_u_41 % 2 == 1
				local v43 = (v_u_41 - 1) // 2
				local v_u_44
				if v42 then
					v_u_44 = v33
				else
					v_u_44 = v36
				end
				local v_u_45 = (v42 and 1.5707963267948966 or -1.5707963267948966) + v43 * 3.141592653589793 * 2 / 3
				local v_u_46 = v43 * 3.141592653589793 * 2 / 3 + (v42 and 0 or 1.0471975511965976)
				local function v_u_62(_, p47) -- name: place
					-- upvalues: (copy) v_u_44, (copy) v_u_46, (copy) v_u_37, (copy) v_u_41, (copy) v_u_9, (copy) v_u_30, (copy) v_u_45, (copy) v_u_38, (ref) v_u_39
					local v48 = v_u_44.cf
					local v49 = v_u_46
					local v50 = math.cos(v49) * v_u_37
					local v51 = p47 * 1.3 + v_u_41
					local v52 = math.sin(v51) * 0.25 * v_u_9
					local v53 = v_u_46
					local v54 = math.sin(v53) * v_u_37
					local v55 = v48 * Vector3.new(v50, v52, v54)
					local v56 = v_u_30.cf
					local v57 = v_u_45
					local v58 = math.cos(v57) * v_u_38
					local v59 = v_u_45
					local v60 = math.sin(v59) * v_u_38
					local v61 = v56 * Vector3.new(v58, v60, 0)
					return CFrame.new(v55:Lerp(v61, v_u_39))
				end
				local v63 = p_u_6.ball(0.42 * v_u_9, v_u_4, 0)
				p_u_6.add(p_u_7, v63, v_u_62)
				table.insert(v40, v63)
				local v_u_64 = p_u_6.picture(1.8 * v_u_9, v_u_3.AstralStar, v_u_10, 0)
				p_u_6.add(p_u_7, v_u_64, function(p65, p66)
					-- upvalues: (copy) v_u_62, (ref) p_u_6, (copy) v_u_41, (ref) v_u_39, (copy) v_u_9, (copy) v_u_64
					local v67 = v_u_62(p65, p66).Position
					local v68 = p_u_6.camPos() - v67
					local v69 = v68.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v68.Unit
					local v70 = p66 * 5 + v_u_41 * 1.9
					local v71 = (math.sin(v70) * 0.4 + 1.6 + v_u_39 * 1.1) * v_u_9
					v_u_64.Size = Vector3.new(v71, 0.05, v71)
					return CFrame.lookAt(v67, v67 + v69) * CFrame.Angles(1.5707963267948966, 0, 0)
				end)
			end
			local v_u_72 = {}
			for v73 = 1, 6 do
				local v74 = (v73 + 1) % 6 + 1
				local v75 = Instance.new("Attachment")
				v75.Parent = v40[v73]
				local v76 = Instance.new("Attachment")
				v76.Parent = v40[v74]
				local v77 = p_u_6.ray(v75, v76, v_u_10, 0.14 * v_u_9, 0.14 * v_u_9)
				v77.LightEmission = 1
				v77.Transparency = NumberSequence.new(0.2)
				table.insert(v_u_72, v77)
			end
			local v_u_78 = -1
			local v79 = p_u_7.ticks
			local function v85()
				-- upvalues: (ref) v_u_39, (ref) v_u_78, (copy) v_u_9, (copy) v_u_10, (ref) v_u_5, (copy) v_u_72
				local v80 = v_u_39 * 20 + 0.5
				local v81 = math.floor(v80) / 20
				if v81 ~= v_u_78 then
					v_u_78 = v81
					local v82 = (v81 * 0.16 + 0.14) * v_u_9
					local v83 = ColorSequence.new(v_u_10:Lerp(v_u_5, v81 * 0.6))
					for _, v84 in v_u_72 do
						v84.Width0 = v82
						v84.Width1 = v82
						v84.Color = v83
					end
				end
			end
			table.insert(v79, v85)
			local v86, v_u_87 = p_u_6.picture(4 * v_u_9, v_u_3.AstralSigil, v_u_10, 1)
			p_u_6.pin(p_u_7, v_u_30, v86, CFrame.Angles(1.5707963267948966, 0, 0))
			local v88, v_u_89 = p_u_6.picture(v_u_38 * 2.25, v_u_3.Ring, v_u_10, 1)
			p_u_6.pin(p_u_7, v_u_30, v88, CFrame.Angles(1.5707963267948966, 0, 0))
			local v_u_90 = -1
			local v91 = p_u_7.ticks
			local function v96()
				-- upvalues: (ref) v_u_39, (ref) v_u_90, (copy) v_u_87, (copy) v_u_89
				local v92 = v_u_39 * 20 + 0.5
				local v93 = math.floor(v92) / 20
				if v93 ~= v_u_90 then
					v_u_90 = v93
					for _, v94 in v_u_87 do
						v94.Transparency = 1 - v93 * 0.9
					end
					for _, v95 in v_u_89 do
						v95.Transparency = 1 - v93 * 0.75
					end
				end
			end
			table.insert(v91, v96)
			p_u_6.particles(p_u_7, "Petals", v_u_4, {
				["rate"] = 0.8,
				["glow"] = 0.7,
				["only"] = nil,
				["only"] = { "Motes" }
			})
			p_u_6.particles(p_u_7, "AuraMode", v_u_10, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end