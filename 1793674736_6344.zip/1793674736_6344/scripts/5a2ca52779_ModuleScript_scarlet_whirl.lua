local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return {
		["w3_scarlet_whirl"] = function(p_u_5, p6)
			-- upvalues: (ref) v_u_2, (copy) p_u_4, (ref) v_u_3
			local v_u_7 = v_u_2.color(p6.color)
			local v8 = v_u_2.color(p6.color2)
			local v_u_9 = p_u_4.rgb(255, 34, 46)
			local v_u_10 = p_u_5.fx <= 1 and 1 or p_u_5.fx / 1.35
			local v_u_12 = p_u_4.throb(p_u_5, 3.4, 1.2, 1.6, function(p11)
				-- upvalues: (ref) v_u_2, (ref) p_u_4, (copy) p_u_5, (copy) v_u_9, (ref) v_u_3, (copy) v_u_7
				v_u_2.ring(p_u_4.feetAt(p_u_5, p11, 0.15), v_u_9, 4.5 * p_u_5.fx, 0.4, v_u_3.Ring)
				v_u_2.burst("Slash", p11.Position, v_u_7, 1.1 * p_u_5.fx)
			end)
			local v_u_13 = 0
			local v14 = p_u_5.ticks
			local function v16(_, _, p15)
				-- upvalues: (ref) v_u_13, (copy) v_u_12
				v_u_13 = v_u_13 + p15 * (1.7 + v_u_12() * 6)
			end
			table.insert(v14, v16)
			local v_u_17 = p_u_5.feet + 0.5
			local v_u_18 = p_u_5.headY + 0.7
			local v_u_19 = {}
			local v_u_20 = {}
			v_u_19[1] = CFrame.identity
			v_u_20[1] = 0
			v_u_19[2] = CFrame.identity
			v_u_20[2] = 0
			v_u_19[3] = CFrame.identity
			v_u_20[3] = 0
			v_u_19[4] = CFrame.identity
			v_u_20[4] = 0
			v_u_19[5] = CFrame.identity
			v_u_20[5] = 0
			v_u_19[6] = CFrame.identity
			v_u_20[6] = 0
			local v21 = p_u_5.ticks
			local function v40(p22, p23)
				-- upvalues: (copy) v_u_12, (copy) v_u_20, (ref) v_u_13, (copy) v_u_10, (copy) v_u_17, (copy) v_u_18, (copy) v_u_19
				local v24 = v_u_12()
				for v25 = 1, 6 do
					local v26 = (p23 * 0.3 + (v25 - 1) / 6) % 1
					v_u_20[v25] = v26
					local v27 = v_u_13 + (v25 - 1) * 2.4 + v26 * 3.2
					local v28 = (1.6 + 1.6 * v26 + 0.7 * v24) * v_u_10
					local v29 = p22.Position
					local v30 = math.cos(v27) * v28
					local v31 = v_u_17 + (v_u_18 - v_u_17) * v26
					local v32 = math.sin(v27) * v28
					local v33 = v29 + Vector3.new(v30, v31, v32)
					local v34 = -math.sin(v27)
					local v35 = math.cos(v27)
					local v36 = Vector3.new(v34, 0.32, v35).Unit
					local v37 = math.cos(v27)
					local v38 = math.sin(v27)
					local v39 = Vector3.new(v37, 0, v38)
					v_u_19[v25] = CFrame.fromMatrix(v33, v39, v39:Cross(v36) * -1) * CFrame.Angles(0, -p23 * 7 - v25, 0)
				end
			end
			table.insert(v21, v40)
			local v_u_41 = v_u_13
			local v_u_42 = {}
			local v_u_43 = {}
			for v_u_44 = 1, 6 do
				local v_u_45 = {}
				for v46 = 1, 3 do
					local v47 = (v46 - 1) / 3 * 2.2689280275926285
					local v48 = v46 / 3 * 2.2689280275926285
					local v49 = 1.2 * v_u_10
					local v50 = math.cos(v47) * v49
					local v51 = math.sin(v47) * v49
					local v52 = Vector3.new(v50, 0, v51)
					local v53 = math.cos(v48) * v49
					local v54 = math.sin(v48) * v49
					local v55 = Vector3.new(v53, 0, v54)
					local v56 = (0.64 - (v46 - 1) * 0.19) * v_u_10
					local v57 = p_u_4.bar
					local v58 = 0.15 * v_u_10
					local v59 = (v55 - v52).Magnitude + 0.1 * v_u_10
					local v60 = Vector3.new(v56, v58, v59)
					local v61
					if v46 == 3 then
						v61 = v8
					else
						v61 = v_u_9
					end
					local v62 = v57(v60, v61, 1)
					local v_u_63 = CFrame.lookAt((v52 + v55) / 2, v55)
					p_u_4.add(p_u_5, v62, function()
						-- upvalues: (copy) v_u_19, (copy) v_u_44, (copy) v_u_63
						return v_u_19[v_u_44] * v_u_63
					end)
					table.insert(v_u_45, v62)
				end
				local v64 = p_u_4.tail
				local v65 = v_u_45[3]
				local v66 = 0.45 * v_u_10
				table.insert(v_u_42, v64(v65, v8, v_u_7, v66, 0.35))
				v_u_43[v_u_44] = 0
				local v_u_67 = -1
				local v_u_68 = false
				local v69 = p_u_5.ticks
				local function v78()
					-- upvalues: (copy) v_u_20, (copy) v_u_44, (copy) v_u_42, (ref) v_u_68, (copy) v_u_43, (ref) v_u_67, (copy) v_u_45
					local v70 = v_u_20[v_u_44]
					local v71 = v_u_42[v_u_44]
					if v_u_68 then
						v_u_68 = false
						v71.Enabled = true
					end
					if v70 < v_u_43[v_u_44] and v71.Enabled then
						v71.Enabled = false
						v71:Clear()
						v_u_68 = true
					end
					v_u_43[v_u_44] = v70
					local v72 = v70 / 0.12
					local v73 = (1 - v70) / 0.15
					local v74 = math.min(v72, v73)
					local v75 = (1 - math.clamp(v74, 0, 1)) * 20 + 0.5
					local v76 = math.floor(v75) / 20
					if v76 ~= v_u_67 then
						v_u_67 = v76
						for _, v77 in v_u_45 do
							v77.Transparency = v76
						end
					end
				end
				table.insert(v69, v78)
			end
			for v_u_79 = 1, 6 do
				local v80 = p_u_4.ball(0.42 * v_u_10, v_u_9, 0)
				p_u_4.add(p_u_5, v80, function(p81, p82)
					-- upvalues: (ref) v_u_41, (copy) v_u_79, (copy) v_u_10, (ref) p_u_4, (copy) p_u_5
					local v83 = -v_u_41 * 0.7 + (v_u_79 - 1) / 6 * 3.141592653589793 * 2
					local v84 = 2.5 * v_u_10
					local v85 = CFrame.new
					local v86 = p_u_4.feetAt
					local v87 = p_u_5
					local v88 = p82 * 2.5 + v_u_79
					local v89 = v86(v87, p81, math.sin(v88) * 0.08 + 0.35)
					local v90 = math.cos(v83) * v84
					local v91 = math.sin(v83) * v84
					return v85(v89 + Vector3.new(v90, 0, v91))
				end)
				p_u_4.tail(v80, v8, v_u_7, 0.26 * v_u_10, 0.28)
			end
			p_u_4.particles(p_u_5, "AuraMode", v_u_7, {
				["rate"] = 0.5,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
		end
	}
end