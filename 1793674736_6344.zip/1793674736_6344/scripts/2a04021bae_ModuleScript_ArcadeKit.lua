local v1 = game:GetService("Players")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(script.Parent.Sfx)
local v_u_4 = {
	["FONT"] = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy),
	["GOLD"] = Color3.fromRGB(255, 214, 60),
	["GREEN"] = Color3.fromRGB(110, 255, 90),
	["RED"] = Color3.fromRGB(255, 70, 90),
	["CYAN"] = Color3.fromRGB(80, 215, 255),
	["PURPLE"] = Color3.fromRGB(190, 110, 255),
	["WHITE"] = Color3.new(1, 1, 1),
	["BOARD"] = Color3.fromRGB(16, 18, 32)
}
local v_u_5 = v1.LocalPlayer
function v_u_4.tween(p6, p7, p8, p9, p10) -- name: tween
	-- upvalues: (copy) v_u_2
	local v11 = v_u_2:Create(p6, TweenInfo.new(p7, p9 or Enum.EasingStyle.Quad, p10 or Enum.EasingDirection.Out), p8)
	v11:Play()
	return v11
end
function v_u_4.main() -- name: main
	-- upvalues: (copy) v_u_5
	return v_u_5:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
end
function v_u_4.find(p12) -- name: find
	-- upvalues: (copy) v_u_4
	local v13 = v_u_4.main()
	for v14 in string.gmatch(p12, "[^%.]+") do
		if not v13 then
			continue
		end
		v13 = v13:FindFirstChild(v14)
	end
	return v13
end
function v_u_4.scaleNamed(p15, p16) -- name: scaleNamed
	local v17 = p15:FindFirstChild(p16)
	if v17 and v17:IsA("UIScale") then
		return v17
	end
	local v18 = Instance.new("UIScale")
	v18.Name = p16
	v18.Parent = p15
	return v18
end
local function v_u_26(p19) -- name: tiles
	for _, v_u_20 in p19:GetDescendants() do
		if not v_u_20:IsA("ImageLabel") or v_u_20:GetAttribute("Ui-Scale") ~= "ImageTileScale" then
			continue
		end
		local v_u_21 = v_u_20.Parent
		if not (v_u_21 and v_u_21:IsA("GuiObject")) then
			continue
		end
		local v22 = v_u_20:GetAttribute("Ui-Scale-Rate")
		local v_u_23 = type(v22) ~= "number" and 4 or math.max(v22, 0.1)
		v_u_21:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- name: update
			-- upvalues: (copy) v_u_21, (copy) v_u_23, (copy) v_u_20
			local v24 = v_u_21.AbsoluteSize.X / v_u_23
			if v24 >= 1 then
				v_u_20.TileSize = UDim2.fromOffset(v24, v24)
			end
		end)
		local v25 = v_u_21.AbsoluteSize.X / v_u_23
		if v25 < 1 then
			continue
		end
		v_u_20.TileSize = UDim2.fromOffset(v25, v25)
	end
end
v_u_4.tiles = v_u_26
function v_u_4.motion(p_u_27) -- name: motion
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v_u_28 = p_u_27:FindFirstChild("Pop")
	if not (v_u_28 and v_u_28:IsA("UIScale")) then
		v_u_28 = Instance.new("UIScale")
		v_u_28.Name = "Pop"
		v_u_28.Parent = p_u_27
	end
	local v29 = p_u_27:GetAttribute("Ui-Hover-Rate")
	local v30 = p_u_27:GetAttribute("Ui-Click-Rate")
	local v_u_31 = type(v29) ~= "number" and 1.08 or v29
	local v_u_32 = type(v30) ~= "number" and 0.9 or v30
	p_u_27.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_28, (copy) v_u_31, (copy) p_u_27, (ref) v_u_3
		local v33 = {
			["Scale"] = v_u_31
		}
		v_u_4.tween(v_u_28, 0.1, v33)
		if p_u_27.Visible and p_u_27.Active then
			v_u_3.play("Hover")
		end
	end)
	p_u_27.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_28
		v_u_4.tween(v_u_28, 0.1, {
			["Scale"] = 1
		})
	end)
	p_u_27.Activated:Connect(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_28, (copy) v_u_32
		v_u_3.play("Click")
		local v34 = {
			["Scale"] = v_u_32
		}
		v_u_4.tween(v_u_28, 0.08, v34)
		task.delay(0.08, function()
			-- upvalues: (ref) v_u_4, (ref) v_u_28
			v_u_4.tween(v_u_28, 0.2, {
				["Scale"] = 1
			}, Enum.EasingStyle.Back)
		end)
	end)
end
function v_u_4.setText(p35, p36) -- name: setText
	local v37 = p35:FindFirstChild("TextLabel")
	if v37 and v37:IsA("TextLabel") then
		v37.Text = p36
	end
end
function v_u_4.paint(p38, p39, p40, p41) -- name: paint
	local v42
	if p41 then
		v42 = p38:FindFirstChild(p41)
	else
		v42 = p38:FindFirstChildOfClass("UIGradient")
	end
	if v42 and v42:IsA("UIGradient") then
		v42.Color = ColorSequence.new(p39, p40)
	end
end
function v_u_4.button(p43, p44, p45) -- name: button
	-- upvalues: (copy) v_u_4, (copy) v_u_26
	local v46 = p43:Clone()
	v46.Name = p44
	v46.Visible = true
	v46.Selectable = true
	for v47 in v46:GetAttributes() do
		if v47 ~= "Ui-Close" and (v47 ~= "Ui-Frame" and (v47 ~= "Ui-Product" and v47 ~= "Ui-Pass")) then
			continue
		end
		v46:SetAttribute(v47, nil)
	end
	v_u_4.setText(v46, p45)
	v_u_4.motion(v46)
	v_u_26(v46)
	return v46
end
function v_u_4.label(p48, p49, p50, p51, p52, p53, p54) -- name: label
	-- upvalues: (copy) v_u_4
	local v55 = Instance.new("TextLabel")
	v55.Name = p49
	v55.BackgroundTransparency = 1
	v55.AnchorPoint = Vector2.new(0.5, 0.5)
	v55.Size = p51
	v55.Position = p52
	v55.FontFace = v_u_4.FONT
	v55.TextScaled = true
	v55.Text = p50
	v55.TextColor3 = p53 or v_u_4.WHITE
	v55.ZIndex = 20
	local v56 = Instance.new("UIStroke")
	v56.Thickness = p54 or 2.5
	v56.Color = Color3.new(0, 0, 0)
	v56.Parent = v55
	v55.Parent = p48
	return v55
end
function v_u_4.bump(p57, p58) -- name: bump
	-- upvalues: (copy) v_u_4
	local v59 = p57:FindFirstChild("Bump")
	if not (v59 and v59:IsA("UIScale")) then
		v59 = Instance.new("UIScale")
		v59.Name = "Bump"
		v59.Parent = p57
	end
	v59.Scale = 1 + (p58 or 0.25)
	v_u_4.tween(v59, 0.35, {
		["Scale"] = 1
	}, Enum.EasingStyle.Back)
end
function v_u_4.float(p60, p61, p62, p63, p64, p65) -- name: float
	-- upvalues: (copy) v_u_4
	local v66 = v_u_4.label
	local v67 = UDim2.fromOffset(p64 * 5, p64)
	local v68 = p64 / 12
	local v_u_69 = v66(p60, "Float", p61, v67, p63, p62, (math.max(1.5, v68)))
	v_u_69.ZIndex = 40
	local v70 = v_u_69:FindFirstChild("Bump")
	if not (v70 and v70:IsA("UIScale")) then
		v70 = Instance.new("UIScale")
		v70.Name = "Bump"
		v70.Parent = v_u_69
	end
	v70.Scale = 0.3
	v_u_4.tween(v70, 0.25, {
		["Scale"] = 1
	}, Enum.EasingStyle.Back)
	local v_u_71 = v_u_69:FindFirstChildOfClass("UIStroke")
	v_u_4.tween(v_u_69, 0.9, {
		["Position"] = p63 - UDim2.fromOffset(0, p65 or p64 * 1.6)
	})
	task.delay(0.5, function()
		-- upvalues: (ref) v_u_4, (copy) v_u_69, (copy) v_u_71
		v_u_4.tween(v_u_69, 0.4, {
			["TextTransparency"] = 1
		})
		if v_u_71 then
			v_u_4.tween(v_u_71, 0.4, {
				["Transparency"] = 1
			})
		end
	end)
	task.delay(0.95, function()
		-- upvalues: (copy) v_u_69
		v_u_69:Destroy()
	end)
end
function v_u_4.burst(p72, p73, p74, p75) -- name: burst
	-- upvalues: (copy) v_u_4
	local v_u_76 = Instance.new("Frame")
	v_u_76.Name = "Burst"
	v_u_76.BackgroundTransparency = 1
	v_u_76.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_76.Position = p73
	v_u_76.Size = UDim2.fromOffset(p74 * 0.4, p74 * 0.4)
	v_u_76.ZIndex = 35
	local v77 = Instance.new("UICorner")
	v77.CornerRadius = UDim.new(1, 0)
	v77.Parent = v_u_76
	local v78 = Instance.new("UIStroke")
	local v79 = p74 * 0.12
	v78.Thickness = math.max(2, v79)
	v78.Color = p75
	v78.Parent = v_u_76
	v_u_76.Parent = p72
	v_u_4.tween(v_u_76, 0.35, {
		["Size"] = UDim2.fromOffset(p74 * 2.2, p74 * 2.2)
	})
	v_u_4.tween(v78, 0.35, {
		["Transparency"] = 1,
		["Thickness"] = 1
	})
	task.delay(0.4, function()
		-- upvalues: (copy) v_u_76
		v_u_76:Destroy()
	end)
end
function v_u_4.sparks(p80, p81, p82, p83, p84) -- name: sparks
	-- upvalues: (copy) v_u_4
	for v85 = 1, p84 do
		local v_u_86 = Instance.new("Frame")
		v_u_86.Name = "Spark"
		v_u_86.BorderSizePixel = 0
		local v87
		if v85 % 3 == 0 then
			v87 = v_u_4.WHITE
		else
			v87 = p83
		end
		v_u_86.BackgroundColor3 = v87
		v_u_86.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_86.Position = p81
		local v88 = p82 * (0.18 + math.random() * 0.14)
		local v89 = math.max(3, v88)
		v_u_86.Size = UDim2.fromOffset(v89, v89)
		v_u_86.Rotation = math.random(0, 90)
		v_u_86.ZIndex = 36
		v_u_86.Parent = p80
		local v90 = math.random() * 3.141592653589793 * 2
		local v91 = p82 * (1 + math.random() * 1.6)
		v_u_4.tween(v_u_86, 0.45 + math.random() * 0.2, {
			["Position"] = nil,
			["Rotation"] = nil,
			["BackgroundTransparency"] = 1,
			["Position"] = p81 + UDim2.fromOffset(math.cos(v90) * v91, math.sin(v90) * v91),
			["Rotation"] = v_u_86.Rotation + math.random(-180, 180)
		})
		task.delay(0.7, function()
			-- upvalues: (copy) v_u_86
			v_u_86:Destroy()
		end)
	end
end
local v_u_92 = {}
function v_u_4.shake(p_u_93, p_u_94, p_u_95) -- name: shake
	-- upvalues: (copy) v_u_92
	local v_u_96 = v_u_92[p_u_93] or p_u_93.Position
	v_u_92[p_u_93] = v_u_96
	local v_u_97 = os.clock() + (p_u_95 or 0.25)
	task.spawn(function()
		-- upvalues: (copy) v_u_97, (copy) p_u_93, (copy) p_u_95, (copy) v_u_96, (copy) p_u_94, (ref) v_u_92
		while os.clock() < v_u_97 and p_u_93.Parent do
			local v98 = (v_u_97 - os.clock()) / (p_u_95 or 0.25)
			p_u_93.Position = v_u_96 + UDim2.fromOffset((math.random() * 2 - 1) * p_u_94 * v98, (math.random() * 2 - 1) * p_u_94 * v98)
			task.wait()
		end
		p_u_93.Position = v_u_96
		v_u_92[p_u_93] = nil
	end)
end
function v_u_4.box(p99, p100, p101, p102) -- name: box
	local v103 = Instance.new("Frame")
	v103.Name = p100
	v103.BackgroundColor3 = p101
	v103.BackgroundTransparency = p102
	v103.BorderSizePixel = 0
	local v104 = Instance.new("UICorner")
	v104.CornerRadius = UDim.new(0, 8)
	v104.Parent = v103
	v103.Parent = p99
	return v103
end
function v_u_4.clock(p105) -- name: clock
	local v106 = math.ceil(p105)
	local v107 = math.max(0, v106)
	return string.format("%d:%02d", v107 // 60, v107 % 60)
end
return v_u_4