local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF7A1A")
local v_u_8 = Color3.fromHex("FFD84A")
local v_u_9 = Color3.fromRGB(226, 46, 18)
local v_u_10 = Color3.fromRGB(14, 8, 6)
local v_u_11 = Color3.fromRGB(255, 246, 214)
local v_u_12 = Color3.fromRGB(196, 230, 255)
local v_u_13 = Color3.fromRGB(110, 178, 236)
local v_u_14 = Color3.fromRGB(235, 248, 255)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.PartType.Cylinder
local v_u_17 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_31(p18, p19, p20, p21, p22, p23) -- name: picture
	-- upvalues: (copy) v_u_4
	local v24 = v_u_4.part
	local v25 = p19 * 2
	local v26 = p19 * 2
	local v27 = v24(Vector3.new(v25, 0.05, v26), p18, p21, {
		["transparency"] = 1
	})
	local v28
	if p23 then
		v28 = { Enum.NormalId.Top }
	else
		v28 = { Enum.NormalId.Top, Enum.NormalId.Bottom }
	end
	for _, v29 in v28 do
		local v30 = Instance.new("Decal")
		v30.Face = v29
		v30.Texture = p20
		v30.Color3 = p21
		v30.Transparency = p22
		v30.Parent = v27
	end
	return v27
end
local function v_u_35(p32, p33) -- name: setAlpha
	for _, v34 in p32:GetChildren() do
		if not v34:IsA("Decal") then
			continue
		end
		v34.Transparency = p33
	end
end
local function v_u_40(p36, p37, p38) -- name: curls
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_9
	local v39 = Instance.new("ParticleEmitter")
	v39.Texture = v_u_6.EmberCurl
	v39.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v39.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v39.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_8), ColorSequenceKeypoint.new(0.45, v_u_7), ColorSequenceKeypoint.new(1, v_u_9) })
	v39.LightEmission = 0.55
	v39.LightInfluence = 0
	v39.Lifetime = NumberRange.new(p38 * 0.75, p38)
	v39.Size = NumberSequence.new(p37 * 0.8, p37 * 1.25)
	v39.Rotation = NumberRange.new(0, 360)
	v39.RotSpeed = NumberRange.new(-90, 90)
	v39.Speed = NumberRange.new(0)
	v39.Rate = 0
	v39.Enabled = false
	v39.Parent = p36
	return v39
end
local function v_u_47(p41, p42, p43, p44) -- name: curlBurst
	-- upvalues: (copy) v_u_3, (copy) v_u_40, (copy) v_u_1
	local v45 = Instance.new("Attachment")
	v45.WorldPosition = p41
	v45.Parent = v_u_3.Terrain
	local v46 = v_u_40(v45, p43, 0.45)
	v46.Speed = NumberRange.new(p44 * 0.6, p44)
	v46.SpreadAngle = Vector2.new(180, 180)
	v46.Drag = 4
	v46:Emit(p42)
	v_u_1:AddItem(v45, 0.7)
end
return function(p_u_48)
	-- upvalues: (copy) v_u_31, (copy) v_u_1, (copy) v_u_35, (copy) v_u_4, (copy) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_9, (copy) v_u_15, (copy) v_u_6, (copy) v_u_40, (copy) v_u_3, (copy) v_u_47, (copy) v_u_16, (copy) v_u_17, (copy) v_u_12, (copy) v_u_14, (copy) v_u_11, (copy) v_u_13, (copy) v_u_5
	local function v_u_65(p_u_49, p_u_50, p_u_51, p52, p53, p_u_54, p_u_55, p56) -- name: flare
		-- upvalues: (ref) v_u_31, (ref) v_u_1, (copy) p_u_48, (ref) v_u_35
		local v_u_57 = p56 or 0
		local v_u_58 = v_u_31(p_u_49, p_u_50, p52, p53, v_u_57, true)
		v_u_1:AddItem(v_u_58, p_u_54 + 0.1)
		p_u_48.animate(p_u_54, 0, function(p59)
			-- upvalues: (copy) v_u_58, (copy) p_u_50, (copy) p_u_51, (copy) p_u_49, (copy) p_u_54, (copy) p_u_55, (ref) v_u_35, (copy) v_u_57
			local v60 = 1 - (1 - p59) ^ 3
			local v61 = v_u_58
			local v62 = p_u_50 + (p_u_51 - p_u_50) * v60
			local v63 = v62 * 2
			local v64 = v62 * 2
			v61.Size = Vector3.new(v63, 0.05, v64)
			v_u_58.CFrame = p_u_49 * CFrame.Angles(0, p59 * p_u_54 * p_u_55, 0)
			v_u_35(v_u_58, v_u_57 + (1 - v_u_57) * p59 ^ 1.5)
			if p59 >= 1 then
				v_u_58:Destroy()
			end
		end)
	end
	local function v_u_78(p66, p67, p68, p69) -- name: blade
		-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_1, (ref) v_u_7, (copy) p_u_48, (ref) v_u_8, (ref) v_u_9
		local v70 = v_u_4.part
		local v71 = p67 * 0.4
		local v72 = v70(Vector3.new(0.3, v71, p67), p66, v_u_10, {
			["shape"] = Enum.PartType.Wedge,
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_1:AddItem(v72, p69)
		local v73 = { v72 }
		if not p68 then
			local v74 = v_u_4.part
			local v75 = p67 * 0.52
			local v76 = p67 * 1.12
			local v77 = v74(Vector3.new(0.5, v75, v76), p66, v_u_7, {
				["shape"] = nil,
				["transparency"] = 0.45,
				["shape"] = Enum.PartType.Wedge
			})
			v_u_1:AddItem(v77, p69)
			table.insert(v73, v77)
			p_u_48.streak(v72, v_u_8, v_u_9, p67 * 0.35, 0.22)
		end
		return v73
	end
	local function v101(p79, p80) -- name: commaShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (ref) v_u_31, (ref) v_u_6, (copy) p_u_48, (ref) v_u_9, (ref) v_u_40, (ref) v_u_1, (ref) v_u_3
		local v_u_81 = p79.size
		local v_u_82 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p80, v_u_7, {
			["transparency"] = 1
		})
		local v83 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_15
		}
		local v_u_84 = v_u_4.part(Vector3.new(1.45, 1.45, 1.45) * v_u_81, p80, v_u_7, v83)
		local v85 = {
			["shape"] = v_u_15
		}
		local v_u_86 = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * v_u_81, p80, v_u_8, v85)
		local v_u_87 = v_u_31(p80, 1.15 * v_u_81, v_u_6.EmberComma, v_u_7, 0, true)
		local v_u_88 = { v_u_84, v_u_86, v_u_87 }
		p_u_48.streak(v_u_82, v_u_8, v_u_9, 1.1 * v_u_81, 0.16)
		local v_u_89
		if p79.lite then
			v_u_89 = nil
		else
			v_u_89 = v_u_40(v_u_82, 0.9 * v_u_81, 0.35)
			v_u_89.Rate = 28
			v_u_89.Enabled = true
		end
		if p79.mine then
			p_u_48.light(v_u_82, v_u_7, 9 * v_u_81)
		end
		for _, v90 in v_u_88 do
			v_u_1:AddItem(v90, 3)
		end
		v_u_1:AddItem(v_u_82, 3)
		local v_u_91 = false
		return {
			["place"] = function(p92, p93) -- name: place
				-- upvalues: (copy) v_u_82, (copy) v_u_84, (copy) v_u_86, (ref) v_u_3, (copy) v_u_87, (ref) p_u_48, (copy) v_u_81
				local v94 = p92.Position
				v_u_82.CFrame = p92
				v_u_84.CFrame = p92
				v_u_86.CFrame = p92
				local v95 = v_u_3.CurrentCamera
				local v96
				if v95 then
					local v97 = v95.CFrame.Position - v94
					v96 = v97.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v97.Unit
				else
					v96 = Vector3.new(0, 0, 1)
				end
				v_u_87.CFrame = p_u_48.facing(v94 + v96 * 0.8 * v_u_81, v96) * CFrame.Angles(0, -p93 * 20, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_91, (ref) v_u_89, (copy) v_u_82, (ref) v_u_1, (copy) v_u_88
				if not v_u_91 then
					v_u_91 = true
					local v98 = v_u_89
					if v98 then
						v98.Enabled = false
					end
					local v99 = v_u_82:FindFirstChildWhichIsA("PointLight")
					if v99 then
						v99:Destroy()
					end
					v_u_1:AddItem(v_u_82, 0.4)
					for _, v100 in v_u_88 do
						v100:Destroy()
					end
				end
			end
		}
	end
	local function v108(p102, p103) -- name: commaImpact
		-- upvalues: (ref) v_u_47, (copy) p_u_48, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3, (copy) v_u_65
		local v104 = p102.size
		v_u_47(p103, p102.lite and 2 or 5, 1.4 * v104, 9 * v104)
		p_u_48.pop(p103, v_u_7, 1.2 * v104, 4.2 * v104, 0.18, 0.3)
		p_u_48.pop(p103, v_u_8, 0.8 * v104, 2.2 * v104, 0.1)
		v_u_4.ring(p_u_48.ground(p103), v_u_7, p102.ability.radius * v104, 0.25, v_u_6.Ring)
		p_u_48.burst("Impact", p103, v_u_7, 0.9 * v104)
		if not p102.lite then
			local v105 = v_u_3.CurrentCamera
			local v106
			if v105 then
				local v107 = v105.CFrame.Position - p103
				v106 = v107.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v107.Unit
			else
				v106 = Vector3.new(0, 0, 1)
			end
			v_u_65(p_u_48.facing(p103 + v106 * 0.7, v106), 1.15 * v104, 3 * v104, v_u_6.EmberComma, v_u_7, 0.22, -12)
		end
		p_u_48.hitSound(p103)
	end
	local function v138(p109, p110) -- name: pinwheelShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_16, (ref) v_u_8, (ref) v_u_31, (ref) v_u_6, (copy) p_u_48, (ref) v_u_9, (ref) v_u_40, (ref) v_u_1, (ref) v_u_3, (ref) v_u_17
		local v111 = p109.size
		local v_u_112 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p110, v_u_7, {
			["transparency"] = 1
		})
		local v113 = v_u_4.part
		local v114 = 2.8 * v111
		local v115 = 2.8 * v111
		local v_u_116 = v113(Vector3.new(0.14, v114, v115), p110, v_u_7, {
			["shape"] = nil,
			["transparency"] = 0.12,
			["shape"] = v_u_16
		})
		local v117 = v_u_4.part
		local v118 = 1.3 * v111
		local v119 = 1.3 * v111
		local v_u_120 = v117(Vector3.new(0.18, v118, v119), p110, v_u_8, {
			["shape"] = v_u_16
		})
		local v_u_121 = v_u_31(p110, 2.1 * v111, v_u_6.EmberTrinity, v_u_7, 0, false)
		local v_u_122 = { v_u_116, v_u_120, v_u_121 }
		p_u_48.streak(v_u_112, v_u_8, v_u_9, 1.8 * v111, 0.18)
		local v_u_123
		if p109.lite then
			v_u_123 = nil
		else
			v_u_123 = v_u_40(v_u_112, 1 * v111, 0.35)
			v_u_123.Rate = 18
			v_u_123.Enabled = true
		end
		if p109.mine then
			p_u_48.light(v_u_112, v_u_7, 9 * v111)
		end
		for _, v124 in v_u_122 do
			v_u_1:AddItem(v124, 3)
		end
		v_u_1:AddItem(v_u_112, 3)
		local v_u_125 = false
		return {
			["place"] = function(p126, p127) -- name: place
				-- upvalues: (copy) v_u_112, (ref) p_u_48, (ref) v_u_3, (copy) v_u_116, (ref) v_u_17, (copy) v_u_120, (copy) v_u_121
				local v128 = p126.Position
				v_u_112.CFrame = p126
				local v129 = p_u_48.flatUnit
				local v130 = v_u_3.CurrentCamera
				local v131
				if v130 then
					local v132 = v130.CFrame.Position - v128
					v131 = v132.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v132.Unit
				else
					v131 = Vector3.new(0, 0, 1)
				end
				local v133 = v129(v131) * 0.5
				local v134 = p_u_48.facing(v128, (Vector3.new(0, 1, 0) + v133).Unit) * CFrame.Angles(0, -p127 * 26, 0)
				v_u_116.CFrame = v134 * v_u_17
				v_u_120.CFrame = v134 * CFrame.new(0, 0.03, 0) * v_u_17
				v_u_121.CFrame = v134 * CFrame.new(0, 0.12, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_125, (ref) v_u_123, (copy) v_u_112, (ref) v_u_1, (copy) v_u_122
				if not v_u_125 then
					v_u_125 = true
					local v135 = v_u_123
					if v135 then
						v135.Enabled = false
					end
					local v136 = v_u_112:FindFirstChildWhichIsA("PointLight")
					if v136 then
						v136:Destroy()
					end
					v_u_1:AddItem(v_u_112, 0.4)
					for _, v137 in v_u_122 do
						v137:Destroy()
					end
				end
			end
		}
	end
	local function v164(p139, p_u_140) -- name: pinwheelImpact
		-- upvalues: (copy) v_u_78, (copy) p_u_48, (ref) v_u_7, (ref) v_u_47, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6
		local v_u_141 = p139.size
		local v_u_142 = p139.lite
		local v_u_143 = math.random() * 3.141592653589793 * 2
		local v_u_144 = 4.6 * v_u_141
		for v_u_145 = 0, 2 do
			local v_u_146 = v_u_78(CFrame.new(p_u_140), 2.4 * v_u_141, v_u_142, 0.7)
			p_u_48.animate(0.42, 0, function(p147)
				-- upvalues: (copy) v_u_143, (copy) v_u_145, (copy) v_u_141, (copy) v_u_144, (copy) p_u_140, (copy) v_u_146, (ref) p_u_48, (ref) v_u_7, (copy) v_u_142, (ref) v_u_47
				local v148 = 1 - (1 - p147) ^ 2
				local v149 = v_u_143 + v_u_145 * 3.141592653589793 * 2 / 3 + p147 * 8
				local v150 = 0.6 * v_u_141 + v_u_144 * v148
				local v151 = p_u_140
				local v152 = math.cos(v149) * v150
				local v153 = -0.5 * p147
				local v154 = math.sin(v149) * v150
				local v155 = v151 + Vector3.new(v152, v153, v154)
				local v156 = -math.sin(v149)
				local v157 = math.cos(v149)
				local v158 = Vector3.new(v156, 0, v157)
				local v159 = CFrame.lookAt(v155, v155 - v158) * CFrame.Angles(0, 0, 1.5707963267948966)
				for _, v160 in v_u_146 do
					v160.CFrame = v159
					if p147 <= 0.7 then
						continue
					end
					local v161 = v160.Transparency
					local v162 = (p147 - 0.7) / 0.3
					v160.Transparency = math.max(v161, v162)
				end
				if p147 >= 1 then
					for _, v163 in v_u_146 do
						v163:Destroy()
					end
					p_u_48.pop(v155, v_u_7, 0.8 * v_u_141, 2.8 * v_u_141, 0.16, 0.3)
					if not v_u_142 then
						v_u_47(v155, 2, 1.1 * v_u_141, 5 * v_u_141)
					end
				end
			end)
		end
		p_u_48.pop(p_u_140, v_u_7, 1.2 * v_u_141, 5 * v_u_141, 0.22, 0.35)
		p_u_48.pop(p_u_140, v_u_8, 0.8 * v_u_141, 2.4 * v_u_141, 0.12)
		v_u_4.ring(p_u_48.ground(p_u_140), v_u_7, v_u_144 * 1.1, 0.35, v_u_6.Ring)
		p_u_48.burst("Impact", p_u_140, v_u_7, 1 * v_u_141)
		if not v_u_142 then
			v_u_47(p_u_140, 3, 1.5 * v_u_141, 7 * v_u_141)
		end
		p_u_48.hitSound(p_u_140)
	end
	local v_u_165 = {}
	setmetatable(v_u_165, {
		["__mode"] = "k"
	})
	local function v_u_208(p166, p167, p168) -- name: freeze
		-- upvalues: (copy) p_u_48, (ref) v_u_4, (ref) v_u_17, (ref) v_u_12, (ref) v_u_16, (ref) v_u_1, (ref) v_u_7, (ref) v_u_31, (ref) v_u_6, (ref) v_u_8, (ref) v_u_14
		local v_u_169 = p166.size
		local v_u_170 = p166.ability.radius * v_u_169
		local v_u_171 = p_u_48.ground(p167, 0)
		local v172 = math.max(p168, 0.12)
		local v173 = v172 + 3
		local v_u_174 = v_u_4.part(Vector3.new(0.35, 2, 2), CFrame.new(v_u_171 + Vector3.new(0, 0.22, 0)) * v_u_17, v_u_12, {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.35,
			["shape"] = v_u_16,
			["material"] = Enum.Material.Glass
		})
		v_u_1:AddItem(v_u_174, v173)
		local v175 = {
			["shape"] = nil,
			["transparency"] = 0.6,
			["shape"] = v_u_16
		}
		local v_u_176 = v_u_4.part(Vector3.new(0.1, 2, 2), CFrame.new(v_u_171 + Vector3.new(0, 0.1, 0)) * v_u_17, v_u_7, v175)
		v_u_1:AddItem(v_u_176, v173)
		local v_u_177 = v_u_31(CFrame.new(v_u_171 + Vector3.new(0, 0.16, 0)), 1, v_u_6.EmberSun, v_u_8, 0.3)
		v_u_1:AddItem(v_u_177, v173)
		local v178 = p166.lite and 4 or 7
		local v179 = math.random() * 3.141592653589793 * 2
		local v_u_180 = {}
		local v_u_181 = {}
		local v_u_182 = {}
		for v183 = 1, v178 do
			local v184 = v179 + (v183 - 1) / v178 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.4
			local v185 = v_u_4.part
			local v186 = 0.35 * v_u_169
			local v187 = v185(Vector3.new(v186, 0.12, 0.1), CFrame.new(v_u_171), v_u_8)
			table.insert(v_u_182, v184)
			local v188 = v_u_170 * (0.55 + math.random() * 0.35)
			table.insert(v_u_180, v188)
			v_u_1:AddItem(v187, v173)
			table.insert(v_u_181, v187)
		end
		local v_u_189 = {
			["sheet"] = nil,
			["glow"] = nil,
			["glare"] = nil,
			["cracks"] = nil,
			["born"] = nil,
			["taken"] = false,
			["sheet"] = v_u_174,
			["glow"] = v_u_176,
			["glare"] = v_u_177,
			["cracks"] = v_u_181,
			["born"] = os.clock()
		}
		p_u_48.animate(v172, 0, function(p190)
			-- upvalues: (copy) v_u_189, (copy) v_u_170, (copy) v_u_174, (copy) v_u_176, (copy) v_u_177, (copy) v_u_181, (copy) v_u_182, (copy) v_u_180, (copy) v_u_171, (copy) v_u_169
			if not v_u_189.taken then
				local v191 = 1 - (1 - p190) ^ 2
				local v192 = 6 + (v_u_170 * 1.8 - 6) * v191
				v_u_174.Size = Vector3.new(0.35, v192, v192)
				local v193 = 3 + v_u_170 * 0.9 * p190 * p190
				v_u_176.Size = Vector3.new(0.1, v193, v193)
				v_u_176.Transparency = 0.6 - 0.45 * p190
				local v194 = v_u_177
				local v195 = 1.5 + v_u_170 * 0.55 * p190 * p190
				local v196 = v195 * 2
				local v197 = v195 * 2
				v194.Size = Vector3.new(v196, 0.05, v197)
				for v198, v199 in v_u_181 do
					local v200 = v_u_182[v198]
					local v201 = v_u_180[v198] * p190 * p190
					local v202 = math.max(v201, 0.1)
					local v203 = math.cos(v200)
					local v204 = math.sin(v200)
					local v205 = Vector3.new(v203, 0, v204)
					local v206 = v_u_171 + Vector3.new(0, 0.42, 0) + v205 * v202 / 2
					local v207 = 0.35 * v_u_169
					v199.Size = Vector3.new(v207, 0.12, v202)
					v199.CFrame = CFrame.lookAt(v206, v206 + v205)
				end
			end
		end)
		v_u_4.ring(v_u_171, v_u_14, v_u_170, v172 + 0.1, v_u_6.Ring)
		return v_u_189
	end
	local function v_u_225(p209, p210, p211, p_u_212) -- name: shatter
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (copy) p_u_48, (ref) v_u_35, (ref) v_u_1, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14
		p210.taken = true
		v_u_4.tween(p210.sheet, 0.15, {
			["Transparency"] = 1
		})
		v_u_4.tween(p210.glow, 0.25, {
			["Transparency"] = 1
		})
		for _, v213 in p210.cracks do
			v213.Color = v_u_11
			v_u_4.tween(v213, 0.3, {
				["Transparency"] = 1
			})
		end
		local v_u_214 = p210.glare
		p_u_48.animate(0.3, 0, function(p215)
			-- upvalues: (copy) v_u_214, (copy) p_u_212, (ref) v_u_35
			local v216 = v_u_214
			local v217 = (p_u_212 * 0.55 + 1.5) * (1 + p215)
			local v218 = v217 * 2
			local v219 = v217 * 2
			v216.Size = Vector3.new(v218, 0.05, v219)
			v_u_35(v_u_214, 0.3 + 0.7 * p215)
		end)
		v_u_1:AddItem(p210.sheet, 0.2)
		v_u_1:AddItem(p210.glow, 0.3)
		v_u_1:AddItem(v_u_214, 0.35)
		p_u_48.chunks(p_u_48.ground(p211, 0.8), { v_u_12, v_u_13, v_u_14 }, p209.lite and 8 or 18, 50, 1.3, 1.3)
		if not p209.lite then
			for _ = 1, 3 do
				local v220 = math.random() * 3.141592653589793 * 2
				local v221 = p_u_212 * (0.3 + math.random() * 0.5)
				local v222 = p_u_48.burst
				local v223 = math.cos(v220) * v221
				local v224 = math.sin(v220) * v221
				v222("Smoke", p211 + Vector3.new(v223, 1, v224), nil, 2.2)
			end
		end
	end
	local function v_u_241(p226, p227) -- name: newSun
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_15, (ref) v_u_7, (ref) v_u_31, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1
		local v228 = {
			["shape"] = v_u_15
		}
		local v229 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.identity, v_u_8, v228)
		local v230 = {
			["shape"] = nil,
			["transparency"] = 0.35,
			["shape"] = v_u_15
		}
		local v231 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.identity, v_u_7, v230)
		local v232 = v_u_31(CFrame.identity, 1, v_u_6.EmberSun, v_u_8, 0.15, true)
		local v233 = v_u_31(CFrame.identity, 1, v_u_6.EmberTrinity, v_u_7, 1, true)
		local v234 = v_u_31(CFrame.identity, 1, v_u_6.Ring, v_u_9, 0, true)
		local v235 = v_u_31(CFrame.identity, 1, v_u_6.Ring, v_u_7, 0.1, true)
		local v236 = {}
		if not p226 then
			for _ = 1, 3 do
				local v237 = v_u_31(CFrame.identity, 1, v_u_6.EmberComma, v_u_7, 0, true)
				table.insert(v236, v237)
			end
		end
		local v238 = {
			["core"] = v229,
			["shell"] = v231,
			["corona"] = v232,
			["mark"] = v233,
			["pupil"] = v234,
			["ring"] = v235,
			["commas"] = v236
		}
		for _, v239 in {
			v229,
			v231,
			v232,
			v233,
			v234,
			v235
		} do
			v_u_1:AddItem(v239, p227)
		end
		for _, v240 in v236 do
			v_u_1:AddItem(v240, p227)
		end
		return v238
	end
	local function v_u_245(p242) -- name: dropSun
		for _, v243 in {
			p242.core,
			p242.shell,
			p242.corona,
			p242.mark,
			p242.pupil,
			p242.ring
		} do
			v243:Destroy()
		end
		for _, v244 in p242.commas do
			v244:Destroy()
		end
	end
	local function v_u_272(p246, p_u_247, p248, p249) -- name: sunBurst
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (copy) p_u_48, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_78, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
		local v250 = p246.lite
		v_u_4.flash(p_u_247, v_u_11, p249 * 1.3, 0.22)
		p_u_48.pop(p_u_247, v_u_8, 4, p249 * 1.2, 0.35, 0.2)
		p_u_48.pop(p248, v_u_7, p249 * 0.5, p249 * 2.1, 0.55, 0.45)
		p_u_48.burst("Explosion", p_u_247, v_u_7, 2.5)
		p_u_48.burst("Flash", p_u_247, v_u_8, 0.8, true)
		v_u_4.ring(p248, v_u_8, p249 * 1.2, 0.45, v_u_6.Shockwave)
		v_u_4.ring(p248, v_u_7, p249 * 1.5, 0.6, v_u_6.Ring)
		p_u_48.burst("Shockwave", p248 + Vector3.new(0, 0.3, 0), v_u_7, p249 / 14)
		p_u_48.spikes(p_u_247, v_u_8, v250 and 6 or 14, p249 * 1.1, 0.3)
		local v251 = math.random() * 3.141592653589793 * 2
		for v252 = 0, 2 do
			local v253 = v251 + v252 * 3.141592653589793 * 2 / 3
			local v254 = math.cos(v253)
			local v255 = math.sin(v253)
			local v_u_256 = p248 + Vector3.new(v254, 0, v255) * p249 * 0.8 + Vector3.new(0, 0.5, 0)
			local v_u_257 = v_u_78(CFrame.new(p_u_247), 7, v250, 1)
			p_u_48.animate(0.4, 0, function(p258)
				-- upvalues: (copy) p_u_247, (copy) v_u_256, (copy) v_u_257, (ref) p_u_48, (ref) v_u_7, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
				local v259 = p_u_247:Lerp(v_u_256, p258)
				local v260 = p258 * 3.141592653589793
				local v261 = v259 + Vector3.new(0, 1, 0) * math.sin(v260) * 4
				local v262 = (v_u_256 - p_u_247).Unit
				local v263 = CFrame.lookAt(v261, v261 + v262) * CFrame.Angles(0, 0, p258 * 14)
				for _, v264 in v_u_257 do
					v264.CFrame = v263
				end
				if p258 >= 1 then
					for _, v265 in v_u_257 do
						v265:Destroy()
					end
					p_u_48.burst("Explosion", v_u_256, v_u_7, 1.2)
					p_u_48.pop(v_u_256, v_u_7, 2, 9, 0.3, 0.35)
					v_u_4.ring(p_u_48.ground(v_u_256), v_u_9, 7, 0.35, v_u_6.Shockwave)
					p_u_48.mark(v_u_256, v_u_9, 5, 1.6, v_u_6.Glow, 0.3)
				end
			end)
		end
		p_u_48.chunks(p_u_247, { v_u_10, v_u_7, v_u_8 }, v250 and 5 or 12, 40, 0.8, 1.2, true, 0.6)
		if not v250 then
			for v266 = 1, 4 do
				local v267 = v251 + v266 * 3.141592653589793 / 2 + 0.6
				local v268 = math.cos(v267)
				local v269 = math.sin(v267)
				local v270 = p248 + Vector3.new(v268, 0, v269) * p249 * 0.45
				local v271 = p_u_48.loopAt("Fire", v270, v_u_7, 1.6)
				p_u_48.after(1.1, v271)
			end
			p_u_48.burst("Smoke", p248 + Vector3.new(0, 2, 0), nil, 2.5)
			p_u_48.burst("Smoke", p248 + Vector3.new(0, 2, 0), nil, 2.5)
		end
		v_u_5.play("Explosion", {
			["at"] = p_u_247,
			["volume"] = p246.mine and 1 or 0.6
		})
		if p246.mine then
			v_u_4.shake(0.6, 0.5)
		end
	end
	local function v_u_329(p_u_273, p_u_274, p_u_275) -- name: sunRise
		-- upvalues: (copy) v_u_241, (copy) p_u_48, (copy) v_u_245, (copy) v_u_272, (ref) v_u_3, (ref) v_u_8, (ref) v_u_11, (ref) v_u_35, (ref) v_u_40, (ref) v_u_1
		local v_u_276 = p_u_273.size
		local v277 = p_u_273.lite
		local v_u_278 = v_u_241(v277, 1.75)
		local v_u_279 = os.clock()
		local v_u_280 = v_u_279
		local v_u_281 = 0
		local v_u_282 = 0
		local v_u_283 = false
		p_u_48.runNow(function()
			-- upvalues: (ref) v_u_280, (copy) v_u_279, (ref) v_u_283, (copy) v_u_278, (ref) v_u_245, (ref) v_u_272, (copy) p_u_273, (copy) p_u_274, (copy) p_u_275, (copy) v_u_276, (ref) v_u_3, (ref) p_u_48, (ref) v_u_8, (ref) v_u_11, (ref) v_u_281, (ref) v_u_35, (ref) v_u_282
			local v284 = os.clock()
			local v285 = v284 - v_u_280
			local v286 = math.min(v285, 0.05)
			v_u_280 = v284
			local v287 = v284 - v_u_279
			if v287 >= 0.75 then
				if not v_u_283 then
					v_u_283 = true
					local v288 = v_u_278.core.Position
					v_u_245(v_u_278)
					v_u_272(p_u_273, v288, p_u_274, p_u_275)
				end
				return false
			end
			local v289 = v287 / 0.45
			local v290 = math.clamp(v289, 0, 1) - 1
			local v291 = v290 * 2.7 * v290 * v290 + 1 + v290 * 1.7 * v290
			local v292 = v287 - 0.5700000000000001
			local v293 = math.max(v292, 0) / 0.18
			local v294 = (v291 * 6.5 + 2) * v_u_276 * (v293 * 0.28 * v293 + 1)
			local v295 = p_u_274 + Vector3.new(0, 1, 0) * (v291 * 15 + -2) * v_u_276
			local v296 = v_u_3.CurrentCamera
			local v297
			if v296 then
				local v298 = v296.CFrame.Position - v295
				v297 = v298.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v298.Unit
			else
				v297 = Vector3.new(0, 0, 1)
			end
			local v299 = p_u_48.facing(v295 + v297 * v294 * 1.02, v297)
			v_u_278.core.Size = Vector3.new(1, 1, 1) * v294 * 1.7
			v_u_278.core.CFrame = CFrame.new(v295)
			v_u_278.core.Color = v_u_8:Lerp(v_u_11, v293)
			v_u_278.shell.Size = Vector3.new(1, 1, 1) * v294 * 2.1
			v_u_278.shell.CFrame = CFrame.new(v295)
			local v300 = v_u_278.corona
			local v301 = v294 * 2.3
			local v302 = v301 * 2
			local v303 = v301 * 2
			v300.Size = Vector3.new(v302, 0.05, v303)
			v_u_278.corona.CFrame = p_u_48.facing(v295 - v297 * v294 * 0.2, v297) * CFrame.Angles(0, v287 * 0.8, 0)
			local v304 = (v287 - 0.15) / 0.25
			local v305 = math.clamp(v304, 0, 1)
			local v306 = v_u_281
			local v307 = (v287 - 0.2) / 0.5
			v_u_281 = v306 + v286 * (math.clamp(v307, 0, 1) ^ 2 * 16 + 1.5)
			local v308 = v_u_278.mark
			local v309 = v294 * 0.98
			local v310 = v309 * 2
			local v311 = v309 * 2
			v308.Size = Vector3.new(v310, 0.05, v311)
			v_u_278.mark.CFrame = v299 * CFrame.Angles(0, -v_u_281, 0)
			v_u_35(v_u_278.mark, 1 - v305)
			local v312 = v_u_278.pupil
			local v313 = v294 * 0.3
			local v314 = v313 * 2
			local v315 = v313 * 2
			v312.Size = Vector3.new(v314, 0.05, v315)
			v_u_278.pupil.CFrame = v299 * CFrame.new(0, 0.06, 0)
			v_u_35(v_u_278.pupil, 1 - v305)
			v_u_282 = v_u_282 + v286 * 2.4
			local v316 = v_u_278.ring
			local v317 = v294 * 1.3
			local v318 = v317 * 2
			local v319 = v317 * 2
			v316.Size = Vector3.new(v318, 0.05, v319)
			v_u_278.ring.CFrame = v299 * CFrame.new(0, -0.04, 0) * CFrame.Angles(0, v_u_282 * 0.3, 0)
			v_u_35(v_u_278.ring, (1 - v305) * 0.9 + 0.1)
			for v320, v321 in v_u_278.commas do
				local v322 = v_u_282 + (v320 - 1) * 3.141592653589793 * 2 / 3
				local v323 = v294 * 1.3
				local v324 = v294 * 0.24
				local v325 = v324 * 2
				local v326 = v324 * 2
				v321.Size = Vector3.new(v325, 0.05, v326)
				v321.CFrame = v299 * CFrame.new(math.cos(v322) * v323, 0.08, math.sin(v322) * v323) * CFrame.Angles(0, -v322 + 3.141592653589793, 0)
				v_u_35(v321, 1 - v305)
			end
			return true
		end)
		if not v277 then
			local v327 = Instance.new("Attachment")
			v327.WorldPosition = p_u_274 + Vector3.new(0, 2, 0)
			v327.Parent = v_u_3.Terrain
			local v328 = v_u_40(v327, 2.2 * v_u_276, 0.6)
			v328.Speed = NumberRange.new(10, 18)
			v328.SpreadAngle = Vector2.new(35, 35)
			v328.EmissionDirection = Enum.NormalId.Top
			v328:Emit(8)
			v_u_1:AddItem(v327, 1)
		end
	end
	local v358 = {
		["ember_trinity_a"] = {
			["cast"] = function(p330) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_48, (ref) v_u_8, (copy) v_u_65, (ref) v_u_6
				local v331 = p330.size
				local v332 = p330.eye + p330.dir * 1.2
				v_u_4.flash(v332, v_u_7, 3.2 * v331, 0.1)
				p_u_48.pop(v332, v_u_8, 1.3 * v331, 0.3 * v331, 0.1)
				if not p330.lite then
					v_u_65(p_u_48.facing(v332, -p330.dir), 0.6 * v331, 1.6 * v331, v_u_6.EmberComma, v_u_7, 0.12, 25)
				end
			end,
			["shot"] = v101,
			["impact"] = v108,
			["hit"] = function(_, p333, _) -- name: hit
				-- upvalues: (copy) p_u_48, (ref) v_u_7
				p_u_48.burst("Impact", p333, v_u_7, 0.6)
			end
		},
		["ember_trinity_e"] = {
			["cast"] = function(p334) -- name: cast
				-- upvalues: (copy) p_u_48, (ref) v_u_7, (ref) v_u_3, (copy) v_u_65, (ref) v_u_6, (ref) v_u_8, (ref) v_u_47
				p_u_48.skillCast(p334, v_u_7)
				local v335 = p334.size
				local v336 = p334.eye + Vector3.new(0, 1.2, 0) - p334.dir * 0.6
				local v337 = v_u_3.CurrentCamera
				local v338
				if v337 then
					local v339 = v337.CFrame.Position - v336
					v338 = v339.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v339.Unit
				else
					v338 = Vector3.new(0, 0, 1)
				end
				local v340 = p_u_48.facing(v336, v338)
				v_u_65(v340, 1.2 * v335, 3.4 * v335, v_u_6.EmberSun, v_u_8, 0.35, 0, 0.2)
				v_u_65(v340 * CFrame.new(0, 0.05, 0), 1 * v335, 2.8 * v335, v_u_6.EmberTrinity, v_u_7, 0.4, -18)
				if not p334.lite then
					v_u_47(v336, 4, 1.4 * v335, 8 * v335)
					p_u_48.spikes(v336, v_u_8, 5, 5 * v335, 0.16, p334.dir, 0.6)
				end
			end,
			["shot"] = v138,
			["impact"] = v164,
			["hit"] = function(p341, p342, _) -- name: hit
				-- upvalues: (copy) p_u_48, (ref) v_u_7, (ref) v_u_8
				p_u_48.burst("Impact", p342, v_u_7, 0.7)
				if not p341.lite then
					p_u_48.glint(p342, v_u_8, 3, 0.14)
				end
			end
		},
		["ember_trinity_r"] = {
			["cast"] = function(p343) -- name: cast
				-- upvalues: (copy) p_u_48, (ref) v_u_7, (copy) v_u_65, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4
				p_u_48.skillCast(p343, v_u_7, true)
				local v344 = p343.size
				local v345 = p343.eye + p343.dir * 1.4
				local v346 = p_u_48.facing(v345, -p343.dir)
				v_u_65(v346, 1 * v344, 4 * v344, v_u_6.EmberTrinity, v_u_7, 0.32, 12)
				v_u_65(v346 * CFrame.new(0, -0.05, 0), 1.5 * v344, 5 * v344, v_u_6.EmberSun, v_u_8, 0.3, 0, 0.2)
				if p343.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p347, p348, p349) -- name: windup
				-- upvalues: (copy) v_u_165, (copy) v_u_208
				v_u_165[p347] = v_u_208(p347, p348, p349)
			end,
			["land"] = function(p350, p351) -- name: land
				-- upvalues: (copy) p_u_48, (copy) v_u_165, (copy) v_u_225, (ref) v_u_4, (ref) v_u_8, (ref) v_u_7, (ref) v_u_6, (copy) v_u_329, (ref) v_u_5
				local v352 = p350.size
				local v353 = p350.ability.radius * v352
				local v354 = p_u_48.ground(p351, 0)
				local v355 = v_u_165[p350]
				v_u_165[p350] = nil
				if v355 then
					v_u_225(p350, v355, v354, v353)
				end
				v_u_4.flash(v354 + Vector3.new(0, 3, 0), v_u_8, v353 * 0.8, 0.22)
				p_u_48.pop(v354 + Vector3.new(0, 2, 0), v_u_7, 4, v353 * 1.1, 0.3, 0.35)
				v_u_4.ring(v354, v_u_7, v353, 0.45, v_u_6.Shockwave)
				p_u_48.burst("Shockwave", v354 + Vector3.new(0, 0.3, 0), v_u_8, v353 / 16)
				p_u_48.spikes(v354 + Vector3.new(0, 2, 0), v_u_8, p350.lite and 5 or 10, v353 * 0.9, 0.28, Vector3.new(0, 1, 0), 0.8)
				v_u_329(p350, v354, v353)
				v_u_5.play("Fireball", {
					["at"] = v354,
					["volume"] = p350.mine and 1 or 0.6
				})
				if p350.mine then
					v_u_4.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(p356, p357, _) -- name: hit
				-- upvalues: (copy) p_u_48, (ref) v_u_7, (ref) v_u_8
				p_u_48.burst("Impact", p357, v_u_7, 1.1)
				if not p356.lite then
					p_u_48.glint(p357, v_u_8, 3.5, 0.15)
				end
			end
		}
	}
	return v358
end