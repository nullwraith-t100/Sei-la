local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local function v_u_10(p4, p5, p6, p7) -- name: triangle
	local v8 = p4 / 2
	local v9 = Vector3.new(p6, p5, v8)
	if p7 then
		return { v9 }, { CFrame.new(p4 / 4, p5 / 2, 0) * CFrame.Angles(0, -1.5707963267948966, 0) }
	else
		return { v9, v9 }, { CFrame.new(p4 / 4, p5 / 2, 0) * CFrame.Angles(0, -1.5707963267948966, 0), CFrame.new(-p4 / 4, p5 / 2, 0) * CFrame.Angles(0, 1.5707963267948966, 0) }
	end
end
return function(p_u_11)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_10
	return {
		["w3_thorn_halo"] = function(p_u_12, p13)
			-- upvalues: (ref) v_u_2, (copy) p_u_11, (ref) v_u_3, (ref) v_u_10
			local v_u_14 = p_u_12.character:GetScale()
			local v_u_15 = v_u_2.color(p13.color)
			local v16 = v_u_2.color(p13.color2)
			local v17 = p_u_11.rgb(255, 255, 255)
			local v18 = p_u_11.rgb(175, 125, 255)
			local v_u_19 = p_u_11.crownOf(p_u_12)
			local v_u_21 = p_u_11.throb(p_u_12, 3.6, 1.2, 1.8, function(p20)
				-- upvalues: (ref) v_u_2, (ref) p_u_11, (copy) p_u_12, (copy) v_u_15, (ref) v_u_3
				v_u_2.ring(p_u_11.feetAt(p_u_12, p20, 0.15), v_u_15, 5 * p_u_12.fx, 0.5, v_u_3.Ring)
			end)
			local v_u_30 = p_u_11.group(p_u_12, function(p22, p23)
				-- upvalues: (copy) v_u_19, (copy) p_u_12, (ref) p_u_11
				local v24 = v_u_19(p22).Position
				local v25 = p_u_12.eyeLift
				local v26 = v24 + Vector3.new(0, v25, 0)
				local v27 = p_u_11.camPos() - v26
				local v28
				if v27.Magnitude > 0.001 then
					v28 = v27.Unit
				else
					v28 = p22.LookVector
				end
				local v29 = v26 - v28 * 0.9
				return CFrame.lookAt(v29, v29 + v28) * CFrame.Angles(0, 0, p23 * 0.4)
			end)
			local v31 = p_u_11.disc(Vector3.new(0.05, 4.3, 4.3), v16, 0.2, Enum.Material.SmoothPlastic)
			p_u_11.pin(p_u_12, v_u_30, v31, CFrame.new(0, 0, 0.35) * CFrame.Angles(0, 1.5707963267948966, 0))
			p_u_11.fadeFromBehind(p_u_12, v31, 0.85)
			local v32 = p_u_11.picture(3.8, v_u_3.Ring, v_u_15, 0.1)
			p_u_11.pin(p_u_12, v_u_30, v32, CFrame.Angles(1.5707963267948966, 0, 0))
			for v33 = 0, 11 do
				local v_u_34 = v33 % 3 == 0
				local v35 = 1.5707963267948966 + v33 * 3.141592653589793 / 6
				local v36 = math.cos(v35)
				local v37 = math.sin(v35)
				local v_u_38 = Vector3.new(v36, v37, 0)
				local v_u_39 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v_u_38:Cross(Vector3.new(0, 0, 1)), v_u_38)
				local v40, v41 = v_u_10(v_u_34 and 0.8 or 0.55, v_u_34 and 1.7 or 0.85, v_u_34 and 0.18 or 0.16, not v_u_34)
				for v42, v43 in v40 do
					local v44 = v_u_2.part
					local v45 = CFrame.identity
					local v46
					if v_u_34 then
						v46 = v17
					else
						v46 = v_u_15
					end
					local v47 = v44(v43, v45, v46, {
						["shape"] = Enum.PartType.Wedge
					})
					local v_u_48 = v41[v42]
					p_u_11.fadeFromBehind(p_u_12, v47, 0.5)
					p_u_11.add(p_u_12, v47, function()
						-- upvalues: (copy) v_u_21, (copy) v_u_34, (copy) v_u_30, (copy) v_u_38, (copy) v_u_39, (copy) v_u_48
						local v49 = v_u_21() * (v_u_34 and 0.45 or 0.3)
						return v_u_30.cf * CFrame.new(v_u_38 * (1.75 + v49)) * v_u_39 * v_u_48
					end)
				end
			end
			local v_u_52 = p_u_11.group(p_u_12, function(p50, p51)
				-- upvalues: (copy) v_u_14
				return p50 * CFrame.new(0, -0.3 * v_u_14, 0) * CFrame.Angles(0.16, 0, -0.1) * CFrame.Angles(0, p51 * 0.55, 0)
			end)
			local v_u_53 = 2.5 * v_u_14
			for v_u_54 = 0, 5 do
				local v55 = v_u_54 * 3.141592653589793 / 3
				local v56 = math.cos(v55)
				local v57 = math.sin(v55)
				local v_u_58 = Vector3.new(v56, 0, v57)
				local v59 = (v_u_54 % 2 == 0 and 2.9 or 2) * v_u_14
				local function v64(_, p60) -- name: place
					-- upvalues: (copy) v_u_21, (copy) v_u_54, (copy) v_u_14, (copy) v_u_52, (copy) v_u_58, (copy) v_u_53
					local v61 = v_u_21() * 1.1
					local v62 = p60 * 2 + v_u_54
					local v63 = (v61 + math.sin(v62) * 0.1) * v_u_14
					return v_u_52.cf * CFrame.lookAt(v_u_58 * (v_u_53 + v63), v_u_58 * (v_u_53 + v63 + 1))
				end
				local v65 = p_u_11.add
				local v66 = p_u_11.blob
				local v67 = 0.36 * v_u_14
				local v68 = 0.36 * v_u_14
				v65(p_u_12, v66(Vector3.new(v67, v68, v59), v17, 0), v64)
				local v69 = p_u_11.add
				local v70 = p_u_11.blob
				local v71 = 0.6 * v_u_14
				local v72 = 0.6 * v_u_14
				local v73 = v59 * 1.15
				v69(p_u_12, v70(Vector3.new(v71, v72, v73), v18, 0.72), p_u_11.behind(v64, 0.2 * v_u_14))
			end
			p_u_11.particles(p_u_12, "AuraMode", v18, {
				["rate"] = 0.5,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
			p_u_11.particles(p_u_12, "Petals", v17, {
				["rate"] = 0.9,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end