local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF7FB8")
local v_u_8 = Color3.fromHex("FFE4F0")
local v_u_9 = Color3.fromRGB(240, 70, 150)
local v_u_10 = Color3.fromRGB(255, 244, 250)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Wedge
local function v_u_24(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part
	local v19 = p14 * 2
	local v20 = p14 * 2
	local v21 = v18(Vector3.new(v19, 0.05, v20), p13, p16, {
		["transparency"] = 1
	})
	for _, v22 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v23 = Instance.new("Decal")
		v23.Face = v22
		v23.Texture = p15
		v23.Color3 = p16
		v23.Transparency = p17
		v23.Parent = v21
	end
	return v21
end
local function v_u_28(p25, p26) -- name: setAlpha
	for _, v27 in p25:GetChildren() do
		if not v27:IsA("Decal") then
			continue
		end
		v27.Transparency = p26
	end
end
local function v_u_34(p29, p30, p31, p32) -- name: petalEmitter
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_8
	local v33 = Instance.new("ParticleEmitter")
	v33.Texture = v_u_6.SakuraPetal
	v33.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v33.FlipbookMode = Enum.ParticleFlipbookMode.Loop
	v33.FlipbookFramerate = NumberRange.new(12, 26)
	v33.FlipbookStartRandom = true
	v33.Color = ColorSequence.new(v_u_7, v_u_8)
	v33.LightEmission = 0.3
	v33.LightInfluence = 0
	v33.Lifetime = NumberRange.new(p32 * 0.7, p32)
	v33.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p30 * 0.4), NumberSequenceKeypoint.new(0.15, p30), NumberSequenceKeypoint.new(1, p30 * 0.7) })
	v33.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), NumberSequenceKeypoint.new(1, 1) })
	v33.Speed = NumberRange.new(p31 * 0.4, p31)
	v33.SpreadAngle = Vector2.new(180, 180)
	v33.Drag = 2.5
	v33.Acceleration = Vector3.new(0, -3, 0)
	v33.Rotation = NumberRange.new(0, 360)
	v33.RotSpeed = NumberRange.new(-160, 160)
	v33.Rate = 0
	v33.Parent = p29
	return v33
end
return function(p_u_35)
	-- upvalues: (copy) v_u_24, (copy) v_u_1, (copy) v_u_28, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10, (copy) v_u_6, (copy) v_u_7, (copy) v_u_34, (copy) v_u_11, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5, (copy) v_u_12
	local function v_u_52(p_u_36, p_u_37, p_u_38, p39, p40, p_u_41, p_u_42, p43) -- name: flare
		-- upvalues: (ref) v_u_24, (ref) v_u_1, (copy) p_u_35, (ref) v_u_28
		local v_u_44 = p43 or 0
		local v_u_45 = v_u_24(p_u_36, p_u_37, p39, p40, v_u_44)
		v_u_1:AddItem(v_u_45, p_u_41 + 0.1)
		p_u_35.animate(p_u_41, 0, function(p46)
			-- upvalues: (copy) v_u_45, (copy) p_u_37, (copy) p_u_38, (copy) p_u_36, (copy) p_u_41, (copy) p_u_42, (ref) v_u_28, (copy) v_u_44
			local v47 = 1 - (1 - p46) ^ 3
			local v48 = v_u_45
			local v49 = p_u_37 + (p_u_38 - p_u_37) * v47
			local v50 = v49 * 2
			local v51 = v49 * 2
			v48.Size = Vector3.new(v50, 0.05, v51)
			v_u_45.CFrame = p_u_36 * CFrame.Angles(0, p46 * p_u_41 * p_u_42, 0)
			v_u_28(v_u_45, v_u_44 + (1 - v_u_44) * p46 ^ 1.5)
			if p46 >= 1 then
				v_u_45:Destroy()
			end
		end)
	end
	local function v_u_65(p53, p54, p55, p56) -- name: cut
		-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_1
		local v57 = (p54 - p53).Magnitude
		local v58 = math.max(v57, 0.1)
		local v59 = v_u_4.part
		local v60 = p55 * 0.4
		local v61 = v59(Vector3.new(p55, v60, v58), CFrame.lookAt((p53 + p54) / 2, p54), v_u_10)
		local v62 = v_u_4.tween
		local v63 = {
			["Size"] = nil,
			["Transparency"] = 1
		}
		local v64 = v58 * 1.1
		v63.Size = Vector3.new(0.05, 0.05, v64)
		v62(v61, p56, v63)
		v_u_1:AddItem(v61, p56 + 0.05)
	end
	local function v_u_80(p66, p67) -- name: skillCast
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_52, (copy) p_u_35, (ref) v_u_4, (ref) v_u_34, (ref) v_u_1, (ref) v_u_11
		local v68 = p66.size
		local v69 = p66.eye + p66.dir * 1.2
		local v70 = 0.6 * v68
		local v71 = (p67 and 4.5 or 3.2) * v68
		local v72 = v_u_6.Glow
		local v73 = v_u_7
		local v74 = v_u_3.CurrentCamera
		local v75
		if v74 then
			local v76 = v74.CFrame.Position - v69
			v75 = v76.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v76.Unit
		else
			v75 = Vector3.new(0, 0, 1)
		end
		v_u_52(p_u_35.facing(v69 + v75 * 0.3, v75), v70, v71, v72, v73, 0.2, 0, 0.05)
		v_u_52(p_u_35.facing(v69, p66.dir), 0.5 * v68, (p67 and 3.4 or 2.4) * v68, v_u_6.SakuraBloom, v_u_7, 0.32, -6, 0.05)
		v_u_4.ring(p66.feet, v_u_7, (p67 and 9 or 6) * v68, 0.3, v_u_6.Ring)
		if not p66.lite then
			local v77 = 10 * v68
			local v78 = 0.4 * v68
			local v79 = Instance.new("Attachment")
			v79.Parent = v_u_3.Terrain
			v79.WorldPosition = v69
			v_u_34(v79, v78, v77, 1.1):Emit(p67 and 14 or 8)
			v_u_1:AddItem(v79, 1.3)
			p_u_35.glint(v69, v_u_11, (p67 and 3 or 2) * v68, 0.14)
		end
		if p66.mine then
			v_u_4.shake(p67 and 0.15 or 0.07, 0.14)
		end
	end
	local function v106(p81, p82) -- name: bladeShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (copy) p_u_35, (ref) v_u_9, (ref) v_u_34
		local v83 = p81.size
		local v84 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p82, v_u_7, {
			["transparency"] = 1
		})
		local v85 = v_u_4.part
		local v86 = 0.08 * v83
		local v87 = 0.32 * v83
		local v88 = 1.7 * v83
		local v89 = v85(Vector3.new(v86, v87, v88), p82, v_u_7)
		local v90 = v_u_4.part
		local v91 = 0.1 * v83
		local v92 = 0.12 * v83
		local v93 = 1.9 * v83
		local v94 = v90(Vector3.new(v91, v92, v93), p82, v_u_10)
		local v95 = {
			{
				["p"] = v89,
				["off"] = CFrame.identity
			},
			{
				["p"] = v94,
				["off"] = CFrame.new(0, 0.1 * v83, -0.1 * v83)
			}
		}
		local v96 = {}
		for _ = 1, p81.lite and 2 or 4 do
			local v97 = v_u_4.part
			local v98 = 0.05 * v83
			local v99 = 0.16 * v83
			local v100 = 0.9 * v83
			local v101 = Vector3.new(v98, v99, v100)
			local v102 = v_u_8
			table.insert(v96, v97(v101, p82, v102))
		end
		p_u_35.streak(v84, v_u_7, v_u_9, 0.7 * v83, 0.18)
		if p81.mine then
			p_u_35.light(v84, v_u_7, 9 * v83)
		end
		local v103 = {}
		if not p81.lite then
			local v104 = Instance.new("Attachment")
			v104.Parent = v84
			local v_u_105 = v_u_34(v104, 0.32 * v83, 2.5 * v83, 0.6)
			v_u_105.Rate = 55
			table.insert(v103, function()
				-- upvalues: (copy) v_u_105
				v_u_105.Enabled = false
			end)
		end
		return p_u_35.assemble(v84, v95, v96, 0.55 * v83, 22, v103, 0.18, 8)
	end
	local function v128(p107, p108) -- name: bladeHit
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_52, (copy) p_u_35, (ref) v_u_8, (ref) v_u_34, (ref) v_u_1
		local v109 = p107.size
		local v110 = 0.8 * v109
		local v111 = 4.4 * v109
		local v112 = v_u_6.SakuraBloom
		local v113 = v_u_7
		local v114 = v_u_3.CurrentCamera
		local v115
		if v114 then
			local v116 = v114.CFrame.Position - p108
			v115 = v116.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v116.Unit
		else
			v115 = Vector3.new(0, 0, 1)
		end
		v_u_52(p_u_35.facing(p108 + v115 * 0.3, v115), v110, v111, v112, v113, 0.32, 5, 0.05)
		local v117 = 0.6 * v109
		local v118 = 3 * v109
		local v119 = v_u_6.Glow
		local v120 = v_u_8
		local v121 = v_u_3.CurrentCamera
		local v122
		if v121 then
			local v123 = v121.CFrame.Position - p108
			v122 = v123.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v123.Unit
		else
			v122 = Vector3.new(0, 0, 1)
		end
		v_u_52(p_u_35.facing(p108 + v122 * 0.3, v122), v117, v118, v119, v120, 0.18, 0, 0.25)
		local v124 = p107.lite and 6 or 14
		local v125 = 18 * v109
		local v126 = 0.38 * v109
		local v127 = Instance.new("Attachment")
		v127.Parent = v_u_3.Terrain
		v127.WorldPosition = p108
		v_u_34(v127, v126, v125, 1.1):Emit(v124)
		v_u_1:AddItem(v127, 1.3)
		if not p107.lite then
			p_u_35.spikes(p108, v_u_8, 4, 4.5 * v109, 0.15)
		end
		p_u_35.burst("Impact", p108, v_u_7, 0.8 * v109)
		p_u_35.hitSound(p108)
	end
	local function v227(p_u_129, p130, p_u_131) -- name: sphereOfPetals
		-- upvalues: (copy) p_u_35, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_34, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_24, (ref) v_u_6, (ref) v_u_3, (copy) v_u_65, (copy) v_u_52, (ref) v_u_5
		local v_u_132 = p_u_129.size
		local v_u_133 = p_u_129.ability.radius * v_u_132
		local v_u_134 = p_u_129.lite
		local v_u_135 = p_u_129.ability.tick or 0.4
		local v_u_136 = p_u_35.ground(p130, 0)
		local v_u_137 = v_u_136 + Vector3.new(0, 3, 0) * v_u_132
		local v138 = p_u_131 + 2
		local v_u_139 = v_u_4.part(Vector3.new(1, 1, 1) * v_u_133 * 1.9, CFrame.new(v_u_137), v_u_7, {
			["transparency"] = 1
		})
		v_u_139.Shape = Enum.PartType.Ball
		v_u_1:AddItem(v_u_139, v138)
		local function v143(p140, p141) -- name: shell
			-- upvalues: (ref) v_u_34, (copy) v_u_139, (copy) v_u_132
			local v142 = v_u_34(v_u_139, 0.85 * v_u_132, 0.8 * v_u_132, 1.6)
			v142.Color = ColorSequence.new(p140)
			v142.Shape = Enum.ParticleEmitterShape.Sphere
			v142.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v142.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
			v142.Acceleration = Vector3.new(0, 0, 0)
			v142.Rate = p141
			return v142
		end
		local v_u_144 = { v143(v_u_7, v_u_134 and 14 or 28), v143(v_u_8, v_u_134 and 8 or 24), (v143(v_u_9, v_u_134 and 0 or 18)) }
		if not v_u_134 then
			local v145 = Instance.new("ParticleEmitter")
			v145.Texture = "rbxassetid://76741008972969"
			v145.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v145.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v145.Color = ColorSequence.new(v_u_11, v_u_8)
			v145.LightEmission = 0.8
			v145.LightInfluence = 0
			v145.Lifetime = NumberRange.new(0.3, 0.5)
			v145.Size = NumberSequence.new(0.8 * v_u_132, 0.1 * v_u_132)
			v145.Speed = NumberRange.new(0.2, 1)
			v145.Shape = Enum.ParticleEmitterShape.Sphere
			v145.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v145.Rate = 16
			v145.Parent = v_u_139
			table.insert(v_u_144, v145)
		end
		local v_u_146 = v_u_24(CFrame.new(v_u_137), 0.1, v_u_6.Ring, v_u_7, 0.3)
		local v_u_147 = v_u_24(CFrame.new(v_u_137), 0.1, v_u_6.Glow, v_u_7, 0.72)
		local v_u_148
		if v_u_134 then
			v_u_148 = nil
		else
			v_u_148 = v_u_24(CFrame.new(v_u_137), 0.1, v_u_6.SakuraBloom, v_u_7, 0.6)
		end
		local v_u_149 = { v_u_146, v_u_147 }
		if v_u_148 then
			table.insert(v_u_149, v_u_148)
		end
		for _, v150 in v_u_149 do
			v_u_1:AddItem(v150, v138)
		end
		local v_u_151 = true
		local v_u_152 = os.clock()
		local v_u_153 = 0.05
		local v_u_154 = v_u_133 * 0.95
		p_u_35.runNow(function()
			-- upvalues: (ref) v_u_151, (copy) v_u_139, (copy) v_u_152, (copy) v_u_135, (ref) v_u_154, (copy) v_u_133, (copy) p_u_131, (copy) v_u_137, (ref) v_u_3, (ref) p_u_35, (copy) v_u_146, (copy) v_u_147, (copy) v_u_148, (ref) v_u_153, (copy) v_u_134, (ref) v_u_65, (copy) v_u_136, (copy) v_u_132, (ref) v_u_34, (ref) v_u_1
			if not (v_u_151 and v_u_139.Parent) then
				return false
			end
			local v155 = os.clock() - v_u_152
			local v156 = v155 / 0.25
			local v157 = math.clamp(v156, 0, 1) - 1
			local v158 = v157 * 2.7 * v157 * v157 + 1 + v157 * 1.7 * v157
			local v159 = v155 / v_u_135
			local v160 = v_u_133
			local v161 = math.floor(v159) * v_u_135 / p_u_131
			v_u_154 = v160 * (0.95 - math.min(v161, 1) * 0.3) * v158
			local v162 = v_u_154 * 2
			local v163 = math.max(v162, 0.2)
			v_u_139.Size = Vector3.new(v163, v163, v163)
			local v164 = v_u_137
			local v165 = v_u_3.CurrentCamera
			local v166
			if v165 then
				local v167 = v165.CFrame.Position - v164
				v166 = v167.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v167.Unit
			else
				v166 = Vector3.new(0, 0, 1)
			end
			local v168 = p_u_35.facing(v_u_137, v166)
			v_u_146.CFrame = v168 * CFrame.new(0, 0.3, 0) * CFrame.Angles(0, v155 * 1.5, 0)
			local v169 = v_u_146
			local v170 = v_u_154 * 1.02
			local v171 = v170 * 2
			local v172 = v170 * 2
			v169.Size = Vector3.new(v171, 0.05, v172)
			v_u_147.CFrame = v168
			local v173 = v_u_147
			local v174 = v_u_154
			local v175 = v174 * 2
			local v176 = v174 * 2
			v173.Size = Vector3.new(v175, 0.05, v176)
			if v_u_148 then
				v_u_148.CFrame = v168 * CFrame.new(0, -0.2, 0) * CFrame.Angles(0, -v155 * 1.2, 0)
				local v177 = v_u_148
				local v178 = v_u_154 * 0.9
				local v179 = v178 * 2
				local v180 = v178 * 2
				v177.Size = Vector3.new(v179, 0.05, v180)
			end
			if v_u_153 <= v155 then
				v_u_153 = v_u_153 + v_u_135
				for _ = 1, v_u_134 and 1 or 3 do
					local v181 = math.random() - 0.5
					local v182 = math.random() * 0.8
					local v183 = math.random() - 0.5
					local v184 = Vector3.new(v181, v182, v183)
					local v185 = v184.X
					local v186 = -v184.Y
					local v187 = v184.Z
					local v188 = -Vector3.new(v185, v186, v187)
					local v189 = math.random() - 0.5
					local v190 = math.random() - 0.5
					local v191 = v188 + Vector3.new(v189, 0, v190) * 0.6
					local v192 = v_u_137 + (v184.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v184.Unit) * v_u_154 * 0.85
					local v193 = v_u_137 + (v191.Magnitude <= 0.001 and Vector3.new(-0, -1, -0) or v191.Unit) * v_u_154 * 0.85
					local v194 = v_u_65
					local v195 = v193.X
					local v196 = v193.Y
					local v197 = v_u_136.Y + 0.5
					local v198 = math.max(v196, v197)
					local v199 = v193.Z
					v194(v192, Vector3.new(v195, v198, v199), 0.35 * v_u_132, 0.2)
				end
				if not v_u_134 then
					local v200 = v_u_137
					local v201 = 8 * v_u_132
					local v202 = 0.4 * v_u_132
					local v203 = Instance.new("Attachment")
					v203.Parent = v_u_3.Terrain
					v203.WorldPosition = v200
					v_u_34(v203, v202, v201, 1.1):Emit(5)
					v_u_1:AddItem(v203, 1.3)
				end
			end
			return true
		end)
		return function()
			-- upvalues: (ref) v_u_151, (copy) v_u_144, (ref) v_u_1, (copy) v_u_139, (copy) v_u_149, (copy) v_u_137, (copy) v_u_134, (copy) v_u_132, (ref) v_u_3, (ref) v_u_34, (ref) v_u_154, (ref) v_u_6, (ref) v_u_7, (ref) v_u_52, (ref) p_u_35, (ref) v_u_8, (ref) v_u_4, (copy) v_u_136, (copy) v_u_133, (ref) v_u_5, (copy) p_u_129
			v_u_151 = false
			for _, v204 in v_u_144 do
				v204.Enabled = false
			end
			v_u_1:AddItem(v_u_139, 1.3)
			for _, v205 in v_u_149 do
				v205:Destroy()
			end
			local v206 = v_u_137
			local v207 = v_u_134 and 16 or 45
			local v208 = 30 * v_u_132
			local v209 = 0.6 * v_u_132
			local v210 = Instance.new("Attachment")
			v210.Parent = v_u_3.Terrain
			v210.WorldPosition = v206
			v_u_34(v210, v209, v208, 1.1):Emit(v207)
			v_u_1:AddItem(v210, 1.3)
			local v211 = v_u_137
			local v212 = 2 * v_u_132
			local v213 = v_u_154 * 0.9 + 3 * v_u_132
			local v214 = v_u_6.SakuraBloom
			local v215 = v_u_7
			local v216 = v_u_3.CurrentCamera
			local v217
			if v216 then
				local v218 = v216.CFrame.Position - v211
				v217 = v218.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v218.Unit
			else
				v217 = Vector3.new(0, 0, 1)
			end
			v_u_52(p_u_35.facing(v211 + v217 * 0.3, v217), v212, v213, v214, v215, 0.4, 4, 0.05)
			local v219 = v_u_137
			local v220 = 2 * v_u_132
			local v221 = v_u_154
			local v222 = v_u_6.Glow
			local v223 = v_u_8
			local v224 = v_u_3.CurrentCamera
			local v225
			if v224 then
				local v226 = v224.CFrame.Position - v219
				v225 = v226.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v226.Unit
			else
				v225 = Vector3.new(0, 0, 1)
			end
			v_u_52(p_u_35.facing(v219 + v225 * 0.3, v225), v220, v221, v222, v223, 0.25, 0, 0.3)
			v_u_4.ring(v_u_136, v_u_7, v_u_133 * 1.2, 0.45, v_u_6.Ring)
			p_u_35.burst("Impact", v_u_137, v_u_7, 1.6 * v_u_132)
			v_u_5.play("Burst", {
				["at"] = v_u_137,
				["volume"] = p_u_129.mine and 0.6 or 0.35
			})
			if p_u_129.mine then
				v_u_4.shake(0.25, 0.25)
			end
		end
	end
	local function v236(p228, p229, p230) -- name: rushIn
		-- upvalues: (copy) p_u_35, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_1, (ref) v_u_34
		local v231 = p228.size
		local v232 = p228.ability.radius * v231
		local v233 = p_u_35.ground(p229, 0)
		v_u_4.ring(v233, v_u_7, v232, 0.3, v_u_6.Ring)
		local v234 = v_u_4.part(Vector3.new(1, 1, 1) * v232 * 3, CFrame.new(v233 + Vector3.new(0, 3, 0) * v231), v_u_7, {
			["transparency"] = 1
		})
		v234.Shape = Enum.PartType.Ball
		v_u_1:AddItem(v234, 1.2)
		local v235 = v_u_34(v234, 0.5 * v231, v232 * 4, math.max(p230, 0.12) + 0.2)
		v235.Shape = Enum.ParticleEmitterShape.Sphere
		v235.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
		v235.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
		v235.Drag = 0
		v235.Acceleration = Vector3.new(0, 0, 0)
		v235:Emit(p228.lite and 10 or 30)
	end
	local v_u_237 = {}
	setmetatable(v_u_237, {
		["__mode"] = "k"
	})
	local function v_u_246(p238, p239, p240, p241) -- name: makeBlade
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_1
		local v242 = v_u_4.part(Vector3.new(p239, p240, 0.3), p238, v_u_7, {
			["transparency"] = 0.05
		})
		local v243 = v_u_4.part
		local v244 = p239 * 1.3
		local v245 = v243(Vector3.new(0.3, v244, p239), p238, v_u_7, {
			["transparency"] = 0.05
		})
		v245.Shape = v_u_12
		v_u_1:AddItem(v242, p241)
		v_u_1:AddItem(v245, p241)
		return {
			["body"] = v242,
			["tip"] = v245,
			["base"] = p238,
			["height"] = p240
		}
	end
	local function v_u_251(p247, p248) -- name: placeBlade
		local v249 = p247.height
		p247.body.CFrame = p248 * CFrame.new(0, v249 / 2, 0)
		local v250 = p247.body.Size.X
		p247.tip.CFrame = p248 * CFrame.new(0, v249 + v250 * 0.65, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
	end
	local v382 = {
		["senbonzakura_a"] = {
			["cast"] = function(p252) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (copy) v_u_52, (copy) p_u_35, (ref) v_u_34, (ref) v_u_1
				local v253 = p252.size
				local v254 = p252.eye + p252.dir * 1.1
				local v255 = 0.4 * v253
				local v256 = 1.9 * v253
				local v257 = v_u_6.Glow
				local v258 = v_u_7
				local v259 = v_u_3.CurrentCamera
				local v260
				if v259 then
					local v261 = v259.CFrame.Position - v254
					v260 = v261.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v261.Unit
				else
					v260 = Vector3.new(0, 0, 1)
				end
				v_u_52(p_u_35.facing(v254 + v260 * 0.3, v260), v255, v256, v257, v258, 0.12, 0, 0.15)
				if not p252.lite then
					local v262 = 6 * v253
					local v263 = 0.3 * v253
					local v264 = Instance.new("Attachment")
					v264.Parent = v_u_3.Terrain
					v264.WorldPosition = v254
					v_u_34(v264, v263, v262, 1.1):Emit(4)
					v_u_1:AddItem(v264, 1.3)
				end
			end,
			["shot"] = v106,
			["impact"] = v128,
			["hit"] = function(p265, p266, _) -- name: hit
				-- upvalues: (copy) p_u_35, (ref) v_u_7, (ref) v_u_3, (ref) v_u_34, (ref) v_u_1
				p_u_35.burst("Impact", p266, v_u_7, 0.5)
				if not p265.lite then
					local v267 = Instance.new("Attachment")
					v267.Parent = v_u_3.Terrain
					v267.WorldPosition = p266
					v_u_34(v267, 0.3, 8, 1.1):Emit(4)
					v_u_1:AddItem(v267, 1.3)
				end
			end
		},
		["senbonzakura_e"] = {
			["castSound"] = "Orb",
			["loopSound"] = "ModeLoop",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["hit"] = nil,
			["cast"] = function(p268) -- name: cast
				-- upvalues: (copy) v_u_80
				v_u_80(p268, false)
			end,
			["windup"] = v236,
			["zone"] = v227,
			["hit"] = function(p269, p270, _) -- name: hit
				-- upvalues: (copy) p_u_35, (ref) v_u_7, (ref) v_u_11
				p_u_35.burst("Impact", p270, v_u_7, 0.45)
				if not p269.lite then
					p_u_35.glint(p270, v_u_11, 1.6, 0.1)
				end
			end
		},
		["senbonzakura_r"] = {
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["land"] = nil,
			["hit"] = nil,
			["cast"] = function(p271) -- name: cast
				-- upvalues: (copy) v_u_80
				v_u_80(p271, true)
			end,
			["windup"] = function(p272, p273, p274) -- name: markRing
				-- upvalues: (copy) p_u_35, (ref) v_u_24, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (copy) v_u_237, (ref) v_u_4, (ref) v_u_34
				local v275 = p272.size
				local v_u_276 = p272.ability.radius * v275
				local v_u_277 = p_u_35.ground(p273, 0)
				local v_u_278 = v_u_24(CFrame.new(v_u_277 + Vector3.new(0, 0.2, 0)), v_u_276 * 1.4, v_u_6.Ring, v_u_7, 0.1)
				v_u_1:AddItem(v_u_278, p274 + 1)
				v_u_237[p272] = {
					["g"] = v_u_277,
					["marker"] = v_u_278
				}
				p_u_35.animate(math.max(p274, 0.08), 0, function(p279)
					-- upvalues: (copy) v_u_278, (copy) v_u_276, (copy) v_u_277
					if v_u_278.Parent then
						local v280 = v_u_278
						local v281 = v_u_276 * (1.4 - 0.45 * p279)
						local v282 = v281 * 2
						local v283 = v281 * 2
						v280.Size = Vector3.new(v282, 0.05, v283)
						v_u_278.CFrame = CFrame.new(v_u_277 + Vector3.new(0, 0.2, 0)) * CFrame.Angles(0, p279 * 2, 0)
					end
				end)
				if not p272.lite then
					local v284 = v_u_4.part
					local v285 = v_u_276 * 1.9
					local v286 = v_u_276 * 1.9
					local v287 = v284(Vector3.new(v285, 0.4, v286), CFrame.new(v_u_277 + Vector3.new(0, 0.4, 0)), v_u_7, {
						["transparency"] = 1
					})
					v_u_1:AddItem(v287, 1.5)
					local v288 = v_u_34(v287, 0.6 * v275, 6 * v275, 0.8)
					v288.Shape = Enum.ParticleEmitterShape.Cylinder
					v288.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
					v288.EmissionDirection = Enum.NormalId.Top
					v288.SpreadAngle = Vector2.new(20, 20)
					v288.Acceleration = Vector3.new(0, 0, 0)
					v288:Emit(24)
				end
			end,
			["land"] = function(p_u_289, p290) -- name: senkei
				-- upvalues: (copy) v_u_237, (copy) p_u_35, (copy) v_u_246, (copy) v_u_251, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_34, (ref) v_u_6, (ref) v_u_3, (copy) v_u_52, (ref) v_u_5, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8
				local v_u_291 = p_u_289.size
				local v_u_292 = p_u_289.ability.radius * v_u_291
				local v_u_293 = p_u_289.lite
				local v294 = v_u_237[p_u_289]
				v_u_237[p_u_289] = nil
				local v_u_295
				if v294 then
					v_u_295 = v294.g
				else
					v_u_295 = p_u_35.ground(p290, 0)
				end
				if v294 then
					v294.marker:Destroy()
				end
				local v_u_296 = {}
				local function v315(p297, p298, p299, p300, p301) -- name: ringOf
					-- upvalues: (copy) v_u_295, (ref) v_u_246, (ref) v_u_251, (copy) v_u_296
					for v302 = 1, p297 do
						local v303 = p301 + (v302 - 1) * 3.141592653589793 * 2 / p297
						local v304 = v_u_295
						local v305 = math.cos(v303)
						local v306 = math.sin(v303)
						local v307 = v304 + Vector3.new(v305, 0, v306) * p298
						local v308 = CFrame.lookAt
						local v309 = v_u_295.X
						local v310 = v307.Y
						local v311 = v_u_295.Z
						local v312 = v308(v307, (Vector3.new(v309, v310, v311)))
						local v313 = v_u_246(v312, p299, p300, 2)
						v_u_251(v313, v312 * CFrame.new(0, -p300, 0))
						local v314 = v_u_296
						table.insert(v314, v313)
					end
				end
				v315(v_u_293 and 10 or 20, v_u_292 * 0.92, 1.9 * v_u_291, 13 * v_u_291, 0)
				if not v_u_293 then
					v315(12, v_u_292 * 0.58, 1.5 * v_u_291, 9 * v_u_291, 0.2617993877991494)
				end
				p_u_35.animate(0.14, 0, function(p316)
					-- upvalues: (copy) v_u_296, (ref) v_u_251
					local v317 = p316 - 1
					local v318 = v317 * 2.7 * v317 * v317 + 1 + v317 * 1.7 * v317
					for _, v319 in v_u_296 do
						v_u_251(v319, v319.base * CFrame.new(0, -v319.height * (1 - v318), 0))
					end
				end)
				local v320 = v_u_4.part
				local v321 = v_u_292 * 1.85
				local v322 = v_u_292 * 1.85
				local v323 = v320(Vector3.new(v321, 0.4, v322), CFrame.new(v_u_295 + Vector3.new(0, 0.4, 0)), v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v323, 1.8)
				local v324 = v_u_34(v323, 0.7 * v_u_291, 16 * v_u_291, 1)
				v324.Shape = Enum.ParticleEmitterShape.Cylinder
				v324.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
				v324.EmissionDirection = Enum.NormalId.Top
				v324.SpreadAngle = Vector2.new(30, 30)
				v324:Emit(v_u_293 and 14 or 40)
				local v325 = v_u_295 + Vector3.new(0, 3, 0) * v_u_291
				local v326 = 2 * v_u_291
				local v327 = 9 * v_u_291
				local v328 = v_u_6.Glow
				local v329 = v_u_7
				local v330 = v_u_3.CurrentCamera
				local v331
				if v330 then
					local v332 = v330.CFrame.Position - v325
					v331 = v332.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v332.Unit
				else
					v331 = Vector3.new(0, 0, 1)
				end
				v_u_52(p_u_35.facing(v325 + v331 * 0.3, v331), v326, v327, v328, v329, 0.25, 0, 0.2)
				v_u_4.ring(v_u_295, v_u_7, v_u_292, 0.4, v_u_6.Shockwave)
				p_u_35.burst("Impact", v325, v_u_7, 1.8 * v_u_291)
				v_u_5.play("Burst", {
					["at"] = v_u_295,
					["volume"] = p_u_289.mine and 0.9 or 0.5
				})
				if p_u_289.mine then
					v_u_4.shake(0.3, 0.25)
				end
				local v_u_333 = os.clock()
				p_u_35.frame(function()
					-- upvalues: (copy) v_u_333, (copy) v_u_296, (ref) v_u_7, (ref) v_u_11
					local v334 = os.clock() - v_u_333
					if v334 > 0.36 then
						return false
					end
					for v335, v336 in v_u_296 do
						local v337 = v334 * 18 + v335 * 0.9
						local v338 = math.sin(v337)
						local v339 = math.max(v338, 0) ^ 6
						v336.body.Color = v_u_7:Lerp(v_u_11, v339)
					end
					return true
				end)
				p_u_35.after(0.36, function()
					-- upvalues: (copy) v_u_295, (copy) v_u_291, (copy) v_u_296, (copy) v_u_293, (ref) p_u_35, (ref) v_u_7, (ref) v_u_9, (ref) v_u_251
					local v_u_340 = v_u_295 + Vector3.new(0, 4, 0) * v_u_291
					for v341, v_u_342 in v_u_296 do
						if not v_u_293 and v341 % 2 == 1 then
							p_u_35.streak(v_u_342.body, v_u_7, v_u_9, 1.2 * v_u_291, 0.22)
						end
						local v_u_343 = v_u_342.body.CFrame * CFrame.new(0, -v_u_342.height / 2, 0)
						p_u_35.animate(0.16, 0, function(p344)
							-- upvalues: (copy) v_u_340, (copy) v_u_343, (copy) v_u_342, (ref) v_u_251
							local v345 = p344 * p344
							local v346 = v_u_340 - v_u_343.Position
							local v347 = v346.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v346.Unit
							local v348 = v_u_343.UpVector
							local v349 = p344 * 2
							local v350 = v348:Lerp(v347, (math.min(v349, 1)))
							local v351 = v350.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v350.Unit
							local v352 = v_u_343.Position:Lerp(v_u_340 - v347 * v_u_342.height, v345)
							v_u_251(v_u_342, CFrame.fromMatrix(v352, v_u_343.RightVector, v351))
							if p344 >= 1 then
								v_u_342.body:Destroy()
								v_u_342.tip:Destroy()
							end
						end)
					end
				end)
				p_u_35.after(0.52, function()
					-- upvalues: (copy) v_u_295, (copy) v_u_291, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (ref) v_u_52, (ref) p_u_35, (ref) v_u_8, (ref) v_u_11, (copy) v_u_293, (ref) v_u_34, (ref) v_u_1, (ref) v_u_4, (copy) v_u_292, (ref) v_u_5, (copy) p_u_289
					local v353 = v_u_295 + Vector3.new(0, 4, 0) * v_u_291
					local v354 = 4 * v_u_291
					local v355 = 21 * v_u_291
					local v356 = v_u_6.SakuraBloom
					local v357 = v_u_7
					local v358 = v_u_3.CurrentCamera
					local v359
					if v358 then
						local v360 = v358.CFrame.Position - v353
						v359 = v360.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v360.Unit
					else
						v359 = Vector3.new(0, 0, 1)
					end
					v_u_52(p_u_35.facing(v353 + v359 * 0.3, v359), v354, v355, v356, v357, 0.6, 2.5, 0)
					local v361 = 3 * v_u_291
					local v362 = 15 * v_u_291
					local v363 = v_u_6.Glow
					local v364 = v_u_8
					local v365 = v_u_3.CurrentCamera
					local v366
					if v365 then
						local v367 = v365.CFrame.Position - v353
						v366 = v367.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v367.Unit
					else
						v366 = Vector3.new(0, 0, 1)
					end
					v_u_52(p_u_35.facing(v353 + v366 * 0.3, v366), v361, v362, v363, v364, 0.35, 0, 0.05)
					local v368 = 2 * v_u_291
					local v369 = 9 * v_u_291
					local v370 = v_u_6.SakuraBloom
					local v371 = v_u_11
					local v372 = v_u_3.CurrentCamera
					local v373
					if v372 then
						local v374 = v372.CFrame.Position - v353
						v373 = v374.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v374.Unit
					else
						v373 = Vector3.new(0, 0, 1)
					end
					v_u_52(p_u_35.facing(v353 + v373 * 0.3, v373), v368, v369, v370, v371, 0.4, -4, 0.2)
					local v375 = v_u_293 and 20 or 60
					local v376 = 48 * v_u_291
					local v377 = 0.8 * v_u_291
					local v378 = Instance.new("Attachment")
					v378.Parent = v_u_3.Terrain
					v378.WorldPosition = v353
					v_u_34(v378, v377, v376, 1.1):Emit(v375)
					v_u_1:AddItem(v378, 1.3)
					v_u_4.ring(v_u_295, v_u_7, v_u_292 * 1.3, 0.5, v_u_6.Shockwave)
					v_u_4.ring(v_u_295, v_u_8, v_u_292 * 1.6, 0.65, v_u_6.Ring)
					p_u_35.burst("Impact", v353, v_u_7, 3 * v_u_291)
					p_u_35.burst("Flash", v353, v_u_7, 0.7 * v_u_291)
					if not v_u_293 then
						p_u_35.spikes(v353, v_u_8, 14, v_u_292 * 0.9, 0.3, nil, nil, true)
						p_u_35.glint(v353, v_u_11, 8 * v_u_291, 0.25)
					end
					v_u_5.play("Explosion", {
						["at"] = v353,
						["volume"] = p_u_289.mine and 1 or 0.6
					})
					v_u_5.play("Crit", {
						["at"] = v353,
						["volume"] = p_u_289.mine and 0.6 or 0.3
					})
					if p_u_289.mine then
						v_u_4.shake(0.6, 0.5)
					end
				end)
			end,
			["hit"] = function(p379, p380, _) -- name: hit
				-- upvalues: (copy) p_u_35, (ref) v_u_7, (ref) v_u_3, (ref) v_u_34, (ref) v_u_1
				p_u_35.burst("Impact", p380, v_u_7, 0.8)
				if not p379.lite then
					local v381 = Instance.new("Attachment")
					v381.Parent = v_u_3.Terrain
					v381.WorldPosition = p380
					v_u_34(v381, 0.4, 10, 1.1):Emit(5)
					v_u_1:AddItem(v381, 1.3)
				end
			end
		}
	}
	return v382
end