local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("6FC3FF")
local v_u_8 = Color3.fromRGB(6, 6, 12)
local v_u_9 = Color3.fromRGB(150, 195, 255)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_22(p12, p13) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v14 = v_u_2:FindFirstChild("EyePieces")
	if v14 then
		v14 = v14:FindFirstChild(p12)
	end
	if not (v14 and v14:IsA("MeshPart")) then
		return nil
	end
	local v15 = v14:Clone()
	local v16 = v14.Size
	local v17 = v14.Size.X
	local v18 = v14.Size.Y
	local v19 = v14.Size.Z
	v15.Size = v16 * (p13 / math.max(v17, v18, v19, 0.01))
	v15.Anchored = true
	v15.CanCollide = false
	v15.CanQuery = false
	v15.CanTouch = false
	v15.Massless = true
	v15.CastShadow = false
	local v20 = v15:FindFirstChildOfClass("SurfaceAppearance")
	if v20 then
		local v21 = v20.EmissiveStrength
		v20.EmissiveStrength = math.max(v21, 5)
	end
	v15.Parent = v_u_4.folder()
	return v15
end
local function v_u_28(p23, p24) -- name: axisAt
	local v25 = p24.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p24.Unit
	local v26 = v25.Y
	local v27 = math.abs(v26) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p23, p23 + v25, v27) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_33(p29, p30, p31) -- name: smoke
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_5
	local v32 = Instance.new("ParticleEmitter")
	v32.Texture = v_u_6.AlmightyWisp
	v32.Color = ColorSequence.new(v_u_9)
	v32.LightEmission = 0
	v32.LightInfluence = 0
	v32.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p30 * 0.4), NumberSequenceKeypoint.new(0.4, p30), NumberSequenceKeypoint.new(1, p30 * 1.2) })
	v32.Transparency = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 1),
		NumberSequenceKeypoint.new(0.15, 0.1),
		NumberSequenceKeypoint.new(0.7, 0.3),
		NumberSequenceKeypoint.new(1, 1)
	})
	v32.Lifetime = NumberRange.new(1.3, 2)
	v32.Speed = NumberRange.new(0.8, 1.8)
	v32.EmissionDirection = Enum.NormalId.Top
	v32.SpreadAngle = Vector2.new(30, 30)
	v32.Acceleration = Vector3.new(0, 0.6, 0)
	v32.Drag = 0.8
	v32.Rotation = NumberRange.new(-30, 30)
	v32.RotSpeed = NumberRange.new(-25, 25)
	v32.Shape = Enum.ParticleEmitterShape.Box
	v32.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v32:SetAttribute("BaseRate", p31)
	v32.Rate = p31 * v_u_5.formRate()
	v32.Parent = p29
	return v32
end
local function v_u_38(p34, p35, p36) -- name: eyes
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (copy) v_u_5
	local v37 = Instance.new("ParticleEmitter")
	v37.Texture = v_u_6.AlmightyEye
	v37.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v37.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v37.Color = ColorSequence.new(v_u_7)
	v37.LightEmission = 0.3
	v37.LightInfluence = 0
	v37.Size = NumberSequence.new(p35)
	v37.Transparency = NumberSequence.new(0)
	v37.Lifetime = NumberRange.new(1.5, 1.9)
	v37.Speed = NumberRange.new(0)
	v37.Rotation = NumberRange.new(-12, 12)
	v37.LockedToPart = true
	v37.ZOffset = 1
	v37.Shape = Enum.ParticleEmitterShape.Box
	v37.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v37:SetAttribute("BaseRate", p36)
	v37.Rate = p36 * v_u_5.formRate()
	v37.Parent = p34
	return v37
end
return function(p_u_39)
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_22, (copy) v_u_11, (copy) v_u_10, (copy) v_u_28, (copy) v_u_3, (copy) v_u_33, (copy) v_u_38
	return {
		["w7_almighty"] = function(p_u_40, _)
			-- upvalues: (ref) v_u_1, (copy) p_u_39, (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_22, (ref) v_u_11, (ref) v_u_10, (ref) v_u_28, (ref) v_u_3, (ref) v_u_33, (ref) v_u_38
			local v41 = p_u_40.headY / 1.5
			local v_u_42 = math.clamp(v41, 0.7, 3)
			local v_u_43 = p_u_40.fx
			local v44 = p_u_40.character == v_u_1.LocalPlayer.Character
			local v45 = p_u_40.character:FindFirstChild("Head")
			if not (v45 and v45:IsA("BasePart")) then
				v45 = nil
			end
			local v_u_46
			if v45 then
				v_u_46 = v45.Size.Y
			else
				v_u_46 = v_u_42 * 1.2
			end
			local v_u_47 = p_u_39.crownOf(p_u_40)
			p_u_40.eyeLift = 3
			local v_u_48 = nil
			local v_u_49 = nil
			local v_u_50 = nil
			local function v_u_51()
				-- upvalues: (copy) p_u_40, (copy) v_u_42
				return p_u_40.root.Position + Vector3.new(0, 1, 0) * (p_u_40.headY + v_u_42 * 0.8)
			end
			local v_u_64 = p_u_39.throb(p_u_40, 6, 2, 0.8, function(p52)
				-- upvalues: (ref) v_u_4, (ref) v_u_51, (ref) v_u_7, (copy) v_u_42, (copy) v_u_43, (ref) p_u_39, (copy) p_u_40, (ref) v_u_8, (ref) v_u_6, (ref) v_u_48, (ref) v_u_5, (ref) v_u_49, (ref) v_u_50
				v_u_4.flash(v_u_51(), v_u_7, v_u_42 * 2.6 * v_u_43, 0.25)
				v_u_4.ring(p_u_39.feetAt(p_u_40, p52, 0.1), v_u_8, 9 * v_u_43, 0.6, v_u_6.Shockwave)
				local v53 = v_u_48
				if v53 then
					v53:Emit(v_u_5.level() <= 1 and 3 or 10)
				end
				local v54 = v_u_49
				local v55 = v_u_50
				if v54 and v55 then
					for v56 = 1, v_u_5.level() <= 1 and 3 or 7 do
						local v57 = v56 * 3.141592653589793 * 2 / 7 + math.random() * 0.3
						local v58 = v_u_42 * 2.4 * v_u_43
						local v59 = p52.Position
						local v60 = math.cos(v57) * v58
						local v61 = v56 * 1.7
						local v62 = (math.sin(v61) * 0.9 + 0.4) * v_u_42
						local v63 = math.sin(v57) * v58
						v54.WorldPosition = v59 + Vector3.new(v60, v62, v63)
						v55:Emit(1)
					end
				end
			end)
			local v_u_71 = p_u_39.group(p_u_40, function(p65, p66)
				-- upvalues: (copy) v_u_47, (copy) v_u_46
				local v67 = v_u_47(p65)
				local v68 = CFrame.new
				local v69 = 0.66 * v_u_46
				local v70 = p66 * 1.4
				return v67 * v68(0, v69 + math.sin(v70) * 0.03 * v_u_46, 0.02 * v_u_46)
			end)
			v_u_51 = function()
				-- upvalues: (copy) v_u_71, (copy) v_u_46
				return (v_u_71.cf * CFrame.new(0, 0, -0.62 * v_u_46)).Position
			end
			local v72 = v_u_22("w7_almighty", 1.55 * v_u_46)
			if v72 then
				p_u_39.pin(p_u_40, v_u_71, v72, v_u_11)
			else
				local v73 = p_u_39.disc
				local v74 = 0.22 * v_u_46
				local v75 = 1.1 * v_u_46
				local v76 = 1.1 * v_u_46
				local v77 = v73(Vector3.new(v74, v75, v76), v_u_8, 0, v_u_10)
				p_u_39.pin(p_u_40, v_u_71, v77, CFrame.new(0, -0.15 * v_u_46, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
				for v78 = 1, 8 do
					local v79 = (v78 - 0.5) / 8 * 3.141592653589793 * 2
					local v80 = Instance.new("WedgePart")
					v80.Anchored = true
					v80.CanCollide = false
					v80.CanQuery = false
					v80.CanTouch = false
					v80.CastShadow = false
					v80.Massless = true
					v80.Color = v_u_8
					v80.Material = v_u_10
					v80.Reflectance = 0.15
					local v81 = 0.08 * v_u_46
					local v82 = (v78 % 2 == 0 and 0.55 or 0.75) * v_u_46
					local v83 = 0.26 * v_u_46
					v80.Size = Vector3.new(v81, v82, v83)
					v80.Parent = v_u_4.folder()
					local v84 = math.cos(v79)
					local v85 = math.sin(v79)
					local v86 = Vector3.new(v84, 0, v85)
					local v87 = v86 * 0.52 * v_u_46 + Vector3.new(0, 1, 0) * v80.Size.Y * 0.4
					p_u_39.pin(p_u_40, v_u_71, v80, CFrame.lookAt(v87, v87 + v86) * CFrame.Angles(-0.2, 0, 0))
				end
				p_u_39.pin(p_u_40, v_u_71, p_u_39.ball(0.22 * v_u_46, v_u_7, 0, Enum.Material.Neon), CFrame.new(0, -0.12 * v_u_46, -0.58 * v_u_46))
			end
			local v_u_88 = {}
			for _, v89 in { false, true } do
				for _, v90 in { -1, 1 } do
					local v_u_91 = Instance.new("Attachment")
					v_u_91.Parent = p_u_40.root
					p_u_39.own(p_u_40, v_u_91)
					local v92 = p_u_40.stops
					table.insert(v92, function()
						-- upvalues: (copy) v_u_91
						v_u_91:Destroy()
					end)
					local v_u_93 = Instance.new("Attachment")
					v_u_93.Parent = p_u_40.root
					p_u_39.own(p_u_40, v_u_93)
					local v94 = p_u_40.stops
					table.insert(v94, function()
						-- upvalues: (copy) v_u_93
						v_u_93:Destroy()
					end)
					local v95 = p_u_39.ray(v_u_91, v_u_93, v_u_8, (v89 and 1.4 or 1.8) * v_u_42, (v89 and 3 or 3.6) * v_u_42, v_u_6.AlmightyMantle)
					v95.Color = ColorSequence.new(v_u_8)
					v95.LightEmission = 0
					v95.LightInfluence = 0
					v95.TextureMode = Enum.TextureMode.Wrap
					v95.TextureLength = v_u_42 * 3.5
					v95.TextureSpeed = -0.6
					v95.Segments = 12
					v95.Transparency = NumberSequence.new({
						NumberSequenceKeypoint.new(0, 0.3),
						NumberSequenceKeypoint.new(0.15, 0.02),
						NumberSequenceKeypoint.new(0.8, 0.1),
						NumberSequenceKeypoint.new(1, 0.9)
					})
					table.insert(v_u_88, {
						["a0"] = v_u_91,
						["a1"] = v_u_93,
						["beam"] = v95,
						["side"] = v90,
						["outer"] = v89
					})
				end
			end
			local v_u_96 = 0
			local v97 = p_u_40.ticks
			local function v128(p98, p99, p100)
				-- upvalues: (copy) p_u_40, (ref) v_u_96, (copy) v_u_64, (copy) v_u_88, (ref) v_u_28, (copy) v_u_42
				local v101 = v_u_96
				local v102 = -p98:VectorToObjectSpace(p_u_40.root.AssemblyLinearVelocity).Z / 18
				local v103 = math.clamp(v102, 0, 1) - v_u_96
				local v104 = p100 * 4
				v_u_96 = v101 + v103 * math.min(v104, 1)
				local v105 = v_u_64()
				for v106, v107 in v_u_88 do
					local v108 = v107.side
					local v109 = p99 * 1.7 + v106 * 1.3
					local v110 = math.sin(v109)
					local v111 = v107.outer and 1.05 or 0.55
					local v112 = v107.a0
					local v113 = v_u_28
					local v114 = v108 * v111 * v_u_42
					local v115 = v_u_42 * 1.05
					local v116 = v_u_42 * 0.25
					local v117 = Vector3.new(v114, v115, v116)
					local v118 = v108 * 0.25
					local v119 = 0.4 + v105 * 0.4
					v112.CFrame = v113(v117, (Vector3.new(v118, v119, 1)))
					local v120 = v107.a1
					local v121 = v_u_28
					local v122 = v108 * (v111 + 0.5 + v110 * 0.25 + v105 * 0.8) * v_u_42
					local v123 = p_u_40.feet + 0.1 + v_u_96 * 1.6 * v_u_42 + v105 * 1.2 * v_u_42
					local v124 = (v110 * 0.3 + 2.1 + v_u_96 * 2.4 + v105) * v_u_42
					local v125 = Vector3.new(v122, v123, v124)
					local v126 = v108 * 0.2 + v110 * 0.2
					local v127 = v_u_96 * 0.4 + -0.3
					v120.CFrame = v121(v125, (Vector3.new(v126, v127, 1)))
					v107.beam.CurveSize0 = (v110 * 0.4 + 1.2) * v_u_42
					v107.beam.CurveSize1 = v_u_42 * 1.4
				end
			end
			table.insert(v97, v128)
			if v44 then
				local v_u_129 = -1
				local v130 = p_u_40.ticks
				local function v147(p131)
					-- upvalues: (ref) v_u_3, (ref) v_u_129, (copy) v_u_88
					local v132 = v_u_3.CurrentCamera
					local v133 = ((not v132 and 0 or v132.CFrame.LookVector:Dot(p131.LookVector)) - 0.3) * 1.4
					local v134 = math.clamp(v133, 0, 1) * 4
					local v135 = math.floor(v134) / 4
					if v135 ~= v_u_129 then
						v_u_129 = v135
						local v136 = v135 * 0.4 + 0.02
						for _, v137 in v_u_88 do
							local v138 = v137.beam
							local v139 = NumberSequence.new
							local v140 = {}
							local v141 = NumberSequenceKeypoint.new
							local v142 = v136 + 0.3
							local v143 = v141(0, (math.min(v142, 1)))
							local v144 = NumberSequenceKeypoint.new(0.15, v136)
							local v145 = NumberSequenceKeypoint.new
							local v146 = v136 + 0.08
							__set_list(v140, 1, {v143, v144, v145(0.8, (math.min(v146, 1))), NumberSequenceKeypoint.new(1, 0.9)})
							v138.Transparency = v139(v140)
						end
					end
				end
				table.insert(v130, v147)
			end
			local v148 = v_u_42 * 2.6
			local v149 = v_u_42 * 1.6
			local v150 = v_u_42 * 1.4
			local v151 = Vector3.new(v148, v149, v150)
			local v152 = Instance.new("Part")
			v152.Size = v151
			v152.Transparency = 1
			v152.Anchored = true
			v152.CanCollide = false
			v152.CanQuery = false
			v152.CanTouch = false
			v152.CastShadow = false
			v152.Parent = v_u_4.folder()
			p_u_39.add(p_u_40, v152, function(p153)
				-- upvalues: (copy) v_u_42
				return p153 * CFrame.new(0, v_u_42 * 0.7, v_u_42 * 0.2)
			end)
			local v_u_154 = v_u_33(v152, v_u_42 * 2.2 * v_u_43, 8 * v_u_43)
			v_u_48 = v_u_154
			p_u_39.own(p_u_40, v152)
			local v155 = p_u_40.stops
			table.insert(v155, function()
				-- upvalues: (copy) v_u_154
				v_u_154.Enabled = false
			end)
			local v156 = p_u_40.character:FindFirstChild("RightHand") or p_u_40.character:FindFirstChild("Right Arm")
			if v156 and v156:IsA("BasePart") then
				local v157 = v156.Name ~= "Right Arm" and 0 or -v156.Size.Y / 2
				local v_u_158 = Instance.new("Attachment")
				local v159 = v157 + v_u_42 * 0.35
				v_u_158.Position = Vector3.new(0, v159, 0)
				v_u_158.Parent = v156
				local v_u_160 = Instance.new("Attachment")
				local v161 = v157 - v_u_42 * 0.35
				v_u_160.Position = Vector3.new(0, v161, 0)
				v_u_160.Parent = v156
				local v162 = Instance.new("Trail")
				v162.Attachment0 = v_u_158
				v162.Attachment1 = v_u_160
				v162.Texture = v_u_6.AlmightyMantle
				v162.TextureMode = Enum.TextureMode.Stretch
				v162.Color = ColorSequence.new(v_u_8)
				v162.Transparency = NumberSequence.new(0.1, 1)
				v162.WidthScale = NumberSequence.new(1, 1.8)
				v162.Lifetime = 0.6
				v162.LightEmission = 0
				v162.LightInfluence = 0
				v162.FaceCamera = true
				v162.MinLength = 0.05
				v162.Parent = v_u_158
				local v_u_163 = v_u_33(v_u_160, v_u_42 * 0.9 * v_u_43, 1.5 * v_u_43)
				v_u_163.Shape = Enum.ParticleEmitterShape.Sphere
				v_u_163.EmissionDirection = Enum.NormalId.Bottom
				v_u_163.Acceleration = Vector3.new(0, -0.5, 0)
				for _, v164 in { v_u_158, v_u_160 } do
					p_u_39.own(p_u_40, v164)
				end
				local v165 = p_u_40.stops
				table.insert(v165, function()
					-- upvalues: (copy) v_u_163, (copy) v_u_158, (copy) v_u_160
					v_u_163.Enabled = false
					v_u_158:Destroy()
					v_u_160:Destroy()
				end)
			end
			local v166 = v_u_42 * 3.4
			local v167 = v_u_42 * 3.6
			local v168 = v_u_42 * 2.6
			local v169 = Vector3.new(v166, v167, v168)
			local v170 = Instance.new("Part")
			v170.Size = v169
			v170.Transparency = 1
			v170.Anchored = true
			v170.CanCollide = false
			v170.CanQuery = false
			v170.CanTouch = false
			v170.CastShadow = false
			v170.Parent = v_u_4.folder()
			p_u_39.add(p_u_40, v170, function(p171)
				-- upvalues: (copy) v_u_42
				return p171 * CFrame.new(0, v_u_42 * 0.4, v_u_42 * 0.5)
			end)
			local v_u_172 = v_u_38(v170, (v44 and 0.5 or 0.6) * v_u_42 * v_u_43, 0.8 * v_u_43)
			p_u_39.own(p_u_40, v170)
			local v_u_173 = Instance.new("Attachment")
			v_u_173.Parent = v_u_3.Terrain
			local v174 = v_u_38(v_u_173, v_u_42 * 0.75 * v_u_43, 0)
			v174.LockedToPart = false
			v174.Shape = Enum.ParticleEmitterShape.Box
			v_u_49 = v_u_173
			v_u_50 = v174
			local v175 = p_u_40.stops
			table.insert(v175, function()
				-- upvalues: (copy) v_u_172, (copy) v_u_173
				v_u_172.Enabled = false
				game:GetService("Debris"):AddItem(v_u_173, 2)
			end)
			local v_u_176 = p_u_39.picture(v_u_42 * 5.6, v_u_6.Glow, v_u_8, 0.05)
			p_u_39.add(p_u_40, v_u_176, function(p177)
				-- upvalues: (ref) p_u_39, (copy) p_u_40
				return CFrame.new(p_u_39.feetAt(p_u_40, p177, 0.05))
			end)
			local v178 = p_u_39.picture(v_u_42 * 3.6, v_u_6.Glow, v_u_8, 0)
			p_u_39.add(p_u_40, v178, function(p179)
				-- upvalues: (ref) p_u_39, (copy) p_u_40
				return CFrame.new(p_u_39.feetAt(p_u_40, p179, 0.07))
			end)
			local v_u_180 = -1
			local v181 = p_u_40.ticks
			local function v185()
				-- upvalues: (copy) v_u_64, (ref) v_u_180, (copy) v_u_42, (copy) v_u_176
				local v182 = v_u_64() * 16
				local v183 = math.floor(v182) / 16
				if v183 ~= v_u_180 then
					v_u_180 = v183
					local v184 = v_u_42 * 5.6 * (v183 * 0.45 + 1)
					v_u_176.Size = Vector3.new(v184, 0.05, v184)
				end
			end
			table.insert(v181, v185)
			local v_u_186 = v_u_33(v_u_176, v_u_42 * 1.3 * v_u_43, 2.5 * v_u_43)
			v_u_186.Speed = NumberRange.new(0.3, 0.8)
			v_u_186.Lifetime = NumberRange.new(1, 1.6)
			p_u_39.own(p_u_40, v_u_176)
			local v187 = p_u_40.stops
			table.insert(v187, function()
				-- upvalues: (copy) v_u_186
				v_u_186.Enabled = false
			end)
			p_u_39.particles(p_u_40, "AuraMode", v_u_7, {
				["rate"] = 0.2,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Sparks" }
			})
		end
	}
end