local v1 = {
	["castle_demon"] = {
		["shirt"] = 6853322295,
		["pants"] = 6853320846,
		["accessories"] = nil,
		["skin"] = "#D2C8C0",
		["accessories"] = { 102806127354707, 100119911590809 }
	},
	["horned_oni"] = {
		["shirt"] = 4534470600,
		["pants"] = 4690061613,
		["accessories"] = nil,
		["skin"] = "#B5372C",
		["accessories"] = { 117126955525010, 8786330068 }
	},
	["tatami_crawler"] = {
		["shirt"] = 11329420100,
		["pants"] = 11329428745,
		["accessories"] = nil,
		["skin"] = "#8C927A",
		["accessories"] = { 115761828042609, 103470979109406, 14182827805 }
	},
	["mask_demon"] = {
		["shirt"] = 7039601717,
		["pants"] = 7039603099,
		["accessories"] = nil,
		["skin"] = "#C2BACB",
		["accessories"] = { 13367368034, 135887860575192 }
	},
	["lantern_ghoul"] = {
		["shirt"] = 10653834975,
		["pants"] = 10652751225,
		["accessories"] = nil,
		["skin"] = "#A9B3BD",
		["accessories"] = { 91327912247318, 103498238904300, 106412841769526 }
	},
	["thread_demon"] = {
		["shirt"] = 4812587828,
		["pants"] = 4812656896,
		["accessories"] = nil,
		["skin"] = "#F2EEF0",
		["accessories"] = {
			12561062579,
			15474900644,
			129660553936446,
			114751927201441
		}
	},
	["lower_moon_one"] = {
		["shirt"] = 4856660868,
		["pants"] = 4856712668,
		["accessories"] = nil,
		["skin"] = "#EDE7E2",
		["accessories"] = {
			14424170358,
			16628203740,
			137856806767144,
			96898076340039
		}
	},
	["vase_fiend"] = {
		["shirt"] = 6793989406,
		["pants"] = 6793990540,
		["accessories"] = nil,
		["skin"] = "#E8E4EE",
		["accessories"] = { 112371693637318, 123185590099776 }
	},
	["needle_fish_demon"] = {
		["shirt"] = 8262665527,
		["pants"] = 8262666093,
		["accessories"] = nil,
		["skin"] = "#F0A060",
		["accessories"] = {
			18625276787,
			91942570124215,
			138105807540847,
			15619129448
		}
	},
	["ceiling_crawler"] = {
		["shirt"] = 410057752,
		["pants"] = 7952825025,
		["accessories"] = nil,
		["skin"] = "#C9D1D8",
		["accessories"] = { 98860883654498, 12025029109 }
	},
	["upside_demon"] = {
		["shirt"] = 7437127883,
		["pants"] = 7437131226,
		["accessories"] = nil,
		["skin"] = "#7B6B96",
		["accessories"] = { 14355998505, 80252604474433 }
	},
	["thunder_disciple"] = {
		["shirt"] = 6419215881,
		["pants"] = 121990360123333,
		["accessories"] = nil,
		["skin"] = "#D9C2A2",
		["accessories"] = {
			12465739726,
			112448477426260,
			16963286771,
			138336097381795
		}
	},
	["sickle_demon"] = {
		["shirt"] = 6339133463,
		["pants"] = 6335223679,
		["accessories"] = nil,
		["skin"] = "#9B9792",
		["accessories"] = { 73925013235252, 77665158882376 }
	},
	["upper_six"] = {
		["shirt"] = 6138390170,
		["pants"] = 6138392602,
		["accessories"] = nil,
		["skin"] = "#DCCAB4",
		["accessories"] = {
			126566929017257,
			112419633659203,
			100743537815601,
			18453905523
		}
	},
	["shoji_stalker"] = {
		["shirt"] = 15512730260,
		["pants"] = 15512732598,
		["accessories"] = nil,
		["skin"] = "#5C5862",
		["accessories"] = { 76162011454800, 135209172897036, 85384620931401 }
	},
	["biwa_servant"] = {
		["shirt"] = 6789334908,
		["pants"] = 6789336102,
		["accessories"] = nil,
		["skin"] = "#EFE8E2",
		["accessories"] = { 18682379410, 12677450358 }
	},
	["eyeball_demon"] = {
		["shirt"] = 6147116650,
		["pants"] = 6141148796,
		["accessories"] = nil,
		["skin"] = "#E6DDE0",
		["accessories"] = { 121712349013731, 130772350976056 }
	},
	["room_shifter"] = {
		["shirt"] = 17856492485,
		["pants"] = 17856549306,
		["accessories"] = nil,
		["skin"] = "#C7B7A8",
		["accessories"] = { 17250339345, 107806732872382 }
	},
	["ice_doll"] = {
		["shirt"] = 6704186045,
		["pants"] = 6704519540,
		["accessories"] = nil,
		["skin"] = "#DDF0FA",
		["accessories"] = { 107268573787447, 85153919900811, 18940711380 }
	},
	["lotus_cultist"] = {
		["shirt"] = 10653261164,
		["pants"] = 10653264040,
		["accessories"] = nil,
		["skin"] = "#E5D1BC",
		["accessories"] = {
			94820539439985,
			139701207235416,
			15715650117,
			105157510533885
		}
	},
	["upper_two"] = {
		["shirt"] = 13110969310,
		["pants"] = 13111034064,
		["accessories"] = nil,
		["skin"] = "#F2E8DE",
		["accessories"] = {
			95478921211093,
			99907862560338,
			110010565052242,
			14269354905
		}
	},
	["martial_demon"] = {
		["shirt"] = 132384058532976,
		["pants"] = 137970308485495,
		["accessories"] = nil,
		["skin"] = "#E9E2E6",
		["accessories"] = { 115922203007560, 85573046478516 }
	},
	["compass_brawler"] = {
		["shirt"] = 97227961661181,
		["pants"] = 76103306145919,
		["accessories"] = nil,
		["skin"] = "#C98B6B",
		["accessories"] = { 14675265828, 16081282581, 82893115272510 }
	},
	["stair_ghoul"] = {
		["shirt"] = 73758491243392,
		["pants"] = 17811566464,
		["accessories"] = nil,
		["skin"] = "#8E7F75",
		["accessories"] = { 91538079627764, 85862548028802, 128156155507386 }
	},
	["crescent_demon"] = {
		["shirt"] = 15414851596,
		["pants"] = 15414558995,
		["accessories"] = nil,
		["skin"] = "#B8AACB",
		["accessories"] = { 122859436810233, 16483110347 }
	},
	["moon_blade_demon"] = {
		["shirt"] = 6676905779,
		["pants"] = 10693458873,
		["accessories"] = nil,
		["skin"] = "#7F2C30",
		["accessories"] = {
			101367336456073,
			18446978333,
			118781822261372,
			9666297316
		}
	},
	["six_eye_sentinel"] = {
		["shirt"] = 11263589848,
		["pants"] = 11263594439,
		["accessories"] = nil,
		["skin"] = "#D9BBA4",
		["accessories"] = { 18943128124, 8937494639, 98255504962768 }
	},
	["upper_one"] = {
		["shirt"] = 10263060124,
		["pants"] = 10263064167,
		["accessories"] = nil,
		["skin"] = "#E0C6B0",
		["accessories"] = {
			75383899165104,
			16562433543,
			126417293573328,
			87110799539894
		}
	},
	["flesh_demon"] = {
		["shirt"] = 83144932153747,
		["pants"] = 82191973170851,
		["accessories"] = nil,
		["skin"] = "#A34A4A",
		["accessories"] = { 84317448755936, 14182802872 }
	},
	["rubble_oni"] = {
		["shirt"] = 11256424643,
		["pants"] = 9818527293,
		["accessories"] = nil,
		["skin"] = "#7D716A",
		["accessories"] = { 133276881852964, 4820150916, 77471260635339 }
	},
	["dawn_runner"] = {
		["shirt"] = 5219948504,
		["pants"] = 5219953501,
		["accessories"] = nil,
		["skin"] = "#E1C9B5",
		["accessories"] = { 14387126586, 84061748450818 }
	},
	["sunless_demon"] = {
		["shirt"] = 6529546410,
		["pants"] = 11722576049,
		["accessories"] = nil,
		["skin"] = "#C0B5AF",
		["accessories"] = { 80253412367874, 120449662629402, 105248865545161 }
	},
	["muzan_clone"] = {
		["shirt"] = 6171481460,
		["pants"] = 6171484809,
		["accessories"] = nil,
		["skin"] = "#E4C3A2",
		["accessories"] = { 121498551889638, 93690253378735, 12875735024 }
	},
	["blood_tendril_demon"] = {
		["shirt"] = 10705806016,
		["pants"] = 6645175328,
		["accessories"] = nil,
		["skin"] = "#E6DAD2",
		["accessories"] = { 136843285016633, 14737876417 }
	},
	["demon_king_muzan"] = {
		["shirt"] = 18201720022,
		["pants"] = 18201728299,
		["accessories"] = nil,
		["skin"] = "#F0E8E0",
		["accessories"] = {
			96530595599765,
			92014230573720,
			116850438638411,
			116642368198083
		}
	}
}
return v1