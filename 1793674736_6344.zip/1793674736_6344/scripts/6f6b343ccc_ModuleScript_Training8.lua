require(script.Parent.Training)
return {
	{
		["id"] = "w8_hall_dummy",
		["name"] = "Hall Dummy",
		["theme"] = "dummy",
		["rebirths"] = 549,
		["mult"] = 9.2e27,
		["color"] = "#C8A27A"
	},
	{
		["id"] = "w8_lantern_ring",
		["name"] = "Lantern Ring",
		["theme"] = "ring",
		["rebirths"] = 557,
		["mult"] = 2.93e28,
		["color"] = "#FF8A3A"
	},
	{
		["id"] = "w8_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 9.4e28,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w8_water_falls",
		["name"] = "Water Falls",
		["theme"] = "waterfall",
		["rebirths"] = 565,
		["mult"] = 9.4e28,
		["color"] = "#2EA8FF"
	},
	{
		["id"] = "w8_sun_forge",
		["name"] = "Sun Forge",
		["theme"] = "forge",
		["rebirths"] = 573,
		["mult"] = 2.98e29,
		["color"] = "#FFB21F"
	},
	{
		["id"] = "w8_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 9.6e29,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w8_shoji_temple",
		["name"] = "Shoji Temple",
		["theme"] = "temple",
		["rebirths"] = 581,
		["mult"] = 9.6e29,
		["color"] = "#F2E2C4"
	},
	{
		["id"] = "w8_thunder_tower",
		["name"] = "Thunder Tower",
		["theme"] = "storm",
		["rebirths"] = 589,
		["mult"] = 3.09e30,
		["color"] = "#FFD23D"
	},
	{
		["id"] = "w8_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 9.85e30,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w8_biwa_chamber",
		["name"] = "Biwa Chamber",
		["theme"] = "gravity",
		["rebirths"] = 597,
		["mult"] = 9.85e30,
		["color"] = "#FF6FB8"
	},
	{
		["id"] = "w8_blood_moon_shrine",
		["name"] = "Blood Moon Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 605,
		["mult"] = 3.18e31,
		["color"] = "#E0213A"
	},
	{
		["id"] = "w8_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 3.4e32,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w8_demon_altar",
		["name"] = "Demon Altar",
		["theme"] = "void",
		["rebirths"] = 613,
		["mult"] = 1.01e32,
		["color"] = "#8A0F2A"
	}
}