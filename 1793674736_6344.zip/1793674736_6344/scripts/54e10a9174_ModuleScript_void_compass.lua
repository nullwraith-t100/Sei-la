local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = {
	Vector3.new(0, 0, -1),
	Vector3.new(1, 0, 0),
	Vector3.new(0, 0, 1),
	Vector3.new(-1, 0, 0)
}
return function(p_u_6)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_1, (copy) v_u_5
	local v_u_7 = Enum.Material.SmoothPlastic
	local v_u_8 = CFrame.Angles(1.5707963267948966, 0, 0)
	local function v_u_19(p9, p10, p11) -- name: voidFlare
		-- upvalues: (copy) p_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_1
		local v12, v13 = p_u_6.picture(p10, v_u_4.VoidStar, p11, 0)
		v12.CFrame = CFrame.lookAt(p9, p_u_6.camPos()) * CFrame.Angles(-1.5707963267948966, 0, 0)
		local v14 = v_u_3.tween
		local v15 = {}
		local v16 = p10 * 2.2
		local v17 = p10 * 2.2
		v15.Size = Vector3.new(v16, 0.05, v17)
		v14(v12, 0.5, v15)
		for _, v18 in v13 do
			v_u_3.tween(v18, 0.5, {
				["Transparency"] = 1
			})
		end
		v_u_1:AddItem(v12, 0.55)
	end
	return {
		["w3_void_compass"] = function(p_u_20, p21) -- name: w3_void_compass
			-- upvalues: (copy) p_u_6, (copy) v_u_19, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (copy) v_u_7, (copy) v_u_8
			local v_u_22 = p_u_20.fx <= 1 and 1 or p_u_20.fx / 1.35
			local v_u_23 = Color3.fromHex(p21.color)
			local v_u_24 = Color3.fromHex(p21.color2)
			local v25 = p_u_6.rgb(8, 6, 20)
			p_u_20.eyeLift = 3.7
			local v_u_26 = 0
			local v_u_27 = 0
			local v_u_28 = 0
			local v_u_29 = 1.5
			local v_u_30 = -1
			local v_u_31 = 0
			local v32 = p_u_20.ticks
			local function v46(p33, p34, p35)
				-- upvalues: (ref) v_u_29, (ref) v_u_28, (ref) v_u_26, (ref) v_u_30, (ref) v_u_27, (ref) v_u_31, (copy) p_u_20, (ref) p_u_6, (copy) v_u_22, (ref) v_u_19, (copy) v_u_23, (ref) v_u_3, (copy) v_u_24
				if v_u_29 <= p34 then
					v_u_29 = p34 + 4.5
					v_u_28 = v_u_26 + (math.random() < 0.5 and -1 or 1) * (1.6 + math.random() * 2.2)
					v_u_30 = p34 + 0.75
				end
				local v36 = math.min(p35, 0.03333333333333333)
				v_u_27 = v_u_27 + ((v_u_28 - v_u_26) * 32 - v_u_27 * 3.2) * v36
				v_u_26 = v_u_26 + v_u_27 * v36
				if v_u_30 > 0 and v_u_30 <= p34 then
					v_u_30 = -1
					v_u_31 = 1
					p_u_20.pulse = 1
					if (p33.Position - p_u_6.camPos()).Magnitude < 150 then
						local v37 = v_u_28
						local v38 = -math.sin(v37)
						local v39 = v_u_28
						local v40 = -math.cos(v39)
						local v41 = Vector3.new(v38, 0, v40)
						local v42 = p33.Position + v41 * 5 * v_u_22 + Vector3.new(0, 0.8, 0) * v_u_22
						v_u_19(v42, 2.2 * v_u_22, v_u_23)
						v_u_3.flash(v42, v_u_24, 3 * p_u_20.fx, 0.3)
					end
				end
				local v43 = v_u_31 - p35 * 2.5
				v_u_31 = math.max(v43, 0)
				local v44 = p_u_20
				local v45 = p_u_20.pulse - p35 * 2
				v44.pulse = math.max(v45, 0)
			end
			table.insert(v32, v46)
			local v_u_53 = p_u_6.group(p_u_20, function(p47, p48)
				-- upvalues: (copy) v_u_22
				local v49 = CFrame.new
				local v50 = p47.Position
				local v51 = -0.35 * v_u_22
				local v52 = p48 * 1.3
				return v49(v50 + Vector3.new(0, 1, 0) * (v51 + math.sin(v52) * 0.06 * v_u_22)) * CFrame.Angles(0, p48 * 0.15, 0)
			end)
			p_u_6.pin(p_u_20, v_u_53, p_u_6.picture(7.2 * v_u_22, v_u_4.CompassRose, v_u_23, 0.15), CFrame.identity)
			local v_u_54 = v_u_26
			local v_u_55 = v_u_31
			local v_u_56 = {}
			for v_u_57, v_u_58 in v_u_5 do
				local function v62(_, p59) -- name: orbAt
					-- upvalues: (copy) v_u_57, (copy) v_u_22, (copy) v_u_53, (copy) v_u_58
					local v60 = p59 * 2 + v_u_57 * 1.6
					local v61 = math.sin(v60) * 0.12 * v_u_22
					return v_u_53.cf * CFrame.new(v_u_58 * 3 * v_u_22 + Vector3.new(0, 1, 0) * (0.25 * v_u_22 + v61))
				end
				local v63 = p_u_6.ball(0.62 * v_u_22, v_u_23, 0)
				p_u_6.add(p_u_20, v63, v62)
				p_u_6.add(p_u_20, p_u_6.ball(0.9 * v_u_22, v25, 0, v_u_7), p_u_6.behind(v62, 0.2 * v_u_22))
				table.insert(v_u_56, v63)
				local v_u_64 = (v_u_58 + v_u_5[v_u_57 % 4 + 1]).Unit
				p_u_6.add(p_u_20, p_u_6.bar(Vector3.new(0.34, 0.9, 0.34) * v_u_22, v_u_24, 0.05), function(_, p65)
					-- upvalues: (copy) v_u_53, (copy) v_u_64, (copy) v_u_22, (copy) v_u_57
					local v66 = v_u_53.cf
					local v67 = CFrame.new
					local v68 = v_u_64 * 3.7 * v_u_22
					local v69 = p65 * 1.7 + v_u_57
					return v66 * v67(v68 + Vector3.new(0, 1, 0) * (math.sin(v69) + 0.5) * 0.4 * v_u_22) * CFrame.Angles(0, p65 * 2 + v_u_57, 0.7853981633974483)
				end)
			end
			local v_u_70 = -1
			local v71 = p_u_20.ticks
			local function v74()
				-- upvalues: (ref) v_u_55, (ref) v_u_70, (copy) v_u_22, (copy) v_u_56
				if v_u_55 ~= v_u_70 then
					v_u_70 = v_u_55
					local v72 = (v_u_55 * 0.35 + 0.62) * v_u_22
					for _, v73 in v_u_56 do
						v73.Size = Vector3.new(1, 1, 1) * v72
					end
				end
			end
			table.insert(v71, v74)
			local v81 = p_u_6.group(p_u_20, function(p75, p76)
				-- upvalues: (copy) p_u_20, (copy) v_u_22, (ref) v_u_54
				local v77 = CFrame.new
				local v78 = p75.Position
				local v79 = p_u_20.headY + 1.3 * v_u_22
				local v80 = p76 * 1.8
				return v77(v78 + Vector3.new(0, 1, 0) * (v79 + math.sin(v80) * 0.05 * v_u_22)) * CFrame.Angles(0, v_u_54, 0)
			end)
			p_u_6.pin(p_u_20, v81, p_u_6.blob(Vector3.new(0.34, 0.16, 1.5) * v_u_22, v_u_23, 0), CFrame.new(0, 0, -0.75 * v_u_22))
			p_u_6.pin(p_u_20, v81, p_u_6.blob(Vector3.new(0.34, 0.16, 1.2) * v_u_22, v_u_24, 0), CFrame.new(0, 0, 0.6 * v_u_22))
			local v82 = p_u_6.ball(0.36 * v_u_22, v25, 0, v_u_7)
			p_u_6.pin(p_u_20, v81, v82, CFrame.identity)
			p_u_6.pin(p_u_20, v81, p_u_6.picture(2.6 * v_u_22, v_u_4.Ring, v_u_23, 0.3), CFrame.identity)
			local v83 = Instance.new("Attachment")
			v83.Parent = v82
			for _, v84 in v_u_56 do
				local v85 = Instance.new("Attachment")
				v85.Parent = v84
				p_u_6.ray(v85, v83, v_u_23, 0.08 * v_u_22, 0.03 * v_u_22).Transparency = NumberSequence.new(0.35, 0.75)
			end
			local v88 = p_u_6.group(p_u_20, function(p86, p87)
				-- upvalues: (copy) v_u_22
				return p86 * CFrame.new(0, 1 * v_u_22, 0.95 * v_u_22) * CFrame.Angles(0, 0, p87 * 0.3)
			end)
			p_u_6.pin(p_u_20, v88, p_u_6.picture(5 * v_u_22, v_u_4.Ring, v_u_24, 0.15), v_u_8)
			for _, v89 in { 0.7853981633974483, -0.7853981633974483 } do
				p_u_6.pin(p_u_20, v88, p_u_6.bar(Vector3.new(0.22, 5.2, 0.12) * v_u_22, v_u_24, 0.1), CFrame.new(0, 0, 0.05 * v_u_22) * CFrame.Angles(0, 0, v89))
			end
			p_u_6.pin(p_u_20, v88, p_u_6.picture(4.4 * v_u_22, v_u_4.VoidStar, v_u_23, 0), CFrame.new(0, 0, 0.12 * v_u_22) * v_u_8)
			p_u_6.particles(p_u_20, "AuraMode", v_u_24, {
				["rate"] = 0.45,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
			p_u_6.particles(p_u_20, "Petals", v_u_23, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end