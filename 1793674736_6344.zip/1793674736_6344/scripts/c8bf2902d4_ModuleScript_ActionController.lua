local v_u_1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserControlModuleEnabledAPI")
local v_u_2 = {}
v_u_2.__index = v_u_2
function v_u_2.new() -- name: new
	-- upvalues: (copy) v_u_2
	local v3 = v_u_2
	local v4 = setmetatable({}, v3)
	v4.enabled = true
	return v4
end
function v_u_2.initializeActions(p_u_5) -- name: initializeActions
	p_u_5.connectionUtil:trackConnection("SERVER_AUTHORITY_CHANGED", p_u_5.eventBus:subscribe("SERVER_AUTHORITY_CHANGED"):Connect(function()
		-- upvalues: (copy) p_u_5
		p_u_5.actions = {}
	end))
	if p_u_5.actions.MoveAction and p_u_5.actions.JumpAction then
		return
	elseif p_u_5.player then
		pcall(function()
			-- upvalues: (copy) p_u_5
			local v6 = script.Parent.Parent.InputContexts
			if p_u_5.isServerAuthority then
				v6 = p_u_5.player.InputContexts
			end
			local v7 = v6.CharacterContext
			p_u_5.actions = {
				["MoveAction"] = v7.MoveAction,
				["JumpAction"] = v7.JumpAction
			}
			p_u_5.eventBus:publish("ACTIONS_RELOADED")
		end)
	end
end
function v_u_2.update(p8) -- name: update
	-- upvalues: (copy) v_u_1
	if v_u_1 then
		if not (p8.actions.MoveAction and p8.actions.JumpAction) then
			return
		end
		local v9 = p8.playerModule.ControlModule
		p8.actions.MoveAction.Enabled = v9.Enabled
		p8.actions.JumpAction.Enabled = v9.Enabled
	end
	p8.moveVector = p8.actions.MoveAction:GetState()
	p8.isJumping = p8.actions.JumpAction:GetState()
end
function v_u_2.Enable(_, _) -- name: Enable end
return v_u_2