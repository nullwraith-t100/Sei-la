local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v_u_2.Shared.Config.Fuse)
local v_u_6 = require(v_u_2.Shared.Config.Pets)
local v_u_7 = require(v_u_2.Shared.Config.Release)
local v_u_8 = require(v_u_2.Shared.Config.Textures)
local v_u_9 = require(script.Parent.Perf)
local v_u_10 = {}
local v_u_11 = Color3.fromRGB
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_14 = v_u_3:IsStudio()
function v_u_10.enabled() -- name: enabled
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	return v_u_7.on(v_u_5.UPDATE)
end
local function v21(p15) -- name: seq
	local v16 = {}
	for v17, v18 in p15 do
		local v19 = ColorSequenceKeypoint.new
		local v20 = (v17 - 1) / (#p15 - 1)
		table.insert(v16, v19(v20, v18))
	end
	return ColorSequence.new(v16)
end
local function v_u_31(p22, p23, p24) -- name: rainbow
	local v25 = {}
	for v26 = 0, 9 do
		local v27 = (p22 + v26 / 9 * p23) % 1
		local v28 = ColorSequenceKeypoint.new
		local v29 = v26 / 9
		local v30 = Color3.fromHSV
		table.insert(v25, v28(v29, v30(v27, p24 or 0.75, 1)))
	end
	return ColorSequence.new(v25)
end
local v_u_32 = v_u_31(0, 1)
local v_u_33 = {
	{
		["body"] = nil,
		["low"] = nil,
		["high"] = nil,
		["lead"] = "B",
		["partDark"] = nil,
		["partLight"] = nil,
		["neonDark"] = nil,
		["neonLight"] = nil,
		["particles"] = nil,
		["flames"] = nil,
		["flameGlow"] = 0.05,
		["light"] = nil,
		["fill"] = nil,
		["fillTransparency"] = 0.7,
		["edge"] = nil,
		["edgeTransparency"] = 0.2,
		["tag"] = nil,
		["tagRotation"] = 90,
		["tagEdge"] = nil,
		["glow"] = nil,
		["body"] = v_u_11(74, 40, 135),
		["low"] = v_u_11(10, 8, 26),
		["high"] = v_u_11(104, 78, 185),
		["partDark"] = v_u_11(14, 8, 30),
		["partLight"] = v_u_11(130, 90, 225),
		["neonDark"] = v_u_11(120, 60, 255),
		["neonLight"] = v_u_11(225, 185, 255),
		["particles"] = v21({ v_u_11(225, 190, 255), v_u_11(150, 80, 255), v_u_11(80, 30, 190) }),
		["flames"] = v21({ v_u_11(110, 60, 200), v_u_11(55, 20, 120), v_u_11(20, 6, 45) }),
		["light"] = v_u_11(150, 90, 255),
		["fill"] = v_u_11(105, 45, 225),
		["edge"] = v_u_11(200, 140, 255),
		["tag"] = v21({
			v_u_11(240, 215, 255),
			v_u_11(185, 115, 255),
			v_u_11(120, 50, 235),
			v_u_11(85, 25, 190)
		}),
		["tagEdge"] = v_u_11(28, 6, 52),
		["glow"] = v_u_11(150, 80, 255)
	},
	{
		["body"] = nil,
		["low"] = nil,
		["high"] = nil,
		["partDark"] = nil,
		["partLight"] = nil,
		["neonDark"] = nil,
		["neonLight"] = nil,
		["particles"] = nil,
		["flames"] = nil,
		["flameGlow"] = 0.3,
		["light"] = nil,
		["fill"] = nil,
		["fillTransparency"] = 0.85,
		["edge"] = nil,
		["edgeTransparency"] = 0.15,
		["tag"] = nil,
		["tagRotation"] = 0,
		["tagEdge"] = nil,
		["glow"] = nil,
		["body"] = v_u_12,
		["low"] = v_u_12,
		["high"] = v_u_12,
		["partDark"] = v_u_11(60, 60, 70),
		["partLight"] = v_u_12,
		["neonDark"] = v_u_12,
		["neonLight"] = v_u_12,
		["particles"] = v_u_32,
		["flames"] = v_u_32,
		["light"] = v_u_11(190, 240, 255),
		["fill"] = v_u_11(255, 120, 200),
		["edge"] = v_u_12,
		["tag"] = v_u_32,
		["tagEdge"] = v_u_11(20, 14, 40),
		["glow"] = v_u_12
	},
	{
		["body"] = nil,
		["low"] = nil,
		["high"] = nil,
		["lead"] = "R",
		["partDark"] = nil,
		["partLight"] = nil,
		["neonDark"] = nil,
		["neonLight"] = nil,
		["particles"] = nil,
		["flames"] = nil,
		["flameGlow"] = 0.05,
		["light"] = nil,
		["fill"] = nil,
		["fillTransparency"] = 0.9,
		["edge"] = nil,
		["edgeTransparency"] = 0,
		["tag"] = nil,
		["tagRotation"] = 90,
		["tagEdge"] = nil,
		["glow"] = nil,
		["body"] = v_u_11(52, 16, 22),
		["low"] = v_u_11(6, 4, 6),
		["high"] = v_u_11(120, 40, 50),
		["partDark"] = v_u_11(8, 4, 6),
		["partLight"] = v_u_11(70, 42, 50),
		["neonDark"] = v_u_11(200, 0, 30),
		["neonLight"] = v_u_11(255, 95, 85),
		["particles"] = v21({ v_u_11(255, 120, 110), v_u_11(230, 20, 45), v_u_11(120, 0, 20) }),
		["flames"] = v21({ v_u_11(170, 12, 34), v_u_11(90, 0, 16), v_u_11(24, 0, 4) }),
		["light"] = v_u_11(255, 30, 50),
		["fill"] = v_u_11(40, 0, 8),
		["edge"] = v_u_11(255, 30, 55),
		["tag"] = v21({
			v_u_11(255, 110, 110),
			v_u_11(240, 20, 45),
			v_u_11(150, 0, 22),
			v_u_11(45, 0, 8)
		}),
		["tagEdge"] = v_u_11(14, 0, 2),
		["glow"] = v_u_11(220, 10, 40)
	}
}
function v_u_10.tag(p34) -- name: tag
	-- upvalues: (copy) v_u_33, (copy) v_u_12, (copy) v_u_5
	local v35 = v_u_33[p34]
	if v35 then
		return v_u_5.name(p34), v35.tag
	else
		return "", ColorSequence.new(v_u_12)
	end
end
local v_u_36 = {}
local v_u_37 = false
local function v_u_41(p38, p39, p40) -- name: numbers
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p38), NumberSequenceKeypoint.new(0.35, p39), NumberSequenceKeypoint.new(1, p40) })
end
for _, v42 in v_u_6.list do
	if v_u_36[v42.name] then
		continue
	end
	v_u_36[v42.name] = v42
end
local function v_u_73(p43, p44) -- name: multiplier
	local v45 = p43.R
	local v46 = p44.body.R
	local v47 = p44.low.R
	local v48 = p44.high.R
	local v49 = v46 / math.max(v45, 0.02)
	local v50 = math.clamp(v49, v47, v48)
	local v51 = p43.G
	local v52 = p44.body.G
	local v53 = p44.low.G
	local v54 = p44.high.G
	local v55 = v52 / math.max(v51, 0.02)
	local v56 = math.clamp(v55, v53, v54)
	local v57 = p43.B
	local v58 = p44.body.B
	local v59 = p44.low.B
	local v60 = p44.high.B
	local v61 = v58 / math.max(v57, 0.02)
	local v62 = math.clamp(v61, v59, v60)
	if p44.lead == "B" then
		local v63 = p43.B * v62
		local v64 = p43.R
		local v65 = v63 * (p44.body.R / p44.body.B) / math.max(v64, 0.02)
		v50 = math.min(v50, v65)
		local v66 = p43.G
		local v67 = v63 * (p44.body.G / p44.body.B) / math.max(v66, 0.02)
		v56 = math.min(v56, v67)
	elseif p44.lead == "R" then
		local v68 = p43.R * v50
		local v69 = p43.G
		local v70 = v68 * (p44.body.G / p44.body.R) / math.max(v69, 0.02)
		v56 = math.min(v56, v70)
		local v71 = p43.B
		local v72 = v68 * (p44.body.B / p44.body.R) / math.max(v71, 0.02)
		v62 = math.min(v62, v72)
	end
	return Color3.new(v50, v56, v62)
end
local function v_u_81(p74, p75) -- name: baseColor
	-- upvalues: (copy) v_u_11
	if p74 then
		local v76 = p74.look
		local v77 = v76.body
		if string.find(p75, "^Wing") and (v76.wings and v76.wings[1]) then
			v77 = v76.wings[1]
		elseif (string.find(p75, "^Leg") or string.find(p75, "^Ear")) and v76.limbs then
			v77 = v76.limbs
		end
		local v78 = Color3.fromHex
		local v79, v80 = pcall(v78, v77)
		if v79 then
			return v80
		else
			return v_u_11(200, 200, 200)
		end
	else
		return v_u_11(200, 200, 200)
	end
end
local v_u_82 = {}
local v_u_83 = {}
local v_u_84 = {}
local v_u_85 = nil
local v_u_86 = {}
local v_u_87 = nil
local function v_u_89() -- name: startLoop
	-- upvalues: (ref) v_u_85, (copy) v_u_3, (ref) v_u_87
	if not v_u_85 and (v_u_3:IsRunning() and v_u_3:IsClient()) then
		v_u_85 = v_u_3.RenderStepped:Connect(function(p88)
			-- upvalues: (ref) v_u_87
			v_u_87(p88)
		end)
	end
end
local function v_u_93() -- name: stopLoopIfIdle
	-- upvalues: (ref) v_u_85, (copy) v_u_82, (copy) v_u_83, (copy) v_u_84, (copy) v_u_86
	if v_u_85 then
		local v90 = 0
		for _ in v_u_82 do
			v90 = v90 + 1
		end
		for _ in v_u_83 do
			v90 = v90 + 1
		end
		for _ in v_u_84 do
			v90 = v90 + 1
		end
		if v90 == 0 then
			v_u_85:Disconnect()
			v_u_85 = nil
			for _, v91 in v_u_86 do
				for _, v92 in v91 do
					v92:Destroy()
				end
			end
			table.clear(v_u_86)
		end
	end
end
local function v_u_98(p94, p95) -- name: template
	-- upvalues: (copy) v_u_2
	local v96 = v_u_2:FindFirstChild("Fx")
	if v96 then
		v96 = v96:FindFirstChild(p94)
	end
	if v96 then
		v96 = v96:FindFirstChild(p95)
	end
	if not (v96 and v96:IsA("ParticleEmitter")) then
		return nil
	end
	local v97 = v96:Clone()
	v97.Name = "Tier" .. p95
	v97.Enabled = true
	return v97
end
local v_u_99 = {
	["Body"] = {
		[Enum.NormalId.Left] = 0,
		[Enum.NormalId.Right] = 0,
		[Enum.NormalId.Top] = 0,
		[Enum.NormalId.Front] = 0
	},
	["Head"] = {
		[Enum.NormalId.Left] = 0,
		[Enum.NormalId.Right] = 0,
		[Enum.NormalId.Top] = 0,
		[Enum.NormalId.Front] = 0.35
	}
}
local v_u_100 = Color3.new(4, 0.36, 0.44)
local function v_u_120(p101, p102) -- name: collect
	-- upvalues: (copy) v_u_81
	local v103 = p101:GetPivot()
	local v104 = {}
	local v105 = (1 / 0)
	local v106 = (-1 / 0)
	local v107 = {}
	for _, v108 in p101:GetDescendants() do
		if not v108:IsA("BasePart") or v108.Transparency >= 0.95 then
			continue
		end
		local v109 = v103:PointToObjectSpace(v108.Position).Y
		v104[v108] = v109
		v105 = math.min(v105, v109)
		v106 = math.max(v106, v109)
	end
	local v110 = v106 - v105
	local v111 = math.max(v110, 0.1)
	for v112, v113 in v104 do
		local v114 = v112.Material == Enum.Material.Neon
		local v115 = v112:IsA("MeshPart")
		if v115 then
			v115 = v112.MeshId ~= ""
		end
		local v116 = {
			["part"] = v112,
			["neon"] = v114,
			["mesh"] = v115,
			["original"] = v112.Color
		}
		local v117 = v_u_81
		local v118 = v112:GetAttribute("Bone")
		if type(v118) ~= "string" then
			v118 = string.match(v112.Name, "^(.-)__") or v112.Name
		end
		v116.base = v117(p102, v118)
		local v119 = (v113 - v105) / v111
		v116.height = math.clamp(v119, 0, 1)
		table.insert(v107, v116)
	end
	return v107
end
local function v_u_137(p121, p122, p123, p124) -- name: paint
	-- upvalues: (copy) v_u_73
	local v125 = p121.part
	if p121.part.Transparency > 0 and not p121.neon then
		return
	elseif p123 == 2 then
		local v126 = ((p124 or 0) + p121.height * 0.7) % 1
		if p121.neon or p121.mesh then
			v125.Color = Color3.fromHSV(v126, 0.8, 1)
		else
			local v127 = Color3.fromHSV
			local v128 = p121.original
			v125.Color = v127(v126, 0.75, (v128.R * 0.3 + v128.G * 0.59 + v128.B * 0.11) * 0.55 + 0.45)
		end
	elseif p121.neon then
		local v129 = p122.neonDark
		local v130 = p122.neonLight
		local v131 = p121.original
		local v132 = v131.R * 0.3 + v131.G * 0.59 + v131.B * 0.11
		v125.Color = v129:Lerp(v130, (math.clamp(v132, 0, 1)))
		return
	elseif p121.mesh then
		v125.Color = v_u_73(p121.base, p122)
	else
		local v133 = p122.partDark
		local v134 = p122.partLight
		local v135 = p121.original
		local v136 = v135.R * 0.3 + v135.G * 0.59 + v135.B * 0.11
		v125.Color = v133:Lerp(v134, math.clamp(v136, 0, 1) ^ 0.8)
	end
end
local function v_u_146(p138, p139, p140) -- name: holder
	-- upvalues: (copy) v_u_86, (copy) v_u_33, (copy) v_u_11
	local v141 = v_u_86[p138]
	if not v141 then
		v141 = {}
		v_u_86[p138] = v141
	end
	local v142 = v141[p139]
	if v142 and v142.Parent == p138 then
		return v142
	end
	local v143 = v_u_33[p140]
	local v144 = Instance.new("Model")
	v144.Name = "PetTier_" .. p139
	local v145 = Instance.new("Highlight")
	v145.DepthMode = Enum.HighlightDepthMode.Occluded
	if p139 == "glitch" then
		v145.FillColor = v_u_11(120, 255, 250)
		v145.FillTransparency = 0.68
		v145.OutlineColor = v_u_11(80, 255, 255)
		v145.OutlineTransparency = 0
	else
		v145.FillColor = v143.fill
		v145.FillTransparency = v143.fillTransparency
		v145.OutlineColor = v143.edge
		v145.OutlineTransparency = v143.edgeTransparency
	end
	v145.Parent = v144
	v144.Parent = p138
	v141[p139] = v144
	return v144
end
local function v_u_152(p147) -- name: layer
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_146
	local v148 = p147.model
	local v149 = v148.Parent
	if v149 and (v148:IsDescendantOf(v_u_4) and v_u_9.level() >= 2) then
		if v149.Name ~= "PetTier_" .. p147.tier and v149.Name ~= "PetTier_glitch" then
			local v150 = v_u_146
			local v151 = p147.tier
			v148.Parent = v150(v149, tostring(v151), p147.tier)
		end
	else
		return
	end
end
local function v_u_197(p153, p154) -- name: addEffects
	-- upvalues: (copy) v_u_9, (copy) v_u_98, (copy) v_u_41, (copy) v_u_8, (copy) v_u_32
	local v155 = p153.model
	local v156 = v155.PrimaryPart
	if v156 then
		local v157 = p153.scale
		local v158 = p153.tier
		local v159 = v_u_9.level()
		local v160 = v_u_9.formRate()
		local v161 = v155:FindFirstChild("Head")
		if v161 then
			if not v161:IsA("BasePart") then
				v161 = v156
			end
		else
			v161 = v156
		end
		local v162 = false
		local v163 = false
		for _, v164 in v155:GetDescendants() do
			if v164:IsA("ParticleEmitter") then
				local v165 = p153.recolored
				local v166 = {
					["emitter"] = v164,
					["color"] = v164.Color,
					["glow"] = v164.LightEmission
				}
				table.insert(v165, v166)
			elseif v164:IsA("PointLight") then
				local v167 = p153.recolored
				local v168 = {
					["light"] = v164,
					["lightColor"] = v164.Color
				}
				table.insert(v167, v168)
			end
			if v164:IsA("ParticleEmitter") then
				if v164.Name == "FlameBack" then
					v164.Color = p154.flames
					v164.LightEmission = p154.flameGlow
					v162 = true
				else
					v163 = v164.Name == "Stars" and true or v163
					v164.Color = p154.particles
				end
			else
				if not v164:IsA("PointLight") then
					continue
				end
				p153.light = v164
				v164.Color = p154.light
			end
		end
		if v159 > 1 then
			if v158 == 1 then
				if not v162 then
					local v169 = v_u_98("FireDark", "Flames")
					if v169 then
						v169.Rate = 5 * v160
						v169.Shape = Enum.ParticleEmitterShape.Box
						v169.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
						v169.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
						v169.Parent = v156
						local v170 = p153.added
						table.insert(v170, v169)
					else
						v169 = nil
					end
					if v169 then
						v169.Color = p154.flames
						v169.LightEmission = 0
						v169.Size = v_u_41(v157 * 0.9, v157 * 0.7, 0)
						v169.Lifetime = NumberRange.new(0.5, 0.8)
						v169.Speed = NumberRange.new(v157 * 1, v157 * 1.8)
						v169.EmissionDirection = Enum.NormalId.Top
						v169.SpreadAngle = Vector2.new(15, 15)
						local v171 = v157 * 1.5
						v169.Acceleration = Vector3.new(0, v171, 0)
						v169.Transparency = v_u_41(0.35, 0.45, 1)
					end
				end
				local v172 = v_u_98("Petals", "Motes")
				if v172 then
					v172.Rate = 4 * v160
					v172.Shape = Enum.ParticleEmitterShape.Box
					v172.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
					v172.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
					v172.Parent = v161
					local v173 = p153.added
					table.insert(v173, v172)
				else
					v172 = nil
				end
				if v172 then
					v172.Color = p154.particles
					v172.LightEmission = 0.6
					v172.Size = v_u_41(v157 * 0.32, v157 * 0.26, 0)
					v172.Lifetime = NumberRange.new(0.9, 1.4)
					v172.Speed = NumberRange.new(v157 * 0.4, v157 * 1)
					v172.EmissionDirection = Enum.NormalId.Top
					v172.SpreadAngle = Vector2.new(60, 60)
					local v174 = v157 * 0.8
					v172.Acceleration = Vector3.new(0, v174, 0)
				end
			elseif v158 == 2 then
				if not v163 then
					local v175 = v_u_98("Sparkle", "Stars")
					if v175 then
						v175.Rate = 4 * v160
						v175.Shape = Enum.ParticleEmitterShape.Box
						v175.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
						v175.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
						v175.Parent = v161
						local v176 = p153.added
						table.insert(v176, v175)
					else
						v175 = nil
					end
					if v175 then
						v175.Texture = v_u_8.PetStar
						v175.FlipbookLayout = Enum.ParticleFlipbookLayout.None
						v175.Color = v_u_32
						v175.LightEmission = 0.35
						v175.Size = v_u_41(0, v157 * 0.6, 0)
						v175.Lifetime = NumberRange.new(0.7, 1.1)
						v175.Speed = NumberRange.new(v157 * 0.3, v157 * 0.8)
						v175.SpreadAngle = Vector2.new(180, 180)
						v175.Rotation = NumberRange.new(-30, 30)
						v175.RotSpeed = NumberRange.new(-90, 90)
						local v177 = v157 * 0.6
						v175.Acceleration = Vector3.new(0, v177, 0)
						v175.Drag = 0
					end
				end
				local _, v178 = v155:GetBoundingBox()
				local v179 = Instance.new("Attachment")
				v179.Name = "TierStreakTop"
				local v180 = v178.Y * 0.3
				local v181 = v156.Size.Y * 0.5
				local v182 = math.min(v180, v181)
				v179.Position = Vector3.new(0, v182, 0)
				v179.Parent = v156
				local v183 = Instance.new("Attachment")
				v183.Name = "TierStreakLow"
				local v184 = -v156.Size.Y * 0.35
				v183.Position = Vector3.new(0, v184, 0)
				v183.Parent = v156
				local v185 = Instance.new("Trail")
				v185.Name = "TierStreak"
				v185.Attachment0 = v179
				v185.Attachment1 = v183
				v185.Color = v_u_32
				v185.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(1, 1) })
				v185.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.2) })
				v185.Lifetime = 0.35
				v185.MinLength = 0.15
				v185.LightEmission = 0.5
				v185.FaceCamera = true
				v185.Parent = v156
				for _, v186 in { v179, v183, v185 } do
					local v187 = p153.added
					table.insert(v187, v186)
				end
			elseif v158 == 3 then
				if not v162 then
					local v188 = v_u_98("FireDark", "Edges")
					if v188 then
						v188.Rate = 4 * v160
						v188.Shape = Enum.ParticleEmitterShape.Box
						v188.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
						v188.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
						v188.Parent = v156
						local v189 = p153.added
						table.insert(v189, v188)
					else
						v188 = nil
					end
					if v188 then
						v188.Color = p154.flames
						v188.LightEmission = 0.1
						v188.Size = v_u_41(v157 * 0.9, v157 * 0.75, v157 * 0.1)
						v188.Lifetime = NumberRange.new(0.45, 0.7)
						v188.Speed = NumberRange.new(v157 * 1.2, v157 * 2)
						v188.EmissionDirection = Enum.NormalId.Top
						v188.SpreadAngle = Vector2.new(15, 15)
					end
				end
				local v190 = v_u_98("FireDark", "Embers")
				if v190 then
					v190.Rate = 4 * v160
					v190.Shape = Enum.ParticleEmitterShape.Box
					v190.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
					v190.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
					v190.Parent = v161
					local v191 = p153.added
					table.insert(v191, v190)
				else
					v190 = nil
				end
				if v190 then
					v190.Color = p154.particles
					v190.LightEmission = 0.5
					v190.Size = v_u_41(v157 * 0.3, v157 * 0.25, 0)
					v190.Lifetime = NumberRange.new(0.7, 1.1)
					v190.Speed = NumberRange.new(v157 * 0.6, v157 * 1.3)
					v190.EmissionDirection = Enum.NormalId.Top
					v190.SpreadAngle = Vector2.new(35, 35)
					local v192 = v157 * 1
					v190.Acceleration = Vector3.new(0, v192, 0)
				end
				local v193 = v_u_98("Lightning", "Arcs")
				if v193 then
					v193.Enabled = false
					v193.Color = p154.particles
					v193.LightEmission = 0.6
					v193.Size = v_u_41(v157 * 0.7, v157 * 0.6, 0)
					v193.Lifetime = NumberRange.new(0.12, 0.2)
					v193.Speed = NumberRange.new(0, v157 * 0.5)
					v193.Shape = Enum.ParticleEmitterShape.Box
					v193.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
					v193.ShapeInOut = Enum.ParticleEmitterShapeInOut.Outward
					v193.Parent = v156
					local v194 = p153.added
					table.insert(v194, v193)
					p153.statics = v193
				end
			end
			if not p153.light and v159 >= 3 then
				local v195 = Instance.new("PointLight")
				v195.Name = "TierLight"
				v195.Shadows = false
				v195.Color = p154.light
				v195.Range = 5.5
				v195.Brightness = v158 == 1 and 0.8 or 0.9
				v195.Parent = v156
				local v196 = p153.added
				table.insert(v196, v195)
				p153.light = v195
			end
		end
	else
		return
	end
end
local function v_u_210(p198) -- name: addCracks
	-- upvalues: (copy) v_u_8, (copy) v_u_99, (copy) v_u_100
	local v199 = v_u_8.CrackLines
	for _, v200 in p198.pieces do
		local v201 = v200.part
		if v200.neon or v201.Transparency > 0 then
			continue
		end
		local v202 = v_u_99
		local v203 = v201:GetAttribute("Bone")
		if type(v203) ~= "string" then
			v203 = string.match(v201.Name, "^(.-)__") or v201.Name
		end
		local v204 = v202[v203]
		if not v204 then
			continue
		end
		for v205, v206 in v204 do
			local v207 = Instance.new("Decal")
			v207.Name = "TierCrack"
			v207.Texture = v199
			v207.Face = v205
			v207.Color3 = v_u_100
			v207.Transparency = v206
			v207:SetAttribute("Fade", v206)
			v207.Parent = v201
			local v208 = p198.cracks
			table.insert(v208, v207)
			local v209 = p198.added
			table.insert(v209, v207)
		end
	end
end
local function v_u_220(p211) -- name: undo
	-- upvalues: (copy) v_u_82, (copy) v_u_93
	for _, v212 in p211.pieces do
		v212.part.Color = v212.original
		v212.part.LocalTransparencyModifier = 0
	end
	for _, v213 in p211.added do
		v213:Destroy()
	end
	for _, v214 in p211.recolored do
		if v214.emitter and (v214.color and v214.glow) then
			v214.emitter.Color = v214.color
			v214.emitter.LightEmission = v214.glow
		else
			if not (v214.light and v214.lightColor) then
				continue
			end
			v214.light.Color = v214.lightColor
		end
	end
	local v215 = p211.model.Parent
	if v215 then
		local v216 = v215.Name
		if string.sub(v216, 1, 8) == "PetTier_" and v215.Parent then
			p211.model.Parent = v215.Parent
		end
	end
	local v217 = p211.model
	local v218 = v_u_82[v217]
	if v218 then
		v_u_82[v217] = nil
		for _, v219 in v218.conns do
			v219:Disconnect()
		end
		v_u_93()
	end
end
function v_u_10.apply(p_u_221, p222, p223) -- name: apply
	-- upvalues: (copy) v_u_82, (copy) v_u_220, (copy) v_u_33, (copy) v_u_10, (copy) v_u_6, (copy) v_u_36, (copy) v_u_120, (copy) v_u_137, (copy) v_u_210, (copy) v_u_197, (copy) v_u_93, (copy) v_u_152, (copy) v_u_89
	local v224 = v_u_82[p_u_221]
	if v224 then
		v_u_220(v224)
	end
	local v225 = v_u_33[p222]
	if v225 and v_u_10.enabled() then
		if p223 == nil then
			p223 = p_u_221:FindFirstChildWhichIsA("Motor6D", true) ~= nil
		end
		local v226 = p_u_221:GetAttribute("Kind")
		local v227
		if type(v226) == "string" and v_u_6.byId[v226] then
			v227 = v_u_6.byId[v226]
		else
			v227 = v_u_36[p_u_221.Name]
		end
		local v228 = p_u_221:GetAttribute("Scale")
		local v_u_229 = {
			["model"] = nil,
			["tier"] = nil,
			["world"] = nil,
			["scale"] = nil,
			["pieces"] = nil,
			["added"] = nil,
			["recolored"] = nil,
			["light"] = nil,
			["statics"] = nil,
			["cracks"] = nil,
			["nextAt"] = 0,
			["view"] = nil,
			["viewSeenAt"] = (-1 / 0),
			["viewShown"] = false,
			["glitchAt"] = nil,
			["glitchUntil"] = 0,
			["glitchOffset"] = nil,
			["conns"] = nil,
			["model"] = p_u_221,
			["tier"] = p222,
			["world"] = p223,
			["scale"] = type(v228) ~= "number" and 1 or v228,
			["pieces"] = v_u_120(p_u_221, v227),
			["added"] = {},
			["recolored"] = {},
			["cracks"] = {},
			["glitchAt"] = os.clock() + 1 + math.random() * 3,
			["conns"] = {}
		}
		for _, v230 in v_u_229.pieces do
			v_u_137(v230, v225, p222, 0)
		end
		if p222 == 3 then
			v_u_210(v_u_229)
		end
		if p223 then
			v_u_197(v_u_229, v225)
		end
		v_u_82[p_u_221] = v_u_229
		local v231 = v_u_229.conns
		local v232 = p_u_221.Destroying
		local function v236()
			-- upvalues: (copy) p_u_221, (ref) v_u_82, (ref) v_u_93
			local v233 = p_u_221
			local v234 = v_u_82[v233]
			if v234 then
				v_u_82[v233] = nil
				for _, v235 in v234.conns do
					v235:Disconnect()
				end
				v_u_93()
			end
		end
		table.insert(v231, v232:Connect(v236))
		if p223 then
			local v237 = v_u_229.conns
			local v238 = p_u_221.AncestryChanged
			local function v239()
				-- upvalues: (ref) v_u_82, (copy) p_u_221, (copy) v_u_229, (ref) v_u_152
				task.defer(function()
					-- upvalues: (ref) v_u_82, (ref) p_u_221, (ref) v_u_229, (ref) v_u_152
					if v_u_82[p_u_221] == v_u_229 then
						v_u_152(v_u_229)
					end
				end)
			end
			table.insert(v237, v238:Connect(v239))
			v_u_152(v_u_229)
		end
		v_u_89()
	end
end
function v_u_10.jitter(p240) -- name: jitter
	-- upvalues: (copy) v_u_82
	local v241 = v_u_82[p240]
	if v241 then
		return v241.glitchOffset
	else
		return nil
	end
end
function v_u_10.tagLabel(p242) -- name: tagLabel
	-- upvalues: (copy) v_u_33, (copy) v_u_10, (copy) v_u_5, (copy) v_u_13, (copy) v_u_11, (copy) v_u_12, (copy) v_u_83, (copy) v_u_93, (copy) v_u_89
	local v243 = v_u_33[p242]
	if not (v243 and v_u_10.enabled()) then
		return nil
	end
	local v_u_244 = v_u_5.name(p242)
	local v_u_245 = Instance.new("Frame")
	v_u_245.Name = "TierTag"
	v_u_245.BackgroundTransparency = 1
	v_u_245.Size = UDim2.fromScale(1, 1)
	local v246 = {}
	local function v250(p247, p248) -- name: word
		-- upvalues: (ref) v_u_13, (copy) v_u_244, (copy) v_u_245
		local v249 = Instance.new("TextLabel")
		v249.Name = p247
		v249.BackgroundTransparency = 1
		v249.AnchorPoint = Vector2.new(0.5, 0.5)
		v249.Position = UDim2.fromScale(0.5, 0.5)
		v249.Size = UDim2.fromScale(1, 1)
		v249.FontFace = v_u_13
		v249.TextScaled = true
		v249.Text = v_u_244
		v249.TextColor3 = p248
		v249.Parent = v_u_245
		return v249
	end
	if p242 == 3 then
		for _, v251 in { v_u_11(0, 255, 240), v_u_11(255, 0, 40) } do
			local v252 = v250("Split", v251)
			v252.TextTransparency = 1
			table.insert(v246, v252)
		end
	end
	local v253 = v250("Text", v_u_12)
	local v254 = Instance.new("UIStroke")
	v254.Color = v243.tagEdge
	v254.Thickness = 0.12
	v254.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v254.LineJoinMode = Enum.LineJoinMode.Round
	v254.Parent = v253
	local v255 = Instance.new("UIGradient")
	v255.Color = v243.tag
	v255.Rotation = v243.tagRotation
	v255.Parent = v253
	if p242 == 2 or p242 == 3 then
		v_u_83[v_u_245] = {
			["frame"] = nil,
			["text"] = nil,
			["paint"] = nil,
			["ghosts"] = nil,
			["tier"] = nil,
			["nextAt"] = 0,
			["seenAt"] = (-1 / 0),
			["shown"] = false,
			["glitchAt"] = nil,
			["glitchUntil"] = 0,
			["frame"] = v_u_245,
			["text"] = v253,
			["paint"] = v255,
			["ghosts"] = v246,
			["tier"] = p242,
			["glitchAt"] = os.clock() + 1 + math.random() * 2
		}
		v_u_245.Destroying:Connect(function()
			-- upvalues: (ref) v_u_83, (copy) v_u_245, (ref) v_u_93
			v_u_83[v_u_245] = nil
			v_u_93()
		end)
		v_u_89()
	end
	return v_u_245
end
function v_u_10.badge(p256, p257) -- name: badge
	-- upvalues: (copy) v_u_10
	local v258 = p256:FindFirstChild("TierTag")
	if v258 then
		v258:Destroy()
	end
	local v259 = v_u_10.tagLabel(p257)
	if not v259 then
		return nil
	end
	local v260 = p257 == 3 and 0.86 or (p257 == 2 and 0.76 or 0.5)
	v259.AnchorPoint = Vector2.new(0, 0)
	v259.Position = UDim2.fromScale(0.04, 0.03)
	v259.Size = UDim2.fromScale(v260, 0.2)
	v259.Rotation = -6
	v259.ZIndex = 8
	for _, v261 in v259:GetDescendants() do
		if not v261:IsA("GuiObject") then
			continue
		end
		v261.ZIndex = 8
	end
	v259.Parent = p256
	return v259
end
function v_u_10.backdrop(p262, p263) -- name: backdrop
	-- upvalues: (copy) v_u_33, (copy) v_u_10, (copy) v_u_32, (copy) v_u_84, (copy) v_u_93, (copy) v_u_89
	local v264 = p262.Parent
	if not v264 then
		return nil
	end
	local v265 = "TierGlow_" .. p262.Name
	local v266 = v264:FindFirstChild(v265)
	if v266 then
		v266:Destroy()
	end
	local v267 = v_u_33[p263]
	if not (v267 and v_u_10.enabled()) then
		return nil
	end
	local v_u_268 = Instance.new("ImageLabel")
	v_u_268.Name = v265
	v_u_268.BackgroundTransparency = 1
	v_u_268.Image = "rbxassetid://96427887277553"
	v_u_268.ImageColor3 = v267.glow
	v_u_268.ImageTransparency = 0.35
	v_u_268.ScaleType = Enum.ScaleType.Fit
	v_u_268.AnchorPoint = p262.AnchorPoint
	v_u_268.Position = p262.Position
	v_u_268.Size = p262.Size
	local v269 = p262.ZIndex - 1
	v_u_268.ZIndex = math.max(1, v269)
	local v270
	if p263 == 2 then
		v270 = Instance.new("UIGradient")
		v270.Color = v_u_32
		v270.Parent = v_u_268
	else
		v270 = nil
	end
	v_u_268.Parent = v264
	v_u_84[v_u_268] = {
		["image"] = nil,
		["paint"] = nil,
		["tier"] = nil,
		["seenAt"] = (-1 / 0),
		["shown"] = false,
		["image"] = v_u_268,
		["paint"] = v270,
		["tier"] = p263
	}
	v_u_268.Destroying:Connect(function()
		-- upvalues: (ref) v_u_84, (copy) v_u_268, (ref) v_u_93
		v_u_84[v_u_268] = nil
		v_u_93()
	end)
	v_u_89()
	return v_u_268
end
local function v_u_273(p271) -- name: guiShown
	-- upvalues: (copy) v_u_1
	while p271 do
		if p271:IsA("GuiObject") then
			if not p271.Visible then
				return false
			end
		elseif p271:IsA("LayerCollector") then
			local v272 = p271.Enabled
			if v272 then
				v272 = p271:IsDescendantOf(v_u_1.LocalPlayer or game)
			end
			return v272
		end
		p271 = p271.Parent
	end
	return false
end
local function v_u_284(p274, p275) -- name: endGlitch
	-- upvalues: (copy) v_u_137, (copy) v_u_146
	p274.glitchOffset = nil
	p274.glitchUntil = 0
	for _, v276 in p274.pieces do
		v276.part.LocalTransparencyModifier = 0
		v_u_137(v276, p275, p274.tier, 0)
	end
	for _, v277 in p274.cracks do
		local v278 = v277:GetAttribute("Fade")
		v277.Transparency = type(v278) ~= "number" and 0 or v278
	end
	local v279 = p274.model
	local v280 = v279.Parent
	if v280 and (v280.Name == "PetTier_glitch" and v280.Parent) then
		local v281 = v_u_146
		local v282 = v280.Parent
		local v283 = p274.tier
		v279.Parent = v281(v282, tostring(v283), p274.tier)
	end
end
local function v_u_295(p285, p286) -- name: glitchFrame
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	local v287 = p285.scale
	local v288 = p286 * 6
	local v289 = math.floor(v288) % 2 == 0
	if p285.world then
		p285.glitchOffset = CFrame.new((v289 and 0.22 or -0.16) * v287, (math.random() - 0.5) * 0.12 * v287, 0)
	end
	for _, v290 in p285.pieces do
		local v291 = v290.part
		if v290.neon then
			local v292
			if v289 then
				v292 = v_u_11(120, 255, 250)
			else
				v292 = v_u_12
			end
			v291.Color = v292
		elseif v289 then
			v291.LocalTransparencyModifier = p285.world and 0.45 or 0
			if not v290.mesh then
				continue
			end
			v291.Color = v_u_11(150, 30, 50)
		else
			v291.LocalTransparencyModifier = 0
			local v293
			if v290.mesh then
				v293 = v_u_11(30, 90, 100)
			else
				v293 = v291.Color
			end
			v291.Color = v293
		end
	end
	for _, v294 in p285.cracks do
		v294.Transparency = v289 and 0 or 0.6
	end
end
local function v_u_300(p296, p297) -- name: startGlitch
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_146
	p296.glitchUntil = p297 + 0.2 + math.random() * 0.08
	p296.glitchAt = p297 + 2.6 + math.random() * 2
	if p296.statics then
		p296.statics:Emit(3)
	end
	local v298 = p296.model
	if p296.world and (v298.Parent and (v298:IsDescendantOf(v_u_4) and v_u_9.level() >= 2)) then
		local v299 = v298.Parent
		if v299 and (v299.Name == "PetTier_" .. p296.tier and v299.Parent) then
			v298.Parent = v_u_146(v299.Parent, "glitch", 3)
		end
	end
end
local function v_u_319(p301, p302, p303, p304) -- name: stepEntry
	-- upvalues: (copy) v_u_33, (copy) v_u_284, (copy) v_u_9, (copy) v_u_273, (ref) v_u_37, (copy) v_u_300, (copy) v_u_295
	local v305 = v_u_33[p301.tier]
	local v306 = p301.model
	if p301.world then
		local v307 = v306.PrimaryPart
		if not (v307 and p304) then
			return
		end
		local v308 = (v307.Position - p303).Magnitude
		local _, v309 = p304:WorldToViewportPoint(v307.Position)
		if not v309 or v308 > 220 then
			if p301.glitchUntil > 0 then
				v_u_284(p301, v305)
			end
			p301.nextAt = p302 + 0.25
			return
		end
		if p301.glitchUntil == 0 and p302 < p301.nextAt then
			return
		end
		p301.nextAt = p302 + v_u_9.frameGap(v308)
	else
		if p302 < p301.nextAt then
			return
		end
		p301.nextAt = p302 + 0.1
		if p302 - p301.viewSeenAt > 0.5 then
			p301.viewSeenAt = p302
			local v310 = p301.view or v306:FindFirstAncestorWhichIsA("ViewportFrame")
			p301.view = v310
			local v311 = v310 ~= nil and v_u_273(v310)
			if v311 then
				v311 = p301.tier ~= 2 and true or v310.AbsoluteSize.X >= 130
			end
			p301.viewShown = v311
		end
		if not p301.viewShown then
			return
		end
	end
	if p301.tier == 2 then
		local v312 = p302 * 0.22 % 1
		for _, v313 in p301.pieces do
			local v314 = -v312
			local v315 = v313.part
			if v313.part.Transparency > 0 and not v313.neon then
				continue
			end
			local v316 = ((v314 or 0) + v313.height * 0.7) % 1
			if v313.neon or v313.mesh then
				v315.Color = Color3.fromHSV(v316, 0.8, 1)
			else
				local v317 = Color3.fromHSV
				local v318 = v313.original
				v315.Color = v317(v316, 0.75, (v318.R * 0.3 + v318.G * 0.59 + v318.B * 0.11) * 0.55 + 0.45)
			end
		end
		if p301.light then
			p301.light.Color = Color3.fromHSV(v312, 0.45, 1)
			return
		end
	elseif p301.tier == 3 then
		if v_u_37 then
			if p301.glitchUntil == 0 then
				v_u_300(p301, p302)
			end
			p301.glitchUntil = p302 + 0.25
			v_u_295(p301, p302 * 2 % 1)
			return
		end
		if p301.glitchUntil > 0 then
			if p301.glitchUntil <= p302 then
				v_u_284(p301, v305)
			else
				v_u_295(p301, 1 - (p301.glitchUntil - p302) / 0.25)
			end
		end
		if p301.glitchAt <= p302 then
			v_u_300(p301, p302)
			v_u_295(p301, 0)
		end
	end
end
local function v_u_327(p320, p321) -- name: stepTag
	-- upvalues: (copy) v_u_273, (copy) v_u_31, (ref) v_u_37
	if p321 - p320.seenAt > 0.5 then
		p320.seenAt = p321
		p320.shown = v_u_273(p320.frame)
	end
	if p320.shown and p321 >= p320.nextAt then
		p320.nextAt = p321 + 0.05
		if p320.tier == 2 then
			p320.paint.Color = v_u_31(-p321 * 0.35 % 1, 1)
		else
			local v322 = p320.text
			if p320.glitchUntil > 0 and p320.glitchUntil <= p321 then
				p320.glitchUntil = 0
				v322.Position = UDim2.fromScale(0.5, 0.5)
				for _, v323 in p320.ghosts do
					v323.TextTransparency = 1
				end
			elseif v_u_37 or p320.glitchUntil == 0 and p320.glitchAt <= p321 then
				p320.glitchUntil = p321 + 0.16
				p320.glitchAt = p321 + 1.8 + math.random() * 1.6
			end
			if p320.glitchUntil > 0 then
				local v324 = (math.random() - 0.5) * 0.08
				v322.Position = UDim2.fromScale(0.5 + v324, 0.5)
				for v325, v326 in p320.ghosts do
					v326.TextTransparency = 0.25
					v326.Position = UDim2.fromScale((v325 == 1 and -0.035 or 0.035) + 0.5, 0.5 + v324 * 0.5)
				end
			end
		end
	else
		return
	end
end
local function v_u_333(p328, p329) -- name: stepGlow
	-- upvalues: (copy) v_u_273
	if p329 - p328.seenAt > 0.5 then
		p328.seenAt = p329
		p328.shown = v_u_273(p328.image)
	end
	if p328.shown then
		p328.image.Rotation = p329 * 18 % 360
		if p328.paint then
			p328.paint.Rotation = -p329 * 60 % 360
		elseif p328.tier == 3 then
			local v330 = math.random() < 0.03 and 0.5 or 0
			local v331 = p328.image
			local v332 = p329 * 3
			v331.ImageTransparency = (math.sin(v332) * 0.5 + 0.5) * 0.2 + 0.25 + v330
		end
	else
		return
	end
end
v_u_87 = function(_)
	-- upvalues: (copy) v_u_1, (ref) v_u_37, (copy) v_u_14, (copy) v_u_4, (copy) v_u_33, (copy) v_u_86, (copy) v_u_82, (copy) v_u_319, (copy) v_u_83, (copy) v_u_327, (copy) v_u_84, (copy) v_u_333
	local v334 = os.clock()
	local v335 = v_u_1.LocalPlayer
	local v336 = v_u_14
	if v336 then
		if v335 == nil then
			v336 = false
		else
			v336 = v335:GetAttribute("DevPetGlitch") == true
		end
	end
	v_u_37 = v336
	local v337 = v_u_4.CurrentCamera
	local v338 = not v337 and Vector3.new(0, 0, 0) or v337.CFrame.Position
	local v339 = v334 * 0.22 % 1
	local v340 = v_u_33[1].edgeTransparency
	local v341 = v334 * 2.2
	local v342 = v340 + (math.sin(v341) * 0.5 + 0.5) * 0.3
	local v343 = math.random() < 0.04 and 0.6 or 0
	for v344, v345 in v_u_86 do
		for v346, v347 in v345 do
			local v348 = v345["3"]
			local v349
			if v346 == "glitch" then
				v349 = v348 ~= nil
			else
				v349 = false
			end
			if v347.Parent == v344 and (#v347:GetChildren() > 1 or v349) then
				local v350 = v347:FindFirstChildOfClass("Highlight")
				if not v350 then
					continue
				end
				if v346 == "2" then
					v350.FillColor = Color3.fromHSV(v339, 0.75, 1)
					v350.OutlineColor = Color3.fromHSV((v339 + 0.5) % 1, 0.35, 1)
				elseif v346 == "1" then
					v350.OutlineTransparency = v342
				else
					if v346 ~= "3" then
						continue
					end
					v350.OutlineTransparency = v343
				end
			else
				v345[v346] = nil
				v347:Destroy()
			end
		end
		if next(v345) ~= nil then
			break
		end
		v_u_86[v344] = nil
	end
	for v351, v352 in v_u_82 do
		if not v351.Parent then
			continue
		end
		v_u_319(v352, v334, v338, v337)
	end
	for _, v353 in v_u_83 do
		v_u_327(v353, v334)
	end
	for _, v354 in v_u_84 do
		v_u_333(v354, v334)
	end
end
return v_u_10