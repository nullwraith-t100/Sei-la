local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("8A4BD6")
local v_u_9 = Color3.fromHex("1A0A2E")
local v_u_10 = Color3.fromRGB(12, 5, 22)
local v_u_11 = Color3.fromRGB(176, 110, 255)
local v_u_12 = Color3.fromRGB(224, 200, 255)
local v_u_13 = Color3.fromRGB(24, 9, 44)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_28(p17, p18, p19, p20, p21) -- name: disc
	-- upvalues: (copy) v_u_5
	local v22 = v_u_5.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: fadeDecals
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_39(p33, p34, p35, p36) -- name: egg
	-- upvalues: (copy) v_u_5
	local v37 = v_u_5.part(p33, CFrame.identity, p34, {
		["transparency"] = p35,
		["material"] = p36
	})
	local v38 = Instance.new("SpecialMesh")
	v38.MeshType = Enum.MeshType.Sphere
	v38.Parent = v37
	return v37
end
local function v_u_40() -- name: newBody
	return {
		["parts"] = nil,
		["offs"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["decals"] = nil,
		["dalphas"] = nil,
		["cfs"] = nil,
		["k"] = -1,
		["f"] = -1,
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {},
		["alphas"] = {},
		["decals"] = {},
		["dalphas"] = {},
		["cfs"] = {}
	}
end
local function v_u_57(p41, p42, p43, p44, p45, p46, p47) -- name: picturePiece
	-- upvalues: (copy) v_u_28, (copy) v_u_1
	local v48 = v_u_28(CFrame.identity, p42, p43, p44, 1)
	v48.Transparency = 1
	v_u_1:AddItem(v48, p47)
	local v49 = p41.parts
	table.insert(v49, v48)
	local v50 = p41.offs
	table.insert(v50, p46)
	local v51 = p41.sizes
	local v52 = v48.Size
	table.insert(v51, v52)
	local v53 = p41.alphas
	table.insert(v53, 1)
	for _, v54 in v48:GetChildren() do
		if not v54:IsA("Decal") then
			continue
		end
		local v55 = p41.decals
		table.insert(v55, v54)
		local v56 = p41.dalphas
		table.insert(v56, p45)
	end
	return v48
end
local function v_u_79(p58, p59, p60, p61) -- name: placeBody
	-- upvalues: (copy) v_u_4
	local v62 = math.max(p60, 0.02)
	local v63 = math.clamp(p61, 0, 1)
	local v64 = p58.parts
	local v65 = p58.offs
	local v66 = p58.cfs
	for v67 = 1, #v64 do
		local v68 = v65[v67]
		v66[v67] = p59 * (v68 - v68.Position + v68.Position * v62)
	end
	if #v64 > 0 then
		v_u_4:BulkMoveTo(v64, v66, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local v69 = v62 - p58.k
	if math.abs(v69) > 0.0001 then
		p58.k = v62
		for v70, v71 in v64 do
			v71.Size = p58.sizes[v70] * v62
		end
	end
	local v72 = v63 - p58.f
	if math.abs(v72) > 0.001 then
		p58.f = v63
		for v73, v74 in v64 do
			local v75 = p58.alphas[v73]
			v74.Transparency = v75 + (1 - v75) * v63
		end
		for v76, v77 in p58.decals do
			local v78 = p58.dalphas[v76]
			v77.Transparency = v78 + (1 - v78) * v63
		end
	end
end
return function(p_u_80)
	-- upvalues: (copy) v_u_28, (copy) v_u_1, (copy) v_u_32, (copy) v_u_5, (copy) v_u_8, (copy) v_u_11, (copy) v_u_9, (copy) v_u_39, (copy) v_u_10, (copy) v_u_16, (copy) v_u_7, (copy) v_u_4, (copy) v_u_13, (copy) v_u_12, (copy) v_u_40, (copy) v_u_57, (copy) v_u_15, (copy) v_u_6, (copy) v_u_79, (copy) v_u_2, (copy) v_u_14
	local function v_u_97(p_u_81, p_u_82, p_u_83, p84, p85, p_u_86, p_u_87, p88) -- name: flare
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_80, (ref) v_u_32
		local v_u_89 = p88 or 0
		local v_u_90 = v_u_28(p_u_81, p_u_82, p84, p85, v_u_89)
		v_u_1:AddItem(v_u_90, p_u_86 + 0.1)
		p_u_80.animate(p_u_86, 0, function(p91)
			-- upvalues: (copy) p_u_82, (copy) p_u_83, (copy) v_u_90, (copy) p_u_81, (copy) p_u_86, (copy) p_u_87, (ref) v_u_32, (copy) v_u_89
			local v92 = 1 - (1 - p91) ^ 3
			local v93 = p_u_82 + (p_u_83 - p_u_82) * v92
			local v94 = v_u_90
			local v95 = v93 * 2
			local v96 = v93 * 2
			v94.Size = Vector3.new(v95, 0.05, v96)
			v_u_90.CFrame = p_u_81 * CFrame.Angles(0, p91 * p_u_86 * p_u_87, 0)
			v_u_32(v_u_90, v_u_89 + (1 - v_u_89) * p91 ^ 1.5)
			if p91 >= 1 then
				v_u_90:Destroy()
			end
		end)
	end
	local v_u_98 = CFrame.Angles(0.9599310885968813, 0, 0)
	local function v128(p99, p100) -- name: mothShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_80, (ref) v_u_11, (ref) v_u_9, (ref) v_u_39, (ref) v_u_10, (ref) v_u_16, (ref) v_u_28, (ref) v_u_7, (ref) v_u_1, (copy) v_u_98
		local v_u_101 = p99.size
		local v102 = p99.lite
		local v_u_103 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p100, v_u_8, {
			["transparency"] = 1
		})
		p_u_80.streak(v_u_103, v_u_11, v_u_9, 1.1 * v_u_101, 0.2)
		local v_u_104 = v_u_39(Vector3.new(0.34, 0.3, 1.15) * v_u_101, v_u_10, 0, v_u_16)
		local v_u_105 = v_u_28(p100, 1.9 * v_u_101, v_u_7.NightMoth, v_u_11, 0.05)
		local v_u_106 = { v_u_104, v_u_105 }
		local v_u_107 = {}
		for _, v108 in { -1, 1 } do
			local v109 = v_u_39(Vector3.new(1.4, 0.07, 1.15) * v_u_101, v_u_10, 0, v_u_16)
			table.insert(v_u_106, v109)
			local v110 = {
				["p"] = v109,
				["side"] = v108,
				["z"] = -0.62 * v_u_101,
				["reach"] = 0.8 * v_u_101
			}
			table.insert(v_u_107, v110)
			if v102 then
				continue
			end
			local v111 = v_u_39(Vector3.new(1.15, 0.07, 1) * v_u_101, v_u_10, 0.05, v_u_16)
			table.insert(v_u_106, v111)
			local v112 = {
				["p"] = v111,
				["side"] = v108,
				["z"] = 0.72 * v_u_101,
				["reach"] = 0.66 * v_u_101
			}
			table.insert(v_u_107, v112)
		end
		if p99.mine then
			p_u_80.light(v_u_103, v_u_11, 9 * v_u_101)
		end
		for _, v113 in v_u_106 do
			v_u_1:AddItem(v113, 3)
		end
		v_u_1:AddItem(v_u_103, 3)
		local v_u_114 = false
		return {
			["place"] = function(p115, p116) -- name: place
				-- upvalues: (copy) v_u_103, (copy) v_u_101, (ref) v_u_98, (copy) v_u_104, (copy) v_u_107, (copy) v_u_105
				v_u_103.CFrame = p115
				local v117 = CFrame.new
				local v118 = p116 * 19
				local v119 = p115 * v117(0, math.sin(v118) * 0.3 * v_u_101, 0) * v_u_98
				local v120 = p116 * 40
				local v121 = math.sin(v120) * 0.8
				v_u_104.CFrame = v119
				for _, v122 in v_u_107 do
					v122.p.CFrame = v119 * CFrame.new(v122.side * 0.15 * v_u_101, 0, v122.z) * CFrame.Angles(0, 0, v122.side * v121) * CFrame.new(v122.side * v122.reach, 0, 0)
				end
				local v123 = v_u_105
				local v124 = 3.8 * v_u_101 * (math.cos(v121) * 0.7 + 0.3)
				local v125 = 3.8 * v_u_101
				v123.Size = Vector3.new(v124, 0.05, v125)
				v_u_105.CFrame = v119 * CFrame.new(0, -0.04 * v_u_101, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_114, (copy) v_u_103, (ref) v_u_1, (copy) v_u_106
				if not v_u_114 then
					v_u_114 = true
					local v126 = v_u_103:FindFirstChildWhichIsA("PointLight")
					if v126 then
						v126:Destroy()
					end
					v_u_1:AddItem(v_u_103, 0.22)
					for _, v127 in v_u_106 do
						v127:Destroy()
					end
				end
			end
		}
	end
	local function v135(p129, p130) -- name: mothImpact
		-- upvalues: (ref) v_u_4, (copy) v_u_97, (copy) p_u_80, (ref) v_u_7, (ref) v_u_11, (ref) v_u_13, (ref) v_u_16, (ref) v_u_8, (ref) v_u_12
		local v131 = p129.size
		local v132 = v_u_4.CurrentCamera
		local v133
		if v132 then
			local v134 = v132.CFrame.Position - p130
			v133 = v134.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v134.Unit
		else
			v133 = Vector3.new(0, 0, 1)
		end
		v_u_97(p_u_80.facing(p130, v133), 1.4 * v131, 4.6 * v131, v_u_7.NightMoth, v_u_11, 0.24, 0)
		p_u_80.pop(p130, v_u_13, 1.8 * v131, 4.4 * v131, 0.32, 0.35, v_u_16)
		p_u_80.pop(p130, v_u_8, 1 * v131, 3.4 * v131, 0.16, 0.3)
		p_u_80.burst("Impact", p130, v_u_8, 0.8 * v131)
		p_u_80.chunks(p130, { v_u_11, v_u_12, v_u_8 }, p129.lite and 3 or 7, 14, 0.3 * v131, 0.55, true, 0.35)
		if not p129.lite then
			p_u_80.spikes(p130, v_u_12, 3, 3 * v131, 0.12)
		end
		p_u_80.hitSound(p130)
	end
	local v_u_136 = {}
	setmetatable(v_u_136, {
		["__mode"] = "k"
	})
	local v_u_137 = {}
	setmetatable(v_u_137, {
		["__mode"] = "k"
	})
	local function v_u_202(p138, p139) -- name: buildWheel
		-- upvalues: (ref) v_u_40, (ref) v_u_57, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_10, (ref) v_u_5, (ref) v_u_16, (ref) v_u_1, (ref) v_u_15
		local v140 = v_u_40()
		local v141 = {}
		local v142 = CFrame.Angles(1.5707963267948966, 0, 0)
		v_u_57(v140, 6.048, v_u_7.NightPinwheel, v_u_8, 0.3, CFrame.new(0, 0, -0.35) * v142, p139)
		if not p138 then
			v_u_57(v140, 4.032, v_u_7.Ring, v_u_11, 0.25, CFrame.new(0, 0, -0.3) * v142, p139)
		end
		for v143 = 0, 3 do
			local v144 = v143 * 3.141592653589793 / 2 + 0.35
			local v145 = math.cos(v144)
			local v146 = math.sin(v144)
			local v147 = Vector3.new(v145, v146, 0)
			local v148 = -math.sin(v144)
			local v149 = math.cos(v144)
			local v150 = Vector3.new(v148, v149, 0)
			local v151 = v147 * 2.15
			local v152 = CFrame.lookAt(v151, v151 + v147, Vector3.new(0, 0, 1))
			local v153 = v147 * 0.5816830894638836 + v150 * 0.8134155047893737
			local v154 = v147 * 3.5 + v153 * 1.05
			local v155 = CFrame.lookAt(v154, v154 + v153, Vector3.new(0, 0, 1))
			local v156 = v_u_10
			local v157 = {
				["material"] = v_u_16
			}
			local v158 = v_u_5.part(Vector3.new(1.5, 0.5, 3.1), CFrame.identity, v156, v157)
			v158.Transparency = 1
			v_u_1:AddItem(v158, p139)
			local v159 = v140.parts
			table.insert(v159, v158)
			local v160 = v140.offs
			table.insert(v160, v152)
			local v161 = v140.sizes
			local v162 = v158.Size
			table.insert(v161, v162)
			local v163 = v140.alphas
			table.insert(v163, 0)
			local v164 = v_u_10
			local v165 = {
				["material"] = v_u_16
			}
			local v166 = v_u_5.part(Vector3.new(1, 0.5, 2.3), CFrame.identity, v164, v165)
			v166.Transparency = 1
			v_u_1:AddItem(v166, p139)
			local v167 = v140.parts
			table.insert(v167, v166)
			local v168 = v140.offs
			table.insert(v168, v155)
			local v169 = v140.sizes
			local v170 = v166.Size
			table.insert(v169, v170)
			local v171 = v140.alphas
			table.insert(v171, 0)
			if p138 then
				continue
			end
			local v172 = v_u_5.part(Vector3.new(2.1, 0.4, 3.7), CFrame.identity, v_u_11)
			local v173 = v152 + Vector3.new(0, 0, -0.25)
			v172.Transparency = 1
			v_u_1:AddItem(v172, p139)
			local v174 = v140.parts
			table.insert(v174, v172)
			local v175 = v140.offs
			table.insert(v175, v173)
			local v176 = v140.sizes
			local v177 = v172.Size
			table.insert(v176, v177)
			local v178 = v140.alphas
			table.insert(v178, 0.35)
			local v179 = v_u_5.part(Vector3.new(1.55, 0.4, 2.9), CFrame.identity, v_u_11)
			local v180 = v155 + Vector3.new(0, 0, -0.25)
			v179.Transparency = 1
			v_u_1:AddItem(v179, p139)
			local v181 = v140.parts
			table.insert(v181, v179)
			local v182 = v140.offs
			table.insert(v182, v180)
			local v183 = v140.sizes
			local v184 = v179.Size
			table.insert(v183, v184)
			local v185 = v140.alphas
			table.insert(v185, 0.35)
			if v143 % 2 ~= 0 then
				continue
			end
			table.insert(v141, v166)
		end
		local v186 = {
			["shape"] = v_u_15,
			["material"] = v_u_16
		}
		local v187 = v_u_5.part(Vector3.new(1.9, 1.9, 1.9), CFrame.identity, v_u_10, v186)
		local v188 = CFrame.identity
		v187.Transparency = 1
		v_u_1:AddItem(v187, p139)
		local v189 = v140.parts
		table.insert(v189, v187)
		local v190 = v140.offs
		table.insert(v190, v188)
		local v191 = v140.sizes
		local v192 = v187.Size
		table.insert(v191, v192)
		local v193 = v140.alphas
		table.insert(v193, 0)
		local v194 = {
			["shape"] = v_u_15
		}
		local v195 = v_u_5.part(Vector3.new(2.8, 2.8, 2.8), CFrame.identity, v_u_11, v194)
		local v196 = CFrame.new(0, 0, -0.2)
		v195.Transparency = 1
		v_u_1:AddItem(v195, p139)
		local v197 = v140.parts
		table.insert(v197, v195)
		local v198 = v140.offs
		table.insert(v198, v196)
		local v199 = v140.sizes
		local v200 = v195.Size
		table.insert(v199, v200)
		local v201 = v140.alphas
		table.insert(v201, 0.45)
		return v140, v141
	end
	local function v_u_211(p203) -- name: endWheel
		-- upvalues: (ref) v_u_5, (ref) v_u_1
		if not p203.done then
			p203.done = true
			for _, v204 in p203.body.parts do
				v204:Destroy()
			end
			for _, v205 in p203.gash do
				local v206 = v_u_5.tween
				local v207 = {
					["Transparency"] = 1,
					["Size"] = nil
				}
				local v208 = v205.Size.X * 0.3
				local v209 = v205.Size.Y
				local v210 = v205.Size.Z
				v207.Size = Vector3.new(v208, v209, v210)
				v206(v205, 0.8, v207)
				v_u_1:AddItem(v205, 0.85)
			end
		end
	end
	local function v_u_237(p212, p213, p214) -- name: shatterWheel
		-- upvalues: (ref) v_u_10, (ref) v_u_5, (ref) v_u_16, (ref) v_u_1, (ref) v_u_11, (copy) p_u_80, (copy) v_u_97, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_13, (ref) v_u_8, (ref) v_u_9, (ref) v_u_6
		local v215 = p212.size
		local v216 = p212.lite
		local v217 = p214:Cross(Vector3.new(0, 1, 0)).Unit
		for v218 = 0, 3 do
			local v219 = v218 * 3.141592653589793 / 2 + math.random() * 0.6
			local v_u_220 = v217 * math.cos(v219) + Vector3.new(0, 1, 0) * math.sin(v219)
			local v221 = Vector3.new(1.4, 0.5, 4.2) * v215
			local v222 = v_u_10
			local v223 = {
				["material"] = v_u_16
			}
			local v_u_224 = v_u_5.part(v221, CFrame.identity, v222, v223)
			v_u_1:AddItem(v_u_224, 0.6)
			local v_u_225
			if v216 then
				v_u_225 = nil
			else
				v_u_225 = v_u_5.part(Vector3.new(2, 0.4, 4.8) * v215, CFrame.identity, v_u_11, {
					["transparency"] = 0.35
				})
				v_u_1:AddItem(v_u_225, 0.6)
			end
			local v_u_226 = p213 + v_u_220 * 2 * v215
			local v_u_227 = p213 + v_u_220 * 11 * v215 - Vector3.new(0, 3, 0)
			p_u_80.animate(0.5, 0, function(p228)
				-- upvalues: (copy) v_u_226, (copy) v_u_227, (copy) v_u_220, (copy) v_u_224, (ref) v_u_225
				local v229 = v_u_226:Lerp(v_u_227, 1 - (1 - p228) ^ 2)
				local v230 = CFrame.lookAt(v229, v229 + v_u_220) * CFrame.Angles(0, p228 * 14, 0)
				v_u_224.CFrame = v230
				v_u_224.Transparency = p228 ^ 1.5
				local v231 = v_u_225
				if v231 then
					v231.CFrame = v230
					v231.Transparency = 0.35 + 0.65 * p228
				end
				if p228 >= 1 then
					v_u_224:Destroy()
					if v231 then
						v231:Destroy()
					end
				end
			end)
		end
		local v232 = v_u_97
		local v233 = p_u_80.facing
		local v234 = v_u_4.CurrentCamera
		local v235
		if v234 then
			local v236 = v234.CFrame.Position - p213
			v235 = v236.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v236.Unit
		else
			v235 = Vector3.new(0, 0, 1)
		end
		v232(v233(p213, v235), 2 * v215, 9 * v215, v_u_7.NightPinwheel, v_u_11, 0.36, -12, 0.1)
		v_u_5.flash(p213, v_u_12, 9 * v215, 0.16)
		p_u_80.pop(p213, v_u_13, 3 * v215, 9 * v215, 0.4, 0.4, v_u_16)
		p_u_80.burst("Impact", p213, v_u_8, 1.8 * v215)
		p_u_80.burst("Slash", p213, v_u_11, 1.6 * v215)
		v_u_5.ring(p_u_80.ground(p213), v_u_8, 9 * v215, 0.4, v_u_7.Shockwave)
		if not v216 then
			p_u_80.spikes(p213, v_u_11, 8, 9 * v215, 0.3)
			p_u_80.chunks(p_u_80.ground(p213, 1), { p_u_80.EARTH[1], p_u_80.EARTH[2], v_u_9 }, 8, 34, 0.8, 1)
		end
		v_u_6.play("Explosion", {
			["at"] = p213,
			["volume"] = p212.mine and 0.6 or 0.35
		})
	end
	local function v_u_267(p238, p239) -- name: wheelStep
		-- upvalues: (ref) v_u_79, (copy) p_u_80, (ref) v_u_12, (copy) v_u_237, (copy) v_u_211
		if p239.done then
			return false
		else
			local v240 = os.clock()
			local v241 = v240 - p239.born
			local v242 = v240 - p239.last
			local v243 = math.min(v242, 0.05)
			p239.last = v240
			local v244 = v241 / 0.14
			local v245 = math.clamp(v244, 0, 1)
			local v246 = v245 - 1
			local v247 = ((v246 * 2.9 * v246 * v246 + 1 + v246 * 1.9 * v246) * 0.7 + 0.3) * p238.size
			local v248 = p239.runAt
			local v249 = p239.runFrom
			local v250 = p239.runTo
			if v248 and (v249 and v250) then
				local v251 = (v240 - v248) / 0.26
				local v252 = math.clamp(v251, 0, 1)
				p239.spin = p239.spin - v243 * 38
				local v253 = v249:Lerp(v250, v252)
				local v254 = CFrame.lookAt(v253, v253 + p239.dir) * CFrame.Angles(0, 0, p239.spin)
				v_u_79(p239.body, v254, v247, 0)
				local v255 = p_u_80.ground(v249, 0.07)
				local v256 = p_u_80.ground(v253, 0.07)
				local v257 = (v256 - v255).Magnitude
				if v257 > 0.2 then
					for _, v258 in p239.gash do
						local v259 = v258.Size.X
						local v260 = v258.Size.Y
						v258.Size = Vector3.new(v259, v260, v257)
						v258.CFrame = CFrame.lookAt((v255 + v256) / 2, v256)
					end
				end
				if not p239.lite and p239.nextSpark <= v240 then
					p239.nextSpark = v240 + 0.035
					p_u_80.spikes(p_u_80.ground(v253, 0.4), v_u_12, 2, 3.5, 0.14, -p239.dir + Vector3.new(0, 0.9, 0), 0.5)
				end
				if v252 < 1 then
					return true
				end
				v_u_237(p238, v253, p239.dir)
				v_u_211(p239)
				return false
			else
				p239.spin = p239.spin - v243 * 9 * (v245 * 1.5 + 1)
				if v241 > 1 then
					local v261 = (v241 - 1) / 0.3
					local v262 = math.clamp(v261, 0, 1)
					v_u_79(p239.body, p239.home * CFrame.Angles(0, 0, p239.spin), v247 * (1 - v262 * 0.4), v262)
					if v262 < 1 then
						return true
					end
					v_u_211(p239)
					return false
				else
					local v263 = v_u_79
					local v264 = p239.body
					local v265 = p239.home * CFrame.Angles(0, 0, p239.spin)
					local v266 = v245 * 3
					v263(v264, v265, v247, 1 - math.min(v266, 1))
					return true
				end
			end
		end
	end
	local function v_u_279(p_u_268) -- name: startWheel
		-- upvalues: (copy) v_u_202, (copy) p_u_80, (ref) v_u_11, (ref) v_u_9, (copy) v_u_136, (copy) v_u_211, (copy) v_u_137, (copy) v_u_267
		local v269 = p_u_268.lite
		local v270, v271 = v_u_202(v269, 4.26)
		local v272 = p_u_80.flatUnit(p_u_268.dir)
		local v273 = p_u_80.ground(p_u_268.feet, 5.152 * p_u_268.size) + v272 * 4.5
		local v274 = os.clock()
		local v_u_275 = {
			["body"] = nil,
			["tips"] = nil,
			["born"] = nil,
			["spin"] = 0,
			["last"] = nil,
			["home"] = nil,
			["dir"] = nil,
			["runFrom"] = nil,
			["runTo"] = nil,
			["runAt"] = nil,
			["gash"] = nil,
			["nextSpark"] = 0,
			["done"] = false,
			["lite"] = nil,
			["body"] = v270,
			["tips"] = v271,
			["born"] = v274,
			["last"] = v274,
			["home"] = CFrame.lookAt(v273, v273 + v272),
			["dir"] = v272,
			["gash"] = {},
			["lite"] = v269
		}
		for _, v276 in v271 do
			p_u_80.streak(v276, v_u_11, v_u_9, 0.9, 0.22)
		end
		local v277 = p_u_268.caster
		if v277 then
			local v278 = v_u_136[v277]
			if v278 and not v278.runAt then
				v_u_211(v278)
			end
			v_u_136[v277] = v_u_275
		else
			v_u_137[p_u_268] = v_u_275
		end
		p_u_80.runNow(function()
			-- upvalues: (ref) v_u_267, (copy) p_u_268, (copy) v_u_275
			return v_u_267(p_u_268, v_u_275)
		end)
		return v_u_275
	end
	local v_u_280 = nil
	local function v_u_285(p281) -- name: nightScreen
		-- upvalues: (ref) v_u_280, (ref) v_u_2, (ref) v_u_5, (ref) v_u_1, (ref) v_u_14
		if p281 then
			local v282 = v_u_280
			if not (v282 and v282.Parent) then
				v282 = Instance.new("ColorCorrectionEffect")
				v282.Name = "Nightfall"
				v282.Parent = v_u_2
				v_u_280 = v282
			end
			if v282 then
				v_u_5.tween(v282, 0.3, {
					["TintColor"] = nil,
					["Brightness"] = -0.1,
					["Contrast"] = 0.15,
					["Saturation"] = -0.3,
					["TintColor"] = Color3.fromRGB(205, 185, 255)
				})
				v_u_1:AddItem(v282, 6)
				return
			end
		else
			local v283 = v_u_280
			if v283 and v283.Parent then
				v_u_280 = nil
				local v284 = {
					["TintColor"] = nil,
					["Brightness"] = 0,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_14
				}
				v_u_5.tween(v283, 0.35, v284)
				v_u_1:AddItem(v283, 0.4)
			end
		end
	end
	local function v_u_293(p286, p287, p288, p289) -- name: newEyes
		-- upvalues: (ref) v_u_39, (ref) v_u_11, (ref) v_u_10, (ref) v_u_16, (ref) v_u_1
		local v290 = {}
		for _ = 1, 2 do
			local v291 = v_u_39(Vector3.new(1.3, 0.55, 0.15) * p288, v_u_11, 1)
			local v292 = v_u_39(Vector3.new(0.16, 0.5, 0.18) * p288, v_u_10, 1, v_u_16)
			v_u_1:AddItem(v291, p289)
			v_u_1:AddItem(v292, p289)
			table.insert(v290, v291)
			table.insert(v290, v292)
		end
		return {
			["parts"] = nil,
			["at"] = nil,
			["openAt"] = nil,
			["blinkAt"] = nil,
			["size"] = nil,
			["last"] = -1,
			["parts"] = v290,
			["at"] = p286,
			["openAt"] = p287,
			["blinkAt"] = p287 + 0.6 + math.random() * 0.8,
			["size"] = p288
		}
	end
	local function v_u_320(p294, p295, p296, p297) -- name: placeEyes
		local v298 = (p295 - p294.openAt) / 0.12
		local v299 = math.clamp(v298, 0, 1)
		local v300 = p295 - p294.blinkAt
		if v300 > 0 and v300 < 0.2 then
			local v301 = v300 - 0.1
			v299 = v299 * (math.abs(v301) / 0.1)
		end
		local v302 = v299 * (1 - p297)
		local v303 = CFrame.lookAt(p294.at, p296)
		local v304 = p294.size
		local v305 = v302 ~= p294.last
		p294.last = v302
		for v306 = 0, 1 do
			local v307 = v306 == 0 and -1 or 1
			local v308 = p294.parts[v306 * 2 + 1]
			local v309 = p294.parts[v306 * 2 + 2]
			local v310 = v303 * CFrame.new(v307 * 0.85 * v304, 0, 0) * CFrame.Angles(0, 0, -v307 * 0.28)
			v308.CFrame = v310
			v309.CFrame = v310 * CFrame.new(0, 0, v304 * -0.06)
			if not v305 then
				continue
			end
			local v311 = v302 > 0.02 and 0 or 1
			local v312 = v304 * 1.3
			local v313 = v304 * 0.55 * v302
			local v314 = math.max(v313, 0.02)
			local v315 = v304 * 0.15
			v308.Size = Vector3.new(v312, v314, v315)
			v308.Transparency = v311
			local v316 = v304 * 0.16
			local v317 = v304 * 0.5 * v302
			local v318 = math.max(v317, 0.02)
			local v319 = v304 * 0.18
			v309.Size = Vector3.new(v316, v318, v319)
			v309.Transparency = v311
		end
	end
	local function v_u_347(p321, p322, p323) -- name: shadowBlade
		-- upvalues: (copy) p_u_80, (ref) v_u_10, (ref) v_u_5, (ref) v_u_16, (ref) v_u_11, (ref) v_u_9, (ref) v_u_1
		local v324 = math.random() * 3.141592653589793 * 2
		local v325 = math.cos(v324)
		local v326 = math.sin(v324)
		local v327 = Vector3.new(v325, 0, v326)
		local v_u_328 = p_u_80.ground(p321, 1.2 + math.random() * p322 * 0.45) + v327 * p322 * 0.95
		local v_u_329 = p_u_80.ground(p321, 1.2 + math.random() * p322 * 0.45) - v327 * p322 * 0.95
		local v330 = v_u_10
		local v331 = {
			["material"] = v_u_16
		}
		local v_u_332 = v_u_5.part(Vector3.new(1, 0.35, 4.4), CFrame.identity, v330, v331)
		local v333 = v_u_10
		local v334 = {
			["material"] = v_u_16
		}
		local v_u_335 = v_u_5.part(Vector3.new(0.75, 0.35, 2.2), CFrame.identity, v333, v334)
		v_u_332.CFrame = CFrame.new(v_u_328)
		v_u_335.CFrame = CFrame.new(v_u_328)
		local v_u_336 = { v_u_332, v_u_335 }
		local v_u_337
		if p323 then
			v_u_337 = nil
		else
			v_u_337 = v_u_5.part(Vector3.new(1.6, 0.25, 5.2), CFrame.new(v_u_328), v_u_11, {
				["transparency"] = 0.3
			})
			table.insert(v_u_336, v_u_337)
			p_u_80.streak(v_u_332, v_u_11, v_u_9, 1.4, 0.18)
		end
		for _, v338 in v_u_336 do
			v_u_1:AddItem(v338, 0.74)
		end
		local v_u_339 = (math.random() < 0.5 and 1 or -1) * (16 + math.random() * 6)
		p_u_80.after(0.12, function()
			-- upvalues: (ref) p_u_80, (copy) v_u_328, (copy) v_u_329, (ref) v_u_11
			p_u_80.burst("Slash", (v_u_328 + v_u_329) / 2, v_u_11, 1.4)
		end)
		local v_u_340 = os.clock()
		p_u_80.runNow(function()
			-- upvalues: (copy) v_u_340, (copy) v_u_328, (copy) v_u_329, (copy) v_u_339, (copy) v_u_332, (copy) v_u_335, (ref) v_u_337, (copy) v_u_336, (ref) p_u_80
			local v341 = os.clock() - v_u_340
			local v342 = v341 / 0.24
			local v343 = math.clamp(v342, 0, 1)
			local v344 = CFrame.new(v_u_328:Lerp(v_u_329, v343)) * CFrame.Angles(0, v341 * v_u_339, 0) * CFrame.new(0, 0, -1.2)
			v_u_332.CFrame = v344
			v_u_335.CFrame = v344 * CFrame.new(0.55, 0, -2.4) * CFrame.Angles(0, -0.9, 0) * CFrame.new(0, 0, -0.8)
			local v345 = v_u_337
			if v345 then
				v345.CFrame = v344 * CFrame.new(0, -0.05, -0.2)
			end
			if v343 < 1 then
				return true
			end
			for _, v346 in v_u_336 do
				p_u_80.fadeOut(v346, 0.12)
			end
			return false
		end)
	end
	local function v_u_387(p348, p349, p350) -- name: startNight
		-- upvalues: (copy) p_u_80, (ref) v_u_1, (ref) v_u_5, (ref) v_u_13, (ref) v_u_15, (ref) v_u_16, (ref) v_u_11, (ref) v_u_10, (ref) v_u_28, (ref) v_u_7, (ref) v_u_8, (ref) v_u_14, (ref) v_u_4, (copy) v_u_293
		local v351 = p348.size
		local v352 = p348.lite
		local v353 = p348.ability.radius * 1.1 * v351
		local v354 = p_u_80.ground(p349, 0)
		local v355 = p350 + 2.5
		local v356 = {}
		local v357 = {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_15,
			["material"] = v_u_16
		}
		local v358 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v354), v_u_13, v357)
		v_u_1:AddItem(v358, v355)
		table.insert(v356, v358)
		local v359
		if v352 then
			v359 = nil
		else
			v359 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v354), v_u_11, {
				["shape"] = v_u_15,
				["material"] = Enum.Material.ForceField
			})
			v_u_1:AddItem(v359, v355)
			table.insert(v356, v359)
		end
		local v360 = p_u_80.plate(p_u_80.ground(p349, 0.08), 0.5, v_u_10, 0.15, v_u_16)
		v_u_1:AddItem(v360, v355)
		table.insert(v356, v360)
		local v361 = v_u_28(CFrame.new(p_u_80.ground(p349, 0.14)), 0.5, v_u_7.NightPinwheel, v_u_8, 0.35)
		v_u_1:AddItem(v361, v355)
		table.insert(v356, v361)
		local v362 = v354 + Vector3.new(0, 1, 0) * (v353 + 4)
		local v363 = v_u_28(CFrame.new(v362), 4.5 * v351, p_u_80.iris("nightshade_pinwheel", v_u_7.NightPinwheel), v_u_14, 1)
		v_u_1:AddItem(v363, v355)
		table.insert(v356, v363)
		local v364 = {
			["shape"] = nil,
			["transparency"] = 0.5,
			["shape"] = v_u_15
		}
		local v365 = v_u_5.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v362), v_u_11, v364)
		v_u_1:AddItem(v365, v355)
		table.insert(v356, v365)
		local v366 = {
			["r"] = nil,
			["born"] = nil,
			["collapseAt"] = nil,
			["parts"] = nil,
			["dome"] = nil,
			["edge"] = nil,
			["floor"] = nil,
			["swirl"] = nil,
			["sky"] = nil,
			["skyGlow"] = nil,
			["eyes"] = nil,
			["moths"] = nil,
			["alive"] = true,
			["k"] = -1,
			["r"] = v353,
			["born"] = os.clock(),
			["parts"] = v356,
			["dome"] = v358,
			["edge"] = v359,
			["floor"] = v360,
			["swirl"] = v361,
			["sky"] = v363,
			["skyGlow"] = v365,
			["eyes"] = {},
			["moths"] = {}
		}
		local v367 = p_u_80.flatUnit
		local v368 = v_u_4.CurrentCamera
		local v369 = v367((not v368 and Vector3.new(0, 50, 50) or v368.CFrame.Position) - v354)
		local v370 = v369.Z
		local v371 = v369.X
		local v372 = math.atan2(v370, v371)
		local v373 = v352 and 2 or 5
		for v374 = 1, v373 do
			local v375 = v372 + (v374 - (v373 + 1) / 2) * (v352 and 0.9 or 0.62) + (math.random() - 0.5) * 0.2
			local v376 = v353 * (0.22 + math.random() * 0.45)
			local v377 = v353 * v353 - v376 * v376
			local v378 = math.max(v377, 1)
			local v379 = math.sqrt(v378) * 1.02
			local v380 = math.cos(v375) * v379
			local v381 = math.sin(v375) * v379
			local v382 = v354 + Vector3.new(v380, v376, v381)
			local v383 = v366.eyes
			local v384 = v_u_293(v382, v374 * 0.1 + 0.08 + math.random() * 0.08, v351 * (0.9 + math.random() * 0.5), v355)
			table.insert(v383, v384)
		end
		for _ = 1, v352 and 2 or 5 do
			local v385 = v366.moths
			local v386 = v_u_28(CFrame.new(v354), 0.8 * v351, v_u_7.NightMoth, v_u_11, 0.05)
			v_u_1:AddItem(v386, v355)
			table.insert(v356, v386)
			table.insert(v385, v386)
		end
		return v366
	end
	local function v_u_445(p388, p389, p390) -- name: nightStep
		-- upvalues: (copy) p_u_80, (ref) v_u_4, (ref) v_u_32, (copy) v_u_320
		if not p389.alive then
			return false
		end
		local v391 = os.clock()
		local v392 = v391 - p389.born
		local v393 = p389.r
		local v394 = p388.size
		local v395 = p_u_80.ground(p390, 0)
		local v396 = v392 / 0.28
		local v397 = math.clamp(v396, 0, 1) - 1
		local v398 = v397 * 2.9 * v397 * v397 + 1 + v397 * 1.9 * v397
		local v399 = p389.collapseAt
		local v400
		if v399 then
			local v401 = (v391 - v399) / 0.12
			v400 = math.clamp(v401, 0, 1)
		else
			v400 = 0
		end
		local v402 = v398 * (1 - v400)
		local v403 = math.max(v402, 0.02)
		local v404 = v_u_4.CurrentCamera
		local v405 = not v404 and Vector3.new(0, 50, 50) or v404.CFrame.Position
		if v403 ~= p389.k then
			p389.k = v403
			p389.dome.Size = Vector3.new(1, 1, 1) * v393 * 2 * v403
			p389.dome.CFrame = CFrame.new(v395)
			local v406 = p389.edge
			if v406 then
				v406.Size = Vector3.new(1, 1, 1) * v393 * 2.04 * v403
				v406.CFrame = CFrame.new(v395)
			end
			local v407 = p389.floor
			local v408 = v393 * 2 * v403
			local v409 = v393 * 2 * v403
			v407.Size = Vector3.new(0.12, v408, v409)
			local v410 = p389.swirl
			local v411 = v393 * 1.8 * v403
			local v412 = v393 * 1.8 * v403
			v410.Size = Vector3.new(v411, 0.05, v412)
		end
		p389.swirl.CFrame = CFrame.new(p_u_80.ground(p390, 0.14)) * CFrame.Angles(0, -v392 * 1.6, 0)
		local v413 = v395 + Vector3.new(0, 1, 0) * (v393 * v403 + 4 * v394)
		local v414 = (v405 - v413).Unit
		local v415 = (v392 - 0.25) / 0.2
		local v416 = math.clamp(v415, 0, 1) * (1 - v400)
		local v417 = 9 * v394
		local v418 = p389.sky
		local v419 = v417 * v416
		local v420 = math.max(v419, 0.05)
		v418.Size = Vector3.new(v417, 0.05, v420)
		p389.sky.CFrame = p_u_80.facing(v413, v414)
		v_u_32(p389.sky, v416 > 0.02 and 0 or 1)
		local v421 = p389.skyGlow
		local v422 = v417 * 1.25 * v416
		local v423 = v392 * 6
		local v424 = v422 * (math.sin(v423) * 0.05 + 1)
		v421.Size = Vector3.new(1, 1, 1) * math.max(v424, 0.1)
		p389.skyGlow.CFrame = CFrame.new(v413 - v414 * 0.6)
		for _, v425 in p389.eyes do
			v_u_320(v425, v392, v405, v400)
		end
		for v426, v427 in p389.moths do
			local v428 = v392 * (v426 * 0.13 + 1.1) + v426 * 1.9
			local v429 = v392 * 0.9 + v426
			local v430 = v393 * (math.sin(v429) * 0.3 + 0.45)
			local v431 = math.cos(v428) * v430
			local v432 = v426 % 3 * 1.4 + 1.5
			local v433 = v392 * 3 + v426
			local v434 = v432 + math.sin(v433) * 0.8
			local v435 = math.sin(v428) * v430
			local v436 = v395 + Vector3.new(v431, v434, v435)
			local v437 = v392 * 22 + v426
			local v438 = math.cos(v437)
			local v439 = math.abs(v438)
			local v440 = 1.6 * v394 * (v439 * 0.75 + 0.25) * v403
			local v441 = 1.6 * v394 * v403
			v427.Size = Vector3.new(v440, 0.05, v441)
			v427.CFrame = p_u_80.facing(v436, (v405 - v436).Unit)
		end
		if v400 < 1 then
			return v392 < 12
		end
		p389.alive = false
		for _, v442 in p389.parts do
			v442:Destroy()
		end
		for _, v443 in p389.eyes do
			for _, v444 in v443.parts do
				v444:Destroy()
			end
		end
		return false
	end
	local function v_u_482(p446, p447) -- name: dawn
		-- upvalues: (copy) p_u_80, (ref) v_u_5, (ref) v_u_12, (ref) v_u_11, (ref) v_u_8, (ref) v_u_7, (copy) v_u_97, (ref) v_u_4, (ref) v_u_28, (ref) v_u_1, (ref) v_u_32, (ref) v_u_6
		local v_u_448 = p446.size
		local v449 = p446.lite
		local v_u_450 = p446.ability.radius * 1.1 * v_u_448
		local v_u_451 = p_u_80.ground(p447)
		local v452 = p_u_80.ground(p447, 3)
		v_u_5.flash(v452, v_u_12, v_u_450 * 1.3, 0.16)
		p_u_80.pop(v452, v_u_11, 2, v_u_450 * 2.2, 0.45, 0.25)
		p_u_80.pop(v_u_451, v_u_8, v_u_450 * 0.8, v_u_450 * 2.6, 0.6, 0.6)
		p_u_80.burst("Explosion", v452, v_u_8, v_u_450 / 6)
		p_u_80.burst("Shockwave", v_u_451 + Vector3.new(0, 0.3, 0), v_u_11, v_u_450 / 14)
		v_u_5.ring(v_u_451, v_u_8, v_u_450 * 1.4, 0.5, v_u_7.Shockwave)
		p_u_80.after(0.06, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_451, (ref) v_u_12, (copy) v_u_450, (ref) v_u_7
			v_u_5.ring(v_u_451, v_u_12, v_u_450 * 1.6, 0.45, v_u_7.Ring)
		end)
		local v453 = v_u_97
		local v454 = p_u_80.facing
		local v455 = v_u_4.CurrentCamera
		local v456
		if v455 then
			local v457 = v455.CFrame.Position - v452
			v456 = v457.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v457.Unit
		else
			v456 = Vector3.new(0, 0, 1)
		end
		v453(v454(v452, v456), 3, v_u_450 * 1.2, v_u_7.NightPinwheel, v_u_11, 0.45, -10)
		p_u_80.spikes(v452, v_u_11, v449 and 5 or 10, v_u_450 * 1.1, 0.35)
		local v458 = v449 and 3 or 8
		for v_u_459 = 1, v458 do
			local v460 = v_u_459 / v458 * 3.141592653589793 * 2 + math.random() * 0.5
			local v461 = math.cos(v460)
			local v462 = 0.5 + math.random() * 0.8
			local v463 = math.sin(v460)
			local v464 = Vector3.new(v461, v462, v463).Unit
			local v_u_465 = v452 + v464 * 1.5
			local v_u_466 = v452 + v464 * v_u_450 * (0.9 + math.random() * 0.5)
			local v_u_467 = v_u_28(CFrame.new(v_u_465), 0.9 * v_u_448, v_u_7.NightMoth, v_u_11, 0)
			v_u_1:AddItem(v_u_467, 0.8)
			p_u_80.animate(0.7, 0, function(p468)
				-- upvalues: (copy) v_u_465, (copy) v_u_466, (copy) v_u_459, (copy) v_u_467, (copy) v_u_448, (ref) p_u_80, (ref) v_u_4, (ref) v_u_32
				local v469 = v_u_465:Lerp(v_u_466, 1 - (1 - p468) ^ 2)
				local v470 = p468 * 30 + v_u_459
				local v471 = math.cos(v470)
				local v472 = math.abs(v471)
				local v473 = v_u_467
				local v474 = 1.8 * v_u_448 * (v472 * 0.75 + 0.25)
				local v475 = 1.8 * v_u_448
				v473.Size = Vector3.new(v474, 0.05, v475)
				local v476 = v_u_467
				local v477 = p_u_80.facing
				local v478 = v_u_4.CurrentCamera
				local v479
				if v478 then
					local v480 = v478.CFrame.Position - v469
					v479 = v480.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v480.Unit
				else
					v479 = Vector3.new(0, 0, 1)
				end
				v476.CFrame = v477(v469, v479)
				v_u_32(v_u_467, p468 ^ 2)
				if p468 >= 1 then
					v_u_467:Destroy()
				end
			end)
		end
		if not v449 then
			local v481 = { v_u_11, v_u_12, v_u_8 }
			p_u_80.chunks(p_u_80.ground(p447, 1), v481, 10, 40, 0.5, 0.9, true, 0.8)
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_451,
			["volume"] = p446.mine and 0.9 or 0.5
		})
		if p446.mine then
			v_u_5.shake(0.5, 0.4)
		end
	end
	local v552 = {
		["nightshade_pinwheel_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["weave"] = 1.3,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p483) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_11, (copy) p_u_80, (ref) v_u_12, (copy) v_u_97, (ref) v_u_7, (ref) v_u_8
				local v484 = p483.size
				local v485 = p483.eye + p483.dir * 1.2
				v_u_5.flash(v485, v_u_11, 3 * v484, 0.12)
				p_u_80.pop(v485, v_u_12, 1.2 * v484, 0.3 * v484, 0.1)
				if not p483.lite then
					v_u_97(p_u_80.facing(v485, p483.dir), 0.5 * v484, 2.2 * v484, v_u_7.NightMoth, v_u_8, 0.14, 0, 0.1)
				end
			end,
			["shot"] = v128,
			["impact"] = v135,
			["hit"] = function(p486, p487, _) -- name: hit
				-- upvalues: (copy) p_u_80, (ref) v_u_8, (ref) v_u_13, (ref) v_u_16
				p_u_80.burst("Impact", p487, v_u_8, 0.6)
				if not p486.lite then
					p_u_80.pop(p487, v_u_13, 1, 2.6, 0.2, 0.4, v_u_16)
				end
			end
		},
		["nightshade_pinwheel_e"] = {
			["castSound"] = "Roll",
			["cast"] = nil,
			["windup"] = nil,
			["beam"] = nil,
			["hit"] = nil,
			["cast"] = function(p488) -- name: cast
				-- upvalues: (copy) p_u_80, (ref) v_u_8, (copy) v_u_279
				p_u_80.skillCast(p488, v_u_8)
				v_u_279(p488)
			end,
			["windup"] = function(p489, _, _) -- name: windup
				-- upvalues: (copy) v_u_136, (copy) v_u_137, (copy) v_u_279
				local v490 = p489.caster
				local v491
				if v490 then
					v491 = v_u_136[v490]
				else
					v491 = v_u_137[p489]
				end
				if not v491 or (v491.done or v491.runAt) then
					v491 = nil
				end
				if not v491 then
					v_u_279(p489)
				end
			end,
			["beam"] = function(p492, _, p493) -- name: beam
				-- upvalues: (copy) v_u_136, (copy) v_u_137, (copy) v_u_279, (copy) p_u_80, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5, (ref) v_u_16, (ref) v_u_1, (ref) v_u_6
				local v494 = p492.caster
				local v495
				if v494 then
					v495 = v_u_136[v494]
				else
					v495 = v_u_137[p492]
				end
				if not v495 or (v495.done or v495.runAt) then
					v495 = nil
				end
				local v496 = v495 or v_u_279(p492)
				local v497 = p492.size
				local v498 = v496.home.Position
				local v499 = p493.X
				local v500 = v498.Y
				local v501 = p493.Z
				local v502 = Vector3.new(v499, v500, v501)
				v496.dir = p_u_80.flatUnit(v502 - v498)
				v496.runFrom = v498
				v496.runTo = v502
				v496.runAt = os.clock()
				p_u_80.glowBeam(p_u_80.ground(v498, 1.2), p_u_80.ground(v502, 1.2), v_u_11, 1.4 * v497, 0.3)
				p_u_80.groundLine(v498, v502, 10 * v497, v_u_9, 0.7, 0.6)
				local v503 = 2.4 * v497
				local v504 = Vector3.new(v503, 0.12, 0.1)
				local v505 = v_u_10
				local v506 = {
					["material"] = v_u_16
				}
				local v507 = v_u_5.part(v504, CFrame.identity, v505, v506)
				local v508 = v_u_5.part
				local v509 = 0.7 * v497
				local v510 = v508(Vector3.new(v509, 0.16, 0.1), CFrame.identity, v_u_11)
				v507.CFrame = CFrame.new(p_u_80.ground(v498, 0.07))
				v510.CFrame = CFrame.new(p_u_80.ground(v498, 0.08))
				v_u_1:AddItem(v507, 4)
				v_u_1:AddItem(v510, 4)
				v496.gash = { v507, v510 }
				v_u_6.play("EyeActivate", {
					["at"] = v498,
					["volume"] = p492.mine and 0.9 or 0.5
				})
				if p492.mine then
					v_u_5.shake(0.3, 0.25)
				end
			end,
			["hit"] = function(p511, p512, _) -- name: hit
				-- upvalues: (copy) p_u_80, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11
				p_u_80.burst("Impact", p512, v_u_8, 0.8)
				if not p511.lite then
					for v513 = 0, 1 do
						local v514 = math.random() - 0.5
						local v515 = (v513 - 0.5) * 1.6
						local v516 = math.random() - 0.5
						local v517 = Vector3.new(v514, v515, v516).Unit * 1.8
						local v518 = p_u_80.thin
						local v519 = p_u_80.rod
						local v520 = p512 - v517
						local v521 = p512 + v517
						local v522 = 0.22
						local v523
						if v513 == 0 then
							v523 = v_u_10
						else
							v523 = v_u_11
						end
						v518(v519(v520, v521, v522, v523), 0.14)
					end
				end
			end
		},
		["nightshade_pinwheel_r"] = {
			["castSound"] = "Bind",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p524) -- name: cast
				-- upvalues: (copy) p_u_80, (ref) v_u_8
				p_u_80.skillCast(p524, v_u_8, true)
			end,
			["windup"] = function(p525, p526, p527) -- name: windup
				-- upvalues: (copy) v_u_285, (copy) p_u_80, (ref) v_u_5, (ref) v_u_13, (ref) v_u_15, (ref) v_u_16, (ref) v_u_1, (ref) v_u_11, (ref) v_u_9, (copy) v_u_97, (ref) v_u_7, (ref) v_u_10
				local v_u_528 = p525.size
				local v529 = math.max(p527, 0.06)
				if p525.mine then
					v_u_285(true)
				end
				local v_u_530 = p_u_80.ground(p526, 26)
				local v_u_531 = p_u_80.ground(p526, 1)
				local v532 = {
					["shape"] = v_u_15,
					["material"] = v_u_16
				}
				local v_u_533 = v_u_5.part(Vector3.new(2.2, 2.2, 2.2) * v_u_528, CFrame.new(v_u_530), v_u_13, v532)
				v_u_1:AddItem(v_u_533, v529 + 0.3)
				p_u_80.streak(v_u_533, v_u_11, v_u_9, 2 * v_u_528, 0.25)
				p_u_80.animate(v529, 0, function(p534)
					-- upvalues: (copy) v_u_533, (copy) v_u_530, (copy) v_u_531, (copy) v_u_528
					v_u_533.CFrame = CFrame.new(v_u_530:Lerp(v_u_531, p534 * p534))
					v_u_533.Size = Vector3.new(1, 1, 1) * (2.2 + 2 * p534) * v_u_528
					if p534 >= 1 then
						v_u_533:Destroy()
					end
				end)
				v_u_97(CFrame.new(p_u_80.ground(p526, 0.1)), 1, p525.ability.radius * v_u_528, v_u_7.Glow, v_u_10, v529 + 0.25, 0, 0.05)
			end,
			["zone"] = function(p_u_535, p_u_536, p_u_537) -- name: zone
				-- upvalues: (copy) v_u_387, (copy) p_u_80, (ref) v_u_10, (ref) v_u_16, (ref) v_u_5, (ref) v_u_8, (ref) v_u_7, (copy) v_u_445, (copy) v_u_347, (ref) v_u_11, (ref) v_u_6, (ref) v_u_280, (ref) v_u_14, (ref) v_u_1
				local v_u_538 = p_u_535.lite
				local v_u_539 = v_u_387(p_u_535, p_u_536, p_u_537)
				local v_u_540 = p_u_80.ground(p_u_536)
				p_u_80.pop(p_u_80.ground(p_u_536, 1), v_u_10, 3, v_u_539.r * 2.3, 0.35, 0.3, v_u_16)
				v_u_5.ring(v_u_540, v_u_8, v_u_539.r * 1.2, 0.4, v_u_7.Shockwave)
				p_u_80.runNow(function()
					-- upvalues: (ref) v_u_445, (copy) p_u_535, (copy) v_u_539, (copy) p_u_536
					return v_u_445(p_u_535, v_u_539, p_u_536)
				end)
				local v_u_541 = p_u_535.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (copy) v_u_539, (copy) p_u_537, (copy) v_u_538, (ref) v_u_347, (copy) p_u_536, (ref) p_u_80, (ref) v_u_11, (ref) v_u_6, (copy) v_u_540, (copy) p_u_535, (copy) v_u_541
					task.wait(0.15)
					while v_u_539.alive and (not v_u_539.collapseAt and os.clock() - v_u_539.born < p_u_537 + 0.5) do
						for _ = 1, v_u_538 and 2 or 4 do
							v_u_347(p_u_536, v_u_539.r, v_u_538)
						end
						if not v_u_538 then
							p_u_80.inward(p_u_80.ground(p_u_536, 1.2), v_u_11, 5, v_u_539.r, 0.3)
						end
						v_u_6.play("EyeActivate", {
							["at"] = nil,
							["volume"] = nil,
							["pitch"] = 0.8,
							["at"] = v_u_540,
							["volume"] = p_u_535.mine and 0.45 or 0.25
						})
						task.wait(v_u_541)
					end
				end)
				return function()
					-- upvalues: (copy) v_u_539, (copy) p_u_535, (ref) v_u_280, (ref) v_u_5, (ref) v_u_14, (ref) v_u_1
					v_u_539.collapseAt = os.clock()
					if p_u_535.mine then
						local v542 = v_u_280
						if v542 and v542.Parent then
							v_u_280 = nil
							local v543 = {
								["TintColor"] = nil,
								["Brightness"] = 0,
								["Contrast"] = 0,
								["Saturation"] = 0,
								["TintColor"] = v_u_14
							}
							v_u_5.tween(v542, 0.35, v543)
							v_u_1:AddItem(v542, 0.4)
						end
					end
				end
			end,
			["finish"] = function(p544, p545) -- name: finish
				-- upvalues: (copy) v_u_482
				v_u_482(p544, p545)
			end,
			["hit"] = function(p546, p547, _) -- name: hit
				-- upvalues: (copy) p_u_80, (ref) v_u_11, (ref) v_u_10
				p_u_80.burst("Impact", p547, v_u_11, 0.7)
				if not p546.lite then
					local v548 = math.random() * 3.141592653589793
					local v549 = math.cos(v548)
					local v550 = math.sin(v548)
					local v551 = Vector3.new(v549, 0.6, v550).Unit * 2
					p_u_80.thin(p_u_80.rod(p547 - v551, p547 + v551, 0.25, v_u_10), 0.16)
					p_u_80.thin(p_u_80.rod(p547 - v551 * 0.8, p547 + v551 * 0.8, 0.12, v_u_11), 0.14)
				end
			end
		}
	}
	return v552
end