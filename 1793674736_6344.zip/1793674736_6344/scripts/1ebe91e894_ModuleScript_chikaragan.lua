local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(150, 215, 255)
local v_u_6 = Color3.fromRGB(38, 44, 76)
local v_u_7 = Color3.fromRGB(58, 66, 104)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7
	return {
		["w5_chikaragan"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
			local v_u_11 = v_u_2.color(p10.color)
			local v12 = v_u_2.color(p10.color2)
			local v13 = p_u_9.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_15 = p_u_8.crownOf(p_u_9)
			local v_u_22 = p_u_8.group(p_u_9, function(p16)
				-- upvalues: (copy) v_u_15, (copy) p_u_9, (ref) p_u_8
				local v17 = v_u_15(p16).Position + Vector3.new(0, 1, 0) * p_u_9.eyeLift
				local v18 = p_u_8.camPos() - v17
				local v19 = v18.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v18.Unit
				local v20 = v19.Y
				local v21 = math.abs(v20) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v17, v17 + v19, v21) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v_u_24 = p_u_8.throb(p_u_9, 4, 4, 1.8, function(p23)
				-- upvalues: (ref) v_u_2, (ref) p_u_8, (copy) p_u_9, (copy) v_u_11, (ref) v_u_3, (copy) v_u_22, (ref) v_u_4, (copy) v_u_14
				v_u_2.ring(p_u_8.feetAt(p_u_9, p23, 0.15), v_u_11, 6.5 * p_u_9.fx, 0.6, v_u_3.Shockwave)
				v_u_2.flash(v_u_22.cf.Position, v_u_4, v_u_14 * 3.6 * p_u_9.fx, 0.22)
			end)
			local v_u_25 = v_u_14 * 2.8
			local v26 = p_u_9.ticks
			local function v32(_, p27)
				-- upvalues: (ref) v_u_25, (copy) v_u_14
				local v28 = p27 % 4
				if p27 >= 3.75 and v28 >= 3.75 then
					local v29 = (v28 - 3.75) / 0.25
					v_u_25 = v_u_14 * (2.8 - 1.6 * v29 * v29)
					return
				elseif p27 >= 4 and v28 < 0.65 then
					local v30 = v_u_14
					local v31 = v28 / 0.65 - 1
					v_u_25 = v30 * ((v31 * 2.6 * v31 * v31 + 1 + v31 * 1.6 * v31) * 1.6 + 1.2)
				else
					v_u_25 = v_u_14 * 2.8
				end
			end
			table.insert(v26, v32)
			local v_u_33 = v_u_25
			for v_u_34 = 1, 4 do
				local v35
				if v_u_34 % 2 == 0 then
					v35 = v12
				else
					v35 = v_u_11
				end
				local v_u_36, v_u_37 = p_u_8.picture(1, v_u_3.Ring, v35, 0)
				for _, v38 in v_u_37 do
					v38.Color3 = Color3.new(v35.R * 1.8, v35.G * 1.8, v35.B * 1.8)
				end
				p_u_8.add(p_u_9, v_u_36, function(_, p39)
					-- upvalues: (copy) v_u_34, (copy) v_u_24, (copy) v_u_14, (copy) v_u_36, (copy) v_u_37, (copy) v_u_22
					local v40 = (p39 * 0.55 + v_u_34 / 4) % 1
					local v41 = v_u_24()
					local v42 = (3.1 - 2.3 * v40) * v_u_14 * (1 - 0.8 * v41)
					local v43 = v_u_36
					local v44 = v42 * 2
					local v45 = v42 * 2
					v43.Size = Vector3.new(v44, 0.05, v45)
					local v46 = v40 / 0.15
					local v47 = (1 - v40) / 0.25
					local v48 = math.min(v46, v47, 1)
					for _, v49 in v_u_37 do
						v49.Transparency = 1 - v48 * 0.9
					end
					return v_u_22.cf * CFrame.new(0, -0.35 - v_u_34 * 0.02, 0)
				end)
			end
			local v50 = p_u_8.picture(v_u_14 * 4.6, v_u_3.ChikaSwirl, v_u_5, 0.35)
			p_u_8.add(p_u_9, v50, function(_, p51)
				-- upvalues: (copy) v_u_22
				return v_u_22.cf * CFrame.new(0, -0.6, 0) * CFrame.Angles(0, -p51 * 0.9, 0)
			end)
			local v_u_58 = p_u_8.group(p_u_9, function(p52)
				-- upvalues: (copy) v_u_14, (ref) p_u_8
				local v53 = p52.Position + Vector3.new(0, 0.4, 0) * v_u_14
				local v54 = p_u_8.camPos() - v53
				local v55 = v54.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v54.Unit
				local v56 = v55.Y
				local v57 = math.abs(v56) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v53, v53 + v55, v57) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v59, v_u_60 = p_u_8.picture(v_u_14 * 8.5, v_u_3.ChikaSwirl, v12, 0.72)
			p_u_8.add(p_u_9, v59, function(_, p61)
				-- upvalues: (copy) v_u_58, (copy) v_u_14
				return v_u_58.cf * CFrame.new(0, v_u_14 * -1.4, 0) * CFrame.Angles(0, p61 * 0.35, 0)
			end)
			local v_u_62 = -1
			local v63 = p_u_9.ticks
			local function v70(p64)
				-- upvalues: (ref) p_u_8, (ref) v_u_62, (copy) v_u_60
				local v65 = p64.Position - p_u_8.camPos()
				local v66 = ((v65.Magnitude <= 0.01 and 0 or v65.Unit:Dot(p64.LookVector)) + 0.1) * 1.6
				local v67 = math.clamp(v66, 0, 1) * 0.24 + 0.72
				local v68 = v67 - v_u_62
				if math.abs(v68) > 0.01 then
					v_u_62 = v67
					for _, v69 in v_u_60 do
						v69.Transparency = v67
					end
				end
			end
			table.insert(v63, v70)
			for v_u_71 = 1, 7 do
				local v_u_72 = v_u_71 * 1.618
				local v73 = v_u_72 * 3.1 % 0.5 + 0.55
				local v74 = v_u_72 * 5.3 % 0.45 + 0.5
				local v75 = v_u_72 * 7.7 % 0.5 + 0.6
				local v76 = Vector3.new(v73, v74, v75) * 1.25 * v_u_14
				local v77
				if v_u_71 % 2 == 0 then
					v77 = v_u_6
				else
					v77 = v_u_7
				end
				local function v90(p78, p79) -- name: place
					-- upvalues: (copy) v_u_71, (copy) v_u_14, (ref) v_u_33, (copy) v_u_72
					local v80 = p79 * 0.45 + (v_u_71 - 1) / 7 * 3.141592653589793 * 2
					local v81 = v_u_14 * 0.15
					local v82 = v_u_14 * 0.35
					local v83 = p79 * 1.3 + v_u_71
					local v84 = v81 + v82 * math.sin(v83) + v_u_14 * 0.55 * math.sin(v80)
					local v85 = v_u_33 * (v_u_72 * 2.3 % 1 * 0.16 + 0.92)
					local v86 = p78.Position
					local v87 = math.cos(v80) * v85
					local v88 = math.sin(v80) * v85
					local v89 = v86 + Vector3.new(v87, v84, v88)
					return CFrame.new(v89) * CFrame.Angles(p79 * 0.7 + v_u_71, p79 * 0.5 + v_u_71 * 2, 0)
				end
				p_u_8.add(p_u_9, p_u_8.bar(v76, v77, 0, Enum.Material.SmoothPlastic), v90)
				local v91 = v76.X
				local v92 = v76.Y
				local v93 = v76.Z
				local v94 = math.max(v91, v92, v93) * 1.3
				p_u_8.add(p_u_9, p_u_8.ball(v94, v12, 0.7), p_u_8.behind(v90, v94 * 0.45))
			end
			for v_u_95 = 1, 3 do
				local v_u_96, v_u_97 = p_u_8.picture(1, v_u_3.Ring, v_u_11, 0)
				for _, v98 in v_u_97 do
					v98.Color3 = Color3.new(v_u_11.R * 1.6, v_u_11.G * 1.6, v_u_11.B * 1.6)
				end
				p_u_8.add(p_u_9, v_u_96, function(p99, p100)
					-- upvalues: (copy) v_u_95, (copy) v_u_14, (copy) v_u_96, (copy) v_u_97, (ref) p_u_8, (copy) p_u_9
					local v101 = (p100 * 0.4 + v_u_95 / 3) % 1
					local v102 = (3.8 - 3.1 * v101) * v_u_14
					local v103 = v_u_96
					local v104 = v102 * 2
					local v105 = v102 * 2
					v103.Size = Vector3.new(v104, 0.05, v105)
					local v106 = v101 / 0.2
					local v107 = (1 - v101) / 0.25
					local v108 = math.min(v106, v107, 1)
					for _, v109 in v_u_97 do
						v109.Transparency = 1 - v108 * 0.7
					end
					return CFrame.new(p_u_8.feetAt(p_u_9, p99, v_u_95 * 0.01 + 0.12))
				end)
			end
			p_u_8.particles(p_u_9, "AuraMode", v12, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			local v110 = p_u_8.particles
			local v111 = {
				["rate"] = 0.35,
				["scale"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Lines" }
			}
			local v112 = p_u_9.headY + p_u_9.eyeLift
			v111.at = Vector3.new(0, v112, 0)
			v110(p_u_9, "Charge", v_u_11, v111)
		end
	}
end