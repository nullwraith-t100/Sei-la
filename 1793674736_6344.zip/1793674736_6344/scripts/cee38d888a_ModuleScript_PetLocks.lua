local v_u_1 = require(script.Parent.Parent.Config.Pets)
local v_u_20 = {
	["AUTO_DELETE"] = { "Common", "Rare", "Epic" },
	["MAX_LIST"] = 1000,
	["canAutoDelete"] = function(p2) -- name: canAutoDelete
		-- upvalues: (copy) v_u_20
		return table.find(v_u_20.AUTO_DELETE, p2) ~= nil
	end,
	["cleanLocks"] = function(p3, p4) -- name: cleanLocks
		local v5 = {}
		if type(p4) ~= "table" then
			return v5
		end
		for v6, v7 in p4 do
			if type(v6) ~= "string" or (v7 ~= true or p3[v6] == nil) then
				continue
			end
			v5[v6] = true
		end
		return v5
	end,
	["cleanAutoDelete"] = function(p8) -- name: cleanAutoDelete
		-- upvalues: (copy) v_u_20
		local v9 = {}
		if type(p8) ~= "table" then
			return v9
		end
		for _, v10 in v_u_20.AUTO_DELETE do
			if p8[v10] ~= true then
				continue
			end
			v9[v10] = true
		end
		return v9
	end,
	["isLocked"] = function(p11, p12) -- name: isLocked
		local v13
		if p11 == nil then
			v13 = false
		else
			v13 = p11[p12] == true
		end
		return v13
	end,
	["deletable"] = function(p14, p15, p16) -- name: deletable
		-- upvalues: (copy) v_u_1, (copy) v_u_20
		if type(p16) ~= "string" then
			return false
		end
		local v17 = p14[p16]
		local v18
		if v17 then
			v18 = v_u_1.byId[v17]
		else
			v18 = nil
		end
		local v19
		if v18 == nil or v18.pass ~= nil then
			v19 = false
		else
			v19 = not v_u_20.isLocked(p15, p16)
		end
		return v19
	end
}
local function v_u_25(p21, p22) -- name: byUid
	local v23 = tonumber(p21)
	local v24 = tonumber(p22)
	if v23 and (v24 and v23 ~= v24) then
		return v23 < v24
	else
		return p21 < p22
	end
end
v_u_20.SWEEP = {
	"Common",
	"Rare",
	"Epic",
	"Legendary"
}
function v_u_20.sweepable(p26, p27) -- name: sweepable
	-- upvalues: (copy) v_u_1, (copy) v_u_20
	local v28 = v_u_1.byId[p26]
	local v29
	if v28 == nil or p27 ~= nil then
		v29 = false
	else
		v29 = table.find(v_u_20.SWEEP, v28.rarity) ~= nil
	end
	return v29
end
function v_u_20.toDelete(p30, p31, p32, p33, p34) -- name: toDelete
	-- upvalues: (copy) v_u_20, (copy) v_u_25
	local v35
	if p33 == nil then
		v35 = nil
	else
		v35 = {}
		if type(p33) == "table" then
			local v36 = 0
			for _, v37 in p33 do
				v36 = v36 + 1
				if v_u_20.MAX_LIST < v36 then
					break
				end
				if type(v37) ~= "string" then
					continue
				end
				v35[v37] = true
			end
		end
	end
	local v38 = {}
	for v39 in p30 do
		if v35 ~= nil and not v35[v39] or (not v_u_20.deletable(p30, p31, v39) or table.find(p32, v39)) then
			continue
		end
		local v40 = v_u_20.sweepable
		local v41 = p30[v39]
		local v42
		if p34 then
			v42 = p34[v39]
		else
			v42 = nil
		end
		if not v40(v41, v42) then
			continue
		end
		table.insert(v38, v39)
	end
	table.sort(v38, v_u_25)
	return v38
end
function v_u_20.canAutoDeleteKind(p43) -- name: canAutoDeleteKind
	-- upvalues: (copy) v_u_1, (copy) v_u_20
	if type(p43) ~= "string" then
		return false
	end
	local v44 = v_u_1.byId[p43]
	local v45
	if v44 == nil or v44.pass ~= nil then
		v45 = false
	else
		v45 = v_u_20.canAutoDelete(v44.rarity)
	end
	return v45
end
function v_u_20.cleanAutoDeletePets(p46) -- name: cleanAutoDeletePets
	-- upvalues: (copy) v_u_20
	local v47 = {}
	if type(p46) ~= "table" then
		return v47
	end
	for v48, v49 in p46 do
		if v49 ~= true or not v_u_20.canAutoDeleteKind(v48) then
			continue
		end
		v47[v48] = true
	end
	return v47
end
function v_u_20.autoDeleted(p50, p51) -- name: autoDeleted
	-- upvalues: (copy) v_u_20
	local v52
	if p51 == nil or p51[p50] ~= true then
		v52 = false
	else
		v52 = v_u_20.canAutoDeleteKind(p50)
	end
	return v52
end
function v_u_20.sortHatch(p53, p54) -- name: sortHatch
	-- upvalues: (copy) v_u_20
	local v55 = {}
	local v56 = 0
	for v57, v58 in p53 do
		v55[v57] = v_u_20.autoDeleted(v58, p54)
		if v55[v57] then
			continue
		end
		v56 = v56 + 1
	end
	return v55, v56
end
function v_u_20.fits(p59, p60, p61) -- name: fits
	return p60 <= 0 and true or p59 + p60 <= p61
end
function v_u_20.firstLocked(p62, p63) -- name: firstLocked
	-- upvalues: (copy) v_u_20
	for _, v64 in p63 do
		if not v_u_20.isLocked(p62, v64) then
			continue
		end
		return v64
	end
	return nil
end
function v_u_20.forget(p65, p66) -- name: forget
	for _, v67 in p66 do
		p65[v67] = nil
	end
end
return v_u_20