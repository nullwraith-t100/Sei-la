local v_u_1 = require(script.Parent.ArcadeLog)
local v_u_2 = require(script.Parent.Parent.Config.Arcade)
local v_u_3 = {
	["LEFT"] = 1,
	["RIGHT"] = 2,
	["ROTATE"] = 3,
	["ROTATE_BACK"] = 4,
	["SOFT"] = 5,
	["HARD"] = 6,
	["ACTIONS"] = 6
}
local v_u_4 = {
	{
		{
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 },
			{ 3, 1 }
		},
		{
			{ 2, 0 },
			{ 2, 1 },
			{ 2, 2 },
			{ 2, 3 }
		},
		{
			{ 0, 2 },
			{ 1, 2 },
			{ 2, 2 },
			{ 3, 2 }
		},
		{
			{ 1, 0 },
			{ 1, 1 },
			{ 1, 2 },
			{ 1, 3 }
		}
	},
	{
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 1, 1 },
			{ 2, 1 }
		}
	},
	{
		{
			{ 1, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 1, 1 },
			{ 2, 1 },
			{ 1, 2 }
		},
		{
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 },
			{ 1, 2 }
		},
		{
			{ 1, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 1, 2 }
		}
	},
	{
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 0, 1 },
			{ 1, 1 }
		},
		{
			{ 1, 0 },
			{ 1, 1 },
			{ 2, 1 },
			{ 2, 2 }
		},
		{
			{ 1, 1 },
			{ 2, 1 },
			{ 0, 2 },
			{ 1, 2 }
		},
		{
			{ 0, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 1, 2 }
		}
	},
	{
		{
			{ 0, 0 },
			{ 1, 0 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 2, 0 },
			{ 1, 1 },
			{ 2, 1 },
			{ 1, 2 }
		},
		{
			{ 0, 1 },
			{ 1, 1 },
			{ 1, 2 },
			{ 2, 2 }
		},
		{
			{ 1, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 0, 2 }
		}
	},
	{
		{
			{ 0, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 2, 0 },
			{ 1, 1 },
			{ 1, 2 }
		},
		{
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 },
			{ 2, 2 }
		},
		{
			{ 1, 0 },
			{ 1, 1 },
			{ 0, 2 },
			{ 1, 2 }
		}
	},
	{
		{
			{ 2, 0 },
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 }
		},
		{
			{ 1, 0 },
			{ 1, 1 },
			{ 1, 2 },
			{ 2, 2 }
		},
		{
			{ 0, 1 },
			{ 1, 1 },
			{ 2, 1 },
			{ 0, 2 }
		},
		{
			{ 0, 0 },
			{ 1, 0 },
			{ 1, 1 },
			{ 1, 2 }
		}
	}
}
v_u_3.KINDS = #v_u_4
local v_u_5 = {
	{ 0, 0 },
	{ -1, 0 },
	{ 1, 0 },
	{ 0, -1 },
	{ -1, -1 },
	{ 1, -1 },
	{ -2, 0 },
	{ 2, 0 }
}
function v_u_3.cells(p6, p7) -- name: cells
	-- upvalues: (copy) v_u_4
	return v_u_4[p6][p7]
end
local function v_u_16(p8, p9, p10, p11, p12) -- name: fits
	-- upvalues: (copy) v_u_4
	for _, v13 in v_u_4[p9][p10] do
		local v14 = p11 + v13[1]
		local v15 = p12 + v13[2]
		if v14 < 1 or (p8.w < v14 or (v15 < 1 or p8.h < v15)) then
			return false
		end
		if p8.cells[(v15 - 1) * p8.w + v14] == 0 then
			continue
		end
		return false
	end
	return true
end
v_u_3.fits = v_u_16
local function v_u_26(p17) -- name: refill
	-- upvalues: (copy) v_u_1
	while #p17.queue < 7 do
		local v18 = {
			1,
			2,
			3,
			4,
			5,
			6,
			7
		}
		for v19 = #v18, 2, -1 do
			local v20, v21 = v_u_1.roll(p17.rng, v19)
			p17.rng = v20
			local v22 = v18[v21]
			local v23 = v18[v19]
			v18[v19] = v22
			v18[v21] = v23
		end
		for _, v24 in v18 do
			local v25 = p17.queue
			table.insert(v25, v24)
		end
	end
end
local function v_u_31(p27) -- name: spawn
	-- upvalues: (copy) v_u_26, (copy) v_u_16
	v_u_26(p27)
	local v28 = table.remove(p27.queue, 1)
	v_u_26(p27)
	p27.piece = {
		["kind"] = nil,
		["rot"] = 1,
		["x"] = nil,
		["y"] = 1,
		["kind"] = v28,
		["x"] = (p27.w - 4) // 2 + 1
	}
	p27.fall = 0
	p27.rest = 0
	p27.resets = 0
	p27.pieces = p27.pieces + 1
	if not v_u_16(p27, v28, 1, p27.piece.x, p27.piece.y) then
		p27.over = true
		p27.reason = "top"
		local v29 = p27.events
		local v30 = {
			["kind"] = "over",
			["rows"] = nil,
			["count"] = 0,
			["points"] = 0,
			["combo"] = nil,
			["rows"] = {},
			["combo"] = p27.combo
		}
		table.insert(v29, v30)
	end
end
function v_u_3.new(p32) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_31
	local v33 = v_u_2.blocks
	local v34 = v33.height + v33.hidden
	local v35 = {
		["w"] = nil,
		["h"] = nil,
		["hidden"] = nil,
		["cells"] = nil,
		["piece"] = nil,
		["queue"] = nil,
		["rng"] = nil,
		["tick"] = 0,
		["time"] = 0,
		["fall"] = 0,
		["rest"] = 0,
		["resets"] = 0,
		["level"] = 1,
		["lines"] = 0,
		["score"] = 0,
		["combo"] = 0,
		["bestCombo"] = 0,
		["pieces"] = 0,
		["blasts"] = 0,
		["over"] = false,
		["reason"] = "",
		["events"] = nil,
		["w"] = v33.width,
		["h"] = v34,
		["hidden"] = v33.hidden,
		["cells"] = table.create(v33.width * v34, 0),
		["piece"] = {
			["kind"] = 1,
			["rot"] = 1,
			["x"] = 1,
			["y"] = 1
		},
		["queue"] = {},
		["rng"] = v_u_1.seed(p32),
		["events"] = {}
	}
	v_u_31(v35)
	return v35
end
function v_u_3.dropDistance(p36) -- name: dropDistance
	-- upvalues: (copy) v_u_16
	local v37 = p36.piece
	local v38 = 0
	while v_u_16(p36, v37.kind, v37.rot, v37.x, v37.y + v38 + 1) do
		v38 = v38 + 1
	end
	return v38
end
local function v_u_74(p39) -- name: lock
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_31
	local v40 = v_u_2.blocks
	local v41 = p39.piece
	local v42 = p39.h
	for _, v43 in v_u_4[v41.kind][v41.rot] do
		local v44 = v41.x + v43[1]
		local v45 = v41.y + v43[2]
		p39.cells[(v45 - 1) * p39.w + v44] = v41.kind
		v42 = math.min(v42, v45)
	end
	local v46 = p39.events
	local v47 = {
		["kind"] = "lock",
		["rows"] = nil,
		["count"] = 0,
		["points"] = 0,
		["combo"] = nil,
		["rows"] = {},
		["combo"] = p39.combo
	}
	table.insert(v46, v47)
	local v48 = {}
	for v49 = 1, p39.h do
		local v50 = true
		for v51 = 1, p39.w do
			if p39.cells[(v49 - 1) * p39.w + v51] ~= 0 then
				continue
			end
			v50 = false
		end
		if not v50 then
			break
		end
		table.insert(v48, v49)
	end
	if #v48 > 0 then
		local v52 = {}
		for v53 = p39.h, 1, -1 do
			if table.find(v48, v53) then
				continue
			end
			for v54 = p39.w, 1, -1 do
				local v55 = p39.cells[(v53 - 1) * p39.w + v54]
				table.insert(v52, v55)
			end
		end
		local v56 = 1
		for v57 = p39.h, 1, -1 do
			for v58 = p39.w, 1, -1 do
				p39.cells[(v57 - 1) * p39.w + v58] = v52[v56] or 0
				v56 = v56 + 1
			end
		end
		p39.combo = p39.combo + 1
		local v59 = p39.bestCombo
		local v60 = p39.combo
		p39.bestCombo = math.max(v59, v60)
		local v61 = v40.lineScores
		local v62 = #v48
		local v63 = #v40.lineScores
		local v64 = v61[math.min(v62, v63)] * p39.level
		if p39.combo >= 2 then
			v64 = v64 + v40.comboPoints * (p39.combo - 1) * p39.level
		end
		if #v48 >= 4 then
			p39.blasts = p39.blasts + 1
		end
		p39.score = p39.score + v64
		p39.lines = p39.lines + #v48
		local v65 = p39.events
		local v66 = {
			["kind"] = "clear",
			["rows"] = nil,
			["count"] = nil,
			["points"] = nil,
			["combo"] = nil,
			["rows"] = v48 or {},
			["count"] = v48 and #v48 or 0,
			["points"] = v64 or 0,
			["combo"] = p39.combo
		}
		table.insert(v65, v66)
		local v67 = 1 + p39.lines // v40.linesPerLevel
		if p39.level < v67 then
			p39.level = v67
			local v68 = p39.events
			local v69 = {
				["kind"] = "level",
				["rows"] = nil,
				["count"] = 0,
				["points"] = 0,
				["combo"] = nil,
				["rows"] = {},
				["combo"] = p39.combo
			}
			table.insert(v68, v69)
		end
	else
		p39.combo = 0
	end
	if #v48 == 0 and v42 <= p39.hidden then
		local v70 = false
		for _, v71 in v_u_4[v41.kind][v41.rot] do
			if v41.y + v71[2] <= p39.hidden then
				continue
			end
			v70 = true
		end
		if not v70 then
			p39.over = true
			p39.reason = "top"
			local v72 = p39.events
			local v73 = {
				["kind"] = "over",
				["rows"] = nil,
				["count"] = 0,
				["points"] = 0,
				["combo"] = nil,
				["rows"] = {},
				["combo"] = p39.combo
			}
			table.insert(v72, v73)
			return
		end
	end
	v_u_31(p39)
end
function v_u_3.act(p75, p76) -- name: act
	-- upvalues: (copy) v_u_3, (copy) v_u_16, (copy) v_u_2, (copy) v_u_5, (copy) v_u_74
	if p75.over then
		return false
	end
	local v77 = p75.piece
	if p76 == v_u_3.LEFT or p76 == v_u_3.RIGHT then
		local v78 = p76 == v_u_3.LEFT and -1 or 1
		if not v_u_16(p75, v77.kind, v77.rot, v77.x + v78, v77.y) then
			return false
		end
		v77.x = v77.x + v78
		if p75.rest > 0 and p75.resets < v_u_2.blocks.lockResets then
			p75.rest = 0
			p75.resets = p75.resets + 1
		end
		local v79 = p75.events
		local v80 = {
			["kind"] = "move",
			["rows"] = nil,
			["count"] = 0,
			["points"] = 0,
			["combo"] = nil,
			["rows"] = {},
			["combo"] = p75.combo
		}
		table.insert(v79, v80)
		return true
	end
	if p76 == v_u_3.ROTATE or p76 == v_u_3.ROTATE_BACK then
		local v81
		if p76 == v_u_3.ROTATE then
			v81 = v77.rot % 4 + 1
		else
			v81 = (v77.rot + 2) % 4 + 1
		end
		for _, v82 in v_u_5 do
			if not v_u_16(p75, v77.kind, v81, v77.x + v82[1], v77.y + v82[2]) then
				continue
			end
			v77.rot = v81
			v77.x = v77.x + v82[1]
			v77.y = v77.y + v82[2]
			if p75.rest > 0 and p75.resets < v_u_2.blocks.lockResets then
				p75.rest = 0
				p75.resets = p75.resets + 1
			end
			local v83 = p75.events
			local v84 = {
				["kind"] = "rotate",
				["rows"] = nil,
				["count"] = 0,
				["points"] = 0,
				["combo"] = nil,
				["rows"] = {},
				["combo"] = p75.combo
			}
			table.insert(v83, v84)
			return true
		end
		return false
	end
	if p76 == v_u_3.SOFT then
		if not v_u_16(p75, v77.kind, v77.rot, v77.x, v77.y + 1) then
			return false
		end
		v77.y = v77.y + 1
		p75.fall = 0
		p75.score = p75.score + v_u_2.blocks.softPoints
		return true
	end
	if p76 ~= v_u_3.HARD then
		return false
	end
	local v85 = v_u_3.dropDistance(p75)
	v77.y = v77.y + v85
	p75.score = p75.score + v_u_2.blocks.hardPoints * v85
	local v86 = p75.events
	local v87 = {
		["kind"] = "drop",
		["rows"] = nil,
		["count"] = 0,
		["points"] = nil,
		["combo"] = nil,
		["rows"] = {},
		["points"] = v85 or 0,
		["combo"] = p75.combo
	}
	table.insert(v86, v87)
	v_u_74(p75)
	return true
end
function v_u_3.gravity(p88) -- name: gravity
	-- upvalues: (copy) v_u_2
	local v89 = v_u_2.blocks.gravity
	local v90 = p88.level
	local v91 = #v89
	return v89[math.min(v90, v91)]
end
function v_u_3.step(p92) -- name: step
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_16, (copy) v_u_74
	if p92.over then
		return
	else
		local v93 = v_u_2.blocks
		p92.tick = p92.tick + 1
		p92.time = p92.tick / v93.tickRate
		if p92.time >= v93.roundSeconds then
			p92.over = true
			p92.reason = "time"
			local v94 = p92.events
			local v95 = {
				["kind"] = "over",
				["rows"] = nil,
				["count"] = 0,
				["points"] = 0,
				["combo"] = nil,
				["rows"] = {},
				["combo"] = p92.combo
			}
			table.insert(v94, v95)
		else
			p92.fall = p92.fall + 1
			if p92.fall >= v_u_3.gravity(p92) then
				p92.fall = 0
				local v96 = p92.piece
				if v_u_16(p92, v96.kind, v96.rot, v96.x, v96.y + 1) then
					v96.y = v96.y + 1
				end
			end
			local v97 = p92.piece
			if v_u_16(p92, v97.kind, v97.rot, v97.x, v97.y + 1) then
				p92.rest = 0
			else
				p92.rest = p92.rest + 1
				if p92.rest >= v93.lockTicks then
					v_u_74(p92)
					return
				end
			end
		end
	end
end
function v_u_3.left(p98) -- name: left
	-- upvalues: (copy) v_u_2
	local v99 = v_u_2.blocks.roundSeconds - p98.time
	return math.max(0, v99)
end
function v_u_3.replay(p100, p101, p102, p103) -- name: replay
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v104 = v_u_3.new(p100)
	local v105 = v_u_2.blocks.tickRate
	local v106 = 1
	while not v104.over and v104.tick < p102 do
		while p101[v106] and p101[v106].tick <= v104.tick do
			if p101[v106].tick == v104.tick then
				v_u_3.act(v104, p101[v106].action)
			end
			v106 = v106 + 1
		end
		if v104.over or p103 < (v104.tick + 1) / v105 then
			break
		end
		v_u_3.step(v104)
		table.clear(v104.events)
	end
	while not v104.over and (p101[v106] and (p101[v106].tick <= v104.tick and v104.tick <= p102)) do
		if p101[v106].tick == v104.tick then
			v_u_3.act(v104, p101[v106].action)
		end
		v106 = v106 + 1
	end
	return v104
end
return v_u_3