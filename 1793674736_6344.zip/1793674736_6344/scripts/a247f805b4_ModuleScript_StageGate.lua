local v_u_1 = require(script.Parent.Parent.Config.Stages)
return {
	["need"] = function(p2, p3, p4, p5) -- name: need
		-- upvalues: (copy) v_u_1
		if p3 <= p4 then
			return nil
		else
			local v6 = v_u_1.forWorld(p2)[p3]
			if v6 then
				v6 = v6.needWins
			end
			if v6 and p5 < v6 then
				return v6
			else
				return nil
			end
		end
	end
}