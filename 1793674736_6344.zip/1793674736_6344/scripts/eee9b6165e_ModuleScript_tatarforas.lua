local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.TatarEye,
	v_u_7.TatarVeins,
	v_u_7.HollowRing,
	v_u_7.FxSmoke,
	v_u_7.FxTwinkle
})
local v_u_8 = Color3.fromHex("A05CFF")
local v_u_9 = Color3.fromRGB(60, 10, 110)
local v_u_10 = Color3.fromRGB(12, 6, 20)
local v_u_11 = Color3.fromRGB(230, 220, 255)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(226, 220, 206)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.Material.SmoothPlastic
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_17 = CFrame.Angles(-1.5707963267948966, 0, 0)
local function v_u_22(p18, p19, p20) -- name: wedge
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v21 = Instance.new("WedgePart")
	v21.Anchored = true
	v21.CanCollide = false
	v21.CanQuery = false
	v21.CanTouch = false
	v21.CastShadow = false
	v21.Color = p18
	v21.Material = p19
	v21.Size = Vector3.new(0.1, 0.1, 0.1)
	v21.CFrame = CFrame.new(0, -500, 0)
	v21.Parent = v_u_4.folder()
	v_u_1:AddItem(v21, p20)
	return v21
end
local function v_u_29(p23, p24, p25, p26) -- name: newBlade
	-- upvalues: (copy) v_u_22, (copy) v_u_10, (copy) v_u_15, (copy) v_u_9, (copy) v_u_14
	local v27 = {
		["a"] = v_u_22(v_u_10, v_u_15, p26)
	}
	local v28
	if p25 then
		v28 = nil
	else
		v28 = v_u_22(v_u_9, v_u_14, p26)
	end
	v27.b = v28
	v27.wide = p23
	v27.thick = p24
	return v27
end
local function v_u_38(p30, p31, p32) -- name: placeBlade
	local v33 = math.max(p32, 0.05)
	local v34 = p30.thick
	local v35 = p30.wide / 2
	local v36 = Vector3.new(v34, v33, v35)
	local v37 = p30.b
	if v37 then
		p30.a.Size = v36
		p30.a.CFrame = p31 * CFrame.new(0, v33 / 2, -p30.wide / 4)
		v37.Size = v36
		v37.CFrame = p31 * CFrame.new(0, v33 / 2, p30.wide / 4) * CFrame.Angles(0, 3.141592653589793, 0)
	else
		p30.a.Size = v36
		p30.a.CFrame = p31 * CFrame.new(0, v33 / 2, 0)
	end
end
local function v_u_52(p39, p40) -- name: seq
	local v41 = -1
	local v42 = {}
	local v43 = p40 or 1
	for v44, v45 in p39 do
		local v46 = v45[1]
		local v47 = math.clamp(v46, 0, 1)
		local v48 = v44 == 1 and 0 or (v44 == #p39 and 1 or v47)
		if v48 <= v41 then
			local v49 = v41 + 0.001
			v48 = math.min(v49, 1)
		end
		if v48 <= v41 then
			continue
		end
		local v50 = NumberSequenceKeypoint.new
		local v51 = v45[2] * v43
		table.insert(v42, v50(v48, v51))
		v41 = v48
	end
	return NumberSequence.new(v42)
end
local function v_u_58(p53, p54) -- name: flat
	-- upvalues: (copy) v_u_3, (copy) v_u_52, (copy) v_u_16, (copy) v_u_1
	local v55 = Instance.new("Attachment")
	v55.WorldCFrame = CFrame.new(p53)
	v55.Parent = v_u_3.Terrain
	local v56 = Instance.new("ParticleEmitter")
	v56.Enabled = false
	v56.Texture = p54.image
	v56.Color = ColorSequence.new(p54.color)
	v56.LightEmission = p54.emission
	v56.LightInfluence = 0
	v56.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v56.EmissionDirection = Enum.NormalId.Top
	v56.SpreadAngle = Vector2.zero
	v56.Speed = NumberRange.new(0.01)
	v56.Size = v_u_52(p54.sizes, 0.5)
	v56.Transparency = v_u_52(p54.alphas)
	local v57 = p54.squash
	if v57 then
		v56.Squash = v_u_52(v57)
	end
	v56.Lifetime = NumberRange.new(p54.life)
	v56.Rotation = NumberRange.new(p54.rot or math.random() * 360)
	v56.RotSpeed = NumberRange.new(p54.spin or 0)
	if p54.flip then
		v56.FlipbookLayout = v_u_16
		v56.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v56.Parent = v55
	v56:Emit(1)
	v_u_1:AddItem(v55, p54.life + 0.3)
end
local function v_u_66(p59, p60, p61, p62, p63, p64) -- name: veins
	-- upvalues: (copy) v_u_58, (copy) v_u_7, (copy) v_u_8
	local v65 = p62 + p63 + p64
	v_u_58(p59, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.25,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["spin"] = 4,
		["image"] = v_u_7.TatarVeins,
		["color"] = v_u_8,
		["life"] = v65,
		["sizes"] = {
			{ 0, p60 },
			{ p62 / v65, p61 },
			{ 1, p61 * 1.08 }
		},
		["alphas"] = {
			{ 0, 0.4 },
			{ p62 / v65, 0.1 },
			{ (p62 + p63) / v65, 0.2 },
			{ 1, 1 }
		}
	})
end
local function v_u_71(p67, p68, p69, p70) -- name: tremor
	-- upvalues: (copy) v_u_58, (copy) v_u_7, (copy) v_u_8
	v_u_58(p67, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.15,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["flip"] = true,
		["image"] = v_u_7.HollowRing,
		["color"] = p70 or v_u_8,
		["life"] = p69,
		["sizes"] = {
			{ 0, p68 * 0.75 },
			{ 1, p68 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 1, 0.2 }
		}
	})
end
local function v_u_84(p72, p73, p74, p75, p76, p77) -- name: groundEye
	-- upvalues: (copy) v_u_58, (copy) v_u_7, (copy) v_u_12
	local v78 = p74 / p76
	local v79 = p74 + 0.2
	local v80 = math.min(v79, p75) / p76
	local v81 = p75 / p76
	local v82 = p75 + 0.22
	local v83 = math.min(v82, p76) / p76
	v_u_58(p72, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.05,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["squash"] = nil,
		["rot"] = nil,
		["image"] = v_u_7.TatarEye,
		["color"] = v_u_12,
		["life"] = p76,
		["sizes"] = {
			{ 0, p73 },
			{ 1, p73 }
		},
		["alphas"] = {
			{ 0, 0.15 },
			{ v78, 0 },
			{ v83, 0 },
			{ 1, 1 }
		},
		["squash"] = {
			{ 0, -3 },
			{ v78, -3 },
			{ v80, 0 },
			{ v81, 0 },
			{ v83, -3 },
			{ 1, -3 }
		},
		["rot"] = p77 or 0
	})
end
local function v_u_92(p85, p86, p87, p88, p89) -- name: smokePuff
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_16, (copy) v_u_9, (copy) v_u_10, (copy) v_u_52, (copy) v_u_1
	local v90 = Instance.new("Attachment")
	v90.WorldPosition = p85
	v90.Parent = v_u_3.Terrain
	local v91 = Instance.new("ParticleEmitter")
	v91.Enabled = false
	v91.Texture = v_u_7.FxSmoke
	v91.FlipbookLayout = v_u_16
	v91.FlipbookMode = Enum.ParticleFlipbookMode.Random
	v91.Color = ColorSequence.new(v_u_9, v_u_10)
	v91.LightEmission = 0
	v91.LightInfluence = 0
	v91.Lifetime = NumberRange.new(p89 * 0.7, p89)
	v91.Size = NumberSequence.new(p87 * 0.6, p87 * 1.4)
	v91.Transparency = v_u_52({
		{ 0, 0.1 },
		{ 0.6, 0.3 },
		{ 1, 1 }
	})
	v91.Speed = NumberRange.new(p88 * 0.4, p88)
	v91.Drag = 3
	v91.SpreadAngle = Vector2.new(180, 30)
	v91.EmissionDirection = Enum.NormalId.Top
	v91.Rotation = NumberRange.new(0, 360)
	v91.RotSpeed = NumberRange.new(-60, 60)
	v91.Parent = v90
	v91:Emit(p86)
	v_u_1:AddItem(v90, p89 + 0.3)
end
local function v_u_101(p93, p94) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1
	local v95 = v_u_2:FindFirstChild("EyePieces")
	if v95 then
		v95 = v95:FindFirstChild("w7_tatarforas")
	end
	if not (v95 and v95:IsA("MeshPart")) then
		return nil
	end
	local v96 = v95:Clone()
	local v97 = v95.Size
	local v98 = v95.Size.X
	local v99 = v95.Size.Y
	local v100 = v95.Size.Z
	v96.Size = v97 * (p93 / math.max(v98, v99, v100, 0.01))
	v96.Anchored = true
	v96.CanCollide = false
	v96.CanQuery = false
	v96.CanTouch = false
	v96.CastShadow = false
	v96.CFrame = CFrame.new(0, -500, 0)
	v96.Parent = v_u_4.folder()
	v_u_1:AddItem(v96, p94)
	return v96
end
return function(p_u_102)
	-- upvalues: (copy) v_u_8, (copy) v_u_11, (copy) v_u_10, (copy) v_u_71, (copy) v_u_4, (copy) v_u_1, (copy) v_u_29, (copy) v_u_22, (copy) v_u_15, (copy) v_u_9, (copy) v_u_38, (copy) v_u_66, (copy) v_u_84, (copy) v_u_3, (copy) v_u_101, (copy) v_u_17, (copy) v_u_7, (copy) v_u_16, (copy) v_u_6, (copy) v_u_14, (copy) v_u_58, (copy) v_u_52, (copy) v_u_13, (copy) v_u_92
	local v103 = {}
	local function v_u_107(p104, p105) -- name: fearCast
		-- upvalues: (copy) p_u_102, (ref) v_u_8, (ref) v_u_11, (ref) v_u_10, (ref) v_u_71, (ref) v_u_4
		local v106 = p104.size
		p_u_102.burst("Flash", p104.eye, v_u_8, (p105 and 0.3 or 0.2) * v106)
		p_u_102.glint(p104.eye + p104.dir * 0.8, v_u_11, (p105 and 4 or 3) * v106, 0.16)
		if not p104.lite then
			p_u_102.spikes(p104.eye, v_u_10, p105 and 6 or 4, 3.5 * v106, 0.16, p104.dir, 0.6)
		end
		v_u_71(p_u_102.ground(p104.feet, 0.12), (p105 and 10 or 7) * v106, 0.5)
		if p104.mine then
			v_u_4.shake(p105 and 0.14 or 0.07, 0.14)
		end
	end
	v103.tatarforas_a = {
		["cast"] = nil,
		["shot"] = nil,
		["keep"] = 0.22,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p108) -- name: cast
			-- upvalues: (copy) p_u_102, (ref) v_u_8, (ref) v_u_10
			local v109 = p108.size
			local v110 = p108.eye + p108.dir * 1.2
			p_u_102.glint(v110, v_u_8, 2.4 * v109, 0.1)
			if not p108.lite then
				p_u_102.spikes(v110, v_u_10, 3, 2.8 * v109, 0.1, p108.dir, 0.3)
			end
		end,
		["shot"] = function(p111, p112) -- name: thornShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_29, (ref) v_u_22, (ref) v_u_10, (ref) v_u_15, (copy) p_u_102, (ref) v_u_9, (ref) v_u_38
			local v_u_113 = p111.size
			local v_u_114 = 5.6 * v_u_113
			local v_u_115 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p112, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_115, 3)
			local v_u_116 = v_u_29(1 * v_u_113, 0.3 * v_u_113, p111.lite, 3)
			local v_u_117 = {}
			if not p111.lite then
				local v118 = 0.5 * v_u_113
				local v119 = 0.18 * v_u_113
				local v120 = {
					["a"] = nil,
					["b"] = nil,
					["wide"] = nil,
					["thick"] = nil,
					["a"] = v_u_22(v_u_10, v_u_15, 3),
					["wide"] = v118,
					["thick"] = v119
				}
				table.insert(v_u_117, v120)
				local v121 = 0.5 * v_u_113
				local v122 = 0.18 * v_u_113
				local v123 = {
					["a"] = nil,
					["b"] = nil,
					["wide"] = nil,
					["thick"] = nil,
					["a"] = v_u_22(v_u_10, v_u_15, 3),
					["wide"] = v121,
					["thick"] = v122
				}
				table.insert(v_u_117, v123)
				local v124 = 0.5 * v_u_113
				local v125 = 0.18 * v_u_113
				local v126 = {
					["a"] = nil,
					["b"] = nil,
					["wide"] = nil,
					["thick"] = nil,
					["a"] = v_u_22(v_u_10, v_u_15, 3),
					["wide"] = v124,
					["thick"] = v125
				}
				table.insert(v_u_117, v126)
			end
			p_u_102.streak(v_u_115, v_u_8, v_u_9, 0.55 * v_u_113, 0.16)
			if p111.mine then
				p_u_102.light(v_u_115, v_u_8, 7 * v_u_113)
			end
			local v_u_127 = false
			return {
				["place"] = function(p128, p129) -- name: place
					-- upvalues: (copy) v_u_115, (copy) v_u_114, (ref) v_u_38, (copy) v_u_116, (copy) v_u_117, (copy) v_u_113
					v_u_115.CFrame = p128
					local v130 = p128 * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, p129 * 16, 0) * CFrame.new(0, -v_u_114 * 0.55, 0)
					v_u_38(v_u_116, v130, v_u_114)
					for v131, v132 in v_u_117 do
						v_u_38(v132, v130 * CFrame.Angles(0, v131 * 3.141592653589793 * 2 / 3, 0) * CFrame.new(0, v_u_114 * 0.3, 0) * CFrame.Angles(2.530727415391778, 0, 0), 1.4 * v_u_113)
					end
				end,
				["stop"] = function(p133) -- name: stop
					-- upvalues: (ref) v_u_127, (copy) v_u_115, (ref) v_u_1, (copy) v_u_116, (copy) v_u_117, (ref) v_u_4
					if v_u_127 then
						return
					else
						v_u_127 = true
						local v134 = v_u_115:FindFirstChildWhichIsA("PointLight")
						if v134 then
							v134:Destroy()
						end
						v_u_1:AddItem(v_u_115, 0.3)
						local v135 = v_u_116
						local v136 = { v135.a }
						local v137 = v135.b
						if v137 then
							table.insert(v136, v137)
						end
						for _, v138 in v_u_117 do
							local v139 = { v138.a }
							local v140 = v138.b
							if v140 then
								table.insert(v139, v140)
							end
							for _, v141 in v139 do
								table.insert(v136, v141)
							end
						end
						local v142 = p133 or 0
						if v142 > 0 then
							for _, v143 in v136 do
								v_u_4.tween(v143, v142, {
									["Transparency"] = 1
								})
								v_u_1:AddItem(v143, v142 + 0.05)
							end
						else
							for _, v144 in v136 do
								v144:Destroy()
							end
						end
					end
				end
			}
		end,
		["impact"] = function(p145, p146) -- name: impact
			-- upvalues: (copy) p_u_102, (ref) v_u_66, (ref) v_u_71, (ref) v_u_84, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11
			local v147 = p145.size
			local v148 = p_u_102.ground(p146, 0.1)
			v_u_66(v148, 2 * v147, 11 * v147, 0.22, 0.3, 0.45)
			v_u_71(v148 + Vector3.new(0, 0.03, 0), 7.5 * v147, 0.45)
			if not p145.lite then
				local v149 = v_u_84
				local v150 = v148 + Vector3.new(0, 0.06, 0)
				local v151 = 4.6 * v147
				local v152 = p145.dir
				local v153 = v152.X
				local v154 = -v152.Z
				local v155 = math.atan2(v153, v154)
				v149(v150, v151, 0.02, 0.45, 0.75, (math.deg(v155)))
				p_u_102.spikes(p146, v_u_10, 4, 3 * v147, 0.16)
				local v156 = { v_u_10, v_u_9 }
				p_u_102.chunks(p146, v156, 3, 14 * v147, 0.35 * v147, 0.5, false, 0.7)
			end
			p_u_102.glint(p146, v_u_11, 2.6 * v147, 0.14)
			p_u_102.hitSound(p146)
		end,
		["hit"] = function(_, p157, _) -- name: hit
			-- upvalues: (copy) p_u_102, (ref) v_u_8
			p_u_102.burst("Impact", p157, v_u_8, 0.55)
		end
	}
	local function v_u_197(p158, p159, p160) -- name: crown
		-- upvalues: (ref) v_u_3, (copy) p_u_102, (ref) v_u_8, (ref) v_u_101, (ref) v_u_22, (ref) v_u_10, (ref) v_u_15, (ref) v_u_9, (ref) v_u_17
		local v161 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_162
		if v161 then
			v_u_162 = v161:FindFirstChild("Foe" .. p160)
		else
			v_u_162 = nil
		end
		if v_u_162 then
			v_u_162 = v_u_162:FindFirstChild("Head")
		end
		local v_u_163 = p158.ability.freeze or 3
		if v_u_162 and v_u_162:IsA("BasePart") then
			local v164 = v_u_162.Size.X * 2.4
			local v_u_165 = math.clamp(v164, 2.2, 6)
			local v166 = v_u_163 + 1
			local v_u_167 = {}
			local v_u_168 = v_u_101(v_u_165, v166)
			local v_u_169 = {}
			if v_u_168 then
				table.insert(v_u_167, v_u_168)
			else
				for _ = 1, 6 do
					local v170 = v_u_22(v_u_10, v_u_15, v166)
					local v171 = v_u_165 * 0.32
					local v172 = v_u_165 * 0.14
					v170.Size = Vector3.new(0.12, v171, v172)
					table.insert(v_u_169, v170)
					table.insert(v_u_167, v170)
				end
			end
			local v_u_173 = os.clock()
			local v_u_174 = 0.25
			local function v_u_178(p175) -- name: gone
				-- upvalues: (ref) p_u_102, (ref) v_u_10, (ref) v_u_9, (copy) v_u_167
				if p175 then
					local v176 = { v_u_10, v_u_9 }
					p_u_102.chunks(p175, v176, 4, 10, 0.3, 0.55, false, 0.5)
				end
				for _, v177 in v_u_167 do
					v177:Destroy()
				end
			end
			p_u_102.frame(function()
				-- upvalues: (copy) v_u_173, (copy) v_u_162, (ref) v_u_3, (copy) v_u_167, (copy) v_u_163, (copy) v_u_178, (copy) v_u_168, (ref) v_u_17, (copy) v_u_169, (copy) v_u_165, (ref) v_u_174, (ref) p_u_102, (ref) v_u_8
				local v179 = os.clock() - v_u_173
				if not (v_u_162.Parent and v_u_162:IsDescendantOf(v_u_3)) then
					for _, v180 in v_u_167 do
						v180:Destroy()
					end
					return false
				end
				local v181 = v_u_162.Position + Vector3.new(0, 1, 0) * (v_u_162.Size.Y * 0.5 + 0.15)
				if v_u_163 + 0.1 <= v179 then
					v_u_178(v181)
					return false
				end
				local v182 = v179 / 0.12
				local v183 = math.clamp(v182, 0, 1) - 1
				local v184 = 1 - (v183 * 2.7 * v183 * v183 + 1 + v183 * 1.7 * v183)
				local v185 = v179 > 0.12 and 0.07 or 0
				local v186 = (math.random() - 0.5) * 2 * v185
				local v187 = (math.random() - 0.5) * v185
				local v188 = (math.random() - 0.5) * 2 * v185
				local v189 = Vector3.new(v186, v187, v188)
				local v190 = CFrame.new(v181 + Vector3.new(0, 1, 0) * v184 * 3 + v189) * CFrame.Angles((math.random() - 0.5) * v185, v179 * 0.8, (math.random() - 0.5) * v185)
				if v_u_168 then
					v_u_168.CFrame = v190 * CFrame.new(0, v_u_168.Size.Z * 0.15, 0) * v_u_17
				else
					for v191, v192 in v_u_169 do
						local v193 = v191 * 3.141592653589793 / 3
						local v194 = math.cos(v193)
						local v195 = math.sin(v193)
						local v196 = Vector3.new(v194, 0, v195)
						v192.CFrame = v190 * CFrame.new(v196 * v_u_165 * 0.38 + Vector3.new(0, 1, 0) * v_u_165 * 0.12) * CFrame.lookAt(Vector3.new(0, 0, 0), v196).Rotation * CFrame.Angles(0.35, 1.5707963267948966, 0)
					end
				end
				if v_u_174 <= v179 then
					v_u_174 = v179 + 0.32
					p_u_102.spikes(v_u_162.Position, v_u_8, 2, 1.8, 0.14, nil, nil, true)
				end
				return true
			end)
		else
			p_u_102.burst("Impact", p159, v_u_8, 0.7)
		end
	end
	v103.tatarforas_e = {
		["cast"] = function(p198) -- name: cast
			-- upvalues: (copy) v_u_107
			v_u_107(p198, false)
		end,
		["windup"] = function(p199, p200, p201) -- name: windup
			-- upvalues: (copy) p_u_102, (ref) v_u_84, (ref) v_u_9
			local v202 = p199.size
			local v203 = p199.ability.radius * v202
			local v204 = p199.ability.freeze or 3
			local v205 = p_u_102.ground(p200, 0.1)
			local v206 = math.max(p201, 0.12)
			local v207 = v_u_84
			local v208 = v205 + Vector3.new(0, 0.05, 0)
			local v209 = v203 * 2
			local v210 = v206 + v204
			local v211 = v206 + v204 + 0.45
			local v212 = p199.dir
			local v213 = v212.X
			local v214 = -v212.Z
			local v215 = math.atan2(v213, v214)
			v207(v208, v209, v206, v210, v211, (math.deg(v215)))
			p_u_102.inward(v205 + Vector3.new(0, 1.5, 0), v_u_9, p199.lite and 4 or 8, v203, v206)
		end,
		["land"] = function(p216, p217) -- name: land
			-- upvalues: (copy) p_u_102, (ref) v_u_66, (ref) v_u_71, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_16, (ref) v_u_6
			local v_u_218 = p216.size
			local v_u_219 = p216.ability.radius * v_u_218
			local v220 = p216.ability.freeze or 3
			local v_u_221 = p_u_102.ground(p217, 0.08)
			v_u_66(v_u_221, v_u_219 * 0.8, v_u_219 * 2.4, 0.3, v220 - 0.3, 0.5)
			v_u_71(v_u_221 + Vector3.new(0, 0.04, 0), v_u_219 * 2.4, 0.6)
			p_u_102.glint(v_u_221 + Vector3.new(0, 1.2, 0), v_u_11, 7 * v_u_218, 0.25)
			p_u_102.after(1.5, function()
				-- upvalues: (ref) p_u_102, (copy) v_u_221, (ref) v_u_11, (copy) v_u_218
				p_u_102.glint(v_u_221 + Vector3.new(0, 1.2, 0), v_u_11, 5 * v_u_218, 0.2)
			end)
			local v222 = v_u_4.part
			local v223 = v_u_219 * 1.4
			local v224 = v_u_219 * 0.45
			local v225 = Vector3.new(v223, 0.4, v224)
			local v226 = CFrame.new(v_u_221 + Vector3.new(0, 0.3, 0))
			local v227 = CFrame.Angles
			local v228 = p216.dir
			local v229 = v228.X
			local v230 = -v228.Z
			local v231 = math.atan2(v229, v230)
			local v232 = math.deg(v231)
			local v233 = v222(v225, v226 * v227(0, -math.rad(v232), 0), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v233, v220 + 1.5)
			local v_u_234 = Instance.new("ParticleEmitter")
			v_u_234.Texture = v_u_7.FxTwinkle
			v_u_234.FlipbookLayout = v_u_16
			v_u_234.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_234.Color = ColorSequence.new(v_u_8, v_u_11)
			v_u_234.LightEmission = 0.6
			v_u_234.LightInfluence = 0
			v_u_234.Lifetime = NumberRange.new(0.8, 1.3)
			v_u_234.Size = NumberSequence.new(0.9 * v_u_218, 0.3 * v_u_218)
			v_u_234.Speed = NumberRange.new(5, 10)
			v_u_234.EmissionDirection = Enum.NormalId.Top
			v_u_234.SpreadAngle = Vector2.new(8, 8)
			v_u_234.Shape = Enum.ParticleEmitterShape.Box
			v_u_234.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_234.Rate = p216.lite and 10 or 28
			v_u_234.Parent = v233
			task.delay(v220 - 0.2, function()
				-- upvalues: (copy) v_u_234
				v_u_234.Enabled = false
			end)
			v_u_6.play("Hit", {
				["at"] = v_u_221,
				["volume"] = p216.mine and 0.7 or 0.4
			})
			if p216.mine then
				v_u_4.shake(0.2, 0.2)
			end
			p_u_102.after(v220 + 0.05, function()
				-- upvalues: (ref) v_u_71, (copy) v_u_221, (copy) v_u_219
				v_u_71(v_u_221 + Vector3.new(0, 0.04, 0), v_u_219 * 1.6, 0.45)
			end)
		end,
		["hit"] = function(p235, p236, p237) -- name: hit
			-- upvalues: (copy) p_u_102, (ref) v_u_8, (copy) v_u_197
			if p235.lite then
				p_u_102.burst("Impact", p236, v_u_8, 0.6)
			else
				v_u_197(p235, p236, p237)
			end
		end
	}
	local v_u_238 = {}
	setmetatable(v_u_238, {
		["__mode"] = "k"
	})
	local function v_u_249(p239) -- name: placeCage
		-- upvalues: (ref) v_u_17, (ref) v_u_38
		local v240 = CFrame.new(p239.g + Vector3.new(0, 1, 0) * p239.y) * CFrame.Angles(0, p239.spin, 0)
		local v241 = p239.piece
		if v241 then
			v241.CFrame = v240 * v_u_17
		else
			local v242 = #p239.blades
			for v243, v244 in p239.blades do
				local v245 = v243 * 3.141592653589793 * 2 / v242
				local v246 = math.cos(v245)
				local v247 = math.sin(v245)
				local v248 = Vector3.new(v246, 0, v247)
				v_u_38(v244, v240 * CFrame.new(v248 * p239.R * p239.scale) * CFrame.lookAt(Vector3.new(0, 0, 0), -v248).Rotation * CFrame.Angles(0.45, 1.5707963267948966, 0) * CFrame.new(0, -1, 0), (v243 % 2 * 2 + 5) * p239.scale)
			end
		end
	end
	local function v_u_279(p250, p251) -- name: stab
		-- upvalues: (ref) v_u_22, (ref) v_u_10, (ref) v_u_15, (ref) v_u_9, (ref) v_u_14, (copy) p_u_102, (ref) v_u_38
		local v252 = math.random() * 3.141592653589793 * 2
		local v253 = p250.R * p250.scale * 0.95
		local v254 = math.cos(v252)
		local v255 = math.sin(v252)
		local v256 = Vector3.new(v254, 0, v255)
		local v257 = p250.g + v256 * v253 + Vector3.new(0, 1, 0) * (1 + math.random() * 1.6)
		local v258 = -v256
		local v259 = (math.random() - 0.5) * 0.3
		local v260 = (math.random() - 0.5) * 0.3
		local v261 = (v258 + Vector3.new(v259, -0.05, v260)).Unit
		local v_u_262 = {
			["a"] = nil,
			["b"] = nil,
			["wide"] = 1.1,
			["thick"] = 0.25,
			["a"] = v_u_22(v_u_10, v_u_15, 1)
		}
		local v263
		if p251 then
			v263 = nil
		else
			v263 = v_u_22(v_u_9, v_u_14, 1)
		end
		v_u_262.b = v263
		local v264 = (Vector3.new(0, 1, 0)):Cross(v261).Unit
		local v_u_265 = CFrame.fromMatrix(v257, v261:Cross(v264).Unit, v261)
		local v_u_266 = v253 * (0.6 + math.random() * 0.25)
		p_u_102.animate(0.32, 0, function(p267)
			-- upvalues: (copy) v_u_266, (ref) v_u_38, (copy) v_u_262, (copy) v_u_265
			local v268
			if p267 < 0.25 then
				local v269 = v_u_266
				local v270 = p267 / 0.25
				local v271 = math.clamp(v270, 0, 1) - 1
				v268 = v269 * (v271 * 2.7 * v271 * v271 + 1 + v271 * 1.7 * v271)
			elseif p267 < 0.55 then
				v268 = v_u_266
			else
				local v272 = v_u_266
				local v273 = (p267 - 0.55) / 0.45
				local v274 = math.clamp(v273, 0, 1)
				v268 = v272 * (1 - v274 * v274 * (3 - v274 * 2))
			end
			v_u_38(v_u_262, v_u_265, v268)
			if p267 >= 1 then
				local v275 = v_u_262
				local v276 = { v275.a }
				local v277 = v275.b
				if v277 then
					table.insert(v276, v277)
				end
				for _, v278 in v276 do
					v278:Destroy()
				end
			end
		end)
	end
	v103.tatarforas_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p280) -- name: cast
			-- upvalues: (copy) v_u_107
			v_u_107(p280, true)
		end,
		["windup"] = function(p281, p282, p283) -- name: windup
			-- upvalues: (copy) p_u_102, (ref) v_u_58, (ref) v_u_7, (ref) v_u_10, (ref) v_u_9
			local v284 = p281.size
			local v285 = p281.ability.radius * v284
			local v286 = p_u_102.ground(p282, 0.06)
			local v287 = math.max(p283, 0.12) + 0.2
			v_u_58(v286, {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0,
				["life"] = nil,
				["sizes"] = nil,
				["alphas"] = nil,
				["image"] = v_u_7.Glow,
				["color"] = v_u_10,
				["life"] = v287 + 0.3,
				["sizes"] = {
					{ 0, v285 * 0.6 },
					{ v287 / (v287 + 0.3), v285 * 2.3 },
					{ 1, v285 * 2.3 }
				},
				["alphas"] = {
					{ 0, 0.9 },
					{ v287 / (v287 + 0.3), 0.45 },
					{ 1, 1 }
				}
			})
			p_u_102.inward(v286 + Vector3.new(0, 2, 0), v_u_9, p281.lite and 4 or 10, v285, (math.max(p283, 0.12)))
		end,
		["zone"] = function(p_u_288, p289, p_u_290) -- name: zone
			-- upvalues: (copy) p_u_102, (ref) v_u_101, (ref) v_u_29, (copy) v_u_238, (copy) v_u_249, (ref) v_u_66, (ref) v_u_4, (ref) v_u_10, (ref) v_u_1, (ref) v_u_7, (ref) v_u_16, (ref) v_u_9, (ref) v_u_52, (ref) v_u_71, (ref) v_u_13, (ref) v_u_92, (ref) v_u_6, (copy) v_u_279
			local v_u_291 = p_u_288.size
			local v_u_292 = p_u_288.lite
			local v_u_293 = p_u_288.ability.radius * v_u_291
			local v_u_294 = p_u_102.ground(p289, 0)
			local v295 = p_u_290 + 2
			local v_u_296 = {
				["piece"] = nil,
				["blades"] = nil,
				["g"] = nil,
				["R"] = nil,
				["scale"] = 1,
				["spin"] = nil,
				["y"] = 28,
				["shut"] = false,
				["piece"] = v_u_101(v_u_293 * 2.1, v295),
				["blades"] = {},
				["g"] = v_u_294,
				["R"] = v_u_293,
				["spin"] = math.random() * 3.141592653589793 * 2
			}
			if not v_u_296.piece then
				for _ = 1, v_u_292 and 8 or 12 do
					local v297 = v_u_296.blades
					local v298 = v_u_29(1.6 * v_u_291, 0.35 * v_u_291, v_u_292, v295)
					table.insert(v297, v298)
				end
			end
			local v_u_299 = v_u_296.spin
			v_u_238[p_u_288] = v_u_296
			v_u_249(v_u_296)
			v_u_66(v_u_294 + Vector3.new(0, 0.08, 0), v_u_293 * 0.6, v_u_293 * 2.1, 0.35, p_u_290 - 0.35, 0.5)
			local v300 = v_u_4.part(Vector3.new(v_u_293, 2, v_u_293), CFrame.new(v_u_294 + Vector3.new(0, 4, 0)), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v300, v295)
			local v_u_301 = Instance.new("ParticleEmitter")
			v_u_301.Texture = v_u_7.FxSmoke
			v_u_301.FlipbookLayout = v_u_16
			v_u_301.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_301.Color = ColorSequence.new(v_u_9, v_u_10)
			v_u_301.LightEmission = 0
			v_u_301.LightInfluence = 0
			v_u_301.Lifetime = NumberRange.new(1, 1.5)
			v_u_301.Size = NumberSequence.new(3.5 * v_u_291, 7 * v_u_291)
			v_u_301.Transparency = v_u_52({
				{ 0, 1 },
				{ 0.15, 0.15 },
				{ 0.7, 0.3 },
				{ 1, 1 }
			})
			v_u_301.Speed = NumberRange.new(1, 3)
			v_u_301.EmissionDirection = Enum.NormalId.Top
			v_u_301.SpreadAngle = Vector2.new(60, 60)
			v_u_301.Acceleration = Vector3.new(0, 1, 0)
			v_u_301.Rotation = NumberRange.new(0, 360)
			v_u_301.RotSpeed = NumberRange.new(-40, 40)
			v_u_301.Shape = Enum.ParticleEmitterShape.Box
			v_u_301.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_301.Rate = v_u_292 and 10 or 30
			v_u_301.Parent = v300
			local v_u_302 = os.clock()
			local v_u_303 = false
			local v_u_304 = 0.3
			local v_u_305 = false
			p_u_102.frame(function()
				-- upvalues: (ref) v_u_305, (copy) v_u_296, (copy) v_u_302, (copy) v_u_291, (ref) v_u_303, (ref) v_u_71, (copy) v_u_294, (copy) v_u_293, (copy) v_u_292, (ref) p_u_102, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (ref) v_u_92, (ref) v_u_6, (copy) p_u_288, (ref) v_u_4, (copy) p_u_290, (copy) v_u_299, (ref) v_u_249, (ref) v_u_304, (ref) v_u_279
				if v_u_305 or v_u_296.shut then
					return false
				end
				local v306 = os.clock() - v_u_302
				local v307 = v306 / 0.2
				local v308 = math.clamp(v307, 0, 1)
				v_u_296.y = 28 + (0.7 * v_u_291 - 28) * v308 * v308
				if v308 >= 1 and not v_u_303 then
					v_u_303 = true
					v_u_71(v_u_294 + Vector3.new(0, 0.05, 0), v_u_293 * 2.6, 0.55)
					if not v_u_292 then
						local v309 = { v_u_10, v_u_9, v_u_13 }
						p_u_102.chunks(v_u_294 + Vector3.new(0, 0.5, 0), v309, 10, 24, 0.5 * v_u_291, 0.8, false, 0.7)
						v_u_92(v_u_294 + Vector3.new(0, 0.5, 0), 10, 4 * v_u_291, 18, 0.9)
					end
					v_u_6.play("Hit", {
						["at"] = v_u_294,
						["volume"] = p_u_288.mine and 0.8 or 0.45
					})
					if p_u_288.mine then
						v_u_4.shake(0.25, 0.25)
					end
				end
				local v310 = v306 - 0.2
				local v311 = p_u_290 - 0.2
				local v312 = v310 / math.max(v311, 0.1)
				local v313 = math.clamp(v312, 0, 1)
				local v314 = v313 * v313 * (3 - v313 * 2)
				v_u_296.scale = 1 - v314 * 0.45
				v_u_296.spin = v_u_299 + v306 * (v314 * 1.2 + 0.7)
				local v315 = v_u_296.piece
				if v315 then
					local v316 = v_u_293 * 2.1 * v_u_296.scale
					local v317 = v315.Size.X
					local v318 = v315.Size.Y
					local v319 = v315.Size.Z
					local v320 = v316 / math.max(v317, v318, v319, 0.01)
					local v321 = v320 - 1
					if math.abs(v321) > 0.01 then
						v315.Size = v315.Size * v320
					end
				end
				v_u_249(v_u_296)
				if v_u_303 and v_u_304 <= v306 then
					v_u_304 = v_u_304 + (p_u_288.ability.tick or 0.4)
					for _ = 1, v_u_292 and 2 or 4 do
						v_u_279(v_u_296, v_u_292)
					end
					v_u_71(v_u_294 + Vector3.new(0, 0.05, 0), v_u_293 * 0.9, 0.4)
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_305, (copy) v_u_301, (ref) p_u_102, (copy) v_u_296
				v_u_305 = true
				v_u_301.Enabled = false
				p_u_102.after(0.6, function()
					-- upvalues: (ref) v_u_296
					if not v_u_296.shut then
						v_u_296.shut = true
						local v322 = v_u_296.piece
						if v322 then
							v322:Destroy()
						end
						for _, v323 in v_u_296.blades do
							local v324 = { v323.a }
							local v325 = v323.b
							if v325 then
								table.insert(v324, v325)
							end
							for _, v326 in v324 do
								v326:Destroy()
							end
						end
					end
				end)
			end
		end,
		["finish"] = function(p_u_327, p328) -- name: finish
			-- upvalues: (copy) p_u_102, (copy) v_u_238, (copy) v_u_249, (ref) v_u_22, (ref) v_u_10, (ref) v_u_15, (ref) v_u_9, (ref) v_u_14, (ref) v_u_38, (ref) v_u_84, (ref) v_u_71, (ref) v_u_66, (ref) v_u_92, (ref) v_u_13, (ref) v_u_11, (ref) v_u_6, (ref) v_u_4
			local v_u_329 = p_u_327.size
			local v_u_330 = p_u_327.lite
			local v_u_331 = p_u_327.ability.radius * v_u_329
			local v_u_332 = p_u_102.ground(p328, 0)
			local v_u_333 = v_u_238[p_u_327]
			if v_u_333 and not v_u_333.shut then
				v_u_333.shut = true
				local v_u_334 = v_u_333.scale
				p_u_102.animate(0.12, 0, function(p335)
					-- upvalues: (copy) v_u_333, (copy) v_u_334, (copy) v_u_331, (ref) v_u_249
					v_u_333.scale = v_u_334 + (0.1 - v_u_334) * p335 * p335
					local v336 = v_u_333.piece
					if v336 then
						local v337 = v_u_331 * 2.1 * v_u_333.scale
						local v338 = v336.Size.X
						local v339 = v336.Size.Y
						local v340 = v336.Size.Z
						local v341 = v337 / math.max(v338, v339, v340, 0.01)
						v336.Size = v336.Size * v341
					end
					v_u_249(v_u_333)
					if p335 >= 1 then
						local v342 = v_u_333.piece
						if v342 then
							v342:Destroy()
						end
						for _, v343 in v_u_333.blades do
							local v344 = { v343.a }
							local v345 = v343.b
							if v345 then
								table.insert(v344, v345)
							end
							for _, v346 in v344 do
								v346:Destroy()
							end
						end
					end
				end)
			end
			p_u_102.after(0.1, function()
				-- upvalues: (copy) v_u_330, (copy) v_u_332, (copy) v_u_329, (ref) v_u_22, (ref) v_u_10, (ref) v_u_15, (ref) v_u_9, (ref) v_u_14, (ref) p_u_102, (ref) v_u_38, (ref) v_u_84, (copy) v_u_331, (copy) p_u_327, (ref) v_u_71, (ref) v_u_66, (ref) v_u_92, (ref) v_u_13, (ref) v_u_11, (ref) v_u_6, (ref) v_u_4
				local v347 = v_u_330 and 5 or 11
				local v348 = math.random() * 3.141592653589793 * 2
				local v_u_349 = {}
				local v_u_350 = {}
				local v_u_351 = {}
				for v352 = 1, v347 do
					local v353 = v352 == 1 and 1 or 0.55 + math.random() * 0.4
					local v354 = v348 + v352 * 2.39996
					local v355 = 1 - v353 * v353
					local v356 = math.max(v355, 0)
					local v357 = math.sqrt(v356)
					local v358 = math.cos(v354) * v357
					local v359 = math.sin(v354) * v357
					local v360 = Vector3.new(v358, v353, v359).Unit
					local v361 = -math.sin(v354)
					local v362 = math.cos(v354)
					local v363 = Vector3.new(v361, 0, v362)
					local v364 = CFrame.fromMatrix
					local v365 = v_u_332 - Vector3.new(0, 1, 0)
					table.insert(v_u_350, v364(v365, v363, v360))
					local v366 = (v352 == 1 and 18 or 9 + math.random() * 6) * v_u_329
					table.insert(v_u_351, v366)
					local v367 = (v352 == 1 and 3.4 or 2.4) * v_u_329
					local v368 = 0.6 * v_u_329
					local v369 = v_u_330
					local v370 = {
						["a"] = v_u_22(v_u_10, v_u_15, 2)
					}
					local v371
					if v369 then
						v371 = nil
					else
						v371 = v_u_22(v_u_9, v_u_14, 2)
					end
					v370.b = v371
					v370.wide = v367
					v370.thick = v368
					table.insert(v_u_349, v370)
				end
				p_u_102.animate(1, 0, function(p372)
					-- upvalues: (copy) v_u_349, (ref) v_u_38, (copy) v_u_350, (copy) v_u_351
					local v373
					if p372 < 0.1 then
						local v374 = p372 / 0.1
						local v375 = math.clamp(v374, 0, 1) - 1
						v373 = v375 * 2.7 * v375 * v375 + 1 + v375 * 1.7 * v375
					elseif p372 < 0.7 then
						v373 = 1
					else
						local v376 = (p372 - 0.7) / 0.3
						local v377 = math.clamp(v376, 0, 1)
						v373 = 1 - v377 * v377 * (3 - v377 * 2)
					end
					for v378, v379 in v_u_349 do
						v_u_38(v379, v_u_350[v378], v_u_351[v378] * v373)
					end
					if p372 >= 1 then
						for _, v380 in v_u_349 do
							local v381 = { v380.a }
							local v382 = v380.b
							if v382 then
								table.insert(v381, v382)
							end
							for _, v383 in v381 do
								v383:Destroy()
							end
						end
					end
				end)
				local v384 = v_u_84
				local v385 = v_u_332 + Vector3.new(0, 0.07, 0)
				local v386 = v_u_331 * 1.1
				local v387 = p_u_327.dir
				local v388 = v387.X
				local v389 = -v387.Z
				local v390 = math.atan2(v388, v389)
				v384(v385, v386, 0.02, 0.7, 1, (math.deg(v390)))
				v_u_71(v_u_332 + Vector3.new(0, 0.05, 0), v_u_331 * 2.8, 0.6)
				v_u_66(v_u_332 + Vector3.new(0, 0.09, 0), v_u_331 * 0.5, v_u_331 * 2.6, 0.2, 0.3, 0.5)
				v_u_92(v_u_332 + Vector3.new(0, 1.5, 0), v_u_330 and 8 or 22, 6 * v_u_329, 30, 1.2)
				p_u_102.chunks(v_u_332 + Vector3.new(0, 1, 0), { v_u_10, v_u_9, v_u_13 }, v_u_330 and 5 or 14, 34, 0.6 * v_u_329, 1, false, 0.9)
				p_u_102.glint(v_u_332 + Vector3.new(0, 3, 0), v_u_11, 9 * v_u_329, 0.25)
				v_u_6.play("Explosion", {
					["at"] = v_u_332,
					["volume"] = p_u_327.mine and 0.9 or 0.5
				})
				if p_u_327.mine then
					v_u_4.shake(0.45, 0.4)
				end
			end)
		end,
		["hit"] = function(_, p391, _) -- name: hit
			-- upvalues: (copy) p_u_102, (ref) v_u_8
			p_u_102.burst("Impact", p391, v_u_8, 0.6)
		end
	}
	return v103
end