local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("E8E8F0")
local v_u_8 = Color3.fromHex("0A0A0A")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(214, 222, 236)
local v_u_11 = Color3.fromRGB(120, 126, 140)
local v_u_12 = Enum.PartType.Ball
local v_u_13 = Enum.Material.SmoothPlastic
local v_u_14 = Color3.new(v_u_9.R * 1.8, v_u_9.G * 1.8, v_u_9.B * 1.8)
local function v_u_21(p15, p16, p17) -- name: face
	local v18 = p17 - p16 * p17:Dot(p16)
	local v19
	if v18.Magnitude > 0.001 then
		v19 = v18.Unit
	else
		local v20 = p16.Y
		v19 = math.abs(v20) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p15, p16:Cross(v19), p16, v19)
end
local function v_u_40(p22, p23, p24, p25, p26) -- name: picture
	-- upvalues: (copy) v_u_4
	local v27 = Color3.new
	local v28 = p25.R
	local v29 = math.min(v28, 1)
	local v30 = p25.G
	local v31 = math.min(v30, 1)
	local v32 = p25.B
	local v33 = v27(v29, v31, (math.min(v32, 1)))
	local v34 = v_u_4.part
	local v35 = p23 * 2
	local v36 = p23 * 2
	local v37 = v34(Vector3.new(v35, 0.05, v36), p22, v33, {
		["transparency"] = 1
	})
	for _, v38 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v39 = Instance.new("Decal")
		v39.Face = v38
		v39.Texture = p24
		v39.Color3 = p25
		v39.Transparency = p26
		v39.Parent = v37
	end
	return v37
end
local function v_u_44(p41, p42) -- name: setAlpha
	for _, v43 in p41:GetChildren() do
		if not v43:IsA("Decal") then
			continue
		end
		v43.Transparency = p42
	end
end
return function(p_u_45)
	-- upvalues: (copy) v_u_40, (copy) v_u_3, (copy) v_u_21, (copy) v_u_1, (copy) v_u_44, (copy) v_u_4, (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_6, (copy) v_u_14, (copy) v_u_11, (copy) v_u_10, (copy) v_u_5, (copy) v_u_7, (copy) v_u_12
	local v46 = {}
	local function v_u_80(p_u_47, p_u_48, p_u_49, p50, p51, p_u_52, p_u_53, p54) -- name: flare
		-- upvalues: (ref) v_u_40, (ref) v_u_3, (ref) v_u_21, (ref) v_u_1, (copy) p_u_45, (ref) v_u_44
		local v_u_55 = p54 or 0
		local v_u_56 = math.random() * 6.283185307179586
		local v57 = v_u_40
		local v58 = v_u_3.CurrentCamera
		local v59
		if v58 then
			local v60 = v58.CFrame.Position - p_u_47
			v59 = v60.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v60.Unit
		else
			v59 = Vector3.new(0, 0, 1)
		end
		local v61 = Vector3.new(0, 1, 0) - v59 * (Vector3.new(0, 1, 0)):Dot(v59)
		local v62 = v61.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v61.Unit
		local v63 = v62:Cross(v59)
		local v_u_64 = v57(v_u_21(p_u_47 + v59 * 0, v59, v62 * math.cos(v_u_56) + v63 * math.sin(v_u_56)), p_u_48, p50, p51, v_u_55)
		v_u_1:AddItem(v_u_64, p_u_52 + 0.1)
		p_u_45.animate(p_u_52, 0, function(p65)
			-- upvalues: (copy) v_u_64, (copy) p_u_48, (copy) p_u_49, (copy) p_u_47, (copy) v_u_56, (copy) p_u_52, (copy) p_u_53, (ref) v_u_3, (ref) v_u_21, (ref) v_u_44, (copy) v_u_55
			local v66 = v_u_64
			local v67 = p_u_48 + (p_u_49 - p_u_48) * (1 - (1 - p65) ^ 3)
			local v68 = math.max(v67, 0.03)
			local v69 = v68 * 2
			local v70 = v68 * 2
			v66.Size = Vector3.new(v69, 0.05, v70)
			local v71 = v_u_64
			local v72 = p_u_47
			local v73 = v_u_56 + p65 * p_u_52 * p_u_53
			local v74 = v_u_3.CurrentCamera
			local v75
			if v74 then
				local v76 = v74.CFrame.Position - v72
				v75 = v76.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v76.Unit
			else
				v75 = Vector3.new(0, 0, 1)
			end
			local v77 = Vector3.new(0, 1, 0) - v75 * (Vector3.new(0, 1, 0)):Dot(v75)
			local v78 = v77.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v77.Unit
			local v79 = v78:Cross(v75)
			v71.CFrame = v_u_21(v72 + v75 * 0, v75, v78 * math.cos(v73) + v79 * math.sin(v73))
			v_u_44(v_u_64, v_u_55 + (1 - v_u_55) * p65 ^ 1.6)
			if p65 >= 1 then
				v_u_64:Destroy()
			end
		end)
	end
	local function v_u_106(p81, p82, p83, p84, p85) -- name: needles
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_1
		local v86 = v_u_3.CurrentCamera
		local v87
		if v86 then
			local v88 = v86.CFrame.Position - p81
			v87 = v88.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v88.Unit
		else
			v87 = Vector3.new(0, 0, 1)
		end
		local v89 = Vector3.new(0, 1, 0) - v87 * (Vector3.new(0, 1, 0)):Dot(v87)
		local v90 = v89.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v89.Unit
		local v91 = v90:Cross(v87)
		local v92 = math.random() * 6.283185307179586
		for v93 = 1, p82 do
			local v94 = v92 + (v93 - 1) / p82 * 6.283185307179586
			local v95 = v91 * math.cos(v94) + v90 * math.sin(v94)
			local v96 = p81 + v87 * 0.4 + v95 * p84 * 0.4
			local v97 = {
				["material"] = v_u_13
			}
			local v98 = v_u_4.part(Vector3.new(0.3, 0.3, p84), CFrame.lookAt(v96, v96 + v95), v_u_8, v97)
			local v99 = v_u_4.part
			local v100 = p84 * 1.05
			for _, v101 in { v98, (v99(Vector3.new(0.55, 0.55, v100), CFrame.lookAt(v96 - v87 * 0.2, v96 - v87 * 0.2 + v95), v_u_9, {
					["transparency"] = 0.35
				})) } do
				local v102 = v101.CFrame
				local v103 = v_u_4.tween
				local v104 = {
					["CFrame"] = nil,
					["Size"] = nil,
					["Transparency"] = 1,
					["CFrame"] = v102 + v95 * p83
				}
				local v105 = p84 * 0.4
				v104.Size = Vector3.new(0.05, 0.05, v105)
				v103(v101, p85, v104, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				v_u_1:AddItem(v101, p85 + 0.05)
			end
		end
	end
	local function v_u_133(p107, p108, p109) -- name: claws
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (copy) p_u_45, (ref) v_u_1
		local v110 = v_u_3.CurrentCamera
		local v111
		if v110 then
			local v112 = v110.CFrame.Position - p107
			v111 = v112.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v112.Unit
		else
			v111 = Vector3.new(0, 0, 1)
		end
		local v113 = Vector3.new(0, 1, 0) - v111 * (Vector3.new(0, 1, 0)):Dot(v111)
		local v114 = v113.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v113.Unit
		local v115 = v111:Cross((v114:Cross(v111) * 0.6 - v114).Unit)
		local v116 = p109 and 1 or 3
		for v117 = 1, v116 do
			local v118 = v115 * (v117 - (v116 + 1) / 2) * 0.55 * p108
			local v119 = p107 + v111 * 0.8 + v118
			local v_u_120 = p108 * (v117 == 2 and 2.6 or 2.1)
			local v121 = v_u_4.part
			local v122 = p108 * 0.22
			local v123 = {
				["material"] = v_u_13
			}
			local v124 = v121(Vector3.new(v122, 0.1, 0.1), CFrame.fromMatrix(v119, v115, v111), v_u_8, v123)
			local v125 = v_u_4.part
			local v126 = p108 * 0.5
			for _, v_u_127 in { v124, (v125(Vector3.new(v126, 0.1, 0.1), CFrame.fromMatrix(v119 - v111 * 0.15, v115, v111), v_u_9, {
					["transparency"] = 0.3
				})) } do
				local v128 = v_u_127.Size.X
				v_u_4.tween(v_u_127, 0.07, {
					["Size"] = Vector3.new(v128, 0.1, v_u_120)
				}, Enum.EasingStyle.Quad)
				p_u_45.after(0.12, function()
					-- upvalues: (copy) v_u_127, (ref) v_u_4, (copy) v_u_120
					if v_u_127.Parent then
						local v129 = v_u_4.tween
						local v130 = v_u_127
						local v131 = {
							["Size"] = nil,
							["Transparency"] = 1
						}
						local v132 = v_u_120
						v131.Size = Vector3.new(0.02, 0.05, v132)
						v129(v130, 0.2, v131)
					end
				end)
				v_u_1:AddItem(v_u_127, 0.36)
			end
		end
	end
	v46.kurobyougan_a = {
		["cast"] = function(p134) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) v_u_80, (ref) v_u_6, (ref) v_u_14
			local v135 = p134.size
			local v136 = p134.eye + p134.dir * 1.2
			v_u_4.flash(v136, v_u_9, 3 * v135, 0.12)
			if not p134.lite then
				v_u_80(v136, 1.5 * v135, 0.3 * v135, v_u_6.KuroStar, v_u_14, 0.12, -25, 0)
			end
		end,
		["shot"] = function(p137, p138) -- name: starShot
			-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_40, (ref) v_u_6, (ref) v_u_14, (ref) v_u_1, (copy) p_u_45, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_21
			local v_u_139 = p137.size
			local v_u_140 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p138, v_u_9, {
				["transparency"] = 1
			})
			local v_u_141 = v_u_40(p138, 0.95 * v_u_139, v_u_6.KuroStar, v_u_14, 0)
			local v_u_142 = v_u_40(p138, 1.5 * v_u_139, v_u_6.Glow, v_u_9, 0.45)
			local v_u_143 = {}
			if not p137.lite then
				local v144 = v_u_4.part
				local v145 = Vector3.new(0.14, 0.14, 1.5) * v_u_139
				local v146 = v_u_9
				table.insert(v_u_143, v144(v145, p138, v146))
				local v147 = v_u_4.part
				local v148 = Vector3.new(0.14, 0.14, 1.5) * v_u_139
				local v149 = v_u_9
				table.insert(v_u_143, v147(v148, p138, v149))
			end
			for _, v150 in { v_u_140, v_u_141, v_u_142 } do
				v_u_1:AddItem(v150, 3)
			end
			for _, v151 in v_u_143 do
				v_u_1:AddItem(v151, 3)
			end
			p_u_45.streak(v_u_140, v_u_9, v_u_11, 1.1 * v_u_139, p137.lite and 0.1 or 0.15)
			if p137.mine then
				p_u_45.light(v_u_140, v_u_10, 8 * v_u_139)
			end
			local v_u_152 = false
			return {
				["place"] = function(p153, p154) -- name: place
					-- upvalues: (copy) v_u_140, (copy) v_u_141, (ref) v_u_3, (ref) v_u_21, (copy) v_u_142, (copy) v_u_143, (copy) v_u_139
					local v155 = p153.Position
					v_u_140.CFrame = p153
					local v156 = v_u_141
					local v157 = -p154 * 30
					local v158 = v_u_3.CurrentCamera
					local v159
					if v158 then
						local v160 = v158.CFrame.Position - v155
						v159 = v160.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v160.Unit
					else
						v159 = Vector3.new(0, 0, 1)
					end
					local v161 = Vector3.new(0, 1, 0) - v159 * (Vector3.new(0, 1, 0)):Dot(v159)
					local v162 = v161.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v161.Unit
					local v163 = v162:Cross(v159)
					v156.CFrame = v_u_21(v155 + v159 * 0.3, v159, v162 * math.cos(v157) + v163 * math.sin(v157))
					local v164 = v_u_142
					local v165 = v_u_3.CurrentCamera
					local v166
					if v165 then
						local v167 = v165.CFrame.Position - v155
						v166 = v167.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v167.Unit
					else
						v166 = Vector3.new(0, 0, 1)
					end
					local v168 = Vector3.new(0, 1, 0) - v166 * (Vector3.new(0, 1, 0)):Dot(v166)
					local v169 = v168.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v168.Unit
					local v170 = v169:Cross(v166)
					v164.CFrame = v_u_21(v155 + v166 * 0.1, v166, v169 * 1 + v170 * 0)
					if #v_u_143 > 0 then
						local v171 = v_u_3.CurrentCamera
						local v172
						if v171 then
							local v173 = v171.CFrame.Position - v155
							v172 = v173.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v173.Unit
						else
							v172 = Vector3.new(0, 0, 1)
						end
						local v174 = Vector3.new(0, 1, 0) - v172 * (Vector3.new(0, 1, 0)):Dot(v172)
						local v175 = v174.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v174.Unit
						local v176 = v175:Cross(v172)
						for v177, v178 in v_u_143 do
							local v179 = p154 * 22 + v177 * 3.141592653589793
							local v180 = v176 * math.cos(v179) + v175 * math.sin(v179)
							local v181 = -v176 * math.sin(v179) + v175 * math.cos(v179)
							local v182 = v155 + v180 * 1.35 * v_u_139 + v172 * 0.2
							v178.CFrame = CFrame.lookAt(v182, v182 + v181)
						end
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_152, (copy) v_u_140, (ref) v_u_1, (copy) v_u_141, (copy) v_u_142, (copy) v_u_143
					if not v_u_152 then
						v_u_152 = true
						local v183 = v_u_140:FindFirstChildWhichIsA("PointLight")
						if v183 then
							v183:Destroy()
						end
						v_u_1:AddItem(v_u_140, 0.25)
						v_u_141:Destroy()
						v_u_142:Destroy()
						for _, v184 in v_u_143 do
							v184:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p185, p186) -- name: starImpact
			-- upvalues: (copy) v_u_80, (ref) v_u_6, (ref) v_u_14, (copy) v_u_106, (copy) p_u_45, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10
			local v187 = p185.size
			v_u_80(p186, 1.1 * v187, 3.8 * v187, v_u_6.KuroStar, v_u_14, 0.22, 12, 0)
			v_u_106(p186, p185.lite and 5 or 10, 4 * v187, 1.6 * v187, 0.22)
			p_u_45.pop(p186, v_u_9, 1.2 * v187, 3.4 * v187, 0.16, 0.2)
			v_u_4.ring(p_u_45.ground(p186), v_u_10, p185.ability.radius * 0.9 * v187, 0.25, v_u_6.Ring)
			p_u_45.burst("Impact", p186, v_u_9, 0.7 * v187)
			p_u_45.hitSound(p186)
		end,
		["hit"] = p_u_45.simpleHit(v_u_9, 0.55)
	}
	local v_u_188 = {}
	setmetatable(v_u_188, {
		["__mode"] = "k"
	})
	local function v_u_208(p_u_189, p_u_190) -- name: spinUp
		-- upvalues: (ref) v_u_40, (ref) v_u_21, (ref) v_u_6, (ref) v_u_14, (ref) v_u_1, (copy) p_u_45, (ref) v_u_9
		local v_u_191 = p_u_189.size
		local v_u_192 = p_u_189.eye + p_u_189.dir * 3 + Vector3.new(0, 0.3, 0)
		local v_u_193 = v_u_40(v_u_21(v_u_192, -p_u_189.dir, Vector3.new(0, 1, 0)), 0.3 * v_u_191, v_u_6.KuroStar, v_u_14, 0)
		v_u_1:AddItem(v_u_193, p_u_190 + 0.6)
		local v_u_194 = 0
		local v_u_195 = os.clock()
		local v_u_196 = v_u_195
		p_u_45.runNow(function()
			-- upvalues: (copy) v_u_193, (copy) v_u_195, (ref) v_u_194, (ref) v_u_196, (copy) v_u_191, (ref) v_u_21, (copy) v_u_192, (copy) p_u_189, (copy) p_u_190
			if not v_u_193.Parent then
				return false
			end
			local v197 = os.clock()
			local v198 = (v197 - v_u_195) / 0.15
			local v199 = math.clamp(v198, 0, 1)
			v_u_194 = v_u_194 + (v197 - v_u_196) * (v199 * 30 + 12)
			v_u_196 = v197
			local v200 = v_u_193
			local v201 = 2.4 * v_u_191
			local v202 = v199 - 1
			local v203 = v202 * 2.7 * v202 * v202 + 1 + v202 * 1.7 * v202
			local v204 = v201 * math.max(v203, 0.1)
			local v205 = math.max(v204, 0.03)
			local v206 = v205 * 2
			local v207 = v205 * 2
			v200.Size = Vector3.new(v206, 0.05, v207)
			v_u_193.CFrame = v_u_21(v_u_192, -p_u_189.dir, CFrame.fromAxisAngle(p_u_189.dir, v_u_194):VectorToWorldSpace(Vector3.new(0, 1, 0)))
			return v197 - v_u_195 < p_u_190 + 0.5
		end)
		if not p_u_189.lite then
			p_u_45.inward(v_u_192, v_u_9, 6, 7 * v_u_191, (math.max(p_u_190, 0.12)))
		end
		return v_u_193
	end
	local function v_u_262(p_u_209, p210, p_u_211) -- name: storm
		-- upvalues: (copy) p_u_45, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9, (ref) v_u_11, (ref) v_u_8, (ref) v_u_13, (ref) v_u_1, (ref) v_u_3, (ref) v_u_40, (ref) v_u_21, (ref) v_u_6, (ref) v_u_44, (copy) v_u_80, (ref) v_u_14, (copy) v_u_106, (ref) v_u_5
		local v_u_212 = p_u_209.size
		local v_u_213 = p_u_209.lite
		local v_u_214 = p210 + p_u_209.dir * 1.5
		local v_u_215 = p_u_211 - v_u_214
		local v_u_216 = v_u_215.Magnitude
		if v_u_216 >= 1 then
			local v_u_217 = v_u_215.Unit
			local v218 = v_u_217:Cross(Vector3.new(0, 1, 0))
			local v_u_219 = v218.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v218.Unit
			local v_u_220 = v_u_219:Cross(v_u_217)
			local v_u_221 = (p_u_209.ability.width or 10) * 0.45
			p_u_45.glowBeam(v_u_214, p_u_211, v_u_10, v_u_221 * 1.6, 0.4)
			v_u_4.beam(v_u_214, p_u_211, v_u_9, v_u_221 * 0.5, 0.3)
			p_u_45.groundLine(v_u_214, p_u_211, v_u_221 * 1.2, v_u_10, 0.6, 0.35)
			local v222 = v_u_213 and 1 or 3
			local v_u_223 = {}
			local v224 = v_u_213 and 3 or 8
			for v225 = 1, v222 do
				local v226 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_214), v_u_9, {
					["transparency"] = 1
				})
				p_u_45.streak(v226, v_u_9, v_u_11, 1.6 * v_u_212, 0.35)
				local v227 = {
					["p"] = nil,
					["a"] = nil,
					["r"] = nil,
					["delay"] = 0,
					["blade"] = false,
					["p"] = v226,
					["a"] = (v225 - 1) * 6.283185307179586 / v222,
					["r"] = v_u_221
				}
				table.insert(v_u_223, v227)
			end
			for v228 = 1, v224 do
				local v229 = {
					["material"] = v_u_13
				}
				local v230 = {
					["p"] = nil,
					["a"] = nil,
					["r"] = nil,
					["delay"] = nil,
					["blade"] = true,
					["p"] = v_u_4.part(Vector3.new(0.3, 1.1, 3.2) * v_u_212, CFrame.new(v_u_214), v_u_8, v229),
					["a"] = v228 * 2.3,
					["r"] = v_u_221 * (v228 % 3 * 0.2 + 0.45),
					["delay"] = (v228 - 1) / v224 * 0.12
				}
				table.insert(v_u_223, v230)
			end
			for _, v231 in v_u_223 do
				v_u_1:AddItem(v231.p, 1.08)
			end
			local v_u_232 = os.clock()
			local v_u_233 = {}
			local v_u_234 = {}
			p_u_45.runNow(function()
				-- upvalues: (copy) v_u_232, (copy) v_u_233, (copy) v_u_234, (copy) v_u_223, (copy) v_u_216, (ref) v_u_219, (copy) v_u_220, (copy) v_u_214, (copy) v_u_217, (ref) v_u_3
				local v235 = os.clock() - v_u_232
				table.clear(v_u_233)
				table.clear(v_u_234)
				for _, v236 in v_u_223 do
					local v237 = (v235 - v236.delay) / 0.28
					local v238 = v_u_216 * math.clamp(v237, 0, 1)
					local v239 = v236.a + v238 / v_u_216 * 5.5 * (v236.blade and 1.3 or 1)
					local v240 = v_u_219 * math.cos(v239) + v_u_220 * math.sin(v239)
					local v241 = v_u_214 + v_u_217 * v238 + v240 * v236.r
					local v242 = v_u_217 * v_u_216 / 0.28 + (-v_u_219 * math.sin(v239) + v_u_220 * math.cos(v239)) * v236.r * 5.5 / 0.28
					local v243 = v_u_233
					local v244 = v236.p
					table.insert(v243, v244)
					if v236.blade then
						local v245 = v_u_234
						local v246 = CFrame.lookAt
						local v247 = v241 + v242
						table.insert(v245, v246(v241, v247, v240))
					else
						local v248 = v_u_234
						local v249 = CFrame.new
						table.insert(v248, v249(v241))
					end
				end
				v_u_3:BulkMoveTo(v_u_233, v_u_234, Enum.BulkMoveMode.FireCFrameChanged)
				if v235 < 0.43000000000000005 then
					return true
				end
				for _, v250 in v_u_223 do
					if not v250.blade then
						continue
					end
					v250.p:Destroy()
				end
				return false
			end)
			local v251 = v_u_213 and 3 or 7
			for v252 = 1, v251 do
				local v_u_253 = v252 / (v251 + 1)
				p_u_45.after(v_u_253 * 0.28, function()
					-- upvalues: (copy) v_u_214, (copy) v_u_215, (copy) v_u_253, (ref) v_u_40, (ref) v_u_21, (copy) v_u_217, (copy) v_u_221, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1, (ref) p_u_45, (ref) v_u_44
					local v254 = v_u_9
					local v_u_255 = v_u_40(v_u_21(v_u_214 + v_u_215 * v_u_253, v_u_217, Vector3.new(0, 1, 0)), v_u_221 * 0.5, v_u_6.Ring, Color3.new(v254.R * 1.4, v254.G * 1.4, v254.B * 1.4), 0)
					v_u_1:AddItem(v_u_255, 0.3)
					p_u_45.animate(0.25, 0, function(p256)
						-- upvalues: (copy) v_u_255, (ref) v_u_221, (ref) v_u_44
						local v257 = v_u_255
						local v258 = v_u_221 * (0.5 + 0.9 * p256)
						local v259 = math.max(v258, 0.03)
						local v260 = v259 * 2
						local v261 = v259 * 2
						v257.Size = Vector3.new(v260, 0.05, v261)
						v_u_44(v_u_255, p256 * p256)
						if p256 >= 1 then
							v_u_255:Destroy()
						end
					end)
				end)
			end
			p_u_45.after(0.28, function()
				-- upvalues: (ref) v_u_80, (copy) p_u_211, (copy) v_u_212, (ref) v_u_6, (ref) v_u_14, (ref) v_u_106, (copy) v_u_213, (ref) p_u_45, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_5, (copy) p_u_209
				v_u_80(p_u_211, 2 * v_u_212, 7 * v_u_212, v_u_6.KuroStar, v_u_14, 0.3, 8, 0)
				v_u_106(p_u_211, v_u_213 and 5 or 10, 7, 3, 0.3)
				p_u_45.pop(p_u_211, v_u_9, 2, 9, 0.25, 0.2)
				v_u_4.ring(p_u_45.ground(p_u_211), v_u_10, 9, 0.35, v_u_6.Shockwave)
				p_u_45.burst("Impact", p_u_211, v_u_9, 1.2)
				v_u_5.play("Burst", {
					["at"] = p_u_211,
					["volume"] = p_u_209.mine and 0.6 or 0.35
				})
			end)
			if p_u_209.mine then
				v_u_4.shake(0.25, 0.25)
			end
		end
	end
	v46.kurobyougan_e = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["beam"] = nil,
		["hit"] = nil,
		["cast"] = function(p263) -- name: cast
			-- upvalues: (copy) p_u_45, (ref) v_u_7
			p_u_45.skillCast(p263, v_u_7)
		end,
		["windup"] = function(p264, _, p265) -- name: windup
			-- upvalues: (copy) v_u_188, (copy) v_u_208
			v_u_188[p264] = v_u_208(p264, p265)
		end,
		["beam"] = function(p266, p267, p268) -- name: beam
			-- upvalues: (copy) v_u_188, (copy) v_u_80, (ref) v_u_6, (ref) v_u_14, (ref) v_u_4, (ref) v_u_9, (copy) v_u_262
			local v269 = v_u_188[p266]
			v_u_188[p266] = nil
			if v269 and v269.Parent then
				local v270 = v269.Position
				v269:Destroy()
				v_u_80(v270, 2.4 * p266.size, 4 * p266.size, v_u_6.KuroStar, v_u_14, 0.18, 20, 0)
				v_u_4.flash(v270, v_u_9, 6 * p266.size, 0.15)
			end
			v_u_262(p266, p267, p268)
		end,
		["hit"] = function(p271, p272, _) -- name: hit
			-- upvalues: (copy) v_u_133, (copy) p_u_45, (ref) v_u_9
			v_u_133(p272, 1.5, p271.lite)
			p_u_45.burst("Impact", p272, v_u_9, 0.6)
			p_u_45.beamHitSound(p271, p272, "Hit")
		end
	}
	local v_u_273 = {}
	setmetatable(v_u_273, {
		["__mode"] = "k"
	})
	local function v_u_286(p274, p275) -- name: starPos
		local v276 = p274.sink
		local v277
		if v276 then
			local v278 = p275 - v276
			local v279 = p274.span
			local v280 = v278 / math.max(v279, 0.1)
			local v281 = math.clamp(v280, 0, 1)
			v277 = v281 * v281 * (3 - v281 * 2)
		else
			v277 = 0
		end
		local v282 = p274.fallAt
		local v283 = v277 * -14 + 24
		if v282 then
			local v284 = (p275 - v282) / 0.14
			local v285 = math.clamp(v284, 0, 1)
			v283 = v283 + (1.5 - v283) * v285 * v285
		end
		return p274.g + Vector3.new(0, 1, 0) * v283, v277 * 3 + 6
	end
	local function v_u_334(p287, p288) -- name: rise
		-- upvalues: (copy) p_u_45, (ref) v_u_40, (ref) v_u_6, (ref) v_u_14, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_12, (ref) v_u_1, (copy) v_u_286, (ref) v_u_3, (ref) v_u_21
		local v_u_289 = p287.ability.radius
		local v290 = p_u_45.ground(p288, 0)
		local v_u_291 = (p287.ability.duration or 2) + 2.5
		local v_u_292 = v_u_40(CFrame.new(v290 + Vector3.new(0, 24, 0)), 0.1, v_u_6.KuroStar, v_u_14, 0)
		local v_u_293 = v_u_40(CFrame.new(v290 + Vector3.new(0, 24, 0)), 0.1, v_u_6.Glow, v_u_9, 0.2)
		local v_u_294 = v_u_4.part(Vector3.new(1, 1, 1) * v_u_289 * 0.4, CFrame.new(v290), v_u_10, {
			["shape"] = nil,
			["transparency"] = 1,
			["material"] = nil,
			["shape"] = v_u_12,
			["material"] = Enum.Material.ForceField
		})
		for _, v295 in { v_u_292, v_u_293, v_u_294 } do
			v_u_1:AddItem(v295, v_u_291)
		end
		local v_u_296 = {
			["g"] = nil,
			["star"] = nil,
			["glow"] = nil,
			["hush"] = nil,
			["born"] = nil,
			["sink"] = nil,
			["span"] = nil,
			["fallAt"] = nil,
			["spears"] = nil,
			["g"] = v290,
			["star"] = v_u_292,
			["glow"] = v_u_293,
			["hush"] = v_u_294,
			["born"] = os.clock(),
			["span"] = p287.ability.duration or 2,
			["spears"] = {}
		}
		p_u_45.runNow(function()
			-- upvalues: (copy) v_u_292, (copy) v_u_296, (ref) v_u_286, (copy) v_u_293, (ref) v_u_3, (ref) v_u_21, (copy) v_u_294, (copy) v_u_289, (copy) v_u_291
			if not v_u_292.Parent then
				return false
			end
			local v297 = os.clock()
			local v298 = v297 - v_u_296.born
			local v299 = v298 / 0.25
			local v300 = math.clamp(v299, 0, 1) - 1
			local v301 = v300 * 2.7 * v300 * v300 + 1 + v300 * 1.7 * v300
			local v302, v303 = v_u_286(v_u_296, v297)
			local v304 = v_u_292
			local v305 = v303 * v301
			local v306 = math.max(v305, 0.03)
			local v307 = v306 * 2
			local v308 = v306 * 2
			v304.Size = Vector3.new(v307, 0.05, v308)
			local v309 = v_u_293
			local v310 = v303 * 1.7 * v301
			local v311 = math.max(v310, 0.03)
			local v312 = v311 * 2
			local v313 = v311 * 2
			v309.Size = Vector3.new(v312, 0.05, v313)
			local v314 = v_u_292
			local v315 = -v298 * 2.2
			local v316 = v_u_3.CurrentCamera
			local v317
			if v316 then
				local v318 = v316.CFrame.Position - v302
				v317 = v318.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v318.Unit
			else
				v317 = Vector3.new(0, 0, 1)
			end
			local v319 = Vector3.new(0, 1, 0) - v317 * (Vector3.new(0, 1, 0)):Dot(v317)
			local v320 = v319.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v319.Unit
			local v321 = v320:Cross(v317)
			v314.CFrame = v_u_21(v302 + v317 * 0.3, v317, v320 * math.cos(v315) + v321 * math.sin(v315))
			local v322 = v_u_293
			local v323 = v_u_3.CurrentCamera
			local v324
			if v323 then
				local v325 = v323.CFrame.Position - v302
				v324 = v325.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v325.Unit
			else
				v324 = Vector3.new(0, 0, 1)
			end
			local v326 = Vector3.new(0, 1, 0) - v324 * (Vector3.new(0, 1, 0)):Dot(v324)
			local v327 = v326.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v326.Unit
			local v328 = v327:Cross(v324)
			v322.CFrame = v_u_21(v302 + v324 * 0, v324, v327 * 1 + v328 * 0)
			local v329 = v298 / 0.3
			local v330 = math.clamp(v329, 0, 1)
			local v331 = v_u_294
			local v332 = Vector3.new(1, 1, 1) * v_u_289
			local v333 = math.clamp(v330, 0, 1)
			v331.Size = v332 * (v333 * v333 * (3 - v333 * 2) * 1.8 + 0.4)
			v_u_294.Transparency = 1 - v330 * 0.55
			return v298 < v_u_291
		end)
		return v_u_296
	end
	local function v_u_349(p_u_335, p336, p_u_337) -- name: spear
		-- upvalues: (copy) v_u_286, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_1, (copy) p_u_45, (ref) v_u_6, (ref) v_u_11
		local v_u_338 = v_u_286(p336, os.clock())
		local v_u_339 = (v_u_338 - p_u_337).Unit
		local v340 = {
			["material"] = v_u_13
		}
		local v_u_341 = v_u_4.part(Vector3.new(0.8, 0.8, 8), CFrame.lookAt(v_u_338 + v_u_339 * 8 * 0.5, v_u_338 + v_u_339 * 8), v_u_8, v340)
		local v_u_342
		if p_u_335.lite then
			v_u_342 = nil
		else
			v_u_342 = v_u_4.part(Vector3.new(1.05, 1.05, 8.24), CFrame.lookAt(v_u_338 + v_u_339 * 8 * 0.5, v_u_338 + v_u_339 * 8), v_u_9, {
				["transparency"] = 0.82
			})
			local v343 = p336.spears
			table.insert(v343, v_u_342)
			v_u_1:AddItem(v_u_342, 4)
		end
		local v344 = p336.spears
		table.insert(v344, v_u_341)
		v_u_1:AddItem(v_u_341, 4)
		local v_u_345 = p_u_337 - v_u_339 * 1.6
		p_u_45.animate(0.12, 0, function(p346)
			-- upvalues: (copy) v_u_338, (copy) v_u_345, (copy) v_u_341, (copy) v_u_339, (ref) v_u_342, (ref) v_u_4, (copy) p_u_337, (ref) v_u_9, (ref) v_u_6, (ref) p_u_45, (copy) p_u_335, (ref) v_u_11
			local v347 = v_u_338:Lerp(v_u_345, p346 * p346)
			v_u_341.CFrame = CFrame.lookAt(v347 + v_u_339 * 8 * 0.5, v347 + v_u_339 * 8)
			local v348 = v_u_342
			if v348 then
				v348.CFrame = CFrame.lookAt(v347 + v_u_339 * 8 * 0.5, v347 + v_u_339 * 8)
			end
			if p346 >= 1 then
				v_u_4.ring(p_u_337, v_u_9, 5, 0.3, v_u_6.Shockwave)
				p_u_45.burst("Impact", p_u_337 + Vector3.new(0, 0.5, 0), v_u_9, 1)
				if not p_u_335.lite then
					p_u_45.mark(p_u_337, v_u_11, 2.5, 1.8, v_u_6.CrackLines, 0.2)
					p_u_45.spikes(p_u_337 + Vector3.new(0, 0.4, 0), v_u_9, 4, 4, 0.2, nil, nil, true)
				end
			end
		end)
	end
	local function v_u_391(p_u_350, p_u_351, p_u_352) -- name: cyclone
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_45, (ref) v_u_10, (ref) v_u_1, (ref) v_u_3, (copy) v_u_349, (ref) v_u_6
		local v_u_353 = p_u_350.ability.radius
		local v_u_354 = p_u_351.g
		local v_u_355 = p_u_350.lite
		local v_u_356 = {}
		for v357 = 1, v_u_355 and 3 or 7 do
			local v358 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_354), v_u_9, {
				["transparency"] = 1
			})
			p_u_45.streak(v358, v_u_9, v_u_10, v357 % 3 * 0.6 + 2.2, 0.45)
			v_u_1:AddItem(v358, p_u_352 + 1.5)
			local v359 = {
				["p"] = v358,
				["a"] = v357 * 2.39,
				["h"] = (v357 - 1) % 4 * 2.6 + 0.8,
				["speed"] = v357 % 3 * 0.8 + 5.2
			}
			table.insert(v_u_356, v359)
		end
		local v_u_360 = os.clock()
		local v_u_361 = false
		local v_u_362 = 0.05
		local v_u_363 = 0
		local v_u_364 = {}
		local v_u_365 = {}
		p_u_45.runNow(function()
			-- upvalues: (copy) v_u_360, (copy) v_u_364, (copy) v_u_365, (copy) p_u_352, (copy) v_u_356, (copy) v_u_353, (copy) v_u_354, (ref) v_u_3, (ref) v_u_361, (ref) v_u_362, (copy) v_u_355, (ref) v_u_363, (ref) v_u_349, (copy) p_u_350, (copy) p_u_351, (ref) p_u_45, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6
			local v366 = os.clock() - v_u_360
			table.clear(v_u_364)
			table.clear(v_u_365)
			local v367 = p_u_352
			local v368 = v366 / math.max(v367, 0.1)
			local v369 = 1 - math.min(v368, 1) * 0.18
			for _, v370 in v_u_356 do
				local v371 = v370.a + v366 * v370.speed
				local v372 = v_u_353 * v369 * (1.05 - v370.h * 0.018)
				local v373 = v_u_364
				local v374 = v370.p
				table.insert(v373, v374)
				local v375 = v_u_365
				local v376 = CFrame.new
				local v377 = v_u_354
				local v378 = math.cos(v371) * v372
				local v379 = v370.h
				local v380 = math.sin(v371) * v372
				local v381 = v377 + Vector3.new(v378, v379, v380)
				table.insert(v375, v376(v381))
			end
			v_u_3:BulkMoveTo(v_u_364, v_u_365, Enum.BulkMoveMode.FireCFrameChanged)
			if not v_u_361 and v_u_362 <= v366 then
				v_u_362 = v_u_362 + 0.4
				for _ = 1, v_u_355 and 1 or 2 do
					if v_u_363 >= 10 then
						continue
					end
					v_u_363 = v_u_363 + 1
					local v382 = math.random() * 6.283185307179586
					local v383 = (0.25 + math.random() * 0.65) * v_u_353
					local v384 = v_u_349
					local v385 = p_u_350
					local v386 = p_u_351
					local v387 = v_u_354
					local v388 = math.cos(v382) * v383
					local v389 = math.sin(v382) * v383
					v384(v385, v386, v387 + Vector3.new(v388, 0, v389))
				end
				if not v_u_355 then
					p_u_45.inward(v_u_354 + Vector3.new(0, 1.5, 0), v_u_9, 6, v_u_353, 0.32)
				end
				v_u_4.ring(v_u_354, v_u_10, v_u_353 * 1.1, 0.35, v_u_6.Ring)
			end
			if not v_u_361 then
				return v366 < p_u_352 + 0.6
			end
			for _, v390 in v_u_356 do
				v390.p:Destroy()
			end
			return false
		end)
		return function()
			-- upvalues: (ref) v_u_361
			v_u_361 = true
		end
	end
	local function v_u_415(p_u_392, p393) -- name: eclipse
		-- upvalues: (copy) v_u_273, (copy) p_u_45, (ref) v_u_4, (ref) v_u_1, (ref) v_u_8, (ref) v_u_12, (ref) v_u_13, (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11
		local v_u_394 = p_u_392.ability.radius
		local v_u_395 = v_u_273[p_u_392]
		v_u_273[p_u_392] = nil
		local v_u_396
		if v_u_395 then
			v_u_396 = v_u_395.g
		else
			v_u_396 = p_u_45.ground(p393, 0)
		end
		local v_u_397 = p_u_392.lite
		if v_u_395 then
			v_u_395.fallAt = os.clock()
		end
		p_u_45.after(0.14, function()
			-- upvalues: (copy) v_u_395, (ref) v_u_4, (copy) v_u_394, (ref) v_u_1, (copy) v_u_396, (ref) v_u_8, (ref) v_u_12, (ref) v_u_13, (ref) p_u_45, (ref) v_u_5, (copy) p_u_392
			if v_u_395 then
				v_u_395.star:Destroy()
				v_u_395.glow:Destroy()
				v_u_4.tween(v_u_395.hush, 0.3, {
					["Transparency"] = 1,
					["Size"] = nil,
					["Size"] = Vector3.new(1, 1, 1) * v_u_394 * 2.8
				})
				v_u_1:AddItem(v_u_395.hush, 0.32)
			end
			local v398 = {
				["shape"] = nil,
				["material"] = nil,
				["transparency"] = 0.05,
				["shape"] = v_u_12,
				["material"] = v_u_13
			}
			local v_u_399 = v_u_4.part(Vector3.new(4, 4, 4), CFrame.new(v_u_396 + Vector3.new(0, 1.5, 0)), v_u_8, v398)
			v_u_4.tween(v_u_399, 0.22, {
				["Size"] = Vector3.new(1, 1, 1) * v_u_394 * 1.7
			}, Enum.EasingStyle.Quart)
			p_u_45.after(0.22, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_399, (ref) v_u_394
				v_u_4.tween(v_u_399, 0.2, {
					["Transparency"] = 1,
					["Size"] = nil,
					["Size"] = Vector3.new(1, 1, 1) * v_u_394 * 2
				})
			end)
			v_u_1:AddItem(v_u_399, 0.45)
			v_u_5.play("Crit", {
				["at"] = v_u_396,
				["volume"] = p_u_392.mine and 0.7 or 0.4
			})
		end)
		p_u_45.after(0.36, function()
			-- upvalues: (ref) v_u_4, (copy) v_u_396, (ref) v_u_9, (copy) v_u_394, (ref) v_u_6, (ref) v_u_10, (ref) p_u_45, (ref) v_u_7, (ref) v_u_8, (ref) v_u_13, (ref) v_u_1, (copy) v_u_395, (copy) v_u_397, (ref) v_u_11, (ref) v_u_5, (copy) p_u_392
			v_u_4.flash(v_u_396 + Vector3.new(0, 2, 0), v_u_9, v_u_394 * 2.2, 0.3)
			v_u_4.ring(v_u_396, v_u_9, v_u_394 * 1.7, 0.45, v_u_6.Shockwave)
			v_u_4.ring(v_u_396, v_u_10, v_u_394 * 2, 0.6, v_u_6.Ring)
			p_u_45.pop(v_u_396 + Vector3.new(0, 2, 0), v_u_9, 4, v_u_394 * 2.6, 0.45, 0.25, Enum.Material.ForceField)
			p_u_45.burst("Shockwave", v_u_396 + Vector3.new(0, 0.3, 0), v_u_9, v_u_394 / 12)
			p_u_45.burst("Explosion", v_u_396 + Vector3.new(0, 2, 0), v_u_7, 2)
			local v400 = math.random() * 6.283185307179586
			for v401 = 1, 10 do
				local v402 = v400 + (v401 - 1) / 10 * 6.283185307179586
				local v403 = math.cos(v402)
				local v404 = math.sin(v402)
				local v405 = Vector3.new(v403, 0, v404)
				local v406 = v_u_396 + Vector3.new(0, 0.4, 0) + v405 * 2
				local v407 = {
					["material"] = v_u_13
				}
				local v_u_408 = v_u_4.part(Vector3.new(1.3, 0.2, 2), CFrame.lookAt(v406, v406 + v405), v_u_8, v407)
				local v409 = v_u_4.tween
				local v410 = {}
				local v411 = v_u_394 * 1.4
				v410.Size = Vector3.new(0.3, 0.2, v411)
				v410.CFrame = CFrame.lookAt(v406 + v405 * v_u_394 * 0.7, v406 + v405 * (v_u_394 * 0.7 + 1))
				v409(v_u_408, 0.3, v410, Enum.EasingStyle.Quart)
				p_u_45.after(0.35, function()
					-- upvalues: (copy) v_u_408, (ref) v_u_4
					if v_u_408.Parent then
						v_u_4.tween(v_u_408, 0.3, {
							["Transparency"] = 1
						})
					end
				end)
				v_u_1:AddItem(v_u_408, 0.7)
			end
			if v_u_395 then
				for _, v412 in v_u_395.spears do
					if not v412.Parent then
						continue
					end
					local v413 = v412.Position
					v412:Destroy()
					if v_u_397 then
						continue
					end
					local v414 = { v_u_8, v_u_9, v_u_11 }
					p_u_45.chunks(v413, v414, 3, 30, 0.8, 0.8, false, 0.8)
				end
			end
			p_u_45.chunks(v_u_396 + Vector3.new(0, 1, 0), { v_u_8, v_u_9, v_u_10 }, v_u_397 and 6 or 12, 50, 1.2, 1.1, false, 1)
			p_u_45.spikes(v_u_396 + Vector3.new(0, 1.5, 0), v_u_9, v_u_397 and 6 or 12, v_u_394 * 1.6, 0.35, nil, nil, true)
			p_u_45.mark(v_u_396, v_u_11, v_u_394 * 1.1, 1.2, v_u_6.CrackLines, 0.1)
			v_u_5.play("Explosion", {
				["at"] = v_u_396,
				["volume"] = p_u_392.mine and 1 or 0.6
			})
			if p_u_392.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end)
	end
	v46.kurobyougan_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p416) -- name: cast
			-- upvalues: (copy) p_u_45, (ref) v_u_7, (copy) v_u_80, (ref) v_u_6, (ref) v_u_14, (ref) v_u_4
			p_u_45.skillCast(p416, v_u_7, true)
			local v417 = p416.size
			v_u_80(p416.eye + p416.dir * 1.4, 3.6 * v417, 0.5 * v417, v_u_6.KuroStar, v_u_14, 0.3, -18, 0)
			if p416.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p418, p419, p420) -- name: windup
			-- upvalues: (copy) v_u_334, (copy) v_u_273, (copy) p_u_45, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9
			local v421 = v_u_334(p418, p419)
			v_u_273[p418] = v421
			p_u_45.mark(v421.g, v_u_10, p418.ability.radius, p420 + 0.4, v_u_6.Glow, 0.4)
			if not p418.lite then
				p_u_45.inward(v421.g + Vector3.new(0, 24, 0), v_u_9, 8, 16, (math.max(p420, 0.15)))
			end
		end,
		["zone"] = function(p422, p423, p424) -- name: zone
			-- upvalues: (copy) v_u_273, (copy) v_u_334, (copy) p_u_45, (ref) v_u_9, (ref) v_u_6, (ref) v_u_4, (copy) v_u_391
			local v425 = v_u_273[p422] or v_u_334(p422, p423)
			v_u_273[p422] = v425
			v425.sink = os.clock()
			v425.span = p424
			p_u_45.mark(v425.g, v_u_9, p422.ability.radius, p424 + 0.2, v_u_6.Glow, 0.5)
			if p422.mine then
				v_u_4.shake(0.3, 0.3)
			end
			return v_u_391(p422, v425, p424)
		end,
		["finish"] = function(p426, p427) -- name: finish
			-- upvalues: (copy) v_u_415
			v_u_415(p426, p427)
		end,
		["hit"] = function(p428, p429, _) -- name: hit
			-- upvalues: (copy) p_u_45, (ref) v_u_9, (copy) v_u_133
			p_u_45.burst("Impact", p429, v_u_9, 0.7)
			if not p428.lite then
				v_u_133(p429, 1.2, true)
			end
		end
	}
	return v46
end