require(script.Parent.Parent.Config.Products)
local v_u_13 = {
	["best"] = function(p1, p2) -- name: best
		local v3 = 1
		for _, v4 in p1 do
			local v5 = v4.mult or 1
			if not p2(v4.key) or v3 >= v5 then
				continue
			end
			v3 = v5
		end
		return v3
	end,
	["next"] = function(p6, p7) -- name: next
		-- upvalues: (copy) v_u_13
		local v8 = v_u_13.best(p6, p7)
		for _, v9 in p6 do
			if v9.retired or (p7(v9.key) or v8 >= (v9.mult or 1)) then
				continue
			end
			return v9
		end
		return nil
	end,
	["top"] = function(p10) -- name: top
		local v11 = nil
		for _, v12 in p10 do
			if v12.retired then
				continue
			end
			v11 = v12
		end
		return v11
	end
}
return v_u_13