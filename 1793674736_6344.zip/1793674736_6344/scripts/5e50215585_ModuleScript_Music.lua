local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("SoundService")
local v_u_3 = game:GetService("TweenService")
local v4 = {}
local function v_u_8(p5) -- name: playlist
	local v6 = {}
	if p5 then
		for _, v7 in p5:GetChildren() do
			if not v7:IsA("Sound") then
				continue
			end
			v7.Looped = false
			if type(v7:GetAttribute("BaseVolume")) ~= "number" then
				v7:SetAttribute("BaseVolume", v7.Volume)
			end
			table.insert(v6, v7)
		end
	end
	return {
		["tracks"] = nil,
		["order"] = nil,
		["at"] = 1,
		["last"] = nil,
		["tracks"] = v6,
		["order"] = {}
	}
end
local function v_u_18(p9) -- name: nextTrack
	if #p9.tracks == 0 then
		return nil
	end
	if p9.at > #p9.order then
		local v10 = table.clone(p9.tracks)
		for v11 = #v10, 2, -1 do
			local v12 = math.random(v11)
			local v13 = v10[v12]
			local v14 = v10[v11]
			v10[v11] = v13
			v10[v12] = v14
		end
		if v10[1] == p9.last and #v10 > 1 then
			local v15 = v10[2]
			local v16 = v10[1]
			v10[1] = v15
			v10[2] = v16
		end
		p9.order = v10
		p9.at = 1
	end
	local v17 = p9.order[p9.at]
	p9.at = p9.at + 1
	p9.last = v17
	return v17
end
local function v_u_22(p19, p20, p21) -- name: fade
	-- upvalues: (copy) v_u_3
	v_u_3:Create(p19, TweenInfo.new(p21, Enum.EasingStyle.Sine), {
		["Volume"] = p20
	}):Play()
end
function v4.start() -- name: start
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_2, (copy) v_u_22, (copy) v_u_18
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_8, (ref) v_u_2, (ref) v_u_22, (ref) v_u_18
		local v_u_23 = v_u_1.LocalPlayer
		local v_u_24 = v_u_8(v_u_2:WaitForChild("Music", 30))
		local v_u_25 = v_u_8(v_u_2:WaitForChild("BattleMusic", 5))
		local v_u_26 = "lobby"
		local v_u_27 = nil
		local v_u_28 = 0
		local function v_u_36(p29) -- name: play
			-- upvalues: (ref) v_u_28, (ref) v_u_27, (ref) v_u_22, (ref) v_u_18, (copy) v_u_25, (copy) v_u_24, (copy) v_u_36, (ref) v_u_26
			v_u_28 = v_u_28 + 1
			local v_u_30 = v_u_28
			local v_u_31 = v_u_27
			if v_u_31 then
				v_u_22(v_u_31, 0, 1.2)
				task.delay(1.2, function()
					-- upvalues: (ref) v_u_27, (copy) v_u_31
					if v_u_27 ~= v_u_31 then
						v_u_31:Stop()
					end
				end)
			end
			local v32 = v_u_18
			local v33
			if p29 == "battle" then
				v33 = v_u_25
			else
				v33 = v_u_24
			end
			local v_u_34 = v32(v33)
			v_u_27 = v_u_34
			if v_u_34 then
				local v35 = v_u_34:GetAttribute("BaseVolume")
				v_u_34.Volume = 0
				v_u_34.TimePosition = p29 == "battle" and 2 or 0
				v_u_34:Play()
				v_u_22(v_u_34, type(v35) ~= "number" and 0.1 or v35, v_u_31 and 1.2 or 0.4)
				task.spawn(function()
					-- upvalues: (ref) v_u_28, (copy) v_u_30, (copy) v_u_34, (ref) v_u_36, (ref) v_u_26
					task.wait(2)
					while v_u_28 == v_u_30 and v_u_34.IsPlaying do
						task.wait(0.5)
					end
					if v_u_28 == v_u_30 then
						task.wait(1)
						if v_u_28 == v_u_30 then
							v_u_36(v_u_26)
						end
					end
				end)
			end
		end
		if v_u_23:GetAttribute("InStages") == true and #v_u_25.tracks > 0 then
			v_u_26 = "battle"
		else
			v_u_26 = "lobby"
		end
		v_u_36(v_u_26)
		v_u_23:GetAttributeChangedSignal("InStages"):Connect(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_25, (ref) v_u_26, (copy) v_u_36
			local v37 = v_u_23:GetAttribute("InStages") == true and #v_u_25.tracks > 0 and "battle" or "lobby"
			if v37 ~= v_u_26 then
				v_u_26 = v37
				v_u_36(v37)
			end
		end)
	end)
end
return v4