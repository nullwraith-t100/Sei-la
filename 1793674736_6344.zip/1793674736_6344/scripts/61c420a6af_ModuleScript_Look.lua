local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Fx.Kit)
local v_u_6 = require(script.Parent.Fx.Modes)
local v_u_7 = require(script.Parent.Fx.Abilities)
local v_u_8 = require(v_u_2.Shared.Config.Eyes)
local v_u_9 = require(v_u_2.Shared.Config.Images)
local v_u_10 = require(v_u_2.Shared.Config.Textures)
local v_u_11 = {}
local v_u_12 = table.clone(v_u_9.Iris)
local v_u_13 = {}
local v_u_14 = {}
local function v_u_25(p15, p_u_16) -- name: hideFace
	local v_u_17 = {}
	for _, v_u_18 in p_u_16:GetChildren() do
		if not v_u_18:IsA("Decal") or v_u_18.Name ~= "face" then
			continue
		end
		local v_u_19 = v_u_18.Transparency
		v_u_18.Transparency = 1
		table.insert(v_u_17, function()
			-- upvalues: (copy) v_u_18, (copy) v_u_19
			v_u_18.Transparency = v_u_19
		end)
	end
	if p_u_16:IsA("MeshPart") and p_u_16.TextureID ~= "" then
		local v_u_20 = p_u_16.TextureID
		p_u_16.TextureID = ""
		table.insert(v_u_17, function()
			-- upvalues: (copy) p_u_16, (copy) v_u_20
			if p_u_16.Parent then
				p_u_16.TextureID = v_u_20
			end
		end)
	end
	for _, v21 in p15:GetChildren() do
		if not v21:IsA("Accessory") or (v21.AccessoryType ~= Enum.AccessoryType.Face or v21:GetAttribute("KeepOnFace") == true) then
			continue
		end
		for _, v_u_22 in v21:GetDescendants() do
			if not v_u_22:IsA("BasePart") then
				continue
			end
			local v_u_23 = v_u_22.Transparency
			v_u_22.Transparency = 1
			table.insert(v_u_17, function()
				-- upvalues: (copy) v_u_22, (copy) v_u_23
				v_u_22.Transparency = v_u_23
			end)
		end
	end
	return function()
		-- upvalues: (copy) v_u_17
		for _, v24 in v_u_17 do
			v24()
		end
	end
end
local function v_u_62(p26, p27) -- name: buildFace
	-- upvalues: (copy) v_u_10, (copy) v_u_5, (copy) v_u_9, (copy) v_u_12
	local v28 = Instance.new("SurfaceGui")
	v28.Name = "AnimeEyes"
	v28.Face = Enum.NormalId.Front
	v28.SizingMode = Enum.SurfaceGuiSizingMode.FixedSize
	v28.CanvasSize = Vector2.new(400, 400)
	v28.LightInfluence = 0
	v28.Brightness = 1.2
	v28.ZOffset = 2
	v28.ClipsDescendants = false
	v28.ResetOnSpawn = false
	v28.Adornee = p26
	local v29 = {}
	local v30 = {}
	for _, v31 in { "L", "R" } do
		local v32 = v31 == "L" and 0.31 or 0.69
		local v33 = Instance.new("Frame")
		v33.Name = "Eye" .. v31
		v33.BackgroundTransparency = 1
		v33.AnchorPoint = Vector2.new(0.5, 0.5)
		v33.Position = UDim2.fromScale(v32, 0.42)
		v33.Size = UDim2.fromScale(0.36, 0.18)
		v33.Parent = v28
		local v34 = v_u_10.Glow
		local v35 = UDim2.fromScale(1.5, 2.4)
		local v36 = UDim2.fromScale(0.5, 0.5)
		local v37 = Instance.new("ImageLabel")
		v37.Name = "Glow"
		v37.BackgroundTransparency = 1
		v37.Image = v34
		v37.Size = v35
		v37.Position = v36
		v37.AnchorPoint = Vector2.new(0.5, 0.5)
		v37.ZIndex = 1
		v37.Parent = v33
		v37.ImageColor3 = v_u_5.color(p27.color)
		v37.ImageTransparency = 1
		local v38 = v_u_9.Eye.White
		local v39 = UDim2.fromScale(1, 1)
		local v40 = UDim2.fromScale(0.5, 0.5)
		local v41 = Instance.new("ImageLabel")
		v41.Name = "White"
		v41.BackgroundTransparency = 1
		v41.Image = v38
		v41.Size = v39
		v41.Position = v40
		v41.AnchorPoint = Vector2.new(0.5, 0.5)
		v41.ZIndex = 2
		v41.Parent = v33
		local v42 = v_u_12[p27.id]
		local v43 = UDim2.fromScale(0.352, 0.703)
		local v44 = UDim2.fromScale(0.5, 0.5)
		local v45 = Instance.new("ImageLabel")
		v45.Name = "Iris"
		v45.BackgroundTransparency = 1
		v45.Image = v42 or ""
		v45.Size = v43
		v45.Position = v44
		v45.AnchorPoint = Vector2.new(0.5, 0.5)
		v45.ZIndex = 3
		v45.Parent = v33
		local v46 = Instance.new("UIAspectRatioConstraint")
		v46.AspectRatio = 1
		v46.Parent = v45
		if not v42 then
			local v47 = v_u_5.color(p27.color)
			local v48 = v47.R * 0.3 + v47.G * 0.59 + v47.B * 0.11 > 0.8
			v45.BackgroundTransparency = 0
			if v48 then
				v47 = v_u_5.color(p27.color2)
			end
			v45.BackgroundColor3 = v47
			local v49 = Instance.new("UICorner")
			v49.CornerRadius = UDim.new(1, 0)
			v49.Parent = v45
			local v50 = Instance.new("Frame")
			v50.AnchorPoint = Vector2.new(0.5, 0.5)
			v50.Position = UDim2.fromScale(0.5, 0.5)
			v50.Size = UDim2.fromScale(0.42, 0.42)
			v50.BackgroundColor3 = v45.BackgroundColor3:Lerp(Color3.new(0, 0, 0), 0.7)
			v50.BorderSizePixel = 0
			v50.ZIndex = 3
			local v51 = Instance.new("UICorner")
			v51.CornerRadius = UDim.new(1, 0)
			v51.Parent = v50
			v50.Parent = v45
		end
		local v52 = v_u_9.Eye.Shine
		local v53 = UDim2.fromScale(0.176, 0.352)
		local v54 = UDim2.fromScale(0.46, 0.41)
		local v55 = Instance.new("ImageLabel")
		v55.Name = "Shine"
		v55.BackgroundTransparency = 1
		v55.Image = v52
		v55.Size = v53
		v55.Position = v54
		v55.AnchorPoint = Vector2.new(0.5, 0.5)
		v55.ZIndex = 4
		v55.Parent = v33
		local v56
		if v31 == "L" then
			v56 = v_u_9.Eye.LidL
		else
			v56 = v_u_9.Eye.LidR
		end
		local v57 = UDim2.fromScale(1, 1)
		local v58 = UDim2.fromScale(0.5, 0.5)
		local v59 = Instance.new("ImageLabel")
		v59.Name = "Lid"
		v59.BackgroundTransparency = 1
		v59.Image = v56
		v59.Size = v57
		v59.Position = v58
		v59.AnchorPoint = Vector2.new(0.5, 0.5)
		v59.ZIndex = 5
		v59.Parent = v33
		table.insert(v29, v45)
		table.insert(v30, v37)
	end
	local v60 = Instance.new("Frame")
	v60.Name = "Mouth"
	v60.BorderSizePixel = 0
	v60.BackgroundColor3 = Color3.fromRGB(40, 22, 28)
	v60.AnchorPoint = Vector2.new(0.5, 0.5)
	v60.Position = UDim2.fromScale(0.5, 0.71)
	v60.Size = UDim2.fromScale(0.16, 0.035)
	local v61 = Instance.new("UICorner")
	v61.CornerRadius = UDim.new(1, 0)
	v61.Parent = v60
	v60.Parent = v28
	v28.Parent = p26
	return v28, v29, v30
end
local function v_u_67(p63) -- name: teardown
	-- upvalues: (copy) v_u_13
	local v64 = v_u_13[p63]
	if v64 then
		v_u_13[p63] = nil
		for _, v65 in v64.links do
			v65:Disconnect()
		end
		if v64.stopMode then
			v64.stopMode()
			v64.stopMode = nil
		end
		for v66 = #v64.showFace, 1, -1 do
			v64.showFace[v66]()
		end
		if v64.face then
			v64.face:Destroy()
		end
	end
end
local function v_u_90(p_u_68, p_u_69) -- name: build
	-- upvalues: (copy) v_u_14, (copy) v_u_67, (copy) v_u_4, (copy) v_u_8, (copy) v_u_62, (copy) v_u_25, (copy) v_u_13, (copy) v_u_6
	local v70 = (v_u_14[p_u_68] or 0) + 1
	v_u_14[p_u_68] = v70
	v_u_67(p_u_68)
	local v_u_71 = p_u_69:WaitForChild("Head", 10)
	local v72 = p_u_69:WaitForChild("HumanoidRootPart", 10)
	if v_u_14[p_u_68] == v70 then
		if v_u_71 and (v_u_71:IsA("BasePart") and (v72 and v72:IsA("BasePart"))) then
			local v73 = p_u_69:FindFirstChildOfClass("Humanoid")
			if p_u_68.Character == p_u_69 and (p_u_69:IsDescendantOf(v_u_4) and (not v73 or v73.Health > 0)) then
				v_u_67(p_u_68)
				if p_u_68:GetAttribute("HideEye") == true then
					return
				else
					local v74 = p_u_68:GetAttribute("Eye")
					local v75 = v_u_8.byId
					if type(v74) ~= "string" then
						v74 = v_u_8.STARTER
					end
					local v76 = v75[v74] or v_u_8.byId[v_u_8.STARTER]
					local v77, v78, v79 = v_u_62(v_u_71, v76)
					local v_u_80 = {
						["player"] = nil,
						["character"] = nil,
						["eyeId"] = nil,
						["irises"] = nil,
						["glows"] = nil,
						["face"] = nil,
						["showFace"] = nil,
						["stopMode"] = nil,
						["links"] = nil,
						["player"] = p_u_68,
						["character"] = p_u_69,
						["eyeId"] = v76.id,
						["irises"] = v78,
						["glows"] = v79,
						["face"] = v77,
						["showFace"] = { (v_u_25(p_u_69, v_u_71)) },
						["links"] = {}
					}
					v_u_13[p_u_68] = v_u_80
					if v73 then
						local v81 = v_u_80.links
						local v82 = v73.Died
						local function v83()
							-- upvalues: (ref) v_u_13, (copy) p_u_68, (copy) v_u_80, (ref) v_u_67
							if v_u_13[p_u_68] == v_u_80 then
								v_u_67(p_u_68)
							end
						end
						table.insert(v81, v82:Connect(v83))
					end
					local v84 = v_u_80.links
					local v85 = p_u_69.AncestryChanged
					local function v86()
						-- upvalues: (ref) v_u_13, (copy) p_u_68, (copy) v_u_80, (copy) p_u_69, (ref) v_u_4, (ref) v_u_67
						if v_u_13[p_u_68] == v_u_80 and not p_u_69:IsDescendantOf(v_u_4) then
							v_u_67(p_u_68)
						end
					end
					table.insert(v84, v85:Connect(v86))
					task.delay(3, function()
						-- upvalues: (ref) v_u_13, (copy) p_u_68, (copy) v_u_80, (copy) v_u_71, (ref) v_u_25, (copy) p_u_69
						if v_u_13[p_u_68] == v_u_80 and v_u_71.Parent then
							local v87 = v_u_80.showFace
							local v88 = v_u_25(p_u_69, v_u_71)
							table.insert(v87, v88)
						end
					end)
					if not v_u_80.stopMode then
						v_u_80.stopMode = v_u_6.start(v_u_80.player, v_u_80.character, v_u_80.eyeId)
						if v_u_80.face then
							v_u_80.face.Brightness = 2.2
						end
						for _, v89 in v_u_80.glows do
							v89.ImageTransparency = 0.35
						end
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_11.dressModel(p91, p92) -- name: dressModel
	-- upvalues: (copy) v_u_8, (copy) v_u_2, (copy) v_u_62, (copy) v_u_25, (copy) v_u_6
	local v93 = v_u_8.byId[p92] or v_u_8.byId[v_u_8.STARTER]
	local v_u_94 = v_u_2:FindFirstChild("Fx")
	local function v97(p95) -- name: leftover
		-- upvalues: (copy) v_u_94
		if p95:IsA("SurfaceGui") then
			return p95.Name == "AnimeEyes"
		end
		if p95:IsA("BillboardGui") then
			return p95.Name == "FormEye" and true or p95.Name == "DivineEye"
		end
		if not p95:IsA("Attachment") then
			return false
		end
		local v96
		if p95.Name == "BloodThread" then
			v96 = true
		elseif v_u_94 == nil then
			v96 = false
		else
			v96 = v_u_94:FindFirstChild(p95.Name) ~= nil
		end
		return v96
	end
	for _, v98 in p91:GetDescendants() do
		if not v97(v98) then
			continue
		end
		v98:Destroy()
	end
	local v_u_99 = {}
	local v100 = p91:FindFirstChild("Head")
	if v100 and v100:IsA("BasePart") then
		local v_u_101, _, v102 = v_u_62(v100, v93)
		v_u_101.Brightness = 2.2
		for _, v103 in v102 do
			v103.ImageTransparency = 0.35
		end
		local v_u_104 = v_u_25(p91, v100)
		table.insert(v_u_99, function()
			-- upvalues: (copy) v_u_104, (copy) v_u_101
			v_u_104()
			v_u_101:Destroy()
		end)
	end
	local v105 = v_u_6.startOn
	local v106 = v93.id
	table.insert(v_u_99, v105(p91, v106))
	local v_u_107 = false
	return function()
		-- upvalues: (ref) v_u_107, (copy) v_u_99
		if not v_u_107 then
			v_u_107 = true
			for v108 = #v_u_99, 1, -1 do
				v_u_99[v108]()
			end
		end
	end
end
function v_u_11.flare(p109) -- name: flare
	-- upvalues: (copy) v_u_13, (copy) v_u_6, (copy) v_u_5
	local v110 = v_u_13[p109]
	if v110 then
		v_u_6.flare(v110.character)
		for _, v111 in v110.irises do
			v111.Rotation = 0
			v_u_5.tween(v111, 0.45, {
				["Rotation"] = 360
			}, Enum.EasingStyle.Quart)
		end
		local v_u_112 = v110.face
		if v_u_112 then
			v_u_112.Brightness = 3.5
			task.delay(0.35, function()
				-- upvalues: (copy) v_u_112
				v_u_112.Brightness = 2.2
			end)
		end
	end
end
local v_u_113 = {}
function v_u_11.pose(p114, p115, p116) -- name: pose
	-- upvalues: (copy) v_u_113, (copy) v_u_1
	local v117 = p114.Character
	if v117 then
		v_u_113[v117] = {
			["character"] = v117,
			["untilTime"] = os.clock() + (p116 and 0.45 or 0.28),
			["both"] = p116
		}
		if p114 == v_u_1.LocalPlayer then
			local v118 = v117:FindFirstChild("HumanoidRootPart")
			local v119 = v117:FindFirstChildOfClass("Humanoid")
			if v118 and (v118:IsA("BasePart") and (v119 and not v119.Sit)) then
				local v120 = p115.X
				local v121 = v118.Position.Y
				local v122 = p115.Z
				local v123 = Vector3.new(v120, v121, v122)
				if (v123 - v118.Position).Magnitude > 1 then
					v118.CFrame = CFrame.lookAt(v118.Position, v123)
				end
			end
		end
	end
end
function v_u_11.start() -- name: start
	-- upvalues: (copy) v_u_90, (copy) v_u_1, (copy) v_u_67, (copy) v_u_14, (copy) v_u_7, (copy) v_u_11, (copy) v_u_3, (copy) v_u_113
	local function v127(p_u_124) -- name: added
		-- upvalues: (ref) v_u_90
		p_u_124.CharacterAdded:Connect(function(p125)
			-- upvalues: (ref) v_u_90, (copy) p_u_124
			v_u_90(p_u_124, p125)
		end)
		if p_u_124.Character then
			task.spawn(v_u_90, p_u_124, p_u_124.Character)
		end
		for _, v126 in { "Eye", "HideEye" } do
			p_u_124:GetAttributeChangedSignal(v126):Connect(function()
				-- upvalues: (copy) p_u_124, (ref) v_u_90
				if p_u_124.Character then
					v_u_90(p_u_124, p_u_124.Character)
				end
			end)
		end
	end
	v_u_1.PlayerAdded:Connect(v127)
	for _, v128 in v_u_1:GetPlayers() do
		v127(v128)
	end
	v_u_1.PlayerRemoving:Connect(function(p129)
		-- upvalues: (ref) v_u_67, (ref) v_u_14
		v_u_67(p129)
		v_u_14[p129] = nil
	end)
	v_u_7.onCast(function(p130, p131, p132)
		-- upvalues: (ref) v_u_11, (ref) v_u_1
		v_u_11.flare(p130)
		if p130 ~= v_u_1.LocalPlayer then
			v_u_11.pose(p130, p131, p132.cooldown >= 3)
		end
	end)
	v_u_3.Stepped:Connect(function()
		-- upvalues: (ref) v_u_113
		local v133 = os.clock()
		for v134, v135 in v_u_113 do
			if v135.untilTime < v133 or not v134.Parent then
				v_u_113[v134] = nil
			else
				local v136 = v134:FindFirstChild("RightUpperArm")
				if v136 then
					v136 = v136:FindFirstChild("RightShoulder")
				end
				if not (v136 and v136:IsA("Motor6D")) then
					v136 = nil
				end
				local v137 = v134:FindFirstChild("LeftUpperArm")
				if v137 then
					v137 = v137:FindFirstChild("LeftShoulder")
				end
				if not (v137 and v137:IsA("Motor6D")) then
					v137 = nil
				end
				if v135.both then
					if v136 then
						v136.Transform = CFrame.Angles(1.4835298641951802, 0, -0.6108652381980153)
					end
					if not v137 then
						continue
					end
					v137.Transform = CFrame.Angles(1.4835298641951802, 0, 0.6108652381980153)
				else
					if not v136 then
						continue
					end
					v136.Transform = CFrame.Angles(1.6580627893946132, 0, 0)
				end
			end
		end
	end)
end
return v_u_11