require(script.Parent.Training)
return {
	{
		["id"] = "w7_sand_dummy",
		["name"] = "Sand Dummy",
		["theme"] = "dummy",
		["rebirths"] = 477,
		["mult"] = 4.2e23,
		["color"] = "#F2EEE4"
	},
	{
		["id"] = "w7_cero_ring",
		["name"] = "Cero Ring",
		["theme"] = "ring",
		["rebirths"] = 485,
		["mult"] = 1.34e24,
		["color"] = "#2EE6C9"
	},
	{
		["id"] = "w7_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 4.3e24,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w7_quartz_falls",
		["name"] = "Quartz Falls",
		["theme"] = "waterfall",
		["rebirths"] = 493,
		["mult"] = 4.3e24,
		["color"] = "#9FE8FF"
	},
	{
		["id"] = "w7_bone_forge",
		["name"] = "Bone Forge",
		["theme"] = "forge",
		["rebirths"] = 501,
		["mult"] = 1.36e25,
		["color"] = "#FF5A3A"
	},
	{
		["id"] = "w7_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 4.4e25,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w7_las_noches_temple",
		["name"] = "Las Noches Temple",
		["theme"] = "temple",
		["rebirths"] = 509,
		["mult"] = 4.4e25,
		["color"] = "#E8E4D8"
	},
	{
		["id"] = "w7_sonido_tower",
		["name"] = "Sonido Tower",
		["theme"] = "storm",
		["rebirths"] = 517,
		["mult"] = 1.41e26,
		["color"] = "#8FD3FF"
	},
	{
		["id"] = "w7_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 4.5e26,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w7_garganta_chamber",
		["name"] = "Garganta Chamber",
		["theme"] = "gravity",
		["rebirths"] = 525,
		["mult"] = 4.5e26,
		["color"] = "#8A3CFF"
	},
	{
		["id"] = "w7_menos_shrine",
		["name"] = "Menos Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 533,
		["mult"] = 1.45e27,
		["color"] = "#FF2E3A"
	},
	{
		["id"] = "w7_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 1.56e28,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w7_espada_altar",
		["name"] = "Espada Altar",
		["theme"] = "void",
		["rebirths"] = 541,
		["mult"] = 4.6e27,
		["color"] = "#2BFF9A"
	}
}