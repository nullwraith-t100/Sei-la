return {
	["nearest"] = function(p1, p2, p3) -- name: nearest
		local v4 = nil
		for _, v5 in p2 do
			local v6 = v5.pos
			local v7 = v6.X - p1.X
			local v8 = v6.Z - p1.Z
			local v9 = Vector3.new(v7, 0, v8).Magnitude
			if v9 > p3 then
				continue
			end
			v4 = v5
			p3 = v9
		end
		return v4
	end,
	["cluster"] = function(p10, p11, p12, p13) -- name: cluster
		local v14 = -1
		local v15 = (1 / 0)
		local v16 = nil
		for _, v17 in p11 do
			local v18 = v17.pos
			local v19 = v18.X - p10.X
			local v20 = v18.Z - p10.Z
			local v21 = Vector3.new(v19, 0, v20).Magnitude
			if v21 > p12 then
				continue
			end
			local v22 = 0
			for _, v23 in p11 do
				local v24 = v23.pos
				local v25 = v17.pos
				local v26 = v24.X - v25.X
				local v27 = v24.Z - v25.Z
				if Vector3.new(v26, 0, v27).Magnitude > p13 then
					continue
				end
				v22 = v22 + (v23.boss and 3 or 1)
			end
			if v14 >= v22 and (v22 ~= v14 or v21 >= v15) then
				break
			end
			v16 = v17
			v15 = v21
			v14 = v22
		end
		return v16
	end
}