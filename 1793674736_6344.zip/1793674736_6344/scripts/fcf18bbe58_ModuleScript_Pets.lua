local v_u_1 = {
	["EQUIP_MAX"] = 3,
	["SPACE"] = 30
}
local v2 = {}
local v3 = {
	["id"] = "shiba",
	["name"] = "Shiba",
	["rarity"] = "Common",
	["mult"] = 1.1,
	["look"] = nil,
	["look"] = {
		["body"] = "#E2702C",
		["accent"] = "#FFF1DE",
		["ears"] = "dog",
		["tails"] = 1,
		["tail"] = "curl",
		["cloth"] = "#E5322D",
		["gear"] = nil,
		["gear"] = {
			"brows",
			"socks",
			"bandana",
			"tongue"
		}
	}
}
local v4 = {
	["id"] = "kitty",
	["name"] = "Kitty",
	["rarity"] = "Common",
	["mult"] = 1.2,
	["look"] = nil,
	["look"] = {
		["body"] = "#8C96A8",
		["accent"] = "#F2F4F8",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["cloth"] = "#FF4F86",
		["gear"] = nil,
		["gear"] = {
			"stripes",
			"whiskers",
			"collar",
			"bell"
		}
	}
}
local v5 = {
	["id"] = "bunny",
	["name"] = "Bunny",
	["rarity"] = "Rare",
	["mult"] = 1.4,
	["look"] = nil,
	["look"] = {
		["body"] = "#F7F7FB",
		["accent"] = "#FFE1EC",
		["ears"] = "bunny",
		["tails"] = 1,
		["tail"] = "puff",
		["glow"] = "#FF7FBF",
		["cloth"] = "#45B5FF",
		["gear"] = nil,
		["gear"] = { "teeth", "bow" }
	}
}
local v6 = {
	["id"] = "panda",
	["name"] = "Panda",
	["rarity"] = "Epic",
	["mult"] = 1.7,
	["look"] = nil,
	["look"] = {
		["body"] = "#F7F7F7",
		["accent"] = "#E6E6EE",
		["limbs"] = "#24242C",
		["ears"] = "round",
		["tails"] = 0,
		["glow"] = "#B45CFF",
		["cloth"] = "#E5322D",
		["gear"] = nil,
		["gear"] = {
			"patches",
			"band",
			"headband",
			"bamboo"
		}
	}
}
local v7 = {
	["id"] = "gold_shiba",
	["name"] = "Golden Shiba",
	["rarity"] = "Legendary",
	["mult"] = 2.5,
	["look"] = nil,
	["look"] = {
		["body"] = "#FFC531",
		["accent"] = "#FFF4CC",
		["ears"] = "dog",
		["tails"] = 1,
		["tail"] = "curl",
		["glow"] = "#FFE36B",
		["cloth"] = "#D61F3C",
		["gear"] = nil,
		["gear"] = {
			"brows",
			"socks",
			"crown",
			"cape"
		}
	}
}
local v8 = {
	["id"] = "toad",
	["name"] = "Ninja Toad",
	["rarity"] = "Common",
	["mult"] = 1.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "toad",
		["body"] = "#E8783A",
		["accent"] = "#6A3E9C",
		["belly"] = "#FFE2B0",
		["eye"] = "#FFD84A",
		["ears"] = "none",
		["tails"] = 0,
		["cloth"] = "#2B3A67",
		["gear"] = nil,
		["gear"] = {
			"marks",
			"headband",
			"plate",
			"pipe",
			"scroll"
		}
	}
}
local v9 = {
	["id"] = "crow",
	["name"] = "Shadow Crow",
	["rarity"] = "Rare",
	["mult"] = 2.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#26263A",
		["accent"] = "#3B3B58",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF2A3A",
		["cloth"] = "#1A1A28",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#30304A", "#1E1E30", "#FF2A3A" },
		["gear"] = {
			"crest",
			"headband",
			"plate",
			"scratch"
		}
	}
}
local v10 = {
	["id"] = "serpent",
	["name"] = "White Serpent",
	["rarity"] = "Epic",
	["mult"] = 2.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "serpent",
		["body"] = "#EDEAF7",
		["accent"] = "#9B4DFF",
		["belly"] = "#FFF4DC",
		["eye"] = "#FFD23F",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#B57BFF",
		["cloth"] = "#7A3FD1",
		["gear"] = nil,
		["gear"] = { "eyeline", "horns", "rope" }
	}
}
local v11 = {
	["id"] = "kitsune",
	["name"] = "Kitsune",
	["rarity"] = "Legendary",
	["mult"] = 3.6,
	["look"] = nil,
	["look"] = {
		["body"] = "#FF8A3D",
		["accent"] = "#FFFFFF",
		["ears"] = "fox",
		["tails"] = 3,
		["tail"] = "fluffy",
		["glow"] = "#FF2E4D",
		["cloth"] = "#E5322D",
		["spirit"] = "#5FD4FF",
		["gear"] = nil,
		["gear"] = {
			"marks",
			"rope",
			"mask",
			"foxfire"
		}
	}
}
local v12 = {
	["id"] = "nine_tails",
	["name"] = "Nine-Tails",
	["rarity"] = "Mythic",
	["mult"] = 5,
	["look"] = nil,
	["look"] = {
		["body"] = "#FF5A1F",
		["accent"] = "#2A0610",
		["belly"] = "#FF8A4A",
		["eye"] = "#FF2A3A",
		["ears"] = "long",
		["tails"] = 9,
		["tail"] = "fluffy",
		["glow"] = "#FF8A1F",
		["tip"] = "#FF5A00",
		["aura"] = "flames",
		["gear"] = nil,
		["gear"] = { "eyeline", "fangs" }
	}
}
local v13 = {
	["id"] = "celestial_dragon",
	["name"] = "Celestial Dragon",
	["rarity"] = "Mythic",
	["mult"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["body"] = "#5CC6FF",
		["accent"] = "#FFFFFF",
		["belly"] = "#F2FBFF",
		["eye"] = "#FFD23F",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF7AD2",
		["spirit"] = "#FFFFFF",
		["wings"] = nil,
		["aura"] = "rainbow",
		["gear"] = nil,
		["wings"] = { "#6FF0FF", "#A884FF", "#FF7AD2" },
		["gear"] = {
			"antlers",
			"frills",
			"mane",
			"barbels",
			"halo",
			"pearl"
		}
	}
}
local v14 = {
	["id"] = "sunfire_phoenix",
	["name"] = "Sunfire Phoenix",
	["rarity"] = "Mythic",
	["mult"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#FF5A1F",
		["accent"] = "#FFE15A",
		["belly"] = "#FFC46A",
		["beak"] = "#FFE15A",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FFD23F",
		["spirit"] = "#FFF4C2",
		["wings"] = nil,
		["aura"] = "flames",
		["gear"] = nil,
		["wings"] = { "#FFE15A", "#FFA21F", "#FF3B1F" },
		["gear"] = { "crest", "plumes", "halo" }
	}
}
local v15 = {
	["id"] = "storm_tiger",
	["name"] = "Storm Tiger",
	["rarity"] = "Mythic",
	["mult"] = 4,
	["look"] = nil,
	["look"] = {
		["size"] = 1.1,
		["body"] = "#3A4A7A",
		["accent"] = "#FFFFFF",
		["belly"] = "#DDEBFF",
		["eye"] = "#FFE15A",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#FFE15A",
		["glow"] = "#FFE15A",
		["gear"] = nil,
		["aura"] = "rainbow",
		["gear"] = { "tigerstripes", "sabers", "whiskers" }
	}
}
local v16 = {
	["id"] = "shadow_pegasus",
	["name"] = "Shadow Pegasus",
	["rarity"] = "Mythic",
	["mult"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "horse",
		["fly"] = true,
		["size"] = 1.05,
		["body"] = "#241A33",
		["accent"] = "#B04DFF",
		["belly"] = "#3A2A52",
		["eye"] = "#D08AFF",
		["ears"] = "dog",
		["tails"] = 0,
		["glow"] = "#B04DFF",
		["tip"] = "#D08AFF",
		["spirit"] = "#B04DFF",
		["beak"] = "#C9B8FF",
		["wings"] = nil,
		["aura"] = "cosmic",
		["gear"] = nil,
		["wings"] = { "#3A2A52", "#6B3FA8", "#B04DFF" },
		["gear"] = { "nebulamane", "startail" }
	}
}
local v17 = {
	["id"] = "akatsuki_crow",
	["name"] = "Akatsuki Crow",
	["rarity"] = "Epic",
	["mult"] = 6,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#1C1A24",
		["accent"] = "#2E2A3A",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF2A3A",
		["cloth"] = "#16141C",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#1C1A24", "#2E2A3A", "#FF2A3A" },
		["gear"] = {
			"crest",
			"headband",
			"plate",
			"scratch",
			"clouds"
		}
	}
}
local v18 = {
	["id"] = "red_cloud_fox",
	["name"] = "Red Cloud Fox",
	["rarity"] = "Epic",
	["mult"] = 8,
	["look"] = nil,
	["look"] = {
		["body"] = "#1C1A24",
		["accent"] = "#E5141E",
		["belly"] = "#2E2A3A",
		["eye"] = "#FF2A3A",
		["ears"] = "fox",
		["tails"] = 2,
		["tail"] = "fluffy",
		["glow"] = "#FF3B3B",
		["tip"] = "#FF2A3A",
		["cloth"] = "#E5141E",
		["gear"] = nil,
		["gear"] = {
			"marks",
			"headband",
			"plate",
			"scratch",
			"clouds"
		}
	}
}
__set_list(v2, 1, {v3, v4, v5, v6, v7, v8, v9, v10, v11, v12, v13, v14, v15, v16, v17, v18})
local v19 = {
	["id"] = "samehada",
	["name"] = "Samehada Shark",
	["rarity"] = "Legendary",
	["mult"] = 10,
	["look"] = nil,
	["look"] = {
		["shape"] = "serpent",
		["body"] = "#4A6C9E",
		["accent"] = "#22344E",
		["belly"] = "#DDE9FA",
		["eye"] = "#7FE9FF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#5FD4FF",
		["cloth"] = "#1C1A24",
		["gear"] = nil,
		["gear"] = {
			"eyeline",
			"fins",
			"fangs",
			"rope"
		}
	}
}
local v20 = {
	["id"] = "puppet_scorpion",
	["name"] = "Puppet Scorpion",
	["rarity"] = "Legendary",
	["mult"] = 12,
	["look"] = nil,
	["look"] = {
		["body"] = "#8A4B2A",
		["accent"] = "#E8C9A0",
		["limbs"] = "#5E3219",
		["eye"] = "#C08BFF",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "stinger",
		["glow"] = "#B57BFF",
		["gear"] = nil,
		["gear"] = { "marks", "claws", "clouds" }
	}
}
local v21 = {
	["id"] = "akatsuki_dragon",
	["name"] = "Akatsuki Dragon",
	["rarity"] = "Mythic",
	["mult"] = 20,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#1C1A24",
		["accent"] = "#E5141E",
		["belly"] = "#2E2A3A",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF2A3A",
		["wings"] = nil,
		["aura"] = "flames",
		["gear"] = nil,
		["wings"] = { "#1C1A24", "#2E2A3A", "#FF2A3A" },
		["gear"] = {
			"horns",
			"frills",
			"mane",
			"clouds"
		}
	}
}
local v22 = {
	["id"] = "angel_bunny",
	["name"] = "Angel Bunny",
	["rarity"] = "Epic",
	["mult"] = 10,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["body"] = "#FFFFFF",
		["accent"] = "#FFF1CC",
		["ears"] = "bunny",
		["tails"] = 1,
		["tail"] = "puff",
		["glow"] = "#FFD24A",
		["cloth"] = "#FFD24A",
		["spirit"] = "#7FE9FF",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#FFF4D6", "#FFD24A" },
		["gear"] = {
			"halo",
			"gem",
			"teeth",
			"bow"
		}
	}
}
local v23 = {
	["id"] = "holy_owl",
	["name"] = "Holy Owl",
	["rarity"] = "Epic",
	["mult"] = 13,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#F7F1E1",
		["accent"] = "#FFFFFF",
		["eye"] = "#FFC93C",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FFD24A",
		["spirit"] = "#7FE9FF",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#F7F1E1", "#FFD24A" },
		["gear"] = {
			"tufts",
			"eyeline",
			"halo",
			"gem"
		}
	}
}
local v24 = {
	["id"] = "seraph_cat",
	["name"] = "Seraph Cat",
	["rarity"] = "Legendary",
	["mult"] = 16,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["body"] = "#FFFBF0",
		["accent"] = "#FFF1CC",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["glow"] = "#FFD24A",
		["tip"] = "#FFD24A",
		["cloth"] = "#FFD24A",
		["spirit"] = "#FF7AD2",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#FFF4D6", "#FFD24A" },
		["gear"] = {
			"halo",
			"gem",
			"whiskers",
			"collar",
			"bell"
		}
	}
}
local v25 = {
	["id"] = "golden_phoenix",
	["name"] = "Golden Phoenix",
	["rarity"] = "Legendary",
	["mult"] = 22,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#FFB21F",
		["accent"] = "#FFE9A8",
		["eye"] = "#FF4A1A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF7A1A",
		["spirit"] = "#FFD24A",
		["wings"] = nil,
		["aura"] = "flames",
		["gear"] = nil,
		["wings"] = { "#FF7A1A", "#FFB21F", "#FF7A1A" },
		["gear"] = { "crest", "gem", "foxfire" }
	}
}
local v26 = {
	["id"] = "divine_dragon",
	["name"] = "Divine Dragon",
	["rarity"] = "Mythic",
	["mult"] = 35,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#FFFFFF",
		["accent"] = "#FFF1CC",
		["belly"] = "#FFE7A3",
		["eye"] = "#4AD8FF",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FFD24A",
		["spirit"] = "#FFF4D6",
		["wings"] = nil,
		["aura"] = "rainbow",
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#FFF4D6", "#FFD24A" },
		["gear"] = {
			"antlers",
			"frills",
			"mane",
			"barbels",
			"halo",
			"pearl"
		}
	}
}
local v27 = {
	["id"] = "kurama",
	["name"] = "Kyubi",
	["rarity"] = "Mythic",
	["mult"] = 100,
	["pass"] = "kurama",
	["look"] = nil,
	["look"] = {
		["size"] = 1.3,
		["body"] = "#FF6A1A",
		["accent"] = "#1A0408",
		["belly"] = "#FF9A4A",
		["eye"] = "#FF1A2A",
		["ears"] = "long",
		["tails"] = 9,
		["tail"] = "fluffy",
		["glow"] = "#FFB02B",
		["tip"] = "#FF4A00",
		["aura"] = "flames",
		["gear"] = nil,
		["gear"] = {
			"eyeline",
			"marks",
			"fangs",
			"mane"
		}
	}
}
local v28 = {
	["id"] = "lotus_frog",
	["name"] = "Lotus Frog",
	["rarity"] = "Common",
	["mult"] = 2.4,
	["look"] = nil,
	["look"] = {
		["shape"] = "toad",
		["body"] = "#8ED86A",
		["accent"] = "#FF8FC4",
		["belly"] = "#F4FFE0",
		["ears"] = "none",
		["tails"] = 0,
		["gear"] = nil,
		["gear"] = { "marks", "lotus" }
	}
}
local v29 = {
	["id"] = "koi",
	["name"] = "Koi",
	["rarity"] = "Rare",
	["mult"] = 3,
	["look"] = nil,
	["look"] = {
		["shape"] = "fish",
		["fly"] = true,
		["body"] = "#FFFFFF",
		["accent"] = "#FF5A1F",
		["belly"] = "#FFF1E6",
		["limbs"] = "#FF9A5A",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FFB35A",
		["gear"] = nil,
		["gear"] = { "spots", "barbels" }
	}
}
local v30 = {
	["id"] = "lotus_turtle",
	["name"] = "Lotus Turtle",
	["rarity"] = "Epic",
	["mult"] = 3.8,
	["look"] = nil,
	["look"] = {
		["body"] = "#6FCFB0",
		["accent"] = "#E8FFF4",
		["belly"] = "#E8FFF4",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF8FC4",
		["cloth"] = "#2E8A6A",
		["gear"] = nil,
		["gear"] = { "shell", "lotus" }
	}
}
local v31 = {
	["id"] = "sacred_crane",
	["name"] = "Sacred Crane",
	["rarity"] = "Legendary",
	["mult"] = 4.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#FFFFFF",
		["accent"] = "#26262E",
		["belly"] = "#FFFFFF",
		["eye"] = "#FF4F9A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF6FB5",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#26262E", "#FF6FB5" },
		["gear"] = { "crest", "eyeline" }
	}
}
local v32 = {
	["id"] = "lotus_dragon",
	["name"] = "Lotus Dragon",
	["rarity"] = "Mythic",
	["mult"] = 6.5,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["body"] = "#FFF0F6",
		["accent"] = "#FF5FA8",
		["belly"] = "#FFD6E8",
		["eye"] = "#FF3A8A",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF6FB5",
		["spirit"] = "#FFFFFF",
		["wings"] = nil,
		["aura"] = "rainbow",
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#FFC4E2", "#FF6FB5" },
		["gear"] = {
			"lotus",
			"frills",
			"mane",
			"barbels",
			"pearl"
		}
	}
}
local v33 = {
	["id"] = "moon_bunny",
	["name"] = "Moon Bunny",
	["rarity"] = "Common",
	["mult"] = 3.2,
	["look"] = nil,
	["look"] = {
		["body"] = "#F4F8FF",
		["accent"] = "#DCE8FF",
		["ears"] = "bunny",
		["tails"] = 1,
		["tail"] = "puff",
		["glow"] = "#7FD3FF",
		["gear"] = nil,
		["gear"] = { "crescent", "teeth" }
	}
}
local v34 = {
	["id"] = "star_owl",
	["name"] = "Star Owl",
	["rarity"] = "Rare",
	["mult"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#2B3A7A",
		["accent"] = "#FFE98A",
		["belly"] = "#7FC8FF",
		["eye"] = "#FFD84A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#7FD3FF",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#2B3A7A", "#3E58B0", "#7FD3FF" },
		["gear"] = { "tufts", "star", "starry" }
	}
}
__set_list(v2, 17, {v19, v20, v21, v22, v23, v24, v25, v26, v27, v28, v29, v30, v31, v32, v33, v34})
local v35 = {
	["id"] = "sky_whale",
	["name"] = "Sky Whale",
	["rarity"] = "Epic",
	["mult"] = 5,
	["look"] = nil,
	["look"] = {
		["shape"] = "whale",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#6FB8F0",
		["accent"] = "#FFE98A",
		["belly"] = "#F2FBFF",
		["limbs"] = "#4F98D8",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FFD84A",
		["gear"] = nil,
		["gear"] = { "starry", "crescent" }
	}
}
local v36 = {
	["id"] = "star_pegasus",
	["name"] = "Star Pegasus",
	["rarity"] = "Legendary",
	["mult"] = 6.5,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["body"] = "#FFFFFF",
		["accent"] = "#BFE4FF",
		["ears"] = "dog",
		["tails"] = 1,
		["tail"] = "fluffy",
		["glow"] = "#FFD84A",
		["tip"] = "#FFD84A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#BFE4FF", "#FFD84A" },
		["gear"] = { "mane", "star", "socks" }
	}
}
local v37 = {
	["id"] = "astral_kirin",
	["name"] = "Astral Kirin",
	["rarity"] = "Mythic",
	["mult"] = 9,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["body"] = "#2A3E9A",
		["accent"] = "#FFE98A",
		["belly"] = "#7FC8FF",
		["eye"] = "#FFE14B",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "fluffy",
		["glow"] = "#7FE9FF",
		["tip"] = "#7FE9FF",
		["spirit"] = "#FFF4D6",
		["aura"] = "rainbow",
		["gear"] = nil,
		["gear"] = {
			"antlers",
			"frills",
			"mane",
			"crescent",
			"starry",
			"pearl"
		}
	}
}
local v38 = {
	["id"] = "moon_bat",
	["name"] = "Moon Bat",
	["rarity"] = "Common",
	["mult"] = 4.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "bat",
		["fly"] = true,
		["body"] = "#4E2D5C",
		["accent"] = "#FF9CC2",
		["belly"] = "#F7E3EE",
		["limbs"] = "#2E1838",
		["ears"] = "none",
		["tails"] = 0,
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#A3579A", "#2E1838" },
		["gear"] = { "fang", "crescent" }
	}
}
local v39 = {
	["id"] = "crimson_fox",
	["name"] = "Crimson Fox",
	["rarity"] = "Rare",
	["mult"] = 5.2,
	["look"] = nil,
	["look"] = {
		["body"] = "#D7263D",
		["accent"] = "#FFF3EE",
		["belly"] = "#FFF3EE",
		["limbs"] = "#3B1119",
		["ears"] = "fox",
		["tails"] = 1,
		["tail"] = "fluffy",
		["glow"] = "#FF5A70",
		["gear"] = nil,
		["gear"] = { "socks", "marks", "lily" }
	}
}
local v40 = {
	["id"] = "blood_raven",
	["name"] = "Blood Raven",
	["rarity"] = "Epic",
	["mult"] = 6.5,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#2A1520",
		["accent"] = "#E3122E",
		["belly"] = "#43202E",
		["beak"] = "#3A2A32",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF2A3A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#2A1520", "#5C1024", "#FF2A3A" },
		["gear"] = { "thorns", "eyeline", "drop" }
	}
}
local v41 = {
	["id"] = "vampire_cat",
	["name"] = "Vampire Cat",
	["rarity"] = "Legendary",
	["mult"] = 8.4,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["size"] = 1.05,
		["body"] = "#2E2440",
		["accent"] = "#E3122E",
		["belly"] = "#ECE4F4",
		["eye"] = "#FF2A3A",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#FF2A3A",
		["glow"] = "#FF2A3A",
		["cloth"] = "#15101C",
		["membrane"] = true,
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#5A1630", "#15101C", "#FF2A3A" },
		["gear"] = { "bite", "vcape" }
	}
}
local v42 = {
	["id"] = "blood_moon_wolf",
	["name"] = "Blood Moon Wolf",
	["rarity"] = "Mythic",
	["mult"] = 11.5,
	["look"] = nil,
	["look"] = {
		["size"] = 1.2,
		["body"] = "#2B2433",
		["accent"] = "#C9C0D6",
		["belly"] = "#D9D2E4",
		["eye"] = "#FF2A3A",
		["ears"] = "fox",
		["tails"] = 1,
		["tail"] = "fluffy",
		["tip"] = "#FF2A3A",
		["glow"] = "#FF2A3A",
		["aura"] = "blood",
		["gear"] = nil,
		["gear"] = {
			"marks",
			"fangs",
			"ruff",
			"moonhalo"
		}
	}
}
local v43 = {
	["id"] = "demon_imp",
	["name"] = "Demon Imp",
	["rarity"] = "Common",
	["mult"] = 5.6,
	["look"] = nil,
	["look"] = {
		["shape"] = "imp",
		["fly"] = true,
		["size"] = 0.95,
		["body"] = "#E5383B",
		["accent"] = "#2B0C14",
		["belly"] = "#FFB4A2",
		["limbs"] = "#C82A32",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "spade",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#7A1A2A", "#2B0C14" },
		["gear"] = { "demonhorns", "fang", "pitchfork" }
	}
}
local v44 = {
	["id"] = "oni_pup",
	["name"] = "Oni Pup",
	["rarity"] = "Rare",
	["mult"] = 7,
	["look"] = nil,
	["look"] = {
		["body"] = "#EE5A3C",
		["accent"] = "#FFE2CF",
		["belly"] = "#FFE2CF",
		["ears"] = "dog",
		["tails"] = 1,
		["tail"] = "curl",
		["glow"] = "#FFC23A",
		["cloth"] = "#FFC531",
		["gear"] = nil,
		["gear"] = {
			"onihorns",
			"tusks",
			"tigerscarf",
			"kanabo"
		}
	}
}
local v45 = {
	["id"] = "hell_spider",
	["name"] = "Hell Spider",
	["rarity"] = "Epic",
	["mult"] = 8.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "spider",
		["body"] = "#22161C",
		["accent"] = "#FF7A1A",
		["belly"] = "#3A242C",
		["limbs"] = "#33202A",
		["eye"] = "#FFB02B",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF6A12",
		["spirit"] = "#FFB02B",
		["gear"] = nil,
		["gear"] = { "hourglass", "horns" }
	}
}
local v46 = {
	["id"] = "demon_lion",
	["name"] = "Demon Lion",
	["rarity"] = "Legendary",
	["mult"] = 11.4,
	["look"] = nil,
	["look"] = {
		["size"] = 1.1,
		["body"] = "#7A1C24",
		["accent"] = "#FFB02B",
		["belly"] = "#A8443C",
		["eye"] = "#FFC23A",
		["ears"] = "round",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#FF7A1A",
		["glow"] = "#FF7A1A",
		["gear"] = nil,
		["gear"] = {
			"lionmane",
			"demonhorns",
			"lava",
			"bite"
		}
	}
}
local v47 = {
	["id"] = "demon_dragon",
	["name"] = "Demon Dragon",
	["rarity"] = "Mythic",
	["mult"] = 16,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["size"] = 1.2,
		["membrane"] = true,
		["body"] = "#46121C",
		["accent"] = "#FF4A1A",
		["belly"] = "#7A2422",
		["eye"] = "#FFC23A",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF4A1A",
		["wings"] = nil,
		["aura"] = "hellfire",
		["gear"] = nil,
		["wings"] = { "#7A1A26", "#22080E", "#FF4A1A" },
		["gear"] = {
			"demonhorns",
			"lava",
			"mane",
			"fangs"
		}
	}
}
local v48 = {
	["id"] = "snow_fox",
	["name"] = "Snow Fox",
	["rarity"] = "Common",
	["mult"] = 7.4,
	["look"] = nil,
	["look"] = {
		["body"] = "#F2F8FF",
		["accent"] = "#BFE3FF",
		["belly"] = "#FFFFFF",
		["ears"] = "arctic",
		["tails"] = 1,
		["tail"] = "fluffy",
		["cloth"] = "#3FA0FF",
		["gear"] = nil,
		["gear"] = { "scarf", "snowflake" }
	}
}
local v49 = {
	["id"] = "frost_penguin",
	["name"] = "Frost Penguin",
	["rarity"] = "Rare",
	["mult"] = 9.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "penguin",
		["body"] = "#24324F",
		["accent"] = "#FFA62B",
		["belly"] = "#F7FBFF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#8FE3FF",
		["cloth"] = "#3FB6FF",
		["gear"] = nil,
		["gear"] = { "beanie", "scarf" }
	}
}
local v50 = {
	["id"] = "ice_owl",
	["name"] = "Ice Owl",
	["rarity"] = "Epic",
	["mult"] = 11.6,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#E2F1FF",
		["accent"] = "#7FB8F0",
		["belly"] = "#FFFFFF",
		["beak"] = "#AFC4DA",
		["eye"] = "#3FD0FF",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#5FDCFF",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#E2F1FF", "#BFE0FF", "#5FDCFF" },
		["gear"] = { "tufts", "icecrown", "crystals" }
	}
}
__set_list(v2, 33, {v35, v36, v37, v38, v39, v40, v41, v42, v43, v44, v45, v46, v47, v48, v49, v50})
local v51 = {
	["id"] = "frost_tiger",
	["name"] = "Frost Tiger",
	["rarity"] = "Legendary",
	["mult"] = 15,
	["look"] = nil,
	["look"] = {
		["size"] = 1.1,
		["body"] = "#EEF6FF",
		["accent"] = "#1F2F6E",
		["belly"] = "#FFFFFF",
		["eye"] = "#4FDCFF",
		["ears"] = "round",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#6FE6FF",
		["glow"] = "#6FE6FF",
		["gear"] = nil,
		["gear"] = { "tigerstripes", "sabers", "crystals" }
	}
}
local v52 = {
	["id"] = "ice_phoenix",
	["name"] = "Ice Phoenix",
	["rarity"] = "Mythic",
	["mult"] = 20.5,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["size"] = 1.2,
		["body"] = "#BFE8FF",
		["accent"] = "#FFFFFF",
		["belly"] = "#E8F8FF",
		["beak"] = "#E8F8FF",
		["eye"] = "#2F6BFF",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#4FD8FF",
		["spirit"] = "#FFFFFF",
		["wings"] = nil,
		["aura"] = "frost",
		["gear"] = nil,
		["wings"] = { "#E8F8FF", "#8FD8FF", "#4FD8FF" },
		["gear"] = { "icecrown", "gem", "plumes" }
	}
}
local v53 = {
	["id"] = "glow_fish",
	["name"] = "Glow Fish",
	["rarity"] = "Common",
	["mult"] = 10,
	["look"] = nil,
	["look"] = {
		["shape"] = "fish",
		["fly"] = true,
		["body"] = "#2F4FA8",
		["accent"] = "#5A7FE0",
		["belly"] = "#9FC0FF",
		["limbs"] = "#22388A",
		["ears"] = "none",
		["tails"] = 1,
		["spirit"] = "#7FFFE0",
		["gear"] = nil,
		["gear"] = { "lure", "jaws" }
	}
}
local v54 = {
	["id"] = "deep_jelly",
	["name"] = "Deep Jelly",
	["rarity"] = "Rare",
	["mult"] = 12.4,
	["look"] = nil,
	["look"] = {
		["shape"] = "jelly",
		["fly"] = true,
		["body"] = "#9A7BFF",
		["accent"] = "#FF9FE6",
		["belly"] = "#E4DBFF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#C99BFF",
		["spirit"] = "#FFFFFF",
		["gear"] = nil,
		["gear"] = { "glowdots" }
	}
}
local v55 = {
	["id"] = "abyss_turtle",
	["name"] = "Abyss Turtle",
	["rarity"] = "Epic",
	["mult"] = 15.6,
	["look"] = nil,
	["look"] = {
		["shape"] = "seaturtle",
		["fly"] = true,
		["body"] = "#3B7F8C",
		["accent"] = "#4FE0C8",
		["belly"] = "#D2F2EA",
		["cloth"] = "#173A5C",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#4FE0C8",
		["gear"] = nil,
		["gear"] = { "coral", "glowdots" }
	}
}
local v56 = {
	["id"] = "kraken",
	["name"] = "Kraken",
	["rarity"] = "Legendary",
	["mult"] = 20,
	["look"] = nil,
	["look"] = {
		["shape"] = "octopus",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#5E2E96",
		["accent"] = "#FF7AD9",
		["belly"] = "#FFA8E8",
		["eye"] = "#FFE14B",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF5AD1",
		["spirit"] = "#8FFFF2",
		["gear"] = nil,
		["gear"] = { "crown", "glowdots", "pearl" }
	}
}
local v57 = {
	["id"] = "abyss_serpent",
	["name"] = "Abyss Serpent",
	["rarity"] = "Mythic",
	["mult"] = 28,
	["look"] = nil,
	["look"] = {
		["shape"] = "leviathan",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#13296A",
		["accent"] = "#3BE0FF",
		["belly"] = "#2F5FB8",
		["eye"] = "#7FFFF0",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#3BE0FF",
		["spirit"] = "#C59BFF",
		["aura"] = "abyss",
		["gear"] = nil,
		["gear"] = {
			"horns",
			"frills",
			"glowdots",
			"pearl"
		}
	}
}
local v58 = {
	["id"] = "astro_pup",
	["name"] = "Astro Pup",
	["rarity"] = "Common",
	["mult"] = 13.5,
	["look"] = nil,
	["look"] = {
		["fly"] = true,
		["body"] = "#B9A8FF",
		["accent"] = "#FFFFFF",
		["belly"] = "#FFFFFF",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "thin",
		["cloth"] = "#5AD8FF",
		["spirit"] = "#7FE9FF",
		["gear"] = nil,
		["gear"] = {
			"socks",
			"floppy",
			"jetpack",
			"helmet"
		}
	}
}
local v59 = {
	["id"] = "nebula_kitten",
	["name"] = "Nebula Kitten",
	["rarity"] = "Rare",
	["mult"] = 16.7,
	["look"] = nil,
	["look"] = {
		["body"] = "#8048E8",
		["accent"] = "#FF8AD8",
		["belly"] = "#F6EAFF",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#7FF0FF",
		["glow"] = "#7FF0FF",
		["cloth"] = "#FF5AB8",
		["gear"] = nil,
		["gear"] = {
			"nebula",
			"whiskers",
			"collar",
			"starcharm"
		}
	}
}
local v60 = {
	["id"] = "comet_fox",
	["name"] = "Comet Fox",
	["rarity"] = "Epic",
	["mult"] = 21,
	["look"] = nil,
	["look"] = {
		["body"] = "#4FA8FF",
		["accent"] = "#FFFFFF",
		["belly"] = "#FFFFFF",
		["limbs"] = "#2C5FD0",
		["ears"] = "arctic",
		["tails"] = 0,
		["glow"] = "#38D6FF",
		["gear"] = nil,
		["gear"] = {
			"socks",
			"ruff",
			"cometmark",
			"comettail"
		}
	}
}
local v61 = {
	["id"] = "cosmo_owl",
	["name"] = "Cosmo Owl",
	["rarity"] = "Legendary",
	["mult"] = 27,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#3A2E9A",
		["accent"] = "#FFE14B",
		["belly"] = "#5B48D0",
		["eye"] = "#FFE14B",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#A07BFF",
		["spirit"] = "#FF7AC8",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#3A2E9A", "#5B48D0", "#A07BFF" },
		["gear"] = {
			"tufts",
			"facedisc",
			"constellation",
			"planet"
		}
	}
}
local v62 = {
	["id"] = "starlight_pegasus",
	["name"] = "Starlight Pegasus",
	["rarity"] = "Mythic",
	["mult"] = 37.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "horse",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#FAF7FF",
		["accent"] = "#C9B8FF",
		["belly"] = "#EDE5FF",
		["eye"] = "#5AC8FF",
		["ears"] = "dog",
		["tails"] = 0,
		["glow"] = "#FF5AD8",
		["tip"] = "#4FDDFF",
		["spirit"] = "#9B6BFF",
		["beak"] = "#FFD24A",
		["wings"] = nil,
		["aura"] = "cosmic",
		["gear"] = nil,
		["wings"] = { "#9B6BFF", "#4FDDFF", "#FF5AD8" },
		["gear"] = { "nebulamane", "startail", "startiara" }
	}
}
local v63 = {
	["id"] = "orbit_slime",
	["name"] = "Orbit Slime",
	["rarity"] = "Common",
	["mult"] = 18.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "slime",
		["body"] = "#7A4DFF",
		["accent"] = "#3FF0F0",
		["ears"] = "none",
		["tails"] = 0,
		["gear"] = nil,
		["gear"] = { "saturnring", "moon" }
	}
}
local v64 = {
	["id"] = "alien_pup",
	["name"] = "Alien Pup",
	["rarity"] = "Rare",
	["mult"] = 22.6,
	["look"] = nil,
	["look"] = {
		["body"] = "#8BEA62",
		["accent"] = "#A35CFF",
		["belly"] = "#E4FFD2",
		["limbs"] = "#5CC24A",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "curl",
		["glow"] = "#FF6AD5",
		["gear"] = nil,
		["gear"] = {
			"alienears",
			"antennae",
			"bigeyes",
			"alienspots"
		}
	}
}
local v65 = {
	["id"] = "void_wolf",
	["name"] = "Void Wolf",
	["rarity"] = "Epic",
	["mult"] = 28.4,
	["look"] = nil,
	["look"] = {
		["size"] = 1.05,
		["body"] = "#33266E",
		["accent"] = "#9B5CFF",
		["belly"] = "#4E3E96",
		["limbs"] = "#221A4C",
		["eye"] = "#62F2FF",
		["ears"] = "arctic",
		["tails"] = 1,
		["tail"] = "fluffy",
		["tip"] = "#62F2FF",
		["glow"] = "#6E44FF",
		["gear"] = nil,
		["gear"] = {
			"marks",
			"bite",
			"stardust",
			"voidwisps"
		}
	}
}
local v66 = {
	["id"] = "star_whale",
	["name"] = "Star Whale",
	["rarity"] = "Legendary",
	["mult"] = 36.5,
	["look"] = nil,
	["look"] = {
		["shape"] = "whale",
		["fly"] = true,
		["size"] = 1.2,
		["body"] = "#2B3CA6",
		["accent"] = "#FFE98A",
		["belly"] = "#6FD8FF",
		["limbs"] = "#4A63D8",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#5AE8FF",
		["spirit"] = "#FF8AD8",
		["gear"] = nil,
		["gear"] = { "constellation", "starspout" }
	}
}
__set_list(v2, 49, {v51, v52, v53, v54, v55, v56, v57, v58, v59, v60, v61, v62, v63, v64, v65, v66})
local v67 = {
	["id"] = "galaxy_dragon",
	["name"] = "Galaxy Dragon",
	["rarity"] = "Mythic",
	["mult"] = 51,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["size"] = 1.25,
		["body"] = "#4B2296",
		["accent"] = "#FF6AD5",
		["belly"] = "#6A4AD0",
		["eye"] = "#7FFFF4",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF6AD5",
		["tip"] = "#7FFFF4",
		["spirit"] = "#FFFFFF",
		["wings"] = nil,
		["aura"] = "cosmic",
		["gear"] = nil,
		["wings"] = { "#FF6AD5", "#9B5CFF", "#5AE8FF" },
		["gear"] = {
			"starhorns",
			"frills",
			"mane",
			"galaxy",
			"stardust",
			"orbitstars"
		}
	}
}
local v68 = {
	["id"] = "soul_kitten",
	["name"] = "Soul Kitten",
	["rarity"] = "Common",
	["mult"] = 30.7,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["body"] = "#25232E",
		["accent"] = "#F4F4F8",
		["belly"] = "#3E3B4A",
		["eye"] = "#FFC83A",
		["ears"] = "cat",
		["tails"] = 1,
		["tail"] = "thin",
		["tip"] = "#9FEFFF",
		["cloth"] = "#F4F4F8",
		["gear"] = nil,
		["gear"] = { "whiskers", "scarf" }
	}
}
local v69 = {
	["id"] = "hell_moth",
	["name"] = "Hell Moth",
	["rarity"] = "Rare",
	["mult"] = 34,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "butterfly",
		["fly"] = true,
		["body"] = "#1F1C26",
		["accent"] = "#FF3A4A",
		["belly"] = "#ECE6F4",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF3A4A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#17141D", "#FF3A4A" },
		["gear"] = {}
	}
}
local v70 = {
	["id"] = "zanpaku_fox",
	["name"] = "Zanpaku Fox",
	["rarity"] = "Epic",
	["mult"] = 38,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["body"] = "#FF8A26",
		["accent"] = "#FFFFFF",
		["belly"] = "#FFF3E2",
		["ears"] = "fox",
		["tails"] = 1,
		["tail"] = "fluffy",
		["glow"] = "#7FD8FF",
		["cloth"] = "#1A1A22",
		["gear"] = nil,
		["gear"] = {
			"shihakusho",
			"zangetsu",
			"spikytuft",
			"scowl"
		}
	}
}
local v71 = {
	["id"] = "sakura_spirit_w6",
	["name"] = "Sakura Spirit",
	["rarity"] = "Legendary",
	["mult"] = 49,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "spirit",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#FFD9EA",
		["accent"] = "#FFFFFF",
		["belly"] = "#FFF3F8",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF6FAE",
		["tip"] = "#FF9ACB",
		["cloth"] = "#FFFFFF",
		["gear"] = nil,
		["gear"] = { "kazahana", "sakura", "petalring" }
	}
}
local v72 = {
	["id"] = "ice_dragon",
	["name"] = "Ice Dragon",
	["rarity"] = "Mythic",
	["mult"] = 68,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "skydragon",
		["fly"] = true,
		["size"] = 1.2,
		["body"] = "#8ED6F6",
		["accent"] = "#FFFFFF",
		["belly"] = "#EFFBFF",
		["limbs"] = "#5FB8E8",
		["eye"] = "#29D8FF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#3FE6FF",
		["tip"] = "#E8FCFF",
		["wings"] = nil,
		["aura"] = "glacier",
		["gear"] = nil,
		["wings"] = { "#EFFBFF", "#BDEBFF", "#3FE6FF" },
		["gear"] = { "icehorns", "frostmane", "icecrescent" }
	}
}
local v73 = {
	["id"] = "petal_bunny",
	["name"] = "Petal Bunny",
	["rarity"] = "Common",
	["mult"] = 41,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["body"] = "#FFF6FA",
		["accent"] = "#FFA8CC",
		["belly"] = "#FFFFFF",
		["ears"] = "bunny",
		["tails"] = 1,
		["tail"] = "puff",
		["cloth"] = "#D8263A",
		["gear"] = nil,
		["gear"] = { "sakura", "cord" }
	}
}
local v74 = {
	["id"] = "kido_owl",
	["name"] = "Kido Owl",
	["rarity"] = "Rare",
	["mult"] = 46,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["body"] = "#7A5A3E",
		["accent"] = "#FFE7B0",
		["belly"] = "#E9D3AC",
		["eye"] = "#FFD23A",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FFD23A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#7A5A3E", "#5C4230", "#FFD23A" },
		["gear"] = {
			"tufts",
			"facedisc",
			"ofuda",
			"kidoseal"
		}
	}
}
local v75 = {
	["id"] = "bone_snake",
	["name"] = "Bone Snake",
	["rarity"] = "Epic",
	["mult"] = 51,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "serpent",
		["body"] = "#EFE7D6",
		["accent"] = "#D8263A",
		["belly"] = "#FFF7E8",
		["eye"] = "#FF3A2A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF5A3A",
		["gear"] = nil,
		["gear"] = {
			"boneplates",
			"redmane",
			"baboonskull",
			"fangs"
		}
	}
}
local v76 = {
	["id"] = "phoenix_kikou",
	["name"] = "Phoenix Kikou",
	["rarity"] = "Legendary",
	["mult"] = 66,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "firebird",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#FFE09A",
		["accent"] = "#FFD24A",
		["belly"] = "#FFF6DC",
		["eye"] = "#FF4A1A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF7A1A",
		["beak"] = "#FFB21F",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFE14B", "#FF8A1F", "#FF3A1A" },
		["gear"] = { "flamecrest", "kikoumask" }
	}
}
local v77 = {
	["id"] = "flame_dragon",
	["name"] = "Flame Dragon",
	["rarity"] = "Mythic",
	["mult"] = 92,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "firedragon",
		["fly"] = true,
		["size"] = 1.25,
		["body"] = "#D9361F",
		["accent"] = "#FFC23A",
		["belly"] = "#FFB347",
		["limbs"] = "#8E1E16",
		["eye"] = "#FFE14B",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF8A1F",
		["tip"] = "#FFE14B",
		["cloth"] = "#7B3FD0",
		["wings"] = nil,
		["aura"] = "blaze",
		["gear"] = nil,
		["wings"] = { "#FFE45A", "#FF9A1F", "#FF3A1A" },
		["gear"] = { "elderhorns", "beard" }
	}
}
local v78 = {
	["id"] = "hollow_pup",
	["name"] = "Hollow Pup",
	["rarity"] = "Common",
	["mult"] = 55,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "hound",
		["body"] = "#2A2631",
		["accent"] = "#D8263A",
		["belly"] = "#F4EEDC",
		["ears"] = "none",
		["tails"] = 1,
		["tail"] = "thin",
		["gear"] = nil,
		["gear"] = { "floppy", "maskstripes" }
	}
}
local v79 = {
	["id"] = "bone_bat",
	["name"] = "Bone Bat",
	["rarity"] = "Rare",
	["mult"] = 61,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "bonebat",
		["fly"] = true,
		["body"] = "#2A2631",
		["accent"] = "#D8263A",
		["eye"] = "#FF3A3A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF3A3A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#1E1B24", "#F4EEDC", "#FF3A3A" },
		["gear"] = { "maskbrows" }
	}
}
local v80 = {
	["id"] = "sand_scorpion",
	["name"] = "Sand Scorpion",
	["rarity"] = "Epic",
	["mult"] = 68,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "scorpion",
		["body"] = "#E9C27A",
		["limbs"] = "#B5823F",
		["accent"] = "#D8263A",
		["eye"] = "#FF3A3A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF3A3A",
		["gear"] = nil,
		["gear"] = { "maskchevron" }
	}
}
local v81 = {
	["id"] = "mask_panther",
	["name"] = "Mask Panther",
	["rarity"] = "Legendary",
	["mult"] = 88,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "panther",
		["size"] = 1.1,
		["body"] = "#232638",
		["accent"] = "#33F0D2",
		["belly"] = "#3A3F58",
		["eye"] = "#33F0D2",
		["ears"] = "cat",
		["tails"] = 0,
		["glow"] = "#33F0D2",
		["tip"] = "#33F0D2",
		["cloth"] = "#4FC3FF",
		["gear"] = nil,
		["gear"] = {
			"jawmask",
			"pantheramarks",
			"bluemane",
			"pawclaws"
		}
	}
}
local v82 = {
	["id"] = "menos_titan",
	["name"] = "Menos Titan",
	["rarity"] = "Mythic",
	["mult"] = 122,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "menos",
		["size"] = 1.25,
		["body"] = "#1C1A22",
		["accent"] = "#D8263A",
		["eye"] = "#FF2A3A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF2A3A",
		["aura"] = "menos",
		["gear"] = nil,
		["gear"] = {}
	}
}
__set_list(v2, 65, {v67, v68, v69, v70, v71, v72, v73, v74, v75, v76, v77, v78, v79, v80, v81, v82})
local v83 = {
	["id"] = "cero_slime",
	["name"] = "Cero Slime",
	["rarity"] = "Common",
	["mult"] = 73.4,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "slime",
		["body"] = "#E8344A",
		["accent"] = "#D8263A",
		["ears"] = "none",
		["tails"] = 0,
		["gear"] = nil,
		["gear"] = { "maskband" }
	}
}
local v84 = {
	["id"] = "quartz_lizard",
	["name"] = "Quartz Lizard",
	["rarity"] = "Rare",
	["mult"] = 82,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "lizard",
		["body"] = "#5A6788",
		["limbs"] = "#4A5674",
		["accent"] = "#9FE8FF",
		["belly"] = "#C9D4EA",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#7FE6FF",
		["tip"] = "#7FE6FF",
		["gear"] = nil,
		["gear"] = { "quartz" }
	}
}
local v85 = {
	["id"] = "arrancar_wolf",
	["name"] = "Arrancar Wolf",
	["rarity"] = "Epic",
	["mult"] = 91,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["body"] = "#8F98A8",
		["accent"] = "#F2F4F8",
		["belly"] = "#E8ECF2",
		["limbs"] = "#7D8696",
		["eye"] = "#8FD3FF",
		["ears"] = "arctic",
		["tails"] = 1,
		["tail"] = "fluffy",
		["glow"] = "#8FD3FF",
		["tip"] = "#8FD3FF",
		["cloth"] = "#F7F7FA",
		["spirit"] = "#8FD3FF",
		["gear"] = nil,
		["gear"] = { "arrancarcoat", "wolfskull", "foxfire" }
	}
}
local v86 = {
	["id"] = "bat_serpent",
	["name"] = "Bat Serpent",
	["rarity"] = "Legendary",
	["mult"] = 118,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "batserpent",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#EEF0F4",
		["accent"] = "#2BFF9A",
		["belly"] = "#FFFFFF",
		["limbs"] = "#1B1A22",
		["eye"] = "#2BFF9A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#2BFF9A",
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#17151D", "#2E2B36", "#2BFF9A" },
		["gear"] = { "batfringe", "ulquihelmet", "tearlines" }
	}
}
local v87 = {
	["id"] = "quincy_eagle",
	["name"] = "Quincy Eagle",
	["rarity"] = "Mythic",
	["mult"] = 165,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "eagle",
		["fly"] = true,
		["size"] = 1.2,
		["body"] = "#2F5FE0",
		["accent"] = "#F4F7FF",
		["belly"] = "#A9C8FF",
		["eye"] = "#6FD0FF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#6FD0FF",
		["cloth"] = "#F7F9FF",
		["beak"] = "#FFC83A",
		["wings"] = nil,
		["aura"] = "quincy",
		["gear"] = nil,
		["wings"] = {
			"#2F5FE0",
			"#2448B8",
			"#FFC83A",
			"#6FD0FF"
		},
		["gear"] = { "quincycross", "goldcrest" }
	}
}
local v88 = {
	["id"] = "lantern_imp",
	["name"] = "Lantern Imp",
	["rarity"] = "Common",
	["mult"] = 98.3,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "oni",
		["body"] = "#E8473B",
		["accent"] = "#FFB547",
		["belly"] = "#F58B7C",
		["limbs"] = "#D63A30",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FFB547",
		["gear"] = nil,
		["gear"] = { "onihorns", "tigerloin", "lantern" }
	}
}
local v89 = {
	["id"] = "thread_spider",
	["name"] = "Thread Spider",
	["rarity"] = "Rare",
	["mult"] = 109,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "spider",
		["body"] = "#F3EDF1",
		["limbs"] = "#E4DAE2",
		["belly"] = "#FFFFFF",
		["accent"] = "#E8193C",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF2A4A",
		["spirit"] = "#FF2A4A",
		["gear"] = nil,
		["gear"] = { "threadweb", "threadknots", "ruimarks" }
	}
}
local v90 = {
	["id"] = "needle_goldfish",
	["name"] = "Needle Goldfish",
	["rarity"] = "Epic",
	["mult"] = 121,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "goldfish",
		["fly"] = true,
		["body"] = "#FF6A2B",
		["belly"] = "#FFF1E6",
		["limbs"] = "#FFA36E",
		["accent"] = "#FF8FA3",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#3DE0FF",
		["gear"] = nil,
		["gear"] = { "needlefins" }
	}
}
local v91 = {
	["id"] = "ice_lotus_doll",
	["name"] = "Ice Lotus Doll",
	["rarity"] = "Legendary",
	["mult"] = 157,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "lotusdoll",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#DDF6FF",
		["belly"] = "#FFFAEC",
		["limbs"] = "#FF9FD8",
		["accent"] = "#9FF2FF",
		["cloth"] = "#BFE6FF",
		["eye"] = "#FF6FD8",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#7AF0FF",
		["gear"] = nil,
		["gear"] = { "icefans" }
	}
}
local v92 = {
	["id"] = "six_eye_oni",
	["name"] = "Six-Eye Oni",
	["rarity"] = "Mythic",
	["mult"] = 218,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "oni",
		["size"] = 1.2,
		["body"] = "#EAD8CC",
		["belly"] = "#EAD8CC",
		["limbs"] = "#1C1820",
		["accent"] = "#A0122E",
		["eye"] = "#FFD23D",
		["cloth"] = "#5A2A7E",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#B05CFF",
		["aura"] = "moonbreath",
		["gear"] = nil,
		["gear"] = {
			"sixeyes",
			"kimono",
			"kokuhair",
			"moonmarks",
			"moonblade"
		}
	}
}
local v93 = {
	["id"] = "kasugai_crow",
	["name"] = "Kasugai Crow",
	["rarity"] = "Common",
	["mult"] = 131,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "crow",
		["fly"] = true,
		["body"] = "#25252F",
		["belly"] = "#3A3A4C",
		["limbs"] = "#2C2C38",
		["accent"] = "#8A90A6",
		["beak"] = "#5A5B66",
		["cloth"] = "#1F8A55",
		["ears"] = "none",
		["tails"] = 0,
		["gear"] = nil,
		["gear"] = { "checkbandana", "letter" }
	}
}
local v94 = {
	["id"] = "chuntaro_sparrow",
	["name"] = "Chuntaro Sparrow",
	["rarity"] = "Rare",
	["mult"] = 146,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "sparrow",
		["fly"] = true,
		["body"] = "#9A6438",
		["belly"] = "#F1E8DA",
		["limbs"] = "#5E3A22",
		["accent"] = "#1E1A1C",
		["beak"] = "#3A3236",
		["ears"] = "none",
		["tails"] = 0,
		["gear"] = nil,
		["gear"] = {}
	}
}
local v95 = {
	["id"] = "boar_piglet",
	["name"] = "Boar Piglet",
	["rarity"] = "Epic",
	["mult"] = 162,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "piglet",
		["body"] = "#FFB3C1",
		["belly"] = "#FFD3DC",
		["limbs"] = "#F59BAE",
		["accent"] = "#FF8FA6",
		["cloth"] = "#8C8F99",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#8FD3FF",
		["gear"] = nil,
		["gear"] = { "boarmask", "boarblades" }
	}
}
local v96 = {
	["id"] = "water_dragon",
	["name"] = "Water Dragon",
	["rarity"] = "Legendary",
	["mult"] = 211,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "waterdragon",
		["fly"] = true,
		["size"] = 1.15,
		["body"] = "#2E8BFF",
		["belly"] = "#BDEBFF",
		["limbs"] = "#7FD0FF",
		["accent"] = "#EAFBFF",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#7FE6FF",
		["gear"] = nil,
		["gear"] = {}
	}
}
local v97 = {
	["id"] = "sun_dragon",
	["name"] = "Sun Dragon",
	["rarity"] = "Mythic",
	["mult"] = 294,
	["update"] = 4,
	["look"] = nil,
	["look"] = {
		["shape"] = "sundragon",
		["fly"] = true,
		["size"] = 1.2,
		["body"] = "#FF6A1F",
		["belly"] = "#FFD46B",
		["limbs"] = "#FFB21F",
		["accent"] = "#FFE9A8",
		["eye"] = "#FFE07A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FFB21F",
		["tip"] = "#FFF4CC",
		["aura"] = "sunbreath",
		["gear"] = nil,
		["gear"] = { "hanafuda" }
	}
}
local v98 = {
	["id"] = "ten_tails",
	["name"] = "Ten Tails",
	["rarity"] = "Mythic",
	["mult"] = 250,
	["pass"] = "tenTails",
	["world"] = 2,
	["look"] = nil,
	["look"] = {
		["size"] = 1.4,
		["body"] = "#6E6A86",
		["accent"] = "#24202E",
		["belly"] = "#8C88A2",
		["eye"] = "#C8A0FF",
		["ears"] = "none",
		["tails"] = 10,
		["tail"] = "fluffy",
		["glow"] = "#B57BFF",
		["tip"] = "#B57BFF",
		["gear"] = nil,
		["gear"] = {
			"rinne",
			"horns",
			"mane",
			"fangs"
		}
	}
}
__set_list(v2, 81, {v83, v84, v85, v86, v87, v88, v89, v90, v91, v92, v93, v94, v95, v96, v97, v98})
local v99 = {
	["id"] = "royal_lion",
	["name"] = "Royal Lion",
	["rarity"] = "Mythic",
	["mult"] = 110,
	["pass"] = "vipPlus",
	["bundled"] = true,
	["look"] = nil,
	["look"] = {
		["size"] = 1.3,
		["fly"] = true,
		["body"] = "#FFC93C",
		["accent"] = "#FFF4CC",
		["belly"] = "#FFE7A0",
		["eye"] = "#6A1FD0",
		["ears"] = "round",
		["tails"] = 1,
		["tail"] = "thin",
		["glow"] = "#FFE36B",
		["tip"] = "#6A1FD0",
		["cloth"] = "#6A2BD9",
		["spirit"] = "#7A2FE0",
		["wings"] = nil,
		["aura"] = "royal",
		["gear"] = nil,
		["wings"] = { "#FFFFFF", "#FFE7A0", "#FFE36B" },
		["gear"] = {
			"lionmane",
			"crown",
			"cape",
			"gem"
		}
	}
}
local v100 = {
	["id"] = "magma_slime",
	["name"] = "Magma Slime",
	["rarity"] = "Common",
	["mult"] = 2.8,
	["look"] = nil,
	["look"] = {
		["shape"] = "slime",
		["body"] = "#FF7A22",
		["accent"] = "#FFE08A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FFE04A",
		["tip"] = "#FF4A14",
		["embers"] = true,
		["gear"] = nil,
		["gear"] = { "crust" }
	}
}
local v101 = {
	["id"] = "aegis_turtle",
	["name"] = "Aegis Turtle",
	["rarity"] = "Rare",
	["mult"] = 3.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "seaturtle",
		["fly"] = true,
		["body"] = "#C24A26",
		["accent"] = "#FFC23A",
		["belly"] = "#FFB46A",
		["ears"] = "none",
		["tails"] = 0,
		["glow"] = "#FF7A1A",
		["cloth"] = "#231C20",
		["spirit"] = "#FF8A1A",
		["embers"] = true,
		["gear"] = nil,
		["gear"] = { "shellcracks", "aegiseye" }
	}
}
local v102 = {
	["id"] = "ember_knight",
	["name"] = "Ember Knight",
	["rarity"] = "Epic",
	["mult"] = 3.6,
	["look"] = nil,
	["look"] = {
		["body"] = "#352C30",
		["accent"] = "#FFC23A",
		["belly"] = "#FFC23A",
		["eye"] = "#FFB020",
		["ears"] = "dog",
		["tails"] = 1,
		["tail"] = "curl",
		["tip"] = "#FF7A1A",
		["glow"] = "#FF7A1A",
		["spirit"] = "#FF8A1A",
		["embers"] = true,
		["gear"] = nil,
		["gear"] = {
			"crest",
			"pauldrons",
			"aegis",
			"lava"
		}
	}
}
local v103 = {
	["id"] = "aegis_phoenix",
	["name"] = "Aegis Phoenix",
	["rarity"] = "Legendary",
	["mult"] = 4.2,
	["look"] = nil,
	["look"] = {
		["shape"] = "bird",
		["fly"] = true,
		["size"] = 1.1,
		["body"] = "#2A2226",
		["accent"] = "#FFC23A",
		["belly"] = "#FFB04A",
		["beak"] = "#FFC23A",
		["eye"] = "#FFB020",
		["ears"] = "none",
		["tails"] = 3,
		["glow"] = "#FF7A1A",
		["spirit"] = "#FF8A1A",
		["embers"] = true,
		["wings"] = nil,
		["gear"] = nil,
		["wings"] = { "#FFC23A", "#FF7A1A", "#2A2226" },
		["gear"] = { "crest", "plumes", "aegiseye" }
	}
}
local v104 = {
	["id"] = "infernal_guardian",
	["name"] = "Infernal Guardian",
	["rarity"] = "Mythic",
	["mult"] = 5,
	["look"] = nil,
	["look"] = {
		["shape"] = "dragon",
		["fly"] = true,
		["size"] = 1.2,
		["membrane"] = true,
		["body"] = "#262024",
		["accent"] = "#FFC23A",
		["belly"] = "#FFC23A",
		["eye"] = "#FFB020",
		["ears"] = "none",
		["tails"] = 1,
		["glow"] = "#FF7A1A",
		["spirit"] = "#FF8A1A",
		["embers"] = true,
		["wings"] = nil,
		["aura"] = "aegis",
		["gear"] = nil,
		["wings"] = { "#3A1E1A", "#FFC23A", "#FF7A1A" },
		["gear"] = {
			"goldhorns",
			"aegiseye",
			"pauldrons",
			"lava",
			"fangs"
		}
	}
}
local v105 = {
	["id"] = "shadow_kyubi",
	["name"] = "Shadow Kyubi",
	["rarity"] = "Mythic",
	["mult"] = 15,
	["drop"] = true,
	["look"] = nil,
	["look"] = {
		["size"] = 1.3,
		["body"] = "#26232E",
		["accent"] = "#A8102A",
		["belly"] = "#3A3546",
		["eye"] = "#FF1A2A",
		["ears"] = "long",
		["tails"] = 9,
		["tail"] = "fluffy",
		["glow"] = "#A62BFF",
		["tip"] = "#FF1A3A",
		["aura"] = "shadow",
		["gear"] = nil,
		["gear"] = {
			"eyeline",
			"marks",
			"fangs",
			"mane"
		}
	}
}
__set_list(v2, 97, {v99, v100, v101, v102, v103, v104, v105})
v_u_1.list = v2
v_u_1.eggs = {
	{
		["id"] = "normal",
		["name"] = "Normal Egg",
		["cost"] = 10,
		["color"] = "#F7F7F2",
		["color2"] = "#D9DDE8",
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "shiba",
				["weight"] = 45
			},
			{
				["pet"] = "kitty",
				["weight"] = 32
			},
			{
				["pet"] = "bunny",
				["weight"] = 16
			},
			{
				["pet"] = "panda",
				["weight"] = 6
			},
			{
				["pet"] = "gold_shiba",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "shinobi",
		["name"] = "Shinobi Egg",
		["cost"] = 400,
		["color"] = "#E5141E",
		["color2"] = "#1C1418",
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "toad",
				["weight"] = 45
			},
			{
				["pet"] = "crow",
				["weight"] = 32
			},
			{
				["pet"] = "serpent",
				["weight"] = 16
			},
			{
				["pet"] = "kitsune",
				["weight"] = 6
			},
			{
				["pet"] = "nine_tails",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "akatsuki",
		["name"] = "Akatsuki Egg",
		["cost"] = 0,
		["color"] = "#16141C",
		["color2"] = "#E5141E",
		["product"] = "eggAkatsuki",
		["tag"] = "SUPER OP",
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "akatsuki_crow",
				["weight"] = 40
			},
			{
				["pet"] = "red_cloud_fox",
				["weight"] = 30
			},
			{
				["pet"] = "samehada",
				["weight"] = 18
			},
			{
				["pet"] = "puppet_scorpion",
				["weight"] = 10
			},
			{
				["pet"] = "akatsuki_dragon",
				["weight"] = 2
			}
		}
	},
	{
		["id"] = "divine",
		["name"] = "Divine Egg",
		["cost"] = 0,
		["color"] = "#FFFFFF",
		["color2"] = "#FFD966",
		["product"] = "eggDivine",
		["tag"] = "ULTRA OP",
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "angel_bunny",
				["weight"] = 40
			},
			{
				["pet"] = "holy_owl",
				["weight"] = 30
			},
			{
				["pet"] = "seraph_cat",
				["weight"] = 18
			},
			{
				["pet"] = "golden_phoenix",
				["weight"] = 10
			},
			{
				["pet"] = "divine_dragon",
				["weight"] = 2
			}
		}
	},
	{
		["id"] = "lotus",
		["name"] = "Lotus Egg",
		["cost"] = 790000000,
		["color"] = "#FF8FC4",
		["color2"] = "#FFF0F6",
		["world"] = 2,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "lotus_frog",
				["weight"] = 45
			},
			{
				["pet"] = "koi",
				["weight"] = 32
			},
			{
				["pet"] = "lotus_turtle",
				["weight"] = 16
			},
			{
				["pet"] = "sacred_crane",
				["weight"] = 6
			},
			{
				["pet"] = "lotus_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "celestial",
		["name"] = "Celestial Egg",
		["cost"] = 1800000000000,
		["color"] = "#7FD3FF",
		["color2"] = "#FFE98A",
		["world"] = 2,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "moon_bunny",
				["weight"] = 45
			},
			{
				["pet"] = "star_owl",
				["weight"] = 32
			},
			{
				["pet"] = "sky_whale",
				["weight"] = 16
			},
			{
				["pet"] = "star_pegasus",
				["weight"] = 6
			},
			{
				["pet"] = "astral_kirin",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "bloodmoon",
		["name"] = "Blood Moon Egg",
		["cost"] = 3.9e17,
		["color"] = "#E3122E",
		["color2"] = "#2A0A10",
		["world"] = 3,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "moon_bat",
				["weight"] = 45
			},
			{
				["pet"] = "crimson_fox",
				["weight"] = 32
			},
			{
				["pet"] = "blood_raven",
				["weight"] = 16
			},
			{
				["pet"] = "vampire_cat",
				["weight"] = 6
			},
			{
				["pet"] = "blood_moon_wolf",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "demon",
		["name"] = "Demon Egg",
		["cost"] = 8.9e20,
		["color"] = "#FF5A1E",
		["color2"] = "#1A0408",
		["world"] = 3,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "demon_imp",
				["weight"] = 45
			},
			{
				["pet"] = "oni_pup",
				["weight"] = 32
			},
			{
				["pet"] = "hell_spider",
				["weight"] = 16
			},
			{
				["pet"] = "demon_lion",
				["weight"] = 6
			},
			{
				["pet"] = "demon_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "frost",
		["name"] = "Frost Egg",
		["cost"] = 1.95e26,
		["color"] = "#BFE6FF",
		["color2"] = "#FFFFFF",
		["world"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "snow_fox",
				["weight"] = 45
			},
			{
				["pet"] = "frost_penguin",
				["weight"] = 32
			},
			{
				["pet"] = "ice_owl",
				["weight"] = 16
			},
			{
				["pet"] = "frost_tiger",
				["weight"] = 6
			},
			{
				["pet"] = "ice_phoenix",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "abyss",
		["name"] = "Abyss Egg",
		["cost"] = 4.4e29,
		["color"] = "#1E3A8A",
		["color2"] = "#3BE0FF",
		["world"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "glow_fish",
				["weight"] = 45
			},
			{
				["pet"] = "deep_jelly",
				["weight"] = 32
			},
			{
				["pet"] = "abyss_turtle",
				["weight"] = 16
			},
			{
				["pet"] = "kraken",
				["weight"] = 6
			},
			{
				["pet"] = "abyss_serpent",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "nebula",
		["name"] = "Nebula Egg",
		["cost"] = 9.75e34,
		["color"] = "#B06BFF",
		["color2"] = "#5AD8FF",
		["world"] = 5,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "astro_pup",
				["weight"] = 45
			},
			{
				["pet"] = "nebula_kitten",
				["weight"] = 32
			},
			{
				["pet"] = "comet_fox",
				["weight"] = 16
			},
			{
				["pet"] = "cosmo_owl",
				["weight"] = 6
			},
			{
				["pet"] = "starlight_pegasus",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "void",
		["name"] = "Void Egg",
		["cost"] = 2.2e38,
		["color"] = "#14101E",
		["color2"] = "#9B4DFF",
		["world"] = 5,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "orbit_slime",
				["weight"] = 45
			},
			{
				["pet"] = "alien_pup",
				["weight"] = 32
			},
			{
				["pet"] = "void_wolf",
				["weight"] = 16
			},
			{
				["pet"] = "star_whale",
				["weight"] = 6
			},
			{
				["pet"] = "galaxy_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "shinigami",
		["name"] = "Shinigami Egg",
		["cost"] = 4.875e43,
		["color"] = "#16161C",
		["color2"] = "#F2F2F2",
		["world"] = 6,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "soul_kitten",
				["weight"] = 45
			},
			{
				["pet"] = "hell_moth",
				["weight"] = 32
			},
			{
				["pet"] = "zanpaku_fox",
				["weight"] = 16
			},
			{
				["pet"] = "sakura_spirit_w6",
				["weight"] = 6
			},
			{
				["pet"] = "ice_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "sakura_w6",
		["name"] = "Sakura Egg",
		["cost"] = 1.1e47,
		["color"] = "#FFF4F8",
		["color2"] = "#FF8FBF",
		["world"] = 6,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "petal_bunny",
				["weight"] = 45
			},
			{
				["pet"] = "kido_owl",
				["weight"] = 32
			},
			{
				["pet"] = "bone_snake",
				["weight"] = 16
			},
			{
				["pet"] = "phoenix_kikou",
				["weight"] = 6
			},
			{
				["pet"] = "flame_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "hollow",
		["name"] = "Hollow Egg",
		["cost"] = 2.4375e52,
		["color"] = "#F2EEE4",
		["color2"] = "#C8242E",
		["world"] = 7,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "hollow_pup",
				["weight"] = 45
			},
			{
				["pet"] = "bone_bat",
				["weight"] = 32
			},
			{
				["pet"] = "sand_scorpion",
				["weight"] = 16
			},
			{
				["pet"] = "mask_panther",
				["weight"] = 6
			},
			{
				["pet"] = "menos_titan",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "espada",
		["name"] = "Espada Egg",
		["cost"] = 5.5e55,
		["color"] = "#121216",
		["color2"] = "#FFD24A",
		["world"] = 7,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "cero_slime",
				["weight"] = 45
			},
			{
				["pet"] = "quartz_lizard",
				["weight"] = 32
			},
			{
				["pet"] = "arrancar_wolf",
				["weight"] = 16
			},
			{
				["pet"] = "bat_serpent",
				["weight"] = 6
			},
			{
				["pet"] = "quincy_eagle",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "demonmoon",
		["name"] = "Demon Moon Egg",
		["cost"] = 1.21875e61,
		["color"] = "#5A0A18",
		["color2"] = "#FFD23D",
		["world"] = 8,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "lantern_imp",
				["weight"] = 45
			},
			{
				["pet"] = "thread_spider",
				["weight"] = 32
			},
			{
				["pet"] = "needle_goldfish",
				["weight"] = 16
			},
			{
				["pet"] = "ice_lotus_doll",
				["weight"] = 6
			},
			{
				["pet"] = "six_eye_oni",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "slayer",
		["name"] = "Slayer Egg",
		["cost"] = 2.75e64,
		["color"] = "#121216",
		["color2"] = "#FFC83A",
		["world"] = 8,
		["update"] = 4,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "kasugai_crow",
				["weight"] = 45
			},
			{
				["pet"] = "chuntaro_sparrow",
				["weight"] = 32
			},
			{
				["pet"] = "boar_piglet",
				["weight"] = 16
			},
			{
				["pet"] = "water_dragon",
				["weight"] = 6
			},
			{
				["pet"] = "sun_dragon",
				["weight"] = 1
			}
		}
	},
	{
		["id"] = "infernal_aegis",
		["name"] = "Infernal Aegis Egg",
		["cost"] = 0,
		["color"] = "#1E1A1C",
		["color2"] = "#FFC23A",
		["prizeOnly"] = true,
		["pool"] = nil,
		["pool"] = {
			{
				["pet"] = "magma_slime",
				["weight"] = 35
			},
			{
				["pet"] = "aegis_turtle",
				["weight"] = 30
			},
			{
				["pet"] = "ember_knight",
				["weight"] = 20
			},
			{
				["pet"] = "aegis_phoenix",
				["weight"] = 12
			},
			{
				["pet"] = "infernal_guardian",
				["weight"] = 3
			}
		}
	}
}
v_u_1.byId = {}
for _, v106 in v_u_1.list do
	v_u_1.byId[v106.id] = v106
end
for v107, v108 in {
	["lotus_frog"] = 3,
	["koi"] = 3.4,
	["moon_bunny"] = 4.1,
	["star_owl"] = 4.5,
	["moon_bat"] = 5.4,
	["crimson_fox"] = 5.9,
	["demon_imp"] = 7,
	["oni_pup"] = 7.8,
	["snow_fox"] = 9.5,
	["frost_penguin"] = 10.5,
	["glow_fish"] = 12.5,
	["deep_jelly"] = 14,
	["astro_pup"] = 16.8,
	["nebula_kitten"] = 18.8,
	["orbit_slime"] = 22.7,
	["alien_pup"] = 25.4
} do
	local v109 = v_u_1.byId[v107]
	if not v109 or v109.mult >= v108 then
		continue
	end
	v109.mult = v108
end
v_u_1.eggById = {}
for _, v110 in v_u_1.eggs do
	v_u_1.eggById[v110.id] = v110
end
v_u_1.STANDS = {
	{
		"normal",
		"shinobi",
		"akatsuki",
		"divine"
	},
	{
		"lotus",
		"celestial",
		"akatsuki",
		"divine"
	},
	{
		"bloodmoon",
		"demon",
		"akatsuki",
		"divine"
	},
	{
		"frost",
		"abyss",
		"akatsuki",
		"divine"
	},
	{
		"nebula",
		"void",
		"akatsuki",
		"divine"
	},
	{
		"shinigami",
		"sakura_w6",
		"akatsuki",
		"divine"
	},
	{
		"hollow",
		"espada",
		"akatsuki",
		"divine"
	},
	{
		"demonmoon",
		"slayer",
		"akatsuki",
		"divine"
	}
}
v_u_1.ROBUX_GROWTH = {}
local function v115(p111) -- name: averagePet
	-- upvalues: (copy) v_u_1
	local v112 = 0
	local v113 = 0
	for _, v114 in p111.pool do
		v112 = v112 + v_u_1.byId[v114.pet].mult * v114.weight
		v113 = v113 + v114.weight
	end
	return v112 / v113
end
for v116, v117 in v_u_1.STANDS do
	v_u_1.ROBUX_GROWTH[v116] = v115(v_u_1.eggById[v117[2]]) / v115(v_u_1.eggById[v_u_1.STANDS[1][2]])
end
local function v128(p118, p119) -- name: grow
	-- upvalues: (copy) v_u_1
	local v120 = {}
	for v121, v122 in v_u_1.ROBUX_GROWTH do
		local v123 = p118.mult
		local v124 = p118.mult * v122 / v_u_1.ROBUX_GROWTH[p119]
		local v125
		if v124 >= 10 then
			local v126 = v124 + 0.5
			v125 = math.floor(v126)
		else
			local v127 = v124 * 10 + 0.5
			v125 = math.floor(v127) / 10
		end
		v120[v121] = math.max(v123, v125)
	end
	p118.mults = v120
end
for _, v129 in v_u_1.eggs do
	if not v129.product then
		continue
	end
	for _, v130 in v129.pool do
		v128(v_u_1.byId[v130.pet], 1)
	end
end
for _, v131 in v_u_1.list do
	if not v131.pass then
		continue
	end
	v128(v131, v131.world or 1)
end
v128(v_u_1.byId.celestial_dragon, 1)
for _, v132 in { "sunfire_phoenix", "storm_tiger", "shadow_pegasus" } do
	v128(v_u_1.byId[v132], 1)
end
for _, v133 in v_u_1.eggById.infernal_aegis.pool do
	v128(v_u_1.byId[v133.pet], 1)
end
local v134 = require(script.Parent.BossDrops).PET_TIMES_BEST_FREE
local v135 = v_u_1.byId.shadow_kyubi
local v136 = {}
for v137, v138 in v_u_1.STANDS do
	local v139 = 0
	for v140 = 1, 2 do
		for _, v141 in v_u_1.eggById[v138[v140]].pool do
			local v142 = v_u_1.byId[v141.pet].mult
			v139 = math.max(v139, v142)
		end
	end
	local v143 = v139 * v134
	local v144
	if v143 >= 10 then
		local v145 = v143 + 0.5
		v144 = math.floor(v145)
	else
		local v146 = v143 * 10 + 0.5
		v144 = math.floor(v146) / 10
	end
	v136[v137] = v144
end
v135.mults = v136
v135.mult = v136[1]
function v_u_1.multIn(p147, p148) -- name: multIn
	local v149 = p147.mults
	local v150
	if v149 then
		v150 = v149[p148 or 1]
		if not v150 then
			return v149[#v149]
		end
	else
		v150 = p147.mult
	end
	return v150
end
function v_u_1.eggsFor(p151) -- name: eggsFor
	-- upvalues: (copy) v_u_1
	local v152 = {}
	for _, v153 in v_u_1.STANDS[p151 or 1] or v_u_1.STANDS[1] do
		local v154 = v_u_1.eggById[v153]
		table.insert(v152, v154)
	end
	return v152
end
v_u_1.PODIUMS = {
	[3] = { "kurama", "ten_tails" },
	[4] = { "kurama", "ten_tails" },
	[5] = { "kurama", "ten_tails" },
	[6] = { "kurama", "ten_tails" },
	[7] = { "kurama", "ten_tails" },
	[8] = { "kurama", "ten_tails" }
}
function v_u_1.showcasesFor(p155) -- name: showcasesFor
	-- upvalues: (copy) v_u_1
	local v156 = v_u_1.PODIUMS[p155 or 1]
	if v156 then
		local v157 = {}
		for _, v158 in v156 do
			local v159 = v_u_1.byId[v158]
			table.insert(v157, v159)
		end
		return v157
	else
		local v160 = {}
		for _, v161 in v_u_1.list do
			if not v161.pass or (v161.bundled or (v161.world or 1) ~= (p155 or 1)) then
				continue
			end
			table.insert(v160, v161)
		end
		return v160
	end
end
function v_u_1.showcaseFor(p162) -- name: showcaseFor
	-- upvalues: (copy) v_u_1
	return v_u_1.showcasesFor(p162)[1]
end
return v_u_1