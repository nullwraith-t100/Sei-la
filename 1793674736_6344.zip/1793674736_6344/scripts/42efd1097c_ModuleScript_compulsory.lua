local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(255, 128, 36)
local v_u_9 = Color3.fromRGB(86, 18, 10)
local v_u_10 = Color3.fromRGB(12, 10, 10)
local v_u_11 = Enum.Material.SmoothPlastic
local function v_u_18(p12, p13, p14, p15, p16) -- name: nerve
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	local v17 = Instance.new("Beam")
	v17.Attachment0 = p12
	v17.Attachment1 = p13
	v17.Texture = v_u_6.CompulsoryNerve
	v17.TextureMode = Enum.TextureMode.Wrap
	v17.TextureLength = 2
	v17.TextureSpeed = p16
	v17.Color = ColorSequence.new(v_u_7)
	v17.LightEmission = 0.2
	v17.LightInfluence = 0
	v17.FaceCamera = true
	v17.Segments = 12
	v17.Width0 = p14
	v17.Width1 = p15
	v17.Parent = p12
	return v17
end
return function(p_u_19)
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_1, (copy) v_u_7, (copy) v_u_9, (copy) v_u_2, (copy) v_u_11, (copy) v_u_10, (copy) v_u_18, (copy) v_u_5
	return {
		["w7_compulsory"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_4, (ref) v_u_3, (copy) p_u_19, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_9, (ref) v_u_2, (ref) v_u_11, (ref) v_u_10, (ref) v_u_18, (ref) v_u_5
			local v_u_22 = v_u_4.color(p21.color)
			local v23 = p_u_20.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v_u_25 = Instance.new("Attachment")
			v_u_25.Parent = v_u_3.Terrain
			p_u_19.own(p_u_20, v_u_25)
			local v_u_26 = Instance.new("ParticleEmitter")
			v_u_26.Enabled = false
			v_u_26.Texture = v_u_6.CompulsorySpark
			v_u_26.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v_u_26.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_26.Color = ColorSequence.new(v_u_22, v_u_8)
			v_u_26.LightEmission = 0.5
			v_u_26.LightInfluence = 0
			v_u_26.Lifetime = NumberRange.new(0.25, 0.35)
			v_u_26.Size = NumberSequence.new(v_u_24 * 0.7 * p_u_20.fx, v_u_24 * 1 * p_u_20.fx)
			v_u_26.Rotation = NumberRange.new(0, 360)
			v_u_26.Speed = NumberRange.new(0)
			v_u_26.Parent = v_u_25
			local v27 = p_u_20.stops
			local function v28()
				-- upvalues: (ref) v_u_1, (copy) v_u_25
				v_u_1:AddItem(v_u_25, 0.5)
			end
			table.insert(v27, v28)
			local v29 = p_u_19.bar(Vector3.new(0.2, 0.2, 0.2), v_u_7, 1)
			p_u_19.add(p_u_20, v29, function(p30)
				-- upvalues: (ref) p_u_19, (copy) p_u_20
				return CFrame.new(p_u_19.feetAt(p_u_20, p30, 0.12))
			end)
			local v_u_31 = Instance.new("ParticleEmitter")
			v_u_31.Texture = v_u_6.CompulsoryWeb
			v_u_31.Color = ColorSequence.new(v_u_22)
			v_u_31.LightEmission = 0.2
			v_u_31.LightInfluence = 0
			v_u_31.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
			v_u_31.EmissionDirection = Enum.NormalId.Top
			v_u_31.SpreadAngle = Vector2.zero
			v_u_31.Speed = NumberRange.new(0.01)
			v_u_31.LockedToPart = true
			v_u_31.Lifetime = NumberRange.new(3)
			v_u_31.Size = NumberSequence.new(v_u_24 * 2.1 * p_u_20.fx)
			v_u_31.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.25, 0.15),
				NumberSequenceKeypoint.new(0.75, 0.15),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_31.Rotation = NumberRange.new(0, 360)
			v_u_31.RotSpeed = NumberRange.new(-12, 12)
			v_u_31.Rate = 0.67
			v_u_31.Parent = v29
			v_u_31:Emit(1)
			local v32 = p_u_20.stops
			table.insert(v32, function()
				-- upvalues: (copy) v_u_31
				v_u_31.Enabled = false
			end)
			local v_u_34 = p_u_19.throb(p_u_20, 5, 2, 1.4285714285714286, function(p33)
				-- upvalues: (copy) v_u_31, (ref) v_u_4, (ref) p_u_19, (copy) p_u_20, (ref) v_u_9, (ref) v_u_6, (copy) v_u_22
				v_u_31:Emit(1)
				v_u_4.ring(p_u_19.feetAt(p_u_20, p33, 0.15), v_u_9, 4.5 * p_u_20.fx, 0.45, v_u_6.Ring)
				v_u_4.ring(p_u_19.feetAt(p_u_20, p33, 0.15), v_u_22, 6 * p_u_20.fx, 0.55, v_u_6.Ring)
			end)
			local v_u_35 = Vector3.new(0, 0, -1)
			local v_u_36 = v_u_35
			local v_u_37 = 0
			local v48 = p_u_19.group(p_u_20, function(p38, p39)
				-- upvalues: (copy) v_u_24, (copy) p_u_20, (ref) p_u_19, (copy) v_u_34, (ref) v_u_36, (ref) v_u_37, (ref) v_u_35
				local v40 = CFrame.new
				local v41 = v_u_24 * 1.35
				local v42 = p_u_20.headY + v_u_24 * 0.95
				local v43 = p39 * 1.2
				local v44 = (p38 * v40(v41, v42 + math.sin(v43) * 0.15 * v_u_24, v_u_24 * 0.8)).Position
				local v45 = p_u_19.camPos() - v44
				if v_u_34() > 0.2 and v45.Magnitude > 0.001 then
					v_u_36 = v45.Unit
				elseif v_u_37 <= p39 then
					v_u_37 = p39 + 1.6 + math.random() * 1.6
					local v46 = (math.random() - 0.5) * 2.2
					local v47 = (math.random() - 0.5) * 0.7
					v_u_36 = (p38 * CFrame.Angles(0, v46, 0) * CFrame.Angles(v47, 0, 0)).LookVector
				end
				v_u_35 = v_u_35:Lerp(v_u_36, 0.35)
				v_u_35 = v_u_35.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v_u_35.Unit
				return CFrame.lookAt(v44, v44 + v_u_35)
			end)
			local v49 = v_u_2:FindFirstChild("EyePieces")
			if v49 then
				v49 = v49:FindFirstChild("w7_compulsory")
			end
			local v50, v51
			if v49 and v49:IsA("MeshPart") then
				v50 = v49:Clone()
				local v52 = v49.Size
				local v53 = v_u_24 * 3.1
				local v54 = v49.Size.X
				local v55 = v49.Size.Y
				local v56 = v49.Size.Z
				v50.Size = v52 * (v53 / math.max(v54, v55, v56, 0.01))
				v50.Anchored = true
				v50.CanCollide = false
				v50.CanQuery = false
				v50.CanTouch = false
				v50.CastShadow = false
				v50.Massless = true
				v50.Parent = v_u_4.folder()
				p_u_19.pin(p_u_20, v48, v50, CFrame.Angles(0, 2.5830872929516078, 0) * CFrame.new(0, -v50.Size.Y * 0.22, 0))
				v51 = -v50.Size.Y * 0.45
			else
				v50 = p_u_19.ball(v_u_24 * 1.2, Color3.fromRGB(240, 236, 226), 0, v_u_11)
				p_u_19.pin(p_u_20, v48, v50, CFrame.identity)
				p_u_19.pin(p_u_20, v48, p_u_19.ball(v_u_24 * 0.55, v_u_10, 0, v_u_11), CFrame.new(0, 0, v_u_24 * -0.42))
				v51 = v_u_24 * -0.5
			end
			p_u_19.fadeFromBehind(p_u_20, v50, 0.35)
			local v57 = p_u_19.bar(Vector3.new(0.2, 0.2, 0.2), v_u_7, 1)
			p_u_19.add(p_u_20, v57, function(p58)
				-- upvalues: (copy) v_u_24
				return p58 * CFrame.new(0, v_u_24 * 0.75, v_u_24 * 0.5)
			end)
			local v59 = Instance.new("Attachment")
			v59.Position = Vector3.new(0, v51, 0)
			v59.Parent = v50
			local v_u_60 = {}
			for _, v61 in { 0.25, 0.55 } do
				local v62 = Instance.new("Attachment")
				local v63 = v61 * v_u_24
				local v64 = v_u_24 * 0.1
				v62.Position = Vector3.new(v63, v64, 0)
				v62.Parent = v57
				local v65 = v_u_18(v62, v59, v_u_24 * 0.4, v_u_24 * 0.25, 1.2)
				v65.CurveSize0 = v_u_24 * 0.8
				table.insert(v_u_60, v65)
			end
			local v_u_66 = {}
			for v_u_67, v68 in {
				{ -1, 0.5 },
				{ -1, -0.1 },
				{ 1, 0.5 },
				{ 1, -0.1 }
			} do
				local v_u_69 = v68[1]
				local v_u_70 = v68[2]
				local v71 = Instance.new("Attachment")
				local v72 = v_u_69 * 0.35 * v_u_24
				local v73 = v_u_70 * v_u_24
				v71.Position = Vector3.new(v72, v73, 0)
				v71.Parent = v57
				local v74 = p_u_19.ball(v_u_24 * 0.32, v_u_22)
				local v75 = Instance.new("Attachment")
				v75.Parent = v74
				local v76 = {
					["tip"] = v74,
					["a"] = v75,
					["beam"] = v_u_18(v71, v75, v_u_24 * 0.5, v_u_24 * 0.18, -1.5),
					["side"] = v_u_69,
					["i"] = v_u_67
				}
				table.insert(v_u_66, v76)
				p_u_19.add(p_u_20, v74, function(p77, p78)
					-- upvalues: (copy) v_u_67, (copy) v_u_69, (copy) v_u_24, (copy) v_u_70, (copy) v_u_34, (ref) p_u_19, (copy) p_u_20
					local v79 = p78 * 1.7 + v_u_67 * 1.9
					local v80 = math.sin(v79)
					local v81 = CFrame.new
					local v82 = v_u_69 * (v80 * 0.35 + 1.7) * v_u_24
					local v83 = v_u_70 + 0.5
					local v84 = p78 * 1.3 + v_u_67
					local v85 = (v83 + math.sin(v84) * 0.55) * v_u_24
					local v86 = p78 * 1.1 + v_u_67
					local v87 = p77 * v81(v82, v85, (math.cos(v86) * 0.3 + 1.3) * v_u_24)
					local v88 = v_u_34()
					local v89
					if v88 <= 0 then
						v89 = 0
					else
						local v90 = 1 - v88
						local v91 = math.clamp(v90, 0, 1)
						local v92 = v91 * v91 * (3 - v91 * 2) * 3.141592653589793
						v89 = math.sin(v92)
					end
					if v89 <= 0 then
						return v87
					end
					local v93 = p77 * CFrame.Angles(0, (v_u_67 - 2.5) * 0.9 + 3.141592653589793, 0)
					local v94 = p_u_19.feetAt(p_u_20, p77, 0) + v93.LookVector * 2.6 * v_u_24
					return v87:Lerp(CFrame.new(v94), v89)
				end)
			end
			local v_u_95 = false
			local v96 = p_u_20.ticks
			local function v113(p97, p98)
				-- upvalues: (copy) v_u_34, (copy) v_u_66, (copy) v_u_24, (copy) v_u_60, (ref) v_u_95, (ref) v_u_5, (ref) p_u_19, (copy) v_u_25, (copy) v_u_26
				local v99 = v_u_34()
				local v100
				if v99 <= 0 then
					v100 = 0
				else
					local v101 = 1 - v99
					local v102 = math.clamp(v101, 0, 1)
					local v103 = v102 * v102 * (3 - v102 * 2) * 3.141592653589793
					v100 = math.sin(v103)
				end
				for _, v104 in v_u_66 do
					local v105 = v104.beam
					local v106 = p98 * 2.3 + v104.i
					v105.CurveSize0 = (math.sin(v106) * 0.8 + 1.2) * v_u_24 * (1 - v100)
					local v107 = v104.beam
					local v108 = p98 * 1.9 + v104.i * 2
					v107.CurveSize1 = math.sin(v108) * 0.9 * v_u_24 * (1 - v100)
				end
				for v109, v110 in v_u_60 do
					local v111 = p98 * 1.4 + v109
					v110.CurveSize1 = math.sin(v111) * 0.6 * v_u_24
				end
				if v100 > 0.9 and not v_u_95 then
					v_u_95 = true
					if v_u_5.level() >= 2 and (p97.Position - p_u_19.camPos()).Magnitude < 150 then
						for _, v112 in v_u_66 do
							v_u_25.WorldPosition = v112.tip.Position + Vector3.new(0, 0.3, 0) * v_u_24
							v_u_26:Emit(1)
						end
						return
					end
				elseif v100 < 0.5 then
					v_u_95 = false
				end
			end
			table.insert(v96, v113)
			p_u_19.particles(p_u_20, "AuraMode", v_u_22, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end