local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v3.Shared.Config.Textures)
return function(p_u_7)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_6, (copy) v_u_2, (copy) v_u_5
	local v_u_8 = p_u_7.rgb
	local v_u_9 = v_u_8(122, 16, 32)
	local v_u_10 = v_u_8(205, 28, 50)
	local v_u_11 = v_u_8(255, 72, 88)
	local v_u_12 = v_u_8(243, 230, 230)
	local v_u_13 = v_u_8(45, 4, 10)
	local v_u_14 = v_u_8(80, 6, 18)
	local function v_u_32(p15, p16, p17, p18, p19, p20, p21) -- name: newHelix
		-- upvalues: (ref) v_u_4, (ref) v_u_1, (copy) v_u_13
		local v22 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p15), p16[1], {
			["transparency"] = 1
		})
		v_u_1:AddItem(v22, p21)
		local v23 = {
			["holder"] = v22,
			["strands"] = {},
			["n"] = p17,
			["width"] = p18,
			["place"] = p20
		}
		for _, v24 in p16 do
			local v25 = {
				["atts"] = {},
				["beams"] = {}
			}
			for _ = 0, p17 do
				local v26 = Instance.new("Attachment")
				v26.Parent = v22
				local v27 = v25.atts
				table.insert(v27, v26)
			end
			for v28 = 1, p17 do
				local v29 = Instance.new("Beam")
				v29.Attachment0 = v25.atts[v28]
				v29.Attachment1 = v25.atts[v28 + 1]
				v29.Texture = p19
				v29.TextureMode = Enum.TextureMode.Wrap
				v29.TextureLength = 5
				v29.TextureSpeed = 4
				v29.LightEmission = v24 == v_u_13 and 0 or 0.6
				v29.LightInfluence = 0
				v29.Color = ColorSequence.new(v24)
				v29.FaceCamera = true
				v29.Segments = 8
				v29.Width0 = p18
				v29.Width1 = p18
				v29.Parent = v22
				local v30 = v25.beams
				table.insert(v30, v29)
			end
			local v31 = v23.strands
			table.insert(v31, v25)
		end
		return v23
	end
	local function v_u_56(p33, p34, p35, p36, p37) -- name: helixStep
		-- upvalues: (copy) p_u_7
		local v38 = p33.n
		local v39 = 0.25 / v38
		local v40 = NumberSequence.new((math.clamp(p36, 0, 1)))
		for v41, v42 in p33.strands do
			for v43, v44 in v42.atts do
				local v45 = (v43 - 1) / v38
				local v46 = p33.place(v41, v45, p34)
				local v47 = p33.place
				local v48 = v45 + v39
				local v49 = v47(v41, math.min(v48, 1), p34)
				local v50 = p33.place
				local v51 = v45 - v39
				local v52 = v50(v41, math.max(v51, 0), p34)
				v44.WorldCFrame = p_u_7.aimAt(v46, v49 - v52) * CFrame.Angles(0, 1.5707963267948966, 0)
			end
			for v53, v54 in v42.beams do
				local v55 = (v42.atts[v53 + 1].WorldPosition - v42.atts[v53].WorldPosition).Magnitude
				v54.CurveSize0 = v55 * 0.38
				v54.CurveSize1 = v55 * 0.38
				v54.Width0 = p33.width * p35 * (not p37 and 1 or p37((v53 - 1) / v38))
				v54.Width1 = p33.width * p35 * (not p37 and 1 or p37(v53 / v38))
				v54.Transparency = v40
			end
		end
	end
	local function v_u_77(p_u_57, p_u_58, p_u_59, p60, p61, p_u_62, p_u_63, p64) -- name: picture
		-- upvalues: (ref) v_u_4, (ref) v_u_1, (copy) p_u_7
		local v_u_65 = v_u_4.part(Vector3.new(p_u_58, 0.05, p_u_58), p_u_57, p61, {
			["transparency"] = 1
		})
		local v_u_66 = p64 or 0
		local v_u_67 = {}
		for _, v68 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v69 = Instance.new("Decal")
			v69.Face = v68
			v69.Texture = p60
			v69.Color3 = p61
			v69.Transparency = v_u_66
			v69.Parent = v_u_65
			table.insert(v_u_67, v69)
		end
		v_u_1:AddItem(v_u_65, p_u_62 + 0.1)
		local v_u_70 = math.random() * 6.28
		p_u_7.animate(p_u_62, 0, function(p71)
			-- upvalues: (copy) p_u_58, (copy) p_u_59, (copy) v_u_65, (copy) p_u_57, (copy) v_u_70, (copy) p_u_62, (copy) p_u_63, (copy) v_u_67, (copy) v_u_66
			local v72 = 1 - (1 - p71) ^ 2
			local v73 = p_u_58 + (p_u_59 - p_u_58) * v72
			v_u_65.Size = Vector3.new(v73, 0.05, v73)
			v_u_65.CFrame = p_u_57 * CFrame.Angles(0, v_u_70 + p71 * p_u_62 * p_u_63, 0)
			local v74 = (p71 - 0.35) / 0.65
			local v75 = math.clamp(v74, 0, 1)
			for _, v76 in v_u_67 do
				v76.Transparency = v_u_66 + (1 - v_u_66) * v75
			end
			if p71 >= 1 then
				v_u_65:Destroy()
			end
		end)
	end
	local function v_u_86(p78, p79, p80) -- name: pool
		-- upvalues: (copy) p_u_7, (copy) v_u_14, (ref) v_u_4
		local v_u_81 = p_u_7.plate(p_u_7.ground(p78, 0.07), 0.3, v_u_14, 0.2, Enum.Material.SmoothPlastic)
		local v82 = v_u_4.tween
		local v83 = {}
		local v84 = p79 * 2
		local v85 = p79 * 2
		v83.Size = Vector3.new(0.12, v84, v85)
		v82(v_u_81, 0.2, v83)
		task.delay(p80, function()
			-- upvalues: (ref) p_u_7, (copy) v_u_81
			p_u_7.fadeOut(v_u_81, 0.3)
		end)
	end
	local function v_u_111(p_u_87, p88, p89, p_u_90, p91, p_u_92) -- name: spiralSplash
		-- upvalues: (copy) v_u_12, (copy) v_u_11, (copy) v_u_10, (copy) p_u_7
		local v93 = math.random() * 3.141592653589793 * 2
		local v_u_94 = {}
		for v95 = 1, p88 do
			local v96
			if v95 % 3 == 0 then
				v96 = v_u_12
			elseif v95 % 3 == 1 then
				v96 = v_u_11
			else
				v96 = v_u_10
			end
			local v97 = {
				["p"] = p_u_7.ball(p_u_87, v96, p_u_92, 0),
				["a"] = v93 + v95 / p88 * 3.141592653589793 * 2,
				["d"] = p89 * (0.6 + math.random() * 0.4)
			}
			table.insert(v_u_94, v97)
		end
		p_u_7.animate(p91, 0, function(p98)
			-- upvalues: (copy) v_u_94, (copy) p_u_87, (copy) p_u_90, (copy) p_u_92
			local v99 = 1 - (1 - p98) ^ 2
			for _, v100 in v_u_94 do
				local v101 = v100.a + v99 * 2.6
				local v102 = v100.p
				local v103 = CFrame.new
				local v104 = p_u_87
				local v105 = math.cos(v101)
				local v106 = math.sin(v101)
				local v107 = v104 + Vector3.new(v105, 0, v106) * v100.d * v99
				local v108 = p_u_90 * 4 * p98 * (1 - p98)
				v102.CFrame = v103(v107 + Vector3.new(0, v108, 0))
				v100.p.Size = Vector3.new(1, 1, 1) * p_u_92 * (1 - 0.6 * p98)
				local v109 = v100.p
				local v110 = (p98 - 0.6) / 0.4
				v109.Transparency = math.max(0, v110)
				if p98 < 1 then
					continue
				end
				v100.p:Destroy()
			end
		end)
	end
	local function v_u_130(p112, p113) -- name: drillRig
		-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_9, (copy) v_u_11, (copy) v_u_12
		local v114 = p_u_7.newRig()
		for v115, v116 in {
			{ 0.6, -1.45 },
			{ 1, -0.9 },
			{ 1.4, -0.35 },
			{ 1.8, 0.2 }
		} do
			local v117 = v116[1]
			local v118 = v116[2]
			local v119 = v115 % 2 == 1
			local v120 = p_u_7.rigAdd
			local v121 = Vector3.new(0.62, v117, v117)
			local v122 = CFrame.new(0, 0, v118) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v123
			if v119 then
				v123 = v_u_10
			else
				v123 = v_u_9
			end
			local v124 = 0
			local v125
			if v119 then
				v125 = Enum.Material.Neon
			else
				v125 = Enum.Material.SmoothPlastic
			end
			v120(v114, v121, v122, v123, v124, v125, p113).Shape = Enum.PartType.Cylinder
		end
		p_u_7.rigAdd(v114, Vector3.new(0.5, 0.5, 0.5), CFrame.new(0, 0, -1.85), v_u_11, 0, nil, p113).Shape = Enum.PartType.Ball
		p_u_7.rigAdd(v114, Vector3.new(0.22, 2.2, 2.2), CFrame.new(0, 0, 0.6) * CFrame.Angles(0, 1.5707963267948966, 0), v_u_12, 0, Enum.Material.SmoothPlastic, p113).Shape = Enum.PartType.Cylinder
		for v126 = 0, p112 and 0 or 1 do
			for v127 = 0, 3 do
				local v128 = v127 * 0.55 + -1.45
				local v129 = (v128 + 1.45) / 1.65 * 0.6 + 0.3
				p_u_7.rigAdd(v114, Vector3.new(0.24, 0.3, 0.7), CFrame.Angles(0, 0, v126 * 3.141592653589793 + v127 * 1.1) * CFrame.new(v129, 0, v128) * CFrame.Angles(0.6, 0, 0), v_u_12, 0, Enum.Material.SmoothPlastic, p113)
			end
		end
		return v114
	end
	local function v146(p131, p132) -- name: drillShot
		-- upvalues: (copy) v_u_130, (ref) v_u_4, (copy) v_u_10, (ref) v_u_1, (copy) p_u_7, (copy) v_u_13, (copy) v_u_11, (copy) v_u_9
		local v_u_133 = p131.size
		local v_u_134 = v_u_130(p131.lite, 3)
		local v_u_135 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p132, v_u_10, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_135, 3)
		p_u_7.streak(v_u_135, v_u_10, v_u_13, 1.1 * v_u_133, 0.12)
		local v_u_136 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p132, v_u_10, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_136, 3)
		if not p131.lite then
			local v137 = Instance.new("Attachment")
			local v138 = 1.4 * v_u_133
			v137.Position = Vector3.new(0, v138, 0)
			v137.Parent = v_u_136
			local v139 = Instance.new("Attachment")
			local v140 = -1.4 * v_u_133
			v139.Position = Vector3.new(0, v140, 0)
			v139.Parent = v_u_136
			local v141 = Instance.new("Trail")
			v141.Attachment0 = v137
			v141.Attachment1 = v139
			v141.Color = ColorSequence.new(v_u_11, v_u_9)
			v141.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
			v141.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.25) })
			v141.Lifetime = 0.16
			v141.LightEmission = 0.4
			v141.LightInfluence = 0
			v141.FaceCamera = false
			v141.MinLength = 0.05
			v141.Parent = v_u_136
		end
		if p131.mine then
			p_u_7.light(v_u_135, v_u_10, 9 * v_u_133)
		end
		local v_u_142 = false
		return {
			["place"] = function(p143, p144) -- name: place
				-- upvalues: (copy) v_u_135, (copy) v_u_136, (copy) v_u_133, (ref) p_u_7, (copy) v_u_134
				v_u_135.CFrame = p143
				v_u_136.CFrame = p143 * CFrame.Angles(0, 0, p144 * 70) * CFrame.new(0, 0, 1.2 * v_u_133)
				p_u_7.rigPlace(v_u_134, p143 * CFrame.Angles(0, 0, p144 * 40), 1.35 * v_u_133)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_142, (copy) v_u_135, (ref) v_u_1, (copy) v_u_136, (ref) p_u_7, (copy) v_u_134
				if not v_u_142 then
					v_u_142 = true
					local v145 = v_u_135:FindFirstChildWhichIsA("PointLight")
					if v145 then
						v145:Destroy()
					end
					v_u_1:AddItem(v_u_135, 0.15)
					v_u_1:AddItem(v_u_136, 0.2)
					p_u_7.rigDestroy(v_u_134)
				end
			end
		}
	end
	local function v_u_170(p147, p_u_148, p149) -- name: geyser
		-- upvalues: (copy) p_u_7, (copy) v_u_32, (copy) v_u_11, (copy) v_u_12, (copy) v_u_10, (ref) v_u_6, (copy) v_u_56
		local v_u_150 = p_u_7.ground(p147, 0.2)
		local v_u_151 = 0
		local v152 = v_u_32
		local v153
		if p149 then
			v153 = { v_u_11 }
		else
			v153 = { v_u_11, v_u_12, v_u_10 }
		end
		local v_u_163 = v152(v_u_150, v153, p149 and 6 or 10, 1.3, v_u_6.Beam, function(p154, p155, p156)
			-- upvalues: (copy) v_u_150, (copy) p_u_148, (ref) v_u_151
			local v157 = p154 * 2.1 + p155 * 3.141592653589793 * 5 + p156
			local v158 = p155 * 2.6 + 1.2
			local v159 = v_u_150
			local v160 = math.cos(v157) * v158
			local v161 = p155 * p_u_148 * v_u_151
			local v162 = math.sin(v157) * v158
			return v159 + Vector3.new(v160, v161, v162)
		end, 1.2)
		local v_u_164 = os.clock()
		p_u_7.runNow(function()
			-- upvalues: (copy) v_u_164, (ref) v_u_151, (ref) v_u_56, (copy) v_u_163
			local v165 = os.clock() - v_u_164
			local v166 = v165 / 0.16
			v_u_151 = 1 - (1 - math.min(v166, 1)) ^ 2
			local v167 = (v165 - 0.25) / 0.4
			local v168 = math.clamp(v167, 0, 1)
			v_u_56(v_u_163, -v165 * 18, 1 - v168 * 0.5, v168, function(p169)
				return 1.2 - p169 * 0.7
			end)
			if v168 < 1 then
				return true
			end
			v_u_163.holder:Destroy()
			return false
		end)
		p_u_7.thin(p_u_7.pillar(v_u_150, p_u_148, 2.6, v_u_10, 0.35), 0.5, true)
		p_u_7.thin(p_u_7.pillar(v_u_150, p_u_148 * 0.8, 1, v_u_11, 0), 0.4, true)
	end
	local v_u_171 = 0
	local function v_u_174() -- name: kickFrame
		-- upvalues: (ref) v_u_171, (ref) v_u_2, (ref) v_u_4, (copy) v_u_8, (copy) p_u_7, (ref) v_u_1
		local v172 = os.clock()
		if v172 >= v_u_171 then
			v_u_171 = v172 + 0.5
			local v_u_173 = Instance.new("ColorCorrectionEffect")
			v_u_173.Name = "SpiralCannon"
			v_u_173.Parent = v_u_2
			v_u_4.tween(v_u_173, 0.04, {
				["Brightness"] = -0.12,
				["Contrast"] = 0.45,
				["Saturation"] = 0.25,
				["TintColor"] = nil,
				["TintColor"] = v_u_8(255, 205, 210)
			})
			task.delay(0.08, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_173, (ref) p_u_7
				v_u_4.tween(v_u_173, 0.32, {
					["Brightness"] = 0,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = nil,
					["TintColor"] = p_u_7.WHITE
				})
			end)
			v_u_1:AddItem(v_u_173, 0.5)
		end
	end
	local function v_u_180(p175, p176, p177) -- name: cannonEnd
		-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_77, (ref) v_u_6, (copy) v_u_12, (copy) v_u_11, (ref) v_u_4, (copy) v_u_111, (copy) v_u_86, (copy) v_u_13, (copy) v_u_170, (ref) v_u_5
		local v178 = p175.lite
		local v179 = p_u_7.ground(p176)
		p_u_7.burst("Explosion", p176, v_u_10, 2.2)
		p_u_7.burst("Shockwave", v179 + Vector3.new(0, 0.3, 0), v_u_10, 1.1)
		v_u_77(p_u_7.facing(p176, -p177), 6, 30, v_u_6.Swirl, v_u_10, 0.5, -8)
		v_u_77(p_u_7.facing(p176 - p177 * 0.3, -p177), 4, 20, v_u_6.Swirl, v_u_12, 0.4, 12, 0.2)
		p_u_7.pop(p176, v_u_11, 3, 16, 0.22, 0.3)
		v_u_4.ring(v179, v_u_10, 16, 0.5, v_u_6.Shockwave)
		v_u_111(p176, v178 and 6 or 12, 12, 7, 0.6, 0.8)
		v_u_86(p176, 5, 1.2)
		p_u_7.mark(p176, v_u_13, 8, 1.8, v_u_6.CrackLines, 0.05)
		if not v178 then
			v_u_170(p176, 14, false)
			p_u_7.chunks(p_u_7.ground(p176, 1), { p_u_7.EARTH[1], p_u_7.EARTH[2], v_u_13 }, 8, 36, 1, 0.9)
		end
		v_u_5.play("Explosion", {
			["at"] = v179,
			["volume"] = p175.mine and 0.9 or 0.5
		})
	end
	local v326 = {
		["crimson_spiral_a"] = {
			["cast"] = function(p181) -- name: cast
				-- upvalues: (ref) v_u_4, (copy) v_u_10, (copy) p_u_7, (copy) v_u_11, (copy) v_u_77, (ref) v_u_6
				local v182 = p181.size
				local v183 = p181.eye + p181.dir * 1.1
				v_u_4.flash(v183, v_u_10, 3.2 * v182, 0.12)
				p_u_7.pop(v183, v_u_11, 1.4 * v182, 0.3 * v182, 0.1)
				if not p181.lite then
					v_u_77(p_u_7.facing(v183, p181.dir), 1 * v182, 4 * v182, v_u_6.Swirl, v_u_11, 0.13, 25)
				end
			end,
			["shot"] = v146,
			["impact"] = function(p184, p185) -- name: impact
				-- upvalues: (copy) p_u_7, (copy) v_u_77, (ref) v_u_6, (copy) v_u_11, (copy) v_u_10, (ref) v_u_4, (copy) v_u_111
				local v186 = p184.size
				local v187 = p_u_7.flatUnit(p184.origin - p185)
				v_u_77(p_u_7.facing(p185 + v187 * 0.4, v187), 2 * v186, 10 * v186, v_u_6.Swirl, v_u_11, 0.25, 22)
				v_u_77(CFrame.new(p_u_7.ground(p185, 0.12)), 3 * v186, p184.ability.radius * 2 * v186, v_u_6.Swirl, v_u_10, 0.35, -8, 0)
				p_u_7.burst("Impact", p185, v_u_10, 1 * v186)
				v_u_4.flash(p185, v_u_10, 4.5 * v186, 0.15)
				v_u_111(p185, p184.lite and 4 or 7, 5 * v186, 2.5, 0.4, 0.45 * v186)
				p_u_7.hitSound(p185)
			end,
			["hit"] = function(p188, p189, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_77, (ref) v_u_6, (copy) v_u_11
				p_u_7.burst("Impact", p189, v_u_10, 0.6)
				if not p188.lite then
					v_u_77(CFrame.new(p189), 1, 3.5, v_u_6.Swirl, v_u_11, 0.18, 20)
				end
			end
		},
		["crimson_spiral_e"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p190) -- name: cast
				-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_111
				p_u_7.skillCast(p190, v_u_10)
				p_u_7.glint(p190.eye, v_u_11, 5, 0.2)
				if not p190.lite then
					v_u_111(p190.eye + p190.dir, 5, 2.5, 1, 0.3, 0.35)
				end
			end,
			["windup"] = function(p191, p192, p193) -- name: windup
				-- upvalues: (copy) v_u_77, (copy) p_u_7, (ref) v_u_6, (copy) v_u_11, (copy) v_u_10
				local v194 = p191.ability.radius
				v_u_77(CFrame.new(p_u_7.ground(p192, 0.2)), v194 * 2.6, v194 * 0.8, v_u_6.Ring, v_u_11, p193 + 0.1, 4)
				p_u_7.pop(p_u_7.ground(p192, 1), v_u_10, 1, 4, p193 + 0.1, 0.3)
			end,
			["zone"] = function(p195, p_u_196, p_u_197) -- name: zone
				-- upvalues: (copy) p_u_7, (copy) v_u_14, (ref) v_u_4, (copy) v_u_13, (copy) v_u_10, (copy) v_u_12, (copy) v_u_11, (copy) v_u_32, (ref) v_u_6, (copy) v_u_56, (copy) v_u_77
				local v_u_198 = p195.ability.radius
				local v_u_199 = p195.lite
				local v_u_200 = p_u_7.ground(p_u_196, 0.25)
				local v_u_201 = p_u_7.plate(p_u_7.ground(p_u_196, 0.07), 0.3, v_u_14, 0.25, Enum.Material.SmoothPlastic)
				local v202 = v_u_4.tween
				local v203 = {}
				local v204 = v_u_198 * 2.1
				local v205 = v_u_198 * 2.1
				v203.Size = Vector3.new(0.12, v204, v205)
				v202(v_u_201, 0.25, v203)
				local v_u_206 = p_u_7.plate(p_u_7.ground(p_u_196, 0.1), 0.3, v_u_13, 0, Enum.Material.SmoothPlastic)
				v_u_4.tween(v_u_206, 0.25, {
					["Size"] = Vector3.new(0.12, 3.6, 3.6)
				})
				local v207
				if v_u_199 then
					v207 = { v_u_10, v_u_12 }
				else
					v207 = { v_u_10, v_u_12, v_u_11 }
				end
				local v_u_208 = #v207
				local v_u_209 = 1
				local function v_u_222(p210, p211, p212) -- name: place
					-- upvalues: (copy) v_u_208, (copy) v_u_198, (copy) v_u_200, (ref) v_u_209
					local v213 = p210 / v_u_208 * 3.141592653589793 * 2 + p211 * 3.141592653589793 * 5 + p212
					local v214, v215
					if p211 < 0.5 then
						local v216 = p211 / 0.5
						v214 = v_u_198 * (1 - v216) + v216 * 1.4
						v215 = 0
					else
						local v217 = (p211 - 0.5) / 0.5
						v214 = 1.4 + (v_u_198 * 0.8 - 1.4) * v217 ^ 1.3
						v215 = v217 * 12
					end
					local v218 = v_u_200
					local v219 = math.cos(v213) * v214 * v_u_209
					local v220 = v215 * v_u_209
					local v221 = math.sin(v213) * v214 * v_u_209
					return v218 + Vector3.new(v219, v220, v221)
				end
				local v_u_223 = v_u_32(v_u_200, v207, v_u_199 and 10 or 16, 2.3, v_u_6.Beam, v_u_222, p_u_197 + 2)
				local function v_u_225(p224) -- name: taper
					if p224 < 0.5 then
						return 1.3 - p224
					else
						return (p224 - 0.5) * 0.9 + 0.8
					end
				end
				local v_u_226 = {}
				if not v_u_199 then
					for v227 = 1, 6 do
						local v228 = p_u_7.ball
						local v229
						if v227 % 2 == 0 then
							v229 = v_u_12
						else
							v229 = v_u_11
						end
						table.insert(v_u_226, v228(v_u_200, v229, 0.7, 0))
					end
				end
				local v_u_230 = os.clock()
				local v_u_231 = v_u_230
				local v_u_232 = 0
				local v_u_233 = nil
				p_u_7.runNow(function()
					-- upvalues: (copy) v_u_230, (ref) v_u_231, (ref) v_u_232, (copy) p_u_197, (ref) v_u_233, (ref) v_u_209, (ref) v_u_56, (copy) v_u_223, (copy) v_u_225, (copy) v_u_226, (copy) v_u_222, (copy) v_u_208
					local v234 = os.clock()
					local v235 = v234 - v_u_230
					local v236 = v234 - v_u_231
					local v237 = math.min(v236, 0.05)
					v_u_231 = v234
					local v238 = v_u_232
					local v239 = v235 / p_u_197
					v_u_232 = v238 - v237 * (math.min(v239, 1) * 4 + 4)
					local v240 = v235 / 0.25
					local v241 = 1 - (1 - math.min(v240, 1)) ^ 2
					local v242
					if v_u_233 then
						local v243 = (v234 - v_u_233) / 0.12
						v242 = math.clamp(v243, 0, 1)
					else
						v242 = 0
					end
					local v244 = v241 * (1 - v242)
					v_u_209 = math.max(v244, 0.02)
					v_u_56(v_u_223, v_u_232, 1, v242 * 0.4 + 0.05, v_u_225)
					for v245, v246 in v_u_226 do
						local v247 = (v235 * 0.55 + v245 / #v_u_226) % 1
						v246.CFrame = CFrame.new(v_u_222(v245 % v_u_208 + 1, v247, v_u_232) + Vector3.new(0, 0.3, 0))
					end
					if v242 < 1 then
						return v235 < p_u_197 + 1
					end
					v_u_223.holder:Destroy()
					for _, v248 in v_u_226 do
						v248:Destroy()
					end
					return false
				end)
				local v_u_249 = true
				local v_u_250 = p195.ability.tick or 0.32
				task.spawn(function()
					-- upvalues: (ref) v_u_249, (copy) v_u_230, (copy) p_u_197, (ref) v_u_77, (ref) p_u_7, (copy) p_u_196, (copy) v_u_198, (ref) v_u_6, (ref) v_u_11, (copy) v_u_199, (ref) v_u_10, (copy) v_u_250
					while v_u_249 and os.clock() - v_u_230 < p_u_197 + 0.5 do
						v_u_77(CFrame.new(p_u_7.ground(p_u_196, 0.3)), v_u_198 * 2.5, 3, v_u_6.Ring, v_u_11, 0.3, 3, 0.1)
						if not v_u_199 then
							p_u_7.inward(p_u_7.ground(p_u_196, 1.2), v_u_10, 4, v_u_198 * 1.2, 0.3)
						end
						task.wait(v_u_250)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_249, (ref) v_u_233, (ref) p_u_7, (copy) v_u_201, (copy) v_u_206
					v_u_249 = false
					v_u_233 = os.clock()
					p_u_7.fadeOut(v_u_201, 0.5)
					p_u_7.fadeOut(v_u_206, 0.3)
				end
			end,
			["finish"] = function(p251, p252) -- name: finish
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_10, (ref) v_u_4, (ref) v_u_6, (copy) v_u_170, (copy) v_u_111, (copy) v_u_86, (copy) v_u_13, (ref) v_u_5
				local v253 = p251.ability.radius
				local v254 = p251.lite
				local v255 = p_u_7.ground(p252)
				local v256 = p_u_7.ground(p252, 2)
				p_u_7.pop(v256, v_u_11, 2, v253 * 1.2, 0.25, 0.2)
				p_u_7.burst("Explosion", v256, v_u_10, v253 / 7)
				p_u_7.burst("Shockwave", v255 + Vector3.new(0, 0.3, 0), v_u_10, v253 / 16)
				v_u_4.ring(v255, v_u_10, v253 * 1.3, 0.45, v_u_6.Shockwave)
				v_u_170(p252, 18, v254)
				v_u_111(p_u_7.ground(p252, 1), v254 and 6 or 12, v253 * 0.9, 6, 0.6, 0.7)
				v_u_86(p252, v253 * 0.5, 0.9)
				p_u_7.mark(p252, v_u_13, v253 * 0.7, 2, v_u_6.CrackLines, 0.1)
				v_u_5.play("Explosion", {
					["at"] = nil,
					["volume"] = 0.85,
					["at"] = v255
				})
				if p251.mine then
					v_u_4.shake(0.45, 0.4)
				end
			end,
			["hit"] = function(p257, p258, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_77, (ref) v_u_6, (copy) v_u_11
				p_u_7.burst("Impact", p258, v_u_10, 0.6)
				if not p257.lite then
					v_u_77(CFrame.new(p258), 4, 1, v_u_6.Swirl, v_u_11, 0.2, -18)
				end
			end
		},
		["crimson_spiral_r"] = {
			["cast"] = function(p259) -- name: cast
				-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_111
				p_u_7.skillCast(p259, v_u_10, true)
				p_u_7.burst("Flash", p259.eye, v_u_10, 0.4)
				p_u_7.glint(p259.eye, v_u_11, 7, 0.22)
				if not p259.lite then
					v_u_111(p259.eye + p259.dir * 2, 6, 3, 1, 0.35, 0.4)
				end
			end,
			["windup"] = function(p260, p261, p_u_262) -- name: windup
				-- upvalues: (copy) v_u_130, (copy) p_u_7, (copy) v_u_32, (copy) v_u_10, (copy) v_u_12, (copy) v_u_11, (ref) v_u_6, (copy) v_u_77, (copy) v_u_56
				if p_u_262 >= 0.04 then
					local v_u_263 = p260.size
					local v264 = p260.lite
					local v_u_265 = p260.dir
					local v_u_266 = p261 + v_u_265 * 3.5
					local v_u_267 = v_u_130(v264, p_u_262 + 1)
					local v_u_268
					if v264 then
						v_u_268 = nil
					else
						local v_u_269 = p261 - v_u_265 * 2
						local v_u_270 = p_u_7.aimAt(v_u_269, v_u_265)
						v_u_268 = v_u_32(v_u_269, { v_u_10, v_u_12, v_u_11 }, 8, 0.7, v_u_6.Beam, function(p271, p272, p273)
							-- upvalues: (copy) v_u_269, (copy) v_u_265, (copy) v_u_270
							local v274 = p271 / 3 * 3.141592653589793 * 2 + p272 * 3.141592653589793 * 2 + p273
							local v275 = (1 - p272) * 5.5 + 0.4
							return v_u_269 + v_u_265 * (p272 * 5.5) + (v_u_270.RightVector * math.cos(v274) + v_u_270.UpVector * math.sin(v274)) * v275
						end, p_u_262 + 0.5)
					end
					local v_u_276
					if v264 then
						v_u_276 = nil
					else
						v_u_276 = p_u_7.loopAt("Charge", v_u_266, v_u_10, 0.9)
					end
					v_u_77(CFrame.new(p260.feet + Vector3.new(0, 0.15, 0)), 4, 14, v_u_6.Swirl, v_u_10, p_u_262 + 0.2, -6, 0.2)
					local v_u_277 = os.clock()
					p_u_7.runNow(function()
						-- upvalues: (copy) v_u_277, (copy) p_u_262, (ref) p_u_7, (copy) v_u_267, (copy) v_u_266, (copy) v_u_265, (copy) v_u_263, (ref) v_u_268, (ref) v_u_56, (ref) v_u_276
						local v278 = os.clock() - v_u_277
						local v279 = v278 / p_u_262
						local v280 = math.clamp(v279, 0, 1)
						local v281 = v278 / 0.1
						local v282 = 1 - (1 - math.min(v281, 1)) ^ 2
						p_u_7.rigPlace(v_u_267, p_u_7.aimAt(v_u_266, v_u_265) * CFrame.Angles(0, 0, v278 * (v280 * 30 + 12)), 2.4 * v_u_263 * v282)
						local v283 = v_u_268
						if v283 then
							v_u_56(v283, -v278 * (v280 * 10 + 8), 1, 0.35 - v280 * 0.3)
						end
						if v280 < 1 then
							return true
						end
						p_u_7.rigDestroy(v_u_267)
						if v283 then
							v283.holder:Destroy()
						end
						if v_u_276 then
							v_u_276()
						end
						return false
					end)
				end
			end,
			["beam"] = function(p_u_284, p285, p_u_286) -- name: beam
				-- upvalues: (copy) p_u_7, (copy) v_u_11, (copy) v_u_10, (copy) v_u_9, (ref) v_u_6, (copy) v_u_12, (copy) v_u_13, (copy) v_u_32, (copy) v_u_56, (copy) v_u_130, (copy) v_u_77, (copy) v_u_180, (ref) v_u_4, (ref) v_u_5, (copy) v_u_174
				local v_u_287 = p_u_284.size
				local v_u_288 = p_u_284.lite
				local v_u_289 = (p_u_286 - p285).Unit
				local v_u_290 = p285 + v_u_289 * 2.5
				local v_u_291 = (p_u_286 - v_u_290).Magnitude
				local v_u_292 = p_u_7.aimAt(v_u_290, v_u_289)
				p_u_7.thin(p_u_7.rod(v_u_290, p_u_286, 2.2 * v_u_287, v_u_11), 0.5, true)
				p_u_7.thin(p_u_7.rod(v_u_290, p_u_286, 6.5 * v_u_287, v_u_10, 0.5), 0.6, true)
				p_u_7.thin(p_u_7.rod(v_u_290, p_u_286, 11 * v_u_287, v_u_9, 0.86), 0.7, true)
				p_u_7.glowBeam(v_u_290, p_u_286, v_u_10, 12 * v_u_287, 0.7, v_u_6.BloodThread)
				local v_u_293
				if v_u_288 then
					v_u_293 = { v_u_12 }
				else
					v_u_293 = { v_u_12, v_u_13, v_u_11 }
				end
				local v_u_294 = v_u_291 / 15
				local v_u_295 = 0
				local v_u_296 = 4.2
				local v297 = v_u_32
				local v298
				if v_u_288 then
					v298 = 14
				else
					local v299 = v_u_291 / 3.6
					local v300 = math.floor(v299)
					v298 = math.clamp(v300, 10, 30)
				end
				local v_u_308 = v297(v_u_290, v_u_293, v298, 2 * v_u_287, v_u_6.BloodThread, function(p301, p302, p303)
					-- upvalues: (copy) v_u_293, (copy) v_u_294, (ref) v_u_296, (copy) v_u_287, (copy) v_u_290, (copy) v_u_289, (copy) v_u_291, (ref) v_u_295, (copy) v_u_292
					local v304 = p301 / #v_u_293 * 3.141592653589793 * 2 + p302 * v_u_294 * 3.141592653589793 * 2 + p303
					local v305 = v_u_296
					local v306 = p302 * 10
					local v307 = v305 * (math.min(v306, 1) * 0.65 + 0.35) * v_u_287
					return v_u_290 + v_u_289 * (p302 * v_u_291 * v_u_295) + (v_u_292.RightVector * math.cos(v304) + v_u_292.UpVector * math.sin(v304)) * v307
				end, 2)
				local v_u_309 = os.clock()
				p_u_7.runNow(function()
					-- upvalues: (copy) v_u_309, (ref) v_u_295, (ref) v_u_296, (ref) v_u_56, (copy) v_u_308
					local v310 = os.clock() - v_u_309
					local v311 = v310 / 0.16
					local v312 = math.min(v311, 1)
					v_u_295 = math.max(v312, 0.02)
					local v313 = (v310 - 0.3) / 0.45
					local v314 = math.clamp(v313, 0, 1)
					local v315 = v314 * 5 + 4.2
					local v316 = v310 * 30
					v_u_296 = v315 + math.sin(v316) * 0.3
					v_u_56(v_u_308, -v310 * 16, 1 - v314 * 0.6, v314 * 0.95 + 0.05)
					if v314 < 1 then
						return true
					end
					v_u_308.holder:Destroy()
					return false
				end)
				local v_u_317 = v_u_130(v_u_288, 2)
				p_u_7.animate(0.16, 0, function(p318)
					-- upvalues: (ref) p_u_7, (copy) v_u_317, (copy) v_u_290, (copy) p_u_286, (copy) v_u_292, (copy) v_u_287
					p_u_7.rigPlace(v_u_317, CFrame.new(v_u_290:Lerp(p_u_286, p318)) * v_u_292.Rotation * CFrame.Angles(0, 0, p318 * 14), 3 * v_u_287)
					if p318 >= 1 then
						p_u_7.rigDestroy(v_u_317)
					end
				end)
				local v319 = v_u_288 and 4 or 9
				for v_u_320 = 1, v319 do
					local v321 = v_u_320 / (v319 + 1)
					local v_u_322 = v_u_290:Lerp(p_u_286, v321)
					p_u_7.after(v321 * 0.16, function()
						-- upvalues: (ref) v_u_77, (ref) p_u_7, (copy) v_u_322, (copy) v_u_289, (copy) v_u_287, (ref) v_u_6, (ref) v_u_10, (copy) v_u_320, (copy) v_u_288, (ref) v_u_12
						v_u_77(p_u_7.facing(v_u_322, v_u_289), 8 * v_u_287, 26 * v_u_287, v_u_6.Swirl, v_u_10, 0.45, v_u_320 % 2 == 0 and 9 or -9)
						if not v_u_288 then
							v_u_77(p_u_7.facing(v_u_322 + v_u_289 * 0.3, v_u_289), 6 * v_u_287, 20 * v_u_287, v_u_6.Ring, v_u_12, 0.35, 0, 0.2)
						end
					end)
				end
				p_u_7.groundLine(p285, p_u_286, 10 * v_u_287, v_u_13, 1.6, 0.35)
				if not v_u_288 then
					p_u_7.alongPath(v_u_290, p_u_286, 16, 0.16, function(p323)
						-- upvalues: (ref) v_u_77, (ref) p_u_7, (ref) v_u_6, (ref) v_u_10
						v_u_77(CFrame.new(p_u_7.ground(p323, 0.15)), 4, 13, v_u_6.Swirl, v_u_10, 0.6, -5, 0.25)
						p_u_7.burst("Impact", p323, v_u_10, 1.6)
					end)
				end
				p_u_7.after(0.16, function()
					-- upvalues: (ref) v_u_180, (copy) p_u_284, (copy) p_u_286, (copy) v_u_289
					v_u_180(p_u_284, p_u_286, v_u_289)
				end)
				p_u_7.burst("Flash", v_u_290, v_u_10, 0.6)
				v_u_4.ring(p_u_284.feet, v_u_11, 10, 0.35, v_u_6.SpeedLines)
				v_u_5.play("Burst", {
					["at"] = p285,
					["volume"] = p_u_284.mine and 0.9 or 0.5
				})
				if p_u_284.mine then
					v_u_4.shake(0.6, 0.5)
					v_u_174()
				end
			end,
			["hit"] = function(p324, p325, _) -- name: hit
				-- upvalues: (copy) p_u_7, (copy) v_u_10, (copy) v_u_111
				p_u_7.burst("Impact", p325, v_u_10, 1.2)
				if not p324.lite then
					v_u_111(p325, 4, 3, 1.5, 0.35, 0.4)
				end
			end
		}
	}
	return v326
end