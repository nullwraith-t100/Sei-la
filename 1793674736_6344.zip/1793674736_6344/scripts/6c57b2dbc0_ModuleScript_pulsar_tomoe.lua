local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(255, 150, 176)
local v_u_6 = Color3.fromRGB(240, 70, 120)
local v_u_7 = Color3.fromRGB(255, 236, 242)
local function v_u_13(p8, p9) -- name: facing
	local v10 = p9.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p9.Unit
	local v11 = v10.Y
	local v12 = math.abs(v11) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p8, p8 + v10, v12) * CFrame.Angles(-1.5707963267948966, 0, 0)
end
return function(p_u_14)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_13, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6
	return {
		["w5_pulsar_tomoe"] = function(p_u_15, p16)
			-- upvalues: (ref) v_u_3, (copy) p_u_14, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_1, (ref) v_u_7, (ref) v_u_6
			local v_u_17 = v_u_3.color(p16.color)
			local v18 = p_u_15.headY / 1.5
			local v_u_19 = math.clamp(v18, 0.7, 3)
			p_u_15.eyeLift = 3.1
			local v_u_20 = 0
			local function v45(p21) -- name: pulse
				-- upvalues: (ref) v_u_20, (copy) p_u_15, (ref) p_u_14, (copy) v_u_19, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_3, (ref) v_u_1, (copy) v_u_17
				v_u_20 = v_u_20 + 1
				local v22 = p_u_15.fx
				local v23 = os.clock() - p_u_15.started
				local v24 = p21.Position
				local v25 = p_u_15.headY + p_u_15.eyeLift
				local v26 = v23 * 2
				local v27 = v24 + Vector3.new(0, 1, 0) * (v25 + math.sin(v26) * 0.1)
				local v28 = p_u_14.camPos() - v27
				local v29 = v28.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v28.Unit
				local v30, v31 = p_u_14.picture(v_u_19 * 2, v_u_4.PulsarRipple, v_u_5, 0.1)
				v30.CFrame = v_u_13(v27 - v29 * 0.6 * v_u_19, v29)
				local v32 = v_u_3.tween
				local v33 = {}
				local v34 = v_u_19 * 8.5
				local v35 = v_u_19 * 8.5
				v33.Size = Vector3.new(v34, 0.05, v35)
				v32(v30, 0.55, v33)
				for _, v36 in v31 do
					v_u_3.tween(v36, 0.55, {
						["Transparency"] = 1
					})
				end
				v_u_1:AddItem(v30, 0.6)
				local v37, v38 = p_u_14.picture(v_u_19 * 3.6, v_u_4.PulsarRipple, v_u_17, 0.1)
				local v39 = p_u_14.feetAt(p_u_15, p21, 0.2)
				v37.CFrame = CFrame.new(v39)
				local v40 = v_u_3.tween
				local v41 = {
					["CFrame"] = CFrame.new(p21.Position + Vector3.new(0, 1, 0) * p_u_15.headY)
				}
				local v42 = v_u_19 * 2.2
				local v43 = v_u_19 * 2.2
				v41.Size = Vector3.new(v42, 0.05, v43)
				v40(v37, 0.5, v41, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				for _, v44 in v38 do
					v_u_3.tween(v44, 0.5, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
				v_u_1:AddItem(v37, 0.55)
				if v_u_20 % 4 == 0 then
					v_u_3.ring(v39, v_u_17, 5.5 * v22, 0.6, v_u_4.PulsarRipple)
				end
			end
			local v_u_46 = p_u_14.throb(p_u_15, 1.15, 0.6, 3.5, v45)
			local v_u_47 = p_u_14.picture(v_u_19 * 5.6, v_u_4.Glow, v_u_17, 0.12)
			p_u_14.add(p_u_15, v_u_47, function(p48, p49)
				-- upvalues: (copy) p_u_15, (ref) p_u_14, (copy) v_u_46, (copy) v_u_19, (copy) v_u_47, (ref) v_u_13
				local v50 = p48.Position
				local v51 = p_u_15.headY + p_u_15.eyeLift
				local v52 = p49 * 2
				local v53 = v50 + Vector3.new(0, 1, 0) * (v51 + math.sin(v52) * 0.1)
				local v54 = p_u_14.camPos() - v53
				local v55 = v54.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v54.Unit
				local v56 = (5.6 + 2 * v_u_46()) * v_u_19
				v_u_47.Size = Vector3.new(v56, 0.05, v56)
				return v_u_13(v53 - v55 * 0.7 * v_u_19, v55)
			end)
			local v57 = p_u_14.ball(v_u_19 * 0.5, v_u_7, 0)
			p_u_14.add(p_u_15, v57, function(p58, p59)
				-- upvalues: (copy) p_u_15, (ref) p_u_14, (copy) v_u_19
				local v60 = p58.Position
				local v61 = p_u_15.headY + p_u_15.eyeLift
				local v62 = p59 * 2
				local v63 = v60 + Vector3.new(0, 1, 0) * (v61 + math.sin(v62) * 0.1)
				local v64 = CFrame.new
				local v65 = p_u_14.camPos() - v63
				return v64(v63 - (v65.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v65.Unit) * 0.45 * v_u_19)
			end)
			local v66 = Instance.new("Attachment")
			v66.Parent = v57
			local v_u_67 = v_u_19 * 5.5
			for _, v_u_68 in { 1, -1 } do
				local v69 = p_u_14.bar(Vector3.new(0.1, 0.1, 0.1), v_u_17, 1)
				p_u_14.add(p_u_15, v69, function(p70, p71)
					-- upvalues: (copy) p_u_15, (copy) v_u_68, (copy) v_u_67
					local v72 = CFrame.new
					local v73 = p70.Position
					local v74 = p_u_15.headY + p_u_15.eyeLift
					local v75 = p71 * 2
					local v76 = v73 + Vector3.new(0, 1, 0) * (v74 + math.sin(v75) * 0.1)
					local v77 = p71 * 3.4
					local v78 = p71 * 1.3
					local v79 = math.sin(v78) * 0.2 + 0.25
					local v80 = math.cos(v77) * math.cos(v79)
					local v81 = math.sin(v79)
					local v82 = math.sin(v77) * math.cos(v79)
					return v72(v76 + Vector3.new(v80, v81, v82) * v_u_68 * v_u_67)
				end)
				local v83 = Instance.new("Attachment")
				v83.Parent = v69
				local v_u_84 = p_u_14.ray(v66, v83, v_u_6, v_u_19 * 0.5, v_u_19 * 2.6, v_u_4.Beam)
				v_u_84.LightEmission = 0.2
				v_u_84.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.6, 0.35), NumberSequenceKeypoint.new(1, 1) })
				local v_u_85 = p_u_14.ray(v66, v83, v_u_5, v_u_19 * 0.2, v_u_19 * 0.9, v_u_4.Beam)
				v_u_85.LightEmission = 0.35
				v_u_85.Transparency = v_u_84.Transparency
				local v86 = p_u_15.ticks
				table.insert(v86, function()
					-- upvalues: (copy) v_u_46, (copy) v_u_84, (copy) v_u_19, (copy) v_u_85
					local v87 = v_u_46()
					v_u_84.Width1 = (2.6 + 1.6 * v87) * v_u_19
					v_u_85.Width1 = (0.9 + 0.6 * v87) * v_u_19
				end)
			end
			for v_u_88 = 1, 3 do
				local v89 = p_u_14.picture(v_u_19 * 1.5, v_u_4.PulsarTomoe, v_u_17, 0)
				p_u_14.add(p_u_15, v89, function(p90, p91)
					-- upvalues: (copy) p_u_15, (ref) p_u_14, (copy) v_u_88, (copy) v_u_46, (copy) v_u_19, (ref) v_u_13
					local v92 = p90.Position
					local v93 = p_u_15.headY + p_u_15.eyeLift
					local v94 = p91 * 2
					local v95 = v92 + Vector3.new(0, 1, 0) * (v93 + math.sin(v94) * 0.1)
					local v96 = p_u_14.camPos() - v95
					local v97 = v96.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v96.Unit
					local v98 = v97:Cross(Vector3.new(0, 1, 0))
					local v99 = (v98.Magnitude < 0.01 and Vector3.new(1, 0, 0) or v98).Unit
					local v100 = v99:Cross(v97)
					local v101 = -p91 * 2.2 + (v_u_88 - 1) * 3.141592653589793 * 2 / 3
					local v102 = (2.15 + 0.45 * v_u_46()) * v_u_19
					return v_u_13(v95 + (v99 * math.cos(v101) + v100 * math.sin(v101)) * v102 + v97 * 0.2 * v_u_19, v97) * CFrame.Angles(0, -p91 * 5 + v_u_88, 0)
				end)
			end
			p_u_14.particles(p_u_15, "AuraMode", v_u_17, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_14.particles(p_u_15, "Petals", v_u_5, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end