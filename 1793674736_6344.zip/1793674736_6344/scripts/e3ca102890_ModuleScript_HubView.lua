local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Menus)
local v_u_6 = require(script.Parent.Store)
local v_u_7 = require(script.Parent.LimitedCards)
local v_u_8 = require(script.Parent.Tutorial)
local v_u_9 = require(script.Parent.PetModels)
local v_u_10 = require(script.Parent.Look)
local v_u_11 = require(script.Parent.State)
local v_u_12 = require(script.Parent.Fx.Kit)
local v_u_13 = require(script.Parent.Perf)
local v_u_14 = require(script.Parent.Streamed)
local v15 = v2.Shared
local v_u_16 = require(v15.Config.Eyes)
local v_u_17 = require(v15.Config.Images)
local v_u_18 = require(v15.Config.Pets)
local v_u_19 = require(v15.Config.Plots)
local v_u_20 = require(v15.Config.World)
local v_u_21 = require(v15.Logic.Format)
local v22 = {}
local v_u_23 = v1.LocalPlayer
local v_u_24 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_25 = table.clone(v_u_17.Iris)
local v_u_26 = Color3.fromRGB(110, 255, 90)
local v_u_27 = Color3.fromRGB(255, 80, 90)
local v_u_28 = Color3.fromRGB(255, 40, 40)
local v_u_29 = Color3.fromRGB(255, 205, 30)
local v_u_30 = Color3.fromRGB(60, 255, 90)
local v_u_31 = Color3.fromRGB(40, 140, 255)
local v_u_32 = Color3.new(1, 1, 1)
local v_u_33 = v_u_17.Icon.Trophy or v_u_17.Icon.Wins
local function v_u_42(p34, p35, p36, p37, p38, p39) -- name: label
	-- upvalues: (copy) v_u_24
	local v40 = Instance.new("TextLabel")
	v40.Name = p35
	v40.BackgroundTransparency = 1
	v40.Size = p37
	v40.Position = p38
	v40.AnchorPoint = Vector2.new(0.5, 0.5)
	v40.FontFace = v_u_24
	v40.TextScaled = true
	v40.Text = p36
	v40.TextColor3 = p39
	local v41 = Instance.new("UIStroke")
	v41.Thickness = 0.12
	v41.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v41.Parent = v40
	v40.Parent = p34
	return v40
end
local function v_u_57(p43, p44, p45, p46, p47) -- name: iconCount
	-- upvalues: (copy) v_u_42, (copy) v_u_32
	local v_u_48 = Instance.new("Frame")
	v_u_48.Name = p44
	v_u_48.BackgroundTransparency = 1
	v_u_48.Size = p46
	v_u_48.Position = p47
	v_u_48.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_48.Parent = p43
	local v49 = Instance.new("UIListLayout")
	v49.FillDirection = Enum.FillDirection.Horizontal
	v49.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v49.VerticalAlignment = Enum.VerticalAlignment.Center
	v49.Padding = UDim.new(0.02, 0)
	v49.SortOrder = Enum.SortOrder.LayoutOrder
	v49.Parent = v_u_48
	local v50 = UDim2.fromScale(0.2, 1)
	local v51 = UDim2.new()
	local v52 = Instance.new("ImageLabel")
	v52.Name = "Icon"
	v52.BackgroundTransparency = 1
	v52.Image = p45
	v52.Size = v50
	v52.Position = v51
	v52.AnchorPoint = Vector2.new(0.5, 0.5)
	v52.ScaleType = Enum.ScaleType.Fit
	v52.Parent = v_u_48
	v52.LayoutOrder = 1
	Instance.new("UIAspectRatioConstraint").Parent = v52
	local v_u_53 = v_u_42(v_u_48, "Count", "", UDim2.fromScale(0, 0.9), UDim2.new(), v_u_32)
	v_u_53.LayoutOrder = 2
	v_u_53.AutomaticSize = Enum.AutomaticSize.X
	v_u_53.TextScaled = false
	v_u_48:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- name: fit
		-- upvalues: (copy) v_u_53, (copy) v_u_48
		local v54 = v_u_53
		local v55 = v_u_48.AbsoluteSize.Y * 0.85
		v54.TextSize = math.max(8, v55)
	end)
	local v56 = v_u_48.AbsoluteSize.Y * 0.85
	v_u_53.TextSize = math.max(8, v56)
	return v_u_53, v52, v_u_48
end
local function v_u_61(p58) -- name: frameGap
	-- upvalues: (copy) v_u_4, (copy) v_u_13
	local v59 = v_u_4.CurrentCamera
	local v60 = nil
	while p58 do
		if p58:IsA("BillboardGui") and (p58.Adornee and p58.Adornee:IsA("BasePart")) then
			v60 = p58.Adornee.Position
			break
		end
		if p58:IsA("BasePart") then
			v60 = p58.Position
			break
		end
		if p58:IsA("Model") then
			v60 = p58:GetPivot().Position
			break
		end
		p58 = p58.Parent
	end
	return not (v59 and v60) and 0.03333333333333333 or v_u_13.frameGap((v60 - v59.CFrame.Position).Magnitude)
end
local function v_u_103(p62, p63) -- name: trainingSigns
	-- upvalues: (copy) v_u_19, (copy) v_u_14, (copy) v_u_12, (copy) v_u_42, (copy) v_u_21, (copy) v_u_32, (copy) v_u_6, (copy) v_u_23, (copy) v_u_7, (copy) v_u_26, (copy) v_u_57, (copy) v_u_17, (copy) v_u_11, (copy) v_u_27, (copy) v_u_61
	for v_u_64, v_u_65 in v_u_19.forWorld(p63) do
		v_u_14.each(p62, "Training" .. v_u_64, function(p66)
			-- upvalues: (ref) v_u_14, (ref) v_u_12, (copy) v_u_65, (ref) v_u_42, (ref) v_u_21, (ref) v_u_32, (ref) v_u_6, (ref) v_u_23, (ref) v_u_7, (ref) v_u_26, (ref) v_u_57, (ref) v_u_17, (ref) v_u_11, (ref) v_u_27, (copy) v_u_64, (ref) v_u_61
			local v67
			if p66 then
				v67 = p66:FindFirstChild("Display")
			else
				v67 = p66
			end
			if not (v67 and v67:IsA("BasePart")) then
				v67 = nil
			end
			local v68 = v67 or p66:WaitForChild("Display", 10)
			if not (v68 and v68:IsA("BasePart")) then
				return nil
			end
			local v69, v_u_70 = v_u_14.bag()
			local v_u_71 = true
			local v_u_72 = Instance.new("BillboardGui")
			v_u_72.Adornee = v68
			v_u_72.Size = UDim2.fromScale(14, 6)
			v_u_72.StudsOffsetWorldSpace = Vector3.new(0, 0, 0)
			v_u_72.LightInfluence = 0
			v_u_72.MaxDistance = 220
			v_u_72.Parent = v68
			v_u_72.Name = "Sign"
			local v73 = v_u_12.color(v_u_65.color)
			local v74 = v_u_42(v_u_72, "Mult", string.upper(v_u_21.mult(v_u_65.mult)) .. " CHAKRA", UDim2.fromScale(1, 0.5), UDim2.fromScale(0.5, 0.27), v_u_32)
			local v75 = v73:Lerp(v_u_32, 0.45)
			local v76 = Instance.new("UIGradient")
			v76.Color = ColorSequence.new(v75, v73)
			v76.Rotation = 90
			v76.Parent = v74
			if v_u_65.pass then
				local v_u_77 = v_u_6.pass(v_u_65.pass)
				local v_u_78 = v_u_42(v_u_72, "Price", "", UDim2.fromScale(0.8, 0.38), UDim2.fromScale(0.5, 0.76), Color3.fromRGB(255, 215, 60))
				local v_u_79 = "Pass_" .. v_u_65.pass
				local function v88() -- name: show
					-- upvalues: (ref) v_u_23, (copy) v_u_79, (ref) v_u_7, (ref) v_u_65, (copy) v_u_78, (ref) v_u_6, (copy) v_u_77, (ref) v_u_26
					local v80 = v_u_23:GetAttribute(v_u_79) == true
					local v81 = not v80
					if v81 then
						v81 = v_u_7.left(v_u_65.pass) == 0
					end
					local v82 = v_u_78
					local v83
					if v80 then
						v83 = "OWNED"
					elseif v81 then
						v83 = "SOLD OUT"
					else
						local v84 = v_u_6.ROBUX
						local v85 = not v_u_77 and "?" or v_u_77.price
						v83 = v84 .. " " .. tostring(v85)
					end
					v82.Text = v83
					local v86 = v_u_78
					local v87
					if v80 then
						v87 = v_u_26
					elseif v81 then
						v87 = Color3.fromRGB(190, 190, 200)
					else
						v87 = Color3.fromRGB(255, 215, 60)
					end
					v86.TextColor3 = v87
				end
				local v89 = v_u_23:GetAttributeChangedSignal(v_u_79)
				table.insert(v69, v89:Connect(v88))
				local v90 = v_u_7.changed
				table.insert(v69, v90:Connect(v88))
				v88()
			else
				local v_u_91, v_u_92 = v_u_57(v_u_72, "Need", v_u_17.Icon.Rebirth, UDim2.fromScale(1, 0.42), UDim2.fromScale(0.5, 0.76))
				local v93 = v_u_11.watch
				local function v99()
					-- upvalues: (ref) v_u_11, (ref) v_u_65, (copy) v_u_91, (ref) v_u_21, (ref) v_u_26, (ref) v_u_27, (copy) v_u_92, (ref) v_u_32
					local v94 = v_u_11.number("Rebirths") >= v_u_65.rebirths
					v_u_91.Text = v_u_21.short(v_u_65.rebirths)
					local v95 = v_u_91
					local v96
					if v94 then
						v96 = v_u_26
					else
						v96 = v_u_27
					end
					v95.TextColor3 = v96
					local v97 = v_u_92
					local v98
					if v94 then
						v98 = v_u_32
					else
						v98 = Color3.fromRGB(150, 150, 160)
					end
					v97.ImageColor3 = v98
				end
				table.insert(v69, v93("Rebirths", v99))
				task.spawn(function()
					-- upvalues: (ref) v_u_71, (copy) v_u_72, (ref) v_u_64, (ref) v_u_61
					while v_u_71 do
						local v100 = v_u_72
						local v101 = os.clock() * 2 + v_u_64
						local v102 = math.sin(v101) * 0.35
						v100.StudsOffsetWorldSpace = Vector3.new(0, v102, 0)
						task.wait(v_u_61(v_u_72))
					end
				end)
			end
			return function()
				-- upvalues: (ref) v_u_71, (copy) v_u_70, (copy) v_u_72
				v_u_71 = false
				v_u_70()
				v_u_72:Destroy()
			end
		end)
	end
end
local function v_u_156(p104, p105) -- name: eyeSigns
	-- upvalues: (copy) v_u_16, (copy) v_u_14, (copy) v_u_12, (copy) v_u_25, (copy) v_u_17, (copy) v_u_42, (copy) v_u_21, (copy) v_u_26, (copy) v_u_57, (copy) v_u_33, (copy) v_u_6, (copy) v_u_11, (copy) v_u_30, (copy) v_u_29, (copy) v_u_31, (copy) v_u_28, (copy) v_u_27, (copy) v_u_32, (copy) v_u_61
	local v106 = v_u_16.padEyesFor(p105)
	for v107 = #v106 + 1, 20 do
		v_u_14.each(p104, "EyePad" .. v107, function(p108)
			local v109
			if p108 then
				v109 = p108:FindFirstChild("Pad")
			else
				v109 = p108
			end
			if not (v109 and v109:IsA("BasePart")) then
				v109 = nil
			end
			if p108 then
				p108 = p108:FindFirstChild("Rim")
			end
			if not (p108 and p108:IsA("BasePart")) then
				p108 = nil
			end
			if v109 and p108 then
				v109.Material = Enum.Material.SmoothPlastic
				v109.Color = p108.Color
			end
			return nil
		end)
	end
	for v_u_110, v_u_111 in v106 do
		v_u_14.each(p104, "EyePad" .. v_u_110, function(p_u_112)
			-- upvalues: (ref) v_u_14, (ref) v_u_12, (copy) v_u_111, (ref) v_u_25, (ref) v_u_17, (ref) v_u_42, (ref) v_u_16, (ref) v_u_21, (ref) v_u_26, (ref) v_u_57, (ref) v_u_33, (ref) v_u_6, (ref) v_u_11, (ref) v_u_30, (ref) v_u_29, (ref) v_u_31, (ref) v_u_28, (ref) v_u_27, (ref) v_u_32, (copy) v_u_110, (ref) v_u_61
			local v113
			if p_u_112 then
				v113 = p_u_112:FindFirstChild("Display")
			else
				v113 = p_u_112
			end
			if not (v113 and v113:IsA("BasePart")) then
				v113 = nil
			end
			local v114 = v113 or p_u_112:WaitForChild("Display", 10)
			if not (v114 and v114:IsA("BasePart")) then
				return nil
			end
			local v115, v_u_116 = v_u_14.bag()
			local v_u_117 = true
			local v_u_118 = Instance.new("BillboardGui")
			v_u_118.Adornee = v114
			v_u_118.Size = UDim2.fromScale(9, 11)
			v_u_118.StudsOffsetWorldSpace = Vector3.new(0, 1.5, 0)
			v_u_118.LightInfluence = 0
			v_u_118.MaxDistance = 220
			v_u_118.Parent = v114
			v_u_118.Name = "Sign"
			local v119 = UDim2.fromScale(1.1, 0.62)
			local v120 = UDim2.fromScale(0.5, 0.26)
			local v_u_121 = Instance.new("ImageLabel")
			v_u_121.Name = "Glow"
			v_u_121.BackgroundTransparency = 1
			v_u_121.Image = "rbxassetid://96427887277553"
			v_u_121.Size = v119
			v_u_121.Position = v120
			v_u_121.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_121.ScaleType = Enum.ScaleType.Fit
			v_u_121.Parent = v_u_118
			v_u_121.ImageColor3 = v_u_12.color(v_u_111.color)
			local v122 = v_u_25[v_u_111.id] or v_u_17.Iris.sharingan
			local v123 = UDim2.fromScale(0.66, 0.44)
			local v124 = UDim2.fromScale(0.5, 0.26)
			local v_u_125 = Instance.new("ImageLabel")
			v_u_125.Name = "Iris"
			v_u_125.BackgroundTransparency = 1
			v_u_125.Image = v122
			v_u_125.Size = v123
			v_u_125.Position = v124
			v_u_125.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_125.ScaleType = Enum.ScaleType.Fit
			v_u_125.Parent = v_u_118
			v_u_42(v_u_118, "Name", v_u_111.short, UDim2.fromScale(1.15, 0.16), UDim2.fromScale(0.5, 0.56), v_u_12.color(v_u_16.RARITY_COLOR[v_u_111.rarity])).ZIndex = 2
			v_u_42(v_u_118, "Mult", v_u_21.mult(v_u_111.mult) .. " Chakra", UDim2.fromScale(1.1, 0.13), UDim2.fromScale(0.5, 0.7), Color3.fromRGB(255, 230, 120))
			local v_u_126 = v_u_42(v_u_118, "State", "", UDim2.fromScale(1.1, 0.14), UDim2.fromScale(0.5, 0.86), v_u_26)
			local v_u_127, v_u_128, v_u_129 = v_u_57(v_u_118, "Need", v_u_33, UDim2.fromScale(1, 0.17), UDim2.fromScale(0.5, 0.86))
			if p_u_112 then
				p_u_112 = p_u_112:FindFirstChild("Pad")
			end
			if not (p_u_112 and p_u_112:IsA("BasePart")) then
				p_u_112 = nil
			end
			local v_u_130
			if p_u_112 then
				v_u_130 = p_u_112.Color
			else
				v_u_130 = nil
			end
			local v_u_131
			if p_u_112 then
				v_u_131 = Instance.new("BillboardGui")
				v_u_131.Adornee = p_u_112
				v_u_131.Size = UDim2.fromScale(4.6, 2.3)
				v_u_131.StudsOffsetWorldSpace = Vector3.new(0, 1.35, -1.7)
				v_u_131.LightInfluence = 0
				v_u_131.MaxDistance = 220
				v_u_131.Parent = p_u_112
				v_u_131.Name = "Skip"
				v_u_131.MaxDistance = 140
				v_u_42(v_u_131, "Title", "SKIP", UDim2.fromScale(1, 0.52), UDim2.fromScale(0.5, 0.27), Color3.fromRGB(255, 214, 64))
				local v_u_132 = v_u_6.product("skipEye")
				if v_u_132 and v_u_132.id ~= 0 then
					local v_u_133 = v_u_42(v_u_131, "Price", v_u_6.priceText(v_u_132.price), UDim2.fromScale(1, 0.46), UDim2.fromScale(0.5, 0.76), v_u_26)
					local v134 = v_u_6.pricesChanged
					local function v135()
						-- upvalues: (copy) v_u_133, (ref) v_u_6, (copy) v_u_132
						v_u_133.Text = v_u_6.priceText(v_u_132.price)
					end
					table.insert(v115, v134:Connect(v135))
				end
			else
				v_u_131 = nil
			end
			local function v149() -- name: refresh
				-- upvalues: (ref) v_u_11, (ref) v_u_111, (ref) v_u_16, (copy) p_u_112, (ref) v_u_30, (ref) v_u_29, (ref) v_u_31, (ref) v_u_28, (ref) v_u_131, (copy) v_u_126, (copy) v_u_129, (copy) v_u_127, (ref) v_u_21, (ref) v_u_26, (ref) v_u_27, (copy) v_u_128, (ref) v_u_32, (copy) v_u_125, (copy) v_u_121
				local v136 = v_u_11.eyes()[v_u_111.id] ~= nil
				local v137 = v_u_16.nextLocked(v_u_11.eyes())
				local v138 = not v136
				if v138 then
					if v137 == nil then
						v138 = false
					else
						v138 = v137.id == v_u_111.id
					end
				end
				local v139 = v_u_11.string("Eye") == v_u_111.id
				if p_u_112 then
					local v140 = p_u_112
					local v141
					if v139 then
						v141 = v_u_30
					elseif v136 then
						v141 = v_u_29
					elseif v138 then
						v141 = v_u_31
					else
						v141 = v_u_28
					end
					v140.Color = v141
				end
				if v_u_131 then
					v_u_131.Enabled = v138
				end
				v_u_126.Visible = v136
				v_u_129.Visible = not v136
				v_u_126.Text = v139 and "EQUIPPED" or "OWNED"
				v_u_127.Text = v_u_21.short(v_u_111.wins)
				local v142 = v_u_11.number("TotalWins") >= v_u_111.wins
				local v143 = v_u_127
				local v144
				if v142 then
					v144 = v_u_26
				else
					v144 = v_u_27
				end
				v143.TextColor3 = v144
				local v145 = v_u_128
				local v146
				if v142 then
					v146 = v_u_32
				else
					v146 = Color3.fromRGB(170, 170, 180)
				end
				v145.ImageColor3 = v146
				local v147 = v_u_125
				local v148
				if v136 then
					v148 = v_u_32
				else
					v148 = Color3.fromRGB(110, 110, 120)
				end
				v147.ImageColor3 = v148
				v_u_121.Visible = v136 or v142
			end
			for _, v150 in { "Eye", "Eyes", "TotalWins" } do
				local v151 = v_u_11.watch
				table.insert(v115, v151(v150, v149))
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_117, (copy) v_u_125, (ref) v_u_110, (copy) v_u_121, (copy) v_u_118, (ref) v_u_61
				while v_u_117 do
					local v152 = os.clock()
					v_u_125.Rotation = (v152 * 30 + v_u_110 * 40) % 360
					v_u_121.Rotation = -(v152 * 15) % 360
					local v153 = v_u_118
					local v154 = v152 * 2.2 + v_u_110
					local v155 = math.sin(v154) * 0.3 + 1.5
					v153.StudsOffsetWorldSpace = Vector3.new(0, v155, 0)
					task.wait(v_u_61(v_u_118))
				end
			end)
			return function()
				-- upvalues: (ref) v_u_117, (copy) v_u_116, (copy) v_u_118, (ref) v_u_131, (copy) p_u_112, (copy) v_u_130
				v_u_117 = false
				v_u_116()
				v_u_118:Destroy()
				if v_u_131 then
					v_u_131:Destroy()
				end
				if p_u_112 and v_u_130 then
					p_u_112.Color = v_u_130
				end
			end
		end)
	end
end
local v_u_157 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 60, 60)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(255, 200, 40)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(80, 255, 90)),
	ColorSequenceKeypoint.new(0.6, Color3.fromRGB(60, 200, 255)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(190, 90, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 60, 60))
})
local function v_u_173(p158, p159, p160, p161, p162) -- name: animatedTag
	-- upvalues: (copy) v_u_42, (copy) v_u_32, (copy) v_u_61
	local v_u_163 = v_u_42(p158, "Tag", p159, p160, p161, v_u_32)
	local v_u_164 = Instance.new("UIGradient")
	v_u_164.Color = p162
	v_u_164.Parent = v_u_163
	local v_u_165 = Instance.new("UIScale")
	v_u_165.Parent = v_u_163
	task.spawn(function()
		-- upvalues: (copy) v_u_163, (copy) v_u_164, (copy) v_u_165, (ref) v_u_61
		local v166 = math.random() * 10
		while v_u_163.Parent do
			local v167 = os.clock() + v166
			v_u_164.Offset = Vector2.new(v167 * 0.6 % 2 - 1, 0)
			local v168 = v_u_165
			local v169 = v167 * 3.2
			local v170 = math.sin(v169)
			v168.Scale = math.abs(v170) * 0.14 + 1
			local v171 = v_u_163
			local v172 = v167 * 2.1
			v171.Rotation = math.sin(v172) * 5
			task.wait(v_u_61(v_u_163))
		end
	end)
	return v_u_163
end
local function v_u_191(p174, p_u_175, p_u_176) -- name: buyPrompt
	-- upvalues: (copy) v_u_23, (copy) v_u_6
	local v_u_177 = Instance.new("Attachment")
	v_u_177.Name = "BuyPrompt"
	local v178 = p174.Size.Y / 2 + 3
	v_u_177.Position = Vector3.new(0, v178, 0)
	v_u_177.Parent = p174
	local v_u_179 = Instance.new("ProximityPrompt")
	v_u_179.ActionText = "Buy"
	v_u_179.HoldDuration = 0
	v_u_179.MaxActivationDistance = 16
	v_u_179.RequiresLineOfSight = false
	v_u_179.KeyboardKeyCode = Enum.KeyCode.E
	v_u_179.GamepadKeyCode = Enum.KeyCode.ButtonX
	v_u_179.Parent = v_u_177
	local function v188() -- name: show
		-- upvalues: (ref) v_u_23, (copy) p_u_175, (ref) v_u_6, (copy) v_u_179, (copy) p_u_176
		local v180 = v_u_23:GetAttribute("Pass_" .. p_u_175) == true
		local v181 = v_u_6.pass(p_u_175)
		local v182 = v_u_179
		local v183 = p_u_176
		local v184 = v_u_6.ROBUX
		local v185 = not v181 and "?" or v181.price
		v182.ObjectText = v183 .. "  " .. v184 .. " " .. tostring(v185)
		local v186 = v_u_179
		local v187 = not v180
		if v187 then
			if v181 == nil then
				v187 = false
			else
				v187 = v181.id ~= 0
			end
		end
		v186.Enabled = v187
	end
	v188()
	local v_u_189 = v_u_23:GetAttributeChangedSignal("Pass_" .. p_u_175):Connect(v188)
	local v_u_190 = v_u_6.pricesChanged:Connect(v188)
	v_u_179.Triggered:Connect(function()
		-- upvalues: (ref) v_u_6, (copy) p_u_175
		v_u_6.buyPass(p_u_175)
	end)
	return function()
		-- upvalues: (copy) v_u_189, (copy) v_u_190, (copy) v_u_177
		v_u_189:Disconnect()
		v_u_190:Disconnect()
		v_u_177:Destroy()
	end
end
local function v_u_223(p192, p193, p194, p195, p_u_196, p197, p_u_198) -- name: dealBoard
	-- upvalues: (copy) v_u_173, (copy) v_u_157, (copy) v_u_42, (copy) v_u_32, (copy) v_u_6, (copy) v_u_26, (copy) v_u_23, (copy) v_u_7, (copy) v_u_61
	local v199 = p_u_198 * 16
	local v200 = p_u_198 * 9
	local v_u_201 = Instance.new("BillboardGui")
	v_u_201.Adornee = p192
	v_u_201.Size = UDim2.fromScale(v199, v200)
	v_u_201.StudsOffsetWorldSpace = Vector3.new(0, 0, 0)
	v_u_201.LightInfluence = 0
	v_u_201.MaxDistance = 220
	v_u_201.Parent = p192
	v_u_201.Name = "Deal"
	v_u_173(v_u_201, p193, UDim2.fromScale(1, 0.26), UDim2.fromScale(0.5, 0.13), v_u_157)
	local v202 = v_u_42(v_u_201, "Name", p194, UDim2.fromScale(1, 0.26), UDim2.fromScale(0.5, 0.42), v_u_32)
	local v203 = p197:Lerp(v_u_32, 0.4)
	local v204 = Instance.new("UIGradient")
	v204.Color = ColorSequence.new(v203, p197)
	v204.Rotation = 90
	v204.Parent = v202
	v_u_42(v_u_201, "Info", p195, UDim2.fromScale(0.9, 0.17), UDim2.fromScale(0.5, 0.64), Color3.fromRGB(255, 230, 120))
	local v_u_205 = v_u_6.pass(p_u_196)
	local v_u_206 = v_u_42(v_u_201, "Price", "", UDim2.fromScale(0.6, 0.18), UDim2.fromScale(0.5, 0.86), v_u_26)
	local function v211() -- name: show
		-- upvalues: (ref) v_u_23, (copy) p_u_196, (copy) v_u_206, (ref) v_u_7, (ref) v_u_6, (copy) v_u_205
		local v207 = v_u_206
		local v208
		if v_u_23:GetAttribute("Pass_" .. p_u_196) == true then
			v208 = "OWNED"
		elseif v_u_7.left(p_u_196) == 0 then
			v208 = "SOLD OUT"
		else
			local v209 = v_u_6.ROBUX
			local v210 = not v_u_205 and "?" or v_u_205.price
			v208 = v209 .. " " .. tostring(v210)
		end
		v207.Text = v208
	end
	local v_u_212 = v_u_23:GetAttributeChangedSignal("Pass_" .. p_u_196):Connect(v211)
	local v_u_213 = v_u_6.pricesChanged:Connect(v211)
	local v_u_214 = v_u_7.changed:Connect(v211)
	local v215
	if v_u_23:GetAttribute("Pass_" .. p_u_196) == true then
		v215 = "OWNED"
	elseif v_u_7.left(p_u_196) == 0 then
		v215 = "SOLD OUT"
	else
		local v216 = v_u_6.ROBUX
		local v217 = not v_u_205 and "?" or v_u_205.price
		v215 = v216 .. " " .. tostring(v217)
	end
	v_u_206.Text = v215
	local v_u_218 = v_u_7.podium(p192, p_u_196, p_u_198, v_u_61)
	local v_u_219 = true
	task.spawn(function()
		-- upvalues: (ref) v_u_219, (copy) v_u_201, (copy) p_u_198, (ref) v_u_61
		while v_u_219 do
			local v220 = v_u_201
			local v221 = os.clock() * 1.8
			local v222 = math.sin(v221) * 0.4 * p_u_198
			v220.StudsOffsetWorldSpace = Vector3.new(0, v222, 0)
			task.wait(v_u_61(v_u_201))
		end
	end)
	return function()
		-- upvalues: (ref) v_u_219, (copy) v_u_212, (copy) v_u_213, (copy) v_u_214, (copy) v_u_218, (copy) v_u_201
		v_u_219 = false
		v_u_212:Disconnect()
		v_u_213:Disconnect()
		v_u_214:Disconnect()
		if v_u_218 then
			v_u_218()
		end
		v_u_201:Destroy()
	end
end
local function v_u_240(p224) -- name: standStraight
	local v225 = p224:FindFirstChild("HumanoidRootPart")
	if v225 and v225:IsA("BasePart") then
		local v226 = {}
		for _, v227 in p224:GetDescendants() do
			if v227:IsA("JointInstance") and (v227.Part0 and v227.Part1) then
				local v228 = {
					["a"] = v227.Part0,
					["b"] = v227.Part1,
					["rest"] = v227.C0 * v227.C1:Inverse()
				}
				table.insert(v226, v228)
			elseif v227:IsA("AnimationConstraint") or v227:IsA("RigidConstraint") then
				local v229 = v227.Attachment0
				local v230 = v227.Attachment1
				local v231
				if v229 then
					v231 = v229.Parent
				else
					v231 = v229
				end
				local v232
				if v230 then
					v232 = v230.Parent
				else
					v232 = v230
				end
				if not (v229 and (v230 and (v231 and (v232 and (v231:IsA("BasePart") and v232:IsA("BasePart")))))) then
					continue
				end
				local v233 = {
					["a"] = v231,
					["b"] = v232,
					["rest"] = v229.CFrame * v230.CFrame:Inverse()
				}
				table.insert(v226, v233)
			else
				if not (v227:IsA("WeldConstraint") and (v227.Part0 and v227.Part1)) then
					continue
				end
				local v234 = v227.Part0
				local v235 = v227.Part1
				local v236 = {
					["a"] = v234,
					["b"] = v235,
					["rest"] = v234.CFrame:ToObjectSpace(v235.CFrame)
				}
				table.insert(v226, v236)
			end
		end
		local v237 = true
		local v238 = {
			[v225] = true
		}
		while v237 do
			v237 = false
			for _, v239 in v226 do
				if v238[v239.a] and not v238[v239.b] then
					v239.b.CFrame = v239.a.CFrame * v239.rest
					v238[v239.b] = true
					v237 = true
				else
					if not v238[v239.b] or v238[v239.a] then
						continue
					end
					v239.a.CFrame = v239.b.CFrame * v239.rest:Inverse()
					v238[v239.a] = true
					v237 = true
				end
			end
		end
	end
end
local function v_u_247(p241, p242) -- name: petOnPodium
	-- upvalues: (copy) v_u_9, (copy) v_u_12, (copy) v_u_18
	local v243 = p241.CFrame * CFrame.new(0, p241.Size.Y / 2, 0)
	local _, v244 = v_u_9.showcase(p242, 2.2, v243, v_u_12.folder())
	local v245 = v_u_18.byId[p242]
	local v246
	if v245 and v245.look.glow then
		v246 = v_u_12.color(v245.look.glow)
	else
		v246 = Color3.fromRGB(255, 120, 30)
	end
	v_u_12.loop("Fire", p241, v246, 2, 0.3)
	return v244
end
local function v_u_342(p248, p_u_249) -- name: showcases
	-- upvalues: (copy) v_u_20, (copy) v_u_16, (copy) v_u_21, (copy) v_u_3, (copy) v_u_23, (copy) v_u_8, (copy) v_u_6, (copy) v_u_14, (copy) v_u_223, (copy) v_u_12, (copy) v_u_240, (copy) v_u_10, (copy) v_u_61, (copy) v_u_191, (copy) v_u_18, (copy) v_u_247
	local v250 = v_u_20.origin(p_u_249)
	local v_u_251 = v_u_16.showcaseFor(p_u_249)
	if v_u_251 then
		local v252 = string.upper((string.gsub(v_u_251.blurb, "%.$", "")))
		local v_u_253 = v250 + v_u_20.SHOWCASE_EYE
		local v_u_254 = v_u_21.mult(v_u_16.multIn(v_u_251, p_u_249)) .. " CHAKRA - " .. v252
		local v_u_255 = v_u_251.pass or ""
		local v_u_256 = false
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_253, (ref) v_u_20, (ref) v_u_256, (copy) v_u_255, (ref) v_u_8, (ref) v_u_6
			local v257 = v_u_23.Character
			if v257 then
				v257 = v257:FindFirstChild("HumanoidRootPart")
			end
			if v257 and v257:IsA("BasePart") then
				local v258 = v257.Position
				local v259 = Vector2.new(v258.X - v_u_253.X, v258.Z - v_u_253.Z).Magnitude <= v_u_20.SHOWCASE_REACH
				if v259 and (not v_u_256 and (v_u_23:GetAttribute("Pass_" .. v_u_255) ~= true and not v_u_8.active())) then
					v_u_6.buyPass(v_u_255)
				end
				v_u_256 = v259
			end
		end)
		local v_u_260 = "SPECIAL DEAL!"
		v_u_14.each(p248, "ShowcaseEye", function(p261)
			-- upvalues: (ref) v_u_223, (copy) v_u_260, (copy) v_u_251, (copy) v_u_254, (copy) v_u_255, (ref) v_u_12, (ref) v_u_23, (ref) v_u_240, (ref) v_u_16, (ref) v_u_10, (ref) v_u_61, (ref) v_u_191
			local v262
			if p261 then
				v262 = p261:FindFirstChild("Stand")
			else
				v262 = p261
			end
			if not (v262 and v262:IsA("BasePart")) then
				v262 = nil
			end
			local v_u_263 = v262 or p261:WaitForChild("Stand", 10)
			local v264
			if p261 then
				v264 = p261:FindFirstChild("Display")
			else
				v264 = p261
			end
			if not (v264 and v264:IsA("BasePart")) then
				v264 = nil
			end
			local v265 = v264 or p261:WaitForChild("Display", 10)
			if not (v_u_263 and (v_u_263:IsA("BasePart") and (v265 and v265:IsA("BasePart")))) then
				return nil
			end
			local v_u_266 = v_u_223(v265, v_u_260, string.upper(v_u_251.name), v_u_254, v_u_255, v_u_12.color(v_u_251.color), 1.6)
			local v_u_267 = v_u_251.id
			local v_u_268 = false
			local v_u_269 = nil
			local v_u_270 = nil
			local function v_u_271() -- name: cleanup
				-- upvalues: (ref) v_u_268, (ref) v_u_270, (ref) v_u_269
				v_u_268 = true
				if v_u_270 then
					v_u_270()
					v_u_270 = nil
				end
				if v_u_269 then
					v_u_269:Destroy()
					v_u_269 = nil
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (ref) v_u_268, (ref) v_u_240, (copy) v_u_263, (ref) v_u_12, (ref) v_u_269, (ref) v_u_16, (copy) v_u_267, (ref) v_u_270, (ref) v_u_10, (ref) v_u_61
				local v272 = v_u_23.Character or v_u_23.CharacterAdded:Wait()
				v272:WaitForChild("HumanoidRootPart", 10)
				task.wait(1)
				if v_u_268 then
					return
				else
					v272.Archivable = true
					local v273 = v272:Clone()
					v272.Archivable = false
					if v273 then
						for _, v274 in v273:GetDescendants() do
							if v274:IsA("LuaSourceContainer") or (v274:IsA("Sound") or v274:GetAttribute("FormExtra") == true) then
								v274:Destroy()
							else
								if not v274:IsA("BasePart") then
									continue
								end
								v274.Anchored = true
								v274.CanCollide = false
								v274.CanQuery = false
								v274.CanTouch = false
							end
						end
						v_u_240(v273)
						local v275 = v273:FindFirstChildOfClass("Humanoid")
						if v275 then
							v275.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
						end
						v273.Name = "ShowcaseAvatar"
						v273:ScaleTo(1.6)
						local _, v276 = v273:GetBoundingBox()
						local v277 = v_u_263.CFrame * CFrame.new(0, v_u_263.Size.Y / 2 + v276.Y / 2, 0)
						v273:PivotTo(v277)
						v273.Parent = v_u_12.folder()
						v_u_269 = v273
						local v278 = v_u_16.byId[v_u_267]
						local v279
						if v278 then
							v279 = v_u_12.color(v278.color)
						else
							v279 = Color3.new(1, 0, 0)
						end
						v_u_270 = v_u_10.dressModel(v273, v_u_267)
						local v280 = v_u_263.Position
						local v281 = v_u_263.Size.Y / 2 + 0.2
						local v282 = v280 + Vector3.new(0, v281, 0)
						while not v_u_268 do
							local v283 = os.clock()
							local v284 = CFrame.Angles
							local v285 = v283 * 0.6
							v273:PivotTo(v277 * v284(0, math.sin(v285) * 0.9, 0))
							local v286 = v283 * 30
							if math.floor(v286) % 75 == 0 then
								v_u_12.burst("Flash", v277.Position + Vector3.new(0, 2, 0), v279, 1.2)
								v_u_12.ring(v282, v279, 9, 0.8)
							end
							task.wait(v_u_61(v273))
						end
					end
				end
			end)
			local v_u_287 = v_u_191(v_u_263, v_u_255, v_u_251.name)
			return function()
				-- upvalues: (copy) v_u_266, (copy) v_u_271, (copy) v_u_287
				v_u_266()
				v_u_271()
				v_u_287()
			end
		end)
	end
	local v_u_288 = v_u_16.everyWorldShowcase()
	if v_u_288 then
		local v_u_289 = v250 + v_u_20.SHOWCASE_EYE_ALL
		local v_u_290 = v_u_21.mult(v_u_16.multIn(v_u_288, p_u_249)) .. " CHAKRA - THE STRONGEST EYE"
		local v_u_291 = v_u_288.pass or ""
		local v_u_292 = false
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_289, (ref) v_u_20, (ref) v_u_292, (copy) v_u_291, (ref) v_u_8, (ref) v_u_6
			local v293 = v_u_23.Character
			if v293 then
				v293 = v293:FindFirstChild("HumanoidRootPart")
			end
			if v293 and v293:IsA("BasePart") then
				local v294 = v293.Position
				local v295 = Vector2.new(v294.X - v_u_289.X, v294.Z - v_u_289.Z).Magnitude <= v_u_20.SHOWCASE_REACH
				if v295 and (not v_u_292 and (v_u_23:GetAttribute("Pass_" .. v_u_291) ~= true and not v_u_8.active())) then
					v_u_6.buyPass(v_u_291)
				end
				v_u_292 = v295
			end
		end)
		local v_u_296 = "NEW EYE!"
		v_u_14.each(p248, "ShowcaseEyeAll", function(p297)
			-- upvalues: (ref) v_u_223, (copy) v_u_296, (copy) v_u_288, (copy) v_u_290, (copy) v_u_291, (ref) v_u_12, (ref) v_u_23, (ref) v_u_240, (ref) v_u_16, (ref) v_u_10, (ref) v_u_61, (ref) v_u_191
			local v298
			if p297 then
				v298 = p297:FindFirstChild("Stand")
			else
				v298 = p297
			end
			if not (v298 and v298:IsA("BasePart")) then
				v298 = nil
			end
			local v_u_299 = v298 or p297:WaitForChild("Stand", 10)
			local v300
			if p297 then
				v300 = p297:FindFirstChild("Display")
			else
				v300 = p297
			end
			if not (v300 and v300:IsA("BasePart")) then
				v300 = nil
			end
			local v301 = v300 or p297:WaitForChild("Display", 10)
			if not (v_u_299 and (v_u_299:IsA("BasePart") and (v301 and v301:IsA("BasePart")))) then
				return nil
			end
			local v_u_302 = v_u_223(v301, v_u_296, string.upper(v_u_288.name), v_u_290, v_u_291, v_u_12.color(v_u_288.color), 1.6)
			local v_u_303 = v_u_288.id
			local v_u_304 = false
			local v_u_305 = nil
			local v_u_306 = nil
			local function v_u_307() -- name: cleanup
				-- upvalues: (ref) v_u_304, (ref) v_u_306, (ref) v_u_305
				v_u_304 = true
				if v_u_306 then
					v_u_306()
					v_u_306 = nil
				end
				if v_u_305 then
					v_u_305:Destroy()
					v_u_305 = nil
				end
			end
			task.spawn(function()
				-- upvalues: (ref) v_u_23, (ref) v_u_304, (ref) v_u_240, (copy) v_u_299, (ref) v_u_12, (ref) v_u_305, (ref) v_u_16, (copy) v_u_303, (ref) v_u_306, (ref) v_u_10, (ref) v_u_61
				local v308 = v_u_23.Character or v_u_23.CharacterAdded:Wait()
				v308:WaitForChild("HumanoidRootPart", 10)
				task.wait(1)
				if v_u_304 then
					return
				else
					v308.Archivable = true
					local v309 = v308:Clone()
					v308.Archivable = false
					if v309 then
						for _, v310 in v309:GetDescendants() do
							if v310:IsA("LuaSourceContainer") or (v310:IsA("Sound") or v310:GetAttribute("FormExtra") == true) then
								v310:Destroy()
							else
								if not v310:IsA("BasePart") then
									continue
								end
								v310.Anchored = true
								v310.CanCollide = false
								v310.CanQuery = false
								v310.CanTouch = false
							end
						end
						v_u_240(v309)
						local v311 = v309:FindFirstChildOfClass("Humanoid")
						if v311 then
							v311.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
						end
						v309.Name = "ShowcaseAvatar"
						v309:ScaleTo(1.6)
						local _, v312 = v309:GetBoundingBox()
						local v313 = v_u_299.CFrame * CFrame.new(0, v_u_299.Size.Y / 2 + v312.Y / 2, 0)
						v309:PivotTo(v313)
						v309.Parent = v_u_12.folder()
						v_u_305 = v309
						local v314 = v_u_16.byId[v_u_303]
						local v315
						if v314 then
							v315 = v_u_12.color(v314.color)
						else
							v315 = Color3.new(1, 0, 0)
						end
						v_u_306 = v_u_10.dressModel(v309, v_u_303)
						local v316 = v_u_299.Position
						local v317 = v_u_299.Size.Y / 2 + 0.2
						local v318 = v316 + Vector3.new(0, v317, 0)
						while not v_u_304 do
							local v319 = os.clock()
							local v320 = CFrame.Angles
							local v321 = v319 * 0.6
							v309:PivotTo(v313 * v320(0, math.sin(v321) * 0.9, 0))
							local v322 = v319 * 30
							if math.floor(v322) % 75 == 0 then
								v_u_12.burst("Flash", v313.Position + Vector3.new(0, 2, 0), v315, 1.2)
								v_u_12.ring(v318, v315, 9, 0.8)
							end
							task.wait(v_u_61(v309))
						end
					end
				end
			end)
			local v_u_323 = v_u_191(v_u_299, v_u_291, v_u_288.name)
			return function()
				-- upvalues: (copy) v_u_302, (copy) v_u_307, (copy) v_u_323
				v_u_302()
				v_u_307()
				v_u_323()
			end
		end)
	end
	for v324, v_u_325 in v_u_18.showcasesFor(p_u_249) do
		local v326
		if v324 == 1 then
			v326 = v_u_20.SHOWCASE_PET
		else
			v326 = v_u_20.SHOWCASE_PET2
		end
		local v327 = v324 == 1 and "ShowcasePet" or "ShowcasePet" .. v324
		local v_u_328 = v250 + v326
		local v_u_329 = v_u_325.pass or "kurama"
		local v_u_330 = false
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_23, (copy) v_u_328, (ref) v_u_20, (ref) v_u_330, (copy) v_u_329, (ref) v_u_8, (ref) v_u_6
			local v331 = v_u_23.Character
			if v331 then
				v331 = v331:FindFirstChild("HumanoidRootPart")
			end
			if v331 and v331:IsA("BasePart") then
				local v332 = v331.Position
				local v333 = Vector2.new(v332.X - v_u_328.X, v332.Z - v_u_328.Z).Magnitude <= v_u_20.SHOWCASE_REACH
				if v333 and (not v_u_330 and (v_u_23:GetAttribute("Pass_" .. v_u_329) ~= true and not v_u_8.active())) then
					v_u_6.buyPass(v_u_329)
				end
				v_u_330 = v333
			end
		end)
		v_u_14.each(p248, v327, function(p334)
			-- upvalues: (ref) v_u_223, (copy) v_u_325, (ref) v_u_21, (ref) v_u_18, (copy) p_u_249, (ref) v_u_247, (ref) v_u_191
			local v335
			if p334 then
				v335 = p334:FindFirstChild("Stand")
			else
				v335 = p334
			end
			if not (v335 and v335:IsA("BasePart")) then
				v335 = nil
			end
			local v336 = v335 or p334:WaitForChild("Stand", 10)
			local v337
			if p334 then
				v337 = p334:FindFirstChild("Display")
			else
				v337 = p334
			end
			if not (v337 and v337:IsA("BasePart")) then
				v337 = nil
			end
			local v338 = v337 or p334:WaitForChild("Display", 10)
			if not (v336 and (v336:IsA("BasePart") and (v338 and v338:IsA("BasePart")))) then
				return nil
			end
			local v_u_339 = v_u_223(v338, "SPECIAL PET!", string.upper(v_u_325.name), v_u_21.mult(v_u_18.multIn(v_u_325, p_u_249)) .. " CHAKRA", v_u_325.pass or "kurama", Color3.fromRGB(255, 120, 30), 1)
			local v_u_340 = v_u_247(v336, v_u_325.id)
			local v_u_341 = v_u_191(v336, v_u_325.pass or "kurama", v_u_325.name)
			return function()
				-- upvalues: (copy) v_u_339, (copy) v_u_340, (copy) v_u_341
				v_u_339()
				v_u_340()
				v_u_341()
			end
		end)
	end
end
local function v_u_373(p343, p344) -- name: eggs
	-- upvalues: (copy) v_u_18, (copy) v_u_14, (copy) v_u_42, (copy) v_u_32, (copy) v_u_12, (copy) v_u_57, (copy) v_u_33, (copy) v_u_21, (copy) v_u_6, (copy) v_u_26, (copy) v_u_173, (copy) v_u_157, (copy) v_u_61
	for v_u_345, v_u_346 in v_u_18.eggsFor(p344) do
		v_u_14.each(p343, "Egg" .. v_u_345, function(p347)
			-- upvalues: (ref) v_u_42, (copy) v_u_346, (ref) v_u_32, (ref) v_u_12, (ref) v_u_57, (ref) v_u_33, (ref) v_u_21, (ref) v_u_6, (ref) v_u_26, (ref) v_u_173, (ref) v_u_157, (copy) v_u_345, (ref) v_u_61
			p347 = p347
			local v348
			if p347 then
				v348 = p347:FindFirstChild("Display")
			else
				v348 = p347
			end
			if not (v348 and v348:IsA("BasePart")) then
				v348 = nil
			end
			local v349 = v348 or p347:WaitForChild("Display", 10)
			if not (v349 and v349:IsA("BasePart")) then
				return nil
			end
			local v_u_350 = true
			local v_u_351 = Instance.new("BillboardGui")
			v_u_351.Adornee = v349
			v_u_351.Size = UDim2.fromScale(10.5, 4.6)
			v_u_351.StudsOffsetWorldSpace = Vector3.new(0, 5, 0)
			v_u_351.LightInfluence = 0
			v_u_351.MaxDistance = 220
			v_u_351.Parent = v349
			v_u_351.Name = "Sign"
			local v352 = v_u_42(v_u_351, "Name", string.upper(v_u_346.name), UDim2.fromScale(1, 0.45), UDim2.fromScale(0.5, 0.25), v_u_32)
			local v353 = v_u_12.color(v_u_346.color)
			local v354 = v353:Lerp(v_u_32, 0.5)
			local v355 = v353:Lerp(Color3.fromRGB(255, 200, 60), 0.3)
			local v356 = Instance.new("UIGradient")
			v356.Color = ColorSequence.new(v354, v355)
			v356.Rotation = 90
			v356.Parent = v352
			local v357, v358 = v_u_57(v_u_351, "Cost", v_u_33, UDim2.fromScale(1, 0.42), UDim2.fromScale(0.5, 0.75))
			v357.Text = v_u_21.short(v_u_346.cost)
			v357.TextColor3 = Color3.fromRGB(255, 230, 120)
			if v_u_346.product then
				local v359 = v_u_6.product(v_u_346.product .. "1")
				v358.Visible = false
				local v360 = v_u_6.ROBUX
				local v361 = not v359 and "?" or v359.price
				v357.Text = v360 .. " " .. tostring(v361)
				v357.TextColor3 = v_u_26
			end
			local v_u_362
			if v_u_346.tag then
				v_u_362 = Instance.new("BillboardGui")
				v_u_362.Adornee = v349
				v_u_362.Size = UDim2.fromScale(12, 3.4)
				v_u_362.StudsOffsetWorldSpace = Vector3.new(0, 9.6, 0)
				v_u_362.LightInfluence = 0
				v_u_362.MaxDistance = 220
				v_u_362.Parent = v349
				v_u_362.Name = "Tag"
				v_u_173(v_u_362, v_u_346.tag, UDim2.fromScale(1, 1), UDim2.fromScale(0.5, 0.5), v_u_157)
			else
				v_u_362 = nil
			end
			local v_u_363 = p347:FindFirstChild("EggModel")
			if v_u_363 and v_u_363:IsA("Model") then
				local v_u_364 = v_u_363:GetPivot()
				task.spawn(function()
					-- upvalues: (ref) v_u_350, (ref) v_u_345, (copy) v_u_363, (copy) v_u_364, (ref) v_u_61
					while v_u_350 do
						local v365 = os.clock() + v_u_345
						local v366 = v_u_363
						local v367 = v_u_364
						local v368 = CFrame.new
						local v369 = v365 * 2
						local v370 = v367 * v368(0, math.sin(v369) * 0.35, 0)
						local v371 = CFrame.Angles
						local v372 = v365 * 0.8
						v366:PivotTo(v370 * v371(0, math.sin(v372) * 0.5, 0))
						task.wait(v_u_61(v_u_363))
					end
				end)
			end
			return function()
				-- upvalues: (ref) v_u_350, (copy) v_u_351, (ref) v_u_362
				v_u_350 = false
				v_u_351:Destroy()
				if v_u_362 then
					v_u_362:Destroy()
				end
			end
		end)
	end
end
local function v_u_427(p374) -- name: freeRewards
	-- upvalues: (copy) v_u_14, (copy) v_u_23, (copy) v_u_4, (copy) v_u_20, (copy) v_u_12, (copy) v_u_61
	v_u_14.each(p374, "FreeRewards", function(p375)
		-- upvalues: (ref) v_u_14, (ref) v_u_23, (ref) v_u_4, (ref) v_u_20, (ref) v_u_12, (ref) v_u_61
		local v_u_376 = true
		local v377, v_u_378 = v_u_14.bag()
		local v_u_379 = p375:FindFirstChild("Gift")
		local v_u_380 = p375:FindFirstChild("Title", true)
		if v_u_379 and v_u_379:IsA("Model") then
			local v_u_381 = v_u_379:GetPivot()
			local v_u_382 = (-1 / 0)
			local v383 = v_u_23:GetAttributeChangedSignal("GroupClaimed")
			local function v391()
				-- upvalues: (ref) v_u_23, (ref) v_u_4, (copy) v_u_381, (ref) v_u_382, (ref) v_u_20, (ref) v_u_12
				if v_u_23:GetAttribute("GroupClaimed") == true then
					local v384 = v_u_4.CurrentCamera
					local v385 = v_u_381.Position
					if v384 and (v384.CFrame.Position - v385).Magnitude <= 120 then
						v_u_382 = os.clock()
						local v386 = Color3.fromRGB(142, 77, 255)
						local v387 = v385.X
						local v388 = v_u_20.FLOOR_Y + 0.3
						local v389 = v385.Z
						local v390 = Vector3.new(v387, v388, v389)
						v_u_12.flash(v385, v386, 16, 0.4)
						v_u_12.burst("Flash", v385, v386, 1.4)
						v_u_12.burst("Sparkle", v385, nil, 1.6)
						v_u_12.burst("Shockwave", v390, v386, 1.2)
						v_u_12.ring(v390, v386, 18, 0.7)
						v_u_12.shake(0.25, 0.4)
					end
				else
					return
				end
			end
			table.insert(v377, v383:Connect(v391))
			task.spawn(function()
				-- upvalues: (ref) v_u_376, (ref) v_u_382, (copy) v_u_379, (copy) v_u_381, (ref) v_u_61
				while v_u_376 do
					local v392 = os.clock()
					local v393 = (v392 - v_u_382) / 0.9
					local v394 = math.clamp(v393, 0, 1)
					local v395 = v394 * 3.141592653589793
					local v396 = math.sin(v395) * 3
					local v397 = (1 - v394) * (1 - v394) * 12
					local v398 = v_u_379
					local v399 = v_u_381
					local v400 = CFrame.new
					local v401 = v392 * 2.4
					v398:PivotTo(v399 * v400(0, math.sin(v401) * 0.5 + 0.6 + v396, 0) * CFrame.Angles(0, v392 * 0.9 + v397, 0))
					task.wait(v394 < 1 and 0 or v_u_61(v_u_379))
				end
			end)
		end
		local v_u_402 = p375:FindFirstChild("Orbs")
		if v_u_402 and v_u_402:IsA("Model") then
			local v_u_403 = {}
			for _, v404 in v_u_402:GetChildren() do
				if not v404:IsA("BasePart") then
					continue
				end
				table.insert(v_u_403, v404)
			end
			if #v_u_403 > 0 then
				local v_u_405 = v_u_402:GetBoundingBox().Position
				local v406 = v_u_403[1].Position
				local v_u_407 = Vector2.new(v406.X - v_u_405.X, v406.Z - v_u_405.Z).Magnitude
				local v_u_408 = table.create(#v_u_403)
				task.spawn(function()
					-- upvalues: (ref) v_u_376, (copy) v_u_403, (copy) v_u_408, (copy) v_u_405, (copy) v_u_407, (ref) v_u_4, (ref) v_u_61, (copy) v_u_402
					while v_u_376 do
						local v409 = os.clock()
						for v410, _ in v_u_403 do
							local v411 = (v410 - 1) / #v_u_403 * 3.141592653589793 * 2 + v409 * 0.7
							local v412 = v_u_408
							local v413 = CFrame.new
							local v414 = v_u_405
							local v415 = math.cos(v411) * v_u_407
							local v416 = v409 * 1.8 + v410
							local v417 = math.sin(v416) * 0.45
							local v418 = math.sin(v411) * v_u_407
							v412[v410] = v413(v414 + Vector3.new(v415, v417, v418))
						end
						v_u_4:BulkMoveTo(v_u_403, v_u_408, Enum.BulkMoveMode.FireCFrameChanged)
						task.wait(v_u_61(v_u_402))
					end
				end)
			end
		end
		if v_u_380 and v_u_380:IsA("BillboardGui") then
			local v_u_419 = v_u_380:FindFirstChildWhichIsA("TextLabel", true)
			local v_u_420 = Instance.new("UIScale")
			v_u_420.Parent = v_u_419 or v_u_380
			task.spawn(function()
				-- upvalues: (ref) v_u_376, (copy) v_u_420, (copy) v_u_419, (ref) v_u_61, (copy) v_u_380
				while v_u_376 do
					local v421 = os.clock()
					local v422 = v_u_420
					local v423 = v421 * 3
					local v424 = math.sin(v423)
					v422.Scale = math.abs(v424) * 0.12 + 1
					if v_u_419 then
						local v425 = v_u_419
						local v426 = v421 * 2
						v425.Rotation = math.sin(v426) * 4
					end
					task.wait(v_u_61(v_u_380))
				end
			end)
		end
		return function()
			-- upvalues: (ref) v_u_376, (copy) v_u_378
			v_u_376 = false
			v_u_378()
		end
	end)
end
local function v_u_443() -- name: proximity
	-- upvalues: (copy) v_u_5, (copy) v_u_3, (copy) v_u_23, (copy) v_u_20, (copy) v_u_6, (copy) v_u_18
	local v_u_428 = 0
	local v_u_429 = 1
	local v_u_430 = false
	v_u_5.onHatchDone(function()
		-- upvalues: (ref) v_u_428, (ref) v_u_5, (ref) v_u_429
		if v_u_428 > 0 and v_u_5.current() == nil then
			v_u_5.openEgg(v_u_428, v_u_429)
		end
	end)
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_23, (ref) v_u_20, (ref) v_u_6, (ref) v_u_18, (ref) v_u_429, (ref) v_u_428, (ref) v_u_5, (ref) v_u_430
		local v431 = v_u_23.Character
		if v431 then
			v431 = v431:FindFirstChild("HumanoidRootPart")
		end
		if v431 and v431:IsA("BasePart") then
			local v432 = v_u_20.worldAt(v431.Position)
			local v433 = v431.Position - v_u_20.origin(v432)
			local v434 = 0
			for v435, v436 in v_u_20.EGGS do
				if Vector2.new(v433.X - v436.X, v433.Z - v436.Z).Magnitude > v_u_20.EGG_REACH then
					continue
				end
				local v437 = v433.Y - v436.Y
				if math.abs(v437) >= 12 then
					continue
				end
				v434 = v435
			end
			if v434 > 0 and v_u_6.randomRestricted() then
				local v438 = v_u_18.STANDS[v432] or v_u_18.STANDS[1]
				local v439 = v_u_18.eggById[v438[v434] or ""]
				v434 = v439 and v439.product and 0 or v434
			end
			v_u_429 = v432
			if v434 ~= v_u_428 then
				if v434 > 0 then
					v_u_5.openEgg(v434, v432)
				else
					v_u_5.leaveEgg()
				end
				v_u_428 = v434
			end
			local v440 = v_u_20.FREE_REWARD
			local v441
			if Vector2.new(v433.X - v440.X, v433.Z - v440.Z).Magnitude <= v_u_20.FREE_REWARD_RADIUS then
				local v442 = v433.Y - v440.Y
				v441 = math.abs(v442) < 10
			else
				v441 = false
			end
			if v441 and not v_u_430 then
				v_u_5.openCommunity()
			end
			v_u_430 = v441
		end
	end)
end
function v22.start() -- name: start
	-- upvalues: (copy) v_u_20, (copy) v_u_4, (copy) v_u_103, (copy) v_u_156, (copy) v_u_373, (copy) v_u_427, (copy) v_u_342, (copy) v_u_443
	for v_u_444 in v_u_20.ORIGINS do
		if not v_u_20.mapLive(v_u_444) then
			continue
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_444, (ref) v_u_4, (ref) v_u_103, (ref) v_u_156, (ref) v_u_373, (ref) v_u_427, (ref) v_u_342
			local v445 = v_u_444 == 1 and "Map" or "Map" .. v_u_444
			local v446 = v_u_4:WaitForChild(v445, 60)
			if v446 then
				v446 = v446:WaitForChild("Hub", 30)
			end
			if v446 then
				task.wait()
				task.spawn(v_u_103, v446, v_u_444)
				task.wait()
				task.spawn(v_u_156, v446, v_u_444)
				task.wait()
				task.spawn(v_u_373, v446, v_u_444)
				task.wait()
				task.spawn(v_u_427, v446)
				task.wait()
				task.spawn(v_u_342, v446, v_u_444)
			else
				warn("[HubView] Workspace." .. v445 .. ".Hub is missing")
			end
		end)
	end
	v_u_443()
end
return v22