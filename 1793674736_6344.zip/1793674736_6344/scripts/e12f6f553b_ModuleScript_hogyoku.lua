local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Bars)
local v_u_6 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v7 = require(script.Parent.Parent.Preload)
local v_u_8 = require(script.Parent.Parent.Parent.Sfx)
local v_u_9 = require(v3.Shared.Config.Textures)
v7.images({ v_u_9.HogyokuWing, v_u_9.Ring, v_u_9.FxTwinkle })
local v_u_10 = Color3.fromHex("B05CFF")
local v_u_11 = Color3.fromRGB(78, 18, 150)
local v_u_12 = Color3.fromRGB(226, 196, 255)
local v_u_13 = Color3.fromRGB(246, 240, 255)
local v_u_14 = Color3.fromRGB(40, 32, 44)
local v_u_15 = Color3.new(1, 1, 1)
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = Enum.Material.Neon
local function v_u_49(p18, p19, p20, p21, p22, p23, p24, p25, p26, p27) -- name: groundPic
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v28 = p24 + p25 + p26
	local v29 = math.max(v28, 0.05)
	local v30 = {}
	local v31 = {}
	for v32 = 0, 12 do
		local v33 = v32 / 12
		local v34 = v33 * v29
		local v35 = v34 / math.max(p24, 0.001)
		local v36 = math.clamp(v35, 0, 1) - 1
		local v37 = v36 * 2.7 * v36 * v36 + 1 + v36 * 1.7 * v36
		local v38 = (v34 - p24 - p25) / math.max(p26, 0.001)
		local v39 = math.clamp(v38, 0, 1)
		local v40 = v39 * v39 * (3 - v39 * 2)
		local v41 = NumberSequenceKeypoint.new
		local v42 = p19 + (p20 - p19) * v37 + p20 * 0.1 * v40
		local v43 = math.max(v42, 0.05) / 2
		table.insert(v31, v41(v33, v43))
		local v44 = NumberSequenceKeypoint.new
		local v45 = p23 + (1 - p23) * v40
		local v46 = math.clamp(v45, 0, 1)
		table.insert(v30, v44(v33, v46))
	end
	local v47 = Instance.new("Attachment")
	v47.WorldPosition = p18
	v47.Parent = v_u_4.Terrain
	local v48 = Instance.new("ParticleEmitter")
	v48.Enabled = false
	v48.Texture = p21
	v48.Color = ColorSequence.new(p22)
	v48.LightEmission = 0
	v48.LightInfluence = 0
	v48.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v48.EmissionDirection = Enum.NormalId.Top
	v48.SpreadAngle = Vector2.zero
	v48.Speed = NumberRange.new(0.01)
	v48.Size = NumberSequence.new(v31)
	v48.Transparency = NumberSequence.new(v30)
	v48.Lifetime = NumberRange.new(v29)
	v48.Rotation = NumberRange.new(0, 360)
	v48.RotSpeed = NumberRange.new((math.deg(p27)))
	v48.Parent = v47
	v48:Emit(1)
	v_u_1:AddItem(v47, v29 + 0.2)
end
local function v_u_57(p50, p51, p52, p53, p54) -- name: ringBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_1
	local v55 = Instance.new("Attachment")
	v55.WorldPosition = p50
	v55.Parent = v_u_4.Terrain
	local v56 = Instance.new("ParticleEmitter")
	v56.Enabled = false
	v56.Texture = v_u_9.Ring
	v56.Color = ColorSequence.new(p53)
	v56.LightEmission = 0.3
	v56.LightInfluence = 0
	v56.Size = NumberSequence.new(p51 / 2, p52 / 2)
	v56.Transparency = NumberSequence.new(0, 1)
	v56.Lifetime = NumberRange.new(p54)
	v56.Speed = NumberRange.new(0)
	v56.ZOffset = 1
	v56.Parent = v55
	v56:Emit(1)
	v_u_1:AddItem(v55, p54 + 0.2)
end
local function v_u_65(p58, p59, p60, p61, p62) -- name: motes
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_12, (copy) v_u_10, (copy) v_u_1
	if p59 > 0 then
		local v63 = Instance.new("Attachment")
		v63.WorldPosition = p58
		v63.Parent = v_u_4.Terrain
		local v64 = Instance.new("ParticleEmitter")
		v64.Enabled = false
		v64.Texture = v_u_9.FxTwinkle
		v64.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v64.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		v64.Color = ColorSequence.new(v_u_12, v_u_10)
		v64.LightEmission = 0.45
		v64.LightInfluence = 0
		v64.Size = NumberSequence.new(p60)
		v64.Lifetime = NumberRange.new(p62 * 0.6, p62)
		v64.Speed = NumberRange.new(p61 * 0.3, p61)
		v64.SpreadAngle = Vector2.new(180, 180)
		v64.Drag = 2
		v64.Acceleration = Vector3.new(0, 2, 0)
		v64.Rotation = NumberRange.new(0, 45)
		v64.Parent = v63
		v64:Emit(p59)
		v_u_1:AddItem(v63, p62 + 0.3)
	end
end
local function v_u_74(p66, p67, p68, p69, p70, p_u_71) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_15, (copy) v_u_1
	local v_u_72 = Instance.new("ColorCorrectionEffect")
	v_u_72.Name = "Hogyoku"
	v_u_72.Parent = v_u_2
	v_u_6.tween(v_u_72, p69, {
		["TintColor"] = p66,
		["Brightness"] = p67,
		["Saturation"] = p68
	})
	task.delay(p69 + p70, function()
		-- upvalues: (ref) v_u_6, (copy) v_u_72, (copy) p_u_71, (ref) v_u_15
		local v73 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_15
		}
		v_u_6.tween(v_u_72, p_u_71, v73)
	end)
	v_u_1:AddItem(v_u_72, p69 + p70 + p_u_71 + 0.1)
end
local function v_u_83(p75, p76, p77, p78) -- name: newWing
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_1, (copy) v_u_9, (copy) v_u_12
	local v79 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p75), v_u_10, {
		["transparency"] = 1
	})
	v_u_1:AddItem(v79, p78)
	local v80 = Instance.new("Attachment")
	v80.Parent = v79
	local v81 = Instance.new("Attachment")
	v81.Parent = v79
	v81.WorldPosition = p76
	local v82 = Instance.new("Beam")
	v82.Attachment0 = v80
	v82.Attachment1 = v81
	v82.Texture = v_u_9.HogyokuWing
	v82.TextureMode = Enum.TextureMode.Stretch
	v82.TextureLength = 1
	v82.Color = ColorSequence.new(v_u_10, v_u_12)
	v82.LightEmission = 0.35
	v82.LightInfluence = 0
	v82.FaceCamera = true
	v82.Segments = 10
	v82.Width0 = p77
	v82.Width1 = p77
	v82.Parent = v79
	return {
		["holder"] = v79,
		["root"] = v80,
		["tip"] = v81,
		["beam"] = v82
	}
end
return function(p_u_84)
	-- upvalues: (copy) v_u_6, (copy) v_u_10, (copy) v_u_12, (copy) v_u_14, (copy) v_u_16, (copy) v_u_11, (copy) v_u_9, (copy) v_u_57, (copy) v_u_4, (copy) v_u_5, (copy) v_u_65, (copy) v_u_13, (copy) v_u_83, (copy) v_u_1, (copy) v_u_17, (copy) v_u_49, (copy) v_u_8, (copy) v_u_74
	local v112 = {
		["hogyoku_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["weave"] = 0.4,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p85) -- name: cast
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_57, (ref) v_u_12
				local v86 = p85.size
				local v87 = p85.eye + p85.dir * 1.1
				v_u_6.flash(v87, v_u_10, 2.6 * v86, 0.1)
				v_u_57(v87, 0.6 * v86, 2.4 * v86, v_u_12, 0.18)
			end,
			["shot"] = function(p88, p89) -- name: pulseShot
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_12, (ref) v_u_14, (ref) v_u_16, (copy) p_u_84, (ref) v_u_11, (ref) v_u_9
				local v90 = p88.size
				local v91 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), p89, v_u_10, {
					["transparency"] = 1
				})
				local v92 = v_u_6.part(Vector3.new(0.85, 0.85, 0.85) * v90, p89, v_u_10, {
					["shape"] = Enum.PartType.Ball
				})
				local v93 = v_u_6.part(Vector3.new(1.5, 1.5, 1.5) * v90, p89, v_u_12, {
					["shape"] = nil,
					["transparency"] = 0.7,
					["shape"] = Enum.PartType.Ball
				})
				local v94 = {
					{
						["p"] = v92,
						["off"] = CFrame.identity
					},
					{
						["p"] = v93,
						["off"] = CFrame.identity
					}
				}
				for v95 = 0, 3 do
					local v96 = v_u_6.part
					local v97 = 0.16 * v90
					local v98 = 0.6 * v90
					local v99 = 0.16 * v90
					local v100 = {
						["p"] = v96(Vector3.new(v97, v98, v99), p89, v_u_14, {
							["material"] = v_u_16
						}),
						["off"] = CFrame.Angles(0, 0, v95 * 3.141592653589793 / 2) * CFrame.new(0, 0.62 * v90, 0)
					}
					table.insert(v94, v100)
				end
				p_u_84.streak(v91, v_u_10, v_u_11, 0.7 * v90, 0.12)
				local v101 = {}
				if not p88.lite then
					p_u_84.light(v91, v_u_10, 8 * v90)
					local v102 = Instance.new("Attachment")
					v102.Parent = v91
					local v_u_103 = Instance.new("ParticleEmitter")
					v_u_103.Texture = v_u_9.Ring
					v_u_103.Color = ColorSequence.new(v_u_10, v_u_11)
					v_u_103.LightEmission = 0.3
					v_u_103.LightInfluence = 0
					v_u_103.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
					v_u_103.EmissionDirection = Enum.NormalId.Front
					v_u_103.SpreadAngle = Vector2.zero
					v_u_103.Speed = NumberRange.new(0.05)
					v_u_103.Size = NumberSequence.new(1.8 * v90, 0.25 * v90)
					v_u_103.Transparency = NumberSequence.new(0.05, 1)
					v_u_103.Lifetime = NumberRange.new(0.42)
					v_u_103.Rate = 22
					v_u_103.Parent = v102
					table.insert(v101, function()
						-- upvalues: (copy) v_u_103
						v_u_103.Enabled = false
					end)
				end
				return p_u_84.assemble(v91, v94, {}, 0, 0, v101, 0.12, 9)
			end,
			["impact"] = function(p104, p105) -- name: pulseBurst
				-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_57, (ref) v_u_4, (ref) v_u_5, (ref) v_u_12, (ref) v_u_65
				local v106 = p104.size
				v_u_6.flash(p105, v_u_10, 3.6 * v106, 0.14)
				v_u_57(p105, 1.2 * v106, 6 * v106, v_u_10, 0.32)
				local v107 = v_u_4.CurrentCamera
				if v107 and not p104.lite then
					local v108 = v107.CFrame
					for v109 = 0, 3 do
						local v110 = v109 * 3.141592653589793 / 2 + 0.7853981633974483
						local v111 = v108.RightVector * math.cos(v110) + v108.UpVector * math.sin(v110)
						v_u_5.thin(v_u_5.rod(p105, p105 + v111 * 3.2 * v106, 0.22 * v106, v_u_12), 0.2)
					end
					v_u_65(p105, 5, 0.5 * v106, 9 * v106, 0.6)
				end
			end,
			["hit"] = p_u_84.simpleHit(v_u_10, 0.55)
		}
	}
	local v_u_113 = {}
	setmetatable(v_u_113, {
		["__mode"] = "k"
	})
	local function v_u_131(p114, p_u_115, p_u_116) -- name: hatch
		-- upvalues: (ref) v_u_6, (ref) v_u_10, (ref) v_u_57, (ref) v_u_12, (copy) p_u_84, (ref) v_u_13, (ref) v_u_65, (ref) v_u_4, (ref) v_u_83
		local v117 = p114.lite
		v_u_6.flash(p_u_115, v_u_10, p_u_116 * 1.2, 0.2)
		v_u_57(p_u_115, p_u_116 * 0.4, p_u_116 * 2, v_u_12, 0.4)
		p_u_84.chunks(p_u_115, { v_u_13, v_u_13, v_u_10 }, v117 and 3 or 8, 14, 0.5, 0.9, false, 0.7)
		if not v117 then
			v_u_65(p_u_115, 10, 0.6, 10, 1)
			for _, v118 in { -1, 1 } do
				local v119 = v_u_4.CurrentCamera
				local v120 = not v119 and Vector3.new(1, 0, 0) or v119.CFrame.RightVector
				local v_u_121 = v_u_83(p_u_115, p_u_115, p_u_116 * 0.45, 0.9)
				local v_u_122 = (v120 * v118 * 0.8 + Vector3.new(0, 1, 0)).Unit
				p_u_84.animate(0.8, 0, function(p123)
					-- upvalues: (copy) v_u_121, (copy) p_u_115, (copy) v_u_122, (copy) p_u_116
					local v124 = p123 / 0.35
					local v125 = math.clamp(v124, 0, 1) - 1
					local v126 = v125 * 2.7 * v125 * v125 + 1 + v125 * 1.7 * v125
					v_u_121.tip.WorldPosition = p_u_115 + v_u_122 * p_u_116 * 1.1 * math.max(v126, 0.02)
					local v127 = v_u_121.beam
					local v128 = NumberSequence.new
					local v129 = (p123 - 0.45) / 0.55
					local v130 = math.clamp(v129, 0, 1)
					v127.Transparency = v128(v130 * v130 * (3 - v130 * 2))
					if p123 >= 1 then
						v_u_121.holder:Destroy()
					end
				end)
			end
		end
	end
	local function v_u_184(p_u_132, p133, p134) -- name: cocoon
		-- upvalues: (ref) v_u_4, (copy) p_u_84, (ref) v_u_6, (ref) v_u_1, (ref) v_u_13, (ref) v_u_16, (ref) v_u_10, (ref) v_u_17, (copy) v_u_131
		local v_u_135 = p_u_132.ability.freeze or 3
		local v136 = v_u_4:FindFirstChild("MyEnemies")
		local v_u_137
		if v136 then
			v_u_137 = v136:FindFirstChild("Foe" .. p134)
		else
			v_u_137 = nil
		end
		local v_u_138, v_u_139
		if v_u_137 and v_u_137:IsA("Model") then
			local _, v140 = v_u_137:GetBoundingBox()
			local v141 = v140.Y * 1.15
			v_u_138 = math.clamp(v141, 4, 14)
			local v142 = v140.X
			local v143 = v140.Z
			local v144 = math.max(v142, v143) * 1.1
			v_u_139 = math.clamp(v144, 3, 9)
		else
			v_u_138 = 6
			v_u_139 = 3.4
		end
		local v_u_145 = p_u_84.ground(p133, 0)
		local function v151(p146, p147, p148) -- name: blob
			-- upvalues: (ref) v_u_6, (copy) v_u_145, (ref) v_u_1, (copy) v_u_135
			local v149 = v_u_6.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v_u_145), p146, {
				["material"] = p148,
				["transparency"] = p147
			})
			local v150 = Instance.new("SpecialMesh")
			v150.MeshType = Enum.MeshType.Sphere
			v150.Parent = v149
			v_u_1:AddItem(v149, v_u_135 + 1)
			return v149
		end
		local v_u_152 = v151(v_u_13, 0.12, v_u_16)
		local v_u_153 = v151(v_u_10, 0.35, v_u_17)
		local v_u_154 = {}
		for _ = 1, p_u_132.lite and 0 or 4 do
			local v155 = v151(v_u_10, 0, v_u_17)
			table.insert(v_u_154, v155)
		end
		local v_u_156 = math.random() * 3.141592653589793
		local v_u_157 = os.clock()
		p_u_84.runNow(function()
			-- upvalues: (copy) v_u_157, (copy) v_u_137, (copy) v_u_135, (copy) v_u_152, (copy) v_u_153, (copy) v_u_154, (ref) v_u_131, (copy) p_u_132, (copy) v_u_145, (ref) v_u_138, (ref) v_u_139, (copy) v_u_156
			local v158 = os.clock() - v_u_157
			local v159
			if v_u_137 == nil then
				v159 = false
			else
				v159 = v_u_137.Parent == nil
			end
			if v_u_135 <= v158 or v159 then
				v_u_152:Destroy()
				v_u_153:Destroy()
				for _, v160 in v_u_154 do
					v160:Destroy()
				end
				v_u_131(p_u_132, v_u_145 + Vector3.new(0, 1, 0) * v_u_138 * 0.5, v_u_138)
				return false
			end
			local v161 = v158 / 0.35
			local v162 = math.clamp(v161, 0, 1) - 1
			local v163 = v162 * 2.7 * v162 * v162 + 1 + v162 * 1.7 * v162
			local v164 = math.max(v163, 0.03)
			local v165 = v158 * 9
			local v166 = math.sin(v165) * 0.05 * math.min(v158, 1) + 1
			local v167 = v_u_138 * v164
			local v168 = v_u_145 + Vector3.new(0, 1, 0) * v167 * 0.5
			local v169 = v_u_139
			local v170 = v_u_139
			v_u_152.Size = Vector3.new(v169, v167, v170) * v166
			v_u_152.CFrame = CFrame.new(v168) * CFrame.Angles(0, v_u_156 + v158 * 0.4, 0)
			local v171 = v_u_153
			local v172 = v_u_139 * 0.86
			local v173 = v167 * 0.92
			local v174 = v_u_139 * 0.86
			v171.Size = Vector3.new(v172, v173, v174) * v166
			v_u_153.CFrame = v_u_152.CFrame
			local v175 = v_u_153
			local v176 = v158 * 9
			v175.Transparency = math.sin(v176) * 0.25 + 0.3
			for v177, v178 in v_u_154 do
				local v179 = v_u_156 + v158 * 0.4 + v177 * 3.141592653589793 * 2 / #v_u_154
				local v180 = v167 * 0.85
				v178.Size = Vector3.new(0.18, v180, 0.18) * v166
				local v181 = CFrame.new
				local v182 = math.cos(v179)
				local v183 = math.sin(v179)
				v178.CFrame = v181(v168 + Vector3.new(v182, 0, v183) * v_u_139 * 0.47 * v166) * CFrame.Angles(0, -v179, 0)
			end
			return true
		end)
		p_u_84.burst("Impact", p133, v_u_10, 0.6)
	end
	v112.hogyoku_e = {
		["cast"] = function(p185) -- name: cast
			-- upvalues: (copy) p_u_84, (ref) v_u_10, (ref) v_u_12
			local v186 = p185.size
			p_u_84.skillCast(p185, v_u_10, false, true)
			p_u_84.glint(p185.eye, v_u_12, 4 * v186, 0.2)
		end,
		["windup"] = function(p187, p188, p189) -- name: windup
			-- upvalues: (copy) p_u_84, (ref) v_u_13, (ref) v_u_6, (ref) v_u_10
			local v190 = p187.size
			local v191 = math.max(p189, 0.1)
			p_u_84.inward(p_u_84.ground(p188, 2), v_u_13, p187.lite and 4 or 10, 10 * v190, v191 + 0.05)
			v_u_6.flash(p_u_84.ground(p188, 2), v_u_10, 5 * v190, v191)
		end,
		["land"] = function(p_u_192, p193) -- name: land
			-- upvalues: (copy) p_u_84, (ref) v_u_49, (ref) v_u_9, (ref) v_u_11, (ref) v_u_6, (ref) v_u_10, (ref) v_u_1, (ref) v_u_65, (ref) v_u_8, (ref) v_u_12
			local v194 = p_u_192.size
			local v_u_195 = p_u_192.ability.radius * v194
			local v_u_196 = p_u_192.ability.freeze or 3
			local v_u_197 = p_u_84.ground(p193, 0.08)
			v_u_49(v_u_197, v_u_195 * 0.6, v_u_195 * 2.3, v_u_9.Glow, v_u_11, 0.35, 0.3, v_u_196 - 0.4, 0.6, 0)
			v_u_49(v_u_197 + Vector3.new(0, 0.05, 0), v_u_195 * 0.5, v_u_195 * 2.1, v_u_9.Ring, v_u_11, 0, 0.3, v_u_196 - 0.4, 0.6, 0.2)
			if not p_u_192.lite then
				local v_u_198 = {}
				for v199 = 1, 6 do
					local v200 = v_u_6.part(Vector3.new(0.1, 0.05, 0.1), CFrame.new(v_u_197), v_u_11, {
						["transparency"] = 1
					})
					for _, v201 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
						local v202 = Instance.new("Decal")
						v202.Face = v201
						v202.Texture = v_u_9.HogyokuWing
						local v203
						if v199 % 2 == 0 then
							v203 = v_u_11
						else
							v203 = v_u_10
						end
						v202.Color3 = v203
						v202.Parent = v200
					end
					table.insert(v_u_198, v200)
					v_u_1:AddItem(v200, v_u_196 + 1)
				end
				local v_u_204 = os.clock()
				p_u_84.runNow(function()
					-- upvalues: (copy) v_u_204, (copy) v_u_196, (copy) v_u_198, (copy) v_u_195, (copy) v_u_197
					local v205 = os.clock() - v_u_204
					local v206 = v205 / 0.4
					local v207 = math.clamp(v206, 0, 1) - 1
					local v208 = v207 * 2.7 * v207 * v207 + 1 + v207 * 1.7 * v207
					local v209 = (v205 - v_u_196 + 0.3) / 0.5
					local v210 = math.clamp(v209, 0, 1)
					local v211 = v210 * v210 * (3 - v210 * 2)
					for v212, v213 in v_u_198 do
						if not v213.Parent then
							return false
						end
						local v214 = v205 * 0.3 + v212 * 3.141592653589793 / 3
						local v215 = v_u_195 * 0.85 * v208 * (v211 * 0.2 + 1)
						local v216 = v215 * 0.46
						local v217 = math.max(v215, 0.1)
						v213.Size = Vector3.new(v216, 0.05, v217)
						v213.CFrame = CFrame.new(v_u_197 + Vector3.new(0, 1, 0) * (v212 * 0.01 + 0.1)) * CFrame.Angles(0, v214, 0) * CFrame.new(0, 0, -v215 * 0.5)
						for _, v218 in v213:GetChildren() do
							if not v218:IsA("Decal") then
								continue
							end
							v218.Transparency = v211
						end
					end
					if v211 < 1 then
						return true
					end
					for _, v219 in v_u_198 do
						v219:Destroy()
					end
					return false
				end)
			end
			v_u_6.ring(v_u_197, v_u_10, v_u_195 * 1.1, 0.5, v_u_9.Ring)
			v_u_65(v_u_197 + Vector3.new(0, 1.5, 0), p_u_192.lite and 4 or 14, 0.6 * v194, v_u_195, 1.4)
			v_u_8.play("Bind", {
				["at"] = v_u_197,
				["volume"] = p_u_192.mine and 0.8 or 0.45
			})
			if p_u_192.mine then
				v_u_6.shake(0.2, 0.2)
			end
			p_u_84.after(v_u_196, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_197, (ref) v_u_12, (copy) v_u_195, (ref) v_u_9, (ref) v_u_8, (copy) p_u_192
				v_u_6.ring(v_u_197, v_u_12, v_u_195 * 1.3, 0.55, v_u_9.Ring)
				v_u_8.play("Crit", {
					["at"] = v_u_197,
					["volume"] = p_u_192.mine and 0.6 or 0.35
				})
			end)
		end,
		["hit"] = function(p220, p221, p222) -- name: hit
			-- upvalues: (copy) v_u_113, (copy) p_u_84, (ref) v_u_10, (copy) v_u_184
			local v223 = (v_u_113[p220] or 0) + 1
			v_u_113[p220] = v223
			if (p220.lite and 3 or 8) < v223 then
				p_u_84.burst("Impact", p221, v_u_10, 0.6)
			else
				v_u_184(p220, p221, p222)
			end
		end
	}
	local v_u_224 = {}
	setmetatable(v_u_224, {
		["__mode"] = "k"
	})
	local v_u_225 = {
		{ 62, -30 },
		{ 62, 30 },
		{ 30, -62 },
		{ 30, 62 },
		{ -2, -85 },
		{ -2, 85 }
	}
	v112.hogyoku_r = {
		["cast"] = function(p226) -- name: cast
			-- upvalues: (copy) p_u_84, (ref) v_u_10, (ref) v_u_12, (ref) v_u_6, (ref) v_u_74
			local v227 = p226.size
			p_u_84.skillCast(p226, v_u_10, true, true)
			p_u_84.glint(p226.eye, v_u_12, 5 * v227, 0.25)
			if p226.mine then
				v_u_6.shake(0.12, 0.15)
				v_u_74(Color3.fromRGB(232, 214, 255), 0.03, -0.15, 0.2, 1.2, 0.6)
			end
		end,
		["windup"] = function(p228, _, p229) -- name: windup
			-- upvalues: (ref) v_u_4, (ref) v_u_5, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10, (ref) v_u_57, (copy) v_u_225, (ref) v_u_83, (copy) p_u_84, (copy) v_u_224, (ref) v_u_8
			local v230 = p228.size
			local v231 = p228.ability.radius * v230
			local v232 = math.max(p229, 0.15)
			local v233 = -p228.dir
			local v234 = p228.eye - Vector3.new(0, 1.3, 0) * v230
			local v_u_235 = v234 + v233 * 0.6 * v230
			local v236 = p228.dir
			local v237 = v236.X
			local v238 = v236.Z
			local v239 = Vector3.new(v237, 0, v238)
			local v240 = (v239.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v239.Unit):Cross(Vector3.new(0, 1, 0))
			local v241 = v_u_4.CurrentCamera
			local v242
			if v241 then
				v242 = v241.CFrame
			else
				v242 = CFrame.identity
			end
			for v243 = 0, 3 do
				local v244 = v243 * 3.141592653589793 / 2
				local v245 = v242.RightVector * math.cos(v244) + v242.UpVector * math.sin(v244)
				v_u_5.thin(v_u_5.rod(v234, v234 + v245 * 6 * v230, 0.35 * v230, v_u_12), v232 + 0.3, true)
			end
			v_u_6.flash(v234, v_u_10, 7 * v230, v232 + 0.2)
			v_u_57(v234, 2 * v230, 14 * v230, v_u_10, v232 + 0.3)
			local v_u_246 = v231 * 0.42
			local v_u_247 = {}
			local v_u_248 = {}
			for v249, v250 in v_u_225 do
				local v251 = v250[1]
				local v252 = math.rad(v251)
				local v253 = v250[2]
				local v254 = math.rad(v253)
				local v255 = (v233 * math.cos(v254) + v240 * math.sin(v254)) * math.cos(v252) + Vector3.new(0, 1, 0) * math.sin(v252)
				local v256 = CFrame.lookAt(v_u_235, v_u_235 + v255)
				table.insert(v_u_247, v256)
				local v257 = v_u_83(v_u_235, v_u_235, (v249 <= 2 and 5.2 or 4.4) * v230, v232 + 2)
				table.insert(v_u_248, v257)
			end
			p_u_84.animate(v232 + 0.15, 0, function(p258)
				-- upvalues: (copy) v_u_248, (copy) v_u_235, (copy) v_u_247, (copy) v_u_246
				local v259 = math.clamp(p258, 0, 1) - 1
				local v260 = v259 * 2.7 * v259 * v259 + 1 + v259 * 1.7 * v259
				for v261, v262 in v_u_248 do
					v262.tip.WorldPosition = v_u_235 + v_u_247[v261].LookVector * v_u_246 * math.max(v260, 0.03)
				end
			end)
			v_u_224[p228] = {
				["wings"] = v_u_248,
				["spots"] = v_u_247,
				["chest"] = v234
			}
			if not p228.lite then
				p_u_84.inward(v234, v_u_12, 10, v231 * 0.5, v232)
			end
			v_u_8.play("EyeActivate", {
				["at"] = v234,
				["volume"] = p228.mine and 0.6 or 0.3
			})
		end,
		["land"] = function(p_u_263, p264) -- name: land
			-- upvalues: (copy) p_u_84, (copy) v_u_224, (ref) v_u_65, (ref) v_u_14, (ref) v_u_10, (ref) v_u_13, (ref) v_u_49, (ref) v_u_9, (ref) v_u_11, (ref) v_u_6, (ref) v_u_12, (ref) v_u_8, (ref) v_u_74
			local v_u_265 = p_u_263.size
			local v_u_266 = p_u_263.lite
			local v_u_267 = p_u_263.ability.radius * v_u_265
			local v_u_268 = p_u_84.ground(p264, 0.1)
			local v269 = v_u_224[p_u_263]
			v_u_224[p_u_263] = nil
			local v_u_270 = {}
			for v271 = 1, 6 do
				local v272 = v271 * 3.141592653589793 / 3 + math.random() * 0.3
				local v273 = math.cos(v272)
				local v274 = math.sin(v272)
				local v275 = Vector3.new(v273, 0, v274)
				table.insert(v_u_270, v275)
			end
			if v269 then
				local v_u_276 = v269.wings
				local v_u_277 = {}
				for v278, v279 in v_u_276 do
					v_u_277[v278] = v279.tip.WorldPosition
				end
				p_u_84.animate(0.82, 0, function(p280)
					-- upvalues: (copy) v_u_276, (copy) v_u_268, (copy) v_u_270, (copy) v_u_267, (copy) v_u_277, (ref) v_u_65, (copy) v_u_266, (copy) v_u_265
					local v281 = p280 * 0.82 / 0.22
					local v282 = math.clamp(v281, 0, 1)
					local v283 = v282 * v282 * (3 - v282 * 2)
					local v284 = (p280 * 0.82 - 0.22) / 0.6
					local v285 = math.clamp(v284, 0, 1)
					local v286 = v285 * v285 * (3 - v285 * 2)
					for v287, v288 in v_u_276 do
						local v289 = v288.root.WorldPosition
						local v290 = v_u_268 + v_u_270[v287] * v_u_267 * 0.55
						local v291 = v_u_277[v287]:Lerp(v290, v283)
						local v292 = v283 * 3.141592653589793
						local v293 = v291 + Vector3.new(0, 1, 0) * math.sin(v292) * v_u_267 * 0.15
						v288.tip.WorldPosition = v293
						v288.beam.Width0 = v288.beam.Width1 * (1 - v283 * 0.3)
						v288.beam.Transparency = NumberSequence.new(v286)
						if p280 < 1 then
							continue
						end
						v_u_65(v289:Lerp(v293, 0.6), v_u_266 and 2 or 8, 0.6 * v_u_265, 8 * v_u_265, 1.2)
						v288.holder:Destroy()
					end
				end)
			end
			p_u_84.after(0.22, function()
				-- upvalues: (copy) v_u_270, (copy) v_u_268, (copy) v_u_265, (copy) v_u_267, (ref) p_u_84, (ref) v_u_14, (ref) v_u_10, (copy) v_u_266, (ref) v_u_13, (ref) v_u_49, (ref) v_u_9, (ref) v_u_11, (ref) v_u_6, (ref) v_u_12, (ref) v_u_65, (ref) v_u_8, (copy) p_u_263, (ref) v_u_74
				for v294, v295 in v_u_270 do
					local v296 = v_u_268 + v295 * 2 * v_u_265
					local v297 = v_u_268 + v295 * v_u_267 * 1.05
					p_u_84.groundLine(v296, v297, 2.2 * v_u_265, v_u_14, 1.6, 0.1)
					p_u_84.groundLine(v296, v297, 0.8 * v_u_265, v_u_10, 1.3, 0)
					if v_u_266 or v294 % 2 ~= 0 then
						continue
					end
					local v298 = { v_u_14, v_u_10, v_u_13 }
					p_u_84.chunks(v_u_268 + v295 * v_u_267 * 0.6, v298, 4, 22 * v_u_265, 0.6 * v_u_265, 1, false, 0.7)
				end
				v_u_49(v_u_268, v_u_267 * 0.4, v_u_267 * 2.4, v_u_9.Ring, v_u_11, 0, 0.3, 0.2, 0.5, 0)
				v_u_49(v_u_268 + Vector3.new(0, 0.05, 0), v_u_267 * 0.6, v_u_267 * 2.2, v_u_9.Glow, v_u_11, 0.4, 0.3, 0.6, 0.6, 0)
				v_u_6.ring(v_u_268, v_u_10, v_u_267 * 1.2, 0.5, v_u_9.Shockwave)
				p_u_84.burst("Shockwave", v_u_268 + Vector3.new(0, 0.3, 0), v_u_10, v_u_267 / 14)
				p_u_84.dome(v_u_268, v_u_267, v_u_10, 0.5)
				v_u_6.flash(v_u_268 + Vector3.new(0, 3, 0) * v_u_265, v_u_12, v_u_267 * 0.9, 0.25)
				v_u_65(v_u_268 + Vector3.new(0, 2, 0), v_u_266 and 6 or 24, 0.8 * v_u_265, v_u_267 * 0.9, 1.6)
				v_u_8.play("Explosion", {
					["at"] = v_u_268,
					["volume"] = p_u_263.mine and 1 or 0.5
				})
				if p_u_263.mine then
					v_u_6.shake(0.5, 0.45)
					v_u_74(Color3.fromRGB(220, 190, 255), 0.18, 0, 0.03, 0.08, 0.4)
				end
			end)
		end,
		["hit"] = function(p299, p300, _) -- name: hit
			-- upvalues: (copy) p_u_84, (ref) v_u_10, (ref) v_u_12
			p_u_84.burst("Impact", p300, v_u_10, 0.8)
			if not p299.lite then
				p_u_84.glint(p300, v_u_12, 3, 0.15)
			end
		end
	}
	return v112
end