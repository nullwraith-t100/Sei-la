local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromRGB(57, 255, 90)
local v_u_8 = Color3.fromRGB(11, 61, 18)
local v_u_9 = Color3.fromRGB(28, 150, 48)
local v_u_10 = Color3.fromRGB(190, 255, 160)
local v_u_11 = Color3.fromRGB(215, 255, 40)
local v_u_12 = Color3.fromRGB(95, 190, 70)
local v_u_13 = Color3.fromRGB(255, 255, 255)
return function(p_u_14)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_2, (copy) v_u_12, (copy) v_u_3, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_11, (copy) v_u_13, (copy) v_u_5, (copy) v_u_6
	local function v_u_22(p15, p16, p17, p18, p19) -- name: ellip
		-- upvalues: (ref) v_u_4, (ref) v_u_1
		local v20 = v_u_4.part(p15, p16, p17, {
			["transparency"] = p18,
			["material"] = p19
		})
		local v21 = Instance.new("SpecialMesh")
		v21.MeshType = Enum.MeshType.Sphere
		v21.Parent = v20
		v_u_1:AddItem(v20, 8)
		return v20
	end
	local function v_u_31(p23, p24) -- name: scaled
		local v25 = {}
		for _, v26 in p23.Keypoints do
			local v27 = NumberSequenceKeypoint.new
			local v28 = v26.Time
			local v29 = v26.Value * p24
			local v30 = v26.Envelope * p24
			table.insert(v25, v27(v28, v29, v30))
		end
		return NumberSequence.new(v25)
	end
	local function v_u_42(p32, p33) -- name: fumes
		-- upvalues: (ref) v_u_2, (ref) v_u_12, (copy) v_u_31, (ref) v_u_3, (ref) v_u_1
		local v34 = v_u_2:FindFirstChild("Fx")
		if v34 then
			v34 = v34:FindFirstChild("Smoke")
		end
		if v34 and v34:IsA("Attachment") then
			local v35 = v34:Clone()
			local v36 = {}
			for _, v37 in v35:GetDescendants() do
				if not v37:IsA("ParticleEmitter") then
					continue
				end
				v37.Color = ColorSequence.new(v_u_12)
				v37.Size = v_u_31(v37.Size, p33)
				v37.Speed = NumberRange.new(v37.Speed.Min * p33, v37.Speed.Max * p33)
				table.insert(v36, v37)
			end
			v35.WorldPosition = p32
			v35.Parent = v_u_3.Terrain
			for _, v38 in v36 do
				local v39 = v38:GetAttribute("Emit")
				if type(v39) ~= "number" then
					continue
				end
				local v40 = v39 * 0.6
				v38:Emit((math.ceil(v40)))
			end
			local v41 = v35:GetAttribute("Life")
			v_u_1:AddItem(v35, (type(v41) ~= "number" and 2 or v41) + 0.5)
		end
	end
	local function v_u_47(p43, p_u_44, p45) -- name: bubble
		-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_4, (ref) v_u_10
		local v_u_46 = p_u_14.ball(p43, v_u_7, p_u_44 * 0.3, 0.15)
		v_u_4.tween(v_u_46, p45, {
			["Size"] = Vector3.new(1, 1, 1) * p_u_44,
			["CFrame"] = CFrame.new(p43 + Vector3.new(0, 1, 0) * p_u_44 * 0.45)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		p_u_14.after(p45, function()
			-- upvalues: (copy) v_u_46, (ref) p_u_14, (ref) v_u_10, (copy) p_u_44
			if v_u_46.Parent then
				p_u_14.pop(v_u_46.Position, v_u_10, p_u_44, p_u_44 * 1.8, 0.12, 0.35)
				v_u_46:Destroy()
			end
		end)
	end
	local function v_u_61(p48, p_u_49) -- name: drip
		-- upvalues: (copy) p_u_14, (ref) v_u_7
		local v_u_50 = p_u_14.ball(p48, v_u_7, p_u_49, 0.1)
		local v51 = (math.random() - 0.5) * 3
		local v52 = (math.random() - 0.5) * 3
		local v_u_53 = Vector3.new(v51, -2, v52)
		local v_u_54 = os.clock()
		local v_u_55 = v_u_54
		p_u_14.frame(function()
			-- upvalues: (ref) v_u_55, (copy) v_u_54, (copy) v_u_50, (ref) v_u_53, (ref) p_u_14, (copy) p_u_49
			local v56 = os.clock()
			local v57 = v56 - v_u_55
			local v58 = math.min(v57, 0.05)
			v_u_55 = v56
			local v59 = v56 - v_u_54
			if not v_u_50.Parent then
				return false
			end
			v_u_53 = v_u_53 - Vector3.new(0, 90, 0) * v58
			local v60 = v_u_50.Position + v_u_53 * v58
			if v60.Y < p_u_14.FLOOR + p_u_49 / 2 or v59 > 0.45 then
				v_u_50:Destroy()
				return false
			end
			v_u_50.CFrame = CFrame.new(v60)
			v_u_50.Transparency = 0.1 + v59 * 1.5
			return true
		end)
	end
	local function v_u_77(p62, p63, p64) -- name: puddle
		-- upvalues: (copy) p_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_1
		local v65 = p_u_14.ground(p62, 0.07 + math.random() * 0.04)
		local v_u_66 = p_u_14.plate(v65, p63 * 0.3, v_u_8, 0.05, Enum.Material.SmoothPlastic)
		local v_u_67 = p_u_14.plate(v65 - Vector3.new(0, 0.02, 0), p63 * 0.35, v_u_7, 0.3)
		local v68 = v_u_4.tween
		local v69 = {}
		local v70 = p63 * 2
		local v71 = p63 * 2
		v69.Size = Vector3.new(0.12, v70, v71)
		v68(v_u_66, 0.18, v69, Enum.EasingStyle.Back)
		local v72 = v_u_4.tween
		local v73 = {}
		local v74 = p63 * 2.3
		local v75 = p63 * 2.3
		v73.Size = Vector3.new(0.12, v74, v75)
		v72(v_u_67, 0.18, v73, Enum.EasingStyle.Back)
		p_u_14.after(p64, function()
			-- upvalues: (copy) v_u_66, (copy) v_u_67, (ref) v_u_4, (ref) v_u_1
			for _, v76 in { v_u_66, v_u_67 } do
				if not v76.Parent then
					continue
				end
				v_u_4.tween(v76, 0.4, {
					["Size"] = Vector3.new(0.12, 0.2, 0.2),
					["Transparency"] = 1
				})
				v_u_1:AddItem(v76, 0.45)
			end
		end)
	end
	local v_u_78 = {}
	local function v_u_88(p79, p80) -- name: pathAt
		-- upvalues: (copy) v_u_88
		if p80 <= 0 then
			return p79.e + Vector3.new(0, 1, 0) * (p80 + 4.5)
		end
		if p80 > p79.len then
			local v81 = p80 - p79.len
			return v_u_88(p79, p79.len) + p79.dir * v81 * 0.45 - Vector3.new(0, 1, 0) * v81 * 1.1
		end
		local v82 = p80 / 24 * 3.141592653589793 * 2
		local v83 = math.sin(v82) * 2.4
		local v84 = p80 / 8
		local v85 = v83 * math.min(v84, 1)
		local v86 = p79.e + p79.dir * p80 + p79.side * v85
		local v87 = 3.141592653589793 * p80 / p79.len
		return v86 + Vector3.new(0, 1, 0) * (math.sin(v87) * 3.2 + 4.5)
	end
	local function v_u_125(p89, p90) -- name: buildSerpent
		-- upvalues: (copy) p_u_14, (copy) v_u_22, (ref) v_u_7, (ref) v_u_1, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_13
		local v91 = p89.lite
		local v_u_92 = p_u_14.ground(p89.feet + p89.dir * 5, 0)
		local v93 = p89.ability.range - 6
		local v94 = math.max(v93, 20)
		local v95 = v91 and 9 or 16
		local v_u_96 = p90 + 2.5
		local v97 = {}
		for v98 = 1, v95 do
			local v99 = (v98 - 1) / (v95 - 1) * -3.3 + 4.8
			local v100 = v_u_22(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_92 - Vector3.new(0, 20, 0)), v_u_7, 0.62)
			v_u_1:AddItem(v100, v_u_96)
			local v101
			if v91 then
				v101 = nil
			else
				local v102 = v_u_22
				local v103 = Vector3.new(0.2, 0.2, 0.2)
				local v104 = CFrame.new(v_u_92 - Vector3.new(0, 20, 0))
				local v105
				if v98 % 2 == 0 then
					v105 = v_u_9
				else
					v105 = v_u_8
				end
				v101 = v102(v103, v104, v105, 0, Enum.Material.SmoothPlastic)
				v_u_1:AddItem(v101, v_u_96)
			end
			table.insert(v97, {
				["core"] = v101,
				["skin"] = v100,
				["w"] = v99
			})
		end
		local v_u_106 = {}
		local v_u_107 = {}
		local function v119(p108, p109, p110, p111, p112, p113) -- name: part
			-- upvalues: (ref) v_u_22, (copy) v_u_92, (ref) v_u_4, (ref) v_u_1, (copy) v_u_96, (copy) v_u_106, (copy) v_u_107
			local v114 = p108 * 1.35
			local v115
			if p112 then
				v115 = v_u_22(v114, CFrame.new(v_u_92 - Vector3.new(0, 20, 0)), p110, p111, p113)
			else
				v115 = v_u_4.part(v114, CFrame.new(v_u_92 - Vector3.new(0, 20, 0)), p110, {
					["transparency"] = p111,
					["material"] = p113
				})
			end
			v_u_1:AddItem(v115, v_u_96)
			local v116 = v_u_106
			table.insert(v116, v115)
			local v117 = v_u_107
			local v118 = p109 - p109.Position + p109.Position * 1.35
			table.insert(v117, v118)
		end
		v119(Vector3.new(4.6, 3.3, 7), CFrame.new(0, 0, -0.5), v_u_7, 0.45, true)
		v119(Vector3.new(9.5, 7.5, 0.7), CFrame.new(0, 1.2, 2.4) * CFrame.Angles(0.25, 0, 0), v_u_9, 0.15, true, Enum.Material.SmoothPlastic)
		for _, v120 in { -1, 1 } do
			v119(Vector3.new(0.95, 0.6, 0.95), CFrame.new(1.35 * v120, 0.8, -2.3), v_u_11, 0, true)
		end
		if not v91 then
			v119(Vector3.new(3.8, 2.6, 6), CFrame.new(0, 0, -0.5), v_u_8, 0, true, Enum.Material.SmoothPlastic)
			v119(Vector3.new(3.2, 0.9, 4.6), CFrame.new(0, -1.5, -1.3) * CFrame.Angles(-0.45, 0, 0), v_u_8, 0, true, Enum.Material.SmoothPlastic)
			v119(Vector3.new(6.5, 5, 0.75), CFrame.new(0, 1.3, 2.45) * CFrame.Angles(0.25, 0, 0), v_u_7, 0.35, true)
			for _, v121 in { -1, 1 } do
				v119(Vector3.new(0.35, 1.5, 0.35), CFrame.new(0.85 * v121, -1.25, -2.9), v_u_13, 0, false)
			end
		end
		local v122 = {}
		for _ = 1, v95 do
			table.insert(v122, false)
		end
		local v123 = {
			["e"] = nil,
			["dir"] = nil,
			["side"] = nil,
			["len"] = nil,
			["gap"] = nil,
			["segs"] = nil,
			["head"] = nil,
			["headOffs"] = nil,
			["born"] = nil,
			["rise"] = nil,
			["lungeAt"] = nil,
			["landed"] = false,
			["gone"] = nil,
			["lite"] = nil,
			["ctx"] = nil,
			["e"] = v_u_92,
			["dir"] = p89.dir,
			["side"] = p89.dir:Cross(Vector3.new(0, 1, 0)),
			["len"] = v94
		}
		local v124 = (v94 + 4) / v95
		v123.gap = math.clamp(v124, 2, 6)
		v123.segs = v97
		v123.head = v_u_106
		v123.headOffs = v_u_107
		v123.born = os.clock()
		v123.rise = math.max(p90, 0.06)
		v123.gone = v122
		v123.lite = v91
		v123.ctx = p89
		return v123
	end
	local function v_u_130(p126) -- name: removeSerpent
		for _, v127 in p126.head do
			v127:Destroy()
		end
		for _, v128 in p126.segs do
			v128.skin:Destroy()
			local v129 = v128.core
			if not v129 then
				continue
			end
			v129:Destroy()
		end
	end
	local function v_u_138(p131) -- name: serpentLands
		-- upvalues: (copy) v_u_88, (copy) p_u_14, (ref) v_u_7, (ref) v_u_4, (copy) v_u_77, (ref) v_u_9, (ref) v_u_11, (copy) v_u_42, (ref) v_u_5
		local v132 = p131.ctx
		local v133 = v_u_88(p131, p131.len)
		local v134 = p_u_14.ground(v133, 0)
		p_u_14.burst("Explosion", p_u_14.ground(v133, 2), v_u_7, 1.2)
		p_u_14.burst("Shockwave", p_u_14.ground(v133, 0.3), v_u_7, 0.6)
		v_u_4.ring(v134, v_u_7, 9, 0.4)
		v_u_77(v134, 4.5, 1.6)
		local v135 = p_u_14.ground(v133, 1)
		local v136 = p131.lite and 4 or 10
		local v137 = { v_u_7, v_u_9, v_u_11 }
		p_u_14.chunks(v135, v137, v136, 34, 0.6, 0.55, true, 0.8)
		v_u_42(p_u_14.ground(v133, 1), 1.6)
		v_u_5.play("Explosion", {
			["at"] = v134,
			["volume"] = v132.mine and 0.8 or 0.45
		})
		if v132.mine then
			v_u_4.shake(0.4, 0.3)
		end
	end
	local function v_u_174(p139) -- name: driveSerpent
		-- upvalues: (copy) v_u_138, (copy) v_u_130, (copy) v_u_88, (copy) p_u_14, (copy) v_u_77, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11, (copy) v_u_42, (copy) v_u_47
		local v140 = os.clock()
		local v141 = -1
		local v142 = p139.lungeAt
		local v143
		if v142 then
			local v144 = v140 - v142
			if v144 < 0.17 then
				local v145 = v144 / 0.17
				v143 = p139.len * (1 - (1 - v145) ^ 2)
			else
				local v146 = p139.len
				local v147 = (v144 - 0.17) / 0.1
				v143 = v146 + math.min(v147, 1) * 7
				if not p139.landed then
					p139.landed = true
					v_u_138(p139)
				end
				v141 = (v144 - 0.17 - 0.1) / 0.45
				if v141 > 1.1 then
					v_u_130(p139)
					return false
				end
			end
		else
			local v148 = v140 - p139.born
			local v149 = v148 / p139.rise
			v143 = (1 - math.clamp(v149, 0, 1)) ^ 2 * -7.5
			if p139.rise + 1.2 < v148 then
				v_u_130(p139)
				return false
			end
		end
		local v150 = v_u_88(p139, v143)
		local v151
		if v143 <= 0 then
			v151 = (p139.dir + Vector3.new(0, 0.35, 0)).Unit
		else
			v151 = (v_u_88(p139, v143 + 0.6) - v_u_88(p139, v143 - 0.6)).Unit
		end
		local v152 = p_u_14.aimAt(v150, v151)
		local v153 = p139.len + 6 < v143
		for v154, v155 in p139.head do
			v155.CFrame = v152 * p139.headOffs[v154]
			if not v153 then
				continue
			end
			v155.Transparency = 1
		end
		local v156 = #p139.segs
		for v157, v158 in p139.segs do
			if p139.gone[v157] then
				continue
			end
			local v159 = v143 - 3.4 - (v157 - 0.5) * p139.gap
			local v160 = v_u_88(p139, v159)
			local v161 = p_u_14.aimAt(v160, v_u_88(p139, v159 + 0.5) - v160)
			local v162 = v158.w
			local v163 = v158.w
			local v164 = p139.gap * 1.45
			local v165 = Vector3.new(v162, v163, v164)
			v158.skin.CFrame = v161
			v158.skin.Size = v165 * 1.22
			local v166 = v158.core
			if v166 then
				v166.CFrame = v161
				v166.Size = v165
			end
			if (v157 - 1) / v156 > v141 then
				continue
			end
			p139.gone[v157] = true
			v158.skin:Destroy()
			if v166 then
				v166:Destroy()
			end
			if v159 <= 0 or p139.lite and v157 % 3 ~= 1 or v157 % 2 ~= 1 then
				continue
			end
			local v167 = p_u_14.ground(v160, 0)
			v_u_77(v167, v158.w * 0.4 + 2.4, 1.3)
			p_u_14.burst("Impact", p_u_14.ground(v160, 1), v_u_7, 0.9)
			if p139.lite then
				continue
			end
			local v168 = p_u_14.ground(v160, 1)
			local v169 = { v_u_7, v_u_9, v_u_11 }
			p_u_14.chunks(v168, v169, 3, 20, 0.45, 0.55, true, 0.8)
			if v157 % 4 == 1 then
				v_u_42(p_u_14.ground(v160, 0.5), 1.1)
			end
			for _ = 1, 2 do
				local v170 = math.random() * 3.141592653589793 * 2
				local v171 = v_u_47
				local v172 = math.cos(v170)
				local v173 = math.sin(v170)
				v171(v167 + Vector3.new(v172, 0.2, v173) * 1.5, 0.8 + math.random() * 0.8, 0.4 + math.random() * 0.5)
			end
		end
		return true
	end
	local v300 = {
		["venom_tomoe_a"] = {
			["cast"] = function(p175) -- name: cast
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11
				p_u_14.muzzle(p175, v_u_7)
				if not p175.lite then
					local v176 = p175.eye + p175.dir * 1.2
					local v177 = { v_u_7, v_u_9, v_u_11 }
					p_u_14.chunks(v176, v177, 3, 12, 0.3, 0.55, true, 0.8)
				end
			end,
			["shot"] = function(p_u_178, p179) -- name: globShot
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) v_u_22, (ref) v_u_9, (ref) v_u_11, (ref) v_u_1, (copy) p_u_14, (ref) v_u_8, (copy) v_u_61
				local v_u_180 = p_u_178.size
				local v_u_181 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p179, v_u_7, {
					["transparency"] = 1
				})
				local v_u_182 = v_u_22(Vector3.new(1.3, 1.3, 1.8) * v_u_180, p179, v_u_7)
				local v_u_183 = v_u_22(Vector3.new(2.2, 2.2, 3) * v_u_180, p179, v_u_9, 0.45, Enum.Material.Glass)
				local v_u_184 = v_u_22(Vector3.new(0.7, 0.7, 0.7) * v_u_180, p179, v_u_11, 0.1)
				v_u_1:AddItem(v_u_181, 6)
				p_u_14.streak(v_u_181, v_u_7, v_u_8, 1.4 * v_u_180, 0.18)
				if p_u_178.mine then
					p_u_14.light(v_u_181, v_u_7, 9 * v_u_180)
				end
				local v_u_185 = 0
				local v_u_186 = false
				return {
					["place"] = function(p187, p188) -- name: place
						-- upvalues: (copy) v_u_181, (copy) v_u_182, (copy) v_u_180, (copy) v_u_183, (copy) v_u_184, (copy) p_u_178, (ref) v_u_185, (ref) v_u_61
						v_u_181.CFrame = p187
						local v189 = p188 * 34
						local v190 = math.sin(v189) * 0.18
						v_u_182.CFrame = p187
						local v191 = v_u_182
						local v192 = (v190 + 1) * 1.3
						local v193 = (1 - v190) * 1.3
						local v194 = (1 - v190) * 1.8
						v191.Size = Vector3.new(v192, v193, v194) * v_u_180
						v_u_183.CFrame = p187 * CFrame.new(0, 0, 0.3 * v_u_180)
						local v195 = v_u_183
						local v196 = (1 - v190) * 2.2
						local v197 = (v190 + 1) * 2.2
						local v198 = (v190 + 1) * 3
						v195.Size = Vector3.new(v196, v197, v198) * v_u_180
						v_u_184.CFrame = p187 * CFrame.new(0.35 * v_u_180, 0.35 * v_u_180, -0.4 * v_u_180)
						if not p_u_178.lite and v_u_185 <= p188 then
							v_u_185 = p188 + 0.045
							v_u_61(p187.Position - Vector3.new(0, 0.6, 0) * v_u_180, 0.35 * v_u_180)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_186, (copy) v_u_181, (ref) v_u_1, (copy) v_u_182, (copy) v_u_183, (copy) v_u_184
						if not v_u_186 then
							v_u_186 = true
							local v199 = v_u_181:FindFirstChildWhichIsA("PointLight")
							if v199 then
								v199:Destroy()
							end
							v_u_1:AddItem(v_u_181, 0.2)
							v_u_182:Destroy()
							v_u_183:Destroy()
							v_u_184:Destroy()
						end
					end
				}
			end,
			["impact"] = function(p200, p201) -- name: impact
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_4, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (copy) v_u_77, (copy) v_u_42, (copy) v_u_47
				local v_u_202 = p200.size
				p_u_14.burst("Impact", p201, v_u_7, 1 * v_u_202)
				v_u_4.flash(p201, v_u_7, 4.5 * v_u_202, 0.15)
				p_u_14.pop(p201, v_u_10, 1.4 * v_u_202, 5 * v_u_202, 0.15, 0.3)
				local v203 = p200.lite and 3 or 7
				local v204 = 0.45 * v_u_202
				local v205 = { v_u_7, v_u_9, v_u_11 }
				p_u_14.chunks(p201, v205, v203, 22, v204, 0.55, true, 0.8)
				v_u_77(p201, 2.6 * v_u_202, 0.9)
				if not p200.lite then
					v_u_42(p_u_14.ground(p201, 0.8), 0.7 * v_u_202)
					for v206 = 1, 3 do
						local v207 = math.random() * 3.141592653589793 * 2
						local v208 = p_u_14.ground(p201, 0.2)
						local v209 = math.cos(v207)
						local v210 = math.sin(v207)
						local v_u_211 = v208 + Vector3.new(v209, 0, v210) * 1.4 * v_u_202
						p_u_14.after(v206 * 0.15, function()
							-- upvalues: (ref) v_u_47, (copy) v_u_211, (copy) v_u_202
							v_u_47(v_u_211, (0.6 + math.random() * 0.5) * v_u_202, 0.3)
						end)
					end
				end
				p_u_14.hitSound(p201)
			end,
			["hit"] = function(p212, p213, _) -- name: hit
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (copy) v_u_61
				p_u_14.burst("Impact", p213, v_u_7, 0.6)
				if not p212.lite then
					v_u_61(p213, 0.3)
					v_u_61(p213, 0.3)
				end
			end
		},
		["venom_tomoe_e"] = {
			["loopSound"] = "Flames",
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["hit"] = nil,
			["cast"] = function(p214) -- name: cast
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11
				p_u_14.skillCast(p214, v_u_7)
				local v215 = p214.eye + p214.dir * 1.2
				local v216 = p214.lite and 2 or 4
				local v217 = { v_u_7, v_u_9, v_u_11 }
				p_u_14.chunks(v215, v217, v216, 14, 0.35, 0.55, true, 0.8)
			end,
			["windup"] = function(p218, p219, p220) -- name: windup
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_9, (ref) v_u_11
				local v221 = p218.ability.radius
				p_u_14.burst("Impact", p_u_14.ground(p219, 1), v_u_7, 1.4)
				v_u_4.ring(p_u_14.ground(p219), v_u_7, v221, p220 + 0.2, v_u_6.Ring)
				local v222 = p_u_14.ground(p219, 1)
				local v223 = p218.lite and 3 or 8
				local v224 = { v_u_7, v_u_9, v_u_11 }
				p_u_14.chunks(v222, v224, v223, 30, 0.5, 0.55, true, 0.8)
			end,
			["zone"] = function(p225, p_u_226, p_u_227) -- name: zone
				-- upvalues: (copy) p_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (copy) v_u_42, (copy) v_u_47, (ref) v_u_1
				local v_u_228 = p225.ability.radius
				local v_u_229 = p225.lite
				local v_u_230 = p_u_14.ground(p_u_226, 0.08)
				local v_u_231 = p_u_14.plate(v_u_230, v_u_228 * 0.3, v_u_8, 0.05, Enum.Material.SmoothPlastic)
				local v_u_232 = p_u_14.plate(v_u_230 - Vector3.new(0, 0.02, 0), v_u_228 * 0.35, v_u_7, 0.3)
				local v233 = v_u_4.tween
				local v234 = {}
				local v235 = v_u_228 * 2
				local v236 = v_u_228 * 2
				v234.Size = Vector3.new(0.12, v235, v236)
				v233(v_u_231, 0.25, v234, Enum.EasingStyle.Back)
				local v237 = v_u_4.tween
				local v238 = {}
				local v239 = v_u_228 * 2.12
				local v240 = v_u_228 * 2.12
				v238.Size = Vector3.new(0.12, v239, v240)
				v237(v_u_232, 0.25, v238, Enum.EasingStyle.Back)
				p_u_14.sigil(CFrame.new(p_u_14.ground(p_u_226, 0.2)), v_u_228 * 0.92, v_u_7, v_u_6.Swirl, p_u_227, 0.8)
				local v_u_241 = {}
				local v242 = p_u_14.loopAt
				local v243 = p_u_14.ground(p_u_226, 0)
				local v244 = v_u_7
				table.insert(v_u_241, v242("Fire", v243, v244, 1.1))
				if not v_u_229 then
					for v245 = 1, 3 do
						local v246 = v245 / 3 * 3.141592653589793 * 2 + 0.5
						local v247 = p_u_14.ground(p_u_226, 0)
						local v248 = math.cos(v246)
						local v249 = math.sin(v246)
						local v250 = v247 + Vector3.new(v248, 0, v249) * v_u_228 * 0.55
						local v251 = p_u_14.loopAt
						local v252 = v_u_7
						table.insert(v_u_241, v251("Fire", v250, v252, 0.8))
					end
				end
				v_u_42(p_u_14.ground(p_u_226, 1), 1.4)
				local v_u_253 = true
				local v_u_254 = os.clock()
				local v_u_255 = 0
				local v_u_256 = 0.3
				local v_u_257 = 0
				local v_u_258 = p225.ability.tick or 0.5
				p_u_14.frame(function()
					-- upvalues: (copy) v_u_254, (ref) v_u_253, (copy) p_u_227, (ref) v_u_255, (copy) v_u_229, (copy) v_u_228, (ref) v_u_47, (copy) v_u_230, (ref) v_u_256, (ref) v_u_42, (ref) v_u_257, (copy) v_u_258, (ref) v_u_4, (ref) p_u_14, (copy) p_u_226, (ref) v_u_7, (ref) v_u_6, (copy) v_u_232
					local v259 = os.clock() - v_u_254
					if not v_u_253 or p_u_227 + 0.5 < v259 then
						return false
					end
					local v260 = 0
					while v_u_255 <= v259 and v260 < 3 do
						v260 = v260 + 1
						v_u_255 = v_u_255 + (v_u_229 and 0.2 or 0.07)
						local v261 = math.random() * 3.141592653589793 * 2
						local v262 = v_u_228 * 0.85
						local v263 = math.random()
						local v264 = v262 * math.sqrt(v263)
						local v265 = v_u_47
						local v266 = v_u_230
						local v267 = math.cos(v261) * v264
						local v268 = math.sin(v261) * v264
						v265(v266 + Vector3.new(v267, 0.25, v268), 1.1 + math.random() * 1.6, 0.3 + math.random() * 0.3)
					end
					if v_u_256 <= v259 then
						v_u_256 = v259 + (v_u_229 and 0.9 or 0.35)
						local v269 = math.random() * 3.141592653589793 * 2
						local v270 = v_u_228 * 0.7
						local v271 = math.random()
						local v272 = v270 * math.sqrt(v271)
						local v273 = v_u_42
						local v274 = v_u_230
						local v275 = math.cos(v269) * v272
						local v276 = math.sin(v269) * v272
						v273(v274 + Vector3.new(v275, 1, v276), 1.1)
					end
					if v_u_257 <= v259 then
						v_u_257 = v_u_257 + v_u_258
						v_u_4.ring(p_u_14.ground(p_u_226), v_u_7, v_u_228, 0.35, v_u_6.Ring)
						if not v_u_229 then
							v_u_232.Transparency = 0
							v_u_4.tween(v_u_232, 0.3, {
								["Transparency"] = 0.3
							})
						end
					end
					return true
				end)
				return function()
					-- upvalues: (ref) v_u_253, (copy) v_u_241, (copy) v_u_231, (copy) v_u_232, (ref) v_u_4, (copy) v_u_228, (ref) v_u_1, (ref) v_u_42, (ref) p_u_14, (copy) p_u_226
					v_u_253 = false
					for _, v277 in v_u_241 do
						v277()
					end
					for _, v278 in { v_u_231, v_u_232 } do
						if not v278.Parent then
							continue
						end
						local v279 = v_u_4.tween
						local v280 = {
							["Size"] = nil,
							["Transparency"] = 1
						}
						local v281 = v_u_228 * 0.4
						local v282 = v_u_228 * 0.4
						v280.Size = Vector3.new(0.12, v281, v282)
						v279(v278, 0.5, v280)
						v_u_1:AddItem(v278, 0.55)
					end
					v_u_42(p_u_14.ground(p_u_226, 1), 1.2)
				end
			end,
			["hit"] = function(_, p283, _) -- name: hit
				-- upvalues: (copy) p_u_14, (ref) v_u_7
				p_u_14.burst("Impact", p283, v_u_7, 0.5)
			end
		},
		["venom_tomoe_r"] = {
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["beam"] = nil,
			["hit"] = nil,
			["cast"] = function(p284) -- name: cast
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6
				p_u_14.skillCast(p284, v_u_7, true)
				p_u_14.glint(p284.eye, v_u_10, 8, 0.22)
				p_u_14.mark(p284.feet + p284.dir * 5, v_u_8, 5, 1.4, v_u_6.CrackLines, 0.05)
			end,
			["windup"] = function(p285, _, p286) -- name: windup
				-- upvalues: (copy) v_u_78, (copy) v_u_130, (copy) v_u_125, (copy) p_u_14, (copy) v_u_174, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_9, (ref) v_u_11, (copy) v_u_42
				local v287 = v_u_78[p285]
				if v287 then
					v_u_130(v287)
				end
				local v_u_288 = v_u_125(p285, p286)
				p_u_14.runNow(function()
					-- upvalues: (ref) v_u_174, (copy) v_u_288
					return v_u_174(v_u_288)
				end)
				v_u_78[p285] = v_u_288
				local v289 = v_u_288.e
				p_u_14.burst("Impact", p_u_14.ground(v289, 1), v_u_7, 1.4)
				v_u_4.ring(v289, v_u_7, 6, 0.35, v_u_6.Ring)
				p_u_14.mark(v289, v_u_7, 4, 1.4, v_u_6.CrackGlow, 0.2)
				local v290 = p_u_14.ground(v289, 1)
				local v291 = p285.lite and 3 or 8
				local v292 = { v_u_7, v_u_9, v_u_11 }
				p_u_14.chunks(v290, v292, v291, 30, 0.6, 0.55, true, 0.8)
				if not p285.lite then
					p_u_14.chunks(p_u_14.ground(v289, 0.5), p_u_14.EARTH, 5, 30, 0.8, 0.8)
					v_u_42(p_u_14.ground(v289, 1), 1.2)
				end
			end,
			["beam"] = function(p293, _, _) -- name: beam
				-- upvalues: (copy) v_u_78, (copy) v_u_125, (copy) p_u_14, (copy) v_u_174, (copy) v_u_88, (ref) v_u_7, (ref) v_u_9, (ref) v_u_5, (ref) v_u_4
				local v_u_294 = v_u_78[p293]
				v_u_78[p293] = nil
				if not v_u_294 then
					v_u_294 = v_u_125(p293, 0)
					p_u_14.runNow(function()
						-- upvalues: (ref) v_u_174, (copy) v_u_294
						return v_u_174(v_u_294)
					end)
				end
				v_u_294.lungeAt = os.clock()
				local v295 = v_u_294.e + Vector3.new(0, 4.5, 0)
				local v296 = v_u_88(v_u_294, v_u_294.len)
				p_u_14.glowBeam(v295, v296, v_u_7, 5, 0.3)
				p_u_14.groundLine(v_u_294.e, v296, p293.ability.width or 7, v_u_9, 1.8, 0.45)
				p_u_14.burst("Flash", v295, v_u_7, 0.4)
				v_u_5.play("Rain", {
					["at"] = v295,
					["volume"] = p293.mine and 0.9 or 0.5
				})
				if p293.mine then
					v_u_4.shake(0.45, 0.35)
				end
			end,
			["hit"] = function(p297, p298, _) -- name: hit
				-- upvalues: (copy) p_u_14, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11
				p_u_14.burst("Impact", p298, v_u_7, 0.9)
				if not p297.lite then
					local v299 = { v_u_7, v_u_9, v_u_11 }
					p_u_14.chunks(p298, v299, 3, 18, 0.35, 0.55, true, 0.8)
				end
			end
		}
	}
	return v300
end