local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF5FA8")
local v_u_9 = Color3.fromHex("FFF0F6")
local v_u_10 = Color3.fromRGB(70, 6, 44)
local v_u_11 = Color3.fromRGB(14, 8, 16)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.PartType.Ball
local v_u_14 = Enum.Material.SmoothPlastic
local function v_u_26(p15, p16, p17, p18, p19) -- name: disc
	-- upvalues: (copy) v_u_5
	local v20 = v_u_5.part
	local v21 = p16 * 2
	local v22 = p16 * 2
	local v23 = v20(Vector3.new(v21, 0.05, v22), p15, p18, {
		["transparency"] = 1
	})
	for _, v24 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v25 = Instance.new("Decal")
		v25.Face = v24
		v25.Texture = p17
		v25.Color3 = p18
		v25.Transparency = p19
		v25.Parent = v23
	end
	return v23
end
local function v_u_30(p27, p28) -- name: fadeDecals
	for _, v29 in p27:GetChildren() do
		if not v29:IsA("Decal") then
			continue
		end
		v29.Transparency = p28
	end
end
local function v_u_38(p31, p32, p33) -- name: newOrb
	-- upvalues: (copy) v_u_5, (copy) v_u_11, (copy) v_u_13, (copy) v_u_14, (copy) v_u_8, (copy) v_u_1
	local v34 = {
		["shape"] = v_u_13,
		["material"] = v_u_14
	}
	local v35 = v_u_5.part(Vector3.new(1, 1, 1) * p32, CFrame.new(p31), v_u_11, v34)
	v35.Reflectance = 0.25
	local v36 = {
		["shape"] = nil,
		["transparency"] = 0.45,
		["shape"] = v_u_13
	}
	local v37 = v_u_5.part(Vector3.new(1, 1, 1) * p32 * 1.3, CFrame.new(p31), v_u_8, v36)
	v_u_1:AddItem(v35, p33)
	v_u_1:AddItem(v37, p33)
	return {
		["core"] = v35,
		["rim"] = v37,
		["size"] = p32
	}
end
local function v_u_49(p39, p40, p41) -- name: placeOrb
	-- upvalues: (copy) v_u_4
	local v42 = p41 or p39.size
	if p41 then
		local v43 = p41 - p39.core.Size.X
		if math.abs(v43) > 0.001 then
			p39.core.Size = Vector3.new(1, 1, 1) * v42
			p39.rim.Size = Vector3.new(1, 1, 1) * v42 * 1.3
		end
	end
	p39.core.CFrame = CFrame.new(p40)
	local v44 = p39.rim
	local v45 = CFrame.new
	local v46 = v_u_4.CurrentCamera
	local v47
	if v46 then
		local v48 = v46.CFrame.Position - p40
		v47 = v48.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v48.Unit
	else
		v47 = Vector3.new(0, 0, 1)
	end
	v44.CFrame = v45(p40 - v47 * v42 * 0.4)
end
return function(p_u_50)
	-- upvalues: (copy) v_u_26, (copy) v_u_1, (copy) v_u_30, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_12, (copy) v_u_38, (copy) v_u_7, (copy) v_u_9, (copy) v_u_13, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_14, (copy) v_u_49, (copy) v_u_6
	local function v_u_66(p_u_51, p_u_52, p_u_53, p54, p55, p_u_56, p_u_57, p58) -- name: flare
		-- upvalues: (ref) v_u_26, (ref) v_u_1, (copy) p_u_50, (ref) v_u_30
		local v_u_59 = p58 or 0
		local v_u_60 = v_u_26(p_u_51, p_u_52, p54, p55, v_u_59)
		v_u_1:AddItem(v_u_60, p_u_56 + 0.1)
		p_u_50.animate(p_u_56, 0, function(p61)
			-- upvalues: (copy) p_u_52, (copy) p_u_53, (copy) v_u_60, (copy) p_u_51, (copy) p_u_56, (copy) p_u_57, (ref) v_u_30, (copy) v_u_59
			local v62 = p_u_52 + (p_u_53 - p_u_52) * (1 - (1 - p61) ^ 3)
			local v63 = v_u_60
			local v64 = v62 * 2
			local v65 = v62 * 2
			v63.Size = Vector3.new(v64, 0.05, v65)
			v_u_60.CFrame = p_u_51 * CFrame.Angles(0, p61 * p_u_56 * p_u_57, 0)
			v_u_30(v_u_60, v_u_59 + (1 - v_u_59) * p61 ^ 1.5)
			if p61 >= 1 then
				v_u_60:Destroy()
			end
		end)
	end
	local function v_u_76(p_u_67, p_u_68, p_u_69, p70, p71) -- name: fling
		-- upvalues: (copy) p_u_50, (ref) v_u_8, (ref) v_u_1
		local v_u_72 = p_u_50.ball(p_u_67, p70, p_u_69)
		p_u_50.streak(v_u_72, p70, v_u_8, p_u_69 * 0.8, 0.1)
		v_u_1:AddItem(v_u_72, p71 + 0.2)
		p_u_50.animate(p71, 0, function(p73)
			-- upvalues: (copy) v_u_72, (copy) p_u_67, (copy) p_u_68, (copy) p_u_69
			v_u_72.CFrame = CFrame.new(p_u_67 + p_u_68 * (1 - (1 - p73) ^ 3))
			local v74 = v_u_72
			local v75 = p_u_69 * (1 - p73)
			v74.Size = Vector3.new(1, 1, 1) * math.max(v75, 0.05)
			if p73 >= 1 then
				v_u_72:Destroy()
			end
		end)
	end
	local v_u_77 = 0
	local function v_u_81() -- name: pinkFrame
		-- upvalues: (ref) v_u_77, (ref) v_u_2, (ref) v_u_5, (copy) p_u_50, (ref) v_u_12, (ref) v_u_1
		local v78 = os.clock()
		if v78 >= v_u_77 then
			v_u_77 = v78 + 0.5
			local v_u_79 = Instance.new("ColorCorrectionEffect")
			v_u_79.Name = "TrinityBeam"
			v_u_79.Parent = v_u_2
			v_u_5.tween(v_u_79, 0.05, {
				["TintColor"] = nil,
				["Contrast"] = 0.2,
				["Saturation"] = 0.2,
				["TintColor"] = Color3.fromRGB(255, 215, 235)
			})
			p_u_50.after(0.1, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_79, (ref) v_u_12
				local v80 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_12
				}
				v_u_5.tween(v_u_79, 0.35, v80)
			end)
			v_u_1:AddItem(v_u_79, 0.5)
		end
	end
	local function v112(p82, p83) -- name: flickShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_38, (ref) v_u_26, (ref) v_u_7, (ref) v_u_1, (ref) v_u_9, (ref) v_u_13, (copy) p_u_50, (ref) v_u_10, (ref) v_u_4
		local v_u_84 = p82.size
		local v_u_85 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p83, v_u_8, {
			["transparency"] = 1
		})
		local v_u_86 = v_u_38(p83.Position, 1.05 * v_u_84, 3)
		local v_u_87 = { v_u_86.core, v_u_86.rim }
		local v_u_88
		if p82.lite then
			v_u_88 = nil
		else
			v_u_88 = v_u_26(p83, 1.15 * v_u_84, v_u_7.Ring, v_u_8, 0)
			v_u_1:AddItem(v_u_88, 3)
			table.insert(v_u_87, v_u_88)
		end
		local v_u_89 = {}
		for _ = 1, 2 do
			local v90 = {
				["shape"] = v_u_13
			}
			local v91 = v_u_5.part(Vector3.new(0.38, 0.38, 0.38) * v_u_84, p83, v_u_9, v90)
			v_u_1:AddItem(v91, 3)
			table.insert(v_u_89, v91)
			table.insert(v_u_87, v91)
		end
		p_u_50.streak(v_u_85, v_u_8, v_u_10, 1.1 * v_u_84, 0.13)
		if p82.mine then
			p_u_50.light(v_u_85, v_u_8, 9 * v_u_84)
		end
		v_u_1:AddItem(v_u_85, 3)
		local v_u_92 = false
		return {
			["place"] = function(p93, p94) -- name: place
				-- upvalues: (copy) v_u_85, (copy) v_u_86, (ref) v_u_4, (ref) v_u_88, (ref) p_u_50, (copy) v_u_84, (copy) v_u_89
				local v95 = p93.Position
				v_u_85.CFrame = p93
				local v96 = v_u_86
				local v97 = v96.size
				v96.core.CFrame = CFrame.new(v95)
				local v98 = v96.rim
				local v99 = CFrame.new
				local v100 = v_u_4.CurrentCamera
				local v101
				if v100 then
					local v102 = v100.CFrame.Position - v95
					v101 = v102.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v102.Unit
				else
					v101 = Vector3.new(0, 0, 1)
				end
				v98.CFrame = v99(v95 - v101 * v97 * 0.4)
				local v103 = v_u_88
				if v103 then
					local v104 = v_u_4.CurrentCamera
					local v105
					if v104 then
						local v106 = v104.CFrame.Position - v95
						v105 = v106.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v106.Unit
					else
						v105 = Vector3.new(0, 0, 1)
					end
					v103.CFrame = p_u_50.facing(v95 - v105 * 0.3 * v_u_84, v105)
				end
				for v107, v108 in v_u_89 do
					local v109 = p94 * 19 + v107 * 3.141592653589793
					v108.CFrame = p93 * CFrame.Angles(0.55, 0, 0) * CFrame.new(math.cos(v109) * 1.3 * v_u_84, math.sin(v109) * 1.3 * v_u_84, 0)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_92, (copy) v_u_85, (ref) v_u_1, (copy) v_u_87
				if not v_u_92 then
					v_u_92 = true
					local v110 = v_u_85:FindFirstChildWhichIsA("PointLight")
					if v110 then
						v110:Destroy()
					end
					v_u_1:AddItem(v_u_85, 0.15)
					for _, v111 in v_u_87 do
						v111:Destroy()
					end
				end
			end
		}
	end
	local function v120(p113, p114) -- name: flickImpact
		-- upvalues: (ref) v_u_4, (copy) v_u_66, (copy) p_u_50, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14, (copy) v_u_76, (ref) v_u_9
		local v115 = p113.size
		local v116 = v_u_4.CurrentCamera
		local v117
		if v116 then
			local v118 = v116.CFrame.Position - p114
			v117 = v118.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v118.Unit
		else
			v117 = Vector3.new(0, 0, 1)
		end
		v_u_66(p_u_50.facing(p114 - v117 * 0.2, v117), 1 * v115, 3.8 * v115, v_u_7.Ring, v_u_8, 0.2, 0, 0)
		p_u_50.pop(p114, v_u_11, 1.1 * v115, 2.5 * v115, 0.14, 0, v_u_14)
		p_u_50.pop(p114, v_u_8, 1.4 * v115, 4.4 * v115, 0.18, 0.35)
		p_u_50.burst("Impact", p114, v_u_8, 0.8 * v115)
		if not p113.lite then
			local v119 = p_u_50.flatUnit(v117):Cross(Vector3.new(0, 1, 0))
			v_u_76(p114, (v119 + Vector3.new(0, 0.4, 0)) * 3.5 * v115, 0.4 * v115, v_u_9, 0.2)
			v_u_76(p114, (-v119 + Vector3.new(0, 0.2, 0)) * 3.5 * v115, 0.4 * v115, v_u_9, 0.2)
			p_u_50.spikes(p114, v_u_9, 3, 3 * v115, 0.12)
		end
		p_u_50.hitSound(p114)
	end
	local v_u_121 = {}
	setmetatable(v_u_121, {
		["__mode"] = "k"
	})
	local function v_u_142(p122, p123, p124) -- name: dropOrbs
		-- upvalues: (copy) p_u_50, (ref) v_u_38, (ref) v_u_8, (ref) v_u_10, (ref) v_u_49, (copy) v_u_121
		local v125 = p122.size
		local v126 = p122.ability.radius * 0.8 * v125
		local v_u_127 = {
			["orbs"] = nil,
			["angle"] = nil,
			["landed"] = false,
			["orbs"] = {},
			["angle"] = math.random() * 3.141592653589793 * 2
		}
		local v128 = p124 + (p122.ability.freeze or 2.5) + 2
		for v129 = 1, 3 do
			local v130 = v_u_127.angle + (v129 - 1) * 3.141592653589793 * 2 / 3
			local v131 = 1.4 * v125
			local v132 = p_u_50.ground(p123, v131)
			local v133 = math.cos(v130) * v126
			local v134 = math.sin(v130) * v126
			local v_u_135 = v132 + Vector3.new(v133, 0, v134)
			local v136 = math.cos(v130) * 6
			local v137 = math.sin(v130) * 6
			local v_u_138 = v_u_135 + Vector3.new(v136, 34, v137)
			local v_u_139 = v_u_38(v_u_138, 2.6 * v125, v128)
			p_u_50.streak(v_u_139.core, v_u_8, v_u_10, 1.8 * v125, 0.2)
			local v140 = v_u_127.orbs
			table.insert(v140, v_u_139)
			p_u_50.animate(math.max(p124, 0.03), 0, function(p141)
				-- upvalues: (copy) v_u_127, (ref) v_u_49, (copy) v_u_139, (copy) v_u_138, (copy) v_u_135
				if not v_u_127.landed then
					v_u_49(v_u_139, v_u_138:Lerp(v_u_135, p141 * p141))
				end
			end)
		end
		v_u_121[p122] = v_u_127
		return v_u_127
	end
	local v_u_143 = 0
	local function v_u_169(p_u_144, p_u_145) -- name: smallLock
		-- upvalues: (ref) v_u_143, (ref) v_u_26, (ref) v_u_7, (ref) v_u_8, (ref) v_u_5, (ref) v_u_11, (ref) v_u_13, (ref) v_u_14, (ref) v_u_1, (copy) p_u_50, (ref) v_u_30
		if v_u_143 < 14 then
			v_u_143 = v_u_143 + 1
			local v_u_146 = v_u_26(CFrame.new(p_u_144), 1.6, v_u_7.Ring, v_u_8, 0)
			local v147 = {
				["shape"] = v_u_13,
				["material"] = v_u_14
			}
			local v_u_148 = v_u_5.part(Vector3.new(0.55, 0.55, 0.55), CFrame.new(p_u_144), v_u_11, v147)
			v_u_1:AddItem(v_u_146, p_u_145 + 1)
			v_u_1:AddItem(v_u_148, p_u_145 + 1)
			local v_u_149 = os.clock()
			p_u_50.runNow(function()
				-- upvalues: (copy) v_u_149, (copy) p_u_145, (copy) v_u_146, (copy) p_u_144, (ref) v_u_30, (copy) v_u_148, (ref) v_u_143
				local v150 = os.clock() - v_u_149
				local v151 = v150 / 0.1
				local v152 = math.min(v151, 1)
				local v153 = (v150 - p_u_145) / 0.2
				local v154 = math.clamp(v153, 0, 1)
				local v155 = v152 * 1.6 * (v154 * 0.8 + 1)
				local v156 = v_u_146
				local v157 = v155 * 2
				local v158 = math.max(v157, 0.05)
				local v159 = v155 * 2
				local v160 = math.max(v159, 0.05)
				v156.Size = Vector3.new(v158, 0.05, v160)
				v_u_146.CFrame = CFrame.new(p_u_144) * CFrame.Angles(0.15, v150 * 2, 0)
				v_u_30(v_u_146, v154)
				local v161 = v150 * 9
				local v162 = v_u_148
				local v163 = CFrame.new
				local v164 = p_u_144
				local v165 = math.cos(v161) * v155
				local v166 = v161 * 2
				local v167 = math.sin(v166) * 0.3
				local v168 = math.sin(v161) * v155
				v162.CFrame = v163(v164 + Vector3.new(v165, v167, v168))
				v_u_148.Transparency = v154
				if v154 < 1 and v_u_146.Parent then
					return true
				end
				v_u_146:Destroy()
				v_u_148:Destroy()
				v_u_143 = v_u_143 - 1
				return false
			end)
		end
	end
	local v_u_170 = {}
	setmetatable(v_u_170, {
		["__mode"] = "k"
	})
	local function v_u_174(p171) -- name: endTri
		if not p171.done then
			p171.done = true
			for _, v172 in p171.orbs do
				v172.core:Destroy()
				v172.rim:Destroy()
			end
			for _, v173 in p171.lines do
				v173:Destroy()
			end
			p171.core:Destroy()
			p171.glow:Destroy()
		end
	end
	local function v_u_229(p175, p176, p_u_177) -- name: startTri
		-- upvalues: (copy) p_u_50, (ref) v_u_12, (ref) v_u_8, (ref) v_u_1, (ref) v_u_38, (ref) v_u_10, (ref) v_u_5, (ref) v_u_9, (copy) v_u_170, (ref) v_u_49, (copy) v_u_174
		local v_u_178 = p175.size
		local v179 = p_u_50.flatUnit(p175.dir)
		local v_u_180 = v179:Cross(Vector3.new(0, 1, 0)).Unit
		local v_u_181 = p176 + v179 * 4.5 * v_u_178
		local v182 = p_u_177 + 3
		local v_u_183 = { p176 - v_u_180 * 2.6 * v_u_178 - v179 * 1.2 * v_u_178 + Vector3.new(0, 0.4, 0) * v_u_178, p176 + v_u_180 * 2.6 * v_u_178 - v179 * 1.2 * v_u_178 + Vector3.new(0, 0.4, 0) * v_u_178, p176 + Vector3.new(0, 3.4, 0) * v_u_178 - v179 * 1.5 * v_u_178 }
		local v_u_184 = {
			["orbs"] = nil,
			["lines"] = nil,
			["core"] = nil,
			["glow"] = nil,
			["center"] = nil,
			["fireAt"] = nil,
			["done"] = false,
			["orbs"] = {},
			["lines"] = {},
			["core"] = p_u_50.ball(v_u_181, v_u_12, 0.3 * v_u_178),
			["glow"] = p_u_50.ball(v_u_181, v_u_8, 1 * v_u_178, 0.6),
			["center"] = v_u_181
		}
		v_u_1:AddItem(v_u_184.core, v182)
		v_u_1:AddItem(v_u_184.glow, v182)
		for v185 = 1, 3 do
			local v186 = v_u_38(v_u_183[v185], 2.3 * v_u_178, v182)
			local v187 = v_u_184.orbs
			table.insert(v187, v186)
			if not p175.lite then
				p_u_50.streak(v186.core, v_u_8, v_u_10, 1.2 * v_u_178, 0.15)
			end
			local v188 = v_u_5.part(Vector3.new(0.22, 0.22, 1) * v_u_178, CFrame.new(v_u_181), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v188, v182)
			local v189 = v_u_184.lines
			table.insert(v189, v188)
		end
		p_u_50.sigil(p_u_50.facing(v_u_181 + v179 * 0.2 * v_u_178, v179), 2.4 * v_u_178, v_u_12, p_u_50.iris("blossom_orbit"), p_u_177 + 0.5, 0)
		if not p175.lite then
			p_u_50.inward(v_u_181, v_u_8, 7, 8 * v_u_178, (math.max(p_u_177, 0.12)))
			p_u_50.inward(v_u_181, v_u_9, 4, 6 * v_u_178, (math.max(p_u_177, 0.12)))
			if p175.mine then
				p_u_50.light(v_u_184.glow, v_u_8, 16)
			end
		end
		v_u_170[p175] = v_u_184
		local v_u_190 = os.clock()
		local v_u_191 = 0
		local v_u_192 = v_u_190
		local v_u_193 = v_u_190 + p_u_177 + 1
		p_u_50.runNow(function()
			-- upvalues: (copy) v_u_184, (ref) v_u_192, (copy) v_u_190, (copy) p_u_177, (ref) v_u_191, (copy) v_u_178, (copy) v_u_181, (copy) v_u_180, (copy) v_u_183, (ref) v_u_49, (copy) v_u_193, (ref) v_u_174
			if v_u_184.done then
				return false
			end
			local v194 = os.clock()
			local v195 = v194 - v_u_192
			local v196 = math.min(v195, 0.05)
			v_u_192 = v194
			local v197 = v194 - v_u_190
			local v198 = p_u_177
			local v199 = v197 / math.max(v198, 0.05)
			local v200 = 1 - (1 - math.clamp(v199, 0, 1)) ^ 3
			local v201 = v_u_184.fireAt
			local v202 = not v201 and 0 or v194 - v201
			v_u_191 = v_u_191 + v196 * (v200 * 5 + 2.5 + (v201 and 14 or 0))
			local v203 = 3.4 * v_u_178 * (v200 * 0.45 + 0.55)
			local v204 = v202 * 0.6
			local v205 = v203 * (math.min(v204, 0.3) + 1)
			local v206
			if v201 then
				local v207 = (v202 - 0.3) / 0.18
				v206 = math.clamp(v207, 0, 1)
			else
				v206 = 0
			end
			local v208 = {}
			for v209, v210 in v_u_184.orbs do
				local v211 = 1.5707963267948966 + (v209 - 1) * 3.141592653589793 * 2 / 3 + v_u_191
				local v212 = v_u_181 + (v_u_180 * math.cos(v211) + Vector3.new(0, 1, 0) * math.sin(v211)) * v205
				local v213 = v_u_183[v209]:Lerp(v212, v200)
				if v206 > 0 then
					v213 = v212 + (v212 - v_u_181).Unit * v206 * 7 * v_u_178
				end
				v_u_49(v210, v213, 2.3 * v_u_178 * (1 - v206 * 0.7))
				v210.core.Transparency = v206
				v210.rim.Transparency = v206 * 0.55 + 0.45
				v208[v209] = v213
			end
			for v214, v215 in v_u_184.lines do
				local v216 = v208[v214]
				local v217 = v208[v214 % 3 + 1]
				local v218 = (v217 - v216).Magnitude
				local v219 = 0.22 * v_u_178
				local v220 = 0.22 * v_u_178
				local v221 = math.max(v218, 0.1)
				v215.Size = Vector3.new(v219, v220, v221)
				v215.CFrame = CFrame.lookAt((v216 + v217) / 2, v217)
				v215.Transparency = v200 < 0.35 and 1 or v206 * 0.9 + 0.1
			end
			if v201 then
				local v222 = 1 - v202 * 4
				v200 = math.max(v222, 0)
			end
			local v223 = v_u_184.core
			local v224 = (v200 * 1.6 + 0.3) * v_u_178
			v223.Size = Vector3.new(1, 1, 1) * math.max(v224, 0.05)
			local v225 = v_u_184.glow
			local v226 = (v200 * 3 + 1) * v_u_178
			local v227 = v197 * 40
			local v228 = v226 * (math.sin(v227) * 0.05 + 1)
			v225.Size = Vector3.new(1, 1, 1) * math.max(v228, 0.05)
			if v206 < 1 and (v201 or v_u_193 >= v194) then
				return true
			end
			v_u_174(v_u_184)
			return false
		end)
		return v_u_184
	end
	local function v_u_265(p230, p_u_231, p232, p_u_233) -- name: strands
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (copy) p_u_50, (ref) v_u_4
		local v_u_234 = p230.size
		local v_u_235 = p232 - p_u_231
		local v236 = v_u_235.Magnitude
		if v236 >= 1 then
			local v237 = v_u_235.Unit
			local v238 = v237:Cross(Vector3.new(0, 1, 0))
			local v_u_239 = v238.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v238.Unit
			local v_u_240 = v_u_239:Cross(v237).Unit
			local v241 = v236 / 6
			local v242 = math.floor(v241)
			local v_u_243 = math.clamp(v242, 4, 15)
			local v_u_244 = {}
			for _ = 1, v_u_243 * 3 do
				local v245 = v_u_5.part(Vector3.new(0.35, 0.35, 1) * v_u_234, CFrame.new(p_u_231), v_u_8)
				v_u_1:AddItem(v245, p_u_233 + 0.2)
				table.insert(v_u_244, v245)
			end
			local v_u_246 = table.create(#v_u_244, CFrame.identity)
			local v_u_247 = os.clock()
			p_u_50.runNow(function()
				-- upvalues: (copy) v_u_247, (copy) p_u_233, (copy) v_u_234, (copy) p_u_231, (copy) v_u_235, (copy) v_u_243, (ref) v_u_239, (copy) v_u_240, (copy) v_u_246, (copy) v_u_244, (ref) v_u_4
				local v248 = os.clock() - v_u_247
				local v249 = v248 / p_u_233
				local v250 = math.clamp(v249, 0, 1)
				local v251 = 2.3 * v_u_234 * (v250 * 0.5 + 1)
				local v252 = 0.35 * v_u_234 * (1 - v250)
				local v253 = math.max(v252, 0.05)
				for v254 = 0, 2 do
					for v255 = 1, v_u_243 do
						local v256 = v255 - 1
						local v257 = v248 * 16 + v256 * 0.62 + v254 * 3.141592653589793 * 2 / 3
						local v258 = p_u_231 + v_u_235 * (v256 / v_u_243) + (v_u_239 * math.cos(v257) + v_u_240 * math.sin(v257)) * v251
						local v259 = v248 * 16 + v255 * 0.62 + v254 * 3.141592653589793 * 2 / 3
						local v260 = p_u_231 + v_u_235 * (v255 / v_u_243) + (v_u_239 * math.cos(v259) + v_u_240 * math.sin(v259)) * v251
						local v261 = v254 * v_u_243 + v255
						v_u_246[v261] = CFrame.lookAt((v258 + v260) / 2, v260)
						local v262 = v_u_244[v261]
						local v263 = (v260 - v258).Magnitude + 0.2
						v262.Size = Vector3.new(v253, v253, v263)
					end
				end
				v_u_4:BulkMoveTo(v_u_244, v_u_246, Enum.BulkMoveMode.FireCFrameChanged)
				if v250 < 1 then
					return true
				end
				for _, v264 in v_u_244 do
					v264:Destroy()
				end
				return false
			end)
		end
	end
	local function v_u_271(p266, p267) -- name: beamEnd
		-- upvalues: (copy) p_u_50, (ref) v_u_5, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14, (ref) v_u_7, (ref) v_u_10, (ref) v_u_9, (ref) v_u_6
		local v_u_268 = p266.size
		local v_u_269 = p_u_50.ground(p267)
		v_u_5.flash(p267, v_u_8, 16 * v_u_268, 0.16)
		p_u_50.pop(p267, v_u_11, 3 * v_u_268, 11 * v_u_268, 0.32, 0.05, v_u_14)
		p_u_50.pop(p267, v_u_8, 4 * v_u_268, 15 * v_u_268, 0.38, 0.4)
		p_u_50.burst("Explosion", p267, v_u_8, 1.4 * v_u_268)
		v_u_5.ring(v_u_269, v_u_8, 14 * v_u_268, 0.45, v_u_7.Shockwave)
		p_u_50.mark(p267, v_u_10, 6 * v_u_268, 2, v_u_7.CrackGlow, 0.1)
		if not p266.lite then
			p_u_50.after(0.05, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_269, (ref) v_u_9, (copy) v_u_268, (ref) v_u_7
				v_u_5.ring(v_u_269, v_u_9, 17 * v_u_268, 0.4, v_u_7.Ring)
			end)
			p_u_50.burst("Shockwave", v_u_269 + Vector3.new(0, 0.3, 0), v_u_8, 0.8 * v_u_268)
			p_u_50.spikes(p267, v_u_8, 8, 9 * v_u_268, 0.25)
			local v270 = { v_u_11, v_u_8, v_u_11 }
			p_u_50.chunks(p267, v270, 9, 40, 0.7, 1, false, 0.9)
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_269,
			["volume"] = p266.mine and 0.8 or 0.5
		})
	end
	local v424 = {
		["blossom_orbit_a"] = {
			["cast"] = function(p272) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_50, (ref) v_u_9, (copy) v_u_66, (ref) v_u_7
				local v273 = p272.size
				local v274 = p272.eye + p272.dir * 1.2
				v_u_5.flash(v274, v_u_8, 2.8 * v273, 0.1)
				p_u_50.pop(v274, v_u_9, 0.9 * v273, 0.2 * v273, 0.1)
				if not p272.lite then
					v_u_66(p_u_50.facing(v274, p272.dir), 0.5 * v273, 2.2 * v273, v_u_7.Ring, v_u_8, 0.12, 0, 0.1)
				end
			end,
			["shot"] = v112,
			["impact"] = v120,
			["hit"] = function(_, p275, _) -- name: hit
				-- upvalues: (copy) p_u_50, (ref) v_u_8
				p_u_50.burst("Impact", p275, v_u_8, 0.6)
			end
		},
		["blossom_orbit_e"] = {
			["cast"] = function(p276) -- name: cast
				-- upvalues: (copy) p_u_50, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14, (ref) v_u_10, (ref) v_u_5, (ref) v_u_1
				p_u_50.skillCast(p276, v_u_8)
				local v277 = p276.size
				local v278 = p276.eye + Vector3.new(0, 2.4, 0) * v277
				for v279 = 1, 3 do
					local v280 = 1.5707963267948966 + (v279 - 1) * 3.141592653589793 * 2 / 3
					local v281 = math.cos(v280)
					local v282 = math.sin(v280)
					local v283 = v278 + Vector3.new(v281, 0, v282) * 1.6 * v277
					local v284 = p_u_50.ball(v283, v_u_11, 0.9 * v277, 0, v_u_14)
					p_u_50.streak(v284, v_u_8, v_u_10, 0.8 * v277, 0.15)
					v_u_5.tween(v284, 0.18, {
						["CFrame"] = CFrame.new(v283 + Vector3.new(0, 14, 0))
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v284, 0.2)
				end
				v_u_5.flash(v278, v_u_8, 4 * v277, 0.14)
			end,
			["windup"] = function(p285, p286, p287) -- name: windup
				-- upvalues: (copy) v_u_142, (copy) v_u_66, (copy) p_u_50, (ref) v_u_7, (ref) v_u_8
				local v288 = p285.ability.radius * p285.size
				v_u_142(p285, p286, p287)
				v_u_66(CFrame.new(p_u_50.ground(p286, 0.15)), v288 * 1.4, v288 * 0.95, v_u_7.Ring, v_u_8, math.max(p287, 0.1) + 0.05, 2, 0.25)
			end,
			["land"] = function(p289, p_u_290) -- name: land
				-- upvalues: (copy) v_u_121, (copy) v_u_142, (copy) p_u_50, (ref) v_u_4, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_9, (ref) v_u_26, (ref) v_u_1, (ref) v_u_30
				local v_u_291 = p289.size
				local v_u_292 = p289.lite
				local v_u_293 = p289.ability.radius * v_u_291
				local v_u_294 = v_u_293 * 0.8
				local v_u_295 = p289.ability.freeze or 2.5
				local v_u_296 = v_u_121[p289] or v_u_142(p289, p_u_290, 0)
				v_u_121[p289] = nil
				v_u_296.landed = true
				local v297 = v_u_295 + 1.5
				for v298, v299 in v_u_296.orbs do
					local v300 = v_u_296.angle + (v298 - 1) * 3.141592653589793 * 2 / 3
					local v301 = p_u_50.ground(p_u_290, 0)
					local v302 = math.cos(v300) * v_u_294
					local v303 = math.sin(v300) * v_u_294
					local v304 = v301 + Vector3.new(v302, 0, v303)
					local v305 = 1.4 * v_u_291
					local v306 = p_u_50.ground(p_u_290, v305)
					local v307 = math.cos(v300) * v_u_294
					local v308 = math.sin(v300) * v_u_294
					local v309 = v306 + Vector3.new(v307, 0, v308)
					local v310 = v299.size
					v299.core.CFrame = CFrame.new(v309)
					local v311 = v299.rim
					local v312 = CFrame.new
					local v313 = v_u_4.CurrentCamera
					local v314
					if v313 then
						local v315 = v313.CFrame.Position - v309
						v314 = v315.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v315.Unit
					else
						v314 = Vector3.new(0, 0, 1)
					end
					v311.CFrame = v312(v309 - v314 * v310 * 0.4)
					p_u_50.burst("Impact", v304 + Vector3.new(0, 1, 0), v_u_8, 1.2 * v_u_291)
					v_u_5.ring(p_u_50.ground(v304), v_u_8, 4.5 * v_u_291, 0.3, v_u_7.Ring)
					p_u_50.mark(v304, v_u_10, 2.6 * v_u_291, 1.6, v_u_7.CrackGlow, 0.15)
					if v_u_292 then
						continue
					end
					p_u_50.chunks(p_u_50.ground(v304, 0.5), { p_u_50.EARTH[1], p_u_50.EARTH[2], v_u_11 }, 4, 26, 0.6, 0.9)
				end
				v_u_5.ring(p_u_50.ground(p_u_290), v_u_8, v_u_293 * 1.15, 0.4, v_u_7.Shockwave)
				local v_u_316 = p_u_50.newRig()
				local v317 = v_u_292 and 12 or 24
				local v318 = 2 * v_u_294
				local v319 = 3.141592653589793 / v317
				local v320 = v318 * math.sin(v319) + 0.3
				for v321 = 1, v317 do
					local v322 = (v321 - 0.5) / v317 * 3.141592653589793 * 2
					local v323 = math.cos(v322) * v_u_294
					local v324 = math.sin(v322) * v_u_294
					local v325 = Vector3.new(v323, 0, v324)
					local v326 = -math.sin(v322)
					local v327 = math.cos(v322)
					local v328 = Vector3.new(v326, 0, v327)
					local v329 = p_u_50.rigAdd
					local v330 = 0.7 * v_u_291
					local v331 = 0.55 * v_u_291
					v329(v_u_316, Vector3.new(v330, v331, v320), CFrame.lookAt(v325, v325 + v328), v_u_8, 0, nil, v297 + 1)
					if v_u_292 then
						continue
					end
					local v332 = p_u_50.rigAdd
					local v333 = 0.12 * v_u_291
					local v334 = 1.9 * v_u_291
					v332(v_u_316, Vector3.new(v333, v334, v320), CFrame.lookAt(v325, v325 + v328), v_u_9, 0.55, nil, v297 + 1)
				end
				local v_u_335 = v_u_26(CFrame.identity, v_u_294 * 1.15, v_u_7.Ring, v_u_8, 0)
				v_u_1:AddItem(v_u_335, v297 + 1)
				local v_u_336 = {}
				if not v_u_292 then
					for _ = 1, 3 do
						local v337 = v_u_26(CFrame.identity, 1.3 * v_u_291, v_u_7.Ring, v_u_9, 0)
						v_u_1:AddItem(v337, v297 + 1)
						table.insert(v_u_336, v337)
					end
				end
				local v_u_338 = p_u_50.ground(p_u_290, 2.6 * v_u_291)
				p_u_50.burst("Flash", v_u_338, v_u_8, 0.5 * v_u_291)
				if p289.mine then
					v_u_5.shake(0.25, 0.2)
				end
				p_u_50.hitSound(p_u_290, true)
				local v_u_339 = os.clock()
				local v_u_340 = v_u_339
				local v_u_341 = v_u_296.angle
				local v_u_342 = table.create(#v_u_316.parts, CFrame.identity)
				local v_u_343 = -1
				local function v_u_352(p344, p345) -- name: placeBand
					-- upvalues: (copy) v_u_316, (copy) v_u_342, (ref) v_u_4, (ref) v_u_343
					local v346 = math.max(p345, 0.02)
					for v347, v348 in v_u_316.offs do
						v_u_342[v347] = p344 * (v348 - v348.Position + v348.Position * v346)
					end
					v_u_4:BulkMoveTo(v_u_316.parts, v_u_342, Enum.BulkMoveMode.FireCFrameChanged)
					local v349 = v346 - v_u_343
					if math.abs(v349) > 0.01 then
						v_u_343 = v346
						for v350, v351 in v_u_316.parts do
							v351.Size = v_u_316.sizes[v350] * v346
						end
					end
				end
				p_u_50.runNow(function()
					-- upvalues: (copy) v_u_339, (ref) v_u_340, (ref) v_u_341, (copy) v_u_295, (copy) v_u_291, (copy) v_u_296, (copy) p_u_290, (copy) v_u_294, (ref) p_u_50, (ref) v_u_4, (copy) v_u_352, (copy) v_u_338, (copy) v_u_316, (copy) v_u_335, (ref) v_u_30, (copy) v_u_336
					local v353 = os.clock()
					local v354 = v353 - v_u_339
					local v355 = v353 - v_u_340
					local v356 = math.min(v355, 0.05)
					v_u_340 = v353
					local v357 = v_u_341
					local v358 = 1 - v354 / 0.6
					v_u_341 = v357 + v356 * (math.max(v358, 0) * 6 + 2.2)
					local v359 = v354 / 0.15
					local v360 = 1 - (1 - math.clamp(v359, 0, 1)) ^ 3
					local v361 = (v354 - v_u_295) / 0.35
					local v362 = math.clamp(v361, 0, 1)
					local v363 = (v360 * 1.2000000000000002 + 1.4) * v_u_291
					for v364, v365 in v_u_296.orbs do
						local v366 = v_u_341 + (v364 - 1) * 3.141592653589793 * 2 / 3
						local v367 = p_u_290
						local v368 = v_u_294 * (v362 * 0.6 + 1)
						local v369 = v354 * 3 + v364 * 2
						local v370 = v363 + math.sin(v369) * 0.25 + v362 * 18
						local v371 = p_u_50.ground(v367, v370)
						local v372 = math.cos(v366) * v368
						local v373 = math.sin(v366) * v368
						local v374 = v371 + Vector3.new(v372, 0, v373)
						local v375 = v365.size
						v365.core.CFrame = CFrame.new(v374)
						local v376 = v365.rim
						local v377 = CFrame.new
						local v378 = v_u_4.CurrentCamera
						local v379
						if v378 then
							local v380 = v378.CFrame.Position - v374
							v379 = v380.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v380.Unit
						else
							v379 = Vector3.new(0, 0, 1)
						end
						v376.CFrame = v377(v374 - v379 * v375 * 0.4)
						v365.core.Transparency = v362
						v365.rim.Transparency = v362 * 0.55 + 0.45
					end
					local v381 = v354 / 0.09
					local v382 = math.clamp(v381, 0, 1)
					local v383 = 1.35 - v382 * 0.35 * v382
					local v384 = v354 * 6
					local v385 = v383 + math.sin(v384) * 0.015 + v362 * 0.7
					v_u_352(CFrame.new(v_u_338) * CFrame.Angles(0, -v_u_341 * 0.15, 0), v385)
					if v362 > 0 then
						p_u_50.rigFade(v_u_316, v362)
					end
					local v386 = v_u_294 * 1.15 * v385
					local v387 = v_u_335
					local v388 = v386 * 2
					local v389 = v386 * 2
					v387.Size = Vector3.new(v388, 0.05, v389)
					v_u_335.CFrame = CFrame.new(v_u_338)
					local v390 = v_u_30
					local v391 = v_u_335
					local v392 = 1 - v382
					v390(v391, (math.max(v362, v392)))
					for v393, v394 in v_u_336 do
						local v395 = -v_u_341 * 1.6 + (v393 - 1) * 3.141592653589793 * 2 / 3
						local v396 = v_u_338 + Vector3.new(0, 0.6, 0)
						local v397 = math.cos(v395)
						local v398 = math.sin(v395)
						local v399 = v396 + Vector3.new(v397, 0, v398) * v_u_294 * 0.38
						local v400 = p_u_50.facing
						local v401 = v_u_4.CurrentCamera
						local v402
						if v401 then
							local v403 = v401.CFrame.Position - v399
							v402 = v403.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v403.Unit
						else
							v402 = Vector3.new(0, 0, 1)
						end
						v394.CFrame = v400(v399, v402)
						local v404 = 1.3 * v_u_291 * 2 * v360 * (v362 + 1)
						local v405 = math.max(v404, 0.05)
						v394.Size = Vector3.new(v405, 0.05, v405)
						v_u_30(v394, v362)
					end
					if v362 < 1 then
						return true
					end
					for _, v406 in v_u_296.orbs do
						v406.core:Destroy()
						v406.rim:Destroy()
					end
					p_u_50.rigDestroy(v_u_316)
					v_u_335:Destroy()
					for _, v407 in v_u_336 do
						v407:Destroy()
					end
					return false
				end)
				p_u_50.after(v_u_295, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_338, (ref) v_u_8, (copy) v_u_294, (ref) p_u_50, (copy) p_u_290, (ref) v_u_9, (copy) v_u_293, (ref) v_u_7, (copy) v_u_292
					v_u_5.flash(v_u_338, v_u_8, v_u_294, 0.15)
					v_u_5.ring(p_u_50.ground(p_u_290), v_u_9, v_u_293 * 1.3, 0.35, v_u_7.Ring)
					if not v_u_292 then
						p_u_50.spikes(v_u_338, v_u_8, 8, v_u_294 * 0.8, 0.25, nil, nil, true)
					end
				end)
			end,
			["hit"] = function(p408, p409, _) -- name: hit
				-- upvalues: (copy) v_u_169, (copy) p_u_50, (ref) v_u_8
				if not p408.lite then
					v_u_169(p409, p408.ability.freeze or 2.5)
				end
				p_u_50.burst("Impact", p409, v_u_8, 0.6)
			end
		},
		["blossom_orbit_r"] = {
			["cast"] = function(p410) -- name: cast
				-- upvalues: (copy) p_u_50, (ref) v_u_8, (ref) v_u_9
				p_u_50.skillCast(p410, v_u_8, true)
				p_u_50.glint(p410.eye, v_u_9, 6, 0.2)
			end,
			["windup"] = function(p411, p412, p413) -- name: windup
				-- upvalues: (copy) v_u_229, (ref) v_u_5
				v_u_229(p411, p412, p413)
				if p411.mine then
					v_u_5.shake(0.12, (math.max(p413, 0.1)))
				end
			end,
			["beam"] = function(p414, p415, p416) -- name: beam
				-- upvalues: (copy) v_u_170, (copy) p_u_50, (ref) v_u_5, (ref) v_u_8, (ref) v_u_12, (copy) v_u_66, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11, (ref) v_u_14, (copy) v_u_265, (copy) v_u_271, (copy) v_u_81
				local v417 = p414.size
				local v418 = v_u_170[p414]
				v_u_170[p414] = nil
				local v419
				if v418 then
					v419 = v418.center
				else
					v419 = p415 + p_u_50.flatUnit(p416 - p415) * 4.5 * v417
				end
				if v418 then
					v418.fireAt = os.clock()
				end
				local v420 = p416 - v419
				local v421
				if v420.Magnitude > 0.001 then
					v421 = v420.Unit
				else
					v421 = p414.dir
				end
				v_u_5.flash(v419, v_u_8, 12 * v417, 0.16)
				p_u_50.pop(v419, v_u_12, 2 * v417, 5.5 * v417, 0.14)
				v_u_66(p_u_50.facing(v419, v421), 2 * v417, 9 * v417, v_u_7.SpeedLines, v_u_9, 0.25, 0, 0.1)
				p_u_50.glowBeam(v419, p416, v_u_8, 10 * v417, 0.55, v_u_7.Beam)
				p_u_50.thin(p_u_50.rod(v419, p416, 6 * v417, v_u_8, 0.55), 0.5, true)
				p_u_50.thin(p_u_50.rod(v419, p416, 3.2 * v417, v_u_11, 0, v_u_14), 0.5, true)
				p_u_50.groundLine(v419, p416, 5 * v417, v_u_8, 0.9, 0.35)
				if not p414.lite then
					v_u_265(p414, v419, p416, 0.5)
					p_u_50.glowBeam(v419, p416, v_u_9, 3 * v417, 0.3, v_u_7.Beam)
				end
				v_u_271(p414, p416)
				if p414.mine then
					v_u_5.shake(0.45, 0.4)
					v_u_81()
				end
			end,
			["hit"] = function(p422, p423, _) -- name: hit
				-- upvalues: (copy) p_u_50, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14
				p_u_50.burst("Impact", p423, v_u_8, 0.9)
				if not p422.lite then
					p_u_50.pop(p423, v_u_11, 0.8, 2.2, 0.15, 0, v_u_14)
				end
			end
		}
	}
	return v424
end