local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Mythic8)
local v6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v2.Shared.Config.Textures)
v6.images({ v_u_8.MoonCrescents, v_u_8.MoonArc, v_u_8.MoonSeal })
local v_u_9 = Color3.fromHex("FFD23D")
local v_u_10 = Color3.fromHex("8A0F2A")
local v_u_11 = Color3.fromRGB(230, 40, 70)
local v_u_12 = Color3.fromRGB(255, 246, 210)
local v_u_13 = Color3.fromRGB(70, 40, 30)
local v_u_14 = Color3.fromRGB(26, 6, 12)
local v_u_15 = Enum.ParticleFlipbookLayout.Grid2x2
local function v_u_22(p16, p17, p18, p19, p20, p21) -- name: moons
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_15, (copy) v_u_11
	v_u_5.spray(p16, v_u_8.MoonCrescents, p17, p18, p19, p20, v_u_9, {
		["layout"] = nil,
		["mode"] = nil,
		["color2"] = nil,
		["emission"] = 0.35,
		["spin"] = 260,
		["gravity"] = nil,
		["layout"] = v_u_15,
		["mode"] = Enum.ParticleFlipbookMode.Random,
		["color2"] = v_u_11,
		["gravity"] = p21
	})
end
return function(p_u_23)
	-- upvalues: (copy) v_u_4, (copy) v_u_9, (copy) v_u_5, (copy) v_u_11, (copy) v_u_8, (copy) v_u_22, (copy) v_u_12, (copy) v_u_10, (copy) v_u_7, (copy) v_u_3, (copy) v_u_1, (copy) v_u_13, (copy) v_u_14
	local v81 = {
		["moon_breathing_a"] = {
			["cast"] = function(p24) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9
				local v25 = p24.size
				local v26 = p24.eye + p24.dir * 1.2
				v_u_4.flash(v26, v_u_9, 2.4 * v25, 0.1)
			end,
			["beam"] = function(p27, p28, p29) -- name: beam
				-- upvalues: (ref) v_u_5, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_22
				local v30 = p27.size
				local v31 = p27.lite
				local v32 = p29 - p28
				if v32.Magnitude >= 1 then
					local v33 = v32.Unit
					v_u_5.thinBar(v_u_5.bar(p28, p29, 0.75 * v30, v_u_11, 0.5), 0.16)
					v_u_5.thinBar(v_u_5.bar(p28, p29, 0.26 * v30, v_u_9), 0.22)
					v_u_5.facePic(p28 + v33 * 4 * v30, 2 * v30, 7.5 * v30, v_u_8.MoonArc, v_u_9, 0.2, nil, 0.25, (math.random() < 0.5 and 0 or 180) + (math.random() - 0.5) * 60)
					local v34 = v_u_5.flat(v33):Cross(Vector3.new(0, 1, 0))
					for v35 = 1, v31 and 2 or 6 do
						v_u_22(p28:Lerp(p29, (v35 - 0.3 + math.random() * 0.6) / (v31 and 2 or 6)) + v34 * (math.random() - 0.5) * 3 * v30 + Vector3.new(0, 1, 0) * (math.random() - 0.5) * 2 * v30, 1, (1 + math.random()) * v30, 2 * v30, 0.4)
					end
				end
			end,
			["hit"] = function(p36, p37, _) -- name: hit
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_22, (copy) p_u_23
				local v38 = p36.size
				v_u_5.facePic(p37, 1.5 * v38, 4.5 * v38, v_u_8.MoonArc, v_u_9, 0.2, nil, 0.25, (math.random() < 0.5 and 0 or 180) + (math.random() - 0.5) * 60)
				if not p36.lite then
					v_u_22(p37, 2, 0.8 * v38, 8 * v38, 0.4)
				end
				p_u_23.beamHitSound(p36, p37, "Hit")
			end
		},
		["moon_breathing_e"] = {
			["cast"] = function(p39) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_23, (ref) v_u_12, (ref) v_u_8
				local v40 = p39.size
				v_u_4.flash(p39.eye, v_u_9, 4 * v40, 0.16)
				p_u_23.glint(p39.eye, v_u_12, 4 * v40, 0.2)
				v_u_4.ring(p39.feet, v_u_9, 6 * v40, 0.3, v_u_8.Ring)
			end,
			["windup"] = function(p41, p42, p43) -- name: windup
				-- upvalues: (copy) p_u_23, (ref) v_u_9
				local v44 = p41.size
				local v45 = math.max(p43, 0.1)
				p_u_23.inward(p_u_23.ground(p42, 2.5), v_u_9, p41.lite and 4 or 10, 9 * v44, v45 + 0.04)
			end,
			["land"] = function(p46, p47) -- name: land
				-- upvalues: (copy) p_u_23, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (ref) v_u_22, (ref) v_u_10, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7
				local v_u_48 = p46.size
				local v_u_49 = p46.lite
				local v_u_50 = p46.ability.radius * v_u_48
				local v_u_51 = p_u_23.ground(p47, 0.1)
				for v52, v53 in { 1, 3, 5.2 } do
					local v54
					if v52 == 2 then
						local v55 = math.random() - 0.5
						local v56 = math.random() - 0.5
						v54 = (Vector3.new(0, 1, 0) + Vector3.new(v55, 0, v56) * 0.7).Unit
					else
						v54 = Vector3.new(0, 1, 0)
					end
					v_u_5.planePic(v_u_5.facing(v_u_51 + Vector3.new(0, 1, 0) * v53 * v_u_48, v54), 4 * v_u_48, v_u_50 * (2.2 - v52 * 0.2), v_u_8.MoonArc, v_u_9, 0, 0.28, 0.12, 0.35, v52 % 2 == 0 and -7 or 7, 0.25)
				end
				local v57 = v_u_49 and 5 or 14
				local v_u_58 = math.random() * 3.141592653589793 * 2
				for v_u_59 = 1, v57 do
					local v_u_60 = v_u_59 / v57
					p_u_23.after(v_u_60 * 0.32, function()
						-- upvalues: (copy) v_u_58, (copy) v_u_60, (copy) v_u_48, (copy) v_u_50, (copy) v_u_51, (ref) v_u_5, (ref) v_u_8, (copy) v_u_59, (ref) v_u_11, (ref) v_u_9, (copy) v_u_49, (ref) v_u_22
						local v61 = v_u_58 + v_u_60 * 3.141592653589793 * 3
						local v62 = 3 * v_u_48 + (v_u_50 * 0.85 - 3 * v_u_48) * v_u_60
						local v63 = v_u_51
						local v64 = v_u_60 * 3.141592653589793
						local v65 = v63 + Vector3.new(0, 1, 0) * (math.sin(v64) * 2.6 + 1.6) * v_u_48
						local v66 = math.cos(v61)
						local v67 = math.sin(v61)
						local v68 = v65 + Vector3.new(v66, 0, v67) * v62
						local v69 = v_u_5.facePic
						local v70 = 3 * v_u_48
						local v71 = (v_u_60 * 2 + 5) * v_u_48
						local v72 = v_u_8.MoonArc
						local v73
						if v_u_59 % 3 == 0 then
							v73 = v_u_11
						else
							v73 = v_u_9
						end
						v69(v68, v70, v71, v72, v73, 0.3, nil, 0.2, (math.random() < 0.5 and 0 or 180) + (math.random() - 0.5) * 60)
						if not v_u_49 and v_u_59 % 2 == 0 then
							v_u_22(v68, 2, 1 * v_u_48, 6 * v_u_48, 0.5)
						end
					end)
				end
				v_u_5.groundPic(v_u_51, v_u_50 * 0.4, v_u_50 * 1.7, v_u_8.MoonSeal, v_u_9, 0, 0.25, 0.35, 0.5, 1.5, 0.15)
				v_u_5.groundPic(v_u_51 - Vector3.new(0, 0.04, 0), v_u_50 * 0.6, v_u_50 * 2.2, v_u_8.Glow, v_u_10, 0.3, 0.25, 0.4, 0.5, 0)
				if not v_u_49 then
					for v74 = 1, 6 do
						local v75 = v_u_58 + v74 * 3.141592653589793 / 3
						local v76 = math.cos(v75)
						local v77 = math.sin(v75)
						local v78 = v_u_51 + Vector3.new(v76, 0, v77) * v_u_50 * 0.6 + Vector3.new(0, 0.03, 0) * v74
						v_u_5.groundPic(v78, v_u_50 * 0.2, v_u_50 * 0.75, v_u_8.MoonArc, v_u_9, 0, 0.18, 0.4, 0.5, 0)
					end
				end
				v_u_22(v_u_51 + Vector3.new(0, 2, 0) * v_u_48, v_u_49 and 8 or 30, 1.3 * v_u_48, v_u_50 * 1.1, 1, 6)
				v_u_4.ring(v_u_51, v_u_9, v_u_50 * 1.1, 0.45, v_u_8.Shockwave)
				v_u_4.flash(v_u_51 + Vector3.new(0, 3, 0) * v_u_48, v_u_12, v_u_50 * 0.5, 0.2)
				v_u_7.play("Explosion", {
					["at"] = v_u_51,
					["volume"] = p46.mine and 0.8 or 0.4
				})
				if p46.mine then
					v_u_4.shake(0.3, 0.3)
				end
			end,
			["hit"] = function(p79, p80, _) -- name: hit
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (copy) p_u_23
				v_u_5.facePic(p80, 1.5 * p79.size, 4.5 * p79.size, v_u_8.MoonArc, v_u_9, 0.22, nil, 0.25, (math.random() < 0.5 and 0 or 180) + (math.random() - 0.5) * 60)
				p_u_23.burst("Impact", p80, v_u_9, 0.7)
			end
		}
	}
	local v_u_82 = {}
	setmetatable(v_u_82, {
		["__mode"] = "k"
	})
	v81.moon_breathing_r = {
		["cast"] = function(p83) -- name: cast
			-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_9, (copy) p_u_23, (ref) v_u_12, (ref) v_u_5
			local v84 = p83.size
			local v85 = v_u_3.CurrentCamera
			local v86
			if v85 then
				v86 = v85.CFrame
			else
				v86 = CFrame.identity
			end
			for v87 = -1, 1 do
				for _, v88 in { -1, 1 } do
					local v89 = p83.eye + v86.RightVector * v88 * 0.32 * v84 + v86.UpVector * v87 * 0.36 * v84 - v86.LookVector * 0.6 * v84
					v_u_4.flash(v89, v_u_9, 1.1 * v84, 0.35)
				end
			end
			p_u_23.glint(p83.eye, v_u_12, 6 * v84, 0.3)
			if p83.mine then
				v_u_4.shake(0.12, 0.15)
				v_u_5.tint("MoonBreathing", Color3.fromRGB(255, 232, 205), -0.08, 0.2, 0.15, 1.2, 0.5)
			end
		end,
		["windup"] = function(p_u_90, p91, p92) -- name: windup
			-- upvalues: (copy) p_u_23, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (copy) v_u_82, (ref) v_u_11, (ref) v_u_10, (ref) v_u_22, (ref) v_u_7, (ref) v_u_4
			local v_u_93 = p_u_90.size
			local v_u_94 = p_u_90.ability.radius * v_u_93
			local v95 = p_u_23.ground(p91, 0.1)
			local v96 = math.max(p92, 0.3)
			local v97 = v95 + Vector3.new(0, 1, 0) * v_u_94 * 0.62
			local v98 = v_u_5.flat(p_u_90.origin - p91)
			local v_u_99 = CFrame.lookAt(v97, v97 - v98)
			local v_u_100, v_u_101 = v_u_5.standingCard(v_u_94 * 2.2, v_u_94 * 2.2, v_u_8.MoonArc, v_u_9, 1, 1.9)
			v_u_100.CFrame = v_u_99
			v_u_1:AddItem(v_u_100, v96 + 1.5)
			v_u_82[p_u_90] = {
				["card"] = v_u_100,
				["labels"] = v_u_101,
				["at"] = v97
			}
			local v_u_102 = os.clock()
			p_u_23.runNow(function()
				-- upvalues: (copy) v_u_102, (copy) v_u_100, (ref) v_u_5, (copy) v_u_94, (copy) v_u_99, (copy) v_u_101
				local v103 = os.clock() - v_u_102
				if not v_u_100.Parent then
					return false
				end
				local v104 = v_u_5.outBack(v103 / 0.35)
				local v105 = v_u_94 * 2.2 * v104
				local v106 = math.max(v105, 0.1)
				v_u_100.Size = Vector3.new(v106, v106, 0.05)
				v_u_100.CFrame = v_u_99 * CFrame.new(0, (1 - v104) * v_u_94 * 0.3, 0)
				for _, v107 in v_u_101 do
					v107.ImageTransparency = 1 - v_u_5.smooth(v103 / 0.25)
				end
				return v103 < 0.4
			end)
			v_u_5.facePic(v97, v_u_94 * 0.6, v_u_94 * 2.4, v_u_8.Glow, v_u_11, v96 + 0.5, nil, 0.1)
			v_u_5.groundPic(v95, v_u_94 * 0.5, v_u_94 * 2.2, v_u_8.MoonSeal, v_u_9, 0.15, 0.4, v96, 0.5, 0.4, 0.1)
			v_u_5.groundPic(v95 - Vector3.new(0, 0.04, 0), v_u_94 * 0.8, v_u_94 * 2.6, v_u_8.Glow, v_u_10, 0.4, 0.4, v96, 0.5, 0)
			v_u_22(v97, p_u_90.lite and 4 or 14, 1.4 * v_u_93, v_u_94 * 0.4, 1.2)
			v_u_7.play("EyeActivate", {
				["at"] = v97,
				["volume"] = p_u_90.mine and 0.6 or 0.3
			})
			p_u_23.after(v96 + 0.25, function()
				-- upvalues: (ref) v_u_82, (copy) p_u_90, (ref) v_u_4, (ref) v_u_1, (ref) v_u_22, (copy) v_u_93, (copy) v_u_94, (ref) v_u_9
				local v108 = v_u_82[p_u_90]
				v_u_82[p_u_90] = nil
				if v108 then
					for _, v109 in v108.labels do
						v_u_4.tween(v109, 0.35, {
							["ImageTransparency"] = 1
						})
					end
					v_u_1:AddItem(v108.card, 0.4)
					v_u_22(v108.at, p_u_90.lite and 6 or 30, 1.5 * v_u_93, v_u_94 * 0.5, 1.6, 30)
					v_u_4.flash(v108.at, v_u_9, v_u_94 * 0.6, 0.25)
				end
			end)
		end,
		["strike"] = function(p_u_110, p111, p112) -- name: strike
			-- upvalues: (copy) p_u_23, (copy) v_u_82, (ref) v_u_3, (ref) v_u_5, (ref) v_u_8, (ref) v_u_12, (ref) v_u_1, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_22, (ref) v_u_13, (ref) v_u_14, (ref) v_u_7
			local v_u_113 = p_u_110.size
			local v_u_114 = p_u_110.lite
			local v_u_115 = (p_u_110.ability.strikeRadius or 8) * v_u_113
			local v_u_116 = p_u_110.ability.radius * v_u_113
			local v_u_117 = p_u_23.ground(p111, 0.1)
			local v118 = p_u_23.after
			local v119 = p112 - 0.14
			v118(math.max(v119, 0), function()
				-- upvalues: (ref) v_u_82, (copy) p_u_110, (copy) v_u_117, (copy) v_u_116, (ref) v_u_3, (ref) v_u_5, (copy) v_u_115, (ref) v_u_8, (ref) v_u_12, (ref) v_u_1, (ref) v_u_9, (ref) p_u_23, (ref) v_u_4
				local v120 = v_u_82[p_u_110]
				local v_u_121
				if v120 then
					v_u_121 = v120.at
				else
					v_u_121 = v_u_117 + Vector3.new(0, 1, 0) * v_u_116
				end
				local v122 = v_u_3.CurrentCamera
				local v_u_123 = not v122 and Vector3.new(0, 0, 1) or v_u_5.flat(v122.CFrame.Position - v_u_117)
				local v_u_124, v_u_125 = v_u_5.standingCard(v_u_115 * 2.4, v_u_115 * 2.4, v_u_8.MoonArc, v_u_12, 0, 2)
				v_u_1:AddItem(v_u_124, 0.6)
				for _, v126 in v_u_125 do
					v126.ImageColor3 = v_u_9
				end
				local v_u_127 = CFrame.Angles(0, 0, 3.141592653589793)
				p_u_23.animate(0.14, 0, function(p128)
					-- upvalues: (copy) v_u_121, (ref) v_u_117, (ref) v_u_115, (copy) v_u_124, (copy) v_u_123, (copy) v_u_127, (copy) v_u_125, (ref) v_u_4
					local v129 = v_u_121:Lerp(v_u_117 + Vector3.new(0, 1, 0) * v_u_115 * 0.55, p128 * p128)
					v_u_124.CFrame = CFrame.lookAt(v129, v129 - v_u_123) * v_u_127
					if p128 >= 1 then
						for _, v130 in v_u_125 do
							v_u_4.tween(v130, 0.25, {
								["ImageTransparency"] = 1
							})
						end
					end
				end)
			end)
			p_u_23.after(math.max(p112, 0), function()
				-- upvalues: (ref) v_u_5, (copy) v_u_117, (copy) v_u_115, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (ref) v_u_22, (copy) v_u_114, (copy) v_u_113, (ref) p_u_23, (ref) v_u_13, (ref) v_u_14, (ref) v_u_7, (copy) p_u_110
				v_u_5.groundPic(v_u_117, v_u_115 * 0.6, v_u_115 * 2.6, v_u_8.MoonArc, v_u_9, 0, 0.1, 0.45, 0.5, 0)
				v_u_5.groundPic(v_u_117 - Vector3.new(0, 0.04, 0), v_u_115, v_u_115 * 2.4, v_u_8.Glow, v_u_10, 0.4, 0.1, 0.3, 0.5, 0)
				v_u_5.facePic(v_u_117 + Vector3.new(0, 1, 0) * v_u_115 * 0.4, v_u_115 * 1.2, v_u_115 * 3, v_u_8.MoonArc, v_u_9, 0.25, nil, 0.3, 180)
				v_u_4.ring(v_u_117, v_u_9, v_u_115 * 1.3, 0.35, v_u_8.Shockwave)
				v_u_22(v_u_117 + Vector3.new(0, 1, 0), v_u_114 and 3 or 10, 1.1 * v_u_113, v_u_115 * 2.2, 0.8, 12)
				if not v_u_114 then
					local v131 = { v_u_13, v_u_14, v_u_9 }
					p_u_23.chunks(v_u_117 + Vector3.new(0, 0.4, 0), v131, 4, 20 * v_u_113, 0.6 * v_u_113, 0.9, false, 0.9)
				end
				v_u_7.play("Hit", {
					["at"] = v_u_117,
					["volume"] = p_u_110.mine and 0.6 or 0.3
				})
				if p_u_110.mine then
					v_u_4.shake(0.16, 0.12)
				end
			end)
		end,
		["hit"] = function(p132, p133, _) -- name: hit
			-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_22
			p_u_23.burst("Impact", p133, v_u_9, 0.75)
			if not p132.lite then
				v_u_22(p133, 2, 0.9 * p132.size, 8, 0.4)
			end
		end
	}
	return v81
end