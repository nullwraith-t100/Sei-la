local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(200, 226, 255)
local v_u_6 = Enum.Material.SmoothPlastic
local v_u_7 = CFrame.Angles(0, 0, 1.5707963267948966)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_5, (copy) v_u_3
	return {
		["w4_blizzard_wheel"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_4, (ref) v_u_6, (ref) v_u_7, (ref) v_u_5, (ref) v_u_3
			local v_u_11 = v_u_2.color(p10.color)
			local v12 = v_u_2.color(p10.color2)
			local v13 = p_u_9.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_15 = v_u_14 * 2.35
			p_u_9.eyeLift = 2.3
			local v_u_16 = 0
			local v_u_17 = 0
			local v_u_18 = 0
			local v_u_19 = nil
			local v_u_22 = p_u_8.throb(p_u_9, 3.4, 1.4, 1.6, function(p20)
				-- upvalues: (ref) v_u_2, (ref) p_u_8, (copy) p_u_9, (copy) v_u_11, (ref) v_u_4, (ref) v_u_19
				v_u_2.ring(p_u_8.feetAt(p_u_9, p20, 0.15), v_u_11, 5.5 * p_u_9.fx, 0.5, v_u_4.Shockwave)
				local v21 = v_u_19
				if v21 then
					v21:Emit(14)
				end
			end)
			local v23 = p_u_9.ticks
			local function v26(_, _, p24)
				-- upvalues: (copy) v_u_22, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18
				local v25 = v_u_22()
				v_u_16 = v_u_16 + p24 * (2.4 + v25 * 16)
				v_u_17 = v_u_17 - p24 * (1.2 + v25 * 6)
				v_u_18 = v25
			end
			table.insert(v23, v26)
			local v_u_37 = p_u_8.group(p_u_9, function(p27, p28)
				-- upvalues: (copy) p_u_9, (copy) v_u_14
				local v29 = CFrame.new
				local v30 = p_u_9.headY + v_u_14 * 4.6
				local v31 = p28 * 1.5
				local v32 = p27 * v29(0, v30 + math.sin(v31) * 0.12 * v_u_14, v_u_14 * 0.3)
				local v33 = CFrame.Angles
				local v34 = p28 * 0.9
				local v35 = math.sin(v34) * 0.04 + 0.4886921905584123
				local v36 = p28 * 1.1
				return v32 * v33(v35, 0, math.sin(v36) * 0.05)
			end)
			local v38 = #p_u_9.pieces + 1
			p_u_8.add(p_u_9, p_u_8.dark(p_u_8.disc(Vector3.new(0.34, 2.7, 2.7) * v_u_14, v12, 0, v_u_6)), function()
				-- upvalues: (copy) v_u_37, (ref) v_u_16, (ref) v_u_7
				return v_u_37.cf * CFrame.Angles(0, v_u_16, 0) * v_u_7
			end)
			local v_u_39 = v_u_18
			local v_u_40 = v_u_17
			local v_u_41 = v_u_16
			for v42 = 0, 5 do
				local v43 = v42 * 3.141592653589793 / 3
				local v44 = math.cos(v43)
				local v45 = math.sin(v43)
				local v46 = Vector3.new(v44, 0, v45)
				local v47 = v_u_14 * 0.64
				local v48 = p_u_8.bar
				local v49 = v_u_14 * 0.42
				local v50 = v_u_14 * 0.52
				local v51 = v48(Vector3.new(v49, v47, v50), v_u_11, 0)
				v51.Shape = Enum.PartType.Wedge
				local v_u_52 = CFrame.fromMatrix(v46 * (v_u_14 * 0.5 + v47 / 2), Vector3.new(0, 1, 0), v46)
				p_u_8.add(p_u_9, v51, function()
					-- upvalues: (copy) v_u_37, (ref) v_u_41, (copy) v_u_52
					return v_u_37.cf * CFrame.Angles(0, v_u_41, 0) * v_u_52
				end)
			end
			p_u_8.add(p_u_9, p_u_8.disc(Vector3.new(0.44, 0.82, 0.82) * v_u_14, v_u_11, 0), function()
				-- upvalues: (copy) v_u_37, (ref) v_u_41, (ref) v_u_7
				return v_u_37.cf * CFrame.Angles(0, v_u_41, 0) * v_u_7
			end)
			p_u_8.add(p_u_9, p_u_8.dark(p_u_8.disc(Vector3.new(0.52, 0.34, 0.34) * v_u_14, v12, 0, v_u_6)), function()
				-- upvalues: (copy) v_u_37, (ref) v_u_41, (ref) v_u_7
				return v_u_37.cf * CFrame.Angles(0, v_u_41, 0) * v_u_7
			end)
			p_u_8.pin(p_u_9, v_u_37, p_u_8.picture(v_u_15 * 2.15, v_u_4.Ring, v_u_11, 0.05), CFrame.identity)
			p_u_8.pin(p_u_9, v_u_37, p_u_8.picture(v_u_15 * 2.8, v_u_4.Ring, v_u_5, 0.4), CFrame.new(0, v_u_14 * -0.03, 0))
			for v53 = 0, 5 do
				local v_u_54 = v53 * 3.141592653589793 / 3
				local v55 = p_u_8.dark(p_u_8.ball(v_u_14 * 0.62, v12, 0, v_u_6))
				p_u_8.add(p_u_9, v55, function()
					-- upvalues: (copy) v_u_37, (ref) v_u_40, (copy) v_u_54, (copy) v_u_15, (ref) v_u_39
					local v56 = v_u_37.cf
					local v57 = CFrame.new
					local v58 = v_u_40 + v_u_54 + 0
					local v59 = v_u_15 * (v_u_39 * 0.3 + 1) + 0
					local v60 = math.cos(v58) * v59
					local v61 = math.sin(v58) * v59
					return v56 * v57((Vector3.new(v60, 0, v61)))
				end)
				p_u_8.add(p_u_9, p_u_8.dark(p_u_8.blob(Vector3.new(0.34, 0.3, 0.8) * v_u_14, v12, 0, v_u_6)), function()
					-- upvalues: (ref) v_u_40, (copy) v_u_54, (copy) v_u_15, (ref) v_u_39, (copy) v_u_14, (copy) v_u_37
					local v62 = v_u_40 + v_u_54 + 0.06
					local v63 = v_u_15 * (v_u_39 * 0.3 + 1) + 0
					local v64 = math.cos(v62) * v63
					local v65 = math.sin(v62) * v63
					local v66 = Vector3.new(v64, 0, v65)
					local v67 = v_u_14 * 0.1
					local v68 = v_u_40 + v_u_54 + 0.3
					local v69 = v_u_15 * (v_u_39 * 0.3 + 1) + v67
					local v70 = math.cos(v68) * v69
					local v71 = math.sin(v68) * v69
					local v72 = Vector3.new(v70, 0, v71)
					return v_u_37.cf * CFrame.lookAt((v66 + v72) / 2, v72)
				end)
				p_u_8.add(p_u_9, p_u_8.dark(p_u_8.blob(Vector3.new(0.2, 0.2, 0.62) * v_u_14, v12, 0, v_u_6)), function()
					-- upvalues: (copy) v_u_14, (ref) v_u_40, (copy) v_u_54, (copy) v_u_15, (ref) v_u_39, (copy) v_u_37
					local v73 = v_u_14 * 0.1
					local v74 = v_u_40 + v_u_54 + 0.29
					local v75 = v_u_15 * (v_u_39 * 0.3 + 1) + v73
					local v76 = math.cos(v74) * v75
					local v77 = math.sin(v74) * v75
					local v78 = Vector3.new(v76, 0, v77)
					local v79 = v_u_14 * 0.55
					local v80 = v_u_40 + v_u_54 + 0.36
					local v81 = v_u_15 * (v_u_39 * 0.3 + 1) + v79
					local v82 = math.cos(v80) * v81
					local v83 = math.sin(v80) * v81
					local v84 = Vector3.new(v82, 0, v83)
					return v_u_37.cf * CFrame.lookAt((v78 + v84) / 2, v84)
				end)
				p_u_8.tail(v55, v_u_11, v_u_5, v_u_14 * 0.3, 0.3)
			end
			for v85 = v38, #p_u_9.pieces do
				p_u_8.fadeFromBehind(p_u_9, p_u_9.pieces[v85].part, 0.6)
			end
			local v86 = p_u_8.bar
			local v87 = v_u_15 * 2.2
			local v88 = v_u_15 * 2.2
			local v89 = v86(Vector3.new(v87, 0.2, v88), v_u_11, 1)
			p_u_8.pin(p_u_9, v_u_37, v89, CFrame.identity)
			local v90 = Instance.new("ParticleEmitter")
			v90.Texture = v_u_4.Glow
			v90.Color = ColorSequence.new(v_u_11)
			v90.LightEmission = 0.6
			v90.LightInfluence = 0
			v90.EmissionDirection = Enum.NormalId.Bottom
			v90.Lifetime = NumberRange.new(1.5, 2.1)
			v90.Speed = NumberRange.new(1 * p_u_9.fx, 2.5 * p_u_9.fx)
			v90.SpreadAngle = Vector2.new(25, 25)
			local v91 = -6 * p_u_9.fx
			v90.Acceleration = Vector3.new(0, v91, 0)
			v90.Drag = 0.6
			v90.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_14 * 0.2 * p_u_9.fx), NumberSequenceKeypoint.new(1, v_u_14 * 0.1 * p_u_9.fx) })
			v90.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.8, 0.3), NumberSequenceKeypoint.new(1, 1) })
			v90:SetAttribute("BaseRate", 16)
			v90.Rate = 16 * v_u_3.formRate()
			v90.Parent = v89
			p_u_8.own(p_u_9, v89)
			v_u_19 = v90
			local v_u_92 = {}
			for _ = 1, 2 do
				local v_u_93 = Instance.new("Attachment")
				v_u_93.Parent = p_u_9.root
				local v_u_94 = Instance.new("Attachment")
				v_u_94.Parent = p_u_9.root
				local v95 = p_u_8.ray(v_u_93, v_u_94, v_u_11, v_u_14 * 0.45 * p_u_9.fx, v_u_14 * 1.05 * p_u_9.fx, v_u_4.BlizzardWind)
				v95.Color = ColorSequence.new(v_u_5, v_u_11)
				v95.Segments = 14
				v95.TextureLength = v_u_14 * 3
				v95.TextureSpeed = 1.6
				v95.LightEmission = 0.35
				v95.CurveSize0 = v_u_14 * 2.4
				v95.CurveSize1 = v_u_14 * 2.4
				v95.Transparency = NumberSequence.new({
					NumberSequenceKeypoint.new(0, 1),
					NumberSequenceKeypoint.new(0.25, 0.6),
					NumberSequenceKeypoint.new(0.75, 0.55),
					NumberSequenceKeypoint.new(1, 0.92)
				})
				p_u_8.own(p_u_9, v_u_93)
				p_u_8.own(p_u_9, v_u_94)
				local v96 = p_u_9.stops
				table.insert(v96, function()
					-- upvalues: (copy) v_u_93, (copy) v_u_94
					v_u_93:Destroy()
					v_u_94:Destroy()
				end)
				table.insert(v_u_92, {
					["a0"] = v_u_93,
					["a1"] = v_u_94,
					["beam"] = v95
				})
			end
			local v97 = p_u_9.ticks
			table.insert(v97, function(p98)
				-- upvalues: (copy) v_u_92, (ref) v_u_40, (copy) v_u_14, (copy) p_u_9, (copy) v_u_37, (copy) v_u_15
				for v99, v100 in v_u_92 do
					local v101 = -v_u_40 * 1.4 + v99 * 3.141592653589793
					local v102 = v_u_14 * 2.3
					local v103 = math.cos(v101) * v102
					local v104 = p_u_9.feet + v_u_14 * 0.5
					local v105 = math.sin(v101) * v102
					local v106 = Vector3.new(v103, v104, v105)
					local v107 = -math.sin(v101)
					local v108 = math.cos(v101)
					local v109 = Vector3.new(v107, 0, v108)
					local v110 = v101 + 2.827433388230814
					local v111 = v_u_37.cf
					local v112 = math.cos(v110) * v_u_15 * 1.05
					local v113 = math.sin(v110) * v_u_15 * 1.05
					local v114 = p98:PointToObjectSpace(v111 * Vector3.new(v112, 0, v113))
					local v115 = -math.sin(v110)
					local v116 = math.cos(v110)
					local v117 = Vector3.new(v115, 0, v116)
					v100.a0.CFrame = CFrame.fromMatrix(v106, v109, Vector3.new(0, 1, 0))
					v100.a1.CFrame = CFrame.fromMatrix(v114, v117, Vector3.new(0, 1, 0))
				end
			end)
			p_u_8.particles(p_u_9, "AuraMode", v_u_11, {
				["rate"] = 0.4,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Streaks", "Sparks" }
			})
		end
	}
end