local v_u_1 = require(script.Parent.Parent.Config.Boss)
require(script.Parent.Parent.Config.Abilities)
local v_u_54 = {
	["CENTRE"] = Vector3.new(-3000, 0, 300),
	["FLOOR_RADIUS"] = 100,
	["INSIDE_RADIUS"] = 125,
	["ENTRY_RADIUS"] = 84,
	["SHOP"] = Vector3.new(-3000, 0, 401),
	["SHOP_REACH"] = 7,
	["HEIGHT"] = 75,
	["BODY_RADIUS"] = 22,
	["CHEST"] = 14,
	["FOE_ID"] = 2000000000,
	["LOCK_REACH"] = 70,
	["RANGE_SLACK"] = 10,
	["gap"] = function(p2, p3, p4, p5) -- name: gap
		-- upvalues: (copy) v_u_54
		local v6 = p2 - (p4 or v_u_54.CENTRE.X)
		local v7 = p3 - (p5 or v_u_54.CENTRE.Z)
		local v8 = v6 * v6 + v7 * v7
		local v9 = math.sqrt(v8) - v_u_54.BODY_RADIUS
		return math.max(v9, 0)
	end,
	["aimPoint"] = function(p10, p11, p12, p13) -- name: aimPoint
		-- upvalues: (copy) v_u_54
		local v14 = p12 or v_u_54.CENTRE.X
		local v15 = v_u_54.CENTRE.Y
		local v16 = p13 or v_u_54.CENTRE.Z
		local v17 = Vector3.new(v14, v15, v16)
		local v18 = p10 - v17.X
		local v19 = p11 - v17.Z
		local v20 = v18 * v18 + v19 * v19
		local v21 = math.sqrt(v20)
		if v21 < 0.001 then
			local v22 = v17.X
			local v23 = v17.Y + v_u_54.CHEST
			local v24 = v17.Z
			return Vector3.new(v22, v23, v24)
		end
		local v25 = v_u_54.BODY_RADIUS
		local v26 = math.min(v25, v21)
		local v27 = v17.X + v18 / v21 * v26
		local v28 = v17.Y + v_u_54.CHEST
		local v29 = v17.Z + v19 / v21 * v26
		return Vector3.new(v27, v28, v29)
	end,
	["WALK_SPEED"] = 15,
	["STOP_GAP"] = 8,
	["ROAM"] = 70,
	["NEAR"] = 30,
	["LEAP_EVERY"] = 7,
	["LEAP_RADIUS"] = 26,
	["BURST"] = 0.1,
	["BURST_SECONDS"] = 4,
	["ROAR_EVERY"] = 12,
	["THREAT_HALF"] = 5,
	["RECOVER"] = 0.5,
	["CHASE_EXTRA"] = 0.8,
	["LEAP_LAUNCH"] = 0.6,
	["clampRoam"] = function(p30, p31) -- name: clampRoam
		-- upvalues: (copy) v_u_54
		local v32 = p30 - v_u_54.CENTRE.X
		local v33 = p31 - v_u_54.CENTRE.Z
		local v34 = v32 * v32 + v33 * v33
		local v35 = math.sqrt(v34)
		if v35 <= v_u_54.ROAM then
			return p30, p31
		else
			return v_u_54.CENTRE.X + v32 / v35 * v_u_54.ROAM, v_u_54.CENTRE.Z + v33 / v35 * v_u_54.ROAM
		end
	end,
	["walk"] = function(p36, p37, p38, p39, p40, p41) -- name: walk
		-- upvalues: (copy) v_u_54
		local v42 = p38 - p36
		local v43 = p39 - p37
		local v44 = v42 * v42 + v43 * v43
		local v45 = math.sqrt(v44)
		local v46 = v_u_54.BODY_RADIUS + v_u_54.STOP_GAP
		if v45 <= v46 then
			return v_u_54.clampRoam(p36, p37)
		end
		local v47 = p40 * p41
		local v48 = v45 - v46
		local v49 = math.min(v47, v48)
		return v_u_54.clampRoam(p36 + v42 / v45 * v49, p37 + v43 / v45 * v49)
	end,
	["leapTo"] = function(p50, p51) -- name: leapTo
		-- upvalues: (copy) v_u_54
		return v_u_54.clampRoam(p50, p51)
	end,
	["fade"] = function(p52, p53) -- name: fade
		-- upvalues: (copy) v_u_54
		return p52 * 0.5 ^ (p53 / v_u_54.THREAT_HALF)
	end,
	["ENTRANCE_SPEED"] = 2
}
v_u_54.ENTRANCE = 4 / v_u_54.ENTRANCE_SPEED
v_u_54.FIGHT_SHOWN = 1
v_u_54.SKIP_WARN = 5
v_u_54.RESULTS = 8
v_u_54.PORTAL_DELAY = 5
v_u_54.EXIT_OPEN = 20
v_u_54.PROTECT = 2
v_u_54.HP_EVERY = 0.25
v_u_54.EFFORT = 0.7
v_u_54.LAG = 1.5
v_u_54.ENRAGE = 0.5
v_u_54.SPEED = 1.3
v_u_54.BOMB_FIRST = 10
v_u_54.BOMB_EVERY = 16
v_u_54.BOMB_RAGE_EVERY = 11
v_u_54.ATTACKS = {
	["claw_left"] = {
		["clip"] = "claw_left",
		["windup"] = 1.2,
		["damage"] = 0.35,
		["weight"] = 1.5,
		["near"] = 2,
		["far"] = 0.4
	},
	["claw_right"] = {
		["clip"] = "claw_right",
		["windup"] = 1.2,
		["damage"] = 0.35,
		["weight"] = 1.5,
		["near"] = 2,
		["far"] = 0.4
	},
	["tail_sweep"] = {
		["clip"] = "tail_sweep",
		["windup"] = 1.5,
		["damage"] = 0.4,
		["weight"] = 2,
		["near"] = 3,
		["far"] = 0.3
	},
	["stomp"] = {
		["clip"] = "stomp",
		["windup"] = 1.3,
		["damage"] = 0.3,
		["weight"] = 2,
		["near"] = 1.2,
		["far"] = 1.8
	},
	["roar"] = {
		["clip"] = "roar",
		["windup"] = 1.2,
		["damage"] = 0.15,
		["weight"] = 1.2,
		["near"] = 1.2,
		["far"] = 0.2,
		["push"] = 85
	},
	["bomb"] = {
		["clip"] = "bomb_charge",
		["windup"] = 3.35,
		["damage"] = 0.85,
		["weight"] = 2.5,
		["near"] = 1.2,
		["far"] = 2.5
	},
	["fox_rain"] = {
		["clip"] = "roar",
		["windup"] = 2,
		["damage"] = 0.3,
		["weight"] = 2.5,
		["near"] = 1.5,
		["far"] = 2.5,
		["rage"] = true
	},
	["leap"] = {
		["clip"] = "leap",
		["windup"] = 1.3,
		["damage"] = 0.4,
		["weight"] = 0,
		["near"] = 0,
		["far"] = 3.5
	}
}
local v55 = {
	"claw_left",
	"claw_right",
	"tail_sweep",
	"stomp",
	"roar",
	"bomb"
}
v_u_54.ORDER = v55
local v56 = { "leap" }
v_u_54.CHASE_ORDER = v56
local v57 = { "fox_rain" }
v_u_54.RAGE_ORDER = v57
local v_u_58 = table.clone(v55)
for _, v59 in v56 do
	table.insert(v_u_58, v59)
end
for _, v60 in v57 do
	table.insert(v_u_58, v60)
end
v_u_54.ALL = v_u_58
v_u_54.CLAW_REACH = 56
v_u_54.CLAW_HALF = 0.75
v_u_54.CLAW_TURN = 0.35
v_u_54.TAIL_INNER = 22
v_u_54.TAIL_OUTER = 72
v_u_54.STOMP_RADIUS = 13
v_u_54.STOMP_MAX = 4
v_u_54.ROAR_RADIUS = 50
v_u_54.BOMB_RADIUS = 32
v_u_54.RAIN_RADIUS = 11
v_u_54.RAIN_MAX = 10
v_u_54.RAIN_EXTRA = 6
v_u_54.RAIN_NEAR = 0.35
v_u_54.RAIN_FAR = 0.92
function v_u_54.clock(p61) -- name: clock
	local v62 = math.ceil(p61)
	local v63 = math.max(0, v62)
	return string.format("%d:%02d", v63 // 60, v63 % 60)
end
function v_u_54.nextAfter(p64, p65) -- name: nextAfter
	-- upvalues: (copy) v_u_1
	local v66 = p64 + v_u_1.EVERY
	if v66 < p65 then
		local v67 = (p65 - v66) / v_u_1.EVERY
		v66 = v66 + math.ceil(v67) * v_u_1.EVERY
	end
	return v66
end
function v_u_54.strikes(p68) -- name: strikes
	local v69 = p68.kind
	if v69 == "spread" then
		return (p68.count or 3) * 0.6
	end
	if v69 == "rain" then
		return (p68.count or 6) * 0.7
	end
	if v69 ~= "zone" then
		return 1
	end
	local v70 = (p68.duration or 2) / (p68.tick or 0.5)
	local v71 = math.ceil(v70)
	local v72 = p68.finalPower or 0
	local v73 = p68.power
	return v71 + v72 / math.max(v73, 1e-6)
end
function v_u_54.perCast(p74) -- name: perCast
	-- upvalues: (copy) v_u_54
	return p74.power * v_u_54.strikes(p74)
end
function v_u_54.rate(p75, p76, p77, p78, p79) -- name: rate
	-- upvalues: (copy) v_u_54
	local v80 = v_u_54.perCast(p75)
	local v81 = p75.cooldown
	local v82 = v80 / math.max(v81, 0.05)
	local v83 = v_u_54.perCast(p76)
	local v84 = p76.cooldown
	local v85 = v82 + v83 / math.max(v84, 0.05)
	local v86 = v_u_54.perCast(p77)
	local v87 = p77.cooldown
	return (v85 + v86 / math.max(v87, 0.05)) * (p78 * (p79 - 1) + 1) * v_u_54.EFFORT
end
function v_u_54.worth(p88, p89, p90) -- name: worth
	return p88 * (not p89 and 1 or p90)
end
function v_u_54.newPool(p91) -- name: newPool
	-- upvalues: (copy) v_u_1
	local v92 = 0
	for _, v93 in p91 do
		v92 = v92 + math.max(v93, 0)
	end
	local v94 = v92 * v_u_1.TARGET_SECONDS
	return {
		["hp"] = v94,
		["maxHp"] = v94,
		["rate"] = v92
	}
end
function v_u_54.join(p95, p96) -- name: join
	-- upvalues: (copy) v_u_1
	local v97 = math.max(p96, 0)
	if p95.rate > 1e-9 and p95.maxHp > 1e-9 then
		local v98 = (p95.rate + v97) / p95.rate
		return {
			["hp"] = p95.hp * v98,
			["maxHp"] = p95.maxHp * v98,
			["rate"] = p95.rate + v97
		}
	end
	local v99
	if p95.maxHp > 1e-9 then
		local v100 = p95.hp / p95.maxHp
		v99 = math.clamp(v100, 0, 1)
	else
		v99 = 1
	end
	local v101 = v97 * v_u_1.TARGET_SECONDS
	return {
		["hp"] = v101 * v99,
		["maxHp"] = v101,
		["rate"] = v97
	}
end
function v_u_54.leave(p102, p103) -- name: leave
	local v104 = math.max(p103, 0)
	local v105 = p102.rate - v104
	if v105 <= 1e-9 then
		return {
			["hp"] = nil,
			["maxHp"] = nil,
			["rate"] = 0,
			["hp"] = p102.hp,
			["maxHp"] = p102.maxHp
		}
	end
	local v106 = v105 / p102.rate
	return {
		["hp"] = p102.hp * v106,
		["maxHp"] = p102.maxHp * v106,
		["rate"] = v105
	}
end
function v_u_54.hurt(p107, p108) -- name: hurt
	local v109 = {}
	local v110 = p107.hp - math.max(p108, 0)
	v109.hp = math.max(0, v110)
	v109.maxHp = p107.maxHp
	v109.rate = p107.rate
	return v109
end
function v_u_54.share(p111) -- name: share
	if p111.maxHp <= 1e-9 then
		return 0
	end
	local v112 = p111.hp / p111.maxHp
	return math.clamp(v112, 0, 1)
end
function v_u_54.credit(p113, p114) -- name: credit
	return math.max(p113, 0) / math.max(p114, 1e-9)
end
v_u_54.FLOOR_CREDIT = 5
function v_u_54.payouts(p115, p116) -- name: payouts
	-- upvalues: (copy) v_u_1, (copy) v_u_54
	local v117 = {}
	local v118 = 0
	local v119 = 0
	for v120, v121 in p116 do
		v117[v120] = 0
		if v121.credit <= 0 then
			continue
		end
		local v122 = v_u_1.COINS_PER_WIN
		local v123 = v121.joinShare
		v118 = v118 + v122 * math.clamp(v123, 0, 1)
		v119 = v119 + v121.credit
	end
	if not p115 or v119 <= 0 then
		return v117
	end
	for v124, v125 in p116 do
		if v125.credit <= 0 then
			continue
		end
		local v126 = v118 * v125.credit / v119 + 0.5
		local v127 = math.floor(v126)
		local v128 = v125.credit < v_u_54.FLOOR_CREDIT and 1 or v_u_1.COINS_FLOOR
		local v129 = v_u_1.COINS_MAX
		v117[v124] = math.clamp(v127, v128, v129)
	end
	return v117
end
function v_u_54.chakraBoost(p130, p131) -- name: chakraBoost
	-- upvalues: (copy) v_u_1
	if p130 <= 0 or (p131 <= 0 or p130 <= p131) then
		return 1
	end
	local v132 = v_u_1.BOOST_PER_TEN
	local v133 = p130 / p131
	local v134 = 1 + v132 * math.log10(v133)
	local v135 = v_u_1.BOOST_MAX
	return math.clamp(v134, 1, v135)
end
function v_u_54.fightSeconds(p136) -- name: fightSeconds
	-- upvalues: (copy) v_u_1
	if p136 <= 1 then
		return v_u_1.FIGHT_SECONDS_SOLO
	else
		return v_u_1.FIGHT_SECONDS
	end
end
function v_u_54.expectedSeconds(p137, p138) -- name: expectedSeconds
	-- upvalues: (copy) v_u_1, (copy) v_u_54
	local v139 = v_u_1.TARGET_SECONDS * v_u_54.EFFORT
	local v140 = p137 * p138
	return v139 / math.max(v140, 1e-6)
end
function v_u_54.countdown(p141, p142) -- name: countdown
	-- upvalues: (copy) v_u_1, (copy) v_u_54
	local v143 = p142 - p141
	if v_u_1.COUNTDOWN < v143 then
		return nil
	end
	if v143 <= 0 then
		return -v143 < v_u_54.FIGHT_SHOWN and "FIGHT!" or nil
	end
	local v144 = math.ceil(v143)
	local v145 = v_u_1.COUNTDOWN
	local v146 = math.clamp(v144, 1, v145)
	return tostring(v146)
end
function v_u_54.yawToward(p147, p148, p149, p150) -- name: yawToward
	local v151 = -(p149 - p147)
	local v152 = -(p150 - p148)
	return math.atan2(v151, v152)
end
function v_u_54.angleBetween(p153, p154) -- name: angleBetween
	local v155 = (p153 - p154) % 6.283185307179586
	if v155 > 3.141592653589793 then
		v155 = 6.283185307179586 - v155
	end
	return v155
end
function v_u_54.inside(p156, p157, p158, p159) -- name: inside
	-- upvalues: (copy) v_u_54
	local v160 = p157 - p156.x
	local v161 = p158 - p156.z
	local v162 = v160 * v160 + v161 * v161
	local v163 = math.sqrt(v162)
	if p156.kind == "circle" then
		return v163 <= p156.radius - p159
	end
	if p156.kind == "ring" then
		local v164
		if v163 <= p156.radius - p159 then
			v164 = (p156.inner or 0) + p159 <= v163
		else
			v164 = false
		end
		return v164
	end
	if p156.radius - p159 < v163 then
		return false
	end
	if v163 < 4 then
		return true
	end
	local v165 = -v160
	local v166 = -v161
	local v167 = math.atan2(v165, v166)
	local v168 = p159 / v163
	local v169 = math.min(v168, 0.3)
	return v_u_54.angleBetween(v167, p156.yaw or 0) <= (p156.half or 0) - v169
end
function v_u_54.hits(p170, p171, p172, p173) -- name: hits
	-- upvalues: (copy) v_u_54
	for _, v174 in p170 do
		if not v_u_54.inside(v174, p171, p172, p173) then
			continue
		end
		return true
	end
	return false
end
function v_u_54.crowd(p175, p176) -- name: crowd
	local v177 = -1
	local v178 = nil
	for _, v179 in p175 do
		local v180 = 0
		for _, v181 in p175 do
			local v182 = v179.X - v181.X
			local v183 = v179.Z - v181.Z
			if v182 * v182 + v183 * v183 > p176 * p176 then
				continue
			end
			v180 = v180 + 1
		end
		if v177 >= v180 then
			break
		end
		v178 = v179
		v177 = v180
	end
	if v178 then
		return v178.X, v178.Z
	else
		return 0, 0
	end
end
function v_u_54.shapes(p184, p185, p186, p187, p188, p189) -- name: shapes
	-- upvalues: (copy) v_u_54
	if p184 ~= "fox_rain" then
		if p184 == "claw_left" or p184 == "claw_right" then
			local v190
			if p184 == "claw_left" then
				v190 = v_u_54.CLAW_TURN
			else
				v190 = -v_u_54.CLAW_TURN
			end
			return {
				{
					["kind"] = "cone",
					["x"] = nil,
					["z"] = nil,
					["radius"] = nil,
					["yaw"] = nil,
					["half"] = nil,
					["x"] = p185,
					["z"] = p186,
					["radius"] = v_u_54.CLAW_REACH,
					["yaw"] = p187 + v190,
					["half"] = v_u_54.CLAW_HALF
				}
			}
		elseif p184 == "tail_sweep" then
			return {
				{
					["kind"] = "ring",
					["x"] = nil,
					["z"] = nil,
					["radius"] = nil,
					["inner"] = nil,
					["x"] = p185,
					["z"] = p186,
					["radius"] = v_u_54.TAIL_OUTER,
					["inner"] = v_u_54.TAIL_INNER
				}
			}
		elseif p184 == "stomp" then
			local v191 = #p188
			local v192 = v_u_54.STOMP_MAX
			local v193 = {}
			for v194 = 1, math.min(v191, v192) do
				local v195 = p188[v194]
				local v196 = {
					["kind"] = "circle",
					["x"] = nil,
					["z"] = nil,
					["radius"] = nil,
					["x"] = v195.X,
					["z"] = v195.Z,
					["radius"] = v_u_54.STOMP_RADIUS
				}
				table.insert(v193, v196)
			end
			if #v193 == 0 then
				local v197 = {
					["kind"] = "circle",
					["x"] = nil,
					["z"] = nil,
					["radius"] = nil,
					["x"] = p185,
					["z"] = p186,
					["radius"] = v_u_54.STOMP_RADIUS * 2
				}
				table.insert(v193, v197)
			end
			return v193
		else
			if p184 == "roar" then
				return {
					{
						["kind"] = "circle",
						["x"] = nil,
						["z"] = nil,
						["radius"] = nil,
						["x"] = p185,
						["z"] = p186,
						["radius"] = v_u_54.ROAR_RADIUS
					}
				}
			end
			if p184 ~= "leap" then
				if #p188 > 0 then
					p185, p186 = v_u_54.crowd(p188, v_u_54.BOMB_RADIUS)
				end
				return {
					{
						["kind"] = "circle",
						["x"] = nil,
						["z"] = nil,
						["radius"] = nil,
						["x"] = p185,
						["z"] = p186,
						["radius"] = v_u_54.BOMB_RADIUS
					}
				}
			end
			local v198 = p188[1]
			if v198 then
				p185 = v198.X
			end
			if v198 then
				p186 = v198.Z
			end
			return {
				{
					["kind"] = "circle",
					["x"] = nil,
					["z"] = nil,
					["radius"] = nil,
					["x"] = p185,
					["z"] = p186,
					["radius"] = v_u_54.LEAP_RADIUS
				}
			}
		end
	end
	local v199 = #p188
	local v200 = v_u_54.RAIN_MAX
	local v201 = {}
	for v202 = 1, math.min(v199, v200) do
		local v203 = p188[v202]
		local v204 = {
			["kind"] = "circle",
			["x"] = nil,
			["z"] = nil,
			["radius"] = nil,
			["x"] = v203.X,
			["z"] = v203.Z,
			["radius"] = v_u_54.RAIN_RADIUS
		}
		table.insert(v201, v204)
	end
	local v205 = p189 or {}
	for v206 = 1, v_u_54.RAIN_EXTRA do
		local v207 = v205[v206 * 2 - 1]
		local v208 = v205[v206 * 2]
		if v207 == nil or v208 == nil then
			break
		end
		local v209 = v207 * 2 * 3.141592653589793
		local v210 = (v_u_54.RAIN_NEAR + (v_u_54.RAIN_FAR - v_u_54.RAIN_NEAR) * v208) * v_u_54.FLOOR_RADIUS
		local v211 = {
			["kind"] = "circle",
			["x"] = nil,
			["z"] = nil,
			["radius"] = nil,
			["x"] = p185 - math.sin(v209) * v210,
			["z"] = p186 - math.cos(v209) * v210,
			["radius"] = v_u_54.RAIN_RADIUS
		}
		table.insert(v201, v211)
	end
	return v201
end
function v_u_54.choose(p212, p213, p214, p215, p216, p217) -- name: choose
	-- upvalues: (copy) v_u_58, (copy) v_u_54
	local v218 = p215 == true
	local v219 = p217 == true
	local v220 = 0
	for v221 = 1, #v_u_58 do
		local v222 = v_u_58[v221]
		local v223
		if v222 == p213 then
			v223 = false
		else
			local v224 = v_u_54.ATTACKS[v222]
			local v225
			if p216 == "near" then
				v225 = v224.near
			elseif p216 == "far" then
				v225 = v224.far
			else
				v225 = v224.weight
			end
			if v225 <= 0 or (v_u_54.ATTACKS[v222].rage and not v218 or v222 == "leap" and (not v219 or p216 ~= "far")) then
				v223 = false
			else
				v223 = p214 or v222 ~= "bomb"
			end
		end
		if not v223 then
			continue
		end
		local v226 = v_u_54.ATTACKS[v222]
		local v227
		if p216 == "near" then
			v227 = v226.near
		elseif p216 == "far" then
			v227 = v226.far
		else
			v227 = v226.weight
		end
		v220 = v220 + v227
	end
	local v228 = math.clamp(p212, 0, 0.999999) * v220
	local v229 = "tail_sweep"
	for v230 = 1, #v_u_58 do
		local v231 = v_u_58[v230]
		local v232
		if v231 == p213 then
			v232 = false
		else
			local v233 = v_u_54.ATTACKS[v231]
			local v234
			if p216 == "near" then
				v234 = v233.near
			elseif p216 == "far" then
				v234 = v233.far
			else
				v234 = v233.weight
			end
			if v234 <= 0 or (v_u_54.ATTACKS[v231].rage and not v218 or v231 == "leap" and (not v219 or p216 ~= "far")) then
				v232 = false
			else
				v232 = p214 or v231 ~= "bomb"
			end
		end
		if not v232 then
			continue
		end
		local v235 = v_u_54.ATTACKS[v231]
		local v236
		if p216 == "near" then
			v236 = v235.near
		elseif p216 == "far" then
			v236 = v235.far
		else
			v236 = v235.weight
		end
		v228 = v228 - v236
		if v228 < 0 then
			return v231
		end
		v229 = v231
	end
	return v229
end
function v_u_54.rest(p237, p238) -- name: rest
	if p238 then
		return p237 * 0.6 + 0.6
	else
		return p237 * 0.8 + 1.2
	end
end
function v_u_54.bombEvery(p239) -- name: bombEvery
	-- upvalues: (copy) v_u_54
	if p239 then
		return v_u_54.BOMB_RAGE_EVERY
	else
		return v_u_54.BOMB_EVERY
	end
end
function v_u_54.afterHit(p240, p241, p242) -- name: afterHit
	local v243 = p240 - p242 * p241
	if v243 <= 0 then
		return 0, true
	else
		return v243, false
	end
end
v_u_54.BOARD_KEEP = 50
function v_u_54.board(p244) -- name: board
	-- upvalues: (copy) v_u_54
	local v245 = 0
	for _, v246 in p244 do
		local v247 = v246.dealt
		v245 = v245 + math.max(v247, 0)
	end
	local v248 = table.clone(p244)
	table.sort(v248, function(p249, p250)
		if p249.dealt == p250.dealt then
			return p249.id < p250.id
		else
			return p249.dealt > p250.dealt
		end
	end)
	local v251 = {}
	for v252, v253 in v248 do
		if v_u_54.BOARD_KEEP < v252 then
			break
		end
		local v254
		if v245 > 0 then
			local v255 = v253.dealt
			v254 = math.max(v255, 0) / v245
		else
			v254 = 0
		end
		local v256 = {
			["id"] = v253.id,
			["name"] = v253.name
		}
		local v257 = v254 * 1000 + 0.5
		v256.share = math.floor(v257) / 1000
		table.insert(v251, v256)
	end
	return v251
end
function v_u_54.boardRows(p258, p259, p260) -- name: boardRows
	local v261 = {}
	for v262, v263 in p258 do
		local v264 = v263.id == p259
		if v262 > p260 then
			if not v264 then
				continue
			end
			table.insert(v261, {
				["rank"] = nil,
				["line"] = nil,
				["mine"] = true,
				["rank"] = v262,
				["line"] = v263
			})
			return v261
		end
		table.insert(v261, {
			["rank"] = v262,
			["line"] = v263,
			["mine"] = v264
		})
	end
	return v261
end
function v_u_54.percentText(p265) -- name: percentText
	if p265 <= 0 then
		return "0%"
	end
	if p265 < 0.01 then
		return "<1%"
	end
	local v266 = p265 * 100 + 0.5
	return math.floor(v266) .. "%"
end
return v_u_54