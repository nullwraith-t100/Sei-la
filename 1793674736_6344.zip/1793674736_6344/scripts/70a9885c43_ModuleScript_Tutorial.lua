local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TextChatService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.Device)
local v_u_8 = require(script.Parent.Events)
local v_u_9 = require(script.Parent.Gamepad)
local v_u_10 = require(script.Parent.Sfx)
local v_u_11 = require(script.Parent.State)
local v_u_12 = require(script.Parent.Fx.Kit)
local v_u_13 = require(script.Parent.Fx.Abilities)
local v14 = v2.Shared
local v_u_15 = require(v14.Logic.Tutorial)
local v_u_16 = require(v14.Logic.Economy)
local v_u_17 = require(v14.Config.Eyes)
local v_u_18 = require(v14.Config.Abilities)
local v_u_19 = require(v14.Config.Images)
local v_u_20 = require(v14.Net)
local v_u_21 = require(v14.Config.World)
local v_u_22 = {}
local v_u_23 = v1.LocalPlayer
local v_u_24 = "done"
local v_u_25 = false
local v_u_26 = {}
local v_u_27 = {
	"battle",
	"fight",
	"pad",
	"eye",
	"skillE",
	"skillR",
	"train",
	"rebirth"
}
local v_u_28 = false
local v_u_29 = 0
local v_u_30 = 0
local v_u_31 = nil
local v_u_32 = nil
function v_u_22.step() -- name: step
	-- upvalues: (ref) v_u_24
	return v_u_24
end
function v_u_22.active() -- name: active
	-- upvalues: (ref) v_u_25, (ref) v_u_24
	local v33 = v_u_25
	if v33 then
		v33 = v_u_24 ~= "done"
	end
	return v33
end
function v_u_22.known() -- name: known
	-- upvalues: (ref) v_u_25
	return v_u_25
end
function v_u_22.onChange(p34) -- name: onChange
	-- upvalues: (copy) v_u_26
	local v35 = v_u_26
	table.insert(v35, p34)
end
local function v_u_39() -- name: info
	-- upvalues: (copy) v_u_11, (ref) v_u_28, (copy) v_u_23, (copy) v_u_17, (ref) v_u_29, (ref) v_u_30, (copy) v_u_16
	if v_u_11.number("TrainSpot") > 0 and v_u_11.number("TrainMult", 1) > 1 then
		v_u_28 = true
	end
	local v36 = v_u_11.number("Rebirths")
	local v37 = {
		["done"] = v_u_23:GetAttribute("TutorialDone") == true,
		["rebirths"] = v36,
		["totalWins"] = v_u_11.number("TotalWins"),
		["inWave"] = v_u_23:GetAttribute("InWave") == true,
		["runCleared"] = v_u_11.number("RunCleared")
	}
	local v38
	if v_u_11.number("TrainSpot") > 0 then
		v38 = v_u_11.number("TrainMult", 1) > 1
	else
		v38 = false
	end
	v37.onPlot = v38
	v37.upgraded = v_u_17.chain[2] == nil and true or v_u_11.eyes()[v_u_17.chain[2].id] ~= nil
	v37.usedE = v_u_29 > 0
	v37.usedR = v_u_30 > 0
	v37.trained = v_u_28
	v37.level = v_u_11.number("Level", 1)
	v37.rebirthLevel = v_u_16.rebirthLevel(v36)
	return v37
end
local function v_u_43(p40) -- name: rebirthWords
	-- upvalues: (copy) v_u_9, (copy) v_u_7
	if p40 then
		local v41 = v_u_9.active()
		if v41 then
			v41 = not v_u_7.touch()
		end
		return not v41 and "Press REBIRTH!" or ("Press %* to REBIRTH!"):format((v_u_9.name(Enum.KeyCode.ButtonA)))
	else
		local v42 = v_u_9.active()
		if v42 then
			v42 = not v_u_7.touch()
		end
		return not v42 and "Rebirth to get stronger!" or ("Rebirth to get stronger! Press %*!"):format((v_u_9.name(Enum.KeyCode.DPadLeft)))
	end
end
local function v_u_62(p44) -- name: instruction
	-- upvalues: (copy) v_u_9, (copy) v_u_7, (ref) v_u_31, (copy) v_u_17, (copy) v_u_11, (copy) v_u_18, (copy) v_u_16
	if p44 == "battle" then
		return "Go to the battle!"
	elseif p44 == "fight" then
		local v45 = v_u_9.active()
		if v45 then
			v45 = not v_u_7.touch()
		end
		if v45 then
			return ("Defeat the enemies! Hold %* to attack!"):format((v_u_9.name(Enum.KeyCode.ButtonR2)))
		else
			return ("Defeat the enemies! %* to attack!"):format(v_u_7.touch() and "Tap" or "Click")
		end
	else
		if p44 == "pad" then
			return "Grab the win pad!"
		end
		if p44 == "eye" then
			local v46
			if v_u_31 then
				v46 = v_u_17.nextLocked(v_u_11.eyes())
			else
				v46 = v_u_17.chain[2]
			end
			return v_u_31 and "Upgrade your eye! Walk onto an eye pad!" or ("Upgrade your eye! Walk onto the %* pad!"):format(not v46 and "next eye" or v46.short)
		end
		if p44 ~= "skillE" and p44 ~= "skillR" then
			if p44 == "train" then
				return "Go to the training zone!"
			end
			if p44 ~= "level" then
				if p44 ~= "rebirth" then
					return ""
				end
				local v47 = v_u_9.active()
				if v47 then
					v47 = not v_u_7.touch()
				end
				return not v47 and "Rebirth to get stronger!" or ("Rebirth to get stronger! Press %*!"):format((v_u_9.name(Enum.KeyCode.DPadLeft)))
			end
			local v48 = v_u_16.rebirthLevel(v_u_11.number("Rebirths"))
			local v49 = v_u_11.number("Level", 1)
			local v50 = math.min(v49, v48)
			local v51 = v_u_9.active()
			if v51 then
				v51 = not v_u_7.touch()
			end
			local v52
			if v51 then
				v52 = ("Press %*"):format((v_u_9.name(Enum.KeyCode.ButtonR2)))
			else
				v52 = v_u_7.touch() and "Tap" or "Click"
			end
			return ("Reach level %*! %* to go faster!   %* / %*"):format(v48, v52, v50, v48)
		end
		local v53 = v_u_17.byId[v_u_11.string("Eye")] or v_u_17.byId[v_u_17.STARTER]
		local v54 = v_u_18.byId
		local v55
		if p44 == "skillE" then
			v55 = v53.skillE
		else
			v55 = v53.skillR
		end
		local v56 = v54[v55]
		local v57 = p44 == "skillE" and "E" or "R"
		local v58 = v_u_9.active()
		if v58 then
			v58 = not v_u_7.touch()
		end
		if v58 then
			local v59 = v_u_9.name
			local v60
			if p44 == "skillE" then
				v60 = Enum.KeyCode.ButtonL1
			else
				v60 = Enum.KeyCode.ButtonR1
			end
			v57 = v59(v60)
		end
		local v61 = v_u_7.touch() and "Tap" or "Press"
		return ("Use %*! %* %*!"):format(not v56 and "your ability" or v56.name, v61, v57)
	end
end
local function v_u_70(p63) -- name: localPlace
	-- upvalues: (copy) v_u_21, (copy) v_u_11, (ref) v_u_31, (copy) v_u_17
	if p63 == "battle" then
		local v64 = v_u_21.FLOOR_Y
		local v65 = v_u_21.stageStart(1) - v_u_21.TRIGGER_DEPTH - 6
		return Vector3.new(0, v64, v65)
	else
		if p63 == "pad" then
			return v_u_21.padPosition(1, "gold")
		end
		if p63 == "eye" then
			local v66 = v_u_11.number("World", 1)
			local v67
			if v_u_31 then
				v67 = v_u_17.nextLocked(v_u_11.eyes())
			else
				v67 = v_u_17.chain[2]
			end
			if v_u_31 and (not v67 or (v67.world or 1) ~= v66) then
				v67 = v_u_17.padEyesFor(v66)[1]
			end
			for v68, v69 in v_u_17.padEyesFor(v66) do
				if not v67 or v69.id ~= v67.id then
					continue
				end
				return v_u_21.eyePadsFor(v66)[v68]
			end
		elseif p63 == "train" then
			return v_u_21.TRAINING[1]
		end
		return nil
	end
end
local v_u_71 = nil
local v_u_72 = Color3.fromRGB(255, 220, 80)
local v_u_73 = {}
local v_u_74 = {}
local v_u_75 = nil
local v_u_76 = nil
local function v_u_83() -- name: makeGuide
	-- upvalues: (ref) v_u_71, (copy) v_u_19, (copy) v_u_74, (copy) v_u_72, (copy) v_u_73, (ref) v_u_75, (ref) v_u_76, (copy) v_u_6
	v_u_71 = Instance.new("Folder")
	v_u_71.Name = "TutorialGuide"
	for _ = 1, 3 do
		local v77 = Instance.new("Part")
		v77.Name = "Chevron"
		v77.Anchored = true
		v77.CanCollide = false
		v77.CanQuery = false
		v77.CanTouch = false
		v77.CastShadow = false
		v77.Transparency = 1
		v77.Size = Vector3.new(6, 0.2, 6)
		local v78 = Instance.new("Decal")
		v78.Texture = v_u_19.Icon.GuideChevron
		v78.Face = Enum.NormalId.Top
		v78.Parent = v77
		v77.Parent = v_u_71
		local v79 = v_u_74
		table.insert(v79, {
			["part"] = v77,
			["decal"] = v78
		})
	end
	for _ = 1, 40 do
		local v80 = Instance.new("Part")
		v80.Name = "Trail"
		v80.Anchored = true
		v80.CanCollide = false
		v80.CanQuery = false
		v80.CanTouch = false
		v80.CastShadow = false
		v80.Material = Enum.Material.Neon
		v80.Color = v_u_72
		v80.Size = Vector3.new(1.7, 0.12, 2.8)
		v80.Transparency = 1
		v80.Parent = v_u_71
		local v81 = v_u_73
		table.insert(v81, v80)
	end
	v_u_75 = Instance.new("Part")
	v_u_75.Name = "Marker"
	v_u_75.Anchored = true
	v_u_75.CanCollide = false
	v_u_75.CanQuery = false
	v_u_75.CanTouch = false
	v_u_75.Transparency = 1
	v_u_75.Size = Vector3.new(1, 1, 1)
	v_u_76 = Instance.new("BillboardGui")
	v_u_76.AlwaysOnTop = true
	v_u_76.LightInfluence = 0
	v_u_76.Size = UDim2.fromScale(7, 7)
	v_u_76.MaxDistance = 1000
	local v82 = Instance.new("ImageLabel")
	v82.BackgroundTransparency = 1
	v82.Size = UDim2.fromScale(1, 1)
	v82.Image = v_u_19.Icon.GuideArrow
	v82.Parent = v_u_76
	v_u_76.Adornee = v_u_75
	v_u_76.Parent = v_u_75
	v_u_75.Parent = v_u_71
	v_u_71.Parent = v_u_6
end
local function v_u_105(p84, p85) -- name: showTrail
	-- upvalues: (copy) v_u_73
	local v86 = p85.X - p84.X
	local v87 = p85.Z - p84.Z
	local v88 = Vector3.new(v86, 0, v87)
	local v89 = v88.Magnitude
	if v89 < 6 then
		for _, v90 in v_u_73 do
			v90.Transparency = 1
		end
	else
		local v91 = v88.Unit
		local v92 = p85.Y + 0.15
		local v93 = os.clock() * 7 % 4
		for v94, v95 in v_u_73 do
			local v96 = (v94 - 1) * 4 + 2.5 + v93
			if v89 - 1 < v96 then
				v95.Transparency = 1
			else
				local v97 = (v96 - 2.5) / 3
				local v98 = math.clamp(v97, 0, 1)
				local v99 = (v89 - 1 - v96) / 3
				local v100 = math.clamp(v99, 0, 1)
				local v101 = math.min(v98, v100)
				local v102 = p84.X
				local v103 = p84.Z
				local v104 = Vector3.new(v102, v92, v103) + v91 * v96
				v95.CFrame = CFrame.lookAt(v104, v104 + v91)
				v95.Transparency = 1 - v101 * 0.95
			end
		end
	end
end
local function v_u_138(p106, p107) -- name: showGuide
	-- upvalues: (copy) v_u_23, (copy) v_u_105, (copy) v_u_73, (copy) v_u_74, (ref) v_u_76, (ref) v_u_75
	local v108 = v_u_23.Character
	if v108 then
		v108 = v108:FindFirstChild("HumanoidRootPart")
	end
	if p107 and (p106 and (v108 and v108:IsA("BasePart"))) then
		v_u_105(v108.Position, p106)
	else
		for _, v109 in v_u_73 do
			v109.Transparency = 1
		end
	end
	if p106 and (v108 and v108:IsA("BasePart")) then
		local v110 = os.clock()
		v_u_76.Enabled = true
		local v111 = v_u_75
		local v112 = v110 * 4
		local v113 = math.sin(v112) * 1.2 + 9
		v111.Position = p106 + Vector3.new(0, v113, 0)
		local v114 = v108.Position
		local v115 = p106.X - v114.X
		local v116 = p106.Z - v114.Z
		local v117 = Vector3.new(v115, 0, v116)
		local v118 = v117.Magnitude
		if v118 < 8 then
			for _, v119 in v_u_74 do
				v119.decal.Transparency = 1
			end
		else
			local v120 = v117.Unit
			local v121 = v108.Parent
			if v121 then
				v121 = v108.Parent:FindFirstChildOfClass("Humanoid")
			end
			local v122 = not v121 and 2 or v121.HipHeight
			local v123 = v108.Position.Y - v108.Size.Y / 2 - v122 + 0.15
			local v124 = v110 * 6 % 5
			for v125, v126 in v_u_74 do
				local v127 = (v125 - 1) * 5 + 7 + v124
				local v128 = (v127 - 7) / 1.5
				local v129 = math.clamp(v128, 0, 1)
				local v130 = (22 - v127) / 1.5
				local v131 = math.clamp(v130, 0, 1)
				local v132 = (v118 - v127 - 2) / 2
				local v133 = math.clamp(v132, 0, 1)
				local v134 = v114.X
				local v135 = v114.Z
				local v136 = Vector3.new(v134, v123, v135) + v120 * v127
				v126.part.CFrame = CFrame.lookAt(v136, v136 - v120)
				v126.decal.Transparency = 1 - math.min(v129, v131) * v133 * 0.95
			end
		end
	else
		for _, v137 in v_u_74 do
			v137.decal.Transparency = 1
		end
		v_u_76.Enabled = false
		return
	end
end
local function v_u_140() -- name: menuOpen
	-- upvalues: (ref) v_u_32
	for _, v139 in v_u_32:GetChildren() do
		if not (v139:IsA("GuiObject") and v139.Visible) then
			continue
		end
		return true
	end
	return false
end
local v_u_141 = nil
local v_u_142 = nil
local v_u_143 = nil
local v_u_144 = nil
local v_u_145 = nil
local v_u_146 = nil
local v_u_147 = nil
local function v_u_163(p148) -- name: showEdge
	-- upvalues: (copy) v_u_6, (ref) v_u_146, (ref) v_u_142
	local v149 = v_u_6.CurrentCamera
	if p148 and v149 then
		local v150, v151 = v149:WorldToViewportPoint(p148 + Vector3.new(0, 4, 0))
		local v152 = v149.ViewportSize
		if v151 and (v150.X > 40 and (v150.X < v152.X - 40 and (v150.Y > 40 and v150.Y < v152.Y - 40))) then
			v_u_146.Visible = false
		else
			local v153 = v152 / 2
			local v154 = Vector2.new(v150.X, v150.Y) - v153
			if v150.Z < 0 then
				v154 = -v154
			end
			if v154.Magnitude < 1 then
				v154 = Vector2.new(0, 1)
			end
			local v155 = v154.Unit
			local v156 = v152.X
			local v157 = v152.Y
			local v158 = (v153 + v155 * (math.min(v156, v157) * 0.38)) / v152 * v_u_142.AbsoluteSize
			v_u_146.Visible = true
			v_u_146.Position = UDim2.fromOffset(v158.X, v158.Y)
			local v159 = v_u_146
			local v160 = v155.Y
			local v161 = v155.X
			local v162 = math.atan2(v160, v161)
			v159.Rotation = math.deg(v162) - 90
		end
	else
		v_u_146.Visible = false
		return
	end
end
local function v_u_167(p164) -- name: hudButton
	-- upvalues: (copy) v_u_23
	local v165 = v_u_23:FindFirstChild("PlayerGui")
	for v166 in string.gmatch(p164, "[^%.]+") do
		if not v165 then
			continue
		end
		v165 = v165:FindFirstChild(v166)
	end
	if v165 and v165:IsA("GuiObject") then
		return v165
	else
		return nil
	end
end
local function v_u_187(p168) -- name: showPointer
	-- upvalues: (copy) v_u_167, (ref) v_u_145, (ref) v_u_142, (ref) v_u_144, (copy) v_u_9, (copy) v_u_7, (copy) v_u_43
	if p168 == "skillE" or p168 == "skillR" then
		local v169 = v_u_167(p168 == "skillE" and "Main.HUD.Skills.E" or "Main.HUD.Skills.R")
		if v169 and v169.Visible then
			local v170 = v169.AbsolutePosition - v_u_142.AbsolutePosition
			local v171 = v169.AbsoluteSize
			v_u_145.Visible = true
			v_u_145.Rotation = 0
			local v172 = v_u_145
			local v173 = UDim2.fromOffset
			local v174 = v170.X + v171.X / 2
			local v175 = v170.Y - 34
			local v176 = os.clock() * 6
			v172.Position = v173(v174, v175 + math.sin(v176) * 8)
		else
			v_u_145.Visible = false
		end
	end
	if p168 ~= "rebirth" then
		v_u_145.Visible = false
		return
	end
	local v177 = v_u_167("Main.Frames.Rebirths")
	local v178
	if v177 == nil then
		v178 = false
	else
		v178 = v177.Visible
	end
	local v179
	if v178 then
		v179 = v_u_167("Main.Frames.Rebirths.Redeem")
	else
		v179 = v_u_167("Main.HUD.Left.Rebirths")
	end
	if not (v179 and v179.Visible) then
		v_u_145.Visible = false
		return
	end
	local v180 = v_u_144
	local v181, v182, v183, v184, v185
	if v178 then
		v181 = v_u_43(v178)
		v180.Text = v181
		v182 = os.clock() * 6
		v183 = math.sin(v182) * 8
		v184 = v179.AbsolutePosition - v_u_142.AbsolutePosition
		v185 = v179.AbsoluteSize
		v_u_145.Visible = true
		if v178 then
			v_u_145.Rotation = 0
			v_u_145.Position = UDim2.fromOffset(v184.X + v185.X / 2, v184.Y - 40 + v183)
		else
			v_u_145.Rotation = 90
			v_u_145.Position = UDim2.fromOffset(v184.X + v185.X + 45 + v183, v184.Y + v185.Y / 2)
		end
	else
		local v186 = v_u_9.active()
		if v186 then
			v186 = not v_u_7.touch()
		end
		if v186 and v_u_9.selected() == v179 then
			v181 = ("Press %*!"):format((v_u_9.name(Enum.KeyCode.ButtonA)))
			v180.Text = v181
			v182 = os.clock() * 6
			v183 = math.sin(v182) * 8
			v184 = v179.AbsolutePosition - v_u_142.AbsolutePosition
			v185 = v179.AbsoluteSize
			v_u_145.Visible = true
			if v178 then
				v_u_145.Rotation = 0
				v_u_145.Position = UDim2.fromOffset(v184.X + v185.X / 2, v184.Y - 40 + v183)
			else
				v_u_145.Rotation = 90
				v_u_145.Position = UDim2.fromOffset(v184.X + v185.X + 45 + v183, v184.Y + v185.Y / 2)
			end
		else
			v181 = v_u_43(v178)
			v180.Text = v181
			v182 = os.clock() * 6
			v183 = math.sin(v182) * 8
			v184 = v179.AbsolutePosition - v_u_142.AbsolutePosition
			v185 = v179.AbsoluteSize
			v_u_145.Visible = true
			if v178 then
				v_u_145.Rotation = 0
				v_u_145.Position = UDim2.fromOffset(v184.X + v185.X / 2, v184.Y - 40 + v183)
			else
				v_u_145.Rotation = 90
				v_u_145.Position = UDim2.fromOffset(v184.X + v185.X + 45 + v183, v184.Y + v185.Y / 2)
			end
		end
	end
end
local v_u_188 = {
	Color3.fromRGB(255, 80, 90),
	Color3.fromRGB(255, 214, 64),
	Color3.fromRGB(80, 220, 120),
	Color3.fromRGB(70, 170, 255),
	Color3.fromRGB(190, 110, 255)
}
local function v_u_192(p189) -- name: confetti
	-- upvalues: (copy) v_u_188, (copy) v_u_5
	for _ = 1, 70 do
		local v_u_190 = Instance.new("Frame")
		v_u_190.BorderSizePixel = 0
		v_u_190.BackgroundColor3 = v_u_188[math.random(#v_u_188)]
		v_u_190.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_190.Size = UDim2.fromOffset(math.random(7, 13), math.random(12, 20))
		v_u_190.Position = UDim2.fromScale(math.random(), -0.05 - math.random() * 0.3)
		v_u_190.Rotation = math.random(0, 360)
		v_u_190.ZIndex = 24
		v_u_190.Parent = p189
		local v191 = 1.8 + math.random() * 1.6
		v_u_5:Create(v_u_190, TweenInfo.new(v191, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
			["Position"] = UDim2.fromScale(v_u_190.Position.X.Scale + (math.random() - 0.5) * 0.3, 1.1),
			["Rotation"] = v_u_190.Rotation + math.random(-540, 540)
		}):Play()
		task.delay(v191, function()
			-- upvalues: (copy) v_u_190
			v_u_190:Destroy()
		end)
	end
end
local function v_u_196() -- name: celebrate
	-- upvalues: (ref) v_u_147, (copy) v_u_5, (copy) v_u_192, (ref) v_u_141, (copy) v_u_10, (copy) v_u_23, (copy) v_u_12
	v_u_147.Visible = true
	v_u_147.TextTransparency = 0
	local v_u_193 = v_u_147:FindFirstChildOfClass("UIStroke")
	if v_u_193 then
		v_u_193.Transparency = 0
	end
	local v194 = v_u_147:FindFirstChild("Pop")
	if not (v194 and v194:IsA("UIScale")) then
		v194 = Instance.new("UIScale")
		v194.Name = "Pop"
		v194.Parent = v_u_147
	end
	v194.Scale = 0.3
	v_u_5:Create(v194, TweenInfo.new(0.45, Enum.EasingStyle.Back), {
		["Scale"] = 1
	}):Play()
	v_u_192(v_u_141)
	v_u_10.play("RevealBig")
	v_u_10.play("WaveClear", {
		["volume"] = 0.8
	})
	local v195 = v_u_23.Character
	if v195 then
		v195 = v_u_23.Character:FindFirstChild("HumanoidRootPart")
	end
	if v195 and v195:IsA("BasePart") then
		v_u_12.burst("Sparkle", v195.Position + Vector3.new(0, 2, 0), nil, 2)
	end
	task.delay(2.6, function()
		-- upvalues: (ref) v_u_5, (ref) v_u_147, (copy) v_u_193
		v_u_5:Create(v_u_147, TweenInfo.new(0.5), {
			["TextTransparency"] = 1
		}):Play()
		if v_u_193 then
			v_u_5:Create(v_u_193, TweenInfo.new(0.5), {
				["Transparency"] = 1
			}):Play()
		end
		task.delay(0.5, function()
			-- upvalues: (ref) v_u_147
			v_u_147.Visible = false
		end)
	end)
end
local function v_u_201() -- name: replayStep
	-- upvalues: (ref) v_u_31, (copy) v_u_27, (copy) v_u_23, (copy) v_u_11, (ref) v_u_29, (ref) v_u_30, (ref) v_u_32
	local v197 = v_u_31
	if not v197 then
		return "done"
	end
	local v198 = v_u_27[v197.index]
	local v199 = false
	if v198 == "battle" then
		v199 = v_u_23:GetAttribute("InWave") == true and true or v_u_11.number("RunCleared") >= 1
	elseif v198 == "fight" then
		v199 = v_u_11.number("RunCleared") >= 1
	elseif v198 == "pad" then
		v199 = v197.padAt > 0
	elseif v198 == "eye" then
		v199 = v197.eyeAt > 0
	elseif v198 == "skillE" then
		v199 = v_u_29 > v197.startedAt
	elseif v198 == "skillR" then
		v199 = v_u_30 > v197.startedAt
	elseif v198 == "train" then
		if v_u_11.number("TrainSpot") > 0 then
			v199 = v_u_11.number("TrainMult", 1) > 1
		else
			v199 = false
		end
	elseif v198 == "rebirth" then
		local v200 = v_u_32:FindFirstChild("Rebirths")
		v199 = v_u_11.number("Rebirths") <= v197.startRebirths and (v200 ~= nil and v200:IsA("GuiObject"))
		if v199 then
			v199 = v200.Visible
		end
	end
	if not v199 then
		return v198
	end
	v197.index = v197.index + 1
	if v197.index <= #v_u_27 then
		return v_u_27[v197.index]
	end
	v_u_31 = nil
	return "done"
end
function v_u_22.replay() -- name: replay
	-- upvalues: (ref) v_u_25, (ref) v_u_31, (copy) v_u_11
	if v_u_25 then
		v_u_31 = {
			["index"] = 1,
			["startWins"] = nil,
			["startRebirths"] = nil,
			["padAt"] = 0,
			["eyeAt"] = 0,
			["startedAt"] = nil,
			["startWins"] = v_u_11.number("TotalWins"),
			["startRebirths"] = v_u_11.number("Rebirths"),
			["startedAt"] = os.clock()
		}
	end
end
local function v_u_208(p202) -- name: setStep
	-- upvalues: (ref) v_u_24, (ref) v_u_25, (ref) v_u_143, (ref) v_u_31, (copy) v_u_20, (ref) v_u_144, (copy) v_u_62, (copy) v_u_5, (copy) v_u_10, (copy) v_u_196, (copy) v_u_26
	if p202 ~= v_u_24 or not v_u_25 then
		local v203 = v_u_24
		local v204 = not v_u_25
		v_u_24 = p202
		v_u_25 = true
		v_u_143.Visible = p202 ~= "done"
		if not v_u_31 and p202 ~= "done" then
			v_u_20.event("Tutorial"):FireServer(p202)
		end
		v_u_144.Text = v_u_62(p202)
		if p202 ~= "done" and not v204 then
			local v205 = v_u_143:FindFirstChild("Pop")
			if v205 and v205:IsA("UIScale") then
				v205.Scale = 0.6
				v_u_5:Create(v205, TweenInfo.new(0.3, Enum.EasingStyle.Back), {
					["Scale"] = 1
				}):Play()
			end
			v_u_10.play("Click")
		end
		if p202 == "done" and (not v204 and v203 ~= "done") then
			v_u_196()
		end
		local v206 = v204 and "done" or v203
		for _, v207 in v_u_26 do
			task.spawn(v207, p202, v206)
		end
	end
end
function v_u_22.start() -- name: start
	-- upvalues: (copy) v_u_23, (ref) v_u_141, (ref) v_u_32, (ref) v_u_142, (ref) v_u_143, (ref) v_u_144, (ref) v_u_145, (ref) v_u_146, (ref) v_u_147, (copy) v_u_83, (copy) v_u_7, (copy) v_u_13, (copy) v_u_17, (copy) v_u_11, (ref) v_u_29, (ref) v_u_30, (copy) v_u_8, (ref) v_u_31, (copy) v_u_22, (copy) v_u_4, (copy) v_u_3, (ref) v_u_24, (copy) v_u_208, (copy) v_u_201, (copy) v_u_15, (copy) v_u_39, (copy) v_u_62, (copy) v_u_73, (copy) v_u_74, (ref) v_u_76, (copy) v_u_6, (copy) v_u_187, (copy) v_u_70, (copy) v_u_21, (copy) v_u_138, (copy) v_u_163, (copy) v_u_140
	local v209 = v_u_23:WaitForChild("PlayerGui"):WaitForChild("Main")
	v_u_141 = v209:WaitForChild("HUD"):WaitForChild("Tutorial")
	v_u_32 = v209:WaitForChild("Frames")
	v_u_142 = v_u_141
	v_u_143 = v_u_141:WaitForChild("Banner")
	v_u_144 = v_u_143:WaitForChild("Text")
	v_u_145 = v_u_141:WaitForChild("Pointer")
	v_u_146 = v_u_141:WaitForChild("Edge")
	v_u_147 = v_u_141:WaitForChild("Done")
	local v210 = Instance.new("UIScale")
	v210.Name = "Pop"
	v210.Parent = v_u_143
	v_u_143.Visible = false
	v_u_83()
	if v_u_7.touch() then
		v_u_143.Size = UDim2.fromScale(0.8, 0.11)
		v_u_145.Size = UDim2.fromScale(0.12, 0.12)
		v_u_146.Size = UDim2.fromScale(0.12, 0.12)
	end
	v_u_13.onCast(function(p211, _, p212)
		-- upvalues: (ref) v_u_23, (ref) v_u_17, (ref) v_u_11, (ref) v_u_29, (ref) v_u_30
		if p211 == v_u_23 then
			local v213 = v_u_17.byId[v_u_11.string("Eye")]
			if v213 and p212.id == v213.skillE then
				v_u_29 = os.clock()
			elseif v213 and p212.id == v213.skillR then
				v_u_30 = os.clock()
			end
		else
			return
		end
	end)
	v_u_8.on("pad", function()
		-- upvalues: (ref) v_u_31
		if v_u_31 then
			v_u_31.padAt = os.clock()
		end
	end)
	v_u_8.onNotify("EyePad", function()
		-- upvalues: (ref) v_u_31
		if v_u_31 then
			v_u_31.eyeAt = os.clock()
		end
	end)
	local v_u_214 = v_u_32:WaitForChild("Settings", 10)
	local v215
	if v_u_214 then
		v215 = v_u_214:FindFirstChild("ReplayTutorial", true)
	else
		v215 = v_u_214
	end
	if v215 and v215:IsA("GuiButton") then
		v215.Activated:Connect(function()
			-- upvalues: (copy) v_u_214, (ref) v_u_22
			if v_u_214 and v_u_214:IsA("GuiObject") then
				v_u_214.Visible = false
			end
			v_u_22.replay()
		end)
	end
	local v216 = Instance.new("TextChatCommand")
	v216.Name = "ReplayTutorial"
	v216.PrimaryAlias = "/tutorial"
	v216.Triggered:Connect(function()
		-- upvalues: (ref) v_u_22
		v_u_22.replay()
	end)
	v216.Parent = v_u_4
	while v_u_23:GetAttribute("Loaded") ~= true do
		task.wait(0.2)
	end
	local v_u_217 = false
	local v_u_218 = 0
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_24, (ref) v_u_31, (ref) v_u_218, (ref) v_u_208, (ref) v_u_201, (ref) v_u_15, (ref) v_u_39, (ref) v_u_144, (ref) v_u_62, (ref) v_u_217, (ref) v_u_23, (ref) v_u_73, (ref) v_u_74, (ref) v_u_76, (ref) v_u_6, (ref) v_u_146, (ref) v_u_187, (ref) v_u_143, (ref) v_u_70, (ref) v_u_21, (ref) v_u_11, (ref) v_u_138, (ref) v_u_163, (ref) v_u_140
		local v219 = os.clock()
		if (v_u_24 == "done" and not v_u_31 and 2 or 0.15) < v219 - v_u_218 then
			v_u_218 = v219
			local v220 = v_u_208
			local v221
			if v_u_31 then
				v221 = v_u_201()
			else
				v221 = v_u_15.step((v_u_39()))
			end
			v220(v221)
			if v_u_24 ~= "done" and v_u_24 ~= "rebirth" then
				v_u_144.Text = v_u_62(v_u_24)
			end
		end
		if v_u_24 == "done" then
			if not v_u_217 then
				v_u_217 = true
				local v222 = v_u_23.Character
				if v222 then
					v222:FindFirstChild("HumanoidRootPart")
				end
				for _, v223 in v_u_73 do
					v223.Transparency = 1
				end
				for _, v224 in v_u_74 do
					v224.decal.Transparency = 1
				end
				v_u_76.Enabled = false
				local _ = v_u_6.CurrentCamera
				v_u_146.Visible = false
				v_u_187(v_u_24)
				v_u_143.Visible = false
			end
		else
			v_u_217 = false
			local v225 = v_u_70(v_u_24)
			local v226
			if v225 then
				v226 = v225 + v_u_21.origin(v_u_11.number("World", 1))
			else
				v226 = nil
			end
			v_u_138(v226, v_u_24 == "battle")
			v_u_163(v226)
			v_u_187(v_u_24)
			v_u_143.Visible = not v_u_140()
		end
	end)
end
return v_u_22