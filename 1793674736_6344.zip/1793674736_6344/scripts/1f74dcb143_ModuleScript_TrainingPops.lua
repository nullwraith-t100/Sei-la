return {
	["first"] = nil,
	["gap"] = nil,
	["life"] = 4,
	["goldLife"] = 6,
	["grace"] = 1,
	["free"] = nil,
	["goldKey"] = "boost50",
	["goldChance"] = 0.025,
	["goldEvery"] = 240,
	["goldAfter"] = 180,
	["first"] = { 3, 5 },
	["gap"] = { 4, 7 },
	["free"] = {
		{
			["mult"] = 2,
			["weight"] = 70
		},
		{
			["mult"] = 3,
			["weight"] = 22
		},
		{
			["mult"] = 5,
			["weight"] = 7
		},
		{
			["mult"] = 10,
			["weight"] = 1
		}
	}
}