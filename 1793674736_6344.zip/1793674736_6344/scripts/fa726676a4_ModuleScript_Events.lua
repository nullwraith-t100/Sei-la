return {
	["tuneIn"] = "7281619791331328660",
	["afterMinutes"] = nil,
	["afterTutorialMinutes"] = 3,
	["quietSeconds"] = 30,
	["afterMinutes"] = { 5, 9 }
}