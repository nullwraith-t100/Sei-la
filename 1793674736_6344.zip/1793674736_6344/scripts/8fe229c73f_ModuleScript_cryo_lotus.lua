local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.CryoFan, v_u_7.CryoLotus, v_u_7.CryoVine })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FF6FD8")
local v_u_10 = Color3.fromHex("7AF0FF")
local v_u_11 = Color3.fromRGB(226, 248, 255)
local v_u_12 = Color3.fromRGB(196, 236, 255)
local v_u_13 = Color3.fromRGB(255, 200, 74)
local v_u_14 = Color3.fromRGB(58, 16, 64)
local v_u_15 = Enum.PartType.Wedge
local v_u_16 = Color3.fromRGB(150, 215, 255)
local v_u_17 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_27(p18, p19, p20, p21, p22) -- name: picture
	-- upvalues: (copy) v_u_4
	local v23 = v_u_4.part(Vector3.new(p19, 0.05, p19), p18, p21, {
		["transparency"] = 1
	})
	local v24 = {}
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p20
		v26.Color3 = p21
		v26.Transparency = p22
		v26.Parent = v23
		table.insert(v24, v26)
	end
	return v23, v24
end
local function v_u_60(p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v39 = p34 + p35 + p36
	local v40 = math.max(v39, 0.05)
	local v41 = {}
	local v42 = {}
	for v43 = 0, 10 do
		local v44 = v43 / 10
		local v45 = v44 * v40
		local v46 = v45 / math.max(p34, 0.001)
		local v47 = 1 - (1 - math.clamp(v46, 0, 1)) ^ 3
		local v48 = (v45 - p34 - p35) / math.max(p36, 0.001)
		local v49 = math.clamp(v48, 0, 1)
		local v50 = v49 * v49 * (3 - v49 * 2)
		local v51 = NumberSequenceKeypoint.new
		local v52 = p29 + (p30 - p29) * v47
		local v53 = math.max(v52, 0.05) / 2
		table.insert(v42, v51(v44, v53))
		local v54 = NumberSequenceKeypoint.new
		local v55 = p33 + (1 - p33) * v50
		local v56 = math.clamp(v55, 0, 1)
		table.insert(v41, v54(v44, v56))
	end
	local v57 = Instance.new("Attachment")
	v57.WorldCFrame = CFrame.new(p28)
	v57.Parent = v_u_3.Terrain
	local v58 = Instance.new("ParticleEmitter")
	v58.Enabled = false
	v58.Texture = p31
	v58.Color = ColorSequence.new(p32)
	v58.LightEmission = p38 or 0
	v58.LightInfluence = 0
	v58.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v58.EmissionDirection = Enum.NormalId.Top
	v58.SpreadAngle = Vector2.zero
	v58.Speed = NumberRange.new(0.01)
	v58.Size = NumberSequence.new(v42)
	v58.Transparency = NumberSequence.new(v41)
	v58.Lifetime = NumberRange.new(v40)
	local v59 = p37 or math.random(0, 359)
	v58.Rotation = NumberRange.new(v59, v59)
	v58.Parent = v57
	v58:Emit(1)
	v_u_1:AddItem(v57, v40 + 0.2)
end
local function v_u_70(p61, p62, p63, p64, p65, p66, p67) -- name: spritePop
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v68 = Instance.new("Attachment")
	v68.WorldPosition = p61
	v68.Parent = v_u_3.Terrain
	local v69 = Instance.new("ParticleEmitter")
	v69.Enabled = false
	v69.Texture = p62
	v69.Color = ColorSequence.new(p63)
	v69.LightEmission = p67 or 0
	v69.LightInfluence = 0
	v69.Speed = NumberRange.new(0)
	v69.Lifetime = NumberRange.new(p66)
	v69.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p64 / 2), NumberSequenceKeypoint.new(0.3, (p64 + (p65 - p64) * 0.8) / 2), NumberSequenceKeypoint.new(1, p65 / 2) })
	v69.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v69.Rotation = NumberRange.new(0, 360)
	v69.Parent = v68
	v69:Emit(1)
	v_u_1:AddItem(v68, p66 + 0.2)
end
local function v_u_81(p71, p72, p73, p74, p75, p76) -- name: frost
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_11, (copy) v_u_10, (copy) v_u_1
	local v77 = Instance.new("Attachment")
	local v78
	if p72 then
		v78 = CFrame.lookAt(p71, p71 + p72)
	else
		v78 = CFrame.new(p71)
	end
	v77.WorldCFrame = v78
	v77.Parent = v_u_3.Terrain
	local v79 = Instance.new("ParticleEmitter")
	v79.Enabled = false
	v79.Texture = v_u_7.FxSmoke
	v79.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v79.FlipbookMode = Enum.ParticleFlipbookMode.Random
	v79.Color = ColorSequence.new(v_u_11, v_u_10)
	v79.LightEmission = 0.3
	v79.LightInfluence = 0
	v79.Lifetime = NumberRange.new(p76 * 0.6, p76)
	v79.Size = NumberSequence.new(p74 * 0.4, p74)
	v79.Transparency = NumberSequence.new(0.25, 1)
	v79.Speed = NumberRange.new(p75 * 0.5, p75)
	v79.Drag = 2
	v79.EmissionDirection = Enum.NormalId.Front
	local v80
	if p72 then
		v80 = Vector2.new(16, 16)
	else
		v80 = Vector2.new(180, 180)
	end
	v79.SpreadAngle = v80
	v79.Rotation = NumberRange.new(0, 360)
	v79.RotSpeed = NumberRange.new(-40, 40)
	v79.Parent = v77
	v79:Emit(p73)
	v_u_1:AddItem(v77, p76 + 0.2)
end
local function v_u_94(p82, p83, p84) -- name: newLotus
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_13
	local v85 = {}
	for v86 = 1, p83 do
		local v87 = v_u_4.part
		local v88 = Vector3.new(0.4, 1, 0.13) * p82
		local v89 = CFrame.new(0, -500, 0)
		local v90 = v86 / p83 + math.random() * 0.1
		local v91 = v87(v88, v89, Color3.fromHSV(v90 % 1, 0.45, 1), {
			["transparency"] = 0.2
		})
		local v92 = Instance.new("SpecialMesh")
		v92.MeshType = Enum.MeshType.Sphere
		v92.Parent = v91
		v_u_1:AddItem(v91, p84)
		table.insert(v85, v91)
	end
	local v93 = v_u_4.part(Vector3.new(0.36, 0.36, 0.36) * p82, CFrame.new(0, -500, 0), v_u_13, {
		["shape"] = Enum.PartType.Ball
	})
	v_u_1:AddItem(v93, p84)
	return {
		["petals"] = v85,
		["heart"] = v93,
		["size"] = p82,
		["turn"] = math.random() * 3.141592653589793 * 2
	}
end
local function v_u_103(p95, p96, p97, p98) -- name: placeLotus
	local v99 = p97 * 1.05 + 0.12
	for v100, v101 in p95.petals do
		local v102 = p95.turn + v100 / #p95.petals * 3.141592653589793 * 2
		v101.CFrame = p96 * CFrame.Angles(0, v102, 0) * CFrame.Angles(v99, 0, 0) * CFrame.new(0, p95.size * 0.48, 0)
		v101.Transparency = p98 * 0.8 + 0.2
	end
	p95.heart.CFrame = p96 * CFrame.new(0, p95.size * 0.12, 0)
	p95.heart.Transparency = p98
end
return function(p_u_104)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_70, (copy) v_u_7, (copy) v_u_13, (copy) v_u_27, (copy) v_u_1, (copy) v_u_60, (copy) v_u_14, (copy) v_u_81, (copy) v_u_94, (copy) v_u_103, (copy) v_u_6, (copy) v_u_15, (copy) v_u_16, (copy) v_u_11, (copy) v_u_17
	local v105 = {}
	local function v_u_111(p106, p107, p108, p109) -- name: shatter
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (copy) p_u_104, (ref) v_u_10, (ref) v_u_12
		v_u_4.flash(p106, v_u_8, p107 * 2.4, 0.12)
		v_u_4.flash(p106, v_u_9, p107 * 4.4, 0.22)
		p_u_104.glint(p106, v_u_10, p107 * 4, 0.2)
		if not p109 then
			local v110 = {
				v_u_10,
				v_u_12,
				v_u_9,
				v_u_8
			}
			p_u_104.chunks(p106, v110, p108, 20, p107 * 0.35, 0.7, true, 1)
		end
	end
	v105.cryo_lotus_a = {
		["cast"] = function(p112) -- name: cast
			-- upvalues: (ref) v_u_70, (ref) v_u_7, (ref) v_u_13
			v_u_70(p112.eye + p112.dir, v_u_7.CryoFan, v_u_13, 1, 3 * p112.size, 0.18, 0.2)
		end,
		["shot"] = function(p113, p114) -- name: shot
			-- upvalues: (ref) v_u_27, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) v_u_10
			local v115 = p113.size
			local v_u_116, v_u_117 = v_u_27(p114, 3.2 * v115, v_u_7.CryoFan, v_u_9, 0)
			v_u_1:AddItem(v_u_116, 3)
			local v118 = Instance.new("Attachment")
			local v119 = 1.2 * v115
			v118.Position = Vector3.new(v119, 0, 0)
			v118.Parent = v_u_116
			local v120 = Instance.new("Attachment")
			local v121 = -1.2 * v115
			v120.Position = Vector3.new(v121, 0, 0)
			v120.Parent = v_u_116
			local v_u_122 = Instance.new("Trail")
			v_u_122.Attachment0 = v118
			v_u_122.Attachment1 = v120
			v_u_122.Color = ColorSequence.new(v_u_10, v_u_9)
			v_u_122.Transparency = NumberSequence.new(0.3, 1)
			v_u_122.Lifetime = p113.lite and 0.08 or 0.15
			v_u_122.LightEmission = 0.4
			v_u_122.LightInfluence = 0
			v_u_122.FaceCamera = true
			v_u_122.Parent = v_u_116
			local v_u_123 = false
			local v_u_124 = math.random()
			return {
				["place"] = function(p125, p126) -- name: place
					-- upvalues: (copy) v_u_116, (copy) v_u_124, (copy) v_u_117, (copy) v_u_122, (ref) v_u_10
					v_u_116.CFrame = CFrame.new(p125.Position) * CFrame.Angles(0, p126 * 22, 0) * CFrame.Angles(0.25, 0, 0)
					local v127 = v_u_124 + p126 * 2.5
					local v128 = Color3.fromHSV(v127 % 1, 0.45, 1)
					for _, v129 in v_u_117 do
						v129.Color3 = v128
					end
					v_u_122.Color = ColorSequence.new(v128, v_u_10)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_123, (copy) v_u_117, (ref) v_u_1, (copy) v_u_116
					if not v_u_123 then
						v_u_123 = true
						for _, v130 in v_u_117 do
							v130.Transparency = 1
						end
						v_u_1:AddItem(v_u_116, 0.2)
					end
				end
			}
		end,
		["impact"] = function(p131, p132) -- name: impact
			-- upvalues: (copy) v_u_111, (ref) v_u_70, (ref) v_u_7, (ref) v_u_10, (ref) v_u_60, (copy) p_u_104, (ref) v_u_8, (ref) v_u_4, (ref) v_u_14
			local v133 = p131.size
			v_u_111(p132, v133, 4, p131.lite)
			v_u_70(p132, v_u_7.CryoFan, v_u_10, 2 * v133, 6 * v133, 0.25, 0.3)
			if not p131.lite then
				v_u_60(p_u_104.ground(p132, 0.12), 1, 4.5 * v133, v_u_7.CryoLotus, v_u_8, 0, 0.12, 0.4, 0.5, nil, 0.1)
			end
			v_u_4.ring(p_u_104.ground(p132, 0.15), v_u_14, 2.8 * v133, 0.3, v_u_7.Ring)
			p_u_104.hitSound(p132)
		end,
		["hit"] = function(_, p134, _) -- name: hit
			-- upvalues: (copy) p_u_104, (ref) v_u_10
			p_u_104.burst("Impact", p134, v_u_10, 0.6)
		end
	}
	v105.cryo_lotus_e = {
		["cast"] = function(p135) -- name: cast
			-- upvalues: (copy) p_u_104, (ref) v_u_9
			p_u_104.skillCast(p135, v_u_9)
		end,
		["windup"] = function(p136, p137, p138) -- name: windup
			-- upvalues: (copy) p_u_104, (ref) v_u_60, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (ref) v_u_81
			local v139 = p136.size
			local v140 = p136.ability.radius * v139
			local v141 = p_u_104.ground(p137, 0.12)
			local v142 = p138 + (p136.ability.duration or 2)
			v_u_60(v141, v140, v140 * 2.4, v_u_7.Glow, v_u_10, 0.45, 0.3, v142, 0.4, nil, 0.1)
			v_u_60(v141 + Vector3.new(0, 0.04, 0), v140 * 0.5, v140 * 1.8, v_u_7.CryoLotus, v_u_8, 0.05, 0.35, v142, 0.4, nil, 0.1)
			v_u_81(v141 + Vector3.new(0, 1, 0), nil, p136.lite and 4 or 12, 4 * v139, 12 * v139, 0.8)
		end,
		["zone"] = function(p_u_143, p144, p145) -- name: zone
			-- upvalues: (copy) p_u_104, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_94, (ref) v_u_81, (ref) v_u_10, (ref) v_u_9, (ref) v_u_60, (ref) v_u_103, (copy) v_u_111, (ref) v_u_6
			local v_u_146 = p_u_143.size
			local v147 = p_u_143.ability.radius * v_u_146
			local v_u_148 = p_u_104.ground(p144, 0)
			local v_u_149 = p_u_143.ability.tick or 0.4
			local v_u_150 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_148), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_150, p145 + 1.5)
			local v151 = p_u_143.lite and 3 or 6
			local v152 = math.random() * 3.141592653589793 * 2
			local v_u_153 = {}
			for v154 = 1, v151 do
				local v155 = v152 + v154 / v151 * 3.141592653589793 * 2
				local v156 = math.cos(v155)
				local v157 = math.sin(v155)
				local v158 = v_u_148 + Vector3.new(v156, 0, v157) * v147 * 0.78
				local v159 = Instance.new("Attachment")
				v159.Parent = v_u_150
				local v160 = Instance.new("Attachment")
				v160.Parent = v_u_150
				local v161 = Instance.new("Beam")
				v161.Attachment0 = v159
				v161.Attachment1 = v160
				v161.Texture = v_u_7.CryoVine
				v161.TextureMode = Enum.TextureMode.Wrap
				v161.TextureLength = 2.6 * v_u_146
				v161.TextureSpeed = 0
				v161.Color = ColorSequence.new(v_u_8)
				v161.LightEmission = 0.15
				v161.LightInfluence = 0
				v161.FaceCamera = true
				v161.Segments = 12
				v161.Width0 = 1.9 * v_u_146
				v161.Width1 = 0.95 * v_u_146
				v161.Parent = v159
				local v162
				if p_u_143.lite then
					v162 = nil
				else
					v162 = v_u_94(2.4 * v_u_146, 6, p145 + 1.5)
				end
				local v163 = {
					["a0"] = nil,
					["a1"] = nil,
					["b"] = nil,
					["root"] = nil,
					["bud"] = nil,
					["phase"] = nil,
					["whip"] = -10,
					["struck"] = true,
					["a0"] = v159,
					["a1"] = v160,
					["b"] = v161,
					["root"] = v158,
					["bud"] = v162,
					["phase"] = v154 * 1.7
				}
				table.insert(v_u_153, v163)
				v_u_81(v158 + Vector3.new(0, 1, 0), Vector3.new(0, 1, 0), 4, 2.5 * v_u_146, 8 * v_u_146, 0.6)
			end
			local v_u_164 = os.clock()
			local v_u_165 = true
			local v_u_166 = 0
			p_u_104.frame(function()
				-- upvalues: (ref) v_u_165, (copy) v_u_150, (copy) v_u_164, (copy) v_u_149, (ref) v_u_166, (copy) v_u_153, (copy) v_u_148, (copy) v_u_146, (ref) v_u_4, (ref) p_u_104, (ref) v_u_10, (ref) v_u_7, (ref) v_u_9, (copy) p_u_143, (ref) v_u_60, (ref) v_u_8, (ref) v_u_103
				if not (v_u_165 and v_u_150.Parent) then
					return false
				end
				local v167 = os.clock() - v_u_164
				local v168 = v167 / 0.3
				local v169 = 1 - (1 - math.clamp(v168, 0, 1)) ^ 3
				local v170 = v167 / v_u_149
				local v171 = math.floor(v170)
				if v_u_166 < v171 then
					v_u_166 = v171
					local v172 = v_u_153[(v171 * 2 + 0) % #v_u_153 + 1]
					v172.whip = v167
					v172.struck = false
					local v173 = v_u_153[(v171 * 2 + 1) % #v_u_153 + 1]
					v173.whip = v167
					v173.struck = false
				end
				for _, v174 in v_u_153 do
					local v175 = (v_u_148 - v174.root) * Vector3.new(1, 0, 1)
					local v176 = v175.Magnitude <= 0.1 and Vector3.new(0, 0, 0) or v175.Unit
					local v177 = v167 * 2.2 + v174.phase
					local v178 = math.sin(v177)
					local v179 = v167 * 1.8 + v174.phase
					local v180 = math.cos(v179)
					local v181 = Vector3.new(v178, 0, v180) * 1.2 * v_u_146
					local v182 = v174.root + Vector3.new(0, 1, 0) * (7.5 * v_u_146 * v169) + v176 * 1.5 * v_u_146 + v181
					local v183 = v167 - v174.whip
					if v183 >= 0 and v183 < 0.35 then
						local v184
						if v183 < 0.12 then
							local v185 = v183 / 0.12
							local v186 = math.clamp(v185, 0, 1)
							v184 = v186 * v186 * (3 - v186 * 2)
						else
							local v187 = (v183 - 0.12) / 0.23
							local v188 = math.clamp(v187, 0, 1)
							v184 = 1 - v188 * v188 * (3 - v188 * 2)
						end
						local v189 = v174.root:Lerp(v_u_148, 0.75) + Vector3.new(0, 0.8, 0)
						v182 = v182:Lerp(v189, v184)
						if v183 >= 0.12 and not v174.struck then
							v174.struck = true
							v_u_4.ring(p_u_104.ground(v189, 0.15), v_u_10, 4 * v_u_146, 0.3, v_u_7.Ring)
							v_u_4.flash(v189, v_u_9, 3 * v_u_146, 0.14)
							if not p_u_143.lite then
								v_u_60(p_u_104.ground(v189, 0.1), 1, 4 * v_u_146, v_u_7.CryoLotus, v_u_8, 0, 0.08, 0.2, 0.35, nil, 0.1)
							end
						end
					end
					local v190 = v182 - v174.root
					v174.a0.WorldCFrame = CFrame.fromMatrix(v174.root, Vector3.new(0, 1, 0), v176:Cross(Vector3.new(0, 1, 0)) + Vector3.new(0, 0, 0.001))
					v174.a1.WorldCFrame = CFrame.lookAt(v182, v182 + v190.Unit) * CFrame.Angles(0, 1.5707963267948966, 0)
					v174.b.CurveSize0 = 3 * v_u_146 * v169
					v174.b.CurveSize1 = 0
					local v191 = v174.bud
					if not v191 then
						continue
					end
					local v192 = v_u_103
					local v193 = CFrame.lookAt(v182, v182 + v190) * CFrame.Angles(-1.5707963267948966, 0, 0)
					local v194 = v167 * 5 + v174.phase
					v192(v191, v193, math.sin(v194) * 0.1 + 0.1, 1 - v169)
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_165, (copy) v_u_153, (ref) p_u_104, (ref) v_u_103, (ref) v_u_111, (copy) v_u_146, (copy) p_u_143, (copy) v_u_150, (ref) v_u_81, (copy) v_u_148, (ref) v_u_6
				v_u_165 = false
				for _, v_u_195 in v_u_153 do
					local v_u_196 = v_u_195.bud
					local v197 = v_u_195.a1.WorldPosition
					if v_u_196 then
						local v_u_198 = v_u_196.heart.CFrame
						p_u_104.animate(0.18, 0, function(p199)
							-- upvalues: (ref) v_u_103, (copy) v_u_196, (copy) v_u_198
							v_u_103(v_u_196, v_u_198, 0.2 + 0.8 * p199, p199 * p199)
							if p199 >= 1 then
								local v200 = v_u_196
								for _, v201 in v200.petals do
									v201:Destroy()
								end
								v200.heart:Destroy()
							end
						end)
					end
					v_u_111(v197, v_u_146, 3, p_u_143.lite)
					local v_u_202 = v_u_195.b.Width0
					local v_u_203 = v_u_195.b.Width1
					p_u_104.animate(0.25, 0, function(p204)
						-- upvalues: (copy) v_u_195, (copy) v_u_202, (copy) v_u_203
						v_u_195.b.Width0 = v_u_202 * (1 - p204)
						v_u_195.b.Width1 = v_u_203 * (1 - p204)
					end)
				end
				p_u_104.after(0.3, function()
					-- upvalues: (ref) v_u_150
					v_u_150:Destroy()
				end)
				v_u_81(v_u_148 + Vector3.new(0, 1, 0), nil, p_u_143.lite and 4 or 10, 5 * v_u_146, 16 * v_u_146, 0.7)
				v_u_6.play("Crit", {
					["at"] = v_u_148,
					["volume"] = p_u_143.mine and 0.6 or 0.35
				})
			end
		end,
		["hit"] = function(p205, p206, _) -- name: hit
			-- upvalues: (copy) p_u_104, (ref) v_u_10, (ref) v_u_9
			p_u_104.burst("Impact", p206, v_u_10, 0.6)
			if not p205.lite then
				p_u_104.glint(p206, v_u_9, 3 * p205.size, 0.15)
			end
		end
	}
	v105.cryo_lotus_r = {
		["cast"] = function(p207) -- name: cast
			-- upvalues: (copy) p_u_104, (ref) v_u_9
			p_u_104.skillCast(p207, v_u_9, true)
		end,
		["windup"] = function(p208, p209, p210) -- name: windup
			-- upvalues: (copy) p_u_104, (ref) v_u_60, (ref) v_u_7, (ref) v_u_10, (ref) v_u_4
			local v211 = p208.size
			local v212 = p208.ability.radius * v211
			v_u_60(p_u_104.ground(p209, 0.12), v212 * 0.5, v212 * 2.3, v_u_7.Glow, v_u_10, 0.4, math.max(p210, 0.1), 1.6, 0.5, nil, 0.1)
			if p208.mine then
				v_u_4.shake(0.2, 0.4)
			end
		end,
		["land"] = function(p_u_213, p214) -- name: land
			-- upvalues: (copy) p_u_104, (ref) v_u_4, (ref) v_u_15, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_16, (ref) v_u_12, (ref) v_u_11, (ref) v_u_13, (ref) v_u_27, (ref) v_u_7, (ref) v_u_8, (ref) v_u_17, (ref) v_u_81, (ref) v_u_60, (ref) v_u_14, (ref) v_u_6, (copy) v_u_111, (ref) v_u_70
			local v_u_215 = p_u_213.size
			local v_u_216 = p_u_213.lite
			local v_u_217 = p_u_213.ability.radius * v_u_215
			local v_u_218 = p_u_104.ground(p214, 0)
			local v219 = p_u_104.flatUnit(p214 - p_u_213.origin)
			local v_u_220 = v_u_218 + v219 * v_u_217 * 0.75
			local v_u_221 = CFrame.lookAt(v_u_220, v_u_220 - v219)
			local v_u_222 = {}
			local function v238(p223, p224, p225, p226, p227, p228) -- name: add
				-- upvalues: (ref) v_u_4, (copy) v_u_215, (ref) v_u_15, (ref) v_u_1, (copy) v_u_222
				local v229 = v_u_4.part
				local v230 = p223 * v_u_215
				local v231 = CFrame.new(0, -500, 0)
				local v232 = {
					["transparency"] = p226 and 0.05 or 0.22
				}
				local v233
				if p228 then
					v233 = v_u_15
				else
					v233 = nil
				end
				v232.shape = v233
				local v234 = v229(v230, v231, p225, v232)
				if p227 then
					local v235 = Instance.new("SpecialMesh")
					v235.MeshType = Enum.MeshType.Sphere
					v235.Parent = v234
				end
				v_u_1:AddItem(v234, 2.9)
				local v236 = v_u_222
				local v237 = {
					["p"] = v234,
					["off"] = CFrame.new(p224.Position * v_u_215) * p224.Rotation
				}
				table.insert(v236, v237)
				return v234
			end
			local v239 = v_u_216 and 4 or 8
			for v240 = 1, v239 do
				local v241 = v240 / v239 * 3.141592653589793 * 2
				local v242 = Vector3.new(3, 5.5, 1)
				local v243 = CFrame.Angles(0, v241, 0) * CFrame.new(0, 1.4, -4.2) * CFrame.Angles(-0.9, 0, 0)
				local v244
				if v240 % 2 == 0 then
					v244 = v_u_9
				else
					v244 = v_u_10
				end
				v238(v242, v243, v244, true, true)
			end
			v238(Vector3.new(9, 8, 7), CFrame.new(0, 6, 0), v_u_16, false, true)
			if not v_u_216 then
				v238(Vector3.new(11, 4.2, 6), CFrame.new(0, 10, 0), v_u_12, false, true)
				for _, v245 in { -1, 1 } do
					v238(Vector3.new(3.2, 7.5, 3.6), CFrame.new(v245 * 5.2, 7.6, -0.4) * CFrame.Angles(0, 0, v245 * 0.18), v_u_11, false, true)
				end
			end
			v238(Vector3.new(4.6, 5.4, 4.6), CFrame.new(0, 14.4, 0), v_u_11, false, true)
			local v_u_246 = v238(Vector3.new(1.2, 0.6, 0.6), CFrame.new(0, 13.3, -2.2), v_u_9, true, true)
			if not v_u_216 then
				for v247 = 1, 5 do
					local v248 = (v247 - 3) * 0.42
					v238(Vector3.new(0.5, 1.6, 0.9), CFrame.Angles(0, v248, 0) * CFrame.new(0, 17.4, -1.7) * CFrame.Angles(0.3, 0, 0), v_u_13, true, false, true)
				end
			end
			local v_u_249 = v_u_27(CFrame.new(0, -500, 0), 14 * v_u_215, v_u_7.CryoLotus, v_u_8, 0)
			v_u_1:AddItem(v_u_249, 2.9)
			local v_u_250 = CFrame.new(0, 14.4 * v_u_215, 3.4 * v_u_215) * v_u_17
			local v_u_251 = {}
			for _ = 1, v_u_216 and 4 or 10 do
				local v252 = math.random() * 3.141592653589793 * 2
				local v253 = v_u_217 * 0.85
				local v254 = math.random()
				local v255 = v253 * math.sqrt(v254)
				local v256 = (3 + math.random() * 3.5) * v_u_215
				local v257 = v_u_4.part
				local v258 = 0.9 * v_u_215
				local v259 = 0.9 * v_u_215
				local v260 = v257(Vector3.new(v258, v256, v259), CFrame.new(0, -500, 0), v_u_10, {
					["transparency"] = 0.12
				})
				v_u_1:AddItem(v260, 2.9)
				local v261 = {
					["p"] = v260
				}
				local v262 = math.cos(v252) * v255
				local v263 = math.sin(v252) * v255
				v261.at = v_u_218 + Vector3.new(v262, 0, v263)
				v261.tilt = CFrame.Angles((math.random() - 0.5) * 0.6, math.random() * 6.28, (math.random() - 0.5) * 0.6)
				v261.h = v256
				table.insert(v_u_251, v261)
			end
			local v_u_264 = os.clock()
			local v_u_265 = false
			local v_u_266 = false
			local v_u_267 = false
			v_u_81(v_u_220 + Vector3.new(0, 2, 0), Vector3.new(0, 1, 0), v_u_216 and 5 or 14, 6 * v_u_215, 20 * v_u_215, 0.8)
			p_u_104.chunks(v_u_220 + Vector3.new(0, 1, 0), { v_u_10, v_u_12, v_u_8 }, v_u_216 and 3 or 8, 24, 0.6 * v_u_215, 0.9, false, 1.3)
			p_u_104.frame(function()
				-- upvalues: (copy) v_u_264, (copy) v_u_221, (copy) v_u_215, (ref) v_u_267, (copy) v_u_222, (copy) v_u_249, (copy) v_u_250, (ref) v_u_265, (copy) v_u_246, (copy) v_u_218, (ref) v_u_81, (copy) v_u_216, (ref) p_u_104, (ref) v_u_4, (ref) v_u_10, (ref) v_u_266, (ref) v_u_60, (copy) v_u_217, (ref) v_u_7, (ref) v_u_8, (ref) v_u_14, (ref) v_u_6, (copy) p_u_213, (copy) v_u_251, (copy) v_u_220, (ref) v_u_111, (ref) v_u_70
				local v268 = os.clock() - v_u_264
				local v269 = v268 / 0.5
				local v270 = 1 - (1 - math.clamp(v269, 0, 1)) ^ 3
				local v271 = v_u_221 * CFrame.new(0, -22 * v_u_215 * (1 - v270), 0)
				if not v_u_267 then
					for _, v272 in v_u_222 do
						v272.p.CFrame = v271 * v272.off
					end
					v_u_249.CFrame = v271 * v_u_250
				end
				if v268 >= 0.55 and not v_u_265 then
					v_u_265 = true
					local v_u_273 = v_u_246.Position
					local v_u_274 = v_u_218 + Vector3.new(0, 1.5, 0)
					v_u_81(v_u_273, v_u_274 - v_u_273, v_u_216 and 10 or 30, 9 * v_u_215, (v_u_274 - v_u_273).Magnitude * 1.6, 0.7)
					if not v_u_216 then
						p_u_104.after(0.12, function()
							-- upvalues: (ref) v_u_81, (copy) v_u_273, (copy) v_u_274, (ref) v_u_215
							v_u_81(v_u_273, v_u_274 - v_u_273, 20, 8 * v_u_215, (v_u_274 - v_u_273).Magnitude * 1.5, 0.7)
						end)
					end
					v_u_4.flash(v_u_273, v_u_10, 6 * v_u_215, 0.3)
				end
				if v268 >= 0.85 and not v_u_266 then
					v_u_266 = true
					v_u_60(v_u_218 + Vector3.new(0, 0.1, 0), v_u_217 * 0.4, v_u_217 * 2.1, v_u_7.CryoLotus, v_u_8, 0, 0.2, 0.9, 0.4, nil, 0.1)
					v_u_4.ring(v_u_218 + Vector3.new(0, 0.2, 0), v_u_14, v_u_217 * 0.9, 0.45, v_u_7.Ring)
					v_u_4.ring(v_u_218 + Vector3.new(0, 0.25, 0), v_u_10, v_u_217 * 1.2, 0.55, v_u_7.Ring)
					v_u_6.play("Crit", {
						["at"] = v_u_218,
						["volume"] = p_u_213.mine and 0.7 or 0.4
					})
				end
				if v_u_266 then
					local v275 = (v268 - 0.85) / 0.15
					local v276 = 1 - (1 - math.clamp(v275, 0, 1)) ^ 3
					for _, v277 in v_u_251 do
						v277.p.CFrame = CFrame.new(v277.at) * v277.tilt * CFrame.new(0, v277.h * (v276 - 0.5), 0)
					end
				end
				if v268 >= 1.75 and not v_u_267 then
					v_u_267 = true
					for _, v278 in v_u_222 do
						local v279 = v278.p
						local v280 = v279.Position - (v_u_220 + Vector3.new(0, 9, 0) * v_u_215)
						local v281 = v280.Magnitude <= 0.1 and Vector3.new(0, 1, 0) or v280.Unit
						v_u_4.tween(v279, 0.45, {
							["CFrame"] = nil,
							["Size"] = nil,
							["Transparency"] = 1,
							["CFrame"] = v279.CFrame + v281 * 6 * v_u_215 + Vector3.new(0, 2, 0) * v_u_215,
							["Size"] = v279.Size * 0.6
						})
					end
					for _, v282 in v_u_251 do
						v_u_4.tween(v282.p, 0.35, {
							["Transparency"] = 1
						})
					end
					v_u_249:Destroy()
					local v283 = v_u_220 + Vector3.new(0, 10, 0) * v_u_215
					v_u_111(v283, v_u_215 * 2.5, v_u_216 and 4 or 14, v_u_216)
					v_u_70(v283, v_u_7.CryoLotus, v_u_8, 6 * v_u_215, 20 * v_u_215, 0.45, 0.15)
					v_u_81(v283, nil, v_u_216 and 6 or 16, 7 * v_u_215, 18 * v_u_215, 0.8)
					v_u_6.play("Explosion", {
						["at"] = v283,
						["volume"] = p_u_213.mine and 0.9 or 0.5
					})
					if p_u_213.mine then
						v_u_4.shake(0.4, 0.3)
					end
				end
				if v268 < 2.4 then
					return true
				end
				for _, v284 in v_u_222 do
					v284.p:Destroy()
				end
				for _, v285 in v_u_251 do
					v285.p:Destroy()
				end
				return false
			end)
		end,
		["hit"] = function(p286, p287, _) -- name: hit
			-- upvalues: (copy) p_u_104, (ref) v_u_10, (ref) v_u_9
			p_u_104.burst("Impact", p287, v_u_10, 0.8)
			if not p286.lite then
				p_u_104.glint(p287, v_u_9, 3 * p286.size, 0.15)
			end
		end
	}
	return v105
end