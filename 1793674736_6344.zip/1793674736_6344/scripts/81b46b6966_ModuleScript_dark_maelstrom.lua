local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("8A2A1A")
local v_u_8 = Color3.fromRGB(214, 36, 40)
local v_u_9 = Color3.fromRGB(70, 6, 10)
local v_u_10 = Color3.fromRGB(12, 4, 4)
local v_u_11 = Color3.fromRGB(255, 150, 130)
local v_u_12 = Color3.fromRGB(200, 228, 245)
local v_u_13 = Enum.PartType.Ball
local v_u_14 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_28(p15, p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.part
	local v22 = p16 * 2
	local v23 = p16 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p15, p18, {
		["transparency"] = 1
	})
	local v25
	if p20 then
		v25 = { Enum.NormalId.Top }
	else
		v25 = { Enum.NormalId.Top, Enum.NormalId.Bottom }
	end
	for _, v26 in v25 do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p17
		v27.Color3 = p18
		v27.Transparency = p19
		v27.Parent = v24
	end
	return v24
end
local function v_u_32(p29, p30) -- name: setAlpha
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_39(p33, p34, p35, p36) -- name: newIris
	-- upvalues: (copy) v_u_28, (copy) v_u_6, (copy) v_u_1
	local v37 = {}
	for _ = 1, p33 do
		local v38 = v_u_28(CFrame.identity, p34 * 1.35 / 2, v_u_6.MaelstromBlade, p35, 0, true)
		v_u_1:AddItem(v38, p36)
		table.insert(v37, v38)
	end
	return {
		["blades"] = v37,
		["radius"] = p34
	}
end
local function v_u_51(p40, p41, p42, p43, p44, p45) -- name: bladeFrame
	-- upvalues: (copy) v_u_14
	local v46 = #p40.blades
	local v47 = p40.radius * p45 * 0.95
	local v48 = p40.radius * 1.35 * p45
	local v49 = p43 + (p41 - 1) / v46 * 3.141592653589793 * 2
	local v50 = v49 + 1.5707963267948966 + 1.9477874452256718 * p44
	return p42 * CFrame.new(math.cos(v49) * v47, p41 * 0.012, math.sin(v49) * v47) * CFrame.Angles(0, -v50, 0) * CFrame.new(Vector3.new(0.42, -0, -0.06) * v48) * v_u_14
end
local function v_u_61(p52, p53, p54, p55, p56) -- name: placeIris
	-- upvalues: (copy) v_u_51
	local v57 = math.max(p56, 0.02)
	local v58 = p52.radius * 1.35 * v57
	for v59, v60 in p52.blades do
		if not v60.Parent then
			continue
		end
		v60.Size = Vector3.new(v58, 0.05, v58)
		v60.CFrame = v_u_51(p52, v59, p53, p54, p55, v57)
	end
end
return function(p_u_62)
	-- upvalues: (copy) v_u_1, (copy) v_u_32, (copy) v_u_28, (copy) v_u_4, (copy) v_u_8, (copy) v_u_10, (copy) v_u_13, (copy) v_u_6, (copy) v_u_11, (copy) v_u_7, (copy) v_u_9, (copy) v_u_3, (copy) v_u_39, (copy) v_u_61, (copy) v_u_5, (copy) v_u_12
	local function v_u_79(p_u_63, p64, p_u_65, p66, p_u_67) -- name: fling
		-- upvalues: (ref) v_u_1, (copy) p_u_62, (ref) v_u_32
		local v_u_68 = {}
		local v_u_69 = {}
		for _, v70 in p_u_63.blades do
			local v71 = v70.CFrame
			table.insert(v_u_68, v71)
			local v72 = v70.Position - p64.Position
			local v73
			if v72.Magnitude > 0.001 then
				v73 = v72.Unit
			else
				v73 = p64.RightVector
			end
			table.insert(v_u_69, v73)
			v_u_1:AddItem(v70, p66 + 0.1)
		end
		p_u_62.animate(p66, 0, function(p74)
			-- upvalues: (copy) p_u_63, (copy) v_u_68, (copy) v_u_69, (copy) p_u_65, (copy) p_u_67, (ref) v_u_32
			local v75 = 1 - (1 - p74) ^ 2
			for v76, v77 in p_u_63.blades do
				if not v77.Parent then
					continue
				end
				v77.CFrame = (v_u_68[v76] + v_u_69[v76] * p_u_65 * v75 - Vector3.new(0, 1, 0) * p_u_67 * p74 * p74) * CFrame.Angles(0, p74 * 7, 0)
				v_u_32(v77, p74 ^ 1.6)
			end
			if p74 >= 1 then
				for _, v78 in p_u_63.blades do
					v78:Destroy()
				end
			end
		end)
	end
	local function v_u_96(p_u_80, p_u_81, p_u_82, p83, p84, p_u_85, p_u_86, p87) -- name: flare
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_62, (ref) v_u_32
		local v_u_88 = p87 or 0
		local v_u_89 = v_u_28(p_u_80, p_u_81, p83, p84, v_u_88, true)
		v_u_1:AddItem(v_u_89, p_u_85 + 0.1)
		p_u_62.animate(p_u_85, 0, function(p90)
			-- upvalues: (copy) v_u_89, (copy) p_u_81, (copy) p_u_82, (copy) p_u_80, (copy) p_u_85, (copy) p_u_86, (ref) v_u_32, (copy) v_u_88
			local v91 = 1 - (1 - p90) ^ 3
			local v92 = v_u_89
			local v93 = p_u_81 + (p_u_82 - p_u_81) * v91
			local v94 = v93 * 2
			local v95 = v93 * 2
			v92.Size = Vector3.new(v94, 0.05, v95)
			v_u_89.CFrame = p_u_80 * CFrame.Angles(0, p90 * p_u_85 * p_u_86, 0)
			v_u_32(v_u_89, v_u_88 + (1 - v_u_88) * p90 ^ 1.5)
			if p90 >= 1 then
				v_u_89:Destroy()
			end
		end)
	end
	local function v127(p97, p98) -- name: undertowShot
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_13, (ref) v_u_28, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (copy) p_u_62, (ref) v_u_9, (ref) v_u_1, (ref) v_u_3
		local v_u_99 = p97.size
		local v_u_100 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p98, v_u_8, {
			["transparency"] = 1
		})
		local v_u_101 = v_u_4.part(Vector3.new(0.95, 0.95, 0.95) * v_u_99, p98, v_u_10, {
			["shape"] = v_u_13,
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_101.Reflectance = 0.15
		local v102 = {
			["shape"] = nil,
			["transparency"] = 0.55,
			["shape"] = v_u_13
		}
		local v_u_103 = v_u_4.part(Vector3.new(1.75, 1.75, 1.75) * v_u_99, p98, v_u_8, v102)
		local v_u_104 = v_u_28(p98, 1.5 * v_u_99, v_u_6.MaelstromVortex, v_u_8, 0, true)
		local v_u_105 = { v_u_101, v_u_103, v_u_104 }
		local v_u_106 = {}
		local v_u_107
		if p97.lite then
			v_u_107 = nil
		else
			v_u_107 = v_u_28(p98, 0.9 * v_u_99, v_u_6.MaelstromVortex, v_u_11, 0.25, true)
			table.insert(v_u_105, v_u_107)
			for _ = 1, 3 do
				local v108 = {
					["shape"] = v_u_13
				}
				local v109 = v_u_4.part(Vector3.new(0.32, 0.32, 0.32) * v_u_99, p98, v_u_7, v108)
				table.insert(v_u_105, v109)
				table.insert(v_u_106, v109)
			end
			p_u_62.streak(v_u_100, v_u_11, v_u_8, 0.35 * v_u_99, 0.08)
		end
		p_u_62.streak(v_u_100, v_u_8, v_u_9, 1.3 * v_u_99, 0.18)
		if p97.mine then
			p_u_62.light(v_u_100, v_u_8, 8 * v_u_99)
		end
		for _, v110 in v_u_105 do
			v_u_1:AddItem(v110, 3)
		end
		v_u_1:AddItem(v_u_100, 3)
		local v_u_111 = false
		return {
			["place"] = function(p112, p113) -- name: place
				-- upvalues: (copy) v_u_100, (copy) v_u_101, (copy) v_u_103, (ref) v_u_3, (ref) p_u_62, (copy) v_u_99, (copy) v_u_104, (ref) v_u_107, (copy) v_u_106
				local v114 = p112.Position
				v_u_100.CFrame = p112
				v_u_101.CFrame = p112
				v_u_103.CFrame = p112
				local v115 = v_u_3.CurrentCamera
				local v116
				if v115 then
					local v117 = v115.CFrame.Position - v114
					v116 = v117.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v117.Unit
				else
					v116 = Vector3.new(0, 0, 1)
				end
				local v118 = p_u_62.facing(v114 + v116 * 0.95 * v_u_99, v116)
				v_u_104.CFrame = v118 * CFrame.Angles(0, p113 * 22, 0)
				local v119 = v_u_107
				if v119 then
					v119.CFrame = v118 * CFrame.new(0, 0.05, 0) * CFrame.Angles(0, p113 * 38, 0)
				end
				for v120, v121 in v_u_106 do
					local v122 = (p113 * 2.6 + v120 / 3) % 1
					local v123 = 1.8 * v_u_99 * (1 - v122)
					local v124 = p113 * 14 + v120 * 2.1 + v122 * 4
					v121.CFrame = v118 * CFrame.new(math.cos(v124) * v123, 0.1, math.sin(v124) * v123)
					v121.Size = Vector3.new(0.34, 0.34, 0.34) * v_u_99 * (1 - v122 * 0.6)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_111, (copy) v_u_100, (ref) v_u_1, (copy) v_u_105
				if not v_u_111 then
					v_u_111 = true
					local v125 = v_u_100:FindFirstChildWhichIsA("PointLight")
					if v125 then
						v125:Destroy()
					end
					v_u_1:AddItem(v_u_100, 0.2)
					for _, v126 in v_u_105 do
						v126:Destroy()
					end
				end
			end
		}
	end
	local function v143(p_u_128, p_u_129) -- name: undertowImpact
		-- upvalues: (ref) v_u_3, (copy) p_u_62, (ref) v_u_28, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_32, (ref) v_u_10, (ref) v_u_4
		local v_u_130 = p_u_128.size
		local v131 = v_u_3.CurrentCamera
		local v132
		if v131 then
			local v133 = v131.CFrame.Position - p_u_129
			v132 = v133.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v133.Unit
		else
			v132 = Vector3.new(0, 0, 1)
		end
		local v_u_134 = p_u_62.facing(p_u_129 + v132 * 0.6, v132)
		local v_u_135 = v_u_28(v_u_134, 1.5 * v_u_130, v_u_6.MaelstromVortex, v_u_8, 0, true)
		v_u_1:AddItem(v_u_135, 0.5)
		p_u_62.animate(0.36, 0, function(p136)
			-- upvalues: (copy) v_u_135, (copy) v_u_130, (copy) v_u_134, (ref) v_u_32
			local v137
			if p136 < 0.35 then
				local v138 = p136 / 0.35
				v137 = math.sqrt(v138) * 3.4 + 1.5
			else
				v137 = 4.9 * (1 - (p136 - 0.35) / 0.65) ^ 1.5 + 0.05
			end
			local v139 = v_u_135
			local v140 = v137 * v_u_130
			local v141 = v140 * 2
			local v142 = v140 * 2
			v139.Size = Vector3.new(v141, 0.05, v142)
			v_u_135.CFrame = v_u_134 * CFrame.Angles(0, p136 * 16, 0)
			v_u_32(v_u_135, p136 < 0.6 and 0 or (p136 - 0.6) / 0.4)
			if p136 >= 1 then
				v_u_135:Destroy()
			end
		end)
		p_u_62.inward(p_u_129, v_u_8, p_u_128.lite and 3 or 6, 6 * v_u_130, 0.24)
		p_u_62.burst("Impact", p_u_129, v_u_8, 0.8 * v_u_130)
		p_u_62.after(0.22, function()
			-- upvalues: (ref) p_u_62, (copy) p_u_129, (ref) v_u_10, (copy) v_u_130, (ref) v_u_4, (ref) v_u_8, (copy) p_u_128, (ref) v_u_6
			p_u_62.pop(p_u_129, v_u_10, 2.6 * v_u_130, 0.2, 0.12, 0.1, Enum.Material.SmoothPlastic)
			v_u_4.ring(p_u_62.ground(p_u_129), v_u_8, p_u_128.ability.radius * 0.5 * v_u_130, 0.25, v_u_6.Ring)
			if not p_u_128.lite then
				p_u_62.pop(p_u_129, v_u_8, 0.6 * v_u_130, 3 * v_u_130, 0.14, 0.4)
			end
		end)
		p_u_62.hitSound(p_u_129)
	end
	local v_u_144 = {}
	local v_u_145 = {}
	setmetatable(v_u_145, {
		["__mode"] = "k"
	})
	local function v_u_188(p_u_146, p147) -- name: openTunnel
		-- upvalues: (ref) v_u_39, (ref) v_u_8, (ref) v_u_28, (ref) v_u_6, (ref) v_u_1, (copy) p_u_62, (copy) v_u_144, (copy) v_u_79, (ref) v_u_61
		local v148 = p_u_146.lite
		local v149 = p_u_146.ability.range
		local v_u_150 = {
			["gates"] = nil,
			["born"] = nil,
			["cutAt"] = nil,
			["flung"] = false,
			["done"] = false,
			["gates"] = {},
			["born"] = p147
		}
		for v151, v152 in v148 and { 12, 32, 55 } or {
			10,
			21,
			33,
			46,
			60
		} do
			if v149 < v152 then
				break
			end
			local v153 = (v151 * (v148 and 0.8 or 0.5) + 4) * p_u_146.size
			local v154 = v_u_39(v148 and 5 or 6, v153, v_u_8, 2.5)
			local v155 = v_u_28(CFrame.identity, v153, v_u_6.Ring, v_u_8, 0.15, true)
			v_u_1:AddItem(v155, 2.5)
			local v156 = v_u_150.gates
			local v157 = {
				["iris"] = v154,
				["ring"] = v155,
				["d"] = v152,
				["radius"] = v153
			}
			local v158 = p_u_146.eye
			local v159 = p_u_146.dir
			local v160 = v158 + v159 * v152
			local v161 = v158.Y - v152 * 1.2 / math.max(v149, 1)
			local v162 = p_u_62.FLOOR + v153 * 0.8
			local v163 = math.max(v161, v162)
			local v164 = p_u_62.facing
			local v165 = v160.X
			local v166 = v160.Z
			v157.cf = v164(Vector3.new(v165, v163, v166), -v159)
			v157.spin = math.random() * 3.141592653589793 * 2
			table.insert(v156, v157)
		end
		local v_u_167 = os.clock()
		p_u_62.runNow(function()
			-- upvalues: (ref) v_u_167, (copy) v_u_150, (copy) p_u_146, (ref) v_u_144, (ref) v_u_79, (ref) v_u_61
			local v168 = os.clock()
			local v169 = v168 - v_u_167
			local v170 = math.min(v169, 0.05)
			v_u_167 = v168
			local v171 = v168 - v_u_150.born
			local v172 = v_u_150.cutAt
			if v172 or v171 <= 1.1 then
				if v_u_150.flung then
					return false
				end
				for v173, v174 in v_u_150.gates do
					v174.spin = v174.spin + v170 * (v172 and 0.5 or 2.4)
					local v175 = (v171 - (v173 - 1) * 0.025) / 0.12
					local v176 = math.clamp(v175, 0, 1) - 1
					local v177 = v176 * 2.7 * v176 * v176 + 1 + v176 * 1.7 * v176
					local v178 = v171 * 9 + v173
					local v179 = math.sin(v178) * 0.03 + 0.06
					if v172 then
						local v180 = (v168 - v172 - (v173 - 1) * 0.028) / 0.05
						local v181 = math.clamp(v180, 0, 1)
						v179 = v179 + (1.02 - v179) * v181 * v181
					end
					v_u_61(v174.iris, v174.cf, v174.spin, v179, v177)
					local v182 = v174.ring
					local v183 = v174.radius * 1.08 * math.max(v177, 0.02)
					local v184 = v183 * 2
					local v185 = v183 * 2
					v182.Size = Vector3.new(v184, 0.05, v185)
					v174.ring.CFrame = v174.cf * CFrame.new(0, 0.11, 0) * CFrame.Angles(0, -v174.spin * 0.5, 0)
				end
				return true
			end
			v_u_150.done = true
			local v186 = p_u_146.caster
			if v186 and v_u_144[v186] == v_u_150 then
				v_u_144[v186] = nil
			end
			for _, v187 in v_u_150.gates do
				v_u_79(v187.iris, v187.cf, 2, 0.3, 0)
				v187.ring:Destroy()
			end
			return false
		end)
		return v_u_150
	end
	local function v219(p189, p_u_190, p_u_191) -- name: shutterCut
		-- upvalues: (copy) v_u_144, (copy) v_u_145, (copy) v_u_188, (copy) p_u_62, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (copy) v_u_79, (copy) v_u_96, (ref) v_u_6, (ref) v_u_5
		local v_u_192 = p189.size
		local v_u_193 = p189.lite
		local v194 = p189.caster
		local v_u_195
		if v194 then
			v_u_195 = v_u_144[v194]
		else
			v_u_195 = v_u_145[p189]
		end
		if v194 then
			v_u_144[v194] = nil
		else
			v_u_145[p189] = nil
		end
		if not v_u_195 or (v_u_195.done or v_u_195.cutAt) then
			v_u_195 = v_u_188(p189, os.clock() - 0.12)
		end
		local v196 = p_u_191 - p_u_190
		local v_u_197
		if v196.Magnitude > 0.1 then
			v_u_197 = v196.Unit
		else
			v_u_197 = p189.dir
		end
		local v198 = v196.Magnitude
		local v199 = math.max(v198, 1)
		for _, v200 in v_u_195.gates do
			local v201 = v200.d
			local v202 = math.min(v201, v199)
			local v203 = v200.radius
			local v204 = p_u_190 + v_u_197 * v202
			local v205 = p_u_190.Y - v202 * 1.2 / math.max(v199, 1)
			local v206 = p_u_62.FLOOR + v203 * 0.8
			local v207 = math.max(v205, v206)
			local v208 = p_u_62.facing
			local v209 = v204.X
			local v210 = v204.Z
			v200.cf = v208(Vector3.new(v209, v207, v210), -v_u_197)
		end
		v_u_195.cutAt = os.clock()
		for v211, v_u_212 in v_u_195.gates do
			p_u_62.after((v211 - 1) * 0.028 + 0.05, function()
				-- upvalues: (copy) v_u_212, (ref) p_u_62, (copy) v_u_192, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (copy) v_u_193
				local v213 = v_u_212.cf.Position
				local v214 = math.random() * 3.141592653589793
				local v215 = (v_u_212.cf.RightVector * math.cos(v214) + v_u_212.cf.LookVector * math.sin(v214)) * v_u_212.radius * 1.15
				p_u_62.thin(p_u_62.rod(v213 - v215, v213 + v215, 0.32 * v_u_192, v_u_11), 0.14)
				v_u_4.flash(v213, v_u_8, v_u_212.radius * 1.1, 0.12)
				if not v_u_193 then
					p_u_62.thin(p_u_62.rod(v213 - v215 * 0.9, v213 + v215 * 0.9, 0.9 * v_u_192, v_u_8, 0.35), 0.18)
					p_u_62.burst("Impact", v213, v_u_8, 1.1 * v_u_192)
				end
			end)
		end
		local v216 = (#v_u_195.gates - 1) * 0.028 + 0.05
		p_u_62.groundLine(p_u_190, p_u_191, 2.6 * v_u_192, v_u_9, 0.6, 0.45)
		p_u_62.after(v216, function()
			-- upvalues: (copy) p_u_190, (copy) v_u_197, (ref) p_u_62, (copy) p_u_191, (ref) v_u_8, (copy) v_u_192, (ref) v_u_11, (copy) v_u_193
			local v217 = p_u_190 + v_u_197 * 4
			p_u_62.glowBeam(v217, p_u_191, v_u_8, 1.4 * v_u_192, 0.28)
			p_u_62.thin(p_u_62.rod(v217, p_u_191, 0.3 * v_u_192, v_u_11), 0.2)
			if not v_u_193 then
				p_u_62.spikes(p_u_191, v_u_8, 6, 7 * v_u_192, 0.2, nil, nil, true)
				p_u_62.burst("Impact", p_u_191, v_u_8, 1.4 * v_u_192)
			end
		end)
		p_u_62.after(v216 + 0.12, function()
			-- upvalues: (copy) v_u_195, (ref) v_u_79, (ref) v_u_96, (ref) v_u_6, (ref) v_u_8
			v_u_195.flung = true
			for _, v218 in v_u_195.gates do
				v_u_79(v218.iris, v218.cf, v218.radius * 1.4, 0.42, 1.5)
				v_u_96(v218.cf * CFrame.new(0, 0.1, 0), v218.radius, v218.radius * 1.6, v_u_6.Ring, v_u_8, 0.3, 0)
				v218.ring:Destroy()
			end
		end)
		v_u_5.play("EyeActivate", {
			["at"] = p_u_190,
			["volume"] = p189.mine and 0.9 or 0.5
		})
		if p189.mine then
			v_u_4.shake(0.3, 0.25)
		end
	end
	local v_u_220 = {}
	setmetatable(v_u_220, {
		["__mode"] = "k"
	})
	local v_u_221 = { 1.02, 0.72, 0.44 }
	local v_u_222 = { 1.4, 2.6, 4.4 }
	local function v_u_236(p223, p224, p225) -- name: newPool
		-- upvalues: (copy) p_u_62, (ref) v_u_7, (ref) v_u_8, (ref) v_u_28, (ref) v_u_6, (ref) v_u_1, (ref) v_u_4, (ref) v_u_10, (ref) v_u_39
		local v226 = p223.lite
		local v227 = p223.ability.radius * p223.size
		local v228 = p_u_62.ground(p224, 0)
		local v229 = { v_u_7, v_u_8, v_u_8 }
		local v230 = {}
		for v231 = 1, v226 and 2 or 3 do
			local v232 = v_u_28(CFrame.new(v228 + Vector3.new(0, 1, 0) * (v231 * 0.03 + 0.1)), 0.1, v_u_6.MaelstromVortex, v229[v231], 0.1, true)
			v_u_1:AddItem(v232, p225)
			table.insert(v230, v232)
		end
		local v233 = v_u_4.part(Vector3.new(0.1, 1, 1), CFrame.new(v228 + Vector3.new(0, 0.06, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_10, {
			["shape"] = Enum.PartType.Cylinder,
			["material"] = Enum.Material.SmoothPlastic
		})
		v_u_1:AddItem(v233, p225)
		local v234 = v_u_28(CFrame.new(v228 + Vector3.new(0, 0.22, 0)), 0.1, v_u_6.Glow, v_u_10, 0, true)
		v_u_1:AddItem(v234, p225)
		local v235 = v_u_28(CFrame.new(v228 + Vector3.new(0, 0.3, 0)), v227, v_u_6.Ring, v_u_8, 0.1, true)
		v_u_1:AddItem(v235, p225)
		return {
			["iris"] = nil,
			["swirls"] = nil,
			["pit"] = nil,
			["core"] = nil,
			["rim"] = nil,
			["g"] = nil,
			["r"] = nil,
			["born"] = nil,
			["openAt"] = nil,
			["shutAt"] = nil,
			["crushAt"] = nil,
			["flot"] = nil,
			["iris"] = v_u_39(v226 and 6 or 8, v227, v_u_8, p225),
			["swirls"] = v230,
			["pit"] = v233,
			["core"] = v234,
			["rim"] = v235,
			["g"] = v228,
			["r"] = v227,
			["born"] = os.clock(),
			["flot"] = {}
		}
	end
	local function v_u_241(p237) -- name: dropPool
		for _, v238 in p237.iris.blades do
			v238:Destroy()
		end
		for _, v239 in p237.swirls do
			v239:Destroy()
		end
		p237.pit:Destroy()
		p237.core:Destroy()
		p237.rim:Destroy()
		for _, v240 in p237.flot do
			v240.p:Destroy()
		end
		table.clear(p237.flot)
	end
	local function v_u_300(p_u_242, p_u_243) -- name: runPool
		-- upvalues: (copy) p_u_62, (copy) v_u_241, (ref) v_u_61, (copy) v_u_222, (copy) v_u_221
		local v_u_244 = math.random() * 3.141592653589793 * 2
		local v_u_245 = os.clock()
		local v_u_246 = { 0, 0, 0 }
		p_u_62.runNow(function()
			-- upvalues: (ref) v_u_245, (copy) p_u_242, (copy) p_u_243, (ref) v_u_241, (ref) v_u_244, (ref) v_u_61, (copy) v_u_246, (ref) v_u_222, (ref) v_u_221
			local v247 = os.clock()
			local v248 = v247 - v_u_245
			local v249 = math.min(v248, 0.05)
			v_u_245 = v247
			local v250 = v247 - p_u_242.born
			if p_u_243 < v250 then
				v_u_241(p_u_242)
				return false
			end
			local v251 = p_u_242.r
			local v252 = p_u_242.g
			local v253 = p_u_242.openAt
			local v254, v255
			if v253 then
				local v256 = (v247 - v253) / 0.4
				local v257 = math.clamp(v256, 0, 1)
				local v258 = v257 - 1
				v254 = v258 * 2.7 * v258 * v258 + 1 + v258 * 1.7 * v258
				local v259 = 1 - math.clamp(v254, 0, 1.05) * 0.88
				local v260 = v247 * 2.2
				v255 = v259 + math.sin(v260) * 0.05 * v257
			else
				v255 = 1
				v254 = 0
			end
			local v261 = p_u_242.shutAt
			if v261 then
				local v262 = (v247 - v261) / 0.1
				local v263 = math.clamp(v262, 0, 1)
				v255 = v255 + (1.02 - v255) * v263 * v263
			end
			local v264 = v250 / 0.16
			local v265 = math.clamp(v264, 0, 1) - 1
			local v266 = v265 * 2.7 * v265 * v265 + 1 + v265 * 1.7 * v265
			local v267 = p_u_242.crushAt
			if v267 then
				local v268 = (v247 - v267) / 0.16
				local v269 = math.clamp(v268, 0, 1)
				v266 = v266 * (1 - v269 * v269)
				if v269 >= 1 then
					v_u_241(p_u_242)
					return false
				end
			end
			v_u_244 = v_u_244 + v249 * ((v267 and 14 or 0) + 0.7)
			v_u_61(p_u_242.iris, CFrame.new(v252 + Vector3.new(0, 0.4, 0)), v_u_244, math.min(v255, 1.05), v266)
			local v270 = p_u_242.rim
			local v271 = v251 * 1.06 * math.max(v266, 0.02)
			local v272 = v271 * 2
			local v273 = v271 * 2
			v270.Size = Vector3.new(v272, 0.05, v273)
			p_u_242.rim.CFrame = CFrame.new(v252 + Vector3.new(0, 0.3, 0)) * CFrame.Angles(0, -v_u_244 * 0.4, 0)
			for v274, v275 in p_u_242.swirls do
				local v276 = v_u_246
				v276[v274] = v276[v274] + v249 * v_u_222[v274] * (math.max(v254, 0) * 0.7 + 0.3)
				local v277 = v251 * v_u_221[v274] * math.max(v254, 0.05) * v266
				local v278 = math.max(v277, 0.05)
				local v279 = v278 * 2
				local v280 = v278 * 2
				v275.Size = Vector3.new(v279, 0.05, v280)
				v275.CFrame = CFrame.new(v252 + Vector3.new(0, 1, 0) * (v274 * 0.03 + 0.1)) * CFrame.Angles(0, -v_u_246[v274], 0)
			end
			local v281 = p_u_242.core
			local v282 = v251 * 0.42 * math.max(v254, 0.05) * v266
			local v283 = math.max(v282, 0.05)
			local v284 = v283 * 2
			local v285 = v283 * 2
			v281.Size = Vector3.new(v284, 0.05, v285)
			local v286 = v251 * 2 * math.max(v254, 0.3) * v266
			local v287 = math.max(v286, 0.1)
			p_u_242.pit.Size = Vector3.new(0.1, v287, v287)
			local v288 = {}
			for _, v289 in p_u_242.flot do
				local v290 = (v247 - v289.born) / v289.life
				if v290 >= 1 or not v289.p.Parent then
					v289.p:Destroy()
				else
					local v291 = v289.r * (1 - v290) ^ 1.25 + 0.5
					local v292 = v289.a + 2.2 * v290 + 5 * v290 * v290 * v290
					local v293 = v290 - 0.7
					local v294 = math.max(v293, 0) / 0.3
					local v295 = v289.p
					local v296 = CFrame.new
					local v297 = math.cos(v292) * v291
					local v298 = v289.size * 0.3 + 0.5 - v294 * 1.2
					local v299 = math.sin(v292) * v291
					v295.CFrame = v296(v252 + Vector3.new(v297, v298, v299)) * CFrame.Angles(v247 * v289.spin, v247 * v289.spin * 0.7, 0)
					v289.p.Size = Vector3.new(1, 1, 1) * v289.size * (1 - v294 * 0.8)
					table.insert(v288, v289)
				end
			end
			p_u_242.flot = v288
			return true
		end)
	end
	local function v_u_315(p301, p302) -- name: spawnFlotsam
		-- upvalues: (ref) v_u_4, (ref) v_u_12, (ref) v_u_10, (ref) v_u_1
		for v303 = 1, p302 do
			local v304 = 0.6 + math.random() * 0.8
			local v305 = v303 % 2 == 1
			local v306 = v_u_4.part
			local v307 = Vector3.new(1, 1, 1) * v304
			local v308 = CFrame.new(p301.g)
			local v309
			if v305 then
				v309 = v_u_12
			else
				v309 = v_u_10
			end
			local v310 = {}
			local v311
			if v305 then
				v311 = Enum.Material.Glass
			else
				v311 = Enum.Material.SmoothPlastic
			end
			v310.material = v311
			local v312 = v306(v307, v308, v309, v310)
			if v305 then
				v312.Transparency = 0.25
			end
			v_u_1:AddItem(v312, 2)
			local v313 = p301.flot
			local v314 = {
				["p"] = v312,
				["a"] = math.random() * 3.141592653589793 * 2,
				["r"] = p301.r * (0.75 + math.random() * 0.3),
				["born"] = os.clock(),
				["life"] = 0.8 + math.random() * 0.35,
				["size"] = v304,
				["spin"] = 1 + math.random() * 3
			}
			table.insert(v313, v314)
		end
	end
	local function v_u_325(p_u_316) -- name: dragRing
		-- upvalues: (ref) v_u_28, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (copy) p_u_62, (ref) v_u_32
		local v_u_317 = CFrame.new(p_u_316.g + Vector3.new(0, 0.35, 0))
		local v_u_318 = v_u_28(v_u_317, p_u_316.r * 1.15, v_u_6.Ring, v_u_8, 0.15, true)
		v_u_1:AddItem(v_u_318, 0.45)
		p_u_62.animate(0.36, 0, function(p319)
			-- upvalues: (copy) v_u_318, (copy) p_u_316, (copy) v_u_317, (ref) v_u_32
			local v320 = p319 * p319
			local v321 = v_u_318
			local v322 = p_u_316.r * (1.15 - 0.95 * v320)
			local v323 = v322 * 2
			local v324 = v322 * 2
			v321.Size = Vector3.new(v323, 0.05, v324)
			v_u_318.CFrame = v_u_317 * CFrame.Angles(0, -p319 * 3, 0)
			v_u_32(v_u_318, 0.15 + 0.85 * p319 ^ 2)
			if p319 >= 1 then
				v_u_318:Destroy()
			end
		end)
	end
	local v396 = {
		["dark_maelstrom_a"] = {
			["cast"] = function(p326) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) p_u_62, (ref) v_u_10, (copy) v_u_96, (ref) v_u_6
				local v327 = p326.size
				local v328 = p326.eye + p326.dir * 1.2
				v_u_4.flash(v328, v_u_8, 3 * v327, 0.1)
				p_u_62.pop(v328, v_u_10, 1.6 * v327, 0.3 * v327, 0.1, 0.1, Enum.Material.SmoothPlastic)
				if not p326.lite then
					v_u_96(p_u_62.facing(v328, -p326.dir), 1.4 * v327, 0.4 * v327, v_u_6.MaelstromVortex, v_u_8, 0.12, 20)
				end
			end,
			["shot"] = v127,
			["impact"] = v143,
			["hit"] = function(p329, p330, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_7, (ref) v_u_3, (copy) v_u_96, (ref) v_u_6, (ref) v_u_8
				p_u_62.burst("Impact", p330, v_u_7, 0.6)
				if not p329.lite then
					local v331 = v_u_3.CurrentCamera
					local v332
					if v331 then
						local v333 = v331.CFrame.Position - p330
						v332 = v333.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v333.Unit
					else
						v332 = Vector3.new(0, 0, 1)
					end
					v_u_96(p_u_62.facing(p330 + v332 * 0.5, v332), 1.6, 0.2, v_u_6.MaelstromVortex, v_u_8, 0.22, 18)
				end
			end
		},
		["dark_maelstrom_e"] = {
			["cast"] = function(p334) -- name: cast
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_39, (ref) v_u_61, (ref) v_u_32, (copy) v_u_188, (copy) v_u_144, (copy) v_u_145
				p_u_62.skillCast(p334, v_u_8)
				local v335 = p334.size
				if not p334.lite then
					local v336 = p334.eye + p334.dir * 1.6
					local v_u_337 = p_u_62.facing(v336, -p334.dir)
					local v_u_338 = v_u_39(6, 1.3 * v335, v_u_8, 0.6)
					local v_u_339 = math.random() * 6
					p_u_62.animate(0.3, 0, function(p340)
						-- upvalues: (ref) v_u_61, (copy) v_u_338, (copy) v_u_337, (copy) v_u_339, (ref) v_u_32
						local v341
						if p340 < 0.4 then
							v341 = p340 / 0.4
						else
							v341 = 1 - (p340 - 0.4) / 0.6
						end
						v_u_61(v_u_338, v_u_337, v_u_339 + p340 * 3, v341, 1)
						local v342 = v_u_338
						local v343 = p340 - 0.6
						local v344 = math.max(v343, 0) / 0.4
						for _, v345 in v342.blades do
							v_u_32(v345, v344)
						end
						if p340 >= 1 then
							for _, v346 in v_u_338.blades do
								v346:Destroy()
							end
						end
					end)
				end
				local v347 = v_u_188(p334, os.clock())
				local v348 = p334.caster
				if v348 then
					local v349 = v_u_144[v348]
					if v349 and not v349.cutAt then
						v349.born = -100
					end
					v_u_144[v348] = v347
				else
					v_u_145[p334] = v347
				end
			end,
			["beam"] = v219,
			["hit"] = function(p350, p351, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_11
				p_u_62.burst("Impact", p351, v_u_8, 0.8)
				if not p350.lite then
					for v352 = 0, 1 do
						local v353 = math.random() * 3.141592653589793
						local v354 = math.cos(v353)
						local v355 = (v352 - 0.5) * 1.4
						local v356 = math.sin(v353)
						local v357 = Vector3.new(v354, v355, v356).Unit * 1.8
						local v358 = p_u_62.thin
						local v359 = p_u_62.rod
						local v360 = p351 - v357
						local v361 = p351 + v357
						local v362 = 0.2
						local v363
						if v352 == 0 then
							v363 = v_u_11
						else
							v363 = v_u_8
						end
						v358(v359(v360, v361, v362, v363), 0.14)
					end
				end
			end
		},
		["dark_maelstrom_r"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p364) -- name: cast
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (copy) v_u_96, (ref) v_u_6, (ref) v_u_10, (ref) v_u_4
				p_u_62.skillCast(p364, v_u_8, true)
				local v365 = p364.size
				v_u_96(CFrame.new(p364.feet + Vector3.new(0, 0.15, 0)), 4.5 * v365, 0.4 * v365, v_u_6.MaelstromVortex, v_u_8, 0.4, -14, 0.1)
				p_u_62.pop(p364.eye, v_u_10, 2.4 * v365, 0.4, 0.16, 0.1, Enum.Material.SmoothPlastic)
				if p364.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p366, p367, p368) -- name: windup
				-- upvalues: (copy) v_u_236, (copy) v_u_220, (copy) v_u_300, (copy) v_u_96, (ref) v_u_6, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7
				local v369 = p368 + (p366.ability.duration or 2.4) + 2.5
				local v370 = v_u_236(p366, p367, v369)
				v_u_220[p366] = v370
				v_u_300(v370, v369)
				v_u_96(CFrame.new(v370.g + Vector3.new(0, 0.32, 0)), v370.r * 1.7, v370.r, v_u_6.Ring, v_u_8, math.max(p368, 0.12), 2, 0.1)
				v_u_4.ring(v370.g, v_u_7, v370.r * 1.2, 0.3, v_u_6.Shockwave)
			end,
			["zone"] = function(p371, p372, p_u_373) -- name: zone
				-- upvalues: (copy) v_u_220, (copy) v_u_236, (copy) v_u_300, (copy) p_u_62, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (copy) v_u_315, (copy) v_u_325, (ref) v_u_11
				local v_u_374 = p371.lite
				local v_u_375 = v_u_220[p371]
				if not v_u_375 then
					local v376 = p_u_373 + 2.5
					v_u_375 = v_u_236(p371, p372, v376)
					v_u_300(v_u_375, v376)
				end
				v_u_220[p371] = v_u_375
				v_u_375.openAt = os.clock()
				local v_u_377 = v_u_375.g
				local v_u_378 = v_u_375.r
				p_u_62.pop(v_u_377 + Vector3.new(0, 1, 0), v_u_8, 2, v_u_378 * 1.3, 0.3, 0.45)
				p_u_62.burst("Impact", v_u_377 + Vector3.new(0, 2, 0), v_u_8, 1.6)
				v_u_4.ring(v_u_377, v_u_8, v_u_378 * 1.25, 0.35, v_u_6.Shockwave)
				if not v_u_374 then
					p_u_62.spikes(v_u_377 + Vector3.new(0, 1.5, 0), v_u_8, 8, v_u_378 * 0.9, 0.25, Vector3.new(0, 1, 0), 0.9)
				end
				local v_u_379 = true
				local v_u_380 = os.clock()
				local v_u_381 = p371.ability.tick or 0.4
				task.spawn(function()
					-- upvalues: (ref) v_u_379, (copy) v_u_380, (copy) p_u_373, (ref) v_u_315, (ref) v_u_375, (copy) v_u_374, (ref) v_u_325, (ref) p_u_62, (copy) v_u_377, (ref) v_u_8, (copy) v_u_378, (copy) v_u_381
					while v_u_379 and os.clock() - v_u_380 < p_u_373 + 0.3 do
						v_u_315(v_u_375, v_u_374 and 2 or 5)
						v_u_325(v_u_375)
						if not v_u_374 then
							p_u_62.inward(v_u_377 + Vector3.new(0, 1.2, 0), v_u_8, 4, v_u_378, 0.3)
						end
						task.wait(v_u_381)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_379, (ref) v_u_375, (ref) p_u_62, (ref) v_u_4, (copy) v_u_377, (ref) v_u_8, (copy) v_u_378, (ref) v_u_11, (ref) v_u_6
					v_u_379 = false
					v_u_375.shutAt = os.clock()
					p_u_62.after(0.1, function()
						-- upvalues: (ref) v_u_4, (ref) v_u_377, (ref) v_u_8, (ref) v_u_378, (ref) v_u_11, (ref) v_u_6
						v_u_4.flash(v_u_377 + Vector3.new(0, 1, 0), v_u_8, v_u_378 * 0.9, 0.12)
						v_u_4.ring(v_u_377, v_u_11, v_u_378 * 1.05, 0.2, v_u_6.Ring)
					end)
				end
			end,
			["finish"] = function(p_u_382, p383) -- name: finish
				-- upvalues: (copy) v_u_220, (copy) p_u_62, (ref) v_u_10, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_6, (ref) v_u_7, (ref) v_u_39, (ref) v_u_61, (copy) v_u_79, (ref) v_u_12, (ref) v_u_5
				local v_u_384 = p_u_382.lite
				local v385 = v_u_220[p_u_382]
				v_u_220[p_u_382] = nil
				local v_u_386
				if v385 then
					v_u_386 = v385.g
				else
					v_u_386 = p_u_62.ground(p383, 0)
				end
				local v_u_387
				if v385 then
					v_u_387 = v385.r
				else
					v_u_387 = p_u_382.ability.radius * p_u_382.size
				end
				local v_u_388 = v385 and #v385.iris.blades or 8
				if v385 then
					v385.crushAt = os.clock()
				end
				p_u_62.pop(v_u_386 + Vector3.new(0, 2, 0), v_u_10, v_u_387 * 1.2, 0.5, 0.16, 0.15, Enum.Material.SmoothPlastic)
				p_u_62.inward(v_u_386 + Vector3.new(0, 2, 0), v_u_8, v_u_384 and 4 or 10, v_u_387 * 1.2, 0.16)
				p_u_62.after(0.16, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_386, (ref) v_u_11, (copy) v_u_387, (ref) p_u_62, (ref) v_u_10, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (copy) v_u_384, (ref) v_u_39, (copy) v_u_388, (ref) v_u_61, (ref) v_u_79, (ref) v_u_12, (ref) v_u_5, (copy) p_u_382
					v_u_4.flash(v_u_386 + Vector3.new(0, 3, 0), v_u_11, v_u_387 * 0.8, 0.14)
					p_u_62.pop(v_u_386 + Vector3.new(0, 2, 0), v_u_10, 2, v_u_387 * 0.9, 0.25, 0.1, Enum.Material.SmoothPlastic)
					p_u_62.pop(v_u_386, v_u_8, v_u_387 * 0.5, v_u_387 * 2.2, 0.5, 0.4)
					p_u_62.burst("Explosion", v_u_386 + Vector3.new(0, 3, 0), v_u_8, 2.5)
					p_u_62.burst("Shockwave", v_u_386 + Vector3.new(0, 0.3, 0), v_u_8, v_u_387 / 14)
					v_u_4.ring(v_u_386, v_u_8, v_u_387 * 1.6, 0.5, v_u_6.Shockwave)
					v_u_4.ring(v_u_386, v_u_7, v_u_387 * 1.3, 0.4, v_u_6.Ring)
					p_u_62.spikes(v_u_386 + Vector3.new(0, 2, 0), v_u_8, v_u_384 and 5 or 12, v_u_387 * 1.3, 0.3, nil, nil, true)
					local v389 = v_u_39(v_u_388, v_u_387, v_u_8, 1)
					v_u_61(v389, CFrame.new(v_u_386 + Vector3.new(0, 0.4, 0)), math.random() * 6, 0.9, 1)
					v_u_79(v389, CFrame.new(v_u_386 + Vector3.new(0, 0.4, 0)), v_u_387 * 1.1, 0.55, 0)
					if not v_u_384 then
						local v390 = { v_u_12, v_u_10, v_u_7 }
						p_u_62.chunks(v_u_386 + Vector3.new(0, 1, 0), v390, 10, 45, 0.9, 1.1)
						p_u_62.spikes(v_u_386 + Vector3.new(0, 2, 0), v_u_11, 6, v_u_387 * 1.6, 0.25, Vector3.new(0, 1, 0), 0.7)
					end
					v_u_5.play("Explosion", {
						["at"] = v_u_386,
						["volume"] = p_u_382.mine and 0.9 or 0.5
					})
					if p_u_382.mine then
						v_u_4.shake(0.5, 0.45)
					end
				end)
			end,
			["hit"] = function(p391, p392, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_7, (ref) v_u_3, (copy) v_u_96, (ref) v_u_6, (ref) v_u_8
				p_u_62.burst("Impact", p392, v_u_7, 0.9)
				if not p391.lite then
					local v393 = v_u_3.CurrentCamera
					local v394
					if v393 then
						local v395 = v393.CFrame.Position - p392
						v394 = v395.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v395.Unit
					else
						v394 = Vector3.new(0, 0, 1)
					end
					v_u_96(p_u_62.facing(p392 + v394 * 0.5, v394), 1.8, 0.2, v_u_6.MaelstromVortex, v_u_8, 0.25, -16)
				end
			end
		}
	}
	return v396
end