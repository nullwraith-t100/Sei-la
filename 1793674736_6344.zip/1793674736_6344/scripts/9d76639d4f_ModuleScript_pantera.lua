local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.PanteraClaw })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("2FA8FF")
local v_u_10 = Color3.fromHex("33F0D2")
local v_u_11 = Color3.fromRGB(8, 36, 80)
local v_u_12 = Color3.fromRGB(242, 238, 226)
local v_u_13 = Color3.fromRGB(236, 232, 220)
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = Enum.PartType.Wedge
local function v_u_24(p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.part(Vector3.new(p17, 0.05, p17), p16, p19, {
		["transparency"] = 1
	})
	for _, v22 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v23 = Instance.new("Decal")
		v23.Face = v22
		v23.Texture = p18
		v23.Color3 = p19
		v23.Transparency = p20
		v23.Parent = v21
	end
	return v21
end
local function v_u_57(p25, p26, p27, p28, p29, p30, p31, p32, p33, p34, p35) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v36 = p31 + p32 + p33
	local v37 = math.max(v36, 0.05)
	local v38 = {}
	local v39 = {}
	for v40 = 0, 10 do
		local v41 = v40 / 10
		local v42 = v41 * v37
		local v43 = v42 / math.max(p31, 0.001)
		local v44 = 1 - (1 - math.clamp(v43, 0, 1)) ^ 3
		local v45 = (v42 - p31 - p32) / math.max(p33, 0.001)
		local v46 = math.clamp(v45, 0, 1)
		local v47 = v46 * v46 * (3 - v46 * 2)
		local v48 = NumberSequenceKeypoint.new
		local v49 = p26 + (p27 - p26) * v44
		local v50 = math.max(v49, 0.05) / 2
		table.insert(v39, v48(v41, v50))
		local v51 = NumberSequenceKeypoint.new
		local v52 = p30 + (1 - p30) * v47
		local v53 = math.clamp(v52, 0, 1)
		table.insert(v38, v51(v41, v53))
	end
	local v54 = Instance.new("Attachment")
	v54.WorldCFrame = CFrame.new(p25)
	v54.Parent = v_u_3.Terrain
	local v55 = Instance.new("ParticleEmitter")
	v55.Enabled = false
	v55.Texture = p28
	v55.Color = ColorSequence.new(p29)
	v55.LightEmission = p35 or 0
	v55.LightInfluence = 0
	v55.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v55.EmissionDirection = Enum.NormalId.Top
	v55.SpreadAngle = Vector2.zero
	v55.Speed = NumberRange.new(0.01)
	v55.Size = NumberSequence.new(v39)
	v55.Transparency = NumberSequence.new(v38)
	v55.Lifetime = NumberRange.new(v37)
	local v56 = p34 or math.random(0, 359)
	v55.Rotation = NumberRange.new(v56, v56)
	v55.Parent = v54
	v55:Emit(1)
	v_u_1:AddItem(v54, v37 + 0.2)
end
local function v_u_68(p58, p59, p60, p61, p_u_62) -- name: slashAt
	-- upvalues: (copy) v_u_3, (copy) v_u_24, (copy) v_u_7, (copy) v_u_1, (copy) v_u_4
	local v63 = v_u_3.CurrentCamera
	local v64
	if v63 then
		local v65 = v63.CFrame.Position - p58
		v64 = v65.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v65.Unit
	else
		v64 = Vector3.new(0, 0, 1)
	end
	local v_u_66 = v_u_24(CFrame.lookAt(p58, p58 + v64) * CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.Angles(0, p61, 0), p59 * 0.3, v_u_7.PanteraClaw, p60, 0)
	v_u_1:AddItem(v_u_66, p_u_62 + 0.1)
	v_u_4.tween(v_u_66, p_u_62 * 0.3, {
		["Size"] = Vector3.new(p59, 0.05, p59)
	}, Enum.EasingStyle.Quart)
	task.delay(p_u_62 * 0.35, function()
		-- upvalues: (copy) v_u_66, (ref) v_u_4, (copy) p_u_62
		for _, v67 in v_u_66:GetChildren() do
			if not v67:IsA("Decal") then
				continue
			end
			v_u_4.tween(v67, p_u_62 * 0.65, {
				["Transparency"] = 1
			})
		end
	end)
end
local function v_u_88(p69) -- name: newDart
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_12, (copy) v_u_14, (copy) v_u_10, (copy) v_u_15, (copy) v_u_11
	local v70 = {
		["parts"] = {},
		["offs"] = {}
	}
	local v71 = {
		["material"] = v_u_14
	}
	local v72 = v_u_4.part(Vector3.new(0.26, 0.26, 1.7) * p69, CFrame.identity, v_u_12, v71)
	local v73 = CFrame.identity
	v_u_1:AddItem(v72, 4)
	local v74 = v70.parts
	table.insert(v74, v72)
	local v75 = v70.offs
	table.insert(v75, v73)
	for _, v76 in { 0, 3.141592653589793 } do
		local v77 = {
			["shape"] = v_u_15
		}
		local v78 = v_u_4.part(Vector3.new(0.26, 0.2, 0.75) * p69, CFrame.identity, v_u_10, v77)
		local v79 = CFrame.new(0, 0, p69 * -1.2) * CFrame.Angles(0, 0, v76) * CFrame.new(0, p69 * 0.1, 0)
		v_u_1:AddItem(v78, 4)
		local v80 = v70.parts
		table.insert(v80, v78)
		local v81 = v70.offs
		table.insert(v81, v79)
	end
	for _, v82 in { -1, 1 } do
		local v83 = {
			["shape"] = v_u_15,
			["material"] = v_u_14
		}
		local v84 = v_u_4.part(Vector3.new(0.06, 0.42, 0.5) * p69, CFrame.identity, v_u_11, v83)
		local v85 = CFrame.new(0, v82 * 0.22 * p69, p69 * 0.75) * CFrame.Angles(v82 > 0 and 0 or 3.141592653589793, 0, 0)
		v_u_1:AddItem(v84, 4)
		local v86 = v70.parts
		table.insert(v86, v84)
		local v87 = v70.offs
		table.insert(v87, v85)
	end
	return v70
end
return function(p_u_89)
	-- upvalues: (copy) v_u_57, (copy) v_u_7, (copy) v_u_10, (copy) v_u_68, (copy) v_u_4, (copy) v_u_11, (copy) v_u_14, (copy) v_u_13, (copy) v_u_12, (copy) v_u_88, (copy) v_u_9, (copy) v_u_1, (copy) v_u_8, (copy) v_u_3, (copy) v_u_24, (copy) v_u_6
	local v131 = {
		["pantera_a"] = {
			["windup"] = function(p90, p91, _) -- name: windup
				-- upvalues: (ref) v_u_68, (ref) v_u_10
				local v92 = p90.size
				v_u_68(p91 + p90.dir:Cross(Vector3.new(0, 1, 0)) * 0.8 * v92 + p90.dir * 1.2, 3 * v92, v_u_10, -0.5, 0.16)
			end,
			["beam"] = function(p93, p94, p95) -- name: beam
				-- upvalues: (copy) p_u_89, (ref) v_u_4, (ref) v_u_10, (ref) v_u_11, (ref) v_u_14, (ref) v_u_68, (ref) v_u_13, (ref) v_u_12
				local v_u_96 = p93.size
				local v97 = p_u_89.flatUnit(p95 - p94)
				local v98 = v97:Cross(Vector3.new(0, 1, 0))
				local v_u_99 = p_u_89.ground(p94 + v97 * 2, 0.08)
				local v_u_100 = p_u_89.ground(p95, 0.08)
				local v_u_101 = {}
				for _, v102 in p93.lite and { -1, 0, 1 } or {
					-2,
					-1,
					0,
					1,
					2
				} do
					local v103 = v_u_99 + v98 * v102 * 0.4 * v_u_96
					local v104 = v_u_100 + v98 * v102 * 0.75 * v_u_96
					local v105 = CFrame.lookAt(v103, v104)
					local v106 = v_u_4.part
					local v107 = 0.22 * v_u_96
					local v108 = v106(Vector3.new(v107, 0.12, 0.1), v105, v_u_10)
					local v109
					if p93.lite then
						v109 = nil
					else
						local v110 = v_u_4.part
						local v111 = 0.6 * v_u_96
						local v112 = {
							["material"] = nil,
							["transparency"] = 0.1,
							["material"] = v_u_14
						}
						v109 = v110(Vector3.new(v111, 0.08, 0.1), v105, v_u_11, v112)
					end
					table.insert(v_u_101, {
						["glow"] = v108,
						["groove"] = v109,
						["a"] = v103,
						["b"] = v104
					})
				end
				p_u_89.animate(0.1, 0, function(p113)
					-- upvalues: (copy) v_u_101
					local v114 = 1 - (1 - p113) ^ 2
					for _, v115 in v_u_101 do
						local v116 = v115.a:Lerp(v115.b, v114)
						local v117 = (v116 - v115.a).Magnitude
						local v118 = math.max(v117, 0.1)
						local v119 = CFrame.lookAt((v115.a + v116) / 2, v116 + (v115.b - v115.a).Unit * 0.01)
						local v120 = v115.glow
						local v121 = v115.glow.Size.X
						v120.Size = Vector3.new(v121, 0.12, v118)
						v115.glow.CFrame = v119 + Vector3.new(0, 0.03, 0)
						local v122 = v115.groove
						if not v122 then
							continue
						end
						local v123 = v122.Size.X
						v122.Size = Vector3.new(v123, 0.08, v118)
						v122.CFrame = v119
					end
				end)
				p_u_89.after(0.12, function()
					-- upvalues: (copy) v_u_101, (ref) p_u_89
					for _, v124 in v_u_101 do
						p_u_89.thin(v124.glow, 0.4)
						local v125 = v124.groove
						if not v125 then
							continue
						end
						p_u_89.fadeOut(v125, 0.45)
					end
				end)
				local v126 = p_u_89.ground(p95, 2.4)
				v_u_68(v126, 6 * v_u_96, v_u_10, math.random() * 0.6 - 0.3, 0.25)
				if not p93.lite then
					v_u_4.flash(v126, v_u_10, 3 * v_u_96, 0.15)
					for v_u_127 = 1, 3 do
						p_u_89.after(v_u_127 * 0.03, function()
							-- upvalues: (ref) p_u_89, (copy) v_u_99, (copy) v_u_100, (copy) v_u_127, (ref) v_u_13, (ref) v_u_12, (copy) v_u_96
							local v128 = { v_u_13, v_u_12 }
							p_u_89.chunks(v_u_99:Lerp(v_u_100, v_u_127 / 3) + Vector3.new(0, 0.3, 0), v128, 2, 12, 0.35 * v_u_96, 0.5, false, 1)
						end)
					end
				end
				p_u_89.beamHitSound(p93, p95, "Hit")
			end,
			["hit"] = function(p129, p130, _) -- name: hit
				-- upvalues: (ref) v_u_68, (ref) v_u_10, (copy) p_u_89
				v_u_68(p130 + Vector3.new(0, 0.5, 0), 3.2 * p129.size, v_u_10, math.random() * 6.28, 0.2)
				p_u_89.burst("Impact", p130, v_u_10, 0.5)
			end
		}
	}
	local v_u_132 = 0
	v131.pantera_e = {
		["cast"] = nil,
		["shot"] = nil,
		["weave"] = 0.5,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p133) -- name: cast
			-- upvalues: (copy) p_u_89, (ref) v_u_10, (ref) v_u_4, (ref) v_u_12
			p_u_89.skillCast(p133, v_u_10, false, true)
			local v134 = p133.size
			local v135 = p133.dir:Cross(Vector3.new(0, 1, 0))
			for _, v136 in { -1, 1 } do
				local v137 = p133.eye - Vector3.new(0, 1.1, 0) + v135 * v136 * 1.1 * v134
				v_u_4.flash(v137, v_u_10, 2.6 * v134, 0.18)
				if p133.lite then
					continue
				end
				p_u_89.spikes(v137, v_u_12, 3, 2.4 * v134, 0.16, p133.dir, 0.5)
			end
		end,
		["shot"] = function(p138, _) -- name: shot
			-- upvalues: (ref) v_u_132, (ref) v_u_88, (copy) p_u_89, (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (ref) v_u_1
			local v_u_139 = p138.size
			v_u_132 = v_u_132 + 1
			local v_u_140 = v_u_132 % 2 == 0 and 1 or -1
			local v141 = (p138.target - p138.eye).Magnitude / (p138.ability.speed or 180)
			local v_u_142 = math.max(v141, 0.05)
			local v_u_143 = v_u_88(v_u_139)
			local v144 = v_u_143.parts[1]
			p_u_89.streak(v144, v_u_10, v_u_9, 0.5 * v_u_139, p138.lite and 0.12 or 0.22)
			if not p138.lite then
				local v145 = Instance.new("Attachment")
				local v146 = 0.08 * v_u_139
				local v147 = 0.8 * v_u_139
				v145.Position = Vector3.new(0, v146, v147)
				v145.Parent = v144
				local v148 = Instance.new("Attachment")
				local v149 = -0.08 * v_u_139
				local v150 = 0.8 * v_u_139
				v148.Position = Vector3.new(0, v149, v150)
				v148.Parent = v144
				local v151 = Instance.new("Trail")
				v151.Attachment0 = v145
				v151.Attachment1 = v148
				v151.Color = ColorSequence.new(v_u_11)
				v151.Transparency = NumberSequence.new(0.2, 1)
				v151.Lifetime = 0.2
				v151.LightEmission = 0
				v151.LightInfluence = 0
				v151.FaceCamera = true
				v151.Parent = v144
			end
			local v_u_152 = false
			return {
				["place"] = function(p153, p154) -- name: place
					-- upvalues: (copy) v_u_142, (copy) v_u_140, (copy) v_u_139, (copy) v_u_143
					local v155 = p154 / v_u_142
					local v156 = (1 - math.clamp(v155, 0, 1)) ^ 1.5
					local v157 = p153 * CFrame.new(v_u_140 * 1.1 * v_u_139 * v156, v156 * -1.1, 0) * CFrame.Angles(0, 0, p154 * 16)
					for v158, v159 in v_u_143.parts do
						v159.CFrame = v157 * v_u_143.offs[v158]
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_152, (copy) v_u_143, (ref) v_u_1
					if not v_u_152 then
						v_u_152 = true
						for v160, v161 in v_u_143.parts do
							if v160 == 1 then
								v161.Transparency = 1
								v_u_1:AddItem(v161, 0.3)
							else
								v161:Destroy()
							end
						end
					end
				end
			}
		end,
		["impact"] = function(p162, p163) -- name: impact
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (copy) p_u_89, (ref) v_u_9, (ref) v_u_11, (ref) v_u_7, (ref) v_u_12
			local v164 = p162.size
			v_u_4.flash(p163, v_u_8, 2.5 * v164, 0.1)
			v_u_4.flash(p163, v_u_10, 6 * v164, 0.25)
			p_u_89.pop(p163, v_u_9, 1 * v164, 5 * v164, 0.25, 0.4)
			v_u_4.ring(p_u_89.ground(p163, 0.12), v_u_11, 4.5 * v164, 0.3, v_u_7.Ring)
			if not p162.lite then
				local v165 = { v_u_12, v_u_12, v_u_10 }
				p_u_89.chunks(p163, v165, 4, 20, 0.3 * v164, 0.6, false, 0.8)
				p_u_89.burst("Impact", p163, v_u_10, 0.9)
			end
			p_u_89.hitSound(p163, not p162.lite)
		end,
		["hit"] = function(_, p166, _) -- name: hit
			-- upvalues: (copy) p_u_89, (ref) v_u_10
			p_u_89.burst("Impact", p166, v_u_10, 0.7)
		end
	}
	local function v_u_197(p167, p168, p169, p170) -- name: rake
		-- upvalues: (copy) p_u_89, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11
		local v171 = p167.size
		local v172 = p167.lite
		local v173 = p_u_89.ground(p168, 0.2)
		local v174 = p169:Cross(Vector3.new(0, 1, 0))
		local v_u_175 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v173), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_175, p170 + 1.2)
		local v176 = v172 and 3 or 5
		local v_u_177 = {}
		for v178 = 1, v176 do
			local v179 = (v178 - (v176 + 1) / 2) * 1.6 * v171
			local v180 = v173 - p169 * 9 * v171 + v174 * v179 * 1.6 + Vector3.new(0, 26, 0) * v171
			local v181 = v173 + p169 * 7 * v171 + v174 * v179
			local v182 = Instance.new("Attachment")
			v182.Parent = v_u_175
			v182.WorldCFrame = CFrame.fromMatrix(v180, p169, Vector3.new(0, 1, 0))
			local v183 = Instance.new("Attachment")
			v183.Parent = v_u_175
			v183.WorldCFrame = CFrame.fromMatrix(v180, p169, Vector3.new(0, 1, 0))
			local v184 = {}
			for v185 = 1, v172 and 1 or 2 do
				local v186 = Instance.new("Beam")
				v186.Attachment0 = v182
				v186.Attachment1 = v183
				v186.Texture = v_u_7.Beam
				v186.TextureMode = Enum.TextureMode.Stretch
				v186.FaceCamera = true
				v186.Segments = 12
				v186.CurveSize0 = 6 * v171
				v186.CurveSize1 = 4 * v171
				v186.LightInfluence = 0
				if v185 == 1 then
					v186.Color = ColorSequence.new(v_u_8, v_u_10)
					v186.LightEmission = 0.7
					v186.Width0 = 2.8 * v171
					v186.Width1 = 0.5 * v171
					v186.ZOffset = 0.4
				else
					v186.Color = ColorSequence.new(v_u_11)
					v186.LightEmission = 0
					v186.Width0 = 4 * v171
					v186.Width1 = 0.8 * v171
					v186.Transparency = NumberSequence.new(0.15)
				end
				v186.Parent = v_u_175
				table.insert(v184, v186)
			end
			table.insert(v_u_177, {
				["a0"] = v182,
				["a1"] = v183,
				["from"] = v180,
				["to"] = v181,
				["beams"] = v184
			})
		end
		local v187 = p_u_89.after
		local v188 = p170 - 0.16
		v187(math.max(v188, 0), function()
			-- upvalues: (ref) p_u_89, (copy) v_u_177
			p_u_89.animate(0.16, 0, function(p189)
				-- upvalues: (ref) v_u_177
				local v190 = p189 * p189
				for _, v191 in v_u_177 do
					v191.a1.WorldPosition = v191.from:Lerp(v191.to, v190)
				end
			end)
		end)
		p_u_89.after(p170, function()
			-- upvalues: (ref) p_u_89, (copy) v_u_177, (copy) v_u_175
			p_u_89.animate(0.3, 0, function(p192)
				-- upvalues: (ref) v_u_177, (ref) v_u_175
				for _, v193 in v_u_177 do
					v193.a0.WorldPosition = v193.from:Lerp(v193.to, p192 * 0.6)
					for _, v194 in v193.beams do
						local v195 = NumberSequence.new
						local v196 = 0.15 + p192
						v194.Transparency = v195((math.clamp(v196, 0, 1)))
					end
				end
				if p192 >= 1 then
					v_u_175:Destroy()
				end
			end)
		end)
	end
	v131.pantera_r = {
		["cast"] = function(p198) -- name: cast
			-- upvalues: (copy) p_u_89, (ref) v_u_10, (ref) v_u_68, (ref) v_u_9
			p_u_89.skillCast(p198, v_u_10, true, true)
			local v199 = p198.size
			local v200 = p198.dir:Cross(Vector3.new(0, 1, 0))
			v_u_68(p198.eye + v200 * 1.2 * v199 + p198.dir * 1.5, 4.5 * v199, v_u_10, -0.6, 0.3)
			v_u_68(p198.eye - v200 * 1.2 * v199 + p198.dir * 1.5, 4.5 * v199, v_u_9, 0.6, 0.3)
		end,
		["windup"] = function(p201, p202, p203) -- name: windup
			-- upvalues: (copy) p_u_89, (ref) v_u_3, (ref) v_u_24, (ref) v_u_7, (ref) v_u_10, (ref) v_u_1, (ref) v_u_4, (ref) v_u_9, (ref) v_u_11, (ref) v_u_57
			local v_u_204 = p201.size
			local v205 = p201.ability.radius * v_u_204
			local v206 = p_u_89.ground(p202, 20 * v_u_204)
			local v207 = v_u_3.CurrentCamera
			local v208
			if v207 then
				local v209 = v207.CFrame.Position - v206
				v208 = v209.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v209.Unit
			else
				v208 = Vector3.new(0, 0, 1)
			end
			local v_u_210 = v_u_24(p_u_89.facing(v206, v208), 4 * v_u_204, v_u_7.PanteraClaw, v_u_10, 0)
			v_u_1:AddItem(v_u_210, p203 + 0.6)
			v_u_4.tween(v_u_210, 0.25, {
				["Size"] = Vector3.new(16, 0.05, 16) * v_u_204
			}, Enum.EasingStyle.Back)
			local v_u_211 = v_u_24(p_u_89.facing(v206 - v208 * 0.3, v208), 6 * v_u_204, v_u_7.Glow, v_u_9, 0.3)
			v_u_1:AddItem(v_u_211, p203 + 0.6)
			v_u_4.tween(v_u_211, 0.25, {
				["Size"] = Vector3.new(26, 0.05, 26) * v_u_204
			})
			p_u_89.after(p203, function()
				-- upvalues: (ref) v_u_4, (copy) v_u_210, (copy) v_u_204, (copy) v_u_211
				v_u_4.tween(v_u_210, 0.4, {
					["Size"] = Vector3.new(22, 0.05, 22) * v_u_204
				})
				for _, v212 in { v_u_210, v_u_211 } do
					for _, v213 in v212:GetChildren() do
						if not v213:IsA("Decal") then
							continue
						end
						v_u_4.tween(v213, 0.4, {
							["Transparency"] = 1
						})
					end
				end
			end)
			p_u_89.sigil(CFrame.new(p_u_89.ground(p202, 0.12)), v205, v_u_11, v_u_7.Ring, p203 + 0.3, 0)
			if not p201.lite then
				v_u_57(p_u_89.ground(p202, 0.1), v205, v205 * 2, v_u_7.Glow, v_u_10, 0.65, 0.2, p203, 0.3, nil, 0.2)
			end
		end,
		["strike"] = function(p_u_214, p_u_215, p216) -- name: strike
			-- upvalues: (copy) v_u_197, (copy) p_u_89, (ref) v_u_57, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6
			local v_u_217 = p_u_214.size
			local v218 = math.random() * 3.141592653589793 * 2
			local v219 = math.cos(v218)
			local v220 = math.sin(v218)
			local v_u_221 = Vector3.new(v219, 0, v220)
			v_u_197(p_u_214, p_u_215, v_u_221, (math.max(p216, 0)))
			p_u_89.after(math.max(p216, 0), function()
				-- upvalues: (ref) p_u_89, (copy) p_u_215, (copy) v_u_221, (copy) v_u_217, (ref) v_u_57, (ref) v_u_7, (ref) v_u_10, (copy) p_u_214, (ref) v_u_11, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6
				local v222 = p_u_89.ground(p_u_215, 0.15)
				local v223 = v_u_221
				local v224 = 13 * v_u_217
				local v225 = v223.X
				local v226 = v223.Z
				local v227 = math.atan2(v225, v226)
				local v228 = math.deg(v227) + 0
				v_u_57(p_u_89.ground(v222, 0.1), v224 * 0.5, v224, v_u_7.PanteraClaw, v_u_10, 0, 0.08, 0.9, 0.5, v228, 0.2)
				if not p_u_214.lite then
					local v229 = v_u_221
					local v230 = 15 * v_u_217
					local v231 = v_u_11
					local v232 = v229.X
					local v233 = v229.Z
					local v234 = math.atan2(v232, v233)
					local v235 = math.deg(v234) + 0
					v_u_57(p_u_89.ground(v222, 0.1), v230 * 0.5, v230, v_u_7.PanteraClaw, v231 or v_u_10, 0, 0.08, 0.6, 0.5, v235, 0.2)
				end
				v_u_4.flash(v222 + Vector3.new(0, 1.5, 0), v_u_8, 5 * v_u_217, 0.14)
				v_u_4.flash(v222 + Vector3.new(0, 1.5, 0), v_u_10, 7 * v_u_217, 0.25)
				v_u_4.ring(v222, v_u_11, (p_u_214.ability.strikeRadius or 10) * v_u_217, 0.4, v_u_7.Shockwave)
				v_u_4.ring(v222, v_u_10, (p_u_214.ability.strikeRadius or 10) * 1.3 * v_u_217, 0.5, v_u_7.Ring)
				if not p_u_214.lite then
					local v236 = { v_u_13, v_u_12, v_u_10 }
					p_u_89.chunks(v222 + Vector3.new(0, 0.5, 0), v236, 6, 26, 0.5 * v_u_217, 0.8, false, 1)
				end
				v_u_6.play("Explosion", {
					["at"] = v222,
					["volume"] = p_u_214.mine and 0.7 or 0.4
				})
				if p_u_214.mine then
					v_u_4.shake(0.25, 0.22)
				end
			end)
		end,
		["hit"] = function(p237, p238, _) -- name: hit
			-- upvalues: (ref) v_u_68, (ref) v_u_10, (copy) p_u_89
			v_u_68(p238 + Vector3.new(0, 0.5, 0), 4 * p237.size, v_u_10, math.random() * 6.28, 0.22)
			p_u_89.burst("Impact", p238, v_u_10, 0.8)
		end
	}
	return v131
end