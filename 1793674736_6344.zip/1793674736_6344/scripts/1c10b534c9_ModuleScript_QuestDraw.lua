require(script.Parent.Parent.Config.Quests)
local v_u_70 = {
	["seed"] = function(p1, p2, p3, p4) -- name: seed
		local v5 = 1234567
		for _, v6 in {
			math.abs(p1),
			p2,
			p3,
			p4 and 7 or 1
		} do
			local v7 = math.floor(v6) % 2147483647
			v5 = (((v5 * 48271 + v7) % 2147483647 * 48271 + v7) % 2147483647 * 48271 + v7) % 2147483647
		end
		return math.max(v5, 1)
	end,
	["rolls"] = function(p8) -- name: rolls
		local v9 = math.floor(p8) % 2147483647
		local v_u_10 = math.clamp(v9, 1, 2147483646)
		return function()
			-- upvalues: (ref) v_u_10
			v_u_10 = v_u_10 * 48271 % 2147483647
			return (v_u_10 - 1) / 2147483646
		end
	end,
	["draw"] = function(p11, p12, p13, p14, p15) -- name: draw
		local v16 = {}
		local v17 = {}
		if p14 then
			for _, v18 in p14 do
				v16[v18.kind] = true
				v17[v18.id] = true
			end
		end
		local v19 = {}
		for _ = 1, p12 do
			local v20 = {}
			local v21 = {}
			for _, v22 in p11 do
				if v16[v22.kind] or v17[v22.id] then
					continue
				end
				local v23
				if p15 and p15[v22.id] then
					v23 = v20
				else
					v23 = v21
				end
				table.insert(v23, v22)
			end
			if #v21 > 0 then
				v20 = v21
			end
			if #v20 == 0 then
				break
			end
			local v24 = p13() * #v20
			local v25 = math.floor(v24) + 1
			local v26 = #v20
			local v27 = v20[math.clamp(v25, 1, v26)]
			table.insert(v19, v27)
			v16[v27.kind] = true
			v17[v27.id] = true
		end
		return v19
	end,
	["ids"] = function(p28) -- name: ids
		local v29 = {}
		for _, v30 in p28 do
			local v31 = v30.id
			table.insert(v29, v31)
		end
		return v29
	end,
	["newState"] = function(p32, p33, p34) -- name: newState
		return {
			["period"] = nil,
			["base"] = nil,
			["claimed"] = nil,
			["quests"] = nil,
			["starts"] = nil,
			["refreshes"] = 0,
			["period"] = p32,
			["base"] = p33,
			["claimed"] = {},
			["quests"] = p34,
			["starts"] = {}
		}
	end,
	["progress"] = function(p35, p36, p37, p38) -- name: progress
		local v39 = p38 - (p35.starts[tostring(p36)] or (p35.base[p37] or 0))
		return math.max(v39, 0)
	end,
	["open"] = function(p40, p41, p42, p43) -- name: open
		-- upvalues: (copy) v_u_70
		local v44 = not p40.claimed[tostring(p41)]
		if v44 then
			v44 = v_u_70.progress(p40, p41, p42.kind, p43) < p42.goal
		end
		return v44
	end,
	["openSlots"] = function(p45, p46, p47) -- name: openSlots
		-- upvalues: (copy) v_u_70
		local v48 = {}
		for v49, v50 in p45.quests do
			local v51 = p46[v50]
			if v51 and not v_u_70.open(p45, v49, v51, p47[v51.kind] or 0) then
				continue
			end
			table.insert(v48, v49)
		end
		return v48
	end,
	["redraw"] = function(p52, p53, p54, p55, p56, p57) -- name: redraw
		-- upvalues: (copy) v_u_70
		if #p53 == 0 then
			return 0
		end
		local v58 = {}
		local v59 = {}
		for _, v60 in p53 do
			v58[v60] = true
			v59[p52.quests[v60] or ""] = true
		end
		local v61 = {}
		for v62, v63 in p52.quests do
			local v64 = p55[v63]
			if not v64 or v58[v62] then
				continue
			end
			table.insert(v61, v64)
		end
		local v65 = v_u_70.draw(p54, #p53, p57, v61, v59)
		local v66 = 0
		for v67, v68 in p53 do
			local v69 = v65[v67]
			if not v69 then
				continue
			end
			p52.quests[v68] = v69.id
			p52.starts[tostring(v68)] = p56[v69.kind] or 0
			p52.claimed[tostring(v68)] = nil
			v66 = v66 + 1
		end
		return v66
	end
}
return v_u_70