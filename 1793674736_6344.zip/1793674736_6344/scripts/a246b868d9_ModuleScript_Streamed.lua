return {
	["each"] = function(p1, p_u_2, p_u_3) -- name: each
		local v_u_4 = {}
		local function v8(p_u_5) -- name: arrive
			-- upvalues: (copy) p_u_2, (copy) v_u_4, (copy) p_u_3
			if p_u_5.Name == p_u_2 and not v_u_4[p_u_5] then
				local v_u_6 = {
					["cleanup"] = nil,
					["gone"] = false
				}
				v_u_4[p_u_5] = v_u_6
				task.spawn(function()
					-- upvalues: (ref) p_u_3, (copy) p_u_5, (copy) v_u_6
					local v7 = p_u_3(p_u_5)
					if v_u_6.gone then
						if v7 then
							v7()
							return
						end
					else
						v_u_6.cleanup = v7
					end
				end)
			end
		end
		local v_u_9 = p1.ChildAdded:Connect(v8)
		local v_u_13 = p1.ChildRemoved:Connect(function(p10) -- name: leave
			-- upvalues: (copy) v_u_4
			local v11 = v_u_4[p10]
			if v11 then
				v_u_4[p10] = nil
				v11.gone = true
				local v12 = v11.cleanup
				if v12 then
					v11.cleanup = nil
					v12()
				end
			end
		end)
		for _, v14 in p1:GetChildren() do
			v8(v14)
		end
		return function()
			-- upvalues: (copy) v_u_9, (copy) v_u_13, (copy) v_u_4
			v_u_9:Disconnect()
			v_u_13:Disconnect()
			for v15 in v_u_4 do
				local v16 = v_u_4[v15]
				if not v16 then
					continue
				end
				v_u_4[v15] = nil
				v16.gone = true
				local v17 = v16.cleanup
				if not v17 then
					continue
				end
				v16.cleanup = nil
				v17()
			end
		end
	end,
	["bag"] = function() -- name: bag
		local v_u_18 = {}
		return v_u_18, function()
			-- upvalues: (copy) v_u_18
			for _, v19 in v_u_18 do
				v19:Disconnect()
			end
			table.clear(v_u_18)
		end
	end
}