local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v6 = require(script.Parent.Parent.Parent.Events)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v3.Shared.Config.Textures)
local v_u_9 = Color3.fromRGB(232, 181, 48)
local v_u_10 = Color3.fromRGB(255, 240, 176)
local v_u_11 = Color3.fromRGB(44, 30, 12)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = {}
v6.on("die", function(p14)
	-- upvalues: (ref) v_u_13
	local v15 = p14.id
	if type(v15) == "number" then
		local v16 = v_u_13[v15]
		if v16 then
			v_u_13[v15] = nil
			for _, v17 in table.clone(v16) do
				v17()
			end
		end
	end
end)
local v_u_18 = v_u_13
for _, v19 in { "clear", "reset" } do
	v6.on(v19, function()
		-- upvalues: (ref) v_u_18
		local v20 = v_u_18
		v_u_18 = {}
		for _, v21 in v20 do
			for _, v22 in table.clone(v21) do
				v22()
			end
		end
	end)
end
return function(p_u_23)
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_5, (copy) v_u_12, (ref) v_u_18, (copy) v_u_11, (copy) v_u_2, (copy) v_u_7
	local function v_u_38(p_u_24, p25, p26) -- name: needleThread
		-- upvalues: (ref) v_u_4, (ref) v_u_1, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) p_u_23
		local v_u_27 = Instance.new("Attachment")
		v_u_27.Parent = v_u_4.Terrain
		v_u_27.WorldCFrame = CFrame.fromMatrix(p_u_24, Vector3.new(0, -1, 0), Vector3.new(1, 0, 0))
		v_u_1:AddItem(v_u_27, 3)
		local v_u_28 = Instance.new("Attachment")
		local v29 = p26 * 1.9
		v_u_28.Position = Vector3.new(0, 0, v29)
		v_u_28.Parent = p25
		local v_u_30 = p26 * 0.24
		local v_u_31 = Instance.new("Beam")
		v_u_31.Attachment0 = v_u_27
		v_u_31.Attachment1 = v_u_28
		v_u_31.Texture = v_u_8.Beam
		v_u_31.TextureMode = Enum.TextureMode.Wrap
		v_u_31.TextureLength = 6
		v_u_31.TextureSpeed = 3
		v_u_31.Color = ColorSequence.new(v_u_9, v_u_10)
		v_u_31.Transparency = NumberSequence.new(0.1)
		v_u_31.LightEmission = 0.6
		v_u_31.LightInfluence = 0
		v_u_31.Brightness = 1.6
		v_u_31.FaceCamera = true
		v_u_31.Width0 = v_u_30
		v_u_31.Width1 = v_u_30
		v_u_31.Segments = 12
		v_u_31.Parent = v_u_27
		local v_u_32 = false
		return function()
			-- upvalues: (ref) v_u_32, (copy) v_u_28, (ref) v_u_4, (ref) v_u_1, (copy) p_u_24, (ref) p_u_23, (copy) v_u_30, (copy) v_u_31, (copy) v_u_27
			if not v_u_32 then
				v_u_32 = true
				local v33 = v_u_28.WorldPosition
				v_u_28.Parent = v_u_4.Terrain
				v_u_28.WorldCFrame = CFrame.fromMatrix(v33, Vector3.new(0, 1, 0), Vector3.new(1, 0, 0))
				v_u_1:AddItem(v_u_28, 0.6)
				local v_u_34 = (v33 - p_u_24).Magnitude * 0.16
				p_u_23.animate(0.32, 0, function(p35)
					-- upvalues: (ref) v_u_30, (ref) v_u_31, (copy) v_u_34, (ref) v_u_27, (ref) v_u_28
					local v36 = v_u_30 * (1 - p35 * 0.7)
					local v37 = v_u_31
					v_u_31.Width0 = v36
					v37.Width1 = v36
					v_u_31.CurveSize0 = v_u_34 * p35
					v_u_31.CurveSize1 = v_u_34 * p35
					v_u_31.Transparency = NumberSequence.new(0.1 + 0.9 * p35)
					if p35 >= 1 then
						v_u_27:Destroy()
						v_u_28:Destroy()
					end
				end)
			end
		end
	end
	local function v50(p39, p40) -- name: needleShot
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (copy) p_u_23, (copy) v_u_38
		local v41 = p39.size
		local v42 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p40, v_u_9, {
			["transparency"] = 1
		})
		local v43 = v_u_5.part(Vector3.new(0.16, 0.16, 3.4) * v41, p40, v_u_10)
		local v44 = v_u_5.part(Vector3.new(0.5, 0.5, 3.6) * v41, p40, v_u_9, {
			["transparency"] = 0.62
		})
		local v45 = v_u_5.part(Vector3.new(0.3, 0.3, 0.9) * v41, p40, v_u_12)
		local v46 = v_u_5.part(Vector3.new(0.44, 0.16, 0.7) * v41, p40, v_u_9)
		local v47 = {
			{
				["p"] = v43,
				["off"] = CFrame.identity
			},
			{
				["p"] = v44,
				["off"] = CFrame.identity
			},
			{
				["p"] = v45,
				["off"] = CFrame.new(0, 0, -2 * v41) * CFrame.Angles(0, 0, 0.7853981633974483)
			},
			{
				["p"] = v46,
				["off"] = CFrame.new(0, 0, 1.75 * v41)
			}
		}
		p_u_23.streak(v42, v_u_9, v_u_10, 0.6 * v41, 0.1)
		local v48 = {}
		if not p39.lite then
			local v49 = v_u_38(p40.Position, v42, v41)
			table.insert(v48, v49)
		end
		if p39.mine then
			p_u_23.light(v42, v_u_9, 8 * v41)
		end
		return p_u_23.assemble(v42, v47, {}, 0, 0, v48, 0.1, 18)
	end
	local function v_u_59(p51, p52, p53, p54) -- name: stitch
		-- upvalues: (ref) v_u_4, (copy) p_u_23, (ref) v_u_10, (ref) v_u_9
		local v55 = v_u_4.CurrentCamera
		if v55 then
			local v56 = v55.CFrame
			for _, v57 in { 0.7853981633974483, -0.7853981633974483 } do
				local v58 = (v56.RightVector * math.cos(v57) + v56.UpVector * math.sin(v57)) * p52 / 2
				p_u_23.thin(p_u_23.rod(p51 - v58, p51 + v58, 0.26, v_u_10), p53)
				if not p54 then
					continue
				end
				p_u_23.thin(p_u_23.rod(p51 - v58, p51 + v58, 0.8, v_u_9, 0.55), p53 * 0.8)
			end
		end
	end
	local function v61(_, p60, _) -- name: needleHit
		-- upvalues: (copy) p_u_23, (ref) v_u_9, (copy) v_u_59
		p_u_23.burst("Impact", p60, v_u_9, 0.6)
		v_u_59(p60, 2.2, 0.16, false)
	end
	local v_u_62 = {}
	local function v_u_105(p63, p64) -- name: newLoom
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (copy) p_u_23
		local v65 = os.clock()
		local v_u_66 = {
			["parts"] = nil,
			["sizes"] = nil,
			["offs"] = nil,
			["ends"] = nil,
			["caster"] = nil,
			["at"] = nil,
			["dir"] = nil,
			["born"] = nil,
			["fadeAt"] = nil,
			["yankAt"] = nil,
			["used"] = 0,
			["done"] = false,
			["parts"] = {},
			["sizes"] = {},
			["offs"] = {},
			["ends"] = {},
			["caster"] = p63.caster,
			["at"] = p63.eye,
			["dir"] = p63.dir,
			["born"] = v65,
			["fadeAt"] = v65 + p64
		}
		local function v75(p67, p68, p69, p70) -- name: add
			-- upvalues: (ref) v_u_5, (copy) v_u_66, (ref) v_u_1
			local v71 = v_u_5.part(p67 * 0.05, CFrame.new(v_u_66.at), p69, {
				["shape"] = p70
			})
			v_u_1:AddItem(v71, 12)
			local v72 = v_u_66.parts
			table.insert(v72, v71)
			local v73 = v_u_66.sizes
			table.insert(v73, p67)
			local v74 = v_u_66.offs
			table.insert(v74, p68)
			return v71
		end
		local v76 = v75(Vector3.new(6.2, 0.4, 0.4), CFrame.identity, v_u_9)
		local v77 = v75(Vector3.new(0.4, 0.4, 4.4), CFrame.identity, v_u_9)
		v75(Vector3.new(1.05, 1.05, 1.05), CFrame.identity, v_u_10, Enum.PartType.Ball)
		for _, v78 in {
			{
				["part"] = nil,
				["at"] = Vector3.new(3.1, 0, 0),
				["part"] = v76
			},
			{
				["part"] = nil,
				["at"] = Vector3.new(0, 0, -2.2),
				["part"] = v77
			},
			{
				["part"] = nil,
				["at"] = Vector3.new(-3.1, 0, 0),
				["part"] = v76
			},
			{
				["part"] = nil,
				["at"] = Vector3.new(0, 0, 2.2),
				["part"] = v77
			}
		} do
			local v79 = Instance.new("Attachment")
			v79.Position = v78.at
			v79.Parent = v78.part
			local v80 = v_u_66.ends
			table.insert(v80, v79)
			if p63.lite then
				continue
			end
			v75(Vector3.new(0.1, 2.2, 0.1), CFrame.new(v78.at + Vector3.new(0, -1.1, 0)), v_u_10)
		end
		p_u_23.runNow(function()
			-- upvalues: (copy) v_u_66, (ref) p_u_23
			local v81 = os.clock()
			if v_u_66.done or v_u_66.fadeAt < v81 then
				v_u_66.done = true
				for _, v82 in v_u_66.parts do
					p_u_23.fadeOut(v82, 0.25)
				end
				return false
			end
			local v83 = v81 - v_u_66.born
			local v84 = v83 / 0.16
			local v85 = 1 - (1 - math.clamp(v84, 0, 1)) ^ 3
			local v86 = v_u_66.yankAt
			local v87
			if v86 then
				local v88 = (v81 - v86) / 0.4
				local v89 = math.clamp(v88, 0, 1)
				local v90 = v89 * 3.141592653589793
				v87 = math.sin(v90) * (1 - v89 * 0.3)
			else
				v87 = 0
			end
			local v91 = v_u_66.caster
			if v91 then
				v91 = v91.Character
			end
			if v91 then
				v91 = v91:FindFirstChild("Head")
			end
			local v92
			if v91 and v91:IsA("BasePart") then
				v92 = v91.Position
			else
				v92 = nil
			end
			local v93 = v92 or v_u_66.at
			local v94 = v87 * 1.4 + 5.6
			local v95 = v93 + Vector3.new(0, v94, 0)
			local v96 = p_u_23.aimAt(v95, v_u_66.dir)
			local v97 = CFrame.Angles
			local v98 = v83 * 2.4
			local v99 = math.sin(v98) * 0.1 - v87 * 0.45
			local v100 = v83 * 1.9
			local v101 = v96 * v97(v99, 0, math.sin(v100) * 0.08)
			for v102, v103 in v_u_66.parts do
				local v104 = v_u_66.offs[v102]
				v103.CFrame = v101 * (v104 - v104.Position + v104.Position * v85)
				v103.Size = v_u_66.sizes[v102] * math.max(v85, 0.05)
			end
			return true
		end)
		return v_u_66
	end
	local v_u_106 = {}
	local function v_u_131(p107, p108, p109) -- name: spreadThreads
		-- upvalues: (copy) p_u_23, (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (copy) v_u_106
		local v110 = p107.ability.radius
		local v_u_111 = p_u_23.ground(p108, 2.4)
		local v112 = p107.lite and 8 or 16
		local v_u_113 = {}
		for v114 = 1, v112 do
			local v115 = (v114 + math.random() * 0.4) / v112 * 3.141592653589793 * 2
			local v116 = p_u_23.ground(p108, 0.5 + math.random() * 2.6)
			local v117 = math.cos(v115)
			local v118 = math.sin(v115)
			local v119 = v116 + Vector3.new(v117, 0, v118) * v110 * (0.82 + math.random() * 0.22)
			local v120 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_111), v_u_9)
			v_u_1:AddItem(v120, p109 + 1.5)
			table.insert(v_u_113, {
				["p"] = v120,
				["to"] = v119
			})
		end
		local v121 = v_u_106
		local v122 = p107.caster
		local v123
		if v122 then
			local v124 = v122.UserId
			v123 = tostring(v124)
		else
			v123 = "podium"
		end
		v121[v123] = v_u_113
		p_u_23.animate(math.max(p109, 0.06), 0, function(p125)
			-- upvalues: (copy) v_u_113, (copy) v_u_111, (ref) p_u_23
			local v126 = 1 - (1 - p125) ^ 2
			for _, v127 in v_u_113 do
				if not v127.p.Parent then
					continue
				end
				local v128 = v_u_111:Lerp(v127.to, (math.max(v126, 0.02)))
				local v129 = v127.p
				local v130 = (v128 - v_u_111).Magnitude
				v129.Size = Vector3.new(0.24, 0.24, v130)
				v127.p.CFrame = p_u_23.aimAt((v_u_111 + v128) / 2, v127.to - v_u_111)
			end
		end)
	end
	local function v_u_168(p132, p_u_133, p_u_134, p135) -- name: puppetString
		-- upvalues: (copy) v_u_62, (ref) v_u_4, (ref) v_u_1, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9, (copy) p_u_23, (ref) v_u_18
		local v136 = v_u_62
		local v137 = p132.caster
		local v138
		if v137 then
			local v139 = v137.UserId
			v138 = tostring(v139)
		else
			v138 = "podium"
		end
		local v140 = v136[v138]
		local v141
		if v140 and not v140.done then
			v140.used = v140.used + 1
			v141 = v140.ends[(v140.used - 1) % #v140.ends + 1]
		else
			v141 = Instance.new("Attachment")
			v141.WorldPosition = p132.eye + Vector3.new(0, 5.6, 0)
			v141.Parent = v_u_4.Terrain
			v_u_1:AddItem(v141, p135 + 1)
		end
		local v_u_142 = Instance.new("Attachment")
		v_u_142.WorldPosition = v141.WorldPosition
		v_u_142.Parent = v_u_4.Terrain
		v_u_1:AddItem(v_u_142, p135 + 1)
		local v_u_143 = Instance.new("Beam")
		v_u_143.Attachment0 = v141
		v_u_143.Attachment1 = v_u_142
		v_u_143.Texture = v_u_8.Beam
		v_u_143.TextureMode = Enum.TextureMode.Wrap
		v_u_143.TextureLength = 5
		v_u_143.TextureSpeed = 2
		v_u_143.Color = ColorSequence.new(v_u_10, v_u_9)
		v_u_143.Transparency = NumberSequence.new(0.05)
		v_u_143.LightEmission = 0.6
		v_u_143.LightInfluence = 0
		v_u_143.Brightness = 1.6
		v_u_143.FaceCamera = true
		v_u_143.Width0 = 0.22
		v_u_143.Width1 = 0.22
		v_u_143.Parent = v_u_142
		local v_u_144 = v141.WorldPosition
		p_u_23.animate(0.1, 0, function(p145)
			-- upvalues: (copy) v_u_142, (copy) v_u_144, (copy) p_u_133
			if v_u_142.Parent then
				v_u_142.WorldPosition = v_u_144:Lerp(p_u_133, 1 - (1 - p145) ^ 2)
			end
		end)
		local v146 = v_u_4.CurrentCamera
		local v147
		if v146 then
			local v148 = v146.CFrame.Position - p_u_133
			v147 = v148.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v148.Unit
		else
			v147 = Vector3.new(0, 0, 1)
		end
		local v149 = v147:Cross(Vector3.new(0, 1, 0))
		local v150 = v149.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v149.Unit
		local v_u_151 = {}
		for _, v152 in { 1, -1 } do
			local v153 = v150 * 1.3 * v152 + Vector3.new(0, 1.7, 0)
			local v154 = p_u_23.rod
			local v155 = p_u_133 - v153
			local v156 = p_u_133 + v153
			local v157 = v_u_9
			table.insert(v_u_151, v154(v155, v156, 0.2, v157))
		end
		local v_u_158 = p_u_23.sigil(CFrame.new(p_u_133 + Vector3.new(0, 0.2, 0)), 1.9, v_u_9, v_u_8.Ring, p135, 0)
		local v_u_159 = false
		local function v_u_166() -- name: release
			-- upvalues: (ref) v_u_159, (copy) p_u_134, (copy) v_u_166, (ref) v_u_18, (copy) v_u_151, (ref) p_u_23, (copy) v_u_158, (copy) v_u_143, (copy) v_u_142
			if not v_u_159 then
				v_u_159 = true
				local v160 = p_u_134
				local v161 = v_u_166
				local v162 = v_u_18[v160]
				if v162 then
					local v163 = table.find(v162, v161)
					if v163 then
						table.remove(v162, v163)
					end
					if #v162 == 0 then
						v_u_18[v160] = nil
					end
				end
				for _, v164 in v_u_151 do
					p_u_23.thin(v164, 0.18)
				end
				if v_u_158.Parent then
					v_u_158:Destroy()
				end
				p_u_23.animate(0.2, 0, function(p165)
					-- upvalues: (ref) v_u_143, (ref) v_u_142
					v_u_143.Width0 = 0.22 * (1 - p165)
					v_u_143.Width1 = 0.22 * (1 - p165)
					if p165 >= 1 then
						v_u_142:Destroy()
					end
				end)
			end
		end
		local v167 = v_u_18[p_u_134]
		if not v167 then
			v167 = {}
			v_u_18[p_u_134] = v167
		end
		table.insert(v167, v_u_166)
		task.delay(p135, function()
			-- upvalues: (ref) v_u_159, (ref) p_u_23, (copy) p_u_133, (ref) v_u_10, (copy) v_u_166
			if not v_u_159 then
				p_u_23.glint(p_u_133 + Vector3.new(0, 1, 0), v_u_10, 2.6, 0.15)
				v_u_166()
			end
		end)
	end
	local v_u_169 = {}
	local function v_u_223(p170, p171, p172, p173) -- name: buildClock
		-- upvalues: (copy) p_u_23, (ref) v_u_4, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12, (ref) v_u_5, (ref) v_u_1, (ref) v_u_8
		local v174 = p170.lite
		local v175 = p_u_23.ground(p171, 21)
		local v176 = v_u_4.CurrentCamera
		local v177
		if v176 then
			local v178 = v176.CFrame.Position - v175
			v177 = v178.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v178.Unit
		else
			v177 = Vector3.new(0, 0, 1)
		end
		local v_u_179 = CFrame.lookAt(v175, v175 - v177)
		local v180 = p172 + p173 + 0.8
		local v_u_181 = p_u_23.newRig()
		if not v174 then
			p_u_23.rigAdd(v_u_181, Vector3.new(0.3, 25, 25), CFrame.new(0, 0, -0.25) * CFrame.Angles(0, 1.5707963267948966, 0), v_u_11, 0, Enum.Material.SmoothPlastic, v180).Shape = Enum.PartType.Cylinder
		end
		for v182 = 1, 12 do
			if v174 and v182 % 3 ~= 0 then
				continue
			end
			local v183 = v182 / 12 * 3.141592653589793 * 2
			local v184 = v182 % 3 == 0
			local v185 = (v184 and 0.8 or 0.83) * 12.5
			local v186 = CFrame.new(math.sin(v183) * v185, math.cos(v183) * v185, 0.2) * CFrame.Angles(0, 0, -v183)
			if v184 then
				p_u_23.rigAdd(v_u_181, Vector3.new(1.5, 1.5, 0.3), v186 * CFrame.Angles(0, 0, 0.7853981633974483), v_u_9, 0, nil, v180)
			else
				p_u_23.rigAdd(v_u_181, Vector3.new(0.5, 1.9, 0.3), v186, v_u_9, 0, nil, v180)
			end
		end
		p_u_23.rigAdd(v_u_181, Vector3.new(1.9, 1.9, 1.9), CFrame.new(0, 0, 0.7), v_u_9, 0, nil, v180).Shape = Enum.PartType.Ball
		local v_u_187 = {}
		for v188, v189 in {
			{
				["len"] = 6.25,
				["w"] = 1.05,
				["z"] = 0.45,
				["speed"] = 7,
				["color"] = nil,
				["color"] = v_u_9
			},
			{
				["len"] = 9.5,
				["w"] = 0.62,
				["z"] = 0.55,
				["speed"] = 21,
				["color"] = nil,
				["color"] = v_u_10
			},
			{
				["len"] = 11,
				["w"] = 0.22,
				["z"] = 0.62,
				["speed"] = 38,
				["color"] = nil,
				["color"] = v_u_12
			}
		} do
			if v174 and v188 == 3 then
				continue
			end
			local v190 = v_u_5.part
			local v191 = v189.w
			local v192 = v189.len
			local v193 = v190(Vector3.new(v191, v192, 0.25), v_u_179, v189.color)
			v_u_1:AddItem(v193, v180 + 1)
			local v194 = {
				["p"] = v193,
				["len"] = v189.len,
				["w"] = v189.w,
				["z"] = v189.z,
				["speed"] = v189.speed,
				["angle"] = math.random() * 3.141592653589793 * 2
			}
			table.insert(v_u_187, v194)
		end
		local v195 = p172 + p173
		p_u_23.sigil(p_u_23.facing(v175 + v177 * 0.15, v177), 13.5, v_u_9, v_u_8.Ring, v195, 0)
		if not v174 then
			p_u_23.sigil(p_u_23.facing(v175 - v177 * 0.5, v177), 17.25, v_u_9, v_u_8.MagicCircle, v195, 0.35)
		end
		local v196 = os.clock()
		local v_u_197 = {
			["rig"] = nil,
			["hands"] = nil,
			["face"] = nil,
			["sky"] = nil,
			["born"] = nil,
			["stopAt"] = nil,
			["strikeAt"] = nil,
			["endAt"] = nil,
			["snapFrom"] = nil,
			["broken"] = false,
			["rig"] = v_u_181,
			["hands"] = v_u_187,
			["face"] = v_u_179,
			["sky"] = v175,
			["born"] = v196
		}
		local v198 = p172 - 0.08
		v_u_197.stopAt = v196 + math.max(v198, 0)
		v_u_197.strikeAt = v196 + p172
		v_u_197.endAt = v196 + p172 + p173
		v_u_197.snapFrom = {}
		local v_u_199 = v196
		p_u_23.runNow(function()
			-- upvalues: (ref) v_u_199, (copy) v_u_197, (ref) p_u_23, (copy) v_u_181, (copy) v_u_179, (copy) v_u_187
			local v200 = os.clock()
			local v201 = v200 - v_u_199
			local v202 = math.min(v201, 0.05)
			v_u_199 = v200
			if v_u_197.broken then
				return false
			end
			local v203 = (v200 - v_u_197.born) / 0.18
			local v204 = math.clamp(v203, 0, 1)
			local v205 = v204 >= 1 and 1 or (v204 - 1) ^ 3 * 2.7 + 1 + (v204 - 1) ^ 2 * 1.7
			local v206 = math.max(v205, 0.05)
			p_u_23.rigPlace(v_u_181, v_u_179, v206)
			for v207, v208 in v_u_187 do
				local v209
				if v200 < v_u_197.stopAt then
					v208.angle = v208.angle + v208.speed * v202 * (1 + (v200 - v_u_197.born) * 4)
					v209 = v208.angle
				elseif v200 < v_u_197.strikeAt then
					local v210 = v208.angle
					local v211 = v200 * 95 + v207
					v209 = v210 + math.sin(v211) * 0.03
				else
					local v212 = v_u_197.snapFrom[v207]
					if not v212 then
						v212 = v208.angle
						v_u_197.snapFrom[v207] = v212
					end
					local v213 = v212 / 6.283185307179586
					local v214 = math.ceil(v213) * 3.141592653589793 * 2
					local v215 = (v200 - v_u_197.strikeAt) / 0.07
					local v216 = math.clamp(v215, 0, 1)
					v209 = v212 + (v214 - v212) * (1 - (1 - v216) ^ 2)
					if v207 == 3 then
						local v217 = v200 - v_u_197.strikeAt
						local v218 = math.floor(v217)
						local v219 = (v200 - v_u_197.strikeAt - v218) / 0.06
						v209 = v209 + (v218 + math.clamp(v219, 0, 1)) * 3.141592653589793 / 6
					end
				end
				local v220 = v208.p
				local v221 = v208.w * v206
				local v222 = v208.len * v206
				v220.Size = Vector3.new(v221, v222, 0.25)
				v208.p.CFrame = v_u_179 * CFrame.Angles(0, 0, -v209) * CFrame.new(0, v208.len * 0.38 * v206, v208.z)
			end
			return v200 < v_u_197.endAt + 0.5
		end)
		return v_u_197
	end
	local function v_u_231(p224) -- name: breakClock
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (ref) v_u_10
		if not p224.broken then
			p224.broken = true
			local v225 = table.clone(p224.rig.parts)
			for _, v226 in p224.hands do
				local v227 = v226.p
				table.insert(v225, v227)
			end
			for _, v228 in v225 do
				if not v228.Parent then
					continue
				end
				local v229 = v228.Position - p224.sky
				local v230 = v229.Magnitude <= 0.1 and Vector3.new(0, 1, 0) or v229.Unit
				v_u_5.tween(v228, 0.55, {
					["CFrame"] = nil,
					["Transparency"] = 1,
					["CFrame"] = (v228.CFrame + v230 * 7 + Vector3.new(0, -4, 0)) * CFrame.Angles(math.random() * 2, math.random() * 2, math.random() * 2)
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				v_u_1:AddItem(v228, 0.6)
			end
			v_u_5.flash(p224.sky, v_u_10, 10, 0.3)
		end
	end
	local function v_u_279(p232, p233, p234, p_u_235) -- name: hangingRubble
		-- upvalues: (copy) p_u_23, (ref) v_u_5, (ref) v_u_10, (ref) v_u_1
		local v_u_236 = {}
		for v237 = 1, p232.lite and 4 or 12 do
			local v238 = v237 % 3 == 0
			local v239
			if v238 then
				v239 = 0.5 + math.random() * 0.4
			else
				v239 = 0.8 + math.random() * 1.1
			end
			local v240 = math.random() * 3.141592653589793 * 2
			local v241 = math.random()
			local v242 = p234 * math.sqrt(v241) * 0.75
			local v243 = p_u_23.ground
			local v244 = math.cos(v240) * v242
			local v245 = math.sin(v240) * v242
			local v246 = v243(p233 + Vector3.new(v244, 0, v245), v239 / 2)
			local v247 = v_u_5.part
			local v248 = Vector3.new(1, 1, 1) * v239
			local v249 = CFrame.new(v246)
			local v250
			if v238 then
				v250 = v_u_10
			else
				v250 = p_u_23.EARTH[v237 % 2 + 1]
			end
			local v251 = {}
			local v252
			if v238 then
				v252 = Enum.Material.Neon
			else
				v252 = Enum.Material.SmoothPlastic
			end
			v251.material = v252
			local v253 = v247(v248, v249, v250, v251)
			v_u_1:AddItem(v253, p_u_235 + 2)
			local v254 = {
				["p"] = v253
			}
			local v255 = math.cos(v240) * 6
			local v256 = 34 + math.random() * 26
			local v257 = math.sin(v240) * 6
			v254.v = Vector3.new(v255, v256, v257)
			v254.spin = CFrame.Angles((math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4, 0)
			v254.r = CFrame.Angles(math.random() * 6, math.random() * 6, 0)
			table.insert(v_u_236, v254)
		end
		local v_u_258 = os.clock()
		local v_u_259 = v_u_258
		p_u_23.frame(function()
			-- upvalues: (ref) v_u_259, (copy) v_u_258, (copy) p_u_235, (copy) v_u_236, (ref) p_u_23
			local v260 = os.clock()
			local v261 = v260 - v_u_259
			local v262 = math.min(v261, 0.05)
			v_u_259 = v260
			local v263 = v260 - v_u_258
			local v264
			if v263 > 0.13 then
				v264 = v263 < p_u_235 + 0.13
			else
				v264 = false
			end
			for _, v265 in v_u_236 do
				if not v264 then
					if v263 > 0.13 then
						local v266 = v265.v
						local v267 = v262 * 110
						v265.v = v266 - Vector3.new(0, v267, 0)
					else
						v265.v = v265.v * (1 - v262 * 6)
					end
					v265.r = v265.r * v265.spin
					local v268 = v265.p.Position + v265.v * v262
					local v269 = p_u_23.FLOOR + v265.p.Size.Y / 2
					if v268.Y < v269 then
						local v270 = v268.X
						local v271 = v268.Z
						v268 = Vector3.new(v270, v269, v271)
						local v272 = v265.v.X * 0.4
						local v273 = v265.v.Y
						local v274 = math.abs(v273) * 0.25
						local v275 = v265.v.Z * 0.4
						v265.v = Vector3.new(v272, v274, v275)
					end
					v265.p.CFrame = CFrame.new(v268) * v265.r
				end
				if p_u_235 + 0.13 + 0.5 >= v263 then
					continue
				end
				local v276 = v265.p
				local v277 = (v263 - 0.13 - p_u_235 - 0.5) / 0.4
				v276.Transparency = math.clamp(v277, 0, 1)
			end
			if p_u_235 + 0.13 + 0.9 >= v263 then
				return true
			end
			for _, v278 in v_u_236 do
				v278.p:Destroy()
			end
			return false
		end)
	end
	local v_u_280 = 0
	local function v_u_287(p281, p282, p283) -- name: stopTime
		-- upvalues: (ref) v_u_280, (ref) v_u_2, (ref) v_u_1, (copy) p_u_23, (ref) v_u_5, (ref) v_u_12
		local v284 = os.clock()
		if v284 >= v_u_280 then
			v_u_280 = v284 + p282 + p283 + 1
			local v_u_285 = Instance.new("ColorCorrectionEffect")
			v_u_285.Name = "FateClock"
			v_u_285.Parent = v_u_2
			v_u_1:AddItem(v_u_285, p282 + p283 + 1)
			p_u_23.after(p281, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_285
				v_u_5.tween(v_u_285, 0.04, {
					["Saturation"] = -0.85,
					["Contrast"] = 0.2,
					["TintColor"] = nil,
					["TintColor"] = Color3.fromRGB(255, 246, 224)
				})
			end)
			p_u_23.after(p282, function()
				-- upvalues: (copy) v_u_285, (ref) v_u_5
				v_u_285.Brightness = 0.35
				v_u_5.tween(v_u_285, 0.3, {
					["Brightness"] = 0
				})
			end)
			task.delay(p282 + p283, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_285, (ref) v_u_12
				local v286 = {
					["Saturation"] = 0,
					["Contrast"] = 0,
					["TintColor"] = nil,
					["TintColor"] = v_u_12
				}
				v_u_5.tween(v_u_285, 0.8, v286)
			end)
		end
	end
	local v_u_288 = {}
	local function v_u_304(p289, p290, p291, p292) -- name: groundDial
		-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_1
		local v293 = p289.ability.radius
		p_u_23.sigil(CFrame.new(p_u_23.ground(p290, 0.16)), v293, v_u_9, v_u_8.Ring, p292, 0)
		if not p289.lite then
			p_u_23.sigil(CFrame.new(p_u_23.ground(p290, 0.13)), v293 * 0.62, v_u_10, v_u_8.MagicCircle, p292, -0.5)
		end
		local v294 = p_u_23.flatUnit(p291.LookVector)
		local v295 = p_u_23.flatUnit(p291.RightVector)
		local v296 = {
			["marks"] = {},
			["ends"] = {}
		}
		for v297 = 1, 12 do
			if p289.lite and v297 % 3 ~= 0 then
				continue
			end
			local v298 = v297 / 12 * 3.141592653589793 * 2
			local v299 = v294 * math.cos(v298) + v295 * math.sin(v298)
			local v300 = p_u_23.ground(p290, 0.12) + v299 * v293 * 0.86
			v296.ends[v297] = v300
			local v301 = v297 % 3 == 0 and 3.4 or 2
			local v_u_302 = v_u_5.part(Vector3.new(0.2, 0.14, 0.2), p_u_23.aimAt(v300, v299), v_u_9, {
				["transparency"] = 0.15
			})
			v_u_5.tween(v_u_302, 0.2, {
				["Size"] = Vector3.new(0.75, 0.14, v301)
			}, Enum.EasingStyle.Back)
			v_u_1:AddItem(v_u_302, p292 + 0.5)
			task.delay(p292, function()
				-- upvalues: (ref) p_u_23, (copy) v_u_302
				p_u_23.fadeOut(v_u_302, 0.4)
			end)
			local v303 = v296.marks
			table.insert(v303, v_u_302)
		end
		return v296
	end
	local function v_u_332(p305, p_u_306, p_u_307) -- name: frozenClock
		-- upvalues: (ref) v_u_4, (copy) p_u_23, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (ref) v_u_18
		local v308 = p305 + Vector3.new(0, 3.4, 0)
		local v309 = v_u_4.CurrentCamera
		local v310
		if v309 then
			local v311 = v309.CFrame.Position - v308
			v310 = v311.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v311.Unit
		else
			v310 = Vector3.new(0, 0, 1)
		end
		local v_u_312 = CFrame.lookAt(v308, v308 - v310)
		local v_u_313 = p_u_23.sigil(p_u_23.facing(v308, v310), 1.3, v_u_9, v_u_8.Ring, p_u_307, 0)
		local v_u_314 = v_u_5.part(Vector3.new(0.16, 0.9, 0.1), v_u_312, v_u_10)
		v_u_1:AddItem(v_u_314, p_u_307 + 0.5)
		local v_u_315 = os.clock()
		local v_u_316 = false
		local function v_u_321() -- name: release
			-- upvalues: (ref) v_u_316, (copy) p_u_306, (copy) v_u_321, (ref) v_u_18, (copy) v_u_314, (copy) v_u_313
			if not v_u_316 then
				v_u_316 = true
				local v317 = p_u_306
				local v318 = v_u_321
				local v319 = v_u_18[v317]
				if v319 then
					local v320 = table.find(v319, v318)
					if v320 then
						table.remove(v319, v320)
					end
					if #v319 == 0 then
						v_u_18[v317] = nil
					end
				end
				v_u_314:Destroy()
				if v_u_313.Parent then
					v_u_313:Destroy()
				end
			end
		end
		local v322 = v_u_18[p_u_306]
		if not v322 then
			v322 = {}
			v_u_18[p_u_306] = v322
		end
		table.insert(v322, v_u_321)
		p_u_23.runNow(function()
			-- upvalues: (ref) v_u_316, (copy) v_u_315, (copy) p_u_307, (copy) p_u_306, (copy) v_u_321, (ref) v_u_18, (copy) v_u_314, (copy) v_u_313, (copy) v_u_312
			if v_u_316 then
				return false
			end
			local v323 = os.clock() - v_u_315
			if p_u_307 < v323 then
				if not v_u_316 then
					v_u_316 = true
					local v324 = p_u_306
					local v325 = v_u_321
					local v326 = v_u_18[v324]
					if v326 then
						local v327 = table.find(v326, v325)
						if v327 then
							table.remove(v326, v327)
						end
						if #v326 == 0 then
							v_u_18[v324] = nil
						end
					end
					v_u_314:Destroy()
					if v_u_313.Parent then
						v_u_313:Destroy()
					end
				end
				return false
			end
			local v328 = v323 * 2
			local v329 = math.floor(v328)
			local v330 = (v323 * 2 - v329) / 0.1
			local v331 = (v329 + math.clamp(v330, 0, 1)) * 3.141592653589793 / 4
			v_u_314.CFrame = v_u_312 * CFrame.Angles(0, 0, -v331) * CFrame.new(0, 0.4, 0.05)
			return true
		end)
	end
	local v401 = {
		["oracle_eye_a"] = {
			["cast"] = function(p333) -- name: cast
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_10
				p_u_23.muzzle(p333, v_u_9, 0.75)
				p_u_23.glint(p333.eye + p333.dir * 1.2, v_u_10, 2.4, 0.12)
			end,
			["shot"] = v50,
			["impact"] = function(p334, p335) -- name: impact
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_5, (copy) v_u_59, (ref) v_u_8
				local v336 = p334.size
				p_u_23.burst("Impact", p335, v_u_9, 0.85 * v336)
				v_u_5.flash(p335, v_u_9, 4 * v336, 0.14)
				v_u_59(p335, 3.4 * v336, 0.24, not p334.lite)
				v_u_5.ring(p_u_23.ground(p335), v_u_9, p334.ability.radius * v336, 0.25, v_u_8.Ring)
				p_u_23.hitSound(p335)
			end,
			["hit"] = v61
		},
		["oracle_eye_e"] = {
			["cast"] = function(p337) -- name: cast
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_10, (copy) v_u_62, (copy) v_u_105
				p_u_23.skillCast(p337, v_u_9)
				p_u_23.glint(p337.eye, v_u_10, 4, 0.18)
				local v338 = p337.caster
				local v339
				if v338 then
					local v340 = v338.UserId
					v339 = tostring(v340)
				else
					v339 = "podium"
				end
				local v341 = v_u_62[v339]
				if v341 then
					v341.done = true
				end
				v_u_62[v339] = v_u_105(p337, 1)
			end,
			["windup"] = function(p342, p343, p344) -- name: windup
				-- upvalues: (copy) v_u_62, (copy) v_u_105, (copy) v_u_131, (ref) v_u_5, (copy) p_u_23, (ref) v_u_9, (ref) v_u_8
				local v345 = p342.ability.freeze or 4
				local v346 = p342.caster
				local v347
				if v346 then
					local v348 = v346.UserId
					v347 = tostring(v348)
				else
					v347 = "podium"
				end
				local v349 = v_u_62[v347]
				if not v349 or v349.done then
					v349 = v_u_105(p342, 1)
				end
				v_u_62[v347] = v349
				v349.fadeAt = os.clock() + p344 + v345 + 0.4
				v_u_131(p342, p343, p344)
				v_u_5.ring(p_u_23.ground(p343), v_u_9, p342.ability.radius, p344 + 0.2, v_u_8.Ring)
				p_u_23.sigil(CFrame.new(p_u_23.ground(p343, 0.18)), 5, v_u_9, v_u_8.MagicCircle, p344 + 0.5, 2.5)
			end,
			["land"] = function(p350, p351) -- name: land
				-- upvalues: (copy) p_u_23, (copy) v_u_106, (ref) v_u_12, (copy) v_u_62, (ref) v_u_5, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7
				local v352 = p350.ability.radius
				local v353 = p_u_23.ground(p351)
				local v354 = p350.caster
				local v355
				if v354 then
					local v356 = v354.UserId
					v355 = tostring(v356)
				else
					v355 = "podium"
				end
				local v357 = v_u_106[v355]
				v_u_106[v355] = nil
				if v357 then
					for _, v358 in v357 do
						if not v358.p.Parent then
							continue
						end
						v358.p.Color = v_u_12
						p_u_23.thin(v358.p, 0.32)
					end
				end
				local v359 = v_u_62[v355]
				if v359 then
					v359.yankAt = os.clock()
				end
				v_u_5.ring(v353, v_u_10, v352, 0.4, v_u_8.Ring)
				p_u_23.burst("Shockwave", v353 + Vector3.new(0, 0.3, 0), v_u_9, v352 / 22)
				v_u_7.play("Burst", {
					["at"] = nil,
					["volume"] = 0.7,
					["at"] = v353
				})
				if p350.mine then
					v_u_5.shake(0.2, 0.25)
				end
			end,
			["hit"] = function(p360, p361, p362) -- name: hit
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (copy) v_u_168
				p_u_23.burst("Impact", p361, v_u_9, 0.7)
				v_u_168(p360, p361, p362, p360.ability.freeze or 4)
			end
		},
		["oracle_eye_r"] = {
			["cast"] = function(p363) -- name: cast
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_10
				p_u_23.skillCast(p363, v_u_9, true)
				p_u_23.glint(p363.eye, v_u_10, 6, 0.22)
				p_u_23.burst("Flash", p363.eye, v_u_9, 0.35)
			end,
			["windup"] = function(p_u_364, p365, p366) -- name: windup
				-- upvalues: (copy) v_u_169, (copy) v_u_231, (copy) v_u_223, (copy) v_u_288, (copy) v_u_304, (copy) p_u_23, (ref) v_u_9, (ref) v_u_10, (copy) v_u_287, (ref) v_u_7, (ref) v_u_5
				local v367 = p_u_364.ability.freeze or 3
				local v368 = p_u_364.caster
				local v_u_369
				if v368 then
					local v370 = v368.UserId
					v_u_369 = tostring(v370)
				else
					v_u_369 = "podium"
				end
				local v371 = v_u_169[v_u_369]
				if v371 then
					v_u_231(v371)
				end
				local v_u_372 = v_u_223(p_u_364, p365, p366, v367)
				v_u_169[v_u_369] = v_u_372
				v_u_288[v_u_369] = v_u_304(p_u_364, p365, v_u_372.face, p366 + v367)
				p_u_23.burst("Flash", v_u_372.sky, v_u_9, 0.6)
				if not p_u_364.lite then
					p_u_23.inward(v_u_372.sky, v_u_10, 6, 17.5, (math.max(p366, 0.12)))
				end
				local v373 = p366 - 0.08
				local v374 = math.max(v373, 0)
				if p_u_364.mine then
					v_u_287(v374, p366, 0.65)
				end
				p_u_23.after(v374, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_372, (copy) p_u_364, (ref) v_u_5, (ref) v_u_10
					v_u_7.play("Bind", {
						["at"] = v_u_372.sky,
						["volume"] = p_u_364.mine and 0.7 or 0.4
					})
					v_u_5.flash(v_u_372.sky, v_u_10, 20, 0.12)
				end)
				p_u_23.after(p366 + v367, function()
					-- upvalues: (ref) v_u_169, (copy) v_u_369, (copy) v_u_372, (ref) v_u_231
					if v_u_169[v_u_369] == v_u_372 then
						v_u_169[v_u_369] = nil
					end
					v_u_231(v_u_372)
				end)
			end,
			["land"] = function(p375, p376) -- name: land
				-- upvalues: (copy) p_u_23, (copy) v_u_169, (ref) v_u_12, (ref) v_u_9, (copy) v_u_288, (ref) v_u_10, (ref) v_u_5, (ref) v_u_8, (copy) v_u_279, (ref) v_u_1, (ref) v_u_7
				local v_u_377 = p375.ability.radius
				local v378 = p_u_23.ground(p376)
				local v379 = p375.caster
				local v380
				if v379 then
					local v381 = v379.UserId
					v380 = tostring(v381)
				else
					v380 = "podium"
				end
				local v382 = p375.ability.freeze or 3
				local v383 = v_u_169[v380]
				local v384
				if v383 then
					v384 = v383.sky
				else
					v384 = p_u_23.ground(p376, 21)
				end
				p_u_23.pop(v384, v_u_12, 4, 30, 0.3, 0.05)
				p_u_23.burst("Flash", v384, v_u_9, 0.9, true)
				p_u_23.thin(p_u_23.rod(v384, v378, 7, v_u_12, 0.05), 0.35, true)
				p_u_23.thin(p_u_23.rod(v384, v378, 13, v_u_9, 0.5), 0.5, true)
				local v385 = v_u_288[v380]
				v_u_288[v380] = nil
				if v385 and v383 then
					for v386, v387 in v385.ends do
						local v388 = v383.face
						local v389 = v386 / 12 * 3.141592653589793 * 2
						local v390 = (v388 * CFrame.new(math.sin(v389) * 10, math.cos(v389) * 10, 0)).Position
						p_u_23.thin(p_u_23.rod(v390, v387, 1, v_u_10), 0.4, true)
						if p375.lite then
							continue
						end
						p_u_23.thin(p_u_23.rod(v390, v387, 2.6, v_u_9, 0.55), 0.5, true)
					end
					for _, v391 in v385.marks do
						if not v391.Parent then
							continue
						end
						v391.Color = v_u_12
						local v392 = {
							["Color"] = v_u_9
						}
						v_u_5.tween(v391, 0.5, v392)
					end
				end
				p_u_23.burst("Explosion", p_u_23.ground(p376, 2), v_u_9, v_u_377 / 9)
				local v393 = p_u_23.burst
				local v394 = v378 + Vector3.new(0, 0.3, 0)
				local v395 = v_u_9
				local v396 = v_u_377 / 16
				v393("Shockwave", v394, v395, (math.min(v396, 1.6)))
				v_u_5.ring(v378, v_u_9, v_u_377, 0.6)
				v_u_5.ring(v378, v_u_10, v_u_377 * 1.25, 0.45, v_u_8.SpeedLines)
				p_u_23.glint(p_u_23.ground(p376, 5), v_u_10, 16, 0.3)
				p_u_23.mark(p376, v_u_9, v_u_377 * 0.65, 1.8, v_u_8.CrackGlow, 0.15)
				v_u_279(p375, p376, v_u_377, v382)
				local v_u_397 = p_u_23.ball(v378, v_u_10, v_u_377 * 2.1, 0.3, Enum.Material.ForceField)
				v_u_1:AddItem(v_u_397, v382 + 1)
				task.delay(v382, function()
					-- upvalues: (copy) v_u_397, (ref) v_u_5, (copy) v_u_377
					if v_u_397.Parent then
						v_u_5.tween(v_u_397, 0.35, {
							["Size"] = nil,
							["Transparency"] = 1,
							["Size"] = Vector3.new(1, 1, 1) * v_u_377 * 2.4
						})
					end
				end)
				v_u_7.play("Explosion", {
					["at"] = v378,
					["volume"] = p375.mine and 1 or 0.6
				})
				if p375.mine then
					v_u_5.shake(0.6, 0.5)
				end
			end,
			["hit"] = function(p398, p399, p400) -- name: hit
				-- upvalues: (copy) p_u_23, (ref) v_u_9, (ref) v_u_10, (copy) v_u_332
				p_u_23.burst("Impact", p399, v_u_9, 1)
				p_u_23.glint(p399, v_u_10, 4.5, 0.18)
				v_u_332(p399, p400, p398.ability.freeze or 3)
			end
		}
	}
	return v401
end