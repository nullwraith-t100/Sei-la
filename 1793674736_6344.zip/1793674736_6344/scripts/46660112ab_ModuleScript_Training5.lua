require(script.Parent.Training)
return {
	{
		["id"] = "w5_stardummy",
		["name"] = "Star Dummy",
		["theme"] = "dummy",
		["rebirths"] = 300,
		["mult"] = 860000000000000,
		["color"] = "#F4F0FF"
	},
	{
		["id"] = "w5_orbitring",
		["name"] = "Orbit Ring",
		["theme"] = "ring",
		["rebirths"] = 307,
		["mult"] = 2750000000000000,
		["color"] = "#B06BFF"
	},
	{
		["id"] = "w5_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 8800000000000000,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w5_meteorfalls",
		["name"] = "Meteor Falls",
		["theme"] = "waterfall",
		["rebirths"] = 314,
		["mult"] = 8800000000000000,
		["color"] = "#5AD8FF"
	},
	{
		["id"] = "w5_starforge",
		["name"] = "Star Forge",
		["theme"] = "forge",
		["rebirths"] = 322,
		["mult"] = 2.82e16,
		["color"] = "#FF8A1A"
	},
	{
		["id"] = "w5_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 9e16,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w5_nebulatemple",
		["name"] = "Nebula Temple",
		["theme"] = "temple",
		["rebirths"] = 329,
		["mult"] = 9e16,
		["color"] = "#C77DFF"
	},
	{
		["id"] = "w5_pulsartower",
		["name"] = "Pulsar Tower",
		["theme"] = "storm",
		["rebirths"] = 336,
		["mult"] = 2.88e17,
		["color"] = "#E89AA8"
	},
	{
		["id"] = "w5_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 9.2e17,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w5_gravitychamber",
		["name"] = "Gravity Chamber",
		["theme"] = "gravity",
		["rebirths"] = 343,
		["mult"] = 9.2e17,
		["color"] = "#7A4DFF"
	},
	{
		["id"] = "w5_cometshrine",
		["name"] = "Comet Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 350,
		["mult"] = 2.95e18,
		["color"] = "#FF2A2A"
	},
	{
		["id"] = "w5_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 4.7e19,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w5_voidaltar",
		["name"] = "Void Altar",
		["theme"] = "void",
		["rebirths"] = 358,
		["mult"] = 9.4e18,
		["color"] = "#9B4DFF"
	}
}