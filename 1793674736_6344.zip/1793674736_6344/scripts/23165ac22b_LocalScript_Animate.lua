local v_u_1 = script.Parent
local v_u_2 = v_u_1:WaitForChild("Humanoid")
local v_u_3 = "Standing"
local function v_u_4() -- name: getRigScale
	-- upvalues: (copy) v_u_1
	return v_u_1:GetScale()
end
local v_u_5 = script:FindFirstChild("ScaleDampeningPercent")
local v6, v7 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAnimateRemoveEmoteChatHook")
end)
local v8 = v6 and v7
local v_u_9 = ""
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = 1
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {
	["idle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507766666",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766951",
			["weight"] = 1
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507766388",
			["weight"] = 9
		}
	},
	["walk"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777826",
			["weight"] = 10
		}
	},
	["run"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767714",
			["weight"] = 10
		}
	},
	["swim"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507784897",
			["weight"] = 10
		}
	},
	["swimidle"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507785072",
			["weight"] = 10
		}
	},
	["jump"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765000",
			["weight"] = 10
		}
	},
	["fall"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507767968",
			["weight"] = 10
		}
	},
	["climb"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507765644",
			["weight"] = 10
		}
	},
	["sit"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=2506281703",
			["weight"] = 10
		}
	},
	["toolnone"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507768375",
			["weight"] = 10
		}
	},
	["toolslash"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522635514",
			["weight"] = 10
		}
	},
	["toollunge"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=522638767",
			["weight"] = 10
		}
	},
	["wave"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770239",
			["weight"] = 10
		}
	},
	["point"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770453",
			["weight"] = 10
		}
	},
	["dance"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507771019",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507771955",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507772104",
			["weight"] = 10
		}
	},
	["dance2"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507776043",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776720",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507776879",
			["weight"] = 10
		}
	},
	["dance3"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507777268",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777451",
			["weight"] = 10
		},
		{
			["id"] = "http://www.roblox.com/asset/?id=507777623",
			["weight"] = 10
		}
	},
	["laugh"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770818",
			["weight"] = 10
		}
	},
	["cheer"] = {
		{
			["id"] = "http://www.roblox.com/asset/?id=507770677",
			["weight"] = 10
		}
	}
}
local v_u_19 = {
	["wave"] = false,
	["point"] = false,
	["dance"] = true,
	["dance2"] = true,
	["dance3"] = true,
	["laugh"] = false,
	["cheer"] = false
}
local v_u_20 = nil
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
local v25, v26 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAnimationAbilityManagerFixed")
end)
local v_u_27 = v25 and v26
function resetManagerListeners() -- name: resetManagerListeners
	-- upvalues: (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	if v_u_20 then
		v_u_20:Disconnect()
		v_u_20 = nil
	end
	if v_u_21 then
		v_u_21:Disconnect()
		v_u_21 = nil
	end
	if v_u_22 then
		v_u_22:Disconnect()
		v_u_22 = nil
	end
end
function teardownManager() -- name: teardownManager
	-- upvalues: (ref) v_u_23, (ref) v_u_24
	resetManagerListeners()
	v_u_23 = nil
	v_u_24 = nil
end
function processIfManagerBelongsToCharacter(p_u_28) -- name: processIfManagerBelongsToCharacter
	-- upvalues: (copy) v_u_1, (ref) v_u_24, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (ref) v_u_22
	if p_u_28.RootPart ~= v_u_1.PrimaryPart then
		return false
	end
	if v_u_24 ~= p_u_28 then
		resetManagerListeners()
		v_u_23 = p_u_28.GroundSensor
		v_u_20 = p_u_28:GetPropertyChangedSignal("GroundSensor"):Connect(function()
			-- upvalues: (copy) p_u_28, (ref) v_u_20
			if processIfManagerBelongsToCharacter(p_u_28) then
				v_u_20:Disconnect()
				v_u_20 = nil
			end
		end)
		v_u_21 = p_u_28:GetPropertyChangedSignal("RootPart"):Connect(function()
			-- upvalues: (copy) p_u_28, (ref) v_u_21
			if processIfManagerBelongsToCharacter(p_u_28) then
				v_u_21:Disconnect()
				v_u_21 = nil
			end
		end)
		v_u_22 = p_u_28.AncestryChanged:Connect(function(_, p29)
			if p29 == nil then
				resetManagerListeners()
				lookForControllerManager()
			end
		end)
		v_u_24 = p_u_28
	end
	return true
end
function setupManager(p_u_30) -- name: setupManager
	-- upvalues: (ref) v_u_24, (ref) v_u_23, (ref) v_u_20, (ref) v_u_21, (copy) v_u_1, (ref) v_u_22
	v_u_24 = p_u_30
	v_u_23 = p_u_30.GroundSensor
	v_u_20 = p_u_30:GetPropertyChangedSignal("GroundSensor"):Connect(function()
		-- upvalues: (ref) v_u_23, (ref) v_u_24
		v_u_23 = v_u_24.GroundSensor
	end)
	v_u_21 = p_u_30:GetPropertyChangedSignal("RootPart"):Connect(function()
		-- upvalues: (copy) p_u_30, (ref) v_u_1
		if p_u_30.RootPart ~= v_u_1.PrimaryPart then
			teardownManager()
			lookForControllerManager()
		end
	end)
	v_u_22 = p_u_30.AncestryChanged:Connect(function(_, p31)
		if p31 == nil then
			teardownManager()
			lookForControllerManager()
		end
	end)
end
function lookForControllerManager() -- name: lookForControllerManager
	-- upvalues: (ref) v_u_27, (copy) v_u_1, (ref) v_u_23, (ref) v_u_24
	if v_u_27 then
		local v_u_32 = v_u_1:FindFirstChildOfClass("ControllerManager")
		if v_u_32 then
			if v_u_32.RootPart == v_u_1.PrimaryPart then
				setupManager(v_u_32)
			else
				local v_u_33 = nil
				v_u_33 = v_u_32:GetPropertyChangedSignal("RootPart"):Connect(function()
					-- upvalues: (copy) v_u_32, (ref) v_u_1, (ref) v_u_33
					if v_u_32.RootPart == v_u_1.PrimaryPart then
						v_u_33:Disconnect()
						setupManager(v_u_32)
					end
				end)
			end
		else
			local v_u_34 = nil
			v_u_34 = v_u_1.ChildAdded:Connect(function(p35)
				-- upvalues: (ref) v_u_34
				if p35:IsA("ControllerManager") then
					v_u_34:Disconnect()
					lookForControllerManager()
				end
			end)
			return
		end
	else
		v_u_23 = nil
		v_u_24 = nil
		local v36 = v_u_1:FindFirstChildOfClass("ControllerManager")
		if v36 then
			processIfManagerBelongsToCharacter(v36)
		end
		if v_u_24 == nil then
			local v_u_37 = nil
			v_u_37 = v_u_1.ChildAdded:Connect(function(p38)
				-- upvalues: (ref) v_u_37
				if p38:IsA("ControllerManager") and processIfManagerBelongsToCharacter(p38) then
					v_u_37:Disconnect()
					v_u_37 = nil
				end
			end)
		end
		return
	end
end
lookForControllerManager()
math.randomseed(tick())
function findExistingAnimationInSet(p39, p40) -- name: findExistingAnimationInSet
	if p39 == nil or p40 == nil then
		return 0
	end
	for v41 = 1, p39.count do
		if p39[v41].anim.AnimationId ~= p40.AnimationId then
			continue
		end
		return v41
	end
	return 0
end
function configureAnimationSet(p_u_42, p_u_43) -- name: configureAnimationSet
	-- upvalues: (copy) v_u_17, (copy) v_u_16, (copy) v_u_2
	if v_u_17[p_u_42] ~= nil then
		for _, v44 in pairs(v_u_17[p_u_42].connections) do
			v44:disconnect()
		end
	end
	v_u_17[p_u_42] = {}
	v_u_17[p_u_42].count = 0
	v_u_17[p_u_42].totalWeight = 0
	v_u_17[p_u_42].connections = {}
	local v_u_45 = true
	local function v46()
		-- upvalues: (ref) v_u_45
		v_u_45 = game:GetService("StarterPlayer").AllowCustomAnimations
	end
	local v47, _ = pcall(v46)
	v_u_45 = not v47 and true or v_u_45
	local v48 = script:FindFirstChild(p_u_42)
	if v_u_45 and v48 ~= nil then
		local v49 = v_u_17[p_u_42].connections
		local v50 = v48.ChildAdded
		table.insert(v49, v50:connect(function(_)
			-- upvalues: (copy) p_u_42, (copy) p_u_43
			configureAnimationSet(p_u_42, p_u_43)
		end))
		local v51 = v_u_17[p_u_42].connections
		local v52 = v48.ChildRemoved
		table.insert(v51, v52:connect(function(_)
			-- upvalues: (copy) p_u_42, (copy) p_u_43
			configureAnimationSet(p_u_42, p_u_43)
		end))
		for _, v53 in pairs(v48:GetChildren()) do
			if not v53:IsA("Animation") then
				continue
			end
			local v54 = v53:FindFirstChild("Weight")
			local v55 = v54 == nil and 1 or v54.Value
			v_u_17[p_u_42].count = v_u_17[p_u_42].count + 1
			local v56 = v_u_17[p_u_42].count
			v_u_17[p_u_42][v56] = {}
			v_u_17[p_u_42][v56].anim = v53
			v_u_17[p_u_42][v56].weight = v55
			v_u_17[p_u_42].totalWeight = v_u_17[p_u_42].totalWeight + v_u_17[p_u_42][v56].weight
			local v57 = v_u_17[p_u_42].connections
			local v58 = v53.Changed
			table.insert(v57, v58:connect(function(_)
				-- upvalues: (copy) p_u_42, (copy) p_u_43
				configureAnimationSet(p_u_42, p_u_43)
			end))
			local v59 = v_u_17[p_u_42].connections
			local v60 = v53.ChildAdded
			table.insert(v59, v60:connect(function(_)
				-- upvalues: (copy) p_u_42, (copy) p_u_43
				configureAnimationSet(p_u_42, p_u_43)
			end))
			local v61 = v_u_17[p_u_42].connections
			local v62 = v53.ChildRemoved
			table.insert(v61, v62:connect(function(_)
				-- upvalues: (copy) p_u_42, (copy) p_u_43
				configureAnimationSet(p_u_42, p_u_43)
			end))
		end
	end
	if v_u_17[p_u_42].count <= 0 then
		for v63, v64 in pairs(p_u_43) do
			v_u_17[p_u_42][v63] = {}
			v_u_17[p_u_42][v63].anim = Instance.new("Animation")
			v_u_17[p_u_42][v63].anim.Name = p_u_42
			v_u_17[p_u_42][v63].anim.AnimationId = v64.id
			v_u_17[p_u_42][v63].weight = v64.weight
			v_u_17[p_u_42].count = v_u_17[p_u_42].count + 1
			v_u_17[p_u_42].totalWeight = v_u_17[p_u_42].totalWeight + v64.weight
		end
	end
	for _, v65 in pairs(v_u_17) do
		for v66 = 1, v65.count do
			if v_u_16[v65[v66].anim.AnimationId] ~= nil then
				continue
			end
			v_u_2:LoadAnimation(v65[v66].anim)
			v_u_16[v65[v66].anim.AnimationId] = true
		end
	end
end
function configureAnimationSetOld(p_u_67, p_u_68) -- name: configureAnimationSetOld
	-- upvalues: (copy) v_u_17, (copy) v_u_2
	if v_u_17[p_u_67] ~= nil then
		for _, v69 in pairs(v_u_17[p_u_67].connections) do
			v69:disconnect()
		end
	end
	v_u_17[p_u_67] = {}
	v_u_17[p_u_67].count = 0
	v_u_17[p_u_67].totalWeight = 0
	v_u_17[p_u_67].connections = {}
	local v_u_70 = true
	local function v71()
		-- upvalues: (ref) v_u_70
		v_u_70 = game:GetService("StarterPlayer").AllowCustomAnimations
	end
	local v72, _ = pcall(v71)
	v_u_70 = not v72 and true or v_u_70
	local v73 = script:FindFirstChild(p_u_67)
	if v_u_70 and v73 ~= nil then
		local v74 = v_u_17[p_u_67].connections
		local v75 = v73.ChildAdded
		table.insert(v74, v75:connect(function(_)
			-- upvalues: (copy) p_u_67, (copy) p_u_68
			configureAnimationSet(p_u_67, p_u_68)
		end))
		local v76 = v_u_17[p_u_67].connections
		local v77 = v73.ChildRemoved
		table.insert(v76, v77:connect(function(_)
			-- upvalues: (copy) p_u_67, (copy) p_u_68
			configureAnimationSet(p_u_67, p_u_68)
		end))
		local v78 = 1
		for _, v79 in pairs(v73:GetChildren()) do
			if not v79:IsA("Animation") then
				continue
			end
			local v80 = v_u_17[p_u_67].connections
			local v81 = v79.Changed
			table.insert(v80, v81:connect(function(_)
				-- upvalues: (copy) p_u_67, (copy) p_u_68
				configureAnimationSet(p_u_67, p_u_68)
			end))
			v_u_17[p_u_67][v78] = {}
			v_u_17[p_u_67][v78].anim = v79
			local v82 = v79:FindFirstChild("Weight")
			if v82 == nil then
				v_u_17[p_u_67][v78].weight = 1
			else
				v_u_17[p_u_67][v78].weight = v82.Value
			end
			v_u_17[p_u_67].count = v_u_17[p_u_67].count + 1
			v_u_17[p_u_67].totalWeight = v_u_17[p_u_67].totalWeight + v_u_17[p_u_67][v78].weight
			v78 = v78 + 1
		end
	end
	if v_u_17[p_u_67].count <= 0 then
		for v83, v84 in pairs(p_u_68) do
			v_u_17[p_u_67][v83] = {}
			v_u_17[p_u_67][v83].anim = Instance.new("Animation")
			v_u_17[p_u_67][v83].anim.Name = p_u_67
			v_u_17[p_u_67][v83].anim.AnimationId = v84.id
			v_u_17[p_u_67][v83].weight = v84.weight
			v_u_17[p_u_67].count = v_u_17[p_u_67].count + 1
			v_u_17[p_u_67].totalWeight = v_u_17[p_u_67].totalWeight + v84.weight
		end
	end
	for _, v85 in pairs(v_u_17) do
		for v86 = 1, v85.count do
			v_u_2:LoadAnimation(v85[v86].anim)
		end
	end
end
function scriptChildModified(p87) -- name: scriptChildModified
	-- upvalues: (copy) v_u_18
	local v88 = v_u_18[p87.Name]
	if v88 ~= nil then
		configureAnimationSet(p87.Name, v88)
	end
end
script.ChildAdded:connect(scriptChildModified)
script.ChildRemoved:connect(scriptChildModified)
local v89
if v_u_2 then
	v89 = v_u_2:FindFirstChildOfClass("Animator")
else
	v89 = nil
end
local v_u_90, v_u_91
if v89 then
	local v92 = v89:GetPlayingAnimationTracks()
	v_u_90 = v_u_24
	v_u_91 = v_u_23
	for _, v93 in ipairs(v92) do
		v93:Stop(0)
		v93:Destroy()
	end
else
	v_u_90 = v_u_24
	v_u_91 = v_u_23
end
for v94, v95 in pairs(v_u_18) do
	configureAnimationSet(v94, v95)
end
local v_u_96 = "None"
local v_u_97 = 0
local v_u_98 = 0
local v_u_99 = false
function stopAllAnimations() -- name: stopAllAnimations
	-- upvalues: (ref) v_u_9, (copy) v_u_19, (ref) v_u_99, (ref) v_u_10, (ref) v_u_12, (ref) v_u_11, (ref) v_u_15, (ref) v_u_14
	local v100 = v_u_9
	local v101 = v_u_19[v100] ~= nil and v_u_19[v100] == false and "idle" or v100
	if v_u_99 then
		v101 = "idle"
		v_u_99 = false
	end
	v_u_9 = ""
	v_u_10 = nil
	if v_u_12 ~= nil then
		v_u_12:disconnect()
	end
	if v_u_11 ~= nil then
		v_u_11:Stop()
		v_u_11:Destroy()
		v_u_11 = nil
	end
	if v_u_15 ~= nil then
		v_u_15:disconnect()
	end
	if v_u_14 ~= nil then
		v_u_14:Stop()
		v_u_14:Destroy()
		v_u_14 = nil
	end
	return v101
end
function getHeightScale() -- name: getHeightScale
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_5
	if not v_u_2 then
		return v_u_4()
	end
	if not v_u_2.AutomaticScalingEnabled then
		return v_u_4()
	end
	local v102 = v_u_2.HipHeight / 2
	if v_u_5 == nil then
		v_u_5 = script:FindFirstChild("ScaleDampeningPercent")
	end
	if v_u_5 ~= nil then
		v102 = 1 + (v_u_2.HipHeight - 2) * v_u_5.Value / 2
	end
	return v102
end
local function v_u_108(p103) -- name: setRunSpeed
	-- upvalues: (ref) v_u_11, (ref) v_u_14
	local v104 = p103 * 1.25 / getHeightScale()
	local v105 = 0.0001
	local v106 = 0.0001
	local v107 = 1
	if v104 <= 0.5 then
		v107 = v104 / 0.5
		v105 = 1
	elseif v104 < 1 then
		v106 = (v104 - 0.5) / 0.5
		v105 = 1 - v106
	else
		v107 = v104 / 1
		v106 = 1
	end
	v_u_11:AdjustWeight(v105)
	v_u_14:AdjustWeight(v106)
	v_u_11:AdjustSpeed(v107)
	v_u_14:AdjustSpeed(v107)
end
function setAnimationSpeed(p109) -- name: setAnimationSpeed
	-- upvalues: (ref) v_u_9, (copy) v_u_108, (ref) v_u_13, (ref) v_u_11
	if v_u_9 == "walk" then
		v_u_108(p109)
	elseif p109 ~= v_u_13 then
		v_u_13 = p109
		v_u_11:AdjustSpeed(v_u_13)
	end
end
function keyFrameReachedFunc(p110) -- name: keyFrameReachedFunc
	-- upvalues: (ref) v_u_9, (ref) v_u_14, (ref) v_u_11, (copy) v_u_19, (ref) v_u_99, (ref) v_u_13, (copy) v_u_2
	if p110 == "End" then
		if v_u_9 == "walk" then
			if v_u_14.Looped ~= true then
				v_u_14.TimePosition = 0
			end
			if v_u_11.Looped ~= true then
				v_u_11.TimePosition = 0
				return
			end
		else
			local v111 = v_u_9
			local v112 = v_u_19[v111] ~= nil and v_u_19[v111] == false and "idle" or v111
			if v_u_99 then
				if v_u_11.Looped then
					return
				end
				v112 = "idle"
				v_u_99 = false
			end
			local v113 = v_u_13
			playAnimation(v112, 0.15, v_u_2)
			setAnimationSpeed(v113)
		end
	end
end
function rollAnimation(p114) -- name: rollAnimation
	-- upvalues: (copy) v_u_17
	local v115 = math.random(1, v_u_17[p114].totalWeight)
	local v116 = 1
	while v_u_17[p114][v116].weight < v115 do
		v115 = v115 - v_u_17[p114][v116].weight
		v116 = v116 + 1
	end
	return v116
end
local function v_u_122(p117, p118, p119, p120) -- name: switchToAnim
	-- upvalues: (ref) v_u_10, (ref) v_u_11, (ref) v_u_14, (ref) v_u_13, (ref) v_u_9, (ref) v_u_12, (copy) v_u_17, (ref) v_u_15
	if p117 ~= v_u_10 then
		if v_u_11 ~= nil then
			v_u_11:Stop(p119)
			v_u_11:Destroy()
		end
		if v_u_14 ~= nil then
			v_u_14:Stop(p119)
			v_u_14:Destroy()
			v_u_14 = nil
		end
		v_u_13 = 1
		v_u_11 = p120:LoadAnimation(p117)
		v_u_11.Priority = Enum.AnimationPriority.Core
		v_u_11:Play(p119)
		v_u_9 = p118
		v_u_10 = p117
		if v_u_12 ~= nil then
			v_u_12:disconnect()
		end
		v_u_12 = v_u_11.KeyframeReached:connect(keyFrameReachedFunc)
		if p118 == "walk" then
			local v121 = rollAnimation("run")
			v_u_14 = p120:LoadAnimation(v_u_17.run[v121].anim)
			v_u_14.Priority = Enum.AnimationPriority.Core
			v_u_14:Play(p119)
			if v_u_15 ~= nil then
				v_u_15:disconnect()
			end
			v_u_15 = v_u_14.KeyframeReached:connect(keyFrameReachedFunc)
		end
	end
end
function playAnimation(p123, p124, p125) -- name: playAnimation
	-- upvalues: (copy) v_u_17, (copy) v_u_122, (ref) v_u_99
	local v126 = rollAnimation(p123)
	v_u_122(v_u_17[p123][v126].anim, p123, p124, p125)
	v_u_99 = false
end
function playEmote(p127, p128, p129) -- name: playEmote
	-- upvalues: (copy) v_u_122, (ref) v_u_99
	v_u_122(p127, p127.Name, p128, p129)
	v_u_99 = true
end
local v_u_130 = ""
local v_u_131 = nil
local v_u_132 = nil
local v_u_133 = nil
function toolKeyFrameReachedFunc(p134) -- name: toolKeyFrameReachedFunc
	-- upvalues: (ref) v_u_130, (copy) v_u_2
	if p134 == "End" then
		playToolAnimation(v_u_130, 0, v_u_2)
	end
end
function playToolAnimation(p135, p136, p137, p138) -- name: playToolAnimation
	-- upvalues: (copy) v_u_17, (ref) v_u_132, (ref) v_u_131, (ref) v_u_130, (ref) v_u_133
	local v139 = rollAnimation(p135)
	local v140 = v_u_17[p135][v139].anim
	if v_u_132 ~= v140 then
		if v_u_131 ~= nil then
			v_u_131:Stop()
			v_u_131:Destroy()
			p136 = 0
		end
		v_u_131 = p137:LoadAnimation(v140)
		if p138 then
			v_u_131.Priority = p138
		end
		v_u_131:Play(p136)
		v_u_130 = p135
		v_u_132 = v140
		v_u_133 = v_u_131.KeyframeReached:connect(toolKeyFrameReachedFunc)
	end
end
function stopToolAnimations() -- name: stopToolAnimations
	-- upvalues: (ref) v_u_130, (ref) v_u_133, (ref) v_u_132, (ref) v_u_131
	local v141 = v_u_130
	if v_u_133 ~= nil then
		v_u_133:disconnect()
	end
	v_u_130 = ""
	v_u_132 = nil
	if v_u_131 ~= nil then
		v_u_131:Stop()
		v_u_131:Destroy()
		v_u_131 = nil
	end
	return v141
end
function onRunning(p142) -- name: onRunning
	-- upvalues: (ref) v_u_91, (copy) v_u_2, (ref) v_u_90, (ref) v_u_99, (ref) v_u_3, (copy) v_u_19, (ref) v_u_9
	local v143 = getHeightScale()
	if v_u_91 ~= nil and v_u_2.EvaluateStateMachine == false then
		local v144 = v_u_2.RootPart
		local v145 = v_u_91.SensedPart
		if v145 then
			local v146 = v145:GetVelocityAtPosition(v_u_91.HitFrame.Position)
			local v147 = v144.AssemblyLinearVelocity
			local v148 = v147.X - v146.X
			local v149 = v147.Z - v146.Z
			local v150 = Vector3.new(v148, 0, v149).Magnitude
			local v151 = v_u_90.MovingDirection.Magnitude
			if v151 < 0.1 then
				v150 = 0
				v151 = 0
			elseif v151 > 1 then
				v151 = 1
			end
			p142 = v150 * v151
		end
	end
	local v152 = v_u_99
	if v152 then
		v152 = v_u_2.MoveDirection == Vector3.new(0, 0, 0)
	end
	if (v152 and (v_u_2.WalkSpeed / v143 or 0.75) or 0.75) * v143 < p142 then
		playAnimation("walk", 0.2, v_u_2)
		setAnimationSpeed(p142 / 16)
		v_u_3 = "Running"
	elseif v_u_19[v_u_9] == nil and not v_u_99 then
		playAnimation("idle", 0.2, v_u_2)
		v_u_3 = "Standing"
	end
end
function onDied() -- name: onDied
	-- upvalues: (ref) v_u_3
	v_u_3 = "Dead"
end
function onJumping() -- name: onJumping
	-- upvalues: (copy) v_u_2, (ref) v_u_98, (ref) v_u_3
	playAnimation("jump", 0.1, v_u_2)
	v_u_98 = 0.31
	v_u_3 = "Jumping"
end
function onClimbing(p153) -- name: onClimbing
	-- upvalues: (copy) v_u_2, (ref) v_u_3
	local v154 = p153 / getHeightScale()
	playAnimation("climb", 0.1, v_u_2)
	setAnimationSpeed(v154 / 5)
	v_u_3 = "Climbing"
end
function onGettingUp() -- name: onGettingUp
	-- upvalues: (ref) v_u_3
	v_u_3 = "GettingUp"
end
function onFreeFall() -- name: onFreeFall
	-- upvalues: (ref) v_u_98, (copy) v_u_2, (ref) v_u_3
	if v_u_98 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	end
	v_u_3 = "FreeFall"
end
function onFallingDown() -- name: onFallingDown
	-- upvalues: (ref) v_u_3
	v_u_3 = "FallingDown"
end
function onSeated() -- name: onSeated
	-- upvalues: (ref) v_u_3
	v_u_3 = "Seated"
end
function onPlatformStanding() -- name: onPlatformStanding
	-- upvalues: (ref) v_u_3
	v_u_3 = "PlatformStanding"
end
function onSwimming(p155) -- name: onSwimming
	-- upvalues: (copy) v_u_2, (ref) v_u_3
	local v156 = p155 / getHeightScale()
	if v156 > 1 then
		playAnimation("swim", 0.4, v_u_2)
		setAnimationSpeed(v156 / 10)
		v_u_3 = "Swimming"
	else
		playAnimation("swimidle", 0.4, v_u_2)
		v_u_3 = "Standing"
	end
end
function animateTool() -- name: animateTool
	-- upvalues: (ref) v_u_96, (copy) v_u_2
	if v_u_96 == "None" then
		playToolAnimation("toolnone", 0.1, v_u_2, Enum.AnimationPriority.Idle)
		return
	elseif v_u_96 == "Slash" then
		playToolAnimation("toolslash", 0, v_u_2, Enum.AnimationPriority.Action)
		return
	elseif v_u_96 == "Lunge" then
		playToolAnimation("toollunge", 0, v_u_2, Enum.AnimationPriority.Action)
	end
end
function getToolAnim(p157) -- name: getToolAnim
	for _, v158 in ipairs(p157:GetChildren()) do
		if v158.Name ~= "toolanim" or v158.className ~= "StringValue" then
			continue
		end
		return v158
	end
	return nil
end
local v_u_159 = 0
function stepAnimate(p160) -- name: stepAnimate
	-- upvalues: (ref) v_u_159, (ref) v_u_98, (ref) v_u_3, (copy) v_u_2, (copy) v_u_1, (ref) v_u_96, (ref) v_u_97, (ref) v_u_132
	local v161 = p160 - v_u_159
	v_u_159 = p160
	if v_u_98 > 0 then
		v_u_98 = v_u_98 - v161
	end
	if v_u_3 == "FreeFall" and v_u_98 <= 0 then
		playAnimation("fall", 0.2, v_u_2)
	else
		if v_u_3 == "Seated" then
			playAnimation("sit", 0.5, v_u_2)
			return
		end
		if v_u_3 == "Running" then
			playAnimation("walk", 0.2, v_u_2)
		elseif v_u_3 == "Dead" or (v_u_3 == "GettingUp" or (v_u_3 == "FallingDown" or (v_u_3 == "Seated" or v_u_3 == "PlatformStanding"))) then
			stopAllAnimations()
		end
	end
	local v162 = v_u_1:FindFirstChildOfClass("Tool")
	if v162 and v162:FindFirstChild("Handle") then
		local v163 = getToolAnim(v162)
		if v163 then
			v_u_96 = v163.Value
			v163.Parent = nil
			v_u_97 = p160 + 0.3
		end
		if v_u_97 < p160 then
			v_u_97 = 0
			v_u_96 = "None"
		end
		animateTool()
	else
		stopToolAnimations()
		v_u_96 = "None"
		v_u_132 = nil
		v_u_97 = 0
	end
end
v_u_2.Died:connect(onDied)
v_u_2.Running:connect(onRunning)
v_u_2.Jumping:connect(onJumping)
v_u_2.Climbing:connect(onClimbing)
v_u_2.GettingUp:connect(onGettingUp)
v_u_2.FreeFalling:connect(onFreeFall)
v_u_2.FallingDown:connect(onFallingDown)
v_u_2.Seated:connect(onSeated)
v_u_2.PlatformStanding:connect(onPlatformStanding)
v_u_2.Swimming:connect(onSwimming)
if not v8 then
	game:GetService("Players").LocalPlayer.Chatted:connect(function(p164)
		-- upvalues: (ref) v_u_3, (copy) v_u_19, (copy) v_u_2
		local v165 = ""
		if string.sub(p164, 1, 3) == "/e " then
			v165 = string.sub(p164, 4)
		elseif string.sub(p164, 1, 7) == "/emote " then
			v165 = string.sub(p164, 8)
		end
		if v_u_3 == "Standing" and v_u_19[v165] ~= nil then
			playAnimation(v165, 0.1, v_u_2)
		end
	end)
end
script:WaitForChild("PlayEmote").OnInvoke = function(p166)
	-- upvalues: (ref) v_u_3, (copy) v_u_19, (copy) v_u_2, (ref) v_u_11
	if v_u_3 == "Standing" then
		if v_u_19[p166] ~= nil then
			playAnimation(p166, 0.1, v_u_2)
			return true, v_u_11
		end
		if typeof(p166) ~= "Instance" or not p166:IsA("Animation") then
			return false
		end
		playEmote(p166, 0.1, v_u_2)
		return true, v_u_11
	end
end
if v_u_1.Parent ~= nil then
	playAnimation("idle", 0.1, v_u_2)
	local _ = "Standing"
end
while v_u_1.Parent ~= nil do
	local _, v167 = wait(0.1)
	stepAnimate(v167)
end