local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Events)
local v_u_6 = require(script.Parent.ArcadeKit)
local v_u_7 = require(script.Parent.Menus)
local v_u_8 = require(script.Parent.Sfx)
local v9 = v_u_2.Shared
local v10 = require(v9.Config.Perks)
local v_u_11 = require(v9.Config.Release)
local v_u_12 = require(v9.Logic.Format)
local v13 = {}
local v_u_14 = v1.LocalPlayer
local v_u_15 = "Pass_" .. v10.AUTO_WIN_PASS
local function v_u_21(p_u_16) -- name: settingsRow
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_6
	local v17 = v_u_14:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	if v17 then
		v17 = v17:FindFirstChild("Frames")
	end
	if v17 then
		v17 = v17:FindFirstChild("Settings")
	end
	if v17 then
		v17 = v17:FindFirstChild("ReplayTutorial", true)
	end
	if v17 and v17:IsA("GuiButton") then
		local v_u_18 = v17:Clone()
		v_u_18.Name = "AutoWin"
		v_u_18:SetAttribute("Pad", true)
		v_u_18.LayoutOrder = v17.LayoutOrder + 1
		local function v20() -- name: show
			-- upvalues: (copy) v_u_18, (ref) v_u_14, (ref) v_u_15, (ref) v_u_6
			v_u_18.Visible = v_u_14:GetAttribute(v_u_15) == true
			local v19 = v_u_14:GetAttribute("AutoWinOn") ~= false
			v_u_6.setText(v_u_18, v19 and "AUTO WIN: ON" or "AUTO WIN: OFF")
			if v19 then
				v_u_6.paint(v_u_18, Color3.fromRGB(124, 255, 107), Color3.fromRGB(30, 170, 60))
			else
				v_u_6.paint(v_u_18, Color3.fromRGB(150, 152, 165), Color3.fromRGB(90, 92, 104))
			end
		end
		v_u_18.Activated:Connect(function()
			-- upvalues: (copy) p_u_16, (ref) v_u_14
			p_u_16:FireServer("on", v_u_14:GetAttribute("AutoWinOn") == false)
		end)
		v_u_14:GetAttributeChangedSignal("AutoWinOn"):Connect(v20)
		v_u_14:GetAttributeChangedSignal(v_u_15):Connect(v20)
		v20()
		v_u_18.Parent = v17.Parent
	end
end
local function v_u_29(p22) -- name: payout
	-- upvalues: (copy) v_u_14, (copy) v_u_6, (copy) v_u_12, (copy) v_u_8
	if type(p22) ~= "table" then
		p22 = nil
	end
	if p22 then
		p22 = p22.wins
	end
	local v23 = v_u_14:FindFirstChild("PlayerGui")
	if v23 then
		v23 = v_u_14.PlayerGui:FindFirstChild("Main")
	end
	if v23 then
		v23 = v23:FindFirstChild("TrophyCounter", true)
	end
	if type(p22) == "number" and (v23 and v23:IsA("GuiObject")) then
		local v24 = v_u_6.float
		local v25 = "AUTO WIN +" .. v_u_12.short(p22)
		local v26 = Color3.fromRGB(255, 214, 64)
		local v27 = UDim2.fromScale(3.2, -0.25)
		local v28 = v23.AbsoluteSize.Y * 0.42
		v24(v23, v25, v26, v27, math.clamp(v28, 16, 30), v23.AbsoluteSize.Y * 0.7)
		v_u_8.play("Coin")
	end
end
local v_u_30 = false
local function v_u_35() -- name: begin
	-- upvalues: (ref) v_u_30, (copy) v_u_2, (copy) v_u_21, (copy) v_u_5, (copy) v_u_29, (copy) v_u_14, (copy) v_u_15, (copy) v_u_7
	if v_u_30 then
		return
	else
		v_u_30 = true
		local v31 = v_u_2:FindFirstChild("Remotes")
		local v_u_32 = v31
		if v_u_32 then
			v_u_32 = v31:WaitForChild("AutoWin", 10)
		end
		if not (v_u_32 and v_u_32:IsA("RemoteEvent")) then
			v_u_32 = nil
		end
		if v_u_32 then
			task.spawn(v_u_21, v_u_32)
			v_u_5.onNotify("AutoWin", v_u_29)
			local v_u_33 = false
			task.spawn(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_15, (ref) v_u_7, (ref) v_u_33, (copy) v_u_32
				while true do
					task.wait(0.5)
					local v34 = v_u_14:GetAttribute(v_u_15) == true
					if v34 then
						v34 = v_u_7.current() ~= nil and true or v_u_14:GetAttribute("ArcadeOpen") == true
					end
					if v34 == v_u_33 then
						continue
					end
					v_u_33 = v34
					v_u_32:FireServer("busy", v34)
				end
			end)
		end
	end
end
function v13.start() -- name: start
	-- upvalues: (copy) v_u_11, (copy) v_u_35, (copy) v_u_3, (copy) v_u_4
	if v_u_11.on(v_u_11.PERKS) then
		task.spawn(v_u_35)
	elseif v_u_3:IsStudio() then
		v_u_4:GetAttributeChangedSignal("DevUpdate2"):Connect(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_35
			if v_u_11.on(v_u_11.PERKS) then
				task.spawn(v_u_35)
			end
		end)
	end
end
return v13