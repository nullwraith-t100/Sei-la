local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.ArcadeKit)
local v_u_3 = require(script.Parent.Sfx)
local v4 = v1.Shared
local v_u_5 = require(v4.Logic.Blocks)
require(v4.Logic.ArcadeLog)
local v6 = require(v4.Config.Arcade)
local v7 = {
	["KEYS"] = {
		[Enum.KeyCode.A] = "left",
		[Enum.KeyCode.Left] = "left",
		[Enum.KeyCode.DPadLeft] = "left",
		[Enum.KeyCode.D] = "right",
		[Enum.KeyCode.Right] = "right",
		[Enum.KeyCode.DPadRight] = "right",
		[Enum.KeyCode.S] = "down",
		[Enum.KeyCode.Down] = "down",
		[Enum.KeyCode.DPadDown] = "down",
		[Enum.KeyCode.W] = "rotate",
		[Enum.KeyCode.Up] = "rotate",
		[Enum.KeyCode.X] = "rotate",
		[Enum.KeyCode.ButtonA] = "rotate",
		[Enum.KeyCode.Z] = "rotateBack",
		[Enum.KeyCode.Q] = "rotateBack",
		[Enum.KeyCode.ButtonX] = "rotateBack",
		[Enum.KeyCode.Space] = "drop",
		[Enum.KeyCode.DPadUp] = "drop",
		[Enum.KeyCode.ButtonY] = "drop"
	}
}
local v_u_8 = {
	Color3.fromRGB(70, 215, 255),
	Color3.fromRGB(255, 212, 50),
	Color3.fromRGB(185, 95, 255),
	Color3.fromRGB(95, 230, 105),
	Color3.fromRGB(255, 70, 90),
	Color3.fromRGB(60, 120, 255),
	Color3.fromRGB(255, 150, 45)
}
local v_u_9 = {
	"NICE!",
	"DOUBLE!",
	"TRIPLE!",
	"CHAKRA BLAST!"
}
local v_u_10 = {
	v_u_2.WHITE,
	v_u_2.CYAN,
	v_u_2.GREEN,
	v_u_2.GOLD
}
local v_u_11 = {
	"Burst",
	"Burst",
	"Crit",
	"RevealBig"
}
local v_u_12 = 1 / v6.blocks.tickRate
local function v_u_25(p13, p14, p15, p16, p17, p18) -- name: blockCell
	-- upvalues: (copy) v_u_2
	local v19 = Instance.new("Frame")
	v19.Name = "Cell"
	v19.BackgroundTransparency = 1
	v19.Position = UDim2.fromScale((p14 - 1) / p16, (p15 - 1) / p17)
	v19.Size = UDim2.fromScale(1 / p16, 1 / p17)
	v19.ZIndex = p18
	local v20 = Instance.new("Frame")
	v20.Name = "Block"
	v20.BorderSizePixel = 0
	v20.AnchorPoint = Vector2.new(0.5, 0.5)
	v20.Position = UDim2.fromScale(0.5, 0.5)
	v20.Size = UDim2.fromScale(0.94, 0.94)
	v20.ZIndex = p18 + 1
	v20.Visible = false
	local v21 = Instance.new("UICorner")
	v21.CornerRadius = UDim.new(0.18, 0)
	v21.Parent = v20
	local v22 = Instance.new("UIStroke")
	v22.Thickness = 2
	v22.Color = Color3.new(0, 0, 0)
	v22.Parent = v20
	local v23 = Instance.new("Frame")
	v23.Name = "Shine"
	v23.BorderSizePixel = 0
	v23.BackgroundColor3 = v_u_2.WHITE
	v23.BackgroundTransparency = 0.55
	v23.Position = UDim2.fromScale(0.16, 0.16)
	v23.Size = UDim2.fromScale(0.26, 0.26)
	v23.ZIndex = p18 + 2
	local v24 = Instance.new("UICorner")
	v24.CornerRadius = UDim.new(0.3, 0)
	v24.Parent = v23
	v23.Parent = v20
	v20.Parent = v19
	v19.Parent = p13
	return {
		["root"] = v19,
		["block"] = v20,
		["shine"] = v23,
		["stroke"] = v22
	}
end
local function v_u_29(p26, p27) -- name: show
	-- upvalues: (copy) v_u_8
	if p27 == 0 then
		p26.block.Visible = false
		return
	else
		local v28 = v_u_8[math.abs(p27)]
		p26.block.Visible = true
		if p27 > 0 then
			p26.block.BackgroundColor3 = v28
			p26.block.BackgroundTransparency = 0
			p26.stroke.Color = Color3.new(0, 0, 0)
			p26.stroke.Thickness = 2
			p26.shine.Visible = true
		else
			p26.block.BackgroundColor3 = v28
			p26.block.BackgroundTransparency = 0.82
			p26.stroke.Color = v28
			p26.stroke.Thickness = 2
			p26.shine.Visible = false
		end
	end
end
local function v_u_42(p30, p31, p32, p33, p34, p35, p36, p_u_37) -- name: touchButton
	-- upvalues: (copy) v_u_2
	local v38 = v_u_2.find("Frames.Leave.Redeem")
	if not v38 then
		return nil
	end
	local v39 = v_u_2.button(v38, p31, p32)
	v_u_2.paint(v39, p35, p36)
	v39.AnchorPoint = Vector2.new(0.5, 0.5)
	v39.Position = p33
	v39.Size = p34
	v39.Selectable = false
	v39.Parent = p30
	return v39.InputBegan:Connect(function(p_u_40)
		-- upvalues: (copy) p_u_37
		if p_u_40.UserInputType == Enum.UserInputType.Touch or p_u_40.UserInputType == Enum.UserInputType.MouseButton1 then
			p_u_37(true)
			local v_u_41 = nil
			v_u_41 = p_u_40:GetPropertyChangedSignal("UserInputState"):Connect(function()
				-- upvalues: (copy) p_u_40, (ref) v_u_41, (ref) p_u_37
				if p_u_40.UserInputState == Enum.UserInputState.End or p_u_40.UserInputState == Enum.UserInputState.Cancel then
					v_u_41:Disconnect()
					p_u_37(false)
				end
			end)
		end
	end)
end
function v7.new(p43, p44, p_u_45, p46, p47, p_u_48) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_25, (copy) v_u_29, (copy) v_u_8, (copy) v_u_3, (copy) v_u_10, (copy) v_u_9, (copy) v_u_11, (copy) v_u_42, (copy) v_u_12
	local v_u_49 = v_u_5.new(p43)
	local v_u_50 = v_u_49.w
	local v_u_51 = v_u_49.h - v_u_49.hidden
	local v_u_52 = v_u_49.hidden
	local v_u_53 = v_u_2.box(p44, "Board", v_u_2.BOARD, 0)
	v_u_53.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_53.Position = UDim2.fromScale(0.5, 0.5)
	v_u_53.Size = UDim2.fromScale(1, 1)
	local v54 = Instance.new("UIAspectRatioConstraint")
	v54.AspectRatio = v_u_50 / v_u_51
	v54.Parent = v_u_53
	local v55 = Instance.new("UIStroke")
	v55.Thickness = 4
	v55.Color = Color3.new(0, 0, 0)
	v55.Parent = v_u_53
	local v_u_56 = 0
	local v_u_57 = {}
	local v_u_58 = false
	local v_u_59 = {
		["left"] = false,
		["right"] = false
	}
	local v_u_60 = 0
	local v_u_61 = 0
	local v_u_62 = 0
	local v_u_63 = 0
	local v_u_64 = true
	local v_u_65 = {
		["left"] = 0,
		["right"] = 0
	}
	local v_u_66 = 0
	for v67 = 1, v_u_50 do
		if v67 % 2 ~= 0 then
			continue
		end
		local v68 = Instance.new("Frame")
		v68.Name = "Column"
		v68.BorderSizePixel = 0
		v68.BackgroundColor3 = Color3.fromRGB(34, 38, 64)
		v68.BackgroundTransparency = 0.45
		v68.Position = UDim2.fromScale((v67 - 1) / v_u_50, 0)
		v68.Size = UDim2.fromScale(1 / v_u_50, 1)
		v68.ZIndex = 2
		v68.Parent = v_u_53
	end
	local v_u_69 = {}
	local v_u_70 = {}
	for v71 = 1, v_u_51 do
		for v72 = 1, v_u_50 do
			local v73 = v_u_25(v_u_53, v72, v71, v_u_50, v_u_51, 4)
			table.insert(v_u_69, v73)
			table.insert(v_u_70, 0)
		end
	end
	local v_u_74 = v_u_2.box(p46, "Next", v_u_2.BOARD, 0.1)
	v_u_74.AnchorPoint = Vector2.new(0.5, 0)
	v_u_74.Position = UDim2.fromScale(0.5, 0.02)
	v_u_74.Size = UDim2.fromScale(0.8, 0.3)
	local v75 = Instance.new("UIAspectRatioConstraint")
	v75.AspectRatio = 1.15
	v75.Parent = v_u_74
	local v76 = Instance.new("UIStroke")
	v76.Thickness = 3
	v76.Parent = v_u_74
	v_u_2.label(v_u_74, "Title", "NEXT", UDim2.fromScale(0.9, 0.22), UDim2.fromScale(0.5, 0.14), v_u_2.WHITE, 2)
	local v77 = Instance.new("Frame")
	v77.Name = "Preview"
	v77.BackgroundTransparency = 1
	v77.AnchorPoint = Vector2.new(0.5, 0.5)
	v77.Position = UDim2.fromScale(0.5, 0.62)
	v77.Size = UDim2.fromScale(0.8, 0.6)
	local v78 = Instance.new("UIAspectRatioConstraint")
	v78.AspectRatio = 2
	v78.Parent = v77
	v77.Parent = v_u_74
	local v_u_79 = {}
	for v80 = 1, 2 do
		for v81 = 1, 4 do
			local v82 = v_u_25(v77, v81, v80, 4, 2, 4)
			table.insert(v_u_79, v82)
		end
	end
	local v83 = p47 and 0.36 or 0.4
	local v_u_84 = v_u_2.label(p46, "Lines", "LINES 0", UDim2.fromScale(0.95, 0.08), UDim2.fromScale(0.5, v83), v_u_2.WHITE, 2)
	local v_u_85 = v_u_2.label(p46, "Level", "LEVEL 1", UDim2.fromScale(0.95, 0.08), UDim2.fromScale(0.5, v83 + 0.09), v_u_2.CYAN, 2)
	local v_u_86 = v_u_2.label(p44, "Callout", "", UDim2.fromScale(1.4, 0.11), UDim2.fromScale(0.5, 0.3), v_u_2.GOLD, 3)
	v_u_86.ZIndex = 45
	local v_u_87 = (-1 / 0)
	local function v_u_96() -- name: showNext
		-- upvalues: (copy) v_u_49, (copy) v_u_79, (ref) v_u_5, (ref) v_u_29
		local v88 = v_u_49.queue[1]
		for _, v89 in v_u_79 do
			v89.block.Visible = false
		end
		if v88 then
			local v90 = v_u_5.cells(v88, 1)
			local v91 = 9
			for _, v92 in v90 do
				local v93 = v92[2]
				v91 = math.min(v91, v93)
			end
			for _, v94 in v90 do
				local v95 = v_u_79[(v94[2] - v91) * 4 + v94[1] + 1]
				if not v95 then
					continue
				end
				v_u_29(v95, v88)
			end
		end
	end
	v_u_96()
	local function v_u_111() -- name: paint
		-- upvalues: (copy) v_u_50, (copy) v_u_51, (copy) v_u_49, (copy) v_u_52, (ref) v_u_5, (copy) v_u_70, (ref) v_u_29, (copy) v_u_69, (ref) v_u_87, (copy) v_u_86
		local v97 = table.create(v_u_50 * v_u_51, 0)
		for v98 = 1, v_u_51 do
			for v99 = 1, v_u_50 do
				v97[(v98 - 1) * v_u_50 + v99] = v_u_49.cells[(v98 + v_u_52 - 1) * v_u_50 + v99]
			end
		end
		if not v_u_49.over then
			local v100 = v_u_49.piece
			local v101 = v_u_5.dropDistance(v_u_49)
			local v102 = v_u_5.cells(v100.kind, v100.rot)
			for _, v103 in v102 do
				local v104 = v100.x + v103[1]
				local v105 = v100.y + v103[2] + v101 - v_u_52
				if v105 < 1 or v97[(v105 - 1) * v_u_50 + v104] ~= 0 then
					continue
				end
				v97[(v105 - 1) * v_u_50 + v104] = -v100.kind
			end
			for _, v106 in v102 do
				local v107 = v100.x + v106[1]
				local v108 = v100.y + v106[2] - v_u_52
				if v108 < 1 then
					continue
				end
				v97[(v108 - 1) * v_u_50 + v107] = v100.kind
			end
		end
		for v109, v110 in v97 do
			if v_u_70[v109] == v110 then
				continue
			end
			v_u_70[v109] = v110
			v_u_29(v_u_69[v109], v110)
		end
		if os.clock() - v_u_87 > 1.4 and v_u_86.Text ~= "" then
			v_u_86.Text = ""
		end
	end
	local function v_u_117(p112) -- name: flashRow
		-- upvalues: (copy) v_u_52, (ref) v_u_2, (copy) v_u_51, (copy) v_u_53, (copy) v_u_50, (ref) v_u_8
		local v113 = p112 - v_u_52
		if v113 >= 1 then
			local v_u_114 = Instance.new("Frame")
			v_u_114.Name = "Flash"
			v_u_114.BorderSizePixel = 0
			v_u_114.BackgroundColor3 = v_u_2.WHITE
			v_u_114.BackgroundTransparency = 0.1
			v_u_114.Position = UDim2.fromScale(0, (v113 - 1) / v_u_51)
			v_u_114.Size = UDim2.fromScale(1, 1 / v_u_51)
			v_u_114.ZIndex = 30
			v_u_114.Parent = v_u_53
			v_u_2.tween(v_u_114, 0.35, {
				["BackgroundTransparency"] = 1,
				["Size"] = nil,
				["Size"] = UDim2.fromScale(1, 0)
			})
			task.delay(0.4, function()
				-- upvalues: (copy) v_u_114
				v_u_114:Destroy()
			end)
			local v115 = v_u_53.AbsoluteSize.X / v_u_50
			for v116 = 2, v_u_50, 3 do
				v_u_2.sparks(v_u_53, UDim2.fromScale((v116 - 0.5) / v_u_50, (v113 - 0.5) / v_u_51), v115, v_u_8[v116 % 7 + 1], 2)
			end
		end
	end
	local function v_u_137() -- name: onEvents
		-- upvalues: (copy) v_u_49, (ref) v_u_3, (ref) v_u_2, (copy) v_u_53, (copy) v_u_96, (copy) v_u_117, (copy) v_u_52, (ref) v_u_10, (copy) v_u_51, (copy) v_u_50, (ref) v_u_9, (copy) v_u_86, (ref) v_u_87, (ref) v_u_11, (copy) v_u_84, (copy) v_u_85, (ref) v_u_64
		for _, v118 in v_u_49.events do
			if v118.kind == "move" then
				v_u_3.play("RouletteTick", {
					["volume"] = 0.6
				})
			elseif v118.kind == "rotate" then
				v_u_3.play("RouletteTick", {
					["volume"] = 0.9,
					["pitch"] = 1.4
				})
			elseif v118.kind == "drop" then
				v_u_3.play("Hit", {
					["volume"] = 0.45
				})
				if v118.points <= 2 then
					continue
				end
				v_u_2.shake(v_u_53, 4, 0.15)
			elseif v118.kind == "lock" then
				v_u_3.play("Equip", {
					["volume"] = 0.35
				})
				v_u_96()
			elseif v118.kind == "clear" then
				local v119 = v118.count
				local v120 = math.min(v119, 4)
				for _, v121 in v118.rows do
					v_u_117(v121)
				end
				local v122 = 0
				for _, v123 in v118.rows do
					v122 = v122 + (v123 - v_u_52)
				end
				local v124 = #v118.rows
				local v125 = v122 / math.max(v124, 1)
				local v126 = v_u_2.float
				local v127 = v_u_53
				local v128 = "+" .. v118.points
				local v129 = v_u_10[v120]
				local v130 = UDim2.fromScale(0.5, (v125 - 0.5) / v_u_51)
				local v131 = v_u_53.AbsoluteSize.X / v_u_50 * 1.1
				v126(v127, v128, v129, v130, (math.max(18, v131)))
				if v118.combo >= 2 then
					local v132 = v_u_9[v120] .. "  COMBO x" .. v118.combo
					local v133 = v_u_10[v120]
					v_u_86.Text = v132
					v_u_86.TextColor3 = v133
					v_u_87 = os.clock()
					v_u_2.bump(v_u_86, 0.5)
				else
					local v134 = v_u_9[v120]
					local v135 = v_u_10[v120]
					v_u_86.Text = v134
					v_u_86.TextColor3 = v135
					v_u_87 = os.clock()
					v_u_2.bump(v_u_86, 0.5)
				end
				v_u_3.play(v_u_11[v120])
				if v120 >= 4 then
					v_u_2.shake(v_u_53, 10, 0.35)
				end
				v_u_84.Text = "LINES " .. v_u_49.lines
				v_u_2.bump(v_u_84, 0.3)
			elseif v118.kind == "level" then
				v_u_85.Text = "LEVEL " .. v_u_49.level
				v_u_2.bump(v_u_85, 0.5)
				v_u_3.play("LevelUp", {
					["volume"] = 0.8
				})
				task.delay(0.6, function()
					-- upvalues: (ref) v_u_64, (ref) v_u_2, (ref) v_u_86, (ref) v_u_87
					if v_u_64 then
						local v136 = v_u_2.CYAN
						v_u_86.Text = "SPEED UP!"
						v_u_86.TextColor3 = v136
						v_u_87 = os.clock()
						v_u_2.bump(v_u_86, 0.5)
					end
				end)
			else
				if v118.kind ~= "over" then
					continue
				end
				v_u_2.shake(v_u_53, 8, 0.35)
				v_u_3.play("Hurt")
			end
		end
		table.clear(v_u_49.events)
	end
	local function v_u_141(p138) -- name: act
		-- upvalues: (ref) v_u_64, (copy) p_u_48, (copy) v_u_49, (ref) v_u_5, (copy) v_u_57, (copy) v_u_137
		if v_u_64 and (p_u_48() and (not v_u_49.over and v_u_5.act(v_u_49, p138))) then
			local v139 = v_u_57
			local v140 = {
				["tick"] = v_u_49.tick,
				["action"] = p138
			}
			table.insert(v139, v140)
		end
		v_u_137()
	end
	local function v_u_146(p142, p143) -- name: press
		-- upvalues: (copy) v_u_59, (copy) v_u_65, (copy) v_u_141, (ref) v_u_5, (ref) v_u_58, (ref) v_u_66
		if p142 == "left" or p142 == "right" then
			v_u_59[p142] = p143
			if p143 then
				v_u_65[p142] = 0
				v_u_59[p142 == "left" and "right" or "left"] = false
				local v144 = v_u_141
				local v145
				if p142 == "left" then
					v145 = v_u_5.LEFT
				else
					v145 = v_u_5.RIGHT
				end
				v144(v145)
				return
			end
		elseif p142 == "down" then
			v_u_58 = p143
			if p143 then
				v_u_66 = 0
				v_u_141(v_u_5.SOFT)
				return
			end
		else
			if p143 and p142 == "rotate" then
				v_u_141(v_u_5.ROTATE)
				return
			end
			if p143 and p142 == "rotateBack" then
				v_u_141(v_u_5.ROTATE_BACK)
				return
			end
			if p143 and p142 == "drop" then
				v_u_141(v_u_5.HARD)
			end
		end
	end
	local v_u_147 = {}
	if p47 then
		local v_u_148 = Color3.fromRGB(80, 200, 255)
		local v_u_149 = Color3.fromRGB(40, 120, 255)
		local function v157(p150, p151, p152, p_u_153) -- name: move
			-- upvalues: (ref) v_u_42, (copy) p_u_45, (copy) v_u_148, (copy) v_u_149, (copy) v_u_146, (copy) v_u_147
			local v155 = v_u_42(p_u_45, p150, p151, p152, UDim2.fromScale(0.42, 0.2), v_u_148, v_u_149, function(p154)
				-- upvalues: (ref) v_u_146, (copy) p_u_153
				v_u_146(p_u_153, p154)
			end)
			if v155 then
				local v156 = v_u_147
				table.insert(v156, v155)
			end
		end
		v157("Left", "\226\151\128", UDim2.fromScale(0.27, 0.5), "left")
		v157("Right", "\226\150\182", UDim2.fromScale(0.73, 0.5), "right")
		v157("Down", "\226\150\188", UDim2.fromScale(0.5, 0.8), "down")
		for _, v160 in { v_u_42(p46, "Turn", "TURN", UDim2.fromScale(0.5, 0.68), UDim2.fromScale(0.85, 0.15), Color3.fromRGB(190, 110, 255), Color3.fromRGB(130, 50, 230), function(p158)
				-- upvalues: (copy) v_u_141, (ref) v_u_5
				if p158 then
					v_u_141(v_u_5.ROTATE)
				end
			end), (v_u_42(p46, "Drop", "DROP", UDim2.fromScale(0.5, 0.87), UDim2.fromScale(0.85, 0.15), Color3.fromRGB(255, 200, 40), Color3.fromRGB(255, 120, 0), function(p159)
				-- upvalues: (copy) v_u_141, (ref) v_u_5
				if p159 then
					v_u_141(v_u_5.HARD)
				end
			end)) } do
			if not v160 then
				continue
			end
			table.insert(v_u_147, v160)
		end
	end
	v_u_111()
	return {
		["score"] = function() -- name: score
			-- upvalues: (copy) v_u_49
			return v_u_49.score
		end,
		["over"] = function() -- name: over
			-- upvalues: (copy) v_u_49
			return v_u_49.over
		end,
		["reason"] = function() -- name: reason
			-- upvalues: (copy) v_u_49
			return v_u_49.reason
		end,
		["tick"] = function() -- name: tick
			-- upvalues: (copy) v_u_49
			return v_u_49.tick
		end,
		["left"] = function() -- name: left
			-- upvalues: (ref) v_u_5, (copy) v_u_49
			return v_u_5.left(v_u_49)
		end,
		["count"] = function() -- name: count
			-- upvalues: (copy) v_u_49
			return v_u_49.lines
		end,
		["inputs"] = v_u_57,
		["update"] = function(p161) -- name: update
			-- upvalues: (ref) v_u_64, (copy) v_u_49, (ref) v_u_62, (ref) v_u_12, (copy) v_u_59, (copy) v_u_65, (copy) v_u_141, (ref) v_u_5, (ref) v_u_58, (ref) v_u_66, (copy) v_u_137, (copy) v_u_111
			if v_u_64 then
				if not v_u_49.over then
					v_u_62 = v_u_62 + math.min(p161, 0.25)
					local v162 = 0
					while v_u_12 <= v_u_62 and (not v_u_49.over and v162 < 20) do
						v_u_62 = v_u_62 - v_u_12
						v162 = v162 + 1
						for _, v163 in { "left", "right" } do
							if not v_u_59[v163] then
								continue
							end
							local v164 = v_u_65
							v164[v163] = v164[v163] + 1
							local v165 = v_u_65[v163] - 10
							if v165 < 0 or v165 % 3 ~= 0 then
								continue
							end
							local v166 = v_u_141
							local v167
							if v163 == "left" then
								v167 = v_u_5.LEFT
							else
								v167 = v_u_5.RIGHT
							end
							v166(v167)
						end
						if v_u_58 then
							v_u_66 = v_u_66 + 1
							if v_u_66 % 2 == 0 then
								v_u_141(v_u_5.SOFT)
							end
						end
						if v_u_49.over then
							break
						end
						v_u_5.step(v_u_49)
						v_u_137()
					end
				end
				v_u_111()
			end
		end,
		["press"] = v_u_146,
		["auto"] = function() -- name: auto
			-- upvalues: (copy) v_u_49, (ref) v_u_60, (ref) v_u_63, (ref) v_u_61, (ref) v_u_56, (copy) v_u_50, (copy) v_u_141, (ref) v_u_5
			if v_u_49.over or os.clock() < v_u_60 then
				return
			else
				v_u_60 = os.clock() + 0.09
				if v_u_63 ~= v_u_49.pieces then
					v_u_63 = v_u_49.pieces
					v_u_61 = math.random(0, 3)
					v_u_56 = math.random(0, v_u_50 - 3)
				end
				if v_u_61 > 0 then
					v_u_61 = v_u_61 - 1
					v_u_141(v_u_5.ROTATE)
					return
				elseif v_u_49.piece.x < v_u_56 and v_u_5.fits(v_u_49, v_u_49.piece.kind, v_u_49.piece.rot, v_u_49.piece.x + 1, v_u_49.piece.y) then
					v_u_141(v_u_5.RIGHT)
					return
				elseif v_u_56 < v_u_49.piece.x and v_u_5.fits(v_u_49, v_u_49.piece.kind, v_u_49.piece.rot, v_u_49.piece.x - 1, v_u_49.piece.y) then
					v_u_141(v_u_5.LEFT)
				else
					v_u_141(v_u_5.HARD)
				end
			end
		end,
		["destroy"] = function() -- name: destroy
			-- upvalues: (ref) v_u_64, (copy) v_u_147, (copy) v_u_53, (copy) v_u_74, (copy) v_u_84, (copy) v_u_85, (copy) v_u_86
			v_u_64 = false
			for _, v168 in v_u_147 do
				v168:Disconnect()
			end
			v_u_53:Destroy()
			v_u_74:Destroy()
			v_u_84:Destroy()
			v_u_85:Destroy()
			v_u_86:Destroy()
		end
	}
end
return v7