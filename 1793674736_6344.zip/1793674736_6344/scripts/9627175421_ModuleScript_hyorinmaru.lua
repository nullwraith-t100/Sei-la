local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(70, 214, 255)
local v_u_6 = Color3.fromRGB(34, 112, 226)
local v_u_7 = Color3.fromRGB(196, 238, 255)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6, (copy) v_u_5, (copy) v_u_3
	return {
		["w6_hyorinmaru"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_4, (ref) v_u_1, (ref) v_u_7, (ref) v_u_6, (ref) v_u_5, (ref) v_u_3
			local v_u_11 = v_u_2.color(p10.color)
			local v_u_12 = v_u_2.color(p10.color2)
			local v13 = p_u_9.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_15 = v_u_14 * 3
			local v_u_16 = v_u_14 * 2.6
			local function v_u_43(p17, p18, p19) -- name: swim
				-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) p_u_9
				local v20 = p18 * 1.2
				local v21 = v_u_14 * 0.45
				local v22 = v_u_14 * 1.25
				local v23 = p18 * 0.62
				local v24 = v21 + v22 * math.sin(v23)
				local v25 = p17.Position
				local v26 = math.cos(v20) * v_u_15
				local v27 = math.sin(v20) * v_u_15
				local v28 = v25 + Vector3.new(v26, v24, v27)
				local v29
				if p18 < 2.5 then
					v29 = 0
				else
					local v30 = (p18 - 2.5) % 6
					if v30 < 0.55 then
						local v31 = v30 / 0.55
						local v32 = math.clamp(v31, 0, 1)
						v29 = v32 * v32 * (3 - v32 * 2)
					elseif v30 < 1.35 then
						v29 = 1
					elseif v30 < 1.9000000000000001 then
						local v33 = (1.9000000000000001 - v30) / 0.55
						local v34 = math.clamp(v33, 0, 1)
						v29 = v34 * v34 * (3 - v34 * 2)
					else
						v29 = 0
					end
				end
				if v29 <= 0 then
					return v28
				end
				local v35 = p17.LookVector
				local v36 = v35.X
				local v37 = v35.Z
				local v38 = Vector3.new(v36, 0, v37)
				local v39 = v38.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v38.Unit
				local v40 = v39:Cross(Vector3.new(0, 1, 0))
				local v41 = p17.Position + Vector3.new(0, 1, 0) * (p_u_9.headY + v_u_14 * 1.3 - v_u_14 * 0.42 * p19) - v39 * (v_u_14 * 1.3 + v_u_14 * 0.18 * p19)
				local v42 = p19 * 0.7
				return v28:Lerp(v41 + v40 * math.sin(v42) * 0.45 * v_u_14, v29)
			end
			local v_u_44 = {}
			local v_u_45 = CFrame.identity
			local v_u_46 = -1
			local v47 = p_u_9.ticks
			local function v77(p48, p49)
				-- upvalues: (copy) v_u_44, (copy) v_u_43, (ref) v_u_45, (ref) v_u_46, (copy) p_u_9, (ref) p_u_8, (copy) v_u_14, (copy) v_u_16, (ref) v_u_2, (copy) v_u_12, (copy) v_u_11, (ref) v_u_4
				for v50 = 0, 10 do
					v_u_44[v50 + 1] = v_u_43(p48, p49 - v50 * 0.22, v50)
				end
				local v51 = v_u_44[1]
				local v52 = v_u_43(p48, p49 + 0.04, 0) - v51
				local v53
				if v52.Magnitude > 0.001 then
					v53 = v52.Unit
				else
					local v54 = p48.LookVector
					local v55 = v54.X
					local v56 = v54.Z
					local v57 = Vector3.new(v55, 0, v56)
					v53 = v57.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v57.Unit
				end
				local v58
				if p49 < 2.5 then
					v58 = 0
				else
					local v59 = (p49 - 2.5) % 6
					if v59 < 0.55 then
						local v60 = v59 / 0.55
						local v61 = math.clamp(v60, 0, 1)
						v58 = v61 * v61 * (3 - v61 * 2)
					elseif v59 < 1.35 then
						v58 = 1
					elseif v59 < 1.9000000000000001 then
						local v62 = (1.9000000000000001 - v59) / 0.55
						local v63 = math.clamp(v62, 0, 1)
						v58 = v63 * v63 * (3 - v63 * 2)
					else
						v58 = 0
					end
				end
				if v58 > 0 then
					local v64 = p48.LookVector
					local v65 = v64.X
					local v66 = v64.Z
					local v67 = Vector3.new(v65, 0, v66)
					local v68 = v53:Lerp(((v67.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v67.Unit) - Vector3.new(0, 0.3, 0)).Unit, v58)
					if v68.Magnitude > 0.001 then
						v53 = v68.Unit
					else
						local v69 = p48.LookVector
						local v70 = v69.X
						local v71 = v69.Z
						local v72 = Vector3.new(v70, 0, v71)
						v53 = v72.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v72.Unit
					end
				end
				v_u_45 = CFrame.lookAt(v51, v51 + v53)
				if p49 >= 2.5 then
					local v73 = (p49 - 2.5) / 6
					local v74 = math.floor(v73)
					local v75 = (p49 - 2.5) % 6
					if v74 ~= v_u_46 and v75 >= 0.55 then
						v_u_46 = v74
						p_u_9.pulse = 1
						if (v51 - p_u_8.camPos()).Magnitude < 150 then
							local v76 = (v_u_45 * CFrame.new(0, v_u_14 * -0.2, -v_u_16 * 0.55)).Position
							v_u_2.burst("Impact", v76, v_u_12, 0.8 * p_u_9.fx)
							v_u_2.flash(v76, v_u_12, v_u_14 * 2.6, 0.3)
							v_u_2.ring(p_u_8.feetAt(p_u_9, p48, 0.15), v_u_11, 6.5 * p_u_9.fx, 0.6, v_u_4.Ring)
						end
					end
				end
			end
			table.insert(v47, v77)
			local v78 = p_u_9.ticks
			table.insert(v78, function(_, _, p79)
				-- upvalues: (copy) p_u_9
				local v80 = p_u_9
				local v81 = p_u_9.pulse - p79 * 1.5
				v80.pulse = math.max(v81, 0)
			end)
			local v82 = v_u_1:FindFirstChild("EyePieces")
			if v82 then
				v82 = v82:FindFirstChild("w6_hyorinmaru")
			end
			local v_u_83 = nil
			local v84
			if v82 and v82:IsA("MeshPart") then
				v84 = v82:Clone()
				v84.Anchored = true
				v84.CanCollide = false
				v84.CanQuery = false
				v84.CanTouch = false
				v84.CastShadow = false
				v84.Massless = true
				local v85 = v82.Size
				local v86 = v82.Size.Z
				v84.Size = v85 * (v_u_16 / math.max(v86, 0.01))
				local v87 = v84:FindFirstChildWhichIsA("SurfaceAppearance")
				if v87 then
					v_u_83 = v87
				else
					v84.Color = v_u_7
					v84.Material = Enum.Material.SmoothPlastic
					v84.Reflectance = 0.15
				end
				v84.Parent = v_u_2.folder()
			else
				local v88 = v_u_7
				local v89 = Enum.Material.SmoothPlastic
				v84 = Instance.new("WedgePart")
				v84.Anchored = true
				v84.CanCollide = false
				v84.CanQuery = false
				v84.CanTouch = false
				v84.CastShadow = false
				v84.Massless = true
				v84.Color = v88
				v84.Material = v89
				v84.Transparency = 0
				v84.Size = Vector3.new(0.1, 0.1, 0.1)
				v84.Parent = v_u_2.folder()
				local v90 = v_u_16 * 0.55
				local v91 = v_u_16 * 0.5
				v84.Size = Vector3.new(v90, v91, v_u_16)
				v84.Reflectance = 0.15
			end
			p_u_8.add(p_u_9, v84, function()
				-- upvalues: (ref) v_u_45
				return v_u_45
			end)
			if v_u_83 then
				local v_u_92 = v_u_83.EmissiveStrength
				local v_u_93 = -1
				local v94 = p_u_9.ticks
				local function v97()
					-- upvalues: (copy) p_u_9, (ref) v_u_93, (copy) v_u_83, (copy) v_u_92
					local v95 = p_u_9.pulse * 20
					local v96 = math.floor(v95) / 20
					if v96 ~= v_u_93 then
						v_u_93 = v96
						v_u_83.EmissiveStrength = v_u_92 * (v96 * 1.5 + 1)
					end
				end
				table.insert(v94, v97)
			end
			for v_u_98 = 1, 10 do
				local v99 = (v_u_98 - 1) / 10
				local v_u_100 = (1.2 - v99 * 0.7) * v_u_14
				local v101 = p_u_8.blob
				local v102 = v_u_100 * 0.82
				local v103 = v_u_100 * 1.5
				local v104 = v101(Vector3.new(v_u_100, v102, v103), v_u_6:Lerp(v_u_7, v99 * 0.85), 0, Enum.Material.SmoothPlastic)
				p_u_8.add(p_u_9, v104, function()
					-- upvalues: (copy) v_u_44, (copy) v_u_98
					local v105 = v_u_44[v_u_98 + 1] or Vector3.new(0, 0, 0)
					local v106 = v_u_44[v_u_98] or v105
					if (v106 - v105).Magnitude > 0.001 then
						return CFrame.lookAt(v105, v106)
					else
						return CFrame.new(v105)
					end
				end)
				v104.Reflectance = 0.18
				if v_u_98 < 10 then
					local v107
					if v_u_98 % 2 == 1 then
						v107 = v_u_12
					else
						v107 = v_u_5
					end
					local v108 = Enum.Material.Neon
					local v109 = Instance.new("WedgePart")
					v109.Anchored = true
					v109.CanCollide = false
					v109.CanQuery = false
					v109.CanTouch = false
					v109.CastShadow = false
					v109.Massless = true
					v109.Color = v107
					v109.Material = v108
					v109.Transparency = 0
					v109.Size = Vector3.new(0.1, 0.1, 0.1)
					v109.Parent = v_u_2.folder()
					local v110 = v_u_14 * 0.1
					local v111 = v_u_100 * 0.8
					local v112 = v_u_100 * 1.1
					v109.Size = Vector3.new(v110, v111, v112)
					p_u_8.add(p_u_9, v109, function()
						-- upvalues: (copy) v_u_44, (copy) v_u_98, (copy) v_u_100
						local v113 = v_u_44[v_u_98 + 1] or Vector3.new(0, 0, 0)
						local v114 = v_u_44[v_u_98] or v113
						local v115
						if (v114 - v113).Magnitude > 0.001 then
							v115 = CFrame.lookAt(v113, v114)
						else
							v115 = CFrame.new(v113)
						end
						return v115 * CFrame.new(0, v_u_100 * 0.55, v_u_100 * 0.25)
					end)
				end
				if v_u_98 ~= 10 then
					continue
				end
				p_u_8.tail(v104, v_u_12, v_u_11, v_u_14 * 0.5, 0.5)
			end
			local v_u_116 = {}
			for v_u_117 = 1, 6 do
				local v118
				if v_u_117 % 2 == 0 then
					v118 = v_u_12
				else
					v118 = v_u_5
				end
				local v119 = Enum.Material.Neon
				local v_u_120 = Instance.new("WedgePart")
				v_u_120.Anchored = true
				v_u_120.CanCollide = false
				v_u_120.CanQuery = false
				v_u_120.CanTouch = false
				v_u_120.CastShadow = false
				v_u_120.Massless = true
				v_u_120.Color = v118
				v_u_120.Material = v119
				v_u_120.Transparency = 0.1
				v_u_120.Size = Vector3.new(0.1, 0.1, 0.1)
				v_u_120.Parent = v_u_2.folder()
				v_u_116[v_u_117] = v_u_120
				p_u_8.add(p_u_9, v_u_120, function(p121, p122)
					-- upvalues: (copy) v_u_117, (copy) v_u_120, (ref) p_u_8, (copy) p_u_9, (copy) v_u_14
					local v123 = (v_u_117 - 1) * 3.141592653589793 * 2 / 6 + p122 * 0.25
					local v124 = math.cos(v123)
					local v125 = math.sin(v123)
					local v126 = Vector3.new(v124, 0, v125)
					local v127 = v_u_120.Size.Y
					local v128 = p_u_8.feetAt(p_u_9, p121, 0) + v126 * 1.55 * v_u_14
					local v129 = Vector3.new(0, 0.9393727, 0) + v126 * 0.34289780745545134
					return CFrame.fromMatrix(v128 + v129 * v127 / 2, v126:Cross(Vector3.new(0, 1, 0)), v129)
				end)
			end
			local v_u_130 = -1
			local v131 = p_u_9.ticks
			local function v139(_, p132)
				-- upvalues: (ref) v_u_130, (copy) p_u_9, (copy) v_u_116, (copy) v_u_14
				if p132 - v_u_130 >= 0.06666666666666667 then
					v_u_130 = p132
					local v133 = 1 + 0.9 * p_u_9.pulse
					for v134, v135 in v_u_116 do
						local v136 = (v134 * 7 % 3 * 0.3 / 2 + 0.75) * v_u_14 * v133
						local v137 = v_u_14 * 0.12
						local v138 = v_u_14 * 0.5
						v135.Size = Vector3.new(v137, v136, v138)
					end
				end
			end
			table.insert(v131, v139)
			local v140 = v_u_2.part
			local v141 = v_u_15 * 2
			local v142 = v_u_15 * 2
			local v143 = v140(Vector3.new(v141, 0.2, v142), CFrame.identity, v_u_11, {
				["transparency"] = 1
			})
			v143.Massless = true
			p_u_8.add(p_u_9, v143, function(p144)
				-- upvalues: (copy) p_u_9, (copy) v_u_14
				local v145 = CFrame.new
				local v146 = p144.Position
				local v147 = p_u_9.headY + v_u_14 * 1.2
				return v145(v146 + Vector3.new(0, v147, 0))
			end)
			local v_u_148 = Instance.new("ParticleEmitter")
			v_u_148.Texture = v_u_4.Snowflake
			v_u_148.Color = ColorSequence.new(v_u_12, v_u_11)
			v_u_148.LightEmission = 0.55
			v_u_148.LightInfluence = 0
			v_u_148.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.15, v_u_14 * 0.32 * p_u_9.fx), NumberSequenceKeypoint.new(1, v_u_14 * 0.1 * p_u_9.fx) })
			v_u_148.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.8, 0.2), NumberSequenceKeypoint.new(1, 1) })
			v_u_148.Lifetime = NumberRange.new(1.6, 2.4)
			v_u_148.Speed = NumberRange.new(0.5, 1.5)
			v_u_148.SpreadAngle = Vector2.new(180, 180)
			v_u_148.Acceleration = Vector3.new(0, -1.6, 0)
			v_u_148.Rotation = NumberRange.new(0, 360)
			v_u_148.RotSpeed = NumberRange.new(-60, 60)
			v_u_148.Shape = Enum.ParticleEmitterShape.Box
			v_u_148.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_148:SetAttribute("BaseRate", 5 * p_u_9.fx)
			v_u_148.Rate = 5 * p_u_9.fx * v_u_3.formRate()
			v_u_148.Parent = v143
			p_u_8.own(p_u_9, v143)
			local v149 = p_u_9.stops
			table.insert(v149, function()
				-- upvalues: (copy) v_u_148
				v_u_148.Enabled = false
			end)
			p_u_8.particles(p_u_9, "Petals", v_u_12, {
				["rate"] = 0.7,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
			p_u_8.particles(p_u_9, "AuraMode", v_u_11, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end