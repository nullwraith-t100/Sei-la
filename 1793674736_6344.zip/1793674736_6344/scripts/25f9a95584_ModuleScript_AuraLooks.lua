local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v2.Shared.Config.Textures)
local v6 = {}
local function v_u_8(p7) -- name: hex
	return Color3.fromHex(p7)
end
local function v_u_15(...) -- name: seq
	local v9 = { ... }
	local v10 = {}
	for v11 = 1, #v9, 2 do
		local v12 = NumberSequenceKeypoint.new
		local v13 = v9[v11]
		local v14 = v9[v11 + 1]
		table.insert(v10, v12(v13, v14))
	end
	return NumberSequence.new(v10)
end
local function v_u_25(p16, p17, p18, p19) -- name: emit
	local v20 = Instance.new("ParticleEmitter")
	v20.Name = p18
	v20.Texture = p19.texture
	local v21
	if p19.fixed then
		v21 = p19.rate
	else
		v21 = p19.rate * p16.rate
	end
	v20.Rate = v21
	v20.Lifetime = p19.life
	v20.Size = p19.size
	v20.Transparency = p19.transparency
	v20.Color = p19.color or ColorSequence.new(Color3.new(1, 1, 1))
	v20.Speed = p19.speed or NumberRange.new(0)
	v20.SpreadAngle = p19.spread or Vector2.zero
	v20.Acceleration = p19.accel or Vector3.new(0, 0, 0)
	v20.Drag = p19.drag or 0
	v20.Rotation = p19.rotation or NumberRange.new(0)
	v20.RotSpeed = p19.rotSpeed or NumberRange.new(0)
	v20.Orientation = p19.orientation or Enum.ParticleOrientation.FacingCamera
	v20.EmissionDirection = p19.direction or Enum.NormalId.Top
	v20.LightEmission = p19.glow or 0
	v20.LightInfluence = 0
	v20.Brightness = p19.brightness or 1
	v20.ZOffset = p19.zOffset or 0
	v20.LockedToPart = p19.locked == true
	if p19.squash then
		v20.Squash = p19.squash
	end
	if p19.grid then
		local v22
		if p19.grid == "2x2" then
			v22 = Enum.ParticleFlipbookLayout.Grid2x2
		else
			v22 = Enum.ParticleFlipbookLayout.Grid4x4
		end
		v20.FlipbookLayout = v22
		v20.FlipbookMode = p19.mode or Enum.ParticleFlipbookMode.OneShot
		local v23 = p19.fps
		if v23 then
			v20.FlipbookFramerate = NumberRange.new(v23)
		end
		v20.FlipbookStartRandom = v23 == 0 and true or v20.FlipbookMode == Enum.ParticleFlipbookMode.Loop
	end
	v20.Parent = p17
	local v24 = p16.emitters
	table.insert(v24, v20)
	return v20
end
local v_u_26 = CFrame.new
local v_u_27 = Enum.ParticleOrientation.VelocityPerpendicular
local v_u_28 = Enum.ParticleOrientation.FacingCameraWorldUp
local v_u_29 = Color3.fromHex("#3D9BFF")
local v_u_30 = Color3.fromHex("#A8DCFF")
local v_u_31 = Color3.fromHex("#2EE6C9")
local v_u_32 = Color3.fromHex("#9BFFF0")
local v_u_33 = NumberRange.new(10, 11.5)
local function v_u_39(p34, p35, p36) -- name: spin
	-- upvalues: (copy) v_u_4
	local v37 = v_u_4:Create(p35, TweenInfo.new(p36, Enum.EasingStyle.Linear, Enum.EasingDirection.In, -1), {
		["Orientation"] = Vector3.new(0, 360, 0)
	})
	v37:Play()
	local v38 = p34.tweens
	table.insert(v38, v37)
end
local v_u_40 = Color3.fromHex("#E0213A")
local v_u_41 = Color3.fromHex("#9A4CFF")
local v_u_42 = Color3.fromHex("#FF6A92")
local v_u_43 = NumberRange.new(12, 13.5)
local v_u_44 = Color3.fromHex("#FFC24A")
local v_u_45 = Color3.fromHex("#FF6A1F")
local v_u_46 = Color3.fromHex("#E8321A")
local v_u_47 = {
	{
		["y"] = -0.8,
		["r"] = 2.35,
		["tiltX"] = 13,
		["tiltZ"] = 5,
		["width"] = 2.1,
		["flow"] = 0.8,
		["way"] = 1
	},
	{
		["y"] = 0.9,
		["r"] = 1.95,
		["tiltX"] = -9,
		["tiltZ"] = -15,
		["width"] = 1.6,
		["flow"] = 1,
		["way"] = -1
	}
}
local function v_u_76(p48, p49, p50) -- name: fireRing
	-- upvalues: (copy) v_u_5
	local v51 = CFrame.new(0, p49.y, 0)
	local v52 = CFrame.Angles
	local v53 = p49.tiltX
	local v54 = math.rad(v53)
	local v55 = p49.tiltZ
	local v56 = v51 * v52(v54, 0, (math.rad(v55)))
	local v57 = v56.UpVector
	local v58 = {}
	for v59 = 0, 3 do
		local v60 = p49.way * v59 / 4 * 3.141592653589793 * 2
		local v61 = math.cos(v60) * p49.r
		local v62 = math.sin(v60) * p49.r
		local v63 = v56 * Vector3.new(v61, 0, v62)
		local v64 = -math.sin(v60)
		local v65 = math.cos(v60)
		local v66 = v56:VectorToWorldSpace(Vector3.new(v64, 0, v65) * p49.way)
		local v67 = "Fire" .. p50 .. "_" .. v59
		local v68 = CFrame.fromMatrix(v63, v66, v57)
		local v69 = Instance.new("Attachment")
		v69.Name = "AuraLook" .. v67
		v69.CFrame = v68
		v69.Parent = p48.root
		local v70 = p48.made
		table.insert(v70, v69)
		table.insert(v58, v69)
	end
	local v71 = p49.r * 0.5522847498307933
	for v72, v73 in v58 do
		local v74 = Instance.new("Beam")
		v74.Attachment0 = v73
		v74.Attachment1 = v58[v72 % 4 + 1]
		v74.CurveSize0 = v71
		v74.CurveSize1 = v71
		v74.Texture = v_u_5.AuraHinoRibbon
		v74.TextureMode = Enum.TextureMode.Wrap
		v74.TextureLength = p49.width * 2
		v74.TextureSpeed = p49.flow
		v74.Color = ColorSequence.new(Color3.new(1, 1, 1))
		v74.LightEmission = 0.3
		v74.LightInfluence = 0
		v74.Brightness = 1.4
		v74.FaceCamera = true
		v74.Segments = 10
		v74.Width0 = p49.width
		v74.Width1 = p49.width
		v74.Transparency = NumberSequence.new(0)
		v74.Parent = v73
		local v75 = p48.beams
		table.insert(v75, v74)
	end
end
local v_u_148 = {
	["almighty_shadow"] = function(p77) -- name: almightyShadow
		-- upvalues: (copy) v_u_26, (copy) v_u_25, (copy) v_u_5, (copy) v_u_15, (copy) v_u_27, (copy) v_u_8, (copy) v_u_29, (copy) v_u_28, (copy) v_u_30
		local v78 = p77.feet
		local v79 = v_u_26(0, v78 + 0.12, 0)
		local v80 = Instance.new("Attachment")
		v80.Name = "AuraLookGround"
		v80.CFrame = v79
		v80.Parent = p77.root
		local v81 = p77.made
		table.insert(v81, v80)
		v_u_25(p77, v80, "Pool", {
			["texture"] = nil,
			["rate"] = 0.75,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["orientation"] = nil,
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["locked"] = true,
			["texture"] = v_u_5.AuraShadowPool,
			["life"] = NumberRange.new(4, 4.6),
			["size"] = v_u_15(0, 7.2, 1, 9.6),
			["transparency"] = v_u_15(0, 1, 0.2, 0.06, 0.75, 0.06, 1, 1),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27,
			["rotation"] = NumberRange.new(0, 360),
			["rotSpeed"] = NumberRange.new(-16, 16)
		})
		v_u_25(p77, v80, "Pulse", {
			["texture"] = nil,
			["rate"] = 0.3,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["color"] = nil,
			["speed"] = nil,
			["orientation"] = nil,
			["rotation"] = nil,
			["grid"] = "4x4",
			["locked"] = true,
			["texture"] = v_u_5.KyubiRing,
			["life"] = NumberRange.new(1.1),
			["size"] = v_u_15(0, 3, 1, 15),
			["transparency"] = v_u_15(0, 0.15, 0.7, 0.4, 1, 1),
			["color"] = ColorSequence.new(v_u_8("#0A1636")),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27,
			["rotation"] = NumberRange.new(0, 360)
		})
		v_u_25(p77, v80, "Smoke", {
			["texture"] = nil,
			["rate"] = 9,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["spread"] = nil,
			["drag"] = 3,
			["accel"] = Vector3.new(0, 3.5, 0),
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["grid"] = "4x4",
			["texture"] = v_u_5.AuraShadowSmoke,
			["life"] = NumberRange.new(1.1, 1.5),
			["size"] = v_u_15(0, 1.8, 0.5, 3, 1, 3.8),
			["transparency"] = v_u_15(0, 0.1, 1, 0.25),
			["speed"] = NumberRange.new(7, 10),
			["spread"] = Vector2.new(82, 82),
			["rotation"] = NumberRange.new(-180, 180),
			["rotSpeed"] = NumberRange.new(-30, 30)
		})
		local v82 = {}
		local v83 = v78 + 0.5
		local v84 = Vector3.new(-1.6, v83, 0.4)
		local v85 = v78 + 0.5
		local v86 = Vector3.new(1.6, v85, 0.4)
		local v87 = v78 + 0.5
		__set_list(v82, 1, {v84, v86, (Vector3.new(0, v87, 1.5))})
		for v88, v89 in v82 do
			local v90 = v_u_25
			local v91 = "Flame" .. v88
			local v92 = v_u_26(v89.X, v89.Y, v89.Z)
			local v93 = Instance.new("Attachment")
			v93.Name = "AuraLook" .. v91
			v93.CFrame = v92
			v93.Parent = p77.root
			local v94 = p77.made
			table.insert(v94, v93)
			v90(p77, v93, "Flames", {
				["texture"] = nil,
				["rate"] = 6,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["color"] = nil,
				["brightness"] = 1.6,
				["speed"] = nil,
				["spread"] = nil,
				["accel"] = Vector3.new(0, 5, 0),
				["rotation"] = nil,
				["orientation"] = nil,
				["grid"] = "4x4",
				["texture"] = v_u_5.ShadowFlame,
				["life"] = NumberRange.new(0.7, 0.95),
				["size"] = v_u_15(0, 1.5, 0.4, 2.3, 1, 1.3),
				["transparency"] = v_u_15(0, 0.05, 0.85, 0.1, 1, 1),
				["color"] = ColorSequence.new(v_u_29),
				["speed"] = NumberRange.new(3, 6),
				["spread"] = Vector2.new(18, 18),
				["rotation"] = NumberRange.new(-12, 12),
				["orientation"] = v_u_28
			})
		end
		local v95 = p77.full and 4 or 2
		for v96 = 1, v95 do
			local v97 = v96 * 360 / v95 + 45
			local v98 = math.rad(v97)
			local v99 = v_u_25
			local v100 = "Tendril" .. v96
			local v101 = v_u_26(math.cos(v98) * 1.5, v78 + 1.1, math.sin(v98) * 1.5)
			local v102 = Instance.new("Attachment")
			v102.Name = "AuraLook" .. v100
			v102.CFrame = v101
			v102.Parent = p77.root
			local v103 = p77.made
			table.insert(v103, v102)
			v99(p77, v102, "Tendrils", {
				["texture"] = nil,
				["rate"] = 1.4,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["speed"] = nil,
				["spread"] = nil,
				["accel"] = Vector3.new(0, 2, 0),
				["rotation"] = nil,
				["orientation"] = nil,
				["squash"] = nil,
				["brightness"] = 1.2,
				["grid"] = "4x4",
				["mode"] = nil,
				["fps"] = 16,
				["texture"] = v_u_5.AuraShadowTendril,
				["life"] = NumberRange.new(1.2, 1.6),
				["size"] = v_u_15(0, 3.2, 0.5, 4.6, 1, 4.2),
				["transparency"] = v_u_15(0, 1, 0.15, 0.04, 0.7, 0.08, 1, 1),
				["speed"] = NumberRange.new(1.5, 3),
				["spread"] = Vector2.new(10, 10),
				["rotation"] = NumberRange.new(-14, 14),
				["orientation"] = v_u_28,
				["squash"] = v_u_15(0, 0.3, 1, 0.3),
				["mode"] = Enum.ParticleFlipbookMode.Loop
			})
		end
		local v104 = v_u_25
		local v105 = v_u_26(0, 0.5, 0)
		local v106 = Instance.new("Attachment")
		v106.Name = "AuraLookEyes"
		v106.CFrame = v105
		v106.Parent = p77.root
		local v107 = p77.made
		table.insert(v107, v106)
		v104(p77, v106, "Eyes", {
			["texture"] = nil,
			["rate"] = 1.5,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["brightness"] = 2.2,
			["speed"] = nil,
			["spread"] = nil,
			["drag"] = 4,
			["rotation"] = nil,
			["zOffset"] = 0.6,
			["locked"] = true,
			["grid"] = "4x4",
			["texture"] = v_u_5.AuraShadowEye,
			["life"] = NumberRange.new(1.5, 2),
			["size"] = NumberSequence.new(2.6),
			["transparency"] = NumberSequence.new(0),
			["speed"] = NumberRange.new(11, 14),
			["spread"] = Vector2.new(180, 180),
			["rotation"] = NumberRange.new(-8, 8)
		})
		if p77.full then
			v_u_25(p77, v80, "Motes", {
				["texture"] = nil,
				["rate"] = 7,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["color"] = nil,
				["glow"] = 1,
				["brightness"] = 2,
				["speed"] = nil,
				["spread"] = nil,
				["drag"] = 2.5,
				["accel"] = Vector3.new(0, 3, 0),
				["texture"] = v_u_5.Glow,
				["life"] = NumberRange.new(1.2, 1.8),
				["size"] = v_u_15(0, 0.4, 1, 0),
				["transparency"] = v_u_15(0, 0.1, 1, 0.6),
				["color"] = ColorSequence.new(v_u_29, v_u_30),
				["speed"] = NumberRange.new(4, 7),
				["spread"] = Vector2.new(60, 60)
			})
		end
	end,
	["hollow_hole"] = function(p_u_108) -- name: hollowHole
		-- upvalues: (copy) v_u_26, (copy) v_u_25, (copy) v_u_5, (copy) v_u_15, (copy) v_u_27, (copy) v_u_31, (copy) v_u_33, (copy) v_u_32, (copy) v_u_3, (copy) v_u_8
		local v109 = v_u_26(0, p_u_108.feet + 0.12, 0)
		local v110 = Instance.new("Attachment")
		v110.Name = "AuraLookGround"
		v110.CFrame = v109
		v110.Parent = p_u_108.root
		local v111 = p_u_108.made
		table.insert(v111, v110)
		local v_u_112 = v_u_25(p_u_108, v110, "Ring", {
			["texture"] = nil,
			["rate"] = 0,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["orientation"] = nil,
			["rotSpeed"] = nil,
			["locked"] = true,
			["texture"] = v_u_5.AuraHollowRing,
			["life"] = NumberRange.new(8),
			["size"] = NumberSequence.new(7.6),
			["transparency"] = v_u_15(0, 1, 0.06, 0, 0.88, 0, 1, 1),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27,
			["rotSpeed"] = NumberRange.new(18)
		})
		v_u_112.Enabled = false
		task.spawn(function()
			-- upvalues: (copy) p_u_108, (copy) v_u_112
			local v113 = os.clock()
			while p_u_108.alive and v_u_112.Parent do
				v_u_112.Rotation = NumberRange.new((os.clock() - v113) * 18 % 360)
				v_u_112:Emit(1)
				task.wait(7.04)
			end
		end)
		v_u_25(p_u_108, v110, "Cero", {
			["texture"] = nil,
			["rate"] = 1,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["color"] = nil,
			["glow"] = 1,
			["brightness"] = 1.5,
			["speed"] = nil,
			["orientation"] = nil,
			["locked"] = true,
			["texture"] = v_u_5.Glow,
			["life"] = NumberRange.new(2),
			["size"] = v_u_15(0, 4, 0.5, 4.8, 1, 4),
			["transparency"] = v_u_15(0, 1, 0.5, 0.5, 1, 1),
			["color"] = ColorSequence.new(v_u_31),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27
		})
		local v114 = v_u_26(0, -0.4, 0)
		local v_u_115 = Instance.new("Attachment")
		v_u_115.Name = "AuraLookOrbit"
		v_u_115.CFrame = v114
		v_u_115.Parent = p_u_108.root
		local v116 = p_u_108.made
		table.insert(v116, v_u_115)
		v_u_25(p_u_108, v_u_115, "Shards", {
			["texture"] = nil,
			["rate"] = 5,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["spread"] = nil,
			["direction"] = nil,
			["drag"] = 4,
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["locked"] = true,
			["grid"] = "2x2",
			["mode"] = nil,
			["fps"] = 0,
			["texture"] = v_u_5.AuraHollowShards,
			["life"] = NumberRange.new(2.4),
			["size"] = v_u_15(0, 0, 0.15, 0.95, 0.85, 0.95, 1, 0),
			["transparency"] = NumberSequence.new(0),
			["speed"] = v_u_33,
			["spread"] = Vector2.new(0, 180),
			["direction"] = Enum.NormalId.Right,
			["rotation"] = NumberRange.new(0, 360),
			["rotSpeed"] = NumberRange.new(-120, 120),
			["mode"] = Enum.ParticleFlipbookMode.Loop
		})
		v_u_25(p_u_108, v_u_115, "Glints", {
			["texture"] = nil,
			["rate"] = 4,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["color"] = nil,
			["glow"] = 0.6,
			["brightness"] = 2,
			["speed"] = nil,
			["spread"] = nil,
			["direction"] = nil,
			["drag"] = 4,
			["locked"] = true,
			["texture"] = v_u_5.Glow,
			["life"] = NumberRange.new(1.6),
			["size"] = v_u_15(0, 0, 0.2, 0.45, 1, 0),
			["transparency"] = v_u_15(0, 0.1, 1, 0.5),
			["color"] = ColorSequence.new(v_u_32, v_u_31),
			["speed"] = v_u_33,
			["spread"] = Vector2.new(0, 180),
			["direction"] = Enum.NormalId.Right
		})
		p_u_108.turning = v_u_3.Heartbeat:Connect(function()
			-- upvalues: (copy) v_u_115
			if v_u_115.Parent then
				v_u_115.CFrame = CFrame.new(0, -0.4, 0) * CFrame.Angles(0, os.clock() * 2.2, 0)
			end
		end)
		v_u_25(p_u_108, v110, "Chips", {
			["texture"] = nil,
			["rate"] = 3.5,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["spread"] = nil,
			["drag"] = 2,
			["accel"] = Vector3.new(0, 2, 0),
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["grid"] = "2x2",
			["mode"] = nil,
			["fps"] = 0,
			["texture"] = v_u_5.AuraHollowShards,
			["life"] = NumberRange.new(1.4, 2),
			["size"] = v_u_15(0, 0.55, 0.8, 0.6, 1, 0),
			["transparency"] = NumberSequence.new(0),
			["speed"] = NumberRange.new(4, 7),
			["spread"] = Vector2.new(55, 55),
			["rotation"] = NumberRange.new(0, 360),
			["rotSpeed"] = NumberRange.new(-160, 160),
			["mode"] = Enum.ParticleFlipbookMode.Loop
		})
		v_u_25(p_u_108, v110, "Void", {
			["texture"] = nil,
			["rate"] = 7,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["color"] = nil,
			["speed"] = nil,
			["spread"] = nil,
			["drag"] = 3,
			["accel"] = Vector3.new(0, 4, 0),
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["grid"] = "4x4",
			["mode"] = nil,
			["fps"] = 0,
			["texture"] = v_u_5.FxSmoke,
			["life"] = NumberRange.new(1.2, 1.8),
			["size"] = v_u_15(0, 1.4, 1, 3.2),
			["transparency"] = v_u_15(0, 0.3, 1, 1),
			["color"] = ColorSequence.new(v_u_8("#0A0A12")),
			["speed"] = NumberRange.new(5, 7),
			["spread"] = Vector2.new(80, 80),
			["rotation"] = NumberRange.new(-180, 180),
			["rotSpeed"] = NumberRange.new(-20, 20),
			["mode"] = Enum.ParticleFlipbookMode.Loop
		})
		if p_u_108.full then
			v_u_25(p_u_108, v110, "Motes", {
				["texture"] = nil,
				["rate"] = 6,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["color"] = nil,
				["glow"] = 0.6,
				["brightness"] = 2,
				["speed"] = nil,
				["spread"] = nil,
				["drag"] = 2.5,
				["accel"] = Vector3.new(0, 3, 0),
				["texture"] = v_u_5.Glow,
				["life"] = NumberRange.new(1.2, 1.8),
				["size"] = v_u_15(0, 0.35, 1, 0),
				["transparency"] = v_u_15(0, 0.1, 1, 0.6),
				["color"] = ColorSequence.new(v_u_31, v_u_32),
				["speed"] = NumberRange.new(4, 7),
				["spread"] = Vector2.new(60, 60)
			})
		end
	end,
	["upper_moon"] = function(p117) -- name: upperMoon
		-- upvalues: (copy) v_u_26, (copy) v_u_25, (copy) v_u_5, (copy) v_u_15, (copy) v_u_27, (copy) v_u_43, (copy) v_u_39, (copy) v_u_42, (copy) v_u_40, (copy) v_u_41
		local v118 = p117.feet
		local v119 = v_u_26(0, v118 + 0.12, 0)
		local v120 = Instance.new("Attachment")
		v120.Name = "AuraLookGround"
		v120.CFrame = v119
		v120.Parent = p117.root
		local v121 = p117.made
		table.insert(v121, v120)
		v_u_25(p117, v120, "Floor", {
			["texture"] = nil,
			["rate"] = 0.6,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["brightness"] = 1.3,
			["speed"] = nil,
			["orientation"] = nil,
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["locked"] = true,
			["texture"] = v_u_5.AuraMoonFloor,
			["life"] = NumberRange.new(4.2, 5),
			["size"] = v_u_15(0, 5.6, 1, 7.6),
			["transparency"] = v_u_15(0, 1, 0.25, 0.4, 0.75, 0.4, 1, 1),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27,
			["rotation"] = NumberRange.new(0, 360),
			["rotSpeed"] = NumberRange.new(-14, 14)
		})
		local v122 = v_u_25
		local v123 = v_u_26(0, v118 + 0.7, 0)
		local v124 = Instance.new("Attachment")
		v124.Name = "AuraLookRoll"
		v124.CFrame = v123
		v124.Parent = p117.root
		local v125 = p117.made
		table.insert(v125, v124)
		v122(p117, v124, "Mist", {
			["texture"] = nil,
			["rate"] = 7,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["brightness"] = 1.7,
			["speed"] = nil,
			["spread"] = nil,
			["direction"] = nil,
			["drag"] = 2.5,
			["accel"] = Vector3.new(0, 0.8, 0),
			["rotation"] = nil,
			["grid"] = "4x4",
			["texture"] = v_u_5.AuraMoonMist,
			["life"] = NumberRange.new(1.4, 1.9),
			["size"] = v_u_15(0, 1.8, 0.5, 3.2, 1, 4),
			["transparency"] = v_u_15(0, 0.25, 0.7, 0.4, 1, 1),
			["speed"] = NumberRange.new(6, 8),
			["spread"] = Vector2.new(0, 180),
			["direction"] = Enum.NormalId.Right,
			["rotation"] = NumberRange.new(-10, 10)
		})
		local v126 = p117.full and 3 or 2
		for v127 = 1, v126 do
			local v128 = v127 * 360 / v126 + 90
			local v129 = math.rad(v128)
			local v130 = v_u_25
			local v131 = "Wisp" .. v127
			local v132 = v_u_26(math.cos(v129) * 1.7, v118 + 0.6, math.sin(v129) * 1.7)
			local v133 = Instance.new("Attachment")
			v133.Name = "AuraLook" .. v131
			v133.CFrame = v132
			v133.Parent = p117.root
			local v134 = p117.made
			table.insert(v134, v133)
			v130(p117, v133, "Wisps", {
				["texture"] = nil,
				["rate"] = 2.2,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["brightness"] = 1.8,
				["speed"] = nil,
				["spread"] = nil,
				["accel"] = Vector3.new(0, 2.5, 0),
				["rotation"] = nil,
				["rotSpeed"] = nil,
				["grid"] = "4x4",
				["texture"] = v_u_5.AuraMoonMist,
				["life"] = NumberRange.new(1.3, 1.7),
				["size"] = v_u_15(0, 1, 0.5, 1.8, 1, 2.3),
				["transparency"] = v_u_15(0, 0.25, 0.6, 0.35, 1, 1),
				["speed"] = NumberRange.new(2.5, 4),
				["spread"] = Vector2.new(14, 14),
				["rotation"] = NumberRange.new(-20, 20),
				["rotSpeed"] = NumberRange.new(-15, 15)
			})
		end
		local v135 = v_u_26(0, 0.8, 0)
		local v136 = Instance.new("Attachment")
		v136.Name = "AuraLookEyeRing"
		v136.CFrame = v135
		v136.Parent = p117.root
		local v137 = p117.made
		table.insert(v137, v136)
		v_u_25(p117, v136, "Eyes", {
			["texture"] = nil,
			["rate"] = 2.8,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["brightness"] = 1.4,
			["speed"] = nil,
			["spread"] = nil,
			["direction"] = nil,
			["drag"] = 4,
			["rotation"] = nil,
			["zOffset"] = 0.3,
			["locked"] = true,
			["grid"] = "4x4",
			["texture"] = v_u_5.AuraMoonEye,
			["life"] = NumberRange.new(2.6, 3.2),
			["size"] = v_u_15(0, 0, 0.12, 1.5, 1, 1.5),
			["transparency"] = NumberSequence.new(0),
			["speed"] = v_u_43,
			["spread"] = Vector2.new(0, 180),
			["direction"] = Enum.NormalId.Right,
			["rotation"] = NumberRange.new(-6, 6)
		})
		v_u_39(p117, v136, 24)
		if p117.full then
			v_u_25(p117, v120, "Motes", {
				["texture"] = nil,
				["rate"] = 6,
				["life"] = nil,
				["size"] = nil,
				["transparency"] = nil,
				["color"] = nil,
				["glow"] = 0.7,
				["brightness"] = 2,
				["speed"] = nil,
				["spread"] = nil,
				["drag"] = 2.5,
				["accel"] = Vector3.new(0, 3, 0),
				["texture"] = v_u_5.Glow,
				["life"] = NumberRange.new(1.3, 1.9),
				["size"] = v_u_15(0, 0.4, 1, 0),
				["transparency"] = v_u_15(0, 0.1, 1, 0.6),
				["color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_42), ColorSequenceKeypoint.new(0.5, v_u_40), ColorSequenceKeypoint.new(1, v_u_41) }),
				["speed"] = NumberRange.new(4, 7),
				["spread"] = Vector2.new(60, 60)
			})
		end
	end,
	["hinokami"] = function(p138) -- name: hinokami
		-- upvalues: (copy) v_u_26, (copy) v_u_25, (copy) v_u_5, (copy) v_u_15, (copy) v_u_27, (copy) v_u_47, (copy) v_u_76, (copy) v_u_28, (copy) v_u_44, (copy) v_u_45, (copy) v_u_46
		local v139 = v_u_26(0, p138.feet + 0.12, 0)
		local v140 = Instance.new("Attachment")
		v140.Name = "AuraLookGround"
		v140.CFrame = v139
		v140.Parent = p138.root
		local v141 = p138.made
		table.insert(v141, v140)
		v_u_25(p138, v140, "Sun", {
			["texture"] = nil,
			["rate"] = 0.5,
			["fixed"] = true,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["speed"] = nil,
			["orientation"] = nil,
			["rotation"] = nil,
			["rotSpeed"] = nil,
			["glow"] = 0.5,
			["brightness"] = 1.5,
			["locked"] = true,
			["texture"] = v_u_5.AuraHinoFloor,
			["life"] = NumberRange.new(4.5),
			["size"] = v_u_15(0, 7.2, 1, 8.4),
			["transparency"] = v_u_15(0, 1, 0.25, 0.1, 0.75, 0.1, 1, 1),
			["speed"] = NumberRange.new(0.01),
			["orientation"] = v_u_27,
			["rotation"] = NumberRange.new(0, 360),
			["rotSpeed"] = NumberRange.new(28, 34)
		})
		for v142, v143 in v_u_47 do
			if v142 ~= 1 and not p138.full then
				continue
			end
			v_u_76(p138, v143, v142)
		end
		local v144 = v_u_25
		local v145 = v_u_26(0, v_u_47[1].y, 0)
		local v146 = Instance.new("Attachment")
		v146.Name = "AuraLookFlames"
		v146.CFrame = v145
		v146.Parent = p138.root
		local v147 = p138.made
		table.insert(v147, v146)
		v144(p138, v146, "Flames", {
			["texture"] = nil,
			["rate"] = 10,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["glow"] = 0.25,
			["brightness"] = 1.5,
			["speed"] = nil,
			["spread"] = nil,
			["direction"] = nil,
			["drag"] = 4,
			["accel"] = Vector3.new(0, 7, 0),
			["rotation"] = nil,
			["orientation"] = nil,
			["grid"] = "4x4",
			["texture"] = v_u_5.AuraHinoFlame,
			["life"] = NumberRange.new(0.8, 1.1),
			["size"] = v_u_15(0, 0, 0.2, 2, 1, 1.3),
			["transparency"] = NumberSequence.new(0),
			["speed"] = NumberRange.new(9, 10.5),
			["spread"] = Vector2.new(0, 180),
			["direction"] = Enum.NormalId.Right,
			["rotation"] = NumberRange.new(-8, 8),
			["orientation"] = v_u_28
		})
		v_u_25(p138, v140, "Embers", {
			["texture"] = nil,
			["rate"] = nil,
			["life"] = nil,
			["size"] = nil,
			["transparency"] = nil,
			["color"] = nil,
			["glow"] = 1,
			["brightness"] = 2.5,
			["speed"] = nil,
			["spread"] = nil,
			["drag"] = 1.5,
			["accel"] = Vector3.new(0, 4, 0),
			["texture"] = v_u_5.Glow,
			["rate"] = p138.full and 14 or 6,
			["life"] = NumberRange.new(1.4, 2.2),
			["size"] = v_u_15(0, 0.45, 1, 0),
			["transparency"] = v_u_15(0, 0, 1, 0.5),
			["color"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_44), ColorSequenceKeypoint.new(0.5, v_u_45), ColorSequenceKeypoint.new(1, v_u_46) }),
			["speed"] = NumberRange.new(4, 7),
			["spread"] = Vector2.new(50, 50)
		})
	end
}
function v6.has(p149) -- name: has
	-- upvalues: (copy) v_u_148
	return v_u_148[p149] ~= nil
end
function v6.start(p150, p151, p152, p153) -- name: start
	-- upvalues: (copy) v_u_148, (copy) v_u_1
	local v154 = v_u_148[p150]
	if not (v154 and p151:IsA("BasePart")) then
		return nil
	end
	local v155 = p151.Parent
	if v155 then
		v155 = p151.Parent:FindFirstChildOfClass("Humanoid")
	end
	local v_u_156 = {
		["root"] = nil,
		["feet"] = nil,
		["rate"] = nil,
		["full"] = nil,
		["made"] = nil,
		["emitters"] = nil,
		["alive"] = true,
		["turning"] = nil,
		["tweens"] = nil,
		["beams"] = nil,
		["root"] = p151,
		["feet"] = (not v155 or v155.RigType ~= Enum.HumanoidRigType.R15) and -3 or -(p151.Size.Y / 2 + v155.HipHeight),
		["rate"] = p152,
		["full"] = p153,
		["made"] = {},
		["emitters"] = {},
		["tweens"] = {},
		["beams"] = {}
	}
	v154(v_u_156)
	return function()
		-- upvalues: (copy) v_u_156, (ref) v_u_1
		if v_u_156.alive then
			v_u_156.alive = false
			if v_u_156.turning then
				v_u_156.turning:Disconnect()
			end
			for _, v157 in v_u_156.tweens do
				v157:Cancel()
			end
			for _, v158 in v_u_156.beams do
				v158.Enabled = false
			end
			for _, v159 in v_u_156.emitters do
				v159.Enabled = false
				if not v159.LockedToPart then
					continue
				end
				v159:Clear()
			end
			for _, v160 in v_u_156.made do
				v_u_1:AddItem(v160, 2.5)
			end
		end
	end
end
return v6