local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("E8102A")
local v_u_8 = Color3.fromRGB(10, 8, 10)
local v_u_9 = Color3.fromRGB(110, 0, 18)
local v_u_10 = Color3.fromRGB(255, 110, 120)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Ball
local v_u_13 = Enum.PartType.Cylinder
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_27(p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_31(p28, p29) -- name: setAlpha
	for _, v30 in p28:GetChildren() do
		if not v30:IsA("Decal") then
			continue
		end
		v30.Transparency = p29
	end
end
return function(p_u_32)
	-- upvalues: (copy) v_u_27, (copy) v_u_6, (copy) v_u_1, (copy) v_u_31, (copy) v_u_3, (copy) v_u_4, (copy) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_14, (copy) v_u_12, (copy) v_u_9, (copy) v_u_15, (copy) v_u_13, (copy) v_u_11, (copy) v_u_5
	local function v_u_47(p_u_33, p_u_34, p_u_35, p36, p_u_37, p_u_38) -- name: swirl
		-- upvalues: (ref) v_u_27, (ref) v_u_6, (ref) v_u_1, (copy) p_u_32, (ref) v_u_31
		local v_u_39 = v_u_27(p_u_33, p_u_34, v_u_6.CrimsonGalaxy, p36, 0)
		v_u_1:AddItem(v_u_39, p_u_37 + 0.1)
		p_u_32.animate(p_u_37, 0, function(p40)
			-- upvalues: (copy) v_u_39, (copy) p_u_34, (copy) p_u_35, (copy) p_u_33, (copy) p_u_37, (copy) p_u_38, (ref) v_u_31
			local v41 = 1 - (1 - p40) ^ 3
			local v42 = v_u_39
			local v43 = p_u_34 + (p_u_35 - p_u_34) * v41
			local v44 = math.max(v43, 0.05)
			local v45 = v44 * 2
			local v46 = v44 * 2
			v42.Size = Vector3.new(v45, 0.05, v46)
			v_u_39.CFrame = p_u_33 * CFrame.Angles(0, -p40 * p_u_37 * p_u_38, 0)
			v_u_31(v_u_39, p40 ^ 1.8)
			if p40 >= 1 then
				v_u_39:Destroy()
			end
		end)
	end
	local function v_u_68(p48, p49, p_u_50) -- name: cut
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (copy) p_u_32, (ref) v_u_1
		local v51 = v_u_3.CurrentCamera
		local v52
		if v51 then
			local v53 = v51.CFrame.Position - p48
			v52 = v53.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v53.Unit
		else
			v52 = Vector3.new(0, 0, 1)
		end
		local v54 = CFrame.lookAt(p48, p48 + v52)
		local v55 = CFrame.Angles
		local v56 = 35 + math.random() * 30
		local v57 = v54 * v55(0, 0, (math.rad(v56)))
		local v58 = v_u_4.part
		local v59 = p49 * 0.2
		local v_u_60 = v58(Vector3.new(0.35, v59, 0.1), v57, v_u_10)
		v_u_4.tween(v_u_60, p_u_50 * 0.35, {
			["Size"] = Vector3.new(0.35, p49, 0.1)
		})
		local v61 = v_u_4.part
		local v62 = p49 * 0.2
		local v_u_63 = v61(Vector3.new(0.9, v62, 0.08), v57, v_u_7, {
			["transparency"] = 0.45
		})
		local v64 = v_u_4.tween
		local v65 = p_u_50 * 0.35
		local v66 = {}
		local v67 = p49 * 1.05
		v66.Size = Vector3.new(0.9, v67, 0.08)
		v64(v_u_63, v65, v66)
		p_u_32.after(p_u_50 * 0.35, function()
			-- upvalues: (ref) p_u_32, (copy) v_u_60, (copy) p_u_50, (copy) v_u_63
			p_u_32.thin(v_u_60, p_u_50 * 0.65)
			p_u_32.thin(v_u_63, p_u_50 * 0.65)
		end)
		v_u_1:AddItem(v_u_60, p_u_50 + 0.1)
		v_u_1:AddItem(v_u_63, p_u_50 + 0.1)
	end
	local function v96(p69, p70) -- name: drillShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_14, (ref) v_u_10, (ref) v_u_12, (ref) v_u_27, (ref) v_u_6, (copy) p_u_32, (ref) v_u_9, (ref) v_u_1
		local v_u_71 = p69.size
		local v_u_72 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p70, v_u_7, {
			["transparency"] = 1
		})
		local v73 = {
			["material"] = v_u_14
		}
		local v_u_74 = v_u_4.part(Vector3.new(0.34, 0.34, 2.6) * v_u_71, p70, v_u_8, v73)
		local v_u_75 = v_u_4.part(Vector3.new(0.85, 0.85, 2.9) * v_u_71, p70, v_u_7, {
			["transparency"] = 0.55
		})
		local v76 = {
			["shape"] = v_u_12
		}
		local v_u_77 = v_u_4.part(Vector3.new(0.62, 0.62, 0.62) * v_u_71, p70, v_u_10, v76)
		local v_u_78 = v_u_27(p70, 1.15 * v_u_71, v_u_6.CrimsonGalaxy, v_u_7, 0)
		p_u_32.streak(v_u_72, v_u_7, v_u_8, 0.55 * v_u_71, 0.1)
		local v_u_79 = p69.lite and 2 or 3
		local v_u_80 = {}
		local v_u_81 = {
			v_u_74,
			v_u_75,
			v_u_77,
			v_u_78
		}
		for _ = 1, v_u_79 do
			local v82 = {
				["shape"] = v_u_12
			}
			local v83 = v_u_4.part(Vector3.new(0.42, 0.42, 0.42) * v_u_71, p70, v_u_7, v82)
			p_u_32.streak(v83, v_u_7, v_u_9, 0.32 * v_u_71, 0.18)
			v_u_1:AddItem(v83, 3)
			table.insert(v_u_80, v83)
		end
		if p69.mine then
			p_u_32.light(v_u_72, v_u_7, 8 * v_u_71)
		end
		for _, v84 in v_u_81 do
			v_u_1:AddItem(v84, 3)
		end
		v_u_1:AddItem(v_u_72, 3)
		local v_u_85 = false
		return {
			["place"] = function(p86, p87) -- name: place
				-- upvalues: (copy) v_u_72, (copy) v_u_74, (copy) v_u_75, (copy) v_u_77, (copy) v_u_71, (copy) v_u_80, (copy) v_u_79, (copy) v_u_78, (ref) p_u_32
				v_u_72.CFrame = p86
				local v88 = p86 * CFrame.Angles(0, 0, p87 * 28)
				v_u_74.CFrame = v88
				v_u_75.CFrame = v88
				v_u_77.CFrame = p86 * CFrame.new(0, 0, -1.4 * v_u_71)
				for v89, v90 in v_u_80 do
					local v91 = p87 * 30 + v89 * 3.141592653589793 * 2 / v_u_79
					v90.CFrame = p86 * CFrame.new(math.cos(v91) * 0.85 * v_u_71, math.sin(v91) * 0.85 * v_u_71, (v89 - 1) * 0.3 * v_u_71)
				end
				local v92 = -p86.LookVector
				v_u_78.CFrame = p_u_32.facing(p86.Position + v92 * 1.3 * v_u_71, v92) * CFrame.Angles(0, -p87 * 22, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_85, (copy) v_u_72, (ref) v_u_1, (copy) v_u_81, (copy) v_u_80
				if not v_u_85 then
					v_u_85 = true
					local v93 = v_u_72:FindFirstChildWhichIsA("PointLight")
					if v93 then
						v93:Destroy()
					end
					v_u_1:AddItem(v_u_72, 0.3)
					for _, v94 in v_u_81 do
						v94:Destroy()
					end
					for _, v95 in v_u_80 do
						v95.Transparency = 1
						v_u_1:AddItem(v95, 0.25)
					end
				end
			end
		}
	end
	local function v111(p97, p98) -- name: drillImpact
		-- upvalues: (ref) v_u_3, (copy) p_u_32, (ref) v_u_27, (ref) v_u_6, (ref) v_u_7, (ref) v_u_1, (ref) v_u_31, (ref) v_u_8, (ref) v_u_14, (ref) v_u_4, (ref) v_u_10
		local v_u_99 = p97.size
		local v100 = v_u_3.CurrentCamera
		local v101
		if v100 then
			local v102 = v100.CFrame.Position - p98
			v101 = v102.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v102.Unit
		else
			v101 = Vector3.new(0, 0, 1)
		end
		local v_u_103 = p_u_32.facing(p98 + v101 * 0.6, v101)
		local v_u_104 = v_u_27(v_u_103, 2.8 * v_u_99, v_u_6.CrimsonGalaxy, v_u_7, 0)
		v_u_1:AddItem(v_u_104, 0.4)
		p_u_32.animate(0.28, 0, function(p105)
			-- upvalues: (copy) v_u_104, (copy) v_u_99, (copy) v_u_103, (ref) v_u_31
			local v106 = v_u_104
			local v107 = (2.8 - 2.4 * p105 ^ 0.7) * v_u_99
			local v108 = math.max(v107, 0.05)
			local v109 = v108 * 2
			local v110 = v108 * 2
			v106.Size = Vector3.new(v109, 0.05, v110)
			v_u_104.CFrame = v_u_103 * CFrame.Angles(0, -p105 * 16, 0)
			v_u_31(v_u_104, p105 ^ 2)
			if p105 >= 1 then
				v_u_104:Destroy()
			end
		end)
		p_u_32.pop(p98, v_u_7, 1 * v_u_99, 3.8 * v_u_99, 0.15, 0.3)
		p_u_32.pop(p98, v_u_8, 1.8 * v_u_99, 0.2 * v_u_99, 0.2, 0, v_u_14)
		v_u_4.ring(p_u_32.ground(p98), v_u_7, p97.ability.radius * v_u_99, 0.25, v_u_6.Ring)
		p_u_32.burst("Impact", p98, v_u_7, 0.8 * v_u_99)
		if not p97.lite then
			p_u_32.spikes(p98, v_u_7, 6, 4 * v_u_99, 0.16, nil, nil, true)
			p_u_32.spikes(p98, v_u_10, 3, 2.6 * v_u_99, 0.12)
		end
		p_u_32.hitSound(p98)
	end
	local function v_u_158(p112) -- name: sweep
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_12, (ref) v_u_14, (ref) v_u_7, (ref) v_u_1, (ref) v_u_10, (copy) p_u_32, (ref) v_u_3, (copy) v_u_47
		local v_u_113 = p112.size
		local v114 = p112.lite
		local v_u_115 = 18 * v_u_113
		local v_u_116 = p112.feet + Vector3.new(0, 2.2, 0) + p112.dir * 1.5
		local v117 = {
			["shape"] = v_u_12,
			["material"] = v_u_14
		}
		local v_u_118 = v_u_4.part(Vector3.new(1.4, 1.4, 1.4) * v_u_113, CFrame.new(v_u_116), v_u_8, v117)
		local v119 = {
			["shape"] = nil,
			["transparency"] = 0.5,
			["shape"] = v_u_12
		}
		local v_u_120 = v_u_4.part(Vector3.new(2.3, 2.3, 2.3) * v_u_113, CFrame.new(v_u_116), v_u_7, v119)
		v_u_1:AddItem(v_u_118, 0.65)
		v_u_1:AddItem(v_u_120, 0.65)
		local v_u_121 = v114 and 5 or 8
		local v_u_122 = {}
		for _, v123 in { 0, 1 } do
			local v124 = {}
			for v125 = 1, v_u_121 do
				local v126 = v125 / v_u_121
				local v127 = v_u_4.part
				local v128 = Vector3.new(1, 1, 1) * (v126 * 0.75 + 0.45) * v_u_113
				local v129 = CFrame.new(v_u_116)
				local v130
				if v125 % 3 == 0 then
					v130 = v_u_10
				else
					v130 = v_u_7
				end
				local v131 = v127(v128, v129, v130, {
					["shape"] = v_u_12
				})
				v_u_1:AddItem(v131, 0.9500000000000001)
				table.insert(v124, v131)
			end
			p_u_32.streak(v124[v_u_121], v_u_7, v_u_8, 1.4 * v_u_113, 0.28)
			table.insert(v_u_122, {
				["stars"] = v124,
				["side"] = v123
			})
		end
		local v132 = p112.dir.Z
		local v133 = p112.dir.X
		local v_u_134 = math.atan2(v132, v133) - 1.3
		p_u_32.animate(0.55, 0, function(p135)
			-- upvalues: (copy) v_u_113, (copy) v_u_115, (copy) v_u_134, (copy) v_u_122, (copy) v_u_121, (copy) v_u_116, (copy) v_u_118, (copy) v_u_120
			local v136 = p135 / 0.75
			local v137 = 1 - (1 - math.min(v136, 1)) ^ 2.5
			local v138 = 1.5 * v_u_113 + v_u_115 * v137
			local v139 = v_u_134 + p135 * 2.6
			local v140 = (p135 - 0.6) / 0.4
			local v141 = math.clamp(v140, 0, 1)
			for _, v142 in v_u_122 do
				for v143, v144 in v142.stars do
					local v145 = v143 / v_u_121
					local v146 = v139 + v142.side * 3.141592653589793 + (1 - v145) * 1.9
					local v147 = CFrame.new
					local v148 = v_u_116
					local v149 = math.cos(v146)
					local v150 = v145 * 6
					local v151 = math.sin(v150) * 0.08
					local v152 = math.sin(v146)
					v144.CFrame = v147(v148 + Vector3.new(v149, v151, v152) * v138 * v145)
					v144.Transparency = v141
				end
			end
			v_u_118.Transparency = v141
			v_u_120.Transparency = v141 * 0.5 + 0.5
			if p135 >= 1 then
				for _, v153 in v_u_122 do
					for _, v154 in v153.stars do
						v154.Transparency = 1
					end
				end
				v_u_118:Destroy()
				v_u_120:Destroy()
			end
		end)
		local v155 = v_u_3.CurrentCamera
		local v156
		if v155 then
			local v157 = v155.CFrame.Position - v_u_116
			v156 = v157.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v157.Unit
		else
			v156 = Vector3.new(0, 0, 1)
		end
		v_u_47(p_u_32.facing(v_u_116 + v156 * 0.5, v156), 1.5 * v_u_113, 5 * v_u_113, v_u_7, 0.3, 14)
		v_u_4.flash(v_u_116, v_u_7, 5 * v_u_113, 0.18)
	end
	local function v181(p159, p160) -- name: armShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_27, (ref) v_u_6, (ref) v_u_8, (ref) v_u_12, (ref) v_u_14, (copy) p_u_32, (ref) v_u_9, (ref) v_u_1, (ref) v_u_3
		local v161 = p159.size
		local v_u_162 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p160, v_u_7, {
			["transparency"] = 1
		})
		local v_u_163 = v_u_27(p160, 1.8 * v161, v_u_6.CrimsonGalaxy, v_u_7, 0)
		local v164 = {
			["shape"] = v_u_12,
			["material"] = v_u_14
		}
		local v_u_165 = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * v161, p160, v_u_8, v164)
		local v166 = {
			["shape"] = nil,
			["transparency"] = 0.45,
			["shape"] = v_u_12
		}
		local v_u_167 = v_u_4.part(Vector3.new(1.2, 1.2, 1.2) * v161, p160, v_u_7, v166)
		local v_u_168 = { v_u_163, v_u_165, v_u_167 }
		p_u_32.streak(v_u_162, v_u_7, v_u_9, 1.1 * v161, 0.16)
		if p159.mine then
			p_u_32.light(v_u_162, v_u_7, 8 * v161)
		end
		for _, v169 in v_u_168 do
			v_u_1:AddItem(v169, 3)
		end
		v_u_1:AddItem(v_u_162, 3)
		local v_u_170 = false
		return {
			["place"] = function(p171, p172) -- name: place
				-- upvalues: (copy) v_u_162, (copy) v_u_165, (copy) v_u_167, (ref) p_u_32, (ref) v_u_3, (copy) v_u_163
				local v173 = p171.Position
				v_u_162.CFrame = p171
				v_u_165.CFrame = p171
				v_u_167.CFrame = p171
				local v174 = p_u_32.flatUnit
				local v175 = v_u_3.CurrentCamera
				local v176
				if v175 then
					local v177 = v175.CFrame.Position - v173
					v176 = v177.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v177.Unit
				else
					v176 = Vector3.new(0, 0, 1)
				end
				local v178 = v174(v176) * 0.55
				v_u_163.CFrame = p_u_32.facing(v173, (Vector3.new(0, 1, 0) + v178).Unit) * CFrame.Angles(0, -p172 * 24, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_170, (copy) v_u_162, (ref) v_u_1, (copy) v_u_168
				if not v_u_170 then
					v_u_170 = true
					local v179 = v_u_162:FindFirstChildWhichIsA("PointLight")
					if v179 then
						v179:Destroy()
					end
					v_u_1:AddItem(v_u_162, 0.3)
					for _, v180 in v_u_168 do
						v180:Destroy()
					end
				end
			end
		}
	end
	local function v188(p182, p183) -- name: armImpact
		-- upvalues: (copy) v_u_68, (copy) p_u_32, (ref) v_u_7, (ref) v_u_3, (copy) v_u_47, (ref) v_u_4, (ref) v_u_6, (ref) v_u_10
		local v184 = p182.size
		v_u_68(p183, 6 * v184, 0.3)
		p_u_32.burst("Slash", p183, v_u_7, 1.1 * v184)
		local v185 = v_u_3.CurrentCamera
		local v186
		if v185 then
			local v187 = v185.CFrame.Position - p183
			v186 = v187.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v187.Unit
		else
			v186 = Vector3.new(0, 0, 1)
		end
		v_u_47(p_u_32.facing(p183 + v186 * 0.5, v186), 1.5 * v184, 4.5 * v184, v_u_7, 0.25, 18)
		p_u_32.pop(p183, v_u_7, 1 * v184, 4.2 * v184, 0.16, 0.35)
		v_u_4.ring(p_u_32.ground(p183), v_u_7, 4 * v184, 0.25, v_u_6.Ring)
		if not p182.lite then
			p_u_32.spikes(p183, v_u_10, 4, 3.5 * v184, 0.14, nil, nil, true)
		end
		p_u_32.hitSound(p183)
	end
	local v_u_189 = {}
	setmetatable(v_u_189, {
		["__mode"] = "k"
	})
	local v328 = {
		["crimson_vortex_a"] = {
			["cast"] = function(p190) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_32, (ref) v_u_10, (copy) v_u_47
				local v191 = p190.size
				local v192 = p190.eye + p190.dir * 1.2
				v_u_4.flash(v192, v_u_7, 3 * v191, 0.1)
				p_u_32.pop(v192, v_u_10, 1.1 * v191, 0.3 * v191, 0.1)
				if not p190.lite then
					v_u_47(p_u_32.facing(v192, -p190.dir), 0.5 * v191, 1.6 * v191, v_u_7, 0.12, 30)
				end
			end,
			["shot"] = v96,
			["impact"] = v111,
			["hit"] = function(_, p193, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_7
				p_u_32.burst("Impact", p193, v_u_7, 0.6)
			end
		},
		["crimson_vortex_e"] = {
			["cast"] = function(p194) -- name: cast
				-- upvalues: (copy) p_u_32, (ref) v_u_7, (copy) v_u_158
				p_u_32.skillCast(p194, v_u_7)
				v_u_158(p194)
			end,
			["shot"] = v181,
			["impact"] = v188,
			["hit"] = function(p195, p196, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_7, (ref) v_u_10
				p_u_32.burst("Impact", p196, v_u_7, 0.7)
				if not p195.lite then
					p_u_32.glint(p196, v_u_10, 3, 0.14)
				end
			end
		},
		["crimson_vortex_r"] = {
			["cast"] = nil,
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p197) -- name: cast
				-- upvalues: (copy) p_u_32, (ref) v_u_7, (copy) v_u_47, (ref) v_u_4
				p_u_32.skillCast(p197, v_u_7, true)
				local v198 = p197.size
				local v199 = p197.eye + p197.dir * 1.5
				v_u_47(p_u_32.facing(v199, -p197.dir), 1.2 * v198, 4.6 * v198, v_u_7, 0.34, 16)
				if p197.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p200, p201, p202) -- name: windup
				-- upvalues: (copy) p_u_32, (ref) v_u_7, (ref) v_u_8, (ref) v_u_14, (ref) v_u_4
				local v203 = p200.size
				local v204 = p200.ability.radius * v203
				local v205 = p_u_32.ground(p201, 1.6)
				p_u_32.inward(v205, v_u_7, p200.lite and 6 or 12, v204 * 1.1, math.max(p202, 0.15) + 0.08)
				p_u_32.pop(v205, v_u_8, 0.5, 3.2 * v203, math.max(p202, 0.12), 0.1, v_u_14)
				v_u_4.flash(v205, v_u_7, 6 * v203, math.max(p202, 0.12) + 0.08)
			end,
			["zone"] = function(p206, p207, p_u_208) -- name: galaxy
				-- upvalues: (copy) p_u_32, (copy) v_u_189, (ref) v_u_4, (ref) v_u_15, (ref) v_u_8, (ref) v_u_13, (ref) v_u_14, (ref) v_u_27, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_12, (ref) v_u_1, (copy) v_u_68, (ref) v_u_9
				local v_u_209 = p206.size
				local v_u_210 = p206.lite
				local v_u_211 = p206.ability.radius * v_u_209
				local v_u_212 = p_u_32.ground(p207, 0)
				local v_u_213 = p_u_208 + 0.6
				local v_u_214 = {
					["done"] = false,
					["closing"] = 0
				}
				v_u_189[p206] = v_u_214
				local v215 = {
					["shape"] = nil,
					["material"] = nil,
					["transparency"] = 0.3,
					["shape"] = v_u_13,
					["material"] = v_u_14
				}
				local v_u_216 = v_u_4.part(Vector3.new(0.12, 2, 2), CFrame.new(v_u_212 + Vector3.new(0, 0.12, 0)) * v_u_15, v_u_8, v215)
				local v_u_217 = v_u_27(CFrame.new(v_u_212 + Vector3.new(0, 0.45, 0)), 1, v_u_6.CrimsonGalaxy, v_u_7, 0.05)
				local v_u_218 = v_u_27(CFrame.new(v_u_212 + Vector3.new(0, 0.6, 0)), 1, v_u_6.CrimsonGalaxy, v_u_10, 0.3)
				local v_u_219 = v_u_27(CFrame.new(v_u_212 + Vector3.new(0, 0.35, 0)), 1, v_u_6.Glow, v_u_7, 0.35)
				local v220 = {
					["shape"] = v_u_12,
					["material"] = v_u_14
				}
				local v_u_221 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_212 + Vector3.new(0, 1.6, 0)), v_u_8, v220)
				local v222 = {
					["shape"] = nil,
					["transparency"] = 0.45,
					["shape"] = v_u_12
				}
				local v_u_223 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_212 + Vector3.new(0, 1.6, 0)), v_u_7, v222)
				local v_u_224 = v_u_27(CFrame.new(v_u_212 + Vector3.new(0, 0.8, 0)), 1, v_u_6.Ring, v_u_7, 0)
				local v_u_225 = {
					v_u_216,
					v_u_217,
					v_u_218,
					v_u_219,
					v_u_221,
					v_u_223,
					v_u_224
				}
				for _, v226 in v_u_225 do
					v_u_1:AddItem(v226, v_u_213)
				end
				local v_u_227 = v_u_210 and 2 or 4
				local v228 = v_u_210 and 3 or 4
				local v_u_229 = {}
				for v230 = 1, v_u_227 do
					for v231 = 1, v228 do
						local v232 = v231 / v228
						local v233 = v_u_4.part
						local v234 = 0.7 * v_u_209
						local v235 = v233(Vector3.new(v234, 0.22, 1), CFrame.new(v_u_212), v_u_7)
						local v236 = v_u_4.part
						local v237 = 0.22 * v_u_209
						local v238 = v236(Vector3.new(v237, 0.3, 1), CFrame.new(v_u_212), v_u_10)
						v_u_1:AddItem(v235, v_u_213)
						v_u_1:AddItem(v238, v_u_213)
						table.insert(v_u_229, {
							["body"] = v235,
							["edge"] = v238,
							["arm"] = v230,
							["u"] = v232
						})
					end
				end
				local v_u_239 = v_u_210 and function() end or p_u_32.loopAt("Vortex", v_u_212 + Vector3.new(0, 1.6, 0), v_u_7, 1.2 * v_u_209)
				local v_u_240 = os.clock()
				local v_u_241 = v_u_240
				local v_u_242 = math.random() * 3.141592653589793 * 2
				local v_u_243 = 0.35
				p_u_32.runNow(function()
					-- upvalues: (ref) v_u_241, (copy) v_u_240, (copy) v_u_213, (copy) v_u_216, (copy) p_u_208, (ref) v_u_242, (copy) v_u_214, (copy) v_u_225, (copy) v_u_229, (copy) v_u_211, (copy) v_u_217, (copy) v_u_212, (copy) v_u_218, (copy) v_u_219, (copy) v_u_221, (copy) v_u_209, (copy) v_u_223, (copy) v_u_224, (copy) v_u_227, (ref) v_u_243, (copy) v_u_210, (ref) p_u_32, (ref) v_u_7, (ref) v_u_68, (ref) v_u_9, (ref) v_u_4, (ref) v_u_6
					local v244 = os.clock()
					local v245 = v244 - v_u_241
					local v246 = math.min(v245, 0.05)
					v_u_241 = v244
					local v247 = v244 - v_u_240
					if v_u_213 <= v247 or not v_u_216.Parent then
						return false
					end
					local v248 = v247 / p_u_208
					v_u_242 = v_u_242 + v246 * (math.clamp(v248, 0, 1) ^ 1.6 * 11 + 1.2)
					local v249 = v247 / 0.3
					local v250 = 1 - (1 - math.min(v249, 1)) ^ 3
					local v251
					if v_u_214.done then
						if v_u_214.closing >= 1 then
							for _, v252 in v_u_225 do
								v252:Destroy()
							end
							for _, v253 in v_u_229 do
								v253.body:Destroy()
								v253.edge:Destroy()
							end
							return false
						end
						local v254 = v_u_214
						local v255 = v_u_214.closing + v246 / 0.12
						v254.closing = math.min(v255, 1)
						v251 = 1 - v_u_214.closing * 0.45
					else
						v251 = 1
					end
					local v256 = v_u_211 * v250 * v251
					local v257 = v_u_216
					local v258 = v256 * 2.05
					local v259 = v256 * 2.05
					v257.Size = Vector3.new(0.12, v258, v259)
					v_u_216.Transparency = v_u_214.closing * 0.7 + 0.3
					local v260 = v_u_217
					local v261 = v256 * 1.05
					local v262 = math.max(v261, 0.05)
					local v263 = v262 * 2
					local v264 = v262 * 2
					v260.Size = Vector3.new(v263, 0.05, v264)
					v_u_217.CFrame = CFrame.new(v_u_212 + Vector3.new(0, 0.45, 0)) * CFrame.Angles(0, -v_u_242, 0)
					local v265 = v_u_218
					local v266 = v256 * 0.62
					local v267 = math.max(v266, 0.05)
					local v268 = v267 * 2
					local v269 = v267 * 2
					v265.Size = Vector3.new(v268, 0.05, v269)
					v_u_218.CFrame = CFrame.new(v_u_212 + Vector3.new(0, 0.6, 0)) * CFrame.Angles(0, -v_u_242 * 1.6, 0)
					local v270 = v_u_219
					local v271 = v256 * 0.7
					local v272 = math.max(v271, 0.05)
					local v273 = v272 * 2
					local v274 = v272 * 2
					v270.Size = Vector3.new(v273, 0.05, v274)
					local v275 = v247 * 18
					local v276 = math.sin(v275) * 0.08 + 1
					v_u_221.Size = Vector3.new(3.2, 3.2, 3.2) * v_u_209 * v250 * v276
					v_u_223.Size = Vector3.new(4.6, 4.6, 4.6) * v_u_209 * v250 * v276
					local v277 = v_u_224
					local v278 = 3.4 * v_u_209 * v250
					local v279 = math.max(v278, 0.05)
					local v280 = v279 * 2
					local v281 = v279 * 2
					v277.Size = Vector3.new(v280, 0.05, v281)
					v_u_224.CFrame = CFrame.new(v_u_212 + Vector3.new(0, 0.8, 0)) * CFrame.Angles(0, v_u_242 * 2, 0)
					for _, v282 in v_u_229 do
						local v283 = v_u_242 + (v282.arm - 1) * 3.141592653589793 * 2 / v_u_227 + (1 - v282.u) * 2.6
						local v284 = v256 * (v282.u * 0.78 + 0.2)
						local v285 = v_u_212 + Vector3.new(0, 1.1, 0)
						local v286 = math.cos(v283)
						local v287 = math.sin(v283)
						local v288 = v285 + Vector3.new(v286, 0, v287) * v284
						local v289 = math.cos(v283)
						local v290 = math.sin(v283)
						local v291 = Vector3.new(v289, 0, v290) * v256 * 0.78
						local v292 = -math.sin(v283)
						local v293 = math.cos(v283)
						local v294 = v291 + Vector3.new(v292, 0, v293) * v284 * -2.6
						local v295 = CFrame.lookAt(v288, v288 + v294) * CFrame.Angles(0, 0.35, 0)
						local v296 = (v282.u * 3.6 + 1.6) * v_u_209 * v250
						local v297 = v282.body
						local v298 = 0.7 * v_u_209
						v297.Size = Vector3.new(v298, 0.22, v296)
						v282.body.CFrame = v295
						local v299 = v282.edge
						local v300 = 0.22 * v_u_209
						local v301 = v296 * 1.08
						v299.Size = Vector3.new(v300, 0.3, v301)
						v282.edge.CFrame = v295 * CFrame.new(0.35 * v_u_209, 0, 0)
						v282.body.Transparency = v_u_214.closing
						v282.edge.Transparency = v_u_214.closing
					end
					if v_u_243 <= v247 and not v_u_214.done then
						v_u_243 = v247 + 0.4
						for v302 = 1, v_u_210 and 1 or 2 do
							local v303 = v_u_242 + (v302 * 2 - 1) * 3.141592653589793 * 2 / v_u_227 + math.random() * 0.8
							local v304 = v256 * (0.35 + 0.55 * math.random())
							local v305 = v_u_212 + Vector3.new(0, 1.4, 0)
							local v306 = math.cos(v303)
							local v307 = math.sin(v303)
							local v308 = v305 + Vector3.new(v306, 0, v307) * v304
							p_u_32.burst("Slash", v308, v_u_7, 1.3 * v_u_209)
							v_u_68(v308, 5 * v_u_209, 0.3)
							if v_u_210 then
								continue
							end
							local v309 = -math.sin(v303)
							local v310 = math.cos(v303)
							local v311 = Vector3.new(v309, 0, v310) * 3 * v_u_209
							p_u_32.groundLine(v308 - v311, v308 + v311, 0.6 * v_u_209, v_u_9, 1, 0.2)
						end
						v_u_4.ring(v_u_212, v_u_7, v256 * 0.9, 0.35, v_u_6.Ring)
					end
					return true
				end)
				if p206.mine then
					v_u_4.shake(0.2, 0.25)
				end
				return function()
					-- upvalues: (copy) v_u_214, (ref) v_u_239
					v_u_214.done = true
					v_u_239()
				end
			end,
			["finish"] = function(p312, p313) -- name: coreFlash
				-- upvalues: (copy) p_u_32, (copy) v_u_189, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10, (ref) v_u_6, (ref) v_u_27, (ref) v_u_1, (ref) v_u_31, (ref) v_u_8, (ref) v_u_5
				local v314 = p312.size
				local v315 = p312.lite
				local v_u_316 = p312.ability.radius * v314
				local v_u_317 = p_u_32.ground(p313, 0)
				local v318 = v_u_317 + Vector3.new(0, 1.6, 0)
				v_u_189[p312] = nil
				v_u_4.flash(v318, v_u_11, v_u_316 * 0.9, 0.18)
				v_u_4.flash(v318, v_u_7, v_u_316 * 1.6, 0.35)
				p_u_32.pop(v318, v_u_10, 3 * v314, v_u_316 * 0.9, 0.3, 0.1)
				p_u_32.pop(v_u_317, v_u_7, v_u_316 * 0.6, v_u_316 * 2.2, 0.5, 0.45)
				v_u_4.ring(v_u_317, v_u_7, v_u_316 * 1.3, 0.5, v_u_6.Shockwave)
				v_u_4.ring(v_u_317, v_u_10, v_u_316 * 1.6, 0.6, v_u_6.Ring)
				p_u_32.burst("Explosion", v318, v_u_7, 2.2)
				p_u_32.burst("Flash", v318, v_u_7, 0.7, true)
				p_u_32.burst("Shockwave", v_u_317 + Vector3.new(0, 0.3, 0), v_u_7, v_u_316 / 14)
				p_u_32.spikes(v318, v_u_7, v315 and 6 or 16, v_u_316 * 1.3, 0.35, nil, nil, true)
				p_u_32.spikes(v318, v_u_10, v315 and 3 or 8, v_u_316 * 0.9, 0.3)
				local v_u_319 = v_u_27(CFrame.new(v_u_317 + Vector3.new(0, 0.5, 0)), v_u_316, v_u_6.CrimsonGalaxy, v_u_7, 0)
				v_u_1:AddItem(v_u_319, 0.5)
				p_u_32.animate(0.42, 0, function(p320)
					-- upvalues: (copy) v_u_319, (copy) v_u_316, (copy) v_u_317, (ref) v_u_31
					local v321 = v_u_319
					local v322 = v_u_316 * (1 + 0.7 * (1 - (1 - p320) ^ 2))
					local v323 = v322 * 2
					local v324 = v322 * 2
					v321.Size = Vector3.new(v323, 0.05, v324)
					v_u_319.CFrame = CFrame.new(v_u_317 + Vector3.new(0, 0.5, 0)) * CFrame.Angles(0, -p320 * 6, 0)
					v_u_31(v_u_319, p320 ^ 1.4)
					if p320 >= 1 then
						v_u_319:Destroy()
					end
				end)
				if not v315 then
					local v325 = { v_u_7, v_u_10, v_u_8 }
					p_u_32.chunks(v318, v325, 10, 40, 0.8 * v314, 1.1, true, 0.6)
				end
				v_u_5.play("Explosion", {
					["at"] = v318,
					["volume"] = p312.mine and 1 or 0.6
				})
				if p312.mine then
					v_u_4.shake(0.55, 0.5)
				end
			end,
			["hit"] = function(p326, p327, _) -- name: hit
				-- upvalues: (copy) p_u_32, (ref) v_u_7, (ref) v_u_10
				p_u_32.burst("Impact", p327, v_u_7, 0.9)
				if not p326.lite then
					p_u_32.glint(p327, v_u_10, 3, 0.14)
				end
			end
		}
	}
	return v328
end