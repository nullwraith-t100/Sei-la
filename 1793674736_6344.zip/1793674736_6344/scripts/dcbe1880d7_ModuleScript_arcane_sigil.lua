local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("B57BFF")
local v_u_9 = Color3.fromHex("F0E2FF")
local v_u_10 = Color3.fromRGB(110, 40, 225)
local v_u_11 = Color3.fromRGB(22, 8, 38)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.PartType.Wedge
local v_u_14 = CFrame.Angles(0.7853981633974483, 0.6154030942532006, 0)
local function v_u_26(p15, p16, p17, p18, p19) -- name: card
	-- upvalues: (copy) v_u_5
	local v20 = v_u_5.part
	local v21 = p16 * 2
	local v22 = p16 * 2
	local v23 = v20(Vector3.new(v21, 0.05, v22), p15, p18, {
		["transparency"] = 1
	})
	for _, v24 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v25 = Instance.new("Decal")
		v25.Face = v24
		v25.Texture = p17
		v25.Color3 = p18
		v25.Transparency = p19
		v25.Parent = v23
	end
	return v23
end
local function v_u_33(p27, p28, p29) -- name: panel
	-- upvalues: (copy) v_u_5
	local v30 = v_u_5.part(Vector3.new(1, 1, 0.05), CFrame.identity, p28, {
		["transparency"] = 1
	})
	for _, v31 in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local v32 = Instance.new("Decal")
		v32.Face = v31
		v32.Texture = p27
		v32.Color3 = p28
		v32.Transparency = p29
		v32.Parent = v30
	end
	return v30
end
local function v_u_37(p34, p35) -- name: fadeDecals
	for _, v36 in p34:GetChildren() do
		if not v36:IsA("Decal") then
			continue
		end
		v36.Transparency = p35
	end
end
local function v_u_43(p38, p39, p40) -- name: triangle
	local v41 = p38 / 2
	local v42 = Vector3.new(p40, p39, v41)
	return { v42, v42 }, { CFrame.new(p38 / 4, p39 / 2, 0) * CFrame.Angles(0, -1.5707963267948966, 0), CFrame.new(-p38 / 4, p39 / 2, 0) * CFrame.Angles(0, 1.5707963267948966, 0) }
end
local function v_u_50(p44, p45, p46) -- name: pointing
	local v47 = p45.Magnitude <= 0.0001 and Vector3.new(0, 1, 0) or p45.Unit
	local v48 = p46 - v47 * p46:Dot(v47)
	if v48.Magnitude < 0.001 then
		local v49 = v47.Y
		v48 = math.abs(v49) >= 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0) - v47 * v47.Y
	end
	return CFrame.fromMatrix(p44, v47:Cross(v48.Unit), v47)
end
return function(p_u_51)
	-- upvalues: (copy) v_u_26, (copy) v_u_1, (copy) v_u_37, (copy) v_u_5, (copy) v_u_14, (copy) v_u_9, (copy) v_u_8, (copy) v_u_7, (copy) v_u_10, (copy) v_u_4, (copy) v_u_12, (copy) v_u_6, (copy) v_u_43, (copy) v_u_13, (copy) v_u_33, (copy) v_u_50, (copy) v_u_2, (copy) v_u_11
	local function v_u_68(p_u_52, p_u_53, p_u_54, p55, p56, p_u_57, p_u_58, p59) -- name: flare
		-- upvalues: (ref) v_u_26, (ref) v_u_1, (copy) p_u_51, (ref) v_u_37
		local v_u_60 = p59 or 0
		local v_u_61 = v_u_26(p_u_52, p_u_53, p55, p56, v_u_60)
		v_u_1:AddItem(v_u_61, p_u_57 + 0.1)
		p_u_51.animate(p_u_57, 0, function(p62)
			-- upvalues: (copy) p_u_53, (copy) p_u_54, (copy) v_u_61, (copy) p_u_52, (copy) p_u_57, (copy) p_u_58, (ref) v_u_37, (copy) v_u_60
			local v63 = 1 - (1 - p62) ^ 3
			local v64 = p_u_53 + (p_u_54 - p_u_53) * v63
			local v65 = v_u_61
			local v66 = v64 * 2
			local v67 = v64 * 2
			v65.Size = Vector3.new(v66, 0.05, v67)
			v_u_61.CFrame = p_u_52 * CFrame.Angles(0, p62 * p_u_57 * p_u_58, 0)
			v_u_37(v_u_61, v_u_60 + (1 - v_u_60) * p62 ^ 1.5)
			if p62 >= 1 then
				v_u_61:Destroy()
			end
		end)
	end
	local function v_u_100(p69, p70, p71, p72, p_u_73) -- name: shards
		-- upvalues: (ref) v_u_5, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (copy) p_u_51
		if p70 > 0 then
			local v_u_74 = {}
			for v75 = 1, p70 do
				local v76 = (v75 + math.random() * 0.6) / p70 * 3.141592653589793 * 2
				local v77 = math.cos(v76)
				local v78 = 0.6 + math.random() * 0.8
				local v79 = math.sin(v76)
				local v80 = Vector3.new(v77, v78, v79).Unit
				local v81 = v_u_5.part
				local v82 = Vector3.new(1, 1, 1) * p71 * (0.7 + math.random() * 0.5)
				local v83 = CFrame.new(p69) * v_u_14
				local v84
				if v75 % 2 == 0 then
					v84 = v_u_9
				else
					v84 = v_u_8
				end
				local v85 = v81(v82, v83, v84)
				v_u_1:AddItem(v85, p_u_73 + 0.1)
				local v86 = {
					["p"] = v85,
					["v"] = v80 * p72 * (0.6 + math.random() * 0.6),
					["r"] = v_u_14,
					["spin"] = CFrame.Angles(math.random() * 0.4, math.random() * 0.4, 0)
				}
				table.insert(v_u_74, v86)
			end
			local v_u_87 = os.clock()
			local v_u_88 = v_u_87
			p_u_51.frame(function()
				-- upvalues: (ref) v_u_88, (copy) v_u_87, (copy) p_u_73, (copy) v_u_74
				local v89 = os.clock()
				local v90 = v89 - v_u_88
				local v91 = math.min(v90, 0.05)
				v_u_88 = v89
				local v92 = (v89 - v_u_87) / p_u_73
				local v93 = math.clamp(v92, 0, 1)
				for _, v94 in v_u_74 do
					local v95 = v94.v
					local v96 = v91 * 2.5
					local v97 = v95 * (1 - math.min(v96, 0.5))
					local v98 = v91 * 60
					v94.v = v97 - Vector3.new(0, v98, 0)
					v94.r = v94.r * v94.spin
					v94.p.CFrame = CFrame.new(v94.p.Position + v94.v * v91) * v94.r
					v94.p.Transparency = v93 * v93
				end
				if v93 < 1 then
					return true
				end
				for _, v99 in v_u_74 do
					v99.p:Destroy()
				end
				return false
			end)
		end
	end
	local function v116(p101, p102) -- name: runeShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_14, (ref) v_u_26, (ref) v_u_7, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1, (copy) p_u_51
		local v103 = p101.size
		local v_u_104 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p102, v_u_8, {
			["transparency"] = 1
		})
		local v_u_105 = v_u_5.part(Vector3.new(0.85, 0.85, 0.85) * v103, p102 * v_u_14, v_u_8)
		local v_u_106 = v_u_26(p102, 1.45 * v103, v_u_7.ArcaneRuneRing, v_u_9, 0)
		local v_u_107 = { v_u_105, v_u_106 }
		local v_u_108
		if p101.lite then
			v_u_108 = nil
		else
			v_u_108 = v_u_5.part(Vector3.new(2.1, 2.1, 2.1) * v103, p102, v_u_10, {
				["shape"] = nil,
				["transparency"] = 0.68,
				["shape"] = Enum.PartType.Ball
			})
			table.insert(v_u_107, v_u_108)
		end
		for _, v109 in v_u_107 do
			v_u_1:AddItem(v109, 4)
		end
		v_u_1:AddItem(v_u_104, 4)
		p_u_51.streak(v_u_104, v_u_8, v_u_10, 1.3 * v103, 0.14)
		if p101.mine then
			p_u_51.light(v_u_104, v_u_8, 9 * v103)
		end
		local v_u_110 = false
		return {
			["place"] = function(p111, p112) -- name: place
				-- upvalues: (copy) v_u_104, (copy) v_u_105, (ref) v_u_14, (copy) v_u_106, (ref) p_u_51, (ref) v_u_108
				v_u_104.CFrame = p111
				v_u_105.CFrame = p111 * CFrame.Angles(0, 0, p112 * 9) * v_u_14
				v_u_106.CFrame = p_u_51.facing(p111.Position, p111.LookVector) * CFrame.Angles(0, p112 * 12, 0)
				local v113 = v_u_108
				if v113 then
					v113.CFrame = p111
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_110, (copy) v_u_104, (ref) v_u_1, (copy) v_u_107
				if not v_u_110 then
					v_u_110 = true
					local v114 = v_u_104:FindFirstChildWhichIsA("PointLight")
					if v114 then
						v114:Destroy()
					end
					v_u_1:AddItem(v_u_104, 0.16)
					for _, v115 in v_u_107 do
						v115:Destroy()
					end
				end
			end
		}
	end
	local function v123(p117, p118) -- name: runeBreak
		-- upvalues: (ref) v_u_4, (copy) v_u_68, (copy) p_u_51, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (copy) v_u_100
		local v119 = p117.size
		local v120 = v_u_4.CurrentCamera
		local v121
		if v120 then
			local v122 = v120.CFrame.Position - p118
			v121 = v122.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v122.Unit
		else
			v121 = Vector3.new(0, 0, 1)
		end
		v_u_68(p_u_51.facing(p118, v121), 1.2 * v119, 4.6 * v119, v_u_7.ArcaneRuneRing, v_u_9, 0.24, 6, 0)
		p_u_51.pop(p118, v_u_8, 1.6 * v119, 5.5 * v119, 0.16, 0.35)
		v_u_5.flash(p118, v_u_9, 3.6 * v119, 0.12)
		p_u_51.burst("Impact", p118, v_u_8, 0.9 * v119)
		v_u_100(p118, p117.lite and 0 or 4, 0.45 * v119, 20 * v119, 0.4)
		if p118.Y - p_u_51.FLOOR < 5 then
			v_u_5.ring(p_u_51.ground(p118), v_u_8, p117.ability.radius * 0.6 * v119, 0.28, v_u_7.Ring)
		end
		p_u_51.hitSound(p118)
	end
	local function v252(p_u_124, p125, p_u_126) -- name: hexZone
		-- upvalues: (copy) p_u_51, (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (ref) v_u_12, (ref) v_u_9, (ref) v_u_14, (ref) v_u_26, (ref) v_u_7, (ref) v_u_37, (ref) v_u_6
		local v_u_127 = p_u_124.size
		local v_u_128 = p_u_124.ability.radius * v_u_127
		local v_u_129 = p_u_124.lite
		local v_u_130 = p_u_51.ground(p125, 0.2)
		local v_u_131 = p_u_126 + 2
		local v_u_132 = v_u_129 and 12 or 24
		local v133 = 2 * v_u_128
		local v134 = 3.141592653589793 / v_u_132
		local v_u_135 = v133 * math.sin(v134) + 0.35
		local v_u_136 = {}
		for v137 = 1, v_u_132 do
			local v138 = (v137 - 0.5) / v_u_132 * 3.141592653589793 * 2
			local v139 = math.cos(v138)
			local v140 = math.sin(v138)
			local v141 = v_u_130 + Vector3.new(v139, 0, v140) * v_u_128
			local v142 = -math.sin(v138)
			local v143 = math.cos(v138)
			local v144 = Vector3.new(v142, 0, v143)
			local v145 = v_u_5.part(Vector3.new(0.6, 0.35, v_u_135), CFrame.lookAt(v141, v141 + v144), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v145, v_u_131)
			table.insert(v_u_136, v145)
		end
		local v_u_146 = p_u_51.ball(v_u_130 + Vector3.new(v_u_128, 0.4, 0), v_u_12, 1.2 * v_u_127, 0)
		p_u_51.streak(v_u_146, v_u_9, v_u_8, 0.9 * v_u_127, 0.2)
		v_u_1:AddItem(v_u_146, 0.8)
		local v_u_147 = {}
		for v148 = 1, 6 do
			if v_u_129 and v148 % 2 == 0 then
				continue
			end
			local v149 = v_u_5.part
			local v150 = Vector3.new(0.95, 0.95, 0.95) * v_u_127
			local v151 = CFrame.new
			local v152 = v_u_128 * 0.82
			local v153 = 1.5707963267948966 + (v148 - 1) * 3.141592653589793 / 3
			local v154 = math.cos(v153)
			local v155 = math.sin(v153)
			local v156 = v149(v150, v151(v_u_130 + Vector3.new(v154, 0, v155) * v152) * v_u_14, v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v156, v_u_131)
			v_u_147[v148] = v156
		end
		local v_u_157
		if v_u_129 then
			v_u_157 = nil
		else
			v_u_157 = v_u_26(CFrame.new(v_u_130 + Vector3.new(0, 3.2, 0)), v_u_128 * 0.62, v_u_7.ArcaneRuneRing, v_u_9, 1)
			v_u_1:AddItem(v_u_157, v_u_131)
		end
		local v_u_158 = {}
		local v_u_159 = os.clock()
		local v_u_160 = nil
		local v_u_161 = 0
		p_u_51.after(0.12, function()
			-- upvalues: (ref) v_u_160, (ref) v_u_5, (copy) v_u_130, (ref) v_u_8, (copy) v_u_128, (copy) p_u_126, (ref) v_u_7
			if not v_u_160 then
				local v162 = v_u_5.disc
				local v163 = v_u_130
				local v164 = v_u_8
				local v165 = v_u_128
				local v166 = p_u_126 - 0.25
				v162(v163, v164, v165, math.max(v166, 0.3), v_u_7.ArcaneRunes, 0.5)
			end
		end)
		p_u_51.runNow(function()
			-- upvalues: (copy) v_u_159, (copy) v_u_132, (ref) v_u_161, (copy) v_u_136, (copy) v_u_146, (ref) v_u_5, (ref) v_u_9, (copy) v_u_130, (copy) v_u_128, (copy) v_u_147, (ref) v_u_14, (ref) v_u_160, (ref) v_u_157, (ref) v_u_37, (copy) p_u_126
			local v167 = os.clock() - v_u_159
			local v168 = v167 / 0.3
			local v169 = math.clamp(v168, 0, 1)
			local v170 = v169 * v_u_132 + 0.5
			local v171 = math.floor(v170)
			while v_u_161 < v171 do
				v_u_161 = v_u_161 + 1
				v_u_136[v_u_161].Transparency = 0
			end
			if v_u_146.Parent then
				if v169 >= 1 then
					v_u_5.flash(v_u_146.Position, v_u_9, 3, 0.12)
					v_u_146:Destroy()
				else
					local v172 = v169 * 3.141592653589793 * 2
					local v173 = v_u_146
					local v174 = CFrame.new
					local v175 = v_u_130
					local v176 = math.cos(v172) * v_u_128
					local v177 = math.sin(v172) * v_u_128
					v173.CFrame = v174(v175 + Vector3.new(v176, 0.4, v177))
				end
			end
			local v178 = (v167 - 0.3) / 0.18
			local v179 = math.clamp(v178, 0, 1)
			for v180, v181 in v_u_147 do
				local v182 = v_u_130
				local v183 = v_u_128 * 0.82
				local v184 = 1.5707963267948966 + (v180 - 1) * 3.141592653589793 / 3
				local v185 = math.cos(v184)
				local v186 = math.sin(v184)
				local v187 = v182 + Vector3.new(v185, 0, v186) * v183
				local v188 = v179 - 1
				local v189 = (v188 * 2.9 * v188 * v188 + 1 + v188 * 1.9 * v188) * 2.4
				local v190 = v167 * 3 + v180
				local v191 = v187 + Vector3.new(0, 1, 0) * (v189 + math.sin(v190) * 0.25)
				v181.CFrame = CFrame.new(v191) * CFrame.Angles(0, v167 * 2.5 + v180, 0) * v_u_14
				if v179 <= 0 or v_u_160 then
					continue
				end
				v181.Transparency = 0
			end
			local v192 = v_u_157
			if v192 and not v_u_160 then
				local v193 = (v167 - 0.3) / 0.2
				local v194 = math.clamp(v193, 0, 1)
				local v195 = v_u_128 * 0.62 * (v194 * 0.6 + 0.4)
				local v196 = v195 * 2
				local v197 = v195 * 2
				v192.Size = Vector3.new(v196, 0.05, v197)
				v192.CFrame = CFrame.new(v_u_130 + Vector3.new(0, 3.2, 0)) * CFrame.Angles(0, -v167 * 1.3, 0)
				v_u_37(v192, 1 - v194 * 0.85)
			end
			local v198
			if v_u_160 == nil then
				v198 = v167 < p_u_126 + 1
			else
				v198 = false
			end
			return v198
		end)
		if not v_u_129 then
			p_u_51.after(0.3, function()
				-- upvalues: (ref) v_u_160, (copy) v_u_130, (copy) v_u_128, (ref) v_u_5, (ref) v_u_9, (ref) v_u_8, (ref) v_u_1, (copy) v_u_131, (copy) v_u_158, (ref) p_u_51
				if not v_u_160 then
					for v199, v200 in {
						{ 1, 3 },
						{ 3, 5 },
						{ 5, 1 },
						{ 2, 4 },
						{ 4, 6 },
						{ 6, 2 }
					} do
						local v201 = v_u_130
						local v202 = v_u_128 * 0.82
						local v203 = 1.5707963267948966 + (v200[1] - 1) * 3.141592653589793 / 3
						local v204 = math.cos(v203)
						local v205 = math.sin(v203)
						local v_u_206 = v201 + Vector3.new(v204, 0, v205) * v202
						local v207 = v_u_130
						local v208 = v_u_128 * 0.82
						local v209 = 1.5707963267948966 + (v200[2] - 1) * 3.141592653589793 / 3
						local v210 = math.cos(v209)
						local v211 = math.sin(v209)
						local v_u_212 = v207 + Vector3.new(v210, 0, v211) * v208
						local v213 = v_u_5.part
						local v214 = Vector3.new(0.42, 0.3, 0.1)
						local v215 = CFrame.lookAt(v_u_206, v_u_212)
						local v216
						if v199 <= 3 then
							v216 = v_u_9
						else
							v216 = v_u_8
						end
						local v_u_217 = v213(v214, v215, v216)
						v_u_1:AddItem(v_u_217, v_u_131)
						local v218 = v_u_158
						table.insert(v218, v_u_217)
						p_u_51.after((v199 - 1) * 0.025, function()
							-- upvalues: (ref) p_u_51, (copy) v_u_217, (copy) v_u_206, (copy) v_u_212
							p_u_51.animate(0.12, 0, function(p219)
								-- upvalues: (ref) v_u_217, (ref) v_u_206, (ref) v_u_212
								if v_u_217.Parent then
									local v220 = v_u_206:Lerp(v_u_212, p219)
									local v221 = v_u_217
									local v222 = (v220 - v_u_206).Magnitude
									local v223 = math.max(v222, 0.1)
									v221.Size = Vector3.new(0.42, 0.3, v223)
									v_u_217.CFrame = CFrame.lookAt((v_u_206 + v220) / 2, v_u_212)
								end
							end)
						end)
					end
				end
			end)
		end
		local v_u_224 = p_u_124.ability.tick or 0.4
		local v_u_225 = 0
		task.spawn(function()
			-- upvalues: (ref) v_u_160, (copy) v_u_159, (copy) p_u_126, (ref) v_u_225, (copy) v_u_129, (copy) v_u_147, (copy) v_u_128, (copy) v_u_130, (copy) v_u_127, (ref) v_u_9, (ref) v_u_8, (ref) p_u_51, (ref) v_u_5, (copy) v_u_224, (ref) v_u_6, (copy) p_u_124
			task.wait(0.38)
			while not v_u_160 and os.clock() - v_u_159 < p_u_126 do
				v_u_225 = v_u_225 + 1
				for v226 = 1, v_u_129 and 1 or 3 do
					local v227 = v_u_147[(v_u_225 * 2 + v226 * 2) % 6 + 1] or v_u_147[1]
					if not v227 then
						continue
					end
					local v228 = math.random() * 3.141592653589793 * 2
					local v229 = v_u_128 * (0.1 + math.random() * 0.6)
					local v230 = v_u_130
					local v231 = math.cos(v228) * v229
					local v232 = math.sin(v228) * v229
					local v233 = v230 + Vector3.new(v231, 0, v232)
					local v234 = v227.Position
					local v235 = 0.28 * v_u_127
					local v236
					if v226 == 2 then
						v236 = v_u_9
					else
						v236 = v_u_8
					end
					local v237 = p_u_51.drawPath
					local v238 = p_u_51.boltPath
					local v239 = (v233 - v234).Magnitude * 0.12
					v237(v238(v234, v233, math.min(v239, 1.4), 2.4), v235, v236, 0.15)
					v_u_5.flash(v233 + Vector3.new(0, 0.6, 0), v_u_9, 2.6 * v_u_127, 0.1)
					if v_u_129 then
						continue
					end
					p_u_51.burst("Impact", v233 + Vector3.new(0, 0.5, 0), v_u_8, 0.45)
				end
				if not v_u_129 then
					p_u_51.inward(v_u_130 + Vector3.new(0, 1.5, 0), v_u_9, 3, v_u_128, v_u_224 * 0.7)
				end
				if v_u_225 % 2 == 1 then
					v_u_6.play("Lightning", {
						["at"] = v_u_130 + Vector3.new(0, 2, 0),
						["volume"] = p_u_124.mine and 0.35 or 0.2
					})
				end
				task.wait(v_u_224)
			end
		end)
		return function()
			-- upvalues: (ref) v_u_160, (copy) v_u_136, (ref) v_u_5, (copy) v_u_135, (ref) v_u_1, (copy) v_u_158, (ref) p_u_51, (copy) v_u_147, (ref) v_u_8, (copy) v_u_127, (ref) v_u_157, (copy) v_u_128, (copy) v_u_146, (copy) v_u_130, (ref) v_u_7
			if not v_u_160 then
				v_u_160 = os.clock()
				for _, v240 in v_u_136 do
					if not v240.Parent then
						continue
					end
					local v241 = v_u_5.tween
					local v242 = {
						["CFrame"] = nil,
						["Transparency"] = 1,
						["Size"] = nil,
						["CFrame"] = v240.CFrame + Vector3.new(0, 2.2, 0)
					}
					local v243 = v_u_135
					v242.Size = Vector3.new(0.1, 0.1, v243)
					v241(v240, 0.32, v242)
					v_u_1:AddItem(v240, 0.35)
				end
				for _, v244 in v_u_158 do
					if not v244.Parent then
						continue
					end
					p_u_51.fadeOut(v244, 0.25)
				end
				for _, v245 in v_u_147 do
					if not v245.Parent then
						continue
					end
					v_u_5.flash(v245.Position, v_u_8, 2.4 * v_u_127, 0.14)
					v245:Destroy()
				end
				local v246 = v_u_157
				if v246 and v246.Parent then
					for _, v247 in v246:GetChildren() do
						if not v247:IsA("Decal") then
							continue
						end
						v_u_5.tween(v247, 0.25, {
							["Transparency"] = 1
						})
					end
					local v248 = v_u_5.tween
					local v249 = {}
					local v250 = v_u_128 * 2.2
					local v251 = v_u_128 * 2.2
					v249.Size = Vector3.new(v250, 0.05, v251)
					v248(v246, 0.25, v249)
					v_u_1:AddItem(v246, 0.3)
				end
				if v_u_146.Parent then
					v_u_146:Destroy()
				end
				v_u_5.ring(v_u_130, v_u_8, v_u_128 * 1.15, 0.38, v_u_7.ArcaneRuneRing)
				p_u_51.burst("Impact", v_u_130 + Vector3.new(0, 1, 0), v_u_8, 1.2)
			end
		end
	end
	local v_u_253 = {}
	setmetatable(v_u_253, {
		["__mode"] = "k"
	})
	local v_u_254 = {}
	setmetatable(v_u_254, {
		["__mode"] = "k"
	})
	local function v_u_266(p255, p256) -- name: skyPoint
		-- upvalues: (copy) p_u_51
		local v257 = p255.feet.X
		local v258 = p_u_51.FLOOR
		local v259 = p255.feet.Z
		local v260 = Vector3.new(v257, v258, v259)
		local v261 = p256.X
		local v262 = p_u_51.FLOOR
		local v263 = p256.Z
		local v264 = Vector3.new(v261, v262, v263)
		local v265
		if (v264 - v260).Magnitude > 1 then
			v265 = p_u_51.flatUnit(v264 - v260)
		else
			v265 = p_u_51.flatUnit(p255.dir)
		end
		return p_u_51.ground(v264, 20) + v265 * 7
	end
	local function v_u_271(p267) -- name: dropEye
		if not p267.done then
			p267.done = true
			for _, v268 in p267.points do
				for _, v269 in v268.parts do
					v269:Destroy()
				end
			end
			p267.iris:Destroy()
			p267.swirl:Destroy()
			p267.runes:Destroy()
			local v270 = p267.band
			if v270 then
				v270:Destroy()
			end
		end
	end
	local function v_u_307(p272, p273) -- name: buildEye
		-- upvalues: (copy) v_u_266, (ref) v_u_43, (ref) v_u_5, (ref) v_u_13, (ref) v_u_1, (ref) v_u_10, (ref) v_u_8, (ref) v_u_33, (copy) p_u_51, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9
		local v274 = p272.lite
		local v_u_275 = v_u_266(p272, p273)
		local v276 = {}
		for v277 = 0, 7 do
			local v278 = v277 % 2 == 0
			if v274 and not v278 then
				continue
			end
			local v279 = v278 and 11 or 6.5
			local v280 = v278 and 4.6 or 3.2
			local v_u_281 = {}
			local v_u_282 = {}
			local v_u_283 = {}
			local function v299(p284, p285, p286, p287, p288) -- name: add
				-- upvalues: (ref) v_u_43, (ref) v_u_5, (copy) v_u_275, (ref) v_u_13, (ref) v_u_1, (copy) v_u_281, (copy) v_u_282, (copy) v_u_283
				local v289, v290 = v_u_43(p284, p285, 0.4)
				for v291, v292 in v289 do
					local v293 = {
						["shape"] = nil,
						["transparency"] = 1,
						["shape"] = v_u_13
					}
					local v294 = v_u_5.part(v292, CFrame.new(v_u_275), p286, v293)
					v294:SetAttribute("Alpha", p287)
					v_u_1:AddItem(v294, 5)
					local v295 = v_u_281
					table.insert(v295, v294)
					local v296 = v_u_282
					local v297 = CFrame.new(0, 0, p288) * v290[v291]
					table.insert(v296, v297)
					local v298 = v_u_283
					table.insert(v298, v292)
				end
			end
			local v300
			if v278 then
				v300 = v_u_10
			else
				v300 = v_u_8
			end
			v299(v280, v279, v300, 0, 0)
			if v278 and not v274 then
				v299(v280 * 1.45, v279 * 1.2, v_u_8, 0.5, 0.6)
			end
			local v301 = {
				["parts"] = v_u_281,
				["offs"] = v_u_282,
				["sizes"] = v_u_283,
				["angle"] = 1.5707963267948966 + v277 * 3.141592653589793 / 4
			}
			table.insert(v276, v301)
		end
		local v302 = v_u_33(p_u_51.iris("arcane_sigil", v_u_7.ArcaneRunes), v_u_12, 0)
		local v303 = v_u_33(v_u_7.Swirl, v_u_9, 0.25)
		local v304 = v_u_33(v_u_7.ArcaneRunes, v_u_8, 1)
		local v305
		if v274 then
			v305 = nil
		else
			v305 = v_u_33(v_u_7.ArcaneRuneRing, v_u_9, 1)
		end
		for _, v306 in { v302, v303, v304 } do
			v_u_1:AddItem(v306, 5)
		end
		if v305 then
			v_u_1:AddItem(v305, 5)
		end
		return {
			["lite"] = nil,
			["at"] = nil,
			["target"] = nil,
			["points"] = nil,
			["iris"] = nil,
			["swirl"] = nil,
			["runes"] = nil,
			["band"] = nil,
			["born"] = nil,
			["spin"] = 0,
			["last"] = nil,
			["k"] = -1,
			["landAt"] = nil,
			["done"] = false,
			["parts"] = nil,
			["cfs"] = nil,
			["lite"] = v274,
			["at"] = v_u_275,
			["target"] = p273,
			["points"] = v276,
			["iris"] = v302,
			["swirl"] = v303,
			["runes"] = v304,
			["band"] = v305,
			["born"] = os.clock(),
			["last"] = os.clock(),
			["parts"] = {},
			["cfs"] = {}
		}
	end
	local function v_u_367(p308) -- name: eyeStep
		-- upvalues: (ref) v_u_4, (ref) v_u_50, (ref) v_u_37, (ref) v_u_5, (ref) v_u_8, (copy) v_u_271
		if p308.done then
			return false
		end
		local v309 = os.clock()
		local v310 = v309 - p308.born
		local v311 = v309 - p308.last
		local v312 = math.min(v311, 0.05)
		p308.last = v309
		local v313 = p308.landAt
		local v314
		if v313 then
			v314 = v313 + 0.6
		else
			v314 = p308.born + 1.4
		end
		local v315 = (v309 - v314) / 0.16
		local v316 = math.clamp(v315, 0, 1)
		local v317 = v310 / 0.16
		local v318 = math.clamp(v317, 0, 1) - 1
		local v319 = (v318 * 2.9 * v318 * v318 + 1 + v318 * 1.9 * v318) * (1 - v316)
		local v320 = (v310 - 0.05) / 0.16
		local v321 = math.clamp(v320, 0, 1) - 1
		local v322 = (v321 * 2.9 * v321 * v321 + 1 + v321 * 1.9 * v321) * (1 - v316)
		local v323 = math.max(v319, 0.02)
		local v324
		if v313 then
			v324 = 22
		else
			local v325 = v310 / 0.35
			v324 = math.clamp(v325, 0, 1) ^ 2 * 60 + 4
		end
		p308.spin = p308.spin + v324 * v312
		local v326 = p308.at
		local v327 = v_u_4.CurrentCamera
		local v328
		if v327 then
			local v329 = v327.CFrame.Position - v326
			v328 = v329.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v329.Unit
		else
			v328 = Vector3.new(0, 0, 1)
		end
		local v330 = CFrame.lookAt(p308.at, p308.at + v328)
		local v331 = v330.RightVector
		local v332 = v330.UpVector
		local v333 = v310 * 0.35
		local v334 = p308.parts
		local v335 = p308.cfs
		table.clear(v334)
		table.clear(v335)
		local v336 = v323 - p308.k
		local v337 = math.abs(v336) > 0.001
		p308.k = v323
		for _, v338 in p308.points do
			local v339 = v338.angle + v333
			local v340 = v331 * math.cos(v339)
			local v341 = v338.angle + v333
			local v342 = v340 + v332 * math.sin(v341)
			local v343 = v_u_50(p308.at + v342 * 4.6 * v323 - v328 * 0.5, v342, v328)
			for v344, v345 in v338.parts do
				local v346 = v338.offs[v344]
				table.insert(v334, v345)
				local v347 = v343 * (v346 - v346.Position + v346.Position * v323)
				table.insert(v335, v347)
				if not v337 then
					continue
				end
				v345.Size = v338.sizes[v344] * v323
				local v348 = v345:GetAttribute("Alpha")
				v345.Transparency = type(v348) ~= "number" and 0 or v348 + (1 - v348) * v316
			end
		end
		if #v334 > 0 then
			v_u_4:BulkMoveTo(v334, v335, Enum.BulkMoveMode.FireCFrameChanged)
		end
		local v349 = v323 * 12
		p308.iris.CFrame = v330
		local v350 = p308.iris
		local v351 = v349 * v322
		local v352 = math.max(v351, 0.05)
		v350.Size = Vector3.new(v349, v352, 0.05)
		p308.swirl.CFrame = v330 * CFrame.new(0, 0, -0.3) * CFrame.Angles(0, 0, -p308.spin)
		local v353 = p308.swirl
		local v354 = v349 * 0.5
		local v355 = v349 * 0.5 * v322
		local v356 = math.max(v355, 0.05)
		v353.Size = Vector3.new(v354, v356, 0.05)
		local v357 = v310 / 0.25
		local v358 = math.clamp(v357, 0, 1) * (1 - v316)
		local v359 = v323 * 17.16
		p308.runes.CFrame = v330 * CFrame.new(0, 0, 1) * CFrame.Angles(0, 0, v310 * 0.5)
		local v360 = p308.runes
		local v361 = v359 * 2
		local v362 = v359 * 2
		v360.Size = Vector3.new(v361, v362, 0.05)
		v_u_37(p308.runes, 1 - v358 * 0.75)
		local v363 = p308.band
		if v363 then
			local v364 = v359 * 1.2
			v363.CFrame = v330 * CFrame.new(0, 0, 1.3) * CFrame.Angles(0, 0, -v310 * 0.8)
			local v365 = v364 * 2
			local v366 = v364 * 2
			v363.Size = Vector3.new(v365, v366, 0.05)
			v_u_37(v363, 1 - v358 * 0.7)
		end
		if v316 < 1 then
			return true
		end
		v_u_5.flash(p308.at, v_u_8, 9, 0.18)
		v_u_271(p308)
		return false
	end
	local function v_u_373(p368, p369) -- name: startEye
		-- upvalues: (copy) v_u_307, (copy) v_u_253, (copy) v_u_271, (copy) v_u_254, (copy) p_u_51, (ref) v_u_8, (copy) v_u_367
		local v_u_370 = v_u_307(p368, p369)
		local v371 = p368.caster
		if v371 then
			local v372 = v_u_253[v371]
			if v372 and not v372.landAt then
				v_u_271(v372)
			end
			v_u_253[v371] = v_u_370
		else
			v_u_254[p368] = v_u_370
		end
		p_u_51.burst("Flash", v_u_370.at, v_u_8, 0.6)
		p_u_51.runNow(function()
			-- upvalues: (ref) v_u_367, (copy) v_u_370
			return v_u_367(v_u_370)
		end)
		return v_u_370
	end
	local v_u_374 = 0
	local function v_u_378() -- name: dusk
		-- upvalues: (ref) v_u_374, (ref) v_u_2, (ref) v_u_5, (copy) p_u_51, (ref) v_u_12, (ref) v_u_1
		local v375 = os.clock()
		if v375 >= v_u_374 then
			v_u_374 = v375 + 1.4
			local v_u_376 = Instance.new("ColorCorrectionEffect")
			v_u_376.Name = "ArcaneCataclysm"
			v_u_376.Parent = v_u_2
			v_u_5.tween(v_u_376, 0.15, {
				["TintColor"] = nil,
				["Brightness"] = -0.12,
				["Contrast"] = 0.18,
				["Saturation"] = 0.1,
				["TintColor"] = Color3.fromRGB(205, 175, 255)
			})
			p_u_51.after(0.75, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_376, (ref) v_u_12
				local v377 = {
					["TintColor"] = nil,
					["Brightness"] = 0,
					["Contrast"] = 0,
					["Saturation"] = 0,
					["TintColor"] = v_u_12
				}
				v_u_5.tween(v_u_376, 0.55, v377)
			end)
			v_u_1:AddItem(v_u_376, 1.4)
		end
	end
	local function v_u_398(p_u_379, p_u_380, p_u_381, p382, p_u_383, p_u_384, p_u_385, p_u_386) -- name: column
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (copy) p_u_51
		local v_u_387 = v_u_5.part(Vector3.new(0.1, p_u_381, p_u_381), CFrame.new(p_u_379), p382, {
			["shape"] = Enum.PartType.Cylinder,
			["transparency"] = p_u_383
		})
		v_u_1:AddItem(v_u_387, p_u_384 + p_u_385 + p_u_386 + 0.3)
		local v_u_388 = os.clock()
		p_u_51.runNow(function()
			-- upvalues: (copy) v_u_388, (copy) p_u_384, (copy) p_u_379, (copy) p_u_380, (copy) p_u_385, (copy) p_u_386, (copy) p_u_381, (copy) v_u_387, (ref) p_u_51, (copy) p_u_383
			local v389 = os.clock() - v_u_388
			local v390 = v389 / p_u_384
			local v391 = math.clamp(v390, 0, 1)
			local v392 = p_u_379:Lerp(p_u_380, v391 * v391)
			local v393 = (v392 - p_u_379).Magnitude
			local v394 = math.max(v393, 0.1)
			local v395 = (v389 - p_u_384 - p_u_385) / p_u_386
			local v396 = math.clamp(v395, 0, 1)
			local v397 = p_u_381 * (1 - v396 * 0.9)
			v_u_387.Size = Vector3.new(v394, v397, v397)
			v_u_387.CFrame = p_u_51.aimAt((p_u_379 + v392) / 2, v392 - p_u_379) * CFrame.Angles(0, 1.5707963267948966, 0)
			v_u_387.Transparency = p_u_383 + (1 - p_u_383) * v396
			if v396 < 1 then
				return true
			end
			v_u_387:Destroy()
			return false
		end)
	end
	local function v_u_414(p_u_399, p_u_400, p_u_401) -- name: cataclysm
		-- upvalues: (copy) p_u_51, (copy) v_u_398, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_26, (ref) v_u_7, (ref) v_u_1, (ref) v_u_5, (ref) v_u_12, (copy) v_u_68, (copy) v_u_100, (ref) v_u_11, (ref) v_u_6
		local v_u_402 = p_u_399.ability.radius
		local v_u_403 = p_u_399.lite
		local v_u_404 = p_u_51.ground(p_u_400, 0)
		local v_u_405 = p_u_51.ground(p_u_400, 4)
		v_u_398(p_u_401, v_u_404, v_u_402 * 0.95, v_u_8, 0.35, 0.06, 0.14, 0.45)
		v_u_398(p_u_401, v_u_404, v_u_402 * 0.4, v_u_9, 0, 0.06, 0.1, 0.35)
		if not v_u_403 then
			v_u_398(p_u_401, v_u_404, v_u_402 * 1.4, v_u_10, 0.75, 0.06, 0.12, 0.5)
			for v_u_406 = 0, 2 do
				p_u_51.after(v_u_406 * 0.05, function()
					-- upvalues: (ref) v_u_26, (copy) p_u_401, (copy) v_u_402, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) p_u_51, (copy) v_u_404, (ref) v_u_5, (ref) v_u_8, (copy) v_u_406
					local v_u_407 = v_u_26(CFrame.new(p_u_401), v_u_402 * 0.8, v_u_7.ArcaneRuneRing, v_u_9, 0)
					v_u_1:AddItem(v_u_407, 0.3)
					p_u_51.animate(0.11, 0, function(p408)
						-- upvalues: (ref) p_u_401, (ref) v_u_404, (ref) v_u_402, (copy) v_u_407, (ref) v_u_5, (ref) v_u_8, (ref) v_u_406, (ref) v_u_7
						local v409 = p_u_401:Lerp(v_u_404 + Vector3.new(0, 0.5, 0), p408 * p408)
						local v410 = v_u_402 * (0.8 - 0.25 * p408)
						local v411 = v_u_407
						local v412 = v410 * 2
						local v413 = v410 * 2
						v411.Size = Vector3.new(v412, 0.05, v413)
						v_u_407.CFrame = CFrame.new(v409) * CFrame.Angles(0, p408 * 4, 0)
						if p408 >= 1 then
							v_u_407:Destroy()
							v_u_5.ring(v_u_404, v_u_8, v_u_402 * (v_u_406 * 0.2 + 0.9), 0.32, v_u_7.ArcaneRuneRing)
						end
					end)
				end)
			end
		end
		v_u_5.flash(p_u_401, v_u_9, 10, 0.14)
		p_u_51.after(0.06, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_405, (ref) v_u_9, (copy) v_u_402, (ref) p_u_51, (copy) v_u_404, (ref) v_u_8, (ref) v_u_10, (copy) p_u_400, (ref) v_u_7, (ref) v_u_12, (ref) v_u_68, (copy) v_u_403, (ref) v_u_100, (ref) v_u_11, (ref) v_u_6, (copy) p_u_399
			v_u_5.flash(v_u_405, v_u_9, v_u_402 * 1.3, 0.15)
			p_u_51.pop(v_u_404, v_u_8, v_u_402 * 0.6, v_u_402 * 2.2, 0.5, 0.25)
			p_u_51.pop(v_u_404, v_u_10, v_u_402, v_u_402 * 2.7, 0.7, 0.6)
			p_u_51.burst("Flash", v_u_405, v_u_8, 1, true)
			p_u_51.burst("Explosion", p_u_51.ground(p_u_400, 2), v_u_8, 2.4)
			p_u_51.burst("Shockwave", v_u_404 + Vector3.new(0, 0.3, 0), v_u_8, 1.5)
			v_u_5.ring(v_u_404, v_u_8, v_u_402 * 1.25, 0.55, v_u_7.Shockwave)
			p_u_51.after(0.05, function()
				-- upvalues: (ref) v_u_5, (ref) v_u_404, (ref) v_u_9, (ref) v_u_402, (ref) v_u_7
				v_u_5.ring(v_u_404, v_u_9, v_u_402 * 1.5, 0.5, v_u_7.ArcaneRuneRing)
			end)
			p_u_51.after(0.1, function()
				-- upvalues: (ref) v_u_5, (ref) v_u_404, (ref) v_u_12, (ref) v_u_402, (ref) v_u_7
				v_u_5.ring(v_u_404, v_u_12, v_u_402 * 1.6, 0.45, v_u_7.SpeedLines)
			end)
			v_u_68(CFrame.new(p_u_51.ground(p_u_400, 0.25)), v_u_402, v_u_402 * 1.6, v_u_7.ArcaneRunes, v_u_8, 0.7, 1.5, 0)
			p_u_51.spikes(v_u_405, v_u_9, v_u_403 and 5 or 10, v_u_402 * 1.3, 0.35, Vector3.new(0, 1, 0), 0.8)
			v_u_100(p_u_51.ground(p_u_400, 1.5), v_u_403 and 3 or 8, 0.8, 45, 0.9)
			p_u_51.chunks(p_u_51.ground(p_u_400, 1), {
				p_u_51.EARTH[1],
				p_u_51.EARTH[2],
				v_u_10,
				p_u_51.EARTH[4]
			}, v_u_403 and 6 or 14, 55, 1.4, 1.3, false, 1.1)
			p_u_51.mark(p_u_400, v_u_11, v_u_402 * 0.8, 2.4, v_u_7.CrackGlow, 0.05)
			p_u_51.mark(p_u_400, v_u_8, v_u_402 * 0.6, 2, v_u_7.CrackLines, 0.15)
			v_u_6.play("Explosion", {
				["at"] = v_u_404,
				["volume"] = p_u_399.mine and 1 or 0.6
			})
			if p_u_399.mine then
				v_u_5.shake(0.6, 0.55)
			end
		end)
	end
	local v460 = {
		["arcane_sigil_a"] = {
			["cast"] = function(p415) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) v_u_68, (copy) p_u_51, (ref) v_u_7, (ref) v_u_9
				local v416 = p415.size
				local v417 = p415.eye + p415.dir * 1.3
				v_u_5.flash(v417, v_u_8, 2.8 * v416, 0.1)
				v_u_68(p_u_51.facing(v417, p415.dir), 0.5 * v416, 2 * v416, v_u_7.ArcaneRuneRing, v_u_9, 0.12, 8, 0)
			end,
			["shot"] = v116,
			["impact"] = v123,
			["hit"] = function(p418, p419, _) -- name: hit
				-- upvalues: (copy) p_u_51, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9
				p_u_51.burst("Impact", p419, v_u_8, 0.6)
				if not p418.lite then
					v_u_5.flash(p419, v_u_9, 2, 0.08)
				end
			end
		},
		["arcane_sigil_e"] = {
			["cast"] = function(p420) -- name: cast
				-- upvalues: (copy) p_u_51, (ref) v_u_8, (copy) v_u_68, (ref) v_u_7, (ref) v_u_9
				p_u_51.skillCast(p420, v_u_8)
				local v421 = p420.eye + p420.dir * 1.6
				v_u_68(p_u_51.facing(v421, p420.dir), 0.8, 3.4, v_u_7.ArcaneRunes, v_u_9, 0.2, 5, 0)
			end,
			["windup"] = function(p422, p423, p424) -- name: windup
				-- upvalues: (copy) p_u_51, (ref) v_u_9, (ref) v_u_5, (ref) v_u_8
				local v425 = p_u_51.ground(p423, 0.6)
				local v426 = p422.eye + p422.dir
				local v427 = v_u_9
				local v428 = math.max(p424, 0.08) + 0.08
				local v429 = p_u_51.drawPath
				local v430 = p_u_51.boltPath
				local v431 = (v425 - v426).Magnitude * 0.12
				v429(v430(v426, v425, math.min(v431, 1.4), 2.4), 0.3, v427, v428)
				v_u_5.flash(v425, v_u_8, 4, 0.14)
			end,
			["zone"] = v252,
			["hit"] = function(p432, p433, _) -- name: hit
				-- upvalues: (copy) p_u_51, (ref) v_u_8, (ref) v_u_9
				p_u_51.burst("Impact", p433, v_u_8, 0.5)
				if not p432.lite then
					local v434 = p433 + Vector3.new(0, 5, 0)
					local v435 = v_u_9
					local v436 = p_u_51.drawPath
					local v437 = p_u_51.boltPath
					local v438 = (p433 - v434).Magnitude * 0.12
					v436(v437(v434, p433, math.min(v438, 1.4), 2.4), 0.16, v435, 0.1)
				end
			end
		},
		["arcane_sigil_r"] = {
			["cast"] = function(p439) -- name: cast
				-- upvalues: (copy) p_u_51, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (copy) v_u_378, (copy) v_u_373
				p_u_51.skillCast(p439, v_u_8, true)
				v_u_5.ring(p439.feet, v_u_9, 12, 0.4, v_u_7.ArcaneRuneRing)
				if p439.mine then
					v_u_378()
				end
				v_u_373(p439, p439.target)
			end,
			["windup"] = function(p440, p441, p442) -- name: windup
				-- upvalues: (copy) v_u_253, (copy) v_u_254, (copy) v_u_373, (ref) v_u_5, (copy) p_u_51, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1
				local v443 = p440.caster
				local v444
				if v443 then
					v444 = v_u_253[v443]
				else
					v444 = v_u_254[p440]
				end
				if not v444 or (v444.done or v444.landAt) then
					v444 = nil
				end
				local v445 = v444 or v_u_373(p440, p441)
				local v446 = p440.ability.radius
				local v447 = math.max(p442, 0.1)
				v_u_5.disc(p_u_51.ground(p441, 0), v_u_8, v446, v447 + 0.6, v_u_7.ArcaneRunes, 2.5)
				if not p440.lite then
					p_u_51.inward(v445.at, v_u_9, 8, 16, v447)
					v_u_1:AddItem(p_u_51.rod(v445.at, p_u_51.ground(p441, 0), 0.5, v_u_9, 0.55), v447 + 0.02)
				end
				if p440.mine then
					v_u_5.shake(0.2, 0.25)
				end
			end,
			["land"] = function(p448, p449) -- name: land
				-- upvalues: (copy) v_u_253, (copy) v_u_254, (copy) v_u_266, (copy) v_u_414
				local v450 = p448.caster
				local v451
				if v450 then
					v451 = v_u_253[v450]
				else
					v451 = v_u_254[p448]
				end
				local v452 = v_u_266(p448, p449)
				if v451 and not (v451.done or v451.landAt) then
					v451.landAt = os.clock()
					v452 = v451.at
				end
				v_u_414(p448, p449, v452)
			end,
			["hit"] = function(p453, p454, _) -- name: hit
				-- upvalues: (copy) p_u_51, (ref) v_u_8, (copy) v_u_68, (ref) v_u_4, (ref) v_u_7, (ref) v_u_9
				p_u_51.burst("Impact", p454, v_u_8, 1.2)
				if not p453.lite then
					local v455 = v_u_68
					local v456 = p_u_51.facing
					local v457 = v_u_4.CurrentCamera
					local v458
					if v457 then
						local v459 = v457.CFrame.Position - p454
						v458 = v459.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v459.Unit
					else
						v458 = Vector3.new(0, 0, 1)
					end
					v455(v456(p454, v458), 0.6, 2.8, v_u_7.ArcaneRuneRing, v_u_9, 0.2, 6, 0)
				end
			end
		}
	}
	return v460
end