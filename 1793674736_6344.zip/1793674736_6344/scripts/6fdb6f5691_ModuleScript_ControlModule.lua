local v_u_1 = {}
v_u_1.__index = v_u_1
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GuiService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = game:GetService("StarterPlayer")
local v_u_8 = UserSettings():GetService("UserGameSettings")
local v_u_9 = game:GetService("VRService")
local v_u_10 = game:GetService("ContextActionService")
local v11 = require(script.Parent:WaitForChild("CommonUtils"))
local v12 = v11.get("FlagUtil")
local v_u_13 = v12.getUserFlag("UserVRFixCameraCloseArticulation")
local v_u_14 = v12.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_15 = v12.getUserFlag("UserPlayerScriptsBindActivateOnIAS")
local v_u_16 = v12.getUserFlag("UserPlayerScriptsPlayerControlState2")
local v_u_17 = v12.getUserFlag("UserPlayerScriptsTaskDeferSimulation")
local v_u_18 = v12.getUserFlag("UserPlayerScriptsFixSAuthRenderStepMove")
local v_u_19 = v12.getUserFlag("UserPlayerScriptsSupportMicroGamepad")
local v_u_20 = v12.getUserFlag("UserAbilitiesUserInterfaceC")
local v_u_21 = v12.getUserFlag("UserControlModuleEnabledAPI")
local v_u_22 = v12.getUserFlag("UserPSUseBindToAnimation")
local v_u_23 = v12.getUserFlag("UserServerAuthorityDontSetAutoRotate")
local v_u_24 = require(script:WaitForChild("ActionController"))
local v_u_25
if v_u_14 or v_u_16 then
	v_u_25 = require(script:WaitForChild("InputReplication"))
else
	v_u_25 = nil
end
local v_u_26
if v_u_14 then
	v_u_26 = require(script:WaitForChild("InputSlots"))
else
	v_u_26 = nil
end
local v_u_27
if v_u_3:IsClient() then
	v_u_27 = require(script:WaitForChild("DynamicThumbstick"))
else
	v_u_27 = nil
end
local v_u_28 = require(script:WaitForChild("ClassicThumbstick"))
local v_u_29 = require(script:WaitForChild("ClickToMoveController"))
local v_u_30 = require(script:WaitForChild("TouchJump"))
local v_u_31
if v_u_14 then
	v_u_31 = require(script:WaitForChild("TouchAbilities"))
else
	v_u_31 = nil
end
local v_u_32 = require(script:WaitForChild("VehicleController"))
local v_u_33, v_u_34
if v_u_14 then
	v_u_33 = require(script:WaitForChild("AvatarAbilitiesInterface"))
	v_u_34 = v_u_33.get(v_u_2.LocalPlayer)
else
	v_u_33 = nil
	v_u_34 = nil
end
local v_u_35 = script.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext"):WaitForChild("CameraRotationAction")
local _ = Enum.ContextActionPriority.Medium.Value
local v_u_36 = v11.get("VRFirstPersonState")
local v_u_37 = {
	[Enum.TouchMovementMode.DPad] = v_u_27,
	[Enum.DevTouchMovementMode.DPad] = v_u_27,
	[Enum.TouchMovementMode.Thumbpad] = v_u_27,
	[Enum.DevTouchMovementMode.Thumbpad] = v_u_27,
	[Enum.TouchMovementMode.Thumbstick] = v_u_28,
	[Enum.DevTouchMovementMode.Thumbstick] = v_u_28,
	[Enum.TouchMovementMode.DynamicThumbstick] = v_u_27,
	[Enum.DevTouchMovementMode.DynamicThumbstick] = v_u_27,
	[Enum.TouchMovementMode.ClickToMove] = v_u_29,
	[Enum.DevTouchMovementMode.ClickToMove] = v_u_29,
	[Enum.TouchMovementMode.Default] = v_u_27,
	[Enum.ComputerMovementMode.Default] = v_u_24,
	[Enum.ComputerMovementMode.KeyboardMouse] = v_u_24,
	[Enum.DevComputerMovementMode.KeyboardMouse] = v_u_24,
	[Enum.DevComputerMovementMode.Scriptable] = nil,
	[Enum.ComputerMovementMode.ClickToMove] = v_u_29,
	[Enum.DevComputerMovementMode.ClickToMove] = v_u_29
}
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_2, (copy) v_u_32, (copy) v_u_8, (copy) v_u_14, (ref) v_u_34, (copy) v_u_5, (copy) v_u_4, (copy) v_u_15, (copy) v_u_10
	local v38 = v_u_1
	local v_u_39 = setmetatable({}, v38)
	if v_u_3:IsServer() then
		return v_u_39
	end
	v_u_39.controllers = {}
	v_u_39.activeControlModule = nil
	v_u_39.activeController = nil
	v_u_39.touchJumpController = nil
	v_u_39.touchAbilitiesController = nil
	v_u_39.moveFunction = v_u_2.LocalPlayer.Move
	v_u_39.humanoid = nil
	v_u_39.controlsEnabled = true
	v_u_39.enabled = false
	v_u_39.humanoidSeatedConn = nil
	v_u_39.vehicleController = nil
	v_u_39.touchControlFrame = nil
	v_u_39.currentTorsoAngle = 0
	v_u_39.inputMoveVector = Vector3.new(0, 0, 0)
	v_u_39.renderedRotationOverride = nil
	v_u_39.vehicleController = v_u_32.new()
	v_u_2.LocalPlayer.CharacterAdded:Connect(function(p40)
		-- upvalues: (copy) v_u_39
		v_u_39:OnCharacterAdded(p40)
	end)
	v_u_2.LocalPlayer.CharacterRemoving:Connect(function(p41)
		-- upvalues: (copy) v_u_39
		v_u_39:OnCharacterRemoving(p41)
	end)
	if v_u_2.LocalPlayer.Character then
		v_u_39:OnCharacterAdded(v_u_2.LocalPlayer.Character)
	end
	v_u_8:GetPropertyChangedSignal("TouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevTouchMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
	end)
	v_u_8:GetPropertyChangedSignal("ComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
	end)
	v_u_2.LocalPlayer:GetPropertyChangedSignal("DevComputerMovementMode"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
	end)
	if v_u_14 then
		v_u_34:GetEnabledChangedSignal():Connect(function()
			-- upvalues: (copy) v_u_39
			v_u_39:UpdateAbilitiesControllers()
		end)
	end
	v_u_39.playerGui = nil
	v_u_39.touchGui = nil
	v_u_39.playerGuiAddedConn = nil
	v_u_5:GetPropertyChangedSignal("TouchControlsEnabled"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
		v_u_39:UpdateActiveControlModuleEnabled()
	end)
	v_u_4:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) v_u_39
		v_u_39:UpdateMovementMode()
	end)
	v_u_39.playerGui = v_u_2.LocalPlayer:FindFirstChildOfClass("PlayerGui")
	if not v_u_39.playerGui then
		v_u_39.playerGuiAddedConn = v_u_2.LocalPlayer.ChildAdded:Connect(function(p42)
			-- upvalues: (copy) v_u_39
			if p42:IsA("PlayerGui") then
				v_u_39.playerGui = p42
				v_u_39.playerGuiAddedConn:Disconnect()
				v_u_39.playerGuiAddedConn = nil
				v_u_39:UpdateMovementMode()
			end
		end)
	end
	if v_u_15 then
		v_u_10:BindActivate(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonR2)
	end
	return v_u_39
end
local function v_u_48(p43) -- name: _fireCustomInputs
	-- upvalues: (copy) v_u_8
	local v44 = p43:FindFirstChild("InputContexts")
	if v44 == nil then
		return
	else
		local v45 = v44:FindFirstChild("CharacterContext")
		if v45 ~= nil then
			local v46 = v45:FindFirstChild("RotationAction")
			local v47 = v46 and v46:FindFirstChild("RotationScriptableBinding")
			if v47 then
				v47:Fire(v_u_8.RotationType == Enum.RotationType.CameraRelative)
			end
		end
	end
end
function v_u_1.restoreSimulatedRotation(p49) -- name: restoreSimulatedRotation
	local v50 = p49.renderedRotationOverride
	if v50 ~= nil then
		if v50.rootPart.Parent ~= nil then
			v50.rootPart.CFrame = CFrame.new(v50.rootPart.CFrame.Position) * v50.simulatedRotation
		end
		p49.renderedRotationOverride = nil
	end
end
function v_u_1.applyRenderedRotation(p51) -- name: applyRenderedRotation
	-- upvalues: (copy) v_u_6
	local v52 = v_u_6.CurrentCamera
	local v53 = p51.humanoid
	local v54
	if v53 then
		v54 = v53.RootPart
	else
		v54 = v53
	end
	if v52 == nil or (v54 == nil or (v53.Sit or (v53.SeatPart ~= nil or (v54:IsGrounded() or v53:GetState() == Enum.HumanoidStateType.Swimming)))) then
		return
	else
		local v55 = v52.CFrame.LookVector
		local v56 = v55.X
		local v57 = v55.Z
		local v58 = Vector3.new(v56, 0, v57)
		if v58.Magnitude >= 0.001 then
			if p51.renderedRotationOverride ~= nil and p51.renderedRotationOverride.rootPart ~= v54 then
				p51:restoreSimulatedRotation()
			end
			if p51.renderedRotationOverride == nil then
				p51.renderedRotationOverride = {
					["rootPart"] = v54,
					["simulatedRotation"] = v54.CFrame.Rotation
				}
			end
			local v59 = v54.CFrame.Position
			v54.CFrame = CFrame.lookAt(v59, v59 + v58)
		end
	end
end
local function v_u_62(p60) -- name: _cloneInputs
	-- upvalues: (copy) v_u_7
	local v61 = v_u_7.PlayerModule.InputContexts:Clone()
	v61.CharacterContext.Enabled = true
	v61.CameraContext.Enabled = true
	v61.Parent = p60
end
function v_u_1.InitializeServerAuthority(p_u_63) -- name: InitializeServerAuthority
	-- upvalues: (copy) v_u_3, (copy) v_u_14, (copy) v_u_2, (copy) v_u_25, (copy) v_u_7, (copy) v_u_62, (copy) v_u_16, (copy) v_u_17, (ref) v_u_33, (copy) v_u_22, (copy) v_u_23, (copy) v_u_48, (copy) v_u_8, (ref) v_u_34
	if v_u_3:IsServer() then
		if v_u_14 then
			for _, v64 in v_u_2:GetPlayers() do
				v_u_25.CloneInputsIfAbsent(v64)
			end
			v_u_2.PlayerAdded:Connect(v_u_25.CloneInputsIfAbsent)
		else
			for _, v65 in v_u_2:GetPlayers() do
				local v66 = v_u_7.PlayerModule.InputContexts:Clone()
				v66.CharacterContext.Enabled = true
				v66.CameraContext.Enabled = true
				v66.Parent = v65
			end
			v_u_2.PlayerAdded:Connect(v_u_62)
		end
		if v_u_16 then
			for _, v67 in v_u_2:GetPlayers() do
				v_u_25.createPlayerControlState(v67)
			end
			v_u_2.PlayerAdded:Connect(v_u_25.createPlayerControlState)
		end
		if v_u_14 and v_u_17 then
			for _, v68 in v_u_2:GetPlayers() do
				v_u_33.get(v68)
			end
			v_u_2.PlayerAdded:Connect(function(p69)
				-- upvalues: (ref) v_u_33
				v_u_33.get(p69)
			end)
		end
		if v_u_22 then
			v_u_3:BindToAnimation(function(p70)
				-- upvalues: (ref) v_u_2, (copy) p_u_63
				for _, v71 in v_u_2:GetPlayers() do
					p_u_63:ProcessInputs(v71, p70)
				end
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p72)
				-- upvalues: (ref) v_u_2, (copy) p_u_63
				for _, v73 in v_u_2:GetPlayers() do
					p_u_63:ProcessInputs(v73, p72)
				end
			end, Enum.StepFrequency.Hz60)
		end
	else
		if v_u_16 then
			v_u_25.watchForPlayerControlState(v_u_2.LocalPlayer)
		end
		if v_u_23 then
			v_u_3.PreAnimation:Connect(function()
				-- upvalues: (copy) p_u_63
				p_u_63:restoreSimulatedRotation()
			end)
		end
		v_u_3:BindToRenderStep("CameraInput", Enum.RenderPriority.Last.Value, function()
			-- upvalues: (ref) v_u_16, (ref) v_u_25, (ref) v_u_2, (copy) p_u_63, (ref) v_u_14, (ref) v_u_48, (ref) v_u_23, (ref) v_u_8, (ref) v_u_34
			if v_u_16 then
				v_u_25.writeInputToPCS(v_u_2.LocalPlayer, p_u_63, true)
			elseif v_u_14 then
				v_u_25.FireCustomInputs(v_u_2.LocalPlayer)
			else
				v_u_48(v_u_2.LocalPlayer)
			end
			if v_u_23 and (v_u_8.RotationType == Enum.RotationType.CameraRelative and not (v_u_14 and v_u_34:isEnabled())) then
				p_u_63:applyRenderedRotation()
			end
		end)
		if v_u_22 then
			v_u_3:BindToAnimation(function(p74)
				-- upvalues: (copy) p_u_63, (ref) v_u_2
				p_u_63:ProcessInputs(v_u_2.LocalPlayer, p74)
			end, Enum.StepFrequency.Hz60)
		else
			v_u_3:BindToSimulation(function(p75)
				-- upvalues: (copy) p_u_63, (ref) v_u_2
				p_u_63:ProcessInputs(v_u_2.LocalPlayer, p75)
			end, Enum.StepFrequency.Hz60)
		end
	end
	if p_u_63.data and p_u_63.data.eventBus then
		p_u_63.data.isServerAuthority = true
		p_u_63.data.eventBus:publish("SERVER_AUTHORITY_CHANGED", true)
	end
end
function v_u_1.GetEstimatedVRTorsoFrame(p76) -- name: GetEstimatedVRTorsoFrame
	-- upvalues: (copy) v_u_9
	local v77 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local _, v78, _ = v77:ToEulerAnglesYXZ()
	local v79 = -v78
	if v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.RightHand) and v_u_9:GetUserCFrameEnabled(Enum.UserCFrame.LeftHand) then
		local v80 = v_u_9:GetUserCFrame(Enum.UserCFrame.LeftHand)
		local v81 = v_u_9:GetUserCFrame(Enum.UserCFrame.RightHand)
		local v82 = v77.Position - v80.Position
		local v83 = v77.Position - v81.Position
		local v84 = v82.X
		local v85 = v82.Z
		local v86 = -math.atan2(v84, v85)
		local v87 = v83.X
		local v88 = v83.Z
		local v89 = (-math.atan2(v87, v88) - v86 + 12.566370614359172) % 6.283185307179586
		if v89 > 3.141592653589793 then
			v89 = v89 - 6.283185307179586
		end
		local v90 = (v86 + v89 / 2 + 12.566370614359172) % 6.283185307179586
		if v90 > 3.141592653589793 then
			v90 = v90 - 6.283185307179586
		end
		local v91 = (v79 - p76.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v91 > 3.141592653589793 then
			v91 = v91 - 6.283185307179586
		end
		local v92 = (v90 - p76.currentTorsoAngle + 12.566370614359172) % 6.283185307179586
		if v92 > 3.141592653589793 then
			v92 = v92 - 6.283185307179586
		end
		local v93
		if v92 > -1.5707963267948966 then
			v93 = v92 < 1.5707963267948966
		else
			v93 = false
		end
		if not v93 then
			v92 = v91
		end
		local v94 = math.min(v92, v91)
		local v95 = math.max(v92, v91)
		local v96 = 0
		if v94 > 0 then
			v95 = v94
		elseif v95 >= 0 then
			v95 = v96
		end
		p76.currentTorsoAngle = v95 + p76.currentTorsoAngle
	else
		p76.currentTorsoAngle = v79
	end
	return CFrame.new(v77.Position) * CFrame.fromEulerAnglesYXZ(0, -p76.currentTorsoAngle, 0)
end
function v_u_1.GetActiveController(p97) -- name: GetActiveController
	return p97.activeController
end
function v_u_1.UpdateAbilitiesControllers(p98) -- name: UpdateAbilitiesControllers
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_28, (ref) v_u_27, (ref) v_u_34, (copy) v_u_30, (copy) v_u_31
	local v99 = p98.enabled and p98.touchControlFrame
	if v99 then
		if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
			v99 = (p98.activeControlModule == v_u_29 or p98.activeControlModule == v_u_28) and true or p98.activeControlModule == v_u_27
		else
			v99 = false
		end
	end
	local v100
	if v99 then
		v100 = not v_u_34:isEnabled()
	else
		v100 = v99
	end
	if v99 then
		v99 = v_u_34:isEnabled()
	end
	if v100 then
		if not p98.controllers[v_u_30] then
			p98.controllers[v_u_30] = v_u_30.new(p98.data)
		end
		p98.touchJumpController = p98.controllers[v_u_30]
		p98.touchJumpController:Enable(true, p98.touchControlFrame)
	elseif p98.touchJumpController then
		p98.touchJumpController:Enable(false)
	end
	if v99 then
		if not p98.controllers[v_u_31] then
			p98.controllers[v_u_31] = v_u_31.new(p98.touchControlFrame)
		end
		p98.touchAbilitiesController = p98.controllers[v_u_31]
		p98.touchAbilitiesController:Enable(true)
	elseif p98.touchAbilitiesController then
		p98.touchAbilitiesController:Enable(false)
	end
end
function v_u_1.UpdateActiveControlModuleEnabled(p_u_101) -- name: UpdateActiveControlModuleEnabled
	-- upvalues: (copy) v_u_14, (ref) v_u_34, (copy) v_u_2, (copy) v_u_4, (copy) v_u_29, (copy) v_u_28, (ref) v_u_27, (copy) v_u_30, (copy) v_u_5
	local function v102()
		-- upvalues: (ref) v_u_14, (copy) p_u_101, (ref) v_u_34, (ref) v_u_2
		if v_u_14 then
			p_u_101.enabled = false
		end
		p_u_101.activeController:Enable(false)
		if v_u_14 then
			p_u_101:UpdateAbilitiesControllers()
		elseif p_u_101.touchJumpController then
			p_u_101.touchJumpController:Enable(false)
		end
		if p_u_101.moveFunction and not (v_u_14 and v_u_34:isEnabled()) then
			p_u_101.moveFunction(v_u_2.LocalPlayer, Vector3.new(0, 0, 0), true)
		end
	end
	local function v103()
		-- upvalues: (ref) v_u_14, (copy) p_u_101, (ref) v_u_4, (ref) v_u_29, (ref) v_u_28, (ref) v_u_27, (ref) v_u_30, (ref) v_u_2
		if v_u_14 then
			p_u_101.enabled = true
			p_u_101:UpdateAbilitiesControllers()
		elseif p_u_101.touchControlFrame and (v_u_4.PreferredInput == Enum.PreferredInput.Touch and (p_u_101.activeControlModule == v_u_29 or (p_u_101.activeControlModule == v_u_28 or p_u_101.activeControlModule == v_u_27))) then
			if not p_u_101.controllers[v_u_30] then
				p_u_101.controllers[v_u_30] = v_u_30.new(p_u_101.data)
			end
			p_u_101.touchJumpController = p_u_101.controllers[v_u_30]
			p_u_101.touchJumpController:Enable(true, p_u_101.touchControlFrame)
		elseif p_u_101.touchJumpController then
			p_u_101.touchJumpController:Enable(false)
		end
		if p_u_101.activeControlModule == v_u_29 then
			p_u_101.activeController:Enable(true, v_u_2.LocalPlayer.DevComputerMovementMode == Enum.DevComputerMovementMode.UserChoice, p_u_101.touchJumpController)
			return
		elseif p_u_101.touchControlFrame then
			p_u_101.activeController:Enable(true, p_u_101.touchControlFrame)
		else
			p_u_101.activeController:Enable(true)
		end
	end
	if p_u_101.activeController then
		if p_u_101.controlsEnabled then
			if v_u_5.TouchControlsEnabled or (v_u_4.PreferredInput ~= Enum.PreferredInput.Touch or p_u_101.activeControlModule ~= v_u_29 and (p_u_101.activeControlModule ~= v_u_28 and p_u_101.activeControlModule ~= v_u_27)) then
				v103()
			else
				v102()
			end
		else
			v102()
			return
		end
	else
		return
	end
end
function v_u_1.Enable(p104, p105) -- name: Enable
	local v106 = p105 == nil and true or p105
	if p104.controlsEnabled == v106 then
		return
	else
		p104.controlsEnabled = v106
		if p104.activeController then
			p104:UpdateActiveControlModuleEnabled()
		end
	end
end
function v_u_1.Disable(p107) -- name: Disable
	p107:Enable(false)
end
function v_u_1.SelectComputerMovementModule(_) -- name: SelectComputerMovementModule
	-- upvalues: (copy) v_u_19, (copy) v_u_4, (copy) v_u_24, (copy) v_u_2, (copy) v_u_8, (copy) v_u_29, (copy) v_u_37
	local v_u_108 = false
	if v_u_19 then
		local function v109()
			-- upvalues: (ref) v_u_108, (ref) v_u_4
			v_u_108 = v_u_4.PreferredInput == Enum.PreferredInput.MicroGamepad
		end
		pcall(v109)
	end
	if v_u_4.PreferredInput == Enum.PreferredInput.KeyboardAndMouse or (v_u_4.PreferredInput == Enum.PreferredInput.Gamepad or v_u_108) then
		local v110 = v_u_24
		local v111 = v_u_2.LocalPlayer.DevComputerMovementMode
		if v111 == Enum.DevComputerMovementMode.UserChoice then
			if v_u_8.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove then
				v110 = v_u_29
			end
		else
			v110 = v_u_37[v111]
			if not v110 and v111 ~= Enum.DevComputerMovementMode.Scriptable then
				warn("No character control module is associated with DevComputerMovementMode ", v111)
			end
		end
		if v110 then
			return v110, true
		elseif v111 == Enum.DevComputerMovementMode.Scriptable then
			return nil, true
		else
			return nil, false
		end
	else
		return nil, false
	end
end
function v_u_1.SelectTouchModule(_) -- name: SelectTouchModule
	-- upvalues: (copy) v_u_2, (copy) v_u_37, (copy) v_u_8
	local v112 = v_u_2.LocalPlayer.DevTouchMovementMode
	local v113
	if v112 == Enum.DevTouchMovementMode.UserChoice then
		v113 = v_u_37[v_u_8.TouchMovementMode]
	else
		if v112 == Enum.DevTouchMovementMode.Scriptable then
			return nil, true
		end
		v113 = v_u_37[v112]
	end
	return v113, true
end
function v_u_1.calculateRawMoveVector(p114, p115, p116) -- name: calculateRawMoveVector
	-- upvalues: (copy) v_u_6, (copy) v_u_9, (copy) v_u_35
	local v117 = v_u_6.CurrentCamera
	if not v117 then
		return p116
	end
	local v118 = v117.CFrame
	if v_u_9.VREnabled and p115.RootPart then
		local v119 = p114:GetEstimatedVRTorsoFrame()
		if (v117.Focus.Position - v118.Position).Magnitude < 3 then
			v118 = v118 * v119
		else
			v118 = v117.CFrame * (v119.Rotation + v119.Position * v117.HeadScale)
		end
	end
	if p115:GetState() ~= Enum.HumanoidStateType.Swimming then
		local _, _, _, v124, v121, v122, _, _, v123, _, _, v124 = v118:GetComponents()
		if v123 >= 1 or v123 <= -1 then
			v122 = -v121 * math.sign(v123)
		end
		local v125 = v124 * v124 + v122 * v122
		local v126 = math.sqrt(v125)
		local v127 = (v124 * p116.X + v122 * p116.Z) / v126
		local v128 = (v124 * p116.Z - v122 * p116.X) / v126
		return Vector3.new(v127, 0, v128)
	end
	if not v_u_9.VREnabled then
		return v118:VectorToWorldSpace(p116)
	end
	local v129 = p116.X
	local v130 = p116.Z
	local v131 = Vector3.new(v129, 0, v130)
	if v131.Magnitude < 0.01 then
		return Vector3.new(0, 0, 0)
	end
	local v132 = not (v_u_35 and v_u_35.Enabled) and 0 or -v_u_35:GetState().Y / 2.31
	local v133 = -v131.X
	local v134 = -v131.Z
	local v135 = math.atan2(v133, v134)
	local _, v136, _ = v118:ToEulerAnglesYXZ()
	local v137 = v135 + v136
	return CFrame.fromEulerAnglesYXZ(v132, v137, 0).LookVector
end
function v_u_1.initialize(p138, p139) -- name: initialize
	-- upvalues: (copy) v_u_24, (copy) v_u_14, (copy) v_u_26
	p138.data = p139
	p138:UpdateMovementMode()
	v_u_24.initializeActions(p138.data)
	if v_u_14 then
		v_u_26.setupSlotActions(p138.data.player, p138.data.isServerAuthority)
	end
end
function v_u_1.Update(p140, p141, p142) -- name: Update
	-- upvalues: (copy) v_u_21, (copy) v_u_24, (copy) v_u_9, (copy) v_u_16, (copy) v_u_14, (ref) v_u_34, (copy) v_u_25, (copy) v_u_2, (copy) v_u_18
	local v143 = p141.player
	assert(v143)
	local v144 = p141.character
	assert(v144)
	if v_u_21 then
		if not p140.humanoid then
			return
		end
		if not p141.playerModule.ControlModule.Enabled then
			p141.isJumping = false
			p141.moveVector = Vector2.new()
			p141.worldMoveVector = Vector3.new()
			v_u_24.update(p141)
			p140.inputMoveVector = Vector3.new()
			if p140.vehicleController then
				p140.vehicleController:Update(Vector3.new(), true)
			end
			p140:characterMove(p141)
			return
		end
	end
	v_u_24.initializeActions(p141)
	if v_u_21 or p141.actions.MoveAction and p141.actions.JumpAction then
		if p140.activeController and (p140.activeController.enabled and p140.humanoid) then
			v_u_24.update(p141)
			p140:GetClickToMoveController():Update(p141, p142)
			local v145 = p141.moveVector.X
			local v146 = -p141.moveVector.Y
			local v147 = Vector3.new(v145, 0, v146)
			if p140.vehicleController then
				local v148
				v147, v148 = p140.vehicleController:Update(v147, true)
				_ = v148
			end
			local v149 = p140:calculateRawMoveVector(p140.humanoid, v147)
			p140.inputMoveVector = v149
			if v_u_9.VREnabled then
				v149 = p140:updateVRMoveVector(v149)
			end
			if v_u_21 then
				p141.worldMoveVector = v149
				p140:characterMove(p141)
				return
			end
			if v_u_16 then
				if not p141.isServerAuthority then
					if v_u_14 and v_u_34:isEnabled() then
						v_u_25.writeInputToPCS(v_u_2.LocalPlayer, p140, false)
					else
						p140.moveFunction(v_u_2.LocalPlayer, v149, false)
						p140.humanoid.Jump = p141.isJumping
					end
				end
			elseif not (v_u_18 and p141.isServerAuthority or v_u_14 and v_u_34:isEnabled()) then
				p140.moveFunction(v_u_2.LocalPlayer, v149, false)
				p140.humanoid.Jump = p141.isJumping
			end
		end
	end
end
function v_u_1.characterMove(p150, p151) -- name: characterMove
	-- upvalues: (copy) v_u_16, (copy) v_u_14, (ref) v_u_34, (copy) v_u_25, (copy) v_u_2, (copy) v_u_18
	if v_u_16 then
		if not p151.isServerAuthority then
			if v_u_14 and v_u_34:isEnabled() then
				v_u_25.writeInputToPCS(v_u_2.LocalPlayer, p150, false)
			else
				p150.moveFunction(v_u_2.LocalPlayer, p151.worldMoveVector, false)
				p150.humanoid.Jump = p151.isJumping
			end
		end
	elseif not (v_u_18 and p151.isServerAuthority or v_u_14 and v_u_34:isEnabled()) then
		p150.moveFunction(v_u_2.LocalPlayer, p151.worldMoveVector, false)
		p150.humanoid.Jump = p151.isJumping
	end
end
function v_u_1.updateVRMoveVector(p152, p153) -- name: updateVRMoveVector
	-- upvalues: (copy) v_u_13, (copy) v_u_36, (copy) v_u_9
	local v154 = workspace.CurrentCamera
	local v155 = v154.Focus.Position - v154.CFrame.Position
	local v156
	if v_u_13 then
		v156 = v_u_36.inFirstPerson
	else
		v156 = v155.Magnitude < 5
	end
	if p153.Magnitude ~= 0 or (not v156 or (not v_u_9.AvatarGestures or (not p152.humanoid or p152.humanoid.Sit))) then
		return p153
	end
	local v157 = v_u_9:GetUserCFrame(Enum.UserCFrame.Head)
	local v158 = v157.Rotation + v157.Position * v154.HeadScale
	local v159 = -0.7 * p152.humanoid.RootPart.Size.Y / 2
	local v160 = (v154.CFrame * v158 * CFrame.new(0, v159, 0)).Position - p152.humanoid.RootPart.CFrame.Position
	local v161 = v160.x
	local v162 = v160.z
	local v163 = Vector3.new(v161, 0, v162)
	if v_u_13 then
		local v164 = (v154.Focus.Position - v154.CFrame.Position).Magnitude
		local v165 = 4 * v154.HeadScale
		if math.max(v165, 1) < v164 then
			return p153
		end
	end
	return v163
end
function v_u_1.OnHumanoidSeated(p166, p167, p168) -- name: OnHumanoidSeated
	if p167 then
		if p168 and p168:IsA("VehicleSeat") then
			if not p166.vehicleController then
				p166.vehicleController = p166.vehicleController.new()
			end
			p166.vehicleController:Enable(true, p168)
			return
		end
	elseif p166.vehicleController then
		p166.vehicleController:Enable(false, p168)
	end
end
function v_u_1.OnCharacterAdded(p_u_169, p170) -- name: OnCharacterAdded
	p_u_169.humanoid = p170:FindFirstChildOfClass("Humanoid")
	while not p_u_169.humanoid do
		p170.ChildAdded:wait()
		p_u_169.humanoid = p170:FindFirstChildOfClass("Humanoid")
	end
	if p_u_169.humanoidSeatedConn then
		p_u_169.humanoidSeatedConn:Disconnect()
		p_u_169.humanoidSeatedConn = nil
	end
	p_u_169.humanoidSeatedConn = p_u_169.humanoid.Seated:Connect(function(p171, p172)
		-- upvalues: (copy) p_u_169
		p_u_169:OnHumanoidSeated(p171, p172)
	end)
	p_u_169:UpdateMovementMode()
end
function v_u_1.OnCharacterRemoving(p173, _) -- name: OnCharacterRemoving
	p173.humanoid = nil
	p173:UpdateMovementMode()
end
function v_u_1.UpdateTouchGuiVisibility(p174) -- name: UpdateTouchGuiVisibility
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v175 = p174.humanoid and v_u_5.TouchControlsEnabled
	if v175 then
		v175 = v_u_4.PreferredInput == Enum.PreferredInput.Touch
	end
	if v175 and not p174.touchGui then
		p174:CreateTouchGuiContainer()
	end
	if p174.touchGui then
		p174.touchGui.Enabled = v175 and true or false
	end
end
function v_u_1.SwitchToController(p176, p177) -- name: SwitchToController
	if p177 then
		if not p176.controllers[p177] then
			p176.controllers[p177] = p177.new(p176.data)
		end
		if p176.activeController ~= p176.controllers[p177] then
			if p176.activeController then
				p176.activeController:Enable(false)
			end
			p176.activeController = p176.controllers[p177]
			p176.activeControlModule = p177
			p176:UpdateActiveControlModuleEnabled()
		end
	else
		if p176.activeController then
			p176.activeController:Enable(false)
		end
		p176.activeController = nil
		p176.activeControlModule = nil
	end
end
function v_u_1.UpdateMovementMode(p178) -- name: UpdateMovementMode
	-- upvalues: (copy) v_u_4
	p178:UpdateTouchGuiVisibility()
	if v_u_4.PreferredInput == Enum.PreferredInput.Touch then
		local v179, v180 = p178:SelectTouchModule()
		if v180 and p178.touchControlFrame then
			p178:SwitchToController(v179)
			return
		end
	else
		p178:SwitchToController((p178:SelectComputerMovementModule()))
	end
end
function v_u_1.CreateTouchGuiContainer(p181) -- name: CreateTouchGuiContainer
	-- upvalues: (copy) v_u_14, (copy) v_u_20
	if p181.playerGui then
		if p181.touchGui then
			p181.touchGui:Destroy()
		end
		p181.touchGui = Instance.new("ScreenGui")
		p181.touchGui.Name = "TouchGui"
		p181.touchGui.ResetOnSpawn = false
		p181.touchGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		if v_u_14 and v_u_20 then
			p181.touchGui.ScreenInsets = Enum.ScreenInsets.DeviceSafeInsets
		end
		p181.touchGui.ClipToDeviceSafeArea = false
		p181.touchControlFrame = Instance.new("Frame")
		p181.touchControlFrame.Name = "TouchControlFrame"
		p181.touchControlFrame.Size = UDim2.new(1, 0, 1, 0)
		p181.touchControlFrame.BackgroundTransparency = 1
		p181.touchControlFrame.Parent = p181.touchGui
		p181.touchGui.Parent = p181.playerGui
	end
end
function v_u_1.GetClickToMoveController(p182) -- name: GetClickToMoveController
	-- upvalues: (copy) v_u_29
	if not p182.controllers[v_u_29] then
		p182.controllers[v_u_29] = v_u_29.new()
	end
	return p182.controllers[v_u_29]
end
function v_u_1.ProcessInputs(_, p183, _) -- name: ProcessInputs
	-- upvalues: (copy) v_u_14, (ref) v_u_33, (copy) v_u_16, (copy) v_u_25
	if v_u_14 then
		if not v_u_33.get(p183):isEnabled() then
			if v_u_16 then
				v_u_25.processPCSInputs(p183)
			else
				v_u_25.SendInputToHumanoidForServerAuth(p183)
			end
		end
	else
		if v_u_16 then
			v_u_25.processPCSInputs(p183)
			return
		end
		local v184 = p183.Character
		if v184 == nil then
			return
		end
		local v185 = v184:FindFirstChild("Humanoid")
		if v185 == nil then
			return
		end
		local v186 = p183:FindFirstChild("InputContexts")
		if v186 == nil then
			return
		end
		local v187 = v186:FindFirstChild("CharacterContext")
		if v187 == nil then
			return
		end
		local v188 = v187.MoveAction
		local v189 = v187.RotationAction
		local v190 = v187.JumpAction
		local v191
		if v188 == nil then
			v191 = Vector2.new(0, 0)
		else
			v191 = v188:GetState()
		end
		local v192 = p183:GetCameraState().CFrame.LookVector
		if v191.X == v191.X and (v191.Y == v191.Y and v191.X ~= (1 / 0)) and v191.Y ~= (1 / 0) and (v192.X == v192.X and (v192.Y == v192.Y and (v192.Z == v192.Z and (v192.X ~= (1 / 0) and v192.Y ~= (1 / 0)))) and v192.Z ~= (1 / 0) and v192.Magnitude > 0) then
			if v185:GetState() ~= Enum.HumanoidStateType.Swimming then
				local v193 = v192.X
				local v194 = v192.Z
				v192 = Vector3.new(v193, 0, v194).Unit
			end
			local v195 = v192:Cross(Vector3.new(0, 1, 0)).Unit
			v185:Move(v192 * v191.Y + v195 * v191.X)
			if v189:GetState() then
				v185.AutoRotate = false
				if v185.SeatPart == nil and (v185.RootPart ~= nil and not (v185.Sit or v185.RootPart:IsGrounded())) then
					v185.RootPart.CFrame = CFrame.new(v185.RootPart.CFrame.Position, v185.RootPart.CFrame.Position + v192)
				end
			else
				v185.AutoRotate = true
			end
		end
		local v196
		if v190 == nil then
			v196 = false
		else
			v196 = v190:GetState()
		end
		v185.Jump = v196
	end
end
if v_u_3:IsClient() then
	return v_u_1.new()
else
	return v_u_1
end