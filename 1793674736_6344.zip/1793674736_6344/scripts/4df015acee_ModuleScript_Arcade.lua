local v1 = {
	["snake"] = {
		["width"] = 17,
		["height"] = 13,
		["roundSeconds"] = 120,
		["startLength"] = 3,
		["interval"] = 0.16,
		["speedUp"] = 0.002,
		["minInterval"] = 0.085,
		["orbPoints"] = 10,
		["comboSeconds"] = 3.5,
		["comboMax"] = 5,
		["goldenEvery"] = 5,
		["goldenSeconds"] = 6,
		["goldenPoints"] = 50,
		["goldenGrow"] = 2
	},
	["blocks"] = {
		["width"] = 10,
		["height"] = 18,
		["hidden"] = 2,
		["roundSeconds"] = 150,
		["tickRate"] = 60,
		["linesPerLevel"] = 6,
		["gravity"] = nil,
		["lockTicks"] = 30,
		["lockResets"] = 15,
		["lineScores"] = nil,
		["comboPoints"] = 50,
		["softPoints"] = 1,
		["hardPoints"] = 2,
		["gravity"] = {
			48,
			40,
			33,
			27,
			22,
			18,
			14,
			11,
			9,
			7,
			6,
			5,
			4,
			3
		},
		["lineScores"] = {
			100,
			300,
			500,
			800
		}
	},
	["expire"] = 900,
	["grace"] = 3,
	["graceShare"] = 0.03,
	["maxInputs"] = 12000,
	["startBurst"] = 3,
	["startEvery"] = 4
}
return v1