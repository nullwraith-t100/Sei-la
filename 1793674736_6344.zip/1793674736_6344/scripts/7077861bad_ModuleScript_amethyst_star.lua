local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("9B3DE6")
local v_u_8 = Color3.fromHex("E9D2FF")
local v_u_9 = Color3.fromRGB(62, 18, 112)
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = CFrame.lookAt(Vector3.new(0, 0, 0), Vector3.new(1, 1, 1)):Inverse()
local v_u_12 = CFrame.Angles(1.5707963267948966, 0, 0) * v_u_11
local function v_u_30(p13, p14) -- name: hexBars
	local v15 = {}
	for v16 = 0, 1 do
		for v17 = 0, 2 do
			local v18 = v16 * 180 + 90 + v17 * 120
			local v19 = math.rad(v18)
			local v20 = v16 * 180 + 90 + (v17 + 1) * 120
			local v21 = math.rad(v20)
			local v22 = math.cos(v19)
			local v23 = math.sin(v19)
			local v24 = Vector3.new(v22, 0, v23) * p13
			local v25 = math.cos(v21)
			local v26 = math.sin(v21)
			local v27 = Vector3.new(v25, 0, v26) * p13
			local v28 = {
				["off"] = CFrame.lookAt((v24 + v27) / 2, v27)
			}
			local v29 = (v27 - v24).Magnitude + p14
			v28.size = Vector3.new(p14, 0.12, v29)
			table.insert(v15, v28)
		end
	end
	return v15
end
local function v_u_39(p31) -- name: starPoints
	local v32 = {}
	for v33 = 0, 5 do
		local v34 = v33 * 60 + 90
		local v35 = math.rad(v34)
		local v36 = math.cos(v35)
		local v37 = math.sin(v35)
		local v38 = Vector3.new(v36, 0, v37) * p31
		table.insert(v32, v38)
	end
	return v32
end
local function v_u_56(p40, p41, p42, p43, p44) -- name: starFlash
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (copy) v_u_10
	local v45 = CFrame.lookAt
	local v46 = v_u_3.CurrentCamera
	local v47
	if v46 then
		local v48 = v46.CFrame.Position - p41
		v47 = v48.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v48.Unit
	else
		v47 = Vector3.new(0, 1, 0)
	end
	local v49 = v45(p41, p41 + v47)
	for v50 = 0, 2 do
		local v51 = v49 * CFrame.Angles(0, 0, 1.5707963267948966 + v50 * 3.141592653589793 / 3)
		local v52 = v_u_4.part
		local v53 = p43 * 0.3
		local v54 = p43 * 0.06 + 0.2
		local v55 = v52(Vector3.new(v53, v54, 0.1), v51, p42)
		v_u_4.tween(v55, p44, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(p43, 0.05, 0.05)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		v_u_1:AddItem(v55, p44 + 0.05)
	end
	p40.pop(p41, v_u_10, p43 * 0.22, p43 * 0.05, p44)
end
return function(p_u_57)
	-- upvalues: (copy) v_u_7, (copy) v_u_12, (copy) v_u_8, (copy) v_u_9, (copy) v_u_30, (copy) v_u_39, (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_11, (copy) v_u_56, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	local function v_u_76(p58, p59, p60, p61) -- name: crystalRig
		-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_12, (ref) v_u_8
		local v62 = p_u_57.newRig()
		local v63 = p58 - p59 * 0.5
		local v64 = math.max(v63, p59)
		for v65 = 0, 1 do
			p_u_57.rigAdd(v62, Vector3.new(p59, v64, p59), CFrame.new(0, v64 / 2, 0) * CFrame.Angles(0, v65 * 3.141592653589793 / 4, 0), v_u_7, 0.12, Enum.Material.Glass, p60).Reflectance = 0.25
		end
		local v66 = p_u_57.rigAdd
		local v67 = Vector3.new(1, 1, 1) * p59 * 0.86
		local v68 = CFrame.new(0, v64, 0) * v_u_12
		local v69
		if p61 then
			v69 = v_u_8
		else
			v69 = v_u_7
		end
		local v70 = 0.05
		local v71
		if p61 then
			v71 = Enum.Material.Neon
		else
			v71 = Enum.Material.Glass
		end
		v66(v62, v67, v68, v69, v70, v71, p60).Reflectance = 0.2
		if p61 then
			local v72 = p_u_57.rigAdd
			local v73 = p59 * 0.32
			local v74 = v64 * 0.92
			local v75 = p59 * 0.32
			v72(v62, Vector3.new(v73, v74, v75), CFrame.new(0, v64 / 2, 0) * CFrame.Angles(0, 0.39269908169872414, 0), v_u_8, 0, Enum.Material.Neon, p60)
		end
		return v62
	end
	local function v_u_83(p77, p78, p79, p80, p81) -- name: breakCrystal
		-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
		p_u_57.rigDestroy(p77)
		if p80 > 0 then
			local v82 = { v_u_7, v_u_8, v_u_9 }
			p_u_57.chunks(p78, v82, p80, 22, p79 * 0.22, 0.55, true, 0.6)
		end
		if p81 then
			p_u_57.glint(p78, v_u_8, p79 * 0.8, 0.15)
		end
	end
	local function v_u_100(p84, p_u_85, p86, p87, p_u_88, p89, p_u_90) -- name: growCrystal
		-- upvalues: (copy) v_u_76, (copy) p_u_57, (copy) v_u_83
		local v_u_91 = v_u_76(p_u_85, p86, p_u_88 + 1, p89)
		local v_u_92 = CFrame.new(p84) * p87
		local v_u_93 = os.clock()
		p_u_57.runNow(function()
			-- upvalues: (copy) v_u_93, (ref) p_u_57, (copy) v_u_91, (copy) v_u_92, (copy) p_u_88, (ref) v_u_83, (copy) p_u_85, (copy) p_u_90
			local v94 = os.clock() - v_u_93
			local v95 = v94 / 0.1
			local v96 = math.clamp(v95, 0, 1)
			local v97 = 1 - (1 - v96) ^ 3
			local v98 = v96 * 3.141592653589793
			local v99 = v97 * (math.sin(v98) * 0.15 + 1)
			p_u_57.rigPlace(v_u_91, v_u_92, (math.max(v99, 0.03)))
			if p_u_88 + 0.1 >= v94 then
				return true
			end
			v_u_83(v_u_91, (v_u_92 * CFrame.new(0, p_u_85 * 0.5, 0)).Position, p_u_85, p_u_90, true)
			return false
		end)
	end
	local function v_u_124(p101, p102, p103, p_u_104, p_u_105, p106) -- name: starSeal
		-- upvalues: (copy) p_u_57, (ref) v_u_30, (ref) v_u_7, (ref) v_u_8, (ref) v_u_39, (ref) v_u_12
		local v_u_107 = p_u_57.ground(p101, 0.12)
		local v_u_108 = p_u_57.newRig()
		for _, v109 in v_u_30(p102, p103) do
			p_u_57.rigAdd(v_u_108, v109.size, v109.off, v_u_7, 0, Enum.Material.Neon, p_u_105 + 1)
		end
		if not p106 then
			for _, v110 in v_u_30(p102, p103 * 2.8) do
				p_u_57.rigAdd(v_u_108, v110.size - Vector3.new(0, 0.04, 0), v110.off - Vector3.new(0, 0.03, 0), v_u_8, 0.72, Enum.Material.Neon, p_u_105 + 1)
			end
		end
		for _, v111 in v_u_39(p102) do
			local v112 = p_u_57.rigAdd
			local v113 = Vector3.new(1, 1, 1) * p103 * 2.2
			local v114 = CFrame.new
			local v115 = p103 * 0.8
			v112(v_u_108, v113, v114(v111 + Vector3.new(0, v115, 0)) * v_u_12, v_u_8, 0, Enum.Material.Neon, p_u_105 + 1)
		end
		local v_u_116 = os.clock()
		p_u_57.runNow(function()
			-- upvalues: (copy) v_u_116, (copy) p_u_104, (ref) p_u_57, (copy) v_u_108, (copy) v_u_107, (copy) p_u_105
			local v117 = os.clock() - v_u_116
			local v118 = p_u_104
			local v119 = v117 / math.max(v118, 0.05)
			local v120 = math.clamp(v119, 0, 1)
			p_u_57.rigPlace(v_u_108, CFrame.new(v_u_107) * CFrame.Angles(0, v117 * 0.5, 0), (1 - (1 - v120) ^ 2) * 0.94 + 0.06)
			if p_u_105 < v117 then
				local v121 = p_u_57.rigFade
				local v122 = v_u_108
				local v123 = (v117 - p_u_105) / 0.3
				v121(v122, (math.clamp(v123, 0, 1)))
			end
			if p_u_105 + 0.3 >= v117 then
				return true
			end
			p_u_57.rigDestroy(v_u_108)
			return false
		end)
	end
	local function v_u_162(p125, p126, p_u_127) -- name: encase
		-- upvalues: (copy) p_u_57, (ref) v_u_3, (copy) v_u_76, (ref) v_u_7, (ref) v_u_6, (copy) v_u_83
		local v128 = p125.Y - p_u_57.FLOOR
		local v_u_129 = math.max(v128, 1.2) * 2
		local v130 = p_u_57.ground(p125, 0)
		local v131 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_132
		if v131 then
			v_u_132 = v131:FindFirstChild("Foe" .. p126)
		else
			v_u_132 = nil
		end
		local v133 = math.random() * 3.141592653589793 * 2
		local v_u_134 = {}
		for v135 = 0, 2 do
			local v136 = v133 + v135 * 3.141592653589793 * 2 / 3
			local v137 = math.cos(v136)
			local v138 = math.sin(v136)
			local v139 = v130 + Vector3.new(v137, 0, v138) * v_u_129 * 0.38
			local v140 = {}
			local v141 = v_u_76
			local v142 = v_u_129 * 1.15
			local v143 = v_u_129 * 0.3
			v140.rig = v141(v142, math.max(v143, 0.8), p_u_127 + 1, false)
			local v144 = CFrame.new(v139)
			local v145 = v139.X - v130.X
			local v146 = v139.Z - v130.Z
			local v147 = Vector3.new(v145, 0, v146)
			local v148
			if v147.Magnitude < 0.001 then
				v148 = CFrame.identity
			else
				v148 = CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v147.Unit), -0.3839724354387525)
			end
			v140.cf = v144 * v148
			table.insert(v_u_134, v140)
		end
		local v_u_149 = p_u_57.sigil(CFrame.new(p_u_57.ground(p125, 0.2)), v_u_129 * 0.7, v_u_7, v_u_6.Ring, p_u_127, 0.6)
		local v_u_150 = os.clock()
		p_u_57.runNow(function()
			-- upvalues: (copy) v_u_150, (copy) v_u_134, (ref) p_u_57, (copy) v_u_132, (copy) p_u_127, (copy) v_u_129, (ref) v_u_83, (copy) v_u_149
			local v151 = os.clock() - v_u_150
			if v151 < 0.15 then
				local v152 = v151 / 0.1
				local v153 = math.clamp(v152, 0, 1)
				local v154 = 1 - (1 - v153) ^ 3
				local v155 = v153 * 3.141592653589793
				local v156 = v154 * (math.sin(v155) * 0.12 + 1)
				for _, v157 in v_u_134 do
					p_u_57.rigPlace(v157.rig, v157.cf, (math.max(v156, 0.03)))
				end
			end
			local v158
			if v_u_132 == nil then
				v158 = false
			else
				v158 = v_u_132.Parent == nil
			end
			if p_u_127 >= v151 and not v158 then
				return true
			end
			for v159, v160 in v_u_134 do
				local v161 = (v160.cf * CFrame.new(0, v_u_129 * 0.5, 0)).Position
				v_u_83(v160.rig, v161, v_u_129, v159 == 1 and 4 or 0, v159 == 1)
			end
			if v158 then
				v_u_149:Destroy()
			end
			return false
		end)
	end
	local v194 = {
		["amethyst_star_a"] = {
			["cast"] = function(p163) -- name: cast
				-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8
				p_u_57.muzzle(p163, v_u_7, 0.9)
				if not p163.lite then
					v_u_56(p_u_57, p163.eye + p163.dir * 1.3, v_u_8, 2.4, 0.12)
				end
			end,
			["shot"] = function(p164, p165) -- name: shardShot
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (copy) p_u_57
				local v166 = p164.size
				local v167 = p164.lite
				local v168 = 2.6 * v166
				local v169 = 0.62 * v166
				local v170 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p165, v_u_7, {
					["transparency"] = 1
				})
				local v171 = {}
				for v172 = 0, v167 and 0 or 1 do
					local v173 = v_u_4.part(Vector3.new(v169, v169, v168), p165, v_u_7, {
						["material"] = nil,
						["transparency"] = 0.1,
						["material"] = Enum.Material.Glass
					})
					v173.Reflectance = 0.25
					local v174 = {
						["p"] = v173,
						["off"] = CFrame.Angles(0, 0, v172 * 3.141592653589793 / 4)
					}
					table.insert(v171, v174)
				end
				local v175 = {
					["p"] = v_u_4.part(Vector3.new(1, 1, 1) * v169 * 0.95, p165, v_u_8),
					["off"] = CFrame.new(0, 0, -v168 / 2) * v_u_11
				}
				table.insert(v171, v175)
				local v176 = {
					["p"] = v_u_4.part(Vector3.new(1, 1, 1) * v169 * 0.8, p165, v_u_7, {
						["material"] = nil,
						["transparency"] = 0.1,
						["material"] = Enum.Material.Glass
					}),
					["off"] = CFrame.new(0, 0, v168 / 2) * v_u_11
				}
				table.insert(v171, v176)
				local v177 = v_u_4.part
				local v178 = v169 * 0.35
				local v179 = v169 * 0.35
				local v180 = v168 * 0.9
				local v181 = {
					["p"] = v177(Vector3.new(v178, v179, v180), p165, v_u_8),
					["off"] = CFrame.identity
				}
				table.insert(v171, v181)
				local v182 = {}
				if not v167 then
					local v183 = v_u_4.part
					local v184 = Vector3.new(0.3, 0.3, 0.3) * v166
					local v185 = v_u_8
					table.insert(v182, v183(v184, p165, v185))
					local v186 = v_u_4.part
					local v187 = Vector3.new(0.3, 0.3, 0.3) * v166
					local v188 = v_u_8
					table.insert(v182, v186(v187, p165, v188))
				end
				p_u_57.streak(v170, v_u_7, v_u_8, 1.3 * v166, 0.14)
				if p164.mine then
					p_u_57.light(v170, v_u_7, 9 * v166)
				end
				return p_u_57.assemble(v170, v171, v182, 0.95 * v166, 16, {}, 0.14, 12)
			end,
			["impact"] = function(p189, p190) -- name: impact
				-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_6
				local v191 = p189.size
				p_u_57.burst("Impact", p190, v_u_7, 0.9 * v191)
				v_u_56(p_u_57, p190, v_u_8, 7 * v191, 0.2)
				p_u_57.pop(p190, v_u_7, 1.5 * v191, 6 * v191, 0.15, 0.25)
				if not p189.lite then
					local v192 = { v_u_7, v_u_8, v_u_9 }
					p_u_57.chunks(p190, v192, 5, 24, 0.45 * v191, 0.5, true, 0.6)
				end
				v_u_4.ring(p_u_57.ground(p190), v_u_7, 6 * v191, 0.25, v_u_6.Ring)
				p_u_57.hitSound(p190)
			end,
			["hit"] = function(_, p193, _) -- name: hit
				-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8
				p_u_57.burst("Impact", p193, v_u_7, 0.6)
				v_u_56(p_u_57, p193, v_u_8, 3, 0.12)
			end
		}
	}
	local v_u_195 = {}
	v194.amethyst_star_e = {
		["cast"] = function(p196) -- name: cast
			-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8
			p_u_57.skillCast(p196, v_u_7)
			v_u_56(p_u_57, p196.eye + p196.dir * 1.2, v_u_8, 5, 0.2)
		end,
		["windup"] = function(p197, p198, p199) -- name: windup
			-- upvalues: (copy) v_u_124, (copy) p_u_57, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7
			local v200 = p197.ability.radius
			v_u_124(p198, v200 * 0.92, 0.9, math.max(p199, 0.1), p199 + 0.9, p197.lite)
			p_u_57.sigil(CFrame.new(p_u_57.ground(p198, 0.15)), v200, v_u_8, v_u_6.Ring, p199 + 0.9, 0.8)
			p_u_57.sigil(CFrame.new(p_u_57.ground(p198, 0.17)), v200 * 0.42, v_u_7, v_u_6.MagicCircle, p199 + 0.9, -2)
		end,
		["land"] = function(p201, p202) -- name: land
			-- upvalues: (copy) p_u_57, (ref) v_u_39, (copy) v_u_100, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_8, (ref) v_u_5
			local v203 = p201.ability.radius
			local v204 = p201.lite
			local v205 = p_u_57.ground(p202)
			for v206, v207 in v_u_39(v203 * 0.92) do
				local v208 = v205 + v207
				local v209 = v_u_100
				local v210 = 5 + v206 % 2 * 2
				local v211 = 1.5
				local v212 = v208.X - v205.X
				local v213 = v208.Z - v205.Z
				local v214 = Vector3.new(v212, 0, v213)
				local v215
				if v214.Magnitude < 0.001 then
					v215 = CFrame.identity
				else
					v215 = CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v214.Unit), 0.24434609527920614)
				end
				v209(v208, v210, v211, v215, 0.55 + v206 * 0.03, not v204, v204 and 0 or 2)
			end
			if not v204 then
				for v216, v217 in v_u_39(v203 * 0.92 / 1.7320508075688772) do
					local v218 = v205 + CFrame.Angles(0, 0.5235987755982988, 0):VectorToWorldSpace(v217)
					local v219 = v_u_100
					local v220 = 3.4
					local v221 = 1.1
					local v222 = v218.X - v205.X
					local v223 = v218.Z - v205.Z
					local v224 = Vector3.new(v222, 0, v223)
					local v225
					if v224.Magnitude < 0.001 then
						v225 = CFrame.identity
					else
						v225 = CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v224.Unit), 0.4188790204786391)
					end
					v219(v218, v220, v221, v225, 0.45 + v216 * 0.03, false, 0)
				end
			end
			p_u_57.burst("Shockwave", v205 + Vector3.new(0, 0.3, 0), v_u_7, v203 / 20)
			v_u_4.ring(v205, v_u_7, v203, 0.45, v_u_6.Ring)
			v_u_4.ring(v205, v_u_8, v203 * 0.85, 0.35, v_u_6.SpeedLines)
			p_u_57.pop(p_u_57.ground(p202, 1), v_u_8, 3, v203 * 0.6, 0.25, 0.55)
			v_u_5.play("Burst", {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v205
			})
			if p201.mine then
				v_u_4.shake(0.22, 0.25)
			end
		end,
		["hit"] = function(p_u_226, p227, p228) -- name: hit
			-- upvalues: (copy) p_u_57, (ref) v_u_7, (copy) v_u_195, (ref) v_u_56, (ref) v_u_8, (copy) v_u_162
			local v229 = p_u_226.ability.freeze or 4
			p_u_57.burst("Impact", p227, v_u_7, 0.8)
			local v230 = (v_u_195[p_u_226] or 0) + 1
			v_u_195[p_u_226] = v230
			if v230 == 1 then
				task.delay(v229 + 1, function()
					-- upvalues: (ref) v_u_195, (copy) p_u_226
					v_u_195[p_u_226] = nil
				end)
			end
			if v230 > 12 then
				v_u_56(p_u_57, p227, v_u_8, 4, 0.18)
			else
				v_u_162(p227, p228, v229)
			end
		end
	}
	local v_u_231 = {}
	v194.amethyst_star_r = {
		["cast"] = function(p232) -- name: cast
			-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_8, (ref) v_u_56
			p_u_57.skillCast(p232, v_u_7, true)
			p_u_57.burst("Flash", p232.eye, v_u_8, 0.45)
			v_u_56(p_u_57, p232.eye + p232.dir * 1.5, v_u_8, 8, 0.25)
		end,
		["windup"] = function(p_u_233, p234, p_u_235) -- name: windup
			-- upvalues: (copy) p_u_57, (copy) v_u_124, (ref) v_u_8, (ref) v_u_6, (ref) v_u_7, (ref) v_u_39, (copy) v_u_76, (ref) v_u_9, (copy) v_u_231, (ref) v_u_10, (ref) v_u_4, (ref) v_u_1
			local v236 = p_u_233.ability.radius
			local v237 = p_u_233.lite
			local v238 = p_u_57.ground(p234, 0)
			local v239 = p_u_235 + 0.15
			local v_u_240 = p_u_57.ground(p234, 9)
			local v241 = v_u_124
			local v242 = v236 * 0.85
			local v243 = p_u_235 * 0.6
			v241(p234, v242, 1.1, math.max(v243, 0.06), v239, v237)
			p_u_57.sigil(CFrame.new(p_u_57.ground(p234, 0.15)), v236, v_u_8, v_u_6.MagicCircle, v239, 1.5)
			p_u_57.sigil(CFrame.new(p_u_57.ground(p234, 0.17)), v236 * 1.08, v_u_7, v_u_6.Ring, v239, -1)
			local v244 = p_u_235 * 0.6
			local v_u_245 = math.max(v244, 0.06)
			local v_u_246 = {}
			for _, v247 in v_u_39(v236 * 0.85) do
				local v248 = v238 + v247
				local v249 = {
					["rig"] = nil,
					["cf"] = nil,
					["height"] = 15,
					["rig"] = v_u_76(15, 2.8, p_u_235 + 2, true)
				}
				local v250 = CFrame.new(v248)
				local v251 = v248.X - v238.X
				local v252 = v248.Z - v238.Z
				local v253 = Vector3.new(v251, 0, v252)
				local v254
				if v253.Magnitude < 0.001 then
					v254 = CFrame.identity
				else
					v254 = CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v253.Unit), -0.2792526803190927)
				end
				v249.cf = v250 * v254
				table.insert(v_u_246, v249)
				if not v237 then
					p_u_57.chunks(p_u_57.ground(v248, 0.8), p_u_57.EARTH, 3, 24, 0.7, 0.6)
				end
				p_u_57.mark(v248, v_u_9, 3.5, v239 + 1, v_u_6.CrackLines, 0.1)
			end
			v_u_231[p_u_233] = v_u_246
			task.delay(p_u_235 + 2, function()
				-- upvalues: (ref) v_u_231, (copy) p_u_233
				v_u_231[p_u_233] = nil
			end)
			local v_u_255 = os.clock()
			p_u_57.runNow(function()
				-- upvalues: (ref) v_u_231, (copy) p_u_233, (copy) v_u_246, (copy) v_u_255, (copy) v_u_245, (ref) p_u_57
				if v_u_231[p_u_233] ~= v_u_246 then
					return false
				end
				local v256 = (os.clock() - v_u_255) / v_u_245
				local v257 = math.clamp(v256, 0, 1)
				local v258 = 1 - (1 - v257) ^ 3
				local v259 = v257 * 3.141592653589793
				local v260 = v258 * (math.sin(v259) * 0.1 + 1)
				for _, v261 in v_u_246 do
					p_u_57.rigPlace(v261.rig, v261.cf, (math.max(v260, 0.03)))
				end
				return v257 < 1
			end)
			p_u_57.after(v_u_245, function()
				-- upvalues: (copy) v_u_246, (ref) p_u_57, (copy) v_u_240, (ref) v_u_7, (copy) p_u_235, (copy) v_u_245, (ref) v_u_10
				for _, v262 in v_u_246 do
					local v263 = (v262.cf * CFrame.new(0, v262.height, 0)).Position
					local v264 = p_u_57.glowBeam
					local v265 = v_u_240
					local v266 = v_u_7
					local v267 = p_u_235 - v_u_245
					v264(v263, v265, v266, 1.8, math.max(v267, 0) + 0.2)
					local v268 = p_u_57.thin
					local v269 = p_u_57.rod(v263, v_u_240, 0.35, v_u_10)
					local v270 = p_u_235 - v_u_245
					v268(v269, math.max(v270, 0) + 0.15, true)
				end
			end)
			local v271 = p_u_57.ball(v_u_240, v_u_8, 1, 0)
			local v272 = p_u_57.ball(v_u_240, v_u_7, 2, 0.5)
			v_u_4.tween(v271, math.max(p_u_235, 0.05), {
				["Size"] = Vector3.new(5, 5, 5)
			})
			v_u_4.tween(v272, math.max(p_u_235, 0.05), {
				["Size"] = Vector3.new(9, 9, 9)
			})
			v_u_1:AddItem(v271, p_u_235 + 0.03)
			v_u_1:AddItem(v272, p_u_235 + 0.03)
			if p_u_233.mine then
				p_u_57.light(v271, v_u_7, 30)
			end
			if not v237 then
				p_u_57.inward(v_u_240, v_u_8, 8, 12, (math.max(p_u_235, 0.12)))
			end
		end,
		["land"] = function(p273, p274) -- name: land
			-- upvalues: (copy) p_u_57, (ref) v_u_10, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8, (ref) v_u_4, (ref) v_u_6, (copy) v_u_231, (ref) v_u_9, (copy) v_u_100, (ref) v_u_5
			local v275 = p273.ability.radius
			local v_u_276 = p273.lite
			local v_u_277 = p_u_57.ground(p274)
			local v278 = p_u_57.ground(p274, 9)
			p_u_57.pop(v278, v_u_10, 4, v275 * 1.3, 0.3, 0.2)
			p_u_57.pop(v278, v_u_7, 6, v275 * 1.6, 0.4, 0.5)
			v_u_56(p_u_57, v278, v_u_8, v275 * 1.8, 0.35)
			p_u_57.burst("Explosion", p_u_57.ground(p274, 3), v_u_7, v275 / 8)
			p_u_57.burst("Flash", v278, v_u_7, 1)
			local v279 = p_u_57.burst
			local v280 = v_u_277 + Vector3.new(0, 0.3, 0)
			local v281 = v_u_7
			local v282 = v275 / 14
			v279("Shockwave", v280, v281, (math.min(v282, 1.6)))
			v_u_4.ring(v_u_277, v_u_7, v275 * 1.2, 0.5)
			v_u_4.ring(v_u_277, v_u_8, v275 * 1.4, 0.45, v_u_6.SpeedLines)
			p_u_57.thin(p_u_57.pillar(v_u_277, 30, v275 * 0.5, v_u_8, 0.3), 0.45, true)
			local v283 = v_u_231[p273]
			v_u_231[p273] = nil
			if v283 then
				for v284, v_u_285 in v283 do
					p_u_57.after(v284 * 0.04, function()
						-- upvalues: (copy) v_u_285, (copy) v_u_276, (ref) p_u_57, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_56
						local v286 = (v_u_285.cf * CFrame.new(0, v_u_285.height, 0)).Position
						local v287 = v_u_285.rig
						local v288 = (v_u_285.cf * CFrame.new(0, v_u_285.height * 0.5, 0)).Position
						local v289 = v_u_276 and 0 or 3
						p_u_57.rigDestroy(v287)
						if v289 > 0 then
							local v290 = { v_u_7, v_u_8, v_u_9 }
							p_u_57.chunks(v288, v290, v289, 22, 1.98, 0.55, true, 0.6)
						end
						v_u_56(p_u_57, v286, v_u_8, 7, 0.2)
					end)
				end
			end
			local v291 = v_u_276 and 6 or 10
			for v292 = 1, v291 do
				local v293 = (v292 + math.random() * 0.5) / v291 * 3.141592653589793 * 2
				local v294 = v275 * (v292 % 3 / 2 * 0.45 + 0.2)
				local v295 = math.cos(v293)
				local v296 = math.sin(v293)
				local v_u_297 = v_u_277 + Vector3.new(v295, 0, v296) * v294
				p_u_57.after(v292 % 4 * 0.03, function()
					-- upvalues: (ref) v_u_100, (copy) v_u_297, (copy) v_u_277, (copy) v_u_276
					local v298 = v_u_100
					local v299 = v_u_297
					local v300 = 6 + math.random() * 5
					local v301 = 1.6 + math.random() * 0.9
					local v302 = v_u_297
					local v303 = v_u_277
					local v304 = 18 + math.random() * 14
					local v305 = math.rad(v304)
					local v306 = v302.X - v303.X
					local v307 = v302.Z - v303.Z
					local v308 = Vector3.new(v306, 0, v307)
					local v309
					if v308.Magnitude < 0.001 then
						v309 = CFrame.identity
					else
						v309 = CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v308.Unit), v305)
					end
					v298(v299, v300, v301, v309, 0.5, not v_u_276, 0)
				end)
			end
			p_u_57.chunks(p_u_57.ground(p274, 1), { p_u_57.EARTH[1], p_u_57.EARTH[2], v_u_7 }, v_u_276 and 6 or 14, 44, 1.3, 1.1)
			p_u_57.mark(p274, v_u_9, v275 * 0.9, 2, v_u_6.CrackLines, 0)
			p_u_57.mark(p274, v_u_7, v275 * 0.7, 1.4, v_u_6.CrackGlow, 0.1)
			v_u_5.play("Explosion", {
				["at"] = v_u_277
			})
			v_u_5.play("Crit", {
				["at"] = v_u_277,
				["volume"] = p273.mine and 0.8 or 0.5
			})
			if p273.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end,
		["hit"] = function(_, p310, _) -- name: hit
			-- upvalues: (copy) p_u_57, (ref) v_u_7, (ref) v_u_56, (ref) v_u_8
			p_u_57.burst("Impact", p310, v_u_7, 1.1)
			v_u_56(p_u_57, p310, v_u_8, 5, 0.18)
		end
	}
	return v194
end