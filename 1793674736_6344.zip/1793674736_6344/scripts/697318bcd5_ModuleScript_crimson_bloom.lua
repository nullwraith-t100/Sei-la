local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("E3122E")
local v_u_9 = Color3.fromHex("1A0306")
local v_u_10 = Color3.fromRGB(130, 0, 20)
local v_u_11 = Color3.fromRGB(255, 70, 80)
local v_u_12 = Color3.fromRGB(255, 175, 175)
local v_u_13 = Color3.fromRGB(125, 12, 26)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.PartType.Ball
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_28(p17, p18, p19, p20, p21) -- name: disc
	-- upvalues: (copy) v_u_5
	local v22 = v_u_5.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: fadeDecals
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_40(p33, p34, p35, p36, p37) -- name: egg
	-- upvalues: (copy) v_u_5
	local v38 = v_u_5.part(p33, p34, p35, {
		["transparency"] = p36,
		["material"] = p37
	})
	local v39 = Instance.new("SpecialMesh")
	v39.MeshType = Enum.MeshType.Sphere
	v39.Parent = v38
	return v38
end
local function v_u_47(p41, p42, p43, p44) -- name: splash
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_1
	local v45 = Instance.new("Attachment")
	v45.WorldPosition = p41 + Vector3.new(0, 1, 0) * p43 * 0.3
	v45.Parent = v_u_4.Terrain
	local v46 = Instance.new("ParticleEmitter")
	v46.Texture = v_u_7.BloomSplash
	v46.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v46.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v46.Color = ColorSequence.new(p42)
	v46.LightEmission = 0.1
	v46.LightInfluence = 0
	v46.Size = NumberSequence.new(p43 / 2)
	v46.Lifetime = NumberRange.new(0.42, 0.55)
	v46.Speed = NumberRange.new(0)
	v46.Rotation = NumberRange.new(-25, 25)
	v46.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v46.Shape = Enum.ParticleEmitterShape.Sphere
	v46.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v46.Enabled = false
	v46.Parent = v45
	v46:Emit(p44)
	v_u_1:AddItem(v45, 0.8)
end
return function(p_u_48)
	-- upvalues: (copy) v_u_28, (copy) v_u_1, (copy) v_u_32, (copy) v_u_40, (copy) v_u_11, (copy) v_u_8, (copy) v_u_2, (copy) v_u_5, (copy) v_u_14, (copy) v_u_15, (copy) v_u_10, (copy) v_u_16, (copy) v_u_9, (copy) v_u_12, (copy) v_u_4, (copy) v_u_47, (copy) v_u_7, (copy) v_u_13, (copy) v_u_6
	local function v_u_63(p49, p_u_50, p_u_51, p52, p53, p54, p55) -- name: flare
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_48, (ref) v_u_32
		local v_u_56 = p55 or 0
		local v_u_57 = v_u_28(p49, p_u_50, p52, p53, v_u_56)
		v_u_1:AddItem(v_u_57, p54 + 0.1)
		p_u_48.animate(p54, 0, function(p58)
			-- upvalues: (copy) p_u_50, (copy) p_u_51, (copy) v_u_57, (ref) v_u_32, (copy) v_u_56
			local v59 = p_u_50 + (p_u_51 - p_u_50) * (1 - (1 - p58) ^ 3)
			local v60 = v_u_57
			local v61 = v59 * 2
			local v62 = v59 * 2
			v60.Size = Vector3.new(v61, 0.05, v62)
			v_u_32(v_u_57, v_u_56 + (1 - v_u_56) * p58 ^ 1.5)
			if p58 >= 1 then
				v_u_57:Destroy()
			end
		end)
	end
	local function v_u_91(p64, p65, p66, p67, p_u_68) -- name: droplets
		-- upvalues: (ref) v_u_40, (ref) v_u_11, (ref) v_u_8, (ref) v_u_1, (copy) p_u_48
		local v_u_69 = {}
		for v70 = 1, p65 do
			local v71 = math.random() * 3.141592653589793 * 2
			local v72 = math.cos(v71)
			local v73 = math.sin(v71)
			local v74 = Vector3.new(v72, 0, v73) * p66 * (0.4 + math.random() * 0.6) + Vector3.new(0, 1, 0) * p66 * (0.7 + math.random() * 0.6)
			local v75 = p67 * (0.6 + math.random() * 0.6)
			local v76 = v_u_40
			local v77 = v75 * 1.5
			local v78 = Vector3.new(v75, v77, v75)
			local v79 = CFrame.new(p64)
			local v80
			if v70 % 3 == 0 then
				v80 = v_u_11
			else
				v80 = v_u_8
			end
			local v81 = v76(v78, v79, v80, 0)
			v_u_1:AddItem(v81, p_u_68 + 0.1)
			table.insert(v_u_69, {
				["p"] = v81,
				["v"] = v74
			})
		end
		local v_u_82 = os.clock()
		local v_u_83 = v_u_82
		p_u_48.frame(function()
			-- upvalues: (ref) v_u_83, (copy) v_u_69, (ref) p_u_48, (copy) v_u_82, (copy) p_u_68
			local v84 = os.clock()
			local v85 = v84 - v_u_83
			local v86 = math.min(v85, 0.05)
			v_u_83 = v84
			local v87 = false
			for _, v88 in v_u_69 do
				if not v88.p.Parent then
					continue
				end
				v88.v = v88.v - Vector3.new(0, 90, 0) * v86
				local v89 = v88.p.Position + v88.v * v86
				if v89.Y < p_u_48.FLOOR + 0.1 then
					v88.p:Destroy()
				else
					v88.p.CFrame = p_u_48.aimAt(v89, v88.v) * CFrame.Angles(1.5707963267948966, 0, 0)
					v87 = true
				end
			end
			if v87 and p_u_68 >= v84 - v_u_82 then
				return true
			end
			for _, v90 in v_u_69 do
				v90.p:Destroy()
			end
			return false
		end)
	end
	local v_u_92 = 0
	local function v_u_97(p93) -- name: redSky
		-- upvalues: (ref) v_u_92, (ref) v_u_2, (ref) v_u_5, (copy) p_u_48, (ref) v_u_14, (ref) v_u_1
		local v94 = os.clock()
		if v94 >= v_u_92 then
			v_u_92 = v94 + p93 + 0.4
			local v_u_95 = Instance.new("ColorCorrectionEffect")
			v_u_95.Name = "BloodRain"
			v_u_95.Parent = v_u_2
			v_u_5.tween(v_u_95, 0.25, {
				["TintColor"] = nil,
				["Saturation"] = 0.15,
				["TintColor"] = Color3.fromRGB(255, 205, 205)
			})
			p_u_48.after(p93, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_95, (ref) v_u_14
				local v96 = {
					["TintColor"] = nil,
					["Saturation"] = 0,
					["TintColor"] = v_u_14
				}
				v_u_5.tween(v_u_95, 0.4, v96)
			end)
			v_u_1:AddItem(v_u_95, p93 + 0.45)
		end
	end
	local function v129(p98, p99) -- name: pollenShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_15, (ref) v_u_10, (ref) v_u_16, (ref) v_u_11, (ref) v_u_1, (copy) p_u_48, (ref) v_u_9
		local v_u_100 = p98.size
		local v_u_101 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p99, v_u_8, {
			["transparency"] = 1
		})
		local v102 = {
			["shape"] = v_u_15
		}
		local v_u_103 = v_u_5.part(Vector3.new(1.1, 1.1, 1.1) * v_u_100, p99, v_u_8, v102)
		local v104 = {
			["shape"] = nil,
			["transparency"] = 0.55,
			["material"] = nil,
			["shape"] = v_u_15,
			["material"] = v_u_16
		}
		local v_u_105 = v_u_5.part(Vector3.new(1.9, 1.9, 1.9) * v_u_100, p99, v_u_10, v104)
		local v_u_106 = {}
		for _ = 1, p98.lite and 3 or 5 do
			local v107 = {
				["shape"] = v_u_15
			}
			local v108 = v_u_5.part(Vector3.new(0.3, 0.3, 0.3) * v_u_100, p99, v_u_11, v107)
			table.insert(v_u_106, v108)
		end
		local v_u_109 = { v_u_103, v_u_105 }
		for _, v110 in v_u_106 do
			table.insert(v_u_109, v110)
		end
		for _, v111 in v_u_109 do
			v_u_1:AddItem(v111, 3)
		end
		v_u_1:AddItem(v_u_101, 3)
		p_u_48.streak(v_u_101, v_u_8, v_u_9, 1 * v_u_100, 0.14)
		if p98.mine then
			p_u_48.light(v_u_101, v_u_8, 8 * v_u_100)
		end
		local v_u_112 = false
		return {
			["place"] = function(p113, p114) -- name: place
				-- upvalues: (copy) v_u_101, (copy) v_u_103, (copy) v_u_105, (copy) v_u_100, (copy) v_u_106
				local v115 = p113.Position
				v_u_101.CFrame = p113
				v_u_103.CFrame = p113
				v_u_105.CFrame = p113
				local v116 = v_u_105
				local v117 = Vector3.new(1.9, 1.9, 1.9) * v_u_100
				local v118 = p114 * 50
				v116.Size = v117 * (math.sin(v118) * 0.07 + 1)
				for v119, v120 in v_u_106 do
					local v121 = p114 * (v119 + 8) + v119 * 1.3
					local v122 = v119 * 2.1 + p114 * 4
					local v123 = CFrame.new
					local v124 = math.cos(v121) * math.sin(v122)
					local v125 = math.cos(v122)
					local v126 = math.sin(v121) * math.sin(v122)
					v120.CFrame = v123(v115 + Vector3.new(v124, v125, v126) * 1.25 * v_u_100)
				end
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_112, (copy) v_u_101, (ref) v_u_1, (copy) v_u_109
				if not v_u_112 then
					v_u_112 = true
					local v127 = v_u_101:FindFirstChildWhichIsA("PointLight")
					if v127 then
						v127:Destroy()
					end
					v_u_1:AddItem(v_u_101, 0.16)
					for _, v128 in v_u_109 do
						v128:Destroy()
					end
				end
			end
		}
	end
	local function v_u_149(p_u_130, p131, p132, p133) -- name: spores
		-- upvalues: (copy) p_u_48, (ref) v_u_11, (ref) v_u_12, (ref) v_u_1
		local v_u_134 = {}
		for _ = 1, p131 do
			local v135 = math.random() - 0.5
			local v136 = math.random() * 0.7 - 0.1
			local v137 = math.random() - 0.5
			local v138 = Vector3.new(v135, v136, v137)
			local v139 = v138.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v138.Unit
			local v140 = p_u_48.ball
			local v141
			if math.random() < 0.5 then
				v141 = v_u_11
			else
				v141 = v_u_12
			end
			local v142 = v140(p_u_130, v141, 0.35)
			v_u_1:AddItem(v142, p133 + 0.1)
			local v143 = {
				["p"] = v142,
				["way"] = v139 * p132 * (0.6 + math.random() * 0.6)
			}
			table.insert(v_u_134, v143)
		end
		p_u_48.animate(p133, 0, function(p144)
			-- upvalues: (copy) v_u_134, (copy) p_u_130
			local v145 = 1 - (1 - p144) ^ 3
			for _, v146 in v_u_134 do
				v146.p.CFrame = CFrame.new(p_u_130 + v146.way * v145 - Vector3.new(0, 1, 0) * p144 * p144 * 1.5)
				local v147 = v146.p
				local v148 = 0.35 * (1 - p144 * 0.7)
				v147.Size = Vector3.new(1, 1, 1) * math.max(v148, 0.05)
				v146.p.Transparency = p144 * p144
				if p144 < 1 then
					continue
				end
				v146.p:Destroy()
			end
		end)
	end
	local function v156(p150, p151) -- name: pollenImpact
		-- upvalues: (ref) v_u_4, (ref) v_u_47, (ref) v_u_8, (copy) p_u_48, (ref) v_u_10, (ref) v_u_16, (copy) v_u_149, (copy) v_u_63, (ref) v_u_7
		local v152 = p150.size
		local v153 = v_u_4.CurrentCamera
		local v154
		if v153 then
			local v155 = v153.CFrame.Position - p151
			v154 = v155.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v155.Unit
		else
			v154 = Vector3.new(0, 0, 1)
		end
		v_u_47(p151, v_u_8, 3.2 * v152, 2)
		p_u_48.pop(p151, v_u_8, 1.2 * v152, 4.2 * v152, 0.18, 0.35)
		p_u_48.pop(p151, v_u_10, 1.2 * v152, 2.8 * v152, 0.14, 0.2, v_u_16)
		p_u_48.burst("Impact", p151, v_u_8, 0.7 * v152)
		v_u_149(p151, p150.lite and 4 or 8, 4.5 * v152, 0.6)
		if not p150.lite then
			v_u_63(p_u_48.facing(p151 + v154 * 0.3, v154), 1 * v152, 3 * v152, v_u_7.BloomSplat, v_u_8, 0.25)
		end
		if p151.Y - p_u_48.FLOOR < 5 then
			p_u_48.mark(p151, v_u_10, 2.4 * v152, 1.5, v_u_7.BloomSplat, 0.15)
		end
		p_u_48.hitSound(p151)
	end
	local function v_u_217(p157, p158, p159, p160, p_u_161) -- name: eruptRoots
		-- upvalues: (copy) p_u_48, (ref) v_u_5, (ref) v_u_8, (ref) v_u_13, (ref) v_u_16, (ref) v_u_1, (ref) v_u_4
		local v_u_162 = p157.size
		local v163 = p157.lite
		local v164 = p_u_161 + 1
		local v_u_165 = {}
		local v_u_166 = {}
		local v167 = v163 and 3 or 4
		for v168 = 1, p160 do
			local v169 = (v168 + math.random() * 0.6) / p160 * 3.141592653589793 * 2
			local v170 = p159 * (0.25 + math.random() * 0.65)
			local v171 = p_u_48.ground(p158, 0)
			local v172 = math.cos(v169)
			local v173 = math.sin(v169)
			local v174 = v171 + Vector3.new(v172, 0, v173) * v170
			local v175 = {
				["segs"] = {},
				["base"] = v174
			}
			local v176 = v169 + 2
			local v177 = math.cos(v176)
			local v178 = v169 + 2
			local v179 = math.sin(v178)
			v175.way = Vector3.new(v177, 0, v179)
			v175.high = (6.5 + math.random() * 3.5) * v_u_162
			v175.curl = 0.6 + math.random() * 0.5
			v175.phase = math.random() * 6
			for v180 = 1, v167 do
				local v181 = v_u_5.part
				local v182 = Vector3.new(1, 1, 1)
				local v183 = CFrame.new(v174)
				local v184
				if v180 == v167 then
					v184 = v_u_8
				else
					v184 = v_u_13
				end
				local v185 = {}
				local v186
				if v180 == v167 then
					v186 = Enum.Material.Neon
				else
					v186 = v_u_16
				end
				v185.material = v186
				local v187 = v181(v182, v183, v184, v185)
				v_u_1:AddItem(v187, v164)
				local v188 = v175.segs
				table.insert(v188, v187)
				table.insert(v_u_165, v187)
			end
			table.insert(v_u_166, v175)
			p_u_48.burst("Impact", p_u_48.ground(v174, 1), v_u_8, 1 * v_u_162)
			if v163 then
				break
			end
			p_u_48.chunks(p_u_48.ground(v174, 0.5), { p_u_48.EARTH[1], v_u_13, p_u_48.EARTH[2] }, 3, 26, 0.6, 0.8)
		end
		local v_u_189 = table.create(#v_u_165, CFrame.identity)
		local v_u_190 = os.clock()
		p_u_48.runNow(function()
			-- upvalues: (copy) v_u_190, (copy) p_u_161, (copy) v_u_166, (copy) v_u_162, (copy) v_u_189, (ref) p_u_48, (ref) v_u_4, (copy) v_u_165
			local v191 = os.clock() - v_u_190
			local v192 = v191 / 0.14
			local v193 = 1 - (1 - math.clamp(v192, 0, 1)) ^ 3
			local v194 = (v191 - p_u_161) / 0.35
			local v195 = math.clamp(v194, 0, 1)
			local v196 = 0
			for _, v197 in v_u_166 do
				local v198 = v197.high * v193
				local v199 = v197.base - Vector3.new(0, 1, 0) * (v195 * v198 + 1)
				local v200 = v197.curl
				local v201 = v191 * 5 + v197.phase
				local v202 = v200 + math.sin(v201) * 0.25
				local v203 = v199 + Vector3.new(0, 1, 0) * v198 * 0.7
				local v204 = v199 + Vector3.new(0, 1, 0) * v198 * 1.05 + v197.way * v198 * 0.35 * v202
				local v205 = v199 + Vector3.new(0, 1, 0) * v198 * 0.75 + v197.way * v198 * 0.7 * v202
				local v206 = #v197.segs
				local v207 = v199 * 1 + v203 * 0 + v204 * 0 + v205 * 0
				for v208, v209 in v197.segs do
					local v210 = v208 / v206
					local v211 = 1 - v210
					local v212 = v199 * (v211 * v211 * v211) + v203 * (v211 * 3 * v211 * v210) + v204 * (v211 * 3 * v210 * v210) + v205 * (v210 * v210 * v210)
					local v213 = (1.6 - v210 * 1.15) * v_u_162
					local v214 = (v212 - v207).Magnitude + v213 * 0.4
					local v215 = math.max(v214, 0.1)
					v209.Size = Vector3.new(v213, v213, v215)
					v196 = v196 + 1
					v_u_189[v196] = p_u_48.aimAt((v207 + v212) / 2, v212 - v207)
					v207 = v212
				end
			end
			v_u_4:BulkMoveTo(v_u_165, v_u_189, Enum.BulkMoveMode.FireCFrameChanged)
			if v195 < 1 then
				return true
			end
			for _, v216 in v_u_165 do
				v216:Destroy()
			end
			return false
		end)
	end
	local v_u_218 = 0
	local function v_u_267(p_u_219, p_u_220, p221) -- name: coil
		-- upvalues: (ref) v_u_218, (copy) p_u_48, (ref) v_u_5, (ref) v_u_8, (ref) v_u_13, (ref) v_u_16, (ref) v_u_1, (ref) v_u_4
		if v_u_218 < 12 then
			v_u_218 = v_u_218 + 1
			local v_u_222 = p221 and 4 or 7
			local v223 = p_u_219.Y + 1.6
			local v224 = p_u_48.FLOOR + 2.5
			local v_u_225 = math.max(v223, v224)
			local v_u_226 = p_u_48.FLOOR - 0.2
			local v_u_227 = math.random() * 3.141592653589793 * 2
			local v_u_228 = {}
			for v229 = 1, v_u_222 do
				local v230 = v_u_5.part
				local v231 = Vector3.new(1, 1, 1)
				local v232 = CFrame.new(p_u_219)
				local v233
				if v229 == v_u_222 then
					v233 = v_u_8
				else
					v233 = v_u_13
				end
				local v234 = {}
				local v235
				if v229 == v_u_222 then
					v235 = Enum.Material.Neon
				else
					v235 = v_u_16
				end
				v234.material = v235
				local v236 = v230(v231, v232, v233, v234)
				v_u_1:AddItem(v236, p_u_220 + 1)
				table.insert(v_u_228, v236)
			end
			local v_u_237 = table.create(v_u_222, CFrame.identity)
			local v_u_238 = os.clock()
			p_u_48.runNow(function()
				-- upvalues: (copy) v_u_238, (copy) p_u_220, (copy) v_u_227, (copy) p_u_219, (copy) v_u_226, (copy) v_u_225, (copy) v_u_228, (copy) v_u_222, (copy) v_u_237, (ref) p_u_48, (ref) v_u_4, (ref) v_u_218
				local v239 = os.clock() - v_u_238
				local v240 = v239 / 0.16
				local v241 = 1 - (1 - math.clamp(v240, 0, 1)) ^ 3
				local v242 = v239 / 0.3
				local v243 = 1.15 - math.clamp(v242, 0, 1) * 0.15
				local v244 = v239 * 7
				local v245 = v243 + math.sin(v244) * 0.03
				local v246 = (v239 - p_u_220) / 0.3
				local v247 = math.clamp(v246, 0, 1)
				local v248 = v_u_227 + 0
				local v249 = v245 * 1.5
				local v250 = p_u_219.X + math.cos(v248) * v249
				local v251 = v_u_226 + (v_u_225 - v_u_226) * 0
				local v252 = p_u_219.Z + math.sin(v248) * v249
				local v253 = Vector3.new(v250, v251, v252)
				for v254, v255 in v_u_228 do
					local v256 = v254 / v_u_222 * v241
					local v257 = v_u_227 + v256 * 3.141592653589793 * 3.2
					local v258 = (1.5 - v256 * 0.35) * v245
					local v259 = p_u_219.X + math.cos(v257) * v258
					local v260 = v_u_226 + (v_u_225 - v_u_226) * v256
					local v261 = p_u_219.Z + math.sin(v257) * v258
					local v262 = Vector3.new(v259, v260, v261) - Vector3.new(0, 1, 0) * v247 * 2 * (1 - v256)
					local v263 = 0.6 - v256 * 0.25
					local v264 = (v262 - v253).Magnitude + v263 * 0.5
					local v265 = math.max(v264, 0.1)
					v255.Size = Vector3.new(v263, v263, v265)
					v_u_237[v254] = p_u_48.aimAt((v253 + v262) / 2, v262 - v253)
					v255.Transparency = v247
					v253 = v262
				end
				v_u_4:BulkMoveTo(v_u_228, v_u_237, Enum.BulkMoveMode.FireCFrameChanged)
				if v247 < 1 and v_u_228[1].Parent then
					return true
				end
				for _, v266 in v_u_228 do
					v266:Destroy()
				end
				v_u_218 = v_u_218 - 1
				return false
			end)
		end
	end
	local v_u_268 = {}
	setmetatable(v_u_268, {
		["__mode"] = "k"
	})
	local function v_u_277(p269, p270) -- name: flowerAxis
		-- upvalues: (copy) p_u_48
		local v271 = p269.feet.X - p270.X
		local v272 = p269.feet.Z - p270.Z
		local v273 = Vector3.new(v271, 0, v272)
		local v274
		if v273.Magnitude > 2 then
			v274 = v273.Unit
		else
			v274 = -p_u_48.flatUnit(p269.dir)
		end
		local v275 = (v274 * 0.8 - Vector3.new(0, 1, 0)).Unit
		local v276 = v274:Cross(Vector3.new(0, 1, 0)).Unit
		return v275, v276, v275:Cross(v276).Unit
	end
	local function v_u_326(p278, p279, p_u_280) -- name: openFlower
		-- upvalues: (copy) p_u_48, (copy) v_u_277, (ref) v_u_9, (ref) v_u_16, (ref) v_u_8, (ref) v_u_5, (ref) v_u_40, (ref) v_u_1, (ref) v_u_14, (ref) v_u_7, (ref) v_u_10, (copy) v_u_268
		local v_u_281 = p278.size
		local v282 = p278.lite
		local v283 = p278.ability.radius * v_u_281
		local v_u_284 = p_u_48.ground(p279, 22 * v_u_281)
		local v_u_285, v_u_286, v_u_287 = v_u_277(p278, p279)
		local v_u_288 = p_u_48.ball(v_u_284, v_u_9, 4 * v_u_281, 0, v_u_16)
		v_u_288.Reflectance = 0.1
		local v_u_289 = p_u_48.ball(v_u_284 + v_u_285 * 0.8 * v_u_281, v_u_8, 6.5 * v_u_281, 0.55)
		local v_u_290 = {
			["petals"] = nil,
			["heart"] = nil,
			["glow"] = nil,
			["rain"] = nil,
			["at"] = nil,
			["kickAt"] = -10,
			["petals"] = {},
			["heart"] = v_u_288,
			["glow"] = v_u_289
		}
		local v291 = v_u_5.part
		local v292 = v283 * 1.4
		local v293 = v283 * 1.4
		v_u_290.rain = v291(Vector3.new(v292, 0.2, v293), CFrame.new(v_u_284 - Vector3.new(0, 2, 0) * v_u_281), v_u_8, {
			["transparency"] = 1
		})
		v_u_290.at = v_u_284
		for v294 = 1, 8 do
			local v295 = (v294 - 1) / 8 * 3.141592653589793 * 2
			local v296 = v_u_40(Vector3.new(3.4, 0.6, 9.5) * v_u_281, CFrame.new(v_u_284), v_u_9, 0, v_u_16)
			v296.Reflectance = 0.05
			local v297 = v_u_290.petals
			table.insert(v297, {
				["p"] = nil,
				["a"] = nil,
				["inner"] = false,
				["p"] = v296,
				["a"] = v295
			})
			if v282 and v294 % 2 ~= 0 then
				continue
			end
			local v298 = v_u_40(Vector3.new(2.4, 0.5, 6) * v_u_281, CFrame.new(v_u_284), v_u_8, 0)
			local v299 = v_u_290.petals
			local v300 = {
				["p"] = nil,
				["a"] = nil,
				["inner"] = true,
				["p"] = v298,
				["a"] = v295 + 0.39269908169872414
			}
			table.insert(v299, v300)
		end
		local v_u_301 = { v_u_288, v_u_289, v_u_290.rain }
		for _, v302 in v_u_290.petals do
			local v303 = v302.p
			table.insert(v_u_301, v303)
		end
		for _, v304 in v_u_301 do
			v_u_1:AddItem(v304, p_u_280 + 2)
		end
		p_u_48.sigil(p_u_48.facing(v_u_284 + v_u_285 * 2.1 * v_u_281, v_u_285), 3.2 * v_u_281, v_u_14, p_u_48.iris("crimson_bloom"), p_u_280, 0.5)
		local v_u_305 = Instance.new("ParticleEmitter")
		v_u_305.Texture = v_u_7.Beam
		v_u_305.Color = ColorSequence.new(v_u_8, v_u_10)
		v_u_305.LightEmission = 0.4
		v_u_305.LightInfluence = 0
		v_u_305.Orientation = Enum.ParticleOrientation.VelocityParallel
		v_u_305.Size = NumberSequence.new(1.6 * v_u_281)
		v_u_305.Squash = NumberSequence.new(1.2)
		v_u_305.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.6), NumberSequenceKeypoint.new(0.15, 0.1), NumberSequenceKeypoint.new(1, 0.2) })
		v_u_305.EmissionDirection = Enum.NormalId.Bottom
		v_u_305.Speed = NumberRange.new(70 * v_u_281)
		v_u_305.SpreadAngle = Vector2.new(6, 6)
		v_u_305.Lifetime = NumberRange.new(0.2785714285714286)
		v_u_305.Rate = v282 and 14 or 30
		v_u_305.Parent = v_u_290.rain
		if p278.mine then
			p_u_48.light(v_u_289, v_u_8, 40)
		end
		v_u_268[p278] = v_u_290
		local v_u_306 = os.clock()
		local v_u_307 = false
		p_u_48.runNow(function()
			-- upvalues: (copy) v_u_306, (copy) p_u_280, (ref) v_u_307, (copy) v_u_305, (copy) v_u_290, (copy) v_u_286, (copy) v_u_287, (copy) v_u_285, (copy) v_u_284, (copy) v_u_281, (copy) v_u_288, (copy) v_u_289, (copy) v_u_301
			local v308 = os.clock() - v_u_306
			local v309 = v308 / 0.35
			local v310 = math.clamp(v309, 0, 1)
			local v311 = (v310 - 1) ^ 3 * 2.4 + 1 + (v310 - 1) ^ 2 * 1.4
			local v312 = (v308 - p_u_280) / 0.7
			local v313 = math.clamp(v312, 0, 1)
			if v313 > 0 and not v_u_307 then
				v_u_307 = true
				v_u_305.Enabled = false
			end
			local v314 = 1 - (os.clock() - v_u_290.kickAt) / 0.2
			local v315 = math.max(v314, 0)
			local v316 = v308 * 0.3
			for _, v317 in v_u_290.petals do
				local v318 = (v317.inner and 1.15 or 1.45) * (1 - v311) + (v317.inner and 0.42 or 0.18) * v311 - v315 * 0.12
				local v319 = v317.a + v316
				local v320 = v_u_286 * math.cos(v319) + v_u_287 * math.sin(v319)
				local v321 = (v320 * math.cos(v318) + v_u_285 * math.sin(v318)).Unit
				local v322 = v317.p.Size.Z
				local v323 = v_u_284 + v320 * (v317.inner and 1.1 or 1.7) * v_u_281 + v321 * v322 / 2 - Vector3.new(0, 1, 0) * v313 * v313 * 30 + v320 * v313 * 6
				local v324 = v_u_285 * math.cos(v318) - v320 * math.sin(v318)
				v317.p.CFrame = CFrame.lookAt(v323, v323 + v321, v324) * CFrame.Angles(0, 0, v313 * 2)
				v317.p.Transparency = v313
			end
			v_u_288.Transparency = v313
			v_u_289.Transparency = v313 * 0.45 + 0.55
			v_u_289.Size = Vector3.new(1, 1, 1) * (v315 * 2.5 + 6.5) * v_u_281
			if v313 < 1 then
				return true
			end
			for _, v325 in v_u_301 do
				v325:Destroy()
			end
			return false
		end)
		return v_u_290
	end
	local function v_u_355(p_u_327, p_u_328, p_u_329) -- name: torrent
		-- upvalues: (copy) p_u_48, (copy) v_u_268, (ref) v_u_8, (ref) v_u_11, (ref) v_u_47, (ref) v_u_10, (ref) v_u_7, (ref) v_u_5, (copy) v_u_91, (ref) v_u_12, (ref) v_u_6
		local v_u_330 = p_u_327.size
		local v_u_331 = p_u_327.lite
		local v_u_332 = p_u_48.ground(p_u_328)
		local v_u_333 = (p_u_327.ability.strikeRadius or 8) * v_u_330
		p_u_48.after(p_u_329 - 0.12, function()
			-- upvalues: (ref) v_u_268, (copy) p_u_327, (copy) v_u_330, (ref) p_u_48, (copy) p_u_328, (copy) p_u_329, (ref) v_u_8, (copy) v_u_331, (ref) v_u_11, (copy) v_u_332
			local v334 = v_u_268[p_u_327]
			local v_u_335
			if v334 then
				v_u_335 = v334.at - Vector3.new(0, 2, 0) * v_u_330
			else
				v_u_335 = p_u_48.ground(p_u_328, 22 * v_u_330)
			end
			if v334 then
				v334.kickAt = os.clock()
				local v336 = p_u_328.X
				local v337 = v_u_335.Y
				local v338 = p_u_328.Z
				v_u_335 = v_u_335 + (Vector3.new(v336, v337, v338) - v_u_335) * 0.35
			end
			local v339 = p_u_329
			local v340 = math.min(0.12, v339)
			local v341 = math.max(v340, 0.03)
			local v_u_342 = p_u_48.rod(v_u_335, v_u_335, 2.4 * v_u_330, v_u_8, 0.1)
			local v_u_343
			if v_u_331 then
				v_u_343 = nil
			else
				v_u_343 = p_u_48.rod(v_u_335, v_u_335, 1 * v_u_330, v_u_11, 0)
			end
			p_u_48.animate(v341, 0, function(p344)
				-- upvalues: (ref) v_u_335, (ref) v_u_332, (ref) p_u_48, (copy) v_u_342, (copy) v_u_343
				local v345 = v_u_335:Lerp(v_u_332, p344)
				local v346 = (v345 - v_u_335).Magnitude
				local v347 = math.max(v346, 0.1)
				local v348 = p_u_48.aimAt((v_u_335 + v345) / 2, v345 - v_u_335) * CFrame.Angles(0, 1.5707963267948966, 0)
				local v349 = v_u_342
				local v350 = v_u_342.Size.Y
				local v351 = v_u_342.Size.Z
				v349.Size = Vector3.new(v347, v350, v351)
				v_u_342.CFrame = v348
				local v352 = v_u_343
				if v352 then
					local v353 = v352.Size.Y
					local v354 = v352.Size.Z
					v352.Size = Vector3.new(v347, v353, v354)
					v352.CFrame = v348
				end
				if p344 >= 1 then
					p_u_48.thin(v_u_342, 0.25)
					if v352 then
						p_u_48.thin(v352, 0.18)
					end
				end
			end)
		end)
		p_u_48.after(p_u_329, function()
			-- upvalues: (ref) v_u_47, (copy) v_u_332, (ref) v_u_8, (copy) v_u_330, (copy) v_u_331, (ref) p_u_48, (copy) p_u_328, (ref) v_u_10, (copy) v_u_333, (ref) v_u_7, (ref) v_u_5, (ref) v_u_91, (ref) v_u_12, (ref) v_u_6, (copy) p_u_327
			v_u_47(v_u_332, v_u_8, 7 * v_u_330, v_u_331 and 2 or 4)
			p_u_48.mark(p_u_328, v_u_10, v_u_333 * 0.8, 2.5, v_u_7.BloomSplat, 0.05)
			v_u_5.ring(v_u_332, v_u_8, v_u_333, 0.35, v_u_7.Ring)
			p_u_48.burst("Impact", p_u_48.ground(p_u_328, 1), v_u_8, 1.3 * v_u_330)
			v_u_91(p_u_48.ground(p_u_328, 0.5), v_u_331 and 4 or 10, 30 * v_u_330, 0.5 * v_u_330, 1)
			if not v_u_331 then
				v_u_5.ring(v_u_332, v_u_12, v_u_333 * 0.6, 0.25, v_u_7.Shockwave)
			end
			v_u_6.play("Explosion", {
				["at"] = v_u_332,
				["volume"] = p_u_327.mine and 0.35 or 0.2
			})
			if p_u_327.mine then
				v_u_5.shake(0.15, 0.12)
			end
		end)
	end
	local v392 = {
		["crimson_bloom_a"] = {
			["cast"] = function(p356) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_48, (ref) v_u_12, (copy) v_u_149
				local v357 = p356.size
				local v358 = p356.eye + p356.dir * 1.2
				v_u_5.flash(v358, v_u_8, 2.8 * v357, 0.1)
				p_u_48.pop(v358, v_u_12, 0.9 * v357, 0.2 * v357, 0.1)
				if not p356.lite then
					v_u_149(v358, 3, 1.6 * v357, 0.25)
				end
			end,
			["shot"] = v129,
			["impact"] = v156,
			["hit"] = function(_, p359, _) -- name: hit
				-- upvalues: (copy) p_u_48, (ref) v_u_8
				p_u_48.burst("Impact", p359, v_u_8, 0.6)
			end
		},
		["crimson_bloom_e"] = {
			["cast"] = function(p360) -- name: cast
				-- upvalues: (copy) p_u_48, (ref) v_u_8, (ref) v_u_7
				p_u_48.skillCast(p360, v_u_8)
				local v361 = p360.feet
				local v362 = p_u_48.ground(p360.target)
				if (v362 - v361).Magnitude > 4 then
					p_u_48.alongPath(v361, v362, 4, 0.12, function(p363)
						-- upvalues: (ref) p_u_48, (ref) v_u_8, (ref) v_u_7
						p_u_48.mark(p363, v_u_8, 1.5, 0.8, v_u_7.CrackGlow, 0.25)
					end)
				end
			end,
			["windup"] = function(p364, p365, p366) -- name: windup
				-- upvalues: (copy) p_u_48, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
				local v367 = p364.size
				local v368 = p364.ability.radius * v367
				p_u_48.mark(p365, v_u_8, v368 * 0.75, 3, v_u_7.CrackGlow, 0.15)
				p_u_48.mark(p365, v_u_9, v368 * 0.9, 3, v_u_7.CrackLines, 0.1)
				for v369 = 1, p364.lite and 4 or 7 do
					local v370 = v369 / 7 * 3.141592653589793 * 2 + math.random() * 0.5
					local v371 = math.cos(v370)
					local v372 = math.sin(v370)
					local v373 = p365 + Vector3.new(v371, 0, v372) * v368 * 0.95
					p_u_48.groundLine(p365, v373, 0.8 * v367, v_u_8, math.max(p366, 0.1) + 0.8, 0.2)
				end
			end,
			["land"] = function(p374, p375) -- name: land
				-- upvalues: (copy) v_u_217, (copy) p_u_48, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7
				local v376 = p374.size
				local v377 = p374.ability.radius * v376
				v_u_217(p374, p375, v377, p374.lite and 4 or 8, 0.8)
				p_u_48.burst("Shockwave", p_u_48.ground(p375, 0.3), v_u_8, v377 / 16)
				v_u_5.ring(p_u_48.ground(p375), v_u_8, v377 * 1.1, 0.4, v_u_7.Shockwave)
				p_u_48.hitSound(p375, true)
				if p374.mine then
					v_u_5.shake(0.25, 0.2)
				end
			end,
			["hit"] = function(p378, p379, _) -- name: hit
				-- upvalues: (copy) v_u_267, (copy) p_u_48, (ref) v_u_8
				v_u_267(p379, p378.ability.freeze or 2.5, p378.lite)
				p_u_48.burst("Impact", p379, v_u_8, 0.6)
			end
		},
		["crimson_bloom_r"] = {
			["cast"] = function(p380) -- name: cast
				-- upvalues: (copy) p_u_48, (ref) v_u_8, (ref) v_u_12
				p_u_48.skillCast(p380, v_u_8, true)
				p_u_48.glint(p380.eye, v_u_12, 6, 0.2)
			end,
			["windup"] = function(p381, p382, p383) -- name: windup
				-- upvalues: (copy) v_u_326, (copy) v_u_277, (copy) v_u_63, (copy) p_u_48, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (copy) v_u_97, (ref) v_u_5
				local v384 = p381.size
				local v385 = p381.ability.radius * v384
				v_u_326(p381, p382, p383 + 0.15)
				local v386 = v_u_277(p381, p382)
				v_u_63(p_u_48.facing(p_u_48.ground(p382, 22 * v384) + v386 * 1.2 * v384, v386), 4 * v384, 16 * v384, v_u_7.Ring, v_u_8, 0.4)
				p_u_48.mark(p382, v_u_10, v385, p383 + 1, v_u_7.Glow, 0.6)
				if p381.mine then
					v_u_97(p383)
					v_u_5.shake(0.15, 0.2)
				end
			end,
			["strike"] = function(p387, p388, p389) -- name: strike
				-- upvalues: (copy) v_u_355
				v_u_355(p387, p388, p389)
			end,
			["hit"] = function(p390, p391, _) -- name: hit
				-- upvalues: (copy) p_u_48, (ref) v_u_8, (ref) v_u_47
				p_u_48.burst("Impact", p391, v_u_8, 0.7)
				if not p390.lite then
					v_u_47(p391 - Vector3.new(0, 1, 0), v_u_8, 2.6, 1)
				end
			end
		}
	}
	return v392
end