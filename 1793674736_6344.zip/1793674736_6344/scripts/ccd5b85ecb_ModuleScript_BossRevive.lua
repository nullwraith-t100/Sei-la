local v_u_1 = {
	["SECONDS"] = 5,
	["RESETS"] = 3
}
v_u_1.STOPS = v_u_1.RESETS + 1
v_u_1.PAUSE_MAX = 20
v_u_1.RECEIPT_WAIT = 10
function v_u_1.new(p2) -- name: new
	-- upvalues: (copy) v_u_1
	return {
		["left"] = nil,
		["since"] = nil,
		["paused"] = false,
		["resets"] = 0,
		["stops"] = 0,
		["window"] = false,
		["waitUntil"] = nil,
		["left"] = v_u_1.SECONDS,
		["since"] = p2
	}
end
function v_u_1.left(p3, p4) -- name: left
	if p3.paused then
		local v5 = p3.left
		return math.max(0, v5)
	else
		local v6 = p3.left - (p4 - p3.since)
		return math.max(0, v6)
	end
end
function v_u_1.open(p7, p8) -- name: open
	-- upvalues: (copy) v_u_1
	if p7.window or (p7.paused or v_u_1.left(p7, p8) <= 0) then
		return nil
	end
	p7.window = true
	if p7.stops >= v_u_1.STOPS then
		return "running"
	end
	p7.stops = p7.stops + 1
	p7.left = v_u_1.left(p7, p8)
	p7.since = p8
	p7.paused = true
	return "stopped"
end
function v_u_1.close(p9, p10, p11) -- name: close
	-- upvalues: (copy) v_u_1
	if not p9.window then
		return nil
	end
	p9.window = false
	if p11 then
		p9.left = v_u_1.left(p9, p10)
		p9.since = p10
		p9.paused = true
		p9.waitUntil = p10 + v_u_1.RECEIPT_WAIT
		return "waiting"
	end
	if not p9.paused then
		return "resumed"
	end
	local v12
	if p9.resets < v_u_1.RESETS then
		p9.resets = p9.resets + 1
		p9.left = v_u_1.SECONDS
		v12 = "reset"
	else
		v12 = "resumed"
	end
	p9.paused = false
	p9.since = p10
	p9.waitUntil = nil
	return v12
end
function v_u_1.step(p13, p14) -- name: step
	-- upvalues: (copy) v_u_1
	if not p13.paused then
		return v_u_1.left(p13, p14) <= 0 and "over" or "running"
	end
	if p13.window then
		if p14 - p13.since < v_u_1.PAUSE_MAX then
			return "paused"
		end
		v_u_1.close(p13, p14, false)
		return "resumed"
	end
	local v15 = p13.waitUntil
	if v15 and p14 < v15 then
		return "paused"
	end
	p13.paused = false
	p13.since = p14
	p13.waitUntil = nil
	return "resumed"
end
return v_u_1