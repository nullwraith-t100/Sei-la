local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v2.Shared.Config.Release)
local v_u_6 = require(v2.Shared.Config.Skies)
local v_u_7 = require(v2.Shared.Config.World)
local v8 = {}
local v_u_9 = {
	["Sky"] = "Sky",
	["Atmosphere"] = "Atmosphere"
}
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = 0
local function v_u_16() -- name: restore
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (ref) v_u_12
	for v13 = #v_u_10, 1, -1 do
		local v14 = v_u_10[v13]
		if not v14.target.Parent then
			continue
		end
		v14.target[v14.prop] = v14.value
	end
	table.clear(v_u_10)
	for _, v15 in v_u_11 do
		v15:Destroy()
	end
	table.clear(v_u_11)
	v_u_12 = 0
end
local function v_u_28(p17, p18) -- name: apply
	-- upvalues: (copy) v_u_1, (copy) v_u_9, (copy) v_u_11, (copy) v_u_10, (ref) v_u_12
	for v19, v20 in p18.set do
		local v21
		if v19 == "Lighting" then
			v21 = v_u_1
		else
			v21 = v_u_1:FindFirstChild(v19)
			if not v21 then
				local v22 = v_u_9[v19]
				if v22 then
					v21 = Instance.new(v22)
					v21.Name = v19
					v21.Parent = v_u_1
					local v23 = v_u_11
					table.insert(v23, v21)
				else
					v21 = nil
				end
			end
		end
		if not v21 then
			continue
		end
		for v24, v25 in v20 do
			local v26 = v_u_10
			local v27 = {
				["target"] = v21,
				["prop"] = v24,
				["value"] = v21[v24]
			}
			table.insert(v26, v27)
			v21[v24] = v25
		end
	end
	v_u_12 = p17
end
function v8.current() -- name: current
	-- upvalues: (ref) v_u_12
	return v_u_12
end
function v8.start() -- name: start
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (ref) v_u_12, (copy) v_u_16, (copy) v_u_28
	local v29 = false
	for v30 in v_u_6 do
		local v31 = v_u_6[v30]
		if not (v31 and v_u_5.on(v31.update)) then
			v31 = nil
		end
		if not v31 then
			continue
		end
		v29 = true
	end
	if v29 then
		local v_u_32 = 0
		v_u_3.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_32, (ref) v_u_6, (ref) v_u_5, (ref) v_u_12, (ref) v_u_16, (ref) v_u_28
			local v33 = v_u_4.CurrentCamera
			if v33 then
				local v34 = v_u_7.worldAt(v33.Focus.Position)
				if v34 ~= v_u_32 then
					v_u_32 = v34
					local v35 = v_u_6[v34]
					if not (v35 and v_u_5.on(v35.update)) then
						v35 = nil
					end
					if v_u_12 == v34 and v35 then
						return
					end
					if v_u_12 ~= 0 then
						v_u_16()
					end
					if v35 then
						v_u_28(v34, v35)
					end
				end
			end
		end)
	end
end
return v8