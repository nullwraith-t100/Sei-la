local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("5AE6FF")
local v_u_8 = Color3.fromHex("EFFFFF")
local v_u_9 = Color3.fromRGB(170, 238, 255)
local v_u_10 = Color3.fromRGB(95, 205, 255)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Wedge
local function v_u_21(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part(Vector3.new(p14, 0.05, p14), p13, p16, {
		["transparency"] = 1
	})
	for _, v19 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v20 = Instance.new("Decal")
		v20.Face = v19
		v20.Texture = p15
		v20.Color3 = p16
		v20.Transparency = p17
		v20.Parent = v18
	end
	return v18
end
local function v_u_25(p22, p23) -- name: setAlpha
	for _, v24 in p22:GetChildren() do
		if not v24:IsA("Decal") then
			continue
		end
		v24.Transparency = p23
	end
end
local function v_u_35(p26, p27, p28, p29) -- name: shardBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_11, (copy) v_u_6, (copy) v_u_7, (copy) v_u_1
	local v30 = v_u_4.part
	local v31 = math.max(p29, 0.2)
	local v32 = math.max(p29, 0.2)
	local v33 = v30(Vector3.new(v31, 0.2, v32), CFrame.new(p26), v_u_11, {
		["transparency"] = 1
	})
	local v34 = Instance.new("ParticleEmitter")
	v34.Texture = v_u_6.ShirayukiBurst
	v34.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v34.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v34.Color = ColorSequence.new(v_u_11, v_u_7)
	v34.LightEmission = 0.35
	v34.LightInfluence = 0
	v34.Lifetime = NumberRange.new(0.45, 0.55)
	v34.Size = NumberSequence.new(p27)
	v34.Speed = NumberRange.new(0)
	v34.Rotation = NumberRange.new(-15, 15)
	v34.Shape = Enum.ParticleEmitterShape.Box
	v34.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v34.Rate = 0
	v34.Enabled = false
	v34.Parent = v33
	v34:Emit(p28)
	v_u_1:AddItem(v33, 0.8)
end
local function v_u_52(p36, p37, p38, p39, p40, p41) -- name: snowSpray
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_11, (copy) v_u_9, (copy) v_u_1
	local v42 = Instance.new("Attachment")
	v42.WorldPosition = p36
	v42.Parent = v_u_3.Terrain
	local v43 = Instance.new("ParticleEmitter")
	v43.Texture = v_u_6.ShirayukiCrystal
	v43.Color = ColorSequence.new(v_u_11, v_u_9)
	v43.LightEmission = 0.5
	v43.LightInfluence = 0
	v43.Lifetime = NumberRange.new(p40 * 0.6, p40)
	v43.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p38), NumberSequenceKeypoint.new(0.7, p38 * 0.7), NumberSequenceKeypoint.new(1, 0) })
	v43.Rotation = NumberRange.new(0, 360)
	v43.RotSpeed = NumberRange.new(-220, 220)
	v43.Speed = NumberRange.new(p39 * 0.5, p39)
	local v44
	if p41 then
		v44 = Vector2.new(24, 6)
	else
		v44 = Vector2.new(180, 180)
	end
	v43.SpreadAngle = v44
	local v45
	if p41 then
		v45 = Enum.NormalId.Front
	else
		v45 = Enum.NormalId.Top
	end
	v43.EmissionDirection = v45
	v43.Drag = 4
	v43.Rate = 0
	v43.Enabled = false
	v43.Parent = v42
	if p41 then
		for v46 = 1, 8 do
			local v47 = v46 * 3.141592653589793 / 4
			local v48 = CFrame.lookAt
			local v49 = math.cos(v47)
			local v50 = math.sin(v47)
			v42.WorldCFrame = v48(p36, p36 + Vector3.new(v49, 0.12, v50))
			local v51 = p37 / 8
			v43:Emit((math.ceil(v51)))
		end
	else
		v43:Emit(p37)
	end
	v_u_1:AddItem(v42, p40 + 0.3)
end
local function v_u_74(p53, p54, p55, p56, p57) -- name: newSpike
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_1, (copy) v_u_8, (copy) v_u_12
	local v58 = math.random() * 3.141592653589793
	local v59 = CFrame.lookAt(p53, p53 + p54) * CFrame.Angles(0, 0, v58)
	local v60 = v_u_4.part
	local v61 = p55 * 0.7
	local v62 = v60(Vector3.new(p55, v61, 0.05), v59, v_u_10, {
		["transparency"] = 0.08
	})
	v_u_1:AddItem(v62, p57)
	local v63 = {
		["body"] = v62,
		["w"] = p55,
		["tip"] = p55 * 1.5,
		["cf"] = v59
	}
	if not p56 then
		local v64 = v_u_4.part
		local v65 = p55 * 0.7
		local v66 = p55 / 2
		local v67 = p55 * 1.5
		local v68 = v64(Vector3.new(v65, v66, v67), v59, v_u_8, {
			["shape"] = v_u_12
		})
		local v69 = v_u_4.part
		local v70 = p55 * 0.7
		local v71 = p55 / 2
		local v72 = p55 * 1.5
		local v73 = v69(Vector3.new(v70, v71, v72), v59, v_u_8, {
			["shape"] = v_u_12
		})
		v_u_1:AddItem(v68, p57)
		v_u_1:AddItem(v73, p57)
		v63.tipA = v68
		v63.tipB = v73
	end
	return v63
end
local function v_u_84(p75, p76) -- name: placeSpike
	local v77 = math.max(p76, 0.05)
	local v78 = p75.body
	local v79 = p75.w
	local v80 = p75.w * 0.7
	v78.Size = Vector3.new(v79, v80, v77)
	p75.body.CFrame = p75.cf * CFrame.new(0, 0, -v77 / 2)
	local v81 = p75.cf * CFrame.new(0, 0, -v77 - p75.tip / 2)
	local v82 = p75.tipA
	local v83 = p75.tipB
	if v82 and v83 then
		v82.CFrame = v81 * CFrame.new(p75.w / 4, 0, 0) * CFrame.Angles(0, 0, -1.5707963267948966)
		v83.CFrame = v81 * CFrame.new(-p75.w / 4, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
	end
end
return function(p_u_85)
	-- upvalues: (copy) v_u_21, (copy) v_u_1, (copy) v_u_25, (copy) v_u_3, (copy) v_u_6, (copy) v_u_7, (copy) v_u_11, (copy) v_u_74, (copy) v_u_84, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (copy) v_u_35, (copy) v_u_5, (copy) v_u_52
	local function v_u_99(p_u_86, p_u_87, p_u_88, p89, p90, p_u_91, p_u_92) -- name: bloom
		-- upvalues: (ref) v_u_21, (ref) v_u_1, (copy) p_u_85, (ref) v_u_25
		local v_u_93 = v_u_21(p_u_86, p_u_87, p89, p90, 0)
		v_u_1:AddItem(v_u_93, p_u_91 + 0.1)
		p_u_85.animate(p_u_91, 0, function(p94)
			-- upvalues: (copy) v_u_93, (copy) p_u_87, (copy) p_u_88, (copy) p_u_86, (copy) p_u_91, (copy) p_u_92, (ref) v_u_25
			local v95 = 1 - (1 - p94) ^ 3
			local v96 = v_u_93
			local v97 = p_u_87 + (p_u_88 - p_u_87) * v95
			local v98 = math.max(v97, 0.05)
			v96.Size = Vector3.new(v98, 0.05, v98)
			v_u_93.CFrame = p_u_86 * CFrame.Angles(0, p94 * p_u_91 * p_u_92, 0)
			v_u_25(v_u_93, p94 ^ 1.6)
			if p94 >= 1 then
				v_u_93:Destroy()
			end
		end)
	end
	local function v_u_107(p100, p101, p102, p103) -- name: crystalPop
		-- upvalues: (ref) v_u_3, (copy) v_u_99, (copy) p_u_85, (ref) v_u_6, (ref) v_u_7, (ref) v_u_11
		local v104 = v_u_3.CurrentCamera
		local v105
		if v104 then
			local v106 = v104.CFrame.Position - p100
			v105 = v106.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v106.Unit
		else
			v105 = Vector3.new(0, 0, 1)
		end
		v_u_99(p_u_85.facing(p100 + v105 * 0.5, v105), p101 * 1.5, p102 * 1.4, v_u_6.Glow, v_u_7, p103, 0)
		v_u_99(p_u_85.facing(p100 + v105 * 0.7, v105), p101, p102, v_u_6.ShirayukiCrystal, v_u_11, p103, 3)
	end
	local function v_u_128(p108, p109, p110, p_u_111) -- name: spikes
		-- upvalues: (ref) v_u_74, (ref) v_u_84, (copy) p_u_85, (ref) v_u_9, (ref) v_u_11, (ref) v_u_7
		local v_u_112 = {}
		local v_u_113 = {}
		for _, v114 in p108 do
			local v115 = v_u_74(v114.base, v114.dir, v114.w, p_u_111, p110 + 1)
			v_u_84(v115, 0.05)
			table.insert(v_u_112, v115)
			local v116 = v114.len
			table.insert(v_u_113, v116)
		end
		p_u_85.animate(p109, 0, function(p117)
			-- upvalues: (copy) v_u_112, (ref) v_u_84, (copy) v_u_113
			local v118 = 1 - (1 - p117) ^ 3
			for v119, v120 in v_u_112 do
				v_u_84(v120, v_u_113[v119] * v118)
			end
		end)
		p_u_85.after(p110, function()
			-- upvalues: (copy) v_u_112, (copy) v_u_113, (copy) p_u_111, (ref) p_u_85, (ref) v_u_9, (ref) v_u_11, (ref) v_u_7
			for v121, v122 in v_u_112 do
				local v123 = (v122.cf * CFrame.new(0, 0, -v_u_113[v121] * 0.5)).Position
				local v124 = { v122.body }
				local v125 = v122.tipA
				local v126 = v122.tipB
				if v125 and v126 then
					table.insert(v124, v125)
					table.insert(v124, v126)
				end
				for _, v127 in v124 do
					v127:Destroy()
				end
				if p_u_111 and v121 % 2 ~= 0 then
					break
				end
				p_u_85.chunks(v123, { v_u_9, v_u_11, v_u_7 }, p_u_111 and 2 or 3, 18, 0.6, 0.6, true, 0.7)
			end
		end)
	end
	local v242 = {
		["shirayuki_a"] = {
			["cast"] = function(p129) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) v_u_99, (copy) p_u_85, (ref) v_u_6, (ref) v_u_11
				local v130 = p129.size
				local v131 = p129.eye + p129.dir * 1.2
				v_u_4.flash(v131, v_u_7, 2.8 * v130, 0.1)
				if not p129.lite then
					v_u_99(p_u_85.facing(v131, -p129.dir), 0.6 * v130, 2 * v130, v_u_6.ShirayukiCrystal, v_u_11, 0.14, 12)
				end
			end,
			["shot"] = function(p132, p133) -- name: petalShot
				-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_21, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_1, (copy) p_u_85, (ref) v_u_9, (ref) v_u_3
				local v134 = p132.size
				local v_u_135 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p133, v_u_11, {
					["transparency"] = 1
				})
				local v_u_136 = v_u_21(p133, 6.5 * v134, v_u_6.Glow, v_u_7, 0.2)
				local v_u_137 = v_u_21(p133, 2.5 * v134, v_u_6.ShirayukiCrystal, v_u_11, 0)
				local v_u_138 = v_u_4.part(Vector3.new(0.55, 0.55, 0.55) * v134, p133, v_u_8)
				for _, v139 in {
					v_u_135,
					v_u_136,
					v_u_137,
					v_u_138
				} do
					v_u_1:AddItem(v139, 3)
				end
				p_u_85.streak(v_u_135, v_u_7, v_u_8, 1.1 * v134, 0.18)
				local v_u_140
				if p132.lite then
					v_u_140 = nil
				else
					v_u_140 = Instance.new("ParticleEmitter")
					v_u_140.Texture = v_u_6.ShirayukiCrystal
					v_u_140.Color = ColorSequence.new(v_u_11, v_u_9)
					v_u_140.LightEmission = 0.5
					v_u_140.LightInfluence = 0
					v_u_140.Lifetime = NumberRange.new(0.25, 0.4)
					v_u_140.Size = NumberSequence.new(0.6 * v134, 0)
					v_u_140.Rotation = NumberRange.new(0, 360)
					v_u_140.RotSpeed = NumberRange.new(-200, 200)
					v_u_140.Speed = NumberRange.new(0, 2)
					v_u_140.SpreadAngle = Vector2.new(180, 180)
					v_u_140.Rate = 30
					v_u_140.Parent = v_u_135
				end
				if p132.mine then
					p_u_85.light(v_u_135, v_u_7, 8 * v134)
				end
				local v_u_141 = false
				return {
					["place"] = function(p142, p143) -- name: place
						-- upvalues: (copy) v_u_135, (ref) v_u_3, (ref) p_u_85, (copy) v_u_137, (copy) v_u_136, (copy) v_u_138
						v_u_135.CFrame = p142
						local v144 = p142.Position
						local v145 = v_u_3.CurrentCamera
						local v146
						if v145 then
							local v147 = v145.CFrame.Position - v144
							v146 = v147.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v147.Unit
						else
							v146 = Vector3.new(0, 0, 1)
						end
						local v148 = p_u_85.facing(p142.Position + v146 * 0.2, v146)
						v_u_137.CFrame = v148 * CFrame.Angles(0, p143 * 14, 0)
						v_u_136.CFrame = v148 * CFrame.new(0, -0.05, 0)
						v_u_138.CFrame = p142 * CFrame.Angles(p143 * 9, p143 * 7, 0.7853981633974483)
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_141, (ref) v_u_140, (copy) v_u_135, (ref) v_u_1, (copy) v_u_136, (copy) v_u_137, (copy) v_u_138
						if not v_u_141 then
							v_u_141 = true
							local v149 = v_u_140
							if v149 then
								v149.Enabled = false
							end
							local v150 = v_u_135:FindFirstChildWhichIsA("PointLight")
							if v150 then
								v150:Destroy()
							end
							v_u_1:AddItem(v_u_135, 0.4)
							v_u_136:Destroy()
							v_u_137:Destroy()
							v_u_138:Destroy()
						end
					end
				}
			end,
			["impact"] = function(p151, p152) -- name: impact
				-- upvalues: (copy) v_u_107, (copy) p_u_85, (ref) v_u_9, (ref) v_u_11, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6, (ref) v_u_35
				local v153 = p151.size
				v_u_107(p152, 1.2 * v153, 6 * v153, 0.3)
				p_u_85.pop(p152, v_u_9, 1 * v153, 4.5 * v153, 0.2, 0.4)
				p_u_85.glint(p152, v_u_11, 4 * v153, 0.16)
				v_u_4.ring(p_u_85.ground(p152), v_u_7, p151.ability.radius * 0.8 * v153, 0.28, v_u_6.Ring)
				if not p151.lite then
					v_u_35(p_u_85.ground(p152, 1.6), 4 * v153, 1, 0.5)
				end
				p_u_85.hitSound(p152)
			end,
			["hit"] = function(_, p154, _) -- name: hit
				-- upvalues: (copy) p_u_85, (ref) v_u_7
				p_u_85.burst("Impact", p154, v_u_7, 0.6)
			end
		},
		["shirayuki_e"] = {
			["cast"] = function(p155) -- name: cast
				-- upvalues: (copy) p_u_85, (ref) v_u_7, (copy) v_u_99, (ref) v_u_6, (ref) v_u_11
				p_u_85.skillCast(p155, v_u_7)
				local v156 = p155.size
				local v157 = p155.eye + p155.dir * 1.4
				v_u_99(p_u_85.facing(v157, -p155.dir), 1 * v156, 3.6 * v156, v_u_6.ShirayukiCrystal, v_u_11, 0.3, -6)
				p_u_85.glint(v157, v_u_11, 4 * v156, 0.16)
			end,
			["windup"] = function(p158, p159, p160) -- name: windup
				-- upvalues: (copy) p_u_85, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9, (ref) v_u_8
				local v161 = p158.size
				local v162 = p158.ability.radius * v161
				local v163 = p160 + (p158.ability.freeze or 3) + 0.1
				local v164 = p_u_85.ground(p159, 0.12)
				p_u_85.sigil(CFrame.new(v164), v162 * 1.05, v_u_11, v_u_6.Ring, v163, 0.2)
				p_u_85.sigil(CFrame.new(v164 + Vector3.new(0, 0.03, 0)), v162 * 0.8, v_u_9, v_u_6.ShirayukiCrystal, v163, -0.25)
				p_u_85.inward(v164 + Vector3.new(0, 2, 0), v_u_8, p158.lite and 4 or 8, v162, (math.max(p160, 0.12)))
			end,
			["land"] = function(p_u_165, p166) -- name: pillar
				-- upvalues: (copy) p_u_85, (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (ref) v_u_9, (ref) v_u_6, (copy) v_u_128, (ref) v_u_35, (ref) v_u_5, (ref) v_u_52
				local v_u_167 = p_u_165.size
				local v_u_168 = p_u_165.lite
				local v_u_169 = p_u_165.ability.radius * v_u_167
				local v170 = p_u_165.ability.freeze or 3
				local v_u_171 = p_u_85.ground(p166, 0.15)
				local v_u_172 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_171), v_u_11, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_172, v170 + 1)
				local v173 = Instance.new("Attachment")
				v173.Parent = v_u_172
				local v174 = Instance.new("Attachment")
				v174.Position = Vector3.new(0, 70, 0)
				v174.Parent = v_u_172
				local v_u_175 = {}
				for v176, v177 in {
					{
						["w"] = nil,
						["c"] = nil,
						["t"] = 0.45,
						["w"] = v_u_169 * 1.9,
						["c"] = v_u_9
					},
					{
						["w"] = nil,
						["c"] = nil,
						["t"] = 0.2,
						["w"] = v_u_169 * 0.7,
						["c"] = v_u_11
					}
				} do
					if v_u_168 and v176 == 2 then
						continue
					end
					local v178 = Instance.new("Beam")
					v178.Attachment0 = v173
					v178.Attachment1 = v174
					v178.Texture = v_u_6.Beam
					v178.TextureMode = Enum.TextureMode.Stretch
					v178.Color = ColorSequence.new(v177.c, v_u_11)
					v178.LightEmission = 0.8
					v178.LightInfluence = 0
					v178.FaceCamera = true
					v178.Segments = 1
					v178.Width0 = v177.w * 0.2
					v178.Width1 = v177.w * 0.2
					v178.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v177.t), NumberSequenceKeypoint.new(0.6, (v177.t + 1) / 2), NumberSequenceKeypoint.new(1, 1) })
					v178.Parent = v_u_172
					table.insert(v_u_175, v178)
				end
				local v_u_179 = { v_u_169 * 1.9, v_u_169 * 0.7 }
				p_u_85.animate(0.2, 0, function(p180)
					-- upvalues: (copy) v_u_175, (copy) v_u_179
					local v181 = 1 - (1 - p180) ^ 3
					for v182, v183 in v_u_175 do
						v183.Width0 = v_u_179[v182] * v181
						v183.Width1 = v_u_179[v182] * v181
					end
				end)
				local v184 = v_u_168 and 6 or 12
				local v185 = math.random() * 3.141592653589793 * 2
				local v186 = {}
				for v187 = 1, v184 do
					local v188 = v185 + v187 * 3.141592653589793 * 2 / v184
					local v189 = math.cos(v188)
					local v190 = math.sin(v188)
					local v191 = Vector3.new(v189, 0, v190)
					local v192 = {
						["base"] = v_u_171 + v191 * v_u_169 * (0.82 + math.random() * 0.12),
						["dir"] = (Vector3.new(0, 1, 0) - v191 * 0.32).Unit,
						["len"] = (8 + math.random() * 6) * v_u_167,
						["w"] = (1.6 + math.random() * 0.6) * v_u_167
					}
					table.insert(v186, v192)
				end
				if not v_u_168 then
					for v193 = 1, 4 do
						local v194 = v185 + v193 * 3.141592653589793 / 2 + 0.4
						local v195 = math.cos(v194)
						local v196 = math.sin(v194)
						local v197 = Vector3.new(v195, 0, v196)
						local v198 = {
							["base"] = v_u_171 + v197 * v_u_169 * 0.35,
							["dir"] = (Vector3.new(0, 1, 0) + v197 * 0.25).Unit,
							["len"] = (5 + math.random() * 3) * v_u_167,
							["w"] = 1.3 * v_u_167
						}
						table.insert(v186, v198)
					end
				end
				v_u_128(v186, 0.12, v170, v_u_168)
				v_u_35(v_u_171 + Vector3.new(0, 3, 0), 9 * v_u_167, v_u_168 and 3 or 7, v_u_169 * 1.6)
				if not v_u_168 then
					local v199 = v_u_4.part
					local v200 = v_u_169 * 1.6
					local v201 = v_u_169 * 1.6
					local v202 = v199(Vector3.new(v200, 1, v201), CFrame.new(v_u_171 + Vector3.new(0, 1, 0)), v_u_11, {
						["transparency"] = 1
					})
					local v_u_203 = Instance.new("ParticleEmitter")
					v_u_203.Texture = v_u_6.ShirayukiCrystal
					v_u_203.Color = ColorSequence.new(v_u_11, v_u_9)
					v_u_203.LightEmission = 0.5
					v_u_203.LightInfluence = 0
					v_u_203.Lifetime = NumberRange.new(1.2, 1.8)
					v_u_203.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, 1.1 * v_u_167), NumberSequenceKeypoint.new(1, 0) })
					v_u_203.Rotation = NumberRange.new(0, 360)
					v_u_203.RotSpeed = NumberRange.new(-120, 120)
					v_u_203.Speed = NumberRange.new(10, 18)
					v_u_203.EmissionDirection = Enum.NormalId.Top
					v_u_203.SpreadAngle = Vector2.new(8, 8)
					v_u_203.Shape = Enum.ParticleEmitterShape.Box
					v_u_203.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
					v_u_203.Rate = 26
					v_u_203.Parent = v202
					task.delay(v170 - 0.3, function()
						-- upvalues: (copy) v_u_203
						v_u_203.Enabled = false
					end)
					v_u_1:AddItem(v202, v170 + 2)
				end
				v_u_4.flash(v_u_171 + Vector3.new(0, 3, 0), v_u_11, v_u_169 * 0.9, 0.3)
				v_u_4.ring(v_u_171, v_u_11, v_u_169 * 1.1, 0.4, v_u_6.Shockwave)
				v_u_5.play("Hit", {
					["at"] = v_u_171,
					["volume"] = p_u_165.mine and 0.7 or 0.4
				})
				if p_u_165.mine then
					v_u_4.shake(0.2, 0.2)
				end
				p_u_85.after(v170, function()
					-- upvalues: (ref) p_u_85, (copy) v_u_175, (copy) v_u_179, (copy) v_u_172, (ref) v_u_4, (copy) v_u_171, (ref) v_u_11, (copy) v_u_169, (ref) v_u_35, (copy) v_u_167, (copy) v_u_168, (ref) v_u_52, (ref) v_u_5, (copy) p_u_165
					p_u_85.animate(0.25, 0, function(p204)
						-- upvalues: (ref) v_u_175, (ref) v_u_179, (ref) v_u_172
						for v205, v206 in v_u_175 do
							v206.Width0 = v_u_179[v205] * (1 + p204 * 0.3)
							v206.Width1 = v_u_179[v205] * (1 + p204 * 0.3)
							local v207 = NumberSequence.new
							local v208 = 0.2 + p204
							v206.Transparency = v207((math.min(v208, 1)))
						end
						if p204 >= 1 then
							v_u_172:Destroy()
						end
					end)
					v_u_4.flash(v_u_171 + Vector3.new(0, 4, 0), v_u_11, v_u_169 * 1.1, 0.25)
					v_u_35(v_u_171 + Vector3.new(0, 2, 0), 8 * v_u_167, v_u_168 and 3 or 6, v_u_169 * 1.4)
					if not v_u_168 then
						v_u_52(v_u_171 + Vector3.new(0, 2, 0), 18, 1.4 * v_u_167, 26 * v_u_167, 0.7, false)
					end
					v_u_5.play("Hit", {
						["at"] = v_u_171,
						["volume"] = p_u_165.mine and 0.6 or 0.35
					})
				end)
			end,
			["hit"] = function(p209, p210, _) -- name: hit
				-- upvalues: (ref) v_u_3, (copy) p_u_85, (ref) v_u_11, (ref) v_u_6, (ref) v_u_7
				local v211 = v_u_3.CurrentCamera
				local v212
				if v211 then
					local v213 = v211.CFrame.Position - p210
					v212 = v213.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v213.Unit
				else
					v212 = Vector3.new(0, 0, 1)
				end
				local v214 = p209.ability.freeze or 3
				p_u_85.sigil(p_u_85.facing(p210 + v212 * 1.3, v212), 2.6, v_u_11, v_u_6.ShirayukiCrystal, v214, 0.6)
				p_u_85.sigil(p_u_85.facing(p210 + v212 * 1.2, v212), 3.4, v_u_7, v_u_6.Glow, v214, 0)
				p_u_85.glint(p210, v_u_11, 3, 0.15)
			end
		},
		["shirayuki_r"] = {
			["cast"] = function(p215) -- name: cast
				-- upvalues: (copy) p_u_85, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4
				p_u_85.skillCast(p215, v_u_7, true)
				p_u_85.burst("Flash", p215.eye, v_u_9, 0.3)
				if p215.mine then
					v_u_4.shake(0.12, 0.15)
				end
			end,
			["windup"] = function(p216, p217, p218) -- name: windup
				-- upvalues: (copy) v_u_99, (copy) p_u_85, (ref) v_u_6, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8, (ref) v_u_52
				local v219 = p216.size
				local v220 = math.max(p218, 0.15)
				local v221 = p216.eye + p216.dir * 2.4 - Vector3.new(0, 0.6, 0)
				v_u_99(p_u_85.facing(v221, -p216.dir), 1 * v219, 6 * v219, v_u_6.ShirayukiCrystal, v_u_11, v220 + 0.15, 10)
				p_u_85.pop(v221, v_u_7, 1 * v219, 4 * v219, v220, 0.3)
				p_u_85.sigil(CFrame.new(p_u_85.ground(p217, 0.12)), 7 * v219, v_u_11, v_u_6.ShirayukiCrystal, v220 + 0.1, 3)
				p_u_85.inward(p_u_85.ground(p217, 2.5), v_u_8, p216.lite and 6 or 12, 14 * v219, v220)
				if not p216.lite then
					v_u_52(p_u_85.ground(p217, 1), 10, 1 * v219, 8 * v219, v220 + 0.2, false)
				end
			end,
			["land"] = function(p_u_222, p223) -- name: blizzard
				-- upvalues: (copy) p_u_85, (ref) v_u_4, (ref) v_u_11, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_52, (copy) v_u_128, (ref) v_u_35, (ref) v_u_5
				local v_u_224 = p_u_222.size
				local v_u_225 = p_u_222.lite
				local v_u_226 = p_u_222.ability.radius * v_u_224
				local v_u_227 = p_u_85.ground(p223, 0.15)
				local v228 = p_u_222.dir.Z
				local v229 = p_u_222.dir.X
				local v_u_230 = math.atan2(v228, v229)
				v_u_4.flash(v_u_227 + Vector3.new(0, 3, 0), v_u_11, 14 * v_u_224, 0.3)
				p_u_85.pop(v_u_227 + Vector3.new(0, 2, 0), v_u_9, 4 * v_u_224, v_u_226 * 0.9, 0.45, 0.5)
				p_u_85.dome(v_u_227, v_u_226, v_u_7, 0.55)
				v_u_4.ring(v_u_227, v_u_11, v_u_226 * 1.05, 0.55, v_u_6.Shockwave)
				v_u_4.ring(v_u_227, v_u_7, v_u_226 * 1.25, 0.7, v_u_6.Ring)
				p_u_85.burst("Shockwave", v_u_227 + Vector3.new(0, 0.3, 0), v_u_7, v_u_226 / 14)
				v_u_52(v_u_227 + Vector3.new(0, 2, 0), v_u_225 and 16 or 44, 1.8 * v_u_224, 70 * v_u_224, 0.9, true)
				for v_u_231, v_u_232 in v_u_225 and {
					{
						["r"] = 0.6,
						["n"] = 8
					}
				} or {
					{
						["r"] = 0.3,
						["n"] = 6
					},
					{
						["r"] = 0.6,
						["n"] = 9
					},
					{
						["r"] = 0.9,
						["n"] = 12
					}
				} do
					p_u_85.after((v_u_231 - 1) * 0.09, function()
						-- upvalues: (copy) v_u_232, (copy) v_u_230, (copy) v_u_231, (copy) v_u_226, (copy) v_u_227, (copy) v_u_224, (ref) v_u_128, (copy) v_u_225, (ref) v_u_35
						local v233 = {}
						for v234 = 1, v_u_232.n do
							local v235 = v_u_230 + (v234 + v_u_231 * 0.5) * 3.141592653589793 * 2 / v_u_232.n
							local v236 = math.cos(v235)
							local v237 = math.sin(v235)
							local v238 = Vector3.new(v236, 0, v237)
							local v239 = {
								["base"] = v_u_227 + v238 * (v_u_226 * v_u_232.r * (0.9 + math.random() * 0.2)),
								["dir"] = (Vector3.new(0, 1, 0) + v238 * 0.55).Unit,
								["len"] = (v_u_232.r * 4 + 4 + math.random() * 3) * v_u_224,
								["w"] = (v_u_232.r + 1.2) * v_u_224
							}
							table.insert(v233, v239)
						end
						v_u_128(v233, 0.09, 0.95 - (v_u_231 - 1) * 0.09, v_u_225)
						v_u_35(v_u_227 + Vector3.new(0, 2.5, 0), 7 * v_u_224, v_u_225 and 3 or 5, v_u_226 * v_u_232.r * 2)
					end)
				end
				if not v_u_225 then
					p_u_85.mark(p223, v_u_11, v_u_226 * 0.9, 1.6, v_u_6.Glow, 0.3)
					p_u_85.mark(p223, v_u_9, v_u_226 * 0.6, 1.4, v_u_6.ShirayukiCrystal, 0.2)
				end
				v_u_5.play("Explosion", {
					["at"] = v_u_227,
					["volume"] = p_u_222.mine and 0.9 or 0.5
				})
				p_u_85.after(0.95, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_227, (copy) p_u_222, (ref) v_u_4
					v_u_5.play("Hit", {
						["at"] = v_u_227,
						["volume"] = p_u_222.mine and 0.6 or 0.3
					})
					if p_u_222.mine then
						v_u_4.shake(0.18, 0.2)
					end
				end)
				if p_u_222.mine then
					v_u_4.shake(0.45, 0.45)
				end
			end,
			["hit"] = function(p240, p241, _) -- name: hit
				-- upvalues: (copy) p_u_85, (ref) v_u_7, (ref) v_u_11
				p_u_85.burst("Impact", p241, v_u_7, 1)
				if not p240.lite then
					p_u_85.glint(p241, v_u_11, 3.4, 0.15)
				end
			end
		}
	}
	return v242
end