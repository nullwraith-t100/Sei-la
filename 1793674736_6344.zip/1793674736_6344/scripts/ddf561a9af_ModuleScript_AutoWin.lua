local v_u_1 = require(script.Parent.Parent.Config.Perks)
require(script.Parent.Parent.Config.Stages)
local v_u_17 = {
	["stage"] = function(p2, p3, _) -- name: stage
		local v4 = math.floor(p3)
		local v5 = #p2
		return math.clamp(v4, 0, v5)
	end,
	["interval"] = function(p6) -- name: interval
		-- upvalues: (copy) v_u_1
		local v7 = v_u_1.AUTO_WIN_MIN_SECONDS
		local v8 = p6 * v_u_1.RUN_SECONDS_PER_STAGE * v_u_1.AUTO_WIN_SLOWER
		local v9 = math.ceil(v8)
		return math.max(v7, v9)
	end,
	["payout"] = function(p10, p11, p12) -- name: payout
		-- upvalues: (copy) v_u_17
		local v13 = p10 * (p11 and 2 or 1)
		return v_u_17.vipTrophies(v13, p12)
	end,
	["vipTrophies"] = function(p14, p15) -- name: vipTrophies
		-- upvalues: (copy) v_u_1
		if not p15 then
			return p14
		end
		local v16 = p14 * v_u_1.VIP_TROPHIES + 0.5
		return math.floor(v16)
	end
}
return v_u_17