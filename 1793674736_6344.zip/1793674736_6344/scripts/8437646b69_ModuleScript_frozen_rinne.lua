local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("9EDCFF")
local v_u_9 = Color3.fromHex("E8F7FF")
local v_u_10 = Color3.fromRGB(40, 110, 200)
local v_u_11 = Color3.fromRGB(56, 120, 205)
local v_u_12 = Color3.fromRGB(14, 18, 30)
local v_u_13 = Color3.fromRGB(150, 205, 250)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = CFrame.Angles(0, 0.7853981633974483, 0)
local v_u_16 = CFrame.Angles(0, 0, 0.7853981633974483)
local v_u_17 = {
	{
		["d"] = 8.4,
		["color"] = nil,
		["rate"] = 2,
		["color"] = v_u_9
	},
	{
		["d"] = 5.8,
		["color"] = nil,
		["rate"] = -3,
		["color"] = v_u_8
	},
	{
		["d"] = 3.2,
		["color"] = nil,
		["rate"] = 4,
		["color"] = v_u_10
	}
}
local function v_u_23(p18, p19, p20, p21) -- name: flakes
	-- upvalues: (copy) v_u_7
	local v22 = Instance.new("ParticleEmitter")
	v22.Texture = v_u_7.Snowflake
	v22.Color = ColorSequence.new(p18)
	v22.LightEmission = 0.35
	v22.LightInfluence = 0
	v22.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p19 * 0.4), NumberSequenceKeypoint.new(0.2, p19), NumberSequenceKeypoint.new(1, p19 * 0.5) })
	v22.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.75, 0.25), NumberSequenceKeypoint.new(1, 1) })
	v22.Lifetime = NumberRange.new(p21 * 0.6, p21)
	v22.Speed = NumberRange.new(p20 * 0.4, p20)
	v22.SpreadAngle = Vector2.new(180, 180)
	v22.Rotation = NumberRange.new(0, 360)
	v22.RotSpeed = NumberRange.new(-160, 160)
	v22.Drag = 3
	v22.Acceleration = Vector3.new(0, -6, 0)
	v22.Rate = 0
	v22.Enabled = false
	return v22
end
local function v_u_31(p24, p25, p26, p27, p28) -- name: flakeBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_23, (copy) v_u_1
	local v29 = Instance.new("Attachment")
	v29.WorldPosition = p24
	v29.Parent = v_u_4.Terrain
	local v30 = v_u_23(p25, p27, p28, 0.9)
	v30.Parent = v29
	v30:Emit(p26)
	v_u_1:AddItem(v29, 1.1)
end
local function v_u_40(p32, p33, p34, p35) -- name: picture
	-- upvalues: (copy) v_u_5
	local v36 = v_u_5.part(Vector3.new(p32, 0.05, p32), CFrame.identity, p34, {
		["transparency"] = 1
	})
	local v37 = {}
	for _, v38 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v39 = Instance.new("Decal")
		v39.Face = v38
		v39.Texture = p33
		v39.Color3 = p34
		v39.Transparency = p35 or 0
		v39.Parent = v36
		table.insert(v37, v39)
	end
	return v36, v37
end
local function v_u_49(p41, p42, p43, p44, p45) -- name: ripple
	-- upvalues: (copy) v_u_40, (copy) v_u_7, (copy) v_u_5, (copy) v_u_1
	local v46, v47 = v_u_40(p42, v_u_7.Ring, p45)
	v46.CFrame = p41
	for _, v48 in v47 do
		v_u_5.tween(v48, p44, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	v_u_5.tween(v46, p44, {
		["Size"] = Vector3.new(p43, 0.05, p43)
	})
	v_u_1:AddItem(v46, p44 + 0.05)
end
local function v_u_60(p50, p51, p52, p53, p54) -- name: ribbon
	local v55 = Instance.new("Attachment")
	local v56 = p53 / 2
	v55.Position = Vector3.new(0, v56, 0)
	v55.Parent = p50
	local v57 = Instance.new("Attachment")
	local v58 = -p53 / 2
	v57.Position = Vector3.new(0, v58, 0)
	v57.Parent = p50
	local v59 = Instance.new("Trail")
	v59.Attachment0 = v55
	v59.Attachment1 = v57
	v59.Color = ColorSequence.new(p51, p52)
	v59.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v59.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.2) })
	v59.Lifetime = p54
	v59.LightEmission = 0.4
	v59.LightInfluence = 0
	v59.FaceCamera = true
	v59.MinLength = 0.05
	v59.Parent = p50
	return v59
end
local v_u_61 = 0
local function v_u_65() -- name: frostFrame
	-- upvalues: (ref) v_u_61, (copy) v_u_2, (copy) v_u_5, (copy) v_u_14, (copy) v_u_1
	local v62 = os.clock()
	if v62 >= v_u_61 then
		v_u_61 = v62 + 0.5
		local v63 = Instance.new("ColorCorrectionEffect")
		v63.TintColor = Color3.fromRGB(205, 232, 255)
		v63.Brightness = 0.1
		v63.Contrast = 0.12
		v63.Saturation = -0.3
		v63.Parent = v_u_2
		local v64 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_14
		}
		v_u_5.tween(v63, 0.4, v64)
		v_u_1:AddItem(v63, 0.45)
	end
end
return function(p_u_66)
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_16, (copy) v_u_11, (copy) v_u_40, (copy) v_u_7, (copy) v_u_49, (copy) v_u_15, (copy) v_u_13, (copy) v_u_1, (copy) v_u_4, (copy) v_u_12, (copy) v_u_31, (copy) v_u_10, (copy) v_u_14, (copy) v_u_60, (copy) v_u_23, (copy) v_u_6, (copy) v_u_17, (copy) v_u_65
	local v_u_67 = {}
	local function v_u_111(p68, p69, p70, p71) -- name: spikeWake
		-- upvalues: (copy) p_u_66, (ref) v_u_5, (ref) v_u_15, (ref) v_u_13, (ref) v_u_1, (ref) v_u_9, (ref) v_u_8
		local v_u_72 = p68.lite
		local v73 = p_u_66.flatUnit(p70 - p69)
		local v74 = v73:Cross(Vector3.new(0, 1, 0))
		local v75 = p_u_66.ground(p69, 0) + v73 * 4
		local v76 = p_u_66.ground(p70, 0)
		local v77 = (v76 - v75).Magnitude / (v_u_72 and 12 or 8)
		local v78 = math.floor(v77)
		local v79 = math.max(v78, 1)
		local v_u_80 = {}
		for v81 = 1, v79 do
			local v82 = v81 / v79
			local v83 = v75:Lerp(v76, v82)
			for _, v84 in v_u_72 and { v81 % 2 == 0 and 1 or -1 } or { -1, 1 } do
				local v85 = v74 * v84
				local v86 = v83 + v85 * (3 + math.random() * 1.4)
				local v87 = v82 * 4 + 3.5 + math.random() * 1.5
				local v88 = v82 * 0.5 + 1
				local v89 = (v85 + v73 * 0.6).Unit
				local v90 = CFrame.new(v86) * CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v89), 0.4188790204786391)
				local v91 = v_u_5.part(Vector3.new(v88, v87, v88), v90 * CFrame.new(0, -v87 / 2, 0) * v_u_15, v_u_13, {
					["material"] = nil,
					["transparency"] = 0.08,
					["material"] = Enum.Material.Ice
				})
				v_u_1:AddItem(v91, 4)
				local v92
				if v_u_72 then
					v92 = nil
				else
					local v93 = v_u_5.part
					local v94 = v88 * 0.55
					local v95 = v87 * 0.4
					local v96 = v88 * 0.55
					v92 = v93(Vector3.new(v94, v95, v96), v91.CFrame, v_u_9)
					v_u_1:AddItem(v92, 4)
				end
				local v97 = p71 * v82
				local v98 = {
					["body"] = nil,
					["tip"] = nil,
					["frame"] = nil,
					["h"] = nil,
					["at"] = nil,
					["breakAt"] = nil,
					["up"] = false,
					["body"] = v91,
					["tip"] = v92,
					["frame"] = v90,
					["h"] = v87,
					["at"] = v97,
					["breakAt"] = v97 * 2 + 1.1
				}
				table.insert(v_u_80, v98)
			end
		end
		local v_u_99 = os.clock()
		p_u_66.frame(function()
			-- upvalues: (copy) v_u_99, (copy) v_u_80, (copy) v_u_72, (ref) p_u_66, (ref) v_u_13, (ref) v_u_9, (ref) v_u_8, (ref) v_u_15
			local v100 = os.clock() - v_u_99
			local v101 = 0
			for v102, v103 in v_u_80 do
				if not v103.body.Parent then
					continue
				end
				v101 = v101 + 1
				if v103.breakAt <= v100 then
					local v104 = (v103.frame * CFrame.new(0, v103.h * 0.5, 0)).Position
					v103.body:Destroy()
					local v105 = v103.tip
					if v105 then
						v105:Destroy()
					end
					if v_u_72 or v102 % 3 ~= 0 then
						continue
					end
					local v106 = { v_u_13, v_u_9, v_u_8 }
					p_u_66.chunks(v104, v106, 3, 20, 0.6, 0.5, false, 0.5)
				else
					if v103.up or v103.at > v100 then
						continue
					end
					local v107 = (v100 - v103.at) / 0.09
					local v108 = 1 - (1 - math.clamp(v107, 0, 1)) ^ 3
					local v109 = v103.h
					v103.body.CFrame = v103.frame * CFrame.new(0, -v109 / 2 + v109 * v108, 0) * v_u_15
					local v110 = v103.tip
					if v110 then
						v110.CFrame = v103.frame * CFrame.new(0, -v109 * 0.2 + v109 * v108, 0) * v_u_15
					end
					if v108 < 1 then
						continue
					end
					v103.up = true
					if v_u_72 or v102 % 4 ~= 1 then
						continue
					end
					p_u_66.burst("Impact", p_u_66.ground(v103.frame.Position, 1), v_u_8, 0.6)
				end
			end
			return v101 > 0
		end)
	end
	local v314 = {
		["frozen_rinne_a"] = {
			["cast"] = function(p112) -- name: cast
				-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_49, (ref) v_u_9
				p_u_66.muzzle(p112, v_u_8, 0.85)
				if not p112.lite then
					v_u_49(p_u_66.facing(p112.eye + p112.dir * 1.3, p112.dir), 0.8, 3, 0.14, v_u_9)
				end
			end,
			["shot"] = function(p113, p114) -- name: lanceShot
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_16, (ref) v_u_11, (ref) v_u_40, (ref) v_u_7, (copy) p_u_66, (ref) v_u_49
				local v_u_115 = p113.size
				local v116 = p113.lite
				local v117 = 5.4 * v_u_115
				local v118 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p114, v_u_8, {
					["transparency"] = 1
				})
				local v119 = {}
				local v120 = {}
				local v121 = v_u_5.part
				local v122 = 0.32 * v_u_115
				local v123 = 0.32 * v_u_115
				v120.p = v121(Vector3.new(v122, v123, v117), p114, v_u_8, {
					["transparency"] = 0.1
				})
				v120.off = CFrame.identity
				__set_list(v119, 1, {v120, {
	["p"] = v_u_5.part(Vector3.new(0.62, 0.62, 1.7) * v_u_115, p114, v_u_9),
	["off"] = CFrame.new(0, 0, -v117 / 2 - 0.6 * v_u_115) * v_u_16
}})
				if not v116 then
					local v124 = {
						["p"] = v_u_5.part(Vector3.new(0.45, 0.45, 0.9) * v_u_115, p114, v_u_11),
						["off"] = CFrame.new(0, 0, v117 / 2 + 0.2 * v_u_115) * v_u_16
					}
					table.insert(v119, v124)
					local v125 = {
						["p"] = v_u_40(2.3 * v_u_115, v_u_7.Ring, v_u_9),
						["off"] = CFrame.new(0, 0, -v117 * 0.28) * CFrame.Angles(1.5707963267948966, 0, 0)
					}
					table.insert(v119, v125)
				end
				p_u_66.streak(v118, v_u_9, v_u_8, 0.75 * v_u_115, 0.14)
				if p113.mine then
					p_u_66.light(v118, v_u_8, 8 * v_u_115)
				end
				local v_u_126 = p_u_66.assemble(v118, v119, {}, 0, 0, {}, 0.14, 10)
				if v116 then
					return v_u_126
				end
				local v_u_127 = 0.03
				return {
					["place"] = function(p128, p129) -- name: place
						-- upvalues: (copy) v_u_126, (ref) v_u_127, (ref) v_u_49, (copy) v_u_115, (ref) v_u_8
						v_u_126.place(p128, p129)
						if v_u_127 <= p129 then
							v_u_127 = p129 + 0.07
							v_u_49(p128 * CFrame.Angles(1.5707963267948966, 0, 0), 1.6 * v_u_115, 4.2 * v_u_115, 0.22, v_u_8)
						end
					end,
					["stop"] = v_u_126.stop
				}
			end,
			["impact"] = function(p130, p131) -- name: impact
				-- upvalues: (copy) p_u_66, (ref) v_u_4, (ref) v_u_49, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_31
				local v_u_132 = p130.size
				local v133 = p_u_66.facing
				local v134 = v_u_4.CurrentCamera
				local v135
				if v134 then
					local v136 = v134.CFrame.Position - p131
					v135 = v136.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v136.Unit
				else
					v135 = Vector3.new(0, 1, 0)
				end
				local v_u_137 = v133(p131, v135)
				v_u_49(v_u_137, 1.5 * v_u_132, 7 * v_u_132, 0.24, v_u_9)
				p_u_66.after(0.05, function()
					-- upvalues: (ref) v_u_49, (copy) v_u_137, (copy) v_u_132, (ref) v_u_12
					v_u_49(v_u_137, 1 * v_u_132, 5 * v_u_132, 0.2, v_u_12)
				end)
				p_u_66.spikes(p131, v_u_9, p130.lite and 3 or 6, 4.2 * v_u_132, 0.14, p130.dir, 0.6)
				p_u_66.burst("Impact", p131, v_u_8, 0.85 * v_u_132)
				p_u_66.pop(p131, v_u_9, 1.1 * v_u_132, 4.2 * v_u_132, 0.13, 0.25)
				v_u_5.ring(p_u_66.ground(p131), v_u_8, 5 * v_u_132, 0.25, v_u_7.Ring)
				if not p130.lite then
					v_u_31(p131, v_u_9, 6, 0.3 * v_u_132, 10 * v_u_132)
				end
				p_u_66.hitSound(p131)
			end,
			["hit"] = function(_, p138, _) -- name: hit
				-- upvalues: (copy) p_u_66, (ref) v_u_8
				p_u_66.burst("Impact", p138, v_u_8, 0.6)
			end
		},
		["frozen_rinne_e"] = {
			["cast"] = function(p139) -- name: cast
				-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_49, (ref) v_u_9, (ref) v_u_12
				p_u_66.skillCast(p139, v_u_8)
				local v140 = p_u_66.facing(p139.eye + p139.dir * 1.5, p139.dir)
				v_u_49(v140, 1, 5, 0.22, v_u_9)
				v_u_49(v140, 0.6, 3, 0.18, v_u_12)
			end,
			["windup"] = function(p141, p142, p143) -- name: windup
				-- upvalues: (ref) v_u_5, (copy) p_u_66, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9
				local v144 = p141.ability.radius
				v_u_5.ring(p_u_66.ground(p142), v_u_8, v144, p143 + 0.2, v_u_7.Ring)
				p_u_66.pop(p_u_66.ground(p142, 3), v_u_9, 1, 6, p143 + 0.1, 0.4)
				if not p141.lite then
					p_u_66.burst("Smoke", p_u_66.ground(p142, 1), nil, 1)
				end
			end,
			["zone"] = function(p145, p_u_146, p_u_147) -- name: zone
				-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_10, (ref) v_u_40, (ref) v_u_14, (ref) v_u_1, (ref) v_u_5, (ref) v_u_60, (ref) v_u_23, (ref) v_u_4
				local v_u_148 = p145.ability.radius
				local v_u_149 = p145.lite
				local v_u_150 = p_u_66.ground(p_u_146, 0)
				p_u_66.sigil(CFrame.new(p_u_66.ground(p_u_146, 0.12)), v_u_148, v_u_8, v_u_7.Ring, p_u_147, 0.8)
				p_u_66.sigil(CFrame.new(p_u_66.ground(p_u_146, 0.14)), v_u_148 * 0.62, v_u_9, v_u_7.Ring, p_u_147, -1.2)
				p_u_66.sigil(CFrame.new(p_u_66.ground(p_u_146, 0.16)), v_u_148 * 0.3, v_u_10, v_u_7.Ring, p_u_147, 1.6)
				p_u_66.mark(p_u_146, v_u_8, v_u_148 * 0.9, p_u_147 + 0.6, v_u_7.CrackLines, 0.35)
				local v_u_151 = v_u_40(0.5, p_u_66.iris("frozen_rinne"), v_u_14)
				local v_u_152 = v_u_40(0.5, v_u_7.Ring, v_u_8)
				v_u_1:AddItem(v_u_151, p_u_147 + 2)
				v_u_1:AddItem(v_u_152, p_u_147 + 2)
				local v_u_153 = {}
				local v_u_154 = {
					["stopAt"] = nil
				}
				for v155 = 1, v_u_149 and 5 or 10 do
					local v156 = v_u_5.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(v_u_150 + Vector3.new(0, 1, 0)), v_u_9, {
						["shape"] = Enum.PartType.Ball
					})
					v_u_1:AddItem(v156, p_u_147 + 2)
					local v157 = {
						["p"] = nil,
						["trail"] = nil,
						["phase"] = nil,
						["turn"] = nil,
						["lastU"] = 0,
						["p"] = v156,
						["trail"] = v_u_60(v156, v_u_9, v_u_8, 0.9, 0.3),
						["phase"] = v155 / (v_u_149 and 5 or 10),
						["turn"] = math.random() * 3.141592653589793 * 2
					}
					table.insert(v_u_153, v157)
				end
				local v158 = v_u_5.part
				local v159 = v_u_148 * 1.6
				local v160 = v_u_148 * 1.6
				local v161 = v158(Vector3.new(v159, 5, v160), CFrame.new(v_u_150 + Vector3.new(0, 3.5, 0)), v_u_9, {
					["transparency"] = 1
				})
				local v_u_162 = v_u_23(v_u_9, 0.35, 5, 0.9)
				v_u_162.Acceleration = Vector3.new(0, -2, 0)
				v_u_162.Rate = v_u_149 and 6 or 22
				v_u_162.Enabled = true
				v_u_162.Parent = v161
				v_u_1:AddItem(v161, p_u_147 + 2)
				local v_u_163 = p145.ability.tick or 0.32
				local v_u_164 = v_u_163
				local v_u_165 = -1
				local v_u_166 = os.clock()
				p_u_66.runNow(function()
					-- upvalues: (copy) v_u_166, (copy) v_u_154, (ref) v_u_165, (ref) p_u_66, (copy) p_u_146, (ref) v_u_4, (copy) v_u_151, (copy) v_u_152, (copy) v_u_153, (copy) v_u_148, (copy) v_u_150, (ref) v_u_164, (copy) v_u_163, (copy) v_u_149, (ref) v_u_9, (copy) p_u_147, (copy) v_u_162
					local v167 = os.clock()
					local v168 = v167 - v_u_166
					local v169 = v_u_154.stopAt
					local v170
					if v169 then
						local v171 = (v167 - v169) / 0.12
						v170 = math.clamp(v171, 0, 1)
					else
						v170 = 0
					end
					local v172
					if v_u_165 >= 0 then
						local v173 = 1 - (v168 - v_u_165) / 0.2
						v172 = math.max(v173, 0)
					else
						v172 = 0
					end
					local v174 = v168 / 0.2
					local v175 = math.min(v174, 1) * (1 - v170) * 4.6 * (v172 * 0.18 + 1)
					local v176 = p_u_66.ground
					local v177 = p_u_146
					local v178 = v168 * 2.2
					local v179 = v176(v177, math.sin(v178) * 0.25 + 4.4)
					local v180 = v_u_4.CurrentCamera
					local v181
					if v180 then
						local v182 = v180.CFrame.Position - v179
						v181 = v182.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v182.Unit
					else
						v181 = Vector3.new(0, 1, 0)
					end
					local v183 = v_u_151
					local v184 = math.max(v175, 0.05)
					local v185 = math.max(v175, 0.05)
					v183.Size = Vector3.new(v184, 0.05, v185)
					v_u_151.CFrame = p_u_66.facing(v179, v181) * CFrame.Angles(0, v168 * 0.6, 0)
					local v186 = v_u_152
					local v187 = v175 * 1.6
					local v188 = math.max(v187, 0.05)
					local v189 = v175 * 1.6
					local v190 = math.max(v189, 0.05)
					v186.Size = Vector3.new(v188, 0.05, v190)
					v_u_152.CFrame = p_u_66.facing(v179 - v181 * 0.3, v181) * CFrame.Angles(0, -v168 * 1.5, 0)
					for _, v191 in v_u_153 do
						local v192 = (v168 + v191.phase * 0.9) / 0.9 % 1
						if v192 < v191.lastU and v170 == 0 then
							v191.trail:Clear()
						end
						v191.lastU = v192
						local v193 = v_u_148 * (1 - 0.82 * v192)
						local v194 = 0.5 + 6.5 * v192
						local v195 = v191.turn + v168 * 2.2 + v192 * 4
						local v196 = v_u_150
						local v197 = math.cos(v195) * v193
						local v198 = math.sin(v195) * v193
						local v199 = v196 + Vector3.new(v197, v194, v198)
						v191.p.CFrame = CFrame.new(v199:Lerp(v179, v170))
					end
					if v_u_164 <= v168 and v170 == 0 then
						v_u_164 = v_u_164 + v_u_163
						v_u_165 = v168
						if not v_u_149 then
							p_u_66.inward(p_u_66.ground(p_u_146, 1.5), v_u_9, 3, v_u_148, 0.25)
						end
					end
					if v170 < 1 and p_u_147 + 1 >= v168 then
						return true
					end
					v_u_151:Destroy()
					v_u_152:Destroy()
					for _, v200 in v_u_153 do
						v200.p:Destroy()
					end
					v_u_162.Enabled = false
					return false
				end)
				return function()
					-- upvalues: (copy) v_u_154
					v_u_154.stopAt = os.clock()
				end
			end,
			["finish"] = function(p201, p202) -- name: finish
				-- upvalues: (copy) p_u_66, (ref) v_u_14, (ref) v_u_49, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_13, (ref) v_u_31, (ref) v_u_6
				local v203 = p201.ability.radius
				local v204 = p201.lite
				local v205 = p_u_66.ground(p202, 4)
				local v206 = p_u_66.ground(p202, 0)
				p_u_66.pop(v205, v_u_14, 2, v203 * 1.2, 0.25, 0.1)
				local v207 = v_u_49
				local v208 = p_u_66.facing
				local v209 = v_u_4.CurrentCamera
				local v210
				if v209 then
					local v211 = v209.CFrame.Position - v205
					v210 = v211.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v211.Unit
				else
					v210 = Vector3.new(0, 1, 0)
				end
				v207(v208(v205, v210), 2, v203 * 2.2, 0.3, v_u_9)
				p_u_66.spikes(p_u_66.ground(p202, 2), v_u_9, v204 and 6 or 12, v203 * 0.9, 0.25, nil, nil, true)
				p_u_66.burst("Explosion", v205, v_u_8, v203 / 7)
				p_u_66.burst("Shockwave", p_u_66.ground(p202, 0.3), v_u_8, v203 / 14)
				v_u_5.ring(v206, v_u_9, v203 * 1.2, 0.4, v_u_7.SpeedLines)
				p_u_66.chunks(p_u_66.ground(p202, 1), { v_u_13, v_u_9, v_u_8 }, v204 and 3 or 7, 34, 0.9, 0.8)
				if not v204 then
					v_u_31(v205, v_u_9, 18, 0.5, 20)
				end
				v_u_6.play("Explosion", {
					["at"] = v205,
					["volume"] = p201.mine and 0.8 or 0.5
				})
				if p201.mine then
					v_u_5.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(_, p212, _) -- name: hit
				-- upvalues: (copy) p_u_66, (ref) v_u_8
				p_u_66.burst("Impact", p212, v_u_8, 0.7)
			end
		},
		["frozen_rinne_r"] = {
			["cast"] = function(p213) -- name: cast
				-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_9
				p_u_66.skillCast(p213, v_u_8, true)
				p_u_66.burst("Flash", p213.eye, v_u_8, 0.4)
				p_u_66.glint(p213.eye, v_u_9, 7, 0.2)
			end,
			["windup"] = function(p_u_214, p215, p_u_216) -- name: windup
				-- upvalues: (copy) p_u_66, (copy) v_u_67, (ref) v_u_1, (ref) v_u_17, (ref) v_u_40, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_12, (ref) v_u_10, (ref) v_u_8
				local v_u_217 = p_u_214.lite
				local v218 = p_u_214.dir
				local v_u_219 = p215 + v218 * 3.2
				local v_u_220 = p_u_66.aimAt(v_u_219, v218)
				local v_u_221 = {
					["parts"] = nil,
					["fireAt"] = nil,
					["parts"] = {}
				}
				v_u_67[p_u_214] = v_u_221
				local v_u_222 = {}
				for _, v223 in v_u_17 do
					local v224 = v_u_40(0.5, v_u_7.Ring, v223.color)
					v_u_1:AddItem(v224, p_u_216 + 3)
					local v225 = v_u_221.parts
					table.insert(v225, v224)
					local v226 = {
						["p"] = v224,
						["d"] = v223.d,
						["rate"] = v223.rate
					}
					table.insert(v_u_222, v226)
				end
				local v_u_227 = {}
				if not v_u_217 then
					for v228 = 1, 10 do
						local v229 = v_u_5.part
						local v230 = v228 % 2 == 0 and 1.3 or 0.8
						local v231 = v229(Vector3.new(0.28, 0.28, v230), CFrame.new(v_u_219), v_u_9)
						v_u_1:AddItem(v231, p_u_216 + 3)
						local v232 = v_u_221.parts
						table.insert(v232, v231)
						table.insert(v_u_227, v231)
					end
				end
				local v_u_233 = {}
				if not v_u_217 then
					for _ = 1, 3 do
						local v234 = v_u_5.part(Vector3.new(0.62, 0.62, 0.62), CFrame.new(v_u_219), v_u_12, {
							["shape"] = Enum.PartType.Ball,
							["material"] = Enum.Material.SmoothPlastic
						})
						local v235 = v_u_5.part(Vector3.new(0.26, 0.26, 0.8), CFrame.new(v_u_219), v_u_12, {
							["material"] = Enum.Material.SmoothPlastic
						})
						v_u_1:AddItem(v234, p_u_216 + 3)
						local v236 = v_u_221.parts
						table.insert(v236, v234)
						v_u_1:AddItem(v235, p_u_216 + 3)
						local v237 = v_u_221.parts
						table.insert(v237, v235)
						table.insert(v_u_233, {
							["head"] = v234,
							["tail"] = v235
						})
					end
				end
				local v_u_238 = p_u_66.ball(v_u_219, v_u_9, 0.4, 0)
				local v_u_239 = p_u_66.ball(v_u_219, v_u_10, 1, 0.5)
				v_u_1:AddItem(v_u_238, p_u_216 + 3)
				local v240 = v_u_221.parts
				table.insert(v240, v_u_238)
				v_u_1:AddItem(v_u_239, p_u_216 + 3)
				local v241 = v_u_221.parts
				table.insert(v241, v_u_239)
				if not v_u_217 then
					p_u_66.inward(v_u_219, v_u_8, 6, 7, (math.max(p_u_216, 0.12)))
				end
				local v_u_242 = os.clock()
				p_u_66.runNow(function()
					-- upvalues: (copy) v_u_242, (copy) v_u_221, (ref) v_u_67, (copy) p_u_214, (copy) v_u_220, (copy) v_u_222, (copy) v_u_227, (copy) v_u_233, (copy) p_u_216, (copy) v_u_238, (copy) v_u_239, (copy) v_u_217, (ref) p_u_66, (copy) v_u_219, (ref) v_u_9, (ref) v_u_8, (ref) v_u_12
					local v243 = os.clock()
					local v244 = v243 - v_u_242
					local v245 = v_u_221.fireAt
					local v246 = not v245 and 0 or v243 - v245
					if v_u_67[p_u_214] ~= v_u_221 and not v245 then
						v246 = math.max(v246, 0.5)
					end
					local v247 = v244 / 0.15
					local v248 = 1 - (1 - math.min(v247, 1)) ^ 3
					local v249
					if v245 then
						local v250 = v246 / 0.1
						v249 = math.min(v250, 1) * 0.8
					else
						v249 = 0
					end
					local v251 = v_u_220 * CFrame.new(0, 0, -v249)
					local v252 = v245 and 2.5 or 1
					for _, v253 in v_u_222 do
						local v254 = v253.d * v248 * (v249 * 0.15 + 1)
						local v255 = math.max(v254, 0.05)
						v253.p.Size = Vector3.new(v255, 0.05, v255)
						v253.p.CFrame = v251 * CFrame.Angles(0, 0, v244 * v253.rate * v252) * CFrame.Angles(-1.5707963267948966, 0, 0)
					end
					local v256 = v244 * 2 * v252
					for v257, v258 in v_u_227 do
						local v259 = v256 + v257 / #v_u_227 * 3.141592653589793 * 2
						local v260 = v248 * 4.1
						local v261 = v258.Size.Z
						local v262 = math.cos(v259) * (v260 - v261 / 2)
						local v263 = math.sin(v259) * (v260 - v261 / 2)
						local v264 = v251 * Vector3.new(v262, v263, 0)
						v258.CFrame = CFrame.lookAt(v264, v251.Position)
					end
					local v265 = -v244 * 3 * v252
					for v266, v267 in v_u_233 do
						local v268 = v265 + v266 / 3 * 3.141592653589793 * 2
						local v269 = v248 * 2.9
						local v270 = math.cos(v268) * v269
						local v271 = math.sin(v268) * v269
						local v272 = v251 * Vector3.new(v270, v271, 0)
						local v273 = math.sin(v268)
						local v274 = -math.cos(v268)
						local v275 = v251:VectorToWorldSpace((Vector3.new(v273, v274, 0)))
						v267.head.CFrame = CFrame.new(v272)
						v267.tail.CFrame = CFrame.lookAt(v272 + v275 * 0.45, v272 + v275)
					end
					local v276 = p_u_216
					local v277 = v244 / math.max(v276, 0.05)
					local v278 = v_u_238
					local v279 = Vector3.new(1, 1, 1) * (math.clamp(v277, 0, 1) * 1.8 + 0.4)
					local v280 = v246 / 0.4
					v278.Size = v279 * (1 - math.min(v280, 1))
					v_u_238.CFrame = v251
					v_u_239.Size = v_u_238.Size * 1.4
					v_u_239.CFrame = v251
					if v246 < 0.45 then
						return v244 < p_u_216 + 2
					end
					for _, v281 in v_u_221.parts do
						v281:Destroy()
					end
					if v245 and not v_u_217 then
						local v282 = { v_u_9, v_u_8, v_u_12 }
						p_u_66.chunks(v_u_219, v282, 4, 20, 0.5, 0.5, false, 0.6)
					end
					return false
				end)
				task.delay(p_u_216 + 1, function()
					-- upvalues: (ref) v_u_67, (copy) p_u_214, (copy) v_u_221
					if v_u_67[p_u_214] == v_u_221 then
						v_u_67[p_u_214] = nil
					end
				end)
			end,
			["beam"] = function(p_u_283, p_u_284, p_u_285) -- name: beam
				-- upvalues: (copy) v_u_67, (copy) p_u_66, (ref) v_u_8, (ref) v_u_9, (ref) v_u_40, (ref) v_u_7, (ref) v_u_1, (copy) v_u_111, (ref) v_u_5, (ref) v_u_49, (ref) v_u_15, (ref) v_u_13, (ref) v_u_31, (ref) v_u_6, (ref) v_u_65
				local v_u_286 = p_u_283.lite
				local v_u_287 = (p_u_285 - p_u_284).Unit
				local v288 = v_u_67[p_u_283]
				v_u_67[p_u_283] = nil
				if v288 then
					v288.fireAt = os.clock()
				end
				p_u_66.glowBeam(p_u_284, p_u_285, v_u_8, 9, 0.6)
				p_u_66.glowBeam(p_u_284, p_u_285, v_u_9, 3.2, 0.45)
				p_u_66.thin(p_u_66.rod(p_u_284, p_u_285, 2.4, v_u_9, 0.25), 0.4)
				p_u_66.groundLine(p_u_284, p_u_285, 11, v_u_9, 1.8, 0.4)
				p_u_66.groundLine(p_u_284, p_u_285, 4, v_u_8, 1.4, 0.15)
				local v_u_289 = p_u_66.aimAt(p_u_284, v_u_287) * CFrame.Angles(-1.5707963267948966, 0, 0)
				for v_u_290 = 1, v_u_286 and 1 or 4 do
					p_u_66.after((v_u_290 - 1) * 0.07, function()
						-- upvalues: (ref) v_u_40, (ref) v_u_7, (copy) v_u_290, (ref) v_u_8, (ref) v_u_9, (ref) v_u_1, (ref) p_u_66, (copy) v_u_289, (copy) p_u_285, (copy) p_u_284
						local v291 = v_u_40
						local v292 = 8
						local v293 = v_u_7.Ring
						local v294
						if v_u_290 % 2 == 0 then
							v294 = v_u_8
						else
							v294 = v_u_9
						end
						local v_u_295, v_u_296 = v291(v292, v293, v294)
						v_u_1:AddItem(v_u_295, 1)
						p_u_66.animate(0.3, 0, function(p297)
							-- upvalues: (copy) v_u_295, (ref) v_u_289, (ref) p_u_285, (ref) p_u_284, (copy) v_u_296
							local v298 = 8 + 4 * p297
							v_u_295.Size = Vector3.new(v298, 0.05, v298)
							v_u_295.CFrame = v_u_289 + (p_u_285 - p_u_284) * p297
							for _, v299 in v_u_296 do
								v299.Transparency = p297 * 0.7
							end
							if p297 >= 1 then
								v_u_295:Destroy()
							end
						end)
					end)
				end
				v_u_111(p_u_283, p_u_284, p_u_285, 0.22)
				p_u_66.after(0.22, function()
					-- upvalues: (ref) p_u_66, (copy) p_u_285, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_49, (copy) v_u_287, (copy) v_u_286, (ref) v_u_15, (ref) v_u_13, (ref) v_u_1, (ref) v_u_31, (ref) v_u_6, (copy) p_u_283
					local v300 = p_u_66.ground(p_u_285, 0)
					p_u_66.burst("Explosion", p_u_285, v_u_8, 1.6)
					p_u_66.burst("Shockwave", p_u_66.ground(p_u_285, 0.3), v_u_8, 0.9)
					v_u_5.ring(v300, v_u_9, 12, 0.4)
					v_u_49(p_u_66.facing(p_u_285, -v_u_287), 2, 14, 0.35, v_u_9)
					for v301 = 1, v_u_286 and 2 or 5 do
						local v302 = v301 / (v_u_286 and 2 or 5) * 3.141592653589793 * 2 + math.random()
						local v303 = math.cos(v302)
						local v304 = math.sin(v302)
						local v305 = Vector3.new(v303, 0, v304)
						local v306 = v300 + v305 * 1.5
						local v307 = 8 + math.random() * 2.5
						local v308 = CFrame.new(v306) * CFrame.fromAxisAngle((Vector3.new(0, 1, 0)):Cross(v305), 0.5235987755982988)
						local v309 = v_u_5.part(Vector3.new(1.6, v307, 1.6), v308 * CFrame.new(0, v307 / 2, 0) * v_u_15, v_u_13, {
							["material"] = nil,
							["transparency"] = 0.08,
							["material"] = Enum.Material.Ice
						})
						local v310 = v_u_5.part
						local v311 = v307 * 0.35
						for _, v_u_312 in { v309, (v310(Vector3.new(0.9, v311, 0.9), v308 * CFrame.new(0, v307 * 0.85, 0) * v_u_15, v_u_9)) } do
							p_u_66.after(1.2, function()
								-- upvalues: (ref) p_u_66, (copy) v_u_312
								p_u_66.fadeOut(v_u_312, 0.25)
							end)
							v_u_1:AddItem(v_u_312, 2)
						end
					end
					p_u_66.chunks(p_u_66.ground(p_u_285, 1), { v_u_13, v_u_9, v_u_8 }, v_u_286 and 3 or 8, 34, 1, 0.9)
					if not v_u_286 then
						v_u_31(p_u_285, v_u_9, 20, 0.6, 22)
					end
					v_u_6.play("Explosion", {
						["at"] = p_u_285,
						["volume"] = p_u_283.mine and 0.9 or 0.5
					})
				end)
				v_u_6.play("Crit", {
					["at"] = p_u_284,
					["volume"] = p_u_283.mine and 0.7 or 0.4
				})
				if p_u_283.mine then
					v_u_5.shake(0.5, 0.45)
					v_u_65()
				end
			end,
			["hit"] = function(_, p313, _) -- name: hit
				-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_9
				p_u_66.burst("Impact", p313, v_u_8, 0.9)
				p_u_66.pop(p313, v_u_9, 1, 3.5, 0.12, 0.3)
			end
		}
	}
	return v314
end