require(script.Parent.Training)
return {
	{
		["id"] = "w6_soul_dummy",
		["name"] = "Soul Dummy",
		["theme"] = "dummy",
		["rebirths"] = 369,
		["mult"] = 1.9e19,
		["color"] = "#F2F2F2"
	},
	{
		["id"] = "w6_reiatsu_ring",
		["name"] = "Reiatsu Ring",
		["theme"] = "ring",
		["rebirths"] = 381,
		["mult"] = 6.1e19,
		["color"] = "#9FD8FF"
	},
	{
		["id"] = "w6_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 1.95e20,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w6_shrine_falls",
		["name"] = "Shrine Falls",
		["theme"] = "waterfall",
		["rebirths"] = 393,
		["mult"] = 1.95e20,
		["color"] = "#5AB8FF"
	},
	{
		["id"] = "w6_zanpakuto_forge",
		["name"] = "Zanpakuto Forge",
		["theme"] = "forge",
		["rebirths"] = 405,
		["mult"] = 6.2e20,
		["color"] = "#FF8A3A"
	},
	{
		["id"] = "w6_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 2e21,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w6_gotei_temple",
		["name"] = "Gotei Temple",
		["theme"] = "temple",
		["rebirths"] = 417,
		["mult"] = 2e21,
		["color"] = "#FF7FB8"
	},
	{
		["id"] = "w6_shunpo_tower",
		["name"] = "Shunpo Tower",
		["theme"] = "storm",
		["rebirths"] = 429,
		["mult"] = 6.4e21,
		["color"] = "#CFE1FF"
	},
	{
		["id"] = "w6_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 2.05e22,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w6_reiatsu_chamber",
		["name"] = "Reiatsu Chamber",
		["theme"] = "gravity",
		["rebirths"] = 441,
		["mult"] = 2.05e22,
		["color"] = "#7A4DFF"
	},
	{
		["id"] = "w6_sokyoku_shrine",
		["name"] = "Sokyoku Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 453,
		["mult"] = 6.6e22,
		["color"] = "#FF4A1A"
	},
	{
		["id"] = "w6_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 7.1e23,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w6_bankai_altar",
		["name"] = "Bankai Altar",
		["theme"] = "void",
		["rebirths"] = 465,
		["mult"] = 2.1e23,
		["color"] = "#E0141E"
	}
}