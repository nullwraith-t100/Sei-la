local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.EpicKit8)
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v2.Shared.Config.Textures)
v6.images({
	v_u_8.ObiSash,
	v_u_8.SickleX,
	v_u_8.PoisonSplat,
	v_u_8.Glow
})
local v_u_9 = Color3.fromHex("E0213A")
local v_u_10 = Color3.fromHex("9CFF3D")
local v_u_11 = Color3.fromRGB(255, 150, 160)
local v_u_12 = Color3.fromRGB(70, 4, 18)
local v_u_13 = Color3.fromRGB(40, 20, 16)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.Material.Neon
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_21(p17, p18, p19, p20) -- name: groundCut
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_9
	v_u_4.flat(p17, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.35,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["rot"] = nil,
		["image"] = v_u_8.SickleX,
		["color"] = v_u_9,
		["life"] = p19,
		["sizes"] = {
			{ 0, p18 * 0.5 },
			{ 0.12, p18 },
			{ 1, p18 * 1.05 }
		},
		["alphas"] = {
			{ 0, 0.2 },
			{ 0.12, 0 },
			{ 0.6, 0.15 },
			{ 1, 1 }
		},
		["rot"] = p20
	})
end
local function v_u_25(p22, p23, p24) -- name: groundPoison
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_10
	v_u_4.flat(p22, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.3,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["image"] = v_u_8.PoisonSplat,
		["color"] = v_u_10,
		["life"] = p24,
		["sizes"] = {
			{ 0, p23 * 0.4 },
			{ 0.12, p23 },
			{ 1, p23 * 1.05 }
		},
		["alphas"] = {
			{ 0, 0.2 },
			{ 0.6, 0.3 },
			{ 1, 1 }
		}
	})
end
local function v_u_29(p26, p27, p28) -- name: airCut
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_11
	v_u_4.puff(p26, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.6,
		["count"] = 1,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["image"] = v_u_8.SickleX,
		["color"] = v_u_9,
		["color2"] = v_u_11,
		["life"] = { p28, p28 },
		["sizes"] = {
			{ 0, p27 * 0.3 },
			{ 0.2, p27 },
			{ 1, p27 * 1.15 }
		},
		["alphas"] = {
			{ 0, 0.2 },
			{ 0.25, 0 },
			{ 1, 1 }
		},
		["speed"] = { 0 }
	})
end
local function v_u_34(p30, p31, p32, p33) -- name: poison
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_10
	v_u_4.puff(p30, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.45,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["speed"] = nil,
		["accel"] = Vector3.new(0, -40, 0),
		["drag"] = 1.5,
		["spin"] = 90,
		["image"] = v_u_8.PoisonSplat,
		["color"] = v_u_10,
		["count"] = p31,
		["life"] = { 0.4, 0.7 },
		["sizes"] = {
			{ 0, p33 },
			{ 1, p33 * 0.4 }
		},
		["speed"] = { p32 * 0.5, p32 }
	})
end
local function v_u_58(p35, p36, p37) -- name: sickle
	-- upvalues: (copy) v_u_4, (copy) v_u_13, (copy) v_u_16, (copy) v_u_11, (copy) v_u_9, (copy) v_u_15
	local v38 = {}
	local v39 = v_u_4.part(v_u_13, v_u_16, p36)
	v39.Size = Vector3.new(0.22, 0.22, 1.5) * p35
	local v40 = {
		["p"] = v39,
		["off"] = CFrame.new(0, 0, p35 * 0.35)
	}
	table.insert(v38, v40)
	local v41 = Vector3.new(0.75, 0, -0.4) * p35
	local v42 = p35 * 0.75
	local v43 = p37 and 3 or 4
	local v44 = nil
	for v45 = 0, v43 do
		local v46 = 180 - v45 * (190 / v43)
		local v47 = math.rad(v46)
		local v48 = math.cos(v47)
		local v49 = -math.sin(v47)
		local v50 = v41 + Vector3.new(v48, 0, v49) * v42
		if v44 then
			local v51 = (v50 - v44).Magnitude * 1.12
			local v52 = (0.42 - v45 * 0.07) * p35
			local v53 = v_u_4.part
			local v54
			if v45 == v43 then
				v54 = v_u_11
			else
				v54 = v_u_9
			end
			local v55 = v53(v54, v_u_15, p36)
			local v56 = p35 * 0.1
			v55.Size = Vector3.new(v52, v56, v51)
			local v57 = {
				["p"] = v55,
				["off"] = CFrame.lookAt((v50 + v44) / 2, v50)
			}
			table.insert(v38, v57)
		end
		v44 = v50
	end
	return v38
end
return function(p_u_59)
	-- upvalues: (copy) v_u_9, (copy) v_u_29, (copy) v_u_34, (copy) v_u_21, (copy) v_u_5, (copy) v_u_58, (copy) v_u_4, (copy) v_u_12, (copy) v_u_1, (copy) v_u_8, (copy) v_u_10, (copy) v_u_25, (copy) v_u_11, (copy) v_u_14, (copy) v_u_3, (copy) v_u_7
	local v60 = {}
	local function v_u_64(p61, p62) -- name: sickleCast
		-- upvalues: (copy) p_u_59, (ref) v_u_9, (ref) v_u_29, (ref) v_u_34, (ref) v_u_21, (ref) v_u_5
		local v63 = p61.size
		p_u_59.burst("Flash", p61.eye, v_u_9, (p62 and 0.3 or 0.2) * v63)
		v_u_29(p61.eye + p61.dir * 1.6, (p62 and 5 or 3.5) * v63, 0.35)
		if not p61.lite then
			v_u_34(p61.eye + p61.dir, p62 and 8 or 4, 14, 0.5 * v63)
		end
		v_u_21(p_u_59.ground(p61.feet, 0.12), (p62 and 9 or 6) * v63, 0.6)
		if p61.mine then
			v_u_5.shake(p62 and 0.12 or 0.06, 0.14)
		end
	end
	v60.blood_sickle_a = {
		["cast"] = nil,
		["shot"] = nil,
		["keep"] = 0.12,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p65) -- name: cast
			-- upvalues: (copy) p_u_59, (ref) v_u_9
			local v66 = p65.size
			p_u_59.glint(p65.eye + p65.dir * 1.2, v_u_9, 2.4 * v66, 0.1)
		end,
		["shot"] = function(p67, p68) -- name: sickleShot
			-- upvalues: (ref) v_u_58, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (ref) v_u_5, (ref) v_u_1, (ref) v_u_8, (ref) v_u_10, (copy) p_u_59
			local v69 = p67.size
			local v_u_70 = v_u_58(1.15 * v69, 3, p67.lite)
			local v71 = v_u_70[#v_u_70].p
			v_u_4.trail(v71, v_u_9, v_u_12, 0.5 * v69, 0.16, 0.4)
			local v_u_72 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p68, v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_72, 3)
			if not p67.lite then
				local v73 = Instance.new("ParticleEmitter")
				v73.Texture = v_u_8.PoisonSplat
				v73.Color = ColorSequence.new(v_u_10)
				v73.LightEmission = 0.5
				v73.LightInfluence = 0
				v73.Lifetime = NumberRange.new(0.2, 0.35)
				v73.Size = v_u_4.seq({
					{ 0, 0.35 },
					{ 1, 0.1 }
				}, v69)
				v73.Speed = NumberRange.new(1, 3)
				v73.SpreadAngle = Vector2.new(180, 180)
				v73.Rate = 30
				v73.Parent = v_u_72
			end
			if p67.mine then
				p_u_59.light(v_u_72, v_u_9, 6 * v69)
			end
			local v_u_74 = false
			return {
				["place"] = function(p75, p76) -- name: place
					-- upvalues: (copy) v_u_72, (copy) v_u_70
					v_u_72.CFrame = p75
					local v77 = p75 * CFrame.Angles(0.25, p76 * 26, 0)
					for _, v78 in v_u_70 do
						v78.p.CFrame = v77 * v78.off
					end
				end,
				["stop"] = function(p79) -- name: stop
					-- upvalues: (ref) v_u_74, (copy) v_u_72, (ref) v_u_1, (copy) v_u_70, (ref) v_u_5
					if not v_u_74 then
						v_u_74 = true
						for _, v80 in v_u_72:GetChildren() do
							if v80:IsA("ParticleEmitter") then
								v80.Enabled = false
							else
								if not v80:IsA("PointLight") then
									continue
								end
								v80:Destroy()
							end
						end
						v_u_1:AddItem(v_u_72, 0.4)
						local v81 = p79 or 0
						for _, v82 in v_u_70 do
							if v81 > 0 then
								v_u_5.tween(v82.p, v81, {
									["Transparency"] = 1
								})
								v_u_1:AddItem(v82.p, v81 + 0.05)
							else
								v82.p:Destroy()
							end
						end
					end
				end
			}
		end,
		["impact"] = function(p83, p84) -- name: impact
			-- upvalues: (copy) p_u_59, (ref) v_u_29, (ref) v_u_21, (ref) v_u_25, (ref) v_u_34, (ref) v_u_11
			local v85 = p83.size
			local v86 = p_u_59.ground(p84, 0.1)
			v_u_29(p84 + Vector3.new(0, 0.5, 0), 5 * v85, 0.35)
			v_u_21(v86, 5.5 * v85, 0.7, math.random() * 360)
			v_u_25(v86 + Vector3.new(0, 0.02, 0), 3.5 * v85, 0.9)
			if not p83.lite then
				v_u_34(p84, 6, 16, 0.5 * v85)
			end
			p_u_59.glint(p84, v_u_11, 2.6 * v85, 0.12)
			p_u_59.hitSound(p84)
		end,
		["hit"] = function(_, p87, _) -- name: hit
			-- upvalues: (copy) p_u_59, (ref) v_u_9
			p_u_59.burst("Impact", p87, v_u_9, 0.55)
		end
	}
	local function v_u_130(p88, p89, p90, p91) -- name: wrap
		-- upvalues: (ref) v_u_4, (copy) p_u_59, (ref) v_u_9, (ref) v_u_8, (ref) v_u_14, (ref) v_u_34, (ref) v_u_3
		local v92 = v_u_4.foe(p90)
		local v_u_93
		if v92 then
			v_u_93 = v92:FindFirstChild("HumanoidRootPart") or v92.PrimaryPart
		else
			v_u_93 = v92
		end
		local v_u_94 = p88.ability.freeze or 3
		if v92 and (v_u_93 and v_u_93:IsA("BasePart")) then
			local v95 = v92:GetExtentsSize()
			local v96 = v95.X
			local v97 = v95.Z
			local v98 = math.max(v96, v97) * 0.6
			local v_u_99 = math.clamp(v98, 1.2, 5)
			local v100 = v95.Y
			local v_u_101 = math.clamp(v100, 3, 12)
			local v_u_102 = {}
			for _ = 0, 4 do
				local v103 = Instance.new("Attachment")
				v103.Parent = v_u_93
				table.insert(v_u_102, v103)
			end
			local v_u_104 = {}
			for v105 = 1, 4 do
				local v106 = v_u_102[v105]
				local v107 = v_u_102[v105 + 1]
				local v108 = v_u_4.beam(v106, v107, v_u_8.ObiSash, v_u_14, 0.75, 0.15, 3, 0)
				v108.Segments = 16
				table.insert(v_u_104, v108)
			end
			local v_u_109
			if p91 then
				local v110 = v_u_102[1]
				v_u_109 = v_u_4.beam(v110, p91, v_u_8.ObiSash, v_u_14, 0.6, 0.15, 2.4, 0)
				v_u_109.Segments = 16
				v_u_109.CurveSize0 = 2
			else
				v_u_109 = nil
			end
			local v_u_111 = os.clock()
			local function v_u_116(p112) -- name: done
				-- upvalues: (copy) v_u_104, (ref) v_u_109, (copy) v_u_102, (ref) v_u_34
				for _, v113 in v_u_104 do
					v113:Destroy()
				end
				local v114 = v_u_109
				if v114 then
					v114:Destroy()
				end
				for _, v115 in v_u_102 do
					if p112 and v115.Parent then
						v_u_34(v115.WorldPosition, 2, 10, 0.4)
					end
					v115:Destroy()
				end
			end
			p_u_59.frame(function()
				-- upvalues: (copy) v_u_111, (copy) v_u_93, (ref) v_u_3, (copy) v_u_104, (ref) v_u_109, (copy) v_u_102, (copy) v_u_94, (copy) v_u_116, (copy) v_u_99, (ref) v_u_4, (copy) v_u_101
				local v117 = os.clock() - v_u_111
				if v_u_93.Parent and v_u_93:IsDescendantOf(v_u_3) then
					if v_u_94 <= v117 then
						v_u_116(true)
						return false
					end
					local v118 = v_u_99 * (1 + 1.5 * (1 - v_u_4.smooth(v117 / 0.2)))
					for v119, v120 in v_u_102 do
						local v121 = (v119 - 1) / 4
						local v122 = v117 * 1.4 + v121 * 3.141592653589793 * 2 * 1.5
						local v123 = math.cos(v122) * v118
						local v124 = (v121 - 0.5) * v_u_101 * 0.8
						local v125 = math.sin(v122) * v118
						v120.Position = Vector3.new(v123, v124, v125)
					end
					for _, v126 in v_u_104 do
						v126.CurveSize0 = v118 * 0.55
						v126.CurveSize1 = -v118 * 0.55
					end
					return true
				else
					for _, v127 in v_u_104 do
						v127:Destroy()
					end
					local v128 = v_u_109
					if v128 then
						v128:Destroy()
					end
					for _, v129 in v_u_102 do
						v129:Destroy()
					end
					return false
				end
			end)
		else
			p_u_59.burst("Impact", p89, v_u_9, 0.7)
		end
	end
	local v_u_131 = {}
	setmetatable(v_u_131, {
		["__mode"] = "k"
	})
	v60.blood_sickle_e = {
		["cast"] = function(p132) -- name: cast
			-- upvalues: (copy) v_u_64
			v_u_64(p132, false)
		end,
		["windup"] = function(p133, p134, p135) -- name: windup
			-- upvalues: (copy) p_u_59, (ref) v_u_4, (ref) v_u_8, (ref) v_u_14
			local v_u_136 = p133.size
			local v_u_137 = p_u_59.ground(p134, 0.6)
			local v138 = math.max(p135, 0.12) + 0.12
			local v_u_139 = v_u_4.holder(p133.feet + Vector3.new(0, 2.2, 0), v138 + 0.2)
			for v_u_140 = -1, p133.lite and 0 or 1 do
				local v_u_141 = v_u_4.holder(v_u_139.WorldPosition, v138 + 0.2)
				local v142 = 1 * v_u_136
				local v_u_143 = v_u_4.beam(v_u_139, v_u_141, v_u_8.ObiSash, v_u_14, v142, 0.15, v142 * 4, 0)
				v_u_143.Segments = 16
				local v_u_144 = v_u_4.side(p133.dir) * v_u_140 * 3
				p_u_59.animate(v138, 0, function(p145)
					-- upvalues: (copy) v_u_141, (copy) v_u_139, (copy) v_u_137, (copy) v_u_144, (copy) v_u_143, (copy) v_u_140, (copy) v_u_136
					local v146 = 1 - (1 - p145) * (1 - p145)
					v_u_141.WorldPosition = v_u_139.WorldPosition:Lerp(v_u_137 + v_u_144, v146)
					local v147 = v_u_143
					local v148 = p145 * 9 + v_u_140
					v147.CurveSize0 = math.sin(v148) * 3 * v_u_136
					local v149 = v_u_143
					local v150 = p145 * 7 + v_u_140
					v149.CurveSize1 = math.cos(v150) * 2.5 * v_u_136
				end)
			end
		end,
		["land"] = function(p151, p152) -- name: land
			-- upvalues: (copy) p_u_59, (ref) v_u_21, (ref) v_u_25, (ref) v_u_4, (copy) v_u_131, (ref) v_u_8, (ref) v_u_14, (ref) v_u_29, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5, (ref) v_u_34
			local v_u_153 = p151.size
			local v_u_154 = p151.lite
			local v155 = p151.ability.radius * v_u_153
			local v_u_156 = p151.ability.freeze or 3
			local v_u_157 = p_u_59.ground(p152, 0.1)
			v_u_21(v_u_157, v155 * 1.3, v_u_156 + 0.4)
			v_u_25(v_u_157 + Vector3.new(0, 0.02, 0), v155 * 0.7, v_u_156)
			local v158 = v_u_4.holder(v_u_157 + Vector3.new(0, 0.6, 0), v_u_156 + 0.5)
			v_u_131[p151] = {
				["at"] = v158
			}
			local v159 = v_u_154 and 4 or 7
			local v_u_160 = {}
			for v161 = 1, v159 do
				local v162 = v161 * 3.141592653589793 * 2 / v159 + math.random() * 0.3
				local v163 = v_u_4.holder
				local v164 = math.cos(v162)
				local v165 = math.sin(v162)
				local v166 = v163(v_u_157 + Vector3.new(v164, 0.15, v165) * v155 * 0.95, v_u_156 + 0.5)
				local v167 = 1.1 * v_u_153
				local v168 = v_u_4.beam(v158, v166, v_u_8.ObiSash, v_u_14, v167, 0.15, v167 * 4, 0)
				v168.Segments = 16
				table.insert(v_u_160, v168)
			end
			local v_u_169 = os.clock()
			p_u_59.frame(function()
				-- upvalues: (copy) v_u_169, (copy) v_u_156, (copy) v_u_160, (ref) v_u_4, (copy) v_u_153
				local v170 = os.clock() - v_u_169
				if v_u_156 <= v170 then
					for _, v171 in v_u_160 do
						v171:Destroy()
					end
					return false
				end
				local v172 = v_u_4.smooth(v170 / 0.18)
				for v173, v174 in v_u_160 do
					local v175 = v170 * 5 + v173 * 1.7
					v174.CurveSize0 = math.sin(v175) * 3 * v_u_153 * v172
					local v176 = v170 * 4 + v173
					v174.CurveSize1 = math.cos(v176) * 2.5 * v_u_153 * v172
				end
				return true
			end)
			v_u_29(v_u_157 + Vector3.new(0, 3, 0), 7 * v_u_153, 0.4)
			p_u_59.glint(v_u_157 + Vector3.new(0, 1.5, 0), v_u_11, 6 * v_u_153, 0.2)
			v_u_7.play("Hit", {
				["at"] = v_u_157,
				["volume"] = p151.mine and 0.7 or 0.4
			})
			if p151.mine then
				v_u_5.shake(0.18, 0.2)
			end
			p_u_59.after(v_u_156, function()
				-- upvalues: (ref) v_u_34, (copy) v_u_157, (copy) v_u_154, (copy) v_u_153, (ref) v_u_29
				v_u_34(v_u_157 + Vector3.new(0, 1, 0), v_u_154 and 4 or 12, 18, 0.6 * v_u_153)
				v_u_29(v_u_157 + Vector3.new(0, 2, 0), 6 * v_u_153, 0.35)
			end)
		end,
		["hit"] = function(p177, p178, p179) -- name: hit
			-- upvalues: (copy) p_u_59, (ref) v_u_9, (copy) v_u_131, (copy) v_u_130
			if p177.lite then
				p_u_59.burst("Impact", p178, v_u_9, 0.6)
			else
				local v180 = v_u_131[p177]
				local v181 = v_u_130
				local v182
				if v180 then
					v182 = v180.at
				else
					v182 = nil
				end
				v181(p177, p178, p179, v182)
			end
		end
	}
	local function v_u_210(p_u_183, p_u_184, p_u_185, p186, p_u_187, p_u_188, p189) -- name: arc
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_4, (ref) v_u_11, (ref) v_u_12, (copy) p_u_59
		local v_u_190 = CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0) * CFrame.Angles((math.random() - 0.5) * 1.1, 0, 0)
		local v_u_191 = math.random() < 0.5 and -1 or 1
		local v_u_192 = math.random() * 3.141592653589793 * 2
		local v193 = p186 + 0.4
		local v_u_194 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_183), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_194, v193)
		v_u_4.trail(v_u_194, v_u_11, v_u_9, p_u_188 * 2.4, 0.24, 0.5)
		local v_u_195
		if p189 then
			v_u_195 = nil
		else
			v_u_195 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_183), v_u_12, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_195, v193)
			v_u_4.trail(v_u_195, v_u_12, v_u_12, p_u_188 * 0.6, 0.24, 0)
		end
		p_u_59.animate(p186, 0, function(p196)
			-- upvalues: (copy) p_u_184, (copy) p_u_185, (copy) v_u_192, (copy) v_u_191, (copy) p_u_187, (copy) v_u_190, (copy) p_u_183, (copy) v_u_194, (ref) v_u_195, (copy) p_u_188
			local v197 = 1 - (1 - p196) * (1 - p196)
			local v198 = p_u_184 + (p_u_185 - p_u_184) * v197
			local v199 = v_u_192 + v_u_191 * p_u_187 * v197
			local v200 = v_u_190
			local v201 = math.cos(v199)
			local v202 = math.sin(v199)
			local v203 = v200:VectorToWorldSpace((Vector3.new(v201, 0, v202)))
			local v204 = v_u_190
			local v205 = -math.sin(v199)
			local v206 = math.cos(v199)
			local v207 = v204:VectorToWorldSpace((Vector3.new(v205, 0, v206))) * v_u_191
			local v208 = p_u_183 + v203 * v198
			v_u_194.CFrame = CFrame.fromMatrix(v208, v207, v203)
			local v209 = v_u_195
			if v209 then
				v209.CFrame = CFrame.fromMatrix(v208 + v203 * 1.5 * p_u_188, v207, v203)
			end
		end)
	end
	v60.blood_sickle_r = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["land"] = nil,
		["hit"] = nil,
		["cast"] = function(p211) -- name: cast
			-- upvalues: (copy) v_u_64
			v_u_64(p211, true)
		end,
		["windup"] = function(p212, p213, p214) -- name: windup
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_4, (ref) v_u_11, (copy) p_u_59, (ref) v_u_8
			local v_u_215 = p212.size
			local v216 = math.max(p214, 0.15) + 0.05
			local v_u_217 = p212.feet + Vector3.new(0, 0.5, 0)
			for v_u_218 = 0, p212.lite and 0 or 1 do
				local v_u_219 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_217), v_u_9, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_219, v216 + 0.5)
				v_u_4.trail(v_u_219, v_u_11, v_u_9, 0.9 * v_u_215, 0.25, 0.5)
				p_u_59.animate(v216, 0, function(p220)
					-- upvalues: (copy) v_u_218, (copy) v_u_217, (copy) v_u_215, (copy) v_u_219
					local v221 = p220 * 3.141592653589793 * 4 + v_u_218 * 3.141592653589793
					local v222 = math.cos(v221)
					local v223 = math.sin(v221)
					local v224 = Vector3.new(v222, 0, v223)
					local v225 = v_u_217 + v224 * 3 * v_u_215 + Vector3.new(0, 1, 0) * p220 * 6 * v_u_215
					v_u_219.CFrame = CFrame.fromMatrix(v225, v224:Cross(Vector3.new(0, 1, 0)), Vector3.new(0, 1, 0))
				end)
			end
			v_u_4.flat(p_u_59.ground(p213, 0.12), {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0.4,
				["life"] = nil,
				["sizes"] = nil,
				["alphas"] = nil,
				["spin"] = 400,
				["image"] = v_u_8.SickleX,
				["color"] = v_u_9,
				["life"] = v216 + 0.2,
				["sizes"] = {
					{ 0, 2 * v_u_215 },
					{ 1, 8 * v_u_215 }
				},
				["alphas"] = {
					{ 0, 0.5 },
					{ 0.6, 0.1 },
					{ 1, 1 }
				}
			})
		end,
		["land"] = function(p226, p227) -- name: land
			-- upvalues: (copy) p_u_59, (copy) v_u_210, (ref) v_u_21, (ref) v_u_25, (ref) v_u_4, (ref) v_u_8, (ref) v_u_12, (ref) v_u_9, (ref) v_u_34, (ref) v_u_11, (ref) v_u_7, (ref) v_u_5
			local v_u_228 = p226.size
			local v_u_229 = p226.lite
			local v_u_230 = p226.ability.radius * v_u_228
			local v231 = p_u_59.ground(p227, 0.1)
			local v_u_232 = v231 + Vector3.new(0, 2.5, 0)
			for v233 = 1, v_u_229 and 6 or 16 do
				p_u_59.after((v233 - 1) * 0.025, function()
					-- upvalues: (ref) v_u_210, (copy) v_u_232, (copy) v_u_228, (copy) v_u_230, (copy) v_u_229
					v_u_210(v_u_232, 2.5 * v_u_228, v_u_230 * (0.75 + math.random() * 0.25), 0.4, 3 + math.random() * 1.5, v_u_228, v_u_229)
				end)
			end
			for v_u_234 = 1, v_u_229 and 3 or 9 do
				local v235 = v_u_234 * 2.39996 + math.random()
				local v236 = v_u_230 * (0.25 + 0.7 * math.random())
				local v237 = math.cos(v235)
				local v238 = math.sin(v235)
				local v_u_239 = v231 + Vector3.new(v237, 0, v238) * v236
				p_u_59.after(0.08 + math.random() * 0.25, function()
					-- upvalues: (ref) v_u_21, (copy) v_u_239, (copy) v_u_228, (copy) v_u_234, (ref) v_u_25
					v_u_21(v_u_239, (6 + math.random() * 4) * v_u_228, 0.9, math.random() * 360)
					if v_u_234 % 2 == 0 then
						v_u_25(v_u_239 + Vector3.new(0, 0.02, 0), 3.5 * v_u_228, 1)
					end
				end)
			end
			v_u_4.flat(v231, {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0,
				["life"] = 1.2,
				["sizes"] = nil,
				["alphas"] = nil,
				["image"] = v_u_8.Glow,
				["color"] = v_u_12,
				["sizes"] = {
					{ 0, v_u_230 * 0.4 },
					{ 0.2, v_u_230 * 1.9 },
					{ 1, v_u_230 * 2 }
				},
				["alphas"] = {
					{ 0, 0.6 },
					{ 0.2, 0.35 },
					{ 1, 1 }
				}
			})
			p_u_59.burst("Shockwave", v231, v_u_9, 1.3 * v_u_228)
			if not v_u_229 then
				v_u_34(v_u_232, 14, 30, 0.7 * v_u_228)
				local v240 = { v_u_12, v_u_9 }
				p_u_59.chunks(v231 + Vector3.new(0, 0.5, 0), v240, 10, 30, 0.5 * v_u_228, 0.9, false, 0.7)
			end
			p_u_59.glint(v_u_232, v_u_11, 8 * v_u_228, 0.25)
			v_u_7.play("Explosion", {
				["at"] = v231,
				["volume"] = p226.mine and 0.9 or 0.5
			})
			if p226.mine then
				v_u_5.shake(0.35, 0.35)
			end
		end,
		["hit"] = function(p241, p242, _) -- name: hit
			-- upvalues: (copy) p_u_59, (ref) v_u_9, (ref) v_u_29
			p_u_59.burst("Impact", p242, v_u_9, 0.65)
			if not p241.lite then
				v_u_29(p242, 3, 0.25)
			end
		end
	}
	return v60
end