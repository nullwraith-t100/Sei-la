require(script.Parent.Training)
return {
	{
		["id"] = "w3_bonedummy",
		["name"] = "Bone Dummy",
		["theme"] = "dummy",
		["rebirths"] = 150,
		["mult"] = 1600000,
		["color"] = "#E8D8C8"
	},
	{
		["id"] = "w3_bloodring",
		["name"] = "Blood Ring",
		["theme"] = "ring",
		["rebirths"] = 157,
		["mult"] = 5120000,
		["color"] = "#FF3B4E"
	},
	{
		["id"] = "w3_golden_dojo",
		["name"] = "Golden Dojo",
		["theme"] = "golddojo",
		["rebirths"] = 0,
		["mult"] = 16400000,
		["color"] = "#FFC93C",
		["pass"] = "train1"
	},
	{
		["id"] = "w3_crimsonfalls",
		["name"] = "Crimson Falls",
		["theme"] = "waterfall",
		["rebirths"] = 164,
		["mult"] = 16400000,
		["color"] = "#FF5A64"
	},
	{
		["id"] = "w3_hellforge",
		["name"] = "Hell Forge",
		["theme"] = "forge",
		["rebirths"] = 172,
		["mult"] = 52400000,
		["color"] = "#FF7A12"
	},
	{
		["id"] = "w3_thunder_dome",
		["name"] = "Thunder Dome",
		["theme"] = "thunderdome",
		["rebirths"] = 0,
		["mult"] = 168000000,
		["color"] = "#5CC8FF",
		["pass"] = "train2"
	},
	{
		["id"] = "w3_demontemple",
		["name"] = "Demon Temple",
		["theme"] = "temple",
		["rebirths"] = 179,
		["mult"] = 168000000,
		["color"] = "#C8101E"
	},
	{
		["id"] = "w3_redstormtower",
		["name"] = "Red Storm Tower",
		["theme"] = "storm",
		["rebirths"] = 186,
		["mult"] = 537000000,
		["color"] = "#FF8FA0"
	},
	{
		["id"] = "w3_dragon_sanctum",
		["name"] = "Dragon Sanctum",
		["theme"] = "dragon",
		["rebirths"] = 0,
		["mult"] = 1720000000,
		["color"] = "#FF4FA3",
		["pass"] = "train3"
	},
	{
		["id"] = "w3_moonchamber",
		["name"] = "Moon Chamber",
		["theme"] = "gravity",
		["rebirths"] = 193,
		["mult"] = 1720000000,
		["color"] = "#E6D2FF"
	},
	{
		["id"] = "w3_bloodmoonshrine",
		["name"] = "Blood Moon Shrine",
		["theme"] = "bloodmoon",
		["rebirths"] = 200,
		["mult"] = 5500000000,
		["color"] = "#E3122E"
	},
	{
		["id"] = "w3_six_paths_throne",
		["name"] = "Six Paths Throne",
		["theme"] = "sixpaths",
		["rebirths"] = 0,
		["mult"] = 88000000000,
		["color"] = "#FFF27A",
		["pass"] = "train4"
	},
	{
		["id"] = "w3_crimsonaltar",
		["name"] = "Crimson Altar",
		["theme"] = "void",
		["rebirths"] = 208,
		["mult"] = 17600000000,
		["color"] = "#FFD9DE"
	}
}