local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("6B2BD9")
local v_u_9 = Color3.fromHex("D9B8FF")
local v_u_10 = Color3.fromRGB(22, 8, 44)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = CFrame.Angles(0.8726646259971648, 0, 0)
local function v_u_34(p13, p14, p15, p16) -- name: bladeLayout
	local v17 = {}
	for v18 = 0, 3 do
		local v19 = v18 * 3.141592653589793 / 2
		local v20 = math.cos(v19)
		local v21 = math.sin(v19)
		local v22 = Vector3.new(v20, 0, v21) * p13 * 0.14
		for v23 = 1, p14 do
			local v24 = v23 / p14
			local v25 = v19 + p15 * v24
			local v26 = math.cos(v25)
			local v27 = math.sin(v25)
			local v28 = Vector3.new(v26, 0, v27) * p13 * (v24 * 0.86 + 0.14)
			local v29 = p16 * (1 - (v23 - 1) * 0.5 / math.max(p14, 1))
			local v30 = {
				["off"] = CFrame.lookAt((v22 + v28) / 2, v28)
			}
			local v31 = p16 * 0.22
			local v32 = math.max(v31, 0.12)
			local v33 = (v28 - v22).Magnitude + v29 * 0.35
			v30.size = Vector3.new(v29, v32, v33)
			v30.tip = v23 == p14
			table.insert(v17, v30)
			v22 = v28
		end
	end
	return v17
end
local function v_u_46(p35, p36, p37, p38, p39, p40) -- name: newWheel
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v41 = {}
	local v42 = {}
	for _, v43 in p35 do
		local v44
		if v43.tip then
			v44 = p38
		else
			v44 = p37
		end
		local v45 = v_u_5.part(v43.size, p36 * v43.off, v44, {
			["transparency"] = p39
		})
		v_u_1:AddItem(v45, p40)
		table.insert(v42, v45)
		table.insert(v41, v44)
	end
	return {
		["parts"] = v42,
		["layout"] = p35,
		["colors"] = v41
	}
end
local function v_u_54(p47, p48, p49) -- name: placeWheel
	local v50 = math.max(p49, 0.02)
	for v51, v52 in p47.parts do
		local v53 = p47.layout[v51].off
		v52.CFrame = p48 * (v53 - v53.Position + v53.Position * v50)
		v52.Size = p47.layout[v51].size * v50
	end
end
local function v_u_72(p55, p56, p57, p58, p59) -- name: phaseOut
	-- upvalues: (copy) v_u_4, (copy) v_u_46, (copy) v_u_34, (copy) v_u_54
	local v60 = p55.facing
	local v61 = v_u_4.CurrentCamera
	local v62
	if v61 then
		local v63 = v61.CFrame.Position - p56
		v62 = v63.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v63.Unit
	else
		v62 = Vector3.new(0, 1, 0)
	end
	local v_u_64 = v60(p56, v62)
	local v_u_65 = v_u_46(v_u_34(p58, 1, 1.2, p58 * 0.26), v_u_64, p57, p57, 0.1, p59 + 0.3)
	p55.animate(p59, 0, function(p66)
		-- upvalues: (ref) v_u_54, (copy) v_u_65, (copy) v_u_64
		local v67 = 1 - (1 - p66) ^ 3
		v_u_54(v_u_65, v_u_64 * CFrame.Angles(0, -v67 * 2.6, 0), 0.25 + 0.75 * v67)
		local v68 = v_u_65
		local v69 = 0.1 + 0.9 * p66 * p66
		for _, v70 in v68.parts do
			v70.Transparency = v69
		end
		if p66 >= 1 then
			for _, v71 in v_u_65.parts do
				v71:Destroy()
			end
		end
	end)
end
local function v_u_88(p73, p74, p75, p76, p77) -- name: closingRing
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_1
	local v78 = v_u_5.part
	local v79 = p75 * 2
	local v80 = p75 * 2
	local v81 = v78(Vector3.new(v79, 0.05, v80), CFrame.new(p73), p74, {
		["transparency"] = 1
	})
	for _, v82 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v83 = Instance.new("Decal")
		v83.Face = v82
		v83.Texture = v_u_7.Ring
		v83.Color3 = p74
		v83.Transparency = 0.1
		v83.Parent = v81
		v_u_5.tween(v83, p77, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	local v84 = v_u_5.tween
	local v85 = {}
	local v86 = p76 * 2
	local v87 = p76 * 2
	v85.Size = Vector3.new(v86, 0.05, v87)
	v84(v81, p77, v85, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	v_u_1:AddItem(v81, p77 + 0.05)
end
local function v_u_127(p89, p_u_90, p_u_91, p92, p93, p_u_94) -- name: spiralIn
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	if p92 <= 0 then
		return function() end
	end
	local v_u_95 = {}
	for v96 = 1, p92 do
		local v97 = v_u_5.part(Vector3.new(0.3, 0.3, 2), CFrame.new(p_u_90), p93, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v97, p_u_94 + 1)
		local v98 = {
			["p"] = v97,
			["phase"] = v96 / p92,
			["a"] = v96 / p92 * 3.141592653589793 * 2
		}
		table.insert(v_u_95, v98)
	end
	local v_u_99 = os.clock()
	local v_u_100 = false
	p89.runNow(function()
		-- upvalues: (copy) v_u_99, (ref) v_u_100, (copy) p_u_94, (copy) v_u_95, (copy) p_u_91, (copy) p_u_90
		local v101 = os.clock() - v_u_99
		if v_u_100 or p_u_94 < v101 then
			for _, v102 in v_u_95 do
				v102.p:Destroy()
			end
			return false
		else
			for _, v103 in v_u_95 do
				local v104 = (v101 * 1.5 + v103.phase) % 1
				local v105 = p_u_91 * (1 - v104) + 0.6
				local v106 = v103.a + v104 * 3.4 + v101 * 0.6
				local v107 = p_u_90
				local v108 = math.cos(v106) * v105
				local v109 = (1 - v104) * 1.4 + 0.5
				local v110 = math.sin(v106) * v105
				local v111 = v107 + Vector3.new(v108, v109, v110)
				local v112 = v104 + 0.07
				local v113 = math.min(v112, 1)
				local v114 = p_u_91 * (1 - v113) + 0.6
				local v115 = v103.a + v113 * 3.4 + v101 * 0.6
				local v116 = p_u_90
				local v117 = math.cos(v115) * v114
				local v118 = (1 - v113) * 1.4 + 0.5
				local v119 = math.sin(v115) * v114
				local v120 = v116 + Vector3.new(v117, v118, v119)
				local v121 = v103.p
				local v122 = (v120 - v111).Magnitude * 1.5
				local v123 = math.max(v122, 0.4)
				v121.Size = Vector3.new(0.3, 0.3, v123)
				v103.p.CFrame = CFrame.lookAt(v111, v120)
				local v124 = v103.p
				local v125 = 1 - v104 / 0.12
				local v126 = (v104 - 0.75) / 0.25
				v124.Transparency = math.max(v125, v126, 0) * 0.8 + 0.2
			end
			return true
		end
	end)
	return function()
		-- upvalues: (ref) v_u_100
		v_u_100 = true
	end
end
local function v_u_172(p128, p129, p130, p131, p_u_132) -- name: shatter
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_5, (copy) v_u_1
	local v_u_133 = {}
	for v134 = 1, p131 do
		local v135 = (v134 + math.random() * 0.8) / p131 * 3.141592653589793 * 2
		local v136 = 6 + math.random() * 74
		local v137 = math.rad(v136)
		local v138 = math.cos(v135) * math.cos(v137)
		local v139 = math.sin(v137)
		local v140 = math.sin(v135) * math.cos(v137)
		local v141 = Vector3.new(v138, v139, v140)
		local v142 = v141:Cross(Vector3.new(0, 1, 0)).Unit
		local v143 = v141:Cross(v142).Unit
		local v144 = math.random() * 3.141592653589793 * 2
		local v145 = v142 * math.cos(v144) + v143 * math.sin(v144)
		local v146 = p129 + v141 * p130 * 0.97
		local v147 = p130 * (0.13 + math.random() * 0.14)
		local v148 = v134 % 3 ~= 0
		local v149 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v141, v145)
		local v150 = v147 * (0.6 + math.random() * 0.8)
		local v151 = Vector3.new(0.14, v147, v150)
		local v152 = CFrame.new(v146) * v149
		local v153
		if v148 then
			v153 = v_u_9
		else
			v153 = v_u_8
		end
		local v154
		if v148 then
			v154 = Enum.Material.Glass
		else
			v154 = Enum.Material.Neon
		end
		local v155 = Instance.new("WedgePart")
		v155.Anchored = true
		v155.CanCollide = false
		v155.CanQuery = false
		v155.CanTouch = false
		v155.CastShadow = false
		v155.Size = v151
		v155.CFrame = v152
		v155.Color = v153
		v155.Material = v154
		v155.Transparency = v148 and 0.25 or 0
		v155.Parent = v_u_5.folder()
		if v148 then
			v155.Reflectance = 0.35
		end
		v_u_1:AddItem(v155, p_u_132 + 0.2)
		local v156 = {
			["p"] = v155,
			["pos"] = v146,
			["v"] = v141 * (20 + math.random() * 26) + Vector3.new(0, 10, 0),
			["rot"] = v149,
			["spin"] = CFrame.Angles((math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4)
		}
		table.insert(v_u_133, v156)
	end
	local v_u_157 = os.clock()
	local v_u_158 = v_u_157
	p128.frame(function()
		-- upvalues: (ref) v_u_158, (copy) v_u_157, (copy) p_u_132, (copy) v_u_133
		local v159 = os.clock()
		local v160 = v159 - v_u_158
		local v161 = math.min(v160, 0.05)
		v_u_158 = v159
		local v162 = v159 - v_u_157
		local v163 = (v162 - p_u_132 * 0.55) / (p_u_132 * 0.45)
		local v164 = math.clamp(v163, 0, 1)
		for v165, v166 in v_u_133 do
			local v167 = v166.v
			local v168 = v161 * 75
			v166.v = v167 - Vector3.new(0, v168, 0)
			v166.pos = v166.pos + v166.v * v161
			v166.rot = v166.spin * v166.rot
			v166.p.CFrame = CFrame.new(v166.pos) * v166.rot
			local v169 = v166.p
			local v170 = v165 % 3 == 0 and 0 or 0.25
			v169.Transparency = math.max(v164, v170)
		end
		if p_u_132 > v162 then
			return true
		end
		for _, v171 in v_u_133 do
			v171.p:Destroy()
		end
		return false
	end)
end
local v_u_173 = 0
local function v_u_176(p174) -- name: ghostScreen
	-- upvalues: (ref) v_u_173, (copy) v_u_2, (copy) v_u_5, (copy) v_u_1
	if os.clock() >= v_u_173 then
		local v_u_175 = Instance.new("ColorCorrectionEffect")
		v_u_175.Name = "WorldFlip"
		v_u_175.Parent = v_u_2
		v_u_5.tween(v_u_175, 0.08, {
			["Saturation"] = -0.8,
			["Contrast"] = 0.35,
			["Brightness"] = -0.04,
			["TintColor"] = nil,
			["TintColor"] = Color3.fromRGB(206, 182, 255)
		})
		task.delay(p174, function()
			-- upvalues: (copy) v_u_175, (ref) v_u_5
			v_u_175.Brightness = 0.35
			v_u_175.Saturation = 0.2
			v_u_175.TintColor = Color3.fromRGB(240, 230, 255)
			v_u_5.tween(v_u_175, 0.45, {
				["Saturation"] = 0,
				["Contrast"] = 0,
				["Brightness"] = 0,
				["TintColor"] = nil,
				["TintColor"] = Color3.new(1, 1, 1)
			})
		end)
		v_u_1:AddItem(v_u_175, p174 + 0.6)
		v_u_173 = os.clock() + p174 + 0.6
	end
end
return function(p_u_177)
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_1, (copy) v_u_9, (copy) v_u_46, (copy) v_u_34, (copy) v_u_54, (copy) v_u_12, (copy) v_u_72, (copy) v_u_4, (copy) v_u_7, (copy) v_u_11, (copy) v_u_10, (copy) v_u_127, (copy) v_u_88, (copy) v_u_6, (copy) v_u_176, (copy) v_u_172
	local v276 = {
		["phantom_pinwheel_a"] = {
			["cast"] = function(p178) -- name: cast
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_72, (ref) v_u_9
				p_u_177.muzzle(p178, v_u_8, 0.9)
				if not p178.lite then
					v_u_72(p_u_177, p178.eye + p178.dir * 1.4, v_u_9, 1.7, 0.13)
				end
			end,
			["shot"] = function(p179, p180) -- name: shurikenShot
				-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (copy) p_u_177, (ref) v_u_9, (ref) v_u_46, (ref) v_u_34, (ref) v_u_54, (ref) v_u_12
				local v_u_181 = p179.size
				local v182 = p179.lite
				local v_u_183 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p180, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_183, 6)
				p_u_177.streak(v_u_183, v_u_8, v_u_9, 1.1 * v_u_181, 0.12)
				local v_u_184 = v_u_46(v_u_34(1.6 * v_u_181, v182 and 1 or 2, 0.95, 0.8 * v_u_181), p180, v_u_8, v_u_9, 0, 6)
				local v_u_185 = v_u_5.part(Vector3.new(0.75, 0.75, 0.75) * v_u_181, p180, v_u_9, {
					["shape"] = Enum.PartType.Ball
				})
				v_u_1:AddItem(v_u_185, 6)
				local v_u_186
				if v182 then
					v_u_186 = nil
				else
					v_u_186 = v_u_46(v_u_34(1.7 * v_u_181, 1, 0.95, 0.75 * v_u_181), p180, v_u_9, v_u_9, 0.62, 6)
					p_u_177.streak(v_u_184.parts[2], v_u_9, v_u_8, 0.35 * v_u_181, 0.16)
					p_u_177.streak(v_u_184.parts[6], v_u_9, v_u_8, 0.35 * v_u_181, 0.16)
				end
				if p179.mine then
					p_u_177.light(v_u_183, v_u_8, 9 * v_u_181)
				end
				local v_u_187 = false
				return {
					["place"] = function(p188, p189) -- name: place
						-- upvalues: (copy) v_u_183, (copy) v_u_185, (ref) v_u_54, (copy) v_u_184, (ref) v_u_12, (ref) v_u_186, (copy) v_u_181
						v_u_183.CFrame = p188
						v_u_185.CFrame = p188
						v_u_54(v_u_184, p188 * v_u_12 * CFrame.Angles(0, -p189 * 24, 0), 1)
						if v_u_186 then
							v_u_54(v_u_186, p188 * CFrame.new(0, 0, 1.9 * v_u_181) * v_u_12 * CFrame.Angles(0, -p189 * 24 + 0.7, 0), 1)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_187, (copy) v_u_183, (ref) v_u_1, (copy) v_u_185, (copy) v_u_184, (ref) v_u_186
						if not v_u_187 then
							v_u_187 = true
							local v190 = v_u_183:FindFirstChildWhichIsA("PointLight")
							if v190 then
								v190:Destroy()
							end
							v_u_1:AddItem(v_u_183, 0.15)
							v_u_185:Destroy()
							for _, v191 in v_u_184.parts do
								if v191:FindFirstChildWhichIsA("Trail") then
									v191.Transparency = 1
									v_u_1:AddItem(v191, 0.18)
								else
									v191:Destroy()
								end
							end
							if v_u_186 then
								for _, v192 in v_u_186.parts do
									v192:Destroy()
								end
							end
						end
					end
				}
			end,
			["impact"] = function(p193, p194) -- name: impact
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_72, (ref) v_u_9, (ref) v_u_4, (ref) v_u_7, (ref) v_u_5
				local v195 = p193.size
				p_u_177.burst("Impact", p194, v_u_8, 0.9 * v195)
				v_u_72(p_u_177, p194, v_u_9, 4.4 * v195, 0.22)
				p_u_177.pop(p194, v_u_8, 1.2 * v195, 5 * v195, 0.16, 0.25)
				if not p193.lite then
					local v196 = p_u_177.sigil
					local v197 = p_u_177.facing
					local v198 = v_u_4.CurrentCamera
					local v199
					if v198 then
						local v200 = v198.CFrame.Position - p194
						v199 = v200.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v200.Unit
					else
						v199 = Vector3.new(0, 1, 0)
					end
					v196(v197(p194, v199), 2.2 * v195, v_u_8, v_u_7.Swirl, 0.08, 16)
				end
				v_u_5.ring(p_u_177.ground(p194), v_u_8, 4 * v195, 0.25, v_u_7.Ring)
				p_u_177.hitSound(p194)
			end,
			["hit"] = function(_, p201, _) -- name: hit
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_9
				p_u_177.burst("Impact", p201, v_u_8, 0.6)
				p_u_177.glint(p201, v_u_9, 3, 0.12)
			end
		},
		["phantom_pinwheel_e"] = {
			["loopSound"] = "Vortex",
			["castSound"] = "Burst",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p202) -- name: cast
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_46, (ref) v_u_34, (ref) v_u_9, (ref) v_u_54
				p_u_177.skillCast(p202, v_u_8)
				local v203 = p202.eye + p202.dir * 1.8
				local v_u_204 = p_u_177.facing(v203, p202.dir)
				local v_u_205 = v_u_46(v_u_34(1.7, 1, 1.2, 0.55), v_u_204, v_u_8, v_u_9, 0, 1)
				p_u_177.animate(0.32, 0, function(p206)
					-- upvalues: (ref) v_u_54, (copy) v_u_205, (copy) v_u_204
					local v207 = v_u_54
					local v208 = v_u_205
					local v209 = v_u_204 * CFrame.Angles(0, -p206 * 10, 0)
					local v210 = p206 * 3.141592653589793
					v207(v208, v209, math.sin(v210) * 0.9 + 0.3)
					local v211 = v_u_205
					local v212 = p206 * p206
					for _, v213 in v211.parts do
						v213.Transparency = v212
					end
					if p206 >= 1 then
						for _, v214 in v_u_205.parts do
							v214:Destroy()
						end
					end
				end)
			end,
			["windup"] = function(p215, p216, p217) -- name: windup
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9
				local v218 = p215.ability.radius
				p_u_177.sigil(CFrame.new(p_u_177.ground(p216, 0.12)), v218 * 0.6, v_u_8, v_u_7.MagicCircle, p217 + 0.1, 7)
				p_u_177.pop(p_u_177.ground(p216, 1), v_u_11, 0.6, 3.5, p217 + 0.1, 0.2)
				if not p215.lite then
					p_u_177.inward(p_u_177.ground(p216, 1), v_u_9, 5, v218, (math.max(p217, 0.12)))
				end
			end,
			["zone"] = function(p219, p_u_220, p_u_221) -- name: zone
				-- upvalues: (copy) p_u_177, (ref) v_u_10, (ref) v_u_5, (ref) v_u_1, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_46, (ref) v_u_34, (ref) v_u_127, (ref) v_u_88, (ref) v_u_54, (ref) v_u_11
				local v_u_222 = p219.ability.radius
				local v223 = p219.lite
				local v_u_224 = p219.ability.tick or 0.4
				local v_u_225 = p_u_177.ground(p_u_220, 0)
				local v_u_226 = p_u_177.plate(p_u_177.ground(p_u_220, 0.08), 0.5, v_u_10, 0, Enum.Material.SmoothPlastic)
				local v227 = v_u_5.tween
				local v228 = {}
				local v229 = v_u_222 * 0.95
				local v230 = v_u_222 * 0.95
				v228.Size = Vector3.new(0.12, v229, v230)
				v227(v_u_226, 0.22, v228, Enum.EasingStyle.Back)
				v_u_1:AddItem(v_u_226, p_u_221 + 1)
				p_u_177.sigil(CFrame.new(p_u_177.ground(p_u_220, 0.14)), v_u_222 * 0.5, v_u_8, v_u_7.Swirl, p_u_221, -9)
				p_u_177.sigil(CFrame.new(p_u_177.ground(p_u_220, 0.18)), v_u_222 * 1.05, v_u_9, v_u_7.Ring, p_u_221, 1.2)
				local v_u_231 = v_u_46(v_u_34(v_u_222 * 0.95, v223 and 2 or 3, 1.15, v_u_222 * 0.17), CFrame.new(v_u_225), v_u_8, v_u_9, 0, p_u_221 + 1.5)
				local v_u_232
				if v223 then
					v_u_232 = nil
				else
					v_u_232 = v_u_46(v_u_34(v_u_222 * 1.1, 2, 1.15, v_u_222 * 0.14), CFrame.new(v_u_225), v_u_9, v_u_9, 0.65, p_u_221 + 1.5)
				end
				local v_u_233 = v_u_127(p_u_177, v_u_225, v_u_222 * 1.3, v223 and 0 or 9, v_u_9, p_u_221 + 0.5)
				local v_u_234 = {}
				if not v223 then
					local v235 = p_u_177.loopAt
					local v236 = p_u_177.ground(p_u_220, 2.5)
					local v237 = v_u_9
					table.insert(v_u_234, v235("Charge", v236, v237, 1.5))
				end
				p_u_177.burst("Flash", p_u_177.ground(p_u_220, 2), v_u_8, 0.5)
				v_u_5.ring(v_u_225, v_u_9, v_u_222, 0.3, v_u_7.Ring)
				local v_u_238 = os.clock()
				local v_u_239 = v_u_238
				local v_u_240 = nil
				local v_u_241 = 0
				local v_u_242 = 0
				local v_u_243 = -1
				p_u_177.runNow(function()
					-- upvalues: (ref) v_u_239, (copy) v_u_238, (ref) v_u_240, (ref) v_u_241, (ref) v_u_242, (copy) v_u_224, (ref) v_u_243, (ref) v_u_88, (ref) p_u_177, (copy) p_u_220, (ref) v_u_9, (copy) v_u_222, (ref) v_u_54, (copy) v_u_231, (copy) v_u_225, (ref) v_u_11, (copy) v_u_232, (copy) p_u_221
					local v244 = os.clock()
					local v245 = v244 - v_u_239
					local v246 = math.min(v245, 0.05)
					v_u_239 = v244
					local v247 = v244 - v_u_238
					local v248 = v247 / 0.2
					local v249 = 1 - (1 - math.clamp(v248, 0, 1)) ^ 3
					local v250
					if v_u_240 then
						local v251 = (v244 - v_u_240) / 0.12
						v250 = math.clamp(v251, 0, 1)
					else
						v250 = 0
					end
					local v252 = v249 * (1 - v250 * v250)
					v_u_241 = v_u_241 + v246 * (v250 * 30 + 2.8)
					if not v_u_240 and v_u_242 <= v247 then
						v_u_242 = v_u_242 + v_u_224
						v_u_243 = v244
						v_u_88(p_u_177.ground(p_u_220, 0.3), v_u_9, v_u_222 * 1.15, 1, 0.3)
					end
					local v253 = 1 - (v244 - v_u_243) / 0.2
					local v254 = math.max(v253, 0)
					local v255 = v_u_54
					local v256 = v_u_231
					local v257 = CFrame.new
					local v258 = v_u_225
					local v259 = v247 * 5
					local v260 = math.sin(v259) * 0.15 + 0.45
					v255(v256, v257(v258 + Vector3.new(0, v260, 0)) * CFrame.Angles(0, -v_u_241, 0), v252 * (v254 * 0.07 + 1))
					for v261, v262 in v_u_231.parts do
						v262.Color = v_u_231.colors[v261]:Lerp(v_u_11, v254 * 0.55)
					end
					if v_u_232 then
						v_u_54(v_u_232, CFrame.new(v_u_225 + Vector3.new(0, 1.4, 0)) * CFrame.Angles(0, -v_u_241 * 0.8 + 0.5, 0), v252)
						local v263 = v_u_232
						local v264 = v247 * 9
						local v265 = (math.sin(v264) * 0.5 + 0.5) * 0.45 + 0.5
						for _, v266 in v263.parts do
							v266.Transparency = v265
						end
					end
					if v250 < 1 and p_u_221 + 1 >= v247 then
						return true
					end
					for _, v267 in v_u_231.parts do
						v267:Destroy()
					end
					if v_u_232 then
						for _, v268 in v_u_232.parts do
							v268:Destroy()
						end
					end
					return false
				end)
				return function()
					-- upvalues: (ref) v_u_240, (copy) v_u_233, (copy) v_u_234, (ref) v_u_5, (copy) v_u_226, (ref) v_u_1
					v_u_240 = os.clock()
					v_u_233()
					for _, v269 in v_u_234 do
						v269()
					end
					v_u_5.tween(v_u_226, 0.12, {
						["Size"] = Vector3.new(0.12, 0.2, 0.2)
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v_u_226, 0.13)
				end
			end,
			["finish"] = function(p270, p271) -- name: finish
				-- upvalues: (copy) p_u_177, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_72, (ref) v_u_6
				local v272 = p270.ability.radius
				local v273 = p_u_177.ground(p271)
				local v274 = p_u_177.ground(p271, 2.5)
				p_u_177.pop(v274, v_u_11, 2, v272 * 1.1, 0.25, 0.1)
				p_u_177.burst("Explosion", v274, v_u_8, v272 / 7)
				p_u_177.burst("Shockwave", v273 + Vector3.new(0, 0.3, 0), v_u_8, v272 / 18)
				v_u_5.ring(v273, v_u_8, v272 * 1.3, 0.45)
				v_u_5.ring(v273, v_u_9, v272 * 1.1, 0.35, v_u_7.SpeedLines)
				v_u_72(p_u_177, v274, v_u_9, v272 * 0.9, 0.3)
				p_u_177.spikes(v274, v_u_9, p270.lite and 4 or 9, v272, 0.3, Vector3.new(0, 1, 0), 0.8)
				v_u_6.play("Explosion", {
					["at"] = v274
				})
				if p270.mine then
					v_u_5.shake(0.4, 0.35)
				end
			end,
			["hit"] = function(_, p275, _) -- name: hit
				-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_9
				p_u_177.burst("Impact", p275, v_u_8, 0.65)
				p_u_177.pop(p275, v_u_9, 0.8, 2.6, 0.14, 0.3)
			end
		}
	}
	local v_u_277 = {}
	v276.phantom_pinwheel_r = {
		["cast"] = function(p278) -- name: cast
			-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_9, (ref) v_u_72
			p_u_177.skillCast(p278, v_u_8, true)
			p_u_177.burst("Flash", p278.eye, v_u_9, 0.45)
			v_u_72(p_u_177, p278.eye + p278.dir * 1.5, v_u_9, 3, 0.25)
		end,
		["windup"] = function(p_u_279, p_u_280, p_u_281) -- name: windup
			-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10, (ref) v_u_1, (ref) v_u_9, (ref) v_u_7, (ref) v_u_46, (ref) v_u_34, (ref) v_u_11, (ref) v_u_4, (ref) v_u_54, (ref) v_u_176, (copy) v_u_277
			local v282 = p_u_279.ability.radius
			local v283 = p_u_279.lite
			local v284 = p_u_177.ground(p_u_280, 0)
			local v285 = p_u_281 * 0.8
			local v_u_286 = math.clamp(v285, 0.05, 0.2)
			local v287 = p_u_281 + 1
			local v288 = p_u_177.ball(v284, v_u_8, v282 * 0.4, 0, Enum.Material.ForceField)
			v_u_5.tween(v288, v_u_286, {
				["Size"] = Vector3.new(1, 1, 1) * v282 * 2.05
			}, Enum.EasingStyle.Back)
			local v289 = p_u_177.ball(v284, v_u_10, v282 * 0.4, 0.45, Enum.Material.SmoothPlastic)
			v_u_5.tween(v289, v_u_286, {
				["Size"] = Vector3.new(1, 1, 1) * v282 * 2
			}, Enum.EasingStyle.Back)
			v_u_1:AddItem(v288, v287)
			v_u_1:AddItem(v289, v287)
			local v290 = p_u_177.plate(p_u_177.ground(p_u_280, 0.07), 0.5, v_u_10, 0.2, Enum.Material.SmoothPlastic)
			local v291 = v_u_5.tween
			local v292 = {}
			local v293 = v282 * 2
			local v294 = v282 * 2
			v292.Size = Vector3.new(0.12, v293, v294)
			v291(v290, v_u_286, v292)
			v_u_1:AddItem(v290, v287 + 1)
			p_u_177.sigil(CFrame.new(p_u_177.ground(p_u_280, 0.14)), v282, v_u_9, v_u_7.MagicCircle, p_u_281 + 0.05, 2)
			p_u_177.sigil(CFrame.new(p_u_177.ground(p_u_280, 0.16)), v282 * 1.08, v_u_8, v_u_7.Ring, p_u_281 + 0.05, -1)
			local v_u_295 = v_u_46(v_u_34(v282 * 0.8, v283 and 2 or 3, 1.2, v282 * 0.13), CFrame.new(v284), v_u_9, v_u_11, 0.1, v287)
			local v_u_296 = p_u_177.ground(p_u_280, v282 * 0.9)
			local v_u_297
			if v283 then
				v_u_297 = nil
			else
				v_u_297 = v_u_46(v_u_34(v282 * 0.6, 2, 1.2, v282 * 0.11), CFrame.new(v_u_296), v_u_8, v_u_9, 0.3, v287)
			end
			local v298 = v_u_296 + Vector3.new(0, 6, 0)
			local v299 = v_u_4.CurrentCamera
			local v300
			if v299 then
				local v301 = v299.CFrame.Position - v298
				v300 = v301.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v301.Unit
			else
				v300 = Vector3.new(0, 1, 0)
			end
			p_u_177.sigil(p_u_177.facing(v298, v300), 5, v_u_11, p_u_177.iris("phantom_pinwheel"), p_u_281 + 0.05, 1.5)
			p_u_177.sigil(p_u_177.facing(v298 - v300 * 0.3, v300), 7.5, v_u_8, v_u_7.Ring, p_u_281 + 0.05, -2)
			p_u_177.burst("Flash", v298, v_u_9, 0.5)
			local v_u_302 = os.clock()
			p_u_177.runNow(function()
				-- upvalues: (copy) v_u_302, (copy) v_u_286, (ref) v_u_54, (copy) v_u_295, (ref) p_u_177, (copy) p_u_280, (copy) v_u_297, (copy) v_u_296, (copy) p_u_281
				local v303 = os.clock() - v_u_302
				local v304 = v303 / v_u_286
				local v305 = 1 - (1 - math.clamp(v304, 0, 1)) ^ 3
				v_u_54(v_u_295, CFrame.new(p_u_177.ground(p_u_280, 0.25)) * CFrame.Angles(0, -v303 * 3, 0), v305)
				if v_u_297 then
					v_u_54(v_u_297, CFrame.new(v_u_296) * CFrame.Angles(3.141592653589793, 0, 0) * CFrame.Angles(0, -v303 * 3, 0), v305)
				end
				if p_u_281 > v303 then
					return true
				end
				for _, v306 in v_u_295.parts do
					v306:Destroy()
				end
				if v_u_297 then
					for _, v307 in v_u_297.parts do
						v307:Destroy()
					end
				end
				return false
			end)
			if not v283 then
				p_u_177.inward(p_u_177.ground(p_u_280, v282 * 0.45), v_u_9, 8, v282 * 1.2, (math.max(p_u_281, 0.12)))
			end
			if p_u_279.mine then
				v_u_176(p_u_281)
			end
			v_u_277[p_u_279] = {
				["dome"] = v288,
				["dark"] = v289,
				["floor"] = v290
			}
			task.delay(v287 + 0.5, function()
				-- upvalues: (ref) v_u_277, (copy) p_u_279
				v_u_277[p_u_279] = nil
			end)
		end,
		["land"] = function(p308, p309) -- name: land
			-- upvalues: (copy) p_u_177, (copy) v_u_277, (ref) v_u_172, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_5, (ref) v_u_72, (ref) v_u_6
			local v310 = p308.ability.radius
			local v311 = p308.lite
			local v312 = p_u_177.ground(p309)
			local v313 = v_u_277[p308]
			v_u_277[p308] = nil
			if v313 then
				v313.dome:Destroy()
				v313.dark:Destroy()
				p_u_177.fadeOut(v313.floor, 0.5)
			end
			v_u_172(p_u_177, v312, v310, v311 and 9 or 22, 1.2)
			p_u_177.mark(p309, v_u_9, v310 * 0.95, 1.4, v_u_7.CrackLines, 0)
			p_u_177.mark(p309, v_u_8, v310 * 0.7, 1, v_u_7.CrackGlow, 0.1)
			p_u_177.pop(p_u_177.ground(p309, v310 * 0.35), v_u_11, v310 * 1.6, v310 * 2.3, 0.22, 0.4)
			p_u_177.burst("Flash", p_u_177.ground(p309, 6), v_u_9, 1)
			p_u_177.burst("Explosion", p_u_177.ground(p309, 2), v_u_8, v310 / 9)
			local v314 = p_u_177.burst
			local v315 = v312 + Vector3.new(0, 0.3, 0)
			local v316 = v_u_8
			local v317 = v310 / 14
			v314("Shockwave", v315, v316, (math.min(v317, 1.6)))
			v_u_5.ring(v312, v_u_8, v310 * 1.25, 0.5)
			v_u_5.ring(v312, v_u_9, v310 * 1.45, 0.45, v_u_7.SpeedLines)
			v_u_72(p_u_177, p_u_177.ground(p309, 5), v_u_9, v310 * 1.1, 0.35)
			p_u_177.glint(p_u_177.ground(p309, 6), v_u_11, 22, 0.3)
			v_u_6.play("Explosion", {
				["at"] = v312
			})
			v_u_6.play("Crit", {
				["at"] = v312,
				["volume"] = p308.mine and 0.8 or 0.5
			})
			if p308.mine then
				v_u_5.shake(0.6, 0.5)
			end
		end,
		["hit"] = function(_, p318, _) -- name: hit
			-- upvalues: (copy) p_u_177, (ref) v_u_8, (ref) v_u_72, (ref) v_u_9
			p_u_177.burst("Impact", p318, v_u_8, 1.1)
			v_u_72(p_u_177, p318, v_u_9, 3.5, 0.2)
		end
	}
	return v276
end