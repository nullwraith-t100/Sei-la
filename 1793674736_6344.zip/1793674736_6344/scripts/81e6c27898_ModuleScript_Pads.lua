local v_u_20 = {
	["at"] = function(p1, p2) -- name: at
		for v3, v4 in p2.pads do
			if p2.count >= v3 then
				local v5 = p1.X - v4.X
				if math.abs(v5) > p2.half then
					continue
				end
				local v6 = p1.Z - v4.Z
				if math.abs(v6) > p2.half then
					continue
				end
				local v7 = p1.Y - v4.Y
				if math.abs(v7) >= p2.height then
					continue
				end
				return v3
			end
		end
		return 0
	end,
	["stepped"] = function(p8, p9, p10, p11, p12) -- name: stepped
		-- upvalues: (copy) v_u_20
		if not p8 or (p9 - p8).Magnitude > p12 then
			local v13 = v_u_20.at(p9, p10)
			return v13 == p11 and 0 or v13
		end
		local v14 = p9 - p8
		local v15 = v14.Magnitude
		local v16 = math.ceil(v15)
		local v17 = math.max(1, v16)
		for v18 = 1, v17 do
			local v19 = v_u_20.at(p8 + v14 * (v18 / v17), p10)
			if v19 <= 0 or v19 == p11 then
				continue
			end
			return v19
		end
		return 0
	end
}
return v_u_20