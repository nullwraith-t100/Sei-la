local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Workspace")
require(script.Parent.EnemyModels)
local v_u_6 = require(script.Parent.EnemyRigs)
local v_u_7 = require(script.Parent.Events)
local v_u_8 = require(script.Parent.Numbers)
local v_u_9 = require(script.Parent.Sfx)
local v_u_10 = require(script.Parent.Fx.Kit)
local v_u_11 = require(script.Parent.Perf)
local v_u_12 = require(script.Parent.Fx.Abilities)
local v_u_13 = require(v3.Shared.Net)
local v_u_14 = require(v3.Shared.Config.Enemies)
local v_u_15 = require(v3.Shared.Logic.EnemyFit)
local v_u_16 = require(v3.Shared.Config.Textures)
local v_u_17 = require(v3.Shared.Config.World)
local v_u_18 = {}
local v_u_19 = {}
local v_u_20 = nil
local v_u_21 = v2.LocalPlayer
local v_u_22 = {}
function v_u_18.on(p23, p24) -- name: on
	-- upvalues: (copy) v_u_22
	local v25 = v_u_22[p23]
	if not v25 then
		v25 = {}
		v_u_22[p23] = v25
	end
	table.insert(v25, p24)
end
function v_u_18.count() -- name: count
	-- upvalues: (copy) v_u_19
	local v26 = 0
	for _ in v_u_19 do
		v26 = v26 + 1
	end
	return v26
end
local v_u_27 = {}
function v_u_18.addTarget(p28) -- name: addTarget
	-- upvalues: (copy) v_u_27
	local v29 = v_u_27
	table.insert(v29, p28)
end
function v_u_18.list() -- name: list
	-- upvalues: (copy) v_u_19, (copy) v_u_27
	local v30 = {}
	for v31, v32 in v_u_19 do
		local v33 = {
			["id"] = v31
		}
		local v34 = v32.x
		local v35 = v32.body.lift
		local v36 = v32.z
		v33.pos = Vector3.new(v34, v35, v36)
		v33.boss = v32.boss
		table.insert(v30, v33)
	end
	for _, v37 in v_u_27 do
		local v38 = v37()
		if not v38 then
			continue
		end
		table.insert(v30, v38)
	end
	return v30
end
function v_u_18.position(p39) -- name: position
	-- upvalues: (copy) v_u_19, (copy) v_u_27
	local v40 = v_u_19[p39]
	if not v40 then
		for _, v41 in v_u_27 do
			local v42 = v41()
			if not v42 or v42.id ~= p39 then
				continue
			end
			return v42.pos
		end
	end
	if not v40 then
		return nil
	end
	local v43 = v40.x
	local v44 = v40.body.lift
	local v45 = v40.z
	return Vector3.new(v43, v44, v45)
end
local function v_u_61(p46, p47, p48, p49, p50) -- name: pillar
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	local v51 = v_u_10.part
	local v52 = Vector3.new(p49, p48, p48)
	local v53 = CFrame.new
	local v54 = p49 / 2
	local v55 = v51(v52, v53(p46 + Vector3.new(0, v54, 0)) * CFrame.Angles(0, 0, 1.5707963267948966), p47, {
		["shape"] = nil,
		["transparency"] = 0.15,
		["shape"] = Enum.PartType.Cylinder
	})
	local v56 = v_u_10.tween
	local v57 = {
		["Size"] = nil,
		["Transparency"] = 1
	}
	local v58 = p49 * 1.15
	local v59 = p48 * 0.35
	local v60 = p48 * 0.35
	v57.Size = Vector3.new(v58, v59, v60)
	v56(v55, p50, v57)
	v_u_1:AddItem(v55, p50 + 0.05)
end
local function v_u_69(p62, p63, p64, p65, p66) -- name: starburst
	-- upvalues: (copy) v_u_5, (copy) v_u_16, (copy) v_u_1
	local v67 = Instance.new("Attachment")
	v67.WorldPosition = p62
	v67.Parent = v_u_5.Terrain
	local v68 = Instance.new("ParticleEmitter")
	v68.Texture = v_u_16.ImpactBurst
	v68.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v68.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v68.Color = ColorSequence.new(Color3.new(1, 1, 1), p63)
	v68.LightEmission = 0.8
	v68.LightInfluence = 0
	v68.ZOffset = p66
	v68.Lifetime = NumberRange.new(0.35, 0.45)
	v68.Speed = NumberRange.new(0)
	v68.Rotation = NumberRange.new(0, 360)
	v68.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p64 * 0.35), NumberSequenceKeypoint.new(1, p64 * 0.6) })
	v68.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v68.Enabled = false
	v68.Parent = v67
	v68:Emit(p65)
	v_u_1:AddItem(v67, 0.6)
end
local function v_u_77(p70, p71, p72, p73, p74) -- name: floorMark
	-- upvalues: (copy) v_u_10, (copy) v_u_1
	local v75 = v_u_10.part(Vector3.new(p72, 0.1, p72), CFrame.new(p70 + Vector3.new(0, 0.08, 0)) * CFrame.Angles(0, math.random() * 3.141592653589793 * 2, 0), p71, {
		["transparency"] = 1
	})
	local v76 = Instance.new("Decal")
	v76.Face = Enum.NormalId.Top
	v76.Texture = p73
	v76.Color3 = p71
	v76.Transparency = 0
	v76.Parent = v75
	v_u_10.tween(v76, p74, {
		["Transparency"] = 1
	}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	v_u_1:AddItem(v75, p74 + 0.05)
end
local function v_u_102(p78, p79, p80, p81, p82) -- name: spawnView
	-- upvalues: (copy) v_u_14, (copy) v_u_19, (copy) v_u_6, (copy) v_u_15, (copy) v_u_17, (ref) v_u_20, (copy) v_u_10, (copy) v_u_16, (copy) v_u_61, (copy) v_u_9, (copy) v_u_22
	local v83 = v_u_14.byId[p79]
	if v83 and not v_u_19[p78] then
		local v84, v85 = v_u_6.build(v83, p78)
		local v86 = {
			["id"] = nil,
			["def"] = nil,
			["body"] = nil,
			["rig15"] = nil,
			["reach"] = nil,
			["x"] = nil,
			["z"] = nil,
			["goalX"] = nil,
			["goalZ"] = nil,
			["yaw"] = 3.141592653589793,
			["phase"] = nil,
			["speed"] = 0,
			["hpShare"] = 1,
			["frozen"] = false,
			["windupAt"] = nil,
			["strikeAt"] = 0,
			["spawnedAt"] = nil,
			["flashUntil"] = 0,
			["hitAt"] = 0,
			["bitsAt"] = 0,
			["telegraph"] = nil,
			["boss"] = nil,
			["leapAt"] = nil,
			["id"] = p78,
			["def"] = v83,
			["body"] = v84,
			["rig15"] = v85,
			["reach"] = v_u_15.reach(v83, v85 ~= nil),
			["x"] = p80,
			["z"] = p81,
			["goalX"] = p80,
			["goalZ"] = p81,
			["phase"] = math.random() * 6,
			["spawnedAt"] = os.clock(),
			["boss"] = p82
		}
		v84.root.CFrame = CFrame.new(p80, v_u_17.FLOOR_Y + v84.lift - 6 * v84.scale, p81)
		v84.model.Parent = v_u_20
		local v87 = v84.ground
		if v87 and not v87.Parent then
			v87.Parent = v_u_20
		end
		v_u_19[p78] = v86
		local v88 = v84.scale
		local v89 = v84.glow
		local v90 = v_u_17.FLOOR_Y + 0.05
		local v91 = Vector3.new(p80, v90, p81)
		v_u_10.disc(v91, v89, (p82 and 3.2 or 2.4) * v88, p82 and 1.4 or 0.7, v_u_16.EnemySigil, 5)
		v_u_61(v91, v89, (p82 and 2.6 or 1.8) * v88, p82 and 60 or 18, p82 and 0.7 or 0.4)
		local v92 = v_u_10.burst
		local v93 = v_u_17.FLOOR_Y + 1
		v92("Smoke", Vector3.new(p80, v93, p81), nil, v88)
		local v94 = v_u_10.flash
		local v95 = v84.lift
		v94(v91 + Vector3.new(0, v95, 0), v89, 3.5 * v88, 0.3)
		if p82 then
			local v96 = v_u_10.burst
			local v97 = v_u_17.FLOOR_Y + 0.3
			v96("Shockwave", Vector3.new(p80, v97, p81), v89, 1)
			local v98 = v_u_10.burst
			local v99 = v84.lift
			v98("Flash", v91 + Vector3.new(0, v99, 0), v89, 0.8)
			v_u_10.ring(v91, v89, 16, 0.6)
			v_u_10.shake(0.35, 0.5)
			v_u_9.play("BossAppear")
		end
		local v100 = v_u_22.spawn
		if v100 then
			for _, v101 in v100 do
				task.spawn(v101, v86)
			end
		end
	end
end
local function v_u_116(p103) -- name: flash
	-- upvalues: (copy) v_u_6, (copy) v_u_69
	local v104 = os.clock()
	local v105 = v104 < p103.flashUntil
	p103.flashUntil = v104 + 0.07
	p103.hitAt = v104
	if not v105 then
		if p103.rig15 then
			v_u_6.flash(p103.rig15, true)
		end
		for _, v106 in p103.body.parts do
			v106.Color = Color3.new(1, 1, 1)
		end
	end
	if v104 - p103.bitsAt > 0.2 then
		p103.bitsAt = v104
		local v107 = p103.body
		local v108 = v107.root.Position
		local v109 = 0.3 * v107.scale
		local v110 = v108 + Vector3.new(0, v109, 0)
		local v111 = v_u_69
		local v112 = v107.glow
		local v113 = p103.boss and 6 or 4.5
		local v114 = v107.scale
		v111(v110, v112, v113 * math.min(v114, 1.6), 1, 1.2 * v107.scale + 1)
		for _, v115 in v107.emitters do
			v115:Emit(p103.boss and 4 or 2)
		end
	end
end
local function v_u_154(p117) -- name: shatter
	-- upvalues: (copy) v_u_17, (copy) v_u_10, (copy) v_u_69, (copy) v_u_77, (copy) v_u_16, (copy) v_u_9, (copy) v_u_1, (copy) v_u_6, (copy) v_u_11
	local v118 = p117.body
	local v119 = v118.root.Position
	local v120 = v118.scale
	local v121 = v118.glow
	local v122 = v119.X
	local v123 = v_u_17.FLOOR_Y + 0.05
	local v124 = v119.Z
	local v125 = Vector3.new(v122, v123, v124)
	v_u_10.burst("Smoke", v119, nil, v120 * 1.2)
	v_u_10.burst("Impact", v119, v121, v120)
	v_u_69(v119, v121, 7 * v120, 2, 1.2 * v120 + 1)
	v_u_10.flash(v119, v121, 5 * v120, 0.3)
	v_u_10.ring(v125, v121, 4 * v120, 0.45)
	if v118.boss then
		v_u_77(v125, v121, 9 * v120, v_u_16.CrackGlow, 2.5)
		local v126 = v_u_10.burst
		local v127 = v120 * 0.7
		v126("Explosion", v119, v121, (math.min(v127, 2.2)))
		local v128 = v_u_10.burst
		local v129 = v119.X
		local v130 = v_u_17.FLOOR_Y + 0.3
		local v131 = v119.Z
		v128("Shockwave", Vector3.new(v129, v130, v131), v121, 1.2)
		v_u_10.burst("Flash", v119, v121, 1)
		v_u_10.burst("Sparkle", v119, nil, 1)
		v_u_10.shake(0.45, 0.5)
		v_u_9.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.8,
			["at"] = v119
		})
	end
	v_u_9.play("EnemyDie", {
		["at"] = v119
	})
	for _, v132 in v118.emitters do
		v132:Emit(v118.boss and 24 or 10)
		v132.Enabled = false
	end
	for _, v133 in v118.stops do
		v133()
	end
	table.clear(v118.stops)
	local v134 = v118.ground
	if v134 then
		v134.Anchored = true
		for _, v135 in v134:GetChildren() do
			if not v135:IsA("Decal") then
				continue
			end
			v_u_10.tween(v135, 0.4, {
				["Transparency"] = 1
			})
		end
		v_u_10.tween(v134, 0.4, {
			["Size"] = v134.Size * 1.4
		})
		v_u_1:AddItem(v134, 1.3)
	end
	v118.tag:Destroy()
	v_u_1:AddItem(v118.model, 1.3)
	if p117.rig15 then
		v_u_6.die(p117.rig15, v119)
	else
		for _, v136 in v118.model:GetDescendants() do
			if not (v136:IsA("Motor6D") or v136:IsA("WeldConstraint")) then
				continue
			end
			v136:Destroy()
		end
		local v137 = table.clone(v118.parts)
		table.sort(v137, function(p138, p139)
			return p138.Size.X * p138.Size.Y * p138.Size.Z > p139.Size.X * p139.Size.Y * p139.Size.Z
		end)
		local v140 = v_u_11.level() <= 1 and 6 or (v_u_11.level() == 2 and 10 or 24)
		local v_u_141 = {}
		for v142, v143 in v137 do
			if v142 <= v140 then
				table.insert(v_u_141, v143)
			else
				v143.Anchored = true
				v143.CanCollide = false
				v143.LocalTransparencyModifier = 1
			end
		end
		for _, v144 in v_u_141 do
			v144.Anchored = false
			v144.CanCollide = true
			v144.CollisionGroup = v_u_17.DEBRIS_GROUP
			v144.Massless = false
			local v145 = v144.Position - v119
			if v145.Magnitude < 0.1 then
				local v146 = math.random() - 0.5
				local v147 = math.random() - 0.5
				v145 = Vector3.new(v146, 0, v147)
			end
			local v148 = v145.Unit * (18 + math.random() * 14)
			local v149 = 22 + math.random() * 12
			v144.AssemblyLinearVelocity = v148 + Vector3.new(0, v149, 0)
			local v150 = math.random() - 0.5
			local v151 = math.random() - 0.5
			local v152 = math.random() - 0.5
			v144.AssemblyAngularVelocity = Vector3.new(v150, v151, v152) * 18
		end
		v118.root:Destroy()
		task.delay(0.9, function()
			-- upvalues: (copy) v_u_141, (ref) v_u_10
			for _, v153 in v_u_141 do
				if not v153.Parent then
					continue
				end
				v_u_10.tween(v153, 0.3, {
					["Transparency"] = 1,
					["Size"] = nil,
					["Size"] = v153.Size * 0.4
				})
			end
		end)
	end
end
local function v_u_160(p155) -- name: clearAll
	-- upvalues: (copy) v_u_19, (copy) v_u_10
	for _, v156 in v_u_19 do
		if p155 then
			v_u_10.burst("Smoke", v156.body.root.Position, nil, v156.body.scale)
		end
		v_u_19[v156.id] = nil
		if v156.telegraph then
			v156.telegraph:Destroy()
		end
		local v157 = v156.body
		for _, v158 in v157.stops do
			v158()
		end
		table.clear(v157.stops)
		v156.body.model:Destroy()
		local v159 = v156.body.ground
		if not v159 then
			break
		end
		v159:Destroy()
	end
end
local function v_u_171(p161) -- name: onSnap
	-- upvalues: (copy) v_u_19
	if typeof(p161) == "buffer" and buffer.len(p161) >= 2 then
		local v162 = buffer.readu8(p161, 1)
		if buffer.len(p161) >= v162 * 14 + 2 then
			for v163 = 1, v162 do
				local v164 = (v163 - 1) * 14 + 2
				local v165 = v_u_19[buffer.readu32(p161, v164)]
				if not v165 then
					continue
				end
				local v166 = v164 + 4
				v165.goalX = buffer.readf32(p161, v166)
				local v167 = v164 + 8
				v165.goalZ = buffer.readf32(p161, v167)
				local v168 = v164 + 12
				local v169 = buffer.readu8(p161, v168)
				v165.frozen = bit32.band(v169, 2) ~= 0
				local v170 = v164 + 13
				v165.hpShare = buffer.readu8(p161, v170) / 255
			end
		end
	else
		return
	end
end
local function v_u_178(p_u_172) -- name: telegraph
	-- upvalues: (copy) v_u_10, (copy) v_u_17
	local v173 = p_u_172.reach
	local v174 = v_u_10.part
	local v175 = v173 * 2
	local v176 = v173 * 2
	local v_u_177 = v174(Vector3.new(0.2, v175, v176), CFrame.new(p_u_172.x, v_u_17.FLOOR_Y + 0.15, p_u_172.z) * CFrame.Angles(0, 0, 1.5707963267948966), Color3.fromRGB(255, 50, 60), {
		["shape"] = nil,
		["transparency"] = 0.55,
		["shape"] = Enum.PartType.Cylinder
	})
	p_u_172.telegraph = v_u_177
	v_u_10.tween(v_u_177, p_u_172.def.windup, {
		["Transparency"] = 0.25
	})
	task.delay(p_u_172.def.windup + 0.05, function()
		-- upvalues: (copy) p_u_172, (copy) v_u_177
		if p_u_172.telegraph == v_u_177 then
			p_u_172.telegraph = nil
		end
		v_u_177:Destroy()
	end)
end
local function v_u_198(p179) -- name: strikeFx
	-- upvalues: (copy) v_u_17, (copy) v_u_10
	local v180 = p179.body
	local v181 = v180.scale
	local v182 = p179.yaw
	local v183 = -math.sin(v182)
	local v184 = p179.yaw
	local v185 = -math.cos(v184)
	local v186 = Vector3.new(v183, 0, v185)
	local v187 = p179.x
	local v188 = v_u_17.FLOOR_Y + v180.lift
	local v189 = p179.z
	local v190 = Vector3.new(v187, v188, v189) + v186 * (1.2 * v181)
	local v191 = v_u_10.burst
	local v192 = v180.glow
	local v193 = 0.55 * v181
	v191("Slash", v190, v192, (math.clamp(v193, 0.5, 1.8)))
	if p179.boss then
		local v194 = v_u_10.ring
		local v195 = p179.x
		local v196 = v_u_17.FLOOR_Y + 0.05
		local v197 = p179.z
		v194(Vector3.new(v195, v196, v197) + v186 * (2 * v181), v180.glow, p179.reach, 0.4)
	end
end
local function v_u_249(p199, p200, p201, p202, p203) -- name: pose
	-- upvalues: (copy) v_u_198, (copy) v_u_6
	local v204 = p199.body
	local v205 = v204.rig
	local v206
	if p199.windupAt then
		local v207 = (p200 - p199.windupAt) / p199.def.windup
		v206 = math.clamp(v207, 0, 1)
		if v206 >= 1 then
			p199.windupAt = nil
			p199.strikeAt = p200
			v_u_198(p199)
			v206 = 0
		end
	else
		v206 = 0
	end
	local v208 = p199.rig15
	if v208 then
		local v209 = v_u_6.pose
		local v210 = p199.speed
		local v211 = p199.frozen
		if not p199.windupAt then
			v206 = nil
		end
		v209(v208, p200, p201, v210, v211, v206, p200 - p199.strikeAt, p202, p203)
	else
		local v212 = p199.speed
		local v213 = p199.def.speed
		local v214 = v212 / math.max(v213, 1)
		local v215 = math.clamp(v214, 0, 1)
		if not p199.frozen then
			p199.phase = p199.phase + p201 * (6 + p199.def.speed * 0.5) * math.max(v215, 0.15)
		end
		local v216 = p199.phase
		local v217 = math.sin(v216) * 0.9 * v215
		local v218 = p200 - p199.strikeAt >= 0.18 and -1 or (p200 - p199.strikeAt) / 0.18
		local v219
		if v218 >= 0 then
			local v220 = v218 * 3.141592653589793
			v219 = math.sin(v220)
		else
			v219 = 0
		end
		local v221 = p200 * 2.4 + p199.id
		local v222 = math.sin(v221) * 0.04 * v204.scale
		if v205 == "biped" or v205 == "float" then
			local v223 = v204.ready
			local v224
			if v223 > 0 then
				v224 = v217 * 0.3
			else
				v224 = v217
			end
			local v225 = CFrame.Angles(v223 + v224, 0, 0)
			if p199.windupAt then
				local v226 = v223 + (-2.792526803190927 - v223) * v206
				v225 = CFrame.Angles(v226, 0, v206 * 0.17453292519943295)
			elseif v218 >= 0 then
				v225 = CFrame.Angles(v218 * 3.839724354387525 + -2.792526803190927, 0, 0)
			end
			v204.rightArm.Transform = v225
			if v205 == "float" then
				local v227 = p200 * 2 + p199.id
				local v228 = math.sin(v227) * 0.15
				v204.leftArm.Transform = CFrame.Angles(v228 * 0.5 + 0.3, 0, -0.15)
				v204.rightLeg.Transform = CFrame.Angles(v215 * -0.35 + v228, 0, 0)
				v204.leftLeg.Transform = CFrame.Angles(v215 * -0.35 - v228, 0, 0)
			else
				v204.leftArm.Transform = CFrame.Angles(-v217, 0, 0)
				v204.rightLeg.Transform = CFrame.Angles(-v217, 0, 0)
				v204.leftLeg.Transform = CFrame.Angles(v217, 0, 0)
			end
			v204.waist.Transform = CFrame.new(0, v222, 0) * CFrame.Angles(v219 * -0.12, 0, 0)
		elseif v205 == "wolf" then
			v204.rightArm.Transform = CFrame.Angles(v217 + v206 * 0.9, 0, 0)
			v204.leftArm.Transform = CFrame.Angles(-v217 + v206 * 0.9, 0, 0)
			v204.rightLeg.Transform = CFrame.Angles(-v217, 0, 0)
			v204.leftLeg.Transform = CFrame.Angles(v217, 0, 0)
			v204.waist.Transform = CFrame.new(0, v222, -1.2 * v204.scale * v219) * CFrame.Angles(v206 * 0.45 - v219 * 0.25, 0, 0)
			local v229 = v204.tail
			if v229 then
				local v230 = CFrame.Angles
				local v231 = p200 * 9
				v229.Transform = v230(0, math.sin(v231) * 0.5, 0)
			end
		elseif v205 == "scorpion" then
			local v232 = p199.phase
			local v233 = math.sin(v232) * 0.35 * v215
			v204.rightLeg.Transform = CFrame.Angles(0, v233, 0)
			v204.leftLeg.Transform = CFrame.Angles(0, -v233, 0)
			local v234 = p200 * 3 + p199.id
			local v235 = math.sin(v234) * 0.1
			v204.rightArm.Transform = CFrame.Angles(v206 * 0.3 - v219 * 0.3, v235, 0)
			v204.leftArm.Transform = CFrame.Angles(v206 * 0.3 - v219 * 0.3, -v235, 0)
			v204.waist.Transform = CFrame.new(0, v222, -0.6 * v204.scale * v219)
			local v236 = v204.tail
			if v236 then
				local v237 = CFrame.Angles
				local v238 = p200 * 2 + p199.id
				v236.Transform = v237(math.sin(v238) * 0.08 + v206 * 0.45 - v219 * 1, 0, 0)
			end
		else
			local v239 = p199.phase
			local v240 = math.sin(v239) * 0.3 * v215
			local v241 = p199.phase
			local v242 = math.sin(v241)
			local v243 = math.abs(v242) * 0.15 * v215
			v204.rightArm.Transform = CFrame.Angles(0, v240, v206 * 0.6 + v243)
			v204.leftArm.Transform = CFrame.Angles(0, -v240, v206 * -0.6 - v243)
			v204.rightLeg.Transform = CFrame.Angles(0, -v240, v243)
			v204.leftLeg.Transform = CFrame.Angles(0, v240, -v243)
			v204.waist.Transform = CFrame.new(0, v222, -0.8 * v204.scale * v219) * CFrame.Angles(v206 * 0.4 - v219 * 0.2, 0, 0)
		end
		local v244 = v204.neck
		local v245
		if p199.frozen then
			v245 = CFrame.Angles(-0.3490658503988659, 0, 0)
		else
			v245 = CFrame.identity
		end
		v244.Transform = v245
		for _, v246 in v204.swings do
			local v247 = p200 * v246.speed + v246.offset
			local v248 = math.sin(v247) * v246.amount * (v215 * 0.6 + 0.4) + v246.lean * v215
			v246.motor.Transform = CFrame.fromAxisAngle(v246.axis, v248)
		end
	end
end
local function v_u_313(p250) -- name: step
	-- upvalues: (copy) v_u_21, (copy) v_u_19, (copy) v_u_17, (copy) v_u_10, (copy) v_u_77, (copy) v_u_16, (copy) v_u_9, (copy) v_u_249, (copy) v_u_6
	local v251 = os.clock()
	local v252 = v_u_21.Character
	if v252 then
		v252 = v252:FindFirstChild("HumanoidRootPart")
	end
	local v253
	if v252 and v252:IsA("BasePart") then
		v253 = v252.Position
	else
		v253 = nil
	end
	local v254 = -p250 * 10
	local v255 = 1 - math.exp(v254)
	local v256 = -p250 * 25
	local v257 = 1 - math.exp(v256)
	for _, v258 in v_u_19 do
		local v259 = v258.body
		local v260 = v258.x
		local v261 = v258.z
		local v262
		if v258.leapAt then
			v262 = v257
		else
			v262 = v255
		end
		v258.x = v258.x + (v258.goalX - v258.x) * v262
		v258.z = v258.z + (v258.goalZ - v258.z) * v262
		local v263 = (v258.x - v260) ^ 2 + (v258.z - v261) ^ 2
		local v264 = math.sqrt(v263)
		local v265 = v258.speed
		local v266 = v264 / math.max(p250, 0.001) - v258.speed
		local v267 = p250 * 8
		v258.speed = v265 + v266 * math.min(1, v267)
		local v268 = v258.x - v260
		local v269 = v258.z - v261
		if v253 then
			local v270 = v258.x
			local v271 = v253.Y
			local v272 = v258.z
			if (v253 - Vector3.new(v270, v271, v272)).Magnitude < 40 then
				v268 = v253.X - v258.x
				v269 = v253.Z - v258.z
			end
		end
		if v268 * v268 + v269 * v269 > 0.0001 and not v258.frozen then
			local v273 = -v268
			local v274 = -v269
			local v275 = (math.atan2(v273, v274) - v258.yaw + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
			local v276 = v258.yaw
			local v277 = p250 * 10
			v258.yaw = v276 + v275 * math.min(1, v277)
		end
		local v278 = (v251 - v258.spawnedAt) / 0.2
		local v279 = math.clamp(v278, 0, 1)
		local v280 = (1 - v279) * (1 - v279) * 6 * v259.scale
		local v281 = 0
		local v282 = v258.leapAt
		if v282 then
			local v283 = (v251 - v282) / 0.55
			if v283 >= 1 then
				v258.leapAt = nil
				local v284 = v258.x
				local v285 = v_u_17.FLOOR_Y + 0.3
				local v286 = v258.z
				local v287 = Vector3.new(v284, v285, v286)
				v_u_10.burst("Shockwave", v287, Color3.fromRGB(255, 60, 70), 0.6)
				v_u_10.ring(v287, Color3.fromRGB(255, 60, 70), v258.reach * 1.6, 0.4)
				v_u_77(v287, v259.glow, v258.reach * 1.8, v_u_16.CrackGlow, 1.6)
				v_u_9.play("Explosion", {
					["at"] = nil,
					["volume"] = 0.7,
					["at"] = v287
				})
			else
				local v288 = v283 * 3.141592653589793
				v281 = math.sin(v288) * 10
			end
		end
		if v259.rig == "float" then
			local v289 = v251 * 2 + v258.id
			v281 = v281 + math.sin(v289) * 0.25 * v259.scale
		end
		local v290 = 1 - (v251 - v258.hitAt) / 0.15
		local v291 = math.clamp(v290, 0, 1)
		local v292 = CFrame.new(v258.x, v_u_17.FLOOR_Y + v259.lift - v280 + v281, v258.z) * CFrame.Angles(0, v258.yaw, 0)
		local v293 = v259.root
		if v291 > 0 then
			v292 = v292 * CFrame.new(0, 0, 0.35 * v259.scale * v291) * CFrame.Angles(v291 * 0.12, 0, 0)
		end
		v293.CFrame = v292
		v_u_249(v258, v251, p250, v291, v281)
		if #v259.orbits > 0 then
			local v294 = v258.x
			local v295 = v_u_17.FLOOR_Y + v259.lift - v280 + v281
			local v296 = v258.z
			local v297 = Vector3.new(v294, v295, v296)
			for _, v298 in v259.orbits do
				local v299 = v251 * v298.speed + v298.phase
				local v300 = v298.part
				local v301 = CFrame.new
				local v302 = math.cos(v299) * v298.radius
				local v303 = v298.height
				local v304 = v251 * 2 + v298.phase
				local v305 = v303 + math.sin(v304) * 0.3 * v259.scale
				local v306 = math.sin(v299) * v298.radius
				v300.CFrame = v301(v297 + Vector3.new(v302, v305, v306)) * CFrame.Angles(v251 * 1.5, v299, 0)
			end
		end
		local v307 = v259.ground
		if v307 then
			v307.CFrame = CFrame.new(v258.x, v_u_17.FLOOR_Y + 0.12, v258.z) * CFrame.Angles(0, v251 * 0.8, 0)
		end
		if v258.flashUntil > 0 and v258.flashUntil <= v251 then
			v258.flashUntil = 0
			if v258.rig15 then
				v_u_6.flash(v258.rig15, false)
			end
			for v308, v309 in v259.parts do
				v309.Color = v259.colors[v308]
			end
		end
		local v310 = v259.bar
		if v310 then
			local v311 = UDim2.fromScale
			local v312 = v258.hpShare
			v310.Size = v311(math.max(v312, 0), 1)
		end
		if not v258.telegraph then
			continue
		end
		v258.telegraph.CFrame = CFrame.new(v258.x, v_u_17.FLOOR_Y + 0.15, v258.z) * CFrame.Angles(0, 0, 1.5707963267948966)
	end
end
function v_u_18.start() -- name: start
	-- upvalues: (copy) v_u_5, (ref) v_u_20, (copy) v_u_12, (copy) v_u_18, (copy) v_u_7, (copy) v_u_102, (copy) v_u_6, (copy) v_u_17, (copy) v_u_19, (copy) v_u_116, (copy) v_u_8, (copy) v_u_10, (copy) v_u_9, (copy) v_u_21, (copy) v_u_178, (copy) v_u_22, (copy) v_u_154, (copy) v_u_160, (copy) v_u_13, (copy) v_u_171, (copy) v_u_4, (copy) v_u_313
	local v314 = Instance.new("Folder")
	v314.Name = "MyEnemies"
	v314.Parent = v_u_5
	v_u_20 = v314
	v_u_12.setEnemyLocator(v_u_18.position)
	v_u_7.on("spawn", function(p315)
		-- upvalues: (ref) v_u_102, (ref) v_u_6, (ref) v_u_17, (ref) v_u_19
		local v316 = p315.id
		if type(v316) == "number" then
			local v317 = p315.kind
			if type(v317) == "string" then
				local v318 = p315.x
				if type(v318) == "number" then
					local v319 = p315.z
					if type(v319) == "number" then
						v_u_102(p315.id, p315.kind, p315.x, p315.z, p315.boss == true)
						local v320 = v_u_6.warmAfter
						local v321 = p315.kind
						local v322 = p315.x
						local v323 = v_u_17.FLOOR_Y
						local v324 = p315.z
						v320(v321, (Vector3.new(v322, v323, v324)))
						local v325 = v_u_19[p315.id]
						if v325 then
							local v326 = p315.hp
							if type(v326) == "number" then
								v325.body.model:SetAttribute("MaxHp", p315.hp)
							end
						end
					end
				end
			end
		end
	end)
	v_u_7.on("hit", function(p327)
		-- upvalues: (ref) v_u_19, (ref) v_u_116, (ref) v_u_8, (ref) v_u_10, (ref) v_u_9
		local v328 = v_u_19[p327.id]
		if v328 then
			local v329 = p327.d
			if type(v329) == "number" then
				local v330 = p327.hp
				if type(v330) == "number" then
					local v331 = v328.body.model:GetAttribute("MaxHp")
					if type(v331) == "number" and v331 > 0 then
						v328.hpShare = p327.hp / v331
					end
				end
				v_u_116(v328)
				local v332 = v328.body.head.Position
				local v333 = v_u_8.show
				local v334 = 1.5 * v328.body.scale
				local v335 = v332 + Vector3.new(0, v334, 0)
				local v336 = p327.d
				local v337 = p327.c == true
				local v338 = v328.body.scale
				v333(v335, v336, v337, math.clamp(v338, 1, 1.6), p327.id)
				if p327.c == true then
					v_u_10.burst("Flash", v332, Color3.fromRGB(255, 214, 64), 0.3)
					v_u_9.play("Crit", {
						["at"] = nil,
						["volume"] = 0.8,
						["at"] = v332
					})
				else
					v_u_9.play("Hit", {
						["at"] = nil,
						["volume"] = 0.45,
						["at"] = v332
					})
				end
			end
		end
	end)
	v_u_7.on("leap", function(p339)
		-- upvalues: (ref) v_u_19, (ref) v_u_21, (ref) v_u_17, (ref) v_u_10
		local v340 = v_u_19[p339.id]
		if v340 then
			v340.leapAt = os.clock()
			local v341 = v_u_21.Character
			if v341 then
				v341 = v_u_21.Character:FindFirstChild("HumanoidRootPart")
			end
			if v341 and v341:IsA("BasePart") then
				local v342 = v341.Position.X
				local v343 = v_u_17.FLOOR_Y + 0.15
				local v344 = v341.Position.Z
				local v345 = Vector3.new(v342, v343, v344)
				local v346 = v_u_10.part
				local v347 = v340.reach * 3.2
				local v348 = v340.reach * 3.2
				local v_u_349 = v346(Vector3.new(0.2, v347, v348), CFrame.new(v345) * CFrame.Angles(0, 0, 1.5707963267948966), Color3.fromRGB(255, 50, 60), {
					["shape"] = nil,
					["transparency"] = 0.55,
					["shape"] = Enum.PartType.Cylinder
				})
				v_u_10.tween(v_u_349, 0.5, {
					["Transparency"] = 0.2
				})
				task.delay(0.6, function()
					-- upvalues: (copy) v_u_349
					v_u_349:Destroy()
				end)
			end
		end
	end)
	v_u_7.on("swing", function(p350)
		-- upvalues: (ref) v_u_19, (ref) v_u_178, (ref) v_u_6
		local v351 = v_u_19[p350.id]
		if v351 then
			v351.windupAt = os.clock()
			v_u_178(v351)
			if v351.rig15 then
				v_u_6.swing(v351.rig15)
			end
		end
	end)
	v_u_7.on("die", function(p352)
		-- upvalues: (ref) v_u_19, (ref) v_u_22, (ref) v_u_154
		local v353 = v_u_19[p352.id]
		if v353 then
			v_u_19[v353.id] = nil
			if v353.telegraph then
				v353.telegraph:Destroy()
			end
			local v354 = v_u_22.die
			if v354 then
				for _, v355 in v354 do
					task.spawn(v355, v353)
				end
			end
			v_u_154(v353)
		end
	end)
	v_u_7.on("clear", function()
		-- upvalues: (ref) v_u_160
		v_u_160(true)
	end)
	v_u_7.on("reset", function()
		-- upvalues: (ref) v_u_19
		for _, v356 in v_u_19 do
			v_u_19[v356.id] = nil
			if v356.telegraph then
				v356.telegraph:Destroy()
			end
			local v357 = v356.body
			for _, v358 in v357.stops do
				v358()
			end
			table.clear(v357.stops)
			v356.body.model:Destroy()
			local v359 = v356.body.ground
			if not v359 then
				break
			end
			v359:Destroy()
		end
	end)
	v_u_7.on("start", function()
		-- upvalues: (ref) v_u_19
		for _, v360 in v_u_19 do
			v_u_19[v360.id] = nil
			if v360.telegraph then
				v360.telegraph:Destroy()
			end
			local v361 = v360.body
			for _, v362 in v361.stops do
				v362()
			end
			table.clear(v361.stops)
			v360.body.model:Destroy()
			local v363 = v360.body.ground
			if not v363 then
				break
			end
			v363:Destroy()
		end
	end)
	v_u_13.unreliable("Snap").OnClientEvent:Connect(v_u_171)
	v_u_4.RenderStepped:Connect(v_u_313)
	task.spawn(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_17
		task.wait(15)
		while true do
			local v364 = v_u_5.CurrentCamera
			if v364 then
				local v365 = v364.Focus.Position
				v_u_6.warmWorld(v_u_17.worldAt(v365), v365)
			end
			task.wait(5)
		end
	end)
end
return v_u_18