local v_u_1 = game:GetService("MarketplaceService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v3.Shared.Config.Packs)
local v_u_6 = require(v3.Shared.Config.Products)
local v_u_7 = require(v3.Shared.Config.Release)
local v_u_8 = require(v3.Shared.Config.Daily)
local v_u_9 = require(v3.Shared.Logic.DailyStreak)
require(v3.Shared.Logic.Prizes)
local v_u_10 = require(script.Parent.OfferLog)
local v_u_11 = require(script.Parent.State)
local v_u_12 = require(script.Parent.Tutorial)
local v_u_13 = {}
local v_u_14 = v2.LocalPlayer
function v_u_13.quiet() -- name: quiet
	-- upvalues: (copy) v_u_12, (copy) v_u_4, (copy) v_u_14, (copy) v_u_11
	local v15 = v_u_12.active()
	if not v15 then
		if v_u_4:IsStudio() and v_u_14:GetAttribute("DevQuiet") ~= true then
			return false
		end
		v15 = v_u_11.number("PlayTime") < 180
	end
	return v15
end
local function v_u_16(_) end
function v_u_13.onComingSoon(p17) -- name: onComingSoon
	-- upvalues: (ref) v_u_16
	v_u_16 = p17
end
function v_u_13.product(p18) -- name: product
	-- upvalues: (copy) v_u_6
	local v19 = v_u_6.productByKey[p18]
	if v19 then
		return v19
	end
	for _, v20 in v_u_6.products do
		if v20.name ~= p18 then
			continue
		end
		return v20
	end
	return nil
end
function v_u_13.pass(p21) -- name: pass
	-- upvalues: (copy) v_u_6
	local v22 = v_u_6.passByKey[p21]
	if v22 then
		return v22
	end
	for _, v23 in v_u_6.passes do
		if v23.name ~= p21 then
			continue
		end
		return v23
	end
	return nil
end
local v_u_24 = (-1 / 0)
function v_u_13.sincePrompt() -- name: sincePrompt
	-- upvalues: (ref) v_u_24
	return os.clock() - v_u_24
end
local v_u_25 = nil
local function v_u_26()
	return false
end
local function v_u_27()
	return false
end
function v_u_13.onRandomPurchase(p28, p29, p30) -- name: onRandomPurchase
	-- upvalues: (ref) v_u_25, (ref) v_u_26, (ref) v_u_27
	v_u_25 = p28
	v_u_26 = p29
	v_u_27 = p30
end
function v_u_13.randomRestricted() -- name: randomRestricted
	-- upvalues: (ref) v_u_27
	return v_u_27()
end
function v_u_13.luckBlocked() -- name: luckBlocked
	-- upvalues: (ref) v_u_26
	return v_u_26()
end
local v_u_31 = Instance.new("BindableEvent")
v_u_13.randomChanged = v_u_31.Event
function v_u_13.fireRandomChanged() -- name: fireRandomChanged
	-- upvalues: (copy) v_u_31
	v_u_31:Fire()
end
function v_u_13.dailyAllPrizes() -- name: dailyAllPrizes
	-- upvalues: (copy) v_u_9, (copy) v_u_11, (copy) v_u_8
	local v32, v33 = v_u_9.unlockAll(v_u_11.number("DailyStreak"), v_u_11.number("DailyLast", -1), v_u_11.number("DailyWeek"), v_u_11.number("Today", -2), v_u_8.DAYS)
	local v34 = v_u_8.week(v33)
	local v35 = {}
	for _, v36 in v32 do
		local v37 = v34[v36]
		table.insert(v35, v37)
	end
	return v35
end
function v_u_13.isRandom(p38, p39) -- name: isRandom
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (ref) v_u_27, (copy) v_u_13
	if p38 == "pass" then
		local v40 = v_u_5[p39]
		if not v40 then
			return false
		end
		for _, v41 in v40 do
			if v41.kind ~= "egg" then
				continue
			end
			return true
		end
		return false
	else
		local v42 = v_u_6.productByKey[p39]
		if v42 and (v42.kind == "dailyAll" or v42.kind == "skipDay") and v_u_27() then
			return false
		elseif v42 and v42.kind == "dailyAll" then
			for _, v43 in v_u_13.dailyAllPrizes() do
				if v43.kind ~= "egg" then
					continue
				end
				return true
			end
			return false
		else
			local v44
			if v42 == nil then
				v44 = false
			else
				v44 = v42.kind == "egg" and true or v42.kind == "skipDay"
			end
			return v44
		end
	end
end
function v_u_13.randomBlocked(p45, p46) -- name: randomBlocked
	-- upvalues: (copy) v_u_13, (ref) v_u_26
	local v47 = p45 == "product" and v_u_13.isRandom(p45, p46)
	if v47 then
		v47 = v_u_26()
	end
	return v47
end
function v_u_13.buyProduct(p48, p_u_49, p_u_50) -- name: buyProduct
	-- upvalues: (copy) v_u_13, (ref) v_u_16, (ref) v_u_24, (copy) v_u_10, (copy) v_u_1, (copy) v_u_14, (ref) v_u_25
	local v51 = v_u_13.product(p48)
	if v51 and v51.id ~= 0 then
		local v_u_52 = v51.id
		local v_u_53 = v51.key
		local function v54() -- name: prompt
			-- upvalues: (ref) v_u_24, (copy) p_u_49, (ref) v_u_10, (copy) v_u_53, (copy) p_u_50, (ref) v_u_1, (ref) v_u_14, (copy) v_u_52
			v_u_24 = os.clock()
			if p_u_49 then
				v_u_10.click(p_u_49, "product", v_u_53, p_u_50)
			end
			v_u_1:PromptProductPurchase(v_u_14, v_u_52)
		end
		if v_u_25 and v_u_13.isRandom("product", v51.key) then
			v_u_25("product", v51.key, v54)
		else
			v_u_24 = os.clock()
			if p_u_49 then
				v_u_10.click(p_u_49, "product", v_u_53, p_u_50)
			end
			v_u_1:PromptProductPurchase(v_u_14, v_u_52)
		end
	else
		local v55 = v_u_16
		if v51 then
			p48 = v51.name
		end
		v55(p48)
		return
	end
end
local function v_u_56(_)
	return false
end
function v_u_13.onPassBuy(p57) -- name: onPassBuy
	-- upvalues: (ref) v_u_56
	v_u_56 = p57
end
function v_u_13.promptProduct(p58, p59, p60) -- name: promptProduct
	-- upvalues: (ref) v_u_24, (copy) v_u_6, (copy) v_u_10, (copy) v_u_1, (copy) v_u_14
	v_u_24 = os.clock()
	if p59 then
		for _, v61 in v_u_6.products do
			if v61.id ~= p58 then
				continue
			end
			v_u_10.click(p59, "product", v61.key, p60)
		end
	end
	v_u_1:PromptProductPurchase(v_u_14, p58)
end
function v_u_13.oddsFirst(p62, p63, p64) -- name: oddsFirst
	-- upvalues: (ref) v_u_25, (copy) v_u_13
	if v_u_25 and v_u_13.isRandom(p62, p63) then
		v_u_25(p62, p63, p64)
	else
		p64()
	end
end
function v_u_13.upgradeFor(p65) -- name: upgradeFor
	-- upvalues: (copy) v_u_6, (copy) v_u_14, (copy) v_u_7, (copy) v_u_4
	local v66 = v_u_6.BUNDLES[p65]
	if not v66 or (v_u_14:GetAttribute("Pass_" .. p65) == true or not v_u_7.on(2)) then
		return nil
	end
	for _, v67 in v66 do
		if v_u_14:GetAttribute("Pass_" .. v67) == true then
			continue
		end
		return nil
	end
	local v68 = v_u_4:IsStudio()
	if v68 then
		v68 = game:GetService("Workspace"):GetAttribute("DevStoreCards") == true
	end
	for _, v69 in v_u_6.products do
		if v69.kind ~= "passUpgrade" or (v69.pass ~= p65 or v69.id == 0 and not v68) then
			continue
		end
		return v69
	end
	return nil
end
function v_u_13.passPrice(p70) -- name: passPrice
	-- upvalues: (copy) v_u_13
	local v71 = v_u_13.upgradeFor(p70.key)
	if v71 then
		return v71.price
	else
		return p70.price
	end
end
function v_u_13.buyPass(p72, p_u_73, p_u_74) -- name: buyPass
	-- upvalues: (copy) v_u_13, (ref) v_u_56, (ref) v_u_16, (ref) v_u_24, (copy) v_u_10, (copy) v_u_1, (copy) v_u_14, (ref) v_u_25
	local v75 = v_u_13.pass(p72)
	if v75 and v75.retired then
		return
	elseif v75 and v_u_56(v75.key) then
		return
	else
		local v76
		if v75 then
			v76 = v_u_13.upgradeFor(v75.key)
		else
			v76 = nil
		end
		if v76 then
			v_u_13.buyProduct(v76.key, p_u_73, p_u_74)
			return
		elseif v75 and v75.id ~= 0 then
			local v_u_77 = v75.id
			local v_u_78 = v75.key
			local function v79() -- name: prompt
				-- upvalues: (ref) v_u_24, (copy) p_u_73, (ref) v_u_10, (copy) v_u_78, (copy) p_u_74, (ref) v_u_1, (ref) v_u_14, (copy) v_u_77
				v_u_24 = os.clock()
				if p_u_73 then
					v_u_10.click(p_u_73, "pass", v_u_78, p_u_74)
				end
				v_u_1:PromptGamePassPurchase(v_u_14, v_u_77)
			end
			if v_u_25 and v_u_13.isRandom("pass", v75.key) then
				v_u_25("pass", v75.key, v79)
			else
				v_u_24 = os.clock()
				if p_u_73 then
					v_u_10.click(p_u_73, "pass", v_u_78, p_u_74)
				end
				v_u_1:PromptGamePassPurchase(v_u_14, v_u_77)
			end
		else
			local v80 = v_u_16
			if v75 then
				p72 = v75.name
			end
			v80(p72)
			return
		end
	end
end
function v_u_13.offerPass(p81) -- name: offerPass
	-- upvalues: (copy) v_u_13
	if v_u_13.quiet() then
		return false
	end
	v_u_13.buyPass(p81)
	return true
end
local v_u_82 = Instance.new("BindableEvent")
v_u_13.pricesChanged = v_u_82.Event
function v_u_13.syncPrices() -- name: syncPrices
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_82
	local v83 = false
	for _, v84 in v_u_6.passes do
		if v84.id == 0 or v84.retired then
			continue
		end
		local v_u_85 = v84.id
		local v_u_86 = Enum.InfoType.GamePass
		local function v87()
			-- upvalues: (ref) v_u_1, (copy) v_u_85, (copy) v_u_86
			return v_u_1:GetProductInfo(v_u_85, v_u_86)
		end
		local v88, v89 = pcall(v87)
		if v88 then
			if type(v89) == "table" then
				v88 = v89.PriceInRobux
			else
				v88 = false
			end
		end
		if type(v88) ~= "number" or v88 <= 0 then
			v88 = nil
		end
		if v88 and v88 ~= v84.price then
			v84.price = v88
			v83 = true
		end
		task.wait(0.1)
	end
	for _, v90 in v_u_6.products do
		if v90.id == 0 then
			continue
		end
		local v_u_91 = v90.id
		local v_u_92 = Enum.InfoType.Product
		local function v93()
			-- upvalues: (ref) v_u_1, (copy) v_u_91, (copy) v_u_92
			return v_u_1:GetProductInfo(v_u_91, v_u_92)
		end
		local v94, v95 = pcall(v93)
		if v94 then
			if type(v95) == "table" then
				v94 = v95.PriceInRobux
			else
				v94 = false
			end
		end
		if type(v94) ~= "number" or v94 <= 0 then
			v94 = nil
		end
		if v94 and v94 ~= v90.price then
			v90.price = v94
			v83 = true
		end
		task.wait(0.1)
	end
	if v83 then
		v_u_82:Fire()
	end
end
function v_u_13.livePrice(p_u_96, p_u_97) -- name: livePrice
	-- upvalues: (copy) v_u_1
	local function v98()
		-- upvalues: (ref) v_u_1, (copy) p_u_96, (copy) p_u_97
		return v_u_1:GetProductInfo(p_u_96, p_u_97)
	end
	local v99, v100 = pcall(v98)
	if v99 then
		if type(v100) == "table" then
			v99 = v100.PriceInRobux
		else
			v99 = false
		end
	end
	if type(v99) == "number" and v99 > 0 then
		return v99
	else
		return nil
	end
end
function v_u_13.firePricesChanged() -- name: firePricesChanged
	-- upvalues: (copy) v_u_82
	v_u_82:Fire()
end
v_u_13.ROBUX = "\238\128\130"
function v_u_13.priceText(p101) -- name: priceText
	-- upvalues: (copy) v_u_13
	return v_u_13.ROBUX .. " " .. tostring(p101)
end
local v_u_102 = {}
function v_u_13.offer(p_u_103, p_u_104) -- name: offer
	-- upvalues: (copy) v_u_13, (copy) v_u_102, (copy) v_u_14
	if v_u_13.quiet() then
		return
	else
		local v105 = os.clock()
		if v105 - (v_u_102[p_u_103] or (-1 / 0)) >= 20 then
			v_u_102[p_u_103] = v105
			task.delay(0.6, function()
				-- upvalues: (copy) p_u_103, (ref) v_u_13, (ref) v_u_14, (copy) p_u_104
				if p_u_103 == "rebirth" then
					v_u_13.buyProduct("skipRebirth")
				else
					for _, v106 in { "starter", "pro", "winsPad" } do
						if v_u_14:GetAttribute("Pass_" .. v106) == true or v_u_13.randomBlocked("pass", v106) then
							continue
						end
						v_u_13.buyPass(v106, "TrophyNudge", p_u_104 or "Menu")
						return
					end
				end
			end)
		end
	end
end
function v_u_13.offerProduct(p_u_107, p108) -- name: offerProduct
	-- upvalues: (copy) v_u_13, (copy) v_u_102
	local v109 = v_u_13.product(p_u_107)
	if v109 and (v109.id ~= 0 and not v_u_13.quiet()) then
		local v110 = os.clock()
		if v110 - (v_u_102[p_u_107] or (-1 / 0)) >= (p108 or 20) then
			v_u_102[p_u_107] = v110
			task.delay(0.6, function()
				-- upvalues: (ref) v_u_13, (copy) p_u_107
				v_u_13.buyProduct(p_u_107)
			end)
		end
	else
		return
	end
end
return v_u_13