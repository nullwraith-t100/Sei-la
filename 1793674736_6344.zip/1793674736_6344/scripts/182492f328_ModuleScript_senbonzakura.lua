local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(255, 240, 248)
local v_u_6 = Color3.fromRGB(240, 70, 150)
local v_u_7 = Color3.fromRGB(226, 222, 236)
local v_u_8 = Color3.fromRGB(96, 52, 140)
local function v_u_16(p9) -- name: piece
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_2
	local v10 = v_u_1:FindFirstChild("EyePieces")
	if v10 then
		v10 = v10:FindFirstChild("w6_senbonzakura")
	end
	if v10 and v10:IsA("MeshPart") then
		local v11 = v10:Clone()
		v11.Anchored = true
		v11.CanCollide = false
		v11.CanQuery = false
		v11.CanTouch = false
		v11.CastShadow = false
		v11.Massless = true
		local v12 = v10.Size
		local v13 = v12.X
		local v14 = v12.Y
		local v15 = v12.Z
		v11.Size = v12 * (p9 / math.max(v13, v14, v15, 0.01))
		if not v11:FindFirstChildOfClass("SurfaceAppearance") then
			v11.Color = v_u_7
			v11.Material = Enum.Material.Metal
		end
		v11.Parent = v_u_2.folder()
		if v12.X >= v12.Y and v12.X >= v12.Z then
			return v11, CFrame.identity
		elseif v12.Y >= v12.Z then
			return v11, CFrame.Angles(0, 0, -1.5707963267948966)
		else
			return v11, CFrame.Angles(0, 1.5707963267948966, 0)
		end
	else
		return nil, CFrame.identity
	end
end
local function v_u_22(p17, p18, p19, p20) -- name: petals
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v21 = Instance.new("ParticleEmitter")
	v21.Texture = v_u_4.SakuraPetal
	v21.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v21.FlipbookMode = Enum.ParticleFlipbookMode.Loop
	v21.FlipbookFramerate = NumberRange.new(10, 22)
	v21.FlipbookStartRandom = true
	v21.Color = ColorSequence.new(p20, v_u_5)
	v21.LightEmission = 0.25
	v21.LightInfluence = 0
	v21.Lifetime = NumberRange.new(1, 1.6)
	v21.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 * 0.05 * p19), NumberSequenceKeypoint.new(0.15, p18 * 0.3 * p19), NumberSequenceKeypoint.new(1, p18 * 0.22 * p19) })
	v21.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.75, 0), NumberSequenceKeypoint.new(1, 1) })
	v21.Speed = NumberRange.new(p19 * 0.3, p19 * 1.2)
	v21.SpreadAngle = Vector2.new(180, 180)
	v21.Acceleration = Vector3.new(0, -1.2, 0)
	v21.Drag = 1
	v21.Rotation = NumberRange.new(0, 360)
	v21.RotSpeed = NumberRange.new(-120, 120)
	v21.Shape = Enum.ParticleEmitterShape.Box
	v21.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v21.Rate = 0
	v21.Parent = p17
	return v21
end
return function(p_u_23)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5, (copy) v_u_16, (copy) v_u_7, (copy) v_u_8, (copy) v_u_22, (copy) v_u_6
	return {
		["w6_senbonzakura"] = function(p_u_24, p25)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) p_u_23, (ref) v_u_4, (ref) v_u_5, (ref) v_u_16, (ref) v_u_7, (ref) v_u_8, (ref) v_u_22, (ref) v_u_6
			local v_u_26 = v_u_2.color(p25.color)
			local v27 = p_u_24.headY / 1.5
			local v_u_28 = math.clamp(v27, 0.7, 3)
			local v_u_29 = v_u_3.formRate()
			local v_u_31 = p_u_23.throb(p_u_24, 6, 2.6, 0.5, function(p30)
				-- upvalues: (ref) v_u_2, (ref) p_u_23, (copy) p_u_24, (copy) v_u_26, (ref) v_u_4
				v_u_2.ring(p_u_23.feetAt(p_u_24, p30, 0.15), v_u_26, 6 * p_u_24.fx, 0.55, v_u_4.Ring)
			end)
			local v_u_32 = 0
			local v_u_33 = 0
			local v_u_34 = true
			local v_u_35 = Vector3.new(0, 0, 0)
			local v36 = p_u_24.ticks
			local function v42(_, _, p37)
				-- upvalues: (copy) v_u_31, (ref) v_u_32, (ref) v_u_34, (ref) v_u_35, (ref) p_u_23, (ref) v_u_2, (ref) v_u_5, (copy) v_u_28, (ref) v_u_33
				local v38 = v_u_31()
				local v39 = v38 <= 0 and (1 / 0) or (1 - v38) / 0.5
				local v40 = v_u_32
				if v39 < 0.2 then
					v_u_32 = v39 / 0.2
				elseif v39 < 1.3 then
					v_u_32 = 1
				elseif v39 < 1.9 then
					local v41 = (v39 - 1.3) / 0.6
					v_u_32 = 1 - v41 * v41
				else
					v_u_32 = 0
				end
				if v_u_32 > 0.5 then
					v_u_34 = false
				elseif v40 > 0.05 and (v_u_32 <= 0.05 and not v_u_34) then
					v_u_34 = true
					if (v_u_35 - p_u_23.camPos()).Magnitude < 150 then
						v_u_2.flash(v_u_35, v_u_5, v_u_28 * 3.2, 0.25)
					end
				end
				v_u_33 = v_u_33 + p37 * (v_u_32 * 3.5 + 0.3)
			end
			table.insert(v36, v42)
			local v_u_48 = p_u_23.group(p_u_24, function(p43, p44)
				-- upvalues: (copy) v_u_28
				local v45 = CFrame.new
				local v46 = v_u_28 * 1.25
				local v47 = p44 * 1.05
				return p43 * v45(0, v46 + math.sin(v47) * 0.1 * v_u_28, v_u_28 * 1.45)
			end)
			local v_u_54 = p_u_23.group(p_u_24, function()
				-- upvalues: (copy) v_u_48, (ref) p_u_23
				local v49 = v_u_48.cf.Position
				local v50 = p_u_23.camPos() - v49
				local v51 = v50.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v50.Unit
				local v52 = v51.Y
				local v53 = math.abs(v52) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v49, v49 + v51, v53) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v55 = p_u_23.picture(v_u_28 * 5.4, v_u_4.Glow, v_u_26, 0.4)
			p_u_23.add(p_u_24, v55, function()
				-- upvalues: (copy) v_u_54, (copy) v_u_28
				return v_u_54.cf * CFrame.new(0, v_u_28 * -0.35, 0)
			end)
			p_u_23.fadeFromBehind(p_u_24, v55, 0.55)
			local v_u_56 = p_u_23.picture(v_u_28 * 3.4, v_u_4.SakuraBloom, v_u_26, 0.12)
			p_u_23.add(p_u_24, v_u_56, function()
				-- upvalues: (copy) v_u_54, (copy) v_u_28, (ref) v_u_33
				return v_u_54.cf * CFrame.new(0, v_u_28 * -0.3, 0) * CFrame.Angles(0, -v_u_33, 0)
			end)
			p_u_23.fadeFromBehind(p_u_24, v_u_56, 0.5)
			local v_u_57 = -1
			local v58 = p_u_24.ticks
			local function v61()
				-- upvalues: (ref) v_u_32, (ref) v_u_57, (copy) v_u_28, (copy) v_u_56
				local v59 = v_u_32 - v_u_57
				if math.abs(v59) >= 0.01 then
					v_u_57 = v_u_32
					local v60 = v_u_28 * 3.4 * (v_u_32 * 0.3 + 1)
					v_u_56.Size = Vector3.new(v60, 0.05, v60)
				end
			end
			table.insert(v58, v61)
			local v_u_67 = p_u_23.group(p_u_24, function(_, p62)
				-- upvalues: (copy) v_u_48, (copy) v_u_28
				local v63 = v_u_48.cf * CFrame.new(0, 0, v_u_28 * 0.25)
				local v64 = CFrame.Angles
				local v65 = p62 * 0.9
				local v66 = math.sin(v65) * 5 + -58
				return v63 * v64(0, 0, (math.rad(v66)))
			end)
			local v68, v_u_69 = v_u_16(v_u_28 * 3)
			local v_u_70 = {}
			local v_u_71 = nil
			if v68 then
				p_u_23.add(p_u_24, v68, function()
					-- upvalues: (copy) v_u_67, (copy) v_u_69
					return v_u_67.cf * v_u_69
				end)
				table.insert(v_u_70, v68)
				v_u_71 = v68:FindFirstChildOfClass("SurfaceAppearance")
			else
				local v72 = p_u_23.bar
				local v73 = v_u_28 * 2.1
				local v74 = v_u_28 * 0.2
				local v75 = v_u_28 * 0.05
				local v76 = v72(Vector3.new(v73, v74, v75), v_u_7, 0, Enum.Material.Metal)
				p_u_23.add(p_u_24, v76, function()
					-- upvalues: (copy) v_u_67, (copy) v_u_28
					return v_u_67.cf * CFrame.new(v_u_28 * 0.45, 0, 0)
				end)
				local v77 = p_u_23.bar
				local v78 = v_u_28 * 0.08
				local v79 = v_u_28 * 0.45
				local v80 = v_u_28 * 0.45
				local v81 = v77(Vector3.new(v78, v79, v80), v_u_26, 0)
				p_u_23.add(p_u_24, v81, function()
					-- upvalues: (copy) v_u_67, (copy) v_u_28
					return v_u_67.cf * CFrame.new(v_u_28 * -0.62, 0, 0)
				end)
				local v82 = p_u_23.bar
				local v83 = v_u_28 * 0.75
				local v84 = v_u_28 * 0.14
				local v85 = v_u_28 * 0.14
				local v86 = v82(Vector3.new(v83, v84, v85), v_u_8, 0, Enum.Material.SmoothPlastic)
				p_u_23.add(p_u_24, v86, function()
					-- upvalues: (copy) v_u_67, (copy) v_u_28
					return v_u_67.cf * CFrame.new(v_u_28 * -1.05, 0, 0)
				end)
				v_u_70 = { v76, v81, v86 }
			end
			local v_u_87 = not v_u_71 and 0 or v_u_71.EmissiveStrength
			if v_u_71 then
				v_u_71.EmissiveTint = v_u_26
			end
			local v_u_88 = v_u_22(v_u_70[1], v_u_28, p_u_24.fx, v_u_26)
			v_u_88.Speed = NumberRange.new(1 * p_u_24.fx, 3 * p_u_24.fx)
			local v_u_89 = v_u_32
			local v_u_90 = v_u_35
			local v_u_91 = {}
			for v92, v93 in v_u_70 do
				v_u_91[v92] = v93.Transparency
			end
			local v_u_94 = 0
			local v95 = p_u_24.ticks
			local function v101()
				-- upvalues: (ref) v_u_90, (copy) v_u_67, (ref) v_u_89, (ref) v_u_94, (copy) v_u_88, (copy) v_u_29, (ref) v_u_70, (copy) v_u_91, (ref) v_u_71, (copy) v_u_87
				v_u_90 = v_u_67.cf.Position
				if v_u_89 == v_u_94 then
					return
				elseif v_u_89 > 0 then
					local v96 = v_u_89 - v_u_94
					if math.abs(v96) >= 0.005 then
						v_u_94 = v_u_89
						v_u_88.Rate = v_u_89 * 45 * v_u_29
						for v99, v100 in v_u_70 do
							v100.Transparency = v_u_91[v99] + (0.88 - v_u_91[v99]) * v_u_89
						end
						if v_u_71 then
							v_u_71.EmissiveStrength = v_u_87 * (v_u_89 * 1.5 + 1)
						end
					end
				else
					v_u_94 = v_u_89
					v_u_88.Rate = v_u_89 * 45 * v_u_29
					for v99, v100 in v_u_70 do
						v100.Transparency = v_u_91[v99] + (0.88 - v_u_91[v99]) * v_u_89
					end
					if v_u_71 then
						v_u_71.EmissiveStrength = v_u_87 * (v_u_89 * 1.5 + 1)
					end
					return
				end
			end
			table.insert(v95, v101)
			for v102 = 0, 2 do
				local v103 = p_u_23.ball(v_u_28 * 0.12, v_u_5, 1)
				local v_u_104 = v102 * 3.141592653589793 * 2 / 3
				p_u_23.add(p_u_24, v103, function(p105, p106)
					-- upvalues: (ref) v_u_89, (copy) v_u_104, (copy) v_u_28
					local v107 = p106 * (v_u_89 * 1.6 + 1.6) + v_u_104
					local v108 = (v_u_89 * 1.3 + 2.1) * v_u_28
					local v109 = p106 * 0.8 + v_u_104 * 1.7
					local v110 = (math.sin(v109) * 1.25 + -0.9) * v_u_28
					local v111 = CFrame.new
					local v112 = p105.Position
					local v113 = math.cos(v107) * v108
					local v114 = math.sin(v107) * v108
					return v111(v112 + Vector3.new(v113, v110, v114))
				end)
				local v_u_115 = v_u_22(v103, v_u_28, p_u_24.fx, v_u_26)
				local v116 = p_u_24.ticks
				table.insert(v116, function()
					-- upvalues: (copy) v_u_115, (ref) v_u_89, (copy) v_u_29
					v_u_115.Rate = (v_u_89 * 16 + 6) * v_u_29
				end)
				p_u_23.tail(v103, v_u_5, v_u_26, v_u_28 * 0.12, 0.45)
			end
			for v_u_117 = 1, 8 do
				local v118 = p_u_23.bar
				local v119 = v_u_28 * 0.04
				local v120 = v_u_28 * 0.13
				local v121 = v_u_28 * 0.7
				local v122 = v118(Vector3.new(v119, v120, v121), v_u_5, 0)
				p_u_23.add(p_u_24, v122, function(p123, p124)
					-- upvalues: (copy) v_u_117, (ref) v_u_89, (copy) v_u_28
					local v125 = -p124 * 2.3 + v_u_117 * 3.141592653589793 * 2 / 8
					local v126 = (v_u_89 * 1.4 + 1.85) * v_u_28
					local v127 = p124 * 2 + v_u_117 * 1.3
					local v128 = math.sin(v127) * 0.18 + 0.35
					local v129 = v_u_89 * 0.4
					local v130 = v_u_117 * 2.1
					local v131 = (v128 + v129 * math.sin(v130)) * v_u_28
					local v132 = p123.Position
					local v133 = math.cos(v125) * v126
					local v134 = math.sin(v125) * v126
					local v135 = v132 + Vector3.new(v133, v131, v134)
					local v136 = math.sin(v125)
					local v137 = -math.cos(v125)
					local v138 = Vector3.new(v136, 0, v137)
					return CFrame.lookAt(v135, v135 + v138) * CFrame.Angles(0, 0, v125 * 2)
				end)
				p_u_23.tail(v122, v_u_26, v_u_6, v_u_28 * 0.1, 0.22)
			end
			p_u_23.particles(p_u_24, "AuraMode", v_u_26, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end