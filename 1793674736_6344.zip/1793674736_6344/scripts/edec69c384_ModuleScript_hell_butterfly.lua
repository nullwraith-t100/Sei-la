local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({ v_u_7.HellWings, v_u_7.HellLock, v_u_7.EclipseChain })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FFD21F")
local v_u_10 = Color3.fromHex("141414")
local v_u_11 = Color3.fromRGB(255, 140, 20)
local v_u_12 = Color3.fromRGB(255, 240, 170)
local v_u_13 = Color3.fromRGB(6, 4, 10)
local v_u_14 = Color3.fromRGB(255, 226, 150)
local v15 = Color3.fromRGB(255, 214, 47)
local v_u_16 = Color3.new(v15.R * 1.9, v15.G * 1.9, v15.B * 1.9)
local v_u_17 = Enum.Material.SmoothPlastic
local v_u_18 = Enum.ParticleFlipbookLayout.Grid2x2
local function v_u_37(p19, p20, p21, p22, p23) -- name: picture
	-- upvalues: (copy) v_u_4
	local v24 = Color3.new
	local v25 = p22.R
	local v26 = math.min(v25, 1)
	local v27 = p22.G
	local v28 = math.min(v27, 1)
	local v29 = p22.B
	local v30 = v24(v26, v28, (math.min(v29, 1)))
	local v31 = v_u_4.part
	local v32 = p20 * 2
	local v33 = p20 * 2
	local v34 = v31(Vector3.new(v32, 0.05, v33), p19, v30, {
		["transparency"] = 1
	})
	for _, v35 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v36 = Instance.new("Decal")
		v36.Face = v35
		v36.Texture = p21
		v36.Color3 = p22
		v36.Transparency = p23
		v36.Parent = v34
	end
	return v34
end
local function v_u_41(p38, p39) -- name: setAlpha
	for _, v40 in p38:GetChildren() do
		if not v40:IsA("Decal") then
			continue
		end
		v40.Transparency = p39
	end
end
local function v_u_49(p42, p43) -- name: faceCam
	-- upvalues: (copy) v_u_3
	local v44 = v_u_3.CurrentCamera
	local v45
	if v44 then
		local v46 = v44.CFrame.Position - p42
		v45 = v46.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v46.Unit
	else
		v45 = Vector3.new(0, 0, 1)
	end
	local v47 = p43 - v45 * p43:Dot(v45)
	if v47.Magnitude < 0.001 then
		v47 = Vector3.new(0, 1, 0) - v45 * v45.Y
	end
	local v48 = (v47.Magnitude < 0.001 and Vector3.new(1, 0, 0) or v47).Unit
	return CFrame.fromMatrix(p42, v48:Cross(v45), v48, v45)
end
local v_u_50 = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
local function v_u_56(p51, p52) -- name: emitter
	-- upvalues: (copy) v_u_50
	local v53 = Instance.new("ParticleEmitter")
	v53.Texture = p52.texture
	local v54 = p52.grid
	if v54 then
		v53.FlipbookLayout = v54
		if p52.looped then
			v53.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v53.FlipbookFramerate = NumberRange.new(10, 16)
			v53.FlipbookStartRandom = true
		else
			v53.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
	end
	v53.Color = p52.color
	v53.Size = p52.size
	v53.Transparency = p52.alpha or v_u_50
	v53.Lifetime = p52.life
	v53.Speed = p52.speed
	v53.SpreadAngle = p52.spread or Vector2.new(180, 180)
	local v55
	if p52.front then
		v55 = Enum.NormalId.Front
	else
		v55 = Enum.NormalId.Top
	end
	v53.EmissionDirection = v55
	v53.LightEmission = p52.light or 0
	v53.LightInfluence = 0
	v53.Acceleration = p52.accel or Vector3.new(0, 0, 0)
	v53.Drag = p52.drag or 0
	v53.Rotation = NumberRange.new(-35, 35)
	v53.RotSpeed = p52.spin or NumberRange.new(-30, 30)
	v53.Rate = p52.rate or 0
	v53.ZOffset = p52.z or 0
	if p52.box then
		v53.Shape = Enum.ParticleEmitterShape.Box
		v53.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	end
	v53.Parent = p51
	return v53
end
local function v_u_58(p57) -- name: swell
	return NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.15, p57),
		NumberSequenceKeypoint.new(0.8, p57),
		NumberSequenceKeypoint.new(1, 0)
	})
end
local function v_u_64(p59, p60, p61, p62, p63) -- name: wings
	-- upvalues: (copy) v_u_7, (copy) v_u_18, (copy) v_u_58
	return {
		["texture"] = nil,
		["grid"] = nil,
		["looped"] = true,
		["color"] = nil,
		["size"] = nil,
		["alpha"] = nil,
		["life"] = nil,
		["speed"] = nil,
		["drag"] = 2.5,
		["accel"] = Vector3.new(0, 2, 0),
		["light"] = nil,
		["z"] = 1,
		["texture"] = v_u_7.HellWings,
		["grid"] = v_u_18,
		["color"] = ColorSequence.new(p59),
		["size"] = v_u_58(p60),
		["alpha"] = NumberSequence.new(0),
		["life"] = NumberRange.new(p62 * 0.7, p62),
		["speed"] = NumberRange.new(p61 * 0.5, p61),
		["light"] = p63 and 0.6 or 0
	}
end
local function v_u_102(p65) -- name: butterfly
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (copy) v_u_4, (copy) v_u_17, (copy) v_u_9
	local v66 = v_u_2:FindFirstChild("EyePieces")
	if v66 then
		v66 = v66:FindFirstChild("w6_hell_butterfly")
	end
	if v66 and v66:IsA("MeshPart") then
		local v_u_67 = v66:Clone()
		v_u_67.Anchored = true
		v_u_67.CanCollide = false
		v_u_67.CanQuery = false
		v_u_67.CanTouch = false
		v_u_67.CastShadow = false
		v_u_67.Massless = true
		local v68 = v66.Size.X
		local v69 = v66.Size.Y
		local v70 = v66.Size.Z
		local v71 = math.max(v68, v69, v70, 0.01)
		local v_u_72 = v66.Size * (p65 / v71)
		v_u_67.Size = v_u_72
		if not v_u_67:FindFirstChildWhichIsA("SurfaceAppearance") then
			v_u_67.Color = v_u_10
		end
		v_u_67.Parent = v_u_4.folder()
		return {
			["parts"] = { v_u_67 },
			["place"] = function(p73, p74) -- name: place
				-- upvalues: (copy) v_u_67, (copy) v_u_72
				local v75 = v_u_67
				local v76 = v_u_72.X * (1 - p74 * 0.62)
				local v77 = v_u_72.Y
				local v78 = v_u_72.Z
				v75.Size = Vector3.new(v76, v77, v78)
				v_u_67.CFrame = p73 * CFrame.Angles(0, 3.141592653589793, 0)
			end,
			["fade"] = function(p79) -- name: fade
				-- upvalues: (copy) v_u_67
				v_u_67.Transparency = p79
			end
		}
	else
		local v_u_80 = p65 * 0.5
		local v81 = p65 * 0.62
		local v82 = {
			["material"] = v_u_17
		}
		local v_u_83 = v_u_4.part(Vector3.new(v_u_80, v81, 0.08), CFrame.identity, v_u_10, v82)
		local v84 = {
			["material"] = v_u_17
		}
		local v_u_85 = v_u_4.part(Vector3.new(v_u_80, v81, 0.08), CFrame.identity, v_u_10, v84)
		local v86 = v_u_4.part
		local v87 = v_u_80 * 1.06
		local v88 = v81 * 1.08
		local v_u_89 = v86(Vector3.new(v87, v88, 0.04), CFrame.identity, v_u_9)
		local v90 = v_u_4.part
		local v91 = v_u_80 * 1.06
		local v92 = v81 * 1.08
		local v_u_93 = v90(Vector3.new(v91, v92, 0.04), CFrame.identity, v_u_9)
		local v_u_94 = {
			v_u_83,
			v_u_85,
			v_u_89,
			v_u_93
		}
		return {
			["parts"] = v_u_94,
			["place"] = function(p95, p96) -- name: place
				-- upvalues: (copy) v_u_80, (copy) v_u_83, (copy) v_u_85, (copy) v_u_89, (copy) v_u_93
				local v97 = p96 * 1.25
				local v98 = p95 * CFrame.Angles(0, -v97, 0) * CFrame.new(-v_u_80 / 2, 0, 0)
				local v99 = p95 * CFrame.Angles(0, v97, 0) * CFrame.new(v_u_80 / 2, 0, 0)
				v_u_83.CFrame = v98
				v_u_85.CFrame = v99
				v_u_89.CFrame = v98 * CFrame.new(0, 0, 0.05)
				v_u_93.CFrame = v99 * CFrame.new(0, 0, 0.05)
			end,
			["fade"] = function(p100) -- name: fade
				-- upvalues: (copy) v_u_94
				for _, v101 in v_u_94 do
					v101.Transparency = p100
				end
			end
		}
	end
end
local function v_u_108(p103, p104) -- name: facing
	local v105 = p104.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p104.Unit
	local v106 = v105.Y
	local v107 = math.abs(v106) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p103, p103 + v105, v107) * CFrame.Angles(-1.5707963267948966, 0, 0)
end
local function v_u_125(p109, p_u_110, p_u_111, p_u_112) -- name: lockFlash
	-- upvalues: (copy) v_u_3, (copy) v_u_37, (copy) v_u_108, (copy) v_u_7, (copy) v_u_16, (copy) v_u_1, (copy) v_u_41
	local v113 = v_u_3.CurrentCamera
	local v114
	if v113 then
		local v115 = v113.CFrame.Position - p109
		v114 = v115.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v115.Unit
	else
		v114 = Vector3.new(0, 0, 1)
	end
	local v_u_116 = v_u_37(v_u_108(p109 + v114 * 0.6, v114), p_u_110, v_u_7.HellLock, v_u_16, 0)
	v_u_1:AddItem(v_u_116, p_u_112 + 0.1)
	local v_u_117 = os.clock()
	return function()
		-- upvalues: (copy) v_u_117, (copy) p_u_112, (copy) v_u_116, (copy) p_u_110, (copy) p_u_111, (ref) v_u_41
		local v118 = (os.clock() - v_u_117) / p_u_112
		local v119 = math.clamp(v118, 0, 1)
		local v120 = v_u_116
		local v121 = p_u_110 + (p_u_111 - p_u_110) * (1 - (1 - v119) ^ 3)
		local v122 = math.max(v121, 0.03)
		local v123 = v122 * 2
		local v124 = v122 * 2
		v120.Size = Vector3.new(v123, 0.05, v124)
		v_u_41(v_u_116, v119 ^ 2)
		if v119 >= 1 then
			v_u_116:Destroy()
		end
		return v119 < 1
	end
end
return function(p_u_126)
	-- upvalues: (copy) v_u_125, (copy) v_u_4, (copy) v_u_9, (copy) v_u_1, (copy) v_u_102, (copy) v_u_37, (copy) v_u_7, (copy) v_u_11, (copy) v_u_56, (copy) v_u_12, (copy) v_u_49, (copy) v_u_3, (copy) v_u_64, (copy) v_u_10, (copy) v_u_8, (copy) v_u_6, (copy) v_u_17, (copy) v_u_13, (copy) v_u_2, (copy) v_u_16, (copy) v_u_14
	local v167 = {
		["hell_butterfly_a"] = {
			["cast"] = nil,
			["shot"] = nil,
			["weave"] = 0.9,
			["impact"] = nil,
			["hit"] = nil,
			["cast"] = function(p127) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (copy) p_u_126, (ref) v_u_8, (ref) v_u_64, (ref) v_u_10, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1
				local v128 = p127.size
				local v129 = p127.eye + p127.dir * 1.2
				v_u_4.flash(v129, v_u_9, 3 * v128, 0.12)
				p_u_126.pop(v129, v_u_8, 1.1 * v128, 0.3 * v128, 0.1)
				if not p127.lite then
					local v130 = v_u_64(v_u_10, 0.45 * v128, 6 * v128, 0.6)
					local v131 = Instance.new("Attachment")
					v131.Parent = v_u_3.Terrain
					v131.WorldPosition = v129
					v_u_56(v131, v130):Emit(2)
					v_u_1:AddItem(v131, v130.life.Max + 0.3)
				end
			end,
			["shot"] = function(p132, p133) -- name: dartShot
				-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_102, (ref) v_u_37, (ref) v_u_7, (copy) p_u_126, (ref) v_u_11, (ref) v_u_56, (ref) v_u_12, (ref) v_u_49, (ref) v_u_3
				local v_u_134 = p132.size
				local v_u_135 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p133, v_u_9, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_135, 3)
				local v_u_136 = v_u_102(2.4 * v_u_134)
				local v_u_137 = table.clone(v_u_136.parts)
				local v_u_138
				if p132.lite then
					v_u_138 = nil
				else
					v_u_138 = v_u_37(p133, 1.6 * v_u_134, v_u_7.Glow, v_u_9, 0.6)
					table.insert(v_u_137, v_u_138)
				end
				for _, v139 in v_u_137 do
					v_u_1:AddItem(v139, 3)
				end
				p_u_126.streak(v_u_135, v_u_9, v_u_11, 0.7 * v_u_134, p132.lite and 0.1 or 0.22)
				local v_u_140
				if p132.lite then
					v_u_140 = nil
				else
					v_u_140 = v_u_56(v_u_135, {
						["texture"] = nil,
						["color"] = nil,
						["size"] = nil,
						["life"] = nil,
						["speed"] = nil,
						["accel"] = Vector3.new(0, -6, 0),
						["light"] = 0.6,
						["rate"] = 34,
						["texture"] = v_u_7.Glow,
						["color"] = ColorSequence.new(v_u_12, v_u_9),
						["size"] = NumberSequence.new(0.3 * v_u_134, 0),
						["life"] = NumberRange.new(0.35, 0.6),
						["speed"] = NumberRange.new(0.5, 2)
					})
				end
				local v_u_141 = false
				return {
					["place"] = function(p142, p143) -- name: place
						-- upvalues: (copy) v_u_134, (copy) v_u_135, (copy) v_u_136, (ref) v_u_49, (ref) v_u_138, (ref) v_u_3, (ref) p_u_126
						local v144 = p142.Position
						local v145 = Vector3.new(0, 0.35, 0) * v_u_134
						local v146 = p143 * 13
						local v147 = v144 + v145 * math.sin(v146)
						v_u_135.CFrame = CFrame.new(v147) * p142.Rotation
						local v148 = p143 * 34
						local v149 = math.sin(v148) * 0.5 + 0.5
						v_u_136.place(v_u_49(v147, p142.LookVector + Vector3.new(0, 0.2, 0)), v149)
						local v150 = v_u_138
						if v150 then
							local v151 = v_u_3.CurrentCamera
							local v152
							if v151 then
								local v153 = v151.CFrame.Position - v147
								v152 = v153.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v153.Unit
							else
								v152 = Vector3.new(0, 0, 1)
							end
							v150.CFrame = p_u_126.facing(v147 - v152 * 0.3, v152)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_141, (ref) v_u_140, (copy) v_u_135, (ref) v_u_1, (copy) v_u_137
						if not v_u_141 then
							v_u_141 = true
							local v154 = v_u_140
							if v154 then
								v154.Enabled = false
							end
							local v155 = v_u_135:FindFirstChildWhichIsA("PointLight")
							if v155 then
								v155:Destroy()
							end
							v_u_1:AddItem(v_u_135, 0.7)
							for _, v156 in v_u_137 do
								v156:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p157, p158) -- name: dartImpact
				-- upvalues: (ref) v_u_64, (ref) v_u_10, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1, (ref) v_u_9, (copy) p_u_126, (ref) v_u_125, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7
				local v159 = p157.size
				local v160 = v_u_64(v_u_10, 0.75 * v159, 12 * v159, 1)
				local v161 = p157.lite and 3 or 8
				local v162 = Instance.new("Attachment")
				v162.Parent = v_u_3.Terrain
				v162.WorldPosition = p158
				v_u_56(v162, v160):Emit(v161)
				v_u_1:AddItem(v162, v160.life.Max + 0.3)
				if not p157.lite then
					local v163 = v_u_64(v_u_9, 0.55 * v159, 9 * v159, 0.8, true)
					local v164 = Instance.new("Attachment")
					v164.Parent = v_u_3.Terrain
					v164.WorldPosition = p158
					v_u_56(v164, v163):Emit(3)
					v_u_1:AddItem(v164, v163.life.Max + 0.3)
					local v165 = 0.8 * v159
					local v166 = 2.8 * v159
					p_u_126.runNow((v_u_125(p158, v165, v166, 0.28)))
				end
				p_u_126.pop(p158, v_u_9, 1.2 * v159, 4.2 * v159, 0.2, 0.35)
				p_u_126.pop(p158, v_u_8, 0.8 * v159, 2 * v159, 0.12)
				p_u_126.burst("Impact", p158, v_u_9, 0.8 * v159)
				v_u_4.ring(p_u_126.ground(p158), v_u_9, p157.ability.radius * 0.8 * v159, 0.3, v_u_7.Ring)
				p_u_126.hitSound(p158)
			end,
			["hit"] = p_u_126.simpleHit(v_u_9, 0.6)
		}
	}
	local v_u_168 = {}
	setmetatable(v_u_168, {
		["__mode"] = "k"
	})
	local function v_u_218(p169, p170) -- name: pourSwarm
		-- upvalues: (copy) p_u_126, (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_3, (ref) v_u_56, (ref) v_u_64, (ref) v_u_10, (ref) v_u_102, (ref) v_u_49
		local v171 = p169.ability.radius
		local v_u_172 = p169.ability.freeze or 2.5
		local v_u_173 = p_u_126.ground(p170, 0)
		local v_u_174 = v_u_172 + 2
		local v175 = v_u_4.part
		local v176 = v171 * 1.7
		local v177 = v171 * 1.7
		local v178 = v175(Vector3.new(v176, 0.4, v177), CFrame.new(v_u_173 + Vector3.new(0, 0.6, 0)), v_u_9, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v178, v_u_174)
		local v_u_179 = {
			["g"] = nil,
			["holder"] = nil,
			["flies"] = nil,
			["emitters"] = nil,
			["pinned"] = 0,
			["over"] = false,
			["g"] = v_u_173,
			["holder"] = v178,
			["flies"] = {},
			["emitters"] = {}
		}
		local v180 = Instance.new("Attachment")
		v180.Parent = v_u_3.Terrain
		v180.WorldPosition = v_u_173 + Vector3.new(0, 16, 0)
		local v181 = v_u_56(v180, (v_u_64(v_u_10, 0.8, 20, 0.9)))
		v181.EmissionDirection = Enum.NormalId.Bottom
		v181.SpreadAngle = Vector2.new(22, 22)
		v181.Drag = 0.5
		v181:Emit(p169.lite and 6 or 18)
		v_u_1:AddItem(v180, 1.3)
		if p169.lite then
			return v_u_179
		end
		local v_u_182 = os.clock()
		for v_u_183 = 1, 10 do
			local v_u_184 = v_u_102(1.7)
			for _, v185 in v_u_184.parts do
				v_u_1:AddItem(v185, v_u_174)
			end
			local v186 = v_u_179.flies
			table.insert(v186, v_u_184)
			local v_u_187 = v_u_183 / 10 * 3.141592653589793 * 2
			local v_u_188 = v171 * (v_u_183 * 7 % 5 * 0.35 / 4 + 0.55)
			local v_u_189 = v_u_183 % 3 * 0.9 + 1.6
			local v_u_190 = v_u_173 + Vector3.new(0, 18, 0)
			p_u_126.runNow(function()
				-- upvalues: (copy) v_u_182, (copy) v_u_187, (copy) v_u_173, (copy) v_u_188, (copy) v_u_189, (copy) v_u_179, (copy) v_u_183, (ref) v_u_190, (copy) v_u_184, (ref) v_u_49, (copy) v_u_172, (copy) v_u_174
				local v191 = os.clock() - v_u_182
				local v192
				if v191 < 0.45 then
					local v193 = 1 - (1 - v191 / 0.45) ^ 2
					local v194 = v_u_187 + v193 * 4
					local v195 = v_u_173
					local v196 = math.cos(v194) * v_u_188 * v193
					local v197 = 18 - (18 - v_u_189) * v193
					local v198 = math.sin(v194) * v_u_188 * v193
					v192 = v195 + Vector3.new(v196, v197, v198)
				elseif v_u_179.over then
					local v199 = v_u_187 + 4 + (v191 - 0.45) * 1.6
					local v200 = v_u_190
					local v201 = math.cos(v199)
					local v202 = math.sin(v199)
					v192 = v200 + Vector3.new(v201, 3, v202) * 0.4
				else
					local v203 = v_u_187 + 4 + (v191 - 0.45) * 1.6
					local v204 = v_u_173
					local v205 = math.cos(v203) * v_u_188
					local v206 = v_u_189
					local v207 = v191 * 5 + v_u_183
					local v208 = v206 + math.sin(v207) * 0.5
					local v209 = math.sin(v203) * v_u_188
					v192 = v204 + Vector3.new(v205, v208, v209)
				end
				local v210 = v192 - v_u_190
				v_u_190 = v192
				local v211 = v210.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v210.Unit
				local v212 = v_u_184.place
				local v213 = v_u_49(v192, v211 + Vector3.new(0, 0.3, 0))
				local v214 = v191 * 26 + v_u_183
				v212(v213, math.sin(v214) * 0.5 + 0.5)
				if v_u_179.over then
					local v215 = (v191 - v_u_172 - 0.45) / 0.5
					local v216 = math.clamp(v215, 0, 1)
					v_u_184.fade(v216)
					if v216 >= 1 then
						for _, v217 in v_u_184.parts do
							v217:Destroy()
						end
						return false
					end
				end
				return v191 < v_u_174
			end)
		end
		return v_u_179
	end
	v167.hell_butterfly_e = {
		["cast"] = function(p219) -- name: cast
			-- upvalues: (copy) p_u_126, (ref) v_u_9, (ref) v_u_64, (ref) v_u_10, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1
			p_u_126.skillCast(p219, v_u_9)
			if not p219.lite then
				local v220 = p219.eye + p219.dir * 1.2
				local v221 = v_u_64(v_u_10, 0.6, 8, 0.8)
				local v222 = Instance.new("Attachment")
				v222.Parent = v_u_3.Terrain
				v222.WorldPosition = v220
				v_u_56(v222, v221):Emit(4)
				v_u_1:AddItem(v222, v221.life.Max + 0.3)
			end
		end,
		["windup"] = function(p223, p224, p225) -- name: windup
			-- upvalues: (copy) v_u_168, (copy) v_u_218, (copy) p_u_126, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12
			v_u_168[p223] = v_u_218(p223, p224)
			local v226 = p223.ability.radius
			local v227 = p223.ability.freeze or 2.5
			local v228 = p_u_126.ground(p224, 0)
			p_u_126.sigil(CFrame.new(v228 + Vector3.new(0, 0.2, 0)), v226, v_u_9, v_u_7.Ring, p225 + v227, 0.5)
			p_u_126.sigil(CFrame.new(v228 + Vector3.new(0, 0.25, 0)), v226 * 0.62, v_u_12, v_u_7.Ring, p225 + v227, -0.8)
			p_u_126.mark(v228, v_u_9, v226 * 1.05, p225 + v227 + 0.3, v_u_7.Glow, 0.55)
		end,
		["land"] = function(p_u_229, p230) -- name: land
			-- upvalues: (copy) v_u_168, (copy) v_u_218, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (copy) p_u_126, (ref) v_u_56, (ref) v_u_64, (ref) v_u_10, (ref) v_u_12, (ref) v_u_6, (ref) v_u_3, (ref) v_u_1
			local v_u_231 = v_u_168[p_u_229] or v_u_218(p_u_229, p230)
			v_u_168[p_u_229] = v_u_231
			local v232 = p_u_229.ability.radius
			local v233 = p_u_229.ability.freeze or 2.5
			local v_u_234 = v_u_231.g
			v_u_4.flash(v_u_234 + Vector3.new(0, 2, 0), v_u_9, v232 * 0.9, 0.25)
			v_u_4.ring(v_u_234, v_u_9, v232 * 1.2, 0.4, v_u_7.Ring)
			p_u_126.burst("Shockwave", v_u_234 + Vector3.new(0, 0.3, 0), v_u_9, v232 / 18)
			local v235 = v_u_56(v_u_231.holder, (v_u_64(v_u_10, 0.6, 2.5, 1.8)))
			local v236
			if p_u_229.lite then
				v236 = v232 * 0.3
			else
				v236 = v232 * 0.9
			end
			v235.Rate = v236
			v235.Shape = Enum.ParticleEmitterShape.Box
			v235.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			local v237 = v_u_231.emitters
			table.insert(v237, v235)
			if not p_u_229.lite then
				local v238 = v_u_231.emitters
				local v239 = v_u_56(v_u_231.holder, {
					["texture"] = nil,
					["color"] = nil,
					["size"] = nil,
					["life"] = nil,
					["speed"] = nil,
					["spread"] = nil,
					["light"] = 0.6,
					["rate"] = nil,
					["box"] = true,
					["texture"] = v_u_7.Glow,
					["color"] = ColorSequence.new(v_u_12, v_u_9),
					["size"] = NumberSequence.new(0.35, 0),
					["life"] = NumberRange.new(0.8, 1.3),
					["speed"] = NumberRange.new(2, 5),
					["spread"] = Vector2.new(15, 15),
					["rate"] = v232 * 1.4
				})
				table.insert(v238, v239)
			end
			v_u_6.play("Hit", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v_u_234
			})
			if p_u_229.mine then
				v_u_4.shake(0.35, 0.25)
			end
			p_u_126.after(v233, function()
				-- upvalues: (copy) v_u_231, (copy) v_u_234, (ref) v_u_64, (ref) v_u_10, (copy) p_u_229, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1
				v_u_231.over = true
				for _, v240 in v_u_231.emitters do
					v240.Enabled = false
				end
				local v241 = v_u_234 + Vector3.new(0, 2, 0)
				local v242 = v_u_64(v_u_10, 0.7, 14, 1.1)
				local v243 = p_u_229.lite and 4 or 12
				local v244 = Instance.new("Attachment")
				v244.Parent = v_u_3.Terrain
				v244.WorldPosition = v241
				v_u_56(v244, v242):Emit(v243)
				v_u_1:AddItem(v244, v242.life.Max + 0.3)
			end)
		end,
		["hit"] = function(p245, p_u_246, p247) -- name: hit
			-- upvalues: (copy) v_u_168, (copy) p_u_126, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_102, (ref) v_u_49
			local v248 = v_u_168[p245]
			local v_u_249 = p245.ability.freeze or 2.5
			local v250
			if v248 then
				v248.pinned = v248.pinned + 1
				v250 = v248.pinned
			else
				v250 = 1
			end
			if p245.lite or v250 > 10 then
				p_u_126.bindHit(p245, p_u_246, p247, v_u_9, v_u_10)
			else
				local v_u_251 = p_u_126.ground(p_u_246, 0)
				local v252 = v_u_249 + 1
				local v_u_253 = v_u_4.part(Vector3.new(0.3, 7, 0.3), CFrame.new(p_u_246 + Vector3.new(0, 12, 0)), v_u_9)
				local v_u_254 = v_u_4.part(Vector3.new(0.12, 7.2, 0.12), CFrame.new(p_u_246 + Vector3.new(0, 12, 0)), v_u_8)
				v_u_1:AddItem(v_u_253, v252)
				v_u_1:AddItem(v_u_254, v252)
				p_u_126.animate(0.1, 0, function(p255)
					-- upvalues: (copy) p_u_246, (copy) v_u_253, (copy) v_u_254
					local v256 = p_u_246.Y + 12 - 10.5 * p255 * p255
					v_u_253.CFrame = CFrame.new(p_u_246.X, v256, p_u_246.Z)
					v_u_254.CFrame = v_u_253.CFrame
				end)
				p_u_126.after(0.1, function()
					-- upvalues: (ref) v_u_4, (copy) p_u_246, (ref) v_u_9, (copy) v_u_251, (ref) v_u_7
					v_u_4.flash(p_u_246, v_u_9, 3.5, 0.15)
					v_u_4.ring(v_u_251, v_u_9, 3.2, 0.3, v_u_7.Ring)
				end)
				v_u_1:AddItem(p_u_126.sigil(CFrame.new(v_u_251 + Vector3.new(0, 0.15, 0)), 2.4, v_u_9, v_u_7.Ring, v_u_249, 1.5), v252)
				for v_u_257 = -1, 1, 2 do
					local v_u_258 = v_u_102(1.3)
					for _, v259 in v_u_258.parts do
						v_u_1:AddItem(v259, v252)
					end
					local v260 = v_u_257 * 0.7
					local v_u_261 = p_u_246 + Vector3.new(v260, 1.1, 0)
					local v_u_262 = os.clock()
					p_u_126.runNow(function()
						-- upvalues: (copy) v_u_262, (copy) v_u_249, (copy) v_u_261, (copy) v_u_257, (copy) v_u_258, (ref) v_u_49
						local v263 = os.clock() - v_u_262
						if v_u_249 >= v263 then
							local v264 = v263 / 0.3
							local v265 = v_u_261 + Vector3.new(0, 3, 0) * (1 - math.clamp(v264, 0, 1))
							local v266 = v_u_258.place
							local v267 = v_u_49
							local v268 = v_u_257 * 0.4
							local v269 = v267(v265, Vector3.new(0, 1, 0) + Vector3.new(v268, 0, 0))
							local v270 = v263 * 5 + v_u_257
							v266(v269, math.sin(v270) * 0.35 + 0.35)
							return true
						end
						local v271 = (v263 - v_u_249) / 0.5
						local v272 = math.clamp(v271, 0, 1)
						local v273 = v_u_261
						local v274 = v_u_257 * 2
						local v275 = v273 + Vector3.new(v274, 5, 0) * v272
						local v276 = v_u_258.place
						local v277 = v_u_257
						local v278 = v_u_49(v275, Vector3.new(0, 1, 0) + Vector3.new(v277, 0, 0))
						local v279 = v263 * 30
						v276(v278, math.sin(v279) * 0.5 + 0.5)
						v_u_258.fade(v272)
						if v272 < 1 then
							return true
						end
						for _, v280 in v_u_258.parts do
							v280:Destroy()
						end
						return false
					end)
				end
				p_u_126.after(v_u_249, function()
					-- upvalues: (ref) p_u_126, (copy) v_u_253, (copy) v_u_254, (copy) p_u_246, (ref) v_u_9
					p_u_126.animate(0.25, 0, function(p281)
						-- upvalues: (ref) v_u_253, (ref) v_u_254
						v_u_253.Transparency = p281
						v_u_254.Transparency = p281
						if p281 >= 1 then
							v_u_253:Destroy()
							v_u_254:Destroy()
						end
					end)
					p_u_126.burst("Impact", p_u_246, v_u_9, 0.6)
				end)
			end
		end
	}
	local v_u_282 = {}
	setmetatable(v_u_282, {
		["__mode"] = "k"
	})
	local v_u_283 = {}
	local v_u_284 = {}
	local function v_u_295(p285, p286) -- name: placeGate
		-- upvalues: (copy) v_u_283, (copy) v_u_284, (ref) v_u_3
		local v287 = p285.height
		local v288 = p285.frame * CFrame.new(0, -v287 * 1.15 * (1 - p285.rise + p285.sink), 0)
		local v289 = p285.open * 1.8325957145940461
		table.clear(v_u_283)
		table.clear(v_u_284)
		for _, v290 in p285.parts do
			if not v290.p.Parent then
				continue
			end
			local v291
			if v290.door == 0 then
				v291 = v288 * v290.off
			else
				v291 = v288 * CFrame.new(v290.door * p285.doorW, 0, 0) * CFrame.Angles(0, -v290.door * v289, 0) * v290.off
			end
			local v292 = v_u_283
			local v293 = v290.p
			table.insert(v292, v293)
			local v294 = v_u_284
			table.insert(v294, v291)
		end
		if #v_u_283 > 0 then
			v_u_3:BulkMoveTo(v_u_283, v_u_284, Enum.BulkMoveMode.FireCFrameChanged)
		end
		p285.swirl.CFrame = v288 * CFrame.new(0, v287 * 0.5, 0.55) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, p286 * 1.8, 0)
		if p285.lock.Parent then
			p285.lock.CFrame = v288 * CFrame.new(0, v287 * 0.5, -0.8) * CFrame.Angles(-1.5707963267948966, 0, 0)
		end
		p285.holder.CFrame = v288 * CFrame.new(0, v287 * 0.5, 0)
	end
	local function v_u_359(p296, p297, p_u_298) -- name: buildGate
		-- upvalues: (copy) p_u_126, (ref) v_u_4, (ref) v_u_17, (ref) v_u_1, (ref) v_u_10, (ref) v_u_9, (ref) v_u_13, (ref) v_u_7, (ref) v_u_2, (ref) v_u_37, (ref) v_u_16, (copy) v_u_295
		local v299 = p296.ability.radius
		local v300 = v299 / 15
		local v301 = p_u_126.ground(p297, 0)
		local v302 = p_u_126.flatUnit(p296.origin - p297)
		if (p296.origin - p297).Magnitude < 1 then
			v302 = -p296.dir
		end
		local v303 = v301 - v302 * v299 * 0.85
		local v_u_304 = CFrame.lookAt(v303, v303 + v302)
		local v305 = 7.5 * v300
		local v306 = 20 * v300
		local v_u_307 = {}
		local function v319(p308, p309, p310, p311, p312) -- name: add
			-- upvalues: (ref) v_u_4, (copy) v_u_304, (ref) v_u_17, (ref) v_u_1, (copy) p_u_298, (copy) v_u_307
			local v313 = v_u_4.part
			local v314 = v_u_304
			local v315 = {}
			local v316
			if p312 then
				v316 = nil
			else
				v316 = v_u_17
			end
			v315.material = v316
			local v317 = v313(p308, v314, p310, v315)
			if not p312 then
				v317.Reflectance = 0.15
			end
			v_u_1:AddItem(v317, p_u_298)
			local v318 = v_u_307
			table.insert(v318, {
				["p"] = v317,
				["off"] = p309,
				["door"] = p311
			})
			return v317
		end
		local v320 = v305 * 2 + 9 * v300
		local v321 = 1 * v300
		local v322 = 5 * v300
		v319(Vector3.new(v320, v321, v322), CFrame.new(0, 0.5 * v300, 0), v_u_10, 0)
		for v323 = -1, 1, 2 do
			local v324 = v323 * (v305 + 1.3 * v300)
			local v325 = v306 + 2
			v319(Vector3.new(2.6, v325, 2.6) * v300, CFrame.new(v324, (v306 + 2 * v300) / 2, 0), v_u_10, 0)
			local v326 = 0.35 * v300
			local v327 = 0.2 * v300
			v319(Vector3.new(v326, v306, v327), CFrame.new(v324, v306 / 2 + v300, -1.35 * v300), v_u_9, 0, true)
			v319(Vector3.new(1.6, 5.5, 2.4) * v300, CFrame.new(v323 * (v305 + 3.2 * v300), v306 + 5 * v300, 0) * CFrame.Angles(0, 0, -v323 * 0.45), v_u_10, 0)
		end
		local v328 = v305 * 2 + 7 * v300
		local v329 = 2.6 * v300
		local v330 = 3.2 * v300
		v319(Vector3.new(v328, v329, v330), CFrame.new(0, v306 + 2.4 * v300, 0), v_u_10, 0)
		local v331 = v305 * 2 + 7 * v300
		local v332 = 0.35 * v300
		local v333 = 0.2 * v300
		v319(Vector3.new(v331, v332, v333), CFrame.new(0, v306 + 2.4 * v300, -1.65 * v300), v_u_9, 0, true)
		local v334 = v305 * 2
		local v335 = 0.3 * v300
		v319(Vector3.new(v334, v306, v335), CFrame.new(0, v306 / 2, 0.9 * v300), v_u_13, 0, true)
		for _, v336 in { -1, 1 } do
			local v337 = 1 * v300
			local v338 = v319(Vector3.new(v305, v306, v337), CFrame.new(-v336 * v305 / 2, v306 / 2, 0), v_u_10, v336)
			local v339 = Instance.new("Decal")
			v339.Face = Enum.NormalId.Front
			v339.Texture = v_u_7.HellWings
			v339.Color3 = v_u_9
			v339.Transparency = 0.25
			v339.Parent = v338
			local v340 = 0.4 * v300
			local v341 = 0.2 * v300
			v319(Vector3.new(v340, v306, v341), CFrame.new(-v336 * (v305 - 0.25 * v300), v306 / 2, -0.55 * v300), v_u_9, v336, true)
			for _, v342 in { 0.3, 0.7 } do
				local v343 = 0.4 * v300
				local v344 = 0.2 * v300
				v319(Vector3.new(v305, v343, v344), CFrame.new(-v336 * v305 / 2, v306 * v342, -0.55 * v300), v_u_9, v336, true)
			end
		end
		local v345 = v_u_2:FindFirstChild("EyePieces")
		if v345 then
			v345 = v345:FindFirstChild("w6_hell_butterfly")
		end
		if v345 and v345:IsA("MeshPart") then
			local v346 = v345:Clone()
			v346.Anchored = true
			v346.CanCollide = false
			v346.CanQuery = false
			v346.CanTouch = false
			v346.CastShadow = false
			local v347 = v345.Size.X
			local v348 = v345.Size.Y
			local v349 = v345.Size.Z
			local v350 = math.max(v347, v348, v349, 0.01)
			v346.Size = v345.Size * (7.5 * v300 / v350)
			if not v346:FindFirstChildWhichIsA("SurfaceAppearance") then
				v346.Color = v_u_9
			end
			v346.Parent = v_u_4.folder()
			v_u_1:AddItem(v346, p_u_298)
			local v351 = {
				["p"] = nil,
				["off"] = nil,
				["door"] = 0,
				["p"] = v346,
				["off"] = CFrame.new(0, v306 + 6.2 * v300, -0.6 * v300)
			}
			table.insert(v_u_307, v351)
		end
		local v352 = v_u_37(v_u_304, v305 * 0.95, v_u_7.Swirl, v_u_9, 0.45)
		v_u_1:AddItem(v352, p_u_298)
		local v353 = v_u_37(v_u_304, 3.4 * v300, v_u_7.HellLock, v_u_16, 0)
		v_u_1:AddItem(v353, p_u_298)
		local v354 = v_u_4.part
		local v355 = v305 * 1.6
		local v356 = v306 * 0.8
		local v357 = v354(Vector3.new(v355, v356, 1), v_u_304, v_u_13, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v357, p_u_298)
		local v_u_358 = {
			["frame"] = nil,
			["height"] = nil,
			["doorW"] = nil,
			["parts"] = nil,
			["lock"] = nil,
			["swirl"] = nil,
			["holder"] = nil,
			["mouth"] = nil,
			["rise"] = 0,
			["open"] = 0,
			["sink"] = 0,
			["emitters"] = nil,
			["chains"] = 0,
			["born"] = nil,
			["done"] = false,
			["frame"] = v_u_304,
			["height"] = v306,
			["doorW"] = v305,
			["parts"] = v_u_307,
			["lock"] = v353,
			["swirl"] = v352,
			["holder"] = v357,
			["mouth"] = (v_u_304 * CFrame.new(0, v306 * 0.45, -0.6 * v300)).Position,
			["emitters"] = {},
			["born"] = os.clock()
		}
		v_u_295(v_u_358, 0)
		p_u_126.runNow(function()
			-- upvalues: (copy) v_u_358, (ref) v_u_295, (copy) p_u_298
			if v_u_358.done then
				return false
			end
			v_u_295(v_u_358, os.clock() - v_u_358.born)
			return os.clock() - v_u_358.born < p_u_298
		end)
		return v_u_358
	end
	local function v_u_374(p360, p_u_361, p_u_362) -- name: chain
		-- upvalues: (ref) v_u_7, (ref) v_u_14, (ref) v_u_9, (copy) p_u_126
		local v363 = p360.holder
		local v_u_364 = Instance.new("Attachment")
		v_u_364.Parent = v363
		v_u_364.WorldPosition = p360.mouth
		local v_u_365 = Instance.new("Attachment")
		v_u_365.Parent = v363
		v_u_365.WorldPosition = p360.mouth
		local v_u_366 = Instance.new("Beam")
		v_u_366.Attachment0 = v_u_364
		v_u_366.Attachment1 = v_u_365
		v_u_366.Texture = v_u_7.EclipseChain
		v_u_366.TextureMode = Enum.TextureMode.Wrap
		v_u_366.TextureLength = 2.6
		v_u_366.Color = ColorSequence.new(v_u_14, v_u_9)
		v_u_366.LightEmission = 0.25
		v_u_366.LightInfluence = 0
		v_u_366.FaceCamera = true
		v_u_366.Width0 = 1.3
		v_u_366.Width1 = 1.1
		v_u_366.Segments = 1
		v_u_366.Parent = v363
		local v_u_367 = p360.mouth
		p_u_126.animate(0.42, 0, function(p368)
			-- upvalues: (copy) v_u_367, (copy) p_u_361, (copy) p_u_362, (copy) v_u_365, (copy) v_u_366, (copy) v_u_364
			local v369
			if p368 < 0.3 then
				v369 = v_u_367:Lerp(p_u_361, 1 - (1 - p368 / 0.3) ^ 2)
			else
				local v370 = (p368 - 0.3) / 0.7
				v369 = p_u_361:Lerp(v_u_367, p_u_362 * v370 * v370)
			end
			v_u_365.WorldPosition = v369
			local v371 = v_u_366
			local v372 = NumberSequence.new
			local v373 = p368 - 0.75
			v371.Transparency = v372(math.max(v373, 0) / 0.25)
			if p368 >= 1 then
				v_u_366:Destroy()
				v_u_364:Destroy()
				v_u_365:Destroy()
			end
		end)
	end
	v167.hell_butterfly_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p375) -- name: cast
			-- upvalues: (copy) p_u_126, (ref) v_u_9, (ref) v_u_64, (ref) v_u_10, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1, (ref) v_u_125
			p_u_126.skillCast(p375, v_u_9, true)
			if not p375.lite then
				local v376 = p375.eye + p375.dir * 1.3
				local v377 = v_u_64(v_u_10, 0.7, 9, 0.9)
				local v378 = Instance.new("Attachment")
				v378.Parent = v_u_3.Terrain
				v378.WorldPosition = v376
				v_u_56(v378, v377):Emit(5)
				v_u_1:AddItem(v378, v377.life.Max + 0.3)
				local v379 = p375.eye + p375.dir * 1.4
				p_u_126.runNow((v_u_125(v379, 0.6, 2.4, 0.3)))
			end
		end,
		["windup"] = function(p380, p381, p382) -- name: windup
			-- upvalues: (copy) v_u_359, (copy) v_u_282, (copy) p_u_126, (ref) v_u_9, (ref) v_u_7
			local v_u_383 = v_u_359(p380, p381, p382 + (p380.ability.duration or 2.4) + 2.5)
			v_u_282[p380] = v_u_383
			local v384 = (v_u_383.frame * CFrame.new(0, 0, 0)).Position
			p_u_126.mark(v384, v_u_9, p380.ability.radius * 0.9, p382 + 3, v_u_7.CrackGlow, 0.1)
			p_u_126.burst("Shockwave", v384 + Vector3.new(0, 0.3, 0), v_u_9, 0.7)
			p_u_126.animate(math.max(p382, 0.15) + 0.1, 0, function(p385)
				-- upvalues: (copy) v_u_383
				local v386 = v_u_383
				local v387 = p385 - 1
				local v388 = v387 * 2.7 * v387 * v387 + 1 + v387 * 1.7 * v387
				v386.rise = math.min(v388, 1.05)
			end)
		end,
		["zone"] = function(p389, p390, p_u_391) -- name: zone
			-- upvalues: (copy) v_u_282, (copy) v_u_359, (copy) p_u_126, (ref) v_u_125, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (ref) v_u_56, (ref) v_u_64, (ref) v_u_10, (ref) v_u_7, (ref) v_u_13, (copy) v_u_374
			local v392 = p_u_391 + 2.5
			local v_u_393 = v_u_282[p389] or v_u_359(p389, p390, v392)
			v_u_282[p389] = v_u_393
			local v394 = v_u_393.rise
			v_u_393.rise = math.max(v394, 1)
			local v_u_395 = p389.ability.radius
			local v_u_396 = p_u_126.ground(p390, 0)
			local v_u_397 = p389.lite
			if not v_u_397 then
				local v398 = v_u_393.mouth + v_u_393.frame.LookVector * 1.5
				p_u_126.runNow((v_u_125(v398, 3.4, 6, 0.35)))
			end
			v_u_393.lock:Destroy()
			v_u_4.flash(v_u_393.mouth, v_u_9, 12, 0.3)
			v_u_6.play("GateOpen", {
				["at"] = v_u_393.mouth,
				["volume"] = p389.mine and 0.9 or 0.5
			})
			p_u_126.animate(0.45, 0, function(p399)
				-- upvalues: (copy) v_u_393
				local v400 = v_u_393
				local v401 = p399 - 1
				v400.open = v401 * 2.7 * v401 * v401 + 1 + v401 * 1.7 * v401
			end)
			local v402 = v_u_56(v_u_393.holder, (v_u_64(v_u_10, 0.8, 12, 1.6)))
			v402.Rate = v_u_397 and 5 or 16
			v402.EmissionDirection = Enum.NormalId.Front
			v402.SpreadAngle = Vector2.new(35, 35)
			v402.Shape = Enum.ParticleEmitterShape.Box
			v402.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			local v403 = v_u_393.emitters
			table.insert(v403, v402)
			if not v_u_397 then
				local v404 = v_u_56(v_u_393.holder, (v_u_64(v_u_9, 0.6, 10, 1.4, true)))
				v404.Rate = 5
				v404.EmissionDirection = Enum.NormalId.Front
				v404.SpreadAngle = Vector2.new(35, 35)
				local v405 = v_u_393.emitters
				table.insert(v405, v404)
				local v406 = v_u_56(v_u_393.holder, {
					["texture"] = nil,
					["color"] = nil,
					["size"] = nil,
					["alpha"] = nil,
					["life"] = nil,
					["speed"] = nil,
					["spread"] = nil,
					["rate"] = 7,
					["box"] = true,
					["front"] = true,
					["texture"] = v_u_7.Glow,
					["color"] = ColorSequence.new(v_u_13),
					["size"] = NumberSequence.new(4, 7),
					["alpha"] = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.3, 0.5), NumberSequenceKeypoint.new(1, 1) }),
					["life"] = NumberRange.new(1, 1.4),
					["speed"] = NumberRange.new(3, 6),
					["spread"] = Vector2.new(30, 30)
				})
				local v407 = v_u_393.emitters
				table.insert(v407, v406)
				p_u_126.mark(v_u_396, v_u_13, v_u_395 * 1.05, p_u_391 + 0.4, v_u_7.Glow, 0.45)
			end
			if p389.mine then
				v_u_4.shake(0.3, 0.3)
			end
			local v_u_408 = os.clock()
			local v_u_409 = 0.4
			local v_u_410 = false
			p_u_126.runNow(function()
				-- upvalues: (ref) v_u_410, (copy) v_u_408, (ref) v_u_409, (copy) v_u_393, (copy) v_u_397, (copy) v_u_395, (ref) v_u_374, (copy) v_u_396, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (copy) p_u_391
				if v_u_410 then
					return false
				end
				local v411 = os.clock() - v_u_408
				if v_u_409 <= v411 then
					v_u_409 = v_u_409 + 0.4
					v_u_393.chains = 0
					if not v_u_397 then
						for _ = 1, 2 do
							local v412 = math.random() * 3.141592653589793 * 2
							local v413 = v_u_395 * (0.3 + math.random() * 0.6)
							local v414 = v_u_374
							local v415 = v_u_393
							local v416 = v_u_396
							local v417 = math.cos(v412) * v413
							local v418 = math.sin(v412) * v413
							v414(v415, v416 + Vector3.new(v417, 1, v418), 0.5)
						end
					end
					v_u_4.ring(v_u_396, v_u_9, v_u_395 * 0.9, 0.35, v_u_7.Ring)
				end
				return v411 < p_u_391 + 0.3
			end)
			return function()
				-- upvalues: (ref) v_u_410, (copy) v_u_393, (ref) p_u_126
				v_u_410 = true
				for _, v419 in v_u_393.emitters do
					v419.Enabled = false
				end
				local v_u_420 = v_u_393.open
				p_u_126.animate(0.12, 0, function(p421)
					-- upvalues: (ref) v_u_393, (copy) v_u_420
					v_u_393.open = v_u_420 * (1 - p421 * p421)
				end)
			end
		end,
		["finish"] = function(p422, p423) -- name: finish
			-- upvalues: (copy) v_u_282, (copy) p_u_126, (ref) v_u_125, (ref) v_u_4, (ref) v_u_9, (ref) v_u_64, (ref) v_u_10, (ref) v_u_3, (ref) v_u_56, (ref) v_u_1, (ref) v_u_7, (ref) v_u_6
			local v_u_424 = v_u_282[p422]
			v_u_282[p422] = nil
			local v425 = p422.ability.radius
			local v426 = p_u_126.ground(p423, 0)
			if v_u_424 then
				v_u_424.open = 0
				local v427 = v_u_424.mouth + v_u_424.frame.LookVector * 1.2
				p_u_126.runNow((v_u_125(v427, 7, 4.5, 0.55)))
				v_u_4.flash(v427, v_u_9, 22, 0.35)
				p_u_126.burst("Shockwave", p_u_126.ground(v427, 0.3), v_u_9, v425 / 12)
				local v428 = v_u_64(v_u_10, 0.9, 18, 1.2)
				local v429 = p422.lite and 6 or 20
				local v430 = Instance.new("Attachment")
				v430.Parent = v_u_3.Terrain
				v430.WorldPosition = v427
				v_u_56(v430, v428):Emit(v429)
				v_u_1:AddItem(v430, v428.life.Max + 0.3)
				p_u_126.after(0.35, function()
					-- upvalues: (ref) p_u_126, (copy) v_u_424
					p_u_126.animate(0.6, 0, function(p431)
						-- upvalues: (ref) v_u_424
						v_u_424.sink = p431 * p431
						if p431 >= 1 then
							v_u_424.done = true
							for _, v432 in v_u_424.parts do
								v432.p:Destroy()
							end
							v_u_424.swirl:Destroy()
							v_u_424.holder:Destroy()
						end
					end)
				end)
			end
			v_u_4.ring(v426, v_u_9, v425 * 1.3, 0.5, v_u_7.Shockwave)
			p_u_126.dome(v426, v425 * 1.05, v_u_9, 0.45)
			p_u_126.burst("Explosion", v426 + Vector3.new(0, 2, 0), v_u_9, 1.8)
			v_u_6.play("Explosion", {
				["at"] = v426,
				["volume"] = p422.mine and 1 or 0.6
			})
			if p422.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end,
		["hit"] = function(p433, p434, _) -- name: hit
			-- upvalues: (copy) p_u_126, (ref) v_u_9, (copy) v_u_282, (copy) v_u_374
			p_u_126.burst("Impact", p434, v_u_9, 0.6)
			local v435 = v_u_282[p433]
			if v435 and (not p433.lite and v435.chains < 8) then
				v435.chains = v435.chains + 1
				v_u_374(v435, p434, 0.3)
			end
		end
	}
	return v167
end