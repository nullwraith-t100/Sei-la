local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.Parent.EpicKit8)
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v4 = require(script.Parent.Parent.Preload)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v1.Shared.Config.Textures)
v4.images({
	v_u_6.PorcelainPlate,
	v_u_6.NeedleBurst,
	v_u_6.NeedleSplash,
	v_u_6.Glow
})
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = Color3.fromRGB(8, 40, 70)
local v_u_9 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_10 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_15(p11, p12, p13) -- name: floorEmitter
	local v14 = Instance.new("ParticleEmitter")
	v14.Texture = p11
	v14.Color = ColorSequence.new(p12)
	v14.LightEmission = p13
	v14.LightInfluence = 0
	v14.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v14.EmissionDirection = Enum.NormalId.Top
	v14.SpreadAngle = Vector2.zero
	v14.Speed = NumberRange.new(0.01)
	v14.Rate = 0
	v14.Enabled = false
	v14.LockedToPart = true
	return v14
end
return function(p_u_16)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15
	return {
		["w8_thousand_needles"] = function(p_u_17, p18)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) p_u_16, (ref) v_u_2, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8, (ref) v_u_15
			local v19 = v_u_3.color(p18.color)
			local v20 = p_u_17.headY / 1.5
			local v_u_21 = math.clamp(v20, 0.7, 3)
			local v22 = p_u_17.fx
			local v23 = math.min(v22, 1.6)
			local v24 = v_u_5.formRate()
			local v25 = v_u_5.level() <= 1
			local v_u_26 = p_u_16.throb(p_u_17, 5.5, 2.4, 1.1)
			local v37 = p_u_16.group(p_u_17, function(p27, p28)
				-- upvalues: (copy) v_u_26, (copy) v_u_21, (copy) p_u_17
				local v29 = -0.2 - 0.7 * v_u_26()
				local v30 = CFrame.new
				local v31 = v_u_21 * 1.399999976158142
				local v32 = p_u_17.headY + v_u_21 * 0.25
				local v33 = p28 * 1.6
				local v34 = p27 * v30(v31, v32 + math.sin(v33) * 0.15 * v_u_21, v_u_21 * 0.44999998807907104)
				local v35 = CFrame.Angles
				local v36 = p28 * 1.1
				return v34 * v35(math.sin(v36) * 0.08, 0, v29)
			end)
			local v38 = v_u_21 * 1.9
			local v39 = v_u_2.piece("w8_thousand_needles", v38)
			local v40 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v19, {
				["transparency"] = 1
			})
			p_u_16.pin(p_u_17, v37, v40, CFrame.new(0, v38 * 0.5, 0))
			p_u_16.own(p_u_17, v40)
			if v39 then
				p_u_16.pin(p_u_17, v37, v39, v_u_10 * v_u_2.longY(v39))
			else
				local v41, v42 = v_u_2.build(v_u_2.VASE, v38, v25)
				for v43, v44 in v41 do
					p_u_16.pin(p_u_17, v37, v44, CFrame.new(0, -v38 * 0.5, 0) * v42[v43])
				end
			end
			for v_u_45 = 1, 2 do
				local v_u_46 = v_u_45 * 3.141592653589793
				local v64 = p_u_16.group(p_u_17, function(p47, p48)
					-- upvalues: (copy) v_u_46, (copy) v_u_26, (copy) v_u_21, (copy) v_u_45
					local v49 = p48 * 1.25 + v_u_46
					local v50 = (2.1 + 1.6 * v_u_26()) * v_u_21
					local v51 = p47.Position
					local v52 = math.cos(v49) * v50
					local v53 = v_u_21 * -0.15
					local v54 = p48 * 2 + v_u_45
					local v55 = v53 + math.sin(v54) * 0.35 * v_u_21
					local v56 = math.sin(v49) * v50
					local v57 = v51 + Vector3.new(v52, v55, v56)
					local v58 = -math.sin(v49)
					local v59 = math.cos(v49)
					local v60 = Vector3.new(v58, 0, v59)
					local v61 = CFrame.lookAt(v57, v57 + v60)
					local v62 = CFrame.Angles
					local v63 = p48 * 11 + v_u_45
					return v61 * v62(0, math.sin(v63) * 0.22, 0)
				end)
				local v65, v66 = v_u_2.build(v_u_2.FISH, v_u_21 * 1.75, v25)
				for v67, v68 in v65 do
					p_u_16.pin(p_u_17, v64, v68, v66[v67])
				end
			end
			local v69 = Instance.new("Attachment")
			v69.Parent = v40
			local v_u_70 = Instance.new("ParticleEmitter")
			v_u_70.Texture = v_u_6.NeedleSplash
			v_u_70.FlipbookLayout = v_u_9
			v_u_70.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_70.Color = ColorSequence.new(v19)
			v_u_70.LightEmission = 0.4
			v_u_70.LightInfluence = 0
			v_u_70.Lifetime = NumberRange.new(0.5, 0.6)
			v_u_70.Size = v_u_2.seq({
				{ 0, 1.2 },
				{ 1, 2 }
			}, v_u_21 * v23)
			v_u_70.Speed = NumberRange.new(v_u_21 * 2, v_u_21 * 4)
			v_u_70.SpreadAngle = Vector2.new(40, 40)
			v_u_70.Rotation = NumberRange.new(0, 360)
			v_u_70.Rate = 0
			v_u_70.Enabled = false
			v_u_70.Parent = v69
			local v_u_71 = Instance.new("ParticleEmitter")
			v_u_71.Texture = v_u_6.Glow
			v_u_71.Color = ColorSequence.new(v_u_7, v19)
			v_u_71.LightEmission = 1
			v_u_71.LightInfluence = 0
			v_u_71.Orientation = Enum.ParticleOrientation.VelocityParallel
			v_u_71.Squash = NumberSequence.new(2.2)
			v_u_71.Lifetime = NumberRange.new(0.35, 0.5)
			v_u_71.Size = NumberSequence.new(v_u_21 * 0.4)
			v_u_71.Speed = NumberRange.new(v_u_21 * 14, v_u_21 * 20)
			v_u_71.SpreadAngle = Vector2.new(180, 180)
			v_u_71.Drag = 2
			v_u_71.Rate = 0
			v_u_71.Enabled = false
			v_u_71.Parent = v69
			local v72 = v_u_3.part
			local v73 = v_u_21 * 2.4
			local v74 = v_u_21 * 2.4
			local v75 = v72(Vector3.new(v73, 0.2, v74), CFrame.identity, v_u_8, {
				["transparency"] = 1
			})
			v75.Massless = true
			p_u_16.add(p_u_17, v75, function(p76)
				-- upvalues: (ref) p_u_16, (copy) p_u_17
				return CFrame.new(p_u_16.feetAt(p_u_17, p76, 0.1))
			end)
			p_u_16.own(p_u_17, v75)
			local v77 = Instance.new("Attachment")
			v77.Parent = v75
			local v78 = v_u_15(v_u_6.PorcelainPlate, v_u_7, 0.05)
			v78.Lifetime = NumberRange.new(2.6)
			v78.Size = NumberSequence.new(v_u_21 * 3.2 * v23)
			v78.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.3, 0.45 },
				{ 0.7, 0.45 },
				{ 1, 1 }
			})
			v78.Rotation = NumberRange.new(0, 360)
			v78.RotSpeed = NumberRange.new(12, 12)
			v78:SetAttribute("BaseRate", 0.6)
			v78.Rate = 0.6 * v24
			v78.Enabled = true
			v78.Parent = v77
			v78:Emit(1)
			local v_u_79 = v_u_15(v_u_6.NeedleBurst, v19, 0.5)
			v_u_79.Lifetime = NumberRange.new(0.6)
			v_u_79.Size = v_u_2.seq({
				{ 0, 1 },
				{ 0.25, 5.4 },
				{ 1, 6 }
			}, v_u_21 * v23)
			v_u_79.Transparency = v_u_2.seq({
				{ 0, 0.3 },
				{ 0.25, 0 },
				{ 0.6, 0.2 },
				{ 1, 1 }
			})
			v_u_79.Rotation = NumberRange.new(0, 360)
			v_u_79.RotSpeed = NumberRange.new(60, 60)
			v_u_79.Parent = v77
			local v_u_80 = -1
			local v81 = p_u_17.ticks
			local function v85(p82)
				-- upvalues: (copy) v_u_26, (ref) v_u_80, (ref) p_u_16, (copy) v_u_79, (copy) v_u_70, (copy) v_u_71, (ref) v_u_5
				local v83 = v_u_26() * 20
				local v84 = math.floor(v83) / 20
				if v84 ~= v_u_80 then
					if v84 > 0.95 and (v_u_80 <= 0.95 and (p82.Position - p_u_16.camPos()).Magnitude < 150) then
						v_u_79:Emit(1)
						v_u_70:Emit(2)
						v_u_71:Emit(v_u_5.level() >= 2 and 16 or 6)
					end
					v_u_80 = v84
				end
			end
			table.insert(v81, v85)
		end
	}
end