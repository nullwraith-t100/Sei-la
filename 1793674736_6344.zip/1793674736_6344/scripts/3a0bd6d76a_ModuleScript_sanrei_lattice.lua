local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("3A8AFF")
local v_u_8 = Color3.fromRGB(160, 215, 255)
local v_u_9 = Color3.fromRGB(25, 70, 200)
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Enum.PartType.Wedge
local function v_u_20(p12, p13, p14, p15, p16) -- name: picture
	-- upvalues: (copy) v_u_4
	local v17 = v_u_4.part(Vector3.new(p13, 0.05, p13), p12, p15, {
		["transparency"] = 1
	})
	for _, v18 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v19 = Instance.new("Decal")
		v19.Face = v18
		v19.Texture = p14
		v19.Color3 = p15
		v19.Transparency = p16
		v19.Parent = v17
	end
	return v17
end
local function v_u_24(p21, p22) -- name: setAlpha
	for _, v23 in p21:GetChildren() do
		if not v23:IsA("Decal") then
			continue
		end
		v23.Transparency = p22
	end
end
local function v_u_44(p25, p26, p27, p28, p29) -- name: newBlade
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_10, (copy) v_u_11
	local v30 = v_u_4.part(Vector3.new(p25, p26, 0.05), CFrame.identity, p27)
	v_u_1:AddItem(v30, p29)
	local v31 = {
		["body"] = v30,
		["w"] = p25,
		["t"] = p26,
		["tip"] = p25 * 1.8
	}
	if p28 then
		local v32 = v_u_4.part
		local v33 = p25 / 2
		local v34 = v31.tip
		local v35 = Vector3.new(p26, v33, v34)
		local v36 = {
			["shape"] = v_u_11
		}
		local v37 = v32(v35, CFrame.identity, v_u_10, v36)
		local v38 = v_u_4.part
		local v39 = p25 / 2
		local v40 = v31.tip
		local v41 = Vector3.new(p26, v39, v40)
		local v42 = {
			["shape"] = v_u_11
		}
		local v43 = v38(v41, CFrame.identity, v_u_10, v42)
		v_u_1:AddItem(v37, p29)
		v_u_1:AddItem(v43, p29)
		v31.tipA = v37
		v31.tipB = v43
	end
	return v31
end
local function v_u_55(p45, p46, p47) -- name: placeBlade
	local v48 = math.max(p47, 0.05)
	local v49 = p45.body
	local v50 = p45.w
	local v51 = p45.t
	v49.Size = Vector3.new(v50, v51, v48)
	p45.body.CFrame = p46 * CFrame.new(0, 0, p45.tip + v48 / 2)
	local v52 = p45.tipA
	local v53 = p45.tipB
	if v52 and v53 then
		local v54 = p46 * CFrame.new(0, 0, p45.tip / 2)
		v52.CFrame = v54 * CFrame.new(p45.w / 4, 0, 0) * CFrame.Angles(0, 0, -1.5707963267948966)
		v53.CFrame = v54 * CFrame.new(-p45.w / 4, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966)
	end
end
local function v_u_65(p56, p57, p58, p59, p60) -- name: lightColumn
	-- upvalues: (copy) v_u_4, (copy) v_u_10, (copy) v_u_1, (copy) v_u_6
	local v61 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p56), v_u_10, {
		["transparency"] = 1
	})
	v_u_1:AddItem(v61, p60)
	local v62 = Instance.new("Attachment")
	v62.Parent = v61
	local v63 = Instance.new("Attachment")
	v63.Position = Vector3.new(0, p57, 0)
	v63.Parent = v61
	local v64 = Instance.new("Beam")
	v64.Attachment0 = v62
	v64.Attachment1 = v63
	v64.Texture = v_u_6.SanreiBeam
	v64.TextureMode = Enum.TextureMode.Stretch
	v64.Color = ColorSequence.new(Color3.fromRGB(150, 200, 255), Color3.fromRGB(90, 160, 255))
	v64.LightEmission = 0.3
	v64.LightInfluence = 0
	v64.Brightness = 1
	v64.FaceCamera = true
	v64.Segments = 1
	v64.Width0 = p58
	v64.Width1 = p58
	v64.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, p59), NumberSequenceKeypoint.new(0.7, p59 + (1 - p59) * 0.3), NumberSequenceKeypoint.new(1, 1) })
	v64.Parent = v61
	return v64, v61
end
return function(p_u_66)
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_10, (copy) v_u_20, (copy) v_u_6, (copy) v_u_8, (copy) v_u_1, (copy) v_u_9, (copy) v_u_3, (copy) v_u_44, (copy) v_u_55, (copy) v_u_65, (copy) v_u_5, (copy) v_u_24
	local v111 = {
		["sanrei_lattice_a"] = {
			["cast"] = function(p67) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_66, (ref) v_u_10
				local v68 = p67.size
				local v69 = p67.eye + p67.dir * 1.3
				v_u_4.flash(v69, v_u_7, 2.8 * v68, 0.1)
				p_u_66.pop(v69, v_u_10, 1 * v68, 0.2 * v68, 0.08)
			end,
			["shot"] = function(p70, p71) -- name: sawShot
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_10, (ref) v_u_20, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (copy) p_u_66, (ref) v_u_9
				local v_u_72 = p70.size
				local v73 = p70.lite
				local v_u_74 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p71, v_u_7, {
					["transparency"] = 1
				})
				local v_u_75 = v_u_4.part(Vector3.new(0.6, 0.6, 0.6) * v_u_72, p71, v_u_10, {
					["shape"] = Enum.PartType.Ball
				})
				local v_u_76 = v_u_20(p71, 3.6 * v_u_72, v_u_6.Ring, v_u_8, 0)
				local v_u_77 = v_u_20(p71, 7 * v_u_72, v_u_6.Glow, v_u_7, 0.3)
				local v_u_78 = v73 and 4 or 6
				local v_u_79 = {}
				for v80 = 1, v_u_78 do
					local v81 = v_u_4.part
					local v82 = 0.28 * v_u_72
					local v83 = 0.08 * v_u_72
					local v84 = 1.5 * v_u_72
					local v85 = Vector3.new(v82, v83, v84)
					local v86
					if v80 % 2 == 0 then
						v86 = v_u_8
					else
						v86 = v_u_10
					end
					table.insert(v_u_79, v81(v85, p71, v86))
				end
				for _, v87 in {
					v_u_74,
					v_u_75,
					v_u_76,
					v_u_77
				} do
					v_u_1:AddItem(v87, 3)
				end
				for _, v88 in v_u_79 do
					v_u_1:AddItem(v88, 3)
				end
				p_u_66.streak(v_u_74, v_u_7, v_u_9, 1.4 * v_u_72, 0.12)
				if p70.mine then
					p_u_66.light(v_u_74, v_u_7, 8 * v_u_72)
				end
				local v_u_89 = false
				return {
					["place"] = function(p90, p91) -- name: place
						-- upvalues: (copy) v_u_74, (copy) v_u_75, (copy) v_u_76, (copy) v_u_77, (copy) v_u_79, (copy) v_u_78, (copy) v_u_72
						v_u_74.CFrame = p90
						local v92 = CFrame.new(p90.Position) * CFrame.Angles(0, p91 * 30, 0)
						v_u_75.CFrame = v92
						v_u_76.CFrame = v92
						v_u_77.CFrame = v92 * CFrame.new(0, -0.05, 0)
						for v93, v94 in v_u_79 do
							local v95 = v93 * 3.141592653589793 * 2 / v_u_78
							v94.CFrame = v92 * CFrame.Angles(0, v95, 0) * CFrame.new(0, 0, -1.05 * v_u_72) * CFrame.Angles(0, 0.6108652381980153, 0)
						end
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_89, (copy) v_u_74, (ref) v_u_1, (copy) v_u_75, (copy) v_u_76, (copy) v_u_77, (copy) v_u_79
						if not v_u_89 then
							v_u_89 = true
							local v96 = v_u_74:FindFirstChildWhichIsA("PointLight")
							if v96 then
								v96:Destroy()
							end
							v_u_1:AddItem(v_u_74, 0.3)
							v_u_75:Destroy()
							v_u_76:Destroy()
							v_u_77:Destroy()
							for _, v97 in v_u_79 do
								v97:Destroy()
							end
						end
					end
				}
			end,
			["impact"] = function(p98, p99) -- name: impact
				-- upvalues: (ref) v_u_3, (ref) v_u_20, (copy) p_u_66, (ref) v_u_6, (ref) v_u_10, (ref) v_u_4, (ref) v_u_1, (ref) v_u_7, (ref) v_u_8
				local v100 = p98.size
				local v101 = v_u_3.CurrentCamera
				local v102
				if v101 then
					local v103 = v101.CFrame.Position - p99
					v102 = v103.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v103.Unit
				else
					v102 = Vector3.new(0, 0, 1)
				end
				local v104 = v_u_20(p_u_66.facing(p99 + v102 * 0.4, v102), 2 * v100, v_u_6.Ring, v_u_10, 0)
				local v105 = v_u_4.tween
				local v106 = {}
				local v107 = 7.5 * v100
				local v108 = 7.5 * v100
				v106.Size = Vector3.new(v107, 0.05, v108)
				v105(v104, 0.22, v106)
				for _, v109 in v104:GetChildren() do
					if not v109:IsA("Decal") then
						continue
					end
					v_u_4.tween(v109, 0.22, {
						["Transparency"] = 1
					})
				end
				v_u_1:AddItem(v104, 0.25)
				p_u_66.pop(p99, v_u_7, 1 * v100, 4 * v100, 0.18, 0.4)
				p_u_66.glint(p99, v_u_10, 3.6 * v100, 0.14)
				p_u_66.spikes(p99, v_u_8, p98.lite and 3 or 6, 5 * v100, 0.18, nil, nil, true)
				if not p98.lite then
					v_u_4.ring(p_u_66.ground(p99), v_u_7, p98.ability.radius * 0.9 * v100, 0.25, v_u_6.Ring)
				end
				p_u_66.hitSound(p99)
			end,
			["hit"] = function(_, p110, _) -- name: hit
				-- upvalues: (copy) p_u_66, (ref) v_u_7
				p_u_66.burst("Impact", p110, v_u_7, 0.6)
			end
		}
	}
	local v_u_112 = {}
	setmetatable(v_u_112, {
		["__mode"] = "k"
	})
	v111.sanrei_lattice_e = {
		["cast"] = function(p113) -- name: cast
			-- upvalues: (copy) p_u_66, (ref) v_u_7, (ref) v_u_10
			p_u_66.skillCast(p113, v_u_7)
			p_u_66.glint(p113.eye + p113.dir * 1.4, v_u_10, 4 * p113.size, 0.16)
		end,
		["windup"] = function(p114, p115, p116) -- name: windup
			-- upvalues: (copy) p_u_66, (copy) v_u_112, (ref) v_u_44, (ref) v_u_8, (ref) v_u_55, (ref) v_u_10, (ref) v_u_4, (ref) v_u_1
			local v_u_117 = p114.size
			local v118 = p114.lite
			local v119 = p114.ability.radius * v_u_117 * 0.92
			local v120 = p_u_66.ground(p115, 0)
			local v121 = p114.dir.Z
			local v122 = p114.dir.X
			local v123 = math.atan2(v121, v122)
			local v124 = p116 - 0.03
			local v125 = math.max(v124, 0.06)
			local v_u_126 = {
				["blades"] = {},
				["points"] = {},
				["lines"] = {}
			}
			v_u_112[p114] = v_u_126
			local v127 = p114.eye + p114.dir * 1.5
			for v128 = 1, 5 do
				local v129 = v123 + v128 * 3.141592653589793 * 2 / 5
				local v130 = math.cos(v129)
				local v131 = math.sin(v129)
				local v_u_132 = v120 + Vector3.new(v130, 0, v131) * v119
				local v133 = v_u_126.points
				table.insert(v133, v_u_132)
				local v_u_134 = v_u_44(0.45 * v_u_117, 0.1 * v_u_117, v_u_8, not v118, p116 + 1.5)
				local v135 = v_u_126.blades
				table.insert(v135, v_u_134)
				local v136 = math.cos(v129)
				local v137 = math.sin(v129)
				local v_u_138 = v127 + Vector3.new(v136, 0.4, v137) * 2
				p_u_66.animate(v125, 0, function(p139)
					-- upvalues: (copy) v_u_138, (copy) v_u_132, (ref) v_u_55, (copy) v_u_134, (ref) p_u_66, (copy) v_u_117, (ref) v_u_10
					local v140 = p139 * p139
					local v141 = v_u_138:Lerp(v_u_132, v140)
					local v142 = p139 * 3.141592653589793
					local v143 = v141 + Vector3.new(0, 1, 0) * math.sin(v142) * 6
					local v144 = p139 >= 1 and Vector3.new(-0, -1, -0) or (v_u_132 - v_u_138).Unit:Lerp(Vector3.new(-0, -1, -0), v140)
					v_u_55(v_u_134, p_u_66.aimAt(v143, v144), 3 * v_u_117)
					if p139 >= 1 then
						v_u_55(v_u_134, p_u_66.aimAt(v_u_132 + Vector3.new(0, 0.6, 0), Vector3.new(-0, -1, -0)), 3 * v_u_117)
						p_u_66.pop(v_u_132 + Vector3.new(0, 0.5, 0), v_u_10, 0.6 * v_u_117, 3 * v_u_117, 0.15)
					end
				end)
			end
			p_u_66.after(v125, function()
				-- upvalues: (copy) v_u_126, (copy) v_u_117, (ref) v_u_8, (ref) v_u_4, (ref) v_u_1, (ref) p_u_66
				for v145 = 1, 5 do
					local v_u_146 = v_u_126.points[v145] + Vector3.new(0, 0.12, 0)
					local v_u_147 = v_u_126.points[(v145 + 1) % 5 + 1] + Vector3.new(0, 0.12, 0)
					local v148 = 0.5 * v_u_117
					local v149 = v_u_8
					local v150 = (v_u_146 - v_u_146).Magnitude
					local v151 = math.max(v150, 0.05)
					local v_u_152 = v_u_4.part(Vector3.new(v148, 0.12, v151), CFrame.lookAt((v_u_146 + v_u_146) / 2, v_u_146), v149)
					v_u_1:AddItem(v_u_152, 1.5)
					local v153 = v_u_126.lines
					table.insert(v153, v_u_152)
					p_u_66.animate(0.05, 0, function(p154)
						-- upvalues: (copy) v_u_146, (copy) v_u_147, (copy) v_u_152, (ref) v_u_117
						local v155 = v_u_146:Lerp(v_u_147, (math.max(p154, 0.02)))
						local v156 = v_u_152
						local v157 = 0.5 * v_u_117
						local v158 = (v155 - v_u_146).Magnitude
						v156.Size = Vector3.new(v157, 0.12, v158)
						v_u_152.CFrame = CFrame.lookAt((v_u_146 + v155) / 2, v_u_147)
					end)
				end
			end)
		end,
		["land"] = function(p159, p160) -- name: land
			-- upvalues: (copy) p_u_66, (copy) v_u_112, (ref) v_u_65, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_5
			local v161 = p159.size
			local v162 = p159.lite
			local v163 = p159.ability.radius * v161
			local v164 = p_u_66.ground(p160, 0.2)
			local v165 = v_u_112[p159]
			v_u_112[p159] = nil
			local v_u_166 = v_u_65(v164, 40, v163 * 1.5, 0.35, 0.6)
			v_u_4.tween(v_u_166, 0.45, {
				["Width0"] = v163 * 2.4,
				["Width1"] = v163 * 0.4
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			p_u_66.animate(0.45, 0, function(p167)
				-- upvalues: (copy) v_u_166
				v_u_166.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35 + 0.65 * p167), NumberSequenceKeypoint.new(1, 1) })
			end)
			v_u_4.flash(v164 + Vector3.new(0, 3, 0), v_u_10, v163 * 1.1, 0.25)
			p_u_66.pop(v164 + Vector3.new(0, 2, 0), v_u_7, 3 * v161, v163 * 1.5, 0.4, 0.45)
			p_u_66.dome(v164, v163, v_u_8, 0.4)
			v_u_4.ring(v164, v_u_10, v163 * 1.15, 0.45, v_u_6.Shockwave)
			p_u_66.burst("Shockwave", v164 + Vector3.new(0, 0.3, 0), v_u_7, v163 / 14)
			p_u_66.burst("Flash", v164 + Vector3.new(0, 3, 0), v_u_7, 0.8, true)
			if not v162 then
				p_u_66.spikes(v164 + Vector3.new(0, 2, 0), v_u_8, 10, v163 * 0.9, 0.3, Vector3.new(0, 1, 0), 0.9)
				p_u_66.mark(p160, v_u_7, v163 * 0.8, 1, v_u_6.Glow, 0.35)
			end
			if v165 then
				for _, v168 in v165.lines do
					v168.Color = v_u_10
					local v169 = v168.Size
					local v170 = 0.6 * v161
					v168.Size = v169 + Vector3.new(v170, 0, 0)
					v_u_4.tween(v168, 0.5, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
				for v171, v172 in v165.blades do
					local v173 = v165.points[v171] + Vector3.new(0, 2, 0)
					local v174 = { v172.body }
					local v175 = v172.tipA
					local v176 = v172.tipB
					if v175 and v176 then
						table.insert(v174, v175)
						table.insert(v174, v176)
					end
					for _, v177 in v174 do
						v177:Destroy()
					end
					if not v162 or v171 % 2 == 1 then
						local v178 = { v_u_8, v_u_10, v_u_7 }
						p_u_66.chunks(v173, v178, 3, 20 * v161, 0.4 * v161, 0.6, true, 0.8)
					end
					p_u_66.glint(v173, v_u_10, 4 * v161, 0.18)
				end
			end
			v_u_5.play("Explosion", {
				["at"] = v164,
				["volume"] = p159.mine and 0.8 or 0.45
			})
			if p159.mine then
				v_u_4.shake(0.3, 0.3)
			end
		end,
		["hit"] = function(p179, p180, _) -- name: hit
			-- upvalues: (copy) p_u_66, (ref) v_u_7, (ref) v_u_8
			p_u_66.burst("Impact", p180, v_u_7, 0.9)
			if not p179.lite then
				p_u_66.glint(p180, v_u_8, 3, 0.14)
			end
		end
	}
	local v_u_181 = {}
	setmetatable(v_u_181, {
		["__mode"] = "k"
	})
	local function v_u_219(p182, p183, p184) -- name: lattice
		-- upvalues: (copy) p_u_66, (ref) v_u_8, (ref) v_u_4
		local v_u_185 = p182.size
		local v186 = p182.ability.radius * v_u_185
		local v187 = p_u_66.ground(p183, 0.1)
		local v188 = p182.dir.Z
		local v189 = p182.dir.X
		local v190 = math.atan2(v188, v189) + 0.7853981633974483
		local v191 = p182.lite and { -0.45, 0.45 } or {
			-0.66,
			-0.22,
			0.22,
			0.66
		}
		local v192 = {}
		for _, v193 in { 0, 1.5707963267948966 } do
			local v194 = v190 + v193
			local v195 = math.cos(v194)
			local v196 = v190 + v193
			local v197 = math.sin(v196)
			local v_u_198 = Vector3.new(v195, 0, v197)
			local v199 = -v_u_198.Z
			local v200 = v_u_198.X
			local v201 = Vector3.new(v199, 0, v200)
			for _, v202 in v191 do
				local v203 = 1 - v202 * v202
				local v204 = math.max(v203, 0)
				local v_u_205 = math.sqrt(v204) * v186
				local v_u_206 = v187 + v201 * v202 * v186
				local v207 = v_u_206 + v_u_198 * 0.05
				local v208 = 0.42 * v_u_185
				local v209 = v_u_8
				local v210 = (v207 - v_u_206).Magnitude
				local v211 = math.max(v210, 0.05)
				local v_u_212 = v_u_4.part(Vector3.new(v208, 0.12, v211), CFrame.lookAt((v_u_206 + v207) / 2, v207), v209)
				table.insert(v192, v_u_212)
				p_u_66.animate(p184, 0, function(p213)
					-- upvalues: (copy) v_u_205, (copy) v_u_212, (copy) v_u_185, (copy) v_u_206, (copy) v_u_198
					local v214 = v_u_205 * (1 - (1 - p213) ^ 2)
					local v215 = math.max(v214, 0.05)
					local v216 = v_u_212
					local v217 = 0.42 * v_u_185
					local v218 = v215 * 2
					v216.Size = Vector3.new(v217, 0.12, v218)
					v_u_212.CFrame = CFrame.lookAt(v_u_206, v_u_206 + v_u_198)
				end)
			end
		end
		return v192
	end
	v111.sanrei_lattice_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p220) -- name: cast
			-- upvalues: (copy) p_u_66, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4
			p_u_66.skillCast(p220, v_u_7, true)
			p_u_66.burst("Flash", p220.eye, v_u_8, 0.35)
			if p220.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p221, p222, p223) -- name: windup
			-- upvalues: (copy) p_u_66, (ref) v_u_8, (copy) v_u_219, (ref) v_u_1, (copy) v_u_181, (ref) v_u_4, (ref) v_u_7, (ref) v_u_6
			local v224 = p221.size
			local v225 = math.max(p223, 0.15)
			local v226 = p_u_66.ground(p222, 1.5)
			p_u_66.inward(v226, v_u_8, p221.lite and 6 or 14, p221.ability.radius * 1.4 * v224, v225)
			local v227 = v_u_219(p221, p222, v225)
			local v228 = v225 + (p221.ability.duration or 2.4) + 1
			for _, v229 in v227 do
				v_u_1:AddItem(v229, v228)
			end
			v_u_181[p221] = {
				["lines"] = v227,
				["born"] = os.clock()
			}
			v_u_4.ring(p_u_66.ground(p222), v_u_7, p221.ability.radius * 1.1 * v224, v225 + 0.1, v_u_6.Ring)
		end,
		["zone"] = function(p_u_230, p231, p232) -- name: zone
			-- upvalues: (copy) p_u_66, (ref) v_u_65, (ref) v_u_4, (ref) v_u_10, (ref) v_u_6, (ref) v_u_7, (ref) v_u_5, (ref) v_u_44, (ref) v_u_8, (ref) v_u_1, (copy) v_u_181, (ref) v_u_55, (ref) v_u_20, (ref) v_u_24
			local v_u_233 = p_u_230.size
			local v_u_234 = p_u_230.lite
			local v_u_235 = p_u_230.ability.radius * v_u_233
			local v_u_236 = p_u_66.ground(p231, 0)
			local v_u_237 = p232 + 0.6
			local v_u_238, v_u_239 = v_u_65(v_u_236, 130, 0.1, 0.3, v_u_237)
			local v_u_240
			if v_u_234 then
				v_u_240 = nil
			else
				v_u_240 = v_u_65(v_u_236, 130, 0.1, 0.1, v_u_237)
			end
			v_u_4.flash(v_u_236 + Vector3.new(0, 4, 0), v_u_10, v_u_235 * 1.2, 0.3)
			v_u_4.ring(v_u_236, v_u_10, v_u_235 * 1.4, 0.5, v_u_6.Shockwave)
			p_u_66.burst("Shockwave", v_u_236 + Vector3.new(0, 0.3, 0), v_u_7, v_u_235 / 13)
			p_u_66.mark(p231, v_u_7, v_u_235 * 1.1, v_u_237, v_u_6.Glow, 0.3)
			v_u_5.play("Explosion", {
				["at"] = v_u_236,
				["volume"] = p_u_230.mine and 0.7 or 0.4
			})
			if p_u_230.mine then
				v_u_4.shake(0.3, 0.35)
			end
			local v_u_241 = {}
			for _ = 1, v_u_234 and 4 or 9 do
				local v242 = v_u_44
				local v243 = 0.5 * v_u_233
				local v244 = 0.1 * v_u_233
				local v245
				if #v_u_241 % 2 == 0 then
					v245 = v_u_10
				else
					v245 = v_u_8
				end
				local v246 = v242(v243, v244, v245, not v_u_234, v_u_237)
				table.insert(v_u_241, v246)
			end
			local v_u_247
			if v_u_234 then
				v_u_247 = nil
			else
				local v248 = v_u_4.part
				local v249 = v_u_235 * 1.2
				local v250 = v_u_235 * 1.2
				v_u_247 = v248(Vector3.new(v249, 1, v250), CFrame.new(v_u_236 + Vector3.new(0, 1, 0)), v_u_10, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_247, v_u_237 + 1.5)
				local v251 = Instance.new("ParticleEmitter")
				v251.Texture = v_u_6.Glow
				v251.Color = ColorSequence.new(v_u_10, v_u_8)
				v251.LightEmission = 0.9
				v251.LightInfluence = 0
				v251.Lifetime = NumberRange.new(0.8, 1.2)
				v251.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 2.2 * v_u_233), NumberSequenceKeypoint.new(1, 0) })
				v251.Speed = NumberRange.new(30, 50)
				v251.EmissionDirection = Enum.NormalId.Top
				v251.SpreadAngle = Vector2.new(4, 4)
				v251.Shape = Enum.ParticleEmitterShape.Box
				v251.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
				v251.Rate = 40
				v251.Parent = v_u_247
			end
			local v_u_252 = v_u_181[p_u_230]
			local v_u_253 = os.clock()
			local v_u_254 = 0
			local v_u_255 = false
			p_u_66.runNow(function()
				-- upvalues: (copy) v_u_253, (ref) v_u_255, (copy) v_u_237, (copy) v_u_239, (copy) v_u_241, (copy) v_u_238, (copy) v_u_235, (ref) v_u_240, (copy) v_u_236, (ref) v_u_55, (ref) p_u_66, (copy) v_u_233, (ref) v_u_254, (copy) p_u_230, (ref) v_u_20, (ref) v_u_6, (ref) v_u_8, (ref) v_u_1, (ref) v_u_24, (copy) v_u_234, (copy) v_u_252, (ref) v_u_10, (ref) v_u_4
				local v256 = os.clock() - v_u_253
				if v_u_255 or v_u_237 <= v256 then
					v_u_239:Destroy()
					for _, v257 in v_u_241 do
						local v258 = { v257.body }
						local v259 = v257.tipA
						local v260 = v257.tipB
						if v259 and v260 then
							table.insert(v258, v259)
							table.insert(v258, v260)
						end
						for _, v261 in v258 do
							v261:Destroy()
						end
					end
					return false
				end
				local v262 = v256 / 0.2
				local v263 = 1 - (1 - math.clamp(v262, 0, 1)) ^ 3
				local v264 = v256 * 9
				local v265 = math.sin(v264) * 0.05 + 1
				v_u_238.Width0 = v_u_235 * 2 * v263 * v265
				v_u_238.Width1 = v_u_235 * 2 * v263 * v265
				local v266 = v_u_240
				if v266 then
					v266.Width0 = v_u_235 * 0.9 * v263 / v265
					v266.Width1 = v_u_235 * 0.9 * v263 / v265
				end
				for v267, v268 in v_u_241 do
					local v269 = v267 / #v_u_241
					local v270 = (v256 * 22 + v269 * 130 * 0.5) % 65 + 1
					local v271 = v256 * 2.4 + v269 * 3.141592653589793 * 2
					local v272 = math.cos(v271)
					local v273 = math.sin(v271)
					local v274 = Vector3.new(v272, 0, v273)
					local v275 = v_u_236 + v274 * v_u_235 * 1.02 + Vector3.new(0, 1, 0) * v270
					local v276 = -v274.Z
					local v277 = v274.X
					local v278 = Vector3.new(v276, 0.55, v277)
					v_u_55(v268, p_u_66.aimAt(v275, v278), 3.2 * v_u_233)
				end
				if v_u_254 <= v256 then
					v_u_254 = v_u_254 + (p_u_230.ability.tick or 0.4)
					local v_u_279 = v_u_20(CFrame.new(v_u_236 + Vector3.new(0, 1, 0)), v_u_235 * 2.2, v_u_6.Ring, v_u_8, 0.1)
					v_u_1:AddItem(v_u_279, 1)
					p_u_66.animate(0.8, 0, function(p280)
						-- upvalues: (copy) v_u_279, (ref) v_u_236, (ref) v_u_235, (ref) v_u_24
						v_u_279.CFrame = CFrame.new(v_u_236 + Vector3.new(0, 1, 0) * (1 + p280 * 50))
						local v281 = v_u_235 * (2.2 - p280 * 0.6)
						v_u_279.Size = Vector3.new(v281, 0.05, v281)
						v_u_24(v_u_279, 0.1 + p280 * 0.9)
						if p280 >= 1 then
							v_u_279:Destroy()
						end
					end)
					if not v_u_234 and v_u_252 then
						for _, v282 in v_u_252.lines do
							v282.Color = v_u_10
							local v283 = {
								["Color"] = v_u_8
							}
							v_u_4.tween(v282, 0.3, v283)
						end
					end
				end
				return true
			end)
			return function()
				-- upvalues: (ref) v_u_247, (ref) p_u_66, (copy) v_u_238, (copy) v_u_235, (ref) v_u_255
				local v284 = v_u_247
				local v285 = v284 and v284:FindFirstChildWhichIsA("ParticleEmitter")
				if v285 then
					v285.Enabled = false
				end
				p_u_66.animate(0.12, 0, function(p286)
					-- upvalues: (ref) v_u_238, (ref) v_u_235
					v_u_238.Width0 = v_u_235 * 2 * (1 + p286 * 0.4)
					v_u_238.Width1 = v_u_235 * 2 * (1 + p286 * 0.4)
				end)
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_255
					v_u_255 = true
				end)
			end
		end,
		["finish"] = function(p287, p288) -- name: finish
			-- upvalues: (copy) p_u_66, (copy) v_u_181, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_65, (ref) v_u_1, (ref) v_u_5
			local v289 = p287.size
			local v290 = p287.lite
			local v291 = p287.ability.radius * v289
			local v292 = p_u_66.ground(p288, 0.2)
			local v293 = v_u_181[p287]
			v_u_181[p287] = nil
			v_u_4.flash(v292 + Vector3.new(0, 5, 0), v_u_10, v291 * 1.8, 0.35)
			p_u_66.pop(v292 + Vector3.new(0, 3, 0), v_u_10, 4, v291 * 2, 0.45, 0.3)
			p_u_66.pop(v292, v_u_7, v291 * 0.6, v291 * 2.6, 0.6, 0.45)
			p_u_66.dome(v292, v291 * 1.3, v_u_8, 0.55)
			v_u_4.ring(v292, v_u_10, v291 * 1.6, 0.55, v_u_6.Shockwave)
			v_u_4.ring(v292, v_u_7, v291 * 2, 0.7, v_u_6.Ring)
			p_u_66.burst("Flash", v292 + Vector3.new(0, 4, 0), v_u_8, 0.9, true)
			p_u_66.burst("Shockwave", v292 + Vector3.new(0, 0.3, 0), v_u_7, v291 / 11)
			local v294 = v_u_65(v292, 130, v291 * 2.6, 0, 0.5)
			v_u_4.tween(v294, 0.4, {
				["Width0"] = 0,
				["Width1"] = 0
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			if not v290 then
				p_u_66.spikes(v292 + Vector3.new(0, 3, 0), v_u_10, 16, v291 * 1.4, 0.4, nil, nil, true)
				local v295 = { v_u_8, v_u_10, v_u_7 }
				p_u_66.chunks(v292 + Vector3.new(0, 2, 0), v295, 8, 30 * v289, 0.5 * v289, 0.8, true, 0.7)
			end
			if v293 then
				for _, v296 in v293.lines do
					v296.Color = v_u_10
					v_u_4.tween(v296, 0.4, {
						["Transparency"] = 1
					})
					v_u_1:AddItem(v296, 0.45)
				end
			end
			v_u_5.play("Explosion", {
				["at"] = v292,
				["volume"] = p287.mine and 1 or 0.55
			})
			if p287.mine then
				v_u_4.shake(0.5, 0.45)
			end
		end,
		["hit"] = function(p297, p298, _) -- name: hit
			-- upvalues: (copy) p_u_66, (ref) v_u_7, (ref) v_u_8
			p_u_66.burst("Impact", p298, v_u_7, 0.8)
			if not p297.lite then
				p_u_66.glint(p298, v_u_8, 2.6, 0.12)
			end
		end
	}
	return v111
end