local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Bars)
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v2.Shared.Config.Textures)
v6.images({ v_u_8.MurcielagoBolt, v_u_8.MurcielagoRing, v_u_8.MurcielagoMoon })
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromHex("2BFF9A")
local v_u_11 = Color3.fromRGB(0, 150, 86)
local v_u_12 = Color3.fromHex("0B2A1E")
local v_u_13 = Color3.fromRGB(6, 9, 8)
local v_u_14 = Color3.fromRGB(236, 255, 244)
local v_u_15 = Color3.fromRGB(236, 232, 220)
local v_u_16 = Enum.Material.SmoothPlastic
local v_u_17 = Enum.PartType.Wedge
local function v_u_49(p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v29 = p24 + p25 + p26
	local v30 = math.max(v29, 0.05)
	local v31 = {}
	local v32 = {}
	for v33 = 0, 10 do
		local v34 = v33 / 10
		local v35 = v34 * v30
		local v36 = v35 / math.max(p24, 0.001)
		local v37 = 1 - (1 - math.clamp(v36, 0, 1)) ^ 3
		local v38 = (v35 - p24 - p25) / math.max(p26, 0.001)
		local v39 = math.clamp(v38, 0, 1)
		local v40 = v39 * v39 * (3 - v39 * 2)
		local v41 = NumberSequenceKeypoint.new
		local v42 = p19 + (p20 - p19) * v37
		local v43 = math.max(v42, 0.05) / 2
		table.insert(v32, v41(v34, v43))
		local v44 = NumberSequenceKeypoint.new
		local v45 = p23 + (1 - p23) * v40
		local v46 = math.clamp(v45, 0, 1)
		table.insert(v31, v44(v34, v46))
	end
	local v47 = Instance.new("Attachment")
	v47.WorldCFrame = CFrame.new(p18)
	v47.Parent = v_u_3.Terrain
	local v48 = Instance.new("ParticleEmitter")
	v48.Enabled = false
	v48.Texture = p21
	if p28 then
		v48.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
		v48.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	end
	v48.Color = ColorSequence.new(p22)
	v48.LightEmission = p27 or 0
	v48.LightInfluence = 0
	v48.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v48.EmissionDirection = Enum.NormalId.Top
	v48.SpreadAngle = Vector2.zero
	v48.Speed = NumberRange.new(0.01)
	v48.Size = NumberSequence.new(v32)
	v48.Transparency = NumberSequence.new(v31)
	v48.Lifetime = NumberRange.new(v30)
	v48.Rotation = NumberRange.new(0, 360)
	v48.Parent = v47
	v48:Emit(1)
	v_u_1:AddItem(v47, v30 + 0.2)
end
local function v_u_57(p50, p51, p52, p53, p54) -- name: crackle
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_10, (copy) v_u_1
	local v55 = Instance.new("Attachment")
	v55.WorldPosition = p50
	v55.Parent = v_u_3.Terrain
	local v56 = Instance.new("ParticleEmitter")
	v56.Enabled = false
	v56.Texture = v_u_8.MurcielagoBolt
	v56.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
	v56.FlipbookMode = Enum.ParticleFlipbookMode.Random
	v56.Color = ColorSequence.new(v_u_10)
	v56.LightEmission = 0.6
	v56.LightInfluence = 0
	v56.Lifetime = NumberRange.new((p53 or 0.2) * 0.7, p53 or 0.2)
	v56.Size = NumberSequence.new(p51 * 0.5)
	v56.Transparency = NumberSequence.new(0, 1)
	v56.Speed = NumberRange.new(0, p54 or 0)
	v56.SpreadAngle = Vector2.new(180, 180)
	v56.Rotation = NumberRange.new(0, 360)
	v56.Parent = v55
	v56:Emit(p52)
	v_u_1:AddItem(v55, (p53 or 0.2) + 0.2)
end
local function v_u_73(p58, p59, p60, p_u_61, p_u_62) -- name: moonAt
	-- upvalues: (copy) v_u_5, (copy) v_u_9, (copy) v_u_1, (copy) v_u_8
	local v_u_63 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p58), v_u_9, {
		["transparency"] = 1
	})
	v_u_1:AddItem(v_u_63, p_u_61 + 0.2)
	local v64 = Instance.new("Attachment")
	v64.Parent = v_u_63
	local v65 = p59 / 2
	v64.Position = Vector3.new(0, v65, 0)
	local v66 = Instance.new("Attachment")
	v66.Parent = v_u_63
	local v67 = -p59 / 2
	v66.Position = Vector3.new(0, v67, 0)
	local v_u_68 = Instance.new("Beam")
	v_u_68.Attachment0 = v64
	v_u_68.Attachment1 = v66
	v_u_68.Texture = v_u_8.MurcielagoMoon
	v_u_68.TextureMode = Enum.TextureMode.Stretch
	v_u_68.Color = ColorSequence.new(p60)
	v_u_68.LightEmission = 0.6
	v_u_68.LightInfluence = 0
	v_u_68.FaceCamera = true
	v_u_68.Width0 = p59
	v_u_68.Width1 = p59
	v_u_68.Segments = 1
	v_u_68.Transparency = NumberSequence.new(1)
	v_u_68.Parent = v_u_63
	local v_u_69 = os.clock()
	task.spawn(function()
		-- upvalues: (copy) v_u_63, (copy) v_u_69, (copy) p_u_62, (copy) p_u_61, (copy) v_u_68
		while v_u_63.Parent do
			local v70 = os.clock() - v_u_69
			local v71
			if v70 < p_u_62 then
				v71 = 1 - v70 / p_u_62
			else
				local v72 = (v70 - (p_u_61 - 0.4)) / 0.4
				v71 = math.clamp(v72, 0, 1)
			end
			v_u_68.Transparency = NumberSequence.new((math.clamp(v71, 0, 1)))
			task.wait()
		end
	end)
end
local function v_u_101(p74, p75, p_u_76, p77) -- name: newSpear
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_9, (copy) v_u_10, (copy) v_u_17, (copy) v_u_12, (copy) v_u_16
	local v_u_78 = {
		["parts"] = {},
		["offs"] = {},
		["sizes"] = {}
	}
	local function v89(p79, p80, p81, p82, p83, p84) -- name: add
		-- upvalues: (ref) v_u_5, (ref) v_u_1, (copy) p_u_76, (copy) v_u_78
		local v85 = v_u_5.part(p79, p80, p81, {
			["transparency"] = p82,
			["shape"] = p83,
			["material"] = p84
		})
		v_u_1:AddItem(v85, p_u_76)
		local v86 = v_u_78.parts
		table.insert(v86, v85)
		local v87 = v_u_78.offs
		table.insert(v87, p80)
		local v88 = v_u_78.sizes
		table.insert(v88, p79)
	end
	local v90 = p75 * 0.4
	local v91 = p75 * 0.4
	v89(Vector3.new(v90, v91, p74), CFrame.identity, v_u_9)
	local v92 = p74 * 1.02
	v89(Vector3.new(p75, p75, v92), CFrame.identity, v_u_10, 0.35)
	for _, v93 in { 0, 3.141592653589793 } do
		local v94 = p75 * 1.1
		local v95 = p75 * 1.1
		local v96 = p74 * 0.22
		v89(Vector3.new(v94, v95, v96), CFrame.new(0, 0, -p74 * 0.6) * CFrame.Angles(0, 0, v93) * CFrame.new(0, p75 * 0.55, 0), v_u_10, 0, v_u_17)
	end
	if not p77 then
		for _, v97 in { -0.15, 0.25 } do
			local v98 = p75 * 1.25
			local v99 = p75 * 1.25
			local v100 = p75 * 0.5
			v89(Vector3.new(v98, v99, v100), CFrame.new(0, 0, p74 * v97), v_u_12, 0, nil, v_u_16)
		end
	end
	return v_u_78
end
local function v_u_109(p102, p103, p104) -- name: placeSpear
	local v105 = math.max(p104, 0.02)
	for v106, v107 in p102.parts do
		local v108 = p102.offs[v106]
		v107.CFrame = p103 * (v108 - v108.Position + v108.Position * v105)
		v107.Size = p102.sizes[v106] * v105
	end
end
local function v_u_113(p110, p111) -- name: dropSpear
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	for _, v112 in p110.parts do
		v_u_5.tween(v112, p111, {
			["Transparency"] = 1
		})
		v_u_1:AddItem(v112, p111 + 0.05)
	end
end
local function v_u_122(p114, p115, p116) -- name: darkTrail
	-- upvalues: (copy) v_u_12, (copy) v_u_13
	local v117 = Instance.new("Attachment")
	local v118 = p115 / 2
	v117.Position = Vector3.new(0, v118, 0)
	v117.Parent = p114
	local v119 = Instance.new("Attachment")
	local v120 = -p115 / 2
	v119.Position = Vector3.new(0, v120, 0)
	v119.Parent = p114
	local v121 = Instance.new("Trail")
	v121.Attachment0 = v117
	v121.Attachment1 = v119
	v121.Color = ColorSequence.new(v_u_12, v_u_13)
	v121.Transparency = NumberSequence.new(0.1, 1)
	v121.WidthScale = NumberSequence.new(1, 0.2)
	v121.Lifetime = p116
	v121.LightEmission = 0
	v121.LightInfluence = 0
	v121.FaceCamera = true
	v121.MinLength = 0.05
	v121.Parent = p114
end
return function(p_u_123)
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_10, (copy) v_u_5, (copy) v_u_9, (copy) v_u_101, (copy) v_u_109, (copy) v_u_11, (copy) v_u_122, (copy) v_u_113, (copy) v_u_57, (copy) v_u_8, (copy) v_u_13, (copy) v_u_16, (copy) v_u_1, (copy) v_u_49, (copy) v_u_15, (copy) v_u_7, (copy) v_u_73, (copy) v_u_3, (copy) v_u_14
	local v124 = {}
	local function v_u_137(p125, p126, p127, p128, p129) -- name: groundBolts
		-- upvalues: (copy) p_u_123, (ref) v_u_4, (ref) v_u_12, (ref) v_u_10
		local v130 = math.random() * 3.141592653589793 * 2
		for v131 = 1, p126 do
			local v132 = v130 + v131 / p126 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.4
			local v133 = math.cos(v132)
			local v134 = math.sin(v132)
			local v135 = p125 + Vector3.new(v133, 0, v134) * p127 * (0.7 + math.random() * 0.3)
			local v136 = p_u_123.boltPath(p125, v135, p127 * 0.12, p127 / 6)
			v_u_4.path(v136, p128 * 1.8, v_u_12, p129, 0.1)
			v_u_4.path(p_u_123.jitter(v136, 0.05), p128, v_u_10, p129)
		end
	end
	v124.murcielago_a = {
		["cast"] = nil,
		["shot"] = nil,
		["keep"] = 0.3,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p138) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_123, (ref) v_u_9
			local v139 = p138.size
			local v140 = p138.eye + p138.dir * 1.2
			v_u_5.flash(v140, v_u_10, 2.6 * v139, 0.1)
			if not p138.lite then
				p_u_123.glint(v140, v_u_9, 3 * v139, 0.12)
			end
		end,
		["shot"] = function(p141, p142) -- name: shot
			-- upvalues: (ref) v_u_101, (ref) v_u_109, (copy) p_u_123, (ref) v_u_10, (ref) v_u_11, (ref) v_u_122, (ref) v_u_113
			local v143 = p141.size
			local v_u_144 = v_u_101(4.4 * v143, 0.42 * v143, 3, p141.lite)
			v_u_109(v_u_144, p142, 1)
			local v145 = v_u_144.parts[1]
			p_u_123.streak(v145, v_u_10, v_u_11, 0.5 * v143, 0.14)
			if not p141.lite then
				v_u_122(v145, 0.25 * v143, 0.12)
			end
			local v_u_146 = false
			return {
				["place"] = function(p147, p148) -- name: place
					-- upvalues: (ref) v_u_109, (copy) v_u_144
					v_u_109(v_u_144, p147 * CFrame.Angles(0, 0, p148 * 6), 1)
				end,
				["stop"] = function(p149) -- name: stop
					-- upvalues: (ref) v_u_146, (ref) v_u_113, (copy) v_u_144
					if not v_u_146 then
						v_u_146 = true
						v_u_113(v_u_144, p149 or 0.05)
					end
				end
			}
		end,
		["impact"] = function(p150, p151) -- name: impact
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_10, (ref) v_u_57, (copy) p_u_123, (ref) v_u_12, (ref) v_u_8
			local v152 = p150.size
			v_u_5.flash(p151, v_u_9, 2.4 * v152, 0.1)
			v_u_5.flash(p151, v_u_10, 5 * v152, 0.22)
			v_u_57(p151, 4 * v152, p150.lite and 1 or 2, 0.18)
			if not p150.lite then
				p_u_123.spikes(p151, v_u_10, 4, 4 * v152, 0.16)
			end
			v_u_5.ring(p_u_123.ground(p151, 0.12), v_u_12, p150.ability.radius * 0.6 * v152, 0.25, v_u_8.Ring)
			p_u_123.hitSound(p151)
		end,
		["hit"] = function(_, p153, _) -- name: hit
			-- upvalues: (copy) p_u_123, (ref) v_u_10
			p_u_123.burst("Impact", p153, v_u_10, 0.6)
		end
	}
	v124.murcielago_e = {
		["cast"] = function(p154) -- name: cast
			-- upvalues: (copy) p_u_123, (ref) v_u_10, (ref) v_u_13, (ref) v_u_16, (ref) v_u_57
			p_u_123.skillCast(p154, v_u_10, false, true)
			local v155 = p154.size
			local v156 = p154.eye + p154.dir * 1.5 - Vector3.new(0, 0.4, 0)
			p_u_123.pop(v156, v_u_13, 0.4 * v155, 2.4 * v155, 0.25, 0, v_u_16)
			p_u_123.pop(v156, v_u_10, 0.6 * v155, 3 * v155, 0.25, 0.5)
			v_u_57(v156, 3 * v155, 2, 0.2)
		end,
		["shot"] = function(p157, p158) -- name: shot
			-- upvalues: (ref) v_u_5, (ref) v_u_13, (ref) v_u_16, (ref) v_u_10, (ref) v_u_1, (copy) p_u_123, (ref) v_u_11, (ref) v_u_122, (ref) v_u_8, (ref) v_u_12
			local v_u_159 = p157.size
			local v_u_160 = v_u_5.part(Vector3.new(2, 2, 2) * v_u_159, p158, v_u_13, {
				["shape"] = Enum.PartType.Ball,
				["material"] = v_u_16
			})
			local v_u_161 = v_u_5.part(Vector3.new(2.7, 2.7, 2.7) * v_u_159, p158, v_u_10, {
				["shape"] = nil,
				["transparency"] = 0.6,
				["shape"] = Enum.PartType.Ball
			})
			v_u_1:AddItem(v_u_160, 4)
			v_u_1:AddItem(v_u_161, 4)
			p_u_123.streak(v_u_160, v_u_10, v_u_11, 1.6 * v_u_159, 0.2)
			local v_u_162 = {}
			if not p157.lite then
				v_u_122(v_u_160, 1.2 * v_u_159, 0.25)
				local v163 = Instance.new("ParticleEmitter")
				v163.Texture = v_u_8.MurcielagoBolt
				v163.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
				v163.FlipbookMode = Enum.ParticleFlipbookMode.Random
				v163.Color = ColorSequence.new(v_u_10)
				v163.LightEmission = 0.6
				v163.LightInfluence = 0
				v163.Lifetime = NumberRange.new(0.08, 0.14)
				v163.Size = NumberSequence.new(1.6 * v_u_159)
				v163.Rotation = NumberRange.new(0, 360)
				v163.Speed = NumberRange.new(0)
				v163.LockedToPart = true
				v163.Rate = 24
				v163.Parent = v_u_160
				table.insert(v_u_162, v163)
				local v164 = Instance.new("ParticleEmitter")
				v164.Texture = v_u_8.FxSmoke
				v164.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v164.FlipbookMode = Enum.ParticleFlipbookMode.Random
				v164.Color = ColorSequence.new(v_u_13, v_u_12)
				v164.LightEmission = 0
				v164.LightInfluence = 0
				v164.Lifetime = NumberRange.new(0.3, 0.5)
				v164.Size = NumberSequence.new(1.6 * v_u_159, 0.4 * v_u_159)
				v164.Transparency = NumberSequence.new(0.3, 1)
				v164.Speed = NumberRange.new(0.5, 1.5)
				v164.SpreadAngle = Vector2.new(180, 180)
				v164.Rate = 40
				v164.Parent = v_u_160
				table.insert(v_u_162, v164)
			end
			if p157.mine then
				p_u_123.light(v_u_160, v_u_10, 10 * v_u_159)
			end
			local v_u_165 = false
			return {
				["place"] = function(p166, p167) -- name: place
					-- upvalues: (copy) v_u_160, (copy) v_u_161, (copy) v_u_159
					v_u_160.CFrame = p166 * CFrame.Angles(p167 * 3, p167 * 5, 0)
					local v168 = p167 * 30
					local v169 = math.sin(v168) * 0.06 + 1
					v_u_161.CFrame = p166
					v_u_161.Size = Vector3.new(2.7, 2.7, 2.7) * v_u_159 * v169
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_165, (copy) v_u_162, (copy) v_u_160, (ref) v_u_1, (copy) v_u_161
					if not v_u_165 then
						v_u_165 = true
						for _, v170 in v_u_162 do
							v170.Enabled = false
						end
						v_u_160.Transparency = 1
						v_u_1:AddItem(v_u_160, 0.6)
						v_u_161:Destroy()
					end
				end
			}
		end,
		["impact"] = function(p171, p172) -- name: impact
			-- upvalues: (copy) p_u_123, (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_16, (ref) v_u_10, (ref) v_u_49, (ref) v_u_8, (ref) v_u_57, (copy) v_u_137, (ref) v_u_15, (ref) v_u_12, (ref) v_u_7
			local v173 = p171.size
			local v174 = p171.ability.radius * v173
			local v175 = p_u_123.ground(p172, 0.15)
			v_u_5.flash(p172, v_u_9, 3 * v173, 0.1)
			p_u_123.pop(p172, v_u_13, 2 * v173, v174 * 1.5, 0.45, 0.05, v_u_16)
			p_u_123.pop(p172, v_u_10, 2.5 * v173, v174 * 1.6, 0.4, 0.8)
			v_u_49(v175, v174 * 0.5, v174 * 2.6, v_u_8.MurcielagoRing, v_u_13, 0, 0.45, 0, 0.05, 0, true)
			v_u_5.ring(v175, v_u_10, v174 * 1.2, 0.45, v_u_8.Ring)
			v_u_57(p172, 7 * v173, p171.lite and 2 or 5, 0.3, 8)
			if not p171.lite then
				v_u_137(v175, 5, v174 * 1.1, 0.35 * v173, 0.35)
				local v176 = { v_u_15, v_u_13, v_u_12 }
				p_u_123.chunks(v175 + Vector3.new(0, 0.5, 0), v176, 6, 26, 0.45 * v173, 0.8, false, 1)
			end
			v_u_7.play("Explosion", {
				["at"] = p172,
				["volume"] = p171.mine and 0.9 or 0.5
			})
			if p171.mine then
				v_u_5.shake(0.3, 0.25)
			end
		end,
		["hit"] = function(p177, p178, _) -- name: hit
			-- upvalues: (ref) v_u_57, (copy) p_u_123, (ref) v_u_10
			v_u_57(p178, 3 * p177.size, 1, 0.16)
			p_u_123.burst("Impact", p178, v_u_10, 0.7)
		end
	}
	v124.murcielago_r = {
		["cast"] = function(p179) -- name: cast
			-- upvalues: (copy) p_u_123, (ref) v_u_10
			p_u_123.skillCast(p179, v_u_10, true, true)
		end,
		["windup"] = function(p180, p181, p182) -- name: windup
			-- upvalues: (copy) p_u_123, (ref) v_u_101, (ref) v_u_109, (ref) v_u_113, (ref) v_u_5, (ref) v_u_10, (ref) v_u_57
			local v_u_183 = p180.size
			local v_u_184 = math.max(p182, 0.12)
			local v_u_185 = p180.eye + Vector3.new(0, 3.5, 0) * v_u_183 - p180.dir * 0.5
			local v_u_186 = p_u_123.ground(p181, 1)
			local v_u_187 = v_u_101(14 * v_u_183, 1.1 * v_u_183, v_u_184 + 1, p180.lite)
			local v_u_188 = v_u_184 * 0.55
			p_u_123.animate(v_u_184, 0, function(p189)
				-- upvalues: (copy) v_u_188, (copy) v_u_184, (ref) v_u_109, (copy) v_u_187, (copy) v_u_185, (copy) v_u_186, (copy) v_u_183, (ref) v_u_113
				if p189 < v_u_188 / v_u_184 then
					local v190 = p189 / (v_u_188 / v_u_184)
					local v191 = math.clamp(v190, 0, 1)
					local v192 = v191 * v191 * (3 - v191 * 2)
					v_u_109(v_u_187, CFrame.lookAt(v_u_185, v_u_186), v192 * 0.8 + 0.2)
				else
					local v193 = (p189 - v_u_188 / v_u_184) / (1 - v_u_188 / v_u_184)
					local v194 = v_u_185:Lerp(v_u_186, v193)
					local v195 = v193 * 3.141592653589793
					local v196 = v194 + Vector3.new(0, 1, 0) * math.sin(v195) * 4 * v_u_183
					local v197 = v_u_185
					local v198 = v_u_186
					local v199 = v193 + 0.05
					local v200 = v197:Lerp(v198, (math.min(v199, 1)))
					local v201 = v193 + 0.05
					local v202 = math.min(v201, 1) * 3.141592653589793
					local v203 = v200 + Vector3.new(0, 1, 0) * math.sin(v202) * 4 * v_u_183
					v_u_109(v_u_187, CFrame.lookAt(v196, v203 + (v_u_186 - v_u_185).Unit * 0.01), 1)
				end
				if p189 >= 1 then
					v_u_113(v_u_187, 0.25)
				end
			end)
			v_u_5.flash(v_u_185, v_u_10, 6 * v_u_183, 0.25)
			v_u_57(v_u_185, 6 * v_u_183, p180.lite and 2 or 5, 0.3, 4)
		end,
		["land"] = function(p204, p205) -- name: land
			-- upvalues: (copy) p_u_123, (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_12, (ref) v_u_10, (ref) v_u_8, (ref) v_u_49, (ref) v_u_13, (ref) v_u_57, (copy) v_u_137, (ref) v_u_15, (ref) v_u_73, (ref) v_u_3, (ref) v_u_14, (ref) v_u_7
			local v_u_206 = p204.size
			local v207 = p204.lite
			local v208 = p204.ability.radius * v_u_206
			local v_u_209 = p_u_123.ground(p205, 0.15)
			local v_u_210 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_209), v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_210, 2.2)
			local v211 = Instance.new("Attachment")
			v211.Parent = v_u_210
			local v212 = Instance.new("Attachment")
			v212.Parent = v_u_210
			v212.Position = Vector3.new(0, 90, 0)
			local v_u_213 = {}
			for v214, v215 in {
				{
					["w"] = nil,
					["c"] = nil,
					["e"] = 0,
					["t"] = 0.2,
					["w"] = v208 * 1.05,
					["c"] = v_u_12
				},
				{
					["w"] = nil,
					["c"] = nil,
					["e"] = 0.7,
					["t"] = 0.1,
					["w"] = v208 * 0.85,
					["c"] = v_u_10
				},
				{
					["w"] = nil,
					["c"] = nil,
					["e"] = 0.9,
					["t"] = 0,
					["w"] = v208 * 0.32,
					["c"] = v_u_9
				}
			} do
				if v207 and v214 == 1 then
					continue
				end
				local v216 = Instance.new("Beam")
				v216.Attachment0 = v211
				v216.Attachment1 = v212
				v216.Texture = v_u_8.Beam
				v216.TextureMode = Enum.TextureMode.Stretch
				v216.Color = ColorSequence.new(v215.c)
				v216.LightEmission = v215.e
				v216.LightInfluence = 0
				v216.FaceCamera = true
				v216.Segments = 1
				v216.ZOffset = v214 * 0.3
				v216.Width0 = 0.1
				v216.Width1 = 0.1
				v216.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, v215.t), NumberSequenceKeypoint.new(0.7, (v215.t + 1) / 2), NumberSequenceKeypoint.new(1, 1) })
				v216.Parent = v_u_210
				local v217 = {
					["beam"] = v216,
					["w"] = v215.w
				}
				table.insert(v_u_213, v217)
			end
			p_u_123.animate(1.6, 0, function(p218)
				-- upvalues: (copy) v_u_213, (copy) v_u_210
				local v219 = p218 / 0.12
				local v220 = 1 - (1 - math.clamp(v219, 0, 1)) ^ 3
				local v221 = (p218 - 0.45) / 0.55
				local v222 = math.clamp(v221, 0, 1)
				local v223 = v222 * v222 * (3 - v222 * 2)
				for _, v224 in v_u_213 do
					local v225 = v224.w * v220 * (1 - v223 * 0.85)
					v224.beam.Width0 = math.max(v225, 0.05)
					local v226 = v224.beam
					local v227 = v225 * 0.6
					v226.Width1 = math.max(v227, 0.05)
				end
				if p218 >= 1 then
					v_u_210:Destroy()
				end
			end)
			v_u_5.flash(v_u_209 + Vector3.new(0, 4, 0), v_u_9, 10 * v_u_206, 0.2)
			v_u_5.flash(v_u_209 + Vector3.new(0, 4, 0), v_u_10, v208 * 1.1, 0.4)
			p_u_123.dome(v_u_209, v208, v_u_10, 0.6)
			v_u_49(v_u_209, v208 * 0.4, v208 * 2.8, v_u_8.MurcielagoRing, v_u_13, 0, 0.5, 0, 0.05, 0, true)
			v_u_5.ring(v_u_209, v_u_10, v208 * 1.3, 0.55, v_u_8.Shockwave)
			v_u_5.ring(v_u_209, v_u_12, v208 * 1.05, 0.5, v_u_8.Ring)
			v_u_57(v_u_209 + Vector3.new(0, 6, 0), 12 * v_u_206, v207 and 3 or 8, 0.4, 14)
			if not v207 then
				v_u_137(v_u_209, 7, v208 * 1.2, 0.5 * v_u_206, 0.5)
				local v228 = {
					v_u_15,
					v_u_13,
					v_u_12,
					v_u_10
				}
				p_u_123.chunks(v_u_209 + Vector3.new(0, 0.5, 0), v228, 8, 32, 0.55 * v_u_206, 1, false, 1)
				for v_u_229 = 1, 4 do
					p_u_123.after(v_u_229 * 0.12, function()
						-- upvalues: (ref) v_u_57, (copy) v_u_209, (copy) v_u_229, (copy) v_u_206
						v_u_57(v_u_209 + Vector3.new(0, 1, 0) * (v_u_229 * 12 + 8), 10 * v_u_206, 2, 0.25, 4)
					end)
				end
			end
			p_u_123.after(0.5, function()
				-- upvalues: (ref) v_u_73, (copy) v_u_209, (copy) v_u_206, (ref) v_u_3, (ref) v_u_14, (ref) v_u_5, (ref) p_u_123, (ref) v_u_10, (ref) v_u_1, (ref) v_u_8
				local v230 = v_u_73
				local v231 = v_u_209 + Vector3.new(0, 38, 0) * v_u_206
				local v232 = v_u_209
				local v233 = v_u_3.CurrentCamera
				local v234
				if v233 then
					local v235 = v233.CFrame.Position - v232
					v234 = v235.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v235.Unit
				else
					v234 = Vector3.new(0, 0, 1)
				end
				v230(v231 + v234 * 2, 22 * v_u_206, v_u_14, 1.4, 0.3)
				local v236 = v_u_5.part
				local v237 = Vector3.new(30, 0.05, 30) * v_u_206
				local v238 = p_u_123.facing
				local v239 = v_u_209 + Vector3.new(0, 38, 0) * v_u_206
				local v240 = v_u_209 + Vector3.new(0, 38, 0) * v_u_206
				local v241 = v_u_3.CurrentCamera
				local v242
				if v241 then
					local v243 = v241.CFrame.Position - v240
					v242 = v243.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v243.Unit
				else
					v242 = Vector3.new(0, 0, 1)
				end
				local v244 = v236(v237, v238(v239, v242), v_u_10, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v244, 1.6)
				for _, v245 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
					local v246 = Instance.new("Decal")
					v246.Face = v245
					v246.Texture = v_u_8.Glow
					v246.Color3 = v_u_10
					v246.Transparency = 0.5
					v246.Parent = v244
					v_u_5.tween(v246, 1.5, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
			end)
			v_u_7.play("Explosion", {
				["at"] = v_u_209,
				["volume"] = p204.mine and 1 or 0.55
			})
			v_u_7.play("Lightning", {
				["at"] = v_u_209,
				["volume"] = p204.mine and 0.7 or 0.4
			})
			if p204.mine then
				v_u_5.shake(0.5, 0.45)
			end
		end,
		["hit"] = function(p247, p248, _) -- name: hit
			-- upvalues: (ref) v_u_57, (copy) p_u_123, (ref) v_u_10
			v_u_57(p248, 3.4 * p247.size, 1, 0.18)
			p_u_123.burst("Impact", p248, v_u_10, 0.9)
		end
	}
	return v124
end