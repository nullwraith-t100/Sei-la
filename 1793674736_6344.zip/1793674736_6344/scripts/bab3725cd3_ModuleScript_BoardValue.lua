local v_u_10 = {
	["logged"] = function(p1) -- name: logged
		return p1 ~= "Playtime"
	end,
	["encode"] = function(p2, p3) -- name: encode
		-- upvalues: (copy) v_u_10
		if not v_u_10.logged(p2) then
			local v4 = math.clamp(p3, 0, 9e18)
			return math.floor(v4)
		end
		local v5 = math.max(p3, 1)
		local v6 = math.log10(v5) * 100000000000000
		local v7 = math.clamp(v6, 0, 9e18)
		return math.floor(v7)
	end,
	["decode"] = function(p8, p9) -- name: decode
		-- upvalues: (copy) v_u_10
		if v_u_10.logged(p8) then
			return 10 ^ (p9 / 100000000000000)
		else
			return p9
		end
	end
}
return v_u_10