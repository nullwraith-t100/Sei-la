local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = CFrame.Angles(0.7853981633974483, 0.6154030942532006, 0)
local function v_u_10(p5, p6, p7) -- name: triangle
	local v8 = p5 / 2
	local v9 = Vector3.new(p7, p6, v8)
	return { v9, v9 }, { CFrame.new(p5 / 4, p6 / 2, 0) * CFrame.Angles(0, -1.5707963267948966, 0), CFrame.new(-p5 / 4, p6 / 2, 0) * CFrame.Angles(0, 1.5707963267948966, 0) }
end
return function(p_u_11)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_10, (copy) v_u_4
	return {
		["w3_arcane_sigil"] = function(p_u_12, p13)
			-- upvalues: (ref) v_u_2, (copy) p_u_11, (ref) v_u_3, (ref) v_u_10, (ref) v_u_4
			local v_u_14 = p_u_12.character:GetScale()
			local v_u_15 = v_u_2.color(p13.color)
			local v16 = v_u_2.color(p13.color2)
			local v17 = p_u_11.rgb(110, 40, 225)
			local v18 = p_u_11.rgb(22, 8, 38)
			local v_u_20 = p_u_11.throb(p_u_12, 4.2, 1.5, 1.6, function(p19)
				-- upvalues: (ref) v_u_2, (ref) p_u_11, (copy) p_u_12, (copy) v_u_15, (ref) v_u_3, (copy) v_u_14
				v_u_2.ring(p_u_11.feetAt(p_u_12, p19, 0.15), v_u_15, 6 * p_u_12.fx, 0.6, v_u_3.ArcaneRuneRing)
				v_u_2.burst("Flash", (p19 * CFrame.new(0, 1.4 * v_u_14, 1.8 * v_u_14)).Position, v_u_15, 0.3)
			end)
			local v_u_25 = p_u_11.group(p_u_12, function(p21, p22)
				-- upvalues: (copy) v_u_14
				local v23 = CFrame.new
				local v24 = p22 * 1.4
				return p21 * v23(0, (math.sin(v24) * 0.08 + 1.4) * v_u_14, 1.8 * v_u_14)
			end)
			local v_u_27 = p_u_11.group(p_u_12, function(_, p26)
				-- upvalues: (copy) v_u_25
				return v_u_25.cf * CFrame.Angles(0, 0, p26 * 0.25)
			end)
			local v_u_28 = 0.95 * v_u_14
			for v29 = 0, 7 do
				local v_u_30 = v29 % 2 == 0
				local v31 = 1.5707963267948966 + v29 * 3.141592653589793 / 4
				local v32 = math.cos(v31)
				local v33 = math.sin(v31)
				local v_u_34 = Vector3.new(v32, v33, 0)
				local v_u_35 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v_u_34:Cross(Vector3.new(0, 0, 1)), v_u_34)
				local v36, v37 = v_u_10((v_u_30 and 1.15 or 0.85) * v_u_14, (v_u_30 and 2.8 or 1.5) * v_u_14, (v_u_30 and 0.2 or 0.18) * v_u_14)
				for v38, v39 in v36 do
					local v40 = v_u_2.part
					local v41 = CFrame.identity
					local v42
					if v_u_30 then
						v42 = v16
					else
						v42 = v_u_15
					end
					local v43 = v40(v39, v41, v42, {
						["shape"] = Enum.PartType.Wedge
					})
					local v_u_44 = v37[v38]
					p_u_11.fadeFromBehind(p_u_12, v43, 0.45)
					p_u_11.add(p_u_12, v43, function()
						-- upvalues: (copy) v_u_20, (copy) v_u_30, (copy) v_u_14, (copy) v_u_27, (copy) v_u_34, (copy) v_u_28, (copy) v_u_35, (copy) v_u_44
						local v45 = v_u_20() * (v_u_30 and 0.55 or 0.35) * v_u_14
						local v46 = v_u_27.cf
						local v47 = CFrame.new
						local v48 = v_u_34 * (v_u_28 + v45)
						local v49 = -0.05 * v_u_14
						return v46 * v47(v48 + Vector3.new(0, 0, v49)) * v_u_35 * v_u_44
					end)
				end
			end
			local v50 = p_u_11.pin
			local v51 = p_u_11.disc
			local v52 = 2.1 * v_u_14
			local v53 = 2.1 * v_u_14
			v50(p_u_12, v_u_25, v51(Vector3.new(0.05, v52, v53), v18, 0.05, Enum.Material.SmoothPlastic), CFrame.Angles(0, 1.5707963267948966, 0))
			p_u_11.pin(p_u_12, v_u_25, p_u_11.ball(1.5 * v_u_14, v17, 0.55), CFrame.identity)
			local v54 = p_u_11.picture(1.9 * v_u_14, v_u_3.Swirl, v16, 0.05)
			p_u_11.add(p_u_12, v54, function(_, p55)
				-- upvalues: (copy) v_u_25, (copy) v_u_14
				return v_u_25.cf * CFrame.new(0, 0, 0.08 * v_u_14) * CFrame.Angles(0, 0, -p55 * 5) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v56, v_u_57 = p_u_11.picture(7 * v_u_14, v_u_3.ArcaneRunes, v_u_15, 0.2)
			p_u_11.add(p_u_12, v56, function(_, p58)
				-- upvalues: (copy) v_u_25, (copy) v_u_14
				return v_u_25.cf * CFrame.new(0, 0, -0.15 * v_u_14) * CFrame.Angles(0, 0, p58 * 0.2) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v59, v_u_60 = p_u_11.picture(8.2 * v_u_14, v_u_3.ArcaneRuneRing, v16, 0.35)
			p_u_11.add(p_u_12, v59, function(_, p61)
				-- upvalues: (copy) v_u_25, (copy) v_u_14
				return v_u_25.cf * CFrame.new(0, 0, -0.25 * v_u_14) * CFrame.Angles(0, 0, -p61 * 0.3) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v62 = p_u_12.ticks
			table.insert(v62, function()
				-- upvalues: (copy) v_u_20, (copy) v_u_57, (copy) v_u_60
				local v63 = v_u_20()
				for _, v64 in v_u_57 do
					v64.Transparency = 0.2 - v63 * 0.2
				end
				for _, v65 in v_u_60 do
					v65.Transparency = 0.35 - v63 * 0.3
				end
			end)
			local v_u_66 = 2.7 * v_u_14
			for v_u_67 = 1, 4 do
				local v68 = CFrame.Angles
				local v69 = v_u_67 * 1.7
				local v70 = math.sin(v69) * 0.5
				local v71 = v_u_67 * 0.8
				local v72 = v_u_67 * 2.3
				local v_u_73 = v68(v70, v71, math.cos(v72) * 0.45)
				local v_u_74 = v_u_67 * 0.18 + 1.1
				local function v78(p75, p76) -- name: place
					-- upvalues: (copy) v_u_74, (copy) v_u_67, (copy) v_u_14, (copy) v_u_73, (copy) v_u_66, (ref) v_u_4
					local v77 = p76 * v_u_74 + v_u_67 * 3.141592653589793 / 2
					return p75 * CFrame.new(0, 0.2 * v_u_14, 0) * v_u_73 * CFrame.new(math.cos(v77) * v_u_66, 0, math.sin(v77) * v_u_66) * CFrame.Angles(0, p76 * 3, 0) * v_u_4
				end
				local v79 = p_u_11.bar(Vector3.new(0.48, 0.48, 0.48) * v_u_14, v_u_15, 0)
				p_u_11.add(p_u_12, v79, v78)
				p_u_11.add(p_u_12, p_u_11.ball(1 * v_u_14, v16, 0.62), p_u_11.behind(v78, 0.3 * v_u_14))
				p_u_11.tail(v79, v_u_15, v17, 0.32 * v_u_14, 0.3)
			end
			p_u_11.particles(p_u_12, "AuraMode", v_u_15, {
				["rate"] = 0.55,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = {
					"Glow",
					"FlameBack",
					"Crackle",
					"Sparks"
				}
			})
			p_u_11.particles(p_u_12, "Petals", v16, {
				["rate"] = 1.1,
				["glow"] = 0.65,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end