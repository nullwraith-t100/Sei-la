local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("SocialService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("UserInputService")
local v_u_7 = require(script.Parent.Device)
local v_u_8 = require(script.Parent.Events)
local v_u_9 = require(script.Parent.Gamepad)
local v_u_10 = require(script.Parent.AutoClick)
local v_u_11 = require(script.Parent.Input)
local v_u_12 = require(script.Parent.Sfx)
local v_u_13 = require(script.Parent.State)
local v_u_14 = require(script.Parent.Store)
local v_u_15 = require(script.Parent.Tutorial)
local v_u_16 = require(script.Parent.TrophyOffer)
local v_u_17 = require(script.Parent.Fx.Kit)
local v_u_18 = require(script.Parent.Perf)
local v_u_19 = require(script.Parent.Reveal)
local v_u_20 = require(script.Parent.BossShop)
local v_u_21 = require(script.Parent.BossCoins)
local v22 = v2.Shared
local v_u_23 = require(v22.Config.Abilities)
local v_u_24 = require(v22.Config.Enemies)
local v_u_25 = require(v22.Config.Eyes)
local v_u_26 = require(v22.Config.Images)
local v_u_27 = require(v22.Config.Stages)
local v_u_28 = require(v22.Config.Plots)
local v_u_29 = require(v22.Config.Products)
local v_u_30 = require(v22.Config.Economy)
local v_u_31 = require(v22.Logic.Economy)
local v_u_32 = require(v22.Logic.ChakraLadder)
local v_u_33 = require(v22.Logic.Format)
local v_u_34 = {}
local v_u_35 = v1.LocalPlayer
local v_u_36 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_37 = table.clone(v_u_26.Iris)
local v_u_38 = {
	"Left",
	"TopRight",
	"Top",
	"Bottom",
	"Skills",
	"Upgrade",
	"Boosts",
	"Notifications"
}
local v_u_39 = nil
local function v_u_43(p40) -- name: find
	-- upvalues: (ref) v_u_39
	local v41 = v_u_39
	for v42 in string.gmatch(p40, "[^%.]+") do
		v41 = v41:WaitForChild(v42, 10)
		if v41 then
			continue
		end
		error("HUD is missing " .. p40)
	end
	return v41
end
local v_u_44 = nil
local v_u_45 = nil
function v_u_34.notify(p46, p47) -- name: notify
	-- upvalues: (ref) v_u_45, (ref) v_u_44
	local v48 = v_u_45
	if v48 then
		local v_u_49 = v48:Clone()
		v_u_49.Name = "Note"
		v_u_49.Visible = true
		if p47 then
			v_u_49.BackgroundColor3 = p47
		end
		local v50 = v_u_49:FindFirstChild("Message")
		if v50 and v50:IsA("TextLabel") then
			v50.Text = p46
		end
		v_u_49.Parent = v_u_44
		task.delay(2.6, function()
			-- upvalues: (copy) v_u_49
			v_u_49:Destroy()
		end)
	end
end
local function v_u_89(p51, p_u_52, p_u_53) -- name: counter
	-- upvalues: (copy) v_u_33, (copy) v_u_13, (copy) v_u_5, (copy) v_u_3
	local v_u_54 = p51:FindFirstChild("main")
	local v_u_55 = p51:FindFirstChild("shadow")
	local v_u_56
	if v_u_54 then
		v_u_56 = v_u_54:FindFirstChild("Transactions")
	else
		v_u_56 = v_u_54
	end
	local v_u_57
	if v_u_56 then
		v_u_57 = v_u_56:FindFirstChild("Add")
	else
		v_u_57 = v_u_56
	end
	local v_u_58
	if v_u_56 then
		v_u_58 = v_u_56:FindFirstChild("Subtract")
	else
		v_u_58 = v_u_56
	end
	if v_u_57 then
		v_u_57.Parent = nil
	end
	if v_u_58 then
		v_u_58.Parent = nil
	end
	local v_u_59 = v_u_13.number(p_u_52)
	local v60 = v_u_33.short(v_u_59)
	if v_u_54 and v_u_54:IsA("TextLabel") then
		v_u_54.Text = v60
	end
	if v_u_55 and v_u_55:IsA("TextLabel") then
		v_u_55.Text = v60
	end
	local v_u_61 = nil
	local function v_u_74(p62) -- name: badge
		-- upvalues: (copy) v_u_57, (copy) v_u_58, (copy) v_u_56, (ref) v_u_33, (ref) v_u_5
		local v63
		if p62 > 0 then
			v63 = v_u_57
		else
			v63 = v_u_58
		end
		if v63 and v_u_56 then
			local v_u_64 = v63:Clone()
			if v_u_64:IsA("GuiObject") then
				local v_u_65 = v_u_64.Size
				v_u_64.Size = UDim2.new(v_u_65.X.Scale, v_u_65.X.Offset, 0, 0)
				v_u_64.Visible = true
				local v66 = (p62 > 0 and "+" or "-") .. v_u_33.short((math.abs(p62)))
				for _, v67 in { "main", "shadow" } do
					local v68 = v_u_64:FindFirstChild(v67)
					if not (v68 and v68:IsA("TextLabel")) then
						continue
					end
					v68.Text = v66
				end
				v_u_64.Parent = v_u_56
				local v69 = Enum.EasingStyle.Back
				v_u_5:Create(v_u_64, TweenInfo.new(0.25, v69 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Size"] = v_u_65
				}):Play()
				task.delay(2, function()
					-- upvalues: (copy) v_u_64, (copy) v_u_65, (ref) v_u_5
					local v70 = v_u_64
					local v71 = {
						["Size"] = UDim2.new(v_u_65.X.Scale, v_u_65.X.Offset, 0, 0)
					}
					local v72 = Enum.EasingStyle.Quad
					local v73 = Enum.EasingDirection.In
					v_u_5:Create(v70, TweenInfo.new(0.2, v72 or Enum.EasingStyle.Quad, v73 or Enum.EasingDirection.Out), v71):Play()
					task.delay(0.2, function()
						-- upvalues: (ref) v_u_64
						v_u_64:Destroy()
					end)
				end)
			end
		end
	end
	v_u_13.watch(p_u_52, function()
		-- upvalues: (ref) v_u_13, (copy) p_u_52, (ref) v_u_59, (copy) p_u_53, (copy) v_u_74, (ref) v_u_61, (ref) v_u_3, (ref) v_u_33, (copy) v_u_54, (copy) v_u_55
		local v_u_75 = v_u_13.number(p_u_52)
		local v_u_76 = v_u_59
		local v_u_77 = v_u_75 - v_u_76
		if v_u_77 ~= 0 and (v_u_77 <= 0 or not (p_u_53 and p_u_53())) then
			v_u_59 = v_u_75
			v_u_74(v_u_77)
			if v_u_61 then
				v_u_61:Disconnect()
			end
			local v_u_78 = os.clock()
			local v_u_79 = nil
			v_u_79 = v_u_3.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_78, (copy) v_u_76, (copy) v_u_77, (ref) v_u_33, (ref) v_u_54, (ref) v_u_55, (copy) v_u_75, (ref) v_u_79
				local v80 = (os.clock() - v_u_78) / 0.5
				local v81 = math.clamp(v80, 0, 1)
				local v82 = v_u_76 + v_u_77 * v81
				local v83 = math.floor(v82)
				local v84 = v_u_33.short(v83)
				if v_u_54 and v_u_54:IsA("TextLabel") then
					v_u_54.Text = v84
				end
				if v_u_55 and v_u_55:IsA("TextLabel") then
					v_u_55.Text = v84
				end
				if v81 >= 1 then
					local v85 = v_u_75
					local v86 = v_u_33.short(v85)
					if v_u_54 and v_u_54:IsA("TextLabel") then
						v_u_54.Text = v86
					end
					if v_u_55 and v_u_55:IsA("TextLabel") then
						v_u_55.Text = v86
					end
					v_u_79:Disconnect()
				end
			end)
			v_u_61 = v_u_79
		end
	end)
	return {
		["shown"] = function() -- name: shown
			-- upvalues: (ref) v_u_59
			return v_u_59
		end,
		["setNow"] = function(p87) -- name: setNow
			-- upvalues: (ref) v_u_61, (ref) v_u_59, (ref) v_u_33, (copy) v_u_54, (copy) v_u_55
			if v_u_61 then
				v_u_61:Disconnect()
				v_u_61 = nil
			end
			v_u_59 = p87
			local v88 = v_u_33.short(p87)
			if v_u_54 and v_u_54:IsA("TextLabel") then
				v_u_54.Text = v88
			end
			if v_u_55 and v_u_55:IsA("TextLabel") then
				v_u_55.Text = v88
			end
		end,
		["badge"] = v_u_74
	}
end
local function v_u_94(p90, p91) -- name: setPair
	for _, v92 in { "main", "shadow" } do
		local v93 = p90:FindFirstChild(v92)
		if not (v93 and v93:IsA("TextLabel")) then
			continue
		end
		v93.Text = p91
	end
end
local function v_u_136(p_u_95) -- name: bindTrophyFly
	-- upvalues: (copy) v_u_43, (copy) v_u_13, (copy) v_u_26, (copy) v_u_3, (copy) v_u_12, (copy) v_u_5, (copy) v_u_19
	local v_u_96 = v_u_43("Left.TrophyCounter")
	local v_u_97 = v_u_96:FindFirstChild("Icon", true)
	local v_u_98 = false
	local function v_u_135(p99) -- name: fly
		-- upvalues: (ref) v_u_13, (copy) p_u_95, (ref) v_u_98, (copy) v_u_96, (copy) v_u_97, (ref) v_u_26, (ref) v_u_3, (ref) v_u_12, (ref) v_u_5
		local v100 = v_u_13.number("Wins")
		local v_u_101 = p_u_95.shown()
		local v_u_102 = v100 - v_u_101
		if v_u_102 <= 0 or v_u_98 then
			if not v_u_98 then
				p_u_95.setNow(v100)
			end
		else
			v_u_98 = true
			local v103 = v_u_102 + 1
			local v104 = math.log10(v103) * 3
			local v105 = math.floor(v104) + 3
			local v_u_106 = math.clamp(v105, 4, 10)
			local v107 = v_u_96:FindFirstAncestorOfClass("ScreenGui")
			local v_u_108 = Instance.new("ScreenGui")
			v_u_108.Name = "TrophyFly"
			v_u_108.DisplayOrder = 40
			v_u_108.IgnoreGuiInset = not v107 and true or v107.IgnoreGuiInset
			v_u_108.ResetOnSpawn = false
			v_u_108.Parent = v_u_96:FindFirstAncestorOfClass("PlayerGui")
			task.delay(v_u_106 * 0.07 + 1.5, function()
				-- upvalues: (copy) v_u_108
				v_u_108:Destroy()
			end)
			local v109 = workspace.CurrentCamera
			local v_u_110
			if v109 then
				v_u_110 = v109.ViewportSize
			else
				v_u_110 = Vector2.new(1280, 720)
			end
			local v_u_111 = p99 or v_u_110 / 2
			local v_u_112
			if v_u_97 and v_u_97:IsA("GuiObject") then
				v_u_112 = v_u_97
			else
				v_u_112 = v_u_96
			end
			local v_u_113 = v_u_112.AbsolutePosition + v_u_112.AbsoluteSize / 2
			local v114 = v_u_110.Y * 0.07
			local v_u_115 = math.clamp(v114, 28, 64)
			local v_u_116 = 0
			for v117 = 1, v_u_106 do
				task.delay((v117 - 1) * 0.07, function()
					-- upvalues: (ref) v_u_26, (copy) v_u_115, (copy) v_u_108, (copy) v_u_111, (copy) v_u_113, (copy) v_u_110, (ref) v_u_3, (ref) v_u_116, (ref) p_u_95, (copy) v_u_101, (copy) v_u_102, (copy) v_u_106, (ref) v_u_12, (copy) v_u_112, (ref) v_u_5, (ref) v_u_13, (ref) v_u_98
					local v_u_118 = Instance.new("ImageLabel")
					v_u_118.Name = "FlyingTrophy"
					v_u_118.BackgroundTransparency = 1
					v_u_118.Image = v_u_26.Icon.Trophy
					v_u_118.AnchorPoint = Vector2.new(0.5, 0.5)
					v_u_118.Size = UDim2.fromOffset(v_u_115, v_u_115)
					v_u_118.ZIndex = 50
					v_u_118.Parent = v_u_108
					local v119 = math.random() * 3.141592653589793 * 2
					local v_u_120 = v_u_111 + Vector2.new(math.cos(v119), (math.sin(v119))) * v_u_115 * (0.8 + math.random())
					local v_u_121 = (v_u_120 + v_u_113) / 2 + Vector2.new(0, -v_u_110.Y * 0.12)
					local v_u_122 = os.clock()
					local v_u_123 = nil
					v_u_123 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_122, (ref) v_u_111, (copy) v_u_120, (copy) v_u_118, (ref) v_u_115, (copy) v_u_121, (ref) v_u_113, (ref) v_u_123, (ref) v_u_116, (ref) p_u_95, (ref) v_u_101, (ref) v_u_102, (ref) v_u_106, (ref) v_u_12, (ref) v_u_112, (ref) v_u_5, (ref) v_u_13, (ref) v_u_98
						local v124 = (os.clock() - v_u_122) / 0.75
						local v125
						if v124 < 0.25 then
							local v126 = 1 - (1 - v124 / 0.25) ^ 2
							v125 = v_u_111:Lerp(v_u_120, v126)
							v_u_118.Size = UDim2.fromOffset(v_u_115 * (0.4 + 0.8 * v126), v_u_115 * (0.4 + 0.8 * v126))
						else
							local v127 = (v124 - 0.25) / 0.75
							local v128 = math.clamp(v127, 0, 1)
							local v129 = v128 * v128
							v125 = v_u_120:Lerp(v_u_121, v129):Lerp(v_u_121:Lerp(v_u_113, v129), v129)
							local v130 = v_u_115 * (1.2 - v129 * 0.5)
							v_u_118.Size = UDim2.fromOffset(v130, v130)
						end
						v_u_118.Position = UDim2.fromOffset(v125.X, v125.Y)
						if v124 >= 1 then
							v_u_123:Disconnect()
							v_u_118:Destroy()
							v_u_116 = v_u_116 + 1
							local v131 = p_u_95.setNow
							local v132 = v_u_101
							local v133 = v_u_102 * v_u_116 / v_u_106
							v131(v132 + math.floor(v133))
							v_u_12.play("RouletteTick", {
								["vary"] = 0.15
							})
							local v134 = v_u_112:FindFirstChild("FlyPop")
							if not (v134 or v_u_112:FindFirstChildOfClass("UIScale")) then
								v134 = Instance.new("UIScale")
								v134.Name = "FlyPop"
								v134.Parent = v_u_112
							end
							if v134 and v134:IsA("UIScale") then
								v134.Scale = 1.25
								v_u_5:Create(v134, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
									["Scale"] = 1
								}):Play()
							end
							if v_u_106 <= v_u_116 then
								p_u_95.setNow(v_u_13.number("Wins"))
								p_u_95.badge(v_u_102)
								v_u_98 = false
							end
						end
					end)
				end)
			end
		end
	end
	v_u_19.onRelease(v_u_135)
	task.spawn(function()
		-- upvalues: (ref) v_u_98, (ref) v_u_19, (copy) p_u_95, (ref) v_u_13, (copy) v_u_135
		while true do
			repeat
				task.wait(0.5)
			until not v_u_98 and (not v_u_19.active() and p_u_95.shown() < v_u_13.number("Wins"))
			v_u_135(nil)
		end
	end)
end
local function v_u_193() -- name: bindNumbers
	-- upvalues: (copy) v_u_20, (copy) v_u_43, (copy) v_u_21, (copy) v_u_89, (copy) v_u_19, (copy) v_u_136, (copy) v_u_94, (copy) v_u_33, (copy) v_u_13, (copy) v_u_31, (copy) v_u_5, (copy) v_u_14, (copy) v_u_32, (copy) v_u_29, (copy) v_u_35, (copy) v_u_15
	v_u_20.hud(v_u_43("Left"), function(p137)
		-- upvalues: (ref) v_u_21, (ref) v_u_89
		v_u_21.bind(v_u_89(p137, "KuramaCoins", v_u_21.held), p137)
	end)
	v_u_89(v_u_43("Left.RebirthCounter"), "Rebirths")
	v_u_136((v_u_89(v_u_43("Left.TrophyCounter"), "Wins", v_u_19.active)))
	local v_u_138 = v_u_43("Bottom.Chakra")
	local function v139() -- name: chakraText
		-- upvalues: (ref) v_u_94, (copy) v_u_138, (ref) v_u_33, (ref) v_u_13
		v_u_94(v_u_138, v_u_33.short(v_u_13.number("Chakra")) .. " Chakra")
	end
	v_u_13.watch("Chakra", v139)
	local v_u_140 = v_u_43("Bottom.Stats.Multiplier")
	local v_u_141 = v_u_43("Bottom.Stats.Training")
	local v_u_142 = v_u_43("Bottom.Stats.RebirthBonus")
	local v_u_143 = v_u_43("Bottom.Stats.Pets")
	v_u_13.watch("PetMult", function()
		-- upvalues: (ref) v_u_13, (copy) v_u_143, (ref) v_u_33
		local v144 = v_u_13.number("PetMult", 1)
		v_u_143.Text = v144 <= 1 and "" or "Pets: " .. v_u_33.mult(v144)
	end)
	v_u_13.watch("Mult", function()
		-- upvalues: (copy) v_u_140, (ref) v_u_33, (ref) v_u_13
		v_u_140.Text = "Multiplier: " .. v_u_33.mult(v_u_13.number("Mult", 1))
	end)
	v_u_13.watch("TrainMult", function()
		-- upvalues: (ref) v_u_13, (copy) v_u_141, (ref) v_u_33
		local v145 = v_u_13.number("TrainMult", 1)
		v_u_141.Text = v145 <= 1 and "" or "Training: " .. v_u_33.mult(v145)
	end)
	v_u_13.watch("Rebirths", function()
		-- upvalues: (copy) v_u_142, (ref) v_u_33, (ref) v_u_31, (ref) v_u_13
		v_u_142.Text = "Rebirths: " .. v_u_33.mult(v_u_31.rebirthMult(v_u_13.number("Rebirths")))
	end)
	local v_u_146 = v_u_43("Bottom.Level.LevelText")
	local v_u_147 = v_u_43("Bottom.Level.XPText")
	local v_u_148 = v_u_43("Bottom.Level.Fill")
	local function v156() -- name: level
		-- upvalues: (ref) v_u_13, (ref) v_u_31, (copy) v_u_146, (ref) v_u_33, (copy) v_u_147, (copy) v_u_148, (ref) v_u_5
		local v149 = v_u_13.number("Level", 1)
		local v150 = v_u_13.number("XP")
		local v151 = v_u_31.xpToNext(v149)
		v_u_146.Text = "Level " .. v_u_33.commas(v149)
		v_u_147.Text = v_u_33.short(v150) .. " / " .. v_u_33.short(v151)
		local v152 = v_u_148
		local v153 = {}
		local v154 = UDim2.fromScale
		local v155 = v150 / math.max(v151, 1)
		v153.Size = v154(math.clamp(v155, 0.03, 1), 1)
		v_u_5:Create(v152, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v153):Play()
	end
	v_u_13.watch("Level", v156)
	v_u_13.watch("XP", v156)
	local v_u_157 = v_u_43("Left.RebirthPercent")
	v_u_13.watch("RebirthProgress", function()
		-- upvalues: (ref) v_u_13, (copy) v_u_157
		local v158 = v_u_13.number("RebirthProgress") * 100
		local v159 = math.floor(v158)
		v_u_157.Text = v159 .. "%"
		local v160 = v_u_157
		local v161
		if v159 >= 100 then
			v161 = Color3.fromRGB(120, 255, 90)
		else
			v161 = Color3.fromRGB(255, 255, 255)
		end
		v160.TextColor3 = v161
	end)
	local v_u_162 = v_u_43("Bottom.ChakraProducts")
	local function v168() -- name: chakraButtons
		-- upvalues: (ref) v_u_13, (copy) v_u_162, (ref) v_u_14, (ref) v_u_33
		local v163 = v_u_13.number("PaidPerSecond", v_u_13.number("PerSecond"))
		for _, v164 in { "chakra1", "chakra2", "chakra3" } do
			local v165 = v_u_162:FindFirstChild(v164)
			local v166 = v_u_14.product(v164)
			if not (v165 and (v166 and v166.seconds)) then
				continue
			end
			local v167 = v165:FindFirstChild("TextLabel")
			if not (v167 and v167:IsA("TextLabel")) then
				continue
			end
			v167.Text = "+" .. v_u_33.short(math.max(v163, 1) * v166.seconds)
		end
	end
	v_u_13.watch("PerSecond", v168)
	v_u_13.watch("PaidPerSecond", v168)
	for _, v_u_169 in { "chakra1", "chakra2", "chakra3" } do
		local v170 = v_u_162:FindFirstChild(v_u_169)
		if not (v170 and v170:IsA("GuiButton")) then
			continue
		end
		v170.Activated:Connect(function()
			-- upvalues: (ref) v_u_14, (copy) v_u_169
			v_u_14.buyProduct(v_u_169)
		end)
	end
	local v_u_171 = v_u_43("Upgrade")
	local v_u_172 = v_u_43("Upgrade.Title")
	local v_u_173 = v_u_43("Upgrade.Price")
	v_u_173.RichText = true
	local function v178() -- name: showUpgrade
		-- upvalues: (ref) v_u_32, (ref) v_u_29, (ref) v_u_35, (copy) v_u_171, (ref) v_u_15, (copy) v_u_172, (copy) v_u_173, (ref) v_u_14
		local v175 = v_u_32.next(v_u_29.chakraTiers, function(p174)
			-- upvalues: (ref) v_u_35
			return v_u_35:GetAttribute("Pass_" .. p174) == true
		end)
		local v176 = v_u_171
		local v177 = v175 ~= nil and v_u_15.known()
		if v177 then
			v177 = not v_u_15.active()
		end
		v176.Visible = v177
		if v175 then
			v_u_172.Text = v175.name
			v_u_173.Text = ("ONLY <font color=\"#5CFF6A\">%*</font>%*"):format(v_u_14.ROBUX, v175.price)
		end
	end
	v_u_35.AttributeChanged:Connect(function(p179)
		-- upvalues: (ref) v_u_32, (ref) v_u_29, (ref) v_u_35, (copy) v_u_171, (ref) v_u_15, (copy) v_u_172, (copy) v_u_173, (ref) v_u_14
		if string.sub(p179, 1, 5) == "Pass_" then
			local v181 = v_u_32.next(v_u_29.chakraTiers, function(p180)
				-- upvalues: (ref) v_u_35
				return v_u_35:GetAttribute("Pass_" .. p180) == true
			end)
			local v182 = v_u_171
			local v183 = v181 ~= nil and v_u_15.known()
			if v183 then
				v183 = not v_u_15.active()
			end
			v182.Visible = v183
			if v181 then
				v_u_172.Text = v181.name
				v_u_173.Text = ("ONLY <font color=\"#5CFF6A\">%*</font>%*"):format(v_u_14.ROBUX, v181.price)
			end
		end
	end)
	v_u_14.pricesChanged:Connect(v178)
	v_u_15.onChange(function()
		-- upvalues: (ref) v_u_32, (ref) v_u_29, (ref) v_u_35, (copy) v_u_171, (ref) v_u_15, (copy) v_u_172, (copy) v_u_173, (ref) v_u_14
		local v185 = v_u_32.next(v_u_29.chakraTiers, function(p184)
			-- upvalues: (ref) v_u_35
			return v_u_35:GetAttribute("Pass_" .. p184) == true
		end)
		local v186 = v_u_171
		local v187 = v185 ~= nil and v_u_15.known()
		if v187 then
			v187 = not v_u_15.active()
		end
		v186.Visible = v187
		if v185 then
			v_u_172.Text = v185.name
			v_u_173.Text = ("ONLY <font color=\"#5CFF6A\">%*</font>%*"):format(v_u_14.ROBUX, v185.price)
		end
	end)
	local v189 = v_u_32.next(v_u_29.chakraTiers, function(p188)
		-- upvalues: (ref) v_u_35
		return v_u_35:GetAttribute("Pass_" .. p188) == true
	end)
	local v190 = v189 ~= nil and v_u_15.known()
	if v190 then
		v190 = not v_u_15.active()
	end
	v_u_171.Visible = v190
	if v189 then
		v_u_172.Text = v189.name
		v_u_173.Text = ("ONLY <font color=\"#5CFF6A\">%*</font>%*"):format(v_u_14.ROBUX, v189.price)
	end
	v_u_171.Activated:Connect(function()
		-- upvalues: (ref) v_u_32, (ref) v_u_29, (ref) v_u_35, (ref) v_u_14
		local v192 = v_u_32.next(v_u_29.chakraTiers, function(p191)
			-- upvalues: (ref) v_u_35
			return v_u_35:GetAttribute("Pass_" .. p191) == true
		end)
		if v192 then
			v_u_14.buyPass(v192.key)
		end
	end)
end
local v_u_194 = nil
local function v_u_208(p195, p196, p197, p198, p199) -- name: popup
	-- upvalues: (copy) v_u_36, (ref) v_u_194, (copy) v_u_5
	local v_u_200 = Instance.new("Frame")
	v_u_200.BackgroundTransparency = 1
	v_u_200.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_200.Position = p198
	v_u_200.Size = UDim2.fromScale(0.16 * (p199 or 1), 0.06 * (p199 or 1))
	v_u_200.Rotation = (math.random() - 0.5) * 16
	local v201 = Instance.new("UIAspectRatioConstraint")
	v201.AspectRatio = 4
	v201.Parent = v_u_200
	local v_u_202 = Instance.new("TextLabel")
	v_u_202.BackgroundTransparency = 1
	v_u_202.Size = UDim2.fromScale(0.75, 1)
	v_u_202.FontFace = v_u_36
	v_u_202.TextScaled = true
	v_u_202.Text = p195
	v_u_202.TextColor3 = p197
	v_u_202.TextXAlignment = Enum.TextXAlignment.Right
	local v_u_203 = Instance.new("UIStroke")
	v_u_203.Thickness = 0.1
	v_u_203.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v_u_203.Parent = v_u_202
	v_u_202.Parent = v_u_200
	local v_u_204 = Instance.new("ImageLabel")
	v_u_204.BackgroundTransparency = 1
	v_u_204.Image = p196
	v_u_204.Size = UDim2.fromScale(0.25, 1.2)
	v_u_204.Position = UDim2.fromScale(0.76, -0.1)
	v_u_204.ScaleType = Enum.ScaleType.Fit
	v_u_204.Parent = v_u_200
	local v205 = Instance.new("UIScale")
	v205.Scale = 0.3
	v205.Parent = v_u_200
	v_u_200.Parent = v_u_194
	local v206 = Enum.EasingStyle.Back
	v_u_5:Create(v205, TweenInfo.new(0.22, v206 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Scale"] = 1
	}):Play()
	local v207 = {
		["Position"] = p198 - UDim2.fromScale(0, 0.08)
	}
	v_u_5:Create(v_u_200, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v207):Play()
	task.delay(0.6, function()
		-- upvalues: (copy) v_u_202, (ref) v_u_5, (copy) v_u_203, (copy) v_u_204
		v_u_5:Create(v_u_202, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["TextTransparency"] = 1
		}):Play()
		v_u_5:Create(v_u_203, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Transparency"] = 1
		}):Play()
		v_u_5:Create(v_u_204, TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["ImageTransparency"] = 1
		}):Play()
	end)
	task.delay(1.05, function()
		-- upvalues: (copy) v_u_200
		v_u_200:Destroy()
	end)
end
local v_u_209 = (-1 / 0)
local function v_u_224() -- name: bindPopups
	-- upvalues: (copy) v_u_13, (copy) v_u_11, (copy) v_u_208, (copy) v_u_33, (copy) v_u_26, (copy) v_u_43, (copy) v_u_19, (ref) v_u_209, (ref) v_u_194
	local v_u_210 = v_u_13.number("Chakra")
	local v_u_211 = 0
	v_u_13.watch("Chakra", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_210, (ref) v_u_11, (ref) v_u_211, (ref) v_u_208, (ref) v_u_33, (ref) v_u_26
		local v212 = v_u_13.number("Chakra")
		local v213 = v212 - v_u_210
		v_u_210 = v212
		local v214 = os.clock()
		if v213 <= 0 then
			return
		else
			local v215, v216 = v_u_11.takeClick()
			if (v215 or v214 - v_u_211 >= 0.6) and (not v216 or v214 - v_u_211 >= 0.3) then
				v_u_211 = v214
				local v217 = UDim2.fromScale(0.18 + math.random() * 0.64, 0.22 + math.random() * 0.46)
				v_u_208("+" .. v_u_33.short(v213), v_u_26.Icon.Chakra, Color3.fromRGB(110, 205, 255), v217, v215 and not v216 and 1.15 or 0.9)
			end
		end
	end)
	local v_u_218 = v_u_13.number("Wins")
	local v_u_219 = v_u_43("Left.TrophyCounter")
	v_u_13.watch("Wins", function()
		-- upvalues: (ref) v_u_13, (ref) v_u_218, (ref) v_u_19, (ref) v_u_209, (ref) v_u_194, (copy) v_u_219, (ref) v_u_208, (ref) v_u_33, (ref) v_u_26
		local v220 = v_u_13.number("Wins")
		local v_u_221 = v220 - v_u_218
		v_u_218 = v220
		if v_u_221 > 0 and not v_u_19.active() then
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_209, (ref) v_u_194, (ref) v_u_219, (ref) v_u_208, (ref) v_u_33, (copy) v_u_221, (ref) v_u_26
				if os.clock() - v_u_209 < 1.5 then
					return
				else
					local v222 = v_u_194.AbsoluteSize
					if v222.X > 0 and v222.Y > 0 then
						local v223 = v_u_219.AbsolutePosition + v_u_219.AbsoluteSize * Vector2.new(3.2, 0.5) - v_u_194.AbsolutePosition
						v_u_208("+" .. v_u_33.short(v_u_221), v_u_26.Icon.Trophy or v_u_26.Icon.Wins, Color3.fromRGB(255, 220, 70), UDim2.fromScale(v223.X / v222.X, v223.Y / v222.Y), 1.1)
					end
				end
			end)
		end
	end)
end
local v_u_225 = {}
local v_u_226 = false
local function v_u_345() -- name: bindBadges
	-- upvalues: (copy) v_u_43, (copy) v_u_13, (copy) v_u_225, (ref) v_u_226, (copy) v_u_18, (copy) v_u_20, (copy) v_u_26, (copy) v_u_15, (copy) v_u_34, (copy) v_u_12, (copy) v_u_3
	local v_u_227 = v_u_43("Left.Quests.Badge")
	local v_u_228 = v_u_227:FindFirstChild("Beat")
	if not (v_u_228 and v_u_228:IsA("UIScale")) then
		v_u_228 = Instance.new("UIScale")
		v_u_228.Name = "Beat"
		v_u_228.Parent = v_u_227
	end
	local function v240() -- name: quests
		-- upvalues: (ref) v_u_13, (copy) v_u_227, (copy) v_u_228, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18
		local v229 = v_u_13.questsReady() > 0
		v_u_227.Visible = v229
		local v230 = v_u_227
		local v231 = v_u_228
		if v229 then
			v_u_225[v231] = v230
			if v_u_226 then
				return
			end
			v_u_226 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
				while next(v_u_225) do
					local v232 = os.clock()
					local v233 = v_u_18.level() >= 2
					for v234, v235 in v_u_225 do
						if v235.Parent then
							local v236 = v232 * 5
							local v237 = math.sin(v236)
							v234.Scale = math.abs(v237) * 0.12 + 1
							local v238
							if v233 then
								local v239 = v232 * 11
								v238 = math.sin(v239) * 6
							else
								v238 = 0
							end
							v235.Rotation = v238
						else
							v_u_225[v234] = nil
						end
					end
					task.wait(v_u_18.frameGap(0))
				end
				v_u_226 = false
			end)
		elseif v_u_225[v231] then
			v_u_225[v231] = nil
			v231.Scale = 1
			v230.Rotation = 0
			return
		end
	end
	for _, v241 in v_u_13.QUEST_FIELDS do
		v_u_13.watch(v241, v240)
	end
	local v242 = v_u_43("Left")
	local v_u_243 = v_u_43("Left.Quests")
	local function v274(p244) -- name: bossBadge
		-- upvalues: (copy) v_u_227, (copy) v_u_243, (ref) v_u_20, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18
		if p244.Name == "BossShop" and (p244:IsA("GuiObject") and not p244:FindFirstChild("Badge")) then
			local v_u_245 = v_u_227:Clone()
			v_u_245.Rotation = 0
			local v246 = p244.Size.X.Scale
			local v247 = v_u_243.Size.X.Scale
			local v248 = v246 / math.max(v247, 0.001)
			local v249 = math.max(v248, 1)
			local v250 = v_u_227.Position
			local v251 = v_u_227.Size
			v_u_245.Size = UDim2.new(v251.X.Scale / v249, v251.X.Offset, v251.Y.Scale, v251.Y.Offset)
			v_u_245.Position = UDim2.new(1 - (1 - v250.X.Scale) / v249, v250.X.Offset, v250.Y.Scale, v250.Y.Offset)
			v_u_245.Parent = p244
			local v_u_252 = v_u_245:FindFirstChild("Beat")
			if not (v_u_252 and v_u_252:IsA("UIScale")) then
				v_u_252 = Instance.new("UIScale")
				v_u_252.Name = "Beat"
				v_u_252.Parent = v_u_245
			end
			v_u_252.Scale = 1
			local function v264() -- name: update
				-- upvalues: (ref) v_u_20, (copy) v_u_245, (copy) v_u_252, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18
				local v253 = v_u_20.affordable()
				v_u_245.Visible = v253
				local v254 = v_u_245
				local v255 = v_u_252
				if v253 then
					v_u_225[v255] = v254
					if v_u_226 then
						return
					end
					v_u_226 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
						while next(v_u_225) do
							local v256 = os.clock()
							local v257 = v_u_18.level() >= 2
							for v258, v259 in v_u_225 do
								if v259.Parent then
									local v260 = v256 * 5
									local v261 = math.sin(v260)
									v258.Scale = math.abs(v261) * 0.12 + 1
									local v262
									if v257 then
										local v263 = v256 * 11
										v262 = math.sin(v263) * 6
									else
										v262 = 0
									end
									v259.Rotation = v262
								else
									v_u_225[v258] = nil
								end
							end
							task.wait(v_u_18.frameGap(0))
						end
						v_u_226 = false
					end)
				elseif v_u_225[v255] then
					v_u_225[v255] = nil
					v255.Scale = 1
					v254.Rotation = 0
					return
				end
			end
			v_u_20.onAffordableChanged(v264)
			local v265 = v_u_20.affordable()
			v_u_245.Visible = v265
			if v265 then
				v_u_225[v_u_252] = v_u_245
				if v_u_226 then
					return
				end
				v_u_226 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
					while next(v_u_225) do
						local v266 = os.clock()
						local v267 = v_u_18.level() >= 2
						for v268, v269 in v_u_225 do
							if v269.Parent then
								local v270 = v266 * 5
								local v271 = math.sin(v270)
								v268.Scale = math.abs(v271) * 0.12 + 1
								local v272
								if v267 then
									local v273 = v266 * 11
									v272 = math.sin(v273) * 6
								else
									v272 = 0
								end
								v269.Rotation = v272
							else
								v_u_225[v268] = nil
							end
						end
						task.wait(v_u_18.frameGap(0))
					end
					v_u_226 = false
				end)
			elseif v_u_225[v_u_252] then
				v_u_225[v_u_252] = nil
				v_u_252.Scale = 1
				v_u_245.Rotation = 0
				return
			end
		end
	end
	v242.ChildAdded:Connect(v274)
	local v275 = v242:FindFirstChild("BossShop")
	if v275 then
		v274(v275)
	end
	local v_u_276 = v_u_43("TopRight.Rewards")
	local v_u_277 = v_u_43("TopRight.Rewards.Claim")
	local v_u_278 = v_u_43("TopRight.Rewards.Icon")
	local v_u_279 = v_u_278:FindFirstChild("Beat")
	if not (v_u_279 and v_u_279:IsA("UIScale")) then
		v_u_279 = Instance.new("UIScale")
		v_u_279.Name = "Beat"
		v_u_279.Parent = v_u_278
	end
	local v_u_280 = v_u_43("TopRight.Daily.Claim")
	local v_u_281 = v_u_43("TopRight.Daily.Icon")
	local v_u_282 = v_u_281:FindFirstChild("Beat")
	if not (v_u_282 and v_u_282:IsA("UIScale")) then
		v_u_282 = Instance.new("UIScale")
		v_u_282.Name = "Beat"
		v_u_282.Parent = v_u_281
	end
	local v_u_283 = v_u_43("Boosts")
	local v284 = v_u_283:FindFirstChild("wins")
	if v284 and (v284:IsA("GuiObject") and not v_u_283:FindFirstChild("luck")) then
		local v285 = v284:Clone()
		v285.Name = "luck"
		v285.Visible = false
		v285.Size = UDim2.new(1.2, 0, v284.Size.Y.Scale, v284.Size.Y.Offset)
		local v286 = v285:FindFirstChild("Icon")
		if v286 and v286:IsA("ImageLabel") then
			v286.Image = v_u_26.Icon.Boss or v286.Image
		end
		local v287 = v285:FindFirstChild("Text")
		if v287 and v287:IsA("TextLabel") then
			v287.TextColor3 = Color3.fromRGB(255, 196, 64)
		end
		v285.Parent = v_u_283
	end
	task.spawn(function()
		-- upvalues: (copy) v_u_276, (ref) v_u_13, (copy) v_u_277, (copy) v_u_278, (copy) v_u_279, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18, (copy) v_u_280, (copy) v_u_281, (copy) v_u_282, (copy) v_u_283
		while v_u_276.Parent do
			local v288 = v_u_13.giftsReady() > 0
			v_u_277.Visible = v288
			local v289 = v_u_278
			local v290 = v_u_279
			if v288 then
				v_u_225[v290] = v289
				if not v_u_226 then
					v_u_226 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
						while next(v_u_225) do
							local v291 = os.clock()
							local v292 = v_u_18.level() >= 2
							for v293, v294 in v_u_225 do
								if v294.Parent then
									local v295 = v291 * 5
									local v296 = math.sin(v295)
									v293.Scale = math.abs(v296) * 0.12 + 1
									local v297
									if v292 then
										local v298 = v291 * 11
										v297 = math.sin(v298) * 6
									else
										v297 = 0
									end
									v294.Rotation = v297
								else
									v_u_225[v293] = nil
								end
							end
							task.wait(v_u_18.frameGap(0))
						end
						v_u_226 = false
					end)
				end
			elseif v_u_225[v290] then
				v_u_225[v290] = nil
				v290.Scale = 1
				v289.Rotation = 0
			end
			local v299 = v_u_13.daily()
			v_u_280.Visible = v299 ~= nil
			local v300 = v_u_281
			local v301 = v_u_282
			if v299 ~= nil then
				v_u_225[v301] = v300
				if not v_u_226 then
					v_u_226 = true
					task.spawn(function()
						-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
						while next(v_u_225) do
							local v302 = os.clock()
							local v303 = v_u_18.level() >= 2
							for v304, v305 in v_u_225 do
								if v305.Parent then
									local v306 = v302 * 5
									local v307 = math.sin(v306)
									v304.Scale = math.abs(v307) * 0.12 + 1
									local v308
									if v303 then
										local v309 = v302 * 11
										v308 = math.sin(v309) * 6
									else
										v308 = 0
									end
									v305.Rotation = v308
								else
									v_u_225[v304] = nil
								end
							end
							task.wait(v_u_18.frameGap(0))
						end
						v_u_226 = false
					end)
				end
			elseif v_u_225[v301] then
				v_u_225[v301] = nil
				v301.Scale = 1
				v300.Rotation = 0
			end
			for _, v310 in { "chakra", "wins", "luck" } do
				local v311 = v_u_283:FindFirstChild(v310)
				local v312 = v310 == "luck" and 0 or v_u_13.boostLeft(v310)
				local v313 = 2
				local v314 = v310 == "chakra" and {
					["chakra5"] = 5,
					["chakra10"] = 10
				} or (v310 == "luck" and {
					["luck2"] = 2,
					["luck5"] = 5
				} or nil)
				if v314 then
					for v315, v316 in v314 do
						local v317 = v_u_13.boostLeft(v315)
						if v317 <= 0 or v313 >= v316 and v312 > 0 then
							continue
						end
						v312 = v317
						v313 = v316
					end
				end
				if not (v311 and v311:IsA("GuiObject")) then
					continue
				end
				v311.Visible = v312 > 0
				local v318 = v311:FindFirstChild("Text")
				if not (v318 and v318:IsA("TextLabel")) then
					continue
				end
				local v319 = string.format
				local v320 = v310 == "wins" and "Trophies" or (v310 == "luck" and "Boss Luck" or "Chakra")
				local v321 = v312 / 60
				v318.Text = v319("x%d %s %d:%02d", v313, v320, math.floor(v321), v312 % 60)
			end
			task.wait(1)
		end
	end)
	local v_u_322 = v_u_43("Left.Rebirths")
	local v_u_323 = v_u_322:FindFirstChild("Beat")
	if not (v_u_323 and v_u_323:IsA("UIScale")) then
		v_u_323 = Instance.new("UIScale")
		v_u_323.Name = "Beat"
		v_u_323.Parent = v_u_322
	end
	local v_u_324 = v_u_43("Left.RebirthPercent")
	local v_u_325 = Instance.new("ImageLabel")
	v_u_325.Name = "Glow"
	v_u_325.BackgroundTransparency = 1
	v_u_325.Image = "rbxassetid://96427887277553"
	v_u_325.ImageColor3 = Color3.fromRGB(190, 120, 255)
	v_u_325.Size = UDim2.fromScale(1.9, 1.9)
	v_u_325.Position = UDim2.fromScale(0.5, 0.5)
	v_u_325.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_325.ZIndex = 0
	v_u_325.Visible = false
	v_u_325.Parent = v_u_322
	local v_u_326 = false
	v_u_13.watch("RebirthProgress", function()
		-- upvalues: (ref) v_u_13, (copy) v_u_325, (copy) v_u_322, (copy) v_u_323, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18, (ref) v_u_15, (ref) v_u_326, (ref) v_u_34, (ref) v_u_12
		local v327 = v_u_13.number("RebirthProgress") >= 1
		v_u_325.Visible = v327
		local v328 = v_u_322
		local v329 = v_u_323
		if v327 then
			v_u_225[v329] = v328
			if not v_u_226 then
				v_u_226 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
					while next(v_u_225) do
						local v330 = os.clock()
						local v331 = v_u_18.level() >= 2
						for v332, v333 in v_u_225 do
							if v333.Parent then
								local v334 = v330 * 5
								local v335 = math.sin(v334)
								v332.Scale = math.abs(v335) * 0.12 + 1
								local v336
								if v331 then
									local v337 = v330 * 11
									v336 = math.sin(v337) * 6
								else
									v336 = 0
								end
								v333.Rotation = v336
							else
								v_u_225[v332] = nil
							end
						end
						task.wait(v_u_18.frameGap(0))
					end
					v_u_226 = false
				end)
			end
		elseif v_u_225[v329] then
			v_u_225[v329] = nil
			v329.Scale = 1
			v328.Rotation = 0
		end
		local v338 = v_u_15.active()
		if v338 then
			v338 = v_u_15.step() ~= "rebirth"
		end
		if v327 and not (v_u_326 or v338) then
			v_u_34.notify("You can REBIRTH now!", Color3.fromRGB(150, 60, 255))
			v_u_12.play("RevealBig", {
				["volume"] = 0.5
			})
		end
		v_u_326 = v327
	end)
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_325, (copy) v_u_324
		if v_u_325.Visible then
			local v339 = os.clock()
			v_u_325.Rotation = v339 * 60 % 360
			local v340 = v_u_325
			local v341 = v339 * 6
			v340.ImageTransparency = math.sin(v341) * 0.2 + 0.25
			local v342 = v_u_324
			local v343 = v339 * 4
			local v344
			if math.floor(v343) % 2 == 0 then
				v344 = Color3.fromRGB(120, 255, 90)
			else
				v344 = Color3.fromRGB(255, 255, 120)
			end
			v342.TextColor3 = v344
		end
	end)
end
local v_u_346 = 0
local function v_u_360(p347) -- name: stageTitle
	-- upvalues: (copy) v_u_27, (copy) v_u_13, (ref) v_u_346, (copy) v_u_43, (copy) v_u_33, (copy) v_u_5, (copy) v_u_12
	local v348 = v_u_27.forWorld(v_u_13.number("RunWorld", 1))[p347]
	if v348 then
		v_u_346 = v_u_346 + 1
		local v_u_349 = v_u_346
		local v_u_350 = v_u_43("Overlay.Title")
		local v351 = v_u_43("Overlay.Title.Main")
		local v352 = v_u_43("Overlay.Title.Sub")
		v351.Text = "STAGE " .. p347
		v352.Text = "RECOMMENDED CHAKRA " .. v_u_33.short(v348.recommended)
		local v353
		if v_u_13.number("Chakra") >= v348.recommended then
			v353 = Color3.fromRGB(127, 240, 255)
		else
			v353 = Color3.fromRGB(255, 110, 110)
		end
		v352.TextColor3 = v353
		v_u_350.Visible = true
		v_u_350.Position = UDim2.fromScale(-0.4, 0.22)
		local v354 = {
			["Position"] = UDim2.fromScale(0.5, 0.2)
		}
		local v355 = Enum.EasingStyle.Back
		v_u_5:Create(v_u_350, TweenInfo.new(0.3, v355 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v354):Play()
		v_u_12.play("StageStart")
		task.delay(1.6, function()
			-- upvalues: (copy) v_u_349, (ref) v_u_346, (copy) v_u_350, (ref) v_u_5
			if v_u_349 == v_u_346 then
				local v356 = v_u_350
				local v357 = {
					["Position"] = UDim2.fromScale(1.4, 0.18)
				}
				local v358 = Enum.EasingStyle.Quad
				local v359 = Enum.EasingDirection.In
				v_u_5:Create(v356, TweenInfo.new(0.3, v358 or Enum.EasingStyle.Quad, v359 or Enum.EasingDirection.Out), v357):Play()
				task.delay(0.32, function()
					-- upvalues: (ref) v_u_349, (ref) v_u_346, (ref) v_u_350
					if v_u_349 == v_u_346 then
						v_u_350.Visible = false
					end
				end)
			end
		end)
	end
end
local v_u_361 = 0
local function v_u_368(p362, p363) -- name: banner
	-- upvalues: (ref) v_u_361, (copy) v_u_43, (copy) v_u_5
	v_u_361 = v_u_361 + 1
	local v_u_364 = v_u_361
	local v_u_365 = v_u_43("Overlay.Banner")
	v_u_365.Text = p362
	v_u_365.TextColor3 = p363
	v_u_365.TextTransparency = 0
	v_u_365.Visible = true
	local v366 = v_u_365:FindFirstChild("Grow")
	if not v366 then
		v366 = Instance.new("UIScale")
		v366.Name = "Grow"
		v366.Parent = v_u_365
	end
	if v366 and v366:IsA("UIScale") then
		v366.Scale = 0.2
		local v367 = Enum.EasingStyle.Back
		v_u_5:Create(v366, TweenInfo.new(0.3, v367 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end
	task.delay(1.4, function()
		-- upvalues: (copy) v_u_364, (ref) v_u_361, (copy) v_u_365, (ref) v_u_5
		if v_u_364 == v_u_361 then
			v_u_5:Create(v_u_365, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			task.delay(0.3, function()
				-- upvalues: (ref) v_u_364, (ref) v_u_361, (ref) v_u_365
				if v_u_364 == v_u_361 then
					v_u_365.Visible = false
				end
			end)
		end
	end)
end
local function v_u_386() -- name: bindBoss
	-- upvalues: (copy) v_u_43, (copy) v_u_8, (copy) v_u_24, (copy) v_u_33, (copy) v_u_368, (copy) v_u_5
	local v_u_369 = v_u_43("Top.Boss")
	local v_u_370 = v_u_43("Top.Boss.Back.Fill")
	local v_u_371 = v_u_43("Top.Boss.Back.Name")
	local v_u_372 = v_u_43("Top.Boss.Back.Hp")
	local v_u_373 = nil
	local v_u_374 = 1
	v_u_369.Visible = false
	v_u_8.on("spawn", function(p375)
		-- upvalues: (ref) v_u_24, (ref) v_u_373, (ref) v_u_374, (copy) v_u_371, (copy) v_u_372, (ref) v_u_33, (copy) v_u_370, (copy) v_u_369, (ref) v_u_368
		if p375.boss == true then
			local v376 = p375.hp
			if type(v376) == "number" then
				local v377 = v_u_24.byId[p375.kind]
				v_u_373 = p375.id
				v_u_374 = p375.hp
				v_u_371.Text = not v377 and "Boss" or v377.name
				v_u_372.Text = v_u_33.short(p375.hp) .. " / " .. v_u_33.short(p375.hp)
				v_u_370.Size = UDim2.fromScale(1, 1)
				v_u_369.Visible = true
				v_u_368("BOSS: " .. string.upper(v_u_371.Text), Color3.fromRGB(255, 80, 90))
				return
			end
		end
	end)
	v_u_8.on("hit", function(p378)
		-- upvalues: (ref) v_u_373, (copy) v_u_372, (ref) v_u_33, (ref) v_u_374, (copy) v_u_370, (ref) v_u_5
		if p378.id == v_u_373 then
			local v379 = p378.hp
			if type(v379) == "number" then
				v_u_372.Text = v_u_33.short(p378.hp) .. " / " .. v_u_33.short(v_u_374)
				local v380 = v_u_370
				local v381 = {}
				local v382 = UDim2.fromScale
				local v383 = p378.hp / v_u_374
				v381.Size = v382(math.clamp(v383, 0, 1), 1)
				v_u_5:Create(v380, TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v381):Play()
			end
		end
	end)
	local function v384() -- name: hide
		-- upvalues: (ref) v_u_373, (copy) v_u_369
		v_u_373 = nil
		v_u_369.Visible = false
	end
	v_u_8.on("die", function(p385)
		-- upvalues: (ref) v_u_373, (copy) v_u_369
		if p385.id == v_u_373 then
			v_u_373 = nil
			v_u_369.Visible = false
		end
	end)
	v_u_8.on("reset", v384)
	v_u_8.on("clear", v384)
end
local function v_u_424() -- name: bindSkills
	-- upvalues: (copy) v_u_43, (copy) v_u_9, (copy) v_u_7, (copy) v_u_13, (copy) v_u_25, (copy) v_u_37, (copy) v_u_26, (copy) v_u_23, (copy) v_u_11, (copy) v_u_3
	local v_u_387 = v_u_43("Skills.Attack")
	local v_u_388 = v_u_43("Skills.E")
	local v_u_389 = v_u_43("Skills.R")
	local v_u_390 = {}
	for v391, v392 in {
		[v_u_387] = Enum.KeyCode.ButtonR2,
		[v_u_388] = Enum.KeyCode.ButtonL1,
		[v_u_389] = Enum.KeyCode.ButtonR1
	} do
		local v393 = v391:FindFirstChild("Key")
		if v393 and v393:IsA("GuiObject") then
			table.insert(v_u_390, v393)
			local v394 = v393.Position
			local v395 = v393.Size
			local v396 = v393.AnchorPoint
			local v397 = UDim2.new(v394.X.Scale + (0.5 - v396.X) * v395.X.Scale, v394.X.Offset + (0.5 - v396.X) * v395.X.Offset, v394.Y.Scale + (0.5 - v396.Y) * v395.Y.Scale, v394.Y.Offset + (0.5 - v396.Y) * v395.Y.Offset)
			v_u_9.hint(v391, v392, 34, v397)
		else
			v_u_9.hint(v391, v392, 34)
		end
	end
	local function v400() -- name: showKeys
		-- upvalues: (copy) v_u_390, (ref) v_u_7, (ref) v_u_9
		for _, v398 in v_u_390 do
			local v399 = not v_u_7.touch()
			if v399 then
				v399 = not v_u_9.active()
			end
			v398.Visible = v399
		end
	end
	v400()
	v_u_9.changed:Connect(v400)
	local v401 = v_u_387:FindFirstChild("Key")
	if v401 then
		v401 = v401:FindFirstChild("Text")
	end
	if v401 and v401:IsA("TextLabel") then
		v401.Text = "M1"
	end
	v_u_13.watch("Eye", function()
		-- upvalues: (ref) v_u_25, (ref) v_u_13, (ref) v_u_37, (ref) v_u_26, (copy) v_u_387, (copy) v_u_388, (copy) v_u_389, (ref) v_u_23
		local v402 = v_u_25.byId[v_u_13.string("Eye", v_u_25.STARTER)] or v_u_25.byId[v_u_25.STARTER]
		local v403 = v_u_37[v402.id] or v_u_26.Iris.sharingan
		for _, v404 in {
			{
				["slot"] = "attack",
				["b"] = nil,
				["b"] = v_u_387
			},
			{
				["slot"] = "E",
				["b"] = nil,
				["b"] = v_u_388
			},
			{
				["slot"] = "R",
				["b"] = nil,
				["b"] = v_u_389
			}
		} do
			local v405 = v404.b:FindFirstChild("Icon")
			if v405 and v405:IsA("ImageLabel") then
				v405.Image = v403
			end
			local v406 = v404.b:FindFirstChild("TextLabel")
			if not (v406 and v406:IsA("TextLabel")) then
				continue
			end
			local v407
			if v404.slot == "attack" then
				v407 = v402.attack
			elseif v404.slot == "E" then
				v407 = v402.skillE
			else
				v407 = v402.skillR
			end
			v406.Text = v404.slot == "attack" and "ATTACK" or string.upper(v_u_23.byId[v407].name)
		end
	end)
	v_u_387.InputBegan:Connect(function(p408)
		-- upvalues: (ref) v_u_11
		if p408.UserInputType == Enum.UserInputType.Touch or p408.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_11.hold(true)
		end
	end)
	v_u_387.InputEnded:Connect(function(p409)
		-- upvalues: (ref) v_u_11
		if p409.UserInputType == Enum.UserInputType.Touch or p409.UserInputType == Enum.UserInputType.MouseButton1 then
			v_u_11.hold(false)
		end
	end)
	v_u_388.Activated:Connect(function()
		-- upvalues: (ref) v_u_11
		v_u_11.press("E")
	end)
	v_u_389.Activated:Connect(function()
		-- upvalues: (ref) v_u_11
		v_u_11.press("R")
	end)
	local function v414(p410) -- name: coverOf
		local v411 = p410:FindFirstChild("Cooldown")
		local v412 = p410:FindFirstChild("CooldownText")
		local v413 = {
			["cd"] = nil,
			["text"] = nil,
			["share"] = -1,
			["shown"] = "?"
		}
		if not (v411 and v411:IsA("GuiObject")) then
			v411 = nil
		end
		v413.cd = v411
		if not (v412 and v412:IsA("TextLabel")) then
			v412 = nil
		end
		v413.text = v412
		return v413
	end
	local v_u_415 = {
		{
			["button"] = nil,
			["slot"] = "attack",
			["cover"] = nil,
			["button"] = v_u_387,
			["cover"] = v414(v_u_387)
		},
		{
			["button"] = nil,
			["slot"] = "E",
			["cover"] = nil,
			["button"] = v_u_388,
			["cover"] = v414(v_u_388)
		},
		{
			["button"] = nil,
			["slot"] = "R",
			["cover"] = nil,
			["button"] = v_u_389,
			["cover"] = v414(v_u_389)
		}
	}
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_415, (ref) v_u_11
		for _, v416 in v_u_415 do
			local v417, v418 = v_u_11.cooldown(v416.slot)
			local v419 = v416.cover
			local v420
			if v418 > 0 then
				local v421 = v417 / v418
				local v422 = math.clamp(v421, 0, 1) * 100
				v420 = math.floor(v422) / 100
			else
				v420 = 0
			end
			if v420 ~= v419.share then
				v419.share = v420
				if v419.cd then
					v419.cd.Size = UDim2.fromScale(1, v420)
				end
			end
			local v423 = (v417 <= 0.05 or v418 < 1) and "" or string.format("%.1f", v417)
			if v423 == v419.shown then
				continue
			end
			v419.shown = v423
			if not v419.text then
				continue
			end
			v419.text.Text = v423
		end
	end)
end
local v_u_425 = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 60, 60)),
	ColorSequenceKeypoint.new(0.17, Color3.fromRGB(255, 170, 30)),
	ColorSequenceKeypoint.new(0.33, Color3.fromRGB(255, 240, 60)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(70, 255, 110)),
	ColorSequenceKeypoint.new(0.67, Color3.fromRGB(60, 200, 255)),
	ColorSequenceKeypoint.new(0.83, Color3.fromRGB(150, 80, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 60, 60))
})
local function v_u_514() -- name: bindAutoClick
	-- upvalues: (copy) v_u_43, (copy) v_u_14, (copy) v_u_425, (copy) v_u_3, (copy) v_u_10, (copy) v_u_30, (copy) v_u_34, (copy) v_u_225, (ref) v_u_226, (copy) v_u_18, (copy) v_u_9, (copy) v_u_12
	local v_u_426 = v_u_43("Bottom.AutoClickers")
	local v_u_427 = v_u_43("Bottom.AutoClickers.AutoFree")
	local v_u_428 = v_u_43("Bottom.AutoClickers.AutoOp")
	local v_u_429 = v_u_43("Bottom.AutoClickers.AutoFree.Sub")
	local v_u_430 = v_u_43("Bottom.AutoClickers.AutoFree.Load.Fill")
	local v_u_431 = v_u_43("Bottom.AutoClickers.AutoFree.Load")
	local v_u_432 = v_u_43("Bottom.AutoClickers.AutoOp.Sub")
	local v433 = v_u_43("Bottom.AutoClickers.AutoOpName")
	v_u_432.RichText = true
	local v_u_434 = v_u_427:FindFirstChild("Beat")
	if not (v_u_434 and v_u_434:IsA("UIScale")) then
		v_u_434 = Instance.new("UIScale")
		v_u_434.Name = "Beat"
		v_u_434.Parent = v_u_427
	end
	local v_u_435 = v_u_428:FindFirstChild("Beat")
	if not (v_u_435 and v_u_435:IsA("UIScale")) then
		v_u_435 = Instance.new("UIScale")
		v_u_435.Name = "Beat"
		v_u_435.Parent = v_u_428
	end
	local v_u_436 = (v_u_14.product("autoOp") or {
		["price"] = 0
	}).price
	local v_u_437 = v_u_428:FindFirstChildOfClass("UIGradient")
	local v_u_438 = v433:FindFirstChildOfClass("UIGradient")
	for _, v439 in { v_u_437, v_u_438 } do
		if not v439 then
			continue
		end
		v439.Color = v_u_425
	end
	local v_u_440 = Instance.new("Frame")
	v_u_440.Name = "Streak"
	v_u_440.BackgroundColor3 = Color3.new(1, 1, 1)
	v_u_440.BorderSizePixel = 0
	v_u_440.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_440.Size = UDim2.fromScale(0.16, 1.6)
	v_u_440.Rotation = 20
	v_u_440.ZIndex = 6
	local v441 = Instance.new("UIGradient")
	v441.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(0.5, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v441.Parent = v_u_440
	v_u_440.Parent = v_u_428
	v_u_428.ClipsDescendants = true
	v_u_3.RenderStepped:Connect(function()
		-- upvalues: (copy) v_u_426, (copy) v_u_437, (copy) v_u_438, (copy) v_u_440
		if v_u_426.Visible then
			local v442 = os.clock()
			if v_u_437 then
				local v443 = v_u_437
				local v444 = Vector2.new
				local v445 = v442 * 1.3
				v443.Offset = v444(math.sin(v445) * 0.5, 0)
				v_u_437.Rotation = v442 * 40 % 360
			end
			if v_u_438 then
				v_u_438.Offset = Vector2.new(v442 * 0.6 % 2 - 1, 0)
			end
			local v446 = v442 % 1.6 / 1.6
			v_u_440.Position = UDim2.fromScale(-0.3 + v446 * 1.6, 0.5)
		end
	end)
	local v_u_447 = v_u_10.freeLeft() <= 0
	local function v_u_507() -- name: show
		-- upvalues: (ref) v_u_10, (ref) v_u_30, (copy) v_u_431, (copy) v_u_430, (copy) v_u_429, (copy) v_u_427, (ref) v_u_447, (ref) v_u_34, (copy) v_u_434, (ref) v_u_225, (ref) v_u_226, (ref) v_u_18, (ref) v_u_9, (ref) v_u_12, (copy) v_u_432, (ref) v_u_14, (copy) v_u_436, (copy) v_u_428, (copy) v_u_435
		local v448 = v_u_10.freeLeft()
		local v449 = v448 <= 0
		local v450 = v_u_10.freeUseLeft()
		local v451 = v450 == (1 / 0)
		local v452 = v451 and 1 or v450 / v_u_30.autoFreeFor
		local v453
		if v451 then
			v453 = ""
		else
			local v454 = " "
			local v455 = math.ceil(v450)
			local v456 = math.max(v455, 0)
			local v457
			if v456 >= 3600 then
				v457 = string.format("%d:%02d:%02d", v456 // 3600, v456 // 60 % 60, v456 % 60)
			else
				v457 = string.format("%d:%02d", v456 // 60, v456 % 60)
			end
			v453 = v454 .. v457
		end
		v_u_431.Visible = true
		if v449 then
			if v_u_10.freeOn() then
				v_u_430.Size = UDim2.fromScale(v452, 1)
				v_u_429.Text = "ON" .. v453
				v_u_429.TextColor3 = Color3.fromRGB(255, 255, 255)
				local v458 = v_u_427
				local v459 = Color3.fromRGB(58, 255, 14)
				local v460 = Color3.fromRGB(40, 196, 14)
				local v461 = v458:FindFirstChildOfClass("UIGradient")
				if v461 then
					v461.Color = ColorSequence.new(v459, v460)
				end
			else
				v_u_430.Size = UDim2.fromScale(v452, 1)
				v_u_429.Text = "OFF" .. v453
				v_u_429.TextColor3 = Color3.fromRGB(255, 255, 255)
				local v462 = v_u_427
				local v463 = Color3.fromRGB(69, 200, 255)
				local v464 = Color3.fromRGB(0, 128, 255)
				local v465 = v462:FindFirstChildOfClass("UIGradient")
				if v465 then
					v465.Color = ColorSequence.new(v463, v464)
				end
			end
		else
			v_u_430.Size = UDim2.fromScale(1 - v448 / v_u_30.autoFreeAfter, 1)
			local v466 = v_u_429
			local v467 = math.ceil(v448)
			local v468 = math.max(v467, 0)
			local v469
			if v468 >= 3600 then
				v469 = string.format("%d:%02d:%02d", v468 // 3600, v468 // 60 % 60, v468 % 60)
			else
				v469 = string.format("%d:%02d", v468 // 60, v468 % 60)
			end
			v466.Text = v469
			v_u_429.TextColor3 = Color3.fromRGB(255, 40, 40)
			local v470 = v_u_427
			local v471 = Color3.fromRGB(150, 152, 165)
			local v472 = Color3.fromRGB(90, 92, 104)
			local v473 = v470:FindFirstChildOfClass("UIGradient")
			if v473 then
				v473.Color = ColorSequence.new(v471, v472)
			end
		end
		if v_u_447 and not v449 then
			local v474 = v_u_34.notify
			local v475 = "Free Auto Clicker ran out! Ready again in "
			local v476 = math.ceil(v448)
			local v477 = math.max(v476, 0)
			local v478
			if v477 >= 3600 then
				v478 = string.format("%d:%02d:%02d", v477 // 3600, v477 // 60 % 60, v477 % 60)
			else
				v478 = string.format("%d:%02d", v477 // 60, v477 % 60)
			end
			v474(v475 .. v478, Color3.fromRGB(220, 40, 60))
		end
		local v479 = v_u_427
		local v480 = v449 and not v_u_10.freeOn()
		if v480 then
			v480 = not v_u_10.opOn()
		end
		local v481 = v_u_434
		if v480 then
			v_u_225[v481] = v479
			if not v_u_226 then
				v_u_226 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
					while next(v_u_225) do
						local v482 = os.clock()
						local v483 = v_u_18.level() >= 2
						for v484, v485 in v_u_225 do
							if v485.Parent then
								local v486 = v482 * 5
								local v487 = math.sin(v486)
								v484.Scale = math.abs(v487) * 0.12 + 1
								local v488
								if v483 then
									local v489 = v482 * 11
									v488 = math.sin(v489) * 6
								else
									v488 = 0
								end
								v485.Rotation = v488
							else
								v_u_225[v484] = nil
							end
						end
						task.wait(v_u_18.frameGap(0))
					end
					v_u_226 = false
				end)
			end
		elseif v_u_225[v481] then
			v_u_225[v481] = nil
			v481.Scale = 1
			v479.Rotation = 0
		end
		if v449 and not v_u_447 then
			v_u_34.notify(not v_u_9.active() and "Free Auto Clicker is ready! Tap it" or ("Free Auto Clicker is ready! Press %*"):format((v_u_9.name(Enum.KeyCode.DPadDown))), Color3.fromRGB(40, 200, 60))
			v_u_12.play("RevealBig", {
				["volume"] = 0.5
			})
		end
		v_u_447 = v449
		local v490 = v_u_10.opLeft()
		if v490 <= 0 then
			v_u_432.Text = ("<font color=\"#FFFFFF\">%*</font>%*"):format(v_u_14.ROBUX, (v_u_14.product("autoOp") or {
				["price"] = v_u_436
			}).price)
			v_u_432.TextColor3 = Color3.fromRGB(255, 255, 255)
		else
			local v491 = v_u_432
			local v492 = math.ceil(v490)
			local v493 = math.max(v492, 0)
			local v494
			if v493 >= 3600 then
				v494 = string.format("%d:%02d:%02d", v493 // 3600, v493 // 60 % 60, v493 % 60)
			else
				v494 = string.format("%d:%02d", v493 // 60, v493 % 60)
			end
			v491.Text = v494
			local v495 = v_u_432
			local v496
			if v_u_10.opOn() then
				v496 = Color3.fromRGB(255, 40, 40)
			else
				v496 = Color3.fromRGB(230, 230, 235)
			end
			v495.TextColor3 = v496
		end
		local v497 = v_u_428
		local v498 = v_u_435
		if v_u_10.opOn() or v490 <= 0 then
			v_u_225[v498] = v497
			if v_u_226 then
				return
			end
			v_u_226 = true
			task.spawn(function()
				-- upvalues: (ref) v_u_225, (ref) v_u_18, (ref) v_u_226
				while next(v_u_225) do
					local v499 = os.clock()
					local v500 = v_u_18.level() >= 2
					for v501, v502 in v_u_225 do
						if v502.Parent then
							local v503 = v499 * 5
							local v504 = math.sin(v503)
							v501.Scale = math.abs(v504) * 0.12 + 1
							local v505
							if v500 then
								local v506 = v499 * 11
								v505 = math.sin(v506) * 6
							else
								v505 = 0
							end
							v502.Rotation = v505
						else
							v_u_225[v501] = nil
						end
					end
					task.wait(v_u_18.frameGap(0))
				end
				v_u_226 = false
			end)
		elseif v_u_225[v498] then
			v_u_225[v498] = nil
			v498.Scale = 1
			v497.Rotation = 0
			return
		end
	end
	v_u_10.onChange(v_u_507)
	task.spawn(function()
		-- upvalues: (copy) v_u_427, (copy) v_u_507
		while v_u_427.Parent do
			v_u_507()
			task.wait(0.25)
		end
	end)
	v_u_427.Activated:Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_34, (ref) v_u_12, (copy) v_u_507
		if v_u_10.toggleFree() then
			v_u_34.notify(v_u_10.freeOn() and "Auto Clicker ON" or "Auto Clicker OFF", Color3.fromRGB(40, 200, 60))
			v_u_507()
		else
			local v508 = v_u_34.notify
			local v509 = "The free Auto Clicker loads in "
			local v510 = v_u_10.freeLeft()
			local v511 = math.ceil(v510)
			local v512 = math.max(v511, 0)
			local v513
			if v512 >= 3600 then
				v513 = string.format("%d:%02d:%02d", v512 // 3600, v512 // 60 % 60, v512 % 60)
			else
				v513 = string.format("%d:%02d", v512 // 60, v512 % 60)
			end
			v508(v509 .. v513, Color3.fromRGB(220, 40, 60))
			v_u_12.play("Error")
		end
	end)
	v_u_428.Activated:Connect(function()
		-- upvalues: (ref) v_u_10, (ref) v_u_14
		if not v_u_10.toggleOp() then
			v_u_14.buyProduct("autoOp")
		end
	end)
end
local v_u_515 = {
	"Left.Store",
	"Left.Quests",
	"Left.MyEyes",
	"Left.Auras",
	"Left.Pets",
	"TopRight",
	"Boosts",
	"Bottom.ChakraProducts",
	"Bottom.AutoClickers"
}
local function v_u_539() -- name: bindTutorial
	-- upvalues: (copy) v_u_515, (copy) v_u_43, (copy) v_u_5, (copy) v_u_15
	local v_u_516 = {}
	for _, v517 in v_u_515 do
		local v518 = v_u_43(v517)
		table.insert(v_u_516, v518)
	end
	local v_u_519 = { v_u_43("Left.Rebirths"), (v_u_43("Left.RebirthPercent")) }
	local function v_u_536(p520, p521) -- name: gate
		-- upvalues: (ref) v_u_15, (copy) v_u_516, (ref) v_u_5, (copy) v_u_519
		local v522 = not v_u_15.known() or v_u_15.active()
		local v523 = v_u_15.step()
		local v524 = not v522 or (v523 == "level" and true or v523 == "rebirth")
		local v525
		if p520 == "done" and p521 ~= nil then
			v525 = p521 ~= "done"
		else
			v525 = false
		end
		for v526, v527 in v_u_516 do
			v527.Visible = not v522
			if not v525 then
				continue
			end
			local v528 = v526 * 0.08 + 0.6
			local v_u_529 = v527:FindFirstChild("Pop")
			if not (v_u_529 and v_u_529:IsA("UIScale")) then
				v_u_529 = Instance.new("UIScale")
				v_u_529.Name = "Pop"
				v_u_529.Parent = v527
			end
			v_u_529.Scale = 0
			task.delay(v528, function()
				-- upvalues: (copy) v_u_529, (ref) v_u_5
				local v530 = v_u_529
				local v531 = Enum.EasingStyle.Back
				v_u_5:Create(v530, TweenInfo.new(0.35, v531 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			end)
		end
		for _, v532 in v_u_519 do
			if v524 and (not v532.Visible and (v_u_15.known() and v522)) then
				local v_u_533 = v532:FindFirstChild("Pop")
				if not (v_u_533 and v_u_533:IsA("UIScale")) then
					v_u_533 = Instance.new("UIScale")
					v_u_533.Name = "Pop"
					v_u_533.Parent = v532
				end
				v_u_533.Scale = 0
				task.delay(0, function()
					-- upvalues: (copy) v_u_533, (ref) v_u_5
					local v534 = v_u_533
					local v535 = Enum.EasingStyle.Back
					v_u_5:Create(v534, TweenInfo.new(0.35, v535 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = 1
					}):Play()
				end)
			end
			v532.Visible = v524
		end
	end
	v_u_536()
	v_u_15.onChange(function(p537, p538)
		-- upvalues: (copy) v_u_536
		v_u_536(p537, p538)
	end)
end
local v_u_540 = nil
local function v_u_548(p541, p542, p543) -- name: childBox
	local v544 = p541.Size.X.Scale * p542 + p541.Size.X.Offset
	local v545 = p541.Size.Y.Scale * p543 + p541.Size.Y.Offset
	local v546 = p541:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v546 and (v546.AspectRatio > 0 and v545 > 0) then
		local v547 = v546.AspectRatio
		if v547 < v544 / v545 then
			v544 = v545 * v547
		else
			v545 = v544 / v547
		end
	end
	return p541.Position.X.Scale * p542 + p541.Position.X.Offset - p541.AnchorPoint.X * v544, p541.Position.Y.Scale * p543 + p541.Position.Y.Offset - p541.AnchorPoint.Y * v545, v544, v545
end
local v_u_549 = nil
local v_u_550 = nil
local function v_u_557(p551) -- name: leftSpan
	local v552 = (1 / 0)
	local v553 = (-1 / 0)
	for _, v554 in p551:GetChildren() do
		if not (v554:IsA("GuiObject") and v554.Visible) then
			continue
		end
		local v555 = v554.Position.Y.Scale - v554.AnchorPoint.Y * v554.Size.Y.Scale
		v552 = math.min(v552, v555)
		local v556 = v555 + v554.Size.Y.Scale
		v553 = math.max(v553, v556)
	end
	if v553 < v552 then
		return 0, 1
	else
		return v552, v553
	end
end
local function v_u_564(p558) -- name: thumbstickTop
	-- upvalues: (copy) v_u_35
	local v559 = p558.AbsoluteSize.Y
	local v560 = v_u_35.PlayerGui:FindFirstChild("TouchGui")
	if v560 then
		for _, v561 in { "ThumbstickStart", "ThumbstickFrame" } do
			local v562 = v560:FindFirstChild(v561, true)
			if not v562 or (not v562:IsA("GuiObject") or v562.AbsoluteSize.Y <= 0) then
				continue
			end
			return v562.AbsolutePosition.Y - p558.AbsolutePosition.Y
		end
	end
	local v563 = p558.AbsoluteSize.X
	return v559 - (math.min(v563, v559) <= 500 and 150 or 260)
end
local function v_u_588() -- name: placeLeft
	-- upvalues: (ref) v_u_39, (ref) v_u_549, (ref) v_u_550, (copy) v_u_20, (copy) v_u_548, (copy) v_u_557, (copy) v_u_7, (copy) v_u_564
	local v565 = v_u_39:FindFirstChild("Left")
	local v566 = v_u_549
	local v567 = v_u_550
	local v568 = v_u_39.Parent
	if v565 and (v565:IsA("GuiObject") and (v566 and (v567 and (v568 and v568:IsA("GuiBase2d"))))) then
		v565.Size = v567
		v565.Position = v566
		local v569 = v568.AbsoluteSize.X
		local v570 = v568.AbsoluteSize.Y
		if v_u_20.hudShown() and v570 > 0 then
			local _, _, _, v571 = v_u_548(v565, v569, v570)
			local v572, v573 = v_u_557(v565)
			local v574 = (v573 - v572) * v571
			local v575 = v566.Y.Scale * v570 + v566.Y.Offset - v565.AnchorPoint.Y * v571
			local v576 = -v568.AbsolutePosition.Y
			local v577 = math.max(0, v576) + 6
			local v578 = 1
			local v579, v580
			if v_u_7.touch() then
				v579 = v_u_564(v568) - 6
				local v581 = v575 + v572 * v571
				v580 = math.max(v581, v577)
			else
				v579 = v570 - 6
				local v582 = v_u_39:FindFirstChild("Boosts")
				if v582 and (v582:IsA("GuiObject") and v582.Parent == v_u_39) then
					local _, v583 = v_u_548(v582, v569, v570)
					v579 = v583 - 6
				end
				local v584 = v575 + v571 / 2 - v574 / 2
				v580 = math.max(v584, v577)
			end
			if v579 < v580 + v574 then
				local v585 = v579 - v574
				v580 = math.max(v577, v585)
				local v586 = (v579 - v580) / v574
				v578 = math.clamp(v586, 0.75, 1)
			end
			local v587 = v571 * v578
			v565.Size = UDim2.new(v567.X.Scale * v578, v567.X.Offset * v578, v567.Y.Scale * v578, v567.Y.Offset * v578)
			v565.Position = UDim2.new(v566.X.Scale, v566.X.Offset, 0, v580 - v572 * v587 + v565.AnchorPoint.Y * v587)
		end
	else
		return
	end
end
local v_u_589 = nil
local function v_u_647() -- name: touchLayout
	-- upvalues: (copy) v_u_588, (ref) v_u_540, (copy) v_u_43, (ref) v_u_589, (copy) v_u_7, (ref) v_u_39, (copy) v_u_35, (copy) v_u_548
	v_u_588()
	local v590 = v_u_540 or {
		["skills"] = v_u_43("Skills"),
		["bottom"] = v_u_43("Bottom"),
		["upgrade"] = v_u_43("Upgrade"),
		["boosts"] = v_u_43("Boosts"),
		["autos"] = v_u_43("Bottom.AutoClickers"),
		["stats"] = v_u_43("Bottom.Stats"),
		["left"] = v_u_43("Left")
	}
	v_u_540 = v590
	local v591 = v590.skills
	local v592 = v590.bottom
	local v593 = v590.upgrade
	local v594 = v590.boosts
	local v595 = v_u_589 or {}
	if not v_u_589 then
		for _, v596 in {
			v591,
			v592,
			v593,
			v594,
			v590.autos
		} do
			v595[v596] = {
				["parent"] = v596.Parent,
				["position"] = v596.Position,
				["size"] = v596.Size,
				["anchor"] = v596.AnchorPoint
			}
		end
		v_u_589 = v595
	end
	if not v_u_7.touch() then
		for v597, v598 in v595 do
			v597.Parent = v598.parent
			v597.AnchorPoint = v598.anchor
			v597.Position = v598.position
			v597.Size = v598.size
		end
		return
	end
	local v599 = v_u_39.Parent
	if not (v599 and v599:IsA("GuiBase2d")) then
		return
	end
	local v600 = v599.AbsoluteSize.X
	local v601 = v599.AbsoluteSize.Y
	if v600 < 100 or v601 < 100 then
		return
	end
	local v602 = math.min(v600, v601) <= 500
	local v603 = v602 and 70 or 120
	local v604 = v600 - (v602 and 95 or 170)
	local v605 = v601 - (v602 and 90 or 210)
	local v606 = v_u_35.PlayerGui:FindFirstChild("TouchGui")
	if v606 then
		v606 = v606:FindFirstChild("JumpButton", true)
	end
	if v606 and (v606:IsA("GuiObject") and v606.AbsoluteSize.X > 0) then
		v603 = v606.AbsoluteSize.X
		v604 = v606.AbsolutePosition.X - v599.AbsolutePosition.X
		v605 = v606.AbsolutePosition.Y - v599.AbsolutePosition.Y
	end
	local v607 = v591:FindFirstChildOfClass("UIAspectRatioConstraint")
	local v608 = (not v607 or v607.AspectRatio <= 0) and 1.15 or v607.AspectRatio
	local v609 = v601 * (v602 and 0.44 or 0.34) * v608
	local v610 = v600 * 0.3
	local v611 = math.min(v609, v610) * 0.85
	local v612 = v611 / v608
	local v613 = v600 - (v602 and 6 or 24)
	local v614 = v605 - 4
	v591.AnchorPoint = Vector2.new(1, 1)
	v591.Position = UDim2.fromOffset(v613, v614)
	v591.Size = UDim2.fromOffset(v611, v612)
	local v615 = {
		{
			v604,
			v605,
			v604 + v603,
			v605 + v603
		}
	}
	for _, v616 in v591:GetChildren() do
		if not v616:IsA("GuiButton") then
			continue
		end
		local v617, v618, v619, v620 = v_u_548(v616, v611, v612)
		local v621 = v613 - v611 + v617
		local v622 = v614 - v612 + v618
		local v623 = {
			v621,
			v622,
			v621 + v619,
			v622 + v620
		}
		table.insert(v615, v623)
	end
	local v624 = v592:FindFirstChildOfClass("UIAspectRatioConstraint")
	local v625 = (not v624 or v624.AspectRatio <= 0) and 2.81 or v624.AspectRatio
	local v626, v627, v628
	if v602 then
		v626 = 0.26
		v627 = 0.74
		v628 = 0.21
	else
		v626 = 0.36
		v627 = 0.62
		v628 = 0.15
	end
	local v629, v630, v631, v632 = v_u_548(v590.left, v600, v601)
	local v633 = v600 * (v602 and 0.54 or 0.5)
	local v634 = v601 * (v602 and 0.34 or 0.29) * v625
	local v635 = math.min(v633, v634) * 0.85
	local v636 = v600 / 2 - v635 / 2
	for _ = 1, 30 do
		local v637 = v635 / v625
		local v638 = v601 - 6 - v637
		local v639 = v635 * (v628 * 1.075 + 1.01)
		local v640 = v630 + v632 <= v638 - v637 * 0.31 and 6 or v629 + v631 + 6
		local v641 = v600 - 6
		for _, v642 in v615 do
			if v638 >= v642[4] then
				continue
			end
			local v643 = v642[1] - 6
			v641 = math.min(v641, v643)
		end
		if v639 <= v641 - v640 or v635 < v600 * 0.25 then
			local v644 = v600 / 2 - v635 / 2
			local v645 = v641 - v639
			local v646 = math.max(v640, v645)
			v636 = math.clamp(v644, v640, v646)
			break
		end
		v635 = v635 * 0.96
	end
	v592.AnchorPoint = Vector2.new(0, 1)
	v592.Position = UDim2.fromOffset(v636, v601 - 6)
	v592.Size = UDim2.fromOffset(v635, v635 / v625)
	v590.autos.Position = UDim2.fromScale(1.01, v626)
	v590.autos.Size = UDim2.fromScale(v628, v627)
	v594.Parent = v592
	v594.AnchorPoint = Vector2.new(0, 1)
	v594.Position = UDim2.fromScale(0.02, -0.01)
	v594.Size = UDim2.fromScale(0.34, 0.3)
	v593.AnchorPoint = Vector2.new(1, 0)
	v593.Position = UDim2.new(1, -8, 0.13, 16)
end
local v_u_648 = {
	[Enum.KeyCode.DPadLeft] = { "Left" },
	[Enum.KeyCode.ButtonSelect] = { "Left", "TopRight" },
	[Enum.KeyCode.DPadUp] = { "TopRight" },
	[Enum.KeyCode.DPadDown] = { "Bottom.ChakraProducts", "Bottom.AutoClickers" },
	[Enum.KeyCode.DPadRight] = { "Promo", "Upgrade", "LuckLadder" }
}
local function v_u_652(p649) -- name: node
	-- upvalues: (ref) v_u_39
	local v650 = v_u_39
	for v651 in string.gmatch(p649, "[^%.]+") do
		if not v650 then
			continue
		end
		v650 = v650:FindFirstChild(v651)
	end
	if v650 and v650:IsA("GuiObject") then
		return v650
	else
		return nil
	end
end
local function v_u_674() -- name: bindPad
	-- upvalues: (copy) v_u_9, (copy) v_u_648, (copy) v_u_652, (ref) v_u_39
	v_u_9.onEnter(function(p653)
		-- upvalues: (ref) v_u_648, (ref) v_u_9, (ref) v_u_652
		local v654 = v_u_648[p653]
		if not v654 or v_u_9.captured() then
			return false
		end
		for _, v655 in v654 do
			local v656 = v_u_652(v655)
			if not (v656 and v_u_9.shown(v656)) then
				continue
			end
			v_u_9.select(v656)
			if not v_u_9.selected() then
				continue
			end
			return true
		end
		return false
	end, 0)
	v_u_9.onBack(function(p657)
		-- upvalues: (ref) v_u_39, (ref) v_u_9
		if not (p657 and p657:IsDescendantOf(v_u_39)) then
			return false
		end
		v_u_9.clear()
		return true
	end, 0)
	local v658 = Enum.KeyCode.DPadLeft
	local v659 = UDim2.fromOffset(4, 4)
	local v660 = v_u_652("Left.Store")
	if v660 then
		v_u_9.hint(v660, v658, 34, v659)
	end
	local v661 = Enum.KeyCode.DPadUp
	local v662 = UDim2.new(0, -12, 0.4, 0)
	local v663 = v_u_652("TopRight.Codes")
	if v663 then
		v_u_9.hint(v663, v661, 34, v662)
	end
	local v664 = Enum.KeyCode.DPadDown
	local v665 = UDim2.new(0, -14, 0.5, 0)
	local v666 = v_u_652("Bottom.ChakraProducts.chakra1")
	if v666 then
		v_u_9.hint(v666, v664, 34, v665)
	end
	local v667 = Enum.KeyCode.DPadRight
	local v668 = UDim2.fromOffset(4, 4)
	local v669 = v_u_652("Upgrade")
	local v_u_670
	if v669 then
		v_u_670 = v_u_9.hint(v669, v667, 34, v668)
	else
		v_u_670 = nil
	end
	if v_u_670 then
		task.spawn(function()
			-- upvalues: (copy) v_u_670, (ref) v_u_652, (ref) v_u_9
			while v_u_670.Parent do
				local v671 = v_u_652("Promo.Offer")
				local v672
				if v671 == nil then
					v672 = false
				else
					v672 = v671.Visible
				end
				local v673 = v_u_9.active()
				if v673 then
					v673 = not v672
				end
				if v_u_670.Visible ~= v673 then
					v_u_670.Visible = v673
				end
				task.wait(0.5)
			end
		end)
	end
end
function v_u_34.start() -- name: start
	-- upvalues: (copy) v_u_35, (ref) v_u_39, (copy) v_u_38, (copy) v_u_9, (ref) v_u_549, (ref) v_u_550, (copy) v_u_3, (ref) v_u_589, (copy) v_u_647, (ref) v_u_44, (copy) v_u_43, (ref) v_u_45, (ref) v_u_194, (copy) v_u_193, (copy) v_u_224, (copy) v_u_386, (copy) v_u_424, (copy) v_u_345, (copy) v_u_514, (copy) v_u_539, (copy) v_u_674, (copy) v_u_6, (copy) v_u_20, (copy) v_u_4, (copy) v_u_34, (copy) v_u_8, (copy) v_u_360, (copy) v_u_368, (copy) v_u_12, (copy) v_u_17, (ref) v_u_209, (copy) v_u_208, (copy) v_u_33, (copy) v_u_26, (copy) v_u_14, (copy) v_u_5, (copy) v_u_25, (copy) v_u_13, (copy) v_u_28, (copy) v_u_16, (copy) v_u_11
	local v675 = v_u_35:WaitForChild("PlayerGui"):WaitForChild("Main")
	v_u_39 = v675:WaitForChild("HUD")
	local v_u_676 = {}
	for _, v677 in v_u_38 do
		local v678 = v_u_39:WaitForChild(v677, 10)
		if not (v678 and v678:IsA("GuiObject")) then
			continue
		end
		v_u_676[v678] = {
			["size"] = v678.Size,
			["position"] = v678.Position
		}
	end
	local function v_u_687() -- name: scaleGroups
		-- upvalues: (ref) v_u_9, (copy) v_u_676, (ref) v_u_39, (ref) v_u_549, (ref) v_u_550
		local v679 = v_u_9.tv()
		local v680 = v679 and 0.95 or 0.85
		for v681, v682 in v_u_676 do
			local v683 = v682.size
			local v684 = v682.position
			v681.Size = UDim2.new(v683.X.Scale * v680, v683.X.Offset * v680, v683.Y.Scale * v680, v683.Y.Offset * v680)
			if v679 then
				v684 = UDim2.new(0.5 + (v684.X.Scale - 0.5) * 0.9, v684.X.Offset, 0.5 + (v684.Y.Scale - 0.5) * 0.9, v684.Y.Offset)
			end
			v681.Position = v684
		end
		local v685 = v_u_39:FindFirstChild("Notifications")
		if v679 and (v685 and (v685:IsA("GuiObject") and v_u_676[v685])) then
			v685.Position = v685.Position - UDim2.fromScale(0.07, 0)
		end
		local v686 = v_u_39:FindFirstChild("Left")
		if v686 and (v686:IsA("GuiObject") and v_u_676[v686]) then
			v_u_549 = v686.Position
			v_u_550 = v686.Size
		end
	end
	v_u_687()
	if v_u_3:IsStudio() then
		v_u_35:GetAttributeChangedSignal("DevTV"):Connect(function()
			-- upvalues: (copy) v_u_687, (ref) v_u_589, (ref) v_u_647
			v_u_687()
			v_u_589 = nil
			v_u_647()
		end)
	end
	v_u_44 = v_u_43("Notifications")
	local v688 = v_u_44:FindFirstChild("Template")
	if v688 and v688:IsA("Frame") then
		v688.Visible = false
		v688.Parent = nil
		v_u_45 = v688
	end
	v_u_194 = v_u_43("Overlay.Popups")
	v_u_193()
	v_u_224()
	v_u_386()
	v_u_424()
	v_u_345()
	v_u_514()
	v_u_539()
	v_u_674()
	v_u_647()
	v675:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_647)
	v_u_35.PlayerGui.ChildAdded:Connect(function(p689)
		-- upvalues: (ref) v_u_647
		if p689.Name == "TouchGui" then
			task.delay(0.5, v_u_647)
		end
	end)
	v_u_6:GetPropertyChangedSignal("PreferredInput"):Connect(v_u_647)
	v_u_20.hudChanged:Connect(v_u_647)
	v_u_43("TopRight.Invite").Activated:Connect(function()
		-- upvalues: (ref) v_u_4, (ref) v_u_35, (ref) v_u_34
		local function v690()
			-- upvalues: (ref) v_u_4, (ref) v_u_35
			return v_u_4:CanSendGameInviteAsync(v_u_35)
		end
		local v691, v692 = pcall(v690)
		if v691 and v692 then
			local function v693()
				-- upvalues: (ref) v_u_4, (ref) v_u_35
				v_u_4:PromptGameInvite(v_u_35)
			end
			pcall(v693)
		else
			v_u_34.notify("Invites are not available here")
		end
	end)
	v_u_8.on("start", function(p694)
		-- upvalues: (ref) v_u_360
		local v695 = p694.stage
		if type(v695) == "number" then
			v_u_360(p694.stage)
		end
	end)
	v_u_8.on("clear", function()
		-- upvalues: (ref) v_u_368, (ref) v_u_12, (ref) v_u_35, (ref) v_u_17
		v_u_368("WAVE CLEAR", Color3.fromRGB(255, 214, 64))
		v_u_12.play("WaveClear")
		local v696 = v_u_35.Character
		if v696 then
			v696 = v_u_35.Character:FindFirstChild("HumanoidRootPart")
		end
		if v696 and v696:IsA("BasePart") then
			v_u_17.burst("Sparkle", v696.Position + Vector3.new(0, 2, 0), nil, 1)
		end
	end)
	v_u_8.on("pad", function(p697)
		-- upvalues: (ref) v_u_209, (ref) v_u_208, (ref) v_u_33, (ref) v_u_26
		v_u_209 = os.clock()
		local v698 = p697.wins
		if type(v698) == "number" then
			v_u_208("+" .. v_u_33.short(p697.wins), v_u_26.Icon.Trophy or v_u_26.Icon.Wins, Color3.fromRGB(255, 220, 70), UDim2.fromScale(0.5, 0.3), 2.2)
		end
	end)
	v_u_8.on("vip", function()
		-- upvalues: (ref) v_u_34, (ref) v_u_14
		v_u_34.notify("The purple pad gives x3 Trophies with the x3 Wins Pad pass", Color3.fromRGB(150, 60, 255))
		v_u_14.offerPass("winsPad")
	end)
	local v_u_699 = v_u_43("Overlay.LevelUp")
	v_u_699.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_699.Position = UDim2.fromScale(0.5, 0.175)
	v_u_699.Size = UDim2.fromScale(0.3, 0.05)
	v_u_699.ZIndex = 6
	local v_u_700 = v_u_699:FindFirstChildOfClass("UIStroke")
	local v_u_701 = Instance.new("UIScale")
	v_u_701.Parent = v_u_699
	local v_u_702 = 0
	local v_u_703 = 0
	local v_u_704 = (-1 / 0)
	local function v_u_710() -- name: levelZoom
		-- upvalues: (ref) v_u_704, (ref) v_u_5
		local v_u_705 = workspace.CurrentCamera
		local v706 = os.clock()
		if v_u_705 and v706 - v_u_704 >= 2 then
			local v707 = v_u_705.FieldOfView - 70
			if math.abs(v707) <= 0.5 then
				v_u_704 = v706
				local v708 = v_u_5:Create(v_u_705, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["FieldOfView"] = 66
				})
				v708.Completed:Once(function()
					-- upvalues: (copy) v_u_705, (ref) v_u_5
					local v709 = v_u_705.FieldOfView - 66
					if math.abs(v709) < 0.5 then
						v_u_5:Create(v_u_705, TweenInfo.new(0.45, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut), {
							["FieldOfView"] = 70
						}):Play()
					end
				end)
				v708:Play()
				return
			end
		end
	end
	local v_u_711 = v675:FindFirstChild("Frames")
	local function v_u_713() -- name: menuOpen
		-- upvalues: (copy) v_u_711
		if not v_u_711 then
			return false
		end
		for _, v712 in v_u_711:GetChildren() do
			if not (v712:IsA("GuiObject") and v712.Visible) then
				continue
			end
			return true
		end
		return false
	end
	v_u_8.onNotify("LevelUp", function(p714)
		-- upvalues: (copy) v_u_713, (ref) v_u_703, (ref) v_u_12, (copy) v_u_710, (copy) v_u_699, (copy) v_u_700, (copy) v_u_701, (ref) v_u_5, (ref) v_u_702
		if v_u_713() then
			local v715 = os.clock()
			if v715 - v_u_703 > 0.8 then
				v_u_703 = v715
				v_u_12.play("LevelUp")
			end
		else
			v_u_710()
			v_u_699.Text = "LEVEL UP (" .. tostring(p714) .. ")"
			v_u_699.TextTransparency = 0
			if v_u_700 then
				v_u_700.Transparency = 0
			end
			v_u_699.Visible = true
			v_u_701.Scale = 1.15
			v_u_5:Create(v_u_701, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			v_u_702 = v_u_702 + 1
			local v_u_716 = v_u_702
			task.delay(1.4, function()
				-- upvalues: (copy) v_u_716, (ref) v_u_702, (ref) v_u_699, (ref) v_u_5, (ref) v_u_700
				if v_u_716 == v_u_702 then
					v_u_5:Create(v_u_699, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["TextTransparency"] = 1
					}):Play()
					if v_u_700 then
						v_u_5:Create(v_u_700, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
							["Transparency"] = 1
						}):Play()
					end
					task.delay(0.3, function()
						-- upvalues: (ref) v_u_716, (ref) v_u_702, (ref) v_u_699
						if v_u_716 == v_u_702 then
							v_u_699.Visible = false
						end
					end)
				end
			end)
			local v717 = os.clock()
			if v717 - v_u_703 > 0.8 then
				v_u_703 = v717
				v_u_12.play("LevelUp")
			end
		end
	end)
	v_u_8.onNotify("TutorialGift", function(p718)
		-- upvalues: (ref) v_u_368, (ref) v_u_33, (ref) v_u_12
		if type(p718) ~= "table" then
			p718 = nil
		end
		if p718 then
			p718 = p718.trophies
		end
		if type(p718) == "number" then
			v_u_368("+" .. v_u_33.short(p718) .. " FREE TROPHIES!", Color3.fromRGB(255, 214, 64))
			v_u_12.play("RevealBig")
		end
	end)
	v_u_8.onNotify("Rebirth", function(p719)
		-- upvalues: (ref) v_u_368, (ref) v_u_12
		v_u_368("REBIRTH " .. tostring(p719) .. "!", Color3.fromRGB(212, 155, 255))
		v_u_12.play("Rebirth")
	end)
	local function v_u_722() -- name: offerSkipEye
		-- upvalues: (ref) v_u_14, (ref) v_u_25, (ref) v_u_13, (ref) v_u_34
		if v_u_14.quiet() then
			return false
		end
		local v720 = v_u_25.nextLocked(v_u_13.eyes(), v_u_13.number("World", 1))
		local v721 = v_u_14.product("skipEye")
		if not v720 or (not v721 or v721.id == 0) then
			return false
		end
		v_u_34.notify("Skip to " .. v720.short .. " now!", Color3.fromRGB(255, 170, 0))
		v_u_14.offerProduct("skipEye", 2)
		return true
	end
	v_u_8.onNotify("EyePad", function(p723)
		-- upvalues: (ref) v_u_25, (ref) v_u_368, (ref) v_u_17, (ref) v_u_12, (ref) v_u_35, (ref) v_u_34, (ref) v_u_33, (copy) v_u_722, (ref) v_u_14
		if type(p723) == "table" then
			local v724 = p723.eye
			local v725
			if type(v724) == "string" then
				v725 = v_u_25.byId[p723.eye]
			else
				v725 = nil
			end
			if v725 then
				if p723.result == "unlocked" then
					v_u_368("UNLOCKED " .. string.upper(v725.short) .. "!", v_u_17.color(v_u_25.RARITY_COLOR[v725.rarity]))
					v_u_12.play("RevealBig")
					local v726 = v_u_35.Character
					if v726 then
						v726 = v_u_35.Character:FindFirstChild("HumanoidRootPart")
					end
					if v726 and v726:IsA("BasePart") then
						v_u_17.burst("Sparkle", v726.Position, nil, 1.5)
						return
					end
				else
					if p723.result == "equipped" then
						v_u_34.notify("Equipped " .. v725.name, Color3.fromRGB(40, 200, 60))
						v_u_12.play("Equip")
						return
					end
					if p723.result == "world" then
						local v727 = v_u_34.notify
						local v728 = v725.world or 1
						v727("Reach World " .. tostring(v728) .. " to unlock " .. v725.short, Color3.fromRGB(220, 40, 60))
						v_u_12.play("Error")
						return
					end
					if p723.result == "need" then
						v_u_34.notify("You need " .. v_u_33.short(v725.wins) .. " total Trophies for " .. v725.short, Color3.fromRGB(220, 40, 60))
						v_u_12.play("Error")
						if not v_u_722() then
							v_u_14.offer("trophies", "Eye Pad")
							return
						end
					elseif p723.result == "order" then
						local v729 = v_u_25.previous(v725.id)
						v_u_34.notify("Unlock " .. (not v729 and "the eye before" or v729.short) .. " first", Color3.fromRGB(220, 40, 60))
						v_u_12.play("Error")
						v_u_722()
					end
				end
			end
		else
			return
		end
	end)
	v_u_8.onNotify("TrainRobux", function(p730)
		-- upvalues: (ref) v_u_28, (ref) v_u_13, (ref) v_u_34, (ref) v_u_33, (ref) v_u_14
		local v731 = v_u_28.forWorld(v_u_13.number("World", 1))[type(p730) ~= "number" and 1 or p730]
		if v731 and v731.pass then
			v_u_34.notify(("%*: %* Chakra with Robux"):format(v731.name, (v_u_33.mult(v731.mult))), Color3.fromRGB(255, 170, 0))
			v_u_14.offerPass(v731.pass)
		end
	end)
	v_u_8.onNotify("Boost", function(p732)
		-- upvalues: (ref) v_u_34, (ref) v_u_12
		v_u_34.notify(tostring(p732) .. " is on!", Color3.fromRGB(40, 200, 60))
		v_u_12.play("Boost")
	end)
	v_u_8.onNotify("StageLocked", function(p733)
		-- upvalues: (ref) v_u_34, (ref) v_u_33, (ref) v_u_12, (ref) v_u_16
		if type(p733) == "table" then
			local v734 = p733.stage
			local v735 = p733.need
			if type(v734) == "number" and type(v735) == "number" then
				v_u_34.notify(("Stage %* needs %* Trophies"):format(v734, (v_u_33.short(v735))), Color3.fromRGB(220, 40, 60))
				v_u_12.play("Error")
				v_u_16.arrived(v734, v735)
			end
		end
	end)
	v_u_8.onNotify("TrainLocked", function(p736)
		-- upvalues: (ref) v_u_28, (ref) v_u_13, (ref) v_u_34, (ref) v_u_12, (ref) v_u_14
		local v737 = v_u_28.forWorld(v_u_13.number("World", 1))[type(p736) ~= "number" and 1 or p736]
		if v737 then
			v_u_34.notify(("%* needs %* Rebirths"):format(v737.name, v737.rebirths), Color3.fromRGB(220, 40, 60))
			v_u_12.play("Error")
			v_u_14.offer("rebirth")
		end
	end)
	v_u_35.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_11
		v_u_11.hold(false)
	end)
end
return v_u_34