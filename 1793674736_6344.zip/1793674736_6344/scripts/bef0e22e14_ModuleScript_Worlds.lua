local v1 = require(script.Parent.Release)
return {
	{
		["id"] = 1,
		["name"] = "Shinobi Lands",
		["color"] = "#45C8FF",
		["ready"] = true,
		["image"] = "rbxassetid://70946750290690"
	},
	{
		["id"] = 2,
		["name"] = "Celestial Realm",
		["color"] = "#B45CFF",
		["ready"] = true,
		["needStage"] = 15,
		["image"] = "rbxassetid://99971442275534"
	},
	{
		["id"] = 3,
		["name"] = "Blood Moon",
		["color"] = "#FF2E4D",
		["ready"] = true,
		["needStage"] = 15,
		["image"] = "rbxassetid://109304008010104"
	},
	{
		["id"] = 4,
		["name"] = "Frozen Abyss",
		["color"] = "#3FB8FF",
		["ready"] = true,
		["needStage"] = 15,
		["image"] = "rbxassetid://74188975343783"
	},
	{
		["id"] = 5,
		["name"] = "Cosmic Void",
		["color"] = "#9B5CFF",
		["ready"] = nil,
		["needStage"] = 15,
		["image"] = "rbxassetid://81199196135443",
		["ready"] = v1.on(2)
	},
	{
		["id"] = 6,
		["name"] = "Soul Society",
		["color"] = "#FF7FB8",
		["ready"] = nil,
		["needStage"] = 15,
		["ready"] = v1.on(4)
	},
	{
		["id"] = 7,
		["name"] = "Hueco Mundo",
		["color"] = "#2EE6C9",
		["ready"] = nil,
		["needStage"] = 15,
		["ready"] = v1.on(4)
	},
	{
		["id"] = 8,
		["name"] = "Infinity Castle",
		["color"] = "#FF1A2E",
		["ready"] = nil,
		["needStage"] = 15,
		["ready"] = v1.on(4)
	}
}