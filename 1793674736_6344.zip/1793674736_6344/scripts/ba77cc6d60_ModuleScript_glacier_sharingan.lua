local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = Color3.new(1, 1, 1)
local v_u_6 = Color3.fromRGB(205, 245, 255)
local v_u_7 = Color3.fromRGB(150, 230, 255)
local function v_u_14(p8, p9, p10) -- name: face
	local v11 = p10 - p9 * p10:Dot(p9)
	local v12
	if v11.Magnitude > 0.001 then
		v12 = v11.Unit
	else
		local v13 = p9.Y
		v12 = math.abs(v13) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p8, p9:Cross(v12), p9, v12)
end
return function(p_u_15)
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_1, (copy) v_u_14
	return {
		["w4_glacier_sharingan"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_3, (copy) p_u_15, (ref) v_u_6, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (ref) v_u_1, (ref) v_u_14
			local v_u_18 = v_u_3.color(p17.color)
			local v19 = v_u_3.color(p17.color2)
			local v20 = p_u_16.headY / 1.5
			local v_u_21 = math.clamp(v20, 0.7, 3)
			local v_u_22 = p_u_15.crownOf(p_u_16)
			local v_u_23 = v_u_21 * 2.9
			local v_u_24 = v_u_21 * 3
			local v_u_25 = v_u_21 * 1.7
			local v_u_26 = v_u_21 * 1
			local v_u_27 = Vector3.new(0, 0, 0)
			local v_u_28 = Vector3.new(0, 0, 1)
			local v_u_29 = Vector3.new(0, 1, 0)
			local v30 = p_u_16.ticks
			local function v34(p31)
				-- upvalues: (ref) v_u_27, (copy) v_u_22, (copy) p_u_16, (ref) p_u_15, (ref) v_u_28, (ref) v_u_29
				v_u_27 = v_u_22(p31).Position + Vector3.new(0, 1, 0) * p_u_16.eyeLift
				local v32 = p_u_15.camPos() - v_u_27
				v_u_28 = v32.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v32.Unit
				local v33 = Vector3.new(0, 1, 0) - v_u_28 * (Vector3.new(0, 1, 0)):Dot(v_u_28)
				v_u_29 = v33.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v33.Unit
			end
			table.insert(v30, v34)
			p_u_15.throb(p_u_16, 4.4, 2.579, 2.2, function(p35)
				-- upvalues: (ref) v_u_3, (ref) v_u_27, (ref) v_u_6, (copy) v_u_21, (copy) p_u_16, (ref) p_u_15, (copy) v_u_18, (ref) v_u_4
				v_u_3.flash(v_u_27, v_u_6, v_u_21 * 4 * p_u_16.fx, 0.25)
				v_u_3.ring(p_u_15.feetAt(p_u_16, p35, 0.15), v_u_18, 7 * p_u_16.fx, 0.55, v_u_4.Ring)
			end)
			local v_u_36 = {}
			local v_u_37 = {}
			local v_u_38 = {}
			v_u_36[1] = CFrame.identity
			v_u_37[1] = v_u_24
			v_u_38[1] = 0
			v_u_36[2] = CFrame.identity
			v_u_37[2] = v_u_24
			v_u_38[2] = 0
			v_u_36[3] = CFrame.identity
			v_u_37[3] = v_u_24
			v_u_38[3] = 0
			local function v_u_48(p39, p40) -- name: splash
				-- upvalues: (ref) v_u_3, (ref) v_u_6, (copy) v_u_21, (copy) p_u_16, (ref) v_u_4, (copy) v_u_18, (ref) v_u_5, (ref) v_u_7, (ref) v_u_1
				v_u_3.ring(p39, v_u_6, v_u_21 * 3.2 * p_u_16.fx, 0.4, v_u_4.Shockwave)
				v_u_3.burst("Impact", p39 + Vector3.new(0, 0.6, 0), v_u_18, v_u_21 * 0.8)
				for v41 = 1, 3 do
					local v42 = v_u_3.part
					local v43 = Vector3.new(0.35, 1.3, 0.35) * v_u_21
					local v44 = CFrame.new(p39) * CFrame.Angles(0, v41 * 2.1 + p40, (v41 - 2) * 0.45)
					local v45
					if v41 == 2 then
						v45 = v_u_5
					else
						v45 = v_u_7
					end
					local v46 = v42(v43, v44, v45, {
						["material"] = nil,
						["transparency"] = 0.15,
						["material"] = Enum.Material.Glass
					})
					local v47 = v46.CFrame
					v_u_3.tween(v46, 0.4, {
						["CFrame"] = nil,
						["Size"] = Vector3.new(0.05, 0.4, 0.05),
						["Transparency"] = 1,
						["CFrame"] = v47 * CFrame.new(0, v_u_21 * 1.4, 0)
					})
					v_u_1:AddItem(v46, 0.45)
				end
			end
			local v49 = p_u_16.ticks
			local function v88(p50, p51)
				-- upvalues: (copy) p_u_16, (ref) v_u_29, (ref) v_u_28, (copy) v_u_24, (copy) v_u_23, (copy) v_u_36, (copy) v_u_37, (ref) v_u_14, (ref) v_u_27, (copy) v_u_26, (copy) v_u_21, (copy) v_u_25, (copy) v_u_38, (ref) p_u_15, (copy) v_u_48
				local v52 = p50.Position
				local v53 = v52.Y + p_u_16.feet
				local v54
				if p51 >= 2 then
					local v55 = (p51 - 2) / 4.4
					v54 = math.floor(v55)
				else
					v54 = -1
				end
				local v56 = v54 < 0 and -1 or p51 - 2 - v54 * 4.4
				local v57 = p51 * 5.5
				local v58 = v_u_29:Cross(v_u_28)
				for v59 = 1, 3 do
					local v60 = -p51 * 1.15 + (v59 - 1) * 6.283185307179586 / 3
					local v61 = math.cos(v60)
					local v62 = math.sin(v60)
					local v63 = Vector3.new(v61, 0, v62)
					local v64 = v_u_24 * 0.1
					local v65 = p51 * 2.4 + v59 * 2.1
					local v66 = v64 * (math.sin(v65) * 0.5 + 0.5)
					local v67 = v52.X
					local v68 = v53 + v_u_24 * 0.33 - v66
					local v69 = v52.Z
					local v70 = Vector3.new(v67, v68, v69) + v63 * v_u_23
					local v71 = CFrame.fromMatrix(v70, v63:Cross(Vector3.new(0, 1, 0)), v63, Vector3.new(0, 1, 0))
					local v72 = v56 < 0 and -1 or (v56 - (v59 - 1) * 0.12) / 1.35
					local v73
					if v72 > 0 and v72 < 1 then
						if v72 < 0.34 then
							local v74 = v72 / 0.34
							local v75 = math.clamp(v74, 0, 1)
							v73 = v75 * v75 * (3 - v75 * 2)
						elseif v72 < 0.66 then
							v73 = 1
						else
							local v76 = (v72 - 0.66) / 0.33999999999999997
							local v77 = math.clamp(v76, 0, 1)
							v73 = 1 - v77 * v77 * (3 - v77 * 2)
						end
					else
						v73 = 0
					end
					if v73 <= 0 then
						v_u_36[v59] = v71
						v_u_37[v59] = v_u_24
					else
						local v78 = v57 + (v59 - 1) * 6.283185307179586 / 3
						local v79 = v58 * math.cos(v78) + v_u_29 * math.sin(v78)
						local v80 = v_u_14(v_u_27 + v79 * v_u_26 + v_u_28 * 0.25, v_u_28, v79)
						local v81 = v73 * 3.141592653589793
						local v82 = math.sin(v81)
						local v83 = v70:Lerp(v80.Position, v73) + v63 * v82 * 1.4 * v_u_21 + Vector3.new(0, 1, 0) * v82 * 1.2 * v_u_21
						v_u_36[v59] = v71:Lerp(v80, v73).Rotation + v83
						v_u_37[v59] = v_u_24 + (v_u_25 - v_u_24) * v73
					end
					if v72 < 1 or v_u_38[v59] >= v54 + 1 then
						continue
					end
					v_u_38[v59] = v54 + 1
					if (v52 - p_u_15.camPos()).Magnitude >= 150 then
						continue
					end
					local v84 = v_u_48
					local v85 = v70.X
					local v86 = v53 + 0.2
					local v87 = v70.Z
					v84(Vector3.new(v85, v86, v87), v59)
				end
			end
			table.insert(v49, v88)
			local v_u_89 = v_u_28
			local v_u_90 = v_u_29
			local v_u_91 = v_u_27
			for v_u_92 = 1, 3 do
				local v_u_93, v94 = p_u_15.picture(v_u_24, v_u_4.GlacierBlade, v_u_18, 0)
				for _, v95 in v94 do
					v95.Color3 = Color3.new(v_u_18.R * 1.6, v_u_18.G * 1.6, v_u_18.B * 1.6)
				end
				p_u_15.add(p_u_16, v_u_93, function()
					-- upvalues: (copy) v_u_37, (copy) v_u_92, (copy) v_u_93, (copy) v_u_36
					local v96 = v_u_37[v_u_92]
					v_u_93.Size = Vector3.new(v96, 0.05, v96)
					return v_u_36[v_u_92]
				end)
				local v97 = p_u_15.tail(v_u_93, v_u_5, v_u_18, v_u_21 * 0.6, 0.45)
				local v98 = v97.Attachment0
				local v99 = v97.Attachment1
				if not (v98 and v99) then
					break
				end
				local v100 = v_u_24 * -0.33 + v_u_21 * 0.35
				v98.Position = Vector3.new(0, 0, v100)
				local v101 = v_u_24 * -0.33 - v_u_21 * 0.15
				v99.Position = Vector3.new(0, 0, v101)
			end
			local v_u_102, v_u_103 = p_u_15.picture(1, v_u_4.GlacierMark, v_u_18, 1)
			for _, v104 in v_u_103 do
				v104.Color3 = Color3.new(v_u_18.R * 1.4, v_u_18.G * 1.4, v_u_18.B * 1.4)
			end
			local v_u_105 = -1
			p_u_15.add(p_u_16, v_u_102, function(_, p106)
				-- upvalues: (ref) v_u_105, (copy) v_u_103, (copy) v_u_21, (copy) v_u_102, (ref) v_u_90, (ref) v_u_89, (ref) v_u_14, (ref) v_u_91
				local v107 = ((p106 < 2 and -1 or (p106 - 2) % 4.4) - 0.4590000000000001) / 0.672
				local v108
				if v107 > 0 and v107 < 1 then
					local v109 = v107 * 3.141592653589793
					v108 = math.sin(v109)
				else
					v108 = 0
				end
				local v110 = 1 - v108 * 0.8
				local v111 = v110 - v_u_105
				if math.abs(v111) > 0.01 then
					v_u_105 = v110
					for _, v112 in v_u_103 do
						v112.Transparency = v110
					end
				end
				local v113 = (v108 * 1.8 + 2.4) * v_u_21
				v_u_102.Size = Vector3.new(v113, 0.05, v113)
				local v114 = -p106 * 7
				local v115 = v_u_90:Cross(v_u_89)
				return v_u_14(v_u_91 - v_u_89 * 0.35, v_u_89, v115 * math.cos(v114) + v_u_90 * math.sin(v114))
			end)
			for v_u_116 = 1, 5 do
				local v117 = v_u_116 * 1.618
				local v118 = v117 * 3.1 % 0.6 + 0.9
				local v119 = v117 * 5.3 % 0.5 + 0.7
				local v_u_120 = Vector3.new(v118, 0.28, v119) * v_u_21
				local v121 = p_u_15.bar
				local v122
				if v_u_116 % 2 == 0 then
					v122 = v_u_6
				else
					v122 = v_u_7
				end
				local v123 = v121(v_u_120, v122, 0.1, Enum.Material.Glass)
				local v_u_124 = (v117 * 2.3 % 0.9 + 4.1) * v_u_21
				p_u_15.add(p_u_16, v123, function(p125, p126)
					-- upvalues: (copy) v_u_116, (copy) v_u_21, (copy) v_u_124, (copy) p_u_16, (copy) v_u_120
					local v127 = p126 * 0.32 + (v_u_116 - 1) / 5 * 6.283185307179586
					local v128 = v_u_21 * 0.08
					local v129 = p126 * 1.9 + v_u_116 * 1.3
					local v130 = v128 * math.sin(v129)
					local v131 = p125.Position
					local v132 = math.cos(v127) * v_u_124
					local v133 = p_u_16.feet + v_u_120.Y * 0.5 + 0.02 + v130
					local v134 = math.sin(v127) * v_u_124
					local v135 = v131 + Vector3.new(v132, v133, v134)
					local v136 = CFrame.new(v135)
					local v137 = CFrame.Angles
					local v138 = p126 * 1.7 + v_u_116
					local v139 = math.sin(v138) * 0.06
					local v140 = v127 * 0.6 + v_u_116
					local v141 = p126 * 1.3 + v_u_116
					return v136 * v137(v139, v140, math.cos(v141) * 0.06)
				end)
			end
			local v142 = p_u_15.picture(v_u_21 * 9, v_u_4.Glow, v_u_18, 0.3)
			p_u_15.add(p_u_16, v142, function(p143)
				-- upvalues: (ref) p_u_15, (copy) p_u_16
				return CFrame.new(p_u_15.feetAt(p_u_16, p143, 0.06))
			end)
			local v144 = p_u_15.picture(v_u_21 * 4, v_u_4.Glow, v19, 0.35)
			p_u_15.add(p_u_16, v144, function(p145)
				-- upvalues: (ref) p_u_15, (copy) p_u_16
				return CFrame.new(p_u_15.feetAt(p_u_16, p145, 0.08))
			end)
			p_u_15.ripples(p_u_16, v_u_6, 3, 2.4, p_u_16.feet + 0.12)
			p_u_15.particles(p_u_16, "AuraMode", v_u_18, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_15.particles(p_u_16, "Petals", v_u_6, {
				["rate"] = 0.55,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end