local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(210, 196, 255)
local v_u_6 = Color3.fromRGB(104, 58, 226)
return function(p_u_7)
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_3, (copy) v_u_4, (copy) v_u_6
	return {
		["w0_kanjogan"] = function(p_u_8, p9)
			-- upvalues: (ref) v_u_2, (ref) v_u_5, (copy) p_u_7, (ref) v_u_3, (ref) v_u_4, (ref) v_u_6
			local v_u_10 = v_u_2.color(p9.color)
			local v11 = v_u_5
			local v12 = Color3.new(v11.R * 2.1, v11.G * 2.1, v11.B * 2.1)
			local v13 = p_u_8.headY / 1.5
			local v_u_14 = math.clamp(v13, 0.7, 3)
			local v_u_15 = p_u_8.fx
			local v_u_17 = p_u_7.throb(p_u_8, 3.2, 1.4, 2.4, function(p16)
				-- upvalues: (ref) v_u_2, (ref) p_u_7, (copy) p_u_8, (copy) v_u_10, (copy) v_u_15, (ref) v_u_3, (ref) v_u_5
				v_u_2.ring(p_u_7.feetAt(p_u_8, p16, 0.15), v_u_10, 10 * v_u_15, 0.75, v_u_3.Ring)
				v_u_2.ring(p_u_7.feetAt(p_u_8, p16, 0.2), v_u_5, 6 * v_u_15, 0.45, v_u_3.Ring)
			end)
			local v26 = p_u_7.group(p_u_8, function(p18, p19)
				-- upvalues: (copy) v_u_14
				local v20 = p18.Position - Vector3.new(0, 0.1, 0) * v_u_14
				local v21 = CFrame.new(v20)
				local v22 = CFrame.Angles
				local v23 = p19 * 0.7
				local v24 = math.sin(v23) * 0.17
				local v25 = p19 * 0.55
				return v21 * v22(v24, 0, math.cos(v25) * 0.13) * CFrame.Angles(0, p19 * 0.45, 0)
			end)
			local v27 = v_u_14 * 2.6
			local v28, v_u_29 = p_u_7.picture(v27 * 2 / 0.9, v_u_3.Ring, v_u_5, 0.15)
			p_u_7.pin(p_u_8, v26, v28, CFrame.identity)
			local v_u_30 = {}
			local v_u_31 = {}
			for v32 = 1, 8 do
				local v33 = (v32 - 1) / 8 * 3.141592653589793 * 2
				local v34 = CFrame.new(math.cos(v33) * v27, 0, math.sin(v33) * v27)
				local v35 = p_u_7.ball(v_u_14 * 0.85, v_u_10, 0.7)
				local v36 = p_u_7.ball(v_u_14 * 0.34, v_u_5, 0)
				p_u_7.pin(p_u_8, v26, v35, v34)
				p_u_7.pin(p_u_8, v26, v36, v34)
				table.insert(v_u_30, v35)
				table.insert(v_u_31, v36)
			end
			local v37 = p_u_7.picture(v_u_14 * 7.2, v_u_3.KanjoSweep, v_u_10, 0.3)
			p_u_7.add(p_u_8, v37, function(p38, p39)
				-- upvalues: (ref) p_u_7, (copy) p_u_8
				return CFrame.new(p_u_7.feetAt(p_u_8, p38, 0.1)) * CFrame.Angles(0, -1 * p39 * 2.4, 0)
			end)
			local v40 = p_u_7.picture(v_u_14 * 7.2 / 0.9, v_u_3.Ring, v_u_10, 0.55)
			p_u_7.add(p_u_8, v40, function(p41)
				-- upvalues: (ref) p_u_7, (copy) p_u_8
				return CFrame.new(p_u_7.feetAt(p_u_8, p41, 0.08))
			end)
			local v42, v_u_43 = p_u_7.picture(v_u_14 * 3.4, v_u_3.Ring, v_u_5, 1)
			for _, v44 in v_u_29 do
				v44.Color3 = v12
			end
			for _, v45 in v_u_43 do
				v45.Color3 = v12
			end
			p_u_7.add(p_u_8, v42, function(p46)
				-- upvalues: (copy) p_u_8, (copy) v_u_17, (copy) v_u_14
				local v47 = p_u_8.feet + (1 - v_u_17()) * (p_u_8.headY - p_u_8.feet + v_u_14 * 0.8)
				return CFrame.new(p46.Position + Vector3.new(0, 1, 0) * v47)
			end)
			local v_u_48 = -1
			local v49 = p_u_8.ticks
			local function v60(_, p50)
				-- upvalues: (copy) v_u_17, (copy) v_u_30, (copy) v_u_31, (ref) v_u_5, (ref) v_u_4, (copy) v_u_29, (ref) v_u_48, (copy) v_u_43
				local v51 = v_u_17()
				local v52 = p50 * 1.1 % 1
				for v53 = 1, 8 do
					local v54 = 1 - (v52 - (v53 - 1) / 8) % 1 * 3
					local v55 = math.max(v54, v51)
					v_u_30[v53].Transparency = 0.75 - v55 * 0.45
					v_u_31[v53].Color = v_u_5:Lerp(v_u_4, v55)
				end
				for _, v56 in v_u_29 do
					v56.Transparency = 0.15 * (1 - v51)
				end
				local v57 = v51 <= 0.02 and 1 or 1 - v51 * 0.9
				local v58 = v57 - v_u_48
				if math.abs(v58) > 0.01 then
					v_u_48 = v57
					for _, v59 in v_u_43 do
						v59.Transparency = v57
					end
				end
			end
			table.insert(v49, v60)
			for v_u_61 = 1, 2 do
				local v_u_62 = v_u_61 == 1 and -1 or 1
				local function v73(p63, p64) -- name: place
					-- upvalues: (copy) v_u_61, (copy) v_u_62, (copy) v_u_14, (copy) p_u_8
					local v65 = p64 * 1.1 + v_u_61 * 3.141592653589793
					local v66 = v_u_62 * (math.sin(v65) * 0.35 + 1.5) * v_u_14
					local v67 = p_u_8.headY * 0.75
					local v68 = v_u_14 * 0.45
					local v69 = v65 * 2
					local v70 = v67 + v68 * math.sin(v69)
					local v71 = (math.cos(v65) * 0.3 + 0.6) * v_u_14
					local v72 = Vector3.new(v66, v70, v71)
					return CFrame.new(p63:PointToWorldSpace(v72))
				end
				local v74 = p_u_7.ball(v_u_14 * 0.3, v_u_4, 0)
				p_u_7.add(p_u_8, v74, v73)
				p_u_7.tail(v74, v_u_5, v_u_6, v_u_14 * 0.28, 0.45)
				p_u_7.add(p_u_8, p_u_7.ball(v_u_14 * 0.75, v_u_10, 0.45), v73)
			end
			p_u_7.particles(p_u_8, "AuraMode", v_u_10, {
				["rate"] = 0.35,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_7.particles(p_u_8, "Petals", v_u_5, {
				["rate"] = 0.5,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end