local v_u_1 = {
	["UPDATE2"] = true,
	["PERKS"] = 1,
	["UPDATE3"] = true,
	["UPDATE4"] = false
}
v_u_1.LUCK_LADDER = v_u_1.UPDATE4
function v_u_1.luckLadder() -- name: luckLadder
	-- upvalues: (copy) v_u_1
	if v_u_1.LUCK_LADDER then
		return true
	end
	if not game:GetService("RunService"):IsStudio() then
		return false
	end
	local v2 = game:GetService("Workspace")
	return v2:GetAttribute("DevLuckLadder") == true and true or v2:GetAttribute("DevUpdate4") == true
end
function v_u_1.out(p3) -- name: out
	-- upvalues: (copy) v_u_1
	if p3 == nil or p3 < 2 then
		return true
	end
	if p3 == 3 then
		return v_u_1.UPDATE3
	end
	if p3 == 4 then
		return v_u_1.UPDATE4
	end
	local v4
	if p3 == 2 then
		v4 = v_u_1.UPDATE2
	else
		v4 = false
	end
	return v4
end
local v_u_5 = {
	[2] = "DevUpdate2",
	[3] = "DevUpdate3",
	[4] = "DevUpdate4"
}
function v_u_1.on(p6) -- name: on
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	if v_u_1.out(p6) then
		return true
	end
	local v7
	if p6 then
		v7 = v_u_5[p6]
	else
		v7 = nil
	end
	local v8 = v7 ~= nil and game:GetService("RunService"):IsStudio()
	if v8 then
		v8 = game:GetService("Workspace"):GetAttribute(v7) == true
	end
	return v8
end
return v_u_1