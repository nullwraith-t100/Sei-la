local v_u_1 = {}
local function v41(p2, p3) -- name: add
	-- upvalues: (copy) v_u_1
	local v4 = type(p3) == "table"
	local v5 = ("EnemyOutfits.%* must return a table"):format(p2)
	assert(v4, v5)
	for v6, v7 in p3 do
		local v8 = ("EnemyOutfits.%* %*"):format(p2, (tostring(v6)))
		local v9 = type(v6) == "string"
		local v10 = ("%*: the keys are enemy ids (strings)"):format(v8)
		assert(v9, v10)
		local v11 = type(v7) == "table"
		local v12 = ("%* must be a table"):format(v8)
		assert(v11, v12)
		local v13 = v_u_1[v6] == nil
		local v14 = ("%* is listed twice"):format(v8)
		assert(v13, v14)
		local v15 = {}
		local v16 = v7.accessories
		if v16 ~= nil then
			local v17 = type(v16) == "table"
			local v18 = ("%*.accessories must be a list"):format(v8)
			assert(v17, v18)
			for v19, v20 in v16 do
				local v21 = ("%*.accessories[%*]"):format(v8, v19)
				local v22
				if type(v20) == "number" and v20 > 0 then
					v22 = v20 % 1 == 0
				else
					v22 = false
				end
				local v23 = ("%* must be a catalog id (a whole number), got %* %*"):format(v21, type(v20), (tostring(v20)))
				assert(v22, v23)
				table.insert(v15, v20)
			end
		end
		local v24 = v7.skin
		local v25
		if type(v24) == "string" then
			v25 = string.match(v24, "^#%x%x%x%x%x%x$") ~= nil
		else
			v25 = false
		end
		local v26 = ("%*.skin must be \"#RRGGBB\""):format(v8)
		assert(v25, v26)
		local v27 = v_u_1
		local v28 = {}
		local v29 = v7.shirt
		local v30 = ("%*.shirt"):format(v8)
		local v31
		if type(v29) == "number" and v29 > 0 then
			v31 = v29 % 1 == 0
		else
			v31 = false
		end
		local v32 = ("%* must be a catalog id (a whole number), got %* %*"):format(v30, type(v29), (tostring(v29)))
		assert(v31, v32)
		v28.shirt = v29
		local v33 = v7.pants
		local v34 = ("%*.pants"):format(v8)
		local v35
		if type(v33) == "number" and v33 > 0 then
			v35 = v33 % 1 == 0
		else
			v35 = false
		end
		local v36 = ("%* must be a catalog id (a whole number), got %* %*"):format(v34, type(v33), (tostring(v33)))
		assert(v35, v36)
		v28.pants = v33
		v28.accessories = v15
		local v37
		if v7.face == nil then
			v37 = nil
		else
			v37 = v7.face
			local v38 = ("%*.face"):format(v8)
			local v39
			if type(v37) == "number" and v37 > 0 then
				v39 = v37 % 1 == 0
			else
				v39 = false
			end
			local v40 = ("%* must be a catalog id (a whole number), got %* %*"):format(v38, type(v37), (tostring(v37)))
			assert(v39, v40)
		end
		v28.face = v37
		v28.skin = v24
		v27[v6] = v28
	end
end
v41("World1", require(script.World1))
v41("World2", require(script.World2))
v41("World3", require(script.World3))
v41("World4", require(script.World4))
v41("World5", require(script.World5))
v41("World6", require(script.World6))
v41("World7", require(script.World7))
v41("World8", require(script.World8))
return v_u_1