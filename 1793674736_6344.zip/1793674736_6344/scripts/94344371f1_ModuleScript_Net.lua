local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	"Cast",
	"Train",
	"Equip",
	"UnlockEye",
	"Teleport",
	"Pad",
	"Tutorial",
	"Fx",
	"Wave",
	"Notify",
	"PrivateState",
	"Report",
	"Revive",
	"OfferLog",
	"NextStep"
}
local v_u_4 = { "Snap" }
local v_u_5 = {
	"Fuse",
	"Rebirth",
	"ClaimQuest",
	"ClaimReward",
	"EquipAura",
	"PetAction",
	"ClaimGroup",
	"ClaimDaily",
	"AutoRebirth",
	"AutoOp",
	"RedeemCode",
	"ExitBonus",
	"GetState",
	"Settings"
}
local v6 = {}
local v_u_7 = nil
local function v_u_9() -- name: getFolder
	-- upvalues: (ref) v_u_7, (copy) v_u_2, (copy) v_u_1
	if v_u_7 then
		return v_u_7
	end
	local v8
	if v_u_2:IsServer() then
		v8 = v_u_1:FindFirstChild("Remotes")
		if not (v8 and v8:IsA("Folder")) then
			v8 = Instance.new("Folder")
			v8.Name = "Remotes"
			v8.Parent = v_u_1
		end
	else
		v8 = v_u_1:WaitForChild("Remotes")
	end
	v_u_7 = v8
	return v8
end
function v6.setup() -- name: setup
	-- upvalues: (copy) v_u_9, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v10 = v_u_9()
	for _, v11 in v_u_3 do
		if v10:FindFirstChild(v11) then
			continue
		end
		local v12 = Instance.new("RemoteEvent")
		v12.Name = v11
		v12.Parent = v10
	end
	for _, v13 in v_u_4 do
		if v10:FindFirstChild(v13) then
			continue
		end
		local v14 = Instance.new("UnreliableRemoteEvent")
		v14.Name = v13
		v14.Parent = v10
	end
	for _, v15 in v_u_5 do
		if v10:FindFirstChild(v15) then
			continue
		end
		local v16 = Instance.new("RemoteFunction")
		v16.Name = v15
		v16.Parent = v10
	end
end
function v6.event(p17) -- name: event
	-- upvalues: (copy) v_u_9
	return v_u_9():WaitForChild(p17)
end
function v6.unreliable(p18) -- name: unreliable
	-- upvalues: (copy) v_u_9
	return v_u_9():WaitForChild(p18)
end
function v6.func(p19) -- name: func
	-- upvalues: (copy) v_u_9
	return v_u_9():WaitForChild(p19)
end
return v6