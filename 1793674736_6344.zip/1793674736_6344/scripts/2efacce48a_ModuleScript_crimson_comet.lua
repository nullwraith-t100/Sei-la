local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF2A2A")
local v_u_8 = Color3.fromHex("5A0008")
local v_u_9 = Color3.fromRGB(255, 236, 214)
local v_u_10 = Color3.fromRGB(255, 132, 70)
local v_u_11 = Color3.fromRGB(14, 6, 8)
local v_u_12 = Color3.fromRGB(42, 12, 14)
local v_u_13 = Color3.fromRGB(70, 46, 52)
local v_u_14 = Enum.PartType.Ball
local function v_u_28(p15, p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.part
	local v22 = p16 * 2
	local v23 = p16 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p15, p18, {
		["transparency"] = 1
	})
	local v25
	if p20 then
		v25 = { Enum.NormalId.Top, Enum.NormalId.Bottom }
	else
		v25 = { Enum.NormalId.Top }
	end
	for _, v26 in v25 do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p17
		v27.Color3 = p18
		v27.Transparency = p19
		v27.Parent = v24
	end
	return v24
end
local function v_u_32(p29, p30) -- name: setAlpha
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_39(p33, p34, p35) -- name: flameTail
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	local v36 = Instance.new("Attachment")
	v36.Parent = p33
	local v37 = Instance.new("Attachment")
	v37.WorldPosition = p33.Position
	v37.Parent = v_u_3.Terrain
	local v38 = Instance.new("Beam")
	v38.Attachment0 = v36
	v38.Attachment1 = v37
	v38.Texture = v_u_6.CometFlame
	v38.TextureMode = Enum.TextureMode.Stretch
	v38.TextureLength = 1
	v38.TextureSpeed = 1.6
	v38.Color = ColorSequence.new(Color3.fromRGB(255, 190, 180), Color3.fromRGB(255, 70, 60))
	v38.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.55, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v38.LightEmission = 0.3
	v38.LightInfluence = 0
	v38.FaceCamera = true
	v38.Width0 = p34
	v38.Width1 = p35
	v38.Segments = 1
	v38.Parent = p33
	return v37, v38
end
return function(p_u_40)
	-- upvalues: (copy) v_u_28, (copy) v_u_1, (copy) v_u_32, (copy) v_u_3, (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_14, (copy) v_u_6, (copy) v_u_39, (copy) v_u_10, (copy) v_u_8, (copy) v_u_13, (copy) v_u_11, (copy) v_u_5, (copy) v_u_12
	local function v_u_58(p_u_41, p_u_42, p_u_43, p44, p45, p_u_46, p_u_47, p48, p49) -- name: flare
		-- upvalues: (ref) v_u_28, (ref) v_u_1, (copy) p_u_40, (ref) v_u_32
		local v_u_50 = p48 or 0
		local v_u_51 = v_u_28(p_u_41, p_u_42, p44, p45, v_u_50, p49)
		v_u_1:AddItem(v_u_51, p_u_46 + 0.1)
		p_u_40.animate(p_u_46, 0, function(p52)
			-- upvalues: (copy) v_u_51, (copy) p_u_42, (copy) p_u_43, (copy) p_u_41, (copy) p_u_46, (copy) p_u_47, (ref) v_u_32, (copy) v_u_50
			local v53 = 1 - (1 - p52) ^ 3
			local v54 = v_u_51
			local v55 = p_u_42 + (p_u_43 - p_u_42) * v53
			local v56 = v55 * 2
			local v57 = v55 * 2
			v54.Size = Vector3.new(v56, 0.05, v57)
			v_u_51.CFrame = p_u_41 * CFrame.Angles(0, p52 * p_u_46 * p_u_47, 0)
			v_u_32(v_u_51, v_u_50 + (1 - v_u_50) * p52 ^ 1.5)
			if p52 >= 1 then
				v_u_51:Destroy()
			end
		end)
	end
	local function v_u_67(p59, p60, p61) -- name: crossFlash
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (copy) p_u_40, (ref) v_u_9
		local v62 = v_u_3.CurrentCamera
		if v62 then
			local v63 = v62.CFrame
			local v64 = CFrame.fromMatrix(p59, v63.RightVector, v63.UpVector) * CFrame.Angles(0, 0, 0.7853981633974483)
			for _, v65 in { Vector3.new(1, 0, 0), Vector3.new(0, 1, 0) } do
				local v66 = v_u_4.part(v65 * p60 * 0.25 + Vector3.new(0.55, 0.55, 0.55), v64, v_u_7)
				v_u_4.tween(v66, p61, {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = v65 * p60 + Vector3.new(0.06, 0.06, 0.06)
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
				v_u_1:AddItem(v66, p61 + 0.05)
			end
			p_u_40.pop(p59, v_u_9, p60 * 0.12, p60 * 0.03, p61)
		end
	end
	local function v93(p68, p69) -- name: shurikenShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_14, (ref) v_u_9, (ref) v_u_28, (ref) v_u_6, (ref) v_u_39, (copy) p_u_40, (ref) v_u_1, (ref) v_u_3
		local v_u_70 = p68.size
		local v_u_71 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p69, v_u_7, {
			["transparency"] = 1
		})
		local v72 = {
			["shape"] = nil,
			["transparency"] = 0.3,
			["shape"] = v_u_14
		}
		local v_u_73 = v_u_4.part(Vector3.new(1.9, 1.9, 1.9) * v_u_70, p69, v_u_7, v72)
		local v74 = {
			["shape"] = v_u_14
		}
		local v_u_75 = v_u_4.part(Vector3.new(0.8, 0.8, 0.8) * v_u_70, p69, v_u_9, v74)
		local v_u_76 = v_u_28(p69, 1.05 * v_u_70, v_u_6.CometShuriken, v_u_7, 0)
		local v_u_77 = { v_u_73, v_u_75, v_u_76 }
		local v_u_78, _ = v_u_39(v_u_71, 2.2 * v_u_70, 0.3 * v_u_70)
		if p68.mine then
			p_u_40.light(v_u_71, v_u_7, 9 * v_u_70)
		end
		for _, v79 in v_u_77 do
			v_u_1:AddItem(v79, 3)
		end
		v_u_1:AddItem(v_u_71, 3)
		v_u_1:AddItem(v_u_78, 3)
		local v_u_80 = p69.Position
		local v_u_81 = false
		return {
			["place"] = function(p82, p83) -- name: place
				-- upvalues: (copy) v_u_71, (copy) v_u_73, (copy) v_u_75, (copy) v_u_70, (copy) v_u_80, (copy) v_u_78, (ref) v_u_3, (copy) v_u_76, (ref) p_u_40
				local v84 = p82.Position
				v_u_71.CFrame = p82
				v_u_73.CFrame = p82
				v_u_75.CFrame = p82
				local v85 = 7 * v_u_70
				local v86 = (v84 - v_u_80).Magnitude
				local v87 = math.min(v85, v86)
				v_u_78.WorldPosition = v84 - p82.LookVector * v87
				local v88 = v_u_3.CurrentCamera
				local v89
				if v88 then
					local v90 = v88.CFrame.Position - v84
					v89 = v90.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v90.Unit
				else
					v89 = Vector3.new(0, 0, 1)
				end
				v_u_76.CFrame = p_u_40.facing(v84 + v89 * 0.7 * v_u_70, v89) * CFrame.Angles(0, -p83 * 26, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_81, (copy) v_u_71, (copy) v_u_78, (copy) v_u_77
				if not v_u_81 then
					v_u_81 = true
					local v91 = v_u_71:FindFirstChildWhichIsA("PointLight")
					if v91 then
						v91:Destroy()
					end
					v_u_71:Destroy()
					v_u_78:Destroy()
					for _, v92 in v_u_77 do
						v92:Destroy()
					end
				end
			end
		}
	end
	local function v100(p94, p95) -- name: shurikenImpact
		-- upvalues: (ref) v_u_3, (copy) v_u_58, (copy) p_u_40, (ref) v_u_6, (ref) v_u_7, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10
		local v96 = p94.size
		local v97 = v_u_3.CurrentCamera
		local v98
		if v97 then
			local v99 = v97.CFrame.Position - p95
			v98 = v99.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v99.Unit
		else
			v98 = Vector3.new(0, 0, 1)
		end
		v_u_58(p_u_40.facing(p95 + v98, v98), 1.05 * v96, 3.4 * v96, v_u_6.CometShuriken, v_u_7, 0.2, -18)
		p_u_40.pop(p95, v_u_7, 1.2 * v96, 4.6 * v96, 0.18, 0.3)
		p_u_40.pop(p95, v_u_9, 0.8 * v96, 2 * v96, 0.1)
		v_u_4.ring(p_u_40.ground(p95), v_u_7, p94.ability.radius * v96, 0.25, v_u_6.Ring)
		p_u_40.burst("Impact", p95, v_u_7, 0.9 * v96)
		p_u_40.spikes(p95, v_u_10, p94.lite and 3 or 7, 6 * v96, 0.2, p94.dir, 0.7)
		p_u_40.hitSound(p95)
	end
	local function v138(p101, p102) -- name: orbitShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_14, (ref) v_u_28, (ref) v_u_6, (copy) p_u_40, (ref) v_u_8, (ref) v_u_1, (ref) v_u_3
		local v_u_103 = p101.size
		local v104 = p102.LookVector
		local v105 = v104.Z
		local v106 = v104.X
		local v_u_107 = math.atan2(v105, v106)
		local v_u_108 = p101.eye - Vector3.new(0, 1.3, 0)
		local v109 = p101.dir.Z
		local v110 = p101.dir.X
		local v111 = (v_u_107 - math.atan2(v109, v110) + 3.141592653589793) % 6.283185307179586 - 3.141592653589793
		local v112 = (p101.ability.spreadAngle or 50) / 2
		local v113 = math.rad(v112)
		local v114 = (v111 / math.max(v113, 0.001) + 1) / 2
		local v115 = math.clamp(v114, 0, 1)
		local v_u_116 = v111 + 3.141592653589793 - (v115 - 0.5) * 1.6 * 3.141592653589793
		local v_u_117 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p102, v_u_7, {
			["transparency"] = 1
		})
		local v118 = {
			["shape"] = nil,
			["transparency"] = 0.45,
			["shape"] = v_u_14
		}
		local v_u_119 = v_u_4.part(Vector3.new(2.2, 2.2, 2.2) * v_u_103, p102, v_u_7, v118)
		local v_u_120 = v_u_28(p102, 1.4 * v_u_103, v_u_6.CometShuriken, v_u_7, 0)
		local v_u_121 = { v_u_119, v_u_120 }
		p_u_40.streak(v_u_117, v_u_7, v_u_8, 1.5 * v_u_103, 0.2)
		for _, v122 in v_u_121 do
			v_u_1:AddItem(v122, 3)
		end
		v_u_1:AddItem(v_u_117, 3)
		local v_u_123 = false
		return {
			["place"] = function(p124, p125) -- name: place
				-- upvalues: (copy) v_u_107, (copy) v_u_116, (copy) v_u_108, (copy) v_u_103, (copy) v_u_117, (copy) v_u_119, (ref) v_u_3, (copy) v_u_120, (ref) p_u_40
				local v126 = p125 / 0.17
				local v127 = math.clamp(v126, 0, 1)
				local v128 = v_u_107 - v_u_116 * (1 - v127)
				local v129 = v_u_108
				local v130 = math.cos(v128)
				local v131 = math.sin(v128)
				local v132 = (v129 + Vector3.new(v130, 0, v131) * 3.3 * v_u_103):Lerp(p124.Position, v127 ^ 2.5)
				local v133 = CFrame.new(v132) * p124.Rotation
				v_u_117.CFrame = v133
				v_u_119.CFrame = v133
				local v134 = v_u_3.CurrentCamera
				local v135
				if v134 then
					local v136 = v134.CFrame.Position - v132
					v135 = v136.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v136.Unit
				else
					v135 = Vector3.new(0, 0, 1)
				end
				v_u_120.CFrame = p_u_40.facing(v132 + v135 * 0.6 * v_u_103, v135) * CFrame.Angles(0, -p125 * 22, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_123, (ref) v_u_1, (copy) v_u_117, (copy) v_u_121
				if not v_u_123 then
					v_u_123 = true
					v_u_1:AddItem(v_u_117, 0.25)
					for _, v137 in v_u_121 do
						v137:Destroy()
					end
				end
			end
		}
	end
	local function v145(p139, p140) -- name: orbitImpact
		-- upvalues: (ref) v_u_3, (copy) v_u_67, (copy) v_u_58, (copy) p_u_40, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4
		local v141 = p139.size
		local v142 = v_u_3.CurrentCamera
		local v143
		if v142 then
			local v144 = v142.CFrame.Position - p140
			v143 = v144.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v144.Unit
		else
			v143 = Vector3.new(0, 0, 1)
		end
		v_u_67(p140, 8 * v141, 0.22)
		v_u_58(p_u_40.facing(p140 + v143, v143), 1.4 * v141, 3.8 * v141, v_u_6.CometShuriken, v_u_7, 0.22, -16)
		p_u_40.pop(p140, v_u_7, 1.4 * v141, 5 * v141, 0.2, 0.35)
		v_u_4.ring(p_u_40.ground(p140), v_u_7, 6 * v141, 0.3, v_u_6.Ring)
		p_u_40.burst("Impact", p140, v_u_7, 1 * v141)
		p_u_40.hitSound(p140)
	end
	local v_u_146 = {}
	setmetatable(v_u_146, {
		["__mode"] = "k"
	})
	local function v_u_160(p147, p148) -- name: newComet
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_14, (ref) v_u_9, (ref) v_u_28, (ref) v_u_6, (ref) v_u_39, (ref) v_u_1, (copy) p_u_40
		local v149 = p147.size
		local v150 = {
			["shape"] = nil,
			["transparency"] = 0.15,
			["shape"] = v_u_14
		}
		local v151 = v_u_4.part(Vector3.new(5.5, 5.5, 5.5) * v149, CFrame.identity, v_u_7, v150)
		local v152 = {
			["shape"] = v_u_14
		}
		local v153 = v_u_4.part(Vector3.new(3, 3, 3) * v149, CFrame.identity, v_u_9, v152)
		local v154 = {
			["shape"] = nil,
			["transparency"] = 0.72,
			["shape"] = v_u_14
		}
		local v155 = v_u_4.part(Vector3.new(9, 9, 9) * v149, CFrame.identity, v_u_7, v154)
		local v156 = v_u_28(CFrame.identity, 3.2 * v149, v_u_6.CometShuriken, v_u_7, 0)
		local v157, v158 = v_u_39(v151, 9 * v149, 1.5 * v149)
		for _, v159 in {
			v151,
			v153,
			v155,
			v156
		} do
			v_u_1:AddItem(v159, p148)
		end
		v_u_1:AddItem(v157, p148)
		if p147.mine then
			p_u_40.light(v151, v_u_7, 30)
		end
		return {
			["head"] = nil,
			["heart"] = nil,
			["halo"] = nil,
			["blade"] = nil,
			["tailEnd"] = nil,
			["tail"] = nil,
			["spin"] = 0,
			["head"] = v151,
			["heart"] = v153,
			["halo"] = v155,
			["blade"] = v156,
			["tailEnd"] = v157,
			["tail"] = v158
		}
	end
	local function v_u_170(p161, p162, p163, p164, p165) -- name: placeComet
		-- upvalues: (ref) v_u_3, (copy) p_u_40
		p161.spin = p161.spin + p165 * 16
		local v166 = CFrame.new(p162)
		p161.head.CFrame = v166
		p161.heart.CFrame = v166
		p161.halo.CFrame = v166
		local v167 = v_u_3.CurrentCamera
		local v168
		if v167 then
			local v169 = v167.CFrame.Position - p162
			v168 = v169.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v169.Unit
		else
			v168 = Vector3.new(0, 0, 1)
		end
		p161.blade.CFrame = p_u_40.facing(p162 + v168 * 3, v168) * CFrame.Angles(0, -p161.spin, 0)
		p161.tailEnd.WorldPosition = p162 - p163 * p164
	end
	local function v_u_173(p171) -- name: dropComet
		for _, v172 in {
			p171.head,
			p171.heart,
			p171.halo,
			p171.blade
		} do
			v172:Destroy()
		end
		p171.tailEnd:Destroy()
	end
	local function v_u_194(p174, p175) -- name: incoming
		-- upvalues: (copy) p_u_40, (copy) v_u_160, (copy) v_u_146, (ref) v_u_9, (copy) v_u_170, (ref) v_u_7
		local v_u_176 = p174.size
		local v177 = p174.dir:Cross(Vector3.new(0, 1, 0))
		local v_u_178 = p174.feet - p174.dir * 38 * v_u_176 + Vector3.new(0, 52, 0) * v_u_176 + v177 * 9 * v_u_176
		local v_u_179 = p_u_40.ground(p174.feet + p174.dir * 5 * v_u_176, 2.4 * v_u_176)
		local v180 = math.max(p175, 0.06)
		local v_u_181 = v_u_160(p174, v180 + 0.3 + 3)
		v_u_146[p174] = v_u_181
		p_u_40.glint(v_u_178, v_u_9, 7, 0.2)
		local v_u_182 = (v_u_179 - v_u_178).Unit
		local v_u_183 = os.clock()
		p_u_40.animate(v180, 0, function(p184)
			-- upvalues: (ref) v_u_183, (ref) v_u_170, (copy) v_u_181, (copy) v_u_178, (copy) v_u_179, (copy) v_u_182, (copy) v_u_176
			local v185 = os.clock()
			local v186 = v185 - v_u_183
			local v187 = math.min(v186, 0.05)
			v_u_183 = v185
			local v188 = v_u_170
			local v189 = v_u_181
			local v190 = v_u_178:Lerp(v_u_179, p184)
			local v191 = v_u_182
			local v192 = 26 * v_u_176
			local v193 = p184 * 3
			v188(v189, v190, v191, v192 * math.min(v193, 1), v187)
		end)
		p_u_40.groundLine(p174.feet, p174.feet + p174.dir * p174.ability.range, 1.2 * v_u_176, v_u_7, 0.5, 0.45)
	end
	local function v_u_240(p_u_195, p196) -- name: crash
		-- upvalues: (copy) p_u_40, (copy) v_u_146, (copy) v_u_160, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (ref) v_u_13, (ref) v_u_11, (ref) v_u_5, (ref) v_u_1, (ref) v_u_12, (copy) v_u_170, (copy) v_u_173, (ref) v_u_3, (copy) v_u_58, (ref) v_u_10, (ref) v_u_8
		local v_u_197 = p_u_195.size
		local v_u_198 = p_u_195.lite
		local v_u_199 = p_u_40.ground(p_u_195.feet + p_u_195.dir * 5 * v_u_197, 0)
		local v_u_200 = p_u_40.ground(p196, 0)
		local v201 = v_u_200 - v_u_199
		if v201.Magnitude < 1 then
			v201 = p_u_195.dir
			v_u_200 = v_u_199 + p_u_195.dir
		end
		local v_u_202 = v201.Unit
		local v_u_203 = v201.Magnitude
		local v204 = v_u_146[p_u_195]
		v_u_146[p_u_195] = nil
		local v_u_205 = v204 or v_u_160(p_u_195, 3.3)
		v_u_4.flash(v_u_199 + Vector3.new(0, 2, 0), v_u_9, 14 * v_u_197, 0.2)
		p_u_40.pop(v_u_199 + Vector3.new(0, 2, 0), v_u_7, 3 * v_u_197, 15 * v_u_197, 0.3, 0.3)
		p_u_40.burst("Impact", v_u_199 + Vector3.new(0, 2, 0), v_u_7, 2.2)
		p_u_40.burst("Flash", v_u_199 + Vector3.new(0, 2, 0), v_u_7, 0.5)
		v_u_4.ring(v_u_199, v_u_7, 12 * v_u_197, 0.4, v_u_6.Shockwave)
		p_u_40.chunks(v_u_199 + Vector3.new(0, 1, 0), { v_u_13, v_u_7, v_u_11 }, v_u_198 and 4 or 10, 40, 1.1, 1.1, false, 1)
		v_u_5.play("Fireball", {
			["at"] = v_u_199,
			["volume"] = p_u_195.mine and 1 or 0.6
		})
		if p_u_195.mine then
			v_u_4.shake(0.45, 0.35)
		end
		local function v212(p206, p207, p208, p209, p210) -- name: strip
			-- upvalues: (ref) v_u_4, (copy) v_u_199, (ref) v_u_1
			local v211 = v_u_4.part(Vector3.new(p206, 0.1, 0.1), CFrame.new(v_u_199), p208, {
				["material"] = p209,
				["transparency"] = p210
			})
			v_u_1:AddItem(v211, 3.3)
			v211:SetAttribute("Lift", p207)
			return v211
		end
		local v_u_213 = v212(13 * v_u_197, 0.06, v_u_12, Enum.Material.SmoothPlastic, 0.1)
		local v_u_214 = v212(5.5 * v_u_197, 0.1, v_u_7, Enum.Material.Neon, 0)
		local v_u_215 = v212(1.6 * v_u_197, 0.14, v_u_9, Enum.Material.Neon, 0)
		local v_u_216 = { v_u_213, v_u_214, v_u_215 }
		local v_u_217 = v_u_198 and 24 or 12
		local v_u_218 = 0
		local v_u_219 = os.clock()
		local v_u_220 = 0
		p_u_40.animate(0.3, 0, function(p221)
			-- upvalues: (ref) v_u_219, (copy) v_u_203, (copy) v_u_199, (copy) v_u_202, (ref) v_u_170, (copy) v_u_205, (copy) v_u_197, (copy) v_u_216, (ref) v_u_218, (copy) v_u_217, (ref) p_u_40, (ref) v_u_13, (ref) v_u_7, (ref) v_u_11, (copy) v_u_198, (ref) v_u_220, (ref) v_u_173, (ref) v_u_4, (ref) v_u_200, (ref) v_u_9, (ref) v_u_6, (ref) v_u_3, (ref) v_u_58, (ref) v_u_10, (ref) v_u_5, (copy) p_u_195, (copy) v_u_215, (copy) v_u_214, (ref) v_u_8, (copy) v_u_213
			local v222 = os.clock()
			local v223 = v222 - v_u_219
			local v224 = math.min(v223, 0.05)
			v_u_219 = v222
			local v225 = v_u_203 * (1 - (1 - p221) ^ 1.3)
			v_u_170(v_u_205, v_u_199 + v_u_202 * v225 + Vector3.new(0, 2.4, 0) * v_u_197, (v_u_202 - Vector3.new(0, 0.15, 0)).Unit, 26 * v_u_197, v224)
			local v226 = math.max(v225, 0.2)
			local v227 = v_u_199 + v_u_202 * v226 / 2
			for _, v228 in v_u_216 do
				local v229 = v228:GetAttribute("Lift")
				local v230 = type(v229) ~= "number" and 0.1 or v229
				local v231 = v228.Size.X
				v228.Size = Vector3.new(v231, 0.1, v226)
				v228.CFrame = CFrame.lookAt(v227 + Vector3.new(0, 1, 0) * v230, v227 + Vector3.new(0, 1, 0) * v230 + v_u_202)
			end
			while v_u_218 + v_u_217 <= v225 do
				v_u_218 = v_u_218 + v_u_217
				local v232 = v_u_199 + v_u_202 * v_u_218
				p_u_40.chunks(v232 + Vector3.new(0, 1, 0), { v_u_13, v_u_7, v_u_11 }, v_u_198 and 2 or 4, 30, 0.9, 0.9, false, 1)
				if v_u_198 or v_u_220 >= 7 then
					continue
				end
				v_u_220 = v_u_220 + 1
				local v233 = p_u_40.loopAt("Fire", v232, v_u_7, 1.3)
				p_u_40.after(0.9, v233)
			end
			if p221 >= 1 then
				v_u_173(v_u_205)
				v_u_4.flash(v_u_200 + Vector3.new(0, 2, 0), v_u_9, 16 * v_u_197, 0.22)
				p_u_40.burst("Impact", v_u_200 + Vector3.new(0, 2, 0), v_u_7, 2.6)
				p_u_40.burst("Flash", v_u_200 + Vector3.new(0, 2, 0), v_u_7, 0.6)
				p_u_40.pop(v_u_200 + Vector3.new(0, 2, 0), v_u_7, 4 * v_u_197, 22 * v_u_197, 0.35, 0.3)
				p_u_40.pop(v_u_200 + Vector3.new(0, 2, 0), v_u_9, 3 * v_u_197, 9 * v_u_197, 0.2)
				v_u_4.ring(v_u_200, v_u_7, 18 * v_u_197, 0.45, v_u_6.Shockwave)
				local v234 = v_u_200 + Vector3.new(0, 8, 0) * v_u_197
				local v235 = v_u_3.CurrentCamera
				local v236
				if v235 then
					local v237 = v235.CFrame.Position - v234
					v236 = v237.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v237.Unit
				else
					v236 = Vector3.new(0, 0, 1)
				end
				local v238 = p_u_40.facing(v234, v236)
				v_u_58(v238, 2 * v_u_197, 11 * v_u_197, v_u_6.CometShuriken, v_u_7, 0.45, -10)
				v_u_58(v238 * CFrame.new(0, 0.06, 0), 1.4 * v_u_197, 5.5 * v_u_197, p_u_40.iris("crimson_comet"), Color3.new(1, 1, 1), 0.45, 6)
				if not v_u_198 then
					p_u_40.spikes(v_u_200 + Vector3.new(0, 2, 0), v_u_10, 10, 16 * v_u_197, 0.3)
				end
				v_u_5.play("Explosion", {
					["at"] = v_u_200,
					["volume"] = p_u_195.mine and 0.9 or 0.5
				})
				v_u_4.tween(v_u_215, 0.5, {
					["Transparency"] = 1
				})
				local v239 = {
					["Color"] = v_u_8
				}
				v_u_4.tween(v_u_214, 1.3, v239)
				p_u_40.after(0.9, function()
					-- upvalues: (ref) v_u_4, (ref) v_u_214
					v_u_4.tween(v_u_214, 1, {
						["Transparency"] = 1
					})
				end)
				v_u_4.tween(v_u_213, 2, {
					["Transparency"] = 1
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
			end
		end)
	end
	local v259 = {
		["crimson_comet_a"] = {
			["cast"] = function(p241) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_40, (ref) v_u_9, (copy) v_u_58, (ref) v_u_6
				local v242 = p241.size
				local v243 = p241.eye + p241.dir * 1.2
				v_u_4.flash(v243, v_u_7, 3.2 * v242, 0.1)
				p_u_40.pop(v243, v_u_9, 1.2 * v242, 0.3 * v242, 0.1)
				if not p241.lite then
					v_u_58(p_u_40.facing(v243, -p241.dir), 0.6 * v242, 1.6 * v242, v_u_6.CometShuriken, v_u_7, 0.12, -30)
				end
			end,
			["shot"] = v93,
			["impact"] = v100,
			["hit"] = function(_, p244, _) -- name: hit
				-- upvalues: (copy) p_u_40, (ref) v_u_7
				p_u_40.burst("Impact", p244, v_u_7, 0.6)
			end
		},
		["crimson_comet_e"] = {
			["cast"] = function(p245) -- name: cast
				-- upvalues: (copy) p_u_40, (ref) v_u_7, (copy) v_u_58, (ref) v_u_6, (ref) v_u_10
				p_u_40.skillCast(p245, v_u_7)
				local v246 = p245.size
				local v247 = p245.eye - Vector3.new(0, 1.3, 0)
				v_u_58(CFrame.new(v247), 2.64 * v246, 4.949999999999999 * v246, v_u_6.Ring, v_u_7, 0.3, 4, 0.1, true)
				if not p245.lite then
					p_u_40.spikes(v247, v_u_10, 5, 5 * v246, 0.16, nil, nil, true)
				end
			end,
			["shot"] = v138,
			["impact"] = v145,
			["hit"] = function(p248, p249, _) -- name: hit
				-- upvalues: (copy) p_u_40, (ref) v_u_7, (ref) v_u_9
				p_u_40.burst("Impact", p249, v_u_7, 0.7)
				if not p248.lite then
					p_u_40.glint(p249, v_u_9, 2.6, 0.12)
				end
			end
		},
		["crimson_comet_r"] = {
			["castSound"] = "Charge",
			["cast"] = nil,
			["windup"] = nil,
			["beam"] = nil,
			["hit"] = nil,
			["cast"] = function(p250) -- name: cast
				-- upvalues: (copy) p_u_40, (ref) v_u_7, (copy) v_u_58, (ref) v_u_6, (ref) v_u_4
				p_u_40.skillCast(p250, v_u_7, true)
				local v251 = p250.size
				local v252 = p250.eye + p250.dir * 1.4
				v_u_58(p_u_40.facing(v252, -p250.dir), 1 * v251, 4 * v251, v_u_6.CometShuriken, v_u_7, 0.32, -14)
				if p250.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p253, _, p254) -- name: windup
				-- upvalues: (copy) v_u_194
				v_u_194(p253, p254)
			end,
			["beam"] = function(p255, _, p256) -- name: beam
				-- upvalues: (copy) v_u_240
				v_u_240(p255, p256)
			end,
			["hit"] = function(p257, p258, _) -- name: hit
				-- upvalues: (copy) p_u_40, (ref) v_u_7, (ref) v_u_9
				p_u_40.burst("Impact", p258, v_u_7, 1.1)
				if not p257.lite then
					p_u_40.glint(p258, v_u_9, 3.4, 0.15)
				end
			end
		}
	}
	return v259
end