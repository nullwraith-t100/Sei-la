local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v2.Shared.Logic.Format)
local v_u_6 = require(script.Parent.Perf)
local v7 = {}
local v_u_8 = Font.new("rbxasset://fonts/families/FredokaOne.json", Enum.FontWeight.Regular)
local v_u_9 = {}
local v_u_10 = 0
function v7.show(p11, p12, p13, p14, p_u_15) -- name: show
	-- upvalues: (copy) v_u_9, (copy) v_u_5, (ref) v_u_10, (copy) v_u_6, (copy) v_u_4, (copy) v_u_8, (copy) v_u_3, (copy) v_u_1
	local v16 = os.clock()
	if p_u_15 ~= nil and not p13 then
		local v17 = v_u_9[p_u_15]
		if v17 and (v16 - v17.at < 0.25 and v17.text.Parent) then
			v17.total = v17.total + p12
			v17.text.Text = "-" .. v_u_5.short(v17.total)
			return
		end
	end
	if p13 or v_u_10 < (v_u_6.level() <= 1 and 6 or (v_u_6.level() == 2 and 12 or 24)) then
		local v18 = p14 or 1
		local v19 = Instance.new("Attachment")
		local v20 = (math.random() - 0.5) * 2.5
		local v21 = math.random() * 1.2
		local v22 = (math.random() - 0.5) * 2.5
		v19.WorldPosition = p11 + Vector3.new(v20, v21, v22)
		v19.Parent = v_u_4.Terrain
		local v23 = Instance.new("BillboardGui")
		v23.Adornee = v19
		v23.AlwaysOnTop = true
		v23.LightInfluence = 0
		v23.Size = UDim2.fromScale(7 * v18, 2.2 * v18)
		v23.MaxDistance = 180
		v23.Parent = v19
		local v_u_24 = Instance.new("TextLabel")
		v_u_24.BackgroundTransparency = 1
		v_u_24.AnchorPoint = Vector2.new(0.5, 0.5)
		v_u_24.Position = UDim2.fromScale(0.5, 0.5)
		v_u_24.Size = UDim2.fromScale(0.3, 0.3)
		v_u_24.FontFace = v_u_8
		v_u_24.TextScaled = true
		v_u_24.Text = "-" .. v_u_5.short(p12)
		local v25
		if p13 then
			v25 = Color3.fromRGB(255, 40, 40)
		else
			v25 = Color3.fromRGB(255, 72, 72)
		end
		v_u_24.TextColor3 = v25
		local v_u_26 = Instance.new("UIStroke")
		v_u_26.Thickness = p13 and 3 or 2.5
		v_u_26.Color = Color3.new(0, 0, 0)
		v_u_26.Parent = v_u_24
		v_u_24.Parent = v23
		v_u_10 = v_u_10 + 1
		if p_u_15 ~= nil and not p13 then
			v_u_9[p_u_15] = {
				["text"] = v_u_24,
				["total"] = p12,
				["at"] = v16
			}
		end
		local v27 = p13 and 1.4 or 1
		v_u_3:Create(v_u_24, TweenInfo.new(0.14, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Size"] = UDim2.fromScale(v27, v27)
		}):Play()
		if p13 then
			v_u_24.Rotation = (math.random() - 0.5) * 16
		end
		v_u_3:Create(v23, TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["StudsOffsetWorldSpace"] = Vector3.new(0, 2.5, 0)
		}):Play()
		task.delay(0.45, function()
			-- upvalues: (ref) v_u_3, (copy) v_u_24, (copy) v_u_26
			v_u_3:Create(v_u_24, TweenInfo.new(0.35), {
				["TextTransparency"] = 1
			}):Play()
			v_u_3:Create(v_u_26, TweenInfo.new(0.35), {
				["Transparency"] = 1
			}):Play()
		end)
		task.delay(0.9, function()
			-- upvalues: (ref) v_u_10, (copy) p_u_15, (ref) v_u_9, (copy) v_u_24
			v_u_10 = v_u_10 - 1
			local v28
			if p_u_15 == nil then
				v28 = nil
			else
				v28 = v_u_9[p_u_15]
			end
			if v28 and v28.text == v_u_24 then
				v_u_9[p_u_15] = nil
			end
		end)
		v_u_1:AddItem(v19, 0.9)
	end
end
return v7