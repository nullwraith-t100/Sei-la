local v_u_1 = require(script.Parent.Parent.Config.Economy)
local v_u_2 = require(script.Parent.Economy)
return {
	["available"] = function(p3, p4, p5) -- name: available
		-- upvalues: (copy) v_u_1
		local v6 = not p5
		if v6 then
			v6 = p3 <= 0 and true or p4 - p3 >= v_u_1.exitEvery * 60
		end
		return v6
	end,
	["readyAt"] = function(p7) -- name: readyAt
		-- upvalues: (copy) v_u_1
		return p7 <= 0 and 0 or p7 + v_u_1.exitEvery * 60
	end,
	["levelXp"] = function(p8, p9, p10) -- name: levelXp
		-- upvalues: (copy) v_u_2
		if p10 <= 0 then
			return 0
		end
		local v11 = v_u_2.xpToNext(p8) - p9
		local v12 = math.max(v11, 0)
		for v13 = 1, p10 - 1 do
			v12 = v12 + v_u_2.xpToNext(p8 + v13)
		end
		return v12
	end,
	["boostSeconds"] = function(p14, p15) -- name: boostSeconds
		-- upvalues: (copy) v_u_1
		local v16 = p14 - p15
		local v17 = math.max(v16, 0)
		local v18 = v_u_1.exitBoostCap * 60 - v17
		local v19 = v_u_1.exitBoostMinutes * 60
		local v20 = math.clamp(v18, 0, v19)
		return math.floor(v20)
	end
}