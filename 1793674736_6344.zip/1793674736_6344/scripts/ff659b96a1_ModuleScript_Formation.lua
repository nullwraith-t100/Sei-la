return {
	["place"] = function(p1, p_u_2) -- name: place
		local v_u_3 = {}
		local v_u_4 = {}
		local function v13(p5, p6, p7) -- name: free
			-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) p_u_2
			for v8, v9 in v_u_3 do
				local v10 = p7 + v_u_4[v8] + p_u_2
				local v11 = v9.x - p5
				local v12 = v9.z - p6
				if v11 * v11 + v12 * v12 >= v10 * v10 - 1e-6 then
					continue
				end
				return false
			end
			return true
		end
		for _, v14 in p1 do
			local v15
			if #v_u_3 == 0 then
				v15 = {
					["x"] = 0,
					["z"] = 0
				}
			else
				v15 = nil
				local v16 = 0.5
				while not v15 and v16 < 200 do
					local v17 = 6.283185307179586 * v16 / 0.5
					local v18 = math.floor(v17)
					local v19 = math.max(6, v18)
					for v20 = 0, v19 - 1 do
						local v21 = v20 / v19 * 2 * 3.141592653589793
						local v22 = math.cos(v21) * v16
						local v23 = math.sin(v21) * v16
						if not v13(v22, v23, v14) then
							continue
						end
						v15 = {
							["x"] = v22,
							["z"] = v23
						}
					end
					v16 = v16 + 0.5
				end
			end
			table.insert(v_u_3, v15 or {
				["x"] = 0,
				["z"] = 0
			})
			table.insert(v_u_4, v14)
		end
		return v_u_3
	end
}