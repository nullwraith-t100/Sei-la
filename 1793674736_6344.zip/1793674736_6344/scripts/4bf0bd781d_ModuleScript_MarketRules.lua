local v_u_68 = {
	["blankIntent"] = function() -- name: blankIntent
		return {
			["item"] = "",
			["to"] = 0,
			["at"] = 0,
			["id"] = ""
		}
	end,
	["decode"] = function(p1) -- name: decode
		local v2 = {
			["counts"] = {},
			["recent"] = {}
		}
		if type(p1) ~= "table" then
			return v2
		end
		local v3 = p1.counts
		if type(v3) == "table" then
			for v4, v5 in v3 do
				if type(v4) ~= "string" or (type(v5) ~= "number" or (v5 ~= v5 or v5 < 0)) then
					continue
				end
				v2.counts[v4] = math.floor(v5)
			end
		end
		local v6 = p1.recent
		if type(v6) == "table" then
			for _, v7 in v6 do
				if type(v7) ~= "string" then
					continue
				end
				local v8 = v2.recent
				table.insert(v8, v7)
			end
		end
		return v2
	end,
	["takes"] = function(p9, p10, p11, p12) -- name: takes
		if p10[p9] then
			return { p9 }
		end
		local v13 = p11[p9]
		local v14 = {}
		if p12 and v13 then
			for _, v15 in v13 do
				if not p10[v15] then
					continue
				end
				table.insert(v14, v15)
			end
		end
		return v14
	end,
	["left"] = function(p16, p17, p18) -- name: left
		local v19 = (p18[p17] or 0) - (p16[p17] or 0)
		return math.max(0, v19)
	end,
	["leftOf"] = function(p20, p21, p22) -- name: leftOf
		-- upvalues: (copy) v_u_68
		local v23 = nil
		for _, v24 in p21 do
			local v25 = v_u_68.left(p20, v24, p22)
			if v23 ~= nil and v25 >= v23 then
				continue
			end
			v23 = v25
		end
		return v23
	end,
	["take"] = function(p26, p27, p28, p29) -- name: take
		if table.find(p26.recent, p27) then
			return false
		end
		for _, v30 in p28 do
			p26.counts[v30] = (p26.counts[v30] or 0) + 1
		end
		local v31 = p26.recent
		table.insert(v31, p27)
		while p29 < #p26.recent do
			table.remove(p26.recent, 1)
		end
		return true
	end,
	["merge"] = function(p32, p33) -- name: merge
		if type(p33) ~= "table" then
			return false
		end
		local v34 = false
		for v35, v36 in p33 do
			if type(v35) ~= "string" or (type(v36) ~= "number" or (v36 ~= v36 or (p32[v35] or 0) >= v36)) then
				continue
			end
			p32[v35] = math.floor(v36)
			v34 = true
		end
		return v34
	end,
	["intentValid"] = function(p37, p38, p39, p40, p41, p42) -- name: intentValid
		if p37.item ~= p38 or (p37.to <= 0 or p37.to == p40) then
			return false
		end
		if p37.id ~= "" then
			return p37.id == p39
		end
		local v43
		if p41 - p37.at >= 0 then
			v43 = p41 - p37.at <= p42
		else
			v43 = false
		end
		return v43
	end,
	["giftable"] = function(p44, p45, p46, p47) -- name: giftable
		local v48 = p47 and not p46[p44]
		if v48 then
			v48 = (p45[p44] or 0) ~= 0
		end
		return v48
	end,
	["giftRefusal"] = function(p49) -- name: giftRefusal
		return not p49.giftable and "This can\'t be gifted yet" or (p49.toSelf and "Pick another player to gift" or (not p49.recipientHere and "That player left the server" or (not p49.recipientReady and "That player is still loading, try again in a moment" or (p49.recipientOwns and "They already own it" or (p49.randomBlocked and "Random pets can\'t be gifted to or from this player" or (p49.left ~= nil and not p49.limitedKnown and "Still loading, try again in a moment" or (p49.left ~= nil and p49.left <= 0 and "SOLD OUT" or nil)))))))
	end,
	["buyRefusal"] = function(p50, p51, p52) -- name: buyRefusal
		return p50 and "You already own it" or (p52 == nil and "This can\'t be bought now" or (not p51 and "Still loading, try again in a moment" or (p52 <= 0 and "SOLD OUT" or nil)))
	end,
	["message"] = function(p53) -- name: message
		if type(p53) ~= "table" then
			return nil
		end
		local v54 = p53.kind
		local v55 = p53.item
		local v56 = p53.from
		local v57 = p53.name
		local v58 = p53.id
		return (v54 == "gift" or v54 == "credit") and (type(v55) == "string" and (type(v56) == "number" and (type(v57) == "string" and (type(v58) == "string" and v58 ~= "")))) and {
			["kind"] = v54 == "gift" and "gift" or "credit",
			["item"] = v55,
			["from"] = v56,
			["name"] = v57,
			["id"] = v58
		} or nil
	end,
	["creditId"] = function(p59) -- name: creditId
		return "credit:" .. p59
	end,
	["PRICE_REFUSAL"] = "Can\'t gift this one: it costs more in their country",
	["PRICE_LEVEL_MAX"] = 1000,
	["priceLevels"] = function(p60) -- name: priceLevels
		-- upvalues: (copy) v_u_68
		local v61 = {}
		if type(p60) ~= "table" then
			return v61
		end
		for _, v62 in p60 do
			if type(v62) ~= "table" then
				continue
			end
			local v63 = v62.UserId
			local v64 = v62.PriceLevel
			if type(v63) ~= "number" or (type(v64) ~= "number" or (v64 < 1 or v64 > v_u_68.PRICE_LEVEL_MAX)) then
				continue
			end
			v61[v63] = v64
		end
		return v61
	end,
	["priceRefusal"] = function(p65, p66, p67) -- name: priceRefusal
		-- upvalues: (copy) v_u_68
		if p67 or (p65 == nil or p66 == nil) then
			return nil
		elseif p65 < p66 then
			return v_u_68.PRICE_REFUSAL
		else
			return nil
		end
	end
}
return v_u_68