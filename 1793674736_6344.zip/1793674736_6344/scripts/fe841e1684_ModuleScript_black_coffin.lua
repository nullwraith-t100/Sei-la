local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_1.Shared.Config.Textures)
local v_u_7 = Color3.fromRGB(190, 130, 255)
local v_u_8 = Color3.fromRGB(14, 10, 20)
local function v_u_16(p9) -- name: piece
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_4
	local v10 = v_u_1:FindFirstChild("EyePieces")
	if v10 then
		v10 = v10:FindFirstChild("w6_black_coffin")
	end
	if not (v10 and v10:IsA("MeshPart")) then
		return nil
	end
	local v11 = v10:Clone()
	v11.Anchored = true
	v11.CanCollide = false
	v11.CanQuery = false
	v11.CanTouch = false
	v11.CastShadow = false
	v11.Massless = true
	local v12 = v10.Size.X
	local v13 = v10.Size.Y
	local v14 = v10.Size.Z
	local v15 = math.max(v12, v13, v14, 0.01)
	v11.Size = v10.Size * (p9 / v15)
	if not v11:FindFirstChildOfClass("SurfaceAppearance") then
		v11.Color = v_u_8
		v11.Material = Enum.Material.SmoothPlastic
		v11.Reflectance = 0.15
	end
	v11.Parent = v_u_4.folder()
	return v11
end
local function v_u_22(p17, p18, p19) -- name: squareWave
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_2
	local v20 = Instance.new("Attachment")
	v20.Parent = v_u_3.Terrain
	v20.WorldPosition = p17 + Vector3.new(0, 0.2, 0)
	local v21 = Instance.new("ParticleEmitter")
	v21.Texture = v_u_6.CoffinRipple
	v21.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v21.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v21.Color = ColorSequence.new(p19)
	v21.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 * 0.25), NumberSequenceKeypoint.new(1, p18 * 0.5) })
	v21.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 1) })
	v21.Lifetime = NumberRange.new(0.45)
	v21.LightEmission = 0.7
	v21.LightInfluence = 0
	v21.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v21.EmissionDirection = Enum.NormalId.Top
	v21.Speed = NumberRange.new(0.02)
	v21.SpreadAngle = Vector2.zero
	v21.Rotation = NumberRange.new(0)
	v21.Rate = 0
	v21.Parent = v20
	v21:Emit(1)
	v_u_2:AddItem(v20, 0.7)
end
return function(p_u_23)
	-- upvalues: (copy) v_u_4, (copy) v_u_22, (copy) v_u_5, (copy) v_u_6, (copy) v_u_16, (copy) v_u_8, (copy) v_u_7
	return {
		["w6_black_coffin"] = function(p_u_24, p25)
			-- upvalues: (ref) v_u_4, (copy) p_u_23, (ref) v_u_22, (ref) v_u_5, (ref) v_u_6, (ref) v_u_16, (ref) v_u_8, (ref) v_u_7
			local v_u_26 = v_u_4.color(p25.color)
			local v27 = p_u_24.headY / 1.5
			local v_u_28 = math.clamp(v27, 0.7, 3)
			local v_u_29 = nil
			local v_u_32 = p_u_23.throb(p_u_24, 4, 1.8, 1.25, function(p30)
				-- upvalues: (ref) v_u_22, (ref) p_u_23, (copy) p_u_24, (copy) v_u_28, (copy) v_u_26, (ref) v_u_29, (ref) v_u_5
				v_u_22(p_u_23.feetAt(p_u_24, p30, 0), v_u_28 * 9 * p_u_24.fx, v_u_26)
				local v31 = v_u_29
				if v31 then
					v31:Emit(v_u_5.level() <= 1 and 4 or 10)
				end
			end)
			local v_u_33 = 0
			local v34 = p_u_24.ticks
			local function v40()
				-- upvalues: (ref) v_u_33, (copy) v_u_32
				local v35 = v_u_32()
				local v36
				if v35 <= 0 then
					v36 = 0
				else
					local v37 = (1 - v35) / 1.25
					if v37 < 0.1 then
						v36 = (v37 / 0.1) ^ 2
					elseif v37 < 0.25 then
						v36 = 1
					else
						local v38 = (v37 - 0.25) / 0.5
						local v39 = math.clamp(v38, 0, 1)
						v36 = 1 - v39 * v39 * (3 - v39 * 2)
					end
				end
				v_u_33 = v36
			end
			table.insert(v34, v40)
			local v_u_46 = p_u_23.group(p_u_24, function(p41, p42)
				-- upvalues: (copy) v_u_28
				local v43 = CFrame.new
				local v44 = v_u_28 * 1.7
				local v45 = p42 * 1.2
				return p41 * v43(0, v44 + math.sin(v45) * 0.12 * v_u_28, v_u_28 * 1.75) * CFrame.Angles(0, p42 * 0.6, 0)
			end)
			local v47 = p_u_23.picture(v_u_28 * 5.2, v_u_6.Glow, v_u_26, 0.15)
			p_u_23.add(p_u_24, v47, function()
				-- upvalues: (copy) v_u_46, (ref) p_u_23, (copy) v_u_28
				local v48 = v_u_46.cf.Position + Vector3.new(0, 0, 0)
				local v49 = p_u_23.camPos() - v48
				local v50 = v49.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v49.Unit
				local v51 = v50.Y
				local v52 = math.abs(v51) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v48 - v50 * 0.6 * v_u_28, v48 + v50, v52) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			p_u_23.fadeFromBehind(p_u_24, v47, 0.3)
			local v53 = v_u_16(v_u_28 * 3.3)
			local v_u_54
			if v53 then
				v_u_54 = v53:FindFirstChildOfClass("SurfaceAppearance")
			else
				v_u_54 = nil
			end
			local v_u_55 = not v_u_54 and 0 or v_u_54.EmissiveStrength
			local v_u_56
			if v53 then
				p_u_23.pin(p_u_24, v_u_46, v53, CFrame.identity)
				v_u_56 = v_u_33
			else
				local v57 = p_u_23.dark(p_u_23.bar(Vector3.new(0.5, 2.3, 0.5) * v_u_28, v_u_8, 0, Enum.Material.SmoothPlastic))
				p_u_23.pin(p_u_24, v_u_46, v57, CFrame.new(0, v_u_28 * -0.2, 0))
				local v58 = p_u_23.dark(p_u_23.bar(Vector3.new(0.5, 0.5, 0.5) * v_u_28, v_u_8, 0, Enum.Material.SmoothPlastic))
				p_u_23.pin(p_u_24, v_u_46, v58, CFrame.new(0, v_u_28 * 1.05, 0) * CFrame.Angles(0.7853981633974483, 0, 0.7853981633974483))
				v_u_56 = v_u_33
				for _, v59 in { -1, 1 } do
					local v60 = p_u_23.bar(Vector3.new(0.08, 2.1, 0.08) * v_u_28, v_u_26, 0)
					p_u_23.pin(p_u_24, v_u_46, v60, CFrame.new(v59 * 0.26 * v_u_28, v_u_28 * -0.2, v59 * 0.26 * v_u_28))
				end
			end
			if v_u_54 then
				local v61 = p_u_24.ticks
				table.insert(v61, function()
					-- upvalues: (copy) v_u_54, (copy) v_u_55, (ref) v_u_56
					v_u_54.EmissiveStrength = v_u_55 * (v_u_56 * 2.2 + 1)
				end)
			end
			local v_u_67 = p_u_23.group(p_u_24, function(p62, p63)
				-- upvalues: (copy) v_u_28
				local v64 = CFrame.new
				local v65 = p62.Position
				local v66 = v_u_28 * -0.15
				return v64(v65 + Vector3.new(0, v66, 0)) * CFrame.Angles(0, p63 * 0.35, 0)
			end)
			local v_u_68 = CFrame.Angles(0, 3.141592653589793, 0)
			for v_u_69 = 1, 8 do
				local v70 = (v_u_69 - 1) * 3.141592653589793 * 2 / 8
				local v71 = math.cos(v70)
				local v72 = math.sin(v70)
				local v_u_73 = Vector3.new(v71, 0, v72)
				local v74 = p_u_23.dark
				local v75 = p_u_23.bar
				local v76 = v_u_28 * 0.14
				local v77 = v_u_28 * 0.5
				local v78 = v_u_28 * 1.4
				local v79 = v74(v75(Vector3.new(v76, v77, v78), v_u_8, 0, Enum.Material.SmoothPlastic))
				v79.Shape = Enum.PartType.Wedge
				v79.Reflectance = 0.04
				local v80 = p_u_23.bar
				local v81 = v_u_28 * 0.08
				local v82 = v_u_28 * 0.36
				local v83 = v_u_28 * 1.2
				local v84 = v80(Vector3.new(v81, v82, v83), v_u_7, 0)
				v84.Shape = Enum.PartType.Wedge
				p_u_23.add(p_u_24, v79, function()
					-- upvalues: (ref) v_u_56, (copy) v_u_28, (copy) v_u_73, (copy) v_u_69, (copy) v_u_67, (copy) v_u_68
					local v85 = v_u_73 * ((2.6 - v_u_56 * 0.6) * v_u_28)
					local v86 = v_u_69 * 1.9
					local v87 = math.sin(v86) * 0.25 * v_u_28 + 0
					local v88 = v85 + Vector3.new(0, v87, 0)
					local v89 = v_u_67.cf
					local v90 = CFrame.lookAt
					local v91 = v88.Y
					return v89 * v90(v88, (Vector3.new(0, v91, 0))) * v_u_68
				end)
				p_u_23.add(p_u_24, v84, function()
					-- upvalues: (ref) v_u_56, (copy) v_u_28, (copy) v_u_73, (copy) v_u_69, (copy) v_u_67, (copy) v_u_68
					local v92 = v_u_73 * ((2.6 - v_u_56 * 0.6) * v_u_28)
					local v93 = v_u_69 * 1.9
					local v94 = math.sin(v93) * 0.25 * v_u_28 + 0
					local v95 = v92 + Vector3.new(0, v94, 0)
					local v96 = v_u_67.cf
					local v97 = CFrame.lookAt
					local v98 = v95.Y
					return v96 * v97(v95, (Vector3.new(0, v98, 0))) * v_u_68 * CFrame.new(0, 0, v_u_28 * 0.05) * CFrame.Angles(0, 0, 1.5707963267948966)
				end)
			end
			local v99 = p_u_23.bar
			local v100 = v_u_28 * 4.5
			local v101 = v_u_28 * 4.5
			local v102 = v99(Vector3.new(v100, 0.2, v101), v_u_26, 1)
			p_u_23.add(p_u_24, v102, function(p103)
				-- upvalues: (ref) p_u_23, (copy) p_u_24
				return CFrame.new(p_u_23.feetAt(p_u_24, p103, 0.3))
			end)
			local v104 = Instance.new("ParticleEmitter")
			v104.Texture = v_u_6.CoffinSquare
			v104.Color = ColorSequence.new(v_u_26, v_u_7)
			v104.LightEmission = 0
			v104.LightInfluence = 0
			v104.Lifetime = NumberRange.new(1.1, 1.7)
			v104.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.2, v_u_28 * 0.42 * p_u_24.fx), NumberSequenceKeypoint.new(1, v_u_28 * 0.1 * p_u_24.fx) })
			v104.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.7, 0.2), NumberSequenceKeypoint.new(1, 1) })
			v104.Speed = NumberRange.new(1.5 * p_u_24.fx, 3.5 * p_u_24.fx)
			v104.SpreadAngle = Vector2.new(25, 25)
			v104.EmissionDirection = Enum.NormalId.Top
			v104.Shape = Enum.ParticleEmitterShape.Box
			v104.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v104.Rotation = NumberRange.new(-45, 45)
			v104.RotSpeed = NumberRange.new(-70, 70)
			v104.Rate = 5 * v_u_5.formRate()
			v104.Parent = v102
			v_u_29 = v104
			p_u_23.particles(p_u_24, "AuraMode", v_u_26, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end