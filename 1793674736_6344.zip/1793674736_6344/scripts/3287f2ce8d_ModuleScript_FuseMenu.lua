local v1 = game:GetService("Players")
local v_u_2 = game:GetService("MarketplaceService")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent.Device)
local v_u_8 = require(script.Parent.Events)
local v_u_9 = require(script.Parent.Gamepad)
local v_u_10 = require(script.Parent.ArcadeKit)
local v_u_11 = require(script.Parent.Menus)
local v_u_12 = require(script.Parent.OfferLog)
local v_u_13 = require(script.Parent.PetLooks)
local v_u_14 = require(script.Parent.PetModels)
local v_u_15 = require(script.Parent.PetTile)
local v_u_16 = require(script.Parent.Sfx)
local v_u_17 = require(script.Parent.State)
local v_u_18 = require(script.Parent.Store)
local v_u_19 = require(script.Parent.StoreLook)
local v20 = v_u_3.Shared
local v_u_21 = require(v20.Config.Fuse)
local v_u_22 = require(v20.Config.Pets)
local v_u_23 = require(v20.Config.Products)
local v_u_24 = require(v20.Config.Release)
local v_u_25 = require(v20.Logic.Fuse)
local v_u_26 = require(v20.Logic.Format)
local v_u_27 = require(v20.Logic.OfferLog)
local v_u_28 = {}
local v_u_29 = v1.LocalPlayer
local v_u_30 = v_u_21.COUNT
local v_u_31 = Color3.new(1, 1, 1)
local v_u_32 = Color3.new(0, 0, 0)
local v_u_33 = Color3.fromRGB(58, 255, 14)
local v_u_34 = Color3.fromRGB(40, 196, 14)
local v_u_35 = Color3.fromRGB(150, 152, 165)
local v_u_36 = Color3.fromRGB(90, 92, 104)
local v_u_37 = Color3.fromRGB(64, 64, 78)
local v_u_38 = Color3.fromRGB(30, 30, 40)
local v_u_39 = Color3.fromRGB(69, 200, 255)
local v_u_40 = Color3.fromRGB(0, 128, 255)
local v_u_41 = Color3.fromRGB(236, 238, 248)
local v_u_42 = Color3.fromRGB(255, 226, 60)
local v_u_43 = Color3.fromRGB(255, 240, 90)
local v_u_44 = Color3.fromRGB(255, 96, 110)
local v_u_45 = Color3.fromRGB(124, 255, 79)
local v_u_46 = Color3.fromRGB(34, 34, 46)
local function v_u_55(p47) -- name: tierLook
	-- upvalues: (copy) v_u_21, (copy) v_u_13
	local v48 = v_u_21.tier(p47)
	local _, v49 = v_u_13.tag(p47)
	local v50 = v49.Keypoints
	local v51 = {
		["colours"] = v49
	}
	local v52
	if v48 == nil then
		v52 = false
	else
		v52 = v48.id == "rainbow"
	end
	v51.rainbow = v52
	local v53 = #v50 / 2
	local v54 = math.ceil(v53)
	v51.main = v50[math.max(1, v54)].Value
	return v51
end
local v_u_56 = {}
local v_u_57 = {}
local v_u_58 = {}
local v_u_59 = false
local v_u_60 = 90000
local function v_u_73() -- name: seedFake
	-- upvalues: (ref) v_u_59, (ref) v_u_60, (copy) v_u_56, (copy) v_u_57, (copy) v_u_22, (copy) v_u_21, (copy) v_u_58
	if not v_u_59 then
		v_u_59 = true
		local v61 = {
			["Common"] = {
				["count"] = 9,
				["tier"] = 0,
				["equip"] = 2
			},
			["Rare"] = {
				["count"] = 5,
				["tier"] = 0,
				["equip"] = 0
			},
			["Epic"] = {
				["count"] = 4,
				["tier"] = 1,
				["equip"] = 1
			},
			["Legendary"] = {
				["count"] = 6,
				["tier"] = 2,
				["equip"] = 0
			},
			["Mythic"] = {
				["count"] = 2,
				["tier"] = 3,
				["equip"] = 0
			}
		}
		local v62 = false
		for _, v63 in v_u_22.list do
			local v64 = v61[v63.rarity]
			if v64 and v_u_21.fusable(v63.id) then
				v61[v63.rarity] = nil
				for v65 = 1, v64.count do
					local v66 = v63.id
					local v67 = v64.tier
					v_u_60 = v_u_60 + 1
					local v68 = v_u_60
					local v69 = tostring(v68)
					v_u_56[v69] = v66
					if v67 > 0 then
						v_u_57[v69] = v67
					end
					if v65 > v64.equip then
						continue
					end
					local v70 = v_u_58
					table.insert(v70, v69)
				end
			else
				if not v63.pass or v62 then
					continue
				end
				v62 = true
				local v71 = v63.id
				v_u_60 = v_u_60 + 1
				local v72 = v_u_60
				v_u_56[tostring(v72)] = v71
			end
		end
	end
end
local function v_u_74() -- name: world
	-- upvalues: (copy) v_u_17
	return v_u_17.number("World", 1)
end
local function v_u_83(p75) -- name: fakeFuse
	-- upvalues: (copy) v_u_25, (copy) v_u_56, (copy) v_u_57, (ref) v_u_60, (copy) v_u_58
	local v76, v77 = v_u_25.check(v_u_56, v_u_57, p75)
	if v76 or not v77 then
		return false, v76, nil
	end
	v_u_60 = v_u_60 + 1
	local v78 = v_u_60
	local v79 = tostring(v78)
	local v80, v81 = v_u_25.result(v77.kind, v77.tier)
	local v82 = {
		["Pets"] = v_u_56,
		["PetTiers"] = v_u_57,
		["Equipped"] = v_u_58
	}
	v_u_25.apply(v82, v77, v79, v81)
	return true, nil, {
		["uid"] = v79,
		["kind"] = v80,
		["tier"] = v81
	}
end
local function v_u_94(p_u_84) -- name: callFuse
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_83, (copy) v_u_3
	local v85 = v_u_4:IsStudio()
	if v85 then
		v85 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	if v85 then
		return v_u_83(p_u_84)
	end
	local v_u_86 = v_u_3:FindFirstChild("Remotes")
	if v_u_86 then
		v_u_86 = v_u_86:FindFirstChild("Fuse")
	end
	if not (v_u_86 and v_u_86:IsA("RemoteFunction")) then
		return false, "The fuse machine isn\'t ready yet, try again soon!", nil
	end
	local v87, v88, v89, v90 = pcall(function()
		-- upvalues: (copy) v_u_86, (copy) p_u_84
		return v_u_86:InvokeServer("fuse", p_u_84)
	end)
	if not v87 then
		return false, "Couldn\'t reach the server, try again!", nil
	end
	if v88 ~= true then
		return false, (type(v89) ~= "string" or v89 == "") and "That didn\'t work, try again!" or v89, nil
	end
	if type(v90) == "table" then
		local v91 = v90.uid
		local v92 = v90.kind
		local v93 = v90.tier
		if type(v91) == "string" and (type(v92) == "string" and type(v93) == "number") then
			return true, nil, {
				["uid"] = v91,
				["kind"] = v92,
				["tier"] = v93
			}
		end
	end
	return true, nil, nil
end
local v_u_95 = {
	["void"] = 1
}
local function v_u_105(p96) -- name: skipOffered
	-- upvalues: (copy) v_u_25, (copy) v_u_4, (copy) v_u_29, (copy) v_u_95, (copy) v_u_17, (copy) v_u_23, (copy) v_u_6
	local v97 = v_u_25.creditId(p96)
	local v98
	if v97 then
		local v99 = v_u_4:IsStudio()
		if v99 then
			v99 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		local v100
		if v99 then
			v100 = v_u_95
		else
			v100 = v_u_17.fuseCredits()
		end
		v98 = v100[v97] or 0
	else
		v98 = 0
	end
	if v98 <= 0 then
		local v101 = v_u_4:IsStudio()
		if v101 then
			v101 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		if not v101 then
			local v102 = v_u_25.skipKey(p96)
			local v103
			if v102 then
				v103 = v_u_23.productByKey[v102]
			else
				v103 = nil
			end
			if not v103 then
				return false
			end
			local v104 = v103.id == 0 and v_u_4:IsStudio()
			if v104 then
				v104 = v_u_6:GetAttribute("DevFuseKit") == true
			end
			return v104
		end
	end
	return true
end
local function v_u_124(p_u_106) -- name: callSkip
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_56, (copy) v_u_25, (copy) v_u_57, (copy) v_u_95, (copy) v_u_3
	local v107 = v_u_4:IsStudio()
	if v107 then
		v107 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	if v107 then
		local v108 = v_u_56[p_u_106]
		local v109 = v_u_25.tierOf(v_u_57, p_u_106)
		if not (v108 and v_u_25.canSkip(v108, v109)) then
			return false, "That pet can\'t go higher", nil
		end
		local v110 = v_u_25.creditId(v109 + 1)
		if v110 and (v_u_95[v110] or 0) > 0 then
			local v111 = v_u_95
			v111[v110] = v111[v110] - 1
		end
		v_u_57[p_u_106] = v109 + 1
		return true, nil, {
			["uid"] = nil,
			["kind"] = nil,
			["tier"] = nil,
			["credit"] = true,
			["studio"] = false,
			["uid"] = p_u_106,
			["kind"] = v108,
			["tier"] = v109 + 1
		}
	end
	local v_u_112 = v_u_3:FindFirstChild("Remotes")
	if v_u_112 then
		v_u_112 = v_u_112:FindFirstChild("Fuse")
	end
	if not (v_u_112 and v_u_112:IsA("RemoteFunction")) then
		return false, "The fuse machine isn\'t ready yet, try again soon!", nil
	end
	local v113, v114, v115, v116 = pcall(function()
		-- upvalues: (copy) v_u_112, (copy) p_u_106
		return v_u_112:InvokeServer("skip", p_u_106)
	end)
	if not v113 then
		return false, "Couldn\'t reach the server, try again!", nil
	end
	if v114 ~= true or type(v116) ~= "table" then
		return false, (type(v115) ~= "string" or v115 == "") and "That didn\'t work, try again!" or v115, nil
	end
	local v117 = v116.uid
	local v118 = v116.kind
	local v119 = v116.tier
	local v120 = v116.productId
	if type(v117) ~= "string" or (type(v118) ~= "string" or type(v119) ~= "number") then
		return false, "That didn\'t work, try again!", nil
	end
	local v121 = true
	local v122 = nil
	local v123 = {
		["uid"] = v117,
		["kind"] = v118,
		["tier"] = v119,
		["credit"] = v116.credit == true
	}
	if type(v120) ~= "number" or v120 <= 0 then
		v120 = nil
	end
	v123.productId = v120
	v123.studio = v116.studio == true
	return v121, v122, v123
end
local v_u_125 = {
	nil,
	nil,
	nil,
	nil
}
local function v_u_134() -- name: filter
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_73, (copy) v_u_56, (copy) v_u_17, (copy) v_u_30, (copy) v_u_125, (copy) v_u_25, (copy) v_u_57
	local v126 = v_u_4:IsStudio()
	if v126 then
		v126 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v127
	if v126 then
		v_u_73()
		v127 = v_u_56
	else
		v127 = v_u_17.pets()
	end
	for v128 = 1, v_u_30 do
		local v129 = v_u_125[v128]
		local v130
		if v129 then
			v130 = v127[v129]
		else
			v130 = v129
		end
		if not (v129 and v130) then
			continue
		end
		local v131 = v_u_25.tierOf
		local v132 = v_u_4:IsStudio()
		if v132 then
			v132 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		local v133
		if v132 then
			v133 = v_u_57
		else
			v133 = v_u_17.petTiers()
		end
		return v130, v131(v133, v129)
	end
	return nil, 0
end
local function v_u_154() -- name: validate
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_73, (copy) v_u_56, (copy) v_u_17, (copy) v_u_57, (copy) v_u_30, (copy) v_u_125, (copy) v_u_25, (copy) v_u_22, (copy) v_u_21, (copy) v_u_105
	local v135 = v_u_4:IsStudio()
	if v135 then
		v135 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v136
	if v135 then
		v_u_73()
		v136 = v_u_56
	else
		v136 = v_u_17.pets()
	end
	local v137 = v_u_4:IsStudio()
	if v137 then
		v137 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v138
	if v137 then
		v138 = v_u_57
	else
		v138 = v_u_17.petTiers()
	end
	local v139 = nil
	local v140 = 0
	for v141 = 1, v_u_30 do
		local v142 = v_u_125[v141]
		if not v142 then
			continue
		end
		local v143 = v136[v142]
		local v144 = v_u_25.tierOf(v138, v142)
		local v145
		if v143 == nil then
			v145 = false
		else
			v145 = v_u_25.canFuse(v143, v144)
			if not v145 then
				local v146
				if v_u_22.byId[v143] == nil then
					v146 = false
				else
					v146 = not v_u_21.fusable(v143)
				end
				v145 = v146 and v_u_25.canSkip(v143, v144)
				if v145 then
					v145 = v_u_105(v144 + 1)
				end
			end
			if v145 then
				if v139 == nil then
					v145 = true
				elseif v143 == v139 then
					v145 = v144 == v140
				else
					v145 = false
				end
			end
		end
		if v145 then
			if v139 then
				continue
			end
			v140 = v144
			v139 = v143
		else
			v_u_125[v141] = nil
		end
	end
	local v147 = {}
	for v148 = 1, v_u_30 do
		local v149 = v_u_125[v148]
		if not v149 then
			continue
		end
		table.insert(v147, v149)
	end
	if #v147 > 1 then
		local v150 = v_u_4:IsStudio()
		if v150 then
			v150 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		local v151 = v150 and {} or v_u_17.lockedPets()
		for v152 = 1, v_u_30 do
			local v153 = v_u_125[v152]
			if not (v153 and v151[v153]) then
				continue
			end
			v_u_125[v152] = nil
		end
	end
end
local function v_u_201() -- name: stacks
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_73, (copy) v_u_56, (copy) v_u_17, (copy) v_u_57, (copy) v_u_58, (copy) v_u_30, (copy) v_u_125, (copy) v_u_134, (copy) v_u_25, (copy) v_u_22, (copy) v_u_21, (copy) v_u_105, (copy) v_u_74
	local v155 = v_u_4:IsStudio()
	if v155 then
		v155 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v156
	if v155 then
		v_u_73()
		v156 = v_u_56
	else
		v156 = v_u_17.pets()
	end
	local v157 = v_u_4:IsStudio()
	if v157 then
		v157 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v158
	if v157 then
		v158 = v_u_57
	else
		v158 = v_u_17.petTiers()
	end
	local v159 = v_u_4:IsStudio()
	if v159 then
		v159 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v_u_160
	if v159 then
		v_u_160 = v_u_58
	else
		v_u_160 = v_u_17.equipped()
	end
	local v161 = {}
	for v162 = 1, v_u_30 do
		local v163 = v_u_125[v162]
		if not v163 then
			continue
		end
		table.insert(v161, v163)
	end
	local v164 = v_u_4:IsStudio()
	if v164 then
		v164 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v165 = v164 and {} or v_u_17.lockedPets()
	local v166 = {}
	for v167 = 1, v_u_30 do
		local v168 = v_u_125[v167]
		if not v168 then
			continue
		end
		table.insert(v166, v168)
	end
	for _, v169 in v166 do
		if not v165[v169] then
			continue
		end
		v170 = true
	end
	local v170 = false
	if v170 then
		return {}
	end
	local v171 = v_u_4:IsStudio()
	if v171 then
		v171 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v172 = v171 and {} or v_u_17.lockedPets()
	local v173, v174 = v_u_134()
	local v175 = {}
	local v176 = {}
	for v177, v178 in v156 do
		if table.find(v161, v177) then
			continue
		end
		local v179 = v_u_25.tierOf(v158, v177)
		local v180 = v_u_22.byId[v178]
		if not v180 then
			continue
		end
		local v181 = v_u_25.canFuse(v178, v179)
		if not v181 then
			local v182
			if v_u_22.byId[v178] == nil then
				v182 = false
			else
				v182 = not v_u_21.fusable(v178)
			end
			v181 = v182 and v_u_25.canSkip(v178, v179)
			if v181 then
				v181 = v_u_105(v179 + 1)
			end
		end
		if not v181 or v173 and (v178 ~= v173 or v179 ~= v174) then
			continue
		end
		local v183
		if v172[v177] == true then
			local v184
			if v_u_22.byId[v178] == nil then
				v184 = false
			else
				v184 = not v_u_21.fusable(v178)
			end
			v183 = not v184
		else
			v183 = false
		end
		if v183 and (#v161 > 0 or not (v_u_25.canSkip(v178, v179) and v_u_105(v179 + 1))) then
			continue
		end
		local v185 = v178 .. "|" .. v179 .. (v183 and "|locked" or "")
		local v186 = v175[v185]
		if not v186 then
			v186 = {
				["kind"] = nil,
				["tier"] = nil,
				["pet"] = nil,
				["uids"] = nil,
				["equipped"] = 0,
				["mult"] = nil,
				["only"] = nil,
				["locked"] = nil,
				["kind"] = v178,
				["tier"] = v179,
				["pet"] = v180,
				["uids"] = {},
				["mult"] = v_u_25.mult(v178, v179, v_u_74())
			}
			local v187
			if v_u_22.byId[v178] == nil then
				v187 = false
			else
				v187 = not v_u_21.fusable(v178)
			end
			v186.only = v187
			v186.locked = v183
			v175[v185] = v186
			table.insert(v176, v186)
		end
		local v188 = v186.uids
		table.insert(v188, v177)
		if not table.find(v_u_160, v177) then
			continue
		end
		v186.equipped = v186.equipped + 1
	end
	for _, v189 in v176 do
		table.sort(v189.uids, function(p190, p191)
			-- upvalues: (copy) v_u_160
			local v192 = table.find(v_u_160, p190) ~= nil
			local v193 = table.find(v_u_160, p191) ~= nil
			if v192 == v193 then
				local v194 = tonumber(p190)
				local v195 = tonumber(p191)
				if v194 and (v195 and v194 ~= v195) then
					return v194 < v195
				else
					return p190 < p191
				end
			else
				return v193
			end
		end)
	end
	local v_u_196 = v_u_30 - #v161
	table.sort(v176, function(p197, p198)
		-- upvalues: (copy) v_u_196
		local v199
		if v_u_196 <= #p197.uids then
			v199 = not p197.locked
		else
			v199 = false
		end
		local v200
		if v_u_196 <= #p198.uids then
			v200 = not p198.locked
		else
			v200 = false
		end
		if v199 == v200 then
			if p197.mult == p198.mult then
				if p197.tier == p198.tier then
					return p197.pet.name < p198.pet.name
				else
					return p197.tier > p198.tier
				end
			else
				return p197.mult > p198.mult
			end
		else
			return v199
		end
	end)
	return v176
end
local function v_u_208() -- name: anyEquippedInside
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_58, (copy) v_u_17, (copy) v_u_30, (copy) v_u_125
	local v202 = v_u_4:IsStudio()
	if v202 then
		v202 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v203
	if v202 then
		v203 = v_u_58
	else
		v203 = v_u_17.equipped()
	end
	local v204 = {}
	for v205 = 1, v_u_30 do
		local v206 = v_u_125[v205]
		if not v206 then
			continue
		end
		table.insert(v204, v206)
	end
	for _, v207 in v204 do
		if not table.find(v203, v207) then
			continue
		end
		return true
	end
	return false
end
local v_u_209 = nil
local v_u_210 = "machine"
local v_u_211 = 1
local v_u_212 = false
local v_u_213 = false
local v_u_214 = 0
local v_u_215 = ""
local v_u_216 = false
local v_u_217 = 0
local v_u_218 = nil
local v_u_219 = {}
local function v_u_222(p220, p221) -- name: setFlow
	-- upvalues: (copy) v_u_219, (copy) v_u_55
	if p221 and p221 > 0 then
		p220.Color = v_u_55(p221).colours
		v_u_219[p220] = {
			["tier"] = p221,
			["phase"] = math.random() * 2
		}
	else
		v_u_219[p220] = nil
	end
end
local function v_u_228() -- name: stepFlows
	-- upvalues: (copy) v_u_219, (copy) v_u_55, (copy) v_u_19
	local v223 = os.clock()
	for v224, v225 in v_u_219 do
		if v224.Parent then
			if v_u_55(v225.tier).rainbow then
				v224.Color = v_u_19.rainbow((v223 * 0.3 + v225.phase) % 1, 0.85)
			else
				local v226 = Vector2.new
				local v227 = v223 * 2.2 + v225.phase
				v224.Offset = v226(0, math.sin(v227) * 0.2)
			end
		else
			v_u_219[v224] = nil
		end
	end
end
local function v_u_235(p229, p230, p231) -- name: packButton
	-- upvalues: (copy) v_u_10
	local v232 = p229:Clone()
	v232.Name = p230
	v232.Visible = true
	v232.Selectable = true
	for _, v233 in {
		"Ui-Frame",
		"Ui-Close",
		"Ui-Pass",
		"Ui-Product",
		"Ui-Pack"
	} do
		v232:SetAttribute(v233, nil)
	end
	for _, v234 in v232:GetChildren() do
		if v234.Name ~= "PadHint" and not v234:IsA("UIScale") then
			continue
		end
		v234:Destroy()
	end
	v232:SetAttribute("Pad", true)
	v_u_10.setText(v232, p231)
	return v232
end
local function v_u_238(p236) -- name: clearView
	for _, v237 in p236:GetChildren() do
		if not (v237:IsA("Model") or (v237:IsA("Camera") or v237:IsA("WorldModel"))) then
			continue
		end
		v237:Destroy()
	end
end
local function v_u_244(p239, p240) -- name: showTag
	-- upvalues: (copy) v_u_13
	for _, v241 in p239:GetChildren() do
		v241:Destroy()
	end
	local v242 = v_u_13.tagLabel(p240)
	if v242 then
		v242.ZIndex = p239.ZIndex
		for _, v243 in v242:GetDescendants() do
			if not v243:IsA("GuiObject") then
				continue
			end
			v243.ZIndex = p239.ZIndex
		end
		v242.Parent = p239
	end
end
local function v_u_250(p245, p246, p247) -- name: newCard
	-- upvalues: (copy) v_u_15
	local v248 = p245:Clone()
	v248.Name = p246
	v248.Visible = true
	v248.Active = true
	v248.AutoButtonColor = false
	v248.Selectable = true
	v248:SetAttribute("Pad", true)
	v248:SetAttribute("Ui-Hover", "Expand")
	v248:SetAttribute("Ui-Hover-Rate", 1.06)
	v248:SetAttribute("Ui-Click", "In")
	v248:SetAttribute("Ui-Click-Rate", 0.92)
	local v249 = v248:FindFirstChild("On")
	if v249 and v249:IsA("GuiObject") then
		v249.Interactable = false
		v249.Visible = false
	end
	return v248, v_u_15.dress(v248, p247)
end
local function v_u_259(p251, p252, p253) -- name: slotOf
	-- upvalues: (copy) v_u_31
	local v254 = p252:FindFirstChild("View")
	local v255 = Instance.new("UIScale")
	v255.Name = "Suck"
	v255.Parent = v254
	local v256 = p252:FindFirstChild("Mult")
	local v257 = v_u_31
	local v258 = p251.label:Clone()
	v258.Name = "Plus"
	v258.Text = "+"
	v258.TextColor3 = v257
	v258.TextScaled = true
	v258.Rotation = 0
	v258.Visible = true
	v258.Parent = p252
	v258.AnchorPoint = Vector2.new(0.5, 0.5)
	v258.Position = UDim2.fromScale(0.5, 0.47)
	v258.Size = UDim2.fromScale(0.6, 0.6)
	v258.ZIndex = 8
	return {
		["card"] = nil,
		["tile"] = nil,
		["view"] = nil,
		["suck"] = nil,
		["plus"] = nil,
		["mult"] = nil,
		["badge"] = nil,
		["shown"] = "",
		["card"] = p252,
		["tile"] = p253,
		["view"] = v254,
		["suck"] = v255,
		["plus"] = v258,
		["mult"] = v256,
		["badge"] = p252:FindFirstChild("On")
	}
end
local function v_u_268(p260, p261, p262, p263, p264, p265) -- name: newPipe
	-- upvalues: (copy) v_u_46, (copy) v_u_32
	local v266 = Instance.new("Frame")
	v266.Name = "Pipe"
	v266.BackgroundColor3 = v_u_46
	v266.BorderSizePixel = 0
	v266.AnchorPoint = Vector2.new(0.5, 0.5)
	v266.Position = UDim2.fromScale(p261, p262)
	v266.Size = UDim2.fromScale(p263, p264)
	v266.ZIndex = p265
	local v267 = Instance.new("UIStroke")
	v267.Color = v_u_32
	v267.Thickness = 2
	v267.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v267.Parent = v266
	v266.Parent = p260
	return v266
end
local function v_u_276(p269, p270, p271, p272) -- name: newFill
	-- upvalues: (copy) v_u_31
	local v273 = Instance.new("Frame")
	v273.Name = "Fill"
	v273.BackgroundColor3 = v_u_31
	v273.BorderSizePixel = 0
	v273.ZIndex = p269.ZIndex
	local v274
	if p270 == "down" then
		v273.AnchorPoint = Vector2.new(0.5, 0)
		v273.Position = UDim2.fromScale(0.5, 0)
		v274 = UDim2.fromScale(1, 1)
	elseif p270 == "right" then
		v273.AnchorPoint = Vector2.new(0, 0.5)
		v273.Position = UDim2.fromScale(p271, 0.5)
		v274 = UDim2.fromScale(p272, 1)
	else
		v273.AnchorPoint = Vector2.new(1, 0.5)
		v273.Position = UDim2.fromScale(p271, 0.5)
		v274 = UDim2.fromScale(p272, 1)
	end
	v273.Size = UDim2.fromScale(p270 == "down" and 1 or 0, p270 == "down" and 0 or 1)
	v273.Visible = false
	local v275 = Instance.new("UIGradient")
	v275.Rotation = p270 == "down" and 0 or 90
	v275.Parent = v273
	v273.Parent = p269
	return {
		["fill"] = nil,
		["paint"] = nil,
		["grow"] = nil,
		["size"] = nil,
		["lit"] = false,
		["fill"] = v273,
		["paint"] = v275,
		["grow"] = p270,
		["size"] = v274
	}
end
local function v_u_286(p_u_277, p278, p279) -- name: light
	-- upvalues: (copy) v_u_222, (copy) v_u_55, (copy) v_u_10, (copy) v_u_219
	local v280
	if p278 == nil then
		v280 = false
	else
		v280 = p278 > 0
	end
	if v280 then
		v_u_222(p_u_277.paint, p278)
		local v281
		if p278 == nil then
			v281 = false
		else
			v281 = v_u_55(p278).rainbow
		end
		local v282 = p_u_277.paint
		local v283
		if p_u_277.grow == "down" then
			v283 = v281 and 90 or 0
		else
			v283 = v281 and 0 or 90
		end
		v282.Rotation = v283
	end
	if v280 == p_u_277.lit then
		return
	else
		p_u_277.lit = v280
		local v_u_284 = p_u_277.fill
		if v280 then
			v_u_284.Visible = true
			local v285
			if p_u_277.grow == "down" then
				v285 = UDim2.fromScale(1, 0)
			else
				v285 = UDim2.fromScale(0, 1)
			end
			v_u_284.Size = v285
			task.delay(p279, function()
				-- upvalues: (copy) p_u_277, (ref) v_u_10, (copy) v_u_284
				if p_u_277.lit then
					v_u_10.tween(v_u_284, 0.18, {
						["Size"] = p_u_277.size
					})
				end
			end)
		else
			v_u_284.Visible = false
			v_u_219[p_u_277.paint] = nil
		end
	end
end
local v_u_287 = {
	0.2,
	0.4,
	0.6,
	0.8
}
local v_u_288 = nil
local v_u_289 = nil
local v_u_290 = nil
local v_u_291 = nil
local v_u_292 = nil
local v_u_293 = nil
local v_u_294 = nil
local v_u_295 = nil
local function v_u_313(p296, p297, p298, p299) -- name: makeReveal
	-- upvalues: (copy) v_u_9, (copy) v_u_15, (copy) v_u_31, (ref) v_u_295
	local v300 = Instance.new("TextButton")
	v300.Name = "Reveal"
	v300.Text = ""
	v300.AutoButtonColor = false
	v300.BackgroundColor3 = Color3.fromRGB(8, 8, 14)
	v300.BackgroundTransparency = 0.06
	v300.BorderSizePixel = 0
	v300.AnchorPoint = Vector2.new(0.5, 1)
	v300.Position = UDim2.fromScale(0.5, 1)
	v300.Size = UDim2.fromScale(1, 1 - p298)
	v300.ZIndex = 40
	v300.Visible = false
	v300.ClipsDescendants = true
	v300:SetAttribute("Pad", true)
	v_u_9.noRing(v300)
	local v301 = Instance.new("Frame")
	v301.Name = "Holder"
	v301.BackgroundTransparency = 1
	v301.AnchorPoint = Vector2.new(0.5, 0.5)
	v301.Position = UDim2.fromScale(0.5, 0.5)
	v301.Size = UDim2.fromScale(1, 1)
	v301.ZIndex = 41
	local v302 = Instance.new("UIScale")
	v302.Name = "Pop"
	v302.Parent = v301
	v301.Parent = v300
	local v303
	if p299 and p299:IsA("ImageLabel") then
		v303 = p299:Clone()
		v303.Name = "Rays"
		v303.AnchorPoint = Vector2.new(0.5, 0.5)
		v303.Position = UDim2.fromScale(0.5, 0.4)
		v303.Size = UDim2.fromScale(0.95, 0.95)
		local v304 = Instance.new("UIAspectRatioConstraint")
		v304.AspectRatio = 1
		v304.DominantAxis = Enum.DominantAxis.Height
		v304.Parent = v303
		v303.ZIndex = 41
		v303.ImageTransparency = 0.25
		v303.Parent = v301
	else
		v303 = nil
	end
	local v305 = Instance.new("Frame")
	v305.Name = "Spot"
	v305.BackgroundTransparency = 1
	v305.AnchorPoint = Vector2.new(0.5, 0.5)
	v305.Position = UDim2.fromScale(0.5, 0.42)
	v305.Size = UDim2.fromScale(0.5, 0.5)
	local v306 = Instance.new("UIAspectRatioConstraint")
	v306.AspectRatio = 1
	v306.DominantAxis = Enum.DominantAxis.Height
	v306.Parent = v305
	v305.ZIndex = 42
	v305.Parent = v301
	local v307 = v_u_15.dress(v305, 3)
	local v308 = Instance.new("ViewportFrame")
	v308.Name = "View"
	v308.BackgroundTransparency = 1
	v308.Ambient = Color3.fromRGB(200, 200, 200)
	v308.LightColor = v_u_31
	v308.AnchorPoint = Vector2.new(0.5, 0.5)
	v308.Position = UDim2.fromScale(0.5, 0.4)
	v308.Size = UDim2.fromScale(0.62, 0.62)
	local v309 = Instance.new("UIAspectRatioConstraint")
	v309.AspectRatio = 1
	v309.DominantAxis = Enum.DominantAxis.Height
	v309.Parent = v308
	v308.ZIndex = 43
	v308.Parent = v301
	local v310 = Instance.new("Frame")
	v310.Name = "TierName"
	v310.BackgroundTransparency = 1
	v310.AnchorPoint = Vector2.new(0.5, 0.5)
	v310.Position = UDim2.fromScale(0.5, 0.79)
	v310.Size = UDim2.fromScale(0.8, 0.17)
	v310.ZIndex = 44
	v310.Parent = v301
	local v311 = v_u_31
	local v312 = p296.label:Clone()
	v312.Name = "Info"
	v312.Text = ""
	v312.TextColor3 = v311
	v312.TextScaled = true
	v312.Rotation = 0
	v312.Visible = true
	v312.Parent = v301
	v312.AnchorPoint = Vector2.new(0.5, 0.5)
	v312.Position = UDim2.fromScale(0.5, 0.92)
	v312.Size = UDim2.fromScale(0.8, 0.08)
	v312.ZIndex = 44
	v300.Parent = p297
	v300.Activated:Connect(function()
		-- upvalues: (ref) v_u_295
		v_u_295()
	end)
	return {
		["root"] = v300,
		["pop"] = v302,
		["view"] = v308,
		["sun"] = v303,
		["spot"] = v307,
		["name"] = v310,
		["info"] = v312
	}
end
local function v_u_403() -- name: build
	-- upvalues: (ref) v_u_209, (copy) v_u_29, (copy) v_u_7, (copy) v_u_5, (copy) v_u_9, (ref) v_u_216, (ref) v_u_295, (ref) v_u_210, (ref) v_u_291, (copy) v_u_11, (copy) v_u_30, (copy) v_u_287, (copy) v_u_268, (copy) v_u_276, (copy) v_u_250, (copy) v_u_259, (ref) v_u_212, (copy) v_u_134, (copy) v_u_125, (copy) v_u_16, (ref) v_u_288, (copy) v_u_4, (copy) v_u_25, (copy) v_u_17, (ref) v_u_289, (copy) v_u_42, (copy) v_u_22, (copy) v_u_21, (ref) v_u_290, (copy) v_u_31, (copy) v_u_235, (copy) v_u_10, (copy) v_u_39, (copy) v_u_40, (ref) v_u_294, (copy) v_u_41, (ref) v_u_292, (ref) v_u_293, (copy) v_u_43, (copy) v_u_313, (copy) v_u_228
	if v_u_209 then
		return v_u_209
	end
	local v314 = v_u_29:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
	local v315
	if v314 then
		v315 = v314:WaitForChild("Frames", 10)
	else
		v315 = v314
	end
	if v314 then
		v314 = v314:WaitForChild("Templates", 10)
	end
	local v_u_316
	if v315 then
		v_u_316 = v315:WaitForChild("Pets", 10)
	else
		v_u_316 = v315
	end
	local v317
	if v314 then
		v317 = v314:WaitForChild("PetCard", 10)
	else
		v317 = v314
	end
	if v314 then
		v314 = v314:FindFirstChild("EyeCard")
	end
	if v314 then
		v314 = v314:FindFirstChild("Decor")
	end
	if v314 then
		v314 = v314:FindFirstChild("Sunburst")
	end
	if not (v315 and (v_u_316 and (v_u_316:IsA("Frame") and (v317 and v317:IsA("GuiButton"))))) then
		warn("[FuseMenu] the UI pack\'s pieces are missing: no fuse window")
		return nil
	end
	local v318 = v_u_316:FindFirstChild("Detail")
	if v318 then
		v318 = v318:FindFirstChild("Equip")
	end
	local v319 = v_u_316:FindFirstChild("EquipBest")
	local v320 = v_u_316:FindFirstChild("Grid")
	local v321 = v317:FindFirstChild("Mult")
	if not (v318 and (v318:IsA("GuiButton") and (v319 and (v319:IsA("GuiButton") and (v320 and (v320:IsA("ScrollingFrame") and (v321 and v321:IsA("TextLabel")))))))) then
		warn("[FuseMenu] the Pets menu\'s pieces are missing: no fuse window")
		return nil
	end
	local v_u_322 = Instance.new("Frame")
	v_u_322.Name = "Fuse"
	v_u_322.Visible = false
	v_u_322.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_322.Position = UDim2.fromScale(0.5, 0.5)
	v_u_322.BackgroundColor3 = v_u_316.BackgroundColor3
	v_u_322.BackgroundTransparency = v_u_316.BackgroundTransparency
	v_u_322.BorderSizePixel = 0
	v_u_322.ZIndex = v_u_316.ZIndex
	local v323 = nil
	local v324 = {
		["label"] = v321
	}
	for _, v325 in v_u_316:GetChildren() do
		if v325.Name == "Top" then
			v323 = v325:Clone()
			v323.Parent = v_u_322
		else
			if not (v325:IsA("UIStroke") or (v325:IsA("UICorner") or v325:IsA("UIAspectRatioConstraint"))) then
				continue
			end
			v325:Clone().Parent = v_u_322
		end
	end
	if not (v323 and v323:IsA("GuiObject")) then
		warn("[FuseMenu] the Pets menu has no top bar: no fuse window")
		return nil
	end
	local function v328() -- name: size
		-- upvalues: (copy) v_u_322, (ref) v_u_7, (copy) v_u_316
		local v326 = v_u_322
		local v327
		if v_u_7.touch() then
			v327 = UDim2.fromScale(0.94, 0.86)
		else
			v327 = v_u_316.Size
		end
		v326.Size = v327
	end
	local v329
	if v_u_7.touch() then
		v329 = UDim2.fromScale(0.94, 0.86)
	else
		v329 = v_u_316.Size
	end
	v_u_322.Size = v329
	v_u_5:GetPropertyChangedSignal("PreferredInput"):Connect(v328)
	local v330 = v323.Size.Y.Scale
	local v331 = {}
	local v332 = nil
	for _, v333 in v323:GetChildren() do
		if v333.Name == "Equipped" or (v333.Name == "Space" or (v333.Name == "EquipPlus" or v333.Name == "SpacePlus")) then
			v333:Destroy()
		elseif v333:IsA("TextLabel") then
			v333.Text = "Fuse Machine"
			local v334 = v333.Position.X.Scale - v333.Size.X.Scale * v333.AnchorPoint.X
			v333.AnchorPoint = Vector2.new(0, v333.AnchorPoint.Y)
			v333.Position = UDim2.new(v334, 0, v333.Position.Y.Scale, v333.Position.Y.Offset)
			v333.Size = UDim2.fromScale(0.6, v333.Size.Y.Scale)
			table.insert(v331, v333)
		else
			if v333.Name ~= "Close" or not v333:IsA("GuiButton") then
				continue
			end
			v333:SetAttribute("Ui-Close", nil)
			v332 = v333
		end
	end
	for _, v335 in v323:GetDescendants() do
		if v335.Name ~= "PadHint" then
			continue
		end
		v335:Destroy()
	end
	if not v332 then
		warn("[FuseMenu] the Pets menu\'s top bar has no X: no fuse window")
		return nil
	end
	v_u_9.hint(v332, Enum.KeyCode.ButtonB, 26)
	if v_u_7.touch() then
		v332.Size = UDim2.fromScale(v332.Size.X.Scale * 1.35, v332.Size.Y.Scale * 1.35)
	end
	v332.Activated:Connect(function()
		-- upvalues: (ref) v_u_216, (ref) v_u_295, (ref) v_u_210, (ref) v_u_291, (ref) v_u_11
		if v_u_216 then
			v_u_295()
			return
		elseif v_u_210 == "picker" then
			v_u_291()
		elseif v_u_11.current() == "Fuse" then
			v_u_11.close()
		end
	end)
	local v336 = Instance.new("Frame")
	v336.Name = "Machine"
	v336.BackgroundTransparency = 1
	v336.AnchorPoint = Vector2.new(0.5, 1)
	v336.Position = UDim2.fromScale(0.5, 1)
	v336.Size = UDim2.fromScale(1, 1 - v330)
	v336.ZIndex = 2
	v336.Parent = v_u_322
	local v337 = v_u_322:FindFirstChildOfClass("UIAspectRatioConstraint")
	local v338 = 0.036 / ((not v337 and 1.5 or v337.AspectRatio) / (1 - v330))
	local v339 = {}
	local v340 = {}
	for v_u_341 = 1, v_u_30 do
		local v342 = v_u_287[v_u_341]
		local v343 = v_u_276(v_u_268(v336, v342, 0.359, v338, 0.13799999999999996, 1), "down", 0, 1)
		table.insert(v339, v343)
		local v344, v345 = v_u_250(v317, "Slot" .. v_u_341, v_u_341)
		v344.AnchorPoint = Vector2.new(0.5, 0.5)
		v344.Position = UDim2.fromScale(v342, 0.19)
		v344.Size = UDim2.fromScale(0.28, 0.28)
		local v346 = Instance.new("UIAspectRatioConstraint")
		v346.AspectRatio = 1
		v346.DominantAxis = Enum.DominantAxis.Height
		v346.Parent = v344
		v344.ZIndex = 3
		v344.Parent = v336
		local v347 = v_u_259(v324, v344, v345)
		table.insert(v340, v347)
		v344.Activated:Connect(function()
			-- upvalues: (ref) v_u_212, (ref) v_u_216, (ref) v_u_134, (ref) v_u_125, (copy) v_u_341, (ref) v_u_16, (ref) v_u_288, (ref) v_u_4, (ref) v_u_29, (ref) v_u_25, (ref) v_u_17, (ref) v_u_289, (ref) v_u_42, (ref) v_u_22, (ref) v_u_21, (ref) v_u_290
			if v_u_212 or v_u_216 then
				return
			else
				local v348 = v_u_134()
				if v_u_125[v_u_341] then
					v_u_125[v_u_341] = nil
					v_u_16.play("Close")
					v_u_288()
					return
				else
					local v349 = v_u_4:IsStudio()
					if v349 then
						v349 = v_u_29:GetAttribute("DevFuseFake") == true
					end
					if v349 and true or v_u_25.open(function(p350)
						-- upvalues: (ref) v_u_17
						return v_u_17.number(p350 <= 1 and "BestStage" or "BestStage" .. p350)
					end) then
						if v348 then
							local v351
							if v_u_22.byId[v348] == nil then
								v351 = false
							else
								v351 = not v_u_21.fusable(v348)
							end
							if v351 then
								v_u_16.play("Error")
								v_u_289("Only one copy: upgrade with Robux", v_u_42)
								return
							end
						end
						v_u_290(v_u_341)
					else
						v_u_16.play("Error")
						v_u_289(v_u_25.lockedText(), v_u_42)
					end
				end
			end
		end)
	end
	local v352 = v_u_287[1]
	local v353 = v_u_287[v_u_30]
	local v354 = v353 - v352 + v338
	local v355 = v_u_268(v336, (v352 + v353) / 2, 0.41, v354, 0.036, 2)
	local v356 = v338 / 2 / v354
	local v357 = {}
	for v358 = 1, v_u_30 do
		local v359 = (v_u_287[v358] - v352 + v338 / 2) / v354
		if v359 < 0.5 then
			local v360 = v_u_276(v355, "right", v359 - v356, 0.5 - v359 + v356)
			table.insert(v357, v360)
		else
			local v361 = v_u_276(v355, "left", v359 + v356, v359 - 0.5 + v356)
			table.insert(v357, v361)
		end
	end
	local v362 = v_u_276(v_u_268(v336, 0.5, 0.44999999999999996, v338, 0.07999999999999996, 1), "down", 0, 1)
	local v363, v364 = v_u_250(v317, "Result", 6)
	v363.AnchorPoint = Vector2.new(0.5, 0.5)
	v363.Position = UDim2.fromScale(0.5, 0.6)
	v363.Size = UDim2.fromScale(0.3, 0.3)
	local v365 = Instance.new("UIAspectRatioConstraint")
	v365.AspectRatio = 1
	v365.DominantAxis = Enum.DominantAxis.Height
	v365.Parent = v363
	v363.ZIndex = 3
	v363.Active = false
	v363:SetAttribute("Pad", false)
	v363.Selectable = false
	v363:SetAttribute("Ui-Hover", nil)
	v363:SetAttribute("Ui-Click", nil)
	v363.Parent = v336
	local v366 = v_u_259(v324, v363, v364)
	v366.plus.Visible = false
	v366.mult.Visible = false
	local v367 = v_u_31
	local v368 = v324.label:Clone()
	v368.Name = "Question"
	v368.Text = "?"
	v368.TextColor3 = v367
	v368.TextScaled = true
	v368.Rotation = 0
	v368.Visible = true
	v368.Parent = v363
	v368.AnchorPoint = Vector2.new(0.5, 0.5)
	v368.Position = UDim2.fromScale(0.5, 0.47)
	v368.Size = UDim2.fromScale(0.6, 0.6)
	v368.ZIndex = 8
	local v369 = Instance.new("Frame")
	v369.Name = "ResultTier"
	v369.BackgroundTransparency = 1
	v369.AnchorPoint = Vector2.new(0.5, 0.5)
	v369.Position = UDim2.fromScale(0.5, 0.77)
	v369.Size = UDim2.fromScale(0.3, 0.1)
	v369.ZIndex = 6
	v369.Parent = v336
	local v370 = v_u_235(v319, "AutoFill", "AUTO FILL")
	v370.AnchorPoint = Vector2.new(0.5, 0.5)
	v370.Position = UDim2.fromScale(0.19, 0.6)
	v370.Size = UDim2.fromScale(0.24, 0.15)
	v370.ZIndex = 3
	v_u_10.paint(v370, v_u_39, v_u_40)
	v370.Parent = v336
	v370.Activated:Connect(function()
		-- upvalues: (ref) v_u_294
		v_u_294()
	end)
	local v371 = v_u_31
	local v372 = v324.label:Clone()
	v372.Name = "Change"
	v372.Text = ""
	v372.TextColor3 = v371
	v372.TextScaled = true
	v372.Rotation = 0
	v372.Visible = true
	v372.Parent = v336
	v372.AnchorPoint = Vector2.new(0.5, 0.5)
	v372.Position = UDim2.fromScale(0.8, 0.53)
	v372.Size = UDim2.fromScale(0.3, 0.13)
	v372.RichText = true
	v372.ZIndex = 3
	local v373 = v_u_41
	local v374 = v324.label:Clone()
	v374.Name = "Help"
	v374.Text = ""
	v374.TextColor3 = v373
	v374.TextScaled = true
	v374.Rotation = 0
	v374.Visible = true
	v374.Parent = v336
	v374.AnchorPoint = Vector2.new(0.5, 0.5)
	v374.Position = UDim2.fromScale(0.8, 0.69)
	v374.Size = UDim2.fromScale(0.34, 0.17)
	v374.TextWrapped = true
	v374.ZIndex = 3
	local v375 = v_u_235(v318, "FuseButton", "0/4")
	v375.AnchorPoint = Vector2.new(0.5, 0.5)
	v375.Position = UDim2.fromScale(0.5, 0.915)
	v375.Size = UDim2.fromScale(0.3, 0.125)
	v375.ZIndex = 3
	v375.Parent = v336
	v375.Activated:Connect(function()
		-- upvalues: (ref) v_u_292
		v_u_292()
	end)
	local v376 = v_u_235(v318, "SkipButton", "")
	v376.AnchorPoint = Vector2.new(0.5, 0.5)
	v376.Position = UDim2.fromScale(0.815, 0.915)
	v376.Size = UDim2.fromScale(0.29, 0.125)
	v376.ZIndex = 3
	v376.Visible = false
	v376.Parent = v336
	v376.Activated:Connect(function()
		-- upvalues: (ref) v_u_293
		v_u_293()
	end)
	local v377 = v_u_43
	local v378 = v324.label:Clone()
	v378.Name = "Tag"
	v378.Text = "INSTANT!"
	v378.TextColor3 = v377
	v378.TextScaled = true
	v378.Rotation = 0
	v378.Visible = true
	v378.Parent = v376
	v378.AnchorPoint = Vector2.new(0.5, 0.5)
	v378.Position = UDim2.fromScale(0.86, 0.02)
	v378.Size = UDim2.fromScale(0.46, 0.4)
	v378.Rotation = 10
	v378.ZIndex = 5
	local v379 = Instance.new("Frame")
	v379.Name = "Picker"
	v379.BackgroundTransparency = 1
	v379.AnchorPoint = Vector2.new(0.5, 1)
	v379.Position = UDim2.fromScale(0.5, 1)
	v379.Size = UDim2.fromScale(1, 1 - v330)
	v379.ZIndex = 2
	v379.Visible = false
	v379.Parent = v_u_322
	local v_u_380 = v320:Clone()
	v_u_380.Name = "Grid"
	for _, v381 in v_u_380:GetChildren() do
		if v381:IsA("UIGridLayout") or v381:IsA("UIPadding") then
			continue
		end
		v381:Destroy()
	end
	v_u_380.AnchorPoint = Vector2.new(0.5, 0.5)
	v_u_380.Position = UDim2.fromScale(0.5, 0.5)
	v_u_380.Size = UDim2.fromScale(0.96, 0.94)
	v_u_380.CanvasPosition = Vector2.zero
	v_u_380.Parent = v379
	local v_u_382 = v_u_380:FindFirstChildOfClass("UIGridLayout")
	if v_u_382 then
		v_u_382.SortOrder = Enum.SortOrder.LayoutOrder
		v_u_382.FillDirectionMaxCells = 5
		v_u_380:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(function() -- name: cells
			-- upvalues: (copy) v_u_380, (copy) v_u_382
			local v383 = v_u_380.AbsoluteWindowSize.X
			if v383 > 0 then
				local v384 = v383 * 0.184
				local v385 = math.floor(v384)
				v_u_382.CellSize = UDim2.fromOffset(v385, v385)
				local v386 = v_u_382
				local v387 = UDim2.fromOffset
				local v388 = v383 * 0.016
				local v389 = math.floor(v388)
				local v390 = v383 * 0.016
				v386.CellPadding = v387(v389, (math.floor(v390)))
			end
		end)
		v_u_382:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function() -- name: canvas
			-- upvalues: (copy) v_u_380, (copy) v_u_382
			v_u_380.AutomaticCanvasSize = Enum.AutomaticSize.None
			v_u_380.CanvasSize = UDim2.fromOffset(0, v_u_382.AbsoluteContentSize.Y + 24)
		end)
		local v391 = v_u_380.AbsoluteWindowSize.X
		if v391 > 0 then
			local v392 = v391 * 0.184
			local v393 = math.floor(v392)
			v_u_382.CellSize = UDim2.fromOffset(v393, v393)
			local v394 = UDim2.fromOffset
			local v395 = v391 * 0.016
			local v396 = math.floor(v395)
			local v397 = v391 * 0.016
			v_u_382.CellPadding = v394(v396, (math.floor(v397)))
		end
		v_u_380.AutomaticCanvasSize = Enum.AutomaticSize.None
		v_u_380.CanvasSize = UDim2.fromOffset(0, v_u_382.AbsoluteContentSize.Y + 24)
	end
	local v398 = v_u_31
	local v399 = v324.label:Clone()
	v399.Name = "Empty"
	v399.Text = ""
	v399.TextColor3 = v398
	v399.TextScaled = true
	v399.Rotation = 0
	v399.Visible = true
	v399.Parent = v379
	v399.AnchorPoint = Vector2.new(0.5, 0.5)
	v399.Position = UDim2.fromScale(0.5, 0.45)
	v399.Size = UDim2.fromScale(0.8, 0.14)
	v399.ZIndex = 4
	v399.Visible = false
	local v400 = v_u_313(v324, v_u_322, v330, v314)
	v_u_9.root(v_u_322)
	v_u_322.Parent = v315
	local v401 = {
		["frame"] = v_u_322,
		["titles"] = v331,
		["close"] = v332,
		["machine"] = v336,
		["picker"] = v379,
		["grid"] = v_u_380,
		["empty"] = v399,
		["slots"] = v340,
		["stubs"] = v339,
		["segments"] = v357,
		["centre"] = v362,
		["result"] = v366,
		["resultTag"] = v369,
		["question"] = v368,
		["change"] = v372,
		["help"] = v374,
		["auto"] = v370,
		["fuse"] = v375,
		["skip"] = v376,
		["skipTag"] = v378,
		["reveal"] = v400,
		["card"] = v317,
		["label"] = v321
	}
	v_u_209 = v401
	local v_u_402 = nil
	v_u_322:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) v_u_322, (ref) v_u_402, (ref) v_u_4, (ref) v_u_228, (ref) v_u_216, (ref) v_u_295, (ref) v_u_210, (ref) v_u_291
		if v_u_322.Visible and not v_u_402 then
			v_u_402 = v_u_4.RenderStepped:Connect(v_u_228)
		elseif not v_u_322.Visible then
			if v_u_402 then
				v_u_402:Disconnect()
				v_u_402 = nil
			end
			if v_u_216 then
				v_u_295()
			end
			if v_u_210 ~= "machine" then
				v_u_291()
			end
		end
	end)
	return v401
end
v_u_289 = function(p404, p405, p406)
	-- upvalues: (ref) v_u_218, (ref) v_u_288
	v_u_218 = {
		["text"] = p404,
		["color"] = p405,
		["untilTime"] = os.clock() + (p406 or 3)
	}
	v_u_288()
	task.delay(p406 or 3, function()
		-- upvalues: (ref) v_u_218, (ref) v_u_288
		local v407 = v_u_218
		if v407 and os.clock() >= v407.untilTime then
			v_u_218 = nil
			v_u_288()
		end
	end)
end
local function v_u_423(p408, p409) -- name: drawSlot
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_73, (copy) v_u_56, (copy) v_u_17, (copy) v_u_57, (copy) v_u_238, (copy) v_u_15, (copy) v_u_31, (copy) v_u_25, (copy) v_u_22, (copy) v_u_14, (copy) v_u_13, (copy) v_u_26, (copy) v_u_74, (copy) v_u_58
	local v410 = v_u_4:IsStudio()
	if v410 then
		v410 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v411
	if v410 then
		v_u_73()
		v411 = v_u_56
	else
		v411 = v_u_17.pets()
	end
	local v412 = v_u_4:IsStudio()
	if v412 then
		v412 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v413
	if v412 then
		v413 = v_u_57
	else
		v413 = v_u_17.petTiers()
	end
	local v414
	if p409 then
		v414 = v411[p409]
	else
		v414 = p409
	end
	if p409 and v414 then
		local v415 = v_u_25.tierOf(v413, p409)
		local v416 = v414 .. "|" .. v415
		if p408.shown ~= v416 then
			p408.shown = v416
			v_u_15.paint(p408.tile, v_u_22.byId[v414], v415)
			local v417 = p408.view
			local v418 = v_u_14.build(v414)
			if v418 then
				v_u_13.apply(v418, v415)
				v_u_14.show(v417, v418, false)
			else
				v_u_238(v417)
			end
			v_u_15.tag(p408.card, v415, true)
		end
		p408.plus.Visible = false
		p408.mult.Visible = true
		p408.mult.Text = v_u_26.mult(v_u_25.mult(v414, v415, v_u_74()))
		local v419 = p408.badge
		local v420 = table.find
		local v421 = v_u_4:IsStudio()
		if v421 then
			v421 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		local v422
		if v421 then
			v422 = v_u_58
		else
			v422 = v_u_17.equipped()
		end
		v419.Visible = v420(v422, p409) ~= nil
	else
		if p408.shown == "" then
			if p408.tile.splash.ImageColor3 == v_u_31 then
				v_u_15.empty(p408.tile)
			end
		else
			p408.shown = ""
			v_u_238(p408.view)
			v_u_15.empty(p408.tile)
			v_u_15.tag(p408.card, 0, true)
		end
		p408.plus.Visible = true
		p408.mult.Visible = false
		p408.badge.Visible = false
	end
end
local function v_u_434(p424, p425, p426) -- name: drawResult
	-- upvalues: (copy) v_u_238, (copy) v_u_15, (copy) v_u_244, (copy) v_u_31, (copy) v_u_25, (copy) v_u_14, (copy) v_u_13, (copy) v_u_74, (copy) v_u_26, (copy) v_u_45
	local v427 = p424.result
	if p425 then
		local _, v428 = v_u_25.result(p425, p426)
		local v429 = p425 .. "|" .. v428
		if v427.shown ~= v429 then
			v427.shown = v429
			v_u_15.tier(v427.tile, v428)
			local v430 = v427.view
			local v431 = v_u_14.build(p425)
			if v431 then
				v_u_13.apply(v431, v428)
				v_u_14.show(v430, v431, true)
			else
				v_u_238(v430)
			end
			v_u_244(p424.resultTag, v428)
		end
		p424.question.Visible = false
		p424.change.Visible = true
		local v432 = v_u_25.mult(p425, p426, v_u_74())
		local v433 = v_u_25.mult(p425, v428, v_u_74())
		p424.change.Text = string.format("%s <font color=\"#%s\">\226\134\146 %s</font>", v_u_26.mult(v432), v_u_45:ToHex(), v_u_26.mult(v433))
	else
		if v427.shown == "" then
			if v427.tile.splash.ImageColor3 == v_u_31 then
				v_u_15.empty(v427.tile)
			end
		else
			v427.shown = ""
			v_u_238(v427.view)
			v_u_15.empty(v427.tile)
			v_u_244(p424.resultTag, 0)
		end
		p424.question.Visible = true
		p424.change.Visible = false
	end
end
local function v_u_500(p435) -- name: drawMachine
	-- upvalues: (copy) v_u_134, (copy) v_u_25, (copy) v_u_125, (copy) v_u_423, (copy) v_u_286, (copy) v_u_434, (copy) v_u_4, (copy) v_u_29, (copy) v_u_17, (copy) v_u_30, (copy) v_u_22, (copy) v_u_21, (ref) v_u_212, (ref) v_u_213, (copy) v_u_35, (copy) v_u_36, (copy) v_u_10, (copy) v_u_33, (copy) v_u_34, (copy) v_u_23, (copy) v_u_105, (copy) v_u_18, (copy) v_u_95, (copy) v_u_222, (ref) v_u_215, (copy) v_u_27, (copy) v_u_12, (copy) v_u_219, (ref) v_u_218, (copy) v_u_42, (copy) v_u_41, (copy) v_u_208, (copy) v_u_45
	local v436, v437 = v_u_134()
	local v438
	if v436 then
		local v439
		v439, v438 = v_u_25.result(v436, v437)
	else
		v438 = nil
	end
	local v440 = 0
	for v441, v442 in p435.slots do
		local v443 = v_u_125[v441]
		v_u_423(v442, v443)
		if v443 then
			v440 = v440 + 1
		end
		local v444 = v_u_286
		local v445 = p435.stubs[v441]
		local v446
		if v443 then
			v446 = v438
		else
			v446 = nil
		end
		v444(v445, v446, 0)
		local v447 = v_u_286
		local v448 = p435.segments[v441]
		local v449
		if v443 then
			v449 = v438
		else
			v449 = nil
		end
		v447(v448, v449, 0.12)
	end
	local v450 = v_u_286
	local v451 = p435.centre
	local v452
	if v440 > 0 then
		v452 = v438
	else
		v452 = nil
	end
	v450(v451, v452, 0.24)
	v_u_434(p435, v436, v437)
	local v453 = v_u_4:IsStudio()
	if v453 then
		v453 = v_u_29:GetAttribute("DevFuseFake") == true
	end
	local v454 = v453 and {} or v_u_17.lockedPets()
	local v455 = {}
	for v456 = 1, v_u_30 do
		local v457 = v_u_125[v456]
		if not v457 then
			continue
		end
		table.insert(v455, v457)
	end
	for _, v458 in v455 do
		if not v454[v458] then
			continue
		end
		v459 = true
	end
	local v459 = false
	local v460
	if v436 == nil then
		v460 = false
	else
		local v461
		if v_u_22.byId[v436] == nil then
			v461 = false
		else
			v461 = not v_u_21.fusable(v436)
		end
		v460 = v461 or v459
	end
	p435.fuse.Visible = not v460
	if v_u_212 and not v_u_213 then
		local v462 = p435.fuse
		local v463 = v_u_35
		local v464 = v_u_36
		v_u_10.setText(v462, "FUSING...")
		v_u_10.paint(v462, v463, v464)
	elseif v_u_30 <= v440 then
		local v465 = p435.fuse
		local v466 = v_u_33
		local v467 = v_u_34
		v_u_10.setText(v465, "FUSE!")
		v_u_10.paint(v465, v466, v467)
	else
		local v468 = p435.fuse
		local v469 = ("%*/%*"):format(v440, v_u_30)
		local v470 = v_u_35
		local v471 = v_u_36
		v_u_10.setText(v468, v469)
		v_u_10.paint(v468, v470, v471)
	end
	local v472 = p435.skip:FindFirstChildOfClass("UIGradient")
	local v473
	if v438 then
		local v474 = v_u_25.skipKey(v438)
		if v474 then
			v473 = v_u_23.productByKey[v474]
		else
			v473 = nil
		end
	else
		v473 = nil
	end
	if v436 and (v438 and v440 >= 1) then
		local v475 = v_u_4:IsStudio()
		if v475 then
			v475 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		if (v475 and true or v_u_25.open(function(p476)
			-- upvalues: (ref) v_u_17
			return v_u_17.number(p476 <= 1 and "BestStage" or "BestStage" .. p476)
		end)) and v_u_105(v438) then
			p435.skip.Visible = true
			if v460 then
				local v477 = p435.skip
				v477.AnchorPoint = Vector2.new(0.5, 0.5)
				v477.Position = UDim2.fromScale(0.5, 0.915)
				v477.Size = UDim2.fromScale(0.42, 0.125)
			else
				local v478 = p435.skip
				v478.AnchorPoint = Vector2.new(0.5, 0.5)
				v478.Position = UDim2.fromScale(0.815, 0.915)
				v478.Size = UDim2.fromScale(0.29, 0.125)
			end
			local v479 = not v473 and "" or v_u_18.priceText(v473.price)
			local v480 = v_u_10.setText
			local v481 = p435.skip
			local v482
			if v_u_213 then
				v482 = "WAIT..."
			else
				local v483 = v_u_25.creditId(v438)
				local v484
				if v483 then
					local v485 = v_u_4:IsStudio()
					if v485 then
						v485 = v_u_29:GetAttribute("DevFuseFake") == true
					end
					local v486
					if v485 then
						v486 = v_u_95
					else
						v486 = v_u_17.fuseCredits()
					end
					v484 = v486[v483] or 0
				else
					v484 = 0
				end
				v482 = v484 > 0 and "UPGRADE NOW  FREE" or ("UPGRADE NOW  %*"):format(v479)
			end
			v480(v481, v482)
			p435.skipTag.Visible = not v_u_213
			if v472 then
				v472.Rotation = 90
				v_u_222(v472, v438)
			end
			local v487 = {}
			for v488 = 1, v_u_30 do
				local v489 = v_u_125[v488]
				if not v489 then
					continue
				end
				table.insert(v487, v489)
			end
			local v490 = (v487[1] or "") .. "|" .. v438
			if v490 ~= v_u_215 then
				v_u_215 = v490
				local v491 = v_u_22.byId[v436]
				if v473 and (v473.id ~= 0 and (v_u_27.FROM_CLIENT.FuseSkip and v491)) then
					v_u_12.shown("FuseSkip", "product", v473.key, v491.rarity)
				end
			end
		else
			p435.skip.Visible = false
			v_u_215 = ""
			if v472 then
				v_u_219[v472] = nil
			end
		end
	else
		p435.skip.Visible = false
		v_u_215 = ""
		if v472 then
			v_u_219[v472] = nil
		end
	end
	local v492 = v_u_218
	if v492 and os.clock() < v492.untilTime then
		p435.help.Text = v492.text
		p435.help.TextColor3 = v492.color
	else
		local v493 = v_u_4:IsStudio()
		if v493 then
			v493 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		if v493 and true or v_u_25.open(function(p494)
			-- upvalues: (ref) v_u_17
			return v_u_17.number(p494 <= 1 and "BestStage" or "BestStage" .. p494)
		end) then
			if v436 then
				if v459 then
					p435.help.Text = "Locked pet: unlock it in Pets to fuse it"
					p435.help.TextColor3 = v_u_42
				elseif v460 then
					p435.help.Text = "Only one copy: upgrade with Robux"
					p435.help.TextColor3 = v_u_42
				elseif v_u_208() then
					p435.help.Text = "Equipped pets in the machine will be unequipped."
					p435.help.TextColor3 = v_u_42
				elseif v440 < v_u_30 then
					local v495 = p435.help
					local v496 = "%* more %* to go!"
					local v497 = v_u_30 - v440
					local v498 = v_u_22.byId[v436]
					local v499
					if v498 then
						v499 = v498.name
					else
						v499 = v436
					end
					v495.Text = v496:format(v497, v499)
					p435.help.TextColor3 = v_u_41
				else
					p435.help.Text = "Ready! Press FUSE!"
					p435.help.TextColor3 = v_u_45
				end
			else
				p435.help.Text = ("Put %* of the same pet in to fuse a stronger one!"):format(v_u_30)
				p435.help.TextColor3 = v_u_41
			end
		else
			p435.help.Text = v_u_25.lockedText()
			p435.help.TextColor3 = v_u_42
		end
	end
	p435.help.Position = UDim2.fromScale(0.8, v436 and 0.69 or 0.6)
end
local v_u_501 = {}
local function v_u_543(p502) -- name: drawPicker
	-- upvalues: (copy) v_u_501, (copy) v_u_201, (copy) v_u_134, (copy) v_u_30, (copy) v_u_125, (copy) v_u_22, (copy) v_u_250, (copy) v_u_15, (copy) v_u_26, (copy) v_u_10, (copy) v_u_33, (copy) v_u_37, (copy) v_u_34, (copy) v_u_38, (copy) v_u_14, (copy) v_u_13, (copy) v_u_238, (ref) v_u_212, (ref) v_u_216, (ref) v_u_211, (ref) v_u_291, (copy) v_u_16
	for _, v503 in v_u_501 do
		v503:Destroy()
	end
	table.clear(v_u_501)
	local v504 = v_u_201()
	local v505 = v_u_134()
	local v506 = v_u_30
	local v507 = {}
	for v508 = 1, v_u_30 do
		local v509 = v_u_125[v508]
		if not v509 then
			continue
		end
		table.insert(v507, v509)
	end
	local v510 = v506 - #v507
	if #v504 == 0 then
		p502.empty.Visible = true
		local v511 = p502.empty
		local v512
		if v505 then
			local v513 = "No more %*!"
			local v514 = v_u_22.byId[v505]
			local v515
			if v514 then
				v515 = v514.name
			else
				v515 = v505
			end
			v512 = v513:format(v515)
		else
			v512 = "No pets to fuse yet!\nHatch eggs to get some."
		end
		v511.Text = v512
	else
		p502.empty.Visible = false
	end
	for v516, v_u_517 in v504 do
		local v518, v519 = v_u_250(p502.card, "Pick" .. v516, v516)
		v518.LayoutOrder = v516
		v518.Size = UDim2.fromScale(1, 1)
		v518.Position = UDim2.new()
		v518.AnchorPoint = Vector2.zero
		v_u_15.paint(v519, v_u_517.pet, v_u_517.tier)
		v_u_15.tag(v518, v_u_517.tier, true)
		local v520 = v518:FindFirstChild("Mult")
		if v520 and v520:IsA("TextLabel") then
			v520.Text = v_u_26.mult(v_u_517.mult)
		end
		local v521 = v518:FindFirstChild("On")
		if v521 and v521:IsA("GuiObject") then
			local v522 = #v_u_517.uids > 1 and true or v505 ~= nil
			local v523 = not v522
			if v523 then
				v523 = v_u_517.equipped > 0
			end
			v521.Visible = v523
			local v524 = v521:Clone()
			v524.Name = "Count"
			v524.Visible = v522
			local v525
			if v510 <= #v_u_517.uids then
				v525 = not v_u_517.locked
			else
				v525 = false
			end
			local v526 = v_u_10.paint
			local v527
			if v525 then
				v527 = v_u_33
			else
				v527 = v_u_37
			end
			local v528
			if v525 then
				v528 = v_u_34
			else
				v528 = v_u_38
			end
			v526(v524, v527, v528)
			local v529 = v524:FindFirstChild("Text")
			if v529 and v529:IsA("TextLabel") then
				local v530 = #v_u_517.uids
				v529.Text = tostring(v530)
			end
			v524.Parent = v518
		end
		local v531 = v518:FindFirstChild("View")
		if v531 and v531:IsA("ViewportFrame") then
			local v532 = v_u_517.kind
			local v533 = v_u_517.tier
			local v534 = v_u_14.build(v532)
			if v534 then
				v_u_13.apply(v534, v533)
				v_u_14.show(v531, v534, false)
			else
				v_u_238(v531)
			end
		end
		if v_u_517.locked then
			v_u_15.lock(v518, v_u_517.tier > 0)
		end
		v518.Activated:Connect(function()
			-- upvalues: (ref) v_u_212, (ref) v_u_216, (ref) v_u_30, (ref) v_u_125, (copy) v_u_517, (ref) v_u_211, (ref) v_u_291, (ref) v_u_16
			if v_u_212 or v_u_216 then
				return
			else
				local v535 = {}
				local v536 = nil
				for v537 = 1, v_u_30 do
					local v538 = v_u_125[v537]
					if not v538 then
						continue
					end
					table.insert(v535, v538)
				end
				for _, v539 in v_u_517.uids do
					if table.find(v535, v539) then
						continue
					end
					v536 = v539
				end
				if v536 then
					local v540
					if v_u_125[v_u_211] then
						v540 = nil
					else
						v540 = v_u_211
					end
					if not v540 then
						for v541 = 1, v_u_30 do
							if v_u_125[v541] then
								continue
							end
							v540 = v541
						end
					end
					if v540 then
						v_u_125[v540] = v536
						v_u_16.play("Equip")
						v_u_291()
					else
						v_u_291()
					end
				else
					return
				end
			end
		end)
		v518.Parent = p502.grid
		local v542 = v_u_501
		table.insert(v542, v518)
	end
end
v_u_288 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_212, (copy) v_u_154, (copy) v_u_500
	local v544 = v_u_209
	if v544 then
		if not v_u_212 then
			v_u_154()
		end
		v_u_500(v544)
	end
end
v_u_291 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_210, (ref) v_u_288, (copy) v_u_9, (ref) v_u_211, (copy) v_u_11, (copy) v_u_134, (copy) v_u_22, (copy) v_u_21, (copy) v_u_4, (copy) v_u_29, (copy) v_u_17, (copy) v_u_30, (copy) v_u_125
	local v_u_545 = v_u_209
	if v_u_545 then
		v_u_210 = "machine"
		v_u_545.picker.Visible = false
		v_u_545.machine.Visible = true
		for _, v546 in v_u_545.titles do
			v546.Text = "Fuse Machine"
		end
		v_u_288()
		if v_u_9.active() then
			local v_u_547 = v_u_211
			v_u_9.selectSoon(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_210, (ref) v_u_134, (ref) v_u_22, (ref) v_u_21, (ref) v_u_4, (ref) v_u_29, (ref) v_u_17, (ref) v_u_30, (ref) v_u_125, (copy) v_u_545, (ref) v_u_209, (copy) v_u_547
				if v_u_11.current() ~= "Fuse" or v_u_210 ~= "machine" then
					return nil
				end
				local v548 = v_u_134()
				local v549, v550, v551
				if v548 then
					local v552
					if v_u_22.byId[v548] == nil then
						v552 = false
					else
						v552 = not v_u_21.fusable(v548)
					end
					if v552 then
						if v_u_545.skip.Visible then
							return v_u_545.skip
						end
					else
						local v553 = v_u_4:IsStudio()
						if v553 then
							v553 = v_u_29:GetAttribute("DevFuseFake") == true
						end
						local v554 = v553 and {} or v_u_17.lockedPets()
						local v555 = {}
						for v556 = 1, v_u_30 do
							local v557 = v_u_125[v556]
							if not v557 then
								continue
							end
							table.insert(v555, v557)
						end
						for _, v558 in v555 do
							if not v554[v558] then
								continue
							end
							v559 = true
						end
						local v559 = false
						if not v559 then
							for v562 = 1, v_u_30 do
								if v_u_125[v562] then
									continue
								end
								v549 = v_u_209
								if v549 and v549.slots[v562] then
									return v549.slots[v562].card
								else
									return nil
								end
							end
							if v_u_125[v_u_547] then
								return v_u_545.fuse
							else
								v550 = v_u_547
								v551 = v_u_209
								if v551 and v551.slots[v550] then
									return v551.slots[v550].card
								else
									return nil
								end
							end
						end
						if v_u_545.skip.Visible then
							return v_u_545.skip
						end
					end
					for v562 = 1, v_u_30 do
						if v_u_125[v562] then
							continue
						end
						v549 = v_u_209
						if v549 and v549.slots[v562] then
							return v549.slots[v562].card
						else
							return nil
						end
					end
					if v_u_125[v_u_547] then
						return v_u_545.fuse
					else
						v550 = v_u_547
						v551 = v_u_209
						if v551 and v551.slots[v550] then
							return v551.slots[v550].card
						else
							return nil
						end
					end
				else
					for v562 = 1, v_u_30 do
						if v_u_125[v562] then
							continue
						end
						v549 = v_u_209
						if v549 and v549.slots[v562] then
							return v549.slots[v562].card
						else
							return nil
						end
					end
					if v_u_125[v_u_547] then
						return v_u_545.fuse
					else
						v550 = v_u_547
						v551 = v_u_209
						if v551 and v551.slots[v550] then
							return v551.slots[v550].card
						else
							return nil
						end
					end
				end
			end)
		end
	end
end
v_u_290 = function(p563)
	-- upvalues: (ref) v_u_209, (ref) v_u_211, (ref) v_u_210, (copy) v_u_543, (copy) v_u_9, (copy) v_u_11, (copy) v_u_501
	local v_u_564 = v_u_209
	if v_u_564 then
		v_u_211 = p563
		v_u_210 = "picker"
		for _, v565 in v_u_564.titles do
			v565.Text = "Select a Pet"
		end
		v_u_564.machine.Visible = false
		v_u_564.picker.Visible = true
		v_u_564.grid.CanvasPosition = Vector2.zero
		v_u_543(v_u_564)
		if v_u_9.active() then
			v_u_9.selectSoon(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_210, (ref) v_u_501, (copy) v_u_564
				if v_u_11.current() == "Fuse" and v_u_210 == "picker" then
					return v_u_501[1] or v_u_564.close
				else
					return nil
				end
			end)
		end
	end
end
v_u_294 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_212, (ref) v_u_216, (copy) v_u_4, (copy) v_u_29, (copy) v_u_25, (copy) v_u_17, (copy) v_u_16, (ref) v_u_289, (copy) v_u_42, (copy) v_u_57, (copy) v_u_58, (copy) v_u_134, (copy) v_u_22, (copy) v_u_21, (copy) v_u_30, (copy) v_u_125, (copy) v_u_73, (copy) v_u_56, (copy) v_u_74, (copy) v_u_44, (ref) v_u_288, (copy) v_u_9
	local v566 = v_u_209
	if v566 and not (v_u_212 or v_u_216) then
		local v567 = v_u_4:IsStudio()
		if v567 then
			v567 = v_u_29:GetAttribute("DevFuseFake") == true
		end
		if v567 and true or v_u_25.open(function(p568)
			-- upvalues: (ref) v_u_17
			return v_u_17.number(p568 <= 1 and "BestStage" or "BestStage" .. p568)
		end) then
			local v569 = v_u_4:IsStudio()
			if v569 then
				v569 = v_u_29:GetAttribute("DevFuseFake") == true
			end
			local v570
			if v569 then
				v570 = v_u_57
			else
				v570 = v_u_17.petTiers()
			end
			local v571 = v_u_4:IsStudio()
			if v571 then
				v571 = v_u_29:GetAttribute("DevFuseFake") == true
			end
			local v_u_572
			if v571 then
				v_u_572 = v_u_58
			else
				v_u_572 = v_u_17.equipped()
			end
			local v573, v574 = v_u_134()
			if v573 then
				local v575
				if v_u_22.byId[v573] == nil then
					v575 = false
				else
					v575 = not v_u_21.fusable(v573)
				end
				if v575 then
					v_u_16.play("Error")
					v_u_289("Only one copy: upgrade with Robux", v_u_42)
					return
				end
			end
			local v576 = v_u_4:IsStudio()
			if v576 then
				v576 = v_u_29:GetAttribute("DevFuseFake") == true
			end
			local v577 = v576 and {} or v_u_17.lockedPets()
			local v578 = {}
			for v579 = 1, v_u_30 do
				local v580 = v_u_125[v579]
				if not v580 then
					continue
				end
				table.insert(v578, v580)
			end
			for _, v581 in v578 do
				if not v577[v581] then
					continue
				end
				v582 = true
			end
			local v582 = false
			if v582 then
				v_u_16.play("Error")
				v_u_289("Locked pet: unlock it in Pets to fuse it", v_u_42)
				return
			else
				local v583 = v_u_4:IsStudio()
				if v583 then
					v583 = v_u_29:GetAttribute("DevFuseFake") == true
				end
				local v584 = v583 and {} or v_u_17.lockedPets()
				local v585 = {}
				local v586 = v_u_4:IsStudio()
				if v586 then
					v586 = v_u_29:GetAttribute("DevFuseFake") == true
				end
				local v587, v588, v589
				if v586 then
					v_u_73()
					v587 = v_u_56
					v588 = nil
					v589 = nil
				else
					v587, v588, v589 = v_u_17.pets()
				end
				for v590, v591 in v587, v588, v589 do
					if v584[v590] then
						continue
					end
					v585[v590] = v591
				end
				local v592, v593
				if v573 then
					local v594 = v_u_25.matches
					v592 = v573
					local v595 = {}
					for v596 = 1, v_u_30 do
						local v597 = v_u_125[v596]
						if not v597 then
							continue
						end
						table.insert(v595, v597)
					end
					v593 = v594(v585, v570, v573, v574, v595)
					table.sort(v593, function(p598, p599)
						-- upvalues: (copy) v_u_572
						local v600 = table.find(v_u_572, p598) ~= nil
						local v601 = table.find(v_u_572, p599) ~= nil
						if v600 == v601 then
							return (tonumber(p598) or 0) < (tonumber(p599) or 0)
						else
							return v601
						end
					end)
				else
					local v602 = v_u_25.groups(v585, v570, v_u_572, v_u_74())
					if #v602 == 0 then
						v_u_16.play("Error")
						v_u_289(("You need %* of the same pet to fuse!"):format(v_u_30), v_u_44)
						return
					end
					v593 = v602[1].uids
					v592 = v573
				end
				local v603 = 0
				for v604 = 1, v_u_30 do
					if v_u_125[v604] or not v593[1] then
						continue
					end
					v_u_125[v604] = table.remove(v593, 1)
					v603 = v603 + 1
				end
				if v603 == 0 then
					if v592 then
						local v605 = {}
						for v606 = 1, v_u_30 do
							local v607 = v_u_125[v606]
							if not v607 then
								continue
							end
							table.insert(v605, v607)
						end
						if #v605 < v_u_30 then
							v_u_16.play("Error")
							local v608 = v_u_289
							local v609 = "No more %*!"
							local v610 = v_u_22.byId[v592]
							if v610 then
								v592 = v610.name
							end
							v608(v609:format(v592), v_u_44)
						end
					end
				else
					v_u_16.play("Equip")
					v_u_288()
					if v_u_9.active() then
						local v611 = {}
						for v612 = 1, v_u_30 do
							local v613 = v_u_125[v612]
							if not v613 then
								continue
							end
							table.insert(v611, v613)
						end
						if v_u_30 <= #v611 then
							v_u_9.select(v566.fuse)
						end
					end
				end
			end
		else
			v_u_16.play("Error")
			v_u_289(v_u_25.lockedText(), v_u_42)
			return
		end
	else
		return
	end
end
v_u_295 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_216, (ref) v_u_217, (copy) v_u_238, (copy) v_u_244, (ref) v_u_288, (copy) v_u_9, (copy) v_u_11, (ref) v_u_210
	local v614 = v_u_209
	if v614 and v_u_216 then
		v_u_216 = false
		v_u_217 = v_u_217 + 1
		v614.reveal.root.Visible = false
		v_u_238(v614.reveal.view)
		v_u_244(v614.reveal.name, 0)
		v_u_288()
		if v_u_9.active() and v_u_11.current() == "Fuse" then
			v_u_9.selectSoon(function()
				-- upvalues: (ref) v_u_11, (ref) v_u_210, (ref) v_u_209
				if v_u_11.current() == "Fuse" and v_u_210 == "machine" then
					local v615 = v_u_209
					if v615 and v615.slots[1] then
						return v615.slots[1].card
					else
						return nil
					end
				else
					return nil
				end
			end)
		end
	end
end
local function v_u_632(p616, p617) -- name: reveal
	-- upvalues: (ref) v_u_216, (ref) v_u_217, (copy) v_u_55, (copy) v_u_15, (copy) v_u_14, (copy) v_u_13, (copy) v_u_238, (copy) v_u_244, (copy) v_u_22, (copy) v_u_26, (copy) v_u_25, (copy) v_u_74, (copy) v_u_10, (copy) v_u_31, (copy) v_u_16, (copy) v_u_9, (ref) v_u_295
	local v_u_618 = p616.reveal
	v_u_216 = true
	v_u_217 = v_u_217 + 1
	local v_u_619 = v_u_217
	local v620 = v_u_55(p617.tier)
	v_u_618.root.Visible = true
	v_u_15.tier(v_u_618.spot, p617.tier)
	local v621 = v_u_618.view
	local v622 = p617.kind
	local v623 = p617.tier
	local v624 = v_u_14.build(v622)
	if v624 then
		v_u_13.apply(v624, v623)
		v_u_14.show(v621, v624, true)
	else
		v_u_238(v621)
	end
	v_u_244(v_u_618.name, p617.tier)
	local v625 = v_u_618.info
	local v626 = "%*  %* Chakra"
	local v627 = p617.kind
	local v628 = v_u_22.byId[v627]
	if v628 then
		v627 = v628.name
	end
	v625.Text = v626:format(v627, (v_u_26.mult(v_u_25.mult(p617.kind, p617.tier, v_u_74()))))
	local v_u_629 = v_u_618.sun
	if v_u_629 then
		v_u_629.ImageColor3 = v620.main
		if v620.rainbow then
			task.spawn(function()
				-- upvalues: (ref) v_u_216, (copy) v_u_619, (ref) v_u_217, (copy) v_u_629
				while v_u_216 and (v_u_619 == v_u_217 and v_u_629.Parent) do
					v_u_629.ImageColor3 = Color3.fromHSV(os.clock() * 0.35 % 1, 0.7, 1)
					task.wait()
				end
			end)
		end
	end
	v_u_618.pop.Scale = 0.3
	v_u_10.tween(v_u_618.pop, 0.45, {
		["Scale"] = 1
	}, Enum.EasingStyle.Back)
	local v_u_630 = v_u_618.root.AbsoluteSize.Y * 0.32
	local v_u_631 = UDim2.fromScale(0.5, 0.4)
	v_u_10.burst(v_u_618.root, v_u_631, v_u_630, v620.main)
	v_u_10.sparks(v_u_618.root, v_u_631, v_u_630 * 0.35, v620.main, 16)
	task.delay(0.15, function()
		-- upvalues: (ref) v_u_216, (copy) v_u_619, (ref) v_u_217, (ref) v_u_10, (copy) v_u_618, (copy) v_u_631, (copy) v_u_630, (ref) v_u_31
		if v_u_216 and v_u_619 == v_u_217 then
			v_u_10.burst(v_u_618.root, v_u_631, v_u_630 * 1.3, v_u_31)
		end
	end)
	v_u_16.play(p617.tier >= 2 and "RevealBig" or "Reveal")
	if v_u_9.active() then
		v_u_9.select(v_u_618.root)
	end
	task.delay(2.6, function()
		-- upvalues: (ref) v_u_216, (copy) v_u_619, (ref) v_u_217, (ref) v_u_295
		if v_u_216 and v_u_619 == v_u_217 then
			v_u_295()
		end
	end)
end
v_u_292 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_212, (ref) v_u_216, (copy) v_u_30, (copy) v_u_125, (copy) v_u_16, (copy) v_u_134, (ref) v_u_289, (copy) v_u_22, (copy) v_u_44, (ref) v_u_218, (ref) v_u_288, (copy) v_u_10, (copy) v_u_94, (copy) v_u_632
	local v633 = v_u_209
	if v633 and not (v_u_212 or v_u_216) then
		local v634 = {}
		for v635 = 1, v_u_30 do
			local v636 = v_u_125[v635]
			if not v636 then
				continue
			end
			table.insert(v634, v636)
		end
		if #v634 < v_u_30 then
			v_u_16.play("Error")
			local v637 = v_u_134()
			local v638 = v_u_289
			local v639
			if v637 then
				local v640 = "Put in %* more %* first!"
				local v641 = v_u_30 - #v634
				local v642 = v_u_22.byId[v637]
				if v642 then
					v637 = v642.name
				end
				v639 = v640:format(v641, v637)
			else
				v639 = ("Put %* of the same pet in first!"):format(v_u_30)
			end
			v638(v639, v_u_44)
			return
		else
			v_u_212 = true
			v_u_218 = nil
			v_u_288()
			v_u_16.play("Vortex")
			for _, v643 in v633.slots do
				v_u_10.tween(v643.suck, 0.35, {
					["Scale"] = 0
				}, Enum.EasingStyle.Back, Enum.EasingDirection.In)
			end
			local v644 = os.clock()
			local v645, v646, v647 = v_u_94(v634)
			local v648 = os.clock() - v644
			if v648 < 0.45 then
				task.wait(0.45 - v648)
			end
			v_u_212 = false
			for _, v649 in v633.slots do
				v649.suck.Scale = 1
			end
			if v645 then
				for v650 = 1, v_u_30 do
					v_u_125[v650] = nil
				end
				if v647 then
					v_u_632(v633, v647)
				else
					v_u_16.play("Reveal")
				end
				v_u_288()
			else
				v_u_16.play("Error")
				v_u_289(v646 or "That didn\'t work, try again!", v_u_44, 4)
			end
		end
	else
		return
	end
end
local function v_u_656(p651, p652, p653) -- name: skipped
	-- upvalues: (ref) v_u_212, (ref) v_u_213, (ref) v_u_209, (copy) v_u_30, (copy) v_u_125, (copy) v_u_11, (ref) v_u_288, (copy) v_u_28, (ref) v_u_210, (ref) v_u_291, (copy) v_u_632
	v_u_212 = false
	v_u_213 = false
	local v654 = v_u_209
	if v654 then
		for v655 = 1, v_u_30 do
			v_u_125[v655] = nil
		end
		if v_u_11.current() ~= "Fuse" then
			if v_u_11.current() ~= nil then
				v_u_288()
				return
			end
			v_u_28.open()
		end
		if v_u_210 ~= "machine" then
			v_u_291()
		end
		v_u_632(v654, {
			["uid"] = p651,
			["kind"] = p652,
			["tier"] = p653
		})
		v_u_288()
	end
end
local function v_u_661(p657) -- name: skipLanded
	-- upvalues: (copy) v_u_656, (ref) v_u_212, (ref) v_u_213, (copy) v_u_11, (copy) v_u_28, (copy) v_u_16, (ref) v_u_289, (copy) v_u_21, (copy) v_u_45
	if type(p657) == "table" then
		local v658 = p657.uid
		local v659 = p657.kind
		local v660 = p657.tier
		if p657.how == "bought" and (type(v658) == "string" and (type(v659) == "string" and type(v660) == "number")) then
			v_u_656(v658, v659, v660)
		elseif p657.how == "kept" and type(v660) == "number" then
			v_u_212 = false
			v_u_213 = false
			if v_u_11.current() == nil then
				v_u_28.open()
			end
			v_u_16.play("Reveal")
			v_u_289(("Upgrade to %* saved: use it on any %* pet!"):format(v_u_21.name(v660), (v_u_21.name(v660 - 1))), v_u_45, 6)
		end
	else
		return
	end
end
v_u_293 = function()
	-- upvalues: (ref) v_u_209, (ref) v_u_212, (ref) v_u_216, (copy) v_u_30, (copy) v_u_125, (copy) v_u_134, (copy) v_u_25, (copy) v_u_4, (copy) v_u_29, (copy) v_u_17, (ref) v_u_213, (ref) v_u_218, (ref) v_u_288, (copy) v_u_124, (copy) v_u_16, (ref) v_u_289, (copy) v_u_44, (copy) v_u_656, (ref) v_u_214, (copy) v_u_2, (copy) v_u_18, (copy) v_u_41
	if v_u_209 and not (v_u_212 or v_u_216) then
		local v662 = {}
		for v663 = 1, v_u_30 do
			local v664 = v_u_125[v663]
			if not v664 then
				continue
			end
			table.insert(v662, v664)
		end
		local v665, v666 = v_u_134()
		if #v662 >= 1 and (v665 and v_u_25.canSkip(v665, v666)) then
			local v667 = v_u_4:IsStudio()
			if v667 then
				v667 = v_u_29:GetAttribute("DevFuseFake") == true
			end
			if v667 and true or v_u_25.open(function(p668)
				-- upvalues: (ref) v_u_17
				return v_u_17.number(p668 <= 1 and "BestStage" or "BestStage" .. p668)
			end) then
				v_u_212 = true
				v_u_213 = true
				v_u_218 = nil
				v_u_288()
				local v669, v670, v671 = v_u_124(v662[1])
				if v669 and v671 then
					if v671.credit then
						v_u_656(v671.uid, v671.kind, v671.tier)
						return
					else
						local v_u_672 = v671.productId
						if v_u_672 then
							local v_u_673 = os.clock()
							v_u_214 = v_u_673
							if not v671.studio then
								local v_u_674 = false
								local v_u_675 = false
								local v679 = v_u_2.PromptProductPurchaseFinished:Connect(function(p676, p677, p678)
									-- upvalues: (ref) v_u_29, (copy) v_u_672, (ref) v_u_674, (ref) v_u_675
									if p676 == v_u_29.UserId and p677 == v_u_672 then
										v_u_674 = true
										v_u_675 = p678
									end
								end)
								v_u_18.promptProduct(v_u_672)
								local v680 = v_u_675
								while not v_u_674 and os.clock() - v_u_673 < 180 do
									task.wait(0.2)
								end
								v679:Disconnect()
								if not v680 then
									if v_u_214 == v_u_673 then
										v_u_212 = false
										v_u_213 = false
										v_u_288()
									end
									return
								end
							end
							task.delay(20, function()
								-- upvalues: (ref) v_u_213, (ref) v_u_214, (copy) v_u_673, (ref) v_u_212, (ref) v_u_289, (ref) v_u_41
								if v_u_213 and v_u_214 == v_u_673 then
									v_u_212 = false
									v_u_213 = false
									v_u_289("Thanks! Your pet will upgrade in a moment.", v_u_41, 4)
								end
							end)
							v_u_288()
						else
							v_u_212 = false
							v_u_213 = false
							v_u_288()
						end
					end
				else
					v_u_212 = false
					v_u_213 = false
					v_u_16.play("Error")
					v_u_289(v670 or "That didn\'t work, try again!", v_u_44, 4)
					return
				end
			end
		end
	end
end
local v_u_681 = false
local function v_u_694() -- name: bind
	-- upvalues: (ref) v_u_681, (copy) v_u_29, (ref) v_u_209, (ref) v_u_212, (ref) v_u_288, (ref) v_u_210, (copy) v_u_543, (copy) v_u_8, (copy) v_u_661, (copy) v_u_9, (copy) v_u_11, (ref) v_u_216, (ref) v_u_295, (ref) v_u_291, (copy) v_u_4, (copy) v_u_28, (copy) v_u_30, (copy) v_u_125, (ref) v_u_293, (ref) v_u_292, (ref) v_u_294, (ref) v_u_290
	if not v_u_681 then
		v_u_681 = true
		for _, v682 in {
			"Pets",
			"PetTiers",
			"Equipped",
			"World",
			"BestStage",
			"FuseCredits",
			"LockedPets"
		} do
			v_u_29:GetAttributeChangedSignal(v682):Connect(function()
				-- upvalues: (ref) v_u_209, (ref) v_u_212, (ref) v_u_288, (ref) v_u_210, (ref) v_u_543
				local v683 = v_u_209
				if v683 and (v683.frame.Visible and not v_u_212) then
					v_u_288()
					if v_u_210 == "picker" then
						v_u_543(v683)
					end
				end
			end)
		end
		v_u_8.onNotify("FuseSkip", v_u_661)
		v_u_9.onBack(function()
			-- upvalues: (ref) v_u_11, (ref) v_u_216, (ref) v_u_295, (ref) v_u_210, (ref) v_u_291
			if v_u_11.current() ~= "Fuse" then
				return false
			end
			if v_u_216 then
				v_u_295()
				return true
			end
			if v_u_210 ~= "picker" then
				return false
			end
			v_u_291()
			return true
		end, 20)
		if v_u_4:IsStudio() then
			v_u_29:GetAttributeChangedSignal("DevFuse"):Connect(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_28, (ref) v_u_11
				if v_u_29:GetAttribute("DevFuse") == true then
					v_u_28.open()
				elseif v_u_11.current() == "Fuse" then
					v_u_11.close()
				end
			end)
			v_u_29:GetAttributeChangedSignal("DevFuseFake"):Connect(function()
				-- upvalues: (ref) v_u_30, (ref) v_u_125, (ref) v_u_288
				for v684 = 1, v_u_30 do
					v_u_125[v684] = nil
				end
				v_u_288()
			end)
			v_u_29:GetAttributeChangedSignal("DevFusePick"):Connect(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_30, (ref) v_u_125, (ref) v_u_291
				local v685 = v_u_29:GetAttribute("DevFusePick")
				if type(v685) == "string" and v685 ~= "" then
					local v686 = table.find
					local v687 = {}
					for v688 = 1, v_u_30 do
						local v689 = v_u_125[v688]
						if not v689 then
							continue
						end
						table.insert(v687, v689)
					end
					if not v686(v687, v685) then
						for v690 = 1, v_u_30 do
							if v_u_125[v690] then
								continue
							end
							v_u_125[v690] = v685
						end
						v_u_291()
						return
					end
				end
			end)
			v_u_29:GetAttributeChangedSignal("DevFusePress"):Connect(function()
				-- upvalues: (ref) v_u_29, (ref) v_u_293, (ref) v_u_292, (ref) v_u_294, (ref) v_u_30, (ref) v_u_125, (ref) v_u_288, (ref) v_u_290
				local v691 = v_u_29:GetAttribute("DevFusePress")
				if v691 == "skip" then
					task.spawn(v_u_293)
					return
				elseif v691 == "fuse" then
					task.spawn(v_u_292)
					return
				elseif v691 == "auto" then
					v_u_294()
					return
				elseif v691 == "clear" then
					for v692 = 1, v_u_30 do
						v_u_125[v692] = nil
					end
					v_u_288()
				elseif v691 == "picker" then
					for v693 = 1, v_u_30 do
						if v_u_125[v693] then
							continue
						end
						v_u_290(v693)
						return
					end
				end
			end)
		end
	end
end
function v_u_28.open() -- name: open
	-- upvalues: (copy) v_u_24, (copy) v_u_21, (copy) v_u_694, (copy) v_u_403, (copy) v_u_11, (ref) v_u_210, (ref) v_u_218, (ref) v_u_288
	if v_u_24.on(v_u_21.UPDATE) then
		v_u_694()
		local v695 = v_u_403()
		if v695 then
			if v_u_11.current() ~= "Fuse" then
				v_u_210 = "machine"
				v695.picker.Visible = false
				v695.machine.Visible = true
				for _, v696 in v695.titles do
					v696.Text = "Fuse Machine"
				end
				v_u_218 = nil
				v_u_288()
				v_u_11.open("Fuse")
			end
		else
			return
		end
	else
		return
	end
end
function v_u_28.isOpen() -- name: isOpen
	-- upvalues: (copy) v_u_11
	return v_u_11.current() == "Fuse"
end
function v_u_28.start() -- name: start
	-- upvalues: (copy) v_u_24, (copy) v_u_21, (copy) v_u_694, (copy) v_u_4, (copy) v_u_6
	if v_u_24.on(v_u_21.UPDATE) then
		v_u_694()
		return
	elseif v_u_4:IsStudio() then
		local v_u_697 = nil
		v_u_697 = v_u_6:GetAttributeChangedSignal("DevUpdate3"):Connect(function()
			-- upvalues: (ref) v_u_24, (ref) v_u_21, (ref) v_u_697, (ref) v_u_694
			if v_u_24.on(v_u_21.UPDATE) then
				v_u_697:Disconnect()
				v_u_694()
			end
		end)
	end
end
return v_u_28