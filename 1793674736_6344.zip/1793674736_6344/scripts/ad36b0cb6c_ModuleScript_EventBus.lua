local v_u_1 = {}
v_u_1.__index = v_u_1
function v_u_1.new() -- name: new
	-- upvalues: (copy) v_u_1
	local v2 = v_u_1
	local v3 = setmetatable({}, v2)
	v3._events = {}
	return v3
end
function v_u_1._getOrCreate(p4, p5) -- name: _getOrCreate
	if not p4._events[p5] then
		local v6 = Instance.new("BindableEvent")
		v6.Name = p5
		p4._events[p5] = v6
	end
	return p4._events[p5]
end
function v_u_1.publish(p7, p8, ...) -- name: publish
	p7:_getOrCreate(p8):Fire(...)
end
function v_u_1.subscribe(p9, p10) -- name: subscribe
	return p9:_getOrCreate(p10).Event
end
return v_u_1