local v1 = game:GetService("ReplicatedStorage")
require(v1.Shared.Config.Abilities)
return {}