local v_u_5 = {
	["KEEP"] = 50,
	["seen"] = function(p1, p2) -- name: seen
		return table.find(p1, p2) ~= nil
	end,
	["remember"] = function(p3, p4) -- name: remember
		-- upvalues: (copy) v_u_5
		if not v_u_5.seen(p3, p4) then
			table.insert(p3, p4)
			while #p3 > v_u_5.KEEP do
				table.remove(p3, 1)
			end
		end
	end
}
return v_u_5