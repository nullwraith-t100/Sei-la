local v_u_34 = {
	["view"] = function(p1, p2, p3, p4, p5) -- name: view
		if p5 <= p1 then
			return p2 == p4 and {
				["week"] = nil,
				["claimed"] = nil,
				["next"] = nil,
				["week"] = p3,
				["claimed"] = p5
			} or {
				["week"] = nil,
				["claimed"] = 0,
				["next"] = 1,
				["week"] = p3 + 1
			}
		end
		local v6 = math.max(p1, 0)
		local v7 = {
			["week"] = p3,
			["claimed"] = v6
		}
		local v8
		if p2 == p4 then
			v8 = nil
		else
			v8 = v6 + 1
		end
		v7.next = v8
		return v7
	end,
	["claim"] = function(p9, p10, p11, p12, p13, p14) -- name: claim
		-- upvalues: (copy) v_u_34
		local v15 = v_u_34.view(p9, p10, p11, p12, p13)
		local v16 = v15.next
		if v16 then
			return v16, v16, v15.week
		end
		if not p14 then
			return nil, p9, p11
		end
		if p13 <= v15.claimed then
			return 1, 1, p11 + 1
		end
		local v17 = v15.claimed + 1
		return v17, v17, v15.week
	end,
	["unlockAll"] = function(p18, p19, p20, p21, p22) -- name: unlockAll
		-- upvalues: (copy) v_u_34
		local v23 = v_u_34.view(p18, p19, p20, p21, p22)
		local v24 = {}
		if p22 <= v23.claimed then
			for v25 = 1, p22 do
				table.insert(v24, v25)
			end
			return v24, p20 + 1
		else
			for v26 = v23.claimed + 1, p22 do
				table.insert(v24, v26)
			end
			return v24, v23.week
		end
	end,
	["left"] = function(p27, p28, p29, p30, p31) -- name: left
		-- upvalues: (copy) v_u_34
		return p31 - v_u_34.view(p27, p28, p29, p30, p31).claimed
	end,
	["set"] = function(p32, p33) -- name: set
		return math.max(0, p32) % p33 + 1
	end
}
return v_u_34