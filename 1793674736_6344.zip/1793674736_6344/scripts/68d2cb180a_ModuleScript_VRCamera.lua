local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("VRService")
require(script.Parent:WaitForChild("CameraInput"))
require(script.Parent:WaitForChild("CameraUtils"))
local v_u_3 = require(script.Parent:WaitForChild("VRCameraTeleportDetector"))
local v4 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_5 = v4.getUserFlag("UserPSVRCameraInputMoveVector")
local v_u_6 = v4.getUserFlag("UserVRRecenterOnExternalTeleport")
local v_u_7 = v4.getUserFlag("UserVRSkipOcclusionInFirstPerson")
local v_u_8 = v4.getUserFlag("UserFixVRImmersionAutoRotate")
local v_u_9 = require(script.Parent:WaitForChild("VRBaseCamera"))
local v_u_10 = setmetatable({}, v_u_9)
v_u_10.__index = v_u_10
function v_u_10.new() -- name: new
	-- upvalues: (copy) v_u_9, (copy) v_u_10
	local v11 = v_u_9.new()
	local v12 = v_u_10
	local v13 = setmetatable(v11, v12)
	v13.lastUpdate = tick()
	v13.focusOffset = CFrame.new()
	v13:Reset()
	v13.controlModule = require(script.Parent.Parent:WaitForChild("ControlModule"))
	v13.savedAutoRotate = true
	v13.autoRotateOverridden = false
	return v13
end
function v_u_10.Reset(p14) -- name: Reset
	-- upvalues: (copy) v_u_9
	p14.needsReset = true
	p14.needsBlackout = true
	p14.motionDetTime = 0
	p14.blackOutTimer = 0
	p14.lastCameraResetPosition = nil
	v_u_9.Reset(p14)
end
function v_u_10.Update(p15, p16) -- name: Update
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_2
	local v17 = workspace.CurrentCamera
	local v18 = v17.CFrame
	local v19 = v17.Focus
	local v20 = v_u_1.LocalPlayer
	if p15.lastUpdate == nil or p16 > 1 then
		p15.lastCameraTransform = nil
	end
	p15:UpdateFadeFromBlack(p16)
	local v21 = p15.lastSubjectPosition
	local v22 = p15:GetSubjectPosition()
	if p15.needsBlackout then
		p15:StartFadeFromBlack()
		local v23 = math.clamp(p16, 0.0001, 0.1)
		p15.blackOutTimer = p15.blackOutTimer + v23
		if p15.blackOutTimer > 0.1 and game:IsLoaded() then
			p15.needsBlackout = false
			p15.needsReset = true
		end
	end
	if v22 and (v20 and v17) then
		local v24 = p15:GetVRFocus(v22, p16)
		if v_u_7 then
			local v25 = p15:IsInFirstPerson()
			if v25 then
				v25 = v20.DevCameraOcclusionMode ~= Enum.DevCameraOcclusionMode.Invisicam
			end
			p15.skipOcclusion = v25
		end
		if p15:IsInFirstPerson() then
			if v_u_2.AvatarGestures then
				v18, v19 = p15:UpdateImmersionCamera(p16, v18, v24, v21, v22)
			else
				v18, v19 = p15:UpdateFirstPersonTransform(p16, v18, v24, v21, v22)
			end
		elseif v_u_2.ThirdPersonFollowCamEnabled then
			v18, v19 = p15:UpdateThirdPersonFollowTransform(p16, v18, v24, v21, v22)
		else
			v18, v19 = p15:UpdateThirdPersonComfortTransform(p16, v18, v24, v21, v22)
		end
		p15.lastCameraTransform = v18
		p15.lastCameraFocus = v19
	end
	p15.lastUpdate = tick()
	return v18, v19
end
function v_u_10.GetAvatarFeetWorldYValue(_) -- name: GetAvatarFeetWorldYValue
	local v26 = workspace.CurrentCamera.CameraSubject
	if not v26 then
		return nil
	end
	if not (v26:IsA("Humanoid") and v26.RootPart) then
		return nil
	end
	local v27 = v26.RootPart
	return v27.Position.Y - v27.Size.Y / 2 - v26.HipHeight
end
function v_u_10.UpdateFirstPersonTransform(p28, p29, _, p30, _, _) -- name: UpdateFirstPersonTransform
	if p28.needsReset then
		p28:StartFadeFromBlack()
		p28.needsReset = false
	end
	local v31 = p30.Position
	local v32 = p28:GetCameraLookVector()
	local v33 = v32.X
	local v34 = v32.Z
	local v35 = Vector3.new(v33, 0, v34).Unit
	local v36 = p28:getRotation(p29)
	local v37 = p28:CalculateNewLookVectorFromArg(v35, Vector2.new(v36, 0))
	return CFrame.new(v31 - 0.5 * v37, v31), p30
end
function v_u_10.UpdateImmersionCamera(p38, p39, _, _, p40, p41) -- name: UpdateImmersionCamera
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_8, (copy) v_u_2, (copy) v_u_3
	local v42 = p38:GetSubjectCFrame()
	local v43 = workspace.CurrentCamera
	local v44 = v_u_1.LocalPlayer.Character
	local v45 = p38:GetHumanoid()
	if not v45 then
		return v43.CFrame, v43.Focus
	end
	local v46 = v44:FindFirstChild("HumanoidRootPart")
	if not v46 then
		return v43.CFrame, v43.Focus
	end
	local v47
	if v_u_6 then
		if p40 then
			local v48 = p41.X - p40.X
			local v49 = p41.Z - p40.Z
			v47 = Vector3.new(v48, 0, v49).Magnitude
		else
			v47 = 0
		end
	else
		v47 = nil
	end
	p38.characterOrientation = v46:FindFirstChild("CharacterAlignOrientation")
	if not p38.characterOrientation then
		local v50 = v46:FindFirstChild("RootAttachment")
		if not v50 then
			return
		end
		p38.characterOrientation = Instance.new("AlignOrientation")
		p38.characterOrientation.Name = "CharacterAlignOrientation"
		p38.characterOrientation.Mode = Enum.OrientationAlignmentMode.OneAttachment
		p38.characterOrientation.Attachment0 = v50
		p38.characterOrientation.RigidityEnabled = true
		p38.characterOrientation.Parent = v46
	end
	if p38.characterOrientation.Enabled == false then
		p38.characterOrientation.Enabled = true
	end
	if p38.needsReset then
		p38.needsReset = false
		if v_u_8 then
			p38:updateImmersionAutoRotate()
		else
			p38.savedAutoRotate = v45.AutoRotate
			v45.AutoRotate = false
		end
		if v_u_6 then
			v_u_2:RecenterUserHeadCFrame()
			p38.lastTeleportRecenter = tick()
		end
		p38:StartFadeFromBlack()
	elseif not v45.Sit then
		local v51 = p38.controlModule:GetEstimatedVRTorsoFrame()
		p38.characterOrientation.CFrame = v43.CFrame * v51
		if p38.controlModule.inputMoveVector.Magnitude > 0 then
			p38.motionDetTime = 0.1
		end
		if p38.controlModule.inputMoveVector.Magnitude > 0 or p38.motionDetTime > 0 then
			p38.motionDetTime = p38.motionDetTime - p39
			local v52 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v53 = v52.Rotation + v52.Position * v43.HeadScale
			local v54 = v44.HumanoidRootPart
			local v55 = -0.7 * v54.Size.Y / 2
			local v56 = v43.CFrame * v53 * CFrame.new(0, v55, 0)
			local v57 = v54.CFrame.LookVector
			local v58 = v57.X
			local v59 = v57.Z
			local v60 = p41 - (v56 - Vector3.new(v58, 0, v59).Unit * v54.Size.Y * 0.125).Position + v43.CFrame.Position
			local v61 = v60.X
			local v62 = p41.Y
			local v63 = v60.Z
			local v64 = Vector3.new(v61, v62, v63)
			v42 = v43.CFrame.Rotation + v64
		elseif v_u_6 and v_u_3.shouldRecenter(p38.prevSubjStep, v47, p38.lastTeleportRecenter, tick()) then
			local v65 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v66 = v65.Rotation + v65.Position * v43.HeadScale
			local v67 = v44.HumanoidRootPart
			local v68 = -0.7 * v67.Size.Y / 2
			local v69 = v43.CFrame * v66 * CFrame.new(0, v68, 0)
			local v70 = v67.CFrame.LookVector
			local v71 = v70.X
			local v72 = v70.Z
			local v73 = p41 - (v69 - Vector3.new(v71, 0, v72).Unit * v67.Size.Y * 0.125).Position + v43.CFrame.Position
			local v74 = v73.X
			local v75 = p41.Y
			local v76 = v73.Z
			local v77 = Vector3.new(v74, v75, v76)
			v42 = v43.CFrame.Rotation + v77
			v_u_2:RecenterUserHeadCFrame()
			p38:StartFadeFromBlack()
			p38.lastTeleportRecenter = tick()
		else
			local v78 = v43.CFrame.Rotation
			local v79 = v43.CFrame.Position.X
			local v80 = p41.Y
			local v81 = v43.CFrame.Position.Z
			v42 = v78 + Vector3.new(v79, v80, v81)
		end
		local v82 = p38:getRotation(p39)
		if math.abs(v82) > 0 then
			local v83 = v_u_2:GetUserCFrame(Enum.UserCFrame.Head)
			local v84 = v83.Rotation + v83.Position * v43.HeadScale
			local v85 = v42 * v84
			local v86 = CFrame.new(v85.Position)
			local v87 = CFrame.Angles
			local v88 = v82 * 90
			v42 = v86 * v87(0, -math.rad(v88), 0) * v85.Rotation * v84:Inverse()
		end
	end
	if v_u_6 then
		p38.prevSubjStep = v47
	end
	return v42, v42 * CFrame.new(0, 0, -0.5)
end
function v_u_10.UpdateThirdPersonComfortTransform(p89, p90, p91, p92, p93, p94) -- name: UpdateThirdPersonComfortTransform
	-- upvalues: (copy) v_u_5, (copy) v_u_2
	local v95 = p89:GetCameraToSubjectDistance()
	local v96 = v95 < 0.5 and 0.5 or v95
	if p93 ~= nil and p89.lastCameraFocus ~= nil then
		local v97 = p93 - p94
		local v98
		if v_u_5 then
			v98 = p89.controlModule.inputMoveVector
		else
			v98 = p89.controlModule:GetMoveVector()
		end
		local v99 = v97.magnitude > 0.01 and true or v98.magnitude > 0.01
		if v99 then
			p89.motionDetTime = 0.1
		end
		p89.motionDetTime = p89.motionDetTime - p90
		if (p89.motionDetTime > 0 and true or v99) and not p89.needsReset then
			local v100 = p89.lastCameraFocus
			p89.VRCameraFocusFrozen = true
			return p91, v100
		end
		local v101 = p89.lastCameraResetPosition == nil and true or (p94 - p89.lastCameraResetPosition).Magnitude > 1
		local v102 = p89:getRotation(p90)
		if math.abs(v102) > 0 then
			local v103 = p92:ToObjectSpace(p91)
			p91 = p92 * CFrame.Angles(0, -v102, 0) * v103
		end
		if p89.VRCameraFocusFrozen and v101 or p89.needsReset then
			v_u_2:RecenterUserHeadCFrame()
			p89.VRCameraFocusFrozen = false
			p89.needsReset = false
			p89.lastCameraResetPosition = p94
			p89:ResetZoom()
			p89:StartFadeFromBlack()
			local v104 = p89:GetHumanoid()
			local v105 = v104.Torso and v104.Torso.CFrame.lookVector or Vector3.new(1, 0, 0)
			local v106 = v105.X
			local v107 = v105.Z
			local v108 = Vector3.new(v106, 0, v107)
			local v109 = p92.Position - v108 * v96
			local v110 = p92.Position.X
			local v111 = v109.Y
			local v112 = p92.Position.Z
			local v113 = Vector3.new(v110, v111, v112)
			p91 = CFrame.new(v109, v113)
		end
	end
	return p91, p92
end
function v_u_10.UpdateThirdPersonFollowTransform(p114, p115, _, _, p116, p117) -- name: UpdateThirdPersonFollowTransform
	-- upvalues: (copy) v_u_2, (copy) v_u_5
	local v118 = workspace.CurrentCamera
	local v119 = p114:GetCameraToSubjectDistance()
	local v120 = p114:GetVRFocus(p117, p115)
	if p114.needsReset then
		p114.needsReset = false
		v_u_2:RecenterUserHeadCFrame()
		p114:ResetZoom()
		p114:StartFadeFromBlack()
	end
	if p114.recentered then
		local v121 = p114:GetSubjectCFrame()
		if not v121 then
			return v118.CFrame, v118.Focus
		end
		local v122 = v120 * v121.Rotation * CFrame.new(0, 0, v119)
		p114.focusOffset = v120:ToObjectSpace(v122)
		p114.recentered = false
		return v122, v120
	end
	local v123 = v120:ToWorldSpace(p114.focusOffset)
	local v124 = p116 - p117
	local v125 = p114.controlModule
	local v126
	if v_u_5 then
		v126 = v125.inputMoveVector
	else
		v126 = v125:GetMoveVector()
	end
	if v124.magnitude > 0.01 or v126.magnitude > 0 then
		local v127 = v125:GetEstimatedVRTorsoFrame()
		local v128 = v127.Rotation + v127.Position * v118.HeadScale
		local v129 = v118.CFrame * v128
		local v130 = v129.LookVector
		local v131 = v130.X
		local v132 = v130.Z
		local v133 = Vector3.new(v131, 0, v132).Unit * v119
		local v134 = v120.Position - v133
		v123 = v123:Lerp(CFrame.new(v118.CFrame.Position + v134 - v129.Position) * v123.Rotation, 0.01)
	end
	local v135 = p114:getRotation(p115)
	if math.abs(v135) > 0 then
		local v136 = v120:ToObjectSpace(v123)
		v123 = v120 * CFrame.Angles(0, -v135, 0) * v136
	end
	p114.focusOffset = v120:ToObjectSpace(v123)
	return v123, v123 * CFrame.new(0, 0, -v119)
end
function v_u_10.updateImmersionAutoRotate(p137) -- name: updateImmersionAutoRotate
	-- upvalues: (copy) v_u_2
	local v138 = p137:GetHumanoid()
	if v138 then
		if p137:IsInFirstPerson() and v_u_2.AvatarGestures then
			if not p137.autoRotateOverridden then
				p137.savedAutoRotate = v138.AutoRotate
				p137.autoRotateOverridden = true
			end
			v138.AutoRotate = false
		elseif p137.autoRotateOverridden then
			v138.AutoRotate = p137.savedAutoRotate
			p137.autoRotateOverridden = false
		end
	else
		return
	end
end
function v_u_10.OnEnabledChanged(p_u_139) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_9, (copy) v_u_8, (copy) v_u_2
	v_u_9.OnEnabledChanged(p_u_139)
	if v_u_8 then
		if p_u_139.enabled then
			if not p_u_139.avatarGesturesChangedConn then
				p_u_139.avatarGesturesChangedConn = v_u_2:GetPropertyChangedSignal("AvatarGestures"):Connect(function()
					-- upvalues: (copy) p_u_139
					p_u_139:updateImmersionAutoRotate()
				end)
				return
			end
		elseif p_u_139.avatarGesturesChangedConn then
			p_u_139.avatarGesturesChangedConn:Disconnect()
			p_u_139.avatarGesturesChangedConn = nil
		end
	end
end
function v_u_10.LeaveFirstPerson(p140) -- name: LeaveFirstPerson
	-- upvalues: (copy) v_u_9, (copy) v_u_8
	v_u_9.LeaveFirstPerson(p140)
	p140.needsReset = true
	if p140.VRBlur then
		p140.VRBlur.Visible = false
	end
	if p140.characterOrientation then
		p140.characterOrientation.Enabled = false
	end
	if v_u_8 then
		p140:updateImmersionAutoRotate()
	else
		local v141 = p140:GetHumanoid()
		if v141 then
			v141.AutoRotate = p140.savedAutoRotate
		end
	end
end
return v_u_10