local v_u_11 = {
	["BY_KEY"] = {
		["starter"] = 6,
		["pro"] = 4,
		["winsPad"] = 6,
		["autoRebirth"] = 6,
		["vip"] = 4,
		["autoWin"] = 4,
		["skipEye"] = 3,
		["chakra1"] = 2,
		["chakra2"] = 2,
		["chakra3"] = 2,
		["equip1"] = 2,
		["equip2"] = 2,
		["storage120"] = 2,
		["skipRebirth"] = 2,
		["boostWins"] = 2,
		["speed2"] = 1,
		["boost2"] = 1,
		["boost5"] = 1,
		["boost10"] = 0.25,
		["bossLuck2"] = 3,
		["bossLuck5"] = 2,
		["luckTier2"] = 5,
		["luckTier4"] = 4,
		["luckTier8"] = 3
	},
	["LATER_WORLDS"] = {
		["vip"] = 5,
		["autoWin"] = 5,
		["boostWins"] = 3
	},
	["RUNG_LOW"] = 6,
	["RUNG_HIGH"] = 3,
	["RUNG_LOW_UP_TO"] = 8,
	["of"] = function(p1, p2) -- name: of
		-- upvalues: (copy) v_u_11
		return (p2 < 2 or not v_u_11.LATER_WORLDS[p1]) and (v_u_11.BY_KEY[p1] or 1) or v_u_11.LATER_WORLDS[p1]
	end,
	["rung"] = function(p3) -- name: rung
		-- upvalues: (copy) v_u_11
		if p3 <= v_u_11.RUNG_LOW_UP_TO then
			return v_u_11.RUNG_LOW
		else
			return v_u_11.RUNG_HIGH
		end
	end,
	["pick"] = function(p4, p5) -- name: pick
		local v6 = 0
		for _, v7 in p4 do
			v6 = v6 + math.max(v7, 0)
		end
		if v6 <= 0 then
			return nil
		end
		local v8 = p5 * v6
		for v9, v10 in p4 do
			v8 = v8 - math.max(v10, 0)
			if v8 >= 0 then
				continue
			end
			return v9
		end
		return #p4
	end
}
return v_u_11