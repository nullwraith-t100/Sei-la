local v_u_1 = game:GetService("ContentProvider")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v4 = game:GetService("RunService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = v4:IsStudio()
local v_u_8 = os.clock()
local v9 = v_u_8
local v10 = {}
if v_u_7 then
	local v_u_11 = {}
	local v_u_12 = os.clock()
	local v_u_13 = 0
	local v_u_14 = v_u_6.DescendantAdded:Connect(function()
		-- upvalues: (ref) v_u_13
		v_u_13 = v_u_13 + 1
	end)
	local v_u_15 = nil
	v_u_15 = v4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_12, (copy) v_u_11, (copy) v_u_8, (ref) v_u_13, (copy) v_u_2, (ref) v_u_15, (copy) v_u_14
		local v16 = os.clock()
		if v16 - v_u_12 > 0.05 then
			local v17 = v_u_11
			local v18 = string.format
			local v19 = v_u_12 - v_u_8
			local v20 = (v16 - v_u_12) * 1000
			local v21 = v_u_13
			local v22 = v_u_2.LocalPlayer.Character and "c" or ""
			table.insert(v17, v18("%.1fs:%.0f+%d%s", v19, v20, v21, v22))
			v_u_2.LocalPlayer:SetAttribute("BootSpikes", table.concat(v_u_11, " "))
		end
		v_u_13 = 0
		v_u_12 = v16
		if v16 - v_u_8 > 40 then
			v_u_15:Disconnect()
			v_u_14:Disconnect()
		end
	end)
end
local v23 = require(v_u_3.Shared.Net)
local v24 = require(script.Parent.Events)
local v25 = require(script.Parent.Look)
local v26
if v_u_7 then
	local v27 = os.clock()
	local v28 = string.format
	local v29 = (v27 - v9) * 1000
	local v30 = v27 - v_u_8
	table.insert(v10, v28("%s %.0fms@%.1fs", "load Look (forms, moves)", v29, v30))
	v9 = v27
	v26 = v9
else
	v26 = v9
end
task.wait()
local v31 = require(script.Parent.Enemies)
if v_u_7 then
	local v32 = os.clock()
	local v33 = string.format
	local v34 = (v32 - v26) * 1000
	local v35 = v32 - v_u_8
	table.insert(v10, v33("%s %.0fms@%.1fs", "load Enemies", v34, v35))
	v9 = v32
	v26 = v9
end
task.wait()
local v36 = require(script.Parent.Gates)
local v37 = require(script.Parent.Input)
local v38 = require(script.Parent.Tutorial)
local v39 = require(script.Parent.AutoClick)
local v40 = require(script.Parent.Menus)
if v_u_7 then
	local v41 = os.clock()
	local v42 = string.format
	local v43 = (v41 - v26) * 1000
	local v44 = v41 - v_u_8
	table.insert(v10, v42("%s %.0fms@%.1fs", "load Gates Input Tutorial AutoClick Menus", v43, v44))
	v9 = v41
	v26 = v9
end
task.wait()
local v_u_45 = require(script.Parent.Hud)
local v46 = require(script.Parent.HubView)
local v47 = require(script.Parent.Companions)
local v48 = require(script.Parent.Music)
local v49 = require(script.Parent.Store)
local v_u_50 = require(script.Parent.Fx.Kit)
local v51 = require(script.Parent.Ui)
local v_u_52 = require(script.Parent.Fx.Abilities)
local v53 = require(script.Parent.Dev)
local v54 = require(script.Parent.State)
local v55 = require(script.Parent.Perf)
local v56 = require(script.Parent.TuneIn)
local v57 = require(script.Parent.Report)
local v58 = require(script.Parent.Revive)
local v59 = require(script.Parent.StoreLook)
local v60 = require(script.Parent.Promo)
local v61 = require(script.Parent.Titles)
local v62 = require(script.Parent.Odds)
local v63 = require(script.Parent.Gamepad)
local v64 = require(script.Parent.TrainingPops)
local v65 = require(script.Parent.Arcade)
if v_u_7 then
	local v66 = os.clock()
	local v67 = string.format
	local v68 = (v66 - v26) * 1000
	local v69 = v66 - v_u_8
	table.insert(v10, v67("%s %.0fms@%.1fs", "load the rest", v68, v69))
	v9 = v66
	v26 = v9
end
v55.start()
v54.sync()
if v_u_7 then
	local v70 = os.clock()
	local v71 = string.format
	local v72 = (v70 - v26) * 1000
	local v73 = v70 - v_u_8
	table.insert(v10, v71("%s %.0fms@%.1fs", "start Perf State (waits for the server)", v72, v73))
	v9 = v70
	v26 = v9
end
v_u_2.LocalPlayer:WaitForChild("PlayerGui"):WaitForChild("Main")
if v_u_7 then
	local v74 = os.clock()
	local v75 = string.format
	local v76 = (v74 - v26) * 1000
	local v77 = v74 - v_u_8
	table.insert(v10, v75("%s %.0fms@%.1fs", "wait for the UI", v76, v77))
	v9 = v74
	v26 = v9
end
v63.start()
v51.start()
v24.start()
v25.start()
v31.start()
v36.start()
v37.start()
v39.start()
task.spawn(v38.start)
if v_u_7 then
	local v78 = os.clock()
	local v79 = string.format
	local v80 = (v78 - v26) * 1000
	local v81 = v78 - v_u_8
	table.insert(v10, v79("%s %.0fms@%.1fs", "start Ui Events Look Enemies Gates Input AutoClick Tutorial", v80, v81))
	v9 = v78
	v26 = v9
end
v40.start()
require(script.Parent.Offers).start(v_u_45.notify)
require(script.Parent.ServerBoost).start(v_u_45.notify)
require(script.Parent.LuckStore).start()
v_u_45.start()
task.spawn(require(script.Parent.LuckButton).start)
v46.start()
task.spawn(v59.start)
if v_u_7 then
	local v82 = os.clock()
	local v83 = string.format
	local v84 = (v82 - v26) * 1000
	local v85 = v82 - v_u_8
	table.insert(v10, v83("%s %.0fms@%.1fs", "start Menus Hud HubView", v84, v85))
	v9 = v82
	v26 = v9
end
v47.start()
v48.start()
v56.start()
v60.start()
v61.start()
task.delay(8, v49.syncPrices)
v57.start()
v49.onComingSoon(function(p86)
	-- upvalues: (copy) v_u_45
	v_u_45.notify(p86 .. " is coming soon!")
end)
v40.onNotify(function(p87)
	-- upvalues: (copy) v_u_45
	v_u_45.notify(p87)
end)
v58.onNotify(v_u_45.notify)
v58.start()
v62.start(v_u_45.notify)
task.spawn(require(script.Parent.LimitedCards).start, v_u_45.notify)
task.spawn(require(script.Parent.Gifting).start, v_u_45.notify)
task.spawn(v64.start)
v65.start()
require(script.Parent.Boss).start()
require(script.Parent.BossRift).start()
local v88 = require(script.Parent.BossShop)
v88.onNotify(v_u_45.notify)
v88.start()
require(script.Parent.BossDrops).start()
require(script.Parent.AutoWin).start()
require(script.Parent.FuseMachine).start(v_u_45.notify)
require(script.Parent.FuseMenu).start()
require(script.Parent.Sky).start()
task.spawn(require(script.Parent.WelcomeBack).start, v_u_45.notify)
v53.start()
v23.event("Fx").OnClientEvent:Connect(function(p89)
	-- upvalues: (copy) v_u_52
	if type(p89) == "table" then
		v_u_52.play(p89)
	end
end)
v4:BindToRenderStep("Shake", Enum.RenderPriority.Camera.Value + 1, function()
	-- upvalues: (copy) v_u_6, (copy) v_u_50
	local v90 = v_u_6.CurrentCamera
	if v90 then
		v90.CFrame = v90.CFrame * v_u_50.shakeOffset()
	end
end)
if v_u_7 then
	local v91 = os.clock()
	local v92 = string.format
	local v93 = (v91 - v26) * 1000
	local v94 = v91 - v_u_8
	table.insert(v10, v92("%s %.0fms@%.1fs", "start the rest", v93, v94))
	v9 = v91
end
if v_u_7 then
	v_u_2.LocalPlayer:SetAttribute("BootTimes", table.concat(v10, ", "))
end
task.spawn(function()
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6, (copy) v_u_50, (copy) v_u_7, (copy) v_u_8
	local v95 = v_u_2.LocalPlayer
	if not v95.Character then
		v95.CharacterAdded:Wait()
	end
	task.wait(4)
	local v96 = {}
	local v97 = v_u_3:FindFirstChild("Fx")
	if v97 then
		table.insert(v96, v97)
	end
	local v98 = v_u_5:FindFirstChild("Sfx")
	if v98 then
		table.insert(v96, v98)
	end
	local v99 = v_u_3:FindFirstChild("PetMeshes")
	if v99 then
		table.insert(v96, v99)
	end
	v_u_1:PreloadAsync(v96)
	if v97 then
		local v100 = v_u_6.CurrentCamera
		local v101 = not v100 and Vector3.new(0, 500, 0) or v100.CFrame.Position + v100.CFrame.LookVector * 400
		for _, v102 in v97:GetChildren() do
			v_u_50.burst(v102.Name, v101, Color3.new(1, 1, 1), 0.01)
			task.wait()
		end
	end
	if v_u_7 then
		v_u_2.LocalPlayer:SetAttribute("BootPreload", string.format("%.1fs", os.clock() - v_u_8))
	end
end)