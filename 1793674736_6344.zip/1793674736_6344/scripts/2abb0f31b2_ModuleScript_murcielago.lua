local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.new(1, 1, 1)
local v_u_6 = Color3.fromRGB(6, 9, 8)
local v_u_7 = Color3.fromRGB(236, 255, 244)
local v_u_8 = Enum.Material.SmoothPlastic
local v_u_9 = Enum.PartType.Wedge
local v_u_10 = CFrame.new(0, 0.35, 0.35)
local v_u_11 = CFrame.Angles(0, 3.141592653589793, 0)
return function(p_u_12)
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_10, (copy) v_u_11, (copy) v_u_8, (copy) v_u_6, (copy) v_u_9, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_3
	return {
		["w7_murcielago"] = function(p_u_13, p14)
			-- upvalues: (ref) v_u_2, (copy) p_u_12, (ref) v_u_1, (ref) v_u_10, (ref) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_9, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (ref) v_u_3
			local v_u_15 = v_u_2.color(p14.color)
			local v16 = v_u_2.color(p14.color2)
			local v17 = p_u_13.headY / 1.5
			local v_u_18 = math.clamp(v17, 0.7, 3)
			local v_u_19 = p_u_12.backOf(p_u_13)
			local v20 = v_u_1:FindFirstChild("EyePieces")
			if v20 then
				v20 = v20:FindFirstChild("w7_murcielago")
			end
			if v20 and v20:IsA("MeshPart") then
				local v21 = v20:Clone()
				local v22 = v20.Size
				local v23 = v_u_18 * 5.4
				local v24 = v20.Size.X
				local v25 = v20.Size.Y
				local v26 = v20.Size.Z
				v21.Size = v22 * (v23 / math.max(v24, v25, v26, 0.01))
				v21.CanCollide = false
				v21.CanQuery = false
				v21.CanTouch = false
				v21.CastShadow = false
				v21.Massless = true
				v21.Parent = v_u_2.folder()
				p_u_12.glue(p_u_13, v21, function(p27)
					-- upvalues: (copy) v_u_19, (ref) v_u_10, (copy) v_u_18, (ref) v_u_11
					return p27 * v_u_19 * CFrame.new(v_u_10.Position * v_u_18) * v_u_11
				end)
			else
				for _, v28 in { -1, 1 } do
					local v29 = {}
					for v30, v31 in {
						{ 25, 2.5 },
						{ 52, 2.3 },
						{ 80, 1.8 }
					} do
						local v32 = v31[1]
						local v33 = math.rad(v32)
						local v34 = v31[2] * v_u_18
						local v35 = v28 * math.cos(v33)
						local v36 = math.sin(v33)
						local v_u_37 = Vector3.new(v35, v36, 0.15)
						local v38 = v28 * 0.35 * v_u_18
						local v39 = v_u_18 * 0.5
						local v40 = Vector3.new(v38, v39, 0)
						local v_u_41 = v40 + v_u_37 * v34 / 2
						local v42 = p_u_12.bar
						local v43 = v_u_18 * 0.12
						local v44 = v_u_18 * 0.12
						local v45 = v42(Vector3.new(v43, v44, v34), v16, 0, v_u_8)
						p_u_12.glue(p_u_13, v45, function(p46)
							-- upvalues: (copy) v_u_19, (copy) v_u_41, (copy) v_u_37
							return p46 * v_u_19 * CFrame.lookAt(v_u_41, v_u_41 + v_u_37)
						end)
						v29[v30] = v40 + v_u_37 * v34
					end
					for v47 = 1, 2 do
						local v_u_48 = v29[v47]
						local v_u_49 = v29[v47 + 1]
						local v50 = v28 * 0.35 * v_u_18
						local v51 = v_u_18 * 0.5
						local v52 = Vector3.new(v50, v51, 0)
						local v_u_53 = (v_u_48 + v_u_49 + v52) / 3
						local v54 = (v_u_48 - v_u_49).Magnitude
						local v55 = ((v_u_48 + v_u_49) / 2 - v52).Magnitude
						local v56 = p_u_12.bar
						local v57 = v54 * 0.9
						local v58 = v56(Vector3.new(0.05, v55, v57), v_u_6, 0.05, v_u_8)
						v58.Shape = v_u_9
						local v_u_59 = ((v_u_48 + v_u_49) / 2 - v52).Unit
						local v_u_60 = (v_u_48 - v_u_49).Unit
						p_u_12.glue(p_u_13, v58, function(p61)
							-- upvalues: (copy) v_u_19, (copy) v_u_53, (copy) v_u_59, (copy) v_u_60
							return p61 * v_u_19 * CFrame.fromMatrix(v_u_53, v_u_59:Cross(v_u_60), v_u_59)
						end)
						local v62 = p_u_12.bar
						local v63 = v_u_18 * 0.08
						local v64 = v_u_18 * 0.08
						local v65 = v62(Vector3.new(v63, v64, v54), v_u_15)
						p_u_12.glue(p_u_13, v65, function(p66)
							-- upvalues: (copy) v_u_19, (copy) v_u_48, (copy) v_u_49
							return p66 * v_u_19 * CFrame.lookAt((v_u_48 + v_u_49) / 2, v_u_49)
						end)
					end
				end
			end
			local function v_u_67() end
			local v_u_70 = p_u_12.throb(p_u_13, 6, 2, 1.2, function(p68)
				-- upvalues: (ref) p_u_12, (copy) p_u_13, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4, (copy) v_u_15, (ref) v_u_67
				local v69 = p_u_12.feetAt(p_u_13, p68, 0.15)
				v_u_2.ring(v69, v_u_6, 5 * p_u_13.fx, 0.5, v_u_4.Ring)
				v_u_2.ring(v69, v_u_15, 6.5 * p_u_13.fx, 0.6, v_u_4.Ring)
				v_u_67()
			end)
			local v_u_71 = v_u_18 * 3.2
			local v77 = p_u_12.group(p_u_13, function(p72, p73)
				-- upvalues: (copy) v_u_18, (copy) p_u_13
				local v74 = p72 * CFrame.new(v_u_18 * -1.15, p_u_13.headY - v_u_18 * 0.05, v_u_18 * 1.15)
				local v75 = CFrame.Angles
				local v76 = p73 * 0.8
				return v74 * v75(0, 0, math.sin(v76) * 0.12 + 0.35)
			end)
			local v78 = p_u_12.bar(Vector3.new(0.2, 0.2, 0.2), v_u_5, 1)
			p_u_12.pin(p_u_13, v77, v78, CFrame.identity)
			local v79 = Instance.new("Attachment")
			local v80 = v_u_71 / 2
			v79.Position = Vector3.new(0, v80, 0)
			v79.Parent = v78
			local v81 = Instance.new("Attachment")
			local v82 = -v_u_71 / 2
			v81.Position = Vector3.new(0, v82, 0)
			v81.Parent = v78
			local v_u_83 = Instance.new("Beam")
			v_u_83.Attachment0 = v79
			v_u_83.Attachment1 = v81
			v_u_83.Texture = v_u_4.MurcielagoMoon
			v_u_83.TextureMode = Enum.TextureMode.Stretch
			v_u_83.Color = ColorSequence.new(v_u_7)
			v_u_83.LightEmission = 0.5
			v_u_83.LightInfluence = 0
			v_u_83.FaceCamera = true
			v_u_83.Segments = 1
			v_u_83.Width0 = v_u_71
			v_u_83.Width1 = v_u_71
			v_u_83.Parent = v78
			local v84 = Instance.new("Attachment")
			v84.Position = Vector3.new(0, v_u_71, 0)
			v84.Parent = v78
			local v85 = Instance.new("Attachment")
			local v86 = -v_u_71
			v85.Position = Vector3.new(0, v86, 0)
			v85.Parent = v78
			local v87 = Instance.new("Beam")
			v87.Attachment0 = v84
			v87.Attachment1 = v85
			v87.Texture = v_u_4.Glow
			v87.TextureMode = Enum.TextureMode.Stretch
			v87.Color = ColorSequence.new(v_u_15)
			v87.LightEmission = 0.4
			v87.LightInfluence = 0
			v87.Transparency = NumberSequence.new(0.45)
			v87.FaceCamera = true
			v87.Segments = 1
			v87.ZOffset = -0.5
			v87.Width0 = v_u_71 * 2
			v87.Width1 = v_u_71 * 2
			v87.Parent = v78
			local v_u_88 = -1
			local v89 = p_u_13.ticks
			local function v93()
				-- upvalues: (copy) v_u_70, (ref) v_u_88, (copy) v_u_71, (copy) v_u_83
				local v90 = v_u_70() * 20
				local v91 = math.floor(v90) / 20
				if v91 ~= v_u_88 then
					v_u_88 = v91
					local v92 = v_u_71 * (v91 * 0.25 + 1)
					v_u_83.Width0 = v92
					v_u_83.Width1 = v92
					v_u_83.LightEmission = v91 * 0.5 + 0.5
				end
			end
			table.insert(v89, v93)
			local v94 = p_u_12.bar(Vector3.new(3, 2, 3) * v_u_18, v_u_5, 1)
			p_u_12.add(p_u_13, v94, function(p95)
				-- upvalues: (copy) v_u_18
				return p95 * CFrame.new(0, v_u_18 * 0.6, v_u_18 * 0.6)
			end)
			local v_u_96 = Instance.new("ParticleEmitter")
			v_u_96.Texture = v_u_4.MurcielagoBats
			v_u_96.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_96.FlipbookMode = Enum.ParticleFlipbookMode.Loop
			v_u_96.FlipbookFramerate = NumberRange.new(14, 18)
			v_u_96.FlipbookStartRandom = true
			v_u_96.Color = ColorSequence.new(v_u_6, v16)
			v_u_96.LightEmission = 0
			v_u_96.LightInfluence = 0
			v_u_96.Lifetime = NumberRange.new(1.6, 2.4)
			v_u_96.Size = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0),
				NumberSequenceKeypoint.new(0.1, v_u_18 * 0.45 * p_u_13.fx),
				NumberSequenceKeypoint.new(0.85, v_u_18 * 0.4 * p_u_13.fx),
				NumberSequenceKeypoint.new(1, 0)
			})
			v_u_96.Speed = NumberRange.new(v_u_18 * 2, v_u_18 * 4.5)
			v_u_96.SpreadAngle = Vector2.new(180, 60)
			v_u_96.Acceleration = Vector3.new(0, 1.5, 0)
			v_u_96.Drag = 1
			v_u_96.Shape = Enum.ParticleEmitterShape.Box
			v_u_96.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_96:SetAttribute("BaseRate", 1.6 * p_u_13.fx)
			v_u_96.Rate = 1.6 * p_u_13.fx * v_u_3.formRate()
			v_u_96.Parent = v94
			p_u_12.own(p_u_13, v94)
			local v97 = p_u_13.stops
			table.insert(v97, function()
				-- upvalues: (copy) v_u_96
				v_u_96.Enabled = false
			end)
			v_u_67 = function()
				-- upvalues: (copy) v_u_96, (ref) v_u_3
				v_u_96:Emit(v_u_3.level() <= 1 and 4 or 12)
			end
			p_u_12.particles(p_u_13, "AuraMode", v_u_15, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end