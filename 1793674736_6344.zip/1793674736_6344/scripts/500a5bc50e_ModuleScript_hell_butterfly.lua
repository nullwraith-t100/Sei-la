local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Enum.Material.SmoothPlastic
local function v_u_14(p6, p7) -- name: piece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v8 = v_u_1:FindFirstChild("EyePieces")
	if v8 then
		v8 = v8:FindFirstChild("w6_hell_butterfly")
	end
	if not (v8 and v8:IsA("MeshPart")) then
		return nil
	end
	local v9 = v8:Clone()
	v9.Anchored = true
	v9.CanCollide = false
	v9.CanQuery = false
	v9.CanTouch = false
	v9.CastShadow = false
	v9.Massless = true
	local v10 = v8.Size.X
	local v11 = v8.Size.Y
	local v12 = v8.Size.Z
	local v13 = math.max(v10, v11, v12, 0.01)
	v9.Size = v8.Size * (p6 / v13)
	if not v9:FindFirstChildWhichIsA("SurfaceAppearance") then
		v9.Color = p7
	end
	v9.Parent = v_u_2.folder()
	return v9
end
local function v_u_21(p15, p16, p17, p18, p19) -- name: flutter
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v20 = Instance.new("ParticleEmitter")
	v20.Texture = v_u_4.HellWings
	v20.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
	v20.FlipbookMode = Enum.ParticleFlipbookMode.Loop
	v20.FlipbookFramerate = NumberRange.new(9, 14)
	v20.FlipbookStartRandom = true
	v20.Color = ColorSequence.new(p16)
	v20.LightEmission = p19
	v20.LightInfluence = 0
	v20.Size = NumberSequence.new({
		NumberSequenceKeypoint.new(0, 0),
		NumberSequenceKeypoint.new(0.15, p17),
		NumberSequenceKeypoint.new(0.85, p17),
		NumberSequenceKeypoint.new(1, 0)
	})
	v20.Lifetime = NumberRange.new(1.8, 2.8)
	v20.Speed = NumberRange.new(0.6, 1.8)
	v20.SpreadAngle = Vector2.new(180, 180)
	v20.Acceleration = Vector3.new(0, 0.5, 0)
	v20.Rotation = NumberRange.new(-30, 30)
	v20.RotSpeed = NumberRange.new(-25, 25)
	v20.Shape = Enum.ParticleEmitterShape.Box
	v20.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	v20:SetAttribute("BaseRate", p18)
	v20.Rate = p18 * v_u_3.formRate()
	v20.Parent = p15
	return v20
end
return function(p_u_22)
	-- upvalues: (copy) v_u_2, (copy) v_u_21, (copy) v_u_4, (copy) v_u_3, (copy) v_u_14, (copy) v_u_5
	return {
		["w6_hell_butterfly"] = function(p_u_23, p24)
			-- upvalues: (ref) v_u_2, (copy) p_u_22, (ref) v_u_21, (ref) v_u_4, (ref) v_u_3, (ref) v_u_14, (ref) v_u_5
			local v_u_25 = v_u_2.color(p24.color)
			local v26 = v_u_2.color(p24.color2)
			local v27 = p_u_23.headY / 1.5
			local v_u_28 = math.clamp(v27, 0.7, 3)
			local v29 = p_u_22.bar
			local v30 = p_u_23.headY - p_u_23.feet + 1.4
			local v31 = v29(Vector3.new(4.2, v30, 4.2) * v_u_28, v_u_25, 1)
			p_u_22.add(p_u_23, v31, function(p32)
				-- upvalues: (copy) p_u_23
				return p32 * CFrame.new(0, (p_u_23.headY + p_u_23.feet) / 2 + 0.3, 0)
			end)
			p_u_22.own(p_u_23, v31)
			local v_u_33 = v_u_21(v31, v26, 0.42 * p_u_23.fx, 2.4, 0)
			v_u_21(v31, v_u_25, 0.34 * p_u_23.fx, 0.9, 0.6)
			local v_u_36 = p_u_22.throb(p_u_23, 4.8, 2.4, 2.4, function(p34)
				-- upvalues: (ref) v_u_2, (ref) p_u_22, (copy) p_u_23, (copy) v_u_25, (ref) v_u_4, (copy) v_u_33, (ref) v_u_3
				v_u_2.ring(p_u_22.feetAt(p_u_23, p34, 0.15), v_u_25, 5 * p_u_23.fx, 0.5, v_u_4.Ring)
				local v35 = v_u_33.Speed
				v_u_33.Speed = NumberRange.new(5 * p_u_23.fx, 9 * p_u_23.fx)
				v_u_33:Emit(v_u_3.level() <= 1 and 3 or 8)
				v_u_33.Speed = v35
			end)
			local v_u_37 = 0
			local v38 = p_u_23.ticks
			local function v44(_, p39)
				-- upvalues: (copy) v_u_36, (ref) v_u_37
				local v40 = v_u_36()
				local v41 = p39 * 1.7
				local v42 = (math.sin(v41) * 0.5 + 0.5) * 0.28
				local v43 = v40 * 3.141592653589793
				v_u_37 = v42 + math.sin(v43) * 0.6
			end
			table.insert(v38, v44)
			local v_u_51 = p_u_22.group(p_u_23, function(p45, p46)
				-- upvalues: (copy) v_u_28
				local v47 = CFrame.new
				local v48 = v_u_28 * 0.55
				local v49 = v_u_28 * 0.06
				local v50 = p46 * 1.7
				return p45 * v47(0, v48 + v49 * math.sin(v50), v_u_28 * 0.75) * CFrame.Angles(-0.15, 0, 0)
			end)
			local v52 = p_u_22.picture(v_u_28 * 4.8, v_u_4.Glow, v_u_25, 0.45)
			p_u_22.add(p_u_23, v52, function()
				-- upvalues: (copy) v_u_51, (copy) v_u_28
				return v_u_51.cf * CFrame.new(0, 0, v_u_28 * -0.2) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v_u_53 = v_u_14(v_u_28 * 4.4, v26)
			if v_u_53 then
				local v_u_54 = v_u_53.Size
				p_u_22.add(p_u_23, v_u_53, function()
					-- upvalues: (copy) v_u_53, (copy) v_u_54, (ref) v_u_37, (copy) v_u_51
					local v55 = v_u_53
					local v56 = v_u_54.X * (1 - v_u_37 * 0.55)
					local v57 = v_u_54.Y
					local v58 = v_u_54.Z
					v55.Size = Vector3.new(v56, v57, v58)
					return v_u_51.cf * CFrame.Angles(0, 3.141592653589793, 0)
				end)
			else
				local v_u_59 = v_u_28 * 1.9
				local v60 = v_u_28 * 2.4
				local v_u_61 = v_u_37
				for _, v_u_62 in { -1, 1 } do
					local v63 = p_u_22.bar
					local v64 = v_u_28 * 0.08
					local v65 = v63(Vector3.new(v_u_59, v60, v64), v26, 0, v_u_5)
					local v66 = p_u_22.bar
					local v67 = v_u_59 * 1.06
					local v68 = v60 * 1.06
					local v69 = v_u_28 * 0.05
					local v70 = v66(Vector3.new(v67, v68, v69), v_u_25, 0)
					p_u_22.add(p_u_23, v65, function() -- name: at
						-- upvalues: (copy) v_u_51, (copy) v_u_62, (ref) v_u_61, (copy) v_u_59, (copy) v_u_28
						return v_u_51.cf * CFrame.Angles(0, v_u_62 * v_u_61 * 1.1, 0) * CFrame.new(v_u_62 * v_u_59 / 2, v_u_28 * 0.2, 0)
					end)
					p_u_22.add(p_u_23, v70, function()
						-- upvalues: (copy) v_u_51, (copy) v_u_62, (ref) v_u_61, (copy) v_u_59, (copy) v_u_28
						return v_u_51.cf * CFrame.Angles(0, v_u_62 * v_u_61 * 1.1, 0) * CFrame.new(v_u_62 * v_u_59 / 2, v_u_28 * 0.2, 0) * CFrame.new(0, 0, v_u_28 * -0.05)
					end)
				end
			end
			p_u_22.particles(p_u_23, "AuraMode", v_u_25, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow" }
			})
			p_u_22.particles(p_u_23, "Petals", v_u_25, {
				["rate"] = 0.7,
				["glow"] = 0.7,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end