local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("HttpService")
local v3 = game:GetService("Players")
local v4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = require(script.Parent.BossShop)
local v_u_9 = require(script.Parent.Gamepad)
local v_u_10 = require(script.Parent.LuckLadder)
local v_u_11 = require(script.Parent.Hud)
local v_u_12 = require(script.Parent.Menus)
local v_u_13 = require(script.Parent.Revive)
local v_u_14 = require(script.Parent.Sfx)
local v_u_15 = require(script.Parent.Store)
local v_u_16 = require(script.Parent.Tutorial)
local v_u_17 = require(v4.Shared.Config.Boss)
local v_u_18 = require(v4.Shared.Config.BossDrops)
local v_u_19 = require(v4.Shared.Logic.BossDrops)
local v_u_20 = require(v4.Shared.Config.Images)
local v_u_21 = require(v4.Shared.Logic.Boss)
local v_u_22 = {}
local v_u_23 = v3.LocalPlayer
local v_u_24 = Color3.fromRGB
local v_u_25 = ColorSequence.new(v_u_24(255, 170, 40), v_u_24(235, 96, 14))
local v_u_26 = ColorSequence.new(v_u_24(255, 90, 95), v_u_24(200, 16, 46))
local v_u_27 = ColorSequence.new(v_u_24(255, 14, 14), v_u_24(255, 33, 140))
local v_u_28 = v_u_24(255, 205, 60)
local v_u_29 = v_u_24(255, 80, 70)
local v_u_30 = v_u_24(127, 240, 255)
local v_u_31 = {
	["join"] = function() -- name: join end,
	["leave"] = function() -- name: leave end
}
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = nil
local v_u_38 = nil
local v_u_39 = nil
local v_u_40 = nil
local v_u_41 = nil
local v_u_42 = nil
local v_u_43 = nil
local v_u_44 = "join"
local v_u_45 = nil
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = nil
local v_u_49 = false
local v_u_50 = nil
local v_u_51 = false
local v_u_52 = nil
local v_u_53 = {}
local v_u_54 = {}
local v_u_55 = nil
local v_u_56 = nil
local v_u_57 = 0
local v_u_58 = nil
local v_u_59 = {}
local v_u_60 = {}
local v_u_61 = nil
local v_u_62 = nil
local v_u_63 = false
local v_u_64 = -1
local v_u_65 = nil
local v_u_66 = nil
local v_u_67 = {}
local v_u_68 = {}
local v_u_69 = nil
local v_u_70 = 0
local v_u_71 = 0
local v_u_72 = nil
local v_u_73 = nil
local function v_u_77(p74, p75) -- name: child
	for v76 in string.gmatch(p75, "[^%.]+") do
		if not p74 then
			continue
		end
		p74 = p74:FindFirstChild(v76)
	end
	return p74
end
local function v_u_82(p78, p79) -- name: labels
	local v80 = {}
	for _, v81 in p78:GetChildren() do
		if not v81:IsA("TextLabel") or v81.Name ~= p79 and v81.Name ~= p79 .. "Shadow" then
			continue
		end
		table.insert(v80, v81)
	end
	return v80
end
local function v_u_87(p83, p84, p85) -- name: setText
	for _, v86 in p83 do
		v86.Text = p84
		if not p85 or string.find(v86.Name, "Shadow") then
			continue
		end
		v86.TextColor3 = p85
	end
end
local function v_u_88() -- name: busy
	-- upvalues: (copy) v_u_23, (copy) v_u_16, (copy) v_u_12, (copy) v_u_9, (copy) v_u_13
	return (v_u_23:GetAttribute("InWave") == true or v_u_23:GetAttribute("InStages") == true) and true or (v_u_23:GetAttribute("TutorialDone") ~= true or v_u_16.active() or (v_u_12.current() ~= nil and true or (v_u_9.captured() or v_u_13.open())))
end
local v_u_89 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_90 = v_u_24(20, 6, 12)
local v_u_91 = v_u_24(127, 240, 255)
local v_u_92 = {
	"#FFF1A8",
	"#FFC23A",
	"#FF7A1A",
	"#FF3A14",
	"#FF7A1A",
	"#FFC23A"
}
local v_u_93 = {
	"#F2D2FF",
	"#C65CFF",
	"#FF4FA3",
	"#FFC23A",
	"#FF4FA3",
	"#C65CFF"
}
local v_u_94 = {
	{ "#FFF6B0", "#FFD23A", "#FF9F1A" },
	{ "#FFFFFF", "#D6E2EE", "#93A9BF" },
	{ "#FFE2C2", "#F09A5A", "#B05A28" }
}
local v_u_95 = { "#FFB0A0", "#FF5A4A", "#E0182E" }
local v_u_96 = {
	["title"] = "TITLE",
	["aura"] = "AURA",
	["pet"] = "PET"
}
local v_u_97 = nil
local v_u_98 = nil
local v_u_99 = nil
local v_u_100 = nil
local v_u_101 = {}
local v_u_102 = 5
local v_u_103 = nil
local v_u_104 = nil
local v_u_105 = {}
local v_u_106 = nil
local v_u_107 = nil
local v_u_108 = 1
local v_u_109 = nil
local v_u_110 = {}
local v_u_111 = nil
local v_u_112 = {}
local v_u_113 = {}
local v_u_114 = nil
local function v_u_119(p115) -- name: palette
	local v116 = {}
	for _, v117 in p115 do
		local v118 = Color3.fromHex
		table.insert(v116, v118(v117))
	end
	return v116
end
local function v_u_128(p120) -- name: spread
	local v121 = {}
	for v122, v123 in p120 do
		local v124 = ColorSequenceKeypoint.new
		local v125 = v122 - 1
		local v126 = #p120 - 1
		local v127 = v125 / math.max(v126, 1)
		table.insert(v121, v124(v127, v123))
	end
	return ColorSequence.new(v121)
end
local function v_u_134(p129, p130) -- name: loopAt
	local v131 = #p129
	local v132 = p130 % 1 * v131
	local v133 = math.floor(v132)
	return p129[v133 + 1]:Lerp(p129[(v133 + 1) % v131 + 1], v132 - v133)
end
local function v_u_143(p135, p136) -- name: swept
	-- upvalues: (copy) v_u_134
	local v137 = {}
	for v138 = 0, 9 do
		local v139 = v138 / 9
		local v140 = ColorSequenceKeypoint.new
		local v141 = v_u_134
		local v142 = p136 + v139 * 0.8
		table.insert(v137, v140(v139, v141(p135, v142)))
	end
	return ColorSequence.new(v137)
end
local function v_u_172() -- name: follow
	-- upvalues: (ref) v_u_98, (ref) v_u_99, (ref) v_u_97, (ref) v_u_48, (copy) v_u_7, (copy) v_u_101, (ref) v_u_102, (ref) v_u_111
	local v144 = v_u_98
	local v145 = v_u_99
	local v146 = v_u_97
	if v144 and (v145 and v146) then
		local v147 = v145.AbsolutePosition - v146.AbsolutePosition
		local v148 = v145.AbsoluteSize
		local v149 = UDim2.fromOffset
		local v150 = v147.X
		local v151 = math.floor(v150)
		local v152 = v147.Y
		v144.Position = v149(v151, (math.floor(v152)))
		local v153 = UDim2.fromOffset
		local v154 = v148.X
		local v155 = math.floor(v154)
		local v156 = v148.Y
		v144.Size = v153(v155, (math.floor(v156)))
		local v157 = 0.47 * v148.X
		if v157 < 2 then
			return
		end
		local v158 = 0.20800000000000002 * v148.Y
		local v159 = 18 / math.max(v158, 1)
		local v160 = math.clamp(v159, 1, 1.9)
		local v161 = v145.AbsolutePosition.X
		local v162 = v_u_48
		local v163 = (not v162 or (not v162.Visible or v162.AbsoluteSize.X <= 2)) and 8 or v162.AbsolutePosition.X + v162.AbsoluteSize.X + 6
		local v164 = v_u_7.CurrentCamera
		local v165 = not v164 and 1280 or v164.ViewportSize.X
		local v166 = (v161 + v157 - v163) / v157
		local v167 = (v165 - 8 - (v161 + v148.X - v157)) / v157
		local v168 = math.min(v160, v166, v167)
		local v169 = math.max(1, v168)
		for _, v170 in v_u_101 do
			v170.Scale = v169
		end
		local v171 = v169 > 1.2 and 3 or 5
		if v171 ~= v_u_102 then
			v_u_102 = v171
			v_u_111 = nil
		end
	end
end
local function v_u_177(p173) -- name: setSweeping
	-- upvalues: (ref) v_u_97, (ref) v_u_114, (copy) v_u_5, (copy) v_u_172, (copy) v_u_113, (copy) v_u_143
	local v174 = v_u_97
	if v174 then
		v174.Enabled = p173
	end
	if p173 and not v_u_114 then
		v_u_114 = v_u_5.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_172, (ref) v_u_113, (ref) v_u_143
			v_u_172()
			local v175 = os.clock()
			for _, v176 in v_u_113 do
				v176.gradient.Color = v_u_143(v176.palette, v175 * v176.speed)
			end
		end)
	elseif not p173 and v_u_114 then
		v_u_114:Disconnect()
		v_u_114 = nil
	end
end
local function v_u_186(p178, p179, p180, p181, p182, p183) -- name: listText
	-- upvalues: (copy) v_u_89, (copy) v_u_90
	local v184 = Instance.new("TextLabel")
	v184.Name = p179
	v184.BackgroundTransparency = 1
	v184.AnchorPoint = Vector2.new(0, 0.5)
	v184.Position = UDim2.fromScale(p180, 0.5)
	v184.Size = UDim2.fromScale(p181, p182)
	v184.FontFace = v_u_89
	v184.TextScaled = true
	v184.TextColor3 = Color3.new(1, 1, 1)
	v184.TextXAlignment = p183
	v184.Text = ""
	v184.ZIndex = 3
	local v185 = Instance.new("UIStroke")
	v185.Color = v_u_90
	v185.Thickness = 1.5
	v185.LineJoinMode = Enum.LineJoinMode.Round
	v185.Parent = v184
	v184.Parent = p178
	return v184
end
local function v_u_195(p187, p188, p189) -- name: makeList
	-- upvalues: (copy) v_u_101
	local v190 = Instance.new("Frame")
	v190.Name = p188
	v190.BackgroundTransparency = 1
	v190.AnchorPoint = Vector2.new(p189 and 0 or 1, 0)
	v190.Position = UDim2.fromScale(p189 and 0.53 or 0.47, 0.78)
	v190.Size = UDim2.fromScale(0.47, 1.6)
	v190.Visible = false
	local v191 = Instance.new("UIScale")
	v191.Name = "Fit"
	v191.Parent = v190
	local v192 = v_u_101
	table.insert(v192, v191)
	local v193 = Instance.new("UIListLayout")
	v193.SortOrder = Enum.SortOrder.LayoutOrder
	v193.Padding = UDim.new(0.014, 0)
	local v194
	if p189 then
		v194 = Enum.HorizontalAlignment.Right
	else
		v194 = Enum.HorizontalAlignment.Left
	end
	v193.HorizontalAlignment = v194
	v193.Parent = v190
	v190.Parent = p187
	return v190
end
local function v_u_213(p196, p197, p198, p199) -- name: header
	-- upvalues: (copy) v_u_186, (copy) v_u_113, (copy) v_u_119
	local v200 = Instance.new("Frame")
	v200.Name = "Header"
	v200.LayoutOrder = 0
	v200.BackgroundTransparency = 1
	v200.Size = UDim2.fromScale(1, 0.13)
	v200.Parent = p196
	local v201 = v_u_186
	local v202 = "Title"
	local v203 = 0.02
	local v204 = 0.96
	local v205 = 1
	local v206
	if p199 then
		v206 = Enum.TextXAlignment.Right
	else
		v206 = Enum.TextXAlignment.Left
	end
	local v207 = v201(v200, v202, v203, v204, v205, v206)
	v207.Text = p197
	local v208 = v207:FindFirstChildOfClass("UIStroke")
	if v208 then
		v208.Thickness = 2
	end
	local v209 = ColorSequence.new(Color3.new(1, 1, 1))
	local v210 = Instance.new("UIGradient")
	v210.Color = v209
	v210.Rotation = 0
	v210.Parent = v207
	local v211 = v_u_113
	local v212 = {
		["gradient"] = nil,
		["palette"] = nil,
		["speed"] = 0.35,
		["gradient"] = v210,
		["palette"] = v_u_119(p198)
	}
	table.insert(v211, v212)
	return v207
end
local function v_u_232(p214, p215) -- name: makeRow
	-- upvalues: (copy) v_u_90, (copy) v_u_186
	local v216 = Instance.new("Frame")
	v216.Name = "Row" .. p215
	v216.LayoutOrder = p215
	v216.Size = UDim2.fromScale(1, 0.13)
	v216.BackgroundColor3 = v_u_90
	v216.BackgroundTransparency = 0.3
	v216.Visible = false
	local v217 = Instance.new("UICorner")
	v217.CornerRadius = UDim.new(0.3, 0)
	v217.Parent = v216
	local v218 = Instance.new("UIStroke")
	v218.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v218.Color = v_u_90
	v218.Thickness = 1.5
	v218.Parent = v216
	local v219 = Instance.new("Frame")
	v219.Name = "Fill"
	v219.BackgroundColor3 = Color3.new(1, 1, 1)
	v219.BackgroundTransparency = 0.2
	v219.BorderSizePixel = 0
	v219.Size = UDim2.fromScale(0, 1)
	v219.ZIndex = 2
	local v220 = Instance.new("UICorner")
	v220.CornerRadius = UDim.new(0.3, 0)
	v220.Parent = v219
	local v221 = ColorSequence.new(Color3.new(1, 1, 1))
	local v222 = Instance.new("UIGradient")
	v222.Color = v221
	v222.Rotation = 0
	v222.Parent = v219
	v219.Parent = v216
	local v223 = v_u_186(v216, "Place", 0.025, 0.14, 0.78, Enum.TextXAlignment.Center)
	local v224, v225 = ColorSequence.new(Color3.new(1, 1, 1))
	local v226 = Instance.new("UIGradient")
	v226.Color = v224
	v226.Rotation = v225 or 90
	v226.Parent = v223
	local v227 = v_u_186(v216, "Name", 0.18, 0.56, 0.68, Enum.TextXAlignment.Left)
	local v228 = v_u_186(v216, "Share", 0.74, 0.235, 0.78, Enum.TextXAlignment.Right)
	local v229, v230 = ColorSequence.new(Color3.new(1, 1, 1))
	local v231 = Instance.new("UIGradient")
	v231.Color = v229
	v231.Rotation = v230 or 90
	v231.Parent = v228
	v216.Parent = p214
	return {
		["frame"] = v216,
		["stroke"] = v218,
		["fill"] = v219,
		["fillGradient"] = v222,
		["place"] = v223,
		["placeGradient"] = v226,
		["name"] = v227,
		["share"] = v228,
		["shareGradient"] = v231
	}
end
local function v_u_253(p233, p234, p235) -- name: dropRow
	-- upvalues: (copy) v_u_186, (copy) v_u_19, (copy) v_u_96, (copy) v_u_113, (copy) v_u_119, (copy) v_u_128, (copy) v_u_105
	local v236 = Color3.fromHex(p235.glow)
	local v237 = Instance.new("Frame")
	v237.Name = "Drop" .. p234
	v237.LayoutOrder = p234
	v237.Size = UDim2.fromScale(1, 0.13)
	v237.BackgroundColor3 = v236:Lerp(Color3.new(0, 0, 0), 0.72)
	v237.BackgroundTransparency = 0.2
	local v238 = Instance.new("UICorner")
	v238.CornerRadius = UDim.new(0.3, 0)
	v238.Parent = v237
	local v239 = Instance.new("UIStroke")
	v239.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v239.Color = v236
	v239.Thickness = 1.6
	v239.Transparency = 0.1
	v239.Parent = v237
	local v240 = v_u_186(v237, "Name", 0.04, 0.7, 0.68, Enum.TextXAlignment.Left)
	v240.Text = string.upper(v_u_19.nameOf(p235)) .. " " .. (v_u_96[p235.kind] or "")
	local v241 = v240:FindFirstChildOfClass("UIStroke")
	if v241 then
		v241.Color = Color3.fromHex(p235.stroke)
	end
	local v242 = ColorSequence.new(Color3.new(1, 1, 1))
	local v243 = Instance.new("UIGradient")
	v243.Color = v242
	v243.Rotation = 0
	v243.Parent = v240
	local v244 = v_u_113
	local v245 = {
		["gradient"] = nil,
		["palette"] = nil,
		["speed"] = 0.45,
		["gradient"] = v243,
		["palette"] = v_u_119(p235.colors)
	}
	table.insert(v244, v245)
	local v246 = v_u_186(v237, "Odds", 0.75, 0.22, 0.78, Enum.TextXAlignment.Right)
	v246.Text = v_u_19.percent(p235.chance)
	local v247 = v_u_119(p235.colors)
	local v248, v249 = v_u_128({ v247[1], v247[2], v247[3] })
	local v250 = Instance.new("UIGradient")
	v250.Color = v248
	v250.Rotation = v249 or 90
	v250.Parent = v246
	v237.Parent = p233
	local v251 = v_u_105
	local v252 = {
		["frame"] = v237,
		["stroke"] = v239,
		["labels"] = { v240, v246 },
		["odds"] = v246,
		["chance"] = p235.chance
	}
	table.insert(v251, v252)
end
local function v_u_267(p254, p255) -- name: luckRow
	-- upvalues: (copy) v_u_24, (copy) v_u_20, (copy) v_u_186, (copy) v_u_6, (copy) v_u_14, (copy) v_u_8, (ref) v_u_106, (ref) v_u_107
	local v256 = Instance.new("TextButton")
	v256.Name = "Luck"
	v256.LayoutOrder = p255
	v256.Size = UDim2.fromScale(0.62, 0.1495)
	v256.BackgroundColor3 = Color3.new(1, 1, 1)
	v256.AutoButtonColor = false
	v256.Text = ""
	v256.Visible = false
	v256.Selectable = true
	v256:SetAttribute("Pad", true)
	local v257 = Instance.new("UICorner")
	v257.CornerRadius = UDim.new(0.3, 0)
	v257.Parent = v256
	local v258, v259 = ColorSequence.new(v_u_24(120, 245, 120), v_u_24(16, 150, 70))
	local v260 = Instance.new("UIGradient")
	v260.Color = v258
	v260.Rotation = v259 or 90
	v260.Parent = v256
	local v261 = Instance.new("UIStroke")
	v261.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v261.Color = v_u_24(255, 205, 60)
	v261.Thickness = 2
	v261.Parent = v256
	local v262 = Instance.new("ImageLabel")
	v262.Name = "Clover"
	v262.BackgroundTransparency = 1
	v262.AnchorPoint = Vector2.new(0, 0.5)
	v262.Position = UDim2.fromScale(0.02, 0.5)
	v262.Size = UDim2.fromScale(1.3, 1.3)
	v262.Image = v_u_20.Icon.LuckClover
	v262.ScaleType = Enum.ScaleType.Fit
	v262.ZIndex = 3
	local v263 = Instance.new("UIAspectRatioConstraint")
	v263.AspectRatio = 1
	v263.DominantAxis = Enum.DominantAxis.Height
	v263.Parent = v262
	v262.Parent = v256
	local v264 = v_u_186(v256, "Text", 0.24, 0.72, 0.74, Enum.TextXAlignment.Center)
	v264.Text = "x2 / x5 LUCK"
	local v265 = v264:FindFirstChildOfClass("UIStroke")
	if v265 then
		v265.Color = v_u_24(6, 60, 24)
	end
	local v_u_266 = Instance.new("UIScale")
	v_u_266.Parent = v256
	v256.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_266, (ref) v_u_6
		v_u_6:Create(v_u_266, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1.06
		}):Play()
	end)
	v256.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_266, (ref) v_u_6
		v_u_6:Create(v_u_266, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end)
	v256.Activated:Connect(function()
		-- upvalues: (ref) v_u_14, (ref) v_u_8
		v_u_14.play("Click")
		v_u_8.open("luck")
	end)
	v256.Parent = p254
	v_u_106 = v256
	v_u_107 = v264
end
local function v_u_276(p268) -- name: drawLuck
	-- upvalues: (ref) v_u_106, (copy) v_u_8, (copy) v_u_16, (ref) v_u_107, (copy) v_u_19, (copy) v_u_10, (ref) v_u_108, (copy) v_u_105
	local v269 = v_u_106
	if v269 then
		local v270 = p268 and v_u_8.luckShown()
		if v270 then
			v270 = not v_u_16.active()
		end
		v269.Visible = v270
		local v271, v272 = v_u_8.luck()
		local v273 = v_u_107
		if v273 and v270 then
			v273.Text = v271 <= 1 and "x2 / x5 LUCK" or ("x%* LUCK %*"):format(v271, (v_u_8.clock(v272)))
		end
		local v274 = not p268 and 1 or v_u_19.luckWith(v271, v_u_10.tier())
		if v274 ~= v_u_108 then
			v_u_108 = v274
			for _, v275 in v_u_105 do
				v275.odds.Text = v_u_19.percent(v_u_19.chanceWith(v275.chance, v274))
			end
		end
	end
end
local function v_u_283(p277) -- name: drawDrops
	-- upvalues: (ref) v_u_109, (ref) v_u_104, (copy) v_u_24, (copy) v_u_105
	if v_u_109 ~= p277 then
		v_u_109 = p277
		local v278 = v_u_104
		if v278 then
			v278.Text = p277 and "DROPS" or "NO DROPS THIS FIGHT"
			local v279
			if p277 then
				v279 = Color3.new(1, 1, 1)
			else
				v279 = v_u_24(150, 150, 160)
			end
			v278.TextColor3 = v279
		end
		for _, v280 in v_u_105 do
			v280.frame.BackgroundTransparency = p277 and 0.2 or 0.65
			v280.stroke.Transparency = p277 and 0.1 or 0.7
			for _, v281 in v280.labels do
				v281.TextTransparency = p277 and 0 or 0.55
				local v282 = v281:FindFirstChildOfClass("UIStroke")
				if not v282 then
					continue
				end
				v282.Transparency = p277 and 0 or 0.6
			end
		end
	end
end
local function v_u_295(p284, p285) -- name: buildLists
	-- upvalues: (ref) v_u_97, (ref) v_u_98, (ref) v_u_99, (copy) v_u_195, (copy) v_u_213, (copy) v_u_92, (copy) v_u_110, (copy) v_u_232, (ref) v_u_100, (ref) v_u_104, (copy) v_u_93, (copy) v_u_18, (copy) v_u_253, (copy) v_u_267, (ref) v_u_103
	local v286 = Instance.new("ScreenGui")
	v286.Name = "KyubiLists"
	v286.DisplayOrder = p285.DisplayOrder + 1
	v286.IgnoreGuiInset = p285.IgnoreGuiInset
	v286.ScreenInsets = p285.ScreenInsets
	v286.ResetOnSpawn = false
	v286.Enabled = false
	local v287 = Instance.new("Frame")
	v287.Name = "Bar"
	v287.BackgroundTransparency = 1
	v287.Parent = v286
	v286.Parent = p285.Parent
	v_u_97 = v286
	v_u_98 = v287
	v_u_99 = p284
	local v288 = v_u_195(v287, "KyubiDamage", false)
	v_u_213(v288, "DAMAGE", v_u_92, false)
	for v289 = 1, 6 do
		local v290 = v_u_110
		local v291 = v_u_232(v288, v289)
		table.insert(v290, v291)
	end
	v_u_100 = v288
	local v292 = v_u_195(v287, "KyubiDrops", true)
	v_u_104 = v_u_213(v292, "DROPS", v_u_93, true)
	for v293, v294 in v_u_18.list do
		v_u_253(v292, v293, v294)
	end
	v_u_267(v292, #v_u_18.list + 1)
	v_u_103 = v292
end
local function v_u_306(p_u_296) -- name: readBoard
	-- upvalues: (copy) v_u_2
	local function v297()
		-- upvalues: (ref) v_u_2, (copy) p_u_296
		return v_u_2:JSONDecode(p_u_296)
	end
	local v298, v299 = pcall(v297)
	local v300 = {}
	if not v298 or type(v299) ~= "table" then
		return v300
	end
	for _, v301 in v299 do
		if type(v301) ~= "table" then
			continue
		end
		local v302 = v301.id
		if type(v302) ~= "number" then
			continue
		end
		local v303 = v301.name
		if type(v303) ~= "string" then
			continue
		end
		local v304 = v301.share
		if type(v304) ~= "number" then
			continue
		end
		local v305 = {
			["id"] = v301.id,
			["name"] = v301.name,
			["share"] = v301.share
		}
		table.insert(v300, v305)
	end
	return v300
end
local function v_u_326() -- name: drawBoard
	-- upvalues: (copy) v_u_21, (ref) v_u_112, (copy) v_u_23, (ref) v_u_102, (copy) v_u_110, (copy) v_u_119, (copy) v_u_94, (copy) v_u_95, (copy) v_u_128, (copy) v_u_91, (copy) v_u_90, (copy) v_u_6
	local v307 = v_u_21.boardRows(v_u_112, v_u_23.UserId, v_u_102)
	for v308, v309 in v_u_110 do
		local v310 = v307[v308]
		v309.frame.Visible = v310 ~= nil
		if not v310 then
			continue
		end
		local v311 = v_u_119(v_u_94[v310.rank] or v_u_95)
		local v312 = v_u_128(v311)
		v309.place.Text = "#" .. v310.rank
		v309.placeGradient.Color = v312
		local v313 = v309.name
		local v314 = v310.line.name
		local v315 = utf8.len(v314)
		if v315 and v315 > 14 then
			local v316 = utf8.offset(v314, 14)
			if v316 then
				local v317 = v316 - 1
				v314 = string.sub(v314, 1, v317) .. ".."
			end
		end
		v313.Text = v314
		local v318 = v309.name
		local v319
		if v310.mine then
			v319 = v_u_91
		else
			v319 = Color3.new(1, 1, 1)
		end
		v318.TextColor3 = v319
		v309.share.Text = v_u_21.percentText(v310.line.share)
		v309.shareGradient.Color = v312
		v309.fillGradient.Color = v_u_128({ v311[3]:Lerp(v_u_90, 0.25), v311[2] })
		local v320
		if v310.line.share > 0 then
			local v321 = v310.line.share
			v320 = math.max(v321, 0.03)
		else
			v320 = 0
		end
		local v322 = v309.fill
		local v323 = {
			["Size"] = UDim2.fromScale(v320, 1)
		}
		v_u_6:Create(v322, TweenInfo.new(0.25, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v323):Play()
		local v324 = v309.stroke
		local v325
		if v310.mine then
			v325 = v_u_91
		else
			v325 = v_u_90
		end
		v324.Color = v325
		v309.stroke.Thickness = v310.mine and 2.2 or 1.5
	end
end
local function v_u_334(p327) -- name: stepLists
	-- upvalues: (copy) v_u_12, (ref) v_u_100, (ref) v_u_103, (copy) v_u_23, (copy) v_u_283, (copy) v_u_276, (copy) v_u_177, (copy) v_u_172, (copy) v_u_7, (ref) v_u_111, (ref) v_u_112, (copy) v_u_306, (copy) v_u_326
	local v328 = p327.inArena
	if v328 then
		v328 = v_u_12.current() == nil
	end
	local v329
	if p327.phase == "fight" then
		v329 = v328
	else
		v329 = false
	end
	if v329 then
		v328 = v329
	elseif p327.phase ~= "coming" then
		v328 = false
	end
	local v330 = v_u_100
	local v331 = v_u_103
	if v330 then
		v330.Visible = v329
	end
	if v331 then
		v331.Visible = v328
		local v332 = v_u_23:GetAttribute("BossNoDrops") ~= true
		v_u_283(v332)
		v_u_276(v332)
	end
	v_u_177(v328)
	if v329 then
		v_u_172()
		local v333 = v_u_7:GetAttribute("BossBoard")
		if type(v333) == "string" and v333 ~= v_u_111 then
			v_u_111 = v333
			v_u_112 = v_u_306(v333)
			v_u_326()
		end
	elseif v328 then
		v_u_172()
	end
end
local function v_u_378() -- name: build
	-- upvalues: (copy) v_u_23, (copy) v_u_77, (ref) v_u_45, (ref) v_u_33, (ref) v_u_34, (ref) v_u_35, (ref) v_u_36, (ref) v_u_37, (copy) v_u_24, (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_32, (copy) v_u_295, (ref) v_u_41, (ref) v_u_42, (ref) v_u_43, (ref) v_u_50, (copy) v_u_9, (ref) v_u_44, (ref) v_u_31, (ref) v_u_40, (ref) v_u_39, (copy) v_u_15, (copy) v_u_17, (ref) v_u_38, (ref) v_u_59, (copy) v_u_82, (ref) v_u_60, (ref) v_u_62, (copy) v_u_22, (ref) v_u_61, (ref) v_u_58, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (ref) v_u_66, (ref) v_u_53, (ref) v_u_54, (ref) v_u_55, (ref) v_u_52
	local v335 = v_u_23:FindFirstChild("PlayerGui")
	if v335 then
		v335 = v335:FindFirstChild("Main")
	end
	local v336
	if v335 then
		v336 = v_u_77(v335, "HUD.Top")
	else
		v336 = v335
	end
	local v337
	if v336 then
		v337 = v336:FindFirstChild("Boss")
	else
		v337 = v336
	end
	local v338
	if v335 then
		v338 = v_u_77(v335, "Templates.WorldRow.Button")
	else
		v338 = v335
	end
	local v339
	if v335 then
		v339 = v_u_77(v335, "Frames.Store.MainScrollingFrame.Holder.Pack_starter.Purchase1")
	else
		v339 = v335
	end
	local v340
	if v335 then
		v340 = v_u_77(v335, "HUD.Overlay.Title")
	else
		v340 = v335
	end
	local v341
	if v335 then
		v341 = v_u_77(v335, "HUD.Overlay")
	else
		v341 = v335
	end
	if not (v335 and (v336 and (v337 and (v337:IsA("Frame") and (v338 and (v338:IsA("GuiButton") and (v340 and (v340:IsA("Frame") and v341)))))))) then
		return false
	end
	v_u_45 = v337
	local v342 = v337:Clone()
	v342.Name = "KuramaBar"
	v342.Visible = false
	v342.Size = UDim2.fromScale(0.62, 0.4)
	v342.Position = UDim2.fromScale(0.5, 0)
	v342.AnchorPoint = Vector2.new(0.5, 0)
	local v343 = v_u_77(v342, "Back.Fill")
	if v343 and v343:IsA("GuiObject") then
		v_u_33 = v343
		v_u_34 = v343:FindFirstChildOfClass("UIGradient")
	end
	local v344 = v_u_77(v342, "Back.Name")
	if not (v344 and v344:IsA("TextLabel")) then
		v344 = nil
	end
	v_u_35 = v344
	local v345 = v_u_77(v342, "Back.Hp")
	if not (v345 and v345:IsA("TextLabel")) then
		v345 = nil
	end
	v_u_36 = v345
	local v346 = v342:FindFirstChild("Tag")
	if v346 and v346:IsA("TextLabel") then
		v_u_37 = v346
		v346.Text = "KYUBI"
		v346.TextColor3 = v_u_24(255, 150, 60)
	end
	local v347 = v_u_35
	if v347 then
		v347.Size = UDim2.fromScale(0.94, 0.62)
		v347.TextXAlignment = Enum.TextXAlignment.Center
		v347.Position = UDim2.fromScale(0.5, 0.5)
		v347.AnchorPoint = Vector2.new(0.5, 0.5)
	end
	local v348 = Instance.new("UIScale")
	v348.Name = "Big"
	v348.Scale = 1.4
	v348.Parent = v342
	v_u_46 = v348
	local v349 = v335:FindFirstChild("HUD")
	if v349 then
		v349 = v_u_77(v335, "HUD.TopRight")
	end
	if not (v349 and v349:IsA("GuiObject")) then
		v349 = nil
	end
	v_u_47 = v349
	local v350 = v_u_77(v335, "HUD.Left")
	if not (v350 and v350:IsA("GuiObject")) then
		v350 = nil
	end
	v_u_48 = v350
	local v351 = v_u_77(v335, "HUD.Notifications")
	if v351 and (v351:IsA("GuiObject") and (v336:IsA("GuiObject") and v351.ZIndex <= v336.ZIndex)) then
		v351.ZIndex = v336.ZIndex + 1
	end
	v342.Parent = v336
	v_u_32 = v342
	if v335:IsA("ScreenGui") then
		v_u_295(v342, v335)
	end
	local v352 = v338:Clone()
	v352.Name = "KuramaSide"
	v352.AnchorPoint = Vector2.new(0, 0.5)
	v352.Position = UDim2.new(1, 8, 0.5, 0)
	v352.Size = UDim2.fromScale(0.25, 0.6)
	v352.Visible = false
	local v353 = Instance.new("UIAspectRatioConstraint")
	v353.AspectRatio = 2.6
	v353.Parent = v352
	for _, v355 in v352:GetDescendants() do
		if not v355:IsA("TextLabel") then
			continue
		end
	end
	local v355 = nil
	v_u_41 = v355
	local v356 = v352:FindFirstChildOfClass("UIGradient")
	v_u_42 = v356
	local v357
	if v356 then
		v357 = v356.Color
	else
		v357 = nil
	end
	v_u_43 = v357
	v352:SetAttribute("Pad", true)
	local v358 = v352:FindFirstChild("Pop")
	if not (v358 and v358:IsA("UIScale")) then
		v358 = Instance.new("UIScale")
		v358.Name = "Pop"
		v358.Parent = v352
	end
	v_u_50 = v358
	v_u_9.hint(v352, Enum.KeyCode.DPadUp, 30, UDim2.new(0, -4, 0.5, 0))
	v352.Activated:Connect(function()
		-- upvalues: (ref) v_u_44, (ref) v_u_31
		if v_u_44 == "join" then
			v_u_31.join()
		else
			v_u_31.leave()
		end
	end)
	v352.Parent = v342
	v_u_40 = v352
	if v339 and v339:IsA("GuiButton") then
		local v359 = v339:Clone()
		v359.Name = "KuramaSkip"
		v359.AnchorPoint = Vector2.new(0, 0.5)
		v359.Position = UDim2.new(1, 8, 0.5, 0)
		v359.Size = UDim2.fromScale(0.3, 0.6)
		v359.Visible = false
		local v360 = Instance.new("UIAspectRatioConstraint")
		v360.AspectRatio = 3
		v360.Parent = v359
		local v361 = v359:FindFirstChild("PriceTag")
		if not (v361 and v361:IsA("TextLabel")) then
			v361 = nil
		end
		v_u_39 = v361
		v359.Activated:Connect(function()
			-- upvalues: (ref) v_u_15, (ref) v_u_17
			v_u_15.buyProduct(v_u_17.SKIP_PRODUCT)
		end)
		v359.Parent = v342
		v_u_38 = v359
	end
	local v362 = v340:Clone()
	v362.Name = "KuramaCall"
	v362.Visible = false
	v362.Position = UDim2.fromScale(0.437, 0.165)
	v362.Size = UDim2.fromScale(0.34, 0.085)
	local v363 = v362:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v363 then
		v363.AspectRatio = 4.6
	end
	v_u_59 = v_u_82(v362, "Main")
	v_u_60 = v_u_82(v362, "Sub")
	local v364 = Instance.new("UIScale")
	v364.Scale = 1
	v364.Parent = v362
	v_u_62 = v364
	local v365 = v338:Clone()
	v365.Name = "Join"
	v365.AnchorPoint = Vector2.new(0, 0.5)
	v365.Position = UDim2.fromScale(1.02, 0.5)
	v365.Size = UDim2.fromScale(0.42, 0.8)
	local v366 = Instance.new("UIAspectRatioConstraint")
	v366.AspectRatio = 2.8
	v366.Parent = v365
	for _, v368 in v365:GetDescendants() do
		if not v368:IsA("TextLabel") then
			continue
		end
	end
	local v368 = nil
	if v368 then
		v368.Text = "JOIN"
	end
	v365.Activated:Connect(function()
		-- upvalues: (ref) v_u_31, (ref) v_u_22
		v_u_31.join()
		v_u_22.closeCall()
	end)
	v365.Parent = v362
	v_u_61 = v365
	if v335 then
		v335 = v_u_77(v335, "Frames.Settings.Top.Close")
	end
	if v335 and v335:IsA("GuiButton") then
		local v369 = v335:Clone()
		v369.Name = "Later"
		v369:SetAttribute("Ui-Close", nil)
		v369.AnchorPoint = Vector2.new(0, 0.5)
		v369.Position = UDim2.fromScale(1.47, 0.5)
		v369.Size = UDim2.fromScale(0.12, 0.6)
		local v370 = Instance.new("UIAspectRatioConstraint")
		v370.AspectRatio = 1
		v370.Parent = v369
		v369.Activated:Connect(function()
			-- upvalues: (ref) v_u_22
			v_u_22.closeCall()
		end)
		v369.Parent = v362
	end
	v362.Parent = v341
	v_u_58 = v362
	local v371 = v340:Clone()
	v371.Name = "KuramaCard"
	v371.Visible = false
	v371.Position = UDim2.fromScale(0.5, 0.36)
	v371.Size = UDim2.fromScale(0.42, 0.1)
	local v372 = v371:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v372 then
		v372.AspectRatio = 5.2
	end
	v_u_67 = v_u_82(v371, "Main")
	v_u_68 = v_u_82(v371, "Sub")
	local v373 = Instance.new("UIScale")
	v373.Parent = v371
	v_u_69 = v373
	v371.Parent = v341
	v_u_66 = v371
	local v374 = v340:Clone()
	v374.Name = "KuramaCount"
	v374.Visible = false
	v374.AnchorPoint = Vector2.new(0.5, 0.5)
	v374.Position = UDim2.fromScale(0.5, 0.36)
	v374.Size = UDim2.fromScale(0.3, 0.22)
	local v375 = v374:FindFirstChildOfClass("UIAspectRatioConstraint")
	if v375 then
		v375.AspectRatio = 2.1
	end
	v_u_53 = v_u_82(v374, "Main")
	v_u_54 = v_u_82(v374, "Sub")
	for _, v376 in v_u_54 do
		v376.Size = UDim2.fromScale(v376.Size.X.Scale, 0.17)
	end
	local v377 = Instance.new("UIScale")
	v377.Parent = v374
	v_u_55 = v377
	v374.Parent = v341
	v_u_52 = v374
	return true
end
local function v_u_390(p379) -- name: placeCall
	-- upvalues: (ref) v_u_58, (ref) v_u_62
	local v380 = v_u_58
	local v381
	if v380 then
		v381 = v380.Parent
	else
		v381 = v380
	end
	if v380 and (v381 and v381:IsA("GuiObject")) then
		local v382 = v381.AbsoluteSize.Y
		if v382 >= 2 then
			local v383 = v_u_62
			local v384 = v380.AbsoluteSize.Y
			local v385 = not v383 and 1 or v383.Scale
			local v386 = v384 / math.max(v385, 0.05)
			local v387 = 0.165 * v382
			local v388 = p379 - v381.AbsolutePosition.Y + v386 / 2 + 8
			local v389 = math.max(v387, v388)
			v380.Position = UDim2.new(0.437, 0, 0, (math.floor(v389)))
		end
	else
		return
	end
end
local function v_u_429(p391, p392) -- name: placeBar
	-- upvalues: (ref) v_u_46, (ref) v_u_49, (ref) v_u_38, (ref) v_u_40, (copy) v_u_7, (copy) v_u_1, (ref) v_u_48, (ref) v_u_47, (copy) v_u_390
	local v393 = p391.Parent
	local v394 = v_u_46
	if v393 and (v393:IsA("GuiObject") and v394) then
		local v395 = v393.AbsoluteSize.X
		local v396 = v393.AbsoluteSize.Y
		if v395 >= 2 and v396 >= 2 then
			local v397 = v_u_49 and 0.7 or 0.62
			local v398 = v_u_49 and 0.5 or 0.4
			p391.Size = UDim2.fromScale(v397, v398)
			local v399 = v397 * v395
			local v400 = v398 * v396
			local v401 = 0
			for _, v402 in { v_u_38, v_u_40 } do
				if not (v402 and v402.Visible) then
					continue
				end
				local v403 = v402.Size.X.Scale * v399
				local v404 = v402.Size.Y.Scale * v400
				local v405 = v402:FindFirstChildOfClass("UIAspectRatioConstraint")
				if v405 and v405.AspectRatio > 0 then
					local v406 = v404 * v405.AspectRatio
					v403 = math.min(v403, v406)
				end
				if v402 == v_u_40 then
					v403 = v403 * 1.06
				end
				local v407 = v403 + v402.Position.X.Offset
				v401 = math.max(v401, v407)
			end
			local v408 = v_u_7.CurrentCamera
			local v409 = not v408 and 1280 or v408.ViewportSize.X
			local v410 = v393.AbsolutePosition.Y + (not p392 and 0 or 0.5 * v396)
			local v411 = v410 + v400 * 1.4
			local v412 = v_u_1.TopbarInset.Min.X + 8
			local v413 = v_u_48
			if v413 and v413.Visible then
				for _, v414 in v413:GetChildren() do
					if not v414:IsA("GuiObject") or (not v414.Visible or v414.AbsoluteSize.X <= 2) then
						continue
					end
					local v415 = v414.AbsolutePosition.Y
					if v415 >= v411 or v410 >= v415 + v414.AbsoluteSize.Y then
						continue
					end
					local v416 = v414.AbsolutePosition.X + v414.AbsoluteSize.X + 8
					v412 = math.max(v412, v416)
				end
			end
			local v417 = v409 - 12
			local v418 = v_u_47
			if v418 and (v418.Visible and v418.AbsoluteSize.X > 2) then
				local v419 = v418.AbsolutePosition.X - 14
				v417 = math.min(v417, v419)
			end
			local v420 = 1.4
			local v421 = v417 - v412
			if v421 < (v399 + v401) * v420 then
				local v422 = v421 / (v399 + v401)
				v420 = math.max(v422, 1)
			end
			local v423 = v393.AbsolutePosition.X + v395 / 2
			local v424 = v399 * v420 / 2
			local v425 = v423 + v424 + v401 * v420
			local v426 = v417 >= v425 and 0 or v417 - v425
			if v423 - v424 + v426 < v412 then
				v426 = v412 - (v423 - v424)
			end
			p391.Position = UDim2.new(0.5, math.floor(v426), p392 and 0.5 or 0, 0)
			v394.Scale = v420
			local v427 = v410 + v400 * v420
			if v418 and v418.Visible then
				local v428 = v418.AbsolutePosition.Y + v418.AbsoluteSize.Y
				v427 = math.max(v427, v428)
			end
			v_u_390(v427)
		end
	else
		return
	end
end
local function v_u_444(p430, p431, p432, p433) -- name: showCount
	-- upvalues: (ref) v_u_52, (copy) v_u_87, (ref) v_u_53, (ref) v_u_54, (copy) v_u_30, (ref) v_u_55, (copy) v_u_6
	local v434 = v_u_52
	if v434 then
		v_u_87(v_u_53, p430, p431)
		v_u_87(v_u_54, p432, v_u_30)
		local v435 = v_u_55
		local v436
		if v435 then
			local v437 = v435.Scale
			v436 = math.max(v437, 0.05)
		else
			v436 = 1
		end
		for _, v438 in v_u_53 do
			if #p430 <= 6 then
				v438.TextScaled = false
				local v439 = v438.AbsoluteSize.Y / v436
				local v440 = math.floor(v439)
				v438.TextSize = math.clamp(v440, 14, 100)
			else
				v438.TextScaled = true
			end
		end
		for _, v441 in v_u_54 do
			v441.Visible = p432 ~= ""
		end
		v434.Visible = true
		local v442 = v_u_55
		if v442 then
			v442.Scale = p433 * 1.6
			local v443 = Enum.EasingStyle.Back
			v_u_6:Create(v442, TweenInfo.new(0.3, v443 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = p433
			}):Play()
		end
	end
end
local function v_u_451(p445) -- name: stepCount
	-- upvalues: (ref) v_u_57, (copy) v_u_24, (copy) v_u_21, (ref) v_u_56, (ref) v_u_52, (copy) v_u_87, (ref) v_u_54, (copy) v_u_30, (copy) v_u_444, (copy) v_u_14
	if os.clock() < v_u_57 then
		return
	else
		local v446 = nil
		local v447 = ""
		local v448 = 1.5
		local v449 = v_u_24(255, 255, 255)
		if p445.inArena and not p445.ko then
			if (p445.phase == "coming" or p445.phase == "fight") and p445.countdown then
				v446 = p445.countdown
				if v446 == "FIGHT!" then
					v449 = v_u_24(255, 120, 40)
					v447 = "BEAT KYUBI!"
				else
					v447 = "KYUBI IS COMING..."
				end
			elseif p445.phase == "coming" then
				v449 = v_u_24(255, 150, 60)
				v447 = "KYUBI LANDS IN " .. v_u_21.clock(p445.nextAt - p445.now)
				v446 = "GET READY!"
				v448 = 0.8
			end
		end
		if v446 then
			if v446 == v_u_56 then
				if v446 == "GET READY!" then
					v_u_87(v_u_54, v447, v_u_30)
				end
				return
			else
				v_u_56 = v446
				v_u_444(v446, v449, v447, v448)
				if v446 == "FIGHT!" then
					v_u_14.play("StageStart", {
						["volume"] = 1.2
					})
				elseif v446 ~= "GET READY!" then
					v_u_14.play("RouletteTick", {
						["volume"] = 1.4,
						["pitch"] = nil,
						["pitch"] = v446 == "1" and 1.3 or 1
					})
				end
			end
		else
			if v_u_56 then
				v_u_56 = nil
				local v450 = v_u_52
				if v450 then
					v450.Visible = false
				end
			end
			return
		end
	end
end
local function v_u_461(p452, p453, p454, p455, p456) -- name: showCard
	-- upvalues: (ref) v_u_66, (ref) v_u_70, (copy) v_u_87, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_6
	local v_u_457 = v_u_66
	if v_u_457 then
		v_u_70 = v_u_70 + 1
		local v_u_458 = v_u_70
		v_u_87(v_u_67, p452, p453)
		v_u_87(v_u_68, p454, p455)
		v_u_457.Visible = true
		local v459 = v_u_69
		if v459 then
			v459.Scale = 0.2
			local v460 = Enum.EasingStyle.Back
			v_u_6:Create(v459, TweenInfo.new(0.35, v460 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
		if p456 then
			task.delay(p456, function()
				-- upvalues: (copy) v_u_458, (ref) v_u_70, (copy) v_u_457
				if v_u_458 == v_u_70 then
					v_u_457.Visible = false
				end
			end)
		end
	end
end
function v_u_22.closeCall() -- name: closeCall
	-- upvalues: (ref) v_u_63, (ref) v_u_58, (ref) v_u_65, (ref) v_u_61, (copy) v_u_1, (copy) v_u_9
	v_u_63 = false
	local v462 = v_u_58
	if v462 then
		v462.Visible = false
	end
	local v463 = v_u_65
	v_u_65 = nil
	if v463 then
		v463()
	end
	local v464 = v_u_61
	if v464 and v_u_1.SelectedObject == v464 then
		v_u_9.clear()
	end
end
local function v_u_470(p465, p466) -- name: openCall
	-- upvalues: (ref) v_u_58, (ref) v_u_63, (ref) v_u_64, (copy) v_u_87, (ref) v_u_59, (copy) v_u_24, (ref) v_u_60, (copy) v_u_30, (ref) v_u_62, (copy) v_u_6, (copy) v_u_14, (ref) v_u_65, (copy) v_u_9, (copy) v_u_22, (ref) v_u_61
	local v467 = v_u_58
	if v467 and not p465.inArena then
		v_u_63 = true
		v_u_64 = p465.nextAt
		v_u_87(v_u_59, "KYUBI IS COMING!", v_u_24(255, 150, 60))
		v_u_87(v_u_60, not p466 and "JOIN THE FIGHT!" or string.upper(p466) .. " SUMMONED HIM!", v_u_30)
		v467.Visible = true
		local v468 = v_u_62
		if v468 then
			v468.Scale = 0.2
			local v469 = Enum.EasingStyle.Back
			v_u_6:Create(v468, TweenInfo.new(0.35, v469 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
		v_u_14.play("BossAppear", {
			["volume"] = 0.7
		})
		if v_u_65 == nil then
			v_u_65 = v_u_9.onBack(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_22
				if not v_u_63 then
					return false
				end
				v_u_22.closeCall()
				return true
			end, 5)
		end
		v_u_9.selectSoon(function()
			-- upvalues: (ref) v_u_63, (ref) v_u_61
			if v_u_63 then
				return v_u_61
			else
				return nil
			end
		end, true)
	end
end
function v_u_22.step(p471) -- name: step
	-- upvalues: (ref) v_u_73, (ref) v_u_32, (ref) v_u_35, (ref) v_u_36, (ref) v_u_38, (copy) v_u_23, (copy) v_u_16, (ref) v_u_49, (copy) v_u_21, (copy) v_u_26, (ref) v_u_33, (ref) v_u_34, (ref) v_u_40, (ref) v_u_44, (ref) v_u_41, (ref) v_u_42, (copy) v_u_27, (copy) v_u_17, (copy) v_u_25, (ref) v_u_43, (copy) v_u_24, (copy) v_u_28, (ref) v_u_39, (copy) v_u_15, (ref) v_u_51, (ref) v_u_50, (copy) v_u_5, (ref) v_u_45, (copy) v_u_429, (ref) v_u_37, (copy) v_u_29, (copy) v_u_451, (copy) v_u_334, (ref) v_u_63, (copy) v_u_88, (copy) v_u_22, (ref) v_u_64, (copy) v_u_87, (ref) v_u_59, (ref) v_u_72, (ref) v_u_60, (copy) v_u_30, (copy) v_u_470, (ref) v_u_71, (ref) v_u_68
	v_u_73 = p471
	local v472 = v_u_32
	if v472 then
		v472.Visible = true
		local v473 = v_u_35
		local v474 = v_u_36
		local v475 = v_u_38
		if v475 then
			v475.Visible = false
		end
		if v474 then
			v474.Visible = false
		end
		local v476 = p471.phase == "fight"
		local v477 = (v476 or p471.phase == "coming") and not (p471.inArena or p471.running)
		if v477 then
			if v_u_23:GetAttribute("TutorialDone") == true then
				v477 = not v_u_16.active()
			else
				v477 = false
			end
		end
		local v478
		if v476 then
			v478 = p471.inArena
		else
			v478 = v476
		end
		v_u_49 = v478
		if v476 and p471.inArena then
			if v473 then
				local v479 = string.format
				local v480 = p471.hp * 100
				v473.Text = v479("KYUBI  %d%%   %s", math.ceil(v480), v_u_21.clock(p471.ends - p471.now))
			end
			local v481 = p471.hp
			local v482 = v_u_26
			local v483 = v_u_33
			if v483 then
				v483.Size = UDim2.fromScale(math.clamp(v481, 0, 1), 1)
				v483.Visible = v481 > 0.002
			end
			local v484 = v_u_34
			if v484 then
				v484.Color = v482
			end
			local v485 = v_u_40
			if v485 then
				v_u_44 = "leave"
				v485.Visible = true
				local v486 = v_u_41
				if v486 then
					v486.Text = "LEAVE"
				end
				local v487 = v_u_42
				if v487 then
					v487.Color = v_u_27
				end
			end
		elseif v476 or p471.phase == "coming" then
			if v473 then
				v473.Text = v476 and "KYUBI IS HERE!" or "KYUBI IN " .. v_u_21.clock(p471.nextAt - p471.now)
			end
			local v488
			if v476 then
				v488 = p471.hp
			else
				v488 = 1 - (p471.nextAt - p471.now) / v_u_17.WARN
			end
			local v489
			if v476 then
				v489 = v_u_26
			else
				v489 = v_u_25
			end
			local v490 = v_u_33
			if v490 then
				v490.Size = UDim2.fromScale(math.clamp(v488, 0, 1), 1)
				v490.Visible = v488 > 0.002
			end
			local v491 = v_u_34
			if v491 then
				v491.Color = v489
			end
			local v492 = p471.inArena and "leave" or (v477 and "join" or nil)
			local v493 = v_u_40
			if v493 then
				if v492 then
					v_u_44 = v492
					v493.Visible = true
					local v494 = v_u_41
					if v494 then
						v494.Text = v492 == "join" and "JOIN" or "LEAVE"
					end
					local v495 = v_u_42
					if v495 then
						local v496
						if v492 == "join" then
							v496 = v_u_43 or v495.Color
						else
							v496 = v_u_27
						end
						v495.Color = v496
					end
				else
					v493.Visible = false
				end
			end
		elseif p471.phase == "over" then
			local v497 = p471.won and p471.inArena
			if v497 then
				v497 = p471.overUntil > p471.now
			end
			if v473 then
				local v498
				if v497 then
					v498 = "PORTAL HOME " .. v_u_21.clock(p471.overUntil - p471.now)
				else
					v498 = "KYUBI IN " .. v_u_21.clock(p471.nextAt - p471.now)
				end
				v473.Text = v498
			end
			if v497 then
				local v499 = p471.overUntil - p471.now
				local v500 = v_u_21.EXIT_OPEN
				local v501 = v499 / math.max(v500, 1)
				local v502 = ColorSequence.new(v_u_24(255, 230, 120), v_u_28)
				local v503 = v_u_33
				if v503 then
					v503.Size = UDim2.fromScale(math.clamp(v501, 0, 1), 1)
					v503.Visible = v501 > 0.002
				end
				local v504 = v_u_34
				if v504 then
					v504.Color = v502
				end
			else
				local v505 = v_u_25
				local v506 = v_u_33
				if v506 then
					v506.Size = UDim2.fromScale(0, 1)
					v506.Visible = false
				end
				local v507 = v_u_34
				if v507 then
					v507.Color = v505
				end
			end
			local v508 = p471.inArena and "leave" or nil
			local v509 = v_u_40
			if v509 then
				if v508 then
					v_u_44 = v508
					v509.Visible = true
					local v510 = v_u_41
					if v510 then
						v510.Text = v508 == "join" and "JOIN" or "LEAVE"
					end
					local v511 = v_u_42
					if v511 then
						local v512
						if v508 == "join" then
							v512 = v_u_43 or v511.Color
						else
							v512 = v_u_27
						end
						v511.Color = v512
					end
				else
					v509.Visible = false
				end
			end
		else
			local v513 = p471.nextAt - p471.now
			if v473 then
				v473.Text = "KYUBI IN " .. v_u_21.clock(v513)
			end
			local v514 = 1 - v513 / v_u_17.EVERY
			local v515 = v_u_25
			local v516 = v_u_33
			if v516 then
				v516.Size = UDim2.fromScale(math.clamp(v514, 0, 1), 1)
				v516.Visible = v514 > 0.002
			end
			local v517 = v_u_34
			if v517 then
				v517.Color = v515
			end
			if p471.inArena then
				local v518 = v_u_40
				if v518 then
					v_u_44 = "leave"
					v518.Visible = true
					local v519 = v_u_41
					if v519 then
						v519.Text = "LEAVE"
					end
					local v520 = v_u_42
					if v520 then
						v520.Color = v_u_27
					end
				end
			else
				local v521 = v_u_40
				if v521 then
					v521.Visible = false
				end
				if v475 then
					v475.Visible = true
					local v522 = v_u_39
					local v523 = v_u_15.product(v_u_17.SKIP_PRODUCT)
					if v522 and v523 then
						v522.Text = "SKIP " .. v_u_15.priceText(v523.price)
					end
				end
			end
		end
		local v524 = v_u_40
		local v525 = v524 ~= nil and v524.Visible
		if v525 then
			v525 = v_u_44 == "join"
		end
		if v525 ~= v_u_51 then
			v_u_51 = v525
			if v525 then
				task.spawn(function()
					-- upvalues: (ref) v_u_51, (ref) v_u_50, (ref) v_u_5
					while v_u_51 do
						local v526 = v_u_50
						if v526 then
							local v527 = os.clock() % 0.9 / 0.9
							local v528 = v527 * 3.141592653589793 * 2.2
							local v529 = math.sin(v528)
							v526.Scale = 1 + math.max(0, v529) * 0.12 * (1 - v527)
						end
						v_u_5.RenderStepped:Wait()
					end
				end)
			else
				local v530 = v_u_50
				if v530 then
					v530.Scale = 1
				end
			end
		end
		local v531 = v_u_45
		local v532 = v_u_429
		local v533
		if v531 == nil then
			v533 = false
		else
			v533 = v531.Visible
		end
		v532(v472, v533)
		local v534 = v_u_37
		if v534 then
			if v476 and p471.inArena then
				v534.Visible = p471.enraged
				v534.Text = "ENRAGED!"
				v534.TextColor3 = v_u_29
			else
				v534.Visible = true
				v534.Text = "KYUBI"
				v534.TextColor3 = v_u_24(255, 150, 60)
			end
		end
		v_u_451(p471)
		v_u_334(p471)
		if p471.phase == "coming" or v476 then
			v476 = not p471.inArena
		end
		if v_u_63 then
			if v476 and not v_u_88() then
				local v535 = p471.nextAt - p471.now
				if p471.phase == "coming" then
					v_u_87(v_u_59, "KYUBI IN " .. v_u_21.clock(v535) .. "!", v_u_24(255, 150, 60))
					if v_u_72 then
						v_u_87(v_u_60, string.upper(v_u_72) .. " SUMMONED HIM!", v_u_30)
					elseif p471.fighters > 0 then
						v_u_87(v_u_60, p471.fighters .. " READY, JOIN THE FIGHT!", v_u_30)
					end
				else
					v_u_87(v_u_59, "KYUBI IS HERE!", v_u_29)
					v_u_87(v_u_60, p471.fighters .. " FIGHTING HIM, JOIN NOW!", v_u_30)
				end
			else
				v_u_22.closeCall()
				if v476 then
					v_u_64 = -1
				end
			end
		elseif v476 and (v_u_64 ~= p471.nextAt and (not v_u_88() and (p471.phase == "coming" or p471.now < p471.arrivedAt + v_u_17.FIGHT_SECONDS / 2))) then
			v_u_470(p471, nil)
		end
		if p471.ko then
			local v536 = v_u_71 - p471.now
			local v537 = math.max(0, v536)
			v_u_87(v_u_68, "BACK IN " .. math.ceil(v537), v_u_30)
		end
	end
end
function v_u_22.summoned(p_u_538) -- name: summoned
	-- upvalues: (copy) v_u_11, (copy) v_u_24, (ref) v_u_72, (copy) v_u_21, (ref) v_u_73, (copy) v_u_88, (ref) v_u_64, (copy) v_u_470
	v_u_11.notify(p_u_538 .. " summoned Kyubi!", v_u_24(235, 96, 14))
	v_u_72 = p_u_538
	task.delay(v_u_21.SKIP_WARN + 2, function()
		-- upvalues: (ref) v_u_72, (copy) p_u_538
		if v_u_72 == p_u_538 then
			v_u_72 = nil
		end
	end)
	local v539 = v_u_73
	if v539 and not (v539.inArena or v_u_88()) then
		v_u_64 = -1
		v_u_470(v539, p_u_538)
	end
end
function v_u_22.knockedOut(p540) -- name: knockedOut
	-- upvalues: (ref) v_u_71, (copy) v_u_29, (copy) v_u_17, (copy) v_u_30, (ref) v_u_66, (ref) v_u_70, (copy) v_u_87, (ref) v_u_67, (ref) v_u_68, (ref) v_u_69, (copy) v_u_6, (copy) v_u_14
	v_u_71 = p540
	local v541 = v_u_29
	local v542 = "BACK IN " .. v_u_17.RESPAWN
	local v543 = v_u_30
	local v544 = v_u_66
	if v544 then
		v_u_70 = v_u_70 + 1
		v_u_87(v_u_67, "KNOCKED OUT!", v541)
		v_u_87(v_u_68, v542, v543)
		v544.Visible = true
		local v545 = v_u_69
		if v545 then
			v545.Scale = 0.2
			local v546 = Enum.EasingStyle.Back
			v_u_6:Create(v545, TweenInfo.new(0.35, v546 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
		end
	end
	v_u_14.play("Death", {
		["volume"] = 0.8
	})
end
function v_u_22.up() -- name: up
	-- upvalues: (ref) v_u_70, (ref) v_u_66
	v_u_70 = v_u_70 + 1
	local v547 = v_u_66
	if v547 then
		v547.Visible = false
	end
end
local v_u_548 = nil
function v_u_22.hurt(p549) -- name: hurt
	-- upvalues: (ref) v_u_548, (copy) v_u_24, (copy) v_u_23, (copy) v_u_6
	local v550 = v_u_548
	if not v550 then
		local v551 = Instance.new("ScreenGui")
		v551.Name = "KuramaHurt"
		v551.IgnoreGuiInset = true
		v551.DisplayOrder = -1
		v551.ResetOnSpawn = false
		v550 = Instance.new("Frame")
		v550.Size = UDim2.fromScale(1, 1)
		v550.BackgroundTransparency = 1
		v550.BorderSizePixel = 0
		v550.BackgroundColor3 = v_u_24(200, 20, 20)
		local v552 = Instance.new("UIGradient")
		v552.Transparency = NumberSequence.new({
			NumberSequenceKeypoint.new(0, 0),
			NumberSequenceKeypoint.new(0.22, 0.85),
			NumberSequenceKeypoint.new(0.78, 0.85),
			NumberSequenceKeypoint.new(1, 0)
		})
		v552.Parent = v550
		v550.Parent = v551
		v551.Parent = v_u_23:WaitForChild("PlayerGui")
		v_u_548 = v550
	end
	if v550 then
		v550.BackgroundTransparency = p549 and 0.2 or 0.45
		v_u_6:Create(v550, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["BackgroundTransparency"] = 1
		}):Play()
	end
end
function v_u_22.enraged() -- name: enraged
	-- upvalues: (ref) v_u_73, (ref) v_u_57, (ref) v_u_56, (copy) v_u_444, (copy) v_u_29, (ref) v_u_52
	local v553 = v_u_73
	if v553 and v553.inArena then
		v_u_57 = os.clock() + 2.2
		v_u_56 = "ENRAGED!"
		v_u_444("KYUBI IS ENRAGED!", v_u_29, "HE ATTACKS FASTER!", 1.1)
		task.delay(2.2, function()
			-- upvalues: (ref) v_u_56, (ref) v_u_52
			if v_u_56 == "ENRAGED!" then
				v_u_56 = nil
				local v554 = v_u_52
				if v554 then
					v554.Visible = false
				end
			end
		end)
	end
end
function v_u_22.result(p555, p556, p557, p558, p559) -- name: result
	-- upvalues: (ref) v_u_56, (ref) v_u_52, (copy) v_u_461, (copy) v_u_28, (copy) v_u_24, (copy) v_u_14, (copy) v_u_30, (copy) v_u_29
	v_u_56 = nil
	local v560 = v_u_52
	if v560 then
		v560.Visible = false
	end
	if p555 and p556 > 0 then
		local v561
		if p559 then
			local v562 = string.format
			local v563 = p559 * 100 + 0.5
			local v564 = math.floor(v563)
			v561 = v562(" - %d%% OF THE DAMAGE", (math.clamp(v564, 1, 100)))
		else
			v561 = p558 < 0.999 and " (JOINED LATE)" or ""
		end
		v_u_461("KYUBI DEFEATED!", v_u_28, "+" .. p556 .. " KYUBI COINS" .. v561, v_u_24(255, 214, 64), 5)
		v_u_14.play("RevealBig")
		task.delay(0.4, function()
			-- upvalues: (ref) v_u_14
			v_u_14.play("Coin", {
				["volume"] = 1.2
			})
		end)
		return
	elseif p555 then
		v_u_461("KYUBI DEFEATED!", v_u_28, p557 and "" or "HIT HIM MORE TO EARN COINS", v_u_30, 5)
		v_u_14.play("WaveClear")
	else
		v_u_461("KYUBI ESCAPED!", v_u_29, "BEAT HIM IN TIME FOR COINS", v_u_30, 5)
		v_u_14.play("Error")
	end
end
function v_u_22.say(p565) -- name: say
	-- upvalues: (copy) v_u_11
	v_u_11.notify(p565)
end
function v_u_22.start(p566) -- name: start
	-- upvalues: (ref) v_u_31, (ref) v_u_32, (copy) v_u_378, (copy) v_u_9, (ref) v_u_40, (ref) v_u_44
	v_u_31 = p566
	if v_u_32 then
		return true
	end
	local v567 = v_u_378()
	if v567 then
		v_u_9.onEnter(function(p568)
			-- upvalues: (ref) v_u_40, (ref) v_u_9, (ref) v_u_44
			local v569 = v_u_40
			if p568 ~= Enum.KeyCode.DPadUp or (v_u_9.captured() or (not v569 or (v_u_44 ~= "join" or not v_u_9.shown(v569)))) then
				return false
			end
			v_u_9.select(v569)
			return v_u_9.selected() == v569
		end, 5)
	end
	return v567
end
function v_u_22.hide() -- name: hide
	-- upvalues: (ref) v_u_32, (ref) v_u_97, (ref) v_u_114, (copy) v_u_22, (ref) v_u_70, (ref) v_u_66, (ref) v_u_56, (ref) v_u_52, (ref) v_u_40, (ref) v_u_44, (ref) v_u_51, (ref) v_u_50, (copy) v_u_5
	local v570 = v_u_32
	if v570 then
		v570.Visible = false
	end
	local v571 = v_u_97
	if v571 then
		v571.Enabled = false
	end
	if v_u_114 then
		v_u_114:Disconnect()
		v_u_114 = nil
	end
	v_u_22.closeCall()
	v_u_70 = v_u_70 + 1
	local v572 = v_u_66
	if v572 then
		v572.Visible = false
	end
	v_u_56 = nil
	local v573 = v_u_52
	if v573 then
		v573.Visible = false
	end
	local v574 = v_u_40
	if v574 then
		v574.Visible = false
	end
	local v575 = v_u_40
	local v576 = v575 ~= nil and v575.Visible
	if v576 then
		v576 = v_u_44 == "join"
	end
	if v576 ~= v_u_51 then
		v_u_51 = v576
		if v576 then
			task.spawn(function()
				-- upvalues: (ref) v_u_51, (ref) v_u_50, (ref) v_u_5
				while v_u_51 do
					local v577 = v_u_50
					if v577 then
						local v578 = os.clock() % 0.9 / 0.9
						local v579 = v578 * 3.141592653589793 * 2.2
						local v580 = math.sin(v579)
						v577.Scale = 1 + math.max(0, v580) * 0.12 * (1 - v578)
					end
					v_u_5.RenderStepped:Wait()
				end
			end)
		else
			local v581 = v_u_50
			if v581 then
				v581.Scale = 1
				return
			end
		end
	end
end
return v_u_22