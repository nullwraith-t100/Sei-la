local v_u_1 = game:GetService("GuiService")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(script.Parent.Gamepad)
local v_u_6 = require(script.Parent.Sfx)
local v7 = {}
local v_u_8 = {}
setmetatable(v_u_8, {
	["__mode"] = "k"
})
local v_u_9 = {}
local v_u_10 = {}
local function v_u_11(_) end
local function v_u_12() end
function v7.onFrame(p13) -- name: onFrame
	-- upvalues: (ref) v_u_11
	v_u_11 = p13
end
function v7.onClose(p14) -- name: onClose
	-- upvalues: (ref) v_u_12
	v_u_12 = p14
end
local function v_u_20(p15, p_u_16) -- name: hover
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	local v_u_17 = p15:FindFirstChild("Pop")
	if not (v_u_17 and v_u_17:IsA("UIScale")) then
		v_u_17 = Instance.new("UIScale")
		v_u_17.Name = "Pop"
		v_u_17.Parent = p15
	end
	p15.MouseEnter:Connect(function()
		-- upvalues: (copy) v_u_17, (copy) p_u_16, (ref) v_u_4
		local v18 = {
			["Scale"] = p_u_16
		}
		v_u_4:Create(v_u_17, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v18):Play()
	end)
	p15.MouseLeave:Connect(function()
		-- upvalues: (copy) v_u_17, (ref) v_u_4
		v_u_4:Create(v_u_17, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end)
	p15.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_5, (copy) v_u_17, (copy) p_u_16, (ref) v_u_4
		if v_u_5.quiet() then
			v_u_17.Scale = p_u_16
		else
			local v19 = {
				["Scale"] = p_u_16
			}
			v_u_4:Create(v_u_17, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v19):Play()
		end
	end)
	p15.SelectionLost:Connect(function()
		-- upvalues: (copy) v_u_17, (ref) v_u_4
		v_u_4:Create(v_u_17, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
	end)
end
local function v_u_23(p21) -- name: menuOf
	while p21 and p21.Parent do
		local v22 = p21.Parent
		if v22.Name == "Frames" and (v22.Parent and v22.Parent.Name == "Main") then
			if p21:IsA("GuiObject") then
				return p21
			else
				return nil
			end
		end
		p21 = v22
	end
	return nil
end
local function v_u_27(p24, p_u_25) -- name: playWhileShown
	-- upvalues: (copy) v_u_23
	local v_u_26 = v_u_23(p24)
	if v_u_26 then
		v_u_26:GetPropertyChangedSignal("Visible"):Connect(function() -- name: sync
			-- upvalues: (copy) v_u_26, (copy) p_u_25
			if v_u_26.Visible then
				p_u_25:Play()
			else
				p_u_25:Pause()
			end
		end)
		if v_u_26.Visible then
			p_u_25:Play()
		else
			p_u_25:Pause()
		end
	else
		p_u_25:Play()
		return
	end
end
local v_u_28 = {}
local v_u_29 = {}
local function v_u_33(p30, p31) -- name: shake
	-- upvalues: (copy) v_u_27, (copy) v_u_4
	local v32 = (math.abs(p31) - 1) * 90
	p30.Rotation = -v32
	v_u_27(p30, v_u_4:Create(p30, TweenInfo.new(1, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true), {
		["Rotation"] = v32
	}))
end
local function v_u_37(p34, p35) -- name: shine
	-- upvalues: (copy) v_u_27, (copy) v_u_4
	local v36 = Instance.new("ImageLabel")
	v36.Name = "Shine"
	v36.BackgroundTransparency = 1
	v36.Image = "rbxassetid://71904840558679"
	v36.Size = UDim2.fromScale(3, 3)
	v36.AnchorPoint = Vector2.new(1, 0.5)
	v36.Position = UDim2.fromScale(0, 0.5)
	v36.ZIndex = p34.ZIndex + 1
	Instance.new("UIAspectRatioConstraint").Parent = v36
	v36.Parent = p34
	v_u_27(p34, v_u_4:Create(v36, TweenInfo.new(math.max(p35, 0.5), Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, -1, true, 5), {
		["Position"] = UDim2.fromScale(1, 0.5),
		["AnchorPoint"] = Vector2.new(0, 0.5)
	}))
end
local function v_u_44(p_u_38, p_u_39) -- name: tileScale
	local v_u_40 = p_u_38.Parent
	if v_u_40 and v_u_40:IsA("GuiObject") then
		v_u_40:GetPropertyChangedSignal("AbsoluteSize"):Connect(function() -- name: update
			-- upvalues: (copy) v_u_40, (copy) p_u_39, (copy) p_u_38
			local v41 = p_u_39
			local v42 = v_u_40.AbsoluteSize.X / math.max(v41, 0.1)
			if v42 >= 1 then
				p_u_38.TileSize = UDim2.fromOffset(v42, v42)
			end
		end)
		local v43 = v_u_40.AbsoluteSize.X / math.max(p_u_39, 0.1)
		if v43 >= 1 then
			p_u_38.TileSize = UDim2.fromOffset(v43, v43)
		end
	end
end
local function v_u_51(p_u_45, p46) -- name: shadow
	local v_u_47 = p_u_45.Parent
	if v_u_47 then
		v_u_47 = v_u_47:FindFirstChild(p46)
	end
	if v_u_47 and v_u_47:IsA("TextLabel") then
		local v_u_48 = p_u_45.Position - v_u_47.Position
		p_u_45.Text = v_u_47.Text
		p_u_45.Visible = v_u_47.Visible
		p_u_45.TextTransparency = v_u_47.TextTransparency
		p_u_45.Position = v_u_47.Position + v_u_48
		local function v49() -- name: sync
			-- upvalues: (copy) p_u_45, (copy) v_u_47, (copy) v_u_48
			p_u_45.Text = v_u_47.Text
			p_u_45.Visible = v_u_47.Visible
			p_u_45.TextTransparency = v_u_47.TextTransparency
			p_u_45.Position = v_u_47.Position + v_u_48
		end
		for _, v50 in {
			"Text",
			"Visible",
			"TextTransparency",
			"Position"
		} do
			v_u_47:GetPropertyChangedSignal(v50):Connect(v49)
		end
	end
end
local function v_u_84(p_u_52) -- name: setup
	-- upvalues: (copy) v_u_8, (copy) v_u_20, (copy) v_u_5, (copy) v_u_1, (copy) v_u_4, (copy) v_u_6, (ref) v_u_11, (ref) v_u_12, (copy) v_u_9, (copy) v_u_33, (copy) v_u_27, (copy) v_u_37, (copy) v_u_10, (copy) v_u_44, (copy) v_u_51
	if not v_u_8[p_u_52] and p_u_52:IsA("GuiObject") then
		local v53 = p_u_52.Parent
		while v53 do
			if v53.Name == "Templates" then
				return
			end
			v53 = v53.Parent
		end
		v_u_8[p_u_52] = true
		if p_u_52:GetAttribute("Ui-Hover") == "Expand" then
			local v54 = v_u_20
			local v55 = p_u_52:GetAttribute("Ui-Hover-Rate")
			v54(p_u_52, type(v55) ~= "number" and 1.08 or v55)
		end
		if p_u_52:IsA("GuiButton") then
			p_u_52.Selectable = v_u_5.actionable(p_u_52)
			if p_u_52:GetAttribute("Ui-Click") == "In" then
				local v56 = p_u_52:GetAttribute("Ui-Click-Rate")
				local v_u_57 = type(v56) ~= "number" and 0.9 or v56
				local v_u_58 = p_u_52:FindFirstChild("Pop")
				if not (v_u_58 and v_u_58:IsA("UIScale")) then
					v_u_58 = Instance.new("UIScale")
					v_u_58.Name = "Pop"
					v_u_58.Parent = p_u_52
				end
				p_u_52.Activated:Connect(function()
					-- upvalues: (copy) p_u_52, (ref) v_u_1, (copy) v_u_58, (copy) v_u_57, (ref) v_u_4
					local v_u_59
					if p_u_52.GuiState == Enum.GuiState.Hover or v_u_1.SelectedObject == p_u_52 then
						local v60 = p_u_52:GetAttribute("Ui-Hover-Rate")
						v_u_59 = type(v60) ~= "number" and 1 or v60
					else
						v_u_59 = 1
					end
					local v61 = {
						["Scale"] = v_u_57
					}
					v_u_4:Create(v_u_58, TweenInfo.new(0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v61):Play()
					task.delay(0.1, function()
						-- upvalues: (ref) v_u_58, (copy) v_u_59, (ref) v_u_4
						local v62 = v_u_58
						local v63 = {
							["Scale"] = v_u_59
						}
						local v64 = Enum.EasingStyle.Bounce
						v_u_4:Create(v62, TweenInfo.new(0.2, v64 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v63):Play()
					end)
				end)
			end
			p_u_52.MouseEnter:Connect(function()
				-- upvalues: (copy) p_u_52, (ref) v_u_6
				if p_u_52.Visible and p_u_52.Active then
					v_u_6.play("Hover")
				end
			end)
			p_u_52.Activated:Connect(function()
				-- upvalues: (ref) v_u_6
				v_u_6.play("Click")
			end)
			local v_u_65 = p_u_52:GetAttribute("Ui-Frame")
			if type(v_u_65) == "string" then
				p_u_52.Activated:Connect(function()
					-- upvalues: (ref) v_u_11, (copy) v_u_65
					v_u_11(v_u_65)
				end)
			end
			if p_u_52:GetAttribute("Ui-Close") == true then
				p_u_52.Activated:Connect(function()
					-- upvalues: (ref) v_u_12
					v_u_12()
				end)
			end
		end
		local v66 = p_u_52:GetAttribute("Ui-Effect")
		if v66 == "Spin" then
			v_u_9[p_u_52] = 5
		elseif v66 == "Shake" then
			local v67 = v_u_33
			local v68 = p_u_52:GetAttribute("Ui-Effect-Rate")
			v67(p_u_52, type(v68) ~= "number" and 1.1 or v68)
		elseif v66 == "Float" then
			local v69 = p_u_52:GetAttribute("Ui-Effect-Rate")
			local v_u_70 = type(v69) ~= "number" and 6 or v69
			local v71 = p_u_52:GetAttribute("Ui-Effect-Speed")
			local v_u_72 = type(v71) ~= "number" and 2 or v71
			local v73 = p_u_52:GetAttribute("Ui-Effect-Delay")
			local v74 = type(v73) ~= "number" and 0 or v73
			local v_u_75 = p_u_52.Position
			task.delay(v74, function()
				-- upvalues: (copy) p_u_52, (ref) v_u_27, (ref) v_u_4, (copy) v_u_72, (copy) v_u_75, (copy) v_u_70
				if p_u_52.Parent then
					v_u_27(p_u_52, v_u_4:Create(p_u_52, TweenInfo.new(v_u_72, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
						["Position"] = v_u_75 + UDim2.fromOffset(0, v_u_70)
					}))
				end
			end)
		elseif v66 == "Shine" then
			local v76 = v_u_37
			local v77 = p_u_52:GetAttribute("Ui-Effect-Rate")
			v76(p_u_52, type(v77) ~= "number" and 1 or v77)
		elseif (v66 == "Bg_X" or v66 == "Bg_Y") and p_u_52:IsA("ImageLabel") then
			local v78 = v_u_10
			local v79 = {
				["item"] = p_u_52,
				["origin"] = p_u_52.Position,
				["size"] = p_u_52.Size,
				["axis"] = v66 == "Bg_X" and "X" or "Y"
			}
			local v80 = p_u_52:GetAttribute("Ui-Effect-Rate")
			v79.rate = type(v80) ~= "number" and 4 or v80
			table.insert(v78, v79)
		end
		if p_u_52:GetAttribute("Ui-Scale") == "ImageTileScale" and p_u_52:IsA("ImageLabel") then
			local v81 = v_u_44
			local v82 = p_u_52:GetAttribute("Ui-Scale-Rate")
			v81(p_u_52, type(v82) ~= "number" and 4 or v82)
		end
		local v83 = p_u_52:GetAttribute("ShadowOf")
		if type(v83) == "string" and p_u_52:IsA("TextLabel") then
			v_u_51(p_u_52, v83)
		end
	end
end
function v7.setText(p85, p86) -- name: setText
	for _, v87 in p85:GetChildren() do
		if not v87:IsA("TextLabel") then
			continue
		end
		v87.Text = p86
	end
end
local v_u_88 = {
	["Common"] = ColorSequence.new(Color3.fromRGB(150, 160, 175), Color3.fromRGB(95, 104, 118)),
	["Rare"] = ColorSequence.new(Color3.fromRGB(0, 170, 255), Color3.fromRGB(69, 190, 255)),
	["Epic"] = ColorSequence.new(Color3.fromRGB(150, 60, 255), Color3.fromRGB(205, 110, 255)),
	["Legendary"] = ColorSequence.new(Color3.fromRGB(255, 225, 0), Color3.fromRGB(255, 110, 6)),
	["Mythic"] = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 0, 0)),
		ColorSequenceKeypoint.new(0.25, Color3.fromRGB(255, 255, 0)),
		ColorSequenceKeypoint.new(0.5, Color3.fromRGB(48, 255, 25)),
		ColorSequenceKeypoint.new(0.77, Color3.fromRGB(31, 128, 202)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(166, 23, 255))
	}),
	["Locked"] = ColorSequence.new(Color3.fromRGB(90, 92, 100), Color3.fromRGB(50, 51, 58))
}
function v7.paint(p89, p90) -- name: paint
	-- upvalues: (copy) v_u_88
	local v91 = p89:FindFirstChild("Paint")
	local v92 = v_u_88[p90]
	if v91 and (v91:IsA("UIGradient") and v92) then
		v91.Color = v92
		v91.Rotation = p90 == "Mythic" and -25 or -85
	end
end
function v7.start() -- name: start
	-- upvalues: (copy) v_u_2, (copy) v_u_84, (copy) v_u_3, (copy) v_u_9, (copy) v_u_29, (copy) v_u_28, (copy) v_u_23, (copy) v_u_10
	local v93 = v_u_2.LocalPlayer:WaitForChild("PlayerGui")
	local v_u_94 = {}
	local function v_u_98(p95) -- name: attach
		-- upvalues: (copy) v_u_94, (ref) v_u_84
		if not v_u_94[p95] then
			v_u_94[p95] = true
			p95.DescendantAdded:Connect(function(p96)
				-- upvalues: (ref) v_u_84
				task.defer(v_u_84, p96)
			end)
			for _, v97 in p95:GetDescendants() do
				v_u_84(v97)
			end
		end
	end
	local v99 = v93:FindFirstChild("Main")
	if v99 then
		v_u_98(v99)
	end
	v93.ChildAdded:Connect(function(p100)
		-- upvalues: (copy) v_u_98
		if p100.Name == "Main" then
			v_u_98(p100)
		end
	end)
	v_u_3.RenderStepped:Connect(function(p101)
		-- upvalues: (ref) v_u_9, (ref) v_u_29, (ref) v_u_28, (ref) v_u_23, (ref) v_u_10
		for v102, v103 in v_u_9 do
			if v102.Parent then
				local v104
				if v_u_29[v102] then
					v104 = true
					if not v104 then
						continue
					end
					v102.Rotation = (v102.Rotation + 360 * p101 / v103) % 360
				else
					local v105 = v_u_28[v102]
					if v105 then
						v104 = v105.Visible
						if not v104 then
							continue
						end
						v102.Rotation = (v102.Rotation + 360 * p101 / v103) % 360
					else
						v105 = v_u_23(v102)
						if v105 then
							v_u_28[v102] = v105
							v104 = v105.Visible
							if not v104 then
								continue
							end
							v102.Rotation = (v102.Rotation + 360 * p101 / v103) % 360
						else
							v_u_29[v102] = true
							v104 = true
							if not v104 then
								continue
							end
							v102.Rotation = (v102.Rotation + 360 * p101 / v103) % 360
						end
					end
				end
			else
				v_u_9[v102] = nil
			end
		end
		local v106 = workspace:GetServerTimeNow()
		for _, v107 in v_u_10 do
			local v108 = v107.item
			if not v108.Parent then
				continue
			end
			local v109
			if v_u_29[v108] then
				v109 = true
			else
				local v110 = v_u_28[v108]
				if v110 then
					v109 = v110.Visible
				else
					v110 = v_u_23(v108)
					if v110 then
						v_u_28[v108] = v110
						v109 = v110.Visible
					else
						v_u_29[v108] = true
						v109 = true
					end
				end
			end
			if not v109 then
				continue
			end
			local v111
			if v107.axis == "Y" then
				v111 = v108.TileSize.Y.Offset
			else
				v111 = v108.TileSize.X.Offset
			end
			local v112 = v107.rate
			local v113 = v106 / math.abs(v112) % 1 * v111 * (v107.rate < 0 and -1 or 1)
			local v114 = v107.origin
			local v115
			if v107.axis == "Y" then
				v115 = UDim2.fromOffset(0, v113 - v111)
			else
				v115 = UDim2.fromOffset(v113 - v111, 0)
			end
			v108.Position = v114 + v115
			local v116 = v107.size
			local v117
			if v107.axis == "Y" then
				v117 = UDim2.fromOffset(0, 2 * v111)
			else
				v117 = UDim2.fromOffset(2 * v111, 0)
			end
			v108.Size = v116 + v117
		end
	end)
end
return v7