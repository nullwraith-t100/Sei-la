local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FF1E1E")
local v_u_8 = Color3.fromRGB(255, 120, 90)
local v_u_9 = Color3.fromRGB(150, 0, 10)
local v_u_10 = Color3.fromRGB(70, 0, 6)
local v_u_11 = Color3.fromRGB(16, 8, 10)
local v_u_12 = Color3.fromRGB(70, 6, 10)
local v_u_13 = Color3.new(1, 1, 1)
local v14 = Color3.fromRGB(255, 50, 44)
local v_u_15 = Color3.new(v14.R * 1.8, v14.G * 1.8, v14.B * 1.8)
local v_u_16 = Enum.PartType.Ball
local v_u_17 = Enum.PartType.Cylinder
local v_u_18 = Enum.PartType.Wedge
local v_u_19 = Enum.Material.ForceField
local v_u_20 = Enum.Material.SmoothPlastic
local function v_u_40(p21, p22, p23, p24, p25) -- name: picture
	-- upvalues: (copy) v_u_4
	local v26 = Color3.new
	local v27 = p24.R
	local v28 = math.min(v27, 1)
	local v29 = p24.G
	local v30 = math.min(v29, 1)
	local v31 = p24.B
	local v32 = v26(v28, v30, (math.min(v31, 1)))
	local v33 = math.max(p22, 0.03)
	local v34 = v_u_4.part
	local v35 = v33 * 2
	local v36 = v33 * 2
	local v37 = v34(Vector3.new(v35, 0.05, v36), p21, v32, {
		["transparency"] = 1
	})
	for _, v38 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v39 = Instance.new("Decal")
		v39.Face = v38
		v39.Texture = p23
		v39.Color3 = p24
		v39.Transparency = p25
		v39.Parent = v37
	end
	return v37
end
local function v_u_44(p41, p42) -- name: setAlpha
	for _, v43 in p41:GetChildren() do
		if not v43:IsA("Decal") then
			continue
		end
		v43.Transparency = p42
	end
end
local function v_u_55(p45, p46, p47, p48, p49) -- name: ribbon
	local v50 = Instance.new("Attachment")
	local v51 = p48 / 2
	v50.Position = Vector3.new(0, v51, 0)
	v50.Parent = p45
	local v52 = Instance.new("Attachment")
	local v53 = -p48 / 2
	v52.Position = Vector3.new(0, v53, 0)
	v52.Parent = p45
	local v54 = Instance.new("Trail")
	v54.Attachment0 = v50
	v54.Attachment1 = v52
	v54.Color = ColorSequence.new(p46, p47)
	v54.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v54.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.2) })
	v54.Lifetime = p49
	v54.LightEmission = 0.5
	v54.LightInfluence = 0
	v54.FaceCamera = true
	v54.MinLength = 0.05
	v54.Parent = p45
	return v54
end
local function v_u_66(p56, p57) -- name: tipped
	-- upvalues: (copy) v_u_3
	local v58 = Vector3.new(0, 0.5, 0)
	local v59 = v_u_3.CurrentCamera
	local v60
	if v59 then
		local v61 = v59.CFrame.Position - p56
		v60 = v61.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v61.Unit
	else
		v60 = Vector3.new(0, 0, 1)
	end
	local v62 = v58 + v60 * 0.5
	local v63 = v62.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v62.Unit
	local v64 = v63.Y
	local v65 = (math.abs(v64) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)):Cross(v63).Unit
	return CFrame.fromMatrix(p56, v65, v63) * CFrame.Angles(0, p57, 0)
end
local function v_u_85(p67, p68, p69, p70, p71, p72, p73, p74) -- name: kite
	-- upvalues: (copy) v_u_4, (copy) v_u_18, (copy) v_u_20, (copy) v_u_1
	local v75 = -p68 + p71
	local v76 = -p68 * 0.3 + p71
	local v77 = v76 - v75
	local v78 = p71 - v76
	for _, v79 in {
		{
			["size"] = Vector3.new(p70, p69, v77),
			["off"] = CFrame.new(0, p69 / 2, (v75 + v76) / 2)
		},
		{
			["size"] = Vector3.new(p70, p69, v77),
			["off"] = CFrame.new(0, -p69 / 2, (v75 + v76) / 2) * CFrame.Angles(0, 0, 3.141592653589793)
		},
		{
			["size"] = Vector3.new(p70, p69, v78),
			["off"] = CFrame.new(0, p69 / 2, (v76 + p71) / 2) * CFrame.Angles(0, 3.141592653589793, 0)
		},
		{
			["size"] = Vector3.new(p70, p69, v78),
			["off"] = CFrame.new(0, -p69 / 2, (v76 + p71) / 2) * CFrame.Angles(3.141592653589793, 0, 0)
		}
	} do
		local v80 = {
			["shape"] = v_u_18,
			["material"] = p73
		}
		local v81 = v_u_4.part(v79.size, CFrame.new(0, -500, 0), p72, v80)
		if p73 == v_u_20 then
			v81.Reflectance = 0.15
		end
		v_u_1:AddItem(v81, p74)
		local v82 = p67.parts
		table.insert(v82, v81)
		local v83 = p67.offs
		local v84 = v79.off
		table.insert(v83, v84)
	end
end
local function v_u_91(p86, p87, p88, p89) -- name: makeBlade
	-- upvalues: (copy) v_u_85, (copy) v_u_11, (copy) v_u_20, (copy) v_u_7
	local v90 = {
		["parts"] = {},
		["offs"] = {}
	}
	v_u_85(v90, p86, p87, 0.9, 0, v_u_11, v_u_20, p89)
	if not p88 then
		v_u_85(v90, p86 * 1.08, p87 * 1.32, 0.45, p86 * 0.04, v_u_7, Enum.Material.Neon, p89)
	end
	return v90
end
return function(p_u_92)
	-- upvalues: (copy) v_u_3, (copy) v_u_40, (copy) v_u_1, (copy) v_u_44, (copy) v_u_7, (copy) v_u_13, (copy) v_u_4, (copy) v_u_6, (copy) v_u_15, (copy) v_u_16, (copy) v_u_12, (copy) v_u_55, (copy) v_u_10, (copy) v_u_66, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5, (copy) v_u_91, (copy) v_u_11, (copy) v_u_17, (copy) v_u_20, (copy) v_u_19
	local v93 = {}
	local function v_u_121(p_u_94, p_u_95, p_u_96, p97, p98, p_u_99, p_u_100, p101) -- name: flare
		-- upvalues: (ref) v_u_40, (ref) v_u_3, (copy) p_u_92, (ref) v_u_1, (ref) v_u_44
		local v_u_102 = p101 or 0
		local v_u_103 = math.random() * 3.141592653589793 * 2
		local v104 = v_u_40
		local v105 = v_u_3.CurrentCamera
		local v106
		if v105 then
			local v107 = v105.CFrame.Position - p_u_94
			v106 = v107.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v107.Unit
		else
			v106 = Vector3.new(0, 0, 1)
		end
		local v_u_108 = v104(p_u_92.facing(p_u_94 + v106 * 0.3, v106) * CFrame.Angles(0, v_u_103, 0), p_u_95, p97, p98, v_u_102)
		v_u_1:AddItem(v_u_108, p_u_99 + 0.1)
		p_u_92.animate(p_u_99, 0, function(p109)
			-- upvalues: (copy) v_u_108, (copy) p_u_95, (copy) p_u_96, (copy) p_u_94, (copy) v_u_103, (copy) p_u_99, (copy) p_u_100, (ref) v_u_3, (ref) p_u_92, (ref) v_u_44, (copy) v_u_102
			local v110 = v_u_108
			local v111 = p_u_95 + (p_u_96 - p_u_95) * (1 - (1 - p109) ^ 3)
			local v112 = math.max(v111, 0.03)
			local v113 = v112 * 2
			local v114 = v112 * 2
			v110.Size = Vector3.new(v113, 0.05, v114)
			local v115 = v_u_108
			local v116 = p_u_94
			local v117 = v_u_103 + p109 * p_u_99 * p_u_100
			local v118 = v_u_3.CurrentCamera
			local v119
			if v118 then
				local v120 = v118.CFrame.Position - v116
				v119 = v120.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v120.Unit
			else
				v119 = Vector3.new(0, 0, 1)
			end
			v115.CFrame = p_u_92.facing(v116 + v119 * 0.3, v119) * CFrame.Angles(0, v117, 0)
			v_u_44(v_u_108, v_u_102 + (1 - v_u_102) * p109 ^ 1.5)
			if p109 >= 1 then
				v_u_108:Destroy()
			end
		end)
	end
	local function v_u_136(p122, p123, p124, p125, p126) -- name: crossCut
		-- upvalues: (copy) p_u_92, (ref) v_u_3, (ref) v_u_7, (ref) v_u_13
		local v127 = p_u_92.facing
		local v128 = v_u_3.CurrentCamera
		local v129
		if v128 then
			local v130 = v128.CFrame.Position - p122
			v129 = v130.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v130.Unit
		else
			v129 = Vector3.new(0, 0, 1)
		end
		local v131 = v127(p122, v129)
		for _, v132 in { 1, -1 } do
			local v133 = (v131.RightVector + v131.LookVector * v132).Unit
			local v134 = p122 - v133 * p123
			local v135 = p122 + v133 * p123
			p_u_92.thin(p_u_92.rod(v134, v135, p124, v_u_7), p125)
			if not p126 then
				continue
			end
			p_u_92.thin(p_u_92.rod(v134, v135, p124 * 0.4, v_u_13), p125 * 0.7)
		end
	end
	v93.fuma_mangekyo_a = {
		["cast"] = function(p137) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_92, (ref) v_u_13, (copy) v_u_121, (ref) v_u_6, (ref) v_u_15
			local v138 = p137.size
			local v139 = p137.eye + p137.dir * 1.2
			v_u_4.flash(v139, v_u_7, 2.8 * v138, 0.12)
			p_u_92.pop(v139, v_u_13, 1.1 * v138, 0.3 * v138, 0.1)
			if not p137.lite then
				v_u_121(v139, 0.4 * v138, 1.9 * v138, v_u_6.FumaShuriken, v_u_15, 0.12, 30)
			end
		end,
		["shot"] = function(p140, p141) -- name: throwShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_40, (ref) v_u_6, (ref) v_u_15, (ref) v_u_13, (ref) v_u_16, (ref) v_u_12, (ref) v_u_55, (ref) v_u_10, (ref) v_u_1, (copy) p_u_92, (ref) v_u_66
			local v_u_142 = p140.size
			local v143 = p140.lite
			local v_u_144 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p141, v_u_7, {
				["transparency"] = 1
			})
			local v_u_145 = v_u_40(p141, 1.7 * v_u_142, v_u_6.FumaShuriken, v_u_15, 0)
			local v146 = {
				["shape"] = v_u_16
			}
			local v_u_147 = v_u_4.part(Vector3.new(0.45, 0.45, 0.45) * v_u_142, p141, v_u_13, v146)
			local v_u_148 = { v_u_145, v_u_147 }
			local v_u_149 = {}
			local v_u_150
			if v143 then
				v_u_150 = nil
			else
				v_u_150 = v_u_40(p141, 1.5 * v_u_142, v_u_6.FumaShuriken, v_u_12, 0.25)
				table.insert(v_u_148, v_u_150)
				for _ = 1, 2 do
					local v151 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p141, v_u_7, {
						["transparency"] = 1
					})
					v_u_55(v151, v_u_7, v_u_10, 0.45 * v_u_142, 0.2)
					v_u_1:AddItem(v151, 3)
					table.insert(v_u_149, v151)
				end
			end
			for _, v152 in v_u_148 do
				v_u_1:AddItem(v152, 3)
			end
			v_u_1:AddItem(v_u_144, 3)
			p_u_92.streak(v_u_144, v_u_7, v_u_10, 0.9 * v_u_142, v143 and 0.1 or 0.14)
			if p140.mine then
				p_u_92.light(v_u_144, v_u_7, 9 * v_u_142)
			end
			local v_u_153 = false
			return {
				["place"] = function(p154, p155) -- name: place
					-- upvalues: (copy) v_u_144, (copy) v_u_147, (copy) v_u_145, (ref) v_u_66, (ref) v_u_150, (copy) v_u_142, (copy) v_u_149
					local v156 = p154.Position
					v_u_144.CFrame = p154
					v_u_147.CFrame = p154
					v_u_145.CFrame = v_u_66(v156, -p155 * 32)
					local v157 = v_u_150
					if v157 then
						v157.CFrame = v_u_66(v156 - p154.LookVector * 1.7 * v_u_142 - Vector3.new(0, 0.45, 0) * v_u_142, -p155 * 32 + 0.8)
					end
					for v158, v159 in v_u_149 do
						local v160 = p155 * 30 + v158 * 3.141592653589793
						v159.CFrame = CFrame.new(v156 + (p154.RightVector * math.cos(v160) + p154.UpVector * math.sin(v160)) * 1.05 * v_u_142)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_153, (copy) v_u_144, (ref) v_u_1, (copy) v_u_149, (copy) v_u_148
					if not v_u_153 then
						v_u_153 = true
						local v161 = v_u_144:FindFirstChildWhichIsA("PointLight")
						if v161 then
							v161:Destroy()
						end
						v_u_1:AddItem(v_u_144, 0.2)
						for _, v162 in v_u_149 do
							v_u_1:AddItem(v162, 0.25)
						end
						for _, v163 in v_u_148 do
							v163:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p164, p165) -- name: throwImpact
			-- upvalues: (copy) v_u_136, (copy) v_u_121, (ref) v_u_6, (ref) v_u_15, (copy) p_u_92, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v166 = p164.size
			v_u_136(p165, 3.6 * v166, 0.55 * v166, 0.2, not p164.lite)
			v_u_121(p165, 1.6 * v166, 4.4 * v166, v_u_6.FumaShuriken, v_u_15, 0.22, 14)
			p_u_92.pop(p165, v_u_7, 1.2 * v166, 4 * v166, 0.18, 0.35)
			v_u_4.ring(p_u_92.ground(p165), v_u_7, p164.ability.radius * 1.1, 0.28, v_u_6.Ring)
			p_u_92.burst("Impact", p165, v_u_7, 0.85 * v166)
			if not p164.lite then
				p_u_92.spikes(p165, v_u_8, 4, 4 * v166, 0.14)
			end
			p_u_92.hitSound(p165)
		end,
		["hit"] = p_u_92.simpleHit(v_u_7, 0.6)
	}
	v93.fuma_mangekyo_e = {
		["cast"] = function(p167) -- name: cast
			-- upvalues: (copy) p_u_92, (ref) v_u_7
			p_u_92.skillCast(p167, v_u_7)
		end,
		["windup"] = function(p168, _, p169) -- name: windup
			-- upvalues: (copy) p_u_92, (ref) v_u_40, (ref) v_u_6, (ref) v_u_15, (ref) v_u_1, (ref) v_u_8, (ref) v_u_4, (ref) v_u_7
			local v170 = p168.eye + p168.dir * 3.2
			local v_u_171 = p_u_92.facing(v170, p168.dir)
			local v172 = p168.lite
			local v_u_173 = v_u_40(v_u_171, 0.1, v_u_6.Swirl, v_u_15, 0.05)
			local v_u_174 = v_u_40(v_u_171, 0.1, v_u_6.Ring, v_u_15, 0)
			local v_u_175 = v_u_40(v_u_171, 0.1, v_u_6.FumaShuriken, v_u_15, 0)
			local v_u_176 = math.max(p169, 0.1) + 1.05
			for _, v177 in { v_u_173, v_u_174, v_u_175 } do
				v_u_1:AddItem(v177, v_u_176 + 0.1)
			end
			local v_u_178 = os.clock()
			p_u_92.runNow(function()
				-- upvalues: (copy) v_u_178, (copy) v_u_176, (copy) v_u_173, (copy) v_u_171, (copy) v_u_174, (copy) v_u_175
				local v179 = os.clock() - v_u_178
				local v180 = (v179 - (v_u_176 - 0.25)) / 0.25
				local v181 = math.clamp(v180, 0, 1)
				local v182 = v179 / 0.16
				local v183 = math.clamp(v182, 0, 1) - 1
				local v184 = (v183 * 2.7 * v183 * v183 + 1 + v183 * 1.7 * v183) * (1 - v181 * v181)
				local v185 = v_u_173
				local v186 = v184 * 5
				local v187 = math.max(v186, 0.03)
				local v188 = v187 * 2
				local v189 = v187 * 2
				v185.Size = Vector3.new(v188, 0.05, v189)
				v_u_173.CFrame = v_u_171 * CFrame.Angles(0, -v179 * 9, 0)
				local v190 = v_u_174
				local v191 = v184 * 5.2
				local v192 = math.max(v191, 0.03)
				local v193 = v192 * 2
				local v194 = v192 * 2
				v190.Size = Vector3.new(v193, 0.05, v194)
				v_u_174.CFrame = v_u_171
				local v195 = v_u_175
				local v196 = v184 * 1.8
				local v197 = math.max(v196, 0.03)
				local v198 = v197 * 2
				local v199 = v197 * 2
				v195.Size = Vector3.new(v198, 0.05, v199)
				v_u_175.CFrame = v_u_171 * CFrame.Angles(0, v179 * 24, 0)
				if v_u_176 > v179 then
					return true
				end
				v_u_173:Destroy()
				v_u_174:Destroy()
				v_u_175:Destroy()
				return false
			end)
			if not v172 then
				p_u_92.inward(v170, v_u_8, 6, 7, (math.max(p169, 0.1)))
			end
			v_u_4.flash(v170, v_u_7, 4, 0.2)
		end,
		["beam"] = function(p200, p201, p_u_202) -- name: beam
			-- upvalues: (copy) p_u_92, (ref) v_u_40, (ref) v_u_6, (ref) v_u_15, (ref) v_u_1, (ref) v_u_66, (ref) v_u_7, (ref) v_u_13, (ref) v_u_9, (copy) v_u_121, (copy) v_u_136, (ref) v_u_4, (ref) v_u_5
			local v_u_203 = p200.lite
			local v204 = p_u_202 - p201
			local v_u_205
			if v204.Magnitude > 0.001 then
				v_u_205 = v204.Unit
			else
				v_u_205 = p200.dir
			end
			local v_u_206 = p201 + v_u_205 * 3.2
			local v207 = (p_u_202 - v_u_206).Magnitude
			local v_u_208 = math.max(v207, 1)
			local v_u_209 = p_u_92.aimAt(v_u_206, v_u_205)
			local v_u_210 = (p200.ability.width or 10) * 0.32
			local v211 = v_u_203 and 5 or 12
			for v_u_212 = 1, v211 do
				p_u_92.after((v_u_212 - 1) * 0.04, function()
					-- upvalues: (ref) v_u_40, (copy) v_u_209, (ref) v_u_6, (ref) v_u_15, (ref) v_u_1, (copy) v_u_212, (ref) p_u_92, (copy) v_u_210, (copy) v_u_206, (copy) v_u_205, (copy) v_u_208, (ref) v_u_66
					local v_u_213 = v_u_40(v_u_209, 2.1, v_u_6.FumaShuriken, v_u_15, 0)
					v_u_1:AddItem(v_u_213, 0.62)
					local v_u_214 = v_u_212 * 2.4
					p_u_92.animate(0.42, 0, function(p215)
						-- upvalues: (copy) v_u_214, (ref) v_u_210, (ref) v_u_206, (ref) v_u_205, (ref) v_u_208, (ref) v_u_209, (copy) v_u_213, (ref) v_u_66
						local v216 = v_u_214 + p215 * 9
						local v217 = v_u_210
						local v218 = p215 * 4
						local v219 = math.min(v218, 1) * 3.141592653589793 / 2
						local v220 = v217 * math.sin(v219)
						v_u_213.CFrame = v_u_66(v_u_206 + v_u_205 * v_u_208 * p215 + (v_u_209.RightVector * math.cos(v216) + v_u_209.UpVector * math.sin(v216)) * v220, -p215 * 40)
						if p215 >= 1 then
							v_u_213:Destroy()
						end
					end)
				end)
			end
			p_u_92.glowBeam(v_u_206, p_u_202, v_u_7, 7.5, 0.5, v_u_6.Beam)
			if not v_u_203 then
				p_u_92.glowBeam(v_u_206, p_u_202, v_u_13, 1.6, 0.3)
				local v221 = p_u_92.flatUnit(v_u_205):Cross(Vector3.new(0, 1, 0))
				for _, v222 in { 1, -1 } do
					p_u_92.groundLine(v_u_206 + v221 * v222 * 2.6, p_u_202 + v221 * v222 * 2.6, 0.9, v_u_9, 1.2, 0.2)
				end
			end
			p_u_92.after((v211 - 1) * 0.04 + 0.42, function()
				-- upvalues: (ref) v_u_121, (copy) p_u_202, (ref) v_u_6, (ref) v_u_15, (copy) v_u_203, (ref) v_u_136, (ref) p_u_92, (ref) v_u_7, (ref) v_u_4, (ref) v_u_5
				v_u_121(p_u_202, 2, 7.5, v_u_6.FumaShuriken, v_u_15, 0.3, 16)
				if not v_u_203 then
					v_u_121(p_u_202, 1.5, 6, v_u_6.Swirl, v_u_15, 0.35, -10, 0.2)
					v_u_136(p_u_202, 5, 0.7, 0.25, true)
				end
				p_u_92.pop(p_u_202, v_u_7, 2, 9, 0.25, 0.3)
				v_u_4.ring(p_u_92.ground(p_u_202), v_u_7, 9, 0.35, v_u_6.Shockwave)
				p_u_92.burst("Impact", p_u_202, v_u_7, 1.4)
				local v223 = {
					["at"] = nil,
					["volume"] = 0.5,
					["at"] = p_u_202
				}
				v_u_5.play("Hit", v223)
			end)
			if p200.mine then
				v_u_4.shake(0.25, 0.25)
			end
		end,
		["hit"] = function(p224, p225, _) -- name: hit
			-- upvalues: (copy) p_u_92, (ref) v_u_7, (copy) v_u_136
			p_u_92.burst("Impact", p225, v_u_7, 0.7)
			if not p224.lite then
				v_u_136(p225, 1.6, 0.3, 0.14, false)
			end
		end
	}
	local v_u_226 = {}
	setmetatable(v_u_226, {
		["__mode"] = "k"
	})
	local function v_u_234(p227, p228, p229) -- name: bladeFrame
		local v230 = (p228 - p227).Unit
		local v231 = p229 - v230 * p229:Dot(v230)
		local v232
		if v231.Magnitude > 0.001 then
			v232 = v231.Unit
		else
			v232 = v230:Cross(Vector3.new(0, 1, 0)).Unit
		end
		local v233 = (-v230):Cross(v232)
		return CFrame.fromMatrix(p227, v232, v233)
	end
	local function v_u_245(p235, p236, p237) -- name: plantedFrame
		-- upvalues: (copy) v_u_234
		local v238 = math.cos(p237)
		local v239 = math.sin(p237)
		local v240 = Vector3.new(v238, 0, v239)
		local v241 = -math.sin(p237)
		local v242 = math.cos(p237)
		local v243 = Vector3.new(v241, 0, v242)
		local v244 = p235 + v240 * p236 - Vector3.new(0, 2, 0)
		return v_u_234(v244 + (Vector3.new(0, 0.89, 0) - v240 * 0.45).Unit * 22, v244, (v240 + v243).Unit)
	end
	local v_u_246 = {}
	local v_u_247 = {}
	local function v_u_258(p248, p249) -- name: placeBlades
		-- upvalues: (copy) v_u_246, (copy) v_u_247, (ref) v_u_3
		table.clear(v_u_246)
		table.clear(v_u_247)
		for v250, v251 in p248.blades do
			local v252 = p249[v250]
			for v253, v254 in v251.parts do
				local v255 = v_u_246
				table.insert(v255, v254)
				local v256 = v_u_247
				local v257 = v252 * v251.offs[v253]
				table.insert(v256, v257)
			end
		end
		v_u_3:BulkMoveTo(v_u_246, v_u_247, Enum.BulkMoveMode.FireCFrameChanged)
	end
	local function v_u_278(p259, p260) -- name: makeTrap
		-- upvalues: (copy) p_u_92, (ref) v_u_91, (copy) v_u_245
		local v261 = p259.ability.radius
		local v262 = p_u_92.ground(p260, 0)
		local v263 = p259.dir.Z
		local v264 = p259.dir.X
		local v265 = math.atan2(v263, v264) + 0.7853981633974483
		local v266 = (p259.ability.delay or 0.2) + (p259.ability.duration or 2.4) + 3
		local v267 = {}
		local v268 = {}
		local v269 = {}
		for v270 = 1, 4 do
			local v271 = v265 + (v270 - 1) * 3.141592653589793 / 2
			local v272 = v_u_91(22, 2.6, p259.lite, v266)
			table.insert(v269, v272)
			local v273 = v_u_245(v262, v261, v271)
			table.insert(v267, v273)
			local v274 = math.cos(v271)
			local v275 = math.sin(v271)
			local v276 = Vector3.new(v274, 0, v275)
			local v277 = v273 + Vector3.new(0, 46, 0) + v276 * 12
			table.insert(v268, v277)
		end
		return {
			["g"] = nil,
			["turn"] = nil,
			["blades"] = nil,
			["planted"] = nil,
			["lifted"] = nil,
			["born"] = nil,
			["plantedAt"] = nil,
			["duration"] = nil,
			["blown"] = nil,
			["hub"] = nil,
			["spin"] = 0,
			["drop"] = 0,
			["g"] = v262,
			["turn"] = v265,
			["blades"] = v269,
			["planted"] = v267,
			["lifted"] = v268,
			["born"] = os.clock(),
			["hub"] = {}
		}
	end
	local function v_u_290(p279, p280) -- name: plant
		-- upvalues: (copy) p_u_92, (ref) v_u_7, (ref) v_u_4, (ref) v_u_6, (ref) v_u_11, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5
		local v281 = p279.ability.radius
		local v282 = p279.lite
		for v283 = 1, 4 do
			local v284 = p280.turn + (v283 - 1) * 3.141592653589793 / 2
			local v285 = p280.g
			local v286 = math.cos(v284)
			local v287 = math.sin(v284)
			local v288 = v285 + Vector3.new(v286, 0, v287) * v281
			p_u_92.burst("Impact", v288 + Vector3.new(0, 1, 0), v_u_7, 1.6)
			v_u_4.ring(v288, v_u_7, 6, 0.35, v_u_6.Shockwave)
			p_u_92.mark(v288, v_u_7, 5, 2.6, v_u_6.CrackGlow, 0.2)
			if v282 then
				continue
			end
			local v289 = { v_u_11, v_u_9, v_u_10 }
			p_u_92.chunks(v288 + Vector3.new(0, 1, 0), v289, 5, 30, 0.9, 1, false, 1)
		end
		v_u_5.play("Crit", {
			["at"] = p280.g,
			["volume"] = p279.mine and 0.8 or 0.5
		})
		if p279.mine then
			v_u_4.shake(0.4, 0.3)
		end
	end
	v93.fuma_mangekyo_r = {
		["castSound"] = "Burst",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p291) -- name: cast
			-- upvalues: (copy) p_u_92, (ref) v_u_7, (copy) v_u_121, (ref) v_u_6, (ref) v_u_15, (ref) v_u_4
			p_u_92.skillCast(p291, v_u_7, true)
			local v292 = p291.size
			local v293 = p291.eye + p291.dir * 1.4
			v_u_121(v293, 4 * v292, 0.6 * v292, v_u_6.FumaShuriken, v_u_15, 0.3, 26)
			if not p291.lite then
				v_u_121(v293, 0.6 * v292, 5 * v292, v_u_6.Swirl, v_u_15, 0.3, -12, 0.1)
			end
			if p291.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p_u_294, p295, p296) -- name: windup
			-- upvalues: (copy) v_u_278, (copy) v_u_226, (copy) p_u_92, (copy) v_u_234, (copy) v_u_258, (copy) v_u_290, (ref) v_u_4, (ref) v_u_11, (ref) v_u_17, (ref) v_u_20, (ref) v_u_1, (ref) v_u_7, (ref) v_u_5, (ref) v_u_6, (ref) v_u_13
			local v_u_297 = v_u_278(p_u_294, p295)
			v_u_226[p_u_294] = v_u_297
			local v_u_298 = math.max(p296, 0.05)
			local v_u_299 = {}
			local v_u_300 = p_u_294.lite
			p_u_92.runNow(function()
				-- upvalues: (copy) v_u_297, (copy) v_u_299, (ref) v_u_234, (ref) v_u_258, (copy) v_u_298, (ref) v_u_290, (copy) p_u_294, (ref) v_u_4, (ref) v_u_11, (ref) v_u_17, (ref) v_u_20, (ref) v_u_1, (copy) v_u_300, (ref) v_u_7, (ref) v_u_5
				local v301 = os.clock()
				local v302 = v301 - v_u_297.born
				table.clear(v_u_299)
				local v303 = v_u_297.blown
				local v304 = v_u_297.duration
				local v305 = v_u_297.plantedAt
				if not v303 then
					if v305 then
						local v306 = v301 - v305
						local v307
						if v304 then
							local v308 = v304 - 0.62
							v307 = math.max(v308, 0.1)
						else
							v307 = (1 / 0)
						end
						if v306 < v307 then
							local v309 = v306 * 70
							local v310 = math.sin(v309) * 0.012
							for v311 in v_u_297.blades do
								v_u_299[v311] = v_u_297.planted[v311] * CFrame.Angles(v310, 0, -v310)
							end
						else
							local v312 = v306 - v307
							local v313 = v312 / 0.32
							local v314 = math.clamp(v313, 0, 1)
							local v315 = 1 - (1 - v314) ^ 3
							local v316 = v312 - 0.32
							local v317 = math.max(v316, 0)
							local v318 = v317 * v317 * 28
							local v319 = v317 / 0.3
							local v320 = math.min(v319, 1) * 2
							v_u_297.spin = v318
							v_u_297.drop = v320
							for v321 in v_u_297.blades do
								local v322 = v_u_297.turn + (v321 - 1) * 3.141592653589793 / 2
								local v323 = v_u_297.g
								local v324 = 7 - v320
								local v325 = v322 + v318
								local v326 = math.cos(v325)
								local v327 = math.sin(v325)
								local v328 = Vector3.new(v326, 0, v327)
								local v329 = v323 + Vector3.new(0, 1, 0) * v324
								local v330 = v_u_234(v329 + v328 * 1.4, v329 + v328 * 23.4, Vector3.new(0, 1, 0))
								local v331 = v_u_299
								if v314 < 1 then
									v330 = v_u_297.planted[v321]:Lerp(v330, v315)
								end
								v331[v321] = v330
							end
							if v314 >= 1 and #v_u_297.hub == 0 then
								local v332 = v_u_297.g + Vector3.new(0, 7, 0)
								local v333 = {
									["shape"] = v_u_17,
									["material"] = v_u_20
								}
								local v334 = v_u_4.part(Vector3.new(1.2, 6, 6), CFrame.new(v332) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_11, v333)
								v_u_1:AddItem(v334, 3)
								local v335 = v_u_297.hub
								table.insert(v335, v334)
								if not v_u_300 then
									local v336 = {
										["shape"] = v_u_17
									}
									local v337 = v_u_4.part(Vector3.new(0.6, 7.2, 7.2), CFrame.new(v332) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_7, v336)
									v_u_1:AddItem(v337, 3)
									local v338 = v_u_297.hub
									table.insert(v338, v337)
								end
								v_u_4.flash(v332, v_u_7, 12, 0.2)
								v_u_5.play("Hit", {
									["at"] = nil,
									["volume"] = 0.6,
									["at"] = v332
								})
							end
							for _, v339 in v_u_297.hub do
								v339.CFrame = CFrame.new(v_u_297.g + Vector3.new(0, 1, 0) * (7 - v320)) * CFrame.Angles(0, v318, 1.5707963267948966)
							end
						end
						v_u_258(v_u_297, v_u_299)
						return v306 < 8
					end
					local v340 = v_u_298
					local v341 = v302 / math.max(v340, 0.05)
					local v342 = math.clamp(v341, 0, 1)
					for v343 in v_u_297.blades do
						v_u_299[v343] = v_u_297.lifted[v343]:Lerp(v_u_297.planted[v343], v342 * v342)
					end
					v_u_258(v_u_297, v_u_299)
					if v342 >= 1 then
						v_u_297.plantedAt = v301
						v_u_290(p_u_294, v_u_297)
					end
					return v302 < 10
				end
				local v344 = (v301 - v303) / 0.45
				local v345 = math.clamp(v344, 0, 1)
				local v346 = 1 - (1 - v345) ^ 2
				for v347, v348 in v_u_297.blades do
					local v349 = v_u_297.turn + (v347 - 1) * 3.141592653589793 / 2
					local v350 = v349 + v_u_297.spin
					local v351 = math.cos(v350)
					local v352 = math.sin(v350)
					local v353 = Vector3.new(v351, 0, v352)
					local v354 = v_u_297.g
					local v355 = v_u_297.spin
					local v356 = 7 - v_u_297.drop
					local v357 = v349 + v355
					local v358 = math.cos(v357)
					local v359 = math.sin(v357)
					local v360 = Vector3.new(v358, 0, v359)
					local v361 = v354 + Vector3.new(0, 1, 0) * v356
					v_u_299[v347] = v_u_234(v361 + v360 * 1.4, v361 + v360 * 23.4, Vector3.new(0, 1, 0)) + v353 * 40 * v346 + Vector3.new(0, 8, 0) * v346
					for _, v362 in v348.parts do
						v362.Transparency = v345
					end
				end
				for _, v363 in v_u_297.hub do
					local v364 = v363.Transparency
					v363.Transparency = math.max(v364, v345)
				end
				v_u_258(v_u_297, v_u_299)
				if v345 < 1 then
					return true
				end
				for _, v365 in v_u_297.blades do
					for _, v366 in v365.parts do
						v366:Destroy()
					end
				end
				for _, v367 in v_u_297.hub do
					v367:Destroy()
				end
				return false
			end)
			v_u_4.ring(v_u_297.g, v_u_7, p_u_294.ability.radius * 1.1, math.max(p296, 0.15) + 0.2, v_u_6.Ring)
			if not p_u_294.lite then
				for v368 = 1, 4 do
					local v369 = v_u_297.turn + (v368 - 1) * 3.141592653589793 / 2
					local v370 = math.cos(v369)
					local v371 = math.sin(v369)
					local v372 = Vector3.new(v370, 0, v371)
					p_u_92.glint(v_u_297.g + Vector3.new(0, 40, 0) + v372 * 12, v_u_13, 6, 0.2)
				end
			end
		end,
		["zone"] = function(p_u_373, p374, p_u_375) -- name: zone
			-- upvalues: (copy) v_u_226, (copy) v_u_278, (copy) p_u_92, (copy) v_u_234, (copy) v_u_258, (copy) v_u_290, (ref) v_u_4, (ref) v_u_11, (ref) v_u_17, (ref) v_u_20, (ref) v_u_1, (ref) v_u_7, (ref) v_u_5, (ref) v_u_40, (ref) v_u_6, (ref) v_u_15, (ref) v_u_55, (ref) v_u_10, (ref) v_u_44, (ref) v_u_13
			local v376 = v_u_226[p_u_373]
			local v_u_377 = v376 or v_u_278(p_u_373, p374)
			if not v376 then
				v_u_226[p_u_373] = v_u_377
				local v_u_378 = {}
				local v_u_379 = p_u_373.lite
				local v_u_380 = 0.01
				p_u_92.runNow(function()
					-- upvalues: (copy) v_u_377, (copy) v_u_378, (ref) v_u_234, (ref) v_u_258, (copy) v_u_380, (ref) v_u_290, (copy) p_u_373, (ref) v_u_4, (ref) v_u_11, (ref) v_u_17, (ref) v_u_20, (ref) v_u_1, (copy) v_u_379, (ref) v_u_7, (ref) v_u_5
					local v381 = os.clock()
					local v382 = v381 - v_u_377.born
					table.clear(v_u_378)
					local v383 = v_u_377.blown
					local v384 = v_u_377.duration
					local v385 = v_u_377.plantedAt
					if not v383 then
						if v385 then
							local v386 = v381 - v385
							local v387
							if v384 then
								local v388 = v384 - 0.62
								v387 = math.max(v388, 0.1)
							else
								v387 = (1 / 0)
							end
							if v386 < v387 then
								local v389 = v386 * 70
								local v390 = math.sin(v389) * 0.012
								for v391 in v_u_377.blades do
									v_u_378[v391] = v_u_377.planted[v391] * CFrame.Angles(v390, 0, -v390)
								end
							else
								local v392 = v386 - v387
								local v393 = v392 / 0.32
								local v394 = math.clamp(v393, 0, 1)
								local v395 = 1 - (1 - v394) ^ 3
								local v396 = v392 - 0.32
								local v397 = math.max(v396, 0)
								local v398 = v397 * v397 * 28
								local v399 = v397 / 0.3
								local v400 = math.min(v399, 1) * 2
								v_u_377.spin = v398
								v_u_377.drop = v400
								for v401 in v_u_377.blades do
									local v402 = v_u_377.turn + (v401 - 1) * 3.141592653589793 / 2
									local v403 = v_u_377.g
									local v404 = 7 - v400
									local v405 = v402 + v398
									local v406 = math.cos(v405)
									local v407 = math.sin(v405)
									local v408 = Vector3.new(v406, 0, v407)
									local v409 = v403 + Vector3.new(0, 1, 0) * v404
									local v410 = v_u_234(v409 + v408 * 1.4, v409 + v408 * 23.4, Vector3.new(0, 1, 0))
									local v411 = v_u_378
									if v394 < 1 then
										v410 = v_u_377.planted[v401]:Lerp(v410, v395)
									end
									v411[v401] = v410
								end
								if v394 >= 1 and #v_u_377.hub == 0 then
									local v412 = v_u_377.g + Vector3.new(0, 7, 0)
									local v413 = {
										["shape"] = v_u_17,
										["material"] = v_u_20
									}
									local v414 = v_u_4.part(Vector3.new(1.2, 6, 6), CFrame.new(v412) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_11, v413)
									v_u_1:AddItem(v414, 3)
									local v415 = v_u_377.hub
									table.insert(v415, v414)
									if not v_u_379 then
										local v416 = {
											["shape"] = v_u_17
										}
										local v417 = v_u_4.part(Vector3.new(0.6, 7.2, 7.2), CFrame.new(v412) * CFrame.Angles(0, 0, 1.5707963267948966), v_u_7, v416)
										v_u_1:AddItem(v417, 3)
										local v418 = v_u_377.hub
										table.insert(v418, v417)
									end
									v_u_4.flash(v412, v_u_7, 12, 0.2)
									v_u_5.play("Hit", {
										["at"] = nil,
										["volume"] = 0.6,
										["at"] = v412
									})
								end
								for _, v419 in v_u_377.hub do
									v419.CFrame = CFrame.new(v_u_377.g + Vector3.new(0, 1, 0) * (7 - v400)) * CFrame.Angles(0, v398, 1.5707963267948966)
								end
							end
							v_u_258(v_u_377, v_u_378)
							return v386 < 8
						end
						local v420 = v_u_380
						local v421 = v382 / math.max(v420, 0.05)
						local v422 = math.clamp(v421, 0, 1)
						for v423 in v_u_377.blades do
							v_u_378[v423] = v_u_377.lifted[v423]:Lerp(v_u_377.planted[v423], v422 * v422)
						end
						v_u_258(v_u_377, v_u_378)
						if v422 >= 1 then
							v_u_377.plantedAt = v381
							v_u_290(p_u_373, v_u_377)
						end
						return v382 < 10
					end
					local v424 = (v381 - v383) / 0.45
					local v425 = math.clamp(v424, 0, 1)
					local v426 = 1 - (1 - v425) ^ 2
					for v427, v428 in v_u_377.blades do
						local v429 = v_u_377.turn + (v427 - 1) * 3.141592653589793 / 2
						local v430 = v429 + v_u_377.spin
						local v431 = math.cos(v430)
						local v432 = math.sin(v430)
						local v433 = Vector3.new(v431, 0, v432)
						local v434 = v_u_377.g
						local v435 = v_u_377.spin
						local v436 = 7 - v_u_377.drop
						local v437 = v429 + v435
						local v438 = math.cos(v437)
						local v439 = math.sin(v437)
						local v440 = Vector3.new(v438, 0, v439)
						local v441 = v434 + Vector3.new(0, 1, 0) * v436
						v_u_378[v427] = v_u_234(v441 + v440 * 1.4, v441 + v440 * 23.4, Vector3.new(0, 1, 0)) + v433 * 40 * v426 + Vector3.new(0, 8, 0) * v426
						for _, v442 in v428.parts do
							v442.Transparency = v425
						end
					end
					for _, v443 in v_u_377.hub do
						local v444 = v443.Transparency
						v443.Transparency = math.max(v444, v425)
					end
					v_u_258(v_u_377, v_u_378)
					if v425 < 1 then
						return true
					end
					for _, v445 in v_u_377.blades do
						for _, v446 in v445.parts do
							v446:Destroy()
						end
					end
					for _, v447 in v_u_377.hub do
						v447:Destroy()
					end
					return false
				end)
			end
			v_u_377.duration = p_u_375
			local v_u_448 = p_u_373.ability.radius
			local v_u_449 = v_u_377.g
			local v_u_450 = p_u_373.lite
			local v_u_451 = v_u_40(CFrame.new(v_u_449 + Vector3.new(0, 0.35, 0)), v_u_448 * 1.15, v_u_6.Swirl, v_u_15, 0.25)
			local v_u_452 = v_u_40(CFrame.new(v_u_449 + Vector3.new(0, 0.3, 0)), v_u_448 * 1.15, v_u_6.Ring, v_u_7, 0.2)
			v_u_1:AddItem(v_u_451, p_u_375 + 1)
			v_u_1:AddItem(v_u_452, p_u_375 + 1)
			local v_u_453 = {}
			for v454 = 1, v_u_450 and 0 or 3 do
				local v455 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_449), v_u_7, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v455, p_u_375 + 1)
				local v456 = {
					["p"] = v455,
					["trail"] = v_u_55(v455, v_u_7, v_u_10, 1.2, 0.35),
					["phase"] = v454 / 3
				}
				table.insert(v_u_453, v456)
			end
			local v_u_457 = os.clock()
			local v_u_458 = 0.4
			local v_u_459 = false
			local v_u_460 = { -1, -1, -1 }
			p_u_92.runNow(function()
				-- upvalues: (copy) v_u_457, (ref) v_u_459, (copy) v_u_451, (copy) v_u_449, (ref) v_u_44, (copy) v_u_452, (copy) v_u_453, (copy) v_u_460, (copy) v_u_448, (ref) v_u_458, (copy) v_u_450, (copy) v_u_377, (ref) p_u_92, (ref) v_u_7, (ref) v_u_13, (ref) v_u_4, (ref) v_u_6, (copy) p_u_375
				local v461 = os.clock() - v_u_457
				local v462
				if v_u_459 then
					v462 = 1
				else
					local v463 = v461 / 0.2
					v462 = math.clamp(v463, 0, 1)
				end
				v_u_451.CFrame = CFrame.new(v_u_449 + Vector3.new(0, 0.35, 0)) * CFrame.Angles(0, -v461 * 2.2, 0)
				v_u_44(v_u_451, 1 - v462 * 0.75)
				v_u_44(v_u_452, 1 - v462 * 0.8)
				for v464, v465 in v_u_453 do
					local v466 = v461 * 1.3 + v465.phase
					local v467 = math.floor(v466)
					local v468 = v466 - v467
					if v467 ~= v_u_460[v464] then
						v_u_460[v464] = v467
						v465.trail:Clear()
					end
					local v469 = v465.phase * 3.141592653589793 * 2 + v468 * 5
					local v470 = v_u_448 * 1.1 * (1 - v468)
					local v471 = v465.p
					local v472 = CFrame.new
					local v473 = v_u_449
					local v474 = math.cos(v469) * v470
					local v475 = 1 + v468 * 2
					local v476 = math.sin(v469) * v470
					v471.CFrame = v472(v473 + Vector3.new(v474, v475, v476))
				end
				if v_u_458 <= v461 and not v_u_459 then
					v_u_458 = v_u_458 + 0.4
					for v477 = 1, 4 do
						if v_u_450 and v477 % 2 == 0 then
							continue
						end
						local v478 = v_u_377.turn + (v477 - 1) * 3.141592653589793 / 2
						local v479 = math.cos(v478)
						local v480 = math.sin(v478)
						local v481 = Vector3.new(v479, 0, v480)
						local v482 = v_u_449 + v481 * v_u_448 + (Vector3.new(0, 0.89, 0) - v481 * 0.45).Unit * 10.100000000000001
						p_u_92.drawPath(p_u_92.boltPath(v482, v_u_449 + Vector3.new(0, 1, 0), 1.8, 3), 0.4, v_u_7, 0.14)
						if v_u_450 then
							continue
						end
						p_u_92.drawPath(p_u_92.boltPath(v482, v_u_449 + Vector3.new(0, 1, 0), 1, 4), 0.16, v_u_13, 0.1)
					end
					v_u_4.ring(v_u_449, v_u_7, v_u_448 * 0.7, 0.3, v_u_6.Ring)
					p_u_92.pop(v_u_449 + Vector3.new(0, 1, 0), v_u_7, 2, 6, 0.2, 0.4)
				end
				if not v_u_459 or p_u_375 + 0.4 >= v461 then
					return v461 < p_u_375 + 1
				end
				v_u_451:Destroy()
				v_u_452:Destroy()
				for _, v483 in v_u_453 do
					v483.p:Destroy()
				end
				return false
			end)
			return function()
				-- upvalues: (ref) v_u_459
				v_u_459 = true
			end
		end,
		["finish"] = function(p484, p485) -- name: finish
			-- upvalues: (copy) p_u_92, (copy) v_u_226, (ref) v_u_4, (ref) v_u_13, (ref) v_u_7, (ref) v_u_19, (copy) v_u_121, (ref) v_u_6, (ref) v_u_15, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5
			local v486 = p484.ability.radius
			local v487 = p_u_92.ground(p485, 0)
			local v488 = p484.lite
			local v489 = v_u_226[p484]
			v_u_226[p484] = nil
			if v489 then
				v489.blown = os.clock()
			end
			local v490 = v487 + Vector3.new(0, 7, 0)
			v_u_4.flash(v490, v_u_13, 18, 0.2)
			v_u_4.flash(v487 + Vector3.new(0, 3, 0), v_u_7, v486 * 1.8, 0.3)
			p_u_92.pop(v487 + Vector3.new(0, 2, 0), v_u_7, 4, v486 * 2.6, 0.55, 0.15, v_u_19)
			p_u_92.pop(v490, v_u_13, 3, 16, 0.25)
			p_u_92.dome(v487, v486 * 1.3, v_u_7, 0.5)
			v_u_121(v490, 4, v486 * 1.6, v_u_6.FumaShuriken, v_u_15, 0.45, 9)
			v_u_4.ring(v487, v_u_13, v486 * 1.5, 0.5, v_u_6.Shockwave)
			v_u_4.ring(v487, v_u_7, v486 * 1.9, 0.65, v_u_6.Ring)
			p_u_92.burst("Shockwave", v487 + Vector3.new(0, 0.3, 0), v_u_7, v486 / 12)
			p_u_92.burst("Explosion", v487 + Vector3.new(0, 3, 0), v_u_7, 2.2)
			p_u_92.chunks(v487 + Vector3.new(0, 1, 0), { v_u_11, v_u_9, v_u_7 }, v488 and 6 or 14, 55, 1.2, 1.2, false, 1)
			p_u_92.spikes(v490, v_u_8, v488 and 6 or 14, v486 * 1.6, 0.35, nil, nil, true)
			if not v488 then
				v_u_121(v490, 3, v486 * 1.3, v_u_6.Swirl, v_u_15, 0.5, -8, 0.1)
			end
			p_u_92.mark(v487, v_u_10, v486 * 1.1, 1.4, v_u_6.CrackGlow, 0.2)
			v_u_5.play("Explosion", {
				["at"] = v487,
				["volume"] = p484.mine and 1 or 0.6
			})
			if p484.mine then
				v_u_4.shake(0.6, 0.5)
			end
		end,
		["hit"] = function(p491, p492, _) -- name: hit
			-- upvalues: (copy) p_u_92, (ref) v_u_7, (ref) v_u_8
			p_u_92.burst("Impact", p492, v_u_7, 0.8)
			if not p491.lite then
				p_u_92.glint(p492, v_u_8, 3, 0.14)
			end
		end
	}
	return v93
end