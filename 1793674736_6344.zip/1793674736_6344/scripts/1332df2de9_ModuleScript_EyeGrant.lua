require(script.Parent.Parent.Config.Eyes)
return {
	["affordable"] = function(p1, p2, p3, p4) -- name: affordable
		local v5 = {}
		for _, v6 in p3 do
			if p4 and p4 < (v6.world or 1) then
				break
			end
			if p1[v6.id] then
				continue
			end
			if p2 < (v6.winsBefore or v6.wins) then
				break
			end
			local v7 = v6.id
			table.insert(v5, v7)
		end
		return v5
	end
}