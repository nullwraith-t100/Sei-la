local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(255, 138, 30)
local v_u_6 = Color3.new(1, 1, 1)
local function v_u_13(p7, p8, p9) -- name: bladeFrame
	local v10 = p8.Unit
	local v11 = p9 - v10 * p9:Dot(v10)
	if v11.Magnitude < 0.001 then
		v11 = v10:Cross(Vector3.new(1, 0, 0))
	end
	local v12 = v11.Unit
	return CFrame.fromMatrix(p7, v10, v12:Cross(v10)) * CFrame.Angles(0, 0, 0.3839724354387525)
end
return function(p_u_14)
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_5, (copy) v_u_13, (copy) v_u_4, (copy) v_u_6, (copy) v_u_3
	return {
		["w6_ryujin_jakka"] = function(p_u_15, p16)
			-- upvalues: (ref) v_u_2, (ref) v_u_1, (ref) v_u_5, (ref) v_u_13, (copy) p_u_14, (ref) v_u_4, (ref) v_u_6, (ref) v_u_3
			local v_u_17 = v_u_2.color(p16.color)
			local v_u_18 = v_u_2.color(p16.color2)
			local v19 = p_u_15.headY / 1.5
			local v_u_20 = math.clamp(v19, 0.7, 3)
			local v21 = v_u_20 * 3.3
			local v_u_22 = v_u_20 * 2.7
			local v23 = v_u_1:FindFirstChild("EyePieces")
			if v23 then
				v23 = v23:FindFirstChild("w6_ryujin_jakka")
			end
			local v_u_24 = nil
			local v25
			if v23 and v23:IsA("MeshPart") then
				v25 = v23:Clone()
				local v26 = v23.Size
				local v27 = v23.Size.X
				v25.Size = v26 * (v21 / math.max(v27, 0.01))
				v_u_24 = v25:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_24 then
					v25.Color = v_u_5
					v25.Material = Enum.Material.Neon
				end
			else
				v25 = Instance.new("WedgePart")
				local v28 = v21 * 0.16
				local v29 = v21 * 0.05
				v25.Size = Vector3.new(v21, v28, v29)
				v25.Color = v_u_5
				v25.Material = Enum.Material.Neon
			end
			v25.Anchored = true
			v25.CanCollide = false
			v25.CanQuery = false
			v25.CanTouch = false
			v25.CastShadow = false
			v25.Massless = true
			v25.Parent = v_u_2.folder()
			local v_u_30 = -1
			local v_u_31 = 0
			local v_u_32 = CFrame.identity
			local v33 = p_u_15.ticks
			local function v66(p34, p35, p36)
				-- upvalues: (copy) v_u_20, (ref) v_u_13, (copy) v_u_22, (copy) p_u_15, (ref) v_u_32, (ref) v_u_30, (ref) v_u_31, (ref) p_u_14, (ref) v_u_2, (copy) v_u_17, (ref) v_u_4, (copy) v_u_18, (ref) v_u_5
				local v37 = p35 * 1.9
				local v38 = math.cos(v37)
				local v39 = math.sin(v37)
				local v40 = Vector3.new(v38, 0, v39)
				local v41 = -math.sin(v37)
				local v42 = math.cos(v37)
				local v43 = Vector3.new(v41, 0, v42)
				local v44 = v_u_20 * 0.6
				local v45 = v_u_20 * 0.25
				local v46 = p35 * 1.3
				local v47 = v44 + v45 * math.sin(v46)
				local v48 = v_u_13(p34.Position + v40 * v_u_22 + Vector3.new(0, 1, 0) * v47, (v43 + Vector3.new(0, 0.12, 0)).Unit, (Vector3.new(0, 1, 0) + v40 * 0.35).Unit)
				local v49
				if p35 < 2.2 then
					v49 = 0
				else
					local v50 = (p35 - 2.2) % 5
					if v50 < 0.4 then
						local v51 = v50 / 0.4
						local v52 = math.clamp(v51, 0, 1)
						v49 = v52 * v52 * (3 - v52 * 2)
					elseif v50 < 1.1 then
						v49 = 1
					elseif v50 < 1.5 then
						local v53 = (1.5 - v50) / 0.4
						local v54 = math.clamp(v53, 0, 1)
						v49 = v54 * v54 * (3 - v54 * 2)
					else
						v49 = 0
					end
				end
				if v49 > 0 then
					local v55 = p34.LookVector
					local v56 = v55.X
					local v57 = v55.Z
					local v58 = Vector3.new(v56, 0, v57)
					local v59 = v58.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v58.Unit
					v_u_32 = v48:Lerp(v_u_13(p34.Position + Vector3.new(0, 1, 0) * (p_u_15.headY + v_u_20 * 0.75) - v59 * 0.9 * v_u_20, Vector3.new(0, 1, 0), v59), v49)
				else
					v_u_32 = v48
				end
				if p35 >= 2.2 then
					local v60 = (p35 - 2.2) / 5
					local v61 = math.floor(v60)
					local v62 = (p35 - 2.2) % 5
					if v61 ~= v_u_30 and v62 >= 0.4 then
						v_u_30 = v61
						v_u_31 = 1
						p_u_15.pulse = 1
						if (p34.Position - p_u_14.camPos()).Magnitude < 150 then
							v_u_2.ring(p_u_14.feetAt(p_u_15, p34, 0.15), v_u_17, 6 * p_u_15.fx, 0.6, v_u_4.Ring)
							v_u_2.flash(v_u_32.Position, v_u_18, v_u_20 * 3.5, 0.3)
							v_u_2.burst("Fire", v_u_32.Position, v_u_5, 0.7 * p_u_15.fx)
						end
					end
				end
				local v63 = v_u_31 - p36 * 1.4
				v_u_31 = math.max(v63, 0)
				local v64 = p_u_15
				local v65 = p_u_15.pulse - p36 * 1.4
				v64.pulse = math.max(v65, 0)
			end
			table.insert(v33, v66)
			p_u_14.add(p_u_15, v25, function()
				-- upvalues: (ref) v_u_32
				return v_u_32
			end)
			p_u_14.tail(v25, v_u_18, v_u_17, v_u_20 * 0.75, 0.4)
			if v_u_24 then
				local v_u_67 = v_u_24.EmissiveStrength
				local v_u_68 = -1
				local v69 = p_u_15.ticks
				local function v72()
					-- upvalues: (ref) v_u_31, (ref) v_u_68, (copy) v_u_24, (copy) v_u_67
					local v70 = v_u_31 * 20
					local v71 = math.floor(v70) / 20
					if v71 ~= v_u_68 then
						v_u_68 = v71
						v_u_24.EmissiveStrength = v_u_67 * (v71 * 1.2 + 1)
					end
				end
				table.insert(v69, v72)
			end
			local v_u_73 = Instance.new("ParticleEmitter")
			v_u_73.Texture = v_u_4.RyujinFlame
			v_u_73.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_73.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_73.Color = ColorSequence.new(v_u_6)
			v_u_73.LightEmission = 0.15
			v_u_73.LightInfluence = 0
			v_u_73.Orientation = Enum.ParticleOrientation.FacingCameraWorldUp
			v_u_73.Lifetime = NumberRange.new(0.35, 0.5)
			local v74 = v_u_20 * 0.85 * p_u_15.fx
			v_u_73.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v74 * 0.6), NumberSequenceKeypoint.new(0.4, v74), NumberSequenceKeypoint.new(1, v74 * 0.7) })
			v_u_73.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.85, 0), NumberSequenceKeypoint.new(1, 1) })
			v_u_73.Speed = NumberRange.new(1, 2.5)
			v_u_73.SpreadAngle = Vector2.new(20, 20)
			v_u_73.EmissionDirection = Enum.NormalId.Top
			local v75 = v_u_20 * 7
			v_u_73.Acceleration = Vector3.new(0, v75, 0)
			v_u_73.Rotation = NumberRange.new(-12, 12)
			v_u_73.Shape = Enum.ParticleEmitterShape.Box
			v_u_73.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_73:SetAttribute("BaseRate", 12)
			v_u_73.Rate = 12 * v_u_3.formRate()
			v_u_73.Parent = v25
			p_u_14.own(p_u_15, v25)
			local v_u_76 = -1
			local v77 = p_u_15.ticks
			local function v79()
				-- upvalues: (ref) v_u_31, (ref) v_u_76, (copy) v_u_73, (ref) v_u_3
				local v78 = v_u_31 > 0.05 and 2.5 or 1
				if v78 ~= v_u_76 then
					v_u_76 = v78
					v_u_73:SetAttribute("BaseRate", v78 * 12)
					v_u_73.Rate = v78 * 12 * v_u_3.formRate()
				end
			end
			table.insert(v77, v79)
			local v_u_86 = p_u_14.group(p_u_15, function(p80)
				-- upvalues: (copy) p_u_15, (ref) p_u_14
				local v81 = p80.Position + Vector3.new(0, 1, 0) * (p_u_15.headY + p_u_15.eyeLift)
				local v82 = p_u_14.camPos() - v81
				local v83 = v82.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v82.Unit
				local v84 = v83.Y
				local v85 = math.abs(v84) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v81, v81 + v83, v85)
			end)
			local v_u_87 = v_u_31
			local v_u_88 = {}
			for v_u_89 = 1, 8 do
				local v90 = p_u_14.blob
				local v91 = v_u_20 * 0.3
				local v92 = v_u_20 * 1.4
				local v93 = Vector3.new(v91, v92, 0.05)
				local v94
				if v_u_89 % 2 == 0 then
					v94 = v_u_18
				else
					v94 = v_u_17
				end
				local v95 = v90(v93, v94, 0.05)
				v_u_88[v_u_89] = v95
				p_u_14.add(p_u_15, v95, function(_, p96)
					-- upvalues: (copy) v_u_89, (ref) v_u_87, (copy) v_u_20, (copy) v_u_86
					local v97 = p96 * 1.6 + (v_u_89 - 1) * 3.141592653589793 * 2 / 8
					local v98 = (v_u_87 * 0.35 + 1.75) * v_u_20
					return v_u_86.cf * CFrame.new(math.cos(v97) * v98, math.sin(v97) * v98, 0.05) * CFrame.Angles(0, 0, v97 - 1)
				end)
			end
			local v_u_99 = -1
			local v100 = p_u_15.ticks
			local function v108(_, p101)
				-- upvalues: (ref) v_u_99, (copy) v_u_88, (ref) v_u_87, (copy) v_u_20
				if p101 - v_u_99 >= 0.06666666666666667 then
					v_u_99 = p101
					for v102, v103 in v_u_88 do
						local v104 = p101 * 11 + v102 * 1.9
						local v105 = (math.sin(v104) * 0.25 + 1) * (v_u_87 * 0.8 + 1)
						local v106 = v_u_20 * 0.3 * (v_u_87 * 0.3 + 1)
						local v107 = v_u_20 * 1.4 * v105
						v103.Size = Vector3.new(v106, v107, 0.05)
					end
				end
			end
			table.insert(v100, v108)
			p_u_14.particles(p_u_15, "Fire", v_u_5, {
				["rate"] = 0.5,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Embers" }
			})
			p_u_14.particles(p_u_15, "AuraMode", v_u_17, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end