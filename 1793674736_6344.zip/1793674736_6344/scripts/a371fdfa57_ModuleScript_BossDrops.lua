local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(script.Parent.Sfx)
local v6 = v_u_2.Shared
local v_u_7 = require(v6.Config.BossDrops)
local v_u_8 = require(v6.Logic.BossDrops)
local v9 = {}
local v_u_10 = v1.LocalPlayer
local v_u_11 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_12 = {}
local v_u_13 = false
local v_u_14 = nil
local function v_u_20(p15, p16) -- name: colourAt
	local v17 = #p15
	local v18 = p16 % 1 * v17
	local v19 = math.floor(v18)
	return p15[v19 + 1]:Lerp(p15[(v19 + 1) % v17 + 1], v18 - v19)
end
local function v_u_29(p21, p22) -- name: sweep
	-- upvalues: (copy) v_u_20
	local v23 = {}
	for v24 = 0, 11 do
		local v25 = v24 / 11
		local v26 = ColorSequenceKeypoint.new
		local v27 = v_u_20
		local v28 = p22 + v25 * 0.85
		table.insert(v23, v26(v25, v27(p21, v28)))
	end
	return ColorSequence.new(v23)
end
local function v_u_40(p30, p31, p32, p33, p34) -- name: words
	-- upvalues: (copy) v_u_11
	local v35 = Instance.new("TextLabel")
	v35.Name = "Glow"
	v35.BackgroundTransparency = 1
	v35.AnchorPoint = Vector2.new(0.5, 0.5)
	v35.Size = p33
	v35.Position = p34
	v35.FontFace = v_u_11
	v35.TextScaled = true
	v35.Text = p31
	v35.ZIndex = 1
	v35.Parent = p30
	v35.TextColor3 = Color3.fromHex(p32.glow)
	local v36 = Instance.new("UIStroke")
	v36.Color = Color3.fromHex(p32.glow)
	v36.Thickness = 0.2
	v36.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v36.LineJoinMode = Enum.LineJoinMode.Round
	v36.Transparency = 0.25
	v36.Parent = v35
	local v37 = Instance.new("TextLabel")
	v37.Name = "Text"
	v37.BackgroundTransparency = 1
	v37.AnchorPoint = Vector2.new(0.5, 0.5)
	v37.Size = p33
	v37.Position = p34
	v37.FontFace = v_u_11
	v37.TextScaled = true
	v37.Text = p31
	v37.ZIndex = 2
	v37.Parent = p30
	v37.TextColor3 = Color3.new(1, 1, 1)
	local v38 = Instance.new("UIStroke")
	v38.Color = Color3.fromHex(p32.stroke)
	v38.Thickness = 0.11
	v38.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v38.LineJoinMode = Enum.LineJoinMode.Round
	v38.Parent = v37
	local v39 = Instance.new("UIGradient")
	v39.Rotation = 18
	v39.Parent = v37
	return {
		["front"] = v37,
		["back"] = v35,
		["gradient"] = v39,
		["strokes"] = { v36, v38 }
	}
end
local function v_u_67(p41) -- name: play
	-- upvalues: (ref) v_u_14, (copy) v_u_10, (copy) v_u_40, (copy) v_u_3, (copy) v_u_29, (copy) v_u_5, (copy) v_u_4
	local v42 = v_u_14
	if not (v42 and v42.Parent) then
		local v43 = v_u_10:FindFirstChildOfClass("PlayerGui")
		if v43 then
			v42 = Instance.new("ScreenGui")
			v42.Name = "BossDrops"
			v42.DisplayOrder = 45
			v42.IgnoreGuiInset = true
			v42.ResetOnSpawn = false
			v42.Parent = v43
			v_u_14 = v42
		else
			v42 = nil
		end
	end
	if v42 then
		local v44 = p41.drop
		local v_u_45 = {}
		for _, v46 in v44.colors do
			local v47 = Color3.fromHex
			table.insert(v_u_45, v47(v46))
		end
		local v48 = Instance.new("Frame")
		v48.Name = "Drop"
		v48.BackgroundTransparency = 1
		v48.AnchorPoint = Vector2.new(0.5, 0.5)
		v48.Position = UDim2.fromScale(0.5, 0.2)
		local v_u_49 = {}
		if p41.mine then
			v48.Size = UDim2.fromScale(0.8, 0.15)
			local v50 = v_u_40(v48, p41.main, v44, UDim2.fromScale(1, 0.64), UDim2.fromScale(0.5, 0.33))
			table.insert(v_u_49, v50)
			if p41.sub then
				local v51 = v_u_40(v48, p41.sub, v44, UDim2.fromScale(0.62, 0.3), UDim2.fromScale(0.5, 0.83))
				table.insert(v_u_49, v51)
			end
		else
			v48.Size = UDim2.fromScale(0.6, 0.06)
			local v52 = v_u_40(v48, p41.main, v44, UDim2.fromScale(1, 1), UDim2.fromScale(0.5, 0.5))
			table.insert(v_u_49, v52)
		end
		local v_u_53 = Instance.new("UIScale")
		v_u_53.Scale = 0.15
		v_u_53.Parent = v48
		v48.Rotation = p41.mine and -7 or 0
		v48.Parent = v42
		local v_u_54 = os.clock()
		local v_u_55 = nil
		local v61 = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_29, (copy) v_u_45, (copy) v_u_54, (copy) v_u_49, (ref) v_u_55, (copy) v_u_53
			local v56 = os.clock()
			local v57 = v_u_29(v_u_45, (v56 - v_u_54) * 0.45)
			for _, v58 in v_u_49 do
				v58.gradient.Color = v57
			end
			if v_u_55 then
				local v59 = v_u_53
				local v60 = (v56 - v_u_55) * 5
				v59.Scale = math.sin(v60) * 0.025 + 1
			end
		end)
		if p41.mine then
			v_u_5.play("RevealBig")
		else
			v_u_5.play("Reveal", {
				["volume"] = 0.6
			})
		end
		v_u_4:Create(v_u_53, TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1.28
		}):Play()
		local v62 = Enum.EasingStyle.Back
		v_u_4:Create(v48, TweenInfo.new(0.3, v62 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Rotation"] = 0
		}):Play()
		task.wait(0.16)
		local v63 = Enum.EasingStyle.Back
		v_u_4:Create(v_u_53, TweenInfo.new(0.32, v63 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Scale"] = 1
		}):Play()
		task.wait(0.32)
		v_u_55 = os.clock()
		task.wait(p41.mine and 3 or 2.4)
		v_u_55 = nil
		local v64 = {
			["Position"] = UDim2.fromScale(0.5, 0.17)
		}
		v_u_4:Create(v48, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v64):Play()
		for _, v65 in v_u_49 do
			v_u_4:Create(v65.front, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			v_u_4:Create(v65.back, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			for _, v66 in v65.strokes do
				v_u_4:Create(v66, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
			end
		end
		task.wait(0.45)
		v61:Disconnect()
		v48:Destroy()
	end
end
local function v_u_77(p68) -- name: add
	-- upvalues: (copy) v_u_12, (ref) v_u_13, (copy) v_u_67
	if p68.mine then
		local v69 = #v_u_12 + 1
		for v70, v71 in v_u_12 do
			if v71.mine then
				continue
			end
			v69 = v70
		end
		local v72 = v_u_12
		table.insert(v72, v69, p68)
	else
		local v73 = 0
		for _, v74 in v_u_12 do
			if v74.mine then
				continue
			end
			v73 = v73 + 1
		end
		if v73 >= 3 then
			return
		end
		local v75 = v_u_12
		table.insert(v75, p68)
	end
	if not v_u_13 then
		v_u_13 = true
		task.spawn(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_67, (ref) v_u_13
			while #v_u_12 > 0 do
				local v76 = table.remove(v_u_12, 1)
				if not v76 then
					continue
				end
				v_u_67(v76)
			end
			v_u_13 = false
		end)
	end
end
local function v_u_96(p78) -- name: heard
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_77
	if type(p78) == "table" then
		if p78.t == "mine" then
			local v79 = p78.drops
			if type(v79) == "table" then
				for _, v81 in p78.drops do
					if type(v81) ~= "table" then
						local v81 = nil
					end
					local v82
					if v81 then
						local v83 = v81.id
						if type(v83) == "string" then
							v82 = v_u_7.byId[v81.id]
						else
							v82 = nil
						end
					else
						v82 = nil
					end
					if not (v81 and v82) then
						continue
					end
					local v84 = v81.coins
					local v85 = type(v84) ~= "number" and 0 or v81.coins
					local v86 = v_u_8.lines
					local v87 = {
						["drop"] = v82,
						["duplicate"] = v81.dup == true,
						["coins"] = v85
					}
					local v88 = v81.luck
					v87.luck = type(v88) ~= "number" and 1 or v81.luck
					local v89, v90 = v86(v87)
					v_u_77({
						["mine"] = true,
						["main"] = nil,
						["sub"] = nil,
						["drop"] = nil,
						["main"] = v89,
						["sub"] = v90,
						["drop"] = v82
					})
				end
				return
			end
		end
		if p78.t == "other" then
			local v91 = p78.name
			if type(v91) == "string" then
				local v92 = p78.id
				local v93 = type(v92) == "string" and v_u_7.byId[p78.id]
				if v93 then
					local v94 = p78.luck
					local v95 = type(v94) ~= "number" and 1 or p78.luck
					v_u_77({
						["mine"] = false,
						["main"] = nil,
						["drop"] = nil,
						["main"] = v_u_8.announce(p78.name, v93, v95),
						["drop"] = v93
					})
				end
			end
		end
	end
end
function v9.start() -- name: start
	-- upvalues: (copy) v_u_2, (copy) v_u_96
	task.spawn(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_96
		local v97 = v_u_2:WaitForChild("Remotes"):WaitForChild("BossDrop")
		if v97:IsA("RemoteEvent") then
			v97.OnClientEvent:Connect(v_u_96)
		end
	end)
end
return v9