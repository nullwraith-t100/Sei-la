local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_2 = v1.get("ConnectionUtil")
local v_u_3 = v1.get("CharacterUtil")
local v4 = v1.get("FlagUtil")
local v_u_5 = v4.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_6 = v4.getUserFlag("UserPlayerScriptsRefactor1")
local v_u_7 = v4.getUserFlag("UserPlayerScriptsFixTouchJumpVisibility")
game:GetService("Players")
local v_u_8 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface"))
local v_u_9 = { "rbxasset://textures/ui/Input/JumpButtonRegular.png", "rbxasset://textures/ui/Input/JumpButtonPressed.png" }
local v_u_10 = require(script.Parent:WaitForChild("ActionController"))
local v_u_11 = setmetatable({}, v_u_10)
v_u_11.__index = v_u_11
function v_u_11.new(p12) -- name: new
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_7, (copy) v_u_2
	local v13 = v_u_10.new()
	local v14 = v_u_11
	local v_u_15 = setmetatable(v13, v14)
	v_u_15.data = p12
	p12.eventBus:subscribe("ACTIONS_RELOADED"):Connect(function()
		-- upvalues: (copy) v_u_15, (ref) v_u_7
		v_u_15:Create()
		if v_u_7 and v_u_15._active then
			v_u_15._active = false
			v_u_15:EnableButton(true)
		end
	end)
	v_u_15.parentUIFrame = nil
	v_u_15.jumpButton = nil
	v_u_15.externallyEnabled = false
	v_u_15._active = false
	v_u_15._connectionUtil = v_u_2.new()
	return v_u_15
end
function v_u_11._reset(p16) -- name: _reset
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9
	if p16.jumpButton then
		if not v_u_5 and v_u_8.isEnabled() then
			p16.jumpButton.Image = v_u_9[1]
			return
		end
		p16.jumpButton.ImageRectOffset = Vector2.new(1, 146)
	end
end
function v_u_11.EnableButton(p17, p18) -- name: EnableButton
	if p18 ~= p17._active then
		if p18 then
			if not p17.jumpButton then
				p17:Create()
			end
			p17.jumpButton.Visible = true
		elseif p17.jumpButton then
			p17.jumpButton.Visible = false
		end
		p17:_reset()
		p17._active = p18
	end
end
function v_u_11.UpdateEnabled(p19) -- name: UpdateEnabled
	-- upvalues: (copy) v_u_3
	local v20 = v_u_3.getChild("Humanoid", "Humanoid")
	if v20 and p19.externallyEnabled and (v20.UseJumpPower and v20.JumpPower > 0 or not v20.UseJumpPower and v20.JumpHeight > 0) and v20:GetStateEnabled(Enum.HumanoidStateType.Jumping) then
		p19:EnableButton(true)
	else
		p19:EnableButton(false)
	end
end
function v_u_11._setupConfigurations(p_u_21) -- name: _setupConfigurations
	-- upvalues: (copy) v_u_3
	local function v_u_22() -- name: update
		-- upvalues: (copy) p_u_21
		p_u_21:UpdateEnabled()
	end
	local v26 = v_u_3.onChild("Humanoid", "Humanoid", function(p23)
		-- upvalues: (copy) p_u_21, (copy) v_u_22
		p_u_21:UpdateEnabled()
		p_u_21:_reset()
		p_u_21._connectionUtil:trackConnection("HUMANOID_JUMP_POWER", p23:GetPropertyChangedSignal("JumpPower"):Connect(v_u_22))
		p_u_21._connectionUtil:trackConnection("HUMANOID_JUMP_HEIGHT", p23:GetPropertyChangedSignal("JumpHeight"):Connect(v_u_22))
		p_u_21._connectionUtil:trackConnection("HUMANOID_STATE_ENABLED_CHANGED", p23.StateEnabledChanged:Connect(function(p24, p25)
			-- upvalues: (ref) p_u_21
			if p24 == Enum.HumanoidStateType.Jumping and p25 ~= p_u_21._active then
				p_u_21:UpdateEnabled()
			end
		end))
	end)
	p_u_21._connectionUtil:trackConnection("HUMANOID", v26)
end
function v_u_11.Enable(p27, p28, p29) -- name: Enable
	-- upvalues: (copy) v_u_10
	if p29 then
		p27.parentUIFrame = p29
	end
	if p27.externallyEnabled == p28 then
		return
	else
		p27.externallyEnabled = p28
		v_u_10.Enable(p27, p28)
		p27:UpdateEnabled()
		if p28 then
			p27:_setupConfigurations()
		else
			p27._connectionUtil:disconnectAll()
		end
	end
end
function v_u_11.Create(p_u_30) -- name: Create
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_8, (copy) v_u_9
	if p_u_30.parentUIFrame then
		if p_u_30.jumpButton then
			p_u_30.jumpButton:Destroy()
			p_u_30.jumpButton = nil
		end
		if p_u_30.absoluteSizeChangedConn then
			p_u_30.absoluteSizeChangedConn:Disconnect()
			p_u_30.absoluteSizeChangedConn = nil
		end
		if not v_u_5 and p_u_30.avatarAbilitiesEnabledChangedConn then
			p_u_30.avatarAbilitiesEnabledChangedConn:Disconnect()
			p_u_30.avatarAbilitiesEnabledChangedConn = nil
		end
		p_u_30.jumpButton = Instance.new("ImageButton")
		p_u_30.jumpButton.Name = "JumpButton"
		p_u_30.jumpButton.Visible = false
		p_u_30.jumpButton.BackgroundTransparency = 1
		if v_u_6 then
			p_u_30.jumpButton.ZIndex = 10
		end
		if v_u_5 or not v_u_8.isEnabled() then
			p_u_30.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			p_u_30.jumpButton.ImageRectOffset = Vector2.new(1, 146)
			p_u_30.jumpButton.ImageRectSize = Vector2.new(144, 144)
		else
			p_u_30.jumpButton.Image = v_u_9[1]
		end
		local function v38() -- name: ResizeJumpButton
			-- upvalues: (copy) p_u_30, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
			local v31 = p_u_30.parentUIFrame.AbsoluteSize.x
			local v32 = p_u_30.parentUIFrame.AbsoluteSize.y
			local v33 = math.min(v31, v32) <= 500
			if v_u_5 or not v_u_8.isEnabled() then
				local v34 = v33 and 70 or 120
				p_u_30.jumpButton.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
				p_u_30.jumpButton.ImageRectOffset = Vector2.new(1, 146)
				p_u_30.jumpButton.ImageRectSize = Vector2.new(144, 144)
				p_u_30.jumpButton.Size = UDim2.new(0, v34, 0, v34)
				p_u_30.jumpButton.Position = v33 and UDim2.new(1, -(v34 * 1.5 - 10), 1, -v34 - 20) or UDim2.new(1, -(v34 * 1.5 - 10), 1, -v34 * 1.75)
			else
				local v35 = v33 and 72 or 120
				local v36 = -v35 - (v33 and 64 or 100)
				local v37 = -v35 - (v33 and 64 or 112)
				p_u_30.jumpButton.Image = v_u_9[1]
				p_u_30.jumpButton.ImageRectOffset = Vector2.new(0, 0)
				p_u_30.jumpButton.ImageRectSize = Vector2.new(0, 0)
				p_u_30.jumpButton.Size = UDim2.new(0, v35, 0, v35)
				p_u_30.jumpButton.Position = UDim2.new(1, v36, 1, v37)
			end
		end
		v38()
		p_u_30.absoluteSizeChangedConn = p_u_30.parentUIFrame:GetPropertyChangedSignal("AbsoluteSize"):Connect(v38)
		if not v_u_5 then
			p_u_30.avatarAbilitiesEnabledChangedConn = v_u_8.GetEnabledChangedSignal():Connect(v38)
		end
		p_u_30.jumpButton.Parent = p_u_30.parentUIFrame
		if p_u_30.data.actions.JumpAction then
			p_u_30.data.actions.JumpAction:WaitForChild("TouchBinding").UIButton = p_u_30.jumpButton
			p_u_30.data.actions.JumpAction.Pressed:Connect(function()
				-- upvalues: (copy) p_u_30, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
				if p_u_30.jumpButton then
					if v_u_5 or not v_u_8.isEnabled() then
						p_u_30.jumpButton.ImageRectOffset = Vector2.new(146, 146)
					else
						p_u_30.jumpButton.Image = v_u_9[2]
					end
				else
					return
				end
			end)
			p_u_30.data.actions.JumpAction.Released:Connect(function()
				-- upvalues: (copy) p_u_30, (ref) v_u_5, (ref) v_u_8, (ref) v_u_9
				if p_u_30.jumpButton then
					if v_u_5 or not v_u_8.isEnabled() then
						p_u_30.jumpButton.ImageRectOffset = Vector2.new(1, 146)
					else
						p_u_30.jumpButton.Image = v_u_9[1]
					end
				else
					return
				end
			end)
		end
	else
		return
	end
end
return v_u_11