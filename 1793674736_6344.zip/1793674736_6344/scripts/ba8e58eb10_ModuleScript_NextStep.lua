local v_u_1 = require(script.Parent.Parent.Config.Products)
local v_u_2 = require(script.Parent.ChakraLadder)
local v_u_19 = {
	["DONE"] = "done",
	["NONE"] = "",
	["AFTER_X2"] = "x4",
	["pick"] = function(p3, p4, p5, p6) -- name: pick
		-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_19
		if p3 == "pass" and p4 == "x2" then
			local v7 = v_u_2.next(v_u_1.chakraTiers, p5)
			if v7 and (v7.key == v_u_19.AFTER_X2 and p6(v7.key)) then
				return v7.key
			end
		end
		return not p5("starter") and p6("starter") and "starter" or nil
	end,
	["isFirst"] = function(p8, p9, p10, p11) -- name: isFirst
		for _, v12 in p8 do
			if v12 == p9 then
				continue
			end
			return false
		end
		for _, v13 in p10 do
			if v13 == p11 then
				continue
			end
			return false
		end
		return true
	end,
	["pending"] = function(p14) -- name: pending
		-- upvalues: (copy) v_u_19
		local v15
		if p14 == v_u_19.NONE then
			v15 = false
		else
			v15 = p14 ~= v_u_19.DONE
		end
		return v15
	end,
	["gain"] = function(p16, p17) -- name: gain
		-- upvalues: (copy) v_u_2, (copy) v_u_1
		local v18 = v_u_2.best(v_u_1.chakraTiers, p17)
		return (p16.mult or 1) / math.max(v18, 1)
	end
}
return v_u_19