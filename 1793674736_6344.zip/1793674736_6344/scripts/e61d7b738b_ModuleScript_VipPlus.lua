local v_u_39 = {
	["expand"] = function(p1, p2) -- name: expand
		local v3 = table.clone(p1)
		local v4 = true
		while v4 do
			v4 = false
			for v5, v6 in p2 do
				if not v3[v5] then
					continue
				end
				for _, v7 in v6 do
					if v3[v7] then
						continue
					end
					v3[v7] = true
					v4 = true
				end
			end
		end
		return v3
	end,
	["opened"] = function(p8, p9, p10, p11) -- name: opened
		-- upvalues: (copy) v_u_39
		local v12 = {}
		local v13 = {}
		for v14, v15 in p9 do
			local v16 = p10[v14]
			if v16 ~= nil and not p11(v16) then
				continue
			end
			v12[v14] = v15
			if not p8(v14) then
				continue
			end
			v13[v14] = true
		end
		local v17 = v_u_39.expand(v13, v12)
		for v18 in v13 do
			v17[v18] = nil
		end
		return v17
	end,
	["inside"] = function(p19, p20) -- name: inside
		-- upvalues: (copy) v_u_39
		local v21 = {}
		for v22 in v_u_39.expand({
			[p19] = true
		}, p20) do
			if v22 == p19 then
				continue
			end
			table.insert(v21, v22)
		end
		table.sort(v21)
		return v21
	end,
	["upgradePrice"] = function(p23, p24) -- name: upgradePrice
		local v25 = p23 - p24
		if p24 > 0 and v25 > 0 then
			return v25
		else
			return nil
		end
	end,
	["coins"] = function(p26, p27, p28) -- name: coins
		if not p27 or p26 <= 0 then
			return p26
		end
		local v29 = p26 * p28 + 0.5
		local v30 = math.floor(v29)
		return math.max(p26, v30)
	end,
	["promoWeight"] = function(p31, p32, p33) -- name: promoWeight
		return p32 > p31 and 0 or p33
	end,
	["saving"] = function(p34, p35, p36, p37) -- name: saving
		for _, v38 in p35 do
			p37 = p37 + p36(v38)
		end
		if p37 > 0 then
			return p37, 1 - p34 / p37
		else
			return p37, 0
		end
	end
}
return v_u_39