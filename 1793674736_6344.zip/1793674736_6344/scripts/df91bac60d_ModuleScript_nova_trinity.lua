local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("FF8A1A")
local v_u_9 = Color3.fromHex("FFE14B")
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(255, 248, 225)
local v_u_12 = Color3.fromRGB(232, 58, 20)
local v_u_13 = Color3.fromRGB(165, 28, 10)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.PartType.Cylinder
local function v_u_27(p16, p17, p18, p19, p20) -- name: pic
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_33(p28, p29, p30) -- name: setPic
	local v31 = math.max(p29, 0.03) * 2
	p28.Size = Vector3.new(v31, 0.05, v31)
	if p30 then
		for _, v32 in p28:GetChildren() do
			if not v32:IsA("Decal") then
				continue
			end
			v32.Transparency = p30
		end
	end
end
local function v_u_40(p34, p35, p36, p37) -- name: blob
	-- upvalues: (copy) v_u_5
	local v38 = v_u_5.part(p34, p35, p36, {
		["transparency"] = p37
	})
	local v39 = Instance.new("SpecialMesh")
	v39.MeshType = Enum.MeshType.Sphere
	v39.Parent = v38
	return v38
end
local function v_u_50(p41, p42, p43, p44) -- name: layRod
	local v45 = (p43 - p42).Magnitude
	local v46 = math.max(v45, 0.05)
	local v47 = ((p43 - p42).Magnitude <= 0.001 and Vector3.new(0, 1, 0) or (p43 - p42).Unit).Y
	local v48 = math.abs(v47) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v49 = math.max(p44, 0.02)
	p41.Size = Vector3.new(v46, v49, v49)
	p41.CFrame = CFrame.lookAt((p42 + p43) / 2, p43, v48) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_59(p51, p52, p53, p54, p55, p_u_56) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	local v_u_57 = Instance.new("ColorCorrectionEffect")
	v_u_57.Name = "NovaTrinity"
	v_u_57.Parent = v_u_2
	v_u_5.tween(v_u_57, p54, {
		["TintColor"] = p51,
		["Brightness"] = p52,
		["Contrast"] = p53
	})
	task.delay(p54 + p55, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_57, (copy) p_u_56, (ref) v_u_10
		local v58 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_10
		}
		v_u_5.tween(v_u_57, p_u_56, v58)
	end)
	v_u_1:AddItem(v_u_57, p54 + p55 + p_u_56 + 0.1)
end
return function(p_u_60)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_33, (copy) v_u_9, (copy) v_u_8, (copy) v_u_12, (copy) v_u_40, (copy) v_u_5, (copy) v_u_7, (copy) v_u_11, (copy) v_u_14, (copy) v_u_4, (copy) v_u_6, (copy) v_u_15, (copy) v_u_50, (copy) v_u_13, (copy) v_u_10, (copy) v_u_59
	local v61 = {}
	local function v_u_72(p62, p_u_63, p_u_64, p65, p66, p67, p68) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_60, (ref) v_u_33
		local v_u_69 = p68 or 0
		local v_u_70 = v_u_27(p62, p_u_63, p65, p66, v_u_69)
		v_u_1:AddItem(v_u_70, p67 + 0.1)
		p_u_60.animate(p67, 0, function(p71)
			-- upvalues: (ref) v_u_33, (copy) v_u_70, (copy) p_u_63, (copy) p_u_64, (copy) v_u_69
			v_u_33(v_u_70, p_u_63 + (p_u_64 - p_u_63) * (1 - (1 - p71) ^ 3), v_u_69 + (1 - v_u_69) * p71 ^ 1.5)
			if p71 >= 1 then
				v_u_70:Destroy()
			end
		end)
	end
	local function v_u_114(p_u_73, p_u_74, p_u_75, p_u_76, p_u_77, p_u_78, p_u_79, p80, p_u_81) -- name: flameArms
		-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_12, (ref) v_u_40, (ref) v_u_1, (copy) p_u_60
		local v_u_82 = math.random() * 3.141592653589793 * 2
		local v_u_83 = {}
		for v84 = 0, 2 do
			for v85 = 0, p_u_75 - 1 do
				local v86 = v85 / math.max(p_u_75, 1)
				local v87
				if v86 < 0.34 then
					v87 = v_u_9
				elseif v86 < 0.67 then
					v87 = v_u_8
				else
					v87 = v_u_12
				end
				local v88 = v_u_40(Vector3.new(p_u_79, 0.05, p_u_78), CFrame.new(p_u_73), v87)
				v_u_1:AddItem(v88, p80 + 0.1)
				table.insert(v_u_83, {
					["p"] = v88,
					["arm"] = v84,
					["seg"] = v85
				})
			end
		end
		local v_u_89 = p_u_74.UpVector
		p_u_60.animate(p80, 0, function(p90)
			-- upvalues: (copy) v_u_83, (copy) v_u_82, (copy) p_u_81, (copy) p_u_76, (copy) p_u_77, (copy) p_u_74, (copy) p_u_73, (copy) p_u_75, (copy) p_u_79, (copy) p_u_78, (copy) v_u_89
			for _, v91 in v_u_83 do
				local v92 = p90 * 1.15 - v91.seg * 0.07
				local v93 = 1 - (1 - math.clamp(v92, 0, 1)) ^ 2.2
				local v94 = v_u_82 + v91.arm * 3.141592653589793 * 2 / 3 + p_u_81 * v93
				local v95 = p_u_76 + (p_u_77 - p_u_76) * v93
				local v96 = p_u_74
				local v97 = math.cos(v94)
				local v98 = math.sin(v94)
				local v99 = v96:VectorToWorldSpace((Vector3.new(v97, 0, v98)))
				local v100 = p_u_74
				local v101 = -math.sin(v94)
				local v102 = math.cos(v94)
				local v103 = v100:VectorToWorldSpace((Vector3.new(v101, 0, v102)))
				local v104 = v99 * (p_u_77 - p_u_76) + v103 * v95 * p_u_81
				local v105 = p_u_73 + v99 * v95
				local v106 = (1 - p90 * 0.75) * (1 - v91.seg / (p_u_75 + 1) * 0.55)
				local v107 = v91.p
				local v108 = p_u_79 * v106
				local v109 = math.max(v108, 0.05)
				local v110 = p_u_78 * (0.6 + 0.4 * v106)
				local v111 = math.max(v110, 0.1)
				v107.Size = Vector3.new(v109, 0.05, v111)
				v91.p.CFrame = CFrame.lookAt(v105, v105 + v104, v_u_89)
				local v112 = v91.p
				local v113 = (p90 - 0.35) / 0.65
				v112.Transparency = math.clamp(v113, 0, 1)
				if p90 < 1 then
					continue
				end
				v91.p:Destroy()
			end
		end)
	end
	v61.nova_trinity_a = {
		["cast"] = function(p115) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_60, (ref) v_u_9, (copy) v_u_72, (ref) v_u_4, (ref) v_u_7
			local v116 = p115.size
			local v117 = p115.eye + p115.dir * 1.1
			v_u_5.flash(v117, v_u_8, 3.2 * v116, 0.12)
			p_u_60.pop(v117, v_u_9, 1.2 * v116, 0.3 * v116, 0.1)
			if not p115.lite then
				local v118 = v_u_72
				local v119 = p_u_60.facing
				local v120 = v_u_4.CurrentCamera
				local v121
				if v120 then
					local v122 = v120.CFrame.Position - v117
					v121 = v122.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v122.Unit
				else
					v121 = Vector3.new(0, 0, 1)
				end
				v118(v119(v117, v121), 0.4 * v116, 1.6 * v116, v_u_7.NovaTrinity, v_u_8, 0.14, 0)
			end
		end,
		["shot"] = function(p_u_123, p124) -- name: bladeShot
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_60, (ref) v_u_9, (ref) v_u_12, (ref) v_u_27, (ref) v_u_7, (ref) v_u_11, (ref) v_u_14, (ref) v_u_1, (ref) v_u_4
			local v_u_125 = p_u_123.size
			local v_u_126 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p124, v_u_8, {
				["transparency"] = 1
			})
			p_u_60.streak(v_u_126, v_u_9, v_u_12, 0.95 * v_u_125, p_u_123.lite and 0.12 or 0.2)
			local v_u_127 = v_u_27(p124, 2.4 * v_u_125, v_u_7.Glow, v_u_8, 0.25)
			local v_u_128 = v_u_27(p124, 1.7 * v_u_125, v_u_7.NovaTrinity, v_u_8, 0)
			local v129 = {
				["shape"] = v_u_14
			}
			local v_u_130 = v_u_5.part(Vector3.new(0.42, 0.42, 0.42) * v_u_125, p124, v_u_11, v129)
			local v_u_131 = { v_u_127, v_u_128, v_u_130 }
			local v_u_132, v_u_133, v_u_134
			if p_u_123.lite then
				v_u_132 = nil
				v_u_133 = nil
				v_u_134 = function() end
			else
				v_u_132 = v_u_27(p124, 0.55 * v_u_125, v_u_7.Ring, v_u_9, 0)
				v_u_133 = v_u_27(p124, 2.2 * v_u_125, v_u_7.Ring, v_u_8, 0.3)
				table.insert(v_u_131, v_u_132)
				table.insert(v_u_131, v_u_133)
				v_u_134 = p_u_60.loop("Trail", v_u_126, v_u_8, 0.3 * v_u_125)
			end
			for _, v135 in v_u_131 do
				v_u_1:AddItem(v135, 3)
			end
			v_u_1:AddItem(v_u_126, 3)
			if p_u_123.mine then
				p_u_60.light(v_u_126, v_u_8, 9 * v_u_125)
			end
			local v_u_136 = false
			return {
				["place"] = function(p137, p138) -- name: place
					-- upvalues: (copy) v_u_126, (ref) v_u_4, (ref) p_u_60, (copy) v_u_127, (copy) v_u_128, (copy) v_u_130, (ref) v_u_132, (ref) v_u_133, (copy) v_u_125
					v_u_126.CFrame = p137
					local v139 = p137.Position
					local v140 = v_u_4.CurrentCamera
					local v141
					if v140 then
						local v142 = v140.CFrame.Position - v139
						v141 = v142.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v142.Unit
					else
						v141 = Vector3.new(0, 0, 1)
					end
					local v143 = (v141 + Vector3.new(0, 0.9, 0)).Unit
					local v144 = p_u_60.facing(v139, v143)
					local v145 = v144 * CFrame.Angles(0, -p138 * 20, 0)
					v_u_127.CFrame = v144 * CFrame.new(0, -0.06, 0)
					v_u_128.CFrame = v145
					v_u_130.CFrame = CFrame.new(v139)
					local v146 = v_u_132
					if v146 then
						v146.CFrame = v145 * CFrame.new(0, 0.05, 0)
					end
					local v147 = v_u_133
					if v147 then
						v147.CFrame = v144 * CFrame.new(0, -0.03, 0)
						local v148 = 2.2 * v_u_125
						local v149 = p138 * 30
						local v150 = v148 * (math.sin(v149) * 0.08 + 1)
						local v151 = math.max(v150, 0.03) * 2
						v147.Size = Vector3.new(v151, 0.05, v151)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_136, (ref) v_u_134, (copy) v_u_131, (copy) v_u_126, (ref) v_u_1, (copy) p_u_123
					if not v_u_136 then
						v_u_136 = true
						v_u_134()
						for _, v152 in v_u_131 do
							v152:Destroy()
						end
						local v153 = v_u_126:FindFirstChildWhichIsA("PointLight")
						if v153 then
							v153:Destroy()
						end
						v_u_1:AddItem(v_u_126, p_u_123.lite and 0.2 or 0.8)
					end
				end
			}
		end,
		["impact"] = function(p154, p155) -- name: novaPop
			-- upvalues: (copy) p_u_60, (ref) v_u_4, (ref) v_u_11, (copy) v_u_72, (ref) v_u_7, (ref) v_u_8, (copy) v_u_114, (ref) v_u_9
			local v156 = p154.size
			local v157 = p_u_60.facing
			local v158 = v_u_4.CurrentCamera
			local v159
			if v158 then
				local v160 = v158.CFrame.Position - p155
				v159 = v160.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v160.Unit
			else
				v159 = Vector3.new(0, 0, 1)
			end
			local v161 = v157(p155, v159)
			p_u_60.pop(p155, v_u_11, 0.8 * v156, 4.2 * v156, 0.18)
			v_u_72(v161, 0.9 * v156, 4.6 * v156, v_u_7.Ring, v_u_8, 0.26, 0.05)
			p_u_60.burst("Impact", p155, v_u_8, 0.9 * v156)
			if not p154.lite then
				v_u_114(p155, v161, 1, 0.4 * v156, 3 * v156, 1.7 * v156, 0.6 * v156, 0.26, 1.1)
				p_u_60.glint(p155, v_u_9, 3.4 * v156, 0.16)
			end
			p_u_60.hitSound(p155)
		end,
		["hit"] = p_u_60.simpleHit(v_u_8, 0.55)
	}
	local v_u_162 = {}
	setmetatable(v_u_162, {
		["__mode"] = "k"
	})
	local v_u_163 = {}
	setmetatable(v_u_163, {
		["__mode"] = "k"
	})
	local function v_u_169(p164, p165) -- name: vortexBurst
		-- upvalues: (copy) p_u_60, (ref) v_u_11, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6
		local v166 = p164.ability.radius
		local v167 = p_u_60.ground(p165, 0)
		p_u_60.pop(p165, v_u_11, 2, 13, 0.3)
		p_u_60.burst("Explosion", p165, v_u_8, 1.2)
		v_u_5.ring(v167, v_u_9, v166 * 1.05, 0.4, v_u_7.Shockwave)
		if not p164.lite then
			local v168 = { v_u_9, v_u_8, v_u_11 }
			p_u_60.chunks(p165, v168, 10, 34, 0.9, 0.9, true)
		end
		v_u_6.play("Explosion", {
			["at"] = nil,
			["volume"] = 0.6,
			["at"] = v167
		})
	end
	local function v_u_240(p_u_170, p171, p172) -- name: plasmaVortex
		-- upvalues: (copy) p_u_60, (ref) v_u_8, (ref) v_u_9, (ref) v_u_40, (ref) v_u_1, (ref) v_u_5, (ref) v_u_11, (ref) v_u_15, (ref) v_u_7, (ref) v_u_27, (ref) v_u_50, (copy) v_u_169
		local v_u_173 = p_u_170.ability.radius
		local v174 = p_u_170.ability.freeze or 3
		local v_u_175 = p_u_170.lite and 3 or 5
		local v_u_176 = v174 + 0.35 + 1
		local v_u_177 = p_u_60.ground(p171, 0)
		local v_u_178 = {
			["a0"] = nil,
			["twisters"] = nil,
			["links"] = nil,
			["born"] = nil,
			["endAt"] = nil,
			["a0"] = p172,
			["twisters"] = {},
			["links"] = {},
			["born"] = os.clock()
		}
		for v179 = 0, 2 do
			local v180 = {}
			for v181 = 1, v_u_175 do
				local v182
				if v181 % 2 == 1 then
					v182 = v_u_8
				else
					v182 = v_u_9
				end
				local v183 = v_u_40(Vector3.new(0.1, 0.55, 0.1), CFrame.new(v_u_177), v182, 0.3)
				v_u_1:AddItem(v183, v_u_176)
				v180[v181] = v183
			end
			local v184 = {
				["shape"] = v_u_15
			}
			local v185 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_177), v_u_11, v184)
			v_u_1:AddItem(v185, v_u_176)
			local v186 = v_u_178.twisters
			local v187 = {
				["rings"] = v180,
				["core"] = v185,
				["phase"] = v179 * 2.1
			}
			table.insert(v186, v187)
		end
		if not p_u_170.lite then
			for v188 = 1, 3 do
				local v189 = v_u_178.twisters[v188].rings[v_u_175 - 1]
				local v190 = v_u_178.twisters[v188 % 3 + 1].rings[v_u_175 - 1]
				local v191 = Instance.new("Attachment")
				v191.Parent = v189
				local v192 = Instance.new("Attachment")
				v192.Parent = v190
				local v193 = Instance.new("Beam")
				v193.Attachment0 = v191
				v193.Attachment1 = v192
				v193.Texture = v_u_7.LightningArc
				v193.TextureMode = Enum.TextureMode.Stretch
				v193.TextureSpeed = 3
				v193.Color = ColorSequence.new(v_u_9, v_u_8)
				v193.LightEmission = 1
				v193.LightInfluence = 0
				v193.Brightness = 2
				v193.FaceCamera = true
				v193.Segments = 12
				v193.Width0 = 1.6
				v193.Width1 = 1.6
				v193.Parent = v189
				local v194 = v_u_178.links
				table.insert(v194, v193)
			end
		end
		local v_u_195 = v_u_27(CFrame.new(v_u_177 + Vector3.new(0, 0.2, 0)), v_u_173, v_u_7.Ring, v_u_9, 0.25)
		v_u_1:AddItem(v_u_195, v_u_176)
		p_u_60.mark(v_u_177, v_u_8, v_u_173 * 0.85, v174 + 0.5, v_u_7.Glow, 0.55)
		local v_u_196 = 0
		local v_u_197 = 0.4
		local v_u_198 = false
		p_u_60.runNow(function()
			-- upvalues: (copy) v_u_178, (copy) v_u_173, (copy) v_u_177, (copy) v_u_175, (ref) v_u_50, (copy) v_u_195, (ref) v_u_196, (copy) p_u_170, (ref) v_u_197, (ref) p_u_60, (ref) v_u_9, (ref) v_u_198, (ref) v_u_169, (ref) v_u_5, (ref) v_u_1, (copy) v_u_176
			local v199 = os.clock()
			local v200 = v199 - v_u_178.born
			local v201 = v200 / 0.3
			local v202 = math.clamp(v201, 0, 1) - 1
			local v203 = v202 * 2.9 * v202 * v202 + 1 + v202 * 1.9 * v202
			local v204 = v_u_178.endAt
			local v205
			if v204 then
				local v206 = (v199 - v204) / 0.35
				v205 = math.clamp(v206, 0, 1)
			else
				v205 = 0
			end
			local v207 = v_u_173 * 0.42
			local v208 = v200 * 3
			local v209 = v207 * (math.sin(v208) * 0.05 + 1) * (1 - v205 * v205)
			local v210 = v_u_178.a0 + v200 * 1.7 + v205 * v205 * 6
			for v211, v212 in v_u_178.twisters do
				local v213 = v210 + (v211 - 1) * 3.141592653589793 * 2 / 3
				local v214 = v_u_177
				local v215 = math.cos(v213)
				local v216 = math.sin(v213)
				local v217 = v214 + Vector3.new(v215, 0, v216) * v209
				for v218, v219 in v212.rings do
					local v220 = v218 / v_u_175
					local v221 = v203 * 15 * (v218 - 0.5) / v_u_175
					local v222 = v200 * 8 + v218 * 0.9 + v212.phase
					local v223 = math.cos(v222)
					local v224 = math.sin(v222)
					local v225 = Vector3.new(v223, 0, v224) * (v220 * 0.55 + 0.25)
					v219.CFrame = CFrame.new(v217 + v225 + Vector3.new(0, 1, 0) * v221) * CFrame.Angles(math.sin(v222) * 0.12, 0, math.cos(v222) * 0.12)
					local v226 = (v220 * 2.9 + 0.9) * v203 * (1 - v205 * 0.6)
					local v227 = math.max(v226, 0.05) * 2
					local v228 = v220 * 0.25 + 0.55
					v219.Size = Vector3.new(v227, v228, v227)
				end
				local v229 = v200 * 25 + v212.phase
				local v230 = (math.sin(v229) * 0.2 + 0.75) * v203 * (1 - v205)
				v_u_50(v212.core, v217, v217 + Vector3.new(0, 13.5, 0) * v203, v230)
			end
			v_u_195.CFrame = CFrame.new(v_u_177 + Vector3.new(0, 0.2, 0)) * CFrame.Angles(0, v200 * 0.8, 0)
			if v_u_196 <= v200 and #v_u_178.links > 0 then
				v_u_196 = v200 + 0.07
				for _, v231 in v_u_178.links do
					v231.CurveSize0 = (math.random() - 0.5) * 6
					v231.CurveSize1 = (math.random() - 0.5) * 6
					v231.Transparency = NumberSequence.new(v205 <= 0 and 0.15 or v205 * 0.8 + 0.2)
				end
			end
			if not p_u_170.lite and (v_u_197 <= v200 and not v204) then
				v_u_197 = v200 + 0.45
				local v232 = v_u_178.twisters[math.random(1, 3)]
				p_u_60.burst("Impact", v232.rings[v_u_175].Position, v_u_9, 0.8)
			end
			if not v204 or (v205 < 1 or v_u_198) then
				return v200 < v_u_176
			end
			v_u_198 = true
			v_u_169(p_u_170, v_u_177 + Vector3.new(0, 6.75, 0))
			for _, v233 in v_u_178.twisters do
				for _, v234 in v233.rings do
					v234:Destroy()
				end
				v233.core:Destroy()
			end
			local v235 = v_u_5.tween
			local v236 = v_u_195
			local v237 = {}
			local v238 = v_u_173 * 2.4
			local v239 = v_u_173 * 2.4
			v237.Size = Vector3.new(v238, 0.05, v239)
			v235(v236, 0.25, v237)
			v_u_1:AddItem(v_u_195, 0.3)
			return false
		end)
		p_u_60.after(v174, function()
			-- upvalues: (copy) v_u_178
			v_u_178.endAt = os.clock()
		end)
	end
	v61.nova_trinity_e = {
		["cast"] = function(p241) -- name: cast
			-- upvalues: (copy) p_u_60, (ref) v_u_8, (ref) v_u_9
			p_u_60.skillCast(p241, v_u_8)
			if not p241.lite then
				p_u_60.glint(p241.eye, v_u_9, 4 * p241.size, 0.2)
			end
		end,
		["windup"] = function(p242, p243, p244) -- name: windup
			-- upvalues: (copy) v_u_162, (copy) p_u_60, (ref) v_u_11, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			local v245 = math.random() * 3.141592653589793 * 2
			v_u_162[p242] = v245
			local v246 = p242.ability.radius
			for v247 = 0, 2 do
				local v248 = v245 + v247 * 3.141592653589793 * 2 / 3
				local v249 = p_u_60.ground(p243, 0)
				local v250 = math.cos(v248)
				local v251 = math.sin(v248)
				local v252 = v249 + Vector3.new(v250, 0, v251) * v246 * 0.42 + Vector3.new(0, 0.6, 0)
				p_u_60.pop(v252, v_u_11, 1, 4.5, math.max(p244, 0.08) + 0.12)
			end
			v_u_5.ring(p_u_60.ground(p243), v_u_9, v246, math.max(p244, 0.1) + 0.15, v_u_7.Ring)
		end,
		["land"] = function(p253, p254) -- name: land
			-- upvalues: (copy) v_u_162, (copy) v_u_240, (copy) p_u_60, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6
			local v255 = p253.ability.radius
			local v256 = v_u_162[p253] or math.random() * 3.141592653589793 * 2
			v_u_162[p253] = nil
			v_u_240(p253, p254, v256)
			local v257 = p_u_60.ground(p254)
			p_u_60.burst("Shockwave", v257 + Vector3.new(0, 0.3, 0), v_u_8, v255 / 18)
			v_u_5.ring(v257, v_u_9, v255 * 1.1, 0.35, v_u_7.SpeedLines)
			for v258 = 0, 2 do
				local v259 = p_u_60.burst
				local v260 = v256 + v258 * 3.141592653589793 * 2 / 3
				local v261 = p_u_60.ground(p254, 0)
				local v262 = math.cos(v260)
				local v263 = math.sin(v260)
				v259("Fire", v261 + Vector3.new(v262, 0, v263) * v255 * 0.42, v_u_8, 0.8)
			end
			v_u_6.play("Crit", {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v257
			})
			if p253.mine then
				v_u_5.shake(0.3, 0.25)
			end
		end,
		["hit"] = function(p264, p_u_265, p266) -- name: hit
			-- upvalues: (copy) p_u_60, (ref) v_u_8, (copy) v_u_163, (ref) v_u_5, (ref) v_u_9, (ref) v_u_14, (ref) v_u_1, (ref) v_u_12, (ref) v_u_4
			local v_u_267 = p264.ability.freeze or 3
			p_u_60.burst("Impact", p_u_265, v_u_8, 0.6)
			local v268 = (v_u_163[p264] or 0) + 1
			v_u_163[p264] = v268
			if not p264.lite and v268 <= 10 then
				local v_u_269 = {}
				for v270 = 1, 3 do
					local v271 = {
						["shape"] = v_u_14
					}
					local v272 = v_u_5.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(p_u_265), v_u_9, v271)
					v_u_1:AddItem(v272, v_u_267 + 0.5)
					p_u_60.streak(v272, v_u_9, v_u_12, 0.35, 0.18)
					v_u_269[v270] = v272
				end
				local v273 = v_u_4:FindFirstChild("MyEnemies")
				local v_u_274
				if v273 then
					v_u_274 = v273:FindFirstChild("Foe" .. p266)
				else
					v_u_274 = nil
				end
				local v_u_275 = os.clock()
				local v_u_276 = CFrame.Angles(0.5, math.random() * 6, 0.3)
				p_u_60.runNow(function()
					-- upvalues: (copy) v_u_275, (copy) v_u_274, (copy) v_u_267, (ref) p_u_60, (copy) p_u_265, (ref) v_u_9, (copy) v_u_269, (copy) v_u_276
					local v277 = os.clock() - v_u_275
					local v278
					if v_u_274 == nil then
						v278 = false
					else
						v278 = v_u_274.Parent == nil
					end
					if v_u_267 <= v277 or v278 then
						if not v278 then
							p_u_60.pop(p_u_265, v_u_9, 1, 3.5, 0.2)
						end
						for _, v279 in v_u_269 do
							v279:Destroy()
						end
						return false
					else
						local v280 = CFrame.new(p_u_265) * v_u_276
						for v281, v282 in v_u_269 do
							local v283 = v277 * 7 + (v281 - 1) * 3.141592653589793 * 2 / 3
							v282.CFrame = v280 * CFrame.new(math.cos(v283) * 1.9, 0, math.sin(v283) * 1.9)
						end
						return true
					end
				end)
			end
		end
	}
	local v_u_284 = {}
	setmetatable(v_u_284, {
		["__mode"] = "k"
	})
	local function v_u_385(p_u_285, p286) -- name: igniteStar
		-- upvalues: (copy) p_u_60, (ref) v_u_5, (ref) v_u_11, (ref) v_u_14, (ref) v_u_9, (ref) v_u_8, (ref) v_u_27, (ref) v_u_7, (ref) v_u_1, (ref) v_u_40, (ref) v_u_12, (ref) v_u_13, (ref) v_u_10, (ref) v_u_33, (ref) v_u_4
		local v_u_287 = p_u_60.ground(p286, 10)
		local v_u_288 = (p_u_285.ability.duration or 2.4) + 2
		local v289 = {
			["shape"] = v_u_14
		}
		local v_u_290 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_287), v_u_11, v289)
		local v291 = {
			["shape"] = nil,
			["transparency"] = 0.12,
			["shape"] = v_u_14
		}
		local v_u_292 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_287), v_u_9, v291)
		local v293 = {
			["shape"] = nil,
			["transparency"] = 0.6,
			["shape"] = v_u_14
		}
		local v_u_294 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_287), v_u_8, v293)
		local v_u_295 = v_u_27(CFrame.new(v_u_287), 0.05, v_u_7.Glow, v_u_8, 0.25)
		for _, v296 in {
			v_u_290,
			v_u_292,
			v_u_294,
			v_u_295
		} do
			v_u_1:AddItem(v296, v_u_288)
		end
		local v_u_297 = {
			["at"] = nil,
			["core"] = nil,
			["body"] = nil,
			["corona"] = nil,
			["glow"] = nil,
			["spikes"] = nil,
			["arms"] = nil,
			["born"] = nil,
			["collapseAt"] = nil,
			["dur"] = nil,
			["stopAt"] = nil,
			["done"] = false,
			["at"] = v_u_287,
			["core"] = v_u_290,
			["body"] = v_u_292,
			["corona"] = v_u_294,
			["glow"] = v_u_295,
			["spikes"] = {},
			["arms"] = {},
			["born"] = os.clock(),
			["dur"] = p_u_285.ability.duration or 2.4
		}
		if not p_u_285.lite then
			for v298 = 1, 10 do
				local v299 = math.random() - 0.5
				local v300 = math.random() - 0.5
				local v301 = math.random() - 0.5
				local v302 = Vector3.new(v299, v300, v301)
				local v303 = v302.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v302.Unit
				local v304 = v_u_40
				local v305 = Vector3.new(1, 1, 1)
				local v306 = CFrame.new(v_u_287)
				local v307
				if v298 % 2 == 0 then
					v307 = v_u_12
				else
					v307 = v_u_8
				end
				local v308 = v304(v305, v306, v307)
				v_u_1:AddItem(v308, v_u_288)
				local v309 = v_u_297.spikes
				local v310 = {
					["p"] = v308,
					["dir"] = v303,
					["len"] = 4.16 * (0.7 + math.random() * 0.6),
					["phase"] = math.random() * 6
				}
				table.insert(v309, v310)
			end
		end
		local v311 = p_u_285.lite and 2 or 4
		for v312 = 0, 2 do
			for v313 = 0, v311 - 1 do
				local v314 = v313 / v311
				local v315
				if v314 < 0.34 then
					v315 = v_u_8
				elseif v314 < 0.67 then
					v315 = v_u_12
				else
					v315 = v_u_13
				end
				local v316 = v_u_40(Vector3.new(1, 1, 1), CFrame.new(v_u_287), v315)
				v_u_1:AddItem(v316, v_u_288)
				local v317 = v_u_297.arms
				table.insert(v317, {
					["p"] = v316,
					["arm"] = v312,
					["seg"] = v313
				})
			end
		end
		local v_u_318 = 0
		p_u_60.runNow(function()
			-- upvalues: (copy) v_u_297, (copy) v_u_290, (ref) v_u_10, (copy) v_u_292, (copy) v_u_294, (ref) v_u_33, (copy) v_u_295, (ref) v_u_9, (ref) v_u_11, (ref) p_u_60, (copy) v_u_287, (ref) v_u_4, (ref) v_u_318, (copy) p_u_285, (ref) v_u_27, (ref) v_u_7, (ref) v_u_1, (copy) v_u_288
			local v319 = os.clock()
			local v320 = v319 - v_u_297.born
			if v_u_297.done then
				return false
			end
			local v321 = v320 / 0.28
			local v322 = math.clamp(v321, 0, 1) - 1
			local v323 = v322 * 2.9 * v322 * v322 + 1 + v322 * 1.9 * v322
			local v324 = v_u_297.collapseAt
			local v325
			if v324 then
				local v326 = (v319 - v324) / v_u_297.dur
				v325 = math.clamp(v326, 0, 1)
			else
				v325 = 0
			end
			local v327 = v323 * (1 - v325 ^ 2.4 * 0.94)
			local v328 = v320 * 19
			local v329 = math.sin(v328) * 0.035 + 1
			local v330 = v320 * 31
			local v331 = v327 * (v329 + math.sin(v330) * 0.02)
			local v332 = v331 * 13
			local v333 = v_u_297.stopAt ~= nil
			if v333 then
				local v334 = v320 * 40
				local v335 = math.sin(v334)
				local v336 = math.abs(v335) * 0.5 + 0.9
				v_u_290.Size = Vector3.new(1, 1, 1) * v336
				v_u_290.Color = v_u_10
				v_u_292.Transparency = 1
				v_u_294.Transparency = 1
				v_u_33(v_u_295, v336 + 3, 0.2)
			else
				local v337 = v_u_290
				local v338 = v332 * (v325 * 0.3 + 0.55)
				v337.Size = Vector3.new(1, 1, 1) * math.max(v338, 0.3)
				v_u_292.Size = Vector3.new(1, 1, 1) * math.max(v332, 0.3)
				v_u_292.Color = v_u_9:Lerp(v_u_11, v325)
				local v339 = v_u_294
				local v340 = v332 * (1.35 - v325 * 0.2)
				v339.Size = Vector3.new(1, 1, 1) * math.max(v340, 0.3)
				v_u_294.Transparency = v325 * 0.3 + 0.6
				v_u_33(v_u_295, v332 * (v325 * 0.6 + 1.25), 0.25 - v325 * 0.15)
			end
			local v341 = v_u_295
			local v342 = p_u_60.facing
			local v343 = v_u_287
			local v344 = v_u_287
			local v345 = v_u_4.CurrentCamera
			local v346
			if v345 then
				local v347 = v345.CFrame.Position - v344
				v346 = v347.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v347.Unit
			else
				v346 = Vector3.new(0, 0, 1)
			end
			v341.CFrame = v342(v343, v346) * CFrame.new(0, -v332 * 0.7, 0)
			for _, v348 in v_u_297.spikes do
				local v349 = v348.len * v331
				local v350 = v320 * 14 + v348.phase
				local v351 = v349 * (math.sin(v350) * 0.4 + 0.6) * (1 - v325)
				if v333 or v351 < 0.1 then
					v348.p.Transparency = 1
				else
					local v352 = v_u_287 + v348.dir * v332 * 0.45
					local v353 = v348.p
					local v354 = v332 * 0.12
					local v355 = v332 * 0.12
					v353.Size = Vector3.new(v354, v355, v351)
					v348.p.CFrame = CFrame.lookAt(v352 + v348.dir * v351 * 0.4, v352 + v348.dir * v351)
					v348.p.Transparency = 0.1
				end
			end
			local v356 = p_u_60.facing
			local v357 = v_u_287
			local v358 = v_u_287
			local v359 = v_u_4.CurrentCamera
			local v360
			if v359 then
				local v361 = v359.CFrame.Position - v358
				v360 = v361.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v361.Unit
			else
				v360 = Vector3.new(0, 0, 1)
			end
			local v362 = v356(v357, (v360 + Vector3.new(0, 0.35, 0)).Unit)
			local v363 = v320 * 2.2 + v325 ^ 2 * 9 * v_u_297.dur / 3
			for _, v364 in v_u_297.arms do
				if v333 then
					v364.p.Transparency = 1
				else
					local v365 = v363 + v364.arm * 3.141592653589793 * 2 / 3 - v364.seg * 0.3
					local v366 = v332 * (v364.seg * 0.17 + 0.72)
					local v367 = math.cos(v365)
					local v368 = math.sin(v365)
					local v369 = v362:VectorToWorldSpace((Vector3.new(v367, 0, v368)))
					local v370 = -math.sin(v365)
					local v371 = math.cos(v365)
					local v372 = v362:VectorToWorldSpace((Vector3.new(v370, 0, v371)))
					local v373 = v_u_287 + v369 * v366
					local v374 = 1 - v364.seg * 0.18
					local v375 = v364.p
					local v376 = v332 * 0.2 * v374
					local v377 = v332 * 0.55 * v374
					v375.Size = Vector3.new(v376, 0.05, v377)
					v364.p.CFrame = CFrame.lookAt(v373, v373 + v372 - v369 * 0.35, v362.UpVector)
					v364.p.Transparency = v364.seg * 0.08 + 0.05
				end
			end
			if v324 and (not v333 and v_u_318 <= v320) then
				v_u_318 = v320 + (p_u_285.ability.tick or 0.4)
				local v_u_378 = p_u_285.ability.radius
				local v_u_379 = v_u_27(CFrame.new(p_u_60.ground(v_u_287, 0.25)), v_u_378 * 1.3, v_u_7.Ring, v_u_9, 0.8)
				v_u_1:AddItem(v_u_379, 0.45)
				p_u_60.animate(0.4, 0, function(p380)
					-- upvalues: (ref) v_u_33, (copy) v_u_379, (copy) v_u_378
					v_u_33(v_u_379, v_u_378 * 1.3 * (1 - p380) + 0.5, 0.8 - 0.65 * p380)
					if p380 >= 1 then
						v_u_379:Destroy()
					end
				end)
				if not p_u_285.lite then
					local v381 = p_u_60.inward
					local v382 = v_u_287
					local v383 = v_u_9
					local v384 = v332 * 1.7
					v381(v382, v383, 5, math.max(v384, 6), 0.35)
				end
			end
			return v320 < v_u_288
		end)
		return v_u_297
	end
	local function v_u_389(p386) -- name: endStar
		p386.done = true
		p386.core:Destroy()
		p386.body:Destroy()
		p386.corona:Destroy()
		p386.glow:Destroy()
		for _, v387 in p386.spikes do
			v387.p:Destroy()
		end
		for _, v388 in p386.arms do
			v388.p:Destroy()
		end
	end
	local function v_u_401(p390, p391) -- name: supernova
		-- upvalues: (copy) p_u_60, (ref) v_u_4, (ref) v_u_10, (ref) v_u_8, (copy) v_u_72, (ref) v_u_7, (ref) v_u_9, (copy) v_u_114, (ref) v_u_5, (ref) v_u_11, (ref) v_u_12, (ref) v_u_6, (ref) v_u_59
		local v392 = p390.ability.radius
		local v393 = p_u_60.ground(p391, 10)
		local v394 = p_u_60.ground(p391, 0)
		local v395 = p_u_60.facing
		local v396 = v_u_4.CurrentCamera
		local v397
		if v396 then
			local v398 = v396.CFrame.Position - v393
			v397 = v398.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v398.Unit
		else
			v397 = Vector3.new(0, 0, 1)
		end
		local v399 = v395(v393, v397)
		p_u_60.pop(v393, v_u_10, 2, 42, 0.42)
		p_u_60.pop(v393, v_u_8, 4, 36, 0.6, 0.45)
		p_u_60.dome(p391, v392 * 1.5, v_u_8, 0.75)
		v_u_72(v399, 2, v392 * 2, v_u_7.Ring, v_u_9, 0.55, 0)
		v_u_114(v393, v399, p390.lite and 3 or 5, 1, v392 * 1.5, 7, 3.2, 0.75, 1.4)
		if not p390.lite then
			v_u_114(p_u_60.ground(p391, 2), CFrame.new(v394), 4, 1, v392 * 1.7, 6, 2.6, 0.7, -1.2)
		end
		v_u_5.ring(v394, v_u_11, v392 * 1.6, 0.45, v_u_7.Shockwave)
		v_u_5.ring(v394, v_u_8, v392 * 2.2, 0.7, v_u_7.Ring)
		p_u_60.burst("Shockwave", v394 + Vector3.new(0, 0.3, 0), v_u_8, v392 / 12)
		p_u_60.burst("Explosion", v393, v_u_8, 2.4)
		p_u_60.burst("Explosion", v393, v_u_12, 1.6)
		p_u_60.mark(p391, v_u_12, v392 * 1.1, 2.5, v_u_7.CrackGlow, 0.2)
		if not p390.lite then
			local v400 = { v_u_9, v_u_8, v_u_11 }
			p_u_60.chunks(v393, v400, 14, 45, 1.2, 1.2, true)
			p_u_60.spikes(v393, v_u_9, 10, v392 * 1.1, 0.4)
		end
		v_u_6.play("Explosion", {
			["at"] = nil,
			["volume"] = 1,
			["at"] = v394
		})
		if p390.mine then
			v_u_5.shake(0.6, 0.5)
			v_u_59(Color3.fromRGB(255, 236, 210), 0.18, 0, 0.04, 0.05, 0.45)
		end
	end
	v61.nova_trinity_r = {
		["castSound"] = "Charge",
		["loopSound"] = "Vortex",
		["cast"] = nil,
		["windup"] = nil,
		["zone"] = nil,
		["finish"] = nil,
		["hit"] = nil,
		["cast"] = function(p402) -- name: cast
			-- upvalues: (copy) p_u_60, (ref) v_u_8, (ref) v_u_9, (ref) v_u_59
			p_u_60.skillCast(p402, v_u_8, true)
			p_u_60.glint(p402.eye, v_u_9, 5 * p402.size, 0.25)
			if p402.mine then
				local v403 = (p402.ability.delay or 0.2) + (p402.ability.duration or 2.4)
				v_u_59(Color3.fromRGB(255, 222, 196), -0.1, 0.16, 0.3, v403 - 0.4, 0.3)
			end
		end,
		["windup"] = function(p404, p405, _) -- name: windup
			-- upvalues: (copy) v_u_284, (copy) v_u_385, (copy) p_u_60, (ref) v_u_9
			v_u_284[p404] = v_u_385(p404, p405)
			p_u_60.burst("Explosion", p_u_60.ground(p405, 10), v_u_9, 1)
		end,
		["zone"] = function(p406, p407, p408) -- name: zone
			-- upvalues: (copy) v_u_284, (copy) v_u_385, (copy) p_u_60, (ref) v_u_8, (ref) v_u_7
			local v_u_409 = v_u_284[p406] or v_u_385(p406, p407)
			v_u_284[p406] = v_u_409
			v_u_409.collapseAt = os.clock()
			v_u_409.dur = math.max(p408, 0.3)
			p_u_60.mark(p407, v_u_8, p406.ability.radius, p408 + 0.3, v_u_7.Glow, 0.5)
			return function()
				-- upvalues: (copy) v_u_409
				v_u_409.stopAt = os.clock()
			end
		end,
		["finish"] = function(p410, p411) -- name: finish
			-- upvalues: (copy) v_u_284, (copy) v_u_389, (copy) v_u_401
			local v412 = v_u_284[p410]
			v_u_284[p410] = nil
			if v412 then
				v_u_389(v412)
			end
			v_u_401(p410, p411)
		end,
		["hit"] = function(_, p413, _) -- name: hit
			-- upvalues: (copy) p_u_60, (ref) v_u_8
			p_u_60.burst("Impact", p413, v_u_8, 0.6)
		end
	}
	return v61
end