local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_2 = require(script.Parent:WaitForChild("ZoomController"))
local v_u_3 = v1.getUserFlag("UserFixCameraFPError")
local v_u_4 = {}
v_u_4.__index = v_u_4
local v_u_5 = CFrame.new()
function v_u_4.new() -- name: new
	-- upvalues: (copy) v_u_4
	local v6 = v_u_4
	return setmetatable({
		["lastCFrame"] = nil
	}, v6)
end
function v_u_4.Step(p7, p8, p9) -- name: Step
	-- upvalues: (copy) v_u_5
	local v10 = p7.lastCFrame or p9
	p7.lastCFrame = p9
	local v_u_11 = p9.Position
	local _, _, _, v12, v13, v14, v15, v16, v17, v18, v19, v20 = p9:GetComponents()
	local v_u_21 = CFrame.new(0, 0, 0, v12, v13, v14, v15, v16, v17, v18, v19, v20)
	local v22 = v10.Position
	local _, _, _, v23, v24, v25, v26, v27, v28, v29, v30, v31 = v10:GetComponents()
	local v32 = CFrame.new(0, 0, 0, v23, v24, v25, v26, v27, v28, v29, v30, v31)
	local v_u_33 = (v_u_11 - v22) / p8
	local v34, v35 = (v_u_21 * v32:inverse()):ToAxisAngle()
	local v_u_36 = v34 * v35 / p8
	return {
		["extrapolate"] = function(p37) -- name: extrapolate
			-- upvalues: (copy) v_u_33, (copy) v_u_11, (copy) v_u_36, (ref) v_u_5, (copy) v_u_21
			local v38 = v_u_33 * p37 + v_u_11
			local v39 = v_u_36 * p37
			local v40 = v39.Magnitude
			local v41
			if v40 > 0.00001 then
				v41 = CFrame.fromAxisAngle(v39, v40)
			else
				v41 = v_u_5
			end
			return v41 * v_u_21 + v38
		end,
		["posVelocity"] = v_u_33,
		["rotVelocity"] = v_u_36
	}
end
function v_u_4.Reset(p42) -- name: Reset
	p42.lastCFrame = nil
end
local v_u_43 = require(script.Parent:WaitForChild("BaseOcclusion"))
local v_u_44 = setmetatable({}, v_u_43)
v_u_44.__index = v_u_44
function v_u_44.new() -- name: new
	-- upvalues: (copy) v_u_43, (copy) v_u_44, (copy) v_u_4
	local v45 = v_u_43.new()
	local v46 = v_u_44
	local v47 = setmetatable(v45, v46)
	v47.focusExtrapolator = v_u_4.new()
	return v47
end
function v_u_44.GetOcclusionMode(_) -- name: GetOcclusionMode
	return Enum.DevCameraOcclusionMode.Zoom
end
function v_u_44.Enable(p48, _) -- name: Enable
	p48.focusExtrapolator:Reset()
end
function v_u_44.Update(p49, p50, p51, p52, _) -- name: Update
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v53
	if v_u_3 then
		v53 = CFrame.lookAlong(p52.Position, -p51.LookVector) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	else
		v53 = CFrame.new(p52.Position, p51.Position) * CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1)
	end
	local v54 = p49.focusExtrapolator:Step(p50, v53)
	local v55 = v_u_2.Update(p50, v53, v54)
	return v53 * CFrame.new(0, 0, v55), p52
end
function v_u_44.CharacterAdded(_, _, _) -- name: CharacterAdded end
function v_u_44.CharacterRemoving(_, _, _) -- name: CharacterRemoving end
function v_u_44.OnCameraSubjectChanged(_, _) -- name: OnCameraSubjectChanged end
return v_u_44