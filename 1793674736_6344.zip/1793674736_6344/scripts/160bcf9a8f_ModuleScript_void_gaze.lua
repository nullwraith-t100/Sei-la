local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(214, 246, 255)
local v_u_7 = Color3.new(1, 1, 1)
local v_u_8 = CFrame.Angles(0, 0, 1.5707963267948966)
local function v_u_14(p9, p10) -- name: facing
	local v11 = p10.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or p10.Unit
	local v12 = v11.Y
	local v13 = math.abs(v12) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p9, p9 + v11, v13) * CFrame.Angles(-1.5707963267948966, 0, 0)
end
return function(p_u_15)
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_1, (copy) v_u_5, (copy) v_u_14, (copy) v_u_8, (copy) v_u_7, (copy) v_u_4
	return {
		["w5_void_gaze"] = function(p_u_16, p17)
			-- upvalues: (ref) v_u_3, (ref) v_u_6, (ref) v_u_1, (copy) p_u_15, (ref) v_u_5, (ref) v_u_14, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4
			local v_u_18 = v_u_3.color(p17.color)
			local v19 = v_u_3.color(p17.color2)
			local v20 = p_u_16.headY / 1.5
			local v_u_21 = math.clamp(v20, 0.7, 3)
			local v_u_22 = v_u_21 * 0.74
			local v_u_23 = v_u_21 * 2.5
			local v_u_24 = {}
			local v_u_25 = {}
			v_u_24[1] = CFrame.identity
			v_u_25[1] = 0
			v_u_24[2] = CFrame.identity
			v_u_25[2] = 0
			v_u_24[3] = CFrame.identity
			v_u_25[3] = 0
			v_u_24[4] = CFrame.identity
			v_u_25[4] = 0
			local v_u_26 = 0
			local v_u_27 = 2.2
			local v_u_28 = -10
			local v_u_29 = true
			local function v_u_42(p30, p31, p32) -- name: shoot
				-- upvalues: (copy) v_u_21, (ref) v_u_3, (ref) v_u_6, (ref) v_u_1, (copy) v_u_18, (ref) p_u_15, (copy) p_u_16, (ref) v_u_5
				local v33 = p31 + p32 * 14 * v_u_21
				local v34 = (v33 - p31).Magnitude
				local v35 = v_u_3.part
				local v36 = v_u_21 * 0.35
				local v37 = v_u_21 * 0.35
				local v38 = v35(Vector3.new(v36, v37, v34), CFrame.lookAt((p31 + v33) / 2, v33), v_u_6)
				local v39 = v_u_3.tween
				local v40 = {
					["Size"] = nil,
					["Transparency"] = 1
				}
				local v41 = v34 * 1.2
				v40.Size = Vector3.new(0.02, 0.02, v41)
				v39(v38, 0.4, v40)
				v_u_1:AddItem(v38, 0.45)
				v_u_3.flash(p31, v_u_18, v_u_21 * 3.2, 0.3)
				v_u_3.flash(v33, v_u_6, v_u_21 * 2.6, 0.4)
				v_u_3.ring(p_u_15.feetAt(p_u_16, p30, 0.15), v_u_18, 5 * p_u_16.fx, 0.5, v_u_5.Ring)
			end
			local v43 = p_u_16.ticks
			local function v76(p44, p45, p46)
				-- upvalues: (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_26, (copy) p_u_16, (ref) p_u_15, (copy) v_u_23, (copy) v_u_21, (ref) v_u_14, (copy) v_u_24, (copy) v_u_25, (copy) v_u_42
				if v_u_27 <= p45 then
					v_u_27 = p45 + 4.6
					v_u_28 = p45
					v_u_29 = false
				end
				local v47 = p45 - v_u_28
				if v47 < 0.35 then
					local v48 = v47 / 0.35
					local v49 = math.clamp(v48, 0, 1)
					v_u_26 = v49 * v49 * (3 - v49 * 2)
				elseif v47 < 1 then
					v_u_26 = 1
				elseif v47 < 1.4 then
					local v50 = (v47 - 0.35 - 0.65) / 0.4
					local v51 = math.clamp(v50, 0, 1)
					v_u_26 = 1 - v51 * v51 * (3 - v51 * 2)
				else
					v_u_26 = 0
				end
				local v52 = p44.Position + Vector3.new(0, 1, 0) * (p_u_16.headY + p_u_16.eyeLift)
				local v53 = p44.LookVector.X
				local v54 = p44.LookVector.Z
				local v55 = Vector3.new(v53, 0, v54)
				local v56 = ((v55.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v55.Unit) * 0.7 + Vector3.new(0, 0.72, 0)).Unit
				local v57 = p_u_15.camPos()
				for v58 = 1, 4 do
					local v59 = p45 * 0.55 + (v58 - 1) * 3.141592653589793 * 2 / 4
					local v60 = p44.Position
					local v61 = math.cos(v59)
					local v62 = math.sin(v59) * 0.25
					local v63 = math.sin(v59)
					local v64 = v60 + Vector3.new(v61, v62, v63) * v_u_23
					local v65 = v_u_21 * 0.45
					local v66 = p45 * 1.6 + v58 * 1.7
					local v67 = v64 + Vector3.new(0, 1, 0) * (v65 + math.sin(v66) * 0.15 * v_u_21)
					local v68 = v_u_14(v67, v57 - v67)
					local v69 = v_u_14(v52 + v56 * (v_u_21 * 1.5 + (v58 - 1) * 1.5 * v_u_21), v56)
					local v70 = v_u_24
					if v_u_26 <= 0 then
						v69 = v68
					elseif v_u_26 < 1 then
						v69 = v68:Lerp(v69, v_u_26)
					end
					v70[v58] = v69
					local v71
					if v47 >= 0 and v47 < 1 then
						local v72 = v47 - ((v58 - 1) * 0.08 + 0.43)
						local v73 = 1 - math.abs(v72) / 0.08
						v71 = math.max(v73, 0)
					else
						v71 = 0
					end
					v_u_25[v58] = v71
				end
				local v74 = p_u_16
				local v75 = p_u_16.pulse - p46 * 1.8
				v74.pulse = math.max(v75, 0)
				if not v_u_29 and v47 >= 0.77 then
					v_u_29 = true
					p_u_16.pulse = 1
					if (p44.Position - v57).Magnitude < 150 then
						v_u_42(p44, v52 + v56 * (v_u_21 * 1.5 + v_u_21 * 4.5), v56)
					end
				end
			end
			table.insert(v43, v76)
			local v77 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v_u_18, {
				["transparency"] = 1
			})
			p_u_15.add(p_u_16, v77, function(p78)
				-- upvalues: (copy) p_u_16
				return CFrame.new(p78.Position + Vector3.new(0, 1, 0) * (p_u_16.headY + p_u_16.eyeLift))
			end)
			local v79 = Instance.new("Attachment")
			v79.Parent = v77
			local v_u_80 = v_u_26
			local v_u_81 = {}
			local v_u_82 = {}
			local v_u_83 = {}
			local v_u_84 = {}
			for v_u_85 = 1, 4 do
				local v86 = p_u_15.disc
				local v87 = v_u_21 * 0.06
				local v88 = v_u_22 * 1.95
				local v89 = v_u_22 * 1.95
				local v90 = v86(Vector3.new(v87, v88, v89), v_u_18, 0.25)
				p_u_15.add(p_u_16, v90, function()
					-- upvalues: (copy) v_u_24, (copy) v_u_85, (ref) v_u_8
					return v_u_24[v_u_85] * v_u_8
				end)
				local v91 = p_u_15.picture(v_u_22 * 2.35, v_u_5.Ring, v19, 0)
				p_u_15.add(p_u_16, v91, function()
					-- upvalues: (copy) v_u_24, (copy) v_u_85, (copy) v_u_21
					return v_u_24[v_u_85] * CFrame.new(0, v_u_21 * 0.04, 0)
				end)
				local v92 = p_u_15.picture(v_u_22 * 1.85, v_u_5.VoidCross, v_u_7, 0)
				p_u_15.add(p_u_16, v92, function(_, p93)
					-- upvalues: (copy) v_u_24, (copy) v_u_85, (copy) v_u_21
					return v_u_24[v_u_85] * CFrame.new(0, v_u_21 * 0.08, 0) * CFrame.Angles(0, p93 * 0.8 + v_u_85, 0)
				end)
				v_u_83[v_u_85] = v90
				v_u_84[v_u_85] = v91
				v_u_82[v_u_85] = v92
				local v94 = Instance.new("Attachment")
				v94.Parent = v90
				local v95 = p_u_15.ray(v94, v79, v_u_18, v_u_21 * 0.07, v_u_21 * 0.03, v_u_5.Beam)
				v95.Transparency = NumberSequence.new(0.55)
				v_u_81[v_u_85] = v95
			end
			local v_u_96 = {}
			local v_u_97 = -1
			local v98 = p_u_16.ticks
			local function v116()
				-- upvalues: (copy) v_u_83, (copy) v_u_25, (copy) v_u_96, (copy) v_u_18, (ref) v_u_7, (ref) v_u_80, (ref) v_u_97, (copy) v_u_21, (copy) v_u_22, (copy) v_u_84, (copy) v_u_82, (copy) v_u_81
				for v99, v100 in v_u_83 do
					local v101 = v_u_25[v99]
					if v101 == v_u_96[v99] then
						continue
					end
					v_u_96[v99] = v101
					v100.Color = v_u_18:Lerp(v_u_7, v101)
					v100.Transparency = 0.25 - v101 * 0.2
				end
				if v_u_80 ~= v_u_97 then
					v_u_97 = v_u_80
					local v102 = NumberSequence.new(v_u_80 * 0.45 + 0.55)
					for v103 = 1, 4 do
						local v104 = (v103 - 1) * 0.3 * v_u_80 + 1
						local v105 = v_u_83[v103]
						local v106 = v_u_21 * 0.06
						local v107 = v_u_22 * 1.95 * v104
						local v108 = v_u_22 * 1.95 * v104
						v105.Size = Vector3.new(v106, v107, v108)
						local v109 = v_u_84[v103]
						local v110 = v_u_22 * 2.35 * v104
						local v111 = v_u_22 * 2.35 * v104
						v109.Size = Vector3.new(v110, 0.05, v111)
						local v112 = v_u_82[v103]
						local v113 = v_u_22 * 1.85 * v104
						local v114 = v_u_22 * 1.85 * v104
						v112.Size = Vector3.new(v113, 0.05, v114)
					end
					for _, v115 in v_u_81 do
						v115.Transparency = v102
					end
				end
			end
			table.insert(v98, v116)
			local v117 = v_u_3.part(Vector3.new(5, 6.5, 5) * v_u_21, CFrame.identity, v_u_18, {
				["transparency"] = 1
			})
			p_u_15.add(p_u_16, v117, function(p118)
				-- upvalues: (copy) v_u_21
				return CFrame.new(p118.Position + Vector3.new(0, 0.6, 0) * v_u_21)
			end)
			local v119 = Instance.new("ParticleEmitter")
			v119.Texture = v_u_5.VoidCross
			v119.Color = ColorSequence.new(v_u_18, v_u_6)
			v119.LightEmission = 0.6
			v119.LightInfluence = 0
			v119.Lifetime = NumberRange.new(0.8, 1.3)
			v119.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.4, v_u_21 * 0.32 * p_u_16.fx), NumberSequenceKeypoint.new(1, 0) })
			v119.Rotation = NumberRange.new(0, 90)
			v119.RotSpeed = NumberRange.new(-40, 40)
			v119.Speed = NumberRange.new(0.3, 0.8)
			v119.SpreadAngle = Vector2.new(180, 180)
			v119.Shape = Enum.ParticleEmitterShape.Box
			v119.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v119:SetAttribute("BaseRate", 3)
			v119.Rate = 3 * v_u_4.formRate()
			v119.Parent = v117
			p_u_15.own(p_u_16, v117)
			p_u_15.particles(p_u_16, "AuraMode", v_u_18, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_15.particles(p_u_16, "Petals", v_u_6, {
				["rate"] = 0.6,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end