local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.BiwaString,
	v_u_7.BiwaBachi,
	v_u_7.BiwaShoji,
	v_u_7.BiwaCorridor
})
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FF6FB8")
local v_u_10 = Color3.fromRGB(255, 176, 220)
local v_u_11 = Color3.fromHex("2A1030")
local v_u_12 = Color3.fromRGB(26, 10, 18)
local v_u_13 = Color3.fromRGB(70, 30, 26)
local v_u_14 = Enum.Material.SmoothPlastic
local function v_u_47(p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v26 = p21 + p22 + p23
	local v27 = math.max(v26, 0.05)
	local v28 = {}
	local v29 = {}
	for v30 = 0, 10 do
		local v31 = v30 / 10
		local v32 = v31 * v27
		local v33 = v32 / math.max(p21, 0.001)
		local v34 = 1 - (1 - math.clamp(v33, 0, 1)) ^ 3
		local v35 = (v32 - p21 - p22) / math.max(p23, 0.001)
		local v36 = math.clamp(v35, 0, 1)
		local v37 = v36 * v36 * (3 - v36 * 2)
		local v38 = NumberSequenceKeypoint.new
		local v39 = p16 + (p17 - p16) * v34
		local v40 = math.max(v39, 0.05) / 2
		table.insert(v29, v38(v31, v40))
		local v41 = NumberSequenceKeypoint.new
		local v42 = p20 + (1 - p20) * v37
		local v43 = math.clamp(v42, 0, 1)
		table.insert(v28, v41(v31, v43))
	end
	local v44 = Instance.new("Attachment")
	v44.WorldCFrame = CFrame.new(p15)
	v44.Parent = v_u_3.Terrain
	local v45 = Instance.new("ParticleEmitter")
	v45.Enabled = false
	v45.Texture = p18
	v45.Color = ColorSequence.new(p19)
	v45.LightEmission = p25 or 0
	v45.LightInfluence = 0
	v45.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v45.EmissionDirection = Enum.NormalId.Top
	v45.SpreadAngle = Vector2.zero
	v45.Speed = NumberRange.new(0.01)
	v45.Size = NumberSequence.new(v29)
	v45.Transparency = NumberSequence.new(v28)
	v45.Lifetime = NumberRange.new(v27)
	local v46 = p24 or math.random(0, 359)
	v45.Rotation = NumberRange.new(v46, v46)
	v45.Parent = v44
	v45:Emit(1)
	v_u_1:AddItem(v44, v27 + 0.2)
end
local function v_u_59(p48, p49, p50, p51, p52, p53, p54, p55) -- name: spritePop
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v56 = Instance.new("Attachment")
	v56.WorldPosition = p48
	v56.Parent = v_u_3.Terrain
	local v57 = Instance.new("ParticleEmitter")
	v57.Enabled = false
	v57.Texture = p49
	v57.Color = ColorSequence.new(p50)
	v57.LightEmission = p54 or 0
	v57.LightInfluence = 0
	v57.Speed = NumberRange.new(0)
	v57.Lifetime = NumberRange.new(p53)
	v57.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p51 / 2), NumberSequenceKeypoint.new(0.3, (p51 + (p52 - p51) * 0.8) / 2), NumberSequenceKeypoint.new(1, p52 / 2) })
	v57.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.1), NumberSequenceKeypoint.new(1, 1) })
	local v58 = p55 or math.random(0, 359)
	v57.Rotation = NumberRange.new(v58, v58)
	v57.Parent = v56
	v57:Emit(1)
	v_u_1:AddItem(v56, p53 + 0.2)
end
local function v_u_68(p60, p61, p62) -- name: door
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_14, (copy) v_u_7, (copy) v_u_1
	local v63 = {
		["material"] = v_u_14
	}
	local v64 = v_u_4.part(Vector3.new(p60, p61, 0.25), CFrame.new(0, -500, 0), v_u_12, v63)
	for _, v65 in { Enum.NormalId.Front, Enum.NormalId.Back } do
		local v66 = Instance.new("SurfaceGui")
		v66.Face = v65
		v66.LightInfluence = 0
		v66.Brightness = 1.3
		v66.SizingMode = Enum.SurfaceGuiSizingMode.PixelsPerStud
		v66.PixelsPerStud = 20
		local v67 = Instance.new("ImageLabel")
		v67.Size = UDim2.fromScale(1, 1)
		v67.BackgroundTransparency = 1
		v67.Image = v_u_7.BiwaShoji
		v67.ScaleType = Enum.ScaleType.Stretch
		v67.Parent = v66
		v66.Parent = v64
	end
	v_u_1:AddItem(v64, p62)
	return v64
end
return function(p_u_69)
	-- upvalues: (copy) v_u_59, (copy) v_u_7, (copy) v_u_9, (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_10, (copy) v_u_11, (copy) v_u_47, (copy) v_u_68, (copy) v_u_12, (copy) v_u_13, (copy) v_u_6, (copy) v_u_14
	local v222 = {
		["biwa_castle_a"] = {
			["windup"] = function(p70, _, _) -- name: windup
				-- upvalues: (ref) v_u_59, (ref) v_u_7, (ref) v_u_9
				v_u_59(p70.eye + p70.dir * 0.9, v_u_7.BiwaBachi, v_u_9, 1, 2.4 * p70.size, 0.16, 0.3)
			end,
			["beam"] = function(p71, p_u_72, p_u_73) -- name: beam
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_10, (ref) v_u_9, (copy) p_u_69, (ref) v_u_59, (ref) v_u_11
				local v_u_74 = p71.size
				local v75 = p_u_73 - p_u_72
				local v_u_76 = v75.Magnitude
				if v_u_76 >= 0.5 then
					local v_u_77 = v75.Unit
					local v_u_78 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p_u_72), v_u_8, {
						["transparency"] = 1
					})
					v_u_1:AddItem(v_u_78, 0.7)
					local v_u_79 = {}
					for _, v80 in p71.lite and { 0 } or { -0.55, 0, 0.55 } do
						local v81 = Instance.new("Attachment")
						v81.Parent = v_u_78
						local v82 = Instance.new("Attachment")
						v82.Parent = v_u_78
						local v83 = Instance.new("Beam")
						v83.Attachment0 = v81
						v83.Attachment1 = v82
						v83.Texture = v_u_7.BiwaString
						v83.TextureMode = Enum.TextureMode.Stretch
						local v84 = ColorSequence.new
						local v85
						if v80 == 0 then
							v85 = v_u_10
						else
							v85 = v_u_9
						end
						v83.Color = v84(v85)
						v83.LightEmission = 0.7
						v83.LightInfluence = 0
						v83.FaceCamera = true
						v83.Segments = 16
						v83.Width0 = 0.32 * v_u_74
						v83.Width1 = 0.32 * v_u_74
						v83.Parent = v81
						local v86 = {
							["a0"] = v81,
							["a1"] = v82,
							["b"] = v83,
							["y"] = v80 * v_u_74
						}
						table.insert(v_u_79, v86)
					end
					p_u_69.animate(0.32, 0, function(p87)
						-- upvalues: (copy) v_u_74, (copy) v_u_79, (copy) p_u_72, (copy) v_u_77, (copy) v_u_76, (copy) v_u_78
						local v88 = p87 / 0.2
						local v89 = math.min(v88, 1)
						local v90 = 0.9 * v_u_74 * (1 - p87)
						local v91 = p87 * 60
						local v92 = v90 * math.sin(v91)
						for v93, v94 in v_u_79 do
							local v95 = p_u_72 + Vector3.new(0, 1, 0) * v94.y
							local v96 = v95 + v_u_77 * v_u_76 * v89
							v94.a0.WorldCFrame = CFrame.fromMatrix(v95, Vector3.new(0, 1, 0), v_u_77:Cross(Vector3.new(0, 1, 0)))
							v94.a1.WorldCFrame = CFrame.fromMatrix(v96, Vector3.new(0, 1, 0), v_u_77:Cross(Vector3.new(0, 1, 0)))
							local v97 = v92 * (v93 % 2 == 0 and -1 or 1)
							v94.b.CurveSize0 = v97
							v94.b.CurveSize1 = -v97
							local v98 = 0.32 * v_u_74
							local v99 = (p87 - 0.6) / 0.4
							local v100 = math.clamp(v99, 0, 1)
							local v101 = v98 * (1 - v100 * v100 * (3 - v100 * 2))
							v94.b.Width0 = v101
							v94.b.Width1 = v101
						end
						if p87 >= 1 then
							v_u_78:Destroy()
						end
					end)
					p_u_69.after(0.06, function()
						-- upvalues: (ref) v_u_59, (copy) p_u_73, (ref) v_u_7, (ref) v_u_9, (copy) v_u_74, (ref) v_u_4, (ref) p_u_69, (ref) v_u_11
						v_u_59(p_u_73 + Vector3.new(0, 0.4, 0), v_u_7.BiwaBachi, v_u_9, 1.5 * v_u_74, 4.5 * v_u_74, 0.25, 0.3)
						v_u_4.ring(p_u_69.ground(p_u_73, 0.12), v_u_11, 2.6 * v_u_74, 0.25, v_u_7.Ring)
						v_u_4.ring(p_u_69.ground(p_u_73, 0.16), v_u_9, 3.8 * v_u_74, 0.35, v_u_7.Ring)
					end)
				end
			end,
			["hit"] = function(_, p102, _) -- name: hit
				-- upvalues: (copy) p_u_69, (ref) v_u_9
				p_u_69.burst("Impact", p102, v_u_9, 0.6)
			end
		},
		["biwa_castle_e"] = {
			["cast"] = function(p103) -- name: cast
				-- upvalues: (copy) p_u_69, (ref) v_u_9, (ref) v_u_59, (ref) v_u_7, (ref) v_u_10
				p_u_69.skillCast(p103, v_u_9)
				v_u_59(p103.eye + p103.dir, v_u_7.BiwaBachi, v_u_10, 1.5 * p103.size, 4 * p103.size, 0.25, 0.3)
			end,
			["windup"] = function(p104, p105, p106) -- name: windup
				-- upvalues: (copy) p_u_69, (ref) v_u_47, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9
				local v107 = p104.size
				local v108 = p104.ability.radius * v107
				local v109 = p_u_69.ground(p105, 0.12)
				local v110 = p106 + (p104.ability.duration or 1.6)
				local v111 = p_u_69.flatUnit(p105 - p104.origin)
				local v112 = v111.X
				local v113 = v111.Z
				local v114 = math.atan2(v112, v113)
				local v115 = math.deg(v114)
				v_u_47(v109, v108, v108 * 2.6, v_u_7.Glow, v_u_11, 0.3, 0.2, v110, 0.3, nil, 0)
				v_u_47(v109, v108 * 0.6, v108 * 2.3, v_u_7.BiwaCorridor, v_u_9, 0.1, 0.25, v110, 0.3, v115, 0.25)
			end,
			["zone"] = function(p_u_116, p117, p_u_118) -- name: zone
				-- upvalues: (copy) p_u_69, (ref) v_u_68, (ref) v_u_4, (ref) v_u_9, (ref) v_u_7, (ref) v_u_59, (ref) v_u_10, (ref) v_u_1
				local v_u_119 = p_u_116.size
				local v_u_120 = p_u_116.ability.radius * v_u_119
				local v_u_121 = p_u_69.ground(p117, 0)
				local v_u_122 = p_u_116.ability.tick or 0.32
				local v123 = p_u_69.flatUnit(p117 - p_u_116.origin)
				local v_u_124 = 6.5 * v_u_119
				local v_u_125
				if p_u_116.lite then
					v_u_125 = 2 * v_u_120
				else
					v_u_125 = v_u_120
				end
				local v126 = p_u_116.lite and { 0 } or { -1, 1 }
				local v_u_127 = {}
				for v128 = 0, 3 do
					local v129 = CFrame.Angles(0, v128 * 3.141592653589793 / 2, 0):VectorToWorldSpace(v123)
					local v130 = (Vector3.new(0, 1, 0)):Cross(v129)
					for _, v131 in v126 do
						local v132 = {
							["p"] = v_u_68(v_u_125, v_u_124, p_u_118 + 1),
							["n"] = v129,
							["side"] = v130,
							["lane"] = v131
						}
						table.insert(v_u_127, v132)
					end
				end
				local v_u_133 = os.clock()
				local v_u_134 = true
				local v_u_135 = 0
				p_u_69.frame(function()
					-- upvalues: (ref) v_u_134, (copy) v_u_133, (copy) v_u_120, (copy) p_u_118, (copy) v_u_122, (ref) v_u_135, (ref) v_u_4, (copy) v_u_121, (ref) v_u_9, (ref) v_u_7, (copy) p_u_116, (copy) v_u_127, (ref) v_u_59, (copy) v_u_124, (ref) v_u_10, (copy) v_u_119, (copy) v_u_125
					if not v_u_134 then
						return false
					end
					local v136 = os.clock() - v_u_133
					local v137 = v136 / 0.2
					local v138 = 1 - (1 - math.clamp(v137, 0, 1)) ^ 3
					local v139 = v_u_120
					local v140 = v136 / p_u_118
					local v141 = math.clamp(v140, 0, 1)
					local v142 = v139 * (1 - v141 * v141 * (3 - v141 * 2) * 0.35)
					local v143 = v136 % v_u_122 / v_u_122
					local v144
					if v143 < 0.55 then
						local v145 = v143 / 0.55
						local v146 = math.clamp(v145, 0, 1)
						v144 = v146 * v146 * (3 - v146 * 2)
					else
						v144 = 1 - ((v143 - 0.55) / 0.45) ^ 2
					end
					local v147 = v136 / v_u_122
					local v148 = math.floor(v147)
					if v_u_135 < v148 then
						v_u_135 = v148
						v_u_4.ring(v_u_121 + Vector3.new(0, 0.2, 0), v_u_9, v142 * 1.1, 0.25, v_u_7.Ring)
						if not p_u_116.lite then
							for _, v149 in v_u_127 do
								if v149.lane ~= 1 then
									continue
								end
								v_u_59(v_u_121 + v149.n * v142 + Vector3.new(0, 1, 0) * v_u_124 * 0.5, v_u_7.BiwaBachi, v_u_10, 2 * v_u_119, 6 * v_u_119, 0.2, 0.4)
							end
						end
					end
					for _, v150 in v_u_127 do
						local v151 = v150.lane
						local v152 = v_u_125 * 0.5
						local v153 = v_u_125 * 0.7 * v144
						local v154 = v150.lane
						local v155 = v151 * (v152 + v153 * math.abs(v154))
						local v156 = v_u_121 + v150.n * v142 + v150.side * v155 + Vector3.new(0, 1, 0) * (v_u_124 * 0.5 - v_u_124 * (1 - v138))
						v150.p.CFrame = CFrame.lookAt(v156, v156 - v150.n)
					end
					return true
				end)
				return function()
					-- upvalues: (ref) v_u_134, (copy) v_u_127, (ref) v_u_4, (copy) v_u_124, (ref) v_u_1
					v_u_134 = false
					for _, v157 in v_u_127 do
						local v158 = v157.p.CFrame
						v_u_4.tween(v157.p, 0.2, {
							["CFrame"] = v158 - Vector3.new(0, 1, 0) * v_u_124
						}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
						v_u_1:AddItem(v157.p, 0.25)
					end
				end
			end,
			["finish"] = function(p159, p160) -- name: finish
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_10, (ref) v_u_9, (ref) v_u_47, (ref) v_u_7, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (ref) v_u_6
				local v161 = p159.size
				local v162 = p159.ability.radius * v161
				local v163 = p_u_69.ground(p160, 0.15)
				v_u_4.flash(v163 + Vector3.new(0, 2, 0), v_u_10, 8 * v161, 0.16)
				v_u_4.flash(v163 + Vector3.new(0, 2, 0), v_u_9, v162 * 1.4, 0.35)
				v_u_47(v163, v162 * 0.5, v162 * 2.6, v_u_7.BiwaCorridor, v_u_11, 0, 0.1, 0.25, 0.4, nil, 0)
				v_u_47(v163, v162, v162 * 3, v_u_7.BiwaCorridor, v_u_9, 0, 0.15, 0.1, 0.4, nil, 0.4)
				v_u_4.ring(v163, v_u_11, v162 * 1.1, 0.45, v_u_7.Shockwave)
				v_u_4.ring(v163, v_u_9, v162 * 1.4, 0.55, v_u_7.Ring)
				if not p159.lite then
					local v164 = { v_u_12, v_u_9, v_u_13 }
					p_u_69.chunks(v163 + Vector3.new(0, 0.6, 0), v164, 8, 24, 0.5 * v161, 0.8, false, 1)
				end
				v_u_6.play("Explosion", {
					["at"] = v163,
					["volume"] = p159.mine and 0.75 or 0.4
				})
				if p159.mine then
					v_u_4.shake(0.3, 0.25)
				end
			end,
			["hit"] = function(_, p165, _) -- name: hit
				-- upvalues: (copy) p_u_69, (ref) v_u_9
				p_u_69.burst("Impact", p165, v_u_9, 0.6)
			end
		},
		["biwa_castle_r"] = {
			["cast"] = function(p166) -- name: cast
				-- upvalues: (copy) p_u_69, (ref) v_u_9
				p_u_69.skillCast(p166, v_u_9, true)
			end,
			["windup"] = function(p167, p168, p169) -- name: windup
				-- upvalues: (copy) p_u_69, (ref) v_u_47, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9
				local v170 = p167.size
				local v171 = p167.ability.radius * v170
				local v172 = p_u_69.ground(p168, 0.12)
				local v173 = p_u_69.flatUnit(p168 - p167.origin)
				local v174 = v173.X
				local v175 = v173.Z
				local v176 = math.atan2(v174, v175)
				local v177 = math.deg(v176)
				v_u_47(v172, v171, v171 * 3.6, v_u_7.Glow, v_u_11, 0.25, math.max(p169, 0.1), 0.9, 0.4, nil, 0)
				v_u_47(v172, v171 * 0.8, v171 * 1.75, v_u_7.BiwaCorridor, v_u_9, 0, math.max(p169, 0.1), 0.35, 0.3, v177, 0.3)
			end,
			["land"] = function(p_u_178, p179) -- name: land
				-- upvalues: (copy) p_u_69, (ref) v_u_4, (ref) v_u_13, (ref) v_u_14, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) v_u_10, (ref) v_u_11, (ref) v_u_47, (ref) v_u_12, (ref) v_u_59, (ref) v_u_6
				local v_u_180 = p_u_178.size
				local v_u_181 = p_u_178.ability.radius * v_u_180
				local v_u_182 = v_u_181 * 0.85
				local v_u_183 = p_u_69.ground(p179, 0)
				local v_u_184 = p_u_69.flatUnit(p179 - p_u_178.origin)
				local v_u_185 = 0.9 * v_u_180
				local v_u_186 = {}
				for v187 = 0, 3 do
					local v188 = CFrame.Angles(0, v187 * 3.141592653589793 / 2, 0):VectorToWorldSpace(v_u_184)
					local v189 = CFrame.fromMatrix(v_u_183 + v188 * v_u_182, (Vector3.new(0, 1, 0)):Cross(v188), Vector3.new(0, 1, 0))
					local v190 = v_u_4.part
					local v191 = 2 * v_u_182
					local v192 = {
						["material"] = v_u_14
					}
					local v193 = v190(Vector3.new(v191, v_u_185, v_u_182), CFrame.new(0, -500, 0), v_u_13, v192)
					if not p_u_178.lite then
						local v194 = Instance.new("Texture")
						v194.Face = Enum.NormalId.Bottom
						v194.Texture = v_u_7.BiwaShoji
						v194.StudsPerTileU = 3.2 * v_u_180
						v194.StudsPerTileV = 6.4 * v_u_180
						v194.Parent = v193
					end
					local v195 = v_u_4.part
					local v196 = 2 * v_u_182
					local v197 = v_u_185 * 0.5
					local v198 = v_u_185 * 0.5
					local v199 = v195(Vector3.new(v196, v197, v198), CFrame.new(0, -500, 0), v_u_9)
					v_u_1:AddItem(v193, 1.7)
					v_u_1:AddItem(v199, 1.7)
					table.insert(v_u_186, {
						["p"] = v193,
						["edge"] = v199,
						["hinge"] = v189
					})
				end
				local v_u_200 = os.clock()
				local v_u_201 = false
				p_u_69.frame(function()
					-- upvalues: (copy) v_u_200, (copy) v_u_186, (copy) v_u_185, (copy) v_u_180, (copy) v_u_182, (ref) v_u_201, (ref) v_u_4, (copy) v_u_183, (ref) v_u_10, (ref) v_u_9, (copy) v_u_181, (ref) v_u_11, (ref) v_u_7, (copy) v_u_184, (ref) v_u_47, (copy) p_u_178, (ref) p_u_69, (ref) v_u_12, (ref) v_u_13, (ref) v_u_59, (ref) v_u_6
					local v202 = os.clock() - v_u_200
					local v203 = v202 / 0.34
					local v204 = math.clamp(v203, 0, 1)
					local v205 = 3.141592653589793 * v204 * v204
					local v206 = (v202 - 0.34 - 0.35) / 0.4
					local v207 = math.clamp(v206, 0, 1)
					local v208 = v207 * v207 * (3 - v207 * 2)
					for _, v209 in v_u_186 do
						local v210 = v209.hinge * CFrame.Angles(-v205, 0, 0)
						v209.p.CFrame = v210 * CFrame.new(0, v_u_185 * 0.5 - v208 * 3 * v_u_180, v_u_182 * 0.5)
						v209.edge.CFrame = v210 * CFrame.new(0, v_u_185 * 0.5 - v208 * 3 * v_u_180, v_u_182)
						v209.p.Transparency = v208
						v209.edge.Transparency = v208
					end
					if v204 >= 1 and not v_u_201 then
						v_u_201 = true
						v_u_4.flash(v_u_183 + Vector3.new(0, 2, 0), v_u_10, 10 * v_u_180, 0.18)
						v_u_4.flash(v_u_183 + Vector3.new(0, 2, 0), v_u_9, v_u_181 * 1.5, 0.4)
						v_u_4.ring(v_u_183 + Vector3.new(0, 0.2, 0), v_u_11, v_u_181 * 1.1, 0.5, v_u_7.Shockwave)
						v_u_4.ring(v_u_183 + Vector3.new(0, 0.25, 0), v_u_9, v_u_181 * 1.5, 0.6, v_u_7.Ring)
						local v211 = v_u_184.X
						local v212 = v_u_184.Z
						local v213 = math.atan2(v211, v212)
						local v214 = math.deg(v213)
						v_u_47(v_u_183 + Vector3.new(0, 0.1, 0), v_u_181, v_u_181 * 3.2, v_u_7.BiwaCorridor, v_u_9, 0, 0.12, 0.15, 0.5, v214, 0.4)
						if not p_u_178.lite then
							local v215 = {
								v_u_12,
								v_u_9,
								v_u_13,
								v_u_10
							}
							p_u_69.chunks(v_u_183 + Vector3.new(0, 1, 0), v215, 12, 34, 0.6 * v_u_180, 1, false, 1.2)
							for _ = 1, 4 do
								local v216 = math.random() * 3.141592653589793 * 2
								local v217 = v_u_183
								local v218 = math.cos(v216)
								local v219 = math.sin(v216)
								v_u_59(v217 + Vector3.new(v218, 0, v219) * v_u_181 * 0.9 + Vector3.new(0, 1.5, 0), v_u_7.BiwaBachi, v_u_10, 2 * v_u_180, 7 * v_u_180, 0.3, 0.4)
							end
						end
						v_u_6.play("Explosion", {
							["at"] = v_u_183,
							["volume"] = p_u_178.mine and 0.9 or 0.5
						})
						if p_u_178.mine then
							v_u_4.shake(0.45, 0.35)
						end
					end
					if v202 < 1.4 then
						return true
					end
					for _, v220 in v_u_186 do
						v220.p:Destroy()
						v220.edge:Destroy()
					end
					return false
				end)
			end,
			["hit"] = function(_, p221, _) -- name: hit
				-- upvalues: (copy) p_u_69, (ref) v_u_9
				p_u_69.burst("Impact", p221, v_u_9, 0.8)
			end
		}
	}
	return v222
end