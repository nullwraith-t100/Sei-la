local v_u_1 = {
	["WORLD_NAME"] = "Shinobi Lands",
	["PURPLE_PAD"] = 3,
	["list"] = {
		{
			["index"] = 1,
			["theme"] = "leaf",
			["name"] = "Leaf Village",
			["recommended"] = 10,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 3,
			["boss"] = nil,
			["enemies"] = { "leaf_genin", "leaf_scout" }
		},
		{
			["index"] = 2,
			["theme"] = "bamboo",
			["name"] = "Bamboo Grove",
			["recommended"] = 60,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 12,
			["boss"] = nil,
			["enemies"] = { "bamboo_bandit", "panda_brawler" }
		},
		{
			["index"] = 3,
			["theme"] = "blossom",
			["name"] = "Cherry Blossom Hill",
			["recommended"] = 400,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 50,
			["boss"] = "sakura_kitsune",
			["enemies"] = { "blossom_ronin", "sakura_spirit" }
		},
		{
			["index"] = 4,
			["theme"] = "desert",
			["name"] = "Sand Dunes",
			["recommended"] = 2500,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 150,
			["boss"] = nil,
			["enemies"] = { "sand_golem", "dune_mummy" }
		},
		{
			["index"] = 5,
			["theme"] = "canyon",
			["name"] = "Red Canyon",
			["recommended"] = 15000,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 500,
			["boss"] = nil,
			["enemies"] = { "canyon_bandit", "canyon_scorpion" }
		},
		{
			["index"] = 6,
			["theme"] = "palace",
			["name"] = "Desert Palace",
			["recommended"] = 90000,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 1500,
			["boss"] = "sand_pharaoh",
			["enemies"] = { "jackal_warrior", "palace_guard" }
		},
		{
			["index"] = 7,
			["theme"] = "snow",
			["name"] = "Snow Peaks",
			["recommended"] = 550000,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 5000,
			["boss"] = nil,
			["enemies"] = { "snow_ninja", "frost_wolf" }
		},
		{
			["index"] = 8,
			["theme"] = "ice",
			["name"] = "Ice Cavern",
			["recommended"] = 3300000,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 15000,
			["boss"] = nil,
			["enemies"] = { "ice_wraith", "yeti" }
		},
		{
			["index"] = 9,
			["theme"] = "frost",
			["name"] = "Frozen Temple",
			["recommended"] = 20000000,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 50000,
			["boss"] = "glacier_king",
			["enemies"] = { "frost_knight", "frost_monk" }
		},
		{
			["index"] = 10,
			["theme"] = "volcano",
			["name"] = "Volcano",
			["recommended"] = 120000000,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 150000,
			["boss"] = nil,
			["enemies"] = { "magma_golem", "fire_oni" }
		},
		{
			["index"] = 11,
			["theme"] = "swamp",
			["name"] = "Poison Swamp",
			["recommended"] = 740000000,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 400000,
			["boss"] = nil,
			["enemies"] = { "swamp_lurker", "bog_beast" }
		},
		{
			["index"] = 12,
			["theme"] = "shadow",
			["name"] = "Shadow Forest",
			["recommended"] = 4500000000,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 1000000,
			["boss"] = "shadow_reaper",
			["enemies"] = { "shadow_ninja", "shade_stalker" }
		},
		{
			["index"] = 13,
			["theme"] = "crystal",
			["name"] = "Crystal Cave",
			["recommended"] = 18000000000,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 2500000,
			["boss"] = nil,
			["enemies"] = { "crystal_crawler", "crystal_golem" }
		},
		{
			["index"] = 14,
			["theme"] = "sky",
			["name"] = "Sky Temple",
			["recommended"] = 80000000000,
			["enemies"] = nil,
			["count"] = 8,
			["wins"] = 5000000,
			["boss"] = nil,
			["enemies"] = { "storm_spirit", "sky_tengu" }
		},
		{
			["index"] = 15,
			["theme"] = "fortress",
			["name"] = "Crimson Fortress",
			["recommended"] = 400000000000,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 10000000,
			["boss"] = "crimson_shogun",
			["enemies"] = { "crimson_samurai", "oni_assassin" }
		}
	},
	["WORLD2_NAME"] = "Celestial Realm",
	["world2"] = {
		{
			["index"] = 1,
			["theme"] = "moonmeadow",
			["name"] = "Moonlit Meadow",
			["recommended"] = 800000000000,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 20000000,
			["boss"] = nil,
			["enemies"] = { "moon_monk", "night_fox" }
		},
		{
			["index"] = 2,
			["theme"] = "lotuslake",
			["name"] = "Lotus Lake",
			["recommended"] = 40000000000000,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 260000000,
			["boss"] = nil,
			["enemies"] = { "lotus_guard", "koi_spirit" }
		},
		{
			["index"] = 3,
			["theme"] = "jadegarden",
			["name"] = "Jade Garden",
			["recommended"] = 280000000000000,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 960000000,
			["boss"] = "jade_emperor",
			["enemies"] = { "jade_warrior", "jade_lion" }
		},
		{
			["index"] = 4,
			["theme"] = "mushroom",
			["name"] = "Glowshroom Forest",
			["recommended"] = 2000000000000000,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 3500000000,
			["boss"] = nil,
			["enemies"] = { "shroom_brute", "spore_imp" }
		},
		{
			["index"] = 5,
			["theme"] = "coral",
			["name"] = "Coral Reef",
			["recommended"] = 1.4e16,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 12000000000,
			["boss"] = nil,
			["enemies"] = { "coral_knight", "reef_shark" }
		},
		{
			["index"] = 6,
			["theme"] = "clockwork",
			["name"] = "Clockwork Ruins",
			["recommended"] = 9.6e16,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 45000000000,
			["boss"] = "clockwork_titan",
			["enemies"] = { "gear_soldier", "brass_hound" }
		},
		{
			["index"] = 7,
			["theme"] = "obsidian",
			["name"] = "Obsidian Wastes",
			["recommended"] = 6.7e17,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 160000000000,
			["boss"] = nil,
			["enemies"] = { "obsidian_golem", "glass_wraith" }
		},
		{
			["index"] = 8,
			["theme"] = "aurora",
			["name"] = "Aurora Tundra",
			["recommended"] = 4.7e18,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 590000000000,
			["boss"] = nil,
			["enemies"] = { "aurora_yeti", "polar_spirit" }
		},
		{
			["index"] = 9,
			["theme"] = "thunder",
			["name"] = "Thunder Plateau",
			["recommended"] = 3.3e19,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 2100000000000,
			["boss"] = "raijin",
			["enemies"] = { "storm_oni", "thunder_beast" }
		},
		{
			["index"] = 10,
			["theme"] = "sunforge",
			["name"] = "Sun Forge",
			["recommended"] = 2.3e20,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 7700000000000,
			["boss"] = nil,
			["enemies"] = { "forge_smith", "solar_golem" }
		},
		{
			["index"] = 11,
			["theme"] = "abyss",
			["name"] = "Abyssal Rift",
			["recommended"] = 1.6e21,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 28000000000000,
			["boss"] = nil,
			["enemies"] = { "abyss_lurker", "rune_wraith" }
		},
		{
			["index"] = 12,
			["theme"] = "spiritwood",
			["name"] = "Spirit Woods",
			["recommended"] = 1.1e22,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 100000000000000,
			["boss"] = "elder_spirit",
			["enemies"] = { "spirit_archer", "ghost_stag" }
		},
		{
			["index"] = 13,
			["theme"] = "starfall",
			["name"] = "Starfall Crater",
			["recommended"] = 7.9e22,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 360000000000000,
			["boss"] = nil,
			["enemies"] = { "star_drifter", "meteor_golem" }
		},
		{
			["index"] = 14,
			["theme"] = "heavengate",
			["name"] = "Heaven\'s Gate",
			["recommended"] = 5.5e23,
			["enemies"] = nil,
			["count"] = 8,
			["wins"] = 1300000000000000,
			["boss"] = nil,
			["enemies"] = { "gate_guardian", "seraph_knight" }
		},
		{
			["index"] = 15,
			["theme"] = "voidthrone",
			["name"] = "Void Throne",
			["recommended"] = 3.9e24,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 4700000000000000,
			["boss"] = "void_king",
			["enemies"] = { "void_samurai", "void_assassin" }
		}
	},
	["WORLD3_NAME"] = "Blood Moon",
	["world3"] = {
		{
			["index"] = 1,
			["theme"] = "ashfield",
			["name"] = "Ash Fields",
			["recommended"] = 8e24,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 1e16,
			["boss"] = nil,
			["enemies"] = { "ash_ghoul", "cinder_crow" }
		},
		{
			["index"] = 2,
			["theme"] = "bloodlake",
			["name"] = "Blood Lake",
			["recommended"] = 4e26,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 1.3e17,
			["boss"] = nil,
			["enemies"] = { "blood_kappa", "blood_bat" }
		},
		{
			["index"] = 3,
			["theme"] = "boneyard",
			["name"] = "Bone Yard",
			["recommended"] = 2.8e27,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 4.8e17,
			["boss"] = "bone_shogun",
			["enemies"] = { "skeleton_samurai", "bone_hound" }
		},
		{
			["index"] = 4,
			["theme"] = "redbamboo",
			["name"] = "Crimson Bamboo",
			["recommended"] = 2e28,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 1.75e18,
			["boss"] = nil,
			["enemies"] = { "red_ninja", "mantis_blade" }
		},
		{
			["index"] = 5,
			["theme"] = "magmariver",
			["name"] = "Magma River",
			["recommended"] = 1.4e29,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 6e18,
			["boss"] = nil,
			["enemies"] = { "magma_imp", "lava_salamander" }
		},
		{
			["index"] = 6,
			["theme"] = "cursedshrine",
			["name"] = "Cursed Shrine",
			["recommended"] = 9.6e29,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 2.25e19,
			["boss"] = "shrine_oni",
			["enemies"] = { "cursed_monk", "mask_spirit" }
		},
		{
			["index"] = 7,
			["theme"] = "thornwood",
			["name"] = "Thorn Woods",
			["recommended"] = 6.7e30,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 8e19,
			["boss"] = nil,
			["enemies"] = { "thorn_beast", "briar_witch" }
		},
		{
			["index"] = 8,
			["theme"] = "ruinedcastle",
			["name"] = "Ruined Castle",
			["recommended"] = 4.7e31,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 2.95e20,
			["boss"] = nil,
			["enemies"] = { "ghost_ronin", "gargoyle" }
		},
		{
			["index"] = 9,
			["theme"] = "eclipseplaza",
			["name"] = "Eclipse Plaza",
			["recommended"] = 3.3e32,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 1.05e21,
			["boss"] = "eclipse_priest",
			["enemies"] = { "eclipse_cultist", "shadow_wolf" }
		},
		{
			["index"] = 10,
			["theme"] = "bloodfalls",
			["name"] = "Blood Falls",
			["recommended"] = 2.3e33,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 3.85e21,
			["boss"] = nil,
			["enemies"] = { "crimson_naga", "blood_golem" }
		},
		{
			["index"] = 11,
			["theme"] = "demongate",
			["name"] = "Demon Gate",
			["recommended"] = 1.6e34,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 1.4e22,
			["boss"] = nil,
			["enemies"] = { "demon_guard", "hellhound" }
		},
		{
			["index"] = 12,
			["theme"] = "moonaltar",
			["name"] = "Moon Altar",
			["recommended"] = 1.1e35,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 5e22,
			["boss"] = "blood_moon_queen",
			["enemies"] = { "moon_cultist", "lunar_wraith" }
		},
		{
			["index"] = 13,
			["theme"] = "netherforge",
			["name"] = "Nether Forge",
			["recommended"] = 7.9e35,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 1.8e23,
			["boss"] = nil,
			["enemies"] = { "infernal_smith", "chain_demon" }
		},
		{
			["index"] = 14,
			["theme"] = "redmoonpeak",
			["name"] = "Red Moon Peak",
			["recommended"] = 5.5e36,
			["enemies"] = nil,
			["count"] = 8,
			["wins"] = 6.5e23,
			["boss"] = nil,
			["enemies"] = { "moon_tengu", "blood_drake" }
		},
		{
			["index"] = 15,
			["theme"] = "bloodpalace",
			["name"] = "Blood Moon Palace",
			["recommended"] = 3.9e37,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 2.35e24,
			["boss"] = "blood_moon_king",
			["enemies"] = { "vampire_knight", "crimson_assassin" }
		}
	},
	["WORLD4_NAME"] = "Frozen Abyss",
	["world4"] = {
		{
			["index"] = 1,
			["theme"] = "frostfield",
			["name"] = "Frost Fields",
			["recommended"] = 8e37,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 5e24,
			["boss"] = nil,
			["enemies"] = { "frost_imp", "snow_hare" }
		},
		{
			["index"] = 2,
			["theme"] = "frozenlake",
			["name"] = "Frozen Lake",
			["recommended"] = 4e39,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 6.5e25,
			["boss"] = nil,
			["enemies"] = { "ice_kappa", "frost_seal" }
		},
		{
			["index"] = 3,
			["theme"] = "glacierpass",
			["name"] = "Glacier Pass",
			["recommended"] = 2.8e40,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 2.4e26,
			["boss"] = "glacier_titan",
			["enemies"] = { "glacier_golem", "frost_ram" }
		},
		{
			["index"] = 4,
			["theme"] = "crystalpines",
			["name"] = "Crystal Pines",
			["recommended"] = 2e41,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 8.75e26,
			["boss"] = nil,
			["enemies"] = { "pine_spirit", "ice_lynx" }
		},
		{
			["index"] = 5,
			["theme"] = "bluecaverns",
			["name"] = "Blue Caverns",
			["recommended"] = 1.4e42,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 3e27,
			["boss"] = nil,
			["enemies"] = { "cave_yeti", "icicle_bat" }
		},
		{
			["index"] = 6,
			["theme"] = "frozenwreck",
			["name"] = "Frozen Wreck",
			["recommended"] = 9.6e42,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 1.125e28,
			["boss"] = "frost_captain",
			["enemies"] = { "frozen_pirate", "ice_shark" }
		},
		{
			["index"] = 7,
			["theme"] = "abyssaltrench",
			["name"] = "Abyssal Trench",
			["recommended"] = 6.7e43,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 4e28,
			["boss"] = nil,
			["enemies"] = { "angler", "abyss_squid" }
		},
		{
			["index"] = 8,
			["theme"] = "sunkenruins",
			["name"] = "Sunken Ruins",
			["recommended"] = 4.7e44,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 1.475e29,
			["boss"] = nil,
			["enemies"] = { "drowned_knight", "eel_serpent" }
		},
		{
			["index"] = 9,
			["theme"] = "icepalace",
			["name"] = "Ice Palace",
			["recommended"] = 3.3e45,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 5.25e29,
			["boss"] = "snow_empress",
			["enemies"] = { "ice_maiden", "frost_guard" }
		},
		{
			["index"] = 10,
			["theme"] = "blizzardridge",
			["name"] = "Blizzard Ridge",
			["recommended"] = 2.3e46,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 1.925e30,
			["boss"] = nil,
			["enemies"] = { "storm_yeti", "blizzard_spirit" }
		},
		{
			["index"] = 11,
			["theme"] = "frozenrift",
			["name"] = "Frozen Rift",
			["recommended"] = 1.6e47,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 7e30,
			["boss"] = nil,
			["enemies"] = { "rift_wraith", "crystal_mantis" }
		},
		{
			["index"] = 12,
			["theme"] = "leviathanmaw",
			["name"] = "Leviathan\'s Maw",
			["recommended"] = 1.1e48,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 2.5e31,
			["boss"] = "leviathan",
			["enemies"] = { "deep_cultist", "abyss_eel" }
		},
		{
			["index"] = 13,
			["theme"] = "glowabyss",
			["name"] = "Glow Abyss",
			["recommended"] = 7.9e48,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 9e31,
			["boss"] = nil,
			["enemies"] = { "jelly_spirit", "lantern_fish" }
		},
		{
			["index"] = 14,
			["theme"] = "frozencitadel",
			["name"] = "Frozen Citadel",
			["recommended"] = 5.5e49,
			["enemies"] = nil,
			["count"] = 8,
			["wins"] = 3.25e32,
			["boss"] = nil,
			["enemies"] = { "citadel_knight", "ice_drake" }
		},
		{
			["index"] = 15,
			["theme"] = "abysscore",
			["name"] = "Abyss Core",
			["recommended"] = 3.9e50,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 1.175e33,
			["boss"] = "abyss_king",
			["enemies"] = { "abyss_samurai", "abyss_assassin" }
		}
	},
	["WORLD5_NAME"] = "Cosmic Void",
	["world5"] = {
		{
			["index"] = 1,
			["theme"] = "stardustshore",
			["name"] = "Stardust Shore",
			["recommended"] = 8e50,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 2.5e33,
			["boss"] = nil,
			["enemies"] = { "stardust_imp", "star_crab" }
		},
		{
			["index"] = 2,
			["theme"] = "asteroidfield",
			["name"] = "Asteroid Field",
			["recommended"] = 4e52,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 3.25e34,
			["boss"] = nil,
			["enemies"] = { "rock_drifter", "asteroid_beetle" }
		},
		{
			["index"] = 3,
			["theme"] = "cometwreck",
			["name"] = "Comet Wreck",
			["recommended"] = 2.8e53,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 1.2e35,
			["boss"] = "comet_titan",
			["enemies"] = { "comet_scavenger", "comet_golem" }
		},
		{
			["index"] = 4,
			["theme"] = "nebulagarden",
			["name"] = "Nebula Garden",
			["recommended"] = 2e54,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 4.375e35,
			["boss"] = nil,
			["enemies"] = { "nebula_sprite", "spore_alien" }
		},
		{
			["index"] = 5,
			["theme"] = "crystalplanet",
			["name"] = "Crystal Planet",
			["recommended"] = 1.4e55,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 1.5e36,
			["boss"] = nil,
			["enemies"] = { "crystal_sentinel", "prism_mantis" }
		},
		{
			["index"] = 6,
			["theme"] = "blackholerim",
			["name"] = "Black Hole Rim",
			["recommended"] = 9.6e55,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 5.625e36,
			["boss"] = "singularity_lord",
			["enemies"] = { "gravity_wraith", "void_walker" }
		},
		{
			["index"] = 7,
			["theme"] = "alienruins",
			["name"] = "Alien Ruins",
			["recommended"] = 6.7e56,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 2e37,
			["boss"] = nil,
			["enemies"] = { "alien_priest", "ruin_guardian" }
		},
		{
			["index"] = 8,
			["theme"] = "gasgiantrings",
			["name"] = "Gas Giant Rings",
			["recommended"] = 4.7e57,
			["enemies"] = nil,
			["count"] = 6,
			["wins"] = 7.375e37,
			["boss"] = nil,
			["enemies"] = { "ring_drifter", "gas_jelly" }
		},
		{
			["index"] = 9,
			["theme"] = "observatory",
			["name"] = "Star Observatory",
			["recommended"] = 3.3e58,
			["enemies"] = nil,
			["count"] = 3,
			["wins"] = 2.625e38,
			["boss"] = "star_sage",
			["enemies"] = { "star_sentry", "astronomer" }
		},
		{
			["index"] = 10,
			["theme"] = "meteorstorm",
			["name"] = "Meteor Storm",
			["recommended"] = 2.3e59,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 9.625e38,
			["boss"] = nil,
			["enemies"] = { "meteor_brute", "fire_comet" }
		},
		{
			["index"] = 11,
			["theme"] = "darkmatter",
			["name"] = "Dark Matter Wastes",
			["recommended"] = 1.6e60,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 3.5e39,
			["boss"] = nil,
			["enemies"] = { "dark_slime", "null_shade" }
		},
		{
			["index"] = 12,
			["theme"] = "galaxybridge",
			["name"] = "Galaxy Bridge",
			["recommended"] = 1.1e61,
			["enemies"] = nil,
			["count"] = 4,
			["wins"] = 1.25e40,
			["boss"] = "galaxy_guardian",
			["enemies"] = { "galaxy_knight", "star_serpent" }
		},
		{
			["index"] = 13,
			["theme"] = "quasarspire",
			["name"] = "Quasar Spire",
			["recommended"] = 7.9e61,
			["enemies"] = nil,
			["count"] = 7,
			["wins"] = 4.5e40,
			["boss"] = nil,
			["enemies"] = { "quasar_mage", "plasma_drone" }
		},
		{
			["index"] = 14,
			["theme"] = "wormholegate",
			["name"] = "Wormhole Gate",
			["recommended"] = 5.5e62,
			["enemies"] = nil,
			["count"] = 8,
			["wins"] = 1.625e41,
			["boss"] = nil,
			["enemies"] = { "warp_hunter", "warp_beast" }
		},
		{
			["index"] = 15,
			["theme"] = "cosmicthrone",
			["name"] = "Cosmic Throne",
			["recommended"] = 3.9e63,
			["enemies"] = nil,
			["count"] = 5,
			["wins"] = 5.875e41,
			["boss"] = "void_emperor",
			["enemies"] = { "star_ronin", "cosmic_assassin" }
		}
	},
	["WORLD5_SHIFT"] = 8
}
for _, v2 in v_u_1.world5 do
	v2.recommended = v2.recommended * v_u_1.WORLD5_SHIFT
end
v_u_1.WORLD6_NAME = "Soul Society"
v_u_1.world6 = {
	{
		["index"] = 1,
		["theme"] = "rukongaioutskirts",
		["name"] = "Rukongai Outskirts",
		["recommended"] = 2e64,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 1.25e42,
		["boss"] = nil,
		["enemies"] = { "rukon_thug", "stray_soul" }
	},
	{
		["index"] = 2,
		["theme"] = "rukongaimarket",
		["name"] = "Rukongai Market",
		["recommended"] = 1e66,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 1.625e43,
		["boss"] = nil,
		["enemies"] = { "market_brawler", "wandering_plus" }
	},
	{
		["index"] = 3,
		["theme"] = "seireiteigate",
		["name"] = "Seireitei Gate",
		["recommended"] = 7e66,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 6e43,
		["boss"] = "gate_giant",
		["enemies"] = { "gate_sentry", "wall_guard" }
	},
	{
		["index"] = 4,
		["theme"] = "squadbarracks",
		["name"] = "Squad Barracks",
		["recommended"] = 5e67,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 2.1875e44,
		["boss"] = nil,
		["enemies"] = { "squad_recruit", "barracks_officer" }
	},
	{
		["index"] = 5,
		["theme"] = "sakuracourtyard",
		["name"] = "Sakura Courtyard",
		["recommended"] = 3.5e68,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 7.5e44,
		["boss"] = nil,
		["enemies"] = { "petal_dancer", "courtyard_guard" }
	},
	{
		["index"] = 6,
		["theme"] = "senzaikyutower",
		["name"] = "Senzaikyu Tower",
		["recommended"] = 2.4e69,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 2.8125e45,
		["boss"] = "tower_captain",
		["enemies"] = { "tower_warden", "cell_keeper" }
	},
	{
		["index"] = 7,
		["theme"] = "traininggrounds",
		["name"] = "Training Grounds",
		["recommended"] = 1.7e70,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 1e46,
		["boss"] = nil,
		["enemies"] = { "sparring_shinigami", "kido_trainee" }
	},
	{
		["index"] = 8,
		["theme"] = "squad12lab",
		["name"] = "Squad 12 Lab",
		["recommended"] = 1.2e71,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 3.6875e46,
		["boss"] = nil,
		["enemies"] = { "lab_tech", "mod_soul" }
	},
	{
		["index"] = 9,
		["theme"] = "kidocorpshall",
		["name"] = "Kido Corps Hall",
		["recommended"] = 8.3e71,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 1.3125e47,
		["boss"] = "kido_master",
		["enemies"] = { "kido_adept", "seal_keeper" }
	},
	{
		["index"] = 10,
		["theme"] = "undergroundcave",
		["name"] = "Underground Cave",
		["recommended"] = 5.8e72,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 4.8125e47,
		["boss"] = nil,
		["enemies"] = { "cave_hermit", "training_spirit" }
	},
	{
		["index"] = 11,
		["theme"] = "central46chambers",
		["name"] = "Central 46 Chambers",
		["recommended"] = 4e73,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 1.75e48,
		["boss"] = nil,
		["enemies"] = { "judge_clerk", "chamber_guard" }
	},
	{
		["index"] = 12,
		["theme"] = "sokyokuhill",
		["name"] = "Sokyoku Hill",
		["recommended"] = 2.8e74,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 6.25e48,
		["boss"] = "sokyoku_executioner",
		["enemies"] = { "execution_guard", "sokyoku_monk" }
	},
	{
		["index"] = 13,
		["theme"] = "seireiteirooftops",
		["name"] = "Seireitei Rooftops",
		["recommended"] = 2e75,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 2.25e49,
		["boss"] = nil,
		["enemies"] = { "rooftop_runner", "flash_assassin" }
	},
	{
		["index"] = 14,
		["theme"] = "senkaimon",
		["name"] = "Senkaimon",
		["recommended"] = 1.4e76,
		["enemies"] = nil,
		["count"] = 8,
		["wins"] = 8.125e49,
		["boss"] = nil,
		["enemies"] = { "senkai_keeper", "dangai_stalker" }
	},
	{
		["index"] = 15,
		["theme"] = "headcaptainshall",
		["name"] = "Head Captain\'s Hall",
		["recommended"] = 9.8e76,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 2.9375e50,
		["boss"] = "head_captain",
		["enemies"] = { "captain_guard", "lieutenant_elite" }
	}
}
v_u_1.WORLD7_NAME = "Hueco Mundo"
v_u_1.world7 = {
	{
		["index"] = 1,
		["theme"] = "whitesanddunes",
		["name"] = "White Sand Dunes",
		["recommended"] = 2.88e80,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 6.25e50,
		["boss"] = nil,
		["enemies"] = { "sand_hollow", "lizard_hollow" }
	},
	{
		["index"] = 2,
		["theme"] = "quartzforest",
		["name"] = "Quartz Forest",
		["recommended"] = 1.44e82,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 8.125e51,
		["boss"] = nil,
		["enemies"] = { "quartz_crawler", "adjuchas_scout" }
	},
	{
		["index"] = 3,
		["theme"] = "menosforest",
		["name"] = "Menos Forest",
		["recommended"] = 1.01e83,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 3e52,
		["boss"] = "adjuchas_alpha",
		["enemies"] = { "gillian_brute", "menos_drifter" }
	},
	{
		["index"] = 4,
		["theme"] = "hollowgraveyard",
		["name"] = "Hollow Graveyard",
		["recommended"] = 7.2e83,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 1.09375e53,
		["boss"] = nil,
		["enemies"] = { "grave_hollow", "bone_picker" }
	},
	{
		["index"] = 5,
		["theme"] = "gargantarift",
		["name"] = "Garganta Rift",
		["recommended"] = 5.04e84,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 3.75e53,
		["boss"] = nil,
		["enemies"] = { "garganta_walker", "rift_hollow" }
	},
	{
		["index"] = 6,
		["theme"] = "lasnochesgate",
		["name"] = "Las Noches Gate",
		["recommended"] = 3.46e85,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 1.40625e54,
		["boss"] = "gate_numeros",
		["enemies"] = { "numeros_guard", "gate_arrancar" }
	},
	{
		["index"] = 7,
		["theme"] = "endlesscorridors",
		["name"] = "Endless Corridors",
		["recommended"] = 2.45e86,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 5e54,
		["boss"] = nil,
		["enemies"] = { "corridor_sentry", "sonido_runner" }
	},
	{
		["index"] = 8,
		["theme"] = "fakeskydome",
		["name"] = "Fake Sky Dome",
		["recommended"] = 1.73e87,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 1.84375e55,
		["boss"] = nil,
		["enemies"] = { "dome_watcher", "sky_mimic" }
	},
	{
		["index"] = 9,
		["theme"] = "fraccionbarracks",
		["name"] = "Fraccion Barracks",
		["recommended"] = 1.2e88,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 6.5625e55,
		["boss"] = "fraccion_leader",
		["enemies"] = { "fraccion_brute", "fraccion_lancer" }
	},
	{
		["index"] = 10,
		["theme"] = "szayellab",
		["name"] = "Szayel\'s Lab",
		["recommended"] = 8.35e88,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 2.40625e56,
		["boss"] = nil,
		["enemies"] = { "lab_experiment", "szayel_clone" }
	},
	{
		["index"] = 11,
		["theme"] = "espadatowers",
		["name"] = "Espada Towers",
		["recommended"] = 5.76e89,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 8.75e56,
		["boss"] = nil,
		["enemies"] = { "privaron_espada", "tower_arrancar" }
	},
	{
		["index"] = 12,
		["theme"] = "throneroom",
		["name"] = "Throne Room",
		["recommended"] = 4.03e90,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 3.125e57,
		["boss"] = "espada_cuatro",
		["enemies"] = { "throne_guard", "espada_lieutenant" }
	},
	{
		["index"] = 13,
		["theme"] = "domerooftop",
		["name"] = "Dome Rooftop",
		["recommended"] = 2.88e91,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 1.125e58,
		["boss"] = nil,
		["enemies"] = { "rooftop_arrancar", "black_cero_hollow" }
	},
	{
		["index"] = 14,
		["theme"] = "silbern",
		["name"] = "Silbern",
		["recommended"] = 2.02e92,
		["enemies"] = nil,
		["count"] = 8,
		["wins"] = 4.0625e58,
		["boss"] = nil,
		["enemies"] = { "sternritter_soldier", "quincy_trooper" }
	},
	{
		["index"] = 15,
		["theme"] = "almightythrone",
		["name"] = "The Almighty\'s Throne",
		["recommended"] = 1.41e93,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 1.46875e59,
		["boss"] = "quincy_emperor",
		["enemies"] = { "royal_sentinel", "sternritter_elite" }
	}
}
v_u_1.WORLD8_NAME = "Infinity Castle"
v_u_1.world8 = {
	{
		["index"] = 1,
		["theme"] = "fallinghalls",
		["name"] = "Falling Halls",
		["recommended"] = 1.74e96,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 3.125e59,
		["boss"] = nil,
		["enemies"] = { "castle_demon", "horned_oni" }
	},
	{
		["index"] = 2,
		["theme"] = "tatamimaze",
		["name"] = "Tatami Maze",
		["recommended"] = 8.71e97,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 4.0625e60,
		["boss"] = nil,
		["enemies"] = { "tatami_crawler", "mask_demon" }
	},
	{
		["index"] = 3,
		["theme"] = "lanterncorridors",
		["name"] = "Lantern Corridors",
		["recommended"] = 6.1e98,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 1.5e61,
		["boss"] = "lower_moon_one",
		["enemies"] = { "lantern_ghoul", "thread_demon" }
	},
	{
		["index"] = 4,
		["theme"] = "vasegallery",
		["name"] = "Vase Gallery",
		["recommended"] = 4.36e99,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 5.46875e61,
		["boss"] = nil,
		["enemies"] = { "vase_fiend", "needle_fish_demon" }
	},
	{
		["index"] = 5,
		["theme"] = "upsidedownrooms",
		["name"] = "Upside-Down Rooms",
		["recommended"] = 3.05e100,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 1.875e62,
		["boss"] = nil,
		["enemies"] = { "ceiling_crawler", "upside_demon" }
	},
	{
		["index"] = 6,
		["theme"] = "thunderdojo",
		["name"] = "Thunder Dojo",
		["recommended"] = 2.09e101,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 7.03125e62,
		["boss"] = "upper_six",
		["enemies"] = { "thunder_disciple", "sickle_demon" }
	},
	{
		["index"] = 7,
		["theme"] = "shojihalls",
		["name"] = "Shoji Halls",
		["recommended"] = 1.48e102,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 2.5e63,
		["boss"] = nil,
		["enemies"] = { "shoji_stalker", "biwa_servant" }
	},
	{
		["index"] = 8,
		["theme"] = "biwachamber",
		["name"] = "Biwa Chamber",
		["recommended"] = 1.05e103,
		["enemies"] = nil,
		["count"] = 6,
		["wins"] = 9.21875e63,
		["boss"] = nil,
		["enemies"] = { "eyeball_demon", "room_shifter" }
	},
	{
		["index"] = 9,
		["theme"] = "lotustemple",
		["name"] = "Lotus Temple",
		["recommended"] = 7.23e103,
		["enemies"] = nil,
		["count"] = 3,
		["wins"] = 3.28125e64,
		["boss"] = "upper_two",
		["enemies"] = { "ice_doll", "lotus_cultist" }
	},
	{
		["index"] = 10,
		["theme"] = "compasscourtyard",
		["name"] = "Compass Courtyard",
		["recommended"] = 5.05e104,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 1.203125e65,
		["boss"] = nil,
		["enemies"] = { "martial_demon", "compass_brawler" }
	},
	{
		["index"] = 11,
		["theme"] = "endlessstairs",
		["name"] = "Endless Stairs",
		["recommended"] = 3.48e105,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 4.375e65,
		["boss"] = nil,
		["enemies"] = { "stair_ghoul", "crescent_demon" }
	},
	{
		["index"] = 12,
		["theme"] = "moonpillars",
		["name"] = "Moon Pillars",
		["recommended"] = 2.44e106,
		["enemies"] = nil,
		["count"] = 4,
		["wins"] = 1.5625e66,
		["boss"] = "upper_one",
		["enemies"] = { "moon_blade_demon", "six_eye_sentinel" }
	},
	{
		["index"] = 13,
		["theme"] = "collapsingcastle",
		["name"] = "Collapsing Castle",
		["recommended"] = 1.74e107,
		["enemies"] = nil,
		["count"] = 7,
		["wins"] = 5.625e66,
		["boss"] = nil,
		["enemies"] = { "flesh_demon", "rubble_oni" }
	},
	{
		["index"] = 14,
		["theme"] = "dawnstreets",
		["name"] = "Dawn Streets",
		["recommended"] = 1.22e108,
		["enemies"] = nil,
		["count"] = 8,
		["wins"] = 2.03125e67,
		["boss"] = nil,
		["enemies"] = { "dawn_runner", "sunless_demon" }
	},
	{
		["index"] = 15,
		["theme"] = "muzanlair",
		["name"] = "Muzan\'s Lair",
		["recommended"] = 8.54e108,
		["enemies"] = nil,
		["count"] = 5,
		["wins"] = 7.34375e67,
		["boss"] = "demon_king_muzan",
		["enemies"] = { "muzan_clone", "blood_tendril_demon" }
	}
}
v_u_1.worlds = {
	v_u_1.list,
	v_u_1.world2,
	v_u_1.world3,
	v_u_1.world4,
	v_u_1.world5,
	v_u_1.world6,
	v_u_1.world7,
	v_u_1.world8
}
local v3 = {
	1,
	1,
	1,
	1,
	1,
	1.25,
	1.25,
	1.5,
	1.5,
	2,
	2.5,
	2.5,
	2.5,
	2.5,
	2.5
}
for v4, v5 in v_u_1.worlds do
	for v6, v7 in v5 do
		local v8 = v7.wins * (v4 == 1 and (v3[v6] or 1) or 2.5)
		local v9
		if v8 < 100 then
			local v10 = v8 + 0.5
			v9 = math.floor(v10)
		else
			local v11 = math.log10(v8)
			local v12 = 10 ^ (math.floor(v11) - 1)
			local v13 = v8 / v12 + 0.5
			v9 = math.floor(v13) * v12
		end
		v7.wins = v9
	end
end
v_u_1.LATER_CLIMB = {
	[2] = 1.05,
	[3] = 1.05,
	[6] = 1.68,
	[7] = 1.659,
	[8] = 1.6275
}
v_u_1.STAGE2_EASE = 0.35
local v14 = {
	[5] = {
		[13] = 0.85,
		[14] = 0.6,
		[15] = 0.3
	},
	[7] = {
		[15] = 0.5
	},
	[8] = {
		[15] = 0.5
	}
}
for v15, v16 in v_u_1.worlds do
	for v17, v18 in v16 do
		local v19 = (v_u_1.LATER_CLIMB[v15] or 1) ^ (v17 - 1)
		if v15 >= 2 and v17 == 2 then
			v19 = v19 * v_u_1.STAGE2_EASE
		end
		local v20 = v14[v15]
		if v20 then
			v19 = v19 * (v20[v17] or 1)
		end
		if v19 == 1 then
			continue
		end
		local v21 = v18.recommended * v19
		local v22
		if v21 < 100 then
			local v23 = v21 + 0.5
			v22 = math.floor(v23)
		else
			local v24 = math.log10(v21)
			local v25 = 10 ^ (math.floor(v24) - 1)
			local v26 = v21 / v25 + 0.5
			v22 = math.floor(v26) * v25
		end
		v18.recommended = v22
	end
end
v_u_1.TROPHY_RUNS = {}
for v27, v28 in v_u_1.worlds do
	local v29 = v_u_1.TROPHY_RUNS[v27]
	if not v29 then
		continue
	end
	local v30 = 0
	for v31 = 2, #v28 do
		v30 = v30 + v29 * 6 / (v31 - 1 + 5) * v28[v31 - 1].wins
		local v32 = v28[v31]
		local v33
		if v30 < 100 then
			local v34 = v30 + 0.5
			v33 = math.floor(v34)
		else
			local v35 = math.log10(v30)
			local v36 = 10 ^ (math.floor(v35) - 1)
			local v37 = v30 / v36 + 0.5
			v33 = math.floor(v37) * v36
		end
		v32.needWins = v33
	end
end
function v_u_1.forWorld(p38) -- name: forWorld
	-- upvalues: (copy) v_u_1
	return v_u_1.worlds[p38 or 1] or v_u_1.list
end
function v_u_1.padWins(p39, p40, p41) -- name: padWins
	-- upvalues: (copy) v_u_1
	local v42 = v_u_1.forWorld(p41)[p39]
	return not v42 and 0 or v42.wins * (p40 ~= "purple" and 1 or v_u_1.PURPLE_PAD)
end
return v_u_1