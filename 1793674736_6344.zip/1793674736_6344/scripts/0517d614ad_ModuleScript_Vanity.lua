return {
	["ATTRIBUTES"] = {
		["hideEye"] = "HideEye",
		["hideAura"] = "HideAura"
	},
	["clean"] = function(p1) -- name: clean
		local v2 = {}
		if type(p1) ~= "table" then
			return v2
		end
		if p1.hideEye == true then
			v2.hideEye = true
		end
		if p1.hideAura == true then
			v2.hideAura = true
		end
		return v2
	end,
	["set"] = function(p3, p4, p5) -- name: set
		if type(p5) ~= "boolean" then
			return false
		end
		if p4 == "hideEye" then
			p3.hideEye = p5 and true or nil
		else
			if p4 ~= "hideAura" then
				return false
			end
			p3.hideAura = p5 and true or nil
		end
		return true
	end,
	["hidden"] = function(p6, p7) -- name: hidden
		if p7 == "hideEye" then
			return p6.hideEye == true
		elseif p7 == "hideAura" then
			return p6.hideAura == true
		else
			return false
		end
	end
}