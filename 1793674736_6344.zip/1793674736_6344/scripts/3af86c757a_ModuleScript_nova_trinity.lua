local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(255, 248, 225)
local v_u_5 = Color3.fromRGB(232, 58, 20)
return function(p_u_6)
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_3, (copy) v_u_5
	return {
		["w5_nova_trinity"] = function(p_u_7, p8)
			-- upvalues: (ref) v_u_2, (copy) p_u_6, (ref) v_u_4, (ref) v_u_3, (ref) v_u_5
			local v_u_9 = v_u_2.color(p8.color)
			local v10 = v_u_2.color(p8.color2)
			local v11 = p_u_7.headY / 1.5
			local v_u_12 = math.clamp(v11, 0.7, 3)
			local v_u_13 = v_u_12 * 1.95
			local v_u_14 = v_u_12 * 1.5
			local v_u_15 = 0
			local v_u_16 = 0
			local v_u_17 = 0
			local v_u_18 = 0
			local v_u_24 = p_u_6.group(p_u_7, function(p19, p20)
				-- upvalues: (copy) v_u_12
				local v21 = CFrame.new
				local v22 = v_u_12 * 1.55
				local v23 = p20 * 1.1
				return p19 * v21(0, v22 + math.sin(v23) * 0.1 * v_u_12, v_u_12 * 1.95)
			end)
			local v_u_30 = p_u_6.group(p_u_7, function()
				-- upvalues: (copy) v_u_24, (ref) p_u_6
				local v25 = v_u_24.cf.Position
				local v26 = p_u_6.camPos() - v25
				local v27 = v26.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v26.Unit
				local v28 = v27.Y
				local v29 = math.abs(v28) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v25, v25 + v27, v29) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v31 = p_u_7.ticks
			local function v43(p32, p33, p34)
				-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) p_u_7, (ref) p_u_6, (ref) v_u_2, (copy) v_u_24, (ref) v_u_4, (copy) v_u_12, (copy) v_u_9, (ref) v_u_3, (ref) v_u_15, (ref) v_u_17
				local v35 = (p33 - 2.4) % 4.8
				if p33 >= 2.4 and v35 < v_u_18 then
					v_u_16 = 1
					p_u_7.pulse = 1
					if (p32.Position - p_u_6.camPos()).Magnitude < 150 then
						v_u_2.flash(v_u_24.cf.Position, v_u_4, v_u_12 * 4.5, 0.35)
						v_u_2.ring(p_u_6.feetAt(p_u_7, p32, 0.15), v_u_9, 6 * p_u_7.fx, 0.55, v_u_3.Ring)
					end
				end
				v_u_18 = v35
				local v36 = p33 < 2.4 and (1 / 0) or v35
				local v37
				if p33 < 2.4 then
					v37 = 2.4 - p33
				else
					v37 = 4.8 - v35
				end
				if v37 < 0.4 then
					v_u_15 = ((0.4 - v37) / 0.4) ^ 2
				elseif v36 < 0.45 then
					local v38 = v36 / 0.45 - 1
					v_u_15 = 1 - (v38 * 3.2 * v38 * v38 + 1 + v38 * 2.2 * v38)
				else
					v_u_15 = 0
				end
				local v39 = v_u_16 - p34 * 1.6
				v_u_16 = math.max(v39, 0)
				local v40 = p_u_7
				local v41 = p_u_7.pulse - p34 * 1.6
				v40.pulse = math.max(v41, 0)
				local v42 = v_u_15
				v_u_17 = v_u_17 + p34 * (math.max(v42, 0) * 7 + 0.9 + v_u_16 * 6)
			end
			table.insert(v31, v43)
			local v44 = p_u_6.picture(v_u_12 * 5.8, v_u_3.Glow, v_u_9, 0.35)
			p_u_6.add(p_u_7, v44, function()
				-- upvalues: (copy) v_u_30, (copy) v_u_12
				return v_u_30.cf * CFrame.new(0, v_u_12 * -0.12, 0)
			end)
			p_u_6.fadeFromBehind(p_u_7, v44, 0.6)
			local v45 = p_u_6.picture(v_u_13 * 2.1, v_u_3.Ring, v_u_9, 0.1)
			p_u_6.add(p_u_7, v45, function(_, p46)
				-- upvalues: (copy) v_u_30, (copy) v_u_12
				return v_u_30.cf * CFrame.new(0, v_u_12 * -0.06, 0) * CFrame.Angles(0, p46 * 0.6, 0)
			end)
			p_u_6.fadeFromBehind(p_u_7, v45, 0.5)
			local v_u_47 = v_u_15
			local v_u_48 = v_u_16
			local v_u_49 = v_u_17
			local v_u_50 = {}
			for v_u_51 = 1, 12 do
				local v52 = p_u_6.bar
				local v53 = v_u_12 * 0.08
				local v54 = v_u_12 * 0.62
				local v55 = v_u_12 * 0.46
				local v56 = Vector3.new(v53, v54, v55)
				local v57
				if v_u_51 % 2 == 0 then
					v57 = v10
				else
					v57 = v_u_9
				end
				local v_u_58 = v52(v56, v57, 0)
				v_u_58.Shape = Enum.PartType.Wedge
				v_u_50[v_u_51] = v_u_58
				p_u_6.add(p_u_7, v_u_58, function(_, p59)
					-- upvalues: (copy) v_u_51, (copy) v_u_30, (copy) v_u_58, (copy) v_u_13, (copy) v_u_12
					local v60 = -p59 * 0.5 + (v_u_51 - 1) * 3.141592653589793 * 2 / 12
					local v61 = v_u_30.cf
					local v62 = v61.UpVector
					local v63 = math.cos(v60)
					local v64 = math.sin(v60)
					local v65 = v61:VectorToWorldSpace((Vector3.new(v63, 0, v64)))
					local v66 = v_u_58.Size.Y
					local v67 = v61.Position + v65 * (v_u_13 + v66 / 2) - v62 * 0.04 * v_u_12
					return CFrame.fromMatrix(v67, v62, v65)
				end)
				p_u_6.fadeFromBehind(p_u_7, v_u_58, 0.5)
			end
			local v_u_68 = -1
			local v69 = p_u_7.ticks
			local function v79(_, p70)
				-- upvalues: (ref) v_u_68, (ref) v_u_48, (copy) v_u_50, (copy) v_u_12
				if p70 - v_u_68 >= 0.06666666666666667 then
					v_u_68 = p70
					local v71 = v_u_48 * 1.1 + 1
					for v72, v73 in v_u_50 do
						local v74 = v_u_12 * 0.62
						local v75 = p70 * 12 + v72 * 1.7
						local v76 = v74 * (math.sin(v75) * 0.22 + 1) * v71
						local v77 = v_u_12 * 0.08
						local v78 = v_u_12 * 0.46
						v73.Size = Vector3.new(v77, v76, v78)
					end
				end
			end
			table.insert(v69, v79)
			local v80 = p_u_6.picture(v_u_12 * 3.4, v_u_3.NovaTrinity, v_u_9, 0)
			p_u_6.add(p_u_7, v80, function()
				-- upvalues: (copy) v_u_30, (ref) v_u_49
				return v_u_30.cf * CFrame.Angles(0, -v_u_49, 0)
			end)
			p_u_6.fadeFromBehind(p_u_7, v80, 0.5)
			local v81 = p_u_6.picture(v_u_12 * 0.95, v_u_3.Ring, v10, 0)
			p_u_6.add(p_u_7, v81, function()
				-- upvalues: (copy) v_u_30, (copy) v_u_12
				return v_u_30.cf * CFrame.new(0, v_u_12 * 0.05, 0)
			end)
			for v_u_82 = 0, 2 do
				local v83 = p_u_6.ball(v_u_12 * 0.5, v_u_4, 0)
				p_u_6.add(p_u_7, v83, function()
					-- upvalues: (copy) v_u_14, (ref) v_u_47, (copy) v_u_30, (ref) v_u_49, (copy) v_u_82, (copy) v_u_12
					local v84 = CFrame.new
					local v85 = v_u_14 * (1 - v_u_47)
					return v84((v_u_30.cf * CFrame.Angles(0, -v_u_49 + 0.7 + v_u_82 * 3.141592653589793 * 2 / 3, 0) * CFrame.new(v85, v_u_12 * 0.12, 0)).Position)
				end)
				p_u_6.add(p_u_7, p_u_6.ball(v_u_12 * 0.9, v_u_9, 0.5), p_u_6.behind(function()
					-- upvalues: (copy) v_u_14, (ref) v_u_47, (copy) v_u_30, (ref) v_u_49, (copy) v_u_82, (copy) v_u_12
					local v86 = CFrame.new
					local v87 = v_u_14 * (1 - v_u_47)
					return v86((v_u_30.cf * CFrame.Angles(0, -v_u_49 + 0.7 + v_u_82 * 3.141592653589793 * 2 / 3, 0) * CFrame.new(v87, v_u_12 * 0.12, 0)).Position)
				end, v_u_12 * 0.3))
				p_u_6.tail(v83, v10, v_u_5, v_u_12 * 0.3, 0.3)
			end
			for v_u_88 = 0, 2 do
				local v89 = p_u_6.blob(Vector3.new(0.45, 0.45, 0.9) * v_u_12, v_u_9, 0)
				p_u_6.add(p_u_7, v89, function(p90, p91)
					-- upvalues: (copy) v_u_88, (ref) p_u_6, (copy) p_u_7, (copy) v_u_12
					local v92 = p91 * 2.4 + v_u_88 * 3.141592653589793 * 2 / 3
					local v93 = p_u_6.feetAt(p_u_7, p90, v_u_12 * 0.35)
					local v94 = math.cos(v92)
					local v95 = math.sin(v92)
					local v96 = v93 + Vector3.new(v94, 0, v95) * 1.7 * v_u_12
					local v97 = -math.sin(v92)
					local v98 = math.cos(v92)
					local v99 = Vector3.new(v97, 0, v98)
					return CFrame.lookAt(v96, v96 + v99)
				end)
				p_u_6.tail(v89, v10, v_u_5, v_u_12 * 0.35, 0.45)
			end
			local v100 = p_u_6.particles
			local v101 = {
				["rate"] = 0.45,
				["glow"] = 0.6,
				["only"] = nil,
				["at"] = nil,
				["only"] = { "Embers" }
			}
			local v102 = v_u_12 * 1.55
			local v103 = v_u_12 * 1.95
			v101.at = Vector3.new(0, v102, v103)
			v100(p_u_7, "Fire", v_u_9, v101)
			p_u_6.particles(p_u_7, "AuraMode", v10, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end