local v_u_1 = game:GetService("ContentProvider")
return {
	["images"] = function(p2, p_u_3) -- name: images
		-- upvalues: (copy) v_u_1
		local v_u_4 = {}
		for _, v5 in p2 do
			if v5 == "" then
				continue
			end
			local v6 = Instance.new("Decal")
			v6.Texture = v5
			table.insert(v_u_4, v6)
		end
		if #v_u_4 ~= 0 then
			task.spawn(function()
				-- upvalues: (ref) v_u_1, (copy) v_u_4, (copy) p_u_3
				v_u_1:PreloadAsync(v_u_4, p_u_3)
			end)
		end
	end
}