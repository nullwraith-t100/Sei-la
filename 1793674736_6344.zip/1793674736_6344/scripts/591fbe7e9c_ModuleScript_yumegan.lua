local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("7FD8FF")
local v_u_8 = Color3.fromHex("0B0F1A")
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(196, 236, 255)
local v_u_11 = Color3.fromRGB(40, 96, 210)
local v_u_12 = Enum.PartType.Ball
local v_u_13 = Enum.PartType.Cylinder
local v_u_14 = Enum.Material.ForceField
local v_u_15 = Color3.new(v_u_10.R * 1.8, v_u_10.G * 1.8, v_u_10.B * 1.8)
local v_u_16 = Color3.new(v_u_7.R * 1.6, v_u_7.G * 1.6, v_u_7.B * 1.6)
local function v_u_23(p17, p18, p19) -- name: face
	local v20 = p19 - p18 * p19:Dot(p18)
	local v21
	if v20.Magnitude > 0.001 then
		v21 = v20.Unit
	else
		local v22 = p18.Y
		v21 = math.abs(v22) > 0.9 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	end
	return CFrame.fromMatrix(p17, p18:Cross(v21), p18, v21)
end
local function v_u_33(p24, p25, p26) -- name: toward
	-- upvalues: (copy) v_u_3, (copy) v_u_23
	local v27 = v_u_3.CurrentCamera
	local v28
	if v27 then
		local v29 = v27.CFrame.Position - p24
		v28 = v29.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v29.Unit
	else
		v28 = Vector3.new(0, 0, 1)
	end
	local v30 = Vector3.new(0, 1, 0) - v28 * (Vector3.new(0, 1, 0)):Dot(v28)
	local v31 = v30.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v30.Unit
	local v32 = v31:Cross(v28)
	return v_u_23(p24 + v28 * (p26 or 0), v28, v31 * math.cos(p25) + v32 * math.sin(p25))
end
local function v_u_52(p34, p35, p36, p37, p38) -- name: picture
	-- upvalues: (copy) v_u_4
	local v39 = Color3.new
	local v40 = p37.R
	local v41 = math.min(v40, 1)
	local v42 = p37.G
	local v43 = math.min(v42, 1)
	local v44 = p37.B
	local v45 = v39(v41, v43, (math.min(v44, 1)))
	local v46 = v_u_4.part
	local v47 = p35 * 2
	local v48 = p35 * 2
	local v49 = v46(Vector3.new(v47, 0.05, v48), p34, v45, {
		["transparency"] = 1
	})
	for _, v50 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v51 = Instance.new("Decal")
		v51.Face = v50
		v51.Texture = p36
		v51.Color3 = p37
		v51.Transparency = p38
		v51.Parent = v49
	end
	return v49
end
local function v_u_56(p53, p54) -- name: setAlpha
	for _, v55 in p53:GetChildren() do
		if not v55:IsA("Decal") then
			continue
		end
		v55.Transparency = p54
	end
end
local function v_u_68(p57, p58, p59, p60) -- name: lay
	local v61 = p59 - p58
	local v62 = v61.Magnitude
	local v63 = math.max(v62, 0.05)
	local v64 = math.max(p60, 0.03)
	p57.Size = Vector3.new(v63, v64, v64)
	local v65 = v61.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v61.Unit
	local v66 = v65.Y
	local v67 = math.abs(v66) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	p57.CFrame = CFrame.lookAt((p58 + p59) / 2, (p58 + p59) / 2 + v65, v67) * CFrame.Angles(0, 1.5707963267948966, 0)
end
return function(p_u_69)
	-- upvalues: (copy) v_u_52, (copy) v_u_33, (copy) v_u_1, (copy) v_u_56, (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (copy) v_u_9, (copy) v_u_6, (copy) v_u_16, (copy) v_u_10, (copy) v_u_13, (copy) v_u_3, (copy) v_u_68, (copy) v_u_15, (copy) v_u_14, (copy) v_u_8, (copy) v_u_11, (copy) v_u_5, (copy) v_u_23
	local v70 = {}
	local function v_u_88(p_u_71, p_u_72, p_u_73, p74, p75, p_u_76, p_u_77, p78) -- name: flare
		-- upvalues: (ref) v_u_52, (ref) v_u_33, (ref) v_u_1, (copy) p_u_69, (ref) v_u_56
		local v_u_79 = p78 or 0
		local v_u_80 = math.random() * 6.283185307179586
		local v_u_81 = v_u_52(v_u_33(p_u_71, v_u_80), p_u_72, p74, p75, v_u_79)
		v_u_1:AddItem(v_u_81, p_u_76 + 0.1)
		p_u_69.animate(p_u_76, 0, function(p82)
			-- upvalues: (copy) v_u_81, (copy) p_u_72, (copy) p_u_73, (ref) v_u_33, (copy) p_u_71, (copy) v_u_80, (copy) p_u_76, (copy) p_u_77, (ref) v_u_56, (copy) v_u_79
			local v83 = v_u_81
			local v84 = p_u_72 + (p_u_73 - p_u_72) * (1 - (1 - p82) ^ 3)
			local v85 = math.max(v84, 0.03)
			local v86 = v85 * 2
			local v87 = v85 * 2
			v83.Size = Vector3.new(v86, 0.05, v87)
			v_u_81.CFrame = v_u_33(p_u_71, v_u_80 + p82 * p_u_76 * p_u_77)
			v_u_56(v_u_81, v_u_79 + (1 - v_u_79) * p82 ^ 1.6)
			if p82 >= 1 then
				v_u_81:Destroy()
			end
		end)
	end
	v70.yumegan_a = {
		["cast"] = function(p89) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_69, (ref) v_u_9, (copy) v_u_88, (ref) v_u_6, (ref) v_u_15
			local v90 = p89.size
			local v91 = p89.eye + p89.dir * 1.2
			v_u_4.flash(v91, v_u_7, 3 * v90, 0.12)
			p_u_69.pop(v91, v_u_9, 1.1 * v90, 0.3 * v90, 0.1)
			if not p89.lite then
				v_u_88(v91, 1.8 * v90, 0.4 * v90, v_u_6.YumeStar, v_u_15, 0.14, 4, 0)
			end
		end,
		["shot"] = function(p92, p93) -- name: nodeShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_52, (ref) v_u_6, (ref) v_u_16, (ref) v_u_10, (ref) v_u_13, (ref) v_u_1, (copy) p_u_69, (ref) v_u_3, (ref) v_u_68
			local v_u_94 = p92.size
			local v_u_95 = p93.Position
			local v_u_96 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p93, v_u_7, {
				["transparency"] = 1
			})
			local v97 = {
				["shape"] = v_u_12
			}
			local v_u_98 = v_u_4.part(Vector3.new(0.85, 0.85, 0.85) * v_u_94, p93, v_u_7, v97)
			local v99 = {
				["shape"] = v_u_12
			}
			local v_u_100 = v_u_4.part(Vector3.new(0.42, 0.42, 0.42) * v_u_94, p93, v_u_9, v99)
			local v_u_101 = { v_u_96, v_u_98, v_u_100 }
			local v_u_102, v_u_103, v_u_104
			if p92.lite then
				v_u_102 = nil
				v_u_103 = nil
				v_u_104 = nil
			else
				v_u_102 = v_u_52(p93, 0.95 * v_u_94, v_u_6.Ring, v_u_16, 0)
				local v105 = {
					["shape"] = v_u_12
				}
				v_u_104 = v_u_4.part(Vector3.new(0.26, 0.26, 0.26) * v_u_94, p93, v_u_9, v105)
				local v106 = {
					["shape"] = nil,
					["transparency"] = 0.2,
					["shape"] = v_u_13
				}
				v_u_103 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), p93, v_u_10, v106)
				table.insert(v_u_101, v_u_102)
				table.insert(v_u_101, v_u_104)
			end
			for _, v107 in v_u_101 do
				v_u_1:AddItem(v107, 3)
			end
			if v_u_103 then
				v_u_1:AddItem(v_u_103, 3.5)
			end
			p_u_69.streak(v_u_96, v_u_10, v_u_7, 0.8 * v_u_94, p92.lite and 0.1 or 0.14)
			if p92.mine then
				p_u_69.light(v_u_96, v_u_7, 9 * v_u_94)
			end
			local v_u_108 = false
			return {
				["place"] = function(p109, p110) -- name: place
					-- upvalues: (copy) v_u_96, (copy) v_u_98, (copy) v_u_100, (ref) v_u_3, (copy) v_u_94, (ref) v_u_102, (ref) v_u_104, (ref) v_u_103, (ref) v_u_68, (copy) v_u_95
					local v111 = p109.Position
					v_u_96.CFrame = p109
					v_u_98.CFrame = p109
					local v112 = v_u_100
					local v113 = CFrame.new
					local v114 = v_u_3.CurrentCamera
					local v115
					if v114 then
						local v116 = v114.CFrame.Position - v111
						v115 = v116.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v116.Unit
					else
						v115 = Vector3.new(0, 0, 1)
					end
					v112.CFrame = v113(v111 + v115 * 0.3 * v_u_94)
					local v117 = v_u_102
					local v118 = v_u_104
					local v119 = v_u_103
					if v117 and v118 then
						local v120 = p109 * CFrame.Angles(1.1, p110 * 3, 0)
						v117.CFrame = v120
						local v121 = p110 * 16
						v118.CFrame = v120 * CFrame.new(math.cos(v121) * 0.95 * v_u_94, 0, math.sin(v121) * 0.95 * v_u_94)
					end
					if v119 then
						v_u_68(v119, v_u_95, v111, 0.14 * v_u_94)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_108, (copy) v_u_96, (ref) v_u_1, (copy) v_u_101, (ref) v_u_103, (ref) v_u_4
					if not v_u_108 then
						v_u_108 = true
						local v122 = v_u_96:FindFirstChildWhichIsA("PointLight")
						if v122 then
							v122:Destroy()
						end
						v_u_1:AddItem(v_u_96, 0.25)
						for _, v123 in v_u_101 do
							if v123 == v_u_96 then
								continue
							end
							v123:Destroy()
						end
						local v124 = v_u_103
						if v124 then
							local v125 = v_u_4.tween
							local v126 = {
								["Transparency"] = 1,
								["Size"] = nil
							}
							local v127 = v124.Size.X
							v126.Size = Vector3.new(v127, 0.02, 0.02)
							v125(v124, 0.3, v126)
							v_u_1:AddItem(v124, 0.32)
						end
					end
				end
			}
		end,
		["impact"] = function(p128, p129) -- name: nodeImpact
			-- upvalues: (copy) v_u_88, (ref) v_u_6, (ref) v_u_15, (ref) v_u_16, (copy) p_u_69, (ref) v_u_9, (ref) v_u_7, (ref) v_u_4
			local v130 = p128.size
			v_u_88(p129, 0.8 * v130, 4.6 * v130, v_u_6.YumeStar, v_u_15, 0.3, 2, 0)
			if not p128.lite then
				v_u_88(p129, 0.6 * v130, 2.6 * v130, v_u_6.Ring, v_u_16, 0.2, 0, 0)
			end
			p_u_69.pop(p129, v_u_9, 1 * v130, 2.4 * v130, 0.14)
			p_u_69.pop(p129, v_u_7, 1.6 * v130, 4.6 * v130, 0.24, 0.45)
			v_u_4.ring(p_u_69.ground(p129), v_u_7, p128.ability.radius * 0.8 * v130, 0.3, v_u_6.Ring)
			p_u_69.burst("Impact", p129, v_u_7, 0.8 * v130)
			p_u_69.hitSound(p129)
		end,
		["hit"] = p_u_69.simpleHit(v_u_7, 0.55)
	}
	local v_u_131 = {}
	setmetatable(v_u_131, {
		["__mode"] = "k"
	})
	local v_u_132 = {}
	setmetatable(v_u_132, {
		["__mode"] = "k"
	})
	local function v_u_161(p133, p134, p135) -- name: openDream
		-- upvalues: (copy) p_u_69, (ref) v_u_52, (ref) v_u_6, (ref) v_u_16, (ref) v_u_7, (ref) v_u_1, (ref) v_u_56
		local v_u_136 = p133.ability.radius
		local v137 = p_u_69.ground(p134, 0)
		local v138 = v137 + Vector3.new(0, 11, 0)
		local v_u_139 = CFrame.new(v138) * CFrame.Angles(3.141592653589793, 0, 0)
		local v_u_140 = v_u_52(v_u_139, 0.1, v_u_6.YumeOrbits, v_u_16, 0)
		local v_u_141 = v_u_52(CFrame.new(v138 + Vector3.new(0, 0.3, 0)), 0.1, v_u_6.Glow, v_u_7, 0.35)
		local v142 = p135 + 1
		v_u_1:AddItem(v_u_140, v142)
		v_u_1:AddItem(v_u_141, v142)
		local v_u_143 = {
			["g"] = v137,
			["top"] = v138,
			["orbits"] = v_u_140,
			["glow"] = v_u_141,
			["born"] = os.clock(),
			["until_"] = os.clock() + p135
		}
		p_u_69.runNow(function()
			-- upvalues: (copy) v_u_143, (copy) v_u_140, (copy) v_u_141, (copy) v_u_136, (copy) v_u_139, (ref) v_u_56
			local v144 = os.clock()
			local v145 = v144 - v_u_143.born
			local v146 = v145 / 0.2
			local v147 = math.clamp(v146, 0, 1) - 1
			local v148 = v147 * 2.7 * v147 * v147 + 1 + v147 * 1.7 * v147
			local v149 = (v144 - v_u_143.until_) / 0.3
			local v150 = math.clamp(v149, 0, 1)
			if v150 >= 1 then
				v_u_140:Destroy()
				v_u_141:Destroy()
				return false
			end
			local v151 = v_u_136 * 0.7 * v148 * (v150 * 0.15 + 1)
			local v152 = v_u_140
			local v153 = math.max(v151, 0.03)
			local v154 = v153 * 2
			local v155 = v153 * 2
			v152.Size = Vector3.new(v154, 0.05, v155)
			local v156 = v_u_141
			local v157 = v151 * 1.4
			local v158 = math.max(v157, 0.03)
			local v159 = v158 * 2
			local v160 = v158 * 2
			v156.Size = Vector3.new(v159, 0.05, v160)
			v_u_140.CFrame = v_u_139 * CFrame.Angles(0, v145 * 0.5, 0)
			v_u_56(v_u_140, v150)
			v_u_56(v_u_141, v150 * 0.65 + 0.35)
			return true
		end)
		return v_u_143
	end
	local function v_u_197(p162, p_u_163, p164, p_u_165) -- name: bubble
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_7, (ref) v_u_12, (ref) v_u_14, (ref) v_u_9, (copy) p_u_69, (ref) v_u_10, (ref) v_u_1, (copy) v_u_88, (ref) v_u_6, (ref) v_u_15
		local v_u_166 = p162.ability.freeze or 3
		local v167 = v_u_3:FindFirstChild("MyEnemies")
		local v_u_168
		if v167 then
			v_u_168 = v167:FindFirstChild("Foe" .. p164)
		else
			v_u_168 = nil
		end
		local v169 = {
			["shape"] = nil,
			["material"] = nil,
			["transparency"] = 0.1,
			["shape"] = v_u_12,
			["material"] = v_u_14
		}
		local v_u_170 = v_u_4.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(p_u_163), v_u_7, v169)
		v_u_4.tween(v_u_170, 0.18, {
			["Size"] = Vector3.new(5, 5, 5)
		}, Enum.EasingStyle.Back)
		local v_u_171 = { v_u_170 }
		local v_u_172, v_u_173
		if p_u_165 then
			local v174 = {
				["shape"] = v_u_12
			}
			local v175 = v_u_4.part(Vector3.new(0.5, 0.5, 0.5), CFrame.new(p_u_163), v_u_9, v174)
			v_u_172 = v175
			table.insert(v_u_171, v175)
			local v176 = p_u_69.ground(p162.target, 11)
			v_u_173 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v176), v_u_9, {
				["transparency"] = 1
			})
			local v177 = Instance.new("Attachment")
			v177.Parent = v_u_173
			local v178 = Instance.new("Attachment")
			v178.Parent = v_u_170
			v178.Position = Vector3.new(0, 0, 0)
			local v179 = Instance.new("Beam")
			v179.Attachment0 = v177
			v179.Attachment1 = v178
			v179.Color = ColorSequence.new(v_u_10, v_u_7)
			v179.LightEmission = 1
			v179.LightInfluence = 0
			v179.FaceCamera = true
			v179.Segments = 1
			v179.Width0 = 0.15
			v179.Width1 = 0.3
			v179.Transparency = NumberSequence.new(0.3)
			v179.Parent = v_u_173
		else
			v_u_173 = nil
			v_u_172 = nil
		end
		for _, v180 in v_u_171 do
			v_u_1:AddItem(v180, v_u_166 + 1)
		end
		if v_u_173 then
			v_u_1:AddItem(v_u_173, v_u_166 + 1)
		end
		local v_u_181 = os.clock()
		p_u_69.runNow(function()
			-- upvalues: (copy) v_u_181, (copy) v_u_168, (copy) v_u_166, (ref) p_u_69, (copy) v_u_170, (ref) v_u_10, (copy) p_u_165, (ref) v_u_88, (ref) v_u_6, (ref) v_u_15, (copy) v_u_171, (ref) v_u_173, (copy) p_u_163, (ref) v_u_172
			local v182 = os.clock() - v_u_181
			local v183
			if v_u_168 == nil then
				v183 = false
			else
				v183 = v_u_168.Parent == nil
			end
			if v_u_166 <= v182 or v183 then
				if not v183 then
					p_u_69.pop(v_u_170.Position, v_u_10, 4, 7, 0.22, 0.3)
					if p_u_165 then
						v_u_88(v_u_170.Position, 1, 3.4, v_u_6.YumeStar, v_u_15, 0.25, 3, 0)
					end
				end
				for _, v184 in v_u_171 do
					v184:Destroy()
				end
				local v185 = v_u_173
				if v185 then
					v185:Destroy()
				end
				return false
			end
			local v186 = v182 / 0.4
			local v187 = math.min(v186, 1) * 1.2
			local v188 = v182 * 2.4
			local v189 = p_u_163 + Vector3.new(0, 1, 0) * (v187 + math.sin(v188) * 0.25)
			v_u_170.CFrame = CFrame.new(v189)
			local v190 = v_u_172
			if v190 then
				local v191 = v182 * 5
				local v192 = CFrame.new
				local v193 = math.cos(v191) * 3
				local v194 = v191 * 0.5
				local v195 = math.sin(v194) * 0.6
				local v196 = math.sin(v191) * 3
				v190.CFrame = v192(v189 + Vector3.new(v193, v195, v196))
			end
			return true
		end)
	end
	v70.yumegan_e = {
		["cast"] = function(p198) -- name: cast
			-- upvalues: (copy) p_u_69, (ref) v_u_7, (copy) v_u_88, (ref) v_u_6, (ref) v_u_15
			p_u_69.skillCast(p198, v_u_7)
			if not p198.lite then
				v_u_88(p198.eye + p198.dir * 1.2, 2.4 * p198.size, 0.4 * p198.size, v_u_6.YumeStar, v_u_15, 0.18, 5, 0)
			end
		end,
		["windup"] = function(p199, p200, p201) -- name: windup
			-- upvalues: (copy) v_u_131, (copy) v_u_161, (copy) p_u_69, (ref) v_u_8, (ref) v_u_6, (ref) v_u_11
			local v202 = p201 + (p199.ability.freeze or 3)
			v_u_131[p199] = v_u_161(p199, p200, v202)
			p_u_69.mark(p200, v_u_8, p199.ability.radius * 1.05, v202 + 0.3, v_u_6.Glow, 0.2)
			p_u_69.mark(p200, v_u_11, p199.ability.radius * 0.9, v202, v_u_6.Glow, 0.55)
		end,
		["land"] = function(p203, p204) -- name: land
			-- upvalues: (copy) v_u_131, (copy) v_u_161, (ref) v_u_52, (ref) v_u_6, (ref) v_u_15, (ref) v_u_1, (copy) p_u_69, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_5
			local v_u_205 = p203.ability.radius
			local v_u_206 = v_u_131[p203] or v_u_161(p203, p204, p203.ability.freeze or 3)
			v_u_131[p203] = nil
			local v_u_207 = v_u_206.g
			local v_u_208 = v_u_52(CFrame.new(v_u_206.top), v_u_205 * 0.7, v_u_6.Ring, v_u_15, 0)
			v_u_1:AddItem(v_u_208, 0.3)
			p_u_69.animate(0.2, 0, function(p209)
				-- upvalues: (copy) v_u_208, (copy) v_u_206, (copy) v_u_207, (copy) v_u_205
				v_u_208.CFrame = CFrame.new(v_u_206.top:Lerp(v_u_207 + Vector3.new(0, 0.5, 0), p209 * p209))
				local v210 = v_u_208
				local v211 = v_u_205 * (0.7 + 0.30000000000000004 * p209)
				local v212 = math.max(v211, 0.03)
				local v213 = v212 * 2
				local v214 = v212 * 2
				v210.Size = Vector3.new(v213, 0.05, v214)
				if p209 >= 1 then
					v_u_208:Destroy()
				end
			end)
			local v215 = p203.lite and 4 or 10
			for v216 = 1, v215 do
				local v217 = (v216 - 1) / v215 * 6.283185307179586 + math.random() * 0.3
				local v218 = v_u_205 * (v216 * 0.618 % 1 * 0.65 + 0.25)
				local v219 = math.cos(v217) * v218
				local v220 = math.sin(v217) * v218
				local v_u_221 = Vector3.new(v219, 0, v220)
				local v222 = v_u_4.part
				local v223 = Vector3.new(0.3, 0.3, 5)
				local v224 = p_u_69.aimAt(v_u_206.top + v_u_221, Vector3.new(-0, -1, -0))
				local v225
				if v216 % 2 == 0 then
					v225 = v_u_9
				else
					v225 = v_u_10
				end
				local v_u_226 = v222(v223, v224, v225)
				v_u_1:AddItem(v_u_226, 0.4)
				p_u_69.animate(0.22, 0, function(p227)
					-- upvalues: (copy) v_u_226, (ref) p_u_69, (copy) v_u_206, (copy) v_u_221, (copy) v_u_207, (ref) v_u_10
					v_u_226.CFrame = p_u_69.aimAt(v_u_206.top + v_u_221 - Vector3.new(0, 9, 0) * p227, Vector3.new(-0, -1, -0))
					if p227 >= 1 then
						v_u_226:Destroy()
						p_u_69.pop(v_u_207 + v_u_221 + Vector3.new(0, 0.5, 0), v_u_10, 0.6, 2.4, 0.2)
					end
				end)
			end
			v_u_4.flash(v_u_206.top, v_u_9, 14, 0.25)
			v_u_4.ring(v_u_207, v_u_10, v_u_205 * 1.1, 0.45, v_u_6.Ring)
			v_u_4.ring(v_u_207, v_u_7, v_u_205 * 0.8, 0.35, v_u_6.Shockwave)
			p_u_69.burst("Shockwave", v_u_207 + Vector3.new(0, 0.3, 0), v_u_7, v_u_205 / 18)
			if not p203.lite then
				for v228 = 1, 6 do
					local v229 = v228 * 6.283185307179586 / 6 + math.random() * 0.5
					local v230 = v_u_205 * (0.3 + math.random() * 0.6)
					local v231 = math.cos(v229) * v230
					local v232 = 2 + math.random() * 4
					local v233 = math.sin(v229) * v230
					local v_u_234 = v_u_207 + Vector3.new(v231, v232, v233)
					p_u_69.after(v228 * 0.05, function()
						-- upvalues: (ref) p_u_69, (copy) v_u_234, (ref) v_u_10
						p_u_69.glint(v_u_234, v_u_10, 3.5, 0.3)
					end)
				end
			end
			v_u_5.play("Crit", {
				["at"] = v_u_207,
				["volume"] = p203.mine and 0.5 or 0.3
			})
			if p203.mine then
				v_u_4.shake(0.25, 0.25)
			end
		end,
		["hit"] = function(p235, p236, p237) -- name: hit
			-- upvalues: (copy) v_u_132, (copy) p_u_69, (ref) v_u_7, (copy) v_u_197
			local v238 = (v_u_132[p235] or 0) + 1
			v_u_132[p235] = v238
			p_u_69.burst("Impact", p236, v_u_7, 0.6)
			local v239 = v_u_197
			local v240 = not p235.lite
			if v240 then
				v240 = v238 <= 8
			end
			v239(p235, p236, p237, v240)
		end
	}
	local v_u_241 = {
		10,
		22,
		35,
		49,
		63,
		78
	}
	local v_u_242 = {
		3.2,
		3.6,
		4,
		4.4,
		4.8,
		5.2
	}
	local v_u_243 = {}
	setmetatable(v_u_243, {
		["__mode"] = "k"
	})
	local function v_u_310(p244, p245) -- name: dreamUp
		-- upvalues: (ref) v_u_52, (ref) v_u_23, (copy) p_u_69, (ref) v_u_9, (ref) v_u_6, (ref) v_u_15, (ref) v_u_1, (copy) v_u_241, (ref) v_u_16, (ref) v_u_4, (ref) v_u_10, (ref) v_u_12, (copy) v_u_242
		local v_u_246 = p244.dir
		local v_u_247 = p244.eye - v_u_246 * 1.5 + Vector3.new(0, 7, 0)
		local v248 = p245 + 0.08 + 0.4 + 0.28 + 1.5
		local v_u_249 = v_u_52(v_u_23(v_u_247, v_u_246, Vector3.new(0, 1, 0)), 0.1, p_u_69.iris("yumegan"), v_u_9, 0)
		local v_u_250 = v_u_52(v_u_23(v_u_247 - v_u_246 * 0.3, v_u_246, Vector3.new(0, 1, 0)), 0.1, v_u_6.YumeStar, v_u_15, 0)
		v_u_1:AddItem(v_u_249, v248)
		v_u_1:AddItem(v_u_250, v248)
		local v_u_251 = {}
		local v252 = p244.lite and 3 or #v_u_241
		local v253 = p244.target.X
		local v254 = p244.eye.Y - 1.2
		local v255 = p244.target.Z
		local v256 = Vector3.new(v253, v254, v255)
		local v_u_257
		if (v256 - v_u_247).Magnitude > 1 then
			v_u_257 = (v256 - v_u_247).Unit
		else
			v_u_257 = v_u_246
		end
		local v258 = (v256 - v_u_247).Magnitude
		local v_u_259 = v_u_246:Cross(Vector3.new(0, 1, 0))
		for v260 = 1, v252 do
			local v261
			if p244.lite then
				v261 = v260 * 2
			else
				v261 = v260
			end
			local v262 = v_u_241[v261] + 1.5
			local v263 = v258 - 4
			local v264 = math.max(v263, 2)
			local v265 = v_u_247 + v_u_257 * math.min(v262, v264)
			local v266 = v265 + v_u_259 * ((v260 % 2 == 0 and 1 or -1) * (v260 * 1.5 + 6)) + Vector3.new(0, 1, 0) * (v260 % 3 * 3 + 5)
			local v267 = v_u_52(v_u_23(v266, v_u_257, Vector3.new(0, 1, 0)), 0.1, v_u_6.Ring, v_u_16, 0)
			v_u_1:AddItem(v267, v248)
			local v268
			if p244.lite then
				v268 = nil
			else
				local v269 = {
					["shape"] = v_u_12
				}
				v268 = v_u_4.part(Vector3.new(0.9, 0.9, 0.9), CFrame.new(v266), v_u_10, v269)
				v_u_1:AddItem(v268, v248)
			end
			local v270 = {
				["p"] = nil,
				["node"] = nil,
				["at"] = nil,
				["r"] = nil,
				["from"] = nil,
				["flared"] = false,
				["p"] = v267,
				["node"] = v268,
				["at"] = v265,
				["r"] = v_u_242[v261],
				["from"] = v266
			}
			table.insert(v_u_251, v270)
		end
		local v_u_271 = {
			["eye"] = nil,
			["star"] = nil,
			["at"] = nil,
			["dir"] = nil,
			["hoops"] = nil,
			["born"] = nil,
			["closeAt"] = nil,
			["eye"] = v_u_249,
			["star"] = v_u_250,
			["at"] = v_u_247,
			["dir"] = v_u_257,
			["hoops"] = v_u_251,
			["born"] = os.clock()
		}
		local v_u_272 = math.max(p245, 0.12) + 0.05
		p_u_69.runNow(function()
			-- upvalues: (copy) v_u_271, (copy) v_u_249, (copy) v_u_250, (copy) v_u_251, (ref) v_u_23, (copy) v_u_247, (copy) v_u_246, (copy) v_u_272, (copy) v_u_257, (copy) v_u_259
			local v273 = os.clock()
			local v274 = v273 - v_u_271.born
			local v275 = v274 / 0.22
			local v276 = math.clamp(v275, 0, 1) - 1
			local v277 = v276 * 2.7 * v276 * v276 + 1 + v276 * 1.7 * v276
			local v278 = v_u_271.closeAt
			local v279
			if v278 then
				local v280 = (v273 - v278) / 0.25
				v279 = math.clamp(v280, 0, 1)
			else
				v279 = 0
			end
			if v279 >= 1 then
				v_u_249:Destroy()
				v_u_250:Destroy()
				for _, v281 in v_u_251 do
					v281.p:Destroy()
					local v282 = v281.node
					if not v282 then
						continue
					end
					v282:Destroy()
				end
				return false
			end
			local v283 = v277 * (1 - v279)
			local v284 = v_u_249
			local v285 = v283 * 3.8
			local v286 = math.max(v285, 0.03)
			local v287 = v286 * 2
			local v288 = v286 * 2
			v284.Size = Vector3.new(v287, 0.05, v288)
			v_u_249.CFrame = v_u_23(v_u_247, v_u_246, CFrame.fromAxisAngle(v_u_246, -v274 * 0.8):VectorToWorldSpace(Vector3.new(0, 1, 0)))
			local v289 = v_u_250
			local v290 = v283 * 7.9799999999999995
			local v291 = v274 * 20
			local v292 = v290 * (math.sin(v291) * 0.05 + 1)
			local v293 = math.max(v292, 0.03)
			local v294 = v293 * 2
			local v295 = v293 * 2
			v289.Size = Vector3.new(v294, 0.05, v295)
			v_u_250.CFrame = v_u_23(v_u_247 - v_u_246 * 0.3, v_u_246, CFrame.fromAxisAngle(v_u_246, v274 * 0.5):VectorToWorldSpace(Vector3.new(0, 1, 0)))
			for v296, v297 in v_u_251 do
				local v298 = (v274 - (v296 - 1) * 0.025) / v_u_272
				local v299 = math.clamp(v298, 0, 1)
				local v300 = v299 * v299 * (3 - v299 * 2)
				local v301 = v297.from:Lerp(v297.at, v300)
				local v302 = v274 * (v296 * 0.3 + 2) + (not v297.flared and 0 or v274 * 6)
				local v303 = v297.p
				local v304 = v297.r * math.max(v300, 0.15) * (1 - v279)
				local v305 = math.max(v304, 0.03)
				local v306 = v305 * 2
				local v307 = v305 * 2
				v303.Size = Vector3.new(v306, 0.05, v307)
				v297.p.CFrame = v_u_23(v301, v_u_257, CFrame.fromAxisAngle(v_u_257, v302):VectorToWorldSpace(Vector3.new(0, 1, 0)))
				local v308 = v297.node
				if not v308 then
					continue
				end
				local v309 = v274 * (5 - v296 * 0.4) + v296
				v308.CFrame = CFrame.new(v301 + (v_u_259 * math.cos(v309) + Vector3.new(0, 1, 0) * math.sin(v309)) * v297.r * v300)
			end
			return v274 < 4
		end)
		return v_u_271
	end
	local function v_u_348(p_u_311, p_u_312, p_u_313) -- name: fire
		-- upvalues: (ref) v_u_4, (ref) v_u_9, (ref) v_u_13, (ref) v_u_7, (ref) v_u_11, (ref) v_u_1, (copy) p_u_69, (ref) v_u_68, (copy) v_u_88, (ref) v_u_6, (ref) v_u_15, (ref) v_u_10, (ref) v_u_16, (ref) v_u_14, (ref) v_u_5
		local v_u_314 = p_u_311.lite
		local v_u_315 = p_u_312.at
		local v_u_316 = p_u_312.dir
		local v317 = {
			["shape"] = v_u_13
		}
		local v318 = v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_315), v_u_9, v317)
		local v319 = {
			["shape"] = nil,
			["transparency"] = 0.4,
			["shape"] = v_u_13
		}
		local v_u_320 = { v318, (v_u_4.part(Vector3.new(1, 1, 1), CFrame.new(v_u_315), v_u_7, v319)) }
		if not v_u_314 then
			local v321 = v_u_4.part
			local v322 = CFrame.new(v_u_315)
			local v323 = v_u_11
			local v324 = {
				["shape"] = nil,
				["transparency"] = 0.78,
				["shape"] = v_u_13
			}
			table.insert(v_u_320, v321(Vector3.new(1, 1, 1), v322, v323, v324))
		end
		local v_u_325 = { 1.8, 4.6, 9 }
		for _, v326 in v_u_320 do
			v_u_1:AddItem(v326, 1.26)
		end
		if p_u_311.mine then
			p_u_69.light(v318, v_u_7, 18)
		end
		p_u_69.groundLine(v_u_315, p_u_313, 6, v_u_7, 0.9, 0.3)
		v_u_4.flash(v_u_315, v_u_9, 10, 0.2)
		local v_u_327 = os.clock()
		local v_u_328 = 0
		local v_u_329 = false
		p_u_69.runNow(function()
			-- upvalues: (copy) v_u_327, (copy) v_u_315, (copy) p_u_313, (copy) v_u_320, (ref) v_u_68, (copy) v_u_325, (copy) p_u_312, (ref) v_u_4, (ref) v_u_9, (copy) v_u_314, (ref) v_u_88, (ref) v_u_6, (ref) v_u_15, (ref) p_u_69, (ref) v_u_10, (ref) v_u_328, (copy) v_u_316, (ref) v_u_1, (ref) v_u_329, (ref) v_u_16, (ref) v_u_7, (ref) v_u_14, (ref) v_u_5, (copy) p_u_311
			local v330 = os.clock() - v_u_327
			local v331 = v330 / 0.08
			local v332 = math.clamp(v331, 0, 1)
			local v333
			if v330 < 0.48000000000000004 then
				v333 = 1
			else
				local v334 = 1 - (v330 - 0.08 - 0.4) / 0.28
				v333 = math.max(v334, 0)
			end
			local v335 = v_u_315:Lerp(p_u_313, v332)
			local v336 = v330 * 50
			local v337 = math.sin(v336) * 0.06 + 1
			for v338, v339 in v_u_320 do
				v_u_68(v339, v_u_315, v335, v_u_325[v338] * v333 * v337)
			end
			local v340 = (v335 - v_u_315).Magnitude
			for _, v341 in p_u_312.hoops do
				if v341.flared or (v341.at - v_u_315).Magnitude > v340 + 1 then
					continue
				end
				v341.flared = true
				v_u_4.flash(v341.at, v_u_9, v341.r * 2.4, 0.2)
				if v_u_314 then
					continue
				end
				v_u_88(v341.at, v341.r * 0.6, v341.r * 1.8, v_u_6.YumeStar, v_u_15, 0.3, 3, 0)
				p_u_69.spikes(v341.at, v_u_10, 4, 6, 0.2, nil, nil, false)
			end
			if not v_u_314 and (v332 >= 1 and (v330 < 0.48000000000000004 and v_u_328 <= v330)) then
				v_u_328 = v330 + 0.035
				local v_u_342 = v_u_315 + (v_u_316:Cross(Vector3.new(0, 1, 0)) * (math.random() - 0.5) * 6 + Vector3.new(0, 1, 0) * (math.random() - 0.5) * 5)
				local v_u_343 = v_u_4.part(Vector3.new(0.3, 0.3, 6), CFrame.lookAt(v_u_342, v_u_342 + (p_u_313 - v_u_315)), v_u_9)
				v_u_1:AddItem(v_u_343, 0.35)
				local v_u_344 = (p_u_313 - v_u_315).Magnitude
				p_u_69.animate(0.28, 0, function(p345)
					-- upvalues: (copy) v_u_342, (ref) p_u_313, (ref) v_u_315, (copy) v_u_344, (copy) v_u_343
					local v346 = v_u_342 + (p_u_313 - v_u_315).Unit * v_u_344 * p345
					v_u_343.CFrame = CFrame.lookAt(v346, v346 + (p_u_313 - v_u_315))
					if p345 >= 1 then
						v_u_343:Destroy()
					end
				end)
			end
			if v332 >= 1 and not v_u_329 then
				v_u_329 = true
				v_u_88(p_u_313, 3, 15, v_u_6.YumeStar, v_u_15, 0.5, 1.5, 0)
				v_u_88(p_u_313, 2, 9, v_u_6.YumeOrbits, v_u_16, 0.45, -2, 0.1)
				p_u_69.pop(p_u_313, v_u_9, 3, 12, 0.3, 0.2)
				p_u_69.pop(p_u_313, v_u_7, 4, 18, 0.45, 0.5, v_u_14)
				v_u_4.ring(p_u_69.ground(p_u_313), v_u_10, 14, 0.45, v_u_6.Shockwave)
				p_u_69.burst("Explosion", p_u_313, v_u_7, 1.4)
				p_u_69.spikes(p_u_313, v_u_9, v_u_314 and 5 or 12, 14, 0.35)
				v_u_5.play("Explosion", {
					["at"] = p_u_313,
					["volume"] = p_u_311.mine and 0.9 or 0.5
				})
				if p_u_311.mine then
					v_u_4.shake(0.5, 0.4)
				end
			end
			if v330 < 0.76 then
				return true
			end
			for _, v347 in v_u_320 do
				v347:Destroy()
			end
			p_u_312.closeAt = os.clock()
			return false
		end)
	end
	v70.yumegan_r = {
		["castSound"] = "Laser",
		["cast"] = nil,
		["windup"] = nil,
		["beam"] = nil,
		["hit"] = nil,
		["cast"] = function(p349) -- name: cast
			-- upvalues: (copy) p_u_69, (ref) v_u_7, (ref) v_u_10, (ref) v_u_4
			p_u_69.skillCast(p349, v_u_7, true)
			if not p349.lite then
				p_u_69.glint(p349.eye, v_u_10, 5 * p349.size, 0.25)
			end
			if p349.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p350, _, p351) -- name: windup
			-- upvalues: (copy) v_u_243, (copy) v_u_310
			v_u_243[p350] = v_u_310(p350, p351)
		end,
		["beam"] = function(p352, _, p353) -- name: beam
			-- upvalues: (copy) v_u_243, (copy) v_u_310, (copy) v_u_348
			local v354 = v_u_243[p352] or v_u_310(p352, 0)
			v_u_243[p352] = nil
			v_u_348(p352, v354, p353)
		end,
		["hit"] = function(p355, p356, _) -- name: hit
			-- upvalues: (copy) p_u_69, (ref) v_u_7, (ref) v_u_9
			p_u_69.burst("Impact", p356, v_u_7, 0.8)
			if not p355.lite then
				p_u_69.glint(p356, v_u_9, 3, 0.16)
			end
			p_u_69.beamHitSound(p355, p356, "Hit")
		end
	}
	return v70
end