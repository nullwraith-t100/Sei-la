local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = {
	["CLIPS"] = {
		"idle",
		"walk",
		"leap",
		"intro",
		"roar",
		"claw_left",
		"claw_right",
		"tail_sweep",
		"stomp",
		"bomb_charge",
		"bomb_fire",
		"flinch",
		"death"
	}
}
local v5 = nil
local v_u_6 = CFrame.identity
local v_u_7 = {
	["idle"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 1.5,
			["rise"] = 0.012,
			["head"] = 0.05
		},
		{
			["at"] = 3
		}
	},
	["intro"] = {
		{
			["at"] = 0,
			["rise"] = 0.3,
			["lean"] = 0.3,
			["armL"] = 0.9,
			["armR"] = 0.9,
			["tails"] = 0.6
		},
		{
			["at"] = 0.5,
			["lean"] = 0.35,
			["armL"] = -0.2,
			["armR"] = -0.2
		},
		{
			["at"] = 1,
			["lean"] = 0.2
		},
		{
			["at"] = 1.4,
			["lean"] = -0.25,
			["head"] = 0.6,
			["armL"] = 0.5,
			["armR"] = 0.5,
			["mouth"] = 0.4
		},
		{
			["at"] = 1.6,
			["lean"] = -0.3,
			["head"] = 0.8,
			["tails"] = 1,
			["mouth"] = 1
		},
		{
			["at"] = 3.2,
			["lean"] = -0.25,
			["head"] = 0.7,
			["tails"] = 1,
			["mouth"] = 1
		},
		{
			["at"] = 4
		}
	},
	["roar"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 0.9,
			["lean"] = 0.25,
			["head"] = -0.3
		},
		{
			["at"] = 1.2,
			["lean"] = -0.35,
			["head"] = 0.7,
			["tails"] = 1,
			["armL"] = 0.4,
			["armR"] = 0.4,
			["mouth"] = 1
		},
		{
			["at"] = 2,
			["lean"] = -0.3,
			["head"] = 0.6,
			["tails"] = 1,
			["mouth"] = 1
		},
		{
			["at"] = 2.6
		}
	},
	["claw_left"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 1,
			["twist"] = -0.4,
			["armL"] = 1.7,
			["lean"] = -0.1
		},
		{
			["at"] = 1.2,
			["twist"] = 0.35,
			["armL"] = -0.3,
			["lean"] = 0.35
		},
		{
			["at"] = 1.6,
			["twist"] = 0.3,
			["armL"] = -0.2,
			["lean"] = 0.3
		},
		{
			["at"] = 2.2
		}
	},
	["claw_right"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 1,
			["twist"] = 0.4,
			["armR"] = 1.7,
			["lean"] = -0.1
		},
		{
			["at"] = 1.2,
			["twist"] = -0.35,
			["armR"] = -0.3,
			["lean"] = 0.35
		},
		{
			["at"] = 1.6,
			["twist"] = -0.3,
			["armR"] = -0.2,
			["lean"] = 0.3
		},
		{
			["at"] = 2.2
		}
	},
	["tail_sweep"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 1.2,
			["twist"] = 0.6,
			["swing"] = -0.9,
			["tails"] = -0.4
		},
		{
			["at"] = 1.5,
			["twist"] = -0.1,
			["swing"] = 0.5,
			["tails"] = -0.6
		},
		{
			["at"] = 1.9,
			["twist"] = -0.7,
			["swing"] = 1.3,
			["tails"] = -0.5
		},
		{
			["at"] = 3
		}
	},
	["stomp"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 1,
			["rise"] = 0.08,
			["lean"] = -0.4,
			["armL"] = 1.4,
			["armR"] = 1.4,
			["head"] = 0.2
		},
		{
			["at"] = 1.3,
			["lean"] = 0.4,
			["armL"] = -0.3,
			["armR"] = -0.3,
			["head"] = -0.2
		},
		{
			["at"] = 1.8,
			["lean"] = 0.35,
			["armL"] = -0.3,
			["armR"] = -0.3
		},
		{
			["at"] = 2.4
		}
	},
	["bomb_charge"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 0.8,
			["lean"] = 0.15,
			["head"] = -0.2,
			["tails"] = 1,
			["mouth"] = 0.5
		},
		{
			["at"] = 3,
			["lean"] = 0.3,
			["head"] = -0.35,
			["tails"] = 1,
			["armL"] = -0.2,
			["armR"] = -0.2,
			["mouth"] = 1
		}
	},
	["bomb_fire"] = {
		{
			["at"] = 0,
			["lean"] = 0.3,
			["head"] = -0.35,
			["tails"] = 1,
			["armL"] = -0.2,
			["armR"] = -0.2,
			["mouth"] = 1
		},
		{
			["at"] = 0.35,
			["lean"] = -0.3,
			["head"] = 0.25,
			["tails"] = 1,
			["mouth"] = 1
		},
		{
			["at"] = 0.8,
			["lean"] = -0.2,
			["head"] = 0.15,
			["tails"] = 0.6,
			["mouth"] = 0.5
		},
		{
			["at"] = 1.8
		}
	},
	["walk"] = {
		{
			["at"] = 0,
			["armL"] = 0.3,
			["armR"] = -0.3
		},
		{
			["at"] = 0.3,
			["rise"] = 0.01
		},
		{
			["at"] = 0.6,
			["armL"] = -0.3,
			["armR"] = 0.3
		},
		{
			["at"] = 0.9,
			["rise"] = 0.01
		},
		{
			["at"] = 1.2,
			["armL"] = 0.3,
			["armR"] = -0.3
		}
	},
	["leap"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 0.5,
			["lean"] = 0.3,
			["rise"] = -0.03
		},
		{
			["at"] = 0.6,
			["lean"] = -0.2,
			["armL"] = 0.9,
			["armR"] = 0.9
		},
		{
			["at"] = 0.95,
			["rise"] = 0.25,
			["lean"] = 0.1,
			["armL"] = 0.8,
			["armR"] = 0.8,
			["tails"] = -0.4
		},
		{
			["at"] = 1.3,
			["lean"] = 0.35,
			["rise"] = -0.03,
			["mouth"] = 1
		},
		{
			["at"] = 2.2
		}
	},
	["flinch"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 0.12,
			["lean"] = -0.18,
			["head"] = 0.25,
			["roll"] = 0.05
		},
		{
			["at"] = 0.8
		}
	},
	["death"] = {
		{
			["at"] = 0
		},
		{
			["at"] = 0.6,
			["lean"] = -0.3,
			["head"] = 0.6,
			["armL"] = 0.6,
			["armR"] = 0.6,
			["mouth"] = 1
		},
		{
			["at"] = 1.4,
			["lean"] = -0.1,
			["head"] = 0.3,
			["roll"] = 0.12
		},
		{
			["at"] = 2.3,
			["roll"] = 1.45,
			["rise"] = -0.05,
			["lean"] = 0.2,
			["head"] = -0.2,
			["tails"] = -0.6
		},
		{
			["at"] = 2.6,
			["roll"] = 1.38,
			["rise"] = -0.04
		},
		{
			["at"] = 4,
			["roll"] = 1.45,
			["rise"] = -0.06,
			["tails"] = -0.8,
			["head"] = -0.3
		}
	}
}
local v_u_8 = {
	"lean",
	"twist",
	"rise",
	"roll",
	"head",
	"mouth",
	"armL",
	"armR",
	"tails",
	"swing"
}
local function v_u_22(p9, p10) -- name: knobsAt
	-- upvalues: (copy) v_u_7, (copy) v_u_8
	local v11 = v_u_7[p9] or v_u_7.idle
	local v12 = v11[1]
	local v13 = v11[#v11]
	local v14 = {}
	for v15 = 1, #v11 - 1 do
		if v11[v15].at > p10 or p10 > v11[v15 + 1].at then
			continue
		end
		v12 = v11[v15]
		v13 = v11[v15 + 1]
	end
	local v16 = v13.at - v12.at
	local v17
	if v16 > 0 then
		local v18 = (p10 - v12.at) / v16
		local v19 = math.clamp(v18, 0, 1)
		v17 = v19 * v19 * (3 - v19 * 2)
	else
		v17 = 1
	end
	if v11[#v11].at <= p10 then
		v12 = v11[#v11]
		v13 = v11[#v11]
		v17 = 1
	end
	for _, v20 in v_u_8 do
		local v21 = v12[v20] or 0
		v14[v20] = v21 + ((v13[v20] or 0) - v21) * v17
	end
	return v14
end
local v_u_23 = Color3.fromRGB(235, 104, 28)
local v_u_24 = Color3.fromRGB(150, 52, 18)
local v_u_25 = Color3.fromRGB(255, 40, 30)
local v_u_26 = v5
local v_u_27 = {}
local function v_u_95(p_u_28) -- name: buildStandIn
	-- upvalues: (copy) v_u_6, (copy) v_u_23, (copy) v_u_24, (copy) v_u_25, (copy) v_u_3, (copy) v_u_22
	local v_u_29 = Instance.new("Model")
	v_u_29.Name = "Kurama"
	local v_u_30 = table.create(33, 0)
	local v_u_31 = table.create(33, v_u_6)
	local v32 = CFrame.new(0, 0.38, 0.1)
	v_u_30[2] = 1
	v_u_31[2] = v32
	local v33 = CFrame.new(0, 0.26, -0.5)
	v_u_30[3] = 2
	v_u_31[3] = v33
	local v34 = CFrame.new(0, 0, -0.14)
	v_u_30[4] = 3
	v_u_31[4] = v34
	local v35 = CFrame.new(-0.2, 0.14, -0.4)
	v_u_30[5] = 2
	v_u_31[5] = v35
	local v36 = CFrame.new(0.2, 0.14, -0.4)
	v_u_30[6] = 2
	v_u_31[6] = v36
	for v37 = 1, 9 do
		for v38 = 1, 3 do
			local v39 = (v37 - 1) * 3 + 7 + (v38 - 1)
			if v38 == 1 then
				local v40 = CFrame.new(0, 0.04, 0.36)
				v_u_30[v39] = 2
				v_u_31[v39] = v40
			else
				local v41 = v39 - 1
				local v42 = CFrame.new(0, 0, 0.22)
				v_u_30[v39] = v41
				v_u_31[v39] = v42
			end
		end
	end
	for v43 = 1, 33 do
		local v44 = v_u_31[v43]
		v_u_31[v43] = v44.Rotation + v44.Position * p_u_28
	end
	local v_u_45 = {}
	local v_u_46 = {}
	local v_u_47 = {}
	local function v60(p48, p49, p50, p51, p52, p53) -- name: part
		-- upvalues: (copy) p_u_28, (copy) v_u_29, (copy) v_u_45, (copy) v_u_46, (copy) v_u_47
		local v54 = Instance.new("Part")
		v54.Anchored = true
		v54.CanCollide = false
		v54.CanTouch = false
		v54.CanQuery = false
		v54.Shape = p52 or Enum.PartType.Block
		v54.Size = p50 * p_u_28
		v54.Color = p51
		local v55
		if p53 then
			v55 = Enum.Material.Neon
		else
			v55 = Enum.Material.SmoothPlastic
		end
		v54.Material = v55
		v54.TopSurface = Enum.SurfaceType.Smooth
		v54.BottomSurface = Enum.SurfaceType.Smooth
		v54.Parent = v_u_29
		local v56 = v_u_45
		table.insert(v56, v54)
		local v57 = v_u_46
		table.insert(v57, p48)
		local v58 = v_u_47
		local v59 = p49.Rotation + p49.Position * p_u_28
		table.insert(v58, v59)
	end
	local v61 = Enum.PartType.Ball
	v60(2, CFrame.new(0, 0.1, -0.06), Vector3.new(0.42, 0.4, 0.62), v_u_23)
	v60(2, CFrame.new(0, 0.16, -0.32), Vector3.new(0.46, 0.46, 0.46), v_u_23, v61)
	v60(2, CFrame.new(0, 0.02, 0.2), Vector3.new(0.4, 0.4, 0.4), v_u_23, v61)
	v60(1, CFrame.new(-0.17, 0.16, 0.3), Vector3.new(0.14, 0.32, 0.2), v_u_24)
	v60(1, CFrame.new(0.17, 0.16, 0.3), Vector3.new(0.14, 0.32, 0.2), v_u_24)
	v60(3, CFrame.new(0, 0.08, -0.06), Vector3.new(0.3, 0.24, 0.3), v_u_23)
	v60(3, CFrame.new(0, 0.05, -0.24), Vector3.new(0.15, 0.1, 0.16), v_u_23)
	v60(3, CFrame.new(-0.1, 0.27, -0.02), Vector3.new(0.07, 0.18, 0.06), v_u_24)
	v60(3, CFrame.new(0.1, 0.27, -0.02), Vector3.new(0.07, 0.18, 0.06), v_u_24)
	v60(3, CFrame.new(-0.08, 0.12, -0.215), Vector3.new(0.06, 0.03, 0.02), v_u_25, nil, true)
	v60(3, CFrame.new(0.08, 0.12, -0.215), Vector3.new(0.06, 0.03, 0.02), v_u_25, nil, true)
	v60(4, CFrame.new(0, -0.03, -0.1), Vector3.new(0.13, 0.05, 0.16), v_u_24)
	for _, v62 in { 5, 6 } do
		v60(v62, CFrame.new(0, -0.24, 0), Vector3.new(0.12, 0.5, 0.12), v_u_23)
		v60(v62, CFrame.new(0, -0.5, -0.05), Vector3.new(0.17, 0.07, 0.22), v_u_24)
	end
	for v63 = 1, 9 do
		for v64 = 1, 3 do
			local v65 = (v63 - 1) * 3 + 7 + (v64 - 1)
			local v66 = 0.13 - v64 * 0.025
			local v67 = CFrame.new(0, 0, 0.11)
			local v68 = Vector3.new(v66, v66, 0.253)
			local v69
			if v64 == 3 then
				v69 = v_u_24
			else
				v69 = v_u_23
			end
			v60(v65, v67, v68, v69)
		end
	end
	v_u_29.Parent = v_u_3
	local v_u_70 = table.create(33, v_u_6)
	local v_u_71 = table.create(#v_u_45, v_u_6)
	return {
		["model"] = nil,
		["joints"] = 33,
		["sample"] = nil,
		["apply"] = nil,
		["point"] = nil,
		["model"] = v_u_29,
		["sample"] = function(p72, p73, p74, p75) -- name: sample
			-- upvalues: (ref) v_u_22, (copy) p_u_28
			local v76 = v_u_22(p72, p73)
			p75[1] = CFrame.new(0, v76.rise * p_u_28, 0) * CFrame.Angles(0, v76.twist, 0) * CFrame.Angles(0, 0, -v76.roll)
			p75[2] = CFrame.Angles(-v76.lean, 0, 0)
			local v77 = CFrame.Angles
			local v78 = v76.head
			local v79 = p74 * 1.3
			p75[3] = v77(v78 + math.sin(v79) * 0.04, 0, 0)
			p75[4] = CFrame.Angles(-0.55 * v76.mouth, 0, 0)
			p75[5] = CFrame.Angles(v76.armL, 0, 0)
			p75[6] = CFrame.Angles(v76.armR, 0, 0)
			local v80 = 1 + 0.35 * v76.tails
			for v81 = 1, 9 do
				local v82 = (v81 - 1) / 8 * 2 - 1
				for v83 = 1, 3 do
					local v84 = (v81 - 1) * 3 + 7 + (v83 - 1)
					local v85 = p74 * 1.7 + v81 * 0.8 + v83 * 0.6
					local v86 = math.sin(v85) * 0.2
					if v83 == 1 then
						p75[v84] = CFrame.Angles(0, v82 * v80 + v76.swing, 0) * CFrame.Angles(-(0.55 + 0.3 * v76.tails), v86, 0)
					else
						p75[v84] = CFrame.Angles(-0.28 - 0.1 * v76.tails, v86, 0)
					end
				end
			end
		end,
		["apply"] = function(p87, p88) -- name: apply
			-- upvalues: (copy) v_u_30, (copy) v_u_70, (copy) v_u_31, (copy) v_u_46, (copy) v_u_71, (copy) v_u_47, (ref) v_u_3, (copy) v_u_45
			for v89 = 1, 33 do
				local v90 = v_u_30[v89]
				local v91
				if v90 == 0 then
					v91 = p88
				else
					v91 = v_u_70[v90]
				end
				v_u_70[v89] = v91 * v_u_31[v89] * p87[v89]
			end
			for v92, v93 in v_u_46 do
				v_u_71[v92] = v_u_70[v93] * v_u_47[v92]
			end
			v_u_3:BulkMoveTo(v_u_45, v_u_71, Enum.BulkMoveMode.FireCFrameChanged)
		end,
		["point"] = function(p94, _) -- name: point
			-- upvalues: (copy) v_u_70, (copy) p_u_28
			if p94 == "mouth" then
				return (v_u_70[4] * CFrame.new(0, p_u_28 * 0.02, p_u_28 * -0.2)).Position
			elseif p94 == "head" then
				return (v_u_70[3] * CFrame.new(0, p_u_28 * 0.08, p_u_28 * -0.06)).Position
			elseif p94 == "chest" then
				return (v_u_70[2] * CFrame.new(0, p_u_28 * 0.16, p_u_28 * -0.32)).Position
			elseif p94 == "hand_left" then
				return (v_u_70[5] * CFrame.new(0, p_u_28 * -0.5, p_u_28 * -0.05)).Position
			elseif p94 == "hand_right" then
				return (v_u_70[6] * CFrame.new(0, p_u_28 * -0.5, p_u_28 * -0.05)).Position
			else
				return (v_u_70[7] * CFrame.new(0, 0, p_u_28 * 0.3)).Position
			end
		end
	}
end
for v96 = 1, 64 do
	v_u_27[string.byte("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", v96)] = v96 - 1
end
local function v_u_133(p97, p98) -- name: fit
	local v99 = {}
	local v100 = {}
	for v101, v102 in p97.anchors do
		local v103 = p98[v102.bone]
		if not v103 then
			return nil
		end
		local v104 = v102.x
		local v105 = v102.y
		local v106 = v102.z
		v99[v101] = Vector3.new(v104, v105, v106)
		v100[v101] = v103.WorldPosition
	end
	local v107 = (v100[2] - v100[1]).Magnitude / (v99[2] - v99[1]).Magnitude
	local v108 = v100[1]
	local v109 = v100[2]
	local v110 = v100[3]
	local v111 = v100[4]
	local v112 = (v109 - v108).Unit
	local v113 = v112:Cross(v110 - v111).Unit
	local v114 = v113:Cross(v112)
	local v115 = CFrame.fromMatrix(Vector3.new(0, 0, 0), v112, v114, v113)
	local v116 = v99[1]
	local v117 = v99[2]
	local v118 = v99[3]
	local v119 = v99[4]
	local v120 = (v117 - v116).Unit
	local v121 = v120:Cross(v118 - v119).Unit
	local v122 = v121:Cross(v120)
	local v123 = v115 * CFrame.fromMatrix(Vector3.new(0, 0, 0), v120, v122, v121):Inverse()
	local v124 = CFrame.new(v100[1] - v123:VectorToWorldSpace(v99[1] * v107)) * v123
	local v125 = 0
	for _, v126 in p97.bones do
		local v127 = p98[v126.name]
		if not v127 then
			continue
		end
		local v128 = v126.x
		local v129 = v126.y
		local v130 = v126.z
		local v131 = v124 * (Vector3.new(v128, v129, v130) * v107)
		local v132 = (v127.WorldPosition - v131).Magnitude / v107
		v125 = math.max(v125, v132)
	end
	return {
		["frame"] = v124,
		["scale"] = v107,
		["err"] = v125
	}
end
local function v_u_248(p134, p135) -- name: buildReal
	-- upvalues: (ref) v_u_26, (copy) v_u_6, (copy) v_u_3, (copy) v_u_133, (copy) v_u_27
	local v_u_136 = v_u_26
	if not v_u_136 then
		v_u_136 = require(script.Parent.KuramaClips)
		v_u_26 = v_u_136
	end
	assert(v_u_136, "KuramaRig: no clip data")
	local v_u_137 = p134:Clone()
	local v138 = {}
	for _, v139 in v_u_137:GetDescendants() do
		if v139:IsA("Bone") then
			v138[v139.Name] = v139
			v139.Transform = v_u_6
		else
			if not v139:IsA("BasePart") then
				continue
			end
			v139.Anchored = true
			v139.CanCollide = false
			v139.CanTouch = false
			v139.CanQuery = false
		end
	end
	v_u_137.Parent = v_u_3
	local v140 = v_u_133(v_u_136, v138)
	if not v140 then
		warn("KuramaRig: ReplicatedStorage.Kurama has no bones named like the clips; using the stand-in")
		v_u_137:Destroy()
		return nil
	end
	local v141 = p135 / v_u_136.height
	local v142 = v140.scale / v141 - 1
	if math.abs(v142) > 0.001 then
		v_u_137:ScaleTo(v_u_137:GetScale() * v141 / v140.scale)
		v140 = v_u_133(v_u_136, v138) or v140
	end
	if v140.err > 0.5 then
		warn(string.format("KuramaRig: imported bones are off the clips\' skeleton by %.2f studs", v140.err))
	end
	local v_u_143 = v140.scale
	local v144 = v140.frame:Inverse()
	local v_u_145 = v144 * v_u_137:GetPivot()
	local v_u_146 = #v_u_136.bones
	local v_u_147 = {}
	for v148, v149 in v_u_136.bones do
		v_u_147[v149.name] = v148
	end
	local v_u_150 = table.create(v_u_146, 0)
	local v_u_151 = table.create(v_u_146, 0)
	local v_u_152 = table.create(v_u_146, v_u_6)
	local v_u_153 = table.create(v_u_146, v_u_6)
	local v_u_154 = table.create(v_u_146, Vector3.new(0, 0, 0))
	local v_u_155 = {}
	for v156, v157 in v_u_136.bones do
		v_u_150[v156] = v_u_147[v157.parent] or 0
		local v158 = v138[v157.name]
		local v159 = CFrame.new
		local v160 = v157.x
		local v161 = v157.y
		local v162 = v157.z
		local v163 = v159(Vector3.new(v160, v161, v162) * v_u_143)
		if v158 then
			v_u_155[v156] = v158
			v163 = v144 * v158.WorldCFrame
			local v164 = v158.Parent
			if v164 and v164:IsA("Bone") then
				v_u_151[v156] = v_u_147[v164.Name] or 0
			end
		end
		v_u_152[v156] = v163
		v_u_153[v156] = v163:Inverse()
		v_u_154[v156] = v163.Position
	end
	local v_u_165 = {}
	local function v_u_180(p166) -- name: prepare
		-- upvalues: (copy) v_u_165, (ref) v_u_26, (copy) v_u_147, (copy) v_u_143
		local v167 = v_u_165[p166]
		if v167 then
			return v167
		end
		local v168 = v_u_26
		if not v168 then
			v168 = require(script.Parent.KuramaClips)
			v_u_26 = v168
		end
		assert(v168, "KuramaRig: no clip data")
		local v169 = v168.clips[p166]
		local v170 = "KuramaRig: no clip " .. p166
		assert(v169, v170)
		local v171 = {}
		local v172 = {}
		for v173, v174 in v169.bones do
			local v175 = v_u_147[v173]
			if not v175 then
				continue
			end
			v171[v175] = v174
		end
		for v176, v177 in v169.moves do
			local v178 = v_u_147[v176]
			if not v178 then
				continue
			end
			v172[v178] = v177
		end
		local v179 = {
			["q"] = v171,
			["m"] = v172,
			["reach"] = v169.reach * v_u_143,
			["rate"] = v169.rate,
			["frames"] = v169.frames
		}
		v_u_165[p166] = v179
		return v179
	end
	local function v_u_211(p181, p182, p183) -- name: frameAt
		-- upvalues: (ref) v_u_27
		local v184 = p181.q[p182]
		local v185 = p181.m[p182]
		local v186 = p183 * 6 + 1
		local v187, v188, v189
		if v184 then
			local v190 = v186 + 5
			local v191, v192, v193, v194, v195, v196 = string.byte(v184, v186, v190)
			v187 = (v_u_27[v191] * 64 + v_u_27[v192]) / 4095 * 2 - 1
			v188 = (v_u_27[v193] * 64 + v_u_27[v194]) / 4095 * 2 - 1
			v189 = (v_u_27[v195] * 64 + v_u_27[v196]) / 4095 * 2 - 1
		else
			v187 = 0
			v188 = 0
			v189 = 0
		end
		local v197, v198, v199
		if v185 then
			local v200 = v186 + 5
			local v201, v202, v203, v204, v205, v206 = string.byte(v185, v186, v200)
			local v207 = p181.reach
			v197 = ((v_u_27[v201] * 64 + v_u_27[v202]) / 4095 * 2 - 1) * v207
			v198 = ((v_u_27[v203] * 64 + v_u_27[v204]) / 4095 * 2 - 1) * v207
			v199 = ((v_u_27[v205] * 64 + v_u_27[v206]) / 4095 * 2 - 1) * v207
		else
			v197 = 0
			v198 = 0
			v199 = 0
		end
		local v208 = 1 - v187 * v187 - v188 * v188 - v189 * v189
		local v209 = math.max(0, v208)
		local v210 = math.sqrt(v209)
		return CFrame.new(v197, v198, v199, v187, v188, v189, v210)
	end
	local v_u_212 = table.create(v_u_146, v_u_6)
	local v_u_213 = nil
	return {
		["model"] = v_u_137,
		["joints"] = v_u_146,
		["sample"] = function(p214, p215, _, p216) -- name: sample
			-- upvalues: (copy) v_u_180, (copy) v_u_146, (copy) v_u_211, (ref) v_u_6
			local v217 = v_u_180(p214)
			local v218 = p215 * v217.rate
			local v219 = math.floor(v218)
			local v220 = v217.frames - 1
			local v221 = math.clamp(v219, 0, v220)
			local v222 = v221 + 1
			local v223 = v217.frames - 1
			local v224 = math.min(v222, v223)
			local v225 = v218 - v221
			local v226 = math.clamp(v225, 0, 1)
			for v227 = 1, v_u_146 do
				if v217.q[v227] or v217.m[v227] then
					local v228 = v_u_211(v217, v227, v221)
					if v226 > 0 and v224 ~= v221 then
						v228 = v228:Lerp(v_u_211(v217, v227, v224), v226)
					end
					p216[v227] = v228
				else
					p216[v227] = v_u_6
				end
			end
		end,
		["apply"] = function(p229, p230) -- name: apply
			-- upvalues: (copy) v_u_146, (copy) v_u_154, (copy) v_u_150, (copy) v_u_212, (copy) v_u_155, (copy) v_u_151, (copy) v_u_153, (copy) v_u_152, (ref) v_u_213, (copy) v_u_137, (copy) v_u_145
			for v231 = 1, v_u_146 do
				local v232 = v_u_154[v231]
				local v233 = CFrame.new(v232) * p229[v231] * CFrame.new(-v232)
				local v234 = v_u_150[v231]
				local v235 = v_u_212
				if v234 > 0 then
					v233 = v_u_212[v234] * v233
				end
				v235[v231] = v233
			end
			for v236 = 1, v_u_146 do
				local v237 = v_u_155[v236]
				if not v237 then
					continue
				end
				local v238 = v_u_151[v236]
				local v239 = v_u_212[v236]
				if v238 > 0 then
					v239 = v_u_212[v238]:Inverse() * v239
				end
				v237.Transform = v_u_153[v236] * v239 * v_u_152[v236]
			end
			if p230 ~= v_u_213 then
				v_u_137:PivotTo(p230 * v_u_145)
				v_u_213 = p230
			end
		end,
		["point"] = function(p240, p241) -- name: point
			-- upvalues: (copy) v_u_136, (copy) v_u_147, (copy) v_u_212, (copy) v_u_143
			local v242 = v_u_136.points[p240]
			local v243
			if v242 then
				v243 = v_u_147[v242.bone]
			else
				v243 = nil
			end
			if not (v242 and v243) then
				return p241.Position
			end
			local v244 = v_u_212[v243]
			local v245 = v242.x
			local v246 = v242.y
			local v247 = v242.z
			return p241 * (v244 * (Vector3.new(v245, v246, v247) * v_u_143))
		end
	}
end
function v_u_4.marker(p249, p250) -- name: marker
	-- upvalues: (ref) v_u_26
	local v251 = v_u_26
	if not v251 then
		v251 = require(script.Parent.KuramaClips)
		v_u_26 = v251
	end
	assert(v251, "KuramaRig: no clip data")
	local v252 = v251.clips[p249]
	if v252 then
		return v252.markers[p250]
	else
		return nil
	end
end
function v_u_4.length(p253) -- name: length
	-- upvalues: (ref) v_u_26
	local v254 = v_u_26
	if not v254 then
		v254 = require(script.Parent.KuramaClips)
		v_u_26 = v254
	end
	assert(v254, "KuramaRig: no clip data")
	local v255 = v254.clips[p253]
	local v256 = "KuramaRig: no clip " .. p253
	assert(v255, v256)
	return v255.length
end
function v_u_4.build(p257, p258) -- name: build
	-- upvalues: (ref) v_u_26, (copy) v_u_1, (copy) v_u_248, (copy) v_u_95, (copy) v_u_6, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	local v259 = v_u_26
	if not v259 then
		v259 = require(script.Parent.KuramaClips)
		v_u_26 = v259
	end
	assert(v259, "KuramaRig: no clip data")
	local v260
	if v259.real then
		v260 = v_u_1:FindFirstChild("Kurama")
		if not (v260 and v260:IsA("Model")) then
			v260 = nil
		end
	else
		v260 = nil
	end
	local v261
	if v260 then
		v261 = v_u_248(v260, p258)
	else
		v261 = nil
	end
	local v_u_262 = v261 or v_u_95(p258 * 0.28)
	local v_u_263 = v_u_262.model
	local v_u_264 = v_u_262.joints
	local v_u_265 = p257
	local v_u_266 = {
		["name"] = "idle",
		["clip"] = nil,
		["time"] = 0,
		["speed"] = 1,
		["loop"] = true
	}
	local v267 = v_u_26
	if not v267 then
		v267 = require(script.Parent.KuramaClips)
		v_u_26 = v267
	end
	assert(v267, "KuramaRig: no clip data")
	local v268 = v267.clips.idle
	assert(v268, "KuramaRig: no clip idle")
	v_u_266.clip = v268
	local v_u_269 = nil
	local v_u_270 = nil
	local v_u_271 = 0
	local v_u_272 = 0
	local v_u_273 = nil
	local v_u_274 = table.create(v_u_264, v_u_6)
	local v_u_275 = table.create(v_u_264, v_u_6)
	local v_u_276 = table.create(v_u_264, v_u_6)
	local v_u_277 = table.create(v_u_264, v_u_6)
	local v_u_278 = 0
	local v_u_279 = 0
	local v_u_280 = 0
	local v_u_281 = false
	local v_u_282 = nil
	local function v_u_306(p283) -- name: render
		-- upvalues: (ref) v_u_281, (ref) v_u_278, (ref) v_u_273, (ref) v_u_266, (ref) v_u_269, (copy) v_u_262, (copy) v_u_274, (ref) v_u_271, (ref) v_u_272, (copy) v_u_275, (ref) v_u_270, (copy) v_u_264, (copy) v_u_276, (copy) v_u_277, (ref) v_u_6, (ref) v_u_265, (ref) v_u_282
		v_u_281 = true
		v_u_278 = v_u_278 + p283
		local v284 = v_u_273
		if v284 then
			v284.time = v284.time + p283 * v284.speed
			local v285 = v284.clip.length
			local v286
			if v285 <= v284.time then
				if v284.loop then
					v284.time = v284.time % v285
					v286 = false
				else
					v284.time = v285
					v286 = true
				end
			else
				v286 = false
			end
			if v286 then
				v_u_273 = nil
				v284 = nil
			end
		end
		local v287 = v_u_266
		v287.time = v287.time + p283 * v287.speed
		local v288 = v287.clip.length
		local v289
		if v288 <= v287.time then
			if v287.loop then
				v287.time = v287.time % v288
				v289 = false
			else
				v287.time = v288
				v289 = true
			end
		else
			v289 = false
		end
		local v290 = v_u_269
		if v290 then
			v290.time = v290.time + p283 * v290.speed
			local v291 = v290.clip.length
			if v291 <= v290.time then
				if v290.loop then
					v290.time = v290.time % v291
				else
					v290.time = v291
				end
			end
		end
		v_u_262.sample(v_u_266.name, v_u_266.time, v_u_278, v_u_274)
		if v_u_271 > 0 and v_u_272 < v_u_271 then
			v_u_272 = v_u_272 + p283
			local v292 = v_u_272 / v_u_271
			local v293 = math.clamp(v292, 0, 1)
			local v294 = v293 * v293 * (3 - v293 * 2)
			local v295 = v_u_275
			if v290 then
				v_u_262.sample(v290.name, v290.time, v_u_278, v_u_275)
			elseif v_u_270 then
				v295 = v_u_270
			end
			for v296 = 1, v_u_264 do
				v_u_274[v296] = v295[v296]:Lerp(v_u_274[v296], v294)
			end
			if v_u_271 <= v_u_272 then
				v_u_269 = nil
				v_u_270 = nil
			end
		end
		if v284 then
			v_u_262.sample(v284.name, v284.time, v_u_278, v_u_276)
			v_u_262.sample(v284.name, 0, v_u_278, v_u_277)
			local v297 = v284.clip.length
			local v298 = v284.time / 0.08
			local v299 = (v297 - v284.time) / 0.08
			local v300 = math.min(v298, v299, 1)
			local v301 = math.clamp(v300, 0, 1)
			local v302 = v301 * v301 * (3 - v301 * 2)
			for v303 = 1, v_u_264 do
				local v304 = v_u_277[v303]:Inverse() * v_u_276[v303]
				v_u_274[v303] = v_u_274[v303] * v_u_6:Lerp(v304, v302)
			end
		end
		v_u_262.apply(v_u_274, v_u_265)
		v_u_281 = false
		local v305 = v_u_266.clip.after
		if v289 and v305 then
			v_u_282:play(v305)
		end
	end
	local v_u_310 = v_u_2.RenderStepped:Connect(function(p307)
		-- upvalues: (copy) v_u_263, (ref) v_u_279, (ref) v_u_280, (ref) v_u_3, (ref) v_u_265, (copy) v_u_306
		if v_u_263.Parent then
			v_u_279 = v_u_279 + 1
			v_u_280 = v_u_280 + p307
			local v308 = v_u_3.CurrentCamera
			if not v308 or ((v308.CFrame.Position - v_u_265.Position).Magnitude <= 700 or v_u_279 % 3 == 0) then
				local v309 = v_u_280
				v_u_280 = 0
				v_u_306(v309)
			end
		else
			return
		end
	end)
	v_u_282 = {
		["model"] = v_u_263,
		["height"] = p258,
		["standIn"] = v261 == nil,
		["play"] = function(_, p311, p312) -- name: play
			-- upvalues: (ref) v_u_26, (ref) v_u_273, (ref) v_u_271, (ref) v_u_272, (ref) v_u_270, (copy) v_u_264, (ref) v_u_6, (copy) v_u_274, (ref) v_u_269, (ref) v_u_266, (ref) v_u_281, (copy) v_u_306
			local v313 = v_u_26
			if not v313 then
				v313 = require(script.Parent.KuramaClips)
				v_u_26 = v313
			end
			assert(v313, "KuramaRig: no clip data")
			local v314 = v313.clips[p311]
			local v315 = "KuramaRig: no clip " .. p311
			assert(v314, v315)
			local v316 = p312 and (p312.speed or 1) or 1
			local v317 = math.max(v316, 0.01)
			local v318 = v314.loop
			if p312 and p312.loop ~= nil then
				v318 = p312.loop
			end
			local v319 = p312 and (p312.at or 0) or 0
			local v320 = v314.length
			local v321 = {
				["name"] = p311,
				["clip"] = v314,
				["time"] = math.clamp(v319, 0, v320),
				["speed"] = v317,
				["loop"] = v318
			}
			if v314.layer then
				v_u_273 = v321
				return v314.length / v317
			end
			local v322 = (not p312 or p312.fade == nil) and 0.25 or p312.fade
			if v322 > 0 then
				if v_u_271 > 0 and v_u_272 < v_u_271 or v_u_270 then
					local v323 = v_u_264
					local v324 = table.create(v323, v_u_6)
					for v325 = 1, v_u_264 do
						v324[v325] = v_u_274[v325]
					end
					v_u_270 = v324
					v_u_269 = nil
				else
					v_u_269 = v_u_266
					v_u_270 = nil
				end
				v_u_271 = v322
				v_u_272 = 0
			else
				v_u_269 = nil
				v_u_270 = nil
				v_u_271 = 0
				v_u_272 = 0
			end
			v_u_266 = v321
			if not v_u_281 then
				v_u_306(0)
			end
			return v314.length / v317
		end,
		["marker"] = function(_, p326, p327) -- name: marker
			-- upvalues: (ref) v_u_4
			return v_u_4.marker(p326, p327)
		end,
		["setCFrame"] = function(_, p328) -- name: setCFrame
			-- upvalues: (ref) v_u_265
			v_u_265 = p328
		end,
		["getCFrame"] = function(_) -- name: getCFrame
			-- upvalues: (ref) v_u_265
			return v_u_265
		end,
		["point"] = function(_, p329) -- name: point
			-- upvalues: (copy) v_u_262, (ref) v_u_265
			return v_u_262.point(p329, v_u_265)
		end,
		["current"] = function(_) -- name: current
			-- upvalues: (ref) v_u_266
			return v_u_266.name
		end,
		["destroy"] = function(_) -- name: destroy
			-- upvalues: (copy) v_u_310, (copy) v_u_263
			v_u_310:Disconnect()
			v_u_263:Destroy()
		end
	}
	v_u_306(0)
	return v_u_282
end
return v_u_4