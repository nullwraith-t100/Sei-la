local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.Parent.EpicKit8)
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v4 = require(script.Parent.Parent.Preload)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v1.Shared.Config.Textures)
v4.images({
	v_u_6.DreamEye,
	v_u_6.DreamStar,
	v_u_6.DreamZ,
	v_u_6.FxSmoke,
	v_u_6.Glow
})
local v_u_7 = Color3.fromRGB(196, 170, 255)
local v_u_8 = Color3.fromRGB(150, 120, 230)
local v_u_9 = Color3.fromRGB(40, 16, 96)
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Enum.Material.Neon
local v_u_12 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_13 = CFrame.Angles(0, 0, -1.5707963267948966)
local function v_u_18(p14, p15, p16) -- name: floorEmitter
	local v17 = Instance.new("ParticleEmitter")
	v17.Texture = p14
	v17.Color = ColorSequence.new(p15)
	v17.LightEmission = p16
	v17.LightInfluence = 0
	v17.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v17.EmissionDirection = Enum.NormalId.Top
	v17.SpreadAngle = Vector2.zero
	v17.Speed = NumberRange.new(0.01)
	v17.Rate = 0
	v17.Enabled = false
	v17.LockedToPart = true
	return v17
end
return function(p_u_19)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_11, (copy) v_u_13, (copy) v_u_7, (copy) v_u_10, (copy) v_u_6, (copy) v_u_9, (copy) v_u_12, (copy) v_u_8, (copy) v_u_18
	return {
		["w8_lower_moon"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) p_u_19, (ref) v_u_2, (ref) v_u_11, (ref) v_u_13, (ref) v_u_7, (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (ref) v_u_12, (ref) v_u_8, (ref) v_u_18
			local v22 = v_u_3.color(p21.color)
			local v23 = p_u_20.headY / 1.5
			local v_u_24 = math.clamp(v23, 0.7, 3)
			local v25 = p_u_20.fx
			local v26 = math.min(v25, 1.6)
			local v27 = v_u_5.formRate()
			local v_u_28 = p_u_19.throb(p_u_20, 5.5, 2, 1)
			local v_u_29 = 0
			local v_u_30 = 0
			local v31 = p_u_20.ticks
			local function v35(_, _, p32)
				-- upvalues: (copy) v_u_28, (ref) v_u_30, (ref) v_u_29
				local v33 = v_u_28()
				v_u_30 = v_u_30 + p32 * 2 * (1 - v33)
				local v34 = v_u_30
				v_u_29 = math.sin(v34) * 0.32 * (1 - v33)
			end
			table.insert(v31, v35)
			local v42 = p_u_19.group(p_u_20, function(p36, p37)
				-- upvalues: (copy) v_u_24, (copy) p_u_20, (ref) v_u_29
				local v38 = CFrame.new
				local v39 = v_u_24 * -1.399999976158142
				local v40 = p_u_20.headY + v_u_24 * 0.949999988079071
				local v41 = p37 * 1.2
				return p36 * v38(v39, v40 + math.sin(v41) * 0.12 * v_u_24, v_u_24 * 0.550000011920929) * CFrame.Angles(0, 0, v_u_29)
			end)
			local v43 = v_u_24 * 2.5
			local v44 = v_u_2.piece("w8_lower_moon", v43)
			local v_u_45 = nil
			if v44 then
				v_u_45 = v44:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_45 then
					v44.Color = v22
					v44.Material = v_u_11
				end
				p_u_19.pin(p_u_20, v42, v44, v_u_13 * v_u_2.thinZ(v44))
			else
				v44 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v22, {
					["transparency"] = 1
				})
				p_u_19.pin(p_u_20, v42, v44, CFrame.identity)
				local v46 = v43 * 0.42
				local v47 = v46 * 4.363323129985824 / 9 * 1.18
				for v48 = 1, 9 do
					local v49 = (v48 - 0.5) / 9
					local v50 = v49 * 4.363323129985824 + 0.9599310885968813
					local v51 = 3.141592653589793 * v49
					local v52 = (math.sin(v51) * 0.34 + 0.1) * v_u_24
					local v53 = p_u_19.bar
					local v54 = v_u_24 * 0.2
					local v55 = Vector3.new(v47, v52, v54)
					local v56
					if v48 % 2 == 0 then
						v56 = v_u_7
					else
						v56 = v_u_10
					end
					local v57 = v53(v55, v56)
					p_u_19.pin(p_u_20, v42, v57, CFrame.Angles(0, 0, v50) * CFrame.new(v46 - v52 / 2, 0, 0) * CFrame.Angles(0, 0, 1.5707963267948966))
				end
			end
			p_u_19.own(p_u_20, v44)
			local v58 = Instance.new("Attachment")
			v58.Parent = v44
			local v_u_59 = Instance.new("ParticleEmitter")
			v_u_59.Texture = v_u_6.Glow
			v_u_59.Color = ColorSequence.new(v22)
			v_u_59.LightEmission = 0.6
			v_u_59.LightInfluence = 0
			v_u_59.LockedToPart = true
			v_u_59.Lifetime = NumberRange.new(0.6)
			v_u_59.Speed = NumberRange.new(0)
			v_u_59.Size = NumberSequence.new(v43 * 0.55 * v26)
			v_u_59.ZOffset = -1
			v_u_59.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.3, 0.55 },
				{ 0.7, 0.55 },
				{ 1, 1 }
			})
			v_u_59:SetAttribute("BaseRate", 5)
			v_u_59.Rate = 5 * v27
			v_u_59.Parent = v58
			local v60 = Instance.new("ParticleEmitter")
			v60.Texture = v_u_6.DreamZ
			v60.Color = ColorSequence.new(v_u_7)
			v60.LightEmission = 0.2
			v60.LightInfluence = 0
			v60.Lifetime = NumberRange.new(1.8, 2.4)
			v60.Size = v_u_2.seq({
				{ 0, 0.15 },
				{ 0.3, 0.32 },
				{ 1, 0.45 }
			}, v_u_24 * v26)
			v60.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.2, 0.05 },
				{ 0.75, 0.2 },
				{ 1, 1 }
			})
			v60.Speed = NumberRange.new(v_u_24 * 0.9, v_u_24 * 1.3)
			v60.EmissionDirection = Enum.NormalId.Top
			v60.SpreadAngle = Vector2.new(20, 20)
			local v61 = v_u_24 * 0.3
			v60.Acceleration = Vector3.new(v61, 0, 0)
			v60.Rotation = NumberRange.new(-20, 20)
			v60.RotSpeed = NumberRange.new(-15, 15)
			v60:SetAttribute("BaseRate", 0.7)
			v60.Rate = 0.7 * v27
			v60.Parent = v58
			local v62 = v_u_3.part
			local v63 = v_u_24 * 2.6
			local v64 = v_u_24 * 2.6
			local v65 = v62(Vector3.new(v63, 0.2, v64), CFrame.identity, v_u_9, {
				["transparency"] = 1
			})
			v65.Massless = true
			p_u_19.add(p_u_20, v65, function(p66)
				-- upvalues: (ref) p_u_19, (copy) p_u_20
				return CFrame.new(p_u_19.feetAt(p_u_20, p66, 0.12))
			end)
			p_u_19.own(p_u_20, v65)
			local v67 = Instance.new("ParticleEmitter")
			v67.Texture = v_u_6.FxSmoke
			v67.FlipbookLayout = v_u_12
			v67.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v67.Color = ColorSequence.new(v_u_8, v_u_7)
			v67.LightEmission = 0.15
			v67.LightInfluence = 0
			v67.Lifetime = NumberRange.new(1.6, 2.2)
			v67.Size = v_u_2.seq({
				{ 0, 1.4 },
				{ 1, 2.8 }
			}, v_u_24 * p_u_20.fx)
			v67.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.2, 0.45 },
				{ 0.7, 0.6 },
				{ 1, 1 }
			})
			v67.Speed = NumberRange.new(v_u_24 * 0.3, v_u_24 * 0.9)
			v67.SpreadAngle = Vector2.new(80, 80)
			v67.EmissionDirection = Enum.NormalId.Top
			v67.Rotation = NumberRange.new(0, 360)
			v67.RotSpeed = NumberRange.new(-25, 25)
			v67.Shape = Enum.ParticleEmitterShape.Box
			v67.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v67:SetAttribute("BaseRate", 6)
			v67.Rate = 6 * v27
			v67.Parent = v65
			local v68 = Instance.new("ParticleEmitter")
			v68.Texture = v_u_6.DreamStar
			v68.Color = ColorSequence.new(v_u_10, v_u_7)
			v68.LightEmission = 0.6
			v68.LightInfluence = 0
			v68.Lifetime = NumberRange.new(1.2, 1.8)
			v68.Size = v_u_2.seq({
				{ 0, 0.25 },
				{ 0.5, 0.45 },
				{ 1, 0.15 }
			}, v_u_24 * v26)
			v68.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.15, 0 },
				{ 0.35, 0.7 },
				{ 0.55, 0 },
				{ 0.8, 0.6 },
				{ 1, 1 }
			})
			v68.Speed = NumberRange.new(v_u_24 * 1.2, v_u_24 * 2.4)
			v68.SpreadAngle = Vector2.new(25, 25)
			v68.EmissionDirection = Enum.NormalId.Top
			v68.Drag = 0.6
			v68.Shape = Enum.ParticleEmitterShape.Box
			v68.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v68:SetAttribute("BaseRate", 5)
			v68.Rate = 5 * v27
			v68.Parent = v65
			local v_u_69 = Instance.new("ParticleEmitter")
			v_u_69.Texture = v_u_6.DreamStar
			v_u_69.Color = ColorSequence.new(v_u_10, v22)
			v_u_69.LightEmission = 0.7
			v_u_69.LightInfluence = 0
			v_u_69.Lifetime = NumberRange.new(0.6, 0.9)
			v_u_69.Size = v_u_2.seq({
				{ 0, 0.7 },
				{ 1, 0.2 }
			}, v_u_24 * v26)
			v_u_69.Speed = NumberRange.new(v_u_24 * 5, v_u_24 * 8)
			v_u_69.SpreadAngle = Vector2.new(88, 88)
			v_u_69.EmissionDirection = Enum.NormalId.Top
			v_u_69.Drag = 3
			v_u_69.Rate = 0
			v_u_69.Enabled = false
			v_u_69.Parent = v65
			local v_u_70 = {}
			for v71 = 1, 6 do
				local v72 = v71 * 3.141592653589793 * 2 / 6
				local v73 = Instance.new("Attachment")
				local v74 = math.cos(v72)
				local v75 = math.sin(v72)
				v73.Position = Vector3.new(v74, 0, v75) * 2.4 * v_u_24
				v73.Parent = v65
				local v76 = v_u_18(v_u_6.DreamEye, v_u_10, 0.1)
				v76.FlipbookLayout = v_u_12
				v76.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v76.Lifetime = NumberRange.new(1.5)
				v76.Size = NumberSequence.new(v_u_24 * 0.8 * v26)
				v76.Transparency = v_u_2.seq({
					{ 0, 1 },
					{ 0.1, 0 },
					{ 0.85, 0 },
					{ 1, 1 }
				})
				local v77 = -math.deg(v72) + 90
				v76.Rotation = NumberRange.new(v77, v77)
				v76.Parent = v73
				table.insert(v_u_70, v76)
			end
			local v_u_78 = not v_u_45 and 0 or v_u_45.EmissiveStrength
			local v_u_79 = -1
			local v80 = p_u_20.ticks
			local function v85(p81)
				-- upvalues: (copy) v_u_28, (ref) v_u_79, (copy) v_u_59, (ref) p_u_19, (copy) v_u_70, (copy) v_u_69, (ref) v_u_5, (copy) v_u_45, (copy) v_u_78
				local v82 = v_u_28() * 20
				local v83 = math.floor(v82) / 20
				if v83 ~= v_u_79 then
					if v83 > 0.95 and v_u_79 <= 0.95 then
						v_u_59:Emit(3)
						if (p81.Position - p_u_19.camPos()).Magnitude < 150 then
							for _, v84 in v_u_70 do
								v84:Emit(1)
							end
							v_u_69:Emit(v_u_5.level() >= 2 and 14 or 6)
						end
					end
					v_u_79 = v83
					if v_u_45 then
						v_u_45.EmissiveStrength = v_u_78 * (v83 * 2 + 1)
					end
				end
			end
			table.insert(v80, v85)
		end
	}
end