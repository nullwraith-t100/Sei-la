local v1 = {
	["leaf_genin"] = {
		["shirt"] = 6013782035,
		["pants"] = 6556271821,
		["accessories"] = nil,
		["face"] = 86487700,
		["skin"] = "#F2C29A",
		["accessories"] = { 14201012586, 13344398396 }
	},
	["leaf_scout"] = {
		["shirt"] = 15948938198,
		["pants"] = 4622859381,
		["accessories"] = nil,
		["skin"] = "#F2C29A",
		["accessories"] = { 80077279544950, 13894601332, 114644244008902 }
	},
	["bamboo_bandit"] = {
		["shirt"] = 806950881,
		["pants"] = 14149434497,
		["accessories"] = nil,
		["skin"] = "#D9A27A",
		["accessories"] = { 103257591045718, 14692106384, 114850499138753 }
	},
	["panda_brawler"] = {
		["shirt"] = 8499642486,
		["pants"] = 15191317165,
		["accessories"] = nil,
		["skin"] = "#F4F4F0",
		["accessories"] = { 18777820826, 111889027091417 }
	},
	["blossom_ronin"] = {
		["shirt"] = 10299825884,
		["pants"] = 14542710523,
		["accessories"] = nil,
		["face"] = 86487700,
		["skin"] = "#F2C29A",
		["accessories"] = { 90492309622320, 100719596702880, 98880680646555 }
	},
	["sakura_spirit"] = {
		["shirt"] = 6503953734,
		["pants"] = 9155040253,
		["accessories"] = nil,
		["skin"] = "#FFF0F5",
		["accessories"] = { 15861044059, 119222631375125, 17442475676 }
	},
	["sakura_kitsune"] = {
		["shirt"] = 244638083,
		["pants"] = 7708787926,
		["accessories"] = nil,
		["skin"] = "#FBF6F2",
		["accessories"] = {
			121349224880391,
			121338655693457,
			111141954116264,
			83210859249312
		}
	},
	["sand_golem"] = {
		["shirt"] = 15657862243,
		["pants"] = 15657919718,
		["accessories"] = nil,
		["skin"] = "#D8B47A",
		["accessories"] = { 18892541877, 18868261766, 14943813698 }
	},
	["dune_mummy"] = {
		["shirt"] = 107391694010774,
		["pants"] = 14780961962,
		["accessories"] = nil,
		["skin"] = "#E6D9BC",
		["accessories"] = { 13172068583, 16409279375, 14943800767 }
	},
	["canyon_bandit"] = {
		["shirt"] = 12231843054,
		["pants"] = 5346881935,
		["accessories"] = nil,
		["skin"] = "#C98B5E",
		["accessories"] = { 14692106384, 18213003897, 112875695558959 }
	},
	["canyon_scorpion"] = {
		["shirt"] = 2161855154,
		["pants"] = 72431467155378,
		["accessories"] = nil,
		["skin"] = "#C2452C",
		["accessories"] = { 9785355623, 99187730210875, 14943813698 }
	},
	["jackal_warrior"] = {
		["shirt"] = 9516370888,
		["pants"] = 15529302397,
		["accessories"] = nil,
		["skin"] = "#2A2622",
		["accessories"] = { 118597995674444, 85353804987107, 73573259464861 }
	},
	["palace_guard"] = {
		["shirt"] = 140298262257458,
		["pants"] = 9863588859,
		["accessories"] = nil,
		["face"] = 86487700,
		["skin"] = "#C98B5E",
		["accessories"] = { 12527377902, 77125809552212, 79665910196457 }
	},
	["sand_pharaoh"] = {
		["shirt"] = 13938222534,
		["pants"] = 84274478851488,
		["accessories"] = nil,
		["skin"] = "#E8C34A",
		["accessories"] = {
			93374100335667,
			113934870760473,
			106872121969601,
			16409279375
		}
	},
	["snow_ninja"] = {
		["shirt"] = 9810777237,
		["pants"] = 14404024454,
		["accessories"] = nil,
		["skin"] = "#F4D2B4",
		["accessories"] = { 8154000400, 13892211293, 85106924865712 }
	},
	["frost_wolf"] = {
		["shirt"] = 126558358086537,
		["pants"] = 137605901204440,
		["accessories"] = nil,
		["skin"] = "#E4EEF7",
		["accessories"] = { 77446920114654, 120246450440705, 135310135363043 }
	},
	["ice_wraith"] = {
		["shirt"] = 6089924971,
		["pants"] = 708220158,
		["accessories"] = nil,
		["skin"] = "#1A2A3A",
		["accessories"] = { 91513557647215, 98362181805476, 14943800767 }
	},
	["yeti"] = {
		["shirt"] = 3658285838,
		["pants"] = 3658286646,
		["accessories"] = nil,
		["skin"] = "#7FA6C8",
		["accessories"] = { 79990906029979, 97480144905449, 14943800767 }
	},
	["frost_knight"] = {
		["shirt"] = 131041476181880,
		["pants"] = 113056249233922,
		["accessories"] = nil,
		["skin"] = "#9FB6CF",
		["accessories"] = { 137862034108203, 106138780405080, 127919163182231 }
	},
	["frost_monk"] = {
		["shirt"] = 138207228002735,
		["pants"] = 128261773,
		["accessories"] = nil,
		["face"] = 86487700,
		["skin"] = "#F4D2B4",
		["accessories"] = { 16897571949, 98573464220041 }
	},
	["glacier_king"] = {
		["shirt"] = 9168943891,
		["pants"] = 14876148908,
		["accessories"] = nil,
		["face"] = 86487700,
		["skin"] = "#BFDDF0",
		["accessories"] = {
			85285804580530,
			109074586153756,
			18321442151,
			103970674901498
		}
	},
	["magma_golem"] = {
		["shirt"] = 13510751581,
		["pants"] = 104687930048209,
		["accessories"] = nil,
		["skin"] = "#2E2220",
		["accessories"] = { 122953842123093, 98439210074498, 133508054009094 }
	},
	["fire_oni"] = {
		["shirt"] = 87371824280690,
		["pants"] = 6493386536,
		["accessories"] = nil,
		["skin"] = "#D8382A",
		["accessories"] = { 16393070138, 10148103793, 111889027091417 }
	},
	["swamp_lurker"] = {
		["shirt"] = 8150162673,
		["pants"] = 8999384040,
		["accessories"] = nil,
		["skin"] = "#4E8A3A",
		["accessories"] = { 127380723361264, 131528280128707, 97362739724717 }
	},
	["bog_beast"] = {
		["shirt"] = 5551720953,
		["pants"] = 14547881044,
		["accessories"] = nil,
		["skin"] = "#3E5A2A",
		["accessories"] = { 6773678618, 115729363207047, 7542887803 }
	},
	["shadow_ninja"] = {
		["shirt"] = 15169761084,
		["pants"] = 15191317165,
		["accessories"] = nil,
		["skin"] = "#2A2238",
		["accessories"] = { 17493008845, 14420152234, 104515455478937 }
	},
	["shade_stalker"] = {
		["shirt"] = 133190976618378,
		["pants"] = 12470608847,
		["accessories"] = nil,
		["skin"] = "#0E0A14",
		["accessories"] = { 131154761236120, 84908796251361, 78727467248186 }
	},
	["shadow_reaper"] = {
		["shirt"] = 17460627255,
		["pants"] = 73339977817141,
		["accessories"] = nil,
		["skin"] = "#EDE6D6",
		["accessories"] = {
			11103896868,
			89776174194307,
			102653314436247,
			96075154805983
		}
	},
	["crystal_crawler"] = {
		["shirt"] = 101489721912581,
		["pants"] = 121783197179774,
		["accessories"] = nil,
		["skin"] = "#2E2848",
		["accessories"] = { 116972737435396, 17363460902, 76163725225067 }
	},
	["crystal_golem"] = {
		["shirt"] = 115060195424488,
		["pants"] = 17294287294,
		["accessories"] = nil,
		["skin"] = "#463E70",
		["accessories"] = { 17399481079, 85618638912227, 71535703398170 }
	},
	["storm_spirit"] = {
		["shirt"] = 9667426365,
		["pants"] = 93466544805758,
		["accessories"] = nil,
		["skin"] = "#F4F8FF",
		["accessories"] = { 129270545218801, 111834092978772 }
	},
	["sky_tengu"] = {
		["shirt"] = 13673067593,
		["pants"] = 15731867517,
		["accessories"] = nil,
		["skin"] = "#D8382A",
		["accessories"] = { 14927253943, 121049287555407, 13237535137 }
	},
	["crimson_samurai"] = {
		["shirt"] = 12124747023,
		["pants"] = 12124768105,
		["accessories"] = nil,
		["skin"] = "#F2C29A",
		["accessories"] = { 85210613566473, 78267893394166, 14312089228 }
	},
	["oni_assassin"] = {
		["shirt"] = 12984868345,
		["pants"] = 1056229043,
		["accessories"] = nil,
		["skin"] = "#F2C29A",
		["accessories"] = { 84359238282312, 116112317761072, 14603284727 }
	},
	["crimson_shogun"] = {
		["shirt"] = 15528575924,
		["pants"] = 9260535199,
		["accessories"] = nil,
		["skin"] = "#F2C29A",
		["accessories"] = {
			9120712314,
			8117694609,
			15991359928,
			15991330676
		}
	}
}
return v1