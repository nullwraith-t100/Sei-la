local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = Color3.fromHex("F2EBD9")
local v_u_7 = Color3.fromHex("FF2E3A")
local v_u_8 = Color3.fromRGB(150, 0, 18)
local v_u_9 = Color3.fromRGB(10, 4, 6)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.Material.Neon
local v_u_12 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_23(p13, p14) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v15 = v_u_2:FindFirstChild("EyePieces")
	if v15 then
		v15 = v15:FindFirstChild(p13)
	end
	if not (v15 and v15:IsA("MeshPart")) then
		return nil
	end
	local v16 = v15:Clone()
	local v17 = v15.Size
	local v18 = v15.Size.X
	local v19 = v15.Size.Y
	local v20 = v15.Size.Z
	v16.Size = v17 * (p14 / math.max(v18, v19, v20, 0.01))
	v16.Anchored = true
	v16.CanCollide = false
	v16.CanQuery = false
	v16.CanTouch = false
	v16.Massless = true
	v16.CastShadow = false
	local v21 = v16:FindFirstChildOfClass("SurfaceAppearance")
	if v21 then
		local v22 = v21.EmissiveStrength
		v21.EmissiveStrength = math.max(v22, 4)
	end
	v16.Parent = v_u_3.folder()
	return v16
end
local function v_u_28(p24, p25, p26) -- name: crackle
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4
	local v27 = Instance.new("ParticleEmitter")
	v27.Texture = v_u_5.VastoBolt
	v27.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
	v27.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v27.Color = ColorSequence.new(v_u_7, v_u_8)
	v27.LightEmission = 0.5
	v27.LightInfluence = 0
	v27.Size = NumberSequence.new(p25 * 0.7, p25)
	v27.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v27.Lifetime = NumberRange.new(0.18, 0.28)
	v27.Speed = NumberRange.new(0)
	v27.Rotation = NumberRange.new(0, 360)
	v27.ZOffset = 0.5
	v27:SetAttribute("BaseRate", p26)
	v27.Rate = p26 * v_u_4.formRate()
	v27.Parent = p24
	return v27
end
return function(p_u_29)
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_23, (copy) v_u_12, (copy) v_u_6, (copy) v_u_10, (copy) v_u_11, (copy) v_u_28
	return {
		["w7_vasto_lorde"] = function(p_u_30, _)
			-- upvalues: (ref) v_u_1, (copy) p_u_29, (ref) v_u_3, (ref) v_u_7, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_4, (ref) v_u_23, (ref) v_u_12, (ref) v_u_6, (ref) v_u_10, (ref) v_u_11, (ref) v_u_28
			local v31 = p_u_30.headY / 1.5
			local v_u_32 = math.clamp(v31, 0.7, 3)
			local v_u_33 = p_u_30.fx
			local v34 = p_u_30.character == v_u_1.LocalPlayer.Character
			local v35 = p_u_30.character:FindFirstChild("Head")
			if not (v35 and v35:IsA("BasePart")) then
				v35 = nil
			end
			local v_u_36
			if v35 then
				v_u_36 = v35.Size.Y
			else
				v_u_36 = v_u_32 * 1.2
			end
			local v_u_37 = p_u_29.crownOf(p_u_30)
			p_u_30.eyeLift = 3.1
			local function v_u_38()
				-- upvalues: (copy) p_u_30, (copy) v_u_32
				return p_u_30.root.Position + Vector3.new(0, 1, 0) * (p_u_30.headY + v_u_32 * 1.2)
			end
			local v_u_39 = nil
			p_u_29.throb(p_u_30, 5, 2.5, 1.4, function(p40)
				-- upvalues: (ref) p_u_29, (copy) p_u_30, (ref) v_u_38, (ref) v_u_3, (ref) v_u_7, (copy) v_u_32, (copy) v_u_33, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5, (ref) v_u_39, (ref) v_u_4
				local v41 = p_u_29.feetAt(p_u_30, p40, 0.1)
				local v42 = v_u_38()
				v_u_3.flash(v42, v_u_7, v_u_32 * 4.5 * v_u_33, 0.22)
				v_u_3.flash(v42, v_u_9, v_u_32 * 2.2 * v_u_33, 0.3)
				v_u_3.ring(v41, v_u_8, 9 * v_u_33, 0.6, v_u_5.VastoMark)
				v_u_3.ring(v41 + Vector3.new(0, 0.05, 0), v_u_9, 6 * v_u_33, 0.45, v_u_5.Ring)
				local v43 = v_u_39
				if v43 then
					v43:Emit(v_u_4.level() <= 1 and 2 or 6)
				end
			end)
			local v_u_49 = p_u_29.group(p_u_30, function(p44, p45)
				-- upvalues: (copy) v_u_37, (copy) v_u_36
				local v46 = v_u_37(p44) * CFrame.new(0, 1 * v_u_36, 0.2 * v_u_36)
				local v47 = CFrame.Angles
				local v48 = p45 * 1.1
				return v46 * v47(math.sin(v48) * 0.04 + 0.6108652381980153, 0, 0)
			end)
			local v_u_50 = CFrame.new(0, 0.55 * v_u_36, -0.95 * v_u_36)
			v_u_38 = function()
				-- upvalues: (copy) v_u_49, (copy) v_u_50
				return (v_u_49.cf * v_u_50).Position
			end
			local v51 = v_u_23("w7_vasto_lorde", 3 * v_u_36)
			local v_u_52
			if v51 then
				p_u_29.pin(p_u_30, v_u_49, v51, v_u_12)
				v_u_52 = v_u_38
			else
				local v53 = p_u_29.pin
				local v54 = p_u_29.blob
				local v55 = 1.05 * v_u_36
				local v56 = 1.2 * v_u_36
				local v57 = 0.5 * v_u_36
				v53(p_u_30, v_u_49, v54(Vector3.new(v55, v56, v57), v_u_6, 0, v_u_10), CFrame.new(0, 0, -0.1 * v_u_36))
				v_u_52 = v_u_38
				for _, v58 in { -1, 1 } do
					local v59 = p_u_29.pin
					local v60 = p_u_29.bar
					local v61 = 0.26 * v_u_36
					local v62 = 0.07 * v_u_36
					local v63 = 0.06 * v_u_36
					v59(p_u_30, v_u_49, v60(Vector3.new(v61, v62, v63), v_u_9, 0, v_u_10), CFrame.new(v58 * 0.22 * v_u_36, 0.1 * v_u_36, -0.35 * v_u_36) * CFrame.Angles(0, 0, v58 * 0.25))
					local v64 = p_u_29.pin
					local v65 = p_u_29.bar
					local v66 = 0.05 * v_u_36
					local v67 = 0.42 * v_u_36
					local v68 = 0.04 * v_u_36
					v64(p_u_30, v_u_49, v65(Vector3.new(v66, v67, v68), v_u_8, 0, v_u_11), CFrame.new(v58 * 0.24 * v_u_36, -0.22 * v_u_36, -0.34 * v_u_36))
					local v69 = CFrame.new(v58 * 0.42 * v_u_36, 0.38 * v_u_36, 0) * CFrame.Angles(0, 0, -v58 * 0.5)
					for v70 = 1, 3 do
						local v71 = (0.42 - v70 * 0.06) * v_u_36
						local v72 = (0.22 - v70 * 0.05) * v_u_36
						local v73 = p_u_29.pin
						local v74 = p_u_29.blob
						local v75 = Vector3.new(v72, v71, v72)
						local v76
						if v70 == 2 then
							v76 = v_u_8
						else
							v76 = v_u_6
						end
						local v77 = 0
						local v78
						if v70 == 2 then
							v78 = v_u_11
						else
							v78 = v_u_10
						end
						v73(p_u_30, v_u_49, v74(v75, v76, v77, v78), v69 * CFrame.new(0, v71 / 2, 0))
						v69 = v69 * CFrame.new(0, v71 * 0.9, 0) * CFrame.Angles(0.35, 0, v58 * 0.32)
					end
				end
			end
			local v_u_79 = p_u_29.ball(1, v_u_7, 0.25, v_u_11)
			local v_u_80 = p_u_29.ball(1, v_u_9, 0, v_u_10)
			for _, v81 in { v_u_79, v_u_80 } do
				p_u_29.add(p_u_30, v81, function(_, p82)
					-- upvalues: (ref) v_u_52
					local v83 = v_u_52()
					local v84
					if p82 < 2.5 then
						v84 = 2.5 - p82
					else
						v84 = 5 - (p82 - 2.5) % 5
					end
					local v85 = 1 - v84 / 1.1
					local v86 = math.clamp(v85, 0, 1)
					if v86 * v86 * (3 - v86 * 2) <= 0.01 then
						return CFrame.new(v83 - Vector3.new(0, 6, 0))
					else
						return CFrame.new(v83) * CFrame.Angles(p82 * 3, p82 * 2, 0)
					end
				end)
			end
			local v_u_87 = -1
			local v88 = p_u_30.ticks
			local function v96(_, p89)
				-- upvalues: (ref) v_u_87, (copy) v_u_32, (copy) v_u_33, (copy) v_u_79, (copy) v_u_80
				local v90
				if p89 < 2.5 then
					v90 = 2.5 - p89
				else
					v90 = 5 - (p89 - 2.5) % 5
				end
				local v91 = 1 - v90 / 1.1
				local v92 = math.clamp(v91, 0, 1)
				local v93 = v92 * v92 * (3 - v92 * 2) * 24
				local v94 = math.floor(v93) / 24
				if v94 ~= v_u_87 then
					v_u_87 = v94
					local v95 = math.max(v94, 0.02) * 0.8 * v_u_32 * v_u_33
					v_u_79.Size = Vector3.new(1, 1, 1) * v95
					v_u_80.Size = Vector3.new(1, 1, 1) * v95 * 0.6
					v_u_79.Transparency = (1 - v94) * 0.5 + 0.15
				end
			end
			table.insert(v88, v96)
			local v_u_97 = Instance.new("Attachment")
			v_u_97.Parent = p_u_30.root
			p_u_29.own(p_u_30, v_u_97)
			local v_u_98 = v_u_28(v_u_97, v_u_32 * 1.6 * v_u_33, 0)
			v_u_98.Shape = Enum.ParticleEmitterShape.Sphere
			v_u_98.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			local v99 = p_u_30.ticks
			local function v108(p100, p101)
				-- upvalues: (copy) v_u_97, (ref) v_u_52, (ref) p_u_29, (ref) v_u_4, (copy) v_u_98
				local v102
				if p101 < 2.5 then
					v102 = 2.5 - p101
				else
					v102 = 5 - (p101 - 2.5) % 5
				end
				local v103 = 1 - v102 / 1.1
				local v104 = math.clamp(v103, 0, 1)
				local v105 = v104 * v104 * (3 - v104 * 2)
				v_u_97.WorldPosition = v_u_52()
				local v106 = (v105 <= 0.05 or (p100.Position - p_u_29.camPos()).Magnitude >= 90) and 0 or (v105 * 18 + 4) * v_u_4.formRate()
				local v107 = v_u_98.Rate - v106
				if math.abs(v107) > 0.5 then
					v_u_98.Rate = v106
				end
			end
			table.insert(v99, v108)
			local v109 = p_u_30.stops
			table.insert(v109, function()
				-- upvalues: (copy) v_u_98, (copy) v_u_97
				v_u_98.Enabled = false
				v_u_97:Destroy()
			end)
			local v_u_110 = 0
			local v111 = p_u_30.ticks
			local function v113(_, _, p112)
				-- upvalues: (ref) v_u_110
				v_u_110 = v_u_110 + p112
			end
			table.insert(v111, v113)
			local v_u_114 = v_u_110
			for v_u_115 = 1, 8 do
				local v116 = (v_u_115 - 0.5) / 8 * 3.141592653589793 * 2
				local v117 = -math.sin(v116)
				local v_u_118 = (1.1 - math.max(v117, 0) * 0.45) * v_u_32
				local v119
				if v_u_115 % 2 == 0 then
					v119 = v_u_6
				else
					v119 = Color3.fromRGB(226, 218, 204)
				end
				local v120 = v_u_10
				local v121 = v_u_32 * 0.16
				local v122 = v_u_32 * 0.5
				local v123 = Vector3.new(v121, v_u_118, v122)
				local v124 = Instance.new("WedgePart")
				v124.Anchored = true
				v124.CanCollide = false
				v124.CanQuery = false
				v124.CanTouch = false
				v124.CastShadow = false
				v124.Massless = true
				v124.Color = v119
				v124.Material = v120
				v124.Size = v123
				v124.Parent = v_u_3.folder()
				local v125 = math.cos(v116)
				local v126 = math.sin(v116)
				local v_u_127 = Vector3.new(v125, 0, v126)
				p_u_29.add(p_u_30, v124, function(p128, p129)
					-- upvalues: (copy) v_u_127, (copy) v_u_32, (copy) p_u_30, (copy) v_u_36, (copy) v_u_118, (copy) v_u_115
					local v130 = v_u_127.X * 1.05 * v_u_32
					local v131 = p_u_30.headY - 0.95 * v_u_36 + v_u_118 * 0.4
					local v132 = v_u_127.Z * 0.62 * v_u_32
					local v133 = p128 * Vector3.new(v130, v131, v132)
					local v134 = p128:VectorToWorldSpace(v_u_127)
					local v135 = p129 * 2.1 + v_u_115 * 1.7
					local v136 = math.sin(v135) * 0.06
					return CFrame.lookAt(v133, v133 + v134) * CFrame.Angles(v136 + -0.55, 0, 0)
				end)
			end
			local v137 = Instance.new("Part")
			local v138 = v_u_32 * 2.4
			local v139 = v_u_32 * 3.4
			local v140 = v_u_32 * 1.6
			v137.Size = Vector3.new(v138, v139, v140)
			v137.Transparency = 1
			v137.Anchored = true
			v137.CanCollide = false
			v137.CanQuery = false
			v137.CanTouch = false
			v137.CastShadow = false
			v137.Parent = v_u_3.folder()
			p_u_29.add(p_u_30, v137, function(p141)
				-- upvalues: (copy) v_u_32
				return p141 * CFrame.new(0, v_u_32 * 0.2, 0)
			end)
			local v_u_142 = v_u_28(v137, (v34 and 1.2 or 1.5) * v_u_32 * v_u_33, 1.3 * v_u_33)
			v_u_142.Shape = Enum.ParticleEmitterShape.Box
			v_u_142.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_39 = v_u_142
			p_u_29.own(p_u_30, v137)
			local v143 = p_u_30.stops
			table.insert(v143, function()
				-- upvalues: (copy) v_u_142
				v_u_142.Enabled = false
			end)
			local v144 = p_u_29.picture(v_u_32 * 6.2, v_u_5.Glow, v_u_9, 0.35)
			local v145 = p_u_29.picture(v_u_32 * 4.4, v_u_5.Glow, v_u_7, 0.55)
			local v_u_146 = p_u_29.picture(v_u_32 * 6.6, v_u_5.VastoMark, v_u_8, 0)
			p_u_29.add(p_u_30, v144, function(p147)
				-- upvalues: (ref) p_u_29, (copy) p_u_30
				return CFrame.new(p_u_29.feetAt(p_u_30, p147, 0.04))
			end)
			p_u_29.add(p_u_30, v145, function(p148)
				-- upvalues: (ref) p_u_29, (copy) p_u_30
				return CFrame.new(p_u_29.feetAt(p_u_30, p148, 0.06))
			end)
			p_u_29.add(p_u_30, v_u_146, function(p149)
				-- upvalues: (ref) p_u_29, (copy) p_u_30, (ref) v_u_114
				return CFrame.new(p_u_29.feetAt(p_u_30, p149, 0.09)) * CFrame.Angles(0, -v_u_114 * 0.25, 0)
			end)
			local v_u_150 = -1
			local v151 = p_u_30.ticks
			local function v157(_, p152)
				-- upvalues: (ref) v_u_150, (copy) v_u_32, (copy) v_u_146
				local v153 = 1 - (p152 < 2.5 and 9 or (p152 - 2.5) % 5) / 0.6
				local v154 = math.max(v153, 0) * 20
				local v155 = math.floor(v154) / 20
				if v155 ~= v_u_150 then
					v_u_150 = v155
					local v156 = v_u_32 * 6.6 * (v155 * 0.3 + 1)
					v_u_146.Size = Vector3.new(v156, 0.05, v156)
				end
			end
			table.insert(v151, v157)
			p_u_29.particles(p_u_30, "AuraMode", v_u_7, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end