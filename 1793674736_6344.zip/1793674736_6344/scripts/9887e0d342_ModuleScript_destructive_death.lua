local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.AkazaCompass, v_u_7.AkazaStar, v_u_7.AkazaCrack })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("46C8FF")
local v_u_10 = Color3.fromRGB(196, 242, 255)
local v_u_11 = Color3.fromHex("FF9A1F")
local v_u_12 = Color3.fromRGB(10, 34, 72)
local v_u_13 = Color3.fromRGB(150, 160, 172)
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = Enum.PartType.Wedge
local function v_u_50(p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v28 = p22 + p23 + p24
	local v29 = math.max(v28, 0.05)
	local v30 = {}
	local v31 = {}
	for v32 = 0, 10 do
		local v33 = v32 / 10
		local v34 = v33 * v29
		local v35 = v34 / math.max(p22, 0.001)
		local v36 = 1 - (1 - math.clamp(v35, 0, 1)) ^ 3
		local v37 = (v34 - p22 - p23) / math.max(p24, 0.001)
		local v38 = math.clamp(v37, 0, 1)
		local v39 = v38 * v38 * (3 - v38 * 2)
		local v40 = NumberSequenceKeypoint.new
		local v41 = p17 + (p18 - p17) * v36
		local v42 = math.max(v41, 0.05) / 2
		table.insert(v31, v40(v33, v42))
		local v43 = NumberSequenceKeypoint.new
		local v44 = p21 + (1 - p21) * v39
		local v45 = math.clamp(v44, 0, 1)
		table.insert(v30, v43(v33, v45))
	end
	local v46 = Instance.new("Attachment")
	v46.WorldCFrame = CFrame.new(p16)
	v46.Parent = v_u_3.Terrain
	local v47 = Instance.new("ParticleEmitter")
	v47.Enabled = false
	v47.Texture = p19
	v47.Color = ColorSequence.new(p20)
	v47.LightEmission = p26 or 0
	v47.LightInfluence = 0
	v47.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v47.EmissionDirection = Enum.NormalId.Top
	v47.SpreadAngle = Vector2.zero
	v47.Speed = NumberRange.new(0.01)
	v47.Size = NumberSequence.new(v31)
	v47.Transparency = NumberSequence.new(v30)
	v47.Lifetime = NumberRange.new(v29)
	local v48 = p25 or math.random(0, 359)
	v47.Rotation = NumberRange.new(v48, v48)
	local v49 = p27 or 0
	v47.RotSpeed = NumberRange.new(v49, v49)
	v47.Parent = v46
	v47:Emit(1)
	v_u_1:AddItem(v46, v29 + 0.2)
end
local function v_u_60(p51, p52, p53, p54, p55, p56, p57) -- name: spritePop
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v58 = Instance.new("Attachment")
	v58.WorldPosition = p51
	v58.Parent = v_u_3.Terrain
	local v59 = Instance.new("ParticleEmitter")
	v59.Enabled = false
	v59.Texture = p52
	v59.Color = ColorSequence.new(p53)
	v59.LightEmission = p57 or 0
	v59.LightInfluence = 0
	v59.Speed = NumberRange.new(0)
	v59.Lifetime = NumberRange.new(p56)
	v59.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p54 / 2), NumberSequenceKeypoint.new(0.25, (p54 + (p55 - p54) * 0.8) / 2), NumberSequenceKeypoint.new(1, p55 / 2) })
	v59.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v59.Rotation = NumberRange.new(0, 360)
	v59.RotSpeed = NumberRange.new(-90, 90)
	v59.Parent = v58
	v59:Emit(1)
	v_u_1:AddItem(v58, p56 + 0.2)
end
local function v_u_75(p61, p62, p63, p64, p65) -- name: shockLine
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v66 = p62 - p61
	if v66.Magnitude >= 0.5 then
		local v67 = v66.Magnitude * 0.45
		local v68 = math.min(v67, 9)
		local v69 = v_u_4.part(Vector3.new(p63, p63, v68), CFrame.lookAt(p61, p62), p64)
		local v70 = v_u_4.tween
		local v71 = {
			["CFrame"] = nil,
			["Size"] = nil,
			["Transparency"] = 0.8,
			["CFrame"] = CFrame.lookAt(p62 - v66.Unit * v68 * 0.5, p62 + v66.Unit)
		}
		local v72 = p63 * 0.3
		local v73 = p63 * 0.3
		local v74 = v68 * 0.6
		v71.Size = Vector3.new(v72, v73, v74)
		v70(v69, p65, v71, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		v_u_1:AddItem(v69, p65 + 0.02)
	end
end
return function(p_u_76)
	-- upvalues: (copy) v_u_60, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_11, (copy) v_u_12, (copy) v_u_9, (copy) v_u_50, (copy) v_u_1, (copy) v_u_10, (copy) v_u_15, (copy) v_u_14, (copy) v_u_75, (copy) v_u_6, (copy) v_u_13
	local v77 = {}
	local function v_u_83(p78, p79, p80, p81) -- name: blow
		-- upvalues: (ref) v_u_60, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (copy) p_u_76, (ref) v_u_12, (ref) v_u_9, (ref) v_u_50
		v_u_60(p78, v_u_7.AkazaStar, v_u_8, p79 * 1.2 * p80, p79 * 6.5 * p80, 0.3, 0.1)
		v_u_4.flash(p78, v_u_11, p79 * 2.6 * p80, 0.14)
		local v82 = p_u_76.ground(p78, 0.12)
		v_u_4.ring(v82, v_u_12, p79 * 2.6 * p80, 0.3, v_u_7.Ring)
		v_u_4.ring(v82 + Vector3.new(0, 0.05, 0), v_u_9, p79 * 3.8 * p80, 0.4, v_u_7.Ring)
		if not p81 then
			v_u_60(p78, v_u_7.AkazaCrack, v_u_9, p79 * 2 * p80, p79 * 7 * p80, 0.25, 0.3)
			v_u_50(v82, 1, p79 * 6 * p80, v_u_7.AkazaCrack, v_u_9, 0, 0.06, 0.35, 0.45, nil, 0.25)
		end
	end
	v77.destructive_death_a = {
		["cast"] = function(p84) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			v_u_4.flash(p84.eye + p84.dir, v_u_9, 2.4 * p84.size, 0.1)
		end,
		["shot"] = function(p85, p86) -- name: shot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_11, (ref) v_u_7, (ref) v_u_10, (ref) v_u_9
			local v87 = p85.size
			local v_u_88 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p86, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_88, 3)
			local v_u_89 = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * v87, p86, v_u_11, {
				["shape"] = Enum.PartType.Ball
			})
			v_u_1:AddItem(v_u_89, 3)
			local v90 = Instance.new("Attachment")
			v90.Parent = v_u_88
			local v_u_91 = Instance.new("ParticleEmitter")
			v_u_91.Enabled = false
			v_u_91.Texture = v_u_7.AkazaStar
			v_u_91.Color = ColorSequence.new(v_u_8)
			v_u_91.LightEmission = 0.1
			v_u_91.LightInfluence = 0
			v_u_91.LockedToPart = true
			v_u_91.Speed = NumberRange.new(0)
			v_u_91.Lifetime = NumberRange.new(2)
			v_u_91.Size = NumberSequence.new(1.35 * v87)
			v_u_91.Rotation = NumberRange.new(0, 360)
			v_u_91.RotSpeed = NumberRange.new(720, 720)
			v_u_91.Parent = v90
			v_u_91:Emit(1)
			local v92 = Instance.new("Attachment")
			local v93 = 0.5 * v87
			v92.Position = Vector3.new(0, v93, 0)
			v92.Parent = v_u_88
			local v94 = Instance.new("Attachment")
			local v95 = -0.5 * v87
			v94.Position = Vector3.new(0, v95, 0)
			v94.Parent = v_u_88
			local v96 = Instance.new("Trail")
			v96.Attachment0 = v92
			v96.Attachment1 = v94
			v96.Color = ColorSequence.new(v_u_10, v_u_9)
			v96.Transparency = NumberSequence.new(0.1, 1)
			v96.WidthScale = NumberSequence.new(1, 0.15)
			v96.Lifetime = p85.lite and 0.08 or 0.14
			v96.LightEmission = 0.4
			v96.LightInfluence = 0
			v96.FaceCamera = true
			v96.Parent = v_u_88
			local v_u_97 = false
			return {
				["place"] = function(p98, _) -- name: place
					-- upvalues: (copy) v_u_88, (copy) v_u_89
					v_u_88.CFrame = p98
					v_u_89.CFrame = p98
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_97, (copy) v_u_91, (copy) v_u_89, (ref) v_u_1, (copy) v_u_88
					if not v_u_97 then
						v_u_97 = true
						v_u_91:Clear()
						v_u_89:Destroy()
						v_u_1:AddItem(v_u_88, 0.25)
					end
				end
			}
		end,
		["impact"] = function(p99, p100) -- name: impact
			-- upvalues: (copy) v_u_83, (copy) p_u_76
			v_u_83(p100, p99.size, 0.75, p99.lite)
			p_u_76.hitSound(p100)
		end,
		["hit"] = function(_, p101, _) -- name: hit
			-- upvalues: (copy) p_u_76, (ref) v_u_9
			p_u_76.burst("Impact", p101, v_u_9, 0.6)
		end
	}
	v77.destructive_death_e = {
		["cast"] = function(p102) -- name: cast
			-- upvalues: (copy) p_u_76, (ref) v_u_9
			p_u_76.skillCast(p102, v_u_9)
		end,
		["windup"] = function(p103, _, p104) -- name: windup
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			v_u_4.flash(p103.eye, v_u_9, 5 * p103.size, (math.max(p104, 0.1)))
		end,
		["land"] = function(p_u_105, p106) -- name: land
			-- upvalues: (copy) p_u_76, (ref) v_u_50, (ref) v_u_7, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_11, (ref) v_u_15, (ref) v_u_14, (ref) v_u_1, (ref) v_u_75, (ref) v_u_10, (ref) v_u_6
			local v_u_107 = p_u_105.size
			local v_u_108 = p_u_105.ability.radius * v_u_107
			local v_u_109 = p_u_76.ground(p106, 0.12)
			local v110 = p_u_76.flatUnit(p_u_105.dir)
			local v111 = -v110.X
			local v112 = -v110.Z
			local v_u_113 = math.atan2(v111, v112)
			v_u_50(v_u_109, v_u_108 * 0.5, v_u_108 * 2.5, v_u_7.Glow, v_u_12, 0.35, 0.15, 0.9, 0.45, nil, 0)
			v_u_50(v_u_109 + Vector3.new(0, 0.04, 0), v_u_108 * 0.3, v_u_108 * 2.1, v_u_7.AkazaCompass, v_u_9, 0, 0.18, 0.15, 0.12, 0, 0.35, 420)
			p_u_76.after(0.3, function()
				-- upvalues: (ref) v_u_50, (copy) v_u_109, (copy) v_u_108, (ref) v_u_7, (ref) v_u_9, (copy) v_u_113
				local v114 = v_u_113
				v_u_50(v_u_109 + Vector3.new(0, 0.04, 0), v_u_108 * 2.1, v_u_108 * 2.15, v_u_7.AkazaCompass, v_u_9, 0, 0.02, 0.7, 0.45, math.deg(v114), 0.35)
			end)
			local v_u_115 = v_u_108 * 0.36
			local v_u_116 = 0.9 * v_u_107
			local v_u_117 = {}
			for _, v118 in { false, true } do
				for _, v119 in { 1, -1 } do
					local v120 = v_u_4.part
					local v121 = 0.35 * v_u_107
					local v122 = Vector3.new(v121, v_u_116, v_u_115)
					local v123 = CFrame.new(0, -500, 0)
					local v124
					if v118 then
						v124 = v_u_12
					else
						v124 = v_u_11
					end
					local v125 = {
						["shape"] = v_u_15
					}
					local v126
					if v118 then
						v126 = v_u_14
					else
						v126 = nil
					end
					v125.material = v126
					local v127 = v120(v122, v123, v124, v125)
					v_u_1:AddItem(v127, 1.6)
					table.insert(v_u_117, {
						["p"] = v127,
						["back"] = v118,
						["m"] = v119
					})
				end
			end
			local v_u_128 = os.clock()
			local v_u_129 = false
			p_u_76.frame(function()
				-- upvalues: (copy) v_u_128, (copy) v_u_109, (copy) v_u_113, (copy) v_u_117, (copy) v_u_115, (copy) v_u_116, (ref) v_u_129, (copy) p_u_105, (ref) v_u_75, (copy) v_u_108, (copy) v_u_107, (ref) v_u_10, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7, (ref) v_u_9, (ref) v_u_11, (ref) v_u_6
				local v130 = os.clock() - v_u_128
				local v131 = v130 / 0.5
				local v132 = (1 - (1 - math.clamp(v131, 0, 1)) ^ 3) * 3.141592653589793 * 6
				local v133 = (v130 - 1.05) / 0.4
				local v134 = math.clamp(v133, 0, 1)
				local v135 = v134 * v134 * (3 - v134 * 2)
				local v136 = CFrame.new(v_u_109 + Vector3.new(0, 0.25, 0)) * CFrame.Angles(0, v_u_113 + v132, 0)
				for _, v137 in v_u_117 do
					v137.p.CFrame = v136 * CFrame.Angles(0, v137.back and 3.141592653589793 or 0, 0) * CFrame.new(0, 0, -v_u_115 * 0.5) * CFrame.Angles(0, 0, v137.m * 3.141592653589793 / 2) * CFrame.new(0, v_u_116 / 2, 0)
					v137.p.Transparency = v135
				end
				if v130 >= 0.45 and not v_u_129 then
					v_u_129 = true
					for v138 = 1, p_u_105.lite and 6 or 12 do
						local v139 = v_u_113 + v138 / (p_u_105.lite and 6 or 12) * 3.141592653589793 * 2
						local v140 = -math.sin(v139)
						local v141 = -math.cos(v139)
						local v142 = Vector3.new(v140, 0, v141)
						v_u_75(v_u_109 + Vector3.new(0, 0.5, 0) + v142 * 2, v_u_109 + Vector3.new(0, 0.5, 0) + v142 * v_u_108 * 0.95, 0.45 * v_u_107, v_u_10, 0.16)
					end
					v_u_4.ring(v_u_109, v_u_12, v_u_108 * 0.85, 0.45, v_u_7.Shockwave)
					v_u_4.ring(v_u_109 + Vector3.new(0, 0.05, 0), v_u_9, v_u_108 * 1.1, 0.55, v_u_7.AkazaCompass)
					v_u_4.flash(v_u_109 + Vector3.new(0, 2, 0), v_u_11, 7 * v_u_107, 0.2)
					v_u_6.play("Explosion", {
						["at"] = v_u_109,
						["volume"] = p_u_105.mine and 0.75 or 0.4
					})
					if p_u_105.mine then
						v_u_4.shake(0.3, 0.25)
					end
				end
				if v130 < 1.5 then
					return true
				end
				for _, v143 in v_u_117 do
					v143.p:Destroy()
				end
				return false
			end)
		end,
		["hit"] = function(p144, p_u_145, _) -- name: hit
			-- upvalues: (ref) v_u_75, (ref) v_u_10, (copy) p_u_76, (copy) v_u_83
			local v_u_146 = p144.size
			if not p144.lite then
				v_u_75(p_u_145 + Vector3.new(0, 14, 0) * v_u_146, p_u_145, 0.4 * v_u_146, v_u_10, 0.08)
			end
			p_u_76.after(0.06, function()
				-- upvalues: (ref) v_u_83, (copy) p_u_145, (copy) v_u_146
				v_u_83(p_u_145 + Vector3.new(0, 0.5, 0), v_u_146, 0.8, true)
			end)
		end
	}
	v77.destructive_death_r = {
		["cast"] = function(p147) -- name: cast
			-- upvalues: (copy) p_u_76, (ref) v_u_9
			p_u_76.skillCast(p147, v_u_9, true)
		end,
		["windup"] = function(p_u_148, p149, p150) -- name: windup
			-- upvalues: (copy) p_u_76, (ref) v_u_50, (ref) v_u_7, (ref) v_u_12, (ref) v_u_11, (ref) v_u_75, (ref) v_u_10
			local v_u_151 = p_u_148.size
			local v_u_152 = p_u_148.ability.radius * v_u_151
			local v_u_153 = p_u_76.ground(p149, 0.12)
			local v_u_154 = math.max(p150, 0.2)
			v_u_50(v_u_153, v_u_152, v_u_152 * 2.6, v_u_7.Glow, v_u_12, 0.3, 0.15, v_u_154, 0.4, nil, 0)
			v_u_50(v_u_153 + Vector3.new(0, 0.04, 0), v_u_152 * 0.5, v_u_152 * 2.2, v_u_7.AkazaCompass, v_u_11, 0, 0.2, v_u_154, 0.4, nil, 0.35, 20)
			if not p_u_148.lite then
				local v_u_155 = os.clock()
				local v_u_156 = 0
				p_u_76.frame(function()
					-- upvalues: (copy) v_u_155, (ref) v_u_156, (copy) p_u_148, (copy) v_u_152, (copy) v_u_153, (ref) v_u_75, (copy) v_u_151, (ref) v_u_11, (ref) v_u_10, (copy) v_u_154
					local v157 = os.clock() - v_u_155
					if v157 - v_u_156 >= 0.035 then
						v_u_156 = v157
						local v158 = p_u_148.caster
						if v158 then
							v158 = p_u_148.caster.Character
						end
						if v158 then
							v158 = v158:FindFirstChild("Head")
						end
						local v159
						if v158 and v158:IsA("BasePart") then
							v159 = v158.Position - Vector3.new(0, 0.6, 0)
						else
							v159 = p_u_148.eye
						end
						local v160 = math.random() * 3.141592653589793 * 2
						local v161 = v_u_152
						local v162 = math.random()
						local v163 = v161 * math.sqrt(v162)
						local v164 = v_u_153
						local v165 = math.cos(v160) * v163
						local v166 = 1.5 + math.random() * 2
						local v167 = math.sin(v160) * v163
						local v168 = v164 + Vector3.new(v165, v166, v167)
						local v169 = v_u_75
						local v170 = v159 + (v168 - v159).Unit * 2
						local v171 = 0.3 * v_u_151
						local v172
						if math.random() < 0.3 then
							v172 = v_u_11
						else
							v172 = v_u_10
						end
						v169(v170, v168, v171, v172, 0.12)
					end
					return v157 < v_u_154
				end)
			end
		end,
		["strike"] = function(p_u_173, p_u_174, p175) -- name: strike
			-- upvalues: (copy) p_u_76, (copy) v_u_83, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9, (ref) v_u_60, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
			local v_u_176 = p_u_173.size
			local v_u_177 = (p_u_173.ability.strikeRadius or 6.5) / 6.5
			p_u_76.after(math.max(p175, 0), function()
				-- upvalues: (ref) v_u_83, (ref) p_u_76, (copy) p_u_174, (copy) v_u_176, (copy) v_u_177, (copy) p_u_173, (ref) v_u_10, (ref) v_u_13, (ref) v_u_9, (ref) v_u_60, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_4
				v_u_83(p_u_76.ground(p_u_174, 2.2 * v_u_176), v_u_176 * 1.3, v_u_177, p_u_173.lite)
				if not p_u_173.lite then
					local v178 = { v_u_10, v_u_13, v_u_9 }
					p_u_76.chunks(p_u_76.ground(p_u_174, 0.6), v178, 3, 20, 0.35 * v_u_176, 0.6, false, 1)
					p_u_76.after(0.045, function()
						-- upvalues: (ref) p_u_174, (ref) v_u_176, (ref) v_u_60, (ref) p_u_76, (ref) v_u_7, (ref) v_u_8
						local v179 = math.random() * 3.141592653589793 * 2
						local v180 = p_u_174
						local v181 = math.cos(v179)
						local v182 = math.sin(v179)
						local v183 = v180 + Vector3.new(v181, 0, v182) * 2.5 * v_u_176
						v_u_60(p_u_76.ground(v183, 1.5 + math.random() * 2), v_u_7.AkazaStar, v_u_8, 1, 4 * v_u_176, 0.22, 0.1)
					end)
					p_u_76.after(0.09, function()
						-- upvalues: (ref) p_u_174, (ref) v_u_176, (ref) v_u_60, (ref) p_u_76, (ref) v_u_7, (ref) v_u_8
						local v184 = math.random() * 3.141592653589793 * 2
						local v185 = p_u_174
						local v186 = math.cos(v184)
						local v187 = math.sin(v184)
						local v188 = v185 + Vector3.new(v186, 0, v187) * 2.5 * v_u_176
						v_u_60(p_u_76.ground(v188, 1.5 + math.random() * 2), v_u_7.AkazaStar, v_u_8, 1, 4 * v_u_176, 0.22, 0.1)
					end)
				end
				if p_u_173.mine and math.random() < 0.4 then
					local v189 = {
						["at"] = nil,
						["volume"] = 0.45,
						["at"] = p_u_174
					}
					v_u_6.play("Hit", v189)
				end
				if p_u_173.mine then
					v_u_4.shake(0.12, 0.08)
				end
			end)
		end,
		["hit"] = function(_, p190, _) -- name: hit
			-- upvalues: (copy) p_u_76, (ref) v_u_9
			p_u_76.burst("Impact", p190, v_u_9, 0.7)
		end
	}
	return v77
end