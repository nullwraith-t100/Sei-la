local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("C6E22B")
local v_u_8 = Color3.fromHex("2E3A08")
local v_u_9 = Color3.fromRGB(102, 161, 71)
local v_u_10 = Color3.fromRGB(46, 104, 52)
local v_u_11 = Color3.fromRGB(240, 232, 205)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.lookAt(Vector3.new(0, 0, 0), Vector3.new(1, 1, 1)):Inverse()
local function v_u_30(p14, p15, p16) -- name: talisman
	-- upvalues: (copy) v_u_4, (copy) v_u_11, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10
	local v17 = {}
	local v18 = {
		["p"] = v_u_4.part(Vector3.new(1, 0.06, 2.1) * p15, p14, v_u_11, {
			["material"] = Enum.Material.SmoothPlastic
		}),
		["off"] = CFrame.identity
	}
	table.insert(v17, v18)
	local v19 = v_u_4.part(Vector3.new(0.9, 0.1, 0.9) * p15, p14, v_u_7, {
		["transparency"] = 1
	})
	local v20 = Enum.NormalId.Top
	local v21 = v_u_6.MagicCircle
	local v22 = v_u_10
	local v23 = Instance.new("Decal")
	v23.Face = v20
	v23.Texture = v21
	v23.Color3 = v22
	v23.Transparency = 0
	v23.Parent = v19
	local v24 = Enum.NormalId.Bottom
	local v25 = v_u_6.MagicCircle
	local v26 = v_u_10
	local v27 = Instance.new("Decal")
	v27.Face = v24
	v27.Texture = v25
	v27.Color3 = v26
	v27.Transparency = 0
	v27.Parent = v19
	local v28 = {
		["p"] = v19,
		["off"] = CFrame.new(0, 0, p15 * -0.35)
	}
	table.insert(v17, v28)
	if not p16 then
		local v29 = {
			["p"] = v_u_4.part(Vector3.new(1.4, 0.04, 2.5) * p15, p14, v_u_7, {
				["transparency"] = 0.45
			}),
			["off"] = CFrame.new(0, p15 * -0.03, 0)
		}
		table.insert(v17, v29)
	end
	return v17
end
return function(p_u_31)
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_30, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_13, (copy) v_u_1, (copy) v_u_3, (copy) v_u_11, (copy) v_u_5, (copy) v_u_12
	local function v_u_54(p32, p33, p34, p35) -- name: pillarRig
		-- upvalues: (copy) p_u_31, (ref) v_u_9, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_13
		local v36 = p_u_31.newRig()
		local v37 = p_u_31.rigAdd(v36, Vector3.new(p32, p33, p32), CFrame.new(0, p33 / 2, 0), v_u_9, 0, Enum.Material.Marble, p34)
		v37.Reflectance = 0.12
		for _, v38 in {
			Enum.NormalId.Front,
			Enum.NormalId.Back,
			Enum.NormalId.Left,
			Enum.NormalId.Right
		} do
			local v39 = v_u_6.CrackLines
			local v40 = v_u_7
			local v41 = Instance.new("Decal")
			v41.Face = v38
			v41.Texture = v39
			v41.Color3 = v40
			v41.Transparency = 0
			v41.Parent = v37
		end
		local v42 = p_u_31.rigAdd
		local v43 = p32 * 0.98
		local v44 = p33 * 0.97
		local v45 = p32 * 0.98
		v42(v36, Vector3.new(v43, v44, v45), CFrame.new(0, p33 * 0.485, 0) * CFrame.Angles(0, 0.7853981633974483, 0), v_u_10, 0, Enum.Material.Marble, p34).Reflectance = 0.12
		for _, v46 in { 0.2, 0.8 } do
			local v47 = p_u_31.rigAdd
			local v48 = p32 * 1.14
			local v49 = p33 * 0.035 + 0.2
			local v50 = p32 * 1.14
			v47(v36, Vector3.new(v48, v49, v50), CFrame.new(0, p33 * v46, 0) * CFrame.Angles(0, 0.39269908169872414, 0), v_u_7, 0, Enum.Material.Neon, p34)
		end
		p_u_31.rigAdd(v36, Vector3.new(1, 1, 1) * p32 * 0.95, CFrame.new(0, p33, 0) * v_u_13, v_u_9, 0, Enum.Material.Marble, p34).Reflectance = 0.12
		if not p35 then
			local v51 = p_u_31.rigAdd
			local v52 = p32 * 1.35
			local v53 = p32 * 1.35
			v51(v36, Vector3.new(v52, p33, v53), CFrame.new(0, p33 / 2, 0), v_u_7, 0.84, Enum.Material.Neon, p34)
		end
		return v36
	end
	local function v_u_69(p55, p56, p_u_57, p_u_58, p59) -- name: risePillar
		-- upvalues: (copy) v_u_54, (copy) p_u_31
		local v_u_60 = v_u_54(p56, p_u_57, p_u_58 + 1.5, p59)
		local v_u_61 = CFrame.Angles((math.random() - 0.5) * 0.14, math.random() * 3.141592653589793, (math.random() - 0.5) * 0.14)
		local v_u_62 = p_u_31.ground(p55, 0)
		local v_u_63 = os.clock()
		p_u_31.runNow(function()
			-- upvalues: (copy) v_u_63, (copy) p_u_57, (copy) p_u_58, (ref) p_u_31, (copy) v_u_60, (copy) v_u_62, (copy) v_u_61
			local v64 = os.clock() - v_u_63
			local v65
			if v64 < 0.08 then
				local v66 = v64 / 0.08
				v65 = -p_u_57 * 1.05 * (1 - v66) + p_u_57 * 0.12 * v66
			elseif v64 < 0.16 then
				v65 = p_u_57 * 0.12 * (1 - (v64 - 0.08) / 0.08)
			elseif v64 < p_u_58 + 0.16 then
				v65 = 0
			else
				local v67 = -p_u_57 * 1.05
				local v68 = (v64 - 0.16 - p_u_58) / 0.22
				v65 = v67 * math.clamp(v68, 0, 1) ^ 2
			end
			p_u_31.rigPlace(v_u_60, CFrame.new(v_u_62 + Vector3.new(0, v65, 0)) * v_u_61, 1)
			if p_u_58 + 0.38 >= v64 then
				return true
			end
			p_u_31.rigDestroy(v_u_60)
			return false
		end)
	end
	local function v_u_82(p_u_70, p71, p_u_72) -- name: dragonHead
		-- upvalues: (ref) v_u_4, (ref) v_u_1, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7
		local v_u_73 = {}
		local function v80(p74, p75, p76, p77) -- name: add
			-- upvalues: (ref) v_u_4, (copy) p_u_70, (ref) v_u_1, (copy) p_u_72, (copy) v_u_73
			local v78 = v_u_4.part(p74 * p_u_70, CFrame.new(0, -50, 0), p76, {
				["material"] = p77
			})
			if p77 == Enum.Material.Marble then
				v78.Reflectance = 0.12
			end
			v_u_1:AddItem(v78, p_u_72)
			local v79 = v_u_73
			table.insert(v79, {
				["p"] = v78,
				["off"] = p75
			})
		end
		v80(Vector3.new(2.6, 2, 2.8), CFrame.new(0, p_u_70 * 0.2, 0), v_u_9, Enum.Material.Marble)
		v80(Vector3.new(1.9, 1.2, 2.5), CFrame.new(0, p_u_70 * -0.1, p_u_70 * -2.3), v_u_9, Enum.Material.Marble)
		v80(Vector3.new(1.7, 0.5, 2.6), CFrame.new(0, p_u_70 * -0.95, p_u_70 * -1.9) * CFrame.Angles(-0.35, 0, 0), v_u_10, Enum.Material.Marble)
		for _, v81 in { -1, 1 } do
			v80(Vector3.new(0.55, 0.55, 0.55), CFrame.new(v81 * 0.95 * p_u_70, p_u_70 * 0.55, p_u_70 * -0.95), v_u_7)
			v80(Vector3.new(0.35, 0.35, 3.4), CFrame.new(v81 * 0.75 * p_u_70, p_u_70 * 1.35, p_u_70 * 1.5) * CFrame.Angles(0.45, v81 * 0.28, 0), v_u_7)
			if p71 then
				continue
			end
			v80(Vector3.new(0.14, 0.14, 3.2), CFrame.new(v81 * 1.2 * p_u_70, p_u_70 * -0.3, p_u_70 * -2.4) * CFrame.Angles(0.15, v81 * 0.55, 0) * CFrame.new(0, 0, p_u_70 * 1.4), v_u_7)
		end
		return v_u_73
	end
	local function v_u_158(p83, p84, p85) -- name: dragon
		-- upvalues: (copy) p_u_31, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (ref) v_u_1, (ref) v_u_7, (copy) v_u_82, (ref) v_u_8
		local v86 = p83.ability.radius
		local v_u_87 = p83.lite
		local v_u_88 = p_u_31.ground(p84, 0)
		local v_u_89 = math.max(p85, 0.12)
		local v90 = v_u_89 + 1.6
		local v_u_91 = v86 * 0.82
		local v_u_92 = v_u_87 and 8 or 14
		local v93 = p83.dir.Z
		local v94 = p83.dir.X
		local v_u_95 = math.atan2(v93, v94) + 1.8849555921538759
		local v_u_96 = {}
		local v_u_97 = {}
		local v_u_98 = {}
		for v99 = 1, v_u_92 do
			local v100 = (1 - (v99 - 1) * 0.62 / v_u_92) * 3.2 + 0.5
			local v101 = v_u_4.part
			local v102 = Vector3.new(2, v100, v100)
			local v103 = CFrame.new(v_u_88 + Vector3.new(0, -60, 0))
			local v104
			if v99 % 2 == 0 then
				v104 = v_u_9
			else
				v104 = v_u_10
			end
			local v105 = v101(v102, v103, v104, {
				["shape"] = Enum.PartType.Cylinder,
				["material"] = Enum.Material.Marble
			})
			v105.Reflectance = 0.12
			v_u_1:AddItem(v105, v90)
			table.insert(v_u_98, v105)
			table.insert(v_u_96, v100)
			if v_u_87 or (v99 % 2 ~= 1 or v99 >= v_u_92) then
				continue
			end
			local v106 = Instance.new("WedgePart")
			v106.Anchored = true
			v106.CanCollide = false
			v106.CanQuery = false
			v106.CanTouch = false
			v106.CastShadow = false
			v106.Material = Enum.Material.Neon
			v106.Color = v_u_7
			local v107 = v100 * 0.55
			local v108 = v100 * 0.9
			v106.Size = Vector3.new(0.3, v107, v108)
			v106.CFrame = CFrame.new(v_u_88 + Vector3.new(0, -60, 0))
			v106.Parent = v_u_4.folder()
			v_u_1:AddItem(v106, v90)
			table.insert(v_u_97, v106)
		end
		local v_u_109 = v_u_82(1.4, v_u_87, v90)
		p_u_31.streak(v_u_109[1].p, v_u_7, v_u_8, 2.6, 0.35)
		if not v_u_87 then
			p_u_31.streak(v_u_98[v_u_92], v_u_7, v_u_8, 1, 0.3)
		end
		if p83.mine then
			p_u_31.light(v_u_109[1].p, v_u_7, 26)
		end
		local function v_u_120(p110, p111) -- name: on
			-- upvalues: (copy) v_u_95, (copy) v_u_91, (copy) v_u_88
			local v112 = (p110 - v_u_95) / 8.168140899333462
			local v113, v114
			if v112 <= 0 then
				v113 = 34 - v112 * 26
				v114 = v_u_91 * 0.35
			elseif v112 < 1 then
				v113 = 3.2 + 30.8 * (1 - v112) ^ 2
				v114 = v_u_91 * (math.sqrt(v112) * 0.65 + 0.35)
			else
				local v115 = p110 * 3
				v113 = math.sin(v115) * 0.6 + 3.2
				v114 = v_u_91
			end
			local v116 = v114 * p111
			local v117 = v_u_88
			local v118 = math.cos(p110) * v116
			local v119 = math.sin(p110) * v116
			return v117 + Vector3.new(v118, v113, v119)
		end
		local v_u_121 = os.clock()
		local v_u_122 = false
		p_u_31.runNow(function()
			-- upvalues: (copy) v_u_121, (copy) v_u_89, (copy) v_u_95, (copy) v_u_92, (copy) v_u_120, (copy) v_u_96, (copy) v_u_98, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (copy) v_u_97, (copy) v_u_109, (ref) v_u_122, (copy) v_u_87, (ref) p_u_31
			local v123 = os.clock() - v_u_121
			local v124
			if v123 < v_u_89 then
				v124 = v_u_95 + 8.168140899333462 * (1 - (1 - v123 / v_u_89) ^ 2.2)
			else
				v124 = v_u_95 + 8.168140899333462 + (v123 - v_u_89) * 1.4
			end
			local v125 = v123 - v_u_89
			local v126
			if v125 <= 0 then
				v126 = 1
			else
				local v127 = v125 / 0.12
				v126 = 1 - (1 - (1 - math.clamp(v127, 0, 1)) ^ 3) * 0.42
			end
			local v128 = v125 / 0.1
			local v129 = math.clamp(v128, 0, 1)
			local v130 = {}
			for v131 = 0, v_u_92 do
				local v132 = v_u_120(v124 - v131 * 5.026548245743669 / v_u_92, v126)
				table.insert(v130, v132)
			end
			for v133 = 1, v_u_92 do
				local v134 = v130[v133]
				local v135 = v130[v133 + 1]
				local v136 = v_u_96[v133]
				local v137 = v_u_98[v133]
				local v138 = (v135 - v134).Magnitude
				local v139 = math.max(v138, 0.1) + v136 * 0.55
				v137.Size = Vector3.new(v139, v136, v136)
				v137.CFrame = CFrame.lookAt((v134 + v135) / 2, v135) * CFrame.Angles(0, 1.5707963267948966, 0)
				if v129 <= 0 then
					continue
				end
				local v140
				if v133 % 2 == 0 then
					v140 = v_u_9
				else
					v140 = v_u_10
				end
				v137.Color = v140:Lerp(v_u_7, v129 * 0.7)
				local v141
				if v129 >= 1 then
					v141 = Enum.Material.Neon
				else
					v141 = Enum.Material.Marble
				end
				v137.Material = v141
			end
			for v142, v143 in v_u_97 do
				local v144 = v142 * 2 - 1
				local v145 = v130[v144]
				local v146 = v130[v144 + 1]
				v143.CFrame = CFrame.lookAt((v145 + v146) / 2, v145) * CFrame.new(0, v_u_96[v144] * 0.55, 0) * CFrame.Angles(0, 3.141592653589793, 0)
			end
			local v147 = v130[1]
			local v148 = v_u_120(v124 + 0.08, v126)
			local v149 = CFrame.lookAt(v147, v148) * CFrame.Angles(v129 * -0.25, 0, 0)
			for v150, v151 in v_u_109 do
				local v152 = v151.off
				if v150 == 3 then
					v152 = v152 * CFrame.Angles(v129 * -0.5, 0, 0)
				end
				v151.p.CFrame = v149 * v152
			end
			if v125 <= 0.7 or v_u_122 then
				return true
			end
			v_u_122 = true
			for v153 = 1, v_u_92, v_u_87 and 3 or 2 do
				local v154 = { v_u_7, v_u_9, v_u_10 }
				p_u_31.chunks(v_u_98[v153].Position, v154, 2, 26, 0.9, 0.7, true, 0.6)
			end
			p_u_31.glint(v147, v_u_7, 10, 0.25)
			p_u_31.burst("Impact", v147, v_u_7, 1.4)
			for _, v155 in v_u_98 do
				v155:Destroy()
			end
			for _, v156 in v_u_97 do
				v156:Destroy()
			end
			for _, v157 in v_u_109 do
				v157.p:Destroy()
			end
			return false
		end)
	end
	local v226 = {
		["jade_seal_a"] = {
			["cast"] = function(p159) -- name: cast
				-- upvalues: (copy) p_u_31, (ref) v_u_7
				p_u_31.muzzle(p159, v_u_7, 0.9)
			end,
			["shot"] = function(p160, p161) -- name: talismanShot
				-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_30, (copy) p_u_31, (ref) v_u_8
				local v162 = p160.size
				local v163 = p160.lite
				local v164 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p161, v_u_7, {
					["transparency"] = 1
				})
				local v165 = v_u_30(p161, v162, v163)
				p_u_31.streak(v164, v_u_7, v_u_8, 1.1 * v162, 0.16)
				local v166 = {}
				if not v163 then
					local v167 = p_u_31.loop
					local v168 = v165[1].p
					local v169 = v_u_7
					local v170 = 0.3 * v162
					table.insert(v166, v167("Trail", v168, v169, v170))
				end
				if p160.mine then
					p_u_31.light(v164, v_u_7, 9 * v162)
				end
				local v_u_171 = p_u_31.assemble(v164, v165, {}, 0, 0, v166, 0.16)
				local v_u_172 = math.random() * 6
				return {
					["place"] = function(p173, p174) -- name: place
						-- upvalues: (copy) v_u_171, (copy) v_u_172
						local v175 = v_u_171.place
						local v176 = CFrame.Angles
						local v177 = p174 * 23 + v_u_172
						local v178 = math.sin(v177) * 0.3
						local v179 = p174 * 9 + v_u_172
						local v180 = math.sin(v179) * 0.15
						local v181 = p174 * 15 + v_u_172
						v175(p173 * v176(v178, v180, math.sin(v181) * 0.5), p174)
					end,
					["stop"] = v_u_171.stop
				}
			end,
			["impact"] = function(p182, p183) -- name: impact
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_3, (ref) v_u_6, (ref) v_u_11, (ref) v_u_4
				local v184 = p182.size
				p_u_31.burst("Fire", p_u_31.ground(p183, 0.3), v_u_7, 0.6 * v184)
				p_u_31.burst("Impact", p183, v_u_7, 0.9 * v184)
				p_u_31.pop(p183, v_u_7, 1.4 * v184, 6 * v184, 0.16, 0.25)
				local v185 = p_u_31.sigil
				local v186 = p_u_31.facing
				local v187 = v_u_3.CurrentCamera
				local v188
				if v187 then
					local v189 = v187.CFrame.Position - p183
					v188 = v189.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v189.Unit
				else
					v188 = Vector3.new(0, 1, 0)
				end
				v185(v186(p183, v188), 2.6 * v184, v_u_7, v_u_6.MagicCircle, 0.1, 8)
				if not p182.lite then
					local v190 = { v_u_11, v_u_7 }
					p_u_31.chunks(p183, v190, 3, 18, 0.35 * v184, 0.5, false, 0.8)
				end
				v_u_4.ring(p_u_31.ground(p183), v_u_7, 6 * v184, 0.25, v_u_6.Ring)
				p_u_31.hitSound(p183)
			end,
			["hit"] = function(_, p191, _) -- name: hit
				-- upvalues: (copy) p_u_31, (ref) v_u_7
				p_u_31.burst("Impact", p191, v_u_7, 0.6)
				p_u_31.glint(p191, v_u_7, 3, 0.12)
			end
		},
		["jade_seal_e"] = {
			["cast"] = function(p192) -- name: cast
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_30
				p_u_31.skillCast(p192, v_u_7)
				local v193 = p192.eye + p192.dir * 1.6
				local v194 = p_u_31.facing(v193, p192.dir)
				for _, v195 in v_u_30(v194, p192.size * 1.3, p192.lite) do
					v195.p.CFrame = v194 * v195.off
					p_u_31.fadeOut(v195.p, 0.35)
				end
			end,
			["windup"] = function(p196, p197, p198) -- name: windup
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9
				local v199 = p196.ability.radius
				p_u_31.sigil(CFrame.new(p_u_31.ground(p197, 0.15)), v199, v_u_7, v_u_6.MagicCircle, p198 + 0.2, 1)
				p_u_31.sigil(CFrame.new(p_u_31.ground(p197, 0.17)), v199 * 1.08, v_u_9, v_u_6.Ring, p198 + 0.2, -0.8)
				p_u_31.mark(p197, v_u_7, v199 * 0.6, p198 + 0.4, v_u_6.CrackGlow, 0.3)
			end,
			["strike"] = function(p_u_200, p_u_201, p202) -- name: strike
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_6, (ref) v_u_8, (copy) v_u_69, (ref) v_u_4, (ref) v_u_9, (ref) v_u_5
				local v_u_203 = p_u_200.lite
				local v_u_204 = p_u_200.ability.strikeRadius or 7
				local v_u_205 = v_u_204 * 0.5
				local v_u_206 = v_u_204 * 1.9
				local v_u_207 = math.clamp(p202, 0, 0.2)
				p_u_31.after(p202 - v_u_207, function()
					-- upvalues: (ref) p_u_31, (copy) p_u_201, (ref) v_u_7, (copy) v_u_205, (copy) v_u_207, (ref) v_u_6, (ref) v_u_8
					p_u_31.mark(p_u_201, v_u_7, v_u_205 * 1.3, v_u_207 + 0.3, v_u_6.CrackGlow, 0.05)
					p_u_31.mark(p_u_201, v_u_8, v_u_205 * 1.2, v_u_207 + 0.9, v_u_6.CrackLines, 0)
				end)
				p_u_31.after(p202, function()
					-- upvalues: (ref) v_u_69, (copy) p_u_201, (copy) v_u_205, (copy) v_u_206, (copy) v_u_203, (ref) p_u_31, (ref) v_u_7, (ref) v_u_4, (copy) v_u_204, (ref) v_u_6, (ref) v_u_9, (ref) v_u_5, (copy) p_u_200
					v_u_69(p_u_201, v_u_205, v_u_206, 0.45, v_u_203)
					local v208 = p_u_31.ground(p_u_201)
					p_u_31.burst("Shockwave", v208 + Vector3.new(0, 0.3, 0), v_u_7, v_u_205 / 9)
					p_u_31.burst("Smoke", v208 + Vector3.new(0, 1, 0), nil, v_u_205 / 5)
					v_u_4.ring(v208, v_u_7, v_u_204, 0.3, v_u_6.Ring)
					p_u_31.spikes(v208 + Vector3.new(0, 1, 0), v_u_7, v_u_203 and 3 or 6, v_u_206 * 0.8, 0.25, Vector3.new(0, 1, 0), 0.6)
					if not v_u_203 then
						p_u_31.chunks(v208 + Vector3.new(0, 1, 0), { p_u_31.EARTH[1], p_u_31.EARTH[2], v_u_9 }, 5, 30, 0.9, 0.7)
					end
					v_u_5.play("Hit", {
						["at"] = nil,
						["volume"] = 0.7,
						["at"] = v208
					})
					if p_u_200.mine then
						v_u_4.shake(0.2, 0.15)
					end
				end)
			end,
			["hit"] = function(_, p209, _) -- name: hit
				-- upvalues: (copy) p_u_31, (ref) v_u_7
				p_u_31.burst("Impact", p209, v_u_7, 0.8)
				p_u_31.glint(p209, v_u_7, 4, 0.15)
			end
		},
		["jade_seal_r"] = {
			["cast"] = function(p210) -- name: cast
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_6
				p_u_31.skillCast(p210, v_u_7, true)
				p_u_31.burst("Flash", p210.eye, v_u_7, 0.45)
				p_u_31.sigil(p_u_31.facing(p210.eye + p210.dir * 1.8, p210.dir), 3 * p210.size, v_u_7, v_u_6.MagicCircle, 0.35, 4)
			end,
			["windup"] = function(p211, p212, p213) -- name: windup
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_6, (ref) v_u_9, (copy) v_u_158
				local v214 = p211.ability.radius
				local v215 = p213 + 0.9
				p_u_31.sigil(CFrame.new(p_u_31.ground(p212, 0.15)), v214, v_u_7, v_u_6.MagicCircle, v215, 1.2)
				p_u_31.sigil(CFrame.new(p_u_31.ground(p212, 0.17)), v214 * 1.1, v_u_9, v_u_6.Ring, v215, -0.8)
				p_u_31.mark(p212, v_u_7, v214 * 0.8, v215 + 0.3, v_u_6.CrackGlow, 0.35)
				v_u_158(p211, p212, p213)
			end,
			["land"] = function(p216, p217) -- name: land
				-- upvalues: (copy) p_u_31, (ref) v_u_7, (ref) v_u_12, (ref) v_u_4, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9, (ref) v_u_8, (ref) v_u_5
				local v218 = p216.ability.radius
				local v219 = p216.lite
				local v220 = p_u_31.ground(p217)
				p_u_31.thin(p_u_31.pillar(v220, 34, v218 * 0.7, v_u_7, 0.35), 0.5, true)
				p_u_31.thin(p_u_31.pillar(v220, 34, v218 * 0.28, v_u_12, 0), 0.35, true)
				p_u_31.burst("Explosion", p_u_31.ground(p217, 2), v_u_7, v218 / 9)
				p_u_31.burst("Flash", p_u_31.ground(p217, 4), v_u_7, 0.9)
				local v221 = p_u_31.burst
				local v222 = v220 + Vector3.new(0, 0.3, 0)
				local v223 = v_u_7
				local v224 = v218 / 14
				v221("Shockwave", v222, v223, (math.min(v224, 1.6)))
				v_u_4.ring(v220, v_u_7, v218 * 1.25, 0.5)
				v_u_4.ring(v220, v_u_11, v218 * 1.4, 0.45, v_u_6.SpeedLines)
				p_u_31.sigil(CFrame.new(p_u_31.ground(p217, 0.22)), v218 * 1.15, v_u_7, v_u_6.MagicCircle, 0.3, 6)
				p_u_31.pop(p_u_31.ground(p217, 3), v_u_7, 4, v218 * 1.2, 0.25, 0.45)
				p_u_31.spikes(p_u_31.ground(p217, 1), v_u_7, 12, v218, 0.3, nil, nil, true)
				p_u_31.chunks(p_u_31.ground(p217, 1), { p_u_31.EARTH[1], p_u_31.EARTH[2], v_u_9 }, v219 and 6 or 14, 44, 1.4, 1.1)
				p_u_31.mark(p217, v_u_8, v218 * 0.95, 2, v_u_6.CrackLines, 0)
				p_u_31.mark(p217, v_u_7, v218 * 0.7, 1.4, v_u_6.CrackGlow, 0.1)
				v_u_5.play("Explosion", {
					["at"] = v220
				})
				v_u_5.play("Crit", {
					["at"] = v220,
					["volume"] = p216.mine and 0.8 or 0.5
				})
				if p216.mine then
					v_u_4.shake(0.6, 0.5)
				end
			end,
			["hit"] = function(_, p225, _) -- name: hit
				-- upvalues: (copy) p_u_31, (ref) v_u_7
				p_u_31.burst("Impact", p225, v_u_7, 1.1)
				p_u_31.glint(p225, v_u_7, 5, 0.18)
			end
		}
	}
	return v226
end