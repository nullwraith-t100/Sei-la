require(script.Parent.Pets)
local v_u_1 = require(script.Parent.Parent.Logic.Prizes)
local v_u_7 = {
	["packs"] = {
		["starter"] = v_u_1.worldPet(2, "Epic", 1)
	},
	["DAILY_RARITY"] = "Rare",
	["pack"] = function(p2, p3) -- name: pack
		-- upvalues: (copy) v_u_7, (copy) v_u_1
		local v_u_4 = v_u_7.packs[p2]
		return v_u_1.withoutEggs(p3, function(_)
			-- upvalues: (copy) v_u_4
			return v_u_4
		end, true)
	end,
	["daily"] = function(p5) -- name: daily
		-- upvalues: (copy) v_u_1
		return v_u_1.withoutEggs(p5, function(p6)
			-- upvalues: (ref) v_u_1
			return v_u_1.eggPet(p6, "Rare")
		end)
	end
}
return v_u_7