local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("SocialService")
local v_u_6 = require(v3.Shared.Config.Events)
local v_u_7 = require(script.Parent.Store)
local v_u_8 = require(script.Parent.Tutorial)
local v9 = {}
local v_u_10 = v2.LocalPlayer
local function v_u_15() -- name: calm
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_1, (copy) v_u_7, (copy) v_u_6
	if v_u_8.active() or (v_u_10:GetAttribute("InWave") == true or v_u_1.MenuIsOpen) then
		return false
	end
	if v_u_7.sincePrompt() < v_u_6.quietSeconds then
		return false
	end
	local v11 = v_u_10:FindFirstChild("PlayerGui")
	if v11 then
		v11 = v11:FindFirstChild("Main")
	end
	if not (v11 and (v11:IsA("ScreenGui") and v11.Enabled)) then
		return false
	end
	local v12 = v11:FindFirstChild("Frames")
	if v12 then
		for _, v13 in v12:GetChildren() do
			if not (v13:IsA("GuiObject") and v13.Visible) then
				continue
			end
			return false
		end
	end
	local v14 = v11:FindFirstChild("HUD")
	if v14 then
		v14 = v14:FindFirstChild("Overlay")
	end
	if v14 then
		v14 = v14:FindFirstChild("Hatch")
	end
	return not (v14 and (v14:IsA("GuiObject") and v14.Visible))
end
function v9.start() -- name: start
	-- upvalues: (copy) v_u_6, (copy) v_u_8, (copy) v_u_4, (copy) v_u_10, (copy) v_u_5, (copy) v_u_15
	local v_u_16 = v_u_6.tuneIn
	if v_u_16 ~= "" then
		task.spawn(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_4, (ref) v_u_10, (copy) v_u_16, (ref) v_u_5, (ref) v_u_15
			local v17 = os.clock()
			while not v_u_8.known() or v_u_8.active() do
				task.wait(2)
			end
			local v18 = v_u_6.afterMinutes[1]
			local v19 = v_u_6.afterMinutes[2]
			local v20 = v17 + (v18 + math.random() * (v19 - v18)) * 60
			local v21 = os.clock() + v_u_6.afterTutorialMinutes * 60
			local v22 = math.max(v20, v21)
			while os.clock() < v22 do
				local v23 = v_u_4:IsStudio()
				if v23 then
					v23 = v_u_10:GetAttribute("DevTuneIn") == true
				end
				if v23 then
					break
				end
				task.wait(5)
			end
			local v_u_24 = v_u_16
			local function v25()
				-- upvalues: (ref) v_u_5, (copy) v_u_24
				return v_u_5:GetEventRsvpStatusAsync(v_u_24)
			end
			local v26, v27 = pcall(v25)
			if not v26 then
				v27 = nil
			end
			if v27 ~= Enum.RsvpStatus.None then
				return
			end
			while true do
				if v_u_15() then
					task.wait(1.5)
					if v_u_15() then
						v_u_10:SetAttribute("DevTuneIn", nil)
						local function v28()
							-- upvalues: (ref) v_u_5, (ref) v_u_16
							v_u_5:PromptRsvpToEventAsync(v_u_16)
						end
						pcall(v28)
						return
					end
				end
				task.wait(2)
			end
		end)
	end
end
return v9