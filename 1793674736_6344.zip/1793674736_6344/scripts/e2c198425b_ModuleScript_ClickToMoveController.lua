local v1, v2 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserExcludeNonCollidableForPathfinding")
end)
local v_u_3 = v1 and v2
local v4, v5 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserClickToMoveSupportAgentCanClimb2")
end)
local v_u_6 = v4 and v5
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = game:GetService("PathfindingService")
local v9 = game:GetService("Players")
game:GetService("Debris")
local v_u_10 = game:GetService("Workspace")
local v_u_11 = game:GetService("CollectionService")
local v_u_12 = game:GetService("GuiService")
local v13 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_14 = v13.getUserFlag("UserRaycastUpdateAPI2")
local v_u_15 = v13.getUserFlag("UserPSIASClickToMoveRelaxTeleport")
local v_u_16 = v13.getUserFlag("UserPlayerScriptsRefactor2")
local v_u_17 = v13.getUserFlag("UserDoubleJumpButtonFix")
local v18 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("CharacterContext")
local v_u_19 = v18:WaitForChild("ClickToMoveAction")
local v_u_20 = v18:WaitForChild("ClickToMovePositionAction")
local v_u_21 = true
local v_u_22 = true
local v_u_23 = false
local v_u_24 = 1
local v_u_25 = 8
local v_u_26 = v9.LocalPlayer
local v_u_27 = require(script.Parent:WaitForChild("ClickToMoveDisplay"))
local v_u_28 = RaycastParams.new()
v_u_28.FilterType = Enum.RaycastFilterType.Exclude
local v_u_29 = {}
if not v_u_14 then
	local function v_u_32(p30) -- name: FindCharacterAncestor
		-- upvalues: (copy) v_u_32
		if p30 then
			local v31 = p30:FindFirstChildOfClass("Humanoid")
			if v31 then
				return p30, v31
			else
				return v_u_32(p30.Parent)
			end
		else
			return
		end
	end
	v_u_29.FindCharacterAncestor = v_u_32
	local function v_u_43(p33, p34, p35) -- name: Raycast
		-- upvalues: (copy) v_u_10, (copy) v_u_32, (copy) v_u_43
		local v36 = p35 or {}
		local v37, v38, v39, v40 = v_u_10:FindPartOnRayWithIgnoreList(p33, v36)
		if not v37 then
			return nil, nil
		end
		if p34 and v37.CanCollide == false then
			local v41 = not v37 or v37:FindFirstChildOfClass("Humanoid")
			if not v41 then
				local v42
				v42, v41 = v_u_32(v37.Parent)
			end
			if v41 == nil then
				table.insert(v36, v37)
				return v_u_43(p33, p34, v36)
			end
		end
		return v37, v38, v39, v40
	end
	v_u_29.Raycast = v_u_43
end
local v_u_44 = {}
local v_u_45 = nil
local v_u_46 = nil
local v_u_47 = nil
local v_u_48 = nil
local function v_u_59(p49) -- name: UpdateIgnoreTag
	-- upvalues: (ref) v_u_46, (ref) v_u_47, (ref) v_u_48, (ref) v_u_45, (copy) v_u_26, (copy) v_u_11
	if p49 ~= v_u_46 then
		if v_u_47 then
			v_u_47:Disconnect()
			v_u_47 = nil
		end
		if v_u_48 then
			v_u_48:Disconnect()
			v_u_48 = nil
		end
		v_u_46 = p49
		local v50 = {}
		local v51 = v_u_26
		if v51 then
			v51 = v_u_26.Character
		end
		__set_list(v50, 1, {v51})
		v_u_45 = v50
		if v_u_46 ~= nil then
			local v52 = v_u_11:GetTagged(v_u_46)
			for _, v53 in ipairs(v52) do
				local v54 = v_u_45
				table.insert(v54, v53)
			end
			v_u_47 = v_u_11:GetInstanceAddedSignal(v_u_46):Connect(function(p55)
				-- upvalues: (ref) v_u_45
				local v56 = v_u_45
				table.insert(v56, p55)
			end)
			v_u_48 = v_u_11:GetInstanceRemovedSignal(v_u_46):Connect(function(p57)
				-- upvalues: (ref) v_u_45
				for v58 = 1, #v_u_45 do
					if v_u_45[v58] ~= p57 then
						continue
					end
					v_u_45[v58] = v_u_45[#v_u_45]
					table.remove(v_u_45)
					return
				end
			end)
		end
	end
end
local function v_u_124(p60) -- name: getCollidableExtentsSize
	if p60 == nil or p60.PrimaryPart == nil then
		return
	else
		assert(p60, "")
		local v61 = p60.PrimaryPart
		assert(v61, "")
		local v62 = p60.PrimaryPart.CFrame:Inverse()
		local v63 = Vector3.new(inf, inf, inf)
		local v64 = Vector3.new(-inf, -inf, -inf)
		for _, v65 in pairs(p60:GetDescendants()) do
			if not (v65:IsA("BasePart") and v65.CanCollide) then
				continue
			end
			local v66 = v62 * v65.CFrame
			local v67 = v65.Size.X / 2
			local v68 = v65.Size.Y / 2
			local v69 = v65.Size.Z / 2
			local v70 = Vector3.new(v67, v68, v69)
			local v71 = {}
			local v72 = v70.X
			local v73 = v70.Y
			local v74 = v70.Z
			local v75 = Vector3.new(v72, v73, v74)
			local v76 = v70.X
			local v77 = v70.Y
			local v78 = -v70.Z
			local v79 = Vector3.new(v76, v77, v78)
			local v80 = v70.X
			local v81 = -v70.Y
			local v82 = v70.Z
			local v83 = Vector3.new(v80, v81, v82)
			local v84 = v70.X
			local v85 = -v70.Y
			local v86 = -v70.Z
			local v87 = Vector3.new(v84, v85, v86)
			local v88 = -v70.X
			local v89 = v70.Y
			local v90 = v70.Z
			local v91 = Vector3.new(v88, v89, v90)
			local v92 = -v70.X
			local v93 = v70.Y
			local v94 = -v70.Z
			local v95 = Vector3.new(v92, v93, v94)
			local v96 = -v70.X
			local v97 = -v70.Y
			local v98 = v70.Z
			local v99 = Vector3.new(v96, v97, v98)
			local v100 = -v70.X
			local v101 = -v70.Y
			local v102 = -v70.Z
			__set_list(v71, 1, {v75, v79, v83, v87, v91, v95, v99, (Vector3.new(v100, v101, v102))})
			for _, v103 in ipairs(v71) do
				local v104 = v66 * v103
				local v105 = v63.X
				local v106 = v104.X
				local v107 = math.min(v105, v106)
				local v108 = v63.Y
				local v109 = v104.Y
				local v110 = math.min(v108, v109)
				local v111 = v63.Z
				local v112 = v104.Z
				local v113 = math.min(v111, v112)
				v63 = Vector3.new(v107, v110, v113)
				local v114 = v64.X
				local v115 = v104.X
				local v116 = math.max(v114, v115)
				local v117 = v64.Y
				local v118 = v104.Y
				local v119 = math.max(v117, v118)
				local v120 = v64.Z
				local v121 = v104.Z
				local v122 = math.max(v120, v121)
				v64 = Vector3.new(v116, v119, v122)
			end
		end
		local v123 = v64 - v63
		if v123.X < 0 or (v123.Y < 0 or v123.Z < 0) then
			return nil
		else
			return v123
		end
	end
end
local function v_u_199(p125, p126, p127) -- name: Pather
	-- upvalues: (ref) v_u_23, (copy) v_u_26, (copy) v_u_44, (ref) v_u_24, (copy) v_u_3, (copy) v_u_124, (copy) v_u_6, (copy) v_u_8, (ref) v_u_21, (copy) v_u_27, (ref) v_u_25, (copy) v_u_15, (copy) v_u_14, (copy) v_u_28, (ref) v_u_45, (copy) v_u_10
	local v_u_128 = {}
	local v129
	if p127 == nil then
		v129 = v_u_23
		p127 = true
	else
		v129 = p127
	end
	v_u_128.Cancelled = false
	v_u_128.Started = false
	v_u_128.Finished = Instance.new("BindableEvent")
	v_u_128.PathFailed = Instance.new("BindableEvent")
	v_u_128.PathComputing = false
	v_u_128.PathComputed = false
	v_u_128.OriginalTargetPoint = p125
	v_u_128.TargetPoint = p125
	v_u_128.TargetSurfaceNormal = p126
	v_u_128.DiedConn = nil
	v_u_128.SeatedConn = nil
	v_u_128.BlockedConn = nil
	v_u_128.TeleportedConn = nil
	v_u_128.CurrentPoint = 0
	v_u_128.HumanoidOffsetFromPath = Vector3.new(0, 0, 0)
	v_u_128.CurrentWaypointPosition = nil
	v_u_128.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
	v_u_128.CurrentWaypointPlaneDistance = 0
	v_u_128.CurrentWaypointNeedsJump = false
	v_u_128.CurrentHumanoidPosition = Vector3.new(0, 0, 0)
	v_u_128.CurrentHumanoidVelocity = 0
	v_u_128.NextActionMoveDirection = Vector3.new(0, 0, 0)
	v_u_128.NextActionJump = false
	v_u_128.Timeout = 0
	local v130 = v_u_26
	local v131
	if v130 then
		v131 = v130.Character
	else
		v131 = v130
	end
	local v132
	if v131 then
		v132 = v_u_44[v130]
		if not v132 or v132.Parent ~= v131 then
			v_u_44[v130] = nil
			v132 = v131:FindFirstChildOfClass("Humanoid")
			if v132 then
				v_u_44[v130] = v132
			end
		end
	else
		v132 = nil
	end
	v_u_128.Humanoid = v132
	v_u_128.OriginPoint = nil
	v_u_128.AgentCanFollowPath = false
	v_u_128.DirectPath = false
	v_u_128.DirectPathRiseFirst = false
	v_u_128.stopTraverseFunc = nil
	v_u_128.setPointFunc = nil
	v_u_128.pointList = nil
	local v133 = v_u_128.Humanoid
	if v133 then
		v133 = v_u_128.Humanoid.RootPart
	end
	if v133 then
		v_u_128.OriginPoint = v133.CFrame.Position
		local v134 = 2
		local v135 = 5
		local v136 = true
		local v137 = v_u_128.Humanoid.SeatPart
		if v137 and v137:IsA("VehicleSeat") then
			local v138 = v137:FindFirstAncestorOfClass("Model")
			if v138 then
				local v139 = v138.PrimaryPart
				v138.PrimaryPart = v137
				if p127 then
					local v140 = v138:GetExtentsSize()
					local v141 = v_u_24 * 0.5
					local v142 = v140.X * v140.X + v140.Z * v140.Z
					v134 = v141 * math.sqrt(v142)
					v135 = v_u_24 * v140.Y
					v_u_128.AgentCanFollowPath = true
					v_u_128.DirectPath = p127
					v136 = false
				end
				v138.PrimaryPart = v139
			end
		else
			local v143 = nil
			if v_u_3 then
				local v144 = v_u_26
				if v144 then
					v144 = v_u_26.Character
				end
				if v144 ~= nil then
					v143 = v_u_124(v144)
				end
			end
			if v143 == nil then
				local v145 = v_u_26
				if v145 then
					v145 = v_u_26.Character
				end
				v143 = v145:GetExtentsSize()
			end
			assert(v143, "")
			local v146 = v_u_24 * 0.5
			local v147 = v143.X * v143.X + v143.Z * v143.Z
			v134 = v146 * math.sqrt(v147)
			v135 = v_u_24 * v143.Y
			v136 = v_u_128.Humanoid.JumpPower > 0
			v_u_128.AgentCanFollowPath = true
			v_u_128.DirectPath = v129
			v_u_128.DirectPathRiseFirst = v_u_128.Humanoid.Sit
		end
		if v_u_6 then
			v_u_128.pathResult = v_u_8:CreatePath({
				["AgentRadius"] = nil,
				["AgentHeight"] = nil,
				["AgentCanJump"] = nil,
				["AgentCanClimb"] = true,
				["AgentRadius"] = v134,
				["AgentHeight"] = v135,
				["AgentCanJump"] = v136
			})
		else
			v_u_128.pathResult = v_u_8:CreatePath({
				["AgentRadius"] = v134,
				["AgentHeight"] = v135,
				["AgentCanJump"] = v136
			})
		end
	end
	function v_u_128.Cleanup(_) -- name: Cleanup
		-- upvalues: (copy) v_u_128
		if v_u_128.stopTraverseFunc then
			v_u_128.stopTraverseFunc()
			v_u_128.stopTraverseFunc = nil
		end
		if v_u_128.BlockedConn then
			v_u_128.BlockedConn:Disconnect()
			v_u_128.BlockedConn = nil
		end
		if v_u_128.DiedConn then
			v_u_128.DiedConn:Disconnect()
			v_u_128.DiedConn = nil
		end
		if v_u_128.SeatedConn then
			v_u_128.SeatedConn:Disconnect()
			v_u_128.SeatedConn = nil
		end
		if v_u_128.TeleportedConn then
			v_u_128.TeleportedConn:Disconnect()
			v_u_128.TeleportedConn = nil
		end
		v_u_128.Started = false
	end
	function v_u_128.Cancel(_) -- name: Cancel
		-- upvalues: (copy) v_u_128
		v_u_128.Cancelled = true
		v_u_128:Cleanup()
	end
	function v_u_128.IsActive(_) -- name: IsActive
		-- upvalues: (copy) v_u_128
		local v148 = v_u_128.AgentCanFollowPath and v_u_128.Started
		if v148 then
			v148 = not v_u_128.Cancelled
		end
		return v148
	end
	function v_u_128.OnPathInterrupted(_) -- name: OnPathInterrupted
		-- upvalues: (copy) v_u_128
		v_u_128.Cancelled = true
		v_u_128:OnPointReached(false)
	end
	function v_u_128.ComputePath(_) -- name: ComputePath
		-- upvalues: (copy) v_u_128
		if v_u_128.OriginPoint then
			if v_u_128.PathComputed or v_u_128.PathComputing then
				return
			end
			v_u_128.PathComputing = true
			if v_u_128.AgentCanFollowPath then
				if v_u_128.DirectPath then
					v_u_128.pointList = { PathWaypoint.new(v_u_128.OriginPoint, Enum.PathWaypointAction.Walk), PathWaypoint.new(v_u_128.TargetPoint, v_u_128.DirectPathRiseFirst and Enum.PathWaypointAction.Jump or Enum.PathWaypointAction.Walk) }
					v_u_128.PathComputed = true
				else
					v_u_128.pathResult:ComputeAsync(v_u_128.OriginPoint, v_u_128.TargetPoint)
					v_u_128.pointList = v_u_128.pathResult:GetWaypoints()
					v_u_128.BlockedConn = v_u_128.pathResult.Blocked:Connect(function(p149)
						-- upvalues: (ref) v_u_128
						v_u_128:OnPathBlocked(p149)
					end)
					v_u_128.PathComputed = v_u_128.pathResult.Status == Enum.PathStatus.Success
				end
			end
			v_u_128.PathComputing = false
		end
	end
	function v_u_128.IsValidPath(_) -- name: IsValidPath
		-- upvalues: (copy) v_u_128
		v_u_128:ComputePath()
		local v150 = v_u_128.PathComputed
		if v150 then
			v150 = v_u_128.AgentCanFollowPath
		end
		return v150
	end
	v_u_128.Recomputing = false
	function v_u_128.OnPathBlocked(_, p151) -- name: OnPathBlocked
		-- upvalues: (copy) v_u_128, (ref) v_u_21, (ref) v_u_27
		if v_u_128.CurrentPoint <= p151 and not v_u_128.Recomputing then
			v_u_128.Recomputing = true
			if v_u_128.stopTraverseFunc then
				v_u_128.stopTraverseFunc()
				v_u_128.stopTraverseFunc = nil
			end
			v_u_128.OriginPoint = v_u_128.Humanoid.RootPart.CFrame.Position
			v_u_128.pathResult:ComputeAsync(v_u_128.OriginPoint, v_u_128.TargetPoint)
			v_u_128.pointList = v_u_128.pathResult:GetWaypoints()
			if #v_u_128.pointList > 0 then
				v_u_128.HumanoidOffsetFromPath = v_u_128.pointList[1].Position - v_u_128.OriginPoint
			end
			v_u_128.PathComputed = v_u_128.pathResult.Status == Enum.PathStatus.Success
			if v_u_21 then
				local v152 = v_u_128
				local v153 = v_u_128
				local v154, v155 = v_u_27.CreatePathDisplay(v_u_128.pointList)
				v152.stopTraverseFunc = v154
				v153.setPointFunc = v155
			end
			if v_u_128.PathComputed then
				v_u_128.CurrentPoint = 1
				v_u_128:OnPointReached(true)
			else
				v_u_128.PathFailed:Fire()
				v_u_128:Cleanup()
			end
			v_u_128.Recomputing = false
		end
	end
	function v_u_128.OnRenderStepped(_, p156) -- name: OnRenderStepped
		-- upvalues: (copy) v_u_128, (ref) v_u_25
		if v_u_128.Started and not v_u_128.Cancelled then
			v_u_128.Timeout = v_u_128.Timeout + p156
			if v_u_25 < v_u_128.Timeout then
				v_u_128:OnPointReached(false)
				return
			end
			v_u_128.CurrentHumanoidPosition = v_u_128.Humanoid.RootPart.Position + v_u_128.HumanoidOffsetFromPath
			v_u_128.CurrentHumanoidVelocity = v_u_128.Humanoid.RootPart.Velocity
			while v_u_128.Started and v_u_128:IsCurrentWaypointReached() do
				v_u_128:OnPointReached(true)
			end
			if v_u_128.Started then
				v_u_128.NextActionMoveDirection = v_u_128.CurrentWaypointPosition - v_u_128.CurrentHumanoidPosition
				if v_u_128.NextActionMoveDirection.Magnitude > 1e-6 then
					v_u_128.NextActionMoveDirection = v_u_128.NextActionMoveDirection.Unit
				else
					v_u_128.NextActionMoveDirection = Vector3.new(0, 0, 0)
				end
				if v_u_128.CurrentWaypointNeedsJump then
					v_u_128.NextActionJump = true
					v_u_128.CurrentWaypointNeedsJump = false
					return
				end
				v_u_128.NextActionJump = false
			end
		end
	end
	function v_u_128.IsCurrentWaypointReached(_) -- name: IsCurrentWaypointReached
		-- upvalues: (copy) v_u_128
		local v157
		if v_u_128.CurrentWaypointPlaneNormal == Vector3.new(0, 0, 0) then
			v157 = true
		else
			local v158 = v_u_128.CurrentWaypointPlaneNormal:Dot(v_u_128.CurrentHumanoidPosition) - v_u_128.CurrentWaypointPlaneDistance
			local v159 = 0.0625 * -v_u_128.CurrentWaypointPlaneNormal:Dot(v_u_128.CurrentHumanoidVelocity)
			v157 = v158 < math.max(1, v159)
		end
		if v157 then
			v_u_128.CurrentWaypointPosition = nil
			v_u_128.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			v_u_128.CurrentWaypointPlaneDistance = 0
		end
		return v157
	end
	function v_u_128.OnPointReached(_, p160) -- name: OnPointReached
		-- upvalues: (copy) v_u_128
		if p160 and not v_u_128.Cancelled then
			if v_u_128.setPointFunc then
				v_u_128.setPointFunc(v_u_128.CurrentPoint)
			end
			local v161 = v_u_128.CurrentPoint + 1
			if #v_u_128.pointList < v161 then
				if v_u_128.stopTraverseFunc then
					v_u_128.stopTraverseFunc()
				end
				v_u_128.Finished:Fire()
				v_u_128:Cleanup()
			else
				local v162 = v_u_128.pointList[v_u_128.CurrentPoint]
				local v163 = v_u_128.pointList[v161]
				local v164 = v_u_128.Humanoid:GetState()
				if (v164 == Enum.HumanoidStateType.FallingDown or v164 == Enum.HumanoidStateType.Freefall) and true or v164 == Enum.HumanoidStateType.Jumping then
					local v165 = v163.Action == Enum.PathWaypointAction.Jump
					if not v165 and v_u_128.CurrentPoint > 1 then
						local v166 = v_u_128.pointList[v_u_128.CurrentPoint - 1]
						local v167 = v162.Position - v166.Position
						local v168 = v163.Position - v162.Position
						v165 = Vector2.new(v167.x, v167.z).Unit:Dot(Vector2.new(v168.x, v168.z).Unit) < 0.996
					end
					if v165 then
						v_u_128.Humanoid.FreeFalling:Wait()
						wait(0.1)
					end
				end
				v_u_128:MoveToNextWayPoint(v162, v163, v161)
			end
		else
			v_u_128.PathFailed:Fire()
			v_u_128:Cleanup()
			return
		end
	end
	function v_u_128.MoveToNextWayPoint(_, p169, p170, p171) -- name: MoveToNextWayPoint
		-- upvalues: (copy) v_u_128, (ref) v_u_6
		v_u_128.CurrentWaypointPlaneNormal = p169.Position - p170.Position
		if not v_u_6 or p170.Label ~= "Climb" then
			local v172 = v_u_128
			local v173 = v_u_128.CurrentWaypointPlaneNormal.X
			local v174 = v_u_128.CurrentWaypointPlaneNormal.Z
			v172.CurrentWaypointPlaneNormal = Vector3.new(v173, 0, v174)
		end
		if v_u_128.CurrentWaypointPlaneNormal.Magnitude > 1e-6 then
			v_u_128.CurrentWaypointPlaneNormal = v_u_128.CurrentWaypointPlaneNormal.Unit
			v_u_128.CurrentWaypointPlaneDistance = v_u_128.CurrentWaypointPlaneNormal:Dot(p170.Position)
		else
			v_u_128.CurrentWaypointPlaneNormal = Vector3.new(0, 0, 0)
			v_u_128.CurrentWaypointPlaneDistance = 0
		end
		v_u_128.CurrentWaypointNeedsJump = p170.Action == Enum.PathWaypointAction.Jump
		v_u_128.CurrentWaypointPosition = p170.Position
		v_u_128.CurrentPoint = p171
		v_u_128.Timeout = 0
	end
	function v_u_128.Start(_, p175) -- name: Start
		-- upvalues: (copy) v_u_128, (ref) v_u_27, (ref) v_u_21, (ref) v_u_15
		if v_u_128.AgentCanFollowPath then
			if v_u_128.Started then
				return
			else
				v_u_128.Started = true
				v_u_27.CancelFailureAnimation()
				if v_u_21 and (p175 == nil or p175) then
					local v176 = v_u_128
					local v177 = v_u_128
					local v178, v179 = v_u_27.CreatePathDisplay(v_u_128.pointList, v_u_128.OriginalTargetPoint)
					v176.stopTraverseFunc = v178
					v177.setPointFunc = v179
				end
				if #v_u_128.pointList > 0 then
					local v180 = v_u_128
					local v181 = v_u_128.pointList[1].Position.Y - v_u_128.OriginPoint.Y
					v180.HumanoidOffsetFromPath = Vector3.new(0, v181, 0)
					v_u_128.CurrentHumanoidPosition = v_u_128.Humanoid.RootPart.Position + v_u_128.HumanoidOffsetFromPath
					v_u_128.CurrentHumanoidVelocity = v_u_128.Humanoid.RootPart.Velocity
					v_u_128.SeatedConn = v_u_128.Humanoid.Seated:Connect(function(_, _)
						-- upvalues: (ref) v_u_128
						v_u_128:OnPathInterrupted()
					end)
					v_u_128.DiedConn = v_u_128.Humanoid.Died:Connect(function()
						-- upvalues: (ref) v_u_128
						v_u_128:OnPathInterrupted()
					end)
					if v_u_15 then
						v_u_128.lastPosition = v_u_128.Humanoid.RootPart.CFrame.Position
						v_u_128.TeleportedConn = v_u_128.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
							-- upvalues: (ref) v_u_128
							local v182 = v_u_128.Humanoid.RootPart.CFrame.Position
							local v183 = (v182 - v_u_128.lastPosition).Magnitude
							v_u_128.lastPosition = v182
							if v_u_128.Humanoid.WalkSpeed < v183 then
								v_u_128:OnPathInterrupted()
							end
						end)
					else
						v_u_128.TeleportedConn = v_u_128.Humanoid.RootPart:GetPropertyChangedSignal("CFrame"):Connect(function()
							-- upvalues: (ref) v_u_128
							v_u_128:OnPathInterrupted()
						end)
					end
					v_u_128.CurrentPoint = 1
					v_u_128:OnPointReached(true)
				else
					v_u_128.PathFailed:Fire()
					if v_u_128.stopTraverseFunc then
						v_u_128.stopTraverseFunc()
					end
				end
			end
		else
			v_u_128.PathFailed:Fire()
			return
		end
	end
	local v184 = v_u_128.TargetPoint + v_u_128.TargetSurfaceNormal * 1.5
	if v_u_14 then
		local v185 = v_u_28
		local v186
		if v_u_45 then
			v186 = v_u_45
		else
			v_u_45 = {}
			local v187 = v_u_45
			assert(v187, "")
			local v188 = v_u_45
			local v189 = v_u_26
			if v189 then
				v189 = v_u_26.Character
			end
			table.insert(v188, v189)
			v186 = v_u_45
		end
		v185.FilterDescendantsInstances = v186
		local v190 = v_u_10:Raycast(v184, Vector3.new(-0, -50, -0), v_u_28)
		if v190 then
			v_u_128.TargetPoint = v190.Position
		end
	else
		local v191 = Ray.new(v184, Vector3.new(0, -50, 0))
		local v192 = v_u_10
		local v193
		if v_u_45 then
			v193 = v_u_45
		else
			v_u_45 = {}
			local v194 = v_u_45
			assert(v194, "")
			local v195 = v_u_45
			local v196 = v_u_26
			if v196 then
				v196 = v_u_26.Character
			end
			table.insert(v195, v196)
			v193 = v_u_45
		end
		local v197, v198 = v192:FindPartOnRayWithIgnoreList(v191, v193)
		if v197 then
			v_u_128.TargetPoint = v198
		end
	end
	v_u_128:ComputePath()
	return v_u_128
end
local function v_u_202(p200) -- name: GetEquippedTool
	if p200 ~= nil then
		for _, v201 in pairs(p200:GetChildren()) do
			if not v201:IsA("Tool") then
				continue
			end
			return v201
		end
	end
end
local function v_u_211(p203) -- name: calculateLocalMoveVector
	-- upvalues: (copy) v_u_10
	local v204 = p203.X
	local v205 = p203.Z
	local v206 = Vector3.new(v204, 0, v205)
	if v206.Magnitude < 1e-6 then
		return Vector2.zero
	end
	local v207 = v206.Unit
	local v208 = v_u_10.CurrentCamera
	if not v208 then
		return Vector2.new(v207.X, -v207.Z)
	end
	local _, v209, _ = v208.CFrame:ToEulerAnglesYXZ()
	local v210 = CFrame.Angles(0, v209, 0):VectorToObjectSpace(v207)
	return Vector2.new(v210.X, -v210.Z)
end
local v_u_212 = {}
v_u_212.__index = v_u_212
function v_u_212.new(_) -- name: new
	-- upvalues: (copy) v_u_212, (copy) v_u_17
	local v213 = v_u_212
	local v214 = setmetatable({}, v213)
	v214.mouse2DownTime = tick()
	v214.mouse2DownPos = Vector2.new()
	v214.mouse2UpTime = tick()
	v214.humanoidDiedConn = nil
	v214.characterChildAddedConn = nil
	v214.onCharacterAddedConn = nil
	v214.characterChildRemovedConn = nil
	v214.renderSteppedConn = nil
	v214.menuOpenedConnection = nil
	v214.preferredInputChangedConnection = nil
	if not v_u_17 then
		v214.jumpEnabled = true
	end
	v214.clickPressedConn = nil
	v214.clickReleasedConn = nil
	v214.shouldCleanupPath = false
	v214.lastPatherJumped = false
	v214.data = nil
	v214.running = false
	return v214
end
local v_u_215 = nil
local v_u_216 = nil
local v_u_217 = nil
function v_u_212.CleanupPath(p218) -- name: CleanupPath
	-- upvalues: (ref) v_u_215, (ref) v_u_216, (ref) v_u_217
	if v_u_215 then
		v_u_215:Cancel()
		v_u_215 = nil
	end
	if v_u_216 then
		v_u_216:Disconnect()
		v_u_216 = nil
	end
	if v_u_217 then
		v_u_217:Disconnect()
		v_u_217 = nil
	end
	p218.shouldCleanupPath = true
end
function v_u_212.HandleMoveTo(p_u_219, p220, p_u_221, p_u_222, p_u_223, p_u_224) -- name: HandleMoveTo
	-- upvalues: (ref) v_u_215, (ref) v_u_216, (copy) v_u_202, (ref) v_u_217, (ref) v_u_22, (copy) v_u_27
	p_u_219.shouldCleanupPath = false
	if v_u_215 then
		p_u_219:CleanupPath()
	end
	v_u_215 = p220
	p220:Start(p_u_224)
	v_u_216 = p220.Finished.Event:Connect(function()
		-- upvalues: (copy) p_u_219, (copy) p_u_222, (ref) v_u_202, (copy) p_u_223
		p_u_219:CleanupPath()
		local v225 = p_u_222 and v_u_202(p_u_223)
		if v225 then
			v225:Activate()
		end
	end)
	v_u_217 = p220.PathFailed.Event:Connect(function()
		-- upvalues: (copy) p_u_219, (copy) p_u_224, (ref) v_u_22, (ref) v_u_215, (ref) v_u_27, (copy) p_u_221
		p_u_219:CleanupPath()
		if p_u_224 == nil or p_u_224 then
			local v226 = v_u_22
			if v226 then
				local v227 = v_u_215
				if v227 then
					v227 = v_u_215:IsActive()
				end
				v226 = not v227
			end
			if v226 then
				v_u_27.PlayFailureAnimation()
			end
			v_u_27.DisplayFailureWaypoint(p_u_221)
		end
	end)
end
function v_u_212.ShowPathFailedFeedback(_, p228) -- name: ShowPathFailedFeedback
	-- upvalues: (ref) v_u_215, (ref) v_u_22, (copy) v_u_27
	if v_u_215 and v_u_215:IsActive() then
		v_u_215:Cancel()
	end
	if v_u_22 then
		v_u_27.PlayFailureAnimation()
	end
	v_u_27.DisplayFailureWaypoint(p228)
end
function v_u_212.OnTap(p229, p230, p231) -- name: OnTap
	-- upvalues: (copy) v_u_10, (copy) v_u_26, (copy) v_u_44, (copy) v_u_14, (ref) v_u_45, (copy) v_u_28, (copy) v_u_199, (copy) v_u_29, (copy) v_u_202
	local v232 = v_u_10.CurrentCamera
	local v233 = v_u_26.Character
	local v234 = v_u_26
	local v235
	if v234 then
		v235 = v234.Character
	else
		v235 = v234
	end
	local v236
	if v235 then
		v236 = v_u_44[v234]
		if not v236 or v236.Parent ~= v235 then
			v_u_44[v234] = nil
			v236 = v235:FindFirstChildOfClass("Humanoid")
			if v236 then
				v_u_44[v234] = v236
			end
		end
	else
		v236 = nil
	end
	local v237
	if v236 == nil then
		v237 = false
	else
		v237 = v236.Health > 0
	end
	if v237 then
		if #p230 == 1 or p231 then
			if v232 then
				local v238 = v232:ScreenPointToRay(p230[1].X, p230[1].Y)
				if v_u_14 then
					local v239 = nil
					local v240
					if v_u_45 then
						v240 = v_u_45
					else
						v_u_45 = {}
						local v241 = v_u_45
						assert(v241, "")
						local v242 = v_u_45
						local v243 = v_u_26
						if v243 then
							v243 = v_u_26.Character
						end
						table.insert(v242, v243)
						v240 = v_u_45
					end
					if not v240 then
						v240 = {}
					end
					local v244 = true
					v_u_28.FilterDescendantsInstances = v240
					local v245 = v_u_10:Raycast(v238.Origin, v238.Direction * 1000, v_u_28)
					if v245 then
						local v246 = v245.Instance
						if not v246.CanCollide then
							while true do
								local v247 = v246:FindFirstChildOfClass("Humanoid")
								local v248 = v246.Parent
								if v247 or not v248 then
									break
								end
								v246 = v248
							end
							if v247 or not v248 then
								v239 = v246
							else
								table.insert(v240, v248)
								v244 = false
								v239 = nil
							end
						end
					end
					if not v244 then
						continue
					end
					if v245 and v233 then
						local v249 = v245.Position
						if p231 then
							v239 = nil
						else
							p231 = v249
						end
						p229:CleanupPath()
						local v250 = v_u_199(p231, v245.Normal)
						if v250:IsValidPath() then
							p229:HandleMoveTo(v250, p231, v239, v233)
						else
							v250:Cleanup()
							p229:ShowPathFailedFeedback(p231)
						end
					else
						return
					end
				end
				local v251 = Ray.new(v238.Origin, v238.Direction * 1000)
				local v252 = v_u_29.Raycast
				local v253 = true
				local v254
				if v_u_45 then
					v254 = v_u_45
				else
					v_u_45 = {}
					local v255 = v_u_45
					assert(v255, "")
					local v256 = v_u_45
					local v257 = v_u_26
					if v257 then
						v257 = v_u_26.Character
					end
					table.insert(v256, v257)
					v254 = v_u_45
				end
				local v258, v259, v260 = v252(v251, v253, v254)
				local v261, _ = v_u_29.FindCharacterAncestor(v258)
				if p231 then
					v261 = nil
				else
					p231 = v259
				end
				if p231 and v233 then
					p229:CleanupPath()
					local v262 = v_u_199(p231, v260)
					if v262:IsValidPath() then
						p229:HandleMoveTo(v262, p231, v261, v233)
					else
						v262:Cleanup()
						p229:ShowPathFailedFeedback(p231)
					end
				end
			end
		else
			local v263 = #p230 >= 2 and (v232 and v_u_202(v233))
			if v263 then
				v263:Activate()
			end
		end
	end
end
function v_u_212.DisconnectEvents(p264) -- name: DisconnectEvents
	local v265 = p264.humanoidDiedConn
	if v265 then
		v265:Disconnect()
	end
	local v266 = p264.characterChildAddedConn
	if v266 then
		v266:Disconnect()
	end
	local v267 = p264.onCharacterAddedConn
	if v267 then
		v267:Disconnect()
	end
	local v268 = p264.renderSteppedConn
	if v268 then
		v268:Disconnect()
	end
	local v269 = p264.characterChildRemovedConn
	if v269 then
		v269:Disconnect()
	end
	local v270 = p264.menuOpenedConnection
	if v270 then
		v270:Disconnect()
	end
	local v271 = p264.preferredInputChangedConnection
	if v271 then
		v271:Disconnect()
	end
	local v272 = p264.clickPressedConn
	if v272 then
		v272:Disconnect()
	end
	local v273 = p264.clickReleasedConn
	if v273 then
		v273:Disconnect()
	end
end
function v_u_212.OnPreferredInputChanged(_) -- name: OnPreferredInputChanged
	-- upvalues: (copy) v_u_26, (copy) v_u_7
	local v274 = v_u_26.Character
	if v274 then
		local v275 = v_u_7.PreferredInput == Enum.PreferredInput.Touch
		for _, v276 in pairs(v274:GetChildren()) do
			if not v276:IsA("Tool") then
				continue
			end
			v276.ManualActivationOnly = v275
		end
	end
end
function v_u_212.OnCharacterAdded(p_u_277, p278) -- name: OnCharacterAdded
	-- upvalues: (copy) v_u_19, (copy) v_u_12, (copy) v_u_20, (copy) v_u_16, (ref) v_u_215, (copy) v_u_7
	p_u_277:DisconnectEvents()
	p_u_277.clickPressedConn = v_u_19.Pressed:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_20, (ref) v_u_16, (copy) p_u_277
		local v279, _ = v_u_12:GetGuiInset()
		local v280 = v_u_20:GetState()
		if v280.X ~= -1 or v280.Y ~= -1 then
			local v281
			if v_u_16 then
				local v282 = v_u_12:GetInsetArea(Enum.ScreenInsets.None).Min
				v281 = Vector2.new(v280.X + v282.X, v280.Y + v282.Y)
			else
				v281 = Vector2.new(v280.X - v279.X, v280.Y - v279.Y)
			end
			p_u_277.mouse2DownPos = v281
			p_u_277.mouse2DownTime = tick()
		end
	end)
	p_u_277.clickReleasedConn = v_u_19.Released:Connect(function()
		-- upvalues: (copy) p_u_277, (ref) v_u_215
		p_u_277.mouse2UpTime = tick()
		local v283 = p_u_277.mouse2DownPos
		if p_u_277.data and p_u_277.data.actions.MoveAction then
			local v284 = v_u_215 or p_u_277.data.actions.MoveAction:GetState().Magnitude <= 0
			if p_u_277.mouse2UpTime - p_u_277.mouse2DownTime < 0.25 and v284 then
				p_u_277:OnTap({ v283 })
			end
		end
	end)
	p_u_277.menuOpenedConnection = v_u_12.MenuOpened:Connect(function()
		-- upvalues: (copy) p_u_277
		p_u_277:CleanupPath()
	end)
	local function v_u_287(p285) -- name: OnCharacterChildAdded
		-- upvalues: (ref) v_u_7, (copy) p_u_277
		if v_u_7.PreferredInput == Enum.PreferredInput.Touch and p285:IsA("Tool") then
			p285.ManualActivationOnly = true
		end
		if p285:IsA("Humanoid") then
			local v286 = p_u_277.humanoidDiedConn
			if v286 then
				v286:Disconnect()
			end
			p_u_277.humanoidDiedConn = p285.Died:Connect(function() end)
		end
	end
	p_u_277.characterChildAddedConn = p278.ChildAdded:Connect(function(p288)
		-- upvalues: (copy) v_u_287
		v_u_287(p288)
	end)
	p_u_277.characterChildRemovedConn = p278.ChildRemoved:Connect(function(p289)
		-- upvalues: (ref) v_u_7
		if v_u_7.PreferredInput == Enum.PreferredInput.Touch and p289:IsA("Tool") then
			p289.ManualActivationOnly = false
		end
	end)
	for _, v290 in pairs(p278:GetChildren()) do
		v_u_287(v290)
	end
	p_u_277.preferredInputChangedConnection = v_u_7:GetPropertyChangedSignal("PreferredInput"):Connect(function()
		-- upvalues: (copy) p_u_277
		p_u_277:OnPreferredInputChanged()
	end)
end
function v_u_212.Start(p291) -- name: Start
	p291:Enable(true)
end
function v_u_212.Stop(p292) -- name: Stop
	p292:Enable(false)
end
function v_u_212.Enable(p_u_293, p294, p295, p296) -- name: Enable
	-- upvalues: (copy) v_u_26, (copy) v_u_17, (copy) v_u_7, (copy) v_u_19, (copy) v_u_20
	if p294 then
		if not p_u_293.running then
			if v_u_26.Character then
				p_u_293:OnCharacterAdded(v_u_26.Character)
			end
			p_u_293.onCharacterAddedConn = v_u_26.CharacterAdded:Connect(function(p297)
				-- upvalues: (copy) p_u_293
				p_u_293:OnCharacterAdded(p297)
			end)
			p_u_293.running = true
		end
		if not v_u_17 then
			p_u_293.touchJumpController = p296
			if p_u_293.touchJumpController then
				p_u_293.touchJumpController:Enable(p_u_293.jumpEnabled)
			end
		end
	else
		if p_u_293.running then
			p_u_293:DisconnectEvents()
			p_u_293:CleanupPath()
			if v_u_7.PreferredInput == Enum.PreferredInput.Touch then
				local v298 = v_u_26.Character
				if v298 then
					for _, v299 in pairs(v298:GetChildren()) do
						if not v299:IsA("Tool") then
							continue
						end
						v299.ManualActivationOnly = false
					end
				end
			end
			p_u_293.running = false
		end
		if not v_u_17 then
			if p_u_293.touchJumpController and not p_u_293.jumpEnabled then
				p_u_293.touchJumpController:Enable(true)
			end
			p_u_293.touchJumpController = nil
		end
	end
	v_u_19.Enabled = p294
	v_u_20.Enabled = p294
	p_u_293.wasdEnabled = p294 and p295 and p295 or false
	p_u_293.enabled = p294
end
function v_u_212.Update(p300, p301, p302) -- name: Update
	-- upvalues: (ref) v_u_215, (copy) v_u_211
	local v303 = p301.actions.MoveAction
	assert(v303)
	local v304 = p301.actions.JumpAction
	assert(v304)
	if not p300.data then
		p300.data = p301
	end
	local v305 = v_u_215
	if v305 then
		v305:OnRenderStepped(p302)
		if v_u_215 and v_u_215 == v305 then
			local v306 = v_u_211(v305.NextActionMoveDirection)
			local v307 = p301.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
			if v307 then
				v307:Fire(v306)
			end
			p301.moveVector = v306
			if v305.NextActionJump then
				local v308 = p301.actions.JumpAction:GetState() ~= true and p301.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
				if v308 then
					v308:Fire(true)
				end
				p300.lastPatherJumped = true
				p301.isJumping = true
			elseif p300.lastPatherJumped then
				local v309 = p301.actions.JumpAction:GetState() == true and p301.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
				if v309 then
					v309:Fire(false)
				end
				p300.lastPatherJumped = false
				p301.isJumping = false
			end
		elseif p300.lastPatherJumped then
			local v310 = p301.actions.JumpAction:GetState() == true and p301.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
			if v310 then
				v310:Fire(false)
			end
			p300.lastPatherJumped = false
		end
	end
	if p300.shouldCleanupPath then
		p300.shouldCleanupPath = false
		local v311 = p301.actions.MoveAction:FindFirstChild("ClickToMoveScriptableBinding")
		if v311 then
			v311:Fire(Vector2.zero)
		end
		p301.moveVector = Vector2.zero
		p300.lastPatherJumped = false
		local v312 = p301.actions.JumpAction:FindFirstChild("ClickToMoveScriptableBinding")
		if v312 then
			v312:Fire(false)
		end
		p301.isJumping = false
	end
end
function v_u_212.SetShowPath(_, p313) -- name: SetShowPath
	-- upvalues: (ref) v_u_21
	v_u_21 = p313
end
function v_u_212.GetShowPath(_) -- name: GetShowPath
	-- upvalues: (ref) v_u_21
	return v_u_21
end
function v_u_212.SetWaypointTexture(_, p314) -- name: SetWaypointTexture
	-- upvalues: (copy) v_u_27
	v_u_27.SetWaypointTexture(p314)
end
function v_u_212.GetWaypointTexture(_) -- name: GetWaypointTexture
	-- upvalues: (copy) v_u_27
	return v_u_27.GetWaypointTexture()
end
function v_u_212.SetWaypointRadius(_, p315) -- name: SetWaypointRadius
	-- upvalues: (copy) v_u_27
	v_u_27.SetWaypointRadius(p315)
end
function v_u_212.GetWaypointRadius(_) -- name: GetWaypointRadius
	-- upvalues: (copy) v_u_27
	return v_u_27.GetWaypointRadius()
end
function v_u_212.SetEndWaypointTexture(_, p316) -- name: SetEndWaypointTexture
	-- upvalues: (copy) v_u_27
	v_u_27.SetEndWaypointTexture(p316)
end
function v_u_212.GetEndWaypointTexture(_) -- name: GetEndWaypointTexture
	-- upvalues: (copy) v_u_27
	return v_u_27.GetEndWaypointTexture()
end
function v_u_212.SetWaypointsAlwaysOnTop(_, p317) -- name: SetWaypointsAlwaysOnTop
	-- upvalues: (copy) v_u_27
	v_u_27.SetWaypointsAlwaysOnTop(p317)
end
function v_u_212.GetWaypointsAlwaysOnTop(_) -- name: GetWaypointsAlwaysOnTop
	-- upvalues: (copy) v_u_27
	return v_u_27.GetWaypointsAlwaysOnTop()
end
function v_u_212.SetFailureAnimationEnabled(_, p318) -- name: SetFailureAnimationEnabled
	-- upvalues: (ref) v_u_22
	v_u_22 = p318
end
function v_u_212.GetFailureAnimationEnabled(_) -- name: GetFailureAnimationEnabled
	-- upvalues: (ref) v_u_22
	return v_u_22
end
function v_u_212.SetIgnoredPartsTag(_, p319) -- name: SetIgnoredPartsTag
	-- upvalues: (copy) v_u_59
	v_u_59(p319)
end
function v_u_212.GetIgnoredPartsTag(_) -- name: GetIgnoredPartsTag
	-- upvalues: (ref) v_u_46
	return v_u_46
end
function v_u_212.SetUseDirectPath(_, p320) -- name: SetUseDirectPath
	-- upvalues: (ref) v_u_23
	v_u_23 = p320
end
function v_u_212.GetUseDirectPath(_) -- name: GetUseDirectPath
	-- upvalues: (ref) v_u_23
	return v_u_23
end
function v_u_212.SetAgentSizeIncreaseFactor(_, p321) -- name: SetAgentSizeIncreaseFactor
	-- upvalues: (ref) v_u_24
	v_u_24 = p321 / 100 + 1
end
function v_u_212.GetAgentSizeIncreaseFactor(_) -- name: GetAgentSizeIncreaseFactor
	-- upvalues: (ref) v_u_24
	return (v_u_24 - 1) * 100
end
function v_u_212.SetUnreachableWaypointTimeout(_, p322) -- name: SetUnreachableWaypointTimeout
	-- upvalues: (ref) v_u_25
	v_u_25 = p322
end
function v_u_212.GetUnreachableWaypointTimeout(_) -- name: GetUnreachableWaypointTimeout
	-- upvalues: (ref) v_u_25
	return v_u_25
end
if not v_u_17 then
	function v_u_212.SetUserJumpEnabled(p323, p324) -- name: SetUserJumpEnabled
		p323.jumpEnabled = p324
		if p323.touchJumpController then
			p323.touchJumpController:Enable(p324)
		end
	end
	function v_u_212.GetUserJumpEnabled(p325) -- name: GetUserJumpEnabled
		return p325.jumpEnabled
	end
end
function v_u_212.MoveTo(p326, p327, p328, p329) -- name: MoveTo
	-- upvalues: (copy) v_u_26, (copy) v_u_199
	local v330 = v_u_26.Character
	if v330 == nil then
		return false
	end
	local v331 = v_u_199(p327, Vector3.new(0, 1, 0), p329)
	if not (v331 and v331:IsValidPath()) then
		return false
	end
	p326:HandleMoveTo(v331, p327, nil, v330, p328)
	return true
end
return v_u_212