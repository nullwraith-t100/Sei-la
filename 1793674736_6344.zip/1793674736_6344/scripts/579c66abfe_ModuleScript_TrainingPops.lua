local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("MarketplaceService")
local v4 = game:GetService("Players")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("RunService")
local v_u_7 = game:GetService("TweenService")
local v_u_8 = game:GetService("Workspace")
local v_u_9 = require(script.Parent.Device)
local v_u_10 = require(script.Parent.Gamepad)
local v_u_11 = require(script.Parent.OfferLog)
local v_u_12 = require(script.Parent.Reveal)
local v_u_13 = require(script.Parent.Sfx)
local v_u_14 = require(script.Parent.State)
local v_u_15 = require(script.Parent.Store)
local v_u_16 = require(script.Parent.Tutorial)
local v_u_17 = require(script.Parent.Fx.Kit)
local v18 = v5.Shared
local v_u_19 = require(v18.Net)
local v_u_20 = require(v18.Config.Images)
local v_u_21 = require(v18.Config.Eyes)
local v_u_22 = require(v18.Config.TrainingPops)
local v_u_23 = require(v18.Config.Economy)
local v_u_24 = require(v18.Logic.Format)
local v25 = {}
local v_u_26 = v4.LocalPlayer
local v_u_27 = Enum.KeyCode.ButtonX
local v_u_28 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_29 = {
	["2"] = { Color3.fromRGB(69, 200, 255), Color3.fromRGB(0, 128, 255) },
	["3"] = { Color3.fromRGB(205, 110, 255), Color3.fromRGB(140, 50, 255) },
	["5"] = { Color3.fromRGB(255, 120, 170), Color3.fromRGB(235, 30, 90) },
	["10"] = { Color3.fromRGB(120, 255, 110), Color3.fromRGB(20, 185, 70) },
	["gold"] = { Color3.fromRGB(255, 230, 60), Color3.fromRGB(255, 160, 0) }
}
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = -1
local v_u_37 = nil
local v_u_38 = nil
local v_u_39 = (-1 / 0)
local function v_u_44() -- name: menuOpen
	-- upvalues: (ref) v_u_33, (ref) v_u_32
	for _, v40 in v_u_33:GetChildren() do
		if not (v40:IsA("GuiObject") and v40.Visible) then
			continue
		end
		return true
	end
	local v41 = v_u_32:FindFirstChild("Overlay")
	if v41 then
		for _, v42 in { "Hatch", "Spin" } do
			local v43 = v41:FindFirstChild(v42)
			if not (v43 and (v43:IsA("GuiObject") and v43.Visible)) then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_47() -- name: blockedBy
	-- upvalues: (copy) v_u_16, (copy) v_u_26, (copy) v_u_14, (copy) v_u_2, (copy) v_u_10, (copy) v_u_12, (copy) v_u_15, (ref) v_u_39, (copy) v_u_44
	if not v_u_16.known() or v_u_16.active() then
		return "tutorial"
	end
	if v_u_26:GetAttribute("ArcadeOpen") == true then
		return "arcade"
	end
	if v_u_26:GetAttribute("InWave") == true then
		return "wave"
	end
	if v_u_14.number("TrainSpot") <= 0 or v_u_14.number("TrainMult", 1) <= 1 then
		return "not training"
	end
	if v_u_2.MenuIsOpen then
		return "roblox menu"
	end
	if v_u_10.captured() then
		return "controller taken"
	end
	if v_u_12.active() then
		return "prize reveal"
	end
	local v45 = v_u_15.sincePrompt()
	local v46
	if v45 < 60 then
		v46 = v_u_39 < os.clock() - v45
	else
		v46 = false
	end
	return v46 and "purchase window" or (v_u_44() and "menu" or nil)
end
local v_u_48 = v_u_6:IsStudio()
local function v_u_68() -- name: blockers
	-- upvalues: (ref) v_u_34, (ref) v_u_32, (copy) v_u_26, (ref) v_u_31
	local v_u_49 = {}
	local v_u_50 = v_u_34.AbsolutePosition
	local v_u_51 = v_u_34.AbsoluteSize.X
	local v_u_52 = v_u_34.AbsoluteSize.Y
	local function v_u_58(p53, p54) -- name: add
		-- upvalues: (copy) v_u_50, (copy) v_u_49
		if p53.Visible and (p53.AbsoluteSize.X > 1 and p53.AbsoluteSize.Y > 1) then
			local v55 = p53.AbsolutePosition - v_u_50
			local v56 = v_u_49
			local v57 = {
				v55.X - p54,
				v55.Y - p54,
				v55.X + p53.AbsoluteSize.X + p54,
				v55.Y + p53.AbsoluteSize.Y + p54
			}
			table.insert(v56, v57)
		end
	end
	local function v_u_62(p59, p60) -- name: addTree
		-- upvalues: (copy) v_u_51, (copy) v_u_52, (copy) v_u_62, (copy) v_u_58
		if p59.Visible then
			if p59.AbsoluteSize.X >= v_u_51 * 0.8 and p59.AbsoluteSize.Y >= v_u_52 * 0.8 then
				if p60 < 3 then
					for _, v61 in p59:GetChildren() do
						if not v61:IsA("GuiObject") then
							continue
						end
						v_u_62(v61, p60 + 1)
					end
				end
			else
				v_u_58(p59, 10)
			end
		else
			return
		end
	end
	local v63 = {
		["Overlay"] = true,
		["Tutorial"] = true,
		["LeaveLines"] = true,
		["Notifications"] = true,
		["Pops"] = true
	}
	for _, v64 in v_u_32:GetChildren() do
		if not v64:IsA("GuiObject") or v63[v64.Name] then
			continue
		end
		v_u_62(v64, 0)
	end
	local v65 = v_u_26:FindFirstChildOfClass("PlayerGui")
	if v65 then
		for _, v66 in v65:GetChildren() do
			if not v66:IsA("ScreenGui") or (v66 == v_u_31 or not v66.Enabled) then
				continue
			end
			for _, v67 in v66:GetChildren() do
				if not v67:IsA("GuiObject") then
					continue
				end
				v_u_62(v67, 0)
			end
		end
	end
	return v_u_49
end
local function v_u_74(p69, p70, p71, p72) -- name: overlaps
	for _, v73 in p69 do
		if p70 + p72 <= v73[1] or (p70 - p72 >= v73[3] or (p71 + p72 <= v73[2] or p71 - p72 >= v73[4])) then
			continue
		end
		return true
	end
	return false
end
local function v_u_98(p75) -- name: spot
	-- upvalues: (ref) v_u_34, (copy) v_u_68, (copy) v_u_74, (ref) v_u_38
	local v76 = v_u_34.AbsoluteSize.X
	local v77 = v_u_34.AbsoluteSize.Y
	local v78 = p75 * 0.62
	local v79 = v_u_68()
	local v80 = v76 * 0.16
	local v81 = v78 + 8
	local v82 = math.max(v80, v81)
	local v83 = v76 * 0.84
	local v84 = v76 - v78 - 8
	local v85 = math.min(v83, v84)
	local v86 = v77 * 0.15
	local v87 = v78 + 8
	local v88 = math.max(v86, v87)
	local v89 = v77 * 0.6
	local v90 = v77 - v78 - 8
	local v91 = math.min(v89, v90)
	if v85 <= v82 or v91 <= v88 then
		return Vector2.new(v76 / 2, v77 * 0.3)
	end
	local v92 = {
		v76 * 0.42,
		v77 * 0.32,
		v76 * 0.58,
		v77 * 0.7
	}
	for v93 = 1, 40 do
		local v94 = v82 + math.random() * (v85 - v82)
		local v95 = v88 + math.random() * (v91 - v88)
		local v96 = not v_u_74(v79, v94, v95, v78)
		if v96 and v93 <= 25 then
			v96 = not v_u_74({ v92 }, v94, v95, v78 * 0.5)
			local v97 = v_u_38
			if v96 and v97 then
				v96 = (Vector2.new(v94, v95) - v97).Magnitude > p75 * 1.5
			end
		end
		if not v96 then
			continue
		end
		v_u_38 = Vector2.new(v94, v95)
		return Vector2.new(v94, v95)
	end
	return Vector2.new(v76 / 2, v77 * 0.28)
end
local function v_u_108(p99, p100, p101, p102, p103, p104, p105) -- name: label
	-- upvalues: (copy) v_u_28
	local v106 = Instance.new("TextLabel")
	v106.Name = p100
	v106.BackgroundTransparency = 1
	v106.AnchorPoint = Vector2.new(0.5, 0.5)
	v106.Size = p102
	v106.Position = p103
	v106.FontFace = v_u_28
	v106.TextScaled = true
	v106.RichText = true
	v106.Text = p101
	v106.TextColor3 = p104
	v106.ZIndex = p105
	local v107 = Instance.new("UIStroke")
	v107.Thickness = 0.09
	v107.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v107.Color = Color3.new(0, 0, 0)
	v107.Parent = v106
	v106.Parent = p99
	return v106
end
local v_u_109 = {
	["UICorner"] = true,
	["UIStroke"] = true,
	["StudPattern"] = true,
	["UIGradient"] = true
}
local function v_u_117(p110) -- name: packButton
	-- upvalues: (copy) v_u_109
	local v111 = p110:Clone()
	for _, v112 in v111:GetChildren() do
		if v_u_109[v112.Name] then
			continue
		end
		v112:Destroy()
	end
	for _, v113 in { "Ui-Frame", "Ui-Close" } do
		v111:SetAttribute(v113, nil)
	end
	v111.Name = "Bubble"
	v111.Visible = true
	v111.Rotation = 0
	v111.AnchorPoint = Vector2.new(0.5, 0.5)
	v111.Position = UDim2.fromScale(0.5, 0.5)
	v111.Size = UDim2.fromScale(1, 1)
	v111.Selectable = false
	v111:SetAttribute("Ui-Hover", "Expand")
	v111:SetAttribute("Ui-Hover-Rate", 1.1)
	v111:SetAttribute("Ui-Click", "In")
	local v114 = v111:FindFirstChildOfClass("UICorner")
	if v114 then
		v114.CornerRadius = UDim.new(0.5, 0)
	end
	local v115 = v111:FindFirstChild("StudPattern")
	if v115 and v115:IsA("ImageLabel") then
		local v116 = Instance.new("UICorner")
		v116.CornerRadius = UDim.new(0.5, 0)
		v116.Parent = v115
	end
	return v111
end
local function v_u_149(p118) -- name: build
	-- upvalues: (ref) v_u_32, (ref) v_u_34, (copy) v_u_9, (copy) v_u_98, (copy) v_u_29, (copy) v_u_21, (copy) v_u_14, (copy) v_u_17, (copy) v_u_117, (copy) v_u_20, (copy) v_u_108, (copy) v_u_15, (copy) v_u_22, (copy) v_u_10, (copy) v_u_27
	local v119 = v_u_32:FindFirstChild(p118.kind == "gold" and "Upgrade" or "Left")
	if v119 and p118.kind ~= "gold" then
		v119 = v119:FindFirstChild("Store")
	end
	if not (v119 and v119:IsA("GuiButton")) then
		return nil
	end
	local v120 = p118.kind
	local v121 = p118.mult
	local v122 = v_u_34.AbsoluteSize.Y
	local v123
	if v_u_9.touch() then
		local v124 = v122 * 0.2
		v123 = math.clamp(v124, 78, 150)
	else
		local v125 = v122 * 0.145
		v123 = math.clamp(v125, 72, 160)
	end
	if v120 == "gold" then
		v123 = v123 * 1.3
	elseif v121 >= 10 then
		v123 = v123 * 1.15
	end
	local v126 = v_u_98(v123)
	local v127
	if p118.kind == "gold" then
		v127 = v_u_29.gold
	else
		local v128 = v_u_29
		local v129 = p118.mult
		v127 = v128[tostring(v129)] or v_u_29["2"]
	end
	local v130 = Instance.new("Frame")
	v130.Name = "Bubble" .. p118.id
	v130.BackgroundTransparency = 1
	v130.AnchorPoint = Vector2.new(0.5, 0.5)
	v130.Position = UDim2.fromOffset(v126.X, v126.Y)
	v130.Size = UDim2.fromOffset(v123, v123)
	v130.ZIndex = 2
	local v131 = Instance.new("UIScale")
	v131.Name = "Show"
	v131.Scale = 0
	v131.Parent = v130
	local v132
	if p118.kind == "gold" then
		v132 = Color3.fromRGB(255, 205, 40)
	else
		local v133 = v_u_21.byId[v_u_14.string("Eye", v_u_21.STARTER)] or v_u_21.byId[v_u_21.STARTER]
		v132 = v_u_17.color(v133.color)
	end
	local v134 = Instance.new("ImageLabel")
	v134.Name = "Rays"
	v134.BackgroundTransparency = 1
	v134.Image = "rbxassetid://96427887277553"
	v134.ImageColor3 = v132:Lerp(Color3.new(1, 1, 1), 0.55)
	v134.ImageTransparency = 0.05
	v134.AnchorPoint = Vector2.new(0.5, 0.5)
	v134.Position = UDim2.fromScale(0.5, 0.5)
	v134.Size = UDim2.fromScale(2.7, 2.7)
	v134.ZIndex = 1
	v134.Parent = v130
	local v135 = Instance.new("Frame")
	v135.Name = "Halo"
	v135.BackgroundColor3 = v132
	v135.BackgroundTransparency = 0.45
	v135.AnchorPoint = Vector2.new(0.5, 0.5)
	v135.Position = UDim2.fromScale(0.5, 0.5)
	v135.Size = UDim2.fromScale(1.24, 1.24)
	v135.ZIndex = 1
	local v136 = Instance.new("UICorner")
	v136.CornerRadius = UDim.new(0.5, 0)
	v136.Parent = v135
	v135.Parent = v130
	local v137 = v_u_117(v119)
	local v138 = v137:FindFirstChildOfClass("UIGradient")
	if v138 then
		v138.Color = ColorSequence.new(v127[1], v127[2])
		v138.Rotation = 90
	else
		v137.BackgroundColor3 = v127[2]
	end
	v137.ZIndex = 2
	local v139 = Instance.new("UIAspectRatioConstraint")
	v139.AspectRatio = 1
	v139.Parent = v137
	local v140 = Instance.new("ImageLabel")
	v140.Name = "Icon"
	v140.BackgroundTransparency = 1
	v140.ScaleType = Enum.ScaleType.Fit
	v140.AnchorPoint = Vector2.new(0.5, 0.5)
	v140.ZIndex = 4
	v140.Parent = v137
	if p118.kind == "gold" then
		v140.Image = v_u_20.Icon.BoostChakra or v_u_20.Icon.Chakra
		v140.Size = UDim2.fromScale(0.46, 0.46)
		v140.Position = UDim2.fromScale(0.5, 0.5)
		v_u_108(v137, "Mult", "x" .. p118.mult .. "!", UDim2.fromScale(0.8, 0.3), UDim2.fromScale(0.5, 0.2), Color3.new(1, 1, 1), 6)
		v_u_108(v137, "For", "CHAKRA " .. p118.seconds .. "s", UDim2.fromScale(0.82, 0.15), UDim2.fromScale(0.5, 0.76), Color3.new(1, 1, 1), 6)
		local v141 = v_u_15.product(v_u_22.goldKey)
		local v142 = not v141 and 0 or v141.price
		local v143 = Instance.new("Frame")
		v143.Name = "Price"
		v143.AnchorPoint = Vector2.new(0.5, 0.5)
		v143.Position = UDim2.fromScale(0.5, 1.02)
		v143.Size = UDim2.fromScale(0.62, 0.22)
		v143.BackgroundColor3 = Color3.fromRGB(30, 26, 44)
		v143.ZIndex = 7
		local v144 = Instance.new("UICorner")
		v144.CornerRadius = UDim.new(0.5, 0)
		v144.Parent = v143
		local v145 = Instance.new("UIStroke")
		v145.Thickness = 2
		v145.Color = Color3.new(0, 0, 0)
		v145.Parent = v143
		v_u_108(v143, "Text", ("<font color=\"#5CFF6A\">%*</font>%*"):format(v_u_15.ROBUX, v142), UDim2.fromScale(0.86, 0.8), UDim2.fromScale(0.5, 0.5), Color3.new(1, 1, 1), 8)
		v143.Parent = v137
	else
		v140.Image = v_u_20.Icon.Chakra
		v140.Size = UDim2.fromScale(0.5, 0.5)
		v140.Position = UDim2.fromScale(0.5, 0.36)
		v_u_108(v137, "Mult", "x" .. p118.mult .. "!", UDim2.fromScale(0.86, 0.42), UDim2.fromScale(0.5, 0.7), Color3.new(1, 1, 1), 6)
	end
	local v146 = v_u_10.hint
	local v147 = v_u_27
	local v148 = v123 * 0.34
	v146(v137, v147, math.floor(v148), UDim2.new(1, -v123 * 0.06, 0, v123 * 0.06)).ZIndex = 9
	v137.Parent = v130
	v130.Parent = v_u_34
	return {
		["bubble"] = nil,
		["holder"] = nil,
		["button"] = nil,
		["show"] = nil,
		["rays"] = nil,
		["halo"] = nil,
		["up"] = false,
		["done"] = false,
		["born"] = nil,
		["moved"] = false,
		["bubble"] = p118,
		["holder"] = v130,
		["button"] = v137,
		["show"] = v131,
		["rays"] = v134,
		["halo"] = v135,
		["born"] = os.clock()
	}
end
local function v_u_171(p150, p151, p152, p153) -- name: burst
	-- upvalues: (ref) v_u_34, (copy) v_u_7
	local v_u_154 = Instance.new("Frame")
	v_u_154.Name = "Burst"
	v_u_154.BackgroundTransparency = 1
	v_u_154.Size = UDim2.fromScale(1, 1)
	v_u_154.ZIndex = 4
	v_u_154.Parent = v_u_34
	local v155 = Instance.new("Frame")
	v155.Name = "Ring"
	v155.BackgroundTransparency = 1
	v155.AnchorPoint = Vector2.new(0.5, 0.5)
	v155.Position = UDim2.fromOffset(p150.X, p150.Y)
	v155.Size = UDim2.fromOffset(p151, p151)
	v155.ZIndex = 5
	local v156 = Instance.new("UICorner")
	v156.CornerRadius = UDim.new(0.5, 0)
	v156.Parent = v155
	local v157 = Instance.new("UIStroke")
	local v158 = p151 * 0.07
	v157.Thickness = math.max(4, v158)
	v157.Color = p152
	v157.Parent = v155
	v155.Parent = v_u_154
	local v159 = {
		["Size"] = UDim2.fromOffset(p151 * 2.3, p151 * 2.3)
	}
	v_u_7:Create(v155, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v159):Play()
	v_u_7:Create(v157, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Transparency"] = 1,
		["Thickness"] = 1
	}):Play()
	local v160 = Instance.new("Frame")
	v160.Name = "Flash"
	v160.BackgroundColor3 = Color3.new(1, 1, 1)
	v160.BackgroundTransparency = 0.25
	v160.AnchorPoint = Vector2.new(0.5, 0.5)
	v160.Position = UDim2.fromOffset(p150.X, p150.Y)
	v160.Size = UDim2.fromOffset(p151 * 0.9, p151 * 0.9)
	v160.ZIndex = 4
	local v161 = Instance.new("UICorner")
	v161.CornerRadius = UDim.new(0.5, 0)
	v161.Parent = v160
	v160.Parent = v_u_154
	local v162 = {
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = UDim2.fromOffset(p151 * 1.4, p151 * 1.4)
	}
	v_u_7:Create(v160, TweenInfo.new(0.22, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v162):Play()
	for v163 = 1, 12 do
		local v164 = Instance.new("ImageLabel")
		v164.Name = "Shard"
		v164.BackgroundTransparency = 1
		v164.Image = p153
		local v165
		if v163 % 3 == 0 then
			v165 = Color3.new(1, 1, 1)
		else
			v165 = p152
		end
		v164.ImageColor3 = v165
		v164.AnchorPoint = Vector2.new(0.5, 0.5)
		local v166 = p151 * (0.16 + math.random() * 0.12)
		v164.Size = UDim2.fromOffset(v166, v166)
		v164.Position = UDim2.fromOffset(p150.X, p150.Y)
		v164.Rotation = math.random() * 360
		v164.ZIndex = 6
		v164.Parent = v_u_154
		local v167 = (v163 / 12 + math.random() * 0.06) * 3.141592653589793 * 2
		local v168 = p151 * (0.9 + math.random() * 0.6)
		local v169 = p150 + Vector2.new(math.cos(v167), (math.sin(v167))) * v168
		local v170 = {
			["Position"] = nil,
			["Rotation"] = nil,
			["Size"] = nil,
			["ImageTransparency"] = 1,
			["Position"] = UDim2.fromOffset(v169.X, v169.Y),
			["Rotation"] = v164.Rotation + (math.random() - 0.5) * 360,
			["Size"] = UDim2.fromOffset(v166 * 0.4, v166 * 0.4)
		}
		v_u_7:Create(v164, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), v170):Play()
	end
	task.delay(0.6, function()
		-- upvalues: (copy) v_u_154
		v_u_154:Destroy()
	end)
end
local function v_u_193(p172, p173, p174, p_u_175, p176) -- name: flyToCounter
	-- upvalues: (copy) v_u_108, (ref) v_u_34, (ref) v_u_37, (copy) v_u_7, (ref) v_u_32, (copy) v_u_6, (copy) v_u_13
	local v_u_177 = v_u_108(v_u_34, "Fly", p173, UDim2.fromOffset(p176 * 1.3, p176 * 0.55), UDim2.fromOffset(p_u_175.X, p_u_175.Y), p174, 10)
	local v_u_178 = Instance.new("UIScale")
	v_u_178.Scale = 0.4
	v_u_178.Parent = v_u_177
	v_u_37 = {
		["id"] = p172,
		["label"] = v_u_177
	}
	local v179 = Enum.EasingStyle.Back
	v_u_7:Create(v_u_178, TweenInfo.new(0.25, v179 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Scale"] = 1.35
	}):Play()
	local v_u_180 = v_u_32:FindFirstChild("Bottom")
	if v_u_180 then
		v_u_180 = v_u_180:FindFirstChild("Chakra")
	end
	if not v_u_180 or (not v_u_180:IsA("GuiObject") or v_u_180.AbsoluteSize.X <= 0) then
		v_u_180 = nil
	end
	local v181 = v_u_34.AbsolutePosition
	local v_u_182
	if v_u_180 then
		v_u_182 = v_u_180.AbsolutePosition + v_u_180.AbsoluteSize / 2 - v181
	else
		v_u_182 = Vector2.new(v_u_34.AbsoluteSize.X / 2, v_u_34.AbsoluteSize.Y * 0.9)
	end
	local v_u_183 = (p_u_175 + v_u_182) / 2 + Vector2.new(0, -v_u_34.AbsoluteSize.Y * 0.12)
	task.delay(0.35, function()
		-- upvalues: (copy) v_u_177, (ref) v_u_6, (copy) p_u_175, (copy) v_u_183, (copy) v_u_182, (copy) v_u_178, (copy) v_u_180, (ref) v_u_13, (ref) v_u_7
		if v_u_177.Parent then
			local v_u_184 = os.clock()
			local v_u_185 = nil
			v_u_185 = v_u_6.RenderStepped:Connect(function()
				-- upvalues: (copy) v_u_184, (ref) p_u_175, (ref) v_u_183, (ref) v_u_182, (ref) v_u_177, (ref) v_u_178, (ref) v_u_185, (ref) v_u_180, (ref) v_u_13, (ref) v_u_7
				local v186 = (os.clock() - v_u_184) / 0.55
				local v187 = math.clamp(v186, 0, 1)
				local v188 = v187 * v187
				local v189 = p_u_175:Lerp(v_u_183, v188):Lerp(v_u_183:Lerp(v_u_182, v188), v188)
				v_u_177.Position = UDim2.fromOffset(v189.X, v189.Y)
				v_u_178.Scale = 1.35 - v188 * 0.95
				if v187 >= 1 then
					v_u_185:Disconnect()
					local v190 = v_u_177:GetAttribute("Late") == true
					v_u_177:Destroy()
					if v_u_180 and not v190 then
						v_u_13.play("Gain", {
							["volume"] = 2.5,
							["pitch"] = 1.15
						})
						local v191 = v_u_180:FindFirstChild("PopLand")
						if not (v191 or v_u_180:FindFirstChildOfClass("UIScale")) then
							v191 = Instance.new("UIScale")
							v191.Name = "PopLand"
							v191.Parent = v_u_180
						end
						if v191 and v191:IsA("UIScale") then
							v191.Scale = 1.35
							local v192 = Enum.EasingStyle.Back
							v_u_7:Create(v191, TweenInfo.new(0.25, v192 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
								["Scale"] = 1
							}):Play()
						end
					end
				end
			end)
		end
	end)
end
local function v_u_199(p_u_194, p195) -- name: remove
	-- upvalues: (ref) v_u_35, (copy) v_u_1, (copy) v_u_7
	if p_u_194.done then
		return
	else
		p_u_194.done = true
		if v_u_35 == p_u_194 then
			v_u_35 = nil
			v_u_1:UnbindAction("TrainingPop")
		end
		if p195 == "tap" then
			v_u_7:Create(p_u_194.show, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1.3
			}):Play()
			v_u_7:Create(p_u_194.button, TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["BackgroundTransparency"] = 1
			}):Play()
			task.delay(0.12, function()
				-- upvalues: (copy) p_u_194
				p_u_194.holder:Destroy()
			end)
		else
			local v196 = p_u_194.show
			local v197 = Enum.EasingStyle.Back
			local v198 = Enum.EasingDirection.In
			v_u_7:Create(v196, TweenInfo.new(0.25, v197 or Enum.EasingStyle.Quad, v198 or Enum.EasingDirection.Out), {
				["Scale"] = 0
			}):Play()
			task.delay(0.26, function()
				-- upvalues: (copy) p_u_194
				p_u_194.holder:Destroy()
			end)
		end
	end
end
local function v_u_208(p200) -- name: take
	-- upvalues: (ref) v_u_34, (copy) v_u_29, (copy) v_u_199, (copy) v_u_13, (copy) v_u_171, (copy) v_u_20, (copy) v_u_15, (copy) v_u_22, (ref) v_u_30, (copy) v_u_193, (copy) v_u_24, (copy) v_u_23, (copy) v_u_14, (copy) v_u_26, (copy) v_u_17
	if p200.done or not p200.up then
		return
	else
		local v201 = p200.bubble
		local v202 = p200.holder.AbsoluteSize.X
		local v203 = p200.holder.AbsolutePosition + p200.holder.AbsoluteSize / 2 - v_u_34.AbsolutePosition
		local v204
		if v201.kind == "gold" then
			v204 = v_u_29.gold
		else
			local v205 = v_u_29
			local v206 = v201.mult
			v204 = v205[tostring(v206)] or v_u_29["2"]
		end
		v_u_199(p200, "tap")
		v_u_13.play("Gain", {
			["volume"] = 1.6,
			["pitch"] = 0.85
		})
		if v201.kind == "gold" then
			v_u_171(v203, v202, v204[1], v_u_20.Icon.BoostChakra or v_u_20.Icon.Chakra)
			v_u_15.buyProduct(v_u_22.goldKey, "GoldBubble")
		else
			v_u_30:FireServer("claim", v201.id)
			v_u_171(v203, v202, v204[1], v_u_20.Icon.Chakra)
			v_u_193(v201.id, "+" .. v_u_24.short(v201.mult * v_u_23.clickGain * v_u_14.number("PerSecond")), v204[1], v203, v202)
			local v207 = v_u_26.Character
			if v207 then
				v207 = v207:FindFirstChild("HumanoidRootPart")
			end
			if v207 and v207:IsA("BasePart") then
				v_u_17.burst("Sparkle", v207.Position, v204[1], 0.8)
			end
		end
	end
end
local function v_u_221(p209) -- name: arrive
	-- upvalues: (ref) v_u_35, (copy) v_u_1, (copy) v_u_7, (copy) v_u_149, (copy) v_u_208, (copy) v_u_27
	if type(p209) == "table" then
		local v210 = p209.id
		local v211 = p209.kind
		local v212 = p209.mult
		local v213 = p209.seconds
		local v214 = p209.expires
		if type(v210) == "number" and (v211 == "free" or v211 == "gold") and (type(v212) == "number" and (type(v213) == "number" and type(v214) == "number")) then
			local v_u_215 = v_u_35
			if v_u_215 and not v_u_215.done then
				v_u_215.done = true
				if v_u_35 == v_u_215 then
					v_u_35 = nil
					v_u_1:UnbindAction("TrainingPop")
				end
				local v216 = v_u_215.show
				local v217 = Enum.EasingStyle.Back
				local v218 = Enum.EasingDirection.In
				v_u_7:Create(v216, TweenInfo.new(0.25, v217 or Enum.EasingStyle.Quad, v218 or Enum.EasingDirection.Out), {
					["Scale"] = 0
				}):Play()
				task.delay(0.26, function()
					-- upvalues: (copy) v_u_215
					v_u_215.holder:Destroy()
				end)
			end
			local v_u_219 = v_u_149({
				["id"] = v210,
				["kind"] = v211,
				["mult"] = v212,
				["seconds"] = v213,
				["expires"] = v214
			})
			if v_u_219 then
				v_u_219.button.Activated:Connect(function()
					-- upvalues: (ref) v_u_208, (copy) v_u_219
					v_u_208(v_u_219)
				end)
				v_u_1:BindActionAtPriority("TrainingPop", function(_, p220, _)
					-- upvalues: (ref) v_u_35, (ref) v_u_208
					if p220 ~= Enum.UserInputState.Begin then
						return Enum.ContextActionResult.Pass
					end
					if not (v_u_35 and v_u_35.up) then
						return Enum.ContextActionResult.Pass
					end
					v_u_208(v_u_35)
					return Enum.ContextActionResult.Sink
				end, false, Enum.ContextActionPriority.High.Value + 50, v_u_27)
				v_u_35 = v_u_219
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_248() -- name: frame
	-- upvalues: (ref) v_u_35, (copy) v_u_8, (copy) v_u_1, (copy) v_u_7, (copy) v_u_47, (copy) v_u_48, (copy) v_u_26, (copy) v_u_98, (copy) v_u_13, (ref) v_u_36, (copy) v_u_11, (copy) v_u_22
	local v_u_222 = v_u_35
	if v_u_222 and not v_u_222.done then
		local v223 = v_u_222.bubble.expires - v_u_8:GetServerTimeNow()
		if v223 <= 0 then
			if not v_u_222.done then
				v_u_222.done = true
				if v_u_35 == v_u_222 then
					v_u_35 = nil
					v_u_1:UnbindAction("TrainingPop")
				end
				local v224 = v_u_222.show
				local v225 = Enum.EasingStyle.Back
				local v226 = Enum.EasingDirection.In
				v_u_7:Create(v224, TweenInfo.new(0.25, v225 or Enum.EasingStyle.Quad, v226 or Enum.EasingDirection.Out), {
					["Scale"] = 0
				}):Play()
				task.delay(0.26, function()
					-- upvalues: (copy) v_u_222
					v_u_222.holder:Destroy()
				end)
			end
		else
			local v227 = v_u_47()
			if v_u_48 then
				v_u_26:SetAttribute("DevPopsBlocked", v227 or "")
			end
			local v228 = v227 ~= nil
			if v228 then
				v_u_222.moved = true
				v_u_222.freeAt = nil
			end
			if v228 and v_u_222.up then
				v_u_222.up = false
				local v229 = v_u_222.show
				local v230 = Enum.EasingStyle.Back
				local v231 = Enum.EasingDirection.In
				v_u_7:Create(v229, TweenInfo.new(0.15, v230 or Enum.EasingStyle.Quad, v231 or Enum.EasingDirection.Out), {
					["Scale"] = 0
				}):Play()
			elseif not (v228 or v_u_222.up) then
				if v_u_222.moved then
					local v232 = os.clock()
					local v233 = v_u_222.freeAt or v232
					v_u_222.freeAt = v233
					if v232 - v233 < 0.35 then
						return
					end
					v_u_222.moved = false
					local v234 = v_u_98(v_u_222.holder.Size.X.Offset)
					v_u_222.holder.Position = UDim2.fromOffset(v234.X, v234.Y)
				end
				v_u_222.up = true
				v_u_222.show.Scale = 0
				local v235 = v_u_222.show
				local v236 = Enum.EasingStyle.Back
				v_u_7:Create(v235, TweenInfo.new(0.45, v236 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
				if v_u_222.bubble.kind == "gold" then
					v_u_13.play("Reveal", {
						["volume"] = 0.9
					})
					if v_u_36 ~= v_u_222.bubble.id then
						v_u_36 = v_u_222.bubble.id
						v_u_11.shown("GoldBubble", "product", v_u_22.goldKey)
					end
				else
					local v237 = v_u_13.play
					local v238 = {
						["volume"] = 1.2,
						["pitch"] = nil
					}
					local v239 = 1 + (v_u_222.bubble.mult - 2) * 0.08
					v238.pitch = math.min(v239, 1.4)
					v237("Coin", v238)
				end
			end
			if v_u_222.up then
				local v240 = os.clock() - v_u_222.born
				v_u_222.rays.Rotation = v240 * 50 % 360
				local v241 = v_u_222.button
				local v242 = v240 * 3.1
				v241.Rotation = math.sin(v242) * 6
				local v243 = v240 * 7
				local v244 = (math.sin(v243) + 1) / 2
				local v245 = v_u_222.halo
				v245.Size = UDim2.fromScale(v244 * 0.12 + 1.16, v244 * 0.12 + 1.16)
				v245.BackgroundTransparency = v244 * 0.3 + 0.35
				if v223 < 1.5 then
					local v246 = v240 * 8
					local v247 = math.floor(v246) % 2 == 1
					v_u_222.rays.ImageTransparency = v247 and 0.7 or 0.05
					v245.BackgroundTransparency = v247 and 0.9 or 0.35
				end
			end
		end
	else
		return
	end
end
local function v_u_269() -- name: bindTimers
	-- upvalues: (ref) v_u_32, (copy) v_u_20, (copy) v_u_7, (copy) v_u_14
	local v_u_249 = v_u_32:WaitForChild("Boosts", 10)
	local v_u_250
	if v_u_249 then
		v_u_250 = v_u_249:FindFirstChild("chakra")
	else
		v_u_250 = v_u_249
	end
	if v_u_249 and (v_u_250 and v_u_250:IsA("GuiObject")) then
		local v258, v259, v260 = (function(p251, p252, p253) -- name: pill
			-- upvalues: (copy) v_u_250, (copy) v_u_249
			local v254 = v_u_250:Clone()
			v254.Name = p251
			v254.Visible = false
			local v255 = v254:FindFirstChild("Icon")
			if v255 and v255:IsA("ImageLabel") then
				v255.Image = p252
			end
			local v256 = v254:FindFirstChild("Text")
			if not (v256 and v256:IsA("TextLabel")) then
				v256 = nil
			end
			if v256 then
				v256.TextColor3 = p253
			end
			local v257 = Instance.new("UIScale")
			v257.Name = "Pop"
			v257.Parent = v254
			v254.Parent = v_u_249
			return v254, v256, v257
		end)("chakra50", v_u_20.Icon.BoostChakra or v_u_20.Icon.Chakra, Color3.fromRGB(255, 215, 60))
		local function v265(p261, p262, p263) -- name: appear
			-- upvalues: (ref) v_u_7
			if p263 and not p261.Visible then
				p261.Visible = true
				p262.Scale = 0.3
				local v264 = Enum.EasingStyle.Back
				v_u_7:Create(p262, TweenInfo.new(0.35, v264 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			elseif not p263 then
				p261.Visible = false
			end
		end
		while v_u_249.Parent do
			local v266 = v_u_14.boostLeft("chakra50")
			v265(v258, v260, v266 > 0)
			if v266 > 0 and v259 then
				local v267 = math.ceil(v266)
				local v268 = math.max(v267, 0)
				v259.Text = "x50 Chakra " .. string.format("%d:%02d", v268 // 60, v268 % 60)
			end
			task.wait(0.2)
		end
	end
end
function v25.start() -- name: start
	-- upvalues: (ref) v_u_30, (copy) v_u_19, (copy) v_u_26, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (ref) v_u_34, (copy) v_u_3, (ref) v_u_39, (copy) v_u_221, (ref) v_u_37, (copy) v_u_24, (copy) v_u_6, (copy) v_u_248, (copy) v_u_269
	v_u_30 = v_u_19.event("Pops")
	v_u_31 = v_u_26:WaitForChild("PlayerGui"):WaitForChild("Main")
	v_u_32 = v_u_31:WaitForChild("HUD")
	v_u_33 = v_u_31:WaitForChild("Frames")
	local v270 = Instance.new("Frame")
	v270.Name = "Pops"
	v270.BackgroundTransparency = 1
	v270.Active = false
	v270.Size = UDim2.fromScale(1, 1)
	v270.ZIndex = 20
	v270.Parent = v_u_32
	v_u_34 = v270
	v_u_3.PromptProductPurchaseFinished:Connect(function()
		-- upvalues: (ref) v_u_39
		v_u_39 = os.clock()
	end)
	v_u_3.PromptGamePassPurchaseFinished:Connect(function()
		-- upvalues: (ref) v_u_39
		v_u_39 = os.clock()
	end)
	v_u_30.OnClientEvent:Connect(function(p271, p272)
		-- upvalues: (ref) v_u_221, (ref) v_u_37, (ref) v_u_24
		if p271 == "bubble" then
			v_u_221(p272)
		elseif p271 == "paid" and type(p272) == "table" then
			local v273 = v_u_37
			if v273 and v273.id == p272.id then
				local v274 = p272.amount
				if type(v274) == "number" and v273.label.Parent then
					v273.label.Text = "+" .. v_u_24.short(p272.amount)
					return
				end
			end
		elseif p271 == "late" then
			local v275 = v_u_37
			if v275 and (v275.id == p272 and v275.label.Parent) then
				v275.label:SetAttribute("Late", true)
				v275.label.TextColor3 = Color3.fromRGB(150, 150, 150)
				v275.label.Text = "Too late!"
			end
		end
	end)
	v_u_6.RenderStepped:Connect(v_u_248)
	task.spawn(v_u_269)
end
return v25