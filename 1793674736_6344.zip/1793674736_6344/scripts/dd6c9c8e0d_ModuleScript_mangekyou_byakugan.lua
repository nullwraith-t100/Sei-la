local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v2.Shared.Config.Textures)
local v_u_5 = Color3.fromRGB(252, 250, 255)
local v_u_6 = Color3.fromRGB(176, 158, 255)
local function v_u_12(p7, p8) -- name: facing
	local v9 = p8.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p8.Unit
	local v10 = v9.Y
	local v11 = math.abs(v10) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p7, p7 + v9, v11) * CFrame.Angles(-1.5707963267948966, 0, 0)
end
local v_u_13 = {
	{
		["far"] = 2.5,
		["high"] = -1.7,
		["speed"] = 1.9,
		["phase"] = 0,
		["eye"] = true
	},
	{
		["far"] = 3.4,
		["high"] = -0.6,
		["speed"] = 1.45,
		["phase"] = 2.1,
		["eye"] = false
	},
	{
		["far"] = 2.8,
		["high"] = 0.5,
		["speed"] = 2.2,
		["phase"] = 4,
		["eye"] = false
	},
	{
		["far"] = 3.7,
		["high"] = 1.4,
		["speed"] = 1.3,
		["phase"] = 1,
		["eye"] = true
	},
	{
		["far"] = 2.4,
		["high"] = 2.3,
		["speed"] = 2.5,
		["phase"] = 3.1,
		["eye"] = false
	},
	{
		["far"] = 3.1,
		["high"] = -2.5,
		["speed"] = 1.7,
		["phase"] = 5.2,
		["eye"] = false
	},
	{
		["far"] = 2.9,
		["high"] = 3.1,
		["speed"] = 1.6,
		["phase"] = 0.6,
		["eye"] = true
	}
}
return function(p_u_14)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_1, (copy) v_u_6, (copy) v_u_4, (copy) v_u_13, (copy) v_u_12
	return {
		["w5_mangekyou_byakugan"] = function(p_u_15, p16)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (ref) v_u_1, (copy) p_u_14, (ref) v_u_6, (ref) v_u_4, (ref) v_u_13, (ref) v_u_12
			local v17 = v_u_3.color(p16.color)
			local v_u_18 = v_u_3.color(p16.color2)
			local v19 = p_u_15.headY / 1.5
			local v_u_20 = math.clamp(v19, 0.7, 3)
			local v_u_21 = -10
			local function v_u_46(p22) -- name: look
				-- upvalues: (copy) p_u_15, (ref) v_u_3, (copy) v_u_20, (ref) v_u_5, (ref) v_u_1, (copy) v_u_18, (ref) p_u_14, (ref) v_u_6, (ref) v_u_4
				local v23 = p_u_15.fx
				local v24 = p22.Position + Vector3.new(0, 1, 0) * p_u_15.headY
				local v25 = v_u_3.part(Vector3.new(2, 2, 2) * v_u_20, CFrame.new(v24), v_u_5, {
					["shape"] = nil,
					["transparency"] = 0.82,
					["shape"] = Enum.PartType.Ball
				})
				v_u_3.tween(v25, 0.6, {
					["Size"] = nil,
					["Transparency"] = 1,
					["Size"] = Vector3.new(16, 16, 16) * v23
				})
				v_u_1:AddItem(v25, 0.65)
				local v26 = p22.Position + Vector3.new(-0, -0.2, -0) * v_u_20
				local v27 = p22.LookVector.Z
				local v28 = p22.LookVector.X
				local v29 = math.atan2(v27, v28)
				for v30 = 0, 11 do
					local v31 = v30 * 3.141592653589793 / 6 + v29
					local v32 = math.cos(v31)
					local v33 = math.sin(v31)
					local v34 = Vector3.new(v32, 0, v33)
					local v35 = v26 + v34 * 1.2 * v_u_20
					local v36 = v_u_3.part
					local v37 = Vector3.new(0.35, 0.35, 1.4) * v_u_20
					local v38 = CFrame.lookAt(v35, v35 + v34)
					local v39
					if v30 % 2 == 0 then
						v39 = v_u_5
					else
						v39 = v_u_18
					end
					local v40 = {}
					local v41
					if v30 % 2 == 0 then
						v41 = Enum.Material.Neon
					else
						v41 = Enum.Material.SmoothPlastic
					end
					v40.material = v41
					local v42 = v36(v37, v38, v39, v40)
					local v43 = v_u_3.tween
					local v44 = {
						["CFrame"] = nil,
						["Size"] = nil,
						["Transparency"] = 1,
						["CFrame"] = CFrame.lookAt(v35 + v34 * 2.6 * v23, v35 + v34 * 4 * v23)
					}
					local v45 = 3.4 * v23
					v44.Size = Vector3.new(0.06, 0.06, v45)
					v43(v42, 0.4, v44)
					v_u_1:AddItem(v42, 0.45)
				end
				v_u_3.ring(p_u_14.feetAt(p_u_15, p22, 0.15), v_u_6, 6 * v23, 0.55, v_u_4.Ring)
			end
			p_u_14.throb(p_u_15, 4, 1.6, 2.5, function(p47)
				-- upvalues: (ref) v_u_21, (copy) v_u_46
				v_u_21 = os.clock()
				v_u_46(p47)
			end)
			local v_u_48 = v_u_21
			for _, v_u_49 in v_u_13 do
				local v50 = p_u_14.ball((v_u_49.eye and 0.36 or 0.28) * v_u_20, v_u_5, 0)
				p_u_14.add(p_u_15, v50, function(p51, p52)
					-- upvalues: (copy) v_u_49, (copy) v_u_20
					local v53 = CFrame.new
					local v54 = v_u_49.phase + p52 * v_u_49.speed
					local v55 = p51.Position
					local v56 = math.cos(v54) * v_u_49.far
					local v57 = v_u_49.high
					local v58 = p52 * 0.9 + v_u_49.phase
					local v59 = v57 + math.sin(v58) * 0.15
					local v60 = math.sin(v54) * v_u_49.far
					return v53(v55 + Vector3.new(v56, v59, v60) * v_u_20)
				end)
				p_u_14.tail(v50, v_u_5, v17:Lerp(v_u_6, 0.6), (v_u_49.eye and 0.42 or 0.28) * v_u_20, 1)
				local v_u_61 = (v_u_49.eye and 1.25 or 0.9) * v_u_20
				local v62 = p_u_14.picture
				local v63
				if v_u_49.eye then
					v63 = v_u_4.ByakuStar
				else
					v63 = v_u_4.PetStar
				end
				local v_u_64 = v62(v_u_61, v63, v17, 0)
				local v_u_65 = (v_u_49.eye and 1.2 or -2) + v_u_49.speed
				p_u_14.add(p_u_15, v_u_64, function(p66, p67)
					-- upvalues: (copy) v_u_49, (copy) v_u_20, (ref) p_u_14, (ref) v_u_48, (copy) v_u_64, (copy) v_u_61, (ref) v_u_12, (copy) v_u_65
					local v68 = v_u_49.phase + p67 * v_u_49.speed
					local v69 = p66.Position
					local v70 = math.cos(v68) * v_u_49.far
					local v71 = v_u_49.high
					local v72 = p67 * 0.9 + v_u_49.phase
					local v73 = v71 + math.sin(v72) * 0.15
					local v74 = math.sin(v68) * v_u_49.far
					local v75 = v69 + Vector3.new(v70, v73, v74) * v_u_20
					local v76 = p_u_14.camPos() - v75
					local v77 = v76.Magnitude < 0.01 and Vector3.new(0, 0, 1) or v76
					local v78 = 1 - (os.clock() - v_u_48) / 0.5
					local v79 = math.max(v78, 0)
					local v80 = v_u_64
					local v81 = v_u_61 * (v79 * 0.8 + 1)
					local v82 = v_u_61 * (v79 * 0.8 + 1)
					v80.Size = Vector3.new(v81, 0.05, v82)
					return v_u_12(v75 + v77.Unit * 0.25 * v_u_20, v77) * CFrame.Angles(0, p67 * v_u_65, 0)
				end)
			end
			p_u_14.particles(p_u_15, "AuraMode", v_u_6, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_14.particles(p_u_15, "Petals", v_u_5, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end