return {
	["can"] = function(p1) -- name: can
		if p1.held or (p1.never or (not p1.exists or p1.randomBlocked)) then
			return false
		end
		if p1.credits > 0 then
			return true
		end
		local v2 = p1.giftId ~= 0 and not p1.soldOut
		if v2 then
			v2 = not p1.retired
		end
		return v2
	end,
	["titles"] = function(p_u_3) -- name: titles
		local v4 = {}
		for v5 in p_u_3 do
			table.insert(v4, v5)
		end
		table.sort(v4, function(p6, p7)
			-- upvalues: (copy) p_u_3
			local v8 = p_u_3[p6]
			local v9 = p_u_3[p7]
			if v8.order == v9.order then
				if v8.title == v9.title then
					return p6 < p7
				else
					return v8.title
				end
			else
				return v8.order < v9.order
			end
		end)
		local v10 = {}
		local v11 = nil
		for _, v12 in v4 do
			local v13 = p_u_3[v12]
			if v13.title then
				v10[v12] = false
				v11 = v12
			else
				if not (v13.shown and v11) then
					continue
				end
				v10[v11] = true
			end
		end
		return v10
	end,
	["label"] = function(p14) -- name: label
		return "GIFTING TO: " .. p14
	end
}