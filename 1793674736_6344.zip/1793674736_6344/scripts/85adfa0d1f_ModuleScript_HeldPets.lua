return {
	["sort"] = function(p1, p2, p3, p4, p5) -- name: sort
		for v6, v7 in p3 do
			local v8
			if type(v7) == "table" then
				v8 = v7.kind
			else
				v8 = nil
			end
			if type(v8) == "string" then
				if not p4(v8) then
					continue
				end
				local v9 = v7.tier
				local v10
				if p1[v6] == nil then
					v10 = v6
				else
					v10 = tostring(p5)
					p5 = p5 + 1
				end
				p1[v10] = v8
				if type(v9) == "number" then
					p2[v10] = v9
				end
				p3[v6] = nil
			else
				p3[v6] = nil
			end
		end
		for v11, v12 in p1 do
			if p4(v12) then
				continue
			end
			p3[v11] = {
				["kind"] = v12,
				["tier"] = p2[v11]
			}
			p1[v11] = nil
			p2[v11] = nil
		end
		return p5
	end
}