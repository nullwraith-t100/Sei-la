local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v_u_2.Shared.Config.Textures)
local v_u_6 = {}
local v_u_7 = {}
function v_u_6.color(p8) -- name: color
	-- upvalues: (copy) v_u_7
	local v9 = v_u_7[p8]
	if not v9 then
		v9 = Color3.fromHex(p8)
		v_u_7[p8] = v9
	end
	return v9
end
local v_u_10 = nil
function v_u_6.folder() -- name: folder
	-- upvalues: (ref) v_u_10, (copy) v_u_4
	if v_u_10 and v_u_10.Parent then
		return v_u_10
	end
	local v11 = Instance.new("Folder")
	v11.Name = "ClientFx"
	v11.Parent = v_u_4
	v_u_10 = v11
	return v11
end
local function v_u_20(p12, p13) -- name: scaleSequence
	local v14 = {}
	for _, v15 in p12.Keypoints do
		local v16 = NumberSequenceKeypoint.new
		local v17 = v15.Time
		local v18 = v15.Value * p13
		local v19 = v15.Envelope * p13
		table.insert(v14, v16(v17, v18, v19))
	end
	return NumberSequence.new(v14)
end
local function v_u_27(p21, p22, p23, p24) -- name: prepare
	-- upvalues: (copy) v_u_20
	for _, v25 in p21:GetDescendants() do
		if not v25:IsA("ParticleEmitter") then
			continue
		end
		if p22 and v25:GetAttribute("Tint") == true then
			v25.Color = ColorSequence.new(p22)
			if p24 then
				local v26 = v25.LightEmission
				v25.LightEmission = math.min(v26, p24)
			end
		end
		if p23 == 1 then
			continue
		end
		v25.Size = v_u_20(v25.Size, p23)
		v25.Speed = NumberRange.new(v25.Speed.Min * p23, v25.Speed.Max * p23)
	end
end
function v_u_6.burst(p28, p29, p30, p31, p32) -- name: burst
	-- upvalues: (copy) v_u_2, (copy) v_u_27, (copy) v_u_4, (copy) v_u_1
	local v33 = v_u_2:FindFirstChild("Fx")
	if v33 then
		v33 = v33:FindFirstChild(p28)
	end
	if v33 and v33:IsA("Attachment") then
		local v34 = v33:Clone()
		v_u_27(v34, p30, p31 or 1)
		if p32 then
			v34.Parent = p32
		else
			v34.WorldPosition = p29
			v34.Parent = v_u_4.Terrain
		end
		for _, v_u_35 in v34:GetDescendants() do
			if not v_u_35:IsA("ParticleEmitter") then
				continue
			end
			local v36 = v_u_35:GetAttribute("Emit")
			if type(v36) == "number" then
				v_u_35.Enabled = false
				v_u_35:Emit(v36)
			else
				v_u_35.Enabled = true
				task.delay(0.15, function()
					-- upvalues: (copy) v_u_35
					v_u_35.Enabled = false
				end)
			end
		end
		local v37 = v34:GetAttribute("Life")
		v_u_1:AddItem(v34, (type(v37) ~= "number" and 2 or v37) + 0.5)
	end
end
function v_u_6.loop(p38, p39, p40, p41, p42, p43) -- name: loop
	-- upvalues: (copy) v_u_2, (copy) v_u_27, (copy) v_u_1
	local v44 = v_u_2:FindFirstChild("Fx")
	if v44 then
		v44 = v44:FindFirstChild(p38)
	end
	if not (v44 and v44:IsA("Attachment")) then
		return function() end
	end
	local v_u_45 = v44:Clone()
	v_u_27(v_u_45, p40, p41 or 1, p42)
	v_u_45.Parent = p39
	for _, v46 in v_u_45:GetDescendants() do
		if not v46:IsA("ParticleEmitter") then
			continue
		end
		if p43 and p43 ~= 1 then
			v46.Rate = v46.Rate * p43
		end
		local v47 = v46:GetAttribute("Emit")
		if type(v47) == "number" then
			v46:Emit(v47)
		else
			v46.Enabled = true
		end
	end
	local v_u_48 = false
	return function()
		-- upvalues: (ref) v_u_48, (copy) v_u_45, (ref) v_u_1
		if not v_u_48 then
			v_u_48 = true
			for _, v49 in v_u_45:GetDescendants() do
				if not v49:IsA("ParticleEmitter") then
					continue
				end
				v49.Enabled = false
			end
			v_u_1:AddItem(v_u_45, 2)
		end
	end
end
function v_u_6.loopAt(p50, p51, p52, p53) -- name: loopAt
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_1
	local v_u_54 = Instance.new("Attachment")
	v_u_54.WorldPosition = p51
	v_u_54.Parent = v_u_4.Terrain
	local v_u_55 = v_u_6.loop(p50, v_u_54, p52, p53)
	return function()
		-- upvalues: (copy) v_u_55, (ref) v_u_1, (copy) v_u_54
		v_u_55()
		v_u_1:AddItem(v_u_54, 2.2)
	end
end
function v_u_6.part(p56, p57, p58, p59) -- name: part
	-- upvalues: (copy) v_u_6
	local v60 = Instance.new("Part")
	v60.Anchored = true
	v60.CanCollide = false
	v60.CanQuery = false
	v60.CanTouch = false
	v60.CastShadow = false
	v60.Size = p56
	v60.CFrame = p57
	v60.Color = p58
	v60.Material = p59 and p59.material or Enum.Material.Neon
	v60.Transparency = p59 and (p59.transparency or 0) or 0
	if p59 and p59.shape then
		v60.Shape = p59.shape
	end
	v60.TopSurface = Enum.SurfaceType.Smooth
	v60.BottomSurface = Enum.SurfaceType.Smooth
	v60.Parent = v_u_6.folder()
	return v60
end
function v_u_6.tween(p61, p62, p63, p64, p65) -- name: tween
	-- upvalues: (copy) v_u_3
	local v66 = v_u_3:Create(p61, TweenInfo.new(p62, p64 or Enum.EasingStyle.Quad, p65 or Enum.EasingDirection.Out), p63)
	v66:Play()
	return v66
end
function v_u_6.flash(p67, p68, p69, p70) -- name: flash
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	local v71 = p70 or 0.25
	local v72 = v_u_6.part(Vector3.new(1, 1, 1) * p69 * 0.3, CFrame.new(p67), p68, {
		["shape"] = nil,
		["transparency"] = 0.35,
		["shape"] = Enum.PartType.Ball
	})
	v_u_6.tween(v72, v71, {
		["Size"] = nil,
		["Transparency"] = 1,
		["Size"] = Vector3.new(1, 1, 1) * p69
	})
	v_u_1:AddItem(v72, v71 + 0.05)
end
function v_u_6.ring(p73, p74, p75, p76, p77) -- name: ring
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_1
	local v78 = p76 or 0.45
	local v79 = v_u_6.part
	local v80 = p75 * 0.3
	local v81 = p75 * 0.3
	local v82 = v79(Vector3.new(v80, 0.2, v81), CFrame.new(p73 + Vector3.new(0, 0.25, 0)), p74, {
		["transparency"] = 1
	})
	local v83 = Instance.new("Decal")
	v83.Face = Enum.NormalId.Top
	v83.Texture = p77 or v_u_5.Shockwave
	v83.Color3 = p74
	v83.Transparency = 0
	v83.Parent = v82
	local v84 = v_u_6.tween
	local v85 = {}
	local v86 = p75 * 2.2
	local v87 = p75 * 2.2
	v85.Size = Vector3.new(v86, 0.2, v87)
	v84(v82, v78, v85)
	v_u_6.tween(v83, v78, {
		["Transparency"] = 1
	}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	v_u_1:AddItem(v82, v78 + 0.05)
end
function v_u_6.disc(p88, p89, p_u_90, p_u_91, p92, p93) -- name: disc
	-- upvalues: (copy) v_u_6, (copy) v_u_1
	local v_u_94 = v_u_6.part(Vector3.new(0.1, 0.2, 0.1), CFrame.new(p88 + Vector3.new(0, 0.3, 0)), p89, {
		["transparency"] = 1
	})
	local v_u_95 = Instance.new("Decal")
	v_u_95.Face = Enum.NormalId.Top
	v_u_95.Texture = p92
	v_u_95.Color3 = p89
	v_u_95.Transparency = 1
	v_u_95.Parent = v_u_94
	local v96 = v_u_6.tween
	local v97 = {}
	local v98 = p_u_90 * 2
	local v99 = p_u_90 * 2
	v97.Size = Vector3.new(v98, 0.2, v99)
	v96(v_u_94, 0.25, v97, Enum.EasingStyle.Back)
	v_u_6.tween(v_u_95, 0.2, {
		["Transparency"] = 0
	})
	local v_u_100 = p93 or 1.5
	task.spawn(function()
		-- upvalues: (copy) v_u_94, (copy) p_u_91, (copy) v_u_100, (ref) v_u_6, (copy) v_u_95, (copy) p_u_90, (ref) v_u_1
		local v101 = os.clock()
		while v_u_94.Parent and os.clock() - v101 < p_u_91 do
			v_u_94.CFrame = CFrame.new(v_u_94.Position) * CFrame.Angles(0, (os.clock() - v101) * v_u_100, 0)
			task.wait()
		end
		if v_u_94.Parent then
			v_u_6.tween(v_u_95, 0.3, {
				["Transparency"] = 1
			})
			local v102 = v_u_6.tween
			local v103 = v_u_94
			local v104 = {}
			local v105 = p_u_90 * 2.4
			local v106 = p_u_90 * 2.4
			v104.Size = Vector3.new(v105, 0.2, v106)
			v102(v103, 0.3, v104)
			v_u_1:AddItem(v_u_94, 0.35)
		end
	end)
	return v_u_94
end
function v_u_6.beam(p107, p108, p109, p_u_110, p_u_111, p112) -- name: beam
	-- upvalues: (copy) v_u_6, (copy) v_u_5
	local v_u_113 = v_u_6.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p107), p109, {
		["transparency"] = 1
	})
	local v114 = Instance.new("Attachment")
	v114.Parent = v_u_113
	local v115 = Instance.new("Attachment")
	v115.Parent = v_u_113
	v115.WorldPosition = p108
	local v_u_116 = Instance.new("Beam")
	v_u_116.Attachment0 = v114
	v_u_116.Attachment1 = v115
	v_u_116.Texture = p112 or v_u_5.Beam
	v_u_116.TextureMode = Enum.TextureMode.Wrap
	v_u_116.TextureLength = 8
	v_u_116.TextureSpeed = 2
	v_u_116.LightEmission = 1
	v_u_116.LightInfluence = 0
	v_u_116.Color = ColorSequence.new(p109)
	v_u_116.FaceCamera = true
	v_u_116.Width0 = p_u_110
	v_u_116.Width1 = p_u_110
	v_u_116.Segments = 1
	v_u_116.Parent = v_u_113
	task.spawn(function()
		-- upvalues: (copy) v_u_113, (copy) p_u_111, (copy) p_u_110, (copy) v_u_116
		local v117 = os.clock()
		while v_u_113.Parent and os.clock() - v117 < p_u_111 do
			local v118 = (os.clock() - v117) / p_u_111
			local v119 = p_u_110 * (1 - v118 * v118)
			local v120 = v_u_116
			v_u_116.Width0 = v119
			v120.Width1 = v119
			v_u_116.Transparency = NumberSequence.new(v118 * 0.6)
			task.wait()
		end
		v_u_113:Destroy()
	end)
	return v_u_116
end
local v_u_121 = 0
local v_u_122 = 0
function v_u_6.shake(p123, p124) -- name: shake
	-- upvalues: (ref) v_u_121, (ref) v_u_122
	local v125 = os.clock()
	if v125 >= v_u_121 or p123 > v_u_122 then
		v_u_122 = math.min(p123, 0.6)
		v_u_121 = v125 + p124
	end
end
function v_u_6.shakeOffset() -- name: shakeOffset
	-- upvalues: (ref) v_u_121, (ref) v_u_122
	local v126 = os.clock()
	if v_u_121 <= v126 then
		return CFrame.identity
	end
	local v127 = v_u_122 * (v_u_121 - v126) / 0.3
	local v128 = v_u_122
	local v129 = math.min(v127, v128)
	return CFrame.new((math.random() - 0.5) * v129, (math.random() - 0.5) * v129, 0)
end
return v_u_6