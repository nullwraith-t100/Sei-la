local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Perf)
local v_u_5 = require(script.Parent.Fx.Preload)
local v_u_6 = require(v1.Shared.Config.Images)
local v_u_7 = require(v1.Shared.Config.Release)
local v_u_8 = require(v1.Shared.Logic.Boss)
local v9 = {}
local v_u_10 = Vector2.new(0.09, 0.04)
local v_u_11 = Vector2.new(0.32, 0.14)
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = nil
local v_u_15 = Random.new()
local v_u_16 = false
local function v_u_59(p17) -- name: read
	-- upvalues: (copy) v_u_15, (copy) v_u_4
	local v18 = p17:FindFirstChild("RiftCore")
	local v19
	if v18 then
		v19 = v18:FindFirstChild("Rift")
	else
		v19 = v18
	end
	local v20
	if v19 then
		v20 = v19:FindFirstChild("Window")
	else
		v20 = v19
	end
	if not (v18 and (v18:IsA("BasePart") and (v19 and (v19:IsA("BillboardGui") and v20)))) then
		return nil
	end
	local v21 = v19:GetAttribute("Galaxy")
	local v22 = {
		["model"] = nil,
		["core"] = nil,
		["gui"] = nil,
		["size"] = nil,
		["rim"] = nil,
		["light"] = nil,
		["lightBase"] = 1.8,
		["strips"] = nil,
		["arcs"] = nil,
		["chunks"] = nil,
		["words"] = nil,
		["farTile"] = nil,
		["nearTile"] = nil,
		["galaxy"] = nil,
		["lastStep"] = 0,
		["nextArc"] = nil,
		["arcOff"] = 0,
		["seed"] = nil,
		["model"] = p17,
		["core"] = v18,
		["gui"] = v19,
		["size"] = v19.Size,
		["strips"] = {},
		["arcs"] = {},
		["chunks"] = {}
	}
	local v23 = v19:GetAttribute("FarTile")
	v22.farTile = type(v23) ~= "number" and 3.2 or v23
	local v24 = v19:GetAttribute("NearTile")
	v22.nearTile = type(v24) ~= "number" and 6 or v24
	v22.galaxy = typeof(v21) ~= "Vector3" and Vector3.new(6, 9.5, 7.6) or v21
	v22.nextArc = os.clock() + v_u_15:NextNumber(0.5, 1.5)
	v22.seed = v_u_15:NextNumber(0, 100)
	local v25 = v19:FindFirstChild("Rim")
	if v25 and v25:IsA("ImageLabel") then
		v22.rim = v25
	end
	local v26 = v18:FindFirstChildOfClass("PointLight")
	if v26 then
		v22.light = v26
		local v27 = v26.Brightness
		local v28 = v26:GetAttribute("Brightness")
		if type(v28) == "number" then
			v27 = v28
		end
		v22.lightBase = v27
	end
	for _, v29 in v20:GetChildren() do
		local v30 = v29:GetAttribute("Strip")
		if not v29:IsA("Frame") or typeof(v30) ~= "Vector3" then
			continue
		end
		local v31 = v29:FindFirstChild("Far")
		local v32 = v29:FindFirstChild("Near")
		local v33 = v29:FindFirstChild("Galaxy")
		local v34 = v22.strips
		local v35 = {
			["x"] = v30.X,
			["y"] = v30.Y,
			["w"] = v30.Z
		}
		local v36 = v29:GetAttribute("StripH")
		v35.h = type(v36) ~= "number" and 0.78 or v36
		if not (v31 and v31:IsA("ImageLabel")) then
			v31 = nil
		end
		v35.far = v31
		if not (v32 and v32:IsA("ImageLabel")) then
			v32 = nil
		end
		v35.near = v32
		if not (v33 and v33:IsA("ImageLabel")) then
			v33 = nil
		end
		v35.galaxy = v33
		table.insert(v34, v35)
	end
	for _, v37 in v18:GetChildren() do
		if not v37:IsA("Beam") or v37.Name ~= "Arc" then
			continue
		end
		local v38 = v22.arcs
		table.insert(v38, v37)
	end
	for v39, v40 in p17:GetDescendants() do
		if not v40:IsA("BasePart") or v40.Name ~= "Chunk" then
			continue
		end
		local v41 = v22.chunks
		local v42 = {
			["part"] = v40,
			["rest"] = v40.CFrame,
			["phase"] = v39 * 1.7,
			["spin"] = (v39 % 2 == 0 and 1 or -1) * (0.25 + v39 % 3 * 0.1)
		}
		table.insert(v41, v42)
	end
	local v43 = p17:FindFirstChild("Sign")
	if v43 then
		v43 = v43:FindFirstChild("Board")
	end
	if v43 and v43:IsA("BillboardGui") then
		local v44 = {
			["board"] = nil,
			["paint"] = nil,
			["palette"] = nil,
			["pulse"] = nil,
			["strokes"] = nil,
			["board"] = v43,
			["palette"] = {},
			["strokes"] = {}
		}
		local v45 = v43:FindFirstChild("Title")
		local v46
		if v45 then
			v46 = v45:FindFirstChild("Paint")
		else
			v46 = v45
		end
		if v46 and v46:IsA("UIGradient") then
			local v47 = v46.Color.Keypoints
			for v48 = 1, #v47 - 1 do
				local v49 = v44.palette
				local v50 = v47[v48].Value
				table.insert(v49, v50)
			end
			if #v44.palette >= 2 then
				v44.paint = v46
			end
		end
		local v51 = v43:FindFirstChild("Pulse")
		if v51 and v51:IsA("UIScale") then
			v44.pulse = v51
		end
		for _, v52 in v43:GetChildren() do
			local v53 = v52:FindFirstChildOfClass("UIStroke")
			if not (v52:IsA("TextLabel") and v53) then
				continue
			end
			local v54 = v44.strokes
			local v55 = {
				["stroke"] = v53,
				["share"] = v52 == v45 and 0.055 or 0.04
			}
			table.insert(v54, v55)
		end
		v22.words = v44
	end
	for _, v56 in p17:GetDescendants() do
		if not v56:IsA("ParticleEmitter") then
			continue
		end
		local v57 = v56.Rate
		local v58 = v56:GetAttribute("Rate")
		if type(v58) == "number" then
			v57 = v58
		end
		v56.Rate = v57 * v_u_4.mapRate()
	end
	return v22
end
local function v_u_70(p60, p61) -- name: flowing
	local v62 = #p60
	local v63 = {}
	for v64 = 0, 10 do
		local v65 = v64 / 10
		local v66 = (v65 + p61) % 1 * v62
		local v67 = math.floor(v66)
		local v68 = p60[v67 % v62 + 1]:Lerp(p60[(v67 + 1) % v62 + 1], v66 - v67)
		local v69 = ColorSequenceKeypoint.new
		table.insert(v63, v69(v65, v68))
	end
	return ColorSequence.new(v63)
end
local function v_u_74(p71) -- name: settle
	for _, v72 in p71.chunks do
		if not v72.part.Parent then
			continue
		end
		v72.part.CFrame = v72.rest
	end
	for _, v73 in p71.arcs do
		v73.Enabled = false
	end
	p71.gui.Size = p71.size
end
local function v_u_124(p75, p76, p77) -- name: animate
	-- upvalues: (copy) v_u_10, (copy) v_u_11, (copy) v_u_70, (copy) v_u_4, (copy) v_u_15
	local v78 = p77.CFrame
	local v79 = p75.model:GetPivot()
	local v80 = v78.Position - p75.core.Position
	local v81 = v80.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v80.Unit
	local v82 = v79.RightVector
	local v83 = v81:Dot(v82) * v78.RightVector:Dot(v82)
	local v84 = v81.Y
	local v85 = p76 + p75.seed
	local v86 = v85 * v_u_10.X - v83 * 2.2
	local v87 = v85 * v_u_10.Y + v84 * 2.2
	local v88 = v85 * v_u_11.X - v83 * 0.7
	local v89 = v85 * v_u_11.Y + v84 * 0.7
	local v90 = p75.galaxy
	local v91 = v90.X + v83 * 1.2 - v90.Z / 2
	local v92 = v90.Y - v84 * 1.2 - v90.Z / 2
	local v93 = v85 * -7 % 360
	for _, v94 in p75.strips do
		local v95 = v94.far
		local v96 = v94.near
		local v97 = v94.galaxy
		if v95 then
			local v98 = p75.farTile
			v95.Position = UDim2.fromScale(-((v94.x + v86) % v98) / v94.w, -((v94.y + v87) % v98) / v94.h)
		end
		if v96 then
			local v99 = p75.nearTile
			v96.Position = UDim2.fromScale(-((v94.x + v88) % v99) / v94.w, -((v94.y + v89) % v99) / v94.h)
		end
		if not v97 then
			continue
		end
		v97.Position = UDim2.fromScale((v91 - v94.x) / v94.w, (v92 - v94.y) / v94.h)
		v97.Rotation = v93
	end
	local v100 = math.noise(v85 * 7.3, p75.seed) * 0.5 + math.noise(v85 * 2.1, 3.7) * 0.5
	local v101 = p75.rim
	if v101 then
		local v102 = -v100 * 0.35
		v101.ImageTransparency = math.clamp(v102, 0, 0.18)
	end
	local v103 = p75.light
	if v103 then
		local v104 = p75.lightBase
		local v105 = 0.85 + v100 * 0.9
		v103.Brightness = v104 * math.clamp(v105, 0.45, 1.4)
	end
	local v106 = v85 * 1.7
	local v107 = math.sin(v106) * 0.012 + 1
	local v108 = p75.size
	p75.gui.Size = UDim2.fromScale(v108.X.Scale * v107, v108.Y.Scale * v107)
	local v109 = p75.words
	if v109 then
		local v110 = v109.paint
		if v110 then
			v110.Color = v_u_70(v109.palette, p76 / 4 % 1)
		end
		local v111 = v109.pulse
		if v111 then
			local v112 = p76 * 2.6
			v111.Scale = math.sin(v112) * 0.035 + 1
		end
		local v113 = v109.board.AbsoluteSize.Y
		for _, v114 in v109.strokes do
			local v115 = v114.stroke
			local v116 = v113 * v114.share
			v115.Thickness = math.clamp(v116, 1.5, 7)
		end
	end
	if v_u_4.level() > 1 then
		if p75.arcOff <= p76 then
			for _, v117 in p75.arcs do
				v117.Enabled = false
			end
		end
		if p75.nextArc <= p76 and #p75.arcs > 0 then
			local v118 = p75.arcs[v_u_15:NextInteger(1, #p75.arcs)]
			v118.CurveSize0 = v_u_15:NextNumber(-3, 3)
			v118.CurveSize1 = v_u_15:NextNumber(-3, 3)
			v118.Enabled = true
			p75.arcOff = p76 + v_u_15:NextNumber(0.1, 0.22)
			p75.nextArc = p76 + v_u_15:NextNumber(0.8, 2.4)
		end
		for _, v119 in p75.chunks do
			local v120 = v119.part
			local v121 = v119.rest
			local v122 = CFrame.new
			local v123 = v85 * 0.9 + v119.phase
			v120.CFrame = v121 * v122(0, math.sin(v123) * 0.35, 0) * CFrame.Angles(v85 * v119.spin * 0.6, v85 * v119.spin, 0)
		end
	end
end
local function v_u_129() -- name: portals
	-- upvalues: (copy) v_u_3
	local v125 = {}
	local v126 = v_u_3:FindFirstChild("BossPortals")
	if v126 then
		for _, v127 in v126:GetChildren() do
			if not v127:IsA("Model") then
				continue
			end
			table.insert(v125, v127)
		end
	end
	local v128 = v_u_3:FindFirstChild("BossArena")
	if v128 then
		v128 = v128:FindFirstChild("ExitPortal")
	end
	if v128 and v128:IsA("Model") then
		table.insert(v125, v128)
	end
	return v125
end
local function v_u_134() -- name: step
	-- upvalues: (copy) v_u_3, (ref) v_u_13, (copy) v_u_4, (copy) v_u_124
	local v130 = v_u_3.CurrentCamera
	if v130 then
		local v131 = os.clock()
		local v132 = v130.CFrame.Position
		for _, v133 in v_u_13 do
			if not v133.core.Parent or v_u_4.frameGap((v133.core.Position - v132).Magnitude) > v131 - v133.lastStep then
				continue
			end
			v133.lastStep = v131
			v_u_124(v133, v131, v130)
		end
	end
end
local function v_u_154() -- name: choose
	-- upvalues: (copy) v_u_3, (ref) v_u_16, (copy) v_u_8, (copy) v_u_5, (copy) v_u_6, (copy) v_u_12, (copy) v_u_129, (copy) v_u_59, (ref) v_u_13, (copy) v_u_74, (ref) v_u_14, (copy) v_u_2, (copy) v_u_134
	local v135 = v_u_3.CurrentCamera
	if v135 then
		if not v_u_16 and (v_u_3:FindFirstChild("BossArena") and (v_u_8.CENTRE - v135.CFrame.Position).Magnitude < 450) then
			v_u_16 = true
			v_u_5.images({ v_u_6.Rift.SpaceExit, v_u_6.Rift.RimExit, v_u_6.Rift.Stars })
		end
		for v136 in v_u_12 do
			if v136.Parent then
				continue
			end
			v_u_12[v136] = nil
		end
		local v137 = v135.CFrame.Position
		local v138 = v135.ViewportSize
		local v139 = {}
		for _, v140 in v_u_129() do
			local v141 = v140:FindFirstChild("RiftCore")
			if not (v141 and v141:IsA("BasePart")) then
				continue
			end
			local v142 = (v141.Position - v137).Magnitude
			if v142 > 260 then
				continue
			end
			local v143, v144 = v135:WorldToViewportPoint(v141.Position)
			if not v144 or (v143.X <= -400 or (v143.X >= v138.X + 400 or (v143.Y <= -400 or v143.Y >= v138.Y + 400))) then
				continue
			end
			local v145 = v_u_12[v140]
			local v146 = ((not v145 or v145.core ~= v141) and true or false) and v_u_59(v140)
			if v146 then
				v_u_12[v140] = v146
			end
			if not v146 then
				continue
			end
			table.insert(v139, {
				["rift"] = v146,
				["dist"] = v142
			})
		end
		table.sort(v139, function(p147, p148)
			return p147.dist < p148.dist
		end)
		local v149 = #v139
		local v150 = {}
		for v151 = 1, math.min(2, v149) do
			local v152 = v139[v151].rift
			table.insert(v150, v152)
		end
		for _, v153 in v_u_13 do
			if table.find(v150, v153) or not v153.core.Parent then
				continue
			end
			v_u_74(v153)
		end
		v_u_13 = v150
		if #v_u_13 > 0 and not v_u_14 then
			v_u_14 = v_u_2.RenderStepped:Connect(v_u_134)
		elseif #v_u_13 == 0 and v_u_14 then
			v_u_14:Disconnect()
			v_u_14 = nil
		end
	else
		return
	end
end
function v9.start() -- name: start
	-- upvalues: (copy) v_u_7, (copy) v_u_2, (copy) v_u_3, (copy) v_u_154
	if v_u_7.on(2) or v_u_2:IsStudio() then
		task.spawn(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_3, (ref) v_u_154
			while not v_u_7.on(2) do
				v_u_3:GetAttributeChangedSignal("DevUpdate2"):Wait()
			end
			while true do
				v_u_154()
				task.wait(0.5)
			end
		end)
	end
end
return v9