local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("5AD8FF")
local v_u_9 = Color3.fromHex("0A1A3A")
local v_u_10 = Color3.new(1, 1, 1)
local v_u_11 = Color3.fromRGB(214, 246, 255)
local v_u_12 = Color3.fromRGB(30, 120, 255)
local v_u_13 = Color3.fromRGB(125, 110, 255)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.PartType.Cylinder
local function v_u_27(p16, p17, p18, p19, p20) -- name: pic
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_34(p28, p29, p30, p31) -- name: setPic
	local v32 = math.max(p29, 0.03) * 2
	p28.Size = Vector3.new(v32, 0.05, v32)
	if p30 or p31 then
		for _, v33 in p28:GetChildren() do
			if not v33:IsA("Decal") then
				continue
			end
			if p30 then
				v33.Transparency = p30
			end
			if not p31 then
				continue
			end
			v33.Color3 = p31
		end
	end
end
local function v_u_41(p35, p36, p37, p38) -- name: blob
	-- upvalues: (copy) v_u_5
	local v39 = v_u_5.part(p35, p36, p37, {
		["transparency"] = p38
	})
	local v40 = Instance.new("SpecialMesh")
	v40.MeshType = Enum.MeshType.Sphere
	v40.Parent = v39
	return v39
end
local function v_u_51(p42, p43, p44, p45) -- name: layRod
	local v46 = (p44 - p43).Magnitude
	local v47 = math.max(v46, 0.05)
	local v48 = ((p44 - p43).Magnitude <= 0.001 and Vector3.new(0, 1, 0) or (p44 - p43).Unit).Y
	local v49 = math.abs(v48) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
	local v50 = math.max(p45, 0.02)
	p42.Size = Vector3.new(v47, v50, v50)
	p42.CFrame = CFrame.lookAt((p43 + p44) / 2, p44, v49) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_60(p52, p53, p54, p55, p56, p_u_57) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1
	local v_u_58 = Instance.new("ColorCorrectionEffect")
	v_u_58.Name = "VoidGaze"
	v_u_58.Parent = v_u_2
	v_u_5.tween(v_u_58, p55, {
		["TintColor"] = p52,
		["Brightness"] = p53,
		["Contrast"] = p54
	})
	task.delay(p55 + p56, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_58, (copy) p_u_57, (ref) v_u_10
		local v59 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_10
		}
		v_u_5.tween(v_u_58, p_u_57, v59)
	end)
	v_u_1:AddItem(v_u_58, p55 + p56 + p_u_57 + 0.1)
end
return function(p_u_61)
	-- upvalues: (copy) v_u_27, (copy) v_u_1, (copy) v_u_34, (copy) v_u_7, (copy) v_u_4, (copy) v_u_41, (copy) v_u_10, (copy) v_u_8, (copy) v_u_5, (copy) v_u_12, (copy) v_u_11, (copy) v_u_14, (copy) v_u_13, (copy) v_u_6, (copy) v_u_60, (copy) v_u_51, (copy) v_u_9, (copy) v_u_15
	local v62 = {}
	local function v_u_76(p_u_63, p_u_64, p_u_65, p66, p67, p68, p69, p70) -- name: flare
		-- upvalues: (ref) v_u_27, (ref) v_u_1, (copy) p_u_61, (ref) v_u_34
		local v_u_71 = p69 or 0
		local v_u_72 = v_u_27(p_u_63, p_u_64, p66, p67, v_u_71)
		v_u_1:AddItem(v_u_72, p68 + 0.1)
		local v_u_73 = p70 or 0
		p_u_61.animate(p68, 0, function(p74)
			-- upvalues: (ref) v_u_34, (copy) v_u_72, (copy) p_u_64, (copy) p_u_65, (copy) v_u_71, (copy) v_u_73, (copy) p_u_63
			local v75 = 1 - (1 - p74) ^ 3
			v_u_34(v_u_72, p_u_64 + (p_u_65 - p_u_64) * v75, v_u_71 + (1 - v_u_71) * p74 ^ 1.5)
			if v_u_73 ~= 0 then
				v_u_72.CFrame = p_u_63 * CFrame.Angles(0, v_u_73 * v75, 0)
			end
			if p74 >= 1 then
				v_u_72:Destroy()
			end
		end)
	end
	local function v_u_85(p77, p_u_78, p_u_79, p80, p81) -- name: focus
		-- upvalues: (ref) v_u_27, (ref) v_u_7, (ref) v_u_1, (copy) p_u_61, (ref) v_u_34
		local v_u_82 = v_u_27(p77, p_u_78, v_u_7.Ring, p80, 0.7)
		v_u_1:AddItem(v_u_82, p81 + 0.1)
		p_u_61.animate(p81, 0, function(p83)
			-- upvalues: (ref) v_u_34, (copy) v_u_82, (copy) p_u_78, (copy) p_u_79
			local v84
			if p83 < 0.75 then
				v84 = 0.7 - 0.7 * (p83 / 0.75)
			else
				v84 = (p83 - 0.75) / 0.25
			end
			v_u_34(v_u_82, p_u_78 + (p_u_79 - p_u_78) * p83 * p83, v84)
			if p83 >= 1 then
				v_u_82:Destroy()
			end
		end)
	end
	local function v_u_117(p86, p_u_87, p_u_88, p89, p90) -- name: streakAt
		-- upvalues: (ref) v_u_4, (ref) v_u_41, (ref) v_u_10, (ref) v_u_8, (ref) v_u_1, (copy) p_u_61
		local v91 = v_u_4.CurrentCamera
		local v92
		if v91 then
			local v93 = v91.CFrame.Position - p86
			v92 = v93.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v93.Unit
		else
			v92 = Vector3.new(0, 0, 1)
		end
		local v94 = v_u_4.CurrentCamera
		local v95 = not v94 and Vector3.new(1, 0, 0) or v94.CFrame.RightVector
		local v96 = CFrame.lookAt(p86, p86 + v95, v92)
		local v97 = v_u_41
		local v98 = p_u_87 * 0.2
		local v_u_99 = v97(Vector3.new(p_u_88, 0.05, v98), v96, v_u_10)
		local v_u_100
		if p90 then
			v_u_100 = nil
		else
			local v101 = v_u_41
			local v102 = p_u_88 * 2.8
			local v103 = p_u_87 * 0.25
			v_u_100 = v101(Vector3.new(v102, 0.05, v103), v96, v_u_8, 0.45)
		end
		v_u_1:AddItem(v_u_99, p89 + 0.1)
		if v_u_100 then
			v_u_1:AddItem(v_u_100, p89 + 0.1)
		end
		p_u_61.animate(p89, 0, function(p104)
			-- upvalues: (copy) p_u_87, (copy) v_u_99, (copy) p_u_88, (ref) v_u_100
			local v105 = p104 / 0.12
			local v106 = math.min(v105, 1)
			local v107 = (p104 - 0.12) / 0.88
			local v108 = 1 - math.clamp(v107, 0, 1)
			local v109 = p_u_87 * ((1 - (1 - v106) ^ 2) * 0.8 + 0.2) * ((1 - v108) * 0.15 + 1)
			local v110 = v_u_99
			local v111 = p_u_88 * v108
			local v112 = math.max(v111, 0.03)
			v110.Size = Vector3.new(v112, 0.05, v109)
			v_u_99.Transparency = 1 - v108
			local v113 = v_u_100
			if v113 then
				local v114 = p_u_88 * 2.8 * v108
				local v115 = math.max(v114, 0.03)
				local v116 = v109 * 1.15
				v113.Size = Vector3.new(v115, 0.05, v116)
				v113.Transparency = (1 - v108) * 0.55 + 0.45
			end
			if p104 >= 1 then
				v_u_99:Destroy()
				if v113 then
					v113:Destroy()
				end
			end
		end)
	end
	v62.void_gaze_a = {
		["cast"] = function(p118) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) v_u_76, (copy) p_u_61, (ref) v_u_4, (ref) v_u_7, (ref) v_u_10
			local v119 = p118.size
			local v120 = p118.eye + p118.dir * 1.1
			v_u_5.flash(v120, v_u_8, 3 * v119, 0.12)
			if not p118.lite then
				local v121 = v_u_76
				local v122 = p_u_61.facing
				local v123 = v_u_4.CurrentCamera
				local v124
				if v123 then
					local v125 = v123.CFrame.Position - v120
					v124 = v125.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v125.Unit
				else
					v124 = Vector3.new(0, 0, 1)
				end
				v121(v122(v120, v124), 0.3 * v119, 1.5 * v119, v_u_7.VoidCross, v_u_10, 0.12, 0)
			end
		end,
		["shot"] = function(p126, p127) -- name: crossShot
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_61, (ref) v_u_12, (ref) v_u_27, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_14, (ref) v_u_1, (ref) v_u_4
			local v_u_128 = p126.size
			local v_u_129 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p127, v_u_8, {
				["transparency"] = 1
			})
			p_u_61.streak(v_u_129, v_u_8, v_u_12, 0.75 * v_u_128, p126.lite and 0.1 or 0.16)
			local v_u_130 = v_u_27(p127, 1.8 * v_u_128, v_u_7.VoidCross, v_u_8, 0.05)
			local v_u_131 = v_u_27(p127, 1.15 * v_u_128, v_u_7.VoidCross, v_u_10, 0)
			local v_u_132 = { v_u_130, v_u_131 }
			local v_u_133
			if p126.lite then
				v_u_133 = nil
			else
				local v134 = {
					["shape"] = v_u_14
				}
				v_u_133 = v_u_5.part(Vector3.new(0.42, 0.42, 0.42) * v_u_128, p127, v_u_11, v134)
				table.insert(v_u_132, v_u_133)
			end
			for _, v135 in v_u_132 do
				v_u_1:AddItem(v135, 3)
			end
			v_u_1:AddItem(v_u_129, 3)
			if p126.mine then
				p_u_61.light(v_u_129, v_u_8, 9 * v_u_128)
			end
			local v_u_136 = false
			return {
				["place"] = function(p137, p138) -- name: place
					-- upvalues: (copy) v_u_129, (ref) p_u_61, (ref) v_u_4, (copy) v_u_130, (copy) v_u_128, (copy) v_u_131, (ref) v_u_133
					v_u_129.CFrame = p137
					local v139 = p137.Position
					local v140 = p_u_61.facing
					local v141 = v_u_4.CurrentCamera
					local v142
					if v141 then
						local v143 = v141.CFrame.Position - v139
						v142 = v143.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v143.Unit
					else
						v142 = Vector3.new(0, 0, 1)
					end
					local v144 = v140(v139, v142) * CFrame.Angles(0, p138 * 7, 0)
					local v145 = p138 * 46
					local v146 = math.sin(v145)
					local v147 = math.max(v146, 0) * 0.2 + 1
					v_u_130.CFrame = v144 * CFrame.new(0, -0.04, 0)
					local v148 = v_u_130
					local v149 = 1.8 * v_u_128 * v147
					local v150 = math.max(v149, 0.03) * 2
					v148.Size = Vector3.new(v150, 0.05, v150)
					v_u_131.CFrame = v144
					local v151 = v_u_133
					if v151 then
						v151.CFrame = CFrame.new(v139)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_136, (copy) v_u_132, (copy) v_u_129, (ref) v_u_1
					if not v_u_136 then
						v_u_136 = true
						for _, v152 in v_u_132 do
							v152:Destroy()
						end
						local v153 = v_u_129:FindFirstChildWhichIsA("PointLight")
						if v153 then
							v153:Destroy()
						end
						v_u_1:AddItem(v_u_129, 0.2)
					end
				end
			}
		end,
		["impact"] = function(p154, p155) -- name: crossImpact
			-- upvalues: (copy) p_u_61, (ref) v_u_4, (copy) v_u_76, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8, (copy) v_u_85, (ref) v_u_11
			local v156 = p154.size
			local v157 = p_u_61.facing
			local v158 = v_u_4.CurrentCamera
			local v159
			if v158 then
				local v160 = v158.CFrame.Position - p155
				v159 = v160.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v160.Unit
			else
				v159 = Vector3.new(0, 0, 1)
			end
			local v161 = v157(p155, v159)
			v_u_76(v161, 0.7 * v156, 3.4 * v156, v_u_7.VoidCross, v_u_10, 0.2, 0, 0.7853981633974483)
			v_u_76(v161 * CFrame.new(0, -0.05, 0), 1.2 * v156, 4.6 * v156, v_u_7.VoidCross, v_u_8, 0.26, 0.25, 0.7853981633974483)
			p_u_61.burst("Impact", p155, v_u_8, 0.85 * v156)
			if not p154.lite then
				v_u_85(v161 * CFrame.new(0, 0.05, 0), 3.6 * v156, 0.5 * v156, v_u_11, 0.18)
				p_u_61.glint(p155, v_u_11, 2.8 * v156, 0.14)
			end
			p_u_61.hitSound(p155)
		end,
		["hit"] = p_u_61.simpleHit(v_u_8, 0.5)
	}
	local v_u_162 = {
		{
			["at"] = 0.18,
			["image"] = nil,
			["color"] = nil,
			["r"] = 2.8,
			["alpha"] = 0,
			["image"] = v_u_7.FlareHex,
			["color"] = v_u_12
		},
		{
			["at"] = 0.3,
			["image"] = nil,
			["color"] = nil,
			["r"] = 4.2,
			["alpha"] = 0,
			["image"] = v_u_7.Ring,
			["color"] = v_u_12
		},
		{
			["at"] = 0.42,
			["image"] = nil,
			["color"] = nil,
			["r"] = 5.4,
			["alpha"] = 0.1,
			["image"] = v_u_7.Glow,
			["color"] = v_u_13
		},
		{
			["at"] = 0.54,
			["image"] = nil,
			["color"] = nil,
			["r"] = 3.6,
			["alpha"] = 0,
			["image"] = v_u_7.FlareHex,
			["color"] = v_u_13
		},
		{
			["at"] = 0.66,
			["image"] = nil,
			["color"] = nil,
			["r"] = 6,
			["alpha"] = 0,
			["image"] = v_u_7.Ring,
			["color"] = v_u_8
		},
		{
			["at"] = 0.78,
			["image"] = nil,
			["color"] = nil,
			["r"] = 5,
			["alpha"] = 0,
			["image"] = v_u_7.FlareHex,
			["color"] = v_u_12
		},
		{
			["at"] = 0.9,
			["image"] = nil,
			["color"] = nil,
			["r"] = 6.4,
			["alpha"] = 0.1,
			["image"] = v_u_7.Glow,
			["color"] = v_u_8
		}
	}
	local function v_u_199(p163, p164, p165) -- name: ghosts
		-- upvalues: (copy) v_u_162, (ref) v_u_27, (copy) p_u_61, (ref) v_u_4, (ref) v_u_1, (ref) v_u_34, (ref) v_u_10
		local v166 = p165 - p164
		local v167 = v166.Magnitude
		if v167 >= 1 then
			local v_u_168 = v166.Unit
			local v_u_169 = {}
			for v170, v171 in v_u_162 do
				if p163.lite and v170 % 2 == 0 then
					continue
				end
				local v172 = p164 + v_u_168 * v167 * v171.at + Vector3.new(0, 1, 0) * v171.at * 7
				local v173 = v_u_27
				local v174 = p_u_61.facing
				local v175 = v_u_4.CurrentCamera
				local v176
				if v175 then
					local v177 = v175.CFrame.Position - v172
					v176 = v177.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v177.Unit
				else
					v176 = Vector3.new(0, 0, 1)
				end
				local v178 = v173(v174(v172, v176), 0.05, v171.image, v171.color, v171.alpha)
				v_u_1:AddItem(v178, 1.5)
				local v179 = {
					["p"] = v178,
					["pos"] = v172,
					["r"] = v171.r,
					["color"] = v171.color,
					["alpha"] = v171.alpha,
					["wait"] = (v170 - 1) * 0.022,
					["flashAt"] = (v170 - 1) * 0.028 + 0.15
				}
				table.insert(v_u_169, v179)
			end
			local v_u_180 = os.clock()
			p_u_61.runNow(function()
				-- upvalues: (copy) v_u_180, (copy) v_u_169, (copy) v_u_168, (ref) p_u_61, (ref) v_u_4, (ref) v_u_34, (ref) v_u_10
				local v181 = os.clock() - v_u_180
				for _, v182 in v_u_169 do
					local v183 = v181 - v182.wait
					local v184
					if v183 <= 0 then
						v184 = 0
					else
						local v185 = v183 / 0.12
						local v186 = math.min(v185, 1) - 1
						v184 = v186 * 2.9 * v186 * v186 + 1 + v186 * 1.9 * v186
					end
					local v187 = v181 - v182.flashAt
					local v188 = 1 - math.abs(v187) / 0.07
					local v189 = math.max(v188, 0)
					local v190 = (v181 - 0.42 - v182.wait) / 0.28
					local v191 = math.clamp(v190, 0, 1)
					local v192 = v182.pos + v_u_168 * v181 * 4
					local v193 = v182.p
					local v194 = p_u_61.facing
					local v195 = v_u_4.CurrentCamera
					local v196
					if v195 then
						local v197 = v195.CFrame.Position - v192
						v196 = v197.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v197.Unit
					else
						v196 = Vector3.new(0, 0, 1)
					end
					v193.CFrame = v194(v192, v196)
					v_u_34(v182.p, v182.r * v184 * (v189 * 0.25 + 1) * (v191 * 0.15 + 1), v182.alpha + (1 - v182.alpha) * v191, v182.color:Lerp(v_u_10, v189))
				end
				if v181 <= 0.8999999999999999 then
					return true
				end
				for _, v198 in v_u_169 do
					v198.p:Destroy()
				end
				return false
			end)
		end
	end
	v62.void_gaze_e = {
		["castSound"] = "Laser",
		["cast"] = nil,
		["windup"] = nil,
		["beam"] = nil,
		["hit"] = nil,
		["cast"] = function(p200) -- name: cast
			-- upvalues: (copy) p_u_61, (ref) v_u_8, (ref) v_u_11
			p_u_61.skillCast(p200, v_u_8)
			if not p200.lite then
				p_u_61.glint(p200.eye, v_u_11, 4 * p200.size, 0.2)
			end
		end,
		["windup"] = function(p201, p202, p203) -- name: windup
			-- upvalues: (copy) p_u_61, (ref) v_u_10, (copy) v_u_117, (copy) v_u_85, (ref) v_u_4, (ref) v_u_8
			local v204 = p202 + p201.dir * 1.6
			local v205 = math.max(p203, 0.1)
			p_u_61.pop(v204, v_u_10, 0.6, 2.6, v205 + 0.05)
			v_u_117(v204, 9, 0.3, v205 + 0.12, p201.lite)
			if not p201.lite then
				local v206 = v_u_85
				local v207 = p_u_61.facing
				local v208 = v_u_4.CurrentCamera
				local v209
				if v208 then
					local v210 = v208.CFrame.Position - v204
					v209 = v210.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v210.Unit
				else
					v209 = Vector3.new(0, 0, 1)
				end
				v206(v207(v204, v209), 3.2, 0.3, v_u_8, v205)
			end
		end,
		["beam"] = function(p211, p212, p213) -- name: beam
			-- upvalues: (copy) v_u_117, (copy) p_u_61, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (copy) v_u_199, (ref) v_u_4, (copy) v_u_76, (ref) v_u_11, (ref) v_u_6, (ref) v_u_60, (ref) v_u_5
			local v214 = p212 + (p213 - p212).Unit * 2
			v_u_117(v214, 34, 0.7, 0.5, p211.lite)
			p_u_61.pop(v214, v_u_10, 2, 7, 0.22)
			p_u_61.glowBeam(v214, p213, v_u_8, p211.ability.width or 10, 0.32, v_u_7.Beam)
			p_u_61.glowBeam(v214, p213, v_u_10, 3, 0.22, v_u_7.Beam)
			v_u_199(p211, v214, p213)
			local v215 = p_u_61.facing
			local v216 = v_u_4.CurrentCamera
			local v217
			if v216 then
				local v218 = v216.CFrame.Position - p213
				v217 = v218.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v218.Unit
			else
				v217 = Vector3.new(0, 0, 1)
			end
			local v219 = v215(p213, v217)
			v_u_76(v219, 1, 7.5, v_u_7.VoidCross, v_u_10, 0.32, 0, 0.7853981633974483)
			v_u_76(v219 * CFrame.new(0, -0.05, 0), 2, 10, v_u_7.Glow, v_u_8, 0.38, 0.3)
			p_u_61.burst("Impact", p213, v_u_8, 1.4)
			p_u_61.groundLine(v214, p213, 2.6, v_u_8, 0.55, 0.45)
			if not p211.lite then
				p_u_61.glint(p213, v_u_11, 9, 0.28)
				p_u_61.alongPath(v214, p213, 9, 0.16, function(p220)
					-- upvalues: (ref) p_u_61, (ref) v_u_11
					p_u_61.glint(p220, v_u_11, 2.6, 0.14)
				end)
			end
			v_u_6.play("Burst", {
				["at"] = nil,
				["volume"] = 0.35,
				["at"] = p213
			})
			if p211.mine then
				v_u_60(Color3.fromRGB(215, 242, 255), 0.07, 0.05, 0.05, 0.06, 0.3)
				v_u_5.shake(0.18, 0.2)
			end
		end,
		["hit"] = function(p221, p222, _) -- name: hit
			-- upvalues: (copy) p_u_61, (ref) v_u_8, (copy) v_u_76, (ref) v_u_4, (ref) v_u_7, (ref) v_u_11
			p_u_61.burst("Impact", p222, v_u_8, 0.65)
			if not p221.lite then
				local v223 = v_u_76
				local v224 = p_u_61.facing
				local v225 = v_u_4.CurrentCamera
				local v226
				if v225 then
					local v227 = v225.CFrame.Position - p222
					v226 = v227.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v227.Unit
				else
					v226 = Vector3.new(0, 0, 1)
				end
				v223(v224(p222, v226), 0.8, 2.6, v_u_7.FlareHex, v_u_11, 0.22, 0.1)
			end
		end
	}
	local v_u_228 = {
		0.2,
		0.45,
		0.7,
		0.96
	}
	local v_u_229 = {
		3.6,
		4.2,
		4.8,
		7.5
	}
	local v_u_230 = {}
	setmetatable(v_u_230, {
		["__mode"] = "k"
	})
	local function v_u_243(p231, p232, p233, p234, p235) -- name: reticle
		-- upvalues: (ref) v_u_27, (ref) v_u_7, (ref) v_u_8, (ref) v_u_1, (ref) v_u_5, (ref) v_u_11, (ref) v_u_10
		local v236 = v_u_27(CFrame.new(p232), p233, v_u_7.Ring, v_u_8, 1)
		v_u_1:AddItem(v236, p235)
		local v237 = {}
		for v238 = 1, p231.lite and 2 or 4 do
			local v239 = v_u_5.part
			local v240 = p233 * 0.5
			local v241 = v239(Vector3.new(0.38, 0.12, v240), CFrame.new(p232), v_u_11, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v241, p235)
			v237[v238] = v241
		end
		local v242
		if p231.lite then
			v242 = nil
		else
			v242 = v_u_5.part(Vector3.new(0.75, 0.12, 0.75), CFrame.new(p232), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v242, p235)
		end
		return {
			["ring"] = nil,
			["ticks"] = nil,
			["dot"] = nil,
			["at"] = nil,
			["r"] = nil,
			["wait"] = nil,
			["fadeAt"] = nil,
			["ring"] = v236,
			["ticks"] = v237,
			["dot"] = v242,
			["at"] = p232,
			["r"] = p233,
			["wait"] = p234
		}
	end
	local function v_u_273(p244, p245, p246) -- name: placeReticle
		-- upvalues: (ref) v_u_34, (ref) v_u_8, (ref) v_u_10
		local v247 = p245 - p244.wait
		local v248 = v247 / 0.14
		local v249 = math.clamp(v248, 0, 1)
		local v250 = p244.fadeAt
		local v251
		if v250 then
			local v252 = (os.clock() - v250) / 0.3
			v251 = math.clamp(v252, 0, 1)
		else
			v251 = 0
		end
		local v253
		if v247 <= 0 then
			v253 = 0
		else
			local v254 = v247 / 0.084
			v253 = math.min(v254, 1)
		end
		local v255 = v249 - 1
		local v256 = (1 - (v255 * 2.9 * v255 * v255 + 1 + v255 * 1.9 * v255)) * 1.3 + 1
		local v257 = (1 - v249) ^ 2 * 3.141592653589793 / 2
		local v258 = v247 - 0.14
		local v259 = v257 + math.max(v258, 0) * 0.6
		local v260 = p244.r * v256
		local v261 = CFrame.new(p244.at) * CFrame.Angles(0, v259, 0)
		p244.ring.CFrame = v261
		v_u_34(p244.ring, v260 * 1.1, 1 - v253 * (1 - v251) * 0.95)
		local v262 = v247 - 0.14
		local v263 = 1 - math.abs(v262) / 0.08
		local v264 = math.max(v263, 0)
		for v265, v266 in p244.ticks do
			local v267 = (v265 - 1) * (p246 and 3.141592653589793 or 1.5707963267948966)
			local v268 = math.sin(v267)
			local v269 = -math.cos(v267)
			local v270 = Vector3.new(v268, 0, v269)
			local v271 = v270 * v260 * 0.78
			v266.CFrame = v261 * CFrame.lookAt(v271, v271 + v270)
			v266.Transparency = 1 - v253 * (1 - v251)
			v266.Color = v_u_8:Lerp(v_u_10, (math.max(v264, 0.35)))
		end
		local v272 = p244.dot
		if v272 then
			v272.CFrame = v261 * CFrame.Angles(0, 0.7853981633974483, 0)
			v272.Transparency = 1 - v253 * (1 - v251)
		end
	end
	local function v_u_324(p274) -- name: openStrike
		-- upvalues: (copy) p_u_61, (ref) v_u_27, (ref) v_u_1, (ref) v_u_7, (ref) v_u_8, (ref) v_u_11, (ref) v_u_10, (copy) v_u_228, (copy) v_u_243, (copy) v_u_229, (ref) v_u_5, (ref) v_u_51, (ref) v_u_4, (copy) v_u_273
		local v275 = p_u_61.ground(p274.origin + p274.dir * 6, 0.15)
		local v276 = p_u_61.ground(p274.target, 0.15)
		if (v276 - v275).Magnitude < 4 then
			v276 = v275 + p274.dir * 30
		end
		local v_u_277 = v275:Lerp(v276, 0.55) + Vector3.new(0, 40, 0)
		local v_u_278 = {
			["sat"] = nil,
			["satAt"] = nil,
			["marks"] = nil,
			["near"] = nil,
			["far"] = nil,
			["born"] = nil,
			["closeAt"] = nil,
			["sat"] = {},
			["satAt"] = v_u_277,
			["marks"] = {},
			["near"] = v275,
			["far"] = v276,
			["born"] = os.clock()
		}
		local function v286(p279, p280, p281, p282, p283) -- name: piece
			-- upvalues: (ref) v_u_27, (copy) v_u_277, (ref) v_u_1, (copy) v_u_278
			local v284 = v_u_27(CFrame.new(v_u_277), 0.05, p279, p281, p282)
			v_u_1:AddItem(v284, 3)
			local v285 = v_u_278.sat
			table.insert(v285, {
				["p"] = v284,
				["r"] = p280,
				["spin"] = p283
			})
		end
		v286(v_u_7.Glow, 7, v_u_8, 0.3, 0)
		v286(v_u_7.VoidCross, 6, v_u_11, 0.35, 0.7)
		v286(v_u_7.Ring, 4.4, v_u_8, 0.05, -1.2)
		v286(p_u_61.iris("void_gaze"), 3.2, v_u_10, 0, 0)
		for v287, v288 in v_u_228 do
			local v289 = v287 == #v_u_228 and 0 or (v287 % 2 == 0 and 2 or -2)
			local v290 = v275:Lerp(v276, v288) + p_u_61.flatUnit(v276 - v275):Cross(Vector3.new(0, 1, 0)) * v289
			local v291 = v_u_278.marks
			local v292 = v_u_243(p274, v290, v_u_229[v287], 0.02 + (v287 - 1) * 0.035, 4)
			table.insert(v291, v292)
		end
		if not p274.lite then
			for _, v293 in v_u_278.marks do
				local v294 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_277), v_u_11, {
					["transparency"] = 0.2
				})
				v_u_51(v294, v_u_277, v293.at, 0.16)
				v_u_5.tween(v294, 0.35, {
					["Transparency"] = 1
				})
				v_u_1:AddItem(v294, 0.4)
			end
			p_u_61.groundLine(v275, v276, 0.5, v_u_11, 0.35, 0.3)
		end
		local v_u_295 = p274.lite
		p_u_61.runNow(function()
			-- upvalues: (copy) v_u_278, (ref) p_u_61, (copy) v_u_277, (ref) v_u_4, (ref) v_u_273, (copy) v_u_295
			local v296 = os.clock()
			local v297 = v296 - v_u_278.born
			local v298 = v297 / 0.2
			local v299 = math.clamp(v298, 0, 1) - 1
			local v300 = v299 * 2.9 * v299 * v299 + 1 + v299 * 1.9 * v299
			local v301 = v_u_278.closeAt
			if v301 then
				local v302 = 1 - (v296 - v301) / 0.25
				v300 = v300 * math.max(v302, 0)
			end
			local v303 = p_u_61.facing
			local v304 = v_u_277
			local v305 = v_u_277
			local v306 = v_u_4.CurrentCamera
			local v307
			if v306 then
				local v308 = v306.CFrame.Position - v305
				v307 = v308.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v308.Unit
			else
				v307 = Vector3.new(0, 0, 1)
			end
			local v309 = v303(v304, v307)
			for v310, v311 in v_u_278.sat do
				local v312 = v311.p
				local v313 = v311.r * v300
				local v314 = math.max(v313, 0.03) * 2
				v312.Size = Vector3.new(v314, 0.05, v314)
				v311.p.CFrame = v309 * CFrame.new(0, (v310 - 2) * 0.06, 0) * CFrame.Angles(0, v311.spin * v297, 0)
			end
			for _, v315 in v_u_278.marks do
				v_u_273(v315, v297, v_u_295)
			end
			local v316 = true
			for _, v317 in v_u_278.marks do
				local v318 = v317.fadeAt
				if v318 and v296 - v318 >= 0.32 then
					continue
				end
				v316 = false
			end
			local v319
			if v301 == nil then
				v319 = false
			else
				v319 = v296 - v301 >= 0.25
			end
			if not (v316 and v319) and v297 <= 3 then
				return true
			end
			for _, v320 in v_u_278.sat do
				v320.p:Destroy()
			end
			for _, v321 in v_u_278.marks do
				v321.ring:Destroy()
				for _, v322 in v321.ticks do
					v322:Destroy()
				end
				local v323 = v321.dot
				if not v323 then
					break
				end
				v323:Destroy()
			end
			return false
		end)
		return v_u_278
	end
	local function v_u_330(p325, p326, p327, p328) -- name: touchdown
		-- upvalues: (copy) p_u_61, (ref) v_u_10, (ref) v_u_5, (ref) v_u_11, (ref) v_u_7, (ref) v_u_8, (ref) v_u_6, (ref) v_u_9
		p_u_61.pop(p326 + Vector3.new(0, 1, 0), v_u_10, 2, p327 * 1.5, 0.22)
		v_u_5.ring(p326, v_u_11, p327 * 1.3, 0.35, v_u_7.Ring)
		p_u_61.burst("Shockwave", p326 + Vector3.new(0, 0.3, 0), v_u_8, p327 / 16)
		if not p325.lite then
			p_u_61.mark(p326, v_u_8, p327 * 0.8, 1.4, v_u_7.CrackGlow, 0.15)
			p_u_61.spikes(p326 + Vector3.new(0, 0.5, 0), v_u_11, 5, p327 * 1.1, 0.25, Vector3.new(0, 1, 0), 0.7)
		end
		if p328 then
			p_u_61.burst("Explosion", p326 + Vector3.new(0, 2, 0), v_u_8, 1.5)
			p_u_61.pop(p326 + Vector3.new(0, 2, 0), v_u_8, 4, p327 * 2.4, 0.4, 0.35)
			v_u_6.play("Explosion", {
				["at"] = nil,
				["volume"] = 0.85,
				["at"] = p326
			})
			if p325.mine then
				v_u_5.shake(0.5, 0.4)
			end
			if not p325.lite then
				local v329 = { v_u_9, v_u_8, v_u_11 }
				p_u_61.chunks(p326 + Vector3.new(0, 1, 0), v329, 10, 38, 1.1, 0.9)
				return
			end
		else
			v_u_6.play("Hit", {
				["at"] = nil,
				["volume"] = 0.45,
				["at"] = p326
			})
			if p325.mine then
				v_u_5.shake(0.2, 0.15)
			end
		end
	end
	local function v_u_358(p_u_331, p_u_332, p_u_333) -- name: orbitalLaser
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_15, (ref) v_u_8, (ref) v_u_12, (ref) v_u_1, (copy) p_u_61, (ref) v_u_51, (copy) v_u_330
		local v_u_334 = p_u_332.at
		local v_u_335 = v_u_334 + Vector3.new(0, 150, 0)
		local v_u_336 = p_u_333 and 12 or p_u_332.r * 0.4 + 4.4
		local v337 = {
			["shape"] = v_u_15
		}
		local v_u_338 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_335), v_u_10, v337)
		local v339 = {
			["shape"] = nil,
			["transparency"] = 0.5,
			["shape"] = v_u_15
		}
		local v_u_340 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_335), v_u_8, v339)
		local v_u_341
		if p_u_331.lite then
			v_u_341 = nil
		else
			local v342 = {
				["shape"] = nil,
				["transparency"] = 0.8,
				["shape"] = v_u_15
			}
			v_u_341 = v_u_5.part(Vector3.new(1, 1, 1), CFrame.new(v_u_335), v_u_12, v342)
		end
		v_u_1:AddItem(v_u_338, 1.21)
		v_u_1:AddItem(v_u_340, 1.21)
		if v_u_341 then
			v_u_1:AddItem(v_u_341, 1.21)
		end
		if p_u_331.mine and p_u_333 then
			p_u_61.light(v_u_338, v_u_8, 24)
		end
		local v_u_343 = os.clock()
		local v_u_344 = false
		p_u_61.runNow(function()
			-- upvalues: (copy) v_u_343, (copy) v_u_335, (copy) v_u_334, (ref) v_u_51, (copy) v_u_338, (copy) v_u_336, (copy) v_u_340, (ref) v_u_341, (ref) v_u_344, (ref) v_u_330, (copy) p_u_331, (copy) p_u_333, (copy) p_u_332
			local v345 = os.clock() - v_u_343
			local v346
			if v345 < 0.04 then
				v346 = v_u_335:Lerp(v_u_334, v345 / 0.04)
			else
				v346 = v_u_334
			end
			local v347
			if v345 < 0.04 then
				v347 = 0.05
			elseif v345 < 0.13 then
				local v348 = (v345 - 0.04) / 0.09 - 1
				v347 = (v348 * 2.9 * v348 * v348 + 1 + v348 * 1.9 * v348) * 0.95 + 0.05
			elseif v345 < 0.45 then
				local v349 = v345 * 70
				v347 = math.sin(v349) * 0.06 + 1
			else
				local v350 = 1 - (v345 - 0.04 - 0.09 - 0.32) / 0.26
				v347 = math.max(v350, 0)
			end
			local v351 = v_u_51
			local v352 = v_u_338
			local v353 = v_u_335
			local v354 = v_u_336 * 0.38 * v347
			local v355 = v347 * 20
			local v356 = math.min(v355, 1) * 0.3
			v351(v352, v353, v346, (math.max(v354, v356)))
			v_u_51(v_u_340, v_u_335, v346, v_u_336 * 0.75 * v347)
			local v357 = v_u_341
			if v357 then
				v_u_51(v357, v_u_335, v346, v_u_336 * 1.35 * v347)
			end
			if not v_u_344 and v345 >= 0.04 then
				v_u_344 = true
				v_u_330(p_u_331, v_u_334, v_u_336, p_u_333)
			end
			if v345 <= 0.71 then
				return true
			end
			v_u_338:Destroy()
			v_u_340:Destroy()
			if v357 then
				v357:Destroy()
			end
			p_u_332.fadeAt = os.clock()
			return false
		end)
	end
	v62.void_gaze_r = {
		["castSound"] = "Laser",
		["cast"] = nil,
		["windup"] = nil,
		["beam"] = nil,
		["hit"] = nil,
		["cast"] = function(p359) -- name: cast
			-- upvalues: (copy) p_u_61, (ref) v_u_8, (ref) v_u_11, (ref) v_u_60
			p_u_61.skillCast(p359, v_u_8, true)
			p_u_61.glint(p359.eye, v_u_11, 5 * p359.size, 0.25)
			if p359.mine then
				v_u_60(Color3.fromRGB(200, 218, 255), -0.06, 0.12, 0.15, 0.75, 0.45)
			end
		end,
		["windup"] = function(p360, _, _) -- name: windup
			-- upvalues: (copy) v_u_230, (copy) v_u_324
			v_u_230[p360] = v_u_324(p360)
		end,
		["beam"] = function(p_u_361, _, _) -- name: beam
			-- upvalues: (copy) v_u_230, (copy) v_u_324, (copy) p_u_61, (copy) v_u_358, (ref) v_u_11, (ref) v_u_8
			local v_u_362 = v_u_230[p_u_361] or v_u_324(p_u_361)
			v_u_230[p_u_361] = nil
			local v_u_363 = #v_u_362.marks
			for v_u_364, v_u_365 in v_u_362.marks do
				p_u_61.after((v_u_364 - 1) * 0.045, function()
					-- upvalues: (ref) v_u_358, (copy) p_u_361, (copy) v_u_365, (copy) v_u_364, (copy) v_u_363, (ref) p_u_61, (copy) v_u_362, (ref) v_u_11
					v_u_358(p_u_361, v_u_365, v_u_364 == v_u_363)
					p_u_61.pop(v_u_362.satAt, v_u_11, 3, 9, 0.18, 0.2)
				end)
			end
			p_u_61.groundLine(v_u_362.near, v_u_362.far, 4, v_u_8, 1.1, 0.25)
			p_u_61.after((v_u_363 - 1) * 0.045 + 0.04 + 0.09 + 0.32, function()
				-- upvalues: (copy) v_u_362
				v_u_362.closeAt = os.clock()
			end)
		end,
		["hit"] = function(p366, p367, _) -- name: hit
			-- upvalues: (copy) p_u_61, (ref) v_u_8, (copy) v_u_85
			p_u_61.burst("Impact", p367, v_u_8, 0.8)
			if not p366.lite then
				v_u_85(CFrame.new(p367 + Vector3.new(0, -1, 0)), 2.8, 1, v_u_8, 0.2)
			end
		end
	}
	return v62
end