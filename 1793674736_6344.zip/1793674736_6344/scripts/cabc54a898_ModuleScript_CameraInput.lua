game:GetService("ContextActionService")
local v_u_1 = game:GetService("UserInputService")
game:GetService("Players")
local v_u_2 = UserSettings():GetService("UserGameSettings")
game:GetService("VRService")
local v3 = game:GetService("GuiService")
local v4 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v5 = v4.getUserFlag("UserPSTextboxResetCameraInput")
local v_u_6 = v4.getUserFlag("UserPlayerScriptsSupportTVRemoteKeycodes")
local v7 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext")
local v_u_8 = v7:WaitForChild("CameraRotationAction")
local v_u_9 = v7:WaitForChild("CameraZoomAction")
local v_u_10 = v_u_8:WaitForChild("GamepadBinding")
local v_u_11
if v_u_6 then
	v_u_11 = v_u_8:WaitForChild("MicroGamepadBinding")
else
	v_u_11 = nil
end
local v_u_12 = v_u_8:WaitForChild("MouseBinding")
local v_u_13 = v_u_8:WaitForChild("TrackpadBinding")
local v_u_14 = v7:WaitForChild("CameraToggleAction")
local v_u_15 = v7:WaitForChild("CameraPanActiveAction")
local v_u_16 = 1
local function v_u_20() -- name: updateCameraYInvert
	-- upvalues: (copy) v_u_2, (ref) v_u_16, (copy) v_u_8
	local v17 = v_u_2:GetCameraYInvertValue()
	if v17 ~= v_u_16 then
		v_u_16 = v17
		for _, v18 in v_u_8:GetChildren() do
			if not v18:IsA("InputBinding") then
				continue
			end
			local v19 = v18.Vector2Scale
			v18.Vector2Scale = Vector2.new(v19.X, -v19.Y)
		end
	end
end
local function v22() -- name: updateMouseCameraSensitivity
	-- upvalues: (copy) v_u_2, (copy) v_u_12, (copy) v_u_13
	local v21 = v_u_2.MouseSensitivity
	v_u_12.Scale = v21
	v_u_13.Scale = v21
end
v_u_2:GetPropertyChangedSignal("GamepadCameraSensitivity"):Connect(function() -- name: updateGamepadCameraSensitivity
	-- upvalues: (copy) v_u_10, (copy) v_u_2, (copy) v_u_6, (copy) v_u_11
	v_u_10.Scale = v_u_2.GamepadCameraSensitivity
	if v_u_6 and v_u_11 then
		v_u_11.Scale = v_u_2.GamepadCameraSensitivity
	end
end)
v_u_10.Scale = v_u_2.GamepadCameraSensitivity
if v_u_6 and v_u_11 then
	v_u_11.Scale = v_u_2.GamepadCameraSensitivity
end
v_u_2:GetPropertyChangedSignal("MouseSensitivity"):Connect(v22)
local v23 = v_u_2.MouseSensitivity
v_u_12.Scale = v23
v_u_13.Scale = v23
v_u_20()
local function v_u_28(p24) -- name: adjustTouchPitchSensitivity
	local v25 = workspace.CurrentCamera
	if not v25 then
		return p24
	end
	local v26 = v25.CFrame:ToEulerAnglesYXZ()
	if p24.Y * v26 >= 0 then
		return p24
	end
	local v27 = (1 - (math.abs(v26) * 2 / 3.141592653589793) ^ 0.75) * 0.75 + 0.25
	return Vector2.new(1, v27) * p24
end
local v29 = {}
local v_u_30 = 0
local function v32() -- name: incPanInputCount
	-- upvalues: (ref) v_u_30
	local v31 = v_u_30 + 1
	v_u_30 = math.max(0, v31)
end
local function v34() -- name: decPanInputCount
	-- upvalues: (ref) v_u_30
	local v33 = v_u_30 - 1
	v_u_30 = math.max(0, v33)
end
local function v35() -- name: resetPanInputCount
	-- upvalues: (ref) v_u_30
	v_u_30 = 0
end
function v29.getRotationActivated() -- name: getRotationActivated
	-- upvalues: (ref) v_u_30, (copy) v_u_8
	return v_u_30 > 0 and true or v_u_8:GetState().Magnitude > 0
end
function v29.getPanActivated() -- name: getPanActivated
	-- upvalues: (ref) v_u_30
	return v_u_30 > 0
end
function v29.getRotation(p36) -- name: getRotation
	-- upvalues: (copy) v_u_20, (copy) v_u_8, (copy) v_u_1, (copy) v_u_28
	v_u_20()
	local v37 = v_u_8:GetState() * p36
	if v_u_1.PreferredInput == Enum.PreferredInput.Touch then
		v37 = v_u_28(v37)
	end
	return v37
end
function v29.getZoomDelta(p38) -- name: getZoomDelta
	-- upvalues: (copy) v_u_9
	return v_u_9:GetState() * p38
end
v_u_15.Pressed:Connect(v32)
v_u_15.Released:Connect(v34)
local v_u_39 = false
function v29.setInputEnabled(p40) -- name: setInputEnabled
	-- upvalues: (ref) v_u_39, (ref) v_u_30, (copy) v_u_9, (copy) v_u_8, (copy) v_u_15
	if v_u_39 == p40 then
		return
	else
		v_u_39 = p40
		v_u_30 = 0
		if v_u_39 then
			v_u_9.Enabled = true
			v_u_8.Enabled = true
			v_u_15.Enabled = true
		else
			v_u_9.Enabled = false
			v_u_8.Enabled = false
			v_u_15.Enabled = false
		end
	end
end
function v29.getInputEnabled() -- name: getInputEnabled
	-- upvalues: (ref) v_u_39
	return v_u_39
end
v_u_1.WindowFocused:Connect(v35)
v_u_1.WindowFocusReleased:Connect(v35)
v3.MenuOpened:Connect(v35)
if v5 then
	v_u_1.TextBoxFocusReleased:Connect(v35)
end
local v_u_41 = false
local v_u_42 = false
local v_u_43 = 0
function v29.getHoldPan() -- name: getHoldPan
	-- upvalues: (ref) v_u_41
	return v_u_41
end
function v29.getTogglePan() -- name: getTogglePan
	-- upvalues: (ref) v_u_42
	return v_u_42
end
function v29.getPanning() -- name: getPanning
	-- upvalues: (ref) v_u_42, (ref) v_u_41
	return v_u_42 or v_u_41
end
function v29.setTogglePan(p44) -- name: setTogglePan
	-- upvalues: (ref) v_u_42
	v_u_42 = p44
end
local v_u_45 = false
v_u_14.Pressed:Connect(function()
	-- upvalues: (ref) v_u_41, (ref) v_u_43
	v_u_41 = true
	v_u_43 = tick()
end)
v_u_14.Released:Connect(function()
	-- upvalues: (ref) v_u_41, (ref) v_u_43, (ref) v_u_42, (copy) v_u_1
	v_u_41 = false
	if tick() - v_u_43 < 0.3 and (v_u_42 or v_u_1:GetMouseDelta().Magnitude < 2) then
		v_u_42 = not v_u_42
	end
end)
function v29.enableCameraToggleInput() -- name: enableCameraToggleInput
	-- upvalues: (ref) v_u_45, (ref) v_u_41, (ref) v_u_42, (copy) v_u_14
	if not v_u_45 then
		v_u_45 = true
		v_u_41 = false
		v_u_42 = false
		v_u_14.Enabled = true
	end
end
function v29.disableCameraToggleInput() -- name: disableCameraToggleInput
	-- upvalues: (ref) v_u_45, (copy) v_u_14
	if v_u_45 then
		v_u_45 = false
		v_u_14.Enabled = false
	end
end
return v29