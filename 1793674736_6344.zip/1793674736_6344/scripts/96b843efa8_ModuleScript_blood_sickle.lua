local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.Parent.EpicKit8)
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v4 = require(script.Parent.Parent.Preload)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v1.Shared.Config.Textures)
v4.images({
	v_u_6.ObiSash,
	v_u_6.SickleX,
	v_u_6.PoisonSplat,
	v_u_6.FxSmoke
})
local v_u_7 = Color3.fromRGB(70, 4, 18)
local v_u_8 = Color3.fromRGB(40, 20, 16)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.Material.Neon
local v_u_12 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_13 = CFrame.identity
local function v_u_18(p14, p15, p16) -- name: floorEmitter
	local v17 = Instance.new("ParticleEmitter")
	v17.Texture = p14
	v17.Color = ColorSequence.new(p15)
	v17.LightEmission = p16
	v17.LightInfluence = 0
	v17.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v17.EmissionDirection = Enum.NormalId.Top
	v17.SpreadAngle = Vector2.zero
	v17.Speed = NumberRange.new(0.01)
	v17.Rate = 0
	v17.Enabled = false
	v17.LockedToPart = true
	return v17
end
return function(p_u_19)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_13, (copy) v_u_8, (copy) v_u_10, (copy) v_u_11, (copy) v_u_6, (copy) v_u_9, (copy) v_u_7, (copy) v_u_12, (copy) v_u_18
	return {
		["w8_blood_sickle"] = function(p_u_20, p21)
			-- upvalues: (ref) v_u_3, (ref) v_u_5, (copy) p_u_19, (ref) v_u_2, (ref) v_u_13, (ref) v_u_8, (ref) v_u_10, (ref) v_u_11, (ref) v_u_6, (ref) v_u_9, (ref) v_u_7, (ref) v_u_12, (ref) v_u_18
			local v22 = v_u_3.color(p21.color)
			local v23 = v_u_3.color(p21.color2)
			local v24 = p_u_20.headY / 1.5
			local v_u_25 = math.clamp(v24, 0.7, 3)
			local v26 = p_u_20.fx
			local v27 = math.min(v26, 1.6)
			local v28 = v_u_5.formRate()
			local v_u_29 = p_u_19.throb(p_u_20, 5, 1.4, 1.4)
			local v_u_30 = p_u_19.backOf(p_u_20)
			local v31 = v_u_2.piece("w8_blood_sickle", v_u_25 * 4.2)
			if v31 then
				local v_u_32 = v_u_13 * v_u_2.thinZ(v31)
				p_u_19.glue(p_u_20, v31, function(p33)
					-- upvalues: (copy) v_u_30, (copy) v_u_25, (copy) v_u_32
					return p33 * v_u_30 * CFrame.new(0, v_u_25 * 0.15, v_u_25 * 0.3) * v_u_32
				end)
			else
				v31 = nil
				for _, v34 in { -1, 1 } do
					local v_u_35 = CFrame.new(0, v_u_25 * 0.15, v_u_25 * 0.32) * CFrame.Angles(0, 0, v34 * 0.62)
					local v36 = p_u_19.bar(Vector3.new(0.16, 1.9, 0.16) * v_u_25, v_u_8, 0, v_u_10)
					p_u_19.glue(p_u_20, v36, function(p37)
						-- upvalues: (copy) v_u_30, (copy) v_u_35, (copy) v_u_25
						return p37 * v_u_30 * v_u_35 * CFrame.new(0, v_u_25 * -0.45, 0)
					end)
					local v38 = v34 * 0.7
					local v39 = Vector3.new(v38, 0.5, 0) * v_u_25
					local v40 = v_u_25 * 0.7
					v31 = v31 or v36
					local v41 = nil
					for v42 = 0, 4 do
						local v43
						if v34 > 0 then
							v43 = 180 - v42 * 40
						else
							v43 = v42 * 40
						end
						local v44 = math.rad(v43)
						local v45 = math.cos(v44)
						local v46 = math.sin(v44)
						local v47 = v39 + Vector3.new(v45, v46, 0) * v40
						if v41 then
							local v48 = (v47 - v41).Magnitude * 1.1
							local v49 = (0.34 - v42 * 0.06) * v_u_25
							local v50 = p_u_19.bar
							local v51 = v_u_25 * 0.1
							local v52 = v50(Vector3.new(v48, v49, v51), v22, 0, v_u_11)
							local v_u_53 = (v47 + v41) / 2
							local v54 = v47.Y - v41.Y
							local v55 = v47.X - v41.X
							local v_u_56 = math.atan2(v54, v55)
							p_u_19.glue(p_u_20, v52, function(p57)
								-- upvalues: (copy) v_u_30, (copy) v_u_35, (copy) v_u_53, (copy) v_u_56
								return p57 * v_u_30 * v_u_35 * CFrame.new(v_u_53) * CFrame.Angles(0, 0, v_u_56)
							end)
						end
						v41 = v47
					end
				end
			end
			local v58 = Instance.new("Attachment")
			v58.Parent = v31
			p_u_19.own(p_u_20, v58)
			local v59 = Instance.new("ParticleEmitter")
			v59.Texture = v_u_6.PoisonSplat
			v59.Color = ColorSequence.new(v23)
			v59.LightEmission = 0.4
			v59.LightInfluence = 0
			v59.Lifetime = NumberRange.new(0.6, 0.9)
			v59.Size = NumberSequence.new(v_u_25 * 0.14)
			v59.Speed = NumberRange.new(0.5)
			v59.SpreadAngle = Vector2.new(180, 180)
			v59.Acceleration = Vector3.new(0, -30, 0)
			v59:SetAttribute("BaseRate", 2)
			v59.Rate = 2 * v28
			v59.Parent = v58
			local v60 = v_u_3.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v22, {
				["transparency"] = 1
			})
			p_u_19.add(p_u_20, v60, function(p61)
				return p61
			end)
			p_u_19.own(p_u_20, v60)
			local v_u_62 = {}
			for _, v63 in { -1, 1 } do
				local v64 = Instance.new("Attachment")
				local v65 = v63 * 0.55 * v_u_25
				local v66 = v_u_25 * -0.5
				local v67 = v_u_25 * 0.25
				v64.Position = Vector3.new(v65, v66, v67)
				v64.Parent = v60
				local v68 = Instance.new("Attachment")
				v68.Parent = v60
				local v69 = v_u_2.beam(v64, v68, v_u_6.ObiSash, v_u_9, v_u_25 * 0.85, 0.15, v_u_25 * 3.2, 0)
				v69.Segments = 16
				v69.Width1 = v_u_25 * 0.6
				table.insert(v_u_62, {
					["a0"] = v64,
					["a1"] = v68,
					["beam"] = v69,
					["k"] = v63
				})
			end
			local v70 = p_u_20.ticks
			table.insert(v70, function(_, p71)
				-- upvalues: (copy) v_u_29, (copy) v_u_62, (copy) v_u_25
				local v72 = 1 + 1.3 * v_u_29()
				for _, v73 in v_u_62 do
					local v74 = v73.k
					local v75 = v73.a1
					local v76 = p71 * 1.3 + v74
					local v77 = v74 * (math.sin(v76) * 0.4 + 2.3) * v_u_25 * v72
					local v78 = p71 * 1.7 + v74 * 2
					local v79 = (math.sin(v78) * 0.6 + 0.2) * v_u_25
					local v80 = p71 * 1.1 + v74
					local v81 = (math.cos(v80) * 0.5 + 2.6) * v_u_25
					v75.Position = Vector3.new(v77, v79, v81)
					local v82 = v73.beam
					local v83 = p71 * 2.1 + v74
					v82.CurveSize0 = math.sin(v83) * 1.3 * v_u_25
					local v84 = v73.beam
					local v85 = p71 * 1.6 + v74 * 1.5
					v84.CurveSize1 = math.cos(v85) * 1.1 * v_u_25
				end
			end)
			local v86 = Instance.new("Attachment")
			local v87 = v_u_25 * 0.5
			local v88 = v_u_25 * -1.5
			v86.Position = Vector3.new(0, v87, v88)
			v86.Parent = v60
			local v_u_89 = Instance.new("ParticleEmitter")
			v_u_89.Texture = v_u_6.SickleX
			v_u_89.Color = ColorSequence.new(v22)
			v_u_89.LightEmission = 0.5
			v_u_89.LightInfluence = 0
			v_u_89.Lifetime = NumberRange.new(0.45)
			v_u_89.Size = v_u_2.seq({
				{ 0, 0.6 },
				{ 0.2, 1.9 },
				{ 1, 2.2 }
			}, v_u_25 * v27)
			v_u_89.Transparency = v_u_2.seq({
				{ 0, 0.2 },
				{ 0.3, 0 },
				{ 1, 1 }
			})
			v_u_89.Speed = NumberRange.new(0)
			v_u_89.Rotation = NumberRange.new(-10, 10)
			v_u_89.LockedToPart = true
			v_u_89.Rate = 0
			v_u_89.Enabled = false
			v_u_89.Parent = v86
			local v_u_90 = Instance.new("ParticleEmitter")
			v_u_90.Texture = v_u_6.PoisonSplat
			v_u_90.Color = ColorSequence.new(v23)
			v_u_90.LightEmission = 0.5
			v_u_90.LightInfluence = 0
			v_u_90.Lifetime = NumberRange.new(0.4, 0.7)
			v_u_90.Size = v_u_2.seq({
				{ 0, 0.4 },
				{ 1, 0.15 }
			}, v_u_25 * v27)
			v_u_90.Speed = NumberRange.new(v_u_25 * 6, v_u_25 * 10)
			v_u_90.SpreadAngle = Vector2.new(180, 180)
			v_u_90.Acceleration = Vector3.new(0, -30, 0)
			v_u_90.Drag = 1.5
			v_u_90.Rate = 0
			v_u_90.Enabled = false
			v_u_90.Parent = v86
			local v91 = v_u_3.part
			local v92 = v_u_25 * 2.4
			local v93 = v_u_25 * 2.4
			local v94 = v91(Vector3.new(v92, 0.2, v93), CFrame.identity, v_u_7, {
				["transparency"] = 1
			})
			v94.Massless = true
			p_u_19.add(p_u_20, v94, function(p95)
				-- upvalues: (ref) p_u_19, (copy) p_u_20
				return CFrame.new(p_u_19.feetAt(p_u_20, p95, 0.1))
			end)
			p_u_19.own(p_u_20, v94)
			local v96 = Instance.new("Attachment")
			v96.Parent = v94
			local v97 = Instance.new("ParticleEmitter")
			v97.Texture = v_u_6.FxSmoke
			v97.FlipbookLayout = v_u_12
			v97.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v97.Color = ColorSequence.new(v23, Color3.fromRGB(60, 120, 20))
			v97.LightEmission = 0.1
			v97.LightInfluence = 0
			v97.Lifetime = NumberRange.new(1.4, 2)
			v97.Size = v_u_2.seq({
				{ 0, 1.2 },
				{ 1, 2.4 }
			}, v_u_25 * p_u_20.fx)
			v97.Transparency = v_u_2.seq({
				{ 0, 1 },
				{ 0.25, 0.62 },
				{ 0.7, 0.7 },
				{ 1, 1 }
			})
			v97.Speed = NumberRange.new(v_u_25 * 0.3, v_u_25 * 0.8)
			v97.SpreadAngle = Vector2.new(80, 80)
			v97.EmissionDirection = Enum.NormalId.Top
			v97.Rotation = NumberRange.new(0, 360)
			v97.RotSpeed = NumberRange.new(-20, 20)
			v97.Shape = Enum.ParticleEmitterShape.Box
			v97.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v97:SetAttribute("BaseRate", 4)
			v97.Rate = 4 * v28
			v97.Parent = v94
			local v_u_98 = v_u_18(v_u_6.SickleX, v22, 0.35)
			v_u_98.Lifetime = NumberRange.new(0.9)
			v_u_98.Size = v_u_2.seq({
				{ 0, 2 },
				{ 0.15, 3.6 },
				{ 1, 3.8 }
			}, v_u_25 * v27)
			v_u_98.Transparency = v_u_2.seq({
				{ 0, 0.3 },
				{ 0.15, 0 },
				{ 0.6, 0.2 },
				{ 1, 1 }
			})
			v_u_98.Parent = v96
			local v_u_99 = v_u_18(v_u_6.PoisonSplat, v23, 0.3)
			v_u_99.Lifetime = NumberRange.new(1)
			v_u_99.Size = v_u_2.seq({
				{ 0, 0.8 },
				{ 0.15, 2 },
				{ 1, 2.2 }
			}, v_u_25 * v27)
			v_u_99.Transparency = v_u_2.seq({
				{ 0, 0.2 },
				{ 0.6, 0.3 },
				{ 1, 1 }
			})
			v_u_99.Rotation = NumberRange.new(0, 360)
			v_u_99.Parent = v96
			local v_u_100 = -1
			local v101 = p_u_20.ticks
			local function v105(p102)
				-- upvalues: (copy) v_u_29, (ref) v_u_100, (ref) p_u_19, (copy) v_u_89, (copy) v_u_98, (copy) v_u_99, (copy) v_u_90, (ref) v_u_5
				local v103 = v_u_29() * 20
				local v104 = math.floor(v103) / 20
				if v104 ~= v_u_100 then
					if v104 > 0.95 and (v_u_100 <= 0.95 and (p102.Position - p_u_19.camPos()).Magnitude < 150) then
						v_u_89:Emit(1)
						v_u_98:Emit(1)
						v_u_99:Emit(1)
						v_u_90:Emit(v_u_5.level() >= 2 and 10 or 4)
					end
					v_u_100 = v104
				end
			end
			table.insert(v101, v105)
		end
	}
end