local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromRGB(255, 211, 26)
local v_u_9 = Color3.fromRGB(255, 242, 122)
local v_u_10 = Color3.fromRGB(235, 145, 15)
local v_u_11 = Color3.fromRGB(120, 78, 12)
local v_u_12 = Color3.fromRGB(255, 140, 20)
local v_u_13 = Color3.fromRGB(110, 55, 5)
local v_u_14 = Color3.fromRGB(255, 255, 255)
return function(p_u_15)
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_4, (copy) v_u_8, (copy) v_u_14, (copy) v_u_9, (copy) v_u_11, (copy) v_u_10, (copy) v_u_7, (copy) v_u_6, (copy) v_u_13, (copy) v_u_12, (copy) v_u_2
	local function v_u_16() -- name: newBody
		return {
			["parts"] = {},
			["offs"] = {},
			["sizes"] = {},
			["alphas"] = {}
		}
	end
	local function v_u_30(p17, p18, p19, p20, p21, p22, p23) -- name: add
		-- upvalues: (ref) v_u_5, (ref) v_u_1
		local v24 = v_u_5.part(p18, p19, p20, {
			["transparency"] = 1
		})
		if p22 then
			local v25 = Instance.new("SpecialMesh")
			v25.MeshType = Enum.MeshType.Sphere
			v25.Parent = v24
		end
		v_u_1:AddItem(v24, p23)
		local v26 = p17.parts
		table.insert(v26, v24)
		local v27 = p17.offs
		table.insert(v27, p19)
		local v28 = p17.sizes
		table.insert(v28, p18)
		local v29 = p17.alphas
		table.insert(v29, p21)
		return v24
	end
	local function v_u_41(p31, p32, p33, p34) -- name: place
		local v35 = math.max(p33, 0.02)
		local v36 = math.clamp(p34, 0, 1)
		for v37, v38 in p31.parts do
			local v39 = p31.offs[v37]
			v38.CFrame = p32 * (v39 - v39.Position + v39.Position * v35)
			v38.Size = p31.sizes[v37] * v35
			local v40 = p31.alphas[v37]
			v38.Transparency = v40 + (1 - v40) * v36
		end
	end
	local function v_u_59(p42, p43, p44, p45, p46, p47, p48) -- name: wave
		-- upvalues: (ref) v_u_5, (ref) v_u_1
		local v49 = v_u_5.part
		local v50 = p43 * 2
		local v51 = p43 * 2
		local v52 = v49(Vector3.new(v50, 0.05, v51), p42, p46, {
			["transparency"] = 1
		})
		for _, v53 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
			local v54 = Instance.new("Decal")
			v54.Face = v53
			v54.Texture = p47
			v54.Color3 = p46
			v54.Transparency = p48 or 0
			v54.Parent = v52
			v_u_5.tween(v54, p45, {
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
		local v55 = v_u_5.tween
		local v56 = {}
		local v57 = p44 * 2
		local v58 = p44 * 2
		v56.Size = Vector3.new(v57, 0.05, v58)
		v55(v52, p45, v56, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
		v_u_1:AddItem(v52, p45 + 0.05)
	end
	local function v_u_77(p60, p61, p62, p63, p_u_64) -- name: slashLine
		-- upvalues: (ref) v_u_4, (ref) v_u_5, (copy) p_u_15, (ref) v_u_1
		local v65 = p61 - p60
		local v_u_66 = v65.Magnitude
		if v_u_66 >= 0.1 then
			local v67 = v_u_4.CurrentCamera
			local v68 = not v67 and Vector3.new(0, 1, 0) or v67.CFrame.Position - p60
			local v69
			if v68.Magnitude < 0.1 then
				v69 = Vector3.new(0, 1, 0)
			else
				local v70 = v68.Unit:Dot(v65.Unit)
				v69 = math.abs(v70) > 0.95 and Vector3.new(0, 1, 0) or v68
			end
			local v_u_71 = v_u_5.part(Vector3.new(p62, 0.15, 0.3), CFrame.lookAt(p60, p60 + v65, v69) * CFrame.new(0, 0, -0.15), p63)
			v_u_5.tween(v_u_71, 0.05, {
				["Size"] = Vector3.new(p62, 0.15, v_u_66),
				["CFrame"] = CFrame.lookAt(p60 + v65 / 2, p61, v69)
			})
			p_u_15.after(0.05, function()
				-- upvalues: (copy) v_u_71, (ref) v_u_5, (copy) p_u_64, (copy) v_u_66
				if v_u_71.Parent then
					local v72 = v_u_5.tween
					local v73 = v_u_71
					local v74 = p_u_64
					local v75 = {
						["Size"] = nil,
						["Transparency"] = 1
					}
					local v76 = v_u_66 * 1.1
					v75.Size = Vector3.new(0.05, 0.05, v76)
					v72(v73, v74, v75, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				end
			end)
			v_u_1:AddItem(v_u_71, p_u_64 + 0.15)
		end
	end
	local function v_u_87(p78, p79, p80, p81, p82) -- name: rake
		-- upvalues: (copy) p_u_15, (copy) v_u_77
		local v83 = p_u_15.aimAt(p78, -p79)
		for v84 = -1, 1 do
			local v85 = Vector3.new(0.81, 0.59, 0) * v84 * 1.2 * p80
			local v86 = v84 == 0 and 1.2 or 1
			v_u_77(v83 * (v85 - Vector3.new(1.25, -1.7, 0) * p80 * v86), v83 * (v85 + Vector3.new(1.25, -1.7, 0) * p80 * v86), (v84 == 0 and 0.75 or 0.55) * p80, p82, p81)
		end
	end
	local function v_u_99(p88, p89) -- name: clawStrokes
		local v90 = {}
		for v91 = -1, 1 do
			local v92 = v91 == 0 and 1.12 or 0.88
			local v93 = {}
			for v94 = 0, p89 - 1 do
				local v95 = v94 / (p89 - 1) * 2 - 1
				local v96 = 1 - v95 * v95
				local v97 = v95 * v95 * 1.5 - (v91 == 0 and 0.4 or 0)
				local v98 = (Vector3.new(1.25, -1.7, 0) * v95 * v92 + Vector3.new(0.81, 0.59, 0) * (v91 * 1.15 + v96 * 0.45) + Vector3.new(0, 0, v97)) * p88
				table.insert(v93, v98)
			end
			table.insert(v90, v93)
		end
		return v90
	end
	local function v137(p100, p101) -- name: fangShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) v_u_99, (ref) v_u_14, (ref) v_u_1, (copy) p_u_15, (ref) v_u_9
		local v102 = p100.size
		local v_u_103 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p101, v_u_8, {
			["transparency"] = 1
		})
		local v104 = p100.lite and 3 or 4
		local v_u_105 = {}
		for _, v106 in v_u_99(1.3 * v102, v104) do
			for v107 = 2, #v106 do
				local v108 = v106[v107 - 1]
				local v109 = v106[v107]
				local v110 = (v108 + v109) / 2
				local v111 = v109 - v108
				local v112 = v104 == 3 and true or v107 == 3
				local v113 = (v104 == 3 and 0.6 or (v112 and 0.74 or 0.42)) * v102
				local v114 = CFrame.lookAt(v110, v110 + v111, Vector3.new(0, 0, 1))
				local v115 = 0.16 * v102
				local v116 = v111.Magnitude + v113 * 0.5
				local v117 = Vector3.new(v113, v115, v116)
				local v118 = {
					["p"] = v_u_5.part(v117, p101 * v114, v_u_8),
					["off"] = v114,
					["size"] = v117
				}
				table.insert(v_u_105, v118)
				if not v112 or p100.lite then
					continue
				end
				local v119 = CFrame.new(0, 0, -0.06) * v114
				local v120 = v113 * 0.4
				local v121 = 0.22 * v102
				local v122 = v111.Magnitude * 1.05
				local v123 = Vector3.new(v120, v121, v122)
				local v124 = {
					["p"] = v_u_5.part(v123, p101 * v119, v_u_14),
					["off"] = v119,
					["size"] = v123
				}
				table.insert(v_u_105, v124)
			end
		end
		for _, v125 in v_u_105 do
			v_u_1:AddItem(v125.p, 6)
		end
		v_u_1:AddItem(v_u_103, 6)
		p_u_15.streak(v_u_103, v_u_8, v_u_9, 3.4 * v102, 0.12)
		if p100.mine then
			p_u_15.light(v_u_103, v_u_8, 9 * v102)
		end
		local v_u_126 = false
		local v_u_127 = false
		return {
			["place"] = function(p128, p129) -- name: place
				-- upvalues: (copy) v_u_103, (copy) v_u_105, (ref) v_u_127
				v_u_103.CFrame = p128
				local v130 = p129 * 0.7 / 0.07 + 0.3
				local v131 = math.clamp(v130, 0.3, 1)
				for _, v132 in v_u_105 do
					local v133 = v132.off
					v132.p.CFrame = p128 * (v133 - v133.Position + v133.Position * v131)
					if v_u_127 then
						continue
					end
					v132.p.Size = v132.size * v131
				end
				v_u_127 = v131 >= 1
			end,
			["stop"] = function(p134) -- name: stop
				-- upvalues: (ref) v_u_126, (copy) v_u_103, (ref) v_u_1, (copy) v_u_105, (ref) p_u_15
				if not v_u_126 then
					v_u_126 = true
					local v135 = v_u_103:FindFirstChildWhichIsA("PointLight")
					if v135 then
						v135:Destroy()
					end
					v_u_1:AddItem(v_u_103, 0.17)
					for _, v136 in v_u_105 do
						if p134 then
							p_u_15.fadeOut(v136.p, p134)
						else
							v136.p:Destroy()
						end
					end
				end
			end
		}
	end
	local function v144(p138, p139) -- name: fangImpact
		-- upvalues: (copy) v_u_87, (ref) v_u_9, (copy) p_u_15, (ref) v_u_8, (ref) v_u_5, (ref) v_u_11
		local v140 = p138.size
		v_u_87(p139, p138.dir, 1.45 * v140, 0.22, v_u_9)
		p_u_15.burst("Slash", p139, v_u_8, 1.1 * v140)
		p_u_15.burst("Impact", p139, v_u_8, 0.8 * v140)
		v_u_5.flash(p139, v_u_8, 4.2 * v140, 0.14)
		p_u_15.glint(p139, v_u_9, 4.5 * v140, 0.16)
		if not p138.lite then
			local v141 = p138.dir:Cross(Vector3.new(0, 1, 0))
			for v142 = -1, 1 do
				local v143 = p139 + v141 * v142 * 1.1 * v140
				p_u_15.groundLine(v143 - p138.dir * 0.5, v143 + p138.dir * 3.5 * v140, 0.45 * v140, v_u_11, 0.8, 0.2)
			end
		end
		p_u_15.hitSound(p139)
	end
	local v_u_145 = {}
	local v_u_146 = {}
	local function v_u_175(p147, p148) -- name: buildCage
		-- upvalues: (copy) v_u_16, (copy) v_u_30, (ref) v_u_8, (ref) v_u_9
		local v149 = p147.ability.radius
		local v150 = v_u_16()
		local v151 = p147.lite and 8 or 12
		local v152 = v149 * 0.28
		for v153 = 1, v151 do
			local v154 = (v153 - 0.5) / v151 * 3.141592653589793 * 2
			local v155 = math.cos(v154)
			local v156 = math.sin(v154)
			local v157 = Vector3.new(v155, 0, v156)
			local v158 = v157 * v149 - Vector3.new(0, 1.5, 0)
			local v159 = v157 * v149 + Vector3.new(0, 8.5, 0)
			for _, v160 in {
				{ v158, v159 },
				{ v159, v157 * v152 + Vector3.new(0, 15, 0) }
			} do
				local v161 = (v160[1] + v160[2]) / 2
				local v162 = v160[2] - v160[1]
				local v163 = v_u_30
				local v164 = v162.Magnitude + 0.5
				v163(v150, Vector3.new(0.95, 0.95, v164), CFrame.lookAt(v161, v161 + v162, v157), v_u_8, 0, false, p148)
			end
			if p147.lite then
				break
			end
			local v165 = (v153 + 0.5) / v151 * 3.141592653589793 * 2
			local v166 = math.cos(v165)
			local v167 = math.sin(v165)
			local v168 = Vector3.new(v166, 0, v167) * v149 + Vector3.new(0, 8.5, 0)
			local v169 = (v159 + v168) / 2
			local v170 = v_u_30
			local v171 = (v168 - v159).Magnitude + 0.3
			v170(v150, Vector3.new(0.55, 0.55, v171), CFrame.lookAt(v169, v168), v_u_9, 0.1, false, p148)
		end
		local v172 = v_u_30
		local v173 = v152 * 2 + 1.6
		local v174 = v152 * 2 + 1.6
		v172(v150, Vector3.new(v173, 1.1, v174), CFrame.new(Vector3.new(0, 15, 0)), v_u_8, 0.15, true, p148)
		v_u_30(v150, Vector3.new(2.6, 2.6, 2.6), CFrame.new(Vector3.new(0, 16.2, 0)), v_u_9, 0, true, p148)
		return v150
	end
	local function v_u_185(p176, p177) -- name: shatter
		-- upvalues: (copy) p_u_15, (ref) v_u_5, (ref) v_u_1, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7, (ref) v_u_6
		local v178 = p177.ground
		local v179 = p176.ability.radius
		for v180, v181 in p177.body.parts do
			if not v181.Parent then
				continue
			end
			local v182 = p_u_15.flatUnit(v181.Position - v178)
			v_u_5.tween(v181, 0.25, {
				["CFrame"] = nil,
				["Size"] = nil,
				["Transparency"] = 1,
				["CFrame"] = v181.CFrame + v182 * 2.5 + Vector3.new(0, 1, 0),
				["Size"] = v181.Size * Vector3.new(0.3, 0.3, 0.8)
			})
			v_u_1:AddItem(v181, 0.3)
			if p176.lite or v180 % 3 ~= 0 then
				continue
			end
			local v183 = { v_u_8, v_u_9, v_u_10 }
			p_u_15.chunks(v181.Position, v183, 2, 26, 0.55, 0.7, true, 0.6)
		end
		if p176.lite then
			local v184 = { v_u_8, v_u_9 }
			p_u_15.chunks(v178 + Vector3.new(0, 5, 0), v184, 4, 26, 0.55, 0.6, true, 0.6)
		end
		v_u_5.ring(v178, v_u_9, v179 * 1.1, 0.4, v_u_7.Ring)
		p_u_15.pop(v178 + Vector3.new(0, 7, 0), v_u_9, 3, v179 * 1.1, 0.3, 0.55)
		p_u_15.burst("Impact", v178 + Vector3.new(0, 6, 0), v_u_8, 1.6)
		p_u_15.glint(v178 + Vector3.new(0, 8, 0), v_u_9, 10, 0.25)
		v_u_6.play("EyeActivate", {
			["at"] = v178 + Vector3.new(0, 4, 0),
			["volume"] = p176.mine and 0.8 or 0.45
		})
		v_u_6.play("Hit", {
			["at"] = v178 + Vector3.new(0, 4, 0),
			["volume"] = p176.mine and 0.7 or 0.4
		})
	end
	local v_u_186 = {}
	local function v_u_195(p187, p188) -- name: buildHead
		-- upvalues: (copy) v_u_16, (copy) v_u_30, (ref) v_u_8, (ref) v_u_13, (ref) v_u_14, (ref) v_u_10, (ref) v_u_9, (ref) v_u_12
		local v189 = v_u_16()
		local v190 = v_u_16()
		v_u_30(v189, Vector3.new(12, 10, 11), CFrame.new(0, 1.6, 1.6), v_u_8, 0.6, true, p188)
		v_u_30(v189, Vector3.new(7.4, 5.2, 9), CFrame.new(0, -0.9, -4.4), v_u_8, 0.45, true, p188)
		v_u_30(v189, Vector3.new(2.8, 1.5, 1.8), CFrame.new(0, 0.9, -8.6), v_u_13, 0.05, true, p188)
		v_u_30(v189, Vector3.new(4.6, 2.6, 4.2), CFrame.new(0, -3, -5), v_u_14, 0.25, true, p188)
		for _, v191 in { -1, 1 } do
			v_u_30(v189, Vector3.new(3.6, 1.7, 0.6), CFrame.new(2.5 * v191, 2, -5.35) * CFrame.Angles(0, 0, 0.28 * v191), v_u_13, 0.05, false, p188)
			v_u_30(v189, Vector3.new(4.6, 1.1, 2.4), CFrame.new(2.5 * v191, 3.1, -4.4) * CFrame.Angles(0, 0, 0.32 * v191), v_u_10, 0, false, p188)
			v_u_30(v189, Vector3.new(2.8, 0.8, 0.6), CFrame.new(2.5 * v191, 2, -5.6) * CFrame.Angles(0, 0, 0.28 * v191), v_u_14, 0, false, p188)
			v_u_30(v189, Vector3.new(2.6, 7.5, 1.8), CFrame.new(4.8 * v191, 7.2, 2.2) * CFrame.Angles(0, 0, -0.42 * v191), v_u_8, 0.35, true, p188)
			v_u_30(v189, Vector3.new(0.9, 3.4, 0.9), CFrame.new(1.9 * v191, -4.3, -7.2) * CFrame.Angles(0, 0.7853981633974483, 0), v_u_9, 0, false, p188)
			if p187 then
				continue
			end
			v_u_30(v189, Vector3.new(0.7, 2.2, 0.7), CFrame.new(3.1 * v191, -3.8, -5.4) * CFrame.Angles(0, 0.7853981633974483, 0), v_u_9, 0, false, p188)
		end
		if not p187 then
			for v192 = 1, 10 do
				local v193 = (v192 - 0.5) / 10 * 3.141592653589793 * 2
				v_u_30(v189, Vector3.new(2.6, 9, 1.6), CFrame.new(0, 1.2, 4.2) * CFrame.Angles(0, 0, v193) * CFrame.new(0, 7.5, 0), v_u_12, 0.35, true, p188)
			end
		end
		v_u_30(v190, Vector3.new(6.2, 2.2, 8), CFrame.new(0, -0.8, -4.2), v_u_8, 0.4, true, p188)
		for _, v194 in { -1, 1 } do
			v_u_30(v190, Vector3.new(0.75, 2.4, 0.75), CFrame.new(1.7 * v194, 0.9, -6.8) * CFrame.Angles(0, 0.7853981633974483, 0), v_u_9, 0, false, p188)
		end
		return v189, v190
	end
	local function v_u_200(p196) -- name: headFrame
		-- upvalues: (ref) v_u_4, (copy) p_u_15
		local v197 = v_u_4.CurrentCamera
		local v198
		if v197 then
			v198 = p_u_15.flatUnit(v197.CFrame.Position - p196.feet)
		else
			v198 = -p196.dir
		end
		local v199 = p196.feet + Vector3.new(0, 15, 0) - v198 * 8
		return CFrame.lookAt(v199, v199 + v198) * CFrame.Angles(-0.12, 0, 0)
	end
	local function v_u_226(p201) -- name: driveHead
		-- upvalues: (copy) v_u_41
		local v202 = os.clock()
		local v203 = v202 - p201.born
		local v204 = v203 / p201.form
		local v205 = math.clamp(v204, 0, 1)
		local v206 = (1 - (1 - v205) ^ 3) * 0.65 + 0.35
		local v207 = v205 * 3.141592653589793
		local v208 = v206 + math.sin(v207) * 0.08
		local v209 = v205 * 1.6
		local v210 = 1 - math.min(v209, 1)
		local v211 = p201.cf
		local v212 = 0
		local v213 = p201.roarAt
		if v213 then
			local v214 = v202 - v213
			local v215 = v214 / 0.07
			local v216 = math.clamp(v215, 0, 1)
			v212 = v216 * 0.85
			local v217 = 1 - v214 / 0.7
			local v218 = math.clamp(v217, 0, 1)
			v208 = v216 * 0.12 * (v218 * 0.4 + 0.6) + 1
			local v219 = v218 * 0.5
			v211 = v211 * CFrame.new((math.random() - 0.5) * v219, (math.random() - 0.5) * v219, v216 * -2.2)
			if v214 > 0.7 then
				local v220 = (v214 - 0.7) / 0.4
				v210 = math.clamp(v220, 0, 1)
				v208 = v208 * (v210 * 0.15 + 1)
				v211 = v211 + Vector3.new(0, 3, 0) * v210
				if v210 >= 1 then
					for _, v221 in p201.upper.parts do
						v221:Destroy()
					end
					for _, v222 in p201.jaw.parts do
						v222:Destroy()
					end
					return false
				end
			else
				v210 = 0
			end
		elseif p201.form + 1.2 < v203 then
			local v223 = (v203 - p201.form - 1.2) / 0.3
			v210 = math.clamp(v223, 0, 1)
			if v210 >= 1 then
				for _, v224 in p201.upper.parts do
					v224:Destroy()
				end
				for _, v225 in p201.jaw.parts do
					v225:Destroy()
				end
				return false
			end
		end
		v_u_41(p201.upper, v211, v208, v210)
		v_u_41(p201.jaw, v211 * CFrame.new(Vector3.new(0, -2.4, -0.5) * v208) * CFrame.Angles(-v212, 0, 0), v208, v210)
		return true
	end
	local function v_u_232(p227, p228) -- name: startHead
		-- upvalues: (copy) v_u_195, (copy) v_u_200, (copy) p_u_15, (copy) v_u_226
		local v229, v230 = v_u_195(p227.lite, p228 + 3)
		local v_u_231 = {
			["upper"] = nil,
			["jaw"] = nil,
			["cf"] = nil,
			["born"] = nil,
			["form"] = nil,
			["roarAt"] = nil,
			["upper"] = v229,
			["jaw"] = v230,
			["cf"] = v_u_200(p227),
			["born"] = os.clock(),
			["form"] = math.max(p228, 0.1)
		}
		p_u_15.runNow(function()
			-- upvalues: (ref) v_u_226, (copy) v_u_231
			return v_u_226(v_u_231)
		end)
		return v_u_231
	end
	local v_u_233 = 0
	local function v_u_237() -- name: roarFrame
		-- upvalues: (ref) v_u_233, (ref) v_u_2, (ref) v_u_5, (copy) p_u_15, (ref) v_u_14, (ref) v_u_1
		local v234 = os.clock()
		if v234 >= v_u_233 then
			v_u_233 = v234 + 0.5
			local v_u_235 = Instance.new("ColorCorrectionEffect")
			v_u_235.Name = "BeastRoar"
			v_u_235.Parent = v_u_2
			v_u_5.tween(v_u_235, 0.04, {
				["TintColor"] = nil,
				["Contrast"] = 0.3,
				["Brightness"] = 0.08,
				["TintColor"] = Color3.fromRGB(255, 236, 170)
			})
			p_u_15.after(0.08, function()
				-- upvalues: (ref) v_u_5, (copy) v_u_235, (ref) v_u_14
				local v236 = {
					["TintColor"] = nil,
					["Contrast"] = 0,
					["Brightness"] = 0,
					["TintColor"] = v_u_14
				}
				v_u_5.tween(v_u_235, 0.4, v236)
			end)
			v_u_1:AddItem(v_u_235, 0.55)
		end
	end
	local v325 = {
		["beast_gaze_a"] = {
			["cast"] = function(p238) -- name: cast
				-- upvalues: (copy) p_u_15, (ref) v_u_8, (copy) v_u_87, (ref) v_u_9
				p_u_15.muzzle(p238, v_u_8)
				if not p238.lite then
					v_u_87(p238.eye + p238.dir * 2, p238.dir, 0.5 * p238.size, 0.1, v_u_9)
				end
			end,
			["shot"] = v137,
			["impact"] = v144,
			["hit"] = function(_, p239, _) -- name: hit
				-- upvalues: (copy) p_u_15, (ref) v_u_8, (ref) v_u_9
				p_u_15.burst("Slash", p239, v_u_8, 0.6)
				p_u_15.glint(p239, v_u_9, 3, 0.12)
			end
		},
		["beast_gaze_e"] = {
			["cast"] = function(p240) -- name: cast
				-- upvalues: (copy) p_u_15, (ref) v_u_8, (ref) v_u_9
				p_u_15.skillCast(p240, v_u_8)
				p_u_15.glint(p240.eye, v_u_9, 5, 0.2)
				p_u_15.spikes(p240.eye, v_u_8, 3, 6, 0.2, Vector3.new(0, 1, 0), 0.3)
			end,
			["windup"] = function(p241, p242, p243) -- name: windup
				-- upvalues: (copy) p_u_15, (copy) v_u_175, (copy) v_u_145, (copy) v_u_41, (ref) v_u_8, (ref) v_u_7
				local v244 = p241.ability.radius
				local v_u_245 = p_u_15.ground(p242, 0)
				local v_u_246 = {
					["body"] = nil,
					["landed"] = false,
					["ground"] = nil,
					["body"] = v_u_175(p241, p243 + (p241.ability.freeze or 3) + 1.5),
					["ground"] = v_u_245
				}
				v_u_145[p241] = v_u_246
				local v_u_247 = math.max(p243, 0.05)
				local v_u_248 = os.clock()
				p_u_15.runNow(function()
					-- upvalues: (copy) v_u_246, (copy) v_u_248, (copy) v_u_247, (ref) v_u_41, (copy) v_u_245
					if v_u_246.landed then
						return false
					end
					local v249 = (os.clock() - v_u_248) / v_u_247
					local v250 = math.clamp(v249, 0, 1)
					local v251 = v_u_41
					local v252 = v_u_246.body
					local v253 = CFrame.new(v_u_245 + Vector3.new(0, 26, 0) * (1 - v250 * v250))
					local v254 = v250 * 0.15 + 0.85
					local v255 = v250 * 4
					v251(v252, v253, v254, 1 - math.min(v255, 1))
					return v250 < 1
				end)
				p_u_15.sigil(CFrame.new(p_u_15.ground(p242, 0.15)), v244, v_u_8, v_u_7.Ring, p243 + 0.05, 0)
				p_u_15.burst("Flash", v_u_245 + Vector3.new(0, 26, 0), v_u_8, 0.45)
			end,
			["land"] = function(p_u_256, p257) -- name: land
				-- upvalues: (copy) p_u_15, (copy) v_u_145, (copy) v_u_175, (copy) v_u_41, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6, (copy) v_u_185
				local v_u_258 = p_u_256.ability.radius
				local v_u_259 = p_u_15.ground(p257, 0)
				local v_u_260 = p_u_256.ability.freeze or 3
				local v261 = v_u_145[p_u_256]
				v_u_145[p_u_256] = nil
				local v_u_262 = v261 or {
					["body"] = nil,
					["landed"] = false,
					["ground"] = nil,
					["body"] = v_u_175(p_u_256, v_u_260 + 1.5),
					["ground"] = v_u_259
				}
				v_u_262.landed = true
				v_u_41(v_u_262.body, CFrame.new(v_u_259), 1, 0)
				local v263 = p_u_15.burst
				local v264 = p_u_15.ground(p257, 0.3)
				local v265 = v_u_8
				local v266 = v_u_258 / 18
				v263("Shockwave", v264, v265, (math.min(v266, 1.2)))
				v_u_5.ring(v_u_259, v_u_8, v_u_258 * 1.05, 0.35)
				v_u_5.ring(v_u_259, v_u_9, v_u_258 * 0.8, 0.3, v_u_7.SpeedLines)
				v_u_5.flash(v_u_259 + Vector3.new(0, 5, 0), v_u_8, v_u_258 * 0.9, 0.2)
				p_u_15.sigil(CFrame.new(p_u_15.ground(p257, 0.12)), v_u_258, v_u_8, v_u_7.MagicCircle, v_u_260, 0.6)
				local v_u_267 = v_u_262.body.parts
				local v_u_268 = p_u_256.lite and 8 or 12
				for v269 = 1, v_u_268, 2 do
					local v270 = (v269 - 0.5) / v_u_268 * 3.141592653589793 * 2
					local v271 = math.cos(v270)
					local v272 = math.sin(v270)
					local v273 = v_u_259 + Vector3.new(v271, 0, v272) * v_u_258 + Vector3.new(0, 0.5, 0)
					p_u_15.burst("Impact", v273, v_u_8, 0.8)
					if p_u_256.lite then
						continue
					end
					p_u_15.chunks(v273, p_u_15.EARTH, 2, 20, 0.5, 0.6)
				end
				v_u_6.play("Crit", {
					["at"] = v_u_259,
					["volume"] = p_u_256.mine and 0.8 or 0.45
				})
				if p_u_256.mine then
					v_u_5.shake(0.3, 0.3)
				end
				local v_u_274 = os.clock()
				local v_u_275 = 0
				p_u_15.frame(function()
					-- upvalues: (copy) v_u_274, (copy) v_u_260, (copy) v_u_267, (ref) v_u_41, (copy) v_u_262, (copy) v_u_259, (copy) p_u_256, (ref) v_u_275, (copy) v_u_268, (copy) v_u_258, (ref) p_u_15, (ref) v_u_9
					local v276 = os.clock() - v_u_274
					if v_u_260 <= v276 or not v_u_267[1].Parent then
						return false
					end
					local v277 = v_u_41
					local v278 = v_u_262.body
					local v279 = CFrame.new(v_u_259)
					local v280 = v276 * 11
					v277(v278, v279, 1, (math.sin(v280) * 0.5 + 0.5) * 0.18)
					if not p_u_256.lite and v_u_275 <= v276 then
						v_u_275 = v276 + 0.3
						local v281 = math.random(1, v_u_268)
						local v282 = (v281 - 0.5) / v_u_268 * 3.141592653589793 * 2
						local v283 = (v281 + 0.5) / v_u_268 * 3.141592653589793 * 2
						local v284 = 1.5 + math.random() * 6
						local v285 = v_u_259
						local v286 = math.cos(v282)
						local v287 = math.sin(v282)
						local v288 = v285 + Vector3.new(v286, 0, v287) * v_u_258 + Vector3.new(0, 1, 0) * v284
						local v289 = v_u_259
						local v290 = math.cos(v283)
						local v291 = math.sin(v283)
						local v292 = v289 + Vector3.new(v290, 0, v291) * v_u_258 + Vector3.new(0, 1, 0) * (v284 + (math.random() - 0.5) * 3)
						p_u_15.drawPath(p_u_15.boltPath(v288, v292, 0.7, 1.4), 0.2, v_u_9, 0.12)
					end
					return true
				end)
				p_u_15.after(v_u_260, function()
					-- upvalues: (ref) v_u_185, (copy) p_u_256, (copy) v_u_262
					v_u_185(p_u_256, v_u_262)
				end)
			end,
			["hit"] = function(p293, p294, p295) -- name: hit
				-- upvalues: (copy) v_u_146, (copy) p_u_15, (ref) v_u_8, (ref) v_u_9
				local v296 = os.clock()
				if v296 < (v_u_146[p295] or 0) then
					p_u_15.burst("Impact", p294, v_u_8, 0.6)
				else
					v_u_146[p295] = v296 + (p293.ability.freeze or 3)
					for v297, v298 in v_u_146 do
						if v298 >= v296 then
							continue
						end
						v_u_146[v297] = nil
					end
					p_u_15.bindHit(p293, p294, p295, v_u_8, v_u_9)
				end
			end
		},
		["beast_gaze_r"] = {
			["cast"] = function(p299) -- name: cast
				-- upvalues: (copy) p_u_15, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_7
				p_u_15.skillCast(p299, v_u_8, true)
				p_u_15.glint(p299.eye, v_u_9, 9, 0.25)
				if not p299.lite then
					p_u_15.inward(p299.feet + Vector3.new(0, 6, 0), v_u_8, 8, 14, 0.25)
					p_u_15.mark(p299.feet, v_u_10, 5, 1.2, v_u_7.CrackLines, 0.1)
				end
			end,
			["windup"] = function(p300, _, p301) -- name: windup
				-- upvalues: (copy) v_u_232, (copy) v_u_186, (copy) p_u_15, (ref) v_u_14, (ref) v_u_8
				local v302 = v_u_232(p300, p301)
				v_u_186[p300] = v302
				local v_u_303 = v302.cf * Vector3.new(0, 2, -5.6)
				p_u_15.after(p301 * 0.6, function()
					-- upvalues: (ref) p_u_15, (copy) v_u_303, (ref) v_u_14
					p_u_15.glint(v_u_303, v_u_14, 8, 0.2)
				end)
				p_u_15.burst("Flash", v302.cf.Position, v_u_8, 0.4)
			end,
			["land"] = function(p304, p305) -- name: land
				-- upvalues: (copy) p_u_15, (copy) v_u_186, (copy) v_u_232, (copy) v_u_59, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7, (ref) v_u_8, (ref) v_u_5, (ref) v_u_10, (ref) v_u_6, (copy) v_u_237
				local v_u_306 = p304.ability.radius
				local v_u_307 = p_u_15.ground(p305, 0)
				local v308 = v_u_186[p304]
				v_u_186[p304] = nil
				local v309 = v308 or v_u_232(p304, 0)
				v309.roarAt = os.clock()
				local v_u_310 = v309.cf.LookVector
				local v_u_311 = v309.cf * Vector3.new(0, -3.4, -8)
				for v_u_312 = 0, 2 do
					p_u_15.after(v_u_312 * 0.08, function()
						-- upvalues: (ref) v_u_59, (ref) p_u_15, (copy) v_u_311, (copy) v_u_310, (copy) v_u_312, (ref) v_u_14, (ref) v_u_9, (ref) v_u_7
						local v313 = v_u_59
						local v314 = p_u_15.facing(v_u_311 + v_u_310 * (v_u_312 * 3 + 2), v_u_310)
						local v315 = 2.5
						local v316 = v_u_312 * 5 + 15
						local v317 = 0.4
						local v318
						if v_u_312 == 1 then
							v318 = v_u_14
						else
							v318 = v_u_9
						end
						v313(v314, v315, v316, v317, v318, v_u_7.Ring, 0.1)
					end)
				end
				v_u_59(p_u_15.facing(v_u_311 + v_u_310 * 1.5, v_u_310), 3, 18, 0.35, v_u_8, v_u_7.SpeedLines, 0.2)
				p_u_15.pop(v_u_311, v_u_14, 2, 9, 0.25, 0.2)
				p_u_15.burst("Flash", v_u_311, v_u_8, 0.6)
				v_u_5.ring(v_u_307, v_u_8, v_u_306, 0.45)
				v_u_5.ring(v_u_307, v_u_14, v_u_306 * 0.85, 0.3, v_u_7.SpeedLines)
				p_u_15.after(0.1, function()
					-- upvalues: (ref) v_u_5, (copy) v_u_307, (ref) v_u_9, (copy) v_u_306, (ref) v_u_7
					v_u_5.ring(v_u_307, v_u_9, v_u_306 * 1.15, 0.55, v_u_7.Ring)
				end)
				local v319 = p_u_15.burst
				local v320 = p_u_15.ground(p305, 0.3)
				local v321 = v_u_8
				local v322 = v_u_306 / 16
				v319("Shockwave", v320, v321, (math.min(v322, 1.8)))
				p_u_15.dome(p305, v_u_306, v_u_8, 0.5)
				p_u_15.spikes(p_u_15.ground(p305, 1.5), v_u_9, p304.lite and 8 or 16, v_u_306, 0.4, nil, nil, true)
				p_u_15.mark(p305, v_u_10, 9, 1.8, v_u_7.CrackLines, 0.05)
				if not p304.lite then
					p_u_15.spikes(p_u_15.ground(p305, 3), v_u_14, 8, v_u_306 * 0.75, 0.3, nil, nil, true)
					p_u_15.chunks(p_u_15.ground(p305, 1), { p_u_15.EARTH[1], p_u_15.EARTH[2], v_u_8 }, 10, 48, 1.1, 1.1)
					p_u_15.burst("Explosion", p_u_15.ground(p305, 2), v_u_8, 1.4)
				end
				v_u_6.play("BossAppear", {
					["at"] = v309.cf.Position,
					["volume"] = p304.mine and 1 or 0.6
				})
				v_u_6.play("Explosion", {
					["at"] = v_u_307,
					["volume"] = p304.mine and 0.7 or 0.4
				})
				if p304.mine then
					v_u_5.shake(0.6, 0.6)
					v_u_237()
				end
			end,
			["hit"] = function(p323, p324, _) -- name: hit
				-- upvalues: (copy) p_u_15, (ref) v_u_8, (ref) v_u_9
				p_u_15.burst("Impact", p324, v_u_8, 1)
				p_u_15.spikes(p324, v_u_9, 2, 5, 0.2, p_u_15.flatUnit(p324 - p323.feet), 0.25, true)
			end
		}
	}
	return v325
end