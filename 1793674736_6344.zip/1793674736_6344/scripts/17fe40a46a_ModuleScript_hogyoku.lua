local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
require(script.Parent.Parent.FormTypes)
local v_u_4 = require(script.Parent.Parent.Kit)
local v_u_5 = require(script.Parent.Parent.Parent.Perf)
local v_u_6 = require(v_u_2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("B05CFF")
local v_u_8 = Color3.fromRGB(78, 18, 150)
local v_u_9 = Color3.fromRGB(226, 196, 255)
local v_u_10 = Color3.fromRGB(40, 32, 44)
local v_u_11 = Enum.Material.SmoothPlastic
local v_u_12 = Enum.Material.Neon
local v_u_13 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_24(p14, p15) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v16 = v_u_2:FindFirstChild("EyePieces")
	if v16 then
		v16 = v16:FindFirstChild(p14)
	end
	if not (v16 and v16:IsA("MeshPart")) then
		return nil
	end
	local v17 = v16:Clone()
	local v18 = v16.Size
	local v19 = v16.Size.X
	local v20 = v16.Size.Y
	local v21 = v16.Size.Z
	v17.Size = v18 * (p15 / math.max(v19, v20, v21, 0.01))
	v17.Anchored = true
	v17.CanCollide = false
	v17.CanQuery = false
	v17.CanTouch = false
	v17.Massless = true
	v17.CastShadow = false
	local v22 = v17:FindFirstChildOfClass("SurfaceAppearance")
	if v22 then
		local v23 = v22.EmissiveStrength
		v22.EmissiveStrength = math.max(v23, 5)
	end
	v17.Parent = v_u_4.folder()
	return v17
end
local function v_u_30(p25, p26) -- name: axisAt
	local v27 = p26.Magnitude <= 0.0001 and Vector3.new(0, 0, 1) or p26.Unit
	local v28 = v27.Y
	local v29 = math.abs(v28) > 0.95 and Vector3.new(0, 0, 1) or Vector3.new(0, 1, 0)
	return CFrame.lookAt(p25, p25 + v27, v29) * CFrame.Angles(0, 1.5707963267948966, 0)
end
local function v_u_38(p31, p32, p33, p34, p35) -- name: ringBurst
	-- upvalues: (copy) v_u_3, (copy) v_u_6
	local v36 = Instance.new("Attachment")
	v36.WorldPosition = p31
	v36.Parent = v_u_3.Terrain
	local v37 = Instance.new("ParticleEmitter")
	v37.Enabled = false
	v37.Texture = v_u_6.Ring
	v37.Color = ColorSequence.new(p34)
	v37.LightEmission = 0.3
	v37.LightInfluence = 0
	v37.Size = NumberSequence.new(p32 / 2, p33 / 2)
	v37.Transparency = NumberSequence.new(0, 1)
	v37.Lifetime = NumberRange.new(p35)
	v37.Speed = NumberRange.new(0)
	v37.ZOffset = -0.5
	v37.Parent = v36
	v37:Emit(1)
	game:GetService("Debris"):AddItem(v36, p35 + 0.2)
end
return function(p_u_39)
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_7, (copy) v_u_38, (copy) v_u_9, (copy) v_u_8, (copy) v_u_6, (copy) v_u_5, (copy) v_u_24, (copy) v_u_13, (copy) v_u_12, (copy) v_u_10, (copy) v_u_11, (copy) v_u_30, (copy) v_u_3
	return {
		["w7_hogyoku"] = function(p_u_40, _)
			-- upvalues: (ref) v_u_1, (copy) p_u_39, (ref) v_u_4, (ref) v_u_7, (ref) v_u_38, (ref) v_u_9, (ref) v_u_8, (ref) v_u_6, (ref) v_u_5, (ref) v_u_24, (ref) v_u_13, (ref) v_u_12, (ref) v_u_10, (ref) v_u_11, (ref) v_u_30, (ref) v_u_3
			local v41 = p_u_40.headY / 1.5
			local v_u_42 = math.clamp(v41, 0.7, 3)
			local v_u_43 = p_u_40.fx
			local v44 = p_u_40.character == v_u_1.LocalPlayer.Character
			local v_u_45 = CFrame.new(0, v_u_42 * 0.55, v_u_42 * -0.62)
			local v_u_46 = nil
			local v_u_50 = p_u_39.throb(p_u_40, 5, 1.8, 1.2, function(p47)
				-- upvalues: (copy) v_u_45, (ref) v_u_4, (ref) v_u_7, (copy) v_u_42, (copy) v_u_43, (ref) v_u_38, (ref) v_u_9, (ref) p_u_39, (copy) p_u_40, (ref) v_u_8, (ref) v_u_6, (ref) v_u_46, (ref) v_u_5
				local v48 = (p47 * v_u_45).Position
				v_u_4.flash(v48, v_u_7, v_u_42 * 3.5 * v_u_43, 0.2)
				v_u_38(v48, v_u_42 * 1.5 * v_u_43, v_u_42 * 11 * v_u_43, v_u_7, 0.55)
				v_u_38(v48, v_u_42 * 1 * v_u_43, v_u_42 * 7 * v_u_43, v_u_9, 0.4)
				v_u_4.ring(p_u_39.feetAt(p_u_40, p47, 0.1), v_u_8, 8 * v_u_43, 0.6, v_u_6.Ring)
				local v49 = v_u_46
				if v49 then
					v49:Emit(v_u_5.level() <= 1 and 4 or 14)
				end
			end)
			local v_u_55 = p_u_39.group(p_u_40, function(p51, p52)
				-- upvalues: (copy) v_u_45, (copy) v_u_42
				local v53 = p52 * 2.4
				local v54 = math.sin(v53) * 0.06 + 1
				return p51 * v_u_45 * CFrame.new(0, 0, v_u_42 * -0.04 * (v54 - 1))
			end)
			local v56 = p_u_39.picture(v_u_42 * 1.9, v_u_6.Glow, v_u_7, 0.35)
			p_u_39.add(p_u_40, v56, function()
				-- upvalues: (copy) v_u_55, (ref) p_u_39, (copy) v_u_42
				local v57 = v_u_55.cf.Position
				local v58 = p_u_39.camPos() - v57
				local v59 = v58.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v58.Unit
				return CFrame.lookAt(v57 - v59 * 0.25 * v_u_42, v57 + v59) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			local v_u_60 = v_u_24("w7_hogyoku", v_u_42 * 1.25)
			if v_u_60 then
				local v_u_61 = v_u_60.Size
				p_u_39.pin(p_u_40, v_u_55, v_u_60, v_u_13)
				local v_u_62 = -1
				local v63 = p_u_40.ticks
				local function v66()
					-- upvalues: (copy) v_u_50, (ref) v_u_62, (copy) v_u_60, (copy) v_u_61
					local v64 = v_u_50() * 16
					local v65 = math.floor(v64) / 16
					if v65 ~= v_u_62 then
						v_u_62 = v65
						v_u_60.Size = v_u_61 * (v65 * 0.18 + 1)
					end
				end
				table.insert(v63, v66)
			else
				p_u_39.pin(p_u_40, v_u_55, p_u_39.ball(v_u_42 * 0.46, v_u_7, 0, v_u_12), CFrame.new(0, 0, v_u_42 * -0.06))
				for v67 = 0, 3 do
					local v68 = CFrame.Angles(0, 0, v67 * 3.141592653589793 / 2)
					local v69 = p_u_39.pin
					local v70 = p_u_39.bar
					local v71 = v_u_42 * 0.12
					local v72 = v_u_42 * 0.5
					local v73 = v_u_42 * 0.07
					v69(p_u_40, v_u_55, v70(Vector3.new(v71, v72, v73), v_u_10, 0, v_u_11), v68 * CFrame.new(0, v_u_42 * 0.36, 0))
					local v74 = p_u_39.pin
					local v75 = p_u_39.bar
					local v76 = v_u_42 * 0.07
					local v77 = v_u_42 * 0.12
					local v78 = v_u_42 * 0.08
					v74(p_u_40, v_u_55, v75(Vector3.new(v76, v77, v78), v_u_7, 0, v_u_12), v68 * CFrame.new(0, v_u_42 * 0.6, 0))
				end
			end
			local v79 = Instance.new("Part")
			v79.Shape = Enum.PartType.Ball
			v79.Size = Vector3.new(5, 5, 5) * v_u_42 * v_u_43
			v79.Transparency = 1
			v79.Anchored = true
			v79.CanCollide = false
			v79.CanQuery = false
			v79.CanTouch = false
			v79.CastShadow = false
			v79.Parent = v_u_4.folder()
			p_u_39.add(p_u_40, v79, function()
				-- upvalues: (copy) v_u_55
				return v_u_55.cf
			end)
			local v_u_80 = Instance.new("ParticleEmitter")
			v_u_80.Texture = v_u_6.FxTwinkle
			v_u_80.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_80.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_80.Color = ColorSequence.new(v_u_9, v_u_7)
			v_u_80.LightEmission = 0.4
			v_u_80.LightInfluence = 0
			v_u_80.Size = NumberSequence.new(v_u_42 * 0.45 * v_u_43, v_u_42 * 0.15 * v_u_43)
			v_u_80.Lifetime = NumberRange.new(0.9)
			v_u_80.Speed = NumberRange.new(v_u_42 * 2.6 * v_u_43)
			v_u_80.Shape = Enum.ParticleEmitterShape.Sphere
			v_u_80.ShapeInOut = Enum.ParticleEmitterShapeInOut.Inward
			v_u_80.ShapeStyle = Enum.ParticleEmitterShapeStyle.Surface
			v_u_80.Rotation = NumberRange.new(0, 45)
			v_u_80:SetAttribute("BaseRate", 6 * v_u_43)
			v_u_80.Rate = 6 * v_u_43 * v_u_5.formRate()
			v_u_80.Parent = v79
			v_u_46 = v_u_80
			p_u_39.own(p_u_40, v79)
			local v81 = p_u_40.stops
			table.insert(v81, function()
				-- upvalues: (copy) v_u_80
				v_u_80.Enabled = false
			end)
			local v_u_82 = {}
			for _, v83 in { true, false } do
				for _, v84 in { -1, 1 } do
					local v_u_85 = Instance.new("Attachment")
					v_u_85.Parent = p_u_40.root
					p_u_39.own(p_u_40, v_u_85)
					local v86 = p_u_40.stops
					table.insert(v86, function()
						-- upvalues: (copy) v_u_85
						v_u_85:Destroy()
					end)
					local v_u_87 = Instance.new("Attachment")
					v_u_87.Parent = p_u_40.root
					p_u_39.own(p_u_40, v_u_87)
					local v88 = p_u_40.stops
					table.insert(v88, function()
						-- upvalues: (copy) v_u_87
						v_u_87:Destroy()
					end)
					local v89 = (v83 and 2.1 or 1.5) * v_u_42
					local v90 = p_u_39.ray(v_u_85, v_u_87, v_u_7, v89, v89, v_u_6.HogyokuWing)
					v90.TextureMode = Enum.TextureMode.Stretch
					v90.TextureLength = 1
					v90.TextureSpeed = 0
					v90.Color = ColorSequence.new(v_u_7, v_u_9)
					v90.LightEmission = 0.35
					v90.Segments = 10
					v90.Transparency = NumberSequence.new(0.05)
					table.insert(v_u_82, {
						["root"] = v_u_85,
						["tip"] = v_u_87,
						["beam"] = v90,
						["side"] = v84,
						["upper"] = v83
					})
				end
			end
			local v91 = p_u_40.ticks
			local function v122(_, p92)
				-- upvalues: (copy) v_u_50, (copy) v_u_82, (copy) v_u_42, (ref) v_u_30
				local v93 = v_u_50()
				for v94, v95 in v_u_82 do
					local v96 = v95.side
					local v97 = p92 * 1.3 + v94 * 0.7
					local v98 = math.sin(v97) * 0.12
					local v99 = 1 + 0.45 * v93
					local v100, v101
					if v95.upper then
						local v102 = v96 * 0.3 * v_u_42
						local v103 = v_u_42 * 0.9
						local v104 = v_u_42 * 0.5
						v100 = Vector3.new(v102, v103, v104)
						local v105 = v96 * (v98 * 0.3 + 1.9) * v99 * v_u_42
						local v106 = (v98 + 4) * v_u_42
						local v107 = (1.4 - 0.4 * v93) * v_u_42
						v101 = Vector3.new(v105, v106, v107)
					else
						local v108 = v96 * 0.25 * v_u_42
						local v109 = v_u_42 * 0.35
						local v110 = v_u_42 * 0.5
						v100 = Vector3.new(v108, v109, v110)
						local v111 = v96 * (v98 * 0.2 + 2.9) * v99 * v_u_42
						local v112 = (0.6 - v98) * v_u_42
						local v113 = (1.3 - 0.3 * v93) * v_u_42
						v101 = Vector3.new(v111, v112, v113)
					end
					local v114 = v95.root
					local v115 = v_u_30
					local v116 = v101 - v100
					local v117 = v_u_42 * 0.6
					v114.CFrame = v115(v100, v116 + Vector3.new(0, 0, v117))
					local v118 = v95.tip
					local v119 = v_u_30
					local v120 = v101 - v100
					local v121 = v_u_42 * 0.4
					v118.CFrame = v119(v101, v120 - Vector3.new(0, 0, v121))
					v95.beam.CurveSize0 = (0.6 + 0.4 * v93) * v_u_42
					v95.beam.CurveSize1 = (0.4 + 0.3 * v93) * v_u_42
				end
			end
			table.insert(v91, v122)
			local v123 = p_u_39.picture(v_u_42 * 5.6, v_u_6.Glow, v_u_8, 0.3)
			p_u_39.add(p_u_40, v123, function(p124)
				-- upvalues: (ref) p_u_39, (copy) p_u_40
				return CFrame.new(p_u_39.feetAt(p_u_40, p124, 0.04))
			end)
			local v_u_125 = 0
			local v126 = p_u_40.ticks
			local function v128(_, _, p127)
				-- upvalues: (ref) v_u_125, (copy) v_u_50
				v_u_125 = v_u_125 + p127 * (0.18 + 1.6 * v_u_50())
			end
			table.insert(v126, v128)
			local v_u_129 = v_u_125
			for v_u_130 = 1, 6 do
				local v131 = v_u_4.part
				local v132 = v_u_42 * 1.1
				local v133 = v_u_42 * 2.4
				local v134 = v131(Vector3.new(v132, 0.05, v133), CFrame.identity, v_u_8, {
					["transparency"] = 1
				})
				for _, v135 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
					local v136 = Instance.new("Decal")
					v136.Face = v135
					v136.Texture = v_u_6.HogyokuWing
					local v137
					if v_u_130 % 2 == 0 then
						v137 = v_u_8
					else
						v137 = v_u_7
					end
					v136.Color3 = v137
					v136.Parent = v134
				end
				p_u_39.add(p_u_40, v134, function(p138)
					-- upvalues: (ref) v_u_129, (copy) v_u_130, (ref) p_u_39, (copy) p_u_40, (copy) v_u_42
					local v139 = v_u_129 + v_u_130 * 3.141592653589793 * 2 / 6
					return CFrame.new(p_u_39.feetAt(p_u_40, p138, v_u_130 * 0.004 + 0.07)) * CFrame.Angles(0, v139, 0) * CFrame.new(0, 0, v_u_42 * -1.35)
				end)
			end
			if v44 then
				local v140 = p_u_40.ticks
				local function v147(p141)
					-- upvalues: (ref) v_u_3, (copy) v_u_82
					local v142 = v_u_3.CurrentCamera
					if v142 then
						local v143 = (v142.CFrame.LookVector:Dot(p141.LookVector) - 0.3) * 1.4
						local v144 = math.clamp(v143, 0, 1) * 4
						local v145 = math.floor(v144) / 4 * 0.18 + 0.05
						for _, v146 in v_u_82 do
							v146.beam.Transparency = NumberSequence.new(v145)
						end
					end
				end
				table.insert(v140, v147)
			end
			p_u_39.particles(p_u_40, "AuraMode", v_u_7, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end