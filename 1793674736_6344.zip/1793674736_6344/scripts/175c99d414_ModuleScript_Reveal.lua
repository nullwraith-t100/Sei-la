local v1 = {}
local v_u_2 = 0
local v_u_3 = 0
local v_u_4 = {}
function v1.hold() -- name: hold
	-- upvalues: (ref) v_u_2, (ref) v_u_3
	v_u_2 = v_u_2 + 1
	v_u_3 = os.clock() + 10
end
function v1.active() -- name: active
	-- upvalues: (ref) v_u_2, (ref) v_u_3
	local v5
	if v_u_2 > 0 then
		v5 = os.clock() < v_u_3
	else
		v5 = false
	end
	return v5
end
function v1.release(p6) -- name: release
	-- upvalues: (ref) v_u_2, (copy) v_u_4
	local v7 = v_u_2 - 1
	v_u_2 = math.max(v7, 0)
	if v_u_2 == 0 then
		for _, v8 in v_u_4 do
			task.spawn(v8, p6)
		end
	end
end
function v1.onRelease(p9) -- name: onRelease
	-- upvalues: (copy) v_u_4
	local v10 = v_u_4
	table.insert(v10, p9)
end
function v1.centreOf(p11) -- name: centreOf
	if p11 and p11:IsA("GuiObject") then
		return p11.AbsolutePosition + p11.AbsoluteSize / 2
	else
		return nil
	end
end
return v1