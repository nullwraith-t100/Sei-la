local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("4D7CFF")
local v_u_9 = Color3.fromHex("CFE1FF")
local v_u_10 = Color3.fromRGB(34, 46, 160)
local v_u_11 = Color3.fromRGB(150, 186, 255)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = CFrame.lookAt(Vector3.new(0, 0, 0), Vector3.new(1, 1, 1)):Inverse()
local function v_u_19(p14, p15, p16, p17) -- name: wedge
	-- upvalues: (copy) v_u_5
	local v18 = Instance.new("WedgePart")
	v18.Anchored = true
	v18.CanCollide = false
	v18.CanQuery = false
	v18.CanTouch = false
	v18.CastShadow = false
	v18.Size = p14
	v18.Color = p15
	v18.Material = p17 or Enum.Material.Neon
	v18.Transparency = p16 or 0
	v18.TopSurface = Enum.SurfaceType.Smooth
	v18.BottomSurface = Enum.SurfaceType.Smooth
	v18.Parent = v_u_5.folder()
	return v18
end
local function v_u_25(p20, p21, p22, p23) -- name: flakes
	-- upvalues: (copy) v_u_7
	local v24 = Instance.new("ParticleEmitter")
	v24.Texture = v_u_7.Snowflake
	v24.Color = ColorSequence.new(p20)
	v24.LightEmission = 0.4
	v24.LightInfluence = 0
	v24.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p21 * 0.4), NumberSequenceKeypoint.new(0.2, p21), NumberSequenceKeypoint.new(1, p21 * 0.5) })
	v24.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.75, 0.25), NumberSequenceKeypoint.new(1, 1) })
	v24.Lifetime = NumberRange.new(p23 * 0.6, p23)
	v24.Speed = NumberRange.new(p22 * 0.4, p22)
	v24.SpreadAngle = Vector2.new(180, 180)
	v24.Rotation = NumberRange.new(0, 360)
	v24.RotSpeed = NumberRange.new(-160, 160)
	v24.Drag = 3
	v24.Acceleration = Vector3.new(0, -6, 0)
	v24.Rate = 0
	v24.Enabled = false
	return v24
end
local function v_u_33(p26, p27, p28, p29, p30) -- name: flakeBurst
	-- upvalues: (copy) v_u_4, (copy) v_u_25, (copy) v_u_1
	local v31 = Instance.new("Attachment")
	v31.WorldPosition = p26
	v31.Parent = v_u_4.Terrain
	local v32 = v_u_25(p27, p29, p30, 0.9)
	v32.Parent = v31
	v32:Emit(p28)
	v_u_1:AddItem(v31, 1.1)
end
local function v_u_47(p34, p35, p36, p37, p38) -- name: starFlash
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v39 = CFrame.lookAt(p34, p34 + p35)
	for v40 = 0, 3 do
		local v41
		if v40 % 2 == 0 then
			v41 = p37
		else
			v41 = p37 * 0.62
		end
		local v42 = v39 * CFrame.Angles(0, 0, v40 * 3.141592653589793 / 4)
		local v43 = v_u_5.part
		local v44 = v41 * 0.3
		local v45 = p37 * 0.06 + 0.2
		local v46 = v43(Vector3.new(v44, v45, 0.1), v42, p36)
		v_u_5.tween(v46, p38, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(v41, 0.05, 0.05)
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		v_u_1:AddItem(v46, p38 + 0.05)
	end
end
local function v_u_56(p48, p49, p50, p51, p52) -- name: flakePop
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_1
	local v53 = v_u_5.part(Vector3.new(p49, 0.05, p49), p48, p52, {
		["transparency"] = 1
	})
	for _, v54 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v55 = Instance.new("Decal")
		v55.Face = v54
		v55.Texture = v_u_7.Snowflake
		v55.Color3 = p52
		v55.Parent = v53
		v_u_5.tween(v55, p51, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	v_u_5.tween(v53, p51, {
		["Size"] = Vector3.new(p50, 0.05, p50),
		["CFrame"] = p48 * CFrame.Angles(0, 0.9, 0)
	})
	v_u_1:AddItem(v53, p51 + 0.05)
end
local v_u_57 = 0
local function v_u_61() -- name: frostFrame
	-- upvalues: (ref) v_u_57, (copy) v_u_2, (copy) v_u_5, (copy) v_u_12, (copy) v_u_1
	local v58 = os.clock()
	if v58 >= v_u_57 then
		v_u_57 = v58 + 0.5
		local v59 = Instance.new("ColorCorrectionEffect")
		v59.TintColor = Color3.fromRGB(196, 222, 255)
		v59.Brightness = 0.14
		v59.Contrast = 0.15
		v59.Saturation = -0.4
		v59.Parent = v_u_2
		local v60 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["Saturation"] = 0,
			["TintColor"] = v_u_12
		}
		v_u_5.tween(v59, 0.45, v60)
		v_u_1:AddItem(v59, 0.5)
	end
end
return function(p_u_62)
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_9, (copy) v_u_7, (copy) v_u_25, (copy) v_u_4, (copy) v_u_1, (copy) v_u_19, (copy) v_u_13, (copy) v_u_56, (copy) v_u_47, (copy) v_u_12, (copy) v_u_33, (copy) v_u_11, (copy) v_u_10, (copy) v_u_6, (copy) v_u_61
	local function v88(p63, p64) -- name: flakeShot
		-- upvalues: (ref) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_7, (ref) v_u_25, (ref) v_u_4, (ref) v_u_1, (copy) p_u_62
		local v65 = p63.size
		local v66 = p63.lite
		local v67 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p64, v_u_8, {
			["transparency"] = 1
		})
		local v68 = {}
		for v69 = 0, v66 and 1 or 3 do
			local v70 = v69 < 2
			local v71 = (v70 and 3.4 or 2.2) * v65
			local v72 = (v70 and 0.32 or 0.26) * v65
			local v73 = {
				["p"] = v_u_5.part(Vector3.new(v71, v72, v72), p64, v_u_9)
			}
			local v74 = CFrame.Angles
			local v75 = 0
			local v76 = 0
			local v77
			if v70 then
				v77 = v69 * 3.141592653589793 / 2
			else
				v77 = 0.7853981633974483 + (v69 - 2) * 3.141592653589793 / 2
			end
			v73.off = v74(v75, v76, v77)
			table.insert(v68, v73)
		end
		local v78 = {
			["p"] = v_u_5.part(Vector3.new(1.15, 1.15, 1.15) * v65, p64, v_u_8, {
				["shape"] = Enum.PartType.Ball
			}),
			["off"] = CFrame.identity
		}
		table.insert(v68, v78)
		local v79 = {}
		if not v66 then
			local v80 = v_u_5.part(Vector3.new(3.2, 0.05, 3.2) * v65, p64, v_u_8, {
				["transparency"] = 1
			})
			for _, v81 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
				local v82 = Instance.new("Decal")
				v82.Face = v81
				v82.Texture = v_u_7.Snowflake
				v82.Color3 = v_u_8
				v82.Parent = v80
			end
			local v83 = {
				["p"] = v80,
				["off"] = CFrame.Angles(1.5707963267948966, 0, 0)
			}
			table.insert(v68, v83)
			local v_u_84 = Instance.new("Attachment")
			v_u_84.Parent = v67
			local v_u_85 = v_u_25(v_u_9, 0.26 * v65, 1.5, 0.45)
			v_u_85.Rate = 50
			v_u_85.Enabled = true
			v_u_85.Parent = v_u_84
			local function v87()
				-- upvalues: (copy) v_u_85, (copy) v_u_84, (ref) v_u_4, (ref) v_u_1
				v_u_85.Enabled = false
				local v86 = v_u_84.WorldPosition
				v_u_84.Parent = v_u_4.Terrain
				v_u_84.WorldPosition = v86
				v_u_1:AddItem(v_u_84, 0.6)
			end
			table.insert(v79, v87)
		end
		p_u_62.streak(v67, v_u_8, v_u_9, 1.6 * v65, 0.16)
		if p63.mine then
			p_u_62.light(v67, v_u_8, 10 * v65)
		end
		return p_u_62.assemble(v67, v68, {}, 0, 0, v79, 0.16, 12)
	end
	local function v118(p89, p90) -- name: crystalShot
		-- upvalues: (ref) v_u_19, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_13, (ref) v_u_1, (copy) p_u_62
		local v91 = p89.size
		local v92 = 5.2 * v91
		local v93 = 0.85 * v91
		local v94 = 0.24 * v91
		local v_u_95 = {}
		for v96 = 0, p89.lite and 0 or 1 do
			local v97 = CFrame.Angles(0, 0, v96 * 3.141592653589793 / 2)
			for v98 = -1, 1, 2 do
				local v99 = v_u_19(Vector3.new(v94, v93, v92), v_u_8, 0.12)
				local v100 = v97 * CFrame.new(0, v98 * v93 / 2, 0)
				if v98 < 0 then
					v100 = v100 * CFrame.Angles(0, 0, 3.141592653589793)
				end
				table.insert(v_u_95, {
					["p"] = v99,
					["off"] = v100
				})
			end
		end
		local v101 = {}
		local v102 = v_u_5.part
		local v103 = 0.26 * v91
		local v104 = 0.26 * v91
		local v105 = v92 * 0.92
		v101.p = v102(Vector3.new(v103, v104, v105), p90, v_u_9)
		v101.off = CFrame.new(0, 0, v92 * 0.04)
		table.insert(v_u_95, v101)
		local v106 = {
			["p"] = v_u_5.part(Vector3.new(1, 1, 1) * v93 * 1.05, p90, v_u_9),
			["off"] = CFrame.new(0, 0, v92 / 2) * v_u_13
		}
		table.insert(v_u_95, v106)
		for _, v107 in v_u_95 do
			v_u_1:AddItem(v107.p, 6)
		end
		local v_u_108 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p90, v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_108, 6)
		p_u_62.streak(v_u_108, v_u_8, v_u_9, 1.1 * v91, 0.18)
		if p89.mine then
			p_u_62.light(v_u_108, v_u_8, 8 * v91)
		end
		local v_u_109 = false
		return {
			["place"] = function(p110, p111) -- name: place
				-- upvalues: (copy) v_u_108, (copy) v_u_95
				v_u_108.CFrame = p110
				local v112 = v_u_95
				local v113 = p110 * CFrame.Angles(0, 0, p111 * 5)
				for _, v114 in v112 do
					v114.p.CFrame = v113 * v114.off
				end
			end,
			["stop"] = function(p115) -- name: stop
				-- upvalues: (ref) v_u_109, (copy) v_u_108, (ref) v_u_1, (copy) v_u_95, (ref) p_u_62
				if not v_u_109 then
					v_u_109 = true
					local v116 = v_u_108:FindFirstChildWhichIsA("PointLight")
					if v116 then
						v116:Destroy()
					end
					v_u_1:AddItem(v_u_108, 0.25)
					for _, v117 in v_u_95 do
						if p115 then
							p_u_62.fadeOut(v117.p, p115)
						else
							v117.p:Destroy()
						end
					end
				end
			end
		}
	end
	local v_u_119 = {}
	setmetatable(v_u_119, {
		["__mode"] = "k"
	})
	local function v_u_122(p120, p121) -- name: newZero
		return {
			["g"] = nil,
			["outs"] = nil,
			["reach"] = nil,
			["arms"] = nil,
			["glows"] = nil,
			["branches"] = nil,
			["sky"] = nil,
			["extra"] = nil,
			["done"] = false,
			["g"] = p120,
			["outs"] = {},
			["reach"] = {},
			["arms"] = {},
			["glows"] = {},
			["branches"] = {},
			["sky"] = p121,
			["extra"] = {}
		}
	end
	local function v_u_143(p123, p124, p125, p_u_126) -- name: fling
		-- upvalues: (ref) v_u_1, (copy) p_u_62
		local v_u_127 = {}
		for _, v128 in p123 do
			if not v128.Parent then
				continue
			end
			local v129 = v128.Position.X - p124.X
			local v130 = v128.Position.Z - p124.Z
			local v131 = Vector3.new(v129, 0, v130)
			local v132 = {
				["p"] = v128,
				["v"] = (v131.Magnitude <= 0.1 and Vector3.new(1, 0, 0) or v131.Unit) * p125 * (0.4 + math.random() * 0.6) + Vector3.new(0, 1, 0) * p125 * (0.8 + math.random() * 0.7),
				["spin"] = CFrame.Angles((math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4, (math.random() - 0.5) * 0.4)
			}
			table.insert(v_u_127, v132)
			v_u_1:AddItem(v128, p_u_126 + 0.2)
		end
		local v_u_133 = os.clock()
		local v_u_134 = v_u_133
		p_u_62.frame(function()
			-- upvalues: (ref) v_u_134, (copy) v_u_133, (copy) p_u_126, (copy) v_u_127
			local v135 = os.clock()
			local v136 = v135 - v_u_134
			local v137 = math.min(v136, 0.05)
			v_u_134 = v135
			local v138 = (v135 - v_u_133) / p_u_126
			for _, v139 in v_u_127 do
				v139.v = v139.v - Vector3.new(0, 70, 0) * v137
				v139.p.CFrame = (v139.p.CFrame + v139.v * v137) * v139.spin
				local v140 = v139.p
				local v141 = v139.p.Transparency
				v140.Transparency = math.max(v141, v138)
			end
			if v138 < 1 then
				return true
			end
			for _, v142 in v_u_127 do
				v142.p:Destroy()
			end
			return false
		end)
	end
	local v324 = {
		["glacier_star_a"] = {
			["cast"] = function(p144) -- name: cast
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_56, (ref) v_u_9
				p_u_62.muzzle(p144, v_u_8, 0.9)
				if not p144.lite then
					v_u_56(p_u_62.facing(p144.eye + p144.dir * 1.4, p144.dir), 1, 3.6, 0.14, v_u_9)
				end
			end,
			["shot"] = v88,
			["impact"] = function(p145, p146) -- name: impact
				-- upvalues: (ref) v_u_4, (ref) v_u_56, (copy) p_u_62, (ref) v_u_9, (ref) v_u_47, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_33
				local v147 = p145.size
				local v148 = v_u_4.CurrentCamera
				local v149
				if v148 then
					local v150 = v148.CFrame.Position - p146
					v149 = v150.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v150.Unit
				else
					v149 = Vector3.new(0, 1, 0)
				end
				v_u_56(p_u_62.facing(p146, v149), 2 * v147, 10 * v147, 0.3, v_u_9)
				v_u_47(p146, v149, v_u_12, 7 * v147, 0.2)
				p_u_62.burst("Impact", p146, v_u_8, 0.9 * v147)
				p_u_62.pop(p146, v_u_9, 1.2 * v147, 5 * v147, 0.15, 0.3)
				v_u_5.ring(p_u_62.ground(p146), v_u_8, 6 * v147, 0.25, v_u_7.Ring)
				if not p145.lite then
					v_u_33(p146, v_u_9, 8, 0.35 * v147, 11 * v147)
					local v151 = { v_u_9, v_u_8 }
					p_u_62.chunks(p146, v151, 3, 22, 0.4 * v147, 0.5, true, 0.7)
				end
				p_u_62.hitSound(p146)
			end,
			["hit"] = function(_, p152, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_47, (ref) v_u_4, (ref) v_u_9
				p_u_62.burst("Impact", p152, v_u_8, 0.6)
				local v153 = v_u_47
				local v154 = v_u_4.CurrentCamera
				local v155
				if v154 then
					local v156 = v154.CFrame.Position - p152
					v155 = v156.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v156.Unit
				else
					v155 = Vector3.new(0, 1, 0)
				end
				v153(p152, v155, v_u_9, 3, 0.12)
			end
		},
		["glacier_star_e"] = {
			["cast"] = function(p157) -- name: cast
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_47, (ref) v_u_9, (ref) v_u_56, (ref) v_u_7, (ref) v_u_12
				p_u_62.skillCast(p157, v_u_8)
				local v158 = p157.eye + p157.dir * 2.3
				v_u_47(v158, p157.dir, v_u_9, 7.5, 0.24)
				v_u_56(p_u_62.facing(v158, p157.dir), 2, 7, 0.26, v_u_9)
				p_u_62.sigil(p_u_62.facing(v158 + p157.dir * 0.2, p157.dir), 3.4, v_u_8, v_u_7.Ring, 0.16, 6)
				p_u_62.glint(v158, v_u_12, 4, 0.15)
			end,
			["shot"] = v118,
			["impact"] = function(p159, p160) -- name: impact
				-- upvalues: (ref) v_u_47, (ref) v_u_4, (ref) v_u_9, (copy) p_u_62, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (ref) v_u_12, (ref) v_u_33
				local v161 = p159.size
				local v162 = v_u_47
				local v163 = v_u_4.CurrentCamera
				local v164
				if v163 then
					local v165 = v163.CFrame.Position - p160
					v164 = v165.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v165.Unit
				else
					v164 = Vector3.new(0, 1, 0)
				end
				v162(p160, v164, v_u_9, 6 * v161, 0.2)
				p_u_62.burst("Impact", p160, v_u_8, 1 * v161)
				p_u_62.pop(p160, v_u_8, 1.5 * v161, 5.5 * v161, 0.16, 0.35)
				p_u_62.mark(p160, v_u_9, 3.4 * v161, 1.3, v_u_7.Snowflake, 0.05)
				v_u_5.ring(p_u_62.ground(p160), v_u_9, 5 * v161, 0.25, v_u_7.Ring)
				if not p159.lite then
					local v166 = { v_u_9, v_u_8, v_u_12 }
					p_u_62.chunks(p160, v166, 3, 24, 0.45 * v161, 0.55, true, 0.6)
					v_u_33(p160, v_u_9, 6, 0.35 * v161, 10 * v161)
				end
				p_u_62.hitSound(p160)
			end,
			["hit"] = function(_, p167, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_8
				p_u_62.burst("Impact", p167, v_u_8, 0.7)
			end
		},
		["glacier_star_r"] = {
			["cast"] = function(p168) -- name: cast
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_9, (ref) v_u_47, (ref) v_u_33
				p_u_62.skillCast(p168, v_u_8, true)
				p_u_62.burst("Flash", p168.eye, v_u_9, 0.45)
				v_u_47(p168.eye + p168.dir * 1.6, p168.dir, v_u_9, 9, 0.26)
				if not p168.lite then
					v_u_33(p168.eye + p168.dir, v_u_9, 10, 0.35, 10)
				end
			end,
			["windup"] = function(p_u_169, p170, p171) -- name: windup
				-- upvalues: (copy) p_u_62, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (copy) v_u_122, (copy) v_u_119
				local v172 = p_u_169.lite
				local v_u_173 = p171 + (p_u_169.ability.duration or 2.4) + 0.1
				local v_u_174 = p_u_62.ground(p170, 15)
				local v_u_175 = p_u_62.ground(p170, 0.16)
				p_u_62.sigil(p_u_62.facing(v_u_174, Vector3.new(-0, -1, -0)), 4.6, v_u_12, p_u_62.iris("glacier_star"), v_u_173, 0.5)
				p_u_62.sigil(p_u_62.facing(v_u_174 + Vector3.new(0, 0.3, 0), Vector3.new(-0, -1, -0)), 8.5, v_u_8, v_u_7.Ring, v_u_173, -0.7)
				local v_u_176 = {}
				for v177 = 0, v172 and 3 or 7 do
					local v178 = v177 % 2 == 0
					local v179 = v_u_5.part
					local v180 = Vector3.new(0.5, 0.3, v178 and 7 or 4.2)
					local v181 = CFrame.new(v_u_174)
					local v182
					if v178 then
						v182 = v_u_9
					else
						v182 = v_u_8
					end
					local v183 = v179(v180, v181, v182)
					v_u_1:AddItem(v183, v_u_173 + 2)
					table.insert(v_u_176, v183)
				end
				p_u_62.burst("Flash", v_u_174, v_u_8, 0.5)
				local v_u_184 = v_u_122(v_u_175, v_u_176)
				v_u_119[p_u_169] = v_u_184
				task.delay(v_u_173 + 2, function()
					-- upvalues: (ref) v_u_119, (copy) p_u_169, (copy) v_u_184
					if v_u_119[p_u_169] == v_u_184 then
						v_u_119[p_u_169] = nil
					end
				end)
				local v_u_185 = #v_u_176
				local v_u_186 = os.clock()
				p_u_62.runNow(function()
					-- upvalues: (copy) v_u_184, (copy) v_u_186, (copy) v_u_176, (copy) v_u_185, (copy) v_u_174, (copy) v_u_173
					if v_u_184.done then
						return false
					end
					local v187 = os.clock() - v_u_186
					local v188 = v187 / 0.2
					local v189 = 1 - (1 - math.min(v188, 1)) ^ 3
					for v190, v191 in v_u_176 do
						local v192 = (v190 - 1) / v_u_185 * 3.141592653589793 * 2 + v187 * 0.6
						local v193 = v191.Size.Z
						local v194 = math.cos(v192)
						local v195 = math.sin(v192)
						local v196 = Vector3.new(v194, 0, v195)
						local v197 = 2.2 + v193 / 2 * v189
						v191.CFrame = CFrame.lookAt(v_u_174 + v196 * v197, v_u_174 + v196 * (v197 + 1))
					end
					return v187 < v_u_173 + 1
				end)
				local v_u_198 = p_u_62.ball(v_u_174, v_u_12, 1.4, 0)
				local v_u_199 = p_u_62.ball(v_u_174, v_u_8, 3, 0.5)
				p_u_62.animate(math.max(p171, 0.08), 0, function(p200)
					-- upvalues: (copy) v_u_174, (copy) v_u_175, (copy) v_u_198, (copy) v_u_199
					local v201 = v_u_174:Lerp(v_u_175 + Vector3.new(0, 1, 0), p200 * p200)
					v_u_198.CFrame = CFrame.new(v201)
					v_u_199.CFrame = CFrame.new(v201)
					if p200 >= 1 then
						v_u_198:Destroy()
						v_u_199:Destroy()
					end
				end)
				v_u_5.ring(v_u_175, v_u_8, p_u_169.ability.radius, p171 + 0.25, v_u_7.Ring)
			end,
			["zone"] = function(p202, p_u_203, p_u_204) -- name: zone
				-- upvalues: (copy) v_u_119, (copy) v_u_122, (copy) p_u_62, (ref) v_u_8, (ref) v_u_12, (ref) v_u_5, (ref) v_u_9, (ref) v_u_11, (ref) v_u_1, (ref) v_u_7, (ref) v_u_25
				local v_u_205 = p202.ability.radius
				local v_u_206 = p202.lite
				local v_u_207 = v_u_119[p202] or v_u_122(p_u_62.ground(p_u_203, 0.16), {})
				v_u_119[p202] = v_u_207
				local v_u_208 = v_u_207.g
				local v209 = p_u_204 + 1
				p_u_62.burst("Shockwave", p_u_62.ground(p_u_203, 0.3), v_u_8, v_u_205 / 18)
				p_u_62.pop(p_u_62.ground(p_u_203, 1), v_u_12, 2, 9, 0.25, 0.2)
				v_u_5.flash(p_u_62.ground(p_u_203, 1.5), v_u_9, 10, 0.2)
				local v210 = p_u_62.plate(v_u_208 - Vector3.new(0, 0.08, 0), 1, v_u_11, 0.45, Enum.Material.Ice)
				local v211 = v_u_5.tween
				local v212 = {}
				local v213 = v_u_205 * 2
				local v214 = v_u_205 * 2
				v212.Size = Vector3.new(0.12, v213, v214)
				v211(v210, 0.9, v212, Enum.EasingStyle.Quart)
				v_u_1:AddItem(v210, v209 + 1)
				local v215 = v_u_207.extra
				table.insert(v215, v210)
				p_u_62.sigil(CFrame.new(p_u_62.ground(p_u_203, 0.1)), v_u_205 * 1.02, v_u_8, v_u_7.Ring, p_u_204, 0.3)
				p_u_62.sigil(CFrame.new(p_u_62.ground(p_u_203, 0.12)), v_u_205 * 0.5, v_u_9, v_u_7.Ring, p_u_204, -0.5)
				local v216 = p_u_62.flatUnit(p202.dir)
				local v217 = v216.Z
				local v218 = v216.X
				local v219 = math.atan2(v217, v218)
				for v220 = 0, 7 do
					local v221 = v219 + v220 * 3.141592653589793 / 4
					local v222 = math.cos(v221)
					local v223 = math.sin(v221)
					local v224 = Vector3.new(v222, 0, v223)
					local v225 = v220 % 2 == 0
					local v226 = v_u_207.outs
					table.insert(v226, v224)
					local v227 = v_u_207.reach
					local v228 = v_u_205 * (v225 and 0.96 or 0.6)
					table.insert(v227, v228)
					local v229 = v_u_5.part(Vector3.new(1.2, 0.24, 0.1), CFrame.new(v_u_208), v_u_8)
					v_u_1:AddItem(v229, v209 + 1)
					local v230 = v_u_207.arms
					table.insert(v230, v229)
					if not v_u_206 then
						local v231 = v_u_5.part(Vector3.new(3, 0.1, 0.1), CFrame.new(v_u_208 - Vector3.new(0, 0.04, 0)), v_u_12, {
							["transparency"] = 0.45
						})
						v_u_1:AddItem(v231, v209 + 1)
						local v232 = v_u_207.glows
						table.insert(v232, v231)
					end
					local v233
					if v225 then
						v233 = v_u_206 and {
							{ 0.55, 0.3 }
						} or {
							{ 0.42, 0.34 },
							{ 0.72, 0.22 }
						}
					else
						v233 = v_u_206 and {} or {
							{ 0.5, 0.24 }
						}
					end
					for _, v234 in v233 do
						for _, v235 in { -1, 1 } do
							local v236 = CFrame.Angles(0, v235 * 0.8377580409572782, 0):VectorToWorldSpace(v224)
							local v237 = v_u_5.part(Vector3.new(0.8, 0.2, 0.1), CFrame.new(v_u_208), v_u_8, {
								["transparency"] = 1
							})
							v_u_1:AddItem(v237, v209 + 1)
							local v238 = v_u_207.branches
							local v239 = {
								["p"] = v237,
								["arm"] = v220 + 1,
								["at"] = v234[1],
								["len"] = v_u_205 * v234[2],
								["dir"] = v236
							}
							table.insert(v238, v239)
						end
					end
				end
				local v240 = p_u_62.pillar(v_u_208, 15, 3.4, v_u_9, 0.8)
				v_u_1:AddItem(v240, v209 + 1)
				local v241 = v_u_207.extra
				table.insert(v241, v240)
				local v242 = v_u_5.part
				local v243 = v_u_205 * 1.6
				local v244 = v_u_205 * 1.6
				local v245 = v242(Vector3.new(v243, 0.4, v244), CFrame.new(v_u_208 + Vector3.new(0, 10, 0)), v_u_9, {
					["transparency"] = 1
				})
				local v_u_246 = v_u_25(v_u_9, 0.4, 2, 1.4)
				v_u_246.EmissionDirection = Enum.NormalId.Bottom
				v_u_246.SpreadAngle = Vector2.new(25, 25)
				v_u_246.Acceleration = Vector3.new(0, -9, 0)
				v_u_246.Drag = 0.6
				v_u_246.Rate = v_u_206 and 8 or 24
				v_u_246.Enabled = true
				v_u_246.Parent = v245
				v_u_1:AddItem(v245, v209 + 2)
				if p202.mine then
					p_u_62.light(v240, v_u_9, 30)
				end
				local v_u_247 = p202.ability.tick or 0.4
				local v_u_248 = v_u_247
				local v_u_249 = 0.2
				local v_u_250 = -1
				local v_u_251 = os.clock()
				local v_u_252 = false
				p_u_62.runNow(function()
					-- upvalues: (copy) v_u_207, (copy) v_u_251, (ref) v_u_252, (copy) v_u_208, (ref) v_u_248, (copy) v_u_247, (ref) v_u_250, (ref) v_u_5, (ref) v_u_9, (copy) v_u_205, (ref) v_u_7, (copy) v_u_206, (ref) p_u_62, (copy) p_u_203, (ref) v_u_8, (ref) v_u_12, (ref) v_u_249, (copy) p_u_204
					if v_u_207.done then
						return false
					end
					local v253 = os.clock() - v_u_251
					local v254 = v253 / 0.9
					local v255 = math.clamp(v254, 0, 1)
					local v256 = 1 - (1 - v255) ^ 3
					if not v_u_252 then
						for v257, v258 in v_u_207.arms do
							local v259 = v_u_207.reach[v257] * v256
							local v260 = math.max(v259, 0.1)
							local v261 = v_u_207.outs[v257]
							local v262 = CFrame.lookAt(v_u_208 + v261 * v260 / 2, v_u_208 + v261 * v260)
							v258.Size = Vector3.new(1.2, 0.24, v260)
							v258.CFrame = v262
							local v263 = v_u_207.glows[v257]
							if not v263 then
								continue
							end
							local v264 = v260 + 1
							v263.Size = Vector3.new(3, 0.1, v264)
							v263.CFrame = v262 - Vector3.new(0, 0.04, 0)
						end
						local v265 = v255 < 1
						for _, v266 in v_u_207.branches do
							local v267 = v_u_207.reach[v266.arm]
							local v268 = v267 * v266.at
							local v269 = (v267 * v256 - v268) / (v266.len * 1.1)
							local v270 = math.clamp(v269, 0, 1)
							v265 = v270 < 1 and true or v265
							local v271 = v266.len * v270
							local v272 = math.max(v271, 0.05)
							local v273 = v_u_208 + v_u_207.outs[v266.arm] * v268
							v266.p.Size = Vector3.new(0.8, 0.2, v272)
							v266.p.CFrame = CFrame.lookAt(v273 + v266.dir * v272 / 2, v273 + v266.dir * v272)
							v266.p.Transparency = v270 > 0 and 0 or 1
						end
						v_u_252 = not v265
					end
					if v_u_248 <= v253 then
						v_u_248 = v_u_248 + v_u_247
						v_u_250 = v253
						v_u_5.ring(v_u_208, v_u_9, v_u_205, 0.35, v_u_7.Ring)
						if not v_u_206 then
							p_u_62.inward(p_u_62.ground(p_u_203, 1), v_u_9, 4, v_u_205, 0.3)
						end
					end
					if v_u_250 >= 0 and v253 - v_u_250 < 0.2 then
						local v274 = v_u_8
						local v275 = v_u_12
						local v276 = 1 - (v253 - v_u_250) / 0.15
						local v277 = v274:Lerp(v275, (math.max(v276, 0)))
						for _, v278 in v_u_207.arms do
							v278.Color = v277
						end
					end
					if not v_u_206 and v_u_249 <= v253 then
						v_u_249 = v253 + 0.35
						local v279 = math.random() * 3.141592653589793 * 2
						local v280 = v_u_205 * 0.8
						local v281 = math.random()
						local v282 = v280 * math.sqrt(v281)
						local v283 = p_u_62.burst
						local v284 = p_u_62.ground
						local v285 = p_u_203
						local v286 = math.cos(v279) * v282
						local v287 = math.sin(v279) * v282
						v283("Smoke", v284(v285 + Vector3.new(v286, 0, v287), 0.8), nil, 0.7)
					end
					return v253 < p_u_204 + 1
				end)
				return function()
					-- upvalues: (copy) v_u_246, (copy) v_u_207, (ref) p_u_62
					v_u_246.Enabled = false
					task.delay(0.4, function()
						-- upvalues: (ref) v_u_207, (ref) p_u_62
						if not v_u_207.done then
							v_u_207.done = true
							for _, v288 in { v_u_207.arms, v_u_207.glows, v_u_207.sky } do
								for _, v289 in v288 do
									p_u_62.fadeOut(v289, 0.3)
								end
							end
							for _, v290 in v_u_207.branches do
								p_u_62.fadeOut(v290.p, 0.3)
							end
							for _, v291 in v_u_207.extra do
								p_u_62.fadeOut(v291, 0.3)
							end
						end
					end)
				end
			end,
			["finish"] = function(p292, p293) -- name: finish
				-- upvalues: (copy) p_u_62, (copy) v_u_119, (ref) v_u_12, (copy) v_u_143, (ref) v_u_47, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_56, (ref) v_u_5, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (ref) v_u_33, (ref) v_u_6, (ref) v_u_61
				local v294 = p292.ability.radius
				local v295 = p292.lite
				local v296 = p_u_62.ground(p293, 0)
				local v297 = v_u_119[p292]
				v_u_119[p292] = nil
				if v297 and not v297.done then
					v297.done = true
					local v298 = {}
					for _, v299 in v297.arms do
						v299.Color = v_u_12
						table.insert(v298, v299)
					end
					for _, v300 in v297.branches do
						local v301 = v300.p
						table.insert(v298, v301)
					end
					for _, v302 in v297.glows do
						p_u_62.fadeOut(v302, 0.2)
					end
					v_u_143(v298, v296, 26, 0.8)
					for _, v303 in v297.sky do
						p_u_62.fadeOut(v303, 0.15)
					end
					for _, v304 in v297.extra do
						p_u_62.fadeOut(v304, 0.45)
					end
					v_u_47(p_u_62.ground(p293, 15), Vector3.new(-0, -1, -0), v_u_12, 16, 0.3)
				end
				local v305 = p_u_62.ground(p293, 3)
				p_u_62.pop(v305, v_u_12, 3, v294 * 1.4, 0.3, 0.15)
				p_u_62.pop(v305, v_u_8, 4, v294 * 1.7, 0.4, 0.55)
				local v306 = v_u_47
				local v307 = v_u_4.CurrentCamera
				local v308
				if v307 then
					local v309 = v307.CFrame.Position - v305
					v308 = v309.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v309.Unit
				else
					v308 = Vector3.new(0, 1, 0)
				end
				v306(v305, v308, v_u_9, v294 * 1.6, 0.35)
				local v310 = v_u_56
				local v311 = p_u_62.facing
				local v312 = v_u_4.CurrentCamera
				local v313
				if v312 then
					local v314 = v312.CFrame.Position - v305
					v313 = v314.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v314.Unit
				else
					v313 = Vector3.new(0, 1, 0)
				end
				v310(v311(v305, v313), 4, v294 * 1.6, 0.4, v_u_12)
				p_u_62.burst("Explosion", v305, v_u_8, v294 / 8)
				p_u_62.burst("Flash", v305, v_u_9, 1)
				local v315 = p_u_62.burst
				local v316 = p_u_62.ground(p293, 0.3)
				local v317 = v_u_8
				local v318 = v294 / 14
				v315("Shockwave", v316, v317, (math.min(v318, 1.6)))
				v_u_5.ring(v296, v_u_9, v294 * 1.3, 0.5, v_u_7.SpeedLines)
				v_u_5.ring(v296, v_u_8, v294 * 1.15, 0.45)
				p_u_62.mark(p293, v_u_10, v294 * 0.95, 2, v_u_7.CrackLines, 0)
				p_u_62.mark(p293, v_u_9, v294 * 0.8, 1.6, v_u_7.Snowflake, 0.1)
				p_u_62.chunks(p_u_62.ground(p293, 1), { v_u_9, v_u_8, v_u_11 }, v295 and 6 or 16, 46, 1.2, 1.1)
				if not v295 then
					v_u_33(v305, v_u_12, 24, 0.7, 26)
				end
				v_u_6.play("Explosion", {
					["at"] = v305,
					["volume"] = p292.mine and 1 or 0.6
				})
				v_u_6.play("Crit", {
					["at"] = v305,
					["volume"] = p292.mine and 0.8 or 0.45
				})
				if p292.mine then
					v_u_5.shake(0.6, 0.5)
					v_u_61()
				end
			end,
			["hit"] = function(_, p319, _) -- name: hit
				-- upvalues: (copy) p_u_62, (ref) v_u_8, (ref) v_u_47, (ref) v_u_4, (ref) v_u_9
				p_u_62.burst("Impact", p319, v_u_8, 0.9)
				local v320 = v_u_47
				local v321 = v_u_4.CurrentCamera
				local v322
				if v321 then
					local v323 = v321.CFrame.Position - p319
					v322 = v323.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or v323.Unit
				else
					v322 = Vector3.new(0, 1, 0)
				end
				v320(p319, v322, v_u_9, 4, 0.14)
			end
		}
	}
	return v324
end