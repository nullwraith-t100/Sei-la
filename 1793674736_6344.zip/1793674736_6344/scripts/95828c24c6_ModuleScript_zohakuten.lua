local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({ v_u_7.ZohakuDrum, v_u_7.ZohakuBoom, v_u_7.ZohakuBark })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FF8A1F")
local v_u_10 = Color3.fromRGB(255, 200, 92)
local v_u_11 = Color3.fromRGB(46, 24, 10)
local v_u_12 = Color3.fromRGB(112, 64, 30)
local v_u_13 = Color3.fromRGB(146, 88, 42)
local v_u_14 = Color3.fromRGB(128, 30, 16)
local v_u_15 = Enum.Material.SmoothPlastic
local v_u_16 = Enum.PartType.Wedge
local v_u_17 = CFrame.Angles(1.5707963267948966, 0, 0)
local function v_u_27(p18, p19, p20, p21, p22) -- name: picture
	-- upvalues: (copy) v_u_4
	local v23 = v_u_4.part(Vector3.new(p19, 0.05, p19), p18, p21, {
		["transparency"] = 1
	})
	local v24 = {}
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p20
		v26.Color3 = p21
		v26.Transparency = p22
		v26.Parent = v23
		table.insert(v24, v26)
	end
	return v23, v24
end
local function v_u_60(p28, p29, p30, p31, p32, p33, p34, p35, p36, p37, p38) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v39 = p34 + p35 + p36
	local v40 = math.max(v39, 0.05)
	local v41 = {}
	local v42 = {}
	for v43 = 0, 10 do
		local v44 = v43 / 10
		local v45 = v44 * v40
		local v46 = v45 / math.max(p34, 0.001)
		local v47 = 1 - (1 - math.clamp(v46, 0, 1)) ^ 3
		local v48 = (v45 - p34 - p35) / math.max(p36, 0.001)
		local v49 = math.clamp(v48, 0, 1)
		local v50 = v49 * v49 * (3 - v49 * 2)
		local v51 = NumberSequenceKeypoint.new
		local v52 = p29 + (p30 - p29) * v47
		local v53 = math.max(v52, 0.05) / 2
		table.insert(v42, v51(v44, v53))
		local v54 = NumberSequenceKeypoint.new
		local v55 = p33 + (1 - p33) * v50
		local v56 = math.clamp(v55, 0, 1)
		table.insert(v41, v54(v44, v56))
	end
	local v57 = Instance.new("Attachment")
	v57.WorldCFrame = CFrame.new(p28)
	v57.Parent = v_u_3.Terrain
	local v58 = Instance.new("ParticleEmitter")
	v58.Enabled = false
	v58.Texture = p31
	v58.Color = ColorSequence.new(p32)
	v58.LightEmission = p38 or 0
	v58.LightInfluence = 0
	v58.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v58.EmissionDirection = Enum.NormalId.Top
	v58.SpreadAngle = Vector2.zero
	v58.Speed = NumberRange.new(0.01)
	v58.Size = NumberSequence.new(v42)
	v58.Transparency = NumberSequence.new(v41)
	v58.Lifetime = NumberRange.new(v40)
	local v59 = p37 or math.random(0, 359)
	v58.Rotation = NumberRange.new(v59, v59)
	v58.Parent = v57
	v58:Emit(1)
	v_u_1:AddItem(v57, v40 + 0.2)
end
local function v_u_70(p61, p62, p63, p64, p65, p66, p67) -- name: spritePop
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v68 = Instance.new("Attachment")
	v68.WorldPosition = p61
	v68.Parent = v_u_3.Terrain
	local v69 = Instance.new("ParticleEmitter")
	v69.Enabled = false
	v69.Texture = p62
	v69.Color = ColorSequence.new(p63)
	v69.LightEmission = p67 or 0
	v69.LightInfluence = 0
	v69.Speed = NumberRange.new(0)
	v69.Lifetime = NumberRange.new(p66)
	v69.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p64 / 2), NumberSequenceKeypoint.new(0.35, (p64 + (p65 - p64) * 0.8) / 2), NumberSequenceKeypoint.new(1, p65 / 2) })
	v69.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.5, 0.15), NumberSequenceKeypoint.new(1, 1) })
	v69.Rotation = NumberRange.new(0, 360)
	v69.Parent = v68
	v69:Emit(1)
	v_u_1:AddItem(v68, p66 + 0.2)
end
local function v_u_80(p71, p72, p73, p74, p75, p76) -- name: soundRing
	-- upvalues: (copy) v_u_27, (copy) v_u_17, (copy) v_u_7, (copy) v_u_4, (copy) v_u_1
	local v77, v78 = v_u_27(p71 * v_u_17, p72, v_u_7.ZohakuBoom, p75, 0)
	v77.Size = Vector3.new(p72, 0.05, p72)
	v_u_4.tween(v77, p76, {
		["Size"] = Vector3.new(p73, 0.05, p73),
		["CFrame"] = p71 * CFrame.new(0, 0, p74) * v_u_17
	})
	for _, v79 in v78 do
		v_u_4.tween(v79, p76, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	v_u_1:AddItem(v77, p76 + 0.05)
end
local function v_u_106(p_u_81, p82, p_u_83) -- name: dragonHead
	-- upvalues: (copy) v_u_4, (copy) v_u_11, (copy) v_u_15, (copy) v_u_1, (copy) v_u_16, (copy) v_u_12, (copy) v_u_13, (copy) v_u_9
	local v84 = {
		["material"] = v_u_15
	}
	local v85 = v_u_4.part(Vector3.new(0.72, 0.2, 1.05) * p_u_81, CFrame.new(0, -500, 0), v_u_11, v84)
	v_u_1:AddItem(v85, p_u_83)
	local v_u_86 = {
		["parts"] = {},
		["offs"] = {},
		["jaw"] = v85,
		["s"] = p_u_81
	}
	local function v102(p87, p88, p89, p90, p91) -- name: add
		-- upvalues: (ref) v_u_4, (copy) p_u_81, (ref) v_u_16, (ref) v_u_15, (ref) v_u_1, (copy) p_u_83, (copy) v_u_86
		local v92 = v_u_4.part
		local v93 = p87 * p_u_81
		local v94 = CFrame.new(0, -500, 0)
		local v95 = {}
		local v96
		if p90 then
			v96 = v_u_16
		else
			v96 = nil
		end
		v95.shape = v96
		local v97
		if p91 then
			v97 = nil
		else
			v97 = v_u_15
		end
		v95.material = v97
		local v98 = v92(v93, v94, p88, v95)
		v_u_1:AddItem(v98, p_u_83)
		local v99 = v_u_86.parts
		table.insert(v99, v98)
		local v100 = v_u_86.offs
		local v101 = CFrame.new(p89.Position * p_u_81) * p89.Rotation
		table.insert(v100, v101)
		return v98
	end
	v102(Vector3.new(1, 0.85, 1), v_u_12, CFrame.identity)
	v102(Vector3.new(0.82, 0.5, 1.25), v_u_13, CFrame.new(0, 0.08, -1.08), true)
	v102(Vector3.new(0.5, 0.16, 0.85), v_u_9, CFrame.new(0, -0.24, -0.85), false, true)
	for _, v103 in { -1, 1 } do
		v102(Vector3.new(0.16, 0.12, 0.08), v_u_9, CFrame.new(v103 * 0.34, 0.2, -0.5), false, true)
	end
	if p82 then
		for _, v104 in { -1, 1 } do
			v102(Vector3.new(0.15, 0.75, 0.42), v_u_9, CFrame.new(v104 * 0.3, 0.62, 0.3) * CFrame.Angles(0.55, 0, v104 * -0.22), true, true)
		end
		for v105 = 0, 2 do
			v102(Vector3.new(0.1, 0.45, 0.4), v_u_11, CFrame.new(0, 0.5, v105 * 0.32 + 0.15) * CFrame.Angles(0.4, 0, 0), true)
		end
	end
	return v_u_86
end
local function v_u_113(p107, p108, p109) -- name: placeHead
	for v110, v111 in p107.parts do
		v111.CFrame = p108 * p107.offs[v110]
	end
	local v112 = p107.s
	p107.jaw.CFrame = p108 * CFrame.new(0, v112 * -0.38, v112 * -0.25) * CFrame.Angles(-p109, 0, 0) * CFrame.new(0, 0, v112 * -0.5)
end
local function v_u_117(p114, p115) -- name: fadeHead
	-- upvalues: (copy) v_u_4
	for _, v116 in p114.parts do
		v_u_4.tween(v116, p115, {
			["Transparency"] = 1
		})
	end
	v_u_4.tween(p114.jaw, p115, {
		["Transparency"] = 1
	})
end
local function v_u_125(p118, p119) -- name: drum
	-- upvalues: (copy) v_u_4, (copy) v_u_14, (copy) v_u_15, (copy) v_u_27, (copy) v_u_7, (copy) v_u_8, (copy) v_u_1
	local v120 = {
		["material"] = v_u_15
	}
	local v121 = v_u_4.part(Vector3.new(1.05, 1.05, 0.8) * p118, CFrame.new(0, -500, 0), v_u_14, v120)
	local v122 = Instance.new("SpecialMesh")
	v122.MeshType = Enum.MeshType.Sphere
	v122.Parent = v121
	local v123, v124 = v_u_27(CFrame.new(0, -500, 0), p118, v_u_7.ZohakuDrum, v_u_8, 0)
	v_u_1:AddItem(v121, p119)
	v_u_1:AddItem(v123, p119)
	return {
		["body"] = v121,
		["head"] = v123,
		["decals"] = v124,
		["size"] = p118
	}
end
local function v_u_130(p126, p127, p128) -- name: placeDrum
	local v129 = p126.size * p128
	p126.body.Size = Vector3.new(1.05, 1.05, 0.8) * v129
	p126.body.CFrame = p127
	p126.head.Size = Vector3.new(v129, 0.05, v129)
	p126.head.CFrame = p127 * CFrame.new(0, 0, v129 * -0.42) * CFrame.Angles(-1.5707963267948966, 0, 0)
end
return function(p_u_131)
	-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_11, (copy) v_u_9, (copy) v_u_4, (copy) v_u_106, (copy) v_u_8, (copy) v_u_1, (copy) v_u_7, (copy) v_u_113, (copy) v_u_117, (copy) v_u_10, (copy) v_u_125, (copy) v_u_130, (copy) v_u_80, (copy) v_u_60, (copy) v_u_6, (copy) v_u_70, (copy) v_u_15
	local v132 = {}
	local function v_u_137(p133, p134, p135) -- name: splinters
		-- upvalues: (copy) p_u_131, (ref) v_u_12, (ref) v_u_13, (ref) v_u_11, (ref) v_u_9
		local v136 = { v_u_12, v_u_13, v_u_11 }
		p_u_131.chunks(p133, v136, p135, 22, p134 * 0.4, 0.7, false, 1)
		p_u_131.spikes(p133, v_u_9, 4, p134 * 4.5, 0.2)
	end
	v132.zohakuten_a = {
		["cast"] = function(p138) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			v_u_4.flash(p138.eye + p138.dir * 0.8, v_u_9, 2.6 * p138.size, 0.12)
		end,
		["shot"] = function(p139, p140) -- name: shot
			-- upvalues: (ref) v_u_106, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_113, (ref) v_u_117, (copy) p_u_131
			local v_u_141 = p139.size
			local v_u_142 = v_u_106(1.35 * v_u_141, not p139.lite, 3)
			local v_u_143 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(p139.eye - Vector3.new(0, 0.4, 0)), v_u_8, {
				["transparency"] = 1
			})
			local v_u_144 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p140, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_143, 3)
			v_u_1:AddItem(v_u_144, 3)
			local v_u_145 = Instance.new("Attachment")
			v_u_145.Parent = v_u_143
			local v_u_146 = Instance.new("Attachment")
			v_u_146.Parent = v_u_144
			local v_u_147 = Instance.new("Beam")
			v_u_147.Attachment0 = v_u_145
			v_u_147.Attachment1 = v_u_146
			v_u_147.Texture = v_u_7.ZohakuBark
			v_u_147.TextureMode = Enum.TextureMode.Wrap
			v_u_147.TextureLength = 2.2 * v_u_141
			v_u_147.TextureSpeed = 0
			v_u_147.Color = ColorSequence.new(v_u_8)
			v_u_147.LightEmission = 0
			v_u_147.LightInfluence = 0
			v_u_147.FaceCamera = true
			v_u_147.Width0 = 1 * v_u_141
			v_u_147.Width1 = 1.7 * v_u_141
			v_u_147.Segments = p139.lite and 4 or 10
			v_u_147.Parent = v_u_143
			local v_u_148 = false
			return {
				["place"] = function(p149, p150) -- name: place
					-- upvalues: (ref) v_u_113, (copy) v_u_142, (copy) v_u_144, (copy) v_u_141, (copy) v_u_147, (copy) v_u_143, (copy) v_u_145, (copy) v_u_146
					local v151 = p150 * 22
					local v152 = math.sin(v151)
					v_u_113(v_u_142, p149, math.abs(v152) * 0.35 + 0.25)
					v_u_144.CFrame = p149 * CFrame.new(0, 0, 0.5 * v_u_141)
					local v153 = p150 * 16
					local v154 = math.sin(v153) * 2.5 * v_u_141
					v_u_147.CurveSize0 = v154
					v_u_147.CurveSize1 = -v154
					local v155 = p149.Position - v_u_143.Position
					v_u_145.WorldCFrame = CFrame.lookAt(v_u_143.Position, v_u_143.Position + v155)
					v_u_146.WorldCFrame = CFrame.lookAt(v_u_144.Position, v_u_144.Position + v155)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_148, (copy) v_u_142, (ref) v_u_113, (ref) v_u_117, (copy) v_u_147, (ref) p_u_131, (copy) v_u_143, (copy) v_u_144
					if not v_u_148 then
						v_u_148 = true
						v_u_113(v_u_142, v_u_142.parts[1].CFrame, 0)
						v_u_117(v_u_142, 0.15)
						local v_u_156 = v_u_147.Width0
						local v_u_157 = v_u_147.Width1
						p_u_131.animate(0.18, 0, function(p158)
							-- upvalues: (ref) v_u_147, (copy) v_u_156, (copy) v_u_157, (ref) v_u_143, (ref) v_u_144
							v_u_147.Width0 = v_u_156 * (1 - p158)
							v_u_147.Width1 = v_u_157 * (1 - p158)
							if p158 >= 1 then
								v_u_143:Destroy()
								v_u_144:Destroy()
							end
						end)
					end
				end
			}
		end,
		["impact"] = function(p159, p160) -- name: impact
			-- upvalues: (ref) v_u_4, (ref) v_u_10, (ref) v_u_9, (copy) p_u_131, (ref) v_u_11, (ref) v_u_7, (copy) v_u_137
			local v161 = p159.size
			v_u_4.flash(p160, v_u_10, 2.4 * v161, 0.1)
			v_u_4.flash(p160, v_u_9, 4.4 * v161, 0.22)
			v_u_4.ring(p_u_131.ground(p160, 0.12), v_u_11, 3.2 * v161, 0.28, v_u_7.Ring)
			if not p159.lite then
				v_u_137(p160, v161, 4)
			end
			p_u_131.hitSound(p160)
		end,
		["hit"] = function(_, p162, _) -- name: hit
			-- upvalues: (copy) p_u_131, (ref) v_u_9
			p_u_131.burst("Impact", p162, v_u_9, 0.6)
		end
	}
	v132.zohakuten_e = {
		["cast"] = function(p163) -- name: cast
			-- upvalues: (copy) p_u_131, (ref) v_u_9
			p_u_131.skillCast(p163, v_u_9)
		end,
		["windup"] = function(p164, _, p165) -- name: windup
			-- upvalues: (ref) v_u_4, (ref) v_u_9
			v_u_4.flash(p164.eye, v_u_9, 5 * p164.size, (math.max(p165, 0.1)))
		end,
		["land"] = function(p_u_166, p167) -- name: land
			-- upvalues: (copy) p_u_131, (ref) v_u_125, (ref) v_u_130, (ref) v_u_4, (ref) v_u_9, (ref) v_u_80, (ref) v_u_11, (ref) v_u_7, (ref) v_u_60, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6
			local v_u_168 = p_u_166.size
			local v_u_169 = p_u_166.ability.radius * v_u_168
			local v_u_170 = p_u_131.ground(p167, 0.1)
			local v171 = 6.5 * v_u_168
			local v172 = -p_u_166.dir.X
			local v173 = -p_u_166.dir.Z
			local v174 = math.atan2(v172, v173)
			local v_u_175 = {}
			for v176 = 1, 5 do
				local v177 = v174 + (v176 - 1) / 5 * 3.141592653589793 * 2
				local v178 = -math.sin(v177)
				local v179 = -math.cos(v177)
				local v180 = Vector3.new(v178, 0, v179)
				local v181 = {
					["d"] = v_u_125(3 * v_u_168, 1.8),
					["out"] = v180,
					["at"] = v_u_170 + v180 * v171
				}
				table.insert(v_u_175, v181)
			end
			local v_u_182 = os.clock()
			local v_u_183 = 0
			p_u_131.frame(function()
				-- upvalues: (copy) v_u_182, (copy) v_u_175, (copy) v_u_168, (ref) v_u_130, (ref) v_u_183, (ref) v_u_4, (ref) v_u_9, (copy) p_u_166, (ref) v_u_80, (copy) v_u_170, (ref) v_u_11, (copy) v_u_169, (ref) v_u_7, (ref) v_u_60, (ref) p_u_131, (ref) v_u_12, (ref) v_u_10, (ref) v_u_6
				local v184 = os.clock() - v_u_182
				local v185 = v184 / 0.16
				local v186 = 1 - (1 - math.clamp(v185, 0, 1)) ^ 3
				local v187 = (v184 - 1.5 + 0.35) / 0.35
				local v188 = math.clamp(v187, 0, 1)
				local v189 = v188 * v188 * (3 - v188 * 2)
				for v190, v191 in v_u_175 do
					local v192 = v184 - 0.1 - (v190 - 1) * 0.07
					local v193 = (v192 < 0 or v192 >= 0.3) and 1 or 1 + 0.3 * (1 - v192 / 0.3)
					local v194 = -2 * v_u_168 + 4.6 * v_u_168 * v186 - 5 * v_u_168 * v189
					v_u_130(v191.d, CFrame.lookAt(v191.at + Vector3.new(0, 1, 0) * v194, v191.at + Vector3.new(0, 1, 0) * v194 + v191.out), v193)
					if v189 <= 0 then
						continue
					end
					for _, v195 in v191.d.decals do
						v195.Transparency = v189
					end
					v191.d.body.Transparency = v189
				end
				while v_u_183 < 5 and v_u_183 * 0.07 + 0.1 <= v184 do
					v_u_183 = v_u_183 + 1
					local v196 = v_u_175[v_u_183]
					local v197 = v196.at + Vector3.new(0, 2.6, 0) * v_u_168 + v196.out * 1.3 * v_u_168
					v_u_4.flash(v197, v_u_9, 4 * v_u_168, 0.18)
					if not p_u_166.lite or v_u_183 == 1 then
						v_u_80(CFrame.lookAt(v197, v197 - v196.out), 2.4 * v_u_168, 12 * v_u_168, 9 * v_u_168, v_u_9, 0.5)
					end
					if v_u_183 ~= 5 then
						continue
					end
					v_u_4.ring(v_u_170, v_u_11, v_u_169 * 0.8, 0.5, v_u_7.ZohakuBoom)
					v_u_4.ring(v_u_170, v_u_9, v_u_169 * 1.05, 0.65, v_u_7.ZohakuBoom)
					v_u_60(v_u_170, v_u_169 * 0.4, v_u_169 * 1.6, v_u_7.Glow, v_u_9, 0.45, 0.15, 0.1, 0.4, nil, 0.2)
					if not p_u_166.lite then
						local v198 = { v_u_12, v_u_11, v_u_10 }
						p_u_131.chunks(v_u_170 + Vector3.new(0, 0.5, 0), v198, 8, 30, 0.5 * v_u_168, 0.8, false, 1)
					end
					v_u_6.play("Explosion", {
						["at"] = v_u_170,
						["volume"] = p_u_166.mine and 0.8 or 0.4
					})
					if not p_u_166.mine then
						continue
					end
					v_u_4.shake(0.3, 0.3)
				end
				if v184 < 1.5 then
					return true
				end
				for _, v199 in v_u_175 do
					v199.d.body:Destroy()
					v199.d.head:Destroy()
				end
				return false
			end)
		end,
		["hit"] = function(p200, p201, _) -- name: hit
			-- upvalues: (ref) v_u_70, (ref) v_u_7, (ref) v_u_9
			v_u_70(p201, v_u_7.ZohakuBoom, v_u_9, 1.5 * p200.size, 6 * p200.size, 0.35, 0.3)
		end
	}
	v132.zohakuten_r = {
		["cast"] = function(p202) -- name: cast
			-- upvalues: (copy) p_u_131, (ref) v_u_9
			p_u_131.skillCast(p202, v_u_9, true)
		end,
		["windup"] = function(p203, p204, p205) -- name: windup
			-- upvalues: (copy) p_u_131, (ref) v_u_60, (ref) v_u_7, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (ref) v_u_4
			local v_u_206 = p203.size
			local v207 = p203.ability.radius * v_u_206
			local v208 = p_u_131.ground(p204, 0.12)
			local v209 = p205 + 0.4
			v_u_60(v208, v207, v207 * 2.3, v_u_7.Glow, v_u_11, 0.35, 0.25, v209, 0.4, nil, 0)
			v_u_60(v208, v207 * 1.6, v207 * 2.1, v_u_7.Ring, v_u_9, 0.15, 0.25, v209, 0.4, 0, 0.2)
			for v210 = 1, 5 do
				local v211 = (v210 - 1) / 5 * 3.141592653589793 * 2
				local v212 = math.sin(v211)
				local v213 = math.cos(v211)
				local v_u_214 = v208 + Vector3.new(v212, 0, v213) * v207 * 1.02
				v_u_60(v_u_214, 1, 5.5 * v_u_206, v_u_7.ZohakuDrum, v_u_8, 0, 0.2, v209, 0.35, math.deg(v211), 0)
				p_u_131.after(v210 * 0.12, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_214, (ref) v_u_9, (copy) v_u_206, (ref) v_u_7
					v_u_4.ring(v_u_214, v_u_9, 4 * v_u_206, 0.35, v_u_7.ZohakuBoom)
				end)
			end
			if p203.mine then
				v_u_4.shake(0.15, 0.4)
			end
		end,
		["strike"] = function(p_u_215, p_u_216, p217) -- name: strike
			-- upvalues: (copy) p_u_131, (ref) v_u_106, (ref) v_u_4, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15, (ref) v_u_1, (ref) v_u_8, (ref) v_u_7, (ref) v_u_60, (ref) v_u_11, (ref) v_u_10, (ref) v_u_9, (copy) v_u_137, (ref) v_u_113
			local v_u_218 = p_u_215.size
			local v_u_219 = p_u_215.lite
			local v220 = p_u_131.ground(p_u_216, 0)
			local v221 = p_u_216.X - p_u_215.origin.X
			local v222 = p_u_216.Z - p_u_215.origin.Z
			local v223 = Vector3.new(v221, 0, v222)
			local v224
			if v223.Magnitude > 1 then
				v224 = v223.Unit
			else
				v224 = p_u_131.flatUnit(p_u_215.dir)
			end
			local v225 = (math.random() - 0.5) * 1.4
			local v_u_226 = CFrame.Angles(0, v225, 0):VectorToWorldSpace(v224)
			local v_u_227 = v220 + v_u_226 * 6 * v_u_218
			local v_u_228 = v_u_227 + Vector3.new(0, 13, 0) * v_u_218 - v_u_226 * 2.5 * v_u_218
			local v_u_229 = v220 + Vector3.new(0, 1.6, 0) * v_u_218
			local v230 = p217 - 0.16
			local v_u_231 = math.clamp(v230, 0.12, 0.6)
			local v232 = p217 - v_u_231 - 0.16
			local v233 = math.max(v232, 0)
			local v_u_234 = v_u_231 + 0.16 + 0.9
			p_u_131.after(v233, function()
				-- upvalues: (ref) v_u_106, (copy) v_u_218, (copy) v_u_234, (copy) v_u_219, (ref) v_u_4, (ref) v_u_12, (ref) v_u_13, (ref) v_u_15, (ref) v_u_1, (copy) v_u_227, (ref) v_u_8, (ref) v_u_7, (ref) v_u_60, (ref) v_u_11, (ref) p_u_131, (copy) v_u_231, (copy) v_u_228, (ref) v_u_226, (copy) v_u_229, (ref) v_u_10, (ref) v_u_9, (copy) p_u_216, (copy) p_u_215, (ref) v_u_137, (ref) v_u_113
				local v_u_235 = v_u_106(3.2 * v_u_218, true, v_u_234 + 0.2)
				local v_u_236 = v_u_219 and 0 or 7
				local v_u_237 = {}
				for v238 = 1, v_u_236 do
					local v239 = v_u_4.part
					local v240 = Vector3.new(1, 1, 1)
					local v241 = CFrame.new(0, -500, 0)
					local v242
					if v238 % 2 == 0 then
						v242 = v_u_12
					else
						v242 = v_u_13
					end
					local v243 = v239(v240, v241, v242, {
						["material"] = v_u_15
					})
					v_u_1:AddItem(v243, v_u_234 + 0.2)
					table.insert(v_u_237, v243)
				end
				local v_u_244, v_u_245, v_u_246
				if v_u_219 then
					local v247 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_227), v_u_8, {
						["transparency"] = 1
					})
					v_u_1:AddItem(v247, v_u_234 + 0.2)
					v_u_244 = Instance.new("Attachment")
					v_u_244.Parent = v247
					v_u_245 = Instance.new("Attachment")
					v_u_245.Parent = v247
					v_u_246 = Instance.new("Beam")
					v_u_246.Attachment0 = v_u_244
					v_u_246.Attachment1 = v_u_245
					v_u_246.Texture = v_u_7.ZohakuBark
					v_u_246.TextureMode = Enum.TextureMode.Wrap
					v_u_246.TextureLength = 3 * v_u_218
					v_u_246.LightEmission = 0
					v_u_246.LightInfluence = 0
					v_u_246.FaceCamera = true
					v_u_246.Width0 = 3 * v_u_218
					v_u_246.Width1 = 2.2 * v_u_218
					v_u_246.Segments = 8
					v_u_246.Parent = v247
				else
					v_u_246 = nil
					v_u_244 = nil
					v_u_245 = nil
				end
				v_u_60(v_u_227, 2, 9 * v_u_218, v_u_7.Glow, v_u_11, 0.1, 0.1, 0.6, 0.5, nil, 0)
				v_u_4.ring(v_u_227 + Vector3.new(0, 0.15, 0), v_u_11, 5 * v_u_218, 0.4, v_u_7.Ring)
				if not v_u_219 then
					local v248 = { v_u_12, v_u_11, v_u_13 }
					p_u_131.chunks(v_u_227 + Vector3.new(0, 0.6, 0), v248, 6, 26, 0.6 * v_u_218, 0.9, false, 1.2)
				end
				local v_u_249 = os.clock()
				local v_u_250 = false
				p_u_131.frame(function()
					-- upvalues: (copy) v_u_249, (ref) v_u_231, (ref) v_u_227, (ref) v_u_218, (ref) v_u_228, (ref) v_u_226, (ref) v_u_229, (ref) v_u_250, (ref) v_u_4, (ref) v_u_10, (ref) v_u_9, (ref) p_u_131, (ref) p_u_216, (ref) v_u_11, (ref) p_u_215, (ref) v_u_7, (ref) v_u_60, (ref) v_u_219, (ref) v_u_137, (ref) v_u_113, (copy) v_u_235, (copy) v_u_237, (copy) v_u_236, (ref) v_u_246, (ref) v_u_244, (ref) v_u_245, (ref) v_u_234
					local v251 = os.clock() - v_u_249
					local v252, v253, v254
					if v251 < v_u_231 then
						local v255 = v251 / v_u_231
						local v256 = math.clamp(v255, 0, 1)
						local v257 = v256 * v256 * (3 - v256 * 2)
						v252 = (v_u_227 - Vector3.new(0, 3, 0) * v_u_218):Lerp(v_u_228, v257)
						v253 = (Vector3.new(0, 1, 0)):Lerp(-v_u_226, v257 * 0.8).Unit
						v254 = v257 * 0.5 + 0.15
					else
						local v258 = (v251 - v_u_231) / 0.16
						local v259 = math.clamp(v258, 0, 1)
						v252 = v_u_228:Lerp(v_u_229, v259 * v259)
						v253 = (v_u_229 - v_u_228).Unit
						if v259 < 1 then
							v254 = 0.8
						else
							v254 = 0
						end
					end
					if v_u_231 + 0.16 <= v251 and not v_u_250 then
						v_u_250 = true
						v_u_4.flash(v_u_229, v_u_10, 6 * v_u_218, 0.14)
						v_u_4.flash(v_u_229, v_u_9, 13 * v_u_218, 0.32)
						v_u_4.ring(p_u_131.ground(p_u_216, 0.15), v_u_11, p_u_215.ability.strikeRadius or 8, 0.45, v_u_7.Shockwave)
						v_u_4.ring(p_u_131.ground(p_u_216, 0.2), v_u_9, (p_u_215.ability.strikeRadius or 8) * 1.3, 0.55, v_u_7.Ring)
						v_u_60(p_u_131.ground(p_u_216, 0.1), 3, 12 * v_u_218, v_u_7.Glow, v_u_9, 0.3, 0.1, 0.2, 0.5, nil, 0.25)
						if not v_u_219 then
							v_u_137(v_u_229, v_u_218 * 1.6, 8)
						end
						p_u_131.hitSound(v_u_229, true)
						if p_u_215.mine then
							v_u_4.shake(0.25, 0.22)
						end
					end
					local v260 = (v251 - v_u_231 - 0.16 - 0.35) / 0.45
					local v261 = math.clamp(v260, 0, 1)
					local v262 = v261 * v261 * (3 - v261 * 2)
					local v263 = v252 - Vector3.new(0, 1, 0) * v262 * 6 * v_u_218
					local v264 = CFrame.lookAt
					local v265 = v263 + v253
					local v266 = v253.Y
					local v267 = v264(v263, v265, math.abs(v266) <= 0.95 and Vector3.new(0, 1, 0) or v_u_226)
					v_u_113(v_u_235, v267, v254)
					local v268 = v267 * CFrame.new(0, 0, v_u_235.s * 0.6)
					local v269 = v_u_227 - Vector3.new(0, 1.5, 0) * v_u_218
					local v270 = v268.Position
					local v271 = v_u_227.X
					local v272 = v270.Y
					local v273 = v_u_227.Y + 2
					local v274 = math.max(v272, v273)
					local v275 = v_u_227.Z
					local v276 = Vector3.new(v271, v274, v275):Lerp(v270, 0.25)
					for v277, v278 in v_u_237 do
						local v279 = (v277 - 1) / v_u_236
						local v280 = v277 / v_u_236
						local v281 = v269 * (1 - v279) ^ 2 + v276 * 2 * (1 - v279) * v279 + v270 * v279 * v279
						local v282 = v269 * (1 - v280) ^ 2 + v276 * 2 * (1 - v280) * v280 + v270 * v280 * v280
						local v283 = (2.3 - v280 * 0.9) * v_u_218
						local v284 = (v282 - v281).Magnitude * 1.25 + 0.1
						v278.Size = Vector3.new(v283, v283, v284)
						v278.CFrame = CFrame.lookAt((v281 + v282) / 2, v282)
						v278.Transparency = v262
					end
					local v285 = v_u_246
					if v285 and (v_u_244 and v_u_245) then
						v_u_244.WorldCFrame = CFrame.lookAt(v269, v276)
						v_u_245.WorldCFrame = CFrame.lookAt(v270, v270 + (v270 - v276))
						v285.CurveSize0 = (v276 - v269).Magnitude * 0.6
						v285.CurveSize1 = 0
						v285.Transparency = NumberSequence.new(v262)
					end
					for _, v286 in v_u_235.parts do
						v286.Transparency = v262
					end
					v_u_235.jaw.Transparency = v262
					if v_u_234 > v251 then
						return true
					end
					for _, v287 in v_u_235.parts do
						v287:Destroy()
					end
					v_u_235.jaw:Destroy()
					for _, v288 in v_u_237 do
						v288:Destroy()
					end
					return false
				end)
			end)
		end,
		["hit"] = function(_, p289, _) -- name: hit
			-- upvalues: (copy) p_u_131, (ref) v_u_9
			p_u_131.burst("Impact", p289, v_u_9, 0.8)
		end
	}
	return v132
end