local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.EpicKit8)
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v6 = require(script.Parent.Parent.Preload)
local v_u_7 = require(script.Parent.Parent.Parent.Sfx)
local v_u_8 = require(v2.Shared.Config.Textures)
v6.images({
	v_u_8.DreamMoon,
	v_u_8.DreamEye,
	v_u_8.DreamStar,
	v_u_8.DreamZ,
	v_u_8.FxSmoke,
	v_u_8.Glow
})
local v_u_9 = Color3.fromHex("8A5CFF")
local v_u_10 = Color3.fromRGB(196, 170, 255)
local v_u_11 = Color3.fromHex("F0E6FF")
local v_u_12 = Color3.fromRGB(150, 120, 230)
local v_u_13 = Color3.fromRGB(40, 16, 96)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.Material.Neon
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_21(p17, p18, p19, p20) -- name: groundEye
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_14
	v_u_4.flat(p17, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.1,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["rot"] = nil,
		["flip"] = "4x4",
		["image"] = v_u_8.DreamEye,
		["color"] = v_u_14,
		["life"] = p19,
		["sizes"] = {
			{ 0, p18 },
			{ 1, p18 }
		},
		["alphas"] = {
			{ 0, 1 },
			{ 0.08, 0 },
			{ 0.9, 0 },
			{ 1, 1 }
		},
		["rot"] = p20
	})
end
local function v_u_27(p22, p23, p24, p25, p26) -- name: stars
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_14, (copy) v_u_10
	v_u_4.puff(p22, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.7,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["drag"] = 3,
		["image"] = v_u_8.DreamStar,
		["color"] = v_u_14,
		["color2"] = v_u_10,
		["count"] = p23,
		["life"] = { 0.5, 0.9 },
		["sizes"] = {
			{ 0, p25 },
			{ 1, p25 * 0.2 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 0.6, 0.1 },
			{ 1, 1 }
		},
		["speed"] = { p24 * 0.5, p24 },
		["spread"] = Vector2.new(p26 or 180, p26 or 180)
	})
end
local function v_u_34(p28, p29, p30, p31, p32, p33) -- name: mist
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_12, (copy) v_u_10
	v_u_4.puff(p28, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.3,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["drag"] = 2,
		["spin"] = 30,
		["flip"] = "4x4r",
		["box"] = nil,
		["image"] = v_u_8.FxSmoke,
		["color"] = v_u_12,
		["color2"] = v_u_10,
		["count"] = p29,
		["life"] = { p32 * 0.7, p32 },
		["sizes"] = {
			{ 0, p30 * 0.6 },
			{ 1, p30 * 1.3 }
		},
		["alphas"] = {
			{ 0, 1 },
			{ 0.15, 0.25 },
			{ 0.7, 0.4 },
			{ 1, 1 }
		},
		["speed"] = { p31 * 0.4, p31 },
		["spread"] = Vector2.new(180, 40),
		["box"] = p33
	})
end
local function v_u_38(p35, p36, p37) -- name: sleep
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_11, (copy) v_u_10
	v_u_4.puff(p35, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.3,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["accel"] = Vector3.new(1.5, 0, 0),
		["spin"] = 20,
		["image"] = v_u_8.DreamZ,
		["color"] = v_u_11,
		["color2"] = v_u_10,
		["count"] = p36,
		["life"] = { 0.9, 1.3 },
		["sizes"] = {
			{ 0, p37 * 0.5 },
			{ 0.3, p37 },
			{ 1, p37 * 1.2 }
		},
		["alphas"] = {
			{ 0, 1 },
			{ 0.15, 0 },
			{ 0.75, 0.15 },
			{ 1, 1 }
		},
		["speed"] = { 3, 5 },
		["spread"] = Vector2.new(25, 25)
	})
end
return function(p_u_39)
	-- upvalues: (copy) v_u_9, (copy) v_u_11, (copy) v_u_27, (copy) v_u_38, (copy) v_u_34, (copy) v_u_5, (copy) v_u_1, (copy) v_u_8, (copy) v_u_14, (copy) v_u_10, (copy) v_u_4, (copy) v_u_21, (copy) v_u_15, (copy) v_u_13, (copy) v_u_16, (copy) v_u_7, (copy) v_u_3
	local v40 = {}
	local function v_u_44(p41, p42) -- name: dreamCast
		-- upvalues: (copy) p_u_39, (ref) v_u_9, (ref) v_u_11, (ref) v_u_27, (ref) v_u_38, (ref) v_u_34, (ref) v_u_5
		local v43 = p41.size
		p_u_39.burst("Flash", p41.eye, v_u_9, (p42 and 0.3 or 0.2) * v43)
		p_u_39.glint(p41.eye + p41.dir * 0.8, v_u_11, (p42 and 4 or 3) * v43, 0.16)
		v_u_27(p41.eye, p41.lite and 4 or 10, 10, 0.9 * v43)
		if not p41.lite then
			v_u_38(p41.eye + Vector3.new(0, 1.5, 0), p42 and 3 or 2, 1.2 * v43)
			v_u_34(p_u_39.ground(p41.feet, 0.5), p42 and 6 or 3, 3 * v43, 4, 0.9)
		end
		if p41.mine then
			v_u_5.shake(p42 and 0.1 or 0.05, 0.14)
		end
	end
	v40.lower_moon_a = {
		["cast"] = function(p45) -- name: cast
			-- upvalues: (copy) p_u_39, (ref) v_u_10, (ref) v_u_27
			local v46 = p45.size
			p_u_39.glint(p45.eye + p45.dir * 1.2, v_u_10, 2.4 * v46, 0.1)
			if not p45.lite then
				v_u_27(p45.eye + p45.dir * 1.2, 3, 8, 0.6 * v46)
			end
		end,
		["shot"] = function(p47, p48) -- name: moonShot
			-- upvalues: (ref) v_u_5, (ref) v_u_9, (ref) v_u_1, (ref) v_u_8, (ref) v_u_11, (ref) v_u_14, (ref) v_u_10, (ref) v_u_4, (copy) p_u_39
			local v49 = p47.size
			local v_u_50 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p48, v_u_9, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_50, 3)
			local v51 = Instance.new("Attachment")
			v51.Parent = v_u_50
			local v_u_52 = Instance.new("ParticleEmitter")
			v_u_52.Texture = v_u_8.DreamMoon
			v_u_52.Color = ColorSequence.new(v_u_11)
			v_u_52.LightEmission = 0.5
			v_u_52.LightInfluence = 0
			v_u_52.Lifetime = NumberRange.new(0.06)
			v_u_52.Speed = NumberRange.new(0)
			v_u_52.Size = NumberSequence.new(0.85 * v49)
			v_u_52.LockedToPart = true
			v_u_52.Rate = 70
			v_u_52.Parent = v51
			local v_u_53 = Instance.new("ParticleEmitter")
			v_u_53.Texture = v_u_8.Glow
			v_u_53.Color = ColorSequence.new(v_u_9)
			v_u_53.LightEmission = 0.8
			v_u_53.LightInfluence = 0
			v_u_53.Lifetime = NumberRange.new(0.1)
			v_u_53.Speed = NumberRange.new(0)
			v_u_53.Size = NumberSequence.new(1.3 * v49)
			v_u_53.ZOffset = -0.5
			v_u_53.LockedToPart = true
			v_u_53.Rate = 30
			v_u_53.Parent = v51
			local v_u_54 = Instance.new("ParticleEmitter")
			v_u_54.Texture = v_u_8.DreamStar
			v_u_54.Color = ColorSequence.new(v_u_14, v_u_10)
			v_u_54.LightEmission = 0.7
			v_u_54.LightInfluence = 0
			v_u_54.Lifetime = NumberRange.new(0.3, 0.45)
			v_u_54.Size = v_u_4.seq({
				{ 0, 0.6 },
				{ 1, 0.1 }
			}, v49)
			v_u_54.Speed = NumberRange.new(0.5, 1.5)
			v_u_54.SpreadAngle = Vector2.new(180, 180)
			v_u_54.Rate = p47.lite and 12 or 40
			v_u_54.Parent = v51
			p_u_39.streak(v_u_50, v_u_10, v_u_9, 0.45 * v49, 0.14)
			if p47.mine then
				p_u_39.light(v_u_50, v_u_9, 6 * v49)
			end
			local v_u_55 = false
			return {
				["place"] = function(p56, p57) -- name: place
					-- upvalues: (copy) v_u_50, (copy) v_u_52
					v_u_50.CFrame = p56
					local v58 = p57 * 720 % 360
					v_u_52.Rotation = NumberRange.new(v58, v58)
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_55, (copy) v_u_52, (copy) v_u_53, (copy) v_u_54, (copy) v_u_50, (ref) v_u_1
					if not v_u_55 then
						v_u_55 = true
						v_u_52.Enabled = false
						v_u_52:Clear()
						v_u_53.Enabled = false
						v_u_54.Enabled = false
						local v59 = v_u_50:FindFirstChildWhichIsA("PointLight")
						if v59 then
							v59:Destroy()
						end
						v_u_1:AddItem(v_u_50, 0.5)
					end
				end
			}
		end,
		["impact"] = function(p60, p61) -- name: impact
			-- upvalues: (copy) p_u_39, (ref) v_u_21, (ref) v_u_34, (ref) v_u_27, (ref) v_u_38, (ref) v_u_11
			local v62 = p60.size
			local v63 = p_u_39.ground(p61, 0.1)
			local v64 = v_u_21
			local v65 = 4.2 * v62
			local v66 = p60.dir
			local v67 = v66.X
			local v68 = -v66.Z
			local v69 = math.atan2(v67, v68)
			v64(v63, v65, 0.9, (math.deg(v69)))
			v_u_34(p61, p60.lite and 2 or 5, 3 * v62, 6, 0.7)
			if not p60.lite then
				v_u_27(p61, 7, 14, 0.8 * v62)
				v_u_38(p61 + Vector3.new(0, 1, 0), 2, 0.9 * v62)
			end
			p_u_39.glint(p61, v_u_11, 2.8 * v62, 0.12)
			p_u_39.hitSound(p61)
		end,
		["hit"] = function(_, p70, _) -- name: hit
			-- upvalues: (copy) p_u_39, (ref) v_u_9
			p_u_39.burst("Impact", p70, v_u_9, 0.55)
		end
	}
	local function v_u_79(p71, p72, p73, p74, p75, p76, p77) -- name: bit
		-- upvalues: (ref) v_u_4, (ref) v_u_15
		local v78
		if p76 then
			v78 = v_u_4.wedge(p74, v_u_15, p77, 1)
		else
			v78 = v_u_4.part(p74, v_u_15, p77, 1)
		end
		v78.Size = p72
		table.insert(p71, {
			["p"] = v78,
			["off"] = p73,
			["alpha"] = p75
		})
		return v78
	end
	local function v_u_84(p80, p81, p82, p83) -- name: car
		-- upvalues: (copy) v_u_79, (ref) v_u_13, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
		v_u_79(p80, Vector3.new(3.2, 0.6, 6.4) * p82, CFrame.new(p82 * 0, p82 * 0.3, p82 * 0), v_u_13, 0.15, false, p83)
		if not p81 then
			v_u_79(p80, Vector3.new(3.6, 3.2, 6.4) * p82, CFrame.new(p82 * 0, p82 * 2, p82 * 0), v_u_9, 0.35, false, p83)
			v_u_79(p80, Vector3.new(3.9, 0.35, 6.6) * p82, CFrame.new(p82 * 0, p82 * 3.75, p82 * 0), v_u_13, 0.2, false, p83)
			v_u_79(p80, Vector3.new(3.75, 0.8, 5.4) * p82, CFrame.new(p82 * 0, p82 * 2.6, p82 * 0), v_u_11, 0.05, false, p83)
			return nil
		end
		v_u_79(p80, Vector3.new(3.6, 3, 6) * p82, CFrame.new(p82 * 0, p82 * 1.9, p82 * 0), v_u_9, 0.35, false, p83)
		v_u_79(p80, Vector3.new(3.6, 2.2, 1.8) * p82, CFrame.new(p82 * 0, p82 * 1.5, p82 * -3.9), v_u_10, 0.3, true, p83)
		v_u_79(p80, Vector3.new(3.2, 2, 2.4) * p82, CFrame.new(p82 * 0, p82 * 4.4, p82 * 1.6), v_u_9, 0.3, false, p83)
		v_u_79(p80, Vector3.new(3.75, 0.7, 2.2) * p82, CFrame.new(p82 * 0, p82 * 4.5, p82 * 1.6), v_u_11, 0.05, false, p83)
		return v_u_79(p80, Vector3.new(0.9, 1.6, 0.9) * p82, CFrame.new(p82 * 0, p82 * 4.2, p82 * -1.8), v_u_13, 0.2, false, p83)
	end
	local function v_u_126(p85, p86, p_u_87) -- name: train
		-- upvalues: (ref) v_u_4, (copy) p_u_39, (ref) v_u_11, (ref) v_u_9, (copy) v_u_84, (ref) v_u_8, (ref) v_u_16, (ref) v_u_10, (ref) v_u_14, (ref) v_u_27, (ref) v_u_34
		local v_u_88 = p85.size
		local v_u_89 = p85.lite
		local v90 = p_u_87.X - p86.X
		local v91 = p_u_87.Z - p86.Z
		local v92 = Vector3.new(v90, 0, v91)
		local v_u_93
		if v92.Magnitude > 0.5 then
			v_u_93 = v92.Unit
		else
			v_u_93 = p85.dir
		end
		local v94 = v_u_4.side(v_u_93)
		local v95 = v92.Magnitude
		for _, v96 in { -1, 1 } do
			p_u_39.groundLine(p86 + v94 * v96 * 1.3 * v_u_88, p_u_87 + v94 * v96 * 1.3 * v_u_88, 0.35 * v_u_88, v_u_11, 1.1, 0.15)
		end
		if not v_u_89 then
			local v97 = v95 / 4
			local v98 = math.floor(v97)
			local v99 = math.min(v98, 18)
			for v100 = 1, v99 do
				local v101 = p86 + v_u_93 * (v100 * v95 / (v99 + 1))
				p_u_39.groundLine(v101 - v94 * 1.8 * v_u_88, v101 + v94 * 1.8 * v_u_88, 0.5 * v_u_88, v_u_9, 0.9, 0.35)
			end
		end
		local v_u_102 = 9.25 * v_u_88
		local v_u_103 = {}
		local v104 = nil
		for v105 = 1, v_u_89 and 2 or 3 do
			local v106 = {}
			v104 = v_u_84(v106, v105 == 1, 1.25 * v_u_88, 1.9) or v104
			table.insert(v_u_103, v106)
		end
		if v104 then
			local v107 = Instance.new("ParticleEmitter")
			v107.Texture = v_u_8.FxSmoke
			v107.FlipbookLayout = v_u_16
			v107.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v107.Color = ColorSequence.new(v_u_11, v_u_10)
			v107.LightEmission = 0.3
			v107.LightInfluence = 0
			v107.Lifetime = NumberRange.new(0.5, 0.8)
			v107.Size = v_u_4.seq({
				{ 0, 1.4 },
				{ 1, 3.6 }
			}, v_u_88)
			v107.Transparency = v_u_4.seq({
				{ 0, 0.3 },
				{ 0.6, 0.5 },
				{ 1, 1 }
			})
			v107.Speed = NumberRange.new(3, 6)
			v107.EmissionDirection = Enum.NormalId.Top
			v107.SpreadAngle = Vector2.new(15, 15)
			v107.Rotation = NumberRange.new(0, 360)
			v107.Rate = v_u_89 and 12 or 40
			v107.Parent = v104
		end
		local v108 = v_u_103[#v_u_103][1].p
		if not v_u_89 then
			local v109 = Instance.new("ParticleEmitter")
			v109.Texture = v_u_8.DreamStar
			v109.Color = ColorSequence.new(v_u_14, v_u_10)
			v109.LightEmission = 0.7
			v109.LightInfluence = 0
			v109.Lifetime = NumberRange.new(0.3, 0.5)
			v109.Size = v_u_4.seq({
				{ 0, 0.7 },
				{ 1, 0.1 }
			}, v_u_88)
			v109.Speed = NumberRange.new(2, 5)
			v109.SpreadAngle = Vector2.new(70, 70)
			v109.EmissionDirection = Enum.NormalId.Top
			v109.Rate = 50
			v109.Parent = v108
		end
		local v110 = v_u_103[1][1].p
		if p85.mine then
			p_u_39.light(v110, v_u_9, 14 * v_u_88)
		end
		local v_u_111 = p86 - v_u_93 * 2 * v_u_88
		local v_u_112 = p_u_87 + v_u_93 * 8 * v_u_88
		local v_u_113 = CFrame.lookAt(Vector3.new(0, 0, 0), v_u_93).Rotation
		p_u_39.animate(0.95, 0, function(p114)
			-- upvalues: (copy) v_u_111, (copy) v_u_112, (copy) v_u_103, (copy) v_u_93, (copy) v_u_102, (copy) v_u_113
			local v115 = p114 * 0.95
			local v116 = v115 / 0.65
			local v117 = v_u_111:Lerp(v_u_112, 1 - (1 - math.min(v116, 1)) ^ 1.6)
			local v118
			if v115 < 0.06 then
				v118 = 1 - v115 / 0.06
			elseif v115 > 0.65 then
				local v119 = (v115 - 0.65) / 0.3
				v118 = math.clamp(v119, 0, 1)
			else
				v118 = 0
			end
			for v120, v121 in v_u_103 do
				local v122 = CFrame.new(v117 - v_u_93 * v_u_102 * (v120 - 1)) * v_u_113
				for _, v123 in v121 do
					v123.p.CFrame = v122 * v123.off
					v123.p.Transparency = v123.alpha + (1 - v123.alpha) * v118
				end
			end
			if p114 >= 1 then
				for _, v124 in v_u_103 do
					for _, v125 in v124 do
						v125.p:Destroy()
					end
				end
			end
		end)
		p_u_39.after(0.65, function()
			-- upvalues: (ref) v_u_27, (ref) p_u_39, (copy) p_u_87, (copy) v_u_89, (copy) v_u_88, (ref) v_u_34
			v_u_27(p_u_39.ground(p_u_87, 2.5), v_u_89 and 6 or 20, 18, 1.1 * v_u_88)
			v_u_34(p_u_39.ground(p_u_87, 2), v_u_89 and 2 or 6, 4 * v_u_88, 8, 0.8)
		end)
	end
	v40.lower_moon_e = {
		["cast"] = function(p127) -- name: cast
			-- upvalues: (copy) v_u_44
			v_u_44(p127, false)
		end,
		["beam"] = function(p128, p129, p130) -- name: beam
			-- upvalues: (copy) p_u_39, (copy) v_u_126, (ref) v_u_5, (ref) v_u_7
			local v131 = p_u_39.ground(p129, 0)
			v_u_126(p128, v131, (p_u_39.ground(p130, 0)))
			if p128.mine then
				v_u_5.shake(0.14, 0.4)
			end
			v_u_7.play("Laser", {
				["at"] = v131,
				["volume"] = p128.mine and 0.5 or 0.3
			})
		end,
		["hit"] = function(p132, p133, _) -- name: hit
			-- upvalues: (copy) p_u_39, (ref) v_u_9, (ref) v_u_38
			p_u_39.burst("Impact", p133, v_u_9, 0.65)
			if not p132.lite then
				v_u_38(p133 + Vector3.new(0, 1, 0), 1, 0.9)
			end
		end
	}
	local function v_u_152(p134, p135, p_u_136, p_u_137) -- name: bigMoon
		-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_11, (copy) p_u_39
		local v138 = p_u_136 * 0.75
		local v_u_139 = p135 + p134.dir * p_u_136 * 0.35 + Vector3.new(0, 1, 0) * (p_u_136 * 0.3 + 3)
		local v_u_140 = p_u_137 + 1.2
		v_u_4.puff(v_u_139, {
			["image"] = nil,
			["color"] = nil,
			["emission"] = 0.75,
			["count"] = 1,
			["life"] = nil,
			["sizes"] = nil,
			["alphas"] = nil,
			["speed"] = nil,
			["zoff"] = -3,
			["image"] = v_u_8.Glow,
			["color"] = v_u_9,
			["life"] = { v_u_140, v_u_140 },
			["sizes"] = {
				{ 0, v138 * 0.4 },
				{ 0.12, v138 * 1.5 },
				{ 0.85, v138 * 1.5 },
				{ 1, v138 * 0.6 }
			},
			["alphas"] = {
				{ 0, 1 },
				{ 0.12, 0.35 },
				{ 0.85, 0.4 },
				{ 1, 1 }
			},
			["speed"] = { 0 }
		})
		local v_u_141 = v_u_4.piece("w8_lower_moon", v138, v_u_140)
		if v_u_141 then
			local v_u_142 = CFrame.lookAt(v_u_139, v_u_139 - p134.dir).Rotation * v_u_4.thinZ(v_u_141) * CFrame.Angles(0, 0, -1.5707963267948966)
			local v_u_143 = os.clock()
			p_u_39.frame(function()
				-- upvalues: (copy) v_u_143, (copy) v_u_141, (ref) v_u_4, (copy) p_u_137, (copy) p_u_136, (copy) v_u_139, (copy) v_u_142, (copy) v_u_140
				local v144 = os.clock() - v_u_143
				if not v_u_141.Parent then
					return false
				end
				local v145 = 1 - v_u_4.smooth(v144 / 0.45)
				local v146 = v_u_4.smooth((v144 - p_u_137 - 0.2) / 0.8)
				local v147 = -(v145 + v146) * p_u_136 * 0.5
				local v148 = v_u_141
				local v149 = CFrame.new(v_u_139 + Vector3.new(0, 1, 0) * v147) * v_u_142
				local v150 = CFrame.Angles
				local v151 = v144 * 1.8
				v148.CFrame = v149 * v150(0, 0, math.sin(v151) * 0.25)
				v_u_141.Transparency = v146
				return v144 < v_u_140
			end)
		else
			v_u_4.puff(v_u_139, {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0.5,
				["count"] = 1,
				["life"] = nil,
				["sizes"] = nil,
				["alphas"] = nil,
				["speed"] = nil,
				["image"] = v_u_8.DreamMoon,
				["color"] = v_u_11,
				["life"] = { v_u_140, v_u_140 },
				["sizes"] = {
					{ 0, v138 * 0.3 },
					{ 0.1, v138 },
					{ 0.85, v138 },
					{ 1, v138 * 0.5 }
				},
				["alphas"] = {
					{ 0, 1 },
					{ 0.1, 0 },
					{ 0.85, 0 },
					{ 1, 1 }
				},
				["speed"] = { 0 }
			})
		end
	end
	local function v_u_162(p153, p154, p155) -- name: asleep
		-- upvalues: (ref) v_u_4, (copy) p_u_39, (ref) v_u_9, (ref) v_u_1, (ref) v_u_8, (ref) v_u_11, (ref) v_u_10, (ref) v_u_3, (ref) v_u_27
		local v_u_156 = v_u_4.foe(p155)
		if v_u_156 then
			v_u_156 = v_u_156:FindFirstChild("Head")
		end
		local v157 = p153.ability.freeze or 3
		if v_u_156 and v_u_156:IsA("BasePart") then
			local v158 = Instance.new("Attachment")
			local v159 = v_u_156.Size.Y * 0.5 + 1.2
			v158.Position = Vector3.new(0, v159, 0)
			v158.Parent = v_u_156
			v_u_1:AddItem(v158, v157 + 1.5)
			local v_u_160 = Instance.new("ParticleEmitter")
			v_u_160.Texture = v_u_8.DreamMoon
			v_u_160.Color = ColorSequence.new(v_u_11)
			v_u_160.LightEmission = 0.5
			v_u_160.LightInfluence = 0
			v_u_160.Lifetime = NumberRange.new(0.08)
			v_u_160.Speed = NumberRange.new(0)
			v_u_160.Size = NumberSequence.new(0.75)
			v_u_160.Rotation = NumberRange.new(-15, 15)
			v_u_160.LockedToPart = true
			v_u_160.Rate = 40
			v_u_160.Parent = v158
			local v_u_161 = Instance.new("ParticleEmitter")
			v_u_161.Texture = v_u_8.DreamZ
			v_u_161.Color = ColorSequence.new(v_u_11, v_u_10)
			v_u_161.LightEmission = 0.3
			v_u_161.LightInfluence = 0
			v_u_161.Lifetime = NumberRange.new(1, 1.3)
			v_u_161.Size = v_u_4.seq({
				{ 0, 0.3 },
				{ 0.3, 0.55 },
				{ 1, 0.7 }
			})
			v_u_161.Transparency = v_u_4.seq({
				{ 0, 1 },
				{ 0.15, 0 },
				{ 0.75, 0.15 },
				{ 1, 1 }
			})
			v_u_161.Speed = NumberRange.new(2, 3)
			v_u_161.EmissionDirection = Enum.NormalId.Top
			v_u_161.SpreadAngle = Vector2.new(15, 15)
			v_u_161.Acceleration = Vector3.new(1.2, 0, 0)
			v_u_161.Rotation = NumberRange.new(-20, 20)
			v_u_161.Rate = 2.5
			v_u_161.Parent = v158
			v_u_161:Emit(1)
			p_u_39.after(v157, function()
				-- upvalues: (copy) v_u_160, (copy) v_u_161, (copy) v_u_156, (ref) v_u_3, (ref) v_u_27
				v_u_160.Enabled = false
				v_u_161.Enabled = false
				if v_u_156.Parent and v_u_156:IsDescendantOf(v_u_3) then
					v_u_27(v_u_156.Position + Vector3.new(0, 1, 0), 6, 8, 0.7)
				end
			end)
		else
			p_u_39.burst("Impact", p154, v_u_9, 0.6)
		end
	end
	v40.lower_moon_r = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["land"] = nil,
		["hit"] = nil,
		["cast"] = function(p163) -- name: cast
			-- upvalues: (copy) v_u_44
			v_u_44(p163, true)
		end,
		["windup"] = function(p164, p165, p166) -- name: windup
			-- upvalues: (copy) p_u_39, (ref) v_u_4, (ref) v_u_8, (ref) v_u_13, (ref) v_u_34, (ref) v_u_10
			local v167 = p164.size
			local v168 = p164.ability.radius * v167
			local v169 = p164.ability.freeze or 3
			local v170 = p_u_39.ground(p165, 0.06)
			v_u_4.flat(v170, {
				["image"] = nil,
				["color"] = nil,
				["emission"] = 0,
				["life"] = nil,
				["sizes"] = nil,
				["alphas"] = nil,
				["image"] = v_u_8.Glow,
				["color"] = v_u_13,
				["life"] = p166 + v169 + 0.8,
				["sizes"] = {
					{ 0, v168 * 0.5 },
					{ 0.12, v168 * 2.2 },
					{ 1, v168 * 2.3 }
				},
				["alphas"] = {
					{ 0, 0.8 },
					{ 0.12, 0.4 },
					{ 0.8, 0.45 },
					{ 1, 1 }
				}
			})
			local v171 = v_u_34
			local v172 = v170 + Vector3.new(0, 1.5, 0)
			local v173 = p164.lite and 8 or 20
			local v174 = 8 * v167
			local v175 = p166 + v169 * 0.6
			local v176 = v168 * 1.6
			local v177 = v168 * 1.6
			v171(v172, v173, v174, 3, v175, (Vector3.new(v176, 2, v177)))
			p_u_39.inward(v170 + Vector3.new(0, 2, 0), v_u_10, p164.lite and 4 or 10, v168, (math.max(p166, 0.12)))
		end,
		["land"] = function(p178, p179) -- name: land
			-- upvalues: (copy) p_u_39, (copy) v_u_152, (ref) v_u_21, (ref) v_u_5, (ref) v_u_14, (ref) v_u_1, (ref) v_u_8, (ref) v_u_10, (ref) v_u_4, (ref) v_u_27, (ref) v_u_11, (ref) v_u_7, (ref) v_u_34
			local v_u_180 = p178.size
			local v_u_181 = p178.lite
			local v182 = p178.ability.radius * v_u_180
			local v_u_183 = p178.ability.freeze or 3
			local v_u_184 = p_u_39.ground(p179, 0.1)
			v_u_152(p178, v_u_184, v182, v_u_183)
			for _ = 1, v_u_181 and 4 or 9 do
				local v185 = math.random() * 3.141592653589793 * 2
				local v186 = math.random()
				local v187 = v182 * (math.sqrt(v186) * 0.75 + 0.15)
				local v188 = math.cos(v185)
				local v189 = math.sin(v185)
				local v_u_190 = v_u_184 + Vector3.new(v188, 0, v189) * v187
				p_u_39.after(math.random() * 0.4, function()
					-- upvalues: (ref) v_u_21, (copy) v_u_190, (copy) v_u_180, (copy) v_u_183
					v_u_21(v_u_190, (3.5 + math.random() * 2.5) * v_u_180, v_u_183, math.random() * 40 - 20)
				end)
			end
			local v191 = v_u_5.part
			local v192 = v182 * 1.6
			local v193 = v182 * 1.6
			local v194 = v191(Vector3.new(v192, 1, v193), CFrame.new(v_u_184 + Vector3.new(0, 14, 0)), v_u_14, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v194, v_u_183 + 3)
			local v_u_195 = Instance.new("ParticleEmitter")
			v_u_195.Texture = v_u_8.DreamStar
			v_u_195.Color = ColorSequence.new(v_u_14, v_u_10)
			v_u_195.LightEmission = 0.7
			v_u_195.LightInfluence = 0
			v_u_195.Lifetime = NumberRange.new(2.2, 3)
			v_u_195.Size = v_u_4.seq({
				{ 0, 0.5 },
				{ 0.5, 0.9 },
				{ 1, 0.3 }
			}, v_u_180)
			v_u_195.Transparency = v_u_4.seq({
				{ 0, 1 },
				{ 0.1, 0 },
				{ 0.4, 0.5 },
				{ 0.6, 0 },
				{ 0.9, 0.3 },
				{ 1, 1 }
			})
			v_u_195.Speed = NumberRange.new(3, 5)
			v_u_195.EmissionDirection = Enum.NormalId.Bottom
			v_u_195.SpreadAngle = Vector2.new(15, 15)
			v_u_195.RotSpeed = NumberRange.new(-40, 40)
			v_u_195.Shape = Enum.ParticleEmitterShape.Box
			v_u_195.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_195.Rate = v_u_181 and 8 or 22
			v_u_195.Parent = v194
			task.delay(v_u_183, function()
				-- upvalues: (copy) v_u_195
				v_u_195.Enabled = false
			end)
			v_u_27(v_u_184 + Vector3.new(0, 0.4, 0), v_u_181 and 8 or 26, 30, 1.2 * v_u_180, 88)
			p_u_39.glint(v_u_184 + Vector3.new(0, 2, 0), v_u_11, 7 * v_u_180, 0.25)
			v_u_7.play("Hit", {
				["at"] = v_u_184,
				["volume"] = p178.mine and 0.7 or 0.4
			})
			if p178.mine then
				v_u_5.shake(0.18, 0.25)
			end
			p_u_39.after(v_u_183, function()
				-- upvalues: (ref) v_u_34, (copy) v_u_184, (copy) v_u_181, (copy) v_u_180, (ref) v_u_27
				v_u_34(v_u_184 + Vector3.new(0, 1, 0), v_u_181 and 3 or 8, 7 * v_u_180, 10, 0.9)
				v_u_27(v_u_184 + Vector3.new(0, 2, 0), v_u_181 and 6 or 16, 20, 1 * v_u_180)
			end)
		end,
		["hit"] = function(p196, p197, p198) -- name: hit
			-- upvalues: (copy) p_u_39, (ref) v_u_9, (copy) v_u_162
			if p196.lite then
				p_u_39.burst("Impact", p197, v_u_9, 0.6)
			else
				v_u_162(p196, p197, p198)
			end
		end
	}
	return v40
end