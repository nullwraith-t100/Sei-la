local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(script.Parent.Parent.Parent.Perf)
local v_u_4 = require(v_u_1.Shared.Config.Textures)
local v_u_5 = Color3.new(1, 1, 1)
local v_u_6 = Color3.fromRGB(10, 10, 10)
local v_u_7 = Enum.Material.SmoothPlastic
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_1, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_4, (copy) v_u_3
	return {
		["w7_inner_hollow"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (copy) p_u_8, (ref) v_u_1, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (ref) v_u_4, (ref) v_u_3
			local v11 = v_u_2.color(p10.color)
			local v12 = p_u_9.headY / 1.5
			local v_u_13 = math.clamp(v12, 0.7, 3)
			local v14 = v_u_13 * 2.7
			local v_u_15 = -1
			local v_u_16 = 2.5
			local v38 = p_u_8.group(p_u_9, function(p17, p18)
				-- upvalues: (ref) v_u_15, (copy) v_u_13
				local v19 = (v_u_15 < 0 or p18 - v_u_15 > 0.95) and -1 or (p18 - v_u_15) / 0.95
				local v20 = p18 * 1.4
				local v21 = math.sin(v20) * 0.12
				local v22 = CFrame.new
				local v23 = v_u_13 * 1.9
				local v24 = v_u_13 * -1.8
				local v25 = p18 * 1.1
				local v26 = p17 * v22(v23, v24 + math.sin(v25) * 0.08 * v_u_13, v_u_13 * 0.3) * CFrame.Angles(0, 0, v21 * 0.3 + 0.3) * CFrame.Angles(v21, 1.5707963267948966, 0)
				if v19 < 0 then
					return v26
				end
				local v27 = v19 * 3.141592653589793
				local v28 = math.sin(v27)
				local v29 = v19 * 3.141592653589793 * 2
				local v30 = (p17 * CFrame.Angles(0, -v29, 0)).RightVector
				local v31 = v30:Cross(Vector3.new(0, 1, 0))
				local v32 = v_u_13 * 1.9 + v_u_13 * 1.7000000000000002 * v28
				local v33 = p17.Position + v30 * v32 + Vector3.new(0, 1, 0) * (v_u_13 * -0.9 + v28 * 0.5 * v_u_13)
				local v34 = CFrame.fromMatrix(v33, -v31, -v30)
				local v35 = v28 * 2.2
				local v36 = math.min(v35, 1)
				local v37 = math.clamp(v36, 0, 1)
				return v26:Lerp(v34, v37 * v37 * (3 - v37 * 2))
			end)
			local v39 = v_u_1:FindFirstChild("EyePieces")
			if v39 then
				v39 = v39:FindFirstChild("w7_inner_hollow")
			end
			local v40
			if v39 and v39:IsA("MeshPart") then
				v40 = v39:Clone()
				local v41 = v39.Size
				local v42 = v39.Size.X
				local v43 = v39.Size.Y
				local v44 = v39.Size.Z
				v40.Size = v41 * (v14 / math.max(v42, v43, v44, 0.01))
				v40.Anchored = true
				v40.CanCollide = false
				v40.CanQuery = false
				v40.CanTouch = false
				v40.CastShadow = false
				v40.Massless = true
				v40.Parent = v_u_2.folder()
				p_u_8.pin(p_u_9, v38, v40, CFrame.identity)
			else
				v40 = p_u_8.bar(Vector3.new(0.22, 0.78, 0.035) * v14, v_u_5, 0, v_u_7)
				p_u_8.pin(p_u_9, v38, v40, CFrame.new(v14 * 0.02, v14 * -0.08, 0))
				p_u_8.pin(p_u_9, v38, p_u_8.bar(Vector3.new(0.06, 0.78, 0.045) * v14, v_u_6, 0, v_u_7), CFrame.new(v14 * 0.15, v14 * -0.08, 0))
				p_u_8.pin(p_u_9, v38, p_u_8.bar(Vector3.new(0.025, 0.7, 0.05) * v14, v11), CFrame.new(0, v14 * -0.08, 0))
				p_u_8.pin(p_u_9, v38, p_u_8.bar(Vector3.new(0.07, 0.2, 0.07) * v14, v_u_6, 0, v_u_7), CFrame.new(0, v14 * 0.4, 0))
				p_u_8.pin(p_u_9, v38, p_u_8.bar(Vector3.new(0.2, 0.04, 0.08) * v14, v11), CFrame.new(0, v14 * 0.3, 0))
			end
			local v45 = Instance.new("Attachment")
			local v46 = v14 * 0.35
			v45.Position = Vector3.new(0, v46, 0)
			v45.Parent = v40
			local v47 = Instance.new("Attachment")
			local v48 = -v14 * 0.5
			v47.Position = Vector3.new(0, v48, 0)
			v47.Parent = v40
			local v_u_49 = Instance.new("Trail")
			v_u_49.Attachment0 = v45
			v_u_49.Attachment1 = v47
			v_u_49.Color = ColorSequence.new(v_u_5, v_u_6)
			v_u_49.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(0.6, 0.55), NumberSequenceKeypoint.new(1, 1) })
			v_u_49.Lifetime = 0.35
			v_u_49.LightEmission = 0
			v_u_49.LightInfluence = 0
			v_u_49.Enabled = false
			v_u_49.Parent = v40
			local v_u_50 = v_u_15
			local v51 = nil
			for _, v52 in { "RightHand", "Right Arm" } do
				local v53 = p_u_9.character:FindFirstChild(v52)
				if not (v53 and v53:IsA("BasePart")) then
					continue
				end
				v51 = v53
			end
			local v_u_54 = Instance.new("Attachment")
			if v51 then
				local v55 = -v51.Size.Y / 2
				v_u_54.Position = Vector3.new(0, v55, 0)
				v_u_54.Parent = v51
			else
				v_u_54.Parent = p_u_9.root
			end
			p_u_8.own(p_u_9, v_u_54)
			local v56 = Instance.new("Attachment")
			local v57 = v14 * 0.46
			v56.Position = Vector3.new(0, v57, 0)
			v56.Parent = v40
			local v_u_58 = Instance.new("Beam")
			v_u_58.Attachment0 = v_u_54
			v_u_58.Attachment1 = v56
			v_u_58.Texture = v_u_4.InnerChain
			v_u_58.TextureMode = Enum.TextureMode.Wrap
			v_u_58.TextureLength = v_u_13 * 0.6
			v_u_58.Color = ColorSequence.new(v_u_5)
			v_u_58.LightEmission = 0
			v_u_58.LightInfluence = 0
			v_u_58.FaceCamera = true
			v_u_58.Segments = 8
			v_u_58.CurveSize0 = v_u_13 * -0.6
			v_u_58.CurveSize1 = v_u_13 * 0.4
			v_u_58.Width0 = v_u_13 * 0.28
			v_u_58.Width1 = v_u_13 * 0.28
			v_u_58.Parent = v_u_54
			local v59 = p_u_9.stops
			table.insert(v59, function()
				-- upvalues: (copy) v_u_58, (copy) v_u_54
				v_u_58:Destroy()
				v_u_54:Destroy()
			end)
			local v60 = p_u_8.bar
			local v61 = v_u_13 * 2.4
			local v62 = v_u_13 * 2.4
			local v63 = v60(Vector3.new(v61, 0.2, v62), v_u_5, 1)
			p_u_8.add(p_u_9, v63, function(p64)
				-- upvalues: (ref) p_u_8, (copy) p_u_9
				return CFrame.new(p_u_8.feetAt(p_u_9, p64, 0.2))
			end)
			local v_u_65 = Instance.new("ParticleEmitter")
			v_u_65.Texture = v_u_4.InnerFlame
			v_u_65.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_65.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_65.Color = ColorSequence.new(v_u_5)
			v_u_65.LightEmission = 0
			v_u_65.LightInfluence = 0
			v_u_65.Lifetime = NumberRange.new(0.6, 0.85)
			v_u_65.Size = NumberSequence.new(v_u_13 * 0.7 * p_u_9.fx, v_u_13 * 1 * p_u_9.fx)
			v_u_65.Speed = NumberRange.new(v_u_13 * 2.5, v_u_13 * 4)
			v_u_65.EmissionDirection = Enum.NormalId.Top
			v_u_65.SpreadAngle = Vector2.new(12, 12)
			v_u_65.Rotation = NumberRange.new(-12, 12)
			v_u_65.Shape = Enum.ParticleEmitterShape.Box
			v_u_65.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_65:SetAttribute("BaseRate", 7 * p_u_9.fx)
			v_u_65.Rate = 7 * p_u_9.fx * v_u_3.formRate()
			v_u_65.Parent = v63
			p_u_8.own(p_u_9, v63)
			local v66 = p_u_9.stops
			table.insert(v66, function()
				-- upvalues: (copy) v_u_65
				v_u_65.Enabled = false
			end)
			local v67 = p_u_9.ticks
			local function v70(p68, p69)
				-- upvalues: (ref) v_u_16, (ref) v_u_50, (copy) p_u_9, (copy) v_u_49, (ref) p_u_8, (copy) v_u_65, (ref) v_u_3, (ref) v_u_2, (ref) v_u_6, (ref) v_u_4
				if v_u_16 <= p69 then
					v_u_16 = p69 + 6
					v_u_50 = p69
					p_u_9.pulse = 1
					v_u_49.Enabled = true
					if (p68.Position - p_u_8.camPos()).Magnitude < 150 then
						v_u_65:Emit(v_u_3.level() <= 1 and 3 or 10)
						v_u_2.ring(p_u_8.feetAt(p_u_9, p68, 0.15), v_u_6, 6 * p_u_9.fx, 0.55, v_u_4.Ring)
						return
					end
				elseif v_u_50 >= 0 and p69 - v_u_50 > 1.25 then
					v_u_49.Enabled = false
				end
			end
			table.insert(v67, v70)
			local v71 = p_u_9.ticks
			table.insert(v71, function(_, _, p72)
				-- upvalues: (copy) p_u_9
				local v73 = p_u_9
				local v74 = p_u_9.pulse - p72 * 1.2
				v73.pulse = math.max(v74, 0)
			end)
			p_u_8.particles(p_u_9, "AuraMode", v11, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Sparks" }
			})
		end
	}
end