return {
	["step"] = function(p1, p2, p3, p4, p5, p6) -- name: step
		for v7, v8 in p1 do
			local v9 = 0
			local v10 = 0
			if v8.pullX and (v8.pullZ and v8.pullSpeed) then
				local v11 = v8.pullX - v8.x
				local v12 = v8.pullZ - v8.z
				local v13 = v11 * v11 + v12 * v12
				local v14 = math.sqrt(v13)
				if v14 > 0.5 then
					local v15 = v8.pullSpeed * p5
					local v16 = v14 - 0.5
					local v17 = math.min(v15, v16)
					v9 = v9 + v11 / v14 * v17
					v10 = v10 + v12 / v14 * v17
				end
			elseif p4 and not v8.frozen then
				local v18 = p2 - v8.x
				local v19 = p3 - v8.z
				local v20 = v18 * v18 + v19 * v19
				local v21 = math.sqrt(v20)
				if v21 > 0.001 then
					local v22 = v18 / v21
					local v23 = v19 / v21
					v8.fx = v22
					v8.fz = v23
				end
				local v24 = v8.reach * 0.75
				if v24 < v21 then
					local v25 = v8.speed * p5
					local v26 = v21 - v24
					local v27 = math.min(v25, v26)
					v9 = v9 + v18 / v21 * v27
					v10 = v10 + v19 / v21 * v27
				end
			end
			local v28 = p4 and not v8.frozen
			if v28 then
				v28 = (p2 - v8.x) ^ 2 + (p3 - v8.z) ^ 2 <= v8.reach * v8.reach
			end
			v8.inReach = v28
			for v29, v30 in p1 do
				if v29 == v7 then
					continue
				end
				local v31 = v8.x - v30.x
				local v32 = v8.z - v30.z
				local v33 = (v8.radius + v30.radius) * 0.9
				local v34 = v31 * v31 + v32 * v32
				if v34 >= v33 * v33 then
					continue
				end
				local v35 = math.sqrt(v34)
				if v35 < 0.001 then
					v31 = math.cos(v7)
					v32 = math.sin(v7)
					v35 = 1
				end
				local v36 = (v33 - v35) * 0.5
				v9 = v9 + v31 / v35 * v36
				v10 = v10 + v32 / v35 * v36
			end
			local v37 = v9 + v8.kx * p5
			local v38 = v10 + v8.kz * p5
			local v39 = 1 - p5 * 6
			local v40 = math.max(0, v39)
			v8.kx = v8.kx * v40
			v8.kz = v8.kz * v40
			local v41 = v8.x + v37
			local v42 = p6.minX + v8.radius
			local v43 = p6.maxX - v8.radius
			v8.x = math.clamp(v41, v42, v43)
			local v44 = v8.z + v38
			local v45 = p6.minZ + v8.radius
			local v46 = p6.maxZ - v8.radius
			v8.z = math.clamp(v44, v45, v46)
		end
	end
}