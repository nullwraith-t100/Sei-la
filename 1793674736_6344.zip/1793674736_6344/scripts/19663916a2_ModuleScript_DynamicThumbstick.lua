local v_u_1 = {
	0.10999999999999999,
	0.30000000000000004,
	0.4,
	0.5,
	0.6,
	0.7,
	0.75
}
local v_u_2 = {
	0.55,
	0.65,
	0.7,
	0.75,
	0.8,
	0.85,
	0.875
}
local v_u_3 = #v_u_1
local v_u_4 = Vector2.new(-1, -1)
local v_u_5 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
local v6 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_7 = v6.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_8 = v6.getUserFlag("UserAllowAbilityControlsBonus")
local v_u_9 = v6.getUserFlag("UserDoubleJumpButtonFix")
local v_u_10 = v6.getUserFlag("UserPlayerScriptsResetDTTouchOnCreate")
local v11 = game:GetService("Players")
local v_u_12 = game:GetService("GuiService")
local v_u_13 = game:GetService("RunService")
local v_u_14 = game:GetService("TweenService")
local v_u_15 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("TransformerContext"):WaitForChild("ThumbstickAction")
local v_u_16 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface"))
local v_u_17
if v_u_7 then
	v_u_17 = v_u_16.get(v11.LocalPlayer)
else
	v_u_17 = nil
end
local v_u_18 = v11.LocalPlayer
if not v_u_18 then
	v11:GetPropertyChangedSignal("LocalPlayer"):Wait()
	v_u_18 = v11.LocalPlayer
end
local v_u_19 = require(script.Parent:WaitForChild("ActionController"))
local v_u_20 = setmetatable({}, v_u_19)
v_u_20.__index = v_u_20
function v_u_20.new(p21) -- name: new
	-- upvalues: (copy) v_u_19, (copy) v_u_20
	local v22 = v_u_19.new()
	local v23 = v_u_20
	local v24 = setmetatable(v22, v23)
	v24.data = p21
	v24.enabled = false
	v24.isTouchActive = false
	v24.moveTouchFirstChanged = false
	v24.moveTouchStartPosition = nil
	v24.startImage = nil
	v24.endImage = nil
	v24.endImageStroke = nil
	v24.endImageCenter = nil
	v24.middleImages = {}
	v24.startImageFadeTween = nil
	v24.endImageFadeTween = nil
	v24.endImageCenterFadeTween = nil
	v24.middleImageFadeTweens = {}
	v24.isFirstTouch = true
	v24.thumbstickFrame = nil
	v24.onRenderSteppedConn = nil
	v24.fadeInAndOutBalance = 0.5
	v24.fadeInAndOutHalfDuration = 0.3
	v24.hasFadedBackgroundInPortrait = false
	v24.hasFadedBackgroundInLandscape = false
	v24.tweenInAlphaStart = nil
	v24.tweenOutAlphaStart = nil
	v24.newStyle = false
	return v24
end
function v_u_20.GetIsJumping(p25) -- name: GetIsJumping
	local v26 = p25.isJumping
	p25.isJumping = false
	return v26
end
local function v_u_30(p27) -- name: setupThumbstickInput
	-- upvalues: (copy) v_u_15
	for _, v28 in v_u_15:GetChildren() do
		if v28.Name ~= "DynamicTouchBinding" and v28.Name ~= "ClassicTouchBinding" then
			continue
		end
		v28:Destroy()
	end
	local v29 = Instance.new("InputBinding")
	v29.Name = "DynamicTouchBinding"
	v29.KeyCode = Enum.KeyCode.TouchPosition
	v29.UIModifier = p27.thumbstickButton
	v29.Parent = v_u_15
end
function v_u_20.Enable(p_u_31, p32, p_u_33) -- name: Enable
	-- upvalues: (copy) v_u_19, (copy) v_u_7, (copy) v_u_17, (copy) v_u_10, (copy) v_u_30, (copy) v_u_15
	if p32 == nil then
		return false
	end
	local v34 = p32 and true or false
	if p_u_31.enabled == v34 then
		return true
	end
	v_u_19.Enable(p_u_31, v34)
	if v34 then
		if not p_u_31.thumbstickFrame then
			p_u_31:Create(p_u_33)
			if v_u_7 and not p_u_31.avatarAbilitiesEnabledChangedConn then
				p_u_31.avatarAbilitiesEnabledChangedConn = v_u_17:GetEnabledChangedSignal():Connect(function()
					-- upvalues: (copy) p_u_31, (copy) p_u_33, (ref) v_u_10, (ref) v_u_30, (ref) v_u_15
					if p_u_31.enabled then
						p_u_31:Create(p_u_33)
						if v_u_10 then
							local v35 = p_u_31
							v_u_30(v35)
							v35.thumbstickStateChangedConn = v_u_15.StateChanged:Connect(v35.onStateChanged)
							v_u_15.Enabled = true
						else
							p_u_31.thumbstickStateChangedConn = v_u_15.StateChanged:Connect(p_u_31.onStateChanged)
							v_u_15.Enabled = true
						end
						p_u_31.thumbstickFrame.Visible = true
					end
				end)
			end
		end
		if v_u_10 then
			v_u_30(p_u_31)
			p_u_31.thumbstickStateChangedConn = v_u_15.StateChanged:Connect(p_u_31.onStateChanged)
			v_u_15.Enabled = true
		else
			p_u_31.thumbstickStateChangedConn = v_u_15.StateChanged:Connect(p_u_31.onStateChanged)
			v_u_15.Enabled = true
		end
	else
		if v_u_10 then
			v_u_15.Enabled = false
			if p_u_31.thumbstickStateChangedConn then
				p_u_31.thumbstickStateChangedConn:Disconnect()
				p_u_31.thumbstickStateChangedConn = nil
			end
		else
			v_u_15.Enabled = false
			if p_u_31.thumbstickStateChangedConn then
				p_u_31.thumbstickStateChangedConn:Disconnect()
				p_u_31.thumbstickStateChangedConn = nil
			end
		end
		p_u_31:OnInputEnded()
	end
	p_u_31.enabled = v34
	p_u_31.thumbstickFrame.Visible = v34
	return nil
end
function v_u_20.OnInputEnded(p36) -- name: OnInputEnded
	p36.isTouchActive = false
	local v37 = p36.data.actions.MoveAction:FindFirstChild("DynamicThumbstickScriptableBinding")
	if v37 then
		v37:Fire(Vector2.zero)
	end
	p36:FadeThumbstick(false)
end
function v_u_20.FadeThumbstick(p38, p39) -- name: FadeThumbstick
	-- upvalues: (copy) v_u_7, (copy) v_u_14, (copy) v_u_5, (copy) v_u_2, (copy) v_u_1
	if p39 or not p38.isTouchActive then
		if p38.isFirstTouch then
			return
		else
			if p38.startImageFadeTween then
				p38.startImageFadeTween:Cancel()
			end
			if p38.endImageFadeTween then
				p38.endImageFadeTween:Cancel()
			end
			if v_u_7 and p38.endImageCenterFadeTween then
				p38.endImageCenterFadeTween:Cancel()
			end
			for v40 = 1, #p38.middleImages do
				if not p38.middleImageFadeTweens[v40] then
					continue
				end
				p38.middleImageFadeTweens[v40]:Cancel()
			end
			if p39 then
				if v_u_7 and p38.newStyle then
					p38.startImageFadeTween = v_u_14:Create(p38.startImage, v_u_5, {
						["BackgroundTransparency"] = 0.4
					})
					p38.startImageFadeTween:Play()
					p38.endImageFadeTween = v_u_14:Create(p38.endImageStroke, v_u_5, {
						["Transparency"] = 0
					})
					p38.endImageFadeTween:Play()
					p38.endImageCenterFadeTween = v_u_14:Create(p38.endImageCenter, v_u_5, {
						["BackgroundTransparency"] = 0
					})
					p38.endImageCenterFadeTween:Play()
				else
					p38.startImageFadeTween = v_u_14:Create(p38.startImage, v_u_5, {
						["ImageTransparency"] = 0
					})
					p38.startImageFadeTween:Play()
					p38.endImageFadeTween = v_u_14:Create(p38.endImage, v_u_5, {
						["ImageTransparency"] = 0.2
					})
					p38.endImageFadeTween:Play()
				end
				for v41 = 1, #p38.middleImages do
					if v_u_7 and p38.newStyle then
						p38.middleImageFadeTweens[v41] = v_u_14:Create(p38.middleImages[v41], v_u_5, {
							["BackgroundTransparency"] = v_u_2[v41]
						})
					else
						p38.middleImageFadeTweens[v41] = v_u_14:Create(p38.middleImages[v41], v_u_5, {
							["ImageTransparency"] = v_u_1[v41]
						})
					end
					p38.middleImageFadeTweens[v41]:Play()
				end
			else
				if v_u_7 and p38.newStyle then
					p38.startImageFadeTween = v_u_14:Create(p38.startImage, v_u_5, {
						["BackgroundTransparency"] = 1
					})
					p38.startImageFadeTween:Play()
					p38.endImageFadeTween = v_u_14:Create(p38.endImageStroke, v_u_5, {
						["Transparency"] = 1
					})
					p38.endImageFadeTween:Play()
					p38.endImageCenterFadeTween = v_u_14:Create(p38.endImageCenter, v_u_5, {
						["BackgroundTransparency"] = 1
					})
					p38.endImageCenterFadeTween:Play()
				else
					p38.startImageFadeTween = v_u_14:Create(p38.startImage, v_u_5, {
						["ImageTransparency"] = 1
					})
					p38.startImageFadeTween:Play()
					p38.endImageFadeTween = v_u_14:Create(p38.endImage, v_u_5, {
						["ImageTransparency"] = 1
					})
					p38.endImageFadeTween:Play()
				end
				for v42 = 1, #p38.middleImages do
					if v_u_7 and p38.newStyle then
						p38.middleImageFadeTweens[v42] = v_u_14:Create(p38.middleImages[v42], v_u_5, {
							["BackgroundTransparency"] = 1
						})
					else
						p38.middleImageFadeTweens[v42] = v_u_14:Create(p38.middleImages[v42], v_u_5, {
							["ImageTransparency"] = 1
						})
					end
					p38.middleImageFadeTweens[v42]:Play()
				end
			end
		end
	else
		return
	end
end
function v_u_20.FadeThumbstickFrame(p43, p44, p45) -- name: FadeThumbstickFrame
	p43.fadeInAndOutHalfDuration = p44 * 0.5
	p43.fadeInAndOutBalance = p45
	p43.tweenInAlphaStart = tick()
end
function v_u_20.DoFadeInBackground(p46) -- name: DoFadeInBackground
	-- upvalues: (ref) v_u_18
	local v47 = v_u_18:FindFirstChildOfClass("PlayerGui")
	local v48 = false
	if v47 then
		if v47.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft or v47.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight then
			v48 = p46.hasFadedBackgroundInLandscape
			p46.hasFadedBackgroundInLandscape = true
		elseif v47.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait then
			v48 = p46.hasFadedBackgroundInPortrait
			p46.hasFadedBackgroundInPortrait = true
		end
	end
	if not v48 then
		p46.fadeInAndOutHalfDuration = 0.3
		p46.fadeInAndOutBalance = 0.5
		p46.tweenInAlphaStart = tick()
	end
end
function v_u_20.DoMove(p49, p50) -- name: DoMove
	local v51
	if p50.Magnitude < p49.radiusOfDeadZone then
		v51 = Vector2.new()
	else
		local v52 = p50.Unit
		local v53 = (p49.radiusOfMaxSpeed - p50.Magnitude) / p49.radiusOfMaxSpeed
		v51 = v52 * (1 - math.max(0, v53))
	end
	local v54 = Vector2.new(v51.X, -v51.Y)
	local v55 = p49.data.actions.MoveAction:FindFirstChild("DynamicThumbstickScriptableBinding")
	if v55 then
		v55:Fire(v54)
	end
end
function v_u_20.LayoutMiddleImages(p56, p57, p58) -- name: LayoutMiddleImages
	-- upvalues: (copy) v_u_3
	local v59 = p56.thumbstickSize / 2 + p56.middleSize
	local v60 = p58 - p57
	local v61 = v60.Magnitude - p56.thumbstickRingSize / 2 - p56.middleSize
	local v62 = v60.Unit
	local v63 = p56.middleSpacing * v_u_3
	local v64 = p56.middleSpacing
	if v63 < v61 then
		v64 = v61 / v_u_3
	end
	for v65 = 1, v_u_3 do
		local v66 = p56.middleImages[v65]
		local v67 = v59 + v64 * (v65 - 2)
		local v68 = v59 + v64 * (v65 - 1)
		if v67 < v61 then
			local v69 = p58 - v62 * v68
			local v70 = 1 - (v68 - v61) / v64
			local v71 = math.clamp(v70, 0, 1)
			v66.Visible = true
			v66.Position = UDim2.new(0, v69.X, 0, v69.Y)
			v66.Size = UDim2.new(0, p56.middleSize * v71, 0, p56.middleSize * v71)
		else
			v66.Visible = false
		end
	end
end
function v_u_20.MoveStick(p72, p73) -- name: MoveStick
	local v74 = Vector2.new(p72.moveTouchStartPosition.X, p72.moveTouchStartPosition.Y) - p72.thumbstickFrame.AbsolutePosition
	local v75 = Vector2.new(p73.X, p73.Y) - p72.thumbstickFrame.AbsolutePosition
	p72.endImage.Position = UDim2.new(0, v75.X, 0, v75.Y)
	p72:LayoutMiddleImages(v74, v75)
end
function v_u_20.Create(p_u_76, p_u_77) -- name: Create
	-- upvalues: (copy) v_u_10, (copy) v_u_15, (copy) v_u_7, (copy) v_u_17, (copy) v_u_9, (copy) v_u_3, (copy) v_u_2, (copy) v_u_1, (copy) v_u_16, (copy) v_u_8, (copy) v_u_13, (copy) v_u_4, (copy) v_u_12, (copy) v_u_14, (ref) v_u_18
	if p_u_76.thumbstickFrame then
		if v_u_10 then
			v_u_15.Enabled = false
			if p_u_76.thumbstickStateChangedConn then
				p_u_76.thumbstickStateChangedConn:Disconnect()
				p_u_76.thumbstickStateChangedConn = nil
			end
		else
			v_u_15.Enabled = false
			if p_u_76.thumbstickStateChangedConn then
				p_u_76.thumbstickStateChangedConn:Disconnect()
				p_u_76.thumbstickStateChangedConn = nil
			end
		end
		p_u_76.thumbstickFrame:Destroy()
		p_u_76.thumbstickFrame = nil
		if p_u_76.onRenderSteppedConn then
			p_u_76.onRenderSteppedConn:Disconnect()
			p_u_76.onRenderSteppedConn = nil
		end
		if p_u_76.absoluteSizeChangedConn then
			p_u_76.absoluteSizeChangedConn:Disconnect()
			p_u_76.absoluteSizeChangedConn = nil
		end
		if not v_u_7 and p_u_76.avatarAbilitiesEnabledChangedConn then
			p_u_76.avatarAbilitiesEnabledChangedConn:Disconnect()
			p_u_76.avatarAbilitiesEnabledChangedConn = nil
		end
		if v_u_7 then
			if p_u_76.cameraChangedConn then
				p_u_76.cameraChangedConn:Disconnect()
				p_u_76.cameraChangedConn = nil
			end
			if p_u_76.currentCameraChangedConn then
				p_u_76.currentCameraChangedConn:Disconnect()
				p_u_76.currentCameraChangedConn = nil
			end
			if p_u_76.menuOpenedConnection then
				p_u_76.menuOpenedConnection:Disconnect()
				p_u_76.menuOpenedConnection = nil
			end
			if p_u_76.playerGuiChangedConn then
				p_u_76.playerGuiChangedConn:Disconnect()
				p_u_76.playerGuiChangedConn = nil
			end
		end
	end
	local function v_u_79(p78) -- name: layoutThumbstickFrame
		-- upvalues: (copy) p_u_76
		if p78 then
			p_u_76.thumbstickFrame.Size = UDim2.new(1, 100, 0.4, 100)
			p_u_76.thumbstickFrame.Position = UDim2.new(0, -100, 0.6, 0)
		else
			p_u_76.thumbstickFrame.Size = UDim2.new(0.4, 100, 0.6666666666666666, 100)
			p_u_76.thumbstickFrame.Position = UDim2.new(0, -100, 0.3333333333333333, 0)
		end
	end
	local v80 = v_u_7
	if v80 then
		v80 = v_u_17:isEnabled()
	end
	p_u_76.newStyle = v80
	p_u_76.thumbstickFrame = Instance.new("Frame")
	p_u_76.thumbstickFrame.BorderSizePixel = 0
	p_u_76.thumbstickFrame.Name = "DynamicThumbstickFrame"
	p_u_76.thumbstickFrame.Visible = false
	p_u_76.thumbstickFrame.BackgroundTransparency = 1
	p_u_76.thumbstickFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
	p_u_76.thumbstickFrame.Active = false
	p_u_76.thumbstickFrame.Size = UDim2.new(0.4, 100, 0.6666666666666666, 100)
	p_u_76.thumbstickFrame.Position = UDim2.new(0, -100, 0.3333333333333333, 0)
	p_u_76.thumbstickButton = Instance.new("ImageButton")
	p_u_76.thumbstickButton.Name = "DynamicThumbstickUIModifier"
	p_u_76.thumbstickButton.BackgroundTransparency = 1
	p_u_76.thumbstickButton.ImageTransparency = 1
	p_u_76.thumbstickButton.AutoButtonColor = false
	p_u_76.thumbstickButton.Size = UDim2.new(1, 0, 1, 0)
	p_u_76.thumbstickButton.ZIndex = p_u_76.thumbstickFrame.ZIndex
	p_u_76.thumbstickButton.Visible = true
	p_u_76.thumbstickButton.Active = false
	p_u_76.thumbstickButton.Parent = p_u_76.thumbstickFrame
	if not v_u_10 then
		local v81
		if v_u_9 then
			v81 = v_u_15:FindFirstChild("DynamicTouchBinding")
		else
			v81 = nil
		end
		if not v81 then
			v81 = Instance.new("InputBinding")
			v81.Name = "DynamicTouchBinding"
			v81.KeyCode = Enum.KeyCode.TouchPosition
			v81.Parent = v_u_15
		end
		v81.UIModifier = p_u_76.thumbstickButton
	end
	if v_u_7 and p_u_76.newStyle then
		p_u_76.startImage = Instance.new("Frame")
		p_u_76.startImage.Name = "ThumbstickStart"
		p_u_76.startImage.BackgroundColor3 = Color3.fromRGB(18, 18, 21)
		p_u_76.startImage.BackgroundTransparency = 0.4
		p_u_76.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
		p_u_76.startImage.ZIndex = 10
		p_u_76.startImage.Parent = p_u_76.thumbstickFrame
		local v82 = Instance.new("UICorner")
		v82.CornerRadius = UDim.new(0.5, 0)
		v82.Parent = p_u_76.startImage
		p_u_76.endImage = Instance.new("Frame")
		p_u_76.endImage.Name = "ThumbstickEnd"
		p_u_76.endImage.BackgroundTransparency = 1
		p_u_76.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
		p_u_76.endImage.ZIndex = 10
		p_u_76.endImage.Parent = p_u_76.thumbstickFrame
		local v83 = Instance.new("UICorner")
		v83.CornerRadius = UDim.new(0.5, 0)
		v83.Parent = p_u_76.endImage
		p_u_76.endImageStroke = Instance.new("UIStroke")
		p_u_76.endImageStroke.Thickness = v_u_9 and 1.5 or 2
		p_u_76.endImageStroke.Color = Color3.fromRGB(213, 215, 221)
		p_u_76.endImageStroke.Parent = p_u_76.endImage
		p_u_76.endImageCenter = Instance.new("Frame")
		p_u_76.endImageCenter.Name = "ThumbstickEndCenter"
		p_u_76.endImageCenter.BackgroundTransparency = 0
		p_u_76.endImageCenter.BackgroundColor3 = Color3.fromRGB(213, 215, 221)
		p_u_76.endImageCenter.AnchorPoint = Vector2.new(0.5, 0.5)
		p_u_76.endImageCenter.Size = UDim2.new(0.74, 0, 0.74, 0)
		p_u_76.endImageCenter.Position = UDim2.new(0.5, 0, 0.5, 0)
		p_u_76.endImageCenter.ZIndex = 10
		p_u_76.endImageCenter.Parent = p_u_76.endImage
		local v84 = Instance.new("UICorner")
		v84.CornerRadius = UDim.new(0.5, 0)
		v84.Parent = p_u_76.endImageCenter
		for v85 = 1, v_u_3 do
			p_u_76.middleImages[v85] = Instance.new("Frame")
			p_u_76.middleImages[v85].Name = "ThumbstickMiddle"
			p_u_76.middleImages[v85].Visible = false
			p_u_76.middleImages[v85].BackgroundTransparency = v_u_2[v85]
			p_u_76.middleImages[v85].BackgroundColor3 = Color3.fromRGB(255, 255, 255)
			p_u_76.middleImages[v85].AnchorPoint = Vector2.new(0.5, 0.5)
			p_u_76.middleImages[v85].ZIndex = 9
			p_u_76.middleImages[v85].Parent = p_u_76.thumbstickFrame
			local v86 = Instance.new("UICorner")
			v86.CornerRadius = UDim.new(0.5, 0)
			v86.Parent = p_u_76.middleImages[v85]
		end
	else
		p_u_76.startImage = Instance.new("ImageLabel")
		p_u_76.startImage.Name = "ThumbstickStart"
		p_u_76.startImage.Visible = true
		p_u_76.startImage.BackgroundTransparency = 1
		p_u_76.startImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		p_u_76.startImage.ImageRectOffset = Vector2.new(1, 1)
		p_u_76.startImage.ImageRectSize = Vector2.new(144, 144)
		p_u_76.startImage.ImageColor3 = Color3.new(0, 0, 0)
		p_u_76.startImage.AnchorPoint = Vector2.new(0.5, 0.5)
		p_u_76.startImage.ZIndex = 10
		p_u_76.startImage.Parent = p_u_76.thumbstickFrame
		p_u_76.endImage = Instance.new("ImageLabel")
		p_u_76.endImage.Name = "ThumbstickEnd"
		p_u_76.endImage.Visible = true
		p_u_76.endImage.BackgroundTransparency = 1
		p_u_76.endImage.Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
		p_u_76.endImage.ImageRectOffset = Vector2.new(1, 1)
		p_u_76.endImage.ImageRectSize = Vector2.new(144, 144)
		p_u_76.endImage.AnchorPoint = Vector2.new(0.5, 0.5)
		p_u_76.endImage.ZIndex = 10
		p_u_76.endImage.Parent = p_u_76.thumbstickFrame
		for v87 = 1, v_u_3 do
			p_u_76.middleImages[v87] = Instance.new("ImageLabel")
			p_u_76.middleImages[v87].Name = "ThumbstickMiddle"
			p_u_76.middleImages[v87].Visible = false
			p_u_76.middleImages[v87].BackgroundTransparency = 1
			p_u_76.middleImages[v87].Image = "rbxasset://textures/ui/Input/TouchControlsSheetV2.png"
			p_u_76.middleImages[v87].ImageRectOffset = Vector2.new(1, 1)
			p_u_76.middleImages[v87].ImageRectSize = Vector2.new(144, 144)
			p_u_76.middleImages[v87].ImageTransparency = v_u_1[v87]
			p_u_76.middleImages[v87].AnchorPoint = Vector2.new(0.5, 0.5)
			p_u_76.middleImages[v87].ZIndex = 9
			p_u_76.middleImages[v87].Parent = p_u_76.thumbstickFrame
		end
	end
	local function v96() -- name: ResizeThumbstick
		-- upvalues: (copy) p_u_77, (ref) v_u_7, (copy) p_u_76, (ref) v_u_16, (ref) v_u_8
		local v88 = p_u_77.AbsoluteSize
		local v89 = v88.X
		local v90 = v88.Y
		local v91 = math.min(v89, v90) > 500
		local v92 = v91 and 2 or 1
		local v93
		if v_u_7 then
			v93 = p_u_76.newStyle
		else
			v93 = v_u_16.isEnabled()
		end
		local v94 = v_u_8 and (v93 and v91) and 1.6216216216216217 or v92
		p_u_76.thumbstickSize = 45 * v94
		p_u_76.thumbstickRingSize = 20 * v94
		p_u_76.middleSize = 10 * v94
		p_u_76.middleSpacing = 14 * v94
		p_u_76.radiusOfDeadZone = 2 * v94
		p_u_76.radiusOfMaxSpeed = 20 * v94
		local v95 = 74 * v94
		if not v_u_7 or p_u_76.isFirstTouch then
			if v93 then
				p_u_76.startImage.Position = UDim2.new(0, v95 * 0.5 + 100 + (v91 and 100 or 64), 1, -v95 * 0.5 - 100 - (v91 and 112 or 64))
				p_u_76.startImage.Size = UDim2.new(0, v95, 0, v95)
			else
				p_u_76.startImage.Position = UDim2.new(0, p_u_76.thumbstickRingSize * 3.3 + 100, 1, -p_u_76.thumbstickRingSize * 2.8 - 100)
				p_u_76.startImage.Size = UDim2.new(0, v95, 0, v95)
			end
		end
		p_u_76.endImage.Position = p_u_76.startImage.Position
		if v_u_7 and p_u_76.newStyle then
			p_u_76.endImage.Size = UDim2.new(0, p_u_76.thumbstickSize * 0.6, 0, p_u_76.thumbstickSize * 0.6)
		else
			p_u_76.endImage.Size = UDim2.new(0, p_u_76.thumbstickSize * 0.8, 0, p_u_76.thumbstickSize * 0.8)
		end
	end
	v96()
	p_u_76.absoluteSizeChangedConn = p_u_77:GetPropertyChangedSignal("AbsoluteSize"):Connect(v96)
	if not v_u_7 then
		p_u_76.avatarAbilitiesEnabledChangedConn = v_u_16.GetEnabledChangedSignal():Connect(v96)
	end
	local function v101() -- name: onCurrentCameraChanged
		-- upvalues: (copy) p_u_76, (copy) v_u_79
		if p_u_76.cameraChangedConn then
			p_u_76.cameraChangedConn:Disconnect()
			p_u_76.cameraChangedConn = nil
		end
		local v_u_97 = workspace.CurrentCamera
		if v_u_97 then
			local function v99() -- name: onViewportSizeChanged
				-- upvalues: (copy) v_u_97, (ref) v_u_79
				local v98 = v_u_97.ViewportSize
				v_u_79(v98.X < v98.Y)
			end
			p_u_76.cameraChangedConn = v_u_97:GetPropertyChangedSignal("ViewportSize"):Connect(v99)
			local v100 = v_u_97.ViewportSize
			v_u_79(v100.X < v100.Y)
		end
	end
	p_u_76.currentCameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(v101)
	if workspace.CurrentCamera or v_u_7 then
		v101()
	end
	p_u_76.startImageFadeTween = nil
	p_u_76.endImageFadeTween = nil
	p_u_76.endImageCenterFadeTween = nil
	p_u_76.middleImageFadeTweens = {}
	if v_u_10 and p_u_76.isTouchActive then
		p_u_76:OnInputEnded()
	end
	p_u_76.moveTouchStartPosition = nil
	p_u_76.onRenderSteppedConn = v_u_13.RenderStepped:Connect(function()
		-- upvalues: (copy) p_u_76
		if p_u_76.tweenInAlphaStart == nil then
			if p_u_76.tweenOutAlphaStart ~= nil then
				local v102 = tick() - p_u_76.tweenOutAlphaStart
				local v103 = p_u_76.fadeInAndOutHalfDuration * 2 - p_u_76.fadeInAndOutHalfDuration * 2 * p_u_76.fadeInAndOutBalance
				local v104 = p_u_76.thumbstickFrame
				local v105 = v102 / v103
				v104.BackgroundTransparency = math.min(v105, 1) * 0.35 + 0.65
				if v103 < v102 then
					p_u_76.tweenOutAlphaStart = nil
				end
			end
		else
			local v106 = tick() - p_u_76.tweenInAlphaStart
			local v107 = p_u_76.fadeInAndOutHalfDuration * 2 * p_u_76.fadeInAndOutBalance
			local v108 = p_u_76.thumbstickFrame
			local v109 = v106 / v107
			v108.BackgroundTransparency = 1 - math.min(v109, 1) * 0.35
			if v107 < v106 then
				p_u_76.tweenOutAlphaStart = tick()
				p_u_76.tweenInAlphaStart = nil
				return
			end
		end
	end)
	function p_u_76.onStateChanged(p110)
		-- upvalues: (ref) v_u_4, (ref) v_u_12, (copy) p_u_76, (ref) v_u_14, (ref) v_u_7
		if p110 == v_u_4 then
			if p_u_76.isTouchActive then
				p_u_76:OnInputEnded()
			end
		else
			local v111 = v_u_12:GetInsetArea(Enum.ScreenInsets.None).Min
			local v112 = p110.X + v111.X
			local v113 = p110.Y + v111.Y
			local v114 = Vector3.new(v112, v113, 0)
			if not p_u_76.isTouchActive then
				p_u_76.isTouchActive = true
				if p_u_76.isFirstTouch then
					p_u_76.isFirstTouch = false
					local v115 = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0)
					v_u_14:Create(p_u_76.startImage, v115, {
						["Size"] = UDim2.new(0, 0, 0, 0)
					}):Play()
					if not (v_u_7 and p_u_76.newStyle) then
						v_u_14:Create(p_u_76.endImage, v115, {
							["Size"] = UDim2.new(0, p_u_76.thumbstickSize, 0, p_u_76.thumbstickSize),
							["ImageColor3"] = Color3.new(0, 0, 0)
						}):Play()
					end
				end
				p_u_76.moveTouchStartPosition = v114
				p_u_76.moveTouchFirstChanged = true
				p_u_76:DoFadeInBackground()
				return
			end
			if p_u_76.moveTouchFirstChanged then
				p_u_76.moveTouchFirstChanged = false
				local v116 = Vector2.new(p_u_76.moveTouchStartPosition.X - p_u_76.thumbstickFrame.AbsolutePosition.X, p_u_76.moveTouchStartPosition.Y - p_u_76.thumbstickFrame.AbsolutePosition.Y)
				p_u_76.startImage.Visible = true
				p_u_76.startImage.Position = UDim2.new(0, v116.X, 0, v116.Y)
				p_u_76.endImage.Visible = true
				p_u_76.endImage.Position = p_u_76.startImage.Position
				p_u_76:FadeThumbstick(true)
				p_u_76:MoveStick(p_u_76.moveTouchStartPosition)
			end
			local v117 = Vector2.new(v114.X - p_u_76.moveTouchStartPosition.X, v114.Y - p_u_76.moveTouchStartPosition.Y)
			if v117.Magnitude > 0 then
				p_u_76:DoMove(v117)
				p_u_76:MoveStick(v114)
				return
			end
		end
	end
	p_u_76.menuOpenedConnection = v_u_12.MenuOpened:Connect(function()
		-- upvalues: (copy) p_u_76
		if p_u_76.isTouchActive then
			p_u_76:OnInputEnded()
		end
	end)
	local v_u_118 = v_u_18:FindFirstChildOfClass("PlayerGui")
	while not v_u_118 do
		v_u_18.ChildAdded:wait()
		v_u_118 = v_u_18:FindFirstChildOfClass("PlayerGui")
	end
	local v_u_119 = v_u_118.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeLeft and true or v_u_118.CurrentScreenOrientation == Enum.ScreenOrientation.LandscapeRight
	p_u_76.playerGuiChangedConn = v_u_118:GetPropertyChangedSignal("CurrentScreenOrientation"):Connect(function()
		-- upvalues: (copy) v_u_119, (ref) v_u_118, (copy) p_u_76
		if v_u_119 and v_u_118.CurrentScreenOrientation == Enum.ScreenOrientation.Portrait or not v_u_119 and v_u_118.CurrentScreenOrientation ~= Enum.ScreenOrientation.Portrait then
			p_u_76.playerGuiChangedConn:Disconnect()
			p_u_76.fadeInAndOutHalfDuration = 2.5
			p_u_76.fadeInAndOutBalance = 0.05
			p_u_76.tweenInAlphaStart = tick()
			if v_u_119 then
				p_u_76.hasFadedBackgroundInPortrait = true
				return
			end
			p_u_76.hasFadedBackgroundInLandscape = true
		end
	end)
	p_u_76.thumbstickFrame.Parent = p_u_77
	if game:IsLoaded() then
		p_u_76.fadeInAndOutHalfDuration = 2.5
		p_u_76.fadeInAndOutBalance = 0.05
		p_u_76.tweenInAlphaStart = tick()
	else
		coroutine.wrap(function()
			-- upvalues: (copy) p_u_76
			game.Loaded:Wait()
			p_u_76.fadeInAndOutHalfDuration = 2.5
			p_u_76.fadeInAndOutBalance = 0.05
			p_u_76.tweenInAlphaStart = tick()
		end)()
	end
end
return v_u_20