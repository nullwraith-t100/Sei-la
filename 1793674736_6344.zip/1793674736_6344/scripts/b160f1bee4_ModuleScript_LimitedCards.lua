local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v_u_2.Shared.Config.Market)
local v_u_6 = require(v_u_2.Shared.Config.Products)
local v_u_7 = require(v_u_2.Shared.Logic.Format)
local v_u_8 = require(v_u_2.Shared.Logic.MarketRules)
local v_u_9 = require(script.Parent.Store)
local v_u_10 = {}
local v_u_11 = v1.LocalPlayer
local v_u_12 = Instance.new("BindableEvent")
v_u_10.changed = v_u_12.Event
local function v_u_13(_) end
local v_u_14 = nil
local function v_u_20() -- name: devIds
	-- upvalues: (ref) v_u_14, (copy) v_u_3, (copy) v_u_5
	local v15 = v_u_14
	if v_u_3:IsStudio() and (v15 and v15:GetAttribute("DevIds") == true) then
		for v16, v17 in v_u_5.limited do
			v17.id = 900000000 + v16
		end
		for v18, v19 in v_u_5.gifts do
			v19.id = 910000000 + v18
			v_u_5.GIFT_IDS[v19.item] = v19.id
		end
	end
end
function v_u_10.active(p21) -- name: active
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_6
	local v22 = v_u_5.limitedByPass[p21]
	if v_u_5.SELL_LIMITED and (v22 and (v22.id ~= 0 and #v_u_8.takes(p21, v_u_5.LIMITED, v_u_6.BUNDLES, v_u_5.LIMITED_BUNDLES) ~= 0)) then
		return v22
	else
		return nil
	end
end
function v_u_10.known() -- name: known
	-- upvalues: (ref) v_u_14
	local v23 = v_u_14
	local v24
	if v23 == nil then
		v24 = false
	else
		v24 = v23:GetAttribute("Known") == true
	end
	return v24
end
local function v_u_29() -- name: counts
	-- upvalues: (ref) v_u_14, (copy) v_u_5
	local v25 = {}
	local v26 = v_u_14
	if v26 then
		for v27 in v_u_5.LIMITED do
			local v28 = v26:GetAttribute(v27)
			v25[v27] = type(v28) ~= "number" and 0 or v28
		end
	end
	return v25
end
function v_u_10.left(p30) -- name: left
	-- upvalues: (copy) v_u_10, (copy) v_u_8, (copy) v_u_29, (copy) v_u_5, (copy) v_u_6
	if v_u_10.active(p30) then
		return v_u_8.leftOf(v_u_29(), v_u_8.takes(p30, v_u_5.LIMITED, v_u_6.BUNDLES, v_u_5.LIMITED_BUNDLES), v_u_5.LIMITED)
	else
		return nil
	end
end
local v_u_31 = {}
local v_u_32 = false
local function v_u_53(p33, p34) -- name: buy
	-- upvalues: (copy) v_u_11, (copy) v_u_6, (copy) v_u_31, (ref) v_u_13, (copy) v_u_10, (ref) v_u_32, (copy) v_u_2, (copy) v_u_9
	if v_u_11:GetAttribute("Pass_" .. p33) == true then
		local v35 = "You already own "
		local v36 = v_u_6.passByKey[p33]
		local v37 = string.upper
		local v38
		if v36 then
			v38 = v36.name
		else
			v38 = p33
		end
		local v39 = v35 .. v37(v38)
		local v40 = os.clock()
		if v40 - (v_u_31[p33] or (-1 / 0)) >= 4 then
			v_u_31[p33] = v40
			v_u_13(v39)
		end
	elseif v_u_10.known() and v_u_10.left(p33) == 0 then
		local v41 = v_u_6.passByKey[p33]
		local v42 = string.upper
		local v43
		if v41 then
			v43 = v41.name
		else
			v43 = p33
		end
		local v44 = v42(v43) .. " is SOLD OUT"
		local v45 = os.clock()
		if v45 - (v_u_31[p33] or (-1 / 0)) >= 4 then
			v_u_31[p33] = v45
			v_u_13(v44)
		end
	elseif v_u_32 then
		return
	else
		v_u_32 = true
		local v46, v47, v48 = v_u_2:WaitForChild("Remotes"):WaitForChild("MarketAsk"):InvokeServer("limited", p33)
		v_u_32 = false
		if v46 == true and (type(v48) == "number" and v48 == p34.id) then
			v_u_9.promptProduct(v48)
		elseif type(v47) == "string" then
			if v47 == "SOLD OUT" then
				local v49 = v_u_6.passByKey[p33]
				local v50 = string.upper
				local v51
				if v49 then
					v51 = v49.name
				else
					v51 = p33
				end
				v47 = v50(v51) .. " is SOLD OUT"
			end
			local v52 = os.clock()
			if v52 - (v_u_31[p33] or (-1 / 0)) < 4 then
				return
			end
			v_u_31[p33] = v52
			v_u_13(v47)
		end
	end
end
local function v_u_58() -- name: syncPrices
	-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_10, (copy) v_u_9
	local v54 = false
	for _, v55 in v_u_5.limited do
		local v56 = v_u_6.passByKey[v55.pass]
		if not (v56 and v_u_10.active(v55.pass)) then
			continue
		end
		local v57 = v_u_9.livePrice(v55.id, Enum.InfoType.Product)
		if not v57 or v57 == v56.price then
			continue
		end
		v56.price = v57
		v54 = true
	end
	if v54 then
		v_u_9.firePricesChanged()
	end
end
local v_u_59 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_60 = Color3.fromRGB(255, 240, 90)
local v_u_61 = Color3.fromRGB(255, 70, 70)
local function v_u_66(p62, p63) -- name: tagText
	-- upvalues: (copy) v_u_60
	local v64 = Instance.new("TextLabel")
	v64.Name = p62
	v64.BackgroundTransparency = 1
	v64.AnchorPoint = Vector2.new(0.5, 0.5)
	v64.FontFace = p63
	v64.TextScaled = true
	v64.TextColor3 = v_u_60
	v64.Rotation = 4
	local v65 = Instance.new("UIStroke")
	v65.Color = Color3.new(0, 0, 0)
	v65.Thickness = 0.1
	v65.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v65.Parent = v64
	return v64
end
local function v_u_68(p67) -- name: pop
	-- upvalues: (copy) v_u_4
	p67.Scale = 1.28
	v_u_4:Create(p67, TweenInfo.new(0.45, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		["Scale"] = 1
	}):Play()
end
local function v_u_79(p69, p70) -- name: stockLine
	-- upvalues: (copy) v_u_10, (copy) v_u_60, (copy) v_u_61, (copy) v_u_7, (copy) v_u_8, (copy) v_u_5, (copy) v_u_6
	local v71 = v_u_10.left(p69)
	if not (v_u_10.known() and v71) then
		return "LIMITED STOCK", v_u_60
	end
	if v71 == 0 then
		return "SOLD OUT", v_u_61
	end
	if p70 then
		return ("%* LEFT"):format((v_u_7.commas(v71))), v_u_60
	end
	local v72 = v_u_7.commas(v71)
	local v73 = v_u_7.commas
	local v74 = (1 / 0)
	local v75 = "%* / %* LEFT"
	for _, v76 in v_u_8.takes(p69, v_u_5.LIMITED, v_u_6.BUNDLES, v_u_5.LIMITED_BUNDLES) do
		local v77 = v_u_5.LIMITED[v76] or 0
		v74 = math.min(v74, v77)
	end
	local v78 = v74 == (1 / 0) and 0 or v74
	return v75:format(v72, (v73((math.max(v78, 1))))), v_u_60
end
local v_u_80 = ColorSequence.new(Color3.fromRGB(150, 150, 160), Color3.fromRGB(95, 95, 108))
local v_u_81 = {}
local function v_u_111(p_u_82, p_u_83, p84) -- name: decorate
	-- upvalues: (copy) v_u_59, (copy) v_u_66, (copy) v_u_10, (copy) v_u_79, (copy) v_u_68, (copy) v_u_80, (copy) v_u_81
	if not p_u_82:FindFirstChild("LimitedStock") then
		local v85 = p_u_82.Name
		local v_u_86 = string.sub(v85, 1, 5) == "Pack_"
		local v87 = v_u_59
		local v88 = p_u_82:FindFirstChild("Title")
		if v88 and v88:IsA("TextLabel") then
			v87 = v88.FontFace
		end
		local v_u_89 = v_u_66("LimitedStock", v87)
		if v_u_86 then
			v_u_89.Position = UDim2.fromScale(0.6, 0.14)
			v_u_89.Size = UDim2.fromScale(0.22, 0.14)
		else
			v_u_89.AnchorPoint = Vector2.new(0, 0.5)
			v_u_89.Position = UDim2.fromScale(0.345, 0.905)
			v_u_89.Size = UDim2.fromScale(0.36, 0.12)
			v_u_89.TextXAlignment = Enum.TextXAlignment.Left
			v_u_89.Rotation = 3
		end
		v_u_89.ZIndex = 7
		v_u_89.Visible = false
		local v_u_90 = Instance.new("UIScale")
		v_u_90.Name = "Pop"
		v_u_90.Parent = v_u_89
		v_u_89.Parent = p_u_82
		local v_u_91 = p_u_82:FindFirstChild("Tag")
		local v_u_92 = not (v_u_91 and v_u_91:IsA("TextLabel")) and "" or v_u_91.Text
		local v_u_93 = p84:FindFirstChild("PriceTag")
		local v_u_94 = p84:FindFirstChildOfClass("UIGradient")
		local v_u_95
		if v_u_94 then
			v_u_95 = v_u_94.Color
		else
			v_u_95 = nil
		end
		local v_u_96 = nil
		local function v105() -- name: refresh
			-- upvalues: (ref) v_u_10, (copy) p_u_83, (copy) v_u_89, (copy) v_u_91, (copy) v_u_92, (ref) v_u_79, (copy) v_u_86, (ref) v_u_96, (ref) v_u_68, (copy) v_u_90, (copy) v_u_93, (copy) v_u_94, (copy) v_u_95, (ref) v_u_80
			local v97 = v_u_10.active(p_u_83) ~= nil
			v_u_89.Visible = v97
			if v_u_91 and v_u_91:IsA("TextLabel") then
				v_u_91.Text = v97 and "LIMITED!" or v_u_92
			end
			local v98 = v_u_10.left(p_u_83)
			local v99 = v97 and v_u_10.known()
			if v99 then
				v99 = v98 == 0
			end
			if v97 and v98 then
				local v100, v101 = v_u_79(p_u_83, v_u_86)
				v_u_89.Text = v100
				local v102 = v_u_89
				if v99 then
					v101 = Color3.new(1, 1, 1)
				end
				v102.TextColor3 = v101
				if v_u_10.known() then
					if v_u_96 and v98 < v_u_96 then
						v_u_68(v_u_90)
					end
					v_u_96 = v98
				end
				if v_u_93 and (v_u_93:IsA("TextLabel") and v99) then
					v_u_93.Text = "SOLD OUT"
				end
				if v_u_94 and v_u_95 then
					local v103 = v_u_94
					local v104
					if v99 then
						v104 = v_u_80
					else
						v104 = v_u_95
					end
					v103.Color = v104
				end
			end
		end
		local v106 = v_u_81
		table.insert(v106, v105)
		v105()
		local v_u_107 = nil
		for _, v108 in p_u_82:GetChildren() do
			if not v108:IsA("TextLabel") or (v108.Name ~= "Title" or v108.Rotation == 0) then
				continue
			end
			v_u_107 = v108
		end
		if v_u_86 and v_u_107 then
			local v_u_109 = v_u_107.Text
			task.spawn(function()
				-- upvalues: (copy) p_u_82, (ref) v_u_10, (copy) p_u_83, (copy) v_u_107, (copy) v_u_109
				local v110 = false
				while p_u_82.Parent do
					task.wait(1.6)
					v110 = not v110
					v_u_107.Text = v_u_10.active(p_u_83) ~= nil and v110 and "LIMITED!" or v_u_109
				end
			end)
		end
	end
end
local function v_u_113() -- name: refreshAll
	-- upvalues: (copy) v_u_81, (copy) v_u_12
	for _, v112 in v_u_81 do
		v112()
	end
	v_u_12:Fire()
end
local function v_u_118(p114) -- name: scan
	-- upvalues: (copy) v_u_5, (copy) v_u_111
	for _, v115 in p114:GetDescendants() do
		if not v115:IsA("GuiButton") then
			continue
		end
		local v116 = v115:GetAttribute("Ui-Pass")
		local v117 = v115.Parent
		if type(v116) ~= "string" or not (v_u_5.limitedByPass[v116] and (v117 and v117:IsA("GuiObject"))) then
			continue
		end
		v_u_111(v117, v116, v115)
	end
end
function v_u_10.podium(p119, p_u_120, p_u_121, p_u_122) -- name: podium
	-- upvalues: (copy) v_u_5, (copy) v_u_66, (copy) v_u_59, (copy) v_u_10, (copy) v_u_60, (copy) v_u_61, (copy) v_u_7, (copy) v_u_8, (copy) v_u_6, (copy) v_u_68
	if not v_u_5.limitedByPass[p_u_120] then
		return nil
	end
	local v_u_123 = Instance.new("BillboardGui")
	v_u_123.Name = "LimitedStock"
	v_u_123.Adornee = p119
	v_u_123.Size = UDim2.new(p_u_121 * 15, 70, p_u_121 * 6, 28)
	v_u_123.SizeOffset = Vector2.new(0, 0.5)
	v_u_123.LightInfluence = 0
	v_u_123.MaxDistance = 220
	v_u_123.Enabled = false
	local v_u_124 = v_u_66("Top", v_u_59)
	v_u_124.Text = "LIMITED STOCK"
	v_u_124.Position = UDim2.fromScale(0.5, 0.28)
	v_u_124.Size = UDim2.fromScale(1, 0.5)
	v_u_124.Rotation = -4
	v_u_124.TextColor3 = Color3.new(1, 1, 1)
	local v125 = Instance.new("UIGradient")
	v125.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 236, 120)), ColorSequenceKeypoint.new(0.45, Color3.fromRGB(255, 150, 40)), ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 60, 60)) })
	v125.Rotation = 90
	v125.Parent = v_u_124
	v_u_124.Parent = v_u_123
	local v_u_126 = v_u_66("Count", v_u_59)
	v_u_126.Position = UDim2.fromScale(0.5, 0.76)
	v_u_126.Size = UDim2.fromScale(0.9, 0.36)
	local v_u_127 = Instance.new("UIScale")
	v_u_127.Parent = v_u_126
	v_u_126.Parent = v_u_123
	v_u_123.Parent = p119
	local v_u_128 = nil
	local function v141() -- name: show
		-- upvalues: (copy) v_u_123, (ref) v_u_10, (copy) p_u_120, (ref) v_u_60, (ref) v_u_61, (ref) v_u_7, (ref) v_u_8, (ref) v_u_5, (ref) v_u_6, (copy) v_u_126, (ref) v_u_128, (ref) v_u_68, (copy) v_u_127
		v_u_123.Enabled = v_u_10.active(p_u_120) ~= nil
		local v129 = p_u_120
		local v130 = v_u_10.left(v129)
		local v131, v132
		if v_u_10.known() and v130 then
			if v130 == 0 then
				v131 = v_u_61
				v132 = "SOLD OUT"
			else
				local v133 = v_u_7.commas(v130)
				local v134 = v_u_7.commas
				local v135 = (1 / 0)
				local v136 = "%* / %* LEFT"
				for _, v137 in v_u_8.takes(v129, v_u_5.LIMITED, v_u_6.BUNDLES, v_u_5.LIMITED_BUNDLES) do
					local v138 = v_u_5.LIMITED[v137] or 0
					v135 = math.min(v135, v138)
				end
				local v139 = v135 == (1 / 0) and 0 or v135
				v132 = v136:format(v133, (v134((math.max(v139, 1)))))
				v131 = v_u_60
			end
		else
			v131 = v_u_60
			v132 = "LIMITED STOCK"
		end
		v_u_126.Visible = v132 ~= "LIMITED STOCK"
		v_u_126.Text = v132
		v_u_126.TextColor3 = v131
		local v140 = v_u_10.left(p_u_120)
		if v140 and v_u_10.known() then
			if v_u_128 and v140 < v_u_128 then
				v_u_68(v_u_127)
			end
			v_u_128 = v140
		end
	end
	local v_u_142 = v_u_10.changed:Connect(v141)
	v141()
	local v_u_143 = true
	task.spawn(function()
		-- upvalues: (ref) v_u_143, (copy) v_u_123, (copy) p_u_121, (copy) v_u_124, (copy) v_u_126, (copy) p_u_122
		while v_u_143 do
			local v144 = os.clock()
			local v145 = v_u_123
			local v146 = p_u_121 * 5.5
			local v147 = v144 * 1.8
			local v148 = v146 + math.sin(v147) * 0.4 * p_u_121
			v145.StudsOffsetWorldSpace = Vector3.new(0, v148, 0)
			local v149 = v_u_124
			local v150 = v144 * 2.2
			v149.Rotation = math.sin(v150) * 1.5 + -4
			local v151 = v_u_126
			local v152 = v144 * 2.2 + 1.3
			v151.Rotation = math.sin(v152) * 1.5 + 4
			task.wait(p_u_122(v_u_123))
		end
	end)
	return function()
		-- upvalues: (ref) v_u_143, (copy) v_u_142, (copy) v_u_123
		v_u_143 = false
		v_u_142:Disconnect()
		v_u_123:Destroy()
	end
end
function v_u_10.start(p153) -- name: start
	-- upvalues: (ref) v_u_13, (copy) v_u_2, (ref) v_u_14, (copy) v_u_20, (copy) v_u_9, (copy) v_u_10, (copy) v_u_53, (copy) v_u_81, (copy) v_u_12, (copy) v_u_11, (copy) v_u_118, (copy) v_u_113, (copy) v_u_58, (copy) v_u_6, (copy) v_u_7
	v_u_13 = p153
	local v154 = v_u_2:WaitForChild("MarketStock", 30)
	if v154 then
		v_u_14 = v154
		v_u_20()
		v_u_9.onPassBuy(function(p155)
			-- upvalues: (ref) v_u_10, (ref) v_u_53
			local v156 = v_u_10.active(p155)
			if not v156 then
				return false
			end
			task.spawn(v_u_53, p155, v156)
			return true
		end)
		v154.AttributeChanged:Connect(function(p157)
			-- upvalues: (ref) v_u_20, (ref) v_u_81, (ref) v_u_12
			if p157 == "DevIds" then
				v_u_20()
			end
			for _, v158 in v_u_81 do
				v158()
			end
			v_u_12:Fire()
		end)
		local v_u_159 = v_u_11:WaitForChild("PlayerGui"):WaitForChild("Main", 30)
		if v_u_159 then
			v_u_159 = v_u_159:FindFirstChild("Frames")
		end
		if v_u_159 then
			v_u_159 = v_u_159:FindFirstChild("Store")
		end
		if v_u_159 then
			v_u_159 = v_u_159:FindFirstChild("Holder", true)
		end
		if v_u_159 then
			v_u_118(v_u_159)
			v_u_159.ChildAdded:Connect(function()
				-- upvalues: (ref) v_u_118, (copy) v_u_159
				task.defer(v_u_118, v_u_159)
			end)
		end
		for _, v160 in v_u_81 do
			v160()
		end
		v_u_12:Fire()
		v_u_9.pricesChanged:Connect(function()
			-- upvalues: (ref) v_u_113, (ref) v_u_58
			task.defer(v_u_113)
			task.delay(1, v_u_58)
		end)
		task.delay(3, v_u_58)
		local v161 = v_u_2:WaitForChild("Remotes"):WaitForChild("Market", 30)
		if v161 and v161:IsA("RemoteEvent") then
			v161.OnClientEvent:Connect(function(p162, p163)
				-- upvalues: (ref) v_u_13, (ref) v_u_6, (ref) v_u_7
				if p162 == "sold" and type(p163) == "table" then
					local v164 = p163.name
					local v165 = p163.item
					local v166 = p163.left
					if type(v164) == "string" and (type(v165) == "string" and type(v166) == "number") then
						local v167 = v_u_13
						local v168 = "%* got %*! %* left"
						local v169 = v_u_6.passByKey[v165]
						local v170 = string.upper
						if v169 then
							v165 = v169.name
						end
						v167((v168:format(v164, v170(v165), (v_u_7.commas(v166)))))
					end
				end
			end)
		end
	end
end
return v_u_10