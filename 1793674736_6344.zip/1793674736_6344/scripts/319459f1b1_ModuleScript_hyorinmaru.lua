local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_3.Shared.Config.Textures)
local v_u_8 = Color3.fromHex("8AD8FF")
local v_u_9 = Color3.fromHex("E8FAFF")
local v_u_10 = Color3.fromRGB(70, 214, 255)
local v_u_11 = Color3.fromRGB(34, 112, 226)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Color3.fromRGB(196, 238, 255)
local v_u_14 = Enum.Material.Neon
local v_u_15 = Enum.Material.SmoothPlastic
local function v_u_27(p16, p17, p18, p19, p20) -- name: pic
	-- upvalues: (copy) v_u_5
	local v21 = v_u_5.part
	local v22 = p17 * 2
	local v23 = p17 * 2
	local v24 = v21(Vector3.new(v22, 0.05, v23), p16, p19, {
		["transparency"] = 1
	})
	for _, v25 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v26 = Instance.new("Decal")
		v26.Face = v25
		v26.Texture = p18
		v26.Color3 = p19
		v26.Transparency = p20
		v26.Parent = v24
	end
	return v24
end
local function v_u_34(p28, p29, p30, p31) -- name: blob
	-- upvalues: (copy) v_u_5
	local v32 = v_u_5.part(p28, p29, p30, {
		["material"] = p31
	})
	local v33 = Instance.new("SpecialMesh")
	v33.MeshType = Enum.MeshType.Sphere
	v33.Parent = v32
	return v32
end
local function v_u_38(p35, p36) -- name: wedge
	-- upvalues: (copy) v_u_5
	local v37 = Instance.new("WedgePart")
	v37.Anchored = true
	v37.CanCollide = false
	v37.CanQuery = false
	v37.CanTouch = false
	v37.CastShadow = false
	v37.Color = p35
	v37.Material = p36
	v37.Size = Vector3.new(0.1, 0.1, 0.1)
	v37.CFrame = CFrame.new(0, -500, 0)
	v37.Parent = v_u_5.folder()
	return v37
end
local function v_u_46(p39, p40, p41, p42, p43) -- name: shard
	-- upvalues: (copy) v_u_38, (copy) v_u_1
	local v44 = v_u_38(p39, p40)
	local v45 = v_u_38(p39, p40)
	v_u_1:AddItem(v44, p43)
	v_u_1:AddItem(v45, p43)
	return {
		["a"] = v44,
		["b"] = v45,
		["wide"] = p41,
		["deep"] = p42
	}
end
local function v_u_59(p47, p48, p49, p50, p51) -- name: put
	local v52 = math.max(p51, 0.05)
	local v53 = p49.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p49.Unit
	local v54 = p50 - v53 * p50:Dot(v53)
	if v54.Magnitude < 0.001 then
		v54 = v53:Cross(Vector3.new(1, 0, 0))
		if v54.Magnitude < 0.001 then
			v54 = v53:Cross(Vector3.new(0, 0, 1))
		end
	end
	local v55 = CFrame.fromMatrix(p48 + v53 * (v52 / 2), v54.Unit, v53)
	local v56 = p47.wide
	local v57 = p47.deep / 2
	local v58 = Vector3.new(v56, v52, v57)
	p47.a.Size = v58
	p47.b.Size = v58
	p47.a.CFrame = v55 * CFrame.new(0, 0, -p47.deep / 4)
	p47.b.CFrame = v55 * CFrame.new(0, 0, p47.deep / 4) * CFrame.Angles(0, 3.141592653589793, 0)
end
local function v_u_68(p60, p61) -- name: dragonHead
	-- upvalues: (copy) v_u_3, (copy) v_u_13, (copy) v_u_15, (copy) v_u_5, (copy) v_u_38, (copy) v_u_1
	local v62 = v_u_3:FindFirstChild("EyePieces")
	if v62 then
		v62 = v62:FindFirstChild("w6_hyorinmaru")
	end
	local v63
	if v62 and v62:IsA("MeshPart") then
		v63 = v62:Clone()
		v63.Anchored = true
		v63.CanCollide = false
		v63.CanQuery = false
		v63.CanTouch = false
		v63.CastShadow = false
		local v64 = v62.Size
		local v65 = v62.Size.Z
		v63.Size = v64 * (p60 / math.max(v65, 0.01))
		if not v63:FindFirstChildWhichIsA("SurfaceAppearance") then
			v63.Color = v_u_13
			v63.Material = v_u_15
			v63.Reflectance = 0.15
		end
		v63.Parent = v_u_5.folder()
	else
		v63 = v_u_38(v_u_13, v_u_15)
		local v66 = p60 * 0.55
		local v67 = p60 * 0.5
		v63.Size = Vector3.new(v66, v67, p60)
		v63.Reflectance = 0.15
	end
	v_u_1:AddItem(v63, p61)
	return v63
end
local function v_u_77(p69, p70, p71, p72, p73) -- name: snow
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8, (copy) v_u_1
	if p70 > 0 then
		local v74 = Instance.new("Attachment")
		v74.WorldPosition = p69
		v74.Parent = v_u_4.Terrain
		local v75 = Instance.new("ParticleEmitter")
		v75.Enabled = false
		v75.Texture = v_u_7.Snowflake
		v75.Color = ColorSequence.new(v_u_9, v_u_8)
		v75.LightEmission = 0.6
		v75.LightInfluence = 0
		v75.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p71), NumberSequenceKeypoint.new(0.75, p71 * 0.8), NumberSequenceKeypoint.new(1, 0) })
		v75.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.8, 0.15), NumberSequenceKeypoint.new(1, 1) })
		local v76 = p73 or 1
		v75.Lifetime = NumberRange.new(v76 * 0.6, v76)
		v75.Speed = NumberRange.new(p72 * 0.35, p72)
		v75.SpreadAngle = Vector2.new(180, 180)
		v75.Drag = 2.5
		v75.Acceleration = Vector3.new(0, -5, 0)
		v75.Rotation = NumberRange.new(0, 360)
		v75.RotSpeed = NumberRange.new(-220, 220)
		v75.Parent = v74
		v75:Emit(p70)
		v_u_1:AddItem(v74, v76 + 0.3)
	end
end
local function v_u_84(p78, p79, p80, p81) -- name: twinkle
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_12, (copy) v_u_1
	if p79 > 0 then
		local v82 = Instance.new("Attachment")
		v82.WorldPosition = p78
		v82.Parent = v_u_4.Terrain
		local v83 = Instance.new("ParticleEmitter")
		v83.Enabled = false
		v83.Texture = v_u_7.PetStar
		v83.Color = ColorSequence.new(v_u_12)
		v83.LightEmission = 0.8
		v83.LightInfluence = 0
		v83.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.3, p80), NumberSequenceKeypoint.new(1, 0) })
		v83.Lifetime = NumberRange.new(0.35, 0.6)
		v83.Speed = NumberRange.new(p81 * 0.5, p81 * 1.5)
		v83.SpreadAngle = Vector2.new(180, 180)
		v83.Drag = 6
		v83.Rotation = NumberRange.new(0, 90)
		v83.Parent = v82
		v83:Emit(p79)
		v_u_1:AddItem(v82, 0.9)
	end
end
local function v_u_93(p85, p86, p87, p88, p89, p_u_90) -- name: screenTint
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_12, (copy) v_u_1
	local v_u_91 = Instance.new("ColorCorrectionEffect")
	v_u_91.Name = "Hyorinmaru"
	v_u_91.Parent = v_u_2
	v_u_5.tween(v_u_91, p88, {
		["TintColor"] = p85,
		["Brightness"] = p86,
		["Contrast"] = p87
	})
	task.delay(p88 + p89, function()
		-- upvalues: (ref) v_u_5, (copy) v_u_91, (copy) p_u_90, (ref) v_u_12
		local v92 = {
			["TintColor"] = nil,
			["Brightness"] = 0,
			["Contrast"] = 0,
			["TintColor"] = v_u_12
		}
		v_u_5.tween(v_u_91, p_u_90, v92)
	end)
	v_u_1:AddItem(v_u_91, p88 + p89 + p_u_90 + 0.1)
end
return function(p_u_94)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_12, (copy) v_u_68, (copy) v_u_5, (copy) v_u_1, (copy) v_u_27, (copy) v_u_7, (copy) v_u_34, (copy) v_u_11, (copy) v_u_14, (copy) v_u_15, (copy) v_u_4, (copy) v_u_77, (copy) v_u_46, (copy) v_u_59, (copy) v_u_84, (copy) v_u_13, (copy) v_u_6, (copy) v_u_38, (copy) v_u_93
	local v95 = {}
	local function v_u_103(p96, p97, p98) -- name: shatter
		-- upvalues: (copy) p_u_94, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_12
		for v99, v100 in p96 do
			if v100.a.Parent then
				local v101 = (v100.a.Position + v100.b.Position) / 2
				if not p98 and v99 % 2 == 1 then
					local v102 = { v_u_8, v_u_9, v_u_10 }
					p_u_94.chunks(v101, v102, 3, p97 * 18, p97 * 0.55, 0.7, true, 0.6)
				end
				if v99 % 3 == 1 then
					p_u_94.glint(v101, v_u_12, p97 * 2.4, 0.18)
				end
			end
			v100.a:Destroy()
			v100.b:Destroy()
		end
	end
	local v_u_104 = { 0.95, 0.8, 0.62 }
	v95.hyorinmaru_a = {
		["cast"] = nil,
		["shot"] = nil,
		["weave"] = 0.9,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p105) -- name: cast
			-- upvalues: (ref) v_u_5, (ref) v_u_8, (copy) p_u_94, (ref) v_u_9, (ref) v_u_77
			local v106 = p105.size
			local v107 = p105.eye + p105.dir * 1.1
			v_u_5.flash(v107, v_u_8, 3 * v106, 0.12)
			p_u_94.pop(v107, v_u_9, 1.3 * v106, 0.3 * v106, 0.1)
			if not p105.lite then
				v_u_77(v107, 4, 0.5 * v106, 8, 0.5)
			end
		end,
		["shot"] = function(p_u_108, p_u_109) -- name: fangShot
			-- upvalues: (ref) v_u_68, (ref) v_u_5, (ref) v_u_8, (ref) v_u_1, (copy) p_u_94, (ref) v_u_9, (ref) v_u_10, (ref) v_u_27, (ref) v_u_7, (copy) v_u_104, (ref) v_u_34, (ref) v_u_11, (ref) v_u_14, (ref) v_u_15, (ref) v_u_4, (ref) v_u_77
			local v_u_110 = p_u_108.size
			local v_u_111 = v_u_68(1.9 * v_u_110, 3)
			local v_u_112 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p_u_109, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_112, 3)
			p_u_94.streak(v_u_112, v_u_9, v_u_10, 1.1 * v_u_110, p_u_108.lite and 0.12 or 0.22)
			local v_u_113 = v_u_27(p_u_109, 1.8 * v_u_110, v_u_7.Glow, v_u_8, 0.35)
			v_u_1:AddItem(v_u_113, 3)
			local v_u_114 = {}
			if not p_u_108.lite then
				for v115, v116 in v_u_104 do
					local v117 = v_u_34
					local v118 = v116 * 0.8
					local v119 = v116 * 1.5
					local v120 = Vector3.new(v116, v118, v119) * v_u_110
					local v121
					if v115 % 2 == 1 then
						v121 = v_u_10
					else
						v121 = v_u_11
					end
					local v122
					if v115 % 2 == 1 then
						v122 = v_u_14
					else
						v122 = v_u_15
					end
					local v123 = v117(v120, p_u_109, v121, v122)
					v_u_1:AddItem(v123, 3)
					v_u_114[v115] = v123
				end
			end
			if p_u_108.mine then
				p_u_94.light(v_u_112, v_u_8, 8 * v_u_110)
			end
			local v_u_124 = {}
			local v_u_125 = 0.05
			local v_u_126 = false
			return {
				["place"] = function(p127, p128) -- name: place
					-- upvalues: (copy) v_u_111, (copy) v_u_112, (copy) v_u_113, (ref) p_u_94, (ref) v_u_4, (copy) v_u_110, (copy) v_u_124, (copy) v_u_114, (copy) p_u_109, (copy) p_u_108, (ref) v_u_125, (ref) v_u_77
					local v129 = v_u_111
					local v130 = CFrame.Angles
					local v131 = p128 * 26
					v129.CFrame = p127 * v130(0, math.sin(v131) * 0.22, 0)
					v_u_112.CFrame = p127
					local v132 = v_u_113
					local v133 = p_u_94.facing
					local v134 = p127.Position
					local v135 = p127.Position
					local v136 = v_u_4.CurrentCamera
					local v137
					if v136 then
						local v138 = v136.CFrame.Position - v135
						v137 = v138.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v138.Unit
					else
						v137 = Vector3.new(0, 0, 1)
					end
					v132.CFrame = v133(v134, v137) * CFrame.new(0, -0.4 * v_u_110, 0)
					local v139 = v_u_124
					table.insert(v139, {
						["t"] = p128,
						["cf"] = p127
					})
					if #v_u_124 > 24 then
						table.remove(v_u_124, 1)
					end
					for v140, v141 in v_u_114 do
						local v142 = p128 - v140 * 0.028
						local v143
						for v144 = #v_u_124, 1, -1 do
							if v_u_124[v144].t > v142 then
								continue
							end
							v143 = v_u_124[v144].cf
						end
						if v_u_124[1] then
							v143 = v_u_124[1].cf
						else
							v143 = p_u_109
						end
						local v145 = p128 * 26 - v140 * 1.3
						local v146 = math.sin(v145) * 0.35 * v_u_110
						v141.CFrame = v143 * CFrame.new(v146, 0, 0.95 * v_u_110 * v140)
					end
					if not p_u_108.lite and v_u_125 <= p128 then
						v_u_125 = p128 + 0.07
						v_u_77(p127.Position, 2, 0.5 * v_u_110, 4, 0.5)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_126, (copy) v_u_111, (copy) v_u_113, (copy) v_u_114, (copy) v_u_112, (ref) v_u_1, (copy) p_u_108
					if not v_u_126 then
						v_u_126 = true
						v_u_111:Destroy()
						v_u_113:Destroy()
						for _, v147 in v_u_114 do
							v147:Destroy()
						end
						local v148 = v_u_112:FindFirstChildWhichIsA("PointLight")
						if v148 then
							v148:Destroy()
						end
						v_u_1:AddItem(v_u_112, p_u_108.lite and 0.2 or 0.6)
					end
				end
			}
		end,
		["impact"] = function(p_u_149, p_u_150) -- name: fangBite
			-- upvalues: (ref) v_u_46, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (ref) v_u_14, (copy) p_u_94, (ref) v_u_59, (copy) v_u_103, (ref) v_u_5, (ref) v_u_7, (ref) v_u_8, (ref) v_u_77, (ref) v_u_84
			local v_u_151 = p_u_149.size
			local v_u_152 = p_u_149.lite and 3 or 6
			local v_u_153 = 2.6 * v_u_151
			local v_u_154 = math.random() * 3.141592653589793 * 2
			local v_u_155 = {}
			for v156 = 1, v_u_152 do
				local v157 = v_u_46
				local v158
				if v156 % 2 == 0 then
					v158 = v_u_9
				else
					v158 = v_u_10
				end
				local v159
				if v156 % 2 == 0 then
					v159 = v_u_15
				else
					v159 = v_u_14
				end
				v_u_155[v156] = v157(v158, v159, 0.35 * v_u_151, 0.9 * v_u_151, 0.6)
			end
			local v_u_160 = p_u_150 - Vector3.new(0, 1.2, 0) * v_u_151
			p_u_94.animate(0.3, 0, function(p161)
				-- upvalues: (copy) v_u_155, (copy) v_u_154, (copy) v_u_152, (copy) v_u_160, (copy) v_u_153, (ref) v_u_59, (copy) v_u_151, (ref) v_u_103, (copy) p_u_149
				local v162 = p161 / 0.35
				local v163 = math.clamp(v162, 0, 1) - 1
				local v164 = v163 * 2.8 * v163 * v163 + 1 + v163 * 1.8 * v163
				local v165 = (p161 - 0.38) / 0.16
				local v166 = math.clamp(v165, 0, 1)
				local v167 = v166 * v166 * (3 - v166 * 2)
				for v168, v169 in v_u_155 do
					local v170 = v_u_154 + (v168 - 1) * 3.141592653589793 * 2 / v_u_152
					local v171 = math.cos(v170)
					local v172 = math.sin(v170)
					local v173 = Vector3.new(v171, 0, v172)
					local v174 = v_u_160 + v173 * v_u_153 * (1 - v167 * 0.35)
					local v175 = 0.35 - v167 * 1.05
					v_u_59(v169, v174, Vector3.new(0, 1, 0) * math.cos(v175) + v173 * math.sin(v175), v173, 3 * v_u_151 * math.max(v164, 0.05))
				end
				if p161 >= 1 then
					v_u_103(v_u_155, 0.6 * v_u_151, p_u_149.lite)
				end
			end)
			p_u_94.after(0.16, function()
				-- upvalues: (ref) v_u_5, (ref) p_u_94, (copy) p_u_150, (ref) v_u_9, (copy) v_u_151, (ref) v_u_7, (ref) v_u_8, (copy) p_u_149, (ref) v_u_77, (ref) v_u_84
				v_u_5.ring(p_u_94.ground(p_u_150), v_u_9, 5.5 * v_u_151, 0.35, v_u_7.Ring)
				p_u_94.burst("Impact", p_u_150, v_u_8, 0.75 * v_u_151)
				if not p_u_149.lite then
					v_u_77(p_u_150, 10, 0.7 * v_u_151, 14, 0.8)
					v_u_84(p_u_150, 3, 1.3 * v_u_151, 6)
				end
			end)
			p_u_94.hitSound(p_u_150)
		end,
		["hit"] = p_u_94.simpleHit(v_u_8, 0.55)
	}
	local v_u_176 = {}
	setmetatable(v_u_176, {
		["__mode"] = "k"
	})
	local function v_u_192(p177, p178, p179, p180, p181, p182, p183) -- name: lay
		-- upvalues: (ref) v_u_59
		local v184 = #p177
		for v185, v186 in p177 do
			local v187 = p182 + (v185 - 1) * 3.141592653589793 * 2 / v184
			local v188 = math.cos(v187)
			local v189 = math.sin(v187)
			local v190 = Vector3.new(v188, 0, v189)
			local v191 = Vector3.new(0, 1, 0) * math.cos(p181) + v190 * math.sin(p181)
			v_u_59(v186, p178 + v190 * p179, v191, v190, p180 * math.max(p183, 0.05))
		end
	end
	local function v_u_238(p_u_193, p194) -- name: bigFlower
		-- upvalues: (copy) p_u_94, (ref) v_u_46, (ref) v_u_13, (ref) v_u_10, (ref) v_u_15, (ref) v_u_14, (ref) v_u_11, (ref) v_u_9, (ref) v_u_8, (copy) v_u_192, (ref) v_u_59, (copy) v_u_103, (ref) v_u_5, (ref) v_u_7, (ref) v_u_77, (ref) v_u_6
		local v_u_195 = p_u_193.ability.radius
		local v196 = p_u_193.ability.freeze or 3
		local v_u_197 = v196 + 1
		local v_u_198 = p_u_94.ground(p194, 0)
		local v_u_199 = {}
		local v_u_200 = {}
		local v_u_201 = {}
		for v202 = 1, 8 do
			local v203 = v_u_46
			local v204
			if v202 % 2 == 0 then
				v204 = v_u_13
			else
				v204 = v_u_10
			end
			local v205
			if v202 % 2 == 0 then
				v205 = v_u_15
			else
				v205 = v_u_14
			end
			v_u_199[v202] = v203(v204, v205, 0.6, 3.8, v_u_197)
		end
		if not p_u_193.lite then
			for v206 = 1, 4 do
				v_u_200[v206] = v_u_46(v_u_11, v_u_15, 0.45, 2, v_u_197)
			end
		end
		local v_u_207 = v_u_46(v_u_9, v_u_14, 0.7, 2.2, v_u_197)
		for v208 = 1, p_u_193.lite and 6 or 12 do
			local v209 = v_u_46
			local v210
			if v208 % 2 == 0 then
				v210 = v_u_8
			else
				v210 = v_u_9
			end
			local v211
			if v208 % 2 == 0 then
				v211 = v_u_14
			else
				v211 = v_u_15
			end
			v_u_201[v208] = v209(v210, v211, 0.6, 2, v_u_197)
		end
		local v_u_212 = math.random() * 3.141592653589793 * 2
		local v_u_213 = os.clock()
		local v_u_214 = false
		p_u_94.runNow(function()
			-- upvalues: (copy) v_u_213, (ref) v_u_214, (ref) v_u_192, (copy) v_u_199, (copy) v_u_198, (copy) v_u_212, (copy) v_u_200, (ref) v_u_59, (copy) v_u_207, (copy) v_u_201, (copy) v_u_195, (copy) v_u_197
			local v215 = os.clock() - v_u_213
			if v_u_214 then
				return false
			end
			local v216 = v215 / 0.32
			local v217 = math.clamp(v216, 0, 1) - 1
			local v218 = v217 * 2.8 * v217 * v217 + 1 + v217 * 1.8 * v217
			local v219 = v215 / 0.32
			local v220 = math.clamp(v219, 0, 1) * 1.05
			local v221 = v215 * 3
			local v222 = v220 + math.sin(v221) * 0.04
			v_u_192(v_u_199, v_u_198, 1.2, 11, v222, v_u_212, v218)
			if #v_u_200 > 0 then
				v_u_192(v_u_200, v_u_198, 0.6, 6.6, v222 * 0.45, v_u_212 + 0.7853981633974483, v218)
			end
			v_u_59(v_u_207, v_u_198, Vector3.new(0, 1, 0), Vector3.new(1, 0, 0), math.max(v218, 0.05) * 9.35)
			for v223, v224 in v_u_201 do
				local v225 = (v215 - 0.05 - v223 % 3 * 0.04) / 0.22
				local v226 = math.clamp(v225, 0, 1) - 1
				local v227 = v226 * 2.8 * v226 * v226 + 1 + v226 * 1.8 * v226
				local v228 = v_u_212 + (v223 - 0.5) * 3.141592653589793 * 2 / #v_u_201
				local v229 = math.cos(v228)
				local v230 = math.sin(v228)
				local v231 = Vector3.new(v229, 0, v230)
				local v232 = v223 % 2 * 0.15 + 0.35
				v_u_59(v224, v_u_198 + v231 * v_u_195 * 0.95, Vector3.new(0, 1, 0) * math.cos(v232) + v231 * math.sin(v232), v231, (v223 % 3 * 1.2 + 3.2) * math.max(v227, 0.05))
			end
			return v215 < v_u_197
		end)
		p_u_94.after(v196, function()
			-- upvalues: (ref) v_u_214, (copy) v_u_199, (copy) v_u_200, (copy) v_u_201, (copy) v_u_207, (ref) v_u_103, (copy) p_u_193, (ref) v_u_5, (copy) v_u_198, (ref) v_u_9, (copy) v_u_195, (ref) v_u_7, (ref) v_u_77, (ref) v_u_6
			v_u_214 = true
			local v233 = {}
			for _, v234 in { v_u_199, v_u_200, v_u_201 } do
				for _, v235 in v234 do
					table.insert(v233, v235)
				end
			end
			local v236 = v_u_207
			table.insert(v233, v236)
			v_u_103(v233, 1, p_u_193.lite)
			v_u_5.ring(v_u_198, v_u_9, v_u_195 * 1.15, 0.4, v_u_7.Shockwave)
			v_u_77(v_u_198 + Vector3.new(0, 4, 0), p_u_193.lite and 8 or 26, 1.1, 24, 1.1)
			local v237 = {
				["at"] = nil,
				["volume"] = 0.5,
				["at"] = v_u_198
			}
			v_u_6.play("Crit", v237)
		end)
	end
	v95.hyorinmaru_e = {
		["cast"] = function(p239) -- name: cast
			-- upvalues: (copy) p_u_94, (ref) v_u_8, (ref) v_u_9
			p_u_94.skillCast(p239, v_u_8)
			if not p239.lite then
				p_u_94.glint(p239.eye, v_u_9, 4 * p239.size, 0.2)
			end
		end,
		["windup"] = function(p240, p241, p242) -- name: windup
			-- upvalues: (copy) p_u_94, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7
			local v243 = p240.ability.radius
			local v244 = p_u_94.ground(p241)
			v_u_5.ring(v244, v_u_9, v243, math.max(p242, 0.1) + 0.2, v_u_7.Ring)
			if not p240.lite then
				p_u_94.inward(v244 + Vector3.new(0, 2, 0), v_u_9, 8, v243, math.max(p242, 0.1) + 0.12)
			end
		end,
		["land"] = function(p245, p246) -- name: land
			-- upvalues: (copy) p_u_94, (copy) v_u_238, (ref) v_u_8, (ref) v_u_5, (ref) v_u_7, (ref) v_u_77, (ref) v_u_84, (ref) v_u_6
			local v247 = p245.ability.radius
			local v248 = p_u_94.ground(p246)
			v_u_238(p245, p246)
			p_u_94.burst("Shockwave", v248 + Vector3.new(0, 0.3, 0), v_u_8, v247 / 18)
			v_u_5.ring(v248, v_u_8, v247 * 1.1, 0.35, v_u_7.Shockwave)
			p_u_94.mark(p246, v_u_8, v247 * 0.9, (p245.ability.freeze or 3) + 0.4, v_u_7.Glow, 0.55)
			v_u_77(v248 + Vector3.new(0, 3, 0), p245.lite and 8 or 22, 1, 20, 1.2)
			if not p245.lite then
				v_u_84(v248 + Vector3.new(0, 4, 0), 8, 2, 14)
			end
			v_u_6.play("Bind", {
				["at"] = nil,
				["volume"] = 0.6,
				["at"] = v248
			})
			if p245.mine then
				v_u_5.shake(0.28, 0.22)
			end
		end,
		["hit"] = function(p_u_249, p_u_250, p251) -- name: hit
			-- upvalues: (copy) p_u_94, (ref) v_u_8, (copy) v_u_176, (ref) v_u_46, (ref) v_u_9, (ref) v_u_15, (ref) v_u_14, (ref) v_u_4, (copy) v_u_103, (ref) v_u_77, (ref) v_u_59
			local v_u_252 = p_u_249.ability.freeze or 3
			p_u_94.burst("Impact", p_u_250, v_u_8, 0.6)
			local v253 = (v_u_176[p_u_249] or 0) + 1
			v_u_176[p_u_249] = v253
			if (p_u_249.lite and 3 or 8) >= v253 then
				local v_u_254 = p_u_249.lite and 3 or 5
				local v_u_255 = {}
				for v256 = 1, v_u_254 do
					local v257 = v_u_46
					local v258
					if v256 % 2 == 0 then
						v258 = v_u_9
					else
						v258 = v_u_8
					end
					local v259
					if v256 % 2 == 0 then
						v259 = v_u_15
					else
						v259 = v_u_14
					end
					v_u_255[v256] = v257(v258, v259, 0.3, 1.6, v_u_252 + 1)
				end
				local v260 = v_u_4:FindFirstChild("MyEnemies")
				local v_u_261
				if v260 then
					v_u_261 = v260:FindFirstChild("Foe" .. p251)
				else
					v_u_261 = nil
				end
				local v_u_262 = p_u_94.ground(p_u_250, 0) - Vector3.new(0, 0.3, 0)
				local v_u_263 = math.random() * 3.141592653589793 * 2
				local v_u_264 = os.clock()
				p_u_94.runNow(function()
					-- upvalues: (copy) v_u_264, (copy) v_u_261, (copy) v_u_252, (ref) v_u_103, (copy) v_u_255, (copy) p_u_249, (ref) v_u_77, (copy) p_u_250, (copy) v_u_263, (copy) v_u_254, (ref) v_u_59, (copy) v_u_262
					local v265 = os.clock() - v_u_264
					local v266
					if v_u_261 == nil then
						v266 = false
					else
						v266 = v_u_261.Parent == nil
					end
					if v_u_252 <= v265 or v266 then
						v_u_103(v_u_255, 0.7, p_u_249.lite)
						if not v266 then
							v_u_77(p_u_250, 6, 0.6, 10, 0.7)
						end
						return false
					end
					local v267 = v265 / 0.22
					local v268 = math.clamp(v267, 0, 1) - 1
					local v269 = v268 * 2.8 * v268 * v268 + 1 + v268 * 1.8 * v268
					local v270 = (v265 - 0.12) / 0.2
					local v271 = math.clamp(v270, 0, 1)
					local v272 = 0.55 - v271 * v271 * (3 - v271 * 2) * 0.85
					for v273, v274 in v_u_255 do
						local v275 = v_u_263 + (v273 - 1) * 3.141592653589793 * 2 / v_u_254
						local v276 = math.cos(v275)
						local v277 = math.sin(v275)
						local v278 = Vector3.new(v276, 0, v277)
						local v279 = Vector3.new(0, 1, 0) * math.cos(v272) + v278 * math.sin(v272)
						v_u_59(v274, v_u_262 + v278 * 2.1, v279, v278, math.max(v269, 0.05) * 6.2)
					end
					return true
				end)
			end
		end
	}
	local function v_u_292(p280, p281) -- name: along
		local v282 = p280.path
		local v283 = p280.lens
		local v284 = #v282
		if p281 <= 0 then
			return v282[1], (v282[2] - v282[1]).Unit
		elseif v283[v284] <= p281 then
			return v282[v284], (v282[v284] - v282[v284 - 1]).Unit
		else
			local v285 = 1
			while v284 - v285 > 1 do
				local v286 = (v285 + v284) // 2
				if v283[v286] <= p281 then
					v285 = v286
					v286 = v284
				end
				v284 = v286
			end
			local v287 = p281 - v283[v285]
			local v288 = v283[v284] - v283[v285]
			local v289 = v287 / math.max(v288, 0.0001)
			local v290 = v282[v284] - v282[v285]
			local v291 = v282[v285]:Lerp(v282[v284], v289)
			if v290.Magnitude > 0.0001 then
				return v291, v290.Unit
			else
				return v291, Vector3.new(-0, -1, -0)
			end
		end
	end
	local function v_u_347(p293, p294, p295) -- name: newDragon
		-- upvalues: (copy) p_u_94, (ref) v_u_34, (ref) v_u_13, (ref) v_u_11, (ref) v_u_10, (ref) v_u_14, (ref) v_u_15, (ref) v_u_1, (ref) v_u_38, (ref) v_u_9, (ref) v_u_46, (ref) v_u_68
		local v296 = p293.dir
		local v297 = v296.X
		local v298 = v296.Z
		local v299 = Vector3.new(v297, 0, v298)
		local v300 = v299.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v299.Unit
		local v301 = p_u_94.ground(p294, 0)
		local v302 = v301 + v300 * 30 + Vector3.new(0, 58, 0)
		local v303 = v301 + v300 * 12 + Vector3.new(0, 26, 0)
		local v304 = v301 + Vector3.new(0, 1, 0)
		local v305 = v301 - v300 * 6 - Vector3.new(0, 5, 0)
		local v306 = v301 - v300 * 7 + Vector3.new(0, 17, 0)
		local v307 = (v302 - v303).Unit
		local v308 = {}
		for v309 = 20, 1, -1 do
			local v310 = v302 + v307 * v309 * 4.5
			table.insert(v308, v310)
		end
		local v311 = #v308 + 1
		for v312 = 0, 24 do
			local v313 = v312 / 24
			local v314 = 1 - v313
			local v315 = v302 * v314 * v314 + v303 * 2 * v314 * v313 + v304 * v313 * v313
			table.insert(v308, v315)
		end
		local v316 = #v308
		for v317 = 1, 16 do
			local v318 = v317 / 16
			local v319 = 1 - v318
			local v320 = v304 * v319 * v319 + v305 * 2 * v319 * v318 + v306 * v318 * v318
			table.insert(v308, v320)
		end
		local v321 = { 0 }
		for v322 = 2, #v308 do
			v321[v322] = v321[v322 - 1] + (v308[v322] - v308[v322 - 1]).Magnitude
		end
		local v323 = p293.lite and 8 or 14
		local v324 = {}
		local v325 = {}
		local v326 = {}
		for v327 = 1, v323 do
			local v328 = (1 - (v327 - 1) * 0.66 / v323) * 5.4 + 0.5
			local v329 = v_u_34
			local v330 = v328 * 0.82
			local v331 = Vector3.new(v328, v330, 4.784999999999999)
			local v332 = CFrame.new(v301 - Vector3.new(0, 80, 0))
			local v333
			if v327 % 3 == 0 then
				v333 = v_u_13
			elseif v327 % 2 == 0 then
				v333 = v_u_11
			else
				v333 = v_u_10
			end
			local v334
			if v327 % 2 == 1 then
				v334 = v_u_14
			else
				v334 = v_u_15
			end
			local v335 = v329(v331, v332, v333, v334)
			v_u_1:AddItem(v335, p295)
			v325[v327] = v335
			v326[v327] = v328
			if p293.lite or (v327 % 2 ~= 1 or v327 >= v323) then
				continue
			end
			local v336 = v_u_38(v_u_9, v_u_14)
			local v337 = v328 * 0.7
			local v338 = v328 * 1.1
			v336.Size = Vector3.new(0.3, v337, v338)
			v_u_1:AddItem(v336, p295)
			table.insert(v324, v336)
		end
		local v339 = p293.lite and 2 or 5
		local v340 = {}
		for _, v341 in { -1, 1 } do
			for v342 = 1, v339 do
				local v343 = v_u_46
				local v344
				if v342 % 2 == 1 then
					v344 = v_u_9
				else
					v344 = v_u_10
				end
				local v345
				if v342 % 2 == 1 then
					v345 = v_u_15
				else
					v345 = v_u_14
				end
				local v346 = {
					["s"] = v343(v344, v345, 0.6, 5, p295),
					["side"] = v341,
					["k"] = v342
				}
				table.insert(v340, v346)
			end
		end
		return {
			["head"] = v_u_68(11, p295),
			["segs"] = v325,
			["widths"] = v326,
			["fins"] = v324,
			["wings"] = v340,
			["path"] = v308,
			["lens"] = v321
		}, v321[v311], v321[v316]
	end
	local function v_u_392(p348, p349, p350, p351, p352) -- name: poseDragon
		-- upvalues: (copy) v_u_292, (ref) v_u_59
		local v353, v354 = v_u_292(p348, p349)
		if p352 then
			v354 = v354:Lerp(p352, 0.85)
		end
		local v355 = v354.Magnitude <= 0.001 and Vector3.new(-0, -1, -0) or v354.Unit
		local v356 = v355.Y
		local v357
		if math.abs(v356) > 0.97 then
			local v358 = v355:Cross(Vector3.new(1, 0, 0))
			local v359 = v358.X
			local v360 = v358.Z
			local v361 = Vector3.new(v359, 0, v360)
			v357 = v361.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v361.Unit
		else
			v357 = Vector3.new(0, 1, 0)
		end
		p348.head.CFrame = CFrame.lookAt(v353, v353 + v355, v357)
		local v362 = CFrame.lookAt(v353, v353 + v355, v357)
		local v363 = 1
		for v364, v365 in p348.segs do
			local v366, v367 = v_u_292(p348, p349 - 4.95 - (v364 - 0.5) * 3.3)
			local v368 = v353 - v366
			if v368.Magnitude > 0.001 then
				v367 = v368.Unit
			end
			local v369 = v367.Y
			local v370
			if math.abs(v369) > 0.97 then
				local v371 = v367:Cross(Vector3.new(1, 0, 0))
				local v372 = v371.X
				local v373 = v371.Z
				local v374 = Vector3.new(v372, 0, v373)
				v370 = v374.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v374.Unit
			else
				v370 = Vector3.new(0, 1, 0)
			end
			local v375 = CFrame.lookAt(v366, v366 + v367, v370)
			v365.CFrame = v375
			if v364 == 1 then
				v362 = v375
			end
			local v376 = p348.fins[v363]
			if v364 % 2 == 1 and v376 then
				local v377 = p348.widths[v364]
				v376.CFrame = v375 * CFrame.new(0, v377 * 0.62, v377 * 0.2)
				v363 = v363 + 1
			end
			v353 = v366
		end
		local v378 = v362.LookVector
		local v379 = v362.RightVector
		local v380 = v362.UpVector
		local v381 = v362.Position + v380 * 2.4
		for _, v382 in p348.wings do
			local v383 = v382.k
			local v384 = ((v383 - 1) * 0.32 + 0.15) * (1.6 - p350 * 0.75)
			local v385 = p351 * 0.5 + 0.25 + (1 - p350) * 0.15
			local v386 = ((v379 * v382.side * math.cos(v384) - v378 * math.sin(v384)) * math.cos(v385) + v380 * math.sin(v385)).Unit
			local v387 = (1 - (v383 - 1) * 0.17) * 20 * (p350 * 0.55 + 0.45)
			local v388 = v386:Cross(v378)
			local v389 = v_u_59
			local v390 = v382.s
			local v391 = v381 + v379 * v382.side * 1.2
			if v388.Magnitude <= 0.001 then
				v388 = v380
			end
			v389(v390, v391, v386, v388, v387)
		end
	end
	local function v_u_403(p393, p394) -- name: dragonGone
		-- upvalues: (copy) p_u_94, (ref) v_u_8, (ref) v_u_9, (ref) v_u_13, (ref) v_u_12, (copy) v_u_103, (ref) v_u_77
		local v395 = p393.head.Position
		p393.head:Destroy()
		for v396, v397 in p393.segs do
			if not p394 and v396 % 3 == 1 then
				local v398 = { v_u_8, v_u_9, v_u_13 }
				p_u_94.chunks(v397.Position, v398, 3, 26, 1.3, 0.9, true, 0.5)
			end
			if v396 % 4 == 1 then
				p_u_94.glint(v397.Position, v_u_12, 5, 0.22)
			end
			v397:Destroy()
		end
		for _, v399 in p393.fins do
			v399:Destroy()
		end
		local v400 = {}
		for _, v401 in p393.wings do
			local v402 = v401.s
			table.insert(v400, v402)
		end
		v_u_103(v400, 2, p394)
		v_u_77(v395, p394 and 10 or 30, 1.6, 30, 1.3)
	end
	local function v_u_410(p404) -- name: freezeDragon
		-- upvalues: (ref) v_u_15, (ref) v_u_5, (ref) v_u_9, (ref) v_u_12, (ref) v_u_84
		for _, v405 in p404.segs do
			v405.Material = v_u_15
			v405.Reflectance = 0.25
			local v406 = {
				["Color"] = v_u_9
			}
			v_u_5.tween(v405, 0.3, v406)
		end
		for _, v407 in p404.wings do
			local v408 = {
				["Color"] = v_u_12
			}
			v_u_5.tween(v407.s.a, 0.3, v408)
			local v409 = {
				["Color"] = v_u_12
			}
			v_u_5.tween(v407.s.b, 0.3, v409)
		end
		v_u_84(p404.head.Position, 6, 3, 10)
	end
	local v_u_411 = {}
	setmetatable(v_u_411, {
		["__mode"] = "k"
	})
	local function v_u_446(p_u_412, p413, p_u_414) -- name: glacier
		-- upvalues: (copy) p_u_94, (ref) v_u_46, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (ref) v_u_14, (ref) v_u_59, (copy) v_u_103, (ref) v_u_5, (ref) v_u_7, (ref) v_u_6
		local v_u_415 = p_u_412.ability.radius
		local v_u_416 = p_u_94.ground(p413, 0)
		local v_u_417 = {}
		local function v435(p418, p419, p420, p421, p422) -- name: ring
			-- upvalues: (copy) v_u_417, (ref) v_u_46, (ref) v_u_9, (ref) v_u_10, (ref) v_u_15, (ref) v_u_14, (copy) p_u_414, (copy) v_u_416
			local v423 = math.random() * 3.141592653589793 * 2
			for v424 = 1, p418 do
				local v425 = v423 + (v424 - 1) * 3.141592653589793 * 2 / p418 + (math.random() - 0.5) * 0.3
				local v426 = math.cos(v425)
				local v427 = math.sin(v425)
				local v428 = Vector3.new(v426, 0, v427)
				local v429 = p421 + (math.random() - 0.5) * 0.2
				local v430 = v_u_417
				local v431 = {}
				local v432 = v_u_46
				local v433
				if v424 % 2 == 0 then
					v433 = v_u_9
				else
					v433 = v_u_10
				end
				local v434
				if v424 % 2 == 0 then
					v434 = v_u_15
				else
					v434 = v_u_14
				end
				v431.s = v432(v433, v434, 1.5, 4.2, p_u_414 + 1)
				v431.base = v_u_416 + v428 * p419 * (0.9 + math.random() * 0.2) - Vector3.new(0, 1.2, 0)
				v431.dir = Vector3.new(0, 1, 0) * math.cos(v429) + v428 * math.sin(v429)
				v431.face = v428:Cross(Vector3.new(0, 1, 0))
				v431.len = p420 * (0.8 + math.random() * 0.4)
				v431.at = p422 + v424 % 3 * 0.025
				table.insert(v430, v431)
			end
		end
		v435(3, 2.2, 15, 0.12, 0)
		v435(p_u_412.lite and 4 or 7, v_u_415 * 0.38, 12, 0.32, 0.03)
		v435(p_u_412.lite and 5 or 11, v_u_415 * 0.78, 8.5, 0.5, 0.1)
		local v_u_436 = os.clock()
		p_u_94.runNow(function()
			-- upvalues: (copy) v_u_436, (copy) v_u_417, (ref) v_u_59
			local v437 = os.clock() - v_u_436
			for _, v438 in v_u_417 do
				local v439 = (v437 - v438.at) / 0.16
				local v440 = math.clamp(v439, 0, 1) - 1
				local v441 = v440 * 2.8 * v440 * v440 + 1 + v440 * 1.8 * v440
				v_u_59(v438.s, v438.base, v438.dir, v438.face, v438.len * math.max(v441, 0.03))
			end
			return v437 < 0.35
		end)
		p_u_94.after(p_u_414, function()
			-- upvalues: (copy) v_u_417, (ref) v_u_103, (copy) p_u_412, (ref) v_u_5, (copy) v_u_416, (ref) v_u_9, (copy) v_u_415, (ref) v_u_7, (ref) v_u_6
			local v442 = {}
			for _, v443 in v_u_417 do
				local v444 = v443.s
				table.insert(v442, v444)
			end
			v_u_103(v442, 2, p_u_412.lite)
			v_u_5.ring(v_u_416, v_u_9, v_u_415 * 1.3, 0.5, v_u_7.Ring)
			local v445 = {
				["at"] = nil,
				["volume"] = 0.7,
				["at"] = v_u_416
			}
			v_u_6.play("Crit", v445)
		end)
	end
	v95.hyorinmaru_r = {
		["cast"] = function(p447) -- name: cast
			-- upvalues: (copy) p_u_94, (ref) v_u_8, (ref) v_u_9, (ref) v_u_93
			p_u_94.skillCast(p447, v_u_8, true)
			p_u_94.glint(p447.eye, v_u_9, 5 * p447.size, 0.25)
			if p447.mine then
				v_u_93(Color3.fromRGB(212, 238, 255), 0.04, 0.12, 0.2, 2, 0.5)
			end
		end,
		["windup"] = function(p_u_448, p449, p450) -- name: windup
			-- upvalues: (copy) v_u_347, (copy) v_u_411, (copy) p_u_94, (ref) v_u_9, (ref) v_u_8, (copy) v_u_403, (copy) v_u_392, (copy) v_u_410
			local v_u_451 = p450 + 0.5 + 0.75 + 0.3 + 1.5
			local v_u_452, v_u_453, v_u_454 = v_u_347(p_u_448, p449, v_u_451)
			local v_u_455 = {
				["dragon"] = nil,
				["landed"] = nil,
				["dragon"] = v_u_452
			}
			v_u_411[p_u_448] = v_u_455
			local v_u_456 = math.max(p450, 0.06)
			p_u_94.streak(v_u_452.head, v_u_9, v_u_8, 4.5, 0.4)
			if not p_u_448.lite then
				p_u_94.streak(v_u_452.segs[#v_u_452.segs], v_u_9, v_u_8, 1.6, 0.35)
			end
			if p_u_448.mine then
				p_u_94.light(v_u_452.head, v_u_8, 40)
			end
			local v_u_457 = os.clock()
			local v_u_458 = false
			p_u_94.runNow(function()
				-- upvalues: (copy) v_u_457, (copy) v_u_455, (ref) v_u_458, (ref) v_u_403, (copy) v_u_452, (copy) p_u_448, (copy) v_u_456, (copy) v_u_453, (copy) v_u_454, (ref) v_u_392, (ref) v_u_410, (copy) v_u_451
				local v459 = os.clock()
				local v460 = v459 - v_u_457
				local v461 = v_u_455.landed
				if v_u_458 and (v461 and v459 - v461 >= 1.55) then
					v_u_403(v_u_452, p_u_448.lite)
					return false
				else
					if v461 then
						local v462 = v459 - v461
						local v463 = v_u_454
						local v464 = v_u_452.lens[#v_u_452.lens] - v_u_454
						local v465 = v462 / 0.5
						local v466 = math.clamp(v465, 0, 1)
						local v467 = v463 + v464 * (v466 * v466 * (3 - v466 * 2))
						local v468 = (v462 - 0.2) / 0.35
						local v469 = math.clamp(v468, 0, 1)
						local v470 = v469 * v469 * (3 - v469 * 2)
						local v471 = v462 * 7
						local v472 = math.sin(v471) * 0.6 * v470
						local v473
						if v462 > 0.35 then
							local v474 = p_u_448.dir
							local v475 = v474.X
							local v476 = v474.Z
							local v477 = Vector3.new(v475, 0, v476)
							v473 = (-(v477.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v477.Unit) - Vector3.new(0, 0.35, 0)).Unit
						else
							v473 = nil
						end
						v_u_392(v_u_452, v467, v470, v472, v473)
						if not v_u_458 and v462 >= 1.25 then
							v_u_458 = true
							v_u_410(v_u_452)
						end
					else
						local v478 = v460 / v_u_456
						local v479 = math.clamp(v478, 0, 1)
						local v480 = v_u_453 - 40 + (v_u_454 - v_u_453 + 40) * (v479 * 0.25 + v479 * 0.75 * v479)
						local v481 = v_u_454
						v_u_392(v_u_452, math.min(v480, v481), 0.25, 0.1, nil)
						if v_u_456 + 0.6 < v460 then
							v_u_403(v_u_452, p_u_448.lite)
							return false
						end
					end
					return v460 < v_u_451
				end
			end)
		end,
		["land"] = function(p_u_482, p483) -- name: land
			-- upvalues: (copy) p_u_94, (copy) v_u_411, (copy) v_u_446, (ref) v_u_12, (ref) v_u_8, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_77, (ref) v_u_11, (ref) v_u_84, (ref) v_u_6, (ref) v_u_93
			local v_u_484 = p_u_482.ability.radius
			local v485 = p_u_94.ground(p483)
			local v_u_486 = v_u_411[p_u_482]
			if v_u_486 then
				v_u_486.landed = os.clock()
			end
			v_u_446(p_u_482, p483, 1.55)
			p_u_94.pop(v485 + Vector3.new(0, 2, 0), v_u_12, 3, 34, 0.35)
			p_u_94.pop(v485 + Vector3.new(0, 2, 0), v_u_8, 5, 28, 0.55, 0.35)
			v_u_5.ring(v485, v_u_9, v_u_484 * 1.4, 0.45, v_u_7.Shockwave)
			v_u_5.ring(v485, v_u_8, v_u_484 * 1.9, 0.7, v_u_7.Ring)
			p_u_94.burst("Shockwave", v485 + Vector3.new(0, 0.3, 0), v_u_8, v_u_484 / 12)
			p_u_94.mark(p483, v_u_8, v_u_484 * 1.05, 2.4, v_u_7.Glow, 0.4)
			v_u_77(v485 + Vector3.new(0, 3, 0), p_u_482.lite and 12 or 45, 1.6, 42, 1.5)
			if not p_u_482.lite then
				local v487 = { v_u_8, v_u_9, v_u_11 }
				p_u_94.chunks(v485 + Vector3.new(0, 1, 0), v487, 12, 40, 1.4, 1.2, true)
				p_u_94.spikes(v485 + Vector3.new(0, 2, 0), v_u_9, 10, v_u_484 * 1.1, 0.35, Vector3.new(0, 1, 0), 0.9)
				v_u_84(v485 + Vector3.new(0, 6, 0), 12, 3.5, 22)
			end
			v_u_6.play("Explosion", {
				["at"] = nil,
				["volume"] = 1,
				["at"] = v485
			})
			if p_u_482.mine then
				v_u_5.shake(0.6, 0.5)
				v_u_93(v_u_12, 0.3, 0, 0.03, 0.04, 0.35)
			end
			p_u_94.after(0.6, function()
				-- upvalues: (copy) v_u_486, (ref) v_u_5, (ref) p_u_94, (ref) v_u_9, (copy) v_u_484, (ref) v_u_7, (copy) p_u_482, (ref) v_u_77, (ref) v_u_6
				local v488
				if v_u_486 then
					v488 = v_u_486.dragon.head
				else
					v488 = nil
				end
				if v488 and v488.Parent then
					v_u_5.ring(p_u_94.ground(v488.Position), v_u_9, v_u_484 * 1.2, 0.5, v_u_7.Ring)
					if not p_u_482.lite then
						v_u_77(v488.Position, 16, 1.4, 26, 1)
					end
					v_u_6.play("Burst", {
						["at"] = nil,
						["volume"] = 0.7,
						["at"] = v488.Position
					})
				end
			end)
		end,
		["hit"] = function(_, p489, _) -- name: hit
			-- upvalues: (copy) p_u_94, (ref) v_u_8
			p_u_94.burst("Impact", p489, v_u_8, 0.7)
		end
	}
	return v95
end