local v_u_1 = game:GetService("GroupService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("Lighting")
local v_u_4 = game:GetService("RunService")
local v5 = game:GetService("Players")
local v_u_6 = game:GetService("ReplicatedStorage")
local v_u_7 = game:GetService("SoundService")
local v_u_8 = game:GetService("TweenService")
local v_u_9 = game:GetService("UserInputService")
local v_u_10 = game:GetService("Workspace")
local v_u_11 = require(script.Parent.Gamepad)
local v_u_12 = require(script.Parent.OfferLog)
local v_u_13 = require(script.Parent.Sfx)
local v_u_14 = require(script.Parent.State)
local v_u_15 = require(script.Parent.Store)
local v_u_16 = require(script.Parent.Gifting)
local v_u_17 = require(script.Parent.Tutorial)
local v_u_18 = require(script.Parent.VipPlusCards)
local v_u_19 = require(script.Parent.Ui)
local v_u_20 = require(script.Parent.Events)
local v_u_21 = require(script.Parent.Reveal)
local v_u_22 = require(script.Parent.PetModels)
local v_u_23 = require(script.Parent.PetLooks)
local v_u_24 = require(script.Parent.PetTile)
local v_u_25 = require(script.Parent.Fx.Kit)
local v_u_26 = require(script.Parent.Device)
local v_u_27 = require(script.Parent.LuckLadder)
local v28 = v_u_6.Shared
local v_u_29 = require(v28.Net)
local v_u_30 = require(v28.Logic.Luck)
local v_u_31 = require(v28.Config.Eyes)
local v_u_32 = require(v28.Config.Auras)
local v_u_33 = require(v28.Config.Pets)
local v_u_34 = require(v28.Logic.Fuse)
local v_u_35 = require(v28.Logic.PetLocks)
local v_u_36 = require(v28.Config.Economy)
local v_u_37 = require(v28.Config.Images)
local v_u_38 = require(v28.Config.Products)
local v_u_39 = require(v28.Config.Quests)
local v_u_40 = require(v28.Config.Rewards)
local v_u_41 = require(v28.Config.Daily)
local v_u_42 = require(v28.Config.Packs)
local v_u_43 = require(v28.Config.NoRandom)
local v_u_44 = require(v28.Config.Worlds)
local v_u_45 = require(v28.Config.Plots)
local v_u_46 = require(v28.Config.World)
local v_u_47 = require(v28.Config.Release)
local v_u_48 = require(v28.Logic.Prizes)
local v_u_49 = require(v28.Logic.Economy)
local v_u_50 = require(v28.Logic.Format)
local v_u_51 = require(v28.Logic.BossDrops)
local v_u_52 = {}
local v_u_53 = v5.LocalPlayer
local v_u_54 = table.clone(v_u_37.Iris)
local v_u_55 = nil
local v_u_56 = nil
local v_u_57 = nil
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = {}
local function v_u_61(_) end
function v_u_52.onNotify(p62) -- name: onNotify
	-- upvalues: (ref) v_u_61
	v_u_61 = p62
end
local function v_u_66(p63, p64) -- name: child
	for v65 in string.gmatch(p64, "[^%.]+") do
		p63 = p63:WaitForChild(v65, 10)
		if p63 then
			continue
		end
		error("Menus is missing " .. p64)
	end
	return p63
end
local function v_u_69(p67) -- name: zoom
	-- upvalues: (copy) v_u_10, (copy) v_u_8
	local v68 = v_u_10.CurrentCamera
	if v68 then
		v_u_8:Create(v68, TweenInfo.new(0.3, Enum.EasingStyle.Quint), {
			["FieldOfView"] = p67
		}):Play()
	end
end
function v_u_52.current() -- name: current
	-- upvalues: (ref) v_u_58
	return v_u_58
end
local v_u_70 = nil
local v_u_71 = nil
local v_u_108 = {
	["Store"] = function(p72) -- name: Store
		-- upvalues: (copy) v_u_11
		local v73 = p72:FindFirstChild("Holder", true)
		if v73 then
			return v_u_11.first(v73)
		else
			return nil
		end
	end,
	["Quests"] = function(p74) -- name: Quests
		-- upvalues: (copy) v_u_11
		local v75 = p74:FindFirstChild("List")
		if v75 then
			return v_u_11.first(v75)
		else
			return nil
		end
	end,
	["Auras"] = function(p76) -- name: Auras
		-- upvalues: (copy) v_u_11
		local v77 = p76:FindFirstChild("List")
		if v77 then
			return v_u_11.first(v77)
		else
			return nil
		end
	end,
	["Worlds"] = function(p78) -- name: Worlds
		-- upvalues: (copy) v_u_11
		local v79 = p78:FindFirstChild("List")
		if v79 then
			return v_u_11.first(v79)
		else
			return nil
		end
	end,
	["Pets"] = function(p80) -- name: Pets
		-- upvalues: (copy) v_u_11
		local v81 = p80:FindFirstChild("Grid", true)
		if v81 then
			return v_u_11.first(v81)
		else
			return nil
		end
	end,
	["MyEyes"] = function(p82) -- name: MyEyes
		-- upvalues: (copy) v_u_31, (copy) v_u_14, (copy) v_u_11
		local v83 = p82:FindFirstChild("Grid")
		local v84 = v_u_31.nextLocked(v_u_14.eyes())
		if not (v83 and v84) then
			return nil
		end
		for v85, v86 in v_u_31.list do
			if v86.id ~= v84.id then
				continue
			end
			for _, v87 in v83:GetChildren() do
				if not v87:IsA("GuiObject") or v87.LayoutOrder ~= v85 then
					continue
				end
				local v88 = v87:FindFirstChild("Locked", true)
				if not (v88 and (v88:IsA("GuiObject") and v_u_11.shown(v88))) then
					v88 = nil
				end
				return v88 or v_u_11.first(v87)
			end
		end
		return nil
	end,
	["Daily"] = function(p89) -- name: Daily
		-- upvalues: (copy) v_u_11
		local v90 = p89:FindFirstChild("Holder")
		if v90 then
			return v_u_11.first(v90)
		else
			return nil
		end
	end,
	["Rewards"] = function(p91) -- name: Rewards
		-- upvalues: (copy) v_u_11
		local v92 = p91:FindFirstChild("Holder")
		if v92 then
			return v_u_11.first(v92)
		else
			return nil
		end
	end,
	["Egg"] = function(p93) -- name: Egg
		-- upvalues: (copy) v_u_11
		local v94 = p93:FindFirstChild("Hatch1", true)
		if v94 and (v94:IsA("GuiObject") and v_u_11.shown(v94)) then
			return v94
		else
			return nil
		end
	end,
	["Community"] = function(p95) -- name: Community
		-- upvalues: (copy) v_u_53, (copy) v_u_11
		if v_u_53:GetAttribute("InGroup") == true then
			local v96 = p95:FindFirstChild("Claim", true)
			if not (v96 and (v96:IsA("GuiObject") and v_u_11.shown(v96))) then
				v96 = nil
			end
			if not v96 then
				local v97 = p95:FindFirstChild("Join", true)
				if v97 and (v97:IsA("GuiObject") and v_u_11.shown(v97)) then
					return v97
				end
				v96 = nil
			end
			return v96
		else
			local v98 = p95:FindFirstChild("Join", true)
			if v98 and (v98:IsA("GuiObject") and v_u_11.shown(v98)) then
				return v98
			else
				return nil
			end
		end
	end,
	["Rebirths"] = function(p99) -- name: Rebirths
		-- upvalues: (copy) v_u_11
		local v100 = p99:FindFirstChild("Redeem", true)
		if v100 and (v100:IsA("GuiObject") and v_u_11.shown(v100)) then
			return v100
		else
			return nil
		end
	end,
	["Offline"] = function(p101) -- name: Offline
		-- upvalues: (copy) v_u_11
		local v102 = p101:FindFirstChild("Claim", true)
		if not (v102 and (v102:IsA("GuiObject") and v_u_11.shown(v102))) then
			v102 = nil
		end
		if not v102 then
			local v103 = p101:FindFirstChild("Redeem", true)
			if v103 and (v103:IsA("GuiObject") and v_u_11.shown(v103)) then
				return v103
			end
			v102 = nil
		end
		return v102
	end,
	["Leave"] = function(p104) -- name: Leave
		-- upvalues: (copy) v_u_11
		local v105 = p104:FindFirstChild("Redeem", true)
		if v105 and (v105:IsA("GuiObject") and v_u_11.shown(v105)) then
			return v105
		else
			return nil
		end
	end,
	["Codes"] = function(p106) -- name: Codes
		-- upvalues: (copy) v_u_11
		local v107 = p106:FindFirstChild("TextCode", true)
		if v107 and (v107:IsA("GuiObject") and v_u_11.shown(v107)) then
			return v107
		else
			return nil
		end
	end
}
local function v_u_113(p109) -- name: padStart
	-- upvalues: (ref) v_u_55, (copy) v_u_108, (copy) v_u_11
	local v110 = v_u_55:FindFirstChild(p109)
	if not (v110 and (v110:IsA("Frame") and v110.Visible)) then
		return nil
	end
	local v111 = v_u_108[p109]
	local v112
	if v111 then
		v112 = v111(v110)
	else
		v112 = nil
	end
	return v112 or v_u_11.first(v110)
end
local v_u_114 = {}
local v_u_115 = false
local function v_u_126(p116) -- name: tuck
	-- upvalues: (ref) v_u_115, (copy) v_u_114, (ref) v_u_57, (copy) v_u_8
	if v_u_115 ~= p116 then
		v_u_115 = p116
		local v117 = table.clone(v_u_114)
		local v118 = v_u_57
		if v118 then
			v118 = v_u_57:FindFirstChild("Promo")
		end
		if v118 and v118:IsA("GuiObject") then
			table.insert(v117, v118)
		end
		local v119 = v_u_57
		if v119 then
			v119 = v_u_57:FindFirstChild("LuckLadder")
		end
		if v119 and v119:IsA("GuiObject") then
			table.insert(v117, v119)
		end
		for _, v120 in v117 do
			local v121 = v120:FindFirstChild("Pop") or v120:FindFirstChildOfClass("UIScale")
			if not (v121 and v121:IsA("UIScale")) then
				v121 = Instance.new("UIScale")
				v121.Name = "Pop"
				v121.Parent = v120
			end
			if p116 then
				local v122 = Enum.EasingStyle.Back
				local v123 = Enum.EasingDirection.In
				v_u_8:Create(v121, TweenInfo.new(0.16, v122 or Enum.EasingStyle.Quad, v123 or Enum.EasingDirection.Out), {
					["Scale"] = 0
				}):Play()
			else
				local v124 = Enum.EasingStyle.Back
				local v125 = Enum.EasingDirection.Out
				v_u_8:Create(v121, TweenInfo.new(0.3, v124 or Enum.EasingStyle.Quad, v125 or Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			end
		end
	end
end
function v_u_52.close() -- name: close
	-- upvalues: (ref) v_u_58, (ref) v_u_55, (copy) v_u_8, (ref) v_u_59, (copy) v_u_69, (copy) v_u_126, (copy) v_u_13, (copy) v_u_11, (ref) v_u_70
	local v_u_127 = v_u_58
	if v_u_127 then
		local v_u_128 = v_u_55:FindFirstChild(v_u_127)
		if not (v_u_128 and v_u_128:IsA("Frame")) then
			v_u_128 = nil
		end
		v_u_58 = nil
		if v_u_128 then
			local v_u_129 = v_u_128:FindFirstChild("Open") or v_u_128:FindFirstChildOfClass("UIScale")
			if not (v_u_129 and v_u_129:IsA("UIScale")) then
				v_u_129 = Instance.new("UIScale")
				v_u_129.Name = "Open"
				v_u_129.Parent = v_u_128
			end
			local v130 = Enum.EasingStyle.Quad
			local v131 = Enum.EasingDirection.In
			v_u_8:Create(v_u_129, TweenInfo.new(0.1, v130 or Enum.EasingStyle.Quad, v131 or Enum.EasingDirection.Out), {
				["Scale"] = 0.8
			}):Play()
			task.delay(0.1, function()
				-- upvalues: (ref) v_u_58, (copy) v_u_127, (copy) v_u_128, (copy) v_u_129
				if v_u_58 ~= v_u_127 then
					v_u_128.Visible = false
					v_u_129.Scale = 1
				end
			end)
		end
		v_u_8:Create(v_u_59, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["Size"] = 0
		}):Play()
		v_u_69(70)
		v_u_126(false)
		v_u_13.play("Close")
		v_u_11.capture("menu", false)
		local v132 = v_u_70
		v_u_70 = nil
		local v133 = v_u_11.selected()
		if v132 and (v132.Parent and v_u_11.shown(v132)) then
			v_u_11.select(v132)
		elseif v133 and v133:IsDescendantOf(v_u_55) then
			v_u_11.clear()
		end
	else
		return
	end
end
function v_u_52.open(p_u_134) -- name: open
	-- upvalues: (ref) v_u_58, (copy) v_u_52, (ref) v_u_55, (copy) v_u_60, (copy) v_u_11, (copy) v_u_8, (ref) v_u_59, (copy) v_u_69, (copy) v_u_126, (copy) v_u_13, (ref) v_u_70, (copy) v_u_113
	if v_u_58 == p_u_134 then
		v_u_52.close()
		return
	else
		local v135 = v_u_55:FindFirstChild(p_u_134)
		if not (v135 and v135:IsA("Frame")) then
			v135 = nil
		end
		if v135 then
			if v_u_58 then
				local v136 = v_u_55:FindFirstChild(v_u_58)
				if not (v136 and v136:IsA("Frame")) then
					v136 = nil
				end
				if v136 then
					v136.Visible = false
					local v137 = v136:GetAttribute("Home")
					if typeof(v137) ~= "UDim2" then
						v136:SetAttribute("Home", v136.Position)
						v137 = v136.Position
					end
					v136.Position = v137
					local v138 = v136:FindFirstChild("Open") or v136:FindFirstChildOfClass("UIScale")
					if not (v138 and v138:IsA("UIScale")) then
						v138 = Instance.new("UIScale")
						v138.Name = "Open"
						v138.Parent = v136
					end
					v138.Scale = 1
				end
			end
			v_u_58 = p_u_134
			local v139 = v_u_60[p_u_134]
			if v139 then
				v139()
			end
			local v140 = v135:GetAttribute("Home")
			if typeof(v140) ~= "UDim2" then
				v135:SetAttribute("Home", v135.Position)
				v140 = v135.Position
			end
			local v141
			if v_u_11.tv() then
				v141 = UDim2.fromScale(0, 0.05)
			else
				v141 = UDim2.new()
			end
			v135.Position = v140 + v141
			local v142 = v135:FindFirstChild("Open") or v135:FindFirstChildOfClass("UIScale")
			if not (v142 and v142:IsA("UIScale")) then
				v142 = Instance.new("UIScale")
				v142.Name = "Open"
				v142.Parent = v135
			end
			v142.Scale = 0.72
			v135.Visible = true
			local v143 = Enum.EasingStyle.Back
			local v144 = Enum.EasingDirection.Out
			v_u_8:Create(v142, TweenInfo.new(0.32, v143 or Enum.EasingStyle.Quad, v144 or Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			v_u_8:Create(v_u_59, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Size"] = 24
			}):Play()
			v_u_69(60)
			v_u_126(true)
			v_u_13.play("Open")
			local v145 = v_u_11.selected()
			if v145 and not v145:IsDescendantOf(v_u_55) then
				v_u_70 = v145
			elseif not v145 then
				v_u_70 = nil
			end
			v_u_11.capture("menu", true)
			v_u_11.selectSoon(function()
				-- upvalues: (ref) v_u_58, (copy) p_u_134, (ref) v_u_113
				if v_u_58 == p_u_134 then
					return v_u_113(p_u_134)
				else
					return nil
				end
			end, (p_u_134 == "Egg" or p_u_134 == "Community") and true or p_u_134 == "Worlds")
		end
	end
end
local function v_u_158(p146, p147, p148, p149, p150, p151, p152) -- name: tileOf
	local v153 = p146:FindFirstChild("Tile" .. p147)
	if v153 and v153:IsA("GuiObject") then
		v153.Visible = true
		local v154 = v153:FindFirstChild("Count")
		local v155 = v153:FindFirstChild("Name")
		local v156 = v153:FindFirstChild("Icon")
		if v154 and v154:IsA("TextLabel") then
			v154.Text = p149
		end
		if v155 and v155:IsA("TextLabel") then
			v155.Text = p150
		end
		if v156 and v156:IsA("ImageLabel") then
			v156.Image = p148
		end
		local v157 = v153:FindFirstChildOfClass("UIGradient")
		if v157 then
			v157.Color = ColorSequence.new(p151, p152)
			v157.Rotation = 90
		end
	end
end
local function v_u_192(p159) -- name: ladderCards
	-- upvalues: (copy) v_u_15, (copy) v_u_38, (copy) v_u_158, (copy) v_u_37, (copy) v_u_4, (copy) v_u_10, (copy) v_u_47
	local v160 = v_u_15.pass("ultimate")
	local v161 = p159:FindFirstChild("Pack_pro")
	if v160 and (v160.id ~= 0 and (v161 and not p159:FindFirstChild("Pack_ultimate"))) then
		local v162 = v161:Clone()
		v162.Name = "Pack_ultimate"
		v162.LayoutOrder = 3
		local v163 = 0
		for _, v164 in v_u_38.BUNDLES.ultimate do
			local v165 = v_u_15.pass(v164)
			v163 = v163 + (not v165 and 0 or v165.price)
		end
		local v166 = (1 - v160.price / math.max(v163, 1)) * 100
		local v167 = math.floor(v166)
		for _, v168 in v162:GetChildren() do
			if not v168:IsA("TextLabel") or v168.Name ~= "Title" then
				continue
			end
			v168.Text = v168.Rotation == 0 and v168.Text == "PRO PACK" and "ULTIMATE OP BUNDLE" or ("SAVE %*%%!"):format(v167)
		end
		local v169 = v162:FindFirstChild("Purchase1")
		if v169 then
			v169:SetAttribute("Ui-Pass", "ultimate")
			v169:SetAttribute("Ui-Pack", nil)
		end
		local v170 = v162:FindFirstChild("Tiles")
		if v170 then
			local v171 = { Color3.fromRGB(255, 226, 60), Color3.fromRGB(255, 150, 0) }
			local v172 = { Color3.fromRGB(206, 120, 255), Color3.fromRGB(132, 40, 230) }
			local v173 = { Color3.fromRGB(255, 150, 90), Color3.fromRGB(222, 52, 52) }
			local v174 = { Color3.fromRGB(69, 200, 255), Color3.fromRGB(0, 128, 255) }
			v_u_158(v170, 1, v_u_37.Train.train4, "x4", "Training Areas", v174[1], v174[2])
			v_u_158(v170, 2, v_u_37.Pet.ten_tails, "", "Ten Tails", v173[1], v173[2])
			v_u_158(v170, 3, v_u_37.Aura.rainbow_chakra, "", "Rainbow Aura", v172[1], v172[2])
			v_u_158(v170, 4, v_u_37.Iris.six_paths_sage, "", "Six Paths Sage", v173[1], v173[2])
			v_u_158(v170, 5, "rbxassetid://122420734012429", "", "ULTIMATE Title", v171[1], v171[2])
		end
		v162.Parent = p159
	end
	local v175 = v_u_15.product("boostWins")
	local v176 = p159:FindFirstChild("Product_boost2")
	if v175 and (v175.id ~= 0 and (v176 and not p159:FindFirstChild("Product_boostWins"))) then
		local v177 = v176:Clone()
		v177.Name = "Product_boostWins"
		local v178 = v177:FindFirstChild("Title")
		if v178 and v178:IsA("TextLabel") then
			v178.Text = v175.name
		end
		local v179 = v177:FindFirstChild("Icon")
		if v179 and v179:IsA("ImageLabel") then
			v179.Image = v_u_37.Icon.BoostWins or v179.Image
		end
		local v180 = v177:FindFirstChild("Purchase")
		if v180 then
			v180:SetAttribute("Ui-Product", "boostWins")
		end
		v177.Parent = p159
	end
	local v181 = p159:FindFirstChild("Pass_autoRebirth")
	for v182, v183 in {
		{
			["key"] = "vip",
			["icon"] = nil,
			["a"] = nil,
			["b"] = nil,
			["icon"] = v_u_37.Aura.vip_aura,
			["a"] = Color3.fromRGB(255, 226, 60),
			["b"] = Color3.fromRGB(255, 150, 0)
		},
		{
			["key"] = "autoWin",
			["icon"] = nil,
			["a"] = nil,
			["b"] = nil,
			["icon"] = v_u_37.Icon.Trophy,
			["a"] = Color3.fromRGB(255, 112, 112),
			["b"] = Color3.fromRGB(205, 32, 64)
		}
	} do
		local v184 = v183.key
		local v185 = v_u_15.pass(v184)
		local v186 = v185 ~= nil and (v185.id == 0 and v_u_4:IsStudio())
		if v186 then
			v186 = v_u_10:GetAttribute("DevStoreCards") == true
		end
		if not v_u_47.on(v_u_47.PERKS) or (not v186 or (not v185 or (not v181 or (not v181:IsA("GuiObject") or p159:FindFirstChild("Pass_" .. v184))))) then
			continue
		end
		local v187 = v181:Clone()
		v187.Name = "Pass_" .. v184
		v187.LayoutOrder = v181.LayoutOrder + v182
		local v188 = v187:FindFirstChild("Title")
		if v188 and v188:IsA("TextLabel") then
			v188.Text = v185.name
		end
		local v189 = v187:FindFirstChild("Icon")
		if v189 and v189:IsA("ImageLabel") then
			v189.Image = v183.icon
		end
		local v190 = v187:FindFirstChildOfClass("UIGradient")
		if v190 then
			v190.Color = ColorSequence.new(v183.a, v183.b)
		end
		local v191 = v187:FindFirstChild("Purchase")
		if v191 then
			v191:SetAttribute("Ui-Pass", v184)
		end
		v187.Parent = p159
	end
end
local function v_u_208() -- name: bindStore
	-- upvalues: (ref) v_u_55, (copy) v_u_192, (copy) v_u_18, (copy) v_u_15, (copy) v_u_16, (copy) v_u_53
	local v193 = v_u_55:FindFirstChild("Store")
	if not (v193 and v193:IsA("Frame")) then
		v193 = nil
	end
	if v193 then
		local v194 = v193:FindFirstChild("Holder", true)
		if v194 then
			v_u_192(v194)
			v_u_18.add(v194)
		end
		local v_u_195 = {}
		v_u_15.pricesChanged:Connect(function()
			-- upvalues: (copy) v_u_195
			for _, v196 in v_u_195 do
				v196()
			end
		end)
		for _, v197 in v193:GetDescendants() do
			if not v197:IsA("GuiButton") then
				continue
			end
			local v_u_198 = v197:GetAttribute("Ui-Pass")
			local v_u_199 = v197:GetAttribute("Ui-Product")
			local v_u_200 = v197:FindFirstChild("PriceTag")
			if type(v_u_198) == "string" then
				local v_u_201 = v_u_15.pass(v_u_198)
				if v_u_201 and (v_u_200 and v_u_200:IsA("TextLabel")) then
					local function v202() -- name: show
						-- upvalues: (copy) v_u_200, (ref) v_u_15, (copy) v_u_201
						v_u_200.Text = v_u_15.priceText(v_u_15.passPrice(v_u_201))
					end
					table.insert(v_u_195, v202)
					task.spawn(v202)
				end
				v197.Activated:Connect(function()
					-- upvalues: (ref) v_u_16, (copy) v_u_198, (ref) v_u_15
					if not v_u_16.storeBuy(v_u_198) then
						v_u_15.buyPass(v_u_198)
					end
				end)
				local v_u_203 = v197.Parent
				if v_u_203 then
					v_u_203 = v_u_203:FindFirstChild("Owned")
				end
				if not (v_u_201 and (v_u_203 and v_u_203:IsA("GuiObject"))) then
					continue
				end
				local v_u_204 = v_u_201.key
				local function v205() -- name: show
					-- upvalues: (copy) v_u_203, (ref) v_u_53, (copy) v_u_204
					v_u_203.Visible = v_u_53:GetAttribute("Pass_" .. v_u_204) == true
				end
				v_u_53:GetAttributeChangedSignal("Pass_" .. v_u_204):Connect(v205)
				v_u_203.Visible = v_u_53:GetAttribute("Pass_" .. v_u_204) == true
			else
				if type(v_u_199) ~= "string" then
					continue
				end
				local v_u_206 = v_u_15.product(v_u_199)
				if v_u_206 and (v_u_200 and v_u_200:IsA("TextLabel")) then
					local function v207() -- name: show
						-- upvalues: (copy) v_u_200, (ref) v_u_15, (copy) v_u_206
						v_u_200.Text = v_u_15.priceText(v_u_206.price)
					end
					table.insert(v_u_195, v207)
					task.spawn(v207)
				end
				v197.Activated:Connect(function()
					-- upvalues: (ref) v_u_16, (copy) v_u_199, (ref) v_u_15
					if not v_u_16.storeBuy(v_u_199) then
						v_u_15.buyProduct(v_u_199)
					end
				end)
			end
		end
	end
end
local function v_u_225() -- name: arrangeStore
	-- upvalues: (ref) v_u_55, (copy) v_u_14, (copy) v_u_45, (copy) v_u_31, (copy) v_u_50
	local v209 = v_u_55:FindFirstChild("Store")
	if not (v209 and v209:IsA("Frame")) then
		v209 = nil
	end
	if v209 then
		v209 = v209:FindFirstChild("Holder", true)
	end
	if not v209 then
		return
	end
	local v210 = v_u_14.number("World", 1)
	local v211 = v_u_45.forWorld(v210)
	for _, v212 in v209:GetChildren() do
		if not v212:IsA("GuiObject") then
			continue
		end
		local v213 = v212:GetAttribute("Ui-World")
		if type(v213) == "number" then
			for _, v214 in { "Line1", "Line2" } do
				local v215 = v212:FindFirstChild(v214)
				if not v215 or (not v215:IsA("TextLabel") or v215.Position.X.Scale + v215.Size.X.Scale <= 0.73) then
					continue
				end
				v215.Size = UDim2.new(0.73 - v215.Position.X.Scale, 0, v215.Size.Y.Scale, v215.Size.Y.Offset)
			end
		end
		local v216, v217
		if type(v213) == "number" then
			local v218
			if v213 ~= 0 then
				v218 = v212:GetAttribute("Ui-Slot")
				v212.Visible = v213 <= v210
				v212.LayoutOrder = 10 + (v210 - v213) * 10 + (type(v218) ~= "number" and 0 or v218)
				goto l4
			end
			local v219 = v_u_31.everyWorldShowcase()
			if v219 then
				local v220 = v212:FindFirstChild("Line1")
				if v219 and (v220 and v220:IsA("TextLabel")) then
					v220.Text = "x" .. v_u_50.short(v_u_31.multIn(v219, v210)) .. " CHAKRA"
					v213 = v210
				else
					v213 = v210
				end
				v218 = v212:GetAttribute("Ui-Slot")
				v212.Visible = v213 <= v210
				v212.LayoutOrder = 10 + (v210 - v213) * 10 + (type(v218) ~= "number" and 0 or v218)
				::l4::
				v216 = v212:GetAttribute("Ui-Train")
				v217 = v212:FindFirstChild("Mult")
				if type(v216) ~= "string" or not (v217 and v217:IsA("TextLabel")) then
					continue
				end
				for v223, v224 in v211 do
					if v224.pass ~= v216 then
						continue
					end
					v217.Text = "x" .. v_u_50.short(v224.mult) .. " CHAKRA"
				end
			else
				v212.Visible = false
			end
		else
			v216 = v212:GetAttribute("Ui-Train")
			v217 = v212:FindFirstChild("Mult")
			if type(v216) ~= "string" or not (v217 and v217:IsA("TextLabel")) then
				continue
			end
			for v223, v224 in v211 do
				if v224.pass ~= v216 then
					continue
				end
				v217.Text = "x" .. v_u_50.short(v224.mult) .. " CHAKRA"
			end
		end
	end
end
local function v_u_231() -- name: fitStore
	-- upvalues: (ref) v_u_55
	local v_u_226 = v_u_55:FindFirstChild("Store")
	if not (v_u_226 and v_u_226:IsA("Frame")) then
		v_u_226 = nil
	end
	if v_u_226 then
		v_u_226 = v_u_226:FindFirstChild("MainScrollingFrame", true)
	end
	local v_u_227
	if v_u_226 then
		v_u_227 = v_u_226:FindFirstChild("Holder")
	else
		v_u_227 = v_u_226
	end
	local v_u_228
	if v_u_227 then
		v_u_228 = v_u_227:FindFirstChildWhichIsA("UIListLayout")
	else
		v_u_228 = v_u_227
	end
	if v_u_226 and (v_u_226:IsA("ScrollingFrame") and (v_u_227 and (v_u_227:IsA("GuiObject") and v_u_228))) then
		v_u_228:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(function() -- name: fit
			-- upvalues: (copy) v_u_228, (copy) v_u_227, (copy) v_u_226
			local v229 = v_u_228.AbsoluteContentSize.Y + 24
			v_u_227.Size = UDim2.new(1, 0, 0, v229)
			v_u_226.CanvasSize = UDim2.fromOffset(0, v229)
		end)
		local v230 = v_u_228.AbsoluteContentSize.Y + 24
		v_u_227.Size = UDim2.new(1, 0, 0, v230)
		v_u_226.CanvasSize = UDim2.fromOffset(0, v230)
	end
end
local function v_u_238(p_u_232, p_u_233) -- name: fitCanvas
	if p_u_232:IsA("ScrollingFrame") then
		local v_u_234 = p_u_232:FindFirstChildWhichIsA("UIGridStyleLayout")
		if v_u_234 then
			local v_u_235 = p_u_232:FindFirstChildOfClass("UIPadding")
			local function v237() -- name: fit
				-- upvalues: (copy) v_u_235, (copy) p_u_232, (copy) v_u_234, (copy) p_u_233
				local v236 = not v_u_235 and 0 or v_u_235.PaddingTop.Offset + v_u_235.PaddingBottom.Offset + (v_u_235.PaddingTop.Scale + v_u_235.PaddingBottom.Scale) * p_u_232.AbsoluteWindowSize.Y
				p_u_232.AutomaticCanvasSize = Enum.AutomaticSize.None
				p_u_232.CanvasSize = UDim2.fromOffset(0, v_u_234.AbsoluteContentSize.Y + v236 + (p_u_233 or 12))
			end
			v_u_234:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(v237)
			v237()
		end
	else
		return
	end
end
local v_u_239 = Color3.fromRGB(58, 255, 14)
local v_u_240 = Color3.fromRGB(40, 196, 14)
local v_u_241 = Color3.fromRGB(150, 152, 165)
local v_u_242 = Color3.fromRGB(90, 92, 104)
local v_u_243 = Color3.fromRGB(69, 200, 255)
local v_u_244 = Color3.fromRGB(0, 128, 255)
local v_u_245 = table.clone(v_u_37.Icon)
local v_u_246 = table.clone(v_u_37.Aura)
local v_u_247 = v_u_55
local v_u_248 = v_u_59
local v_u_249 = v_u_61
local v_u_250 = v_u_70
local v_u_251 = v_u_58
local v_u_252 = v_u_57
local v_u_253 = {}
local function v_u_256(p254) -- name: clearList
	for _, v255 in p254:GetChildren() do
		if not v255:IsA("GuiObject") then
			continue
		end
		v255:Destroy()
	end
end
local function v_u_273(p_u_257, p_u_258, p_u_259, p_u_260, p_u_261) -- name: fixGrid
	-- upvalues: (copy) v_u_238
	if p_u_257:IsA("ScrollingFrame") then
		local v_u_262 = p_u_257:FindFirstChildWhichIsA("UIGridLayout")
		if v_u_262 then
			local function v272() -- name: size
				-- upvalues: (copy) p_u_257, (copy) v_u_262, (copy) p_u_258, (copy) p_u_259, (copy) p_u_260, (copy) p_u_261
				local v263 = p_u_257.AbsoluteWindowSize.Y
				if v263 > 0 then
					local v264 = v_u_262
					local v265 = UDim2.new
					local v266 = p_u_258
					local v267 = v263 * p_u_259
					v264.CellSize = v265(v266, 0, 0, (math.floor(v267)))
					local v268 = v_u_262
					local v269 = UDim2.new
					local v270 = p_u_260
					local v271 = v263 * p_u_261
					v268.CellPadding = v269(v270, 0, 0, (math.floor(v271)))
				end
			end
			p_u_257:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(v272)
			v272()
			v_u_238(p_u_257, 48)
		end
	else
		return
	end
end
for v274, v275 in v_u_41.weeks do
	for _, v276 in v275 do
		if v276.kind ~= "aura" or not v276.aura then
			continue
		end
		v_u_253[v276.aura] = v274
	end
end
local function v284(p277) -- name: rainbowSequence
	local v278 = {}
	for v279 = 0, 6 do
		local v280 = Color3.fromHSV(v279 / 6 * 0.83, 0.85, 1)
		local v281 = ColorSequenceKeypoint.new
		local v282 = v279 / 6
		local v283 = Color3.new(0, 0, 0)
		table.insert(v278, v281(v282, v280:Lerp(v283, p277)))
	end
	return ColorSequence.new(v278)
end
local v_u_285 = v284(0.1)
local v_u_286 = v284(0.5)
local v_u_287 = v_u_245.Trophy or v_u_245.Wins
local function v_u_288() -- name: prizeProgress
	-- upvalues: (copy) v_u_48, (copy) v_u_14
	return v_u_48.progress(v_u_14.number("BestStage"), v_u_14.number("BestStage2"), v_u_14.number("BestStage3"), v_u_14.number("BestStage4"), v_u_14.number("BestStage5"), v_u_14.number("BestStage6"), v_u_14.number("BestStage7"), v_u_14.number("BestStage8"))
end
local function v_u_295(p289) -- name: prizeIcon
	-- upvalues: (copy) v_u_288, (copy) v_u_48, (copy) v_u_245, (copy) v_u_287, (copy) v_u_246
	if p289.kind == "egg" then
		local _, v290 = v_u_288()
		local v291 = v_u_48.eggFor(p289, v290)
		local v292 = ""
		for v293 in string.gmatch(v291, "[^_]+") do
			v292 = v292 .. string.upper((string.sub(v293, 1, 1))) .. string.sub(v293, 2)
		end
		return v_u_245["Egg" .. v292] or v_u_245.EggNormal or "rbxassetid://73989013612789"
	elseif p289.kind == "boost" then
		local v294
		if p289.boost == "wins" then
			v294 = v_u_245.BoostWins
			if not v294 then
				return v_u_287
			end
		else
			v294 = v_u_245.BoostChakra or v_u_245.Chakra
		end
		return v294
	elseif p289.kind == "aura" then
		return v_u_246[p289.aura or ""] or v_u_245.Star
	elseif p289.kind == "pet" then
		return v_u_245.Star
	else
		return v_u_287
	end
end
local function v_u_303(p296) -- name: prizeText
	-- upvalues: (copy) v_u_288, (copy) v_u_33, (copy) v_u_48, (copy) v_u_32
	local v297, v298 = v_u_288()
	if p296.kind == "egg" then
		local v299 = v_u_33.eggById[v_u_48.eggFor(p296, v298)]
		return ("x%* %*"):format(p296.count or 1, not v299 and "Egg" or v299.name)
	elseif p296.kind == "aura" then
		local v300 = v_u_32.byId[p296.aura or ""]
		return not v300 and "Aura" or v300.name
	elseif p296.kind == "pet" then
		local v301 = v_u_33.byId[v_u_48.petFor(p296, v298) or ""]
		local v302 = not v301 and "Pet" or v301.name
		if (p296.count or 1) > 1 then
			return ("x%* %*"):format(p296.count, v302)
		else
			return v302
		end
	else
		return v_u_48.label(p296, v297, v298)
	end
end
local v_u_304 = {
	["egg"] = { Color3.fromRGB(206, 120, 255), Color3.fromRGB(132, 40, 230) },
	["trophies"] = { Color3.fromRGB(255, 226, 60), Color3.fromRGB(255, 150, 0) },
	["chakra"] = { Color3.fromRGB(69, 200, 255), Color3.fromRGB(0, 128, 255) },
	["wins"] = { Color3.fromRGB(120, 255, 90), Color3.fromRGB(30, 190, 60) },
	["pet"] = { Color3.fromRGB(255, 225, 0), Color3.fromRGB(255, 110, 6) }
}
local function v_u_336() -- name: fillPacks
	-- upvalues: (ref) v_u_247, (copy) v_u_288, (copy) v_u_42, (copy) v_u_15, (copy) v_u_43, (copy) v_u_48, (copy) v_u_33, (copy) v_u_66, (copy) v_u_22, (copy) v_u_304, (copy) v_u_50, (copy) v_u_303, (copy) v_u_295
	local v305 = v_u_247:FindFirstChild("Store")
	if not (v305 and v305:IsA("Frame")) then
		v305 = nil
	end
	if v305 then
		local v306, v307 = v_u_288()
		for v308, v312 in v_u_42 do
			local v310 = v305:FindFirstChild("Pack_" .. v308, true)
			if v310 then
				v310 = v310:FindFirstChild("Tiles")
			end
			if not v310 then
				continue
			end
			for _, v311 in v310:GetChildren() do
				if not v311:IsA("GuiObject") then
					continue
				end
				v311.Visible = false
			end
			if v_u_15.randomRestricted() then
				local v312 = v_u_43.pack(v308, v312)
			end
			for v313, v314 in v312 do
				local v315 = v310:FindFirstChild("Tile" .. v313)
				if not (v315 and v315:IsA("GuiObject")) then
					continue
				end
				v315.Visible = true
				local v316 = v315:FindFirstChild("PetView", true)
				if v316 then
					v316:Destroy()
				end
				if v314.kind == "pet" and v314.rarity then
					local v317 = v_u_48.petFor(v314, v307)
					local v318 = v_u_33.byId[v317 or ""]
					v_u_66(v315, "Count").Text = ("x%*"):format(v314.count or 1)
					v_u_66(v315, "Name").Text = not v318 and "Pet" or v318.name
					local v319 = v_u_66(v315, "Icon")
					v319.Image = ""
					local v320 = Instance.new("ViewportFrame")
					v320.Name = "PetView"
					v320.BackgroundTransparency = 1
					v320.Size = UDim2.fromScale(1.6, 1.6)
					v320.Position = UDim2.fromScale(0.5, 0.5)
					v320.AnchorPoint = Vector2.new(0.5, 0.5)
					v320.ZIndex = v319.ZIndex
					v320.Ambient = Color3.fromRGB(200, 200, 210)
					v320.Parent = v319
					local v321 = v_u_22.build(v317 or "")
					if v321 then
						v_u_22.show(v320, v321, true)
					end
					local v322 = v_u_304.pet[1]
					local v323 = v_u_304.pet[2]
					local v324 = v315:FindFirstChildOfClass("UIGradient")
					if not v324 then
						continue
					end
					v324.Color = ColorSequence.new(v322, v323)
				else
					local v325, v326
					if v314.kind == "egg" then
						local v327 = v_u_33.eggById[v_u_48.eggFor(v314, v307)]
						v325 = ("x%*"):format(v314.count or 1)
						if v327 then
							v326 = v327.name
						else
							v326 = "Egg"
						end
					elseif v314.kind == "trophies" then
						v325 = "+" .. v_u_50.short(v_u_48.amount(v314, v306, v307))
						v326 = "Trophies"
					elseif v314.kind == "boost" then
						local v328 = v314.minutes or 0
						local v329
						if v328 >= 60 then
							v329 = ("%*h"):format(v328 // 60)
						else
							v329 = ("%*m"):format(v328)
						end
						v326 = ("x%* %* %*"):format(v_u_48.BOOST_MULT[v314.boost or "chakra"] or 2, v314.boost == "wins" and "Trophies" or "Chakra", v329)
						v325 = "x1"
					else
						v326 = v_u_303(v314)
						v325 = ""
					end
					v_u_66(v315, "Count").Text = v325
					v_u_66(v315, "Name").Text = v326
					v_u_66(v315, "Icon").Image = v_u_295(v314)
					local v330 = v_u_304
					local v331
					if v314.kind == "boost" then
						v331 = v314.boost == "wins" and "wins" or "chakra"
					else
						v331 = v314.kind
					end
					local v332 = v330[v331] or v_u_304.egg
					local v333 = v332[1]
					local v334 = v332[2]
					local v335 = v315:FindFirstChildOfClass("UIGradient")
					if not v335 then
						continue
					end
					v335.Color = ColorSequence.new(v333, v334)
				end
			end
		end
	end
end
local v_u_337 = {
	["kills"] = v_u_37.Icon.Sword,
	["stages"] = v_u_37.Icon.Boss,
	["hatch"] = v_u_245.EggNormal or v_u_37.Icon.Star,
	["minutes"] = v_u_37.Icon.Star,
	["rebirths"] = v_u_37.Icon.Rebirth,
	["clicks"] = v_u_37.Icon.Chakra
}
local v_u_338 = "daily"
local function v_u_341(p339) -- name: questText
	-- upvalues: (copy) v_u_50, (copy) v_u_11
	local v340 = v_u_50.short(p339.goal)
	if p339.kind == "kills" then
		return ("Defeat %* enemies"):format(v340)
	elseif p339.kind == "stages" then
		return ("Clear %* stages"):format(v340)
	elseif p339.kind == "hatch" then
		return ("Hatch %* eggs"):format(v340)
	elseif p339.kind == "minutes" then
		return ("Play %* minutes"):format(v340)
	elseif p339.kind == "rebirths" then
		return ("Rebirth %* times"):format(v340)
	elseif v_u_11.active() then
		return ("Press %* to train %* times"):format(v_u_11.name(Enum.KeyCode.ButtonR2), v340)
	else
		return ("Click to train %* times"):format(v340)
	end
end
local v_u_342 = {
	["daily"] = "questsDaily",
	["weekly"] = "questsWeekly"
}
local v_u_343 = nil
local v_u_344 = {}
local v_u_345 = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Heavy)
local v_u_346 = Color3.fromRGB(255, 240, 90)
local v_u_347 = {
	["daily"] = {},
	["weekly"] = {}
}
local v_u_348 = {
	["daily"] = {},
	["weekly"] = {}
}
local v_u_349 = {
	["daily"] = false,
	["weekly"] = false
}
local v_u_350 = {
	["daily"] = 0,
	["weekly"] = 0
}
local v_u_351 = 0
local function v_u_355(p352) -- name: questIdsOf
	-- upvalues: (copy) v_u_14
	local v353 = {}
	for _, v354 in v_u_14.quests(p352) do
		v353[v354.slot] = v354.quest.id
	end
	return v353
end
local function v_u_360(p356, p357) -- name: tiltedWords
	-- upvalues: (copy) v_u_345, (copy) v_u_346
	local v358 = Instance.new("TextLabel")
	v358.Name = p356
	v358.BackgroundTransparency = 1
	v358.AnchorPoint = Vector2.new(0.5, 0.5)
	v358.FontFace = v_u_345
	v358.TextScaled = true
	v358.Text = p357
	v358.TextColor3 = v_u_346
	local v359 = Instance.new("UIStroke")
	v359.Color = Color3.new(0, 0, 0)
	v359.Thickness = 0.1
	v359.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
	v359.Parent = v358
	return v358
end
local function v_u_368(p361) -- name: newQuestsBanner
	-- upvalues: (ref) v_u_351, (copy) v_u_360, (copy) v_u_8
	v_u_351 = v_u_351 + 1
	local v_u_362 = v_u_351
	local v363 = p361:FindFirstChild("NewQuests")
	if v363 then
		v363:Destroy()
	end
	local v_u_364 = v_u_360("NewQuests", "NEW QUESTS!")
	v_u_364.Position = UDim2.fromScale(0.5, 0.6)
	v_u_364.Size = UDim2.fromScale(0.82, 0.17)
	v_u_364.Rotation = -6
	v_u_364.ZIndex = 30
	local v365 = Instance.new("UIScale")
	v365.Scale = 0.2
	v365.Parent = v_u_364
	v_u_364.Parent = p361
	local v366 = Enum.EasingStyle.Back
	v_u_8:Create(v365, TweenInfo.new(0.35, v366 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Scale"] = 1
	}):Play()
	task.delay(1.7, function()
		-- upvalues: (copy) v_u_362, (ref) v_u_351, (copy) v_u_364, (ref) v_u_8
		if v_u_362 == v_u_351 and v_u_364.Parent then
			v_u_8:Create(v_u_364, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["TextTransparency"] = 1
			}):Play()
			local v367 = v_u_364:FindFirstChildOfClass("UIStroke")
			if v367 then
				v_u_8:Create(v367, TweenInfo.new(0.4, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Transparency"] = 1
				}):Play()
			end
			task.delay(0.4, function()
				-- upvalues: (ref) v_u_364
				v_u_364:Destroy()
			end)
		end
	end)
end
local function v_u_386(p369, p370, p371) -- name: markNewRow
	-- upvalues: (copy) v_u_360, (copy) v_u_350, (copy) v_u_8
	local v372 = v_u_360("New", "NEW!")
	v372.Position = UDim2.fromScale(0.1, 0.2)
	v372.Size = UDim2.fromScale(0.17, 0.4)
	v372.Rotation = -12
	v372.ZIndex = 12
	v372.Parent = p369
	local v373 = os.clock() - v_u_350[p370] - p371 * 0.18
	if v373 < 0.8 then
		local v374 = -v373
		local v375 = math.max(0, v374)
		local v376 = v373 / 0.8
		local v_u_377 = math.clamp(v376, 0, 1)
		local v_u_378 = Instance.new("Frame")
		v_u_378.Name = "NewFlash"
		v_u_378.BorderSizePixel = 0
		v_u_378.BackgroundColor3 = Color3.new(1, 1, 1)
		v_u_378.BackgroundTransparency = v_u_377 * 0.9 + 0.1
		v_u_378.Size = UDim2.fromScale(1, 1)
		v_u_378.ZIndex = 11
		v_u_378.Parent = p369
		local v_u_379 = {}
		for _, v380 in { p369:FindFirstChild("Icon"), v372 } do
			if not v380 then
				continue
			end
			local v381 = Instance.new("UIScale")
			v381.Scale = v_u_377 * 0.7 + 0.3
			v381.Parent = v380
			table.insert(v_u_379, v381)
		end
		task.delay(v375, function()
			-- upvalues: (copy) v_u_378, (copy) v_u_377, (ref) v_u_8, (copy) v_u_379
			if v_u_378.Parent then
				local v382 = (1 - v_u_377) * 0.8
				v_u_8:Create(v_u_378, TweenInfo.new(v382, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["BackgroundTransparency"] = 1
				}):Play()
				for _, v383 in v_u_379 do
					local v384 = math.min(v382, 0.45)
					local v385 = Enum.EasingStyle.Back
					v_u_8:Create(v383, TweenInfo.new(v384, v385 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = 1
					}):Play()
				end
				task.delay(v382, function()
					-- upvalues: (ref) v_u_378
					v_u_378:Destroy()
				end)
			end
		end)
	end
end
local function v_u_392() -- name: updateQuestRefresh
	-- upvalues: (ref) v_u_343, (copy) v_u_15, (copy) v_u_342, (ref) v_u_338, (copy) v_u_4, (copy) v_u_53, (copy) v_u_14, (ref) v_u_251, (copy) v_u_344, (copy) v_u_12
	local v387 = v_u_343
	if v387 then
		local v388 = v_u_15.product(v_u_342[v_u_338])
		if v388 then
			if v388.id == 0 and (not v_u_4:IsStudio() or v_u_53:GetAttribute("DevQuestRefresh") ~= true) then
				v388 = nil
			end
		else
			v388 = nil
		end
		local v389
		if v388 == nil then
			v389 = false
		else
			v389 = v_u_14.questsOpen(v_u_338) > 0
		end
		v387.Visible = v389
		if v388 then
			local v390 = "REFRESH  " .. v_u_15.priceText(v388.price)
			local v391 = v387:FindFirstChild("TextLabel")
			if v391 and v391:IsA("TextLabel") then
				v391.Text = v390
			end
			if v387.Visible and (v_u_251 == "Quests" and not v_u_344[v_u_338]) then
				v_u_344[v_u_338] = true
				v_u_12.shown("QuestRefresh", "product", v388.key, v_u_338 == "weekly" and "Weekly" or "Daily")
			end
		end
	end
end
local function v_u_399() -- name: buyQuestRefresh
	-- upvalues: (ref) v_u_338, (copy) v_u_6, (copy) v_u_13, (ref) v_u_249, (copy) v_u_15, (copy) v_u_342
	local v_u_393 = v_u_338
	local v_u_394 = v_u_6:FindFirstChild("Remotes")
	if v_u_394 then
		v_u_394 = v_u_394:FindFirstChild("QuestRefresh")
	end
	if v_u_394 and v_u_394:IsA("RemoteFunction") then
		local v395, v396, v397, v398 = pcall(function()
			-- upvalues: (copy) v_u_394, (copy) v_u_393
			return v_u_394:InvokeServer("ask", v_u_393)
		end)
		if v395 and v396 == true then
			if type(v398) == "number" and v398 ~= 0 then
				v_u_15.promptProduct(v398, "QuestRefresh", v_u_393 == "weekly" and "Weekly" or "Daily")
			else
				v_u_249((("Studio: no product yet (DevRun buy %*)"):format(v_u_342[v_u_393])))
			end
		else
			v_u_13.play("Error")
			v_u_249((not v395 or type(v397) ~= "string") and "Try again" or v397)
			return
		end
	else
		return
	end
end
local function v_u_422(p_u_400) -- name: bindQuestRefresh
	-- upvalues: (copy) v_u_26, (copy) v_u_239, (copy) v_u_240, (copy) v_u_399, (ref) v_u_343, (copy) v_u_344, (copy) v_u_349, (copy) v_u_348, (copy) v_u_15, (copy) v_u_392, (copy) v_u_53, (copy) v_u_14, (copy) v_u_347, (copy) v_u_355, (copy) v_u_13, (ref) v_u_249, (ref) v_u_338, (copy) v_u_60, (ref) v_u_251
	local v401 = p_u_400:FindFirstChild("Tabs")
	if v401 then
		v401 = v401:FindFirstChild("Daily")
	end
	if v401 and v401:IsA("GuiButton") then
		local v402 = v401:Clone()
		v402.Name = "Refresh"
		for _, v403 in { "Ui-Frame", "Ui-Close" } do
			v402:SetAttribute(v403, nil)
		end
		v402:SetAttribute("Pad", true)
		v402.AnchorPoint = Vector2.new(0.5, 0.5)
		local v404 = v_u_26.touch()
		v402.Position = UDim2.fromScale(0.5, v404 and 1.04 or 1.025)
		local v405
		if v404 then
			v405 = UDim2.fromScale(0.64, 0.105)
		else
			v405 = UDim2.fromScale(0.5, 0.075)
		end
		v402.Size = v405
		v402.ZIndex = 6
		v402.Visible = false
		local v406 = v_u_239
		local v407 = v_u_240
		local v408 = v402:FindFirstChildOfClass("UIGradient")
		if v408 then
			v408.Color = ColorSequence.new(v406, v407)
		end
		v402.Activated:Connect(v_u_399)
		v402.Parent = p_u_400
		v_u_343 = v402
		p_u_400:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) p_u_400, (ref) v_u_344, (ref) v_u_349, (ref) v_u_348
			if not p_u_400.Visible then
				table.clear(v_u_344)
				for v409, v410 in v_u_349 do
					if v410 then
						continue
					end
					table.clear(v_u_348[v409])
				end
			end
		end)
		v_u_15.pricesChanged:Connect(v_u_392)
		v_u_53:GetAttributeChangedSignal("DevQuestRefresh"):Connect(v_u_392)
		local function v421(p_u_411, p412, p_u_413) -- name: watch
			-- upvalues: (ref) v_u_14, (ref) v_u_347, (ref) v_u_355, (ref) v_u_53, (ref) v_u_13, (ref) v_u_249, (ref) v_u_348, (ref) v_u_349, (ref) v_u_338, (ref) v_u_60, (ref) v_u_251
			local v_u_414 = v_u_14.questRefreshes(p_u_411)
			v_u_347[p_u_411] = v_u_355(p_u_411)
			v_u_53:GetAttributeChangedSignal(p412):Connect(function()
				-- upvalues: (ref) v_u_14, (copy) p_u_411, (ref) v_u_347, (ref) v_u_355, (ref) v_u_414, (ref) v_u_13, (ref) v_u_249, (copy) p_u_413, (ref) v_u_348, (ref) v_u_349, (ref) v_u_338, (ref) v_u_60, (ref) v_u_251
				local v415 = v_u_14.questRefreshes(p_u_411)
				local v416 = v_u_347[p_u_411]
				local v417 = v_u_355(p_u_411)
				v_u_347[p_u_411] = v417
				if v_u_414 < v415 and next(v416) ~= nil then
					v_u_13.play("RevealBig", {
						["volume"] = 0.6
					})
					v_u_249(p_u_413)
					for v418, v419 in v417 do
						if v416[v418] == v419 then
							continue
						end
						v_u_348[p_u_411][v418] = true
					end
					v_u_349[p_u_411] = true
					v_u_338 = p_u_411
					local v420 = v_u_60.Quests
					if v_u_251 == "Quests" and v420 then
						task.defer(v420)
					end
				elseif v415 < v_u_414 then
					table.clear(v_u_348[p_u_411])
					v_u_349[p_u_411] = false
				end
				v_u_414 = v415
			end)
		end
		v421("daily", "QuestDaily", "New daily quests!")
		v421("weekly", "QuestWeekly", "New weekly quests!")
	end
end
local function v_u_463() -- name: refreshQuests
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_256, (copy) v_u_349, (ref) v_u_338, (copy) v_u_350, (copy) v_u_368, (copy) v_u_243, (copy) v_u_241, (copy) v_u_244, (copy) v_u_242, (copy) v_u_14, (ref) v_u_56, (copy) v_u_337, (copy) v_u_37, (copy) v_u_341, (copy) v_u_303, (copy) v_u_295, (copy) v_u_50, (copy) v_u_239, (copy) v_u_240, (copy) v_u_13, (ref) v_u_249, (copy) v_u_21, (copy) v_u_29, (copy) v_u_348, (copy) v_u_386, (copy) v_u_392
	local v423 = v_u_247:FindFirstChild("Quests")
	if not (v423 and v423:IsA("Frame")) then
		v423 = nil
	end
	if v423 then
		local v424 = v_u_66(v423, "List")
		v_u_256(v424)
		if v_u_349[v_u_338] then
			v_u_349[v_u_338] = false
			v_u_350[v_u_338] = os.clock()
			v_u_368(v423)
		end
		local v425 = 0
		for _, v426 in { "Daily", "Weekly" } do
			local v427 = string.lower(v426) == v_u_338
			local v428 = v_u_66(v423, "Tabs." .. v426)
			local v429
			if v427 then
				v429 = v_u_243
			else
				v429 = v_u_241
			end
			local v430
			if v427 then
				v430 = v_u_244
			else
				v430 = v_u_242
			end
			local v431 = v428:FindFirstChildOfClass("UIGradient")
			if not v431 then
				continue
			end
			v431.Color = ColorSequence.new(v429, v430)
		end
		for v436, v_u_433 in v_u_14.quests(v_u_338) do
			local v_u_434 = v_u_433.quest
			local v_u_435 = v_u_66(v_u_56, "QuestRow"):Clone()
			v_u_435.Visible = true
			local v436
			if v_u_433.claimed then
				v436 = 2000 + v436
			elseif not v_u_433.done then
				v436 = 1000 + v436
			end
			v_u_435.LayoutOrder = v436
			local v437
			if v_u_433.claimed then
				v437 = v_u_241
			elseif v_u_338 == "weekly" then
				v437 = Color3.fromRGB(190, 110, 255)
			else
				v437 = Color3.fromRGB(255, 170, 70)
			end
			local v438
			if v_u_433.claimed then
				v438 = v_u_242
			elseif v_u_338 == "weekly" then
				v438 = Color3.fromRGB(120, 40, 220)
			else
				v438 = Color3.fromRGB(255, 110, 25)
			end
			local v439 = v_u_435:FindFirstChild("Paint")
			if v439 and v439:IsA("UIGradient") then
				v439.Color = ColorSequence.new(v437, v438)
				v439.Rotation = 0
			end
			v_u_66(v_u_435, "Icon").Image = v_u_337[v_u_434.kind] or v_u_37.Icon.Star
			v_u_66(v_u_435, "Title").Text = v_u_341(v_u_434)
			v_u_66(v_u_435, "Amount").Text = v_u_303(v_u_434.prize)
			v_u_66(v_u_435, "AmountIcon").Image = v_u_295(v_u_434.prize)
			local v440 = v_u_66(v_u_435, "Progress.Fill")
			local v441 = UDim2.fromScale
			local v442 = v_u_433.have / v_u_434.goal
			v440.Size = v441(math.clamp(v442, 0.03, 1), 1)
			v_u_66(v_u_435, "Progress.Text").Text = v_u_50.short(v_u_433.have) .. " / " .. v_u_50.short(v_u_434.goal)
			local v443 = v_u_66(v_u_435, "Button")
			if v_u_433.claimed then
				local v444 = v443:FindFirstChild("TextLabel")
				if v444 and v444:IsA("TextLabel") then
					v444.Text = "DONE"
				end
				local v445 = v_u_241
				local v446 = v_u_242
				local v447 = v443:FindFirstChildOfClass("UIGradient")
				if v447 then
					v447.Color = ColorSequence.new(v445, v446)
				end
			elseif v_u_433.done then
				local v448 = v443:FindFirstChild("TextLabel")
				if v448 and v448:IsA("TextLabel") then
					v448.Text = "CLAIM"
				end
				local v449 = v_u_239
				local v450 = v_u_240
				local v451 = v443:FindFirstChildOfClass("UIGradient")
				if v451 then
					v451.Color = ColorSequence.new(v449, v450)
				end
			else
				local v452 = v443:FindFirstChild("TextLabel")
				if v452 and v452:IsA("TextLabel") then
					v452.Text = "..."
				end
				local v453 = v_u_241
				local v454 = v_u_242
				local v455 = v443:FindFirstChildOfClass("UIGradient")
				if v455 then
					v455.Color = ColorSequence.new(v453, v454)
				end
			end
			local v_u_456 = v_u_338
			v443.Activated:Connect(function()
				-- upvalues: (copy) v_u_433, (ref) v_u_13, (ref) v_u_249, (ref) v_u_21, (ref) v_u_29, (copy) v_u_456, (copy) v_u_435, (ref) v_u_303, (copy) v_u_434
				if v_u_433.claimed then
					return
				elseif v_u_433.done then
					v_u_21.hold()
					local function v457()
						-- upvalues: (ref) v_u_29, (ref) v_u_456, (ref) v_u_433
						return v_u_29.func("ClaimQuest"):InvokeServer(v_u_456, v_u_433.slot)
					end
					local v458, v459, v460 = pcall(v457)
					local v461 = v_u_435
					local v_u_462 = v_u_21.centreOf(v461)
					task.delay(0.25, function()
						-- upvalues: (ref) v_u_21, (copy) v_u_462
						v_u_21.release(v_u_462)
					end)
					if v458 and v459 == true then
						v_u_13.play("QuestDone")
						v_u_249("Quest complete: " .. v_u_303(v_u_434.prize))
					else
						v_u_13.play("Error")
						if v458 and type(v460) == "string" then
							v_u_249(v460)
						end
					end
				else
					v_u_13.play("Error")
					v_u_249("Not done yet!")
					return
				end
			end)
			v_u_435.Parent = v424
			if not v_u_348[v_u_338][v_u_433.slot] then
				continue
			end
			v_u_386(v_u_435, v_u_338, v425)
			v425 = v425 + 1
		end
		v_u_392()
	end
end
local function v_u_477() -- name: bindQuests
	-- upvalues: (ref) v_u_247, (copy) v_u_60, (copy) v_u_463, (copy) v_u_422, (copy) v_u_66, (ref) v_u_338, (copy) v_u_14, (copy) v_u_53, (ref) v_u_251, (copy) v_u_39
	local v464 = v_u_247:FindFirstChild("Quests")
	if not (v464 and v464:IsA("Frame")) then
		v464 = nil
	end
	if v464 then
		v_u_60.Quests = v_u_463
		v_u_422(v464)
		for _, v_u_465 in { "Daily", "Weekly" } do
			v_u_66(v464, "Tabs." .. v_u_465).Activated:Connect(function()
				-- upvalues: (ref) v_u_338, (copy) v_u_465, (ref) v_u_463
				v_u_338 = v_u_465 == "Weekly" and "weekly" or "daily"
				v_u_463()
			end)
		end
		for _, v466 in v_u_14.QUEST_FIELDS do
			v_u_53:GetAttributeChangedSignal(v466):Connect(function()
				-- upvalues: (ref) v_u_251, (ref) v_u_463
				if v_u_251 == "Quests" then
					v_u_463()
				end
			end)
		end
		local v_u_467 = v_u_66(v464, "Tabs.Resets")
		task.spawn(function()
			-- upvalues: (ref) v_u_251, (ref) v_u_39, (ref) v_u_338, (copy) v_u_467
			while true do
				if v_u_251 == "Quests" then
					local v468 = v_u_39.resetsIn(v_u_338, DateTime.now().UnixTimestamp)
					local v469 = v468 / 86400
					local v470 = math.floor(v469)
					local v471 = v468 % 86400 / 3600
					local v472 = math.floor(v471)
					local v473 = v468 % 3600 / 60
					local v474 = math.floor(v473)
					local v475 = v_u_467
					local v476
					if v470 > 0 then
						v476 = ("Resets in %*d %*h"):format(v470, v472)
					else
						v476 = ("Resets in %*h %*m"):format(v472, v474)
					end
					v475.Text = v476
				end
				task.wait(1)
			end
		end)
	end
end
local function v_u_555() -- name: refreshAuras
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_256, (copy) v_u_14, (copy) v_u_32, (copy) v_u_53, (copy) v_u_15, (ref) v_u_56, (copy) v_u_285, (copy) v_u_286, (copy) v_u_246, (copy) v_u_37, (copy) v_u_50, (copy) v_u_253, (copy) v_u_51, (copy) v_u_243, (copy) v_u_244, (copy) v_u_239, (copy) v_u_240, (copy) v_u_241, (copy) v_u_242, (copy) v_u_16, (copy) v_u_52, (copy) v_u_13, (ref) v_u_249, (copy) v_u_29
	local v478 = v_u_247:FindFirstChild("Auras")
	if not (v478 and v478:IsA("Frame")) then
		v478 = nil
	end
	if v478 then
		local v479 = v_u_66(v478, "List")
		v_u_256(v479)
		local v_u_480 = v_u_14.number("TotalWins")
		local v481 = v_u_14.string("Aura")
		local v_u_482 = v_u_14.ownedAuras()
		local v483 = v_u_14.number("World", 1)
		local function v485(p484) -- name: has
			-- upvalues: (ref) v_u_32, (ref) v_u_53, (copy) v_u_482, (copy) v_u_480
			if v_u_32.isOut(p484) then
				if p484.pass then
					return v_u_53:GetAttribute("Pass_" .. p484.pass) == true
				elseif p484.skip and v_u_53:GetAttribute("Pass_" .. p484.skip) == true then
					return true
				elseif p484.exclusive then
					return v_u_482[p484.id] == true
				else
					return v_u_480 >= p484.trophies
				end
			else
				return false
			end
		end
		for v486, v_u_487 in v_u_32.list do
			if not v_u_32.isOut(v_u_487) then
				continue
			end
			local v_u_488 = v485(v_u_487)
			local v_u_489 = v_u_487.pass or v_u_487.skip
			local v490
			if v_u_489 then
				v490 = v_u_15.pass(v_u_489)
			else
				v490 = nil
			end
			local v491 = v_u_66(v_u_56, "AuraRow"):Clone()
			v491.Visible = true
			v491.LayoutOrder = v486
			local v492 = Color3.fromHex(v_u_487.color)
			local v493 = v492:Lerp(Color3.new(1, 1, 1), 0.35)
			local v494 = v492:Lerp(Color3.new(0, 0, 0), v_u_488 and 0.35 or 0.6)
			local v495 = v491:FindFirstChild("Paint")
			if v495 and v495:IsA("UIGradient") then
				local v496 = ColorSequence.new
				local v497 = {}
				local v498 = ColorSequenceKeypoint.new
				local v499 = 0
				if not v_u_488 then
					v493 = v493:Lerp(Color3.new(0, 0, 0), 0.45)
				end
				local v500 = v498(v499, v493)
				local v501 = ColorSequenceKeypoint.new
				local v502 = 0.5
				if not v_u_488 then
					v492 = v492:Lerp(Color3.new(0, 0, 0), 0.45)
				end
				__set_list(v497, 1, {v500, v501(v502, v492), ColorSequenceKeypoint.new(1, v494)})
				v495.Color = v496(v497)
				v495.Rotation = 0
				if v_u_487.rainbow then
					local v503
					if v_u_488 then
						v503 = v_u_285
					else
						v503 = v_u_286
					end
					v495.Color = v503
				end
				local v504 = v_u_487.colors
				if v504 and #v504 >= 2 then
					local v505 = {}
					for v506, v507 in v504 do
						local v508 = Color3.fromHex(v507)
						local v509 = ColorSequenceKeypoint.new
						local v510 = (v506 - 1) / (#v504 - 1)
						if not v_u_488 then
							v508 = v508:Lerp(Color3.new(0, 0, 0), 0.45)
						end
						table.insert(v505, v509(v510, v508))
					end
					v495.Color = ColorSequence.new(v505)
				end
			end
			local v511 = v_u_66(v491, "Icon")
			v511.Image = v_u_246[v_u_487.id] or v_u_37.Icon.Star
			local v512
			if v_u_488 then
				v512 = Color3.new(1, 1, 1)
			else
				v512 = Color3.fromRGB(120, 120, 130)
			end
			v511.ImageColor3 = v512
			v_u_66(v491, "Icon.Lock").Visible = not v_u_488
			v_u_66(v491, "Title").Text = v_u_487.name
			v_u_66(v491, "Info").Text = v_u_50.mult(v_u_32.multFor(v_u_487, v483, v485)) .. " Chakra"
			local v513 = v_u_253[v_u_487.id]
			local v514 = v_u_66(v491, "Tag")
			local v515
			if v_u_487.better then
				local v516 = v_u_487.better * 100 + 0.5
				v515 = ("+%*%% OVER YOUR BEST AURA"):format((math.floor(v516)))
			elseif v_u_487.pass then
				v515 = "EXCLUSIVE"
			elseif v_u_487.exclusive and v513 then
				v515 = ("DAILY REWARD - WEEK %*"):format(v513)
			else
				v515 = v_u_487.exclusive and "EXCLUSIVE - DAY 3 REWARD" or ""
			end
			v514.Text = v515
			local v517 = v_u_66(v491, "Amount")
			local v518 = v_u_66(v491, "AmountIcon")
			v517.Text = v_u_487.exclusive and "" or v_u_50.short(v_u_487.trophies)
			v518.Visible = not v_u_487.exclusive
			local v_u_519 = v_u_487.boss
			if v_u_519 then
				v517.Text = v_u_50.commas(v_u_519)
				v518.Visible = true
				if v518:IsA("ImageLabel") then
					v518.Image = v_u_37.Icon.KuramaCoin
				end
			end
			local v_u_520
			if v_u_487.drop then
				v_u_520 = v_u_51.find("aura", v_u_487.id)
			else
				v_u_520 = nil
			end
			if v_u_520 then
				v517.Text = v_u_51.percent(v_u_520.chance)
				v518.Visible = false
			end
			local v521 = v_u_66(v491, "Button")
			if v481 == v_u_487.id then
				local v522 = v521:FindFirstChild("TextLabel")
				if v522 and v522:IsA("TextLabel") then
					v522.Text = "EQUIPPED"
				end
				local v523 = v_u_243
				local v524 = v_u_244
				local v525 = v521:FindFirstChildOfClass("UIGradient")
				if v525 then
					v525.Color = ColorSequence.new(v523, v524)
				end
			elseif v_u_488 then
				local v526 = v521:FindFirstChild("TextLabel")
				if v526 and v526:IsA("TextLabel") then
					v526.Text = "EQUIP"
				end
				local v527 = v_u_239
				local v528 = v_u_240
				local v529 = v521:FindFirstChildOfClass("UIGradient")
				if v529 then
					v529.Color = ColorSequence.new(v527, v528)
				end
			elseif v490 then
				local v530 = v_u_15.ROBUX
				local v531 = v_u_15.passPrice
				local v532 = v530 .. " " .. tostring(v531(v490))
				local v533 = v521:FindFirstChild("TextLabel")
				if v533 and v533:IsA("TextLabel") then
					v533.Text = v532
				end
				local v534 = Color3.fromRGB(255, 215, 60)
				local v535 = Color3.fromRGB(255, 140, 0)
				local v536 = v521:FindFirstChildOfClass("UIGradient")
				if v536 then
					v536.Color = ColorSequence.new(v534, v535)
				end
			elseif v_u_519 then
				local v537 = v521:FindFirstChild("TextLabel")
				if v537 and v537:IsA("TextLabel") then
					v537.Text = "BOSS SHOP"
				end
				local v538 = Color3.fromRGB(255, 168, 52)
				local v539 = Color3.fromRGB(222, 64, 24)
				local v540 = v521:FindFirstChildOfClass("UIGradient")
				if v540 then
					v540.Color = ColorSequence.new(v538, v539)
				end
			elseif v_u_520 then
				local v541 = v521:FindFirstChild("TextLabel")
				if v541 and v541:IsA("TextLabel") then
					v541.Text = "BOSS DROP"
				end
				local v542 = Color3.fromRGB(255, 74, 74)
				local v543 = Color3.fromRGB(150, 8, 30)
				local v544 = v521:FindFirstChildOfClass("UIGradient")
				if v544 then
					v544.Color = ColorSequence.new(v542, v543)
				end
			else
				local v545 = v521:FindFirstChild("TextLabel")
				if v545 and v545:IsA("TextLabel") then
					v545.Text = "LOCKED"
				end
				local v546 = v_u_241
				local v547 = v_u_242
				local v548 = v521:FindFirstChildOfClass("UIGradient")
				if v548 then
					v548.Color = ColorSequence.new(v546, v547)
				end
			end
			if v_u_489 and v490 then
				v_u_16.beside(v521, v_u_489)
				if v521:FindFirstChild("GiftButton") then
					v517.Position = UDim2.new(0.57, 0, v517.Position.Y.Scale, v517.Position.Y.Offset)
					v518.Position = UDim2.new(0.603, 0, v518.Position.Y.Scale, v518.Position.Y.Offset)
				end
			end
			v521.Activated:Connect(function()
				-- upvalues: (copy) v_u_488, (copy) v_u_489, (ref) v_u_15, (copy) v_u_519, (ref) v_u_52, (copy) v_u_520, (ref) v_u_13, (ref) v_u_249, (ref) v_u_51, (copy) v_u_487, (ref) v_u_50, (ref) v_u_14, (ref) v_u_29
				if v_u_488 or not v_u_489 then
					if v_u_488 or not v_u_519 then
						if v_u_488 or not v_u_520 then
							if v_u_488 then
								local v_u_549 = v_u_14.string("Aura") == v_u_487.id and "" or v_u_487.id
								local function v550()
									-- upvalues: (ref) v_u_29, (copy) v_u_549
									return v_u_29.func("EquipAura"):InvokeServer(v_u_549)
								end
								local v551, v552 = pcall(v550)
								v_u_13.play(v551 and v552 == true and "Equip" or "Error")
							else
								v_u_13.play("Error")
								local v553 = v_u_249
								local v554
								if v_u_487.exclusive then
									v554 = v_u_487.name .. " is the day 3 daily reward"
								else
									v554 = ("Earn %* trophies in total to unlock %*"):format(v_u_50.short(v_u_487.trophies), v_u_487.name)
								end
								v553(v554)
							end
						else
							v_u_13.play("Error")
							v_u_249((("Beat Kyubi! Every win has a %* chance of %*"):format(v_u_51.percent(v_u_520.chance), v_u_487.name)))
							return
						end
					else
						v_u_52.open("BossShop")
						return
					end
				else
					v_u_15.buyPass(v_u_489)
					return
				end
			end)
			v491.Parent = v479
		end
	end
end
local function v_u_563() -- name: bindAuras
	-- upvalues: (copy) v_u_60, (copy) v_u_555, (copy) v_u_53, (ref) v_u_251, (copy) v_u_4, (ref) v_u_247
	v_u_60.Auras = v_u_555
	for _, v556 in {
		"Aura",
		"TotalWins",
		"OwnedAuras",
		"World"
	} do
		v_u_53:GetAttributeChangedSignal(v556):Connect(function()
			-- upvalues: (ref) v_u_251, (ref) v_u_555
			if v_u_251 == "Auras" then
				v_u_555()
			end
		end)
	end
	v_u_53.AttributeChanged:Connect(function(p557)
		-- upvalues: (ref) v_u_251, (ref) v_u_555
		if v_u_251 == "Auras" and string.sub(p557, 1, 5) == "Pass_" then
			v_u_555()
		end
	end)
	v_u_4.RenderStepped:Connect(function()
		-- upvalues: (ref) v_u_251, (ref) v_u_247
		if v_u_251 == "Auras" then
			local v558 = v_u_247:FindFirstChild("Auras")
			if not (v558 and v558:IsA("Frame")) then
				v558 = nil
			end
			if v558 then
				v558 = v558:FindFirstChild("List")
			end
			if v558 then
				local v559 = os.clock()
				for _, v560 in v558:GetChildren() do
					local v561 = v560:FindFirstChild("Shine")
					if not (v561 and (v561:IsA("GuiObject") and v560:IsA("GuiObject"))) then
						continue
					end
					local v562 = (v559 * 0.45 + v560.LayoutOrder * 0.13) % 1.6 - 0.3
					v561.Position = UDim2.fromScale(v562, 0.5)
				end
			end
		else
			return
		end
	end)
end
local v_u_564 = nil
local v_u_565 = nil
local v_u_566 = 0
local v_u_567 = {
	["Epic"] = true,
	["Legendary"] = true,
	["Mythic"] = true
}
local v_u_568 = Color3.fromRGB(255, 64, 96)
local v_u_569 = Color3.fromRGB(214, 18, 52)
local v_u_570 = nil
local v_u_571 = nil
local function v_u_578(p_u_572, p_u_573) -- name: petAction
	-- upvalues: (copy) v_u_29, (ref) v_u_249, (copy) v_u_15, (copy) v_u_13
	local function v574()
		-- upvalues: (ref) v_u_29, (copy) p_u_572, (copy) p_u_573
		return v_u_29.func("PetAction"):InvokeServer(p_u_572, p_u_573)
	end
	local v575, v576, v577 = pcall(v574)
	if not v575 then
		return false, nil
	end
	if v576 ~= nil and v576 ~= false then
		return true, v576
	end
	if type(v577) == "string" then
		v_u_249(v577)
		if v577 == "Not enough trophies" then
			v_u_15.offer("trophies")
		end
	end
	v_u_13.play("Error")
	return false, nil
end
local function v_u_594() -- name: sortedPets
	-- upvalues: (copy) v_u_14, (copy) v_u_33, (copy) v_u_34
	local v579 = v_u_14.pets()
	local v580 = v_u_14.petTiers()
	local v581 = v_u_14.number("World", 1)
	local v582 = {}
	for v583, v584 in v579 do
		local v585 = v_u_33.byId[v584]
		if not v585 then
			continue
		end
		local v586 = {
			["uid"] = v583,
			["pet"] = v585,
			["mult"] = v_u_34.multOf(v579, v580, v583, v581)
		}
		table.insert(v582, v586)
	end
	table.sort(v582, function(p587, p588)
		local v589 = p587.mult
		local v590 = p588.mult
		if v589 ~= v590 then
			return v590 < v589
		end
		local v591 = p587.uid
		local v592 = tonumber(v591) or 0
		local v593 = p588.uid
		return v592 < (tonumber(v593) or 0)
	end)
	return v582
end
local function v_u_628(p595) -- name: showPetDetail
	-- upvalues: (copy) v_u_66, (ref) v_u_564, (copy) v_u_14, (copy) v_u_33, (ref) v_u_570, (copy) v_u_22, (copy) v_u_23, (copy) v_u_25, (copy) v_u_31, (copy) v_u_50, (copy) v_u_243, (copy) v_u_241, (copy) v_u_244, (copy) v_u_242, (ref) v_u_565, (copy) v_u_568, (copy) v_u_569, (ref) v_u_566, (copy) v_u_239, (copy) v_u_240
	local v596 = v_u_66(p595, "Detail")
	local v597 = v_u_66(v596, "View")
	local v598 = v_u_66(v596, "Name")
	local v599 = v_u_66(v596, "Rarity")
	local v600 = v_u_66(v596, "Mult")
	local v601 = v_u_66(v596, "Equip")
	local v602 = v_u_66(v596, "Delete")
	local v603
	if v_u_564 then
		v603 = v_u_14.pets()[v_u_564]
	else
		v603 = nil
	end
	local v604
	if v603 then
		v604 = v_u_33.byId[v603]
	else
		v604 = nil
	end
	if v604 and v_u_564 then
		local v605 = v_u_22.build(v604.id)
		local v606 = not v_u_23.enabled() and 0 or v_u_14.petTier(v_u_564)
		if v605 then
			if v606 > 0 then
				v_u_23.apply(v605, v606)
			end
			v_u_22.show(v597, v605, true)
		end
		if v_u_23.enabled() then
			v_u_23.backdrop(v597, v606)
			v_u_23.badge(v597, v606)
		end
		v598.Text = v604.name
		v599.Text = string.upper(v604.rarity)
		v599.TextColor3 = v_u_25.color(v_u_31.RARITY_COLOR[v604.rarity] or "#FFFFFF")
		v600.Text = v_u_50.mult(v_u_14.petMult(v_u_564)) .. " Chakra"
		local v607 = table.find(v_u_14.equipped(), v_u_564) ~= nil
		v601.Visible = true
		v602.Visible = v604.pass == nil
		local v608 = v_u_14.lockedPets()[v_u_564] == true
		if v_u_570 then
			v_u_570.Visible = true
			local v609 = v_u_570
			local v610
			if v608 then
				v610 = v_u_243
			else
				v610 = v_u_241
			end
			local v611
			if v608 then
				v611 = v_u_244
			else
				v611 = v_u_242
			end
			local v612 = v609:FindFirstChildOfClass("UIGradient")
			if v612 then
				v612.Color = ColorSequence.new(v610, v611)
			end
			local v613 = v609:FindFirstChild("Padlock")
			if v613 and v613:IsA("ImageLabel") then
				v613.ImageTransparency = v608 and 0 or 0.4
			end
		end
		if v608 then
			v_u_565 = nil
			local v614 = v602:FindFirstChild("TextLabel")
			if v614 and v614:IsA("TextLabel") then
				v614.Text = "LOCKED"
			end
			local v615 = v_u_241
			local v616 = v_u_242
			local v617 = v602:FindFirstChildOfClass("UIGradient")
			if v617 then
				v617.Color = ColorSequence.new(v615, v616)
			end
		else
			local v618 = v_u_568
			local v619 = v_u_569
			local v620 = v602:FindFirstChildOfClass("UIGradient")
			if v620 then
				v620.Color = ColorSequence.new(v618, v619)
			end
			if v_u_565 ~= v_u_564 or v_u_566 < os.clock() then
				v_u_565 = nil
				local v621 = v602:FindFirstChild("TextLabel")
				if v621 and v621:IsA("TextLabel") then
					v621.Text = "DELETE"
				end
			end
		end
		local v622 = v607 and "UNEQUIP" or "EQUIP"
		local v623 = v601:FindFirstChild("TextLabel")
		if v623 and v623:IsA("TextLabel") then
			v623.Text = v622
		end
		local v624
		if v607 then
			v624 = Color3.fromRGB(255, 64, 96)
		else
			v624 = v_u_239
		end
		local v625
		if v607 then
			v625 = Color3.fromRGB(214, 18, 52)
		else
			v625 = v_u_240
		end
		local v626 = v601:FindFirstChildOfClass("UIGradient")
		if v626 then
			v626.Color = ColorSequence.new(v624, v625)
		end
	else
		v_u_564 = nil
		for _, v627 in v597:GetChildren() do
			v627:Destroy()
		end
		v598.Text = "No pet"
		v599.Text = "Hatch eggs at spawn!"
		v599.TextColor3 = Color3.new(1, 1, 1)
		v600.Text = ""
		v601.Visible = false
		v602.Visible = false
		if v_u_570 then
			v_u_570.Visible = false
		end
	end
end
local v_u_629 = { "equip1", "equip2" }
local v_u_630 = { "storage20", "storage120" }
local function v_u_648() -- name: refreshPets
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_256, (copy) v_u_14, (copy) v_u_594, (ref) v_u_564, (ref) v_u_56, (copy) v_u_19, (copy) v_u_50, (copy) v_u_22, (copy) v_u_23, (copy) v_u_47, (copy) v_u_24, (copy) v_u_628, (copy) v_u_33, (copy) v_u_629, (copy) v_u_53, (copy) v_u_630
	local v_u_631 = v_u_247:FindFirstChild("Pets")
	if not (v_u_631 and v_u_631:IsA("Frame")) then
		v_u_631 = nil
	end
	if v_u_631 then
		local v632 = v_u_66(v_u_631, "Grid")
		v_u_256(v632)
		local v633 = v_u_14.equipped()
		local v634 = v_u_594()
		local v635 = v_u_14.lockedPets()
		if v_u_564 and not v_u_14.pets()[v_u_564] then
			v_u_564 = nil
		end
		if not v_u_564 and v634[1] then
			v_u_564 = v634[1].uid
		end
		for v636, v_u_637 in v634 do
			local v638 = v_u_66(v_u_56, "PetCard"):Clone()
			v638.Visible = true
			v638.Active = true
			v638.LayoutOrder = v636
			v638.Size = UDim2.fromScale(1, 1)
			v638.Position = UDim2.new()
			v638.AnchorPoint = Vector2.zero
			v_u_19.paint(v638, v_u_637.pet.rarity)
			v_u_66(v638, "Mult").Text = v_u_50.mult(v_u_637.mult)
			v_u_66(v638, "On").Visible = table.find(v633, v_u_637.uid) ~= nil
			local v639 = v_u_22.build(v_u_637.pet.id)
			local v640 = not v_u_23.enabled() and 0 or v_u_14.petTier(v_u_637.uid)
			if v639 then
				if v640 > 0 then
					v_u_23.apply(v639, v640)
				end
				v_u_22.show(v_u_66(v638, "View"), v639, false)
			end
			if v_u_47.on(3) then
				v_u_24.pet(v638, v_u_637.pet.id, v640, v636)
			end
			if v635[v_u_637.uid] then
				local v641 = v640 > 0
				v_u_24.lock(v638, v641)
			end
			v638.Activated:Connect(function()
				-- upvalues: (ref) v_u_564, (copy) v_u_637, (ref) v_u_628, (copy) v_u_631
				v_u_564 = v_u_637.uid
				v_u_628(v_u_631)
			end)
			v638.Parent = v632
		end
		v_u_66(v_u_631, "Top.Equipped").Text = ("EQUIPPED %*/%*"):format(#v633, (v_u_14.number("EquipMax", v_u_33.EQUIP_MAX)))
		v_u_66(v_u_631, "Top.Space").Text = ("SPACE %*/%*"):format(#v634, (v_u_14.number("PetSpace", v_u_33.SPACE)))
		local v642 = v_u_66(v_u_631, "Top.EquipPlus")
		for _, v644 in v_u_629 do
			if v_u_53:GetAttribute("Pass_" .. v644) == true then
				continue
			end
		end
		local v644 = nil
		v642.Visible = v644 ~= nil
		local v645 = v_u_66(v_u_631, "Top.SpacePlus")
		for _, v647 in v_u_630 do
			if v_u_53:GetAttribute("Pass_" .. v647) == true then
				continue
			end
		end
		local v647 = nil
		v645.Visible = v647 ~= nil
		v_u_628(v_u_631)
	end
end
local function v_u_697() -- name: bindPets
	-- upvalues: (ref) v_u_247, (copy) v_u_60, (copy) v_u_648, (copy) v_u_66, (ref) v_u_564, (copy) v_u_14, (copy) v_u_578, (copy) v_u_13, (copy) v_u_33, (ref) v_u_249, (copy) v_u_567, (ref) v_u_565, (ref) v_u_566, (copy) v_u_11, (copy) v_u_594, (copy) v_u_37, (ref) v_u_570, (ref) v_u_571, (copy) v_u_35, (copy) v_u_629, (copy) v_u_630, (copy) v_u_53, (copy) v_u_15, (ref) v_u_251
	local v649 = v_u_247:FindFirstChild("Pets")
	if not (v649 and v649:IsA("Frame")) then
		v649 = nil
	end
	if v649 then
		v_u_60.Pets = v_u_648
		local v650 = v_u_66(v649, "Detail")
		v_u_66(v650, "Equip").Activated:Connect(function()
			-- upvalues: (ref) v_u_564, (ref) v_u_14, (ref) v_u_578, (ref) v_u_13
			local v651 = v_u_564
			if v651 then
				if v_u_578(table.find(v_u_14.equipped(), v651) ~= nil and "unequip" or "equip", v651) then
					v_u_13.play("Equip")
				end
			end
		end)
		local v_u_652 = v_u_66(v650, "Delete")
		v_u_652.Activated:Connect(function()
			-- upvalues: (ref) v_u_564, (ref) v_u_14, (ref) v_u_33, (ref) v_u_249, (ref) v_u_13, (ref) v_u_567, (ref) v_u_565, (ref) v_u_566, (copy) v_u_652, (ref) v_u_11, (ref) v_u_594, (ref) v_u_578
			local v_u_653 = v_u_564
			local v654
			if v_u_653 then
				v654 = v_u_14.pets()[v_u_653]
			else
				v654 = nil
			end
			local v655
			if v654 then
				v655 = v_u_33.byId[v654]
			else
				v655 = nil
			end
			if v_u_653 and (v655 and not v655.pass) then
				if v_u_14.lockedPets()[v_u_653] then
					v_u_249("This pet is locked: unlock it to delete it")
					v_u_13.play("Error")
					return
				elseif v_u_567[v655.rarity] and (v_u_565 ~= v_u_653 or v_u_566 < os.clock()) then
					v_u_565 = v_u_653
					v_u_566 = os.clock() + 3
					local v656 = v_u_652
					local v657 = v_u_11.active() and "PRESS AGAIN TO DELETE" or "TAP AGAIN TO DELETE"
					local v658 = v656:FindFirstChild("TextLabel")
					if v658 and v658:IsA("TextLabel") then
						v658.Text = v657
					end
					v_u_13.play("Error")
					task.delay(3, function()
						-- upvalues: (ref) v_u_565, (copy) v_u_653, (ref) v_u_566, (ref) v_u_652
						if v_u_565 == v_u_653 and v_u_566 <= os.clock() then
							v_u_565 = nil
							local v659 = v_u_652:FindFirstChild("TextLabel")
							if v659 and v659:IsA("TextLabel") then
								v659.Text = "DELETE"
							end
						end
					end)
				else
					v_u_565 = nil
					local v660 = v_u_594()
					local v661 = nil
					for v662, v663 in v660 do
						if v663.uid ~= v_u_653 then
							continue
						end
						local v664 = v660[v662 + 1] or v660[v662 - 1]
						if v664 then
							v661 = v664.uid
						else
							v661 = nil
						end
					end
					if v_u_578("delete", { v_u_653 }) then
						v_u_564 = v661
						v_u_13.play("Close")
					end
				end
			else
				return
			end
		end)
		v_u_66(v649, "EquipBest").Activated:Connect(function()
			-- upvalues: (ref) v_u_578, (ref) v_u_13
			if v_u_578("equipBest") then
				v_u_13.play("Equip")
			end
		end)
		v_u_66(v649, "UnequipAll").Activated:Connect(function()
			-- upvalues: (ref) v_u_578
			v_u_578("unequipAll")
		end)
		local v665 = v649:FindFirstChild("Top")
		if v665 then
			v665 = v665:FindFirstChild("EquipPlus")
		end
		if v665 and v665:IsA("GuiButton") then
			local v666 = v665:Clone()
			v666.Name = "Lock"
			v666.Visible = true
			v666:SetAttribute("Pad", true)
			for _, v667 in v666:GetChildren() do
				if v667.Name == "PadHint" or (v667:IsA("UIScale") or v667:IsA("UIAspectRatioConstraint")) then
					v667:Destroy()
				else
					if not v667:IsA("TextLabel") then
						continue
					end
					v667.Visible = false
				end
			end
			v666.AnchorPoint = Vector2.new(0.5, 0.5)
			v666.Position = UDim2.fromScale(0.86, 0.1)
			v666.Size = UDim2.fromScale(0.22, 0.22)
			local v668 = Instance.new("UIAspectRatioConstraint")
			v668.DominantAxis = Enum.DominantAxis.Width
			v668.Parent = v666
			local v669 = 8 - v666.ZIndex
			v666.ZIndex = v666.ZIndex + v669
			for _, v670 in v666:GetDescendants() do
				if not v670:IsA("GuiObject") then
					continue
				end
				v670.ZIndex = v670.ZIndex + v669
			end
			local v671 = Instance.new("ImageLabel")
			v671.Name = "Padlock"
			v671.BackgroundTransparency = 1
			v671.Image = v_u_37.Icon.Lock
			v671.ScaleType = Enum.ScaleType.Fit
			v671.AnchorPoint = Vector2.new(0.5, 0.5)
			v671.Position = UDim2.fromScale(0.5, 0.5)
			v671.Size = UDim2.fromScale(0.74, 0.74)
			v671.ZIndex = v666.ZIndex + 3
			v671.Interactable = false
			v671.Parent = v666
			v666.Parent = v650
			v_u_570 = v666
			v666.Activated:Connect(function()
				-- upvalues: (ref) v_u_564, (ref) v_u_14, (ref) v_u_578, (ref) v_u_13, (ref) v_u_249
				local v672 = v_u_564
				if v672 and v_u_14.pets()[v672] then
					local v673 = v_u_14.lockedPets()[v672] ~= true
					if v_u_578("lock", {
						["uid"] = v672,
						["on"] = v673
					}) then
						v_u_13.play("Equip")
						v_u_249(v673 and "Pet locked: it can\'t be deleted or fused" or "Pet unlocked")
					end
				end
			end)
		end
		local v674 = v_u_66(v649, "UnequipAll")
		local v_u_675 = v674:Clone()
		v_u_675.Name = "DeleteUnlocked"
		v_u_675:SetAttribute("Pad", true)
		for _, v676 in v_u_675:GetChildren() do
			if not v676:IsA("UIScale") and v676.Name ~= "PadHint" then
				continue
			end
			v676:Destroy()
		end
		local v677 = v_u_675:FindFirstChild("TextLabel")
		if v677 and v677:IsA("TextLabel") then
			v677.Text = "DELETE UNLOCKED"
		end
		v_u_675.Parent = v649
		for v678, v679 in { v_u_66(v649, "EquipBest"), v674, v_u_675 } do
			v679.Size = UDim2.new(0.19, 0, v679.Size.Y.Scale, v679.Size.Y.Offset)
			v679.Position = UDim2.new(0.125 + (v678 - 1) * 0.205, 0, v679.Position.Y.Scale, v679.Position.Y.Offset)
		end
		v_u_675.Activated:Connect(function()
			-- upvalues: (ref) v_u_571, (copy) v_u_675, (ref) v_u_578, (ref) v_u_13, (ref) v_u_249, (ref) v_u_35, (ref) v_u_14, (ref) v_u_33
			local v680 = v_u_571
			if v680 then
				v_u_571 = nil
				local v681 = v_u_675:FindFirstChild("TextLabel")
				if v681 and v681:IsA("TextLabel") then
					v681.Text = "DELETE UNLOCKED"
				end
				local v682, v683 = v_u_578("deleteUnlocked", v680)
				if v682 and type(v683) == "number" then
					v_u_13.play("Close")
					v_u_249((("Deleted %* pet%*"):format(v683, v683 == 1 and "" or "s")))
				end
				return
			else
				local v_u_684 = v_u_35.toDelete(v_u_14.pets(), v_u_14.lockedPets(), v_u_14.equipped(), nil, v_u_14.petTiers())
				if #v_u_684 == 0 then
					v_u_249("Nothing to delete: Mythic, fused, locked and equipped pets are kept")
					v_u_13.play("Error")
				else
					v_u_571 = v_u_684
					local v685 = v_u_675
					local v686 = ("DELETE %* PET%*?"):format(#v_u_684, #v_u_684 == 1 and "" or "S")
					local v687 = v685:FindFirstChild("TextLabel")
					if v687 and v687:IsA("TextLabel") then
						v687.Text = v686
					end
					local v688 = v_u_14.pets()
					local v689 = 0
					for _, v690 in v_u_684 do
						local v691 = v_u_33.byId[v688[v690] or ""]
						if not v691 or v691.rarity ~= "Legendary" then
							continue
						end
						v689 = v689 + 1
					end
					if v689 > 0 then
						v_u_249((("Includes %* Legendary pet%*: lock any you want to keep"):format(v689, v689 == 1 and "" or "s")))
					end
					v_u_13.play("Error")
					task.delay(3, function()
						-- upvalues: (ref) v_u_571, (copy) v_u_684, (ref) v_u_675
						if v_u_571 == v_u_684 then
							v_u_571 = nil
							local v692 = v_u_675:FindFirstChild("TextLabel")
							if v692 and v692:IsA("TextLabel") then
								v692.Text = "DELETE UNLOCKED"
							end
						end
					end)
				end
			end
		end)
		for _, v_u_693 in {
			{
				["name"] = "EquipPlus",
				["keys"] = nil,
				["keys"] = v_u_629
			},
			{
				["name"] = "SpacePlus",
				["keys"] = nil,
				["keys"] = v_u_630
			}
		} do
			v_u_66(v649, "Top." .. v_u_693.name).Activated:Connect(function()
				-- upvalues: (copy) v_u_693, (ref) v_u_53, (ref) v_u_15
				for _, v695 in v_u_693.keys do
					if v_u_53:GetAttribute("Pass_" .. v695) == true then
						continue
					end
				end
				local v695 = nil
				if v695 then
					v_u_15.buyPass(v695)
				end
			end)
		end
		for _, v696 in {
			"Pets",
			"Equipped",
			"EquipMax",
			"PetSpace",
			"PetTiers",
			"LockedPets"
		} do
			v_u_53:GetAttributeChangedSignal(v696):Connect(function()
				-- upvalues: (ref) v_u_251, (ref) v_u_648
				if v_u_251 == "Pets" then
					v_u_648()
				end
			end)
		end
	end
end
local v_u_698 = ""
local v_u_699 = false
local v_u_700 = nil
local v_u_701 = false
local function v_u_706(p702, p703) -- name: eggPicture
	-- upvalues: (copy) v_u_295, (copy) v_u_48
	local v704 = p702:FindFirstChild("EggPicture")
	if not (v704 and v704:IsA("ImageLabel")) then
		v704 = Instance.new("ImageLabel")
		v704.Name = "EggPicture"
		v704.BackgroundTransparency = 1
		v704.ScaleType = Enum.ScaleType.Fit
		v704.AnchorPoint = Vector2.new(0.5, 0.5)
		v704.Position = UDim2.fromScale(0.5, 0.42)
		v704.Size = UDim2.fromScale(0.82, 0.66)
		v704.ZIndex = 43
		Instance.new("UIAspectRatioConstraint").Parent = v704
		local v705 = Instance.new("UIScale")
		v705.Name = "Pop"
		v705.Parent = v704
		v704.Parent = p702
	end
	v704.Image = v_u_295(v_u_48.egg(p703, 1))
	v704.Rotation = 0
	v704.ImageTransparency = 0
	v704.Visible = true
	return v704
end
local function v_u_709(p707) -- name: clearView
	for _, v708 in p707:GetChildren() do
		if not (v708:IsA("Model") or v708:IsA("Camera")) then
			continue
		end
		v708:Destroy()
	end
end
local v_u_710 = Color3.fromRGB(255, 64, 96)
local function v_u_718(p711, p712) -- name: deletedStamp
	-- upvalues: (copy) v_u_66, (copy) v_u_710, (copy) v_u_8
	local v713 = p711:FindFirstChild("View")
	if v713 and v713:IsA("ViewportFrame") then
		v713.ImageTransparency = p712 and 0.45 or 0
	end
	local v714 = p711:FindFirstChild("AutoDeleted")
	if p712 then
		if not v714 then
			v714 = v_u_66(p711, "Name"):Clone()
			v714.Name = "AutoDeleted"
			v714.Text = "AUTO DELETED"
			v714.TextColor3 = v_u_710
			v714.AnchorPoint = Vector2.new(0.5, 0.5)
			v714.Position = UDim2.fromScale(0.5, 0.42)
			v714.Size = UDim2.fromScale(0.95, 0.12)
			v714.Rotation = -12
			v714.ZIndex = 44
			v714.Interactable = false
			local v715 = Instance.new("UIScale")
			v715.Name = "Pop"
			v715.Parent = v714
			v714.Parent = p711
		end
		if v714 and v714:IsA("GuiObject") then
			v714.Visible = true
			local v716 = v714:FindFirstChild("Pop")
			if v716 and v716:IsA("UIScale") then
				v716.Scale = 1.6
				local v717 = Enum.EasingStyle.Back
				v_u_8:Create(v716, TweenInfo.new(0.3, v717 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Scale"] = 1
				}):Play()
			end
		end
	elseif v714 and v714:IsA("GuiObject") then
		v714.Visible = false
	end
end
local function v_u_771(p719, p720, p721) -- name: hatchReveal
	-- upvalues: (ref) v_u_252, (copy) v_u_33, (ref) v_u_699, (copy) v_u_66, (copy) v_u_11, (copy) v_u_709, (copy) v_u_706, (ref) v_u_700, (copy) v_u_13, (copy) v_u_22, (copy) v_u_25, (copy) v_u_31, (copy) v_u_50, (copy) v_u_14, (copy) v_u_8, (copy) v_u_718
	local v722 = v_u_252:FindFirstChild("Overlay")
	if v722 then
		v722 = v722:FindFirstChild("Hatch")
	end
	local v723 = v_u_33.eggById[p719]
	if v722 and (v722:IsA("GuiButton") and v723) then
		v_u_699 = true
		local v724 = v_u_66(v722, "Title")
		v_u_66(v722, "Top").Text = string.upper(v723.name)
		v724.Text = not v_u_11.active() and "CLICK!" or ("PRESS %*!"):format((v_u_11.name(Enum.KeyCode.ButtonA)))
		local v725 = {}
		for v726 = 1, 3 do
			local v727 = v_u_66(v722, "Slot" .. v726)
			local v728
			if #p720 == 1 then
				v728 = v726 == 2
			else
				v728 = v726 <= #p720
			end
			v727.Visible = v728
			if v728 then
				table.insert(v725, v727)
			end
			v_u_66(v727, "Name").Text = ""
			v_u_66(v727, "Rarity").Text = ""
			v_u_66(v727, "Mult").Text = ""
			v_u_66(v727, "Rays").Visible = false
			local v729 = v727:FindFirstChild("View")
			if v729 and v729:IsA("ViewportFrame") then
				v729.ImageTransparency = 0
			end
			local v730 = v727:FindFirstChild("AutoDeleted")
			if not (v730 and v730:IsA("GuiObject")) then
				continue
			end
			v730.Visible = false
		end
		local v731 = {}
		for _, v732 in v725 do
			v_u_709((v_u_66(v732, "View")))
			local v733 = v_u_706(v732, v723.id)
			table.insert(v731, v733)
		end
		v722.Visible = true
		v_u_11.noRing(v722)
		v_u_11.select(v722)
		local v_u_734 = false
		local v735 = v722.Activated:Connect(function()
			-- upvalues: (ref) v_u_734
			v_u_734 = true
		end)
		v_u_700 = function()
			-- upvalues: (ref) v_u_734
			v_u_734 = true
		end
		local v736 = os.clock()
		local v737 = Instance.new("UIScale")
		v737.Parent = v724
		while not v_u_734 and os.clock() - v736 < 8 do
			local v738 = os.clock()
			local v739 = v738 * 4
			local v740 = math.sin(v739)
			v737.Scale = math.abs(v740) * 0.15 + 1
			for v741, v742 in v731 do
				local v743 = v738 * 3 + v741
				v742.Rotation = math.sin(v743) * 7
				local v744 = v742:FindFirstChild("Pop")
				local v745 = v738 * 2.2 + v741
				local v746 = math.sin(v745)
				v744.Scale = math.abs(v746) * 0.05 + 1
			end
			task.wait()
		end
		v735:Disconnect()
		v737:Destroy()
		v724.Text = ""
		local v747 = os.clock()
		local v748 = 0
		while os.clock() - v747 < 0.7 do
			local v749 = (os.clock() - v747) / 0.7
			for v750, v751 in v731 do
				local v752 = os.clock() * (30 + v749 * 30) + v750
				v751.Rotation = math.sin(v752) * (9 + v749 * 20)
				v751:FindFirstChild("Pop").Scale = 1 + v749 * 0.18
			end
			if os.clock() - v748 > 0.22 then
				v748 = os.clock()
				v_u_13.play("EggCrack")
			end
			task.wait()
		end
		v_u_13.play("EggOpen")
		for _, v753 in v731 do
			v753.Visible = false
		end
		for v754, v755 in v725 do
			local v756 = p720[v754]
			local v757 = v_u_33.byId[v756]
			if not v757 then
				continue
			end
			local v758 = v_u_22.build(v756)
			if v758 then
				v_u_22.show(v_u_66(v755, "View"), v758, true)
			end
			local v759 = v_u_66(v755, "Rays")
			v759.Visible = true
			v759.ImageTransparency = 0
			v759.ImageColor3 = v_u_25.color(v_u_31.RARITY_COLOR[v757.rarity] or "#FFFFFF")
			v_u_66(v755, "Name").Text = v757.name
			local v760 = v_u_66(v755, "Rarity")
			v760.Text = string.upper(v757.rarity)
			v760.TextColor3 = v759.ImageColor3
			v_u_66(v755, "Mult").Text = v_u_50.mult(v_u_33.multIn(v757, v_u_14.number("World", 1))) .. " Chakra"
			local v761 = v_u_66(v755, "View")
			local v762 = v761:FindFirstChild("Pop")
			if not (v762 and v762:IsA("UIScale")) then
				v762 = Instance.new("UIScale")
			end
			v762.Name = "Pop"
			v762.Parent = v761
			v762.Scale = 0.4
			local v763 = Enum.EasingStyle.Back
			v_u_8:Create(v762, TweenInfo.new(0.35, v763 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["Scale"] = 1
			}):Play()
			if not (p721 and p721[v754]) then
				continue
			end
			v_u_66(v755, "Mult").Text = ""
			v_u_718(v755, true)
		end
		local v764
		if p721 == nil then
			v764 = false
		else
			v764 = #p720 > 0
		end
		for v765 = 1, #p720 do
			if p721 and p721[v765] then
				continue
			end
			v764 = false
		end
		v724.Text = v764 and "AUTO DELETED!" or "YOU OBTAINED!"
		v_u_13.play("RewardLand")
		local v_u_766 = false
		local v767 = v722.Activated:Connect(function()
			-- upvalues: (ref) v_u_766
			v_u_766 = true
		end)
		v_u_700 = function()
			-- upvalues: (ref) v_u_766
			v_u_766 = true
		end
		local v768 = os.clock()
		while not v_u_766 and os.clock() - v768 < 3 do
			for _, v769 in v725 do
				local v770 = v769:FindFirstChild("Rays")
				if not (v770 and v770:IsA("GuiObject")) then
					continue
				end
				v770.Rotation = os.clock() * 40 % 360
			end
			task.wait()
		end
		v767:Disconnect()
		v_u_700 = nil
		if v_u_11.selected() == v722 then
			v_u_11.clear()
		end
		v722.Visible = false
		v_u_699 = false
	end
end
local function v_u_776(p772) -- name: autoToggle
	-- upvalues: (copy) v_u_35, (ref) v_u_249, (copy) v_u_13, (copy) v_u_14, (copy) v_u_578
	if v_u_35.canAutoDeleteKind(p772.id) then
		local v773 = v_u_14.autoDelete()[p772.id] ~= true
		if v_u_578("autoDelete", {
			["kind"] = p772.id,
			["on"] = v773
		}) then
			v_u_13.play(v773 and "Close" or "Equip")
			local v774 = v_u_249
			local v775
			if v773 then
				v775 = ("%* will be deleted when you hatch it"):format(p772.name)
			else
				v775 = ("%* will be kept again"):format(p772.name)
			end
			v774(v775)
		end
	else
		v_u_249((("%* pets are never auto deleted"):format(p772.rarity)))
		v_u_13.play("Error")
	end
end
local function v_u_780(p777) -- name: cardStamp
	-- upvalues: (copy) v_u_66, (copy) v_u_710
	local v778 = p777:FindFirstChild("View")
	if v778 and v778:IsA("ViewportFrame") then
		v778.ImageTransparency = 0.5
	end
	local v779 = v_u_66(p777, "Chance"):Clone()
	v779.Name = "AutoDelete"
	v779.Text = "DELETE"
	v779.TextColor3 = v_u_710
	v779.AnchorPoint = Vector2.new(0.5, 0.5)
	v779.Position = UDim2.fromScale(0.5, 0.38)
	v779.Size = UDim2.fromScale(1.02, 0.24)
	v779.Rotation = -14
	v779.ZIndex = 8
	v779.Interactable = false
	v779.Parent = p777
end
local function v_u_784(p781) -- name: autoHint
	-- upvalues: (copy) v_u_66
	local v782 = p781:FindFirstChild("AutoHint")
	if v782 and v782:IsA("TextLabel") then
		return v782
	end
	local v783 = v_u_66(p781, "Free"):Clone()
	v783.Name = "AutoHint"
	v783.Text = "TAP A PET TO\nAUTO DELETE IT"
	v783.TextColor3 = Color3.new(1, 1, 1)
	v783.AnchorPoint = Vector2.new(0.5, 0.5)
	v783.Position = UDim2.fromScale(0.17, 0.74)
	v783.Size = UDim2.fromScale(0.28, 0.1)
	v783.Parent = p781
	return v783
end
local function v_u_788(p785, p786) -- name: luckNote
	-- upvalues: (copy) v_u_66
	local v787 = p785:FindFirstChild("LuckNote")
	if p786 > 1 or v787 then
		if not (v787 and v787:IsA("TextLabel")) then
			v787 = v_u_66(p785, "Free"):Clone()
			v787.Name = "LuckNote"
			v787.AnchorPoint = Vector2.new(0.5, 0.5)
			v787.Position = UDim2.fromScale(0.83, 0.74)
			v787.Size = UDim2.fromScale(0.28, 0.1)
			v787.TextColor3 = Color3.fromRGB(120, 245, 100)
			v787.Parent = p785
		end
		v787.Text = ("x%* LUCK!"):format(p786)
		v787.Visible = p786 > 1
	end
end
local function v_u_827() -- name: refreshEgg
	-- upvalues: (ref) v_u_247, (copy) v_u_33, (ref) v_u_698, (copy) v_u_19, (copy) v_u_66, (copy) v_u_256, (copy) v_u_27, (copy) v_u_30, (copy) v_u_788, (copy) v_u_14, (copy) v_u_784, (ref) v_u_56, (copy) v_u_22, (copy) v_u_776, (copy) v_u_780, (copy) v_u_15, (copy) v_u_50, (copy) v_u_16
	local v789 = v_u_247:FindFirstChild("Egg")
	if not (v789 and v789:IsA("Frame")) then
		v789 = nil
	end
	local v790 = v_u_33.eggById[v_u_698]
	if v789 and v790 then
		v_u_19.setText(v_u_66(v789, "Top"), v790.name)
		local v791 = v_u_66(v789, "Pool")
		v_u_256(v791)
		local v792 = v_u_27.tier()
		local v795 = v_u_30.chances(v790.pool, function(p793)
			-- upvalues: (ref) v_u_33
			local v794 = v_u_33.byId[p793]
			return not v794 and "Common" or v794.rarity
		end, v792)
		v_u_788(v789, v792)
		local v796 = v790.product == nil
		local v797 = v_u_14.autoDelete()
		v_u_784(v789).Visible = v796
		for v798, v799 in v790.pool do
			local v_u_800 = v_u_33.byId[v799.pet]
			if not v_u_800 then
				continue
			end
			local v801 = v_u_66(v_u_56, "ChanceCard"):Clone()
			v801.Visible = true
			v801.LayoutOrder = v798
			v801.Size = UDim2.fromScale(0.18, 0.95)
			v801.Position = UDim2.new()
			v801.AnchorPoint = Vector2.zero
			v_u_19.paint(v801, v_u_800.rarity)
			v_u_66(v801, "Chance").Text = v_u_30.percent(v795[v798] or 0)
			local v802 = v_u_22.build(v_u_800.id)
			if v802 then
				v_u_22.show(v_u_66(v801, "View"), v802, false)
			end
			if v796 and v801:IsA("GuiButton") then
				v801.Active = true
				v801:SetAttribute("Pad", true)
				v801:SetAttribute("Ui-Hover", "Expand")
				v801:SetAttribute("Ui-Hover-Rate", 1.06)
				v801:SetAttribute("Ui-Click", "In")
				v801:SetAttribute("Ui-Click-Rate", 0.92)
				v801.Activated:Connect(function()
					-- upvalues: (ref) v_u_776, (copy) v_u_800
					v_u_776(v_u_800)
				end)
				if v797[v_u_800.id] then
					v_u_780(v801)
				end
			end
			v801.Parent = v791
		end
		local v803 = v790.product
		local v804
		if v803 then
			v804 = v_u_15.product(v803 .. "1")
		else
			v804 = nil
		end
		local v805
		if v803 then
			v805 = v_u_15.product(v803 .. "3")
		else
			v805 = nil
		end
		local v806 = v_u_66(v789, "Cost")
		local v807
		if v804 then
			local v808 = v_u_15.ROBUX
			local v809 = v804.price
			v807 = v808 .. " " .. tostring(v809)
		else
			v807 = v_u_50.short(v790.cost)
		end
		v806.Text = v807
		v_u_66(v789, "CostIcon").Visible = not v803
		local v810 = v_u_14.freeEggs(v790.id)
		v_u_66(v789, "Free").Text = v810 <= 0 and "" or ("%* FREE HATCH%*!"):format(v810, v810 > 1 and "ES" or "")
		if v804 and v805 then
			local v811 = v_u_66(v789, "Hatch1")
			local v812 = v804.price
			local v813 = "x1  R$" .. tostring(v812)
			local v814 = v811:FindFirstChild("TextLabel")
			if v814 and v814:IsA("TextLabel") then
				v814.Text = v813
			end
			local v815 = v_u_66(v789, "Hatch3")
			local v816 = v805.price
			local v817 = "x3  R$" .. tostring(v816)
			local v818 = v815:FindFirstChild("TextLabel")
			if v818 and v818:IsA("TextLabel") then
				v818.Text = v817
			end
		else
			local v819 = v_u_66(v789, "Hatch1")
			local v820 = v810 >= 1 and "FREE x1" or "HATCH x1"
			local v821 = v819:FindFirstChild("TextLabel")
			if v821 and v821:IsA("TextLabel") then
				v821.Text = v820
			end
			local v822 = v_u_66(v789, "Hatch3")
			local v823 = v810 >= 3 and "FREE x3" or "HATCH x3"
			local v824 = v822:FindFirstChild("TextLabel")
			if v824 and v824:IsA("TextLabel") then
				v824.Text = v823
			end
		end
		local v825 = v_u_16.eggButton
		local v826
		if v804 then
			v826 = v804.key
		else
			v826 = nil
		end
		v825(v789, v826)
	end
end
local v_u_828 = {}
function v_u_52.onHatchDone(p829) -- name: onHatchDone
	-- upvalues: (copy) v_u_828
	local v830 = v_u_828
	table.insert(v830, p829)
end
function v_u_52.openEgg(p831, p832) -- name: openEgg
	-- upvalues: (copy) v_u_33, (ref) v_u_699, (ref) v_u_698, (ref) v_u_251, (copy) v_u_52, (copy) v_u_827
	local v833 = v_u_33.eggsFor(p832)[p831]
	if v_u_699 or not v833 then
		return
	else
		v_u_698 = v833.id
		if v_u_251 == "Egg" then
			v_u_827()
		else
			v_u_52.open("Egg")
		end
	end
end
function v_u_52.leaveEgg() -- name: leaveEgg
	-- upvalues: (ref) v_u_251, (ref) v_u_699, (copy) v_u_52
	if v_u_251 == "Egg" and not v_u_699 then
		v_u_52.close()
	end
end
local function v_u_866() -- name: bindEggs
	-- upvalues: (ref) v_u_247, (copy) v_u_20, (copy) v_u_33, (ref) v_u_701, (ref) v_u_699, (copy) v_u_52, (copy) v_u_771, (copy) v_u_828, (copy) v_u_60, (copy) v_u_827, (copy) v_u_53, (ref) v_u_251, (copy) v_u_66, (ref) v_u_698, (copy) v_u_14, (ref) v_u_249, (copy) v_u_13, (copy) v_u_15, (copy) v_u_578
	local v834 = v_u_247:FindFirstChild("Egg")
	if not (v834 and v834:IsA("Frame")) then
		v834 = nil
	end
	if v834 then
		v_u_20.onNotify("Hatched", function(p835)
			-- upvalues: (ref) v_u_33, (ref) v_u_701, (ref) v_u_699, (ref) v_u_52, (ref) v_u_771, (ref) v_u_828
			if type(p835) == "table" then
				local v836 = p835.egg
				local v837 = p835.kinds
				local v_u_838
				if type(v836) == "string" then
					v_u_838 = v_u_33.eggById[v836]
				else
					v_u_838 = nil
				end
				if v_u_838 and type(v837) == "table" then
					local v_u_839 = {}
					for _, v840 in v837 do
						if type(v840) ~= "string" then
							continue
						end
						table.insert(v_u_839, v840)
					end
					task.spawn(function()
						-- upvalues: (ref) v_u_701, (ref) v_u_699, (ref) v_u_52, (copy) v_u_839, (ref) v_u_771, (copy) v_u_838, (ref) v_u_828
						while v_u_701 or v_u_699 do
							task.wait(0.2)
						end
						v_u_52.close()
						for v841 = 1, #v_u_839, 3 do
							local v842 = v_u_771
							local v843 = v_u_838.id
							local v844 = {}
							local v845 = v_u_839
							local v846 = v841 + 2
							local v847 = #v_u_839
							local v848 = math.min(v846, v847)
							__set_list(v844, 1, {table.unpack(v845, v841, v848)})
							v842(v843, v844)
						end
						for _, v849 in v_u_828 do
							task.spawn(v849)
						end
					end)
				end
			else
				return
			end
		end)
		v_u_60.Egg = v_u_827
		for _, v850 in { "FreeEggs", "AutoDeletePets" } do
			v_u_53:GetAttributeChangedSignal(v850):Connect(function()
				-- upvalues: (ref) v_u_251, (ref) v_u_827
				if v_u_251 == "Egg" then
					v_u_827()
				end
			end)
		end
		local v_u_851 = false
		for v852, v_u_853 in {
			["Hatch1"] = 1,
			["Hatch3"] = 3
		} do
			v_u_66(v834, v852).Activated:Connect(function()
				-- upvalues: (ref) v_u_33, (ref) v_u_698, (ref) v_u_699, (ref) v_u_851, (ref) v_u_14, (copy) v_u_853, (ref) v_u_249, (ref) v_u_13, (ref) v_u_15, (ref) v_u_578, (ref) v_u_52, (ref) v_u_771, (ref) v_u_828
				local v854 = v_u_33.eggById[v_u_698]
				if v854 and not (v_u_699 or v_u_851) then
					if v854.product then
						local v855 = 0
						for _ in v_u_14.pets() do
							v855 = v855 + 1
						end
						if v_u_14.number("PetSpace", v_u_33.SPACE) - v855 < v_u_853 then
							v_u_249("Your pet storage is full! Delete some pets first")
							v_u_13.play("Error")
						else
							local v856 = v_u_853
							v_u_15.buyProduct(v854.product .. tostring(v856))
						end
					else
						v_u_851 = true
						local v857, v858 = v_u_578("hatch", {
							["egg"] = v854.id,
							["count"] = v_u_853
						})
						v_u_851 = false
						if v857 and type(v858) == "table" then
							local v_u_859 = {}
							local v_u_860 = {}
							for _, v861 in v858 do
								if type(v861) ~= "table" then
									continue
								end
								local v862 = v861.kind
								if type(v862) ~= "string" then
									continue
								end
								table.insert(v_u_859, v862)
								local v863 = v861.deleted == true
								table.insert(v_u_860, v863)
							end
							local v_u_864 = v_u_698
							v_u_52.close()
							task.spawn(function()
								-- upvalues: (ref) v_u_771, (copy) v_u_864, (copy) v_u_859, (copy) v_u_860, (ref) v_u_828
								v_u_771(v_u_864, v_u_859, v_u_860)
								for _, v865 in v_u_828 do
									task.spawn(v865)
								end
							end)
						end
					end
				else
					return
				end
			end)
		end
	end
end
local function v_u_872(p867) -- name: worldOpen
	-- upvalues: (copy) v_u_44, (copy) v_u_14
	if p867 <= 1 then
		return true
	end
	local v868 = v_u_44[p867]
	if not (v868 and v868.ready) then
		return false
	end
	local v869
	if p867 - 1 == 1 then
		v869 = v_u_14.number("BestStage")
	else
		local v870 = v_u_14.number
		local v871 = p867 - 1
		v869 = v870("BestStage" .. tostring(v871))
	end
	return v868.needStage == nil and true or v868.needStage <= v869
end
local function v_u_920() -- name: refreshEyes
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_14, (copy) v_u_31, (ref) v_u_56, (copy) v_u_19, (copy) v_u_54, (copy) v_u_37, (copy) v_u_50, (copy) v_u_29, (copy) v_u_13, (copy) v_u_15, (copy) v_u_52, (copy) v_u_872, (ref) v_u_249
	local v873 = v_u_247:FindFirstChild("MyEyes")
	if not (v873 and v873:IsA("Frame")) then
		v873 = nil
	end
	if v873 then
		local v874 = v_u_66(v873, "Grid")
		for _, v875 in v874:GetChildren() do
			if not v875:IsA("GuiObject") then
				continue
			end
			v875:Destroy()
		end
		local v876 = v_u_14.eyes()
		local v877 = v_u_14.string("Eye")
		local v_u_878 = v_u_31.nextLocked(v876, v_u_14.number("World", 1))
		local v879 = v_u_14.number("TotalWins")
		for v880, v_u_881 in v_u_31.list do
			if not v_u_31.listed(v876, v_u_881) then
				continue
			end
			local v882 = v_u_66(v_u_56, "EyeCard"):Clone()
			v882.Visible = true
			v882.LayoutOrder = v880
			local v883 = v876[v_u_881.id] ~= nil
			v_u_19.paint(v882, v_u_881.rarity)
			v_u_66(v882, "DayText").Text = v_u_881.short
			local v884 = v_u_66(v882, "Decor.Icon")
			v884.Image = v_u_54[v_u_881.id] or v_u_37.Iris.sharingan
			local v885
			if v883 then
				v885 = Color3.new(1, 1, 1)
			else
				v885 = Color3.fromRGB(70, 70, 80)
			end
			v884.ImageColor3 = v885
			if not v884:FindFirstChildOfClass("UIAspectRatioConstraint") then
				Instance.new("UIAspectRatioConstraint").Parent = v884
			end
			v_u_66(v882, "RewardText").Text = v_u_50.mult(v_u_31.multIn(v_u_881, v_u_14.number("World", 1))) .. " Chakra"
			local v886 = v_u_66(v882, "Redeem")
			local v887 = v_u_66(v882, "Locked")
			v886.Visible = v883
			v887.Visible = not v883
			if v883 then
				local v888 = v877 == v_u_881.id and "EQUIPPED" or "EQUIP"
				local v889 = v886:FindFirstChild("TextLabel")
				if v889 and v889:IsA("TextLabel") then
					v889.Text = v888
				end
				v886.Activated:Connect(function()
					-- upvalues: (ref) v_u_14, (copy) v_u_881, (ref) v_u_29, (ref) v_u_13
					if v_u_14.string("Eye") ~= v_u_881.id then
						v_u_29.event("Equip"):FireServer(v_u_881.id)
						v_u_13.play("Equip")
					end
				end)
			elseif v_u_881.pass then
				local v890 = v_u_15.pass(v_u_881.pass)
				local v891 = v_u_15.ROBUX
				local v892 = not v890 and "?" or v890.price
				local v893 = v891 .. " " .. tostring(v892)
				local v894 = v887:FindFirstChild("TextLabel")
				if v894 and v894:IsA("TextLabel") then
					v894.Text = v893
				end
				v887.Activated:Connect(function()
					-- upvalues: (ref) v_u_15, (copy) v_u_881
					v_u_15.buyPass(v_u_881.pass or "")
				end)
			elseif v_u_881.boss then
				local v895 = v_u_50.commas(v_u_881.boss) .. " COINS"
				local v896 = v887:FindFirstChild("TextLabel")
				if v896 and v896:IsA("TextLabel") then
					v896.Text = v895
				end
				local v897 = Color3.fromRGB(255, 168, 52)
				local v898 = Color3.fromRGB(222, 64, 24)
				local v899 = v887:FindFirstChildOfClass("UIGradient")
				if v899 then
					v899.Color = ColorSequence.new(v897, v898)
				end
				v887.Activated:Connect(function()
					-- upvalues: (ref) v_u_52
					v_u_52.open("BossShop")
				end)
			else
				local v_u_900 = v_u_872(v_u_881.world or 1)
				local v901
				if v_u_900 then
					v901 = v_u_881.wins <= v879
				else
					v901 = v_u_900
				end
				local v902
				if v901 then
					v902 = "UNLOCK"
				elseif v_u_900 then
					v902 = v_u_50.short(v_u_881.wins) .. " TROPHIES"
				else
					local v903 = v_u_881.world or 1
					v902 = "WORLD " .. tostring(v903)
				end
				local v904 = v887:FindFirstChild("TextLabel")
				if v904 and v904:IsA("TextLabel") then
					v904.Text = v902
				end
				if v901 then
					local v905 = Color3.fromRGB(124, 255, 107)
					local v906 = Color3.fromRGB(30, 170, 60)
					local v907 = v887:FindFirstChildOfClass("UIGradient")
					if v907 then
						v907.Color = ColorSequence.new(v905, v906)
					end
				end
				v887.Activated:Connect(function()
					-- upvalues: (copy) v_u_900, (ref) v_u_13, (ref) v_u_249, (copy) v_u_881, (ref) v_u_14, (ref) v_u_29, (ref) v_u_50, (ref) v_u_15, (copy) v_u_878
					if v_u_900 then
						if v_u_14.number("TotalWins") >= v_u_881.wins then
							v_u_29.event("UnlockEye"):FireServer(v_u_881.id)
							v_u_13.play("Equip")
							return
						else
							v_u_249("You need " .. v_u_50.short(v_u_881.wins) .. " total Trophies for " .. v_u_881.short)
							local v908 = v_u_15.product("skipEye")
							if v_u_878 and (v908 and v908.id ~= 0) then
								if v_u_878.id ~= v_u_881.id then
									v_u_249("Skip to " .. v_u_878.short .. " now!")
								end
								v_u_15.buyProduct("skipEye")
							else
								v_u_13.play("Error")
								v_u_15.offer("trophies", "My Eyes")
							end
						end
					else
						v_u_13.play("Error")
						local v909 = v_u_249
						local v910 = v_u_881.world or 1
						v909("Reach World " .. tostring(v910) .. " to unlock " .. v_u_881.short)
						return
					end
				end)
				local v911 = v_u_15.product("skipEye")
				if not v901 and (v_u_878 and (v_u_878.id == v_u_881.id and (v911 and v911.id ~= 0))) then
					local v912 = v887:Clone()
					v912.Name = "Buy"
					v912.AnchorPoint = Vector2.new(0.5, 0.5)
					v912.Size = UDim2.fromScale(0.46, 0.14)
					v912.Position = UDim2.fromScale(0.74, 0.27)
					v912.ZIndex = v912.ZIndex + 2
					local v913 = v_u_15.ROBUX
					local v914 = v911.price
					local v915 = v913 .. " " .. tostring(v914)
					local v916 = v912:FindFirstChild("TextLabel")
					if v916 and v916:IsA("TextLabel") then
						v916.Text = v915
					end
					local v917 = Color3.fromRGB(255, 215, 60)
					local v918 = Color3.fromRGB(255, 140, 0)
					local v919 = v912:FindFirstChildOfClass("UIGradient")
					if v919 then
						v919.Color = ColorSequence.new(v917, v918)
					end
					v912.Activated:Connect(function()
						-- upvalues: (ref) v_u_15
						v_u_15.buyProduct("skipEye")
					end)
					v912.Parent = v882
				end
			end
			v882.Parent = v874
		end
	end
end
local function v_u_930() -- name: refreshRebirth
	-- upvalues: (ref) v_u_247, (copy) v_u_14, (copy) v_u_49, (copy) v_u_66, (copy) v_u_50
	local v921 = v_u_247:FindFirstChild("Rebirths")
	if not (v921 and v921:IsA("Frame")) then
		v921 = nil
	end
	if v921 then
		local v922 = v_u_14.number("Rebirths")
		local v923 = v_u_49.rebirthLevel(v922)
		local v924 = v_u_14.number("RebirthProgress")
		v_u_66(v921, "MainDescription").Text = ("Chakra multiplier %* -> <font color=\"#7CFF6B\">%*</font>\nNeeds level %*. Resets your Level and Chakra."):format(v_u_50.mult(v_u_49.rebirthMult(v922)), v_u_50.mult(v_u_49.rebirthMult(v922 + 1)), v923)
		v_u_66(v921, "MainDescription").RichText = true
		v_u_66(v921, "Progress.Fill").Size = UDim2.fromScale(math.clamp(v924, 0.02, 1), 1)
		local v925 = v_u_66(v921, "Progress.Text")
		local v926 = v924 * 100
		v925.Text = math.floor(v926) .. "%"
		local v927 = v_u_66(v921, "Redeem")
		local v928 = v923 <= v_u_14.number("Level", 1) and "REBIRTH" or "LEVEL " .. v923
		local v929 = v927:FindFirstChild("TextLabel")
		if v929 and v929:IsA("TextLabel") then
			v929.Text = v928
		end
	end
end
local function v_u_943() -- name: bindRebirth
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_29, (copy) v_u_13, (ref) v_u_249, (copy) v_u_14, (copy) v_u_49, (copy) v_u_15, (copy) v_u_930, (copy) v_u_53, (copy) v_u_60, (ref) v_u_251
	local v931 = v_u_247:FindFirstChild("Rebirths")
	if not (v931 and v931:IsA("Frame")) then
		v931 = nil
	end
	if v931 then
		v_u_66(v931, "Redeem").Activated:Connect(function()
			-- upvalues: (ref) v_u_29, (ref) v_u_13, (ref) v_u_249, (ref) v_u_14, (ref) v_u_49, (ref) v_u_15, (ref) v_u_930
			local function v932()
				-- upvalues: (ref) v_u_29
				return v_u_29.func("Rebirth"):InvokeServer()
			end
			local v933, v934, v935 = pcall(v932)
			if not v933 or v934 ~= true then
				v_u_13.play("Error")
				if type(v935) == "string" then
					v_u_249(v935)
				end
				if v_u_14.number("Level", 1) < v_u_49.rebirthLevel(v_u_14.number("Rebirths")) then
					v_u_15.offer("rebirth")
				end
			end
			v_u_930()
		end)
		local v_u_936 = v_u_66(v931, "Auto")
		local function v940() -- name: autoText
			-- upvalues: (copy) v_u_936, (ref) v_u_53
			local v937 = v_u_936
			local v938 = v_u_53:GetAttribute("AutoRebirth") == true and (v_u_53:GetAttribute("AutoRebirthOn") == true and "AUTO: ON" or "AUTO: OFF") or "AUTO REBIRTH"
			local v939 = v937:FindFirstChild("TextLabel")
			if v939 and v939:IsA("TextLabel") then
				v939.Text = v938
			end
		end
		v_u_14.watch("AutoRebirth", v940)
		v_u_14.watch("AutoRebirthOn", v940)
		v_u_936.Activated:Connect(function()
			-- upvalues: (ref) v_u_53, (ref) v_u_15, (ref) v_u_29
			if v_u_53:GetAttribute("AutoRebirth") == true then
				local v_u_941 = v_u_53:GetAttribute("AutoRebirthOn") ~= true
				local function v942()
					-- upvalues: (ref) v_u_29, (copy) v_u_941
					return v_u_29.func("AutoRebirth"):InvokeServer(v_u_941)
				end
				pcall(v942)
			else
				v_u_15.buyPass("autoRebirth")
			end
		end)
		v_u_66(v931, "Skip").Activated:Connect(function()
			-- upvalues: (ref) v_u_15
			v_u_15.buyProduct("skipRebirth")
		end)
		v_u_60.Rebirths = v_u_930
		v_u_14.watch("RebirthProgress", function()
			-- upvalues: (ref) v_u_251, (ref) v_u_930
			if v_u_251 == "Rebirths" then
				v_u_930()
			end
		end)
	end
end
local v_u_944 = {
	["Common"] = "Common",
	["Rare"] = "Rare",
	["Epic"] = "Epic",
	["Legendary"] = "Legendary",
	["Mythic"] = "Mythic"
}
local function v_u_952(p945, p946, p947, p948) -- name: fillCell
	-- upvalues: (copy) v_u_19, (copy) v_u_944, (copy) v_u_66, (copy) v_u_295, (copy) v_u_48, (copy) v_u_288
	v_u_19.paint(p945, v_u_944[p947] or "Common")
	v_u_66(p945, "Icon").Image = v_u_295(p946)
	local v949 = v_u_66(p945, "Label")
	local v950
	if p946.kind == "egg" then
		local v951 = p946.count or 1
		v950 = "x" .. tostring(v951)
	else
		v950 = v_u_48.label(p946, v_u_288())
	end
	v949.Text = v950
	v_u_66(p945, "Chance").Text = p948
end
local function v_u_982(p_u_953, p_u_954, p_u_955, p_u_956) -- name: spin
	-- upvalues: (ref) v_u_252, (ref) v_u_701, (copy) v_u_66, (copy) v_u_256, (copy) v_u_48, (ref) v_u_56, (copy) v_u_952, (copy) v_u_4, (copy) v_u_13, (copy) v_u_8, (copy) v_u_303, (copy) v_u_21
	local v_u_957 = v_u_252:FindFirstChild("Overlay")
	if v_u_957 then
		v_u_957 = v_u_957:FindFirstChild("Spin")
	end
	if v_u_957 and v_u_957:IsA("GuiButton") then
		v_u_701 = true
		local v958 = v_u_66(v_u_957, "Band")
		local v_u_959 = v_u_66(v958, "Strip")
		local v_u_960 = v_u_66(v_u_957, "Result")
		v_u_960.Text = ""
		v_u_256(v_u_959)
		local v_u_961 = v958.AbsoluteSize.Y * 0.9
		local v_u_962 = v_u_961 * 0.08
		local v963 = Random.new()
		local v_u_964 = {}
		for v965 = 1, 44 do
			local v966
			if v965 == 38 then
				v966 = p_u_953[p_u_954]
			else
				v966 = v_u_48.pick(p_u_953, v963:NextNumber())
			end
			local v967 = v_u_66(v_u_56, "SpinCell"):Clone()
			v967.Visible = true
			v967.Size = UDim2.fromOffset(v_u_961, v_u_961)
			v967.AnchorPoint = Vector2.new(0.5, 0.5)
			v967.Position = UDim2.new(0, (v965 - 1) * (v_u_961 + v_u_962) + v_u_961 / 2, 0.5, 0)
			v_u_952(v967, v966.prize, v966.rarity, "")
			v967.Parent = v_u_959
			table.insert(v_u_964, v967)
		end
		v_u_957.Visible = true
		local v_u_968 = v958.AbsoluteSize.X / 2
		local v_u_969 = v_u_968 - (37 * (v_u_961 + v_u_962) + v_u_961 / 2) + (v963:NextNumber() - 0.5) * v_u_961 * 0.6
		local v_u_970 = os.clock()
		local v_u_971 = 0
		v_u_959.Position = UDim2.new(0, v_u_968, 0.05, 0)
		local v_u_972 = nil
		v_u_972 = v_u_4.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_970, (copy) v_u_968, (copy) v_u_969, (copy) v_u_959, (copy) v_u_968, (copy) v_u_961, (copy) v_u_962, (ref) v_u_971, (ref) v_u_13, (ref) v_u_972, (copy) v_u_964, (ref) v_u_8, (copy) p_u_953, (copy) p_u_954, (copy) v_u_960, (ref) v_u_303, (copy) p_u_956, (ref) v_u_21, (copy) v_u_957, (ref) v_u_701, (copy) p_u_955
			local v973 = (os.clock() - v_u_970) / 4.2
			local v974 = math.clamp(v973, 0, 1)
			local v975 = 1 - (1 - v974) ^ 4
			local v976 = v_u_968 + (v_u_969 - v_u_968) * v975
			v_u_959.Position = UDim2.new(0, v976, 0.05, 0)
			local v977 = (v_u_968 - v976) / (v_u_961 + v_u_962)
			local v978 = math.floor(v977) + 1
			if v978 ~= v_u_971 then
				v_u_971 = v978
				v_u_13.play("RouletteTick", {
					["vary"] = 0.1
				})
			end
			if v974 >= 1 then
				v_u_972:Disconnect()
				local v979 = v_u_964[38]
				if v979 then
					local v980 = Instance.new("UIScale")
					v980.Parent = v979
					v980.Scale = 1.25
					local v981 = Enum.EasingStyle.Back
					v_u_8:Create(v980, TweenInfo.new(0.35, v981 or Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Scale"] = 1.1
					}):Play()
				end
				v_u_13.play(p_u_953[p_u_954].prize.kind == "boost" and "Boost" or "RewardLand")
				v_u_960.Text = "YOU GOT " .. string.upper(v_u_303(p_u_953[p_u_954].prize)) .. "!"
				if p_u_956 then
					p_u_956(v_u_21.centreOf(v979))
				end
				task.delay(1.6, function()
					-- upvalues: (ref) v_u_957, (ref) v_u_701, (ref) p_u_955
					v_u_957.Visible = false
					v_u_701 = false
					p_u_955()
				end)
			end
		end)
	else
		if p_u_956 then
			p_u_956(nil)
		end
		p_u_955()
	end
end
local v_u_983 = {}
local function v_u_985() -- name: fillGiftCells
	-- upvalues: (copy) v_u_983, (copy) v_u_952
	for _, v984 in v_u_983 do
		v_u_952(v984.cell, v984.drop.prize, v984.drop.rarity, v984.chance)
	end
end
local function v_u_1022() -- name: bindRewards
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_40, (ref) v_u_56, (copy) v_u_48, (copy) v_u_983, (copy) v_u_952, (ref) v_u_701, (copy) v_u_21, (copy) v_u_29, (copy) v_u_52, (copy) v_u_982, (copy) v_u_13, (ref) v_u_249, (ref) v_u_251, (copy) v_u_14
	local v986 = v_u_247:FindFirstChild("Rewards")
	if not (v986 and v986:IsA("Frame")) then
		v986 = nil
	end
	if v986 then
		local v_u_987 = v_u_66(v986, "Holder")
		for v_u_988, v_u_989 in v_u_40 do
			local v990 = v_u_987:FindFirstChild((tostring(v_u_988)))
			if not v990 then
				continue
			end
			local v991 = Color3.fromHex(v_u_989.color)
			local v992 = v990:FindFirstChildOfClass("UIGradient")
			if v992 then
				v992.Color = ColorSequence.new(v991:Lerp(Color3.new(1, 1, 1), 0.25), v991:Lerp(Color3.new(0, 0, 0), 0.3))
			end
			v_u_66(v990, "Title").Text = v_u_989.name
			v_u_66(v990, "Icon").Image = v_u_989.icon
			local v993 = v_u_66(v990, "Drops")
			for v994, v995 in v_u_989.drops do
				local v996 = v_u_66(v_u_56, "DropCell"):Clone()
				v996.Visible = true
				v996.LayoutOrder = v994
				local v997 = v_u_48.chance(v_u_989.drops, v995)
				local v998 = {
					["cell"] = v996,
					["drop"] = v995
				}
				local v999
				if v997 < 1 then
					v999 = string.format("%.1f%%", v997)
				else
					local v1000 = string.format
					local v1001 = v997 + 0.5
					v999 = v1000("%d%%", (math.floor(v1001)))
				end
				v998.chance = v999
				local v1002 = v_u_983
				table.insert(v1002, v998)
				v_u_952(v996, v995.prize, v995.rarity, v998.chance)
				v996.Parent = v993
			end
			v_u_66(v990, "Claim").Activated:Connect(function()
				-- upvalues: (ref) v_u_701, (ref) v_u_21, (ref) v_u_29, (copy) v_u_988, (ref) v_u_52, (ref) v_u_982, (copy) v_u_989, (ref) v_u_13, (ref) v_u_249
				if v_u_701 then
					return
				else
					v_u_21.hold()
					local function v1003()
						-- upvalues: (ref) v_u_29, (ref) v_u_988
						return v_u_29.func("ClaimReward"):InvokeServer(v_u_988)
					end
					local v1004, v1005, v1006, v1007 = pcall(v1003)
					if v1004 and (v1005 == true and type(v1006) == "number") then
						v_u_52.close()
						v_u_982(v_u_989.drops, v1006, function() end, v_u_21.release)
					else
						v_u_21.release()
						v_u_13.play("Error")
						if v1004 and type(v1007) == "string" then
							v_u_249(v1007)
						end
					end
				end
			end)
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_251, (ref) v_u_40, (copy) v_u_987, (ref) v_u_14, (ref) v_u_66
			while true do
				repeat
					task.wait(0.25)
				until v_u_251 == "Rewards"
				for v1008, v1009 in v_u_40 do
					local v1010 = v_u_987:FindFirstChild((tostring(v1008)))
					if not v1010 then
						continue
					end
					local v1011, v1012, v1013 = v_u_14.gift(v1008)
					v_u_66(v1010, "Left").Text = ("%*/%* left"):format(v1009.max - v1011, v1009.max)
					local v1014 = v_u_66(v1010, "Claim")
					local v1015 = v_u_66(v1010, "Wait")
					v1014.Visible = v1012 > 0
					v1015.Visible = v1012 <= 0
					local v1016
					if v1009.max <= v1011 then
						v1016 = "DONE"
					else
						local v1017 = math.ceil(v1013)
						local v1018 = math.max(0, v1017)
						local v1019 = string.format
						local v1020 = v1018 / 60
						v1016 = v1019("%d:%02d", math.floor(v1020), v1018 % 60)
					end
					local v1021 = v1015:FindFirstChild("TextLabel")
					if not (v1021 and v1021:IsA("TextLabel")) then
						continue
					end
					v1021.Text = v1016
				end
			end
		end)
	end
end
local function v_u_1026(p1023, p1024) -- name: dailyShown
	-- upvalues: (copy) v_u_41, (copy) v_u_15, (copy) v_u_43
	local v1025 = v_u_41.week(p1023)[p1024]
	if v_u_15.randomRestricted() then
		return v_u_43.daily({ v1025 })[1] or v1025
	else
		return v1025
	end
end
local function v_u_1033(p1027, p1028) -- name: weekTag
	local v1029 = p1027:FindFirstChild("Top")
	if v1029 then
		local v1030 = v1029:FindFirstChild("WeekTag")
		if not v1030 then
			local v1031 = nil
			for _, v1032 in v1029:GetChildren() do
				if not v1032:IsA("TextLabel") or v1031 ~= nil and v1032.Position.Y.Scale >= v1031.Position.Y.Scale then
					continue
				end
				v1031 = v1032
			end
			if not v1031 then
				return
			end
			v1030 = v1031:Clone()
			v1030.Name = "WeekTag"
			v1030.AnchorPoint = Vector2.new(0.5, 0.5)
			v1030.Position = UDim2.fromScale(0.525, 0.5)
			v1030.Size = UDim2.fromScale(0.17, 0.46)
			v1030.TextXAlignment = Enum.TextXAlignment.Center
			v1030.TextScaled = true
			v1030.TextColor3 = Color3.fromRGB(255, 226, 60)
			v1030.Parent = v1029
		end
		if v1030 and v1030:IsA("TextLabel") then
			v1030.Text = ("WEEK %*"):format(p1028 + 1)
		end
	end
end
local function v_u_1057() -- name: refreshDaily
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_14, (copy) v_u_1033, (copy) v_u_41, (copy) v_u_1026, (copy) v_u_19, (copy) v_u_295, (copy) v_u_48, (copy) v_u_288, (copy) v_u_22, (copy) v_u_303
	local v1034 = v_u_247:FindFirstChild("Daily")
	if not (v1034 and v1034:IsA("Frame")) then
		v1034 = nil
	end
	if v1034 then
		local v1035 = v_u_66(v1034, "Holder")
		local v1036, v1037, v1038 = v_u_14.daily()
		v_u_1033(v1034, v1038)
		local v1039 = v1034:FindFirstChild("SkipDay", true)
		if v1039 and v1039:IsA("GuiObject") then
			v1039.Visible = v1036 == nil
		end
		for v1040 = 1, v_u_41.DAYS do
			local v1041 = v_u_1026(v1038, v1040)
			local v1042 = v1035:FindFirstChild((tostring(v1040)))
			if not v1042 then
				continue
			end
			local v1043 = v1040 <= v1037
			local v1044 = v1036 == v1040
			v_u_19.paint(v1042, v1043 and "Locked" or (v1040 == 7 and "Mythic" or ((v1040 == 3 or v1040 == 5) and "Legendary" or "Rare")))
			local v1045 = v1042:FindFirstChild("DayText")
			if v1045 and v1045:IsA("TextLabel") then
				v1045.Text = "Day " .. v1040
			end
			local v1046 = v1042:FindFirstChild("Icon", true)
			if v1046 and v1046:IsA("ImageLabel") then
				v1046.Image = v_u_295(v1041)
				v1046.ImageTransparency = v1041.kind == "pet" and 1 or 0
				local v1047
				if v1041.kind == "pet" then
					v1047 = v_u_48.petFor(v1041, (select(2, v_u_288())))
				else
					v1047 = nil
				end
				local v1048 = v1046:FindFirstChild("PetView")
				if v1048 and v1048:GetAttribute("Pet") ~= v1047 then
					v1048:Destroy()
					v1048 = nil
				end
				if v1047 and not v1048 then
					local v1049 = Instance.new("ViewportFrame")
					v1049:SetAttribute("Pet", v1047)
					v1049.Name = "PetView"
					v1049.BackgroundTransparency = 1
					v1049.Size = UDim2.fromScale(1.3, 1.3)
					v1049.Position = UDim2.fromScale(0.5, 0.5)
					v1049.AnchorPoint = Vector2.new(0.5, 0.5)
					v1049.ZIndex = v1046.ZIndex + 1
					v1049.Ambient = Color3.fromRGB(200, 200, 210)
					v1049.Parent = v1046
					local v1050 = v_u_22.build(v1047)
					if v1050 then
						v_u_22.show(v1049, v1050, true)
					end
				end
			end
			local v1051 = v1042:FindFirstChild("RewardText")
			if v1051 and v1051:IsA("TextLabel") then
				v1051.Text = v_u_303(v1041)
			end
			local v1052 = v1042:FindFirstChild("Redeem")
			local v1053 = v1042:FindFirstChild("Locked")
			if not (v1052 and (v1052:IsA("GuiObject") and (v1053 and v1053:IsA("GuiObject")))) then
				continue
			end
			v1052.Visible = v1044
			v1053.Visible = not v1044
			local v1054 = v1052:FindFirstChild("TextLabel")
			if v1054 and v1054:IsA("TextLabel") then
				v1054.Text = "CLAIM"
			end
			local v1055 = v1043 and "CLAIMED" or "DAY " .. v1040
			local v1056 = v1053:FindFirstChild("TextLabel")
			if not (v1056 and v1056:IsA("TextLabel")) then
				continue
			end
			v1056.Text = v1055
		end
	end
end
local function v_u_1088() -- name: bindDaily
	-- upvalues: (ref) v_u_247, (copy) v_u_60, (copy) v_u_1057, (copy) v_u_15, (copy) v_u_66, (copy) v_u_41, (copy) v_u_11, (copy) v_u_21, (copy) v_u_14, (copy) v_u_29, (copy) v_u_13, (copy) v_u_1026, (ref) v_u_249, (copy) v_u_303, (copy) v_u_53, (ref) v_u_251, (copy) v_u_17, (ref) v_u_699, (copy) v_u_52
	local v1058 = v_u_247:FindFirstChild("Daily")
	if not (v1058 and v1058:IsA("Frame")) then
		v1058 = nil
	end
	if v1058 then
		v_u_60.Daily = v_u_1057
		local v1059 = v1058:FindFirstChild("SkipDay", true)
		if v1059 and v1059:IsA("GuiButton") then
			v1059.Activated:Connect(function()
				-- upvalues: (ref) v_u_15
				v_u_15.buyProduct("skipDay")
			end)
		end
		local v1060 = v_u_66(v1058, "Holder")
		for v_u_1061 = 1, v_u_41.DAYS do
			local v_u_1062 = v1060:FindFirstChild((tostring(v_u_1061)))
			local v1063
			if v_u_1062 then
				v1063 = v_u_1062:FindFirstChild("Locked")
			else
				v1063 = v_u_1062
			end
			if v1063 and v1063:IsA("GuiObject") then
				v_u_11.skip(v1063)
			end
			local v1064
			if v_u_1062 then
				v1064 = v_u_1062:FindFirstChild("Redeem")
			else
				v1064 = v_u_1062
			end
			if not (v1064 and v1064:IsA("GuiButton")) then
				continue
			end
			v1064.Activated:Connect(function()
				-- upvalues: (ref) v_u_21, (ref) v_u_14, (ref) v_u_29, (copy) v_u_1062, (ref) v_u_13, (copy) v_u_1061, (ref) v_u_41, (ref) v_u_1026, (ref) v_u_249, (ref) v_u_303, (ref) v_u_1057
				v_u_21.hold()
				local _, _, v1065 = v_u_14.daily()
				local function v1066()
					-- upvalues: (ref) v_u_29
					return v_u_29.func("ClaimDaily"):InvokeServer()
				end
				local v1067, v1068, v1069, v1070 = pcall(v1066)
				local v1071 = v_u_1062
				local v_u_1072 = v_u_21.centreOf(v1071)
				task.delay(0.25, function()
					-- upvalues: (ref) v_u_21, (copy) v_u_1072
					v_u_21.release(v_u_1072)
				end)
				if v1067 and v1068 == true then
					v_u_13.play("DailyClaim")
					local v1073
					if type(v1069) == "number" then
						v1073 = v1069
					else
						v1073 = v_u_1061
					end
					local v1074
					if v_u_41.week(v1065)[v1073] then
						v1074 = v_u_1026(v1065, v1073)
					else
						v1074 = nil
					end
					local v1075 = v_u_249
					local v1076 = "Day "
					local v1077 = tostring(v1069)
					local v1078 = ": "
					local v1079
					if v1074 then
						v1079 = v_u_303(v1074)
					else
						v1079 = tostring(v1070)
					end
					v1075(v1076 .. v1077 .. v1078 .. v1079)
				else
					v_u_13.play("Error")
					if v1067 and type(v1070) == "string" then
						v_u_249(v1070)
					end
				end
				v_u_1057()
			end)
		end
		for _, v1080 in {
			"DailyStreak",
			"DailyLast",
			"DailyWeek",
			"Today"
		} do
			v_u_53:GetAttributeChangedSignal(v1080):Connect(function()
				-- upvalues: (ref) v_u_251, (ref) v_u_1057
				if v_u_251 == "Daily" then
					v_u_1057()
				end
			end)
		end
		local function v_u_1085() -- name: offerDaily
			-- upvalues: (ref) v_u_14, (ref) v_u_17, (ref) v_u_251, (ref) v_u_699, (ref) v_u_52
			local function v_u_1082()
				-- upvalues: (ref) v_u_14, (ref) v_u_17
				local v1081
				if v_u_14.daily() == nil then
					v1081 = false
				else
					v1081 = not v_u_17.active()
				end
				return v1081
			end
			local v_u_1083 = "Daily"
			task.spawn(function()
				-- upvalues: (copy) v_u_1082, (ref) v_u_251, (ref) v_u_699, (ref) v_u_52, (copy) v_u_1083
				local v1084 = 0
				while v1084 < 60 do
					if not v_u_1082() then
						return
					end
					if v_u_251 == nil and not v_u_699 then
						v_u_52.open(v_u_1083)
						return
					end
					v1084 = v1084 + task.wait(0.5)
				end
			end)
		end
		task.delay(4, v_u_1085)
		v_u_17.onChange(function(p1086, p1087)
			-- upvalues: (copy) v_u_1085
			if p1086 == "done" and p1087 ~= "done" then
				task.delay(3.4, v_u_1085)
			end
		end)
	end
end
local function v_u_1097() -- name: refreshCommunity
	-- upvalues: (ref) v_u_247, (copy) v_u_53, (copy) v_u_66
	local v1089 = v_u_247:FindFirstChild("Community")
	if not (v1089 and v1089:IsA("Frame")) then
		v1089 = nil
	end
	if v1089 then
		local v1090 = v_u_53:GetAttribute("GroupClaimed") == true
		local v1091 = v_u_66(v1089, "Claim")
		local v1092 = v_u_66(v1089, "Join")
		v1091.Visible = not v1090
		local v1093 = v1089:FindFirstChild("Redeemed")
		if v1093 and v1093:IsA("GuiObject") then
			v1093.Visible = v1090
		end
		local v1094 = v_u_53:GetAttribute("InGroup") == true and "JOINED!" or "JOIN GROUP"
		local v1095 = v1092:FindFirstChild("TextLabel")
		if v1095 and v1095:IsA("TextLabel") then
			v1095.Text = v1094
		end
		local v1096 = v1092:FindFirstChild("MainText")
		if v1096 and v1096:IsA("TextLabel") then
			v1096.Text = v_u_53:GetAttribute("InGroup") == true and "JOINED!" or "JOIN GROUP"
		end
	end
end
function v_u_52.openCommunity() -- name: openCommunity
	-- upvalues: (ref) v_u_251, (copy) v_u_52
	if v_u_251 ~= "Community" then
		v_u_52.open("Community")
	end
end
local function v_u_1112() -- name: bindCommunity
	-- upvalues: (ref) v_u_247, (copy) v_u_60, (copy) v_u_1097, (copy) v_u_66, (copy) v_u_1, (copy) v_u_36, (copy) v_u_13, (copy) v_u_53, (copy) v_u_21, (copy) v_u_29, (ref) v_u_249, (ref) v_u_251
	local v_u_1098 = v_u_247:FindFirstChild("Community")
	if not (v_u_1098 and v_u_1098:IsA("Frame")) then
		v_u_1098 = nil
	end
	if v_u_1098 then
		v_u_60.Community = v_u_1097
		v_u_66(v_u_1098, "Join").Activated:Connect(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_36, (ref) v_u_13, (ref) v_u_53, (ref) v_u_1097
			local function v1099()
				-- upvalues: (ref) v_u_1, (ref) v_u_36
				return v_u_1:PromptJoinAsync(v_u_36.groupId)
			end
			local v1100, v1101 = pcall(v1099)
			if v1100 and v1101 == Enum.GroupMembershipStatus.Joined then
				v_u_13.play("Coin")
				v_u_53:SetAttribute("InGroup", true)
				v_u_1097()
			end
		end)
		v_u_66(v_u_1098, "Claim").Activated:Connect(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_29, (copy) v_u_1098, (ref) v_u_66, (ref) v_u_13, (ref) v_u_249, (ref) v_u_36, (ref) v_u_1097
			v_u_21.hold()
			local function v1102()
				-- upvalues: (ref) v_u_29
				return v_u_29.func("ClaimGroup"):InvokeServer()
			end
			local v1103, v1104, v1105 = pcall(v1102)
			local v1106 = v_u_66(v_u_1098, "Claim")
			local v_u_1107 = v_u_21.centreOf(v1106)
			task.delay(0.25, function()
				-- upvalues: (ref) v_u_21, (copy) v_u_1107
				v_u_21.release(v_u_1107)
			end)
			if v1103 and v1104 == true then
				v_u_13.play("RevealBig")
				local v1108 = v_u_249
				local v1109 = v_u_36.groupTrophies
				local v1110 = v_u_36.groupBonus * 100
				v1108((("+%* Trophies and +%*%% Chakra!"):format(v1109, (math.floor(v1110)))))
				v_u_1097()
			else
				v_u_13.play("Error")
				if type(v1105) == "string" then
					v_u_249(v1105)
				end
			end
		end)
		for _, v1111 in { "GroupClaimed", "InGroup" } do
			v_u_53:GetAttributeChangedSignal(v1111):Connect(function()
				-- upvalues: (ref) v_u_251, (ref) v_u_1097
				if v_u_251 == "Community" then
					v_u_1097()
				end
			end)
		end
	end
end
local function v_u_1156() -- name: refreshWorlds
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_256, (copy) v_u_14, (copy) v_u_44, (ref) v_u_56, (copy) v_u_241, (copy) v_u_242, (copy) v_u_37, (copy) v_u_46, (copy) v_u_243, (copy) v_u_244, (copy) v_u_239, (copy) v_u_240, (copy) v_u_52, (copy) v_u_13, (copy) v_u_29, (ref) v_u_249
	local v1113 = v_u_247:FindFirstChild("Worlds")
	if not (v1113 and v1113:IsA("Frame")) then
		v1113 = nil
	end
	if v1113 then
		local v1114 = v_u_66(v1113, "List")
		v_u_256(v1114)
		local v1115 = v_u_14.number("World", 1)
		for v1116, v_u_1117 in v_u_44 do
			if not v_u_1117.ready then
				continue
			end
			local v_u_1118 = v_u_1117.id == v1115
			local v_u_1119 = v_u_1117.needStage
			local v1120
			if v_u_1117.id - 1 == 1 then
				v1120 = v_u_14.number("BestStage")
			else
				local v1121 = v_u_14.number
				local v1122 = v_u_1117.id - 1
				v1120 = v1121("BestStage" .. tostring(v1122))
			end
			local v_u_1123 = v_u_1117.ready
			if v_u_1123 then
				v_u_1123 = v_u_1119 == nil and true or v_u_1119 <= v1120
			end
			local v_u_1124 = v_u_44[v_u_1117.id - 1]
			local v1125 = v_u_66(v_u_56, "WorldRow"):Clone()
			v1125.Visible = true
			v1125.LayoutOrder = v1116
			local v1126 = Color3.fromHex(v_u_1117.color)
			local v1127
			if v_u_1117.ready then
				v1127 = v1126:Lerp(Color3.new(1, 1, 1), 0.25)
			else
				v1127 = v_u_241
			end
			local v1128
			if v_u_1117.ready then
				v1128 = v1126:Lerp(Color3.new(0, 0, 0), 0.3)
			else
				v1128 = v_u_242
			end
			local v1129 = v1125:FindFirstChild("Paint")
			if v1129 and v1129:IsA("UIGradient") then
				v1129.Color = ColorSequence.new(v1127, v1128)
				v1129.Rotation = 0
			end
			local v1130 = v_u_66(v1125, "Icon")
			v1130.Image = v_u_1117.image or v_u_37.Icon.Worlds
			local v1131
			if v_u_1117.image then
				v1131 = Enum.ScaleType.Crop
			else
				v1131 = Enum.ScaleType.Fit
			end
			v1130.ScaleType = v1131
			if v_u_1117.image and not v1130:FindFirstChildOfClass("UICorner") then
				local v1132 = Instance.new("UICorner")
				v1132.CornerRadius = UDim.new(0.12, 0)
				v1132.Parent = v1130
			end
			local v1133
			if v_u_1117.ready and (v_u_1123 or v_u_1118) then
				v1133 = Color3.new(1, 1, 1)
			elseif v_u_1117.ready then
				v1133 = Color3.fromRGB(170, 170, 180)
			else
				v1133 = Color3.fromRGB(150, 150, 160)
			end
			v1130.ImageColor3 = v1133
			v_u_66(v1125, "Title").Text = v_u_1117.name
			local v_u_1134 = v_u_1117.ready
			if v_u_1134 then
				v_u_1134 = not v_u_1123
			end
			local v1135 = v_u_66(v1125, "Info")
			local v1136
			if v_u_1118 then
				v1136 = "You are here"
			elseif v_u_1123 then
				v1136 = "Teleport there"
			elseif v_u_1134 and (v_u_1124 and v_u_1119 == v_u_46.STAGE_COUNT) then
				v1136 = ("Beat the final stage of %*"):format(v_u_1124.name)
			else
				v1136 = not (v_u_1134 and v_u_1124) and "Coming soon!" or ("Clear Stage %* of %*"):format(v_u_1119, v_u_1124.name)
			end
			v1135.Text = v1136
			local v1137 = v_u_66(v1125, "Button")
			if v_u_1118 then
				local v1138 = v1137:FindFirstChild("TextLabel")
				if v1138 and v1138:IsA("TextLabel") then
					v1138.Text = "HERE"
				end
				local v1139 = v_u_243
				local v1140 = v_u_244
				local v1141 = v1137:FindFirstChildOfClass("UIGradient")
				if v1141 then
					v1141.Color = ColorSequence.new(v1139, v1140)
				end
			elseif v_u_1123 then
				local v1142 = v1137:FindFirstChild("TextLabel")
				if v1142 and v1142:IsA("TextLabel") then
					v1142.Text = "TELEPORT"
				end
				local v1143 = v_u_239
				local v1144 = v_u_240
				local v1145 = v1137:FindFirstChildOfClass("UIGradient")
				if v1145 then
					v1145.Color = ColorSequence.new(v1143, v1144)
				end
			elseif v_u_1134 then
				local v1146 = v1137:FindFirstChild("TextLabel")
				if v1146 and v1146:IsA("TextLabel") then
					v1146.Text = "LOCKED"
				end
				local v1147 = v_u_241
				local v1148 = v_u_242
				local v1149 = v1137:FindFirstChildOfClass("UIGradient")
				if v1149 then
					v1149.Color = ColorSequence.new(v1147, v1148)
				end
			else
				local v1150 = v1137:FindFirstChild("TextLabel")
				if v1150 and v1150:IsA("TextLabel") then
					v1150.Text = "SOON"
				end
				local v1151 = v_u_241
				local v1152 = v_u_242
				local v1153 = v1137:FindFirstChildOfClass("UIGradient")
				if v1153 then
					v1153.Color = ColorSequence.new(v1151, v1152)
				end
			end
			v1137.Activated:Connect(function()
				-- upvalues: (copy) v_u_1118, (ref) v_u_52, (copy) v_u_1123, (ref) v_u_13, (ref) v_u_29, (copy) v_u_1117, (ref) v_u_249, (copy) v_u_1134, (copy) v_u_1124, (copy) v_u_1119
				if v_u_1118 then
					v_u_52.close()
					return
				elseif v_u_1123 then
					v_u_52.close()
					v_u_13.play("RevealBig", {
						["volume"] = 0.6
					})
					v_u_29.event("Teleport"):FireServer(v_u_1117.id)
				else
					v_u_13.play("Error")
					local v1154 = v_u_249
					local v1155
					if v_u_1134 and v_u_1124 then
						v1155 = ("Clear Stage %* of %* first!"):format(v_u_1119, v_u_1124.name)
					else
						v1155 = v_u_1117.name .. " is coming soon!"
					end
					v1154(v1155)
				end
			end)
			v1125.Parent = v1114
		end
	end
end
local function v_u_1161() -- name: bindWorlds
	-- upvalues: (ref) v_u_247, (copy) v_u_60, (copy) v_u_1156, (copy) v_u_238, (copy) v_u_66, (copy) v_u_20, (ref) v_u_251, (copy) v_u_52
	local v1157 = v_u_247:FindFirstChild("Worlds")
	if not (v1157 and v1157:IsA("Frame")) then
		v1157 = nil
	end
	if v1157 then
		v_u_60.Worlds = v_u_1156
		local v1158 = v_u_238
		local v1159 = v_u_66
		local v1160 = v_u_247:FindFirstChild("Worlds")
		if not (v1160 and v1160:IsA("Frame")) then
			v1160 = nil
		end
		v1158((v1159(v1160, "List")))
		v_u_20.onNotify("Portal", function()
			-- upvalues: (ref) v_u_251, (ref) v_u_52
			if v_u_251 ~= "Worlds" then
				v_u_52.open("Worlds")
			end
		end)
	end
end
local function v_u_1188() -- name: bindLeave
	-- upvalues: (ref) v_u_247, (ref) v_u_252, (copy) v_u_2, (copy) v_u_53, (copy) v_u_17, (copy) v_u_36, (copy) v_u_14, (ref) v_u_251, (copy) v_u_52, (copy) v_u_13, (copy) v_u_11, (copy) v_u_4, (copy) v_u_66, (copy) v_u_21, (copy) v_u_29, (ref) v_u_249
	local v_u_1162 = v_u_247:FindFirstChild("Leave")
	if not (v_u_1162 and v_u_1162:IsA("Frame")) then
		v_u_1162 = nil
	end
	local v_u_1163 = v_u_252:FindFirstChild("LeaveLines")
	if v_u_1162 and (v_u_1163 and v_u_1163:IsA("GuiObject")) then
		local v_u_1164 = v_u_1162:FindFirstChild("Gift")
		v_u_2.MenuOpened:Connect(function()
			-- upvalues: (ref) v_u_53, (ref) v_u_17, (copy) v_u_1164, (ref) v_u_36, (ref) v_u_14, (ref) v_u_251, (ref) v_u_52, (ref) v_u_13
			if v_u_53:GetAttribute("ExitBonus") == false and not v_u_17.active() then
				if v_u_1164 and v_u_1164:IsA("TextLabel") then
					local v1165 = v_u_36.exitLevels
					local v1166 = v_u_1164
					local v1167
					if v_u_14.boostLeft("chakra") >= v_u_36.exitBoostCap * 60 then
						v1167 = ("+%* LEVELS!"):format(v1165)
					else
						v1167 = ("x2 CHAKRA + %* LEVELS!"):format(v1165)
					end
					v1166.Text = v1167
				end
				if v_u_251 ~= "Leave" then
					v_u_52.open("Leave")
					v_u_13.play("RevealBig", {
						["volume"] = 0.5
					})
				end
			end
		end)
		local v_u_1168 = {}
		for _, v1169 in v_u_1163:GetDescendants() do
			if not v1169:IsA("UIGradient") then
				continue
			end
			table.insert(v_u_1168, v1169)
		end
		local v_u_1170 = v_u_1162:FindFirstChild("Face")
		local v_u_1171 = v_u_252:FindFirstChild("TopRight")
		local v_u_1172 = false
		local function v_u_1175(p1173) -- name: clearTop
			-- upvalues: (copy) v_u_1171, (ref) v_u_1172, (ref) v_u_11, (copy) v_u_1163
			if v_u_1171 and v_u_1171:IsA("GuiObject") then
				if p1173 and (not v_u_1172 and v_u_1171.Visible) then
					v_u_1172 = true
					v_u_1171.Visible = false
				elseif not p1173 and v_u_1172 then
					v_u_1172 = false
					v_u_1171.Visible = true
				end
				local v1174
				if v_u_11.tv() then
					v1174 = UDim2.fromScale(0.9, 0.9)
				else
					v1174 = UDim2.fromScale(1, 1)
				end
				if p1173 and v_u_1163.Size ~= v1174 then
					v_u_1163.Size = v1174
				end
			end
		end
		v_u_4.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_251, (copy) v_u_1163, (copy) v_u_1175, (copy) v_u_1168, (copy) v_u_1170
			local v1176 = v_u_251 == "Leave"
			v_u_1163.Visible = v1176
			v_u_1175(v1176)
			if v1176 then
				local v1177 = os.clock()
				for v1178, v1179 in v_u_1168 do
					v1179.Color = ColorSequence.new(Color3.fromHSV((v1177 * 0.35 + v1178 * 0.13) % 1, 0.85, 1), Color3.fromHSV((v1177 * 0.35 + v1178 * 0.13 + 0.35) % 1, 0.85, 1))
				end
				if v_u_1170 and v_u_1170:IsA("GuiObject") then
					local v1180 = v_u_1170
					local v1181 = v1177 * 5
					v1180.Rotation = math.sin(v1181) * 6
				end
			end
		end)
		v_u_66(v_u_1162, "Redeem").Activated:Connect(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_29, (copy) v_u_1162, (ref) v_u_66, (ref) v_u_52, (ref) v_u_13, (ref) v_u_249
			v_u_21.hold()
			local function v1182()
				-- upvalues: (ref) v_u_29
				return v_u_29.func("ExitBonus"):InvokeServer()
			end
			local v1183, v1184, v1185 = pcall(v1182)
			local v1186 = v_u_66(v_u_1162, "Redeem")
			local v_u_1187 = v_u_21.centreOf(v1186)
			task.delay(0.25, function()
				-- upvalues: (ref) v_u_21, (copy) v_u_1187
				v_u_21.release(v_u_1187)
			end)
			v_u_52.close()
			if v1183 and v1184 == true then
				v_u_13.play("Rebirth")
				v_u_249(type(v1185) ~= "string" and "Exit bonus!" or v1185)
			end
		end)
	end
end
local function v_u_1204() -- name: bindCodes
	-- upvalues: (ref) v_u_247, (copy) v_u_66, (copy) v_u_13, (copy) v_u_21, (copy) v_u_29, (ref) v_u_249, (copy) v_u_11
	local v1189 = v_u_247:FindFirstChild("Codes")
	if not (v1189 and v1189:IsA("Frame")) then
		v1189 = nil
	end
	if v1189 then
		local v_u_1190 = v_u_66(v1189, "TextCode")
		local v_u_1191 = v_u_66(v1189, "MainDescription")
		v_u_1191.Text = "Follow @cizzyvz on Roblox for more codes!"
		local v_u_1192 = false
		local function v_u_1201() -- name: redeem
			-- upvalues: (ref) v_u_1192, (copy) v_u_1190, (ref) v_u_13, (ref) v_u_21, (ref) v_u_29, (copy) v_u_1191, (ref) v_u_249
			if v_u_1192 then
				return
			else
				local v_u_1193 = v_u_1190.Text
				if string.match(v_u_1193, "%S") == nil then
					v_u_13.play("Error")
				else
					v_u_1192 = true
					v_u_21.hold()
					local function v1194()
						-- upvalues: (ref) v_u_29, (copy) v_u_1193
						return v_u_29.func("RedeemCode"):InvokeServer(v_u_1193)
					end
					local v1195, v1196, v1197 = pcall(v1194)
					local v1198 = v_u_1190
					local v_u_1199 = v_u_21.centreOf(v1198)
					task.delay(0.25, function()
						-- upvalues: (ref) v_u_21, (copy) v_u_1199
						v_u_21.release(v_u_1199)
					end)
					v_u_1192 = false
					local v1200 = (not v1195 or type(v1197) ~= "string") and "Try again" or v1197
					if v1195 and v1196 == true then
						v_u_1190.Text = ""
						v_u_1191.Text = ("<font color=\"#7CFF6B\">%*</font>"):format(v1200)
						v_u_13.play("RevealBig", {
							["volume"] = 0.7
						})
					else
						v_u_1191.Text = ("<font color=\"#FF5A6E\">%*</font>"):format(v1200)
						v_u_13.play("Error")
					end
					v_u_249(v1200)
					task.delay(3, function()
						-- upvalues: (ref) v_u_1191
						v_u_1191.Text = "Follow @cizzyvz on Roblox for more codes!"
					end)
				end
			end
		end
		v_u_1191.RichText = true
		local v_u_1202 = v_u_66(v1189, "Redeem")
		v_u_1202.Activated:Connect(v_u_1201)
		v_u_1190.FocusLost:Connect(function(p1203)
			-- upvalues: (ref) v_u_11, (copy) v_u_1202, (copy) v_u_1201
			v_u_11.select(v_u_1202)
			if p1203 then
				v_u_1201()
			end
		end)
	end
end
local function v_u_1214() -- name: bindOffline
	-- upvalues: (ref) v_u_247, (copy) v_u_14, (copy) v_u_66, (copy) v_u_50, (copy) v_u_53, (ref) v_u_251, (ref) v_u_699, (copy) v_u_52, (copy) v_u_13, (copy) v_u_25
	local v_u_1205 = v_u_247:FindFirstChild("Offline")
	if not (v_u_1205 and v_u_1205:IsA("Frame")) then
		v_u_1205 = nil
	end
	if v_u_1205 then
		local v_u_1206 = ""
		v_u_14.watch("Offline", function()
			-- upvalues: (ref) v_u_14, (ref) v_u_1206, (copy) v_u_1205, (ref) v_u_66, (ref) v_u_50, (ref) v_u_53, (ref) v_u_251, (ref) v_u_699, (ref) v_u_52
			local v_u_1207 = v_u_14.string("Offline")
			if v_u_1207 == "" or v_u_1207 == v_u_1206 then
				return
			else
				v_u_1206 = v_u_1207
				local v1208 = v_u_14.offline()
				if v1208 then
					v_u_66(v_u_1205, "MainDescription").Text = ("You were away for %*."):format((v_u_50.duration(v1208.seconds))) .. "\nYour chakra kept growing!"
					v_u_66(v_u_1205, "Gained.Amount").Text = "+" .. v_u_50.short(v1208.chakra)
					local v1209 = v_u_66(v_u_1205, "Levels")
					v1209.Text = "+" .. v_u_50.commas(v1208.levels) .. (v1208.levels == 1 and " Level" or " Levels")
					v1209.Visible = v1208.levels > 0
					task.delay(2, function()
						-- upvalues: (ref) v_u_53, (copy) v_u_1207, (ref) v_u_251, (ref) v_u_699, (ref) v_u_52
						local function v_u_1210()
							-- upvalues: (ref) v_u_53, (ref) v_u_1207
							return v_u_53:GetAttribute("OfflineClaimed") ~= v_u_1207
						end
						local v_u_1211 = "Offline"
						task.spawn(function()
							-- upvalues: (copy) v_u_1210, (ref) v_u_251, (ref) v_u_699, (ref) v_u_52, (copy) v_u_1211
							local v1212 = 0
							while v1212 < 60 do
								if not v_u_1210() then
									return
								end
								if v_u_251 == nil and not v_u_699 then
									v_u_52.open(v_u_1211)
									return
								end
								v1212 = v1212 + task.wait(0.5)
							end
						end)
					end)
				end
			end
		end)
		v_u_66(v_u_1205, "Redeem").Activated:Connect(function()
			-- upvalues: (ref) v_u_52, (ref) v_u_13, (ref) v_u_53, (ref) v_u_25
			v_u_52.close()
			v_u_13.play("RevealBig", {
				["volume"] = 0.6
			})
			local v1213 = v_u_53.Character
			if v1213 then
				v1213 = v_u_53.Character:FindFirstChild("HumanoidRootPart")
			end
			if v1213 and v1213:IsA("BasePart") then
				v_u_25.burst("Sparkle", v1213.Position, nil, 1.5)
			end
		end)
	end
end
local function v_u_1227(p_u_1215) -- name: padSlider
	-- upvalues: (copy) v_u_13, (copy) v_u_9, (copy) v_u_2
	p_u_1215.NextSelectionLeft = p_u_1215
	p_u_1215.NextSelectionRight = p_u_1215
	local function v_u_1221(p1216) -- name: nudge
		-- upvalues: (copy) p_u_1215, (ref) v_u_13
		local v1217 = p_u_1215.Position
		local v1218 = (v1217.X.Scale + p1216) * 10 + 0.5
		local v1219 = math.floor(v1218) / 10
		local v1220 = math.clamp(v1219, 0, 1)
		if v1220 ~= v1217.X.Scale then
			p_u_1215.Position = UDim2.new(v1220, v1217.X.Offset, v1217.Y.Scale, v1217.Y.Offset)
			v_u_13.play("Hover")
		end
	end
	local v_u_1222 = 0
	v_u_9.InputBegan:Connect(function(p1223)
		-- upvalues: (ref) v_u_2, (copy) p_u_1215, (copy) v_u_1221
		if v_u_2.SelectedObject == p_u_1215 then
			if p1223.KeyCode == Enum.KeyCode.DPadLeft then
				v_u_1221(-0.1)
			elseif p1223.KeyCode == Enum.KeyCode.DPadRight then
				v_u_1221(0.1)
			end
		else
			return
		end
	end)
	v_u_9.InputChanged:Connect(function(p1224)
		-- upvalues: (ref) v_u_2, (copy) p_u_1215, (ref) v_u_1222, (copy) v_u_1221
		if p1224.KeyCode == Enum.KeyCode.Thumbstick1 and v_u_2.SelectedObject == p_u_1215 then
			local v1225 = p1224.Position.X
			local v1226 = v1225 > 0.6 and 1 or (v1225 < -0.6 and -1 or 0)
			if v1226 ~= 0 and v1226 ~= v_u_1222 then
				v_u_1221(v1226 * 0.1)
			end
			if math.abs(v1225) < 0.3 or v1226 ~= 0 then
				v_u_1222 = v1226
			end
		end
	end)
end
local function v_u_1260() -- name: bindSettings
	-- upvalues: (ref) v_u_247, (copy) v_u_7, (copy) v_u_1227, (copy) v_u_53, (copy) v_u_241, (copy) v_u_242, (copy) v_u_29, (copy) v_u_13, (copy) v_u_238
	local v1228 = v_u_247:FindFirstChild("Settings")
	if not (v1228 and v1228:IsA("Frame")) then
		v1228 = nil
	end
	if v1228 then
		local v1229 = v_u_7:FindFirstChild("Master")
		for v1230, v1231 in {
			["Music"] = "Music",
			["Sfx"] = "SFX"
		} do
			local v_u_1232 = v1228:FindFirstChild(v1230, true)
			if v_u_1232 then
				v_u_1232 = v_u_1232:FindFirstChild("Dragger", true)
			end
			local v_u_1233
			if v1229 then
				v_u_1233 = v1229:FindFirstChild(v1231)
			else
				v_u_1233 = v1229
			end
			if not (v_u_1232 and v_u_1232:IsA("GuiObject")) then
				continue
			end
			v_u_1232:GetPropertyChangedSignal("Position"):Connect(function() -- name: apply
				-- upvalues: (copy) v_u_1232, (copy) v_u_1233
				local v1234 = v_u_1232.Position.X.Scale
				local v1235 = math.clamp(v1234, 0, 1)
				if v_u_1233 and v_u_1233:IsA("SoundGroup") then
					v_u_1233.Volume = v1235
				end
			end)
			local v1236 = v_u_1232.Position.X.Scale
			local v1237 = math.clamp(v1236, 0, 1)
			if v_u_1233 and v_u_1233:IsA("SoundGroup") then
				v_u_1233.Volume = v1237
			end
			if not v_u_1232:IsA("GuiButton") then
				continue
			end
			v_u_1227(v_u_1232)
		end
		local v1238 = v1228:FindFirstChild("ReplayTutorial", true)
		if v1238 and v1238:IsA("GuiButton") then
			for v1239, v_u_1240 in {
				{
					["name"] = "ShowEye",
					["save"] = "hideEye",
					["attribute"] = "HideEye",
					["text"] = "SHOW MY EYE"
				},
				{
					["name"] = "ShowAura",
					["save"] = "hideAura",
					["attribute"] = "HideAura",
					["text"] = "SHOW MY AURA"
				}
			} do
				local v_u_1241 = v1238:Clone()
				v_u_1241.Name = v_u_1240.name
				v_u_1241:SetAttribute("Pad", true)
				v_u_1241.LayoutOrder = v1238.LayoutOrder + 1 + v1239
				for _, v1242 in v_u_1241:GetChildren() do
					if not v1242:IsA("UIScale") and v1242.Name ~= "PadHint" then
						continue
					end
					v1242:Destroy()
				end
				local function v1254() -- name: show
					-- upvalues: (ref) v_u_53, (copy) v_u_1240, (copy) v_u_1241, (ref) v_u_241, (ref) v_u_242
					local v1243 = v_u_53:GetAttribute(v_u_1240.attribute) ~= true
					local v1244 = v_u_1241
					local v1245 = ("%*: %*"):format(v_u_1240.text, v1243 and "ON" or "OFF")
					local v1246 = v1244:FindFirstChild("TextLabel")
					if v1246 and v1246:IsA("TextLabel") then
						v1246.Text = v1245
					end
					if v1243 then
						local v1247 = v_u_1241
						local v1248 = Color3.fromRGB(124, 255, 107)
						local v1249 = Color3.fromRGB(30, 170, 60)
						local v1250 = v1247:FindFirstChildOfClass("UIGradient")
						if v1250 then
							v1250.Color = ColorSequence.new(v1248, v1249)
							return
						end
					else
						local v1251 = v_u_241
						local v1252 = v_u_242
						local v1253 = v_u_1241:FindFirstChildOfClass("UIGradient")
						if v1253 then
							v1253.Color = ColorSequence.new(v1251, v1252)
						end
					end
				end
				v_u_1241.Activated:Connect(function()
					-- upvalues: (ref) v_u_53, (copy) v_u_1240, (ref) v_u_29, (ref) v_u_13
					local v_u_1255 = v_u_53:GetAttribute(v_u_1240.attribute) ~= true
					local function v1256()
						-- upvalues: (ref) v_u_29, (ref) v_u_1240, (copy) v_u_1255
						return v_u_29.func("Settings"):InvokeServer(v_u_1240.save, v_u_1255)
					end
					local v1257, v1258 = pcall(v1256)
					if not v1257 or v1258 ~= true then
						v_u_13.play("Error")
					end
				end)
				v_u_53:GetAttributeChangedSignal(v_u_1240.attribute):Connect(v1254)
				v1254()
				v_u_1241.Parent = v1238.Parent
			end
			local v1259 = v1238.Parent
			if v1259 then
				v_u_238(v1259)
			end
		end
	else
		return
	end
end
local function v_u_1273() -- name: bindPad
	-- upvalues: (ref) v_u_247, (copy) v_u_11, (copy) v_u_9, (ref) v_u_251, (ref) v_u_338, (copy) v_u_13, (copy) v_u_463, (copy) v_u_113, (ref) v_u_700, (copy) v_u_52, (ref) v_u_252, (ref) v_u_71, (copy) v_u_2
	for _, v1261 in v_u_247:GetChildren() do
		if not v1261:IsA("GuiObject") then
			continue
		end
		v_u_11.root(v1261)
		local v1262 = v1261:FindFirstChild("Top")
		if v1262 then
			v1262 = v1262:FindFirstChild("Close")
		end
		if not (v1262 and v1262:IsA("GuiObject")) then
			continue
		end
		v_u_11.hint(v1262, Enum.KeyCode.ButtonB, 26)
	end
	local v1263 = v_u_247:FindFirstChild("Quests")
	if not (v1263 and v1263:IsA("Frame")) then
		v1263 = nil
	end
	if v1263 then
		v1263 = v1263:FindFirstChild("Tabs")
	end
	local v1264
	if v1263 then
		v1264 = v1263:FindFirstChild("Daily")
	else
		v1264 = v1263
	end
	if v1263 then
		v1263 = v1263:FindFirstChild("Weekly")
	end
	if v1264 and (v1264:IsA("GuiObject") and (v1263 and v1263:IsA("GuiObject"))) then
		v_u_11.hint(v1264, Enum.KeyCode.ButtonL1, 26, UDim2.fromOffset(4, 4))
		v_u_11.hint(v1263, Enum.KeyCode.ButtonR1, 26)
		v_u_9.InputBegan:Connect(function(p1265)
			-- upvalues: (ref) v_u_251, (ref) v_u_338, (ref) v_u_13, (ref) v_u_463, (ref) v_u_11, (ref) v_u_113
			if v_u_251 == "Quests" then
				local v1266 = p1265.KeyCode == Enum.KeyCode.ButtonL1 and "daily" or (p1265.KeyCode == Enum.KeyCode.ButtonR1 and "weekly" or nil)
				if v1266 and v1266 ~= v_u_338 then
					v_u_338 = v1266
					v_u_13.play("Click")
					v_u_463()
					v_u_11.selectSoon(function()
						-- upvalues: (ref) v_u_251, (ref) v_u_113
						if v_u_251 == "Quests" then
							return v_u_113("Quests")
						else
							return nil
						end
					end)
				end
			end
		end)
	end
	v_u_11.onBack(function()
		-- upvalues: (ref) v_u_700, (ref) v_u_251, (ref) v_u_52
		local v1267 = v_u_700
		if v1267 then
			v1267()
			return true
		end
		if not v_u_251 then
			return false
		end
		v_u_52.close()
		return true
	end, 10)
	v_u_11.onEnter(function()
		-- upvalues: (ref) v_u_252, (ref) v_u_700, (ref) v_u_11, (ref) v_u_251, (ref) v_u_247, (ref) v_u_71, (ref) v_u_113
		local v1268 = v_u_252:FindFirstChild("Overlay")
		if v1268 then
			v1268 = v1268:FindFirstChild("Hatch")
		end
		if v_u_700 and (v1268 and v1268:IsA("GuiObject")) then
			v_u_11.select(v1268)
			return true
		end
		local v1269 = v_u_251
		if not v1269 then
			return false
		end
		local v1270 = v_u_247:FindFirstChild(v1269)
		if not (v1270 and v1270:IsA("Frame")) then
			v1270 = nil
		end
		local v1271 = v_u_71
		if not (v1271 and (v1270 and (v1271:IsDescendantOf(v1270) and v_u_11.shown(v1271)))) then
			v1271 = v_u_113(v1269)
		end
		if not v1271 then
			return false
		end
		v_u_11.select(v1271)
		return v_u_11.selected() ~= nil
	end, 10)
	v_u_2:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		-- upvalues: (ref) v_u_2, (ref) v_u_247, (ref) v_u_71
		local v1272 = v_u_2.SelectedObject
		if v1272 and v1272:IsDescendantOf(v_u_247) then
			v_u_71 = v1272
		end
	end)
end
function v_u_52.start() -- name: start
	-- upvalues: (copy) v_u_53, (ref) v_u_247, (ref) v_u_56, (ref) v_u_252, (copy) v_u_114, (copy) v_u_3, (ref) v_u_248, (copy) v_u_19, (copy) v_u_52, (ref) v_u_251, (copy) v_u_8, (copy) v_u_69, (copy) v_u_126, (copy) v_u_11, (ref) v_u_250, (copy) v_u_1273, (copy) v_u_4, (copy) v_u_208, (copy) v_u_477, (copy) v_u_943, (copy) v_u_563, (copy) v_u_697, (copy) v_u_866, (copy) v_u_1022, (copy) v_u_1088, (copy) v_u_1112, (copy) v_u_1161, (copy) v_u_1214, (copy) v_u_1188, (copy) v_u_1204, (copy) v_u_1260, (copy) v_u_336, (copy) v_u_985, (copy) v_u_14, (copy) v_u_15, (copy) v_u_1057, (copy) v_u_231, (copy) v_u_26, (copy) v_u_225, (copy) v_u_238, (copy) v_u_66, (copy) v_u_273, (copy) v_u_60, (copy) v_u_920
	local v1274 = v_u_53:WaitForChild("PlayerGui"):WaitForChild("Main")
	v_u_247 = v1274:WaitForChild("Frames")
	v_u_56 = v1274:WaitForChild("Templates")
	v_u_252 = v1274:WaitForChild("HUD")
	for _, v1275 in {
		"Bottom",
		"Top",
		"Skills",
		"Upgrade",
		"Boosts"
	} do
		local v1276 = v_u_252:WaitForChild(v1275, 10)
		if not (v1276 and v1276:IsA("GuiObject")) then
			continue
		end
		local v1277 = v_u_114
		table.insert(v1277, v1276)
	end
	local v1278 = Instance.new("BlurEffect")
	v1278.Name = "MenuBlur"
	v1278.Size = 0
	v1278.Parent = v_u_3
	v_u_248 = v1278
	v_u_19.onFrame(v_u_52.open)
	v_u_19.onClose(v_u_52.close)
	for _, v_u_1279 in v_u_247:GetChildren() do
		if not v_u_1279:IsA("GuiObject") then
			continue
		end
		v_u_1279:GetPropertyChangedSignal("Visible"):Connect(function()
			-- upvalues: (copy) v_u_1279, (ref) v_u_251, (ref) v_u_248, (ref) v_u_8, (ref) v_u_69, (ref) v_u_126, (ref) v_u_11, (ref) v_u_250
			if not v_u_1279.Visible and v_u_251 == v_u_1279.Name then
				v_u_251 = nil
				v_u_8:Create(v_u_248, TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
					["Size"] = 0
				}):Play()
				v_u_69(70)
				v_u_126(false)
				v_u_11.capture("menu", false)
				v_u_250 = nil
			end
		end)
	end
	v_u_1273()
	if v_u_4:IsStudio() then
		v_u_53:GetAttributeChangedSignal("DevMenu"):Connect(function()
			-- upvalues: (ref) v_u_53, (ref) v_u_52
			local v1280 = v_u_53:GetAttribute("DevMenu")
			if type(v1280) == "string" and v1280 ~= "" then
				v_u_52.open(v1280)
			else
				v_u_52.close()
			end
		end)
	end
	v_u_208()
	v_u_477()
	v_u_943()
	v_u_563()
	v_u_697()
	v_u_866()
	v_u_1022()
	v_u_1088()
	v_u_1112()
	v_u_1161()
	v_u_1214()
	v_u_1188()
	v_u_1204()
	v_u_1260()
	local function v1281() -- name: fillProgressPrizes
		-- upvalues: (ref) v_u_336, (ref) v_u_985
		v_u_336()
		v_u_985()
	end
	v_u_336()
	v_u_985()
	for _, v1282 in {
		"BestStage",
		"BestStage2",
		"BestStage3",
		"BestStage4",
		"BestStage5",
		"BestStage6",
		"BestStage7",
		"BestStage8"
	} do
		v_u_14.watch(v1282, v1281)
	end
	v_u_15.randomChanged:Connect(v1281)
	v_u_15.randomChanged:Connect(v_u_1057)
	v_u_231()
	if v_u_26.touch() then
		for _, v1283 in v_u_247:GetDescendants() do
			if not v1283:IsA("GuiButton") or (v1283.Name ~= "Close" or v1283:FindFirstChildOfClass("UIScale")) then
				continue
			end
			local v1284 = Instance.new("UIScale")
			v1284.Scale = 1.35
			v1284.Parent = v1283
		end
	end
	v_u_14.watch("World", v_u_225)
	for _, v1285 in { "Quests", "Auras" } do
		local v1286 = v_u_247:FindFirstChild(v1285)
		if not (v1286 and v1286:IsA("Frame")) then
			v1286 = nil
		end
		if not v1286 then
			continue
		end
		v_u_238((v_u_66(v1286, "List")))
	end
	local v1287 = v_u_247:FindFirstChild("MyEyes")
	if not (v1287 and v1287:IsA("Frame")) then
		v1287 = nil
	end
	if v1287 then
		v_u_273(v_u_66(v1287, "Grid"), 0.235, 0.46, 0.015, 0.03)
	end
	local v1288 = v_u_247:FindFirstChild("Pets")
	if not (v1288 and v1288:IsA("Frame")) then
		v1288 = nil
	end
	if v1288 then
		v1288 = v1288:FindFirstChild("Grid", true)
	end
	if v1288 then
		v_u_273(v1288, 0.23, 0.32, 0.02, 0.025)
	end
	v_u_60.MyEyes = v_u_920
	for _, v1289 in { "Eye", "Eyes", "TotalWins" } do
		v_u_14.watch(v1289, function()
			-- upvalues: (ref) v_u_251, (ref) v_u_920
			if v_u_251 == "MyEyes" then
				v_u_920()
			end
		end)
	end
end
return v_u_52