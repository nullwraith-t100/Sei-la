local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(255, 120, 90)
local v_u_5 = Color3.fromRGB(80, 0, 8)
return function(p_u_6)
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	return {
		["w0_fuma_mangekyo"] = function(p_u_7, p8)
			-- upvalues: (ref) v_u_2, (copy) p_u_6, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5
			local v_u_9 = v_u_2.color(p8.color)
			local v10 = Color3.fromRGB(255, 50, 44)
			local v11 = Color3.new(v10.R * 1.8, v10.G * 1.8, v10.B * 1.8)
			local v12 = p_u_7.headY / 1.5
			local v_u_13 = math.clamp(v12, 0.7, 3)
			local v_u_14 = p_u_7.fx
			local v_u_15 = v_u_13 * -0.25
			local v_u_17 = p_u_6.throb(p_u_7, 3.6, 1.8, 1.6, function(p16)
				-- upvalues: (ref) v_u_2, (ref) p_u_6, (copy) p_u_7, (copy) v_u_9, (copy) v_u_14, (ref) v_u_3, (copy) v_u_15, (ref) v_u_4, (copy) v_u_13
				v_u_2.ring(p_u_6.feetAt(p_u_7, p16, 0.15), v_u_9, 9 * v_u_14, 0.6, v_u_3.Ring)
				v_u_2.flash(p16.Position + Vector3.new(0, 1, 0) * v_u_15, v_u_4, v_u_13 * 4 * v_u_14, 0.2)
			end)
			local v_u_18 = 0
			local v19 = p_u_7.ticks
			local function v21(_, _, p20)
				-- upvalues: (ref) v_u_18, (copy) v_u_17
				v_u_18 = v_u_18 + p20 * (1.4 + 14 * v_u_17())
			end
			table.insert(v19, v21)
			local v_u_28 = p_u_6.group(p_u_7, function(p22)
				-- upvalues: (copy) v_u_15, (ref) p_u_6
				local v23 = p22.Position + Vector3.new(0, 1, 0) * v_u_15
				local v24 = p_u_6.camPos() - v23
				local v25 = (Vector3.new(0, 0.78, 0) + (v24.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v24.Unit) * 0.22).Unit
				local v26 = v25.Y
				local v27 = math.abs(v26) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.fromMatrix(v23, v27:Cross(v25).Unit, v25)
			end)
			local v_u_29 = v_u_13 * 8.6
			local v30 = p_u_6.picture(v_u_29 * 1.35, v_u_3.Swirl, v_u_9, 0.35)
			p_u_6.add(p_u_7, v30, function(_, p31)
				-- upvalues: (copy) v_u_28
				return v_u_28.cf * CFrame.new(0, -0.08, 0) * CFrame.Angles(0, p31 * 0.9, 0)
			end)
			local v32, v33 = p_u_6.picture(v_u_29, v_u_3.FumaShuriken, v_u_9, 0)
			p_u_6.add(p_u_7, v32, function()
				-- upvalues: (copy) v_u_28, (ref) v_u_18
				return v_u_28.cf * CFrame.Angles(0, -v_u_18, 0)
			end)
			local v34, v_u_35 = p_u_6.picture(v_u_29, v_u_3.FumaShuriken, v_u_9, 1)
			local v_u_36 = v_u_18
			for _, v37 in v33 do
				v37.Color3 = v11
			end
			for _, v38 in v_u_35 do
				v38.Color3 = v11
			end
			p_u_6.add(p_u_7, v34, function()
				-- upvalues: (copy) v_u_28, (ref) v_u_36
				return v_u_28.cf * CFrame.new(0, -0.04, 0) * CFrame.Angles(0, -v_u_36 + 0.4, 0)
			end)
			local v_u_39 = -1
			local v40 = p_u_7.ticks
			local function v44()
				-- upvalues: (copy) v_u_17, (ref) v_u_39, (copy) v_u_35
				local v41 = 1 - 0.65 * v_u_17()
				local v42 = v41 - v_u_39
				if math.abs(v42) > 0.01 then
					v_u_39 = v41
					for _, v43 in v_u_35 do
						v43.Transparency = v41
					end
				end
			end
			table.insert(v40, v44)
			for v_u_45 = 0, 3 do
				local function v46() -- name: place
					-- upvalues: (copy) v_u_28, (ref) v_u_36, (copy) v_u_45, (copy) v_u_29
					return v_u_28.cf * CFrame.Angles(0, -v_u_36 + v_u_45 * 3.141592653589793 / 2, 0) * CFrame.new(v_u_29 * 0.47, 0.05, 0)
				end
				local v47 = p_u_6.ball(v_u_13 * 0.42, v_u_4, 0)
				p_u_6.add(p_u_7, v47, v46)
				p_u_6.tail(v47, v_u_9, v_u_5, v_u_13 * 0.36, 0.3)
				p_u_6.add(p_u_7, p_u_6.ball(v_u_13 * 1, v_u_9, 0.5), p_u_6.behind(v46, v_u_13 * 0.25))
			end
			for v_u_48 = 1, 4 do
				local v_u_49 = p_u_6.ball(v_u_13 * 0.28, v_u_4, 0)
				local v_u_50 = p_u_6.tail(v_u_49, v_u_9, v_u_5, v_u_13 * 0.42, 0.45)
				local v_u_51 = -1
				p_u_6.add(p_u_7, v_u_49, function(p52, p53)
					-- upvalues: (copy) v_u_48, (ref) v_u_51, (copy) v_u_50, (copy) v_u_49, (copy) v_u_13, (copy) p_u_7, (copy) v_u_15, (ref) v_u_36
					local v54 = p53 * 0.8 + v_u_48 / 4
					local v55 = math.floor(v54)
					local v56 = v54 - v55
					if v55 ~= v_u_51 then
						v_u_51 = v55
						v_u_50:Clear()
					end
					local v57 = v_u_49
					local v58 = (v56 - 0.85) / 0.15
					v57.Transparency = math.clamp(v58, 0, 1)
					local v59 = (0.8 + 3.4 * v56 * v56) * v_u_13
					local v60 = p_u_7.feet + v_u_13 * 0.25 + v56 * (v_u_15 - p_u_7.feet - v_u_13 * 0.25)
					local v61 = -(v_u_36 * 0.3 + v56 * 5 + (v_u_48 - 1) * 3.141592653589793 / 2)
					local v62 = CFrame.Angles(0, v61, 0) * Vector3.new(v59, 0, 0)
					local v63 = CFrame.new
					local v64 = p52.Position
					local v65 = v62.X
					local v66 = v62.Z
					return v63(v64 + Vector3.new(v65, v60, v66))
				end)
			end
			local v67 = p_u_6.picture(v_u_13 * 7, v_u_3.Swirl, v_u_9, 0.45)
			p_u_6.add(p_u_7, v67, function(p68, p69)
				-- upvalues: (ref) p_u_6, (copy) p_u_7
				return CFrame.new(p_u_6.feetAt(p_u_7, p68, 0.1)) * CFrame.Angles(0, -p69 * 1.6, 0)
			end)
			p_u_6.particles(p_u_7, "AuraMode", v_u_9, {
				["rate"] = 0.45,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = {
					"Glow",
					"FlameBack",
					"Crackle",
					"Sparks"
				}
			})
		end
	}
end