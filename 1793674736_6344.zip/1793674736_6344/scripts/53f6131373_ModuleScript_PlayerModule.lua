local v1 = require(script:WaitForChild("CommonUtils"))
if v1.get("FlagUtil").getUserFlag("UserControlModuleEnabledAPI") then
	return {
		["ControlModule"] = {
			["Enabled"] = true
		}
	}
end
local v_u_2 = game:GetService("RunService")
local v_u_3 = v1.get("CharacterUtil")
local v_u_4 = v1.get("ConnectionUtil")
local v_u_5 = v1.get("EventBus")
local v_u_6 = require(script:WaitForChild("CameraModule"))
local v_u_7 = require(script:WaitForChild("ControlModule"))
local v_u_8 = require(script:WaitForChild("ServerAuthority"))
local v_u_9 = {}
v_u_9.__index = v_u_9
function v_u_9.new() -- name: new
	-- upvalues: (copy) v_u_4, (copy) v_u_5, (copy) v_u_9
	local v10 = {
		["data"] = {
			["isJumping"] = false,
			["moveVector"] = nil,
			["actions"] = nil,
			["player"] = nil,
			["character"] = nil,
			["connectionUtil"] = nil,
			["eventBus"] = nil,
			["isServerAuthority"] = false,
			["moveVector"] = Vector2.new(),
			["actions"] = {},
			["connectionUtil"] = v_u_4.new(),
			["eventBus"] = v_u_5.new()
		}
	}
	local v11 = v_u_9
	return setmetatable(v10, v11)
end
function v_u_9.start(p_u_12) -- name: start
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_7, (copy) v_u_2, (copy) v_u_6
	p_u_12.data.connectionUtil:trackConnection("ONLOCALPLAYER", v_u_3.onLocalPlayer(function(p13)
		-- upvalues: (copy) p_u_12, (ref) v_u_8, (ref) v_u_7, (ref) v_u_2, (ref) v_u_3, (ref) v_u_6
		p_u_12.data.player = p13
		v_u_8.initialize(p_u_12.data)
		v_u_7:initialize(p_u_12.data)
		v_u_2:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT", Enum.RenderPriority.Input.Value, function(p14)
			-- upvalues: (ref) p_u_12, (ref) v_u_3, (ref) v_u_7
			p_u_12.data.character = v_u_3.getCharacter()
			if p_u_12.data.character then
				v_u_7:Update(p_u_12.data, p14)
			end
		end)
		p_u_12.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_INPUT", function()
			-- upvalues: (ref) v_u_2
			v_u_2:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_INPUT")
		end)
		v_u_2:BindToRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA", Enum.RenderPriority.Camera.Value, function(p15)
			-- upvalues: (ref) v_u_6, (ref) p_u_12
			v_u_6:Update(p_u_12.data, p15)
		end)
		p_u_12.data.connectionUtil:trackBoundFunction("PLAYERMODULE_RENDERSTEPPED_CAMERA", function()
			-- upvalues: (ref) v_u_2
			v_u_2:UnbindFromRenderStep("PLAYERMODULE_RENDERSTEPPED_CAMERA")
		end)
	end))
end
function v_u_9.stop(p16) -- name: stop
	p16.data.connectionUtil:disconnectAll()
end
v_u_9.new():start()
return {}