local v1 = require(script.Parent.Parent.Logic.Prizes)
local v2 = {}
local v3 = {
	["id"] = "gift5",
	["name"] = "Every 5 Min",
	["minutes"] = 5,
	["max"] = 9,
	["color"] = "#3FA9FF",
	["icon"] = "rbxassetid://73989013612789",
	["drops"] = nil,
	["drops"] = {
		{
			["prize"] = nil,
			["weight"] = 52,
			["rarity"] = "Common",
			["prize"] = v1.trophies(0.25, 2)
		},
		{
			["prize"] = nil,
			["weight"] = 25,
			["rarity"] = "Common",
			["prize"] = v1.worldEgg(1, 1)
		},
		{
			["prize"] = nil,
			["weight"] = 8,
			["rarity"] = "Rare",
			["prize"] = v1.boost("chakra", 1)
		},
		{
			["prize"] = nil,
			["weight"] = 10,
			["rarity"] = "Rare",
			["prize"] = v1.trophies(0.75, 4)
		},
		{
			["prize"] = nil,
			["weight"] = 5,
			["rarity"] = "Epic",
			["prize"] = v1.worldEgg(2, 1)
		}
	}
}
local v4 = {
	["id"] = "gift15",
	["name"] = "Every 15 Min",
	["minutes"] = 15,
	["max"] = 4,
	["color"] = "#B45CFF",
	["icon"] = "rbxassetid://112943806732824",
	["drops"] = nil,
	["drops"] = {
		{
			["prize"] = nil,
			["weight"] = 45,
			["rarity"] = "Common",
			["prize"] = v1.trophies(1, 5)
		},
		{
			["prize"] = nil,
			["weight"] = 20,
			["rarity"] = "Rare",
			["prize"] = v1.worldEgg(1, 3)
		},
		{
			["prize"] = nil,
			["weight"] = 10,
			["rarity"] = "Rare",
			["prize"] = v1.boost("chakra", 3)
		},
		{
			["prize"] = nil,
			["weight"] = 15,
			["rarity"] = "Epic",
			["prize"] = v1.boost("wins", 5)
		},
		{
			["prize"] = nil,
			["weight"] = 8,
			["rarity"] = "Epic",
			["prize"] = v1.worldEgg(2, 1)
		},
		{
			["prize"] = nil,
			["weight"] = 2,
			["rarity"] = "Legendary",
			["prize"] = v1.trophies(3.5, 18)
		}
	}
}
local v5 = {
	["id"] = "gift60",
	["name"] = "Every 60 Min",
	["minutes"] = 60,
	["max"] = 1,
	["color"] = "#FFC93C",
	["icon"] = "rbxassetid://135629275004235",
	["drops"] = nil,
	["drops"] = {
		{
			["prize"] = nil,
			["weight"] = 47,
			["rarity"] = "Rare",
			["prize"] = v1.trophies(4.5, 25)
		},
		{
			["prize"] = nil,
			["weight"] = 25,
			["rarity"] = "Epic",
			["prize"] = v1.worldEgg(2, 3)
		},
		{
			["prize"] = nil,
			["weight"] = 13,
			["rarity"] = "Epic",
			["prize"] = v1.boost("chakra", 8)
		},
		{
			["prize"] = nil,
			["weight"] = 12,
			["rarity"] = "Legendary",
			["prize"] = v1.boost("wins", 15)
		},
		{
			["prize"] = nil,
			["weight"] = 3,
			["rarity"] = "Mythic",
			["prize"] = v1.trophies(20, 125)
		}
	}
}
__set_list(v2, 1, {v3, v4, v5})
return v2