local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.new(1, 1, 1)
local v_u_5 = Color3.fromRGB(205, 125, 255)
local v6 = Color3.fromRGB(240, 230, 255)
local v_u_7 = Color3.new(v6.R * 2.4, v6.G * 2.4, v6.B * 2.4)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_3
	return {
		["w5_dark_star"] = function(p_u_9, p10)
			-- upvalues: (ref) v_u_2, (ref) v_u_5, (ref) v_u_4, (ref) v_u_7, (copy) p_u_8, (ref) v_u_3
			local v_u_11 = v_u_2.color(p10.color)
			local v12 = v_u_2.color(p10.color2)
			local v13 = p10.id == "dark_star"
			local v14
			if v13 then
				v14 = v_u_5
			else
				v14 = v_u_11:Lerp(v_u_4, 0.3)
			end
			local v15
			if v13 then
				v15 = v_u_7
			else
				v15 = Color3.new(v12.R * 2.4, v12.G * 2.4, v12.B * 2.4)
			end
			local v16 = p_u_9.headY / 1.5
			local v_u_17 = math.clamp(v16, 0.7, 3)
			local v_u_18 = v_u_17 * 2.9
			local v_u_25 = p_u_8.group(p_u_9, function(p19)
				-- upvalues: (copy) v_u_17, (ref) p_u_8
				local v20 = (p19 * CFrame.new(0, v_u_17 * 0.35, 0)).Position
				local v21 = p_u_8.camPos() - v20
				local v22 = v21.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v21.Unit
				local v23 = v22.Y
				local v24 = math.abs(v23) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
				return CFrame.lookAt(v20, v20 + v22, v24) * CFrame.Angles(-1.5707963267948966, 0, 0)
			end)
			local v_u_27 = p_u_8.throb(p_u_9, 4.4, 4.4, 1.8, function(p26)
				-- upvalues: (ref) v_u_2, (ref) p_u_8, (copy) p_u_9, (copy) v_u_11, (ref) v_u_3, (copy) v_u_17, (ref) v_u_4
				v_u_2.ring(p_u_8.feetAt(p_u_9, p26, 0.15), v_u_11, 5.5 * p_u_9.fx, 0.55, v_u_3.Ring)
				v_u_2.flash((p26 * CFrame.new(0, v_u_17 * 0.35, 0)).Position, v_u_4, v_u_17 * 3.2 * p_u_9.fx, 0.25)
			end)
			local v_u_28 = v_u_18
			local v_u_29 = 0
			local v30 = p_u_9.ticks
			local function v38(_, p31, p32)
				-- upvalues: (ref) v_u_29, (ref) v_u_28, (copy) v_u_18
				v_u_29 = v_u_29 + p32 * 0.45
				local v33 = p31 % 4.4
				if p31 >= 4.08 and v33 >= 4.08 then
					local v34 = (v33 - 4.08) / 0.32
					v_u_28 = v_u_18 * (1 - v34 * v34)
					return
				elseif p31 >= 4.4 and v33 < 0.6 then
					local v35 = v_u_18
					local v36 = v33 / 0.6 - 1
					local v37 = v36 * 2.6 * v36 * v36 + 1 + v36 * 1.6 * v36
					v_u_28 = v35 * math.max(v37, 0.02)
				else
					v_u_28 = v_u_18
				end
			end
			table.insert(v30, v38)
			local v39, v_u_40 = p_u_8.picture(v_u_18 * 2, v_u_3.Ring, v_u_11, 0.15)
			p_u_8.add(p_u_9, v39, function(_, p41)
				-- upvalues: (copy) v_u_25, (copy) v_u_17
				return v_u_25.cf * CFrame.new(0, v_u_17 * -0.8, 0) * CFrame.Angles(0, p41 * 0.2, 0)
			end)
			local v42 = p_u_8.picture(v_u_18 * 2.6, v_u_3.Glow, v_u_11, 0.6)
			p_u_8.add(p_u_9, v42, function()
				-- upvalues: (copy) v_u_25, (copy) v_u_17
				return v_u_25.cf * CFrame.new(0, v_u_17 * -1.2, 0)
			end)
			local v_u_43 = v_u_29
			local v_u_44 = v_u_28
			local v_u_45 = {}
			for v_u_46 = 1, 4 do
				local v47, v48 = p_u_8.picture(v_u_17 * 4.2, v_u_3.DarkStar, v_u_4, 0)
				for _, v49 in v48 do
					v49.Color3 = v15
				end
				table.insert(v_u_45, v47)
				p_u_8.add(p_u_9, v47, function(_, p50)
					-- upvalues: (ref) v_u_43, (copy) v_u_46, (copy) v_u_25, (ref) v_u_44, (copy) v_u_17
					local v51 = v_u_43 + (v_u_46 - 1) * 3.141592653589793 / 2
					local v52 = v_u_25.cf * CFrame.new(math.cos(v51) * v_u_44, v_u_17 * -0.55, math.sin(v51) * v_u_44)
					local v53 = CFrame.Angles
					local v54 = p50 * 1.3 + v_u_46
					return v52 * v53(0, math.sin(v54) * 0.25, 0)
				end)
				p_u_8.add(p_u_9, p_u_8.ball(v_u_17 * 0.34, v_u_4, 0), function()
					-- upvalues: (ref) v_u_43, (copy) v_u_46, (copy) v_u_25, (ref) v_u_44, (copy) v_u_17
					local v55 = v_u_43 + (v_u_46 - 1) * 3.141592653589793 / 2
					return v_u_25.cf * CFrame.new(math.cos(v55) * v_u_44, v_u_17 * -0.6, math.sin(v55) * v_u_44)
				end)
				for v_u_56 = 1, 3 do
					local v57
					if v_u_56 == 1 then
						v57 = v12
					else
						v57 = v_u_11
					end
					local v58 = p_u_8.bar(Vector3.new(1, 1, 1), v57, (v_u_56 - 1) * 0.25 + 0.1)
					local v_u_59 = p_u_8.scalable(v58)
					p_u_8.add(p_u_9, v58, function()
						-- upvalues: (ref) v_u_43, (copy) v_u_46, (copy) v_u_56, (ref) v_u_44, (copy) v_u_17, (copy) v_u_59, (copy) v_u_25
						local v60 = v_u_43 + (v_u_46 - 1) * 3.141592653589793 / 2 - (v_u_56 - 0.4) * 0.17
						local v61 = v_u_44
						local v62 = math.cos(v60) * v61
						local v63 = v_u_17 * -0.7
						local v64 = math.sin(v60) * v61
						local v65 = Vector3.new(v62, v63, v64)
						local v66 = -math.sin(v60)
						local v67 = math.cos(v60)
						local v68 = Vector3.new(v66, 0, v67)
						local v69 = (0.3 - v_u_56 * 0.06) * v_u_17
						local v70 = v_u_59
						local v71 = v61 * 0.17 * 1.15
						local v72 = math.max(v71, 0.05)
						v70.Scale = Vector3.new(v69, v69, v72)
						return v_u_25.cf * CFrame.lookAt(v65, v65 + v68)
					end)
				end
			end
			local v_u_73 = -1
			local v74 = p_u_9.ticks
			local function v84(_, p75)
				-- upvalues: (copy) v_u_45, (copy) v_u_17, (copy) v_u_27, (ref) v_u_73, (copy) v_u_40
				for v76, v77 in v_u_45 do
					local v78 = v_u_17 * 4.2
					local v79 = p75 * 2.2 + v76 * 1.3
					local v80 = math.sin(v79)
					local v81 = v78 * (math.abs(v80) * 0.2 + 0.85)
					v77.Size = Vector3.new(v81, 0.05, v81)
				end
				local v82 = v_u_27()
				if v82 ~= v_u_73 then
					v_u_73 = v82
					for _, v83 in v_u_40 do
						v83.Transparency = 0.15 * (1 - v82)
					end
				end
			end
			table.insert(v74, v84)
			local v_u_85 = p_u_8.blob(Vector3.new(1, 1, 1), v14, 1)
			local v_u_86 = p_u_8.blob(Vector3.new(1, 1, 1), v_u_4, 1)
			p_u_8.add(p_u_9, v_u_85, function()
				-- upvalues: (copy) v_u_25, (copy) v_u_17
				return v_u_25.cf * CFrame.new(0, v_u_17 * 0.9, 0)
			end)
			p_u_8.add(p_u_9, v_u_86, function()
				-- upvalues: (copy) v_u_25, (copy) v_u_17
				return v_u_25.cf * CFrame.new(0, v_u_17 * 0.95, 0)
			end)
			local v_u_87 = false
			local v88 = p_u_9.ticks
			local function v96()
				-- upvalues: (copy) v_u_27, (ref) v_u_87, (copy) v_u_85, (copy) v_u_86, (copy) v_u_17
				local v89 = v_u_27()
				if v89 <= 0 then
					if v_u_87 then
						v_u_87 = false
						v_u_85.Transparency = 1
						v_u_86.Transparency = 1
					end
				else
					v_u_87 = true
					local v90 = v_u_17 * 2.8 * (0.45 + 0.55 * v89)
					local v91 = v_u_85
					local v92 = v_u_17 * 0.6 * v89 + 0.05
					v91.Size = Vector3.new(v92, 0.1, v90)
					local v93 = v_u_86
					local v94 = v_u_17 * 0.2 * v89 + 0.03
					local v95 = v90 * 0.8
					v93.Size = Vector3.new(v94, 0.12, v95)
					v_u_85.Transparency = 0.1 + 0.9 * (1 - v89) ^ 2
					v_u_86.Transparency = (1 - v89) ^ 2
				end
			end
			table.insert(v88, v96)
			p_u_8.particles(p_u_9, "AuraMode", v_u_11, {
				["rate"] = 0.4,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_8.particles(p_u_9, "Petals", v12, {
				["rate"] = 0.8,
				["glow"] = 0.7,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end