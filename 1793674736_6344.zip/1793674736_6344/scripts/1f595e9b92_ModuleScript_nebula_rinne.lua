local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.new(1, 1, 1)
local v_u_7 = Color3.fromRGB(255, 125, 215)
local v_u_8 = Color3.fromRGB(115, 210, 255)
local v9 = Color3.fromRGB(235, 225, 255)
local v_u_10 = Color3.new(v9.R * 2.35, v9.G * 2.35, v9.B * 2.35)
return function(p_u_11)
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_1
	return {
		["w5_nebula_rinne"] = function(p_u_12, p13)
			-- upvalues: (ref) v_u_3, (copy) p_u_11, (ref) v_u_6, (ref) v_u_5, (ref) v_u_4, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_1
			local v_u_14 = v_u_3.color(p13.color)
			local v15 = p_u_12.headY / 1.5
			local v_u_16 = math.clamp(v15, 0.7, 3)
			local v_u_17 = 0
			local v18 = p_u_12.ticks
			local function v25(_, p19)
				-- upvalues: (ref) v_u_17
				if p19 < 4.6 then
					v_u_17 = 0
					return
				else
					local v20 = p19 % 4.6
					if v20 < 0.35 then
						local v21 = v20 / 0.35
						local v22 = math.clamp(v21, 0, 1)
						v_u_17 = v22 * v22 * (3 - v22 * 2)
						return
					elseif v20 < 0.75 then
						v_u_17 = 1
					else
						local v23 = (v20 - 0.35 - 0.4) / 0.5
						local v24 = math.clamp(v23, 0, 1)
						v_u_17 = 1 - v24 * v24 * (3 - v24 * 2)
					end
				end
			end
			table.insert(v18, v25)
			local v_u_26 = nil
			p_u_11.throb(p_u_12, 4.6, 4.949999999999999, 1.6, function(p27)
				-- upvalues: (ref) v_u_3, (ref) v_u_6, (copy) v_u_16, (copy) p_u_12, (ref) p_u_11, (copy) v_u_14, (ref) v_u_5, (ref) v_u_26, (ref) v_u_4
				v_u_3.flash(p27.Position, v_u_6, v_u_16 * 4 * p_u_12.fx, 0.25)
				v_u_3.ring(p_u_11.feetAt(p_u_12, p27, 0.15), v_u_14, 6 * p_u_12.fx, 0.55, v_u_5.Ring)
				local v28 = v_u_26
				if v28 then
					v28:Emit(v_u_4.level() <= 1 and 2 or 6)
				end
			end)
			local v29 = {
				{
					["r"] = nil,
					["y"] = nil,
					["ride"] = 0.9,
					["tomoe"] = nil,
					["wobble"] = 0.7,
					["r"] = v_u_16 * 3,
					["y"] = p_u_12.feet + v_u_16 * 1,
					["tomoe"] = v_u_16 * 1.45
				},
				{
					["r"] = nil,
					["y"] = nil,
					["ride"] = -1.2,
					["tomoe"] = nil,
					["wobble"] = -0.9,
					["r"] = v_u_16 * 2.3,
					["y"] = v_u_16 * 0.25,
					["tomoe"] = v_u_16 * 1.25
				},
				{
					["r"] = nil,
					["y"] = nil,
					["ride"] = 1.6,
					["tomoe"] = nil,
					["wobble"] = 1.2,
					["r"] = v_u_16 * 1.5,
					["y"] = p_u_12.headY + v_u_16 * 1.1,
					["tomoe"] = v_u_16 * 1.05
				}
			}
			local v_u_30 = v_u_16 * -0.1
			local v_u_31 = v_u_17
			for v_u_32, v_u_33 in v29 do
				local v_u_43 = p_u_11.group(p_u_12, function(p34, p35)
					-- upvalues: (copy) v_u_33, (copy) v_u_30, (ref) v_u_31, (copy) v_u_32
					local v36 = v_u_33.y + (v_u_30 - v_u_33.y) * v_u_31
					local v37 = (1 - v_u_31) * 0.14
					local v38 = p35 * v_u_33.wobble + v_u_32
					local v39 = CFrame.new(p34.Position + Vector3.new(0, 1, 0) * v36)
					local v40 = CFrame.fromAxisAngle
					local v41 = math.cos(v38)
					local v42 = math.sin(v38)
					return v39 * v40(Vector3.new(v41, 0, v42), v37)
				end)
				local v44 = p_u_11.add
				local v45 = v_u_33.r * 2
				local v46 = v_u_5.Ring
				local v47, v48 = p_u_11.picture(v45, v46, v_u_6, 0)
				local v49 = p_u_12
				for _, v50 in v48 do
					v50.Color3 = v_u_10
				end
				v44(p_u_12, v47, function()
					-- upvalues: (copy) v_u_43
					return v_u_43.cf
				end)
				local v51 = p_u_11.add
				local v52 = v_u_33.r * 1.93
				local v53 = v_u_5.Ring
				local v54, v55 = p_u_11.picture(v52, v53, v_u_6, 0)
				p_u_12 = v49
				for _, v56 in v55 do
					v56.Color3 = v_u_10
				end
				v51(v49, v54, function()
					-- upvalues: (copy) v_u_43
					return v_u_43.cf * CFrame.new(0, 0.02, 0)
				end)
				p_u_11.add(p_u_12, p_u_11.picture(v_u_33.r * 2.3, v_u_5.Ring, v_u_14, 0.15), function()
					-- upvalues: (copy) v_u_43
					return v_u_43.cf * CFrame.new(0, -0.04, 0)
				end)
				for v_u_57 = 1, 3 do
					local v58 = v_u_33.tomoe
					local v59 = v_u_5.NebulaTomoe
					local v60, v61 = p_u_11.picture(v58, v59, v_u_6, 0)
					for _, v62 in v61 do
						v62.Color3 = v_u_10
					end
					p_u_11.add(p_u_12, v60, function(_, p63)
						-- upvalues: (copy) v_u_33, (copy) v_u_57, (ref) v_u_31, (copy) v_u_43, (ref) p_u_11
						local v64 = v_u_33.ride * p63 + (v_u_57 - 1) * 3.141592653589793 * 2 / 3
						local v65 = v_u_31
						local v66 = v64 + ((1.5707963267948966 + (v_u_57 - 1) * 3.141592653589793 * 2 / 3 - v64 + 3.141592653589793) % 6.283185307179586 - 3.141592653589793) * v65
						local v67 = v_u_43.cf
						local v68 = math.cos(v66) * v_u_33.r
						local v69 = math.sin(v66) * v_u_33.r
						local v70 = v67 * Vector3.new(v68, 0.05, v69)
						local v71 = p_u_11.camPos() - v70
						local v72 = v71.Magnitude <= 0.01 and Vector3.new(0, 0, 1) or v71.Unit
						local v73 = v72.Y
						local v74 = math.abs(v73) > 0.98 and Vector3.new(1, 0, 0) or Vector3.new(0, 1, 0)
						return CFrame.lookAt(v70, v70 + v72, v74) * CFrame.Angles(-1.5707963267948966, 0, 0) * CFrame.Angles(0, -v66 * (v_u_33.ride > 0 and 1 or -1), 0)
					end)
				end
			end
			for v_u_75 = 1, 5 do
				local v76 = p_u_11.bar(Vector3.new(1, 1, 1), v_u_6, 0)
				local v_u_77 = p_u_11.scalable(v76)
				p_u_11.add(p_u_12, v76, function(p78, p79)
					-- upvalues: (copy) v_u_75, (copy) p_u_12, (copy) v_u_16, (copy) v_u_77
					local v80 = (p79 * 0.28 + v_u_75 / 5) % 1
					local v81 = p_u_12.feet + v_u_16 * 0.6 + (p_u_12.headY + v_u_16 * 1.4 - p_u_12.feet) * v80
					local v82 = (2.4 - 1.5 * v80) * v_u_16
					local v83 = p79 * 1.1 + v_u_75 * 1.3
					local v84 = p79 * 3 + v_u_75
					local v85 = math.sin(v84)
					local v86 = math.abs(v85) * 0.18 + 0.12
					local v87 = v80 / 0.1
					local v88 = (1 - v80) / 0.15
					local v89 = math.min(v87, v88, 1)
					local v90 = v_u_77
					local v91 = v86 * v89 * v_u_16
					v90.Scale = Vector3.new(1, 1, 1) * math.max(v91, 0.01)
					local v92 = CFrame.new
					local v93 = p78.Position
					local v94 = math.cos(v83) * v82
					local v95 = math.sin(v83) * v82
					return v92(v93 + Vector3.new(v94, v81, v95)) * CFrame.Angles(0, 0, 0.7853981633974483)
				end)
			end
			local v_u_96 = Instance.new("Attachment")
			local v97 = v_u_16 * -0.6
			v_u_96.Position = Vector3.new(0, v97, 0)
			local v_u_98 = Instance.new("ParticleEmitter")
			v_u_98.Texture = "rbxassetid://84314209625046"
			v_u_98.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v_u_98.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_98.Color = ColorSequence.new({ ColorSequenceKeypoint.new(0, v_u_14), ColorSequenceKeypoint.new(0.5, v_u_7), ColorSequenceKeypoint.new(1, v_u_8) })
			v_u_98.LightEmission = 0.45
			v_u_98.LightInfluence = 0
			v_u_98.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(0.5, 0.6), NumberSequenceKeypoint.new(1, 1) })
			v_u_98.Lifetime = NumberRange.new(1.6, 2.2)
			v_u_98.Size = NumberSequence.new(v_u_16 * 1 * p_u_12.fx, v_u_16 * 2.2 * p_u_12.fx)
			v_u_98.Rotation = NumberRange.new(0, 360)
			v_u_98.RotSpeed = NumberRange.new(-30, 30)
			v_u_98.Speed = NumberRange.new(v_u_16 * 1.2 * p_u_12.fx, v_u_16 * 2.4 * p_u_12.fx)
			v_u_98.SpreadAngle = Vector2.new(180, 180)
			local v99 = 1.2 * p_u_12.fx
			v_u_98.Acceleration = Vector3.new(0, v99, 0)
			v_u_98.Drag = 1
			v_u_98:SetAttribute("BaseRate", 5)
			v_u_98.Rate = 5 * v_u_4.formRate()
			v_u_98.Parent = v_u_96
			v_u_96.Parent = p_u_12.root
			v_u_26 = v_u_98
			p_u_11.own(p_u_12, v_u_96)
			local v100 = p_u_12.stops
			local function v101()
				-- upvalues: (copy) v_u_98, (ref) v_u_1, (copy) v_u_96
				v_u_98.Enabled = false
				v_u_1:AddItem(v_u_96, 2.5)
			end
			table.insert(v100, v101)
			p_u_11.particles(p_u_12, "AuraMode", v_u_14, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end