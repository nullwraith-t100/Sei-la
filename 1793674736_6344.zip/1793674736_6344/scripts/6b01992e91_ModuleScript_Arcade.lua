local v_u_1 = game:GetService("ContextActionService")
local v_u_2 = game:GetService("GuiService")
local v_u_3 = game:GetService("HttpService")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("RunService")
local v_u_7 = game:GetService("UserInputService")
local v_u_8 = require(script.Parent.ArcadeKit)
local v_u_9 = require(script.Parent.ArcadeSnake)
local v_u_10 = require(script.Parent.ArcadeBlocks)
local v_u_11 = require(script.Parent.Device)
local v_u_12 = require(script.Parent.Gamepad)
local v_u_13 = require(script.Parent.Menus)
local v_u_14 = require(script.Parent.Sfx)
local v_u_15 = require(script.Parent.Tutorial)
local v16 = v_u_5.Shared
local v_u_17 = require(v16.Config.Arcade)
local v_u_18 = require(v16.Logic.ArcadeLog)
local v_u_19 = require(v16.Logic.Format)
local v_u_20 = {}
local v_u_21 = v4.LocalPlayer
local v_u_22 = {}
local v29 = {
	["id"] = "snake",
	["title"] = "CHAKRA SNAKE",
	["keys"] = nil,
	["make"] = nil,
	["keyboard"] = nil,
	["controller"] = nil,
	["paint"] = nil,
	["preview"] = nil,
	["previewColor"] = nil,
	["ends"] = nil,
	["counts"] = "ORBS EATEN",
	["keys"] = v_u_9.KEYS,
	["make"] = function(p23, p24, p25, p26, p27, p28) -- name: make
		-- upvalues: (copy) v_u_9
		return v_u_9.new(p23, p24, p25, p26, p27, p28)
	end,
	["keyboard"] = {
		{
			["key"] = "WASD",
			["text"] = "TURN"
		},
		{
			["key"] = "ARROWS",
			["text"] = "TURN"
		},
		{
			["key"] = "BACKSPACE",
			["text"] = "PAUSE"
		}
	},
	["controller"] = {
		{
			["pad"] = nil,
			["text"] = "TURN",
			["pad"] = Enum.KeyCode.DPadUp
		},
		{
			["pad"] = nil,
			["text"] = "TURN",
			["pad"] = Enum.KeyCode.Thumbstick1
		},
		{
			["pad"] = nil,
			["text"] = "PAUSE",
			["pad"] = Enum.KeyCode.ButtonB
		}
	},
	["paint"] = { Color3.fromRGB(190, 110, 255), Color3.fromRGB(120, 40, 220) },
	["preview"] = {
		{ 1, 1 },
		{ 1, 2 },
		{ 1, 3 },
		{ 2, 3 },
		{ 3, 3 },
		{ 3, 2 }
	},
	["previewColor"] = Color3.fromRGB(110, 255, 90),
	["ends"] = {
		["wall"] = "CRASHED!",
		["self"] = "CRASHED!",
		["time"] = "TIME!",
		["full"] = "BOARD FULL!"
	}
}
local v36 = {
	["id"] = "blocks",
	["title"] = "CHAKRA BLOCKS",
	["keys"] = nil,
	["make"] = nil,
	["keyboard"] = nil,
	["controller"] = nil,
	["paint"] = nil,
	["preview"] = nil,
	["previewColor"] = nil,
	["ends"] = nil,
	["counts"] = "LINES CLEARED",
	["keys"] = v_u_10.KEYS,
	["make"] = function(p30, p31, p32, p33, p34, p35) -- name: make
		-- upvalues: (copy) v_u_10
		return v_u_10.new(p30, p31, p32, p33, p34, p35)
	end,
	["keyboard"] = {
		{
			["key"] = "A D",
			["text"] = "MOVE"
		},
		{
			["key"] = "W",
			["text"] = "TURN"
		},
		{
			["key"] = "S",
			["text"] = "DOWN"
		},
		{
			["key"] = "SPACE",
			["text"] = "DROP"
		},
		{
			["key"] = "BACKSPACE",
			["text"] = "PAUSE"
		}
	},
	["controller"] = {
		{
			["pad"] = nil,
			["text"] = "MOVE",
			["pad"] = Enum.KeyCode.DPadLeft
		},
		{
			["pad"] = nil,
			["text"] = "TURN",
			["pad"] = Enum.KeyCode.ButtonA
		},
		{
			["pad"] = nil,
			["text"] = "DOWN",
			["pad"] = Enum.KeyCode.DPadDown
		},
		{
			["pad"] = nil,
			["text"] = "DROP",
			["pad"] = Enum.KeyCode.ButtonY
		},
		{
			["pad"] = nil,
			["text"] = "PAUSE",
			["pad"] = Enum.KeyCode.ButtonB
		}
	},
	["paint"] = { Color3.fromRGB(69, 200, 255), Color3.fromRGB(0, 128, 255) },
	["preview"] = {
		{ 1, 3 },
		{ 2, 3 },
		{ 3, 3 },
		{ 2, 2 },
		{ 4, 3 },
		{ 4, 2 },
		{ 4, 1 }
	},
	["previewColor"] = Color3.fromRGB(255, 212, 50),
	["ends"] = {
		["top"] = "BLOCKED OUT!",
		["time"] = "TIME!"
	}
}
__set_list(v_u_22, 1, {v29, v36})
local v_u_37 = Enum.ContextActionPriority.High.Value + 50
local v_u_38 = {
	Enum.KeyCode.W,
	Enum.KeyCode.A,
	Enum.KeyCode.S,
	Enum.KeyCode.D,
	Enum.KeyCode.Q,
	Enum.KeyCode.Z,
	Enum.KeyCode.X,
	Enum.KeyCode.E,
	Enum.KeyCode.R,
	Enum.KeyCode.F,
	Enum.KeyCode.P,
	Enum.KeyCode.Up,
	Enum.KeyCode.Down,
	Enum.KeyCode.Left,
	Enum.KeyCode.Right,
	Enum.KeyCode.Space,
	Enum.KeyCode.Backspace,
	Enum.KeyCode.Return,
	Enum.KeyCode.ButtonA,
	Enum.KeyCode.ButtonB,
	Enum.KeyCode.ButtonX,
	Enum.KeyCode.ButtonY,
	Enum.KeyCode.ButtonL1,
	Enum.KeyCode.ButtonR1,
	Enum.KeyCode.ButtonL2,
	Enum.KeyCode.ButtonR2,
	Enum.KeyCode.DPadUp,
	Enum.KeyCode.DPadDown,
	Enum.KeyCode.DPadLeft,
	Enum.KeyCode.DPadRight,
	Enum.KeyCode.Thumbstick1
}
local v_u_39 = {
	Enum.KeyCode.W,
	Enum.KeyCode.A,
	Enum.KeyCode.S,
	Enum.KeyCode.D,
	Enum.KeyCode.E,
	Enum.KeyCode.R,
	Enum.KeyCode.F,
	Enum.KeyCode.Space,
	Enum.KeyCode.Return,
	Enum.KeyCode.Backspace,
	Enum.KeyCode.ButtonB,
	Enum.KeyCode.ButtonY,
	Enum.KeyCode.ButtonX,
	Enum.KeyCode.ButtonR2,
	Enum.KeyCode.ButtonL1,
	Enum.KeyCode.ButtonR1
}
local v_u_40 = {
	[Enum.KeyCode.Backspace] = true,
	[Enum.KeyCode.P] = true,
	[Enum.KeyCode.ButtonB] = true
}
local v_u_41 = {
	["up"] = Enum.KeyCode.DPadUp,
	["down"] = Enum.KeyCode.DPadDown,
	["left"] = Enum.KeyCode.DPadLeft,
	["right"] = Enum.KeyCode.DPadRight
}
local v_u_42 = "closed"
local v_u_43 = v_u_22[1]
local v_u_44 = nil
local v_u_45 = nil
local v_u_46 = {}
local v_u_47 = nil
local v_u_48 = {}
local v_u_49 = false
local v_u_50 = 0
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = nil
local function v_u_62() -- name: saved
	-- upvalues: (copy) v_u_21, (copy) v_u_3
	local v_u_54 = v_u_21:GetAttribute("Arcade")
	local v55 = {
		["best"] = {}
	}
	if type(v_u_54) ~= "string" then
		return v55
	end
	local function v56()
		-- upvalues: (ref) v_u_3, (copy) v_u_54
		return v_u_3:JSONDecode(v_u_54)
	end
	local v57, v58 = pcall(v56)
	if not v57 or type(v58) ~= "table" then
		return v55
	end
	local v59 = v58.best
	if type(v59) == "table" then
		for v60, v61 in v58.best do
			if type(v61) ~= "number" then
				continue
			end
			v55.best[v60] = v61
		end
	end
	return v55
end
local function v_u_79(p63, p64, p65, p66, p67, p68) -- name: mini
	-- upvalues: (copy) v_u_8
	local v69 = p67 or 4
	local v70 = p68 or 4
	local v71 = Instance.new("Frame")
	v71.Name = "Mini"
	v71.BackgroundTransparency = 1
	v71.AnchorPoint = Vector2.new(0.5, 0.5)
	v71.Position = UDim2.fromScale(0.5, 0.5)
	v71.Size = UDim2.fromScale(v69 == v70 and 0.8 or 1, v69 == v70 and 0.8 or 1)
	v71.ZIndex = p66
	local v72 = Instance.new("UIAspectRatioConstraint")
	v72.AspectRatio = v69 / v70
	v72.Parent = v71
	for v73, v74 in p64 do
		local v75 = Instance.new("Frame")
		v75.Name = "Cell"
		v75.BorderSizePixel = 0
		local v76
		if v73 == 1 then
			v76 = v_u_8.WHITE
		else
			v76 = p65
		end
		v75.BackgroundColor3 = v76
		v75.Position = UDim2.fromScale((v74[1] - 1) / v69 + 0.04 / v69, (v74[2] - 1) / v70 + 0.04 / v70)
		v75.Size = UDim2.fromScale(0.92 / v69, 0.92 / v70)
		v75.ZIndex = p66
		local v77 = Instance.new("UICorner")
		v77.CornerRadius = UDim.new(0.2, 0)
		v77.Parent = v75
		local v78 = Instance.new("UIStroke")
		v78.Thickness = 1.5
		v78.Parent = v75
		v75.Parent = v71
	end
	v71.Parent = p63
end
local function v_u_88(p80, p81, p82) -- name: keyCap
	-- upvalues: (copy) v_u_12, (copy) v_u_8
	local v83 = Instance.new("Frame")
	v83.Name = "Line"
	v83.BackgroundTransparency = 1
	v83.Size = UDim2.fromScale(1, 0.14)
	v83.LayoutOrder = p82
	v83.Parent = p80
	if p81.pad then
		local v84 = Instance.new("ImageLabel")
		v84.Name = "Glyph"
		v84.BackgroundTransparency = 1
		v84.Size = UDim2.fromScale(0.3, 1)
		v84.Image = v_u_12.glyph(p81.pad)
		v84.ScaleType = Enum.ScaleType.Fit
		v84.ZIndex = 21
		v84.Parent = v83
	else
		local v85 = v_u_8.box(v83, "Cap", Color3.fromRGB(235, 238, 248), 0)
		v85.Size = UDim2.fromScale(0.5, 0.9)
		v85.Position = UDim2.fromScale(0, 0.05)
		v85.ZIndex = 21
		local v86 = Instance.new("UIStroke")
		v86.Thickness = 2
		v86.Parent = v85
		local v87 = v_u_8.label(v85, "Key", p81.key or "", UDim2.fromScale(0.9, 0.7), UDim2.fromScale(0.5, 0.5), Color3.fromRGB(30, 30, 40), 0):FindFirstChildOfClass("UIStroke")
		if v87 then
			v87:Destroy()
		end
	end
	v_u_8.label(v83, "Does", p81.text, UDim2.fromScale(0.45, 0.75), UDim2.fromScale(0.77, 0.5), v_u_8.WHITE, 2)
end
local function v_u_94() -- name: fillHelp
	-- upvalues: (ref) v_u_51, (copy) v_u_11, (copy) v_u_12, (ref) v_u_43, (copy) v_u_88
	local v89 = v_u_51
	if v89 then
		for _, v90 in v89.help:GetChildren() do
			if not v90:IsA("Frame") then
				continue
			end
			v90:Destroy()
		end
		v89.help.Visible = not v_u_11.touch()
		local v91
		if v_u_12.active() then
			v91 = v_u_43.controller
		else
			v91 = v_u_43.keyboard
		end
		for v92, v93 in v91 do
			v_u_88(v89.help, v93, v92)
		end
	end
end
local function v_u_99(p95, p96) -- name: strip
	for _, v97 in p96 do
		local v98 = p95:FindFirstChild(v97)
		if not v98 then
			continue
		end
		v98:Destroy()
	end
end
local function v_u_105(p100, p101) -- name: titled
	local v102 = p100:FindFirstChild("Top")
	local v103 = {}
	if v102 then
		for _, v104 in v102:GetChildren() do
			if not v104:IsA("TextLabel") or v104.Name ~= "MainText" then
				continue
			end
			v104.Text = p101
			table.insert(v103, v104)
		end
	end
	return v103
end
local function v_u_108(p106) -- name: topIcon
	-- upvalues: (copy) v_u_79, (copy) v_u_8
	local v107 = p106:FindFirstChild("Top")
	if v107 then
		v107 = v107:FindFirstChild("Icon")
	end
	if not (v107 and v107:IsA("ImageLabel")) then
		return nil
	end
	v107.Image = ""
	v_u_79(v107, {
		{ 2, 1 },
		{ 1, 2 },
		{ 2, 2 },
		{ 3, 2 }
	}, v_u_8.PURPLE, v107.ZIndex + 1, 3, 2)
	return v107
end
local function v_u_113(p109) -- name: closeButtonOf
	-- upvalues: (copy) v_u_8, (copy) v_u_12
	local v110 = p109:FindFirstChild("Top")
	if v110 then
		v110 = v110:FindFirstChild("Close")
	end
	if not (v110 and v110:IsA("TextButton")) then
		return nil
	end
	v110.Selectable = true
	for v111 in v110:GetAttributes() do
		if v111 ~= "Ui-Close" then
			continue
		end
		v110:SetAttribute(v111, nil)
	end
	v_u_8.motion(v110)
	for _, v112 in v110:GetChildren() do
		if v112.Name ~= "PadHint" then
			continue
		end
		v112:Destroy()
	end
	v_u_12.hint(v110, Enum.KeyCode.ButtonB)
	return v110
end
local function v_u_133(p114, p115, p116, p117) -- name: buildPanel
	-- upvalues: (copy) v_u_99, (copy) v_u_105, (copy) v_u_108, (copy) v_u_8, (copy) v_u_22, (copy) v_u_79, (copy) v_u_20
	local v118 = p115:Clone()
	v118.Name = "Panel"
	v118.Visible = false
	v118.Position = UDim2.fromScale(0.5, 0.48)
	v118.Size = UDim2.fromScale(0.62, 0.74)
	v118.ZIndex = 10
	v_u_99(v118, {
		"MainDescription",
		"Face",
		"Gift",
		"Redeem"
	})
	v_u_105(v118, "MINIGAMES")
	v_u_108(v118)
	v_u_8.tiles(v118)
	v118.Parent = p114
	local v119 = Instance.new("Frame")
	v119.Name = "List"
	v119.BackgroundTransparency = 1
	v119.AnchorPoint = Vector2.new(0.5, 0)
	v119.Position = UDim2.fromScale(0.5, 0.26)
	v119.Size = UDim2.fromScale(0.94, 0.54)
	v119.Parent = v118
	local v120 = Instance.new("UIListLayout")
	v120.Padding = UDim.new(0.06, 0)
	v120.SortOrder = Enum.SortOrder.LayoutOrder
	v120.Parent = v119
	local v121 = {}
	for v122, v_u_123 in v_u_22 do
		local v124 = p116:Clone()
		v124.Name = v_u_123.id
		v124.LayoutOrder = v122
		v124.Visible = true
		local v125 = v124:FindFirstChildOfClass("UIAspectRatioConstraint")
		if v125 then
			v125:Destroy()
		end
		v124.Size = UDim2.fromScale(1, 0.47)
		v_u_8.paint(v124, v_u_123.paint[1], v_u_123.paint[2], "Paint")
		local v126 = v124:FindFirstChild("Paint")
		if v126 and v126:IsA("UIGradient") then
			v126.Rotation = 0
		end
		local v127 = v124:FindFirstChild("Title")
		if v127 and v127:IsA("TextLabel") then
			v127.Text = v_u_123.title
		end
		local v128 = v124:FindFirstChild("Icon")
		if v128 and v128:IsA("ImageLabel") then
			v128.Image = ""
			v_u_79(v128, v_u_123.preview, v_u_123.previewColor, v128.ZIndex + 1)
		end
		v_u_99(v124, { "AmountIcon", "Amount" })
		local v129 = v124:FindFirstChild("Progress")
		if v129 and v129:IsA("GuiButton") then
			v129.Selectable = false
			v129.Active = false
			local v130 = v129:FindFirstChild("Fill")
			if v130 and v130:IsA("GuiObject") then
				v130.Visible = false
			end
		end
		local v131 = v124:FindFirstChild("Button")
		if v131 then
			v131:Destroy()
		end
		local v132 = v_u_8.button(p117, "Button", "PLAY")
		v132.AnchorPoint = Vector2.new(0.5, 0.5)
		v132.Position = UDim2.fromScale(0.88, 0.5)
		v132.Size = UDim2.fromScale(0.2, 0.56)
		v132.ZIndex = 5
		v132.Parent = v124
		v132.Activated:Connect(function()
			-- upvalues: (ref) v_u_20, (copy) v_u_123
			v_u_20.play(v_u_123)
		end)
		v_u_8.tiles(v124)
		v124.Parent = v119
		v121[v_u_123.id] = v124
	end
	v_u_8.label(v118, "Training", "YOUR TRAINING KEEPS GOING WHILE YOU PLAY!", UDim2.fromScale(0.86, 0.06), UDim2.fromScale(0.5, 0.86), Color3.fromRGB(110, 205, 255), 2)
	return v118, v121, v_u_8.label(v118, "Message", "", UDim2.fromScale(0.9, 0.06), UDim2.fromScale(0.5, 0.95), v_u_8.GOLD, 2)
end
local function v_u_141(p134, p135, p136, p137, p138) -- name: overlayButton
	-- upvalues: (copy) v_u_8
	local v139 = v_u_8.button(p134, p135, p136)
	v_u_8.paint(v139, p137, p138)
	v139.AnchorPoint = Vector2.new(0.5, 0.5)
	v139.ZIndex = 52
	for _, v140 in v139:GetDescendants() do
		if not v140:IsA("GuiObject") then
			continue
		end
		v140.ZIndex = 52 + v140.ZIndex % 10
	end
	return v139
end
local function v_u_184() -- name: build
	-- upvalues: (ref) v_u_51, (copy) v_u_8, (copy) v_u_133, (copy) v_u_99, (copy) v_u_105, (copy) v_u_108, (copy) v_u_113, (copy) v_u_20, (copy) v_u_141, (copy) v_u_12, (ref) v_u_43
	if v_u_51 then
		return v_u_51
	end
	local v142 = v_u_8.find("Frames.Leave")
	local v143 = v_u_8.find("Templates.QuestRow")
	local v144
	if v142 then
		v144 = v142:FindFirstChild("Redeem")
	else
		v144 = v142
	end
	if not (v142 and (v142:IsA("Frame") and (v143 and (v143:IsA("Frame") and v144)))) then
		return nil
	end
	local v145 = v_u_8.main()
	local v146 = Instance.new("ScreenGui")
	v146.Name = "Arcade"
	v146.ResetOnSpawn = false
	v146.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v146.DisplayOrder = 6
	if v145 and v145:IsA("ScreenGui") then
		v146.IgnoreGuiInset = v145.IgnoreGuiInset
		v146.ScreenInsets = v145.ScreenInsets
	end
	v146.Enabled = false
	local v147 = Instance.new("TextButton")
	v147.Name = "Backdrop"
	v147.Text = ""
	v147.AutoButtonColor = false
	v147.Selectable = false
	v147.BackgroundColor3 = Color3.new(0, 0, 0)
	v147.BackgroundTransparency = 0.45
	v147.BorderSizePixel = 0
	v147.AnchorPoint = Vector2.new(0.5, 0.5)
	v147.Position = UDim2.fromScale(0.5, 0.5)
	v147.Size = UDim2.new(1, 600, 1, 600)
	v147.ZIndex = 1
	v147.Parent = v146
	local v148, v149, v150 = v_u_133(v146, v142, v143, v144)
	local v151 = v142:Clone()
	v151.Name = "Game"
	v151.Visible = false
	v_u_99(v151, {
		"MainDescription",
		"Face",
		"Gift",
		"Redeem",
		"UIAspectRatioConstraint"
	})
	v151.AnchorPoint = Vector2.new(0.5, 0)
	v151.ZIndex = 10
	local v152 = v_u_105(v151, "")
	local v153 = v_u_108(v151) or v151
	local v154 = v151:FindFirstChild("Top")
	v154.AnchorPoint = Vector2.new(0.5, 0)
	v154.Position = UDim2.fromScale(0.5, 0)
	local v155 = v_u_113(v151)
	if v155 then
		v_u_8.setText(v155, "II")
		v_u_8.paint(v155, Color3.fromRGB(90, 200, 255), Color3.fromRGB(40, 120, 255))
		v155.Activated:Connect(function()
			-- upvalues: (ref) v_u_20
			v_u_20.pause()
		end)
	end
	local v156 = v_u_8.label(v154, "Score", "0", UDim2.fromScale(0.2, 0.62), UDim2.fromScale(0.66, 0.5), v_u_8.WHITE, 2.5)
	local v157 = v_u_8.label(v154, "Best", "", UDim2.fromScale(0.16, 0.42), UDim2.fromScale(0.82, 0.5), v_u_8.GOLD, 2)
	local v158 = v_u_8.box(v151, "Timer", Color3.fromRGB(20, 22, 36), 0.2)
	v158.AnchorPoint = Vector2.new(0.5, 0)
	local v159 = v_u_8.box(v158, "Fill", v_u_8.CYAN, 0)
	v159.Size = UDim2.fromScale(1, 1)
	local v160 = v_u_8.label(v151, "Time", "", UDim2.fromOffset(100, 30), UDim2.fromOffset(0, 0), v_u_8.WHITE, 2.5)
	local v161 = Instance.new("Frame")
	v161.Name = "Left"
	v161.BackgroundTransparency = 1
	v161.ZIndex = 12
	v161.Parent = v151
	local v162 = Instance.new("Frame")
	v162.Name = "Right"
	v162.BackgroundTransparency = 1
	v162.ZIndex = 12
	v162.Parent = v151
	local v163 = Instance.new("Frame")
	v163.Name = "Area"
	v163.BackgroundTransparency = 1
	v163.ZIndex = 12
	v163.Parent = v151
	local v164 = Instance.new("Frame")
	v164.Name = "Help"
	v164.BackgroundTransparency = 1
	v164.ZIndex = 12
	v164.Parent = v151
	local v165 = Instance.new("UIListLayout")
	v165.Padding = UDim.new(0.03, 0)
	v165.SortOrder = Enum.SortOrder.LayoutOrder
	v165.VerticalAlignment = Enum.VerticalAlignment.Center
	v165.Parent = v164
	local v166 = v_u_8.box(v151, "Cover", Color3.new(0, 0, 0), 0.35)
	v166.ZIndex = 50
	v166.Visible = false
	local v167 = v_u_8.label(v151, "Countdown", "", UDim2.fromScale(0.3, 0.25), UDim2.fromScale(0.5, 0.55), v_u_8.GOLD, 4)
	v167.ZIndex = 55
	local v168 = Instance.new("Frame")
	v168.Name = "Pause"
	v168.BackgroundTransparency = 1
	v168.Size = UDim2.fromScale(1, 1)
	v168.ZIndex = 51
	v168.Visible = false
	v168.Parent = v166
	v_u_8.label(v168, "Title", "PAUSED", UDim2.fromScale(0.5, 0.16), UDim2.fromScale(0.5, 0.3), v_u_8.WHITE, 4).ZIndex = 52
	local v169 = v_u_141(v144, "Resume", "RESUME", Color3.fromRGB(58, 255, 14), Color3.fromRGB(40, 196, 14))
	v169.Position = UDim2.fromScale(0.5, 0.52)
	v169.Size = UDim2.fromScale(0.3, 0.14)
	v169.Parent = v168
	local v170 = v_u_141(v144, "Quit", "END ROUND", Color3.fromRGB(255, 70, 70), Color3.fromRGB(214, 18, 40))
	v170.Position = UDim2.fromScale(0.5, 0.72)
	v170.Size = UDim2.fromScale(0.3, 0.14)
	v170.Parent = v168
	v_u_12.hint(v170, Enum.KeyCode.ButtonB)
	v169.Activated:Connect(function()
		-- upvalues: (ref) v_u_20
		v_u_20.resume()
	end)
	v170.Activated:Connect(function()
		-- upvalues: (ref) v_u_20
		v_u_20.finish()
	end)
	local v171 = v_u_8.label(v166, "Checking", "", UDim2.fromScale(0.6, 0.12), UDim2.fromScale(0.5, 0.5), v_u_8.WHITE, 3)
	v171.ZIndex = 52
	v151.Parent = v146
	local v172 = v142:Clone()
	v172.Name = "Results"
	v172.Visible = false
	v172.Position = UDim2.fromScale(0.5, 0.42)
	v172.Size = UDim2.fromScale(0.56, 0.62)
	v172.ZIndex = 10
	v_u_99(v172, {
		"MainDescription",
		"Face",
		"Gift",
		"Redeem"
	})
	local v173 = v_u_105(v172, "")
	v_u_108(v172)
	local v174 = v_u_113(v172)
	if v174 then
		local v175 = v174:FindFirstChild("PadHint")
		if v175 then
			v175:Destroy()
		end
		v174.Activated:Connect(function()
			-- upvalues: (ref) v_u_20
			v_u_20.close()
		end)
	end
	local v176 = v_u_8.label(v172, "Score", "0", UDim2.fromScale(0.6, 0.17), UDim2.fromScale(0.5, 0.35), v_u_8.WHITE, 3.5)
	local v177 = v_u_8.label(v172, "Best", "", UDim2.fromScale(0.6, 0.08), UDim2.fromScale(0.5, 0.47), v_u_8.GOLD, 2.5)
	local v178 = v_u_8.label(v172, "Count", "", UDim2.fromScale(0.7, 0.075), UDim2.fromScale(0.5, 0.6), Color3.fromRGB(110, 255, 90), 2.5)
	local v179 = v_u_8.label(v172, "Note", "", UDim2.fromScale(0.86, 0.055), UDim2.fromScale(0.5, 0.72), Color3.fromRGB(200, 210, 230), 1.5)
	local v180 = v_u_141(v144, "Again", "PLAY AGAIN", Color3.fromRGB(58, 255, 14), Color3.fromRGB(40, 196, 14))
	v180.ZIndex = 20
	v180.Position = UDim2.fromScale(0.3, 0.88)
	v180.Size = UDim2.fromScale(0.36, 0.13)
	v180.Parent = v172
	local v181 = v_u_141(v144, "Back", "MENU", Color3.fromRGB(90, 200, 255), Color3.fromRGB(40, 120, 255))
	v181.ZIndex = 20
	v181.Position = UDim2.fromScale(0.7, 0.88)
	v181.Size = UDim2.fromScale(0.36, 0.13)
	v181.Parent = v172
	v_u_12.hint(v181, Enum.KeyCode.ButtonB)
	v180.Activated:Connect(function()
		-- upvalues: (ref) v_u_20, (ref) v_u_43
		v_u_20.play(v_u_43)
	end)
	v181.Activated:Connect(function()
		-- upvalues: (ref) v_u_20
		v_u_20.openPanel()
	end)
	v_u_8.tiles(v172)
	v172.Parent = v146
	local v182 = v_u_113(v148)
	if v182 then
		v182.Activated:Connect(function()
			-- upvalues: (ref) v_u_20
			v_u_20.close()
		end)
	end
	if v145 then
		v146.Parent = v145.Parent
	end
	local v183 = {
		["screen"] = v146,
		["backdrop"] = v147,
		["panel"] = v148,
		["rows"] = v149,
		["message"] = v150,
		["window"] = v151,
		["windowTitle"] = v152,
		["windowIcon"] = v153,
		["score"] = v156,
		["best"] = v157,
		["time"] = v160,
		["timer"] = v158,
		["timerFill"] = v159,
		["left"] = v161,
		["right"] = v162,
		["area"] = v163,
		["help"] = v164,
		["cover"] = v166,
		["countdown"] = v167,
		["pause"] = v168,
		["resume"] = v169,
		["quit"] = v170,
		["checking"] = v171,
		["results"] = v172,
		["resultTitle"] = v173,
		["resultScore"] = v176,
		["resultBest"] = v177,
		["resultCount"] = v178,
		["resultNote"] = v179,
		["again"] = v180,
		["back"] = v181
	}
	v_u_12.root(v148)
	v_u_12.root(v168)
	v_u_12.root(v172)
	v_u_51 = v183
	return v183
end
local function v_u_214() -- name: layout
	-- upvalues: (ref) v_u_51, (copy) v_u_2, (copy) v_u_12, (copy) v_u_11
	local v185 = v_u_51
	if v185 then
		local v186 = v185.screen.AbsoluteSize
		local v187 = v186.X
		local v188 = v186.Y
		if v187 >= 50 and v188 >= 50 then
			local v189 = v_u_2.TopbarInset
			local v190 = not v185.screen.IgnoreGuiInset and 0 or v189.Max.Y
			local v191 = v_u_12.tv()
			local v192
			if v191 then
				local v193 = v188 * 0.05
				v192 = math.floor(v193)
			else
				v192 = 4
			end
			local v194
			if v191 then
				local v195 = v187 * 0.9
				v194 = math.floor(v195)
			else
				v194 = v187 - 16
			end
			local v196
			if v191 then
				local v197 = v188 * 0.9
				v196 = math.floor(v197)
			else
				v196 = v188 - v192 - 8
			end
			local v198
			if v190 > 0 then
				local v199 = v189.Min.X - 2 - (not v191 and 0 or (v187 - v194) / 2)
				v198 = math.max(0, v199)
			else
				v198 = 0
			end
			local v200 = v_u_11.touch()
			v185.window.Position = UDim2.fromOffset(v187 / 2, v192)
			v185.window.Size = UDim2.fromOffset(v194, v196)
			local v201 = v188 * 0.1
			local v202 = math.clamp(v201, 36, 74)
			local v203 = v185.window:FindFirstChild("Top")
			if v203 and v203:IsA("GuiObject") then
				v203.AnchorPoint = Vector2.new(1, 0)
				v203.Position = UDim2.fromScale(1, 0)
				v203.Size = UDim2.new(1, -v198, 0, v202)
			end
			local v204 = v190 - v192
			local v205 = math.max(v202, v204) + 6
			local v206 = v188 * 0.012
			local v207 = math.clamp(v206, 5, 10)
			v185.timer.Position = UDim2.fromOffset(v194 / 2, v205)
			v185.timer.Size = UDim2.fromOffset(v194 - 24, v207)
			local v208 = v205 + v207 + 8
			local v209 = v196 - v208 - 8
			local v210 = v194 * (v200 and 0.27 or 0.24)
			local v211 = math.floor(v210)
			v185.left.Position = UDim2.fromOffset(10, v208)
			v185.left.Size = UDim2.fromOffset(v211 - 16, v209)
			v185.help.Position = UDim2.fromOffset(16, v208 + v209 * 0.1)
			v185.help.Size = UDim2.fromOffset(v211 - 28, v209 * 0.8)
			local v212 = v209 * 0.12
			local v213 = math.clamp(v212, 22, 54)
			v185.time.AnchorPoint = Vector2.new(0.5, 0)
			v185.time.Position = UDim2.fromOffset(v194 - v211 / 2, v208)
			v185.time.Size = UDim2.fromOffset(v211 * 0.8, v213)
			v185.right.Position = UDim2.fromOffset(v194 - v211 + 6, v208 + v213 + 6)
			v185.right.Size = UDim2.fromOffset(v211 - 16, v209 - v213 - 6)
			v185.area.Position = UDim2.fromOffset(v211, v208)
			v185.area.Size = UDim2.fromOffset(v194 - v211 * 2, v209)
			v185.cover.Position = UDim2.fromOffset(8, v208 - 4)
			v185.cover.Size = UDim2.fromOffset(v194 - 16, v209 + 8)
			v185.countdown.Position = UDim2.fromOffset(v194 / 2, v208 + v209 * 0.45)
			v185.countdown.Size = UDim2.fromOffset(v194 * 0.3, v209 * 0.3)
		end
	else
		return
	end
end
local function v_u_221() -- name: coveredInMain
	-- upvalues: (copy) v_u_8
	local v215 = v_u_8.main()
	if not v215 then
		return false
	end
	for _, v216 in { "GiftPicker", "GiftPopUp" } do
		local v217 = v215:FindFirstChild(v216)
		if not (v217 and (v217:IsA("GuiObject") and v217.Visible)) then
			continue
		end
		return true
	end
	local v218 = v_u_8.find("HUD.Overlay")
	if v218 then
		for _, v219 in { "Hatch", "Spin" } do
			local v220 = v218:FindFirstChild(v219)
			if not (v220 and (v220:IsA("GuiObject") and v220.Visible)) then
				continue
			end
			return true
		end
	end
	return false
end
local function v_u_226() -- name: buttonWanted
	-- upvalues: (ref) v_u_42, (copy) v_u_21, (copy) v_u_15, (copy) v_u_13, (copy) v_u_221
	local v222
	if v_u_42 == "closed" then
		local v223 = v_u_21:GetAttribute("TrainSpot")
		local v224 = v_u_21:GetAttribute("TrainMult")
		local v225
		if type(v223) == "number" and (v223 > 0 and type(v224) == "number") then
			v225 = v224 > 1
		else
			v225 = false
		end
		v222 = v225 and (v_u_21:GetAttribute("TutorialDone") == true and v_u_21:GetAttribute("InWave") ~= true and (v_u_15.known() and not v_u_15.active()))
		if v222 then
			if v_u_13.current() == nil then
				v222 = not v_u_221()
			else
				v222 = false
			end
		end
	else
		v222 = false
	end
	return v222
end
local function v_u_234() -- name: placeButton
	-- upvalues: (ref) v_u_53, (copy) v_u_8, (ref) v_u_52
	local v227 = v_u_53
	local v228 = v_u_8.find("HUD.Bottom")
	local v229 = v_u_52
	if v227 and (v229 and (v228 and v228:IsA("GuiObject"))) then
		local v230 = v229.AbsoluteSize.Y * 0.07
		local v231 = math.clamp(v230, 34, 66)
		v227.Size = UDim2.fromOffset(v231 * 3.6, v231)
		local v232 = v228.AbsolutePosition.X + v228.AbsoluteSize.X * 0.5
		local v233 = v228.AbsolutePosition.Y - 8
		v227.Position = UDim2.fromOffset(v232, v233)
	end
end
local function v_u_243() -- name: buildButton
	-- upvalues: (copy) v_u_8, (copy) v_u_79, (copy) v_u_12, (copy) v_u_20, (ref) v_u_52, (ref) v_u_53, (copy) v_u_234
	local v235 = v_u_8.find("HUD.Bottom.ChakraProducts.chakra2")
	local v236 = v_u_8.main()
	if v235 and v236 then
		local v237 = Instance.new("ScreenGui")
		v237.Name = "ArcadeButton"
		v237.ResetOnSpawn = false
		v237.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v237.DisplayOrder = 3
		if v236:IsA("ScreenGui") then
			v237.IgnoreGuiInset = v236.IgnoreGuiInset
			v237.ScreenInsets = v236.ScreenInsets
		end
		local v238 = Instance.new("Frame")
		v238.Name = "Minigames"
		v238.BackgroundTransparency = 1
		v238.AnchorPoint = Vector2.new(0.5, 1)
		v238.Visible = false
		local v239 = v_u_8.button(v235, "Button", "MINIGAMES")
		v239.AnchorPoint = Vector2.new(0.5, 0.5)
		v239.Position = UDim2.fromScale(0.5, 0.5)
		v239.Size = UDim2.fromScale(1, 1)
		local v240 = v239:FindFirstChild("Icon")
		if v240 and v240:IsA("ImageLabel") then
			v240.Image = ""
			v240.Size = UDim2.fromScale(0.2, 0.8)
			v240.Position = UDim2.fromScale(0.13, 0.5)
			v240.AnchorPoint = Vector2.new(0.5, 0.5)
			v_u_79(v240, {
				{ 2, 1 },
				{ 1, 2 },
				{ 2, 2 },
				{ 3, 2 }
			}, v_u_8.GOLD, v240.ZIndex + 1, 3, 2)
		end
		local v241 = v239:FindFirstChild("TextLabel")
		if v241 and v241:IsA("TextLabel") then
			v241.Position = UDim2.fromScale(0.56, 0.5)
			v241.Size = UDim2.fromScale(0.76, 0.72)
		end
		v_u_12.hint(v239, Enum.KeyCode.ButtonY, 30)
		v239.Activated:Connect(function()
			-- upvalues: (ref) v_u_20
			v_u_20.openPanel()
		end)
		v239.Parent = v238
		v238.Parent = v237
		v237.Parent = v236.Parent
		v_u_52 = v237
		v_u_53 = v238
		local v242 = v_u_8.find("HUD.Bottom")
		if v242 and v242:IsA("GuiObject") then
			v242:GetPropertyChangedSignal("AbsolutePosition"):Connect(v_u_234)
			v242:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_234)
		end
		v237:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_234)
		v_u_234()
	end
end
local v_u_244 = false
local function v_u_249() -- name: refreshButton
	-- upvalues: (ref) v_u_53, (copy) v_u_226, (ref) v_u_244, (copy) v_u_8, (copy) v_u_234, (copy) v_u_1, (copy) v_u_20
	local v_u_245 = v_u_53
	if v_u_245 then
		local v246 = v_u_226()
		if v246 == v_u_244 then
			return
		else
			v_u_244 = v246
			local v247 = v_u_8.scaleNamed(v_u_245, "Show")
			if v246 then
				v_u_234()
				v_u_245.Visible = true
				v247.Scale = 0
				v_u_8.tween(v247, 0.35, {
					["Scale"] = 1
				}, Enum.EasingStyle.Back)
				v_u_1:BindActionAtPriority("ArcadeOpenY", function(_, p248)
					-- upvalues: (ref) v_u_226, (ref) v_u_20
					if p248 ~= Enum.UserInputState.Begin or not v_u_226() then
						return Enum.ContextActionResult.Pass
					end
					v_u_20.openPanel()
					return Enum.ContextActionResult.Sink
				end, false, Enum.ContextActionPriority.Medium.Value + 10, Enum.KeyCode.ButtonY)
			else
				v_u_1:UnbindAction("ArcadeOpenY")
				v_u_8.tween(v247, 0.15, {
					["Scale"] = 0
				}, Enum.EasingStyle.Back, Enum.EasingDirection.In)
				task.delay(0.15, function()
					-- upvalues: (ref) v_u_244, (copy) v_u_245
					if not v_u_244 then
						v_u_245.Visible = false
					end
				end)
			end
		end
	else
		return
	end
end
local function v_u_253() -- name: releaseAll
	-- upvalues: (ref) v_u_44, (copy) v_u_46, (ref) v_u_47, (ref) v_u_43, (copy) v_u_41
	local v250 = v_u_44
	if v250 then
		for _, v251 in v_u_46 do
			v250.press(v251, false)
		end
		local v252 = v_u_47
		if v252 then
			v252 = v_u_43.keys[v_u_41[v_u_47]]
		end
		if v252 then
			v250.press(v252, false)
		end
	end
	table.clear(v_u_46)
	v_u_47 = nil
end
local function v_u_267(_, p254, p255) -- name: playInput
	-- upvalues: (ref) v_u_44, (ref) v_u_42, (ref) v_u_43, (ref) v_u_47, (copy) v_u_41, (copy) v_u_40, (copy) v_u_20, (copy) v_u_46
	local v256 = v_u_44
	if v_u_42 ~= "play" or not v256 then
		return Enum.ContextActionResult.Sink
	end
	local v257 = p255.KeyCode
	if v257 ~= Enum.KeyCode.Thumbstick1 then
		if p254 == Enum.UserInputState.Begin then
			if v_u_40[v257] then
				v_u_20.pause()
				return Enum.ContextActionResult.Sink
			end
			local v258 = v_u_43.keys[v257]
			if v258 then
				v_u_46[v257] = v258
				v256.press(v258, true)
			end
		else
			local v259 = (p254 == Enum.UserInputState.End or p254 == Enum.UserInputState.Cancel) and v_u_46[v257]
			if v259 then
				v_u_46[v257] = nil
				v256.press(v259, false)
			end
		end
		return Enum.ContextActionResult.Sink
	end
	local v260 = p255.Position
	local v261
	if v260.Magnitude > 0.55 then
		local v262 = v260.X
		local v263 = math.abs(v262)
		local v264 = v260.Y
		if math.abs(v264) < v263 then
			v261 = v260.X > 0 and "right" or "left"
		else
			v261 = v260.Y > 0 and "up" or "down"
		end
		if v261 == "up" and v_u_43.id == "blocks" then
			v261 = nil
		end
	else
		v261 = nil
	end
	if v261 ~= v_u_47 then
		local v265 = v_u_47 and v_u_43.keys[v_u_41[v_u_47]]
		if v265 then
			v256.press(v265, false)
		end
		v_u_47 = v261
		local v266 = v261 and v_u_43.keys[v_u_41[v261]]
		if v266 then
			v256.press(v266, true)
		end
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_271(_, p268, p269) -- name: menuInput
	-- upvalues: (ref) v_u_42, (copy) v_u_20, (ref) v_u_50, (ref) v_u_43
	if p268 ~= Enum.UserInputState.Begin then
		return Enum.ContextActionResult.Sink
	end
	local v270 = p269.KeyCode
	if v270 == Enum.KeyCode.ButtonB or v270 == Enum.KeyCode.Backspace then
		if v_u_42 == "panel" then
			v_u_20.close()
		elseif v_u_42 == "paused" then
			v_u_20.finish()
		elseif v_u_42 == "results" then
			v_u_20.openPanel()
		end
	elseif v270 == Enum.KeyCode.Return or v270 == Enum.KeyCode.Space then
		if v_u_42 == "paused" then
			v_u_20.resume()
		elseif v_u_42 == "results" and (v270 == Enum.KeyCode.Return and os.clock() > v_u_50 + 0.8) then
			v_u_20.play(v_u_43)
		end
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_282(p272, p273) -- name: onTouch
	-- upvalues: (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (copy) v_u_48
	if v_u_42 == "play" and (v_u_43.id == "snake" and v_u_44) then
		local v274 = Vector2.new(p272.Position.X, p272.Position.Y)
		if p273 == "start" then
			v_u_48[p272] = v274
		elseif p273 == "move" then
			local v275 = v_u_48[p272]
			if v275 then
				local v276 = v274 - v275
				if v276.Magnitude >= 26 then
					local v277 = v276.X
					local v278 = math.abs(v277)
					local v279 = v276.Y
					local v280
					if math.abs(v279) < v278 then
						v280 = v276.X > 0 and "right" or "left"
					else
						v280 = v276.Y > 0 and "down" or "up"
					end
					local v281 = v_u_44
					if v281 then
						v281.press(v280, true)
						v281.press(v280, false)
					end
					v_u_48[p272] = v274
					return
				end
			end
		else
			v_u_48[p272] = nil
		end
	else
		v_u_48[p272] = nil
		return
	end
end
local function v_u_289() -- name: refreshPanel
	-- upvalues: (ref) v_u_51, (copy) v_u_62, (copy) v_u_22, (copy) v_u_19
	local v283 = v_u_51
	if v283 then
		local v284 = v_u_62()
		for _, v285 in v_u_22 do
			local v286 = v283.rows[v285.id]
			if not v286 then
				continue
			end
			local v287 = v284.best[v285.id] or 0
			local v288 = v286:FindFirstChild("Progress")
			if v288 then
				v288 = v288:FindFirstChild("Text")
			end
			if not (v288 and v288:IsA("TextLabel")) then
				continue
			end
			v288.Text = "BEST " .. v_u_19.commas(v287)
		end
	end
end
function v_u_20.openPanel() -- name: openPanel
	-- upvalues: (copy) v_u_184, (ref) v_u_44, (ref) v_u_45, (copy) v_u_13, (copy) v_u_289, (copy) v_u_8, (copy) v_u_14, (ref) v_u_42, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (ref) v_u_43
	local v290 = v_u_184()
	if v290 then
		if v_u_44 then
			v_u_44.destroy()
			v_u_44 = nil
		end
		v_u_45 = nil
		if v_u_13.current() then
			v_u_13.close()
		end
		v290.screen.Enabled = true
		v290.window.Visible = false
		v290.results.Visible = false
		v290.backdrop.BackgroundTransparency = 0.45
		v290.message.Text = ""
		v_u_289()
		local v291 = v_u_8.scaleNamed(v290.panel, "Open")
		v291.Scale = 0.72
		v290.panel.Visible = true
		v_u_8.tween(v291, 0.3, {
			["Scale"] = 1
		}, Enum.EasingStyle.Back)
		v_u_14.play("Open")
		v_u_42 = "panel"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		if v_u_42 ~= "closed" then
			local v292 = v_u_39
			v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v292))
		end
		local v293 = v290.rows[v_u_43.id]
		local v294 = v_u_12.select
		if v293 then
			v293 = v293:FindFirstChild("Button")
		end
		v294(v293)
	end
end
function v_u_20.close() -- name: close
	-- upvalues: (ref) v_u_51, (ref) v_u_44, (ref) v_u_45, (ref) v_u_42, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_2, (copy) v_u_14, (copy) v_u_8
	local v_u_295 = v_u_51
	if v_u_44 then
		v_u_44.destroy()
		v_u_44 = nil
	end
	v_u_45 = nil
	v_u_42 = "closed"
	if v_u_21:GetAttribute("ArcadeOpen") ~= false then
		v_u_21:SetAttribute("ArcadeOpen", false)
	end
	v_u_12.capture("arcade", false)
	v_u_249()
	v_u_1:UnbindAction("ArcadePlay")
	v_u_1:UnbindAction("ArcadeMenu")
	v_u_253()
	if v_u_42 ~= "closed" then
		local v296 = v_u_39
		v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v296))
	end
	v_u_2.SelectedObject = nil
	if v_u_295 then
		v_u_14.play("Close")
		local v_u_297 = v_u_8.scaleNamed(v_u_295.panel, "Open")
		v_u_8.tween(v_u_297, 0.1, {
			["Scale"] = 0.8
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		task.delay(0.1, function()
			-- upvalues: (ref) v_u_42, (copy) v_u_295, (copy) v_u_297
			if v_u_42 == "closed" then
				v_u_295.screen.Enabled = false
				v_u_295.panel.Visible = false
				v_u_295.results.Visible = false
				v_u_295.window.Visible = false
				v_u_297.Scale = 1
			end
		end)
	end
end
local function v_u_301(p298) -- name: clearColumns
	for _, v299 in { p298.left, p298.right, p298.area } do
		for _, v300 in v299:GetChildren() do
			v300:Destroy()
		end
	end
end
local function v_u_309(p302, p303, p304) -- name: countIn
	-- upvalues: (ref) v_u_45, (ref) v_u_42, (copy) v_u_8, (copy) v_u_14, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_2, (copy) v_u_267, (copy) v_u_37, (copy) v_u_38
	p302.cover.Visible = false
	for _, v305 in p304 do
		if v_u_45 ~= p303 or v_u_42 ~= "countdown" then
			return
		end
		p302.countdown.Text = v305
		local v306 = p302.countdown
		local v307
		if v305 == "GO!" then
			v307 = v_u_8.GREEN
		else
			v307 = v_u_8.GOLD
		end
		v306.TextColor3 = v307
		v_u_8.bump(p302.countdown, 0.6)
		v_u_14.play(v305 == "GO!" and "StageStart" or "RouletteTick", {
			["volume"] = 2
		})
		task.wait(v305 == "GO!" and 0.35 or 0.55)
	end
	if v_u_45 == p303 and v_u_42 == "countdown" then
		p302.countdown.Text = ""
		v_u_42 = "play"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		v_u_2.SelectedObject = nil
		local v308 = v_u_38
		v_u_1:BindActionAtPriority("ArcadePlay", v_u_267, false, v_u_37, table.unpack(v308))
	end
end
local v_u_310 = 0
local v_u_311 = -1
function v_u_20.play(p_u_312) -- name: play
	-- upvalues: (copy) v_u_184, (ref) v_u_42, (ref) v_u_43, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_5, (copy) v_u_20, (copy) v_u_8, (copy) v_u_14, (ref) v_u_45, (ref) v_u_44, (copy) v_u_301, (copy) v_u_214, (ref) v_u_310, (ref) v_u_311, (copy) v_u_19, (copy) v_u_62, (copy) v_u_94, (copy) v_u_11, (copy) v_u_2, (copy) v_u_309
	local v313 = v_u_184()
	if v313 and (v_u_42 ~= "starting" and (v_u_42 ~= "countdown" and (v_u_42 ~= "play" and v_u_42 ~= "checking"))) then
		v_u_43 = p_u_312
		v_u_42 = "starting"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		if v_u_42 ~= "closed" then
			local v314 = v_u_39
			v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v314))
		end
		v313.message.Text = ""
		local function v315()
			-- upvalues: (ref) v_u_5, (copy) p_u_312
			return v_u_5:WaitForChild("Remotes"):WaitForChild("ArcadeStart"):InvokeServer(p_u_312.id)
		end
		local v316, v317, v318, v319 = pcall(v315)
		if v316 and (v317 == true and (type(v318) == "string" and type(v319) == "number")) then
			v_u_45 = v318
			if v_u_44 then
				v_u_44.destroy()
				v_u_44 = nil
			end
			v313.panel.Visible = false
			v313.results.Visible = false
			v313.screen.Enabled = true
			v313.backdrop.BackgroundTransparency = 0.45
			v_u_301(v313)
			v_u_214()
			for _, v320 in v313.windowTitle do
				v320.Text = p_u_312.title
			end
			v_u_310 = 0
			v_u_311 = -1
			v313.score.Text = "0"
			v313.best.Text = "BEST " .. v_u_19.commas(v_u_62().best[p_u_312.id] or 0)
			v313.cover.Visible = false
			v313.pause.Visible = false
			v313.checking.Text = ""
			v_u_94()
			local v321 = p_u_312.make(v319, v313.area, v313.left, v313.right, v_u_11.touch(), function()
				-- upvalues: (ref) v_u_42
				return v_u_42 == "play"
			end)
			v_u_44 = v321
			v313.time.Text = v_u_8.clock(v321.left())
			v313.timerFill.Size = UDim2.fromScale(1, 1)
			local v322 = v_u_8.scaleNamed(v313.window, "Open")
			v322.Scale = 0.8
			v313.window.Visible = true
			v_u_8.tween(v322, 0.3, {
				["Scale"] = 1
			}, Enum.EasingStyle.Back)
			v_u_14.play("Open")
			v_u_42 = "countdown"
			if v_u_21:GetAttribute("ArcadeOpen") ~= true then
				v_u_21:SetAttribute("ArcadeOpen", true)
			end
			v_u_12.capture("arcade", true)
			v_u_249()
			v_u_1:UnbindAction("ArcadePlay")
			v_u_1:UnbindAction("ArcadeMenu")
			v_u_253()
			if v_u_42 ~= "closed" then
				local v323 = v_u_39
				v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v323))
			end
			v_u_2.SelectedObject = nil
			task.spawn(v_u_309, v313, v318, {
				"3",
				"2",
				"1",
				"GO!"
			})
		else
			local v324 = (not v316 or type(v318) ~= "string") and "Try again in a moment!" or v318
			v_u_20.openPanel()
			v313.message.Text = v324
			v_u_8.bump(v313.message, 0.3)
			v_u_14.play("Error")
		end
	else
		return
	end
end
function v_u_20.pause() -- name: pause
	-- upvalues: (ref) v_u_51, (ref) v_u_42, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_14
	local v325 = v_u_51
	if v_u_42 == "play" and v325 then
		v_u_42 = "paused"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		if v_u_42 ~= "closed" then
			local v326 = v_u_39
			v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v326))
		end
		v325.cover.Visible = true
		v325.pause.Visible = true
		v325.checking.Text = ""
		v_u_14.play("Close")
		v_u_12.select(v325.resume)
	end
end
function v_u_20.resume() -- name: resume
	-- upvalues: (ref) v_u_51, (ref) v_u_42, (ref) v_u_45, (copy) v_u_2, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_309
	local v327 = v_u_51
	if v_u_42 == "paused" and (v327 and v_u_45) then
		v327.cover.Visible = false
		v327.pause.Visible = false
		v_u_2.SelectedObject = nil
		v_u_42 = "countdown"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		if v_u_42 ~= "closed" then
			local v328 = v_u_39
			v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v328))
		end
		task.spawn(v_u_309, v327, v_u_45, { "READY", "GO!" })
	end
end
local function v_u_354(p_u_329, p330, p_u_331, p332, p333) -- name: showResults
	-- upvalues: (ref) v_u_42, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_8, (ref) v_u_43, (copy) v_u_62, (copy) v_u_19, (copy) v_u_14, (ref) v_u_50
	v_u_42 = "results"
	if v_u_21:GetAttribute("ArcadeOpen") ~= true then
		v_u_21:SetAttribute("ArcadeOpen", true)
	end
	v_u_12.capture("arcade", true)
	v_u_249()
	v_u_1:UnbindAction("ArcadePlay")
	v_u_1:UnbindAction("ArcadeMenu")
	v_u_253()
	if v_u_42 ~= "closed" then
		local v334 = v_u_39
		v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v334))
	end
	local v_u_335 = v_u_8.scaleNamed(p_u_329.window, "Open")
	v_u_8.tween(v_u_335, 0.18, {
		["Scale"] = 0
	}, Enum.EasingStyle.Back, Enum.EasingDirection.In)
	task.delay(0.18, function()
		-- upvalues: (ref) v_u_42, (copy) p_u_329, (copy) v_u_335
		if v_u_42 == "results" then
			p_u_329.window.Visible = false
			v_u_335.Scale = 1
		end
	end)
	p_u_329.backdrop.BackgroundTransparency = 0.72
	for _, v336 in p_u_329.resultTitle do
		v336.Text = v_u_43.ends[p333] or "ROUND OVER"
	end
	local v_u_337
	if p_u_331 then
		local v338 = p_u_331.score
		v_u_337 = type(v338) ~= "number" and 0 or v338
	else
		v_u_337 = p330.score()
	end
	local v339
	if p_u_331 then
		local v340 = p_u_331.best
		v339 = type(v340) ~= "number" and 0 or v340
	else
		v339 = v_u_62().best[v_u_43.id] or 0
	end
	local v_u_341
	if p_u_331 == nil then
		v_u_341 = false
	else
		v_u_341 = p_u_331.newBest == true
	end
	p_u_329.resultScore.Text = "0"
	p_u_329.resultBest.Text = v_u_341 and "NEW BEST!" or "BEST " .. v_u_19.commas(v339)
	local v342 = p_u_329.resultBest
	local v343
	if v_u_341 then
		v343 = v_u_8.GOLD
	else
		v343 = Color3.fromRGB(200, 210, 230)
	end
	v342.TextColor3 = v343
	local v344 = p_u_329.resultCount
	local v345
	if p_u_331 then
		local v346 = v_u_19.commas
		local v347 = p_u_331.count
		v345 = v346(type(v347) ~= "number" and 0 or v347) .. " " .. v_u_43.counts
	else
		v345 = ""
	end
	v344.Text = v345
	p_u_329.resultNote.Text = p332 or "Your training kept going while you played!"
	local v348 = v_u_8.scaleNamed(p_u_329.results, "Open")
	v348.Scale = 0.6
	p_u_329.results.Visible = true
	v_u_8.tween(v348, 0.35, {
		["Scale"] = 1
	}, Enum.EasingStyle.Back)
	v_u_14.play(v_u_341 and "WaveClear" or "RewardLand")
	v_u_50 = os.clock()
	v_u_12.clear()
	task.delay(0.8, function()
		-- upvalues: (ref) v_u_42, (ref) v_u_12, (copy) p_u_329
		if v_u_42 == "results" then
			v_u_12.select(p_u_329.again)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_42, (copy) p_u_329, (ref) v_u_19, (copy) v_u_337, (ref) v_u_8, (copy) v_u_341, (ref) v_u_14, (copy) p_u_331
		local v349 = os.clock()
		while os.clock() - v349 < 0.7 and v_u_42 == "results" do
			local v350 = (os.clock() - v349) / 0.7
			local v351 = p_u_329.resultScore
			local v352 = v_u_19.commas
			local v353 = v_u_337 * v350
			v351.Text = v352((math.floor(v353)))
			task.wait()
		end
		p_u_329.resultScore.Text = v_u_19.commas(v_u_337)
		v_u_8.bump(p_u_329.resultScore, 0.35)
		if v_u_341 then
			v_u_8.bump(p_u_329.resultBest, 0.6)
			v_u_14.play("LevelUp", {
				["volume"] = 0.8
			})
		end
		if p_u_331 and v_u_42 == "results" then
			v_u_8.bump(p_u_329.resultCount, 0.3)
		end
	end)
end
function v_u_20.finish() -- name: finish
	-- upvalues: (ref) v_u_51, (ref) v_u_44, (ref) v_u_45, (ref) v_u_42, (copy) v_u_21, (copy) v_u_12, (copy) v_u_249, (copy) v_u_1, (copy) v_u_253, (copy) v_u_271, (copy) v_u_37, (copy) v_u_39, (copy) v_u_18, (copy) v_u_5, (copy) v_u_354
	local v_u_355 = v_u_51
	local v_u_356 = v_u_44
	local v_u_357 = v_u_45
	if v_u_355 and (v_u_356 and (v_u_357 and (v_u_42 == "play" or v_u_42 == "paused"))) then
		v_u_42 = "checking"
		if v_u_21:GetAttribute("ArcadeOpen") ~= true then
			v_u_21:SetAttribute("ArcadeOpen", true)
		end
		v_u_12.capture("arcade", true)
		v_u_249()
		v_u_1:UnbindAction("ArcadePlay")
		v_u_1:UnbindAction("ArcadeMenu")
		v_u_253()
		if v_u_42 ~= "closed" then
			local v358 = v_u_39
			v_u_1:BindActionAtPriority("ArcadeMenu", v_u_271, false, v_u_37, table.unpack(v358))
		end
		v_u_45 = nil
		v_u_355.pause.Visible = false
		local v_u_359 = v_u_18.encode(v_u_356.inputs)
		local v_u_360 = v_u_356.tick()
		local v_u_361 = v_u_356.score()
		local v_u_362 = v_u_356.reason()
		local v_u_363 = v_u_356.over()
		task.spawn(function()
			-- upvalues: (copy) v_u_363, (ref) v_u_44, (copy) v_u_356, (copy) v_u_355, (ref) v_u_5, (copy) v_u_357, (copy) v_u_359, (copy) v_u_360, (copy) v_u_361, (ref) v_u_42, (ref) v_u_354, (copy) v_u_362
			task.wait(v_u_363 and 0.9 or 0.2)
			if v_u_44 == v_u_356 then
				v_u_355.cover.Visible = true
				v_u_355.checking.Text = "CHECKING SCORE..."
				local function v364()
					-- upvalues: (ref) v_u_5, (ref) v_u_357, (ref) v_u_359, (ref) v_u_360, (ref) v_u_361
					return v_u_5:WaitForChild("Remotes"):WaitForChild("ArcadeFinish"):InvokeServer(v_u_357, v_u_359, v_u_360, v_u_361)
				end
				local v365, v366, v367 = pcall(v364)
				if v_u_44 == v_u_356 and v_u_42 == "checking" then
					v_u_355.checking.Text = ""
					v_u_355.cover.Visible = false
					local v368
					if v365 and (v366 == true and type(v367) == "table") then
						v368 = v367
					else
						v368 = nil
					end
					if not v365 or (v366 ~= false or type(v367) ~= "string") then
						v367 = not v368 and "Could not reach the server" or nil
					end
					v_u_354(v_u_355, v_u_356, v368, v367, v_u_362)
				end
			else
				return
			end
		end)
	end
end
local function v_u_381(p369) -- name: frame
	-- upvalues: (ref) v_u_51, (ref) v_u_44, (ref) v_u_42, (ref) v_u_49, (ref) v_u_310, (copy) v_u_19, (copy) v_u_8, (ref) v_u_43, (copy) v_u_17, (ref) v_u_311, (copy) v_u_14, (copy) v_u_20
	local v370 = v_u_51
	local v371 = v_u_44
	if v370 and (v371 and v370.window.Visible) then
		if v_u_42 == "play" then
			v371.update(p369)
			if v_u_49 then
				v371.auto()
			end
		elseif v_u_42 == "countdown" then
			v371.update(0)
		end
		local v372 = v371.score()
		if v372 ~= v_u_310 then
			v_u_310 = v372
			v370.score.Text = v_u_19.commas(v372)
			v_u_8.bump(v370.score, 0.3)
		end
		local v373 = v371.left()
		v370.time.Text = v_u_8.clock(v373)
		local v374
		if v_u_43.id == "snake" then
			v374 = v_u_17.snake.roundSeconds
		else
			v374 = v_u_17.blocks.roundSeconds
		end
		local v375 = v370.timerFill
		local v376 = UDim2.fromScale
		local v377 = v373 / v374
		v375.Size = v376(math.clamp(v377, 0, 1), 1)
		local v378 = v370.timerFill
		local v379
		if v373 <= 10 then
			v379 = v_u_8.RED
		else
			v379 = v_u_8.CYAN
		end
		v378.BackgroundColor3 = v379
		local v380 = math.ceil(v373)
		if v_u_42 == "play" and v380 ~= v_u_311 then
			v_u_311 = v380
			if v380 <= 5 and v380 > 0 then
				v_u_14.play("RouletteTick", {
					["volume"] = 2.5,
					["pitch"] = 0.8
				})
				v_u_8.bump(v370.time, 0.4)
			end
		end
		if v_u_42 == "play" and v371.over() then
			v_u_20.finish()
		end
	end
end
function v_u_20.start() -- name: start
	-- upvalues: (copy) v_u_243, (copy) v_u_184, (copy) v_u_214, (copy) v_u_2, (copy) v_u_249, (copy) v_u_6, (copy) v_u_381, (copy) v_u_21, (ref) v_u_42, (copy) v_u_289, (copy) v_u_20, (copy) v_u_7, (ref) v_u_43, (ref) v_u_44, (copy) v_u_48, (copy) v_u_282, (copy) v_u_12, (copy) v_u_94, (ref) v_u_51, (copy) v_u_22, (ref) v_u_49
	task.spawn(function()
		-- upvalues: (ref) v_u_243, (ref) v_u_184, (ref) v_u_214, (ref) v_u_2, (ref) v_u_249
		v_u_243()
		local v382 = v_u_184()
		if v382 then
			v382.screen:GetPropertyChangedSignal("AbsoluteSize"):Connect(v_u_214)
			v_u_2:GetPropertyChangedSignal("TopbarInset"):Connect(v_u_214)
			v_u_214()
		end
		v_u_249()
	end)
	v_u_6.RenderStepped:Connect(v_u_381)
	for _, v383 in {
		"TrainSpot",
		"TrainMult",
		"TutorialDone",
		"InWave"
	} do
		v_u_21:GetAttributeChangedSignal(v383):Connect(v_u_249)
	end
	task.spawn(function()
		-- upvalues: (ref) v_u_249, (ref) v_u_42, (ref) v_u_289
		while true do
			repeat
				task.wait(0.4)
				v_u_249()
			until v_u_42 == "panel"
			v_u_289()
		end
	end)
	v_u_21:GetAttributeChangedSignal("Arcade"):Connect(function()
		-- upvalues: (ref) v_u_42, (ref) v_u_289
		if v_u_42 == "panel" then
			v_u_289()
		end
	end)
	v_u_2.MenuOpened:Connect(function()
		-- upvalues: (ref) v_u_20
		v_u_20.pause()
	end)
	v_u_7.WindowFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_20
		v_u_20.pause()
	end)
	v_u_7.TouchStarted:Connect(function(p384)
		-- upvalues: (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_48
		if v_u_42 == "play" and (v_u_43.id == "snake" and v_u_44) then
			v_u_48[p384] = Vector2.new(p384.Position.X, p384.Position.Y)
		else
			v_u_48[p384] = nil
		end
	end)
	v_u_7.TouchMoved:Connect(function(p385)
		-- upvalues: (ref) v_u_282
		v_u_282(p385, "move")
	end)
	v_u_7.TouchEnded:Connect(function(p386)
		-- upvalues: (ref) v_u_42, (ref) v_u_43, (ref) v_u_44, (ref) v_u_48
		if v_u_42 == "play" and (v_u_43.id == "snake" and v_u_44) then
			Vector2.new(p386.Position.X, p386.Position.Y)
			v_u_48[p386] = nil
		else
			v_u_48[p386] = nil
		end
	end)
	v_u_12.changed:Connect(function()
		-- upvalues: (ref) v_u_42, (ref) v_u_94
		if v_u_42 ~= "closed" then
			v_u_94()
		end
	end)
	v_u_12.onEnter(function(_)
		-- upvalues: (ref) v_u_51, (ref) v_u_42, (ref) v_u_12
		local v387 = v_u_51
		if not v387 or v_u_42 == "closed" then
			return false
		end
		local v388
		if v_u_42 == "panel" then
			v388 = v387.panel
		elseif v_u_42 == "paused" then
			v388 = v387.pause
		elseif v_u_42 == "results" then
			v388 = v387.results
		else
			v388 = nil
		end
		if v388 then
			v_u_12.select(v_u_12.first(v388))
		end
		return true
	end, 100)
	if v_u_6:IsStudio() then
		v_u_21:GetAttributeChangedSignal("DevArcade"):Connect(function()
			-- upvalues: (ref) v_u_21, (ref) v_u_20, (ref) v_u_22, (ref) v_u_49
			local v389 = v_u_21:GetAttribute("DevArcade")
			if v389 == nil then
				return
			else
				v_u_21:SetAttribute("DevArcade", nil)
				if v389 == "open" then
					v_u_20.openPanel()
					return
				elseif v389 == "snake" then
					v_u_20.play(v_u_22[1])
					return
				elseif v389 == "blocks" then
					v_u_20.play(v_u_22[2])
					return
				elseif v389 == "bot" then
					v_u_49 = true
					return
				elseif v389 == "nobot" then
					v_u_49 = false
					return
				elseif v389 == "pause" then
					v_u_20.pause()
					return
				elseif v389 == "end" then
					v_u_20.finish()
				elseif v389 == "close" then
					v_u_20.close()
				end
			end
		end)
	end
end
return v_u_20