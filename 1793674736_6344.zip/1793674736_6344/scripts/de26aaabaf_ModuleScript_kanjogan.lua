local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("9A7BFF")
local v_u_8 = Color3.fromRGB(210, 196, 255)
local v_u_9 = Color3.fromRGB(104, 58, 226)
local v_u_10 = Color3.fromHex("1A1030")
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Color3.new(v_u_8.R * 2.3, v_u_8.G * 2.3, v_u_8.B * 2.3)
local v_u_13 = Color3.new(v_u_7.R * 1.9, v_u_7.G * 1.9, v_u_7.B * 1.9)
local v_u_14 = Enum.PartType.Ball
local v_u_15 = Enum.Material.ForceField
local function v_u_35(p16, p17, p18, p19, p20) -- name: picture
	-- upvalues: (copy) v_u_4
	local v21 = Color3.new
	local v22 = p19.R
	local v23 = math.min(v22, 1)
	local v24 = p19.G
	local v25 = math.min(v24, 1)
	local v26 = p19.B
	local v27 = v21(v23, v25, (math.min(v26, 1)))
	local v28 = math.max(p17, 0.03)
	local v29 = v_u_4.part
	local v30 = v28 * 2
	local v31 = v28 * 2
	local v32 = v29(Vector3.new(v30, 0.05, v31), p16, v27, {
		["transparency"] = 1
	})
	for _, v33 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v34 = Instance.new("Decal")
		v34.Face = v33
		v34.Texture = p18
		v34.Color3 = p19
		v34.Transparency = p20
		v34.Parent = v32
	end
	return v32
end
local function v_u_39(p36, p37) -- name: setAlpha
	for _, v38 in p36:GetChildren() do
		if not v38:IsA("Decal") then
			continue
		end
		v38.Transparency = p37
	end
end
return function(p_u_40)
	-- upvalues: (copy) v_u_3, (copy) v_u_35, (copy) v_u_1, (copy) v_u_39, (copy) v_u_4, (copy) v_u_8, (copy) v_u_14, (copy) v_u_7, (copy) v_u_11, (copy) v_u_6, (copy) v_u_13, (copy) v_u_12, (copy) v_u_9, (copy) v_u_15, (copy) v_u_5, (copy) v_u_10
	local v41 = {}
	local function v_u_69(p_u_42, p_u_43, p_u_44, p45, p46, p_u_47, p_u_48, p49) -- name: flare
		-- upvalues: (ref) v_u_35, (ref) v_u_3, (copy) p_u_40, (ref) v_u_1, (ref) v_u_39
		local v_u_50 = p49 or 0
		local v_u_51 = math.random() * 3.141592653589793 * 2
		local v52 = v_u_35
		local v53 = v_u_3.CurrentCamera
		local v54
		if v53 then
			local v55 = v53.CFrame.Position - p_u_42
			v54 = v55.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v55.Unit
		else
			v54 = Vector3.new(0, 0, 1)
		end
		local v_u_56 = v52(p_u_40.facing(p_u_42 + v54 * 0.3, v54) * CFrame.Angles(0, v_u_51, 0), p_u_43, p45, p46, v_u_50)
		v_u_1:AddItem(v_u_56, p_u_47 + 0.1)
		p_u_40.animate(p_u_47, 0, function(p57)
			-- upvalues: (copy) v_u_56, (copy) p_u_43, (copy) p_u_44, (copy) p_u_42, (copy) v_u_51, (copy) p_u_47, (copy) p_u_48, (ref) v_u_3, (ref) p_u_40, (ref) v_u_39, (copy) v_u_50
			local v58 = v_u_56
			local v59 = p_u_43 + (p_u_44 - p_u_43) * (1 - (1 - p57) ^ 3)
			local v60 = math.max(v59, 0.03)
			local v61 = v60 * 2
			local v62 = v60 * 2
			v58.Size = Vector3.new(v61, 0.05, v62)
			local v63 = v_u_56
			local v64 = p_u_42
			local v65 = v_u_51 + p57 * p_u_47 * p_u_48
			local v66 = v_u_3.CurrentCamera
			local v67
			if v66 then
				local v68 = v66.CFrame.Position - v64
				v67 = v68.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v68.Unit
			else
				v67 = Vector3.new(0, 0, 1)
			end
			v63.CFrame = p_u_40.facing(v64 + v67 * 0.3, v67) * CFrame.Angles(0, v65, 0)
			v_u_39(v_u_56, v_u_50 + (1 - v_u_50) * p57 ^ 1.5)
			if p57 >= 1 then
				v_u_56:Destroy()
			end
		end)
	end
	local function v_u_86(p70, p71, p72, p73, p74) -- name: scatter
		-- upvalues: (copy) p_u_40, (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_14, (ref) v_u_1
		local v75 = p_u_40.facing
		local v76 = v_u_3.CurrentCamera
		local v77
		if v76 then
			local v78 = v76.CFrame.Position - p70
			v77 = v78.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v78.Unit
		else
			v77 = Vector3.new(0, 0, 1)
		end
		local v79 = v75(p70, v77)
		local v80 = math.random() * 3.141592653589793 * 2
		for v81 = 1, p71 do
			local v82 = v80 + (v81 - 1) / p71 * 3.141592653589793 * 2
			local v83 = v79.RightVector * math.cos(v82) + v79.LookVector * math.sin(v82)
			local v84 = {
				["shape"] = v_u_14
			}
			local v85 = v_u_4.part(Vector3.new(1, 1, 1) * p73, CFrame.new(p70), v_u_8, v84)
			v_u_4.tween(v85, p74, {
				["CFrame"] = nil,
				["Size"] = nil,
				["Transparency"] = 1,
				["CFrame"] = CFrame.new(p70 + v83 * p72),
				["Size"] = Vector3.new(1, 1, 1) * p73 * 0.25
			}, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
			v_u_1:AddItem(v85, p74 + 0.05)
		end
	end
	v41.kanjogan_a = {
		["cast"] = function(p87) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (copy) p_u_40, (ref) v_u_11, (copy) v_u_69, (ref) v_u_6, (ref) v_u_12
			local v88 = p87.size
			local v89 = p87.eye + p87.dir * 1.2
			v_u_4.flash(v89, v_u_7, 2.8 * v88, 0.12)
			p_u_40.pop(v89, v_u_11, 1.1 * v88, 0.3 * v88, 0.1)
			if not p87.lite then
				v_u_69(v89, 1.9 * v88, 0.4 * v88, v_u_6.KanjoRing, v_u_12, 0.12, -8)
			end
		end,
		["shot"] = function(p90, p91) -- name: orbShot
			-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_11, (ref) v_u_14, (ref) v_u_35, (ref) v_u_6, (ref) v_u_13, (ref) v_u_12, (ref) v_u_1, (copy) p_u_40, (ref) v_u_8, (ref) v_u_9, (ref) v_u_39
			local v_u_92 = p90.size
			local v_u_93 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p91, v_u_7, {
				["transparency"] = 1
			})
			local v94 = {
				["shape"] = v_u_14
			}
			local v_u_95 = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * v_u_92, p91, v_u_11, v94)
			local v96 = {
				["shape"] = nil,
				["transparency"] = 0.3,
				["shape"] = v_u_14
			}
			local v_u_97 = v_u_4.part(Vector3.new(1.9, 1.9, 1.9) * v_u_92, p91, v_u_7, v96)
			local v_u_98 = v_u_35(p91, 1.5 * v_u_92, v_u_6.KanjoRing, v_u_13, 0)
			local v_u_99 = { v_u_95, v_u_97, v_u_98 }
			local v_u_100
			if p90.lite then
				v_u_100 = nil
			else
				v_u_100 = v_u_35(p91, 1.2 * v_u_92, v_u_6.Ring, v_u_12, 0.4)
				table.insert(v_u_99, v_u_100)
			end
			for _, v101 in v_u_99 do
				v_u_1:AddItem(v101, 3)
			end
			v_u_1:AddItem(v_u_93, 3)
			p_u_40.streak(v_u_93, v_u_8, v_u_9, 1.1 * v_u_92, p90.lite and 0.12 or 0.2)
			if p90.mine then
				p_u_40.light(v_u_93, v_u_7, 9 * v_u_92)
			end
			local v_u_102 = false
			return {
				["place"] = function(p103, p104) -- name: place
					-- upvalues: (copy) v_u_93, (copy) v_u_95, (copy) v_u_97, (copy) v_u_98, (copy) v_u_92, (ref) p_u_40, (ref) v_u_100, (ref) v_u_39
					local v105 = p103.Position
					v_u_93.CFrame = p103
					v_u_95.CFrame = p103
					v_u_97.CFrame = p103
					local v106 = v_u_98
					local v107 = 1.5 * v_u_92
					local v108 = p104 * 40
					local v109 = v107 * (math.sin(v108) * 0.1 + 1)
					local v110 = math.max(v109, 0.03)
					local v111 = v110 * 2
					local v112 = v110 * 2
					v106.Size = Vector3.new(v111, 0.05, v112)
					v_u_98.CFrame = p_u_40.facing(v105, p103.LookVector) * CFrame.Angles(0, p104 * 9, 0)
					local v113 = v_u_100
					if v113 then
						local v114 = p104 * 5 % 1
						local v115 = (v114 * 1.7 + 0.9) * v_u_92
						local v116 = math.max(v115, 0.03)
						local v117 = v116 * 2
						local v118 = v116 * 2
						v113.Size = Vector3.new(v117, 0.05, v118)
						v_u_39(v113, v114 * 0.75 + 0.25)
						v113.CFrame = p_u_40.facing(v105 + p103.LookVector * (v114 * 2.2 + 0.5) * v_u_92, p103.LookVector)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_102, (copy) v_u_93, (ref) v_u_1, (copy) v_u_99
					if not v_u_102 then
						v_u_102 = true
						local v119 = v_u_93:FindFirstChildWhichIsA("PointLight")
						if v119 then
							v119:Destroy()
						end
						v_u_1:AddItem(v_u_93, 0.3)
						for _, v120 in v_u_99 do
							v120:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p121, p122) -- name: orbImpact
			-- upvalues: (copy) v_u_69, (ref) v_u_6, (ref) v_u_12, (copy) v_u_86, (copy) p_u_40, (ref) v_u_7, (ref) v_u_11, (ref) v_u_4
			local v123 = p121.size
			v_u_69(p122, 1.4 * v123, 4.6 * v123, v_u_6.KanjoRing, v_u_12, 0.24, 7)
			v_u_86(p122, p121.lite and 4 or 8, 4 * v123, 0.55 * v123, 0.24)
			p_u_40.pop(p122, v_u_7, 1.2 * v123, 4.6 * v123, 0.2, 0.4)
			p_u_40.pop(p122, v_u_11, 0.9 * v123, 2.2 * v123, 0.12)
			v_u_4.ring(p_u_40.ground(p122), v_u_7, p121.ability.radius * 0.9, 0.3, v_u_6.Ring)
			p_u_40.burst("Impact", p122, v_u_7, 0.8 * v123)
			p_u_40.hitSound(p122)
		end,
		["hit"] = p_u_40.simpleHit(v_u_7, 0.6)
	}
	v41.kanjogan_e = {
		["cast"] = function(p124) -- name: cast
			-- upvalues: (copy) p_u_40, (ref) v_u_7, (copy) v_u_69, (ref) v_u_6, (ref) v_u_12
			p_u_40.skillCast(p124, v_u_7)
			if not p124.lite then
				local v125 = p124.size
				v_u_69(p124.eye + p124.dir * 1.2, 0.5 * v125, 3 * v125, v_u_6.KanjoRing, v_u_12, 0.22, 6)
			end
		end,
		["windup"] = function(p126, p127, p128) -- name: windup
			-- upvalues: (copy) p_u_40, (ref) v_u_35, (ref) v_u_6, (ref) v_u_13, (ref) v_u_7, (ref) v_u_1, (ref) v_u_39, (ref) v_u_8
			local v_u_129 = p126.ability.radius
			local v_u_130 = p_u_40.ground(p127, 0)
			local v_u_131 = math.max(p128, 0.1)
			local v_u_132 = v_u_131 + 0.45
			local v133 = p126.dir.Z
			local v134 = p126.dir.X
			local v_u_135 = math.atan2(v133, v134)
			local v_u_136 = v_u_35(CFrame.new(v_u_130 + Vector3.new(0, 0.35, 0)), v_u_129, v_u_6.KanjoSweep, v_u_13, 0.1)
			local v_u_137 = v_u_35(CFrame.new(v_u_130 + Vector3.new(0, 0.3, 0)), v_u_129 * 0.5, v_u_6.Ring, v_u_7, 0.4)
			v_u_1:AddItem(v_u_136, v_u_132 + 0.1)
			v_u_1:AddItem(v_u_137, v_u_132 + 0.1)
			p_u_40.animate(v_u_132, 0, function(p138)
				-- upvalues: (copy) v_u_132, (copy) v_u_136, (copy) v_u_130, (copy) v_u_135, (copy) v_u_131, (ref) v_u_39, (copy) v_u_137, (copy) v_u_129
				local v139 = p138 * v_u_132
				v_u_136.CFrame = CFrame.new(v_u_130 + Vector3.new(0, 0.35, 0)) * CFrame.Angles(0, -v_u_135 + -1 * v139 / v_u_131 * 3.141592653589793 * 2, 0)
				local v140 = (v139 - v_u_131) / 0.45
				local v141 = math.clamp(v140, 0, 1)
				v_u_39(v_u_136, v141 * 0.9 + 0.1)
				v_u_39(v_u_137, v141 * 0.6 + 0.4)
				local v142 = v_u_137
				local v143 = v_u_129
				local v144 = v139 / v_u_131
				local v145 = v143 * (math.min(v144, 1) * 0.55 + 0.45)
				local v146 = math.max(v145, 0.03)
				local v147 = v146 * 2
				local v148 = v146 * 2
				v142.Size = Vector3.new(v147, 0.05, v148)
				if p138 >= 1 then
					v_u_136:Destroy()
					v_u_137:Destroy()
				end
			end)
			if not p126.lite then
				for v149 = 1, 8 do
					local v150 = p_u_40.pop
					local v151 = v_u_135 + (v149 - 1) / 8 * 3.141592653589793 * 2
					local v152 = math.cos(v151)
					local v153 = math.sin(v151)
					v150(v_u_130 + Vector3.new(v152, 0, v153) * v_u_129 + Vector3.new(0, 1.2, 0), v_u_8, 0.4, 1.8, v_u_131 + 0.15, 0.1)
				end
			end
		end,
		["land"] = function(p154, p155) -- name: land
			-- upvalues: (copy) p_u_40, (ref) v_u_7, (ref) v_u_15, (ref) v_u_8, (ref) v_u_4, (ref) v_u_11, (ref) v_u_6, (ref) v_u_5
			local v_u_156 = p154.ability.radius
			local v_u_157 = p_u_40.ground(p155, 0)
			local v158 = p154.dir.Z
			local v159 = p154.dir.X
			local v160 = math.atan2(v158, v159)
			p_u_40.pop(v_u_157 + Vector3.new(0, 1, 0), v_u_7, 3, v_u_156 * 2.1, 0.45, 0.25, v_u_15)
			p_u_40.pop(v_u_157 + Vector3.new(0, 1, 0), v_u_8, 2, v_u_156 * 1.1, 0.24, 0.55)
			v_u_4.flash(v_u_157 + Vector3.new(0, 2, 0), v_u_11, 7, 0.18)
			for v_u_161 = 0, 2 do
				p_u_40.after(v_u_161 * 0.11, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_157, (copy) v_u_161, (ref) v_u_8, (ref) v_u_7, (copy) v_u_156, (ref) v_u_6
					local v162 = v_u_4.ring
					local v163 = v_u_157
					local v164
					if v_u_161 == 0 then
						v164 = v_u_8
					else
						v164 = v_u_7
					end
					v162(v163, v164, v_u_156 * (1.15 - v_u_161 * 0.08), 0.42, v_u_6.Ring)
				end)
			end
			local v165 = p154.lite and 4 or 8
			for v166 = 1, v165 do
				local v167 = v160 + ((v166 - 1) * (8 / v165) + 1 - 1) / 8 * 3.141592653589793 * 2
				local v168 = math.cos(v167)
				local v169 = math.sin(v167)
				local v170 = v_u_157 + Vector3.new(v168, 0, v169) * v_u_156
				p_u_40.thin(p_u_40.pillar(v170, 10, 0.8, v_u_8), 0.38)
				if p154.lite then
					continue
				end
				p_u_40.pop(v170 + Vector3.new(0, 0.6, 0), v_u_7, 1, 3.6, 0.25, 0.3)
			end
			p_u_40.burst("Shockwave", v_u_157 + Vector3.new(0, 0.3, 0), v_u_7, v_u_156 / 16)
			v_u_5.play("Crit", {
				["at"] = nil,
				["volume"] = 0.55,
				["at"] = v_u_157
			})
			if p154.mine then
				v_u_4.shake(0.3, 0.25)
			end
		end,
		["hit"] = function(p171, p_u_172, _) -- name: hit
			-- upvalues: (copy) p_u_40, (ref) v_u_7, (ref) v_u_35, (ref) v_u_3, (ref) v_u_6, (ref) v_u_12, (ref) v_u_1, (ref) v_u_39
			p_u_40.burst("Impact", p_u_172, v_u_7, 0.6)
			if not p171.lite then
				local v173 = v_u_35
				local v174 = v_u_3.CurrentCamera
				local v175
				if v174 then
					local v176 = v174.CFrame.Position - p_u_172
					v175 = v176.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v176.Unit
				else
					v175 = Vector3.new(0, 0, 1)
				end
				local v_u_177 = v173(p_u_40.facing(p_u_172 + v175 * 0.3, v175) * CFrame.Angles(0, 0, 0), 3.4, v_u_6.KanjoRing, v_u_12, 0)
				v_u_1:AddItem(v_u_177, 0.6)
				p_u_40.animate(0.5, 0, function(p178)
					-- upvalues: (copy) v_u_177, (copy) p_u_172, (ref) v_u_3, (ref) p_u_40, (ref) v_u_39
					local v179 = p178 / 0.3
					local v180 = math.min(v179, 1)
					local v181 = v_u_177
					local v182 = 3.4 - (1 - (1 - v180) ^ 3) * 2.1
					local v183 = math.max(v182, 0.03)
					local v184 = v183 * 2
					local v185 = v183 * 2
					v181.Size = Vector3.new(v184, 0.05, v185)
					local v186 = v_u_177
					local v187 = p_u_172
					local v188 = p178 * 3
					local v189 = v_u_3.CurrentCamera
					local v190
					if v189 then
						local v191 = v189.CFrame.Position - v187
						v190 = v191.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v191.Unit
					else
						v190 = Vector3.new(0, 0, 1)
					end
					v186.CFrame = p_u_40.facing(v187 + v190 * 0.3, v190) * CFrame.Angles(0, v188, 0)
					local v192 = v_u_39
					local v193 = v_u_177
					local v194 = (p178 - 0.55) / 0.45
					v192(v193, (math.clamp(v194, 0, 1)))
					if p178 >= 1 then
						v_u_177:Destroy()
					end
				end)
			end
		end
	}
	local v_u_195 = {}
	setmetatable(v_u_195, {
		["__mode"] = "k"
	})
	local function v_u_260(p196, p197, p198) -- name: openRite
		-- upvalues: (copy) p_u_40, (ref) v_u_35, (ref) v_u_11, (ref) v_u_6, (ref) v_u_13, (ref) v_u_1, (ref) v_u_4, (ref) v_u_14, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_39
		local v199 = p_u_40.ground(p197, 0)
		local v_u_200 = math.max(p198, 0.12)
		local v201 = p196.lite
		local v202 = p196.dir.Z
		local v203 = p196.dir.X
		local v204 = math.atan2(v202, v203)
		local v_u_205 = v199 + Vector3.new(0, 24, 0) + p196.dir * 7
		local v_u_206 = CFrame.new(v_u_205) * CFrame.Angles(3.141592653589793, 0, 0)
		local v_u_207 = v_u_35(v_u_206, 0.1, p_u_40.iris("kanjogan"), v_u_11, 0)
		local v_u_208 = v_u_35(CFrame.new(v_u_205 + Vector3.new(0, 0.4, 0)), 0.1, v_u_6.Glow, v_u_13, 0.1)
		local v_u_209 = v_u_35(CFrame.new(v199 + Vector3.new(0, 0.45, 0)), 20, v_u_6.Ring, v_u_13, 1)
		local v210 = v_u_200 + 2
		for _, v211 in { v_u_207, v_u_208, v_u_209 } do
			v_u_1:AddItem(v211, v210)
		end
		local v_u_212 = {}
		for v213 = 1, 8 do
			local v214 = v204 + (v213 - 1) / 8 * 3.141592653589793 * 2
			local v215 = math.cos(v214)
			local v216 = math.sin(v214)
			local v217 = v199 + Vector3.new(v215, 0, v216) * 20
			local v218 = v199 + (v217 - v199) * 0.8 + Vector3.new(0, 20, 0)
			local v219 = {
				["shape"] = v_u_14
			}
			local v220 = v_u_4.part(Vector3.new(1.5, 1.5, 1.5), CFrame.new(v_u_205), v_u_11, v219)
			v_u_1:AddItem(v220, v210)
			local v221
			if v201 then
				v221 = nil
			else
				local v222 = {
					["shape"] = nil,
					["transparency"] = 0.45,
					["shape"] = v_u_14
				}
				v221 = v_u_4.part(Vector3.new(3.6, 3.6, 3.6), CFrame.new(v_u_205), v_u_7, v222)
				v_u_1:AddItem(v221, v210)
			end
			p_u_40.streak(v220, v_u_8, v_u_9, v201 and 1.2 or 2, v201 and 0.15 or 0.3)
			table.insert(v_u_212, {
				["core"] = v220,
				["shell"] = v221,
				["apex"] = v218,
				["land"] = v217
			})
		end
		local v_u_223 = {
			["top"] = nil,
			["born"] = nil,
			["landed"] = nil,
			["top"] = v_u_205,
			["born"] = os.clock()
		}
		p_u_40.runNow(function()
			-- upvalues: (copy) v_u_223, (copy) v_u_200, (copy) v_u_207, (copy) v_u_206, (copy) v_u_208, (ref) v_u_39, (copy) v_u_209, (copy) v_u_212, (copy) v_u_205
			local v224 = os.clock()
			local v225 = v224 - v_u_223.born
			local v226 = v225 / v_u_200
			local v227 = v_u_223.landed
			local v228
			if v227 then
				local v229 = (v224 - v227 - 0.45) / 0.25
				v228 = math.clamp(v229, 0, 1)
			else
				v228 = 0
			end
			local v230 = v225 / 0.18
			local v231 = math.clamp(v230, 0, 1) - 1
			local v232 = (v231 * 2.7 * v231 * v231 + 1 + v231 * 1.7 * v231) * (1 - v228 * v228)
			local v233 = v_u_207
			local v234 = v232 * 8.5
			local v235 = math.max(v234, 0.03)
			local v236 = v235 * 2
			local v237 = v235 * 2
			v233.Size = Vector3.new(v236, 0.05, v237)
			v_u_207.CFrame = v_u_206 * CFrame.Angles(0, -v225 * 0.8, 0)
			local v238 = v_u_208
			local v239 = v232 * 18.700000000000003
			local v240 = math.max(v239, 0.03)
			local v241 = v240 * 2
			local v242 = v240 * 2
			v238.Size = Vector3.new(v241, 0.05, v242)
			local v243 = v_u_39
			local v244 = v_u_209
			local v245 = v226 * 1.5
			v243(v244, 1 - math.clamp(v245, 0, 1) * 0.75 * (1 - v228))
			local v246 = v_u_209
			local v247 = (math.clamp(v226, 0, 1) * 0.4 + 0.6) * 20
			local v248 = math.max(v247, 0.03)
			local v249 = v248 * 2
			local v250 = v248 * 2
			v246.Size = Vector3.new(v249, 0.05, v250)
			for _, v251 in v_u_212 do
				if not v251.core.Parent then
					continue
				end
				local v252
				if v226 < 0.6 then
					local v253 = v226 / 0.6
					local v254 = v_u_205:Lerp(v251.apex, 1 - (1 - v253) * (1 - v253))
					local v255 = v253 * 3.141592653589793
					v252 = v254 + Vector3.new(0, 1, 0) * math.sin(v255) * 3
				else
					local v256 = (v226 - 0.6) / 0.4
					local v257 = math.min(v256, 1)
					v252 = v251.apex:Lerp(v251.land + Vector3.new(0, 1.2, 0), v257 * v257)
				end
				v251.core.CFrame = CFrame.new(v252)
				local v258 = v251.shell
				if v258 then
					v258.CFrame = CFrame.new(v252)
					local v259 = v225 * 30
					v258.Size = Vector3.new(1, 1, 1) * (math.sin(v259) * 0.5 + 3.6)
				end
				if v226 < 1 then
					continue
				end
				v251.core:Destroy()
				if not v258 then
					continue
				end
				v258:Destroy()
			end
			if v228 < 1 and v_u_200 + 2 >= v225 then
				return true
			end
			v_u_207:Destroy()
			v_u_208:Destroy()
			v_u_209:Destroy()
			return false
		end)
		return v_u_223
	end
	v41.kanjogan_r = {
		["cast"] = function(p261) -- name: cast
			-- upvalues: (copy) p_u_40, (ref) v_u_7, (copy) v_u_69, (ref) v_u_6, (ref) v_u_12, (ref) v_u_13, (ref) v_u_4
			p_u_40.skillCast(p261, v_u_7, true)
			local v262 = p261.size
			local v263 = p261.eye + p261.dir * 1.3
			v_u_69(v263, 0.6 * v262, 4.5 * v262, v_u_6.KanjoRing, v_u_12, 0.3, 5)
			if not p261.lite then
				v_u_69(v263, 4 * v262, 0.5 * v262, v_u_6.KanjoRing, v_u_13, 0.25, -7)
			end
			if p261.mine then
				v_u_4.shake(0.15, 0.15)
			end
		end,
		["windup"] = function(p264, p265, p266) -- name: windup
			-- upvalues: (copy) v_u_260, (copy) v_u_195, (ref) v_u_4, (ref) v_u_8, (copy) p_u_40
			local v267 = v_u_260(p264, p265, p266)
			v_u_195[p264] = v267
			v_u_4.flash(v267.top, v_u_8, 12, 0.25)
			if not p264.lite then
				p_u_40.inward(v267.top, v_u_8, 8, 16, (math.max(p266, 0.12)))
			end
		end,
		["land"] = function(p268, p269) -- name: land
			-- upvalues: (copy) p_u_40, (copy) v_u_195, (ref) v_u_4, (ref) v_u_11, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (ref) v_u_8, (ref) v_u_35, (ref) v_u_12, (ref) v_u_1, (ref) v_u_39, (ref) v_u_15, (ref) v_u_10, (ref) v_u_5
			local v_u_270 = p268.ability.radius
			local v271 = p_u_40.ground(p269, 0)
			local v272 = p268.lite
			local v273 = p268.dir.Z
			local v274 = p268.dir.X
			local v275 = math.atan2(v273, v274)
			local v276 = v_u_195[p268]
			v_u_195[p268] = nil
			if v276 then
				v276.landed = os.clock()
				local v_u_277 = v276.top
				p_u_40.after(0.45, function()
					-- upvalues: (ref) v_u_4, (copy) v_u_277, (ref) v_u_11
					v_u_4.flash(v_u_277, v_u_11, 14, 0.2)
				end)
			end
			for v278 = 1, 8 do
				local v279 = v275 + (v278 - 1) / 8 * 3.141592653589793 * 2
				local v280 = math.cos(v279)
				local v281 = math.sin(v279)
				local v282 = v271 + Vector3.new(v280, 0, v281) * 20
				p_u_40.thin(p_u_40.pillar(v282, 18, 3.2, v_u_7), 0.5)
				p_u_40.thin(p_u_40.pillar(v282, 20, 1.1, v_u_11), 0.35)
				if not v272 then
					p_u_40.thin(p_u_40.pillar(v282, 13, 6.5, v_u_9, 0.45), 0.6)
					p_u_40.burst("Fire", v282 + Vector3.new(0, 0.2, 0), v_u_7, 1.1)
					p_u_40.pop(v282 + Vector3.new(0, 1.5, 0), v_u_11, 2, 6, 0.2)
				end
				v_u_4.ring(v282, v_u_7, 5.5, 0.35, v_u_6.Ring)
				p_u_40.thin(p_u_40.rod(v282 + Vector3.new(0, 0.6, 0), v271 + Vector3.new(0, 0.6, 0), 0.8, v_u_8, 0.1), 0.4)
			end
			local v_u_283 = v_u_35(CFrame.new(v271 + Vector3.new(0, 0.6, 0)), 20, v_u_6.Ring, v_u_12, 0)
			v_u_1:AddItem(v_u_283, 0.5)
			p_u_40.animate(0.4, 0, function(p284)
				-- upvalues: (copy) v_u_283, (copy) v_u_270, (ref) v_u_39
				local v285 = v_u_283
				local v286 = 20 + (v_u_270 * 1.15 - 20) * (1 - (1 - p284) ^ 2)
				local v287 = math.max(v286, 0.03)
				local v288 = v287 * 2
				local v289 = v287 * 2
				v285.Size = Vector3.new(v288, 0.05, v289)
				v_u_39(v_u_283, p284 ^ 1.5)
				if p284 >= 1 then
					v_u_283:Destroy()
				end
			end)
			v_u_4.flash(v271 + Vector3.new(0, 3, 0), v_u_8, 18, 0.25)
			p_u_40.pop(v271 + Vector3.new(0, 2, 0), v_u_11, 3, 14, 0.25)
			p_u_40.pop(v271 + Vector3.new(0, 2, 0), v_u_7, 4, v_u_270 * 2.3, 0.55, 0.2, v_u_15)
			p_u_40.dome(v271, v_u_270 * 1.05, v_u_7, 0.5)
			v_u_4.ring(v271, v_u_8, v_u_270 * 1.2, 0.5, v_u_6.Shockwave)
			v_u_4.ring(v271, v_u_7, v_u_270 * 1.35, 0.65, v_u_6.Ring)
			p_u_40.burst("Shockwave", v271 + Vector3.new(0, 0.3, 0), v_u_7, v_u_270 / 14)
			if not v272 then
				p_u_40.burst("Explosion", v271 + Vector3.new(0, 2, 0), v_u_7, 2)
				p_u_40.spikes(v271 + Vector3.new(0, 2, 0), v_u_8, 12, v_u_270 * 1.1, 0.35, nil, nil, true)
			end
			p_u_40.mark(v271, v_u_10, v_u_270 * 0.8, 1.2, v_u_6.Glow, 0.5)
			p_u_40.mark(v271, v_u_7, 20, 1, v_u_6.Ring, 0.3)
			v_u_5.play("Explosion", {
				["at"] = v271,
				["volume"] = p268.mine and 1 or 0.6
			})
			if p268.mine then
				v_u_4.shake(0.55, 0.45)
			end
		end,
		["hit"] = function(p290, p291, _) -- name: hit
			-- upvalues: (copy) p_u_40, (ref) v_u_7, (ref) v_u_8
			p_u_40.burst("Impact", p291, v_u_7, 0.8)
			if not p290.lite then
				p_u_40.glint(p291, v_u_8, 3, 0.14)
			end
		end
	}
	return v41
end