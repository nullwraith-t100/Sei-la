local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("FFB21F")
local v_u_8 = Color3.fromHex("FF6A00")
local v_u_9 = Color3.fromRGB(255, 238, 170)
local v_u_10 = Color3.fromRGB(225, 55, 10)
local v_u_11 = Color3.new(1, 1, 1)
local v_u_12 = Enum.PartType.Ball
local function v_u_24(p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part
	local v19 = p14 * 2
	local v20 = p14 * 2
	local v21 = v18(Vector3.new(v19, 0.05, v20), p13, p16, {
		["transparency"] = 1
	})
	for _, v22 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v23 = Instance.new("Decal")
		v23.Face = v22
		v23.Texture = p15
		v23.Color3 = p16
		v23.Transparency = p17
		v23.Parent = v21
	end
	return v21
end
local function v_u_28(p25, p26) -- name: setAlpha
	for _, v27 in p25:GetChildren() do
		if not v27:IsA("Decal") then
			continue
		end
		v27.Transparency = p26
	end
end
return function(p_u_29)
	-- upvalues: (copy) v_u_3, (copy) v_u_24, (copy) v_u_6, (copy) v_u_1, (copy) v_u_28, (copy) v_u_4, (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_7, (copy) v_u_10, (copy) v_u_11, (copy) v_u_5
	local function v_u_47(p30, p_u_31, p_u_32, p33, p34) -- name: corona
		-- upvalues: (ref) v_u_3, (copy) p_u_29, (ref) v_u_24, (ref) v_u_6, (ref) v_u_1, (ref) v_u_28
		local v35 = v_u_3.CurrentCamera
		local v36
		if v35 then
			local v37 = v35.CFrame.Position - p30
			v36 = v37.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v37.Unit
		else
			v36 = Vector3.new(0, 0, 1)
		end
		local v_u_38 = p_u_29.facing(p30 + v36 * 0.5, v36)
		local v_u_39 = v_u_24(v_u_38, p_u_31, v_u_6.CoronaFlare, p33, 0)
		v_u_1:AddItem(v_u_39, p34 + 0.1)
		p_u_29.animate(p34, 0, function(p40)
			-- upvalues: (copy) v_u_39, (copy) p_u_31, (copy) p_u_32, (copy) v_u_38, (ref) v_u_28
			local v41 = 1 - (1 - p40) ^ 3
			local v42 = v_u_39
			local v43 = p_u_31 + (p_u_32 - p_u_31) * v41
			local v44 = math.max(v43, 0.05)
			local v45 = v44 * 2
			local v46 = v44 * 2
			v42.Size = Vector3.new(v45, 0.05, v46)
			v_u_39.CFrame = v_u_38 * CFrame.Angles(0, p40 * 2, 0)
			v_u_28(v_u_39, p40 ^ 1.7)
			if p40 >= 1 then
				v_u_39:Destroy()
			end
		end)
	end
	local function v91(p48, p49) -- name: flareShot
		-- upvalues: (copy) p_u_29, (ref) v_u_4, (ref) v_u_8, (ref) v_u_9, (ref) v_u_12, (ref) v_u_24, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_1, (ref) v_u_3
		local v50 = p48.size
		local v_u_51 = p49.Position
		local v52 = p48.target + Vector3.new(0, 0.5, 0) - v_u_51
		local v53 = v52.Magnitude
		local v_u_54 = math.max(v53, 0.001)
		local v_u_55 = v52 / v_u_54
		local v56 = v_u_54 * 0.22
		local v_u_57 = math.clamp(v56, 3, 10) * v50
		local v_u_58 = p_u_29.flatUnit(v52):Cross(Vector3.new(0, 1, 0)) * (math.random() < 0.5 and -1 or 1) * v_u_57 * 0.3
		local v_u_59 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p49, v_u_8, {
			["transparency"] = 1
		})
		local v60 = {
			["shape"] = v_u_12
		}
		local v_u_61 = v_u_4.part(Vector3.new(0.8, 0.8, 0.8) * v50, p49, v_u_9, v60)
		local v62 = {
			["shape"] = nil,
			["transparency"] = 0.35,
			["shape"] = v_u_12
		}
		local v_u_63 = v_u_4.part(Vector3.new(1.6, 1.6, 1.6) * v50, p49, v_u_8, v62)
		local v_u_64 = v_u_24(p49, 1.8 * v50, v_u_6.CoronaFlare, v_u_7, 0.1)
		local v65 = { v_u_61, v_u_63, v_u_64 }
		p_u_29.streak(v_u_59, v_u_8, v_u_10, 1.5 * v50, 0.3)
		p_u_29.streak(v_u_61, v_u_9, v_u_8, 0.5 * v50, 0.18)
		local v_u_66 = {}
		if not p48.lite then
			local v67 = p_u_29.loop
			local v68 = v_u_8
			local v69 = 0.35 * v50
			table.insert(v_u_66, v67("Trail", v_u_61, v68, v69))
		end
		if p48.mine then
			p_u_29.light(v_u_59, v_u_8, 9 * v50)
		end
		for _, v70 in v65 do
			v_u_1:AddItem(v70, 3)
		end
		v_u_1:AddItem(v_u_59, 3)
		local v_u_71 = v_u_51
		local v_u_72 = false
		return {
			["place"] = function(p73, p74) -- name: place
				-- upvalues: (copy) v_u_51, (copy) v_u_55, (copy) v_u_54, (copy) v_u_57, (copy) v_u_58, (ref) v_u_71, (ref) p_u_29, (copy) v_u_59, (copy) v_u_61, (copy) v_u_63, (ref) v_u_3, (copy) v_u_64
				local v75 = p73.Position
				local v76 = (v75 - v_u_51):Dot(v_u_55) / v_u_54
				local v77 = math.clamp(v76, 0, 1)
				local v78 = Vector3.new(0, 1, 0) * v_u_57
				local v79 = 3.141592653589793 * v77 ^ 0.75
				local v80 = v75 + v78 * math.sin(v79)
				local v81 = v_u_58
				local v82 = 3.141592653589793 * v77
				local v83 = v80 + v81 * math.sin(v82)
				local v84 = v83 - v_u_71
				local v85
				if v84.Magnitude > 0.001 then
					v85 = p_u_29.aimAt(v83, v84)
				else
					v85 = CFrame.new(v83) * v_u_59.CFrame.Rotation
				end
				v_u_71 = v83
				v_u_59.CFrame = v85
				v_u_61.CFrame = v85
				v_u_63.CFrame = v85
				local v86 = v_u_3.CurrentCamera
				local v87
				if v86 then
					local v88 = v86.CFrame.Position - v83
					v87 = v88.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v88.Unit
				else
					v87 = Vector3.new(0, 0, 1)
				end
				v_u_64.CFrame = p_u_29.facing(v83 + v87 * 0.3, v87) * CFrame.Angles(0, p74 * 6, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_72, (copy) v_u_66, (copy) v_u_59, (ref) v_u_1, (copy) v_u_63, (copy) v_u_64, (copy) v_u_61
				if not v_u_72 then
					v_u_72 = true
					for _, v89 in v_u_66 do
						v89()
					end
					local v90 = v_u_59:FindFirstChildWhichIsA("PointLight")
					if v90 then
						v90:Destroy()
					end
					v_u_1:AddItem(v_u_59, 0.35)
					v_u_63:Destroy()
					v_u_64:Destroy()
					v_u_61.Transparency = 1
					v_u_1:AddItem(v_u_61, 0.25)
				end
			end
		}
	end
	local function v96(p92, p93) -- name: flareImpact
		-- upvalues: (copy) v_u_47, (ref) v_u_7, (copy) p_u_29, (ref) v_u_8, (ref) v_u_9, (ref) v_u_4, (ref) v_u_6
		local v94 = p92.size
		v_u_47(p93, 1.5 * v94, 5 * v94, v_u_7, 0.22)
		p_u_29.pop(p93, v_u_8, 1.2 * v94, 4.6 * v94, 0.18, 0.3)
		p_u_29.pop(p93, v_u_9, 0.8 * v94, 2.2 * v94, 0.1)
		v_u_4.ring(p_u_29.ground(p93), v_u_8, p92.ability.radius * v94, 0.25, v_u_6.Ring)
		p_u_29.burst("Impact", p93, v_u_8, 0.9 * v94)
		if not p92.lite then
			local v95 = { v_u_7, v_u_8, v_u_9 }
			p_u_29.chunks(p93, v95, 4, 22, 0.35 * v94, 0.45, true, 1.1)
		end
		p_u_29.hitSound(p93)
	end
	local v_u_97 = {}
	setmetatable(v_u_97, {
		["__mode"] = "k"
	})
	local function v_u_161(p98, p_u_99) -- name: spinUp
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_1, (ref) v_u_8, (ref) v_u_24, (ref) v_u_6, (copy) v_u_97, (copy) p_u_29, (ref) v_u_28
		local v_u_100 = p98.size
		local v_u_101 = p98.feet + Vector3.new(0, 2, 0)
		local v_u_102 = p_u_99 + 1.2
		local v_u_103 = 3.6 * v_u_100
		local v_u_104 = {}
		for _ = 1, 6 do
			local v105 = 2 * v_u_103 * 0.374606593415912
			local v106 = v_u_4.part
			local v107 = 0.5 * v_u_100
			local v108 = 0.35 * v_u_100
			local v109 = v106(Vector3.new(v107, v108, v105), CFrame.new(v_u_101), v_u_7)
			v_u_1:AddItem(v109, v_u_102)
			table.insert(v_u_104, v109)
		end
		local v_u_110 = {}
		for _ = 1, 3 do
			local v111 = v_u_4.part
			local v112 = 0.4 * v_u_100
			local v113 = 0.25 * v_u_100
			local v114 = v_u_103 * 0.62
			local v115 = v111(Vector3.new(v112, v113, v114), CFrame.new(v_u_101), v_u_8)
			v_u_1:AddItem(v115, v_u_102)
			table.insert(v_u_110, v115)
		end
		local v_u_116 = v_u_24(CFrame.new(v_u_101), 1.1 * v_u_100, v_u_6.Ring, v_u_8, 0)
		v_u_1:AddItem(v_u_116, v_u_102)
		local v_u_117 = {
			["rim"] = nil,
			["spokes"] = nil,
			["hub"] = nil,
			["center"] = nil,
			["born"] = nil,
			["flung"] = nil,
			["rim"] = v_u_104,
			["spokes"] = v_u_110,
			["hub"] = v_u_116,
			["center"] = v_u_101,
			["born"] = os.clock()
		}
		v_u_97[p98] = v_u_117
		local v_u_118 = v_u_117.born
		local v_u_119 = 0
		local v_u_120 = v_u_118
		p_u_29.runNow(function()
			-- upvalues: (ref) v_u_120, (copy) v_u_118, (copy) v_u_102, (copy) v_u_116, (ref) v_u_119, (copy) p_u_99, (copy) v_u_117, (copy) v_u_104, (copy) v_u_103, (copy) v_u_100, (copy) v_u_101, (copy) v_u_110, (ref) v_u_28
			local v121 = os.clock()
			local v122 = v121 - v_u_120
			local v123 = math.min(v122, 0.05)
			v_u_120 = v121
			local v124 = v121 - v_u_118
			if v_u_102 <= v124 or not v_u_116.Parent then
				return false
			end
			local v125 = v124 / 0.12
			local v126 = math.clamp(v125, 0, 1) - 1
			local v127 = v126 * 2.5 * v126 * v126 + 1 + v126 * 1.5 * v126
			local v128 = v_u_119
			local v129 = p_u_99
			local v130 = v124 / math.max(v129, 0.1)
			v_u_119 = v128 + v123 * (math.clamp(v130, 0, 1) * 26 + 4)
			local v131 = v_u_117.flung
			local v132
			if v131 then
				local v133 = (v121 - v131) / 0.45
				v132 = math.clamp(v133, 0, 1)
			else
				v132 = 0
			end
			for v134, v135 in v_u_104 do
				local v136 = v_u_119 + (v134 - 1) * 3.141592653589793 / 3
				local v137 = v_u_103 * v127 + v132 * 22 * v_u_100
				local v138 = v_u_101
				local v139 = math.cos(v136)
				local v140 = v132 * 0.12 * v134
				local v141 = math.sin(v136)
				local v142 = v138 + Vector3.new(v139, v140, v141) * v137
				local v143 = CFrame.lookAt
				local v144 = -math.sin(v136)
				local v145 = math.cos(v136)
				v135.CFrame = v143(v142, v142 + Vector3.new(v144, 0, v145)) * CFrame.Angles(v132 * 3 * v134, 0, v132 * 2)
				v135.Transparency = v132
			end
			for v146, v147 in v_u_110 do
				local v148 = -v_u_119 * 0.6 + (v146 - 1) * 3.141592653589793 * 2 / 3
				local v149 = math.cos(v148)
				local v150 = math.sin(v148)
				local v151 = Vector3.new(v149, 0, v150)
				local v152 = v_u_101 + v151 * v_u_103 * v127 * 0.55
				v147.CFrame = CFrame.lookAt(v152, v152 + v151)
				local v153 = v132 * 2
				v147.Transparency = math.min(v153, 1)
			end
			local v154 = v_u_116
			local v155 = 1.1 * v_u_100 * v127 * (v132 * 3 + 1)
			local v156 = math.max(v155, 0.05)
			local v157 = v156 * 2
			local v158 = v156 * 2
			v154.Size = Vector3.new(v157, 0.05, v158)
			v_u_116.CFrame = CFrame.new(v_u_101) * CFrame.Angles(0, v_u_119, 0)
			v_u_28(v_u_116, v132)
			if v132 < 1 then
				return true
			end
			for _, v159 in v_u_104 do
				v159:Destroy()
			end
			for _, v160 in v_u_110 do
				v160:Destroy()
			end
			v_u_116:Destroy()
			return false
		end)
	end
	local function v193(p162, p163) -- name: solarWind
		-- upvalues: (copy) p_u_29, (copy) v_u_97, (copy) v_u_47, (ref) v_u_7, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_10, (ref) v_u_1
		local v_u_164 = p162.size
		local v165 = p162.lite
		local v_u_166 = p162.ability.radius * v_u_164
		local v_u_167 = p_u_29.ground(p163, 0)
		local v168 = v_u_97[p162]
		if v168 then
			v168.flung = os.clock()
			v_u_97[p162] = nil
		end
		local v169 = v_u_167 + Vector3.new(0, 2.4, 0)
		v_u_47(v169, 3 * v_u_164, 10 * v_u_164, v_u_7, 0.3)
		v_u_4.flash(v169, v_u_9, 9 * v_u_164, 0.2)
		p_u_29.dome(p163, v_u_166, v_u_8, 0.4)
		p_u_29.burst("Shockwave", v_u_167 + Vector3.new(0, 0.3, 0), v_u_7, v_u_166 / 20)
		local v170 = v165 and 8 or 18
		local v171 = math.random() * 3.141592653589793 * 2
		for v172 = 1, v170 do
			local v_u_173 = v171 + (v172 - 1) / v170 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.3
			local v_u_174 = 0.8 + math.random() * 2.6
			local v175 = 0.3 + math.random() * 0.12
			local v_u_176 = 0.35 + math.random() * 0.15
			local v177 = v_u_4.part
			local v178 = Vector3.new(0.3, 0.3, 3.6) * v_u_164
			local v179 = CFrame.new(v_u_167 + Vector3.new(0, 1, 0) * v_u_174)
			local v180
			if v172 % 3 == 0 then
				v180 = v_u_9
			else
				v180 = v_u_7
			end
			local v_u_181 = v177(v178, v179, v180)
			p_u_29.streak(v_u_181, v_u_8, v_u_10, 0.7 * v_u_164, 0.22)
			v_u_1:AddItem(v_u_181, v175 + 0.5)
			local v_u_182 = v_u_167 + Vector3.new(0, 1, 0) * v_u_174
			p_u_29.animate(v175, 0, function(p183)
				-- upvalues: (copy) v_u_164, (copy) v_u_166, (copy) v_u_173, (copy) v_u_176, (copy) v_u_167, (copy) v_u_174, (ref) v_u_182, (copy) v_u_181
				local v184 = 1 - (1 - p183) ^ 1.6
				local v185 = 2.5 * v_u_164 + (v_u_166 * 1.05 - 2.5 * v_u_164) * v184
				local v186 = v_u_173 + v_u_176 * v184
				local v187 = v_u_167 + Vector3.new(0, 1, 0) * v_u_174
				local v188 = math.cos(v186)
				local v189 = math.sin(v186)
				local v190 = v187 + Vector3.new(v188, 0, v189) * v185
				local v191 = v190 - v_u_182
				if v191.Magnitude > 0.001 then
					v_u_181.CFrame = CFrame.lookAt(v190, v190 + v191)
				end
				v_u_182 = v190
				v_u_181.Transparency = p183 ^ 3
				if p183 >= 1 then
					v_u_181.Transparency = 1
				end
			end)
		end
		if not v165 then
			p_u_29.spikes(v169, v_u_7, 10, 8 * v_u_164, 0.25, nil, nil, true)
			local v192 = { v_u_7, v_u_8, v_u_9 }
			p_u_29.chunks(v169, v192, 6, 34, 0.4 * v_u_164, 0.6, true, 0.4)
		end
		if p162.mine then
			v_u_4.shake(0.25, 0.25)
		end
	end
	local v_u_194 = {}
	setmetatable(v_u_194, {
		["__mode"] = "k"
	})
	local v324 = {
		["corona_gear_a"] = {
			["cast"] = function(p195) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) p_u_29, (ref) v_u_9, (copy) v_u_47, (ref) v_u_7
				local v196 = p195.size
				local v197 = p195.eye + p195.dir * 1.2
				v_u_4.flash(v197, v_u_8, 3.2 * v196, 0.1)
				p_u_29.pop(v197, v_u_9, 1.2 * v196, 0.3 * v196, 0.1)
				if not p195.lite then
					v_u_47(v197, 0.6 * v196, 2 * v196, v_u_7, 0.12)
				end
			end,
			["shot"] = v91,
			["impact"] = v96,
			["hit"] = function(_, p198, _) -- name: hit
				-- upvalues: (copy) p_u_29, (ref) v_u_8
				p_u_29.burst("Impact", p198, v_u_8, 0.6)
			end
		},
		["corona_gear_e"] = {
			["cast"] = function(p199) -- name: cast
				-- upvalues: (copy) p_u_29, (ref) v_u_7
				p_u_29.skillCast(p199, v_u_7)
			end,
			["windup"] = function(p200, _, p201) -- name: windup
				-- upvalues: (copy) v_u_161
				v_u_161(p200, p201)
			end,
			["land"] = v193,
			["hit"] = function(p202, p203, _) -- name: hit
				-- upvalues: (copy) p_u_29, (ref) v_u_8, (ref) v_u_7
				p_u_29.burst("Impact", p203, v_u_8, 0.8)
				if not p202.lite then
					p_u_29.glint(p203, v_u_7, 3, 0.14)
				end
			end
		},
		["corona_gear_r"] = {
			["cast"] = function(p204) -- name: cast
				-- upvalues: (copy) p_u_29, (ref) v_u_7, (copy) v_u_47, (ref) v_u_8, (ref) v_u_4
				p_u_29.skillCast(p204, v_u_7, true)
				local v205 = p204.size
				v_u_47(p204.eye + p204.dir * 1.5, 1.5 * v205, 5 * v205, v_u_7, 0.3)
				p_u_29.burst("Flash", p204.eye, v_u_8, 0.35)
				if p204.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p206, p207, p208) -- name: assemble
				-- upvalues: (copy) p_u_29, (copy) v_u_194, (ref) v_u_4, (ref) v_u_7, (ref) v_u_9, (ref) v_u_1, (ref) v_u_12, (ref) v_u_24, (ref) v_u_6, (ref) v_u_8, (ref) v_u_11, (ref) v_u_3, (ref) v_u_28
				local v_u_209 = p206.size
				local v210 = p206.lite
				local v_u_211 = p_u_29.ground(p207, 17 * v_u_209)
				local v_u_212 = p_u_29.ground(p207, 0.3)
				local v_u_213 = 11 * v_u_209
				local v_u_214 = v210 and 8 or 12
				local v_u_215 = math.max(p208, 0.18)
				local v_u_216 = v_u_215 + 2.2
				local v_u_217 = math.random() * 3.141592653589793 * 2
				local v_u_218 = {
					["landAt"] = nil
				}
				v_u_194[p206] = v_u_218
				local v_u_219 = {}
				for v220 = 1, v_u_214 do
					local v221 = v_u_217 + (v220 - 1) / v_u_214 * 3.141592653589793 * 2 + (math.random() - 0.5) * 0.9
					local v222 = math.cos(v221)
					local v223 = math.sin(v221)
					local v224 = p207 + Vector3.new(v222, 0, v223) * (38 + math.random() * 12) * v_u_209 + Vector3.new(0, 1, 0) * (22 + math.random() * 14) * v_u_209
					local v225 = v_u_4.part(Vector3.new(3.1, 0.3, 2.3) * v_u_209, CFrame.new(v224), v_u_7, {
						["material"] = Enum.Material.Metal
					})
					v225.Reflectance = 0.2
					local v226 = v_u_4.part(Vector3.new(2.5, 0.12, 1.7) * v_u_209, CFrame.new(v224), v_u_9)
					v_u_1:AddItem(v225, v_u_216)
					v_u_1:AddItem(v226, v_u_216)
					local v227 = {
						["body"] = v225,
						["face"] = v226,
						["from"] = v224
					}
					local v228 = math.random() * 4
					local v229 = math.random() * 4
					local v230 = math.random() * 4
					v227.tumble = Vector3.new(v228, v229, v230)
					local v231 = math.cos(v221)
					local v232 = math.sin(v221)
					v227.out = Vector3.new(v231, 0, v232)
					table.insert(v_u_219, v227)
				end
				local v233 = {
					["shape"] = v_u_12
				}
				local v_u_234 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v_u_211), v_u_9, v233)
				local v_u_235 = v_u_24(CFrame.new(v_u_211), 0.1, v_u_6.CoronaFlare, v_u_7, 0.1)
				local v_u_236 = v_u_24(p_u_29.facing(v_u_211, Vector3.new(-0, -1, -0)), 0.1, v_u_6.Ring, v_u_8, 0)
				for _, v237 in { v_u_234, v_u_235, v_u_236 } do
					v_u_1:AddItem(v237, v_u_216)
				end
				if not v210 then
					v_u_4.flash(v_u_211, v_u_7, 8 * v_u_209, v_u_215)
				end
				local v_u_238 = os.clock()
				p_u_29.runNow(function()
					-- upvalues: (copy) v_u_238, (copy) v_u_216, (copy) v_u_234, (copy) v_u_215, (copy) v_u_218, (copy) v_u_219, (copy) v_u_217, (copy) v_u_214, (copy) v_u_211, (copy) v_u_213, (copy) v_u_212, (copy) v_u_209, (ref) v_u_11, (ref) v_u_9, (ref) v_u_3, (copy) v_u_235, (ref) p_u_29, (ref) v_u_28, (copy) v_u_236
					local v239 = os.clock()
					local v240 = v239 - v_u_238
					if v_u_216 <= v240 or not v_u_234.Parent then
						return false
					end
					local v241 = v240 / v_u_215
					local v242 = math.clamp(v241, 0, 1)
					local v243 = v242 - 1
					local v244 = v243 * 2.5 * v243 * v243 + 1 + v243 * 1.5 * v243
					local v245 = v240 * 0.7
					local v246 = v_u_218.landAt
					local v247 = not v246 and -1 or v239 - v246
					local v248 = (v247 - 0.9) / 0.6
					local v249 = math.clamp(v248, 0, 1)
					local v250 = (v247 - 0.7) / 0.5
					local v251 = math.clamp(v250, 0, 1)
					for v252, v253 in v_u_219 do
						local v254 = v_u_217 + (v252 - 1) / v_u_214 * 3.141592653589793 * 2 + v245
						local v255 = v_u_211
						local v256 = math.cos(v254)
						local v257 = math.sin(v254)
						local v258 = v255 + Vector3.new(v256, 0, v257) * v_u_213
						local v259 = v253.from:Lerp(v258, v244)
						local v260 = CFrame.lookAt(v259, v_u_212) * CFrame.Angles(-1.5707963267948966, 0, 0)
						if v242 < 1 then
							local v261 = (1 - v242) ^ 2
							v260 = v260 * CFrame.Angles(v253.tumble.X * v261, v253.tumble.Y * v261, v253.tumble.Z * v261)
						end
						if v249 > 0 then
							v260 = (v260 + (v253.out * 14 * v_u_209 * v249 + Vector3.new(-0, -12, -0) * v_u_209 * v249 * v249)) * CFrame.Angles(v253.tumble.X * v249, v253.tumble.Y * v249, v253.tumble.Z * v249)
						end
						v253.body.CFrame = v260
						v253.face.CFrame = v260 * CFrame.new(0, 0.18 * v_u_209, 0)
						v253.body.Transparency = v249
						v253.face.Transparency = v249
						local v262 = v253.face
						local v263
						if v247 >= 0 and v247 < 0.5 then
							v263 = v_u_11
						else
							v263 = v_u_9
						end
						v262.Color = v263
					end
					local v264 = v_u_211
					local v265 = v_u_3.CurrentCamera
					local v266
					if v265 then
						local v267 = v265.CFrame.Position - v264
						v266 = v267.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v267.Unit
					else
						v266 = Vector3.new(0, 0, 1)
					end
					local v268 = v_u_234
					local v269 = (v242 * 3 + 1) * v_u_209 * (1 - v251)
					v268.Size = Vector3.new(1, 1, 1) * math.max(v269, 0.05)
					v_u_234.Transparency = v251
					local v270 = v_u_235
					local v271 = (v242 * 5.5 + 2) * v_u_209
					local v272 = math.max(v271, 0.05)
					local v273 = v272 * 2
					local v274 = v272 * 2
					v270.Size = Vector3.new(v273, 0.05, v274)
					v_u_235.CFrame = p_u_29.facing(v_u_211 + v266 * 0.6, v266) * CFrame.Angles(0, v240 * 1.5, 0)
					v_u_28(v_u_235, v251 * 0.9 + 0.1)
					local v275 = v_u_236
					local v276 = v_u_213 * 1.15 * v242
					local v277 = math.max(v276, 0.05)
					local v278 = v277 * 2
					local v279 = v277 * 2
					v275.Size = Vector3.new(v278, 0.05, v279)
					v_u_236.CFrame = p_u_29.facing(v_u_211, Vector3.new(-0, -1, -0)) * CFrame.Angles(0, -v245, 0)
					local v280 = v_u_28
					local v281 = v_u_236
					local v282 = 1 - v242
					v280(v281, (math.max(v251, v282)))
					if v249 < 1 then
						return true
					end
					for _, v283 in v_u_219 do
						v283.body:Destroy()
						v283.face:Destroy()
					end
					v_u_234:Destroy()
					v_u_235:Destroy()
					v_u_236:Destroy()
					return false
				end)
			end,
			["land"] = function(p284, p285) -- name: column
				-- upvalues: (copy) p_u_29, (copy) v_u_194, (ref) v_u_9, (ref) v_u_8, (ref) v_u_7, (ref) v_u_4, (copy) v_u_47, (ref) v_u_6, (ref) v_u_5
				local v286 = p284.size
				local v287 = p284.lite
				local v288 = p284.ability.radius * v286
				local v289 = p_u_29.ground(p285, 0)
				local v290 = p_u_29.ground(p285, 17 * v286)
				local v291 = v_u_194[p284]
				if v291 then
					v291.landAt = os.clock()
				end
				local v292 = v287 and 6 or 12
				local v293 = math.random() * 3.141592653589793 * 2
				for v294 = 1, v292 do
					local v295 = v293 + (v294 - 1) / v292 * 3.141592653589793 * 2
					local v296 = math.cos(v295)
					local v297 = math.sin(v295)
					local v298 = v290 + Vector3.new(v296, 0, v297) * 11 * v286
					p_u_29.thin(p_u_29.rod(v298, v289 + Vector3.new(0, 0.5, 0), 0.45 * v286, v_u_9), 0.3)
				end
				local v_u_299 = 17 * v286
				local v_u_300 = {}
				for _, v301 in {
					{
						["color"] = nil,
						["w"] = 5.5,
						["a"] = 0,
						["color"] = v_u_9
					},
					{
						["color"] = nil,
						["w"] = 11,
						["a"] = 0.4,
						["color"] = v_u_8
					},
					{
						["color"] = nil,
						["w"] = 17,
						["a"] = 0.72,
						["color"] = v_u_7
					}
				} do
					local v302 = {
						["p"] = p_u_29.pillar(v289, v_u_299, 0.3, v301.color, v301.a),
						["w"] = v301.w * v286,
						["a"] = v301.a
					}
					table.insert(v_u_300, v302)
				end
				p_u_29.animate(0.95, 0, function(p303)
					-- upvalues: (copy) v_u_300, (copy) v_u_299
					local v304
					if p303 < 0.08 then
						v304 = p303 / 0.08
					elseif p303 < 0.6 then
						local v305 = p303 * 60
						v304 = math.sin(v305) * 0.05 + 1
					else
						v304 = 1 - (p303 - 0.6) / 0.4
					end
					for _, v306 in v_u_300 do
						local v307 = v306.w * v304
						local v308 = math.max(v307, 0.05)
						local v309 = v_u_299
						v306.p.Size = Vector3.new(v309, v308, v308)
						local v310 = v306.p
						local v311 = v306.a
						local v312 = 1 - v306.a
						local v313 = (p303 - 0.6) / 0.4
						v310.Transparency = v311 + v312 * math.clamp(v313, 0, 1)
					end
					if p303 >= 1 then
						for _, v314 in v_u_300 do
							v314.p:Destroy()
						end
					end
				end)
				local v315 = v289 + Vector3.new(0, 2, 0)
				v_u_4.flash(v315, v_u_9, v288 * 1.2, 0.25)
				v_u_47(v315, 4 * v286, v288 * 0.9, v_u_7, 0.45)
				p_u_29.mark(p285, v_u_8, v288 * 0.9, 1.6, v_u_6.Glow, 0.15)
				v_u_4.ring(v289, v_u_7, v288 * 1.1, 0.5, v_u_6.Shockwave)
				v_u_4.ring(v289, v_u_8, v288 * 1.4, 0.6, v_u_6.Ring)
				p_u_29.burst("Explosion", v289 + Vector3.new(0, 1.5, 0), v_u_8, 2.2)
				p_u_29.burst("Shockwave", v289 + Vector3.new(0, 0.3, 0), v_u_7, v288 / 14)
				p_u_29.spikes(v289 + Vector3.new(0, 1, 0), v_u_7, v287 and 6 or 14, v288, 0.3, Vector3.new(0, 1, 0), 0.9)
				if not v287 then
					for v316 = 1, 4 do
						local v317 = v293 + v316 * 3.141592653589793 / 2 + 0.4
						local v318 = math.cos(v317)
						local v319 = math.sin(v317)
						local v320 = v289 + Vector3.new(v318, 0, v319) * v288 * 0.5
						p_u_29.after(1.1, p_u_29.loopAt("Fire", v320, v_u_8, 1.5))
					end
					local v321 = { v_u_7, v_u_8, v_u_9 }
					p_u_29.chunks(v315, v321, 10, 40, 0.6 * v286, 1, true, 0.8)
				end
				v_u_5.play("Explosion", {
					["at"] = v315,
					["volume"] = p284.mine and 1 or 0.6
				})
				if p284.mine then
					v_u_4.shake(0.55, 0.45)
				end
			end,
			["hit"] = function(p322, p323, _) -- name: hit
				-- upvalues: (copy) p_u_29, (ref) v_u_8, (ref) v_u_7
				p_u_29.burst("Impact", p323, v_u_8, 1.1)
				if not p322.lite then
					p_u_29.glint(p323, v_u_7, 3.5, 0.15)
				end
			end
		}
	}
	return v324
end