local v_u_1 = require(script.Parent.Release)
local v_u_2 = require(script.Parent.Worlds)
local v_u_3 = {
	["STARTER"] = "sharingan",
	["RARITY_ORDER"] = {
		"Common",
		"Rare",
		"Epic",
		"Legendary",
		"Mythic"
	},
	["RARITY_COLOR"] = {
		["Common"] = "#C9D3DC",
		["Rare"] = "#3FA9FF",
		["Epic"] = "#B45CFF",
		["Legendary"] = "#FFC93C",
		["Mythic"] = "#FF3D6E"
	}
}
local function v14(p4, p5, p6, p7, p8, p9, p10, p11, p12) -- name: w2eye
	local v13 = {
		["id"] = nil,
		["name"] = nil,
		["short"] = nil,
		["rarity"] = nil,
		["wins"] = nil,
		["mult"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["attack"] = nil,
		["skillE"] = nil,
		["skillR"] = nil,
		["mode"] = nil,
		["blurb"] = nil,
		["pass"] = nil,
		["world"] = 2,
		["id"] = p4,
		["name"] = p5,
		["short"] = p5,
		["rarity"] = p6,
		["wins"] = p7,
		["mult"] = p8,
		["color"] = p9,
		["color2"] = p10,
		["attack"] = p4 .. "_a",
		["skillE"] = p4 .. "_e",
		["skillR"] = p4 .. "_r",
		["mode"] = {
			["name"] = p5 .. " Awakening",
			["look"] = "w2_" .. p4
		},
		["blurb"] = p11,
		["pass"] = p12
	}
	return v13
end
local function v25(p15, p16, p17, p18, p19, p20, p21, p22, p23) -- name: worldEye
	local v24 = {
		["id"] = p16,
		["name"] = p17,
		["short"] = p17,
		["rarity"] = p18,
		["wins"] = p19,
		["mult"] = p20,
		["color"] = p21,
		["color2"] = p22,
		["attack"] = p16 .. "_a",
		["skillE"] = p16 .. "_e",
		["skillR"] = p16 .. "_r",
		["mode"] = {
			["name"] = p17 .. " Awakening",
			["look"] = "w" .. p15 .. "_" .. p16
		},
		["blurb"] = p23,
		["world"] = p15
	}
	return v24
end
local v_u_26 = {}
local function v36(p27, p28, p29, p30, p31, p32, p33, p34) -- name: bossEye
	-- upvalues: (copy) v_u_26
	v_u_26[p27] = p31
	local v35 = {
		["id"] = nil,
		["name"] = nil,
		["short"] = nil,
		["rarity"] = nil,
		["wins"] = 0,
		["mult"] = 1,
		["color"] = nil,
		["color2"] = nil,
		["attack"] = nil,
		["skillE"] = nil,
		["skillR"] = nil,
		["mode"] = nil,
		["blurb"] = nil,
		["update"] = 2,
		["boss"] = nil,
		["id"] = p27,
		["name"] = p28,
		["short"] = p28,
		["rarity"] = p29,
		["color"] = p32,
		["color2"] = p33,
		["attack"] = p27 .. "_a",
		["skillE"] = p27 .. "_e",
		["skillR"] = p27 .. "_r",
		["mode"] = {
			["name"] = p28 .. " Awakening",
			["look"] = "w0_" .. p27
		},
		["blurb"] = p34,
		["boss"] = p30
	}
	return v35
end
local v37 = {
	{
		["id"] = "sharingan",
		["name"] = "Sharingan",
		["short"] = "Sharingan",
		["rarity"] = "Common",
		["wins"] = 0,
		["mult"] = 1,
		["color"] = "#E5141E",
		["color2"] = "#FF8A3D",
		["attack"] = "fireball",
		["skillE"] = "phoenix_flowers",
		["skillR"] = "genjutsu",
		["mode"] = nil,
		["blurb"] = "Fire release. Copies what it sees.",
		["mode"] = {
			["name"] = "Awakened Sharingan",
			["look"] = "tomoe"
		}
	},
	{
		["id"] = "mangekyo",
		["name"] = "Mangekyo Sharingan",
		["short"] = "Mangekyo",
		["rarity"] = "Rare",
		["wins"] = 10,
		["mult"] = 2,
		["color"] = "#D3121C",
		["color2"] = "#2A0610",
		["attack"] = "amaterasu_spark",
		["skillE"] = "amaterasu",
		["skillR"] = "kamui",
		["mode"] = nil,
		["blurb"] = "Black flames that never go out.",
		["mode"] = {
			["name"] = "Susanoo: Ribcage",
			["look"] = "ribcage"
		}
	},
	{
		["id"] = "geass",
		["name"] = "Geass",
		["short"] = "Geass",
		["rarity"] = "Rare",
		["wins"] = 50,
		["mult"] = 3,
		["color"] = "#FF2E63",
		["color2"] = "#FFC2D4",
		["attack"] = "command_ray",
		["skillE"] = "command_kneel",
		["skillR"] = "command_perish",
		["mode"] = nil,
		["blurb"] = "Absolute obedience.",
		["mode"] = {
			["name"] = "Geass Overdrive",
			["look"] = "sigil"
		}
	},
	{
		["id"] = "eternal_mangekyo",
		["name"] = "Eternal Mangekyo Sharingan",
		["short"] = "Eternal Mangekyo",
		["rarity"] = "Epic",
		["wins"] = 300,
		["mult"] = 4,
		["color"] = "#8A5CFF",
		["color2"] = "#D3121C",
		["attack"] = "blaze_arrow",
		["skillE"] = "blaze_release",
		["skillR"] = "susanoo_arrow",
		["mode"] = nil,
		["blurb"] = "Eternal light. Perfect Susanoo.",
		["mode"] = {
			["name"] = "Susanoo: Archer",
			["look"] = "susanoo"
		}
	},
	{
		["id"] = "rinnegan",
		["name"] = "Rinnegan",
		["short"] = "Rinnegan",
		["rarity"] = "Epic",
		["wins"] = 2000,
		["mult"] = 7,
		["color"] = "#A98BFF",
		["color2"] = "#2E1A5E",
		["attack"] = "chakra_rod",
		["skillE"] = "shinra_tensei",
		["skillR"] = "chibaku_tensei",
		["mode"] = nil,
		["blurb"] = "Push, pull, and crush.",
		["mode"] = {
			["name"] = "Six Paths Mode",
			["look"] = "orbs"
		}
	},
	{
		["id"] = "jogan",
		["name"] = "Jogan",
		["short"] = "Jogan",
		["rarity"] = "Epic",
		["wins"] = 15000,
		["mult"] = 10,
		["color"] = "#4FB4FF",
		["color2"] = "#E8F6FF",
		["attack"] = "jogan_pulse",
		["skillE"] = "dimension_rift",
		["skillR"] = "jogan_laser",
		["mode"] = nil,
		["blurb"] = "Sees through dimensions.",
		["mode"] = {
			["name"] = "Jogan Awakening",
			["look"] = "lightning"
		}
	},
	{
		["id"] = "tenseigan",
		["name"] = "Tenseigan",
		["short"] = "Tenseigan",
		["rarity"] = "Legendary",
		["wins"] = 100000,
		["mult"] = 14,
		["color"] = "#9BE7FF",
		["color2"] = "#FFFFFF",
		["attack"] = "truth_orb",
		["skillE"] = "orb_barrage",
		["skillR"] = "planetary_devastation",
		["mode"] = nil,
		["blurb"] = "Reincarnation eye of the moon.",
		["mode"] = {
			["name"] = "Tenseigan Chakra Mode",
			["look"] = "cloak"
		}
	},
	{
		["id"] = "rinne_sharingan",
		["name"] = "Rinne Sharingan",
		["short"] = "Rinne Sharingan",
		["rarity"] = "Mythic",
		["wins"] = 500000,
		["mult"] = 32,
		["color"] = "#FF2B3A",
		["color2"] = "#2B0A3D",
		["attack"] = "tomoe_orb",
		["skillE"] = "limbo_strike",
		["skillR"] = "infinite_tsukuyomi",
		["mode"] = nil,
		["blurb"] = "The eye of the moon\'s goddess.",
		["mode"] = {
			["name"] = "Ten-Tails Avatar",
			["look"] = "tentails"
		}
	},
	{
		["id"] = "senrigan",
		["name"] = "Senrigan",
		["short"] = "Senrigan",
		["rarity"] = "Legendary",
		["wins"] = 2000000,
		["mult"] = 75,
		["color"] = "#FFC83A",
		["color2"] = "#FFF3C4",
		["attack"] = "light_arrow",
		["skillE"] = "arrow_storm",
		["skillR"] = "clairvoyant_judgement",
		["mode"] = nil,
		["blurb"] = "Sees the past, present and future.",
		["mode"] = {
			["name"] = "Clairvoyance",
			["look"] = "garden"
		}
	},
	{
		["id"] = "shion",
		["name"] = "Shion\'s Dojutsu",
		["short"] = "Shion\'s Dojutsu",
		["rarity"] = "Legendary",
		["wins"] = 6000000,
		["mult"] = 170,
		["color"] = "#F3A6FF",
		["color2"] = "#FFFFFF",
		["attack"] = "sealing_light",
		["skillE"] = "sealing_lotus",
		["skillR"] = "prophecy",
		["mode"] = nil,
		["blurb"] = "Foresees the end of all things.",
		["mode"] = {
			["name"] = "Priestess Seal",
			["look"] = "lotus"
		}
	},
	{
		["id"] = "six_eyes",
		["name"] = "Six Eyes",
		["short"] = "Six Eyes",
		["rarity"] = "Mythic",
		["wins"] = 15000000,
		["mult"] = 400,
		["color"] = "#35C8FF",
		["color2"] = "#9B5BFF",
		["attack"] = "lapse_blue",
		["skillE"] = "reversal_red",
		["skillR"] = "hollow_purple",
		["mode"] = nil,
		["blurb"] = "Limitless. The strongest.",
		["mode"] = {
			["name"] = "Limitless: Infinity",
			["look"] = "domain"
		}
	},
	{
		["id"] = "kokugan",
		["name"] = "Kokugan",
		["short"] = "Kokugan",
		["rarity"] = "Mythic",
		["wins"] = 40000000,
		["mult"] = 900,
		["color"] = "#E8E4F2",
		["color2"] = "#3A2A5C",
		["attack"] = "sukunahikona",
		["skillE"] = "daikokuten",
		["skillR"] = "karma_cube",
		["mode"] = nil,
		["blurb"] = "Isshiki\'s eye. Shrinks and crushes.",
		["mode"] = {
			["name"] = "Otsutsuki Awakening",
			["look"] = "otsutsuki"
		}
	},
	{
		["id"] = "all_seeing",
		["name"] = "All-Seeing Eyes of God",
		["short"] = "Eyes of God",
		["rarity"] = "Mythic",
		["wins"] = 100000000,
		["mult"] = 2100,
		["color"] = "#FFD966",
		["color2"] = "#FFFFFF",
		["attack"] = "god_ray",
		["skillE"] = "divine_judgement",
		["skillR"] = "heavens_gaze",
		["mode"] = nil,
		["blurb"] = "Sees everything. Judges everything.",
		["mode"] = {
			["name"] = "Divine Sight",
			["look"] = "divine"
		}
	},
	{
		["id"] = "shin_ketsuryugan",
		["name"] = "Shin Ketsuryugan",
		["short"] = "Shin Ketsuryugan",
		["rarity"] = "Mythic",
		["wins"] = 0,
		["mult"] = 3000,
		["color"] = "#B3001B",
		["color2"] = "#FF3B3B",
		["attack"] = "blood_needles",
		["skillE"] = "crimson_crescent",
		["skillR"] = "blood_moon",
		["mode"] = nil,
		["blurb"] = "The true blood eye.",
		["pass"] = "shin",
		["mode"] = {
			["name"] = "Blood Moon",
			["look"] = "blood"
		}
	},
	v14("beast_gaze", "Beast Gaze", "Epic", 790000000, 3900, "#FFD31A", "#FFF27A", "Eyes of a caged beast."),
	v14("violet_halo", "Violet Halo", "Epic", 3400000000, 16000, "#B04DFF", "#F2D9FF", "A ring of violet light."),
	v14("venom_tomoe", "Venom Tomoe", "Epic", 14000000000, 66000, "#39FF5A", "#0B3D12", "Three poisoned tomoe."),
	v14("lotus_eye", "Lotus Eye", "Legendary", 59000000000, 270000, "#FF6F9E", "#FFE3EC", "A lotus that never wilts."),
	v14("phantom_pinwheel", "Phantom Pinwheel", "Legendary", 240000000000, 1100000, "#6B2BD9", "#D9B8FF", "Spins between worlds."),
	v14("amethyst_star", "Amethyst Star", "Legendary", 960000000000, 4500000, "#9B3DE6", "#E9D2FF", "A six-pointed seal."),
	v14("grave_rinne", "Grave Rinne", "Legendary", 14000000000000, 19000000, "#8E86A3", "#2A2733", "Rings of the underworld."),
	v14("jade_seal", "Jade Seal", "Legendary", 54000000000000, 76000000, "#C6E22B", "#2E3A08", "An ancient jade curse."),
	v14("solar_lotus", "Solar Lotus", "Mythic", 210000000000000, 310000000, "#FF8A1E", "#FFE36B", "Blooms like the sun."),
	v14("crimson_spiral", "Crimson Spiral", "Mythic", 820000000000000, 1300000000, "#7A1020", "#F3E6E6", "A spiral of old blood."),
	v14("sage_rings", "Sage Rings", "Mythic", 3200000000000000, 5200000000, "#F1E08A", "#FFFDF0", "Nine tomoe of the sage."),
	v14("oracle_eye", "Oracle Eye", "Mythic", 1.2e16, 21000000000, "#E8B530", "#FFF0B0", "Reads every fate."),
	v14("celestial_gaze", "Celestial Gaze", "Mythic", 4.7e16, 88000000000, "#FFC21A", "#FFF7D1", "The supreme eye of the heavens."),
	v25(3, "blossom_orbit", "Blossom Orbit", "Epic", 3.9e17, 260000000000, "#FF5FA8", "#FFF0F6", "Three moons in bloom."),
	v25(3, "thorn_blossom", "Thorn Blossom", "Epic", 1.7e18, 1100000000000, "#FF3FA4", "#2A0718", "A flower with thorns for petals."),
	v25(3, "crimson_bloom", "Crimson Bloom", "Epic", 7.1e18, 4300000000000, "#E3122E", "#1A0306", "Blooms in blood."),
	v25(3, "nightshade_pinwheel", "Nightshade Pinwheel", "Epic", 2.8e19, 17000000000000, "#8A4BD6", "#1A0A2E", "Turns with the night."),
	v25(3, "iron_mandala", "Iron Mandala", "Legendary", 1.2e20, 70000000000000, "#B8C2CC", "#2B3036", "An eye forged of iron rings."),
	v25(3, "void_compass", "Void Compass", "Legendary", 4.6e20, 290000000000000, "#4FC8FF", "#7A3BE0", "Points to every void."),
	v25(3, "blood_trident", "Blood Trident", "Legendary", 1.8e21, 1100000000000000, "#E8141F", "#0D0405", "Three blades of blood."),
	v25(3, "moon_rinne", "Moon Rinne", "Legendary", 7.1e21, 4700000000000000, "#F2F2F8", "#1C1C24", "The pale eye of the moon."),
	v25(3, "rift_crescent", "Rift Crescent", "Mythic", 2.8e22, 1.8e16, "#D3121B", "#0A0002", "Tears the sky open."),
	v25(3, "scarlet_whirl", "Scarlet Whirl", "Mythic", 1.1e23, 7.7e16, "#C8101E", "#FF5A64", "A whirl of scarlet blades."),
	v25(3, "eclipse_spiral", "Eclipse Spiral", "Mythic", 4.2e23, 3.1e17, "#FFFFFF", "#101014", "The sun swallowed by night."),
	v25(3, "inferno_star", "Inferno Star", "Mythic", 1.6e24, 1.2e18, "#FF7A12", "#FFD23A", "A star of hellfire."),
	v25(3, "thorn_halo", "Thorn Halo", "Mythic", 6.1e24, 5.1e18, "#E6D2FF", "#2A1B3D", "A crown of white thorns."),
	v25(3, "arcane_sigil", "Arcane Sigil", "Mythic", 2.4e25, 2.1e19, "#B57BFF", "#F0E2FF", "The supreme eye of the blood moon."),
	v25(4, "tide_tomoe", "Tide Tomoe", "Epic", 2e26, 4.7e19, "#2FD8B5", "#063A33", "Six tomoe in the tide."),
	v25(4, "frost_thorn", "Frost Thorn", "Epic", 8.5e26, 2e20, "#4FE0C8", "#0B2E2A", "Thorns of black ice."),
	v25(4, "glacier_star", "Glacier Star", "Epic", 3.6e27, 7.7e20, "#4D7CFF", "#CFE1FF", "A star frozen in a glacier."),
	v25(4, "frozen_rinne", "Frozen Rinne", "Epic", 1.4e28, 3.1e21, "#9EDCFF", "#E8F7FF", "Rings of frozen tomoe."),
	v25(4, "abyss_spindle", "Abyss Spindle", "Legendary", 5.8e28, 1.3e22, "#2338D8", "#050A3A", "Spun in the deep."),
	v25(4, "starsea_rinne", "Starsea Rinne", "Legendary", 2.3e29, 5.1e22, "#3B8BFF", "#0A1B4D", "A sea of stars."),
	(v25(4, "azure_flame", "Azure Flame", "Legendary", 9.2e29, 2.1e23, "#33A7FF", "#DDF4FF", "Blue fire that never melts."))
}
local v38 = v25(4, "polar_dial", "Polar Dial", "Legendary", 3.55e30, 8.3e23, "#BFE6FF", "#0A0F1A", "A compass that only points north.")
local v39 = v25(4, "blizzard_wheel", "Blizzard Wheel", "Mythic", 1.4e31, 3.4e24, "#F4F6F8", "#0B0B0B", "A white storm turning round a black eye.")
local v40 = v25(4, "dark_maelstrom", "Dark Maelstrom", "Mythic", 5.5e31, 1.4e25, "#8A2A1A", "#120404", "A whirlpool at the bottom of the sea.")
local v41 = v25(4, "ember_trinity", "Ember Trinity", "Mythic", 2.1e32, 5.6e25, "#FF7A1A", "#FFD84A", "Three blades of fire under the ice.")
local v42 = v25(4, "glacier_sharingan", "Glacier Sharingan", "Legendary", 8.4e32, 1.1e26, "#38D6FF", "#04222E", "Three black blades frozen in a cyan sea.")
v42.update = 2
local v43 = v25(4, "kurobyougan", "Kurobyougan", "Mythic", 3.4e33, 2.2e26, "#E8E8F0", "#0A0A0A", "A black star whirling in a white storm.")
v43.update = 2
local v44 = v25(4, "yumegan", "Yumegan", "Mythic", 1.35e34, 4.5e26, "#7FD8FF", "#0B0F1A", "The dream node: a star drawn in the iris.")
v44.update = 2
__set_list(v37, 49, {v38, v39, v40, v41, v42, v43, v44, v25(5, "astral_bloom", "Astral Bloom", "Epic", 1e35, 1.2e26, "#F4F2FF", "#1A1A2E", "A flower drawn in starlight."), v25(5, "crimson_vortex", "Crimson Vortex", "Epic", 4.2e35, 4.8e26, "#E8102A", "#0A0A0A", "Red arms of a spinning galaxy."), v25(5, "corona_gear", "Corona Gear", "Epic", 1.8e36, 1.9e27, "#FFB21F", "#FF6A00", "The sun\'s corona, turning like a gear."), v25(5, "mangekyou_byakugan", "Mangekyou Byakugan", "Epic", 6.9e36, 7.7e27, "#E6E4FF", "#141428", "The white eye, awakened."), v25(5, "crimson_comet", "Crimson Comet", "Epic", 2.9e37, 3.1e28, "#FF2A2A", "#5A0008", "A red star that never stops spinning."), v25(5, "pulsar_tomoe", "Pulsar Tomoe", "Legendary", 1.14e38, 1.2e29, "#E89AA8", "#5A1E2E", "Tomoe that beat like a pulsar."), v25(5, "mangekyou_jigokugan", "Mangekyou Jigokugan", "Legendary", 4.6e38, 4.9e29, "#6A3FC8", "#120A2A", "The eye of hell, awakened."), v25(5, "astral_sigil", "Astral Sigil", "Legendary", 1.8e39, 2e30, "#3FF0F0", "#0A2A3A", "A seal written in the stars."), (v25(5, "red_giant", "Red Giant", "Legendary", 7e39, 7.9e30, "#D8141E", "#2A0004", "A dying star full of tomoe."))})
local v45 = v25(5, "void_gaze", "Void Gaze", "Legendary", 2.75e40, 3.1e31, "#5AD8FF", "#0A1A3A", "It sees across the whole void.")
local v46 = v25(5, "nova_trinity", "Nova Trinity", "Mythic", 1.05e41, 1.3e32, "#FF8A1A", "#FFE14B", "Three blades in a burning star.")
local v47 = v25(5, "dark_star", "Dark Star", "Mythic", 4e41, 5e32, "#9B4DFF", "#F0E0FF", "The light at the heart of the dark.")
local v48 = v25(5, "nebula_rinne", "Nebula Rinne", "Mythic", 1.54e42, 2e33, "#B06BFF", "#FFFFFF", "Rings of tomoe across a nebula.")
local v49 = v25(5, "chikaragan", "Chikaragan", "Mythic", 5.9e42, 8e33, "#C8D4FF", "#5A6BFF", "The power that bends space.")
local v50 = v25(6, "raging_current", "Raging Current", "Epic", 7.5e43, 1.3e35, "#2E8BFF", "#E8F6FF", "A riptide turning round a black pupil.")
v50.update = 4
local v51 = v25(6, "hell_butterfly", "Hell Butterfly", "Epic", 3.15e44, 8.32e35, "#FFD21F", "#141414", "Black butterflies that guide the dead.")
v51.update = 4
local v52 = v25(6, "raiko_gaze", "Raiko Gaze", "Epic", 1.35e45, 5.38e36, "#FF9A1F", "#FFF4D0", "Thunder caught in a golden flame.")
v52.update = 4
local v53 = v25(6, "kido_seal", "Kido Seal", "Epic", 5.17e45, 3.4e37, "#F4F2EE", "#D8263A", "A binding spell written in the iris.")
v53.update = 4
local v54 = v25(6, "shinso_edge", "Shinso Edge", "Epic", 2.18e46, 2.16e38, "#8A3CFF", "#D8DCE8", "Three silver blades that reach for miles.")
v54.update = 4
local v55 = v25(6, "shirayuki", "Shirayuki", "Legendary", 8.55e46, 1.36e39, "#5AE6FF", "#EFFFFF", "The whitest snow in Soul Society.")
v55.update = 4
local v56 = v25(6, "quincy_cross", "Quincy Cross", "Legendary", 3.45e47, 8.89e39, "#1E3CC8", "#F4F8FF", "A star of spirit light in the rings.")
v56.update = 4
local v57 = v25(6, "sanrei_lattice", "Sanrei Lattice", "Legendary", 1.35e48, 5.64e40, "#3A8AFF", "#FFFFFF", "A lattice of blades drawn from the air.")
v57.update = 4
local v58 = v25(6, "kyoka_suigetsu", "Kyoka Suigetsu", "Legendary", 5.25e48, 3.65e41, "#E01E9A", "#140810", "Whatever it shows you is a lie.")
v58.update = 4
local v59 = v25(6, "black_coffin", "Black Coffin", "Legendary", 2.06e49, 2.34e42, "#7A2AD8", "#0A0610", "Spikes of darkness closing in.")
v59.update = 4
local v60 = v25(6, "senbonzakura", "Senbonzakura", "Mythic", 7.87e49, 1.54e43, "#FF7FB8", "#FFE4F0", "A thousand blades scattering like petals.")
v60.update = 4
__set_list(v37, 65, {v45, v46, v47, v48, v49, v50, v51, v52, v53, v54, v55, v56, v57, v58, v59, v60})
local v61 = v25(6, "hyorinmaru", "Hyorinmaru", "Mythic", 3e50, 9.5e43, "#8AD8FF", "#E8FAFF", "The ice dragon that rules the heavens.")
v61.update = 4
local v62 = v25(6, "ryujin_jakka", "Ryujin Jakka", "Mythic", 1.15e51, 6.19e44, "#FF4A1A", "#FFD24A", "The oldest and strongest flame.")
v62.update = 4
local v63 = v25(6, "getsuga_tensho", "Getsuga Tensho", "Mythic", 4.42e51, 3.92e45, "#E0141E", "#0A0A0A", "A black moon fang that cuts the sky.")
v63.update = 4
local v64 = v25(7, "gamuza", "Gamuza", "Epic", 7e52, 7.88e45, "#3FD9A0", "#FF6FB5", "A twin lance charging out of the sand.")
v64.update = 4
local v65 = v25(7, "resurreccion", "Resurreccion", "Epic", 2.94e53, 5.04e46, "#2EE6C9", "#F2EBD9", "The sword breaks and the Hollow returns.")
v65.update = 4
local v66 = v25(7, "gran_rey_cero", "Gran Rey Cero", "Epic", 1.26e54, 3.23e47, "#3D7BFF", "#E6F0FF", "A cero sealed with an Espada\'s blood.")
v66.update = 4
local v67 = v25(7, "cero_inferno", "Cero Inferno", "Epic", 4.83e54, 2.06e48, "#FF2A2A", "#120000", "Red light that burns from the inside out.")
v67.update = 4
local v68 = v25(7, "tatarforas", "Tatarforas", "Epic", 2.03e55, 1.31e49, "#A05CFF", "#F2F0FA", "One look and the fear takes root.")
v68.update = 4
local v69 = v25(7, "los_lobos", "Los Lobos", "Legendary", 7.98e55, 8.26e49, "#8FD3FF", "#FFFFFF", "A lonely wolf who runs with a pack.")
v69.update = 4
local v70 = v25(7, "pantera", "Pantera", "Legendary", 3.22e56, 5.36e50, "#2FA8FF", "#33F0D2", "The king of the panthers bares his claws.")
v70.update = 4
local v71 = v25(7, "compulsory", "The Compulsory", "Legendary", 1.26e57, 3.44e51, "#FFC83D", "#F4F6FA", "Every nerve moves at someone else\'s will.")
v71.update = 4
local v72 = v25(7, "murcielago", "Murcielago", "Legendary", 4.9e57, 2.22e52, "#2BFF9A", "#0B2A1E", "Green tears under a moon that never sets.")
v72.update = 4
local v73 = v25(7, "inner_hollow", "Inner Hollow", "Legendary", 1.92e58, 1.42e53, "#FFD21F", "#0A0A0A", "Gold on black, and it wants out.")
v73.update = 4
local v74 = v25(7, "vasto_lorde", "Vasto Lorde", "Mythic", 7.35e58, 9.15e53, "#FF2E3A", "#F2EBD9", "The Hollow at the very top.")
v74.update = 4
local v75 = v25(7, "hogyoku", "Hogyoku", "Mythic", 2.8e59, 5.78e54, "#B05CFF", "#8A7D74", "It grants whatever its holder wishes.")
v75.update = 4
__set_list(v37, 81, {v61, v62, v63, {
	["id"] = "hakka_no_togame",
	["name"] = "Hakka no Togame",
	["short"] = "Hakka no Togame",
	["rarity"] = "Mythic",
	["wins"] = 0,
	["mult"] = 120000000000,
	["mults"] = nil,
	["color"] = "#C9B8FF",
	["color2"] = "#EFFFFF",
	["attack"] = "hakka_no_togame_a",
	["skillE"] = "hakka_no_togame_e",
	["skillR"] = "hakka_no_togame_r",
	["mode"] = nil,
	["blurb"] = "Absolute zero, blooming into white flowers.",
	["pass"] = "hakkaNoTogame",
	["unreleased"] = true,
	["world"] = 6,
	["mults"] = {
		120000000000,
		120000000000,
		3.4e19,
		7.2e26,
		1.04e35,
		6.8e45,
		4.1e56,
		2.5e67
	},
	["mode"] = {
		["name"] = "Bankai: Hakka no Togame",
		["look"] = "w6_hakka_no_togame"
	},
	["update"] = 4
}, v64, v65, v66, v67, v68, v69, v70, v71, v72, v73, v74, v75})
local v76 = v25(7, "soul_king", "Soul King", "Mythic", 1.08e60, 3.74e55, "#34E5FF", "#0A1A3A", "A king sealed in crystal for a million years.")
v76.update = 4
local v77 = v25(7, "almighty", "The Almighty", "Mythic", 4.13e60, 2.37e56, "#6FC3FF", "#050510", "He sees every future and picks his own.")
v77.update = 4
local v78 = v25(8, "exploding_blood", "Exploding Blood", "Epic", 8.75e61, 4.77e56, "#FF4FA0", "#2A0010", "Her blood bursts into pink flame.")
v78.update = 4
local v79 = v25(8, "lower_moon", "Lower Moon", "Epic", 3.67e62, 3.05e57, "#8A5CFF", "#F0E6FF", "Sleep, and dream whatever it wants.")
v79.update = 4
local v80 = v25(8, "blood_sickle", "Blood Sickle", "Epic", 1.57e63, 1.95e58, "#E0213A", "#9CFF3D", "Two demons sharing one body of blades.")
v80.update = 4
local v81 = v25(8, "black_thunder", "Black Thunder", "Epic", 6.04e63, 1.25e59, "#B03CFF", "#120012", "Thunder that turned its back on its master.")
v81.update = 4
local v82 = v25(8, "thousand_needles", "Thousand Needles", "Epic", 2.54e64, 7.98e59, "#3DE0FF", "#F5E6C8", "Every vase hides a fish full of needles.")
v82.update = 4
local v83 = v25(8, "zohakuten", "Zohakuten", "Legendary", 9.98e64, 5e60, "#FF8A1F", "#3A2414", "Hatred carved into five wooden dragons.")
v83.update = 4
local v84 = v25(8, "dead_calm", "Dead Calm", "Legendary", 4.03e65, 3.24e61, "#2EA8FF", "#FFF7C2", "Still water that cuts whatever enters it.")
v84.update = 4
local v85 = v25(8, "biwa_castle", "Biwa Castle", "Legendary", 1.57e66, 2.07e62, "#FF6FB8", "#2A1030", "One string, and the whole castle moves.")
v85.update = 4
local v86 = v25(8, "destructive_death", "Destructive Death", "Legendary", 6.12e66, 1.34e63, "#46C8FF", "#FF9A1F", "A compass that points at the strongest.")
v86.update = 4
local v87 = v25(8, "cryo_lotus", "Cryo Lotus", "Legendary", 2.41e67, 8.58e63, "#FF6FD8", "#7AF0FF", "A rainbow smile over a heart of ice.")
v87.update = 4
local v88 = v25(8, "demon_seal", "Demon Seal", "Mythic", 9.19e67, 5.54e64, "#FF2E6A", "#C9D2E6", "A clockwork sigil that locks a demon in.")
v88.update = 4
local v89 = v25(8, "moon_breathing", "Moon Breathing", "Mythic", 3.5e68, 3.5e65, "#FFD23D", "#8A0F2A", "Six eyes, and a moon in every cut.")
v89.update = 4
local v90 = v25(8, "sun_breathing", "Sun Breathing", "Mythic", 1.35e69, 2.26e66, "#FFB21F", "#FFF4CC", "The first breath, burning like the sun.")
v90.update = 4
local v91 = v25(8, "demon_king", "Demon King", "Mythic", 5.16e69, 1.44e67, "#FF1A2E", "#1A0006", "The first demon, and the last.")
v91.update = 4
__set_list(v37, 97, {v76, v77, v78, v79, v80, v81, v82, v83, v84, v85, v86, v87, v88, v89, v90, v91})
__set_list(v37, 113, {v14("prism_eye", "Prism Eye", "Mythic", 0, 120000000000, "#FF5AD1", "#6BE7FF", "Every colour of power.", "prismEye"), {
	["id"] = "six_paths_sage",
	["name"] = "Six Paths Sage",
	["short"] = "Six Paths Sage",
	["rarity"] = "Mythic",
	["wins"] = 0,
	["mult"] = 3750,
	["mults"] = nil,
	["color"] = "#FF8A00",
	["color2"] = "#FFE14B",
	["attack"] = "six_paths_sage_a",
	["skillE"] = "six_paths_sage_e",
	["skillR"] = "six_paths_sage_r",
	["mode"] = nil,
	["blurb"] = "Kyubi\'s chakra and the power of the Six Paths.",
	["pass"] = "sixPaths",
	["everyWorld"] = true,
	["mults"] = {
		3750,
		150000000000,
		4.1e19,
		1.1e26,
		1.2e35,
		7.45e45,
		4.45e56,
		2.7e67
	},
	["mode"] = {
		["name"] = "Kyubi Sage Mode",
		["look"] = "six_paths"
	}
}, v36("kanjogan", "Kanjogan", "Legendary", 1000, 0.6, "#9A7BFF", "#1A1030", "It senses every chakra in the world."), v36("fuma_mangekyo", "Fuma Mangekyo", "Mythic", 2400, 0.75, "#FF1E1E", "#0A0A0A", "A giant shuriken turning in a red spiral."), (v36("kurenai_mangekyo", "Kurenai Mangekyo", "Mythic", 3200, 0.85, "#FF2A2A", "#120000", "Crimson blades ringed with tomoe."))})
v_u_3.list = v37
v_u_3.PODIUM = {
	[3] = "shin_ketsuryugan",
	[4] = "prism_eye",
	[5] = "prism_eye",
	[6] = "prism_eye",
	[7] = "prism_eye",
	[8] = "prism_eye"
}
local v92 = {
	["shin_ketsuryugan"] = {
		3000,
		3000,
		3.4e19,
		9e25,
		1.04e35,
		6.35e45,
		3.85e56,
		2.33e67
	},
	["prism_eye"] = {
		120000000000,
		120000000000,
		3.4e19,
		9e25,
		1.04e35,
		6.35e45,
		3.85e56,
		2.33e67
	}
}
for _, v93 in v_u_3.list do
	local v94 = v92[v93.id]
	if not v94 then
		continue
	end
	v93.mults = v94
end
local v95 = require(script.Parent.Boss)
local v96 = nil
for _, v97 in v_u_3.list do
	if v97.id ~= v95.GRAND_PRIZE_LOOK then
		continue
	end
	v96 = v97
end
local v98 = v95.byId[v95.GRAND_PRIZE]
local v99, v100
if v96 and v98 then
	v_u_26[v95.GRAND_PRIZE] = 1
	local v101 = v95.GRAND_PRIZE_RECOLOR
	local v102 = v101.look == v96.id
	local v103 = v_u_3.list
	local v104 = {
		["id"] = nil,
		["name"] = nil,
		["short"] = nil,
		["rarity"] = "Mythic",
		["wins"] = 0,
		["mult"] = 1,
		["color"] = nil,
		["color2"] = nil,
		["attack"] = nil,
		["skillE"] = nil,
		["skillR"] = nil,
		["mode"] = nil,
		["blurb"] = nil,
		["update"] = 2,
		["boss"] = nil,
		["id"] = v95.GRAND_PRIZE,
		["name"] = v96.name .. " Kai",
		["short"] = v96.short .. " Kai"
	}
	local v105
	if v102 then
		v105 = v101.color
	else
		v105 = v96.color
	end
	v104.color = v105
	local v106
	if v102 then
		v106 = v101.color2
	else
		v106 = v96.color2
	end
	v104.color2 = v106
	v104.attack = v96.attack
	v104.skillE = v96.skillE
	v104.skillR = v96.skillR
	v104.mode = {
		["name"] = v96.name .. " Kai",
		["look"] = v96.mode.look
	}
	v104.blurb = "Kyubi\'s grand prize. " .. v96.blurb
	v104.boss = v98.cost
	table.insert(v103, v104)
	v99 = 1
	v100 = {
		["kanjogan"] = {
			["id"] = "kanjogan_v2",
			["share"] = 0.5
		},
		["fuma_mangekyo"] = {
			["id"] = "fuma_mangekyo_v2",
			["share"] = 0.75
		},
		["kurenai_mangekyo"] = {
			["id"] = "kurenai_mangekyo_v2",
			["share"] = 1
		},
		["grand_prize"] = {
			["id"] = "grand_prize_v2",
			["share"] = 1.3
		}
	}
else
	v99 = 1
	v100 = {
		["kanjogan"] = {
			["id"] = "kanjogan_v2",
			["share"] = 0.5
		},
		["fuma_mangekyo"] = {
			["id"] = "fuma_mangekyo_v2",
			["share"] = 0.75
		},
		["kurenai_mangekyo"] = {
			["id"] = "kurenai_mangekyo_v2",
			["share"] = 1
		},
		["grand_prize"] = {
			["id"] = "grand_prize_v2",
			["share"] = 1.3
		}
	}
end
while v99 <= #v_u_3.list do
	local v107 = v_u_3.list[v99]
	local v108 = v100[v107.id]
	if v108 then
		v107.retired = true
		local v109 = table.clone(v107)
		v109.id = v108.id
		v109.retired = nil
		v109.reissueOf = v107.id
		local v110 = v_u_3.list
		local v111 = v99 + 1
		table.insert(v110, v111, v109)
		v99 = v99 + 1
	end
	v99 = v99 + 1
end
for _, v112 in v_u_3.list do
	if v112.world ~= 5 or v112.pass then
		continue
	end
	v112.mult = v112.mult * 8
end
v_u_3.EYE_PRICE_UP = 2.5
v_u_3.LAST_EYE_PRICE_UP = 2
local v113 = {}
for _, v114 in v_u_3.list do
	local v115 = (v114.world or 1) >= 2 and not v114.pass
	if v115 then
		v115 = not v114.boss
	end
	if not v115 then
		continue
	end
	v113[v114.world] = (v113[v114.world] or 0) + 1
end
local v116 = {}
for _, v117 in v_u_3.list do
	local v118 = (v117.world or 1) >= 2 and not v117.pass
	if v118 then
		v118 = not v117.boss
	end
	if not v118 then
		continue
	end
	local v119 = v117.world
	v116[v119] = (v116[v119] or 0) + 1
	if v116[v119] < 3 then
		continue
	end
	local v120
	if v116[v119] == v113[v119] then
		v120 = v_u_3.LAST_EYE_PRICE_UP
	else
		v120 = v_u_3.EYE_PRICE_UP
	end
	v117.winsBefore = v117.wins
	local v121 = v117.wins * v120
	local v122 = math.log10(v121)
	local v123 = 10 ^ (math.floor(v122) - 1)
	local v124 = v121 / v123 + 0.5
	v117.wins = math.floor(v124) * v123
end
if v_u_1.on(2) then
	local v125 = {
		["shin_ketsuryugan"] = 7.2e26,
		["prism_eye"] = 7.2e26,
		["six_paths_sage"] = 8.8e26
	}
	for _, v126 in v_u_3.list do
		local v127 = v125[v126.id]
		if not (v127 and v126.mults) then
			continue
		end
		local v128 = table.clone(v126.mults)
		v128[4] = v127
		v126.mults = v128
	end
end
for _, v129 in v_u_3.list do
	local v130 = v_u_26[v129.id]
	if not v130 then
		continue
	end
	for _, v131 in v_u_3.list do
		if v131.id ~= "six_paths_sage" or not v131.mults then
			continue
		end
		local v132 = {}
		for v133, v134 in v131.mults do
			v132[v133] = v134 * v130
		end
		v129.mults = v132
		v129.mult = v132[1]
	end
end
v_u_3.padEyesByWorld = {}
for _, v135 in v_u_3.list do
	if v135.pass or (v135.boss or not v_u_1.on(v135.update)) then
		continue
	end
	local v136 = v135.world or 1
	local v137 = v_u_3.padEyesByWorld[v136]
	if not v137 then
		v137 = {}
		v_u_3.padEyesByWorld[v136] = v137
	end
	table.insert(v137, v135)
end
v_u_3.padEyes = v_u_3.padEyesByWorld[1]
function v_u_3.padEyesFor(p138) -- name: padEyesFor
	-- upvalues: (copy) v_u_3
	return v_u_3.padEyesByWorld[p138 or 1] or v_u_3.padEyes
end
function v_u_3.showcaseFor(p139) -- name: showcaseFor
	-- upvalues: (copy) v_u_3
	local v140 = v_u_3.PODIUM[p139 or 1]
	if v140 then
		for _, v141 in v_u_3.list do
			if v141.id ~= v140 then
				continue
			end
			return v141
		end
	end
	for _, v142 in v_u_3.list do
		if not v142.pass or (v142.everyWorld or (v142.unreleased or (v142.world or 1) ~= (p139 or 1))) then
			continue
		end
		return v142
	end
	return nil
end
function v_u_3.multIn(p143, p144) -- name: multIn
	local v145 = p143.mults
	local v146
	if v145 then
		v146 = v145[p144 or 1]
		if not v146 then
			return v145[#v145]
		end
	else
		v146 = p143.mult
	end
	return v146
end
local v147 = {}
for v148, v149 in v_u_3.padEyesByWorld do
	for _, v150 in v149 do
		local v151 = v147[v148] or 0
		local v152 = v_u_3.multIn
		v147[v148] = math.max(v151, v152(v150, v148))
	end
end
for _, v153 in v_u_3.list do
	local v154 = v100[v153.reissueOf or v153.id]
	if not v154 then
		continue
	end
	local v155 = {}
	for v156, v157 in v147 do
		v155[v156] = v157 * v154.share
	end
	v153.mults = v155
	v153.mult = v155[1]
end
function v_u_3.everyWorldShowcase() -- name: everyWorldShowcase
	-- upvalues: (copy) v_u_3
	for _, v158 in v_u_3.list do
		if not v158.pass or (not v158.everyWorld or v158.unreleased) then
			continue
		end
		return v158
	end
	return nil
end
v_u_3.byId = {}
for _, v159 in v_u_3.list do
	v_u_3.byId[v159.id] = v159
end
function v_u_3.worldOut(p160) -- name: worldOut
	-- upvalues: (copy) v_u_2
	local v161 = v_u_2[p160 or 1]
	return v161 == nil and true or v161.ready
end
function v_u_3.isOut(p162) -- name: isOut
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v163 = v_u_3.worldOut(p162.world)
	if v163 then
		v163 = v_u_1.on(p162.update)
	end
	return v163
end
function v_u_3.owns(p164, p165) -- name: owns
	local v166 = p165.reissueOf
	local v167
	if p164[p165.id] == nil then
		if v166 == nil then
			v167 = false
		else
			v167 = p164[v166] ~= nil
		end
	else
		v167 = true
	end
	return v167
end
function v_u_3.listed(p168, p169) -- name: listed
	-- upvalues: (copy) v_u_3
	if p168[p169.id] ~= nil then
		return true
	end
	local v170 = not p169.unreleased and (not p169.retired and v_u_3.isOut(p169))
	if v170 then
		v170 = not v_u_3.owns(p168, p169)
	end
	return v170
end
v_u_3.chain = {}
for v171 = 1, #v_u_3.padEyesByWorld do
	if not v_u_3.worldOut(v171) then
		continue
	end
	for _, v172 in v_u_3.padEyesByWorld[v171] do
		local v173 = v_u_3.chain
		table.insert(v173, v172)
	end
end
function v_u_3.previous(p174) -- name: previous
	-- upvalues: (copy) v_u_3
	for v175, v176 in v_u_3.chain do
		if v176.id ~= p174 then
			continue
		end
		return v_u_3.chain[v175 - 1]
	end
	return nil
end
function v_u_3.nextLocked(p177, p178) -- name: nextLocked
	-- upvalues: (copy) v_u_3
	for _, v179 in v_u_3.chain do
		if p178 and p178 < (v179.world or 1) then
			return nil
		end
		if p177[v179.id] then
			continue
		end
		return v179
	end
	return nil
end
return v_u_3