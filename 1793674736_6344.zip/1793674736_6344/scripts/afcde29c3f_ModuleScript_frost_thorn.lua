local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v2.Shared.Config.Textures)
local v_u_6 = Color3.fromRGB(16, 32, 38)
local v_u_7 = CFrame.Angles(0, 0.7853981633974483, 0)
local function v_u_20(p8, p9, p10, p11, p12) -- name: snowAura
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
	local v13 = p9.fx
	local v_u_14 = Instance.new("Attachment")
	local v15 = 0.6 * v13
	v_u_14.Position = Vector3.new(0, v15, 0)
	local v_u_16 = Instance.new("ParticleEmitter")
	v_u_16.Texture = v_u_5.Snowflake
	v_u_16.Color = ColorSequence.new(p10)
	v_u_16.LightEmission = 0.35
	v_u_16.LightInfluence = 0
	v_u_16.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.15, p12 * v13), NumberSequenceKeypoint.new(1, p12 * 0.6 * v13) })
	v_u_16.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(0.7, 0.3), NumberSequenceKeypoint.new(1, 1) })
	v_u_16.Lifetime = NumberRange.new(1.2, 2)
	v_u_16.Speed = NumberRange.new(1.2 * v13, 2.6 * v13)
	v_u_16.SpreadAngle = Vector2.new(180, 180)
	v_u_16.Rotation = NumberRange.new(0, 360)
	v_u_16.RotSpeed = NumberRange.new(-90, 90)
	v_u_16.Drag = 1.2
	local v17 = -1.2 * v13
	v_u_16.Acceleration = Vector3.new(0, v17, 0)
	v_u_16:SetAttribute("BaseRate", p11)
	v_u_16.Rate = p11 * v_u_4.formRate()
	v_u_16.Enabled = true
	v_u_16.Parent = v_u_14
	v_u_14.Parent = p9.root
	p8.own(p9, v_u_14)
	local v18 = p9.stops
	local function v19()
		-- upvalues: (copy) v_u_16, (ref) v_u_1, (copy) v_u_14
		v_u_16.Enabled = false
		v_u_1:AddItem(v_u_14, 2.2)
	end
	table.insert(v18, v19)
	return v_u_16
end
return function(p_u_21)
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_6, (copy) v_u_7, (copy) v_u_20
	return {
		["w4_frost_thorn"] = function(p_u_22, p23)
			-- upvalues: (ref) v_u_3, (copy) p_u_21, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_20
			local v_u_24 = v_u_3.color(p23.color)
			local v_u_25 = v_u_24:Lerp(Color3.new(1, 1, 1), 0.7)
			local v_u_26 = p_u_22.character:GetScale()
			local v_u_27 = nil
			local v_u_32 = p_u_21.throb(p_u_22, 3.6, 1.2, 3, function(p28)
				-- upvalues: (ref) v_u_3, (ref) p_u_21, (copy) p_u_22, (copy) v_u_24, (ref) v_u_5, (copy) v_u_26, (copy) v_u_25, (ref) v_u_27
				v_u_3.ring(p_u_21.feetAt(p_u_22, p28, 0.15), v_u_24, 5 * p_u_22.fx, 0.45, v_u_5.Ring)
				local v29 = v_u_3.flash
				local v30 = p28.Position
				local v31 = 0.4 * v_u_26
				v29(v30 + Vector3.new(0, v31, 0), v_u_25, 4 * v_u_26, 0.2)
				if v_u_27 then
					v_u_27:Emit(8)
				end
			end)
			local v33 = 2.3 * v_u_26
			local v34 = 0.42 * v_u_26
			for v_u_35 = 0, 3 do
				local v_u_48 = p_u_21.group(p_u_22, function(p36, p37)
					-- upvalues: (copy) v_u_35, (copy) v_u_32, (copy) v_u_26
					local v38 = v_u_35 * 3.141592653589793 / 2 + 0.7853981633974483 + p37 * 0.45
					local v39 = (3.8 - 0.6 * v_u_32()) * v_u_26
					local v40 = math.cos(v38)
					local v41 = math.sin(v38)
					local v42 = Vector3.new(v40, 0, v41) * v39
					local v43 = p37 * 1.8 + v_u_35 * 1.7
					local v44 = (math.sin(v43) * 0.15 + 0.35) * v_u_26
					local v45 = v42 + Vector3.new(0, v44, 0)
					local v46 = CFrame.lookAt
					local v47 = 0.2 * v_u_26
					return p36 * v46(v45, (Vector3.new(0, v47, 0))) * CFrame.Angles(-1.5707963267948966, 0, 0)
				end)
				local v49 = p_u_21.dark
				local v50 = p_u_21.bar
				local v51 = v33 * 0.62
				local v52 = v49(v50(Vector3.new(v34, v51, v34), v_u_6, 0, Enum.Material.SmoothPlastic))
				p_u_21.pin(p_u_22, v_u_48, v52, CFrame.new(0, v33 * 0.31, 0) * v_u_7)
				local v53 = p_u_21.pin
				local v54 = p_u_21.bar
				local v55 = v34 * 0.55
				local v56 = v33 * 0.45
				local v57 = v34 * 0.55
				v53(p_u_22, v_u_48, v54(Vector3.new(v55, v56, v57), v_u_25, 0), CFrame.new(0, v33 * 0.78, 0) * v_u_7)
				for _, v58 in { -1, 1 } do
					local v59 = {}
					local v60 = v33 * 0.03
					local v61 = Vector3.new(0, v60, 0)
					local v62 = v58 * v33 * 0.26
					local v63 = -v33 * 0.14
					local v64 = Vector3.new(v62, v63, 0)
					local v65 = v58 * v33 * 0.34
					local v66 = -v33 * 0.4
					__set_list(v59, 1, {v61, v64, (Vector3.new(v65, v66, 0))})
					for v67 = 1, 2 do
						local v68 = v59[v67]
						local v69 = v59[v67 + 1]
						local v70, v71 = p_u_21.between(v68, v69)
						local v72 = p_u_21.pin
						local v73 = p_u_21.dark
						local v74 = p_u_21.bar
						local v75 = v34 * 0.62
						local v76 = v34 * 0.62
						local v77 = v71 + v34 * 0.4
						v72(p_u_22, v_u_48, v73(v74(Vector3.new(v75, v76, v77), v_u_6, 0, Enum.Material.SmoothPlastic)), v70)
					end
				end
				local v_u_78 = CFrame.new(0, v33 * 0.42, 0) * v_u_7
				local v79 = p_u_21.add
				local v80 = p_u_21.bar
				local v81 = v34 * 1.9
				local v82 = v33 * 0.8
				local v83 = v34 * 1.9
				v79(p_u_22, v80(Vector3.new(v81, v82, v83), v_u_24, 0.6), p_u_21.behind(function()
					-- upvalues: (copy) v_u_48, (copy) v_u_78
					return v_u_48.cf * v_u_78
				end, 0.3 * v_u_26))
			end
			v_u_27 = v_u_20(p_u_21, p_u_22, v_u_25, 5, 0.22)
			p_u_21.particles(p_u_22, "AuraMode", v_u_24, {
				["rate"] = 0.45,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
			p_u_21.particles(p_u_22, "Petals", v_u_25, {
				["rate"] = 0.8,
				["glow"] = 0.6,
				["only"] = nil,
				["only"] = { "Motes" }
			})
		end
	}
end