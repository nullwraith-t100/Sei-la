local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(script.Parent.Sfx)
local v_u_6 = require(script.Parent.State)
local v_u_7 = require(v2.Shared.Config.Images)
local v8 = {}
local v_u_9 = v1.LocalPlayer
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = 0
local v_u_13 = false
function v8.held() -- name: held
	-- upvalues: (ref) v_u_12, (ref) v_u_13
	return v_u_12 > 0 and true or v_u_13
end
function v8.bind(p14, p15) -- name: bind
	-- upvalues: (ref) v_u_10, (ref) v_u_11
	v_u_10 = p14
	if not p15:IsA("GuiObject") then
		p15 = nil
	end
	v_u_11 = p15
end
local function v_u_18(p16) -- name: pop
	-- upvalues: (copy) v_u_4
	local v17 = p16:FindFirstChild("FlyPop")
	if not (v17 or p16:FindFirstChildOfClass("UIScale")) then
		v17 = Instance.new("UIScale")
		v17.Name = "FlyPop"
		v17.Parent = p16
	end
	if v17 and v17:IsA("UIScale") then
		v17.Scale = 1.3
		v_u_4:Create(v17, TweenInfo.new(0.15, Enum.EasingStyle.Quad), {
			["Scale"] = 1
		}):Play()
	end
end
local v_u_19 = nil
function v8.won(p20, p21) -- name: won
	-- upvalues: (ref) v_u_19
	task.spawn(v_u_19, p20, p21)
end
v_u_19 = function(p_u_22, p23)
	-- upvalues: (ref) v_u_10, (copy) v_u_6, (ref) v_u_12, (ref) v_u_11, (ref) v_u_13, (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_7, (copy) v_u_18
	local v_u_24 = v_u_10
	if p_u_22 <= 0 or not v_u_24 then
		return
	else
		local v_u_25 = p23 or v_u_6.number("KuramaCoins") + p_u_22
		local v_u_26 = v_u_25 - p_u_22
		local v_u_27 = v_u_24.shown() < v_u_25
		if v_u_27 then
			local v28 = v_u_24.shown()
			v_u_26 = math.min(v28, v_u_26)
		end
		v_u_12 = v_u_12 + p_u_22
		local v_u_29 = v_u_11
		if v_u_29 and v_u_29.Parent then
			if not v_u_29.Visible or v_u_29.AbsoluteSize.X <= 2 then
				v_u_29 = v_u_29.Parent:FindFirstChild("BossShop")
				if not (v_u_29 and (v_u_29:IsA("GuiObject") and v_u_29.Visible)) then
					v_u_29 = nil
				end
			end
		else
			v_u_29 = nil
		end
		if v_u_29 then
			v_u_13 = true
			local v30 = p_u_22 / 3
			local v31 = math.floor(v30) + 3
			local v_u_32 = math.clamp(v31, 5, 12)
			local v_u_33 = Instance.new("ScreenGui")
			v_u_33.Name = "KuramaCoinFly"
			v_u_33.DisplayOrder = 40
			v_u_33.IgnoreGuiInset = true
			v_u_33.ResetOnSpawn = false
			local v_u_34 = Instance.new("Frame")
			v_u_34.BackgroundTransparency = 1
			v_u_34.Size = UDim2.fromScale(1, 1)
			v_u_34.Parent = v_u_33
			v_u_33.Parent = v_u_9:FindFirstChildOfClass("PlayerGui")
			task.delay(v_u_32 * 0.08 + 3, function()
				-- upvalues: (copy) v_u_33
				v_u_33:Destroy()
			end)
			v_u_3.RenderStepped:Wait()
			local v35 = v_u_34.AbsolutePosition
			local v_u_36 = v_u_34.AbsoluteSize
			if v_u_36.X < 2 then
				local v37 = workspace.CurrentCamera
				if v37 then
					v_u_36 = v37.ViewportSize
				else
					v_u_36 = Vector2.new(1280, 720)
				end
			end
			local v_u_38 = Vector2.new(v_u_36.X / 2, v_u_36.Y * 0.4)
			local v_u_39 = v_u_29.AbsolutePosition + v_u_29.AbsoluteSize / 2 - v35
			local v40 = v_u_36.Y * 0.075
			local v_u_41 = math.clamp(v40, 30, 70)
			local function v_u_46() -- name: finish
				-- upvalues: (ref) v_u_12, (copy) p_u_22, (ref) v_u_13, (copy) v_u_27, (copy) v_u_24, (ref) v_u_6, (copy) v_u_25, (ref) v_u_5
				local v42 = v_u_12 - p_u_22
				v_u_12 = math.max(v42, 0)
				v_u_13 = false
				if v_u_27 then
					local v43 = v_u_24.setNow
					local v44 = v_u_6.number("KuramaCoins")
					local v45 = v_u_25
					v43((math.max(v44, v45)))
					v_u_24.badge(p_u_22)
				end
				v_u_5.play("Coin", {
					["volume"] = 0.9
				})
			end
			local v_u_47 = 0
			for v48 = 1, v_u_32 do
				task.delay((v48 - 1) * 0.08 + 0.15, function()
					-- upvalues: (ref) v_u_7, (copy) v_u_41, (copy) v_u_34, (copy) v_u_38, (copy) v_u_39, (ref) v_u_36, (ref) v_u_3, (ref) v_u_47, (copy) v_u_27, (copy) v_u_24, (ref) v_u_26, (copy) p_u_22, (copy) v_u_32, (ref) v_u_5, (ref) v_u_18, (copy) v_u_29, (copy) v_u_46
					local v_u_49 = Instance.new("ImageLabel")
					v_u_49.Name = "FlyingCoin"
					v_u_49.BackgroundTransparency = 1
					v_u_49.Image = v_u_7.Icon.KuramaCoin
					v_u_49.AnchorPoint = Vector2.new(0.5, 0.5)
					v_u_49.Size = UDim2.fromOffset(v_u_41, v_u_41)
					v_u_49.ZIndex = 50
					v_u_49.Parent = v_u_34
					local v50 = math.random() * 3.141592653589793 * 2
					local v_u_51 = v_u_38 + Vector2.new(math.cos(v50), math.sin(v50) * 0.6) * v_u_41 * (1 + math.random() * 1.2)
					local v_u_52 = (v_u_51 + v_u_39) / 2 + Vector2.new(-v_u_36.X * 0.05, -v_u_36.Y * 0.1)
					local v_u_53 = (math.random() - 0.5) * 720
					local v_u_54 = os.clock()
					local v_u_55 = nil
					v_u_55 = v_u_3.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_54, (ref) v_u_38, (copy) v_u_51, (ref) v_u_41, (copy) v_u_49, (copy) v_u_52, (ref) v_u_39, (copy) v_u_53, (ref) v_u_55, (ref) v_u_47, (ref) v_u_27, (ref) v_u_24, (ref) v_u_26, (ref) p_u_22, (ref) v_u_32, (ref) v_u_5, (ref) v_u_18, (ref) v_u_29, (ref) v_u_46
						local v56 = (os.clock() - v_u_54) / 0.85
						local v57
						if v56 < 0.25 then
							local v58 = 1 - (1 - v56 / 0.25) ^ 2
							v57 = v_u_38:Lerp(v_u_51, v58)
							local v59 = v_u_41 * (0.3 + 0.9 * v58)
							v_u_49.Size = UDim2.fromOffset(v59, v59)
						else
							local v60 = (v56 - 0.25) / 0.75
							local v61 = math.clamp(v60, 0, 1)
							local v62 = v61 * v61
							v57 = v_u_51:Lerp(v_u_52, v62):Lerp(v_u_52:Lerp(v_u_39, v62), v62)
							local v63 = v_u_41 * (1.2 - v62 * 0.55)
							v_u_49.Size = UDim2.fromOffset(v63, v63)
						end
						v_u_49.Rotation = v_u_53 * math.min(v56, 1)
						v_u_49.Position = UDim2.fromOffset(v57.X, v57.Y)
						if v56 >= 1 then
							v_u_55:Disconnect()
							v_u_49:Destroy()
							v_u_47 = v_u_47 + 1
							if v_u_27 then
								local v64 = v_u_24.setNow
								local v65 = v_u_26
								local v66 = p_u_22 * v_u_47 / v_u_32
								v64(v65 + math.floor(v66))
							end
							v_u_5.play("RouletteTick", {
								["vary"] = 0.15
							})
							v_u_18(v_u_29)
							if v_u_32 <= v_u_47 then
								v_u_46()
							end
						end
					end)
				end)
			end
			task.delay(v_u_32 * 0.08 + 4, function()
				-- upvalues: (ref) v_u_13, (ref) v_u_47, (copy) v_u_32, (copy) v_u_46
				if v_u_13 and v_u_47 < v_u_32 then
					v_u_46()
				end
			end)
		else
			local v67 = v_u_12 - p_u_22
			v_u_12 = math.max(v67, 0)
			local v68 = v_u_24.setNow
			local v69 = v_u_6.number("KuramaCoins")
			v68((math.max(v69, v_u_25)))
			v_u_24.badge(p_u_22)
		end
	end
end
return v8