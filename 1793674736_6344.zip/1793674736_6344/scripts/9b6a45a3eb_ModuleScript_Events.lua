local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Net)
local v3 = {}
local v_u_4 = {}
local v_u_5 = {}
function v3.on(p6, p7) -- name: on
	-- upvalues: (copy) v_u_4
	local v8 = v_u_4[p6]
	if not v8 then
		v8 = {}
		v_u_4[p6] = v8
	end
	table.insert(v8, p7)
end
function v3.onNotify(p9, p10) -- name: onNotify
	-- upvalues: (copy) v_u_5
	local v11 = v_u_5[p9]
	if not v11 then
		v11 = {}
		v_u_5[p9] = v11
	end
	table.insert(v11, p10)
end
function v3.fire(p12) -- name: fire
	-- upvalues: (copy) v_u_4
	local v13 = v_u_4[p12.t]
	if v13 then
		for _, v14 in v13 do
			task.spawn(v14, p12)
		end
	end
end
function v3.start() -- name: start
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_5
	v_u_2.event("Wave").OnClientEvent:Connect(function(p15)
		-- upvalues: (ref) v_u_4
		if type(p15) == "table" then
			for _, v_u_16 in p15 do
				if type(v_u_16) ~= "table" then
					continue
				end
				local v17 = v_u_16.t
				if type(v17) ~= "string" then
					continue
				end
				local v18 = v_u_4[v_u_16.t]
				if not v18 then
					continue
				end
				for _, v_u_19 in v18 do
					local v20, v21 = pcall(function()
						-- upvalues: (copy) v_u_19, (copy) v_u_16
						v_u_19(v_u_16)
					end)
					if v20 then
						continue
					end
					warn("[Events]", v_u_16.t, v21)
				end
			end
		end
	end)
	v_u_2.event("Notify").OnClientEvent:Connect(function(p22, p23)
		-- upvalues: (ref) v_u_5
		local v24 = v_u_5[p22]
		if v24 then
			for _, v25 in v24 do
				task.spawn(v25, p23)
			end
		end
	end)
end
return v3