local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({ v_u_7.LobosMuzzle, v_u_7.LobosPop, v_u_7.LobosPaw })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("8FD3FF")
local v_u_10 = Color3.fromRGB(56, 146, 255)
local v_u_11 = Color3.fromRGB(30, 82, 210)
local v_u_12 = Color3.fromRGB(14, 32, 92)
local v_u_13 = Color3.fromRGB(236, 232, 220)
local v_u_14 = Enum.Material.SmoothPlastic
local v_u_15 = Enum.PartType.Wedge
local v_u_16 = CFrame.Angles(0, 3.141592653589793, 0) * CFrame.Angles(0.8726646259971648, 0, 0)
local function v_u_25(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_4
	local v22 = v_u_4.part(Vector3.new(p18, 0.05, p18), p17, p20, {
		["transparency"] = 1
	})
	for _, v23 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p19
		v24.Color3 = p20
		v24.Transparency = p21
		v24.Parent = v22
	end
	return v22
end
local function v_u_33(p26) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v27 = v_u_2:FindFirstChild("EyePieces")
	if v27 then
		v27 = v27:FindFirstChild("w7_los_lobos")
	end
	if not (v27 and v27:IsA("MeshPart")) then
		return nil
	end
	local v28 = v27:Clone()
	local v29 = v27.Size
	local v30 = v27.Size.X
	local v31 = v27.Size.Y
	local v32 = v27.Size.Z
	v28.Size = v29 * (p26 / math.max(v30, v31, v32, 0.01))
	v28.Anchored = true
	v28.CanCollide = false
	v28.CanQuery = false
	v28.CanTouch = false
	v28.Massless = true
	v28.CastShadow = false
	v28.Parent = v_u_4.folder()
	return v28
end
local function v_u_66(p34, p35, p36, p37, p38, p39, p40, p41, p42, p43, p44) -- name: floorPic
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v45 = p40 + p41 + p42
	local v46 = math.max(v45, 0.05)
	local v47 = {}
	local v48 = {}
	for v49 = 0, 10 do
		local v50 = v49 / 10
		local v51 = v50 * v46
		local v52 = v51 / math.max(p40, 0.001)
		local v53 = 1 - (1 - math.clamp(v52, 0, 1)) ^ 3
		local v54 = (v51 - p40 - p41) / math.max(p42, 0.001)
		local v55 = math.clamp(v54, 0, 1)
		local v56 = v55 * v55 * (3 - v55 * 2)
		local v57 = NumberSequenceKeypoint.new
		local v58 = p35 + (p36 - p35) * v53
		local v59 = math.max(v58, 0.05) / 2
		table.insert(v48, v57(v50, v59))
		local v60 = NumberSequenceKeypoint.new
		local v61 = p39 + (1 - p39) * v56
		local v62 = math.clamp(v61, 0, 1)
		table.insert(v47, v60(v50, v62))
	end
	local v63 = Instance.new("Attachment")
	v63.WorldCFrame = CFrame.new(p34)
	v63.Parent = v_u_3.Terrain
	local v64 = Instance.new("ParticleEmitter")
	v64.Enabled = false
	v64.Texture = p37
	v64.Color = ColorSequence.new(p38)
	v64.LightEmission = p44 or 0
	v64.LightInfluence = 0
	v64.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v64.EmissionDirection = Enum.NormalId.Top
	v64.SpreadAngle = Vector2.zero
	v64.Speed = NumberRange.new(0.01)
	v64.Size = NumberSequence.new(v48)
	v64.Transparency = NumberSequence.new(v47)
	v64.Lifetime = NumberRange.new(v46)
	local v65 = p43 or math.random(0, 359)
	v64.Rotation = NumberRange.new(v65, v65)
	v64.Parent = v63
	v64:Emit(1)
	v_u_1:AddItem(v63, v46 + 0.2)
end
local function v_u_74(p67, p68, p69, p70, p71) -- name: ceroPop
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_1
	local v72 = Instance.new("Attachment")
	v72.WorldPosition = p67
	v72.Parent = v_u_3.Terrain
	local v73 = Instance.new("ParticleEmitter")
	v73.Enabled = false
	v73.Texture = v_u_7.LobosPop
	v73.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
	v73.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
	v73.Color = ColorSequence.new(p69)
	v73.LightEmission = p71 or 0.35
	v73.LightInfluence = 0
	v73.Lifetime = NumberRange.new(p70)
	v73.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p68 * 0.25), NumberSequenceKeypoint.new(0.3, p68 * 0.5), NumberSequenceKeypoint.new(1, p68 * 0.6) })
	v73.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0.1), NumberSequenceKeypoint.new(1, 1) })
	v73.Speed = NumberRange.new(0)
	v73.Rotation = NumberRange.new(0, 360)
	v73.Parent = v72
	v73:Emit(1)
	v_u_1:AddItem(v72, p70 + 0.2)
end
local function v_u_82(p75, p76, p77, p78, p79) -- name: wisps
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_1
	local v80 = Instance.new("Attachment")
	v80.WorldPosition = p75
	v80.Parent = v_u_3.Terrain
	local v81 = Instance.new("ParticleEmitter")
	v81.Enabled = false
	v81.Texture = v_u_7.FxSmoke
	v81.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
	v81.FlipbookMode = Enum.ParticleFlipbookMode.Random
	v81.Color = ColorSequence.new(v_u_9, v_u_10)
	v81.LightEmission = 0.45
	v81.LightInfluence = 0
	v81.Lifetime = NumberRange.new(p79 * 0.6, p79)
	v81.Size = NumberSequence.new(p77 * 0.5, p77)
	v81.Transparency = NumberSequence.new(0.2, 1)
	v81.Speed = NumberRange.new(p78 * 0.4, p78)
	v81.Drag = 3
	v81.SpreadAngle = Vector2.new(180, 180)
	v81.Rotation = NumberRange.new(0, 360)
	v81.RotSpeed = NumberRange.new(-90, 90)
	v81.Parent = v80
	v81:Emit(p76)
	v_u_1:AddItem(v80, p79 + 0.2)
end
local function v_u_99(p83, p84, p85, p86, p87) -- name: muzzleBlast
	-- upvalues: (copy) v_u_25, (copy) v_u_7, (copy) v_u_4, (copy) v_u_1
	local v88 = p84.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or p84.Unit
	local v89 = v88:Cross(Vector3.new(0, 1, 0))
	local v90 = v89.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v89.Unit
	for _, v91 in { v90:Cross(v88).Unit, v90 } do
		local v92 = v88:Cross(v91).Unit
		local v93 = v_u_25(CFrame.fromMatrix(p83 + v88 * p85 * 0.42, v88, v91, v92), p85, v_u_7.LobosMuzzle, p86, 0)
		local v94 = v_u_4.tween
		local v95 = {}
		local v96 = p85 * 1.25
		local v97 = p85 * 1.25
		v95.Size = Vector3.new(v96, 0.05, v97)
		v94(v93, p87, v95)
		for _, v98 in v93:GetChildren() do
			if not v98:IsA("Decal") then
				continue
			end
			v_u_4.tween(v98, p87, {
				["Transparency"] = 1
			}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
		end
		v_u_1:AddItem(v93, p87 + 0.05)
	end
end
local function v_u_112(p100, p101, p102) -- name: bullet
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_10, (copy) v_u_1, (copy) v_u_11, (copy) v_u_12
	local v103 = v_u_4.part(Vector3.new(0.3, 0.3, 1.9) * p101, p100, v_u_8)
	local v104 = v_u_4.part(Vector3.new(0.52, 0.52, 2.3) * p101, p100, v_u_10, {
		["transparency"] = 0.35
	})
	local v105 = v_u_4.part(Vector3.new(0.7, 0.7, 0.7) * p101, p100, v_u_10, {
		["shape"] = nil,
		["transparency"] = 0.2,
		["shape"] = Enum.PartType.Ball
	})
	for _, v106 in { v103, v104, v105 } do
		v_u_1:AddItem(v106, 3)
	end
	local v107 = Instance.new("Attachment")
	local v108 = p101 * 0.2
	v107.Position = Vector3.new(0, v108, 0)
	v107.Parent = v103
	local v109 = Instance.new("Attachment")
	local v110 = p101 * -0.2
	v109.Position = Vector3.new(0, v110, 0)
	v109.Parent = v103
	local v111 = Instance.new("Trail")
	v111.Attachment0 = v107
	v111.Attachment1 = v109
	v111.Color = ColorSequence.new(v_u_11, v_u_12)
	v111.Transparency = NumberSequence.new(0.1, 1)
	v111.WidthScale = NumberSequence.new(1, 0.2)
	v111.Lifetime = p102 and 0.1 or 0.16
	v111.LightEmission = 0
	v111.LightInfluence = 0
	v111.FaceCamera = true
	v111.MinLength = 0.05
	v111.Parent = v103
	return {
		["core"] = v103,
		["head"] = v105,
		["body"] = v104
	}
end
local function v_u_116(p113, p114) -- name: placeBullet
	local v115 = p113.core.Size.Z
	p113.core.CFrame = p114
	p113.body.CFrame = p114 * CFrame.new(0, 0, v115 * 0.1)
	p113.head.CFrame = p114 * CFrame.new(0, 0, -v115 * 0.45)
end
local function v_u_120(p117, p118, p119) -- name: landPop
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_10, (copy) v_u_74, (copy) v_u_12
	v_u_4.flash(p117, v_u_8, p118 * 2.6, 0.12)
	v_u_4.flash(p117, v_u_10, p118 * 4.4, 0.22)
	v_u_74(p117, p118 * 6, v_u_10, 0.35)
	if not p119 then
		v_u_74(p117, p118 * 4.5, v_u_12, 0.3, 0)
	end
end
return function(p_u_121)
	-- upvalues: (copy) v_u_4, (copy) v_u_12, (copy) v_u_7, (copy) v_u_66, (copy) v_u_11, (copy) v_u_13, (copy) v_u_9, (copy) v_u_10, (copy) v_u_99, (copy) v_u_8, (copy) v_u_112, (copy) v_u_116, (copy) v_u_1, (copy) v_u_120, (copy) v_u_74, (copy) v_u_15, (copy) v_u_14, (copy) v_u_33, (copy) v_u_25, (copy) v_u_16, (copy) v_u_3, (copy) v_u_82, (copy) v_u_6
	local v122 = {}
	local function v_u_129(p123, p124, p125, p126) -- name: scorch
		-- upvalues: (copy) p_u_121, (ref) v_u_4, (ref) v_u_12, (ref) v_u_7, (ref) v_u_66, (ref) v_u_11, (ref) v_u_13, (ref) v_u_9
		local v127 = p_u_121.ground(p123, 0.12)
		local v128 = p126 and 1.7 or 1
		v_u_4.ring(v127, v_u_12, p124 * 3.6 * v128, 0.3, v_u_7.Ring)
		if not p125 then
			v_u_66(v127, p124 * 1, p124 * 4 * v128, v_u_7.Glow, v_u_11, 0.3, 0.08, 0.3, 0.7, nil, 0)
			p_u_121.chunks(v127 + Vector3.new(0, 0.4, 0), { v_u_13, v_u_9 }, p126 and 4 or 2, v128 * 16, p124 * 0.4, 0.6, false, 0.9)
		end
	end
	v122.los_lobos_a = {
		["cast"] = function(p130) -- name: cast
			-- upvalues: (ref) v_u_99, (ref) v_u_10, (ref) v_u_4, (ref) v_u_8
			local v131 = p130.size
			local v132 = p130.dir:Cross(Vector3.new(0, 1, 0))
			for _, v133 in { -1, 1 } do
				local v134 = p130.eye - Vector3.new(0, 0.8, 0) + v132 * v133 * 0.9 * v131 + p130.dir * 0.9
				v_u_99(v134, p130.dir, 2.6 * v131, v_u_10, 0.12)
				if p130.lite then
					continue
				end
				v_u_4.flash(v134, v_u_8, 1.2 * v131, 0.08)
			end
		end,
		["shot"] = function(p135, p136) -- name: shot
			-- upvalues: (ref) v_u_112, (ref) v_u_116, (ref) v_u_1
			local v_u_137 = p135.size
			local v138 = (p135.target - p135.eye).Magnitude / (p135.ability.speed or 200)
			local v_u_139 = math.max(v138, 0.05)
			local v_u_140 = v_u_112(p136, v_u_137, p135.lite)
			local v_u_141 = v_u_112(p136, v_u_137, p135.lite)
			local v_u_142 = false
			return {
				["place"] = function(p143, p144) -- name: place
					-- upvalues: (copy) v_u_139, (copy) v_u_137, (ref) v_u_116, (copy) v_u_140, (copy) v_u_141
					local v145 = p144 / v_u_139
					local v146 = math.clamp(v145, 0, 1)
					local v147 = 0.9 * v_u_137 * (1 - v146) ^ 1.4
					local v148 = -0.8 * v_u_137 * (1 - v146)
					v_u_116(v_u_140, p143 * CFrame.new(-v147, v148, 0))
					v_u_116(v_u_141, p143 * CFrame.new(v147, v148, 0))
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_142, (copy) v_u_140, (ref) v_u_1, (copy) v_u_141
					if not v_u_142 then
						v_u_142 = true
						local v149 = v_u_140
						v149.head:Destroy()
						v149.body:Destroy()
						v149.core.Transparency = 1
						v_u_1:AddItem(v149.core, 0.3)
						local v150 = v_u_141
						v150.head:Destroy()
						v150.body:Destroy()
						v150.core.Transparency = 1
						v_u_1:AddItem(v150.core, 0.3)
					end
				end
			}
		end,
		["impact"] = function(p151, p_u_152) -- name: impact
			-- upvalues: (ref) v_u_120, (copy) p_u_121, (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_74, (ref) v_u_12, (ref) v_u_7
			local v_u_153 = p151.size
			local v_u_154 = p151.dir:Cross(Vector3.new(0, 1, 0))
			v_u_120(p_u_152 + v_u_154 * 0.5, v_u_153, p151.lite)
			if not p151.lite then
				p_u_121.after(0.05, function()
					-- upvalues: (copy) p_u_152, (copy) v_u_154, (copy) v_u_153, (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_74
					local v155 = p_u_152 - v_u_154 * 0.5 + Vector3.new(0, 0.3, 0)
					local v156 = v_u_153 * 0.8
					v_u_4.flash(v155, v_u_8, v156 * 2.6, 0.12)
					v_u_4.flash(v155, v_u_10, v156 * 4.4, 0.22)
					v_u_74(v155, v156 * 6, v_u_10, 0.35)
				end)
				p_u_121.spikes(p_u_152, v_u_10, 4, 4 * v_u_153, 0.18)
			end
			v_u_4.ring(p_u_121.ground(p_u_152, 0.12), v_u_12, p151.ability.radius * 0.6 * v_u_153, 0.25, v_u_7.Ring)
			p_u_121.hitSound(p_u_152)
		end,
		["hit"] = function(_, p157, _) -- name: hit
			-- upvalues: (copy) p_u_121, (ref) v_u_10
			p_u_121.burst("Impact", p157, v_u_10, 0.6)
		end
	}
	local function v_u_180(p158) -- name: partsWolf
		-- upvalues: (ref) v_u_1, (ref) v_u_4, (ref) v_u_9, (ref) v_u_8, (ref) v_u_15, (ref) v_u_14, (ref) v_u_10, (ref) v_u_12
		local v159 = {
			["parts"] = {},
			["offs"] = {}
		}
		local v160 = v_u_4.part(Vector3.new(1.3, 1.1, 1.3) * p158, CFrame.identity, v_u_9, {
			["shape"] = Enum.PartType.Ball
		})
		local v161 = CFrame.identity
		v_u_1:AddItem(v160, 4)
		local v162 = v159.parts
		table.insert(v162, v160)
		local v163 = v159.offs
		table.insert(v163, v161)
		local v164 = {
			["shape"] = v_u_15,
			["material"] = v_u_14
		}
		local v165 = v_u_4.part(Vector3.new(0.7, 0.6, 1.2) * p158, CFrame.identity, v_u_8, v164)
		local v166 = CFrame.new(0, p158 * -0.15, p158 * -0.95) * CFrame.Angles(0, 3.141592653589793, 0)
		v_u_1:AddItem(v165, 4)
		local v167 = v159.parts
		table.insert(v167, v165)
		local v168 = v159.offs
		table.insert(v168, v166)
		for _, v169 in { -1, 1 } do
			local v170 = {
				["shape"] = v_u_15
			}
			local v171 = v_u_4.part(Vector3.new(0.2, 0.7, 0.45) * p158, CFrame.identity, v_u_10, v170)
			local v172 = CFrame.new(v169 * 0.38 * p158, p158 * 0.7, p158 * 0.1) * CFrame.Angles(0, 0, v169 * -0.25)
			v_u_1:AddItem(v171, 4)
			local v173 = v159.parts
			table.insert(v173, v171)
			local v174 = v159.offs
			table.insert(v174, v172)
			local v175 = {
				["material"] = v_u_14
			}
			local v176 = v_u_4.part(Vector3.new(0.16, 0.12, 0.08) * p158, CFrame.identity, v_u_12, v175)
			local v177 = CFrame.new(v169 * 0.3 * p158, p158 * 0.15, p158 * -0.6)
			v_u_1:AddItem(v176, 4)
			local v178 = v159.parts
			table.insert(v178, v176)
			local v179 = v159.offs
			table.insert(v179, v177)
		end
		return v159
	end
	v122.los_lobos_e = {
		["cast"] = nil,
		["shot"] = nil,
		["weave"] = 0.6,
		["impact"] = nil,
		["hit"] = nil,
		["cast"] = function(p_u_181) -- name: cast
			-- upvalues: (copy) p_u_121, (ref) v_u_10, (ref) v_u_66, (ref) v_u_7, (ref) v_u_99
			p_u_121.skillCast(p_u_181, v_u_10, false, true)
			local v_u_182 = p_u_181.size
			if not p_u_181.lite then
				for v183 = 1, 6 do
					local v184 = v183 / 6 * 3.141592653589793 * 2 + math.random() * 0.4
					local v185 = math.cos(v184)
					local v186 = math.sin(v184)
					local v_u_187 = Vector3.new(v185, 0, v186)
					p_u_121.after(v183 * 0.025, function()
						-- upvalues: (copy) p_u_181, (copy) v_u_187, (copy) v_u_182, (ref) v_u_66, (ref) p_u_121, (ref) v_u_7, (ref) v_u_10
						local v188 = p_u_181.feet + v_u_187 * 2.6 * v_u_182
						local v189 = v_u_187
						local v190 = 1.5 * v_u_182
						local v191 = v189.X
						local v192 = v189.Z
						local v193 = math.atan2(v191, v192)
						local v194 = math.deg(v193) + 0
						v_u_66(p_u_121.ground(v188, 0.1), v190 * 0.7, v190, v_u_7.LobosPaw, v_u_10, 0.05, 0.06, 0.4, 0.6, v194, 0.15)
					end)
				end
			end
			v_u_99(p_u_181.eye + p_u_181.dir * 0.8, p_u_181.dir, 3.4 * v_u_182, v_u_10, 0.16)
		end,
		["shot"] = function(p_u_195, p196) -- name: wolfShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_33, (ref) v_u_9, (copy) v_u_180, (ref) v_u_25, (ref) v_u_7, (ref) v_u_10, (ref) v_u_11, (copy) p_u_121, (ref) v_u_16, (ref) v_u_3, (ref) v_u_66
			local v_u_197 = p_u_195.size
			local v_u_198 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p196, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_198, 4)
			local v_u_199
			if p_u_195.lite then
				v_u_199 = nil
			else
				v_u_199 = v_u_33(2.7 * v_u_197)
			end
			local v_u_200 = nil
			if v_u_199 then
				local v201 = v_u_199:FindFirstChildWhichIsA("SurfaceAppearance")
				if v201 then
					v201.Color = Color3.fromRGB(150, 205, 255)
				else
					v_u_199.Color = v_u_9
					v_u_199.Material = Enum.Material.Neon
				end
				v_u_1:AddItem(v_u_199, 4)
			else
				v_u_200 = v_u_180(v_u_197)
			end
			local v_u_202 = v_u_25(p196, 5 * v_u_197, v_u_7.Glow, v_u_10, 0.15)
			v_u_1:AddItem(v_u_202, 4)
			local v203 = Instance.new("Attachment")
			local v204 = 0.9 * v_u_197
			local v205 = 0.3 * v_u_197
			v203.Position = Vector3.new(0, v204, v205)
			v203.Parent = v_u_198
			local v206 = Instance.new("Attachment")
			local v207 = -0.6 * v_u_197
			local v208 = 0.3 * v_u_197
			v206.Position = Vector3.new(0, v207, v208)
			v206.Parent = v_u_198
			local v_u_209 = Instance.new("Trail")
			v_u_209.Attachment0 = v203
			v_u_209.Attachment1 = v206
			v_u_209.Color = ColorSequence.new(v_u_9, v_u_11)
			v_u_209.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.1), NumberSequenceKeypoint.new(0.6, 0.55), NumberSequenceKeypoint.new(1, 1) })
			v_u_209.WidthScale = NumberSequence.new(1, 0.1)
			v_u_209.Lifetime = p_u_195.lite and 0.15 or 0.3
			v_u_209.LightEmission = 0.4
			v_u_209.LightInfluence = 0
			v_u_209.FaceCamera = true
			v_u_209.Parent = v_u_198
			local v_u_210
			if p_u_195.lite then
				v_u_210 = nil
			else
				v_u_210 = Instance.new("ParticleEmitter")
				v_u_210.Texture = v_u_7.FxSmoke
				v_u_210.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
				v_u_210.FlipbookMode = Enum.ParticleFlipbookMode.Random
				v_u_210.Color = ColorSequence.new(v_u_9, v_u_10)
				v_u_210.LightEmission = 0.4
				v_u_210.LightInfluence = 0
				v_u_210.Lifetime = NumberRange.new(0.3, 0.45)
				v_u_210.Size = NumberSequence.new(0.9 * v_u_197, 0.2)
				v_u_210.Transparency = NumberSequence.new(0.35, 1)
				v_u_210.Speed = NumberRange.new(0.5, 2)
				v_u_210.SpreadAngle = Vector2.new(180, 180)
				v_u_210.Rate = 34
				v_u_210.Parent = v_u_198
			end
			local v_u_211 = 0
			local v_u_212 = 0
			local v_u_213 = false
			return {
				["place"] = function(p214, p215) -- name: place
					-- upvalues: (copy) v_u_197, (ref) p_u_121, (copy) v_u_198, (copy) v_u_199, (ref) v_u_16, (ref) v_u_200, (ref) v_u_3, (copy) v_u_202, (copy) p_u_195, (ref) v_u_211, (ref) v_u_212, (ref) v_u_66, (ref) v_u_7, (ref) v_u_10
					local v216 = p215 * 13
					local v217 = math.sin(v216)
					local v218 = math.abs(v217)
					local v219 = p214.Position + Vector3.new(0, 1, 0) * (v218 * 0.9 - 0.4) * v_u_197
					local v220 = p_u_121.flatUnit(p214.LookVector)
					local v221 = CFrame.lookAt(v219, v219 + v220)
					local v222 = CFrame.Angles
					local v223 = p215 * 13
					local v224 = v221 * v222(math.cos(v223) * 0.12, 0, 0)
					v_u_198.CFrame = v224
					if v_u_199 then
						v_u_199.CFrame = v224 * v_u_16
					else
						local v225 = v_u_200
						if v225 then
							for v226, v227 in v225.parts do
								v227.CFrame = v224 * v225.offs[v226]
							end
						end
					end
					local v228 = v_u_3.CurrentCamera
					local v229
					if v228 then
						local v230 = v228.CFrame.Position - v219
						v229 = v230.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v230.Unit
					else
						v229 = Vector3.new(0, 0, 1)
					end
					v_u_202.CFrame = p_u_121.facing(v219 - v229 * 0.6, v229)
					if not p_u_195.lite and p215 - v_u_211 > 0.09 then
						v_u_211 = p215
						v_u_212 = v_u_212 + 1
						local v231 = v219 + v221.RightVector * (v_u_212 % 2 == 0 and 0.45 or -0.45) * v_u_197
						local v232 = 1.6 * v_u_197
						local v233 = v220.X
						local v234 = v220.Z
						local v235 = math.atan2(v233, v234)
						local v236 = math.deg(v235) + 0
						v_u_66(p_u_121.ground(v231, 0.1), v232 * 0.7, v232, v_u_7.LobosPaw, v_u_10, 0.05, 0.06, 0.5, 0.6, v236, 0.15)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_213, (copy) v_u_209, (ref) v_u_210, (ref) v_u_1, (copy) v_u_198, (copy) v_u_202, (copy) v_u_199, (ref) v_u_200
					if not v_u_213 then
						v_u_213 = true
						v_u_209.Enabled = false
						local v237 = v_u_210
						if v237 then
							v237.Enabled = false
						end
						v_u_1:AddItem(v_u_198, 0.5)
						v_u_202:Destroy()
						if v_u_199 then
							v_u_199:Destroy()
						end
						local v238 = v_u_200
						if v238 then
							for _, v239 in v238.parts do
								v239:Destroy()
							end
						end
					end
				end
			}
		end,
		["impact"] = function(p240, p241) -- name: impact
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_74, (ref) v_u_12, (ref) v_u_82, (copy) v_u_129, (copy) p_u_121
			local v242 = p240.size
			v_u_4.flash(p241, v_u_8, 4 * v242, 0.14)
			v_u_4.flash(p241, v_u_10, 8 * v242, 0.3)
			v_u_74(p241, 10 * v242, v_u_10, 0.4)
			if not p240.lite then
				v_u_74(p241 + Vector3.new(0, 0.3, 0), 7 * v242, v_u_12, 0.35, 0)
				v_u_82(p241, 10, 2.2 * v242, 18 * v242, 0.6)
			end
			v_u_129(p241, v242, p240.lite, true)
			p_u_121.hitSound(p241, not p240.lite)
		end,
		["hit"] = function(_, p243, _) -- name: hit
			-- upvalues: (copy) p_u_121, (ref) v_u_10
			p_u_121.burst("Impact", p243, v_u_10, 0.8)
		end
	}
	local v_u_244 = CFrame.new(0, 0.1, -2.3)
	local function v_u_247(p245) -- name: makeGun
		-- upvalues: (copy) p_u_121, (ref) v_u_12, (ref) v_u_14, (ref) v_u_10, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9
		local v246 = p_u_121.newRig()
		p_u_121.rigAdd(v246, Vector3.new(0.5, 0.62, 1.3), CFrame.new(0, 0, 0.2), v_u_12, 0, v_u_14, p245)
		p_u_121.rigAdd(v246, Vector3.new(0.36, 0.36, 1.9), CFrame.new(0, 0.1, -1.1), v_u_10, 0, nil, p245)
		p_u_121.rigAdd(v246, Vector3.new(0.18, 0.18, 2.1), CFrame.new(0, 0.1, -1.15), v_u_8, 0, nil, p245)
		p_u_121.rigAdd(v246, Vector3.new(0.12, 0.16, 0.3), CFrame.new(0, 0.42, -1.8), v_u_8, 0, nil, p245)
		p_u_121.rigAdd(v246, Vector3.new(0.4, 1.1, 0.5), CFrame.new(0, -0.55, 0.65) * CFrame.Angles(-0.35, 0, 0), v_u_11, 0, v_u_14, p245)
		p_u_121.rigAdd(v246, Vector3.new(0.58, 0.58, 0.5), CFrame.new(0, 0.05, -0.3), v_u_9, 0, nil, p245)
		return v246
	end
	local v_u_248 = {}
	local v_u_249 = {}
	local function v_u_258(p250, p_u_251, p_u_252, p253, p_u_254) -- name: tracer
		-- upvalues: (ref) v_u_112, (copy) p_u_121, (ref) v_u_116, (ref) v_u_1
		local v_u_255 = v_u_112(CFrame.lookAt(p_u_251, p_u_252), p250.size * 0.8, p250.lite)
		p_u_121.animate(p253, 0, function(p256)
			-- upvalues: (ref) v_u_116, (copy) v_u_255, (copy) p_u_251, (copy) p_u_252, (ref) v_u_1, (copy) p_u_254
			v_u_116(v_u_255, CFrame.lookAt(p_u_251:Lerp(p_u_252, p256), p_u_252 + (p_u_252 - p_u_251).Unit))
			if p256 >= 1 then
				local v257 = v_u_255
				v257.head:Destroy()
				v257.body:Destroy()
				v257.core.Transparency = 1
				v_u_1:AddItem(v257.core, 0.3)
				p_u_254()
			end
		end)
	end
	v122.los_lobos_r = {
		["cast"] = function(p259) -- name: cast
			-- upvalues: (copy) p_u_121, (ref) v_u_10
			p_u_121.skillCast(p259, v_u_10, true, true)
		end,
		["windup"] = function(p_u_260, p261, p262) -- name: windup
			-- upvalues: (copy) p_u_121, (copy) v_u_247, (ref) v_u_4, (ref) v_u_10, (ref) v_u_82, (copy) v_u_248, (copy) v_u_249, (ref) v_u_12, (ref) v_u_7, (ref) v_u_66
			local v_u_263 = p_u_260.size
			local v264 = p_u_260.ability.radius * v_u_263
			local v_u_265 = p262 + 0.6
			local v_u_266 = p_u_260.dir:Cross(Vector3.new(0, 1, 0))
			local v_u_267 = p_u_121.ground(p261, 1.5)
			local v_u_268 = {}
			for _, v269 in { -1, 1 } do
				local v270 = p_u_260.eye - Vector3.new(0, 0.4, 0) + v_u_266 * v269 * 2 * v_u_263 - p_u_260.dir * 0.3
				local v271 = {
					["rig"] = nil,
					["kick"] = 0,
					["frame"] = nil,
					["rig"] = v_u_247(v_u_265 + 0.5),
					["frame"] = CFrame.lookAt(v270, v_u_267)
				}
				table.insert(v_u_268, v271)
				v_u_4.flash(v270, v_u_10, 3 * v_u_263, 0.25)
				if p_u_260.lite then
					continue
				end
				v_u_82(v270, 5, 1 * v_u_263, 5 * v_u_263, 0.4)
			end
			v_u_248[p_u_260] = v_u_268
			local v_u_272 = os.clock()
			local v_u_273 = v_u_272
			p_u_121.frame(function()
				-- upvalues: (copy) v_u_272, (ref) v_u_273, (copy) p_u_260, (copy) v_u_268, (copy) v_u_266, (copy) v_u_263, (copy) v_u_267, (ref) p_u_121, (copy) v_u_265, (ref) v_u_4, (ref) v_u_10, (ref) v_u_82, (ref) v_u_248, (ref) v_u_249
				local v274 = os.clock()
				local v275 = v274 - v_u_272
				local v276 = v274 - v_u_273
				v_u_273 = v274
				local v277 = p_u_260.caster
				if v277 then
					v277 = p_u_260.caster.Character
				end
				if v277 then
					v277 = v277:FindFirstChild("Head")
				end
				local v278
				if v277 and v277:IsA("BasePart") then
					v278 = v277.Position + Vector3.new(0, 0.15, 0)
				else
					v278 = p_u_260.eye
				end
				local v279 = v275 / 0.22
				local v280 = 1 - (1 - math.clamp(v279, 0, 1)) ^ 3
				for v281, v282 in v_u_268 do
					local v283 = v281 == 1 and -1 or 1
					local v284 = v278 - Vector3.new(0, 0.4, 0) + v_u_266 * v283 * 2 * v_u_263 - p_u_260.dir * 0.3
					v282.frame = CFrame.lookAt(v284, v_u_267)
					local v285 = v282.kick - v276 * 12
					v282.kick = math.max(v285, 0)
					p_u_121.rigPlace(v282.rig, v282.frame * CFrame.new(0, v282.kick * 0.25 * v_u_263, v282.kick * 0.6 * v_u_263) * CFrame.Angles(v282.kick * 0.5, 0, (1 - v280) * 3.141592653589793 * 2 * v283), 1.3 * v_u_263 * math.max(v280, 0.05))
				end
				if v_u_265 > v275 then
					return true
				end
				for _, v286 in v_u_268 do
					local v287 = v286.frame.Position
					v_u_4.flash(v287, v_u_10, 3 * v_u_263, 0.2)
					if not p_u_260.lite then
						v_u_82(v287, 6, 1.2 * v_u_263, 8 * v_u_263, 0.5)
					end
					p_u_121.rigDestroy(v286.rig)
				end
				v_u_248[p_u_260] = nil
				v_u_249[p_u_260] = nil
				return false
			end)
			p_u_121.sigil(CFrame.new(p_u_121.ground(p261, 0.12)), v264, v_u_12, v_u_7.Ring, p262 + 0.2, 0)
			if not p_u_260.lite then
				v_u_66(p_u_121.ground(p261, 0.1), v264, v264 * 1.9, v_u_7.Glow, v_u_10, 0.6, 0.2, p262, 0.3, nil, 0.2)
			end
		end,
		["strike"] = function(p_u_288, p289, p290) -- name: strike
			-- upvalues: (copy) v_u_249, (copy) v_u_248, (copy) v_u_244, (ref) v_u_99, (ref) v_u_10, (copy) v_u_258, (ref) v_u_120, (copy) v_u_129, (ref) v_u_6, (ref) v_u_4, (copy) p_u_121, (ref) v_u_12, (ref) v_u_7
			local v_u_291 = p_u_288.size
			local function v_u_299(p_u_292, p_u_293) -- name: fire
				-- upvalues: (ref) v_u_249, (copy) p_u_288, (ref) v_u_248, (ref) v_u_244, (ref) v_u_99, (copy) v_u_291, (ref) v_u_10, (ref) v_u_258, (ref) v_u_120, (ref) v_u_129, (ref) v_u_6, (ref) v_u_4, (ref) p_u_121, (ref) v_u_12, (ref) v_u_7
				local v_u_294 = (v_u_249[p_u_288] or 0) + 1
				v_u_249[p_u_288] = v_u_294
				local v295 = v_u_248[p_u_288]
				local v296
				if v295 then
					v296 = v295[v_u_294 % #v295 + 1]
				else
					v296 = nil
				end
				local v297
				if v296 then
					v297 = (v296.frame * v_u_244).Position
				else
					v297 = p_u_288.eye
				end
				if v296 then
					v296.kick = 1
					v_u_99(v297, p_u_292 - v297, 2.2 * v_u_291, v_u_10, 0.08)
				end
				v_u_258(p_u_288, v297, p_u_292, 0.1, function()
					-- upvalues: (copy) p_u_293, (ref) v_u_120, (copy) p_u_292, (ref) v_u_291, (ref) p_u_288, (ref) v_u_129, (copy) v_u_294, (ref) v_u_6, (ref) v_u_4, (ref) v_u_10, (ref) p_u_121, (ref) v_u_12, (ref) v_u_7
					if p_u_293 then
						v_u_120(p_u_292, v_u_291 * 1.35, p_u_288.lite)
						v_u_129(p_u_292, v_u_291 * 1.2, p_u_288.lite)
						if p_u_288.mine and v_u_294 % 3 == 0 then
							local v298 = {
								["at"] = nil,
								["volume"] = 0.35,
								["at"] = p_u_292
							}
							v_u_6.play("Hit", v298)
							return
						end
					else
						v_u_4.flash(p_u_292, v_u_10, 2.4 * v_u_291, 0.14)
						v_u_4.ring(p_u_121.ground(p_u_292, 0.12), v_u_12, 1.8 * v_u_291, 0.22, v_u_7.Ring)
					end
				end)
			end
			local v_u_300 = p_u_121.ground(p289, 0.6)
			local v301 = p_u_121.after
			local v302 = p290 - 0.1
			v301(math.max(v302, 0), function()
				-- upvalues: (copy) v_u_299, (copy) v_u_300
				v_u_299(v_u_300, true)
			end)
			if not p_u_288.lite then
				for v303 = 1, 3 do
					local v304 = math.random() * 3.141592653589793 * 2
					local v305 = p_u_288.ability.radius * v_u_291 * 0.6
					local v306 = math.random()
					local v307 = v305 * math.sqrt(v306)
					local v308 = p_u_121.ground
					local v309 = math.cos(v304) * v307
					local v310 = math.sin(v304) * v307
					local v_u_311 = v308(p289 + Vector3.new(v309, 0, v310), 0.6)
					local v312 = p_u_121.after
					local v313 = p290 - 0.1 + v303 * 0.035
					v312(math.max(v313, 0), function()
						-- upvalues: (copy) v_u_299, (copy) v_u_311
						v_u_299(v_u_311, false)
					end)
				end
			end
		end,
		["hit"] = function(_, p314, _) -- name: hit
			-- upvalues: (copy) p_u_121, (ref) v_u_10
			p_u_121.burst("Impact", p314, v_u_10, 0.7)
		end
	}
	return v122
end