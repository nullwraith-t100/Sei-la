local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(script.Parent.Parent.EpicKit8)
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v2.Shared.Config.Textures)
v5.images({
	v_u_7.BloodBloom,
	v_u_7.BloodDrop,
	v_u_7.BloodFlame,
	v_u_7.BloodBurst,
	v_u_7.FxSmoke,
	v_u_7.Glow
})
local v_u_8 = Color3.fromHex("FF4FA0")
local v_u_9 = Color3.fromRGB(255, 200, 228)
local v_u_10 = Color3.fromRGB(150, 0, 48)
local v_u_11 = Color3.fromRGB(42, 0, 16)
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = Enum.ParticleFlipbookLayout.Grid4x4
local function v_u_19(p14, p15, p16, p17, p18) -- name: bloom
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8
	v_u_3.flat(p14, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0.5,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["spin"] = nil,
		["image"] = v_u_7.BloodBloom,
		["color"] = v_u_8,
		["life"] = p17,
		["sizes"] = {
			{ 0, p15 },
			{ 0.28, p16 },
			{ 1, p16 * 1.12 }
		},
		["alphas"] = {
			{ 0, 0.3 },
			{ 0.25, 0 },
			{ 0.65, 0.15 },
			{ 1, 1 }
		},
		["spin"] = p18
	})
end
local function v_u_23(p20, p21, p22) -- name: stain
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_11
	v_u_3.flat(p20, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["image"] = v_u_7.Glow,
		["color"] = v_u_11,
		["life"] = p22,
		["sizes"] = {
			{ 0, p21 * 0.5 },
			{ 0.2, p21 },
			{ 1, p21 * 1.05 }
		},
		["alphas"] = {
			{ 0, 0.6 },
			{ 0.2, 0.25 },
			{ 0.7, 0.35 },
			{ 1, 1 }
		}
	})
end
local function v_u_28(p24, p25, p26, p27) -- name: fireBurst
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_9, (copy) v_u_8
	v_u_3.puff(p24, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.55,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["drag"] = 3,
		["spin"] = 60,
		["flip"] = "4x4",
		["image"] = v_u_7.BloodBurst,
		["color"] = v_u_9,
		["color2"] = v_u_8,
		["count"] = p25,
		["life"] = { 0.45, 0.7 },
		["sizes"] = {
			{ 0, p26 * 0.6 },
			{ 1, p26 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 0.7, 0.1 },
			{ 1, 1 }
		},
		["speed"] = { p27 * 0.5, p27 },
		["spread"] = Vector2.new(40, 40)
	})
end
local function v_u_34(p29, p30, p31, p32, p33) -- name: flames
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_8, (copy) v_u_10
	v_u_3.puff(p29, {
		["image"] = nil,
		["color"] = nil,
		["color2"] = nil,
		["emission"] = 0.35,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["drag"] = 2,
		["flip"] = "4x4",
		["image"] = v_u_7.BloodFlame,
		["color"] = v_u_8,
		["color2"] = v_u_10,
		["count"] = p30,
		["life"] = { 0.4, 0.65 },
		["sizes"] = {
			{ 0, p31 * 0.7 },
			{ 0.5, p31 },
			{ 1, p31 * 0.5 }
		},
		["alphas"] = {
			{ 0, 0.1 },
			{ 0.8, 0.2 },
			{ 1, 1 }
		},
		["speed"] = { p32 * 0.5, p32 },
		["spread"] = Vector2.new(p33 or 25, p33 or 25)
	})
end
local function v_u_41(p35, p36, p37, p38, p39, p40) -- name: drops
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_12
	v_u_3.puff(p35, {
		["image"] = nil,
		["color"] = nil,
		["emission"] = 0,
		["count"] = nil,
		["life"] = nil,
		["sizes"] = nil,
		["alphas"] = nil,
		["speed"] = nil,
		["spread"] = nil,
		["dir"] = nil,
		["accel"] = Vector3.new(0, -60, 0),
		["orient"] = nil,
		["image"] = v_u_7.BloodDrop,
		["color"] = v_u_12,
		["count"] = p36,
		["life"] = { 0.45, 0.75 },
		["sizes"] = {
			{ 0, p38 },
			{ 1, p38 * 0.8 }
		},
		["alphas"] = {
			{ 0, 0 },
			{ 0.8, 0 },
			{ 1, 1 }
		},
		["speed"] = { p37 * 0.55, p37 },
		["spread"] = Vector2.new(p39 or 70, p39 or 70),
		["dir"] = p40,
		["orient"] = Enum.ParticleOrientation.VelocityParallel
	})
end
return function(p_u_42)
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_41, (copy) v_u_34, (copy) v_u_19, (copy) v_u_4, (copy) v_u_1, (copy) v_u_7, (copy) v_u_13, (copy) v_u_10, (copy) v_u_3, (copy) v_u_23, (copy) v_u_28, (copy) v_u_11, (copy) v_u_6, (copy) v_u_12
	local v43 = {}
	local function v_u_47(p44, p45) -- name: bloodCast
		-- upvalues: (copy) p_u_42, (ref) v_u_8, (ref) v_u_9, (ref) v_u_41, (ref) v_u_34, (ref) v_u_19, (ref) v_u_4
		local v46 = p44.size
		p_u_42.burst("Flash", p44.eye, v_u_8, (p45 and 0.3 or 0.2) * v46)
		p_u_42.glint(p44.eye + p44.dir * 0.8, v_u_9, (p45 and 4 or 3) * v46, 0.16)
		if not p44.lite then
			v_u_41(p_u_42.aimAt(p44.eye + p44.dir, p44.dir), p45 and 10 or 5, 34, 0.7 * v46, 20, Enum.NormalId.Front)
			v_u_34(p_u_42.ground(p44.feet, 0.3), p45 and 6 or 4, 2.4 * v46, 8, 50)
		end
		v_u_19(p_u_42.ground(p44.feet, 0.12), 1.5 * v46, (p45 and 9 or 6) * v46, 0.45, -320)
		if p44.mine then
			v_u_4.shake(p45 and 0.12 or 0.06, 0.14)
		end
	end
	v43.exploding_blood_a = {
		["cast"] = function(p48) -- name: cast
			-- upvalues: (copy) p_u_42, (ref) v_u_8, (ref) v_u_41
			local v49 = p48.size
			local v50 = p48.eye + p48.dir * 1.2
			p_u_42.glint(v50, v_u_8, 2.4 * v49, 0.1)
			if not p48.lite then
				v_u_41(p_u_42.aimAt(v50, p48.dir), 3, 26, 0.5 * v49, 15, Enum.NormalId.Front)
			end
		end,
		["shot"] = function(p51, p52) -- name: sparkShot
			-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_13, (ref) v_u_10, (ref) v_u_3, (copy) p_u_42
			local v53 = p51.size
			local v_u_54 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p52, v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_54, 3)
			local v55 = Instance.new("Attachment")
			v55.Parent = v_u_54
			local v_u_56 = Instance.new("ParticleEmitter")
			v_u_56.Texture = v_u_7.BloodDrop
			v_u_56.LightEmission = 0
			v_u_56.LightInfluence = 0
			v_u_56.Orientation = Enum.ParticleOrientation.VelocityParallel
			v_u_56.EmissionDirection = Enum.NormalId.Front
			v_u_56.SpreadAngle = Vector2.zero
			v_u_56.Speed = NumberRange.new(0.05)
			v_u_56.Lifetime = NumberRange.new(0.05)
			v_u_56.Size = NumberSequence.new(0.85 * v53)
			v_u_56.LockedToPart = true
			v_u_56.Rate = 80
			v_u_56.Parent = v55
			local v_u_57
			if p51.lite then
				v_u_57 = nil
			else
				v_u_57 = Instance.new("ParticleEmitter")
				v_u_57.Texture = v_u_7.BloodFlame
				v_u_57.FlipbookLayout = v_u_13
				v_u_57.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				v_u_57.Color = ColorSequence.new(v_u_8, v_u_10)
				v_u_57.LightEmission = 0.4
				v_u_57.LightInfluence = 0
				v_u_57.Lifetime = NumberRange.new(0.2, 0.3)
				v_u_57.Size = v_u_3.seq({
					{ 0, 1 },
					{ 1, 0.35 }
				}, v53)
				v_u_57.Speed = NumberRange.new(0.5, 1.5)
				v_u_57.SpreadAngle = Vector2.new(180, 180)
				v_u_57.Rotation = NumberRange.new(0, 360)
				v_u_57.Rate = 45
				v_u_57.Parent = v55
			end
			p_u_42.streak(v_u_54, v_u_8, v_u_10, 0.5 * v53, 0.14)
			if p51.mine then
				p_u_42.light(v_u_54, v_u_8, 6 * v53)
			end
			local v_u_58 = false
			return {
				["place"] = function(p59, _) -- name: place
					-- upvalues: (copy) v_u_54
					v_u_54.CFrame = p59
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_58, (copy) v_u_56, (ref) v_u_57, (copy) v_u_54, (ref) v_u_1
					if not v_u_58 then
						v_u_58 = true
						v_u_56.Enabled = false
						v_u_56:Clear()
						local v60 = v_u_57
						if v60 then
							v60.Enabled = false
						end
						local v61 = v_u_54:FindFirstChildWhichIsA("PointLight")
						if v61 then
							v61:Destroy()
						end
						v_u_1:AddItem(v_u_54, 0.4)
					end
				end
			}
		end,
		["impact"] = function(p62, p63) -- name: impact
			-- upvalues: (copy) p_u_42, (ref) v_u_19, (ref) v_u_23, (ref) v_u_28, (ref) v_u_41, (ref) v_u_34, (ref) v_u_9
			local v64 = p62.size
			local v65 = p_u_42.ground(p63, 0.1)
			v_u_19(v65, 1.5 * v64, 7.5 * v64, 0.55, -300)
			v_u_23(v65 + Vector3.new(0, 0.02, 0), 4 * v64, 1.2)
			v_u_28(p63, p62.lite and 2 or 4, 4.5 * v64, 12)
			if not p62.lite then
				v_u_41(p63, 7, 22, 0.55 * v64)
				v_u_34(v65 + Vector3.new(0, 0.3, 0), 4, 2.4 * v64, 9)
			end
			p_u_42.glint(p63, v_u_9, 3 * v64, 0.12)
			p_u_42.hitSound(p63)
		end,
		["hit"] = function(_, p66, _) -- name: hit
			-- upvalues: (copy) p_u_42, (ref) v_u_8
			p_u_42.burst("Impact", p66, v_u_8, 0.55)
		end
	}
	local function v_u_86(p67, p68, p69, p70) -- name: kickWheel
		-- upvalues: (ref) v_u_3, (ref) v_u_4, (ref) v_u_8, (ref) v_u_11, (ref) v_u_1, (ref) v_u_10, (ref) v_u_7, (ref) v_u_13, (ref) v_u_9, (copy) p_u_42
		local v_u_71 = p67.size
		local v_u_72 = v_u_3.side(p67.dir)
		local v_u_73 = p69 * 0.55
		local v_u_74 = (Vector3.new(0, 1, 0) - p67.dir * 0.3).Unit
		local v_u_75 = p68 + Vector3.new(0, 1, 0) * v_u_73
		local v76 = p70 + 0.5
		local v_u_77 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_75), v_u_8, {
			["transparency"] = 1
		})
		local v_u_78 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_75), v_u_11, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_77, v76)
		v_u_1:AddItem(v_u_78, v76)
		v_u_3.trail(v_u_77, v_u_8, v_u_10, 3.4 * v_u_71, 0.34, 0.25)
		v_u_3.trail(v_u_78, v_u_11, v_u_11, 1 * v_u_71, 0.34, 0)
		local v_u_79
		if p67.lite then
			v_u_79 = nil
		else
			v_u_79 = Instance.new("ParticleEmitter")
			v_u_79.Texture = v_u_7.BloodFlame
			v_u_79.FlipbookLayout = v_u_13
			v_u_79.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_79.Color = ColorSequence.new(v_u_9, v_u_8)
			v_u_79.LightEmission = 0.5
			v_u_79.LightInfluence = 0
			v_u_79.Lifetime = NumberRange.new(0.25, 0.35)
			v_u_79.Size = v_u_3.seq({
				{ 0, 2.6 },
				{ 1, 0.8 }
			}, v_u_71)
			v_u_79.Speed = NumberRange.new(1, 3)
			v_u_79.SpreadAngle = Vector2.new(180, 180)
			v_u_79.Rotation = NumberRange.new(0, 360)
			v_u_79.Rate = 140
			v_u_79.Parent = v_u_77
		end
		p_u_42.animate(math.max(p70, 0.12) + 0.05, 0, function(p80)
			-- upvalues: (copy) v_u_72, (copy) v_u_74, (copy) v_u_75, (copy) v_u_73, (copy) v_u_77, (copy) v_u_78, (copy) v_u_71, (ref) v_u_79
			local v81 = 2.8797932657906435 + -4.4505895925855405 * (1 - (1 - p80) * (1 - p80))
			local v82 = v_u_72 * math.cos(v81) + v_u_74 * math.sin(v81)
			local v83 = (v_u_72 * -math.sin(v81) + v_u_74 * math.cos(v81)) * -1
			local v84 = v_u_75 + v82 * v_u_73
			v_u_77.CFrame = CFrame.fromMatrix(v84, v83, v82)
			v_u_78.CFrame = CFrame.fromMatrix(v84 + v82 * 2.1 * v_u_71, v83, v82)
			local v85 = p80 >= 1 and v_u_79
			if v85 then
				v85.Enabled = false
			end
		end)
	end
	v43.exploding_blood_e = {
		["cast"] = function(p87) -- name: cast
			-- upvalues: (copy) v_u_47
			v_u_47(p87, false)
		end,
		["windup"] = function(p88, p89, p90) -- name: windup
			-- upvalues: (copy) v_u_86, (copy) p_u_42
			local v91 = p88.ability.radius * p88.size
			v_u_86(p88, p_u_42.ground(p89, 0), v91, p90)
		end,
		["land"] = function(p92, p93) -- name: land
			-- upvalues: (copy) p_u_42, (ref) v_u_19, (ref) v_u_23, (ref) v_u_28, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_7, (ref) v_u_13, (ref) v_u_10, (ref) v_u_3, (ref) v_u_41, (ref) v_u_11, (ref) v_u_9, (ref) v_u_6
			local v94 = p92.size
			local v95 = p92.lite
			local v96 = p92.ability.radius * v94
			local v97 = p_u_42.ground(p93, 0.1)
			v_u_19(v97, 3 * v94, v96 * 2, 0.6, -220)
			v_u_23(v97 + Vector3.new(0, 0.02, 0), v96 * 1.6, 1.6)
			v_u_28(CFrame.new(v97 + Vector3.new(0, 0.8, 0)), v95 and 5 or 12, 6 * v94, 16)
			local v98 = v_u_4.part
			local v99 = v96 * 1.1
			local v100 = v96 * 1.1
			local v101 = v98(Vector3.new(v99, 0.4, v100), CFrame.new(v97 + Vector3.new(0, 0.3, 0)), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v101, 2)
			local v_u_102 = Instance.new("ParticleEmitter")
			v_u_102.Texture = v_u_7.BloodFlame
			v_u_102.FlipbookLayout = v_u_13
			v_u_102.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_102.Color = ColorSequence.new(v_u_8, v_u_10)
			v_u_102.LightEmission = 0.35
			v_u_102.LightInfluence = 0
			v_u_102.Lifetime = NumberRange.new(0.5, 0.8)
			v_u_102.Size = v_u_3.seq({
				{ 0, 1.8 },
				{ 0.5, 2.6 },
				{ 1, 1.2 }
			}, v94)
			v_u_102.Speed = NumberRange.new(2, 5)
			v_u_102.SpreadAngle = Vector2.new(15, 15)
			v_u_102.EmissionDirection = Enum.NormalId.Top
			v_u_102.Shape = Enum.ParticleEmitterShape.Box
			v_u_102.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_102.Rate = v95 and 10 or 30
			v_u_102.Parent = v101
			task.delay(1, function()
				-- upvalues: (copy) v_u_102
				v_u_102.Enabled = false
			end)
			if not v95 then
				v_u_41(v97 + Vector3.new(0, 0.6, 0), 12, 30, 0.6 * v94)
				local v103 = { v_u_11, v_u_10 }
				p_u_42.chunks(v97 + Vector3.new(0, 0.5, 0), v103, 8, 26, 0.5 * v94, 0.8, false, 0.8)
			end
			p_u_42.burst("Shockwave", v97, v_u_8, 0.8 * v94)
			p_u_42.glint(v97 + Vector3.new(0, 2, 0), v_u_9, 6 * v94, 0.2)
			v_u_6.play("Explosion", {
				["at"] = v97,
				["volume"] = p92.mine and 0.8 or 0.45
			})
			if p92.mine then
				v_u_4.shake(0.25, 0.25)
			end
		end,
		["hit"] = function(p104, p105, _) -- name: hit
			-- upvalues: (copy) p_u_42, (ref) v_u_8, (ref) v_u_19
			p_u_42.burst("Impact", p105, v_u_8, 0.7)
			if not p104.lite then
				v_u_19(p_u_42.ground(p105, 0.14), 1, 3.5, 0.4, 300)
			end
		end
	}
	local v_u_106 = {}
	setmetatable(v_u_106, {
		["__mode"] = "k"
	})
	local function v_u_119(p107, p108, p109, p110) -- name: fuse
		-- upvalues: (copy) p_u_42, (ref) v_u_4, (ref) v_u_9, (ref) v_u_1, (ref) v_u_8
		local v_u_111 = p_u_42.ground(p107, 0.35)
		local v_u_112 = p_u_42.ground(p108, 0.35)
		local v_u_113 = v_u_4.part(Vector3.new(0.5, 0.5, 0.5) * p110, CFrame.new(v_u_111), v_u_9)
		v_u_1:AddItem(v_u_113, p109 + 0.5)
		p_u_42.streak(v_u_113, v_u_9, v_u_8, p110 * 0.6, 0.25)
		p_u_42.animate(p109, 0, function(p114)
			-- upvalues: (copy) v_u_111, (copy) v_u_112, (copy) v_u_113
			local v115 = v_u_111:Lerp(v_u_112, p114)
			local v116 = p114 * 3.141592653589793 * 3
			local v117 = math.sin(v116)
			local v118 = v115 + Vector3.new(0, 1, 0) * math.abs(v117) * 0.4
			v_u_113.CFrame = CFrame.new(v118) * CFrame.Angles(p114 * 9, p114 * 7, 0)
			if p114 >= 1 then
				v_u_113.Transparency = 1
			end
		end)
	end
	v43.exploding_blood_r = {
		["castSound"] = "Burst",
		["cast"] = nil,
		["windup"] = nil,
		["strike"] = nil,
		["hit"] = nil,
		["cast"] = function(p120) -- name: cast
			-- upvalues: (copy) v_u_47
			v_u_47(p120, true)
		end,
		["windup"] = function(p121, p122, p123) -- name: windup
			-- upvalues: (copy) p_u_42, (copy) v_u_106, (ref) v_u_23, (ref) v_u_4, (ref) v_u_10, (ref) v_u_1, (ref) v_u_7, (ref) v_u_13, (ref) v_u_11, (ref) v_u_3, (ref) v_u_12
			local v124 = p121.size
			local v125 = p121.ability.radius * v124
			local v126 = p_u_42.ground(p122, 0.06)
			v_u_106[p121] = {
				["prev"] = p121.feet
			}
			v_u_23(v126, v125 * 2.2, p123 + 0.9)
			local v127 = v_u_4.part
			local v128 = v125 * 1.7
			local v129 = v125 * 1.7
			local v130 = v127(Vector3.new(v128, 3, v129), CFrame.new(v126 + Vector3.new(0, 2.5, 0)), v_u_10, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v130, p123 + 2.5)
			local v_u_131 = Instance.new("ParticleEmitter")
			v_u_131.Texture = v_u_7.FxSmoke
			v_u_131.FlipbookLayout = v_u_13
			v_u_131.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v_u_131.Color = ColorSequence.new(v_u_10, v_u_11)
			v_u_131.LightEmission = 0
			v_u_131.LightInfluence = 0
			v_u_131.Lifetime = NumberRange.new(1, 1.6)
			v_u_131.Size = v_u_3.seq({
				{ 0, 4 },
				{ 1, 8 }
			}, v124)
			v_u_131.Transparency = v_u_3.seq({
				{ 0, 1 },
				{ 0.2, 0.2 },
				{ 0.75, 0.35 },
				{ 1, 1 }
			})
			v_u_131.Speed = NumberRange.new(0.5, 2)
			v_u_131.SpreadAngle = Vector2.new(180, 180)
			v_u_131.Rotation = NumberRange.new(0, 360)
			v_u_131.RotSpeed = NumberRange.new(-30, 30)
			v_u_131.Shape = Enum.ParticleEmitterShape.Box
			v_u_131.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v_u_131.Rate = p121.lite and 8 or 32
			v_u_131.Parent = v130
			v_u_131:Emit(p121.lite and 4 or 12)
			task.delay(p123 + 0.2, function()
				-- upvalues: (copy) v_u_131
				v_u_131.Enabled = false
			end)
			if not p121.lite then
				local v132 = p121.eye + p121.dir
				local v133 = v126 + Vector3.new(0, 4, 0) - v132
				v_u_3.puff(CFrame.lookAt(v132, v132 + (v133.Unit + Vector3.new(0, 0.35, 0)).Unit), {
					["image"] = nil,
					["color"] = nil,
					["emission"] = 0,
					["count"] = 16,
					["life"] = nil,
					["sizes"] = nil,
					["speed"] = nil,
					["spread"] = nil,
					["dir"] = nil,
					["accel"] = Vector3.new(0, -50, 0),
					["orient"] = nil,
					["image"] = v_u_7.BloodDrop,
					["color"] = v_u_12,
					["life"] = { 0.5, 0.8 },
					["sizes"] = {
						{ 0, 0.8 * v124 },
						{ 1, 0.6 * v124 }
					},
					["speed"] = { v133.Magnitude * 1.1, v133.Magnitude * 1.6 },
					["spread"] = Vector2.new(14, 14),
					["dir"] = Enum.NormalId.Front,
					["orient"] = Enum.ParticleOrientation.VelocityParallel
				})
			end
		end,
		["strike"] = function(p_u_134, p_u_135, p136) -- name: strike
			-- upvalues: (copy) v_u_106, (copy) p_u_42, (copy) v_u_119, (ref) v_u_19, (ref) v_u_28, (ref) v_u_34, (ref) v_u_41, (ref) v_u_9, (ref) v_u_6, (ref) v_u_4
			local v_u_137 = p_u_134.size
			local v_u_138 = (p_u_134.ability.strikeRadius or 7) * v_u_137
			local v139 = v_u_106[p_u_134]
			local v_u_140
			if v139 then
				v_u_140 = v139.prev
			else
				v_u_140 = p_u_135
			end
			if v139 then
				v139.prev = p_u_135
			end
			if not p_u_134.lite and (v_u_140 - p_u_135).Magnitude > 1 then
				local v141 = math.max(p136, 0.05)
				local v_u_142 = math.min(0.2, v141)
				p_u_42.after(p136 - v_u_142, function()
					-- upvalues: (ref) v_u_119, (copy) v_u_140, (copy) p_u_135, (copy) v_u_142, (copy) v_u_137
					v_u_119(v_u_140, p_u_135, v_u_142, v_u_137)
				end)
			end
			p_u_42.after(p136, function()
				-- upvalues: (ref) p_u_42, (copy) p_u_135, (ref) v_u_19, (copy) v_u_138, (ref) v_u_28, (copy) p_u_134, (ref) v_u_34, (copy) v_u_137, (ref) v_u_41, (ref) v_u_9, (ref) v_u_6, (ref) v_u_4
				local v143 = p_u_42.ground(p_u_135, 0.1)
				v_u_19(v143, v_u_138 * 0.4, v_u_138 * 2.2, 0.55, math.random() < 0.5 and -320 or 320)
				v_u_28(CFrame.new(v143 + Vector3.new(0, 1, 0)), p_u_134.lite and 3 or 7, v_u_138 * 1.5, 16)
				v_u_34(v143 + Vector3.new(0, 0.5, 0), p_u_134.lite and 3 or 8, 4.5 * v_u_137, 22, 12)
				if not p_u_134.lite then
					v_u_41(v143 + Vector3.new(0, 1, 0), 5, 24, 0.5 * v_u_137)
				end
				p_u_42.glint(v143 + Vector3.new(0, 2, 0), v_u_9, 4 * v_u_137, 0.14)
				v_u_6.play(math.random() < 0.35 and "Explosion" or "Hit", {
					["at"] = v143,
					["volume"] = p_u_134.mine and 0.55 or 0.3
				})
				if p_u_134.mine then
					v_u_4.shake(0.1, 0.12)
				end
			end)
		end,
		["hit"] = function(_, p144, _) -- name: hit
			-- upvalues: (copy) p_u_42, (ref) v_u_8
			p_u_42.burst("Impact", p144, v_u_8, 0.6)
		end
	}
	return v43
end