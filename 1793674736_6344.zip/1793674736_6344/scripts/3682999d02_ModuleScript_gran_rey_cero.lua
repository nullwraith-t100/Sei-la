local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({
	v_u_7.CeroOrb,
	v_u_7.HollowRing,
	v_u_7.Beam,
	v_u_7.FxTwinkle
})
local v_u_8 = Color3.fromHex("3D7BFF")
local v_u_9 = Color3.fromHex("E6F0FF")
local v_u_10 = Color3.fromRGB(10, 30, 120)
local v_u_11 = Color3.fromRGB(120, 175, 255)
local v_u_12 = Color3.fromRGB(236, 230, 214)
local v_u_13 = Color3.fromRGB(16, 20, 40)
local v_u_14 = Color3.new(1, 1, 1)
local v_u_15 = Enum.Material.SmoothPlastic
local v_u_16 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_17 = CFrame.Angles(0, 1.5707963267948966, 0)
local function v_u_22(p18, p19, p20) -- name: sized
	local v21 = math.clamp(p20 or 0.25, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, p18 / 2), NumberSequenceKeypoint.new(v21, p19 / 2), NumberSequenceKeypoint.new(1, p19 / 2) })
end
local function v_u_25(p23) -- name: fading
	local v24 = math.clamp(p23 or 0.55, 0.01, 0.98)
	return NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(v24, 0.1), NumberSequenceKeypoint.new(1, 1) })
end
local function v_u_32(p26, p27, p28, p29) -- name: once
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v30 = Instance.new("Attachment")
	v30.WorldCFrame = p26
	v30.Parent = v_u_3.Terrain
	local v31 = Instance.new("ParticleEmitter")
	v31.Enabled = false
	v31.LightInfluence = 0
	v31.Speed = NumberRange.new(0)
	v31.Lifetime = NumberRange.new(p27)
	p29(v31)
	v31.Parent = v30
	v31:Emit(p28)
	v_u_1:AddItem(v30, p27 + 0.3)
end
local function v_u_46(p33, p34, p_u_35, p_u_36, p_u_37, p_u_38, p39, p_u_40, p_u_41) -- name: plane
	-- upvalues: (copy) v_u_32, (copy) v_u_22, (copy) v_u_25, (copy) v_u_16
	local v42 = p34.Magnitude <= 0.001 and Vector3.new(0, 1, 0) or p34.Unit
	local v43 = v42.Y
	local v44
	if math.abs(v43) > 0.98 then
		v44 = CFrame.new(p33)
	else
		v44 = CFrame.fromMatrix(p33, v42:Cross(Vector3.new(0, 1, 0)).Unit, v42)
	end
	v_u_32(v44, p39, 1, function(p45)
		-- upvalues: (copy) p_u_35, (copy) p_u_36, (copy) p_u_41, (ref) v_u_22, (copy) p_u_37, (copy) p_u_38, (ref) v_u_25, (copy) p_u_40, (ref) v_u_16
		p45.Texture = p_u_35
		p45.Color = ColorSequence.new(p_u_36)
		p45.LightEmission = p_u_41 or 0.25
		p45.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		p45.EmissionDirection = Enum.NormalId.Top
		p45.SpreadAngle = Vector2.zero
		p45.Speed = NumberRange.new(0.01)
		p45.Size = v_u_22(p_u_37, p_u_38, p_u_38 < p_u_37 and 0.95 or 0.25)
		p45.Transparency = v_u_25()
		p45.Rotation = NumberRange.new(0, 360)
		if p_u_40 then
			p45.FlipbookLayout = v_u_16
			p45.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
	end)
end
local function v_u_64(p_u_47, p_u_48, p49) -- name: orbOn
	-- upvalues: (copy) v_u_16, (copy) v_u_7, (copy) v_u_8, (copy) v_u_14
	local v_u_50 = {}
	local function v59(p51, p52, p53, p54, p55, p56) -- name: layer
		-- upvalues: (copy) p_u_48, (ref) v_u_16, (copy) p_u_47, (copy) v_u_50
		local v57 = Instance.new("ParticleEmitter")
		v57.Texture = p51
		v57.Color = ColorSequence.new(p52)
		v57.LightEmission = p54
		v57.LightInfluence = 0
		v57.LockedToPart = true
		v57.Speed = NumberRange.new(0)
		v57.Lifetime = NumberRange.new(0.1)
		v57.Size = NumberSequence.new(p_u_48 * p53 / 2)
		v57.Transparency = NumberSequence.new(p55)
		v57.Rotation = NumberRange.new(0, 360)
		if p56 then
			v57.FlipbookLayout = v_u_16
			v57.FlipbookMode = Enum.ParticleFlipbookMode.Loop
		end
		v57.Rate = 40
		v57.Parent = p_u_47
		v57:Emit(1)
		local v58 = v_u_50
		table.insert(v58, {
			["e"] = v57,
			["k"] = p53
		})
	end
	v59(v_u_7.Glow, v_u_8, 2.1, 0.5, 0.2, false)
	if not p49 then
		v59(v_u_7.Glow, v_u_14, 0.7, 0.8, 0, false)
	end
	v59(v_u_7.CeroOrb, v_u_8, 1, 0.1, 0, true)
	local v_u_60 = p_u_48
	return function(p61)
		-- upvalues: (ref) v_u_60, (copy) v_u_50
		local v62 = p61 - v_u_60
		if math.abs(v62) >= 0.05 then
			v_u_60 = p61
			for _, v63 in v_u_50 do
				v63.e.Size = NumberSequence.new(p61 * v63.k / 2)
			end
		end
	end
end
local function v_u_84(p65, p66, p67, p68, p69) -- name: lightning
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v70 = (p66 - p65).Magnitude / 3
	local v71 = math.floor(v70)
	local v72 = math.clamp(v71, 2, 7)
	local v73 = (p66 - p65):Cross(Vector3.new(0, 1, 0))
	local v74 = v73.Magnitude <= 0.001 and Vector3.new(1, 0, 0) or v73.Unit
	local v75 = p65
	for v76 = 1, v72 do
		local v77 = v76 / v72
		local v78
		if v76 == v72 then
			v78 = p66
		else
			v78 = v75:Lerp(p66, v77) + v74 * (math.random() - 0.5) * 2.2 + v74:Cross(p66 - v75).Unit * (math.random() - 0.5) * 1.6
		end
		local v79 = (p65 + v78) / 2
		local v80 = (v78 - p65).Magnitude
		local v81 = v_u_4.part
		local v82 = v80 + p67
		local v83 = v81(Vector3.new(p67, p67, v82), CFrame.lookAt(v79, v78), p68)
		v_u_4.tween(v83, p69, {
			["Size"] = nil,
			["Transparency"] = 1,
			["Size"] = Vector3.new(0.05, 0.05, v80)
		})
		v_u_1:AddItem(v83, p69 + 0.05)
		p65 = v78
	end
end
local function v_u_90(p85) -- name: skullPiece
	-- upvalues: (copy) v_u_2, (copy) v_u_12, (copy) v_u_15, (copy) v_u_4, (copy) v_u_1
	local v86 = v_u_2:FindFirstChild("EyePieces")
	if v86 then
		v86 = v86:FindFirstChild("w7_gran_rey_cero")
	end
	if not (v86 and v86:IsA("MeshPart")) then
		return nil
	end
	local v87 = v86:Clone()
	local v88 = v86.Size
	local v89 = v86.Size.Y
	v87.Size = v88 * (p85 / math.max(v89, 0.01))
	if not v87:FindFirstChildWhichIsA("SurfaceAppearance") then
		v87.Color = v_u_12
		v87.Material = v_u_15
	end
	v87.Anchored = true
	v87.CanCollide = false
	v87.CanQuery = false
	v87.CanTouch = false
	v87.CastShadow = false
	v87.Massless = true
	v87.Parent = v_u_4.folder()
	v_u_1:AddItem(v87, 5)
	return v87
end
return function(p_u_91)
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_1, (copy) v_u_64, (copy) v_u_10, (copy) v_u_7, (copy) v_u_16, (copy) v_u_11, (copy) v_u_32, (copy) v_u_22, (copy) v_u_25, (copy) v_u_46, (copy) v_u_9, (copy) v_u_84, (copy) v_u_14, (copy) v_u_6, (copy) v_u_90, (copy) v_u_17, (copy) v_u_12, (copy) v_u_15, (copy) v_u_13
	local v211 = {
		["gran_rey_cero_a"] = {
			["cast"] = function(p92) -- name: cast
				-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_46, (ref) v_u_10
				local v93 = p92.size
				local v94 = p92.eye + p92.dir * 1.4
				local v_u_95 = v_u_7.CeroOrb
				local v_u_96 = v_u_8
				local v_u_97 = 0.6 * v93
				local v_u_98 = 2.4 * v93
				local v_u_99 = 0.1
				local v_u_100 = true
				v_u_32(CFrame.new(v94), 0.14, 1, function(p101)
					-- upvalues: (copy) v_u_95, (copy) v_u_96, (copy) v_u_99, (ref) v_u_22, (copy) v_u_97, (copy) v_u_98, (ref) v_u_25, (copy) v_u_100, (ref) v_u_16
					p101.Texture = v_u_95
					p101.Color = ColorSequence.new(v_u_96)
					p101.LightEmission = v_u_99 or 0.4
					p101.Size = v_u_22(v_u_97, v_u_98)
					p101.Transparency = v_u_25()
					p101.Rotation = NumberRange.new(0, 360)
					if v_u_100 then
						p101.FlipbookLayout = v_u_16
						p101.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				v_u_46(v94, p92.dir, v_u_7.HollowRing, v_u_10, 0.8 * v93, 3.6 * v93, 0.22, true)
			end,
			["shot"] = function(p102, p103) -- name: ceroShot
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_64, (copy) p_u_91, (ref) v_u_10, (ref) v_u_7, (ref) v_u_16, (ref) v_u_11
				local v104 = p102.size
				local v_u_105 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p103, v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_105, 4)
				v_u_64(v_u_105, 2 * v104, p102.lite)
				p_u_91.streak(v_u_105, v_u_8, v_u_10, 1.3 * v104, 0.16)
				local v_u_106
				if p102.lite then
					v_u_106 = nil
				else
					v_u_106 = Instance.new("ParticleEmitter")
					v_u_106.Texture = v_u_7.FxTwinkle
					v_u_106.FlipbookLayout = v_u_16
					v_u_106.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					v_u_106.Color = ColorSequence.new(v_u_11)
					v_u_106.LightEmission = 0.5
					v_u_106.LightInfluence = 0
					v_u_106.Size = NumberSequence.new(0.5 * v104, 0.1)
					v_u_106.Lifetime = NumberRange.new(0.2, 0.3)
					v_u_106.Speed = NumberRange.new(1, 3)
					v_u_106.SpreadAngle = Vector2.new(180, 180)
					v_u_106.Rate = 30
					v_u_106.Parent = v_u_105
				end
				local v_u_107 = false
				return {
					["place"] = function(p108, _) -- name: place
						-- upvalues: (copy) v_u_105
						v_u_105.CFrame = p108
					end,
					["stop"] = function(_) -- name: stop
						-- upvalues: (ref) v_u_107, (copy) v_u_105, (ref) v_u_106, (ref) v_u_1
						if not v_u_107 then
							v_u_107 = true
							for _, v109 in v_u_105:GetChildren() do
								if not v109:IsA("ParticleEmitter") then
									continue
								end
								v109.Enabled = false
								v109:Clear()
							end
							local v110 = v_u_106
							if v110 then
								v110.Enabled = false
							end
							v_u_1:AddItem(v_u_105, 0.3)
						end
					end
				}
			end,
			["impact"] = function(p111, p112) -- name: impact
				-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_46, (copy) p_u_91, (ref) v_u_10, (ref) v_u_9
				local v113 = p111.size
				local v114 = p111.ability.radius * v113
				local v_u_115 = v_u_7.HollowRing
				local v_u_116 = v_u_8
				local v_u_117 = 1 * v113
				local v_u_118 = v114 * 1.6
				local v_u_119 = 0.3
				local v_u_120 = true
				v_u_32(CFrame.new(p112), 0.32, 1, function(p121)
					-- upvalues: (copy) v_u_115, (copy) v_u_116, (copy) v_u_119, (ref) v_u_22, (copy) v_u_117, (copy) v_u_118, (ref) v_u_25, (copy) v_u_120, (ref) v_u_16
					p121.Texture = v_u_115
					p121.Color = ColorSequence.new(v_u_116)
					p121.LightEmission = v_u_119 or 0.4
					p121.Size = v_u_22(v_u_117, v_u_118)
					p121.Transparency = v_u_25()
					p121.Rotation = NumberRange.new(0, 360)
					if v_u_120 then
						p121.FlipbookLayout = v_u_16
						p121.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v_u_122 = v_u_7.Glow
				local v_u_123 = v_u_8
				local v_u_124 = 1.5 * v113
				local v_u_125 = v114 * 0.9
				local v_u_126 = 0.5
				local v_u_127 = nil
				v_u_32(CFrame.new(p112), 0.16, 1, function(p128)
					-- upvalues: (copy) v_u_122, (copy) v_u_123, (copy) v_u_126, (ref) v_u_22, (copy) v_u_124, (copy) v_u_125, (ref) v_u_25, (copy) v_u_127, (ref) v_u_16
					p128.Texture = v_u_122
					p128.Color = ColorSequence.new(v_u_123)
					p128.LightEmission = v_u_126 or 0.4
					p128.Size = v_u_22(v_u_124, v_u_125)
					p128.Transparency = v_u_25()
					p128.Rotation = NumberRange.new(0, 360)
					if v_u_127 then
						p128.FlipbookLayout = v_u_16
						p128.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				v_u_46(p_u_91.ground(p112, 0.14), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 1.5 * v113, v114 * 1.9, 0.4, true)
				p_u_91.spikes(p112, v_u_9, p111.lite and 3 or 6, 7 * v113, 0.16)
				p_u_91.hitSound(p112)
			end,
			["hit"] = function(_, p129, _) -- name: hit
				-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) p_u_91
				local v_u_130 = v_u_7.CeroOrb
				local v_u_131 = v_u_8
				local v_u_132 = 0.1
				local v_u_133 = 1.5
				local v_u_134 = 3.5
				local v_u_135 = true
				v_u_32(CFrame.new(p129), 0.2, 1, function(p136)
					-- upvalues: (copy) v_u_130, (copy) v_u_131, (copy) v_u_132, (ref) v_u_22, (copy) v_u_133, (copy) v_u_134, (ref) v_u_25, (copy) v_u_135, (ref) v_u_16
					p136.Texture = v_u_130
					p136.Color = ColorSequence.new(v_u_131)
					p136.LightEmission = v_u_132 or 0.4
					p136.Size = v_u_22(v_u_133, v_u_134)
					p136.Transparency = v_u_25()
					p136.Rotation = NumberRange.new(0, 360)
					if v_u_135 then
						p136.FlipbookLayout = v_u_16
						p136.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				p_u_91.burst("Impact", p129, v_u_8, 0.6)
			end
		},
		["gran_rey_cero_e"] = {
			["cast"] = function(p137) -- name: cast
				-- upvalues: (copy) p_u_91, (ref) v_u_8
				p_u_91.skillCast(p137, v_u_8, false, true)
			end,
			["windup"] = function(p138, p139, p140) -- name: windup
				-- upvalues: (copy) p_u_91, (ref) v_u_46, (ref) v_u_7, (ref) v_u_10, (ref) v_u_8
				local v141 = p138.size
				local v142 = p138.ability.radius * v141
				local v143 = p_u_91.ground(p139, 0.12)
				v_u_46(v143, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, v142 * 0.4, v142 * 2.2, math.max(p140, 0.1) + 0.3, true)
				p_u_91.inward(v143 + Vector3.new(0, 5, 0) * v141, v_u_8, p138.lite and 4 or 8, v142, (math.max(p140, 0.1)))
			end,
			["zone"] = function(p_u_144, p145, p_u_146) -- name: zone
				-- upvalues: (copy) p_u_91, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_64, (ref) v_u_46, (ref) v_u_7, (ref) v_u_10, (ref) v_u_84, (ref) v_u_9, (ref) v_u_14, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_6
				local v_u_147 = p_u_144.size
				local v_u_148 = p_u_144.lite
				local v_u_149 = p_u_144.ability.radius * v_u_147
				local v_u_150 = p_u_91.ground(p145, 0.12)
				local v_u_151 = v_u_150 + Vector3.new(0, 8, 0) * v_u_147
				local v_u_152 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_151), v_u_8, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_152, p_u_146 + 2)
				local v_u_153 = v_u_64(v_u_152, 2 * v_u_147, v_u_148)
				v_u_46(v_u_150, Vector3.new(0, 1, 0), v_u_7.Glow, v_u_10, v_u_149 * 0.8, v_u_149 * 2.4, p_u_146 + 0.2, false, 0.1)
				v_u_46(v_u_150 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_8, v_u_149 * 2, v_u_149 * 2.2, p_u_146 + 0.2, false, 0.25)
				local v_u_154 = os.clock()
				local v_u_155 = 0
				local v_u_156 = 0
				local v_u_157 = false
				p_u_91.frame(function()
					-- upvalues: (ref) v_u_157, (copy) v_u_152, (copy) v_u_154, (copy) p_u_146, (copy) v_u_147, (copy) v_u_153, (copy) v_u_151, (ref) v_u_155, (copy) v_u_148, (copy) v_u_150, (copy) v_u_149, (ref) v_u_84, (ref) v_u_10, (ref) v_u_8, (ref) v_u_46, (ref) v_u_7, (ref) v_u_156, (copy) p_u_144, (ref) p_u_91, (ref) v_u_9
					if v_u_157 or not v_u_152.Parent then
						return false
					end
					local v158 = os.clock() - v_u_154
					local v159 = v158 / p_u_146
					local v160 = math.clamp(v159, 0, 1)
					local v161 = (v160 ^ 0.7 * 16 + 4) * v_u_147
					local v162 = v158 * 30
					local v163 = v161 * (math.sin(v162) * 0.05 + 1)
					v_u_153(v163)
					v_u_152.CFrame = CFrame.new(v_u_151 + Vector3.new(0, 1, 0) * v160 * 2 * v_u_147)
					if v_u_155 <= v158 then
						v_u_155 = v158 + (v_u_148 and 0.25 or 0.08)
						local v164 = math.random() * 3.141592653589793 * 2
						local v165 = v_u_150
						local v166 = math.cos(v164)
						local v167 = math.sin(v164)
						local v168 = v165 + Vector3.new(v166, 0, v167) * v_u_149 * (0.3 + math.random() * 0.7)
						local v169 = v_u_84
						local v170 = v_u_152.Position
						local v171 = 0.5 * v_u_147
						local v172
						if math.random() < 0.5 then
							v172 = v_u_10
						else
							v172 = v_u_8
						end
						v169(v170, v168, v171, v172, 0.16)
						if not v_u_148 then
							v_u_46(v168 + Vector3.new(0, 0.1, 0), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 1 * v_u_147, 4 * v_u_147, 0.25, true)
						end
					end
					if v_u_156 <= v158 then
						v_u_156 = v158 + (p_u_144.ability.tick or 0.4)
						v_u_46(v_u_150 + Vector3.new(0, 0.03, 0), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, v_u_149 * 2.2, v_u_149 * 0.3, 0.4, true)
						p_u_91.inward(v_u_152.Position, v_u_9, v_u_148 and 3 or 7, v163 * 1.4, 0.3)
					end
					return true
				end)
				return function()
					-- upvalues: (ref) v_u_157, (copy) v_u_152, (ref) v_u_7, (ref) v_u_14, (copy) v_u_147, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_8, (copy) v_u_149, (ref) v_u_46, (copy) v_u_150, (ref) v_u_10, (ref) p_u_91, (ref) v_u_9, (copy) v_u_148, (ref) v_u_6, (copy) p_u_144, (ref) v_u_4
					if not v_u_157 then
						v_u_157 = true
						local v173 = v_u_152.Position
						v_u_152:Destroy()
						local v_u_174 = v_u_7.Glow
						local v_u_175 = v_u_14
						local v_u_176 = 4 * v_u_147
						local v_u_177 = 14 * v_u_147
						local v_u_178 = 0.7
						local v_u_179 = nil
						v_u_32(CFrame.new(v173), 0.14, 1, function(p180)
							-- upvalues: (copy) v_u_174, (copy) v_u_175, (copy) v_u_178, (ref) v_u_22, (copy) v_u_176, (copy) v_u_177, (ref) v_u_25, (copy) v_u_179, (ref) v_u_16
							p180.Texture = v_u_174
							p180.Color = ColorSequence.new(v_u_175)
							p180.LightEmission = v_u_178 or 0.4
							p180.Size = v_u_22(v_u_176, v_u_177)
							p180.Transparency = v_u_25()
							p180.Rotation = NumberRange.new(0, 360)
							if v_u_179 then
								p180.FlipbookLayout = v_u_16
								p180.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						local v_u_181 = v_u_7.Glow
						local v_u_182 = v_u_8
						local v_u_183 = 8 * v_u_147
						local v_u_184 = v_u_149 * 2.6
						local v_u_185 = 0.5
						local v_u_186 = nil
						v_u_32(CFrame.new(v173), 0.3, 1, function(p187)
							-- upvalues: (copy) v_u_181, (copy) v_u_182, (copy) v_u_185, (ref) v_u_22, (copy) v_u_183, (copy) v_u_184, (ref) v_u_25, (copy) v_u_186, (ref) v_u_16
							p187.Texture = v_u_181
							p187.Color = ColorSequence.new(v_u_182)
							p187.LightEmission = v_u_185 or 0.4
							p187.Size = v_u_22(v_u_183, v_u_184)
							p187.Transparency = v_u_25()
							p187.Rotation = NumberRange.new(0, 360)
							if v_u_186 then
								p187.FlipbookLayout = v_u_16
								p187.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						local v_u_188 = v_u_7.HollowRing
						local v_u_189 = v_u_8
						local v_u_190 = 6 * v_u_147
						local v_u_191 = v_u_149 * 2.8
						local v_u_192 = 0.3
						local v_u_193 = true
						v_u_32(CFrame.new(v173), 0.45, 1, function(p194)
							-- upvalues: (copy) v_u_188, (copy) v_u_189, (copy) v_u_192, (ref) v_u_22, (copy) v_u_190, (copy) v_u_191, (ref) v_u_25, (copy) v_u_193, (ref) v_u_16
							p194.Texture = v_u_188
							p194.Color = ColorSequence.new(v_u_189)
							p194.LightEmission = v_u_192 or 0.4
							p194.Size = v_u_22(v_u_190, v_u_191)
							p194.Transparency = v_u_25()
							p194.Rotation = NumberRange.new(0, 360)
							if v_u_193 then
								p194.FlipbookLayout = v_u_16
								p194.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
							end
						end)
						v_u_46(v_u_150, Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 4 * v_u_147, v_u_149 * 2.6, 0.55, true)
						p_u_91.spikes(v173, v_u_9, v_u_148 and 6 or 14, 18 * v_u_147, 0.32)
						if not v_u_148 then
							local v195 = { v_u_8, v_u_10, v_u_9 }
							p_u_91.chunks(v173, v195, 8, 30 * v_u_147, 0.6 * v_u_147, 0.8, true, 0.4)
						end
						v_u_6.play("Explosion", {
							["at"] = v173,
							["volume"] = p_u_144.mine and 0.9 or 0.45
						})
						if p_u_144.mine then
							v_u_4.shake(0.3, 0.3)
						end
					end
				end
			end,
			["hit"] = function(_, p196, _) -- name: hit
				-- upvalues: (ref) v_u_7, (ref) v_u_11, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_8
				local v_u_197 = v_u_7.FxTwinkle
				local v_u_198 = v_u_11
				local v_u_199 = 0.5
				local v_u_200 = 1.5
				local v_u_201 = 3.5
				local v_u_202 = true
				v_u_32(CFrame.new(p196), 0.3, 1, function(p203)
					-- upvalues: (copy) v_u_197, (copy) v_u_198, (copy) v_u_199, (ref) v_u_22, (copy) v_u_200, (copy) v_u_201, (ref) v_u_25, (copy) v_u_202, (ref) v_u_16
					p203.Texture = v_u_197
					p203.Color = ColorSequence.new(v_u_198)
					p203.LightEmission = v_u_199 or 0.4
					p203.Size = v_u_22(v_u_200, v_u_201)
					p203.Transparency = v_u_25()
					p203.Rotation = NumberRange.new(0, 360)
					if v_u_202 then
						p203.FlipbookLayout = v_u_16
						p203.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v_u_204 = v_u_7.HollowRing
				local v_u_205 = v_u_8
				local v_u_206 = 0.3
				local v_u_207 = 1
				local v_u_208 = 4
				local v_u_209 = true
				v_u_32(CFrame.new(p196), 0.3, 1, function(p210)
					-- upvalues: (copy) v_u_204, (copy) v_u_205, (copy) v_u_206, (ref) v_u_22, (copy) v_u_207, (copy) v_u_208, (ref) v_u_25, (copy) v_u_209, (ref) v_u_16
					p210.Texture = v_u_204
					p210.Color = ColorSequence.new(v_u_205)
					p210.LightEmission = v_u_206 or 0.4
					p210.Size = v_u_22(v_u_207, v_u_208)
					p210.Transparency = v_u_25()
					p210.Rotation = NumberRange.new(0, 360)
					if v_u_209 then
						p210.FlipbookLayout = v_u_16
						p210.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
			end
		}
	}
	local v_u_212 = {}
	setmetatable(v_u_212, {
		["__mode"] = "k"
	})
	local function v_u_248(p213, p214) -- name: newSkull
		-- upvalues: (ref) v_u_90, (ref) v_u_17, (ref) v_u_4, (ref) v_u_12, (ref) v_u_15, (ref) v_u_13, (ref) v_u_1, (ref) v_u_8, (ref) v_u_64
		local v215 = p213.size
		local v216 = 7 * v215
		local v217 = p213.eye + Vector3.new(0, 5.6, 0) * v215 - p213.dir * 2.2 * v215
		local v218 = CFrame.lookAt(v217, v217 + p213.dir)
		local v219 = {}
		local v220 = v_u_90(v216)
		if v220 then
			v220.CFrame = v218 * v_u_17
			table.insert(v219, v220)
		else
			local v221 = v_u_4.part
			local v222 = v216 * 1.1
			local v223 = v216 * 0.6
			local v224 = v216 * 0.8
			local v225 = v221(Vector3.new(v222, v223, v224), v218, v_u_12, {
				["material"] = v_u_15
			})
			local v226 = v_u_4.part
			local v227 = v216 * 0.7
			local v228 = v216 * 0.3
			local v229 = v216 * 0.5
			local v230 = Vector3.new(v227, v228, v229)
			local v231 = {
				["material"] = v_u_15
			}
			local v232 = v226(v230, v218 * CFrame.new(0, -v216 * 0.1, -v216 * 0.55), v_u_12, v231)
			table.insert(v219, v225)
			table.insert(v219, v232)
			for _, v233 in { -1, 1 } do
				local v234 = v_u_4.part
				local v235 = v216 * 0.22
				local v236 = v216 * 0.16
				local v237 = v216 * 0.05
				local v238 = Vector3.new(v235, v236, v237)
				local v239 = v218 * CFrame.new(v233 * v216 * 0.25, v216 * 0.08, -v216 * 0.41)
				local v240 = v_u_13
				local v241 = {
					["material"] = v_u_15
				}
				table.insert(v219, v234(v238, v239, v240, v241))
			end
		end
		for _, v242 in v219 do
			v242.Transparency = 1
			v_u_4.tween(v242, math.max(p214, 0.08), {
				["Transparency"] = 0
			})
			v_u_1:AddItem(v242, 5)
		end
		local v243 = CFrame.new
		local v244 = Vector3.new(0, -0.2, -0.38) * v216
		local v245 = -0.2 * v216
		local v246 = (v218 * v243(v244 + Vector3.new(0, 0, v245))).Position
		local v247 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v246), v_u_8, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v247, 5)
		return {
			["parts"] = v219,
			["jaw"] = v246,
			["setOrb"] = v_u_64(v247, 1 * v215, p213.lite),
			["holder"] = v247
		}
	end
	v211.gran_rey_cero_r = {
		["cast"] = function(p249) -- name: cast
			-- upvalues: (copy) p_u_91, (ref) v_u_8, (ref) v_u_4
			p_u_91.skillCast(p249, v_u_8, true, true)
			if p249.mine then
				v_u_4.shake(0.12, 0.15)
			end
		end,
		["windup"] = function(p250, _, p251) -- name: windup
			-- upvalues: (copy) v_u_248, (copy) v_u_212, (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (copy) p_u_91, (ref) v_u_9, (ref) v_u_46, (ref) v_u_10
			local v_u_252 = p250.size
			local v253 = math.max(p251, 0.12)
			local v_u_254 = v_u_248(p250, v253)
			v_u_212[p250] = v_u_254
			local v255 = v_u_254.jaw
			local v_u_256 = v_u_7.Glow
			local v_u_257 = v_u_8
			local v_u_258 = 4 * v_u_252
			local v_u_259 = 12 * v_u_252
			local v260 = v253 + 0.2
			local v_u_261 = 0.4
			local v_u_262 = nil
			v_u_32(CFrame.new(v255), v260, 1, function(p263)
				-- upvalues: (copy) v_u_256, (copy) v_u_257, (copy) v_u_261, (ref) v_u_22, (copy) v_u_258, (copy) v_u_259, (ref) v_u_25, (copy) v_u_262, (ref) v_u_16
				p263.Texture = v_u_256
				p263.Color = ColorSequence.new(v_u_257)
				p263.LightEmission = v_u_261 or 0.4
				p263.Size = v_u_22(v_u_258, v_u_259)
				p263.Transparency = v_u_25()
				p263.Rotation = NumberRange.new(0, 360)
				if v_u_262 then
					p263.FlipbookLayout = v_u_16
					p263.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_91.inward(v_u_254.jaw, v_u_9, p250.lite and 5 or 12, 10 * v_u_252, v253)
			v_u_46(v_u_254.jaw, p250.dir, v_u_7.HollowRing, v_u_10, 12 * v_u_252, 2 * v_u_252, v253, true)
			p_u_91.animate(v253, 0, function(p264)
				-- upvalues: (copy) v_u_254, (copy) v_u_252
				v_u_254.setOrb((1 + 5 * p264 * p264) * v_u_252)
			end)
		end,
		["beam"] = function(p_u_265, _, p_u_266) -- name: beam
			-- upvalues: (copy) v_u_212, (copy) v_u_248, (ref) v_u_4, (ref) v_u_8, (ref) v_u_1, (ref) v_u_10, (ref) v_u_9, (ref) v_u_14, (ref) v_u_7, (copy) p_u_91, (ref) v_u_46, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_6
			local v_u_267 = p_u_265.size
			local v_u_268 = p_u_265.lite
			local v_u_269 = v_u_212[p_u_265] or v_u_248(p_u_265, 0.05)
			v_u_212[p_u_265] = nil
			local v_u_270 = v_u_269.jaw
			local v271 = p_u_266 - v_u_270
			local v272 = v271.Magnitude
			local v_u_273 = math.max(v272, 1)
			local v_u_274 = v271.Unit
			local v_u_275 = (p_u_265.ability.width or 6) * v_u_267
			v_u_269.setOrb(7 * v_u_267)
			local v_u_276 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.lookAt(v_u_270, p_u_266), v_u_8, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_276, 1.35)
			local v277 = Instance.new("Attachment")
			v277.Parent = v_u_276
			local v_u_278 = Instance.new("Attachment")
			v_u_278.WorldPosition = v_u_270
			v_u_278.Parent = v_u_276
			local v_u_279 = {}
			for v280, v281 in {
				{
					["c"] = nil,
					["w"] = 1.4,
					["light"] = 0,
					["alpha"] = 0.05,
					["speed"] = 0,
					["tex"] = "",
					["c"] = v_u_10
				},
				{
					["c"] = nil,
					["w"] = 1,
					["light"] = 0.3,
					["alpha"] = 0,
					["speed"] = 0,
					["tex"] = "",
					["c"] = v_u_8
				},
				{
					["c"] = nil,
					["w"] = 0.38,
					["light"] = 0.6,
					["alpha"] = 0,
					["speed"] = 0,
					["tex"] = "",
					["c"] = v_u_9
				},
				{
					["c"] = nil,
					["w"] = 0.9,
					["light"] = 0.8,
					["alpha"] = 0.2,
					["speed"] = 9,
					["tex"] = nil,
					["c"] = v_u_14,
					["tex"] = v_u_7.Beam
				}
			} do
				if v_u_268 and v280 == 4 then
					continue
				end
				local v282 = Instance.new("Beam")
				v282.Attachment0 = v277
				v282.Attachment1 = v_u_278
				v282.Texture = v281.tex
				v282.ZOffset = v280 * 0.05
				v282.TextureMode = Enum.TextureMode.Wrap
				v282.TextureLength = 10
				v282.TextureSpeed = v281.speed
				v282.Color = ColorSequence.new(v281.c)
				v282.LightEmission = v281.light
				v282.LightInfluence = 0
				v282.Transparency = NumberSequence.new(v281.alpha)
				v282.FaceCamera = true
				v282.Segments = 1
				v282.Width0 = 0
				v282.Width1 = 0
				v282.Parent = v_u_276
				local v283 = {
					["beam"] = v282,
					["w"] = v_u_275 * v281.w
				}
				table.insert(v_u_279, v283)
			end
			p_u_91.animate(0.9299999999999999, 0, function(p284)
				-- upvalues: (copy) v_u_278, (copy) v_u_270, (copy) v_u_274, (copy) v_u_273, (copy) v_u_279, (copy) v_u_276
				local v285 = p284 * 0.9299999999999999
				local v286 = v285 / 0.08
				local v287 = math.clamp(v286, 0, 1)
				v_u_278.WorldPosition = v_u_270 + v_u_274 * v_u_273 * v287
				local v288
				if v285 < 0.63 then
					local v289 = v285 * 60
					v288 = math.sin(v289) * 0.06 + 1
				else
					local v290 = (v285 - 0.08 - 0.55) / 0.3
					local v291 = math.clamp(v290, 0, 1)
					v288 = 1 - v291 * v291 * (3 - v291 * 2)
				end
				for _, v292 in v_u_279 do
					v292.beam.Width0 = v292.w * v288 * 0.8
					v292.beam.Width1 = v292.w * v288
				end
				if p284 >= 1 then
					v_u_276:Destroy()
				end
			end)
			local v_u_293 = 8 * v_u_267
			local v294 = v_u_273 / v_u_293
			local v295 = math.floor(v294)
			local v296 = math.max(v295, 1)
			for v_u_297 = 0, v_u_268 and 0 or 1 do
				for v_u_298 = 1, v296 do
					p_u_91.after(v_u_297 * 0.22 + v_u_298 / v296 * 0.24, function()
						-- upvalues: (copy) v_u_270, (copy) v_u_274, (copy) v_u_298, (copy) v_u_293, (ref) v_u_46, (ref) v_u_7, (copy) v_u_297, (ref) v_u_10, (ref) v_u_8, (copy) v_u_275
						local v299 = v_u_270 + v_u_274 * (v_u_298 * v_u_293)
						local v300 = v_u_46
						local v301 = v_u_274
						local v302 = v_u_7.HollowRing
						local v303
						if v_u_297 == 0 then
							v303 = v_u_10
						else
							v303 = v_u_8
						end
						v300(v299, v301, v302, v303, v_u_275 * 0.9, v_u_275 * 2.6, 0.35, true)
					end)
				end
			end
			local v304 = p_u_91.ground(v_u_270, 0.08)
			local v305 = p_u_91.ground(p_u_266, 0.08)
			local v306 = v305 - v304
			if v306.Magnitude > 1 then
				local v307 = (v304 + v305) / 2
				local v308 = v_u_4.part
				local v309 = v_u_275 * 1.1
				local v310 = v306.Magnitude
				local v311 = v308(Vector3.new(v309, 0.1, v310), CFrame.lookAt(v307, v305), v_u_10, {
					["transparency"] = 0.2
				})
				local v312 = v_u_4.part
				local v313 = v_u_275 * 0.5
				local v314 = v306.Magnitude
				for _, v315 in { v311, (v312(Vector3.new(v313, 0.12, v314), CFrame.lookAt(v307 + Vector3.new(0, 0.02, 0), v305 + Vector3.new(0, 0.02, 0)), v_u_8, {
						["transparency"] = 0.1
					})) } do
					v_u_4.tween(v315, 1.4500000000000002, {
						["Transparency"] = 1
					}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
					v_u_1:AddItem(v315, 1.55)
				end
				if not v_u_268 then
					local v316 = v306.Unit:Cross(Vector3.new(0, 1, 0))
					for v317 = 1, 5 do
						local v_u_318 = v304 + v306 * (v317 / 6) + v316 * (v317 % 2 == 0 and 1 or -1) * v_u_275 * 0.6
						p_u_91.after(v317 * 0.05, function()
							-- upvalues: (ref) p_u_91, (copy) v_u_318, (ref) v_u_10, (ref) v_u_8, (ref) v_u_9, (copy) v_u_267
							local v319 = { v_u_10, v_u_8, v_u_9 }
							p_u_91.chunks(v_u_318, v319, 3, 22 * v_u_267, 0.6 * v_u_267, 0.7, true, 1)
						end)
					end
				end
			end
			local v_u_320 = v_u_7.Glow
			local v_u_321 = v_u_14
			local v_u_322 = 4 * v_u_267
			local v_u_323 = 12 * v_u_267
			local v_u_324 = 0.7
			local v_u_325 = nil
			v_u_32(CFrame.new(v_u_270), 0.2, 1, function(p326)
				-- upvalues: (copy) v_u_320, (copy) v_u_321, (copy) v_u_324, (ref) v_u_22, (copy) v_u_322, (copy) v_u_323, (ref) v_u_25, (copy) v_u_325, (ref) v_u_16
				p326.Texture = v_u_320
				p326.Color = ColorSequence.new(v_u_321)
				p326.LightEmission = v_u_324 or 0.4
				p326.Size = v_u_22(v_u_322, v_u_323)
				p326.Transparency = v_u_25()
				p326.Rotation = NumberRange.new(0, 360)
				if v_u_325 then
					p326.FlipbookLayout = v_u_16
					p326.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			local v_u_327 = v_u_7.HollowRing
			local v_u_328 = v_u_8
			local v_u_329 = 4 * v_u_267
			local v_u_330 = 16 * v_u_267
			local v_u_331 = 0.3
			local v_u_332 = true
			v_u_32(CFrame.new(v_u_270), 0.4, 1, function(p333)
				-- upvalues: (copy) v_u_327, (copy) v_u_328, (copy) v_u_331, (ref) v_u_22, (copy) v_u_329, (copy) v_u_330, (ref) v_u_25, (copy) v_u_332, (ref) v_u_16
				p333.Texture = v_u_327
				p333.Color = ColorSequence.new(v_u_328)
				p333.LightEmission = v_u_331 or 0.4
				p333.Size = v_u_22(v_u_329, v_u_330)
				p333.Transparency = v_u_25()
				p333.Rotation = NumberRange.new(0, 360)
				if v_u_332 then
					p333.FlipbookLayout = v_u_16
					p333.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			p_u_91.after(0.08, function()
				-- upvalues: (copy) p_u_266, (ref) v_u_7, (ref) v_u_8, (copy) v_u_267, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_46, (ref) p_u_91, (ref) v_u_10, (ref) v_u_9, (copy) v_u_268, (ref) v_u_6, (copy) p_u_265
				local v334 = p_u_266
				local v_u_335 = v_u_7.Glow
				local v_u_336 = v_u_8
				local v_u_337 = 6 * v_u_267
				local v_u_338 = 22 * v_u_267
				local v_u_339 = 0.5
				local v_u_340 = nil
				v_u_32(CFrame.new(v334), 0.35, 1, function(p341)
					-- upvalues: (copy) v_u_335, (copy) v_u_336, (copy) v_u_339, (ref) v_u_22, (copy) v_u_337, (copy) v_u_338, (ref) v_u_25, (copy) v_u_340, (ref) v_u_16
					p341.Texture = v_u_335
					p341.Color = ColorSequence.new(v_u_336)
					p341.LightEmission = v_u_339 or 0.4
					p341.Size = v_u_22(v_u_337, v_u_338)
					p341.Transparency = v_u_25()
					p341.Rotation = NumberRange.new(0, 360)
					if v_u_340 then
						p341.FlipbookLayout = v_u_16
						p341.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				local v342 = p_u_266
				local v_u_343 = v_u_7.HollowRing
				local v_u_344 = v_u_8
				local v_u_345 = 4 * v_u_267
				local v_u_346 = 24 * v_u_267
				local v_u_347 = 0.3
				local v_u_348 = true
				v_u_32(CFrame.new(v342), 0.5, 1, function(p349)
					-- upvalues: (copy) v_u_343, (copy) v_u_344, (copy) v_u_347, (ref) v_u_22, (copy) v_u_345, (copy) v_u_346, (ref) v_u_25, (copy) v_u_348, (ref) v_u_16
					p349.Texture = v_u_343
					p349.Color = ColorSequence.new(v_u_344)
					p349.LightEmission = v_u_347 or 0.4
					p349.Size = v_u_22(v_u_345, v_u_346)
					p349.Transparency = v_u_25()
					p349.Rotation = NumberRange.new(0, 360)
					if v_u_348 then
						p349.FlipbookLayout = v_u_16
						p349.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
					end
				end)
				v_u_46(p_u_91.ground(p_u_266, 0.14), Vector3.new(0, 1, 0), v_u_7.HollowRing, v_u_10, 4 * v_u_267, 24 * v_u_267, 0.6, true)
				p_u_91.spikes(p_u_266, v_u_9, v_u_268 and 5 or 12, 16 * v_u_267, 0.3)
				if not v_u_268 then
					local v350 = { v_u_10, v_u_8 }
					p_u_91.chunks(p_u_266, v350, 6, 30 * v_u_267, 0.7 * v_u_267, 0.8, true, 0.8)
				end
				v_u_6.play("Explosion", {
					["at"] = p_u_266,
					["volume"] = p_u_265.mine and 0.8 or 0.4
				})
			end)
			p_u_91.after(0.7000000000000001, function()
				-- upvalues: (copy) v_u_269, (ref) v_u_4
				for _, v351 in v_u_269.parts do
					v_u_4.tween(v351, 0.3, {
						["Transparency"] = 1
					})
				end
				v_u_269.holder:Destroy()
			end)
			if p_u_265.mine then
				v_u_4.shake(0.4, 0.75)
			end
		end,
		["hit"] = function(_, p352, _) -- name: hit
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_32, (ref) v_u_22, (ref) v_u_25, (ref) v_u_16, (ref) v_u_11
			local v_u_353 = v_u_7.HollowRing
			local v_u_354 = v_u_8
			local v_u_355 = 0.3
			local v_u_356 = 1.5
			local v_u_357 = 6
			local v_u_358 = true
			v_u_32(CFrame.new(p352), 0.3, 1, function(p359)
				-- upvalues: (copy) v_u_353, (copy) v_u_354, (copy) v_u_355, (ref) v_u_22, (copy) v_u_356, (copy) v_u_357, (ref) v_u_25, (copy) v_u_358, (ref) v_u_16
				p359.Texture = v_u_353
				p359.Color = ColorSequence.new(v_u_354)
				p359.LightEmission = v_u_355 or 0.4
				p359.Size = v_u_22(v_u_356, v_u_357)
				p359.Transparency = v_u_25()
				p359.Rotation = NumberRange.new(0, 360)
				if v_u_358 then
					p359.FlipbookLayout = v_u_16
					p359.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
			local v_u_360 = v_u_7.Glow
			local v_u_361 = v_u_11
			local v_u_362 = 0.5
			local v_u_363 = 1.5
			local v_u_364 = 5
			local v_u_365 = nil
			v_u_32(CFrame.new(p352), 0.18, 1, function(p366)
				-- upvalues: (copy) v_u_360, (copy) v_u_361, (copy) v_u_362, (ref) v_u_22, (copy) v_u_363, (copy) v_u_364, (ref) v_u_25, (copy) v_u_365, (ref) v_u_16
				p366.Texture = v_u_360
				p366.Color = ColorSequence.new(v_u_361)
				p366.LightEmission = v_u_362 or 0.4
				p366.Size = v_u_22(v_u_363, v_u_364)
				p366.Transparency = v_u_25()
				p366.Rotation = NumberRange.new(0, 360)
				if v_u_365 then
					p366.FlipbookLayout = v_u_16
					p366.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
				end
			end)
		end
	}
	return v211
end