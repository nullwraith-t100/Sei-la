local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Lighting")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v3.Shared.Config.Textures)
local v_u_8 = Color3.fromRGB(232, 235, 246)
local v_u_9 = Color3.new(1, 1, 1)
local v_u_10 = Color3.fromRGB(205, 222, 255)
local v_u_11 = Color3.fromRGB(140, 175, 255)
local v_u_12 = Color3.fromRGB(185, 192, 215)
local v_u_13 = Color3.fromRGB(196, 199, 214)
local v_u_14 = Color3.fromRGB(138, 142, 164)
local v_u_15 = Color3.fromRGB(34, 36, 56)
local v_u_16 = Enum.PartType.Ball
local function v_u_29(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_5
	local v22 = v_u_5.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	local v26 = {}
	for _, v27 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v28 = Instance.new("Decal")
		v28.Face = v27
		v28.Texture = p19
		v28.Color3 = p20
		v28.Transparency = p21
		v28.Parent = v25
		table.insert(v26, v28)
	end
	return v25, v26
end
local v_u_30 = 0
local function v_u_35(p31) -- name: moonlight
	-- upvalues: (ref) v_u_30, (copy) v_u_2, (copy) v_u_5, (copy) v_u_9, (copy) v_u_1
	local v32 = os.clock()
	if v32 >= v_u_30 then
		v_u_30 = v32 + p31 + 0.6
		local v_u_33 = Instance.new("ColorCorrectionEffect")
		v_u_33.Name = "Moonfall"
		v_u_33.Parent = v_u_2
		v_u_5.tween(v_u_33, 0.2, {
			["TintColor"] = nil,
			["Saturation"] = -0.2,
			["Contrast"] = 0.12,
			["Brightness"] = 0.03,
			["TintColor"] = Color3.fromRGB(212, 222, 255)
		})
		task.delay(p31, function()
			-- upvalues: (ref) v_u_5, (copy) v_u_33, (ref) v_u_9
			local v34 = {
				["TintColor"] = nil,
				["Saturation"] = 0,
				["Contrast"] = 0,
				["Brightness"] = 0,
				["TintColor"] = v_u_9
			}
			v_u_5.tween(v_u_33, 0.5, v34)
		end)
		v_u_1:AddItem(v_u_33, p31 + 0.6)
	end
end
return function(p_u_36)
	-- upvalues: (copy) v_u_5, (copy) v_u_10, (copy) v_u_9, (copy) v_u_29, (copy) v_u_7, (copy) v_u_11, (copy) v_u_12, (copy) v_u_4, (copy) v_u_8, (copy) v_u_14, (copy) v_u_15, (copy) v_u_1, (copy) v_u_13, (copy) v_u_6, (copy) v_u_16, (copy) v_u_35
	local function v66(p37, p38) -- name: shardShot
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_9, (ref) v_u_29, (ref) v_u_7, (ref) v_u_11, (copy) p_u_36
		local v39 = p37.size
		local v40 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p38, v_u_10, {
			["transparency"] = 1
		})
		local v41 = p37.lite and 4 or 6
		local v42 = 1.35 * v39
		local v43 = 0.75 * v39
		local v44 = {}
		local v45 = {}
		for v46 = 0, v41 do
			local v47 = v46 * 3.6651914291880923 / v41 + -1.8325957145940461
			local v48 = math.sin(v47) * v42
			local v49 = -math.cos(v47) * v42
			local v50 = Vector3.new(v48, v49, 0)
			table.insert(v44, v50)
		end
		for v51 = 1, v41 do
			local v52 = v44[v51]
			local v53 = v44[v51 + 1]
			local v54 = 3.141592653589793 * (v51 - 0.5) / v41
			local v55 = v43 * (math.sin(v54) * 0.82 + 0.18)
			local v56 = CFrame.lookAt((v52 + v53) / 2, v53, Vector3.new(0, 0, 1))
			local v57 = {}
			local v58 = v_u_5.part
			local v59 = 0.3 * v39
			local v60 = (v53 - v52).Magnitude * 1.1
			local v61 = Vector3.new(v55, v59, v60)
			local v62 = p38 * v56
			local v63
			if v51 == 1 or v51 == v41 then
				v63 = v_u_10
			else
				v63 = v_u_9
			end
			v57.p = v58(v61, v62, v63)
			v57.off = v56
			table.insert(v45, v57)
		end
		if not p37.lite then
			local v64 = CFrame.Angles(1.5707963267948966, 0, 0) * CFrame.new(0, -0.15 * v39, 0)
			local v65 = {
				["p"] = v_u_29(p38 * v64, 2.3 * v39, v_u_7.Glow, v_u_11, 0.35),
				["off"] = v64
			}
			table.insert(v45, v65)
		end
		p_u_36.streak(v40, v_u_9, v_u_11, 1.4 * v39, 0.14)
		if p37.mine then
			p_u_36.light(v40, v_u_10, 9 * v39)
		end
		return p_u_36.assemble(v40, v45, {}, 0, 0, {}, 0.14, 17)
	end
	local function v71(p67, p68) -- name: shardImpact
		-- upvalues: (copy) p_u_36, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_12, (ref) v_u_7
		local v69 = p67.size
		p_u_36.glint(p68, v_u_9, 5 * v69, 0.16)
		v_u_5.flash(p68, v_u_10, 4.2 * v69, 0.14)
		p_u_36.burst("Impact", p68, v_u_10, 0.9 * v69)
		v_u_5.ring(p_u_36.ground(p68), v_u_12, 3.6 * v69, 0.25, v_u_7.Ring)
		if not p67.lite then
			p_u_36.spikes(p68, v_u_9, 4, 3.2 * v69, 0.12)
			local v70 = { v_u_9, v_u_12, v_u_10 }
			p_u_36.chunks(p68, v70, 4, 16, 0.3 * v69, 0.45, true, 0.7)
		end
		p_u_36.hitSound(p68)
	end
	local function v_u_79(p72, p73, p74, p75) -- name: shaft
		-- upvalues: (ref) v_u_7, (ref) v_u_10
		local v76 = Instance.new("Attachment")
		v76.WorldPosition = p73
		v76.Parent = p72
		local v77 = Instance.new("Attachment")
		v77.WorldPosition = p74
		v77.Parent = p72
		local v78 = Instance.new("Beam")
		v78.Attachment0 = v76
		v78.Attachment1 = v77
		v78.Texture = v_u_7.Beam
		v78.TextureMode = Enum.TextureMode.Stretch
		v78.Color = ColorSequence.new(v_u_10)
		v78.LightEmission = 0.5
		v78.LightInfluence = 0
		v78.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 0.6) })
		v78.Width0 = 3
		v78.Width1 = p75
		v78.FaceCamera = true
		v78.Segments = 1
		v78.Parent = p72
		return v78
	end
	local v_u_80 = {}
	setmetatable(v_u_80, {
		["__mode"] = "k"
	})
	local function v_u_99(p81, p82) -- name: placeMoon
		-- upvalues: (copy) p_u_36
		local v83 = p82 * 10
		p81.core.Size = Vector3.new(1, 1, 1) * v83 * 2
		p81.halo.Size = Vector3.new(1, 1, 1) * v83 * 2.7
		for v84, v85 in p81.craters do
			local v86 = p81.craterOffs[v84]
			local v87 = p81.at + v86 * v83
			v85.CFrame = p_u_36.aimAt(v87, v86) * CFrame.Angles(0, 1.5707963267948966, 0)
			local v88 = v85:GetAttribute("D")
			local v89 = type(v88) ~= "number" and 0.3 or v88
			local v90 = p82 * 0.6
			local v91 = v89 * v83
			local v92 = v89 * v83
			v85.Size = Vector3.new(v90, v91, v92)
		end
		for _, v93 in p81.crackParts do
			local v94 = v93:GetAttribute("D")
			local v95 = type(v94) ~= "number" and 1 or v94
			local v96 = v83 * 2 * v95
			local v97 = v83 * 2 * v95
			v93.Size = Vector3.new(v96, 0.05, v97)
			local v98 = v93:GetAttribute("Turn")
			v93.CFrame = p_u_36.facing(p81.at + p81.toward * v83 * 1.03, p81.toward) * CFrame.Angles(0, type(v98) ~= "number" and 0 or v98, 0)
		end
	end
	local function v_u_133(p100, p101) -- name: buildMoon
		-- upvalues: (copy) p_u_36, (ref) v_u_4, (ref) v_u_8, (ref) v_u_10, (ref) v_u_5, (ref) v_u_14, (ref) v_u_29, (ref) v_u_7, (ref) v_u_15, (ref) v_u_1, (copy) v_u_99
		local v102 = p_u_36.ground(p100.target, 26) + p100.dir * 24
		local v103 = v_u_4.CurrentCamera
		local v104
		if v103 then
			local v105 = v103.CFrame.Position - v102
			v104 = v105.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v105.Unit
		else
			v104 = Vector3.new(0, 0, 1)
		end
		local v106 = p_u_36.facing(v102, v104)
		local v107 = p_u_36.ball(v102, v_u_8, 1, 0, Enum.Material.SmoothPlastic)
		local v108 = p_u_36.ball(v102, v_u_10, 1, 0.78)
		local v109 = { v107, v108 }
		local v110 = {
			["at"] = nil,
			["parts"] = nil,
			["core"] = nil,
			["halo"] = nil,
			["craters"] = nil,
			["craterOffs"] = nil,
			["cracks"] = nil,
			["crackParts"] = nil,
			["toward"] = nil,
			["born"] = nil,
			["mass"] = 1,
			["count"] = nil,
			["done"] = false,
			["at"] = v102,
			["parts"] = v109,
			["core"] = v107,
			["halo"] = v108,
			["craters"] = {},
			["craterOffs"] = {},
			["cracks"] = {},
			["crackParts"] = {},
			["toward"] = v104,
			["born"] = os.clock()
		}
		local v111 = p100.ability.count or 6
		v110.count = math.max(v111, 1)
		local v112 = p100.lite and 3 or 6
		for v113 = 1, v112 do
			local v114 = v113 * 2.39996 + math.random() * 0.5
			local v115 = (v113 - 0.5) / v112
			local v116 = math.sqrt(v115) * 0.72
			local v117 = math.cos(v114) * v116
			local v118 = math.sin(v114) * v116
			local v119 = v106.RightVector * v117 + v106.LookVector * v118
			local v120 = 1 - v117 * v117 - v118 * v118
			local v121 = math.max(v120, 0)
			local v122 = (v119 + v104 * math.sqrt(v121)).Unit
			local v123 = v_u_5.part(Vector3.new(0.6, 1, 1), CFrame.new(v102), v_u_14, {
				["shape"] = Enum.PartType.Cylinder,
				["material"] = Enum.Material.SmoothPlastic
			})
			v123:SetAttribute("D", 0.28 + math.random() * 0.22)
			local v124 = v110.craters
			table.insert(v124, v123)
			local v125 = v110.craterOffs
			table.insert(v125, v122)
			table.insert(v109, v123)
		end
		for v126, v127 in { 0, 1.9 } do
			if p100.lite and v126 > 1 then
				break
			end
			local v128, v129 = v_u_29(v106, 0.1, v_u_7.CrackLines, v_u_15, 1)
			v128:SetAttribute("D", 0.3)
			v128:SetAttribute("Turn", v127)
			local v130 = v110.crackParts
			table.insert(v130, v128)
			local v131 = v110.cracks
			table.insert(v131, v129)
			table.insert(v109, v128)
		end
		for _, v132 in v109 do
			v_u_1:AddItem(v132, p101)
		end
		v_u_99(v110, 0.3)
		return v110
	end
	local function v_u_142(p134, p135, p136) -- name: endMoon
		-- upvalues: (ref) v_u_5, (ref) v_u_9, (copy) p_u_36, (ref) v_u_10, (ref) v_u_13, (ref) v_u_12, (ref) v_u_14, (ref) v_u_6
		if not p134.done then
			p134.done = true
			local v137 = p134.at
			local v138 = (p134.mass * 0.45 + 0.55) * 10
			if p135 then
				v_u_5.flash(v137, v_u_9, v138 * 3, 0.25)
				p_u_36.pop(v137, v_u_10, v138, v138 * 3.2, 0.45, 0.4)
				p_u_36.spikes(v137, v_u_9, p136 and 5 or 10, v138 * 2.2, 0.35)
				p_u_36.chunks(v137, {
					v_u_13,
					v_u_12,
					v_u_14,
					v_u_9
				}, p136 and 5 or 12, 40, 1.6, 1.2, false, 0.5)
				p_u_36.burst("Explosion", v137, v_u_10, 2.2)
				v_u_6.play("Explosion", {
					["at"] = nil,
					["volume"] = 0.5,
					["at"] = v137
				})
			end
			for _, v139 in p134.parts do
				if not v139.Parent then
					continue
				end
				p_u_36.fadeOut(v139, 0.2)
			end
			for _, v140 in p134.cracks do
				for _, v141 in v140 do
					v_u_5.tween(v141, 0.2, {
						["Transparency"] = 1
					})
				end
			end
		end
	end
	local function v_u_161(p143, p144) -- name: rockShot
		-- upvalues: (ref) v_u_5, (ref) v_u_10, (ref) v_u_13, (ref) v_u_11, (ref) v_u_16, (copy) p_u_36, (ref) v_u_9, (ref) v_u_1
		local v145 = 3 + math.random() * 1.4
		local v_u_146 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), p144, v_u_10, {
			["transparency"] = 1
		})
		local v147 = v_u_5.part
		local v148 = v145 * 0.8
		local v149 = v145 * 0.9
		local v_u_150 = v147(Vector3.new(v145, v148, v149), p144, v_u_13, {
			["material"] = Enum.Material.SmoothPlastic
		})
		local v_u_151
		if p143.lite then
			v_u_151 = nil
		else
			local v152 = {
				["shape"] = nil,
				["transparency"] = 0.86,
				["shape"] = v_u_16
			}
			v_u_151 = v_u_5.part(Vector3.new(1, 1, 1) * v145 * 1.35, p144, v_u_11, v152)
		end
		p_u_36.streak(v_u_146, v_u_9, v_u_11, v145 * 0.5, 0.2)
		v_u_1:AddItem(v_u_146, 4)
		v_u_1:AddItem(v_u_150, 4)
		if v_u_151 then
			v_u_1:AddItem(v_u_151, 4)
		end
		local v_u_153 = CFrame.Angles(math.random() * 6, math.random() * 6, 0)
		local v_u_154 = false
		return {
			["place"] = function(p155, p156) -- name: place
				-- upvalues: (copy) v_u_146, (copy) v_u_150, (copy) v_u_153, (ref) v_u_151
				local v157 = p155.Position
				v_u_146.CFrame = p155
				v_u_150.CFrame = CFrame.new(v157) * v_u_153 * CFrame.Angles(p156 * 7, p156 * 4, 0)
				local v158 = v_u_151
				if v158 then
					v158.CFrame = CFrame.new(v157)
				end
			end,
			["stop"] = function(p159) -- name: stop
				-- upvalues: (ref) v_u_154, (ref) v_u_1, (copy) v_u_146, (ref) v_u_151, (ref) p_u_36, (copy) v_u_150
				if v_u_154 then
					return
				else
					v_u_154 = true
					v_u_1:AddItem(v_u_146, 0.25)
					local v160 = v_u_151
					if v160 then
						v160:Destroy()
					end
					if p159 then
						p_u_36.fadeOut(v_u_150, p159)
					else
						v_u_150:Destroy()
					end
				end
			end
		}
	end
	local v287 = {
		["moon_rinne_a"] = {
			["cast"] = function(p162) -- name: cast
				-- upvalues: (ref) v_u_5, (ref) v_u_10, (copy) p_u_36, (ref) v_u_9
				local v163 = p162.size
				local v164 = p162.eye + p162.dir * 1.2
				v_u_5.flash(v164, v_u_10, 3.2 * v163, 0.1)
				p_u_36.pop(v164, v_u_9, 1.2 * v163, 0.3 * v163, 0.08)
				if not p162.lite then
					p_u_36.spikes(v164, v_u_9, 3, 2.6 * v163, 0.1, p162.dir, 0.45)
				end
			end,
			["shot"] = v66,
			["impact"] = v71,
			["hit"] = function(_, p165, _) -- name: hit
				-- upvalues: (copy) p_u_36, (ref) v_u_10
				p_u_36.burst("Impact", p165, v_u_10, 0.6)
			end
		},
		["moon_rinne_e"] = {
			["castSound"] = "Burst",
			["loopSound"] = "Vortex",
			["cast"] = nil,
			["windup"] = nil,
			["zone"] = nil,
			["finish"] = nil,
			["hit"] = nil,
			["cast"] = function(p166) -- name: cast
				-- upvalues: (copy) p_u_36, (ref) v_u_10, (ref) v_u_9
				p_u_36.skillCast(p166, v_u_10)
				p_u_36.glint(p166.eye, v_u_9, 5, 0.16)
			end,
			["windup"] = function(p167, p168, p169) -- name: windup
				-- upvalues: (ref) v_u_5, (copy) p_u_36, (ref) v_u_10
				local v170 = p167.ability.radius
				v_u_5.flash(p_u_36.ground(p168, 17), v_u_10, 9, p169 + 0.12)
				p_u_36.inward(p_u_36.ground(p168, 0.8), v_u_10, p167.lite and 3 or 6, v170 * 1.3, p169 + 0.05)
			end,
			["zone"] = function(p171, p_u_172, p_u_173) -- name: zone
				-- upvalues: (copy) p_u_36, (ref) v_u_8, (ref) v_u_10, (ref) v_u_1, (ref) v_u_5, (copy) v_u_79, (ref) v_u_11, (ref) v_u_29, (ref) v_u_7, (ref) v_u_9
				local v174 = p171.size
				local v_u_175 = p171.ability.radius * v174
				local v_u_176 = p171.lite
				local v177 = p_u_173 + 1.5
				local v178 = p_u_36.ground(p_u_172, 0)
				local v179 = p_u_36.ground(p_u_172, 17)
				local v_u_180 = p_u_36.ball(v179, v_u_8, 0.5, 0, Enum.Material.Neon)
				local v_u_181 = p_u_36.ball(v179, v_u_10, 0.5, 0.78)
				v_u_1:AddItem(v_u_180, v177)
				v_u_1:AddItem(v_u_181, v177)
				local v_u_182 = v_u_5.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v179), v_u_10, {
					["transparency"] = 1
				})
				v_u_1:AddItem(v_u_182, v177)
				local v_u_183 = v_u_79(v_u_182, v179, p_u_36.ground(p_u_172, 0.2), v_u_175 * 1.9)
				local v_u_184 = p_u_36.plate(p_u_36.ground(p_u_172, 0.1), 0.5, v_u_11, 0.72)
				v_u_1:AddItem(v_u_184, v177)
				local v_u_185, v_u_186 = v_u_29(CFrame.new(p_u_36.ground(p_u_172, 0.16)), 0.5, v_u_7.Ring, v_u_10, 0.1)
				v_u_1:AddItem(v_u_185, v177)
				local v_u_187 = {}
				local v_u_188 = {}
				for v189 = 1, v_u_176 and 2 or 3 do
					local v190, v191 = v_u_29(CFrame.new(p_u_36.ground(p_u_172, v189 * 0.02 + 0.18)), 0.5, v_u_7.Ring, v_u_9, 0.2)
					v_u_1:AddItem(v190, v177)
					table.insert(v_u_187, v190)
					table.insert(v_u_188, v191)
				end
				local v_u_192
				if v_u_176 then
					v_u_192 = nil
				else
					v_u_192 = p_u_36.loopAt("Charge", p_u_36.ground(p_u_172, 1), v_u_10, 1.4)
				end
				v_u_5.ring(v178, v_u_10, v_u_175 * 1.2, 0.35, v_u_7.Shockwave)
				p_u_36.burst("Impact", p_u_36.ground(p_u_172, 1), v_u_10, 1.4)
				local v_u_193 = p171.ability.tick or 0.32
				local v_u_194 = os.clock()
				local v_u_195 = nil
				local v_u_196 = -1
				p_u_36.runNow(function()
					-- upvalues: (copy) v_u_194, (ref) v_u_195, (copy) v_u_193, (ref) v_u_196, (copy) v_u_176, (ref) p_u_36, (copy) p_u_172, (ref) v_u_9, (ref) v_u_10, (ref) v_u_5, (copy) v_u_187, (copy) v_u_175, (copy) v_u_188, (copy) v_u_184, (copy) v_u_185, (copy) v_u_186, (copy) v_u_180, (copy) v_u_181, (copy) v_u_183, (copy) v_u_182, (copy) p_u_173
					local v197 = os.clock()
					local v198 = v197 - v_u_194
					local v199 = v198 / 0.18
					local v200 = math.clamp(v199, 0, 1) - 1
					local v201 = v200 * 2.7 * v200 * v200 + 1 + v200 * 1.7 * v200
					local v202
					if v_u_195 then
						local v203 = (v197 - v_u_195) / 0.14
						v202 = math.clamp(v203, 0, 1)
					else
						v202 = 0
					end
					local v204 = v201 * (1 - v202)
					local v205 = math.max(v204, 0.02)
					local v206 = v198 / v_u_193 % 1
					local v207
					if v206 < 0.6 then
						local v208 = v206 / 0.6
						local v209 = math.clamp(v208, 0, 1)
						v207 = 1.12 - v209 * v209 * (3 - v209 * 2) * 0.95
					else
						local v210 = (v206 - 0.6) / 0.4
						local v211 = math.clamp(v210, 0, 1)
						v207 = v211 * v211 * (3 - v211 * 2) * 0.95 + 0.17
					end
					local v212 = v206 < 0.6 and 1 or 0.45
					local v213 = v198 / v_u_193
					local v214 = math.floor(v213)
					if v206 >= 0.55 and v214 ~= v_u_196 then
						v_u_196 = v214
						if not v_u_176 then
							local v215 = { v_u_9, v_u_10 }
							p_u_36.chunks(p_u_36.ground(p_u_172, 0.6), v215, 3, 16, 0.3, 0.45, true, 1.3)
						end
						v_u_5.flash(p_u_36.ground(p_u_172, 1), v_u_10, 4, 0.18)
					end
					for v216, v217 in v_u_187 do
						local v218 = v_u_175 * 2 * v205
						local v219 = v207 + (v216 - 1) * 0.16
						local v220 = v218 * math.max(v219, 0.05)
						v217.Size = Vector3.new(v220, 0.05, v220)
						local v221 = v_u_188[v216]
						local v222 = 1 - v212 * (0.85 - (v216 - 1) * 0.2) * (1 - v202)
						for _, v223 in v221 do
							v223.Transparency = v222
						end
					end
					local v224 = v198 / v_u_193 * 3.141592653589793 * 2
					local v225 = math.sin(v224) * 0.06 + 1
					local v226 = v_u_184
					local v227 = v_u_175 * 2 * v205 * v225
					local v228 = v_u_175 * 2 * v205 * v225
					v226.Size = Vector3.new(0.12, v227, v228)
					v_u_184.Transparency = v212 * 0.1 + 0.68 + v202 * 0.3
					local v229 = v_u_185
					local v230 = v_u_175 * 2.15 * v205
					local v231 = v_u_175 * 2.15 * v205
					v229.Size = Vector3.new(v230, 0.05, v231)
					local v232 = v_u_186
					local v233 = v202 * 0.9 + 0.1
					for _, v234 in v232 do
						v234.Transparency = v233
					end
					local v235 = 1 + 0.12 * (1 - v206)
					v_u_180.Size = Vector3.new(5, 5, 5) * v205 * v235
					v_u_181.Size = Vector3.new(9, 9, 9) * v205 * v235
					v_u_183.Width1 = v_u_175 * 1.9 * v205
					v_u_183.Width0 = v205 * 3
					if v202 < 1 then
						return v198 < p_u_173 + 1
					end
					for _, v236 in {
						v_u_180,
						v_u_181,
						v_u_182,
						v_u_184,
						v_u_185
					} do
						v236:Destroy()
					end
					for _, v237 in v_u_187 do
						v237:Destroy()
					end
					return false
				end)
				local v_u_238 = true
				task.spawn(function()
					-- upvalues: (ref) v_u_238, (copy) v_u_194, (copy) p_u_173, (ref) p_u_36, (copy) p_u_172, (ref) v_u_9, (copy) v_u_176, (copy) v_u_175, (copy) v_u_193
					while v_u_238 and os.clock() - v_u_194 < p_u_173 + 0.5 do
						p_u_36.inward(p_u_36.ground(p_u_172, 0.9), v_u_9, v_u_176 and 3 or 6, v_u_175, 0.26)
						task.wait(v_u_193)
					end
				end)
				return function()
					-- upvalues: (ref) v_u_238, (ref) v_u_195, (ref) v_u_192
					v_u_238 = false
					v_u_195 = os.clock()
					local v239 = v_u_192
					if v239 then
						v239()
					end
				end
			end,
			["finish"] = function(p240, p241) -- name: finish
				-- upvalues: (copy) p_u_36, (ref) v_u_10, (ref) v_u_9, (ref) v_u_5, (ref) v_u_7, (ref) v_u_11, (ref) v_u_6
				local v242 = p240.ability.radius * p240.size
				local v243 = p240.lite
				local v244 = p_u_36.ground(p241)
				p_u_36.thin(p_u_36.pillar(v244, 26, v242 * 0.55, v_u_10, 0.35), 0.5, true)
				p_u_36.thin(p_u_36.pillar(v244, 30, v242 * 0.2, v_u_9, 0), 0.4, true)
				p_u_36.pop(p_u_36.ground(p241, 2), v_u_10, 3, v242 * 1.9, 0.35, 0.4)
				v_u_5.flash(p_u_36.ground(p241, 3), v_u_9, v242 * 1.2, 0.16)
				v_u_5.ring(v244, v_u_9, v242 * 1.4, 0.45, v_u_7.SpeedLines)
				v_u_5.ring(v244, v_u_10, v242 * 1.2, 0.5, v_u_7.Shockwave)
				p_u_36.burst("Shockwave", v244 + Vector3.new(0, 0.3, 0), v_u_10, v242 / 14)
				p_u_36.burst("Explosion", p_u_36.ground(p241, 2), v_u_10, v242 / 7)
				p_u_36.chunks(p_u_36.ground(p241, 1.5), { v_u_9, v_u_10, v_u_11 }, v243 and 4 or 10, 42, 0.45, 0.8, true, 1.6)
				v_u_5.flash(p_u_36.ground(p241, 17), v_u_9, 10, 0.2)
				v_u_6.play("Explosion", {
					["at"] = v244,
					["volume"] = p240.mine and 0.8 or 0.5
				})
				if p240.mine then
					v_u_5.shake(0.35, 0.3)
				end
			end,
			["hit"] = function(p245, p246, _) -- name: hit
				-- upvalues: (copy) p_u_36, (ref) v_u_10, (ref) v_u_9
				p_u_36.burst("Impact", p246, v_u_10, 0.6)
				if not p245.lite then
					p_u_36.glint(p246, v_u_9, 2.4, 0.12)
				end
			end
		},
		["moon_rinne_r"] = {
			["cast"] = function(p247) -- name: cast
				-- upvalues: (copy) p_u_36, (ref) v_u_10, (ref) v_u_9, (ref) v_u_7, (ref) v_u_6
				p_u_36.skillCast(p247, v_u_10, true)
				p_u_36.glint(p247.eye, v_u_9, 7, 0.2)
				p_u_36.sigil(p_u_36.facing(p247.eye + p247.dir * 1.6, p247.dir), 2.2, v_u_9, p_u_36.iris("moon_rinne", v_u_7.Ring), 0.3, 5)
				v_u_6.play("EyeActivate", {
					["at"] = p247.origin,
					["volume"] = p247.mine and 0.9 or 0.5
				})
			end,
			["windup"] = function(p248, _, p249) -- name: windup
				-- upvalues: (copy) v_u_133, (copy) v_u_80, (ref) v_u_5, (ref) v_u_9, (copy) p_u_36, (ref) v_u_10, (copy) v_u_99, (copy) v_u_142, (ref) v_u_35
				local v_u_250 = p249 + 2
				local v_u_251 = v_u_133(p248, v_u_250)
				v_u_80[p248] = v_u_251
				local v_u_252 = p248.lite
				v_u_5.flash(v_u_251.at, v_u_9, 26, 0.3)
				if not v_u_252 then
					p_u_36.glowBeam(p248.eye, v_u_251.at, v_u_10, 1.8, 0.4)
					p_u_36.burst("Flash", v_u_251.at, v_u_10, 1.2)
				end
				local v_u_253 = v_u_251.born
				local v254 = p249 * 0.3
				local v_u_255 = math.min(0.2, v254)
				p_u_36.runNow(function()
					-- upvalues: (copy) v_u_251, (copy) v_u_253, (copy) v_u_255, (ref) v_u_99, (copy) v_u_250
					if v_u_251.done then
						return false
					end
					local v256 = os.clock() - v_u_253
					local v257 = v256 / 0.25
					local v258 = math.clamp(v257, 0, 1) - 1
					local v259 = ((v258 * 2.7 * v258 * v258 + 1 + v258 * 1.7 * v258) * 0.7 + 0.3) * (v_u_251.mass * 0.45 + 0.55)
					local v260 = v256 * 13
					local v261 = v259 * (math.sin(v260) * 0.006 + 1)
					local v262 = (v256 - v_u_255) / 0.45
					local v263 = math.clamp(v262, 0, 1)
					local v264 = v263 * v263 * (3 - v263 * 2)
					for v265, v266 in v_u_251.crackParts do
						v266:SetAttribute("D", v264 * 0.8 * (v265 == 1 and 1 or 0.85) + 0.25)
						local v267 = v_u_251.cracks[v265]
						local v268 = 1 - v264 * 0.9
						for _, v269 in v267 do
							v269.Transparency = v268
						end
					end
					v_u_99(v_u_251, v261)
					return v256 < v_u_250
				end)
				p_u_36.after(math.max(p249, 0.2) + 0.12, function()
					-- upvalues: (ref) v_u_142, (copy) v_u_251, (copy) v_u_252
					v_u_142(v_u_251, true, v_u_252)
				end)
				if p248.mine then
					v_u_35(p249 + 0.3)
					v_u_5.shake(0.2, 0.25)
				end
			end,
			["strike"] = function(p_u_270, p_u_271, p272) -- name: strike
				-- upvalues: (copy) v_u_80, (copy) p_u_36, (ref) v_u_10, (ref) v_u_13, (ref) v_u_12, (copy) v_u_161, (ref) v_u_5, (ref) v_u_9, (ref) v_u_7, (ref) v_u_15, (ref) v_u_11, (ref) v_u_6
				local v_u_273 = v_u_80[p_u_270]
				local v274
				if v_u_273 then
					v274 = v_u_273.at
				else
					v274 = p_u_36.ground(p_u_270.target, 26) + p_u_270.dir * 24
				end
				local v_u_275 = p_u_270.ability.strikeRadius or 8
				local v276 = p_u_36.ground(p_u_271, 1.6)
				local v_u_277 = v274 + (v276 - v274).Unit * 10 * 0.75
				local v278 = p_u_36.after
				local v279 = p272 - 0.34
				v278(math.max(v279, 0), function()
					-- upvalues: (copy) v_u_273, (ref) p_u_36, (copy) v_u_277, (ref) v_u_10, (copy) p_u_270, (ref) v_u_13, (ref) v_u_12
					if v_u_273 and not v_u_273.done then
						local v280 = v_u_273
						local v281 = v_u_273.mass - 1 / v_u_273.count
						v280.mass = math.max(v281, 0)
					end
					p_u_36.burst("Impact", v_u_277, v_u_10, 1.4)
					if not p_u_270.lite then
						local v282 = { v_u_13, v_u_12 }
						p_u_36.chunks(v_u_277, v282, 3, 14, 0.8, 0.6, false, 0.2)
					end
				end)
				p_u_36.drop(p_u_270, v_u_161, v_u_277, v276, 0.34, p272, 0.35, function(p283)
					-- upvalues: (ref) p_u_36, (copy) p_u_271, (ref) v_u_5, (ref) v_u_9, (copy) v_u_275, (ref) v_u_10, (ref) v_u_7, (ref) v_u_15, (ref) v_u_11, (copy) p_u_270, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6
					local v284 = p_u_36.ground(p_u_271, 0)
					v_u_5.flash(p_u_36.ground(p_u_271, 2), v_u_9, v_u_275 * 1.1, 0.16)
					p_u_36.pop(p_u_36.ground(p_u_271, 1), v_u_10, 2, v_u_275 * 1.7, 0.3, 0.4)
					v_u_5.ring(v284, v_u_10, v_u_275 * 1.2, 0.4, v_u_7.Shockwave)
					p_u_36.burst("Shockwave", p_u_36.ground(p_u_271, 0.3), v_u_10, v_u_275 / 16)
					p_u_36.burst("Impact", p_u_36.ground(p_u_271, 1.5), v_u_9, 1.4)
					p_u_36.mark(p_u_271, v_u_15, v_u_275 * 0.75, 1.4, v_u_7.CrackLines, 0.05)
					p_u_36.mark(p_u_271, v_u_11, v_u_275 * 0.55, 1, v_u_7.CrackGlow, 0.25)
					p_u_36.spikes(p_u_36.ground(p_u_271, 1), v_u_9, p_u_270.lite and 3 or 6, v_u_275 * 1.2, 0.25, nil, nil, true)
					p_u_36.chunks(p_u_36.ground(p_u_271, 0.8), {
						v_u_13,
						v_u_12,
						p_u_36.EARTH[1],
						p_u_36.EARTH[2]
					}, p_u_270.lite and 3 or 6, 34, 0.9, 0.9)
					v_u_6.play("Hit", {
						["at"] = p283,
						["volume"] = p_u_270.mine and 0.7 or 0.4
					})
					if p_u_270.mine then
						v_u_5.shake(0.28, 0.2)
					end
				end)
			end,
			["hit"] = function(p285, p286, _) -- name: hit
				-- upvalues: (copy) p_u_36, (ref) v_u_10, (ref) v_u_9
				p_u_36.burst("Impact", p286, v_u_10, 0.9)
				if not p285.lite then
					p_u_36.glint(p286, v_u_9, 3, 0.14)
				end
			end
		}
	}
	return v287
end