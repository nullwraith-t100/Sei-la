local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_3 = require(script.Parent.Parent.Kit)
local v_u_4 = require(v_u_2.Shared.Config.Textures)
local v_u_5 = Color3.new(1, 1, 1)
local v_u_6 = Color3.fromRGB(46, 24, 10)
local v_u_7 = Color3.fromRGB(112, 64, 30)
local v_u_8 = Color3.fromRGB(128, 30, 16)
local v_u_9 = Color3.fromRGB(255, 196, 90)
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.PartType.Wedge
local v_u_12 = CFrame.Angles(1.5707963267948966, 0, 0)
local v_u_13 = CFrame.Angles(0, 3.141592653589793, 0)
local function v_u_21(p14) -- name: eyePiece
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v15 = v_u_2:FindFirstChild("EyePieces")
	if v15 then
		v15 = v15:FindFirstChild("w8_zohakuten")
	end
	if not (v15 and v15:IsA("MeshPart")) then
		return nil
	end
	local v16 = v15:Clone()
	local v17 = v15.Size
	local v18 = v17.X
	local v19 = v17.Y
	local v20 = v17.Z
	v16.Size = v17 * (p14 / math.max(v18, v19, v20, 0.01))
	v16.Anchored = true
	v16.CanCollide = false
	v16.CanQuery = false
	v16.CanTouch = false
	v16.Massless = true
	v16.CastShadow = false
	v16.Parent = v_u_3.folder()
	return v16
end
local function v_u_33(p22, p23, p24, p25, p26, p27) -- name: soundRing
	-- upvalues: (copy) v_u_3, (copy) v_u_12, (copy) v_u_4, (copy) v_u_1
	local v28 = v_u_3.part(Vector3.new(p23, 0.05, p23), p22 * v_u_12, p26, {
		["transparency"] = 1
	})
	local v29 = {}
	for _, v30 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v31 = Instance.new("Decal")
		v31.Face = v30
		v31.Texture = v_u_4.ZohakuBoom
		v31.Color3 = p26
		v31.Parent = v28
		table.insert(v29, v31)
	end
	v_u_3.tween(v28, p27, {
		["Size"] = Vector3.new(p24, 0.05, p24),
		["CFrame"] = p22 * CFrame.new(0, 0, p25) * v_u_12
	})
	for _, v32 in v29 do
		v_u_3.tween(v32, p27, {
			["Transparency"] = 1
		}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
	end
	v_u_1:AddItem(v28, p27 + 0.05)
end
return function(p_u_34)
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_6, (copy) v_u_10, (copy) v_u_21, (copy) v_u_13, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_33
	return {
		["w8_zohakuten"] = function(p_u_35, p36)
			-- upvalues: (ref) v_u_3, (copy) p_u_34, (ref) v_u_7, (ref) v_u_6, (ref) v_u_10, (ref) v_u_21, (ref) v_u_13, (ref) v_u_8, (ref) v_u_4, (ref) v_u_5, (ref) v_u_12, (ref) v_u_11, (ref) v_u_9, (ref) v_u_33
			local v_u_37 = v_u_3.color(p36.color)
			local v38 = p_u_35.headY / 1.5
			local v_u_39 = math.clamp(v38, 0.7, 3)
			local v_u_40 = v_u_39 * 1.6
			local v_u_41 = -100
			local v_u_42 = 5
			p_u_34.throb(p_u_35, 5.5, 2, 1, function()
				-- upvalues: (ref) v_u_41, (ref) v_u_42
				v_u_41 = os.clock()
				v_u_42 = 0
			end)
			local v_u_51 = p_u_34.group(p_u_35, function(p43, p44)
				-- upvalues: (copy) v_u_39
				local v45 = CFrame.new
				local v46 = v_u_39 * 0.8
				local v47 = p44 * 1.4
				local v48 = p43 * v45(0, v46 + math.sin(v47) * 0.08 * v_u_39, v_u_39 * 1.35)
				local v49 = CFrame.Angles
				local v50 = p44 * 0.5
				return v48 * v49(0, 0, math.sin(v50) * 0.05)
			end)
			local v52 = v_u_40 * 2 * 0.20791169081775931 + v_u_39 * 0.1
			for v53 = 1, 15 do
				local v54 = (v53 - 0.5) / 15 * 3.141592653589793 * 2
				local v55 = math.sin(v54) * v_u_40
				local v56 = math.cos(v54) * v_u_40
				local v57 = v_u_39 * 0.05
				local v58 = Vector3.new(v55, v56, v57)
				local v59 = math.cos(v54)
				local v60 = -math.sin(v54)
				local v61 = Vector3.new(v59, v60, 0)
				local v62 = p_u_34.bar
				local v63 = v_u_39 * 0.17
				local v64 = v_u_39 * 0.17
				local v65 = Vector3.new(v63, v64, v52)
				local v66
				if v53 % 3 == 0 then
					v66 = v_u_7
				else
					v66 = v_u_6
				end
				local v67 = v62(v65, v66, 0, v_u_10)
				p_u_34.pin(p_u_35, v_u_51, v67, CFrame.lookAt(v58, v58 + v61))
				p_u_34.fadeFromBehind(p_u_35, v67, 0.45)
			end
			local v68 = v_u_21(v_u_39 * 1.9)
			local v_u_69 = {}
			for v70 = 1, 5 do
				local v71 = (v70 - 1) / 5 * 3.141592653589793 * 2
				local v72 = math.sin(v71) * v_u_40
				local v73 = math.cos(v71) * v_u_40
				local v74 = Vector3.new(v72, v73, 0)
				if v70 == 1 and v68 then
					local v75 = p_u_34.pin
					local v76 = CFrame.new
					local v77 = v_u_39 * 0.35
					v75(p_u_35, v_u_51, v68, v76(v74 + Vector3.new(0, v77, 0)) * v_u_13)
					p_u_34.fadeFromBehind(p_u_35, v68, 0.4)
				else
					local v78 = v70 == 1 and 1.3 or 1
					local v79 = Vector3.new(1.05, 1.05, 0.8) * v_u_39 * v78
					local v80 = p_u_34.blob(v79, v_u_8, 0, v_u_10)
					p_u_34.pin(p_u_35, v_u_51, v80, CFrame.new(v74))
					local v81 = p_u_34.picture(v_u_39 * 1.02 * v78, v_u_4.ZohakuDrum, v_u_5, 0)
					local v82 = p_u_34.pin
					local v83 = CFrame.new
					local v84 = v79.Z * 0.52
					v82(p_u_35, v_u_51, v81, v83(v74 + Vector3.new(0, 0, v84)) * v_u_12)
					p_u_34.fadeFromBehind(p_u_35, v80, 0.45)
					p_u_34.fadeFromBehind(p_u_35, v81, 0.4)
					local v85 = {
						["body"] = v80,
						["head"] = v81,
						["size"] = v79,
						["face"] = v_u_39 * 1.02 * v78,
						["index"] = v70
					}
					table.insert(v_u_69, v85)
				end
			end
			if not v68 then
				local v86 = v_u_40 * 0
				local v87 = v_u_40 * 1
				local v88 = Vector3.new(v86, v87, 0)
				local v89 = v_u_39 * 0.95
				local v90 = v_u_39 * 0.1
				local v91 = v88 + Vector3.new(0, v89, v90)
				local v92 = CFrame.new(v91) * CFrame.Angles(0, 3.141592653589793, 0) * CFrame.Angles(0.35, 0, 0)
				p_u_34.pin(p_u_35, v_u_51, p_u_34.bar(Vector3.new(0.7, 0.6, 0.8) * v_u_39, v_u_7, 0, v_u_10), v92)
				local v93 = p_u_34.bar(Vector3.new(0.55, 0.35, 0.8) * v_u_39, v_u_7, 0, v_u_10)
				v93.Shape = v_u_11
				p_u_34.pin(p_u_35, v_u_51, v93, v92 * CFrame.new(0, v_u_39 * 0.05, v_u_39 * -0.7) * CFrame.Angles(0, 3.141592653589793, 0))
				local v94 = p_u_34.bar(Vector3.new(0.5, 0.18, 0.7) * v_u_39, v_u_6, 0, v_u_10)
				p_u_34.pin(p_u_35, v_u_51, v94, v92 * CFrame.new(0, v_u_39 * -0.32, v_u_39 * -0.55) * CFrame.Angles(-0.3, 0, 0))
				for _, v95 in { -1, 1 } do
					local v96 = p_u_34.bar(Vector3.new(0.12, 0.6, 0.3) * v_u_39, v_u_37, 0)
					v96.Shape = v_u_11
					p_u_34.pin(p_u_35, v_u_51, v96, v92 * CFrame.new(v95 * 0.24 * v_u_39, v_u_39 * 0.5, v_u_39 * 0.25) * CFrame.Angles(-0.5, 0, v95 * -0.25))
					p_u_34.pin(p_u_35, v_u_51, p_u_34.bar(Vector3.new(0.14, 0.1, 0.06) * v_u_39, v_u_9, 0), v92 * CFrame.new(v95 * 0.2 * v_u_39, v_u_39 * 0.12, v_u_39 * -0.41))
				end
			end
			local v97 = p_u_35.ticks
			local function v117(p98)
				-- upvalues: (copy) v_u_69, (ref) v_u_41, (ref) v_u_8, (copy) v_u_37, (ref) v_u_42, (copy) v_u_51, (copy) v_u_40, (copy) v_u_39, (ref) v_u_3, (copy) p_u_35, (ref) v_u_33, (ref) p_u_34, (ref) v_u_6, (ref) v_u_4
				for _, v99 in v_u_69 do
					local v100 = v99.index
					local v101 = os.clock() - v_u_41 - (v100 - 1) * 0.11
					local v102 = (v101 < 0 or v101 > 0.4) and 0 or 1 - v101 / 0.4
					local v103 = v102 * 0.28 + 1
					v99.body.Size = v99.size * v103
					local v104 = v99.head
					local v105 = v99.face * v103
					local v106 = v99.face * v103
					v104.Size = Vector3.new(v105, 0.05, v106)
					v99.body.Color = v_u_8:Lerp(v_u_37, v102 * 0.8)
				end
				if v_u_42 < 5 then
					local v107 = os.clock() - v_u_41
					while v_u_42 < 5 and v_u_42 * 0.11 <= v107 do
						v_u_42 = v_u_42 + 1
						local v108 = v_u_51.cf
						local v109 = CFrame.new
						local v110 = (v_u_42 - 1) / 5 * 3.141592653589793 * 2
						local v111 = math.sin(v110) * v_u_40
						local v112 = math.cos(v110) * v_u_40
						local v113 = Vector3.new(v111, v112, 0)
						local v114 = v_u_39 * 0.5
						local v115 = v108 * v109(v113 + Vector3.new(0, 0, v114))
						v_u_3.flash(v115.Position, v_u_37, v_u_39 * 1.8 * p_u_35.fx, 0.16)
						v_u_33(v115, v_u_39 * 0.8, v_u_39 * 3.4 * p_u_35.fx, v_u_39 * 1.6, v_u_37, 0.42)
						if v_u_42 ~= 5 then
							continue
						end
						local v116 = p_u_34.feetAt(p_u_35, p98, 0.15)
						v_u_3.ring(v116, v_u_6, 5 * p_u_35.fx, 0.5, v_u_4.ZohakuBoom)
						v_u_3.ring(v116, v_u_37, 7.5 * p_u_35.fx, 0.65, v_u_4.ZohakuBoom)
					end
				end
			end
			table.insert(v97, v117)
			p_u_34.particles(p_u_35, "AuraMode", v_u_37, {
				["rate"] = 0.3,
				["glow"] = 0.45,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end