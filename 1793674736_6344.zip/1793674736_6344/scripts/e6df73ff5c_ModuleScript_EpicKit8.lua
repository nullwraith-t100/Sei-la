local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Kit)
local v_u_123 = {
	["UP"] = Vector3.new(0, 1, 0),
	["NEON"] = Enum.Material.Neon,
	["SMOOTH"] = Enum.Material.SmoothPlastic,
	["GLASS"] = Enum.Material.Glass,
	["smooth"] = function(p5) -- name: smooth
		local v6 = math.clamp(p5, 0, 1)
		return v6 * v6 * (3 - v6 * 2)
	end,
	["outBack"] = function(p7) -- name: outBack
		local v8 = math.clamp(p7, 0, 1) - 1
		return v8 * 2.7 * v8 * v8 + 1 + v8 * 1.7 * v8
	end,
	["seq"] = function(p9, p10) -- name: seq
		local v11 = -1
		local v12 = {}
		local v13 = p10 or 1
		for v14, v15 in p9 do
			local v16 = v15[1]
			local v17 = math.clamp(v16, 0, 1)
			local v18 = v14 == 1 and 0 or (v14 == #p9 and 1 or v17)
			if v18 <= v11 then
				local v19 = v11 + 0.001
				v18 = math.min(v19, 1)
			end
			if v18 <= v11 then
				continue
			end
			local v20 = NumberSequenceKeypoint.new
			local v21 = v15[2] * v13
			table.insert(v12, v20(v18, v21))
			v11 = v18
		end
		if #v12 >= 2 then
			return NumberSequence.new(v12)
		end
		local v22 = #v12 ~= 1 and 0 or v12[1].Value
		return NumberSequence.new(v22)
	end,
	["holder"] = function(p23, p24) -- name: holder
		-- upvalues: (copy) v_u_3, (copy) v_u_1
		local v25 = Instance.new("Attachment")
		v25.WorldCFrame = CFrame.new(p23)
		v25.Parent = v_u_3.Terrain
		v_u_1:AddItem(v25, p24)
		return v25
	end,
	["flat"] = function(p26, p27) -- name: flat
		-- upvalues: (copy) v_u_123
		local v28 = v_u_123.holder
		local v29 = p27.lift or 0
		local v30 = v28(p26 + Vector3.new(0, v29, 0), p27.life + 0.3)
		local v31 = Instance.new("ParticleEmitter")
		v31.Enabled = false
		v31.Texture = p27.image
		v31.Color = ColorSequence.new(p27.color)
		v31.LightEmission = p27.emission
		v31.LightInfluence = 0
		v31.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
		v31.EmissionDirection = Enum.NormalId.Top
		v31.SpreadAngle = Vector2.zero
		v31.Speed = NumberRange.new(0.01)
		v31.Size = v_u_123.seq(p27.sizes, 0.5)
		v31.Transparency = v_u_123.seq(p27.alphas)
		local v32 = p27.squash
		if v32 then
			v31.Squash = v_u_123.seq(v32)
		end
		v31.Lifetime = NumberRange.new(p27.life)
		local v33 = p27.rot or math.random() * 360
		v31.Rotation = NumberRange.new(v33, v33)
		local v34 = p27.spin or 0
		v31.RotSpeed = NumberRange.new(v34, v34)
		if p27.flip == "4x4" then
			v31.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			v31.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		elseif p27.flip == "2x2" then
			v31.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v31.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
		v31.Parent = v30
		v31:Emit(1)
	end,
	["puff"] = function(p35, p36) -- name: puff
		-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_3, (copy) v_u_123
		local v37 = p36.life[2] or p36.life[1]
		if typeof(p35) ~= "CFrame" then
			p35 = CFrame.new(p35)
		end
		local v38 = p36.box
		local v39
		if v38 then
			v39 = v_u_4.part(v38, p35, p36.color, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v39, v37 + 0.3)
		else
			v39 = Instance.new("Attachment")
			v39.WorldCFrame = p35
			v39.Parent = v_u_3.Terrain
			v_u_1:AddItem(v39, v37 + 0.3)
		end
		local v40 = Instance.new("ParticleEmitter")
		v40.Enabled = false
		v40.Texture = p36.image
		v40.Color = ColorSequence.new(p36.color, p36.color2 or p36.color)
		v40.LightEmission = p36.emission
		v40.LightInfluence = 0
		v40.Lifetime = NumberRange.new(p36.life[1], v37)
		v40.Size = v_u_123.seq(p36.sizes, 0.5)
		v40.Transparency = v_u_123.seq(p36.alphas or {
			{ 0, 0 },
			{ 0.7, 0.2 },
			{ 1, 1 }
		})
		v40.Speed = NumberRange.new(p36.speed[1], p36.speed[2] or p36.speed[1])
		v40.SpreadAngle = p36.spread or Vector2.new(180, 180)
		v40.EmissionDirection = p36.dir or Enum.NormalId.Top
		v40.Acceleration = p36.accel or Vector3.new(0, 0, 0)
		v40.Drag = p36.drag or 0
		local v41 = p36.spin or 0
		v40.Rotation = NumberRange.new(0, 360)
		v40.RotSpeed = NumberRange.new(-v41, v41)
		v40.ZOffset = p36.zoff or 0
		if p36.orient then
			v40.Orientation = p36.orient
		end
		local v42 = p36.squash
		if v42 then
			v40.Squash = NumberSequence.new(v42)
		end
		if v38 then
			v40.Shape = Enum.ParticleEmitterShape.Box
			v40.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
		end
		local v43 = p36.flip
		if v43 == "4x4" or v43 == "4x4r" then
			v40.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid4x4
			local v44
			if v43 == "4x4r" then
				v44 = Enum.ParticleFlipbookMode.Random
			else
				v44 = Enum.ParticleFlipbookMode.OneShot
			end
			v40.FlipbookMode = v44
		elseif v43 == "2x2" then
			v40.FlipbookLayout = Enum.ParticleFlipbookLayout.Grid2x2
			v40.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
		end
		v40.Parent = v39
		v40:Emit(p36.count)
	end,
	["part"] = function(p45, p46, p47, p48) -- name: part
		-- upvalues: (copy) v_u_4, (copy) v_u_123, (copy) v_u_1
		local v49 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(0, -500, 0), p45, {
			["material"] = p46 or v_u_123.NEON,
			["transparency"] = p48
		})
		if p47 then
			v_u_1:AddItem(v49, p47)
		end
		return v49
	end,
	["wedge"] = function(p50, p51, p52, p53) -- name: wedge
		-- upvalues: (copy) v_u_123, (copy) v_u_4, (copy) v_u_1
		local v54 = Instance.new("WedgePart")
		v54.Anchored = true
		v54.CanCollide = false
		v54.CanQuery = false
		v54.CanTouch = false
		v54.CastShadow = false
		v54.Massless = true
		v54.Color = p50
		v54.Material = p51 or v_u_123.NEON
		v54.Transparency = p53 or 0
		v54.Size = Vector3.new(0.1, 0.1, 0.1)
		v54.CFrame = CFrame.new(0, -500, 0)
		v54.Parent = v_u_4.folder()
		if p52 then
			v_u_1:AddItem(v54, p52)
		end
		return v54
	end,
	["blade"] = function(p55, p56, p57, p58, p59, p60) -- name: blade
		local v61 = math.max(p58, 0.05)
		local v62 = p59 / 2
		local v63 = Vector3.new(p60, v61, v62)
		p55.Size = v63
		p55.CFrame = p57 * CFrame.new(0, v61 / 2, -p59 / 4)
		p56.Size = v63
		p56.CFrame = p57 * CFrame.new(0, v61 / 2, p59 / 4) * CFrame.Angles(0, 3.141592653589793, 0)
	end,
	["bar"] = function(p64, p65, p66, p67, p68) -- name: bar
		local v69 = p67 - p66
		local v70 = v69.Magnitude
		local v71 = math.max(v70, 0.05)
		local v72 = CFrame.lookAt
		local v73 = (p66 + p67) / 2
		if v69.Magnitude <= 0.001 then
			p67 = p66 + Vector3.new(0, 0, 1)
		end
		local v74 = v72(v73, p67)
		local v75 = Vector3.new(p68, p68, v71)
		p64.Size = v75
		p64.CFrame = v74
		p65.Size = v75
		p65.CFrame = v74 * CFrame.Angles(0, 0, 0.7853981633974483)
	end,
	["piece"] = function(p76, p77, p78) -- name: piece
		-- upvalues: (copy) v_u_2, (copy) v_u_4, (copy) v_u_1
		local v79 = v_u_2:FindFirstChild("EyePieces")
		if v79 then
			v79 = v79:FindFirstChild(p76)
		end
		if not (v79 and v79:IsA("MeshPart")) then
			return nil
		end
		local v80 = v79:Clone()
		local v81 = v79.Size
		local v82 = v81.X
		local v83 = v81.Y
		local v84 = v81.Z
		v80.Size = v81 * (p77 / math.max(v82, v83, v84, 0.01))
		v80.Anchored = true
		v80.CanCollide = false
		v80.CanQuery = false
		v80.CanTouch = false
		v80.CastShadow = false
		v80.Massless = true
		v80.CFrame = CFrame.new(0, -500, 0)
		v80.Parent = v_u_4.folder()
		if p78 then
			v_u_1:AddItem(v80, p78)
		end
		return v80
	end,
	["longX"] = function(p85) -- name: longX
		local v86 = p85.Size
		if v86.Y >= v86.X and v86.Y >= v86.Z then
			return CFrame.Angles(0, 0, -1.5707963267948966)
		elseif v86.Z >= v86.X and v86.Z >= v86.Y then
			return CFrame.Angles(0, 1.5707963267948966, 0)
		else
			return CFrame.identity
		end
	end,
	["longY"] = function(p87) -- name: longY
		local v88 = p87.Size
		if v88.X >= v88.Y and v88.X >= v88.Z then
			return CFrame.Angles(0, 0, 1.5707963267948966)
		elseif v88.Z >= v88.X and v88.Z >= v88.Y then
			return CFrame.Angles(-1.5707963267948966, 0, 0)
		else
			return CFrame.identity
		end
	end,
	["thinZ"] = function(p89) -- name: thinZ
		local v90 = p89.Size
		if v90.X <= v90.Y and v90.X <= v90.Z then
			return CFrame.Angles(0, 1.5707963267948966, 0)
		elseif v90.Y <= v90.X and v90.Y <= v90.Z then
			return CFrame.Angles(1.5707963267948966, 0, 0)
		else
			return CFrame.identity
		end
	end,
	["resize"] = function(p91, p92) -- name: resize
		local v93 = p91.Size
		local v94 = v93.X
		local v95 = v93.Y
		local v96 = v93.Z
		local v97 = p92 / math.max(v94, v95, v96, 0.01)
		local v98 = v97 - 1
		if math.abs(v98) > 0.005 then
			p91.Size = v93 * v97
		end
	end,
	["foe"] = function(p99) -- name: foe
		-- upvalues: (copy) v_u_3
		local v100 = v_u_3:FindFirstChild("MyEnemies")
		local v101
		if v100 then
			v101 = v100:FindFirstChild("Foe" .. p99)
		else
			v101 = nil
		end
		if v101 and v101:IsA("Model") then
			return v101
		else
			return nil
		end
	end,
	["beam"] = function(p102, p103, p104, p105, p106, p107, p108, p109) -- name: beam
		local v110 = Instance.new("Beam")
		v110.Attachment0 = p102
		v110.Attachment1 = p103
		v110.Texture = p104
		v110.TextureMode = Enum.TextureMode.Wrap
		v110.TextureLength = p108 or 4
		v110.TextureSpeed = p109 or 0
		v110.Color = ColorSequence.new(p105)
		v110.LightEmission = p107
		v110.LightInfluence = 0
		v110.FaceCamera = true
		v110.Width0 = p106
		v110.Width1 = p106
		v110.Segments = 1
		v110.Parent = p102
		return v110
	end,
	["trail"] = function(p111, p112, p113, p114, p115, p116, p117) -- name: trail
		local v118 = Instance.new("Attachment")
		local v119 = p114 / 2
		v118.Position = Vector3.new(0, v119, 0)
		v118.Parent = p111
		local v120 = Instance.new("Attachment")
		local v121 = -p114 / 2
		v120.Position = Vector3.new(0, v121, 0)
		v120.Parent = p111
		local v122 = Instance.new("Trail")
		v122.Attachment0 = v118
		v122.Attachment1 = v120
		v122.Color = ColorSequence.new(p112, p113)
		v122.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(0.6, 0.35), NumberSequenceKeypoint.new(1, 1) })
		v122.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0.25) })
		v122.Lifetime = p115
		v122.LightEmission = p116
		v122.LightInfluence = 0
		v122.FaceCamera = false
		v122.MinLength = 0.05
		if p117 then
			v122.Texture = p117
			v122.TextureMode = Enum.TextureMode.Stretch
		end
		v122.Parent = p111
		return v122
	end,
	["PORCELAIN"] = Color3.fromRGB(245, 236, 214),
	["COBALT"] = Color3.fromRGB(36, 70, 184),
	["NEEDLE"] = Color3.fromRGB(61, 224, 255)
}
v_u_123.FISH = {
	{
		["size"] = Vector3.new(0.2, 0.26, 1),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = true,
		["full"] = false,
		["off"] = CFrame.new(0, 0.13, 0),
		["color"] = v_u_123.PORCELAIN,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.2, 0.26, 1),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = true,
		["full"] = false,
		["off"] = CFrame.new(0, -0.13, 0) * CFrame.Angles(0, 0, 3.141592653589793),
		["color"] = v_u_123.PORCELAIN,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.06, 0.55, 0.28),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0, 0.62),
		["color"] = v_u_123.NEEDLE,
		["material"] = v_u_123.NEON
	},
	{
		["size"] = Vector3.new(0.05, 0.05, 0.6),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0, -0.78),
		["color"] = v_u_123.NEEDLE,
		["material"] = v_u_123.NEON
	},
	{
		["size"] = Vector3.new(0.22, 0.07, 0.55),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = true,
		["off"] = CFrame.new(0, 0.02, 0.12),
		["color"] = v_u_123.COBALT,
		["material"] = v_u_123.SMOOTH
	}
}
v_u_123.VASE = {
	{
		["size"] = Vector3.new(0.62, 0.55, 0.62),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0.32, 0),
		["color"] = v_u_123.PORCELAIN,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.62, 0.55, 0.62),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = true,
		["off"] = CFrame.new(0, 0.32, 0) * CFrame.Angles(0, 0.7853981633974483, 0),
		["color"] = v_u_123.PORCELAIN,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.66, 0.09, 0.66),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0.42, 0),
		["color"] = v_u_123.COBALT,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.66, 0.09, 0.66),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = true,
		["off"] = CFrame.new(0, 0.42, 0) * CFrame.Angles(0, 0.7853981633974483, 0),
		["color"] = v_u_123.COBALT,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.3, 0.32, 0.3),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0.74, 0),
		["color"] = v_u_123.PORCELAIN,
		["material"] = v_u_123.SMOOTH
	},
	{
		["size"] = Vector3.new(0.46, 0.08, 0.46),
		["off"] = nil,
		["color"] = nil,
		["material"] = nil,
		["wedge"] = false,
		["full"] = false,
		["off"] = CFrame.new(0, 0.92, 0),
		["color"] = v_u_123.COBALT,
		["material"] = v_u_123.SMOOTH
	}
}
function v_u_123.build(p124, p125, p126, p127) -- name: build
	-- upvalues: (copy) v_u_123
	local v128 = {}
	local v129 = {}
	for _, v130 in p124 do
		if p126 and v130.full then
			continue
		end
		local v131
		if v130.wedge then
			v131 = v_u_123.wedge(v130.color, v130.material, p127)
		else
			v131 = v_u_123.part(v130.color, v130.material, p127)
		end
		v131.Size = v130.size * p125
		table.insert(v128, v131)
		local v132 = CFrame.new(v130.off.Position * p125) * v130.off.Rotation
		table.insert(v129, v132)
	end
	return v128, v129
end
function v_u_123.side(p133) -- name: side
	local v134 = p133.X
	local v135 = p133.Z
	local v136 = Vector3.new(v134, 0, v135)
	return v136.Magnitude < 0.001 and Vector3.new(1, 0, 0) or v136.Unit:Cross(Vector3.new(0, 1, 0))
end
return v_u_123