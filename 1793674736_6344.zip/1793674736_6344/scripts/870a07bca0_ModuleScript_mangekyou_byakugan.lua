local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v_u_5 = require(script.Parent.Parent.Parent.Sfx)
local v_u_6 = require(v2.Shared.Config.Textures)
local v_u_7 = Color3.fromHex("E6E4FF")
local v_u_8 = Color3.fromRGB(252, 250, 255)
local v_u_9 = Color3.fromRGB(176, 158, 255)
local v_u_10 = Color3.fromRGB(118, 96, 226)
local v_u_11 = Enum.PartType.Ball
local function v_u_25(p12, p13, p14, p15, p16, p17) -- name: picture
	-- upvalues: (copy) v_u_4
	local v18 = v_u_4.part
	local v19 = p13 * 2
	local v20 = p13 * 2
	local v21 = v18(Vector3.new(v19, 0.05, v20), p12, p15, {
		["transparency"] = 1
	})
	local v22
	if p17 then
		v22 = { Enum.NormalId.Top, Enum.NormalId.Bottom }
	else
		v22 = { Enum.NormalId.Top }
	end
	for _, v23 in v22 do
		local v24 = Instance.new("Decal")
		v24.Face = v23
		v24.Texture = p14
		v24.Color3 = p15
		v24.Transparency = p16
		v24.Parent = v21
	end
	return v21
end
local function v_u_29(p26, p27) -- name: setAlpha
	for _, v28 in p26:GetChildren() do
		if not v28:IsA("Decal") then
			continue
		end
		v28.Transparency = p27
	end
end
return function(p_u_30)
	-- upvalues: (copy) v_u_25, (copy) v_u_1, (copy) v_u_29, (copy) v_u_3, (copy) v_u_6, (copy) v_u_8, (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_5
	local function v_u_48(p_u_31, p_u_32, p_u_33, p34, p35, p_u_36, p_u_37, p38, p39) -- name: flare
		-- upvalues: (ref) v_u_25, (ref) v_u_1, (copy) p_u_30, (ref) v_u_29
		local v_u_40 = p38 or 0
		local v_u_41 = v_u_25(p_u_31, p_u_32, p34, p35, v_u_40, p39)
		v_u_1:AddItem(v_u_41, p_u_36 + 0.1)
		p_u_30.animate(p_u_36, 0, function(p42)
			-- upvalues: (copy) v_u_41, (copy) p_u_32, (copy) p_u_33, (copy) p_u_31, (copy) p_u_36, (copy) p_u_37, (ref) v_u_29, (copy) v_u_40
			local v43 = 1 - (1 - p42) ^ 3
			local v44 = v_u_41
			local v45 = p_u_32 + (p_u_33 - p_u_32) * v43
			local v46 = v45 * 2
			local v47 = v45 * 2
			v44.Size = Vector3.new(v46, 0.05, v47)
			v_u_41.CFrame = p_u_31 * CFrame.Angles(0, p42 * p_u_36 * p_u_37, 0)
			v_u_29(v_u_41, v_u_40 + (1 - v_u_40) * p42 ^ 1.5)
			if p42 >= 1 then
				v_u_41:Destroy()
			end
		end)
	end
	local function v_u_75(p_u_49, p_u_50, p51, p52) -- name: starPop
		-- upvalues: (ref) v_u_25, (copy) p_u_30, (ref) v_u_3, (ref) v_u_6, (ref) v_u_1, (ref) v_u_8
		local v53 = v_u_25
		local v54 = p_u_30.facing
		local v55 = v_u_3.CurrentCamera
		local v56
		if v55 then
			local v57 = v55.CFrame.Position - p_u_49
			v56 = v57.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v57.Unit
		else
			v56 = Vector3.new(0, 0, 1)
		end
		local v_u_58 = v53(v54(p_u_49, v56), 0.05, v_u_6.PetStar, p51, 0)
		v_u_1:AddItem(v_u_58, 0.45)
		local v_u_59 = (math.random() - 0.5) * 3
		p_u_30.animate(0.32, 0, function(p60)
			-- upvalues: (copy) v_u_58, (copy) p_u_50, (ref) p_u_30, (copy) p_u_49, (ref) v_u_3, (copy) v_u_59
			local v61
			if p60 < 0.3 then
				local v62 = p60 / 0.3 - 1
				v61 = v62 * 2.9 * v62 * v62 + 1 + v62 * 1.9 * v62
			else
				v61 = 1 - ((p60 - 0.3) / 0.7) ^ 2
			end
			local v63 = v_u_58
			local v64 = p_u_50 * v61
			local v65 = math.max(v64, 0.05)
			local v66 = v65 * 2
			local v67 = v65 * 2
			v63.Size = Vector3.new(v66, 0.05, v67)
			local v68 = v_u_58
			local v69 = p_u_30.facing
			local v70 = p_u_49
			local v71 = p_u_49
			local v72 = v_u_3.CurrentCamera
			local v73
			if v72 then
				local v74 = v72.CFrame.Position - v71
				v73 = v74.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v74.Unit
			else
				v73 = Vector3.new(0, 0, 1)
			end
			v68.CFrame = v69(v70, v73) * CFrame.Angles(0, v_u_59 * p60, 0)
			if p60 >= 1 then
				v_u_58:Destroy()
			end
		end)
		if not p52 then
			p_u_30.pop(p_u_49, v_u_8, p_u_50 * 0.45, p_u_50 * 1.1, 0.14, 0.35)
		end
	end
	local function v102(p76, p77) -- name: palmShot
		-- upvalues: (ref) v_u_4, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_25, (ref) v_u_6, (copy) p_u_30, (ref) v_u_1, (ref) v_u_29, (ref) v_u_3
		local v_u_78 = p76.size
		local v_u_79 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p77, v_u_7, {
			["transparency"] = 1
		})
		local v_u_80 = v_u_4.part(Vector3.new(3.6, 3.6, 1) * v_u_78, p77, v_u_8, {
			["transparency"] = 0.3
		})
		local v81 = Instance.new("SpecialMesh")
		v81.MeshType = Enum.MeshType.Sphere
		v81.Parent = v_u_80
		local v_u_82 = v_u_4.part(Vector3.new(5, 5, 1.6) * v_u_78, p77, v_u_9, {
			["transparency"] = 0.72
		})
		local v83 = Instance.new("SpecialMesh")
		v83.MeshType = Enum.MeshType.Sphere
		v83.Parent = v_u_82
		local v_u_84 = v_u_25(p77, 1.5 * v_u_78, v_u_6.Ring, v_u_7, 0.1, true)
		local v_u_85 = v_u_25(p77, 1 * v_u_78, v_u_6.ByakuStar, v_u_7, 0)
		local v_u_86 = {
			v_u_80,
			v_u_82,
			v_u_84,
			v_u_85
		}
		p_u_30.streak(v_u_79, v_u_8, v_u_9, 2.6 * v_u_78, 0.13)
		if p76.mine then
			p_u_30.light(v_u_79, v_u_9, 9 * v_u_78)
		end
		for _, v87 in v_u_86 do
			v_u_1:AddItem(v87, 3)
		end
		v_u_1:AddItem(v_u_79, 3)
		local v_u_88 = false
		return {
			["place"] = function(p89, p90) -- name: place
				-- upvalues: (copy) v_u_79, (copy) v_u_80, (copy) v_u_82, (copy) v_u_78, (copy) v_u_84, (ref) v_u_29, (ref) p_u_30, (ref) v_u_3, (copy) v_u_85
				local v91 = p89.Position
				v_u_79.CFrame = p89
				v_u_80.CFrame = p89
				v_u_82.CFrame = p89 * CFrame.new(0, 0, 0.35 * v_u_78)
				local v92 = p90 * 8 % 1
				local v93 = v_u_84
				local v94 = (v92 * 1.1 + 1.1) * v_u_78
				local v95 = v94 * 2
				local v96 = v94 * 2
				v93.Size = Vector3.new(v95, 0.05, v96)
				v_u_29(v_u_84, v92 * 0.85 + 0.1)
				v_u_84.CFrame = p_u_30.facing(v91 + p89.LookVector * 0.5 * v_u_78, p89.LookVector)
				local v97 = v_u_3.CurrentCamera
				local v98
				if v97 then
					local v99 = v97.CFrame.Position - v91
					v98 = v99.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v99.Unit
				else
					v98 = Vector3.new(0, 0, 1)
				end
				v_u_85.CFrame = p_u_30.facing(v91 + v98 * 0.9 * v_u_78, v98) * CFrame.Angles(0, p90 * 14, 0)
			end,
			["stop"] = function(_) -- name: stop
				-- upvalues: (ref) v_u_88, (copy) v_u_79, (ref) v_u_1, (copy) v_u_86
				if not v_u_88 then
					v_u_88 = true
					local v100 = v_u_79:FindFirstChildWhichIsA("PointLight")
					if v100 then
						v100:Destroy()
					end
					v_u_1:AddItem(v_u_79, 0.2)
					for _, v101 in v_u_86 do
						v101:Destroy()
					end
				end
			end
		}
	end
	local function v112(p103, p_u_104) -- name: palmImpact
		-- upvalues: (copy) p_u_30, (copy) v_u_48, (ref) v_u_6, (ref) v_u_7, (ref) v_u_3, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9
		local v_u_105 = p103.size
		local v_u_106 = p103.dir
		local v_u_107 = 0
		p_u_30.after(0, function()
			-- upvalues: (ref) v_u_48, (ref) p_u_30, (copy) p_u_104, (copy) v_u_106, (copy) v_u_107, (copy) v_u_105, (ref) v_u_6, (ref) v_u_7
			v_u_48(p_u_30.facing(p_u_104 + v_u_106 * (v_u_107 * 1.2 + 0.4) * v_u_105, v_u_106), 1.2 * v_u_105, (v_u_107 * 1.6 + 5) * v_u_105, v_u_6.Ring, v_u_7, 0.22, 0, 0.05, true)
		end)
		local v_u_108 = 1
		p_u_30.after(0.05, function()
			-- upvalues: (ref) v_u_48, (ref) p_u_30, (copy) p_u_104, (copy) v_u_106, (copy) v_u_108, (copy) v_u_105, (ref) v_u_6, (ref) v_u_7
			v_u_48(p_u_30.facing(p_u_104 + v_u_106 * (v_u_108 * 1.2 + 0.4) * v_u_105, v_u_106), 1.2 * v_u_105, (v_u_108 * 1.6 + 5) * v_u_105, v_u_6.Ring, v_u_7, 0.22, 0, 0.05, true)
		end)
		local v109 = v_u_3.CurrentCamera
		local v110
		if v109 then
			local v111 = v109.CFrame.Position - p_u_104
			v110 = v111.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v111.Unit
		else
			v110 = Vector3.new(0, 0, 1)
		end
		v_u_48(p_u_30.facing(p_u_104 + v110, v110), 0.8 * v_u_105, 3.4 * v_u_105, v_u_6.ByakuStar, v_u_7, 0.24, 9)
		p_u_30.pop(p_u_104, v_u_8, 1.2 * v_u_105, 5.5 * v_u_105, 0.18, 0.35)
		v_u_4.ring(p_u_30.ground(p_u_104), v_u_9, p103.ability.radius * v_u_105, 0.28, v_u_6.Ring)
		p_u_30.burst("Impact", p_u_104, v_u_9, 0.9 * v_u_105)
		if not p103.lite then
			p_u_30.spikes(p_u_104, v_u_8, 5, 5 * v_u_105, 0.16, v_u_106, 0.9)
		end
		p_u_30.hitSound(p_u_104)
	end
	local v_u_113 = {}
	setmetatable(v_u_113, {
		["__mode"] = "k"
	})
	local function v127(p114, p115, p116) -- name: sightRing
		-- upvalues: (copy) p_u_30, (ref) v_u_25, (ref) v_u_6, (ref) v_u_9, (ref) v_u_1, (ref) v_u_29, (ref) v_u_8
		local v117 = p114.size
		local v_u_118 = p114.ability.radius * v117
		local v119 = p_u_30.ground(p115, 0)
		local v120 = math.max(p116, 0.1)
		local v_u_121 = v_u_25(CFrame.new(v119 + Vector3.new(0, 0.25, 0)), v_u_118 * 1.6, v_u_6.Ring, v_u_9, 0.2, true)
		v_u_1:AddItem(v_u_121, v120 + 0.2)
		p_u_30.animate(v120, 0, function(p122)
			-- upvalues: (copy) v_u_121, (copy) v_u_118, (ref) v_u_29
			local v123 = v_u_121
			local v124 = v_u_118 * (1.6 - 0.6 * p122)
			local v125 = v124 * 2
			local v126 = v124 * 2
			v123.Size = Vector3.new(v125, 0.05, v126)
			v_u_29(v_u_121, 0.2 + 0.5 * p122)
			if p122 >= 1 then
				v_u_121:Destroy()
			end
		end)
		if not p114.lite then
			p_u_30.inward(v119 + Vector3.new(0, 2, 0), v_u_8, 8, v_u_118, v120)
		end
	end
	local function v155(p128, p129) -- name: starWaves
		-- upvalues: (copy) p_u_30, (copy) v_u_75, (ref) v_u_8, (ref) v_u_10, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6, (copy) v_u_48, (ref) v_u_3, (ref) v_u_7
		local v_u_130 = p128.size
		local v_u_131 = p128.ability.radius * v_u_130
		local v_u_132 = p_u_30.ground(p129, 0)
		local v_u_133 = p128.lite
		local v_u_134 = math.random() * 3.141592653589793 * 2
		local v135 = v_u_133 and 3 or 4
		for v_u_136 = 1, v135 do
			local v_u_137 = 2 ^ v_u_136
			local v_u_138 = v_u_131 * (v_u_136 * 0.21 + 0.1)
			p_u_30.after((v_u_136 - 1) * 0.085, function()
				-- upvalues: (copy) v_u_137, (copy) v_u_134, (copy) v_u_136, (copy) v_u_132, (copy) v_u_138, (copy) v_u_130, (ref) v_u_75, (ref) v_u_8, (ref) v_u_10, (copy) v_u_133, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
				for v139 = 1, v_u_137 do
					local v140 = v_u_134 + v_u_136 * 0.45 + (v139 - 1) / v_u_137 * 3.141592653589793 * 2
					local v141 = v_u_132
					local v142 = math.cos(v140) * v_u_138
					local v143 = (1.4 + math.random() * 2.4) * v_u_130
					local v144 = math.sin(v140) * v_u_138
					local v145 = v141 + Vector3.new(v142, v143, v144)
					local v146 = v_u_75
					local v147 = (4.4 - v_u_136 * 0.4) * v_u_130
					local v148
					if v139 % 2 == 0 then
						v148 = v_u_8
					else
						v148 = v_u_10
					end
					v146(v145, v147, v148, v_u_133)
				end
				v_u_4.ring(v_u_132, v_u_9, v_u_138 * 1.15, 0.25, v_u_6.Ring)
			end)
		end
		p_u_30.after(v135 * 0.085 + 0.02, function()
			-- upvalues: (copy) v_u_132, (copy) v_u_130, (ref) v_u_48, (ref) p_u_30, (ref) v_u_3, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8, (copy) v_u_131, (ref) v_u_10, (copy) v_u_133
			local v149 = v_u_132 + Vector3.new(0, 7, 0) * v_u_130
			local v150 = v_u_48
			local v151 = p_u_30.facing
			local v152 = v_u_3.CurrentCamera
			local v153
			if v152 then
				local v154 = v152.CFrame.Position - v149
				v153 = v154.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v154.Unit
			else
				v153 = Vector3.new(0, 0, 1)
			end
			v150(v151(v149, v153), 2 * v_u_130, 9.5 * v_u_130, v_u_6.ByakuStar, v_u_7, 0.45, 5)
			v_u_4.flash(v149, v_u_8, 11 * v_u_130, 0.2)
			v_u_4.ring(v_u_132, v_u_7, v_u_131, 0.35, v_u_6.Shockwave)
			v_u_4.ring(v_u_132, v_u_10, v_u_131 * 1.2, 0.45, v_u_6.Ring)
			if not v_u_133 then
				p_u_30.spikes(v149, v_u_8, 6, 7 * v_u_130, 0.2)
			end
			p_u_30.hitSound(v149)
		end)
	end
	local v_u_156 = {}
	setmetatable(v_u_156, {
		["__mode"] = "k"
	})
	local function v_u_160(p157) -- name: dropDome
		p157.inner:Destroy()
		p157.shell:Destroy()
		for _, v158 in p157.streaks do
			v158:Destroy()
		end
		for _, v159 in p157.stars do
			v159:Destroy()
		end
	end
	local function v_u_226(p161, p162, p163) -- name: spinUp
		-- upvalues: (copy) p_u_30, (ref) v_u_4, (ref) v_u_8, (ref) v_u_11, (ref) v_u_9, (ref) v_u_1, (ref) v_u_25, (ref) v_u_6, (ref) v_u_3
		local v_u_164 = p161.size
		local v165 = p161.lite
		local v_u_166 = p_u_30.ground(p162, 0)
		local v_u_167 = math.max(p163, 0.12)
		local v168 = v_u_167 + 2
		local v169 = {
			["shape"] = nil,
			["transparency"] = 0.76,
			["shape"] = v_u_11
		}
		local v_u_170 = v_u_4.part(Vector3.new(2, 2, 2), CFrame.new(v_u_166), v_u_8, v169)
		local v171 = {
			["shape"] = nil,
			["transparency"] = 0.84,
			["shape"] = v_u_11
		}
		local v_u_172 = v_u_4.part(Vector3.new(3, 3, 3), CFrame.new(v_u_166), v_u_9, v171)
		v_u_1:AddItem(v_u_170, v168)
		v_u_1:AddItem(v_u_172, v168)
		local v_u_173 = {}
		local v_u_174 = {}
		for v175 = 1, v165 and 6 or 12 do
			local v176 = v_u_4.part
			local v177 = Vector3.new(0.28, 0.28, 2) * v_u_164
			local v178 = CFrame.new(v_u_166)
			local v179
			if v175 % 2 == 0 then
				v179 = v_u_8
			else
				v179 = v_u_9
			end
			local v180 = v176(v177, v178, v179)
			v_u_1:AddItem(v180, v168)
			table.insert(v_u_174, v180)
			local v181 = v175 * 0.618 % 1 * 0.78 + 0.08
			table.insert(v_u_173, v181)
		end
		local v_u_182 = {}
		if not v165 then
			for _ = 1, 5 do
				local v183 = v_u_25(CFrame.new(v_u_166), 0.7 * v_u_164, v_u_6.PetStar, v_u_8, 0)
				v_u_1:AddItem(v183, v168)
				table.insert(v_u_182, v183)
			end
		end
		local v_u_184 = {
			["g"] = nil,
			["inner"] = nil,
			["shell"] = nil,
			["streaks"] = nil,
			["lats"] = nil,
			["stars"] = nil,
			["radius"] = nil,
			["spin"] = 0,
			["taken"] = false,
			["g"] = v_u_166,
			["inner"] = v_u_170,
			["shell"] = v_u_172,
			["streaks"] = v_u_174,
			["lats"] = v_u_173,
			["stars"] = v_u_182,
			["radius"] = 2 * v_u_164
		}
		local v_u_185 = os.clock()
		local v_u_186 = v_u_185
		p_u_30.runNow(function()
			-- upvalues: (copy) v_u_184, (copy) v_u_170, (ref) v_u_186, (copy) v_u_185, (copy) v_u_167, (copy) v_u_164, (copy) v_u_172, (copy) v_u_174, (copy) v_u_173, (copy) v_u_166, (copy) v_u_182, (ref) p_u_30, (ref) v_u_3
			if v_u_184.taken or not v_u_170.Parent then
				return false
			end
			local v187 = os.clock()
			local v188 = v187 - v_u_186
			local v189 = math.min(v188, 0.05)
			v_u_186 = v187
			local v190 = (v187 - v_u_185) / v_u_167
			local v191 = math.clamp(v190, 0, 1)
			local v192 = (v191 ^ 0.7 * 7 + 2) * v_u_164
			v_u_184.radius = v192
			local v193 = v_u_184
			v193.spin = v193.spin + v189 * (v191 * 26 + 5)
			v_u_170.Size = Vector3.new(1, 1, 1) * v192 * 1.84
			v_u_172.Size = Vector3.new(1, 1, 1) * v192 * 2
			v_u_170.Transparency = 0.76 - v191 * 0.1
			local v194 = #v_u_174
			for v195, v196 in v_u_174 do
				local v197 = v_u_173[v195] * 1.35
				local v198 = v_u_184.spin * (v195 % 3 * 0.15 + 1) + (v195 - 1) / v194 * 3.141592653589793 * 2
				local v199 = v192 * 1.03 * math.cos(v197)
				local v200 = v_u_166
				local v201 = math.cos(v198) * v199
				local v202 = v192 * 1.03 * math.sin(v197)
				local v203 = math.sin(v198) * v199
				local v204 = v200 + Vector3.new(v201, v202, v203)
				local v205 = -math.sin(v198)
				local v206 = math.cos(v198)
				local v207 = Vector3.new(v205, 0, v206)
				local v208 = 0.28 * v_u_164
				local v209 = 0.28 * v_u_164
				local v210 = v199 * 0.9
				local v211 = math.max(v210, 0.5)
				v196.Size = Vector3.new(v208, v209, v211)
				v196.CFrame = CFrame.lookAt(v204, v204 + v207)
			end
			for v212, v213 in v_u_182 do
				local v214 = v212 * 0.2 + 0.25
				local v215 = -v_u_184.spin * 0.8 + v212 * 1.3
				local v216 = v192 * 1.05 * math.cos(v214)
				local v217 = v_u_166
				local v218 = math.cos(v215) * v216
				local v219 = v192 * 1.05 * math.sin(v214)
				local v220 = math.sin(v215) * v216
				local v221 = v217 + Vector3.new(v218, v219, v220)
				local v222 = p_u_30.facing
				local v223 = v_u_3.CurrentCamera
				local v224
				if v223 then
					local v225 = v223.CFrame.Position - v221
					v224 = v225.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v225.Unit
				else
					v224 = Vector3.new(0, 0, 1)
				end
				v213.CFrame = v222(v221, v224) * CFrame.Angles(0, v_u_184.spin, 0)
			end
			return true
		end)
		v_u_4.ring(v_u_166, v_u_9, 6 * v_u_164, v_u_167 + 0.1, v_u_6.Ring)
		return v_u_184
	end
	local function v_u_277(p227, p_u_228, p_u_229) -- name: rotationBlast
		-- upvalues: (copy) p_u_30, (ref) v_u_29, (copy) v_u_160, (ref) v_u_3, (copy) v_u_48, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_4, (ref) v_u_9, (ref) v_u_10, (copy) v_u_75, (ref) v_u_5
		local v_u_230 = p227.size
		local v231 = p227.lite
		local v_u_232 = p_u_228.g
		p_u_228.taken = true
		local v_u_233 = p_u_228.radius
		local v_u_234 = p_u_228.spin
		local v_u_235 = #p_u_228.streaks
		p_u_30.animate(0.4, 0, function(p236)
			-- upvalues: (copy) v_u_233, (copy) p_u_229, (copy) p_u_228, (copy) v_u_234, (copy) v_u_235, (copy) v_u_232, (copy) v_u_230, (ref) v_u_29, (ref) v_u_160
			local v237 = 1 - (1 - p236) ^ 3
			local v238 = v_u_233 + (p_u_229 - v_u_233) * v237
			p_u_228.inner.Size = Vector3.new(1, 1, 1) * v238 * 1.84
			p_u_228.shell.Size = Vector3.new(1, 1, 1) * v238 * 2
			p_u_228.inner.Transparency = 0.66 + 0.34 * p236
			p_u_228.shell.Transparency = 0.84 + 0.16 * p236
			for v239, v240 in p_u_228.streaks do
				local v241 = p_u_228.lats[v239] * 1.35 * (1 - v237)
				local v242 = v_u_234 + p236 * 2.2 + (v239 - 1) / v_u_235 * 3.141592653589793 * 2
				local v243 = v238 * math.cos(v241)
				local v244 = v_u_232
				local v245 = math.cos(v242) * v243
				local v246 = 0.6 + v238 * math.sin(v241)
				local v247 = math.sin(v242) * v243
				local v248 = v244 + Vector3.new(v245, v246, v247)
				local v249 = -math.sin(v242)
				local v250 = math.cos(v242)
				local v251 = Vector3.new(v249, 0, v250)
				local v252 = 0.3 * v_u_230 * (1 - p236 * 0.6)
				local v253 = 0.3 * v_u_230
				local v254 = v243 * 0.7
				local v255 = math.max(v254, 0.5)
				v240.Size = Vector3.new(v252, v253, v255)
				v240.CFrame = CFrame.lookAt(v248, v248 + v251)
				v240.Transparency = p236 ^ 2
			end
			for _, v256 in p_u_228.stars do
				v_u_29(v256, p236)
			end
			if p236 >= 1 then
				v_u_160(p_u_228)
			end
		end)
		local v257 = v_u_232 + Vector3.new(0, 15, 0) * v_u_230
		local v258 = v_u_3.CurrentCamera
		local v259
		if v258 then
			local v260 = v258.CFrame.Position - v257
			v259 = v260.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v260.Unit
		else
			v259 = Vector3.new(0, 0, 1)
		end
		local v261 = p_u_30.facing(v257, v259)
		v_u_48(v261, 3 * v_u_230, 13 * v_u_230, v_u_6.ByakuStar, v_u_7, 0.55, 3, 0)
		v_u_48(v261 * CFrame.new(0, 0.06, 0), 1.6 * v_u_230, 6.5 * v_u_230, p_u_30.iris("mangekyou_byakugan"), v_u_8, 0.55, -1.5, 0)
		v_u_4.flash(v_u_232 + Vector3.new(0, 4, 0), v_u_8, p_u_229 * 0.9, 0.25)
		v_u_4.ring(v_u_232, v_u_7, p_u_229, 0.5, v_u_6.Shockwave)
		v_u_4.ring(v_u_232, v_u_9, p_u_229 * 1.15, 0.6, v_u_6.Ring)
		v_u_4.ring(v_u_232, v_u_10, p_u_229 * 0.7, 0.4, v_u_6.Ring)
		p_u_30.burst("Flash", v_u_232 + Vector3.new(0, 3, 0), v_u_7, 0.7)
		p_u_30.spikes(v_u_232 + Vector3.new(0, 1.5, 0), v_u_8, v231 and 6 or 14, p_u_229, 0.35, nil, nil, true)
		if not v231 then
			local v262 = math.random() * 3.141592653589793 * 2
			for v_u_263 = 1, 10 do
				local v_u_264 = v262 + v_u_263 / 10 * 3.141592653589793 * 2
				local v_u_265 = p_u_229 * (0.62 + math.random() * 0.3)
				p_u_30.after(v_u_263 * 0.02 + 0.12, function()
					-- upvalues: (ref) v_u_75, (copy) v_u_232, (copy) v_u_264, (copy) v_u_265, (copy) v_u_230, (copy) v_u_263, (ref) v_u_8, (ref) v_u_9
					local v266 = v_u_75
					local v267 = v_u_232
					local v268 = v_u_264
					local v269 = math.cos(v268) * v_u_265
					local v270 = (1.5 + math.random() * 2) * v_u_230
					local v271 = v_u_264
					local v272 = math.sin(v271) * v_u_265
					local v273 = v267 + Vector3.new(v269, v270, v272)
					local v274 = 3 * v_u_230
					local v275
					if v_u_263 % 2 == 0 then
						v275 = v_u_8
					else
						v275 = v_u_9
					end
					v266(v273, v274, v275, false)
				end)
			end
			local v276 = { v_u_8, v_u_9, v_u_10 }
			p_u_30.chunks(v_u_232 + Vector3.new(0, 1, 0), v276, 10, 45, 0.9, 1, true, 0.7)
		end
		v_u_5.play("Explosion", {
			["at"] = v_u_232,
			["volume"] = p227.mine and 0.9 or 0.5
		})
		if p227.mine then
			v_u_4.shake(0.5, 0.45)
		end
	end
	local v305 = {
		["mangekyou_byakugan_a"] = {
			["cast"] = function(p278) -- name: cast
				-- upvalues: (ref) v_u_4, (ref) v_u_8, (copy) v_u_48, (copy) p_u_30, (ref) v_u_6, (ref) v_u_7
				local v279 = p278.size
				local v280 = p278.eye + p278.dir * 1.3
				v_u_4.flash(v280, v_u_8, 3.2 * v279, 0.1)
				v_u_48(p_u_30.facing(v280, p278.dir), 0.6 * v279, 2.6 * v279, v_u_6.Ring, v_u_7, 0.13, 0, 0.1, true)
				if not p278.lite then
					v_u_48(p_u_30.facing(v280, -p278.dir), 0.5 * v279, 1.4 * v279, v_u_6.ByakuStar, v_u_7, 0.12, 20)
				end
			end,
			["shot"] = v102,
			["impact"] = v112,
			["hit"] = function(p281, p282, _) -- name: hit
				-- upvalues: (copy) p_u_30, (ref) v_u_9, (ref) v_u_8
				p_u_30.burst("Impact", p282, v_u_9, 0.6)
				if not p281.lite then
					p_u_30.glint(p282, v_u_8, 2.4, 0.12)
				end
			end
		},
		["mangekyou_byakugan_e"] = {
			["cast"] = function(p283) -- name: cast
				-- upvalues: (copy) p_u_30, (ref) v_u_9, (copy) v_u_48, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8
				p_u_30.skillCast(p283, v_u_9)
				local v284 = p283.size
				local v285 = p283.eye + p283.dir * 1.2
				v_u_48(p_u_30.facing(v285, -p283.dir), 0.8 * v284, 2.6 * v284, v_u_6.ByakuStar, v_u_7, 0.3, 10)
				if not p283.lite then
					local v286 = p283.target + Vector3.new(0, 2, 0)
					p_u_30.alongPath(v285, v286, 6, 0.12, function(p287)
						-- upvalues: (ref) p_u_30, (ref) v_u_8
						p_u_30.glint(p287, v_u_8, 1.6, 0.12)
					end)
				end
			end,
			["windup"] = v127,
			["land"] = v155,
			["hit"] = function(p_u_288, p_u_289, _) -- name: hit
				-- upvalues: (copy) v_u_113, (copy) p_u_30, (copy) v_u_75, (ref) v_u_8, (ref) v_u_9
				local v290 = (v_u_113[p_u_288] or 0) + 1
				v_u_113[p_u_288] = v290
				local v291 = p_u_30.after
				local v292 = v290 * 0.05
				v291(math.min(v292, 0.6), function()
					-- upvalues: (ref) v_u_75, (copy) p_u_289, (copy) p_u_288, (ref) v_u_8, (ref) p_u_30, (ref) v_u_9
					v_u_75(p_u_289 + Vector3.new(0, 0.8, 0), 3.8 * p_u_288.size, v_u_8, p_u_288.lite)
					p_u_30.burst("Impact", p_u_289, v_u_9, 0.7)
				end)
			end
		},
		["mangekyou_byakugan_r"] = {
			["cast"] = function(p293) -- name: cast
				-- upvalues: (copy) p_u_30, (ref) v_u_9, (copy) v_u_48, (ref) v_u_6, (ref) v_u_7, (ref) v_u_4
				p_u_30.skillCast(p293, v_u_9, true)
				local v294 = p293.size
				local v295 = p293.eye + p293.dir * 1.4
				v_u_48(p_u_30.facing(v295, -p293.dir), 1 * v294, 4 * v294, v_u_6.ByakuStar, v_u_7, 0.32, 12)
				if p293.mine then
					v_u_4.shake(0.15, 0.15)
				end
			end,
			["windup"] = function(p296, p297, p298) -- name: windup
				-- upvalues: (copy) v_u_156, (copy) v_u_226
				v_u_156[p296] = v_u_226(p296, p297, p298)
			end,
			["land"] = function(p299, p300) -- name: land
				-- upvalues: (copy) v_u_156, (copy) v_u_226, (copy) v_u_277
				local v301 = p299.ability.radius * p299.size
				local v302 = v_u_156[p299]
				v_u_156[p299] = nil
				v_u_277(p299, v302 or v_u_226(p299, p300, 0.05), v301)
			end,
			["hit"] = function(p303, p304, _) -- name: hit
				-- upvalues: (copy) p_u_30, (ref) v_u_9, (ref) v_u_8
				p_u_30.burst("Impact", p304, v_u_9, 1)
				if not p303.lite then
					p_u_30.glint(p304, v_u_8, 3.2, 0.15)
				end
			end
		}
	}
	return v305
end