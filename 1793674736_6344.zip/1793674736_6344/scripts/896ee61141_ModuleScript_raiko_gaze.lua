local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.Parent.Kit)
require(script.Parent.Parent.LookTypes)
local v5 = require(script.Parent.Parent.Preload)
local v_u_6 = require(script.Parent.Parent.Parent.Sfx)
local v_u_7 = require(v_u_2.Shared.Config.Textures)
v5.images({ v_u_7.RaikoSpark, v_u_7.RaikoPillar })
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Color3.fromHex("FF9A1F")
local v_u_10 = Color3.fromHex("FFF4D0")
local v_u_11 = Color3.fromRGB(255, 206, 60)
local v_u_12 = Color3.fromRGB(214, 74, 12)
local v_u_13 = Color3.fromRGB(10, 6, 4)
local v_u_14 = Color3.fromRGB(92, 70, 52)
local v_u_15 = Enum.ParticleFlipbookLayout.Grid2x2
local v_u_16 = Enum.Material.SmoothPlastic
local function v_u_28(p17, p18, p19, p20, p21) -- name: picture
	-- upvalues: (copy) v_u_4
	local v22 = v_u_4.part
	local v23 = p18 * 2
	local v24 = p18 * 2
	local v25 = v22(Vector3.new(v23, 0.05, v24), p17, p20, {
		["transparency"] = 1
	})
	for _, v26 in { Enum.NormalId.Top, Enum.NormalId.Bottom } do
		local v27 = Instance.new("Decal")
		v27.Face = v26
		v27.Texture = p19
		v27.Color3 = p20
		v27.Transparency = p21
		v27.Parent = v25
	end
	return v25
end
local function v_u_32(p29, p30) -- name: setAlpha
	for _, v31 in p29:GetChildren() do
		if not v31:IsA("Decal") then
			continue
		end
		v31.Transparency = p30
	end
end
local function v_u_36(p33, p34) -- name: emitter
	-- upvalues: (copy) v_u_15
	local v35 = Instance.new("ParticleEmitter")
	v35.Texture = p34.texture
	v35.FlipbookLayout = v_u_15
	v35.FlipbookMode = Enum.ParticleFlipbookMode.Random
	v35.FlipbookFramerate = NumberRange.new(p34.still and 0 or 14)
	v35.FlipbookStartRandom = true
	v35.Color = p34.color
	v35.Size = p34.size
	v35.Transparency = p34.alpha or NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.6, 0), NumberSequenceKeypoint.new(1, 1) })
	v35.Lifetime = p34.life
	v35.Speed = p34.speed
	v35.SpreadAngle = p34.spread or Vector2.new(180, 180)
	v35.LightEmission = p34.light or 0.8
	v35.LightInfluence = 0
	v35.Rotation = p34.rot or NumberRange.new(0, 360)
	v35.Rate = p34.rate or 0
	v35.ZOffset = p34.z or 1
	if p34.box then
		v35.Shape = Enum.ParticleEmitterShape.Box
		v35.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
	end
	v35.Parent = p33
	return v35
end
local function v_u_43(p37, p38, p39, p40) -- name: crackle
	-- upvalues: (copy) v_u_7, (copy) v_u_11, (copy) v_u_10, (copy) v_u_3, (copy) v_u_36, (copy) v_u_1
	local v41 = {
		["texture"] = nil,
		["color"] = nil,
		["size"] = nil,
		["life"] = nil,
		["speed"] = nil,
		["still"] = true,
		["texture"] = v_u_7.RaikoSpark,
		["color"] = ColorSequence.new(p40 or v_u_11, v_u_10),
		["size"] = NumberSequence.new(p38, p38 * 1.15),
		["life"] = NumberRange.new(0.14, 0.22),
		["speed"] = NumberRange.new(0.5, 2)
	}
	local v42 = Instance.new("Attachment")
	v42.Parent = v_u_3.Terrain
	v42.WorldPosition = p37
	v_u_36(v42, v41):Emit(p39)
	v_u_1:AddItem(v42, v41.life.Max + 0.3)
end
local function v_u_54(p44, p45, p46, p47, p48, p49) -- name: bolt
	-- upvalues: (copy) v_u_7
	local v50 = Instance.new("Attachment")
	v50.Parent = p44
	v50.WorldPosition = p45
	local v51 = Instance.new("Attachment")
	v51.Parent = p44
	v51.WorldPosition = p46
	local v52 = Instance.new("Beam")
	v52.Attachment0 = v50
	v52.Attachment1 = v51
	v52.Texture = p49 or v_u_7.RaikoPillar
	v52.TextureMode = Enum.TextureMode.Wrap
	local v53 = p47 * 2.2
	v52.TextureLength = math.max(v53, 2)
	v52.TextureSpeed = 3
	v52.Color = ColorSequence.new(p48)
	v52.LightEmission = 1
	v52.LightInfluence = 0
	v52.Brightness = 1.6
	v52.FaceCamera = true
	v52.Width0 = p47
	v52.Width1 = p47
	v52.Segments = 1
	v52.Parent = p44
	return v52
end
local function v_u_81(p55, p_u_56, p_u_57) -- name: slitBlink
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_11, (copy) v_u_13, (copy) v_u_16, (copy) v_u_1
	local v58 = v_u_3.CurrentCamera
	local v59
	if v58 then
		local v60 = v58.CFrame.Position - p55
		v59 = v60.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v60.Unit
	else
		v59 = Vector3.new(0, 0, 1)
	end
	local v61 = CFrame.lookAt(p55 + v59 * 0.8, p55 + v59 * 2)
	local v_u_62 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v61, v_u_11, {
		["transparency"] = 0.05
	})
	local v63 = {
		["material"] = v_u_16
	}
	local v_u_64 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), v61 * CFrame.new(0, 0, -0.06), v_u_13, v63)
	for _, v65 in { v_u_62, v_u_64 } do
		local v66 = Instance.new("SpecialMesh")
		v66.MeshType = Enum.MeshType.Sphere
		v66.Parent = v65
		v_u_1:AddItem(v65, p_u_57 + 0.1)
	end
	local v_u_67 = os.clock()
	return function()
		-- upvalues: (copy) v_u_67, (copy) p_u_57, (copy) v_u_62, (copy) p_u_56, (copy) v_u_64
		local v68 = (os.clock() - v_u_67) / p_u_57
		local v69 = math.clamp(v68, 0, 1)
		local v70 = v69 / 0.85
		local v71 = math.min(v70, 1) * 3.141592653589793
		local v72 = math.sin(v71)
		local v73 = v_u_62
		local v74 = p_u_56 * 0.34 * v72
		local v75 = math.max(v74, 0.05)
		local v76 = p_u_56
		v73.Size = Vector3.new(v75, v76, 0.1)
		local v77 = v_u_64
		local v78 = p_u_56 * 0.18 * v72
		local v79 = math.max(v78, 0.04)
		local v80 = p_u_56 * 0.85
		v77.Size = Vector3.new(v79, v80, 0.12)
		v_u_62.Transparency = v69 ^ 3 * 0.95 + 0.05
		v_u_64.Transparency = v69 ^ 3
		if v69 >= 1 then
			v_u_62:Destroy()
			v_u_64:Destroy()
		end
		return v69 < 1
	end
end
local function v_u_89(p82) -- name: drums
	-- upvalues: (copy) v_u_2, (copy) v_u_9, (copy) v_u_4
	local v83 = v_u_2:FindFirstChild("EyePieces")
	if v83 then
		v83 = v83:FindFirstChild("w6_raiko_gaze")
	end
	if not (v83 and v83:IsA("MeshPart")) then
		return nil
	end
	local v84 = v83:Clone()
	v84.Anchored = true
	v84.CanCollide = false
	v84.CanQuery = false
	v84.CanTouch = false
	v84.CastShadow = false
	v84.Massless = true
	local v85 = v83.Size.X
	local v86 = v83.Size.Y
	local v87 = v83.Size.Z
	local v88 = math.max(v85, v86, v87, 0.01)
	v84.Size = v83.Size * (p82 / v88)
	if not v84:FindFirstChildWhichIsA("SurfaceAppearance") then
		v84.Color = v_u_9
	end
	v84.Parent = v_u_4.folder()
	return v84
end
return function(p_u_90)
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_11, (copy) v_u_1, (copy) v_u_8, (copy) v_u_9, (copy) v_u_12, (copy) v_u_36, (copy) v_u_7, (copy) v_u_10, (copy) v_u_43, (copy) v_u_81, (copy) v_u_54, (copy) v_u_6, (copy) v_u_28, (copy) v_u_89, (copy) v_u_16, (copy) v_u_32, (copy) v_u_14
	local v91 = {}
	local v_u_92 = {
		Vector3.new(-0.5, 0.06, 0),
		Vector3.new(-0.1, 0.2, 0),
		Vector3.new(0.12, -0.16, 0),
		Vector3.new(0.5, 0.06, 0)
	}
	local function v_u_121(p93, p94, p95, p96, p97) -- name: zigSlash
		-- upvalues: (ref) v_u_3, (copy) v_u_92, (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (ref) v_u_8, (copy) p_u_90
		local v98 = v_u_3.CurrentCamera
		local v_u_99
		if v98 then
			local v100 = v98.CFrame.Position - p93
			v_u_99 = v100.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v100.Unit
		else
			v_u_99 = Vector3.new(0, 0, 1)
		end
		local v101 = CFrame.lookAt(p93, p93 - v_u_99) * CFrame.Angles(0, 0, p95)
		local v_u_102 = {}
		for v103 = 1, #v_u_92 - 1 do
			local v104 = (v101 * CFrame.new(v_u_92[v103] * p94)).Position
			local v105 = (v101 * CFrame.new(v_u_92[v103 + 1] * p94)).Position
			local v106 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v104), v_u_11)
			v_u_1:AddItem(v106, p96 + 0.1)
			table.insert(v_u_102, {
				["p"] = nil,
				["a"] = nil,
				["b"] = nil,
				["w"] = 0.5,
				["p"] = v106,
				["a"] = v104,
				["b"] = v105
			})
			if not p97 then
				continue
			end
			local v107 = v_u_4.part(Vector3.new(0.1, 0.1, 0.1), CFrame.new(v104), v_u_8)
			v_u_1:AddItem(v107, p96 + 0.1)
			table.insert(v_u_102, {
				["p"] = nil,
				["a"] = nil,
				["b"] = nil,
				["w"] = 0.2,
				["p"] = v107,
				["a"] = v104,
				["b"] = v105
			})
		end
		p_u_90.animate(p96, 0, function(p108)
			-- upvalues: (copy) v_u_102, (copy) v_u_99
			local v109 = p108 / 0.2
			local v110 = math.min(v109, 1)
			local v111 = p108 - 0.5
			local v112 = math.max(v111, 0) / 0.5
			for _, v113 in v_u_102 do
				local v114 = (v113.a + v113.b) / 2
				local v115 = v114:Lerp(v113.a, v110)
				local v116 = (v114:Lerp(v113.b, v110) - v115).Magnitude
				local v117 = math.max(v116, 0.05)
				local v118 = v113.p
				local v119 = v113.w * (1 - v112 * 0.5)
				local v120 = v117 + v113.w * 0.6
				v118.Size = Vector3.new(v119, 0.12, v120)
				v113.p.CFrame = CFrame.lookAt(v114, v114 + (v113.b - v113.a), v_u_99)
				v113.p.Transparency = v112
				if p108 < 1 then
					continue
				end
				v113.p:Destroy()
			end
		end)
	end
	local v_u_122 = {
		Vector3.new(0.2, 0, 1.7),
		Vector3.new(0.6, 0, 0.35),
		Vector3.new(-0.55, 0, 0.05),
		Vector3.new(0, 0, -1.9)
	}
	v91.raiko_gaze_a = {
		["cast"] = function(p123) -- name: cast
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (copy) p_u_90, (ref) v_u_8, (ref) v_u_43
			local v124 = p123.size
			local v125 = p123.eye + p123.dir * 1.2
			v_u_4.flash(v125, v_u_11, 3 * v124, 0.1)
			p_u_90.pop(v125, v_u_8, 1.1 * v124, 0.3 * v124, 0.1)
			if not p123.lite then
				v_u_43(v125, 1.6 * v124, 1)
			end
		end,
		["shot"] = function(p126, p127) -- name: boltShot
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (copy) v_u_122, (ref) v_u_8, (ref) v_u_9, (copy) p_u_90, (ref) v_u_12, (ref) v_u_36, (ref) v_u_7, (ref) v_u_10, (ref) v_u_3
			local v_u_128 = p126.size
			local v_u_129 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), p127, v_u_11, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v_u_129, 3)
			local v_u_130 = {}
			local v_u_131 = {}
			for _ = 1, #v_u_122 - 1 do
				local v132 = v_u_4.part(Vector3.new(0.45, 0.45, 0.45) * v_u_128, p127, v_u_11)
				local v133 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2) * v_u_128, p127, v_u_8)
				v_u_1:AddItem(v132, 3)
				v_u_1:AddItem(v133, 3)
				table.insert(v_u_130, v132)
				table.insert(v_u_131, v133)
			end
			local v_u_134
			if p126.lite then
				v_u_134 = nil
			else
				v_u_134 = v_u_4.part(Vector3.new(2.6, 2.6, 2.6) * v_u_128, p127, v_u_9, {
					["shape"] = nil,
					["transparency"] = 0.75,
					["shape"] = Enum.PartType.Ball
				})
				v_u_1:AddItem(v_u_134, 3)
			end
			p_u_90.streak(v_u_129, v_u_11, v_u_12, 0.9 * v_u_128, p126.lite and 0.08 or 0.14)
			local v_u_135
			if p126.lite then
				v_u_135 = nil
			else
				v_u_135 = v_u_36(v_u_129, {
					["texture"] = nil,
					["color"] = nil,
					["size"] = nil,
					["life"] = nil,
					["speed"] = nil,
					["rate"] = 26,
					["still"] = true,
					["texture"] = v_u_7.RaikoSpark,
					["color"] = ColorSequence.new(v_u_10, v_u_11),
					["size"] = NumberSequence.new(0.9 * v_u_128),
					["life"] = NumberRange.new(0.08, 0.14),
					["speed"] = NumberRange.new(2, 6)
				})
			end
			if p126.mine then
				p_u_90.light(v_u_129, v_u_11, 10 * v_u_128)
			end
			local v_u_136 = table.clone(v_u_122)
			local v_u_137 = 0
			local v_u_138 = false
			return {
				["place"] = function(p139, p140) -- name: place
					-- upvalues: (copy) v_u_129, (ref) v_u_3, (ref) v_u_137, (copy) v_u_136, (ref) v_u_122, (copy) v_u_130, (copy) v_u_128, (copy) v_u_131, (ref) v_u_134
					v_u_129.CFrame = p139
					local v141 = p139.Position
					local v142 = p139.LookVector
					local v143 = v_u_3.CurrentCamera
					local v144
					if v143 then
						local v145 = v143.CFrame.Position - v141
						v144 = v145.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v145.Unit
					else
						v144 = Vector3.new(0, 0, 1)
					end
					local v146 = v142:Cross(v144)
					if v146.Magnitude < 0.001 then
						v146 = p139.RightVector
					end
					local v147 = v146.Unit
					local v148 = -v142
					local v149 = CFrame.fromMatrix(v141, v147, v148:Cross(v147), v148)
					if v_u_137 <= p140 then
						v_u_137 = p140 + 0.05
						local v150 = v_u_136
						local v151 = v_u_122[2]
						local v152 = (math.random() - 0.5) * 0.35
						v150[2] = v151 + Vector3.new(v152, 0, 0)
						local v153 = v_u_136
						local v154 = v_u_122[3]
						local v155 = (math.random() - 0.5) * 0.35
						v153[3] = v154 + Vector3.new(v155, 0, 0)
					end
					for v156 = 1, #v_u_130 do
						local v157 = (v149 * CFrame.new(v_u_136[v156] * v_u_128)).Position
						local v158 = (v149 * CFrame.new(v_u_136[v156 + 1] * v_u_128)).Position
						local v159 = (v158 - v157).Magnitude
						local v160 = CFrame.lookAt((v157 + v158) / 2, v158, v149.UpVector)
						local v161 = v_u_130[v156]
						local v162 = 0.45 * v_u_128
						local v163 = 0.12 * v_u_128
						local v164 = v159 + 0.35 * v_u_128
						v161.Size = Vector3.new(v162, v163, v164)
						v_u_130[v156].CFrame = v160
						local v165 = v_u_131[v156]
						local v166 = 0.2 * v_u_128
						local v167 = 0.14 * v_u_128
						local v168 = v159 + 0.1 * v_u_128
						v165.Size = Vector3.new(v166, v167, v168)
						v_u_131[v156].CFrame = v160
					end
					local v169 = v_u_134
					if v169 then
						v169.CFrame = CFrame.new(v141 - v144 * 0.4)
					end
				end,
				["stop"] = function(_) -- name: stop
					-- upvalues: (ref) v_u_138, (ref) v_u_135, (copy) v_u_129, (ref) v_u_1, (copy) v_u_130, (copy) v_u_131, (ref) v_u_134
					if not v_u_138 then
						v_u_138 = true
						local v170 = v_u_135
						if v170 then
							v170.Enabled = false
						end
						local v171 = v_u_129:FindFirstChildWhichIsA("PointLight")
						if v171 then
							v171:Destroy()
						end
						v_u_1:AddItem(v_u_129, 0.3)
						for v172 = 1, #v_u_130 do
							v_u_130[v172]:Destroy()
							v_u_131[v172]:Destroy()
						end
						if v_u_134 then
							v_u_134:Destroy()
						end
					end
				end
			}
		end,
		["impact"] = function(p173, p174) -- name: boltImpact
			-- upvalues: (ref) v_u_43, (ref) v_u_4, (ref) v_u_11, (copy) p_u_90, (ref) v_u_8, (ref) v_u_10, (ref) v_u_7, (ref) v_u_81
			local v175 = p173.size
			v_u_43(p174, 3.4 * v175, p173.lite and 2 or 4)
			v_u_4.flash(p174, v_u_11, 5 * v175, 0.14)
			p_u_90.pop(p174, v_u_8, 0.9 * v175, 2.4 * v175, 0.1)
			p_u_90.glint(p174, v_u_10, 4.5 * v175, 0.16)
			v_u_4.ring(p_u_90.ground(p174), v_u_11, p173.ability.radius * 1.2 * v175, 0.25, v_u_7.Ring)
			if not p173.lite then
				p_u_90.runNow((v_u_81(p174, 2.6 * v175, 0.2)))
			end
			p_u_90.hitSound(p174)
		end,
		["hit"] = function(_, p176, _) -- name: hit
			-- upvalues: (copy) p_u_90, (ref) v_u_11
			p_u_90.burst("Lightning", p176, v_u_11, 0.45)
		end
	}
	local function v_u_194(p177, p178, p179, p180) -- name: afterimage
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_1
		if p177 then
			p177 = p177.Character
		end
		local v181
		if p177 then
			v181 = p177:FindFirstChild("HumanoidRootPart")
		else
			v181 = p177
		end
		if p177 and (v181 and v181:IsA("BasePart")) then
			local v182 = CFrame.lookAt
			local v183 = p178.X
			local v184 = v181.Position.Y
			local v185 = p178.Z
			local v186 = Vector3.new(v183, v184, v185)
			local v187 = p178.X
			local v188 = v181.Position.Y
			local v189 = p178.Z
			local v190 = v182(v186, Vector3.new(v187, v188, v189) + p179)
			for _, v191 in p177:GetChildren() do
				if not v191:IsA("BasePart") or (v191 == v181 or v191.Transparency >= 1) then
					continue
				end
				local v192 = v190 * v181.CFrame:ToObjectSpace(v191.CFrame)
				local v193
				if v191:IsA("MeshPart") and v191.Archivable then
					v193 = v191:Clone()
					v193:ClearAllChildren()
					v193.TextureID = ""
				else
					v193 = v_u_4.part(v191.Size, v192, v_u_11)
				end
				v193.Anchored = true
				v193.CanCollide = false
				v193.CanQuery = false
				v193.CanTouch = false
				v193.CastShadow = false
				v193.Material = Enum.Material.Neon
				v193.Color = v_u_11
				v193.Transparency = 0.3
				v193.CFrame = v192
				v193.Parent = v_u_4.folder()
				v_u_4.tween(v193, p180, {
					["Transparency"] = 1
				}, Enum.EasingStyle.Quad, Enum.EasingDirection.In)
				v_u_1:AddItem(v193, p180 + 0.05)
			end
		end
	end
	v91.raiko_gaze_e = {
		["cast"] = function(p195) -- name: cast
			-- upvalues: (copy) p_u_90, (ref) v_u_9, (ref) v_u_43
			p_u_90.skillCast(p195, v_u_9)
			if not p195.lite then
				v_u_43(p195.origin, 2.6 * p195.size, 3)
			end
		end,
		["windup"] = function(p196, _, p197) -- name: windup
			-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_7
			v_u_4.flash(p196.origin, v_u_11, 6 * p196.size, p197 + 0.05)
			v_u_4.ring(p196.feet, v_u_11, 5 * p196.size, 0.25, v_u_7.Ring)
		end,
		["beam"] = function(p_u_198, _, p199) -- name: beam
			-- upvalues: (copy) p_u_90, (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (ref) v_u_54, (ref) v_u_8, (ref) v_u_7, (ref) v_u_9, (ref) v_u_6, (copy) v_u_194, (copy) v_u_121, (ref) v_u_43, (ref) v_u_10
			local v_u_200 = p_u_198.lite
			local v_u_201 = p_u_198.feet + Vector3.new(0, 2.6, 0)
			local v202 = p199.X
			local v203 = v_u_201.Y
			local v204 = p199.Z
			local v_u_205 = Vector3.new(v202, v203, v204)
			local v206 = v_u_205 - v_u_201
			if v206.Magnitude < 1 then
				v206 = p_u_198.dir
				v_u_205 = v_u_201 + v206 * 10
			end
			local v_u_207 = p_u_90.flatUnit(v206)
			local v208 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_201), v_u_11, {
				["transparency"] = 1
			})
			v_u_1:AddItem(v208, 0.74)
			local v_u_209 = v_u_54(v208, v_u_201, v_u_201, 4.5, v_u_11)
			local v_u_210 = v_u_54(v208, v_u_201, v_u_201, 1.2, v_u_8, v_u_7.Beam)
			local v_u_211 = {}
			for _, v212 in { v_u_209, v_u_210 } do
				local v213 = v212.Attachment1
				if not v213 then
					continue
				end
				table.insert(v_u_211, v213)
			end
			p_u_90.animate(0.14, 0, function(p214)
				-- upvalues: (copy) v_u_211, (copy) v_u_201, (ref) v_u_205
				for _, v215 in v_u_211 do
					v215.WorldPosition = v_u_201:Lerp(v_u_205, p214)
				end
			end)
			p_u_90.after(0.14, function()
				-- upvalues: (ref) p_u_90, (copy) v_u_209, (copy) v_u_210
				p_u_90.animate(0.4, 0, function(p216)
					-- upvalues: (ref) v_u_209, (ref) v_u_210
					local v217 = 1 - p216 * p216
					local v218 = v_u_209
					local v219 = v_u_209
					local v220 = 4.5 * v217
					local v221 = 3 * v217
					v218.Width0 = v220
					v219.Width1 = v221
					local v222 = v_u_210
					local v223 = v_u_210
					local v224 = 1.2 * v217
					local v225 = 0.8 * v217
					v222.Width0 = v224
					v223.Width1 = v225
					v_u_209.Transparency = NumberSequence.new(p216)
					v_u_210.Transparency = NumberSequence.new(p216)
				end)
			end)
			p_u_90.groundLine(v_u_201, v_u_205, 1.8, v_u_9, 0.6, 0.35)
			v_u_6.play("Lightning", {
				["at"] = v_u_201,
				["volume"] = p_u_198.mine and 0.7 or 0.4
			})
			if not v_u_200 then
				for _, v_u_226 in { 0.3, 0.62, 0.94 } do
					p_u_90.after(0.14 * v_u_226, function()
						-- upvalues: (ref) v_u_194, (copy) p_u_198, (copy) v_u_201, (ref) v_u_205, (copy) v_u_226, (copy) v_u_207
						v_u_194(p_u_198.caster, v_u_201:Lerp(v_u_205, v_u_226), v_u_207, 0.45)
					end)
				end
			end
			local v227 = v_u_200 and 3 or 6
			for v228 = 1, v227 do
				local v229 = (v228 - 0.4) / v227
				local v_u_230 = v_u_201:Lerp(v_u_205, v229) + Vector3.new(0, 1, 0) * (math.random() - 0.5) * 1.5
				p_u_90.after(v229 * 0.14, function()
					-- upvalues: (ref) v_u_121, (copy) v_u_230, (copy) v_u_200, (ref) v_u_43
					local v231 = 35 + math.random() * 20
					local v232 = math.rad(v231)
					v_u_121(v_u_230, 4.6, v232, 0.34, not v_u_200)
					v_u_121(v_u_230, 4.2, -v232, 0.34, not v_u_200)
					if not v_u_200 then
						v_u_43(v_u_230, 1.8, 1)
					end
				end)
				p_u_90.after(v229 * 0.14 + 0.24, function()
					-- upvalues: (ref) p_u_90, (copy) v_u_230, (ref) v_u_11, (copy) v_u_200, (ref) v_u_4, (ref) v_u_10, (ref) v_u_43
					p_u_90.burst("Lightning", v_u_230, v_u_11, 0.9)
					if not v_u_200 then
						v_u_4.flash(v_u_230, v_u_10, 4, 0.14)
						v_u_43(v_u_230, 3, 2)
					end
				end)
			end
			p_u_90.after(0.14, function()
				-- upvalues: (ref) v_u_4, (ref) v_u_205, (ref) v_u_11, (ref) p_u_90, (ref) v_u_7, (ref) v_u_43, (copy) v_u_200
				v_u_4.flash(v_u_205, v_u_11, 7, 0.2)
				v_u_4.ring(p_u_90.ground(v_u_205), v_u_11, 7, 0.35, v_u_7.Ring)
				v_u_43(v_u_205, 3, v_u_200 and 2 or 4)
			end)
			if p_u_198.mine then
				v_u_4.shake(0.25, 0.2)
			end
		end,
		["hit"] = function(p233, p234, _) -- name: hit
			-- upvalues: (copy) p_u_90, (ref) v_u_11
			p_u_90.burst("Lightning", p234, v_u_11, 0.5)
			p_u_90.beamHitSound(p233, p234, "Lightning")
		end
	}
	local v_u_235 = {}
	setmetatable(v_u_235, {
		["__mode"] = "k"
	})
	local function v_u_299(p236, p237, p_u_238) -- name: gather
		-- upvalues: (copy) p_u_90, (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (ref) v_u_28, (ref) v_u_7, (ref) v_u_9, (ref) v_u_89, (ref) v_u_16, (ref) v_u_54, (ref) v_u_10, (ref) v_u_32
		local v_u_239 = p236.ability.radius
		local v240 = p_u_90.ground(p237, 0)
		local v_u_241 = v240 + Vector3.new(0, 30, 0)
		local v_u_242 = p_u_238 + 2
		local v_u_243 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_241), v_u_11, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v_u_243, v_u_242)
		local v_u_244 = v_u_28(CFrame.new(v_u_241 - Vector3.new(0, 0.5, 0)), 0.1, v_u_7.Glow, v_u_9, 0.2)
		v_u_1:AddItem(v_u_244, v_u_242)
		local v_u_245 = {
			["g"] = nil,
			["top"] = nil,
			["ring"] = nil,
			["stand"] = nil,
			["glow"] = nil,
			["holder"] = nil,
			["arcs"] = nil,
			["born"] = nil,
			["struck"] = nil,
			["g"] = v240,
			["top"] = v_u_241,
			["stand"] = {},
			["glow"] = v_u_244,
			["holder"] = v_u_243,
			["arcs"] = {},
			["born"] = os.clock()
		}
		local v_u_246 = v_u_89(16)
		if v_u_246 then
			v_u_1:AddItem(v_u_246, v_u_242)
			v_u_245.ring = v_u_246
		else
			for _ = 1, 8 do
				local v247 = {
					["material"] = v_u_16
				}
				local v248 = v_u_4.part(Vector3.new(2.6, 1.6, 2.6), CFrame.new(v_u_241), v_u_9, v247)
				local v249 = Instance.new("SpecialMesh")
				v249.MeshType = Enum.MeshType.Sphere
				v249.Parent = v248
				v_u_1:AddItem(v248, v_u_242)
				local v250 = v_u_245.stand
				table.insert(v250, v248)
			end
		end
		if not p236.lite then
			for _ = 1, 3 do
				local v251 = v_u_245.arcs
				local v252 = v_u_54(v_u_243, v_u_241, v_u_241, 1.4, v_u_10)
				table.insert(v251, v252)
			end
		end
		local v_u_253 = not v_u_246 and Vector3.new(1, 1, 1) or v_u_246.Size
		local v_u_254 = 0
		p_u_90.runNow(function()
			-- upvalues: (copy) v_u_245, (copy) p_u_238, (copy) v_u_246, (copy) v_u_244, (copy) v_u_243, (copy) v_u_241, (copy) v_u_253, (ref) v_u_32, (ref) v_u_254, (copy) v_u_242
			local v255 = os.clock()
			local v256 = v255 - v_u_245.born
			local v257 = p_u_238
			local v258 = v256 / math.max(v257, 0.15)
			local v259 = math.clamp(v258, 0, 1) - 1
			local v260 = v259 * 2.7 * v259 * v259 + 1 + v259 * 1.7 * v259
			local v261 = v_u_245.struck
			local v262, v263
			if v261 then
				local v264 = (v255 - v261) / 0.6
				v262 = math.clamp(v264, 0, 1)
				v263 = v262 * 8 * v262
				local v265 = v262 * 3
				local v266 = math.min(v265, 1) * 3.141592653589793
				v260 = v260 * (math.sin(v266) * 0.25 + 1)
				if v262 >= 1 then
					if v_u_246 then
						v_u_246:Destroy()
					end
					for _, v267 in v_u_245.stand do
						v267:Destroy()
					end
					v_u_244:Destroy()
					v_u_243:Destroy()
					return false
				end
			else
				v263 = 0
				v262 = 0
			end
			local v268 = v256 * 2.4
			local v269 = v_u_241 + Vector3.new(0, 1, 0) * v263
			if v_u_246 then
				v_u_246.Size = v_u_253 * math.max(v260, 0.05)
				v_u_246.CFrame = CFrame.new(v269) * CFrame.Angles(0, v268, 0) * CFrame.Angles(1.5707963267948966, 0, 0)
				v_u_246.Transparency = v262
			end
			for v270, v271 in v_u_245.stand do
				local v272 = v268 + v270 / #v_u_245.stand * 3.141592653589793 * 2
				local v273 = CFrame.new
				local v274 = math.cos(v272)
				local v275 = math.sin(v272)
				v271.CFrame = v273(v269 + Vector3.new(v274, 0, v275) * 16 * 0.45 * v260)
				v271.Transparency = v262
			end
			local v276 = v_u_244
			local v277 = v260 * 12
			local v278 = math.max(v277, 0.03)
			local v279 = v278 * 2
			local v280 = v278 * 2
			v276.Size = Vector3.new(v279, 0.05, v280)
			v_u_244.CFrame = CFrame.new(v269 - Vector3.new(0, 0.6, 0))
			v_u_32(v_u_244, v262 * 0.8 + 0.2)
			if #v_u_245.arcs > 0 and v_u_254 <= v256 then
				v_u_254 = v256 + 0.06
				for _, v281 in v_u_245.arcs do
					local v282 = math.random() * 3.141592653589793 * 2
					local v283 = v282 + 0.6 + math.random() * 1.2
					local v284 = v260 * 7.36
					local v285 = v281.Attachment0
					local v286 = v281.Attachment1
					if v285 and v286 then
						local v287 = math.cos(v282) * v284
						local v288 = math.sin(v282) * v284
						v285.WorldPosition = v269 + Vector3.new(v287, 0, v288)
						local v289 = math.cos(v283) * v284
						local v290 = math.sin(v283) * v284
						v286.WorldPosition = v269 + Vector3.new(v289, -0.5, v290)
					end
					local v291
					if v261 == nil then
						v291 = math.random() < 0.8
					else
						v291 = false
					end
					v281.Enabled = v291
				end
			end
			return v256 < v_u_242
		end)
		local v_u_292 = v_u_28(CFrame.new(v240 + Vector3.new(0, 0.3, 0)), v_u_239 * 1.2, v_u_7.Ring, v_u_9, 0.2)
		v_u_1:AddItem(v_u_292, p_u_238 + 0.4)
		p_u_90.animate(math.max(p_u_238, 0.15), 0, function(p293)
			-- upvalues: (copy) v_u_292, (copy) v_u_239
			local v294 = v_u_292
			local v295 = v_u_239 * (1.2 - 0.85 * p293)
			local v296 = math.max(v295, 0.03)
			local v297 = v296 * 2
			local v298 = v296 * 2
			v294.Size = Vector3.new(v297, 0.05, v298)
			if p293 >= 1 then
				v_u_292:Destroy()
			end
		end)
		p_u_90.mark(v240, v_u_9, v_u_239 * 0.9, p_u_238 + 1.5, v_u_7.CrackGlow, 0.15)
		return v_u_245
	end
	local function v_u_333(p300, p301) -- name: hammer
		-- upvalues: (ref) v_u_4, (ref) v_u_11, (ref) v_u_1, (ref) v_u_54, (ref) v_u_10, (ref) v_u_8, (ref) v_u_7, (copy) p_u_90, (ref) v_u_28, (ref) v_u_32, (ref) v_u_9, (ref) v_u_43, (ref) v_u_14, (ref) v_u_12, (ref) v_u_6
		local v_u_302 = p300.ability.radius
		local v_u_303 = p301.g
		local v304 = p301.top
		local v305 = p300.lite
		p301.struck = os.clock()
		local v306 = v_u_4.part(Vector3.new(0.2, 0.2, 0.2), CFrame.new(v_u_303), v_u_11, {
			["transparency"] = 1
		})
		v_u_1:AddItem(v306, 0.8)
		local v_u_307 = {
			{
				["b"] = nil,
				["w"] = 15,
				["b"] = v_u_54(v306, v304, v_u_303, 15, v_u_11)
			},
			{
				["b"] = nil,
				["w"] = 8,
				["b"] = v_u_54(v306, v304, v_u_303, 8, v_u_10)
			},
			{
				["b"] = nil,
				["w"] = 3,
				["b"] = v_u_54(v306, v304, v_u_303, 3, v_u_8, v_u_7.Beam)
			}
		}
		p_u_90.animate(0.6, 0, function(p308)
			-- upvalues: (copy) v_u_307
			local v309 = 1 - p308 * p308
			for _, v310 in v_u_307 do
				v310.b.Width0 = v310.w * v309
				v310.b.Width1 = v310.w * v309 * 1.15
				v310.b.Transparency = NumberSequence.new(p308 * 0.8)
				v310.b.TextureLength = v310.w * (1.8 + math.random() * 0.8)
			end
		end)
		for v_u_311 = 0, 4 do
			local v312 = v_u_311 * 26 / 4 + 1
			local v313 = v_u_28
			local v314 = CFrame.new(v_u_303 + Vector3.new(0, 1, 0) * v312)
			local v315 = 1
			local v316 = v_u_7.Shockwave
			local v317
			if v_u_311 % 2 == 0 then
				v317 = v_u_11
			else
				v317 = v_u_10
			end
			local v_u_318 = v313(v314, v315, v316, v317, 0)
			v_u_1:AddItem(v_u_318, 0.6)
			p_u_90.after(v_u_311 * 0.035, function()
				-- upvalues: (ref) p_u_90, (copy) v_u_318, (copy) v_u_302, (copy) v_u_311, (ref) v_u_32
				p_u_90.animate(0.38, 0, function(p319)
					-- upvalues: (ref) v_u_318, (ref) v_u_302, (ref) v_u_311, (ref) v_u_32
					local v320 = v_u_318
					local v321 = 2 + v_u_302 * (1.15 - v_u_311 * 0.13) * (1 - (1 - p319) ^ 3)
					local v322 = math.max(v321, 0.03)
					local v323 = v322 * 2
					local v324 = v322 * 2
					v320.Size = Vector3.new(v323, 0.05, v324)
					v_u_32(v_u_318, p319 ^ 1.5)
					if p319 >= 1 then
						v_u_318:Destroy()
					end
				end)
			end)
		end
		v_u_4.flash(v_u_303 + Vector3.new(0, 4, 0), v_u_10, v_u_302 * 1.2, 0.25)
		v_u_4.ring(v_u_303, v_u_11, v_u_302 * 1.4, 0.6, v_u_7.Shockwave)
		v_u_4.ring(v_u_303, v_u_10, v_u_302, 0.4, v_u_7.Ring)
		p_u_90.burst("Shockwave", v_u_303 + Vector3.new(0, 0.3, 0), v_u_9, v_u_302 / 14)
		p_u_90.burst("Explosion", v_u_303 + Vector3.new(0, 2, 0), v_u_9, 2.2)
		p_u_90.burst("Lightning", v_u_303 + Vector3.new(0, 3, 0), v_u_11, 2.4)
		p_u_90.mark(v_u_303, v_u_9, v_u_302 * 1.05, 1.6, v_u_7.CrackGlow, 0.05)
		p_u_90.spikes(v_u_303 + Vector3.new(0, 2, 0), v_u_11, v305 and 6 or 14, v_u_302 * 1.2, 0.3, nil, nil, true)
		v_u_43(v_u_303 + Vector3.new(0, 3, 0), 9, v305 and 2 or 4)
		if not v305 then
			local v325 = { v_u_14, v_u_12, v_u_11 }
			p_u_90.chunks(v_u_303 + Vector3.new(0, 1, 0), v325, 12, 45, 1.1, 1.2, false, 0.9)
			for v326 = 1, 7 do
				p_u_90.after(v326 * 0.05 + 0.05, function()
					-- upvalues: (copy) v_u_302, (ref) v_u_43, (copy) v_u_303
					local v327 = math.random() * 3.141592653589793 * 2
					local v328 = v_u_302 * (0.3 + math.random() * 0.65)
					local v329 = v_u_43
					local v330 = v_u_303
					local v331 = math.cos(v327) * v328
					local v332 = math.sin(v327) * v328
					v329(v330 + Vector3.new(v331, 1.5, v332), 4, 2)
				end)
			end
		end
		v_u_6.play("Explosion", {
			["at"] = v_u_303,
			["volume"] = p300.mine and 1 or 0.6
		})
		v_u_6.play("Lightning", {
			["at"] = v_u_303,
			["volume"] = p300.mine and 0.8 or 0.5
		})
		if p300.mine then
			v_u_4.shake(0.6, 0.5)
		end
	end
	v91.raiko_gaze_r = {
		["cast"] = function(p334) -- name: cast
			-- upvalues: (copy) p_u_90, (ref) v_u_9, (ref) v_u_43, (ref) v_u_81
			p_u_90.skillCast(p334, v_u_9, true)
			if not p334.lite then
				v_u_43(p334.eye + p334.dir * 1.3, 3 * p334.size, 3)
				p_u_90.runNow((v_u_81(p334.eye + p334.dir * 1.4, 3 * p334.size, 0.3)))
			end
		end,
		["windup"] = function(p335, p336, p337) -- name: windup
			-- upvalues: (copy) v_u_235, (copy) v_u_299
			v_u_235[p335] = v_u_299(p335, p336, p337)
		end,
		["land"] = function(p338, p339) -- name: land
			-- upvalues: (copy) v_u_235, (copy) v_u_299, (copy) v_u_333
			local v340 = v_u_235[p338] or v_u_299(p338, p339, 0)
			v_u_235[p338] = nil
			v_u_333(p338, v340)
		end,
		["hit"] = function(_, p341, _) -- name: hit
			-- upvalues: (copy) p_u_90, (ref) v_u_11
			p_u_90.burst("Lightning", p341, v_u_11, 0.7)
		end
	}
	return v91
end