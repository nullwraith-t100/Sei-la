local v1 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil")
local v_u_2 = v1.getUserFlag("UserPlayerScriptsCCLIntegrationD")
local v_u_3 = v1.getUserFlag("UserControlModuleEnabledAPI")
local v_u_4 = game:GetService("StarterPlayer")
local v_u_5 = UserSettings():GetService("UserGameSettings")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(script.Parent:WaitForChild("AvatarAbilitiesInterface"))
local v_u_8 = v1.getUserFlag("UserAbilitiesUserInterfaceB")
local v_u_9 = v_u_8 and "ControlState" or "PlayerControlState"
local v_u_10 = {}
v_u_10.__index = v_u_10
function v_u_10._calculatePlayerInputValues(p11) -- name: _calculatePlayerInputValues
	local v12 = p11.Character
	if v12 == nil then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), false
	end
	local v13 = v12:FindFirstChild("Humanoid")
	if v13 == nil then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), false
	end
	local v14 = p11:FindFirstChild("InputContexts")
	if v14 == nil then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), false
	end
	local v15 = v14:FindFirstChild("CharacterContext")
	if v15 == nil then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), false
	end
	local v16 = v15.MoveAction
	local v17 = v15:FindFirstChild("RotationAction")
	local v18
	if v17 == nil then
		v18 = false
	else
		v18 = v17:GetState()
	end
	local v19
	if v16 == nil then
		v19 = Vector2.new(0, 0)
	else
		v19 = v16:GetState()
	end
	local v20 = p11:GetCameraState().CFrame.LookVector
	if v19.X ~= v19.X or (v19.Y ~= v19.Y or v19.X == (1 / 0)) or v19.Y == (1 / 0) or (v20.X ~= v20.X or (v20.Y ~= v20.Y or (v20.Z ~= v20.Z or (v20.X == (1 / 0) or v20.Y == (1 / 0)))) or v20.Z == (1 / 0) or v20.Magnitude <= 0) then
		return Vector3.new(0, 0, 0), Vector3.new(0, 0, 1), false
	end
	if v13 and v13:GetState() ~= Enum.HumanoidStateType.Swimming then
		local v21 = v20.X
		local v22 = v20.Z
		v20 = Vector3.new(v21, 0, v22).Unit
	end
	local v23 = v20:Cross(Vector3.new(0, 1, 0)).Unit
	return v20 * v19.Y + v23 * v19.X, v20, v18
end
function v_u_10.CloneInputsIfAbsent(p24) -- name: CloneInputsIfAbsent
	-- upvalues: (copy) v_u_4
	if not p24:FindFirstChild("InputContexts") then
		local v25 = v_u_4.PlayerModule.InputContexts:Clone()
		v25.CharacterContext.Enabled = true
		v25.CameraContext.Enabled = true
		v25.Parent = p24
	end
end
function v_u_10.FireCustomInputs(p26) -- name: FireCustomInputs
	-- upvalues: (copy) v_u_5
	local v27 = p26:FindFirstChild("InputContexts")
	if v27 then
		local v28 = v27:FindFirstChild("CharacterContext")
		if v28 then
			if v27:FindFirstChild("CameraContext") then
				local v29 = v28:FindFirstChild("RotationAction")
				local v30 = v29 and v29:FindFirstChild("RotationScriptableBinding")
				if v30 then
					v30:Fire(v_u_5.RotationType == Enum.RotationType.CameraRelative)
				end
			end
		else
			return
		end
	else
		return
	end
end
function v_u_10.SendInputToCCLCharacter(p31) -- name: SendInputToCCLCharacter
	-- upvalues: (copy) v_u_7, (copy) v_u_10
	if p31 then
		local v32 = v_u_7.get(p31)
		local v33 = p31:FindFirstChild("InputContexts")
		if v33 then
			local v34 = v33:FindFirstChild("CharacterContext")
			if v34 then
				for _, v35 in v32:GetAbilities() do
					local v36 = v34:FindFirstChild(v35 .. "Action")
					if not v36 then
						continue
					end
					v32:SendInput(v35, v36:GetState())
				end
				local v37, v38, v39 = v_u_10._calculatePlayerInputValues(p31)
				v32:SendInput("Move", v37)
				v32:SendInput("CameraLookDirection", v38)
				v32:SendInput("CameraRelativeRotation", v39)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_10.SendInputToHumanoidForServerAuth(p40) -- name: SendInputToHumanoidForServerAuth
	-- upvalues: (copy) v_u_10
	local v41 = p40.Character
	if v41 == nil then
		return
	else
		local v42 = v41:FindFirstChild("Humanoid")
		if v42 == nil then
			return
		else
			local v43 = p40:FindFirstChild("InputContexts")
			if v43 == nil then
				return
			else
				local v44 = v43:FindFirstChild("CharacterContext")
				if v44 ~= nil then
					local v45 = v44.JumpAction
					local v46, v47, v48 = v_u_10._calculatePlayerInputValues(p40)
					v42:Move(v46)
					v42.AutoRotate = not v48
					if v48 and (v42.SeatPart == nil and (v42.RootPart ~= nil and not (v42.Sit or v42.RootPart:IsGrounded()))) then
						v42.RootPart.CFrame = CFrame.new(v42.RootPart.CFrame.Position, v42.RootPart.CFrame.Position + v47)
					end
					local v49
					if v45 == nil then
						v49 = false
					else
						v49 = v45:GetState()
					end
					v42.Jump = v49
				end
			end
		end
	end
end
function v_u_10.setupPlayerControlState(p50) -- name: setupPlayerControlState
	p50:AddVector3Field("Move", Vector3.new(0, 0, 0), 1)
	p50:AddBoolField("Jump", false)
	p50:AddBoolField("RotateToLookDirection", false)
	p50:AddUnitVector3Field("LookDirection", Vector3.new(0, 0, 1))
end
function v_u_10.watchForPlayerControlState(p51) -- name: watchForPlayerControlState
	-- upvalues: (copy) v_u_9, (copy) v_u_10
	local function v56(p52) -- name: watchCharacter
		-- upvalues: (ref) v_u_9, (ref) v_u_10
		local function v54(p53) -- name: onPCSAdded
			-- upvalues: (ref) v_u_9, (ref) v_u_10
			if p53:IsA(v_u_9) then
				v_u_10.setupPlayerControlState(p53)
			end
		end
		local v55 = p52:FindFirstChildOfClass(v_u_9)
		if v55 then
			v_u_10.setupPlayerControlState(v55)
		end
		p52.ChildAdded:Connect(v54)
	end
	if p51.Character then
		local v57 = p51.Character
		local function v59(p58) -- name: onPCSAdded
			-- upvalues: (ref) v_u_9, (ref) v_u_10
			if p58:IsA(v_u_9) then
				v_u_10.setupPlayerControlState(p58)
			end
		end
		local v60 = v57:FindFirstChildOfClass(v_u_9)
		if v60 then
			v_u_10.setupPlayerControlState(v60)
		end
		v57.ChildAdded:Connect(v59)
	end
	p51.CharacterAdded:Connect(v56)
end
function v_u_10.createPlayerControlState(p_u_61) -- name: createPlayerControlState
	-- upvalues: (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	local function v64(p62) -- name: createForCharacter
		-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) p_u_61, (ref) v_u_10
		if v_u_8 then
			if p62:FindFirstChildOfClass(v_u_9) then
				return
			end
		elseif p62:FindFirstChild(v_u_9) then
			return
		end
		local v63 = Instance.new(v_u_9)
		v63.Owner = p_u_61
		v63.Parent = p62
		v_u_10.setupPlayerControlState(v63)
	end
	if p_u_61.Character then
		local v65 = p_u_61.Character
		local v66
		if v_u_8 then
			if v65:FindFirstChildOfClass(v_u_9) then
				p_u_61.CharacterAdded:Connect(v64)
				return
			end
			v66 = Instance.new(v_u_9)
			v66.Owner = p_u_61
			v66.Parent = v65
			v_u_10.setupPlayerControlState(v66)
		else
			if v65:FindFirstChild(v_u_9) then
				p_u_61.CharacterAdded:Connect(v64)
				return
			end
			v66 = Instance.new(v_u_9)
			v66.Owner = p_u_61
			v66.Parent = v65
			v_u_10.setupPlayerControlState(v66)
		end
		p_u_61.CharacterAdded:Connect(v64)
	else
		p_u_61.CharacterAdded:Connect(v64)
	end
end
function v_u_10.writeInputToPCS(p67, p68, p69) -- name: writeInputToPCS
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_9, (copy) v_u_5, (copy) v_u_6, (copy) v_u_2, (copy) v_u_7
	local v70
	if v_u_3 then
		v70 = p68.data
	else
		v70 = nil
	end
	local v71 = p67.Character
	if v71 then
		local v72
		if v_u_8 then
			v72 = v71:FindFirstChildOfClass(v_u_9)
		else
			v72 = v71:FindFirstChild(v_u_9)
		end
		if v72 then
			local v73 = p68.humanoid
			if v73 then
				local v74
				if p69 then
					v74 = p67:FindFirstChild("InputContexts")
				else
					v74 = script.Parent.Parent:FindFirstChild("InputContexts")
				end
				local v75, v76
				if v_u_3 then
					v75 = v70.isJumping
					v76 = v70.worldMoveVector
				else
					if v74 then
						v74 = v74:FindFirstChild("CharacterContext")
					end
					if not v74 then
						return
					end
					local v77 = v74:FindFirstChild("MoveAction")
					local v78 = v74:FindFirstChild("JumpAction")
					local v79
					if v77 then
						v79 = v77:GetState()
					else
						v79 = Vector2.zero
					end
					if v78 then
						v75 = v78:GetState()
					else
						v75 = false
					end
					local v80 = v79.X
					local v81 = -v79.Y
					v76 = p68:calculateRawMoveVector(v73, (Vector3.new(v80, 0, v81)))
				end
				local v82 = v_u_5.RotationType == Enum.RotationType.CameraRelative
				local v83 = v_u_6.CurrentCamera and v_u_6.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
				local v84 = v83.X
				local v85 = v83.Z
				local v86 = Vector3.new(v84, 0, v85)
				local v87 = {
					["Move"] = v76,
					["RotateToLookDirection"] = v82,
					["LookDirection"] = v86.Magnitude <= 0.001 and Vector3.new(0, 0, 1) or v86.Unit
				}
				if not (v_u_2 and v_u_7.get(p67):isEnabled()) then
					v87.Jump = v75
				end
				v72:UpdateFields(v87)
			end
		else
			return
		end
	else
		return
	end
end
function v_u_10.processPCSInputs(p88) -- name: processPCSInputs
	-- upvalues: (copy) v_u_8, (copy) v_u_9
	local v89 = p88.Character
	if v89 == nil then
		return
	else
		local v90 = v89:FindFirstChild("Humanoid")
		if v90 == nil then
			return
		else
			local v91
			if v_u_8 then
				v91 = v89:FindFirstChildOfClass(v_u_9)
			else
				v91 = v89:FindFirstChild(v_u_9)
			end
			if v91 ~= nil then
				local v92 = v91:GetState()
				local v93 = v92.Move
				local v94 = v92.Jump
				local v95 = v92.RotateToLookDirection
				local v96 = v92.LookDirection
				if v93 then
					v90:Move(v93)
				end
				v90.AutoRotate = not v95
				if v95 and (v96 ~= nil and (v90.RootPart ~= nil and (not v90.Sit and (v90.SeatPart == nil and not v90.RootPart:IsGrounded())))) then
					v90.RootPart.CFrame = CFrame.new(v90.RootPart.CFrame.Position, v90.RootPart.CFrame.Position + v96)
				end
				v90.Jump = v94 or false
			end
		end
	end
end
return v_u_10