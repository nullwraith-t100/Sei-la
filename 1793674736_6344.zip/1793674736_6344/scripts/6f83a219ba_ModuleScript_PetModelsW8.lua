local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.Config.Textures)
local v_u_3 = require(script.Parent.Perf)
require(script.Parent.PetKit)
local v_u_4 = Vector3.new
local v_u_5 = CFrame.new
local v_u_6 = CFrame.Angles
local v_u_7 = Enum.Material.Neon
local v_u_8 = Color3.fromRGB(92, 58, 38)
local v_u_9 = Color3.fromRGB(40, 28, 26)
local v_u_10 = Color3.fromRGB(255, 181, 71)
local v_u_11 = Color3.fromRGB(205, 38, 46)
local v_u_12 = Color3.fromRGB(255, 242, 214)
local v_u_13 = Color3.fromRGB(242, 179, 61)
local v_u_14 = Color3.fromRGB(34, 24, 28)
local v_u_15 = Color3.fromRGB(221, 227, 238)
local v_u_16 = Color3.fromRGB(28, 24, 32)
local v_u_17 = Color3.fromRGB(104, 22, 58)
local v_u_18 = Color3.fromRGB(255, 210, 61)
local v_u_19 = Color3.fromRGB(245, 234, 208)
local v_u_20 = Color3.fromRGB(214, 40, 52)
local v_u_21 = Color3.fromRGB(22, 22, 26)
local v_u_22 = Color3.fromRGB(201, 154, 122)
local v_u_23 = Color3.fromRGB(222, 200, 186)
local v_u_24 = Color3.fromRGB(191, 230, 255)
local v_u_25 = Color3.fromRGB(170, 196, 216)
local v_u_26 = Color3.fromRGB(43, 43, 51)
local v_u_27 = Color3.fromRGB(255, 205, 92)
local v_u_28 = Color3.fromRGB(255, 232, 160)
local v_u_29 = Color3.fromRGB(224, 33, 58)
local v_u_30 = Color3.fromRGB(250, 248, 240)
return {
	["install"] = function(p_u_31) -- name: install
		-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_4, (copy) v_u_7, (copy) v_u_29, (copy) v_u_22, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_11, (copy) v_u_13, (copy) v_u_14, (copy) v_u_16, (copy) v_u_17, (copy) v_u_18, (copy) v_u_15, (copy) v_u_27, (copy) v_u_28, (copy) v_u_21, (copy) v_u_19, (copy) v_u_20, (copy) v_u_23, (copy) v_u_12, (copy) v_u_24, (copy) v_u_26, (copy) v_u_25, (copy) v_u_30, (copy) v_u_2, (copy) v_u_3
		local v32 = p_u_31.SHAPES
		local v33 = p_u_31.GEAR
		local v34 = p_u_31.HOP
		local v_u_35 = p_u_31.DARK
		local v_u_36 = p_u_31.WHITE
		local v_u_37 = p_u_31.BLUSH
		local v_u_38 = p_u_31.hex
		local v_u_39 = p_u_31.has
		local v_u_40 = p_u_31.headTop
		local v_u_41 = p_u_31.bone
		local v_u_42 = p_u_31.onto
		local v_u_43 = p_u_31.box
		local v_u_44 = p_u_31.cyl
		local v_u_45 = p_u_31.wedge
		local v_u_46 = p_u_31.tri
		local v_u_47 = p_u_31.tri3
		local v_u_48 = p_u_31.bar
		local v_u_49 = p_u_31.limb
		local v_u_50 = p_u_31.eyes
		local v_u_51 = p_u_31.cheeks
		local v_u_52 = p_u_31.legs
		v34.oni = { 0.5, 9 }
		v34.piglet = { 0.42, 11 }
		local function v_u_60(p53, p54, p55, p56, p57) -- name: stubArms
			-- upvalues: (ref) v_u_4, (copy) v_u_41, (copy) v_u_43, (ref) v_u_5, (ref) v_u_6
			local v58 = p54 + v_u_4(math.sin(p56) * p55.Y / 2 + 0.18, -p55.Y / 2 + 0.06, 0)
			for v59 = -1, 1, 2 do
				v_u_41(p53, v59 < 0 and "ArmL" or "ArmR", "Body", v_u_4(v59 * p54.X, p54.Y, p54.Z), "arm", v59 * 0.9, v59)
				v_u_43(p53, p55, v_u_5(v59 * v58.X, v58.Y, v58.Z) * v_u_6(0, 0, v59 * p56), p57)
			end
			return v58 + v_u_4(math.sin(p56) * p55.Y / 2, -math.cos(p56) * p55.Y / 2, 0)
		end
		local function v_u_76(p61, p62, p63, p64, p65) -- name: longBody
			-- upvalues: (copy) v_u_41, (copy) v_u_43, (ref) v_u_4, (ref) v_u_5
			local v66 = {}
			for v67 = 1, #p62 - 1 do
				local v68 = p62[v67]
				local v69 = p62[v67 + 1]
				if v67 > 1 then
					v_u_41(p61, "Seg" .. v67, v67 == 2 and "Body" or "Seg" .. v67 - 1, v68, "swim", v67 * 0.9)
				end
				local v70 = p63[v67]
				local v71 = CFrame.lookAt((v68 + v69) / 2, v69)
				local v72 = (v69 - v68).Magnitude + 0.3
				local v73 = v_u_43
				local v74 = v_u_4(v70, v70 * 0.92, v72)
				local v75
				if v67 % 2 == 0 then
					v75 = p65
				else
					v75 = p61.body
				end
				v73(p61, v74, v71, v75)
				if v67 <= p64 then
					v_u_43(p61, v_u_4(v70 * 0.66, 0.1, v72 - 0.15), v71 * v_u_5(0, -v70 * 0.46, 0), p61.belly)
				end
				table.insert(v66, {
					["cf"] = v71,
					["th"] = v70,
					["len"] = v72
				})
			end
			return v66
		end
		local function v_u_84(p77, p78, p79, p80, p81, p82) -- name: demonEye
			-- upvalues: (copy) v_u_43, (ref) v_u_4, (ref) v_u_5, (copy) v_u_38, (ref) v_u_7, (copy) v_u_35, (copy) v_u_36
			local v83 = p77.face
			v_u_43(p77, v_u_4(p80, p81, 0.07), v_u_5(p78, p79, v83 - 0.03), p77.accent)
			v_u_43(p77, v_u_4(p80 * 0.62, p81 * 0.8, 0.06), v_u_5(p78, p79, v83 - 0.07), v_u_38(p77.look.eye or "#FFD23D"), v_u_7)
			if p82 then
				v_u_43(p77, v_u_4(p80 * 0.16, p81 * 0.62, 0.05), v_u_5(p78, p79, v83 - 0.1), v_u_35)
				v_u_43(p77, v_u_4(p80 * 0.22, p80 * 0.22, 0.04), v_u_5(p78 + p80 * 0.2, p79 + p81 * 0.22, v83 - 0.12), v_u_36)
			end
		end
		local function v_u_93(p85) -- name: sixEyes
			-- upvalues: (copy) v_u_84, (copy) v_u_43, (ref) v_u_5, (copy) v_u_38, (ref) v_u_7
			for v86 = -1, 1, 2 do
				v_u_84(p85, v86 * p85.eyeX, p85.eyeY, 0.44, 0.5, true)
				local v87 = v86 * 0.34
				local v88 = p85.eyeY + 0.56
				local v89 = p85.face
				v_u_43(p85, Vector3.new(0.32, 0.24, 0.07), v_u_5(v87, v88, v89 - 0.03), p85.accent)
				v_u_43(p85, Vector3.new(0.1984, 0.192, 0.06), v_u_5(v87, v88, v89 - 0.07), v_u_38(p85.look.eye or "#FFD23D"), v_u_7)
				local v90 = v86 * 0.66
				local v91 = p85.eyeY - 0.5
				local v92 = p85.face
				v_u_43(p85, Vector3.new(0.3, 0.22, 0.07), v_u_5(v90, v91, v92 - 0.03), p85.accent)
				v_u_43(p85, Vector3.new(0.186, 0.176, 0.06), v_u_5(v90, v91, v92 - 0.07), v_u_38(p85.look.eye or "#FFD23D"), v_u_7)
			end
		end
		local function v105(p94) -- name: goldfish
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (copy) v_u_46, (ref) v_u_4, (copy) v_u_41, (copy) v_u_47, (copy) v_u_50, (copy) v_u_35, (copy) v_u_51
			v_u_42(p94, "Body")
			local v95 = p94.limbs
			p94.bodyC = Vector3.new(0, 1.55, 0.35)
			p94.bodyS = Vector3.new(1.85, 1.75, 1.6)
			v_u_43(p94, p94.bodyS, v_u_5(p94.bodyC), p94.body)
			local v96 = p94.bodyC.Y - p94.bodyS.Y / 2
			local v97 = p94.bodyC.Y + p94.bodyS.Y / 2
			v_u_43(p94, Vector3.new(1.45, 0.12, 1.3), v_u_5(0, v96 - 0.03, 0.35), p94.belly)
			v_u_46(p94, v_u_4(0, v97 - 0.05, 1.05), Vector3.new(0, 0, -1), Vector3.new(0, 0.8, 0), 0.14, v95)
			v_u_46(p94, v_u_4(-0.45, v96, 0.75), Vector3.new(0, 0, -0.45), Vector3.new(-0.25, -0.4, 0), 0.08, v95)
			v_u_46(p94, v_u_4(0.45, v96, 0.75), Vector3.new(0, 0, -0.45), Vector3.new(0.25, -0.4, 0), 0.08, v95)
			for v98 = -1, 1, 2 do
				local v99 = v_u_4(v98 * (p94.bodyS.X / 2 - 0.05), 1.25, 0.1)
				v_u_41(p94, v98 < 0 and "WingL" or "WingR", "Body", v99, "wing", 0, v98)
				v_u_46(p94, v99, v_u_4(v98 * 0.85, -0.35, 0), Vector3.new(0, 0, 0.65), 0.1, v95)
			end
			local v100 = p94.bodyC.Z + p94.bodyS.Z / 2
			p94.tailAt = v_u_4(0, 1.55, v100)
			v_u_41(p94, "Tail1", "Body", p94.tailAt, "tail", 0)
			v_u_43(p94, Vector3.new(0.8, 0.8, 0.7), v_u_5(0, 1.55, v100 + 0.25), p94.body)
			local v101 = v_u_4(0, 1.55, v100 + 0.5)
			for v102 = -1, 1, 2 do
				v_u_47(p94, v101 + v_u_4(v102 * 0.1, 0.22, 0), v101 + v_u_4(v102 * 1, 0.85, 1), v101 + v_u_4(v102 * 0.55, 0.02, 1.3), 0.1, v95)
				v_u_47(p94, v101 + v_u_4(v102 * 0.1, -0.22, 0), v101 + v_u_4(v102 * 0.55, 0.02, 1.3), v101 + v_u_4(v102 * 0.95, -0.75, 0.95), 0.1, v95)
			end
			p94.headC = Vector3.new(0, 1.6, -0.8)
			p94.headS = Vector3.new(1.95, 1.8, 1.15)
			p94.face = p94.headC.Z - p94.headS.Z / 2
			p94.eyeX = 0.58
			p94.eyeY = 2
			p94.mouthY = 1.15
			p94.bandY = 2.35
			p94.plateW = 0.85
			p94.neck = v_u_4(0, 0.8, p94.face)
			p94.back = Vector3.new(0, 2.35, 0.4)
			v_u_41(p94, "Head", "Body", Vector3.new(0, 1.5, -0.2), "head")
			v_u_43(p94, p94.headS, v_u_5(p94.headC), p94.body)
			v_u_43(p94, v_u_4(p94.headS.X - 0.25, 0.12, p94.headS.Z - 0.1), v_u_5(0, p94.headC.Y - p94.headS.Y / 2 - 0.03, p94.headC.Z), p94.belly)
			for v103 = -1, 1, 2 do
				v_u_43(p94, Vector3.new(0.72, 0.72, 0.45), v_u_5(v103 * p94.eyeX, p94.eyeY, p94.face - 0.1), p94.body)
			end
			local v104 = p94.face
			p94.face = v104 - 0.32
			v_u_50(p94, 0.46, 0.52)
			p94.face = v104
			v_u_43(p94, Vector3.new(0.66, 0.46, 0.26), v_u_5(0, p94.mouthY, p94.face - 0.1), p94.accent)
			v_u_43(p94, Vector3.new(0.34, 0.18, 0.06), v_u_5(0, p94.mouthY, p94.face - 0.24), v_u_35)
			v_u_51(p94)
		end
		local function v133(p106) -- name: lotusdoll
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (copy) v_u_36, (ref) v_u_4, (copy) v_u_47, (ref) v_u_29, (copy) v_u_41, (ref) v_u_6, (copy) v_u_35, (copy) v_u_40, (copy) v_u_46, (copy) v_u_38, (ref) v_u_7, (copy) v_u_37
			v_u_42(p106, "Body")
			local v107 = p106.limbs
			local v108 = p106.accent
			v_u_43(p106, Vector3.new(1.6, 0.32, 1.6), v_u_5(0, 0.2, 0.1), v108:Lerp(v_u_36, 0.4))
			for v109 = 0, 5 do
				local v110 = v107:Lerp(v_u_36, 0.35)
				local v111 = v109 * 3.141592653589793 / 3 + 0.5235987755982988
				if v109 % 2 == 0 then
					v110 = v107
				end
				local v112 = v_u_4(math.sin(v111), 0, -math.cos(v111))
				local v113 = v_u_4(-v112.Z, 0, v112.X)
				local v114 = Vector3.new(0, 0.2, 0.1) + v112 * 0.58
				v_u_47(p106, v114 - v113 * 1 / 2, v114 + v113 * 1 / 2, Vector3.new(0, 0.2, 0.1) + v112 * 1.25 + Vector3.new(0, 0.9, 0), 0.2, v110)
			end
			v_u_47(p106, Vector3.new(-0.35, 0.2, -0.28), Vector3.new(0.35, 0.2, -0.28), Vector3.new(0, 1.25, -0.62), 0.2, v108)
			v_u_47(p106, Vector3.new(0.38, 0.2, -0.25), Vector3.new(0.38, 0.2, 0.45), Vector3.new(0.72, 1.25, 0.1), 0.2, v108)
			v_u_47(p106, Vector3.new(0.35, 0.2, 0.48), Vector3.new(-0.35, 0.2, 0.48), Vector3.new(0.000000000000000088174575, 1.25, 0.82000005), 0.2, v108)
			v_u_47(p106, Vector3.new(-0.38, 0.2, 0.45), Vector3.new(-0.38, 0.2, -0.25), Vector3.new(-0.72, 1.25, 0.1), 0.2, v108)
			v_u_43(p106, Vector3.new(1.15, 0.75, 1), v_u_5(0, 0.72, 0.1), p106.cloth)
			v_u_43(p106, Vector3.new(0.95, 0.6, 0.85), v_u_5(0, 1.35, 0.1), p106.cloth)
			v_u_43(p106, Vector3.new(1.02, 0.2, 0.92), v_u_5(0, 1.1, 0.1), v_u_29:Lerp(p106.limbs, 0.5))
			p106.bodyC = Vector3.new(0, 1.1, 0.1)
			p106.bodyS = Vector3.new(1.15, 1.3, 1)
			for v115 = -1, 1, 2 do
				v_u_41(p106, v115 < 0 and "ArmL" or "ArmR", "Body", v_u_4(v115 * 0.48, 1.55, 0.1), "arm", v115 * 0.9, v115)
				local v116 = v_u_5(v115 * 0.66, 1.18, 0.1) * v_u_6(0, 0, v115 * 0.28)
				v_u_43(p106, Vector3.new(0.44, 0.82, 0.62), v116, p106.cloth)
				v_u_43(p106, Vector3.new(0.3, 0.06, 0.46), v116 * v_u_5(0, -0.42, 0), p106.cloth:Lerp(v_u_35, 0.35))
			end
			p106.headC = Vector3.new(0, 2.4, 0)
			p106.headS = Vector3.new(1.8, 1.55, 1.55)
			p106.face = p106.headC.Z - p106.headS.Z / 2
			p106.eyeX = 0.42
			p106.eyeY = 2.3
			p106.mouthY = 1.88
			p106.bandY = 2.85
			p106.plateW = 0.8
			p106.neck = Vector3.new(0, 1.62, -0.35)
			p106.back = Vector3.new(0, 1.6, 0.6)
			p106.tailAt = Vector3.new(0, 0.8, 0.7)
			v_u_41(p106, "Head", "Body", Vector3.new(0, 1.65, 0), "head")
			v_u_43(p106, p106.headS, v_u_5(p106.headC), p106.body)
			local v117 = v_u_40(p106)
			local v118 = p106.belly
			local v119 = p106.headS
			v_u_43(p106, v_u_4(v119.X + 0.1, 0.22, v119.Z + 0.08), v_u_5(0, v117 + 0.03, p106.headC.Z + 0.02), v118)
			local v120 = p106.headC.Z + v119.Z / 2 + 0.08
			v_u_43(p106, v_u_4(v119.X + 0.1, 0.75, 0.26), v_u_5(0, v117 - 0.3, v120), v118)
			for v121 = -1, 1 do
				local v122 = v121 * 0.6
				v_u_47(p106, v_u_4(v122 - 0.32, v117 - 0.6, v120), v_u_4(v122 + 0.32, v117 - 0.6, v120), v_u_4(v122, v117 - 1.25, v120), 0.24, v118)
			end
			local v123 = p106.face - 0.05
			for v124 = -1, 1, 2 do
				local v125 = v124 * (v119.X / 2 + 0.06)
				v_u_47(p106, v_u_4(v125, v117 + 0.02, p106.face + 0.12), v_u_4(v125, v117 + 0.02, p106.face + 0.75), v_u_4(v125, v117 - 1.15, p106.face + 0.3), 0.16, v118)
			end
			for v126 = 0, 3 do
				v_u_46(p106, v_u_4(v126 * 0.46 + -0.92, v117 + 0.02, v123), Vector3.new(0.46, 0, 0), v_u_4(0, -0.36 - v126 % 2 * 0.1, 0), 0.12, v118)
			end
			v_u_43(p106, v_u_4(v119.X + 0.14, 0.12, v119.Z + 0.12), v_u_5(0, v117 + 0.16, p106.headC.Z + 0.02), v_u_29)
			for _, v127 in {
				{ -0.62, 0.42 },
				{ 0.08, 0.3 },
				{ 0.5, 0.38 }
			} do
				v_u_46(p106, v_u_4(v127[1], v117 + 0.16, v123 - 0.08), Vector3.new(0.3, 0, 0), v_u_4(0, -v127[2], 0), 0.06, v_u_29)
			end
			for v128 = -1, 1, 2 do
				v_u_46(p106, v_u_4(v128 * (v119.X / 2 + 0.16), v117 + 0.16, p106.headC.Z - 0.3), Vector3.new(0, 0, 0.45), Vector3.new(0, -0.34, 0), 0.06, v_u_29)
			end
			local v129 = p106.face
			for v130 = -1, 1, 2 do
				local v131 = v130 * p106.eyeX
				v_u_43(p106, Vector3.new(0.4, 0.25, 0.08), v_u_5(v131, p106.eyeY + 0.125, v129 - 0.03), v_u_38(p106.look.eye or "#FF6FD8"), v_u_7)
				v_u_43(p106, Vector3.new(0.4, 0.25, 0.08), v_u_5(v131, p106.eyeY - 0.125, v129 - 0.03), p106.glow, v_u_7)
				v_u_43(p106, Vector3.new(0.144, 0.21, 0.06), v_u_5(v131, p106.eyeY, v129 - 0.08), v_u_35)
				v_u_43(p106, Vector3.new(0.096, 0.096, 0.05), v_u_5(v131 + 0.08800000000000001, p106.eyeY + 0.12, v129 - 0.11), v_u_36)
				v_u_43(p106, Vector3.new(0.32, 0.14, 0.06), v_u_5(v130 * (p106.eyeX + 0.3), p106.eyeY - 0.38, v129 - 0.03), v_u_37)
			end
			v_u_43(p106, Vector3.new(0.32, 0.07, 0.05), v_u_5(0, p106.mouthY, v129 - 0.03), v_u_35)
			for v132 = -1, 1, 2 do
				v_u_43(p106, Vector3.new(0.07, 0.12, 0.05), v_u_5(v132 * 0.18, p106.mouthY + 0.04, v129 - 0.03) * v_u_6(0, 0, v132 * 0.6), v_u_35)
			end
		end
		local function v150(p134) -- name: crow
			-- upvalues: (copy) v_u_42, (copy) v_u_38, (copy) v_u_35, (copy) v_u_36, (copy) v_u_43, (ref) v_u_5, (copy) v_u_41, (ref) v_u_4, (ref) v_u_6, (copy) v_u_50, (copy) v_u_51, (copy) v_u_45, (copy) v_u_40, (copy) v_u_46
			v_u_42(p134, "Body")
			local v135
			if p134.look.beak then
				v135 = v_u_38(p134.look.beak)
			else
				v135 = v_u_35:Lerp(v_u_36, 0.25)
			end
			p134.bodyC = Vector3.new(0, 1.25, 0.3)
			p134.bodyS = Vector3.new(1.45, 1.35, 1.75)
			v_u_43(p134, p134.bodyS, v_u_5(p134.bodyC), p134.body)
			v_u_43(p134, Vector3.new(1.05, 0.95, 0.1), v_u_5(0, 1.15, -0.6), p134.belly)
			for v136 = -1, 1, 2 do
				local v137 = v136 * 0.32
				v_u_41(p134, v136 < 0 and "Leg1" or "Leg2", "Body", v_u_4(v137, 0.62, 0.3), "leg", v136 < 0 and 0 or 3.141592653589793)
				v_u_43(p134, Vector3.new(0.16, 0.5, 0.16), v_u_5(v137, 0.35, 0.3), v135)
				v_u_43(p134, Vector3.new(0.34, 0.1, 0.46), v_u_5(v137, 0.07, 0.18), v135)
			end
			p134.tailAt = Vector3.new(0, 1.05, 1.1)
			v_u_41(p134, "Tail1", "Body", p134.tailAt, "tail", 0)
			for v138 = -1, 1 do
				local v139 = v_u_5(p134.tailAt) * v_u_6(0, v138 * 0.3, 0) * v_u_6(0.22, 0, 0)
				local v140 = 1.2 - math.abs(v138) * 0.18
				v_u_43(p134, v_u_4(0.38, 0.1, v140), v139 * v_u_5(0, 0, v140 / 2), p134.limbs)
			end
			for v141 = -1, 1, 2 do
				local v142 = v_u_4(v141 * 0.66, 1.68, 0.15)
				v_u_41(p134, v141 < 0 and "WingL" or "WingR", "Body", v142, "wing", 0, v141)
				local v143 = v_u_5(v142) * v_u_6(0, 0, v141 * 0.32)
				v_u_43(p134, Vector3.new(1, 0.16, 0.85), v143 * v_u_5(v141 * 0.48, 0, 0.08), p134.body)
				for v144 = 1, 3 do
					local v145 = v143 * v_u_5(v141 * 0.82, -0.03, (v144 - 1) * 0.2 + 0.02) * v_u_6(0, -v141 * (v144 - 1) * 0.32, 0)
					local v146 = 1.15 - (v144 - 1) * 0.15
					v_u_43(p134, v_u_4(v146, 0.1, 0.32), v145 * v_u_5(v141 * v146 / 2, 0, 0), p134.limbs)
				end
			end
			p134.headC = Vector3.new(0, 2.45, -0.35)
			p134.headS = Vector3.new(1.8, 1.5, 1.55)
			p134.face = p134.headC.Z - p134.headS.Z / 2
			p134.eyeX = 0.42
			p134.eyeY = 2.55
			p134.mouthY = 2.1
			p134.bandY = 2.95
			p134.plateW = 0.8
			p134.neck = Vector3.new(0, 1.78, -0.66)
			p134.back = Vector3.new(0, 1.98, 0.7)
			v_u_41(p134, "Head", "Body", Vector3.new(0, 1.75, -0.2), "head")
			v_u_43(p134, p134.headS, v_u_5(p134.headC), p134.body)
			for v147 = -1, 1, 2 do
				v_u_43(p134, Vector3.new(0.54, 0.64, 0.05), v_u_5(v147 * p134.eyeX, p134.eyeY, p134.face - 0.02), p134.accent)
			end
			local v148 = p134.face
			p134.face = v148 - 0.04
			v_u_50(p134, 0.38, 0.48)
			p134.face = v148
			v_u_51(p134)
			v_u_45(p134, Vector3.new(0.46, 0.3, 0.8), v_u_5(0, p134.mouthY + 0.12, p134.face - 0.4), v135)
			v_u_43(p134, Vector3.new(0.42, 0.16, 0.6), v_u_5(0, p134.mouthY - 0.08, p134.face - 0.3), v135:Lerp(v_u_35, 0.3))
			local v149 = v_u_40(p134)
			v_u_46(p134, v_u_4(0, v149 - 0.05, p134.headC.Z + 0.1), Vector3.new(0, 0, 0.5), Vector3.new(0, 0.38, 0), 0.14, p134.body)
			v_u_46(p134, v_u_4(0, v149 - 0.05, p134.headC.Z - 0.25), Vector3.new(0, 0, 0.35), Vector3.new(0, 0.28, 0), 0.14, p134.body)
		end
		local function v163(p151) -- name: sparrow
			-- upvalues: (copy) v_u_42, (copy) v_u_38, (copy) v_u_35, (copy) v_u_43, (ref) v_u_5, (copy) v_u_41, (ref) v_u_4, (ref) v_u_22, (ref) v_u_6, (copy) v_u_36, (copy) v_u_50, (copy) v_u_51, (copy) v_u_45
			v_u_42(p151, "Body")
			local v152
			if p151.look.beak then
				v152 = v_u_38(p151.look.beak)
			else
				v152 = v_u_35
			end
			p151.bodyC = Vector3.new(0, 1.05, 0.3)
			p151.bodyS = Vector3.new(1.95, 1.45, 1.8)
			v_u_43(p151, p151.bodyS, v_u_5(p151.bodyC), p151.body)
			v_u_43(p151, Vector3.new(1.55, 1.05, 0.1), v_u_5(0, 0.98, -0.62), p151.belly)
			for v153 = -1, 1, 2 do
				local v154 = v153 * 0.32
				v_u_41(p151, v153 < 0 and "Leg1" or "Leg2", "Body", v_u_4(v154, 0.42, 0.25), "leg", v153 < 0 and 0 or 3.141592653589793)
				v_u_43(p151, Vector3.new(0.14, 0.4, 0.14), v_u_5(v154, 0.22, 0.25), v_u_22)
				v_u_43(p151, Vector3.new(0.3, 0.08, 0.36), v_u_5(v154, 0.04, 0.15), v_u_22)
			end
			p151.tailAt = Vector3.new(0, 1.2, 1.15)
			v_u_41(p151, "Tail1", "Body", p151.tailAt, "tail", 0)
			local v155 = v_u_5(p151.tailAt) * v_u_6(-0.45, 0, 0)
			v_u_43(p151, Vector3.new(0.6, 0.12, 0.85), v155 * v_u_5(0, 0, 0.4), p151.body)
			v_u_43(p151, Vector3.new(0.62, 0.14, 0.24), v155 * v_u_5(0, 0, 0.78), p151.limbs)
			for v156 = -1, 1, 2 do
				local v157 = v_u_4(v156 * 0.95, 1.45, 0.25)
				v_u_41(p151, v156 < 0 and "WingL" or "WingR", "Body", v157, "wing", 0, v156)
				local v158 = v_u_5(v156 * 1.04, 1.08, 0.45) * v_u_6(-0.2, 0, v156 * 0.12)
				v_u_43(p151, Vector3.new(0.26, 0.85, 1.2), v158, p151.body)
				v_u_43(p151, Vector3.new(0.28, 0.1, 0.9), v158 * v_u_5(0, 0.14, -0.05), v_u_36)
				v_u_43(p151, Vector3.new(0.28, 0.09, 0.6), v158 * v_u_5(0, -0.1, 0.22), p151.limbs)
				v_u_43(p151, Vector3.new(0.28, 0.09, 0.6), v158 * v_u_5(0, -0.30000000000000004, 0.22), p151.limbs)
			end
			p151.headC = Vector3.new(0, 2.3, -0.15)
			p151.headS = Vector3.new(1.85, 1.6, 1.6)
			p151.face = p151.headC.Z - p151.headS.Z / 2
			p151.eyeX = 0.44
			p151.eyeY = 2.28
			p151.mouthY = 1.88
			p151.bandY = 2.8
			p151.plateW = 0.8
			p151.neck = Vector3.new(0, 1.55, -0.72)
			p151.back = Vector3.new(0, 1.85, 0.85)
			v_u_41(p151, "Head", "Body", Vector3.new(0, 1.7, -0.1), "head")
			v_u_43(p151, p151.headS, v_u_5(p151.headC), p151.body)
			local v159 = p151.headC.Y - p151.headS.Y / 2 + 0.55
			v_u_43(p151, v_u_4(p151.headS.X - 0.12, 1.1, 0.1), v_u_5(0, v159, p151.face - 0.03), p151.belly)
			for v160 = -1, 1, 2 do
				local v161 = v160 * (p151.headS.X / 2 + 0.01)
				v_u_43(p151, v_u_4(0.06, 0.75, p151.headS.Z - 0.5), v_u_5(v161, v159 - 0.05, p151.headC.Z - 0.15), p151.belly)
				v_u_43(p151, Vector3.new(0.05, 0.28, 0.32), v_u_5(v161 + v160 * 0.04, v159 + 0.02, p151.headC.Z - 0.12), p151.accent)
			end
			local v162 = p151.face
			p151.face = v162 - 0.08
			v_u_50(p151, 0.4, 0.5)
			v_u_51(p151)
			p151.face = v162
			v_u_45(p151, Vector3.new(0.32, 0.22, 0.38), v_u_5(0, p151.mouthY + 0.02, p151.face - 0.27), v152)
			v_u_43(p151, Vector3.new(0.42, 0.24, 0.05), v_u_5(0, p151.mouthY - 0.22, p151.face - 0.1), p151.accent)
		end
		local function v172(p164) -- name: piglet
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (copy) v_u_52, (copy) v_u_41, (copy) v_u_49, (copy) v_u_50, (copy) v_u_35, (copy) v_u_51, (copy) v_u_39, (copy) v_u_40, (ref) v_u_4, (copy) v_u_46
			v_u_42(p164, "Body")
			p164.bodyC = Vector3.new(0, 1, 0.4)
			p164.bodyS = Vector3.new(1.85, 1.3, 2.05)
			v_u_43(p164, p164.bodyS, v_u_5(p164.bodyC), p164.body)
			v_u_43(p164, Vector3.new(1.3, 0.85, 0.1), v_u_5(0, 0.95, -0.63), p164.belly)
			v_u_52(p164, 0.55, -0.2, 1, Vector3.new(0.5, 0.5, 0.5))
			p164.tailAt = Vector3.new(0, 1.35, 1.45)
			v_u_41(p164, "Tail1", "Body", p164.tailAt, "tail", 0)
			local v165 = p164.tailAt
			local v166 = v165 + Vector3.new(0, 0.22, 0.3)
			local v167 = v166 + Vector3.new(0.16, 0.26, -0.04)
			local v168 = v167 + Vector3.new(-0.06, -0.04, -0.22)
			v_u_49(p164, v165, v166, 0.16, p164.body)
			v_u_49(p164, v166, v167, 0.15, p164.body)
			v_u_49(p164, v167, v168, 0.14, p164.body)
			p164.headC = Vector3.new(0, 2.15, -0.5)
			p164.headS = Vector3.new(2.15, 1.8, 1.75)
			p164.face = p164.headC.Z - p164.headS.Z / 2
			p164.eyeX = 0.5
			p164.eyeY = 2.1
			p164.mouthY = 1.62
			p164.bandY = 2.7
			p164.plateW = 0.9
			p164.neck = Vector3.new(0, 1.3, -0.68)
			p164.back = Vector3.new(0, 1.7, 1)
			v_u_41(p164, "Head", "Body", Vector3.new(0, 1.45, -0.35), "head")
			v_u_43(p164, p164.headS, v_u_5(p164.headC), p164.body)
			v_u_50(p164, 0.4, 0.52)
			v_u_43(p164, Vector3.new(0.82, 0.54, 0.3), v_u_5(0, p164.mouthY + 0.04, p164.face - 0.14), p164.accent)
			v_u_43(p164, Vector3.new(0.13, 0.18, 0.05), v_u_5(-0.17, p164.mouthY + 0.04, p164.face - 0.31), v_u_35)
			v_u_43(p164, Vector3.new(0.13, 0.18, 0.05), v_u_5(0.17, p164.mouthY + 0.04, p164.face - 0.31), v_u_35)
			v_u_43(p164, Vector3.new(0.3, 0.07, 0.05), v_u_5(0, p164.mouthY - 0.32, p164.face - 0.03), v_u_35)
			v_u_51(p164)
			if not v_u_39(p164.look, "boarmask") then
				local v169 = v_u_40(p164)
				for v170 = -1, 1, 2 do
					local v171 = v_u_4(v170 * (p164.headS.X / 2 - 0.08), v169 - 0.05, p164.headC.Z - 0.2)
					v_u_41(p164, v170 < 0 and "EarL" or "EarR", "Head", v171, "ear", v170 * 1.3, v170)
					v_u_46(p164, v171, v_u_4(-v170 * 0.6, 0, 0), (Vector3.new(0, 0.55, -0.25)).Unit * 0.6, 0.18, p164.body)
				end
			end
		end
		local v_u_173 = {
			Vector3.new(0, 2, -0.25),
			Vector3.new(0.6, 3, 0.5),
			Vector3.new(1.05, 2.8, 1.4),
			Vector3.new(0.35, 2, 1.95),
			Vector3.new(-0.75, 1.8, 2.35),
			Vector3.new(-1.2, 2.55, 2.85)
		}
		local v_u_174 = {
			1.15,
			1.02,
			0.9,
			0.74,
			0.58
		}
		local function v210(p175) -- name: waterdragon
			-- upvalues: (copy) v_u_42, (copy) v_u_76, (copy) v_u_173, (copy) v_u_174, (ref) v_u_5, (copy) v_u_47, (ref) v_u_7, (copy) v_u_46, (ref) v_u_4, (copy) v_u_41, (copy) v_u_43, (copy) v_u_35, (copy) v_u_50, (copy) v_u_51, (copy) v_u_40, (copy) v_u_49, (copy) v_u_48
			v_u_42(p175, "Body")
			local v176 = p175.accent
			local v177 = v_u_76(p175, v_u_173, v_u_174, 4, p175.body:Lerp(p175.glow, 0.25))
			for v178, v179 in v177 do
				v_u_42(p175, v178 == 1 and "Body" or "Seg" .. v178)
				local v180 = v179.th
				local v181 = v178 % 2 == 1
				local v182 = v179.cf * v_u_5(0, v180 * 0.4, 0)
				local v183 = (v182 * v_u_5(0, 0, -v179.len * 0.3)).Position
				local v184 = (v182 * v_u_5(0, 0, v179.len * 0.3)).Position
				local v185 = (v182 * v_u_5(0, v180 * 0.4 + 0.42, v179.len * 0.42)).Position
				local v186 = v_u_47
				local v187 = 0.12
				local v188
				if v181 then
					v188 = p175.glow
				else
					v188 = p175.limbs
				end
				local v189
				if v181 then
					v189 = v_u_7
				else
					v189 = nil
				end
				v186(p175, v184, v183, v185, v187, v188, v189)
				v_u_47(p175, v185, (v182 * v_u_5(0, v180 * 0.3 + 0.3, v179.len * 0.12)).Position, (v182 * v_u_5(0, v180 * 0.4 + 0.5, v179.len * 0.1)).Position, 0.16, v176)
			end
			v_u_42(p175, "Body")
			for v190 = -1, 1, 2 do
				v_u_46(p175, (v177[1].cf * v_u_5(v190 * 0.5, -0.3, 0)).Position, v_u_4(v190 * 0.6, -0.25, 0), Vector3.new(0, 0, 0.5), 0.1, p175.limbs)
			end
			local v191 = v_u_173[6]
			local v192 = (v191 - v_u_173[5]).Unit
			v_u_41(p175, "Fin", "Seg5", v191, "swim", 5.4)
			v_u_43(p175, Vector3.new(0.46, 0.46, 0.5), CFrame.lookAt(v191, v191 + v192), p175.body)
			local v193 = v192:Cross(Vector3.new(0, 1, 0)).Unit
			v_u_47(p175, v191, v191 + v192 * 0.9 + Vector3.new(0, 0.75, 0), v191 + v192 * 1.1 + v193 * 0.2, 0.12, p175.glow, v_u_7)
			v_u_47(p175, v191, v191 + v192 * 1 - Vector3.new(0, 0.6, 0), v191 + v192 * 1.1 - v193 * 0.2, 0.12, v176)
			p175.bodyC = (v_u_173[1] + v_u_173[2]) / 2
			p175.bodyS = Vector3.new(1.25, 1.15, 1.25)
			p175.tailAt = v191
			p175.headC = Vector3.new(0, 2.35, -1.05)
			p175.headS = Vector3.new(1.95, 1.55, 1.6)
			p175.face = p175.headC.Z - p175.headS.Z / 2
			p175.eyeX = 0.48
			p175.eyeY = 2.55
			p175.mouthY = 1.98
			p175.bandY = 2.85
			p175.plateW = 0.85
			p175.neck = Vector3.new(0, 1.5, -0.5)
			p175.back = Vector3.new(0, 2.75, 0.2)
			v_u_41(p175, "Head", "Body", v_u_173[1], "head")
			v_u_43(p175, p175.headS, v_u_5(p175.headC), p175.body)
			v_u_43(p175, Vector3.new(1.3, 0.62, 0.72), v_u_5(0, p175.mouthY + 0.02, p175.face - 0.3), p175.body)
			v_u_43(p175, Vector3.new(1, 0.14, 0.68), v_u_5(0, p175.mouthY - 0.3, p175.face - 0.28), p175.belly)
			v_u_43(p175, Vector3.new(0.14, 0.1, 0.05), v_u_5(-0.28, p175.mouthY + 0.18, p175.face - 0.67), v_u_35)
			v_u_43(p175, Vector3.new(0.14, 0.1, 0.05), v_u_5(0.28, p175.mouthY + 0.18, p175.face - 0.67), v_u_35)
			v_u_50(p175, 0.46, 0.52)
			v_u_51(p175)
			local v194 = v_u_40(p175)
			for v195 = -1, 1, 2 do
				local v196 = v_u_4(v195 * 0.5, v194 - 0.12, p175.headC.Z + 0.1)
				local v197 = v196 + v_u_4(v195 * 0.25, 0.55, 0.35)
				local v198 = v197 + v_u_4(v195 * 0.08, 0.3, 0.5)
				v_u_49(p175, v196, v197, 0.3, p175.limbs)
				v_u_49(p175, v197, v198, 0.2, p175.glow, v_u_7)
				local v199 = v_u_4(v195 * 0.62, p175.mouthY + 0.1, p175.face - 0.42)
				local v200 = v199 + v_u_4(v195 * 0.5, -0.12, 0.3)
				local v201 = v200 + v_u_4(v195 * 0.25, -0.35, 0.45)
				v_u_48(p175, v199, v200, 0.08, p175.glow, v_u_7)
				v_u_48(p175, v200, v201, 0.07, p175.glow, v_u_7)
			end
			for v202 = -1, 1 do
				local v203 = v202 * 0.55
				local v204 = v_u_47
				local v205 = v_u_4(v203 - 0.3, v194 - 0.02, p175.headC.Z + 0.25)
				local v206 = v_u_4(v203 + 0.3, v194 - 0.02, p175.headC.Z + 0.25)
				local v207 = v_u_4(v203 * 1.35, v194 - 0.5 + math.abs(v202) * 0.1, p175.headC.Z + 1.35)
				local v208 = 0.16
				local v209
				if v202 == 0 then
					v209 = v176
				else
					v209 = p175.limbs
				end
				v204(p175, v205, v206, v207, v208, v209)
			end
		end
		local function v241(p211) -- name: sundragon
			-- upvalues: (copy) v_u_42, (copy) v_u_38, (copy) v_u_43, (ref) v_u_4, (copy) v_u_41, (ref) v_u_5, (copy) p_u_31, (copy) v_u_35, (copy) v_u_50, (copy) v_u_40, (copy) v_u_49, (ref) v_u_7, (copy) v_u_48
			v_u_42(p211, "Body")
			local v212 = v_u_38(p211.look.tip or "#FFF4CC")
			local v213 = Vector3.new(0.0000000000000000887869, 1.0999999, 0.9)
			v_u_43(p211, v_u_4(1.05, 1, (Vector3.new(0, 2, -0.4) - v213).Magnitude + 0.5), CFrame.lookAt((v213 + Vector3.new(0, 2, -0.4)) / 2, Vector3.new(0, 2, -0.4)), p211.body)
			for v214 = 1, 7 do
				local v215 = (v214 - 1) * 5.1661745859032155 / 7 + -1.5707963267948966
				local v216 = Vector3.new(0, 2.55, 0.9) + v_u_4(math.cos(v215), math.sin(v215), 0) * 1.45
				local v217 = v214 * 5.1661745859032155 / 7 + -1.5707963267948966
				local v218 = Vector3.new(0, 2.55, 0.9) + v_u_4(math.cos(v217), math.sin(v217), 0) * 1.45
				if v214 == 6 then
					v_u_41(p211, "Seg6", "Body", v216, "neck", 0.8)
				elseif v214 == 7 then
					v_u_41(p211, "Seg7", "Seg6", v216, "neck", 1.6)
				end
				local v219 = 1.05 - (v214 - 1) * 0.07
				local v220 = (v216 + v218) / 2
				local v221 = (v220 - Vector3.new(0, 2.55, 0.9)).Unit
				local v222 = CFrame.fromMatrix(v220, v221, Vector3.new(0, 0, -1))
				local v223 = (v218 - v216).Magnitude + 0.32
				local v224 = v_u_43
				local v225 = v_u_4(v219, v219 * 0.9, v223)
				local v226
				if v214 % 2 == 0 then
					v226 = p211.body:Lerp(p211.glow, 0.2)
				else
					v226 = p211.body
				end
				v224(p211, v225, v222, v226)
				v_u_43(p211, v_u_4(v219 * 0.55, 0.1, v223 - 0.2), v222 * v_u_5(0, v219 * 0.45, 0), p211.belly)
				local v227 = (v218 - v216).Unit
				local v228 = CFrame.fromMatrix(v220 + v221 * v219 * 0.42, v227, v221)
				p_u_31.flameTongue(p211, v228, 0.8, v219 * 0.4 + 0.6, p211.glow, v212)
			end
			local v229 = Vector3.new(-1.3032514, 1.9143617, 0.9)
			local v230 = (v229 - Vector3.new(-1.3918191, 2.9566197, 0.9)).Unit
			v_u_41(p211, "Fin", "Seg7", v229, "tail", 2.4)
			local v231 = CFrame.fromMatrix(v229, v230:Cross(Vector3.new(0, 0, -1)).Unit, v230)
			p_u_31.flameTongue(p211, v231, 0.62, 1.05, p211.glow, v212)
			p211.bodyC = (v213 + Vector3.new(0, 2, -0.4)) / 2
			p211.bodyS = Vector3.new(1.05, 1, 1.2)
			p211.tailAt = v229
			p211.headC = Vector3.new(0, 2.45, -0.85)
			p211.headS = Vector3.new(1.95, 1.6, 1.6)
			p211.face = p211.headC.Z - p211.headS.Z / 2
			p211.eyeX = 0.48
			p211.eyeY = 2.62
			p211.mouthY = 2.05
			p211.bandY = 2.95
			p211.plateW = 0.85
			p211.neck = Vector3.new(0, 1.6, -0.6)
			p211.back = Vector3.new(0, 2.9, 0.4)
			v_u_41(p211, "Head", "Body", Vector3.new(0, 2, -0.4), "head")
			v_u_43(p211, p211.headS, v_u_5(p211.headC), p211.body)
			v_u_43(p211, Vector3.new(1.3, 0.62, 0.7), v_u_5(0, p211.mouthY + 0.02, p211.face - 0.3), p211.body)
			v_u_43(p211, Vector3.new(1, 0.14, 0.66), v_u_5(0, p211.mouthY - 0.3, p211.face - 0.28), p211.belly)
			v_u_43(p211, Vector3.new(0.14, 0.1, 0.05), v_u_5(-0.28, p211.mouthY + 0.18, p211.face - 0.66), v_u_35)
			v_u_43(p211, Vector3.new(0.14, 0.1, 0.05), v_u_5(0.28, p211.mouthY + 0.18, p211.face - 0.66), v_u_35)
			v_u_50(p211, 0.46, 0.5)
			local v232 = v_u_40(p211)
			local v233 = p211.belly
			for v234 = -1, 1, 2 do
				local v235 = v_u_4(v234 * 0.52, v232 - 0.12, p211.headC.Z + 0.1)
				local v236 = v235 + v_u_4(v234 * 0.28, 0.4, 0.3)
				local v237 = v236 + v_u_4(v234 * 0.1, 0.25, 0.4)
				v_u_49(p211, v235, v236, 0.24, v233)
				v_u_49(p211, v236, v237, 0.16, v212, v_u_7)
				local v238 = v_u_4(v234 * 0.62, p211.mouthY + 0.1, p211.face - 0.42)
				local v239 = v238 + v_u_4(v234 * 0.5, -0.1, 0.3)
				local v240 = v239 + v_u_4(v234 * 0.3, 0.3, 0.4)
				v_u_48(p211, v238, v239, 0.08, p211.glow, v_u_7)
				v_u_48(p211, v239, v240, 0.07, p211.glow, v_u_7)
			end
		end
		function v32.oni(p242) -- name: oni
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (copy) v_u_41, (ref) v_u_4, (copy) v_u_60, (copy) v_u_39, (copy) v_u_93, (copy) v_u_35, (copy) v_u_50, (copy) v_u_51, (ref) v_u_6, (copy) v_u_46, (copy) v_u_36
			v_u_42(p242, "Body")
			p242.bodyC = Vector3.new(0, 1.2, 0.1)
			p242.bodyS = Vector3.new(1.5, 1.2, 1.2)
			v_u_43(p242, p242.bodyS, v_u_5(p242.bodyC), p242.body)
			v_u_43(p242, Vector3.new(1.05, 0.78, 0.1), v_u_5(0, 1.12, -0.52), p242.belly)
			for v243 = -1, 1, 2 do
				local v244 = v243 * 0.38
				v_u_41(p242, v243 < 0 and "Leg1" or "Leg2", "Body", v_u_4(v244, 0.62, 0.1), "leg", v243 < 0 and 0 or 3.141592653589793)
				v_u_43(p242, Vector3.new(0.5, 0.64, 0.56), v_u_5(v244, 0.32, 0.08), p242.limbs)
			end
			v_u_60(p242, Vector3.new(0.72, 1.66, 0.08), Vector3.new(0.4, 0.82, 0.44), 0.22, p242.body)
			p242.headC = Vector3.new(0, 2.68, -0.02)
			p242.headS = Vector3.new(2.15, 1.8, 1.75)
			p242.face = p242.headC.Z - p242.headS.Z / 2
			p242.eyeX = 0.5
			p242.eyeY = 2.72
			p242.mouthY = 2.1
			p242.bandY = 3.2
			p242.plateW = 0.9
			p242.neck = Vector3.new(0, 1.78, -0.55)
			p242.back = Vector3.new(0, 1.75, 0.72)
			p242.tailAt = Vector3.new(0, 0.85, 0.7)
			v_u_41(p242, "Head", "Body", Vector3.new(0, 1.85, -0.02), "head")
			v_u_43(p242, p242.headS, v_u_5(p242.headC), p242.body)
			local v245 = p242.face - 0.03
			if v_u_39(p242.look, "sixeyes") then
				v_u_93(p242)
				v_u_43(p242, Vector3.new(0.42, 0.08, 0.05), v_u_5(0, p242.mouthY - 0.06, v245), v_u_35)
			else
				v_u_50(p242, 0.42, 0.56)
				v_u_51(p242)
				v_u_43(p242, Vector3.new(0.56, 0.1, 0.06), v_u_5(0, p242.mouthY, v245), v_u_35)
				for v246 = -1, 1, 2 do
					v_u_43(p242, Vector3.new(0.1, 0.18, 0.06), v_u_5(v246 * 0.31, p242.mouthY + 0.05, v245) * v_u_6(0, 0, v246 * 0.5), v_u_35)
				end
				v_u_46(p242, v_u_4(0.1, p242.mouthY - 0.04, v245 - 0.02), Vector3.new(0.14, 0, 0), Vector3.new(0, -0.2, 0), 0.05, v_u_36)
			end
		end
		v32.goldfish = v105
		v32.lotusdoll = v133
		v32.crow = v150
		v32.sparrow = v163
		v32.piglet = v172
		v32.waterdragon = v210
		v32.sundragon = v241
		function v33.sixeyes(_) -- name: sixeyes end
		function v33.lantern(p247) -- name: lantern
			-- upvalues: (copy) v_u_42, (copy) v_u_49, (ref) v_u_8, (copy) v_u_41, (copy) v_u_43, (ref) v_u_5, (ref) v_u_9, (ref) v_u_6, (copy) v_u_44, (ref) v_u_10, (ref) v_u_7, (ref) v_u_11
			local v248 = p247.byName.ArmR and "ArmR" or "Body"
			v_u_42(p247, v248)
			v_u_49(p247, Vector3.new(1.08, 0.9, 0.06), Vector3.new(1.18, 1.3, -0.66), 0.1, v_u_8)
			v_u_41(p247, "Lantern", v248, Vector3.new(1.18, 1.3, -0.66), "dangle", 0.7)
			v_u_43(p247, Vector3.new(0.05, 0.16, 0.05), v_u_5(Vector3.new(1.18, 1.23, -0.66)), v_u_9)
			local v249 = v_u_5(Vector3.new(1.18, 0.65999997, -0.66)) * v_u_6(0, 0, 1.5707963267948966)
			v_u_44(p247, 0.8, 0.74, v249, v_u_10, v_u_7)
			v_u_44(p247, 0.12, 0.52, v249 * v_u_5(0.44, 0, 0), v_u_9)
			v_u_44(p247, 0.12, 0.52, v249 * v_u_5(-0.44, 0, 0), v_u_9)
			for v250 = -1, 1, 2 do
				v_u_44(p247, 0.04, 0.77, v249 * v_u_5(v250 * 0.18, 0, 0), v_u_10:Lerp(v_u_11, 0.55))
			end
			v_u_43(p247, Vector3.new(0.2, 0.3, 0.06), v_u_5(Vector3.new(1.18, 0.65999997, -1.03)), v_u_11)
		end
		function v33.tigerloin(p251) -- name: tigerloin
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_4, (ref) v_u_5, (ref) v_u_13, (ref) v_u_6, (ref) v_u_14
			v_u_42(p251, "Body")
			local v252 = p251.bodyC
			local v253 = p251.bodyS
			local v254 = v252.Y - v253.Y / 2 + 0.2
			v_u_43(p251, v_u_4(v253.X + 0.1, 0.42, v253.Z + 0.16), v_u_5(v252.X, v254, v252.Z), v_u_13)
			local v255 = v252.Z - (v253.Z + 0.16) / 2 - 0.02
			for v256 = -1, 1 do
				v_u_43(p251, Vector3.new(0.09, 0.32, 0.04), v_u_5(v256 * 0.45, v254 + 0.02, v255) * v_u_6(0, 0, 0.3), v_u_14)
			end
			for v257 = -1, 1, 2 do
				v_u_43(p251, Vector3.new(0.04, 0.32, 0.09), v_u_5(v257 * (v253.X / 2 + 0.07), v254, v252.Z) * v_u_6(0.3, 0, 0), v_u_14)
			end
		end
		function v33.kimono(p258) -- name: kimono
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (ref) v_u_4, (copy) v_u_48, (ref) v_u_6
			v_u_42(p258, "Body")
			local v259 = p258.bodyC
			local v260 = p258.bodyS
			v_u_43(p258, v260 + Vector3.new(0.1, 0.04, 0.2), v_u_5(v259 + Vector3.new(0, 0.02, 0)), p258.cloth)
			v_u_43(p258, v_u_4(v260.X + 0.14, 0.24, v260.Z + 0.24), v_u_5(v259.X, v259.Y - 0.22, v259.Z), p258.limbs)
			local v261 = v259.Z - (v260.Z + 0.2) / 2 - 0.04
			for v262 = -1, 1, 2 do
				v_u_48(p258, v_u_4(v262 * 0.42, v259.Y + v260.Y / 2 - 0.02, v261), v_u_4(-v262 * 0.06, v259.Y - 0.08, v261), 0.12, p258.limbs)
			end
			for v263 = -1, 1, 2 do
				local v264 = v263 < 0 and "ArmL" or "ArmR"
				if not p258.byName[v264] then
					continue
				end
				v_u_42(p258, v264)
				v_u_43(p258, Vector3.new(0.6, 0.86, 0.64), v_u_5(p258.byName[v264].hinge + v_u_4(v263 * 0.2538387379247738, -0.35, 0)) * v_u_6(0, 0, v263 * 0.22), p258.cloth)
			end
		end
		function v33.kokuhair(p265) -- name: kokuhair
			-- upvalues: (copy) v_u_42, (copy) v_u_40, (copy) v_u_43, (ref) v_u_4, (ref) v_u_5, (ref) v_u_16, (copy) v_u_46, (copy) v_u_41, (copy) v_u_49
			v_u_42(p265, "Head")
			local v266 = v_u_40(p265)
			local v267 = p265.headC
			local v268 = p265.headS
			v_u_43(p265, v_u_4(v268.X + 0.12, 0.34, v268.Z + 0.1), v_u_5(v267.X, v266 + 0.08, v267.Z + 0.02), v_u_16)
			v_u_43(p265, v_u_4(v268.X + 0.12, v268.Y * 0.7, 0.32), v_u_5(v267.X, v266 - v268.Y * 0.3, v267.Z + v268.Z / 2 + 0.1), v_u_16)
			local v269 = p265.face - 0.05
			for v270 = -1, 1, 2 do
				v_u_43(p265, v_u_4(0.2, v268.Y * 0.72, 0.6), v_u_5(v270 * (v268.X / 2 + 0.06), v266 - v268.Y * 0.36, p265.face + 0.3), v_u_16)
				v_u_46(p265, v_u_4(v270 * 0.95, v266 + 0.04, v269), v_u_4(-v270 * 0.9, 0, 0), Vector3.new(0, -0.34, 0), 0.12, v_u_16)
			end
			local v271 = v_u_4(0, v266 + 0.12, v267.Z + v268.Z / 2 - 0.15)
			v_u_41(p265, "Hair", "Head", v271, "tail", 0.6)
			v_u_43(p265, Vector3.new(0.4, 0.22, 0.34), v_u_5(v271 + Vector3.new(0, 0.06, 0.05)), p265.accent)
			local v272 = v271 + Vector3.new(0, 0.16, 0.45)
			local v273 = v272 + Vector3.new(0, -0.55, 0.42)
			local v274 = v273 + Vector3.new(0, -0.8, 0.16)
			v_u_49(p265, v271, v272, 0.44, v_u_16)
			v_u_49(p265, v272, v273, 0.38, v_u_16)
			v_u_49(p265, v273, v274, 0.3, v_u_16)
		end
		function v33.moonmarks(p275) -- name: moonmarks
			-- upvalues: (copy) v_u_42, (copy) v_u_47, (ref) v_u_4
			v_u_42(p275, "Head")
			local v276 = p275.face - 0.03
			local v277 = p275.eyeY + 0.38
			v_u_47(p275, v_u_4(-0.98, v277, v276), v_u_4(-0.6599999999999999, v277, v276), v_u_4(-0.74, v277 + 0.42, v276), 0.05, p275.accent)
			local v278 = p275.mouthY - 0.3
			v_u_47(p275, v_u_4(0.732, v278, v276), v_u_4(0.988, v278, v276), v_u_4(0.78, v278 + 0.336, v276), 0.05, p275.accent)
		end
		function v33.moonblade(p279) -- name: moonblade
			-- upvalues: (copy) v_u_42, (copy) v_u_48, (ref) v_u_17, (copy) v_u_35, (copy) v_u_43, (ref) v_u_6, (ref) v_u_18, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (copy) v_u_46, (copy) v_u_38
			v_u_42(p279, p279.byName.ArmR and "ArmR" or "Body")
			local v280 = (Vector3.new(0.68, 0.7, -0.22)).Unit
			local v281 = Vector3.new(1.08, 0.9, 0.06) + v280 * 0.46
			v_u_48(p279, Vector3.new(1.08, 0.9, 0.06) - v280 * 0.06, v281, 0.18, v_u_17:Lerp(v_u_35, 0.4))
			v_u_43(p279, Vector3.new(0.46, 0.46, 0.1), CFrame.lookAt(v281, v281 + v280) * v_u_6(0, 0, 0.7853981633974483), v_u_18)
			local v282 = v280:Cross(Vector3.new(0, 0, 1)).Unit
			local v283 = {}
			for v284 = 0, 4 do
				local v285 = v284 / 4
				local v286 = v281 + v280 * 2.1 * v285 - v282 * 0.62 * v285 * v285
				table.insert(v283, v286)
			end
			local v287 = v280:Cross(v282).Unit
			for v288 = 1, 4 do
				local v289 = v283[v288]
				local v290 = v283[v288 + 1]
				local v291 = 0.4 - v288 * 0.05
				local v292 = CFrame.lookAt((v289 + v290) / 2, v290, v282)
				local v293 = (v290 - v289).Magnitude + 0.08
				v_u_43(p279, v_u_4(0.1, v291, v293), v292, v_u_17)
				v_u_43(p279, v_u_4(0.07, 0.08, v293), v292 * v_u_5(0, v291 / 2 + 0.03, 0), v_u_18, v_u_7)
			end
			for _, v294 in { 0.38, 0.68 } do
				local v295 = v294 * 4
				local v296 = math.floor(v295) + 1
				v_u_46(p279, v283[v296]:Lerp(v283[v296 + 1], v294 * 4 - (v296 - 1)), v280 * 0.45, v282 * 0.5, 0.08, v_u_17)
			end
			for _, v297 in { 0.2, 0.48, 0.76 } do
				local v298 = v297 * 4
				local v299 = math.floor(v298) + 1
				local v300 = v283[v299]:Lerp(v283[v299 + 1], v297 * 4 - (v299 - 1)) + v287 * 0.06
				local v301 = CFrame.lookAt(v300, v300 + v287, v282)
				v_u_43(p279, Vector3.new(0.15, 0.22, 0.04), v301, v_u_38(p279.look.eye or "#FFD23D"), v_u_7)
				v_u_43(p279, Vector3.new(0.05, 0.16, 0.04), v301 * v_u_5(0, 0, -0.03), v_u_35)
			end
		end
		function v33.threadweb(p302) -- name: threadweb
			-- upvalues: (copy) v_u_42, (ref) v_u_4, (copy) v_u_48, (ref) v_u_7
			v_u_42(p302, p302.byName.Tail1 and "Tail1" or "Body")
			local v303 = p302.bodyC
			local v304 = p302.bodyS
			local v305 = v_u_4(v303.X, v303.Y + v304.Y / 2 + 0.03, v303.Z)
			local v306 = v304.X
			local v307 = v304.Z
			local v308 = math.min(v306, v307) * 0.38
			local v309 = {}
			for v310 = 0, 5 do
				local v311 = v310 * 3.141592653589793 / 3 + 0.5235987755982988
				local v312 = v305 + v_u_4(math.cos(v311), 0, (math.sin(v311))) * v308
				table.insert(v309, v312)
				v_u_48(p302, v305, v312, 0.06, p302.glow, v_u_7)
			end
			for _, v313 in { 0.5, 0.92 } do
				for v314 = 1, 6 do
					local v315 = v309[v314]
					local v316 = v309[v314 % 6 + 1]
					v_u_48(p302, v305 + (v315 - v305) * v313, v305 + (v316 - v305) * v313, 0.06, p302.glow, v_u_7)
				end
			end
		end
		function v33.threadknots(p317) -- name: threadknots
			-- upvalues: (copy) v_u_42, (ref) v_u_4, (copy) v_u_43, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7
			local v318 = {
				-0.42,
				-0.14,
				0.14,
				0.42
			}
			local v319 = {
				-0.8,
				-0.28,
				0.28,
				0.8
			}
			for v320 = -1, 1, 2 do
				for v321, v322 in v318 do
					local v323 = (v320 < 0 and "LegL" or "LegR") .. v321
					if not p317.byName[v323] then
						continue
					end
					v_u_42(p317, v323)
					v_u_43(p317, Vector3.new(0.3, 0.3, 0.3), v_u_5((v_u_4(v320 * 1.45, 1.8, v322 + v319[v321] * 0.55))) * v_u_6(0, 0.7853981633974483, 0), p317.glow, v_u_7)
				end
			end
		end
		function v33.ruimarks(p324) -- name: ruimarks
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (ref) v_u_6
			v_u_42(p324, "Head")
			local v325 = p324.face - 0.03
			for v326 = -1, 1, 2 do
				for v327 = -1, 1 do
					v_u_43(p324, Vector3.new(0.24, 0.06, 0.04), v_u_5(v326 * (p324.eyeX + 0.36), p324.eyeY + 0.02 + v327 * 0.13, v325) * v_u_6(0, 0, v326 * v327 * 0.35), p324.accent)
				end
			end
		end
		function v33.needlefins(p328) -- name: needlefins
			-- upvalues: (copy) v_u_42, (ref) v_u_4, (copy) v_u_48, (ref) v_u_15, (copy) v_u_43, (ref) v_u_5, (ref) v_u_7
			v_u_42(p328, "Body")
			local v329 = p328.bodyC.Y + p328.bodyS.Y / 2
			for v330 = 0, 4 do
				local v331 = v_u_4(0, v329 - 0.05, v330 * 0.22 + 0.1)
				local v332 = v330 * 9 + -12
				local v333 = math.rad(v332)
				local v334 = v_u_4(0, math.cos(v333), (math.sin(v333)))
				local v335 = v330 - 1.5
				local v336 = v331 + v334 * (1.08 - math.abs(v335) * 0.08)
				v_u_48(p328, v331, v336, 0.07, v_u_15)
				v_u_43(p328, Vector3.new(0.11, 0.11, 0.11), v_u_5(v336), p328.glow, v_u_7)
			end
			for v337 = -1, 1, 2 do
				local v338 = v337 < 0 and "WingL" or "WingR"
				local v339 = p328.byName[v338]
				if not v339 then
					continue
				end
				v_u_42(p328, v338)
				for v340 = 0, 2 do
					local v341 = v339.hinge + v_u_4(v337 * 0.95, -0.2 - v340 * 0.12, v340 * 0.32 + 0.1)
					v_u_48(p328, v339.hinge, v341, 0.06, v_u_15)
					v_u_43(p328, Vector3.new(0.1, 0.1, 0.1), v_u_5(v341), p328.glow, v_u_7)
				end
			end
		end
		function v33.icefans(p342) -- name: icefans
			-- upvalues: (copy) v_u_42, (ref) v_u_4, (copy) v_u_47, (ref) v_u_27, (ref) v_u_28, (copy) v_u_48, (ref) v_u_7
			for v343 = -1, 1, 2 do
				local v344 = v343 < 0 and "ArmL" or "ArmR"
				v_u_42(p342, not p342.byName[v344] and "Body" or v344)
				local v345 = v_u_4(v343 * 0.86, 0.82, -0.32)
				local v346 = v343 > 0 and 0.17453292519943295 or 0.8726646259971648
				for v347 = 0, 2 do
					local v348 = v346 + v347 * 0.6981317007977318
					local v349 = v346 + (v347 + 1) * 0.6981317007977318
					local v350 = v345 + v_u_4(math.cos(v348), math.sin(v348), 0) * 0.72
					local v351 = v345 + v_u_4(math.cos(v349), math.sin(v349), 0) * 0.72
					local v352 = v_u_47
					local v353 = 0.08
					local v354
					if v347 % 2 == 0 then
						v354 = v_u_27
					else
						v354 = v_u_28
					end
					v352(p342, v345, v350, v351, v353, v354)
					if v347 ~= 1 then
						continue
					end
					v_u_48(p342, v350, v351, 0.07, p342.glow, v_u_7)
				end
			end
		end
		function v33.checkbandana(p355) -- name: checkbandana
			-- upvalues: (copy) v_u_42, (copy) v_u_43, (ref) v_u_5, (ref) v_u_21, (copy) v_u_46, (ref) v_u_4
			v_u_42(p355, "Body")
			local v356 = p355.neck
			local v357 = v356.Z
			v_u_43(p355, Vector3.new(1.3, 0.22, 0.1), v_u_5(v356.X, v356.Y, v357), p355.cloth)
			for v358 = 0, 2 do
				v_u_43(p355, Vector3.new(0.2, 0.23, 0.11), v_u_5(v358 * 0.44 + -0.44, v356.Y, v357 - 0.005), v_u_21)
			end
			v_u_46(p355, v_u_4(0, v356.Y - 0.1, v357 + 0.02), Vector3.new(-0.55, 0, 0), Vector3.new(0, -0.75, 0), 0.08, p355.cloth)
			v_u_46(p355, v_u_4(0, v356.Y - 0.1, v357 + 0.02), Vector3.new(0.55, 0, 0), Vector3.new(0, -0.75, 0), 0.08, p355.cloth)
			for v359, v360 in {
				{ -0.36, 0, 0.36 },
				{ -0.18, 0.18 },
				{ 0 }
			} do
				for _, v361 in v360 do
					v_u_43(p355, Vector3.new(0.18, 0.18, 0.04), v_u_5(v361, v356.Y - 0.1 - 0.18 * (v359 - 0.5) * 1.15, v357 - 0.04), v_u_21)
				end
			end
		end
		function v33.letter(p362) -- name: letter
			-- upvalues: (copy) v_u_42, (copy) v_u_44, (ref) v_u_5, (ref) v_u_19, (ref) v_u_20
			v_u_42(p362, "Body")
			local v363 = p362.back + Vector3.new(0, 0.08, 0)
			v_u_44(p362, 0.8, 0.28, v_u_5(v363), v_u_19)
			v_u_44(p362, 0.07, 0.31, v_u_5(v363 + Vector3.new(-0.18, 0, 0)), v_u_20)
			v_u_44(p362, 0.07, 0.31, v_u_5(v363 + Vector3.new(0.18, 0, 0)), v_u_20)
		end
		function v33.boarmask(p364) -- name: boarmask
			-- upvalues: (copy) v_u_42, (copy) v_u_40, (copy) v_u_35, (copy) v_u_43, (ref) v_u_4, (ref) v_u_5, (ref) v_u_23, (copy) v_u_46, (ref) v_u_12, (ref) v_u_24, (copy) p_u_31, (copy) v_u_47
			v_u_42(p364, "Head")
			local v365 = p364.headC
			local v366 = p364.headS
			local v367 = v_u_40(p364)
			local v368 = p364.cloth
			local v369 = v368:Lerp(v_u_35, 0.45)
			v_u_43(p364, v_u_4(v366.X + 0.16, 0.85, v366.Z + 0.12), v_u_5(0, v367 - 0.22, v365.Z + 0.03), v368)
			local v370 = v365.Z - (v366.Z + 0.12) / 2 + 0.03
			local v371 = v367 - 0.3
			v_u_43(p364, Vector3.new(0.92, 0.56, 0.52), v_u_5(0, v371, v370 - 0.22), v368)
			v_u_43(p364, Vector3.new(0.74, 0.46, 0.1), v_u_5(0, v371, v370 - 0.5), v_u_23)
			for v372 = -1, 1, 2 do
				v_u_43(p364, Vector3.new(0.13, 0.18, 0.05), v_u_5(v372 * 0.17, v371, v370 - 0.56), v_u_35)
				v_u_46(p364, v_u_4(v372 * 0.6, v371 - 0.26, v370 - 0.44), v_u_4(-v372 * 0.16, 0, 0), Vector3.new(0, 0.5, 0), 0.12, v_u_12)
				v_u_43(p364, Vector3.new(0.26, 0.26, 0.06), v_u_5(v372 * 0.7, v371 + 0.12, v370 - 0.02), v_u_24)
				v_u_43(p364, Vector3.new(0.1, 0.1, 0.04), v_u_5(v372 * 0.7, v371 + 0.12, v370 - 0.06), v_u_35)
				local v373 = v_u_4(v372 * (v366.X / 2 - 0.05), v367 + 0.18, v365.Z - 0.05)
				local v374 = -v372 * 0.25
				v_u_46(p364, v373, p_u_31.rotZ(v_u_4(-v372 * 0.5, 0, 0), v374), p_u_31.rotZ(Vector3.new(0, 0.55, 0), v374), 0.24, v368)
			end
			local v375 = v365.Z + (v366.Z + 0.12) / 2 + 0.03
			for v376 = 0, 2 do
				local v377 = v367 + 0.1 - v376 * 0.32
				v_u_47(p364, v_u_4(-0.35, v377, v375), v_u_4(0.35, v377, v375), v_u_4(0, v377 - 0.5, v375 + 0.12), 0.12, v369)
			end
			v_u_47(p364, v_u_4(-0.32, v367 + 0.2, v365.Z - 0.4), v_u_4(0.32, v367 + 0.2, v365.Z - 0.4), v_u_4(0, v367 + 0.5, v365.Z + 0.2), 0.14, v369)
		end
		function v33.boarblades(p378) -- name: boarblades
			-- upvalues: (copy) v_u_42, (ref) v_u_5, (ref) v_u_6, (copy) v_u_43, (ref) v_u_26, (ref) v_u_18, (copy) v_u_35, (ref) v_u_25, (copy) v_u_46
			v_u_42(p378, "Body")
			local v379 = p378.back + Vector3.new(0, 0.75, 0.15)
			for v380 = -1, 1, 2 do
				local v381 = v_u_5(v379) * v_u_6(0, 0, v380 * 0.6)
				v_u_43(p378, Vector3.new(0.14, 0.46, 0.14), v381 * v_u_5(0, 1.05, 0), v_u_26)
				v_u_43(p378, Vector3.new(0.3, 0.07, 0.2), v381 * v_u_5(0, 0.8, 0), v_u_18:Lerp(v_u_35, 0.3))
				v_u_43(p378, Vector3.new(0.24, 1.45, 0.07), v381 * v_u_5(0, 0.05, 0), v_u_25)
				for v382 = 0, 2 do
					v_u_46(p378, (v381 * v_u_5(0.12, 0.45 - v382 * 0.42, 0)).Position, v381.YVector * -0.2, v381.XVector * 0.12, 0.06, v_u_25)
				end
			end
		end
		function v33.hanafuda(p383) -- name: hanafuda
			-- upvalues: (copy) v_u_42, (ref) v_u_4, (copy) v_u_43, (ref) v_u_5, (copy) v_u_35, (ref) v_u_6, (ref) v_u_30, (ref) v_u_11
			v_u_42(p383, "Head")
			local v384 = p383.headS
			for v385 = -1, 1, 2 do
				local v386 = v_u_4(v385 * (v384.X / 2 + 0.06), p383.mouthY + 0.05, p383.headC.Z - 0.15)
				v_u_43(p383, Vector3.new(0.05, 0.22, 0.05), v_u_5(v386 + Vector3.new(0, 0.1, 0)), v_u_35)
				local v387 = v386 - Vector3.new(0, 0.32, 0)
				v_u_43(p383, Vector3.new(0.36, 0.56, 0.06), v_u_5(v387) * v_u_6(0, -v385 * 0.5, 0), v_u_30)
				local v388 = v_u_5(v387) * v_u_6(0, -v385 * 0.5, 0) * v_u_5(0, 0, -0.05)
				v_u_43(p383, Vector3.new(0.16, 0.16, 0.04), v388 * v_u_5(0, -0.06, 0) * v_u_6(0, 0, 0.7853981633974483), v_u_11)
				v_u_43(p383, Vector3.new(0.3, 0.06, 0.04), v388 * v_u_5(0, 0.18, 0), v_u_11)
			end
		end
		local v389 = p_u_31.AURA_STYLES
		local v390 = p_u_31.AURAS
		local v_u_391 = p_u_31.feetRing
		local v_u_392 = p_u_31.feetPicture
		local v393 = p_u_31.shades
		v389.moonbreath = {
			["flame"] = nil,
			["flameGlow"] = 0.3,
			["motes"] = nil,
			["moteColor"] = nil,
			["moteTexture"] = nil,
			["stars"] = nil,
			["starTexture"] = nil,
			["light"] = nil,
			["flame"] = v393("#D49BFF", "#9B3BE0", "#5A0A2E"),
			["motes"] = { "Petals", "Motes" },
			["moteColor"] = ColorSequence.new(v_u_38("#FFF2B0"), v_u_38("#FFD23D")),
			["moteTexture"] = v_u_2.MurcielagoMoon,
			["stars"] = ColorSequence.new(v_u_38("#FFF2B0"), v_u_38("#FFD23D")),
			["starTexture"] = v_u_2.PolarStar,
			["light"] = v_u_38("#B05CFF")
		}
		function v390.moonbreath(p394, p395, p396)
			-- upvalues: (ref) v_u_3, (copy) v_u_392, (ref) v_u_2, (copy) v_u_38, (copy) v_u_391
			if v_u_3.level() >= 2 then
				v_u_392(p394, p395, "MoonCrescent", v_u_2.MurcielagoMoon, p396 * 2.3, v_u_38("#FFD23D"), NumberRange.new(25, 35), 0.7)
				v_u_391(p394, p395, p396, v_u_38("#B05CFF"), 0.8 * v_u_3.formRate())
			end
		end
		v389.sunbreath = {
			["flame"] = nil,
			["flameGlow"] = 0.35,
			["motes"] = nil,
			["moteColor"] = nil,
			["stars"] = nil,
			["starTexture"] = nil,
			["light"] = nil,
			["flame"] = v393("#FFF4CC", "#FFB21F", "#FF3A1A"),
			["motes"] = { "Fire", "Embers" },
			["moteColor"] = ColorSequence.new(v_u_38("#FFE28A"), v_u_38("#FF5A1A")),
			["stars"] = ColorSequence.new(v_u_38("#FFF2B0"), v_u_38("#FFB21F")),
			["starTexture"] = v_u_2.PolarStar,
			["light"] = v_u_38("#FFB21F")
		}
		function v390.sunbreath(p397, p398, p399)
			-- upvalues: (ref) v_u_3, (copy) v_u_392, (ref) v_u_2, (copy) v_u_38, (copy) v_u_391
			if v_u_3.level() >= 2 then
				v_u_392(p397, p398, "SunDisc", v_u_2.EmberSun, p399 * 2.4, v_u_38("#FFC23A"), NumberRange.new(15, 25), 0.8)
				v_u_391(p397, p398, p399, v_u_38("#FF7A1A"), 0.9 * v_u_3.formRate())
			end
		end
	end
}