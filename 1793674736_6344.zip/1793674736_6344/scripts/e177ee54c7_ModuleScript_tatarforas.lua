local v_u_1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v3 = require(script.Parent.Parent.Preload)
local v_u_4 = require(script.Parent.Parent.Parent.Perf)
local v_u_5 = require(v_u_1.Shared.Config.Textures)
v3.images({
	v_u_5.TatarEye,
	v_u_5.TatarVeins,
	v_u_5.HollowRing,
	v_u_5.FxSmoke
})
local v_u_6 = Color3.fromRGB(60, 10, 110)
local v_u_7 = Color3.fromRGB(12, 6, 20)
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = Enum.Material.Neon
local v_u_10 = Enum.Material.SmoothPlastic
local v_u_11 = Enum.ParticleFlipbookLayout.Grid4x4
local v_u_12 = CFrame.identity
local function v_u_21(p13, p14) -- name: eyePiece
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v15 = v_u_1:FindFirstChild("EyePieces")
	if v15 then
		v15 = v15:FindFirstChild(p13)
	end
	if not (v15 and v15:IsA("MeshPart")) then
		return nil
	end
	local v16 = v15:Clone()
	local v17 = v15.Size
	local v18 = v17.X
	local v19 = v17.Y
	local v20 = v17.Z
	v16.Size = v17 * (p14 / math.max(v18, v19, v20, 0.01))
	v16.Anchored = true
	v16.CanCollide = false
	v16.CanQuery = false
	v16.CanTouch = false
	v16.Massless = true
	v16.CastShadow = false
	v16.Parent = v_u_2.folder()
	return v16
end
local function v_u_26(p22, p23, p24) -- name: thornHalves
	local v25 = math.max(p23, 0.05)
	return p22 * CFrame.new(0, v25 / 2, -p24 / 4), p22 * CFrame.new(0, v25 / 2, p24 / 4) * CFrame.Angles(0, 3.141592653589793, 0)
end
local function v_u_31(p27, p28, p29) -- name: floorEmitter
	local v30 = Instance.new("ParticleEmitter")
	v30.Texture = p27
	v30.Color = ColorSequence.new(p28)
	v30.LightEmission = p29
	v30.LightInfluence = 0
	v30.Orientation = Enum.ParticleOrientation.VelocityPerpendicular
	v30.EmissionDirection = Enum.NormalId.Top
	v30.SpreadAngle = Vector2.zero
	v30.Speed = NumberRange.new(0.01)
	v30.Rate = 0
	v30.Enabled = false
	v30.LockedToPart = true
	return v30
end
return function(p_u_32)
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_31, (copy) v_u_5, (copy) v_u_11, (copy) v_u_8, (copy) v_u_21, (copy) v_u_10, (copy) v_u_12, (copy) v_u_4, (copy) v_u_6, (copy) v_u_9, (copy) v_u_26
	return {
		["w7_tatarforas"] = function(p_u_33, p34)
			-- upvalues: (ref) v_u_2, (ref) v_u_7, (copy) p_u_32, (ref) v_u_31, (ref) v_u_5, (ref) v_u_11, (ref) v_u_8, (ref) v_u_21, (ref) v_u_10, (ref) v_u_12, (ref) v_u_4, (ref) v_u_6, (ref) v_u_9, (ref) v_u_26
			local v35 = v_u_2.color(p34.color)
			local v36 = p_u_33.headY / 1.5
			local v_u_37 = math.clamp(v36, 0.7, 3)
			local v38 = p_u_33.fx
			local v39 = math.min(v38, 1.6)
			local v40 = v_u_2.part
			local v41 = v_u_37 * 2.4
			local v42 = v_u_37 * 2.4
			local v43 = v40(Vector3.new(v41, 0.2, v42), CFrame.identity, v_u_7, {
				["transparency"] = 1
			})
			v43.Massless = true
			p_u_32.add(p_u_33, v43, function(p44)
				-- upvalues: (ref) p_u_32, (copy) p_u_33
				return CFrame.new(p_u_32.feetAt(p_u_33, p44, 0.12))
			end)
			p_u_32.own(p_u_33, v43)
			local v45 = Instance.new("Attachment")
			v45.Parent = v43
			local v_u_46 = v_u_31(v_u_5.HollowRing, v35, 0.15)
			v_u_46.FlipbookLayout = v_u_11
			v_u_46.FlipbookMode = Enum.ParticleFlipbookMode.OneShot
			v_u_46.Lifetime = NumberRange.new(0.6)
			v_u_46.Size = NumberSequence.new(v_u_37 * 2.6 * v39)
			v_u_46.Rotation = NumberRange.new(0, 360)
			v_u_46.Parent = v45
			local v_u_47 = v_u_31(v_u_5.TatarEye, v_u_8, 0.05)
			v_u_47.Lifetime = NumberRange.new(1.1)
			v_u_47.Size = NumberSequence.new(v_u_37 * 2.6 * v39)
			v_u_47.Squash = NumberSequence.new({
				NumberSequenceKeypoint.new(0, -3),
				NumberSequenceKeypoint.new(0.18, 0),
				NumberSequenceKeypoint.new(0.75, 0),
				NumberSequenceKeypoint.new(0.92, -3),
				NumberSequenceKeypoint.new(1, -3)
			})
			v_u_47.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 0.3),
				NumberSequenceKeypoint.new(0.15, 0),
				NumberSequenceKeypoint.new(0.85, 0),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_47.Rotation = NumberRange.new(0)
			v_u_47.Parent = v45
			local v_u_48 = p_u_32.throb(p_u_33, 5, 1.8, 1.3, function()
				-- upvalues: (copy) v_u_46, (copy) v_u_47
				v_u_46:Emit(1)
				v_u_47:Emit(1)
			end)
			local v_u_49 = 0
			local v50 = p_u_33.ticks
			local function v52(_, _, p51)
				-- upvalues: (ref) v_u_49, (copy) v_u_48
				v_u_49 = v_u_49 + p51 * (0.35 + v_u_48() * 4)
			end
			table.insert(v50, v52)
			local v58 = p_u_32.group(p_u_33, function(p53, p54)
				-- upvalues: (copy) p_u_33, (copy) v_u_37, (ref) v_u_49
				local v55 = CFrame.new
				local v56 = p_u_33.headY + v_u_37 * 0.2
				local v57 = p54 * 1.3
				return p53 * v55(0, v56 + math.sin(v57) * 0.08 * v_u_37, v_u_37 * 0.8) * CFrame.Angles(0, 0, v_u_49)
			end)
			local v59 = v_u_37 * 4.2
			local v60 = v_u_21("w7_tatarforas", v59)
			local v_u_61 = nil
			if v60 then
				v_u_61 = v60:FindFirstChildWhichIsA("SurfaceAppearance")
				if not v_u_61 then
					v60.Color = v_u_7
					v60.Material = v_u_10
					v60.Reflectance = 0.15
				end
				p_u_32.pin(p_u_33, v58, v60, v_u_12)
			else
				v60 = v_u_2.part(Vector3.new(0.2, 0.2, 0.2), CFrame.identity, v_u_7, {
					["transparency"] = 1
				})
				p_u_32.pin(p_u_33, v58, v60, CFrame.identity)
				for v62 = 1, 8 do
					local v63 = v_u_7
					local v64 = v_u_10
					local v65 = Instance.new("WedgePart")
					v65.Anchored = true
					v65.CanCollide = false
					v65.CanQuery = false
					v65.CanTouch = false
					v65.CastShadow = false
					v65.Massless = true
					v65.Color = v63
					v65.Material = v64
					v65.Size = Vector3.new(0.1, 0.1, 0.1)
					v65.Parent = v_u_2.folder()
					local v66 = v_u_37 * 0.12
					local v67 = v_u_37 * 0.8
					local v68 = v_u_37 * 0.3
					v65.Size = Vector3.new(v66, v67, v68)
					local v69 = CFrame.Angles(0, 0, v62 * 3.141592653589793 / 4) * CFrame.new(0, v59 * 0.3, 0)
					p_u_32.pin(p_u_33, v58, v65, v69 * CFrame.new(0, v_u_37 * 0.4, 0) * CFrame.Angles(0, 1.5707963267948966, 0))
				end
			end
			local v70 = Instance.new("Attachment")
			v70.Parent = v60
			local v_u_71 = Instance.new("ParticleEmitter")
			v_u_71.Texture = v_u_5.Glow
			v_u_71.Color = ColorSequence.new(v35)
			v_u_71.LightEmission = 0.6
			v_u_71.LightInfluence = 0
			v_u_71.LockedToPart = true
			v_u_71.Lifetime = NumberRange.new(0.5)
			v_u_71.Speed = NumberRange.new(0)
			v_u_71.Size = NumberSequence.new(v59 * 0.45 * v39)
			v_u_71.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.3, 0.5),
				NumberSequenceKeypoint.new(0.7, 0.5),
				NumberSequenceKeypoint.new(1, 1)
			})
			v_u_71:SetAttribute("BaseRate", 6)
			v_u_71.Rate = 6 * v_u_4.formRate()
			v_u_71.Parent = v70
			p_u_32.own(p_u_33, v70)
			local v_u_72 = not v_u_61 and 0 or v_u_61.EmissiveStrength
			local v_u_73 = -1
			local v74 = p_u_33.ticks
			local function v77()
				-- upvalues: (copy) v_u_48, (ref) v_u_73, (copy) v_u_71, (copy) v_u_61, (copy) v_u_72
				local v75 = v_u_48() * 20
				local v76 = math.floor(v75) / 20
				if v76 ~= v_u_73 then
					if v76 > 0.9 and v_u_73 <= 0.9 then
						v_u_71:Emit(3)
					end
					v_u_73 = v76
					if v_u_61 then
						v_u_61.EmissiveStrength = v_u_72 * (v76 * 2.5 + 1)
					end
				end
			end
			table.insert(v74, v77)
			local v_u_78 = {}
			for v79 = 1, 5 do
				local v80 = {}
				local v81 = v_u_7
				local v82 = v_u_10
				local v83 = Instance.new("WedgePart")
				v83.Anchored = true
				v83.CanCollide = false
				v83.CanQuery = false
				v83.CanTouch = false
				v83.CastShadow = false
				v83.Massless = true
				v83.Color = v81
				v83.Material = v82
				v83.Size = Vector3.new(0.1, 0.1, 0.1)
				v83.Parent = v_u_2.folder()
				v80.a = v83
				local v84 = v_u_6
				local v85 = v_u_9
				local v86 = Instance.new("WedgePart")
				v86.Anchored = true
				v86.CanCollide = false
				v86.CanQuery = false
				v86.CanTouch = false
				v86.CastShadow = false
				v86.Massless = true
				v86.Color = v84
				v86.Material = v85
				v86.Size = Vector3.new(0.1, 0.1, 0.1)
				v86.Parent = v_u_2.folder()
				v80.b = v86
				v80.ang = v79 * 3.141592653589793 * 2 / 5 + 0.3
				v80.len = (v79 % 2 * 0.8 + 2.2) * v_u_37
				v80.a.Transparency = 1
				v80.b.Transparency = 1
				table.insert(v_u_78, v80)
			end
			for _, v_u_87 in v_u_78 do
				local function v_u_95(p88) -- name: frameOf
					-- upvalues: (copy) v_u_87, (ref) p_u_32, (copy) p_u_33, (copy) v_u_37
					local v89 = v_u_87.ang
					local v90 = math.cos(v89)
					local v91 = v_u_87.ang
					local v92 = math.sin(v91)
					local v93 = Vector3.new(v90, 0, v92)
					local v94 = p_u_32.feetAt(p_u_33, p88, v_u_37 * -0.2) + v93 * 2 * v_u_37
					return CFrame.lookAt(v94, v94 + v93) * CFrame.Angles(-0.35, 0, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
				end
				p_u_32.add(p_u_33, v_u_87.a, function(p96)
					-- upvalues: (ref) v_u_26, (copy) v_u_95, (copy) v_u_87, (copy) v_u_48, (copy) v_u_37
					local v97 = v_u_26
					local v98 = v_u_95(p96)
					local v99 = v_u_87.len
					local v100 = v_u_48()
					local v101
					if v100 <= 0 then
						v101 = 0
					else
						local v102 = 1 - v100
						local v103 = v102 / 0.12
						local v104 = math.clamp(v103, 0, 1)
						local v105 = v104 * v104 * (3 - v104 * 2)
						local v106 = (v102 - 0.45) / 0.35
						local v107 = math.clamp(v106, 0, 1)
						v101 = v105 * (1 - v107 * v107 * (3 - v107 * 2))
					end
					return v97(v98, v99 * v101, v_u_37 * 0.8)
				end)
				p_u_32.add(p_u_33, v_u_87.b, function(p108)
					-- upvalues: (ref) v_u_26, (copy) v_u_95, (copy) v_u_87, (copy) v_u_48, (copy) v_u_37
					local v109 = v_u_26
					local v110 = v_u_95(p108)
					local v111 = v_u_87.len
					local v112 = v_u_48()
					local v113
					if v112 <= 0 then
						v113 = 0
					else
						local v114 = 1 - v112
						local v115 = v114 / 0.12
						local v116 = math.clamp(v115, 0, 1)
						local v117 = v116 * v116 * (3 - v116 * 2)
						local v118 = (v114 - 0.45) / 0.35
						local v119 = math.clamp(v118, 0, 1)
						v113 = v117 * (1 - v119 * v119 * (3 - v119 * 2))
					end
					local _, v120 = v109(v110, v111 * v113, v_u_37 * 0.8)
					return v120
				end)
			end
			local v_u_121 = false
			local v_u_122 = -1
			local v123 = p_u_33.ticks
			local function v142()
				-- upvalues: (copy) v_u_48, (ref) v_u_122, (ref) v_u_121, (copy) v_u_78, (copy) v_u_37
				local v124 = v_u_48()
				local v125
				if v124 <= 0 then
					v125 = 0
				else
					local v126 = 1 - v124
					local v127 = v126 / 0.12
					local v128 = math.clamp(v127, 0, 1)
					local v129 = v128 * v128 * (3 - v128 * 2)
					local v130 = (v126 - 0.45) / 0.35
					local v131 = math.clamp(v130, 0, 1)
					v125 = v129 * (1 - v131 * v131 * (3 - v131 * 2))
				end
				local v132 = v125 > 0.01
				local v133
				if v132 then
					local v134 = v125 * 30
					v133 = math.floor(v134) / 30 + 0.001
				else
					v133 = -0.5
				end
				if v133 ~= v_u_122 then
					v_u_122 = v133
					if v132 ~= v_u_121 then
						v_u_121 = v132
						for _, v135 in v_u_78 do
							v135.a.Transparency = v132 and 0 or 1
							v135.b.Transparency = v132 and 0.05 or 1
						end
					end
					if v132 then
						for _, v136 in v_u_78 do
							local v137 = v_u_37 * 0.2
							local v138 = v136.len * v125
							local v139 = math.max(v138, 0.05)
							local v140 = v_u_37 * 0.4
							local v141 = Vector3.new(v137, v139, v140)
							v136.a.Size = v141
							v136.b.Size = v141
						end
					end
				end
			end
			table.insert(v123, v142)
			local v143 = Instance.new("ParticleEmitter")
			v143.Texture = v_u_5.FxSmoke
			v143.FlipbookLayout = v_u_11
			v143.FlipbookMode = Enum.ParticleFlipbookMode.Random
			v143.Color = ColorSequence.new(v_u_6, v_u_7)
			v143.LightEmission = 0
			v143.LightInfluence = 0
			v143.Lifetime = NumberRange.new(1.5, 2.1)
			v143.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_37 * 1.5 * p_u_33.fx), NumberSequenceKeypoint.new(1, v_u_37 * 3 * p_u_33.fx) })
			v143.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.15, 0.15),
				NumberSequenceKeypoint.new(0.7, 0.35),
				NumberSequenceKeypoint.new(1, 1)
			})
			v143.Speed = NumberRange.new(v_u_37 * 0.6, v_u_37 * 1.6)
			v143.SpreadAngle = Vector2.new(85, 85)
			v143.EmissionDirection = Enum.NormalId.Top
			local v144 = v_u_37 * 0.5
			v143.Acceleration = Vector3.new(0, v144, 0)
			v143.Rotation = NumberRange.new(0, 360)
			v143.RotSpeed = NumberRange.new(-40, 40)
			v143.Shape = Enum.ParticleEmitterShape.Box
			v143.ShapeStyle = Enum.ParticleEmitterShapeStyle.Volume
			v143:SetAttribute("BaseRate", 10)
			v143.Rate = 10 * v_u_4.formRate()
			v143.Parent = v43
			local v145 = v_u_31(v_u_5.TatarVeins, v35, 0.25)
			v145.Lifetime = NumberRange.new(2.6)
			v145.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, v_u_37 * 2.4 * v39), NumberSequenceKeypoint.new(1, v_u_37 * 2.9 * v39) })
			v145.Transparency = NumberSequence.new({
				NumberSequenceKeypoint.new(0, 1),
				NumberSequenceKeypoint.new(0.3, 0.45),
				NumberSequenceKeypoint.new(0.6, 0.55),
				NumberSequenceKeypoint.new(1, 1)
			})
			v145.Rotation = NumberRange.new(0, 360)
			v145.RotSpeed = NumberRange.new(-8, 8)
			v145:SetAttribute("BaseRate", 0.8)
			v145.Rate = 0.8 * v_u_4.formRate()
			v145.Enabled = true
			v145.Parent = v45
			p_u_32.particles(p_u_33, "AuraMode", v35, {
				["rate"] = 0.3,
				["glow"] = 0.4,
				["only"] = nil,
				["only"] = { "Glow", "Sparks" }
			})
		end
	}
end