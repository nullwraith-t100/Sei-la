local v_u_29 = {
	["CONE"] = 60,
	["KEEP_CONE"] = 80,
	["pick"] = function(p1, p2, p3, p4, p5, p6) -- name: pick
		-- upvalues: (copy) v_u_29
		local v7 = p2.X
		local v8 = p2.Z
		local v9 = Vector3.new(v7, 0, v8)
		local v10 = v9.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v9.Unit
		local v11 = v_u_29.CONE
		local v12 = math.rad(v11)
		local v13 = math.cos(v12)
		local v14 = v_u_29.KEEP_CONE
		local v15 = math.rad(v14)
		local v16 = math.cos(v15)
		local v17 = p4
		local v18 = (1 / 0)
		local v19 = nil
		local v20 = nil
		for _, v21 in p3 do
			local v22 = v21.pos - p1
			local v23 = v22.X
			local v24 = v22.Z
			local v25 = Vector3.new(v23, 0, v24)
			local v26 = v25.Magnitude
			local v27 = v26 <= 0.001 and 1 or v25.Unit:Dot(v10)
			if p6 ~= nil and (v21.id == p6 and (v26 <= p5 and v16 <= v27)) then
				return v21
			end
			if v26 > v17 then
				continue
			end
			if v26 <= p4 then
				v20 = v21
				p4 = v26
			end
			if v13 > v27 then
				continue
			end
			local v28 = v26 * (1 + (1 - v27) * 1.5)
			if v28 >= v18 then
				continue
			end
			v19 = v21
			v18 = v28
		end
		return v19 or v20
	end
}
return v_u_29