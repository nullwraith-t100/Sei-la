local v1 = game:GetService("ReplicatedStorage")
require(script.Parent.Parent.FormTypes)
local v_u_2 = require(script.Parent.Parent.Kit)
local v_u_3 = require(v1.Shared.Config.Textures)
local v_u_4 = Color3.fromRGB(226, 230, 244)
local v_u_5 = Color3.fromRGB(246, 248, 255)
local v_u_6 = Color3.fromRGB(205, 222, 255)
local v_u_7 = Color3.fromRGB(150, 182, 255)
return function(p_u_8)
	-- upvalues: (copy) v_u_2, (copy) v_u_6, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7
	return {
		["w3_moon_rinne"] = function(p_u_9, _)
			-- upvalues: (copy) p_u_8, (ref) v_u_2, (ref) v_u_6, (ref) v_u_3, (ref) v_u_5, (ref) v_u_4, (ref) v_u_7
			local v_u_10 = p_u_9.fx <= 1 and 1 or p_u_9.fx / 1.35
			local v11 = 1.7 * v_u_10
			local v12 = 0.9 * v_u_10
			local v_u_13 = Vector3.new(0, v11, v12)
			local v_u_14 = 4 * v_u_10
			local v_u_16 = p_u_8.throb(p_u_9, 3.6, 1.7999999999999996, 1.3, function(p15)
				-- upvalues: (ref) v_u_2, (ref) p_u_8, (copy) p_u_9, (ref) v_u_6, (ref) v_u_3, (copy) v_u_13, (copy) v_u_14, (ref) v_u_5, (copy) v_u_10
				v_u_2.ring(p_u_8.feetAt(p_u_9, p15, 0.15), v_u_6, 5.5 * p_u_9.fx, 0.55, v_u_3.Ring)
				v_u_2.flash(p15:PointToWorldSpace(v_u_13 + Vector3.new(0.00000000000000006123234, 1, 0) * v_u_14), v_u_5, 3 * v_u_10, 0.35)
			end)
			p_u_8.add(p_u_9, p_u_8.picture(v_u_14 * 2 + 0.3 * v_u_10, v_u_3.Ring, v_u_6, 0.75), function(p17)
				-- upvalues: (copy) v_u_13
				return p17 * CFrame.new(v_u_13) * CFrame.Angles(1.5707963267948966, 0, 0)
			end)
			for v_u_18 = 1, 5 do
				local v_u_19 = p_u_8.ball(1, v_u_4, 1, Enum.Material.SmoothPlastic)
				local v_u_20 = p_u_8.scalable(v_u_19)
				v_u_20.MeshType = Enum.MeshType.Sphere
				p_u_8.add(p_u_9, v_u_19, function(p21, p22)
					-- upvalues: (copy) v_u_18, (copy) v_u_13, (copy) v_u_14
					local v23 = CFrame.new
					local v24 = v_u_18
					local v25 = 3.141592653589793 * (1 - (p22 * 0.05555555555555555 + (v24 - 1) / 5) % 1)
					local v26 = math.cos(v25)
					local v27 = math.sin(v25)
					return p21 * v23(v_u_13 + Vector3.new(v26, v27, 0) * v_u_14)
				end)
				local v28 = 1.2 * v_u_10 * 0.3338068592337709 * 1.15
				local v_u_29 = {}
				for v_u_30 = 1, 4 do
					local v31 = (v_u_30 - 0.5) / 4 * 2 - 1
					local v32 = 1 - math.abs(v31)
					local v33 = p_u_8.bar
					local v34 = (v32 * 0.2 + 0.12) * v_u_10
					local v35 = 0.12 * v_u_10
					local v36 = v33(Vector3.new(v34, v35, v28), v_u_5, 1)
					table.insert(v_u_29, v36)
					p_u_8.add(p_u_9, v36, function(p37, p38)
						-- upvalues: (copy) v_u_18, (copy) v_u_13, (copy) v_u_14, (copy) v_u_10, (copy) v_u_30
						local v39 = v_u_18
						local v40 = 3.141592653589793 * (1 - (p38 * 0.05555555555555555 + (v39 - 1) / 5) % 1)
						local v41 = math.cos(v40)
						local v42 = math.sin(v40)
						local v43 = Vector3.new(v41, v42, 0)
						local v44 = v_u_13 + v43 * v_u_14
						local v45 = -v43.Y
						local v46 = v43.X
						local v47 = Vector3.new(v45, v46, 0)
						local v48 = 0.6 * v_u_10
						local v49 = (v_u_30 - 1) / 4 * 2.722713633111154 + -1.361356816555577
						local v50 = v44 + (v43 * math.cos(v49) + v47 * math.sin(v49)) * v48
						local v51 = v_u_30 / 4 * 2.722713633111154 + -1.361356816555577
						local v52 = v44 + (v43 * math.cos(v51) + v47 * math.sin(v51)) * v48
						return p37 * CFrame.lookAt((v50 + v52) / 2, v52, Vector3.new(0, 0, 1))
					end)
				end
				local v_u_53 = -1
				local v54 = p_u_9.ticks
				local function v73(_, p55)
					-- upvalues: (copy) v_u_18, (copy) v_u_16, (copy) v_u_20, (copy) v_u_10, (copy) v_u_19, (ref) v_u_53, (copy) v_u_29
					local v56 = v_u_18
					local v57 = (p55 * 0.05555555555555555 + (v56 - 1) / 5) % 1
					local v58 = 3.141592653589793 * v57
					local v59 = math.sin(v58)
					local v60 = 1 - v57
					local v61 = math.min(v57, v60) / 0.08
					local v62 = math.clamp(v61, 0, 1)
					local v63 = v62 * v62 * (3 - v62 * 2)
					local v64 = (v59 - 0.55) / 0.3
					local v65 = math.clamp(v64, 0, 1)
					local v66 = v65 * v65 * (3 - v65 * 2)
					local v67 = v_u_16() * 0.3
					local v68 = (v59 - 0.9) / 0.1
					local v69 = math.clamp(v68, 0, 1)
					local v70 = 1 + v67 * (v69 * v69 * (3 - v69 * 2))
					v_u_20.Scale = Vector3.new(1, 1, 1) * (v59 * 0.75 + 0.45) * v_u_10 * v70
					v_u_19.Transparency = 1 - v63 * v66
					local v71 = 1 - v63 * (1 - v66)
					if v71 ~= v_u_53 then
						v_u_53 = v71
						for _, v72 in v_u_29 do
							v72.Transparency = v71
						end
					end
				end
				table.insert(v54, v73)
			end
			local v_u_74 = p_u_8.ball(2 * v_u_10, v_u_6, 1)
			p_u_8.add(p_u_9, v_u_74, function(p75)
				-- upvalues: (copy) v_u_13, (copy) v_u_14, (ref) p_u_8
				local v76 = p75:PointToWorldSpace(v_u_13 + Vector3.new(0.00000000000000006123234, 1, 0) * v_u_14)
				return CFrame.new(v76 + (v76 - p_u_8.camPos()).Unit * 0.5)
			end)
			local v77 = p_u_9.ticks
			table.insert(v77, function(_, p78)
				-- upvalues: (copy) v_u_74, (copy) v_u_16
				local v79 = 0
				for v80 = 1, 5 do
					local v81 = 3.141592653589793 * ((p78 * 0.05555555555555555 + (v80 - 1) / 5) % 1)
					local v82 = math.sin(v81)
					v79 = math.max(v79, v82)
				end
				local v83 = (v79 - 0.94) / 0.06
				local v84 = math.clamp(v83, 0, 1)
				local v85 = v84 * v84 * (3 - v84 * 2)
				v_u_74.Transparency = 1 - (0.25 + 0.2 * v_u_16()) * v85
			end)
			p_u_8.particles(p_u_9, "Petals", v_u_6, {
				["rate"] = 1,
				["glow"] = 0.7,
				["only"] = nil,
				["only"] = { "Motes" }
			})
			p_u_8.particles(p_u_9, "AuraMode", v_u_7, {
				["rate"] = 0.35,
				["glow"] = 0.5,
				["only"] = nil,
				["only"] = { "Glow", "Streaks" }
			})
		end
	}
end